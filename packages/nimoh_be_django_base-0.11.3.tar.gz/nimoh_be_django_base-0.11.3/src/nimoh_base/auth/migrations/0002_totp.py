# Generated migration for TOTP two-factor authentication

import django.db.models.deletion
import django.utils.timezone
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("nimoh_auth", "0001_initial"),
    ]

    operations = [
        # ── Add two_factor_enabled to the concrete User model ─────────────────
        migrations.AddField(
            model_name="user",
            name="two_factor_enabled",
            field=models.BooleanField(
                default=False,
                help_text="Whether TOTP two-factor authentication is active on this account.",
            ),
        ),
        # ── TOTPDevice ─────────────────────────────────────────────────────────
        migrations.CreateModel(
            name="TOTPDevice",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "user",
                    models.OneToOneField(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="totp_device",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "secret",
                    models.CharField(
                        help_text="Base32-encoded TOTP secret.  Treat as write-once.",
                        max_length=64,
                    ),
                ),
                (
                    "name",
                    models.CharField(
                        blank=True,
                        default="Authenticator App",
                        help_text="Human-readable label shown in the authenticator app.",
                        max_length=64,
                    ),
                ),
                (
                    "confirmed",
                    models.BooleanField(
                        default=False,
                        help_text="True once the user verified the device with a valid TOTP code.",
                    ),
                ),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={
                "verbose_name": "TOTP Device",
                "verbose_name_plural": "TOTP Devices",
                "db_table": "nimoh_auth_totp_device",
            },
        ),
        # ── BackupCode ─────────────────────────────────────────────────────────
        migrations.CreateModel(
            name="BackupCode",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="backup_codes",
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
                (
                    "code_hash",
                    models.CharField(
                        help_text="HMAC-SHA256 of the plain backup code.",
                        max_length=64,
                    ),
                ),
                ("used", models.BooleanField(default=False)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("used_at", models.DateTimeField(blank=True, null=True)),
            ],
            options={
                "verbose_name": "Backup Code",
                "verbose_name_plural": "Backup Codes",
                "db_table": "nimoh_auth_backup_code",
            },
        ),
        migrations.AddIndex(
            model_name="backupcode",
            index=models.Index(fields=["user", "used"], name="nimoh_auth_b_user_used_idx"),
        ),
    ]
