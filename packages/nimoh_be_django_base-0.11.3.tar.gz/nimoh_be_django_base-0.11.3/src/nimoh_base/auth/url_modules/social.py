"""URL module: social auth (thin wrapper around social-auth-app-django).

Include in your root URLconf::

    path("auth/social/", include("nimoh_base.auth.url_modules.social")),

All login / redirect / disconnect endpoints are delegated to
``social_django.urls``.
"""

from __future__ import annotations

from django.urls import include, path

app_name = "social"

urlpatterns = [
    path("", include("social_django.urls", namespace="social")),
]
