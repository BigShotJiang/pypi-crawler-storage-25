"""URL module: mobile authentication endpoints.

Include in your root URLconf::

    path("api/v1/auth/mobile/", include("nimoh_base.auth.url_modules.mobile")),

Or use ``nimoh_base_mobile_urlpatterns()`` which wires this automatically.
"""

from django.urls import path

from ..view_modules.mobile import GoogleMobileAuthView, MobileExchangeTokenView

app_name = "mobile"

urlpatterns = [
    path("google/", GoogleMobileAuthView.as_view(), name="google-auth"),
    path("token/refresh/", MobileExchangeTokenView.as_view(), name="token-refresh"),
]
