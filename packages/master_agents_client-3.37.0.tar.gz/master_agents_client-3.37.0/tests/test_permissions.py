"""Tests for E47 — granular permission rules.

The `PermissionsConfig` engine matches tool calls against allow / deny
rule lists using Claude-Code-parity `Tool(<arg-pattern>)` syntax.
Lives in `master_agents_client.permissions` because enforcement runs
in `RemoteToolExecutor` (client-side, per E45).

`ask` tier deferred to a follow-up — Wave 1 ships allow + deny only.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from master_agents_client.permissions import (
    PermissionsConfig,
    PermissionVerdict,
    parse_rule,
    rules_from_legacy_writable_paths,
)


# --- parse_rule: rule string → (tool_name, pattern) -----------------------


def test_parse_bare_tool_name() -> None:
    # `Bash` alone matches the bash tool with ANY arguments.
    name, pattern = parse_rule("Bash")
    assert name == "bash"
    assert pattern is None


def test_parse_tool_with_glob_pattern() -> None:
    name, pattern = parse_rule("Write(./src/**)")
    assert name == "write_file"  # Write → write_file (Claude Code canonical)
    assert pattern == "./src/**"


def test_parse_tool_with_prefix_pattern() -> None:
    name, pattern = parse_rule("Bash(rm -rf:*)")
    assert name == "bash"
    assert pattern == "rm -rf:*"


def test_parse_lowercase_tool_name_accepted() -> None:
    # Be tolerant — accept lowercase too (matches BUILTINS).
    name, pattern = parse_rule("bash(rm:*)")
    assert name == "bash"
    assert pattern == "rm:*"


def test_parse_unknown_tool_alias_passes_through_lowercase() -> None:
    # Unknown aliases (e.g. future tools) pass through as lowercase.
    # Match-time check is still strict (no match if name doesn't exist
    # in the live tool registry).
    name, pattern = parse_rule("FutureTool(arg)")
    assert name == "futuretool"
    assert pattern == "arg"


def test_parse_rejects_malformed_rule() -> None:
    with pytest.raises(ValueError):
        parse_rule("Bash(unclosed")
    with pytest.raises(ValueError):
        parse_rule("()")
    with pytest.raises(ValueError):
        parse_rule("")


# --- PermissionsConfig: match algorithm -----------------------------------


def test_deny_blocks_matching_call() -> None:
    cfg = PermissionsConfig(deny=["Bash(rm -rf:*)"])
    verdict = cfg.check("bash", {"command": "rm -rf /tmp/stuff"})
    assert verdict.action == "deny"
    assert "rm -rf" in verdict.reason.lower()


def test_allow_permits_matching_call() -> None:
    cfg = PermissionsConfig(allow=["Bash(git status:*)"])
    verdict = cfg.check("bash", {"command": "git status -s"})
    assert verdict.action == "allow"


def test_deny_takes_precedence_over_allow() -> None:
    # Same tool matches both lists → deny wins (safest default).
    cfg = PermissionsConfig(
        allow=["Bash"],
        deny=["Bash(rm -rf:*)"],
    )
    verdict = cfg.check("bash", {"command": "rm -rf /"})
    assert verdict.action == "deny"


def test_no_match_falls_back_to_default() -> None:
    # An empty config + no matching rules → default behavior. Default
    # is "allow" for back-compat with pre-E47 sessions (where the only
    # gate was writable_paths). Callers wanting stricter posture use
    # an explicit allow list.
    cfg = PermissionsConfig()
    verdict = cfg.check("read_file", {"path": "/etc/hosts"})
    assert verdict.action == "allow"


def test_glob_match_on_path() -> None:
    cfg = PermissionsConfig(allow=["Write(./src/**)"])
    verdict = cfg.check("write_file", {"path": "./src/foo/bar.py"})
    assert verdict.action == "allow"
    verdict = cfg.check("write_file", {"path": "./tests/foo.py"})
    # No match → fallback default (allow today; explicit allow list
    # doesn't BLOCK calls outside its globs, it just doesn't actively
    # whitelist them. Strict mode = combine with a deny catch-all.).
    assert verdict.action == "allow"


def test_prefix_pattern_with_colon_star_suffix() -> None:
    # `Bash(git:*)` matches commands starting with "git" + anything.
    cfg = PermissionsConfig(allow=["Bash(git:*)"])
    verdict = cfg.check("bash", {"command": "git push origin main"})
    assert verdict.action == "allow"


def test_prefix_pattern_does_not_match_unrelated_command() -> None:
    cfg = PermissionsConfig(deny=["Bash(git:*)"])
    verdict = cfg.check("bash", {"command": "ls -la"})
    # `ls -la` doesn't match `git:*` → no deny rule fires → fallback allow.
    assert verdict.action == "allow"


def test_bare_tool_name_matches_any_args() -> None:
    cfg = PermissionsConfig(deny=["Bash"])
    verdict = cfg.check("bash", {"command": "anything"})
    assert verdict.action == "deny"
    verdict = cfg.check("bash", {})
    assert verdict.action == "deny"


def test_unrelated_tool_not_affected_by_rule() -> None:
    cfg = PermissionsConfig(deny=["Bash"])
    verdict = cfg.check("read_file", {"path": "/etc/hosts"})
    assert verdict.action == "allow"  # bash deny doesn't touch read_file


def test_subset_deny_overrides_broader_allow() -> None:
    # MAO-reviewer-flagged gap (Wave 1 triangulation 2026-05-14):
    # broad allow + narrow deny → narrow deny wins on its scope but
    # the broad allow still applies everywhere else. This is the
    # "carve a hole in the allowlist" pattern.
    cfg = PermissionsConfig(
        allow=["Write(./**)"],
        deny=["Write(./secrets/**)"],
    )
    # Inside the hole → blocked.
    v_hole = cfg.check("write_file", {"path": "./secrets/keys.txt"})
    assert v_hole.action == "deny"
    # Outside the hole → still allowed by the broad rule.
    v_outside = cfg.check("write_file", {"path": "./src/foo.py"})
    assert v_outside.action == "allow"


# --- Migration from legacy writable_paths --------------------------------


def test_legacy_writable_paths_expands_to_allow_rules() -> None:
    rules = rules_from_legacy_writable_paths(["./src", "/tmp/scratch"])
    # Should produce Write/Edit/MultiEdit/Append entries for each path.
    assert any("Write(./src" in r or "write_file" in r.lower() for r in rules)
    assert any("/tmp/scratch" in r for r in rules)


def test_legacy_writable_paths_empty_returns_empty() -> None:
    assert rules_from_legacy_writable_paths([]) == []


def test_legacy_writable_paths_dot_expands_correctly() -> None:
    # The default config has writable_paths=["."]. Make sure that
    # round-trips through the migration without breaking.
    rules = rules_from_legacy_writable_paths(["."])
    # All write-side tools should be covered.
    rule_text = " ".join(rules).lower()
    assert "write" in rule_text
    assert "edit" in rule_text


# --- YAML round-trip ------------------------------------------------------


def test_permissions_config_yaml_round_trip(tmp_path: Path) -> None:
    cfg = PermissionsConfig(
        allow=["Write(./**)", "Bash(git:*)"],
        deny=["Bash(rm -rf:*)", "Write(/etc/**)"],
    )
    yaml_text = cfg.to_yaml_dict()
    # Re-read into a new config.
    cfg2 = PermissionsConfig.from_yaml_dict(yaml_text)
    assert cfg2.allow == cfg.allow
    assert cfg2.deny == cfg.deny


def test_permissions_config_from_empty_dict() -> None:
    cfg = PermissionsConfig.from_yaml_dict({})
    assert cfg.allow == []
    assert cfg.deny == []


def test_permissions_config_from_none_yaml() -> None:
    # `permissions: null` in remote.yaml → load as default empty.
    cfg = PermissionsConfig.from_yaml_dict(None)
    assert cfg.allow == []
    assert cfg.deny == []


# --- Verdict shape --------------------------------------------------------


def test_verdict_carries_reason_for_deny() -> None:
    cfg = PermissionsConfig(deny=["Bash(rm -rf:*)"])
    verdict = cfg.check("bash", {"command": "rm -rf /"})
    assert verdict.action == "deny"
    # Reason mentions the matching rule so the agent (and the user
    # reading the trace) sees WHY the call was blocked.
    assert "rm -rf" in verdict.reason
    assert "deny" in verdict.reason.lower() or "block" in verdict.reason.lower()


def test_verdict_reason_empty_for_allow() -> None:
    cfg = PermissionsConfig(allow=["Bash"])
    verdict = cfg.check("bash", {"command": "ls"})
    assert verdict.action == "allow"
    # Allow verdicts don't need a reason — keep the field empty for
    # callers that emit traces.
    assert verdict.reason == ""
