"""Tests for E48 — CLAUDE.md auto-walk at session start.

The walker lives in `master_agents_client.project_context` because
the walk + cost-gate runs on the user's machine (per E45 client-side
filesystem rule). Server-side injection of the resulting block is
tested in the server suite.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from master_agents_client.project_context import (
    ProjectContextTooLarge,
    collect_project_context_files,
    render_project_context,
)


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


# --- collect_project_context_files -----------------------------------------


def test_walk_finds_claude_md_in_cwd(tmp_path: Path) -> None:
    cwd = tmp_path / "project"
    _write(cwd / "CLAUDE.md", "# Project rules")
    files = collect_project_context_files(cwd, terminate_at=tmp_path)
    assert [str(p) for p in files] == [str(cwd / "CLAUDE.md")]


def test_walk_collects_parents_outermost_first(tmp_path: Path) -> None:
    outer = tmp_path / "platforms_os"
    inner = outer / "master_agents_os"
    _write(outer / "CLAUDE.md", "# Outer rules")
    _write(inner / "CLAUDE.md", "# Inner rules")
    files = collect_project_context_files(inner, terminate_at=tmp_path)
    assert [p.parent.name for p in files] == ["platforms_os", "master_agents_os"]


def test_walk_terminates_at_terminate_at(tmp_path: Path) -> None:
    # CLAUDE.md exists ABOVE the terminate_at boundary; must be excluded.
    above = tmp_path / "above"
    boundary = above / "boundary"
    inside = boundary / "inside"
    _write(above / "CLAUDE.md", "# above boundary")
    _write(boundary / "CLAUDE.md", "# at boundary")
    _write(inside / "CLAUDE.md", "# below boundary")
    files = collect_project_context_files(inside, terminate_at=boundary)
    names = [str(p.relative_to(tmp_path)) for p in files]
    # Walker should stop at `boundary` inclusive — the file ABOVE it is
    # off-limits.
    assert "above\\CLAUDE.md" not in names and "above/CLAUDE.md" not in names


def test_walk_does_not_stop_at_git_marker(tmp_path: Path) -> None:
    """UAT 2026-05-14 finding: nested git repos are common in this
    workspace pattern (platforms_os contains master_agents_os, both
    are git repos). Stopping at the first `.git` would lose the
    outer repo's CLAUDE.md, violating ROADMAP E48's acceptance
    criterion. Walker now relies on `terminate_at` + `max_depth`
    bounds instead. This test pins the new behaviour.
    """
    outer = tmp_path / "outer"
    inner = outer / "inner"
    nested = inner / "src" / "module"
    (outer / ".git").mkdir(parents=True)  # marker on OUTER
    (inner / ".git").mkdir(parents=True)  # marker on INNER (nested)
    _write(outer / "CLAUDE.md", "# OUTER rules")
    _write(inner / "CLAUDE.md", "# INNER rules")
    _write(nested / "CLAUDE.md", "# MODULE rules")
    files = collect_project_context_files(nested, terminate_at=tmp_path)
    # All three CLAUDE.md files must be collected — neither .git
    # marker should stop the walk.
    parent_names = [p.parent.name for p in files]
    assert "outer" in parent_names
    assert "inner" in parent_names
    assert "module" in parent_names


def test_walk_returns_empty_when_no_claude_md(tmp_path: Path) -> None:
    cwd = tmp_path / "empty" / "subdir"
    cwd.mkdir(parents=True)
    files = collect_project_context_files(cwd, terminate_at=tmp_path)
    assert files == []


def test_walk_max_depth_cap(tmp_path: Path) -> None:
    # 15 nested directories; max_depth=3 stops after 3 levels.
    cwd = tmp_path
    for i in range(15):
        cwd = cwd / f"d{i}"
    cwd.mkdir(parents=True)
    # Spread CLAUDE.md files at various levels
    for parent in cwd.parents:
        if parent == tmp_path.parent:
            break
        _write(parent / "CLAUDE.md", f"# at {parent.name}")
    files = collect_project_context_files(cwd, terminate_at=tmp_path, max_depth=3)
    # cwd itself is depth-0; with max_depth=3, walker visits 0..3 inclusive (4 levels).
    assert len(files) <= 4


def test_walk_handles_unreadable_file(tmp_path: Path) -> None:
    # If a CLAUDE.md exists but can't be opened (rare), walker must not
    # crash — degrades to skipping that file.
    cwd = tmp_path / "project"
    cwd.mkdir()
    # Create a path that LOOKS like CLAUDE.md but is actually a directory.
    (cwd / "CLAUDE.md").mkdir()
    files = collect_project_context_files(cwd, terminate_at=tmp_path)
    # CLAUDE.md exists but is a dir — exclude.
    assert files == []


# --- render_project_context ------------------------------------------------


def test_render_returns_empty_block_for_no_files(tmp_path: Path) -> None:
    block, disclosure = render_project_context([])
    assert block == ""
    assert disclosure == ""


def test_render_concatenates_files_in_order(tmp_path: Path) -> None:
    f1 = tmp_path / "outer" / "CLAUDE.md"
    f2 = tmp_path / "outer" / "inner" / "CLAUDE.md"
    _write(f1, "OUTER CONTENT")
    _write(f2, "INNER CONTENT")
    block, _ = render_project_context([f1, f2])
    assert "OUTER CONTENT" in block
    assert "INNER CONTENT" in block
    # Outer must appear BEFORE inner (general rules first, specific overrides last).
    assert block.index("OUTER CONTENT") < block.index("INNER CONTENT")


def test_render_wraps_in_project_context_tag(tmp_path: Path) -> None:
    f = tmp_path / "CLAUDE.md"
    _write(f, "content")
    block, _ = render_project_context([f])
    assert block.startswith("<project_context>")
    assert block.rstrip().endswith("</project_context>")


def test_render_includes_file_path_anchor(tmp_path: Path) -> None:
    # Each file's content gets a path header so the agent can cite
    # which CLAUDE.md a rule came from.
    f = tmp_path / "sub" / "CLAUDE.md"
    _write(f, "RULE A")
    block, _ = render_project_context([f])
    assert str(f) in block or "sub/CLAUDE.md" in block.replace("\\", "/")


def test_render_silent_under_30k_tokens(tmp_path: Path) -> None:
    f = tmp_path / "CLAUDE.md"
    _write(f, "x" * 10_000)  # ~2.5k tokens — under the silent gate
    _, disclosure = render_project_context([f])
    assert disclosure == ""


def test_render_disclosure_between_30k_and_80k(tmp_path: Path) -> None:
    # ~150k chars ≈ 37k tokens → in the disclose band.
    f = tmp_path / "CLAUDE.md"
    _write(f, "x" * 150_000)
    _, disclosure = render_project_context([f])
    assert disclosure  # non-empty
    assert "token" in disclosure.lower() or "context" in disclosure.lower()


def test_render_aborts_above_80k(tmp_path: Path) -> None:
    # ~400k chars ≈ 100k tokens → above hard cap.
    f = tmp_path / "CLAUDE.md"
    _write(f, "x" * 400_000)
    with pytest.raises(ProjectContextTooLarge) as exc:
        render_project_context([f])
    msg = str(exc.value)
    assert "--no-project-context" in msg or "80" in msg


def test_render_byte_stable_across_calls(tmp_path: Path) -> None:
    f1 = tmp_path / "a" / "CLAUDE.md"
    f2 = tmp_path / "b" / "CLAUDE.md"
    _write(f1, "content A")
    _write(f2, "content B")
    files = [f1, f2]
    first_block, _ = render_project_context(files)
    second_block, _ = render_project_context(files)
    assert first_block == second_block


# --- end-to-end (walk + render) --------------------------------------------


def test_end_to_end_two_level_project(tmp_path: Path) -> None:
    outer = tmp_path / "platforms_os"
    inner = outer / "master_agents_os"
    _write(outer / "CLAUDE.md", "# Project-wide rules\n\nNo model upgrades without approval.")
    _write(inner / "CLAUDE.md", "# Master-agents sub-platform rules\n\nFeat branch discipline.")
    files = collect_project_context_files(inner, terminate_at=tmp_path)
    block, disclosure = render_project_context(files)
    assert "No model upgrades" in block
    assert "Feat branch discipline" in block
    assert disclosure == ""  # both files are small


def test_render_continues_past_unreadable_file_in_middle(
    tmp_path: Path,
) -> None:
    # MAO-reviewer-flagged gap (Wave 1 triangulation 2026-05-14):
    # render_project_context catches OSError/UnicodeDecodeError per
    # file and `continue`s. Pin that an unreadable file in the
    # MIDDLE of the list doesn't prevent files AFTER it from being
    # included.
    readable_a = tmp_path / "a" / "CLAUDE.md"
    unreadable = tmp_path / "b" / "CLAUDE.md"
    readable_c = tmp_path / "c" / "CLAUDE.md"
    _write(readable_a, "CONTENT A")
    _write(readable_c, "CONTENT C")
    # Simulate unreadable by giving a Path that points at a directory
    # masquerading as the .md file. parse_atom / read_text both
    # raise on this — exercises the `continue` path.
    unreadable.mkdir(parents=True)
    block, _ = render_project_context([readable_a, unreadable, readable_c])
    assert "CONTENT A" in block
    assert "CONTENT C" in block
