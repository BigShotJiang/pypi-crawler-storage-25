"""Tests for E49 — scheduled-agent runner.

Wave 3 minimum-viable: every/at scheduling forms, YAML round-trip,
add / list / remove / due / mark_fired.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from master_agents_client.scheduler import (
    Schedule,
    add_schedule,
    due_schedules,
    load_schedules,
    mark_fired,
    parse_daily_time,
    parse_duration,
    remove_schedule,
    save_schedules,
)


# --- parse_duration / parse_daily_time ---


def test_parse_duration_minutes() -> None:
    assert parse_duration("5m") == timedelta(minutes=5)
    assert parse_duration("30m") == timedelta(minutes=30)


def test_parse_duration_hours() -> None:
    assert parse_duration("1h") == timedelta(hours=1)
    assert parse_duration("24h") == timedelta(hours=24)


def test_parse_duration_days() -> None:
    assert parse_duration("7d") == timedelta(days=7)


def test_parse_duration_rejects_unknown_unit() -> None:
    with pytest.raises(ValueError):
        parse_duration("5s")
    with pytest.raises(ValueError):
        parse_duration("1w")
    with pytest.raises(ValueError):
        parse_duration("5")


def test_parse_duration_rejects_non_positive() -> None:
    with pytest.raises(ValueError):
        parse_duration("0m")
    with pytest.raises(ValueError):
        parse_duration("-5m")


def test_parse_daily_time_valid() -> None:
    assert parse_daily_time("09:00") == (9, 0)
    assert parse_daily_time("23:59") == (23, 59)
    assert parse_daily_time("0:00") == (0, 0)  # HH may be unpadded; MM always 2 digits


def test_parse_daily_time_rejects_out_of_range() -> None:
    with pytest.raises(ValueError):
        parse_daily_time("24:00")
    with pytest.raises(ValueError):
        parse_daily_time("12:60")


def test_parse_daily_time_rejects_malformed() -> None:
    with pytest.raises(ValueError):
        parse_daily_time("9am")
    with pytest.raises(ValueError):
        parse_daily_time("")


# --- Schedule.validate ---


def test_schedule_validate_requires_every_or_at() -> None:
    s = Schedule(name="x", master="m", prompt="p")
    with pytest.raises(ValueError):
        s.validate()


def test_schedule_validate_rejects_both_every_and_at() -> None:
    s = Schedule(name="x", master="m", prompt="p", every="1h", at="09:00")
    with pytest.raises(ValueError):
        s.validate()


def test_schedule_validate_rejects_bad_name() -> None:
    bad_names = ["", " ", "9starts-with-digit", "has spaces", "x" * 100]
    for bad in bad_names:
        s = Schedule(name=bad, master="m", prompt="p", every="1h")
        with pytest.raises(ValueError):
            s.validate()


def test_schedule_validate_accepts_valid() -> None:
    s = Schedule(name="nightly", master="m", prompt="p", every="24h")
    s.validate()  # no raise
    s2 = Schedule(name="morning", master="m", prompt="p", at="09:00")
    s2.validate()


# --- compute_next_fire ---


def test_compute_next_fire_every_advances_from_last_fire() -> None:
    s = Schedule(
        name="x", master="m", prompt="p", every="1h",
        last_fire_ts="2026-05-14T10:00:00+00:00",
    )
    nxt = s.compute_next_fire()
    assert nxt == datetime(2026, 5, 14, 11, 0, tzinfo=timezone.utc)


def test_compute_next_fire_every_uses_now_when_no_last_fire() -> None:
    s = Schedule(name="x", master="m", prompt="p", every="5m")
    now = datetime(2026, 5, 14, 12, 0, tzinfo=timezone.utc)
    nxt = s.compute_next_fire(now=now)
    assert nxt == datetime(2026, 5, 14, 12, 5, tzinfo=timezone.utc)


def test_compute_next_fire_at_returns_today_when_in_future(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Force LOCAL timezone semantics by passing an explicit `now`.
    s = Schedule(name="x", master="m", prompt="p", at="23:59")
    now = datetime(2026, 5, 14, 12, 0, tzinfo=timezone.utc)
    nxt = s.compute_next_fire(now=now)
    # The exact UTC value depends on the test runner's local TZ; we
    # just assert it's in the future and within 24h.
    assert nxt > now
    assert nxt < now + timedelta(days=1) + timedelta(hours=12)


def test_compute_next_fire_at_returns_tomorrow_when_already_past() -> None:
    s = Schedule(name="x", master="m", prompt="p", at="00:01")
    # `now` is 23:00 local — 00:01 has passed today (well, almost; depends on TZ).
    now = datetime(2026, 5, 14, 23, 0, tzinfo=timezone.utc)
    nxt = s.compute_next_fire(now=now)
    # Must be in the future relative to now.
    assert nxt > now


# --- YAML round-trip ---


def test_save_load_round_trip(tmp_path: Path) -> None:
    p = tmp_path / "schedules.yaml"
    schedules = [
        Schedule(name="a", master="m1", prompt="p1", every="1h"),
        Schedule(name="b", master="m2", prompt="p2", at="09:00"),
    ]
    save_schedules(schedules, path=p)
    loaded = load_schedules(path=p)
    assert len(loaded) == 2
    names = {s.name for s in loaded}
    assert names == {"a", "b"}


def test_load_returns_empty_when_file_missing(tmp_path: Path) -> None:
    p = tmp_path / "nope.yaml"
    assert load_schedules(path=p) == []


def test_load_skips_malformed_entries(tmp_path: Path) -> None:
    p = tmp_path / "schedules.yaml"
    import yaml
    p.write_text(yaml.safe_dump({
        "schema_version": 1,
        "schedules": [
            {"name": "good", "master": "m", "prompt": "p", "every": "1h"},
            {"name": "bad", "master": "m"},  # missing prompt + every/at
            {"name": "alsobad", "every": "5x"},  # invalid duration
        ],
    }), encoding="utf-8")
    loaded = load_schedules(path=p)
    assert [s.name for s in loaded] == ["good"]


# --- add / remove ---


def test_add_schedule_rejects_duplicate_name(tmp_path: Path) -> None:
    p = tmp_path / "schedules.yaml"
    s = Schedule(name="x", master="m", prompt="p", every="1h")
    add_schedule(s, path=p)
    with pytest.raises(ValueError):
        add_schedule(s, path=p)


def test_add_schedule_sets_next_fire_ts(tmp_path: Path) -> None:
    p = tmp_path / "schedules.yaml"
    s = Schedule(name="x", master="m", prompt="p", every="1h")
    add_schedule(s, path=p)
    loaded = load_schedules(path=p)
    assert loaded[0].next_fire_ts is not None


def test_remove_schedule_by_name(tmp_path: Path) -> None:
    p = tmp_path / "schedules.yaml"
    add_schedule(
        Schedule(name="a", master="m", prompt="p", every="1h"), path=p,
    )
    add_schedule(
        Schedule(name="b", master="m", prompt="p", every="2h"), path=p,
    )
    assert remove_schedule("a", path=p) is True
    loaded = load_schedules(path=p)
    assert [s.name for s in loaded] == ["b"]


def test_remove_unknown_schedule_returns_false(tmp_path: Path) -> None:
    p = tmp_path / "schedules.yaml"
    assert remove_schedule("nope", path=p) is False


# --- due_schedules + mark_fired ---


def test_due_schedules_returns_only_past_next_fire(tmp_path: Path) -> None:
    p = tmp_path / "schedules.yaml"
    now = datetime(2026, 5, 14, 12, 0, tzinfo=timezone.utc)
    past = (now - timedelta(minutes=5)).isoformat()
    future = (now + timedelta(minutes=5)).isoformat()
    save_schedules([
        Schedule(name="past_due", master="m", prompt="p", every="1h",
                 next_fire_ts=past),
        Schedule(name="future", master="m", prompt="p", every="1h",
                 next_fire_ts=future),
    ], path=p)
    due = due_schedules(now=now, path=p)
    assert [s.name for s in due] == ["past_due"]


def test_mark_fired_advances_next_fire_ts(tmp_path: Path) -> None:
    p = tmp_path / "schedules.yaml"
    fire_ts = datetime(2026, 5, 14, 12, 0, tzinfo=timezone.utc)
    add_schedule(
        Schedule(name="x", master="m", prompt="p", every="1h"), path=p,
    )
    mark_fired("x", fire_ts=fire_ts, path=p)
    loaded = load_schedules(path=p)
    assert loaded[0].last_fire_ts == fire_ts.isoformat()
    # next_fire_ts is 1h after fire_ts.
    expected_next = (fire_ts + timedelta(hours=1)).isoformat()
    assert loaded[0].next_fire_ts == expected_next
