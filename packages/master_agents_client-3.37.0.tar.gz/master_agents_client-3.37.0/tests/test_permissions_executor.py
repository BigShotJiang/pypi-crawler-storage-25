"""Tests for E47 — permission engine wired into RemoteToolExecutor.

The pure permission-rule matching is covered by test_permissions.py.
This file covers the integration: deny rules block tool calls
before they execute; allow rules pass through; no permissions config
falls back to legacy writable_paths-only enforcement.
"""
from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from master_agents_client.permissions import PermissionsConfig
from master_agents_client.remote_client import RemoteToolExecutor
from master_agents_client.tools.base import Tool


def _stub_tool(name: str = "bash") -> Tool:
    """A do-nothing Tool that records its last call and returns a
    benign confirmation string. The permission engine fires BEFORE
    the handler runs, so a deny rule should prevent the handler from
    being called at all.
    """
    calls: list[dict] = []

    async def handler(**kwargs):
        calls.append(kwargs)
        return f"{name} ran with {kwargs!r}"

    tool = Tool(
        name=name, description="stub", input_schema={}, handler=handler,
    )
    tool._test_calls = calls  # type: ignore[attr-defined]
    return tool


@pytest.fixture
def cwd(tmp_path: Path) -> Path:
    return tmp_path


async def test_deny_rule_blocks_call_before_handler_runs(cwd: Path) -> None:
    tool = _stub_tool("bash")
    perms = PermissionsConfig(deny=["Bash(rm -rf:*)"])
    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool}, permissions=perms,
    )
    out, is_error = await execu.execute("bash", {"command": "rm -rf /tmp/x"})
    assert is_error is True
    assert "permission denied" in out.lower()
    # Handler was never called — deny short-circuited.
    assert tool._test_calls == []  # type: ignore[attr-defined]


async def test_allow_rule_permits_call_through_handler(cwd: Path) -> None:
    tool = _stub_tool("bash")
    perms = PermissionsConfig(allow=["Bash(git:*)"])
    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool}, permissions=perms,
    )
    out, is_error = await execu.execute("bash", {"command": "git status"})
    assert is_error is False
    assert "ran with" in out
    assert tool._test_calls == [{"command": "git status"}]  # type: ignore[attr-defined]


async def test_no_permissions_falls_back_to_legacy_writable_paths(
    cwd: Path,
) -> None:
    # Without a PermissionsConfig, write_file enforcement is purely
    # writable_paths-based (the legacy behaviour). This test pins
    # that the back-compat path still works.
    tool = _stub_tool("read_file")
    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"read_file": tool},
        permissions=None,
    )
    out, is_error = await execu.execute("read_file", {"path": "anything"})
    assert is_error is False  # no perms engine → no deny


async def test_deny_takes_precedence_over_writable_paths(cwd: Path) -> None:
    # Path is inside writable_paths AND inside an allow rule, but a
    # deny rule on the bash command should still block. Tests the
    # ordering: permissions engine runs BEFORE _check_path.
    tool = _stub_tool("bash")
    perms = PermissionsConfig(
        allow=["Bash"],
        deny=["Bash(rm -rf:*)"],
    )
    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool}, permissions=perms,
    )
    out, is_error = await execu.execute("bash", {"command": "rm -rf /tmp/x"})
    assert is_error is True
    assert "permission denied" in out.lower()


async def test_permission_verdict_reason_includes_rule_string(cwd: Path) -> None:
    # The user reading the trace must see WHICH deny rule fired.
    tool = _stub_tool("bash")
    perms = PermissionsConfig(deny=["Bash(sudo:*)"])
    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool}, permissions=perms,
    )
    out, _ = await execu.execute("bash", {"command": "sudo apt install x"})
    assert "Bash(sudo:*)" in out or "sudo" in out
