"""Fixture 3.2 — CLI help golden.

PURPOSE — Phase 1 fixture 3.2 (per
`docs/policy/DECOMPOSITION_PLAN_ADDENDUM_2026-05-15.md` v2 §3.2).
Capture `mao-client --help` AND every subcommand's `--help`
output to golden text files. Test re-derives via the
`build_parser()` factory and diffs against the goldens.

Why this matters: per VERSIONING.md, removed/renamed CLI
subcommands and flags are MAJOR-bump triggers. During the
`remote_cli.py` refactor (Sprints 7 + 9, ~5,365 LoC file split),
argparse plumbing could accidentally drop a flag or rename a
subcommand. This fixture catches that — any change to the
help-text surface fails the test, forcing an explicit golden
refresh in the same commit as the source change.

Implementation:
- Build the parser in-process via
  `master_agents_client.cli.build_parser()` (line 186).
- Force a deterministic terminal width via env so argparse line
  wrapping is byte-stable across CI environments.
- Walk subparsers via `parser._actions` filtering on
  `argparse._SubParsersAction`; recurse into each subparser
  (some subcommands have their own subcommands — e.g.
  `mao-client remote run`).
- One golden text file per (sub)command, named by the dot-joined
  command path (`main.txt`, `remote.txt`, `remote.run.txt`, ...).

Refresh the goldens after an intentional CLI surface change:
    python -m tests.test_help_golden --refresh

Cleans goldens that no longer have a matching subcommand; writes
new goldens for added subcommands.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path

import pytest

from master_agents_client.cli import build_parser

GOLDEN_DIR = Path(__file__).parent / "fixtures" / "help_golden"

# Force deterministic argparse line wrapping. argparse honours
# the COLUMNS env var via shutil.get_terminal_size(); 80 is the
# argparse default fallback so we pin it explicitly.
_DETERMINISTIC_COLUMNS = "80"


def _walk_parsers(
    parser: argparse.ArgumentParser, path: tuple[str, ...] = ("main",)
) -> list[tuple[tuple[str, ...], argparse.ArgumentParser]]:
    """Depth-first walk of the parser tree.

    Yields (path, parser) tuples where `path` is the dot-joined
    command location (e.g. ("main",), ("main", "remote"),
    ("main", "remote", "run")).
    """
    out: list[tuple[tuple[str, ...], argparse.ArgumentParser]] = [(path, parser)]
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            for name, subparser in sorted(action.choices.items()):
                out.extend(_walk_parsers(subparser, path + (name,)))
    return out


def _golden_filename(path: tuple[str, ...]) -> str:
    """`("main",)` → `"main.txt"`; `("main", "remote", "run")` → `"remote.run.txt"`."""
    if path == ("main",):
        return "main.txt"
    return ".".join(path[1:]) + ".txt"


def _current_help() -> dict[str, str]:
    """Snapshot the help output of every (sub)parser as a dict
    of {filename: format_help() text}.
    """
    # Pin COLUMNS for the duration of help_text collection so
    # argparse's HelpFormatter wraps deterministically.
    old_columns = os.environ.get("COLUMNS")
    os.environ["COLUMNS"] = _DETERMINISTIC_COLUMNS
    try:
        parser = build_parser()
        return {
            _golden_filename(path): subparser.format_help()
            for path, subparser in _walk_parsers(parser)
        }
    finally:
        if old_columns is None:
            os.environ.pop("COLUMNS", None)
        else:
            os.environ["COLUMNS"] = old_columns


def _golden() -> dict[str, str]:
    if not GOLDEN_DIR.exists():
        return {}
    return {
        f.name: f.read_text(encoding="utf-8")
        for f in sorted(GOLDEN_DIR.iterdir())
        if f.is_file() and f.suffix == ".txt"
    }


def test_help_golden_dir_exists() -> None:
    """Sanity check: the goldens directory exists and is non-empty.
    Refresh via `python -m tests.test_help_golden --refresh` if
    you've just added this fixture from scratch.
    """
    assert GOLDEN_DIR.is_dir(), (
        f"Golden directory missing: {GOLDEN_DIR}. "
        f"Run --refresh to generate."
    )
    assert any(GOLDEN_DIR.iterdir()), (
        f"Golden directory empty: {GOLDEN_DIR}. "
        f"Run --refresh to generate."
    )


def test_subcommand_set_matches_golden() -> None:
    """The set of (sub)commands hasn't drifted from the golden."""
    current = set(_current_help().keys())
    golden = set(_golden().keys())
    added = sorted(current - golden)
    removed = sorted(golden - current)
    assert current == golden, (
        f"CLI subcommand set drifted from golden.\n"
        f"  Added:   {added}\n"
        f"  Removed: {removed}\n"
        f"If intentional, re-run with --refresh and commit the "
        f"goldens in the same PR."
    )


@pytest.mark.parametrize(
    "name",
    sorted(_golden().keys()) if (GOLDEN_DIR.exists() and any(GOLDEN_DIR.iterdir())) else [],
)
def test_each_help_text_matches_golden(name: str) -> None:
    """Per-(sub)command help-text byte equality against golden."""
    current = _current_help()
    golden = _golden()
    assert current[name] == golden[name], (
        f"Help text for {name!r} drifted from golden.\n"
        f"Run with --refresh to regenerate; commit the golden "
        f"diff in the same PR as the source change."
    )


def _refresh_golden() -> None:
    """Write the current help output to the goldens dir. Removes
    any golden files no longer present in the current parser walk.
    """
    GOLDEN_DIR.mkdir(parents=True, exist_ok=True)
    current = _current_help()
    # Remove stale goldens.
    for existing in GOLDEN_DIR.iterdir():
        if existing.is_file() and existing.suffix == ".txt" and existing.name not in current:
            existing.unlink()
            print(f"  Removed stale golden: {existing.name}")
    # Write current goldens.
    for name, text in sorted(current.items()):
        (GOLDEN_DIR / name).write_text(text, encoding="utf-8")
    print(f"Refreshed {len(current)} golden(s) at {GOLDEN_DIR}")


if __name__ == "__main__":
    import sys
    if "--refresh" in sys.argv:
        _refresh_golden()
    else:
        pytest.main([__file__, "-q"])
