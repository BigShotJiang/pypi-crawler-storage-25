"""Client-side tool executor for  remote-client mode .

A `RemoteToolExecutor` lives on the local workstation. When the home server
delegates a filesystem-touching tool via `event: needs_local_tool`, the client
deserializes `{tool_name, input}` and calls `executor.execute(...)`. Path
arguments are resolved against the client's `cwd` and checked against the
client's `writable_paths` allowlist BEFORE any filesystem operation runs.

This module is deliberately transport-agnostic — the transport layer
(`agents remote chat`, etc.) handles SSE reading + POST `/local_tool_result`;
this module only implements execute+enforce.

Security model : the client's `writable_paths` is authoritative.
Server-side `AgentSpec.writable_paths` is advisory (prompt-side hint only).
"""

from __future__ import annotations

import os
import sys
from collections.abc import Iterable
from pathlib import Path
from typing import Any

from .tools.base import Tool


DEFAULT_CLIENT_SIDE_TOOLS: frozenset[str] = frozenset({
    # ── Filesystem read/write (already client-routable since ) ──
    "write_file", "edit_file", "append_file", "read_file", "file_grep",
    "list_files",
    # ── Document readers ──
    "pdf_read", "docx_read", "csv_read", "json_path",
    # ── Document writers (write to user's disk) ──
    "create_docx", "create_pptx", "create_xlsx", "create_pdf",
    "render_chart",
    # markdown + MD-to-PPTX writers were previously server-only,
    # an asymmetry with the other create_* tools. Promoting both for
    # consistency — they accept a `path` and write a single artifact,
    # same shape as create_docx.
    "create_md", "create_pptx_from_md",
    # ── Exec ──
    # bash exec on the user's machine (CLI channel only).
    "bash",
    # E37 (2026-05-13) — PowerShell sibling to bash for Windows-native
    # cmdlets / COM / WMI / registry / .NET interop. CLI channel only;
    # Windows-only at the handler level (errors clean on Linux/macOS).
    "powershell",
    # OS-agnostic Python invocation (no shell, no WSL needed).
    "python_run",
    # python_eval and the sandboxed variant — run against the
    # user's Python env where their data lives. Sandboxed remains
    # useful when the caller wants isolation; both are now client-
    # routable so analysis tools see the user's libs/data instead of
    # the container's.
    "python_eval", "python_eval_sandboxed",
    # ── Structured edits ──
    # atomic structured edits (CLI channel only).
    "multi_edit", "apply_patch",
    # ── Cost estimation ──
    # estimate_tokens — pre-flight cost estimator. Routed to the
    # client when present so it can measure local files; runs
    # server-side in web mode for files in the mounted corpus.
    "estimate_tokens",
    # ── Git on the user's repo ──
    # pre- git_read/git_write ran against the SERVER's cwd,
    # which meant agents couldn't `git checkout -b feat/...` on the
    # user's repo. Routing both to the client uses the user's git
    # binary in their working directory; subprocess sandboxing
    # (no GIT_* env passthrough) and  main-branch guard still
    # apply because they're enforced inside `run_git`, which the
    # plain handler in BUILTINS calls.
    "git_read", "git_write",
    # ── Network from the user's network namespace ──
    # http_get and browser_fetch run client-side so they see
    # localhost / VPN / corp-network URLs the server can't reach.
    # Server-side fallback when the client doesn't offer them
    # remains intact (server's BUILTINS implementation is unchanged).
    "http_get", "browser_fetch",
    # ── Vision / scoring / calc ──
    # vision_describe reads images from the user's disk and
    # calls a vision LLM; promoting to client lets it operate on
    # local screenshots/charts. score_output and calc have no
    # filesystem dependency — promoted for symmetry, no behaviour
    # difference, but lets agents stay on one side of the bridge
    # for an entire reasoning chain instead of round-tripping.
    "vision_describe", "score_output", "calc",
    # ── Layer-2 memory recall (K-F.1, 2026-05-14) ──
    # The atom corpus is user-curated markdown under
    # ~/.claude/projects/<hash>/memory/ — lives on the client, not
    # the container. The server-side BUILTIN reads
    # MASTER_AGENTS_ATOM_CORPUS_DIR (typically unset on the server,
    # so the tool returns an actionable "not configured" error if
    # routing fails). Client bridge runs the same handler against
    # the user's actual corpus.
    "recall_atom",
    # ── Unified knowledge search (K-F.4, 2026-05-15) ──
    # Layer-2 retrieval across THREE corpora: atoms (client-only,
    # same as recall_atom), INCIDENTS.md + PATTERNS.md (MAO source
    # repo docs). Client-side routing keeps the atom corpus reach-
    # able and the user's editable repo checkout discoverable. For
    # wheel-only installs the user sets
    # MASTER_AGENTS_KNOWLEDGE_DIR; the tool degrades gracefully on
    # any unconfigured corpus and reports the skip in the footer.
    "knowledge_search",
    # ── Notification primitives ──
    # slack_post fires from $MASTER_AGENTS_SLACK_WEBHOOK_URL (operator
    # secret on the user's machine). webhook_post fires at a caller-
    # supplied URL. Both run client-side because:
    # (1) webhook URLs may be internal/VPN/corp-net targets the user
    #     reaches but the container does not;
    # (2) the operator's webhook secrets live in their shell profile,
    #     not in the server container's env;
    # (3) routines (v3.10.0) execute via local cron on the user's
    #     machine anyway — same trust boundary.
    "slack_post",
    "webhook_post",
})
"""Default tool names routed to the client in remote mode.

History:  (initial set) →  A2 (+append_file)
→  (promotion of git/http/vision/score/calc/python_eval/create_md/
create_pptx_from_md/browser_fetch — see commit message).

Tools NOT in this set are either:
  - in `SERVER_ONLY_TOOLS` because they wrap a server-side resource
    (DB, API key, session-scope store) — by-design server-bound, and
    asserted disjoint below; OR
  - tools whose channels excludes "cli" — declared per-tool via
    `Tool.channels`."""


# tools that MUST stay server-side regardless of what a client
# declares. Each is bound to a server-side resource; routing them to
# the client would silently break (DB unreachable, no API key, lost
# state, etc.). Centralized here so the audit lives in one place.
SERVER_ONLY_TOOLS: frozenset[str] = frozenset({
    # Special UI channel (handled outside the bridge).
    "ask_user",
    # Provider API key on the server, not the user's machine.
    "web_search",
    # Server-side Postgres / KV / corpus stores — single source of
    # truth across sessions and clients.
    "memory_get", "memory_set", "memory_list", "memory_delete",
    "scratchpad_append", "scratchpad_read",
    "sql_query",
    "corpus_search",
    # Server-side notebook handle (uploaded via web channel; agent
    # reads via session-bound NotebookStore).
    "notebook_list", "notebook_read", "notebook_search",
    # Office add-in protocol (own channel; uses different bridge).
    "excel_propose_ops", "pptx_propose_ops",
})


# Tools in DEFAULT_CLIENT_SIDE_TOOLS that WRITE to the filesystem — these
# always require a `path` field that passes writable_paths enforcement.
# Note: git_write writes via subprocess in the executor's cwd (no `path`
# arg), apply_patch ships a multi-file diff to git apply — both bypass
# this single-path enforcement and fall back to writable_paths ∩ cwd.
_WRITING_TOOLS: frozenset[str] = frozenset({
    "write_file", "edit_file", "append_file",
    "create_docx", "create_pptx", "create_xlsx", "create_pdf",
    "create_md", "create_pptx_from_md",
    "render_chart",
    # multi_edit takes `path`.
    "multi_edit",
})

# Invariants. Both must hold or the routing layer is incoherent:
#   - every write tool in the client set has path enforcement reach;
#   - the client and server-only sets cannot overlap (would mean a
#     tool is simultaneously routable and forbidden).
assert _WRITING_TOOLS <= DEFAULT_CLIENT_SIDE_TOOLS, (
    "_WRITING_TOOLS must be a subset of DEFAULT_CLIENT_SIDE_TOOLS"
)
assert DEFAULT_CLIENT_SIDE_TOOLS.isdisjoint(SERVER_ONLY_TOOLS), (
    f"DEFAULT_CLIENT_SIDE_TOOLS and SERVER_ONLY_TOOLS must be "
    f"disjoint; overlap: "
    f"{sorted(DEFAULT_CLIENT_SIDE_TOOLS & SERVER_ONLY_TOOLS)}"
)


def _normalize(p: Path) -> str:
    # resolve() handles symlinks on POSIX and most Windows junctions; normcase
    # handles Windows case-insensitive comparison. On POSIX normcase is a
    # no-op, so this works uniformly.
    return os.path.normcase(str(p.resolve()))


def _is_within_any_root(target: Path, roots: list[Path]) -> bool:
    tnorm = _normalize(target)
    for root in roots:
        rnorm = _normalize(root)
        if tnorm == rnorm:
            return True
        if tnorm.startswith(rnorm + os.sep):
            return True
    return False


def _render_unified_diff(
    *, file_path: str, old_text: str, new_text: str, color: bool, stream
) -> None:
    """Print a unified diff with optional ANSI colors to `stream`.

    Used by RemoteToolExecutor to surface what write_file / edit_file /
    multi_edit actually changed, so the user reviewing live agent activity
    sees red/green hunks the same way they would in a code editor.
    Silent when old == new (idempotent edit, common after the agent
    mistypes the same content twice in a row)."""
    import difflib

    if old_text == new_text:
        return
    diff_lines = list(difflib.unified_diff(
        old_text.splitlines(keepends=True),
        new_text.splitlines(keepends=True),
        fromfile=f"{file_path} (before)",
        tofile=f"{file_path} (after)",
        n=3,
    ))
    if not diff_lines:
        return
    if color:
        # Reset every line so a missing trailing newline can't bleed the
        # color across into ConsoleTracer's next event line.
        for line in diff_lines:
            if line.startswith("+++") or line.startswith("---"):
                stream.write(f"\x1b[1m{line}\x1b[0m" if line.endswith("\n")
                             else f"\x1b[1m{line}\x1b[0m\n")
            elif line.startswith("@@"):
                stream.write(f"\x1b[36m{line}\x1b[0m" if line.endswith("\n")
                             else f"\x1b[36m{line}\x1b[0m\n")
            elif line.startswith("+"):
                stream.write(f"\x1b[32m{line}\x1b[0m" if line.endswith("\n")
                             else f"\x1b[32m{line}\x1b[0m\n")
            elif line.startswith("-"):
                stream.write(f"\x1b[31m{line}\x1b[0m" if line.endswith("\n")
                             else f"\x1b[31m{line}\x1b[0m\n")
            else:
                stream.write(line if line.endswith("\n") else line + "\n")
    else:
        for line in diff_lines:
            stream.write(line if line.endswith("\n") else line + "\n")
    stream.flush()


class RemoteToolExecutor:
    """Executes a bounded set of tools under client-side path enforcement."""

    def __init__(
        self,
        *,
        cwd: Path | str,
        writable_paths: Iterable[str],
        tools: dict[str, Tool],
        show_diffs: bool = False,
        diff_color: bool = True,
        permissions: Any = None,
    ) -> None:
        self.cwd = Path(cwd).resolve()
        self._writable_paths_raw = list(writable_paths)
        self._writable_roots: list[Path] = []
        for raw in self._writable_paths_raw:
            p = Path(raw).expanduser()
            if not p.is_absolute():
                p = self.cwd / p
            # Note: we do NOT require allowlist roots to exist — they may be
            # created by tools at execution time. resolve(strict=False) is the
            # default for Path.resolve() on Python 3.6+.
            self._writable_roots.append(p.resolve())
        self.tools = dict(tools)
        # When True, write_file / edit_file / multi_edit print a colored
        # unified diff to stderr after the tool runs. Default False so
        # tests stay quiet; agents remote chat opts in.
        self._show_diffs = show_diffs
        self._diff_color = diff_color
        # E47 (2026-05-14) — permission rule engine. None means
        # legacy/no-permissions mode (back-compat with pre-E47 sessions
        # where the only gate was writable_paths). When provided, this
        # PermissionsConfig fires BEFORE the writable_paths check so
        # deny rules win over the legacy allowlist.
        self._permissions = permissions

    async def execute(
        self, tool_name: str, input_args: dict[str, Any]
    ) -> tuple[str, bool]:
        tool = self.tools.get(tool_name)
        if tool is None:
            return (
                f"error: tool {tool_name!r} is not available on the remote client "
                f"(not in default client-side tool set)",
                True,
            )

        # E47 (2026-05-14): permission rule check BEFORE legacy
        # writable_paths. Deny rules block destructive globs
        # (e.g. ``Bash(rm -rf:*)``) regardless of whether the path
        # is in writable_paths.
        if self._permissions is not None:
            verdict = self._permissions.check(tool_name, input_args)
            if verdict.action == "deny":
                return (
                    f"error: permission denied — {verdict.reason}",
                    True,
                )

        if tool_name in _WRITING_TOOLS:
            raw_path = input_args.get("path")
            if not raw_path:
                return (
                    f"error: tool {tool_name!r} requires an explicit 'path' "
                    "field in remote client mode",
                    True,
                )
            check = self._check_path(raw_path)
            if check is not None:
                return (check, True)

        # Optional: read-side tools also resolve relative paths against cwd,
        # though the server may have sent an absolute path already.
        resolved_input = self._resolve_input_paths(tool_name, input_args)

        # Capture pre-state for write_file so we can render a diff after.
        # edit_file / multi_edit have old_string in the input itself, so
        # they don't need a pre-read; we render their diffs from input alone.
        pre_text: str | None = None
        if self._show_diffs and tool_name == "write_file":
            target = resolved_input.get("path")
            if isinstance(target, str) and target:
                try:
                    pre_text = Path(target).read_text(encoding="utf-8")
                except (OSError, UnicodeDecodeError):
                    pre_text = ""  # new file or binary — diff against empty

        try:
            out = await tool.execute(resolved_input)
        except Exception as exc:
            return (f"error: {type(exc).__name__}: {exc}", True)

        if self._show_diffs:
            self._render_diff_after(tool_name, resolved_input, pre_text)
        return (out, False)

    def _render_diff_after(
        self,
        tool_name: str,
        resolved_input: dict[str, Any],
        pre_text: str | None,
    ) -> None:
        path = resolved_input.get("path")
        if not isinstance(path, str):
            return
        if tool_name == "write_file":
            new_text = resolved_input.get("content", "")
            if not isinstance(new_text, str):
                return
            _render_unified_diff(
                file_path=path,
                old_text=pre_text or "",
                new_text=new_text,
                color=self._diff_color,
                stream=sys.stderr,
            )
        elif tool_name == "edit_file":
            old_string = resolved_input.get("old_string", "")
            new_string = resolved_input.get("new_string", "")
            if isinstance(old_string, str) and isinstance(new_string, str):
                _render_unified_diff(
                    file_path=path,
                    old_text=old_string,
                    new_text=new_string,
                    color=self._diff_color,
                    stream=sys.stderr,
                )
        elif tool_name == "multi_edit":
            edits = resolved_input.get("edits", [])
            if not isinstance(edits, list):
                return
            for i, edit in enumerate(edits, 1):
                if not isinstance(edit, dict):
                    continue
                old_string = edit.get("old_string", "")
                new_string = edit.get("new_string", "")
                if isinstance(old_string, str) and isinstance(new_string, str):
                    _render_unified_diff(
                        file_path=f"{path} (edit {i})",
                        old_text=old_string,
                        new_text=new_string,
                        color=self._diff_color,
                        stream=sys.stderr,
                    )

    def _check_path(self, raw: str) -> str | None:
        p = Path(raw).expanduser()
        if not p.is_absolute():
            p = self.cwd / p
        target = p.resolve()
        if not self._writable_roots:
            return (
                f"Refusing to write: no writable_paths configured on client. "
                f"Target: {raw}"
            )
        if not _is_within_any_root(target, self._writable_roots):
            roots_text = ", ".join(str(r) for r in self._writable_roots)
            return (
                f"Path {raw!r} resolves to {target} — outside client "
                f"writable_paths. Allowed roots: {roots_text}"
            )
        return None

    def _resolve_input_paths(
        self, tool_name: str, input_args: dict[str, Any]
    ) -> dict[str, Any]:
        out = dict(input_args)
        raw_path = out.get("path")
        if isinstance(raw_path, str) and raw_path:
            p = Path(raw_path).expanduser()
            if not p.is_absolute():
                p = self.cwd / p
            out["path"] = str(p)
        return out
