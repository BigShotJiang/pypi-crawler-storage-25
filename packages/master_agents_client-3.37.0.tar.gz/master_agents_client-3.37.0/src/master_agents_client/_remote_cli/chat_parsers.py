"""Pure parsing helpers + the slash-command help text for the
`mao-client remote chat` REPL.

Phase 1 backlog item #5 (2026-05-16, v3.32.0): extracted from
`chat.py` to break a 2603-LoC file into focused sub-modules.

Three names live here, all pure (no I/O, no side effects):
  - `_REMOTE_CHAT_HELP` — multi-line help string emitted by `/help`.
    Worth its own sub-module because future commands land here and
    keeping it next to the REPL bloats `chat.py` for no benefit.
  - `_parse_cap_arg(arg)` — parse `--cap` CLI flag values into
    `(int, is_relative)` tuples / "reset" literal / None.
  - `_parse_budget_arg(arg)` — parse `--threshold-ask-user` and
    related budget flag values into positive int / "reset" / None.

The two regex constants (`_BUDGET_RE`, `_CAP_RE`) live here too —
they're parser-private; nothing else imports them.

Re-exported from `chat.py` for back-compat (Sprint 9f-era callers
still import these names from `master_agents_client._remote_cli.chat`).
"""

from __future__ import annotations

import re


_REMOTE_CHAT_HELP = (
    "Commands:\n"
    "  /exit, /quit          Leave the chat AND destroy the server "
    "session (history is gone).\n"
    "  /detach               Leave the chat but KEEP the session alive. "
    "Next run offers to resume.\n"
    "  /cancel, /stop        Cancel the currently-running turn (works "
    "while the agent is busy).\n"
    "  /help                 Show this message.\n"
    "  /capabilities         Show the current agent's tools + "
    "delegation map (no LLM cost).\n"
    "  /model [standard|pro] Switch the agent's reasoning tier for "
    "this session. No arg = list available.\n"
    "  /threshold-ask-user [N | reset]   Per-turn cost-gate budget. "
    "tier_1 ≤budget (silent); tier_2 (budget..2×) requires ask_user; "
    "tier_3 (>2×) auto-rejected. Default 100K. Alias: /budget.\n"
    "  /threshold-auto-compact [N | reset]  Auto-compact trigger. "
    "Folds older turns into a summary when master's history exceeds N. "
    "Mandatory 80%-of-context-window floor still applies as safety net.\n"
    "  /threshold-turn-input [N | reset]  Per-turn input-token ceiling. "
    "Default UNLIMITED — set N to halt the runner mid-turn when input "
    "tokens within a single turn exceed N (forces the agent to "
    "consolidate). Persists for every remaining turn of this session.\n"
    "  /max-output-tokens [N | reset]  Per-LLM-call output cap. "
    "Override the agent spec's max_output_tokens. Set N to bump for "
    "big verdicts / blueprints; reset to revert. \n"
    "  /tasks <list | resume <id> | kill <id>>  Background-task surface. "
    "`list` shows recent persisted sessions; `resume <id>` prints the "
    "command to re-attach; `kill <id>` terminates a session by id "
    "(useful for cleaning up stale detached sessions). (E42, 2026-05-14)\n"
    "  /threshold-max-steps [N | reset]  Per-turn max_steps loop bound. "
    "Default = spec.max_steps (varies per agent). Override raises (or "
    "lowers) how many LLM round-trips a single turn can fire before "
    "soft-landing. Persists for every remaining turn of this session.\n"
    "  /threshold-total-steps [N | reset]  Session-cumulative step "
    "counter (all turns + all spawned subagents). Default 100. "
    "Override raises the ceiling for long autonomous runs — pre- "
    "the only recovery from a hit was starting a new session.\n"
    "  /cap [N | +N | reset] Session-wide spend cap (cumulative input"
    "+output tokens). Halts execution when crossed; /clear and /compact "
    "preserve the cumulative counter. `+N` adds N to current usage.\n"
    "  /allow-main-commits [on | off]  Override feat-branch-only "
    "commit guard . Default off (guard active — commits to "
    "main/master refused). Use only for emergency hotfixes.\n"
    "  /remember <text>      v3.1.0 — save a fact to user-scope memory. "
    "Auto-loads into every agent's <memory> block from the NEXT session "
    "start. Use `key=text` form to set an explicit key.\n"
    "  /memory               v3.3.0 — audit + curate saved memory: "
    "`/memory` lists user-scope keys + datetimes; `/memory list agent` "
    "for this agent's scope; `/memory get <key>` / `/memory delete <key>` "
    "for single-key ops. Type `/memory help` for full subcommand list.\n"
    "  /clear, /reset        Clear conversation history (start fresh, "
    "same session).\n"
    "  /compact              Fold older messages into a summary to "
    "reclaim context budget.\n"
    "  /draft                Recall the most recent Esc-saved draft "
    "into the next prompt.  — Esc with typed text saves the "
    "buffer instead of silently dropping it.\n"
    "  /agent <name|N>       Switch the active master agent "
    "mid-session . Conversation history carries forward; a "
    "synthetic handoff message is inserted so the new agent treats "
    "prior context as background. Validates target is in the "
    "registry, drivable, and admits this session's channel. Accepts "
    "either the long name (e.g. `/agent code_reviewer`) or the "
    "[N] number from the /agents listing (e.g. `/agent 3`) as a "
    "typing shortcut .\n"
    "  /agents               List available master agents on "
    "this server (filtered by this session's channel) with [N] "
    "shortcuts. Use the names or numbers with /agent.\n"
    "\n"
    "Background work:\n"
    "  Type ANY input while the agent is busy — it queues automatically.\n"
    "  Queued messages dispatch in order after the current turn finishes.\n"
    "\n"
    "Input keys:\n"
    "  Enter                 Submit the prompt.\n"
    "  Esc                   Cancel the currently-running turn "
    "(quick interrupt — same as /cancel).\n"
    "  Ctrl+J                Insert a newline (universal — works on "
    "any terminal).\n"
    "  \\ + Enter             Backslash continuation — drops the "
    "trailing \\ and inserts a newline (universal, no protocol).\n"
    "  (Shift+Enter)  Not enabled by default —  disabled "
    "the kitty keyboard protocol enable that made it work natively, "
    "because unmapped functional keys leaked as phantom Esc presses.\n"
    "  Paste                 Multi-line paste lands as a single prompt "
    "(bracketed paste).\n"
    "  ↑ / ↓                 Recall earlier prompts in this session.\n"
    "  /                     Show slash-command popup."
)


_BUDGET_RE = re.compile(r"^\s*([\d_.]+)\s*([kKmM]?)\s*$")


_CAP_RE = re.compile(r"^\s*(\+)?\s*([\d_.]+)\s*([kKmM]?)\s*$")


def _parse_cap_arg(arg: str) -> tuple[int, bool] | str | None:
    """Parse the user-typed argument to /cap.

    Accepts:
      - absolute integer / k / M:        "1M", "500k", "2_000_000"
      - relative-add :              "+500k", "+200000"
      - reset / default:                 "reset", "default"

    Returns:
      - (int, False) for absolute set
      - (int, True)  for relative-add (caller adds to current usage)
      - "reset"     literal
      - None        for malformed / non-positive
    """
    if not isinstance(arg, str):
        return None
    a = arg.strip().lower()
    if not a:
        return None
    if a in ("reset", "default", "off", "none"):
        return "reset"
    m = _CAP_RE.match(a)
    if not m:
        return None
    is_relative = m.group(1) == "+"
    raw = m.group(2).replace("_", "")
    try:
        val = float(raw)
    except ValueError:
        return None
    suffix = m.group(3).lower()
    if suffix == "k":
        val *= 1000
    elif suffix == "m":
        val *= 1_000_000
    n = int(val)
    if n <= 0:
        return None
    return (n, is_relative)


def _parse_budget_arg(arg: str) -> int | str | None:
    """Parse the user-typed argument to /budget.

    Accepts:
      - bare integer or `_`-separated:  "50000", "50_000"
      - k/K suffix (×1000):              "50k", "50K", "1.5k"
      - M/m suffix (×1_000_000):         "2M", "0.5M"
      - reset / default:                 "reset", "default", "RESET"

    Returns:
      - positive int for a numeric form
      - the literal string "reset" for reset/default
      - None for malformed / non-positive input

    The chat REPL uses the result to either POST a new budget or
    POST None (reset). None from this parser surfaces a usage hint
    to the user instead of calling the server.
    """
    if not isinstance(arg, str):
        return None
    a = arg.strip().lower()
    if not a:
        return None
    if a in ("reset", "default"):
        return "reset"
    m = _BUDGET_RE.match(a)
    if not m:
        return None
    raw = m.group(1).replace("_", "")
    try:
        val = float(raw)
    except ValueError:
        return None
    suffix = m.group(2).lower()
    if suffix == "k":
        val *= 1000
    elif suffix == "m":
        val *= 1_000_000
    n = int(val)
    if n <= 0:
        return None
    return n
