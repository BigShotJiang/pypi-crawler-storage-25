"""Prompt-reader / draft-buffer / kitty-keyboard helpers for the
remote-CLI REPL — extracted from `remote_cli.py` as the fourth
sub-module of the Phase 1 decomposition (per the addendum §3
Sprint 7 module list).

Eight private helpers plus 5 module-level slots / constants live
here:

  Draft buffer :
    - `_draft_slot`               module-level dict slot
    - `_pending_default_slot`     module-level dict slot
    - `_save_draft`               save text to draft slot
    - `_recall_draft`             pop draft (single-use)
    - `_has_draft`                check without consuming
    - `_set_pending_prompt_default` set pending default
    - `_take_pending_prompt_default` pop pending default

  Kitty keyboard protocol :
    - `_KITTY_ENABLE`             CSI sequence string
    - `_KITTY_DISABLE`            CSI sequence string
    - `_kitty_pushed`             idempotency flag
    - `_defensive_kitty_disable`  safe pop on session start
    - `_enable_kitty_keyboard_protocol` push + atexit + SIGTERM

  Prompt-toolkit reader:
    - `_make_prompt_reader`       async prompt builder with CSI-u
                                   kitty mappings, key bindings,
                                   slash-command completer, history

Re-exported from `master_agents_client.remote_cli` via the facade pattern.
All names are private (underscore prefix) and NOT pinned by the
public-API-surface fixture.

Pure prompt / draft / kitty I/O — no orchestration, no HTTP, no
config. Module's surface is invariant to the rest of the
`remote_cli.py` decomposition.

Extraction history: Sprint 7 sub-module 4 (informal: Sprint 1d),
2026-05-16, branched off `v3.17.0` main tip. Function bodies +
state below are VERBATIM from the pre-extraction `remote_cli.py`
(lines 2304-2305 + 2308-2344 + 2439-2774 + 2777-2779 + 2782-2864)
via E83 verbatim passthrough at `apply_edit_step`. Deferred imports
(`string`, `atexit`, `signal`) remain inside the functions where
they were originally — zero behaviour change.
"""

from __future__ import annotations

import asyncio
import sys
from typing import Any

from .._paths import master_agents_home


# preserve typed buffer on Esc (closes A22).
#
# Pre-: hitting Esc with text in the prompt buffer silently
# wiped the buffer (the eager Esc binding submitted "/cancel" and
# prompt_toolkit cleared the buffer on exit). Real-impact failure
# mode for users typing /threshold... commands and bumping Esc
# mid-type — every keystroke gone.
#
#  saves the buffer to a module-level draft slot when Esc fires
# with non-empty text, and adds a /draft slash command that recalls
# the most-recent draft into the next prompt. The Esc cancel
# behaviour itself is preserved (still submits /cancel), so the
# kill-the-running-turn affordance is unchanged.
#
# Two slots:
#   _draft_slot        — text saved by Esc, consumed by /draft.
#   _pending_default_slot — text /draft loaded for the next prompt
#                            session.prompt_async(default=...) call.
_draft_slot: dict[str, str | None] = {"text": None}
_pending_default_slot: dict[str, str | None] = {"text": None}


def _save_draft(text: str) -> None:
    """Save `text` to the draft slot if non-empty.  — called by
    the Esc binding before exiting the prompt with /cancel, so the
    user's typed-but-not-submitted buffer survives the cancel."""
    if text:
        _draft_slot["text"] = text


def _recall_draft() -> str | None:
    """Pop the saved draft (or None if no draft saved). Single-use:
    a second call returns None unless another save happened in
    between."""
    text = _draft_slot.get("text")
    _draft_slot["text"] = None
    return text


def _has_draft() -> bool:
    """Check whether a draft is currently saved without consuming
    it. Used by the /cancel handler's notice line."""
    return _draft_slot.get("text") is not None


def _set_pending_prompt_default(text: str) -> None:
    """Set the default text the NEXT prompt read should be
    pre-populated with. Used by /draft to recall a saved draft into
    the next prompt session.prompt_async() call."""
    _pending_default_slot["text"] = text


def _take_pending_prompt_default() -> str:
    """Pop the pending prompt default. Returns "" when nothing
    pending. Single-use: subsequent calls return "" until another
    set call runs."""
    text = _pending_default_slot.get("text") or ""
    _pending_default_slot["text"] = None
    return text


def _make_prompt_reader():
    """Build an async callable that reads one user input line.

    Returns a coroutine function so the caller awaits it from inside the
    asyncio.run-driven chat loop. We can't use prompt_toolkit's sync
    `prompt()` here because it internally spawns its own asyncio.run(),
    which raises "asyncio.run() cannot be called from a running event
    loop" when nested. `prompt_async()` cooperates with the existing
    loop instead.

    Tries prompt_toolkit first (bracketed-paste so multi-line pastes
    don't truncate at the first newline, plus arrow-key history). Falls
    back to running plain input() in a worker thread when prompt_toolkit
    isn't available or can't attach to the terminal.

    When the fallback fires, writes a one-line diagnostic to stderr so
    the user knows WHY rich features are absent — silent fallback was
    making "blue input doesn't work, Shift+Enter doesn't work" look like
    code bugs when they were really an environment issue.
    """
    def _fallback_reader(reason: str):
        sys.stderr.write(f"(rich input disabled: {reason})\n")
        sys.stderr.flush()

        async def _read(prompt: str) -> str:
            return await asyncio.to_thread(input, prompt)

        return _read

    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.completion import Completer, Completion
        from prompt_toolkit.history import FileHistory, InMemoryHistory
        from prompt_toolkit.input.ansi_escape_sequences import ANSI_SEQUENCES
        from prompt_toolkit.key_binding import KeyBindings
        from prompt_toolkit.keys import Keys
        from prompt_toolkit.styles import Style
    except ImportError as exc:
        return _fallback_reader(
            f"prompt_toolkit not installed — {exc}. "
            "Install with `pip install prompt_toolkit` for blue prompt "
            "+ multi-line paste + Shift+Enter."
        )

    # Teach prompt_toolkit's vt100 parser the kitty-keyboard CSI-u
    # encodings used when the terminal is in "disambiguate escape
    # codes" mode (which we enable below via `\x1b[>1u`). Without
    # these mappings, the parser hits the leading `\x1b` and falls
    # through, so each disambiguated key leaks its literal CSI bytes
    # into the user's input — pressing Esc would paste "[27u",
    # pressing Ctrl+C would paste "[99;5u", etc.
    #
    # prompt_toolkit ships only 4 CSI-u entries (just enough for
    # Ctrl+`5` and friends). We round out the table for every key
    # that kitty level 1 disambiguates and that we (or prompt_toolkit
    # itself) bind: plain Esc/Tab/Backspace/Enter, Shift+Tab,
    # modifier+Esc, all Ctrl+letter, plus the modifier+Enter chords
    # we use for newline insertion.
    #
    # ANSI_SEQUENCES is a plain dict; setdefault keeps any future
    # prompt_toolkit-shipped mappings authoritative.
    _CSI_U_MAPPINGS: dict[str, "Keys"] = {
        # --- Modifier+Enter → newline (the original feature) ---
        "\x1b[13;2u": Keys.ControlJ,   # Shift+Enter
        "\x1b[13;3u": Keys.ControlJ,   # Alt+Enter
        "\x1b[13;5u": Keys.ControlJ,   # Ctrl+Enter
        "\x1b[13;6u": Keys.ControlJ,   # Ctrl+Shift+Enter
        # --- Legacy Alt+Enter (Esc+CR/LF) on terminals without
        # kitty protocol — preserves the chord on the broad set of
        # terminals where eager Esc would otherwise eat the prefix.
        "\x1b\r": Keys.ControlJ,
        "\x1b\n": Keys.ControlJ,
        # --- Plain unmodified disambiguated keys ---
        "\x1b[27u": Keys.Escape,       # Plain Esc — the bug fix
        "\x1b[9u": Keys.Tab,           # Plain Tab (some terminals)
        "\x1b[127u": Keys.Backspace,   # Plain Backspace
        "\x1b[13u": Keys.ControlM,     # Plain Enter (rarely disambiguated;
                                       # ControlM == Enter for binding purposes)
        # --- Shift+Tab ---
        "\x1b[9;2u": Keys.BackTab,
        # --- Modifier+Esc → treat all as plain Esc; nobody binds
        # these specifically and we want /cancel to fire regardless.
        "\x1b[27;2u": Keys.Escape,     # Shift+Esc
        "\x1b[27;3u": Keys.Escape,     # Alt+Esc
        "\x1b[27;5u": Keys.Escape,     # Ctrl+Esc
        "\x1b[27;6u": Keys.Escape,     # Ctrl+Shift+Esc
    }
    # Ctrl+letter (a-z) → corresponding Keys.Control[A-Z]. Critical
    # entries: Ctrl+C (raises KeyboardInterrupt → exits prompt),
    # Ctrl+D (EOF), Ctrl+J (newline — same handler as Shift+Enter).
    # Without these, kitty mode breaks every single Ctrl+letter
    # shortcut that prompt_toolkit relies on.
    import string
    for _letter in string.ascii_lowercase:
        _keycode = ord(_letter)  # 97-122
        _ctrl_key = getattr(Keys, f"Control{_letter.upper()}")
        _CSI_U_MAPPINGS[f"\x1b[{_keycode};5u"] = _ctrl_key

    for _seq, _key in _CSI_U_MAPPINGS.items():
        ANSI_SEQUENCES.setdefault(_seq, _key)

    try:
        kb = KeyBindings()

        @kb.add("enter")
        def _accept(event):
            """Plain Enter submits the buffer (Slack/Discord convention).

            Backslash continuation: if the buffer ends with `\\` and
            the cursor is at the end, strip the trailing backslash
            and insert a newline instead of submitting. Mirrors the
            bash / Python REPL / Claude Code pattern — universal
            multi-line entry chord that needs no terminal protocol
            and works in every shell. Complements Ctrl+J and the
            kitty-protocol Shift+Enter mapped above.

            E46.1 (2026-05-13): MUST call `buf.append_to_history()`
            before `app.exit(result=text)` — bypassing
            prompt_toolkit's standard `validate_and_handle()` flow
            (which is what we do by calling exit directly) ALSO
            bypasses the auto-history-append step. Without this
            line, every submitted prompt is dropped on the floor
            instead of landing in FileHistory → Up arrow has
            nothing to recall, no matter how many prompts the user
            sent. User-reported regression caught 2026-05-13."""
            buf = event.current_buffer
            text = buf.text
            if text.endswith("\\") and buf.cursor_position == len(text):
                buf.delete_before_cursor(1)
                buf.insert_text("\n")
                return
            if text.strip():
                # Only persist non-empty submissions — bare Enter
                # would otherwise litter the FileHistory file with
                # empty lines that pollute Up-arrow recall.
                buf.append_to_history()
            event.app.exit(result=text)

        @kb.add("c-j")
        def _ctrl_j_newline(event):
            """Ctrl+J inserts a newline mid-prompt. Universal: every
            terminal sends Ctrl+J distinctly from Enter so this works
            on Windows Terminal, iTerm2, VS Code's integrated
            terminal, cmd.exe, etc.

            Shift+Enter, Alt+Enter, and Ctrl+Enter all funnel here too
            via the ANSI_SEQUENCES extension above (kitty keyboard
            protocol on capable terminals; bare Esc+CR fallback for
            Alt+Enter on the rest)."""
            event.current_buffer.insert_text("\n")

        # E46 (2026-05-13, refined 2026-05-13) — bash/readline-style
        # history recall in multiline mode. multiline=True (used so
        # Shift+Enter / Ctrl+J insert newlines) rebinds Up/Down to
        # cursor-up/cursor-down by default. That kills the standard
        # shell ergonomic of "Up arrow = last message."
        #
        # v1 (manual cursor_position_row check) didn't fire reliably —
        # the user reported Up still doesn't recall in interactive use.
        # v2 uses prompt_toolkit's `auto_up` / `auto_down` primitives
        # which encapsulate the routing logic robustly (handles wrapped
        # lines, completion menu state, history-search mode etc.) AND
        # also bind `c-p` / `c-n` (Ctrl+P / Ctrl+N) as guaranteed-not-
        # cursor-movement history alternatives — these are universal
        # readline shortcuts and have no multiline-cursor conflict.
        @kb.add("up")
        def _history_up(event):
            event.current_buffer.auto_up(
                count=event.arg,
                go_to_start_of_line_if_history_changes=True,
            )

        @kb.add("down")
        def _history_down(event):
            event.current_buffer.auto_down(
                count=event.arg,
                go_to_start_of_line_if_history_changes=True,
            )

        @kb.add("c-p")
        def _history_prev(event):
            """Ctrl+P — explicit previous-history, never cursor-up.
            Universal readline binding; works regardless of buffer
            state. Use this when Up is ambiguous (mid-buffer)."""
            event.current_buffer.history_backward(count=event.arg)

        @kb.add("c-n")
        def _history_next(event):
            """Ctrl+N — explicit next-history, never cursor-down."""
            event.current_buffer.history_forward(count=event.arg)

        @kb.add("escape", eager=True)
        def _esc_cancel(event):
            """Esc immediately submits `/cancel` — quick interrupt of
            a running turn (Claude-Code-style). The producer's slash-
            handler picks up `/cancel`, posts to /sessions/{id}/cancel,
            agent halts at the next step boundary.

             — before exit, save the typed-but-unsubmitted buffer
            to the module-level draft slot so /draft can recall it.
            Pre- the buffer was silently wiped on Esc, costing
            users any in-progress text. The cancel intent is
            preserved (we still exit with /cancel); the draft is a
            zero-cost addition.

            If no turn is running, the producer prints a soft '(no turn
            running to cancel)' notice and the prompt re-opens; user
            keeps typing.

            `eager=True` makes Esc fire immediately on press without
            waiting for follow-up key disambiguation at the binding
            layer. Esc-Enter (Alt+Enter) is preserved by registering
            `` directly in ANSI_SEQUENCES → Keys.ControlJ at
            the parser layer (above), so the parser emits ControlJ
            for the full two-byte sequence and never emits a bare
            Keys.Escape that this handler would see. Plain Esc still
            falls through here after the parser's input timeout."""
            _save_draft(event.current_buffer.text)
            event.app.exit(result="/cancel")

        style = Style.from_dict({
            "prompt": "ansibrightblack",
            "": "ansibrightblue bold",
            "completion-menu.completion": "bg:#222222 ansibrightcyan",
            "completion-menu.completion.current": "bg:ansibrightcyan ansiblack",
            "completion-menu.meta.completion": "bg:#222222 ansigray",
        })

        slash_commands = [
            ("/exit", "Leave the chat AND destroy the server session."),
            ("/quit", "Alias for /exit."),
            ("/detach", "Leave but KEEP the session alive — next run resumes."),
            ("/cancel", "Cancel the currently-running turn (if any)."),
            ("/stop", "Alias for /cancel."),
            ("/help", "Show this command list."),
            ("/capabilities", "Show this agent's tools + delegation map."),
            ("/model", "Switch tier: /model standard or /model pro."),
            ("/threshold-ask-user", "Per-turn cost-gate (tier_2 → ask_user, tier_3 → reject). Alias /budget."),
            ("/threshold-auto-compact", "Override auto-compact trigger; mandatory 80% floor still applies."),
            ("/threshold-turn-input", "Per-turn input-token ceiling (default UNLIMITED). Set N to halt runaway turns."),
            ("/threshold-max-steps", "Override per-turn max_steps. Default = spec.max_steps. Set N to expand or shrink."),
            ("/max-output-tokens", "Override per-LLM-call max_output_tokens. Default = spec.max_output_tokens. Use when verdicts truncate."),
            ("/tasks", "Background tasks: /tasks list | resume <id> | kill <id>. (E42, 2026-05-14)"),
            ("/threshold-total-steps", "Override session-cumulative max_total_steps (all turns+subagents). Set N to extend long autonomous runs."),
            ("/budget", "Alias for /threshold-ask-user."),
            ("/cap", "Session spend cap: /cap 1M | +500k | reset."),
            ("/allow-main-commits", "Override feat-branch guard : on | off. Default off."),
            ("/remember", "v3.1.0 — save a fact to user-scope memory: /remember <text> | <key>=<text>. Auto-loads in every agent next session."),
            ("/memory", "v3.3.0 — audit + curate saved memory: /memory [list|get|delete] [agent] [key]. Lists user-scope by default with datetimes."),
            ("/clear", "Clear conversation history (start fresh)."),
            ("/reset", "Alias for /clear."),
            ("/compact", "Fold older messages into a summary."),
            ("/draft", "Recall the most recent Esc-saved draft into the next prompt ."),
            ("/agent", "Switch the active master agent mid-session: /agent <name> ."),
            ("/agents", "List available master agents (filtered by this session's channel)."),
            ("/bg", "E42 — spawn a parallel agent run in the background: /bg <agent> <prompt>. Foreground REPL stays responsive."),
            ("/tasks", "E42 — inspect bg tasks: /tasks list | /tasks status <id> | /tasks kill <id>."),
            ("/auto-approve", "E44 — autonomous-run toggle: /auto-approve on|off|status. Auto-grants every needs_approval event when on."),
        ]

        class _SlashCompleter(Completer):
            def get_completions(self, document, complete_event):
                text = document.text_before_cursor
                if not text.startswith("/"):
                    return
                token = text.split()[0] if text.split() else "/"
                for name, desc in slash_commands:
                    if name.startswith(token):
                        yield Completion(
                            name,
                            start_position=-len(token),
                            display_meta=desc,
                        )

        # E46 (2026-05-13) — persistent chat-input history across
        # sessions. Lives at ~/.master_agents/chat_history. Falls
        # back to in-memory if the file can't be created (read-only
        # home dir, permissions, etc.) so chat still works.
        try:
            _hist_path = master_agents_home() / "chat_history"
            _hist_path.parent.mkdir(parents=True, exist_ok=True)
            _history: Any = FileHistory(str(_hist_path))
        except Exception:
            _history = InMemoryHistory()
        session = PromptSession(
            history=_history,
            multiline=True,
            key_bindings=kb,
            style=style,
            completer=_SlashCompleter(),
            complete_while_typing=True,
        )
    except Exception as exc:
        return _fallback_reader(
            f"prompt_toolkit setup failed — "
            f"{type(exc).__name__}: {exc}. Multi-line paste and "
            "Shift+Enter won't work."
        )

    # kitty keyboard protocol enable removed.
    #  originally enabled `\x1b[>1u` so capable terminals would
    # report Shift+Enter as `\x1b[13;2u`. Run 2 of the live mao
    # refactor test (2026-05-03) revealed the trade-off was net
    # negative: capable terminals also start emitting unmapped
    # functional keys (F13+, Caps Lock state reports, Windows
    # menu keys, Print Screen, etc. — kitty-PUA codes 57344–57471)
    # as CSI-u sequences. prompt_toolkit's vt100 parser doesn't
    # recognise those codes, so it emits a phantom Keys.Escape
    # instead — which trips the eager Esc binding and submits
    # `/cancel` automatically. User saw `/threshold-auto-compact`
    # mysteriously routed to `/cancel` because some background
    # key event arrived while typing.
    #
    # Multi-line input still works without kitty: `\` + Enter
    # (universal backslash continuation, B-cli-shift-enter-newline)
    # and Ctrl+J both insert newlines on every terminal. The
    # ergonomic loss is "Shift+Enter no longer works natively";
    # the gain is "no random /cancel hijacks during chat".
    #
    # The `_enable_kitty_keyboard_protocol` function and the
    # ANSI_SEQUENCES extensions are KEPT in the codebase so a
    # future opt-in mechanism (env var, CLI flag) can re-enable
    # them for users on terminals that don't emit phantom keys.
    # Just no longer called at session start.

    async def _read(prompt: str) -> str:
        # if /draft just recalled a saved buffer, pre-populate
        # the next prompt with it so the user can edit/send instead
        # of typing it again from scratch. _take_pending_prompt_default
        # is single-use; the slot is cleared after this read.
        default = _take_pending_prompt_default()
        if default:
            return await session.prompt_async(prompt, default=default)
        return await session.prompt_async(prompt)

    return _read


_KITTY_ENABLE = "\x1b[>1u"
_KITTY_DISABLE = "\x1b[<u"
_kitty_pushed = False


def _defensive_kitty_disable() -> None:
    """ — defensive pop of kitty keyboard protocol on session start
    (closes A23).

    A pre- master_agents_os process pushed kitty keyboard
    protocol level 1 via `\\x1b[>1u`. If that process crashed before
    the atexit pop ran, the terminal stayed in disambiguate-escape
    mode. A + process started afterward inherits the leftover
    state and starts seeing phantom Esc presses from unmapped
    functional keys (kitty PUA codes 57344-57471). User reports
    `[57414u` leaks STILL appearing post- even though the binary
    has .

    The fix: send `\\x1b[<u` (the kitty pop sequence) on session
    start unconditionally. Terminals not in kitty mode treat the
    sequence as a no-op (CSI sequences with unknown final bytes
    are silently discarded by sane terminal emulators), so calling
    it is safe even on bare cmd.exe / non-kitty xterm.

    Skipped when stdout isn't a TTY (capturing the bytes as visible
    output would corrupt redirected logs).

    Best-effort by design: write failures are swallowed because
    terminal cleanup is not load-bearing — the rest of the session
    must proceed even if the cleanup couldn't write.
    """
    if not sys.stdout.isatty():
        return
    try:
        sys.stdout.write(_KITTY_DISABLE)
        sys.stdout.flush()
    except Exception:
        pass


def _enable_kitty_keyboard_protocol() -> None:
    """Idempotently push kitty keyboard protocol level 1 on stdout
    and register a pop handler. No-op if stdout isn't a TTY (e.g.
    redirected to a file) — the sequence would just leak as visible
    bytes into the captured output."""
    global _kitty_pushed
    if _kitty_pushed:
        return
    if not sys.stdout.isatty():
        return
    try:
        sys.stdout.write(_KITTY_ENABLE)
        sys.stdout.flush()
    except Exception:
        return
    _kitty_pushed = True

    def _pop() -> None:
        try:
            sys.stdout.write(_KITTY_DISABLE)
            sys.stdout.flush()
        except Exception:
            pass

    import atexit
    atexit.register(_pop)
    # Best-effort: also pop on SIGTERM so kill from outside leaves
    # the terminal clean. SIGINT is already handled by atexit since
    # KeyboardInterrupt unwinds normally.
    import signal
    try:
        prev = signal.getsignal(signal.SIGTERM)

        def _handle_sigterm(signum, frame):
            _pop()
            if callable(prev):
                prev(signum, frame)
            else:
                # Re-raise as default handler (terminate).
                signal.signal(signal.SIGTERM, signal.SIG_DFL)
                signal.raise_signal(signal.SIGTERM)

        signal.signal(signal.SIGTERM, _handle_sigterm)
    except (ValueError, OSError):
        # Not on the main thread, or platform doesn't support it
        # (Windows lacks SIGTERM in the POSIX sense) — atexit alone
        # covers normal exits.
        pass