"""Mode-A deterministic post-processor (E5) -- extracted from
`remote_cli.py` as Sprint 9b (second slice of the Sprint 9
commands/repl/run decomposition).

Mode-A detection (and the corresponding warning) fires when a
"plan-shaped" agent (currently just `code_planner`) receives a
thin brief lacking architect-blueprint structure AND doesn't
emit PHASE-5 plan-handoff markers in its output. The diagnostic
nudges operators toward running `architect` upstream so the
plan-shaped agent gets a structured blueprint to work from.

Four names live here:
  - `detect_mode_a_brief(prompt)` -- thin-brief heuristic.
  - `detect_no_phase5_emitted(output)` -- output-shape heuristic.
  - `should_emit_mode_a_warning(*, master, prompt, output)` --
    strict-AND of the two heuristics PLUS plan-shaped-master gate.
  - `format_mode_a_warning(*, master)` -- the actionable warning
    text emitted to stderr.

Three module constants tune the heuristics:
  - `_PLAN_SHAPED_AGENTS` -- frozenset of agent names subject to
    Mode-A detection. `architect` is intentionally excluded
    (it's the FIX, not a victim).
  - `_BLUEPRINT_MARKERS` -- section markers that indicate the
    operator has already run architect and pasted the blueprint.
  - `_THIN_BRIEF_CHARS` -- length threshold for "thin brief"
    (kept for future reporting).

All re-exported from `master_agents_client.remote_cli` via the facade.

Extraction history: Sprint 9b (informal; second slice of
Sprint 9), 2026-05-16, branched off `v3.23.0` main tip. VERBATIM
from `remote_cli.py:307-428` (the `# -- Item 2 -- Mode-A
deterministic post-processor (E5)` section).
"""

from __future__ import annotations

import re


# Plan-shaped agents subject to Mode-A detection. architect itself
# is excluded because it's the FIX for Mode-A (running it upstream
# is what we recommend), so its own output need not be PHASE 5
# shaped to avoid the warning.
_PLAN_SHAPED_AGENTS: frozenset[str] = frozenset({"code_planner"})

# Architect-blueprint section markers -- when any appear in the brief,
# the user has already run architect upstream and pasted the
# blueprint as context. No warning needed.
_BLUEPRINT_MARKERS: tuple[str, ...] = (
    "## Architecture",
    "## Modules",
    "Phase 1 (thin end-to-end slice)",
    "Tradeoff that drove",
    "## Constraints",
    "## Modules / interfaces",
)

# Heuristic threshold for "thin brief". Briefs shorter than this AND
# without anchors are very likely Mode-A.
_THIN_BRIEF_CHARS: int = 500

# Compiled once: matches `path/to/file.ext:LINE` or `:LINE-LINE`.
#
# Requires AT LEAST ONE path separator (`/` or `\`) before the file
# extension. Without this constraint, the regex over-matched network
# endpoints like `db.host:5432` and URLs like `example.com:443`,
# silently suppressing the Mode-A warning when a thin brief mentioned
# any host:port. Both MAO and Claude code reviewers identified this
# independently in the consolidation review (2026-05-06). Test
# coverage in test_mode_a_postprocessor.py:
#   - test_host_port_does_not_count_as_citation
#   - test_url_with_port_does_not_count_as_citation
#   - test_real_file_path_citation_still_recognised
#
# Extension restricted to {1,5} chars after the dot -- covers .py /
# .yaml / .json / .md / .toml / .pyi / .yml / .ts / .tsx / .rs /
# .go / .ipynb without false-matching arbitrary `name.attr:value`
# config-style refs.
_CITATION_RE = re.compile(
    r"\b[\w\-]+(?:[/\\][\w\-./\\]+)+\.[a-zA-Z]\w{0,4}:\d+(?:-\d+)?\b"
)


def detect_mode_a_brief(prompt: str) -> bool:
    """Return True if the brief looks Mode-A (no architect upstream).

    Heuristic -- must satisfy all of:
      - No `path/to/file.ext:LINE` citations, AND
      - No architect-blueprint section markers, AND
      - (length < threshold OR explicitly thin shape)

    Returns True on empty/None to be safe -- empty briefs are the
    most Mode-A-shaped of all.
    """
    if not prompt:
        return True
    if any(marker in prompt for marker in _BLUEPRINT_MARKERS):
        return False
    if _CITATION_RE.search(prompt):
        return False
    # No citations, no blueprint markers -- short OR long, the brief
    # is operating without explicit code anchors. Mode-A by
    # definition. Length only varies the *flavour* of Mode-A, not
    # the verdict; the threshold constant is kept for future
    # reporting (e.g. "very thin brief -- also too short").
    return True


def detect_no_phase5_emitted(output: str | None) -> bool:
    """Return True if the agent's output does NOT show PHASE-5 markers.

    A successful PHASE 5 emission produces either:
      - a `# Plan:` heading, OR
      - a JSON handoff section (`## JSON handoff` or `sub_plans` literal)

    Anything else -- exploration thoughts, soft-landing free text,
    empty -- counts as did-not-reach-PHASE-5.
    """
    if not output:
        return True
    if "# Plan:" in output or "# Plan " in output:
        return False
    if "## JSON handoff" in output or "sub_plans" in output:
        return False
    return True


def should_emit_mode_a_warning(
    *, master: str, prompt: str, output: str | None,
) -> bool:
    """Strict AND of three conditions:
      - master is in the plan-shaped agent set
      - brief is Mode-A shaped (no architect upstream)
      - output didn't reach PHASE 5

    Conservative on purpose. False positives would train operators
    to ignore the warning; only fire when the diagnostic is high-
    confidence."""
    if master not in _PLAN_SHAPED_AGENTS:
        return False
    if not detect_mode_a_brief(prompt):
        return False
    if not detect_no_phase5_emitted(output):
        return False
    return True


def format_mode_a_warning(*, master: str = "code_planner") -> str:
    """The warning text emitted to stderr. Actionable: tells the
    operator what happened and exactly what to run instead."""
    return (
        f"[!] Mode-A detected ({master} received a thin brief AND its "
        f"output didn't reach PHASE 5).\n"
        f"   Recommend running architect upstream first:\n"
        f"     mao-client remote run -m architect \"<your brief>\"\n"
        f"   Then feed the resulting blueprint to {master}."
    )
