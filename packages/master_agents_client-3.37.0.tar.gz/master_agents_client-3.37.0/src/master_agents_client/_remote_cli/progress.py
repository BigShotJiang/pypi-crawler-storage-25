"""Progress visibility + background-task helpers for the remote-CLI
REPL — extracted from `remote_cli.py` as Sprint 1b.2 (the
follow-up to Sprint 7 that closes the lazy-import cycle introduced
by Sprint 1e-b).

Two responsibility groups live here:

E41 (2026-05-13) — live progress visibility for long-running local
tools. Tools that exceed `_LONG_TOOL_VISIBILITY_THRESHOLD_S` get
an in-place updating `... <tool> -- elapsed Xm Ys` line on stderr.
Pre-threshold short tools render nothing. Set the env var
`MASTER_AGENTS_DISABLE_PROGRESS=1` to suppress entirely.

E42 (2026-05-13) — background-execution for parallel agent runs.
`/bg <agent> <prompt>` in `remote chat` spawns a parallel agent
run against another session. Operator-level parallelism: the
foreground REPL stays responsive while the background agent
works. Tracked via /tasks slash commands.

Re-exported from `master_agents_client.remote_cli` via the facade pattern.

Extraction history: Sprint 1b.2 (informal; not part of the
Sprint 7 ledger which closed with Sprint 1f / picker.py),
2026-05-16, branched off `v3.21.0` main tip. The motivating
cleanup: Sprint 1e-b introduced a lazy `from ..remote_cli import
_execute_with_progress` inside `_remote_cli/client.py` to avoid
a module-import cycle. Extracting `_execute_with_progress` here
lets client.py replace that with a clean module-level
`from .progress import _execute_with_progress`. The remaining
circular dep (progress.py needs RemoteSessionClient for
_run_bg_task) is bounded to the _run_bg_task function body via
a lazy import — Python's import system handles this naturally.
"""

from __future__ import annotations

import asyncio
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..remote_client import RemoteToolExecutor
    from .config import RemoteConfig


# E41 (2026-05-13) — Live progress visibility for long-running
# local tools. Tools that exceed _LONG_TOOL_VISIBILITY_THRESHOLD_S
# get an in-place updating `... <tool> -- elapsed Xm Ys` line on
# stderr. Pre-threshold short tools render nothing (no flicker for
# sub-second `read_file` / `file_grep` etc.). Set the env var
# MASTER_AGENTS_DISABLE_PROGRESS=1 to suppress entirely (CI, scripts,
# pipes where \r is unwelcome).
_LONG_TOOL_VISIBILITY_THRESHOLD_S = 5.0
_PROGRESS_TICK_S = 1.0
_PROGRESS_DISABLE_ENV = "MASTER_AGENTS_DISABLE_PROGRESS"

# Inlined mirror of the server's per-tool TTL policy (defined in
# master_agents_client.managed_session, NOT in the client wheel). Kept in
# sync via the constants here — when the server policy changes, the
# tests in tests/test_e41_e42_progress_and_bg.py pin the values so
# divergence fails CI loudly. Used only for *displaying* the timeout
# on the progress line; the server is the authoritative enforcer.
_LONG_RUNNING_LOCAL_TOOLS_CLIENT = frozenset({
    "bash", "powershell", "python_run", "python_eval", "python_eval_sandboxed",
})
_DEFAULT_SHORT_TOOL_TIMEOUT_S = 120.0
_DEFAULT_LONG_TOOL_TIMEOUT_S = 14400.0  # 4h (E41 2026-05-13 bump)


def _compute_display_timeout_s(tool_name: str) -> float:
    """Client-side mirror of `_resolve_local_tool_timeout` for the
    progress-line display. Reads the same env vars as the server.
    Returns the wallclock ceiling in seconds. Display-only -- the
    server still enforces the real cutoff."""
    is_long = tool_name in _LONG_RUNNING_LOCAL_TOOLS_CLIENT
    if is_long:
        raw = os.environ.get("MASTER_AGENTS_LONG_LOCAL_TOOL_TIMEOUT_S")
        if raw:
            try:
                return float(raw)
            except (ValueError, TypeError):
                pass
        raw_short = os.environ.get("MASTER_AGENTS_LOCAL_TOOL_TIMEOUT_S")
        if raw_short:
            try:
                return max(float(raw_short), _DEFAULT_LONG_TOOL_TIMEOUT_S)
            except (ValueError, TypeError):
                pass
        return _DEFAULT_LONG_TOOL_TIMEOUT_S
    raw = os.environ.get("MASTER_AGENTS_LOCAL_TOOL_TIMEOUT_S")
    if raw:
        try:
            return float(raw)
        except (ValueError, TypeError):
            pass
    return _DEFAULT_SHORT_TOOL_TIMEOUT_S


def _format_elapsed(seconds: float) -> str:
    """Render seconds as `Xm Ys` (or `Ys` if under a minute, or
    `Xh Ym` if over an hour). E.g. 12.4 -> '12s', 75 -> '1m 15s',
    7321 -> '2h 2m'."""
    s = int(seconds)
    if s < 60:
        return f"{s}s"
    m, s = divmod(s, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"


def _summarise_tool_invocation(tool_name: str, tool_input: dict) -> str:
    """Short one-line `tool args` summary for the progress line.
    Picks the most distinctive arg per tool family (script for
    python_run, command for bash, etc.). Truncates to ~60 chars."""
    if not isinstance(tool_input, dict):
        return tool_name
    distinctive_arg: str | None = None
    if tool_name == "python_run":
        args = tool_input.get("args")
        if isinstance(args, list) and args:
            distinctive_arg = " ".join(str(a) for a in args[:3])
    elif tool_name in ("bash", "powershell"):
        cmd = tool_input.get("command") or tool_input.get("script")
        if isinstance(cmd, str):
            distinctive_arg = cmd.splitlines()[0] if cmd else ""
    elif tool_name in ("python_eval", "python_eval_sandboxed"):
        code = tool_input.get("code")
        if isinstance(code, str):
            distinctive_arg = code.splitlines()[0] if code else ""
    if distinctive_arg:
        if len(distinctive_arg) > 60:
            distinctive_arg = distinctive_arg[:57] + "..."
        return f"{tool_name} {distinctive_arg}"
    return tool_name


async def _execute_with_progress(
    executor: "RemoteToolExecutor",
    tool_name: str,
    tool_input: dict,
    *,
    out=None,
) -> tuple[Any, bool]:
    """Run executor.execute() with an in-place elapsed-time display
    on stderr (default) for tools that exceed the visibility threshold.

    E41 (2026-05-13): wraps the single use site at the SSE round-trip
    boundary so EVERY local tool call gets visibility without affecting
    the executor's API. Short tools render nothing (threshold-gated).
    Disable entirely with MASTER_AGENTS_DISABLE_PROGRESS=1.

    Returns the same `(result, is_error)` tuple as executor.execute.
    """
    if out is None:
        out = sys.stderr
    disabled = os.environ.get(_PROGRESS_DISABLE_ENV, "").lower() in (
        "1", "true", "yes",
    )
    # Non-TTY destinations (pipes / files) get no \r dance -- the line
    # would just accumulate. Only render when the destination looks
    # interactive. CI logs stay clean.
    try:
        is_tty = bool(getattr(out, "isatty", lambda: False)())
    except Exception:
        is_tty = False
    if disabled or not is_tty:
        return await executor.execute(tool_name, tool_input)

    summary = _summarise_tool_invocation(tool_name, tool_input)
    timeout_s = _compute_display_timeout_s(tool_name)
    timeout_str = _format_elapsed(timeout_s)
    started = time.monotonic()
    line_rendered = False

    async def _ticker() -> None:
        nonlocal line_rendered
        # Wait until threshold before rendering anything -- short tools
        # finish in well under threshold and need zero output.
        try:
            await asyncio.sleep(_LONG_TOOL_VISIBILITY_THRESHOLD_S)
        except asyncio.CancelledError:
            return
        while True:
            elapsed = time.monotonic() - started
            try:
                # Format mirrors Claude Code's `(52s . timeout 5m)`
                # ergonomic -- operator sees both how long it's been
                # AND when the server will give up. Esc-to-cancel
                # hint matches the existing keybind at remote_cli.py
                # ~line 2241 (Esc submits /cancel).
                out.write(
                    f"\r... {summary} -- elapsed {_format_elapsed(elapsed)}"
                    f" . timeout {timeout_str} (Esc to cancel)\033[K"
                )
                out.flush()
                line_rendered = True
            except Exception:
                # Anything goes wrong with writing (closed stream,
                # encoding error) -- just stop ticking; the underlying
                # execute() carries on regardless.
                return
            try:
                await asyncio.sleep(_PROGRESS_TICK_S)
            except asyncio.CancelledError:
                return

    ticker_task = asyncio.create_task(_ticker())
    try:
        result, is_error = await executor.execute(tool_name, tool_input)
        return result, is_error
    finally:
        ticker_task.cancel()
        try:
            await ticker_task
        except (asyncio.CancelledError, Exception):
            pass
        # Clear the progress line if anything was rendered. Use
        # `\r` + ANSI erase-to-end-of-line so any pending REPL
        # prompts paint cleanly on top.
        if line_rendered:
            try:
                out.write("\r\033[K")
                out.flush()
            except Exception:
                pass


# E42 (2026-05-13) -- Background-exec for parallel agent runs.
#    `/bg <agent> <prompt>` in `remote chat` spawns a parallel run
#    against another agent in its own session. Operator-level
#    parallelism: the foreground REPL stays responsive while the
#    background agent works. Tracked via /tasks slash commands.
#    Lifetime: chat session. For durable long-running work, use
#    `mao-client remote run --detach` in a separate terminal.
@dataclass
class _BgTask:
    """One parallel agent run kicked off from the foreground chat
    REPL via `/bg`. Lives in the chat session's `bg_tasks` dict.

    Status transitions: 'starting' -> 'running' -> ('completed' |
    'failed' | 'cancelled'). The asyncio task may still be alive
    in the 'starting' window (auth/open negotiation pending)."""
    task_id: str
    agent: str
    prompt: str
    started_at: float  # time.monotonic() for elapsed display
    started_wall: float  # time.time() for human-readable timestamps
    asyncio_task: Any = None  # asyncio.Task -- set after create_task
    status: str = "starting"
    result: str | None = None
    error: str | None = None
    session_id: str | None = None


async def _run_bg_task(
    cfg: "RemoteConfig",
    agent: str,
    prompt: str,
    record: _BgTask,
) -> None:
    """Runner coroutine for a /bg task. Creates a sibling client
    with the same auth context, runs the agent once, captures the
    final answer (or error) into the shared _BgTask record. Status
    updates are observable via /tasks slash commands. Never raises
    -- all failures land in record.error + status='failed' so the
    bg task can be inspected without crashing the REPL."""
    record.status = "running"
    try:
        # Lazy import bounds the progress.py <-> client.py cycle
        # to this function body. Sprint 1b.2 (2026-05-16): client.py
        # also lazy-imports _execute_with_progress from progress.py
        # inside _consume_stream, so neither module-load order
        # triggers a circular dep error.
        from .client import RemoteSessionClient

        client = RemoteSessionClient(
            base_url=cfg.server,
            token=cfg.token,
            cwd=Path(os.getcwd()),
            writable_paths=cfg.writable_paths,
        )
        # Track session_id once open. RemoteSessionClient.run() manages
        # its own session lifecycle, but we don't have a hook to grab
        # the id before it's destroyed. Set via attribute access if
        # the client exposes it after open.
        record.result = await client.run(agent, prompt)
        record.session_id = getattr(client, "_last_run_session_id", None)
        record.status = "completed"
    except asyncio.CancelledError:
        record.status = "cancelled"
        raise
    except Exception as exc:
        record.error = f"{type(exc).__name__}: {exc}"
        record.status = "failed"
