"""Render / display helpers for the remote-CLI REPL — extracted from
`remote_cli.py` as the third sub-module of the Phase 1
decomposition (per the addendum §3 Sprint 7 module list).

Eleven helpers live here, all private (underscore prefix):

  Separators / answer print:
    - `_print_user_separator`      `──── you ────` rule above prompt
    - `_print_agent_separator`     `──── agent ────` rule before reply
    - `_print_separator`           generic labelled separator
    - `_print_answer`              markdown / plain final-answer print

  Ask-user surface:
    - `_surface_agent_question`    print needs_input question + footer

  Duration + footer formatters:
    - `_format_duration`           "30s" / "1m 5s" / "1h 23m"
    - `_format_ctx_suffix`         "  ·  ctx: 65K / 1M (compact at 80%)"
    - `_format_cache_suffix`       "  ·  cache: 78% (3.2M read)"
    - `_format_cap_suffix`         "  ·  cap: 263K / 1M used (26%)"
    - `_format_cost_band_suffix`   "  ·  cost: 25K est within 100K budget"
    - `_print_remote_token_line`   composite footer print

Re-exported from `master_agents_client.remote_cli` via the facade pattern
(see `remote_cli.py` top of file) so existing call sites inside
`remote_cli.py` keep working unchanged. All names are private
(underscore prefix) and therefore NOT pinned by the public-API-surface
fixture (`packages/py/tests/test_public_api_surface.py`).

Pure rendering — no orchestration, no HTTP, no config I/O. This
module's surface is invariant to the rest of the `remote_cli.py`
decomposition.

Extraction history: Sprint 7 sub-module 3 (informal: Sprint 1c),
2026-05-16, branched off `v3.15.0` main tip. Function bodies below
are VERBATIM from the pre-extraction `remote_cli.py` (lines 3121-
3225 + 3323-3518) via E83 verbatim passthrough at `apply_edit_step`.
The `client: "RemoteSessionClient"` parameter in `_surface_agent_question`
remains a string forward-reference (lazily resolved at call time),
so this module needs no import of `RemoteSessionClient`. Zero
behaviour change.
"""

from __future__ import annotations

import sys
from typing import Any


def _print_user_separator(*, color: bool) -> None:
    """Short `──── you ────` rule above the next prompt."""
    _print_separator(label="you", color=color)


def _print_agent_separator(*, color: bool, agent: str | None = None) -> None:
    """Short `──── agent ────` (or `──── brainstormer ────`) rule
    printed right after the user submits, before the agent's activity
    stream begins. Mirrors the user separator so each turn is bookended
    visually."""
    label = agent if agent else "agent"
    _print_separator(label=label, color=color)


def _print_separator(*, label: str, color: bool) -> None:
    """Fixed-width separator anchor — full-width rules dominated the
    output and made the chat feel like form-filling. 4 dashes each side
    of the label is enough to anchor the eye without crowding."""
    line = f"──── {label} ────"
    if color:
        sys.stderr.write(f"\x1b[2m{line}\x1b[0m\n")
    else:
        sys.stderr.write(line + "\n")
    sys.stderr.flush()


def _print_answer(text: str, *, markdown: bool) -> None:
    """Render the agent's final answer.

    With `markdown=True`, try to use `rich` for terminal-friendly rendering
    of bold/headings/tables/code blocks. Falls back to plain `print` if rich
    isn't installed (it's an optional `[remote-chat]` extra) or if the user
    passed --no-markdown.
    """
    if markdown:
        try:
            from rich.console import Console
            from rich.markdown import Markdown

            Console().print(Markdown(text))
            return
        except ImportError:
            pass
    print(text)


def _surface_agent_question(
    question: str,
    *,
    markdown: bool,
    color: bool,
    client: "RemoteSessionClient",
) -> None:
    """ — print an `ask_user` / `needs_approval` question with
    markdown rendering AND a token-line footer.

    Pre- the inline `_on_needs_input` closure printed the
    question verbatim with no rendering and no footer. Two distinct
    UX gaps:

      A7 — markdown surface fields like bold / lists / code fences
        printed as raw `**bold**` / `- item` source. Dense audit
        summaries (the exact case where ask_user fires most) were
        hard to read.

      A6 — token / cost / cap / duration footer only emitted at
        clean turn end, never on pause. The user couldn't see how
        much spend had accrued before deciding what to type back —
        exactly when that decision matters most.

    Extracted to a module-level helper so tests can drive it
    directly without spinning up the full chat REPL."""
    print()
    print("──── agent question ────")
    _print_answer(question, markdown=markdown)
    if client.last_tokens:
        _print_remote_token_line(
            client.last_tokens,
            color=color,
            duration_s=client.last_turn_seconds,
            cost_summary=client.last_cost_summary,
            cap_info=client.last_cap,
        )
    print(
        "(type your answer below; the next message you send goes "
        "back to the agent — queue is paused)"
    )


def _format_duration(seconds: float | None) -> str:
    """Render wallclock seconds for the token line: `30s`, `1m 5s`,
    `1h 23m`. None or non-positive → empty string so the caller can
    omit the prefix entirely."""
    if seconds is None or seconds <= 0:
        return ""
    s = int(seconds)
    if s < 60:
        # Sub-second precision below 10s gives faster turns a more
        # informative read; integer seconds beyond that.
        if seconds < 10:
            return f"{seconds:.1f}s"
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m {s % 60}s"
    return f"{s // 3600}h {(s % 3600) // 60}m"


def _format_ctx_suffix(tokens: dict[str, Any] | None) -> str:
    """: render the context-window indicator.

    Format depends on what's known:
      ctx: 65K / 1M (compact at 100K)        — both fields present
      ctx: 65K / 1M                          — model_max known, no soft threshold
      (empty)                                — model_max=0 (older server)

    Always shows "compact at 80%" when soft_compact is None — the
    mandatory floor always applies.
    """
    if not tokens:
        return ""
    history = int(tokens.get("history_tokens", 0) or 0)
    model_max = int(tokens.get("model_max_tokens", 0) or 0)
    if model_max <= 0:
        return ""
    soft = tokens.get("soft_compact_threshold")
    # Format helpers — match the cap suffix style.
    def _k(n: int) -> str:
        if n < 1000:
            return str(n)
        if n < 1_000_000:
            return f"{n / 1000:g}K"
        return f"{n / 1_000_000:.2f}M"
    pct = int(100 * history / model_max) if model_max else 0
    base = f"  ·  ctx: {_k(history)} / {_k(model_max)}"
    if soft is not None and isinstance(soft, int):
        base += f" (compact at {_k(soft)})"
    elif model_max:
        # No soft threshold; surface the mandatory 80% floor .
        base += f" (auto-compact at {_k(int(model_max * 0.8))})"
    if pct >= 80:
        base += " — close to context wall"
    # append model tier alias when present (vendor-abstracted per
    # ; users see "standard" / "pro", not the canonical model ID).
    alias = tokens.get("model_alias")
    if isinstance(alias, str) and alias:
        base += f"  ·  model: {alias}"
    return base


def _format_cache_suffix(tokens: dict[str, Any] | None) -> str:
    """E36 (2026-05-13): render the cache-hit-rate indicator.

    Format depends on what the server payload carries:

      cache: 78% (3.2M read this session)    — full data
      cache: 78%                              — turn-zero session
      (empty)                                 — older server (no
                                                cache fields in
                                                payload), OR no
                                                cache reads yet.

    The ratio is server-computed via `session.cache_hit_ratio`
    (`_total_cache_read_tokens / _total_input_tokens`); this client
    just renders.

    Cache-regression diagnosis time motivated this — pre-E36, a
    cache-hit-rate collapse like E32 (DeepSeek prefix-cache
    regression, May 2026) only surfaced after a forensic JSONL
    trace dive. With this footer the user sees "cache: 1%" the
    first turn after a regression lands.
    """
    if not tokens:
        return ""
    ratio = tokens.get("session_cache_hit_ratio")
    cache_total = tokens.get("session_cache_read_total")
    if ratio is None and cache_total is None:
        return ""  # older server, no cache fields
    try:
        pct = int(round(float(ratio or 0.0) * 100))
    except (TypeError, ValueError):
        return ""
    if pct <= 0 and not cache_total:
        return ""  # no cache reads yet — don't add noise
    base = f"  ·  cache: {pct}%"
    try:
        total = int(cache_total or 0)
    except (TypeError, ValueError):
        total = 0
    if total >= 1000:
        # Match the K/M format style used by `_format_ctx_suffix`.
        if total < 1_000_000:
            base += f" ({total / 1000:g}K read)"
        else:
            base += f" ({total / 1_000_000:.2f}M read)"
    return base


def _format_cap_suffix(cap_info: dict[str, Any] | None, session_total: int) -> str:
    """Render the  cap indicator. Empty when no cap is set.

    Formats:
      cap: 263K / 1M used (26%)
      cap: 920K / 1M used (92%) — close to halt
      cap: 1.02M / 1M — HALTED
    """
    if not cap_info:
        return ""
    cap = int(cap_info.get("cap", 0) or 0)
    if cap <= 0:
        return ""
    # Always use the live session_total when the chat updates between
    # turns, since cap_info.used can be stale by one turn.
    used = max(int(cap_info.get("used", 0) or 0), session_total)
    pct = int(100 * used / cap) if cap else 0
    used_str = f"{used / 1000:g}K" if used < 1_000_000 else f"{used / 1_000_000:.2f}M"
    cap_str = f"{cap / 1000:g}K" if cap < 1_000_000 else f"{cap / 1_000_000:.2f}M"
    if used > cap:
        return f"  ·  cap: {used_str} / {cap_str} — HALTED"
    if pct >= 90:
        return f"  ·  cap: {used_str} / {cap_str} used ({pct}%) — close to halt"
    return f"  ·  cap: {used_str} / {cap_str} used ({pct}%)"


def _format_cost_band_suffix(cost_summary: dict[str, Any] | None) -> str:
    """Render the  cost-band indicator that appends to the token line.

    Surfaces the agent's estimate-then-decide footprint for every turn that
    called estimate_tokens. Three formats by tier:

      tier_1: "  ·  cost: 25K est within 100K budget"
      tier_2: "  ·  cost: 130K est over budget — user consulted"
      tier_3: "  ·  cost: 250K est REJECTED (over 200K hard cap)"

    Returns "" when no estimate calls were made — keeps the line clean for
    pure-text turns.
    """
    if not cost_summary:
        return ""
    total = int(cost_summary.get("total_estimated_tokens", 0) or 0)
    threshold = int(cost_summary.get("threshold", 0) or 0)
    band = cost_summary.get("band", "tier_1")
    consulted = bool(cost_summary.get("user_consulted", False))
    total_k = total / 1000
    threshold_k = threshold / 1000
    if band == "tier_1":
        return f"  ·  cost: {total_k:g}K est within {threshold_k:g}K budget"
    if band == "tier_2":
        suffix = "user consulted" if consulted else "approval required"
        return f"  ·  cost: {total_k:g}K est over budget — {suffix}"
    # tier_3
    return (
        f"  ·  cost: {total_k:g}K est REJECTED "
        f"(over {threshold_k * 2:g}K hard cap)"
    )


def _print_remote_token_line(
    tokens: dict[str, Any],
    *,
    color: bool,
    duration_s: float | None = None,
    cost_summary: dict[str, Any] | None = None,
    cap_info: dict[str, Any] | None = None,
) -> None:
    """Format the server's `final.tokens` payload as a dim one-liner.

    Mirrors the local-chat token line so remote users get the same per-turn +
    cumulative visibility. With duration_s set, prefixes the line with
    `Time: 30s | ` so the user sees turn latency alongside cost
    (matches Claude Code's per-message summary).

    With `cost_summary` set (the  cost_band_summary event payload),
    appends a tier indicator: `cost: 25K est within 100K budget`.

    Server payload shape:
      {input, output, session_total, history_tokens, compact_savings}
    """
    turn_in = int(tokens.get("input", 0) or 0)
    turn_out = int(tokens.get("output", 0) or 0)
    session_total = int(tokens.get("session_total", 0) or 0)
    duration = _format_duration(duration_s)
    prefix = f"Time: {duration} | " if duration else ""
    cost_suffix = _format_cost_band_suffix(cost_summary)
    cap_suffix = _format_cap_suffix(cap_info, session_total)
    ctx_suffix = _format_ctx_suffix(tokens)
    # E36 (2026-05-13) — surface the cache hit rate in the per-turn
    # footer. Pre-fix the data existed server-side
    # (`session.cache_hit_ratio`, `_total_cache_read_tokens`) but
    # never reached this footer; cache regressions like E32 took
    # days to diagnose because the signal was buried in trace
    # JSONL. Now any user can see "cache: 78%" in real time.
    # Backward-compatible: older servers won't include the cache
    # fields and the suffix collapses to an empty string.
    cache_suffix = _format_cache_suffix(tokens)
    text = (
        f"  {prefix}tokens: {turn_in:,} in + {turn_out:,} out "
        f"({turn_in + turn_out:,} turn)  ·  {session_total:,} session"
        f"{cache_suffix}{cap_suffix}{ctx_suffix}{cost_suffix}"
    )
    if color:
        print(f"\x1b[2m{text}\x1b[0m")
    else:
        print(text)
