"""Server-Sent Events (SSE) chunk parser — extracted from
`remote_cli.py` as the second sub-module of the Sprint 1+
decomposition (Phase B).

One private-by-naming-convention (underscore-prefixed) helper lives
here:
  - `_parse_sse_chunk`: parse a single ``event: NAME\\ndata: {json}``
    SSE frame into a ``(event_name, payload_dict)`` tuple, or
    ``None`` if the chunk does not match that shape.

Re-exported from `master_agents_client.remote_cli` via the facade pattern
(see `remote_cli.py` top of file) so the single internal call site
at ``remote_cli.py`` (~line 1571) keeps working unchanged. The name
is private (underscore prefix) and therefore NOT pinned by the
public-API-surface fixture
(`packages/py/tests/test_public_api_surface.py`).

Pure parsing — no orchestration, no HTTP, no I/O. This module's
surface is invariant to the rest of the `remote_cli.py`
decomposition.

Extraction history: Sprint 1b, 2026-05-15, branched off frozen
Sprint 1a tag. Code below is VERBATIM from the pre-extraction
`remote_cli.py:390-404` with NO changes (no relative imports to
rewrite). Zero behaviour change.
"""

from __future__ import annotations

import json


def _parse_sse_chunk(chunk: bytes) -> tuple[str, dict] | None:
    text = chunk.decode("utf-8", errors="replace")
    if not text.startswith("event: "):
        return None
    parts = text.strip().split("\n", 1)
    if len(parts) != 2:
        return None
    event_line, data_line = parts
    event_name = event_line.split(": ", 1)[1]
    payload_text = data_line.split(": ", 1)[1] if data_line.startswith("data: ") else "{}"
    try:
        payload = json.loads(payload_text)
    except json.JSONDecodeError:
        payload = {}
    return event_name, payload
