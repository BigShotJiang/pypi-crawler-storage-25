"""Routine (cron-driven scheduled-run) helpers for the remote-CLI
REPL -- extracted from `remote_cli.py` as Sprint 9d (fourth slice
of the Sprint 9 commands/repl/run decomposition).

Two names live here:
  - `_cmd_remote_routine(args)` -- dispatcher for `mao-client remote
    routine {add,list,remove,run-all}`. Loads/saves to
    ~/.master_agents/schedules.yaml via the scheduler module.
  - `_routine_run_all(args, due_schedules, mark_fired)` -- the cron-
    driven fire path: iterates due schedules, dispatches each via
    RemoteSessionClient (one-shot, non-interactive), marks_fired
    on success.

The scheduler module lives in the client wheel
(master_agents_client.scheduler), imported lazily inside
`_cmd_remote_routine` so the server-only source install
gracefully degrades.

`RemoteSessionClient` is imported LAZILY inside `_routine_run_all`
to avoid a module-load-time circular dep between this module and
`_remote_cli/client.py` (same pattern as `_remote_cli/progress.py`
for `_run_bg_task`).

All re-exported from `master_agents_client.remote_cli` via the facade.

Extraction history: Sprint 9d (informal; fourth slice of Sprint 9),
2026-05-16, branched off `v3.24.0` main tip. VERBATIM from
`remote_cli.py:198-312`.
"""

from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from typing import Any

from .config import load_remote_config
from .session_state import _config_path


def _cmd_remote_routine(args: Any) -> int:
    """E49 -- dispatcher for `mao-client remote
    routine {add,list,remove,run-all}`.

    Loads / saves to ~/.master_agents/schedules.yaml via the
    scheduler module. `run-all` is the cron-driven fire path:
    iterates due schedules, dispatches each via RemoteSessionClient
    (one-shot, non-interactive), marks_fired on success.
    """
    # The scheduler module lives in the client wheel (wheel-only per
    # _WHEEL_ONLY_PRESERVE). When running from the server source
    # install, fall back gracefully -- the user will install the
    # client wheel to use routines, which is the normal deployment.
    try:
        from master_agents_client.scheduler import (  # type: ignore[import-not-found]
            Schedule, add_schedule, due_schedules, load_schedules,
            mark_fired, remove_schedule,
        )
    except ImportError:
        print(
            "routine: scheduler module not available -- install "
            "`master-agents-client` (the public wheel ships scheduler.py).",
            file=sys.stderr,
        )
        return 2

    sub = getattr(args, "routine_command", None)
    if sub == "add":
        try:
            s = Schedule(
                name=args.name,
                master=args.master,
                prompt=args.prompt,
                every=getattr(args, "every", None),
                at=getattr(args, "at", None),
            )
            add_schedule(s)
        except ValueError as exc:
            print(f"routine add failed: {exc}", file=sys.stderr)
            return 2
        print(
            f"Added routine {args.name!r} "
            f"({'every ' + args.every if args.every else 'at ' + args.at}). "
            f"Next fire: {s.next_fire_ts}."
        )
        return 0
    if sub == "list":
        rows = load_schedules()
        if not rows:
            print("(no routines configured)")
            return 0
        print(f"{'NAME':<24}  {'MASTER':<20}  {'SCHEDULE':<14}  NEXT FIRE")
        for s in rows:
            sched = f"every {s.every}" if s.every else f"at {s.at}"
            nxt = s.next_fire_ts or "(not computed)"
            print(f"{s.name:<24}  {s.master:<20}  {sched:<14}  {nxt}")
        return 0
    if sub == "remove":
        ok = remove_schedule(args.name)
        if not ok:
            print(f"routine {args.name!r} not found", file=sys.stderr)
            return 1
        print(f"Removed routine {args.name!r}.")
        return 0
    if sub == "run-all":
        return asyncio.run(_routine_run_all(args, due_schedules, mark_fired))
    return 2


async def _routine_run_all(args: Any, due_schedules: Any, mark_fired: Any) -> int:
    """Fire every routine whose next_fire_ts is past `now`.

    For each due routine: open a one-shot RemoteSessionClient
    (non-interactive, like `remote run`), dispatch the prompt,
    print the result to stdout, and mark_fired so the schedule
    advances. Failures are logged to stderr but don't abort the
    loop -- one bad routine shouldn't block the others.
    """
    from datetime import datetime, timezone

    # Lazy import bounds the routine.py <-> client.py cycle to this
    # function body. Same pattern as _run_bg_task in progress.py.
    from .client import RemoteSessionClient

    cfg = load_remote_config(_config_path(args))
    due = due_schedules()
    if not due:
        print("(no routines due)")
        return 0
    fired = 0
    failed = 0
    for s in due:
        print(f"--- firing routine {s.name!r} (master={s.master}) ---")
        try:
            client = RemoteSessionClient(
                base_url=cfg.server, token=cfg.token,
                cwd=Path(os.getcwd()),
                writable_paths=cfg.writable_paths,
                permissions=getattr(cfg, "permissions", None),
                # Routines run silently -- no project_context walk by
                # default (the schedule was authored with explicit
                # prompt context). Operators can opt in by setting a
                # future per-routine `project_context: true` flag.
                project_context=False,
            )
            try:
                result = await client.run(s.master, s.prompt)
                print(result)
                mark_fired(s.name, fire_ts=datetime.now(timezone.utc))
                fired += 1
            finally:
                await client.close()
        except Exception as exc:
            print(
                f"routine {s.name!r} failed: {type(exc).__name__}: {exc}",
                file=sys.stderr,
            )
            failed += 1
    print(f"--- {fired} fired, {failed} failed, {len(due) - fired - failed} skipped ---")
    return 0 if failed == 0 else 1
