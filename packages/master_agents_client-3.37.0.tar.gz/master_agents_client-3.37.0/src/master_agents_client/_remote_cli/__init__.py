"""Sprint-1+ remote-CLI subpackage — slices of the larger
remote_cli.py decomposition (Phase 1 of the god-module plan).

Sprint 7 sub-module ledger (closed 2026-05-16 with Sprint 1f):
  - Sprint 1a (2026-05-15) shipped `config.py`
  - Sprint 1b (2026-05-15) added `sse.py`
  - Sprint 1c (2026-05-16) added `render.py`
  - Sprint 1d (2026-05-16) added `prompts.py`
  - Sprint 1e (2026-05-16) added `client.py`
    (1e-a: SessionEndedError; 1e-b: RemoteSessionClient class)
  - Sprint 1f (2026-05-16) added `picker.py`

Sprint 9 (commands / repl / run / `__init__`-shim) targets the
remaining ~3500 LoC in `remote_cli.py` under a separate sub-module
plan; Sprints 8 / 10 / 11 / 12 tackle the service, the service, and
the service respectively.

External callers MUST keep using `master_agents_client.remote_cli` — this
subpackage is implementation, not API. The facade pattern in the
public ``remote_cli`` module re-imports from here, so

    from master_agents_client.remote_cli import RemoteConfig

continues to work exactly as before the extractions. Underscore-
prefixed re-exports (e.g. ``_parse_sse_chunk``, ``_print_separator``)
are private by naming convention but are also re-exported so internal
call sites in ``remote_cli.py`` keep working unchanged after the
extraction.
"""

from __future__ import annotations

from .auth import _cmd_remote_login, _cmd_remote_logout, _resolve_master
from .chat import (
    _REMOTE_CHAT_HELP,
    _cmd_remote_chat,
    _fetch_agent_details,
    _parse_budget_arg,
    _parse_cap_arg,
    _print_capabilities,
    _rehydrate_specific,
    _try_resume_active_session,
)
from .config import RemoteConfig, load_remote_config, save_remote_config
from .mode_a import (
    _BLUEPRINT_MARKERS,
    _CITATION_RE,
    _PLAN_SHAPED_AGENTS,
    _THIN_BRIEF_CHARS,
    detect_mode_a_brief,
    detect_no_phase5_emitted,
    format_mode_a_warning,
    should_emit_mode_a_warning,
)
from .prompts import (
    _defensive_kitty_disable,
    _draft_slot,
    _enable_kitty_keyboard_protocol,
    _has_draft,
    _make_prompt_reader,
    _pending_default_slot,
    _recall_draft,
    _save_draft,
    _set_pending_prompt_default,
    _take_pending_prompt_default,
)
from .render import (
    _format_cache_suffix,
    _format_cap_suffix,
    _format_cost_band_suffix,
    _format_ctx_suffix,
    _format_duration,
    _print_agent_separator,
    _print_answer,
    _print_remote_token_line,
    _print_separator,
    _print_user_separator,
    _surface_agent_question,
)
from .picker import _format_age, _list_recent_sessions, _pick_session
from .routine import _cmd_remote_routine, _routine_run_all
from .run import _build_headless_approval_callback, _cmd_remote_run
from .progress import (
    _BgTask,
    _compute_display_timeout_s,
    _execute_with_progress,
    _format_elapsed,
    _run_bg_task,
    _summarise_tool_invocation,
)
from .session_state import (
    DEFAULT_ACTIVE_SESSION_PATH,
    DEFAULT_REMOTE_CONFIG_PATH,
    _TOKEN_SUFFIXES,
    _clear_active_session,
    _config_path,
    _load_active_session,
    _save_active_session,
    last_session_file_path,
    parse_token_count,
    read_last_session_id,
    write_last_session_id,
)
from .sse import _parse_sse_chunk
from .client import RemoteSessionClient, SessionEndedError

__all__ = [
    "DEFAULT_ACTIVE_SESSION_PATH",
    "DEFAULT_REMOTE_CONFIG_PATH",
    "_REMOTE_CHAT_HELP",
    "RemoteConfig",
    "RemoteSessionClient",
    "SessionEndedError",
    "_BLUEPRINT_MARKERS",
    "_CITATION_RE",
    "_PLAN_SHAPED_AGENTS",
    "_THIN_BRIEF_CHARS",
    "_TOKEN_SUFFIXES",
    "_build_headless_approval_callback",
    "_clear_active_session",
    "_cmd_remote_chat",
    "_cmd_remote_login",
    "_cmd_remote_logout",
    "_cmd_remote_routine",
    "_cmd_remote_run",
    "_config_path",
    "_defensive_kitty_disable",
    "_draft_slot",
    "_enable_kitty_keyboard_protocol",
    "_fetch_agent_details",
    "_format_age",
    "_format_cache_suffix",
    "_format_cap_suffix",
    "_format_cost_band_suffix",
    "_format_ctx_suffix",
    "_format_duration",
    "_has_draft",
    "_list_recent_sessions",
    "_load_active_session",
    "_make_prompt_reader",
    "_parse_budget_arg",
    "_parse_cap_arg",
    "_parse_sse_chunk",
    "_pending_default_slot",
    "_pick_session",
    "_print_agent_separator",
    "_print_capabilities",
    "_print_answer",
    "_print_remote_token_line",
    "_print_separator",
    "_print_user_separator",
    "_recall_draft",
    "_rehydrate_specific",
    "_resolve_master",
    "_routine_run_all",
    "_save_active_session",
    "_save_draft",
    "_set_pending_prompt_default",
    "_surface_agent_question",
    "_take_pending_prompt_default",
    "_try_resume_active_session",
    "detect_mode_a_brief",
    "detect_no_phase5_emitted",
    "format_mode_a_warning",
    "last_session_file_path",
    "load_remote_config",
    "parse_token_count",
    "read_last_session_id",
    "save_remote_config",
    "should_emit_mode_a_warning",
    "write_last_session_id",
]
