"""Remote-client configuration — extracted from `remote_cli.py` as
the first sub-module of the Sprint 1+ decomposition (Phase B).

Three public names live here:
  - `RemoteConfig`: dataclass for `~/.master_agents/remote.yaml`.
  - `save_remote_config`: serialise to YAML with chmod 0600 on POSIX.
  - `load_remote_config`: parse YAML, resolve bearer token via
    MASTER_AGENTS_API_TOKEN env (single SoT), surface E47
    permissions-block + legacy writable_paths deprecation warning.

All three re-export from `master_agents_client.remote_cli` via the facade
pattern (see `remote_cli.py` top of file) so external callers keep
working unchanged. The public-API-surface fixture
(`packages/py/tests/test_public_api_surface.py`) pins this contract.

Pure config I/O — no orchestration logic, no HTTP, no SSE. This
module's surface is invariant to whatever the rest of the
`remote_cli.py` decomposition does later.

Extraction history: Sprint 1a, 2026-05-15, branched off frozen
Sprint 0' tag. Code below is VERBATIM from the pre-extraction
`remote_cli.py:129-233` with only one mechanical change: the lazy
import of `load_platforms_env_files` switches from `._paths` to
`..._paths` to account for being nested one level deeper in the
package tree. Zero behaviour change.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class RemoteConfig:
    server: str
    token: str
    default_master: str | None = None
    cwd_mode: str = "auto"  # "auto" = os.getcwd() at invocation; "fixed" would pin
    writable_paths: list[str] = field(default_factory=lambda: ["."])
    # E47 (2026-05-14) — structured permission rules (allow + deny
    # lists of `Tool(<pattern>)` strings). When None, falls back to
    # legacy `writable_paths`-only enforcement; when present, runs
    # BEFORE the writable_paths check so deny rules win.
    # Schema: {"allow": [...], "deny": [...]}. See
    # `master_agents_client.permissions.PermissionsConfig` for the
    # rule grammar.
    permissions: dict[str, list[str]] | None = None


def save_remote_config(path: Path | str, cfg: RemoteConfig) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "server": cfg.server,
        "token": cfg.token,
        "default_master": cfg.default_master,
        "cwd_mode": cfg.cwd_mode,
        "writable_paths": list(cfg.writable_paths),
    }
    # E47 (2026-05-14): only emit `permissions:` when the config
    # actually has rules — keeps legacy configs unchanged on save.
    if cfg.permissions:
        payload["permissions"] = cfg.permissions
    p.write_text(yaml.safe_dump(payload, sort_keys=True), encoding="utf-8")
    # POSIX: enforce user-only perms. Windows: best-effort (os.chmod partial).
    try:
        os.chmod(p, 0o600)
    except OSError:  # pragma: no cover
        pass
    if sys.platform == "win32":
        print(
            f"Note: on Windows, ensure only your user can read {p}. "
            "The CLI cannot enforce ACLs automatically.",
            file=sys.stderr,
        )


def load_remote_config(path: Path | str) -> RemoteConfig:
    # Single SoT for the bearer token: MASTER_AGENTS_API_TOKEN env var,
    # auto-loaded from vps/.env.production if present (same file the
    # home-server reads). Falls back to remote.yaml's `token` field for
    # legacy configs.
    # Lazy import: this module lives one package level below the
    # ``_paths`` helper, so the relative path is ``..`` (parent).
    from .._paths import load_platforms_env_files
    load_platforms_env_files()

    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(str(p))
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    token = os.environ.get("MASTER_AGENTS_API_TOKEN") or data.get("token", "")
    # E47 (2026-05-14) — load the optional `permissions:` block. None
    # if absent / null. The PermissionsConfig parser validates rule
    # syntax at construction time, so typos surface immediately
    # instead of silently failing to match later.
    permissions_raw = data.get("permissions")
    writable_paths_raw = data.get("writable_paths", ["."])
    if isinstance(permissions_raw, dict):
        # Coerce to the {"allow": [...], "deny": [...]} shape with
        # default-empty lists; persistence shape stays compact when
        # only one of allow/deny is non-empty.
        permissions = {
            "allow": list(permissions_raw.get("allow") or []),
            "deny": list(permissions_raw.get("deny") or []),
        }
    else:
        permissions = None
    # E47 deprecation path (one-cycle warning, per ROADMAP):
    # if the config has writable_paths but NO permissions block, emit
    # a one-time stderr deprecation note pointing the user at the
    # `permissions:` schema. The legacy enforcement still works;
    # we're just nudging migration. Suppressed when:
    #   - writable_paths is the default ["."] (no explicit setting)
    #   - permissions block already exists (already migrated)
    #   - MASTER_AGENTS_SUPPRESS_DEPRECATION_WARNINGS=1
    if (
        permissions is None
        and isinstance(writable_paths_raw, list)
        and list(writable_paths_raw) not in ([], ["."])
        and not os.environ.get("MASTER_AGENTS_SUPPRESS_DEPRECATION_WARNINGS")
    ):
        print(
            f"DeprecationWarning: {p} uses legacy `writable_paths:`. "
            "Migrate to `permissions: {allow: [...], deny: [...]}` per "
            "E47 (see the master-agents project CLAUDE.md). Legacy enforcement still "
            "works; new sessions get richer rules + deny patterns. "
            "Suppress this warning via "
            "MASTER_AGENTS_SUPPRESS_DEPRECATION_WARNINGS=1.",
            file=sys.stderr,
        )
    return RemoteConfig(
        server=data["server"],
        token=token,
        default_master=data.get("default_master"),
        cwd_mode=data.get("cwd_mode", "auto"),
        writable_paths=list(writable_paths_raw),
        permissions=permissions,
    )
