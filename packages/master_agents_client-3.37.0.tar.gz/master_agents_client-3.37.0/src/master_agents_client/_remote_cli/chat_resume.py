"""Session-resume + agent-capabilities helpers for `mao-client
remote chat`.

Phase 1 backlog item #5 (2026-05-16, v3.32.0): extracted from
`chat.py` to break a 2603-LoC file into focused sub-modules.

Four names live here — all "before the REPL starts" lifecycle:
  - `_fetch_agent_details(cfg, agent_name)` — fetch the current
    master's spec details from `GET /agents`.
  - `_print_capabilities(details, *, color)` — render the fetched
    capabilities block (model, tools clustered, allowed_subagents).
  - `_rehydrate_specific(client, session_id)` — rehydrate a specific
    persisted session by id (--resume <id> + --pick paths).
  - `_try_resume_active_session(client, current_server)` — attempt
    to adopt the cached active session for the current server
    (offer-to-resume Y/n prompt + Postgres-rehydrate fallback).

`RemoteSessionClient` is referenced as a forward type string to
avoid a module-load cycle — the runtime import lives only inside
`chat._cmd_remote_chat` (same pattern as `progress.py` /
`routine.py` / `run.py`).

Re-exported from `chat.py` for back-compat.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING, Any

import httpx

from .config import RemoteConfig
from .session_state import (
    _clear_active_session,
    _load_active_session,
    _save_active_session,
)

if TYPE_CHECKING:
    from ..remote_client import RemoteSessionClient


async def _fetch_agent_details(
    cfg: "RemoteConfig", agent_name: str,
) -> dict[str, Any] | None:
    """Fetch the current master's full spec details (description, tools,
    allowed_subagents, model) from GET /agents. Returns None if the
    server doesn't return details for the requested name (older server
    or filter mismatch)."""
    try:
        async with httpx.AsyncClient(base_url=cfg.server, timeout=10) as http:
            headers = (
                {"Authorization": f"Bearer {cfg.token}"} if cfg.token else {}
            )
            resp = await http.get("/agents", headers=headers)
            resp.raise_for_status()
            body = resp.json()
    except Exception as exc:
        sys.stderr.write(
            f"(could not fetch agent details: {type(exc).__name__}: {exc})\n"
        )
        sys.stderr.flush()
        return None
    for entry in body.get("details", []):
        if entry.get("name") == agent_name:
            return entry
    return None


def _print_capabilities(details: dict[str, Any], *, color: bool) -> None:
    """Render the current master's capabilities — model, channels, tools
    grouped, allowed_subagents — for the /capabilities slash command."""
    name = details.get("name", "?")
    description = details.get("description", "").strip()
    channels = details.get("channels") or ["all"]
    tools = sorted(details.get("tools", []))
    subagents = details.get("allowed_subagents", [])
    model = details.get("model", "?")

    def _dim(text: str) -> str:
        return f"\x1b[2m{text}\x1b[0m" if color else text

    def _bold(text: str) -> str:
        return f"\x1b[1m{text}\x1b[0m" if color else text

    print(_bold(f"agent: {name}") + _dim(f"  (model={model})"))
    if description:
        # First sentence of the description for a one-line teaser; the
        # full text is in the yaml if the user wants more.
        first_sentence = description.split(". ")[0].strip().rstrip(".")
        print(_dim(f"  {first_sentence}."))
    print(_dim(f"  channels: {', '.join(channels)}"))
    print()
    if tools:
        print(_bold(f"tools ({len(tools)}):"))
        # Group by prefix when there's a clear cluster (memory_*,
        # create_*, notebook_*); show the rest as flat list.
        clusters: dict[str, list[str]] = {}
        flat: list[str] = []
        for t in tools:
            for prefix in ("memory_", "create_", "notebook_", "scratchpad_"):
                if t.startswith(prefix):
                    clusters.setdefault(prefix.rstrip("_"), []).append(t)
                    break
            else:
                flat.append(t)
        for prefix in sorted(clusters):
            members = sorted(clusters[prefix])
            print(_dim(f"  {prefix}_*: {', '.join(m.removeprefix(prefix + '_') for m in members)}"))
        if flat:
            # Wrap to ~76 cols for readability.
            line = "  "
            for t in flat:
                if len(line) + len(t) + 2 > 76:
                    print(_dim(line.rstrip(", ")))
                    line = "  "
                line += t + ", "
            if line.strip() != "":
                print(_dim(line.rstrip(", ")))
    if subagents:
        print()
        print(_bold(f"can spawn ({len(subagents)}):"))
        print(_dim(f"  {', '.join(subagents)}"))
    print()


async def _rehydrate_specific(
    client: "RemoteSessionClient", session_id: str,
) -> str | None:
    """Rehydrate a specific persisted session by id.

    Used by --resume <id> and the --pick flow. Returns the resumed
    agent_name on success, or None if the server can't rehydrate (no
    Postgres, terminated session, unknown id, spec gone). Caller
    falls through to a fresh open() on None.
    """
    try:
        body = await client.rehydrate(session_id)
    except Exception as exc:
        sys.stderr.write(
            f"(could not rehydrate {session_id}: {type(exc).__name__}: "
            f"{exc}; starting fresh)\n"
        )
        sys.stderr.flush()
        return None
    msg_count = body.get("message_count", 0)
    new_id = body.get("session_id", "?")
    sys.stderr.write(
        f"(rehydrated session {session_id[:12]}… → {new_id[:12]}…: "
        f"{msg_count} messages restored)\n"
    )
    sys.stderr.flush()
    return body.get("agent_name")


async def _try_resume_active_session(
    client: "RemoteSessionClient", current_server: str,
) -> str | None:
    """Attempt to adopt the cached active session for `current_server`.

    Returns the agent_name of the resumed session on success (caller
    sets it as the master). Returns None when:
      - No cache file
      - Cache points at a different server (don't cross-contaminate)
      - User declines the resume offer
      - Both resume() and rehydrate() fail

    On a successful rehydrate the cache is rewritten with the new
    session_id so subsequent /detach + resume cycles stay coherent.
    """
    cached = _load_active_session()
    if cached is None:
        return None
    if cached.get("server") != current_server:
        return None
    session_id = cached.get("session_id")
    nonce = cached.get("session_nonce")
    agent_name = cached.get("agent_name")
    if not (session_id and nonce and agent_name):
        return None

    detached_at = cached.get("detached_at", "?")
    sys.stderr.write(
        f"Found a detached session: agent={agent_name}, "
        f"session_id={session_id[:12]}…, detached at {detached_at}.\n"
    )
    sys.stderr.flush()
    try:
        # Use the synchronous prompt — the resume question runs BEFORE
        # the chat loop's async prompt session; sys.stdin.isatty()
        # check keeps non-interactive callers (CI scripts) from hanging.
        if sys.stdin.isatty():
            try:
                raw = input("Resume? [Y/n]: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                return None
        else:
            raw = "y"
    except OSError:
        return None
    if raw and raw not in ("y", "yes"):
        _clear_active_session()
        return None

    # Try direct resume first (cheaper — no Postgres read, no new id).
    try:
        await client.resume(session_id, nonce)
        return agent_name
    except Exception:
        pass

    # Fallback: server idle-reaped the in-memory session. Rehydrate from
    # Postgres — returns a NEW session_id pre-loaded with prior history.
    try:
        body = await client.rehydrate(session_id)
    except Exception as exc:
        sys.stderr.write(
            f"(could not rehydrate prior session: {type(exc).__name__}: "
            f"{exc}; starting fresh)\n"
        )
        sys.stderr.flush()
        _clear_active_session()
        return None

    # Update cache with the new id so the next /detach saves the right one.
    new_id = body.get("session_id")
    new_nonce = body.get("session_nonce")
    if new_id and new_nonce:
        _save_active_session(
            server=current_server,
            agent_name=agent_name,
            session_id=new_id,
            nonce=new_nonce,
        )
    msg_count = body.get("message_count", 0)
    sys.stderr.write(
        f"(rehydrated from Postgres: {msg_count} messages restored, "
        f"new session_id={new_id[:12] if new_id else '?'}…)\n"
    )
    sys.stderr.flush()
    return agent_name
