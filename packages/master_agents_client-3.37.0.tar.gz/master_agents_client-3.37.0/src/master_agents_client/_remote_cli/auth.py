"""Authentication + master-agent resolution helpers for the
remote-CLI REPL -- extracted from `remote_cli.py` as Sprint 9c
(third slice of the Sprint 9 commands/repl/run decomposition).

Three names live here:
  - `_cmd_remote_login(args)` -- `mao-client remote login` handler.
    Captures the bearer token (interactive or --token flag), builds
    a RemoteConfig, saves it to ~/.master_agents/remote.yaml.
  - `_cmd_remote_logout(args)` -- `mao-client remote logout` handler.
    Removes the saved config file.
  - `_resolve_master(cfg, args, *, interactive)` -- resolve the
    master agent to dispatch against. Priority:
      1. --master/-m on the command line
      2. default_master in remote.yaml
      3. interactive picker against `GET /agents` (chat only)
      4. error message listing the server's agents.

All re-exported from `master_agents_client.remote_cli` via the facade.

Extraction history: Sprint 9c (informal; third slice of Sprint 9),
2026-05-16, branched off `v3.23.1` main tip. VERBATIM from
`remote_cli.py:314-430`.
"""

from __future__ import annotations

import getpass
import sys
from typing import Any

import httpx

from .config import RemoteConfig, save_remote_config
from .session_state import _config_path


def _cmd_remote_login(args: Any) -> int:
    token = args.token
    if token is None:
        if sys.stdin.isatty():
            token = getpass.getpass("Bearer token: ")
        else:
            print(
                "Error: --token required for non-interactive login.",
                file=sys.stderr,
            )
            return 2
    writable_paths = [p.strip() for p in args.writable_paths.split(",")] if args.writable_paths else ["."]
    cfg = RemoteConfig(
        server=args.server,
        token=token,
        default_master=args.default_master,
        cwd_mode="auto",
        writable_paths=writable_paths,
    )
    save_remote_config(_config_path(args), cfg)
    print(f"Logged in to {args.server}. Config: {_config_path(args)}")
    return 0


def _cmd_remote_logout(args: Any) -> int:
    path = _config_path(args)
    if path.exists():
        path.unlink()
        print(f"Removed {path}")
    else:
        print(f"(no config at {path})")
    return 0


async def _resolve_master(cfg: Any, args: Any, *, interactive: bool) -> str | None:
    """Resolve which master agent to use, in priority order:
    1. --master/-m on the command line
    2. default_master in remote.yaml
    3. interactive picker against live `GET /agents` (chat only)
    4. error message listing the server's agents
    """
    chosen = args.master or cfg.default_master
    if chosen:
        return chosen

    # Fetch the live list so we can either prompt or print useful options.
    try:
        async with httpx.AsyncClient(base_url=cfg.server, timeout=10) as http:
            headers = {"Authorization": f"Bearer {cfg.token}"} if cfg.token else {}
            # `?channel=cli` so the picker hides office-only / web-only
            # agents (assistant_office, excel_modeler, pptx_modeler,
            # assistant_web). Channel-agnostic agents (no `channels`
            # field on the spec) are returned for any channel.
            resp = await http.get(
                "/agents", headers=headers, params={"channel": "cli"},
            )
            resp.raise_for_status()
            agents = resp.json().get("agents", [])
    except Exception as exc:
        print(
            f"Error: no master agent specified, and failed to fetch /agents "
            f"to suggest options: {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        return None

    if not agents:
        print(
            "Error: no master agent specified and the server has none registered.",
            file=sys.stderr,
        )
        return None

    if interactive and sys.stdin.isatty():
        print("No master agent specified. Available agents on the server:")
        for i, name in enumerate(agents, 1):
            print(f"  [{i}] {name}")
        try:
            raw = input("Pick one by number or name (Enter for [1]): ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return None
        if not raw:
            return agents[0]
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(agents):
                return agents[idx]
            print(f"Error: pick must be between 1 and {len(agents)}.", file=sys.stderr)
            return None
        if raw in agents:
            return raw
        print(f"Error: {raw!r} is not in the server's agent list.", file=sys.stderr)
        return None

    print(
        "Error: no master agent specified. Pass --master / -m, or set "
        "default_master via `agents remote login --default-master <name>`.",
        file=sys.stderr,
    )
    # Gap-2 (J-O-02 UAT 2026-05-15): when the caller used --resume-last
    # WITHOUT --master, the message above is generic and doesn't explain
    # that --resume-last is per-master (each master has its own last-
    # session file in ~/.master_agents/last_session_<master>.json).
    # Surface the dependency so the operator knows what to add.
    if getattr(args, "resume_last", False):
        print(
            "  Note: --resume-last is scoped per-master (each master "
            "has its own last-session record). Pass --master / -m "
            "<name> alongside --resume-last to resume that master's "
            "most recent detached session.",
            file=sys.stderr,
        )
    print("Available agents on the server:", file=sys.stderr)
    for name in agents:
        print(f"  - {name}", file=sys.stderr)
    return None
