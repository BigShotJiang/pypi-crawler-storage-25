"""Configuration-path + session-id state helpers for the remote-CLI
REPL -- extracted from `remote_cli.py` as Sprint 9a (first slice
of the Sprint 9 commands/repl/run decomposition).

Six names live here:
  - `DEFAULT_REMOTE_CONFIG_PATH` -- constant for `~/.master_agents/
    remote.yaml`.
  - `_config_path(args)` -- resolve config path from argparse args
    (CLI `--config` override OR the default).
  - `parse_token_count(value)` -- parse a human-friendly token count
    string into an int (k/M suffixes, underscore separators).
  - `last_session_file_path(master, *, config_root=None)` -- compute
    the per-master last-detached-session-id file path.
  - `write_last_session_id(master, session_id, *, config_root=None)`
    -- persist a session-id to the per-master file.
  - `read_last_session_id(master, *, config_root=None)` -- read the
    per-master last-session id (or None if missing/empty).

All re-exported from `master_agents_client.remote_cli` via the facade
pattern.

Extraction history: Sprint 9a (informal; first slice of Sprint 9),
2026-05-16, branched off `v3.22.0` main tip. VERBATIM from
`remote_cli.py:94` (DEFAULT_REMOTE_CONFIG_PATH constant) +
`remote_cli.py:298-336` (parse helpers) + `remote_cli.py:339-380`
(session-id state file helpers).
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .._paths import master_agents_home


DEFAULT_REMOTE_CONFIG_PATH = master_agents_home() / "remote.yaml"
DEFAULT_ACTIVE_SESSION_PATH = master_agents_home() / "active_session.json"


def _save_active_session(
    *,
    server: str,
    agent_name: str,
    session_id: str,
    nonce: str,
    path: Path | str = DEFAULT_ACTIVE_SESSION_PATH,
) -> None:
    """Persist the just-detached session so the next agents remote chat
    invocation can offer to resume it. Stored as JSON under
    ~/.master_agents/active_session.json with chmod 0600 on POSIX."""
    from datetime import datetime, timezone

    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "server": server,
        "agent_name": agent_name,
        "session_id": session_id,
        "session_nonce": nonce,
        "detached_at": datetime.now(timezone.utc).isoformat(),
    }
    p.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    try:
        os.chmod(p, 0o600)
    except OSError:  # pragma: no cover
        pass


def _load_active_session(
    path: Path | str = DEFAULT_ACTIVE_SESSION_PATH,
) -> dict[str, Any] | None:
    """Read the cached active session, or None if no file exists or it's
    malformed. Returning None signals the chat REPL to start fresh."""
    p = Path(path)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _clear_active_session(
    path: Path | str = DEFAULT_ACTIVE_SESSION_PATH,
) -> None:
    """Remove the cache. Called on /exit (full destroy) and after the
    user declines a resume offer (so the prompt doesn't loop)."""
    p = Path(path)
    if p.exists():
        try:
            p.unlink()
        except OSError:  # pragma: no cover
            pass


def _config_path(args: Any) -> Path:
    return Path(args.config) if args.config else DEFAULT_REMOTE_CONFIG_PATH


# Phase 1 -- `mao-client remote run` flag helpers


_TOKEN_SUFFIXES: dict[str, int] = {"k": 1_000, "m": 1_000_000}


def parse_token_count(value: str) -> int:
    """Parse a human-friendly token count string into an int.

    Accepts:
      - plain integers: `100`, `100000`
      - underscore separators: `100_000`, `4_000_000`
      - k/M suffixes (case-insensitive): `100k`, `4M`, `1.5k`, `2.5M`

    Rejects everything else with ValueError so argparse surfaces a
    clean error instead of silently coercing.
    """
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"empty/invalid token count: {value!r}")
    s = value.strip().replace("_", "")
    multiplier = 1
    if s and s[-1].lower() in _TOKEN_SUFFIXES:
        multiplier = _TOKEN_SUFFIXES[s[-1].lower()]
        s = s[:-1]
    try:
        # Decimal multipliers like `1.5k` resolve to int via float math.
        n = float(s) * multiplier
    except ValueError as exc:
        raise ValueError(
            f"cannot parse token count {value!r}: not a number "
            f"(allowed suffixes: k, M; underscores OK)"
        ) from exc
    if n < 0:
        raise ValueError(f"token count must be non-negative; got {value!r}")
    return int(n)


def last_session_file_path(
    master: str, *, config_root: Path | None = None,
) -> Path:
    """Per-master file storing the last detached session id.

    Per-master scoping (one file per agent) prevents collisions when
    multiple chains run concurrently across different agents.

    Default config_root is `~/.master_agents/`. Tests pass a tmp_path
    to avoid touching the operator's real config.
    """
    root = (
        Path(config_root) if config_root is not None
        else Path.home() / ".master_agents"
    )
    safe_master = "".join(
        ch if (ch.isalnum() or ch in "-_") else "_" for ch in master
    )
    return root / f"last_session_{safe_master}.txt"


def write_last_session_id(
    master: str, session_id: str, *, config_root: Path | None = None,
) -> None:
    """Write `session_id` to the per-master last-session file. Creates
    parent directory if missing. Overwrites any prior id."""
    p = last_session_file_path(master, config_root=config_root)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(session_id.strip() + "\n", encoding="utf-8")


def read_last_session_id(
    master: str, *, config_root: Path | None = None,
) -> str | None:
    """Read the per-master last-session id. Returns None when the
    file is missing OR empty (operator hasn't detached anything for
    this master yet)."""
    p = last_session_file_path(master, config_root=config_root)
    if not p.exists():
        return None
    text = p.read_text(encoding="utf-8").strip()
    return text or None
