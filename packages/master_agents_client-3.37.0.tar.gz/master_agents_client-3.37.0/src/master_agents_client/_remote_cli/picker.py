"""Interactive session-picker helpers for the remote-CLI REPL —
extracted from `remote_cli.py` as the sixth sub-module of the
Phase 1 decomposition (per the addendum §3 Sprint 7 sub-module
6 of 6: "picker"). Closes Sprint 7's sub-module ledger.

Three names live here:
  - `_list_recent_sessions(cfg, *, limit=20)` — async; fetches
    persisted sessions from the server via `GET /sessions`.
    Returns an empty list on transport failure or no-Postgres
    backend.
  - `_format_age(epoch)` — sync; renders a unix timestamp as
    relative age suitable for the picker UI (`5m` / `2h` / `3d`).
  - `_pick_session(cfg)` — async; interactive picker. Returns
    the picked session dict or `None` if the user bails.

Re-exported from `master_agents_client.remote_cli` via the facade pattern.

Extraction history: Sprint 7 sub-module 6 (informal: Sprint 1f),
2026-05-16, branched off `v3.20.0` main tip. VERBATIM from
`remote_cli.py:1242-1318` via E83 verbatim passthrough at
`apply_edit_step`.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    from .config import RemoteConfig


async def _list_recent_sessions(
    cfg: "RemoteConfig", *, limit: int = 20,
) -> list[dict[str, Any]]:
    """Fetch recent persisted sessions from the server. Returns an empty
    list if the server has no Postgres backend or the request fails."""
    try:
        async with httpx.AsyncClient(base_url=cfg.server, timeout=10) as http:
            headers = (
                {"Authorization": f"Bearer {cfg.token}"} if cfg.token else {}
            )
            resp = await http.get(
                "/sessions", headers=headers, params={"limit": limit},
            )
            resp.raise_for_status()
            return list(resp.json().get("sessions", []))
    except Exception as exc:
        sys.stderr.write(
            f"(could not list sessions: {type(exc).__name__}: {exc})\n"
        )
        sys.stderr.flush()
        return []


def _format_age(epoch: float | int | None) -> str:
    """Render a unix timestamp as a relative age suitable for the
    picker -- `5m`, `2h`, `3d`. Returns `?` on missing/invalid input."""
    if not epoch:
        return "?"
    import time

    delta = max(0, int(time.time() - float(epoch)))
    if delta < 60:
        return f"{delta}s"
    if delta < 3600:
        return f"{delta // 60}m"
    if delta < 86400:
        return f"{delta // 3600}h"
    return f"{delta // 86400}d"


async def _pick_session(cfg: "RemoteConfig") -> dict[str, Any] | None:
    """Show an interactive picker of recent persisted sessions. Returns
    the picked session dict (with session_id + agent_name) or None if
    the user bails out. Server returns server-side metadata; the
    client doesn't have a nonce for arbitrary persisted sessions, so
    the caller MUST go through /rehydrate (which mints a fresh
    nonce) rather than direct resume."""
    sessions = await _list_recent_sessions(cfg, limit=20)
    if not sessions:
        sys.stderr.write(
            "(no persisted sessions on the server -- starting fresh)\n"
        )
        sys.stderr.flush()
        return None
    print(f"Recent sessions on {cfg.server}:")
    for i, s in enumerate(sessions, 1):
        sid = s.get("session_id", "?")
        agent = s.get("agent_name", "?")
        age = _format_age(s.get("last_activity_ts"))
        print(f"  [{i}] {sid[:16]}...  {agent:20s}  {age} ago")
    if not sys.stdin.isatty():
        return None
    try:
        raw = input("Pick one by number (Enter to start fresh): ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    if not raw:
        return None
    if not raw.isdigit():
        print("Not a number -- starting fresh.")
        return None
    idx = int(raw) - 1
    if not 0 <= idx < len(sessions):
        print("Out of range -- starting fresh.")
        return None
    return sessions[idx]
