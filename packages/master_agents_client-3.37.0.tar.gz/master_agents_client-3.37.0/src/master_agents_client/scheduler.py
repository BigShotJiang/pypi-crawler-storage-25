"""E49 — minimal scheduled-agent runner (v3.10.0, 2026-05-14).

Stores schedule definitions in ``~/.master_agents/schedules.yaml``
and fires them via two paths:

1. **Manual / cron-driven**: ``mao-client schedule run-all`` fires
   every schedule whose ``next_fire_ts`` is past. The intended
   deployment is a SYSTEM cron entry that calls ``run-all`` every
   N minutes (e.g. every 5 minutes via crontab on POSIX / Task
   Scheduler on Windows). No long-lived daemon required.
2. **Programmatic**: ``run_due_schedules()`` from Python for the
   in-process case (tests, future REPL integration).

Schedule shape
==============

::

    name: nightly-audit
    master: continuous_engineer
    prompt: "Audit yesterday's traces + flag drift."
    every: 1h            # interval-form: '5m', '1h', '24h', '7d'
    # OR
    at: "09:00"          # daily-fire-form: "HH:MM" 24h
    timezone: UTC        # optional; defaults to local
    last_fire_ts: <iso8601>   # set by the runner
    next_fire_ts: <iso8601>   # computed from every/at + last_fire_ts

Two scheduling forms — KEEP IT SIMPLE:

- ``every: <duration>`` — repeat at fixed interval. Duration grammar
  is ``Nm`` / ``Nh`` / ``Nd`` (minutes / hours / days).
- ``at: HH:MM`` — fire once per day at the local-time HH:MM.

Full crontab expressions (e.g. ``*/15 9-17 * * 1-5``) are
DELIBERATELY OUT OF SCOPE for the v3.10.0 minimum-viable. Most operator
needs are "every N hours" or "daily at 09:00" — either form is
sufficient. Croniter integration can land in a follow-up release if real
operator needs surface a more complex pattern.

Storage location
================

``~/.master_agents/schedules.yaml`` (alongside ``remote.yaml``).
Schema-versioned at top level so future format migrations don't
silently break user state.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import yaml

from ._paths import master_agents_home


SCHEDULES_FILENAME = "schedules.yaml"
SCHEMA_VERSION = 1


def _schedules_path() -> Path:
    return master_agents_home() / SCHEDULES_FILENAME


# Interval-form regex: e.g. ``5m`` / ``1h`` / ``24h`` / ``7d``.
_DURATION_RE = re.compile(r"^(\d+)([mhd])$")
# Daily-time-form regex: ``HH:MM`` 24-hour.
_TIME_RE = re.compile(r"^(\d{1,2}):(\d{2})$")


def parse_duration(s: str) -> timedelta:
    """Parse ``Nm`` / ``Nh`` / ``Nd`` → timedelta. Raises ValueError
    on anything else. Minutes / hours / days only — KEEP IT SIMPLE.
    """
    m = _DURATION_RE.match(s.strip())
    if not m:
        raise ValueError(
            f"invalid duration {s!r}; expected Nm / Nh / Nd "
            "(e.g. '5m', '1h', '24h', '7d')"
        )
    n = int(m.group(1))
    unit = m.group(2)
    if n <= 0:
        raise ValueError(f"duration must be positive; got {s!r}")
    if unit == "m":
        return timedelta(minutes=n)
    if unit == "h":
        return timedelta(hours=n)
    return timedelta(days=n)


def parse_daily_time(s: str) -> tuple[int, int]:
    """Parse ``HH:MM`` → ``(hour, minute)``. Validates 0-23 / 0-59."""
    m = _TIME_RE.match(s.strip())
    if not m:
        raise ValueError(
            f"invalid daily time {s!r}; expected HH:MM (e.g. '09:00')"
        )
    hour, minute = int(m.group(1)), int(m.group(2))
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        raise ValueError(
            f"daily time {s!r} out of range; HH must be 0-23, MM 0-59"
        )
    return hour, minute


@dataclass
class Schedule:
    """One scheduled agent invocation.

    Mutually-exclusive: exactly ONE of ``every`` / ``at`` must be set.
    The constructor doesn't enforce this (allows partial construction
    during YAML load); :meth:`validate` does.
    """
    name: str
    master: str
    prompt: str
    every: str | None = None      # "5m", "1h", "24h", "7d"
    at: str | None = None         # "HH:MM" (24h local time)
    last_fire_ts: str | None = None    # iso8601
    next_fire_ts: str | None = None    # iso8601

    def validate(self) -> None:
        """Raise ValueError if the schedule is malformed."""
        if not self.name or not isinstance(self.name, str):
            raise ValueError(f"schedule name required; got {self.name!r}")
        if not re.match(r"^[A-Za-z][A-Za-z0-9_-]{0,63}$", self.name):
            raise ValueError(
                f"schedule name {self.name!r} must match "
                "^[A-Za-z][A-Za-z0-9_-]{0,63}$"
            )
        if not self.master:
            raise ValueError("master agent name required")
        if not self.prompt:
            raise ValueError("prompt required")
        if (self.every is None) == (self.at is None):
            raise ValueError(
                "schedule must set EXACTLY ONE of `every` / `at`; "
                f"got every={self.every!r} at={self.at!r}"
            )
        if self.every is not None:
            parse_duration(self.every)  # validates format
        if self.at is not None:
            parse_daily_time(self.at)  # validates format

    def compute_next_fire(self, *, now: datetime | None = None) -> datetime:
        """Compute the next firing time given the schedule's spec
        and ``last_fire_ts``. ``now`` defaults to UTC now.

        For ``every: <duration>``, next fire = (last_fire OR now) + duration.
        For ``at: HH:MM``, next fire = next future occurrence of HH:MM
        in LOCAL time.
        """
        now = now if now is not None else datetime.now(timezone.utc)
        if self.every is not None:
            base = (
                datetime.fromisoformat(self.last_fire_ts)
                if self.last_fire_ts else now
            )
            return base + parse_duration(self.every)
        # at: HH:MM — find the next future occurrence in local time.
        assert self.at is not None  # validated
        hour, minute = parse_daily_time(self.at)
        local_now = now.astimezone()
        candidate = local_now.replace(
            hour=hour, minute=minute, second=0, microsecond=0,
        )
        if candidate <= local_now:
            candidate = candidate + timedelta(days=1)
        return candidate.astimezone(timezone.utc)


def load_schedules(path: Path | None = None) -> list[Schedule]:
    """Load ``schedules.yaml`` from ``~/.master_agents/`` (or the
    given override). Returns an empty list when the file doesn't
    exist — first-run case.
    """
    p = path or _schedules_path()
    if not p.exists():
        return []
    raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if not isinstance(raw, dict):
        return []
    schedules_raw = raw.get("schedules") or []
    out: list[Schedule] = []
    for entry in schedules_raw:
        if not isinstance(entry, dict):
            continue
        try:
            s = Schedule(
                name=entry.get("name", ""),
                master=entry.get("master", ""),
                prompt=entry.get("prompt", ""),
                every=entry.get("every"),
                at=entry.get("at"),
                last_fire_ts=entry.get("last_fire_ts"),
                next_fire_ts=entry.get("next_fire_ts"),
            )
            s.validate()
        except ValueError:
            # Skip malformed entries — they don't bring down the rest.
            continue
        out.append(s)
    return out


def save_schedules(schedules: list[Schedule], path: Path | None = None) -> None:
    """Persist schedules to ``schedules.yaml``. Stable key ordering
    so the file diff stays minimal across edits.
    """
    p = path or _schedules_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": SCHEMA_VERSION,
        "schedules": [
            {k: v for k, v in asdict(s).items() if v is not None}
            for s in schedules
        ],
    }
    p.write_text(
        yaml.safe_dump(payload, sort_keys=False, default_flow_style=False),
        encoding="utf-8",
    )


def add_schedule(schedule: Schedule, *, path: Path | None = None) -> None:
    """Add a schedule. Raises ValueError on name collision."""
    schedule.validate()
    existing = load_schedules(path)
    if any(s.name == schedule.name for s in existing):
        raise ValueError(
            f"schedule {schedule.name!r} already exists; "
            "remove it first or pick a different name"
        )
    if schedule.next_fire_ts is None:
        schedule.next_fire_ts = schedule.compute_next_fire().isoformat()
    existing.append(schedule)
    save_schedules(existing, path)


def remove_schedule(name: str, *, path: Path | None = None) -> bool:
    """Remove a schedule by name. Returns True if removed, False if
    no such schedule.
    """
    existing = load_schedules(path)
    filtered = [s for s in existing if s.name != name]
    if len(filtered) == len(existing):
        return False
    save_schedules(filtered, path)
    return True


def due_schedules(
    *,
    now: datetime | None = None,
    path: Path | None = None,
) -> list[Schedule]:
    """Return schedules whose ``next_fire_ts`` is ≤ ``now``.

    Computes next_fire on the fly for schedules missing it. Stable
    sorted by name so callers get deterministic firing order.
    """
    now = now if now is not None else datetime.now(timezone.utc)
    out: list[Schedule] = []
    for s in load_schedules(path):
        if s.next_fire_ts is None:
            s.next_fire_ts = s.compute_next_fire(now=now).isoformat()
        try:
            nft = datetime.fromisoformat(s.next_fire_ts)
        except ValueError:
            continue
        if nft <= now:
            out.append(s)
    out.sort(key=lambda s: s.name)
    return out


def mark_fired(
    name: str,
    *,
    fire_ts: datetime | None = None,
    path: Path | None = None,
) -> None:
    """Update a schedule's ``last_fire_ts`` to ``fire_ts`` and
    recompute ``next_fire_ts``. Called by ``run`` / ``run-all`` after
    successful dispatch so the schedule advances.
    """
    fire_ts = fire_ts if fire_ts is not None else datetime.now(timezone.utc)
    existing = load_schedules(path)
    for s in existing:
        if s.name == name:
            s.last_fire_ts = fire_ts.isoformat()
            s.next_fire_ts = s.compute_next_fire(now=fire_ts).isoformat()
            break
    save_schedules(existing, path)
