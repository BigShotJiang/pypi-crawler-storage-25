"""E47 — granular permission rules engine (2026-05-14).

Replaces the coarse ``writable_paths`` allowlist with structured
``permissions: {allow, deny}`` rules carrying Claude-Code-parity
``<ToolName>(<arg-pattern>)`` syntax. Stays CLIENT-SIDE: enforcement
fires in :class:`RemoteToolExecutor.execute` before the tool's
handler runs, so a deny rule blocks the call without ever touching
the user's filesystem.

The v3.7.0 ship is **allow + deny** only. The ``ask`` tier is deferred to
a follow-up — it interacts with the existing ``requires_approval``
flow in a way that needs more design space than this batch allows.

Grammar
=======

A rule is a string of one of these shapes:

- ``ToolName`` — matches the named tool regardless of arguments
  (e.g. ``"WebFetch"`` denies every WebFetch call).
- ``ToolName(<glob>)`` — for tools with a ``path`` arg
  (Write/Edit/Read/Append/MultiEdit/FileGrep/ListFiles): match against
  the resolved path using ``Path.match()`` glob semantics.
- ``ToolName(<prefix>:*)`` — for shell tools (Bash/PowerShell): match
  when the ``command`` arg starts with ``<prefix>``. The ``:*`` suffix
  is mandatory for command-line patterns and is what disambiguates
  prefix-match from glob-match.
- ``ToolName(<exact>)`` — exact-string match. Rare in practice.

Tool-name aliases follow Claude Code's UpperCase → snake_case
mapping (``Write`` → ``write_file``, ``Edit`` → ``edit_file``,
``Read`` → ``read_file``, ``MultiEdit`` → ``multi_edit``, etc.).
Unknown aliases pass through lowercased — match-time gate the call
against the live registry separately if you need strictness.

Examples
========

Project-rules whitelist (typical setup)::

    permissions:
      allow:
        - Write(./**)
        - Edit(./**)
        - MultiEdit(./**)
        - Append(./**)
        - Bash(git:*)
        - Bash(pip:*)
      deny:
        - Bash(rm -rf:*)
        - Bash(sudo:*)
        - Write(/etc/**)
        - Write(/usr/**)

Match algorithm
===============

For a tool call ``(name, args)``:

1. **Deny pass first** — walk every deny rule; if any matches, return
   ``deny`` with the rule string in the reason. Deny ALWAYS wins.
2. **Allow pass** — walk every allow rule; if any matches, return
   ``allow``.
3. **Default fallback** — return ``allow`` for back-compat with
   pre-E47 sessions (where the only gate was ``writable_paths``).
   Callers wanting strict "deny by default" combine an explicit
   ``allow:`` list with a deny catch-all (e.g. ``deny: [Bash]``).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import PurePath
from typing import Any, Literal


# Claude Code's UpperCase tool aliases → MAO's snake_case names in
# BUILTINS. This is the "common surface" — unknown UpperCase aliases
# pass through lowercased.
_TOOL_NAME_ALIASES: dict[str, str] = {
    "write": "write_file",
    "edit": "edit_file",
    "read": "read_file",
    "append": "append_file",
    "multiedit": "multi_edit",
    "multi_edit": "multi_edit",
    "filegrep": "file_grep",
    "file_grep": "file_grep",
    "listfiles": "list_files",
    "list_files": "list_files",
    "applypatch": "apply_patch",
    "apply_patch": "apply_patch",
    "bash": "bash",
    "powershell": "powershell",
    "pythonrun": "python_run",
    "python_run": "python_run",
    "pythoneval": "python_eval",
    "python_eval": "python_eval",
    "webfetch": "browser_fetch",
    "browser_fetch": "browser_fetch",
    "httpget": "http_get",
    "http_get": "http_get",
    "gitread": "git_read",
    "git_read": "git_read",
    "gitwrite": "git_write",
    "git_write": "git_write",
    "recallatom": "recall_atom",
    "recall_atom": "recall_atom",
}


# Rule string parser. Accepts ``ToolName`` or ``ToolName(<pattern>)``.
# The ``(`` group is greedy up to the final ``)`` so patterns
# containing parens (rare) survive — caller's responsibility to
# escape if it matters.
_RULE_RE = re.compile(r"^([A-Za-z][A-Za-z0-9_]*)(?:\((.*)\))?$")


def parse_rule(rule: str) -> tuple[str, str | None]:
    """Parse a rule string into ``(canonical_tool_name, pattern_or_None)``.

    Raises ``ValueError`` if the rule is malformed — empty, missing
    the close paren, or syntactically invalid otherwise. Strict-parse
    at config-load time catches typos before they become silent
    "rule never fires" mysteries.
    """
    if not isinstance(rule, str) or not rule.strip():
        raise ValueError(f"empty or non-string permission rule: {rule!r}")
    rule = rule.strip()
    # Reject obvious unclosed-paren forms before regex even sees them.
    if rule.count("(") != rule.count(")"):
        raise ValueError(
            f"unbalanced parentheses in permission rule: {rule!r}"
        )
    m = _RULE_RE.match(rule)
    if not m:
        raise ValueError(f"invalid permission rule syntax: {rule!r}")
    raw_name, pattern = m.group(1), m.group(2)
    canonical = _TOOL_NAME_ALIASES.get(raw_name.lower(), raw_name.lower())
    if pattern is not None and not pattern.strip():
        raise ValueError(
            f"permission rule {rule!r} has empty argument pattern"
        )
    return canonical, pattern


# --- match dispatch by tool name -----------------------------------------


def _match_path_pattern(pattern: str, path_value: Any) -> bool:
    """Glob-match a ``path`` argument against the rule's pattern.

    Uses ``PurePath.match`` for cross-platform glob semantics; falls
    back to substring match when the path arg isn't string-shaped
    (defensive — agents occasionally pass weird types).
    """
    if not isinstance(path_value, str):
        return False
    # PurePath.match expects the pattern AND the path to use the same
    # separator family. Normalize both to forward slashes — POSIX-style
    # globbing semantics regardless of host OS.
    p = PurePath(path_value.replace("\\", "/"))
    return p.match(pattern.replace("\\", "/"))


def _match_command_pattern(pattern: str, command_value: Any) -> bool:
    """Prefix-match a ``command`` argument against ``<prefix>:*`` form.

    Patterns without the ``:*`` suffix are treated as exact-match
    (rare but supported). The prefix is matched after stripping
    leading whitespace from the command — agents sometimes generate
    `"  git status"` with leading spaces.
    """
    if not isinstance(command_value, str):
        return False
    cmd = command_value.lstrip()
    if pattern.endswith(":*"):
        prefix = pattern[:-2].rstrip()
        return cmd.startswith(prefix)
    # Exact match (no `:*` suffix). Rare.
    return cmd == pattern


def _rule_matches(
    rule_name: str, rule_pattern: str | None,
    call_name: str, call_args: dict[str, Any],
) -> bool:
    """Return True iff a parsed rule matches a tool call.

    The match algorithm is tool-aware:
    - Bare ``ToolName`` (pattern is None) matches any call to that
      tool, regardless of args.
    - For path-bearing tools (Write/Edit/Read/Append/etc.), the
      pattern is treated as a glob and matched against
      ``call_args["path"]``.
    - For shell tools (Bash/PowerShell/python_run/etc.), the pattern
      is treated as prefix or exact and matched against
      ``call_args["command"]`` (or ``code`` for python_eval).
    - For any other tool, an explicit pattern requires
      ``call_args["arg"]`` exact match (rare).
    """
    if rule_name != call_name:
        return False
    if rule_pattern is None:
        return True  # bare tool name matches any args

    # Tool-name-aware arg selection.
    path_tools = {
        "write_file", "edit_file", "read_file", "append_file",
        "multi_edit", "file_grep", "list_files", "apply_patch",
        "create_md", "create_docx", "create_pptx", "create_xlsx",
        "create_pdf", "create_pptx_from_md", "render_chart",
        "pdf_read", "docx_read", "csv_read",
    }
    command_tools = {"bash", "powershell", "python_run", "python_eval",
                     "python_eval_sandboxed"}

    if call_name in path_tools:
        return _match_path_pattern(rule_pattern, call_args.get("path"))
    if call_name in command_tools:
        # python_eval uses `code` instead of `command`.
        cmd_key = "code" if call_name.startswith("python_eval") else "command"
        return _match_command_pattern(rule_pattern, call_args.get(cmd_key))
    # Unknown tool family: try a generic "first string arg" match.
    for value in call_args.values():
        if isinstance(value, str) and value == rule_pattern:
            return True
    return False


# --- PermissionsConfig + Verdict ----------------------------------------


PermissionAction = Literal["allow", "deny"]


@dataclass(frozen=True)
class PermissionVerdict:
    """Result of :meth:`PermissionsConfig.check`.

    ``reason`` is empty for allow verdicts (no message needed) and
    carries the matching rule string for deny verdicts so the trace
    + the user-facing error message both see WHY the call was blocked.
    """
    action: PermissionAction
    reason: str = ""


@dataclass
class PermissionsConfig:
    """Permission rules loaded from ``remote.yaml``'s ``permissions:``
    block.

    Use :meth:`from_yaml_dict` to load + parse rules at config-read
    time; the constructor accepts raw rule strings without parsing
    (test fixtures use it).
    """
    allow: list[str] = field(default_factory=list)
    deny: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        # Validate rules at construction so config-time typos surface
        # immediately. Parsing is cheap (one regex per rule), and we
        # only do it once per session.
        for r in (*self.allow, *self.deny):
            parse_rule(r)  # may raise ValueError

    def check(self, tool_name: str, tool_args: dict[str, Any]) -> PermissionVerdict:
        """Match a tool call against the rules; return a verdict."""
        canonical = _TOOL_NAME_ALIASES.get(tool_name.lower(), tool_name.lower())

        # Deny pass first — deny ALWAYS wins.
        for rule_str in self.deny:
            name, pattern = parse_rule(rule_str)
            if _rule_matches(name, pattern, canonical, tool_args):
                return PermissionVerdict(
                    action="deny",
                    reason=(
                        f"deny rule {rule_str!r} blocks {tool_name}("
                        + _summarize_args(tool_args) + ")"
                    ),
                )

        # Allow pass — first explicit match wins.
        for rule_str in self.allow:
            name, pattern = parse_rule(rule_str)
            if _rule_matches(name, pattern, canonical, tool_args):
                return PermissionVerdict(action="allow")

        # Fallback default: allow. Back-compat with pre-E47 sessions
        # (where the only gate was ``writable_paths``). For strict
        # "deny by default" posture, callers add a catch-all deny
        # rule (e.g. ``deny: [Bash, Write]``) at the end of the list.
        return PermissionVerdict(action="allow")

    def to_yaml_dict(self) -> dict[str, list[str]]:
        """Serialise to the dict shape ``remote.yaml`` stores."""
        return {"allow": list(self.allow), "deny": list(self.deny)}

    @classmethod
    def from_yaml_dict(cls, data: Any) -> "PermissionsConfig":
        """Load from the dict shape ``remote.yaml`` stores. Tolerates
        ``None`` (block absent / null) and missing keys (allow-only or
        deny-only configs)."""
        if not data or not isinstance(data, dict):
            return cls()
        allow = list(data.get("allow") or [])
        deny = list(data.get("deny") or [])
        return cls(allow=allow, deny=deny)


def _summarize_args(args: dict[str, Any]) -> str:
    """Human-readable args summary for verdict reasons. Used only for
    the deny-reason string; intentionally lossy so the message stays
    short."""
    if not args:
        return ""
    # Common single-arg shapes get a clean form.
    if "command" in args:
        cmd = args["command"]
        return f"command={cmd!r}" if isinstance(cmd, str) else "command=…"
    if "path" in args:
        return f"path={args['path']!r}"
    if "code" in args and isinstance(args["code"], str):
        return f"code={args['code'][:40]!r}…"
    keys = ", ".join(args.keys())
    return f"args=[{keys}]"


# --- Migration from legacy `writable_paths` ------------------------------


def rules_from_legacy_writable_paths(paths: list[str]) -> list[str]:
    """Generate ``allow`` rules from a legacy ``writable_paths`` list.

    Each path expands to four rules — one each for the path-bearing
    write tools (Write/Edit/MultiEdit/Append). Paths get a ``/**``
    suffix so subdirectories are covered (matching the prior
    ``writable_paths`` semantics where ``./src`` allowed writes to
    everything under it).

    Used by :class:`RemoteConfig` loaders that see a legacy config:
    in-memory migration logs a deprecation warning + the user can
    persist the migrated permissions via the eventual
    ``/permissions save`` command (post-v3.8.0 follow-up).
    """
    if not paths:
        return []
    write_tools = ("Write", "Edit", "MultiEdit", "Append")
    rules: list[str] = []
    for p in paths:
        # Strip trailing slash so the glob is well-formed.
        clean = p.rstrip("/\\")
        if not clean:
            clean = "."
        for tool in write_tools:
            rules.append(f"{tool}({clean}/**)")
    return rules
