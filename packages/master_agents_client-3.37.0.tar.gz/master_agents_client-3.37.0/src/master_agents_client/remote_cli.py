"""Remote CLI client — drives a home-server session from a workstation .

Three layers:
- `RemoteConfig` + `save_remote_config` / `load_remote_config`: YAML config at
  `~/.master_agents/remote.yaml`. chmod 0600 on POSIX at save time.
- `RemoteSessionClient`: httpx-based transport that runs a full turn, handling
  `needs_local_tool` SSE events by executing locally via `RemoteToolExecutor`
  and POSTing `/local_tool_result`.
- CLI `_cmd_remote`: wires `agents remote login/run/chat/logout` subcommands.
"""

from __future__ import annotations

import asyncio
import getpass
import json
import os
import sys
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

import httpx
import yaml

from ._paths import master_agents_home
from .remote_client import DEFAULT_CLIENT_SIDE_TOOLS, RemoteToolExecutor
from .tools import BUILTINS
from .tracer import ConsoleTracer, Tracer

# `_remote_cli` subpackage — Phase 1 god-module decomposition.
# All names re-exported here so external callers
#     from master_agents_client.remote_cli import RemoteConfig
# and internal call sites (~15+ scattered through this file) keep
# working unchanged via the facade pattern. Public-API-surface fixture
# (`packages/py/tests/test_public_api_surface.py`) pins RemoteConfig +
# load_remote_config + save_remote_config; underscore-prefixed names
# are private by convention but re-exported for internal call sites.
#
# Sprint history (per `docs/policy/DECOMPOSITION_PLAN_ADDENDUM_2026-05-15.md`):
# - Sprint 1a (2026-05-15) — `config.py`: RemoteConfig, save/load.
# - Sprint 1b (2026-05-15) — `sse.py`: _parse_sse_chunk.
# - Sprint 1c (2026-05-16) — `render.py`: 11 print/format helpers.
#                            Validated by E81 + E83 (verbatim_match
#                            auto-emit + apply_edit_step passthrough).
# - Sprint 1d+: prompts / client / picker / commands / repl / run.
#
# Facade-import consolidation (E85, 2026-05-16): single block per
# triangulation NIT #1. Prevents the "3 separate import lines today,
# 9 by Sprint 1i" growth path. New sub-module = add names here,
# keep alphabetical.
from ._remote_cli import (
    DEFAULT_ACTIVE_SESSION_PATH,
    DEFAULT_REMOTE_CONFIG_PATH,
    RemoteConfig,
    RemoteSessionClient,
    SessionEndedError,
    _BLUEPRINT_MARKERS,
    _BgTask,
    _CITATION_RE,
    _PLAN_SHAPED_AGENTS,
    _REMOTE_CHAT_HELP,
    _THIN_BRIEF_CHARS,
    _TOKEN_SUFFIXES,
    _build_headless_approval_callback,
    _clear_active_session,
    _cmd_remote_chat,
    _cmd_remote_login,
    _cmd_remote_logout,
    _cmd_remote_routine,
    _cmd_remote_run,
    _compute_display_timeout_s,
    _config_path,
    _defensive_kitty_disable,
    _draft_slot,
    _enable_kitty_keyboard_protocol,
    _execute_with_progress,
    _fetch_agent_details,
    _format_age,
    _format_cache_suffix,
    _format_cap_suffix,
    _format_cost_band_suffix,
    _format_ctx_suffix,
    _format_duration,
    _format_elapsed,
    _has_draft,
    _list_recent_sessions,
    _load_active_session,
    _make_prompt_reader,
    _parse_budget_arg,
    _parse_cap_arg,
    _parse_sse_chunk,
    _pending_default_slot,
    _pick_session,
    _print_agent_separator,
    _print_answer,
    _print_capabilities,
    _print_remote_token_line,
    _print_separator,
    _print_user_separator,
    _recall_draft,
    _rehydrate_specific,
    _resolve_master,
    _routine_run_all,
    _run_bg_task,
    _save_active_session,
    _save_draft,
    _set_pending_prompt_default,
    _summarise_tool_invocation,
    _surface_agent_question,
    _take_pending_prompt_default,
    _try_resume_active_session,
    detect_mode_a_brief,
    detect_no_phase5_emitted,
    format_mode_a_warning,
    last_session_file_path,
    load_remote_config,
    parse_token_count,
    read_last_session_id,
    save_remote_config,
    should_emit_mode_a_warning,
    write_last_session_id,
)




""


# NOTE: RemoteConfig, save_remote_config, load_remote_config moved to
# `_remote_cli/config.py` in Sprint 1a (2026-05-15). They are still
# importable from `master_agents_client.remote_cli` via the facade import at
# the top of this file — external callers (and the 6 internal call
# sites further below in this file) keep working unchanged.


# ---- CLI wiring ----


def _cmd_remote(args) -> int:
    if args.remote_command == "login":
        return _cmd_remote_login(args)
    if args.remote_command == "logout":
        return _cmd_remote_logout(args)
    if args.remote_command == "run":
        return asyncio.run(_cmd_remote_run(args))
    if args.remote_command == "chat":
        return asyncio.run(_cmd_remote_chat(args))
    if args.remote_command == "routine":
        return _cmd_remote_routine(args)
    return 2





