"""Built-in ``knowledge_search`` tool — unified Layer-2 retrieval across
all three knowledge corpora (K-F.4).

The three corpora retrieved here:

- **atoms** — user-curated markdown atom files (``MASTER_AGENTS_ATOM_CORPUS_DIR``).
  Per-atom themes from frontmatter; theme filter applies.
- **incidents** — ``INCIDENTS.md`` from the MAO repo (distilled mistakes).
  Section headings ``### I-NNN —`` anchor each entry.
- **patterns** — ``PATTERNS.md`` from the MAO repo (proven approaches).
  Section headings ``### P-NNN —`` anchor each entry.

ROLE — this tool is the **single retrieval surface** that subsumes
``recall_atom`` semantically. ``recall_atom`` stays available for
the atoms-only use case (smaller / cheaper output when the agent
knows the answer is in personal memory), but ``knowledge_search``
is the recommended default when the agent isn't sure which corpus
the answer lives in.

ROUTING — registered in ``DEFAULT_CLIENT_SIDE_TOOLS`` so it runs on
the user's machine. Two reasons:

1. The atom corpus lives only on the client (``~/.claude/projects/<hash>/memory/``).
   Server-side runs would see zero atoms.
2. INCIDENTS/PATTERNS live in the source repo. For editable installs
   the client auto-detects them; for wheel-only installs the user
   sets ``MASTER_AGENTS_KNOWLEDGE_DIR``.

OUTPUT FORMAT — three sections (atoms / patterns / incidents) in
that priority order. Each section uses the corpus_search-compatible
``<rel>:<line>: <content>`` citation format so downstream agents can
parse it with the same conventions for either tool.

DEGRADATION — if one corpus is unconfigured, the tool still runs
on the others and reports the unconfigured ones in the footer.
Only when ALL three are unconfigured (or all return zero hits) does
the tool return a single "not configured" / "no matches" message.

BYTE-STABILITY — output is deterministic given the corpora state
on disk. Same sort order as ``recall_atom``; same retrieval helper
(``atoms.grep_files_for_keywords``).
"""
from __future__ import annotations

import os
from pathlib import Path

from ..atoms import (
    apply_global_line_limit,
    discover_atom_files,
    extract_keywords,
    grep_files_for_keywords,
    list_atom_themes,
)
from ..knowledge import (
    resolve_incidents_path,
    resolve_patterns_path,
)
from .base import Tool


# Defaults — slightly more generous than ``recall_atom`` because
# knowledge_search retrieves across THREE corpora; a sensible
# session-injection budget is roughly the per-corpus cap × source
# count. The cap is still soft (the tool truncates rather than
# raises).
DEFAULT_LIMIT = 10
DEFAULT_MAX_TOTAL_CHARS = 24_000
DEFAULT_MAX_MATCHES_PER_KEYWORD = 12

_ATOM_CORPUS_ENV = "MASTER_AGENTS_ATOM_CORPUS_DIR"

# Source priority — atoms first (user's own curation is the most
# authoritative voice), then patterns (proven approaches), then
# incidents (lessons from mistakes). Matters when output is
# limit-truncated: the higher-priority sources keep their hits.
_SOURCE_ORDER: tuple[str, ...] = ("atoms", "patterns", "incidents")
_VALID_SOURCES: frozenset[str] = frozenset(_SOURCE_ORDER)


def _normalise_list(raw: list[str] | str | None) -> list[str]:
    """Tolerate either a list (canonical) or a scalar string (the LLM
    sometimes forgets the wrapping ``[ ]``). Empty / whitespace-only
    entries dropped.
    """
    if raw is None:
        return []
    if isinstance(raw, str):
        return [raw.strip()] if raw.strip() else []
    return [t.strip() for t in raw if isinstance(t, str) and t.strip()]


def _resolve_atom_dir() -> Path | None:
    """Resolve atom corpus dir from env. Returns None if unset OR if
    the env var points at a non-existent dir — both surface as a
    skipped-source note in the output, not an error.
    """
    raw = os.environ.get(_ATOM_CORPUS_ENV)
    if not raw:
        return None
    path = Path(raw).expanduser()
    return path if path.is_dir() else None


def _resolve_themes_to_atom_files(
    corpus_dir: Path, themes: list[str],
) -> tuple[list[Path], list[str]]:
    """Map themes → union of matching atom files. Same shape as the
    helper inside ``recall_atom`` so atoms-side behaviour stays
    identical across both tools.
    """
    if not themes:
        return discover_atom_files(corpus_dir), []
    index = list_atom_themes(corpus_dir)
    unknown: list[str] = []
    files: dict[Path, None] = {}
    for theme in themes:
        bucket = index.get(theme)
        if not bucket:
            unknown.append(theme)
            continue
        for path in bucket:
            files[path] = None
    return list(files), unknown


def _format_source_section(
    *,
    label: str,
    grouped: dict[Path, list[tuple[int, str]]],
    corpus_root: Path | None,
    truncated: bool,
) -> str:
    """Format one source's results into a ``<rel>:<line>: <content>``
    block, mirroring corpus_search's output convention. Caller is
    responsible for skipping the section when ``grouped`` is empty.
    """
    sections: list[str] = [f"### {label}"]
    for path, hits in grouped.items():
        if corpus_root is not None:
            try:
                rel: Path | str = path.relative_to(corpus_root)
            except ValueError:
                rel = path
        else:
            rel = path.name  # single-file corpora (INCIDENTS / PATTERNS)
        sections.append("```")
        for lineno, line in hits:
            sections.append(f"{rel}:{lineno}: {line}")
        sections.append("```")
    if truncated:
        sections.append(
            f"_…{label} section truncated at the char budget._"
        )
    return "\n".join(sections)


async def _knowledge_search_handler(
    *,
    intent: str,
    sources: list[str] | str | None = None,
    themes: list[str] | str | None = None,
    limit: int = DEFAULT_LIMIT,
) -> str:
    """Drive the actual multi-corpus retrieval. All wrappers funnel here."""
    # ---- input validation -------------------------------------------------
    if not isinstance(intent, str) or not intent.strip():
        return "knowledge_search: `intent` must be a non-empty string"

    keywords = extract_keywords(intent)
    if not keywords:
        return (
            f"knowledge_search: intent {intent!r} contained no content-"
            "bearing terms after stopword filtering. Try a more specific "
            "intent."
        )

    requested_sources = _normalise_list(sources)
    if not requested_sources:
        active_sources = list(_SOURCE_ORDER)
    else:
        # Reject unknown sources actionably rather than silently
        # ignoring — a typo in a spec opt-in shouldn't degrade to
        # "search nothing and return zero hits".
        bad = [s for s in requested_sources if s not in _VALID_SOURCES]
        if bad:
            return (
                f"knowledge_search: unknown source(s) {bad!r}. "
                f"Valid sources: {sorted(_VALID_SOURCES)}"
            )
        # Preserve priority order even if caller listed them out of
        # order — output stays byte-stable.
        active_sources = [s for s in _SOURCE_ORDER if s in requested_sources]

    theme_list = _normalise_themes_or_strings(themes)
    if theme_list and "atoms" not in active_sources:
        # Theme filter is atoms-only by design (INCIDENTS/PATTERNS
        # don't carry per-entry themes today). If caller scoped to
        # only patterns/incidents AND passed themes, that's a
        # contradiction we should surface — not silently ignore.
        return (
            "knowledge_search: `themes` filter only applies to the "
            "`atoms` source, but `atoms` is excluded from the active "
            "`sources` list. Either remove `themes` or include `atoms`."
        )

    # ---- per-source retrieval --------------------------------------------
    section_blocks: list[str] = []
    skipped_notes: list[str] = []
    hit_counts: dict[str, int] = {}
    per_source_budget = _per_source_char_budget(len(active_sources))

    if "atoms" in active_sources:
        block, note, hits = _search_atoms(
            keywords=keywords,
            themes=theme_list,
            per_call_chars=per_source_budget,
        )
        if block:
            section_blocks.append(block)
        if note:
            skipped_notes.append(note)
        hit_counts["atoms"] = hits

    if "patterns" in active_sources:
        block, note, hits = _search_single_file(
            label="patterns (PATTERNS.md)",
            file_path=resolve_patterns_path(),
            env_var="MASTER_AGENTS_KNOWLEDGE_DIR",
            keywords=keywords,
            per_call_chars=per_source_budget,
        )
        if block:
            section_blocks.append(block)
        if note:
            skipped_notes.append(note)
        hit_counts["patterns"] = hits

    if "incidents" in active_sources:
        block, note, hits = _search_single_file(
            label="incidents (INCIDENTS.md)",
            file_path=resolve_incidents_path(),
            env_var="MASTER_AGENTS_KNOWLEDGE_DIR",
            keywords=keywords,
            per_call_chars=per_source_budget,
        )
        if block:
            section_blocks.append(block)
        if note:
            skipped_notes.append(note)
        hit_counts["incidents"] = hits

    # ---- assemble + limit ------------------------------------------------
    total_hits = sum(hit_counts.values())
    if total_hits == 0:
        # Nothing matched. Combine actionable info: which sources were
        # searched vs skipped. The agent uses this to decide whether
        # to broaden the intent or fix configuration.
        searched = [s for s in active_sources if hit_counts.get(s, 0) >= 0
                    and s not in {n.split(":")[0].strip() for n in skipped_notes}]
        msg_parts = [
            f"knowledge_search: NO MATCHES for intent {intent!r} "
            f"(keywords: {', '.join(keywords)})."
        ]
        if searched:
            msg_parts.append(
                f"Searched sources: {sorted(searched)}."
            )
        if skipped_notes:
            msg_parts.append("Skipped: " + "; ".join(skipped_notes))
        msg_parts.append("Try a broader intent or different keywords.")
        return " ".join(msg_parts)

    # Header + summary block — byte-stable across calls for a given
    # corpora state.
    keywords_label = ", ".join(keywords)
    summary_bits = [
        f"{src} ({hit_counts[src]} hit{'s' if hit_counts[src] != 1 else ''})"
        for src in active_sources
        if hit_counts.get(src, 0) > 0
    ]
    header: list[str] = [
        f"## Retrieved knowledge (intent: {intent})",
        f"_Searched keywords: {keywords_label} — "
        f"{', '.join(summary_bits)}; {total_hits} match"
        f"{'es' if total_hits != 1 else ''} total._",
        "_Each line below is `<source-path>:<line>: <content>`. Cite "
        "the anchor verbatim. Read full context via "
        "`read_file(path=..., line=...)`._",
    ]
    if skipped_notes:
        header.append("_Skipped sources: " + "; ".join(skipped_notes) + "._")

    out = "\n".join(header + section_blocks)

    # Soft limit — applied at the line level after assembly so the
    # section/heading structure stays intact. Uses the same shared
    # `apply_global_line_limit` primitive recall_atom uses (atoms.py,
    # K-F.4 refactor) so the limit semantics are byte-identical.
    if limit is not None and isinstance(limit, int) and limit > 0:
        out = apply_global_line_limit(out, limit)

    return out


def _per_source_char_budget(num_active: int) -> int:
    """Divide the total char budget across active sources, with a
    minimum floor. A single-source call gets the full budget; a
    three-source call gets ~1/3 each, but each source still gets at
    least ``DEFAULT_MAX_TOTAL_CHARS // 4`` chars to keep results
    informative.
    """
    if num_active <= 0:
        return DEFAULT_MAX_TOTAL_CHARS
    fair_share = DEFAULT_MAX_TOTAL_CHARS // num_active
    floor = DEFAULT_MAX_TOTAL_CHARS // 4
    return max(fair_share, floor)


def _normalise_themes_or_strings(
    raw: list[str] | str | None,
) -> list[str]:
    """Same shape as _normalise_list — alias kept separate for clarity
    at call sites where the input semantics are 'list of themes'.
    """
    return _normalise_list(raw)


def _search_atoms(
    *,
    keywords: list[str],
    themes: list[str],
    per_call_chars: int,
) -> tuple[str, str, int]:
    """Search the atom corpus; returns ``(formatted_block, skip_note, hit_count)``.

    Skip note non-empty when the source was unconfigured / empty.
    Hit count is the number of (file, line) tuples emitted.
    """
    corpus_dir = _resolve_atom_dir()
    if corpus_dir is None:
        return "", (
            f"atoms: ${_ATOM_CORPUS_ENV} not set or path missing"
        ), 0

    files, unknown = _resolve_themes_to_atom_files(corpus_dir, themes)
    if themes and not files:
        return "", (
            f"atoms: no atom file matches theme(s) {unknown!r} "
            f"(available: {sorted(list_atom_themes(corpus_dir))})"
        ), 0
    if not files:
        return "", "atoms: corpus is empty (no atom files)", 0

    grouped, truncated = grep_files_for_keywords(
        files,
        keywords,
        max_matches_per_keyword=DEFAULT_MAX_MATCHES_PER_KEYWORD,
        max_total_chars=per_call_chars,
    )
    if not grouped:
        return "", "", 0
    hit_count = sum(len(v) for v in grouped.values())
    block = _format_source_section(
        label=f"atoms ({hit_count} hit{'s' if hit_count != 1 else ''})",
        grouped=grouped,
        corpus_root=corpus_dir,
        truncated=truncated,
    )
    return block, "", hit_count


def _search_single_file(
    *,
    label: str,
    file_path: Path | None,
    env_var: str,
    keywords: list[str],
    per_call_chars: int,
) -> tuple[str, str, int]:
    """Search a single-file corpus (INCIDENTS.md or PATTERNS.md).

    Returns ``(formatted_block, skip_note, hit_count)`` — same shape
    as ``_search_atoms`` so the caller's bookkeeping stays uniform.
    """
    if file_path is None:
        return "", (
            f"{label.split(' ')[0]}: ${env_var} not set and auto-detect "
            f"could not locate the file"
        ), 0
    grouped, truncated = grep_files_for_keywords(
        [file_path],
        keywords,
        max_matches_per_keyword=DEFAULT_MAX_MATCHES_PER_KEYWORD,
        max_total_chars=per_call_chars,
    )
    if not grouped:
        return "", "", 0
    hit_count = sum(len(v) for v in grouped.values())
    block = _format_source_section(
        label=f"{label.split(' ')[0]} ({hit_count} hit"
              f"{'s' if hit_count != 1 else ''})",
        grouped=grouped,
        corpus_root=None,
        truncated=truncated,
    )
    return block, "", hit_count


# --- public Tool definitions ------------------------------------------------


_DESCRIPTION = (
    "Unified knowledge retrieval across THREE corpora (K-F.4): "
    "(1) `atoms` — user-curated memory atoms (~/.claude/projects/"
    "<hash>/memory/), themable; (2) `patterns` — proven reusable "
    "patterns from MAO's PATTERNS.md; (3) `incidents` — distilled "
    "mistakes from MAO's INCIDENTS.md. Returns ranked results "
    "with source-tagged citations. Use when you're not sure which "
    "corpus carries the answer — atoms-only callers can still use "
    "`recall_atom` for the cheaper single-corpus path.\n"
    "\n"
    "USAGE:\n"
    "  knowledge_search(intent='byte-stable cache rule')\n"
    "  knowledge_search(intent='git discipline', sources=['atoms'])\n"
    "  knowledge_search(intent='fact vs advice', themes=['agent-discipline'])\n"
    "\n"
    "Themes filter applies to the `atoms` source only (INCIDENTS/"
    "PATTERNS don't carry per-entry themes today). Unconfigured "
    "corpora degrade gracefully — the tool still runs on the "
    "configured ones and reports the skipped sources in the footer."
)

_INPUT_SCHEMA: dict = {
    "type": "object",
    "required": ["intent"],
    "properties": {
        "intent": {
            "type": "string",
            "description": (
                "Free-text intent / question. Content-bearing terms "
                "are extracted heuristically; pass a phrase or a "
                "question, both work."
            ),
        },
        "sources": {
            "type": ["array", "string", "null"],
            "items": {"type": "string", "enum": list(_SOURCE_ORDER)},
            "description": (
                "Optional subset of sources to search. Valid values: "
                "'atoms', 'patterns', 'incidents'. Defaults to all "
                "three. Unknown values surface an actionable error."
            ),
        },
        "themes": {
            "type": ["array", "string", "null"],
            "items": {"type": "string"},
            "description": (
                "Optional theme filter (atoms source only). Unknown "
                "themes surface an actionable error listing the "
                "available themes."
            ),
        },
        "limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 100,
            "description": (
                "Max number of hit lines GLOBALLY across all sections "
                "(default 10). The char-budget caps still apply per-"
                "source independently."
            ),
        },
    },
}


async def _builtin_handler(
    intent: str,
    sources: list[str] | str | None = None,
    themes: list[str] | str | None = None,
    limit: int = DEFAULT_LIMIT,
) -> str:
    """BUILTIN handler — resolves all three corpora from env / auto-
    detect at call time so a long-lived process can be reconfigured
    without restart.
    """
    return await _knowledge_search_handler(
        intent=intent,
        sources=sources,
        themes=themes,
        limit=limit,
    )


knowledge_search = Tool(
    name="knowledge_search",
    description=_DESCRIPTION,
    input_schema=_INPUT_SCHEMA,
    handler=_builtin_handler,
    requires_approval=False,
    abortable=False,
    # E58 (2026-05-15) — owner-only: union of atoms (personal memory) +
    # INCIDENTS.md + PATTERNS.md (MAO's internal dev-history with
    # codenames, version anchors, customer-internal observations). Same
    # access-control rule as recall_atom.
    requires_admin=True,
)
"""Module-level BUILTIN — registered in ``tools/__init__.py`` BUILTINS
and ``remote_client.DEFAULT_CLIENT_SIDE_TOOLS``. Per-spec overrides
(custom corpora paths) aren't needed today because every consumer
points at the same project-wide corpora.
"""
