"""Built-in `render_chart` tool."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any
from uuid import uuid4

from .base import Tool


def _require_matplotlib():
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "render_chart requires the 'matplotlib' package. Install with: pip install master-agents-client[charts] (or [full])."
        ) from exc
    return plt


def _default_output_path() -> Path:
    base = Path("C:/Users/Thang/.codex/memories")
    if not base.exists():
        base = Path.cwd()
    return (base / f"chart-{uuid4().hex}.png").resolve()


def _render_chart_to_file(path: Path, spec: dict[str, Any]) -> str:
    plt = _require_matplotlib()
    chart_type = str(spec.get("type", "line"))
    title = str(spec.get("title", ""))
    x = spec.get("x", []) or []
    y = spec.get("y", []) or []
    xlabel = str(spec.get("xlabel", ""))
    ylabel = str(spec.get("ylabel", ""))
    color = spec.get("color")

    fig, ax = plt.subplots(figsize=(8, 4.5))
    if chart_type == "bar":
        ax.bar(x, y, color=color)
    elif chart_type == "scatter":
        ax.scatter(x, y, color=color)
    else:
        ax.plot(x, y, color=color)

    if title:
        ax.set_title(title)
    if xlabel:
        ax.set_xlabel(xlabel)
    if ylabel:
        ax.set_ylabel(ylabel)
    ax.grid(True, alpha=0.2)

    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, format="png", dpi=160)
    plt.close(fig)
    return f"Chart rendered to {path}"


async def _render_chart_handler(spec: dict[str, Any], path: str | None = None) -> str:
    if not isinstance(spec, dict):
        return "render_chart requires spec to be an object."
    target = Path(path).resolve() if path else _default_output_path()
    if target.suffix.lower() != ".png":
        return f"render_chart requires a .png path: {target}"
    try:
        return _render_chart_to_file(target, spec)
    except Exception as exc:
        return f"render_chart failed: {type(exc).__name__}: {exc}"


render_chart = Tool(
    name="render_chart",
    description=(
        "Render a chart to a PNG file from a structured spec. Supports line, "
        "bar, and scatter charts and returns the output path."
    ),
    input_schema={
        "type": "object",
        "required": ["spec"],
        "properties": {
            "spec": {
                "type": "object",
                "description": (
                    "Chart spec with type, x, y, optional title, labels, and color."
                ),
            },
            "path": {
                "type": "string",
                "description": (
                    "Optional destination .png path. If omitted, a temp-like path is generated."
                ),
            },
        },
    },
    handler=_render_chart_handler,
    channels=["cli"],
)
