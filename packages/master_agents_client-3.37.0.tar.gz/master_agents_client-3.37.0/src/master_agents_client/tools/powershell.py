r"""Built-in `powershell` tool — Windows-native PowerShell execution (E37, 2026-05-13).

Runs a PowerShell command on the *client's* machine (via tool inversion).
Sibling to `bash` for Windows-native commands that don't translate cleanly
to Git Bash / WSL bash:

  - Windows-native cmdlets: `Get-Command`, `Get-ChildItem`, `Get-Process`,
    `Get-Service`, `Get-EventLog`, etc.
  - COM / WMI access: `Get-WmiObject`, `Invoke-CimMethod`.
  - Registry: `Get-ItemProperty HKLM:\...`, `Get-PSDrive`.
  - .NET interop: `[System.X]::Method()` static calls.
  - Anything else where `cmd.exe /c` is too primitive AND WSL bash
    can't see the Windows-native data the agent needs.

Routing: client-side via tool inversion (same as `bash`). On non-Windows
clients this tool errors clean — it does NOT fall back to bash because
that would defeat the purpose (PowerShell-specific syntax wouldn't work).

E37 motivation: the 2026-05-13 capability-parity audit flagged that
the agent framework had no PowerShell sibling to bash. On
Windows-with-WSL the bash tool bridges
via WSL, and on Windows-without-WSL it falls back to cmd.exe. Neither
reaches Windows-native PowerShell, where most operator workflows live.
Without this tool, agents asked for `Get-Command python` had no path
to answer.

Shell invocation
----------------

  powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "..."

Flags chosen for non-interactive subprocess execution:
  -NoProfile         : skip user $PROFILE (faster startup, deterministic env)
  -NonInteractive    : reject Read-Host / Get-Credential prompts immediately
                       instead of hanging (matches our bash -lc tradeoff)
  -ExecutionPolicy Bypass : avoid AllSigned / RemoteSigned blocking the
                       inline -Command (we're not loading scripts)
  -Command           : run the literal string then exit (vs -File which
                       reads from a path)

Prefer `pwsh.exe` (PowerShell 7+, cross-platform Core) over
`powershell.exe` (Windows PowerShell 5.1) when available — PS 7 has
better PSReadLine + faster startup. Auto-select; users can override
via MAO_POWERSHELL_PATH.

Output handling
---------------

stdout and stderr captured + interleaved like bash. Output over
MAX_OUTPUT_BYTES truncated. Encoding: PS 5.1 defaults to UTF-16-LE on
Windows pipes; we force UTF-8 via `$OutputEncoding = [Text.Encoding]::UTF8`
prefix (otherwise Python's text-mode subprocess decode garbles).

Timeouts
--------

`timeout` in seconds, capped at MAX_TIMEOUT. On timeout the process is
killed; the tool returns a non-zero exit and partial output. No hung-
forever case.

CLI-channel only (same as bash). Web channel has no way to reach the
user's PowerShell.
"""

from __future__ import annotations

import asyncio
import os
import shutil
import sys
from pathlib import Path

from .base import Tool


# Hard caps. Same shape as bash.py for symmetry.
MAX_OUTPUT_BYTES = 100 * 1024     # 100 KB combined stdout+stderr
MAX_TIMEOUT = 600                  # 10 min absolute ceiling
DEFAULT_TIMEOUT = 60               # 60s default — most commands return fast

_POWERSHELL_OVERRIDE_ENV = "MAO_POWERSHELL_PATH"


def _is_windows() -> bool:
    return sys.platform == "win32"


def _resolve_powershell_path() -> str | None:
    """Locate the PowerShell executable on Windows.

    Resolution order:
    1. `MAO_POWERSHELL_PATH` env override — explicit operator wins.
    2. `pwsh` on PATH (PowerShell 7+, "Core") — faster + cross-platform.
    3. `powershell` on PATH (Windows PowerShell 5.1) — shipped with
       every Windows install since Win10.
    4. The standard absolute path `C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe`
       — last-resort fallback if PATH is corrupted.

    Returns None when not on Windows OR when no PowerShell is found
    (Windows-without-PS is theoretically possible on stripped-down
    Nano Server / IoT images; agent gets a clean error rather than
    a subprocess crash).
    """
    if not _is_windows():
        return None
    override = os.environ.get(_POWERSHELL_OVERRIDE_ENV, "").strip()
    if override:
        return override
    for candidate in ("pwsh", "powershell"):
        found = shutil.which(candidate)
        if found:
            return found
    fallback = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    if Path(fallback).exists():
        return fallback
    return None


def _build_argv(command: str) -> list[str] | None:
    """Build the powershell.exe argv. Returns None on non-Windows or
    when PowerShell isn't installed.

    Prefix the user's command with `$OutputEncoding = [Text.Encoding]::UTF8`
    so the pipe encoding matches what Python's text-mode subprocess
    decode expects. Without this, PS 5.1 emits UTF-16-LE on stdout and
    we'd see mojibake.
    """
    ps_path = _resolve_powershell_path()
    if ps_path is None:
        return None
    wrapped_command = (
        "$OutputEncoding = [System.Text.Encoding]::UTF8; "
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
        f"{command}"
    )
    return [
        ps_path,
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy", "Bypass",
        "-Command", wrapped_command,
    ]


def _truncate(blob: bytes, *, cap: int = MAX_OUTPUT_BYTES) -> str:
    """Decode + truncate combined output. Mirrors bash._truncate."""
    if len(blob) <= cap:
        return blob.decode("utf-8", errors="replace")
    head = blob[:cap].decode("utf-8", errors="replace")
    return f"{head}\n[...truncated {len(blob) - cap} bytes]"


async def _powershell_handler(
    command: str,
    *,
    cwd: str | None = None,
    timeout: float | int | None = None,
) -> str:
    """Run `command` via PowerShell on the host; return formatted result."""
    if not command or not command.strip():
        return "error: empty command"

    if not _is_windows():
        return (
            "error: powershell tool is Windows-only. On Linux / macOS use "
            "the `bash` tool instead. Detected platform: " + sys.platform
        )

    argv = _build_argv(command)
    if argv is None:
        return (
            "error: PowerShell not found on PATH and the standard "
            "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe "
            "doesn't exist either. Set MAO_POWERSHELL_PATH to the absolute "
            "path of pwsh.exe / powershell.exe if it's installed in a "
            "non-standard location."
        )

    secs = float(timeout if timeout is not None else DEFAULT_TIMEOUT)
    if secs <= 0 or secs > MAX_TIMEOUT:
        secs = min(max(secs, 1.0), float(MAX_TIMEOUT))

    from ._session_cwd import resolve_under_session_cwd, session_cwd_var
    if cwd:
        work_dir = resolve_under_session_cwd(cwd)
    else:
        work_dir = session_cwd_var.get() or Path.cwd()
    if not work_dir.is_dir():
        return f"error: cwd does not exist: {work_dir}"

    try:
        proc = await asyncio.create_subprocess_exec(
            *argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=str(work_dir),
            env=os.environ.copy(),
            # E38 lesson (2026-05-13): subprocess.run / create_subprocess
            # against Windows native binaries on non-TTY contexts can
            # hang on stdin reads. Pin stdin to DEVNULL.
            stdin=asyncio.subprocess.DEVNULL,
        )
    except FileNotFoundError as exc:
        return f"error: PowerShell not found ({exc})"
    except Exception as exc:
        return (
            f"error: failed to spawn PowerShell: "
            f"{type(exc).__name__}: {exc}"
        )

    try:
        stdout, _ = await asyncio.wait_for(
            proc.communicate(), timeout=secs,
        )
        rc = proc.returncode if proc.returncode is not None else -1
        body = _truncate(stdout or b"")
        return f"[exit {rc}] cwd={work_dir}\n{body}"
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except ProcessLookupError:
            pass
        try:
            stdout, _ = await asyncio.wait_for(
                proc.communicate(), timeout=2.0,
            )
        except asyncio.TimeoutError:
            stdout = b""
        body = _truncate(stdout or b"")
        return (
            f"[exit -1; timed out after {secs:.0f}s] cwd={work_dir}\n"
            f"{body}\n"
            f"[note: kill the long-running command or set a higher "
            f"'timeout']"
        )


powershell = Tool(
    name="powershell",
    description=(
        "Run a Windows PowerShell command on the local machine and return "
        "combined stdout+stderr with the exit code. CLI channel only — "
        "the web channel cannot reach this tool. Windows-only — errors "
        "cleanly on Linux / macOS clients.\n"
        "Use for: Windows-native cmdlets (Get-Command, Get-ChildItem, "
        "Get-Process), COM/WMI/CIM, registry access (HKLM:\\, HKCU:\\), "
        ".NET interop, and any Windows-specific workflow where `bash` "
        "(Git Bash / WSL / cmd.exe) doesn't reach the Windows-native "
        "data you need. For cross-platform shell work prefer `bash` — "
        "it auto-bridges via Git Bash or WSL on Windows.\n"
        "Shell selection: `pwsh.exe` (PowerShell 7+) if installed, "
        "else `powershell.exe` (Windows PowerShell 5.1 — shipped with "
        "every modern Windows install). Override via "
        "MAO_POWERSHELL_PATH env. Output is forced to UTF-8 and "
        "capped at 100 KB; default timeout 60s, max 600s."
    ),
    input_schema={
        "type": "object",
        "required": ["command"],
        "properties": {
            "command": {
                "type": "string",
                "description": (
                    "PowerShell command to execute. Full PowerShell "
                    "semantics: pipelines, variables ($var), cmdlets "
                    "(Verb-Noun), backtick line continuation, etc. "
                    "Multi-line commands work — use `;` to sequence "
                    "or newlines in a here-string."
                ),
            },
            "cwd": {
                "type": "string",
                "description": (
                    "Working directory for the command. Defaults to "
                    "the client's current directory."
                ),
            },
            "timeout": {
                "type": "number",
                "description": (
                    "Timeout in seconds (default 60, max 600). On "
                    "timeout the command is killed and partial output "
                    "returned."
                ),
                "minimum": 1,
                "maximum": MAX_TIMEOUT,
            },
        },
    },
    handler=_powershell_handler,
    requires_approval=True,   # Same as bash — destructive by default.
    abortable=False,
    channels=["cli"],
)
