"""Shared SSRF guard for tools that fetch arbitrary URLs on the web
channel.

Security F1 (audit 2026-05-12): tools like `http_get` and
`vision_describe.url` accepted any URL with `follow_redirects=True`,
allowing a web-channel LLM to fetch ``http://host.docker.internal:5432/``,
``http://169.254.169.254/...``, ``http://localhost:8000/admin/...``, etc.
The agent's tool call lands on the API container, so the container's
network namespace is the attack surface (Docker bridge to neighboring
services + WSL host services + cloud metadata).

This module provides a single validator that:
  - Rejects non-HTTP(S) schemes.
  - Rejects deny-listed hostnames (``host.docker.internal``,
    ``metadata.google.internal``, etc.).
  - Resolves the hostname's A/AAAA records and rejects if ANY result
    falls in a private/loopback/link-local/CGN/ULA CIDR. (Catches
    DNS-rebinding via multi-result records.)

CLI channel callers are exempt: the user's network is their trust
boundary — they can already curl localhost themselves, and the tool-
inversion bridge ships these tools to the user's machine via
``DEFAULT_CLIENT_SIDE_TOOLS`` (see ``remote_client.py``). The guard
fires only when the active session's channel is "web" (or "office").

For redirect-aware enforcement: callers must register
``_check_redirect_event_hook(channel)`` as an httpx response event
hook so the validator re-runs on every 3xx ``Location`` header,
closing the "fetch a public URL that 302s to ``http://169.254.169.254``"
gap.

A residual DNS-rebinding race exists between
``validate_outbound_url`` resolving the hostname and httpx resolving
it again at fetch time. Mitigation: callers should keep
``follow_redirects=True`` for legitimate redirects but register the
event hook. For v1, the deny-list + redirect re-check covers the
common case; the residual window is bounded by the private-CIDR
deny-list's coverage.
"""

from __future__ import annotations

import ipaddress
import socket
from typing import Awaitable, Callable
from urllib.parse import urlparse


# CIDR ranges that are NEVER appropriate for an LLM-driven fetch.
# RFC 1918 private, RFC 3927 link-local, RFC 6598 CGN, RFC 4193 IPv6
# ULA, loopback, multicast, broadcast.
_PRIVATE_NETS = [
    ipaddress.ip_network(n) for n in (
        "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16",
        "169.254.0.0/16",            # AWS / link-local
        "100.64.0.0/10",             # CGN
        "127.0.0.0/8", "::1/128",    # loopback
        "fc00::/7",                  # IPv6 ULA
        "fe80::/10",                 # IPv6 link-local
        "224.0.0.0/4",               # multicast
        "0.0.0.0/8",                 # this network
    )
]

# Hostnames the container should never reach via LLM-driven fetch,
# regardless of DNS resolution. Belt-and-braces with the CIDR check.
_DENY_HOSTS = frozenset({
    "host.docker.internal",
    "metadata.google.internal",
    "metadata",                      # GCE short form
    "localhost",
    "ip6-localhost",
    "ip6-loopback",
})

# Channels where the guard fires. CLI is the user's own machine and
# their network is their trust boundary — exempt by design.
_GUARDED_CHANNELS = frozenset({"web", "office"})


class UrlBlocked(Exception):
    """Raised when an outbound URL fails the SSRF allow-deny check."""


def validate_outbound_url(url: str, *, channel: str | None) -> None:
    """Raise ``UrlBlocked`` if ``url`` resolves to a target the
    web/office channel should not be allowed to fetch.

    Args:
        url: Full URL string (scheme + host + path).
        channel: Active session channel ("web" / "office" / "cli" /
            None). CLI sessions and unknown/None channels pass
            through unchecked — the bridge handles tool inversion
            for CLI, and unknown is taken as "not multi-tenant
            untrusted-LLM context".

    Raises:
        UrlBlocked: scheme is not http(s), or host is deny-listed,
            or DNS resolves to a private/loopback/link-local IP.
    """
    if channel not in _GUARDED_CHANNELS:
        return

    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise UrlBlocked(
            f"scheme {parsed.scheme!r} not allowed (only http / https)"
        )
    host = parsed.hostname
    if host is None:
        raise UrlBlocked("URL has no host")
    if host.lower() in _DENY_HOSTS:
        raise UrlBlocked(f"host {host!r} is deny-listed")

    # If the host literal is already an IP, check it directly. (Skips
    # the DNS resolution entirely — caller passed a numeric host.)
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        ip = None
    if ip is not None:
        _check_ip_against_private_nets(ip, host)
        return

    # Resolve every A/AAAA and check ALL of them — DNS-rebinding via
    # multi-result records is a real attack class.
    try:
        infos = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise UrlBlocked(
            f"DNS resolution failed for {host!r}: {exc}",
        ) from exc
    for *_unused, sockaddr in infos:
        addr = sockaddr[0]
        try:
            ip = ipaddress.ip_address(addr)
        except ValueError:
            continue
        _check_ip_against_private_nets(ip, host)


def _check_ip_against_private_nets(
    ip: ipaddress.IPv4Address | ipaddress.IPv6Address,
    host: str,
) -> None:
    for net in _PRIVATE_NETS:
        if ip.version == net.version and ip in net:
            raise UrlBlocked(
                f"host {host!r} resolves to private/blocked IP {ip} "
                f"(in {net})"
            )


def make_redirect_event_hook(
    channel: str | None,
) -> Callable[..., Awaitable[None]]:
    """Construct an httpx response event hook that re-validates the
    Location header on every 3xx response.

    Usage:
        async with httpx.AsyncClient(
            timeout=...,
            follow_redirects=True,
            event_hooks={"response": [make_redirect_event_hook(channel)]},
        ) as client:
            ...

    Without this hook, a public URL that returns a 302 to
    ``http://169.254.169.254/...`` would still SSRF, because httpx
    follows the redirect under the same client without re-running
    the upstream validator.
    """

    async def _hook(response):  # type: ignore[no-untyped-def]
        if 300 <= response.status_code < 400:
            location = response.headers.get("Location")
            if location:
                # Absolute URL only — httpx resolves relative redirects
                # itself; relative redirects can't change the host
                # so they can't introduce a new SSRF target.
                if "://" in location:
                    validate_outbound_url(location, channel=channel)

    return _hook
