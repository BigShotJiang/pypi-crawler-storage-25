"""Built-in ``webhook_post`` tool.5 generic-notification primitive.

Generic HTTP POST/PUT/PATCH to an arbitrary URL with a JSON body.
Use this for n8n / Zapier / IFTTT / custom-webhook integrations that
``slack_post`` doesn't cover. Discord webhooks, Pushover, Discord
embeds, custom alerting endpoints — all flow through here.

SHAPE — unlike ``slack_post`` (single-channel, env-var-only,
operator-secret URL), this tool takes the URL as a tool argument
because the URL is the **action target**, not a credential. The
agent decides where to post; the operator wires up the destination
in the agent spec (or via the env-var pattern the agent's prompt
suggests, e.g. ``$MY_N8N_HOOK``).

ROUTING — client-side. Two reasons:
1. User-supplied URLs may point at internal / VPN / corp-net hosts;
   firing from the user's namespace resolves them correctly.
2. The server's egress is restricted; arbitrary outbound POSTs
   would break SSRF policy if executed there.

FAILURE MODES — same defensive contract as ``slack_post``: every
failure returns an actionable string, never raises:
- invalid URL scheme (non-http/https) → rejected actionably
- network error → returns the error class + message
- HTTP 4xx/5xx → returns status + truncated response body
- single retry on 408/429/5xx (transient); operator-tunable timeout
"""
from __future__ import annotations

import json
from typing import Any
from urllib.parse import urlparse

import httpx

from .base import Tool


_DEFAULT_TIMEOUT = 10.0
_DEFAULT_METHOD = "POST"
_ALLOWED_METHODS = frozenset({"POST", "PUT", "PATCH"})
_RETRY_STATUSES = frozenset({408, 429, 500, 502, 503, 504})
_MAX_RESPONSE_BODY_CHARS = 500


def _validate_url(url: str) -> str | None:
    """Return None if the URL is acceptable, else an actionable error.

    Reject anything other than http/https — file://, gopher://, etc.
    have no legitimate notification use case and shipping them would
    hand the LLM a local-fs read primitive disguised as a notify call.
    Also reject empty / non-string inputs.
    """
    if not isinstance(url, str) or not url.strip():
        return "webhook_post: `url` must be a non-empty string"
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        return (
            f"webhook_post: URL scheme {parsed.scheme!r} not allowed "
            "(only http and https). Provided: " + url[:120]
        )
    if not parsed.netloc:
        return "webhook_post: URL is missing a host: " + url[:120]
    return None


def _validate_method(method: str) -> tuple[str | None, str]:
    """Normalise method to upper-case and validate. Returns
    ``(error_or_None, normalised_method)``.
    """
    if not isinstance(method, str) or not method.strip():
        return None, _DEFAULT_METHOD
    norm = method.strip().upper()
    if norm not in _ALLOWED_METHODS:
        return (
            f"webhook_post: method {method!r} not allowed (use POST / "
            f"PUT / PATCH; GET / DELETE etc. are out of scope for a "
            "notification tool)."
        ), norm
    return None, norm


def _format_response_body(text: str) -> str:
    """Truncate response body to ``_MAX_RESPONSE_BODY_CHARS`` with a
    visible ellipsis. Webhook receivers vary wildly in verbosity — some
    return HTML error pages, others empty bodies; capping protects the
    agent's context.
    """
    if not text:
        return ""
    body = text.strip()
    if len(body) > _MAX_RESPONSE_BODY_CHARS:
        return body[:_MAX_RESPONSE_BODY_CHARS] + "…[truncated]"
    return body


async def _send_request(
    *,
    url: str,
    method: str,
    payload: dict | list | str,
    headers: dict | None,
    timeout_seconds: float,
) -> str:
    """Send the request with one retry on transient failures. Returns
    a formatted result string — never raises.
    """
    if isinstance(payload, (dict, list)):
        body = json.dumps(payload).encode("utf-8")
        default_content_type = "application/json"
    else:
        body = str(payload).encode("utf-8")
        default_content_type = "text/plain; charset=utf-8"

    merged_headers = {"Content-Type": default_content_type}
    if headers:
        # Caller headers override the default (e.g., custom content-type
        # for form-encoded bodies, custom auth tokens).
        for k, v in headers.items():
            if isinstance(k, str) and v is not None:
                merged_headers[k] = str(v)

    last_error: str = ""
    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        for attempt in (1, 2):
            try:
                response = await client.request(
                    method, url, content=body, headers=merged_headers,
                )
            except httpx.HTTPError as exc:
                last_error = f"network error ({type(exc).__name__}): {exc}"
                if attempt == 1:
                    continue
                return f"webhook_post: FAILED after retry — {last_error}"

            if 200 <= response.status_code < 300:
                # Successful POSTs typically return small bodies (or
                # none). Include the body so the agent can extract any
                # IDs / confirmations the receiver returned.
                body_hint = _format_response_body(response.text or "")
                suffix = f" — {body_hint}" if body_hint else ""
                return (
                    f"webhook_post: HTTP {response.status_code}{suffix}"
                )

            text_body = _format_response_body(response.text or "")
            last_error = (
                f"HTTP {response.status_code}"
                + (f" — {text_body}" if text_body else "")
            )
            if response.status_code in _RETRY_STATUSES and attempt == 1:
                continue
            return f"webhook_post: FAILED — {last_error}"

    return f"webhook_post: FAILED — {last_error}"


async def _webhook_post_handler(
    url: str,
    payload: Any,
    headers: dict | None = None,
    method: str = _DEFAULT_METHOD,
    timeout_seconds: float = _DEFAULT_TIMEOUT,
) -> str:
    """Validate inputs and dispatch."""
    err = _validate_url(url)
    if err:
        return err

    method_err, normalised_method = _validate_method(method)
    if method_err:
        return method_err

    if payload is None:
        # Don't silently send empty body — almost always a bug.
        # Caller who wants no body can pass an empty dict / string.
        return (
            "webhook_post: `payload` must not be None. Pass {} for an "
            "empty JSON body, or '' for an empty plain-text body."
        )

    return await _send_request(
        url=url,
        method=normalised_method,
        payload=payload,
        headers=headers,
        timeout_seconds=timeout_seconds,
    )


_DESCRIPTION = (
    "Generic HTTP POST/PUT/PATCH to an arbitrary webhook URL with a "
    "JSON or text body. Use for n8n / Zapier / IFTTT / Discord "
    "webhooks / Pushover / custom alerting — anything that "
    "`slack_post` doesn't cover.\n"
    "\n"
    "URL is a tool ARGUMENT (the action target), not a credential. "
    "If the receiver requires auth, pass an `Authorization` header "
    "in `headers=`.\n"
    "\n"
    "USAGE:\n"
    "  webhook_post(url='https://discord.com/api/webhooks/.../...',\n"
    "               payload={'content': 'Backtest done'})\n"
    "  webhook_post(url='https://n8n.example/webhook/abc',\n"
    "               payload={'status': 'ok', 'rows': 42},\n"
    "               headers={'Authorization': 'Bearer ...'})\n"
    "\n"
    "Returns concise success/failure with status code + truncated "
    "response body. Single auto-retry on 408/429/5xx..5 "
    "notification primitive."
)

_INPUT_SCHEMA: dict = {
    "type": "object",
    "required": ["url", "payload"],
    "properties": {
        "url": {
            "type": "string",
            "description": (
                "Target webhook URL. Must be http or https; file:// "
                "and other schemes are rejected actionably."
            ),
        },
        "payload": {
            # dict, list, or string — JSON-encoded if structured, sent
            # as plain text otherwise.
            "description": (
                "Body to send. Dicts / lists are JSON-encoded with "
                "`Content-Type: application/json`. Strings are sent "
                "as `text/plain; charset=utf-8`. Pass {} for empty "
                "JSON body (don't pass None)."
            ),
        },
        "headers": {
            "type": ["object", "null"],
            "description": (
                "Optional additional headers (e.g. "
                "`{'Authorization': 'Bearer ...'}`). Overrides the "
                "default `Content-Type` if you set it explicitly."
            ),
        },
        "method": {
            "type": "string",
            "enum": ["POST", "PUT", "PATCH"],
            "description": (
                "HTTP method. Default POST. GET / DELETE / HEAD are "
                "out of scope for a notification tool — use other "
                "tools (e.g. `http_get`) for read flows."
            ),
        },
        "timeout_seconds": {
            "type": "number",
            "minimum": 1.0,
            "maximum": 60.0,
            "description": "Per-request timeout. Default 10s.",
        },
    },
}


webhook_post = Tool(
    name="webhook_post",
    description=_DESCRIPTION,
    input_schema=_INPUT_SCHEMA,
    handler=_webhook_post_handler,
    requires_approval=False,
    abortable=False,
    # E58 (2026-05-15) — owner-only: initiates outbound POST/PUT/PATCH
    # from the server's network namespace at the caller's discretion.
    # URL is a tool argument, so an external caller could direct the
    # server to POST anywhere it can reach (internal services / VPN
    # endpoints / cloud metadata). Admin-gated even though the URL
    # scheme guard already exists.
    requires_admin=True,
)
"""Module-level BUILTIN — registered in ``tools/__init__.py`` BUILTINS
and ``remote_client.DEFAULT_CLIENT_SIDE_TOOLS``. Client-side routing
fires the request from the user's network namespace, which is what
the agent's URL almost certainly refers to (internal n8n / VPN
endpoints / corp DNS).
"""
