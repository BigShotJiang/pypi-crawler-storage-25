"""Built-in `create_docx` tool.

Renders a structured JSON-like spec into a `.docx` file. The implementation
aims for a small, stable surface that an LLM can reliably target: title,
header/footer text, hierarchical sections, paragraphs, bullet lists, and
simple tables.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import Tool


def _require_docx():
    try:
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Inches, Pt, RGBColor
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "create_docx requires the 'python-docx' package. "
            "Install with: pip install master-agents-client[office] (or [full])."
        ) from exc
    return Document, WD_ALIGN_PARAGRAPH, Inches, Pt, RGBColor


def _add_image(
    document: Any,
    image_spec: dict[str, Any],
    *,
    Inches: Any,
) -> None:
    """Embed an image into the document.

    Spec fields:
      url | path | base64   one source (required)
      width_in              optional float, default 6.0 (fits A4 minus margins)
      align                 optional: 'left' | 'center' | 'right' (default center)
      caption               optional italic text under the image
    """
    import io
    from ._image_fetch import fetch_image_bytes
    raw, _ext = fetch_image_bytes(
        url=image_spec.get("url"),
        path=image_spec.get("path"),
        base64=image_spec.get("base64"),
    )
    width_in = float(image_spec.get("width_in", 6.0))
    width_in = max(0.5, min(width_in, 7.5))  # clamp to sane A4 range
    align = (image_spec.get("align") or "center").lower()

    # python-docx accepts a stream; saves us from writing a temp file.
    para = document.add_paragraph()
    run = para.add_run()
    run.add_picture(io.BytesIO(raw), width=Inches(width_in))
    if align == "left":
        para.alignment = 0
    elif align == "right":
        para.alignment = 2
    else:
        para.alignment = 1  # center

    caption = image_spec.get("caption")
    if isinstance(caption, str) and caption.strip():
        cap_para = document.add_paragraph(caption.strip())
        cap_para.alignment = 1
        for cap_run in cap_para.runs:
            cap_run.italic = True


def _rgb_from_hex(value: str | None, RGBColor: Any) -> Any | None:
    if not value:
        return None
    text = value.strip().lstrip("#")
    if len(text) != 6:
        return None
    try:
        return RGBColor.from_string(text.upper())
    except Exception:
        return None


def _apply_text_style(paragraph: Any, *, font_name: str | None, size_pt: int | None, Pt: Any) -> None:
    for run in paragraph.runs:
        if font_name:
            run.font.name = font_name
        if size_pt:
            run.font.size = Pt(size_pt)


def _add_bullets(document: Any, bullets: list[str], *, font_name: str | None, size_pt: int | None, Pt: Any) -> None:
    for bullet in bullets:
        para = document.add_paragraph(style="List Bullet")
        para.add_run(str(bullet))
        _apply_text_style(para, font_name=font_name, size_pt=size_pt, Pt=Pt)


def _add_table(document: Any, table_spec: dict[str, Any], *, font_name: str | None, size_pt: int | None, Pt: Any) -> None:
    columns = [str(c) for c in table_spec.get("columns", [])]
    rows = table_spec.get("rows", []) or []
    col_count = max(len(columns), max((len(r) for r in rows), default=0))
    if col_count == 0:
        return
    table = document.add_table(rows=1 if columns else 0, cols=col_count)
    table.style = "Table Grid"
    if columns:
        for idx, value in enumerate(columns):
            cell_para = table.rows[0].cells[idx].paragraphs[0]
            run = cell_para.add_run(value)
            run.bold = True
            _apply_text_style(cell_para, font_name=font_name, size_pt=size_pt, Pt=Pt)
    for row_values in rows:
        row = table.add_row()
        for idx, value in enumerate(row_values):
            cell_para = row.cells[idx].paragraphs[0]
            cell_para.add_run(str(value))
            _apply_text_style(cell_para, font_name=font_name, size_pt=size_pt, Pt=Pt)


def _render_section(
    document: Any,
    section: dict[str, Any],
    *,
    font_name: str | None,
    size_pt: int | None,
    heading_color: Any | None,
    Pt: Any,
    Inches: Any,
) -> None:
    heading = section.get("heading")
    level = int(section.get("level", 1) or 1)
    if heading:
        para = document.add_heading(str(heading), level=min(max(level, 1), 9))
        if heading_color is not None:
            for run in para.runs:
                run.font.color.rgb = heading_color
        _apply_text_style(para, font_name=font_name, size_pt=None, Pt=Pt)

    for paragraph in section.get("paragraphs", []) or []:
        para = document.add_paragraph(str(paragraph))
        _apply_text_style(para, font_name=font_name, size_pt=size_pt, Pt=Pt)

    bullets = section.get("bullets", []) or []
    _add_bullets(document, bullets, font_name=font_name, size_pt=size_pt, Pt=Pt)

    table_spec = section.get("table")
    if isinstance(table_spec, dict):
        _add_table(document, table_spec, font_name=font_name, size_pt=size_pt, Pt=Pt)

    image_spec = section.get("image")
    if isinstance(image_spec, dict):
        _add_image(document, image_spec, Inches=Inches)

    for child in section.get("children", []) or []:
        if isinstance(child, dict):
            _render_section(
                document,
                child,
                font_name=font_name,
                size_pt=size_pt,
                heading_color=heading_color,
                Pt=Pt,
                Inches=Inches,
            )


def _render_docx(path: Path, spec: dict[str, Any]) -> str:
    Document, WD_ALIGN_PARAGRAPH, Inches, Pt, RGBColor = _require_docx()
    document = Document()

    theme = spec.get("theme", {}) if isinstance(spec.get("theme"), dict) else {}
    font_name = theme.get("body_font")
    size_pt = theme.get("body_size_pt")
    heading_color = _rgb_from_hex(theme.get("heading_color"), RGBColor)

    core = document.core_properties
    if spec.get("title"):
        core.title = str(spec["title"])
        title_para = document.add_paragraph()
        title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        title_run = title_para.add_run(str(spec["title"]))
        title_run.bold = True
        title_run.font.size = Pt(20)
        if font_name:
            title_run.font.name = font_name
        if heading_color is not None:
            title_run.font.color.rgb = heading_color
    if spec.get("author"):
        core.author = str(spec["author"])

    header = spec.get("header", {})
    if isinstance(header, dict) and header.get("text"):
        para = document.sections[0].header.paragraphs[0]
        para.text = str(header["text"])

    footer = spec.get("footer", {})
    if isinstance(footer, dict) and footer.get("text"):
        para = document.sections[0].footer.paragraphs[0]
        para.text = str(footer["text"])

    for section in spec.get("sections", []) or []:
        if isinstance(section, dict):
            _render_section(
                document,
                section,
                font_name=font_name,
                size_pt=size_pt if isinstance(size_pt, int) else None,
                heading_color=heading_color,
                Pt=Pt,
                Inches=Inches,
            )

    path.parent.mkdir(parents=True, exist_ok=True)
    document.save(path)
    return f"DOCX created at {path}"


async def _create_docx_handler(path: str, spec: dict[str, Any]) -> str:
    from ._session_outputs import (
        download_url_for,
        resolve_create_target,
        session_id_var,
    )
    try:
        target, is_sandboxed = resolve_create_target(path)
    except ValueError as exc:
        return f"create_docx: {exc}"
    if target.suffix.lower() != ".docx":
        return f"create_docx requires a .docx path: {path}"
    if not isinstance(spec, dict):
        return "create_docx requires spec to be an object."
    try:
        result = _render_docx(target, spec)
    except Exception as exc:
        return f"create_docx failed for {path}: {type(exc).__name__}: {exc}"
    if is_sandboxed:
        sid = session_id_var.get()
        if sid is not None:
            result += f"\n\nDownload URL: {download_url_for(sid, target.name)}"
    return result


create_docx = Tool(
    name="create_docx",
    description=(
        "Create a formatted .docx document from a structured spec.\n"
        "\n"
        "Spec shape:\n"
        "  {\n"
        "    title?: str,            # bold centered title page\n"
        "    author?: str,           # core property\n"
        "    theme?: { body_font?, body_size_pt?, heading_color? },\n"
        "    header?: { text? },     # repeating page header\n"
        "    footer?: { text? },\n"
        "    sections: [\n"
        "      {\n"
        "        heading?: str, level?: 1-9,\n"
        "        paragraphs?: [str, ...],\n"
        "        bullets?: [str, ...],\n"
        "        table?: { columns: [str], rows: [[str, ...]] },\n"
        "        image?: {\n"
        "          # exactly one source:\n"
        "          url?: 'http(s)://...',  # tool fetches (5MB cap)\n"
        "          path?: '/local/path',\n"
        "          base64?: '...',\n"
        "          width_in?: 6.0,         # default 6\", clamps to 0.5-7.5\n"
        "          align?: 'center'|'left'|'right',\n"
        "          caption?: 'italic centered text below'\n"
        "        },\n"
        "        children?: [section, ...]\n"
        "      }\n"
        "    ]\n"
        "  }\n"
        "\n"
        "Order inside a section: heading, paragraphs, bullets, table, "
        "image, children. Use multiple sections to control layout."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "spec"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Destination .docx path to write.",
            },
            "spec": {
                "type": "object",
                "description": (
                    "Structured document spec — see tool description "
                    "for the full shape including image embedding."
                ),
            },
        },
    },
    handler=_create_docx_handler,
    requires_approval=True,
    channels=["cli", "web"],
)
