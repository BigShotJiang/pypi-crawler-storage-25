"""Built-in ``slack_post`` tool.5 notification primitive.

Posts a message to a Slack channel via an **incoming webhook URL**
configured as an operator secret in
``$MASTER_AGENTS_SLACK_WEBHOOK_URL``. The webhook URL determines the
target channel (pre-configured in the Slack app); the agent supplies
only the text + optional title.

WHY ENV-VAR-ONLY — the webhook URL is the credential that authorises
posting to the channel. Per the v3.12.0 design decision (Slack +
webhook only, env-vars-only secrets model), the URL never enters
LLM context; it's read at call time from the env var. Operators
set it once in their shell profile (or ``vps/.env.production``).

ROUTING — registered in ``DEFAULT_CLIENT_SIDE_TOOLS`` so the
webhook fires from the user's network namespace. This matters when:
- the user has VPN / corporate-network webhook destinations,
- the user's Slack workspace has IP allow-lists,
- the server container has restricted egress.

The server-side BUILTIN reads the env var at call time too; if a
spec runs server-side and the env var is set on the server, it
works there too. The tool degrades gracefully on missing env.

FAILURE MODES — every failure returns an actionable string (never
raises), so the agent can react and re-try with adjusted scope:
- env var unset → actionable "not configured" message
- HTTP non-200 from Slack → returns status + Slack's response body
- network error → returns the error class + message
- single retry on transient failures: 408 / 429 / 5xx **plus** any
  ``httpx.HTTPError`` (timeout / connect-refused / protocol errors)
- no retry on permanent 4xx (other than 408 / 429) — caller fixes
  payload / env var before re-firing

OUTPUT — concise success / failure string. Successful posts return
"slack_post: delivered to <channel-hint>"; failures explain what
the operator must fix.
"""
from __future__ import annotations

import json
import os

import httpx

from .base import Tool


_SLACK_WEBHOOK_ENV = "MASTER_AGENTS_SLACK_WEBHOOK_URL"
_DEFAULT_TIMEOUT = 10.0
_RETRY_STATUSES = frozenset({408, 429, 500, 502, 503, 504})


def _channel_hint_from_url(url: str) -> str:
    """Return a short non-secret hint about which webhook URL fired.

    Slack webhook URLs have the shape
    ``https://hooks.slack.com/services/Txxxxxxx/Byyyyyyy/<token>``.
    We return the team-id prefix ``T******`` (first 7 chars masked at
    char 2) so a multi-workspace operator can tell which workspace
    received the post — without leaking the token segment.
    """
    if "/services/" not in url:
        return "<webhook>"
    rest = url.split("/services/", 1)[1]
    parts = rest.split("/")
    if not parts:
        return "<webhook>"
    team = parts[0]
    # Minimum legitimate Slack team ID is 2 chars (`T` + at least one
    # alphanumeric). Anything shorter is malformed → fall back to the
    # safe sentinel rather than print `T*` or empty.
    if len(team) >= 2:
        return f"{team[:2]}{'*' * (len(team) - 2)}"
    return "<webhook>"


def _build_payload(text: str, title: str | None) -> dict:
    """Compose the Slack incoming-webhook JSON body.

    Simplest possible shape: a top-level ``text`` field with optional
    prepended title as bold Markdown. Slack's incoming webhooks
    accept this format universally — no Block Kit complexity, works
    on any workspace that has webhooks enabled at all.
    """
    if title and title.strip():
        body = f"*{title.strip()}*\n{text}"
    else:
        body = text
    return {"text": body}


async def _post_to_slack(
    *,
    url: str,
    payload: dict,
    timeout_seconds: float,
) -> str:
    """Single POST + one retry on a transient failure. Returns a
    formatted result string (success or actionable error) — never
    raises out of this function so the agent always gets a usable
    message.
    """
    body = json.dumps(payload).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    last_error: str = ""

    async with httpx.AsyncClient(timeout=timeout_seconds) as client:
        for attempt in (1, 2):
            try:
                response = await client.post(url, content=body, headers=headers)
            except httpx.HTTPError as exc:
                last_error = f"network error ({type(exc).__name__}): {exc}"
                if attempt == 1:
                    continue
                return f"slack_post: FAILED after retry — {last_error}"

            if response.status_code == 200:
                return (
                    f"slack_post: delivered to "
                    f"{_channel_hint_from_url(url)}"
                )

            # Slack returns plain text bodies for errors ("invalid_payload",
            # "channel_not_found", etc.). Truncate aggressively so a
            # verbose 4xx body doesn't blow up the agent's context.
            text_body = (response.text or "").strip()[:200]
            last_error = (
                f"HTTP {response.status_code}"
                + (f" — {text_body}" if text_body else "")
            )
            if response.status_code in _RETRY_STATUSES and attempt == 1:
                continue
            return f"slack_post: FAILED — {last_error}"

    # Defensive fall-through; the loop above always returns.
    return f"slack_post: FAILED — {last_error}"


async def _slack_post_handler(
    text: str,
    title: str | None = None,
    timeout_seconds: float = _DEFAULT_TIMEOUT,
) -> str:
    """Validate input, resolve env var, dispatch the POST. All
    wrappers funnel here.
    """
    if not isinstance(text, str) or not text.strip():
        return "slack_post: `text` must be a non-empty string"

    url = os.environ.get(_SLACK_WEBHOOK_ENV, "").strip()
    if not url:
        return (
            f"slack_post: not configured. Set ${_SLACK_WEBHOOK_ENV} on "
            "the machine running this tool (typically the client side) "
            "to a Slack incoming-webhook URL — see "
            "https://api.slack.com/messaging/webhooks for setup."
        )

    if not url.startswith("https://hooks.slack.com/"):
        # Soft guard — Slack webhooks always start with this prefix.
        # Don't hard-reject (some self-hosted Slack-compatible
        # endpoints exist), but warn the operator if the URL looks
        # wrong. The actual POST will fail clearly if the URL is
        # truly invalid.
        return (
            f"slack_post: ${_SLACK_WEBHOOK_ENV} does not look like a "
            "Slack webhook URL (expected prefix `https://hooks.slack.com/`). "
            "Verify the env var, then retry."
        )

    payload = _build_payload(text=text, title=title)
    return await _post_to_slack(
        url=url, payload=payload, timeout_seconds=timeout_seconds,
    )


_DESCRIPTION = (
    "Post a message to a Slack channel via incoming webhook. The "
    "channel + workspace are baked into the webhook URL "
    "(`$MASTER_AGENTS_SLACK_WEBHOOK_URL` on the machine running this "
    "tool — typically the client side); the agent supplies only the "
    "text + optional title.\n"
    "\n"
    "USAGE:\n"
    "  slack_post(text='Routine paper-drafter-poll completed: 3 hits')\n"
    "  slack_post(text='Backtest done', title='AlgoTrade nightly')\n"
    "\n"
    "Returns a concise success / failure string. Failures are "
    "actionable: env-unset cases name the env var; HTTP failures "
    "include Slack's response body..5 notification primitive."
)

_INPUT_SCHEMA: dict = {
    "type": "object",
    "required": ["text"],
    "properties": {
        "text": {
            "type": "string",
            "description": (
                "Message body. Slack mrkdwn supported (`*bold*`, "
                "`_italic_`, `` `code` ``, ```` ```block``` ````). "
                "Newlines are preserved."
            ),
        },
        "title": {
            "type": ["string", "null"],
            "description": (
                "Optional title prepended as bold on its own line. "
                "Useful for routine names / report subjects."
            ),
        },
        "timeout_seconds": {
            "type": "number",
            "minimum": 1.0,
            "maximum": 60.0,
            "description": (
                "Per-request timeout. Default 10s; raise only if your "
                "network has known slow paths to hooks.slack.com."
            ),
        },
    },
}


slack_post = Tool(
    name="slack_post",
    description=_DESCRIPTION,
    input_schema=_INPUT_SCHEMA,
    handler=_slack_post_handler,
    requires_approval=False,
    abortable=False,
    # E58 (2026-05-15) — owner-only: fires from operator-credentialed
    # webhook URL ($MASTER_AGENTS_SLACK_WEBHOOK_URL). Allowing a non-
    # admin caller to invoke this would let external customers blast
    # the operator's Slack channel.
    requires_admin=True,
)
"""Module-level BUILTIN — registered in ``tools/__init__.py`` BUILTINS
and ``remote_client.DEFAULT_CLIENT_SIDE_TOOLS``. Client-side routing
keeps the webhook URL (operator secret) on the user's machine and
fires the request from the user's network namespace (matters for VPN
/ corporate Slack workspaces with IP allow-lists).
"""
