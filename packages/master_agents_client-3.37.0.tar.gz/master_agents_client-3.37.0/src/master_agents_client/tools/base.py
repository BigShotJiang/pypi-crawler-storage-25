"""Tool primitive: name, description, JSON Schema for input, and async handler."""

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Any, Literal


@dataclass
class Tool:
    """MCP-compatible tool definition."""

    name: str
    description: str
    input_schema: dict
    handler: Callable[..., Awaitable[str]]
    source: Literal["builtin", "mcp"] = "builtin"
    requires_approval: bool = False
    untrusted_output: bool = False
    abortable: bool = False
    emit_output_in_trace: bool = False
    """If True, the tool's output string is included in the
    `tool_call_end` tracer event (and thus on the WS trace stream),
    capped at 64 KiB. Default False — generic tools (web_search,
    http_get, file_grep, RAG retrieval, etc.) MUST NOT leak raw
    results to WS subscribers; only structured envelope tools that
    explicitly opt in (excel_propose_ops, future office add-ins)
    set this. The runner gates the field on this flag in
    `Runner._execute_tool`."""
    tier: Literal["standard", "premium"] = "standard"
    """Service tier this tool belongs to. Premium tools require the
    an environment flag (or per-account entitlement) AND, for
    rendering tools, a reachable designer sidecar. Standard tools
    always run.

    Conventions:
      - `standard` (default) — content artifacts that look right out
        of the box without designer infrastructure: DOCX, XLSX,
        Markdown, plus all search / RAG / code / vision tools.
      - `premium` — visual-render artifacts that require designer
        infrastructure (Marp + Chromium for PPTX; LibreOffice for
        DOCX→PDF) and would otherwise produce off-brand output. We
        deliberately gate these to avoid shipping dirty versions to
        professional users on standard tier — the system says
        "premium feature" rather than producing something amateur.

    The gate runs in the agent loop BEFORE the handler is invoked;
    premium tools on standard tier never burn compute or attempt
    sidecar calls. See `the server's premium gate`.
    """

    requires_admin: bool = False
    """If True, the runner refuses to invoke this tool when the active
    auth context does not carry admin role. E58 (2026-05-15) — defence-
    in-depth for owner-only tools. The procedural rule (E57) is "wire
    these tools onto `tier: internal` agents only"; this flag is the
    structural backstop so a future spec author can't accidentally wire
    an owner-only tool into a `tier: free` / `tier: pro` agent.

    Conventions (set at module-level on the BUILTIN definition):
      - `False` (default) — runs for any caller. Use for tools whose
        content is not owner-private and whose side-effects are not
        operator-credentialed.
      - `True` — admin-only. Required when the tool either:
          (a) reads owner-private data (atom corpus, INCIDENTS.md,
              PATTERNS.md, owner's personal memory),
          (b) fires from an operator-side credential (Slack webhook URL,
              SMTP credentials, internal-API tokens),
          (c) initiates outbound network calls from the server's
              namespace at the caller's discretion (webhook_post).

    Gate-site: the service + the service tool-dispatch path checks
    `ctx.is_admin` against this flag; non-admin caller gets an
    actionable error rather than the tool running silently.
    """

    channels: list[str] | None = None
    """Which channels this tool may fire on. Single source of truth for
    server-side denial. Mirrors the agent-spec `channels:` discipline.

    Conventions:
      - `None` (default) — no restriction; tool runs on any channel.
        Use for pure-compute or read-only tools (read_file, calc,
        web_search, vision_describe, http_get, etc.).
      - `["cli"]` — CLI-only. Tool either mutates the local filesystem
        (write_file, edit_file, multi_edit, append_file, apply_patch,
        create_*, render_chart) or executes arbitrary code/shell on
        the server (bash, python_eval, python_eval_sandboxed,
        git_write). Server enforces this via session.client_channel
        check; the deny set is DERIVED from this field at import time
        (see `server._TOOLS_DENIED_ON_WEB`), never hand-maintained.
      - `["cli", "web"]` — explicit both-channel allow. Equivalent to
        `None` in current code; declare for documentation clarity if
        a tool reads files but is safe to expose on web (read_file,
        file_grep, estimate_tokens).
      - `["web"]` — web-only. Currently unused; reserved for tools
        that only make sense in the browser context.
    """
    """If True, the handler respects asyncio.CancelledError and the Runner
    may cancel in-flight tool tasks when the session is cancelled.

    If False (default), the tool runs to completion on cancellation but its
    result is discarded. Safer for tools that must not corrupt state
    mid-mutation (write_file, edit_file, create_*, memory_set, etc.).
    """

    async def execute(self, input_args: dict[str, Any]) -> str:
        return await self.handler(**input_args)
