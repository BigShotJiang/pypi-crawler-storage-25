"""Built-in `create_xlsx` tool — structured-spec xlsx generation via openpyxl."""

from __future__ import annotations

import re
from pathlib import Path

from .base import Tool

HEX_COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")
MAX_CELLS = 100_000


def _require_openpyxl():
    try:
        import openpyxl  # type: ignore
        from openpyxl.formatting.rule import CellIsRule  # type: ignore
        from openpyxl.styles import Alignment, Border, Fill, Font, PatternFill, Side  # type: ignore
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "create_xlsx requires the 'openpyxl' package. Install with: pip install master-agents-client[office] (or [full])."
        ) from exc
    return openpyxl, CellIsRule, Alignment, Border, Fill, Font, PatternFill, Side


def _validate_hex(name: str, value: str | None) -> str | None:
    """Return the uppercase 6-hex-digit string (without '#') or raise."""
    if value is None:
        return None
    if not isinstance(value, str) or not HEX_COLOR_RE.match(value):
        raise ValueError(
            f"create_xlsx: {name} must be a 6-hex-digit color like '#RRGGBB' (got {value!r})"
        )
    return value.lstrip("#").upper()


def _count_spec_cells(spec: dict) -> int:
    total = 0
    for sheet in spec.get("sheets", []):
        cols = len(sheet.get("columns", []) or [])
        rows = len(sheet.get("rows", []) or [])
        total += max(cols, 0) * max(rows, 0)
        total += cols  # header row
    return total


async def _create_xlsx_handler(path: str, spec: dict) -> str:
    # ---- Validate spec shape ----
    if not isinstance(spec, dict):
        return "create_xlsx: spec must be a JSON object"
    sheets = spec.get("sheets")
    if not isinstance(sheets, list) or not sheets:
        return "create_xlsx: spec.sheets must be a non-empty list"

    # Cell-count hard cap
    cell_count = _count_spec_cells(spec)
    if cell_count > MAX_CELLS:
        return (
            f"create_xlsx: spec exceeds {MAX_CELLS} cell limit ({cell_count}). "
            "Generate CSV and convert externally for data volumes this large."
        )

    # Duplicate sheet names
    names = [s.get("name", "") for s in sheets]
    if len(set(names)) != len(names):
        return f"create_xlsx: duplicate sheet names — each must be unique (got {names})"

    # Theme hex validation
    theme = spec.get("theme") or {}
    try:
        header_fill = _validate_hex("theme.header_fill_color", theme.get("header_fill_color"))
        header_font = _validate_hex("theme.header_font_color", theme.get("header_font_color"))
    except ValueError as exc:
        return str(exc)

    # Conditional formatting hex validation
    for sheet in sheets:
        for rule in sheet.get("conditional_formatting", []) or []:
            try:
                _validate_hex("conditional_formatting.fill_color", rule.get("fill_color"))
            except ValueError as exc:
                return str(exc)

    # ---- Render ----
    openpyxl, CellIsRule, Alignment, Border, Fill, Font, PatternFill, Side = _require_openpyxl()

    wb = openpyxl.Workbook()
    # openpyxl auto-creates a sheet called "Sheet"; remove it
    wb.remove(wb.active)

    header_bold = bool(theme.get("header_bold", False))
    body_font = theme.get("body_font")
    body_size_pt = theme.get("body_size_pt")

    for sheet in sheets:
        name = sheet.get("name") or "Sheet"
        ws = wb.create_sheet(title=name[:31])  # Excel's 31-char sheet name limit
        columns = sheet.get("columns") or []
        rows = sheet.get("rows") or []

        # Write header row
        for col_idx, col in enumerate(columns, start=1):
            cell = ws.cell(row=1, column=col_idx, value=col)
            if header_fill:
                cell.fill = PatternFill(
                    start_color=header_fill, end_color=header_fill, fill_type="solid"
                )
            font_kwargs = {}
            if header_bold:
                font_kwargs["bold"] = True
            if header_font:
                font_kwargs["color"] = header_font
            if body_font:
                font_kwargs["name"] = body_font
            if font_kwargs:
                cell.font = Font(**font_kwargs)

        # Write body rows
        for row_idx, row in enumerate(rows, start=2):
            for col_idx, value in enumerate(row, start=1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                if body_font or body_size_pt:
                    font_kwargs = {}
                    if body_font:
                        font_kwargs["name"] = body_font
                    if body_size_pt:
                        font_kwargs["size"] = body_size_pt
                    cell.font = Font(**font_kwargs)

        # Column widths
        widths = sheet.get("column_widths") or []
        for col_idx, width in enumerate(widths, start=1):
            if isinstance(width, (int, float)):
                ws.column_dimensions[
                    openpyxl.utils.get_column_letter(col_idx)
                ].width = width

        # Freeze header row
        if sheet.get("freeze_header_row"):
            ws.freeze_panes = "A2"

        # Conditional formatting
        for rule in sheet.get("conditional_formatting", []) or []:
            rng = rule.get("range")
            op = rule.get("operator")
            val = rule.get("value")
            fill_hex = rule.get("fill_color")
            if not (rng and op and val is not None and fill_hex):
                continue
            fill_color = fill_hex.lstrip("#").upper()
            ws.conditional_formatting.add(
                rng,
                CellIsRule(
                    operator=_normalize_operator(op),
                    formula=[str(val)],
                    stopIfTrue=False,
                    fill=PatternFill(
                        start_color=fill_color,
                        end_color=fill_color,
                        fill_type="solid",
                    ),
                ),
            )

    from ._session_outputs import (
        download_url_for,
        resolve_create_target,
        session_id_var,
    )
    try:
        p, is_sandboxed = resolve_create_target(path)
    except ValueError as exc:
        return f"create_xlsx: {exc}"
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        wb.save(str(p))
    except OSError as exc:
        return f"create_xlsx: {type(exc).__name__}: {exc}"

    result = f"Wrote xlsx: {p} ({len(sheets)} sheet(s), {cell_count} cell(s))"
    if is_sandboxed:
        sid = session_id_var.get()
        if sid is not None:
            result += f"\n\nDownload URL: {download_url_for(sid, p.name)}"
    return result


_OPERATOR_MAP = {
    ">": "greaterThan",
    "<": "lessThan",
    ">=": "greaterThanOrEqual",
    "<=": "lessThanOrEqual",
    "==": "equal",
    "!=": "notEqual",
}


def _normalize_operator(op: str) -> str:
    return _OPERATOR_MAP.get(op, op)


create_xlsx = Tool(
    name="create_xlsx",
    description=(
        "Generate an .xlsx (Excel) workbook from a structured JSON spec: "
        "multiple sheets, header styling, column widths, frozen header row, "
        "cell formulas (cells starting with '='), and conditional formatting. "
        "Out of scope: pivot tables, macros, embedded charts (use render_chart "
        "to PNG and embed via a future image-row slot). 100000-cell hard cap."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "spec"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Destination .xlsx path.",
            },
            "spec": {
                "type": "object",
                "description": (
                    "Workbook spec: {title?, theme?: {header_fill_color, "
                    "header_font_color, header_bold, body_font, body_size_pt}, "
                    "sheets: [{name, columns, rows, column_widths?, "
                    "freeze_header_row?, conditional_formatting?}]}"
                ),
            },
        },
    },
    handler=_create_xlsx_handler,
    requires_approval=True,
    channels=["cli", "web"],
)
