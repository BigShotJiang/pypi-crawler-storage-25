"""Built-in `write_file` tool."""

from __future__ import annotations

from pathlib import Path

from .base import Tool


def write_text_file(path: Path, content: str) -> str:
    # Atomic write — temp + fsync + replace. A Ctrl+C / OOM / power
    # loss between truncate and write completion on `Path.write_text`
    # would leave the file empty or partial, breaking the D2 resume
    # hash-divergence detection. See _session_file_state.atomic_write_bytes.
    from ._session_file_state import atomic_write_bytes
    atomic_write_bytes(path, content.encode("utf-8"))
    return f"Wrote {len(content)} chars to {path}"


async def _write_file_handler(path: str, content: str) -> str:
    import sys
    from .._self_host import is_self_hosted_repo, self_hosted_warning_for
    from ._python_smoke_check import python_smoke_check
    from ._session_cwd import resolve_under_session_cwd
    from ._session_file_state import check_can_edit, record_read
    target = resolve_under_session_cwd(path)
    # self-hosted load-bearing warning, mirrors edit_file.
    cwd = resolve_under_session_cwd(".")
    if is_self_hosted_repo(cwd):
        try:
            rel = target.resolve().relative_to(cwd.resolve())
            warning = self_hosted_warning_for(rel.as_posix())
        except ValueError:
            warning = None
        if warning:
            sys.stderr.write(warning + "\n")
            sys.stderr.flush()
    # A4-new: stale-content gate. write_file is overwrite-by-design,
    # but a session that wrote-then-someone-else-modified-then-wrote-
    # again could silently clobber external changes. The gate skips
    # the check when the file doesn't exist yet (write_file's primary
    # use case is creating new files); it gates only when the path
    # already exists, mirroring edit_file's protection.
    pre_existing_bytes: bytes | None = None
    if target.exists():
        rejection = check_can_edit(target)
        if rejection is not None:
            return f"write_file: {rejection}"
        # capture old content so we can revert if smoke fails.
        try:
            pre_existing_bytes = target.read_bytes()
        except OSError:
            pre_existing_bytes = None
    result = write_text_file(target, content)

    # post-write smoke-import check for Python source. On
    # failure: restore pre-existing bytes if file existed, else
    # delete the freshly-created file. Either way, return the
    # diagnostic to the agent so it can fix and retry.
    #
    # E80 (2026-05-15) — sharpen the revert message so the agent's
    # NEXT iter recognises that:
    #   (a) the file is NOT on disk (subsequent verify_function /
    #       verify_command runs will fail with "file not found"
    #       symptoms whose root cause is HERE, not there)
    #   (b) the fix must address the SMOKE-CHECK diagnostic shown
    #       below, not whatever spurious error the downstream
    #       verifier produces from the missing file
    # Captured by Sprint 1a coder_cli failure (bpxkzvjaa): the
    # original message ("Fix the issue and retry. Diagnostic:")
    # was clear enough for a human but the agent's iter_validator
    # was distracted by the downstream verify_function's spurious
    # SyntaxError. The new wording front-loads the upstream-cause
    # framing so iter_validator stays focused on the real cause.
    smoke_diag = python_smoke_check(target)
    if smoke_diag is not None:
        if pre_existing_bytes is not None:
            try:
                from ._session_file_state import atomic_write_bytes
                atomic_write_bytes(target, pre_existing_bytes)
            except OSError as e:
                return (
                    f"write_file: POST-WRITE SMOKE CHECK FAILED for "
                    f"{path} AND restore ALSO failed "
                    f"({type(e).__name__}: {e}). File is in an "
                    f"inconsistent state on disk. The diagnostic "
                    f"below is the ROOT CAUSE — fix it before retry. "
                    f"Any downstream 'file not found' or syntax error "
                    f"is a SYMPTOM, NOT the cause. Smoke check said:\n"
                    f"{smoke_diag}"
                )
        else:
            # Newly-created file — revert == delete.
            try:
                target.unlink()
            except OSError:
                pass
        return (
            f"write_file: POST-WRITE SMOKE CHECK FAILED. "
            f"FILE NOT WRITTEN (reverted: {path} does not exist "
            f"on disk). The diagnostic below is the ROOT CAUSE; "
            f"fix it before retrying. Any downstream 'file not "
            f"found' or spurious syntax error from a subsequent "
            f"verify step is a SYMPTOM of THIS failure, not the "
            f"cause. Address the smoke-check diagnostic below "
            f"DIRECTLY in your next write_file content (likely a "
            f"missing import, undefined name, or top-level "
            f"execution error). Diagnostic:\n{smoke_diag}"
        )

    # Record mtime so a follow-up edit_file/multi_edit on the same
    # path in this session doesn't trip the gate.
    record_read(target)
    return result


write_file = Tool(
    name="write_file",
    description=(
        "Create or overwrite a text file. Use when you need to produce a file "
        "artifact such as code, markdown, JSON, or a plain-text report."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "content"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Destination path to create or overwrite.",
            },
            "content": {
                "type": "string",
                "description": "Full text content to write.",
            },
        },
    },
    handler=_write_file_handler,
    requires_approval=True,
    channels=["cli"],
)
