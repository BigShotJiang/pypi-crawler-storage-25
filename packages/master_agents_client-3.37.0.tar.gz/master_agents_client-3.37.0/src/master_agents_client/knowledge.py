"""Knowledge corpora — INCIDENTS.md + PATTERNS.md path resolution (K-F.4).

The **knowledge corpora** are the curated MAO project docs that
accumulate distilled wisdom:

- ``INCIDENTS.md`` — append-only registry of things that went wrong.
  Each entry is an ``### I-NNN —`` H3-headed block documenting a real
  incident, its root cause, and the structural fix that closed it.
- ``PATTERNS.md`` — append-only registry of proven reusable patterns.
  Each entry is an ``### P-NNN —`` H3-headed block.

These complement the atom corpus (user's personal memory atoms) and
together with it form the EXPLOIT surface that the K-F.4
``knowledge_search`` tool retrieves across.

PATH RESOLUTION — the canonical knowledge dir is
``master_agents_os/docs/knowledge/`` in the source repo. We resolve
it in this priority:

1. ``$MASTER_AGENTS_KNOWLEDGE_DIR`` env var (explicit override) —
   the deterministic path for production / wheel installs.
2. Auto-detect by walking up from this module looking for a
   ``docs/knowledge/INCIDENTS.md`` marker. Works for editable
   installs (``pip install -e packages/py``) where an ancestor of
   this module's directory carries the ``docs/knowledge/`` tree.
3. None — actionable "not configured" error surfaces in the tool's
   response so the caller can fix it.

This module is pure-stdlib (no upward imports from tools/ or
runner). Both ``recall_atom`` and ``knowledge_search`` consume it.
"""
from __future__ import annotations

import os
from pathlib import Path

_KNOWLEDGE_DIR_ENV = "MASTER_AGENTS_KNOWLEDGE_DIR"
_INCIDENTS_FILENAME = "INCIDENTS.md"
_PATTERNS_FILENAME = "PATTERNS.md"


def resolve_knowledge_dir() -> Path | None:
    """Return the directory containing INCIDENTS.md + PATTERNS.md, or
    ``None`` if neither the env var nor auto-detect succeeds.

    Reads ``$MASTER_AGENTS_KNOWLEDGE_DIR`` EVERY call so long-lived
    processes (server, test runner) can be reconfigured without
    restart — same pattern as ``recall_atom``'s corpus dir.
    """
    raw = os.environ.get(_KNOWLEDGE_DIR_ENV)
    if raw:
        candidate = Path(raw).expanduser()
        if candidate.is_dir():
            return candidate
        # Env var set but points at nothing — fall through to auto-
        # detect so a typo in one shell doesn't kill the whole tool.
        # The "not configured" error will surface from the caller.
    return _autodetect_knowledge_dir()


def _autodetect_knowledge_dir() -> Path | None:
    """Walk up from this module's directory looking for a
    ``docs/knowledge/INCIDENTS.md`` marker. Returns the parent dir
    or None.

    For editable installs (``pip install -e packages/py``) this
    finds ``<repo>/docs/knowledge/``. For wheel-only installs the
    repo's docs/ tree isn't shipped, so this returns None and the
    user falls back to the env var path.
    """
    here = Path(__file__).resolve()
    # Cap the walk at 8 levels — repo roots are typically 3-5 levels
    # above source files; deeper means we've left the repo.
    for parent in [here.parent, *here.parents][:8]:
        candidate = parent / "docs" / "knowledge"
        if (candidate / _INCIDENTS_FILENAME).is_file():
            return candidate
    return None


def resolve_incidents_path() -> Path | None:
    """Path to INCIDENTS.md, or None if not resolvable."""
    base = resolve_knowledge_dir()
    if base is None:
        return None
    path = base / _INCIDENTS_FILENAME
    return path if path.is_file() else None


def resolve_patterns_path() -> Path | None:
    """Path to PATTERNS.md, or None if not resolvable."""
    base = resolve_knowledge_dir()
    if base is None:
        return None
    path = base / _PATTERNS_FILENAME
    return path if path.is_file() else None
