# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from fastvm import Fastvm, AsyncFastvm
from tests.utils import assert_matches_type
from fastvm.types.vms import Service, ServiceListResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestServices:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_update(self, client: Fastvm) -> None:
        service = client.vms.services.update(
            service_name="3-69",
            id="id",
            port=1024,
        )
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Fastvm) -> None:
        service = client.vms.services.update(
            service_name="3-69",
            id="id",
            port=1024,
            h2c=True,
        )
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Fastvm) -> None:
        response = client.vms.services.with_raw_response.update(
            service_name="3-69",
            id="id",
            port=1024,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        service = response.parse()
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Fastvm) -> None:
        with client.vms.services.with_streaming_response.update(
            service_name="3-69",
            id="id",
            port=1024,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            service = response.parse()
            assert_matches_type(Service, service, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Fastvm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.vms.services.with_raw_response.update(
                service_name="3-69",
                id="",
                port=1024,
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `service_name` but received ''"):
            client.vms.services.with_raw_response.update(
                service_name="",
                id="id",
                port=1024,
            )

    @parametrize
    def test_method_list(self, client: Fastvm) -> None:
        service = client.vms.services.list(
            "id",
        )
        assert_matches_type(ServiceListResponse, service, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Fastvm) -> None:
        response = client.vms.services.with_raw_response.list(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        service = response.parse()
        assert_matches_type(ServiceListResponse, service, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Fastvm) -> None:
        with client.vms.services.with_streaming_response.list(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            service = response.parse()
            assert_matches_type(ServiceListResponse, service, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Fastvm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.vms.services.with_raw_response.list(
                "",
            )

    @parametrize
    def test_method_delete(self, client: Fastvm) -> None:
        service = client.vms.services.delete(
            service_name="3-69",
            id="id",
        )
        assert service is None

    @parametrize
    def test_raw_response_delete(self, client: Fastvm) -> None:
        response = client.vms.services.with_raw_response.delete(
            service_name="3-69",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        service = response.parse()
        assert service is None

    @parametrize
    def test_streaming_response_delete(self, client: Fastvm) -> None:
        with client.vms.services.with_streaming_response.delete(
            service_name="3-69",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            service = response.parse()
            assert service is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Fastvm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.vms.services.with_raw_response.delete(
                service_name="3-69",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `service_name` but received ''"):
            client.vms.services.with_raw_response.delete(
                service_name="",
                id="id",
            )

    @parametrize
    def test_method_register(self, client: Fastvm) -> None:
        service = client.vms.services.register(
            id="id",
            name="name",
            port=1024,
        )
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    def test_method_register_with_all_params(self, client: Fastvm) -> None:
        service = client.vms.services.register(
            id="id",
            name="name",
            port=1024,
            h2c=True,
        )
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    def test_raw_response_register(self, client: Fastvm) -> None:
        response = client.vms.services.with_raw_response.register(
            id="id",
            name="name",
            port=1024,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        service = response.parse()
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    def test_streaming_response_register(self, client: Fastvm) -> None:
        with client.vms.services.with_streaming_response.register(
            id="id",
            name="name",
            port=1024,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            service = response.parse()
            assert_matches_type(Service, service, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_register(self, client: Fastvm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.vms.services.with_raw_response.register(
                id="",
                name="name",
                port=1024,
            )


class TestAsyncServices:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_update(self, async_client: AsyncFastvm) -> None:
        service = await async_client.vms.services.update(
            service_name="3-69",
            id="id",
            port=1024,
        )
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncFastvm) -> None:
        service = await async_client.vms.services.update(
            service_name="3-69",
            id="id",
            port=1024,
            h2c=True,
        )
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncFastvm) -> None:
        response = await async_client.vms.services.with_raw_response.update(
            service_name="3-69",
            id="id",
            port=1024,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        service = await response.parse()
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncFastvm) -> None:
        async with async_client.vms.services.with_streaming_response.update(
            service_name="3-69",
            id="id",
            port=1024,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            service = await response.parse()
            assert_matches_type(Service, service, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncFastvm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.vms.services.with_raw_response.update(
                service_name="3-69",
                id="",
                port=1024,
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `service_name` but received ''"):
            await async_client.vms.services.with_raw_response.update(
                service_name="",
                id="id",
                port=1024,
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncFastvm) -> None:
        service = await async_client.vms.services.list(
            "id",
        )
        assert_matches_type(ServiceListResponse, service, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncFastvm) -> None:
        response = await async_client.vms.services.with_raw_response.list(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        service = await response.parse()
        assert_matches_type(ServiceListResponse, service, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncFastvm) -> None:
        async with async_client.vms.services.with_streaming_response.list(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            service = await response.parse()
            assert_matches_type(ServiceListResponse, service, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncFastvm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.vms.services.with_raw_response.list(
                "",
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncFastvm) -> None:
        service = await async_client.vms.services.delete(
            service_name="3-69",
            id="id",
        )
        assert service is None

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncFastvm) -> None:
        response = await async_client.vms.services.with_raw_response.delete(
            service_name="3-69",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        service = await response.parse()
        assert service is None

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncFastvm) -> None:
        async with async_client.vms.services.with_streaming_response.delete(
            service_name="3-69",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            service = await response.parse()
            assert service is None

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncFastvm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.vms.services.with_raw_response.delete(
                service_name="3-69",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `service_name` but received ''"):
            await async_client.vms.services.with_raw_response.delete(
                service_name="",
                id="id",
            )

    @parametrize
    async def test_method_register(self, async_client: AsyncFastvm) -> None:
        service = await async_client.vms.services.register(
            id="id",
            name="name",
            port=1024,
        )
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    async def test_method_register_with_all_params(self, async_client: AsyncFastvm) -> None:
        service = await async_client.vms.services.register(
            id="id",
            name="name",
            port=1024,
            h2c=True,
        )
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    async def test_raw_response_register(self, async_client: AsyncFastvm) -> None:
        response = await async_client.vms.services.with_raw_response.register(
            id="id",
            name="name",
            port=1024,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        service = await response.parse()
        assert_matches_type(Service, service, path=["response"])

    @parametrize
    async def test_streaming_response_register(self, async_client: AsyncFastvm) -> None:
        async with async_client.vms.services.with_streaming_response.register(
            id="id",
            name="name",
            port=1024,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            service = await response.parse()
            assert_matches_type(Service, service, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_register(self, async_client: AsyncFastvm) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.vms.services.with_raw_response.register(
                id="",
                name="name",
                port=1024,
            )
