# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .shared_params.firewall_policy import FirewallPolicy

__all__ = ["VmLaunchParams", "Ttl"]


class VmLaunchParams(TypedDict, total=False):
    disk_gi_b: Annotated[int, PropertyInfo(alias="diskGiB")]
    """Override the default disk size (GiB)."""

    env_vars: Annotated[Dict[str, str], PropertyInfo(alias="envVars")]
    """
    Environment variable string→string map injected into the VM at boot. Keys must
    be 1–256 bytes and match shell-variable name (`[A-Za-z_][A-Za-z0-9_]*`); values
    may not contain newline, carriage return, or null bytes. Total JSON encoding
    ≤65536 bytes.
    """

    firewall: FirewallPolicy

    machine_type: Annotated[str, PropertyInfo(alias="machineType")]
    """Machine size identifier (e.g.

    `c1m2`, `c2m4`). Controls CPU and memory allocation. Must be supplied on launch
    unless restoring from a snapshot.
    """

    metadata: Dict[str, str]
    """Free-form string→string map.

    Server-enforced limits: up to 256 keys, key length 1–256 bytes, value length
    ≤4096 bytes, total JSON encoding ≤65536 bytes.
    """

    name: str
    """
    User-facing name (trimmed + whitespace-collapsed, max 64 runes after
    normalization; longer values are truncated server-side). Auto-generated as
    `vm-<8-char-id-prefix>` if empty.
    """

    snapshot_id: Annotated[str, PropertyInfo(alias="snapshotId")]
    """Snapshot ID to restore from."""

    ttl: Ttl
    """Per-VM auto-action timer.

    The cycle ticks down while the VM is `running` and freezes on pause. `seconds`
    is the original cycle duration; refresh and PATCH-time updates reset to this
    value.
    """


class Ttl(TypedDict, total=False):
    """Per-VM auto-action timer.

    The cycle ticks down while the VM is
    `running` and freezes on pause. `seconds` is the original cycle
    duration; refresh and PATCH-time updates reset to this value.
    """

    action: Required[Literal["pause", "delete"]]
    """Action taken on expiry.

    `pause` re-arms the cycle for the next running session; `delete` is terminal.
    """

    seconds: Required[int]
    """Cycle duration.

    Refresh resets to this value. Capped at 1 year (31536000s); larger values are
    rejected with 400.
    """
