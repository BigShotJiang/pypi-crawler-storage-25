# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Literal, Required, TypedDict

__all__ = ["VmUpdateParams", "Ttl"]


class VmUpdateParams(TypedDict, total=False):
    metadata: Dict[str, str]
    """Free-form string→string map.

    Server-enforced limits: up to 256 keys, key length 1–256 bytes, value length
    ≤4096 bytes, total JSON encoding ≤65536 bytes.
    """

    name: str

    ttl: Optional[Ttl]
    """Per-VM auto-action timer.

    The cycle ticks down while the VM is `running` and freezes on pause. `seconds`
    is the original cycle duration; refresh and PATCH-time updates reset to this
    value.
    """


class Ttl(TypedDict, total=False):
    """Per-VM auto-action timer.

    The cycle ticks down while the VM is
    `running` and freezes on pause. `seconds` is the original cycle
    duration; refresh and PATCH-time updates reset to this value.
    """

    action: Required[Literal["pause", "delete"]]
    """Action taken on expiry.

    `pause` re-arms the cycle for the next running session; `delete` is terminal.
    """

    seconds: Required[int]
    """Cycle duration.

    Refresh resets to this value. Capped at 1 year (31536000s); larger values are
    rejected with 400.
    """
