# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .shared.firewall_policy import FirewallPolicy

__all__ = ["Snapshot", "Service"]


class Service(BaseModel):
    """
    Captured (name, port, h2c) tuple for a single service
    registration on a snapshotted VM. Carried across snapshot/
    restore by `POST /v1/vms` (snapshot-restore branch) so the
    new VM gets the same service registrations the source VM
    had at snapshot time.
    """

    name: str

    port: int

    h2c: Optional[bool] = None


class Snapshot(BaseModel):
    id: str

    created_at: datetime = FieldInfo(alias="createdAt")

    name: str

    org_id: str = FieldInfo(alias="orgId")

    status: str
    """Snapshot lifecycle status.

    Known values: `creating`, `ready`, `error`. Additional values may be introduced
    in future server versions.
    """

    vm_id: str = FieldInfo(alias="vmId")

    env_vars: Optional[Dict[str, str]] = FieldInfo(alias="envVars", default=None)
    """
    Environment variable string→string map injected into the VM at boot. Keys must
    be 1–256 bytes and match shell-variable name (`[A-Za-z_][A-Za-z0-9_]*`); values
    may not contain newline, carriage return, or null bytes. Total JSON encoding
    ≤65536 bytes.
    """

    firewall: Optional[FirewallPolicy] = None

    metadata: Optional[Dict[str, str]] = None
    """Free-form string→string map.

    Server-enforced limits: up to 256 keys, key length 1–256 bytes, value length
    ≤4096 bytes, total JSON encoding ≤65536 bytes.
    """

    services: Optional[List[Service]] = None
    """Captured service registrations from the source VM at snapshot time."""
