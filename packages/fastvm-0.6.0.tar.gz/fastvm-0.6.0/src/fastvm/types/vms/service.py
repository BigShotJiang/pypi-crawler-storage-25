# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel

__all__ = ["Service"]


class Service(BaseModel):
    h2c: bool
    """When true, the proxy speaks HTTP/2 cleartext (h2c) to the backend.

    Required for gRPC and h2c-only apps. When false (default), the proxy uses
    HTTP/1.1 — covers HTTP/1.1 apps, Server-Sent Events, and WebSocket pass-through.
    """

    name: str
    """Service name (1–29 chars).

    Embedded in the public URL as `<name>--<vmIdHexNoHyphens>.proxy.<stack-domain>`.
    """

    port: int
    """TCP port the service listens on inside the VM.

    Privileged ports (<1024) are rejected.
    """
