# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ServiceUpdateParams"]


class ServiceUpdateParams(TypedDict, total=False):
    id: Required[str]

    port: Required[int]
    """New TCP port. Same value as the existing entry is a no-op."""

    h2c: bool
    """Optional.

    When true, the proxy uses HTTP/2 cleartext to the backend. Same value as the
    existing entry is a no-op; a different value updates the registered transport.
    """
