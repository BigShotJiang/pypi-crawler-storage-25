# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List
from typing_extensions import TypeAlias

from .service import Service

__all__ = ["ServiceListResponse"]

ServiceListResponse: TypeAlias = List[Service]
