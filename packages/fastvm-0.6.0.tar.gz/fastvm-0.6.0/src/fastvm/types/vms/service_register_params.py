# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["ServiceRegisterParams"]


class ServiceRegisterParams(TypedDict, total=False):
    name: Required[str]

    port: Required[int]

    h2c: bool
    """Optional.

    When true, the proxy uses HTTP/2 cleartext to the backend (required for gRPC).
    Defaults to false (HTTP/1.1).
    """
