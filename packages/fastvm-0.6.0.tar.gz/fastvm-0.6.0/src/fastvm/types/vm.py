# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .shared.firewall_policy import FirewallPolicy

__all__ = ["Vm", "Ttl"]


class Ttl(BaseModel):
    """Per-VM auto-action timer.

    The cycle ticks down while the VM is
    `running` and freezes on pause. `seconds` is the original cycle
    duration; refresh and PATCH-time updates reset to this value.
    """

    action: Literal["pause", "delete"]
    """Action taken on expiry.

    `pause` re-arms the cycle for the next running session; `delete` is terminal.
    """

    seconds: int
    """Cycle duration.

    Refresh resets to this value. Capped at 1 year (31536000s); larger values are
    rejected with 400.
    """


class Vm(BaseModel):
    id: str

    cpu: int

    created_at: datetime = FieldInfo(alias="createdAt")

    disk_gi_b: int = FieldInfo(alias="diskGiB")

    memory_mi_b: int = FieldInfo(alias="memoryMiB")

    name: str

    org_id: str = FieldInfo(alias="orgId")

    status: str
    """Lifecycle status.

    Known values: `provisioning`, `running`, `stopped`, `pausing`, `paused`,
    `resuming`, `deleting`, `error`. Terminal failure statuses are `error` and
    `stopped`; transitional values (`provisioning`, `pausing`, `resuming`,
    `deleting`) indicate the VM is in flight. Additional values may be introduced in
    future server versions; clients should treat unknown values as "in transition"
    rather than as hard errors.
    """

    deleted_at: Optional[datetime] = FieldInfo(alias="deletedAt", default=None)

    effective_firewall: Optional[FirewallPolicy] = FieldInfo(alias="effectiveFirewall", default=None)
    """
    Read-only composed view: `firewall` (the user policy) unioned with per-service
    auto-rules from this VM's registered services. Each auto-rule has source CIDR
    `::/0` and a `description` of the form `auto: proxy service <name>`. The same
    policy is what the worker firewall actually enforces. Set `firewall` to mutate;
    this field is computed per-response from `firewall` and the current service
    registry, never persisted.
    """

    env_vars: Optional[Dict[str, str]] = FieldInfo(alias="envVars", default=None)
    """
    Environment variable string→string map injected into the VM at boot. Keys must
    be 1–256 bytes and match shell-variable name (`[A-Za-z_][A-Za-z0-9_]*`); values
    may not contain newline, carriage return, or null bytes. Total JSON encoding
    ≤65536 bytes.
    """

    expires_at_ms: Optional[int] = FieldInfo(alias="expiresAtMs", default=None)
    """Absolute timestamp in ms when the TTL fires.

    Set only while the VM is `running` (the countdown freezes on pause).
    """

    firewall: Optional[FirewallPolicy] = None

    machine_name: Optional[str] = FieldInfo(alias="machineName", default=None)

    metadata: Optional[Dict[str, str]] = None
    """Free-form string→string map.

    Server-enforced limits: up to 256 keys, key length 1–256 bytes, value length
    ≤4096 bytes, total JSON encoding ≤65536 bytes.
    """

    paused_at: Optional[datetime] = FieldInfo(alias="pausedAt", default=None)
    """When the VM became paused; null otherwise."""

    public_ipv6: Optional[str] = FieldInfo(alias="publicIpv6", default=None)

    source_name: Optional[str] = FieldInfo(alias="sourceName", default=None)
    """Source snapshot or image name (empty on fresh boot)."""

    ttl: Optional[Ttl] = None
    """Per-VM auto-action timer.

    The cycle ticks down while the VM is `running` and freezes on pause. `seconds`
    is the original cycle duration; refresh and PATCH-time updates reset to this
    value.
    """

    ttl_remaining_ms: Optional[int] = FieldInfo(alias="ttlRemainingMs", default=None)
    """Remaining cycle budget in ms.

    Set only while the VM is paused; restored to `expiresAtMs` on resume.
    """
