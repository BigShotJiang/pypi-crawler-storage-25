# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["VmListParams"]


class VmListParams(TypedDict, total=False):
    status: str
    """Restrict to VMs with this status.

    Accepts any value of `VMStatus`; unknown values return an empty list.
    """
