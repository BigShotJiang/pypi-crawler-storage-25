# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from ..._utils import path_template, maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...types.vms import service_update_params, service_register_params
from ..._base_client import make_request_options
from ...types.vms.service import Service
from ...types.vms.service_list_response import ServiceListResponse

__all__ = ["ServicesResource", "AsyncServicesResource"]


class ServicesResource(SyncAPIResource):
    """Per-VM service registrations exposed via the public 4to6 HTTP proxy"""

    @cached_property
    def with_raw_response(self) -> ServicesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/fastvm-org/fastvm-sdk-python#accessing-raw-response-data-eg-headers
        """
        return ServicesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ServicesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/fastvm-org/fastvm-sdk-python#with_streaming_response
        """
        return ServicesResourceWithStreamingResponse(self)

    def update(
        self,
        service_name: str,
        *,
        id: str,
        port: int,
        h2c: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Service:
        """
        Idempotent register-or-update: same name + new port updates the port; same
        name + same port is a no-op. Returns the resulting entry. Used to change the
        upstream port for an existing service registration without dropping and
        re-creating it.

        Args:
          port: New TCP port. Same value as the existing entry is a no-op.

          h2c: Optional. When true, the proxy uses HTTP/2 cleartext to the backend. Same value
              as the existing entry is a no-op; a different value updates the registered
              transport.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not service_name:
            raise ValueError(f"Expected a non-empty value for `service_name` but received {service_name!r}")
        return self._put(
            path_template("/v1/vms/{id}/services/{service_name}", id=id, service_name=service_name),
            body=maybe_transform(
                {
                    "port": port,
                    "h2c": h2c,
                },
                service_update_params.ServiceUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Service,
        )

    def list(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ServiceListResponse:
        """Returns the services currently registered on this VM, sorted by name.

        Each
        service is exposed at `https://<name>--<vmIdHexNoHyphens>.proxy.<stack-domain>`
        over HTTPS.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v1/vms/{id}/services", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ServiceListResponse,
        )

    def delete(
        self,
        service_name: str,
        *,
        id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Idempotent: deleting a service that doesn't exist returns 204.

        Removes the
        firewall auto-rule synchronously; the proxy stops routing to the service within
        seconds (cache invalidation broadcast; 30s TTL is the safety net).

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not service_name:
            raise ValueError(f"Expected a non-empty value for `service_name` but received {service_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            path_template("/v1/vms/{id}/services/{service_name}", id=id, service_name=service_name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    def register(
        self,
        id: str,
        *,
        name: str,
        port: int,
        h2c: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Service:
        """Registers an HTTP service on the VM under `name`, listening on `port`.

        The
        service immediately becomes addressable at
        `https://<name>--<vmIdHexNoHyphens>.proxy.<stack-domain>` once the firewall is
        applied (synchronous).

        Idempotent: a POST with a name that already exists at the same `(port, h2c)`
        returns 201 with the existing entry. POST with a name that already exists at a
        different port OR different `h2c` returns 409 — use PUT to update an existing
        service.

        Per-VM cap: currently 16 services per VM (configurable via `MAX_SERVICES_PER_VM`
        on the scheduler).

        Args:
          h2c: Optional. When true, the proxy uses HTTP/2 cleartext to the backend (required
              for gRPC). Defaults to false (HTTP/1.1).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/v1/vms/{id}/services", id=id),
            body=maybe_transform(
                {
                    "name": name,
                    "port": port,
                    "h2c": h2c,
                },
                service_register_params.ServiceRegisterParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Service,
        )


class AsyncServicesResource(AsyncAPIResource):
    """Per-VM service registrations exposed via the public 4to6 HTTP proxy"""

    @cached_property
    def with_raw_response(self) -> AsyncServicesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/fastvm-org/fastvm-sdk-python#accessing-raw-response-data-eg-headers
        """
        return AsyncServicesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncServicesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/fastvm-org/fastvm-sdk-python#with_streaming_response
        """
        return AsyncServicesResourceWithStreamingResponse(self)

    async def update(
        self,
        service_name: str,
        *,
        id: str,
        port: int,
        h2c: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Service:
        """
        Idempotent register-or-update: same name + new port updates the port; same
        name + same port is a no-op. Returns the resulting entry. Used to change the
        upstream port for an existing service registration without dropping and
        re-creating it.

        Args:
          port: New TCP port. Same value as the existing entry is a no-op.

          h2c: Optional. When true, the proxy uses HTTP/2 cleartext to the backend. Same value
              as the existing entry is a no-op; a different value updates the registered
              transport.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not service_name:
            raise ValueError(f"Expected a non-empty value for `service_name` but received {service_name!r}")
        return await self._put(
            path_template("/v1/vms/{id}/services/{service_name}", id=id, service_name=service_name),
            body=await async_maybe_transform(
                {
                    "port": port,
                    "h2c": h2c,
                },
                service_update_params.ServiceUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Service,
        )

    async def list(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ServiceListResponse:
        """Returns the services currently registered on this VM, sorted by name.

        Each
        service is exposed at `https://<name>--<vmIdHexNoHyphens>.proxy.<stack-domain>`
        over HTTPS.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v1/vms/{id}/services", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ServiceListResponse,
        )

    async def delete(
        self,
        service_name: str,
        *,
        id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Idempotent: deleting a service that doesn't exist returns 204.

        Removes the
        firewall auto-rule synchronously; the proxy stops routing to the service within
        seconds (cache invalidation broadcast; 30s TTL is the safety net).

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        if not service_name:
            raise ValueError(f"Expected a non-empty value for `service_name` but received {service_name!r}")
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            path_template("/v1/vms/{id}/services/{service_name}", id=id, service_name=service_name),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoneType,
        )

    async def register(
        self,
        id: str,
        *,
        name: str,
        port: int,
        h2c: bool | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Service:
        """Registers an HTTP service on the VM under `name`, listening on `port`.

        The
        service immediately becomes addressable at
        `https://<name>--<vmIdHexNoHyphens>.proxy.<stack-domain>` once the firewall is
        applied (synchronous).

        Idempotent: a POST with a name that already exists at the same `(port, h2c)`
        returns 201 with the existing entry. POST with a name that already exists at a
        different port OR different `h2c` returns 409 — use PUT to update an existing
        service.

        Per-VM cap: currently 16 services per VM (configurable via `MAX_SERVICES_PER_VM`
        on the scheduler).

        Args:
          h2c: Optional. When true, the proxy uses HTTP/2 cleartext to the backend (required
              for gRPC). Defaults to false (HTTP/1.1).

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/v1/vms/{id}/services", id=id),
            body=await async_maybe_transform(
                {
                    "name": name,
                    "port": port,
                    "h2c": h2c,
                },
                service_register_params.ServiceRegisterParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Service,
        )


class ServicesResourceWithRawResponse:
    def __init__(self, services: ServicesResource) -> None:
        self._services = services

        self.update = to_raw_response_wrapper(
            services.update,
        )
        self.list = to_raw_response_wrapper(
            services.list,
        )
        self.delete = to_raw_response_wrapper(
            services.delete,
        )
        self.register = to_raw_response_wrapper(
            services.register,
        )


class AsyncServicesResourceWithRawResponse:
    def __init__(self, services: AsyncServicesResource) -> None:
        self._services = services

        self.update = async_to_raw_response_wrapper(
            services.update,
        )
        self.list = async_to_raw_response_wrapper(
            services.list,
        )
        self.delete = async_to_raw_response_wrapper(
            services.delete,
        )
        self.register = async_to_raw_response_wrapper(
            services.register,
        )


class ServicesResourceWithStreamingResponse:
    def __init__(self, services: ServicesResource) -> None:
        self._services = services

        self.update = to_streamed_response_wrapper(
            services.update,
        )
        self.list = to_streamed_response_wrapper(
            services.list,
        )
        self.delete = to_streamed_response_wrapper(
            services.delete,
        )
        self.register = to_streamed_response_wrapper(
            services.register,
        )


class AsyncServicesResourceWithStreamingResponse:
    def __init__(self, services: AsyncServicesResource) -> None:
        self._services = services

        self.update = async_to_streamed_response_wrapper(
            services.update,
        )
        self.list = async_to_streamed_response_wrapper(
            services.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            services.delete,
        )
        self.register = async_to_streamed_response_wrapper(
            services.register,
        )
