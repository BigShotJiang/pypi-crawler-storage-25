# -*- coding: utf-8 -*-
"""
clafrica — Clafrica keyboard mapping for Nufi (Fe'éfě'e) text.

Converts ASCII shortcut sequences produced by the Clafrica input method into
the corresponding Nufi Unicode characters.

Quick start::

    from clafrica import apply_mapping, finalize_input

    apply_mapping("af1 e2 n*")   # → "ɑ̀ é ŋ"
    finalize_input("eu3")        # → "ə̄"

For advanced use, instantiate :class:`ClafricaEngine` directly::

    from clafrica import ClafricaEngine

    engine = ClafricaEngine(extra={"mykey": "ɲ"})
    engine.lookup("mykey")       # → "ɲ"
"""

from __future__ import annotations

import importlib.resources
import json
import re

__version__ = "1.0.0"
__all__ = ["ClafricaEngine", "apply_mapping", "finalize_input"]


# ---------------------------------------------------------------------------
# Mapping loader
# ---------------------------------------------------------------------------

def _load_bundled_map() -> dict[str, str]:
    pkg = importlib.resources.files("clafrica").joinpath("data/clafrica.json")
    with pkg.open("r", encoding="utf-8") as fh:
        data: dict[str, str] = json.load(fh)
    # Mirror the manual addition present in the Android/Windows keyboard engine.
    data.setdefault("uu", "ʉ")
    return data


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class ClafricaEngine:
    """
    Transforms Clafrica shortcut text into Nufi Unicode characters.

    Parameters
    ----------
    mapping:
        Full replacement ``{shortcut: unicode}`` dict.  Defaults to the
        bundled ``clafrica.json`` (canonical mapping used by Android/Windows
        keyboards).
    extra:
        Optional entries merged on top of the base mapping.
    """

    def __init__(
        self,
        mapping: dict[str, str] | None = None,
        extra: dict[str, str] | None = None,
    ) -> None:
        base = mapping if mapping is not None else _load_bundled_map()
        if extra:
            base = {**base, **extra}
        self._token_map: dict[str, str] = {k: v for k, v in base.items() if " " not in k}
        self._phrase_map: dict[str, str] = {k: v for k, v in base.items() if " " in k}
        self._keys_sorted = sorted(self._token_map, key=lambda k: (-len(k), k))
        self._ambiguous: set[str] = {
            k for k in self._keys_sorted
            if any(len(o) > len(k) and o.startswith(k) for o in self._keys_sorted)
        }
        self._phrase_patterns = [
            (re.compile(re.escape(k)), v)
            for k, v in sorted(self._phrase_map.items(), key=lambda kv: -len(kv[0]))
        ]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def apply_mapping(self, text: str, preserve_ambiguous_trailing: bool = False) -> str:
        """Transform all shortcut tokens in *text*, preserving whitespace.

        With ``preserve_ambiguous_trailing=True`` the last token is left as
        typed when it could still grow into a longer shortcut (live-typing).
        """
        if not text:
            return text
        text = self._apply_phrase_mappings(text)
        segments = self._split(text)
        trailing = len(segments) - 1 if text and not text[-1].isspace() else -1
        out: list[str] = []
        for i, seg in enumerate(segments):
            if seg.isspace():
                out.append(seg)
            elif preserve_ambiguous_trailing and i == trailing:
                out.append(self._apply_live(seg))
            else:
                out.append(self._apply_token(seg))
        return "".join(out)

    def finalize_input(self, text: str) -> str:
        """Resolve any remaining shortcut suffix in *text* and return."""
        if not text:
            return text
        text = self._apply_phrase_mappings(text)
        return "".join(
            seg if seg.isspace() else self._finalize_token(seg)
            for seg in self._split(text)
        )

    def lookup(self, shortcut: str) -> str | None:
        """Return the Unicode value for an exact shortcut, or ``None``."""
        key = self._resolve(shortcut)
        return self._token_map.get(key) if key else None

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _is_ascii(s: str) -> bool:
        return all(ord(c) <= 0x7F for c in s)

    @staticmethod
    def _split(text: str) -> list[str]:
        out: list[str] = []
        i = 0
        for m in re.finditer(r"\s+", text):
            if m.start() > i:
                out.append(text[i:m.start()])
            out.append(m.group())
            i = m.end()
        if i < len(text):
            out.append(text[i:])
        return out or [""]

    def _resolve(self, token: str) -> str | None:
        if token in self._token_map:
            return token
        if self._is_ascii(token):
            lower = token.lower()
            if lower != token and lower in self._token_map:
                return lower
        return None

    def _apply_phrase_mappings(self, text: str) -> str:
        result = text
        changed = True
        while changed:
            changed = False
            for pat, repl in self._phrase_patterns:
                nxt = pat.sub(repl, result)
                if nxt != result:
                    result = nxt
                    changed = True
                    break
        return result

    def _apply_compositional(self, token: str) -> str:
        if not token or any(ord(c) > 0x7F for c in token):
            return token
        result = token
        changed = True
        while changed:
            changed = False
            for key in self._keys_sorted:
                if len(key) > len(result) or key not in result:
                    continue
                nxt = result.replace(key, self._token_map[key])
                if nxt != result:
                    result = nxt
                    changed = True
                    break
        return result

    def _apply_token(self, token: str) -> str:
        if not token:
            return token
        direct = self._resolve(token)
        if direct:
            return self._token_map[direct]
        for pattern in (r"^([a-zA-Z]+\*?)([1-9])([1-9])$", r"^([a-zA-Z]+\*?)([1-9])$"):
            m = re.fullmatch(pattern, token)
            if m:
                resolved = self._resolve("".join(m.groups()))
                if resolved:
                    return self._token_map[resolved]
        return self._apply_compositional(token)

    def _longest_trailing_exact_key(self, token: str) -> str | None:
        best: str | None = None
        for i in range(len(token)):
            suffix = token[i:]
            if self._resolve(suffix) and (best is None or len(suffix) > len(best)):
                best = suffix
        return best

    def _longest_trailing_prefix(self, token: str) -> str | None:
        best: str | None = None
        lo = token.lower()
        for i in range(len(token)):
            suffix = token[i:]
            suffix_lo = lo[i:]
            ascii_s = self._is_ascii(suffix)
            if any(
                k.startswith(suffix)
                or (ascii_s and self._is_ascii(k) and k.lower().startswith(suffix_lo))
                for k in self._keys_sorted
            ):
                if best is None or len(suffix) > len(best):
                    best = suffix
        return best

    def _ambiguous_trailing_suffix(self, token: str) -> str | None:
        best: str | None = None
        for i in range(len(token)):
            suffix = token[i:]
            canonical = self._resolve(suffix)
            if canonical and canonical in self._ambiguous:
                if best is None or len(suffix) > len(best):
                    best = suffix
        return best

    def _apply_live(self, token: str) -> str:
        if not token:
            return token
        canonical = self._resolve(token)
        if canonical:
            return token if canonical in self._ambiguous else self._token_map[canonical]
        exact_key = self._longest_trailing_exact_key(token)
        exact_canonical = self._resolve(exact_key) if exact_key else None
        if exact_key and exact_canonical and exact_canonical not in self._ambiguous:
            return self._apply_compositional(token[:-len(exact_key)]) + self._token_map[exact_canonical]
        amb = self._ambiguous_trailing_suffix(token)
        if amb:
            return self._apply_compositional(token[:-len(amb)]) + amb
        prefix = self._longest_trailing_prefix(token)
        if prefix:
            return self._apply_compositional(token[:-len(prefix)]) + prefix
        return self._apply_token(token)

    def _finalize_token(self, token: str) -> str:
        if not token:
            return token
        current = token
        changed = True
        while changed:
            changed = False
            exact_key = self._longest_trailing_exact_key(current)
            exact_canonical = self._resolve(exact_key) if exact_key else None
            if exact_key and exact_canonical:
                nxt = self._apply_compositional(current[:-len(exact_key)]) + self._token_map[exact_canonical]
                if nxt != current:
                    current = nxt
                    changed = True
                    continue
            mapped = self._apply_token(current)
            if mapped != current:
                current = mapped
                changed = True
        return current


# ---------------------------------------------------------------------------
# Module-level convenience functions (shared default engine)
# ---------------------------------------------------------------------------

_default_engine: ClafricaEngine | None = None


def _engine() -> ClafricaEngine:
    global _default_engine
    if _default_engine is None:
        _default_engine = ClafricaEngine()
    return _default_engine


def apply_mapping(text: str, preserve_ambiguous_trailing: bool = False) -> str:
    """Convert Clafrica shortcuts in *text* to Nufi Unicode.

    Example::

        apply_mapping("af1 e2 n*")   # → "ɑ̀ é ŋ"
    """
    return _engine().apply_mapping(text, preserve_ambiguous_trailing)


def finalize_input(text: str) -> str:
    """Finalize *text*: resolve any remaining shortcut suffix and return.

    Example::

        finalize_input("eu3")   # → "ə̄"
    """
    return _engine().finalize_input(text)
