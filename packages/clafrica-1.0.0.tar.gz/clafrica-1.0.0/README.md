# clafrica

Python library for the **Clafrica** keyboard input method — converts ASCII shortcut sequences into Nufi (Fe'éfě'e) Unicode characters.

## Install

```bash
pip install clafrica
```

## Usage

```python
from clafrica import apply_mapping, finalize_input

apply_mapping("af1 e2 n*")   # → "ɑ̀ é ŋ"
apply_mapping("eu3 af5")     # → "ə̄ ɑ̂"
finalize_input("eu3")        # → "ə̄"
```

### Advanced: custom engine

```python
from clafrica import ClafricaEngine

engine = ClafricaEngine(extra={"mykey": "ɲ"})
engine.lookup("mykey")        # → "ɲ"
engine.apply_mapping("mykey af1")  # → "ɲ ɑ̀"
```

### Live-typing mode

Pass `preserve_ambiguous_trailing=True` to leave the last token untouched
while the user is still typing (e.g. `af` could become `af1`, `af2`, …):

```python
apply_mapping("af", preserve_ambiguous_trailing=True)  # → "af"  (still typing)
apply_mapping("af1")                                   # → "ɑ̀"  (finalized)
```

## Shortcut reference

| Shortcut | Output | Description |
|----------|--------|-------------|
| `af` | `ɑ` | open-a |
| `eu` | `ə` | schwa |
| `ai` | `ε` | epsilon |
| `o*` | `ɔ` | open-o |
| `uu` | `ʉ` | u-bar |
| `n*` | `ŋ` | eng |
| `N*` | `Ŋ` | Eng (uppercase) |
| `af1` | `ɑ̀` | open-a low tone |
| `af2` | `ɑ́` | open-a mid tone |
| `af3` | `ɑ̄` | open-a high tone |

Tone digits: `1` = low, `2` = mid, `3` = high, `5` = rising, `7` = falling.
