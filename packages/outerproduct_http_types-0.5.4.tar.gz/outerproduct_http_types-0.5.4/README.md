# outerproduct-http-types

Shared HTTP-facing type definitions for the [OuterProduct](https://outerproduct.com) API.

This package contains the [Pydantic](https://docs.pydantic.dev) models that
describe the request and response shapes used across OuterProduct services and
SDKs. It is the source of truth for the wire contract between the OuterProduct
backend and any client (including the official Python SDK).

Most users should not depend on this package directly. Instead, install the
OuterProduct SDK, which re-exports the relevant types and provides a typed
client. Use this package only when you are building tooling that needs to
construct or parse OuterProduct API payloads independently of the SDK.

## Installation

```bash
pip install outerproduct-http-types
```

Requires Python 3.12 or newer.

## Usage

Import the model that matches the endpoint you are working with and construct
or validate payloads as you would with any Pydantic model:

```python
from outerproduct_http_types import PredictRequest, PredictResponse

request = PredictRequest(
    samples=[[1.0, "x"], [2.5, "y"]],
    feature_names=["feature_a", "feature_b"],
)
payload = request.model_dump_json()

# ... POST `payload` to /v1/models/{model_id}/predict, then parse:
response = PredictResponse.model_validate_json(raw_response_body)
print(response.model_id, response.predictions)
```

The package ships with a `py.typed` marker, so type checkers (mypy, pyright,
ty) will pick up the type information automatically.

## Versioning

This package follows [semantic versioning](https://semver.org/). Breaking
changes to wire types are released as a new major version. Minor versions add
new endpoints or optional fields; patch versions are reserved for documentation
and non-behavioral fixes.

## License

Licensed under the [MIT License](https://opensource.org/license/mit).
