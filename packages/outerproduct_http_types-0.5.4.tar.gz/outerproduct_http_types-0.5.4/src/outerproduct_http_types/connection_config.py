"""Per-Dataset connection-config wire types.

A ``ConnectionConfig`` fully addresses one data source: credentials are
referenced indirectly via ``credential_name`` (looked up server-side
against the per-user, per-type credential tables), and the remaining
fields fully describe the leaf object/table.

Four variants, discriminated on ``connector_type``:

- ``S3ConnectionConfig`` — user-owned S3 object, addressed by full ``s3://`` URI.
- ``SnowflakeConnectionConfig`` — Snowflake account/warehouse/database/schema/table.
- ``DatabricksConnectionConfig`` — Databricks workspace/path/catalog/schema/table.
- ``FileUploadConnectionConfig`` — internal upload bucket; no credential_name
  (server uses platform-internal S3 access for the ``is_internal=true`` row).

A ``ConnectionConfig`` rides inline on every Dataset wire payload; on
``POST /v1/datasets`` (or implicitly on the first fit/run/inference call),
the server persists it to the matching per-type ``*_connection_config``
table and returns a server-assigned ``dataset_id`` that the SDK caches
for idempotency on subsequent calls.
"""

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field


class S3ConnectionConfig(BaseModel):
    """Read from a user-owned S3 object.

    The full ``s3://bucket[/prefix]/key`` URI addresses a single object;
    no ``source_table`` / prefix-then-key split. ``credential_name`` is
    looked up against ``s3_credentials`` for the authenticated user.
    """

    connector_type: Literal["s3"] = "s3"
    credential_name: str = Field(
        ..., description="Name of the user's S3 credential entry."
    )
    uri: str = Field(
        ..., description="Full ``s3://bucket/.../file.ext`` URI of the dataset object."
    )
    region: str | None = Field(None, description="AWS region; optional.")
    file_format: Literal["pkl", "csv", "parquet"] | None = Field(
        None, description="File format; inferred from URI extension when omitted."
    )


class SnowflakeConnectionConfig(BaseModel):
    """Read from a Snowflake table."""

    connector_type: Literal["snowflake"] = "snowflake"
    credential_name: str = Field(
        ..., description="Name of the user's Snowflake credential entry."
    )
    account: str = Field(..., description="Snowflake account identifier.")
    warehouse: str | None = Field(
        None, description="Default warehouse for queries; optional."
    )
    database: str = Field(..., description="Database name.")
    schema_name: str = Field(..., description="Schema name within the database.")
    table: str = Field(..., description="Table name within the schema.")


class DatabricksConnectionConfig(BaseModel):
    """Read from a Databricks table.

    ``schema_name`` is serialized as ``"schema"`` on the wire to match the
    Databricks SDK convention; ``populate_by_name=True`` accepts both.
    """

    model_config = ConfigDict(populate_by_name=True)

    connector_type: Literal["databricks"] = "databricks"
    credential_name: str = Field(
        ..., description="Name of the user's Databricks credential entry."
    )
    server_hostname: str = Field(..., description="Databricks workspace hostname.")
    http_path: str = Field(
        ..., description="HTTP path of the SQL warehouse or cluster."
    )
    catalog: str | None = Field(None, description="Unity Catalog name; optional.")
    schema_name: str = Field(
        ..., alias="schema", description="Schema name within the catalog."
    )
    table: str = Field(..., description="Table name within the schema.")


class FileUploadConnectionConfig(BaseModel):
    """Read from an internally-uploaded file.

    Produced by ``FileUploadConnector`` in the SDK: bytes were PUT to
    the platform's internal S3 bucket via ``/v1/uploads``. The server
    uses its own credentials to read them — no ``credential_name``.
    """

    connector_type: Literal["file_upload"] = "file_upload"
    uri: str = Field(
        ..., description="Internal ``s3://`` URI the SDK uploaded to."
    )
    file_format: Literal["pkl", "csv", "parquet"] = Field(
        ..., description="Format of the bytes at ``uri``."
    )


ConnectionConfig = Annotated[
    S3ConnectionConfig
    | SnowflakeConnectionConfig
    | DatabricksConnectionConfig
    | FileUploadConnectionConfig,
    Field(discriminator="connector_type"),
]
"""Discriminated union of all connection-config variants."""
