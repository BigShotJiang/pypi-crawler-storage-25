"""Request schema for the /v1/trainer/run endpoint.

`/v1/trainer/run` runs the server-side `Trainer` (the replacement for
`ModelOrchestrator` in `outerproduct-trainer`). It compiles a model matrix
across one or more model families and runs HPO, optionally with k-fold CV,
ensembling, or a Pareto sweep over multiple metrics.

The training dataset rides inline as a :class:`Dataset` spec — the server
registers a row internally and proceeds with the rest of the pipeline.
Clients that want a stable id to reuse across runs can still call
``POST /v1/datasets`` first and pass an :class:`UploadedDataset` /
:class:`ConnectorDataset` referencing the same data.
"""

from typing import Literal
from uuid import UUID

from pydantic import BaseModel, Field, model_validator

from .common import JobResponse
from .datasets import Dataset

# --- Compute caps --------------------------------------------------------- #

MAX_HYPEROPT_BUDGET = 200
"""Hard cap on `n_trials x max(1, len(model_types))`.

Bounds total HPO trials per training request. Each trial spawns a Modal
container, so this is the primary cost gate."""


class ModalHardwareSpec(BaseModel):
    """Fan trials out to additional Modal containers.

    The only supported hardware spec for API requests. Local execution is
    intentionally not exposed at the wire — running PlanNodes in-process
    means materializing the dataset in the API container, which OOM's the
    Render server on any non-trivial input. Library / notebook callers can
    still construct ``LocalHardware()`` directly via ``outerproduct-trainer``;
    the wire-level lockdown only applies to API requests.
    """

    kind: Literal["modal"] = "modal"
    gpu: str = Field("A10G", description="Modal GPU type, e.g. 'A10G', 'T4', 'L40S'.")
    timeout_s: int = Field(1200, description="Per-trial timeout in seconds.")
    n_concurrent: int = Field(4, description="Max parallel trial containers.")


HardwareSpec = ModalHardwareSpec


class TrainerRunRequest(BaseModel):
    """POST /v1/trainer/run — configure a Trainer and run HPO across a model matrix.

    The training dataset rides inline; the handler registers it server-side
    before kicking off the worker. ``label_column`` is a per-fit choice so
    the same data source can be trained against different targets.
    """

    dataset: Dataset = Field(
        ...,
        description=(
            "Inline dataset spec. The server creates a dataset row from "
            "this and proceeds with the existing fit pipeline."
        ),
    )
    label_column: str | None = Field(
        None,
        description=(
            "Target column name within the dataset. Required for supervised "
            "training; optional when ``teacher_predict_url`` or "
            "``teacher_model_id`` is set."
        ),
    )

    # --- trainer configuration
    model_types: list[str] | None = Field(
        None,
        description="Candidate model-family identifiers, e.g. ['tabm', 'xgboost', "
        "'xrfm', 'tabicl']. Resolved server-side. If omitted, the server picks a "
        "default set based on dataset shape.",
    )
    metrics: list[str] | None = Field(
        None,
        description="Metric names to optimise, e.g. ['auc'] or ['auc', "
        "'neg_class_error']. Multi-metric requests trigger a Pareto sweep when "
        "grid_size is set. Custom Python callables are not supported in v1.",
    )
    strategy: str = Field(
        "random",
        description="HPO strategy: 'random' or 'optuna'. Resolved server-side.",
    )
    n_trials: int = Field(4, ge=1, description="Number of HPO trials per matrix row.")
    n_splits: int | None = Field(
        None,
        description="K-fold cross-validation folds. None means a single holdout split.",
    )
    ensemble: bool = Field(
        False,
        description="If true, build a Caruana-style ensemble across stage-1 fold/trial "
        "models instead of refitting the winner on full data.",
    )
    grid_size: float | None = Field(
        None,
        description="Simplex grid step for Pareto-style multi-metric sweeps.",
    )
    task_type: Literal["regression", "binclass", "multiclass"] | None = Field(
        None,
        description="Learning task. Required for supervised runs; optional when "
        "teacher_predict_url is set.",
    )

    # --- distillation
    teacher_model_id: str | None = Field(
        None,
        description=(
            "Distill from a same-server trained model identified by id. "
            "The synth-gen worker calls the inference worker in-process — "
            "no HTTP self-loop. Mutually exclusive with ``teacher_predict_url``."
        ),
    )
    teacher_predict_url: str | None = Field(
        None,
        description="If set, distil from an external teacher at this URL. "
        "The worker POSTs ``{'samples': [[...]], 'feature_names': [...]}``. "
        "Use ``teacher_model_id`` for same-server teachers instead.",
    )
    teacher_predict_headers: dict[str, str] | None = Field(
        None, description="Headers to send when calling teacher_predict_url."
    )

    # --- execution
    hardware: HardwareSpec | None = Field(
        None,
        description="Modal trials hardware. Omit to use the API server's "
        "default — currently ModalHardware with the API's pinned trainer "
        "image. In-process execution is not supported at the API edge to "
        "prevent the orchestrator from materializing X.",
    )
    random_state: int = 42

    @model_validator(mode="after")
    def _check_label_column(self):
        if (
            self.label_column is None
            and self.teacher_predict_url is None
            and self.teacher_model_id is None
        ):
            raise ValueError(
                "label_column is required unless teacher_predict_url or "
                "teacher_model_id is set (in which case the teacher provides "
                "the training target)"
            )
        return self

    @model_validator(mode="after")
    def _check_teacher_exclusive(self):
        if self.teacher_model_id is not None and self.teacher_predict_url is not None:
            raise ValueError(
                "teacher_model_id and teacher_predict_url are mutually exclusive"
            )
        return self

    @model_validator(mode="after")
    def _check_hyperopt_budget(self):
        # When model_types is None the server picks a default set, so the
        # client-visible budget is just n_trials. We cap that as a lower
        # bound on the real budget; the server should re-check after
        # resolving the default model list.
        n_models = max(1, len(self.model_types)) if self.model_types else 1
        budget = self.n_trials * n_models
        if budget > MAX_HYPEROPT_BUDGET:
            raise ValueError(
                f"n_trials x len(model_types) = {budget} exceeds the per-request "
                f"cap of {MAX_HYPEROPT_BUDGET}. Reduce n_trials or shrink "
                "model_types."
            )
        return self


class TrainerRunResponse(JobResponse):
    """POST /v1/trainer/run -- async trainer job submission response.

    ``dataset_id`` is the canonical id the server resolved for the inline
    Dataset spec (either looked up via the request's ``dataset.dataset_id``
    or freshly created). SDK clients stamp ``Dataset._id`` from this so
    later calls with the same Dataset short-circuit the create path.
    """

    dataset_id: UUID = Field(..., description="Server-assigned id of the resolved Dataset.")
