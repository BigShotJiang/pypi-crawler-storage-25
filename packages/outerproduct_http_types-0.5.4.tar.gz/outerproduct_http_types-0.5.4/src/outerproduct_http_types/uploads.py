"""Request/response schemas for the presigned-upload endpoint."""

from typing import Literal

from pydantic import BaseModel, Field

# --- Upload size policy --------------------------------------------------- #
# Tunable in review. These constants are the single source of truth for the
# SDK's client-side guards. Server-side enforcement of MAX_UPLOAD_BYTES will
# be wired when the upload flow switches from presigned PUT to presigned POST
# (where S3's `content-length-range` condition becomes available).

MAX_UPLOAD_BYTES = 10_000_000_000
"""Hard cap on uploaded file size, all formats.

Picked to comfortably hold 1M x 1k Parquet workloads with headroom for
~10x growth. Enforced today by the SDK before upload starts. When the
presigned POST switch lands, S3 will enforce server-side via
`content-length-range`."""

MAX_CSV_UPLOAD_BYTES = 3_000_000_000
"""Hard cap on CSV uploads specifically.

CSV is ~10-20x larger than the same data as Parquet, so a CSV near
MAX_UPLOAD_BYTES would almost always be a misformatted workload. Reject
early with a clear message rather than burn upload bandwidth on a file
that should have been Parquet."""

CSV_UPLOAD_WARN_BYTES = 500_000_000
"""SDK emits a UserWarning above this CSV size, suggesting Parquet.

Soft signal — at this scale Parquet would be ~50x100 MB for the same
data, and subsequent training reads are also faster."""


class CreateUploadRequest(BaseModel):
    """POST /v1/uploads -- request a presigned URL for direct-to-S3 upload."""

    file_format: Literal["pkl", "csv", "parquet"] = Field(
        ...,
        description=(
            "Format of the dataset you will PUT to the returned URL. "
            "'pkl' = a pickled pandas DataFrame, 'csv' = RFC4180 CSV with a "
            "header row, 'parquet' = Apache Parquet. The label column must be "
            "present in the uploaded table and its name is supplied on the "
            "subsequent /v1/trainer/run or /v1/reasoning/fit call as "
            "`label_column`."
        ),
    )


class CreateUploadResponse(BaseModel):
    dataset_id: str
    upload_url: str
    upload_key: str
    data_uri: str
    file_format: Literal["pkl", "csv", "parquet"]
    content_type: str
    expires_in: int
