"""Shared types used across all endpoint schemas."""

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class JobStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class ErrorResponse(BaseModel):
    error: str
    detail: str | None = None


class JobResponse(BaseModel):
    """Base response returned by async job-submission endpoints."""

    model_id: str = Field(description="Unique identifier for this model")
    status: JobStatus
    message: str


class StatusResponse(BaseModel):
    """Returned by GET /models/{model_id}/status."""

    model_id: str
    job_type: str = Field(
        description="One of: trainer_run, reasoning_fit, patterns_fit:<tracker_id>."
    )
    status: JobStatus
    progress: dict[str, Any] | None = Field(
        None, description='Progress info, e.g. {"step": 3, "total_steps": 5}'
    )
    error_message: str | None = None
    created_at: datetime
    updated_at: datetime


class FeatureImportance(BaseModel):
    """A single feature's importance score with direction."""

    feature_name: str
    importance: float
    direction: str | None = Field(None, description='"positive" or "negative"')
