"""Request/response schemas for the worker server (finalize + synth_gen)."""

from typing import Literal

from pydantic import BaseModel, Field


class WorkerJobRequest(BaseModel):
    """Body for POST /v1/workers/{finalize,synthgen}.

    Mirrors the AWS Lambda event shape that preceded the worker server: the
    caller uploads a cloudpickled kwargs dict to ``s3://{s3_bucket}/{input_key}``
    and the worker writes its cloudpickled output back to ``output_key``.
    """

    s3_bucket: str
    input_key: str = Field(description="S3 key of the cloudpickled input dict.")
    output_key: str = Field(description="S3 key the worker writes its cloudpickled result to.")


class WorkerJobResponse(BaseModel):
    """Response from POST /v1/workers/{finalize,synthgen}."""

    status: Literal["ok"] = "ok"
    output_key: str
