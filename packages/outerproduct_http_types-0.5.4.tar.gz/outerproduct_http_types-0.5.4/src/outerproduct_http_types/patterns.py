"""Request/response schemas for the /v1/models/{model_id}/patterns/* endpoints.

PatternTracker aggregates per-sample local-rule explanations into a small set
of executable, labeled filter patterns. Fit runs server-side; the SDK
client holds an ``id`` and calls transform/distribution/partition by
``tracker_id``.
"""

from typing import Any, Literal

from pydantic import BaseModel, Field

from .common import JobStatus


class PredicateSchema(BaseModel):
    """One literal of a conjunctive filter: ``feature <op> value``.

    Mirrors ``outerproduct_reasoning.internal.local_rules.Predicate``: ``op``
    is ``<=``/``>=`` for continuous features (numeric ``value``) or ``==`` for
    categoricals (string/bool/int ``value``).
    """

    feature: str
    op: Literal["<=", ">=", "=="]
    value: float | int | str | bool


class FilterPatternSchema(BaseModel):
    """One executable conjunctive filter with coverage stats and a label."""

    predicates: list[PredicateSchema]
    label: str
    support_rejects: float = Field(
        description="Share of fit-time rejected rows the pattern matches."
    )
    precision: float = Field(
        description="Share of all matched rows that are rejects."
    )
    lift: float = Field(description="precision / base_reject_rate.")
    n_local_rules_covered: int


class SchemaInfoSchema(BaseModel):
    """Column / dtype / categorical-level snapshot captured at fit time."""

    columns: list[str]
    dtypes: dict[str, str]
    # frozensets don't survive JSON; the server emits sorted lists, the SDK
    # rehydrates into frozensets on its side.
    categorical_levels: dict[str, list[Any]]


# --- POST /v1/models/{model_id}/patterns/fit ---


class PatternTrackerFitRequest(BaseModel):
    """POST /v1/models/{model_id}/patterns/fit — submit a pattern-tracker fit job.

    Carries the fit hyperparameters plus a ``dataset_id`` reference.
    Register the dataset first via ``POST /v1/datasets`` (the SDK
    ``Dataset(...)`` constructor does this automatically).
    """

    target_range: tuple[float | None, float | None] = Field(
        description=(
            "(lo, hi) bounds defining the 'rejected' band of predictions. "
            "Either side may be null for an open bound; at least one must be "
            "set."
        )
    )
    mode: Literal["cover", "discovery"] = "discovery"
    max_patterns: int = 25
    coverage_target: float = 0.95
    min_pattern_support: float = 0.005
    min_precision: float = 0.5
    max_pattern_size: int = 3
    threshold_n_bins: int = 10
    ensure_coverage: bool = True
    min_wracc: float = 0.0
    diversity_threshold: float = 0.5
    drop_redundant: bool = True
    child_overlap_threshold: float = 0.9
    explained_lift_threshold: float = 1.1
    min_pattern_samples: float = 0.05
    rule_kwargs: dict[str, Any] | None = None

    dataset_id: str = Field(
        ...,
        description=(
            "Identifier of a dataset previously created via "
            "``POST /v1/datasets``."
        ),
    )
    label_column: str | None = Field(
        default=None,
        description=(
            "Optional label column name to drop from the dataset before fitting."
        ),
    )


class PatternTrackerFitResponse(BaseModel):
    """Returned immediately by POST /patterns/fit; the actual artifact is
    retrieved via GET /patterns/{tracker_id} once the job completes."""

    model_id: str
    tracker_id: str
    status: JobStatus
    message: str | None = None


# --- GET /v1/models/{model_id}/patterns/{tracker_id} ---


class PatternTrackerResponse(BaseModel):
    """The fitted pattern tracker. Optional fields are None while the job is
    pending/running/failed; populated once the job completes successfully.
    """

    model_id: str
    tracker_id: str
    status: JobStatus
    patterns: list[FilterPatternSchema] | None = None
    schema_info: SchemaInfoSchema | None = None
    target_range: tuple[float | None, float | None] | None = None
    n_rejected_fit: int | None = None
    coverage_fit: float | None = None
    error_message: str | None = None


# --- POST /v1/models/{model_id}/patterns/{tracker_id}/transform ---


class PatternTrackerApplyRequest(BaseModel):
    """Body shared by /transform, /distribution, and /partition."""

    samples: list[list[float | str | bool | None]] = Field(
        description=(
            "2D array, shape (n_samples, n_features). Cells may be numeric, "
            "string (categorical), or bool."
        )
    )
    feature_names: list[str] = Field(
        description=(
            "Column names. Must include every column the tracker's frozen "
            "schema requires (extras are ignored)."
        )
    )


class PatternTrackerTransformResponse(BaseModel):
    """Boolean match matrix aligned to ``labels``."""

    labels: list[str]
    matrix: list[list[bool]] = Field(
        description="Shape (n_samples, n_patterns); cell `[i, j]` true iff "
        "sample i matches pattern labels[j]."
    )


class PatternTrackerDistributionResponse(BaseModel):
    """Per-pattern match rate over the supplied samples."""

    match_rate: dict[str, float]


class PatternTrackerPartitionResponse(BaseModel):
    """Matching row indices (positional, into the request's `samples`) keyed
    by pattern label."""

    indices: dict[str, list[int]]
