"""Inline ``Dataset`` wire spec used by training and inference requests.

A ``Dataset`` describes how to reach a tabular dataset without
materializing rows on the wire. It carries a discriminated
``ConnectionConfig`` (one of S3, Snowflake, Databricks, or FileUpload)
plus optional column schema and label column.

The same shape is used in three places:

- As the public ``POST /v1/datasets`` request body (clients that want a
  stable id to reuse across runs).
- Embedded directly on ``TrainerRunRequest`` and ``ReasoningFitRequest``
  so callers can train without first registering a dataset.
- Embedded on ``PredictRequest`` / ``ExplainRequest`` /
  ``PredictAndExplainRequest`` / ``ScenarioRequest`` so inference reads
  the same spec — predict materializes inline without persisting.

Idempotency
-----------
``dataset_id`` is server-assigned on first materialization. Subsequent
calls that include the same ``dataset_id`` skip the create entirely —
the server looks the row up by id and reuses it. The SDK stamps
``Dataset._id`` from the response of the first call.

Ownership invariant
-------------------
Dataset requests never carry a ``user_id``. The API derives the caller's
identity from the API key/session via ``get_current_org`` and uses that
authenticated identity for create/list/get scoping.

Endpoints
---------
- ``POST /v1/datasets``        → create a dataset (returns a ``DatasetResponse`` with a stable id)
- ``GET  /v1/datasets``        → list datasets the authenticated user owns
- ``GET  /v1/datasets/{id}``   → get one dataset
"""

from uuid import UUID

from pydantic import BaseModel, Field

from .connection_config import ConnectionConfig


class DatasetColumn(BaseModel):
    """One column in a dataset's input vector.

    Wire counterpart of the server's ``DatasetFeatureType``. ``datatype``
    is the storage dtype as a free-form string (``"float"``, ``"int"``,
    ``"string"``, ``"bool"``, ``"datetime"``), not the semantic Stype —
    semantic inference happens trainer-side.
    """

    feature_name: str
    datatype: str


class Dataset(BaseModel):
    """Inline dataset spec.

    ``connection_config`` is a discriminated union — the ``connector_type``
    inside it is the only discriminator anywhere. ``dataset_id`` is
    None on the first request and populated by the server's response;
    the SDK caches it so subsequent calls short-circuit the create path.
    """

    dataset_id: UUID | None = Field(
        None,
        description=(
            "Server-assigned id. None on the first request that uses this "
            "Dataset; populated thereafter so the server can dedupe."
        ),
    )
    connection_config: ConnectionConfig = Field(
        ..., description="How to reach the data source."
    )
    columns: list[DatasetColumn] = Field(
        default_factory=list,
        description=(
            "Per-column schema. Optional — when empty the server infers "
            "columns from the source on first materialization."
        ),
    )
    label_column: str | None = Field(
        None,
        description=(
            "Target column name within the dataset. Required for supervised "
            "training; optional for inference and teacher-driven distillation."
        ),
    )


class DatasetResponse(BaseModel):
    """Returned by ``POST /v1/datasets``, ``GET /v1/datasets/{id}``, and
    inside ``ListDatasetsResponse``.

    Omits ``user_id`` because it's implied by the API key/session used
    at the HTTP boundary.
    """

    id: UUID = Field(..., description="The canonical server-assigned dataset id.")
    connection_config: ConnectionConfig
    columns: list[DatasetColumn] = Field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None


class ListDatasetsResponse(BaseModel):
    """``GET /v1/datasets`` — all datasets owned by the authenticated user."""

    datasets: list[DatasetResponse]
