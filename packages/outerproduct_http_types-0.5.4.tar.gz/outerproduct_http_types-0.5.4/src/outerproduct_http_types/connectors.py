"""Request/response schemas for credential CRUD and connector validation.

The ``/v1/connector`` endpoints manage **credentials** only — one row
per ``(user, connector_type, credential_name)`` triple in the
per-type credential tables (``s3_credentials``, ``snowflake_credentials``,
``databricks_credentials``). These endpoints are consumed by **console.op**
(the web UI); the SDK never POSTs or DELETEs credentials directly.

The validate endpoint takes an inline ``ConnectionConfig`` (which carries
``credential_name``) and probes connectivity; it's used by both the SDK
and the console.

Endpoints
---------
- ``POST   /v1/connector``                   → create a credential (console only)
- ``GET    /v1/connector``                   → list credentials (console only)
- ``DELETE /v1/connector/{credential_name}`` → delete a credential (console only)
- ``POST   /v1/connector/validate``          → probe connectivity against a config
"""

from enum import StrEnum
from typing import Annotated, Literal

from pydantic import BaseModel, Field

from .connection_config import ConnectionConfig


class ConnectorType(StrEnum):
    """Supported external data source types for user-owned credentials."""

    S3 = "s3"
    SNOWFLAKE = "snowflake"
    DATABRICKS = "databricks"


# ---------------------------------------------------------------------------
# Per-type credentials (write-only; never returned by GET)
# ---------------------------------------------------------------------------


class S3Credentials(BaseModel):
    """Explicit AWS credentials. Omit entirely to use the API server's
    IAM role / default credential chain.
    """

    aws_access_key_id: str
    aws_secret_access_key: str
    aws_session_token: str | None = None


class SnowflakeCredentials(BaseModel):
    """Snowflake basic-auth credentials."""

    user: str
    password: str


class DatabricksCredentials(BaseModel):
    """Databricks personal access token."""

    access_token: str


# ---------------------------------------------------------------------------
# Discriminated create-credential request variants
# ---------------------------------------------------------------------------


class CreateS3CredentialRequest(BaseModel):
    """POST /v1/connector -- S3 credential variant.

    ``bucket_uri`` is the probe target: the server runs ``head_bucket``
    against it with the request's credentials (or our IAM role when
    ``credentials`` is None). The credential row is only inserted if the
    probe succeeds. ``bucket_uri`` is also stored on the credential row
    as the validated target so console.op can show "validated against X"
    per credential.
    """

    connector_type: Literal[ConnectorType.S3] = ConnectorType.S3
    credential_name: str = Field(
        ..., description="Unique-per-user name for this credential entry."
    )
    credentials: S3Credentials | None = Field(
        None,
        description="Omit for IAM-role-based access; the API server's role is used.",
    )
    bucket_uri: str = Field(
        ...,
        description=(
            "Full ``s3://bucket[/prefix]`` URI the server probes with "
            "``head_bucket`` before inserting the credential row. Stored "
            "on the row as the validated target."
        ),
    )


class CreateSnowflakeCredentialRequest(BaseModel):
    """POST /v1/connector -- Snowflake credential variant.

    The (``account``, ``warehouse``, ``database``, ``schema_name``) tuple
    is the probe target: the server runs ``SELECT 1`` against it with
    the request's credentials. The credential row is only inserted if
    the probe succeeds, and the tuple is stored on the row as the
    validated target.
    """

    connector_type: Literal[ConnectorType.SNOWFLAKE] = ConnectorType.SNOWFLAKE
    credential_name: str = Field(
        ..., description="Unique-per-user name for this credential entry."
    )
    credentials: SnowflakeCredentials
    account: str = Field(..., description="Snowflake account identifier (probe target).")
    warehouse: str | None = Field(
        None, description="Default warehouse for the probe; optional."
    )
    database: str = Field(..., description="Database to probe against.")
    schema_name: str = Field(..., description="Schema within the database to probe.")


class CreateDatabricksCredentialRequest(BaseModel):
    """POST /v1/connector -- Databricks credential variant.

    The (``server_hostname``, ``http_path``, ``catalog``, ``schema_name``)
    tuple is the probe target: the server runs ``SELECT 1`` against it
    with the request's credentials. The credential row is only inserted
    if the probe succeeds, and the tuple is stored on the row.
    """

    connector_type: Literal[ConnectorType.DATABRICKS] = ConnectorType.DATABRICKS
    credential_name: str = Field(
        ..., description="Unique-per-user name for this credential entry."
    )
    credentials: DatabricksCredentials
    server_hostname: str = Field(..., description="Databricks workspace hostname.")
    http_path: str = Field(
        ..., description="HTTP path of the SQL warehouse or cluster."
    )
    catalog: str | None = Field(None, description="Unity Catalog name; optional.")
    schema_name: str | None = Field(
        None, description="Schema within the catalog; optional."
    )


CreateCredentialRequest = Annotated[
    CreateS3CredentialRequest
    | CreateSnowflakeCredentialRequest
    | CreateDatabricksCredentialRequest,
    Field(discriminator="connector_type"),
]
"""Discriminated union of all create-credential request variants."""


# ---------------------------------------------------------------------------
# Response shapes
# ---------------------------------------------------------------------------


class CredentialResponse(BaseModel):
    """Returned by POST / GET endpoints. Credentials themselves are
    never returned — ``has_credentials`` indicates whether a non-IAM
    credential is stored for this row.

    The ``verified_*`` fields surface the probe target the credential
    was validated against at create time. Exactly one set of fields is
    populated per response, matching ``connector_type``:

    * ``s3`` → ``verified_bucket_uri``
    * ``snowflake`` → ``verified_account`` + ``verified_warehouse`` +
      ``verified_database`` + ``verified_schema_name``
    * ``databricks`` → ``verified_server_hostname`` + ``verified_http_path``
      + ``verified_catalog`` + ``verified_schema_name``
    """

    credential_name: str
    connector_type: ConnectorType
    has_credentials: bool = Field(
        ...,
        description=(
            "True when a credential ciphertext is stored. False for "
            "S3 entries created with IAM-role-based access."
        ),
    )
    created_at: str
    updated_at: str
    verified_bucket_uri: str | None = None
    verified_account: str | None = None
    verified_warehouse: str | None = None
    verified_database: str | None = None
    verified_schema_name: str | None = None
    verified_server_hostname: str | None = None
    verified_http_path: str | None = None
    verified_catalog: str | None = None


class ListCredentialsResponse(BaseModel):
    """GET /v1/connector — all credentials for the authenticated user."""

    credentials: list[CredentialResponse]


class DeleteCredentialResponse(BaseModel):
    """DELETE /v1/connector/{credential_name}?connector_type=..."""

    credential_name: str
    connector_type: ConnectorType
    deleted: bool


class ValidateConnectorRequest(BaseModel):
    """POST /v1/connector/validate — probe connectivity against an inline config.

    ``connection_config`` carries the ``credential_name`` for non-upload
    variants. ``FileUploadConnectionConfig`` is not a valid input — the
    upload step itself is the connectivity check; the router 400s on it.
    """

    connection_config: ConnectionConfig


class ValidateConnectorResponse(BaseModel):
    """POST /v1/connector/validate — connectivity probe result."""

    valid: bool = Field(..., description="Whether the connection succeeded.")
    error: str | None = Field(
        None, description="Human-readable error message when ``valid=False``."
    )
