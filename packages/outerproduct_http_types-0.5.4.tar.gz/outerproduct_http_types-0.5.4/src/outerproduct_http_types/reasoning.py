"""Request schema for the /v1/reasoning/fit endpoint.

`/v1/reasoning/fit` is the wire equivalent of
`outerproduct_reasoning.reasoning.fit(...)`. The worker imports the real
`outerproduct_reasoning` package and calls `reasoning.fit(...)`, returning a
fitted `ReasoningModel` artifact. Both supervised training (no teacher) and
distillation (teacher set) flow through the same request.

The dataset rides inline as a :class:`Dataset` spec; the handler registers
a row server-side before kicking off the worker. ``label_column`` stays on
the fit request as a per-fit choice.
"""

from typing import Literal
from uuid import UUID

from pydantic import BaseModel, Field, model_validator

from .common import JobResponse
from .datasets import Dataset
from .trainer import HardwareSpec

# --- Compute caps --------------------------------------------------------- #

MAX_REASONING_HYPEROPT_STEPS = 200
"""Hard cap on `n_hyperopt_steps`.

reasoning.fit pins the surrogate to a single model type, so the budget
is just n_hyperopt_steps. Each step is a Modal trial."""


class ReasoningFitRequest(BaseModel):
    """POST /v1/reasoning/fit — fit a ReasoningModel against an inline dataset spec.

    When a teacher is set (``teacher_model_id`` or ``teacher_predict_url``),
    ``label_column`` becomes evaluation-only — the teacher provides the
    training target.
    """

    dataset: Dataset = Field(
        ...,
        description=(
            "Inline dataset spec. The server creates a dataset row from "
            "this and proceeds with the existing fit pipeline."
        ),
    )
    label_column: str | None = Field(
        None,
        description=(
            "Target column name within the dataset. Required for supervised "
            "fits; optional when a teacher is set."
        ),
    )

    # --- reasoning.fit kwargs
    model_types: list[str] | None = Field(
        None,
        description="Candidate model-family identifiers. reasoning.fit pins the "
        "surrogate via force_model_type, so at most one entry is accepted.",
    )
    n_hyperopt_steps: int = Field(5, ge=1, le=MAX_REASONING_HYPEROPT_STEPS)
    device: str | None = Field(None, description="'auto' | 'cuda' | 'cpu'.")
    random_state: int = 42
    task_type: Literal["regression", "binclass", "multiclass"] | None = Field(
        None,
        description="Learning task. Required for supervised fits; optional when "
        "a teacher is set (the teacher pins the task).",
    )
    hardware: HardwareSpec | None = Field(
        None,
        description="Modal trainer hardware. Omit to use the API server's "
        "default — currently ModalHardware with the API's pinned trainer "
        "image. In-process execution is not supported at the API edge to "
        "prevent the orchestrator from materializing X. Synth-gen and "
        "finalize always run on the worker server (also out of process); "
        "no caller-controlled toggle.",
    )

    # --- distillation
    teacher_model_id: str | None = Field(
        None,
        description=(
            "Distill from a same-server trained model identified by id. "
            "The synth-gen worker calls the inference worker in-process — "
            "no HTTP self-loop. Mutually exclusive with ``teacher_predict_url``."
        ),
    )
    teacher_predict_url: str | None = Field(
        None,
        description="If set, distil an external teacher at this URL instead "
        "of training on labels. Use ``teacher_model_id`` for same-server "
        "teachers.",
    )
    teacher_predict_headers: dict[str, str] | None = Field(
        None, description="Headers to send when calling teacher_predict_url."
    )
    teacher_get_grads_url: str | None = Field(
        None,
        description="If set, the teacher is a DiffModel that exposes a per-sample "
        "Jacobian endpoint. Reasoning skips synth-gen and trainer.run and runs "
        "finalize directly against this URL plus teacher_predict_url. Requires "
        "teacher_predict_url.",
    )

    @model_validator(mode="after")
    def _check_label_column(self):
        if (
            self.label_column is None
            and self.teacher_predict_url is None
            and self.teacher_model_id is None
        ):
            raise ValueError(
                "label_column is required unless teacher_predict_url or "
                "teacher_model_id is set"
            )
        return self

    @model_validator(mode="after")
    def _check_teacher_exclusive(self):
        if self.teacher_model_id is not None and self.teacher_predict_url is not None:
            raise ValueError(
                "teacher_model_id and teacher_predict_url are mutually exclusive"
            )
        return self

    @model_validator(mode="after")
    def _check_teacher_grads_pair(self):
        if (
            self.teacher_get_grads_url is not None
            and self.teacher_predict_url is None
            and self.teacher_model_id is None
        ):
            raise ValueError(
                "teacher_get_grads_url requires a paired teacher reference "
                "(teacher_model_id for same-server DiffModels, "
                "teacher_predict_url for external DiffModel endpoints)"
            )
        return self

    @model_validator(mode="after")
    def _check_model_types_length(self):
        if self.model_types is not None and len(self.model_types) > 1:
            raise ValueError(
                "reasoning.fit pins the surrogate via force_model_type, so "
                "model_types accepts at most one entry; pass a single value "
                "or omit."
            )
        return self


class ReasoningFitResponse(JobResponse):
    """POST /v1/reasoning/fit -- async reasoning-fit job submission response.

    ``dataset_id`` is the canonical id the server resolved for the inline
    Dataset spec. SDK clients stamp ``Dataset._id`` from this.
    """

    dataset_id: UUID = Field(..., description="Server-assigned id of the resolved Dataset.")
