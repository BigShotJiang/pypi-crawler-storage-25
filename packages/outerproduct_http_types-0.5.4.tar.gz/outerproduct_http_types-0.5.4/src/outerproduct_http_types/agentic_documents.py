"""Request/response schemas for the agentic-documents endpoints.

Wire format for ``outerproduct.agentic.documents``: per-file presigned
uploads, async ``induce_schema`` and ``tabularize`` jobs polled via the
shared ``GET /v1/models/{model_id}/status`` route. ``induce_schema``
results are keyed by the job's ``model_id`` (the schema id);
``tabularize`` results are keyed by ``dataset_id`` (the produced
dataset, per OUT-361 semantics).

Endpoint summary:

- ``POST /v1/uploads/documents`` -> :class:`CreateDocumentUploadResponse`
- ``POST /v1/agentic/documents/induce_schema`` -> :class:`InduceSchemaJobResponse`
- ``GET  /v1/agentic/documents/schemas/{model_id}`` -> :class:`SchemaResultResponse`
- ``POST /v1/agentic/documents/tabularize`` -> :class:`TabularizeJobResponse`
- ``GET  /v1/agentic/documents/tables/{dataset_id}`` -> :class:`TabularizeResultResponse`
"""

from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from .common import JobResponse


class AnswerType(StrEnum):
    """The legal answer shapes for a :class:`Question`."""

    BOOLEAN = "boolean"
    NUMBER = "number"
    INTEGER = "integer"
    ENUM = "enum"
    MULTI_ENUM = "multi_enum"
    DATE = "date"
    DATE_RANGE = "date_range"
    STRING = "string"
    TEXT = "text"


_DOCUMENT_MEDIA_TYPES = Literal[
    "application/pdf",
    "image/png",
    "image/jpeg",
    "image/gif",
    "image/webp",
    "text/plain",
]


class Question(BaseModel):
    """One survey question in a :class:`Schema`."""

    id: str = Field(
        ...,
        description="Snake-case identifier, unique within the schema.",
        pattern=r"^[a-z][a-z0-9_]*$",
    )
    question: str = Field(..., description="Natural-language prompt the agent answers.")
    answer_type: AnswerType
    rationale: str | None = Field(
        None, description="Why this question is on the schema; surfaced to the agent."
    )
    unit: str | None = Field(
        None, description="Unit string for numeric answers (e.g. 'USD', 'kg')."
    )
    enum: list[str] | None = Field(
        None,
        description="Allowed values when answer_type is 'enum' or 'multi_enum'.",
    )

    @model_validator(mode="after")
    def _check_enum(self):
        if self.answer_type in (AnswerType.ENUM, AnswerType.MULTI_ENUM):
            if not self.enum:
                raise ValueError(
                    f"Question {self.id!r}: answer_type={self.answer_type.value} "
                    "requires non-empty `enum`"
                )
        elif self.enum is not None:
            raise ValueError(
                f"Question {self.id!r}: `enum` is only valid for answer_type='enum' or 'multi_enum'"
            )
        return self


class Schema(BaseModel):
    """A frozen list of :class:`Question` for one document type and one use case."""

    skill: str = Field(..., description="Skill slug (e.g. 'invoice', 'bank-statement').")
    use_case: str = Field(..., description="Use-case description that drove induction.")
    questions: list[Question]
    metadata: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_unique_ids(self):
        seen: set[str] = set()
        for q in self.questions:
            if q.id in seen:
                raise ValueError(f"Schema: duplicate question id {q.id!r}")
            seen.add(q.id)
        return self


# --------------------------------------------------------------------------- #
# Per-document upload                                                         #
# --------------------------------------------------------------------------- #


class CreateDocumentUploadRequest(BaseModel):
    """``POST /v1/uploads/documents`` -- request a presigned URL for one file."""

    document_id: str = Field(
        ...,
        description="Caller-chosen identifier; echoed back in subsequent requests.",
    )
    media_type: _DOCUMENT_MEDIA_TYPES = Field(
        ...,
        description="MIME type of the bytes you will PUT to the returned URL.",
    )


class CreateDocumentUploadResponse(BaseModel):
    document_id: str
    upload_url: str
    upload_key: str = Field(
        ...,
        description="Reference to use as DocumentRef.upload_key in induce/tabularize.",
    )
    media_type: _DOCUMENT_MEDIA_TYPES
    expires_in: int = Field(..., description="Seconds until the upload URL expires.")


class DocumentRef(BaseModel):
    """One uploaded document, by reference."""

    document_id: str
    upload_key: str
    media_type: _DOCUMENT_MEDIA_TYPES


# --------------------------------------------------------------------------- #
# induce_schema                                                               #
# --------------------------------------------------------------------------- #


class InduceSchemaRequest(BaseModel):
    """``POST /v1/agentic/documents/induce_schema`` -- async schema induction job.

    Runs the agent over the supplied document sample to produce a frozen
    :class:`Schema`. Submit, poll ``GET /v1/models/{model_id}/status`` until
    ``status="completed"``, then fetch the result via
    ``GET /v1/agentic/documents/schemas/{model_id}``.
    """

    documents: list[DocumentRef] = Field(
        ...,
        description="Sample of uploaded documents the agent inspects to draft the schema.",
        min_length=1,
    )
    use_case: str = Field(
        ...,
        description="Free-text description of what the resulting features will be used for.",
    )
    skill: str = Field(
        ...,
        description="Skill slug; one of the values returned by GET /v1/agentic/documents/skills.",
    )
    model_id: str | None = Field(
        None,
        description="Custom model_id for the resulting schema; auto-generated if omitted.",
    )


class InduceSchemaJobResponse(JobResponse):
    """``POST /v1/agentic/documents/induce_schema`` -- async submission response."""


class SchemaResultResponse(BaseModel):
    """``GET /v1/agentic/documents/schemas/{model_id}`` -- the produced schema."""

    model_id: str
    schema_: Schema = Field(..., alias="schema")

    model_config = {"populate_by_name": True}


# --------------------------------------------------------------------------- #
# tabularize                                                                  #
# --------------------------------------------------------------------------- #


class TabularizeRequest(BaseModel):
    """``POST /v1/agentic/documents/tabularize`` -- async tabularization job.

    Extracts every uploaded document against ``schema`` and assembles a row
    per document. Submit, poll status, then fetch the result via
    ``GET /v1/agentic/documents/tables/{dataset_id}``.

    Fan-out concurrency is governed server-side by the Lambda fleet's
    reserved concurrency; there is no client-supplied concurrency knob.
    """

    documents: list[DocumentRef] = Field(..., min_length=1)
    schema_: Schema = Field(..., alias="schema")
    web_augmentation: bool = Field(
        False,
        description="If true, allow the agent to issue web searches to corroborate answers.",
    )

    model_config = {"populate_by_name": True}


class TabularizeJobResponse(JobResponse):
    """``POST /v1/agentic/documents/tabularize`` -- async submission response."""


class TabularizeFailure(BaseModel):
    """One document that the per-doc Lambda was unable to extract.

    Surfaced in :class:`TabularizeResultResponse.failures` alongside
    ``failed_document_ids``; the row for this document is omitted from
    the tabularized DataFrame.
    """

    document_id: str
    error: str = Field(..., description="Operator-readable failure reason.")


class TabularizeResultResponse(BaseModel):
    """``GET /v1/agentic/documents/tables/{dataset_id}`` -- the tabularized result.

    The tabularized rows themselves live in object storage under the
    returned ``dataset_id`` (same prefix used by upload-sourced datasets),
    so this response is metadata-only: enough to construct a
    :class:`outerproduct.agentic.documents.DocumentDataset` handle without
    materializing rows on the client.

    ``document_ids`` lists only the docs that produced a row.
    ``failed_document_ids`` lists docs that failed extraction (a row was
    not produced); ``failures`` carries the per-doc error message.
    """

    dataset_id: str
    schema_: Schema = Field(..., alias="schema")
    document_ids: list[str]
    failed_document_ids: list[str] = Field(default_factory=list)
    failures: list[TabularizeFailure] = Field(default_factory=list)

    model_config = {"populate_by_name": True}
