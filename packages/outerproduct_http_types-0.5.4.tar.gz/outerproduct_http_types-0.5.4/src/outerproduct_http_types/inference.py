"""Request/response schemas for inference endpoints.

Inference requests carry an inline ``Dataset`` spec (see
``outerproduct_http_types.datasets``) — the rows themselves never travel
over the wire. The server builds the typed trainer ``Dataset`` from the
spec and ships it to the inference worker, which calls ``materialize()``
inside its container.
"""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .datasets import Dataset

# --- Request size caps ---------------------------------------------------- #
# Tune in review. Defined as module-level constants so callers, tests, and
# worker bodies can reference them. The wire layer no longer enforces row
# counts (rows are not on the wire); the inference worker checks
# ``len(materialized_df)`` against these caps after ``materialize()``.

MAX_PREDICT_ROWS = 100_000
"""Hard cap on materialized row count for /predict requests."""

MAX_EXPLAIN_ROWS = 10_000
"""Hard cap on materialized row count for /explain and /predict_and_explain.

Lower than /predict because explanation computes per-row feature
attributions, which are roughly an order of magnitude more expensive
than prediction."""

MAX_SCENARIO_QUERIES = 100
"""Hard cap on materialized row count for /scenario.

Each query runs ``n_walks`` random walks of up to ``max_steps`` steps;
total work scales as n_queries x n_walks x max_steps."""

MAX_SCENARIO_WALK_BUDGET = 50_000
"""Hard cap on ``n_walks x max_steps`` per request.

Bounds the per-query inner work regardless of how the user splits the
budget between width (more walks) and depth (more steps)."""


# --- POST /v1/models/{model_id}/predict ---


class PredictRequest(BaseModel):
    """POST /v1/models/{model_id}/predict -- Batch predictions."""

    dataset: Dataset = Field(
        ...,
        description=(
            "Inline dataset spec. The server resolves it to a typed trainer "
            "Dataset and ships the reference to the inference worker, which "
            "materializes inside its container."
        ),
    )


class PredictResponse(BaseModel):
    """Inference is stateless — no ``op_datasets`` row is created, hence
    no ``dataset_id`` on the response. The worker materializes rows
    inside its container, runs prediction, returns.
    """

    model_id: str
    predictions: list[float]


# --- POST /v1/models/{model_id}/explain ---


class ExplainRequest(BaseModel):
    """POST /v1/models/{model_id}/explain -- Batch local explanations."""

    dataset: Dataset = Field(
        ...,
        description="Inline dataset spec; rows are materialized inside the worker.",
    )


class ExplainResponse(BaseModel):
    """Batch-shaped explanation arrays. Dimension 0 is the batch.

    `/explain` is purely an attribution endpoint — it does not return
    predictions. Callers that need both predictions and attributions
    should use `/predict_and_explain` instead.
    """

    model_id: str
    attributions: list[list[float]]
    feature_names: list[str]
    ohe_feature_names: list[str] | None = Field(
        default=None,
        description=(
            "OHE-expanded column labels aligned to attributions. Present when "
            "the model has categorical features; the raw feature_names list has "
            "fewer entries than the attributions array in that case."
        ),
    )


# --- POST /v1/models/{model_id}/predict_and_explain ---


class PredictAndExplainRequest(BaseModel):
    """POST /v1/models/{model_id}/predict_and_explain -- Predict + explain in one call."""

    dataset: Dataset = Field(
        ...,
        description="Inline dataset spec; rows are materialized inside the worker.",
    )
    rule_kwargs: dict[str, Any] | None = Field(
        default=None,
        description=(
            "Gates local-rule computation, forwarded to the rule-explanation "
            "backend. Omitted/null → rules skipped. "
            "{} → backend defaults. "
            "Populated dict → use these kwargs (e.g. "
            '{"selector": "lift_threshold", "lift_threshold": 0.9}).'
        ),
    )


class PredictAndExplainResponse(BaseModel):
    """Batch-shaped predict + explain arrays. Dimension 0 is the batch."""

    model_id: str
    predictions: list[float]
    attributions: list[list[float]]
    local_rules: list[dict[str, Any] | None] | None = Field(
        default=None,
        description=(
            "Per-sample rule explanations when rule_kwargs was supplied. "
            "Each entry has sample_prediction, global_mean, direction, "
            "active_features, rules[]."
        ),
    )
    feature_names: list[str]
    ohe_feature_names: list[str] | None = Field(
        default=None,
        description=("OHE-expanded column labels aligned to attributions."),
    )


# --- POST /v1/models/{model_id}/global_drivers ---


class GlobalDriversRequest(BaseModel):
    """POST /v1/models/{model_id}/global_drivers -- Global feature importance."""

    pass


class GlobalDriversResponse(BaseModel):
    model_id: str
    global_drivers: list[float] = Field(description="Per-feature importance scores.")
    feature_names: list[str] | None = None
    ohe_feature_names: list[str] | None = Field(
        default=None,
        description=(
            "OHE-expanded column labels aligned to global_drivers. Present when "
            "the model has categorical features."
        ),
    )


# GET /v1/models/{model_id}/schema returns the SchemaManifest defined alongside
# the S3 sidecar wire schema in the API repo (app.schemas.messages); the HTTP
# response and the on-disk manifest share one definition there.


# --- POST /v1/models/{model_id}/scenario ---


class FeatureConstraintSchema(BaseModel):
    """Per-feature restriction applied during counterfactual walks.

    Mirrors cleartrace.FeatureConstraint. Continuous-only fields
    (value_range, monotonic) and categorical-only fields (allowed_values)
    are validated server-side against the model's feature groups.
    """

    immutable: bool = False
    monotonic: Literal["increase", "decrease"] | None = None
    value_range: tuple[float | None, float | None] | None = None
    allowed_values: list[Any] | None = None

    @model_validator(mode="after")
    def _check_invariants(self):
        if self.immutable and (
            self.monotonic is not None
            or self.value_range is not None
            or self.allowed_values is not None
        ):
            raise ValueError(
                "immutable=True cannot be combined with monotonic, value_range, "
                "or allowed_values."
            )
        if self.value_range is not None:
            lo, hi = self.value_range
            if lo is not None and hi is not None and lo > hi:
                raise ValueError(
                    f"value_range lower bound {lo} exceeds upper bound {hi}."
                )
        if self.allowed_values is not None and len(self.allowed_values) == 0:
            raise ValueError("allowed_values must be non-empty when provided.")
        return self


class ScenarioRequest(BaseModel):
    """POST /v1/models/{model_id}/scenario -- Counterfactual search with constraints."""

    dataset: Dataset = Field(
        ...,
        description=(
            "Inline dataset spec — each materialized row is one query for the "
            "counterfactual search. Caps on row count are enforced inside the "
            "worker after ``materialize()``."
        ),
    )
    desired_class: int = 1
    n_walks: int = Field(500, ge=1)
    max_steps: int = Field(30, ge=1)
    epsilon: float = Field(0.2, gt=0.0, le=1.0)
    random_state: int | None = 42
    constraints: dict[str, FeatureConstraintSchema] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _check_walk_budget(self):
        budget = self.n_walks * self.max_steps
        if budget > MAX_SCENARIO_WALK_BUDGET:
            raise ValueError(
                f"n_walks × max_steps = {budget} exceeds the per-query cap of "
                f"{MAX_SCENARIO_WALK_BUDGET}. Reduce n_walks or max_steps."
            )
        return self


class ScenarioChange(BaseModel):
    """Single-feature diff between a query and one counterfactual row."""

    model_config = ConfigDict(populate_by_name=True)

    from_: Any = Field(alias="from")
    to: Any
    delta: float | None = None


class ScenarioCandidate(BaseModel):
    row: dict[str, Any]
    changes: dict[str, ScenarioChange]
    n_changes: int


class ScenarioResultItem(BaseModel):
    query_index: int
    query: dict[str, Any]
    baseline_prediction: float
    already_at_desired_class: bool
    scenarios: list[ScenarioCandidate]
    scenario_count: int


class ScenarioResponse(BaseModel):
    model_id: str
    desired_class: int
    results: list[ScenarioResultItem]
