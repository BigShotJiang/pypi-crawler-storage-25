"""Enum utils."""

import sys
from enum import Enum
from typing import TypeVar

if sys.version_info >= (3, 11):
    from enum import StrEnum
else:

    class StrEnum(str, Enum):
        """Compatibility fallback for Python 3.10."""


CIEType = TypeVar("CIEType", bound="CaseInsensitiveEnum")


class CaseInsensitiveEnum(StrEnum):
    """Case Insensitive Enum."""

    @classmethod
    def _missing_(cls: type[CIEType], value: object) -> CIEType | None:
        """Lookup value not found in enum."""
        if isinstance(value, cls):
            return value
        if isinstance(value, str):
            value = value.lower()
            for member in cls:
                if member.name.lower() == value or member.value.lower() == value:
                    return member
        return None
