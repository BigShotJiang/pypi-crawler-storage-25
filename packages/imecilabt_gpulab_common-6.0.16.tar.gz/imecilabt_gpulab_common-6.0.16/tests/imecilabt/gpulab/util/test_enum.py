"""Tests for enum module."""

import json

import pytest
from imecilabt.gpulab.util.enum import CaseInsensitiveEnum
from pydantic import BaseModel, ValidationError


class Color(CaseInsensitiveEnum):
    """Test enum for colors."""

    RED = "red"
    GREEN = "green"
    BLUE = "blue"
    YELLOW = "yellow"


class TestCaseInsensitiveEnum:
    """Test CaseInsensitiveEnum class."""

    def test_basic_enum_access(self) -> None:
        """Test basic enum member access."""
        assert Color.RED.value == "red"
        assert Color.GREEN.value == "green"
        assert Color.BLUE.value == "blue"
        assert Color.YELLOW.value == "yellow"

    def test_case_insensitive_lookup_by_name(self) -> None:
        """Test case-insensitive lookup by member name."""
        assert Color._missing_("red") == Color.RED
        assert Color._missing_("RED") == Color.RED
        assert Color._missing_("Red") == Color.RED
        assert Color._missing_("rEd") == Color.RED

        assert Color._missing_("green") == Color.GREEN
        assert Color._missing_("GREEN") == Color.GREEN
        assert Color._missing_("Green") == Color.GREEN

    def test_case_insensitive_lookup_returns_none_for_invalid(self) -> None:
        """Test that invalid lookups return None."""
        assert Color._missing_("purple") is None
        assert Color._missing_("PURPLE") is None
        assert Color._missing_(123) is None
        assert Color._missing_(None) is None

    def test_missing_returns_same_enum_member(self) -> None:
        """Test that passing an enum member returns itself."""
        assert Color._missing_(Color.RED) == Color.RED
        assert Color._missing_(Color.BLUE) == Color.BLUE


class TestCaseInsensitiveEnumWithPydantic:
    """Test CaseInsensitiveEnum integration with Pydantic."""

    class ColorModel(BaseModel):
        """Model with CaseInsensitiveEnum field."""

        color: Color
        name: str

    def test_pydantic_model_with_enum_member(self) -> None:
        """Test Pydantic model with enum member."""
        model = self.ColorModel(color=Color.RED, name="Test")
        assert model.color == Color.RED
        assert model.name == "Test"

    def test_pydantic_model_with_enum_value(self) -> None:
        """Test Pydantic model with enum value."""
        model = self.ColorModel(color="red", name="Test")  # type: ignore[arg-type]
        assert model.color == Color.RED

    def test_pydantic_model_with_case_insensitive_value(self) -> None:
        """Test Pydantic model with case-insensitive enum value."""
        model1 = self.ColorModel(color="RED", name="Test1")  # type: ignore[arg-type]
        assert model1.color == Color.RED

        model2 = self.ColorModel(color="Red", name="Test2")  # type: ignore[arg-type]
        assert model2.color == Color.RED

        model3 = self.ColorModel(color="rEd", name="Test3")  # type: ignore[arg-type]
        assert model3.color == Color.RED

    def test_pydantic_model_with_invalid_enum_value_raises_error(self) -> None:
        """Test Pydantic model with invalid enum value raises ValidationError."""
        with pytest.raises(ValidationError):
            self.ColorModel(color="purple", name="Test")  # type: ignore[arg-type]

    def test_pydantic_model_serialization(self) -> None:
        """Test Pydantic model serialization."""
        model = self.ColorModel(color=Color.BLUE, name="Test")
        data = model.model_dump()
        assert data["color"] == "blue"
        assert data["name"] == "Test"

    def test_pydantic_model_json_serialization(self) -> None:
        """Test Pydantic model JSON serialization."""
        model = self.ColorModel(color=Color.GREEN, name="TestJSON")
        json_str = model.model_dump_json()
        data = json.loads(json_str)
        assert data["color"] == "green"
        assert data["name"] == "TestJSON"

    def test_pydantic_model_from_dict(self) -> None:
        """Test creating Pydantic model from dict."""
        data = {"color": "yellow", "name": "FromDict"}
        model = self.ColorModel.model_validate(data)
        assert model.color == Color.YELLOW
        assert model.name == "FromDict"

    def test_pydantic_model_from_json(self) -> None:
        """Test creating Pydantic model from JSON."""
        json_str = '{"color": "BLUE", "name": "FromJSON"}'
        model = self.ColorModel.model_validate_json(json_str)
        assert model.color == Color.BLUE
        assert model.name == "FromJSON"

    def test_pydantic_model_roundtrip(self) -> None:
        """Test roundtrip serialization and deserialization."""
        original = self.ColorModel(color=Color.RED, name="Roundtrip")
        json_str = original.model_dump_json()
        restored = self.ColorModel.model_validate_json(json_str)
        assert restored.color == original.color
        assert restored.name == original.name

    def test_pydantic_json_schema(self) -> None:
        """Test Pydantic JSON schema generation."""
        schema = self.ColorModel.model_json_schema()
        color_schema = schema["$defs"]["Color"]

        # Check that the schema includes all enum members
        assert "enum" in color_schema
        assert set(color_schema["enum"]) == {"red", "green", "blue", "yellow"}
        assert color_schema["type"] == "string"


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_enum_equality(self) -> None:
        """Test enum member equality."""
        assert Color.RED == Color.RED
        assert Color.RED != Color.BLUE
        assert Color.GREEN == Color.GREEN

    def test_enum_in_container(self) -> None:
        """Test enum members in containers."""
        colors = [Color.RED, Color.GREEN, Color.BLUE]
        assert Color.RED in colors
        assert Color.YELLOW not in [Color.RED, Color.GREEN]

    def test_enum_iteration(self) -> None:
        """Test iterating over enum members."""
        colors = list(Color)
        assert len(colors) == 4
        assert Color.RED in colors
        assert Color.GREEN in colors
        assert Color.BLUE in colors
        assert Color.YELLOW in colors

    def test_enum_members_dict(self) -> None:
        """Test accessing enum members dictionary."""
        assert "RED" in Color.__members__
        assert "GREEN" in Color.__members__
        assert "BLUE" in Color.__members__
        assert "YELLOW" in Color.__members__
        assert len(Color.__members__) == 4


class JobStatus(CaseInsensitiveEnum):
    """Job Status."""

    ONHOLD = "On Hold"
    QUEUED = "Queued"
    MUSTHALT = "Must Halt"


class TestJobStatusEnum:
    """Test JobStatus enum with multi-word values."""

    def test_job_status_values(self) -> None:
        """Test JobStatus enum values."""
        assert JobStatus.ONHOLD.value == "On Hold"
        assert JobStatus.QUEUED.value == "Queued"
        assert JobStatus.MUSTHALT.value == "Must Halt"

    def test_job_status_case_insensitive_lookup(self) -> None:
        """Test case-insensitive lookup for JobStatus."""
        assert JobStatus._missing_("onhold") == JobStatus.ONHOLD
        assert JobStatus._missing_("ONHOLD") == JobStatus.ONHOLD
        assert JobStatus._missing_("OnHold") == JobStatus.ONHOLD
        assert JobStatus._missing_("oNhOlD") == JobStatus.ONHOLD

        assert JobStatus._missing_("queued") == JobStatus.QUEUED
        assert JobStatus._missing_("QUEUED") == JobStatus.QUEUED

        assert JobStatus._missing_("musthalt") == JobStatus.MUSTHALT
        assert JobStatus._missing_("MUSTHALT") == JobStatus.MUSTHALT
        assert JobStatus._missing_("must halt") == JobStatus.MUSTHALT
        assert JobStatus._missing_("MUST HALT") == JobStatus.MUSTHALT

    def test_job_status_pydantic_integration(self) -> None:
        """Test JobStatus with Pydantic."""

        class JobModel(BaseModel):
            status: JobStatus
            job_id: int

        model = JobModel(status=JobStatus.QUEUED, job_id=123)
        assert model.status == JobStatus.QUEUED
        assert model.job_id == 123

    def test_job_status_pydantic_case_insensitive(self) -> None:
        """Test JobStatus Pydantic with case-insensitive values."""

        class JobModel(BaseModel):
            status: JobStatus

        model1 = JobModel(status="ONHOLD")  # type: ignore[arg-type]
        assert model1.status == JobStatus.ONHOLD

        model2 = JobModel(status="queued")  # type: ignore[arg-type]
        assert model2.status == JobStatus.QUEUED

        model3 = JobModel(status="Must Halt")  # type: ignore[arg-type]
        assert model3.status == JobStatus.MUSTHALT

    def test_job_status_serialization(self) -> None:
        """Test JobStatus serialization with multi-word values."""

        class JobModel(BaseModel):
            status: JobStatus

        model = JobModel(status=JobStatus.ONHOLD)
        data = model.model_dump()
        assert data["status"] == "On Hold"

    def test_job_status_json_roundtrip(self) -> None:
        """Test JobStatus JSON roundtrip with multi-word values."""

        class JobModel(BaseModel):
            status: JobStatus
            name: str

        original = JobModel(status=JobStatus.MUSTHALT, name="Test Job")
        json_str = original.model_dump_json()
        data = json.loads(json_str)
        assert data["status"] == "Must Halt"

        restored = JobModel.model_validate_json(json_str)
        assert restored.status == JobStatus.MUSTHALT
        assert restored.name == "Test Job"

    def test_job_status_invalid_lookup(self) -> None:
        """Test invalid JobStatus lookups."""
        assert JobStatus._missing_("running") is None
        assert JobStatus._missing_("completed") is None
        assert JobStatus._missing_("on_hold") is None  # underscore instead of space

    def test_job_status_enum_member_comparison(self) -> None:
        """Test JobStatus enum member comparison."""
        assert JobStatus.ONHOLD != JobStatus.QUEUED
        assert JobStatus.QUEUED != JobStatus.MUSTHALT
        assert JobStatus.ONHOLD == JobStatus.ONHOLD

    def test_job_status_in_collection(self) -> None:
        """Test JobStatus members in collections."""
        statuses = {JobStatus.ONHOLD, JobStatus.QUEUED}
        assert JobStatus.ONHOLD in statuses
        assert JobStatus.MUSTHALT not in statuses

    def test_multiple_enum_types(self) -> None:
        """Test that different enum types don't interfere."""

        class MultiModel(BaseModel):
            color: Color
            status: JobStatus

        model = MultiModel(
            color="RED",  # type: ignore[arg-type]
            status="QUEUED",  # type: ignore[arg-type]
        )
        assert model.color == Color.RED
        assert model.status == JobStatus.QUEUED

        # Verify they are distinct types
        assert model.color != model.status
        assert type(model.color) is not type(model.status)
