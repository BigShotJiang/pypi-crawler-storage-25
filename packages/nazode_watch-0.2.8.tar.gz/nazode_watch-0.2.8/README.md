# Nazode Watch

**[日本語](#日本語) | [English](#english) | [中文](#中文)**

---

## 日本語

バックグラウンドで動くAIデーモン。コードをコピーしたりファイルを保存するだけで、自動的にAIがエラーを解析・コードをレビューします。

**必要なもの:** [Ollama](https://ollama.ai)

### インストール

```bash
pip install nazode-watch
ollama pull qwen2.5-coder:1.5b
```

### 使い方

```bash
nazode-watch start          # バックグラウンドで起動
nazode-watch stop           # 停止
nazode-watch status         # 状態確認
nazode-watch log            # 直近のログを表示
nazode-watch web            # ブラウザでログを確認 (localhost:8888)
nazode-watch install-hook   # Git pre-commitフックをインストール
nazode-watch config         # 設定を編集
```

### 機能

| 機能 | 説明 |
|------|------|
| クリップボード監視 | エラーやコードをコピーすると自動でAI解析・通知 |
| URL自動要約 | URLをコピーすると「何のサイトか」を自動要約 |
| ファイル保存監視 | コードファイルを保存するたびにAIがレビュー（20言語+） |
| ログ Web UI | localhost:8888 でブラウザからログを確認 |
| 日次サマリー | 毎朝9時に前日の統計を通知 |
| Git pre-commit | コミット前にAIが自動チェック |
| スクリーンショット | 5分ごとに作業ログを自動保存（直近30枚） |

### 設定

`~/.nazode/watch/config.json`:

```json
{
  "watch_paths": ["~/projects"],
  "clipboard": true,
  "file_review": true,
  "screenshot_log": true,
  "daily_summary": true,
  "model": "qwen2.5-coder:1.5b"
}
```

### macOS 権限

`システム設定 > プライバシーとセキュリティ` で以下を許可:
- **アクセシビリティ** (クリップボード監視)
- **画面収録** (スクリーンショット)
- **通知** (AI解析結果の通知)

---

## English

A background AI daemon. Just copy code or save a file — AI automatically analyzes errors and reviews your code.

**Requirements:** [Ollama](https://ollama.ai)

### Installation

```bash
pip install nazode-watch
ollama pull qwen2.5-coder:1.5b
```

Windows:
```bash
pip install nazode-watch[windows]
```

### Usage

```bash
nazode-watch start          # Start background daemon
nazode-watch stop           # Stop daemon
nazode-watch status         # Check status
nazode-watch log            # Show recent logs
nazode-watch web            # Open log viewer in browser (localhost:8888)
nazode-watch install-hook   # Install Git pre-commit hook
nazode-watch config         # Edit config file
```

### Features

| Feature | Description |
|---------|-------------|
| Clipboard monitor | Copies an error or code → instant AI analysis + notification |
| URL summarizer | Copies a URL → auto-fetch and summarize what the site is |
| File save monitor | Saves a code file → automatic AI review (20+ languages) |
| Log Web UI | View logs in browser at localhost:8888, auto-refreshes every 5s |
| Daily summary | Every morning at 9:00, get yesterday's stats as a notification |
| Git pre-commit | AI checks staged files before every commit |
| Screenshot log | Auto-saves screenshots every 5 min (keeps latest 30) |

### Configuration

`~/.nazode/watch/config.json`:

```json
{
  "watch_paths": ["~/projects"],
  "clipboard": true,
  "file_review": true,
  "screenshot_log": true,
  "daily_summary": true,
  "model": "qwen2.5-coder:1.5b"
}
```

### macOS Permissions

Go to `System Settings > Privacy & Security` and allow:
- **Accessibility** (clipboard monitoring)
- **Screen Recording** (screenshots)
- **Notifications** (AI analysis results)

### Platform Support

| OS | Status |
|----|--------|
| macOS | Supported |
| Linux | Supported (xclip/xsel, notify-send, scrot) |
| Windows | Beta (`pip install nazode-watch[windows]`) |

---

## 中文

后台运行的AI守护进程。只需复制代码或保存文件，AI就会自动分析错误并进行代码审查。

**必要条件:** [Ollama](https://ollama.ai)

### 安装

```bash
pip install nazode-watch
ollama pull qwen2.5-coder:1.5b
```

Windows 用户:
```bash
pip install nazode-watch[windows]
```

### 使用方法

```bash
nazode-watch start          # 在后台启动
nazode-watch stop           # 停止
nazode-watch status         # 检查状态
nazode-watch log            # 查看最近日志
nazode-watch web            # 在浏览器中查看日志 (localhost:8888)
nazode-watch install-hook   # 安装 Git pre-commit 钩子
nazode-watch config         # 编辑配置文件
```

### 功能

| 功能 | 说明 |
|------|------|
| 剪贴板监控 | 复制错误或代码 → 自动AI分析并发送通知 |
| URL自动摘要 | 复制URL → 自动获取并总结网站内容 |
| 文件保存监控 | 保存代码文件 → 自动AI审查（支持20+语言） |
| 日志Web界面 | 在浏览器 localhost:8888 查看日志，每5秒自动刷新 |
| 每日摘要 | 每天早上9点推送前一天的统计通知 |
| Git pre-commit | 每次提交前AI自动检查暂存文件 |
| 截图日志 | 每5分钟自动保存截图（保留最新30张） |

### 配置

`~/.nazode/watch/config.json`:

```json
{
  "watch_paths": ["~/projects"],
  "clipboard": true,
  "file_review": true,
  "screenshot_log": true,
  "daily_summary": true,
  "model": "qwen2.5-coder:1.5b"
}
```

### macOS 权限设置

前往 `系统设置 > 隐私与安全性` 允许以下权限:
- **辅助功能** (剪贴板监控)
- **屏幕录制** (截图)
- **通知** (AI分析结果通知)

### 平台支持

| 系统 | 状态 |
|------|------|
| macOS | 支持 |
| Linux | 支持 (xclip/xsel, notify-send, scrot) |
| Windows | Beta (`pip install nazode-watch[windows]`) |

---

## License

MIT
