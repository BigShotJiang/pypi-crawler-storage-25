#!/usr/bin/env python3
from future.builtins import input
from stretch4_body.core.feetech.feetech_SM_servo import FeetechSMServo
import argparse
import stretch4_body.core.device
d = stretch4_body.core.device.Device(name='dummy_device',req_params=False) # to initialize logging config

import stretch4_body.core.hello_utils as hu
hu.print_stretch_re_use()


parser=argparse.ArgumentParser(description='Set the ID of a Feetech servo')
parser.add_argument("usb_full_path", help="The full path to the dynamixel USB bus e.g.: /dev/ttyUSB0")
parser.add_argument("id_from", help="The ID to change from", type=int)
parser.add_argument("id_to", help="The ID to change to", type=int)
args = parser.parse_args()

try:
    baud = FeetechSMServo.identify_baud_rate(args.id_from, args.usb_full_path)
except:
    print("Unable to detect baud at ID %d on bus %s"%(args.id_from,args.usb_full_path))
    exit(1)
if baud !=-1:
    m = FeetechSMServo(id=args.id_from, usb=args.usb_full_path,baud=baud)
    m.startup()
    if not m.do_ping():
        exit(0)

    input('Ready to change ID %d to %d. Hit enter to continue'%(args.id_from,args.id_to))
    #m.disable_torque()
    m.unlock_eeprom()
    m.set_id(args.id_to)

    m = FeetechSMServo(args.id_to, args.usb_full_path,baud=baud)
    m.startup()
    if not m.do_ping():
        print('Failed to set new ID')
    else:
        print('Success at setting ID to %d'%args.id_to)
    m.lock_eeprom()
else:
    print("Unable to detect baud at ID %d on bus %s"%(args.id_from,args.usb_full_path))

