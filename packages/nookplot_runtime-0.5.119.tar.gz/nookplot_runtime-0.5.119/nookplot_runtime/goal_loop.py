"""Goal loop — L3 step-by-step execution engine for goal-driven agents.

Python parity with ``runtime/src/goal/goalLoop.ts``. Invoked by
``AutonomousAgent._maybe_bootstrap_goal()`` when an agent was forged with
an ``initial_goal`` set (typically via an L1 swarm suggestion).

Design choices (see ROADMAP_orchestrator-swarm-autodeploy.md §3):
  - Atomic goals, no project decomposition (v1 simplification)
  - Budget is soft — the real gate is owner NOOK balance
  - 3 reformulations of the same step → blocked_stuck
  - 3 consecutive no-ops → treat as complete
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from .doom_loop import (
    ToolCallSignature,
    _hash_args,
    build_corrective_prompt,
    check_for_doom_loop_from_signatures,
)

logger = logging.getLogger("nookplot.goal_loop")

DOOM_LOOP_MAX_TRIGGERS = 3
DOOM_LOOP_SIGNATURE_WINDOW = 30

# ---------------------------------------------------------------------------
#  Prompts (kept in sync with runtime/src/goal/goalPrompts.ts)
# ---------------------------------------------------------------------------

GOAL_STEP_SYSTEM_PROMPT = """You are an autonomous Nookplot agent working on a specific goal. Each turn, you choose the single next action that moves you toward completion.

You have access to tools including web_search (search the live web), search_knowledge (query your KG + mining traces + network), egress_request (call external APIs), and publishing actions.

Your decision each turn is ONE of:

1. Execute an action — return { "type": "action", "action_name": "...", "action_params": {...}, "description": "..." }
2. Complete the goal — return { "type": "complete", "title": "...", "body": "<final markdown artifact>", "domain": "<short topic>", "description": "..." }
3. Declare no-op — return { "type": "noop", "description": "..." }  (use sparingly; 3 consecutive no-ops ends the goal)
4. Declare capability gap — return { "type": "needs_capability", "description": "...", "suggested_preset": "..." | null }

Rules:
- Be concise and focused. Do NOT explore beyond the goal.
- Cite sources in the body when using web_search results.
- Prefer search_knowledge (free) before web_search (costs credits) for anything that might be in the knowledge graph.
- You have a hard cap of 20 steps. Do not waste them.
- If the goal is ambiguous, interpret narrowly — complete a narrow version rather than wandering broadly.
- Budget is a soft cap — stay under if you can, but the goal matters more than the estimate.
- When finished, ALWAYS return type "complete" with the deliverable in "body". Do NOT keep iterating after the goal is achieved.

Return only valid JSON. No prose outside the JSON block."""


def build_goal_step_user_prompt(
    goal: str,
    previous_steps: list[dict[str, Any]],
    spent_nook: int,
    budget_nook: int,
) -> str:
    """Build the per-step user prompt for the LLM."""
    if not previous_steps:
        steps_text = "(no previous steps)"
    else:
        tail = previous_steps[-8:]
        steps_text = "\n".join(
            f"{i + 1}. {s.get('action_type') or '?'}: {(s.get('output_summary') or '')[:180]}"
            for i, s in enumerate(tail)
        )

    return (
        f"Goal: {goal}\n\n"
        f"Previous steps:\n{steps_text}\n\n"
        f"Spent so far: {spent_nook} / {budget_nook} NOOK (soft cap)\n\n"
        "Choose the next action. Return JSON only."
    )


# ---------------------------------------------------------------------------
#  Decision parsing
# ---------------------------------------------------------------------------

_JSON_BLOCK_RE = re.compile(r"\{[\s\S]*\}")


def parse_goal_action(content: str) -> dict[str, Any] | None:
    """Parse a goal action from an LLM response.

    Tolerant to prose wrapping the JSON block. Returns a dict with the
    normalized shape used by ``GoalLoop``, or ``None`` if no valid
    action can be extracted.
    """
    if not content:
        return None
    match = _JSON_BLOCK_RE.search(content)
    if not match:
        return None
    try:
        parsed = json.loads(match.group(0))
    except Exception:
        return None
    if not isinstance(parsed, dict):
        return None

    decision_type = parsed.get("type")
    if not isinstance(decision_type, str):
        return None

    if decision_type == "action":
        action_name = parsed.get("action_name")
        if not isinstance(action_name, str) or not action_name:
            return None
        action_params = parsed.get("action_params")
        if not isinstance(action_params, dict):
            action_params = {}
        description = parsed.get("description")
        if not isinstance(description, str):
            description = action_name
        return {
            "type": "action",
            "action_name": action_name,
            "action_params": action_params,
            "description": description,
        }

    if decision_type == "complete":
        title = parsed.get("title")
        body = parsed.get("body")
        if not isinstance(title, str) or not title or not isinstance(body, str) or not body:
            return None
        domain = parsed.get("domain") if isinstance(parsed.get("domain"), str) else "general"
        description = parsed.get("description") if isinstance(parsed.get("description"), str) else "complete"
        return {
            "type": "complete",
            "title": title,
            "body": body,
            "domain": domain,
            "description": description,
        }

    if decision_type == "noop":
        description = parsed.get("description") if isinstance(parsed.get("description"), str) else "noop"
        return {"type": "noop", "description": description}

    if decision_type == "needs_capability":
        description = parsed.get("description")
        if not isinstance(description, str) or not description:
            return None
        suggested_preset = parsed.get("suggested_preset") if isinstance(parsed.get("suggested_preset"), str) else None
        return {
            "type": "needs_capability",
            "description": description,
            "suggested_preset": suggested_preset,
        }

    return None


# ---------------------------------------------------------------------------
#  Goal result dataclasses
# ---------------------------------------------------------------------------


@dataclass
class GoalResult:
    """Terminal state of a GoalLoop.run() invocation.

    ``outcome`` is one of: complete, blocked_budget, blocked_stuck, blocked_capability.
    """

    outcome: str
    spent_nook: int = 0
    steps_executed: int = 0
    artifact: dict[str, str] | None = None  # for complete
    stuck_reason: str | None = None  # for blocked_stuck
    capability_needed: str | None = None  # for blocked_capability
    suggested_preset: str | None = None  # for blocked_capability


# ---------------------------------------------------------------------------
#  Loop
# ---------------------------------------------------------------------------


# Type alias for the inference caller — matches the keyword-arg style we use.
# Returns (content, cost_nook). cost_nook is optional and defaults to 0.
InferenceCall = Callable[..., Awaitable[tuple[str, int]]]


@dataclass
class GoalLoopOptions:
    """Configuration for a single run of the GoalLoop."""

    runtime: Any
    goal: str
    budget_nook: int
    parent_swarm_id: str | None = None
    max_steps: int = 20
    max_consecutive_noops: int = 3
    max_reformulations: int = 3
    verbose: bool = False
    inference_call: InferenceCall | None = None


class GoalLoop:
    """Step-by-step autonomous execution of a single goal."""

    def __init__(self, options: GoalLoopOptions) -> None:
        self._opts = options
        self._recent_steps: list[dict[str, Any]] = []
        self._spent_nook = 0
        self._steps_executed = 0
        self._tool_signatures: list[ToolCallSignature] = []
        self._doom_loop_triggers = 0
        self._doom_loop_note: str | None = None

    async def run(self) -> GoalResult:
        """Run the loop to completion. Returns exactly one of four outcomes."""
        consecutive_noops = 0
        same_step_repetitions = 0
        last_step_description = ""

        for step in range(self._opts.max_steps):
            decision = await self._ask_llm_for_next_action()
            if decision is None:
                consecutive_noops += 1
                if consecutive_noops >= self._opts.max_consecutive_noops:
                    return self._finalize_fallback("LLM returned unparseable output 3x")
                continue

            decision_type = decision["type"]

            # Termination: complete
            if decision_type == "complete":
                return GoalResult(
                    outcome="complete",
                    artifact={
                        "title": decision["title"][:200],
                        "body": decision["body"][:80_000],
                        "domain": decision.get("domain", "general")[:120],
                    },
                    steps_executed=self._steps_executed,
                    spent_nook=self._spent_nook,
                )

            # Termination: capability gap
            if decision_type == "needs_capability":
                return GoalResult(
                    outcome="blocked_capability",
                    capability_needed=decision["description"][:1000],
                    suggested_preset=decision.get("suggested_preset"),
                    spent_nook=self._spent_nook,
                )

            # Stuck detection
            description = decision.get("description", "")
            if description == last_step_description:
                same_step_repetitions += 1
                if same_step_repetitions >= self._opts.max_reformulations:
                    return GoalResult(
                        outcome="blocked_stuck",
                        stuck_reason=description[:1000],
                        spent_nook=self._spent_nook,
                    )
            else:
                same_step_repetitions = 0
            last_step_description = description

            # No-op
            if decision_type == "noop":
                consecutive_noops += 1
                if consecutive_noops >= self._opts.max_consecutive_noops:
                    return self._finalize_fallback("agent returned 3 no-ops in a row")
                await self._record_step_remotely(step + 1, "noop", description, "", 0)
                continue
            consecutive_noops = 0

            # Execute the action
            exec_result = await self._execute_action(decision)
            self._spent_nook += max(0, int(exec_result.get("cost_nook", 0)))
            self._steps_executed += 1

            self._recent_steps.append({
                "step_number": step + 1,
                "action_type": decision["action_name"],
                "output_summary": exec_result.get("output", ""),
            })
            if len(self._recent_steps) > 16:
                self._recent_steps.pop(0)

            await self._record_step_remotely(
                step + 1,
                decision["action_name"],
                description,
                exec_result.get("output", ""),
                int(exec_result.get("cost_nook", 0)),
            )

            # Track tool-call signature for doom-loop detection. A triggered
            # offender injects a corrective prompt for the next turn; 3 triggers
            # in one goal short-circuits to blocked_stuck (terminal state that
            # already exists — see description-repetition check above).
            self._tool_signatures.append(ToolCallSignature(
                name=decision["action_name"],
                args_hash=_hash_args(decision.get("action_params", {})),
            ))
            if len(self._tool_signatures) > DOOM_LOOP_SIGNATURE_WINDOW:
                self._tool_signatures = self._tool_signatures[-DOOM_LOOP_SIGNATURE_WINDOW:]

            offender = check_for_doom_loop_from_signatures(self._tool_signatures)
            if offender:
                self._doom_loop_triggers += 1
                if self._doom_loop_triggers >= DOOM_LOOP_MAX_TRIGGERS:
                    return GoalResult(
                        outcome="blocked_stuck",
                        stuck_reason=(
                            f"doom loop on '{offender}' "
                            f"({self._doom_loop_triggers} triggers)"
                        )[:1000],
                        spent_nook=self._spent_nook,
                    )
                self._doom_loop_note = build_corrective_prompt(offender)

            if self._spent_nook > self._opts.budget_nook and self._opts.verbose:
                logger.warning(
                    "[goal_loop] over soft budget: spent=%d budget=%d",
                    self._spent_nook, self._opts.budget_nook,
                )

        # Hit max steps without completing — fallback artifact
        return self._finalize_fallback(f"hit maxSteps cap ({self._opts.max_steps})")

    # -----------------------------------------------------------------------
    #  Private helpers
    # -----------------------------------------------------------------------

    async def _ask_llm_for_next_action(self) -> dict[str, Any] | None:
        """Call the LLM and parse the JSON decision."""
        try:
            user_prompt = build_goal_step_user_prompt(
                self._opts.goal, self._recent_steps, self._spent_nook, self._opts.budget_nook,
            )
            if self._doom_loop_note:
                user_prompt = f"{self._doom_loop_note}\n\n---\n\n{user_prompt}"
                self._doom_loop_note = None
            content, cost = await self._invoke_inference(
                system_prompt=GOAL_STEP_SYSTEM_PROMPT,
                user_prompt=user_prompt,
                max_tokens=1024,
                temperature=0.5,
            )
            self._spent_nook += max(0, int(cost))
            return parse_goal_action(content)
        except Exception as exc:
            if self._opts.verbose:
                logger.exception("[goal_loop] LLM call failed: %s", exc)
            return None

    async def _invoke_inference(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int,
        temperature: float,
    ) -> tuple[str, int]:
        """Invoke the LLM via the configured caller.

        Consumers provide ``inference_call`` in GoalLoopOptions. No default
        caller is attempted — Python runtimes typically wire inference
        themselves (via BYOK Anthropic, OpenAI, Ollama, etc).
        """
        if self._opts.inference_call is None:
            raise RuntimeError(
                "GoalLoop requires an inference_call — Python runtime does not "
                "ship a default inference path. Pass one via GoalLoopOptions."
            )
        return await self._opts.inference_call(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
        )

    async def _execute_action(self, action: dict[str, Any]) -> dict[str, Any]:
        """Execute one action via the runtime's action dispatch pipeline.

        All actions go through ``POST /v1/actions/execute``. Sign-required
        on-chain actions are NOT auto-signed here — the goal loop v1 focuses
        on off-chain research/synthesis tools. If the LLM requests an
        on-chain action, we return a stub output so the loop continues.
        """
        runtime = self._opts.runtime
        http = getattr(runtime, "_http", None)
        if http is None:
            return {"ok": False, "output": "runtime has no _http client", "cost_nook": 0}

        try:
            dispatch_result = await http.request(
                "POST",
                "/v1/actions/execute",
                {
                    "toolName": f"nookplot_{action['action_name']}",
                    "payload": action.get("action_params", {}),
                },
            )
        except Exception as exc:
            return {"ok": False, "output": str(exc)[:500], "cost_nook": 0}

        if not isinstance(dispatch_result, dict):
            return {"ok": True, "output": str(dispatch_result)[:500], "cost_nook": 0}

        status = dispatch_result.get("status", "completed")
        if status == "error":
            return {
                "ok": False,
                "output": str(dispatch_result.get("error", "action failed"))[:500],
                "cost_nook": 0,
            }
        if status == "sign_required":
            return {
                "ok": True,
                "output": f"[sign_required] {action['action_name']} — skipped in goal loop v1",
                "cost_nook": 0,
            }

        result = dispatch_result.get("result")
        if isinstance(result, str):
            output_text = result
        else:
            try:
                output_text = json.dumps(result)
            except Exception:
                output_text = str(result)

        return {
            "ok": True,
            "output": output_text[:500],
            "cost_nook": int(dispatch_result.get("costNook", 0) or 0),
        }

    async def _record_step_remotely(
        self,
        step_number: int,
        action_type: str | None,
        input_summary: str,
        output_summary: str,
        cost_nook: int,
    ) -> None:
        """Best-effort step recording — non-fatal on failure."""
        try:
            await self._opts.runtime.identity.record_goal_step(
                step_number=step_number,
                action_type=action_type,
                input_summary=input_summary[:500],
                output_summary=output_summary[:500],
                nook_spent=max(0, int(cost_nook)),
            )
        except Exception as exc:
            if self._opts.verbose:
                logger.debug("[goal_loop] record_goal_step failed: %s", exc)

    def _finalize_fallback(self, reason: str) -> GoalResult:
        """Treat the current state as a completed goal (fallback artifact)."""
        if not self._recent_steps:
            body = f"Goal loop terminated: {reason}.\n\nNo progress was made on: {self._opts.goal}"
        else:
            step_lines = "\n".join(
                f"{i + 1}. **{s.get('action_type') or '?'}** — {(s.get('output_summary') or '')[:200]}"
                for i, s in enumerate(self._recent_steps)
            )
            body = (
                f"# Goal Progress\n\n"
                f"**Goal:** {self._opts.goal}\n\n"
                f"**Termination:** {reason}\n\n"
                f"**Steps executed:** {self._steps_executed}\n\n"
                f"## Recent steps\n\n{step_lines}"
            )
        return GoalResult(
            outcome="complete",
            artifact={
                "title": self._opts.goal[:200],
                "body": body,
                "domain": "goal-fallback",
            },
            steps_executed=self._steps_executed,
            spent_nook=self._spent_nook,
        )
