"""Tests for MiningManager — Python parity with runtime/src/__tests__/mining.test.ts."""
from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from nookplot_runtime.mining import (
    ChallengeSummary,
    MiningManager,
    TrackResult,
    track_of,
)


# ── Mock builders ─────────────────────────────────────────────────────


def make_http(handler):
    http = MagicMock()
    http.request = AsyncMock(side_effect=handler)
    return http


def make_economy(content: str = "x" * 200):
    economy = MagicMock()
    economy.inference = AsyncMock(return_value={"content": content})
    return economy


def setup_responses(knowledge_ids=None, rlm_ids=None, embed_ids=None):
    knowledge_ids = list(knowledge_ids or [])
    rlm_ids = list(rlm_ids or [])
    embed_ids = list(embed_ids or [])

    async def handler(method, path, body=None):
        if method == "GET" and path.startswith("/v1/mining/earnings-preview"):
            return {
                "tracks": [
                    {"track": "knowledge", "openCount": len(knowledge_ids)},
                    {"track": "embedding", "openCount": len(embed_ids)},
                    {"track": "rlm",       "openCount": len(rlm_ids)},
                ]
            }
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open&sourceType=rlm_trajectory"):
            return {
                "challenges": [
                    {
                        "id": cid, "title": f"RLM {i}", "difficulty": "medium",
                        "estimatedRewardNook": 50_000, "sourceType": "rlm_trajectory",
                        "closesAt": "2030-01-01T00:00:00Z",
                    } for i, cid in enumerate(rlm_ids)
                ]
            }
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open"):
            return {
                "challenges": [
                    {
                        "id": cid, "title": f"Knowledge {i}",
                        "difficulty": "expert" if i == 0 else "easy",
                        "estimatedRewardNook": 100_000 - i * 1000,
                        "sourceType": "agent_authored",
                        "closesAt": "2030-01-01T00:00:00Z",
                    } for i, cid in enumerate(knowledge_ids)
                ]
            }
        if method == "GET" and path.startswith("/v1/mining/embedding-challenges?status=open"):
            return {
                "challenges": [
                    {
                        "id": cid, "title": f"Embedding {i}",
                        "difficulty": "easy",
                        "estimatedRewardNook": 5_000,
                        "sourceType": "embedding_generation",
                        "closesAt": "2030-01-01T00:00:00Z",
                    } for i, cid in enumerate(embed_ids)
                ]
            }
        if method == "GET" and path.startswith("/v1/mining/embedding-challenges/"):
            return {"prompts": ["a", "b"], "dimensions": 768}
        if method == "POST" and path.startswith("/v1/mining/submissions/"):
            return {"submissionId": f"sub-{path.split('/')[-1]}"}
        if method == "POST" and "/v1/mining/embedding-challenges/" in path and path.endswith("/submit"):
            return {"submissionId": "embed-sub"}
        raise AssertionError(f"Unmocked request: {method} {path}")

    return handler


# ── track_of ──────────────────────────────────────────────────────────


def test_track_of_classifies_known_source_types():
    assert track_of("embedding_generation") == "embedding"
    assert track_of("rlm_trajectory") == "rlm"
    assert track_of("rlm_audit") == "rlm"
    assert track_of("agent_authored") == "knowledge"
    assert track_of("paper_reproduction") == "knowledge"


# ── run_once ──────────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_run_once_submits_highest_ranked_knowledge_challenge():
    http = make_http(setup_responses(knowledge_ids=["k1", "k2"]))
    economy = make_economy()
    manager = MiningManager(http, economy)
    results = await manager.run_once(tracks=["knowledge"])
    assert len(results) == 1
    assert results[0].track == "knowledge"
    assert results[0].status == "submitted"
    # k1 is "expert" difficulty so it ranks above k2.
    assert results[0].challenge_id == "k1"
    economy.inference.assert_awaited_once()


@pytest.mark.asyncio
async def test_run_once_dry_run_does_not_submit():
    http = make_http(setup_responses(knowledge_ids=["k1"]))
    economy = make_economy()
    manager = MiningManager(http, economy)
    results = await manager.run_once(tracks=["knowledge"], dry_run=True)
    assert results[0].status == "skipped"
    assert results[0].reason == "dry-run"
    posts = [c for c in http.request.call_args_list if c.args[0] == "POST"]
    assert posts == []


@pytest.mark.asyncio
async def test_run_once_returns_empty_when_no_open_challenges():
    http = make_http(setup_responses())
    economy = make_economy()
    manager = MiningManager(http, economy)
    results = await manager.run_once(tracks=["knowledge", "embedding", "rlm"])
    assert results == []


@pytest.mark.asyncio
async def test_run_once_isolates_per_track_failures():
    async def handler(method, path, body=None):
        if method == "GET" and path.startswith("/v1/mining/embedding-challenges?"):
            raise RuntimeError("embedding endpoint exploded")
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open&sourceType=rlm_trajectory"):
            return {"challenges": []}
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open"):
            return {
                "challenges": [{
                    "id": "k1", "title": "K", "difficulty": "easy",
                    "estimatedRewardNook": 1000, "sourceType": "agent_authored",
                    "closesAt": "2030-01-01T00:00:00Z",
                }]
            }
        if method == "POST" and path.startswith("/v1/mining/submissions/"):
            return {"submissionId": "sub-k1"}
        raise AssertionError(f"unexpected {method} {path}")

    http = make_http(handler)
    economy = make_economy()
    manager = MiningManager(http, economy)
    results = await manager.run_once(tracks=["knowledge", "embedding"])
    assert len(results) == 1
    assert results[0].track == "knowledge"
    assert results[0].status == "submitted"


@pytest.mark.asyncio
async def test_run_once_auto_resolves_tracks_via_earnings_preview():
    http = make_http(setup_responses(knowledge_ids=["k1"]))
    economy = make_economy()
    manager = MiningManager(http, economy)
    results = await manager.run_once(tracks="auto")
    assert results[0].track == "knowledge"
    preview_calls = [c for c in http.request.call_args_list if c.args[1].startswith("/v1/mining/earnings-preview")]
    assert preview_calls, "expected earnings-preview to be queried for auto resolution"


@pytest.mark.asyncio
async def test_run_once_skips_embedding_without_callback():
    http = make_http(setup_responses(embed_ids=["e1"]))
    economy = make_economy()
    manager = MiningManager(http, economy)
    results = await manager.run_once(tracks=["embedding"])
    assert results[0].track == "embedding"
    assert results[0].status == "skipped"
    assert "generate_embeddings" in (results[0].reason or "")


@pytest.mark.asyncio
async def test_run_once_submits_embedding_with_callback():
    http = make_http(setup_responses(embed_ids=["e1"]))
    economy = make_economy()
    manager = MiningManager(http, economy)
    captured = {}

    async def gen_embed(prompts, dimensions):
        captured["prompts"] = prompts
        captured["dimensions"] = dimensions
        return [[0.1] * 768, [0.2] * 768]

    results = await manager.run_once(tracks=["embedding"], generate_embeddings=gen_embed)
    assert results[0].status == "submitted"
    assert captured == {"prompts": ["a", "b"], "dimensions": 768}


@pytest.mark.asyncio
async def test_run_once_rlm_skipped_by_default_uses_callback_when_provided():
    http = make_http(setup_responses(rlm_ids=["r1"]))
    economy = make_economy()
    manager = MiningManager(http, economy)
    default_results = await manager.run_once(tracks=["rlm"])
    assert default_results[0].status == "skipped"
    assert "RLM" in (default_results[0].reason or "")

    async def solve_rlm(challenge, _economy):
        return TrackResult(
            track="rlm", challenge_id=challenge.id,
            status="submitted", submission_id="rlm-sub",
        )

    custom_results = await manager.run_once(tracks=["rlm"], solve_rlm=solve_rlm)
    assert custom_results[0].status == "submitted"


# ── start / session lifecycle ─────────────────────────────────────────


@pytest.mark.asyncio
async def test_start_once_drains_queue_and_resolves_done():
    call_count = {"n": 0}

    async def handler(method, path, body=None):
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open&sourceType=rlm_trajectory"):
            return {"challenges": []}
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open"):
            call_count["n"] += 1
            if call_count["n"] == 1:
                return {
                    "challenges": [{
                        "id": "k1", "title": "K", "difficulty": "easy",
                        "estimatedRewardNook": 1000, "sourceType": "agent_authored",
                        "closesAt": "2030-01-01T00:00:00Z",
                    }]
                }
            return {"challenges": []}
        if method == "POST" and path.startswith("/v1/mining/submissions/"):
            return {"submissionId": "sub-k1"}
        raise AssertionError(f"unexpected {method} {path}")

    http = make_http(handler)
    economy = make_economy()
    manager = MiningManager(http, economy)
    session = await manager.start(tracks=["knowledge"], once=True, tick_interval_seconds=0.001)
    await session.done
    stats = session.stats()
    assert stats.submitted == 1
    assert stats.by_track["knowledge"].submitted == 1


@pytest.mark.asyncio
async def test_start_respects_max_credits():
    counter = {"n": 0}

    async def handler(method, path, body=None):
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open&sourceType=rlm_trajectory"):
            return {"challenges": []}
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open"):
            counter["n"] += 1
            return {
                "challenges": [{
                    "id": f"k{counter['n']}", "title": "K", "difficulty": "easy",
                    "estimatedRewardNook": 1000, "sourceType": "agent_authored",
                    "closesAt": "2030-01-01T00:00:00Z",
                }]
            }
        if method == "POST" and path.startswith("/v1/mining/submissions/"):
            return {"submissionId": "sub"}
        raise AssertionError(f"unexpected {method} {path}")

    http = make_http(handler)
    economy = make_economy()
    manager = MiningManager(http, economy)
    session = await manager.start(
        tracks=["knowledge"],
        max_credits=100,  # each knowledge solve charges 50 → ≥2 solves before budget gate trips
        tick_interval_seconds=0.001,
    )
    await asyncio.sleep(0.15)
    await session.stop()
    stats = session.stats()
    assert stats.credits_spent >= 100
    assert stats.submitted >= 2


@pytest.mark.asyncio
async def test_start_rejects_concurrent_session():
    http = make_http(setup_responses())
    economy = make_economy()
    manager = MiningManager(http, economy)
    session = await manager.start(tracks=["knowledge"], tick_interval_seconds=0.01)
    with pytest.raises(RuntimeError, match="already active"):
        await manager.start(tracks=["knowledge"])
    await session.stop()


@pytest.mark.asyncio
async def test_start_dry_run_counts_separately_from_real_skips():
    # Drains after one tick — real gateway moves claimed challenges out of the
    # open list; the mock simulates that so once-mode doesn't loop forever.
    counter = {"n": 0}

    async def handler(method, path, body=None):
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open&sourceType=rlm_trajectory"):
            return {"challenges": []}
        if method == "GET" and path.startswith("/v1/mining/challenges?status=open"):
            counter["n"] += 1
            if counter["n"] == 1:
                return {"challenges": [{
                    "id": "k1", "title": "K", "difficulty": "easy",
                    "estimatedRewardNook": 1000, "sourceType": "agent_authored",
                    "closesAt": "2030-01-01T00:00:00Z",
                }]}
            return {"challenges": []}
        raise AssertionError(f"unexpected {method} {path}")

    http = make_http(handler)
    economy = make_economy()
    manager = MiningManager(http, economy)
    session = await manager.start(
        tracks=["knowledge"], dry_run=True, once=True, tick_interval_seconds=0.001,
    )
    await session.done
    stats = session.stats()
    assert stats.dry_run == 1
    assert stats.skipped == 0
    assert stats.submitted == 0


@pytest.mark.asyncio
async def test_run_once_explain_emits_rank_lines():
    http = make_http(setup_responses(knowledge_ids=["k1", "k2", "k3"]))
    economy = make_economy()
    manager = MiningManager(http, economy)
    logs: list[str] = []
    await manager.run_once(tracks=["knowledge"], explain=True, log=logs.append)
    rank_lines = [l for l in logs if l.startswith("[mining][rank]")]
    assert rank_lines
    assert "score=" in rank_lines[0]


# ── ChallengeSummary type sanity ──────────────────────────────────────


def test_challenge_summary_is_dataclass_with_track():
    s = ChallengeSummary(
        id="x", track="knowledge", title="t", difficulty="easy",
        estimated_reward_nook=0, domain_tags=[], source_type="agent_authored",
        closes_at="2030-01-01T00:00:00Z",
    )
    assert s.track == "knowledge"
