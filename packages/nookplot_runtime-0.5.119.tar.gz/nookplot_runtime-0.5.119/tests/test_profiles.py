"""
Tests for the Python SDK's load_profile helper.

Parallel to @nookplot/runtime's loadProfile.test.ts and @nookplot/mcp's
auth-profile.test.ts — same resolution order, same backward-compat
guarantees, same fail-open behavior.
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from nookplot_runtime.profiles import (
    load_profile,
    list_profiles,
    resolve_active_profile_name,
)


BASE_CREDS = {
    "apiKey": "nk_" + "a" * 64,
    "privateKey": "0x" + "1" * 64,
    "address": "0xcreator0000000000000000000000000000aaaa",
    "gatewayUrl": "https://gateway.nookplot.com",
    "displayName": "Test Creator",
}


@pytest.fixture
def tmp_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Redirect Path.home() + HOME env to a temp dir and clean env vars."""
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    monkeypatch.setenv("HOME", str(tmp_path))
    # Strip env vars that could leak between tests.
    monkeypatch.delenv("NOOKPLOT_PROFILE", raising=False)
    monkeypatch.delenv("NOOKPLOT_GATEWAY_URL", raising=False)
    return tmp_path


def seed_creds(home: Path) -> None:
    nook = home / ".nookplot"
    nook.mkdir(parents=True, exist_ok=True)
    (nook / "credentials.json").write_text(json.dumps(BASE_CREDS))


def seed_profile(home: Path, name: str, overrides: dict | None = None) -> None:
    prof_dir = home / ".nookplot" / "profiles" / name
    prof_dir.mkdir(parents=True, exist_ok=True)
    data = {
        "scopedAgentAddress": "0x" + name.ljust(40, "f")[:40],
    }
    if overrides:
        data.update(overrides)
    (prof_dir / "profile.json").write_text(json.dumps(data))


# ---------------------------------------------------------------------------
# Default-path backward compat
# ---------------------------------------------------------------------------


class TestLoadProfileDefaultPath:
    def test_returns_none_when_no_credentials_json(self, tmp_home: Path):
        assert load_profile() is None

    def test_returns_flat_creds_when_no_profile_active(self, tmp_home: Path):
        """SDK users who adopt this helper without opting into profiles
        must see a credentials bundle IDENTICAL in all user-visible fields
        to what they'd get from rolling their own JSON read."""
        seed_creds(tmp_home)
        creds = load_profile()
        assert creds is not None
        assert creds["api_key"] == BASE_CREDS["apiKey"]
        assert creds["address"] == BASE_CREDS["address"]
        assert creds["gateway_url"] == BASE_CREDS["gatewayUrl"]
        assert creds["display_name"] == BASE_CREDS["displayName"]
        # Scope fields absent — no opt-in, no scope.
        assert "scoped_agent_address" not in creds or creds.get("scoped_agent_address") is None
        assert "profile_name" not in creds or creds.get("profile_name") is None

    def test_honors_nookplot_gateway_url_override(
        self, tmp_home: Path, monkeypatch: pytest.MonkeyPatch
    ):
        seed_creds(tmp_home)
        monkeypatch.setenv("NOOKPLOT_GATEWAY_URL", "http://127.0.0.1:4321")
        creds = load_profile()
        assert creds["gateway_url"] == "http://127.0.0.1:4321"

    def test_rejects_malformed_credentials_json(self, tmp_home: Path):
        nook = tmp_home / ".nookplot"
        nook.mkdir(parents=True)
        (nook / "credentials.json").write_text("not json at all")
        assert load_profile() is None

    def test_rejects_credentials_missing_required_fields(self, tmp_home: Path):
        nook = tmp_home / ".nookplot"
        nook.mkdir(parents=True)
        (nook / "credentials.json").write_text(json.dumps({"apiKey": "nk_x"}))
        # Missing address/privateKey/gatewayUrl → return None, don't crash.
        assert load_profile() is None


# ---------------------------------------------------------------------------
# Profile scope merging
# ---------------------------------------------------------------------------


class TestLoadProfileScopeMerging:
    def test_merges_scoped_agent_address(self, tmp_home: Path):
        seed_creds(tmp_home)
        seed_profile(tmp_home, "researcher")
        creds = load_profile("researcher")
        assert creds["api_key"] == BASE_CREDS["apiKey"]
        assert creds["scoped_agent_address"].startswith("0xresearcher")
        assert creds["profile_name"] == "researcher"

    def test_falls_back_when_profile_doesnt_exist(self, tmp_home: Path):
        """Stale env vars pointing to deleted profiles should NOT crash
        — they should load creator-direct (same pattern as MCP + CLI)."""
        seed_creds(tmp_home)
        creds = load_profile("ghost")
        assert creds is not None
        assert creds.get("scoped_agent_address") is None

    def test_falls_back_on_malformed_profile_json(self, tmp_home: Path):
        seed_creds(tmp_home)
        prof_dir = tmp_home / ".nookplot" / "profiles" / "broken"
        prof_dir.mkdir(parents=True)
        (prof_dir / "profile.json").write_text("not json at all")
        creds = load_profile("broken")
        assert creds is not None
        assert creds.get("scoped_agent_address") is None

    def test_falls_back_on_profile_missing_scoped_address(self, tmp_home: Path):
        seed_creds(tmp_home)
        prof_dir = tmp_home / ".nookplot" / "profiles" / "incomplete"
        prof_dir.mkdir(parents=True)
        (prof_dir / "profile.json").write_text(json.dumps({"displayName": "x"}))
        creds = load_profile("incomplete")
        assert creds is not None
        assert creds.get("scoped_agent_address") is None

    def test_never_touches_credentials_json(self, tmp_home: Path):
        """Additive-only guarantee: loading a profile must not mutate
        the shared creator credentials file in any way."""
        seed_creds(tmp_home)
        seed_profile(tmp_home, "a")
        before = (tmp_home / ".nookplot" / "credentials.json").read_bytes()
        load_profile("a")
        after = (tmp_home / ".nookplot" / "credentials.json").read_bytes()
        assert before == after


# ---------------------------------------------------------------------------
# resolve_active_profile_name priority order
# ---------------------------------------------------------------------------


class TestResolveActiveProfileName:
    def test_priority_explicit_beats_env_beats_sticky(
        self, tmp_home: Path, monkeypatch: pytest.MonkeyPatch
    ):
        seed_creds(tmp_home)
        (tmp_home / ".nookplot" / "active-profile").write_text("sticky")
        monkeypatch.setenv("NOOKPLOT_PROFILE", "env")

        assert resolve_active_profile_name("explicit") == "explicit"
        assert resolve_active_profile_name() == "env"

        monkeypatch.delenv("NOOKPLOT_PROFILE")
        assert resolve_active_profile_name() == "sticky"

    def test_returns_none_when_nothing_set(self, tmp_home: Path):
        # No credentials, no profile, no env, no sticky default — None.
        assert resolve_active_profile_name() is None

    def test_empty_sticky_file_is_none(self, tmp_home: Path):
        nook = tmp_home / ".nookplot"
        nook.mkdir()
        (nook / "active-profile").write_text("   \n")
        assert resolve_active_profile_name() is None


# ---------------------------------------------------------------------------
# list_profiles
# ---------------------------------------------------------------------------


class TestListProfiles:
    def test_returns_empty_when_no_profiles_dir(self, tmp_home: Path):
        seed_creds(tmp_home)
        assert list_profiles() == []

    def test_enumerates_valid_profiles_sorted_alphabetically(self, tmp_home: Path):
        seed_creds(tmp_home)
        seed_profile(tmp_home, "writer")
        seed_profile(tmp_home, "researcher")
        profiles = list_profiles()
        names = [p["name"] for p in profiles]
        assert names == ["researcher", "writer"]

    def test_skips_invalid_profiles_silently(self, tmp_home: Path):
        seed_creds(tmp_home)
        seed_profile(tmp_home, "valid")
        # Invalid: missing scopedAgentAddress.
        bad_dir = tmp_home / ".nookplot" / "profiles" / "bad"
        bad_dir.mkdir(parents=True)
        (bad_dir / "profile.json").write_text("{}")
        profiles = list_profiles()
        assert [p["name"] for p in profiles] == ["valid"]

    def test_carries_optional_metadata(self, tmp_home: Path):
        seed_creds(tmp_home)
        seed_profile(
            tmp_home,
            "demo",
            overrides={"displayName": "Demo Agent", "hermesProfile": "demo-hermes"},
        )
        profiles = list_profiles()
        assert len(profiles) == 1
        assert profiles[0]["display_name"] == "Demo Agent"
        assert profiles[0]["hermes_profile"] == "demo-hermes"
