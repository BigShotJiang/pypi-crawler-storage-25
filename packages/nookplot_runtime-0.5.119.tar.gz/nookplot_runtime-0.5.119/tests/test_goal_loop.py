"""Unit tests for the L3 GoalLoop (Python parity with runtime/src/goal/goalLoop.ts)."""
from __future__ import annotations

import json
from unittest.mock import AsyncMock

import pytest

from nookplot_runtime.goal_loop import (
    GoalLoop,
    GoalLoopOptions,
    parse_goal_action,
)
from tests.helpers.mock_runtime import create_mock_runtime


class TestParseGoalAction:
    def test_parses_complete(self):
        result = parse_goal_action(json.dumps({
            "type": "complete",
            "title": "Done",
            "body": "Deliverable",
            "domain": "research",
            "description": "finished",
        }))
        assert result is not None
        assert result["type"] == "complete"
        assert result["title"] == "Done"

    def test_parses_action_with_params(self):
        result = parse_goal_action(json.dumps({
            "type": "action",
            "action_name": "web_search",
            "action_params": {"query": "base protocols"},
            "description": "search base protocols",
        }))
        assert result is not None
        assert result["type"] == "action"
        assert result["action_name"] == "web_search"
        assert result["action_params"]["query"] == "base protocols"

    def test_returns_none_on_malformed_json(self):
        assert parse_goal_action("not json at all") is None
        assert parse_goal_action("{incomplete") is None

    def test_returns_none_when_type_missing(self):
        assert parse_goal_action(json.dumps({"title": "x"})) is None

    def test_returns_none_when_action_name_missing(self):
        assert parse_goal_action(json.dumps({"type": "action", "description": "do stuff"})) is None

    def test_parses_needs_capability(self):
        result = parse_goal_action(json.dumps({
            "type": "needs_capability",
            "description": "I need python",
            "suggested_preset": "python-runner",
        }))
        assert result is not None
        assert result["type"] == "needs_capability"
        assert result["suggested_preset"] == "python-runner"

    def test_extracts_json_block_from_prose(self):
        result = parse_goal_action(
            'Here is my decision:\n{"type":"noop","description":"waiting"}\nDone.'
        )
        assert result is not None
        assert result["type"] == "noop"


class TestGoalLoopRun:
    @pytest.mark.asyncio
    async def test_returns_complete_on_first_turn(self):
        runtime, _ = create_mock_runtime()

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            return (json.dumps({
                "type": "complete",
                "title": "Top 3 Protocols",
                "body": "1. A\n2. B\n3. C",
                "domain": "defi",
                "description": "done",
            }), 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Find top 3",
            budget_nook=500,
            inference_call=fake_inference,
        ))
        result = await loop.run()
        assert result.outcome == "complete"
        assert result.artifact is not None
        assert result.artifact["title"] == "Top 3 Protocols"
        assert result.steps_executed == 0

    @pytest.mark.asyncio
    async def test_returns_blocked_stuck_after_3_repeats(self):
        runtime, _ = create_mock_runtime()

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            return (json.dumps({
                "type": "action",
                "action_name": "web_search",
                "action_params": {"query": "base"},
                "description": "searching for base",
            }), 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Find",
            budget_nook=500,
            max_steps=10,
            max_reformulations=3,
            inference_call=fake_inference,
        ))
        result = await loop.run()
        assert result.outcome == "blocked_stuck"
        assert "searching" in (result.stuck_reason or "")

    @pytest.mark.asyncio
    async def test_returns_blocked_capability(self):
        runtime, _ = create_mock_runtime()

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            return (json.dumps({
                "type": "needs_capability",
                "description": "need a python sandbox",
                "suggested_preset": "python-runner",
            }), 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Run python",
            budget_nook=500,
            inference_call=fake_inference,
        ))
        result = await loop.run()
        assert result.outcome == "blocked_capability"
        assert "python" in (result.capability_needed or "")
        assert result.suggested_preset == "python-runner"

    @pytest.mark.asyncio
    async def test_3_noops_produces_fallback_artifact(self):
        runtime, _ = create_mock_runtime()

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            return (json.dumps({"type": "noop", "description": "nothing to do"}), 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Do stuff",
            budget_nook=500,
            max_consecutive_noops=3,
            inference_call=fake_inference,
        ))
        result = await loop.run()
        assert result.outcome == "complete"
        assert result.artifact is not None
        assert "Goal loop terminated" in result.artifact["body"]

    @pytest.mark.asyncio
    async def test_hits_max_steps_cap_returns_complete(self):
        runtime, _ = create_mock_runtime()
        turn = {"n": 0}

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            turn["n"] += 1
            return (json.dumps({
                "type": "action",
                "action_name": "web_search",
                "action_params": {"query": f"round {turn['n']}"},
                "description": f"round {turn['n']}",
            }), 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Research",
            budget_nook=10000,
            max_steps=3,
            max_reformulations=99,
            inference_call=fake_inference,
        ))
        result = await loop.run()
        assert result.outcome == "complete"
        assert result.steps_executed == 3
        assert result.artifact is not None
        assert "Steps executed" in result.artifact["body"]

    @pytest.mark.asyncio
    async def test_records_each_step(self):
        runtime, _ = create_mock_runtime()
        turn = {"n": 0}

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            turn["n"] += 1
            return (json.dumps({
                "type": "action",
                "action_name": "web_search",
                "action_params": {},
                "description": f"round {turn['n']}",
            }), 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Research",
            budget_nook=10000,
            max_steps=2,
            max_reformulations=99,
            inference_call=fake_inference,
        ))
        await loop.run()
        assert runtime.identity.record_goal_step.call_count == 2

    @pytest.mark.asyncio
    async def test_unparseable_output_3x_falls_through_to_complete(self):
        runtime, _ = create_mock_runtime()

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            return ("garbage not json", 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Research",
            budget_nook=500,
            max_consecutive_noops=3,
            inference_call=fake_inference,
        ))
        result = await loop.run()
        assert result.outcome == "complete"


class TestGoalLoopDoomLoopIntegration:
    """Doom-loop detector hook in GoalLoop. Spec: ROADMAP_ml-intern-integrations.md Phase 2."""

    @pytest.mark.asyncio
    async def test_injects_corrective_prompt_after_detection(self):
        """After 3 identical tool calls, the next turn's prompt contains a doom-loop warning."""
        runtime, _ = create_mock_runtime()
        captured_prompts: list[str] = []
        turn = {"n": 0}

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            captured_prompts.append(user_prompt)
            turn["n"] += 1
            # Keep sending the same action+params but DIFFERENT descriptions so
            # description-based repetition check doesn't fire first.
            return (json.dumps({
                "type": "action",
                "action_name": "web_search",
                "action_params": {"query": "same"},
                "description": f"variant-{turn['n']}",
            }), 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Research",
            budget_nook=10000,
            max_steps=4,
            max_reformulations=99,
            inference_call=fake_inference,
        ))
        await loop.run()
        # Turns 1-3 produced no warning; turn 4 gets the injection.
        assert len(captured_prompts) >= 4
        assert "Doom loop" not in captured_prompts[0]
        assert "Doom loop" not in captured_prompts[1]
        assert "Doom loop" not in captured_prompts[2]
        assert "Doom loop detected" in captured_prompts[3]
        assert "web_search" in captured_prompts[3]

    @pytest.mark.asyncio
    async def test_blocks_stuck_after_3_doom_loop_triggers(self):
        """5 identical tool calls with varying descriptions → blocked_stuck via doom loop."""
        runtime, _ = create_mock_runtime()
        turn = {"n": 0}

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            turn["n"] += 1
            return (json.dumps({
                "type": "action",
                "action_name": "web_search",
                "action_params": {"query": "same"},
                "description": f"variant-{turn['n']}",
            }), 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Research",
            budget_nook=10000,
            max_steps=10,
            max_reformulations=99,
            inference_call=fake_inference,
        ))
        result = await loop.run()
        assert result.outcome == "blocked_stuck"
        assert "doom loop" in (result.stuck_reason or "").lower()
        assert "web_search" in (result.stuck_reason or "")

    @pytest.mark.asyncio
    async def test_different_action_breaks_the_loop(self):
        """If the agent switches action after the corrective prompt, no blocked_stuck."""
        runtime, _ = create_mock_runtime()
        turn = {"n": 0}

        async def fake_inference(*, system_prompt, user_prompt, max_tokens, temperature):
            turn["n"] += 1
            # Turns 1-3 spam web_search; turn 4 switches to search_knowledge,
            # then completes on turn 5.
            if turn["n"] <= 3:
                return (json.dumps({
                    "type": "action",
                    "action_name": "web_search",
                    "action_params": {"query": "same"},
                    "description": f"variant-{turn['n']}",
                }), 0)
            if turn["n"] == 4:
                return (json.dumps({
                    "type": "action",
                    "action_name": "search_knowledge",
                    "action_params": {"q": "switched"},
                    "description": "changed approach",
                }), 0)
            return (json.dumps({
                "type": "complete",
                "title": "Done",
                "body": "Final answer.",
                "domain": "research",
                "description": "done",
            }), 0)

        loop = GoalLoop(GoalLoopOptions(
            runtime=runtime,
            goal="Research",
            budget_nook=10000,
            max_steps=10,
            max_reformulations=99,
            inference_call=fake_inference,
        ))
        result = await loop.run()
        assert result.outcome == "complete"
        assert result.artifact is not None
        assert result.artifact["title"] == "Done"
