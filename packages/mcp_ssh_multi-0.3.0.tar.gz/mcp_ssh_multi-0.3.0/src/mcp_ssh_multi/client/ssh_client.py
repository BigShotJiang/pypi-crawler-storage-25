"""
Async SSH client manager for multi-server connections.

Manages SSH connections to multiple servers defined in a YAML configuration file.
Uses asyncssh for non-blocking SSH operations.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import asyncssh
import yaml

logger = logging.getLogger(__name__)

# Connection health defaults
KEEPALIVE_INTERVAL = 30  # seconds between keepalive packets
KEEPALIVE_COUNT_MAX = 3  # missed keepalives before disconnect
MAX_CONNECTION_AGE = 3600  # 1 hour max connection lifetime
WAIT_CLOSED_TIMEOUT = 5.0  # seconds to wait for connection close


@dataclass
class ServerConfig:
    """Configuration for a single SSH server."""

    name: str
    host: str
    port: int = 22
    username: str = "root"
    password: str | None = None
    key_file: str | None = None
    description: str = ""

    @classmethod
    def from_dict(cls, name: str, data: dict[str, Any]) -> ServerConfig:
        """Create ServerConfig from a dictionary."""
        return cls(
            name=name,
            host=data["host"],
            port=data.get("port", 22),
            username=data.get("username", "root"),
            password=data.get("password"),
            key_file=data.get("key_file"),
            description=data.get("description", ""),
        )


@dataclass
class SSHConnectionPool:
    """Manages a pool of SSH connections to configured servers."""

    servers: dict[str, ServerConfig] = field(default_factory=dict)
    _connections: dict[str, asyncssh.SSHClientConnection] = field(
        default_factory=dict, repr=False
    )
    _connection_times: dict[str, float] = field(default_factory=dict, repr=False)
    _locks: dict[str, asyncio.Lock] = field(default_factory=dict, repr=False)
    _stats: dict[str, int] = field(
        default_factory=lambda: {
            "connects": 0,
            "reconnects": 0,
            "failed_commands": 0,
            "timeouts": 0,
        },
        repr=False,
    )

    def _get_server_lock(self, server_name: str) -> asyncio.Lock:
        """Get or create a lock for a specific server."""
        if server_name not in self._locks:
            self._locks[server_name] = asyncio.Lock()
        return self._locks[server_name]

    @classmethod
    def from_yaml(cls, config_path: str) -> SSHConnectionPool:
        """Load server configurations from a YAML file."""
        path = Path(config_path)
        if not path.exists():
            logger.warning(f"SSH servers config not found: {config_path}")
            return cls()

        with open(path) as f:
            raw = yaml.safe_load(f)

        if not raw or "servers" not in raw:
            logger.warning(f"No 'servers' key in {config_path}")
            return cls()

        servers: dict[str, ServerConfig] = {}
        for name, data in raw["servers"].items():
            try:
                servers[name] = ServerConfig.from_dict(name, data)
                logger.debug(f"Loaded server config: {name} ({data['host']})")
            except (KeyError, TypeError) as e:
                logger.error(f"Invalid server config for '{name}': {e}")

        logger.info(f"Loaded {len(servers)} server configurations from {config_path}")
        return cls(servers=servers)

    def get_stats(self) -> dict[str, Any]:
        """Return connection pool statistics."""
        active = sum(1 for c in self._connections.values() if not c.is_closed())
        return {**self._stats, "active_connections": active}

    def _is_connection_expired(self, server_name: str) -> bool:
        """Check if a connection has exceeded its max age."""
        created = self._connection_times.get(server_name)
        if created is None:
            return False
        return (time.monotonic() - created) > MAX_CONNECTION_AGE

    def list_servers(self) -> list[dict[str, Any]]:
        """List all configured servers with connection status."""
        result = []
        for name, config in self.servers.items():
            connected = (
                name in self._connections and not self._connections[name].is_closed()
            )
            result.append(
                {
                    "name": name,
                    "host": config.host,
                    "port": config.port,
                    "username": config.username,
                    "description": config.description,
                    "connected": connected,
                }
            )
        return result

    def get_server_config(self, server_name: str) -> ServerConfig | None:
        """Get configuration for a specific server."""
        return self.servers.get(server_name)

    async def _close_connection(self, conn: asyncssh.SSHClientConnection) -> None:
        """Close a connection and wait for cleanup to complete."""
        conn.close()
        try:
            await asyncio.wait_for(conn.wait_closed(), timeout=WAIT_CLOSED_TIMEOUT)
        except (TimeoutError, asyncio.CancelledError):
            pass
        except Exception as e:
            logger.debug(f"Connection close error: {e}")

    async def connect(self, server_name: str) -> asyncssh.SSHClientConnection:
        """Connect to a server, reusing existing connections when possible."""
        lock = self._get_server_lock(server_name)
        async with lock:
            # Check for existing valid connection
            if server_name in self._connections:
                conn = self._connections[server_name]
                if not conn.is_closed() and not self._is_connection_expired(
                    server_name
                ):
                    return conn
                # Connection was closed or expired, remove it
                old_conn = self._connections.pop(server_name)
                self._connection_times.pop(server_name, None)
                reason = "expired" if not old_conn.is_closed() else "stale"
                logger.debug(f"Removing {reason} connection to {server_name}")
                await self._close_connection(old_conn)

            config = self.servers.get(server_name)
            if config is None:
                raise ValueError(f"Server '{server_name}' not found in configuration")

            connect_kwargs: dict[str, Any] = {
                "host": config.host,
                "port": config.port,
                "username": config.username,
                "known_hosts": None,
                "keepalive_interval": KEEPALIVE_INTERVAL,
                "keepalive_count_max": KEEPALIVE_COUNT_MAX,
            }

            if config.key_file:
                key_path = Path(config.key_file).expanduser()
                if key_path.exists():
                    connect_kwargs["client_keys"] = [str(key_path)]
                else:
                    logger.warning(
                        f"Key file not found: {config.key_file}, "
                        f"falling back to password auth"
                    )

            if config.password:
                connect_kwargs["password"] = config.password

            logger.info(f"Connecting to {server_name} ({config.host}:{config.port})")
            conn = await asyncssh.connect(**connect_kwargs)
            self._connections[server_name] = conn
            self._connection_times[server_name] = time.monotonic()
            self._stats["connects"] += 1
            logger.info(f"Connected to {server_name}")
            return conn

    async def disconnect(self, server_name: str) -> bool:
        """Disconnect from a specific server."""
        lock = self._get_server_lock(server_name)
        async with lock:
            conn = self._connections.pop(server_name, None)
            self._connection_times.pop(server_name, None)
            if conn is not None:
                await self._close_connection(conn)
                logger.info(f"Disconnected from {server_name}")
                return True
            return False

    async def disconnect_all(self) -> None:
        """Disconnect from all servers."""
        names = list(self._connections.keys())
        await asyncio.gather(
            *(self.disconnect(name) for name in names),
            return_exceptions=True,
        )
        logger.info("Disconnected from all servers")

    async def _invalidate_connection(
        self, server_name: str, failed_conn: asyncssh.SSHClientConnection
    ) -> None:
        """Remove a connection from the pool only if it's the same object we failed on."""
        async with self._get_server_lock(server_name):
            current = self._connections.get(server_name)
            if current is failed_conn:
                self._connections.pop(server_name, None)
                self._connection_times.pop(server_name, None)
                await self._close_connection(failed_conn)

    async def execute(
        self,
        server_name: str,
        command: str,
        timeout: int = 30,
        _retried: bool = False,
    ) -> dict[str, Any]:
        """Execute a command on a remote server.

        Retries once on connection failure (stale connection).
        """
        conn = await self.connect(server_name)

        try:
            result = await asyncio.wait_for(
                conn.run(command, check=False),
                timeout=timeout,
            )
        except TimeoutError as err:
            self._stats["timeouts"] += 1
            raise TimeoutError(
                f"Command timed out after {timeout}s on {server_name}: {command}"
            ) from err
        except (asyncssh.ConnectionLost, asyncssh.DisconnectError, OSError) as err:
            if _retried:
                self._stats["failed_commands"] += 1
                raise
            logger.warning(f"Connection lost to {server_name}, retrying: {err}")
            await self._invalidate_connection(server_name, conn)
            self._stats["reconnects"] += 1
            return await self.execute(
                server_name, command, timeout=timeout, _retried=True
            )

        return {
            "stdout": result.stdout or "",
            "stderr": result.stderr or "",
            "exit_code": result.exit_status if result.exit_status is not None else -1,
        }

    async def _with_sftp_retry(
        self,
        server_name: str,
        operation: str,
        func: Any,
    ) -> Any:
        """Run an SFTP operation with one retry on connection failure."""
        for attempt in range(2):
            conn = await self.connect(server_name)
            try:
                return await func(conn)
            except (asyncssh.ConnectionLost, asyncssh.DisconnectError, OSError) as err:
                if attempt > 0:
                    self._stats["failed_commands"] += 1
                    raise
                logger.warning(
                    f"Connection lost during {operation} on {server_name}, "
                    f"retrying: {err}"
                )
                await self._invalidate_connection(server_name, conn)
                self._stats["reconnects"] += 1
        raise RuntimeError("Unreachable")  # pragma: no cover

    async def upload_file(
        self,
        server_name: str,
        local_path: str,
        remote_path: str,
    ) -> dict[str, Any]:
        """Upload a file to a remote server via SFTP."""
        local = Path(local_path)
        if not local.exists():
            raise FileNotFoundError(f"Local file not found: {local_path}")

        async def _upload(conn: asyncssh.SSHClientConnection) -> dict[str, Any]:
            async with conn.start_sftp_client() as sftp:
                await sftp.put(local_path, remote_path)
            return {}

        await self._with_sftp_retry(server_name, "upload", _upload)

        file_size = local.stat().st_size
        logger.info(
            f"Uploaded {local_path} -> {server_name}:{remote_path} ({file_size} bytes)"
        )

        return {
            "local_path": local_path,
            "remote_path": remote_path,
            "size_bytes": file_size,
        }

    async def download_file(
        self,
        server_name: str,
        remote_path: str,
        local_path: str,
    ) -> dict[str, Any]:
        """Download a file from a remote server via SFTP."""
        local = Path(local_path)
        local.parent.mkdir(parents=True, exist_ok=True)

        async def _download(conn: asyncssh.SSHClientConnection) -> dict[str, Any]:
            async with conn.start_sftp_client() as sftp:
                await sftp.get(remote_path, local_path)
            return {}

        await self._with_sftp_retry(server_name, "download", _download)

        file_size = local.stat().st_size
        logger.info(
            f"Downloaded {server_name}:{remote_path} -> {local_path} ({file_size} bytes)"
        )

        return {
            "remote_path": remote_path,
            "local_path": local_path,
            "size_bytes": file_size,
        }

    async def read_file(
        self,
        server_name: str,
        remote_path: str,
        max_size: int = 1_000_000,
    ) -> str:
        """Read a file from a remote server."""

        async def _read(conn: asyncssh.SSHClientConnection) -> str:
            async with conn.start_sftp_client() as sftp:
                attrs = await sftp.stat(remote_path)
                if attrs.size and attrs.size > max_size:
                    raise ValueError(
                        f"File too large ({attrs.size} bytes, max {max_size}). "
                        f"Use ssh_download to transfer large files."
                    )
                async with sftp.open(remote_path, "r") as f:
                    content = await f.read()
            return (
                content
                if isinstance(content, str)
                else content.decode("utf-8", errors="replace")
            )

        return await self._with_sftp_retry(server_name, "read_file", _read)

    async def write_file(
        self,
        server_name: str,
        remote_path: str,
        content: str,
    ) -> dict[str, Any]:
        """Write content to a file on a remote server."""

        async def _write(conn: asyncssh.SSHClientConnection) -> dict[str, Any]:
            async with conn.start_sftp_client() as sftp:
                async with sftp.open(remote_path, "w") as f:
                    await f.write(content)
            return {}

        await self._with_sftp_retry(server_name, "write_file", _write)

        size = len(content.encode("utf-8"))
        logger.info(f"Wrote {size} bytes to {server_name}:{remote_path}")

        return {
            "remote_path": remote_path,
            "size_bytes": size,
        }

    async def file_exists(
        self,
        server_name: str,
        remote_path: str,
    ) -> dict[str, Any]:
        """Check if a file or directory exists on a remote server."""

        async def _exists(conn: asyncssh.SSHClientConnection) -> dict[str, Any]:
            async with conn.start_sftp_client() as sftp:
                try:
                    attrs = await sftp.stat(remote_path)
                    return {
                        "exists": True,
                        "path": remote_path,
                        "is_dir": attrs.type == asyncssh.FILEXFER_TYPE_DIRECTORY,
                        "size": attrs.size,
                        "permissions": oct(attrs.permissions)
                        if attrs.permissions
                        else None,
                    }
                except (asyncssh.SFTPNoSuchFile, asyncssh.SFTPError):
                    return {"exists": False, "path": remote_path}

        return await self._with_sftp_retry(server_name, "file_exists", _exists)

    async def list_dir(
        self,
        server_name: str,
        remote_path: str = ".",
        limit: int = 0,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List contents of a remote directory with optional pagination."""

        async def _listdir(conn: asyncssh.SSHClientConnection) -> list[dict[str, Any]]:
            all_entries: list[dict[str, Any]] = []
            async with conn.start_sftp_client() as sftp:
                async for entry in sftp.scandir(remote_path):
                    attrs = entry.attrs
                    all_entries.append(
                        {
                            "name": entry.filename,
                            "is_dir": attrs.type == asyncssh.FILEXFER_TYPE_DIRECTORY
                            if attrs.type is not None
                            else None,
                            "size": attrs.size,
                            "permissions": oct(attrs.permissions)
                            if attrs.permissions
                            else None,
                        }
                    )
            return all_entries

        all_entries = await self._with_sftp_retry(server_name, "list_dir", _listdir)

        total = len(all_entries)

        if offset:
            all_entries = all_entries[offset:]

        has_more = False
        if limit and limit > 0:
            has_more = len(all_entries) > limit
            all_entries = all_entries[:limit]

        return {
            "entries": all_entries,
            "total": total,
            "has_more": has_more,
        }
