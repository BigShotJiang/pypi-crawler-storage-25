#!/usr/bin/env python3
"""
NOW Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.11
"""

from datetime import datetime, date, timedelta, timezone
from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


def _parse_datetime(val):
    if isinstance(val, datetime):
        return val
    if isinstance(val, date):
        return datetime.combine(val, datetime.min.time())
    if isinstance(val, (int, float)):
        return datetime.fromtimestamp(val)
    if isinstance(val, str):
        for fmt in ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d', '%m/%d/%Y'):
            try:
                return datetime.strptime(val, fmt)
            except ValueError:
                continue
    return None


class NowExecutor(AUniversalOperationExecutor):
    OPERATION_NAME = "NOW"
    OPERATION_TYPE = OperationType.ADVANCED
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params
        result_data = self._execute_op(context.node, params, context)
        return ExecutionResult(
            success=True,
            data=result_data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _execute_op(self, node: Any, params: dict, context: ExecutionContext) -> dict:
        items = extract_items(node)
        as_field = params.get("as_field", "_now")
        output_format = params.get("format")
        use_utc = bool(params.get("utc", False))

        current_dt = datetime.now(timezone.utc) if use_utc else datetime.now()
        value = current_dt.strftime(output_format) if output_format else current_dt.isoformat()

        if not items:
            return {"value": value, "count": 1}

        result_items = []
        for item in items:
            if isinstance(item, dict):
                item_copy = item.copy()
                item_copy[as_field] = value
                result_items.append(item_copy)
            else:
                result_items.append({as_field: value, "value": item})

        return {"items": result_items, "count": len(result_items), "field": as_field}


__all__ = ["NowExecutor"]
