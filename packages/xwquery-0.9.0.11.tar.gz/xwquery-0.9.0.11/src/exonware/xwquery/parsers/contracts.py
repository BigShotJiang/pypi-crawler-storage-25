#!/usr/bin/env python3
"""
#exonware/xwnode/src/exonware/xwnode/queries/parsers/contracts.py

Parser Contracts

Interfaces for query parameter extractors.
Follows DEV_GUIDELINES.md: contracts.py for all interfaces.

Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.11
Generation Date: 09-Oct-2025
"""

from abc import ABC, abstractmethod
from typing import Any


class IParamExtractor(ABC):
    """
    Interface for parameter extractors.
    
    Extracts structured parameters from query strings.
    """
    
    @abstractmethod
    def extract_params(self, query: str, action_type: str) -> dict[str, Any]:
        """
        Extract structured parameters from query.
        
        Args:
            query: Raw query string
            action_type: Type of action (SELECT, INSERT, etc.)
        
        Returns:
            Structured parameters dictionary
        """
    
    @abstractmethod
    def can_parse(self, query: str) -> bool:
        """Check if this extractor can parse the query."""

