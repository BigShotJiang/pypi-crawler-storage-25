import{aq as o,ar as n}from"./index-DC-3tjkk.js";const t=(r,a)=>o.lang.round(n.parse(r)[a]);export{t as c};
