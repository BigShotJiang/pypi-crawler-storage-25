import{b as r}from"./_baseUniq-BRr4GMYA.js";var e=4;function a(o){return r(o,e)}export{a as c};
