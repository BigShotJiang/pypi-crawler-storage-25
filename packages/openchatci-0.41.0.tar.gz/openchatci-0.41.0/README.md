# OpenChatCi

Hawaii-built localhost-first AI agent platform powered by Microsoft Agent Framework.

## Install

```bash
pip install openchatci
```

## Quick Start

### Linux / macOS

```bash
# Generate .env configuration
openchatci init

# Edit .env and set AZURE_OPENAI_ENDPOINT
nano .env

# Login to Azure CLI
az login

# Start the server
openchatci
```

### Windows (PowerShell)

```powershell
# Generate .env configuration
openchatci init

# Edit .env and set AZURE_OPENAI_ENDPOINT
notepad .env

# Login to Azure CLI
az login

# Start the server
openchatci
```

Open http://localhost:8000/chat

## CLI Usage

```
openchatci                    Start the server
openchatci init               Generate .env from template
openchatci init --force       Overwrite existing .env
openchatci --host 0.0.0.0     Bind to all interfaces
openchatci --port 9000        Use custom port
openchatci --skip-auth-check  Skip Azure CLI login check
openchatci --version          Show version
```

## Requirements

- Python 3.12+
- Azure OpenAI resource with a deployed model
- Azure CLI (`az login`)

## Supported Platforms

- Windows 10/11
- macOS (Intel / Apple Silicon)
- Linux (Ubuntu, Debian, etc.)

## License

Apache-2.0
