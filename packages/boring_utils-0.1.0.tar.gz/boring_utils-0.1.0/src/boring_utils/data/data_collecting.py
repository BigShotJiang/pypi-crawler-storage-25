import sys
import requests
import re
import zipfile
from urllib.parse import urlparse
from pathlib import Path
from boring_utils.helpers._paths import DATA_DIRECTORY_PATH
from typing import Optional

def get_filename_from_headers(response) -> Optional[str]:
    """
    Extracts filename from Content-Disposition header if available.

    Args:
        response: The HTTP response object from which to extract the filename.

    Returns:
        Optional[str]: The filename if found, otherwise None.
    """
    content_disposition = response.headers.get('Content-Disposition')
    if content_disposition:
        # Looks for filename="name.ext" or filename=name.ext
        fname = re.findall(r'filename\*?=(?:.*\'\')?([^;]+)', content_disposition)
        if fname:
            return fname[0].strip('" ')
    return None

def download_file(url: str, dest_path: Path = DATA_DIRECTORY_PATH) -> None:
    """
    Downloads a file. If dest_path is a directory, it determines the filename 
    from the server headers or the URL.
    """
    try:
        with requests.get(url, stream=True) as r:
            r.raise_for_status()

            # --- Filename Logic ---
            # If the user provided a directory, we need to find a filename
            if dest_path.is_dir():
                header_name = get_filename_from_headers(r)
                url_name = Path(urlparse(url).path).name
                filename = header_name or url_name or "downloaded_file"
                final_path = dest_path / filename
            else:
                # If they provided a full file path, use it as is
                final_path = dest_path

            total_size = int(r.headers.get('content-length', 0))
            downloaded = 0
            chunk_size = 8192 

            with open(final_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        if total_size != 0:
                            percent = int(100 * downloaded / total_size)
                            sys.stdout.write(f"\rDownloading {final_path.name}: {percent}% ({downloaded}/{total_size} bytes)")
                        else:
                            sys.stdout.write(f"\rDownloading {final_path.name}: {downloaded} bytes (Size unknown)")
                        sys.stdout.flush()
        print() 
    except Exception as e:
        print(f"\nERRO: {e}")


def download_several_files(urls: list[str], list_file_paths: Optional[list[Path]] = None) -> None:
    """
    Downloads multiple files and prints status information.

    Args:
        urls (list[str]): List of URLs to download.
        list_file_paths (Optional[list[Path]]): Optional list of Paths where each file should be saved. If None, files will be saved in the default data directory.
    
    Returns:
        None: This function does not return anything, it just processes the files.
    """
    total_files = len(urls)

    if list_file_paths is None:
        print("Nenhum caminho específico foi selecionado. Por padrão os dados serão baixados e salvos no diretório 'data'")
        for file_number, (url) in enumerate(zip(urls), 1):
            print("#" * 80)
            local_file_path = DATA_DIRECTORY_PATH 
            print(f"Arquivo {file_number}/{total_files}: {local_file_path.name}")
            print(f"Local do arquivo: {local_file_path.parent.absolute()}")
            download_file(url, local_file_path)
            print("#" * 80)
        return

    for file_number, (url, local_file_path) in enumerate(zip(urls, [list_file_paths]), 1):
        print("#" * 80)
        print(f"Arquivo {file_number}/{total_files}: {local_file_path.name}")
        print(f"Local do arquivo: {local_file_path.parent.absolute()}")
        download_file(url, local_file_path)
        print("#" * 80)

def unzip_file(local_file_path: Path) -> None:
    """
    Unzips a file into a new folder named after the zip file.
    
    Args:
        local_file_path (Path): Path to the .zip file
    
    Returns:
        None: This function does not return anything, it just processes the file.
    """
    try:
        if not local_file_path.exists():
            print(f"ERRO: Arquivo não encontrado em {local_file_path}")
            return

        # .stem gets the filename without the extension (e.g., 'data' from 'data.zip')
        output_folder = local_file_path.parent / local_file_path.stem
        
        # Create the directory if it doesn't exist
        output_folder.mkdir(parents=True, exist_ok=True)
        
        print(f"Extraindo: {local_file_path.name}")
        print(f"Para: {output_folder.absolute()}")
        
        with zipfile.ZipFile(local_file_path, 'r') as zip_ref:
            zip_ref.extractall(output_folder)
            
        print("Extração concluída com sucesso.")
        
    except zipfile.BadZipFile:
        print(f"ERRO: O arquivo {local_file_path.name} não é um arquivo ZIP válido ou está corrompido.")
    except Exception as e:
        print(f"ERRO ao extrair {local_file_path.name}: {e}")

def unzip_several_files(list_file_paths: list[Path]) -> None:
    """
    Args:
        list_file_paths (list[Path]): List of Paths to zip files

    Returns:
        None: This function does not return anything, it just processes the files.
    """
    total = len(list_file_paths)
    for index, file_path in enumerate(list_file_paths, 1):
        print(f"\n--- Processando arquivo {index}/{total} ---")
        unzip_file(file_path)
        print("-" * 30)