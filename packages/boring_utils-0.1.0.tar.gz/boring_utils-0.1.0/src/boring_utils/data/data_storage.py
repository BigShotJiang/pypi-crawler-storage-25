from __future__ import annotations

import json
import pickle
from pathlib import Path
from typing import Any, Union

from boring_utils.helpers._paths import DATA_DIRECTORY_PATH


class DataStorageError(Exception):
    """Custom exception for data storage failures."""


def ensure_directory(destination: Path = DATA_DIRECTORY_PATH) -> Path:
    """
    Ensure a directory exists and return its path.
    
    Args:
        destination (Path): The directory path to ensure exists. Defaults to DATA_DIRECTORY_PATH.

    Returns:
        Path: The path to the ensured directory.
    """
    destination.mkdir(parents=True, exist_ok=True)
    return destination


def build_data_path(filename: str, parent: Path = DATA_DIRECTORY_PATH) -> Path:
    """
    Build a full data file path under the default data directory.

    Args:
        filename (str): The name of the file.
        parent (Path): The parent directory. Defaults to DATA_DIRECTORY_PATH.

    Returns:
        Path: The full path to the data file.
    """
    target_directory = ensure_directory(parent)
    return target_directory / filename


def resolve_file_path(file_path: Union[Path, str], default_directory: Path = DATA_DIRECTORY_PATH) -> Path:
    """
    Resolve a file path, allowing directories to be expanded into a default filename.

    Args:
        file_path (Path | str): The path to the file.
        default_directory (Path): The default directory to use if the path is a directory. Defaults to DATA_DIRECTORY_PATH.

    Returns:
        Path: The resolved file path.
    """
    candidate = Path(file_path)

    if candidate.is_dir():
        raise DataStorageError("Expected a file path, but received a directory.")

    if candidate.parent == Path('.') and not candidate.suffix:
        return default_directory / candidate

    if candidate.parent and not candidate.parent.exists():
        ensure_directory(candidate.parent)

    return candidate


def _normalize_format(format_name: Union[str, None], file_path: Path) -> str:
    """
    Normalize the format name by using the provided format or inferring it from the file extension.

    Args:
        format_name (str | None): The format name.
        file_path (Path): The path to the file.

    Returns:
        str: The normalized format name.
    """
    extension = format_name or file_path.suffix.lstrip('.')
    if not extension:
        raise DataStorageError(f"Could not infer format from path {file_path}")
    return extension.lower().lstrip('.')


def get_file_extension(file_path: Union[Path, str]) -> str:
    """
    Return the normalized extension for a file path.
    
    Args:
        file_path (Path | str): The path to the file.
    
    Returns:
        str: The file extension without the leading dot, in lowercase.
    """
    return Path(file_path).suffix.lower().lstrip('.')


def save_json(data: Any, file_path: Union[Path, str], *, indent: int = 2, overwrite: bool = True) -> Path:
    """
    Persist Python data structures to a JSON file.
    
    Args:
        data (Any): The Python data structure to save.
        file_path (Path | str): The path to the JSON file to save to.
        indent (int): The indentation level for the JSON output. Defaults to 2.
        overwrite (bool): Whether to overwrite the file if it already exists. Defaults to True.

    Returns:
        Path: The path to the saved JSON file.

    Raises:
        FileExistsError: If the target file already exists and overwrite is False.
    """
    path = resolve_file_path(Path(file_path))
    if path.exists() and not overwrite:
        raise FileExistsError(f"File already exists: {path}")

    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, indent=indent, ensure_ascii=False)

    return path


def load_json(file_path: Union[Path, str]) -> Any:
    """
    Load JSON data from a file.
    
    Args:
        file_path (Path | str): The path to the JSON file to load.

    Returns:
        Any: The Python data structure loaded from the JSON file.

    Raises:
        FileNotFoundError: If the specified file does not exist.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(path)

    with open(path, 'r', encoding='utf-8') as handle:
        return json.load(handle)


def save_pickle(data: Any, file_path: Union[Path, str], *, protocol: int = pickle.HIGHEST_PROTOCOL, overwrite: bool = True) -> Path:
    """
    Persist Python objects to a pickle file.
    
    Args:
        data (Any): The Python object to serialize and save.
        file_path (Path | str): The path to the pickle file to save to.
        protocol (int): The pickle protocol version to use. Defaults to pickle.HIGHEST_PROTOCOL.
        overwrite (bool): Whether to overwrite the file if it already exists. Defaults to True.

    Returns:
        Path: The path to the saved pickle file.

    Raises:
        FileExistsError: If the target file already exists and overwrite is False.
    """
    path = resolve_file_path(Path(file_path))
    if path.exists() and not overwrite:
        raise FileExistsError(f"File already exists: {path}")

    with open(path, 'wb') as handle:
        pickle.dump(data, handle, protocol=protocol)

    return path


def load_pickle(file_path: Union[Path, str]) -> Any:
    """
    Load a pickled object from disk.
    
    Args:
        file_path (Path | str): The path to the pickle file to load.
    
    Returns:
        Any: The Python object loaded from the pickle file.
    
    Raises:
        FileNotFoundError: If the specified file does not exist.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(path)

    with open(path, 'rb') as handle:
        return pickle.load(handle)


def save_text(text: str, file_path: Union[Path, str], *, encoding: str = 'utf-8', overwrite: bool = True) -> Path:
    """
    Save string data to a plain text file.
    
    Args:
        text (str): The text content to save.
        file_path (Path | str): The path to the text file to save to.
        encoding (str): The encoding to use when writing the file. Defaults to 'utf-8'. 
        overwrite (bool): Whether to overwrite the file if it already exists. Defaults to True.

    Returns:
        Path: The path to the saved text file.
    """
    path = resolve_file_path(Path(file_path))
    if path.exists() and not overwrite:
        raise FileExistsError(f"File already exists: {path}")

    with open(path, 'w', encoding=encoding) as handle:
        handle.write(text)

    return path


def load_text(file_path: Union[Path, str], *, encoding: str = 'utf-8') -> str:
    """
    Load plain text from a file.
    
    Args:
        file_path (Path | str): The path to the text file to load.
        encoding (str): The encoding to use when reading the file. Defaults to 'utf-8'.
    
    Returns:
        str: The contents of the text file.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(path)

    with open(path, 'r', encoding=encoding) as handle:
        return handle.read()


def _import_pandas() -> Any:
    try:
        import pandas as pd
    except ImportError as error:
        raise DataStorageError("pandas is required for tabular storage operations") from error
    return pd


def save_tabular(data: Any, file_path: Union[Path, str], *, overwrite: bool = True, index: bool = False, **kwargs) -> Path:
    """
    Save tabular data to CSV, TSV, Parquet, or Excel.
    
    Args:
        data (Any): The tabular data to save, typically a pandas DataFrame or something convertible to one.
        file_path (Path | str): The path to the file to save to.
        overwrite (bool): Whether to overwrite the file if it already exists. Defaults to True.
        index (bool): Whether to include the DataFrame index in the output file. Defaults to False.
        **kwargs: Additional keyword arguments to pass to the underlying pandas to_* function.
    
    Returns:
        Path: The path to the saved file.
    """
    pd = _import_pandas()
    path = resolve_file_path(Path(file_path))
    extension = get_file_extension(path)

    if path.exists() and not overwrite:
        raise FileExistsError(f"File already exists: {path}")

    if not isinstance(data, pd.DataFrame):
        data = pd.DataFrame(data)

    if extension == 'csv':
        data.to_csv(path, index=index, **kwargs)
    elif extension == 'tsv':
        data.to_csv(path, sep='\t', index=index, **kwargs)
    elif extension == 'parquet':
        data.to_parquet(path, index=index, **kwargs)
    elif extension in ('xls', 'xlsx'):
        data.to_excel(path, index=index, **kwargs)
    else:
        raise DataStorageError(f"Unsupported tabular extension: .{extension}")

    return path


def load_tabular(file_path: Union[Path, str], **kwargs) -> Any:
    """
    Load tabular data from CSV, TSV, Parquet, or Excel.
    
    Args:
        file_path (Path | str): The path to the tabular file to load.
        **kwargs: Additional keyword arguments to pass to the underlying pandas read function.
    
    Returns:
        Any: The loaded tabular data, typically as a pandas DataFrame.
    """
    pd = _import_pandas()
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(path)

    extension = get_file_extension(path)
    if extension == 'csv':
        return pd.read_csv(path, **kwargs)
    if extension == 'tsv':
        return pd.read_csv(path, sep='\t', **kwargs)
    if extension == 'parquet':
        return pd.read_parquet(path, **kwargs)
    if extension in ('xls', 'xlsx'):
        return pd.read_excel(path, **kwargs)

    raise DataStorageError(f"Unsupported tabular extension: .{extension}")


def save_data(data: Any, file_path: Union[Path, str], *, format: Union[str, None] = None, overwrite: bool = True, **kwargs) -> Path:
    """
    Save data to disk, choosing the writer from the file extension or explicit format.
    
    Args:
        data (Any): The data to save.
        file_path (Path | str): The path to the file to save to.
        format (str | None): Optional explicit format to use instead of inferring from the file extension. Supported values include 'json', 'pickle', 'txt', 'csv', 'tsv', 'parquet', 'xls', and 'xlsx'.
        overwrite (bool): Whether to overwrite the file if it already exists. Defaults to True.
        **kwargs: Additional keyword arguments to pass to the underlying save function.
    
    Returns:
        Path: The path to the saved file.
    """
    path = resolve_file_path(Path(file_path))
    resolved_format = _normalize_format(format, path)

    if resolved_format in ('json',):
        return save_json(data, path, overwrite=overwrite, **kwargs)
    if resolved_format in ('pickle', 'pkl'):
        return save_pickle(data, path, overwrite=overwrite, **kwargs)
    if resolved_format in ('txt', 'text'):
        return save_text(str(data), path, overwrite=overwrite, **kwargs)
    if resolved_format in ('csv', 'tsv', 'parquet', 'xls', 'xlsx'):
        return save_tabular(data, path, overwrite=overwrite, **kwargs)

    raise DataStorageError(f"Unsupported storage format: {resolved_format}")


def load_data(file_path: Union[Path, str], *, format: Union[str, None] = None, **kwargs) -> Any:
    """
    Load data from disk and return the value in a Python-friendly format.
    
    Args:
        file_path (Path | str): The path to the file to load.
        format (str | None): Optional explicit format to use instead of inferring from the file extension.
        **kwargs: Additional keyword arguments to pass to the underlying load function.

    Returns:
        Any: The loaded data, in a Python-friendly format.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(path)

    resolved_format = _normalize_format(format, path)
    if resolved_format == 'json':
        return load_json(path)
    if resolved_format in ('pickle', 'pkl'):
        return load_pickle(path)
    if resolved_format in ('txt', 'text'):
        return load_text(path, **kwargs)
    if resolved_format in ('csv', 'tsv', 'parquet', 'xls', 'xlsx'):
        return load_tabular(path, **kwargs)

    raise DataStorageError(f"Unsupported storage format: {resolved_format}")
