from pathlib import Path

ROOT_DIRECTORY_PATH = Path(__file__).resolve().parent.parent
DATA_DIRECTORY_PATH = ROOT_DIRECTORY_PATH / "data"
HELPER_DIRECTORY_PATH = ROOT_DIRECTORY_PATH / "helper"
NETWORK_DIRECTORY_PATH = ROOT_DIRECTORY_PATH / "network"