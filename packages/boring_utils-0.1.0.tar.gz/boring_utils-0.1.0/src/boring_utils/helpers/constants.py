# src/boring_utils/helper/constants.py

# A dictionary of common data extensions
DATA_EXTENSIONS = {
    'tabular': ['.csv', '.tsv', '.parquet', '.xlsx'],
    'structured': ['.json', '.yaml', '.xml'],
    'text': ['.txt', '.md', '.pdf']
}

# Default headers for network requests
DEFAULT_HEADERS = {
    "User-Agent": "boring-utils/0.1.0 (Automation Tool)"
}