# boring-utils

For every project involving data, there's alot of tedious repetitive work that goes into it, which results in the creation of reusable scripts that greatly automate the process for you. What if instead of copy and pasting these files into new projects, there was one library that simplified things, and get solutions done through one line of code? Introducing 'boring-utils', a library focused on simplifying tedius, boring tasks involving data, such as downloading files, renaming folders, unziping files, integrating datasets, and much more.

## Installation
