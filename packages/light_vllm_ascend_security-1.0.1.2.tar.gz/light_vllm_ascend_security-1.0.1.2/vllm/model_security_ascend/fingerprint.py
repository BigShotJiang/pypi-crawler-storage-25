# SPDX-License-Identifier: Apache-2.0
"""
Machine fingerprinting for NPU/Ascend platforms.

Extends the core fingerprinting with NPU-specific functionality.
"""

from typing import Optional, List

# Import from lightr_vllm_core - already supports NPU!
from lightr_vllm_core import FingerprintPolicy
from lightr_vllm_core.cli.get_fingerprint import (
    get_cpu_id,
    get_mac_addresses,
    get_npu_uuids as _core_get_npu_uuids,
    get_machine_fingerprint as _core_get_machine_fingerprint,
    get_fingerprint_info as _core_get_fingerprint_info,
)


def get_npu_uuids() -> List[str]:
    """
    Get NPU UUIDs for Ascend devices.

    Uses torch.npu API to get device UUIDs.

    Returns:
        List of NPU UUID strings
    """
    return _core_get_npu_uuids()


def get_machine_fingerprint(
    salt: Optional[str] = None
) -> str:
    """
    Generate a unique machine fingerprint for NPU platforms.

    Automatically includes NPU UUIDs if available.

    Args:
        salt: Optional salt for hashing

    Returns:
        Hex-encoded SHA-256 hash of machine characteristics
    """
    return _core_get_machine_fingerprint(salt=salt)


def get_fingerprint_info() -> dict:
    """
    Get detailed fingerprint information for debugging.

    Returns:
        Dictionary with fingerprint components including NPU UUIDs
    """
    return _core_get_fingerprint_info()


def verify_fingerprint(
    expected: str,
    salt: Optional[str] = None
) -> bool:
    """
    Verify if current machine matches expected fingerprint.

    Args:
        expected: Expected fingerprint hash
        salt: Salt used in original fingerprint

    Returns:
        True if fingerprints match
    """
    current = get_machine_fingerprint(salt=salt)
    return current == expected