"""
MCP Midtrans - Midtrans Payment Gateway Documentation MCP Server.

This server provides comprehensive Midtrans Core API documentation, API references,
payment method guides, implementation examples, and best practices to help
AI agents understand and implement Midtrans payment gateway integration.

Languages supported: Python, JavaScript/TypeScript, Go, Rust
Focus: Core API (NOT Snap)
"""

from enum import Enum
from typing import Optional

from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field, ConfigDict

from mcp_midtrans.knowledge_base import (
    API_ENDPOINTS,
    AUTHORIZATION_GUIDE,
    CHANNEL_RESPONSE_CODES,
    CHARGE_TRANSACTION_GUIDE,
    DOCUMENTATION_MAP,
    HTTP_REQUEST_GUIDE,
    IMPLEMENTATION_EXAMPLES,
    INVOICING_GUIDE,
    JSON_OBJECT_SCHEMAS,
    MERCHANT_BALANCE_GUIDE,
    MIDTRANS_OVERVIEW,
    NOTIFICATION_GUIDE,
    PAYMENT_LINK_GUIDE,
    PAYMENT_METHOD_DETAILS,
    PAYMENT_METHODS_LIST,
    STATUS_CODES,
    SUBSCRIPTION_GUIDE,
    TESTING_CREDENTIALS,
    TRANSACTION_MANAGEMENT_GUIDE,
    TRANSACTION_STATUS_GUIDE,
)

mcp = FastMCP(
    "midtrans_mcp",
    instructions=(
        "MCP server for Midtrans payment gateway Core API documentation. "
        "Use these tools to get comprehensive information about Midtrans Core APIs, "
        "payment methods, integration guides, code examples, and best practices. "
        "Start with midtrans_get_documentation_map to see all available topics, "
        "then drill down into specific areas using the other tools. "
        "Supported languages: Python, JavaScript/TypeScript, Go, Rust."
    ),
)


# =============================================================================
# Enums & Input Models
# =============================================================================


class PaymentMethod(str, Enum):
    CREDIT_CARD = "credit_card"
    GOPAY = "gopay"
    QRIS = "qris"
    SHOPEEPAY = "shopeepay"
    OVO = "ovo"
    DANA = "dana"
    GOOGLE_PAY = "google_pay"
    BCA_VA = "bca_va"
    BNI_VA = "bni_va"
    BRI_VA = "bri_va"
    PERMATA_VA = "permata_va"
    MANDIRI_BILL = "mandiri_bill"
    CIMB_VA = "cimb_va"
    INDOMARET = "indomaret"
    ALFAMART = "alfamart"
    AKULAKU = "akulaku"
    KREDIVO = "kredivo"


class JsonObjectType(str, Enum):
    TRANSACTION_DETAILS = "transaction_details"
    CUSTOMER_DETAILS = "customer_details"
    ITEM_DETAILS = "item_details"
    SELLER_DETAILS = "seller_details"
    CUSTOM_EXPIRY = "custom_expiry"
    CREDIT_CARD = "credit_card_object"
    GOPAY = "gopay_object"
    SHOPEEPAY = "shopeepay_object"
    BANK_TRANSFER = "bank_transfer_object"
    ECHANNEL = "echannel_object"
    QRIS = "qris_object"
    OVO = "ovo_object"
    CONVENIENCE_STORE = "convenience_store_object"
    ACTION = "action_object"
    PAYMENT_AMOUNT = "payment_amount_object"
    DANA = "dana_object"
    GOOGLE_PAY = "google_pay_object"


class StatusCodeRange(str, Enum):
    CODE_2XX = "2xx"
    CODE_3XX = "3xx"
    CODE_4XX = "4xx"
    CODE_5XX = "5xx"


class ProgrammingLanguage(str, Enum):
    PYTHON = "python"
    JAVASCRIPT = "javascript"
    GO = "go"
    RUST = "rust"


class DocumentationTopic(str, Enum):
    OVERVIEW = "overview"
    AUTHORIZATION = "authorization"
    HTTP_REQUEST = "http_request"
    API_ENDPOINTS = "api_endpoints"
    CHARGE = "charge"
    PAYMENT_METHODS = "payment_methods"
    NOTIFICATION = "notification"
    TRANSACTION_MANAGEMENT = "transaction_management"
    TRANSACTION_STATUS = "transaction_status"
    CHANNEL_RESPONSE = "channel_response"
    SUBSCRIPTION = "subscription"
    PAYMENT_LINK = "payment_link"
    INVOICING = "invoicing"
    MERCHANT_BALANCE = "merchant_balance"
    TESTING = "testing"
    STATUS_CODES = "status_codes"


# =============================================================================
# Input Models
# =============================================================================


class GetDocumentationMapInput(BaseModel):
    """Input for getting the documentation map."""

    model_config = ConfigDict(str_strip_whitespace=True)


class GetDocumentationTopicInput(BaseModel):
    """Input for getting documentation on a specific topic."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    topic: DocumentationTopic = Field(
        ...,
        description=(
            "Documentation topic to retrieve. Options: "
            "overview, authorization, http_request, api_endpoints, charge, "
            "payment_methods, notification, transaction_management, "
            "transaction_status, channel_response, subscription, "
            "payment_link, invoicing, merchant_balance, testing, status_codes"
        ),
    )


class GetPaymentMethodGuideInput(BaseModel):
    """Input for getting a specific payment method integration guide."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    payment_method: PaymentMethod = Field(
        ...,
        description=(
            "Payment method to get guide for. Options: "
            "credit_card, gopay, qris, shopeepay, ovo, dana, google_pay, "
            "bca_va, bni_va, bri_va, permata_va, mandiri_bill, cimb_va, "
            "indomaret, alfamart, akulaku, kredivo"
        ),
    )


class GetJsonObjectSchemaInput(BaseModel):
    """Input for getting a JSON object schema reference."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    object_type: JsonObjectType = Field(
        ...,
        description=(
            "JSON object type to get schema for. Options: "
            "transaction_details, customer_details, item_details, seller_details, "
            "custom_expiry, credit_card_object, gopay_object, shopeepay_object, "
            "bank_transfer_object, echannel_object, qris_object, ovo_object, "
            "convenience_store_object, action_object, payment_amount_object, "
            "dana_object, google_pay_object"
        ),
    )


class GetStatusCodesInput(BaseModel):
    """Input for getting status code reference."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    code_range: StatusCodeRange = Field(
        ...,
        description="Status code range: 2xx, 3xx, 4xx, or 5xx",
    )


class GetCodeExampleInput(BaseModel):
    """Input for getting implementation code examples."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    language: ProgrammingLanguage = Field(
        ...,
        description="Programming language: python, javascript, go, or rust",
    )


class SearchDocumentationInput(BaseModel):
    """Input for searching across all documentation."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    query: str = Field(
        ...,
        description=(
            "Search query to find relevant documentation. "
            "Examples: 'gopay charge', 'notification webhook', "
            "'virtual account bca', 'refund', '3d secure', 'subscription'"
        ),
        min_length=2,
        max_length=200,
    )


class GetChargeExampleInput(BaseModel):
    """Input for getting a charge request example for a specific payment type."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    payment_method: PaymentMethod = Field(
        ...,
        description="Payment method to get charge example for",
    )
    include_customer_details: bool = Field(
        default=True,
        description="Whether to include customer_details in the example",
    )
    include_item_details: bool = Field(
        default=False,
        description="Whether to include item_details in the example",
    )


# =============================================================================
# Tools
# =============================================================================


@mcp.tool(
    name="midtrans_get_documentation_map",
    annotations={
        "title": "Get Midtrans Documentation Map",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def midtrans_get_documentation_map(params: GetDocumentationMapInput) -> str:
    """Get the complete Midtrans Core API documentation map showing all available
    topics, APIs, payment methods, and guides. Use this as your starting point to
    understand what documentation is available and navigate to specific topics.

    Returns:
        str: Complete documentation map with categorized links to all Midtrans
        Core API documentation topics including APIs, payment methods, and guides.
    """
    return DOCUMENTATION_MAP


@mcp.tool(
    name="midtrans_get_documentation",
    annotations={
        "title": "Get Midtrans Documentation by Topic",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def midtrans_get_documentation(params: GetDocumentationTopicInput) -> str:
    """Get detailed documentation for a specific Midtrans Core API topic.

    Covers: overview, authorization, HTTP requests, API endpoints,
    charge transactions, payment methods list, notifications, transaction management,
    transaction status guide, channel response codes, subscriptions, payment links,
    invoicing, merchant balance, testing credentials, and status codes.

    Args:
        params: Contains the topic to retrieve documentation for.

    Returns:
        str: Detailed documentation for the requested topic including
        explanations, code examples, request/response formats, and best practices.
    """
    topic_map = {
        DocumentationTopic.OVERVIEW: MIDTRANS_OVERVIEW,
        DocumentationTopic.AUTHORIZATION: AUTHORIZATION_GUIDE,
        DocumentationTopic.HTTP_REQUEST: HTTP_REQUEST_GUIDE,
        DocumentationTopic.API_ENDPOINTS: API_ENDPOINTS,
        DocumentationTopic.CHARGE: CHARGE_TRANSACTION_GUIDE,
        DocumentationTopic.PAYMENT_METHODS: PAYMENT_METHODS_LIST,
        DocumentationTopic.NOTIFICATION: NOTIFICATION_GUIDE,
        DocumentationTopic.TRANSACTION_MANAGEMENT: TRANSACTION_MANAGEMENT_GUIDE,
        DocumentationTopic.TRANSACTION_STATUS: TRANSACTION_STATUS_GUIDE,
        DocumentationTopic.CHANNEL_RESPONSE: CHANNEL_RESPONSE_CODES,
        DocumentationTopic.SUBSCRIPTION: SUBSCRIPTION_GUIDE,
        DocumentationTopic.PAYMENT_LINK: PAYMENT_LINK_GUIDE,
        DocumentationTopic.INVOICING: INVOICING_GUIDE,
        DocumentationTopic.MERCHANT_BALANCE: MERCHANT_BALANCE_GUIDE,
        DocumentationTopic.TESTING: TESTING_CREDENTIALS,
        DocumentationTopic.STATUS_CODES: "\n\n".join(STATUS_CODES.values()),
    }

    result = topic_map.get(params.topic)
    if result:
        return result
    return f"Documentation for topic '{params.topic}' not found. Use midtrans_get_documentation_map to see available topics."


@mcp.tool(
    name="midtrans_get_payment_method_guide",
    annotations={
        "title": "Get Payment Method Integration Guide",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def midtrans_get_payment_method_guide(
    params: GetPaymentMethodGuideInput,
) -> str:
    """Get a complete integration guide for a specific Midtrans payment method.

    Includes charge request format, response format, integration flow,
    special features, and sandbox testing information.

    Supported: credit_card, gopay, qris, shopeepay, ovo, dana, google_pay,
    bca_va, bni_va, bri_va, permata_va, mandiri_bill, cimb_va,
    indomaret, alfamart, akulaku, kredivo.

    Args:
        params: Contains the payment method to get the guide for.

    Returns:
        str: Complete integration guide with request/response examples,
        flow descriptions, and payment-method-specific notes.
    """
    result = PAYMENT_METHOD_DETAILS.get(params.payment_method.value)
    if result:
        return result
    return (
        f"Guide for payment method '{params.payment_method}' not found. "
        "Use midtrans_get_documentation with topic='payment_methods' to see all available methods."
    )


@mcp.tool(
    name="midtrans_get_json_object_schema",
    annotations={
        "title": "Get JSON Object Schema Reference",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def midtrans_get_json_object_schema(
    params: GetJsonObjectSchemaInput,
) -> str:
    """Get the detailed JSON object schema for Midtrans API request/response objects.

    Includes field definitions, types, required status, descriptions,
    and example JSON for each object type.

    Available objects: transaction_details, customer_details, item_details,
    seller_details, custom_expiry, credit_card_object, gopay_object,
    shopeepay_object, bank_transfer_object, echannel_object, qris_object,
    ovo_object, convenience_store_object, action_object, payment_amount_object,
    dana_object, google_pay_object.

    Args:
        params: Contains the object type to get schema for.

    Returns:
        str: Detailed schema with field table, example JSON, and usage notes.
    """
    result = JSON_OBJECT_SCHEMAS.get(params.object_type.value)
    if result:
        return result
    return (
        f"Schema for object type '{params.object_type}' not found. "
        "Available types: " + ", ".join(JSON_OBJECT_SCHEMAS.keys())
    )


@mcp.tool(
    name="midtrans_get_status_codes",
    annotations={
        "title": "Get Midtrans Status Codes",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def midtrans_get_status_codes(params: GetStatusCodesInput) -> str:
    """Get Midtrans HTTP status code reference for a specific range.

    Includes status code numbers, descriptions, common scenarios,
    and troubleshooting tips.

    Args:
        params: Contains the status code range (2xx, 3xx, 4xx, or 5xx).

    Returns:
        str: Status code reference table with descriptions and handling guidance.
    """
    result = STATUS_CODES.get(params.code_range.value)
    if result:
        return result
    return f"Status codes for range '{params.code_range}' not found."


@mcp.tool(
    name="midtrans_get_code_example",
    annotations={
        "title": "Get Implementation Code Example",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def midtrans_get_code_example(params: GetCodeExampleInput) -> str:
    """Get complete implementation code examples for Midtrans Core API integration
    in a specific programming language.

    Includes: charge transactions, transaction status checks, cancellation,
    refunds, notification/webhook handlers with signature verification,
    and subscription management.

    Available languages: python (requests/Flask/FastAPI), javascript (fetch/Express
    with TypeScript types), go (net/http), rust (reqwest/actix-web/axum).

    Args:
        params: Contains the programming language.

    Returns:
        str: Complete code examples including imports, configuration,
        API calls, and webhook handlers.
    """
    result = IMPLEMENTATION_EXAMPLES.get(params.language.value)
    if result:
        return result
    return (
        f"Code example for '{params.language}' not found. "
        "Available: python, javascript, go, rust"
    )


@mcp.tool(
    name="midtrans_search_documentation",
    annotations={
        "title": "Search Midtrans Documentation",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def midtrans_search_documentation(
    params: SearchDocumentationInput,
) -> str:
    """Search across all Midtrans Core API documentation for relevant information.

    Searches through all documentation topics, payment method guides,
    JSON schemas, code examples, and reference materials.

    Use this when you need to find specific information across multiple
    documentation sections or when unsure which topic contains the answer.

    Args:
        params: Contains the search query string.

    Returns:
        str: Matching documentation sections with relevant content.
    """
    query = params.query.lower()
    results: list[str] = []

    all_docs = {
        "Overview": MIDTRANS_OVERVIEW,
        "Authorization": AUTHORIZATION_GUIDE,
        "HTTP Request": HTTP_REQUEST_GUIDE,
        "API Endpoints": API_ENDPOINTS,
        "Charge Transaction": CHARGE_TRANSACTION_GUIDE,
        "Payment Methods": PAYMENT_METHODS_LIST,
        "Notification Handling": NOTIFICATION_GUIDE,
        "Transaction Management": TRANSACTION_MANAGEMENT_GUIDE,
        "Transaction Status": TRANSACTION_STATUS_GUIDE,
        "Channel Response Codes": CHANNEL_RESPONSE_CODES,
        "Subscription": SUBSCRIPTION_GUIDE,
        "Payment Link": PAYMENT_LINK_GUIDE,
        "Invoicing": INVOICING_GUIDE,
        "Merchant Balance": MERCHANT_BALANCE_GUIDE,
        "Testing Credentials": TESTING_CREDENTIALS,
    }

    # Search main docs
    for name, content in all_docs.items():
        if query in content.lower():
            results.append(f"## Found in: {name}\n{content}")

    # Search payment method details
    for method, content in PAYMENT_METHOD_DETAILS.items():
        if query in content.lower():
            results.append(f"## Found in: Payment Method - {method}\n{content}")

    # Search JSON schemas
    for obj_type, content in JSON_OBJECT_SCHEMAS.items():
        if query in content.lower():
            results.append(f"## Found in: JSON Schema - {obj_type}\n{content}")

    # Search status codes
    for code_range, content in STATUS_CODES.items():
        if query in content.lower():
            results.append(f"## Found in: Status Codes {code_range}\n{content}")

    # Search code examples
    for lang, content in IMPLEMENTATION_EXAMPLES.items():
        if query in content.lower():
            results.append(f"## Found in: Code Example - {lang}\n{content}")

    if results:
        header = f"# Search Results for: '{params.query}'\n\nFound {len(results)} matching section(s).\n\n"
        return header + "\n\n---\n\n".join(results[:5])

    return (
        f"No documentation found matching '{params.query}'. "
        "Try broader terms or use midtrans_get_documentation_map to browse available topics. "
        "Example queries: 'gopay', 'virtual account', 'notification', 'refund', 'subscription'"
    )


@mcp.tool(
    name="midtrans_get_charge_example",
    annotations={
        "title": "Get Charge Request Example",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def midtrans_get_charge_example(params: GetChargeExampleInput) -> str:
    """Generate a complete charge request JSON example for a specific payment method.

    Creates a ready-to-use charge request body with all required fields
    and optionally includes customer_details and item_details.

    Args:
        params: Contains payment method, and flags for optional sections.

    Returns:
        str: Complete charge request JSON example with curl command
        and response format.
    """
    import json

    method = params.payment_method.value

    # Build base request
    request_body: dict = {
        "transaction_details": {
            "order_id": "ORDER-" + method.upper() + "-001",
            "gross_amount": 100000,
        }
    }

    # Add payment type and method-specific fields
    if method == "credit_card":
        request_body["payment_type"] = "credit_card"
        request_body["credit_card"] = {
            "token_id": "<TOKEN_FROM_GET_TOKEN_API>",
            "authentication": True,
        }
    elif method == "gopay":
        request_body["payment_type"] = "gopay"
        request_body["gopay"] = {
            "enable_callback": True,
            "callback_url": "https://yourapp.com/gopay-finish",
        }
    elif method == "qris":
        request_body["payment_type"] = "qris"
        request_body["qris"] = {"acquirer": "gopay"}
    elif method == "shopeepay":
        request_body["payment_type"] = "shopeepay"
        request_body["shopeepay"] = {
            "callback_url": "https://yourapp.com/shopeepay-finish"
        }
    elif method == "ovo":
        request_body["payment_type"] = "ovo"
        # OVO requires phone in customer_details
        params.include_customer_details = True
    elif method == "dana":
        request_body["payment_type"] = "dana"
        request_body["dana"] = {
            "callback_url": "https://yourapp.com/dana-finish",
        }
    elif method == "google_pay":
        request_body["payment_type"] = "googlepay"
        request_body["payment_amount"] = {
            "paid_amount": 100000,
        }
    elif method in ("bca_va", "bni_va", "bri_va", "permata_va", "cimb_va"):
        bank = method.replace("_va", "")
        request_body["payment_type"] = "bank_transfer"
        request_body["bank_transfer"] = {"bank": bank}
    elif method == "mandiri_bill":
        request_body["payment_type"] = "echannel"
        request_body["echannel"] = {
            "bill_info1": "Payment:",
            "bill_info2": "Online purchase",
        }
    elif method in ("indomaret", "alfamart"):
        request_body["payment_type"] = "cstore"
        request_body["cstore"] = {"store": method}
    elif method == "akulaku":
        request_body["payment_type"] = "akulaku"
    elif method == "kredivo":
        request_body["payment_type"] = "kredivo"
        params.include_item_details = True  # Required for Kredivo

    # Add optional sections
    if params.include_customer_details:
        request_body["customer_details"] = {
            "first_name": "Budi",
            "last_name": "Utomo",
            "email": "budi.utomo@example.com",
            "phone": "081223323423",
        }

    if params.include_item_details:
        request_body["item_details"] = [
            {
                "id": "ITEM-1",
                "price": 100000,
                "quantity": 1,
                "name": "Product Name",
            }
        ]

    body_json = json.dumps(request_body, indent=2)

    result = f"""# Charge Request Example: {method}

## Endpoint
POST https://api.sandbox.midtrans.com/v2/charge

## Headers
```
Content-Type: application/json
Accept: application/json
Authorization: Basic {{base64(server_key:)}}
```

## Request Body
```json
{body_json}
```

## cURL Command
```bash
curl -X POST https://api.sandbox.midtrans.com/v2/charge \\
  -H "Authorization: Basic <BASE64_SERVER_KEY>" \\
  -H "Content-Type: application/json" \\
  -H "Accept: application/json" \\
  -d '{json.dumps(request_body)}'
```

## Notes
- Replace `<BASE64_SERVER_KEY>` with Base64 of your `server_key:`
- Replace `ORDER-{method.upper()}-001` with your unique order ID
- gross_amount is in IDR (Indonesian Rupiah), no decimal
"""

    if method == "credit_card":
        result += "- Replace `<TOKEN_FROM_GET_TOKEN_API>` with token from frontend tokenization\n"
        result += "- Set `authentication: true` for 3D Secure (recommended)\n"
    elif method == "ovo":
        result += "- `customer_details.phone` is REQUIRED for OVO\n"
    elif method == "dana":
        result += "- `callback_url` is REQUIRED for DANA to redirect user back\n"
    elif method == "google_pay":
        result += "- Google Pay uses `googlepay` as payment_type\n"
        result += "- `payment_amount.paid_amount` specifies the amount charged\n"
    elif method == "kredivo":
        result += "- `item_details` is REQUIRED for Kredivo\n"

    return result


@mcp.tool(
    name="midtrans_get_notification_handler",
    annotations={
        "title": "Get Notification Handler Code",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def midtrans_get_notification_handler(
    params: GetCodeExampleInput,
) -> str:
    """Get a complete notification/webhook handler implementation for
    a specific programming language.

    Includes: signature verification, transaction status handling,
    idempotent processing, and error handling.

    Available languages: python, javascript, go, rust.

    Args:
        params: Contains the programming language.

    Returns:
        str: Complete webhook handler code with signature verification
        and all transaction status cases.
    """
    handlers = {
        "python": """
# Python Notification Handler (Flask + FastAPI)

## Flask Version
```python
import hashlib
import json
from flask import Flask, request, jsonify, abort

app = Flask(__name__)
SERVER_KEY = "SB-Mid-server-xxxx"  # Store in environment variable!

def verify_signature(notification: dict) -> bool:
    order_id = notification.get("order_id", "")
    status_code = notification.get("status_code", "")
    gross_amount = notification.get("gross_amount", "")
    signature = notification.get("signature_key", "")
    raw = f"{order_id}{status_code}{gross_amount}{SERVER_KEY}"
    calculated = hashlib.sha512(raw.encode()).hexdigest()
    return calculated == signature

def process_transaction(order_id: str, status: str, fraud_status: str, payment_type: str):
    if status == "capture":
        if payment_type == "credit_card":
            if fraud_status == "accept":
                update_order_status(order_id, "paid")
            elif fraud_status == "challenge":
                update_order_status(order_id, "review")
            elif fraud_status == "deny":
                update_order_status(order_id, "denied")
    elif status == "settlement":
        update_order_status(order_id, "paid")
    elif status == "pending":
        update_order_status(order_id, "pending")
    elif status in ("deny", "cancel", "expire"):
        update_order_status(order_id, "failed")
    elif status == "refund":
        update_order_status(order_id, "refunded")
    elif status == "partial_refund":
        update_order_status(order_id, "partial_refund")

def update_order_status(order_id: str, status: str):
    print(f"Order {order_id} -> {status}")
    # db.orders.update(order_id, status=status)

@app.route("/midtrans/notification", methods=["POST"])
def handle_notification():
    notification = request.json
    if not notification:
        abort(400, "Empty notification body")
    if not verify_signature(notification):
        abort(403, "Invalid signature")

    order_id = notification["order_id"]
    transaction_status = notification["transaction_status"]
    fraud_status = notification.get("fraud_status", "")
    payment_type = notification.get("payment_type", "")
    process_transaction(order_id, transaction_status, fraud_status, payment_type)
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(port=5000)
```

## FastAPI Version
```python
from fastapi import FastAPI, Request, HTTPException
import hashlib

app = FastAPI()
SERVER_KEY = "SB-Mid-server-xxxx"  # Store in environment variable!

@app.post("/midtrans/notification")
async def handle_notification(request: Request):
    notification = await request.json()
    order_id = notification.get("order_id", "")
    status_code = notification.get("status_code", "")
    gross_amount = notification.get("gross_amount", "")
    signature = notification.get("signature_key", "")

    raw = f"{order_id}{status_code}{gross_amount}{SERVER_KEY}"
    expected = hashlib.sha512(raw.encode()).hexdigest()
    if expected != signature:
        raise HTTPException(status_code=403, detail="Invalid signature")

    status = notification["transaction_status"]
    fraud = notification.get("fraud_status", "")
    # Process based on status...
    return {"status": "ok"}
```
""",
        "javascript": """
# JavaScript/TypeScript Notification Handler (Express)

## JavaScript (Express)
```javascript
const express = require('express');
const crypto = require('crypto');
const app = express();
app.use(express.json());

const SERVER_KEY = process.env.MIDTRANS_SERVER_KEY || 'SB-Mid-server-xxxx';

function verifySignature(notification) {
  const { order_id, status_code, gross_amount, signature_key } = notification;
  const raw = order_id + status_code + gross_amount + SERVER_KEY;
  const hash = crypto.createHash('sha512').update(raw).digest('hex');
  return hash === signature_key;
}

function processTransaction(orderId, status, fraudStatus, paymentType) {
  switch (status) {
    case 'capture':
      if (paymentType === 'credit_card') {
        if (fraudStatus === 'accept') updateOrderStatus(orderId, 'paid');
        else if (fraudStatus === 'challenge') updateOrderStatus(orderId, 'review');
        else if (fraudStatus === 'deny') updateOrderStatus(orderId, 'denied');
      }
      break;
    case 'settlement':
      updateOrderStatus(orderId, 'paid');
      break;
    case 'pending':
      updateOrderStatus(orderId, 'pending');
      break;
    case 'cancel':
    case 'deny':
    case 'expire':
      updateOrderStatus(orderId, 'failed');
      break;
    case 'refund':
      updateOrderStatus(orderId, 'refunded');
      break;
    case 'partial_refund':
      updateOrderStatus(orderId, 'partial_refund');
      break;
  }
}

function updateOrderStatus(orderId, status) {
  console.log(`Order ${orderId} -> ${status}`);
}

app.post('/midtrans/notification', (req, res) => {
  const notification = req.body;
  if (!verifySignature(notification)) {
    return res.status(403).json({ error: 'Invalid signature' });
  }
  const { order_id, transaction_status, fraud_status, payment_type } = notification;
  processTransaction(order_id, transaction_status, fraud_status || '', payment_type || '');
  res.status(200).json({ status: 'ok' });
});

app.listen(3000, () => console.log('Server running on port 3000'));
```

## TypeScript Version
```typescript
import express, { Request, Response } from 'express';
import crypto from 'crypto';

interface MidtransNotification {
  order_id: string;
  status_code: string;
  gross_amount: string;
  signature_key: string;
  transaction_status: string;
  fraud_status?: string;
  payment_type?: string;
}

const app = express();
app.use(express.json());

const SERVER_KEY = process.env.MIDTRANS_SERVER_KEY || 'SB-Mid-server-xxxx';

function verifySignature(notification: MidtransNotification): boolean {
  const { order_id, status_code, gross_amount, signature_key } = notification;
  const raw = order_id + status_code + gross_amount + SERVER_KEY;
  const hash = crypto.createHash('sha512').update(raw).digest('hex');
  return hash === signature_key;
}

app.post('/midtrans/notification', (req: Request, res: Response) => {
  const notification = req.body as MidtransNotification;
  if (!verifySignature(notification)) {
    return res.status(403).json({ error: 'Invalid signature' });
  }

  const { order_id, transaction_status, fraud_status, payment_type } = notification;

  switch (transaction_status) {
    case 'capture':
      if (payment_type === 'credit_card' && fraud_status === 'accept') {
        console.log(`Order ${order_id}: paid`);
      }
      break;
    case 'settlement':
      console.log(`Order ${order_id}: paid`);
      break;
    case 'pending':
      console.log(`Order ${order_id}: pending`);
      break;
    case 'cancel':
    case 'deny':
    case 'expire':
      console.log(`Order ${order_id}: failed`);
      break;
    case 'refund':
    case 'partial_refund':
      console.log(`Order ${order_id}: refunded`);
      break;
  }

  res.status(200).json({ status: 'ok' });
});

app.listen(3000, () => console.log('Server running on port 3000'));
```
""",
        "go": """
# Go Notification Handler

```go
package main

import (
    "crypto/sha512"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "os"
)

var serverKey = os.Getenv("MIDTRANS_SERVER_KEY")

type Notification struct {
    OrderID           string `json:"order_id"`
    StatusCode        string `json:"status_code"`
    GrossAmount       string `json:"gross_amount"`
    SignatureKey       string `json:"signature_key"`
    TransactionStatus string `json:"transaction_status"`
    FraudStatus       string `json:"fraud_status"`
    PaymentType       string `json:"payment_type"`
}

func verifySignature(n Notification) bool {
    raw := n.OrderID + n.StatusCode + n.GrossAmount + serverKey
    hash := sha512.Sum512([]byte(raw))
    return fmt.Sprintf("%x", hash) == n.SignatureKey
}

func handleNotification(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        http.Error(w, "Method not allowed", 405)
        return
    }

    var notification Notification
    if err := json.NewDecoder(r.Body).Decode(&notification); err != nil {
        http.Error(w, "Bad request", 400)
        return
    }

    if !verifySignature(notification) {
        http.Error(w, "Invalid signature", 403)
        return
    }

    switch notification.TransactionStatus {
    case "capture":
        if notification.FraudStatus == "accept" {
            log.Printf("Order %s: paid", notification.OrderID)
        } else if notification.FraudStatus == "challenge" {
            log.Printf("Order %s: review", notification.OrderID)
        }
    case "settlement":
        log.Printf("Order %s: paid", notification.OrderID)
    case "pending":
        log.Printf("Order %s: pending", notification.OrderID)
    case "cancel", "deny", "expire":
        log.Printf("Order %s: failed", notification.OrderID)
    case "refund", "partial_refund":
        log.Printf("Order %s: refunded", notification.OrderID)
    }

    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(200)
    json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
}

func main() {
    http.HandleFunc("/midtrans/notification", handleNotification)
    log.Fatal(http.ListenAndServe(":8080", nil))
}
```
""",
        "rust": """
# Rust Notification Handler (Actix-web)

## Cargo.toml dependencies
```toml
[dependencies]
actix-web = "4"
serde = { version = "1", features = ["derive"] }
serde_json = "1"
sha2 = "0.10"
hex = "0.4"
tokio = { version = "1", features = ["full"] }
```

## src/main.rs
```rust
use actix_web::{web, App, HttpServer, HttpResponse, middleware};
use serde::{Deserialize, Serialize};
use sha2::{Sha512, Digest};

#[derive(Deserialize)]
struct Notification {
    order_id: String,
    status_code: String,
    gross_amount: String,
    signature_key: String,
    transaction_status: String,
    fraud_status: Option<String>,
    payment_type: Option<String>,
}

#[derive(Serialize)]
struct Response {
    status: String,
}

fn verify_signature(notification: &Notification, server_key: &str) -> bool {
    let raw = format!(
        "{}{}{}{}",
        notification.order_id,
        notification.status_code,
        notification.gross_amount,
        server_key
    );
    let mut hasher = Sha512::new();
    hasher.update(raw.as_bytes());
    let result = hex::encode(hasher.finalize());
    result == notification.signature_key
}

async fn handle_notification(
    body: web::Json<Notification>,
) -> HttpResponse {
    let server_key = std::env::var("MIDTRANS_SERVER_KEY")
        .unwrap_or_else(|_| "SB-Mid-server-xxxx".to_string());

    if !verify_signature(&body, &server_key) {
        return HttpResponse::Forbidden().json(Response {
            status: "invalid signature".to_string(),
        });
    }

    let fraud_status = body.fraud_status.as_deref().unwrap_or("");
    let payment_type = body.payment_type.as_deref().unwrap_or("");

    match body.transaction_status.as_str() {
        "capture" => {
            if payment_type == "credit_card" {
                match fraud_status {
                    "accept" => println!("Order {}: paid", body.order_id),
                    "challenge" => println!("Order {}: review", body.order_id),
                    "deny" => println!("Order {}: denied", body.order_id),
                    _ => {}
                }
            }
        }
        "settlement" => println!("Order {}: paid", body.order_id),
        "pending" => println!("Order {}: pending", body.order_id),
        "cancel" | "deny" | "expire" => println!("Order {}: failed", body.order_id),
        "refund" | "partial_refund" => println!("Order {}: refunded", body.order_id),
        _ => println!("Order {}: unknown status {}", body.order_id, body.transaction_status),
    }

    HttpResponse::Ok().json(Response {
        status: "ok".to_string(),
    })
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    HttpServer::new(|| {
        App::new()
            .route("/midtrans/notification", web::post().to(handle_notification))
    })
    .bind("0.0.0.0:8080")?
    .run()
    .await
}
```

## Axum Version
```rust
use axum::{routing::post, Json, Router};
use serde::{Deserialize, Serialize};
use sha2::{Sha512, Digest};

#[derive(Deserialize)]
struct Notification {
    order_id: String,
    status_code: String,
    gross_amount: String,
    signature_key: String,
    transaction_status: String,
    fraud_status: Option<String>,
    payment_type: Option<String>,
}

#[derive(Serialize)]
struct Resp {
    status: String,
}

async fn handle_notification(Json(body): Json<Notification>) -> Json<Resp> {
    let server_key = std::env::var("MIDTRANS_SERVER_KEY")
        .unwrap_or_else(|_| "SB-Mid-server-xxxx".to_string());

    let raw = format!("{}{}{}{}", body.order_id, body.status_code, body.gross_amount, server_key);
    let hash = hex::encode(Sha512::digest(raw.as_bytes()));

    if hash != body.signature_key {
        return Json(Resp { status: "invalid signature".to_string() });
    }

    match body.transaction_status.as_str() {
        "settlement" | "capture" => println!("Order {}: paid", body.order_id),
        "pending" => println!("Order {}: pending", body.order_id),
        "cancel" | "deny" | "expire" => println!("Order {}: failed", body.order_id),
        "refund" | "partial_refund" => println!("Order {}: refunded", body.order_id),
        other => println!("Order {}: {}", body.order_id, other),
    }

    Json(Resp { status: "ok".to_string() })
}

#[tokio::main]
async fn main() {
    let app = Router::new().route("/midtrans/notification", post(handle_notification));
    let listener = tokio::net::TcpListener::bind("0.0.0.0:8080").await.unwrap();
    axum::serve(listener, app).await.unwrap();
}
```
""",
    }

    result = handlers.get(params.language.value)
    if result:
        return result
    return f"Notification handler for '{params.language}' not found. Available: python, javascript, go, rust"


def main():
    """Run the MCP server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
