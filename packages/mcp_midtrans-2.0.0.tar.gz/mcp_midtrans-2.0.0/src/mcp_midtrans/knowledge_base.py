"""
Midtrans Core API comprehensive knowledge base.
Contains all documentation, API references, payment method guides,
JSON object schemas, status codes, and implementation examples.

Languages: Python, Go, Rust, JavaScript/TypeScript
Focus: Core API (NOT Snap)
"""

# =============================================================================
# OVERVIEW & GETTING STARTED
# =============================================================================

MIDTRANS_OVERVIEW = """
# Midtrans Core API Overview

Midtrans is Indonesia's leading online payment gateway. This documentation covers
the **Core API** integration which gives you full control over the payment UI/UX.

## Core API vs Snap
- **Core API**: Direct API integration, full control over checkout UI, custom payment flow
- **Snap**: Pre-built payment UI (NOT covered in this documentation)

## Products Available via Core API

### 1. Payment API (Core API)
- Direct charge transactions for all payment methods
- Full control over UI/UX
- Requires handling payment-method-specific flows
- POST /v2/charge for all payment types

### 2. Subscription API
- Recurring payment management
- Supports credit card and GoPay
- Automatic charge scheduling
- POST /v1/subscriptions

### 3. Payment Link API
- Generate payment links via API
- Share via email, chat, social media
- POST /v1/payment-links

### 4. Invoicing API
- Create and manage invoices programmatically

### 5. Merchant Balance API
- Query merchant balance mutations

## Environments

| Environment | Base URL | Dashboard |
|-------------|----------|-----------|
| Sandbox | https://api.sandbox.midtrans.com | https://dashboard.sandbox.midtrans.com |
| Production | https://api.midtrans.com | https://dashboard.midtrans.com |

## Authentication
- Uses HTTP Basic Auth
- Server Key as username, empty password
- Format: `Authorization: Basic base64({server_key}:)`
- Different keys for Sandbox and Production

## Key Concepts
- **Server Key**: Used for backend API calls (keep secret, NEVER expose to client)
- **Client Key**: Used for frontend (card tokenization via MidtransNew3ds.js)
- **Order ID**: Unique identifier for each transaction (your system, max 50 chars)
- **Transaction ID**: Midtrans-generated unique ID (UUID format)
- **Notification URL**: Webhook endpoint for payment status updates (set in MAP dashboard)
- **MAP**: Midtrans Account Portal (dashboard.midtrans.com)

## Rate Limiting
- API rate limit exists; exceeding returns HTTP 429
- Use Idempotency-Key header for safe retries

## Max Request Size
- Maximum allowed HTTP(S) request size is 16KB
"""

# =============================================================================
# AUTHORIZATION
# =============================================================================

AUTHORIZATION_GUIDE = """
# Midtrans Authorization Guide

## Overview
Midtrans uses HTTP Basic Auth for API authentication. The Server Key is used as
the username with an empty password, encoded in Base64.

## Steps to Create Authorization Header

1. **Get Server Key** from Midtrans Dashboard:
   - Sandbox: https://dashboard.sandbox.midtrans.com/settings/config_info
   - Production: https://dashboard.midtrans.com/settings/config_info

2. **Format**: `{Server_Key}:` (note the colon after the key, password is blank)

3. **Encode to Base64**: Encode the string from step 2

4. **Set Header**: `Authorization: Basic {base64_encoded_string}`

## Example

| Component | Value |
|-----------|-------|
| Server Key | SB-Mid-server-abc123cde456 |
| Basic Auth Format | SB-Mid-server-abc123cde456: |
| Base64 Encoded | U0ItTWlkLXNlcnZlci1hYmMxMjNjZGU0NTY6 |
| Authorization Header | Basic U0ItTWlkLXNlcnZlci1hYmMxMjNjZGU0NTY6 |

## Important Notes
- ALWAYS include the colon `:` after the Server Key before Base64 encoding
- Sandbox and Production Server Keys are DIFFERENT
- When going live, generate NEW API Keys for Production
- NEVER expose Server Key in client-side code or public repositories

## Code Examples (Authorization Header Creation)

### Python
```python
import base64

server_key = "SB-Mid-server-abc123cde456"
auth_string = base64.b64encode(f"{server_key}:".encode()).decode()
headers = {
    "Authorization": f"Basic {auth_string}",
    "Content-Type": "application/json",
    "Accept": "application/json"
}
```

### JavaScript/TypeScript
```typescript
const serverKey = "SB-Mid-server-abc123cde456";
const authString = Buffer.from(`${serverKey}:`).toString("base64");
const headers = {
  "Authorization": `Basic ${authString}`,
  "Content-Type": "application/json",
  "Accept": "application/json"
};
```

### Go
```go
import "encoding/base64"

serverKey := "SB-Mid-server-abc123cde456"
authString := base64.StdEncoding.EncodeToString([]byte(serverKey + ":"))
// Set header: "Authorization": "Basic " + authString
```

### Rust
```rust
use base64::{Engine as _, engine::general_purpose};

let server_key = "SB-Mid-server-abc123cde456";
let auth_string = general_purpose::STANDARD.encode(format!("{}:", server_key));
// Set header: "Authorization": format!("Basic {}", auth_string)
```
"""

# =============================================================================
# HTTP REQUEST
# =============================================================================

HTTP_REQUEST_GUIDE = """
# Midtrans HTTP(S) Request Guide

## API Base URLs

| Environment | Base URL |
|-------------|----------|
| Sandbox | https://api.sandbox.midtrans.com |
| Production | https://api.midtrans.com |

NOTE: In Sandbox, transactions do NOT trigger actual purchases.

## Required HTTP Headers

| Header | Value | Description |
|--------|-------|-------------|
| Content-Type | application/json | Request data format (required for POST) |
| Accept | application/json | Expected response format |
| Authorization | Basic base64(server_key:) | Authentication (see Authorization guide) |

## Optional Headers

| Header | Description | Example |
|--------|-------------|---------|
| Idempotency-Key | Safely handle retry requests (max 46 chars, use UUID) | d63ae3e0-a7c5-4733-8d81-b451168d8a2c |
| X-Payment-Locale | Language for payment web pages (GoPay linking/charge) | en-EN or id-ID |
| X-POP-ID | Merchant's POP ID (conditional, Midtrans will inform if needed) | UUID format |

## Idempotent Requests

The `Idempotency-Key` header prevents duplicate operations on retries:
- If Midtrans doesn't respond due to error, retry safely with same key
- Key lifetime: 5 minutes. After that, request is processed again
- Global across all endpoints - use new key for each different operation
- If retry happens while first request is processing, returns HTTP 202
- Accepted on all POST requests EXCEPT `/token` and `/account` endpoints
- NOT supported for: Permata VA, CIMB Clicks, KlikBCA, Indomaret

## Maximum Request Size
- Maximum allowed size of HTTP(S) request is **16KB**
"""

# =============================================================================
# API ENDPOINTS
# =============================================================================

API_ENDPOINTS = """
# Midtrans Core API Endpoints Reference

## Base URLs
- Sandbox: https://api.sandbox.midtrans.com
- Production: https://api.midtrans.com

## Payment API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /v2/token | Tokenize payment card information before charging |
| POST | /v2/charge | Perform transaction with various payment methods |
| POST | /v2/capture | Capture an authorized card transaction |
| POST | /v2/{order_id}/approve | Approve a challenged transaction (fraud detection) |
| POST | /v2/{order_id}/deny | Deny a challenged transaction |
| POST | /v2/{order_id}/cancel | Cancel transaction (before settlement) |
| POST | /v2/{order_id}/expire | Expire a pending transaction |
| POST | /v2/{order_id}/refund | Refund a settled transaction |
| POST | /v2/{order_id}/refund/online/direct | Direct refund to customer's bank/provider |
| GET | /v2/{order_id}/status | Get transaction status |
| GET | /v2/{order_id}/status/b2b | Get B2B transaction status |
| GET | /v2/card/register | Register card for One Click/Two Clicks |
| GET | /v2/point_inquiry/{token_id} | Get card point balance |
| POST | /v2/pay/account | Link customer account (GoPay tokenization) |
| GET | /v2/pay/account/{account_id} | Get linked account details |
| POST | /v2/pay/account/{account_id}/unbind | Unbind a linked account |
| GET | /v1/bins/{bin_number} | Get BIN metadata for card |

## Subscription API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /v1/subscriptions | Create a subscription |
| GET | /v1/subscriptions/{subscription_id} | Get subscription details |
| POST | /v1/subscriptions/{subscription_id}/disable | Disable a subscription |
| POST | /v1/subscriptions/{subscription_id}/cancel | Cancel a subscription |
| POST | /v1/subscriptions/{subscription_id}/enable | Re-enable a subscription |
| PATCH | /v1/subscriptions/{subscription_id} | Update subscription details |

## Payment Link API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /v1/payment-links | Create a payment link |
| GET | /v1/payment-links/{order_id} | Get payment link details |
| DELETE | /v1/payment-links/{order_id} | Delete a payment link |

## Invoicing API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /v1/invoices | Create an invoice |
| GET | /v1/invoices/{invoice_id} | Get invoice details |
| PATCH | /v1/invoices/{invoice_id} | Void an invoice |

## Merchant Balance API
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /v1/merchant/balance/mutations | Get balance mutations |
"""

# =============================================================================
# CHARGE TRANSACTION GUIDE
# =============================================================================

CHARGE_TRANSACTION_GUIDE = """
# Charge Transactions Guide (Core API)

## Endpoint
POST https://api.sandbox.midtrans.com/v2/charge

## Request Headers
```
Content-Type: application/json
Accept: application/json
Authorization: Basic {base64(server_key:)}
```

## Minimal Request Body
```json
{
  "payment_type": "<payment_method>",
  "transaction_details": {
    "order_id": "unique-order-id",
    "gross_amount": 100000
  }
}
```

## payment_type Values

| payment_type | Payment Method |
|--------------|---------------|
| credit_card | Credit/Debit Card |
| gopay | GoPay / GoPay QRIS |
| shopeepay | ShopeePay |
| qris | QRIS (generic) |
| ovo | OVO |
| dana | DANA |
| bank_transfer | Bank Transfer (VA) - BCA, BNI, BRI, Permata, CIMB |
| echannel | Mandiri Bill Payment |
| cstore | Convenience Store (Indomaret, Alfamart) |
| akulaku | Akulaku PayLater |
| kredivo | Kredivo |
| googlepay | Google Pay |

## Additional Charge Features

### Set Custom Fields
Add up to 3 custom fields (String, max 255 chars each):
```json
{
  "payment_type": "bank_transfer",
  "bank_transfer": {"bank": "permata"},
  "transaction_details": {"order_id": "C17550", "gross_amount": 145000},
  "custom_field1": "custom field 1 content",
  "custom_field2": "custom field 2 content",
  "custom_field3": "custom field 3 content"
}
```
Custom field labels are configured in MAP: Settings > General Settings > Interface Settings.
Values appear in notifications and Get Status responses.

### Set Custom Expiry
```json
{
  "payment_type": "bank_transfer",
  "bank_transfer": {"bank": "permata"},
  "transaction_details": {"order_id": "C17550", "gross_amount": 145000},
  "custom_expiry": {
    "order_time": "2024-12-07 11:54:12 +0700",
    "expiry_duration": 60,
    "unit": "minute"
  }
}
```
- Applies to pending transactions
- Max expiry: QRIS (Shopee/ShopeePay): 5 days, GoPay: 7 days
- If custom_expiry exceeds max, transaction is rejected
- Unit options: "second", "minute", "hour", "day"

### Set Metadata
Free-form JSON object for transaction tagging:
```json
{
  "payment_type": "bank_transfer",
  "bank_transfer": {"bank": "permata"},
  "transaction_details": {"order_id": "C17550", "gross_amount": 145000},
  "metadata": {
    "campaign": "holiday_promo",
    "source": "mobile_app",
    "user_tier": "premium"
  }
}
```
Retrievable via Get Status and HTTP Notifications. Can configure fraud detection rules based on metadata.

## Response Codes
- 200: Success
- 201: Created (pending transaction)
- 400: Validation error (check request parameters)
- 401: Authentication failure (check Server Key)
- 406: Duplicate order_id
- 429: Rate limit exceeded
"""

# =============================================================================
# NOTIFICATION GUIDE
# =============================================================================

NOTIFICATION_GUIDE = """
# Midtrans Notification (Webhook) Guide

## Overview
Midtrans sends HTTP POST notifications to your server when transaction status changes.
Set the Notification URL in MAP: Settings > Configuration > Payment Notification URL.

## How Notifications Work
1. Customer completes/fails payment
2. Midtrans sends HTTP POST to your Notification URL
3. Your server processes the notification
4. Your server returns HTTP 200 (Midtrans retries if not 200)

## Notification JSON Example
```json
{
  "transaction_time": "2024-01-15 10:30:00",
  "transaction_status": "settlement",
  "transaction_id": "1eae238a-cb9e-4f92-b284-aac8b39e4eab",
  "status_message": "midtrans payment notification",
  "status_code": "200",
  "signature_key": "ad7ccda03d8ec6f2f415661fb511d47fcd17dcc...",
  "payment_type": "bank_transfer",
  "order_id": "ORDER-123",
  "merchant_id": "M001234",
  "gross_amount": "100000.00",
  "fraud_status": "accept",
  "currency": "IDR"
}
```

## Signature Verification (CRITICAL)
ALWAYS verify the signature_key before processing:

```
SHA512(order_id + status_code + gross_amount + server_key)
```

Example:
- order_id: "ORDER-123"
- status_code: "200"
- gross_amount: "100000.00"
- server_key: "SB-Mid-server-abc123"
- Input string: "ORDER-123200100000.00SB-Mid-server-abc123"
- Result: SHA512 hash of that string must equal signature_key

## Transaction Status Values

| Status | Description | Action |
|--------|-------------|--------|
| capture | Card payment captured (check fraud_status) | If fraud_status=accept: mark as paid |
| settlement | Payment completed successfully | Mark as paid |
| pending | Waiting for customer payment | Show pending status |
| deny | Payment denied by provider | Mark as failed |
| cancel | Payment cancelled | Mark as cancelled |
| expire | Payment expired (customer didn't pay in time) | Mark as expired |
| refund | Full refund processed | Mark as refunded |
| partial_refund | Partial refund processed | Update refund amount |
| authorize | Pre-authorization successful (card only) | Proceed to capture |

## Fraud Status Values (Card Payments Only)

| Status | Description | Action |
|--------|-------------|--------|
| accept | Transaction safe | Process normally |
| challenge | Suspicious, needs review | Review in MAP dashboard |
| deny | Detected as fraud | Reject transaction |

## Best Practices

1. **Always verify signature** before processing
2. **Return HTTP 200** immediately, process asynchronously
3. **Idempotent processing**: Check if notification was already processed
4. **Use Get Status API** as fallback to verify transaction status
5. **Handle all status values** including edge cases
6. **Log all notifications** for debugging
7. **Retry behavior**: Midtrans retries up to 4 times if no 200 response

## Override Notification URL
You can override the notification URL per-transaction in the charge request:
```json
{
  "payment_type": "gopay",
  "transaction_details": {"order_id": "order-1", "gross_amount": 100000},
  "notification_url": "https://yourapp.com/custom-notification-endpoint"
}
```
"""

# =============================================================================
# TRANSACTION MANAGEMENT
# =============================================================================

TRANSACTION_MANAGEMENT_GUIDE = """
# Transaction Management Guide

## Get Transaction Status
```
GET https://api.sandbox.midtrans.com/v2/{order_id}/status
Authorization: Basic {base64(server_key:)}
Accept: application/json
```

Response includes: transaction_status, fraud_status, payment_type, gross_amount,
transaction_time, settlement_time, and payment-method-specific fields.

## Get Transaction Status B2B
```
GET https://api.sandbox.midtrans.com/v2/{order_id}/status/b2b
```
Returns multiple B2B transactions related to the order.

## Cancel Transaction
```
POST https://api.sandbox.midtrans.com/v2/{order_id}/cancel
Authorization: Basic {base64(server_key:)}
```
- Only for transactions with status: pending, authorize, capture (before settlement)
- Cannot cancel after settlement (use refund instead)

## Expire Transaction
```
POST https://api.sandbox.midtrans.com/v2/{order_id}/expire
Authorization: Basic {base64(server_key:)}
```
- Changes pending transactions to expired status
- Applicable to all payment methods with pending status

## Capture Transaction (Card Only)
```
POST https://api.sandbox.midtrans.com/v2/capture
Authorization: Basic {base64(server_key:)}
Content-Type: application/json

{
  "transaction_id": "uuid-from-charge-response",
  "gross_amount": 100000
}
```
- Only for credit card payments with pre-authorization
- gross_amount can be less than or equal to authorized amount
- Must capture before authorization expires

## Refund Transaction
```
POST https://api.sandbox.midtrans.com/v2/{order_id}/refund
Authorization: Basic {base64(server_key:)}
Content-Type: application/json

{
  "refund_key": "unique-refund-key",
  "amount": 50000,
  "reason": "Customer request"
}
```
- Only for settled transactions
- amount can be partial (less than gross_amount)
- refund_key must be unique per refund attempt

## Direct Refund
```
POST https://api.sandbox.midtrans.com/v2/{order_id}/refund/online/direct
```
- Sends refund directly to customer's bank/payment provider
- Same request body as regular refund
- Faster processing than regular refund

## Approve/Deny Transaction (Fraud Detection)
```
POST https://api.sandbox.midtrans.com/v2/{order_id}/approve
POST https://api.sandbox.midtrans.com/v2/{order_id}/deny
```
- For transactions flagged as "challenge" by Fraud Detection System
- Approve to accept, deny to reject

## BIN API
```
GET https://api.sandbox.midtrans.com/v1/bins/{bin_number}
```
- Returns card metadata: bank, brand (visa/mastercard), type (credit/debit), country
- Supports 6-digit and 8-digit BINs

## Card Registration (One Click / Two Clicks)
```
GET https://api.sandbox.midtrans.com/v2/card/register?card_number={}&card_exp_month={}&card_exp_year={}&client_key={}
```
- Register card for future tokenized payments
- Returns saved_token_id for use in subsequent charges
"""

# =============================================================================
# SUBSCRIPTION GUIDE
# =============================================================================

SUBSCRIPTION_GUIDE = """
# Subscription API Guide

## Overview
Create recurring payments for credit card and GoPay.

## Create Subscription
```
POST https://api.sandbox.midtrans.com/v1/subscriptions
Authorization: Basic {base64(server_key:)}
Content-Type: application/json
```

### Credit Card Subscription
```json
{
  "name": "Monthly Subscription",
  "amount": "100000",
  "currency": "IDR",
  "payment_type": "credit_card",
  "token": "saved_token_id_from_initial_charge",
  "schedule": {
    "interval": 1,
    "interval_unit": "month",
    "max_interval": 12,
    "start_time": "2024-01-15 07:00:00 +0700"
  },
  "retry_schedule": {
    "interval": 1,
    "interval_unit": "day",
    "max_interval": 3
  },
  "customer_details": {
    "first_name": "Budi",
    "last_name": "Utomo",
    "email": "budi@example.com",
    "phone": "081234567890"
  }
}
```

### GoPay Subscription
```json
{
  "name": "Monthly GoPay Sub",
  "amount": "100000",
  "currency": "IDR",
  "payment_type": "gopay",
  "gopay": {
    "account_id": "account_id_from_linking"
  },
  "schedule": {
    "interval": 1,
    "interval_unit": "month",
    "max_interval": 12
  }
}
```

### Schedule interval_unit Options
- "day", "week", "month"

## Manage Subscription

### Get Subscription
```
GET /v1/subscriptions/{subscription_id}
```

### Disable Subscription (pause)
```
POST /v1/subscriptions/{subscription_id}/disable
```

### Enable Subscription (resume)
```
POST /v1/subscriptions/{subscription_id}/enable
```

### Cancel Subscription (permanent)
```
POST /v1/subscriptions/{subscription_id}/cancel
```

### Update Subscription
```
PATCH /v1/subscriptions/{subscription_id}
Content-Type: application/json

{
  "name": "Updated Subscription",
  "amount": "150000",
  "schedule": {
    "interval": 1,
    "interval_unit": "month"
  }
}
```

## Subscription Notifications
Midtrans sends HTTP POST notification for each subscription charge.
The notification body is the same as regular payment notifications.
"""

# =============================================================================
# PAYMENT LINK GUIDE
# =============================================================================

PAYMENT_LINK_GUIDE = """
# Payment Link API Guide

## API Base URLs
- Sandbox: https://api.sandbox.midtrans.com
- Production: https://api.midtrans.com

## Create Payment Link
```
POST /v1/payment-links
Authorization: Basic {base64(server_key:)}
Content-Type: application/json

{
  "transaction_details": {
    "order_id": "link-order-001",
    "gross_amount": 100000,
    "payment_link_id": "my-unique-link-id"
  },
  "credit_card": {
    "secure": true
  },
  "usage_limit": 1,
  "expiry": {
    "start_time": "2024-01-15 10:00:00 +0700",
    "duration": 7,
    "unit": "days"
  },
  "item_details": [
    {
      "id": "item-1",
      "name": "Product Name",
      "price": 100000,
      "quantity": 1
    }
  ],
  "customer_details": {
    "first_name": "Budi",
    "email": "budi@example.com",
    "phone": "081234567890"
  },
  "customer_required": true,
  "custom_field1": "Field 1",
  "title": "Payment for Order",
  "enabled_payments": ["credit_card", "gopay", "bank_transfer"]
}
```

## Get Payment Link Details
```
GET /v1/payment-links/{order_id}
```

## Delete Payment Link
```
DELETE /v1/payment-links/{order_id}
```
"""

# =============================================================================
# INVOICING GUIDE
# =============================================================================

INVOICING_GUIDE = """
# Invoicing API Guide

## Create Invoice
```
POST https://api.sandbox.midtrans.com/v1/invoices
Authorization: Basic {base64(server_key:)}
Content-Type: application/json

{
  "order_id": "invoice-001",
  "invoice_number": "INV-2024-001",
  "due_date": "2024-02-15",
  "customer_details": {
    "id": "cust-001",
    "name": "Budi Utomo",
    "email": "budi@example.com",
    "phone": "081234567890"
  },
  "item_details": [
    {
      "item_id": "item-1",
      "description": "Consulting Service",
      "quantity": 1,
      "price": 500000
    }
  ],
  "notes": "Thank you for your business",
  "payment_type": "payment_link"
}
```

## Get Invoice
```
GET /v1/invoices/{invoice_id}
```

## Void Invoice
```
PATCH /v1/invoices/{invoice_id}
Content-Type: application/json

{
  "status": "void",
  "void_reason": "Customer cancelled order"
}
```
"""

# =============================================================================
# MERCHANT BALANCE GUIDE
# =============================================================================

MERCHANT_BALANCE_GUIDE = """
# Merchant Balance Mutation API

## API Base URL
- Sandbox: https://api.sandbox.midtrans.com
- Production: https://api.midtrans.com

## Get Balance Mutations
```
POST /v1/merchant/balance/mutations
Authorization: Basic {base64(server_key:)}
Content-Type: application/json

{
  "from_date": "2024-01-01",
  "to_date": "2024-01-31"
}
```

Returns a list of balance mutations including settlements, refunds, and payouts.
"""

# =============================================================================
# TESTING CREDENTIALS
# =============================================================================

TESTING_CREDENTIALS = """
# Midtrans Sandbox Testing Credentials

## Sandbox Dashboard
URL: https://dashboard.sandbox.midtrans.com

## Credit Card Test Numbers

### Success Scenarios
| Card Number | Description |
|-------------|-------------|
| 4811 1111 1111 1114 | Visa - Success (no 3DS) |
| 5211 1111 1111 1117 | Mastercard - Success |
| 4511 1111 1111 1117 | Visa - 3DS enrolled |
| 4811 1111 1111 1114 | Full PAN success |

### Failure Scenarios
| Card Number | Description |
|-------------|-------------|
| 4911 1111 1111 1113 | Denied by bank |
| 4411 1111 1111 1118 | Expired card |

### Card Details for Testing
- **CVV**: Any 3 digits (e.g., 123)
- **Expiry**: Any future date (e.g., 01/2030)
- **3DS OTP**: 112233 (for 3DS-enrolled cards)

## Bank Transfer (Virtual Account)

### BCA VA
- Pay via BCA ATM/mobile with the generated VA number

### BNI VA
- Pay via BNI ATM/mobile with the generated VA number

### BRI VA
- Pay via BRI ATM/mobile with the generated VA number

### Permata VA
- Pay via Permata ATM/mobile with the generated VA number

### Mandiri Bill
- Use the generated Bill Key and Biller Code

### CIMB VA
- Pay via CIMB ATM/mobile with the generated VA number

## E-Wallet Testing

### GoPay
- Sandbox will return QR code URL and deeplink URL
- Use the simulator to complete payment

### ShopeePay
- Returns redirect URL to ShopeePay simulator

### OVO
- Returns 200 immediately (simulated)
- Requires valid phone number format in customer_details

### DANA
- Returns redirect URL

### QRIS
- Returns QR code image URL
- Use QRIS simulator to scan and pay

## Over The Counter

### Indomaret
- Returns payment code to present at Indomaret

### Alfamart
- Returns payment code to present at Alfamart

## Cardless Credit

### Akulaku
- Returns redirect URL to Akulaku simulator

### Kredivo
- Returns redirect URL to Kredivo simulator
- Requires item_details in charge request

## Google Pay
- Available in sandbox with test cards

## Important Notes
- Sandbox transactions are NOT real charges
- Settlement occurs automatically or can be triggered via dashboard
- Test notification URL must be publicly accessible (use ngrok for local dev)
- Notification URL set in: MAP > Settings > Configuration > Payment Notification URL
"""

# =============================================================================
# PAYMENT METHODS LIST
# =============================================================================

PAYMENT_METHODS_LIST = """
# Midtrans Core API - All Payment Methods

## Card Payments
| payment_type | Method | Description |
|--------------|--------|-------------|
| credit_card | Credit/Debit Card | Visa, Mastercard, JCB, Amex |

### Card Features
- 3D Secure (3DS) 1.0 and 2.0 (EMV 3DS)
- One Click (saved card, no CVV needed)
- Two Clicks (saved card, CVV required)
- Pre-Authorization (authorize then capture)
- Installment payments
- BIN Promo filtering
- Point redemption
- Full PAN (direct card charge)
- Route to Specific Channel (BNI, Mandiri, BCA, etc.)

## Bank Transfer (Virtual Account)
| payment_type | bank | Method |
|--------------|------|--------|
| bank_transfer | bca | BCA Virtual Account |
| bank_transfer | bni | BNI Virtual Account |
| bank_transfer | bri | BRI Virtual Account |
| bank_transfer | permata | Permata Virtual Account |
| bank_transfer | cimb | CIMB Virtual Account |
| echannel | - | Mandiri Bill Payment |

## E-Wallets
| payment_type | Method | Notes |
|--------------|--------|-------|
| gopay | GoPay | Supports QR, deeplink, callback |
| shopeepay | ShopeePay | Redirect-based flow |
| qris | QRIS | Generic QR standard, acquirer: gopay/airpay |
| ovo | OVO | Requires phone in customer_details |
| dana | DANA | Redirect-based flow |

## Google Pay
| payment_type | Method |
|--------------|--------|
| googlepay | Google Pay |

## Over The Counter (OTC)
| payment_type | store | Method |
|--------------|-------|--------|
| cstore | indomaret | Indomaret |
| cstore | alfamart | Alfamart |

## Cardless Credit
| payment_type | Method |
|--------------|--------|
| akulaku | Akulaku PayLater |
| kredivo | Kredivo (requires item_details) |
"""

# =============================================================================
# TRANSACTION STATUS REFERENCE
# =============================================================================

TRANSACTION_STATUS_GUIDE = """
# Transaction Status Reference

## Transaction Status Values

| Status | Description | Applicable Payment Types |
|--------|-------------|-------------------------|
| authorize | Pre-auth successful, awaiting capture | Credit Card (pre-auth) |
| capture | Payment captured successfully | Credit Card |
| settlement | Payment settled to merchant | All payment types |
| pending | Awaiting customer payment | VA, E-wallet, OTC, Cardless Credit |
| deny | Transaction denied | All payment types |
| cancel | Transaction cancelled by merchant/system | All payment types |
| expire | Transaction expired | All payment types |
| refund | Full refund processed | Credit Card, GoPay, ShopeePay |
| partial_refund | Partial refund processed | Credit Card, GoPay |
| failure | Transaction failed | All payment types |

## Fraud Status Values (Card Only)

| Status | Description | Recommended Action |
|--------|-------------|-------------------|
| accept | Transaction is safe | Process normally |
| challenge | Needs review | Review in MAP, approve or deny |
| deny | Detected as fraud | Reject transaction |

## Status Flow by Payment Type

### Credit Card
1. authorize/capture -> settlement -> refund/partial_refund
2. pending (3DS) -> capture -> settlement
3. pending -> deny/expire

### Bank Transfer (VA)
1. pending -> settlement
2. pending -> expire/cancel

### E-Wallet (GoPay, ShopeePay, OVO, DANA)
1. pending -> settlement
2. pending -> expire/cancel

### Over The Counter
1. pending -> settlement
2. pending -> expire/cancel

### Cardless Credit (Akulaku, Kredivo)
1. pending -> settlement
2. pending -> expire/cancel
"""

# =============================================================================
# CHANNEL RESPONSE CODES
# =============================================================================

CHANNEL_RESPONSE_CODES = """
# Channel Response Codes

## Card Channel Response Codes
These are response codes from the card-issuing bank/network.

| Code | Description | Category |
|------|-------------|----------|
| 00 | Approved | Success |
| 01 | Refer to card issuer | Decline |
| 02 | Refer to card issuer, special | Decline |
| 03 | Invalid merchant | Decline |
| 04 | Pick up card | Decline |
| 05 | Do not honor | Decline |
| 12 | Invalid transaction | Decline |
| 13 | Invalid amount | Decline |
| 14 | Invalid card number | Decline |
| 30 | Format error | Decline |
| 41 | Lost card | Decline |
| 43 | Stolen card | Decline |
| 51 | Insufficient funds | Decline |
| 54 | Expired card | Decline |
| 55 | Incorrect PIN | Decline |
| 61 | Exceeds withdrawal amount limit | Decline |
| 65 | Exceeds withdrawal frequency limit | Decline |

## GoPay Response Codes
| Code | Description |
|------|-------------|
| 00 | Success |
| 01 | Unknown error |
| 04 | Insufficient balance |
| 05 | Account not found |
| 10 | Account blocked |
| 11 | Transaction not permitted |
| 12 | Request already processed |
| 14 | Transaction expired |
| 15 | Transaction cancelled |

## ShopeePay Response Codes
| Code | Description |
|------|-------------|
| 00 | Success |
| 12 | Duplicate request |
| 13 | Transaction expired |
| 14 | Insufficient balance |
| 15 | Transaction not found |
| 16 | Transaction cancelled |
"""

# =============================================================================
# STATUS CODES
# =============================================================================

STATUS_CODES = {
    "2xx": """
# Midtrans Status Code 2xx (Success)

| Code | Description |
|------|-------------|
| 200 | Success - Transaction is successful / found |
| 201 | Success - Transaction is successfully created (pending) |
| 202 | Success - Transaction is successfully processed (accepted, in-process) |

## Common 2xx Scenarios
- 200: Charge success (capture/settlement), Get Status found
- 201: Pending transaction created (awaiting customer payment)
- 202: Request accepted and being processed (async), or idempotent retry while in-process
""",
    "3xx": """
# Midtrans Status Code 3xx (Redirection)

| Code | Description |
|------|-------------|
| 300 | Transaction is moved permanently (redirect required) |

## When 3xx Occurs
- Payment method requires redirect (3DS authentication, e-wallet redirect)
- Follow the redirect URL in the response `redirect_url` field
""",
    "4xx": """
# Midtrans Status Code 4xx (Client Error)

| Code | Description |
|------|-------------|
| 400 | Validation error - Invalid request parameters |
| 401 | Authentication error - Invalid/missing Server Key |
| 402 | Transaction denied by bank/payment provider |
| 403 | Forbidden - Merchant not authorized for this feature |
| 404 | Transaction/resource not found |
| 405 | HTTP method not allowed |
| 406 | Duplicate order_id (transaction already exists) |
| 407 | Account expired or inactive |
| 408 | Request timeout |
| 409 | Transaction in conflict state (e.g., already cancelled) |
| 410 | Transaction expired |
| 411 | Feature not available for this merchant |
| 412 | Merchant account not activated |
| 413 | Request body too large (max 16KB) |
| 429 | Rate limit exceeded - Too many requests |

## Troubleshooting 4xx Errors
- **400**: Check JSON format, required fields, field types/lengths
- **401**: Verify Server Key, check Sandbox vs Production key
- **402**: Card declined - customer should try different card/method
- **406**: Use unique order_id for each new transaction
- **429**: Implement retry with exponential backoff
""",
    "5xx": """
# Midtrans Status Code 5xx (Server Error)

| Code | Description |
|------|-------------|
| 500 | Internal server error |
| 501 | Feature not available |
| 502 | Bank/provider connection error |
| 503 | Service temporarily unavailable |
| 504 | Gateway timeout - Bank/provider timeout |

## Handling 5xx Errors
- Retry with exponential backoff
- Use Idempotency-Key for safe retries
- Check Midtrans status page for outages
- 502/504: Bank-side issue, retry after delay
- If persistent, contact Midtrans support
""",
}

# =============================================================================
# JSON OBJECT SCHEMAS
# =============================================================================

JSON_OBJECT_SCHEMAS = {
    "transaction_details": """
# Transaction Details Object

Required in every charge request.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| order_id | String(50) | Yes | Unique order ID from your system. Max 50 chars. Alphanumeric, dash, underscore, tilde, dot allowed. |
| gross_amount | Integer | Yes | Total transaction amount in IDR. No decimals. Must match sum of item_details prices*quantities if provided. |

```json
{
  "transaction_details": {
    "order_id": "ORDER-20240115-001",
    "gross_amount": 150000
  }
}
```

## Important Notes
- order_id must be unique per transaction
- If order_id already exists and transaction is pending, you'll get 406 error
- gross_amount is in smallest currency unit (IDR = Rupiah, no cents)
""",
    "customer_details": """
# Customer Details Object

Optional but recommended. Required for some payment methods (OVO requires phone).

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| first_name | String(255) | No | Customer first name |
| last_name | String(255) | No | Customer last name |
| email | String(255) | No | Customer email |
| phone | String(255) | Conditional | Customer phone (required for OVO) |
| billing_address | Object | No | Billing address object |
| shipping_address | Object | No | Shipping address object |

### Address Object Fields
| Field | Type | Description |
|-------|------|-------------|
| first_name | String(255) | Recipient name |
| last_name | String(255) | Recipient last name |
| phone | String(255) | Recipient phone |
| address | String(255) | Street address |
| city | String(255) | City |
| postal_code | String(255) | Postal code |
| country_code | String(3) | ISO 3166-1 alpha-3 (e.g., "IDN") |

```json
{
  "customer_details": {
    "first_name": "Budi",
    "last_name": "Utomo",
    "email": "budi.utomo@example.com",
    "phone": "081223323423",
    "billing_address": {
      "first_name": "Budi",
      "address": "Jl. Sudirman No. 1",
      "city": "Jakarta",
      "postal_code": "10110",
      "country_code": "IDN"
    }
  }
}
```
""",
    "item_details": """
# Item Details Object

Optional for most payment methods. Required for Kredivo and Akulaku.

Array of item objects. Sum of (price * quantity) MUST equal gross_amount.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| id | String(50) | No | Item ID |
| price | Integer | Yes | Price per item in IDR (no decimal) |
| quantity | Integer | Yes | Quantity of items |
| name | String(50) | Yes | Item name |
| brand | String(50) | No | Item brand |
| category | String(50) | No | Item category |
| merchant_name | String(50) | No | Merchant/seller name |
| url | String(255) | No | Item URL |

```json
{
  "item_details": [
    {
      "id": "ITEM-001",
      "price": 75000,
      "quantity": 1,
      "name": "T-Shirt Blue",
      "brand": "Brand A",
      "category": "Clothing"
    },
    {
      "id": "ITEM-002",
      "price": 25000,
      "quantity": 1,
      "name": "Shipping Fee",
      "category": "Shipping"
    }
  ]
}
```

## Important
- Sum of (price * quantity) for all items MUST equal transaction_details.gross_amount
- price must be >= 0
- quantity must be >= 1
""",
    "seller_details": """
# Seller Details Object

Optional. Used for marketplace/multi-seller scenarios.

| Field | Type | Description |
|-------|------|-------------|
| id | String(50) | Seller ID |
| name | String(255) | Seller name |
| email | String(255) | Seller email |
| url | String(255) | Seller URL |
| address | Object | Seller address |

```json
{
  "seller_details": {
    "id": "SELLER-001",
    "name": "Toko Rani",
    "email": "rani@marketplace.com",
    "url": "https://marketplace.com/toko-rani",
    "address": {
      "first_name": "Rani",
      "address": "Jl. Kemang Raya No. 10",
      "city": "Jakarta",
      "postal_code": "12730",
      "country_code": "IDN"
    }
  }
}
```
""",
    "custom_expiry": """
# Custom Expiry Object

Set custom payment expiry time for pending transactions.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| order_time | String | No | Order timestamp (format: "YYYY-MM-DD HH:mm:ss +0700"). Defaults to current time. |
| expiry_duration | Integer | Yes | Duration of expiry |
| unit | String | Yes | Duration unit: "second", "minute", "hour", "day" |

```json
{
  "custom_expiry": {
    "order_time": "2024-01-15 11:54:12 +0700",
    "expiry_duration": 60,
    "unit": "minute"
  }
}
```

## Maximum Expiry by Payment Method
- QRIS (Shopee/AirPay acquirer): 5 days max
- GoPay: 7 days max
- Bank Transfer (VA): varies by bank, typically 24 hours default
- Exceeding max expiry will cause transaction rejection
""",
    "credit_card_object": """
# Credit Card Object

Used in charge request for credit card payments.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| token_id | String | Yes | Token from GET /v2/token (frontend tokenization) |
| authentication | Boolean | Recommended | Enable 3DS authentication (true recommended) |
| bank | String | No | Acquiring bank: "bni", "mandiri", "bca", "bri", "mega", "cimb", etc. |
| installment | Object | No | Installment configuration |
| type | String | No | "authorize" for pre-auth |
| save_token_id | Boolean | No | Save card for future use (One Click/Two Clicks) |
| saved_token_id | String | No | Saved token for recurring charges |
| bins | Array[String] | No | BIN whitelist for promo filtering |
| channel | String | No | Route to specific channel |

### Installment Object
| Field | Type | Description |
|-------|------|-------------|
| required | Boolean | Force installment |
| terms | Object | Bank-specific terms: {"bni": [3, 6, 12], "mandiri": [3, 6]} |

```json
{
  "payment_type": "credit_card",
  "credit_card": {
    "token_id": "48111111-1114-7baba36c-5698-47cf-9170-80efd6a2e973",
    "authentication": true,
    "bank": "bni",
    "save_token_id": true
  }
}
```

### Pre-Authorization
```json
{
  "credit_card": {
    "token_id": "...",
    "authentication": true,
    "type": "authorize"
  }
}
```

### Installment
```json
{
  "credit_card": {
    "token_id": "...",
    "authentication": true,
    "installment": {
      "required": true,
      "terms": {
        "bni": [3, 6, 12],
        "mandiri": [3, 6, 12],
        "bca": [3, 6, 12]
      }
    }
  }
}
```
""",
    "gopay_object": """
# GoPay Object

Used in charge request for GoPay payments.

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| enable_callback | Boolean | No | Enable callback after payment (default: false) |
| callback_url | String(255) | Conditional | URL to redirect after payment (required if enable_callback=true) |
| account_id | String | Conditional | Linked GoPay account ID (for tokenization/recurring) |
| payment_option_token | String | Conditional | Token from GoPay promotion fetch |

```json
{
  "payment_type": "gopay",
  "gopay": {
    "enable_callback": true,
    "callback_url": "https://yourapp.com/gopay-finish"
  }
}
```

### GoPay Tokenization (Recurring)
```json
{
  "payment_type": "gopay",
  "gopay": {
    "account_id": "account-id-from-linking",
    "payment_option_token": "token-from-fetch-promotion"
  }
}
```

## Response
The charge response includes `actions` array with:
- `generate-qr-code`: URL to generate QR code image
- `deeplink-redirect`: Deep link to open GoPay/Gojek app
- `get-status`: URL to check payment status
""",
    "shopeepay_object": """
# ShopeePay Object

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| callback_url | String(255) | Yes | URL to redirect after payment |

```json
{
  "payment_type": "shopeepay",
  "shopeepay": {
    "callback_url": "https://yourapp.com/shopeepay-finish"
  }
}
```

## Response
Returns `actions` with redirect URL to ShopeePay payment page.
Customer completes payment on ShopeePay, then redirected to callback_url.
""",
    "bank_transfer_object": """
# Bank Transfer (Virtual Account) Object

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| bank | String | Yes | Bank code: "bca", "bni", "bri", "permata", "cimb" |
| va_number | String | No | Custom VA number (if supported/configured) |
| free_text | Object | No | BCA VA specific free text fields |

### BCA VA
```json
{
  "payment_type": "bank_transfer",
  "bank_transfer": {
    "bank": "bca",
    "va_number": "12345678901",
    "free_text": {
      "inquiry": [{"en": "Payment for Order 123", "id": "Pembayaran Order 123"}],
      "payment": [{"en": "Thank you", "id": "Terima kasih"}]
    }
  }
}
```

### BNI VA
```json
{
  "payment_type": "bank_transfer",
  "bank_transfer": {
    "bank": "bni",
    "va_number": "12345678"
  }
}
```

### BRI VA
```json
{
  "payment_type": "bank_transfer",
  "bank_transfer": {
    "bank": "bri",
    "va_number": "123456789012345"
  }
}
```

### Permata VA
```json
{
  "payment_type": "bank_transfer",
  "bank_transfer": {
    "bank": "permata",
    "va_number": "1234567890"
  }
}
```

### CIMB VA
```json
{
  "payment_type": "bank_transfer",
  "bank_transfer": {
    "bank": "cimb"
  }
}
```

## VA Response
Response includes `va_numbers` array with bank and va_number fields.
Customer uses this VA number to complete payment via ATM/mobile banking.
""",
    "echannel_object": """
# E-Channel Object (Mandiri Bill Payment)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| bill_info1 | String(10) | Yes | Label for bill info 1 |
| bill_info2 | String(30) | Yes | Value for bill info 2 |

```json
{
  "payment_type": "echannel",
  "echannel": {
    "bill_info1": "Payment:",
    "bill_info2": "Online purchase"
  }
}
```

## Response
Returns `bill_key` and `biller_code` that customer uses to pay via Mandiri ATM/mobile.
""",
    "qris_object": """
# QRIS Object

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| acquirer | String | No | QRIS acquirer: "gopay" or "airpay" (ShopeePay). Default: "gopay" |

```json
{
  "payment_type": "qris",
  "qris": {
    "acquirer": "gopay"
  }
}
```

## Response
Returns `actions` with URL to QR code image. Customer scans with any QRIS-compatible app.
Note: QRIS acquirer "airpay" = ShopeePay as acquirer.
""",
    "ovo_object": """
# OVO Object

OVO does not have additional object fields. However, `customer_details.phone` is REQUIRED.

```json
{
  "payment_type": "ovo",
  "customer_details": {
    "first_name": "Budi",
    "last_name": "Utomo",
    "email": "budi@example.com",
    "phone": "081223323423"
  }
}
```

## Important
- Phone number must be the customer's OVO-registered number
- OVO payment is push-based: charge request triggers push notification to customer's OVO app
- No redirect URL needed
""",
    "convenience_store_object": """
# Convenience Store (Over The Counter) Object

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| store | String | Yes | Store code: "indomaret" or "alfamart" |
| message | String | No | Message displayed on payment screen |
| alfamart_free_text_1 | String | No | Alfamart-specific free text |
| alfamart_free_text_2 | String | No | Alfamart-specific free text |
| alfamart_free_text_3 | String | No | Alfamart-specific free text |

### Indomaret
```json
{
  "payment_type": "cstore",
  "cstore": {
    "store": "indomaret",
    "message": "Payment for Order #123"
  }
}
```

### Alfamart
```json
{
  "payment_type": "cstore",
  "cstore": {
    "store": "alfamart",
    "alfamart_free_text_1": "Order #123",
    "alfamart_free_text_2": "Thank you",
    "alfamart_free_text_3": ""
  }
}
```

## Response
Returns `payment_code` that customer presents at the store counter to make payment.
""",
    "action_object": """
# Action Object (Response)

Present in charge responses for payment methods that require customer action.

| Field | Type | Description |
|-------|------|-------------|
| name | String | Action identifier (e.g., "generate-qr-code", "deeplink-redirect") |
| method | String | HTTP method ("GET" or "POST") |
| url | String | URL to perform the action |
| fields | Array | Additional fields needed (if POST) |

## Common Action Types

### GoPay
- `generate-qr-code`: GET URL to render QR code image
- `deeplink-redirect`: Deep link to open Gojek/GoPay app
- `get-status`: GET URL to check payment status
- `cancel`: POST URL to cancel payment

### ShopeePay
- `deeplink-redirect`: Redirect URL to ShopeePay

### QRIS
- `generate-qr-code`: GET URL to render QR code image
- `get-status`: GET URL to check payment status

## Example Response Actions
```json
{
  "actions": [
    {
      "name": "generate-qr-code",
      "method": "GET",
      "url": "https://api.sandbox.midtrans.com/v2/gopay/qr-code/..."
    },
    {
      "name": "deeplink-redirect",
      "method": "GET",
      "url": "gojek://gopay/merchanttransfer?..."
    }
  ]
}
```
""",
    "payment_amount_object": """
# Payment Amount Object

Used in subscription and partial payment contexts.

| Field | Type | Description |
|-------|------|-------------|
| paid_at | String | Timestamp of payment |
| amount | String | Amount paid |
| payment_status | String | Status of this payment |

## Example
```json
{
  "payment_amount": {
    "paid_at": "2024-01-15 10:30:00",
    "amount": "100000.00",
    "payment_status": "settlement"
  }
}
```
""",
    "dana_object": """
# DANA Object

DANA uses redirect-based flow.

```json
{
  "payment_type": "dana",
  "customer_details": {
    "first_name": "Budi",
    "email": "budi@example.com",
    "phone": "081223323423"
  }
}
```

## Response
Returns `actions` array with redirect URL to DANA payment page.
Customer completes payment on DANA and is redirected back.
""",
    "google_pay_object": """
# Google Pay Object

```json
{
  "payment_type": "googlepay",
  "transaction_details": {
    "order_id": "order-gp-001",
    "gross_amount": 100000
  }
}
```

## Notes
- Google Pay is available in sandbox for testing
- Requires Google Pay integration on the frontend to obtain payment token
- Customer sees Google Pay button, authorizes payment via Google Pay
""",
}

# =============================================================================
# PAYMENT METHOD DETAILS
# =============================================================================

PAYMENT_METHOD_DETAILS = {
    "credit_card": """
# Credit Card Payment (Core API)

## Overview
Credit card payment in Core API requires 2 steps:
1. **Frontend**: Tokenize card details using MidtransNew3ds.js -> get token_id
2. **Backend**: Send charge request with token_id

## Step 1: Get Card Token (Frontend)

Include Midtrans JS library:
```html
<script
  id="midtrans-script"
  src="https://api.midtrans.com/v2/assets/js/midtrans-new-3ds.min.js"
  data-environment="sandbox"
  data-client-key="<YOUR_CLIENT_KEY>"
  type="text/javascript">
</script>
```

Get token:
```javascript
var card = {
  card_number: "4811111111111114",
  card_cvv: "123",
  card_exp_month: "12",
  card_exp_year: "2025"
};

MidtransNew3ds.getCardToken(card, {
  onSuccess: function(response) {
    // response.token_id -> send to your backend
    var tokenId = response.token_id;
  },
  onFailure: function(response) {
    // Handle error
  }
});
```

### Token Response Fields
| Field | Description |
|-------|-------------|
| status_code | "200" for success |
| token_id | Card token to use in charge request |
| hash | Irreversible hash of card number (consistent per card) |

## Step 2: Charge (Backend)

```json
{
  "payment_type": "credit_card",
  "transaction_details": {
    "order_id": "ORDER-CC-001",
    "gross_amount": 100000
  },
  "credit_card": {
    "token_id": "48111111-1114-7baba36c-5698-47cf-9170-80efd6a2e973",
    "authentication": true
  }
}
```

## 3D Secure (3DS)
- Set `authentication: true` (recommended, required by many banks)
- 3DS 1.0: Direct support via token
- 3DS 2.0 (EMV 3DS): Enhanced flow with device fingerprinting

### 3DS 2.0 Flow
1. Get token with card details
2. Charge with authentication: true
3. If response contains redirect_url -> redirect customer for 3DS
4. Customer completes authentication
5. Receive notification with final status

## Pre-Authorization
```json
{
  "credit_card": {
    "token_id": "...",
    "authentication": true,
    "type": "authorize"
  }
}
```
Then capture later:
```
POST /v2/capture
{"transaction_id": "uuid", "gross_amount": 100000}
```

## One Click (Saved Card, No CVV)
Initial charge with `save_token_id: true`, then use `saved_token_id` for subsequent:
```json
{
  "credit_card": {
    "saved_token_id": "48111111sHfSakAvHvFQFEjTivUV1114",
    "authentication": true
  }
}
```

## Two Clicks (Saved Card, CVV Required)
Same as One Click but get new token with saved_token_id + CVV from frontend first.

## BIN Promo
Filter cards by BIN prefix:
```json
{
  "credit_card": {
    "token_id": "...",
    "bins": ["48111111", "521111"]
  }
}
```

## Installment
```json
{
  "credit_card": {
    "token_id": "...",
    "installment": {
      "required": true,
      "terms": {"bni": [3, 6, 12], "mandiri": [3, 6, 12]}
    }
  }
}
```

## Point Redemption
```
GET /v2/point_inquiry/{token_id}
```
Returns point balance. Include points info in charge if needed.

## 8-Digit BIN Support
Midtrans supports 8-digit BINs (Visa mandate):
- token_id format: `8 first digits + "-" + 4 last + "-" + 36 random`
- saved_token_id: `8 first digits + 20 random + 4 last`
- masked_card: `8 first digits + 4 last digits`
""",
    "gopay": """
# GoPay Payment (Core API)

## Charge Request
```json
{
  "payment_type": "gopay",
  "transaction_details": {
    "order_id": "ORDER-GOPAY-001",
    "gross_amount": 100000
  },
  "gopay": {
    "enable_callback": true,
    "callback_url": "https://yourapp.com/gopay-finish"
  }
}
```

## Response
```json
{
  "status_code": "201",
  "status_message": "GoPay transaction is created",
  "transaction_id": "uuid",
  "order_id": "ORDER-GOPAY-001",
  "gross_amount": "100000.00",
  "payment_type": "gopay",
  "transaction_status": "pending",
  "actions": [
    {"name": "generate-qr-code", "method": "GET", "url": "https://api.sandbox.midtrans.com/v2/gopay/..."},
    {"name": "deeplink-redirect", "method": "GET", "url": "gojek://gopay/merchanttransfer?..."},
    {"name": "get-status", "method": "GET", "url": "https://api.sandbox.midtrans.com/v2/.../status"},
    {"name": "cancel", "method": "POST", "url": "https://api.sandbox.midtrans.com/v2/.../cancel"}
  ]
}
```

## Integration Flow
1. Send charge request
2. Get response with actions
3. Display QR code (web) or redirect via deeplink (mobile)
4. Customer pays in GoPay/Gojek app
5. Receive webhook notification

### Web: Show QR Code
Use `generate-qr-code` URL as image source:
```html
<img src="https://api.sandbox.midtrans.com/v2/gopay/..." alt="GoPay QR" />
```

### Mobile: Deeplink
Open `deeplink-redirect` URL to launch Gojek app:
```javascript
window.location.href = "gojek://gopay/merchanttransfer?...";
```

## GoPay Tokenization (Account Linking)
For recurring/saved payment:

### 1. Link Account
```
POST /v2/pay/account
{
  "payment_type": "gopay",
  "gopay_partner": {
    "phone_number": "081234567890",
    "country_code": "62",
    "redirect_url": "https://yourapp.com/gopay-link-finish"
  }
}
```
Returns redirect URL for customer to authorize linking.

### 2. Get Account
```
GET /v2/pay/account/{account_id}
```

### 3. Charge with Linked Account
```json
{
  "payment_type": "gopay",
  "gopay": {
    "account_id": "linked-account-id"
  }
}
```

### 4. Unbind Account
```
POST /v2/pay/account/{account_id}/unbind
```

## Max Custom Expiry
GoPay: maximum 7 days
""",
    "qris": """
# QRIS Payment (Core API)

## Charge Request
```json
{
  "payment_type": "qris",
  "transaction_details": {
    "order_id": "ORDER-QRIS-001",
    "gross_amount": 100000
  },
  "qris": {
    "acquirer": "gopay"
  }
}
```

## acquirer Options
- `"gopay"` (default): GoPay as QRIS acquirer
- `"airpay"`: ShopeePay as QRIS acquirer

## Response
Returns QR code URL in `actions`:
```json
{
  "actions": [
    {"name": "generate-qr-code", "method": "GET", "url": "https://api.sandbox.midtrans.com/v2/qris/..."}
  ]
}
```

## Integration Flow
1. Send charge request
2. Display QR code image from URL
3. Customer scans QR with any QRIS-compatible app (GoPay, ShopeePay, DANA, OVO, etc.)
4. Receive webhook notification

## Max Custom Expiry
- GoPay acquirer: 7 days
- AirPay (ShopeePay) acquirer: 5 days
""",
    "shopeepay": """
# ShopeePay Payment (Core API)

## Charge Request
```json
{
  "payment_type": "shopeepay",
  "transaction_details": {
    "order_id": "ORDER-SPAY-001",
    "gross_amount": 100000
  },
  "shopeepay": {
    "callback_url": "https://yourapp.com/shopeepay-finish"
  }
}
```

## Response
Returns redirect URL in `actions`:
```json
{
  "actions": [
    {"name": "deeplink-redirect", "method": "GET", "url": "https://..."}
  ]
}
```

## Integration Flow
1. Send charge request
2. Redirect customer to ShopeePay URL
3. Customer completes payment in ShopeePay app
4. Customer redirected to callback_url
5. Receive webhook notification

## callback_url is REQUIRED
""",
    "ovo": """
# OVO Payment (Core API)

## Charge Request
**customer_details.phone is REQUIRED**

```json
{
  "payment_type": "ovo",
  "transaction_details": {
    "order_id": "ORDER-OVO-001",
    "gross_amount": 100000
  },
  "customer_details": {
    "first_name": "Budi",
    "last_name": "Utomo",
    "email": "budi@example.com",
    "phone": "081223323423"
  }
}
```

## Response
```json
{
  "status_code": "201",
  "transaction_status": "pending",
  "payment_type": "ovo"
}
```

## Integration Flow
1. Send charge request with customer phone number
2. Push notification sent to customer's OVO app
3. Customer approves payment in OVO app
4. Receive webhook notification

## Important
- Phone must be the OVO-registered number
- OVO is push-based (no redirect URL needed)
- Customer sees payment request in their OVO app
""",
    "dana": """
# DANA Payment (Core API)

## Charge Request
```json
{
  "payment_type": "dana",
  "transaction_details": {
    "order_id": "ORDER-DANA-001",
    "gross_amount": 100000
  },
  "customer_details": {
    "first_name": "Budi",
    "email": "budi@example.com",
    "phone": "081223323423"
  }
}
```

## Response
Returns redirect URL for DANA payment page.

## Integration Flow
1. Send charge request
2. Redirect customer to DANA payment URL
3. Customer logs in and confirms payment on DANA
4. Customer redirected back
5. Receive webhook notification
""",
    "google_pay": """
# Google Pay Payment (Core API)

## Charge Request
```json
{
  "payment_type": "googlepay",
  "transaction_details": {
    "order_id": "ORDER-GPAY-001",
    "gross_amount": 100000
  }
}
```

## Integration Flow
1. Integrate Google Pay button on frontend
2. Customer clicks Google Pay and authorizes
3. Send charge request to Midtrans with payment details
4. Receive webhook notification

## Notes
- Requires Google Pay frontend SDK integration
- Available in sandbox for testing
""",
    "bca_va": """
# BCA Virtual Account (Core API)

## Charge Request
```json
{
  "payment_type": "bank_transfer",
  "transaction_details": {
    "order_id": "ORDER-BCA-001",
    "gross_amount": 100000
  },
  "bank_transfer": {
    "bank": "bca",
    "va_number": "12345678901",
    "free_text": {
      "inquiry": [{"en": "Payment for Order", "id": "Pembayaran untuk Order"}],
      "payment": [{"en": "Thank you", "id": "Terima kasih"}]
    }
  }
}
```

## Response
```json
{
  "status_code": "201",
  "transaction_status": "pending",
  "va_numbers": [{"bank": "bca", "va_number": "12345678901"}]
}
```

## Integration Flow
1. Send charge request
2. Get VA number from response
3. Display VA number to customer
4. Customer pays via BCA ATM / BCA Mobile / KlikBCA
5. Receive webhook notification (settlement)

## Custom VA Number
- Optional: set `va_number` in request for custom VA
- Must be configured/enabled in Midtrans dashboard
""",
    "bni_va": """
# BNI Virtual Account (Core API)

## Charge Request
```json
{
  "payment_type": "bank_transfer",
  "transaction_details": {
    "order_id": "ORDER-BNI-001",
    "gross_amount": 100000
  },
  "bank_transfer": {
    "bank": "bni",
    "va_number": "12345678"
  }
}
```

## Response
```json
{
  "status_code": "201",
  "transaction_status": "pending",
  "va_numbers": [{"bank": "bni", "va_number": "9880012345678"}]
}
```

## Customer pays via BNI ATM / BNI Mobile / iBank
""",
    "bri_va": """
# BRI Virtual Account (Core API)

## Charge Request
```json
{
  "payment_type": "bank_transfer",
  "transaction_details": {
    "order_id": "ORDER-BRI-001",
    "gross_amount": 100000
  },
  "bank_transfer": {
    "bank": "bri",
    "va_number": "123456789012345"
  }
}
```

## Response
Returns VA number in `va_numbers` array.
Customer pays via BRI ATM / BRI Mobile / Internet Banking BRI.
""",
    "permata_va": """
# Permata Virtual Account (Core API)

## Charge Request
```json
{
  "payment_type": "bank_transfer",
  "transaction_details": {
    "order_id": "ORDER-PERMATA-001",
    "gross_amount": 100000
  },
  "bank_transfer": {
    "bank": "permata",
    "va_number": "1234567890"
  }
}
```

## Response
Returns `permata_va_number` field.
Customer pays via Permata ATM / PermataMobile / PermataNet.

## Note
- Idempotent requests NOT supported for Permata VA
""",
    "mandiri_bill": """
# Mandiri Bill Payment (Core API)

## Charge Request
```json
{
  "payment_type": "echannel",
  "transaction_details": {
    "order_id": "ORDER-MANDIRI-001",
    "gross_amount": 100000
  },
  "echannel": {
    "bill_info1": "Payment:",
    "bill_info2": "Online purchase"
  }
}
```

## Response
```json
{
  "status_code": "201",
  "transaction_status": "pending",
  "bill_key": "990012345678",
  "biller_code": "70012"
}
```

## Integration Flow
1. Send charge request
2. Get bill_key and biller_code from response
3. Display both to customer
4. Customer pays via Mandiri ATM / Livin' / Internet Banking Mandiri
5. Customer enters biller_code first, then bill_key
6. Receive webhook notification
""",
    "cimb_va": """
# CIMB Virtual Account (Core API)

## Charge Request
```json
{
  "payment_type": "bank_transfer",
  "transaction_details": {
    "order_id": "ORDER-CIMB-001",
    "gross_amount": 100000
  },
  "bank_transfer": {
    "bank": "cimb"
  }
}
```

## Response
Returns VA number in `va_numbers` array.
Customer pays via CIMB ATM / CIMB Clicks / Go Mobile.
""",
    "indomaret": """
# Indomaret Payment (Core API)

## Charge Request
```json
{
  "payment_type": "cstore",
  "transaction_details": {
    "order_id": "ORDER-INDO-001",
    "gross_amount": 100000
  },
  "cstore": {
    "store": "indomaret",
    "message": "Payment for Order #001"
  }
}
```

## Response
```json
{
  "status_code": "201",
  "transaction_status": "pending",
  "payment_code": "123456789012"
}
```

## Integration Flow
1. Send charge request
2. Get payment_code from response
3. Display payment_code to customer
4. Customer goes to Indomaret and provides the code at counter
5. Receive webhook notification

## Note
- Idempotent requests NOT supported for Indomaret
""",
    "alfamart": """
# Alfamart Payment (Core API)

## Charge Request
```json
{
  "payment_type": "cstore",
  "transaction_details": {
    "order_id": "ORDER-ALFA-001",
    "gross_amount": 100000
  },
  "cstore": {
    "store": "alfamart",
    "alfamart_free_text_1": "Order #001",
    "alfamart_free_text_2": "Thank you",
    "alfamart_free_text_3": ""
  }
}
```

## Response
Returns `payment_code` for customer to use at Alfamart counter.

## Integration Flow
1. Send charge request
2. Display payment_code to customer
3. Customer pays at Alfamart counter
4. Receive webhook notification
""",
    "akulaku": """
# Akulaku PayLater (Core API)

## Charge Request
```json
{
  "payment_type": "akulaku",
  "transaction_details": {
    "order_id": "ORDER-AKU-001",
    "gross_amount": 100000
  },
  "item_details": [
    {
      "id": "ITEM-1",
      "price": 100000,
      "quantity": 1,
      "name": "Product Name"
    }
  ]
}
```

## Response
Returns redirect URL. Customer completes payment on Akulaku page.

## Integration Flow
1. Send charge request (item_details recommended)
2. Get redirect_url from response
3. Redirect customer to Akulaku
4. Customer logs in and selects installment plan
5. Customer redirected back
6. Receive webhook notification
""",
    "kredivo": """
# Kredivo Payment (Core API)

## Charge Request (item_details REQUIRED)
```json
{
  "payment_type": "kredivo",
  "transaction_details": {
    "order_id": "ORDER-KRED-001",
    "gross_amount": 100000
  },
  "item_details": [
    {
      "id": "ITEM-1",
      "price": 100000,
      "quantity": 1,
      "name": "Product Name"
    }
  ],
  "customer_details": {
    "first_name": "Budi",
    "last_name": "Utomo",
    "email": "budi@example.com",
    "phone": "081223323423"
  }
}
```

## IMPORTANT: item_details is REQUIRED for Kredivo

## Response
Returns redirect URL. Customer completes payment on Kredivo page.

## Integration Flow
1. Send charge request with item_details
2. Get redirect_url from response
3. Redirect customer to Kredivo
4. Customer logs in and selects payment plan (30 days, 3, 6, 12 months)
5. Customer redirected back
6. Receive webhook notification
""",
}

# =============================================================================
# IMPLEMENTATION EXAMPLES
# =============================================================================

IMPLEMENTATION_EXAMPLES = {
    "python": """
# Python Implementation Examples (Core API)

## Installation
```bash
pip install requests
# or for async:
pip install httpx
```

## Configuration
```python
import base64
import hashlib
import json
import requests

MIDTRANS_SERVER_KEY = "SB-Mid-server-YOUR_KEY_HERE"  # Use env variable in production!
MIDTRANS_BASE_URL = "https://api.sandbox.midtrans.com"  # Change for production

def get_auth_header():
    auth_string = base64.b64encode(f"{MIDTRANS_SERVER_KEY}:".encode()).decode()
    return {
        "Authorization": f"Basic {auth_string}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }
```

## Charge Transaction (GoPay Example)
```python
def charge_gopay(order_id: str, amount: int, callback_url: str = None) -> dict:
    payload = {
        "payment_type": "gopay",
        "transaction_details": {
            "order_id": order_id,
            "gross_amount": amount
        }
    }
    if callback_url:
        payload["gopay"] = {
            "enable_callback": True,
            "callback_url": callback_url
        }

    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v2/charge",
        headers=get_auth_header(),
        json=payload
    )
    return response.json()
```

## Charge Transaction (Bank Transfer / VA)
```python
def charge_bank_transfer(order_id: str, amount: int, bank: str) -> dict:
    payload = {
        "payment_type": "bank_transfer",
        "transaction_details": {
            "order_id": order_id,
            "gross_amount": amount
        },
        "bank_transfer": {
            "bank": bank  # "bca", "bni", "bri", "permata", "cimb"
        }
    }
    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v2/charge",
        headers=get_auth_header(),
        json=payload
    )
    return response.json()
```

## Charge Mandiri Bill Payment
```python
def charge_mandiri_bill(order_id: str, amount: int) -> dict:
    payload = {
        "payment_type": "echannel",
        "transaction_details": {
            "order_id": order_id,
            "gross_amount": amount
        },
        "echannel": {
            "bill_info1": "Payment:",
            "bill_info2": "Online purchase"
        }
    }
    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v2/charge",
        headers=get_auth_header(),
        json=payload
    )
    return response.json()
```

## Charge Credit Card
```python
def charge_credit_card(order_id: str, amount: int, token_id: str) -> dict:
    payload = {
        "payment_type": "credit_card",
        "transaction_details": {
            "order_id": order_id,
            "gross_amount": amount
        },
        "credit_card": {
            "token_id": token_id,
            "authentication": True
        }
    }
    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v2/charge",
        headers=get_auth_header(),
        json=payload
    )
    return response.json()
```

## Charge E-Wallet (ShopeePay, DANA)
```python
def charge_ewallet(order_id: str, amount: int, payment_type: str, callback_url: str) -> dict:
    payload = {
        "payment_type": payment_type,  # "shopeepay" or "dana"
        "transaction_details": {
            "order_id": order_id,
            "gross_amount": amount
        }
    }
    if payment_type == "shopeepay":
        payload["shopeepay"] = {"callback_url": callback_url}

    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v2/charge",
        headers=get_auth_header(),
        json=payload
    )
    return response.json()
```

## Get Transaction Status
```python
def get_transaction_status(order_id: str) -> dict:
    response = requests.get(
        f"{MIDTRANS_BASE_URL}/v2/{order_id}/status",
        headers=get_auth_header()
    )
    return response.json()
```

## Cancel Transaction
```python
def cancel_transaction(order_id: str) -> dict:
    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v2/{order_id}/cancel",
        headers=get_auth_header()
    )
    return response.json()
```

## Expire Transaction
```python
def expire_transaction(order_id: str) -> dict:
    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v2/{order_id}/expire",
        headers=get_auth_header()
    )
    return response.json()
```

## Refund Transaction
```python
def refund_transaction(order_id: str, amount: int, reason: str = "") -> dict:
    payload = {
        "refund_key": f"refund-{order_id}-{amount}",
        "amount": amount,
        "reason": reason
    }
    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v2/{order_id}/refund",
        headers=get_auth_header(),
        json=payload
    )
    return response.json()
```

## Capture Card Authorization
```python
def capture_transaction(transaction_id: str, amount: int) -> dict:
    payload = {
        "transaction_id": transaction_id,
        "gross_amount": amount
    }
    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v2/capture",
        headers=get_auth_header(),
        json=payload
    )
    return response.json()
```

## Notification Handler (Flask)
```python
from flask import Flask, request, jsonify, abort

app = Flask(__name__)

def verify_signature(notification: dict) -> bool:
    order_id = notification.get("order_id", "")
    status_code = notification.get("status_code", "")
    gross_amount = notification.get("gross_amount", "")
    signature = notification.get("signature_key", "")

    raw = f"{order_id}{status_code}{gross_amount}{MIDTRANS_SERVER_KEY}"
    expected = hashlib.sha512(raw.encode()).hexdigest()
    return expected == signature

@app.route("/midtrans/notification", methods=["POST"])
def handle_notification():
    notification = request.json
    if not notification:
        abort(400)

    if not verify_signature(notification):
        abort(403)

    order_id = notification["order_id"]
    status = notification["transaction_status"]
    fraud_status = notification.get("fraud_status", "")
    payment_type = notification.get("payment_type", "")

    if status == "capture":
        if payment_type == "credit_card":
            if fraud_status == "accept":
                # Payment successful - update order status
                pass
    elif status == "settlement":
        # Payment complete - mark order as paid
        pass
    elif status == "pending":
        # Awaiting payment
        pass
    elif status in ("deny", "cancel", "expire"):
        # Payment failed - mark order accordingly
        pass
    elif status in ("refund", "partial_refund"):
        # Refunded - update order
        pass

    return jsonify({"status": "ok"})
```

## Notification Handler (FastAPI)
```python
from fastapi import FastAPI, Request, HTTPException

app = FastAPI()

@app.post("/midtrans/notification")
async def handle_notification(request: Request):
    notification = await request.json()

    order_id = notification.get("order_id", "")
    status_code = notification.get("status_code", "")
    gross_amount = notification.get("gross_amount", "")
    signature = notification.get("signature_key", "")

    raw = f"{order_id}{status_code}{gross_amount}{MIDTRANS_SERVER_KEY}"
    expected = hashlib.sha512(raw.encode()).hexdigest()

    if expected != signature:
        raise HTTPException(status_code=403, detail="Invalid signature")

    status = notification["transaction_status"]
    fraud_status = notification.get("fraud_status", "")

    if status == "capture" and fraud_status == "accept":
        pass  # Card payment successful
    elif status == "settlement":
        pass  # Payment complete
    elif status == "pending":
        pass  # Awaiting payment
    elif status in ("deny", "cancel", "expire"):
        pass  # Payment failed
    elif status in ("refund", "partial_refund"):
        pass  # Refunded

    return {"status": "ok"}
```

## Create Subscription
```python
def create_subscription(name: str, amount: int, payment_type: str, token: str = None, gopay_account_id: str = None) -> dict:
    payload = {
        "name": name,
        "amount": str(amount),
        "currency": "IDR",
        "payment_type": payment_type,
        "schedule": {
            "interval": 1,
            "interval_unit": "month",
            "max_interval": 12
        }
    }
    if payment_type == "credit_card" and token:
        payload["token"] = token
    elif payment_type == "gopay" and gopay_account_id:
        payload["gopay"] = {"account_id": gopay_account_id}

    response = requests.post(
        f"{MIDTRANS_BASE_URL}/v1/subscriptions",
        headers=get_auth_header(),
        json=payload
    )
    return response.json()
```
""",
    "javascript": """
# JavaScript/TypeScript Implementation Examples (Core API)

## Installation
```bash
npm install node-fetch  # or use built-in fetch in Node 18+
# For TypeScript:
npm install -D typescript @types/node
```

## Configuration (TypeScript)
```typescript
const MIDTRANS_SERVER_KEY = process.env.MIDTRANS_SERVER_KEY || "SB-Mid-server-YOUR_KEY";
const MIDTRANS_BASE_URL = "https://api.sandbox.midtrans.com";  // Change for production

function getAuthHeader(): Record<string, string> {
  const authString = Buffer.from(`${MIDTRANS_SERVER_KEY}:`).toString("base64");
  return {
    "Authorization": `Basic ${authString}`,
    "Content-Type": "application/json",
    "Accept": "application/json"
  };
}
```

## Type Definitions
```typescript
interface TransactionDetails {
  order_id: string;
  gross_amount: number;
}

interface CustomerDetails {
  first_name?: string;
  last_name?: string;
  email?: string;
  phone?: string;
}

interface Action {
  name: string;
  method: string;
  url: string;
}

interface VaNumber {
  bank: string;
  va_number: string;
}

interface ChargeResponse {
  status_code: string;
  status_message: string;
  transaction_id: string;
  order_id: string;
  gross_amount: string;
  payment_type: string;
  transaction_status: string;
  fraud_status?: string;
  actions?: Action[];
  va_numbers?: VaNumber[];
  bill_key?: string;
  biller_code?: string;
  payment_code?: string;
  redirect_url?: string;
}

interface MidtransNotification {
  order_id: string;
  status_code: string;
  gross_amount: string;
  signature_key: string;
  transaction_status: string;
  fraud_status?: string;
  payment_type?: string;
  transaction_id: string;
}
```

## Charge Transaction (GoPay)
```typescript
async function chargeGoPay(
  orderId: string,
  amount: number,
  callbackUrl?: string
): Promise<ChargeResponse> {
  const payload: any = {
    payment_type: "gopay",
    transaction_details: { order_id: orderId, gross_amount: amount }
  };
  if (callbackUrl) {
    payload.gopay = { enable_callback: true, callback_url: callbackUrl };
  }

  const response = await fetch(`${MIDTRANS_BASE_URL}/v2/charge`, {
    method: "POST",
    headers: getAuthHeader(),
    body: JSON.stringify(payload)
  });
  return response.json();
}
```

## Charge Bank Transfer (VA)
```typescript
async function chargeBankTransfer(
  orderId: string,
  amount: number,
  bank: "bca" | "bni" | "bri" | "permata" | "cimb"
): Promise<ChargeResponse> {
  const response = await fetch(`${MIDTRANS_BASE_URL}/v2/charge`, {
    method: "POST",
    headers: getAuthHeader(),
    body: JSON.stringify({
      payment_type: "bank_transfer",
      transaction_details: { order_id: orderId, gross_amount: amount },
      bank_transfer: { bank }
    })
  });
  return response.json();
}
```

## Charge Credit Card
```typescript
async function chargeCreditCard(
  orderId: string,
  amount: number,
  tokenId: string
): Promise<ChargeResponse> {
  const response = await fetch(`${MIDTRANS_BASE_URL}/v2/charge`, {
    method: "POST",
    headers: getAuthHeader(),
    body: JSON.stringify({
      payment_type: "credit_card",
      transaction_details: { order_id: orderId, gross_amount: amount },
      credit_card: { token_id: tokenId, authentication: true }
    })
  });
  return response.json();
}
```

## Charge Mandiri Bill
```typescript
async function chargeMandiriBill(orderId: string, amount: number): Promise<ChargeResponse> {
  const response = await fetch(`${MIDTRANS_BASE_URL}/v2/charge`, {
    method: "POST",
    headers: getAuthHeader(),
    body: JSON.stringify({
      payment_type: "echannel",
      transaction_details: { order_id: orderId, gross_amount: amount },
      echannel: { bill_info1: "Payment:", bill_info2: "Online purchase" }
    })
  });
  return response.json();
}
```

## Get Transaction Status
```typescript
async function getTransactionStatus(orderId: string): Promise<ChargeResponse> {
  const response = await fetch(`${MIDTRANS_BASE_URL}/v2/${orderId}/status`, {
    headers: getAuthHeader()
  });
  return response.json();
}
```

## Cancel / Expire Transaction
```typescript
async function cancelTransaction(orderId: string): Promise<ChargeResponse> {
  const response = await fetch(`${MIDTRANS_BASE_URL}/v2/${orderId}/cancel`, {
    method: "POST",
    headers: getAuthHeader()
  });
  return response.json();
}

async function expireTransaction(orderId: string): Promise<ChargeResponse> {
  const response = await fetch(`${MIDTRANS_BASE_URL}/v2/${orderId}/expire`, {
    method: "POST",
    headers: getAuthHeader()
  });
  return response.json();
}
```

## Refund Transaction
```typescript
async function refundTransaction(
  orderId: string,
  amount: number,
  reason: string = ""
): Promise<ChargeResponse> {
  const response = await fetch(`${MIDTRANS_BASE_URL}/v2/${orderId}/refund`, {
    method: "POST",
    headers: getAuthHeader(),
    body: JSON.stringify({
      refund_key: `refund-${orderId}-${amount}`,
      amount,
      reason
    })
  });
  return response.json();
}
```

## Notification Handler (Express)
```typescript
import express from "express";
import crypto from "crypto";

const app = express();
app.use(express.json());

function verifySignature(notification: MidtransNotification): boolean {
  const { order_id, status_code, gross_amount, signature_key } = notification;
  const raw = `${order_id}${status_code}${gross_amount}${MIDTRANS_SERVER_KEY}`;
  const hash = crypto.createHash("sha512").update(raw).digest("hex");
  return hash === signature_key;
}

app.post("/midtrans/notification", (req, res) => {
  const notification: MidtransNotification = req.body;

  if (!verifySignature(notification)) {
    return res.status(403).json({ error: "Invalid signature" });
  }

  const { transaction_status, fraud_status, payment_type } = notification;

  switch (transaction_status) {
    case "capture":
      if (payment_type === "credit_card" && fraud_status === "accept") {
        // Card payment successful
      }
      break;
    case "settlement":
      // Payment complete
      break;
    case "pending":
      // Awaiting payment
      break;
    case "cancel":
    case "deny":
    case "expire":
      // Payment failed
      break;
    case "refund":
    case "partial_refund":
      // Refunded
      break;
  }

  res.status(200).json({ status: "ok" });
});

app.listen(3000);
```

## Frontend Card Tokenization
```html
<script src="https://api.midtrans.com/v2/assets/js/midtrans-new-3ds.min.js"
  data-environment="sandbox"
  data-client-key="YOUR_CLIENT_KEY"></script>

<script>
function getCardToken() {
  const card = {
    card_number: document.getElementById('card_number').value,
    card_cvv: document.getElementById('card_cvv').value,
    card_exp_month: document.getElementById('card_exp_month').value,
    card_exp_year: document.getElementById('card_exp_year').value
  };

  MidtransNew3ds.getCardToken(card, {
    onSuccess: function(response) {
      // Send response.token_id to your backend
      fetch('/charge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token_id: response.token_id })
      });
    },
    onFailure: function(response) {
      console.error('Tokenization failed:', response);
    }
  });
}
</script>
```

## Create Subscription
```typescript
async function createSubscription(
  name: string,
  amount: number,
  paymentType: "credit_card" | "gopay",
  token?: string,
  gopayAccountId?: string
): Promise<any> {
  const payload: any = {
    name,
    amount: String(amount),
    currency: "IDR",
    payment_type: paymentType,
    schedule: { interval: 1, interval_unit: "month", max_interval: 12 }
  };
  if (paymentType === "credit_card" && token) payload.token = token;
  if (paymentType === "gopay" && gopayAccountId) payload.gopay = { account_id: gopayAccountId };

  const response = await fetch(`${MIDTRANS_BASE_URL}/v1/subscriptions`, {
    method: "POST",
    headers: getAuthHeader(),
    body: JSON.stringify(payload)
  });
  return response.json();
}
```
""",
    "go": """
# Go Implementation Examples (Core API)

## Dependencies
```bash
# Standard library only - no external dependencies needed for HTTP calls
```

## Configuration
```go
package midtrans

import (
    "bytes"
    "crypto/sha512"
    "encoding/base64"
    "encoding/json"
    "fmt"
    "io"
    "net/http"
    "os"
)

var (
    ServerKey = os.Getenv("MIDTRANS_SERVER_KEY") // Never hardcode in production
    BaseURL   = "https://api.sandbox.midtrans.com" // Change for production
)

func authHeader() string {
    return "Basic " + base64.StdEncoding.EncodeToString([]byte(ServerKey+":"))
}

func newAuthedRequest(method, url string, body io.Reader) (*http.Request, error) {
    req, err := http.NewRequest(method, url, body)
    if err != nil {
        return nil, err
    }
    req.Header.Set("Authorization", authHeader())
    req.Header.Set("Content-Type", "application/json")
    req.Header.Set("Accept", "application/json")
    return req, nil
}
```

## Data Structures
```go
type TransactionDetails struct {
    OrderID     string `json:"order_id"`
    GrossAmount int    `json:"gross_amount"`
}

type GoPay struct {
    EnableCallback bool   `json:"enable_callback,omitempty"`
    CallbackURL    string `json:"callback_url,omitempty"`
    AccountID      string `json:"account_id,omitempty"`
}

type BankTransfer struct {
    Bank     string `json:"bank"`
    VANumber string `json:"va_number,omitempty"`
}

type EChannel struct {
    BillInfo1 string `json:"bill_info1"`
    BillInfo2 string `json:"bill_info2"`
}

type CStore struct {
    Store   string `json:"store"`
    Message string `json:"message,omitempty"`
}

type CreditCard struct {
    TokenID        string `json:"token_id,omitempty"`
    Authentication bool   `json:"authentication,omitempty"`
    Bank           string `json:"bank,omitempty"`
    Type           string `json:"type,omitempty"`
    SaveTokenID    bool   `json:"save_token_id,omitempty"`
    SavedTokenID   string `json:"saved_token_id,omitempty"`
}

type ShopeePay struct {
    CallbackURL string `json:"callback_url"`
}

type CustomerDetails struct {
    FirstName string `json:"first_name,omitempty"`
    LastName  string `json:"last_name,omitempty"`
    Email     string `json:"email,omitempty"`
    Phone     string `json:"phone,omitempty"`
}

type ItemDetail struct {
    ID       string `json:"id,omitempty"`
    Price    int    `json:"price"`
    Quantity int    `json:"quantity"`
    Name     string `json:"name"`
}

type ChargeRequest struct {
    PaymentType        string              `json:"payment_type"`
    TransactionDetails TransactionDetails  `json:"transaction_details"`
    GoPay              *GoPay              `json:"gopay,omitempty"`
    BankTransfer       *BankTransfer       `json:"bank_transfer,omitempty"`
    EChannel           *EChannel           `json:"echannel,omitempty"`
    CStore             *CStore             `json:"cstore,omitempty"`
    CreditCard         *CreditCard         `json:"credit_card,omitempty"`
    ShopeePay          *ShopeePay          `json:"shopeepay,omitempty"`
    CustomerDetails    *CustomerDetails    `json:"customer_details,omitempty"`
    ItemDetails        []ItemDetail        `json:"item_details,omitempty"`
}

type Action struct {
    Name   string `json:"name"`
    Method string `json:"method"`
    URL    string `json:"url"`
}

type VA struct {
    Bank     string `json:"bank"`
    VANumber string `json:"va_number"`
}

type ChargeResponse struct {
    StatusCode        string   `json:"status_code"`
    StatusMessage     string   `json:"status_message"`
    TransactionID     string   `json:"transaction_id"`
    OrderID           string   `json:"order_id"`
    GrossAmount       string   `json:"gross_amount"`
    PaymentType       string   `json:"payment_type"`
    TransactionStatus string   `json:"transaction_status"`
    FraudStatus       string   `json:"fraud_status"`
    Actions           []Action `json:"actions"`
    VANumbers         []VA     `json:"va_numbers"`
    BillKey           string   `json:"bill_key"`
    BillerCode        string   `json:"biller_code"`
    PaymentCode       string   `json:"payment_code"`
    RedirectURL       string   `json:"redirect_url"`
}
```

## Charge Transaction
```go
func Charge(req ChargeRequest) (*ChargeResponse, error) {
    body, err := json.Marshal(req)
    if err != nil {
        return nil, fmt.Errorf("marshal charge request: %w", err)
    }

    httpReq, err := newAuthedRequest("POST", BaseURL+"/v2/charge", bytes.NewReader(body))
    if err != nil {
        return nil, err
    }

    resp, err := http.DefaultClient.Do(httpReq)
    if err != nil {
        return nil, fmt.Errorf("charge request: %w", err)
    }
    defer resp.Body.Close()

    var result ChargeResponse
    if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
        return nil, fmt.Errorf("decode charge response: %w", err)
    }
    return &result, nil
}
```

## Get Transaction Status
```go
func GetStatus(orderID string) (*ChargeResponse, error) {
    req, err := newAuthedRequest("GET", BaseURL+"/v2/"+orderID+"/status", nil)
    if err != nil {
        return nil, err
    }

    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()

    var result ChargeResponse
    json.NewDecoder(resp.Body).Decode(&result)
    return &result, nil
}
```

## Cancel / Expire Transaction
```go
func CancelTransaction(orderID string) (*ChargeResponse, error) {
    req, err := newAuthedRequest("POST", BaseURL+"/v2/"+orderID+"/cancel", nil)
    if err != nil {
        return nil, err
    }
    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()
    var result ChargeResponse
    json.NewDecoder(resp.Body).Decode(&result)
    return &result, nil
}

func ExpireTransaction(orderID string) (*ChargeResponse, error) {
    req, err := newAuthedRequest("POST", BaseURL+"/v2/"+orderID+"/expire", nil)
    if err != nil {
        return nil, err
    }
    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()
    var result ChargeResponse
    json.NewDecoder(resp.Body).Decode(&result)
    return &result, nil
}
```

## Refund Transaction
```go
type RefundRequest struct {
    RefundKey string `json:"refund_key"`
    Amount    int    `json:"amount"`
    Reason    string `json:"reason,omitempty"`
}

func RefundTransaction(orderID string, amount int, reason string) (*ChargeResponse, error) {
    refund := RefundRequest{
        RefundKey: fmt.Sprintf("refund-%s-%d", orderID, amount),
        Amount:    amount,
        Reason:    reason,
    }
    body, _ := json.Marshal(refund)
    req, err := newAuthedRequest("POST", BaseURL+"/v2/"+orderID+"/refund", bytes.NewReader(body))
    if err != nil {
        return nil, err
    }
    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        return nil, err
    }
    defer resp.Body.Close()
    var result ChargeResponse
    json.NewDecoder(resp.Body).Decode(&result)
    return &result, nil
}
```

## Notification Handler
```go
type Notification struct {
    OrderID           string `json:"order_id"`
    StatusCode        string `json:"status_code"`
    GrossAmount       string `json:"gross_amount"`
    SignatureKey       string `json:"signature_key"`
    TransactionStatus string `json:"transaction_status"`
    FraudStatus       string `json:"fraud_status"`
    PaymentType       string `json:"payment_type"`
    TransactionID     string `json:"transaction_id"`
}

func VerifySignature(n Notification) bool {
    raw := n.OrderID + n.StatusCode + n.GrossAmount + ServerKey
    hash := sha512.Sum512([]byte(raw))
    return fmt.Sprintf("%x", hash) == n.SignatureKey
}

func HandleNotification(w http.ResponseWriter, r *http.Request) {
    if r.Method != http.MethodPost {
        http.Error(w, "Method not allowed", 405)
        return
    }

    var n Notification
    if err := json.NewDecoder(r.Body).Decode(&n); err != nil {
        http.Error(w, "Bad request", 400)
        return
    }

    if !VerifySignature(n) {
        http.Error(w, "Invalid signature", 403)
        return
    }

    switch n.TransactionStatus {
    case "capture":
        if n.PaymentType == "credit_card" && n.FraudStatus == "accept" {
            // Card payment successful
        }
    case "settlement":
        // Payment complete
    case "pending":
        // Awaiting payment
    case "cancel", "deny", "expire":
        // Payment failed
    case "refund", "partial_refund":
        // Refunded
    }

    w.Header().Set("Content-Type", "application/json")
    json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
}

// Register in main():
// http.HandleFunc("/midtrans/notification", HandleNotification)
// http.ListenAndServe(":8080", nil)
```
""",
    "rust": """
# Rust Implementation Examples (Core API)

## Dependencies (Cargo.toml)
```toml
[dependencies]
reqwest = { version = "0.12", features = ["json"] }
serde = { version = "1", features = ["derive"] }
serde_json = "1"
base64 = "0.22"
sha2 = "0.10"
hex = "0.4"
tokio = { version = "1", features = ["full"] }
actix-web = "4"  # For notification handler (or use axum)
```

## Configuration
```rust
use base64::{Engine as _, engine::general_purpose};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use std::env;

fn server_key() -> String {
    env::var("MIDTRANS_SERVER_KEY").unwrap_or_else(|_| "SB-Mid-server-YOUR_KEY".into())
}

fn base_url() -> String {
    env::var("MIDTRANS_BASE_URL").unwrap_or_else(|_| "https://api.sandbox.midtrans.com".into())
}

fn auth_header() -> String {
    let encoded = general_purpose::STANDARD.encode(format!("{}:", server_key()));
    format!("Basic {}", encoded)
}
```

## Data Structures
```rust
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct TransactionDetails {
    pub order_id: String,
    pub gross_amount: i64,
}

#[derive(Serialize, Debug, Default)]
pub struct GoPay {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub enable_callback: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub callback_url: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub account_id: Option<String>,
}

#[derive(Serialize, Debug)]
pub struct BankTransfer {
    pub bank: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub va_number: Option<String>,
}

#[derive(Serialize, Debug)]
pub struct EChannel {
    pub bill_info1: String,
    pub bill_info2: String,
}

#[derive(Serialize, Debug)]
pub struct CStore {
    pub store: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub message: Option<String>,
}

#[derive(Serialize, Debug)]
pub struct CreditCard {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub token_id: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub authentication: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub bank: Option<String>,
    #[serde(rename = "type", skip_serializing_if = "Option::is_none")]
    pub card_type: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub save_token_id: Option<bool>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub saved_token_id: Option<String>,
}

#[derive(Serialize, Debug)]
pub struct ShopeePay {
    pub callback_url: String,
}

#[derive(Serialize, Deserialize, Debug, Default)]
pub struct CustomerDetails {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub first_name: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub last_name: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub email: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub phone: Option<String>,
}

#[derive(Serialize, Debug)]
pub struct ItemDetail {
    #[serde(skip_serializing_if = "Option::is_none")]
    pub id: Option<String>,
    pub price: i64,
    pub quantity: i32,
    pub name: String,
}

#[derive(Serialize, Debug)]
pub struct ChargeRequest {
    pub payment_type: String,
    pub transaction_details: TransactionDetails,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub gopay: Option<GoPay>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub bank_transfer: Option<BankTransfer>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub echannel: Option<EChannel>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub cstore: Option<CStore>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub credit_card: Option<CreditCard>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub shopeepay: Option<ShopeePay>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub customer_details: Option<CustomerDetails>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub item_details: Option<Vec<ItemDetail>>,
}

#[derive(Deserialize, Debug)]
pub struct Action {
    pub name: String,
    pub method: String,
    pub url: String,
}

#[derive(Deserialize, Debug)]
pub struct VaNumber {
    pub bank: String,
    pub va_number: String,
}

#[derive(Deserialize, Debug)]
pub struct ChargeResponse {
    pub status_code: String,
    pub status_message: Option<String>,
    pub transaction_id: Option<String>,
    pub order_id: Option<String>,
    pub gross_amount: Option<String>,
    pub payment_type: Option<String>,
    pub transaction_status: Option<String>,
    pub fraud_status: Option<String>,
    pub actions: Option<Vec<Action>>,
    pub va_numbers: Option<Vec<VaNumber>>,
    pub bill_key: Option<String>,
    pub biller_code: Option<String>,
    pub payment_code: Option<String>,
    pub redirect_url: Option<String>,
}
```

## Charge Transaction
```rust
pub async fn charge(req: &ChargeRequest) -> Result<ChargeResponse, reqwest::Error> {
    let client = Client::new();
    let resp = client
        .post(format!("{}/v2/charge", base_url()))
        .header("Authorization", auth_header())
        .header("Content-Type", "application/json")
        .header("Accept", "application/json")
        .json(req)
        .send()
        .await?;
    resp.json().await
}
```

## Get Transaction Status
```rust
pub async fn get_status(order_id: &str) -> Result<ChargeResponse, reqwest::Error> {
    let client = Client::new();
    let resp = client
        .get(format!("{}/v2/{}/status", base_url(), order_id))
        .header("Authorization", auth_header())
        .header("Accept", "application/json")
        .send()
        .await?;
    resp.json().await
}
```

## Cancel / Expire Transaction
```rust
pub async fn cancel_transaction(order_id: &str) -> Result<ChargeResponse, reqwest::Error> {
    let client = Client::new();
    let resp = client
        .post(format!("{}/v2/{}/cancel", base_url(), order_id))
        .header("Authorization", auth_header())
        .send()
        .await?;
    resp.json().await
}

pub async fn expire_transaction(order_id: &str) -> Result<ChargeResponse, reqwest::Error> {
    let client = Client::new();
    let resp = client
        .post(format!("{}/v2/{}/expire", base_url(), order_id))
        .header("Authorization", auth_header())
        .send()
        .await?;
    resp.json().await
}
```

## Refund Transaction
```rust
#[derive(Serialize)]
struct RefundRequest {
    refund_key: String,
    amount: i64,
    reason: String,
}

pub async fn refund_transaction(
    order_id: &str,
    amount: i64,
    reason: &str,
) -> Result<ChargeResponse, reqwest::Error> {
    let client = Client::new();
    let resp = client
        .post(format!("{}/v2/{}/refund", base_url(), order_id))
        .header("Authorization", auth_header())
        .header("Content-Type", "application/json")
        .json(&RefundRequest {
            refund_key: format!("refund-{}-{}", order_id, amount),
            amount,
            reason: reason.to_string(),
        })
        .send()
        .await?;
    resp.json().await
}
```

## Signature Verification
```rust
use sha2::{Sha512, Digest};

pub fn verify_signature(
    order_id: &str,
    status_code: &str,
    gross_amount: &str,
    signature_key: &str,
) -> bool {
    let raw = format!("{}{}{}{}", order_id, status_code, gross_amount, server_key());
    let mut hasher = Sha512::new();
    hasher.update(raw.as_bytes());
    let result = hex::encode(hasher.finalize());
    result == signature_key
}
```

## Notification Handler (Actix-web)
```rust
use actix_web::{web, App, HttpServer, HttpResponse};

#[derive(Deserialize)]
pub struct MidtransNotification {
    pub order_id: String,
    pub status_code: String,
    pub gross_amount: String,
    pub signature_key: String,
    pub transaction_status: String,
    pub fraud_status: Option<String>,
    pub payment_type: Option<String>,
}

async fn handle_notification(
    notification: web::Json<MidtransNotification>,
) -> HttpResponse {
    let n = notification.into_inner();

    if !verify_signature(&n.order_id, &n.status_code, &n.gross_amount, &n.signature_key) {
        return HttpResponse::Forbidden()
            .json(serde_json::json!({"error": "Invalid signature"}));
    }

    match n.transaction_status.as_str() {
        "capture" => {
            if n.payment_type.as_deref() == Some("credit_card")
                && n.fraud_status.as_deref() == Some("accept")
            {
                // Card payment successful
            }
        }
        "settlement" => { /* Payment complete */ }
        "pending" => { /* Awaiting payment */ }
        "cancel" | "deny" | "expire" => { /* Payment failed */ }
        "refund" | "partial_refund" => { /* Refunded */ }
        _ => {}
    }

    HttpResponse::Ok().json(serde_json::json!({"status": "ok"}))
}

// In main:
// HttpServer::new(|| {
//     App::new().route("/midtrans/notification", web::post().to(handle_notification))
// })
// .bind("0.0.0.0:8080")?
// .run()
// .await
```

## Notification Handler (Axum alternative)
```rust
use axum::{extract::Json, http::StatusCode, response::IntoResponse, routing::post, Router};

async fn handle_notification_axum(
    Json(n): Json<MidtransNotification>,
) -> impl IntoResponse {
    if !verify_signature(&n.order_id, &n.status_code, &n.gross_amount, &n.signature_key) {
        return (StatusCode::FORBIDDEN, Json(serde_json::json!({"error": "Invalid signature"})));
    }

    match n.transaction_status.as_str() {
        "capture" | "settlement" => { /* Success */ }
        "pending" => { /* Waiting */ }
        "cancel" | "deny" | "expire" => { /* Failed */ }
        "refund" | "partial_refund" => { /* Refunded */ }
        _ => {}
    }

    (StatusCode::OK, Json(serde_json::json!({"status": "ok"})))
}

// let app = Router::new().route("/midtrans/notification", post(handle_notification_axum));
```
""",
}

# =============================================================================
# DOCUMENTATION MAP
# =============================================================================

DOCUMENTATION_MAP = """
# Midtrans Core API Documentation Map

## Getting Started
- [Overview] Core API overview, products, environments
- [Authorization] HTTP Basic Auth, Server Key, Base64 encoding
- [HTTP Request] Base URLs, headers, request format, idempotency

## Core API Reference
- [API Endpoints] All endpoint methods with URLs
- [Charge Transaction] POST /v2/charge - custom fields, expiry, metadata
- [Transaction Management] Get status, cancel, expire, capture, refund, BIN API
- [Transaction Status] All status values, fraud status, status flows

## Payment Methods (Core API)
### Card Payments
- Credit/Debit Card (with 3DS, One Click, Two Clicks, Pre-Auth, Installment, BIN Promo, Point)

### Bank Transfer (Virtual Account)
- BCA VA, BNI VA, BRI VA, Permata VA, CIMB VA, Mandiri Bill Payment

### E-Wallets
- GoPay (QR + deeplink + tokenization/recurring)
- ShopeePay (redirect flow)
- QRIS (QR code, acquirer: gopay or airpay)
- OVO (push notification, requires phone)
- DANA (redirect flow)

### Other
- Google Pay
- Indomaret (payment code at counter)
- Alfamart (payment code at counter)
- Akulaku PayLater (redirect flow)
- Kredivo (redirect flow, requires item_details)

## JSON Object Schemas
- transaction_details, customer_details, item_details, seller_details
- custom_expiry, credit_card_object, gopay_object, shopeepay_object
- bank_transfer_object, echannel_object, qris_object, ovo_object
- convenience_store_object, action_object, payment_amount_object
- dana_object, google_pay_object

## Notifications & Webhooks
- Webhook setup, JSON format, signature verification
- Transaction status values, fraud status values
- Best practices, retry behavior, override URL

## Status Codes
- 2xx (Success), 3xx (Redirect), 4xx (Client Error), 5xx (Server Error)

## Channel Response Codes
- Card issuer codes, GoPay codes, ShopeePay codes

## Additional APIs
- Subscription API (create, get, update, cancel, enable, disable)
- Payment Link API (create, get, delete)
- Invoicing API (create, get, void)
- Merchant Balance API

## Code Examples (Python, JavaScript/TypeScript, Go, Rust)
- Configuration & auth header
- Charge transactions (all payment types)
- Transaction management (status, cancel, expire, refund, capture)
- Notification/webhook handlers with signature verification
- Subscription management

## Testing
- Sandbox credentials, test card numbers, payment simulators
"""
