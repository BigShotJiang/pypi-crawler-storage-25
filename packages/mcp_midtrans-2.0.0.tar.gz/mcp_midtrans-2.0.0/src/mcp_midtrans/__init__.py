"""MCP Midtrans - Midtrans Payment Gateway Documentation MCP Server."""

__version__ = "1.0.0"
