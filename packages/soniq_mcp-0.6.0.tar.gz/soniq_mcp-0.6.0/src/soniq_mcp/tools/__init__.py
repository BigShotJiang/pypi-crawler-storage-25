"""Tools package for SoniqMCP.

Each module exposes a ``register(app, config)`` function that registers
its tools onto the FastMCP application. Sonos-specific tools arrive
in Story 2+.
"""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from soniq_mcp.config import SoniqConfig


def register_all(app: FastMCP, config: SoniqConfig) -> None:
    """Register all available tools, respecting tools_disabled."""
    from soniq_mcp.adapters.discovery_adapter import DiscoveryAdapter
    from soniq_mcp.adapters.soco_adapter import SoCoAdapter
    from soniq_mcp.services.audio_settings_service import AudioSettingsService
    from soniq_mcp.services.favourites_service import FavouritesService
    from soniq_mcp.services.group_service import GroupService
    from soniq_mcp.services.input_service import InputService
    from soniq_mcp.services.library_service import LibraryService
    from soniq_mcp.services.play_mode_service import PlayModeService
    from soniq_mcp.services.playback_service import PlaybackService
    from soniq_mcp.services.queue_service import QueueService
    from soniq_mcp.services.room_service import RoomService
    from soniq_mcp.services.sonos_service import SonosService
    from soniq_mcp.services.volume_service import VolumeService
    from soniq_mcp.tools.alarms import register as register_alarms
    from soniq_mcp.tools.audio import register as register_audio
    from soniq_mcp.tools.favourites import register as register_favourites
    from soniq_mcp.tools.groups import register as register_groups
    from soniq_mcp.tools.inputs import register as register_inputs
    from soniq_mcp.tools.library import register as register_library
    from soniq_mcp.tools.play_modes import register as register_play_modes
    from soniq_mcp.tools.playback import register as register_playback
    from soniq_mcp.tools.playlists import register as register_playlists
    from soniq_mcp.tools.queue import register as register_queue
    from soniq_mcp.tools.setup_support import register as register_setup
    from soniq_mcp.tools.system import register as register_system
    from soniq_mcp.tools.volume import register as register_volume

    register_setup(app, config)

    room_service = RoomService(DiscoveryAdapter())
    register_system(app, config, room_service)

    sonos_service = SonosService(room_service, SoCoAdapter(), config)
    playback_service = PlaybackService(sonos_service=sonos_service)
    register_playback(app, config, playback_service)

    volume_service = VolumeService(sonos_service=sonos_service)
    register_volume(app, config, volume_service)

    favourites_service = FavouritesService(room_service, SoCoAdapter())
    register_favourites(app, config, favourites_service)

    from soniq_mcp.services.playlist_service import PlaylistService

    playlist_service = PlaylistService(room_service, SoCoAdapter())
    register_playlists(app, config, playlist_service)

    queue_service = QueueService(room_service, SoCoAdapter())
    register_queue(app, config, queue_service)

    group_service = GroupService(room_service, SoCoAdapter(), config)
    register_groups(app, config, group_service)

    play_mode_service = PlayModeService(room_service, SoCoAdapter(), config)
    register_play_modes(app, config, play_mode_service)

    audio_settings_service = AudioSettingsService(room_service, SoCoAdapter())
    register_audio(app, config, audio_settings_service)

    input_service = InputService(room_service, SoCoAdapter())
    register_inputs(app, config, input_service)

    from soniq_mcp.services.alarm_service import AlarmService

    alarm_service = AlarmService(room_service, SoCoAdapter())
    register_alarms(app, config, alarm_service)

    library_service = LibraryService(room_service, SoCoAdapter())
    register_library(app, config, library_service)
