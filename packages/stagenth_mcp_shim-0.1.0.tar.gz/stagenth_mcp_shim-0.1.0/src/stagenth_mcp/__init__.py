"""stagenth file-relay 的本地 stdio MCP shim。

把远端 HTTPS Streamable HTTP MCP 服务 (https://stagenth.com/mcp/file-relay/) 转接成
一个跑在用户本机的 stdio MCP server, 让只支持 stdio 的客户端 (Cline / Claude Desktop
/ Cursor) 无痛接入, 同时把 download_file 改造成 "直接落盘到本地路径"。
"""

__version__ = "0.1.0"
