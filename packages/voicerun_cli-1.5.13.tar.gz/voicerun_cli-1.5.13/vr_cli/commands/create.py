import base64
from pathlib import Path

import typer
from typing import Optional

from ..entities.agent import AgentRepository
from ..entities.agent_environment import AgentEnvironment, AgentEnvironmentRepository
from ..entities.agent_environment_variable import AgentEnvironmentVariable, AgentEnvironmentVariableRepository
from ..entities.agent_secret import AgentSecret, AgentSecretRepository
from ..entities.organization_phone_number import OrganizationPhoneNumber, OrganizationPhoneNumberRepository
from ..entities.organization_secret import OrganizationSecret, OrganizationSecretRepository
from ..entities.organization_variable import OrganizationVariable, OrganizationVariableRepository
from ..entities.organization_telephony import (
    OrganizationTelephonyRepository,
    PROVIDER_TYPES,
    PROVIDER_CREDENTIAL_FIELDS,
)
from ..entities.agent_template import AgentTemplate, AgentTemplateRepository
from ..entities.user import get_current_user, get_effective_organization_id
from ..utils.agent_lock import load_agent_lock, resolve_agent
from ..utils.config import (
    TITLE_STYLE,
    INFO_STYLE,
    ERROR_STYLE,
    SUCCESS_STYLE,
)
from ..utils.utils import (
    console,
    iter_project_files,
    package_function,
    print_warning,
    prompt,
)

app = typer.Typer(help="Create resources.")


@app.command("secret")
@app.command("secrets", hidden=True)
def create_secret(
    name: str = typer.Argument(help="Secret name"),
    value: str = typer.Argument(help="Secret value"),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent name or ID (omit for organization secret)"),
):
    """Create an organization secret for evaluator usage.

    Agent-scoped secrets are not yet supported for runtime injection. To inject a value
    into `context.variables` at runtime, use `vr create variable` with `--masked` instead.
    """
    if agent:
        console.print(
            f"[{ERROR_STYLE}]Agent-scoped secrets are not yet supported.[/{ERROR_STYLE}]"
        )
        console.print(
            f"[{INFO_STYLE}]To inject a value readable via `context.variables.get(\"{name}\")`, "
            f"create a masked variable instead:[/{INFO_STYLE}]"
        )
        console.print(
            f"  [{TITLE_STYLE}]vr create variable {name} {value} --masked "
            f"--agent {agent} --environment ENVIRONMENT[/{TITLE_STYLE}]"
        )
        raise typer.Exit(1)

    # Create organization secret
    organization_id = get_effective_organization_id()
    if not organization_id:
        console.print(f"[{ERROR_STYLE}]Unable to determine organization. Please sign in or set organization ID with 'vr context set-org'.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    repo = OrganizationSecretRepository()
    secret = OrganizationSecret(name=name, value=value)
    created_secret = repo.create(secret)

    if not created_secret:
        console.print(f"[{ERROR_STYLE}]Failed to create organization secret '{name}'.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    console.print(f"[{SUCCESS_STYLE}]Organization secret '{name}' created successfully.[/{SUCCESS_STYLE}]")
    console.print(f"  [{INFO_STYLE}]ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{created_secret.id}[/{TITLE_STYLE}]")


@app.command("variable")
@app.command("variables", hidden=True)
def create_variable(
    name: str = typer.Argument(help="Variable name"),
    value: str = typer.Argument(help="Variable value"),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent name or ID (defaults to agent.lock)"),
    environment: Optional[str] = typer.Option(None, "--environment", "-e", help="Environment name or ID (required unless --org)"),
    org: bool = typer.Option(False, "--org", help="Create an organization-level variable instead of an agent environment variable"),
    masked: bool = typer.Option(False, "--masked", help="Mask the value in listings and describe output"),
):
    """Create a variable readable via `context.variables.get(NAME)` in agent handlers.

    By default, creates a variable scoped to a specific agent environment. Use --org to
    create an organization-level variable visible to every agent in the org.
    """
    if org:
        if agent or environment:
            console.print(f"[{ERROR_STYLE}]--org cannot be combined with --agent or --environment.[/{ERROR_STYLE}]")
            raise typer.Exit(1)

        organization_id = get_effective_organization_id()
        if not organization_id:
            console.print(f"[{ERROR_STYLE}]Unable to determine organization. Please sign in or set organization ID with 'vr context set-org'.[/{ERROR_STYLE}]")
            raise typer.Exit(1)

        repo = OrganizationVariableRepository()
        variable = OrganizationVariable(name=name, value=value, masked=masked)
        created = repo.create(variable)

        if not created:
            console.print(f"[{ERROR_STYLE}]Failed to create organization variable '{name}'.[/{ERROR_STYLE}]")
            raise typer.Exit(1)

        console.print(f"[{SUCCESS_STYLE}]Organization variable '{name}' created successfully.[/{SUCCESS_STYLE}]")
        console.print(f"  [{INFO_STYLE}]ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{created.id}[/{TITLE_STYLE}]")
        return

    if not environment:
        console.print(f"[{ERROR_STYLE}]--environment is required for agent-scoped variables.[/{ERROR_STYLE}]")
        console.print(f"[{INFO_STYLE}]Pass --environment ENV_NAME or use --org for an organization-level variable.[/{INFO_STYLE}]")
        raise typer.Exit(1)

    agent_entity = resolve_agent(agent)

    env_repo = AgentEnvironmentRepository(agent_entity.id)
    env_entity = env_repo.get_by_name_or_id(environment)
    if not env_entity:
        console.print(f"[{ERROR_STYLE}]Environment not found: {environment}[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    repo = AgentEnvironmentVariableRepository(agent_entity.id, env_entity.id)
    variable = AgentEnvironmentVariable(name=name, value=value, masked=masked)
    created = repo.create(variable)

    if not created:
        console.print(f"[{ERROR_STYLE}]Failed to create variable '{name}'.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    console.print(
        f"[{SUCCESS_STYLE}]Variable '{name}' created successfully for agent '{agent_entity.name}' "
        f"environment '{env_entity.name}'.[/{SUCCESS_STYLE}]"
    )
    console.print(f"  [{INFO_STYLE}]ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{created.id}[/{TITLE_STYLE}]")


@app.command("assignment")
@app.command("assignments", hidden=True)
def create_assignment(
    first: Optional[str] = typer.Argument(None, help="Agent name or ID, or environment name if agent is from agent.lock"),
    second: Optional[str] = typer.Argument(None, help="Environment name or ID, or phone number ID if agent is from agent.lock"),
    third: Optional[str] = typer.Argument(None, help="Organization phone number ID"),
    configure: bool = typer.Option(False, "--configure", help="Configure the phone number with the telephony provider after assignment"),
):
    """Assign a phone number to an agent environment."""
    if third is not None:
        agent_entity = resolve_agent(first)
        environment = second
        phone_number_id = third
    elif second is not None:
        agent_entity = resolve_agent(None)
        environment = first
        phone_number_id = second
    else:
        console.print(f"[{ERROR_STYLE}]Usage: vr create assignment [AGENT] ENVIRONMENT PHONE_NUMBER_ID[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    # Resolve environment
    env_repo = AgentEnvironmentRepository(agent_entity.id)
    env_entity = env_repo.get_by_name_or_id(environment)

    if not env_entity:
        console.print(f"[{ERROR_STYLE}]Environment not found: {environment}[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    repo = OrganizationPhoneNumberRepository()
    assigned = repo.assign(phone_number_id, agent_entity.id, env_entity.id)

    if not assigned:
        console.print(f"[{ERROR_STYLE}]Failed to create assignment.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    console.print(f"[{SUCCESS_STYLE}]Assignment created successfully.[/{SUCCESS_STYLE}]")
    console.print(f"  [{INFO_STYLE}]Phone Number ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{assigned.id}[/{TITLE_STYLE}]")
    console.print(f"  [{INFO_STYLE}]Agent ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{assigned.agent_id}[/{TITLE_STYLE}]")
    console.print(f"  [{INFO_STYLE}]Environment ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{assigned.agent_environment_id}[/{TITLE_STYLE}]")

    if configure:
        configured = repo.configure(assigned.id)
        if not configured:
            console.print(f"[{ERROR_STYLE}]Failed to configure phone number.[/{ERROR_STYLE}]")
            raise typer.Exit(1)
        console.print(f"[{SUCCESS_STYLE}]Phone number configured successfully.[/{SUCCESS_STYLE}]")


@app.command("environment")
@app.command("environments", hidden=True)
def create_environment(
    agent_or_name: Optional[str] = typer.Argument(None, help="Agent name or ID, or environment name if agent is from agent.lock"),
    name: Optional[str] = typer.Argument(None, help="Environment name"),
    stt_model: Optional[str] = typer.Option(None, "--stt-model", help="Speech-to-text model (e.g. flux-general-en)"),
    stt_language: Optional[str] = typer.Option(None, "--stt-language", help="STT language code (e.g. en)"),
    stt_endpointing: Optional[int] = typer.Option(None, "--stt-endpointing", help="STT endpointing timeout in ms"),
    recording: Optional[bool] = typer.Option(None, "--recording/--no-recording", help="Enable or disable call recording"),
):
    """Create an environment for an agent."""
    if name is not None:
        agent_entity = resolve_agent(agent_or_name)
    elif agent_or_name is not None:
        agent_entity = resolve_agent(None)
        name = agent_or_name
    else:
        console.print(f"[{ERROR_STYLE}]Environment name is required.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    env_kwargs = {"name": name}

    voicerun_dir = Path.cwd() / ".voicerun"
    agent_lock = load_agent_lock(voicerun_dir)
    if agent_lock and agent_lock.get("functionId"):
        env_kwargs["function_id"] = agent_lock["functionId"]

    if stt_model is not None:
        env_kwargs["stt_model"] = stt_model
    if stt_language is not None:
        env_kwargs["stt_language"] = stt_language
    if stt_endpointing is not None:
        env_kwargs["stt_endpointing"] = stt_endpointing
    if recording is not None:
        env_kwargs["recording_enabled"] = recording

    env = AgentEnvironment(**env_kwargs)
    repo = AgentEnvironmentRepository(agent_entity.id)
    created = repo.create(env)

    if not created:
        console.print(f"[{ERROR_STYLE}]Failed to create environment '{name}'.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    console.print(f"[{SUCCESS_STYLE}]Environment '{name}' created successfully for agent '{agent_entity.name}'.[/{SUCCESS_STYLE}]")
    console.print(f"  [{INFO_STYLE}]ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{created.id}[/{TITLE_STYLE}]")
    console.print(f"  [{INFO_STYLE}]Name:[/{INFO_STYLE}] [{TITLE_STYLE}]{created.name}[/{TITLE_STYLE}]")


@app.command("phonenumber")
@app.command("phonenumbers", hidden=True)
def create_phone_number(
    telephony_id: str = typer.Argument("voicerun", help="Telephony provider ID"),
    purchase: bool = typer.Option(False, "--purchase", help="Purchase a new number from the telephony provider"),
    area_code: Optional[str] = typer.Option(None, "--area-code", "-a", help="Area code for the phone number"),
    country_code: Optional[str] = typer.Option(None, "--country-code", "-c", help="Country code (defaults to US)"),
    friendly_name: Optional[str] = typer.Option(None, "--friendly-name", "-n", help="Friendly name for the phone number"),
    phone_number_value: Optional[str] = typer.Option(None, "--phone-number", "-p", help="Phone number to register (without --purchase)"),
):
    """Create or purchase a phone number for the organization."""
    organization_id = get_effective_organization_id()
    if not organization_id:
        console.print(f"[{ERROR_STYLE}]Unable to determine organization. Please sign in or set organization ID with 'vr context set-org'.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    repo = OrganizationPhoneNumberRepository()

    if purchase:
        phone_number = repo.purchase(
            telephony_id=telephony_id,
            area_code=area_code,
            country_code=country_code,
            friendly_name=friendly_name,
        )

        if not phone_number:
            console.print(f"[{ERROR_STYLE}]Failed to purchase phone number.[/{ERROR_STYLE}]")
            raise typer.Exit(1)

        console.print(f"[{SUCCESS_STYLE}]Phone number purchased successfully.[/{SUCCESS_STYLE}]")
    else:
        entity = OrganizationPhoneNumber(
            telephony_id=telephony_id,
            phone_number=phone_number_value,
            area_code=area_code,
            country_code=country_code,
            friendly_name=friendly_name,
        )
        phone_number = repo.create(entity)

        if not phone_number:
            console.print(f"[{ERROR_STYLE}]Failed to create phone number.[/{ERROR_STYLE}]")
            raise typer.Exit(1)

        console.print(f"[{SUCCESS_STYLE}]Phone number created successfully.[/{SUCCESS_STYLE}]")

    console.print(f"  [{INFO_STYLE}]Phone Number:[/{INFO_STYLE}] [{TITLE_STYLE}]{phone_number.phone_number}[/{TITLE_STYLE}]")
    console.print(f"  [{INFO_STYLE}]ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{phone_number.id}[/{TITLE_STYLE}]")
    if phone_number.friendly_name:
        console.print(f"  [{INFO_STYLE}]Friendly Name:[/{INFO_STYLE}] [{TITLE_STYLE}]{phone_number.friendly_name}[/{TITLE_STYLE}]")


@app.command("telephony")
def create_telephony(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Name for the telephony provider"),
    provider_type: Optional[str] = typer.Option(None, "--provider-type", "-p", help=f"Provider type ({', '.join(PROVIDER_TYPES)})"),
    # Twilio credentials
    account_sid: Optional[str] = typer.Option(None, "--account-sid", help="Twilio Account SID"),
    api_key_sid: Optional[str] = typer.Option(None, "--api-key-sid", help="Twilio API Key SID"),
    api_key_secret: Optional[str] = typer.Option(None, "--api-key-secret", help="Twilio API Key Secret"),
    # Telnyx credentials
    api_key: Optional[str] = typer.Option(None, "--api-key", help="Telnyx API Key"),
):
    """Create a telephony provider for the organization."""
    organization_id = get_effective_organization_id()
    if not organization_id:
        console.print(f"[{ERROR_STYLE}]Unable to determine organization. Please sign in or set organization ID with 'vr context set-org'.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    # Prompt for missing values interactively
    if not name:
        name = prompt("Name")

    if not provider_type:
        def _validate_provider_type(value):
            if value not in PROVIDER_TYPES:
                raise typer.BadParameter(f"Must be one of: {', '.join(PROVIDER_TYPES)}")
            return value

        provider_type = prompt(
            f"Provider type ({', '.join(PROVIDER_TYPES)})",
            validation=_validate_provider_type,
        )

    if provider_type not in PROVIDER_TYPES:
        console.print(f"[{ERROR_STYLE}]Invalid provider type '{provider_type}'. Must be one of: {', '.join(PROVIDER_TYPES)}[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    # Build credentials from flags or interactive prompts
    flag_values = {
        "account_sid": account_sid,
        "api_key_sid": api_key_sid,
        "api_key_secret": api_key_secret,
        "api_key": api_key,
    }

    credentials = {}
    for field_key, field_label in PROVIDER_CREDENTIAL_FIELDS[provider_type]:
        # Convert snake_case field key to camelCase for API
        camel_key = "".join(
            word.capitalize() if i > 0 else word
            for i, word in enumerate(field_key.split("_"))
        )
        value = flag_values.get(field_key)
        if not value:
            value = prompt(field_label)
        credentials[camel_key] = value

    repo = OrganizationTelephonyRepository()
    telephony = repo.create_with_credentials(name, provider_type, credentials)

    if not telephony:
        console.print(f"[{ERROR_STYLE}]Failed to create telephony provider.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    console.print(f"[{SUCCESS_STYLE}]Telephony provider '{name}' created successfully.[/{SUCCESS_STYLE}]")
    console.print(f"  [{INFO_STYLE}]ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{telephony.id}[/{TITLE_STYLE}]")
    console.print(f"  [{INFO_STYLE}]Provider:[/{INFO_STYLE}] [{TITLE_STYLE}]{telephony.provider_type}[/{TITLE_STYLE}]")


@app.command("template")
@app.command("templates", hidden=True)
def create_template(
    name: str = typer.Argument(help="Template name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Template description"),
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Template category"),
    public: bool = typer.Option(False, "--public/--private", help="Make template public (admin only) or private to org"),
    upsert: bool = typer.Option(False, "--upsert", help="Update the template if one with the same name and visibility already exists, otherwise create it"),
):
    """Create a template from the current project files."""
    # Only admins can create public templates
    user = get_current_user()
    if not user:
        console.print(f"[{ERROR_STYLE}]Unable to fetch user session. Please sign in with `vr signin`.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    if public and not user.is_admin:
        print_warning("You cannot create public templates. Creating as private.")
        public = False

    project_dir = Path.cwd()

    # Exclude agent.lock from the published template: it binds the author's
    # project to a specific deployed function (agent ID + function ID + checksum).
    # Including it leaks internal IDs and gives everyone who instantiates
    # the template a broken binding on their first `vr push`. Templates are
    # source snapshots — the lock should be regenerated per-instance.
    # This exclusion is scoped to template creation only; `vr push` and other
    # commands continue to include agent.lock as before.
    template_excludes = ["agent.lock"]

    file_paths = [rel_path for _, rel_path in iter_project_files(str(project_dir), template_excludes)]
    if not file_paths:
        console.print(f"[{ERROR_STYLE}]No files found in current directory.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    zip_bytes, _ = package_function(str(project_dir), template_excludes)
    code_b64 = base64.b64encode(zip_bytes).decode("utf-8")

    repo = AgentTemplateRepository()

    # --upsert: scope the lookup to (name, is_public) so we only match a
    # template with identical visibility. A public and private template can
    # coexist with the same name (public has null organizationId, private is
    # org-scoped), and flipping visibility is a destructive operation that
    # should require explicit delete + recreate — not a silent update.
    existing = None
    if upsert:
        existing = next(
            (
                t for t in repo.get()
                if t.name == name and bool(getattr(t, "is_public", False)) == public
            ),
            None,
        )

    if existing:
        update_entity = AgentTemplate(
            description=description,
            category=category,
            code=code_b64,
        )
        updated = repo.update_by_id(existing.id, update_entity)
        if not updated:
            console.print(f"[{ERROR_STYLE}]Failed to update template.[/{ERROR_STYLE}]")
            raise typer.Exit(1)

        console.print(f"[{SUCCESS_STYLE}]Template '{name}' updated successfully.[/{SUCCESS_STYLE}]")
        console.print(f"  [{INFO_STYLE}]ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{updated.id}[/{TITLE_STYLE}]")
        console.print(f"  [{INFO_STYLE}]Files:[/{INFO_STYLE}]")
        for f in file_paths:
            console.print(f"    [{TITLE_STYLE}]{f}[/{TITLE_STYLE}]")
        return

    template_entity = AgentTemplate(
        name=name,
        description=description,
        category=category,
        is_public=public,
        code=code_b64,
    )
    created = repo.create(template_entity)

    if not created:
        console.print(f"[{ERROR_STYLE}]Failed to create template.[/{ERROR_STYLE}]")
        raise typer.Exit(1)

    console.print(f"[{SUCCESS_STYLE}]Template '{name}' created successfully.[/{SUCCESS_STYLE}]")
    console.print(f"  [{INFO_STYLE}]ID:[/{INFO_STYLE}] [{TITLE_STYLE}]{created.id}[/{TITLE_STYLE}]")
    console.print(f"  [{INFO_STYLE}]Files:[/{INFO_STYLE}]")
    for f in file_paths:
        console.print(f"    [{TITLE_STYLE}]{f}[/{TITLE_STYLE}]")


if __name__ == "__main__":
    app()
