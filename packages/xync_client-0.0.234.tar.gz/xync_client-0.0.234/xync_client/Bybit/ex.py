import json
from asyncio import run
from uuid import uuid4

from pyro_client.client.file import FileClient
from x_client import df_hdrs
from x_model import init_db
from xync_schema import models, xtype
from xync_schema.enums import AdStatus
from xync_schema.models import Ex, Agent

from xync_client.Bybit.etype import pm
from xync_client.Abc.Ex import BaseExClient
from xync_client.loader import NET_TOKEN, PRX
from xync_client.Bybit.etype import ad as ad_etype
from xync_client.Abc.xtype import PmEx, MapOfIdsList, GetAdsReq
from xync_client.loader import TORM


class ExClient(BaseExClient):  # Bybit client
    headers = df_hdrs  # rewrite token for public methods
    agent: Agent = None
    tuid = uuid4().hex
    sec_hdrs = {
        # "accept": "application/json",
        "accept-language": "en",
        "lang": "en",
        "platform": "PC",
        "sec-fetch-site": "same-origin",
        "traceparent": f"00-{tuid}-{tuid[16::-1]}-01",
        "origin": "https://www.bybit.com",
        "cookies": f"deviceId={uuid4()}",
        # "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
    }

    @staticmethod
    def ad_status(status: int) -> AdStatus:
        return {
            10: AdStatus.active,
            20: AdStatus.defActive,
            30: AdStatus.soldOut,
        }[status]

    async def _get_config(self):
        resp = await self._get("/x-api/fiat/p2p/config/initial", hdrs=self.sec_hdrs)
        return resp["result"]["symbols"]  # todo: tokens, pairs, ...

    # 19: Список поддерживаемых валют тейкера
    async def curs(self) -> dict[int, xtype.CurEx]:
        config = await self._get_config()
        return {
            c["currencyId"]: xtype.CurEx(
                exid=c["currencyId"],
                ticker=c["currencyId"],
                scale=c["currency"]["scale"],
                minimum=c["currencyMinQuote"],
            )
            for c in config
        }

    # 20: Список платежных методов
    async def pms(self, cks: dict = None) -> dict[int, PmEx]:
        pms = await self._post("/x-api/fiat/otc/configuration/queryAllPaymentList/", hdrs=self.sec_hdrs, cks=cks)
        pms = [pm.PmEx.model_validate(p) for p in pms["result"]["paymentConfigVo"]]
        # if ctrs := {p.exid: p.country for p in pms if p.country}: # todo: добавить страны
        return {p.exid: PmEx.model_validate(p) for p in pms}

    # 21: Список платежных методов по каждой валюте
    async def cur_pms_map(self, cks: dict = None) -> MapOfIdsList:
        pms = await self._post("/x-api/fiat/otc/configuration/queryAllPaymentList/", hdrs=self.sec_hdrs, cks=cks)
        return json.loads(pms["result"]["currencyPaymentIdMap"])

    # 22: Список торгуемых монет (с ограничениям по валютам, если есть)
    async def coins(self) -> dict[str, xtype.CoinEx]:
        config = await self._get_config()
        coinexs = {}
        for c in config:
            coinexs[c["tokenId"]] = xtype.CoinEx(
                exid=c["tokenId"], ticker=c["tokenId"], minimum=c["tokenMinQuote"], scale=c["token"]["scale"]
            )
        return coinexs

    # 23: Список пар валюта/монет
    async def pairs(self) -> tuple[MapOfIdsList, MapOfIdsList]:
        config = await self._get_config()
        cc: dict[str, set[str]] = {}
        for c in config:
            cc[c["currencyId"]] = cc.get(c["currencyId"], set()) | {c["tokenId"]}
        return cc, cc

    # 24: Список объяв по (buy/sell, cur, coin, pm)
    async def _ads(self, req: ad_etype.AdsReq, post_pmexs: set[models.PmEx] = None) -> list[ad_etype.Ad]:
        if post_pmexs:
            req.payment = []
            req.size = str(min(1000, int(req.size) * 25))
        res = await self._post("/x-api/fiat/otc/item/online/", req.model_dump(), hdrs=self.sec_hdrs)
        ads = [ad_etype.Ad(**_ad) for _ad in res["result"]["items"]]
        if post_pmexs:
            post_pmexids = {p.exid for p in post_pmexs}
            ads = [
                ad
                for ad in ads
                if (set(ad.pmex_exids) & post_pmexids or [True for px in post_pmexs if px.pm.norm in ad.remark.lower()])
            ]
        return ads


async def main():
    _ = await init_db(TORM, True)
    ex = await Ex.get(name="Bybit")
    bot = FileClient(NET_TOKEN)
    # await bot.start()
    prx = PRX and "http://" + PRX
    cl: ExClient = ex.client(proxy=prx)
    x_ads_req = GetAdsReq(coin_id=1, cur_id=1, is_sell=True, vm_only=True)  # , pm_ids=[330, 366, 1853]
    _ads = await cl.ads(x_ads_req)
    # await cl.set_curs()
    await cl.set_pms(bot)
    await cl.set_coins()
    await cl.set_pairs()
    # await bot.stop()
    await cl.stop()


if __name__ == "__main__":
    run(main())
