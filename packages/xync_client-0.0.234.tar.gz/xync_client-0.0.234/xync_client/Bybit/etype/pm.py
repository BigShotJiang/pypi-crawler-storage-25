from enum import IntEnum
from typing import Self

from pydantic import Field, model_validator

from xync_client.Abc.xtype import PmEx as BasePmEx
from xync_schema.enums import PmType


class Typ(IntEnum):
    bank_acc = 1  # no. or IBAN
    emoney = 2  # QR / phone-based
    cash = 3  # ваучеры / агентские
    card = 4  # fintech/processing/PSP
    # India
    imps = 6  # IMPS
    upi = 7  # UPI
    neft_rgts = 9  # NEFT / RTGS
    # Regional
    sea_bank = 22  # Vietnam / Cambodia
    ukraine = 27  # banks
    philip_wallet = 37  # Philippines
    columbia_daviplata = 42
    columbia_nequi = 43
    pix = 50  # Brasilia
    venezuela_pago = 68
    sea_wallet = 71
    pakistan = 74  # Pakistan
    philip_bank = 75  # Philippines
    bank_acc_idr = 79  # Indonesia banks
    emoney_idr = 80  # Indonesia wallets
    mexico_clabe = 83
    mexico_spei = 84
    mexico_bank = 85
    # local = 100+


typ_map: dict[Typ | int, PmType] = {
    Typ.bank_acc: PmType.bank_acc,
    Typ.emoney: PmType.emoney,
    Typ.cash: PmType.cash,
    Typ.card: PmType.card,
    Typ.imps: PmType.emoney,
    Typ.upi: PmType.emoney,
    Typ.neft_rgts: PmType.emoney,
    Typ.sea_bank: PmType.bank_acc,
    Typ.ukraine: PmType.bank_acc,
    Typ.columbia_daviplata: PmType.emoney,
    Typ.columbia_nequi: PmType.emoney,
    Typ.pix: PmType.emoney,
    Typ.venezuela_pago: PmType.emoney,
    Typ.sea_wallet: PmType.emoney,
    Typ.pakistan: PmType.bank_acc,
    Typ.philip_wallet: PmType.emoney,
    Typ.philip_bank: PmType.bank_acc,
    Typ.bank_acc_idr: PmType.bank_acc,
    Typ.emoney_idr: PmType.emoney,
    Typ.mexico_clabe: PmType.emoney,
    Typ.mexico_spei: PmType.emoney,
    Typ.mexico_bank: PmType.bank_acc,
}


class PmEx(BasePmEx):
    exid: int = Field(alias="paymentType")
    name: str = Field(alias="paymentName")
    typ: Typ | PmType | int = Field(alias="checkType")
    country: str | None = None

    @model_validator(mode="after")
    def type_map(self) -> Self:
        if self.typ in {Typ.imps, Typ.upi, Typ.neft_rgts, 31, 32}:
            self.country = "In"
        elif self.typ in {Typ.sea_wallet, Typ.sea_bank}:
            self.country = "SEA"
        elif self.typ in {Typ.ukraine, 51, 52, 53, 54, 55}:
            self.country = "UA"
        elif self.typ in {Typ.columbia_nequi, Typ.columbia_daviplata, 66, 120}:
            self.country = "CO"
        elif self.typ in {Typ.pix, 82}:
            self.country = "BR"
        elif self.typ in {Typ.venezuela_pago, 86, 87, 89, 90}:
            self.country = "VE"
        elif self.typ in {Typ.pakistan, 72}:
            self.country = "PK"
        elif self.typ in {Typ.philip_bank, Typ.philip_wallet}:
            self.country = "PH"
        elif self.typ in {Typ.mexico_clabe, Typ.mexico_spei, Typ.mexico_bank, 167}:
            self.country = "MX"
        elif self.typ in {62, 138, 141, 154, 159, 160, 161, 162, 163}:
            self.country = "AR"
        elif 92 <= self.typ <= 100 or 107 <= self.typ <= 118:
            self.country = "PY"
        elif 129 <= self.typ <= 136:
            self.country = "UY"
        elif 142 <= self.typ <= 153:
            self.country = "GT"
        self.typ: PmType = typ_map.get(self.typ, PmType.common)
        return self
