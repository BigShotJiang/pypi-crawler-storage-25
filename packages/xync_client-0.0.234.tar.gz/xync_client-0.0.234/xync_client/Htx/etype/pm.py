from enum import IntEnum
from typing import Self

from pydantic import Field, model_validator
from xync_schema.enums import PmType
from xync_client.Abc.xtype import PmEx as BasePmEx


class Typ(IntEnum):
    common = 0
    bank_acc = 1  # no. or IBAN
    emoney = 2  # QR / phone-based
    cash = 3  # ваучеры / агентские
    card = 4  # fintech/processing
    local = 5  # региональные: bank_routing-based: IFSC(Индия), CLABE(Мексика), банк.коды ЛатАм


typ_map: dict[Typ, PmType] = {
    Typ.common: PmType.common,
    Typ.bank_acc: PmType.bank_acc,
    Typ.emoney: PmType.emoney,
    Typ.cash: PmType.cash,
    Typ.card: PmType.card,
    Typ.local: PmType.local,
}


class PmEx(BasePmEx):
    exid: int = Field(alias="payMethodId")
    name: str
    typ: Typ | PmType = Field(alias="template")
    color: str
    bankImage: str | None
    bankImageWeb: str | None
    logo: str = None
    # defaultName: str | None = None
    # bankType: int

    @model_validator(mode="after")
    def type_map(self) -> Self:
        self.typ: PmType = typ_map[self.typ]
        self.logo = self.bankImage or self.bankImageWeb
        return self
