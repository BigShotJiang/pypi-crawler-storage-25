import logging
from abc import abstractmethod
from enum import IntEnum

from xync_schema.enums import OrderStatus

from xync_client.Abc.xtype import BaseOrder

from xync_client.Abc.Agent import BaseAgentClient
from xync_schema.models import Order, PmEx, CredEx, PairSide, Cred


class RetCode(IntEnum):
    SUCCESS = 0
    ILLEGAL_STATUS = 1


class BaseOrderClient:
    order: Order
    agent_client: BaseAgentClient
    im_maker: bool
    im_seller: bool

    def __init__(self, order: Order, agent_client: BaseAgentClient):
        assert isinstance(order.ad.pair_side, PairSide) and isinstance(order.cred, Cred)
        self.order = order
        self.im_maker = order.taker_id != agent_client.actor.id  # or order.ad.agent_id == agent.id
        self.im_seller = order.ad.pair_side.is_sell and self.im_maker
        self.agent_client = agent_client

    # 5: [B] Перевод сделки в состояние "оплачено", c отправкой чека
    async def mark_payed(self, cred_id: int = None, receipt: bytes = None):
        cred_id = cred_id or self.order.cred_id
        pmex = await PmEx.get(pm__pmcurs__id=self.order.cred.pmcur_id, ex=self.agent_client.ex_client.ex)
        credex = await CredEx.get(cred_id=cred_id, ex=self.agent_client.ex_client.ex)
        try:
            await self._mark_payed(credex.exid, pmex.exid, receipt)
        except Exception as e:
            o = await self.agent_client.get_order_full(self.order.exid)
            logging.error(f"ORDER STATUS NOW: {o.status}")
            raise e
        txt = "Buyer paid sell" if self.im_seller else "You paid buy"
        logging.info(txt)

    @abstractmethod
    async def _mark_payed(self, credex_exid: int = None, pmex_exid: int | str = None, receipt: bytes = None): ...

    # 6: [B] Отмена сделки
    @abstractmethod
    async def cancel_order(self) -> bool: ...

    # 6: Запрос отмены (оплаченная контрагентом продажа)
    async def cancel_request(self) -> bool: ...

    # 6: Одобрение запроса на отмену (оплаченная мной покупка)
    async def cancel_accept(self, check_first: bool = False) -> (RetCode, str):
        fo: BaseOrder | None = None
        if check_first:
            fo: BaseOrder = await self.agent_client._get_order_full(self.order.exid)
            if fo.status == OrderStatus.canceled:
                logging.error(f"ORDER STATUS NOW: {fo.status}")
                return RetCode.ILLEGAL_STATUS
        try:
            return await self._cancel_accept()
        except Exception as e:
            fo = fo or await self.agent_client.get_order_full(self.order.exid)
            logging.error(f"ORDER STATUS NOW: {fo.status}")
            raise e

    # 7: [S] Подтвердить получение оплаты
    @abstractmethod
    async def confirm(self) -> bool: ...

    # 9, 10: [S, B] Подать аппеляцию cо скриншотом / видео / файлом
    @abstractmethod
    async def start_appeal(self, file) -> bool: ...

    # 11, 12: [S, B] Встречное оспаривание полученной аппеляции cо скриншотом / видео / файлом
    @abstractmethod
    async def dispute_appeal(self, file) -> bool: ...

    # 15: [B, S] Отмена аппеляции
    @abstractmethod
    async def cancel_appeal(self) -> bool: ...

    # 15: Принять аппеляцию
    async def appeal_accept(self): ...

    # 16: Отправка сообщения юзеру в чат по ордеру с приложенным файлом
    @abstractmethod
    async def send_order_msg(self, msg: str, file=None) -> bool: ...

    # 17: Отправка сообщения по апелляции
    @abstractmethod
    async def send_appeal_msg(self, file, msg: str = None) -> bool: ...
