from enum import IntEnum

from pydantic import BaseModel, Field, model_validator
from typing import Optional, List, Self

from xync_schema.enums import PmType


class PaymentConfig(BaseModel):
    type: int
    category: int
    required: bool
    key: str
    title: str
    placeholder: str
    length: Optional[int] = None
    sort: int
    titleTranslationKey: Optional[str] = None
    placeholderTranslationKey: Optional[str] = None


class Typ(IntEnum):
    Bank = 1
    Mobile = 2
    Cash = 3
    Fintech = 4
    National = 5


# Known name sets (lowercase) for high-confidence classification
_TYPE5 = {"pix", "imps", "nequi", "daviplata", "bancolombia s.a.", "banesco", "itaú brazil"}

_CASH = {
    "western union",
    "efecty",
    "oxxo",
    "7-eleven",
    "cash deposit to bank",
    "cash in person",
    "bank slip",
    "airtime mobile top-up",
    "mobile top-up",
    "recarga pines",
    "wafa cash",
    "cash plus",
}

_FINTECH = {
    "paypal",
    "revolut",
    "wise",
    "skrill (moneybookers)",
    "neteller",
    "payoneer",
    "apple pay",
    "coinpay",
    "payeer",
    "paysera",
    "bunq",
    "n26",
    "monzo",
    "zen.com",
    "zinli",
    "chipper cash",
    "ecopayz",
    "volet",
    "trubit",
    "cash app",
    "interac e-transfer",
    "airtm",
    "perfect money",
    "zen",
    "picpay",
    "pagseguro",
    "ubii pagos",
}

_EWALLET = {
    # Asian e-wallets & QR
    "alipay",
    "gcash",
    "gopay",
    "dana(indonesia)",
    "ovo",
    "grabpay",
    "touch 'n go",
    "shopeepay - sea",
    "shopeepay-sea",
    "momo",
    "jkopay",
    "upi",
    "coins.ph",
    "maya",
    "zalo pay",
    "careem pay",
    "aani",
    "payme",
    "khqr",
    "mandiri pay",
    "vietqr",
    "yap! (bni)",
    "u-money",
    "bit",
    "stc pay",
    "google pay (gpay)",
    "samsungpay",
    "true money (cambodia)",
    "yape",
    "click",
    "jenius payme",
    # Mobile money (Africa / South Asia / Middle East)
    "m-pesa kenya",
    "mtn mobile money",
    "airtel money",
    "wave mobile money",
    "moov money",
    "orange money (om)",
    "vodafone cash",
    "mpesa ethiopia",
    "cbe birr",
    "tele birr",
    "o!money",
    "bkash",
    "nagad",
    "rocket",
    "easypaisa (pakistan)",
    "nayapay",
    "upaisa",
    "sadapay",
    "khalti",
    "esewa",
    "ime pay",
    "ezcash",
    "kbzpay",
    "aya pay",
    "asiapay",
    "bigpay",
    "m-pesa paybill",
    "m-pesa pochi la biashara",
    "fnb ewallet",
    "fnb-ewallet",
    "etisalat cash",
    "etisalat wallet",
    "orange cash",
    "we pay",
    "telecash",
    "salampay",
    "wavepay",
    # Regional fintech wallets (account-number-based but wallet-first UX)
    "opay",
    "palmpay",
    "telda",
    "pyypl",
    "mobily pay",
    "alinma pay",
    "urpay",
    "zain cash",
    "zaincash - business",
    "leumi digital",
    "m10 - instant",
    "komo bank",
    "genie",
    "raast",
    "instapay",
    "superqi",
    "юmoney",
    "geo pay",
    "fastpay",
}

_P2P = {
    "sbp - fast bank transfer",
    "sepa",
    "sepa instant",
    "swift",
    "zelle",
    "bizum",
    "blik",
    "faster payments",
    "spei",
    "pagomóvil",
    "koronapay",
    "paysend",
    "paysend.com",
    "mastercard send",
    "visa direct",
    "stp",
    "switch",
    "neo pay iraq",
    "kapital bank instant",
}

_LATAM_WALLET = {
    "mercadopago",
    "lemon cash",
    "prex",
    "uala",
    "ualá colombia",
    "naranja x",
    "belo app",
    "movii",
    "llaves bre-b",
}

_BANK_ABBREVS = {
    "aba",
    "abb",
    "acba",
    "mcb",
    "qnb",
    "hsbc",
    "ing",
    "bnp",
    "cib",
    "cih",
    "bbva",
    "ocbc",
    "rhb",
    "bca",
    "bri",
    "bni",
    "bdo",
    "pnb",
    "gtb",
    "fnb",
    "otp",
    "rbc",
    "brd",
    "cimb",
    "pumb",
    "maib",
}


def _is_bank_like(name_lower: str) -> bool:
    """Heuristic: does this name look like a bank?"""
    if any(w in name_lower for w in ["bank", "banco", "banque", "banca", "banc"]):
        return True
    first_word = name_lower.split()[0] if name_lower else ""
    if first_word in _BANK_ABBREVS:
        return True
    # Names that end with bank-related suffixes
    for suffix in ("reservas", "popular", "activo"):
        if name_lower.endswith(suffix):
            return True
    return False


def _is_pay_name(name_lower: str) -> bool:
    """Name suggests a wallet / payment app (not a bank)."""
    if _is_bank_like(name_lower):
        return False
    return any(w in name_lower for w in ["pay", "money", "cash", "wallet", "pesa"])


def _field_flags(fields: list[str]) -> dict:
    fl = [f.lower() for f in fields]
    fj = " ".join(fl)
    req = [f.lower() for f in fields if "optional" not in f.lower()]

    return {
        "iban": any("iban" in f for f in fl),
        "swift": any("swift" in f or "bic" in f for f in fl),
        "branch": any("branch" in f for f in fl),
        "qr": any("qr" in f for f in fl),
        "phone": any("phone" in f or "mobile" in f for f in fl),
        "account": any("account" in f for f in fl),
        "bank_account": any("bank account" in f for f in fl),
        "email": any("email" in f for f in fl),
        "email_required": any("email" in f for f in req),
        "account_required": any("account" in f for f in req),
        "id_doc": any(k in fj for k in ["id number", "document", "cpf", "cuit", "dni", "identification", "identity"]),
        "wallet": any("wallet" in f for f in fl),
        "payment_details": any("payment details" in f for f in fl),
        "card": any("card number" in f for f in fl),
        "sort_code": any("sort code" in f for f in fl),
        "cashtag": any("cashtag" in f or "$cashtag" in f for f in fl),
        "username": any("username" in f for f in fl),
        "clabe": any("clabe" in f for f in fl),
        "cbu": any("cbu" in f or "cvu" in f for f in fl),
        "institution": any("institution" in f for f in fl),
        "reference": any("reference" in f or "barcode" in f for f in fl),
        "user_id": any("user id" in f or "user identification" in f for f in fl),
    }


def pm_def(name: str, fields: list[str]) -> int:
    """
    Classify a payment method by name and its required user-facing fields.

    Returns:
        1 = Bank, 2 = E-wallet, 3 = Cash/P2P, 4 = Fintech, 5 = Instant system
    """
    nl = name.lower().strip()
    n_fields = len(fields)
    f = _field_flags(fields)
    bank = _is_bank_like(nl)
    pay = _is_pay_name(nl)
    email_opt = f["email"] and not f["email_required"]

    # ── 1. Exact-name lookups (highest confidence) ──────────────────────
    if nl in _TYPE5:
        return 5
    if nl in _CASH:
        return 3
    if nl in _FINTECH:
        return 4
    if nl in _EWALLET:
        return 2
    if nl in _P2P:
        return 3
    if nl in _LATAM_WALLET:
        return 3

    # ── 2. Name-pattern + field guards ──────────────────────────────────
    if f["reference"] and not bank:
        return 3

    # "Pay/Money/Cash" in name + phone/wallet/qr/user-id/few-fields → e-wallet
    if pay and (f["phone"] or f["wallet"] or f["qr"] or f["user_id"] or n_fields <= 2):
        return 2
    # Parenthesized bank name (e.g. "Konnect (HBL)") + phone → mobile wallet of bank
    if "(" in name and f["phone"] and not bank:
        return 2

    # Wallet field without bank name → e-wallet
    if f["wallet"] and not bank:
        return 2

    # Cashtag / username → fintech
    if f["cashtag"] or f["username"]:
        return 4
    # User-ID field → fintech
    if f["user_id"]:
        return 4

    # ── 3. Field-structure heuristics ───────────────────────────────────

    # Account required + email optional (not pay-named) → bank
    if f["account_required"] and email_opt and not pay:
        return 1

    # SWIFT + IBAN → international bank
    if f["swift"] and f["iban"]:
        return 1
    # Sort code → UK bank
    if f["sort_code"]:
        return 1
    # Institution number → Canadian bank
    if f["institution"]:
        return 1
    # CLABE → Mexican bank
    if f["clabe"]:
        return 1

    # Email required, no required account, not bank-like → fintech
    if f["email_required"] and not f["account_required"] and not bank and not f["id_doc"]:
        return 4

    # QR + Phone, no bank account, not bank → mobile wallet
    if f["qr"] and f["phone"] and not f["bank_account"] and not bank:
        return 2
    # Phone-only (≤2 fields, no account) → mobile wallet
    if f["phone"] and not f["account"] and not f["iban"] and n_fields <= 2 and not bank:
        return 2

    # IBAN + branch → traditional bank
    if f["iban"] and f["branch"]:
        return 1
    # IBAN only (no phone) → bank
    if f["iban"] and not f["phone"]:
        return 1

    # Bank-like name → bank
    if bank:
        return 1

    # Account + branch → bank
    if f["account"] and f["branch"]:
        return 1
    # Account + ID document → bank (LatAm verification pattern)
    if f["account"] and f["id_doc"]:
        return 1
    # Account + payment details → bank (CIS pattern)
    if f["account"] and f["payment_details"]:
        return 1

    # CBU/CVU → Argentine transfer
    if f["cbu"]:
        return 3
    # Card number → card-based transfer
    if f["card"]:
        return 3

    # Account + required email (no bank name) → fintech
    if f["account"] and f["email_required"] and not bank:
        return 4

    # Plain account (≤2 fields) → bank-like default
    if f["account"] and n_fields <= 2:
        return 1

    # QR → e-wallet
    if f["qr"]:
        return 2
    # Phone + few fields → mobile payment
    if f["phone"] and n_fields <= 3:
        return 2

    # Generic payment details → alternative
    if f["payment_details"] and n_fields <= 2:
        return 3

    return 3  # fallback


class PmEx(BaseModel):
    exid: int = Field(alias="id")
    name: str
    # nameCn: str
    logo: str = Field(alias="icon")
    config: List[PaymentConfig]
    typ: PmType = None

    @model_validator(mode="after")
    def type_set(self) -> Self:
        mexc_type = Typ(pm_def(self.name, [c.title for c in self.config]))
        self.typ = {
            Typ.Bank: PmType.bank_acc,
            Typ.Mobile: PmType.emoney,
            Typ.Cash: PmType.cash,
            Typ.Fintech: PmType.card,
            Typ.National: PmType.local,
        }[mexc_type]
        return self
