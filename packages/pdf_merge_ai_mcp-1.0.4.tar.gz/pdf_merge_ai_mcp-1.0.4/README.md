[![pdf-merge-ai-mcp MCP server](https://glama.ai/mcp/servers/CSOAI-ORG/pdf-merge-ai-mcp/badges/card.svg)](https://glama.ai/mcp/servers/CSOAI-ORG/pdf-merge-ai-mcp)

<div align="center">

[![GitHub stars](https://img.shields.io/github/stars/CSOAI-ORG/pdf-merge-ai-mcp)](https://github.com/CSOAI-ORG/pdf-merge-ai-mcp/stargazers)

# updfU mergeU aiU mcp

**PDF analysis, merge planning, split planning, and metadata extraction. — MEOK AI Labs.**

[![npm version](https://img.shields.io/npm/v/@meok-ai/pdf-merge-ai-mcp)](https://www.npmjs.com/package/@meok-ai/pdf-merge-ai-mcp)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![MEOK AI Labs](https://img.shields.io/badge/MEOK_AI_Labs-255+_servers-purple)](https://meok.ai)

[Installation](#installation) · [Docs](https://csoai.org) · [Report Bug](https://github.com/CSOAI-ORG/pdf-merge-ai-mcp/issues)

</div>

---

## Installation

```bash
pip install pdf-merge-ai-mcp
# or
npm install -g @meok-ai/pdf-merge-ai-mcp
```

## Quick Start

See the project repository for full documentation and examples.

## Enterprise Support

- 📧 nicholas@csoai.org
- 🌐 [CSOAI.org](https://csoai.org)

## License

MIT © [CSOAI](https://csoai.org)
<!-- mcp-name: io.github.CSOAI-ORG/pdf-merge-ai-mcp -->
