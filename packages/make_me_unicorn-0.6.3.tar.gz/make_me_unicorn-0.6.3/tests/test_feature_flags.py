"""Tests for feature flag config and conditional blueprint scanning."""

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from mmu_cli.cli import FEATURE_FLAG_DEFAULTS, load_feature_flags, _generate_stack_config  # noqa: E402
from mmu_cli.display import scan_blueprint, scan_all_blueprints  # noqa: E402


class FeatureFlagLoadingTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def write(self, rel: str, content: str) -> None:
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_defaults_all_true(self):
        """Without config file, all flags should default to True."""
        flags = load_feature_flags(self.root)
        self.assertEqual(flags, FEATURE_FLAG_DEFAULTS)
        for v in flags.values():
            self.assertTrue(v)

    def test_load_config_overrides(self):
        """Config file should override specific flags."""
        self.write(".mmu/config.toml", """
[features]
billing = false
i18n = false

[architecture]
containerized = false

[market]
targets_eu = false
""")
        flags = load_feature_flags(self.root)
        self.assertFalse(flags["has_billing"])
        self.assertFalse(flags["has_i18n"])
        self.assertFalse(flags["uses_containers"])
        self.assertFalse(flags["targets_eu"])
        # Unset flags remain True
        self.assertTrue(flags["has_mfa"])
        self.assertTrue(flags["has_file_upload"])

    def test_invalid_config_returns_defaults(self):
        """Malformed TOML should fall back to defaults."""
        self.write(".mmu/config.toml", "this is not valid toml {{{}}")
        flags = load_feature_flags(self.root)
        self.assertEqual(flags, FEATURE_FLAG_DEFAULTS)


class ConditionalScanningTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def write(self, rel: str, content: str) -> None:
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_no_flags_counts_all(self):
        """Without flags, all items should be counted."""
        self.write("test.md", """
<!-- if:has_billing -->
## Billing
- [ ] Item A
- [ ] Item B
<!-- endif -->
## Always
- [ ] Item C
""")
        done, total, skipped = scan_blueprint(self.root / "test.md", None)
        self.assertEqual(total, 3)
        self.assertEqual(skipped, 0)

    def test_flag_false_skips_section(self):
        """Items in a false-flag section should be skipped."""
        self.write("test.md", """
<!-- if:has_billing -->
## Billing
- [ ] Item A
- [x] Item B
<!-- endif -->
## Always
- [ ] Item C
""")
        flags = {"has_billing": False}
        done, total, skipped = scan_blueprint(self.root / "test.md", flags)
        self.assertEqual(total, 1)  # Only Item C
        self.assertEqual(done, 0)
        self.assertEqual(skipped, 2)  # Item A and B

    def test_flag_true_counts_section(self):
        """Items in a true-flag section should be counted normally."""
        self.write("test.md", """
<!-- if:has_billing -->
## Billing
- [ ] Item A
- [x] Item B
<!-- endif -->
## Always
- [ ] Item C
""")
        flags = {"has_billing": True}
        done, total, skipped = scan_blueprint(self.root / "test.md", flags)
        self.assertEqual(total, 3)
        self.assertEqual(done, 1)
        self.assertEqual(skipped, 0)

    def test_multiple_conditions(self):
        """Multiple conditional sections should work independently."""
        self.write("test.md", """
<!-- if:has_billing -->
- [ ] Billing item
<!-- endif -->
<!-- if:has_i18n -->
- [ ] i18n item
<!-- endif -->
- [ ] Always item
""")
        flags = {"has_billing": False, "has_i18n": True}
        done, total, skipped = scan_blueprint(self.root / "test.md", flags)
        self.assertEqual(total, 2)  # i18n + always
        self.assertEqual(skipped, 1)  # billing

    def test_unknown_flag_defaults_true(self):
        """Unknown flag names in markers should default to True."""
        self.write("test.md", """
<!-- if:unknown_future_flag -->
- [ ] Future item
<!-- endif -->
""")
        flags = {}
        done, total, skipped = scan_blueprint(self.root / "test.md", flags)
        self.assertEqual(total, 1)
        self.assertEqual(skipped, 0)


class ConfigGenerationTest(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_generates_valid_toml(self):
        """Generated config should be parseable by our simple parser."""
        from mmu_cli.cli import _parse_simple_toml
        content = _generate_stack_config(self.root)
        data = _parse_simple_toml(content)
        self.assertIn("features", data)
        self.assertIn("architecture", data)
        self.assertIn("market", data)

    def test_detects_dockerfile(self):
        """Should detect Docker when Dockerfile exists."""
        (self.root / "Dockerfile").write_text("FROM node:20\n")
        content = _generate_stack_config(self.root)
        self.assertIn("containerized = true", content)

    def test_no_dockerfile_defaults_false(self):
        """Without Dockerfile, containerized should be false."""
        content = _generate_stack_config(self.root)
        self.assertIn("containerized = false", content)


class AutoCheckConditionTest(unittest.TestCase):
    """Test that run_scan respects condition markers (false-pass prevention)."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def write(self, rel: str, content: str) -> None:
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_scan_skips_disabled_block_items(self):
        """Auto-check should NOT mark items inside disabled condition blocks."""
        from mmu_cli.scan import run_scan

        # Create a blueprint with a conditional billing section
        self.write("docs/blueprints/14-analytics.md", """
## Analytics Strategy
- [ ] Choose analytics platform (PostHog, Mixpanel, or Amplitude).
<!-- if:has_billing -->
## Business Metrics
- [ ] Track Monthly Recurring Revenue (MRR).
<!-- endif -->
""")
        # Create package.json with posthog to trigger scan rule
        self.write("package.json", '{"dependencies": {"posthog-js": "^1.0.0"}}')

        flags = {"has_billing": False}
        run_scan(self.root, flags)

        # Read the blueprint back
        text = (self.root / "docs" / "blueprints" / "14-analytics.md").read_text()
        # The "analytics platform" item should be auto-checked (active section)
        self.assertIn("[x]", text.split("Analytics Strategy")[1].split("if:has_billing")[0])
        # The "MRR" item should NOT be auto-checked (disabled section)
        self.assertIn("[ ] Track Monthly Recurring Revenue", text)

    def test_scan_checks_enabled_block_items(self):
        """Auto-check SHOULD mark items inside enabled condition blocks."""
        from mmu_cli.scan import run_scan

        self.write("docs/blueprints/14-analytics.md", """
<!-- if:has_billing -->
## Business Metrics
- [ ] Track Monthly Recurring Revenue (MRR).
<!-- endif -->
## Analytics Strategy
- [ ] Choose analytics platform (PostHog, Mixpanel, or Amplitude).
""")
        self.write("package.json", '{"dependencies": {"posthog-js": "^1.0.0"}}')

        flags = {"has_billing": True}
        run_scan(self.root, flags)

        text = (self.root / "docs" / "blueprints" / "14-analytics.md").read_text()
        # Both items should be eligible for auto-check
        self.assertIn("[x]", text)

    def test_scan_without_flags_checks_all(self):
        """Without flags, all items should be eligible for auto-check."""
        from mmu_cli.scan import run_scan

        self.write("docs/blueprints/14-analytics.md", """
<!-- if:has_billing -->
## Business Metrics
- [ ] Track Monthly Recurring Revenue (MRR).
<!-- endif -->
## Analytics Strategy
- [ ] Choose analytics platform (PostHog, Mixpanel, or Amplitude).
""")
        self.write("package.json", '{"dependencies": {"posthog-js": "^1.0.0"}}')

        run_scan(self.root, None)

        text = (self.root / "docs" / "blueprints" / "14-analytics.md").read_text()
        # Without flags, all items should be checkable
        self.assertIn("[x]", text)


class RealBlueprintScanTest(unittest.TestCase):
    """Test against actual blueprint files in the repo."""

    def test_billing_blueprint_skippable(self):
        """04-billing.md should be fully skippable."""
        bp = ROOT / "docs" / "blueprints" / "04-billing.md"
        if not bp.exists():
            self.skipTest("Blueprint not in working directory")

        _, total_on, _ = scan_blueprint(bp, {"has_billing": True})
        _, total_off, skipped = scan_blueprint(bp, {"has_billing": False})

        self.assertGreater(total_on, 0)
        self.assertEqual(total_off, 0)
        self.assertEqual(skipped, total_on)

    def test_full_scan_skip_count(self):
        """Minimal config should skip significant items from full scan."""
        bp_dir = ROOT / "docs" / "blueprints"
        if not bp_dir.exists():
            self.skipTest("Blueprints not in working directory")

        all_on = scan_all_blueprints(ROOT, None)
        total_on = sum(t for _, _, t, _ in all_on)

        conservative = {k: False for k in FEATURE_FLAG_DEFAULTS}
        all_off = scan_all_blueprints(ROOT, conservative)
        total_off = sum(t for _, _, t, _ in all_off)
        skipped_off = sum(s for _, _, _, s in all_off)

        self.assertGreater(skipped_off, 50, "Should skip at least 50 items with all flags off")
        self.assertLess(total_off, total_on, "Filtered total should be less than full total")


class ScoreBreakdownTest(unittest.TestCase):
    """Test mmu status --why score decomposition."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def write(self, rel: str, content: str) -> None:
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_breakdown_shows_composition(self):
        """Score breakdown should show applicable, checked, skipped counts."""
        from mmu_cli.display import render_score_breakdown

        self.write("docs/blueprints/01-frontend.md", """
## Frontend
- [x] Item A
- [ ] Item B
<!-- if:has_billing -->
- [ ] Billing item
<!-- endif -->
""")
        flags = {"has_billing": False}
        output = render_score_breakdown(self.root, flags)
        self.assertIn("SCORE BREAKDOWN", output)
        self.assertIn("Skipped", output)
        self.assertIn("has_billing", output)

    def test_breakdown_all_enabled(self):
        """With all flags enabled, no disabled flags should appear."""
        from mmu_cli.display import render_score_breakdown

        self.write("docs/blueprints/01-frontend.md", """
## Frontend
- [x] Item A
- [ ] Item B
""")
        output = render_score_breakdown(self.root, None)
        self.assertIn("All feature flags enabled", output)


class NextActionsTest(unittest.TestCase):
    """Test mmu next command."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def write(self, rel: str, content: str) -> None:
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_recommends_unchecked_items(self):
        """Should recommend unchecked items sorted by priority."""
        from mmu_cli.display import render_next_actions

        self.write("docs/blueprints/01-frontend.md", """
## Frontend
- [ ] [P0] Critical item
- [ ] [P1] Important item
- [ ] Regular item
- [x] Done item
""")
        output = render_next_actions(self.root, None, count=3)
        self.assertIn("NEXT ACTIONS", output)
        self.assertIn("Critical item", output)
        self.assertIn("Important item", output)
        # Should not include done items
        self.assertNotIn("Done item", output)

    def test_respects_flags(self):
        """Should not recommend items in disabled sections."""
        from mmu_cli.display import render_next_actions

        self.write("docs/blueprints/01-frontend.md", """
<!-- if:has_billing -->
- [ ] Billing item
<!-- endif -->
- [ ] Always item
""")
        flags = {"has_billing": False}
        output = render_next_actions(self.root, flags, count=3)
        self.assertNotIn("Billing item", output)
        self.assertIn("Always item", output)

    def test_empty_when_all_done(self):
        """Should show done message when all items are checked."""
        from mmu_cli.display import render_next_actions

        self.write("docs/blueprints/01-frontend.md", """
## Frontend
- [x] Done item
""")
        output = render_next_actions(self.root, None, count=3)
        self.assertIn("done", output.lower())

    def test_priority_parsing_preserves_brackets(self):
        """[P0]/[P1] tags should be parsed correctly, not mangled by lstrip."""
        from mmu_cli.display import render_next_actions

        self.write("docs/blueprints/01-frontend.md", """
## Frontend
- [ ] [P0] Critical security fix
- [ ] [P1] Important performance item
- [ ] Regular item
""")
        output = render_next_actions(self.root, None, count=3)
        # P0 should render with red/bold, not show "P0]" or "P1]"
        self.assertNotIn("P0]", output)
        self.assertNotIn("P1]", output)
        self.assertIn("Critical security fix", output)
        self.assertIn("Important performance item", output)

    def test_negative_count_defaults_to_3(self):
        """next -n 0 or negative should default to 3, not show done."""
        from mmu_cli.display import render_next_actions

        self.write("docs/blueprints/01-frontend.md", """
## Frontend
- [ ] Item A
- [ ] Item B
""")
        output = render_next_actions(self.root, None, count=0)
        self.assertIn("Item A", output)
        self.assertNotIn("done", output.lower())

    def test_diversity_cap(self):
        """Recommendations should not all come from one blueprint."""
        from mmu_cli.display import render_next_actions

        self.write("docs/blueprints/01-frontend.md", """
## Frontend
- [ ] Frontend item 1
- [ ] Frontend item 2
- [ ] Frontend item 3
- [ ] Frontend item 4
""")
        self.write("docs/blueprints/02-backend.md", """
## Backend
- [ ] Backend item 1
- [ ] Backend item 2
""")
        output = render_next_actions(self.root, None, count=4)
        # Should include backend items (not just 4 frontend)
        self.assertIn("Backend item", output)
        # Frontend should be capped at 2
        self.assertNotIn("Frontend item 3", output)


class CheckConditionAwareTest(unittest.TestCase):
    """Test that mmu check uses condition-aware item numbering."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def write(self, rel: str, content: str) -> None:
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_check_skips_hidden_items(self):
        """check #1 should target first visible item, not hidden one."""
        from mmu_cli.cli import command_check

        self.write("docs/blueprints/01-frontend.md", """
<!-- if:has_billing -->
- [ ] Hidden billing item
<!-- endif -->
- [ ] Visible item A
- [ ] Visible item B
""")
        self.write(".mmu/config.toml", """
[features]
billing = false
""")
        result = command_check("frontend", 1, self.root, force_state="check")
        self.assertEqual(result.exit_code, 0)

        text = (self.root / "docs" / "blueprints" / "01-frontend.md").read_text()
        # Hidden item should NOT be checked
        self.assertIn("[ ] Hidden billing item", text)
        # Visible item A (#1) should be checked
        self.assertIn("[x] Visible item A", text)


class BreakdownWarningTest(unittest.TestCase):
    """Test --why warning when flags are set but no markers exist."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def write(self, rel: str, content: str) -> None:
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_warns_when_flags_disabled_but_no_skips(self):
        """Should warn if flags are disabled but no items were skipped."""
        from mmu_cli.display import render_score_breakdown

        # Blueprint WITHOUT condition markers
        self.write("docs/blueprints/01-frontend.md", """
## Frontend
- [ ] Item A
- [ ] Item B
""")
        flags = {"has_billing": False, "has_mfa": False}
        output = render_score_breakdown(self.root, flags)
        self.assertIn("no items were skipped", output)
        self.assertIn("mmu init --force", output)


class ShareCardTest(unittest.TestCase):
    """Test mmu share card generation."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def write(self, rel: str, content: str) -> None:
        path = self.root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")

    def test_card_contains_border(self):
        """Card should have top and bottom box-drawing borders."""
        from mmu_cli.display import render_share_card

        self.write("docs/checklists/from_scratch.md", """
## M0 Problem Fit
- [x] Validate problem
- [x] Interview users
## M1 Build Fit
- [ ] Ship MVP
""")
        card = render_share_card(self.root, None)
        self.assertTrue(card.startswith("┌"))
        self.assertIn("┘", card)
        from mmu_cli.display import REPO_URL
        self.assertIn(REPO_URL.replace("https://", ""), card)

    def test_card_contains_score_and_stage(self):
        """Card should display score percentage and stage name."""
        from mmu_cli.display import render_share_card

        self.write("docs/checklists/from_scratch.md", """
## M0 Problem Fit
- [x] Item A
- [x] Item B
## M1 Build Fit
- [x] Item C
- [ ] Item D
""")
        card = render_share_card(self.root, None)
        self.assertIn("Score:", card)
        self.assertIn("Stage:", card)
        self.assertIn("%", card)

    def test_card_contains_gates(self):
        """Card should list gate stages with PASS/OPEN status."""
        from mmu_cli.display import render_share_card

        self.write("docs/checklists/from_scratch.md", """
## M0 Problem Fit
- [x] Done
## M1 Build Fit
- [ ] Open
""")
        card = render_share_card(self.root, None)
        self.assertIn("PASS", card)
        self.assertIn("OPEN", card)
        self.assertIn("M0", card)
        self.assertIn("M1", card)

    def test_card_contains_hashtag(self):
        """Card should contain branding elements."""
        from mmu_cli.display import render_share_card
        card = render_share_card(self.root, None)
        self.assertIn("#MakeMeUnicorn", card)
        self.assertIn("pip install make-me-unicorn", card)

    def test_card_no_ansi_codes(self):
        """Share card must be plain text — no ANSI escape sequences."""
        from mmu_cli.display import render_share_card

        self.write("docs/checklists/from_scratch.md", """
## M0 Problem Fit
- [x] Done
""")
        card = render_share_card(self.root, None)
        self.assertNotIn("\033[", card)

    def test_card_with_stack_config(self):
        """Stack line should appear when config has architecture info."""
        from mmu_cli.display import render_share_card

        cfg = {"architecture": {"framework": "Next.js"}, "features": {"billing": True}}
        card = render_share_card(self.root, None, cfg)
        self.assertIn("Stack:", card)
        self.assertIn("Next.js", card)

    def test_card_without_stack_config(self):
        """No Stack line when config is empty."""
        from mmu_cli.display import render_share_card

        card = render_share_card(self.root, None, None)
        self.assertNotIn("Stack:", card)


class ShareClipboardTest(unittest.TestCase):
    """Test mmu share --clipboard integration."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def test_command_share_returns_card(self):
        """command_share should return card text in messages."""
        from mmu_cli.cli import command_share
        result = command_share(self.root, clipboard=False)
        self.assertEqual(result.exit_code, 0)
        self.assertTrue(len(result["messages"]) >= 1)
        self.assertIn("#MakeMeUnicorn", result["messages"][0])

    def test_command_share_clipboard_appends_message(self):
        """--clipboard should add a clipboard status message."""
        from unittest.mock import patch
        from mmu_cli.cli import command_share

        with patch("mmu_cli.cli.try_copy_clipboard", return_value=(True, "bundle copied to clipboard")):
            result = command_share(self.root, clipboard=True)
        self.assertEqual(result.exit_code, 0)
        self.assertTrue(any("clipboard" in m for m in result["messages"]))

    def test_command_share_clipboard_failure(self):
        """Clipboard failure should still succeed with error message."""
        from unittest.mock import patch
        from mmu_cli.cli import command_share

        with patch("mmu_cli.cli.try_copy_clipboard", return_value=(False, "clipboard copy is only supported on macOS for now")):
            result = command_share(self.root, clipboard=True)
        self.assertEqual(result.exit_code, 0)
        self.assertTrue(any("macOS" in m for m in result["messages"]))


class BadgeTest(unittest.TestCase):
    """Test mmu badge command and badge rendering."""

    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        self.tmp.cleanup()

    def write(self, rel: str, content: str) -> None:
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")

    def test_badge_markdown_contains_shields_url(self):
        """Markdown badge should reference shields.io."""
        from mmu_cli.display import render_badge_markdown
        md = render_badge_markdown(75, "young unicorn", "MyApp")
        self.assertIn("img.shields.io", md)
        self.assertIn("make-me-unicorn", md)
        self.assertIn("MyApp", md)

    def test_badge_svg_valid_xml(self):
        """SVG badge should be valid XML-ish."""
        from mmu_cli.display import render_badge_svg
        svg = render_badge_svg(42, "foal")
        self.assertIn("<svg", svg)
        self.assertIn("</svg>", svg)
        self.assertIn("42%", svg)
        self.assertIn("foal", svg)

    def test_badge_html_contains_link(self):
        """HTML badge should contain clickable link."""
        from mmu_cli.display import render_badge_html
        html = render_badge_html(90, "unicorn")
        self.assertIn("<a href=", html)
        self.assertIn("make-me-unicorn", html)
        self.assertIn("<img", html)

    def test_command_badge_markdown(self):
        """command_badge should return markdown by default."""
        from mmu_cli.cli import command_badge
        result = command_badge(self.root, fmt="markdown")
        self.assertEqual(result.exit_code, 0)
        self.assertIn("img.shields.io", result["messages"][0])

    def test_command_badge_svg(self):
        """command_badge with svg format should return SVG."""
        from mmu_cli.cli import command_badge
        result = command_badge(self.root, fmt="svg")
        self.assertEqual(result.exit_code, 0)
        self.assertIn("<svg", result["messages"][0])

    def test_command_badge_output_file(self):
        """command_badge with --output should write file."""
        from mmu_cli.cli import command_badge
        out_path = str(self.root / "badge.md")
        result = command_badge(self.root, fmt="markdown", output=out_path)
        self.assertEqual(result.exit_code, 0)
        self.assertTrue(Path(out_path).is_file())
        content = Path(out_path).read_text()
        self.assertIn("img.shields.io", content)

    def test_badge_stage_colors(self):
        """Each stage should map to a specific color."""
        from mmu_cli.display import STAGE_COLORS
        self.assertIn("egg", STAGE_COLORS)
        self.assertIn("legendary", STAGE_COLORS)
        self.assertEqual(len(STAGE_COLORS), 6)


if __name__ == "__main__":
    unittest.main()
