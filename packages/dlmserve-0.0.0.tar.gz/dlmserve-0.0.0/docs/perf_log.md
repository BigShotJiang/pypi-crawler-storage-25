# Performance Log

Record every benchmark run here with date, hardware, model config, and results.
This file is committed so we can `git diff` perf regressions over time.

---

## Phase 0 baseline (target: measure after model loads successfully)

Hardware: RTX 5070 (12 GB, SM 12.0)
Model: LLaDA-8B-Instruct FP8, batch=4, seq=2048

*Pending Phase 0 gate: LLaDA-8B loads without OOM at target config.*
*Run `torch.cuda.memory_summary()` after first successful load; record here.*

| Component | Measured | Target (plan §3.2) |
|---|---|---|
| Weights (FP8) | — | 8.0 GB |
| Activations | — | 1.2 GB |
| KV (committed) | — | 1.0 GB |
| KV (pending scratch) | — | 0.4 GB |
| CUDA workspace | — | 0.3 GB |
| PyTorch overhead | — | 0.5 GB |
| Safety margin | — | 0.6 GB |
| **Total** | — | **~12.0 GB** |
