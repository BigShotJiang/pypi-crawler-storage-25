# dlmserve

**The first OSS production-grade serving engine for diffusion language models.**

> Coming soon. Diffusion LLM serving engine — LLaDA, DiffuLLaMA, and more.

---

Diffusion language models (LLaDA, DiffuLLaMA, Mercury Coder) are architecturally
distinct from autoregressive transformers. They need their own scheduler, KV cache
semantics, batching strategy, and sampling logic. dlmserve is the missing piece.

- Bidirectional attention, not causal
- Denoising-step-aware continuous batching
- Committed/pending KV cache split
- OpenAI-compatible HTTP API

## Status

Pre-alpha. Not ready for use. Watch this space.

## License

MIT
