"""Throughput benchmark — tokens/sec at various batch sizes and dtypes."""
