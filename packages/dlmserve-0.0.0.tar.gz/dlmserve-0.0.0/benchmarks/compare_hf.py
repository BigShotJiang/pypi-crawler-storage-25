"""Compare dlmserve output vs the LLaDA reference HF inference loop."""
