"""Tests for DiffusionKVCache committed/pending split."""
