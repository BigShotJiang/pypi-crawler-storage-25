"""Tests for the denoising loop and sampler.

Phase 1 gate: sampled tokens must match LLaDA reference at seed=0,
temperature=0, top_k=1 on 5 fixed prompts. See plan §7 Phase 1 → 2.
"""
