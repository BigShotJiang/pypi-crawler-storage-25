"""Tests for DiffusionScheduler.

Use DiffuLLaMA-1.3B (real model, no mocks) per plan §22 anti-pattern #12.
Mark slow/GPU tests with @pytest.mark.slow and @pytest.mark.gpu.
"""
