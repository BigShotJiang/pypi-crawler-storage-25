# diffuserve — First OSS Serving Stack for Diffusion Language Models

> Working name. Rename freely. Other options: `denoist`, `dlm-engine`, `bidir`, `parallax`.

---

## 0. How to read this plan

- This document is the design spec for a new OSS project. Treat it as a contract for v0.1.
- Sections tagged **[OPUS-REQUIRED]** are places where Sonnet should stop and prompt the user to swap to Opus before producing code. Sonnet should explicitly say: *"This step is flagged [OPUS-REQUIRED] in plan.md. Please run /model and pick Opus 4.7 before I continue."*
- Sections tagged **[SONNET-OK]** are safe for Sonnet to execute directly.
- Sections tagged **[RESEARCH-FIRST]** require reading a specific paper or repo before writing code; Sonnet should do the reading and summarize back to the user, not improvise.

---

## 1. Mission

Be to **diffusion LLMs** what vLLM is to autoregressive LLMs: the de-facto open-source serving engine. Diffusion language models (LLaDA, BD3-LMs, DiffuLLaMA, Mercury Coder) are architecturally distinct from autoregressive transformers — they need their own scheduler, KV cache semantics, batching strategy, and sampling logic. As of May 2026, **no production-grade OSS engine exists for them**. Multiple 2026 research papers each ship their own toy inference loop. The opening is to be the first credible unified engine.

### Aspiration / north star

**Three explicit milestones** — because the user is driving Sonnet against published references, not coding by hand, the calendar collapses by ~5× vs naive estimates:

- **MVP-for-traction (3-5 weeks)**: rough but working end-to-end. LLaDA-8B loads on RTX 5070, single-request generation matches reference, **continuous batching at ≥2× single-request throughput**, OpenAI-compatible HTTP server, public GitHub repo with demo. Goal: **claim the niche publicly**, get on HN, get cited in 1-2 diffusion-LLM repos, accumulate early users / contributors. **NOT production-grade**. Bugs are fine if the demo lands.
- **v0.1 hardening (8-12 weeks total)**: 50-prompt regression suite green, quality metrics within thresholds, real observability, graceful shutdown, two acceleration techniques landed. Used by a handful of external testers.
- **v0.5 (6-9 months)**: 3+ models, beats Mercury Coder published numbers, talks pitched at MLSys / ASPLOS.
- **v1.0 (12-18 months)**: de-facto OSS engine. Cited.

**Repo visibility strategy**:

- **Day 1**: `git init` locally only. No GitHub repo yet. Register the domain (`dlmserve.dev` or `.ai`) + reserve the PyPI name (publish a stub `0.0.0` — prevents squatting). No code on GitHub until MVP.
- **MVP complete**: audit every file — zero placeholder stubs, zero internal dev notes in code. Then: first commit, create GitHub repo private, push.
- **Phase 5 launch day**: flip repo public, real launch (HN, r/LocalLLaMA, etc.)

Why defer GitHub to MVP: a repo with stub files and placeholder comments looks worse than no repo. Claim the namespace (domain + PyPI) immediately; push code only when it's real.

---

## 2. Why now (state of the field, May 2026)

**Open diffusion language models exist:**
- `gsai-ml/LLaDA-8B-Instruct` and `LLaDA-8B-Base` — Renmin University, open weights, ~8B params, MIT license.
- `kuleshov-group/bd3lms` (Block Diffusion BD3-LMs) — Cornell, open.
- `HKUNLP/DiffuLLaMA` — Hong Kong U, open, smaller variants exist.
- LLaDA-V (Ant Group) — vision-language extension.

**Commercial proof point:**
- Inception Labs **Mercury Coder** — closed-source, ships at ~6× autoregressive speedup, raised real funding. Validates architecture at production scale.

**Research is exploding (verified via `gh search repos`, May 2026):**
- AdaBlock-dLLM (ICLR 2026) — adaptive block size
- Focus-dLLM — confidence-guided context focusing for long context
- LocalLeap — local determinism propagation
- Mosaic (May 23 2026) — global memory planning for 30× context length
- TIDE (May 23 2026) — I/O-aware expert offload for MoE diffusion
- LLaDA-1.5, LLaDA-V, and Dream-7B in the same family
- `YannnnnnY/Awesome-Diffusion-LLM-Inference` curated list tracks ~30 papers

**Critical observation:** every paper ships its own from-scratch inference loop based on the LLaDA reference. None integrate with vLLM/SGLang because the architectural assumptions (causal mask, sequential KV growth, one-token decode) are wrong for diffusion. The unified engine is the missing piece.

---

## 3. Hardware: RTX 5070 (12 GB, SM 12.0 Blackwell consumer)

### What fits

| Model | FP16 | FP8 | INT4 | Notes |
|---|---|---|---|---|
| LLaDA-8B-Instruct | 16 GB (NO) | 8 GB (TIGHT) | 5 GB (OK) | Primary target. INT4 for dev, FP8 for benchmarks. |
| LLaDA-1.5 | same | same | same | Same param count. |
| BD3-LMs | varies | — | — | Smaller variants available. |
| DiffuLLaMA-1.3B | 2.6 GB | 1.3 GB | 0.7 GB | Easy fit — use for unit-test models. |
| Dream-7B | 14 GB | 7 GB | 3.5 GB | Borderline FP16, easy FP8/INT4. |

### What you cannot test on a 5070

- Multi-GPU tensor parallelism (need a 2nd GPU)
- Long-context >32K with FP16 LLaDA-8B (KV-equivalent doesn't fit)
- MoE diffusion at full scale (TIDE-style offload requires NVMe + multi-GPU realistic testing)

### CI strategy

- Local: INT4 LLaDA-8B + FP16 DiffuLLaMA-1.3B for correctness + smoke benchmarks.
- Cloud: rent H100 80GB hourly for: FP16 LLaDA-8B reference, multi-GPU TP, long-context (≥128K) benchmarks, cross-hardware perf comparisons, soak tests. Budget **~$500-1000** across v0.1 development (revised up from $200-400 — initial estimate was too tight once cross-arch + soak time is counted). Vast.ai / RunPod.
- CI runner: the RTX 5070 dev box **cannot also serve as the CI runner** without crippling dev velocity. Two viable options: (1) **ephemeral cloud CI on each PR** (~$0.50 per perf run × ~100 PRs in v0.1 ≈ $50 — cheap), or (2) **self-hosted runner on a second machine**. Default to (1).

### SM 12.0 considerations

- Blackwell consumer shares SM 12.0 with B200 datacenter — same FP4/FP8 tensor cores, TMEM, distributed shared memory.
- Most kernel libraries (FlashInfer, FlashAttention) target SM 80/90/100 first; SM 120 is uncharted.
- For v0.1 use PyTorch + FlashAttention-2 (supported on SM 12.0). Custom kernels deferred to v0.3+.

### 3.1 Compatibility matrix (v0.1)

| Axis | Supported | Not supported in v0.1 |
|---|---|---|
| Python | 3.11, 3.12 | 3.10 (drop — `Self` typing), 3.13 (untested) |
| OS | Linux x86_64 | macOS, Windows |
| CUDA | 12.4+ | ROCm, CPU-only, Metal |
| PyTorch | 2.5+ | 2.4 and below (BF16 KV layout issues), 2.6 nightly |
| GPU arch | SM 8.0+ (A100), SM 9.0 (H100), SM 12.0 (RTX 50xx, B200) | SM 7.0/7.5 (V100/T4 — no FP8) |
| dtypes (weights) | FP16/BF16 on SM 8.0+; **FP8 (E4M3) requires SM 9.0+ (H100, B200, RTX 50xx)**; INT4 (HF-pre-quantized only) on SM 8.0+ | FP4, custom quant |
| Models | LLaDA-8B (-Instruct, -Base, -1.5), DiffuLLaMA-1.3B/7B | BD3-LMs (v0.2), LLaDA-V (v0.6), SEDD/Plaid (never) |
| Distributed | Single-process, single-GPU | TP, PP, DP — all deferred |

Pin in `pyproject.toml`. Reject incompatible configs at startup with a clear error.

### 3.2 Memory budget — RTX 5070 12GB target (LLaDA-8B FP8, batch 4, seq 2048)

This must add up to < 12 GB or the dev target is wrong. Numbers below are estimates; Phase 0 must verify with `torch.cuda.memory_summary()` and update this table.

| Component | Estimate | Notes |
|---|---|---|
| Model weights (LLaDA-8B FP8) | 8.0 GB | Largest single chunk. |
| Activations (forward, batch 4, seq 2048) | 1.2 GB | Bidirectional attention: O(B × L² × num_heads × head_dim / num_heads) per layer ≈ 1.0 GB peak intermediate; rest is FFN. |
| Committed KV (batch 4, seq 2048, FP16) | 1.0 GB | 32 layers × 2048 × 32 heads × 128 head_dim × 2 (K+V) × 2 (fp16 bytes) × 4 (batch). |
| Pending KV scratch | 0.4 GB | Smaller — overwrites per step. |
| CUDA workspace (cuBLAS, FlashAttn) | 0.3 GB | |
| PyTorch overhead, kernel cache | 0.5 GB | |
| Safety margin (OOM headroom) | 0.6 GB | Engine OOM = crashed serving = unacceptable. |
| **Total** | **~12.0 GB** | At the edge. Drop batch to 2 or seq to 1024 if Phase 0 measurements blow this. |

**If FP8 doesn't fit at the chosen batch/seq, fallback ladder**:
1. Drop batch to 2 → frees ~0.7 GB
2. Drop seq to 1024 → frees ~0.6 GB (KV scales with L)
3. INT4 quantization → frees ~4 GB on weights
4. Drop to LLaDA-1.5 with smaller hidden dim if available

**Sonnet must NOT silently downsize the dev target.** If LLaDA-8B FP8 batch 4 doesn't fit, surface it to user, do not change dtype/batch/seq quietly.

---

## 4. Architectural contrast: diffusion vs autoregressive

This is the *whole reason* the project exists. The autoregressive assumptions baked into vLLM/SGLang are wrong for diffusion:

| Property | Autoregressive (GPT/LLaMA) | Diffusion (LLaDA) | Engine implication |
|---|---|---|---|
| Attention mask | Causal (lower-triangular) | **None — bidirectional** | Different attention kernel; cannot reuse causal FlashAttention path. |
| Decode unit | 1 token / forward pass | **k tokens / step**, multiple steps | Scheduler must batch by `(step_idx, block_size)`, not just `(in_prefill, in_decode)`. |
| Steps per response | N tokens = N forwards | **fixed steps (4-32) × full-sequence forward** | Throughput dominated by step count, not output length. |
| KV cache growth | Append per token | **Mostly invalidated each step**; committed tokens stable | PagedAttention's append-only model is wrong. Need committed/pending split. |
| Token revelation | Sequential, left-to-right | **Confidence-ranked, any position** | Sampling kernel commits top-k confidence tokens, masks the rest. |
| Speculative decode | Draft model proposes tokens | **Block speculation: re-noise low-confidence blocks** | Different speculation strategy. |
| Continuous batching | Prefill + decode in same batch | **Same denoising step + same block size bucket** | Batching constraint is stricter — affects scheduler design. |
| Stopping | EOS token | **All blocks committed OR max steps** | Different completion semantics. |
| Streaming | Token-by-token | **Step-by-step (whole block at a time)** | Different streaming protocol; UX implication. |

### The fundamental insight to build the engine around

> A diffusion LLM serving request is not a sequence of decode steps — it is a sequence of **denoising rounds** where each round is a full bidirectional forward pass over a partially-committed sequence. Throughput optimization means **maximizing parallelism across requests at the same denoising round**, and **minimizing recomputation of committed token KV**.

That single sentence is the project's PagedAttention-equivalent thesis. Everything else follows from it.

**Why diffusion can win on raw FLOPs (the throughput thesis, derived)**:

- Autoregressive decode, generating L tokens with KV cache: each step does O(L·d) attention + O(d²) MLP. Total over L tokens: ~O(L²·d + L·d²).
- Diffusion, generating L tokens with S denoising steps: each step does O(L²·d) attention + O(L·d²) MLP. Total: ~O(S·L²·d + S·L·d²).
- Ratio (diffusion / AR) ≈ S·L·d / (L·d) = **S** for the attention term, and S for the MLP term scaled by L.
- For L=1000, d=4096, S=16: diffusion uses **~16/1000 = 1.6%** of the AR attention compute. MLP is similar order.
- **Conclusion**: diffusion is a FLOPs win whenever **S << L** (output length). Short outputs (S ≈ L) lose to AR. Long outputs (L=1000+, S=16) win 10-50×.

The serving engine's job is to make sure this theoretical win translates to wall-clock — which requires (a) batching across concurrent requests at the same step (since per-request parallelism is already maxed inside the model) and (b) avoiding the O(B·L²) attention memory blowup at high batch sizes.

### 4.1 Math contract for v0.1 — LLaDA absorb-and-resample (NON-NEGOTIABLE for v0.1)

Different diffusion LLMs use different math. v0.1 commits to **exactly one process** to avoid abstraction creep killing the MVP:

**v0.1 targets the LLaDA absorb-and-resample (discrete masked diffusion) process.** Specifically:

- **Forward (training) process**: each token independently masked with probability `t ∈ [0, 1]`.
- **Reverse (inference) process**: start from all-`[MASK]` (except prompt prefix which is fully committed), iteratively unmask. At denoising step `s ∈ {0, 1, ..., S-1}`:
  - Compute `t_s = 1 - (s / S)` and `t_{s+1} = 1 - ((s+1) / S)` (the noise schedule).
  - Forward bidirectional pass over the full sequence (prompt committed + body partially masked).
  - For each masked position, model predicts logits over vocab.
  - **Confidence rule**: confidence at position `i` = `top1_prob(i)` over the vocab distribution at that position (after softmax). Higher confidence = unmask first.
  - **Unmask quota at step s**: `n_unmask_s = round(L_masked * (t_s - t_{s+1}) / t_s)` — that is, the fraction of currently-masked tokens that get committed this step. This matches the LLaDA reference.
  - Pick the top `n_unmask_s` masked positions by confidence; commit them.
  - At the final step `s = S-1`, all remaining masked positions are forcibly committed (argmax).

**v0.1 does NOT support**:
- Block diffusion (BD3-LMs) — different math (block-autoregressive × within-block-diffusion). Defer to v0.2.
- Continuous diffusion (SEDD, Plaid) — different math entirely. Out of scope indefinitely.
- Self-conditioning / "x0 estimation" variants — defer.
- Classifier-free guidance — defer.

**Why this matters for the engine**: the absorb-and-resample contract pins down (a) what "committed" means (sampled token, will not change), (b) the unmask quota per step (determines block size dynamics), (c) the confidence metric (top1_prob — Opus must verify against LLaDA reference). Every other module makes correctness assumptions that depend on these specifics. Changing the process post-v0.1 is a major-version break, not a minor one.

**Reference**: LLaDA paper §3 ("Inference Procedure"), arXiv:2502.09992. Sonnet must read this section before writing `denoise_loop.py`.

---

## 5. MVP scope (v0.1) — file layout

Target: **15-18 files**, ~3-5 KLOC. Python + minimal CUDA/Triton. PyTorch backbone.

```
diffuserve/
├── README.md
├── pyproject.toml
├── diffuserve/
│   ├── __init__.py
│   ├── engine.py              # top-level orchestrator (vLLM's LLMEngine analog)
│   ├── scheduler.py           # denoising-step-aware continuous batching
│   ├── kv_cache.py            # committed/pending KV split
│   ├── denoise_loop.py        # core diffusion forward + commit logic
│   ├── sampler.py             # confidence-based top-k commitment
│   ├── models/
│   │   ├── __init__.py
│   │   └── llada.py           # LLaDA-8B loader + forward
│   │                          # NOTE: bd3lm.py deferred to v0.2 — do NOT create in v0.1
│   ├── attention.py           # bidirectional attention wrapper
│   ├── block_size.py          # adaptive block sizing (AdaBlock-dLLM)
│   ├── api/
│   │   ├── server.py          # FastAPI OpenAI-compatible
│   │   └── protocol.py        # request/response models
│   └── metrics.py             # Prometheus exporter
├── benchmarks/
│   ├── throughput.py
│   └── compare_hf.py          # vs reference HF inference loop
└── tests/
    ├── test_scheduler.py
    ├── test_kv_cache.py
    └── test_denoise.py
```

That's 17 source files. Lean.

---

## 6. Core algorithms & code sketches

### 6.1 Denoising loop (`denoise_loop.py`)  **[OPUS-REQUIRED]**

This is the heart of the engine. The committed-vs-pending semantics and confidence ordering must be exactly right — bugs here silently degrade output quality and are hard to detect.

```python
# Pseudocode — not final. Opus must design the actual data flow.

MASK_TOKEN_ID = ...  # model-specific

@dataclass
class DenoiseState:
    seq: torch.Tensor          # (B, L) current tokens, MASK where pending
    committed: torch.BoolTensor # (B, L) True where committed
    step: int                  # current denoising round
    total_steps: int           # planned rounds (e.g. 16)
    block_schedule: list[int]  # how many tokens to commit per step

def denoise_step(model, state: DenoiseState) -> DenoiseState:
    # Bidirectional forward over the entire sequence
    logits = model(state.seq, attention_mask=None)  # full bidirectional

    # Confidence per position (entropy or top-1 prob — see Focus-dLLM)
    probs = logits.softmax(-1)
    top1_prob, top1_id = probs.max(-1)
    confidence = top1_prob.masked_fill(state.committed, -float("inf"))

    # Commit top-k pending tokens by confidence
    k = state.block_schedule[state.step]
    _, commit_idx = confidence.topk(k, dim=-1)

    new_seq = state.seq.scatter(-1, commit_idx, top1_id.gather(-1, commit_idx))
    new_committed = state.committed.scatter(
        -1, commit_idx, True
    )
    return DenoiseState(
        seq=new_seq,
        committed=new_committed,
        step=state.step + 1,
        total_steps=state.total_steps,
        block_schedule=state.block_schedule,
    )
```

Open design questions for Opus:
1. Should `block_schedule` be uniform (`[k]*N`) or front-loaded (more aggressive early)? Papers disagree.
2. How to handle re-masking of low-confidence already-committed tokens (the "re-noise" trick from BD3-LMs)?
3. Numerical: when `top1_prob` is near-uniform across pending positions, ties matter. Argmax tie-break strategy affects determinism.

### 6.2 KV cache for diffusion (`kv_cache.py`)  **[OPUS-REQUIRED]**

The wrong design here destroys throughput. Committed tokens have stable representations; pending tokens are recomputed every step.

```python
class DiffusionKVCache:
    """
    Committed tokens have stable K/V — cache them.
    Pending (masked) tokens are re-evaluated every denoising step — DO NOT cache K/V for them
    in the inter-step sense, but DO reuse intra-step (across attention layers).

    Layout per layer:
        committed_kv: (B, num_committed, num_heads, head_dim) — grown as tokens commit
        pending_kv: (B, num_pending, num_heads, head_dim) — overwritten each step
        position_map: (B, L) -> index into committed_kv or pending_kv
    """
    def __init__(self, num_layers, num_heads, head_dim, max_seq_len, dtype):
        ...

    def admit_request(self, req_id, seq_len) -> RequestHandle: ...
    def update_committed(self, req_id, newly_committed_positions): ...
    def invalidate_pending(self, req_id): ...   # called at the start of each step
    def get_kv_for_attention(self, req_id, layer): ...  # returns merged K/V in position order
```

Open questions for Opus:
1. Is the committed/pending split done **per layer** or **per request**? Per-layer wastes memory; per-request requires re-shuffling between commits.
2. Should we Paged-allocate the committed half (since it grows monotonically) and contiguous the pending half? Or full-paged?
3. Cross-step KV reuse: when *most* of the sequence is now committed, can we treat the previous pending K/V as a warm start and only update the deltas? (Insight from LocalLeap.)

### 6.3 Scheduler (`scheduler.py`)  **[OPUS-REQUIRED]**

Continuous batching for diffusion is **stricter** than for autoregressive — requests can only batch together when at the same denoising step AND with the same/compatible block size. This rules out vLLM-style mixed prefill+decode batching.

```python
class DiffusionScheduler:
    """
    Group ready requests by (step_idx, block_size_bucket).
    Pick the group with the most members up to MAX_BATCH.
    All other groups wait.
    """
    waiting: deque[Request]
    running: list[Request]
    max_batch: int

    def schedule_next_batch(self) -> list[Request]:
        groups = defaultdict(list)
        for req in self.running:
            key = (req.step_idx, req.block_size_bucket)
            groups[key].append(req)
        best_key = max(groups, key=lambda k: len(groups[k]))
        return groups[best_key][: self.max_batch]
```

Open questions for Opus:
1. Should we prefer admitting new requests when no large batch is available, vs. flushing existing requests at small batch?
2. Block-size bucketing granularity — `[8, 16, 32, 64, 128]`? Powers of 2? Per-model tuned?
3. Fairness: a request stuck at a rare `(step, block_size)` combo could starve. Need an aging mechanism.
4. Preemption: do we ever preempt a mid-denoising request to admit a new one? Cost is high — we'd lose committed state. Probably never preempt.

### 6.4 Adaptive block size (`block_size.py`)  **[RESEARCH-FIRST: AdaBlock-dLLM]**

Sonnet: read `lgxi24/AdaBlock-dLLM` ICLR 2026 paper + repo. Summarize the algorithm (likely: detect semantic boundaries via attention pattern, adapt block size per region) and propose an implementation matching their pseudo-code. Then Opus reviews before merging.

### 6.5 Confidence sampling (`sampler.py`)  **[SONNET-OK]**

Top-k confidence selection over pending positions. Straightforward once `denoise_loop` is settled. Implement as:

```python
def commit_top_k_by_confidence(
    logits: torch.Tensor,           # (B, L, V)
    committed_mask: torch.BoolTensor, # (B, L)
    k: int,
    temperature: float = 1.0,
) -> tuple[torch.Tensor, torch.BoolTensor]:
    probs = (logits / temperature).softmax(-1)
    top1_prob, top1_id = probs.max(-1)
    score = top1_prob.masked_fill(committed_mask, -float("inf"))
    _, commit_idx = score.topk(k, dim=-1)
    # write top1_id at commit_idx, leave others as MASK
    ...
```

### 6.6 Bidirectional attention (`attention.py`)  **[SONNET-OK]**

Wrap FlashAttention-2 with `is_causal=False`. Verify it works on SM 12.0 (RTX 5070). If not, fall back to PyTorch SDPA. No causal mask, no sliding window in v0.1.

### 6.7 Model loaders (`models/llada.py`)  **[SONNET-OK after model-card read]**

Load LLaDA-8B from HF. Match the reference checkpoint's forward signature. Verify outputs match the reference inference loop bit-exactly on a fixed seed before declaring the loader done.

### 6.8 API server (`api/server.py`)  **[SONNET-OK]**

FastAPI, OpenAI-compatible `/v1/chat/completions`. Streaming uses Server-Sent Events but emits whole blocks at a time (not tokens). Document the deviation from OpenAI spec in README.

### 6.9 Metrics (`metrics.py`)  **[SONNET-OK]**

Prometheus exporter:
- `diffuserve:requests_in_flight`
- `diffuserve:denoising_step_duration_seconds` (histogram)
- `diffuserve:step_batch_size` (histogram)
- `diffuserve:committed_tokens_per_request` (histogram)
- `diffuserve:throughput_tokens_per_second`

### 6.10 Public Python API surface (besides HTTP)  **[SONNET-OK]**

In addition to the HTTP server, expose a programmatic Python API for offline batch use (research, benchmarks). Mirrors vLLM's `LLM(...).generate(...)`:

```python
from diffuserve import LLM, SamplingParams

llm = LLM(model="gsai-ml/LLaDA-8B-Instruct", dtype="fp8")
params = SamplingParams(
    num_denoising_steps=16,
    temperature=0.0,
    top_k=1,
    target_length=512,
    block_schedule="uniform",
    seed=0,
)
outputs = llm.generate(prompts=["Hello", "World"], sampling_params=params)
for o in outputs:
    print(o.text)
```

Implementation: `LLM` wraps `Engine` and runs its own asyncio loop synchronously. `generate()` blocks until all prompts complete. Streaming variant: `llm.generate_stream(...)` yields per-step block deltas.

This API is the entry point for benchmarks (`benchmarks/throughput.py`), regression tests, and any user who wants offline use. The HTTP server is built on top of the same `Engine`.

**Out of scope for v0.1**: async Python API, multi-engine pools, distributed engines.

---

## 7. Phase plan

### Phase 0: foundations (1-2 DAYS)

- Repo init (local only — no GitHub yet), pyproject, ruff/pyright config, pre-commit hooks
- Empty module skeletons matching section 5
- Load LLaDA-8B via HF, verify single-batch reference inference reproduces the published outputs
- **Verify FA-2 builds + bidirectional path works on SM 12.0** (Phase 0 task #1 — if broken, scope changes)
- **Identify and document LLaDA's tokenizer** (LLaMA-2-based with `<|mdm_mask|>` added; verify exact vocab + special tokens against `gsai-ml/LLaDA` `tokenizer_config.json`)

### Phase 1: correctness MVP (1-2 WEEKS with Sonnet + reference port)

- `denoise_loop.py`, `sampler.py`, `kv_cache.py` (committed-only; no pending caching yet)
- Single-request, single-batch end-to-end generation
- **Match the reference HF inference loop**: (a) **logits within ε=1e-4** at same dtype/seed/batch=1 against PyTorch SDPA path, and (b) **sampled tokens match exactly** at seed=0, temperature=0, top_k=1. Note: bit-exact logit match is NOT achievable across independent FA implementations — atomic adds in FA forward + softmax precision differences make this impossible. The realistic gate is logit-ε-match + token-exact.
- **[OPUS-REQUIRED]** for `denoise_loop.py` and `kv_cache.py` design

### Phase 2: continuous batching (3-5 DAYS)

- `scheduler.py` with `(step, block_size)` bucketing
- Pending-KV reuse within a step (across attention layers)
- Benchmark vs single-request mode — target ≥3× throughput at batch 8
- **[OPUS-REQUIRED]** scheduler design review

### Phase 3: API + observability (2-3 DAYS)

- FastAPI server, OpenAI-compatible endpoint
- Prometheus metrics
- Docker container
- **[SONNET-OK]**

### Phase 4: acceleration techniques (3-7 DAYS — pick ONE for MVP)

Pick TWO of these to implement in v0.1; defer the rest:
- AdaBlock-dLLM (adaptive block size)  **[RESEARCH-FIRST]**
- Focus-dLLM (confidence-guided context focusing)  **[RESEARCH-FIRST]**
- LocalLeap (local determinism propagation)  **[RESEARCH-FIRST]**
- Mosaic (long-context memory planning) — defer; complex
- Block re-noising (BD3-LMs)  **[OPUS-REQUIRED]**

Selection criterion: pick the two with the largest reported throughput gain that are simplest to implement.

### Phase 5: release & launch (2-3 DAYS)

#### Pre-launch checklist (must complete before D-day)

- [ ] Benchmark report (`docs/benchmarks.md`): tokens/sec at batch {1, 4, 8} for FP8 + INT4 on RTX 5070, plus rented-H100 FP16 numbers. Vs reference HF inference loop. Vs published Mercury Coder numbers (with the caveat that their setup is partial).
- [ ] Demo asset: 30-second GIF or video showing side-by-side latency vs LLaMA-3-8B at equal output quality. **This is the single most important launch artifact**. A picture beats 1000 words on HN.
- [ ] README: hero image, install instructions (one-line `pip install`), 10-line quickstart, link to benchmarks, link to ARCHITECTURE.md, link to CREDITS.md.
- [ ] CONTRIBUTING.md: how to set up dev env, run tests, file a good PR. Lower the bar for first contributors.
- [ ] "Good first issue" labels on 10+ specific small tasks (bug-fixable docs, perf measurements on other hardware, additional benchmark prompts).
- [ ] Model zoo: LLaDA-8B-Instruct + LLaDA-1.5 + DiffuLLaMA-1.3B work out of the box, each with a one-liner.
- [ ] OpenAPI spec auto-generated from FastAPI, hosted at `/docs`.
- [ ] LICENSE (MIT), CREDITS.md, ADRs 001-005 merged and visible.

#### Launch day (sequence — execute in order, ~3 hours total)

Pick a **Tuesday 9am PT** launch — best HN window. Avoid Fridays, Mondays.

1. **T-0 minutes**: HN Show HN post.
   - Title: `Show HN: diffuserve – Open-source serving engine for diffusion LLMs`
   - First sentence: what it is + the single most striking benchmark number.
   - Second paragraph: why this matters (LLaDA + Mercury exist, no OSS engine until now).
   - Third paragraph: link to README, demo GIF, benchmarks.
   - DON'T link your Twitter; HN dislikes that.
2. **T + 5 min**: Tweet thread on X. 8-10 tweets.
   - T1: demo video + one-line thesis.
   - T2-T6: technical highlights (committed/pending KV, scheduler bucketing, throughput chart, quality chart).
   - T7: link to HN, link to repo.
   - T8: tag @tri_dao, @WoosukKwon (vLLM), @lmsysorg (SGLang), @gsai_ml (LLaDA team), Albert Gu, Karpathy. Don't tag more than 4 in the *body* of any single tweet; spread across the thread.
3. **T + 30 min**: r/LocalLLaMA post.
   - More technical than the Twitter thread. Lead with the "why diffusion" pitch — many readers won't know.
   - Include `pip install` line.
4. **T + 1 hr**: r/MachineLearning post with `[P]` flair (more academic audience).
5. **T + 1.5 hr**: PR to `YannnnnnY/Awesome-Diffusion-LLM-Inference`. This claims your canonical-list spot.
6. **T + 2 hr**: Post in vLLM and SGLang Discord (`#general` or `#showcase`).
7. **T + 2.5 hr**: Lobste.rs post (smaller but high-quality systems audience).
8. **T + 3 hr**: Email to AI newsletters — TLDR AI, Ben's Bites, Import AI, The Batch. One-paragraph pitch + link.

#### Direct outreach (DMs in the 2 days before launch)

- **LLaDA team** (Renmin University, contact via paper authors): "We're launching an OSS engine for your model. Would love your endorsement on launch day if you find it credible." Show them the benchmark.
- **Inception Labs (Mercury Coder)**: "OSS engine for diffusion LLMs launching Tuesday. Glad to coordinate if useful — not competing with your stack, helping grow the field." Cold but professional.
- **Tri Dao (FlashAttention)**: short DM with the demo + one-line thesis. Even a quote-RT would amplify enormously.
- **vLLM maintainers (Woosuk Kwon, Zhuohan Li)**: brief DM, "we built the diffusion-LLM serving stack you guys decided not to pursue; here's the architecture; happy to coordinate on any future integration."

#### Post-launch (week 1)

- Reply to **every** GitHub issue within 24h. Set this expectation in CONTRIBUTING.md.
- Reply to every HN comment, even hostile ones. Be brief and technical.
- Twitter: one update per day showing progress on issues filed by users.
- If a researcher cites the project on Twitter/arXiv: thank them publicly, link back.
- Track stars/forks/issues; the **first 100 stars** are usually within the first 48h if the launch landed. If you're at <30 stars after 48h, the launch underperformed — diagnose (was the demo not clear? was the niche not obvious?) and re-launch in 2 weeks with the fix.

#### Success metrics for "the launch landed"

| Metric | Target (good) | Target (great) |
|---|---|---|
| HN front-page time | > 4 hours | > 12 hours (top 10) |
| HN points | 200+ | 500+ |
| GitHub stars (week 1) | 500+ | 2000+ |
| Twitter impressions (launch thread) | 50k+ | 250k+ |
| External PRs (week 1) | 1-3 | 5+ |
| Issues filed by non-author (week 1) | 5+ | 20+ |
| Newsletter pickups | 1-2 | 4+ |
| Cited by a researcher on Twitter | 1 | 3+ |

#### If launch flops

- Diagnose honestly: was the demo unclear? Was the niche not obvious to readers? Was the launch day bad timing?
- Do NOT relaunch in panic. Wait 2 weeks. Address the diagnosed issue. Re-launch with a different angle (e.g., "we beat Mercury Coder on X benchmark" if you achieve that).
- A flopped launch is not fatal. vLLM's first announcement got little attention; the paper + word-of-mouth carried it.

### Phase exit criteria (hard gates — do not advance until ALL met)

**Phase 0 → 1**:
- [ ] LLaDA-8B loads on RTX 5070 in FP8 at the chosen `(batch, seq)` without OOM (measured, recorded in `docs/perf_log.md`).
- [ ] Reference HF `generate.py` reproduces published LLaDA outputs on 5 fixed prompts at seed=0.
- [ ] Repo skeleton matches §5 file layout. CI is green.
- [ ] LLaDA paper §3 (Inference Procedure) read; math contract §4.1 confirmed.

**Phase 1 → 2**:
- [ ] Single-request, single-batch generation completes end-to-end for 5 fixed prompts.
- [ ] **Reference match** with reference HF inference loop on those 5 prompts: logits within ε=1e-4 (PyTorch SDPA path, same dtype, seed=0) AND sampled tokens identical (seed=0, temperature=0, top_k=1). This is the single most important checkpoint in the project — if your sampled tokens diverge from the reference, you have a math bug and nothing downstream will work. (NOTE: bit-exact logit match is NOT possible across independent FA implementations and is NOT the gate.)
- [ ] ADRs 001-005 written and merged.

**Phase 2 → 3**:
- [ ] Batched mode (batch=8) generates correct output across all 50 regression prompts.
- [ ] Quality metrics within thresholds (§18).
- [ ] ≥3× throughput vs single-request mode on at least one model/dtype combo.

**Phase 3 → 4**:
- [ ] HTTP API serves 100 concurrent requests without errors for 10 minutes.
- [ ] All 6 metrics (§6.9) appear in `/metrics`.
- [ ] Graceful shutdown completes within 30s.

**Phase 4 → 5**:
- [ ] Two acceleration techniques landed, each gated on (a) license audit complete, (b) `CREDITS.md` entry, (c) measured speedup ≥10% over Phase 3 baseline.

**Phase 5 → public launch**:
- [ ] Benchmark report published; numbers reproducible by anyone with the repo.
- [ ] At least 3 external testers have run the engine and filed feedback issues.
- [ ] README, CONTRIBUTING, CREDITS, ADRs all present and accurate.

**Do not advance phases by feel.** Each gate failure is debugged and fixed before moving on. Better to slip a phase by a week than carry a hidden math bug into Phase 4.

---

## 8. Techniques to bake in (cheat sheet)

| Paper | Repo | What it gives | When to add |
|---|---|---|---|
| LLaDA | `gsai-ml/LLaDA` | Reference forward pass + sampling | v0.1 (must-have) |
| AdaBlock-dLLM | `lgxi24/AdaBlock-dLLM` | Adaptive block size | v0.1 (pick 1 of 2) |
| Focus-dLLM | `Longxmas/Focus-dLLM` | Long-context throughput | v0.1 (pick 1 of 2) |
| LocalLeap | `friedrichor/LocalLeap` | Local KV reuse across steps | v0.2 |
| Mosaic | `flashserve/Mosaic` | 30× context memory planning | v0.3 |
| TIDE | `ims-kdks/TIDE` | MoE expert offload (if model is MoE) | v0.4 |
| BD3-LMs | `kuleshov-group/bd3lms` | Block diffusion, re-noising | v0.2 (model) |

---

## 9. Benchmarking & evaluation

### Throughput

- Reference: `gsai-ml/LLaDA`'s `generate.py` (single batch, naive loop)
- Target v0.1: **2× tokens/sec at batch 1**, **8× at batch 8** vs reference
- Hardware: RTX 5070 INT4, RTX 5070 FP8, rented H100 FP16

### Quality (regression checks)

- Compare logits/outputs vs reference on a fixed prompt set (50 prompts) with seed pinning
- Target: bit-exact match in single-batch mode at the same dtype
- Acceptable divergence in batched mode if quality metrics (MMLU subset, HumanEval subset) stay within 1% of reference

### Latency

- Time-to-first-block (TTFB), not TTFT — diffusion has no per-token streaming
- Step duration histogram

### Comparison targets to call out in the launch post

- vs HF reference inference loop (must beat by ≥3×)
- vs Mercury Coder published throughput numbers (parity is a win; beating is a moonshot)
- vs the per-paper inference loops in Mosaic/Focus-dLLM/AdaBlock (parity claim)

---

## 10. Opus vs Sonnet delegation map

### Use Opus for:

- **All algorithm design** in `denoise_loop.py`, `kv_cache.py`, `scheduler.py`
- Any kernel/numerical work (attention wrapper if FlashAttention path needs custom integration)
- Debugging output-quality regressions (subtle math bugs)
- Reading and synthesizing papers when implementation details matter (BD3-LMs re-noising, LocalLeap propagation rules)
- Design review at every phase gate
- Any benchmarking interpretation where you need to root-cause unexpected results

### Use Sonnet for:

- Boilerplate: pyproject, ruff config, FastAPI route handlers, Pydantic models
- HF model loading and weight inspection
- Metrics plumbing (Prometheus exporter)
- Test scaffolding (pytest structure, fixtures)
- Docker / CI YAML
- README, docs, blog post drafts
- Bulk refactoring once the design is set

### Reminder protocol (Sonnet, follow this exactly):

When you reach a step tagged **[OPUS-REQUIRED]**, do not write code. Instead, output literally:

> *"This step is tagged [OPUS-REQUIRED] in plan.md (section 6.X). I recommend you run `/model` and switch to Opus 4.7 before continuing. The specific design decisions that need Opus judgment are: [list them]. Want me to continue with Sonnet anyway?"*

When you reach a step tagged **[RESEARCH-FIRST]**, fetch the paper/repo, summarize the algorithm in 200 words, and **wait for user confirmation** before writing code.

---

## 11. Risks & mitigations

| Risk | Likelihood | Mitigation |
|---|---|---|
| Diffusion LLMs stay niche, project audience tiny | Medium | Build the engine generic enough that the scheduler/KV ideas transfer to other parallel-decode regimes (e.g. lookahead, Medusa). Frame launch as "parallel decoding engine," not "diffusion-only." |
| Mercury Coder team open-sources Inception's stack first | Low | Move fast; v0.1 in 3 months. First-mover on OSS is the moat. |
| Microsoft / Google publishes a competing OSS engine | Medium | Be first; differentiate on hackability and small surface area (vs corporate-scale framework bloat). |
| LLaDA-8B doesn't fit on 5070 even at INT4 | Low | INT4 LLaDA-8B is ~5GB weights + ~3-4GB activations. Fits. Verified by similar-size models in HF. |
| FlashAttention-2 bidirectional path is broken on SM 12.0 | Medium | Fall back to PyTorch SDPA. Defer custom kernels to v0.3. |
| Continuous batching gains are smaller than expected (because step count, not output length, dominates throughput) | Medium | Pre-bake the math: if batch 8 gives 8× per-step throughput, that's still 8× total. The risk is only if step time scales super-linearly with batch — measure early. |
| Output quality regresses in batched vs single-request mode | High | Catch in CI: 50-prompt regression suite, seed-pinned, bit-exact in single-batch, quality-metric-bounded in batched. |
| Adoption is zero because nobody believes diffusion LLMs are real | Medium | Launch with a striking demo: side-by-side latency comparison vs LLaMA-3 8B at equal quality. Visual proof. |
| Step time scales super-linearly with batch (because bidirectional attention is O(L²) and not amortized across timesteps the way KV cache amortizes AR decode) | **High** | Measure at end of Phase 0. If true, our throughput thesis is broken. Mitigation: drive batch via *number of concurrent requests at the same step*, not by intra-request parallelism. Re-verify the thesis early — do not discover this at v0.1 release. |
| Bit-exact reproduction of LLaDA reference fails in Phase 1 (math bug we can't find) | Medium | Allocate explicit Phase 1 buffer week. If still failing: open issue on `gsai-ml/LLaDA` for clarification, port their `generate.py` line-by-line into our codebase first, then refactor in place. Do NOT pretend "close enough" — Phase 1 gate is bit-exact. |
| FlashAttention-2 bidirectional path is broken or 5× slower on SM 12.0 | Medium | Phase 0 task: build FA2 with `FLASH_ATTENTION_FORCE_BUILD=TRUE` on the 5070, benchmark bidirectional. Fall back to PyTorch SDPA if broken. SDPA is slower but functional. |
| Determinism guarantees impossible due to non-deterministic kernels (FA bwd, atomic adds) | Low | Forward-only is deterministic in PyTorch with `use_deterministic_algorithms(True)` for our ops. We do not do training/backward in serving. Add CI check. |
| Research code we want to adapt turns out to be non-commercial / no-license / "ask for permission" | Medium | License audit gate (§14 Rule 2) catches this early. Have a backup technique per slot — if AdaBlock can't be used, fall back to Focus-dLLM or LocalLeap. |
| First external contributors flood with low-quality PRs we cannot review | Low (early) | Strict CONTRIBUTING.md: every PR must reference an issue, pass CI, include benchmark numbers if perf-touching. Closed by default unless review-ready. |
| Numerical drift in batched mode is too large to meet quality thresholds | Medium | Phase 2 gate is quality-bounded. If drift > threshold: investigate root cause (attention reduction order, softmax precision, FP8 quant accumulation). Last resort: support `force_single_batch=true` mode and document as a known limitation. |
| User's RTX 5070 dies / is unavailable for extended period | Low | All Phase 0-2 work can also run on rented H100 (smaller batches feasible on a 5070 are also feasible on H100). Keep a `requirements-cloud.txt` for quick cloud spin-up. |
| Mercury Coder published throughput numbers are unreproducible (vague paper, missing setup details) | Medium | Do not over-promise on Mercury parity in v0.1 launch. Frame the launch around "first OSS engine for diffusion LLMs" not "beats Mercury". Mercury comparison is a stretch goal. |
| The diffusion LLM field consolidates on BD3-LMs / continuous diffusion before our absorb-resample v0.1 ships | Low | v0.2 already plans BD3-LMs. Engine architecture (committed/pending KV, step-bucketed scheduler) generalizes — only the `denoise_loop.py` math is process-specific. |
| **Zero external contributors after launch** — repo gets some stars but no PRs, becomes "another dead OSS project" | **High** for new OSS in unfamiliar architecture niche | Lower the bar for first contributors: file "good first issue" labels from day 1, write a CONTRIBUTING.md that gives concrete pickup tasks, personally respond to every issue within 24h for the first 3 months. Solicit specific contributors (LLaDA team, diffusion paper authors) directly. |
| **Bit-exact reference reproduction in Phase 1 turns out to require a kernel rewrite** | Medium | Realistic Phase 1 gate is logit-ε-match + token-exact (§7), not bit-exact. If even that fails, line-by-line port LLaDA's `generate.py` into our skeleton first, then refactor. |

---

## 12. Repo bootstrap checklist (Phase 0)

### Day 1 (local setup only — no GitHub yet)

- [ ] `git init` at `~/Codebase/dlmserve`
- [ ] `uv venv --python 3.12 && source .venv/bin/activate`
- [ ] `uv pip install torch transformers accelerate fastapi uvicorn pydantic prometheus-client pytest ruff pyright` (flash-attn separately — requires compilation)
- [ ] Pin versions in `pyproject.toml`
- [ ] Pre-commit: ruff, pyright, pytest
- [ ] Empty module skeleton (section 5 layout)
- [ ] Reserve PyPI namespace: `uv build && uv publish` a stub `0.0.0`. Prevents squatting. (~5 min)
- [ ] Buy domain: `dlmserve.dev` (~$15/yr) or `.ai` (~$70/yr). Park it.
- [ ] Download LLaDA-8B-Instruct weights, run reference `generate.py` once, save output to `tests/fixtures/llada_reference.json`

### When to create the GitHub repo and first commit

Gate — ALL must be true before `git commit` + `gh repo create dlmserve --private --source . --remote origin --push`:

- [ ] MVP complete: all placeholder stubs replaced with real implementation.
- [ ] Zero internal dev notes remaining in any committed file (no placeholder docstrings, no TODO markers visible in code).
- [ ] No secrets, no `.env`, no personal credentials (`git log --all -p | grep -iE 'token|password|secret|api_key'`).
- [ ] Commit history is clean — single squashed commit or clean linear history. Once pushed, history is forever.

### When to flip repo PUBLIC (single decision, deliberate)

Public-flip checklist — ALL must be true before `gh repo edit --visibility public`:

- [ ] Repo has: working README with quickstart, LICENSE, CREDITS.md, at least one tagged release (`v0.1.0`).
- [ ] Benchmark numbers in `docs/perf_log.md` are real and reproducible.
- [ ] CONTRIBUTING.md ready. You're ready to receive issues.
- [ ] You literally type "yes, flip public" — no other phrasing triggers this.

### Sonnet push-reminder protocol

Sonnet must surface a `[PUSH-REMINDER]` block to the user at these specific moments. Do NOT push autonomously — always ask.

| Trigger | Sonnet says |
|---|---|
| Completing Phase 0 bootstrap | *"[PUSH-REMINDER] Phase 0 bootstrap complete. Recommend committing now: `git add . && git commit -m 'phase 0: skeleton + tooling'`. Want me to draft the commit?"* |
| Completing a `[OPUS-REQUIRED]` design module (e.g., `denoise_loop.py`) | *"[PUSH-REMINDER] `denoise_loop.py` design landed. Commit + tag a checkpoint? Suggest tag `phase-1-denoise-loop`."* |
| Reference-match Phase 1 gate passes | *"[PUSH-REMINDER] Phase 1 gate met. This is the public-flip checkpoint. Want to run the public-flip checklist (§12)?"* |
| Each acceleration technique landed (Phase 4) | *"[PUSH-REMINDER] {Technique} integrated. Commit + tag? Update CREDITS.md?"* |
| Pre-launch day (Phase 5) | *"[PUSH-REMINDER] Pre-launch checklist (§7 Phase 5) — verifying all items. Found: [list of missing items]. Push when resolved."* |
| Any time `git status` shows >50 changed files | *"[PUSH-REMINDER] Large uncommitted change set ({N} files). Commit before continuing? Easier to revert."* |
| After any successful benchmark run with new numbers | *"[PUSH-REMINDER] Benchmark numbers changed. Commit `docs/perf_log.md` update so we can git-diff perf later."* |

Rule: Sonnet **never** runs `git push` without user confirmation. `git commit` to local is OK if the user has explicitly said "commit and continue" earlier in the session; otherwise ask. `git push` is ALWAYS user-confirmed. Public-flip (`gh repo edit --visibility public`) requires explicit user typing "yes, flip public" — no other phrasing.

### Branching

- `main`: always green. Public-facing.
- Feature work: short-lived branches `phase-N/feature-name`. Squash-merge into `main`.
- Tag every phase exit with `phase-N-complete`.
- After v0.1 public launch: switch to semver tags (`v0.1.0`, `v0.1.1`, ...).

---

## 13. Naming & branding

Working name `diffuserve` is fine but not great. Suggestions for the user to pick from:

- **diffuserve** — literal, easy to type, .com probably available
- **denoist** — short, evokes denoising
- **parallax** — parallel decoding, not diffusion-only (future-proofs against architecture shift)
- **bidir** — bidirectional, distinguishes from autoregressive
- **dlm-engine** — clear, boring

Pick before Phase 0; renames are expensive after release.

---

## 14. Credits, attribution, and licensing protocol (NON-NEGOTIABLE)

This project incorporates ideas from many papers and reference repos. The line between "engineering on top of published research" (legitimate) and "stealing code" (career-ending) is **attribution + license compliance + clean-room rewrites where required**. Sonnet must follow these rules without exception.

### Rule 1 — Algorithms vs code

Algorithms described in papers are **not copyrightable**. Re-implementing an algorithm from the paper text, in our own coding style, is the academic norm and is explicitly fine. Code expression IS copyrightable. Copy-pasting source from a research repo without honoring its license is theft.

### Rule 2 — Check the license of every source repo before reading its code

For each technique we adapt, the workflow is:

1. Find the source repo on GitHub.
2. Read its LICENSE file. Categorize as:
   - **Permissive (MIT, Apache-2.0, BSD)**: code reuse allowed with attribution. Preserve copyright headers if copying.
   - **Copyleft (GPL, AGPL, LGPL)**: cannot copy code into our MIT/Apache project. Must clean-room reimplement from the paper alone.
   - **Research-only / no license / "non-commercial"**: cannot copy. Clean-room from paper. If paper alone is insufficient, skip the technique.
3. Record the license verdict in `CREDITS.md` BEFORE writing any code touching that technique.

### Rule 3 — Clean-room reimplementation when in doubt

If license is unclear or restrictive: do not look at the source code while writing ours. Implement from the paper text + our own design. Sonnet must explicitly state: *"I have NOT read the source repo for [technique]; this implementation is from the paper alone."*

### Rule 4 — `CREDITS.md` at repo root, mandatory before v0.1 release

Format:

```
## [Technique name]
- Paper: [title], [authors], [venue/arXiv link]
- Source repo: [url], commit hash, license
- Adapted in: diffuserve/[file.py]
- What we used: [algorithm idea only] / [reference for algorithm verification] / [adapted code with attribution]
- Modifications: [list]
```

One entry per technique, no exceptions.

### Rule 5 — Inline citation comments

Top of every module that adapts external work, e.g.:

```python
# diffuserve/block_size.py
#
# Adaptive block-size scheduling for diffusion LLM denoising.
#
# Based on:
#   AdaBlock-dLLM: Semantic-Aware Diffusion LLM Inference via Adaptive Block Size
#   [authors], ICLR 2026, arXiv:XXXX.XXXXX
#   Reference impl: https://github.com/lgxi24/AdaBlock-dLLM @ <commit-sha>, MIT License
#
# This implementation is a clean-room rewrite from the paper / a direct
# adaptation of the reference impl preserving its MIT attribution.
# (Pick one. Be honest. Sonnet: if you read their code, say so here.)
```

### Rule 6 — Cite in README intro

The README must have a "Built on" section linking the LLaDA paper, BD3-LMs paper, and any other foundational work in the engine's core (not just adapted techniques).

### Rule 7 — Trademarks / model names

LLaDA, Mercury Coder, etc. are model names. We can support them, document compatibility, and benchmark against them. We cannot use their names in our project branding ("LLaDA-Serve" — bad; "diffuserve supporting LLaDA" — fine).

### Rule 8 — Do not vendor model weights

Never check in or redistribute model weights. Always download from the original source (HF Hub) at runtime. Document the source URL in the model loader.

### Sonnet enforcement protocol

Before writing any module flagged **[RESEARCH-FIRST]** (sections 6.4, Phase 4):

1. Fetch the source repo's LICENSE.
2. State the license verdict in chat.
3. Decide: adapt code (permissive) or clean-room (restrictive).
4. If clean-room: state *"I will not read [repo]'s source. I will implement from the paper only."*
5. Add the `CREDITS.md` entry BEFORE writing the implementation file.
6. Add the inline citation comment as the first 10 lines of the file.

Skipping any of these steps is a hard stop. Sonnet must surface to the user: *"License audit incomplete for [technique]. Cannot proceed without [step]."*

---

## 15. API semantic gotchas (OpenAI compatibility)

The OpenAI Chat Completions API assumes autoregressive semantics. Several parameters and behaviors **do not translate** to diffusion. v0.1 must pick an explicit policy for each and document the deviation. Sonnet must not silently fake autoregressive behavior.

| OpenAI param / behavior | Diffusion reality | v0.1 policy |
|---|---|---|
| `max_tokens` | Diffusion generates to a *fixed sequence length* (e.g., 1024) configured at request admission. Tokens don't "stop early" the way EOS does in AR. | Treat `max_tokens` as **target generation length L**. Reject requests with `max_tokens > model_max_len - prompt_len`. Document. |
| `stream: true` | No per-token streaming exists. Tokens are revealed in confidence order, not left-to-right. | Stream **per denoising step**, not per token. Emit a "block delta" SSE event per step containing newly-committed tokens. README must call this out. |
| `temperature` | LLaDA confidence sampling uses argmax. Temperature scales logits BEFORE the top-1 confidence calc — affects which positions get committed first, not which token is sampled at a position. | Implement temperature scaling on logits before argmax. Document that `temperature=0` is the default (matches LLaDA reference). |
| `top_p` / `top_k` | Native LLaDA uses argmax per masked position. Nucleus / top-k sampling would require sampling instead of argmax. | v0.1 supports `top_k > 1` by sampling from top-k at each committed position. `top_p` deferred. Document. |
| `logprobs` | OpenAI returns logprobs in left-to-right order. Diffusion has no canonical order. | Return logprobs in **commit order** (the order positions were revealed across steps). Document. Include a `position` field per logprob entry so clients can re-order. |
| `stop` tokens | AR stops when EOS is generated. Diffusion has no early stop — sequence is committed to length L. | Honor `stop` strings by **truncating the final output**, not stopping generation. Document. |
| `n > 1` (multiple completions) | Natural — batch dimension. | Supported. Use the same prompt across the batch dim. |
| `presence_penalty`, `frequency_penalty`, `repetition_penalty` | Designed for sequential decoding (penalize tokens already in the sequence). Doesn't make sense when committing top-k by confidence in parallel. | **Not supported in v0.1.** Reject with HTTP 400 if specified non-zero. Document. |
| `seed` | Diffusion is deterministic given (model, seed, prompt, step count, temperature, top_k, batch composition). | Honor `seed`. See §17 (determinism contract). |
| `tools` / function calling | Out of scope. | Reject with 400. |
| `logit_bias` | Doable but interacts with confidence calc. | Defer to v0.2. |
| EOS handling | AR stops on EOS. Diffusion may commit EOS *anywhere*, including the middle of the sequence. | Truncate output at the first EOS in left-to-right order **after** generation completes. Tokens past EOS exist in logs but not in the user-visible response. |
| `max_tokens=0` | AR returns empty. Diffusion has no analog. | Reject 400. |
| Empty prompt | AR: unconditional generation. Diffusion: all-masked sequence. | Supported. |
| Multi-turn (chat history) | AR can reuse KV across turns. Diffusion has no analog (KV is mostly invalidated per step). | No cross-turn KV reuse in v0.1. Each turn is a fresh request. |
| Token counting (`usage.prompt_tokens` etc) | AR has clear "input tokens" vs "output tokens". | Same — prompt = input, generated body = output. But "completion_tokens" is the *fixed L*, not "tokens until EOS." Document. |

**Diffusion-specific extension params** (add to API beyond OpenAI spec):

| Param | Type | Description |
|---|---|---|
| `num_denoising_steps` | int, default 16 | More steps = higher quality, lower throughput. Bound `[1, 64]`. |
| `block_schedule` | str, default `"uniform"` | `"uniform"` or `"front_loaded"` or `"cosine"`. Affects commit quota per step. |
| `confidence_metric` | str, default `"top1_prob"` | `"top1_prob"` or `"entropy_inverse"`. |
| `target_length` | int | Explicit override for sequence length (alternative to `max_tokens`). |

Add these as fields in `protocol.py`. Reject unknown extension params with 400.

---

## 16. Operational edge cases & request lifecycle

These are the things that break in production but never come up in dev. Sonnet must surface to the user when the design touches any of them, not paper over silently.

### Request lifecycle states

```
QUEUED → ADMITTED → DENOISING(step=0..S-1) → COMPLETING → DONE
                                            ↓
                                          ABORTED
```

- **QUEUED**: in `scheduler.waiting`, not yet allocated KV.
- **ADMITTED**: KV allocated, in `scheduler.running`, awaiting a batch slot at its current step.
- **DENOISING**: actively being processed in a batch.
- **COMPLETING**: final step done, post-processing (detokenize, apply `stop`, EOS truncation).
- **DONE**: response written/streamed.
- **ABORTED**: client disconnect, KV OOM, model error, timeout.

### Cancellation

- **Client disconnect**: detect via FastAPI request `is_disconnected()` polling between denoising steps. Mark `ABORTED`, release KV at end of current step (don't abort mid-step — kernel launch is in flight).
- **Server-initiated cancellation** (e.g., admin endpoint): same protocol.
- **Cancellation latency budget**: ≤ 1 step duration. Step duration target: 50-200ms.

### KV OOM handling

- **Pre-admission check**: scheduler must compute KV needed for a new request *at full length L* before admitting. If not available → keep in QUEUED with backpressure.
- **At-step OOM**: if we mis-estimated and OOM happens mid-batch → abort the entire batch (all requests in it get ABORTED with HTTP 503), free their KV, surface error. Do NOT silently kill one request and continue.
- **Mitigation**: pre-allocate a max KV pool at startup (sized by `gpu_memory_utilization`). Never grow beyond.

### Model forward errors

- NaN/Inf in logits → abort batch with 500, log full request state, dump model inputs to disk for repro.
- CUDA error (illegal memory, etc) → process is poisoned. Trigger graceful shutdown + restart (orchestrator's job in prod; in v0.1, log + exit 1).

### Graceful shutdown (SIGTERM)

- Stop admitting new requests immediately (HTTP 503 on `/v1/...`).
- `/health` returns 503 with `Connection: close`.
- Drain: finish currently-running batches to completion (bounded — max `num_denoising_steps × step_time`).
- Timeout: if drain exceeds 30s, force-abort remaining and exit. Configurable.

### Backpressure

- `scheduler.waiting` has a max length (configurable, default 256). Beyond that, new requests get HTTP 429.
- Admission throttle: if `running` is full AND `waiting` is at max, queue depth exceeded → 429.

### Health endpoints

- `/health` (liveness): returns 200 if engine event loop is alive and not in graceful-shutdown mode. Bounded `< 100ms` response time.
- `/ready` (readiness): returns 200 only after model is loaded and a smoke-test inference has succeeded. Used by k8s readiness gates.
- `/metrics`: Prometheus endpoint (§6.9). Public; no auth in v0.1.

### Logging contract

- Structured JSON logs (one event per line). Schema:
  - `ts`, `level`, `req_id`, `event`, `step`, fields...
- Sensitive: do NOT log full prompts at INFO. At DEBUG only, configurable.
- Default level: INFO. Verbose tracing: DEBUG with explicit env var.

### Timeouts

- Per-request hard timeout: configurable, default **180s** (LLaDA-8B at 1024 tokens × 16 steps under batch contention on RTX 5070 can exceed 60s legitimately; 60s default trips on healthy requests). Exceeds → ABORTED with 504.
- Per-step soft warning: 1s. Logs a warning, does not abort.

### Request ID propagation

- Generate UUIDv7 per request at admission. Echo in response headers (`X-Request-ID`). Honor incoming `X-Request-ID` if client sent one.

---

## 17. Determinism, reproducibility & seeding contract

What we guarantee, what we don't, and how it interacts with batching.

### What v0.1 guarantees

**Single-request, fixed seed, SDPA path** (the "deterministic reference path"):
- Same `(model, prompt, seed, num_denoising_steps, temperature, top_k, confidence_metric, block_schedule, dtype, device)` AND `attention_backend="sdpa"` AND `torch.use_deterministic_algorithms(True)` → **token-exact** output. Logits match within ε=1e-7 (single-pass FP32 accumulation). Tested via the regression suite (§18).
- WARNING: FlashAttention-2 forward uses atomic adds for the split-K path — **NOT deterministic** even single-batch. The FA path is the *performance* backend; the SDPA path is the *reference* backend. We do not guarantee determinism on the FA path.

**Single-request, FA backend**:
- Token-exact in practice on most prompts at temperature=0, but not formally guaranteed. Quality-bounded only.

**Batched mode (any backend)**:
- Same seed, but in a batch with different other requests → output may differ at the LSB level due to reduction order and batch-invariance violations. Quality-metric-bounded (§18) but not token-exact.
- We **document this clearly** in the API. Clients needing reproducibility must set `attention_backend="sdpa"` AND `force_single_batch: true`.

### What we do NOT guarantee

- Cross-hardware bit-exactness (RTX 5070 vs H100). Different SM count → different tile decomposition → different reductions.
- Cross-dtype (FP8 vs FP16) bit-exactness.
- Cross-version bit-exactness (between diffuserve releases). Major versions may change kernels.

### Seeding implementation

- Each request carries its own RNG state, seeded from `seed` param (or hash of request ID if unseeded).
- All randomness sources MUST consume from this RNG:
  - top-k sampling (when `top_k > 1`)
  - tie-breaking in `topk(confidence)` (when ties exist — they will at temperature 0)
  - any future stochastic component
- Use `torch.Generator` per request, not the global RNG.

### Tie-breaking determinism

`torch.topk` on tied confidences is **not deterministic by default**. Fix by adding tiny ε-noise from the request RNG:

```python
noise = torch.rand(confidence.shape, generator=req_rng, device=confidence.device) * 1e-9
confidence_tiebroken = confidence + noise
```

Tracked as a Phase 1 design item.

### Determinism CI

- 50-prompt fixed-seed regression suite (§18) runs on every PR.
- Bit-exact diff against golden outputs. Any drift = CI failure.
- Golden outputs are stored in `tests/fixtures/golden/` and re-generated only when intentionally changing the math (must be a PR with explicit "GOLDEN-UPDATE" tag and human review).

---

## 18. Quality & performance regression test suite

The thing that catches "I optimized throughput 3× but output quality cratered."

### Regression prompt set (`tests/fixtures/prompts.json`)

50 prompts spanning:
- Short factual ("What is the capital of France?") × 10
- Code generation (simple Python function from docstring) × 10
- Long-form narrative ("Write a 200-word story about...") × 10
- Reasoning chains (GSM8K subset) × 10
- Edge cases (empty prompt, max-length prompt, unicode-heavy, code blocks, system messages) × 10

Each prompt has a frozen `expected_completion` generated from the LLaDA reference inference loop at seed=0, num_steps=16, temperature=0.

### Quality metrics

Run on each PR (gated):

| Metric | How | Threshold for PR-merge |
|---|---|---|
| Bit-exact match (single-batch) | Diff committed tokens | 50/50 prompts must match |
| Bit-exact match (batched, force_single_batch=true) | Diff via API in batch mode | 50/50 must match |
| BLEU vs reference (batched, normal mode) | sacrebleu | ≥ 0.95 |
| MMLU subset accuracy | 100 questions | within 1% of reference |
| HumanEval pass@1 | 20 problems | within 2 absolute points of reference |

### Performance metrics (CI on RTX 5070 dev box, runner self-hosted)

| Metric | Target | Reject PR if |
|---|---|---|
| Tokens/sec at batch 1 (FP8, seq 512) | Phase 0 baseline + ≥2× by v0.1 | Regression > 5% vs main |
| Tokens/sec at batch 8 | Phase 0 baseline + ≥8× by v0.1 | Regression > 5% vs main |
| Step duration p50 (batch 4, seq 512) | Phase 0 baseline | Regression > 10% |
| Step duration p99 | within 2× of p50 | p99/p50 > 3 |
| GPU mem peak | < 11.5 GB | > 11.8 GB (OOM risk) |
| Cold-start to first response (model loaded) | < 200ms | > 500ms |

### Determinism CI

- Same prompts, run twice in identical environment, bit-exact diff. 50/50 required.

### Long-running soak (weekly, manual on rented H100)

- 1000-request stream over 30 minutes. Detect:
  - Memory growth (KV pool leak)
  - Throughput degradation
  - Quality drift

---

## 19. Execution model: async, GIL, threading

Decisions to lock in early. Changes here are expensive once code is written.

### High-level architecture

```
[FastAPI async event loop]
    ↓ (async queue)
[Engine event loop — single Python thread]
    ↓
[GPU worker]
    ↓ (CUDA streams)
[Bidirectional model forward]
```

### Decisions

- **FastAPI**: async with `uvicorn`. All endpoint handlers are `async def`.
- **Engine**: single `asyncio` task driving the scheduler loop. NOT a separate thread (avoids GIL contention on Python data structures).
- **GPU work**: PyTorch in default stream. Single CUDA stream in v0.1 (multi-stream overlap deferred to v0.3 once profiled).
- **Tokenization**: runs on the CPU. **HF tokenizers (Rust)** which releases the GIL. Tokenize in the FastAPI handler before submitting to engine queue — keeps GIL hold short.
- **Detokenization**: same — in the engine loop, after `COMPLETING`, before response. HF tokenizers Rust impl releases GIL.

### Why not threads

- GIL means CPU work in Python competes with the engine loop.
- Engine loop must be hot — schedule decisions are made between every step.
- Threads add complexity (locking shared scheduler state) for no perf gain.

### Why not multiprocessing

- Model weights are on GPU, shared via single CUDA context. Multi-process requires CUDA IPC or model duplication.
- v0.1 single-process is simpler. Multi-process (à la vLLM workers) deferred to v0.5+ for multi-GPU.

### What this means for Sonnet

- All engine code is `async`. Use `asyncio.Queue` for request submission.
- Never call `torch.cuda.synchronize()` from the FastAPI handler — blocks the event loop.
- Long-running CPU work (e.g., tokenization of a huge prompt) must be in an `asyncio.to_thread()` or executor.
- Model forward calls return from kernel-launch immediately; await results via `torch.cuda.Event` polling in the engine loop, not `synchronize`.

---

## 20. Profiling strategy

When throughput is below target, the answer to "where's the bottleneck" must be findable, not guessed.

### Tools (in order of preference)

1. **NVIDIA Nsight Systems** — kernel timing, CUDA stream utilization. Use NVTX ranges in scheduler/denoise loop to correlate engine-level events with kernels.
2. **PyTorch profiler** (`torch.profiler`) — for op-level breakdown.
3. **`/metrics` Prometheus + Grafana** — long-running production view.
4. **py-spy** — for CPU-side scheduler hot paths.

### NVTX range conventions (add to every phase)

- `denoise.step.s{N}` around each denoising step
- `kv.update_committed` around KV updates
- `scheduler.schedule_batch` around batch selection
- `model.forward.layer{N}` around per-layer forwards (optional, expensive)

These let Nsight traces map directly to engine concepts. Adds <0.1% overhead when disabled.

### Bottleneck triage protocol

When throughput is < target:
1. Run Nsight Systems, look at GPU utilization. If < 70%, problem is CPU/Python.
2. If GPU-bound: profile model forward, find hottest kernel.
3. If CPU-bound: py-spy the scheduler loop.
4. If memory-bound (high HBM bandwidth, low FLOPs): kernel fusion or smaller dtype.

Document each bottleneck found in `docs/perf_log.md` with date, version, fix.

---

## 21. Decision log / ADRs

Architecturally significant decisions get a short ADR in `docs/adrs/NNN-title.md`. Format:

```
# ADR NNN: [title]
Date: YYYY-MM-DD
Status: proposed | accepted | superseded by ADR M

## Context
## Decision
## Consequences
## Alternatives considered
```

v0.1 must have ADRs for at minimum:
- 001: Why LLaDA absorb-and-resample for v0.1 (not BD3-LMs)
- 002: Committed/pending KV split design (Opus designs)
- 003: Scheduler bucketing by (step, block_size) (Opus designs)
- 004: Single-process async model (no multiprocessing)
- 005: OpenAI API deviations (per §15)

ADRs are short (<1 page). They exist so reviewers and future contributors understand WHY, not WHAT. The PR description references the ADR.

---

## 22. Sonnet anti-patterns (what Sonnet will get wrong if not warned)

These are the failure modes I (Opus) expect from a Sonnet session on this project. Sonnet: re-read these before every coding session.

1. **Treating diffusion as autoregressive in disguise.** Tempting because the HTTP API looks similar. It is not. Bidirectional attention, parallel commit, fixed-length output. If you are about to write `for token in generated:` — stop. Diffusion does not produce tokens one at a time.
2. **Silently scope-creeping.** Adding "while I'm here" support for BD3-LMs, multi-GPU, or LoRA mid-MVP. **Stop.** Out of scope for v0.1 (§23). If the user asks for it, surface that it's scope creep and ask for confirmation.
3. **Copy-pasting research code without §14 audit.** Every adapted module needs `CREDITS.md` entry + license verdict + inline citation BEFORE the code is written. No exceptions.
4. **Skipping the Phase 1 reference-match gate.** The gate is (a) logits within ε=1e-4 on the SDPA path, AND (b) sampled tokens identical at seed=0, temperature=0, top_k=1. "It looks close" is not the gate. If sampled tokens differ from the reference, there is a math bug — find it before advancing. **Bit-exact logit match across independent FA implementations is impossible and is NOT the gate** (FA uses atomic adds). Do not chase impossible determinism.
5. **Adding error handling to scenarios that can't happen.** Trust internal invariants. Only validate at API boundaries (HTTP handler) and at GPU boundaries (OOM check before launch). Do not wrap every internal call in try/except.
6. **Writing dataclasses for everything.** Pydantic at API boundary. Plain dataclasses for engine state. Don't proliferate.
7. **Calling `torch.cuda.synchronize()` from the FastAPI handler.** Blocks the event loop. Use events or async wrappers.
8. **Mixing dtypes silently.** If model is FP8 and you cast intermediate to FP16, document why. Otherwise stick to one.
9. **Reaching for `torch.compile` early.** Defer until profiled. It interacts badly with dynamic shapes (variable batch / seq).
10. **Padding requests to max length to make batching uniform.** Diffusion is O(L²) — wasted padding is wasted compute. The scheduler must respect actual lengths via bucketing.
11. **Building abstractions for hypothetical multi-backend support** (PyTorch vs JAX vs Triton). v0.1 is PyTorch only. Don't build a `Backend` base class.
12. **Writing tests that mock the model.** Use a tiny real diffusion model (DiffuLLaMA-1.3B) for tests. Mocked logits hide math bugs.
13. **Comments that explain WHAT the code does.** Code says what. Comments say why (a hidden invariant, a workaround, a numerical constraint). The plan's CLAUDE.md rules apply.
14. **Long docstrings on internal classes.** One-line. The class name should already explain it.
15. **`from X import *`.** Banned. Explicit imports.
16. **Updating `expected_completion` golden files because output changed.** That's a math regression unless it was an explicit intentional change with `GOLDEN-UPDATE` PR tag (§17).
17. **Auto-fixing lint by changing logic.** Ruff fixes are mechanical. If the fix changes behavior, you didn't fix lint — you changed code.
18. **Adding configuration parameters "for flexibility".** Each config option has to be tested and documented. Default to hard-coded. Add config only when there is a measured reason.
19. **Calling out to web tools mid-implementation.** All papers / repo references go through the user. Sonnet does not have license to silently fetch external code.
20. **Forgetting to flag [OPUS-REQUIRED].** §10 reminder protocol is binding. If you write code that touches `denoise_loop.py`, `kv_cache.py`, or `scheduler.py` core logic without prompting an Opus switch, that is a process violation.

---

## 23. Out of scope for v0.1

Listed so Sonnet does not scope-creep:

- Multi-GPU tensor parallelism (defer to v0.5+; can't dev-test on 5070)
- Quantization (use HF's pre-quantized checkpoints; do not implement quantization ourselves)
- LoRA / adapter support
- Vision-language (LLaDA-V) — defer to v0.6
- Tool use, function calling
- Speculative decoding (block-level re-noising is the diffusion analog — defer to v0.3)
- Custom CUDA kernels — defer until a kernel-level bottleneck is profiled
- KV cache offload to CPU/NVMe — defer

---

## 24. First-week concrete actions

For the user to do **before** opening a Sonnet session with this plan:

1. Read this plan end to end. Push back on anything you disagree with.
2. Pick a name (section 13).
3. Decide INT4 vs FP8 for primary dev target (recommendation: FP8 — slightly more headroom, simpler quant scheme; INT4 for end-of-phase benchmarks).
4. Skim the LLaDA paper (arXiv:2502.09992 — "Large Language Diffusion Models") and the LLaDA repo README. 30 minutes max — you need the vocabulary, not mastery.
5. Verify access to a rented H100 for occasional CI (RunPod / Vast.ai account funded).

Then Sonnet can take Phase 0 in one session. Phase 1 is where Opus comes back in.

---

*End of plan. Sonnet: read this top-to-bottom before doing anything. The delegation map in section 10 is binding. The risks in section 11 are not theoretical — they are the things that will kill the project if you ignore them.*
