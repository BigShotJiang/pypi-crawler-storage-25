# Credits & Attribution

dlmserve builds on the ideas and research from the following works.
Every adapted technique is listed here per the licensing protocol in plan §14.

---

## LLaDA — Large Language Diffusion with mAsking

- **Paper**: "LLaDA: Large Language Diffusion with mAsking", Nie et al., arXiv:2502.09992
- **Source repo**: https://github.com/gsai-ml/LLaDA, MIT License
- **Adapted in**: `dlmserve/denoise_loop.py`, `dlmserve/sampler.py`
- **What we used**: Absorb-and-resample inference procedure (paper §3); math contract for v0.1
- **Modifications**: Reimplemented for batch serving; scheduling and KV cache are original

---

*Additional entries will be added as techniques are implemented. No code is adapted
without a corresponding entry here and an inline citation in the source file.*
