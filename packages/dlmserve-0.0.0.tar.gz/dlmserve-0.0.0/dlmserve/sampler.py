"""Confidence-based top-k token commitment sampler.

[SONNET-OK] per plan §6.5. Implement after denoise_loop design is settled.
"""
