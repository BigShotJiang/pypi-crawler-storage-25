"""FastAPI server — OpenAI-compatible /v1/chat/completions endpoint.

[SONNET-OK] per plan §6.8. Deviations from OpenAI spec are documented in
plan §15 and must appear in README.
"""
