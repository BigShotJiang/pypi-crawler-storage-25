"""Pydantic request/response models for the HTTP API.

[SONNET-OK] per plan §6.8 / §15. Includes diffusion-specific extension
params: num_denoising_steps, block_schedule, confidence_metric, target_length.
"""
