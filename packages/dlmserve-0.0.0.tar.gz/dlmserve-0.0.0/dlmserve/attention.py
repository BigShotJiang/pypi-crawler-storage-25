"""Bidirectional attention wrapper (no causal mask).

[SONNET-OK] per plan §6.6.
Wraps FlashAttention-2 with is_causal=False; falls back to PyTorch SDPA
if FA2 is unavailable or broken on the current SM architecture.
"""
