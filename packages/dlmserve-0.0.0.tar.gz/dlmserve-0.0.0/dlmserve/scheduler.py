"""Denoising-step-aware continuous batching scheduler.

[OPUS-REQUIRED] — core design must be reviewed by Opus before implementation.
See plan §6.3 and §10 delegation map.
"""
