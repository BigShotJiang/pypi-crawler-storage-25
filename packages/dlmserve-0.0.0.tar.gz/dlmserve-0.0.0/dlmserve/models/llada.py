"""LLaDA-8B model loader and forward pass.

[SONNET-OK after model-card read] per plan §6.7.
Loads from HF Hub (gsai-ml/LLaDA-8B-Instruct or LLaDA-8B-Base).
Outputs must match the reference inference loop before this is declared done.
"""
