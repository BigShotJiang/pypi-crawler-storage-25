"""Model loaders. bd3lm.py is deferred to v0.2 — do NOT create in v0.1."""
