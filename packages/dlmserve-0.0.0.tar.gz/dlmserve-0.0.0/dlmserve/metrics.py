"""Prometheus metrics exporter.

[SONNET-OK] per plan §6.9. Exposes:
  dlmserve:requests_in_flight
  dlmserve:denoising_step_duration_seconds (histogram)
  dlmserve:step_batch_size (histogram)
  dlmserve:committed_tokens_per_request (histogram)
  dlmserve:throughput_tokens_per_second
"""
