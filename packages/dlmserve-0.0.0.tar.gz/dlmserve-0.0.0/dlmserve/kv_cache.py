"""Committed/pending KV cache split for diffusion denoising.

[OPUS-REQUIRED] — core design must be reviewed by Opus before implementation.
See plan §6.2 and §10 delegation map.
"""
