# saf-sdk

> **Note:** `saf-sdk` is a temporary package name. It will be renamed to `deployments-wrap-sdk` later.

SDK for wrapping third-party agent frameworks (Google ADK, Strands, etc.) for deployment on LangSmith.

## Installation

```bash
pip install saf-sdk[google-adk]
```

## Quick Start

```python
from google.adk.agents import Agent
from google.adk.runners import Runner
from saf_sdk.adk import LangsmithSessionService, wrap

agent = wrap(
    Runner(
        agent=Agent(name="my_agent", model="gemini-2.0-flash", instruction="..."),
        app_name="my_app",
        session_service=LangsmithSessionService(),
    )
)
```

Export `agent` from your graph module and deploy with `langgraph dev` or LangSmith.
