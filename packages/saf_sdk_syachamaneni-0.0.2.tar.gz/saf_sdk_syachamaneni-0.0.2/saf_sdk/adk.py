"""Google ADK integration for LangSmith Deployments."""

from __future__ import annotations

import contextvars
from typing import TYPE_CHECKING, Annotated, Any, TypedDict

from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    AnyMessage,
    HumanMessage,
)
from pydantic import BaseModel, Field
from langchain_core.outputs import ChatGeneration, ChatGenerationChunk, LLMResult
from langchain_core.runnables.config import (
    RunnableConfig,
    get_async_callback_manager_for_config,
)
from langgraph.config import get_config
from langgraph.func import entrypoint
from langgraph.graph.message import add_messages
from uuid_utils.compat import uuid7

try:
    from langsmith.integrations.google_adk import configure_google_adk
    from langsmith.utils import tracing_is_enabled
except ImportError:
    configure_google_adk = None  # type: ignore[assignment, misc]
    tracing_is_enabled = None  # type: ignore[assignment]

if TYPE_CHECKING:
    from google.adk.agents.run_config import RunConfig, StreamingMode
    from google.adk.runners import Runner
    from google.adk.sessions import BaseSessionService, Session
    from google.adk.sessions.base_session_service import ListSessionsResponse
    from google.genai.types import Content, Part
    from langgraph.pregel import Pregel

# Runtime import guard — gives a clear error when google-adk is missing.
try:
    from google.adk.agents.run_config import RunConfig, StreamingMode
    from google.adk.sessions import BaseSessionService, Session
    from google.adk.sessions.base_session_service import (
        ListSessionsResponse,
    )
    from google.genai.types import Content, Part
except ImportError as _err:
    raise ImportError(
        "google-adk is required for ADK integration. "
        "Install it with: pip install saf-sdk[google-adk]"
    ) from _err

__all__ = ["ADKInput", "ADKOutput", "LangsmithSessionService", "SessionData", "wrap"]

_DEFAULT_USER_ID = "anonymous"


class ADKInput(BaseModel):
    """Default input schema for ADK agents wrapped with :func:`wrap`.

    ``messages`` is required; ``state_delta`` is optional and passed directly
    to ``runner.run_async(state_delta=...)`` to update ADK session state.

    Defined as a Pydantic ``BaseModel`` so the generated JSON schema exposes
    ``properties`` at the top level (no ``$ref`` wrapper). This keeps the
    A2A endpoint's ``messages`` field discoverable and avoids Pydantic's
    refusal to process ``typing.TypedDict`` on Python < 3.12.
    """

    messages: Annotated[list[AnyMessage], add_messages] = Field(default_factory=list)
    state_delta: dict[str, Any] | None = None


class ADKOutput(BaseModel):
    """Default output/state schema for ADK agents wrapped with :func:`wrap`.

    Exposing ``messages`` as a typed field (rather than a plain ``dict``) lets
    LangGraph Studio detect the graph as chat-compatible and enable the chat
    mode toggle in the UI.
    """

    messages: Annotated[list[AnyMessage], add_messages] = Field(default_factory=list)


# Per-task session storage: each asyncio task (i.e. each concurrent invocation)
# gets its own isolated session so concurrent requests don't clobber each other.
_task_session: contextvars.ContextVar[Session | None] = contextvars.ContextVar(
    "langsmith_adk_session", default=None
)


class SessionData(TypedDict, total=False):
    """Serialized ADK session stored in the LangGraph checkpoint."""

    id: str
    app_name: str
    user_id: str
    state: dict[str, Any]
    events: list[dict[str, Any]]
    last_update_time: float


class LangsmithSessionService(BaseSessionService):
    """ADK SessionService backed by LangSmith's checkpoint system.

    Use this as the ``session_service`` in your ``Runner``.  Session state is
    persisted automatically by the deployment's storage backend and survives
    server restarts.

    Example::

        from saf_sdk.adk import LangsmithSessionService, wrap

        agent = wrap(Runner(
            agent=my_agent,
            app_name="my_app",
            session_service=LangsmithSessionService(),
        ))
    """

    # -- checkpoint bridge (called by wrap()) --------------------------------

    def load(self, session_data: SessionData | None) -> None:
        """Restore session for the current invocation from checkpoint state."""
        if session_data:
            _task_session.set(Session.model_validate(session_data))
        else:
            _task_session.set(None)

    def dump(self) -> SessionData | None:
        """Serialize the current session to a dict for checkpointing."""
        session = _task_session.get()
        if session is None:
            return None
        return session.model_dump(mode="json")

    # -- BaseSessionService interface ----------------------------------------

    async def get_session(
        self,
        *,
        app_name: str,
        user_id: str,
        session_id: str,
        config: Any = None,
    ) -> Session | None:
        session = _task_session.get()
        if (
            session is not None
            and session.app_name == app_name
            and session.user_id == user_id
            and session.id == session_id
        ):
            return session
        return None

    async def create_session(
        self,
        *,
        app_name: str,
        user_id: str,
        session_id: str | None = None,
        state: dict | None = None,
    ) -> Session:
        session = Session(
            id=session_id or "",
            app_name=app_name,
            user_id=user_id,
            state=state or {},
            events=[],
        )
        _task_session.set(session)
        return session

    async def delete_session(
        self, *, app_name: str, user_id: str, session_id: str
    ) -> None:
        session = _task_session.get()
        if (
            session is not None
            and session.app_name == app_name
            and session.user_id == user_id
            and session.id == session_id
        ):
            _task_session.set(None)

    async def list_sessions(
        self, *, app_name: str, user_id: str | None = None
    ) -> ListSessionsResponse:
        session = _task_session.get()
        if (
            session is not None
            and session.app_name == app_name
            and (user_id is None or session.user_id == user_id)
        ):
            return ListSessionsResponse(sessions=[session])
        return ListSessionsResponse(sessions=[])


async def _stream_runner_events(
    runner: Runner,
    *,
    app_name: str,
    user_id: str,
    session_id: str,
    new_message: Content,
    user_msg_text: str,
    state_delta: dict[str, Any] | None,
    config: RunnableConfig,
) -> tuple[str, str]:
    """Run the ADK agent and stream token events through LangGraph's callback system.

    Bridges ADK's event stream into ``stream_mode="messages"`` so tokens appear
    in useStream / Studio.  Returns ``(response_text, msg_id)``.
    """
    cm = get_async_callback_manager_for_config(config)
    msg_id = str(uuid7())
    llm_runs = await cm.on_chat_model_start(
        serialized={"name": app_name},
        messages=[[HumanMessage(content=user_msg_text)]],
        run_id=uuid7(),
    )

    _run_config = RunConfig(streaming_mode=StreamingMode.SSE)

    response_parts: list[str] = []
    final_parts: list[str] = []
    async for event in runner.run_async(
        user_id=user_id,
        session_id=session_id,
        new_message=new_message,
        state_delta=state_delta,
        run_config=_run_config,
    ):
        if not event.content or not event.content.parts:
            continue
        if event.partial:
            for part in event.content.parts:
                if part.text:
                    response_parts.append(part.text)
                    chunk = ChatGenerationChunk(
                        message=AIMessageChunk(content=part.text, id=msg_id)
                    )
                    for llm_run in llm_runs:
                        await llm_run.on_llm_new_token(part.text, chunk=chunk)
        else:
            for part in event.content.parts:
                if part.text:
                    final_parts.append(part.text)

    response_text = "".join(response_parts) or "".join(final_parts)

    for llm_run in llm_runs:
        await llm_run.on_llm_end(
            LLMResult(
                generations=[
                    [
                        ChatGeneration(
                            message=AIMessageChunk(content=response_text, id=msg_id)
                        )
                    ]
                ]
            )
        )

    return response_text, msg_id


def wrap(runner: Runner) -> Pregel:
    """Wrap a Google ADK Runner for deployment on LangSmith.

    The runner's ``session_service`` must be a ``LangsmithSessionService``.

    Args:
        runner: A configured ``google.adk.runners.Runner`` instance.

    Returns:
        A LangGraph-compatible agent ready to be exported from your graph module.
    """
    if tracing_is_enabled is not None and tracing_is_enabled():
        configure_google_adk()

    if not isinstance(runner.session_service, LangsmithSessionService):
        raise TypeError(
            f"runner.session_service must be a LangsmithSessionService, "
            f"got {type(runner.session_service).__name__}. "
            f"Replace it with: session_service=LangsmithSessionService()"
        )

    app_name = runner.app_name
    output_key: str | None = getattr(runner.agent, "output_key", None)

    async def _run(
        payload: ADKInput,
        previous: dict | None = None,
    ) -> entrypoint.final[ADKOutput, SessionData]:
        config = get_config()
        configurable = config.get("configurable", {})
        session_id = configurable.get("thread_id", "default")
        user_id = configurable.get("langgraph_auth_user_id") or _DEFAULT_USER_ID

        runner.session_service.load(previous or {})

        session = await runner.session_service.get_session(
            app_name=app_name, user_id=user_id, session_id=session_id
        )
        if session is None:
            await runner.session_service.create_session(
                app_name=app_name, user_id=user_id, session_id=session_id
            )

        if not payload["messages"]:
            raise ValueError("messages must not be empty")
        user_msg = HumanMessage(content=payload["messages"][-1]["content"]).text
        new_message = Content(role="user", parts=[Part(text=user_msg)])

        response_text, msg_id = await _stream_runner_events(
            runner,
            app_name=app_name,
            user_id=user_id,
            session_id=session_id,
            new_message=new_message,
            user_msg_text=user_msg,
            state_delta=payload.get("state_delta"),
            config=config,
        )

        session_data = runner.session_service.dump()
        value: dict[str, Any] = {
            "messages": [AIMessage(content=response_text, id=msg_id)],
            "_adk_session": session_data,
        }

        if output_key and session_data:
            output_val = session_data.get("state", {}).get(output_key)
            if output_val is not None:
                value[output_key] = output_val

        return entrypoint.final(
            value=value,
            save=session_data,
        )

    _run.__name__ = app_name
    _run.__annotations__["payload"] = ADKInput
    _run.__annotations__["return"] = entrypoint.final[ADKOutput, SessionData]
    return entrypoint(name=app_name)(_run)
