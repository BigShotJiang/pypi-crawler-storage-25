# Splatlogger (c) 2025 Shadow Doggo.

import struct

import psutil
from PyMemoryEditor import OpenProcess, ProcessIDNotExistsError  # type: ignore[import-untyped]


class CemuGecko:
    """Wrapper around PyMemoryEditor to provide Cemu memory access.
    Compatible with existing code written for TCPGecko.
    """
    def __init__(self, pid: int = -1):
        cemu_pid = self._find_cemu_process() if pid == -1 else pid
        if not cemu_pid:
            raise CemuGeckoException("Cemu process not found.")

        try:
            self._process = OpenProcess(pid=cemu_pid)
        except ProcessIDNotExistsError as e:
            raise CemuGeckoException("Invalid process ID.") from e

        self._base_address = self._get_base_address()
        if self._base_address == 0:
            raise CemuGeckoException("Could not find Wii U memory space base address.")

    def peek_raw(self, address: int, length: int) -> bytes:
        """Read raw memory starting at address and ending at address + length.
        Returns a bytes object.
        """
        return self._process.read_process_memory(self._base_address + address, bytes, length)

    def peek8(self, address: int, *, signed: bool = False) -> int:
        """Get an 8-bit integer value stored at the specified address."""
        return int.from_bytes(self.peek_raw(address + 3, length=1), byteorder="big", signed=signed)

    def peek16(self, address: int, *, signed: bool = False) -> int:
        """Get a 16-bit integer value stored at the specified address."""
        return int.from_bytes(self.peek_raw(address + 2, length=2), byteorder="big", signed=signed)

    def peek32(self, address: int, *, signed: bool = False) -> int:
        """Get a 32-bit integer value stored at the specified address."""
        return int.from_bytes(self.peek_raw(address, length=4), byteorder="big", signed=signed)

    def peek_float(self, address: int) -> float:
        """Get a floating point value stored at the specified address."""
        return struct.unpack(">f", self.peek_raw(address, length=4))[0]

    def read_string(self, address: int, length: int = 1, encoding: str = "utf-8") -> str:
        return self.peek_raw(address, length).decode(encoding)

    def _get_base_address(self) -> int:
        base_address = 0
        for memory_region in self._process.get_memory_regions():
            address = memory_region["address"]
            size = memory_region["size"]
            if size == 0x4E000000:
                base_address = address - 0x2000000
                break

        return base_address

    @staticmethod
    def _find_cemu_process() -> int | None:
        for process in psutil.process_iter():
            if process.name().lower() in ("cemu", "cemu.exe", "xapfish", "xapfish.exe"):
                return process.pid

        return None


class CemuGeckoException(Exception): pass
