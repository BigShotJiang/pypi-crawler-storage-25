# Splatlogger (c) 2025 Shadow Doggo.

from .tcpgecko import TCPGecko, TCPGeckoException


class TCPGeckoAroma(TCPGecko):
    """Extends the TCPGecko class to provide support for the Aroma TCPGecko plugin."""
    def __init__(self, ip: str, *, port: int=7332, timeout: int=10) -> None:
        super().__init__(ip, port=port, timeout=timeout)

    def peek_raw(self, address: int, length: int) -> bytes:
        """Read raw memory starting at address and ending at address + length.
        Returns a bytes object.
        """
        if length == 0:
            raise TCPGeckoException("Reading memory requires a length (# of bytes).")

        if not self._valid_range(address, length):
            raise TCPGeckoException(f"Address 0x{address:X} is outside the valid range.")

        if not self._valid_access(address, length, access="read"):
            raise TCPGeckoException(f"Cannot read from address 0x{address:X}.")

        ret = b""
        # peekmultiple could work as well, but the implementation would
        # have to be a lot more complicated to allow for arbitrary lengths.
        if length > 4:
            for _ in range(length // 4):
                if length > 4:
                    ret += self._peek_request(address, length=4)

                    address += 4
                    length -= 4
                else:
                    ret += self._peek_request(address, length=length)
        else:
            ret = self._peek_request(address, length=length)

        return ret

    def peek8(self, address: int, *, signed: bool=False) -> int:
        """Get an 8-bit integer value stored at the specified address."""
        if not self._valid_range(address, length=1):
            raise TCPGeckoException(f"Address 0x{address:X} is outside the valid range.")

        if not self._valid_access(address, length=1, access="read"):
            raise TCPGeckoException(f"Cannot read from address 0x{address:X}.")

        request = bytes(f"peek -t u8 -a 0x{address + 3:X}", "utf-8")
        self._socket.send(request)

        response = self._socket.recv(8)
        val = int(response.decode("utf-8").strip())
        if signed and val >= 2 ** 7:  # Rough unsigned to signed conversion.
            return val - 2 ** 8

        return val

    def peek16(self, address: int, *, signed: bool=False) -> int:
        """Get a 16-bit integer value stored at the specified address."""
        if not self._valid_range(address, length=2):
            raise TCPGeckoException(f"Address 0x{address:X} is outside the valid range.")

        if not self._valid_access(address, length=2, access="read"):
            raise TCPGeckoException(f"Cannot read from address 0x{address:X}.")

        request = bytes(f"peek -t u16 -a 0x{address + 2:X}", "utf-8")
        self._socket.send(request)

        response = self._socket.recv(16)
        val = int(response.decode("utf-8").strip())
        if signed and val >= 2 ** 15:
            return val - 2 ** 16

        return val

    def peek32(self, address: int, *, signed: bool=False) -> int:
        """Get a 32-bit integer value stored at the specified address."""
        if not self._valid_range(address, length=4):
            raise TCPGeckoException(f"Address 0x{address:X} is outside the valid range.")

        if not self._valid_access(address, length=4, access="read"):
            raise TCPGeckoException(f"Cannot read from address 0x{address:X}.")

        request = bytes(f"peek -t u32 -a 0x{address:X}", "utf-8")
        self._socket.send(request)

        response = self._socket.recv(32)
        val = int(response.decode("utf-8").strip())
        if signed and val >= 2 ** 31:
            return val - 2 ** 32

        return val

    def peek_float(self, address: int) -> float:
        """Get a floating point value stored at the specified address."""
        if not self._valid_range(address, length=4):
            raise TCPGeckoException(f"Address 0x{address:X} is outside the valid range.")

        if not self._valid_access(address, length=4, access="read"):
            raise TCPGeckoException(f"Cannot read from address 0x{address:X}.")

        request = bytes(f"peek -t f32 -a 0x{address:X}", "utf-8")
        self._socket.send(request)

        response = self._socket.recv(32)
        return float(response.decode("utf-8").strip())

    def _peek_request(self, address: int, length: int) -> bytes:
        request = bytes(f"peek -t u32 -a 0x{address:X}", "utf-8")
        self._socket.send(request)

        response = self._socket.recv(32)
        value = int(response.decode("utf-8").strip())

        return value.to_bytes(4, byteorder="big")[:length]
