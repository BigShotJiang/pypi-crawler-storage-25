# Splatlogger (c) 2025 Shadow Doggo.

import os
import time
from datetime import datetime

import userpaths  # type: ignore[import-untyped]

from .cemu_gecko import CemuGecko
from .data import Pointers, Addresses, Offsets, PlayerInfo, Names
from .tcpgecko import TCPGecko


class MatchLogger:
    """Provides the match logging functionality of Splatlogger."""
    def __init__(self, gecko: TCPGecko | CemuGecko, log_level: str, auto_logging: bool, aroma: bool,
                 cemu: bool, stack: int | None, static_mem_adr: int) -> None:
        self._gecko = gecko
        self._log_path = userpaths.get_my_documents() + "/Splatlogger/logs"
        self._log_level = log_level
        self._auto_logging = auto_logging
        self._static_mem_adr = static_mem_adr
        self._date = datetime.now()
        self._align = 2 if auto_logging else 0
        self._aroma = aroma
        self._cemu = cemu
        self._stack = stack
        self._versus_rule = 0
        self._disconnect = False

    def create_new_log(self) -> None:
        """Initialize a new log file."""
        if not os.path.isdir(f"{self._log_path}/{self._date.strftime('%Y-%m-%d')}"):
            os.makedirs(f"{self._log_path}/{self._date.strftime('%Y-%m-%d')}")

        self._write_log(log=f"Splatlogger log from {self._date.strftime('%Y-%m-%d %H:%M:%S')}\n", mode="w")

    def log_match(self, date: datetime, session_id: int,
                  match_count: int, player_info_list: list[PlayerInfo]) -> None:
        """Write player and match data to the log file."""
        match_log = self._new_match(date, session_id, match_count)
        if self._log_level == "standard":
            match_log += (
                f"\n{'Player':<8} | {'PID (Hex)':<10} | {'PID (Dec)':<10} | {'PNID':<16} | Name\n"
                f"{'-' * 73}\n"
            )

        for player_info in player_info_list:
            match_log += (
                f"Player {player_info.idx + 1} | "
                f"0x{f'{player_info.pid:X}':<8} | "
                f"{player_info.pid:<10} | "
                f"{player_info.pnid:<16} | "
                f"{player_info.name} "
                f"{f'({player_info.mii_name})' if player_info.name != player_info.mii_name else ''}\n"
            ) if self._log_level == "standard" else (
                f"\n{' ' * self._align}[Player {player_info.idx + 1}]\n"
                f"{' ' * (self._align + 2)}Name: {player_info.name}"
                f"{' (Mii name: ' + player_info.mii_name + ')' if player_info.name != player_info.mii_name else ''}\n"
                f"{' ' * (self._align + 2)}PID: 0x{player_info.pid:X} ({player_info.pid})\n"
                f"{' ' * (self._align + 2)}PNID: {player_info.pnid}\n"
                f"{' ' * (self._align + 2)}Team: {Names.TEAM_NAME.get(player_info.team, 'Unknown')} "
                f"({player_info.team})\n"
                f"{' ' * (self._align + 2)}Level: {player_info.level}\n"
                f"{' ' * (self._align + 2)}Rank: {Names.RANK_NAME.get(player_info.rank, 'Unknown')} "
                f"({player_info.rank})\n"
                f"{' ' * (self._align + 2)}Appearance: Gender: {Names.GENDER_NAME.get(player_info.gender, 'Unknown')} "
                f"({player_info.gender}) | "
                f"Skin tone: {player_info.skin_tone} | "
                f"Eye color: {Names.EYE_COLOR_NAME.get(player_info.eye_color, 'Unknown')} ({player_info.eye_color})\n"
                f"{' ' * (self._align + 2)}Gear: Headgear: {Names.HEADGEAR_NAME.get(player_info.headgear, 'Unknown')} "
                f"({player_info.headgear}) | "
                f"Clothes: {Names.CLOTHES_NAME.get(player_info.clothes, 'Unknown')} ({player_info.clothes}) | "
                f"Shoes: {Names.SHOES_NAME.get(player_info.shoes, 'Unknown')} ({player_info.shoes})\n"
                f"{' ' * (self._align + 2)}Weapons: Main: {Names.WEAPON_NAME.get(player_info.weapon, 'Unknown')} "
                f"({player_info.weapon}) | "
                f"Sub: {Names.SUB_WEAPON_NAME.get(player_info.sub_weapon, 'Unknown')} ({player_info.sub_weapon}) | "
                f"Special: {Names.SPECIAL_WEAPON_NAME.get(player_info.special_weapon, 'Unknown')} "
                f"({player_info.special_weapon})\n"
            )

            if self._log_level == "stats" and not self._disconnect:
                match_log += self._get_stats(player_info.team, player_info)

        if self._log_level == "standard":
            match_log += (f"\nSession ID: 0x{session_id:X} ({session_id})\n" +
                         (f"Fetched at: {date.strftime('%H:%M:%S')}\n" if self._auto_logging else ""))

        self._write_log(log=match_log, mode="a")

    def _write_log(self, log: str, mode: str) -> None:
        with open(f"{self._log_path}/{self._date.strftime('%Y-%m-%d')}/"
                  f"{self._date.strftime('%Y-%m-%d %H-%M-%S')} log.txt",
                  mode, encoding="utf-8") as f:
            f.write(log)

    def _new_match(self, date: datetime, session_id: int, match_count: int) -> str:
        self._disconnect = False
        self._versus_rule = self._gecko.peek8(self._static_mem_adr + Offsets.STATICMEM_VERSUS_RULE)
        match_hour = self._gecko.peek8(self._static_mem_adr + Offsets.STATICMEM_MATCH_HOUR)
        versus_mode = self._gecko.peek8(self._static_mem_adr + Offsets.STATICMEM_VERSUS_MODE)
        stage = self._gecko.read_string(self._static_mem_adr + Offsets.STATICMEM_STAGE, length=32).split("\u0000")[0]

        match_info = ""
        if self._log_level == "standard":
            match_info += f"\nMatch {match_count}\n"
        elif self._log_level != "standard" and self._auto_logging:
            match_info += (
                f"\n[Match {match_count}]\n"
                f"{' ' * self._align}Time: {date.strftime('%H:%M:%S')}\n"
                f"{' ' * self._align}Session ID: 0x{session_id:X} ({session_id})\n"
                f"{' ' * self._align}Lobby type: {Names.VERSUS_MODE_NAME.get(versus_mode, 'Unknown')} "
                f"({versus_mode})\n"
                f"{' ' * self._align}Game mode: {Names.VERSUS_RULE_NAME.get(self._versus_rule, 'Unknown')} "
                f"({self._versus_rule})\n"
                f"{' ' * self._align}Stage: {Names.STAGE_NAME.get(stage, 'Unknown')} ({stage})\n"
                f"{' ' * self._align}Match hour: {Names.MATCH_HOUR_NAME.get(match_hour, 'Unknown')} ({match_hour})\n"
            )
        else:
            match_info += (
                f"\n{' ' * self._align}Session ID: 0x{session_id:X} ({session_id})\n"
                f"{' ' * self._align}Lobby type: {Names.VERSUS_MODE_NAME.get(versus_mode, 'Unknown')} "
                f"({versus_mode})\n"
                f"{' ' * self._align}Game mode: {Names.VERSUS_RULE_NAME.get(self._versus_rule, 'Unknown')} "
                f"({self._versus_rule})\n"
                f"{' ' * self._align}Stage: {Names.STAGE_NAME.get(stage, 'Unknown')} ({stage})\n"
                f"{' ' * self._align}Match hour: {Names.MATCH_HOUR_NAME.get(match_hour, 'Unknown')} ({match_hour})\n"
            )

        return match_info

    def _get_stats(self, team: int, player_info: PlayerInfo) -> str:
        stats_adr: int = Addresses.STATS
        win_team_adr: int = Addresses.WIN_TEAM
        ptr_offset = 0
        if self._cemu:
            ptr_offset = 0x503000
            if isinstance(self._stack, int):
                stats_adr = self._stack + Offsets.CEMU_STATS
                win_team_adr = self._stack + Offsets.CEMU_WIN_TEAM

        if self._aroma:
            stats_adr -= 0x30
            win_team_adr -= 0x30

        stats = self._gecko.peek_raw(stats_adr, length=0x124)

        # Buffer player 1 data until stats are updated.
        if player_info.idx == 0:
            while self._gecko.peek_raw(stats_adr, length=0x124) == stats:
                if self._gecko.peek32(Pointers.MAIN_MGR_VS_GAME - ptr_offset) == 0:  # Fallback in case the match is not finished.
                    self._disconnect = True
                    break

                time.sleep(5)

        if not self._disconnect:
            winning_team = self._gecko.peek8(win_team_adr)
            stats = self._gecko.peek_raw(stats_adr, length=0x124)
            offset = player_info.idx * 0x20
            points = int.from_bytes(stats[offset + 0x3A:offset + 0x3C], byteorder="big")
            kills = int.from_bytes(stats[offset + 0x3E:offset + 0x40], byteorder="big")
            deaths = int.from_bytes(stats[offset + 0x42:offset + 0x44], byteorder="big")

            # Only log points in turf war cause in ranked they're the same for all players.
            points_log = ""
            if self._versus_rule == 0:
                points_log = f"{' ' * (self._align + 2)}Points: {points + 1000}p ({points}p w/o win bonus)\n" if\
                    team == winning_team else f"{' ' * (self._align + 2)}Points: {points}p\n"

            player_stats = (
                f"{points_log}"
                f"{' ' * (self._align + 2)}K/D: {kills}/{deaths}\n"
                f"{' ' * (self._align + 2)}Result: {'Win' if team == winning_team else 'Lose'}\n"
            )

            return player_stats

        return ""
