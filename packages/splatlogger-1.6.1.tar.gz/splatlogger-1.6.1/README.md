# Splatlogger
A CLI PID (Principal ID)/PNID grabber and match logger for Splatoon, written in Python.

## Prerequisites
To install the package, you'll need to have Python 3.11 or newer installed on your system.
On Android devices you can use Termux.
Python is not required for the Windows executable.

Both the Wii U and Cemu (Windows and Linux only) are supported.

Your Wii U will need to have either the Tiramisu or Aroma environment set up or have another way to run homebrew,
such as Haxchi or the browser exploit.

On Tiramisu, use [TCPGecko](https://github.com/BullyWiiPlaza/tcpgecko), [Geckiine](https://hb-app.store/wiiu/geckiine),
or any other app with the TCPGecko server.

On Aroma, install the [TCPGecko Aroma plugin](https://codeberg.org/ShadowDoggo/TCPGeckoAroma).

## Installation
On Windows, you can use the executable provided on the releases page.
Though if you already have Python installed, it's recommended to use the package.

To install the package from PyPI, run:
```
python -m pip install Splatlogger
```

Or download the latest release from Codeberg and run:
```
python -m pip install path/to/Splatlogger-v1.x.zip
```

If you do have Python installed but do not wish to install the package, you can run the module directly from the source code.

Install the required dependencies:
```
cd path/to/Splatlogger-v1.x/ && pip install -r requirements.txt
```

Then run the module:
```
cd src/ && python -m splatlogger
```

## Usage
Run Splatlogger with:
```
python -m splatlogger -ip IP [options]
```
where `IP` is your Wii U's LAN IP address
(if you have your scripts directory in your PATH, you can omit `python -m`).

If using the Windows executable, run:
```
path/to/Splatlogger-1.x.exe -ip IP [options]
```

Options:
- `-log-level [option]` - Set how much data should be logged.
  - `none` - Don't create a log file.
  - `standard` - Log only basic player information, the same as what's printed to the console (default).
  - `extended` - Log all player information and additional match information.
  - `stats` - Same as above with the addition of player stats (points, K/D). Requires the match to end to finish logging.

- `-auto [option]` - Enable auto logging. When enabled will automatically log every match you play (log level must be at least `standard`).
  - `all` - Save a log of all matches you play (default).
  - `latest` - Save a log of only the latest match.

- `-aroma` - Switch to Aroma mode. Enable if using the TCPGecko Aroma plugin.

- `-cemu [PID]` - Switch to Cemu mode. The `-ip` argument is not required and will be ignored.
  - `PID` - PID of the Cemu process (optional).

- `-stack Address (in hex)` - (Cemu only) Beginning address of the stack space for Default Core 1 (Debug > View PPC threads).
Reuired for logging stats, not needed otherwise.

  <img src="stack.png" width="600" alt="(example)">

- `-silent` - Disable printing logs to the console.

Logs are saved in `/[User]/Documents/Splatlogger/logs/[Date]`.

To always run with the same IP and options without having to type them in manually, create an `args.txt` file in
`/[User]/Documents/Splatlogger` and put the arguments following `splatlogger` in there.
Afterward any arguments passed through the command line will be ignored.

Only one program can be connected to TCPGecko at a time. If you have something else connected, disconnect it beforehand.

## Credits
- [pyGecko](https://github.com/wiiudev/pyGecko) authors for most of `tcpgecko.py`.

- Everyone who contributed to [PNIDGrab](https://github.com/JerrySM64/PNIDGrab) and other similar PID grabbers as those were used as a reference.
