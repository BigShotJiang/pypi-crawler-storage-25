from rich.console import Console
from rich.text import Text

from src.logo.logo import get_logo_lines
from src.tui.color import get_color
from src.tui.terminal import get_terminal_size

# Box-drawing: outer borders = heavy, middle divider = light
H_HEAVY = "━"
V_HEAVY = "┃"
V_LIGHT = "│"
TL = "┏"  # top-left
TR = "┓"  # top-right
BL = "┗"  # bottom-left
BR = "┛"  # bottom-right

LEFT_WIDTH = 40
LOGO_WIDE_MIN = 80


def render_signboard(
    console: Console, *, model: str, cwd: str, theme: str, version: str,
) -> None:
    """Render the startup signboard, two-column if wide enough."""
    width = get_terminal_size().columns
    border_color = get_color("signboard_border", theme)

    if width >= LOGO_WIDE_MIN:
        _render_wide(console, width, border_color, model, cwd, version)
    else:
        _render_narrow(console, width, border_color, model, cwd, version)


def _render_wide(
    console: Console,
    width: int,
    border_color: str,
    model: str,
    cwd: str,
    version: str,
) -> None:
    logo_lines = get_logo_lines()
    left_inner = LEFT_WIDTH - 2
    right_width = width - LEFT_WIDTH - 2

    right_texts = [
        Text("Tips for getting started", style=border_color),
        "Type /exit to quit, /help for help.",
        "",
        "",
        "",
        "",
        "",
    ]

    left_below: list[str | Text] = [
        Text("Lightweight AI coding agent", style=border_color),
        "",
        f"{model} \xb7 API Usage Billing",
        _truncate(cwd, left_inner),
    ]

    _draw_header(console, width, border_color, version)
    for i in range(len(logo_lines)):
        left = _pad_center(logo_lines[i], left_inner)
        rtext = right_texts[i]
        if isinstance(rtext, Text):
            right = Text(rtext.plain.ljust(right_width), style=rtext.style)
        else:
            right = Text(rtext.ljust(right_width))
        line = Text()
        line.append(V_HEAVY, style=border_color)
        line.append(left)
        line.append(V_LIGHT, style=border_color)
        line.append(" ")
        line.append(right)
        line.append(V_HEAVY, style=border_color)
        console.print(line)
    for info in left_below:
        if isinstance(info, Text):
            left = _pad_center(info, left_inner)
        else:
            left = _pad_center(Text(info), left_inner)
        right = "".ljust(right_width)
        line = Text()
        line.append(V_HEAVY, style=border_color)
        line.append(left)
        line.append(V_LIGHT, style=border_color)
        line.append(" ")
        line.append(right)
        line.append(V_HEAVY, style=border_color)
        console.print(line)

    _draw_footer(console, width, border_color)


def _render_narrow(
    console: Console,
    width: int,
    border_color: str,
    model: str,
    cwd: str,
    version: str,
) -> None:
    inner = width - 2
    logo_lines = get_logo_lines()

    _draw_header(console, width, border_color, version)
    for logo_line in logo_lines:
        _draw_centered(console, logo_line, inner, border_color)
    _draw_centered(
        console, Text("Lightweight AI coding agent", style=border_color),
        inner, border_color,
    )
    _draw_centered(console, Text(""), inner, border_color)
    _draw_centered(
        console, Text(f"{model} \xb7 API Usage Billing"), inner, border_color,
    )
    _draw_centered(console, Text(str(cwd)), inner, border_color)
    _draw_footer(console, width, border_color)


def _draw_header(
    console: Console, width: int, border_color: str, version: str,
) -> None:
    title = f"━━━ NanoCode v{version} "
    fill = width - len(title) - 2
    line = Text(TL, style=border_color)
    line.append(title + H_HEAVY * fill, style=border_color)
    line.append(TR, style=border_color)
    console.print(line)


def _draw_footer(console: Console, width: int, border_color: str) -> None:
    console.print(
        Text(BL, style=border_color)
        + Text(H_HEAVY * (width - 2), style=border_color)
        + Text(BR, style=border_color)
    )


def _draw_centered(
    console: Console, content: Text, inner: int, border_color: str,
) -> None:
    pad = (inner - content.cell_len) // 2
    line = Text(V_HEAVY, style=border_color)
    line.append(" " * pad)
    line.append(content)
    line.append(" " * (inner - content.cell_len - pad))
    line.append(V_HEAVY, style=border_color)
    console.print(line)


def _pad_center(content: str | Text, target_width: int) -> Text:
    if isinstance(content, str):
        content = Text(content)
    if content.cell_len > target_width:
        content = Text("…" + content.plain[-(target_width - 1):])
    pad = (target_width - content.cell_len) // 2
    result = Text()
    result.append(" " * pad)
    result.append(content)
    result.append(" " * (target_width - content.cell_len - pad))
    return result


def _truncate(text: str, max_width: int) -> str:
    if len(text) <= max_width:
        return text
    return "…" + text[-(max_width - 1):]
