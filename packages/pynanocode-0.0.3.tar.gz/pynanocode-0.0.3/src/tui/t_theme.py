import os
import re
import select
import subprocess
import sys
import termios
import time
import tty


def detect_t_theme() -> str:
    """Detect terminal color theme. Returns ``"light"`` or ``"dark"`` (default)."""
    term = _detect_terminal()

    if term == "terminal_app":
        return _detect_terminal_app()
    if term == "iterm":
        return _detect_iterm()
    if term == "vscode":
        return _detect_vscode()

    return _fallback_colorfgbg()


def _detect_terminal() -> str | None:
    term_program = os.environ.get("TERM_PROGRAM", "")

    if term_program == "Apple_Terminal":
        return "terminal_app"
    if term_program == "iTerm.app" or "ITERM_SESSION_ID" in os.environ:
        return "iterm"
    if term_program == "vscode" or "VSCODE_INJECTION" in os.environ:
        return "vscode"

    return None


def _detect_terminal_app() -> str:
    """macOS Terminal.app — query background color of front window via osascript."""
    if sys.platform != "darwin":
        return "dark"

    script = (
        'tell application "Terminal"'
        " to get background color of selected tab of front window"
    )
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, timeout=3,
        )
        if result.returncode != 0:
            return "dark"
        # output e.g. "65535, 65535, 65535" (16-bit RGB)
        nums = [int(x.strip()) for x in result.stdout.strip().split(",")]
        if len(nums) >= 2 and nums[0] < 30000 and nums[1] < 30000:
            return "dark"
        return "light"
    except (subprocess.TimeoutExpired, ValueError, OSError):
        return "dark"


def _detect_iterm() -> str:
    """iTerm2 — COLORFGBG env var suffix 0-6 → dark."""
    value = os.environ.get("COLORFGBG", "")
    if not value:
        return "dark"
    try:
        bg = int(value.split(";")[-1])
        return "dark" if bg <= 6 else "light"
    except (ValueError, IndexError):
        return "dark"


def _detect_vscode() -> str:
    """VS Code terminal — OSC 11 true-color query."""
    if sys.platform != "darwin":
        return "dark"

    rgb = _query_osc_11()
    if rgb is None:
        return _fallback_colorfgbg()

    luminance = 0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]
    return "dark" if luminance < 128 else "light"


def _query_osc_11() -> tuple[int, int, int] | None:
    """Send OSC 11 query and parse the background-color response."""
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return None

    fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
    except termios.error:
        return None

    try:
        tty.setraw(fd)
        sys.stdout.write("\033]11;?\a")
        sys.stdout.flush()

        response = ""
        deadline = time.monotonic() + 0.3
        while time.monotonic() < deadline:
            r, _, _ = select.select([sys.stdin], [], [], 0.05)
            if not r:
                break
            ch = sys.stdin.read(1)
            if not ch:
                break
            response += ch
            if ch == "\a" or response.endswith("\033\\"):
                break

        m = re.search(
            r"rgb:([0-9A-Fa-f]{1,4})/([0-9A-Fa-f]{1,4})/([0-9A-Fa-f]{1,4})",
            response,
        )
        if m:
            r = int(m.group(1), 16) >> 8
            g = int(m.group(2), 16) >> 8
            b = int(m.group(3), 16) >> 8
            return (r, g, b)
        return None
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _fallback_colorfgbg() -> str:
    value = os.environ.get("COLORFGBG", "")
    if value:
        try:
            bg = int(value.split(";")[-1])
            return "light" if bg >= 8 else "dark"
        except (ValueError, IndexError):
            pass
    return "dark"
