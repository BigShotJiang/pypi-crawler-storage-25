import shutil
from typing import NamedTuple


class TermSize(NamedTuple):
    columns: int
    lines: int


def get_terminal_size() -> TermSize:
    """Return the current terminal window size in columns and lines."""
    size = shutil.get_terminal_size(fallback=(80, 24))
    return TermSize(size.columns, size.lines)
