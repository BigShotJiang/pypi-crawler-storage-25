# ── Semantic color tokens ────────────────────────────────────────────
# Every color in the TUI is defined here, keyed by semantic role.
# Supports dark and light terminal themes.
#
# Naming convention:
#   text_*     foreground / text colors
#   bg_*       background colors
#   prompt_*   input-area prompt arrow
#   history_*  history line (echoed user input)
#   logo_*     pixel-art logo

TUI_COLOR_MAP: dict[str, dict[str, str]] = {
    "dark": {
        # Text
        "text_primary": "default",
        "text_subdued": "dim",
        "text_error": "red",
        # Input prompt (arrow in the input area)
        "prompt_arrow": "#4488ff",
        # History line (user input echoed back)
        "history_arrow": "#4f504f",
        "history_text": "dim",
        "history_bg": "#373737",
        # Input frame separators
        "input_frame_sep": "dim",
        # Backgrounds
        "bg_primary": "default",
        # Signboard
        "signboard_border": "#3579be",
        "signboard_accent": "#3579be",
        # Logo (hamburger pixel art)
        "logo_fill": "rgb(247,201,16)",
        "logo_stroke": "rgb(58,40,22)",
    },
    "light": {
        # Text
        "text_primary": "default",
        "text_subdued": "dim",
        "text_error": "red",
        # Input prompt
        "prompt_arrow": "#0044cc",
        # History line
        "history_arrow": "#8a8a8a",
        "history_text": "dim",
        "history_bg": "grey70",
        # Input frame separators
        "input_frame_sep": "dim",
        # Backgrounds
        "bg_primary": "default",
        # Signboard
        "signboard_border": "#3579be",
        "signboard_accent": "#3579be",
        # Logo
        "logo_fill": "rgb(247,201,16)",
        "logo_stroke": "rgb(58,40,22)",
    },
}


def get_color(token: str, theme: str = "dark") -> str:
    """Return the color value for *token* in the given *theme*."""
    return TUI_COLOR_MAP[theme][token]


def get_style(token: str, theme: str = "dark") -> str:
    """Return a Rich markup style string for *token*.

    For foreground colors:  ``"[#4f504f]"`` / ``"[dim]"``
    For background colors:  ``"[on #373737]"``
    """
    value = get_color(token, theme)
    if token.startswith("bg_"):
        return f"[on {value}]"
    return f"[{value}]"


def ansi_fg(hex_rgb: str) -> str:
    """Convert a hex RGB like ``#4488ff`` to an ANSI true-color escape."""
    r = int(hex_rgb[1:3], 16)
    g = int(hex_rgb[3:5], 16)
    b = int(hex_rgb[5:7], 16)
    return f"\033[38;2;{r};{g};{b}m"


def get_prompt_ansi(theme: str = "dark") -> tuple[str, str]:
    """Return (open, close) ANSI escape pair for the input prompt arrow."""
    color = get_color("prompt_arrow", theme)
    return ansi_fg(color), "\033[0m"


def get_logo_colors() -> dict[str, str | None]:
    """Return the logo color map used by the pixel renderer.

    Keys are pixel characters (``B``, ``Y``, ``.``), values are Rich color
    strings or ``None`` (transparent). Always uses the dark palette — logo
    colors are fixed and not theme-dependent.
    """
    return {
        "B": TUI_COLOR_MAP["dark"]["logo_stroke"],
        "Y": TUI_COLOR_MAP["dark"]["logo_fill"],
        ".": None,
    }
