from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator

from src.messages import AssistantMessage, StreamEvent, UserMessage


class ModelProvider(ABC):
    @abstractmethod
    async def stream_message(
        self,
        system: str,
        messages: list[UserMessage | AssistantMessage],
        tools: list[dict],
    ) -> AsyncGenerator[StreamEvent | AssistantMessage, None]:
        ...

    @abstractmethod
    async def send_message(
        self,
        system: str,
        messages: list[UserMessage | AssistantMessage],
        tools: list[dict],
    ) -> AssistantMessage:
        ...
