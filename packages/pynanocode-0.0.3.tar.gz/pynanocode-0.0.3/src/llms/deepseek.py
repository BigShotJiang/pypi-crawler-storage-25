import json
from typing import Any

from anthropic import AsyncAnthropic

from src.llms.base import ModelProvider
from src.messages import (
    AssistantMessage,
    StreamEvent,
    TextBlock,
    ThinkingBlock,
    ToolUseBlock,
    UserMessage,
)


class DeepSeekProvider(ModelProvider):
    def __init__(
        self,
        api_key: str,
        base_url: str,
        model: str = "deepseek-v4-pro",
        max_tokens: int = 16000,
        thinking_budget: int = 0,
    ):
        self.client = AsyncAnthropic(base_url=base_url, api_key=api_key, max_retries=2)
        self.model = model
        self.max_tokens = max_tokens
        self.thinking_budget = thinking_budget

    async def stream_message(
        self,
        system: str,
        messages: list[UserMessage | AssistantMessage],
        tools: list[dict],
    ) -> Any:  # AsyncGenerator[StreamEvent | AssistantMessage, None]
        params = self._build_params(system, messages, tools)
        stream = self.client.messages.stream(**params)

        blocks: list[TextBlock | ThinkingBlock | ToolUseBlock] = []
        current_type: str = ""
        current_id: str = ""
        current_name: str = ""
        accumulated_text: str = ""
        accumulated_json: str = ""
        accumulated_thinking: str = ""
        accumulated_signature: str = ""
        stop_reason: str = ""
        usage: dict[str, Any] = {}

        async with stream as s:
            async for event in s:
                event_type = event.type

                if event_type == "content_block_start":
                    block = event.content_block
                    current_type = block.type

                    if current_type == "text":
                        accumulated_text = ""
                    elif current_type == "tool_use":
                        current_id = block.id
                        current_name = block.name
                        accumulated_json = ""
                    elif current_type == "thinking":
                        accumulated_thinking = ""
                        accumulated_signature = ""
                        accumulated_text = ""

                elif event_type == "content_block_delta":
                    delta = event.delta
                    delta_type = delta.type

                    if delta_type == "text_delta":
                        accumulated_text += delta.text
                        yield StreamEvent(
                            type="content_block_delta",
                            data={"type": "text", "text": delta.text},
                        )
                    elif delta_type == "input_json_delta":
                        accumulated_json += delta.partial_json
                    elif delta_type == "thinking_delta":
                        accumulated_thinking += delta.thinking
                    elif delta_type == "signature_delta":
                        accumulated_signature += delta.signature

                elif event_type == "content_block_stop":
                    if current_type == "text":
                        if accumulated_text:
                            blocks.append(TextBlock(text=accumulated_text))
                    elif current_type == "tool_use":
                        try:
                            parsed = (
                                json.loads(accumulated_json)
                                if accumulated_json
                                else {}
                            )
                        except json.JSONDecodeError:
                            parsed = {}
                        blocks.append(
                            ToolUseBlock(
                                id=current_id,
                                name=current_name,
                                input=parsed,
                            )
                        )
                    elif current_type == "thinking":
                        blocks.append(
                            ThinkingBlock(
                                thinking=accumulated_thinking,
                                signature=accumulated_signature,
                            )
                        )

                elif event_type == "message_delta":
                    stop_reason = event.delta.stop_reason or ""
                    if event.usage:
                        usage = event.usage.model_dump(exclude_none=False)
                    else:
                        usage = {}

                elif event_type == "message_stop":
                    pass

        msg = AssistantMessage(
            content=blocks,
            model=self.model,
            stop_reason=stop_reason,
            usage=usage,
        )
        yield msg

    async def send_message(
        self,
        system: str,
        messages: list[UserMessage | AssistantMessage],
        tools: list[dict],
    ) -> AssistantMessage:
        params = self._build_params(system, messages, tools)
        response = await self.client.messages.create(**params)

        blocks: list[TextBlock | ThinkingBlock | ToolUseBlock] = []
        for block in response.content:
            if block.type == "text":
                blocks.append(TextBlock(text=block.text))
            elif block.type == "tool_use":
                blocks.append(
                    ToolUseBlock(
                        id=block.id,
                        name=block.name,
                        input=block.input,
                    )
                )
            elif block.type == "thinking":
                blocks.append(
                    ThinkingBlock(
                        thinking=block.thinking,
                        signature=getattr(block, "signature", ""),
                    )
                )

        return AssistantMessage(
            content=blocks,
            model=response.model,
            stop_reason=response.stop_reason or "",
            usage=response.usage.model_dump(exclude_none=False),
        )

    def _build_params(
        self,
        system: str,
        messages: list[UserMessage | AssistantMessage],
        tools: list[dict],
    ) -> dict:
        params: dict[str, Any] = {
            "model": self.model,
            "system": system,
            "messages": [m.to_api_dict() for m in messages],
            "max_tokens": self.max_tokens,
        }
        if tools:
            params["tools"] = tools
        if self.thinking_budget > 0:
            params["thinking"] = {
                "type": "enabled",
                "budget_tokens": self.thinking_budget,
            }
        return params
