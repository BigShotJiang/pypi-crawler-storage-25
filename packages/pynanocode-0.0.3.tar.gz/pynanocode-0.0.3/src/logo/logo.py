from rich.console import Console
from rich.style import Style
from rich.text import Text

from src.tui import get_logo_colors

PIXELS = [
    "...BBBB...",
    "..BYYYYB..",
    "..BYYYYB..",
    ".BYYYYB...",
    ".BYYYYB...",
    "BYYYYYYBBB",
    "BYYYYYYYYB",
    ".BBBBYYYB.",
    "....BYYB..",
    "...BYYB...",
    "...BYB....",
    "..BYB.....",
    "..BB......",
]


def get_logo_lines() -> list[Text]:
    """Return the pixel-art logo as a list of Rich :class:`Text` lines."""
    color_map = get_logo_colors()
    rows = list(PIXELS)
    if len(rows) % 2 == 1:
        rows = [*rows, "." * len(rows[0])]

    lines: list[Text] = []
    for i in range(0, len(rows), 2):
        top, bottom = rows[i], rows[i + 1]
        text = Text()
        for ct, cb in zip(top, bottom, strict=True):
            top_color = color_map[ct]
            bot_color = color_map[cb]
            style = Style(
                color=top_color if top_color else "default",
                bgcolor=bot_color if bot_color else "default",
            )
            if top_color is not None:
                text.append("▀", style=style)
            elif bot_color is not None:
                text.append("▄", style=Style(color=bot_color))
            else:
                text.append(" ")
        lines.append(text)
    return lines


def terminal_logo(console: Console | None = None) -> None:
    """Render the pixel-art logo to the terminal."""
    if console is None:
        console = Console()
    for line in get_logo_lines():
        console.print(line)
