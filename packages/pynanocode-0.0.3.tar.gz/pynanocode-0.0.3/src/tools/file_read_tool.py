from typing import Any

from src.tool_base import Tool, ToolContext


class FileReadTool(Tool):
    name = "read"
    description = (
        "Read a file from the local filesystem. "
        "Returns the file content with line numbers. "
        "Use to inspect code, configuration, or any text file."
    )
    input_schema = {  # noqa: RUF012
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Absolute path to the file to read.",
            },
            "offset": {
                "type": "integer",
                "description": "Line number to start reading from.",
            },
            "limit": {
                "type": "integer",
                "description": "Maximum number of lines to read.",
            },
        },
        "required": ["file_path"],
    }

    def is_concurrency_safe(self) -> bool:
        return True

    def is_read_only(self) -> bool:
        return True

    async def call(self, params: dict[str, Any], context: ToolContext) -> str:
        path = params["file_path"]
        offset = params.get("offset", 1)
        limit = params.get("limit", 2000)

        try:
            with open(path, encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
        except FileNotFoundError:
            return f"Error: file not found: {path}"
        except PermissionError:
            return f"Error: permission denied: {path}"
        except OSError as exc:
            return f"Error: {exc}"

        if offset > 1:
            lines = lines[offset - 1 :]
        if limit:
            lines = lines[:limit]

        if not lines:
            return "(file is empty)"

        total = offset - 1 + len(lines)
        max_num = min(total, offset - 1 + limit) if limit else total
        width = len(str(max_num))
        numbered = [
            f"{i + offset:>{width}}\t{line.rstrip()}"
            for i, line in enumerate(lines)
        ]
        return "\n".join(numbered)
