import asyncio
import os
from typing import Any

from src.tool_base import Tool, ToolContext


class BashTool(Tool):
    name = "bash"
    description = (
        "Execute a shell command in the user's environment. "
        "Use for running code, building, testing, installing packages, "
        "or any other shell operations. The command runs in the current "
        "working directory and the shell state does not persist between calls."
    )
    input_schema = {  # noqa: RUF012
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The shell command to execute.",
            },
            "timeout": {
                "type": "integer",
                "description": "Timeout in milliseconds (default 120000, max 600000).",
            },
        },
        "required": ["command"],
    }

    def is_concurrency_safe(self) -> bool:
        return False

    def is_read_only(self) -> bool:
        return False

    async def call(self, params: dict[str, Any], context: ToolContext) -> str:
        command = params["command"]
        timeout_ms = min(params.get("timeout", 120000), 600000)
        timeout_sec = timeout_ms / 1000.0

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=context.cwd,
                env={**os.environ, "PYTHONUNBUFFERED": "1"},
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_sec
            )
            out = stdout.decode("utf-8", errors="replace")
            err = stderr.decode("utf-8", errors="replace")

            lines = []
            if out:
                lines.append(out.rstrip())
            if err:
                lines.append(err.rstrip())
            if not out and not err:
                lines.append(f"(exit code: {proc.returncode})")
            return "\n".join(lines)
        except asyncio.TimeoutError:
            return f"Error: command timed out after {timeout_ms}ms"
        except Exception as exc:
            return f"Error: {exc}"
