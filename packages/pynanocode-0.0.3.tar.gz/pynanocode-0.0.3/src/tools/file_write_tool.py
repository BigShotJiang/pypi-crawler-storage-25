import os
from typing import Any

from src.tool_base import Tool, ToolContext


class FileWriteTool(Tool):
    name = "write"
    description = (
        "Write content to a file, creating it if it does not exist. "
        "Overwrites the file if it already exists. "
        "Use to create new files or completely rewrite existing ones."
    )
    input_schema = {  # noqa: RUF012
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Absolute path to the file to write.",
            },
            "content": {
                "type": "string",
                "description": "The content to write to the file.",
            },
        },
        "required": ["file_path", "content"],
    }

    def is_concurrency_safe(self) -> bool:
        return False

    def is_read_only(self) -> bool:
        return False

    async def call(self, params: dict[str, Any], context: ToolContext) -> str:
        path = params["file_path"]
        content = params["content"]

        parent = os.path.dirname(path)
        if parent:
            try:
                os.makedirs(parent, exist_ok=True)
            except OSError as exc:
                return f"Error: cannot create parent directory: {exc}"

        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
        except PermissionError:
            return f"Error: permission denied: {path}"
        except OSError as exc:
            return f"Error: {exc}"

        line_count = content.count("\n") + 1 if content else 0
        size = len(content.encode("utf-8"))
        return f"Wrote {line_count} lines ({size} bytes) to {path}"
