from typing import Any

from src.tool_base import Tool, ToolContext


class FileEditTool(Tool):
    name = "edit"
    description = (
        "Perform exact string replacements in an existing file. "
        "Use for surgical edits without rewriting the entire file. "
        "The edit will fail if old_string is not found or is not unique."
    )
    input_schema = {  # noqa: RUF012
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Absolute path to the file to edit.",
            },
            "old_string": {
                "type": "string",
                "description": "The exact text to replace.",
            },
            "new_string": {
                "type": "string",
                "description": "The text to replace it with.",
            },
            "replace_all": {
                "type": "boolean",
                "description": "Replace all occurrences instead of just the first.",
            },
        },
        "required": ["file_path", "old_string", "new_string"],
    }

    def is_concurrency_safe(self) -> bool:
        return False

    def is_read_only(self) -> bool:
        return False

    async def call(self, params: dict[str, Any], context: ToolContext) -> str:
        path = params["file_path"]
        old = params["old_string"]
        new = params["new_string"]
        replace_all = params.get("replace_all", False)

        if old == new:
            return "Error: old_string and new_string are identical"

        try:
            with open(path, encoding="utf-8") as f:
                original = f.read()
        except FileNotFoundError:
            return f"Error: file not found: {path}"
        except PermissionError:
            return f"Error: permission denied: {path}"

        if old not in original:
            return (
                f"Error: old_string not found in {path}. "
                "The text must match exactly, including whitespace."
            )

        count = original.count(old)
        if count > 1 and not replace_all:
            return (
                f"Error: old_string appears {count} times in {path}. "
                "Add more surrounding context to make it unique, "
                "or set replace_all=True to replace all occurrences."
            )

        if replace_all:
            result = original.replace(old, new)
            replaced = count
        else:
            result = original.replace(old, new, 1)
            replaced = 1

        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(result)
        except PermissionError:
            return f"Error: permission denied writing to: {path}"

        return f"Replaced {replaced} occurrence(s) in {path}"
