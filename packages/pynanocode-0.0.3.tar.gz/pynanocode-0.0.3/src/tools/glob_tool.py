import glob as _glob
import os
from typing import Any

from src.tool_base import Tool, ToolContext


class GlobTool(Tool):
    name = "glob"
    description = (
        "Find files matching a glob pattern. "
        "Returns relative file paths. Use to discover project structure, "
        "find files by naming pattern, or locate all files of a certain type."
    )
    input_schema = {  # noqa: RUF012
        "type": "object",
        "properties": {
            "pattern": {
                "type": "string",
                "description": "Glob pattern to match (e.g., 'src/**/*.py').",
            },
            "path": {
                "type": "string",
                "description": (
                    "Base directory for the search "
                    "(default: current directory)."
                ),
            },
        },
        "required": ["pattern"],
    }

    def is_concurrency_safe(self) -> bool:
        return True

    def is_read_only(self) -> bool:
        return True

    async def call(self, params: dict[str, Any], context: ToolContext) -> str:
        pattern = params["pattern"]
        base = params.get("path", context.cwd)

        full_pattern = os.path.join(base, pattern)
        matches = _glob.glob(full_pattern, recursive=True)

        # Filter out directories and hidden files
        results = [m for m in matches if os.path.isfile(m)]
        results.sort()

        if not results:
            return f"No files matching '{pattern}'"

        # Convert to relative paths if under cwd
        cwd = context.cwd
        display = []
        for p in results:
            try:
                rel = os.path.relpath(p, cwd)
                display.append(rel)
            except ValueError:
                display.append(p)

        if len(display) > 200:
            display = display[:200]
            display.append(f"... truncated (showing 200 of {len(display)} matches)")
        return "\n".join(display)
