import re
from typing import Any

from src.tool_base import Tool, ToolContext


class GrepTool(Tool):
    name = "grep"
    description = (
        "Search for a pattern in files. Returns matching lines with file path, "
        "line number, and content. Use to find function definitions, variable "
        "usages, error messages, or any text pattern in the codebase."
    )
    input_schema = {  # noqa: RUF012
        "type": "object",
        "properties": {
            "pattern": {
                "type": "string",
                "description": "The regex pattern to search for.",
            },
            "path": {
                "type": "string",
                "description": (
                    "Directory or file to search in "
                    "(default: current directory)."
                ),
            },
            "include": {
                "type": "string",
                "description": "File glob pattern to include (e.g., '*.py').",
            },
            "ignore_case": {
                "type": "boolean",
                "description": "Case-insensitive search.",
            },
        },
        "required": ["pattern"],
    }

    def is_concurrency_safe(self) -> bool:
        return True

    def is_read_only(self) -> bool:
        return True

    async def call(self, params: dict[str, Any], context: ToolContext) -> str:
        pattern = params["pattern"]
        search_path = params.get("path", context.cwd)
        include = params.get("include")
        ignore_case = params.get("ignore_case", False)

        flags = re.IGNORECASE if ignore_case else 0
        try:
            regex = re.compile(pattern, flags)
        except re.error as exc:
            return f"Error: invalid regex: {exc}"

        if not await self._is_path_safe(search_path, context.cwd):
            return f"Error: path is outside workspace: {search_path}"

        results: list[str] = []
        import os

        if os.path.isfile(search_path):
            files = [search_path]
        else:
            files = []
            for root, _dirs, filenames in os.walk(search_path):
                if self._should_skip_dir(root):
                    continue
                for fname in filenames:
                    if include and not self._match_glob(fname, include):
                        continue
                    if self._is_binary(fname):
                        continue
                    files.append(os.path.join(root, fname))

        for filepath in files:
            try:
                with open(filepath, encoding="utf-8", errors="replace") as f:
                    for lineno, line in enumerate(f, 1):
                        if regex.search(line):
                            results.append(
                                f"{filepath}:{lineno}: {line.rstrip()}"
                            )
            except (PermissionError, OSError):
                continue

        if not results:
            return f"No matches for '{pattern}'"
        if len(results) > 200:
            results = results[:200]
            results.append(f"... truncated ({len(results)} total matches)")
        return "\n".join(results)

    def _should_skip_dir(self, path: str) -> bool:
        import os

        skip = {".git", "__pycache__", "node_modules", ".venv", "venv", ".tox",
                ".eggs", "dist", "build", ".mypy_cache", ".pytest_cache",
                ".ruff_cache", ".idea", ".vscode"}
        base = os.path.basename(path)
        return base in skip or base.startswith(".")

    def _is_binary(self, filename: str) -> bool:
        import os

        _binary_ext = {
            ".pyc", ".pyo", ".so", ".dylib", ".dll", ".exe", ".bin",
            ".zip", ".tar", ".gz", ".bz2", ".7z", ".rar",
            ".jpg", ".jpeg", ".png", ".gif", ".ico", ".bmp",
            ".mp3", ".mp4", ".avi", ".mov", ".mkv",
            ".ttf", ".otf", ".woff", ".woff2",
            ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
        }
        return os.path.splitext(filename)[1].lower() in _binary_ext

    @staticmethod
    def _match_glob(filename: str, pattern: str) -> bool:
        import fnmatch

        return fnmatch.fnmatch(filename, pattern)

    @staticmethod
    async def _is_path_safe(target: str, workspace: str) -> bool:
        import os

        target_abs = os.path.realpath(target)
        workspace_abs = os.path.realpath(workspace)
        common = os.path.commonpath([target_abs, workspace_abs])
        return common == workspace_abs
