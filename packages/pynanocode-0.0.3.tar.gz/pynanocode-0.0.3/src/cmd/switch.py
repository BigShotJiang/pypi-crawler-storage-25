from src.cmd import Command, CommandResult


class SwitchCommand(Command):
    name = "switch"
    description = "Switch between edit and plan modes"

    def execute(self, args: str, **kwargs) -> CommandResult:
        mode = args.strip().lower()
        if mode not in ("edit", "plan"):
            console = kwargs.get("console")
            if console:
                console.print("Usage: /switch edit | /switch plan")
            return CommandResult()
        return CommandResult(switch_mode=mode)
