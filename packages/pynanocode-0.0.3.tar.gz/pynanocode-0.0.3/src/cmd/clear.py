from src.cmd import Command, CommandResult


class ClearCommand(Command):
    name = "clear"
    description = "Clear the screen"

    def execute(self, args: str, **kwargs) -> CommandResult:
        console = kwargs.get("console")
        if console:
            console.clear()
        return CommandResult()
