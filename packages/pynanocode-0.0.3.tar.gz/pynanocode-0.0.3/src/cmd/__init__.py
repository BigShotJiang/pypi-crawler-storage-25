"""Command framework for NanoCode.

Commands are invoked with ``/name args`` in the input prompt.  The registry
dispatches the leading word (minus ``/``) to a registered command handler;
everything after the first space is passed as *args*.
"""
# ruff: noqa RUF012

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class CommandResult:
    """Returned by a command to signal what the main loop should do next."""

    exit: bool = False
    switch_mode: str | None = None  # "edit" or "plan"


class Command(ABC):
    name: str = ""
    aliases: list[str] = []
    description: str = ""

    @abstractmethod
    def execute(self, args: str, **kwargs) -> CommandResult:
        ...


class CommandRegistry:
    def __init__(self) -> None:
        self._commands: dict[str, Command] = {}

    def register(self, cmd: Command) -> None:
        self._commands[cmd.name] = cmd
        for alias in cmd.aliases:
            self._commands[alias] = cmd

    def dispatch(self, input_line: str, **kwargs) -> CommandResult | None:
        """Try to dispatch *input_line* as a command.

        Returns ``None`` when *input_line* does not start with ``/`` or the
        command name is unknown, so the caller can fall back to the agent.
        """
        stripped = input_line.strip()
        if not stripped.startswith("/"):
            return None

        parts = stripped[1:].split(maxsplit=1)
        name = parts[0]
        args = parts[1] if len(parts) > 1 else ""

        cmd = self._commands.get(name)
        if cmd is None:
            return None
        return cmd.execute(args, **kwargs)
