from src.cmd import Command, CommandResult


class ExitCommand(Command):
    name = "exit"
    aliases = ["quit"]
    description = "Exit Nano Code"

    def execute(self, args: str, **kwargs) -> CommandResult:
        return CommandResult(exit=True)
