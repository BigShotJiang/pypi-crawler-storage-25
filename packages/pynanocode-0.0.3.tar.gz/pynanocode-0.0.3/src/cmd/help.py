from src.cmd import Command, CommandResult


class HelpCommand(Command):
    name = "help"
    description = "Show this help"

    def execute(self, args: str, **kwargs) -> CommandResult:
        console = kwargs.get("console")
        if console:
            console.print(
                "Commands:\n"
                "  /exit, /quit   Exit Nano Code\n"
                "  /help          Show this help\n"
                "  /clear         Clear the screen\n"
                "  /switch edit   Switch to edit mode (full access)\n"
                "  /switch plan   Switch to plan mode (read-only)"
            )
        return CommandResult()
