<p align="center">
    <picture>
        <source srcset="https://raw.githubusercontent.com/zhsh9/nano-code/main/asset/logo-dark.svg" media="(prefers-color-scheme: dark)">
        <source srcset="https://raw.githubusercontent.com/zhsh9/nano-code/main/asset/logo-light.svg" media="(prefers-color-scheme: light)">
        <img src="https://raw.githubusercontent.com/zhsh9/nano-code/main/asset/logo-light.svg" alt="NanoCode logo" width="30%">
    </picture>
</p>
<p align="center"><strong>The lightweight AI coding agent.</strong></p>
<p align="center">
    <img alt="Python" src="https://img.shields.io/badge/Python-3.10-blue?style=flat-square&logo=python&logoColor=white" />
    <a href="https://github.com/zhsh9/nano-code/commits/main">
        <img alt="GitHub Last Commit" src="https://img.shields.io/github/last-commit/zhsh9/nano-code?label=Last%20Commit&style=flat-square&color=green&logo=git&logoColor=white">
    </a>
    <a href="https://pypi.org/project/pynanocode"><img alt="pypi" src="https://img.shields.io/pypi/v/pynanocode?style=flat-square&color=blue&logo=pypi&logoColor=white" /></a>
</p>

<div align="center">
    <img src="https://raw.githubusercontent.com/zhsh9/nano-code/main/asset/demo.gif" alt="EdgeRazor Demo" width="75%">
</div>

---

### Installation

```bash
pip install nanocode
```

### Usage

- Change API key in `.env` or `export THIS_IS_API_KEY="YOUR_KEY"`
- Start your nanocode journey

```bash
$ nanocode
```

### Agents

NanoCode includes two built-in agents you can switch between with the `/switch edit` and `/switch plan` commands.

- `edit`: Default, full-access agent for development work.
- `plan`: Read-only agent for exploration and analysis.
  - Deny editing files by default.
  - Ask permission before running bash commands.

### Built-in Tools

- `bash`: Run shell commands in your terminal.
- `read`: Read any file with line numbers.
- `write`: Create or overwrite a file.
- `edit`: Search-and-replace inside a file.
- `grep`: Search code by regex pattern.
- `glob`: Find files by name pattern.

### LLM Provider

- [x] DeepSeek
- [ ] Anthropic
- [ ] OpenAI