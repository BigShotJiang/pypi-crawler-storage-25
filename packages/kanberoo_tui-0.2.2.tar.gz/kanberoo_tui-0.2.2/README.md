# `kanberoo-tui` has been renamed

This package has been renamed to [`kanbaroo-tui`](https://pypi.org/project/kanbaroo-tui/). The name is a portmanteau of `kangaroo` + `kanban`; the middle letter should have been `a` from the start.

## What to install

```
pip install kanbaroo-tui
```

## Compatibility

This `kanberoo-tui` package remains on PyPI as a version-`0.2.2` compatibility stub that transitively installs `kanbaroo-tui==0.2.2`. `pip install kanberoo-tui` still works; the canonical name going forward is `kanbaroo-tui`. Please update your requirements files and scripts.

## Links

- New package: https://pypi.org/project/kanbaroo-tui/
- GitHub: https://github.com/areese801/kanbaroo
