"""
This package has been renamed to kanbaroo-tui.

Install kanbaroo-tui instead: pip install kanbaroo-tui
"""

import warnings

warnings.warn(
    "The 'kanberoo-tui' package has been renamed to 'kanbaroo-tui'. "
    "Please update your installation: pip install kanbaroo-tui",
    DeprecationWarning,
    stacklevel=2,
)

__version__ = "0.2.2"
