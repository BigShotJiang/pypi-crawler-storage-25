# PYDIFACT-AEK


A wrapper for [pydifact](https://github.com/pydifact/pydifact) that adds support for the Austrian "variant" of the 
EDIFACT format used in medical communication.


## History

The Austrian EDIFACT format, introduced in about 1999 and revised in 2002, implements the EDIFACT standard to some extent.
Or, lets say, it is a subset of the EDIFACT standard, version 1 (exactly: EDIFACT DIR 90.1).

There is a more or less official specification available, we have a copy [here](docs/AEK-edifact-text.doc.pdf).
All software companies operating in the medical sector have implemented this format since 2002.

All software companies operating in the medical sector in Austria have implemented this format since 2002.

Interestingly, an error was introduced during the creation of the specification that apparently went unnoticed by 
everyone: in the original EDIFACT UNB header, a field is designated for date/time, which is a composite 
field: `DATE:TIME`. However, the Austrian EDIFACT standard expects **two** separate data fields for date and time, 
separated by a `+`. Consequently, the format is no longer compatible with the original EDIFACT standard and 
cannot be read or written by standard EDIFACT readers.

Furthermore, over time, a rather peculiar solution was developed to address the need for sending binary files:
PDF files have the characteristic property of beginning with the "magic" code `%PDF` and ending with `%%EOF`. The developers had the "modest" idea of writing an EDIFACT header (as ISO-8859 text), simply appending the PDF file via concatenation, and then adding an EDIFACT trailer at the end.
As a result, the EDIFACT format becomes completely unreadable by standard EDIFACT readers, as segments are no longer properly structured and line length restrictions are not observed.

The PDF format itself doesn't seem to be bothered by this, as PDF readers ignore everything before the start and after the end markers. This approach provided the advantage of being able to wrap PDF files in a pseudo-EDIFACT envelope to add metadata for transmission. It worked, but it certainly isn't elegant.

Over time, they added support for other file formats, like the HL7v2 format (also without proper segments, just plumbed
into the message body as blob). Even worse, the HL7v2 format is easily mixed up with EDIFACT, as it also uses backticks 
as data element separators, and linebreaks as segment separators. Hrmpf. Not enough, more than one patients can be fed 
into one HL7v2 "message". So the "mandatoryness" of the NAD segment is gone.

### TL;DR:

There is a standard EDIFACT format of the Austrian Medical Association, but everybody is using a variant. 
Typically Austrian, I guess: Strong rules, but nobody cares really ;-)


Anyway, that is why this project exists: because I simply want to be able to read these files in a structured way.

