import pytest
import os
from datetime import date, time

from pydifact import Segment

from pydifact_aek.segments import UNBSegment, NADSegment
from pydifact_aek.wrapper import EdifactTextBefund


def test_read_file_standard(tmp_path):
    # Standard format: UNB+ZEICHENSATZ:1+SENDER+EMPFÄNGER+TAGESDATUM+ZEIT+1'
    # Adjusted to AEK format as strictly required.
    content = (
        b"UNA:+.? '"
        b"UNB+UNOC:3+SENDER_STD+RECEIVER_STD+20230312+1001+00002++INVOIC'"
        b"Standard Payload Content"
        b"UNZ+1+00002'"
    )
    test_file = tmp_path / "standard.txt"
    test_file.write_bytes(content)

    wrapper = EdifactTextBefund()
    wrapper.read_file(str(test_file))

    assert b"Standard Payload Content" == wrapper.get_payload()
    metadata = wrapper.metadata
    assert metadata.sender == "SENDER_STD"
    assert metadata.receiver == "RECEIVER_STD"
    assert metadata.preparation_timestamp.date() == date(2023, 3, 12)
    assert metadata.preparation_timestamp.time() == time(10, 1)
    assert metadata.reference == "00002"


def test_read_file_aek(tmp_path):
    # AEK format: UNB+ZEICHENSATZ:1+SENDER+EMPFÄNGER+TAGESDATUM+ZEIT+1'
    content = (
        b"UNA:+.? '"
        b"UNB+UNOC:3+SENDER_AEK+RECEIVER_AEK+20230312+1000+00001++INVOIC'"
        b"AEK Payload Content"
        b"UNZ+1+00001'"
    )
    test_file = tmp_path / "aek.txt"
    test_file.write_bytes(content)

    wrapper = EdifactTextBefund()
    wrapper.read_file(str(test_file))

    assert b"AEK Payload Content" == wrapper.get_payload()
    metadata = wrapper.metadata
    assert metadata.sender == "SENDER_AEK"
    assert metadata.receiver == "RECEIVER_AEK"
    assert metadata.preparation_timestamp.date() == date(2023, 3, 12)
    assert metadata.preparation_timestamp.time() == time(10, 0)
    assert metadata.reference == "00001"


def test_read_file_no_header(tmp_path):
    content = b"Pure payload without any EDIFACT headers"
    test_file = tmp_path / "no_header.txt"
    test_file.write_bytes(content)

    wrapper = EdifactTextBefund()
    wrapper.read_file(str(test_file))

    assert content == wrapper.get_payload()
    assert wrapper.metadata == {}


def test_binary_payload(tmp_path):
    # Testing with a binary payload (e.g., simulating a small PDF snippet)
    binary_data = b"\x25\x50\x44\x46\x2d\x31\x2e\x34\x0a\x25\xe2\xe3\xcf\xd3"
    content = (
        b"UNA:+.? '"
        b"UNB+UNOC:3+SENDER+RECEIVER+20230312+1000+00001'"
        + binary_data
        + b"UNZ+1+00001'"
    )
    test_file = tmp_path / "binary.txt"
    test_file.write_bytes(content)

    wrapper = EdifactTextBefund()
    wrapper.read_file(str(test_file))

    assert binary_data == wrapper.get_payload()


def test_get_header_segments(tmp_path):
    content = (
        b"UNA:+.? '"
        b"UNB+UNOC:3+SENDER+RECEIVER+20230312+1000+00001'"
        b"Payload"
        b"UNZ+1+00001'"
    )
    test_file = tmp_path / "segments.txt"
    test_file.write_bytes(content)

    wrapper = EdifactTextBefund()
    wrapper.read_file(str(test_file))

    headers = wrapper.get_header_segments()
    # headers should contain UNA and UNB
    tags = [s.tag for s in headers]
    assert "UNA" in tags
    assert "UNB" in tags

    trailers = wrapper.get_trailer_segments()
    assert len(trailers) == 1
    assert trailers[0].tag == "UNZ"


def test_file_type_pdf(tmp_path):
    test_file = tmp_path / "test.pdf"
    test_file.write_bytes(b"dummy pdf content")

    wrapper = EdifactTextBefund()
    wrapper.read_file(str(test_file))

    assert wrapper.file_type == "pdf"


def test_file_type_lab(tmp_path):
    test_file = tmp_path / "test.lab"
    test_file.write_bytes(b"dummy lab content")

    wrapper = EdifactTextBefund()
    wrapper.read_file(str(test_file))

    assert wrapper.file_type == "lab"


def test_file_type_bef(tmp_path):
    test_file = tmp_path / "test.bef"
    test_file.write_bytes(b"dummy bef content")

    wrapper = EdifactTextBefund()
    wrapper.read_file(str(test_file))

    assert wrapper.file_type == "bef"


def test_write_file_full_edifact(tmp_path):
    # Create a wrapper with segments but no payload
    wrapper = EdifactTextBefund()
    # Add some segments

    wrapper.segments = [
        UNBSegment("UNB", ["UNOC", "3"], "SENDER", "RECEIVER", "230312", "1000", "1"),
        Segment("UNH", "1", ["MEDRPT", "1", "901", "UN"]),
        Segment("BGM", "020", "", "", "20230312", "", "123412051980", "19800512"),
        Segment("UNT", "3", "1"),
        Segment("UNZ", "1", "1"),
    ]

    test_file = tmp_path / "output.bef"
    wrapper.write_file(str(test_file))

    # Read it back
    new_wrapper = EdifactTextBefund()
    new_wrapper.read_file(str(test_file))

    assert len(new_wrapper.segments) >= 5
    metadata = new_wrapper.metadata
    assert metadata.sender == "SENDER"
    assert metadata.receiver == "RECEIVER"
    assert metadata.specialty == "020"


def test_write_file_with_payload(tmp_path):
    # Create a wrapper with payload
    wrapper = EdifactTextBefund()
    payload = b"%PDF-1.4 binary data"
    wrapper.payload = payload

    # Optionally set some segments to use in header

    wrapper.segments = [
        UNBSegment(
            "UNB", ["ANSI", "1"], "SENDER001", "RECEIVER001", "230313", "1030", "42"
        ),
        NADSegment("NAD", "PAT", "", ["Doe", "John", "Dr", "Main St"]),
    ]

    test_file = tmp_path / "output_with_pdf.bef"
    wrapper.write_file(str(test_file))

    # Verify file content
    content = test_file.read_bytes()
    assert b"UNB+ANSI:1+SENDER001+RECEIVER001+230313+1030+42'" in content
    assert b"NAD+PAT++Doe:John:Dr:Main St" in content
    assert payload in content
    assert b"UNZ+1+42'" in content

    # Read it back
    new_wrapper = EdifactTextBefund()
    new_wrapper.read_file(str(test_file))
    assert new_wrapper.get_payload() == payload
    metadata = new_wrapper.metadata
    assert metadata.sender == "SENDER001"
    assert metadata.patient_name == "Doe John Dr"
