import pytest
from pathlib import Path
from pydifact_aek.wrapper import EdifactTextBefund


def test_read_medreq_file(tmp_path):
    # A sample MEDREQ EDIFACT content
    # According to AEK-edifact-Befundanforderung.doc:
    # NAD+PAT++ZUNAME:VORNAME:TITEL:STRASSE1:STRASSE2+++ORT++PLZ'
    content = (
        "UNA:+.? '"
        "UNB+UNOC:3+SENDER+RECEIVER+260317:0730+123'"
        "UNH+1+MEDREQ:1:901:UN'"
        "BGM+100+++20070307++123430101955+19551030'"
        "FTX+BFD++Sehr geehrter Kollege?,:TEST REQUEST TEXT'"
        "NAD+PAT++Müller:Josefine:Mag?.:Alter Weg 7:+++Altstatt++5030'"
        "UNT+6+1'"
        "UNZ+1+123'"
    )

    file_path = tmp_path / "test.req"
    file_path.write_text(content, encoding="iso-8859-1")

    befund = EdifactTextBefund()
    befund.read_file(str(file_path))

    assert befund.file_type == "req"
    assert befund.metadata.document_name == "MEDREQ"
    assert "TEST REQUEST TEXT" in befund.metadata.findings
    assert befund.metadata.patient_name == "Müller Josefine Mag."
    assert befund.metadata.patient_city == "Altstatt"
    assert befund.metadata.patient_zip == "5030"
    assert befund.metadata.patient_address == "Alter Weg 7"


def test_write_medreq_file(tmp_path):
    befund = EdifactTextBefund()
    befund.metadata.document_name = "MEDREQ"
    befund.metadata.sender = "SENDER"
    befund.metadata.receiver = "RECEIVER"
    befund.metadata.reference = "123"
    befund.metadata.findings = "REQUEST FOR FINDING"

    file_path = tmp_path / "output.req"
    befund.write_file(str(file_path))

    content = file_path.read_text(encoding="iso-8859-1")
    assert "MEDREQ" in content
    assert "REQUEST FOR FINDING" in content


def test_read_full_befreq_example(tmp_path):
    """Test with the full example from AEK-edifact-Befundanforderung.doc page 8"""
    # This is the example from the documentation, adapted for testing
    content = (
        "UNA:+.? '"
        "UNB+ANSI:1+ME008001+ME002222+070307+1108+1'"
        "UNH+123456+MEDREQ:1:901:UN'"
        "BGM+100+++20070307++123430101955+19551030'"
        "FTX+BFD++Sehr geehrter Kollege?,:wir erbitten eine Auskunft zur Patientin'"
        "FTX+BFD++Frau Mag?. Josefine Müller'"
        "NAD+PAT++Müller:Josefine:Mag?.:Alter Weg 7:+++Altstatt++5030'"
        "UNT+6+123456'"
        "UNZ+1+1'"
    )

    file_path = tmp_path / "befreq_example.req"
    file_path.write_text(content, encoding="iso-8859-1")

    befund = EdifactTextBefund()
    befund.read_file(str(file_path))

    # Verify metadata
    assert befund.file_type == "req"
    assert befund.metadata.document_name == "MEDREQ"
    assert befund.metadata.sender == "ME008001"
    assert befund.metadata.receiver == "ME002222"
    assert befund.metadata.specialty == "100"  # Praktiker
    assert befund.metadata.social_insurance_number == "123430101955"

    # Verify patient data
    assert befund.metadata.patient_name == "Müller Josefine Mag."
    assert befund.metadata.patient_city == "Altstatt"
    assert befund.metadata.patient_zip == "5030"
    assert befund.metadata.patient_address == "Alter Weg 7"

    # Verify findings text
    assert "Sehr geehrter Kollege," in befund.metadata.findings
    assert "Frau Mag. Josefine Müller" in befund.metadata.findings


def test_write_and_read_befreq(tmp_path):
    """Test round-trip: write a MEDREQ file and read it back"""
    from datetime import date, datetime

    # Create a MEDREQ document
    befund = EdifactTextBefund()
    befund.metadata.document_name = "MEDREQ"
    befund.metadata.sender = "ME123456"
    befund.metadata.receiver = "ME654321"
    befund.metadata.reference = "REQ001"
    befund.metadata.specialty = "020"  # Interne
    befund.metadata.report_date = date(2026, 3, 17)
    befund.metadata.social_insurance_number = "123430101990"
    befund.metadata.patient_birth_date = date(1990, 1, 30)
    befund.metadata.patient_name = "Mustermann Max Dr."
    befund.metadata.patient_address = "Musterstraße 1"
    befund.metadata.patient_city = "Wien"
    befund.metadata.patient_zip = "1010"
    befund.metadata.findings = "Bitte um Übermittlung des Befundes vom März 2026."
    befund.metadata.preparation_timestamp = datetime(2026, 3, 17, 10, 30)

    # Write to file
    file_path = tmp_path / "roundtrip.req"
    befund.write_file(str(file_path))

    # Read it back
    befund2 = EdifactTextBefund()
    befund2.read_file(str(file_path))

    # Verify all data is preserved
    assert befund2.metadata.document_name == "MEDREQ"
    assert befund2.metadata.sender == "ME123456"
    assert befund2.metadata.receiver == "ME654321"
    assert befund2.metadata.specialty == "020"
    assert befund2.metadata.social_insurance_number == "123430101990"
    assert befund2.metadata.patient_name == "Mustermann Max Dr."
    assert befund2.metadata.patient_city == "Wien"
    assert befund2.metadata.patient_zip == "1010"
    assert befund2.metadata.patient_address == "Musterstraße 1"
    assert "Bitte um Übermittlung des Befundes vom März 2026." in befund2.metadata.findings
