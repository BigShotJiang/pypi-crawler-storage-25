import pytest
from pydifact_aek.wrapper import EdifactTextBefund
from pydifact_aek.exceptions import ValidationError
from pydifact_aek.segments import FTXSegment


def test_ftx_segment_basic():
    # FTX+BFD++TEXT70:TEXT70:TEXT70:TEXT70:TEXT70'
    elements = ["BFD", "", ["TEXT1", "TEXT2", "TEXT3"]]
    ftx = FTXSegment("FTX", *elements)

    ftx.validate()
    assert ftx.text_blocks == ["TEXT1", "TEXT2", "TEXT3"]
    assert str(ftx) == "TEXT1TEXT2TEXT3"


def test_ftx_segment_max_length():
    long_text = "A" * 70
    too_long_text = "A" * 71

    elements_ok = ["BFD", "", [long_text]]
    ftx_ok = FTXSegment("FTX", *elements_ok)
    ftx_ok.validate()

    elements_fail = ["BFD", "", [too_long_text]]
    ftx_fail = FTXSegment("FTX", *elements_fail)
    with pytest.raises(ValidationError):
        ftx_fail.validate()


def test_ftx_segment_erg():
    # FTX+ERG++TEXT70:TEXT70'
    elements = ["ERG", "", ["TEXT1", "TEXT2"]]
    ftx = FTXSegment("FTX", *elements)

    ftx.validate()
    assert ftx.text_blocks == ["TEXT1", "TEXT2"]
    assert str(ftx) == "TEXT1TEXT2"


def test_ftx_segment_invalid_tag():
    elements = ["NOTBFD", "", ["TEXT"]]
    ftx = FTXSegment("FTX", *elements)
    with pytest.raises(ValidationError):
        ftx.validate()


def test_wrapper_extracts_ftx():
    wrapper = EdifactTextBefund()
    ftx1 = FTXSegment("FTX", "BFD", "", ["Unve"])
    ftx2 = FTXSegment("FTX", "ERG", "", ["ränderte"])
    wrapper.segments = [ftx1, ftx2]

    wrapper._update_metadata()
    metadata = wrapper.metadata
    assert metadata.findings == "Unveränderte"


def test_ftx_single_string_element():
    # pydifact might return a single string if there are no sub-elements
    elements = ["BFD", "", "SINGLE TEXT"]
    ftx = FTXSegment("FTX", *elements)
    ftx.validate()
    assert str(ftx) == "SINGLE TEXT"
    assert ftx.text_blocks == ["SINGLE TEXT"]
