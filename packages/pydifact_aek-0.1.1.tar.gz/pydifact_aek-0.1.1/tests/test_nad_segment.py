import pytest
from pydifact_aek.exceptions import ValidationError
from pydifact_aek.segments import NADSegment


def test_nad_segment_patient_names():
    # NAD+PAT++ZUNAME:VORNAME:TITEL:STRASSE1:STRASSE2+++ORT++PLZ'
    # elements: [PAT, "", [ZUNAME, VORNAME, TITEL, STRASSE1, STRASSE2], "", "", ORT, "", PLZ]
    # index:     0,   1,  2,                                         3,  4,  5,   6,  7

    elements = [
        "PAT",
        "",
        ["DOE", "JOHN", "Dr.", "MAIN STREET 1", "MAIN STREET 2"],
        "",
        "",
        "CITY",
        "",
        "12345",
    ]
    nad = NADSegment("NAD", *elements)

    assert nad.patient_last_name == "DOE"
    assert nad.patient_first_name == "JOHN"
    assert nad.patient_name == "DOE JOHN Dr."
    assert nad.patient_city == "CITY"
    assert nad.patient_zip == "12345"
    assert nad.patient_address == "MAIN STREET 1"


def test_nad_segment_no_name_data():
    nad = NADSegment("NAD", "PAT", "", "")
    assert nad.patient_last_name is None
    assert nad.patient_first_name is None
    assert nad.patient_name is None


def test_nad_segment_single_name():
    nad = NADSegment("NAD", "PAT", "", "ONLY_NAME")
    assert nad.patient_last_name == "ONLY_NAME"
    assert nad.patient_first_name == ""
    assert nad.patient_name == "ONLY_NAME"


def test_wrapper_validate_with_invalid_nad():
    from pydifact_aek.wrapper import EdifactTextBefund, NADSegment

    wrapper = EdifactTextBefund()
    # NAD+PAT is valid, NAD+NOTPAT is invalid
    invalid_nad = NADSegment("NAD", "NOTPAT", "", "DOE")
    wrapper.segments = [invalid_nad]
    with pytest.raises(ValidationError):
        wrapper.validate()


def test_wrapper_validate_with_valid_nad():
    from pydifact_aek.wrapper import EdifactTextBefund, NADSegment

    wrapper = EdifactTextBefund()
    valid_nad = NADSegment("NAD", "PAT", "", "DOE")
    wrapper.segments = [valid_nad]
    wrapper.validate()
