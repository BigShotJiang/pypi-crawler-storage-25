import pytest
from datetime import date, time, datetime
from pydifact_aek.wrapper import EdifactTextBefund


def test_metadata_date_time_parsing(tmp_path):
    # Test content with UNB, UNH, BGM, NAD, FTX
    # UNB date/time: 20230312+1001
    # BGM report_date: 20230313
    # BGM patient_birth_date: 19800101
    content = (
        b"UNA:+.? '"
        b"UNB+UNOC:3+SENDER+RECEIVER+20230312+1001+00001'"
        b"UNH+1+INVOIC:D:96A:UN'"
        b"BGM+SPEC+SIN++20230313+RDT+SIN123+19800101'"
        b"NAD+PAT+SURNAME:NAME:STREET:CITY:12345:PHONE'"
        b"FTX+ACB+++FINDINGS'"
        b"UNZ+1+00001'"
    )
    test_file = tmp_path / "metadata_test.txt"
    test_file.write_bytes(content)

    wrapper = EdifactTextBefund()
    wrapper.read_file(str(test_file))

    metadata = wrapper.metadata

    # UNB values
    assert isinstance(metadata.preparation_timestamp, datetime)
    assert metadata.preparation_timestamp == datetime(2023, 3, 12, 10, 1)

    # BGM values
    assert isinstance(metadata.report_date, date)
    assert metadata.report_date == date(2023, 3, 13)
    assert isinstance(metadata.report_datetime, datetime)
    assert metadata.report_datetime == datetime(2023, 3, 13)

    assert isinstance(metadata.patient_birth_date, date)
    assert metadata.patient_birth_date == date(1980, 1, 1)
