class ValidationError(Exception):
    """Raised when EDIFACT validation fails."""
    pass
