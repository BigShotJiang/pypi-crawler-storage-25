from pydifact.parser import Parser
from pydifact import Segment, Serializer

import re
from typing import Any, Optional, Match, List, Dict
from datetime import datetime, date, time
from dataclasses import dataclass, field, asdict

from pydifact_aek.segments import (
    UNBSegment,
    UNHSegment,
    BGMSegment,
    NADSegment,
    FTXSegment,
)

ENCODING = "iso-8859-15"


@dataclass
class EdifactTextBefundMetadata:
    """Metadata for EDIFACT text-based befund documents.

    This class is designed to store metadata about EDIFACT text-based befund documents, spanning
    the entire document. It includes fields for sender and receiver information, as well as
    document-specific metadata such as preparation timestamp, reference, and patient details.
    """

    sender: Optional[str] = None
    receiver: Optional[str] = None
    preparation_timestamp: Optional[datetime] = None
    reference: Optional[str] = None
    document_name: Optional[str] = None
    edi_version: Optional[str] = None
    specialty: Optional[str] = None
    report_datetime: Optional[datetime] = None
    report_date: Optional[date] = None
    social_insurance_number: Optional[str] = None
    patient_birth_date: Optional[date] = None
    patient_name: Optional[str] = None
    patient_city: Optional[str] = None
    patient_address: Optional[str] = None
    patient_zip: Optional[str] = None
    patient_phone: Optional[str] = None
    findings: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Return metadata as a dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}

    def __eq__(self, other: Any) -> bool:
        """Allow comparison of complete Metadata set with a dictionary."""
        if isinstance(other, dict):
            return self.to_dict() == other
        return super().__eq__(other)


class EdifactTextBefund:
    """Wrapper class for EDIFACT text-based befund documents, as defined by the Austrian Medical Association
    (Österreichische Ärztekammer) in AEK-edifact-text.doc.pdf, 23.1.2002.

    This class is designed to read and write EDIFACT text-based befund documents, specifically those that follow the
    EDIFACT standard for text-based medical reports. It provides methods for parsing and manipulating these documents,
    including extracting segments and included payloads, and supports various file formats such as PDF, LAB, and BEF.
    """

    def __init__(self) -> None:
        self.segments: list[Segment] = []
        self.payload: Optional[bytes] = None
        self.file_type: Optional[str] = None
        self.metadata: EdifactTextBefundMetadata = EdifactTextBefundMetadata()

    def read_file(self, file_path: str) -> None:
        """Read a file and extract the EDIFACT segments and its payload."""
        # Detect file type from extension
        if file_path.lower().endswith(".pdf"):
            self.file_type = "pdf"
        elif file_path.lower().endswith(".lab"):
            self.file_type = "lab"
        elif file_path.lower().endswith(".bef"):
            self.file_type = "bef"
        elif file_path.lower().endswith(".req"):
            self.file_type = "req"
        elif file_path.lower().endswith(".edf"):
            self.file_type = "edf"
        else:
            self.file_type = None

        # Using binary read to support PDF or HL7 correctly
        with open(file_path, "rb") as f:
            content: bytes = f.read()

        # Check if it starts with UNA
        segment_terminator: str = "'"
        if content.startswith(b"UNA"):
            # UNA is fixed length: UNA and 6 special chars
            delimiters: bytes = content[3:9]
            # UNA: <component> <element> <decimal> <release> <space> <terminator>
            # Example: UNA:+.? '
            segment_terminator = chr(delimiters[5])

        # Find UNB (start of header) and UNZ (start of trailer)
        unb_match: Optional[Match[bytes]] = re.search(
            rb"UNB\+.*?" + re.escape(segment_terminator.encode()), content, re.DOTALL
        )
        unz_match: Optional[Match[bytes]] = re.search(
            rb"UNZ\+.*?" + re.escape(segment_terminator.encode()) + rb"\s*$",
            content,
            re.DOTALL,
        )

        if not unb_match:
            # Maybe it's not even wrapped?
            self.payload = content
            return

        # Check if it's a pure header string (no trailer yet)
        parser: Parser = Parser()

        if not unz_match and len(content) < 10000:
            try:
                self.segments = list(parser.parse(content.decode(ENCODING)))
                self.payload = b""
                self._wrap_segments()
                self._update_metadata()
                return
            except Exception:
                pass

        # Extract EDIFACT content
        # If there's a UNZ, the EDIFACT part is UNB...UNZ.

        # Isolate the envelope
        header_start = 0
        if content.startswith(b"UNA"):
            header_start = 0
        else:
            header_start = unb_match.start()

        # If there's a UNZ, let's try to parse the envelope
        if unz_match:
            # First, try to see if it's ALL EDIFACT segments
            try:
                envelope_content = content[header_start : unz_match.end()].decode(
                    ENCODING
                )
                self.segments = list(parser.parse(envelope_content))
                # Check if we actually got more than just UNB/UNZ if we expect BGM/NAD
                if not any(s.tag == "BGM" for s in self.segments):
                    raise ValueError("Missing BGM in full envelope")
                self.payload = b""
                self._wrap_segments()
                self._update_metadata()
                return
            except Exception:
                # If it fails, there's a binary payload in the middle.
                pass

        # Identifying where the header ends and payload starts
        # Let's find mandatory segment positions
        unh_match = re.search(
            rb"UNH\+.*?" + re.escape(segment_terminator.encode()), content, re.DOTALL
        )
        bgm_match = re.search(
            rb"BGM\+.*?" + re.escape(segment_terminator.encode()), content, re.DOTALL
        )
        nad_match = re.search(
            rb"NAD\+.*?" + re.escape(segment_terminator.encode()), content, re.DOTALL
        )
        unt_match = re.search(
            rb"UNT\+.*?" + re.escape(segment_terminator.encode()), content, re.DOTALL
        )

        # Segments typically at the start
        possible_header_end = unb_match.end()
        if unh_match:
            possible_header_end = max(possible_header_end, unh_match.end())
        if bgm_match:
            possible_header_end = max(possible_header_end, bgm_match.end())
        if nad_match and nad_match.start() < possible_header_end + 100:
            possible_header_end = max(possible_header_end, nad_match.end())
        if unt_match and unt_match.start() < possible_header_end + 100:
            possible_header_end = max(possible_header_end, unt_match.end())

        all_segments = []

        def add_segments_from_text(text: str):
            try:
                all_segments.extend(list(parser.parse(text)))
            except Exception:
                pass

        header_part = content[header_start:possible_header_end].decode(ENCODING)
        add_segments_from_text(header_part)

        if unz_match:
            # Segments typically at the end
            possible_trailer_start = unz_match.start()

            # If there's a NAD or UNT after possible_header_end but before UNZ
            if (
                nad_match
                and nad_match.start() > possible_header_end
                and nad_match.start() >= unz_match.start() - 200
            ):
                possible_trailer_start = min(possible_trailer_start, nad_match.start())
            if (
                unt_match
                and unt_match.start() > possible_header_end
                and unt_match.start() >= unz_match.start() - 100
            ):
                possible_trailer_start = min(possible_trailer_start, unt_match.start())

            trailer_part = content[possible_trailer_start : unz_match.end()].decode(
                ENCODING
            )
            add_segments_from_text(trailer_part)
            self.segments = all_segments
            self.payload = content[possible_header_end:possible_trailer_start].strip(
                b"\r\n"
            )
        else:
            # No UNZ, parse what we can
            if nad_match and nad_match.start() >= possible_header_end:
                nad_part = nad_match.group().decode(ENCODING)
                add_segments_from_text(nad_part)
                self.payload = content[possible_header_end : nad_match.start()].strip(
                    b"\r\n"
                )
            else:
                self.payload = content[possible_header_end:].strip(b"\r\n")
            self.segments = all_segments

        # Ensure UNA is in segments if present
        if content.startswith(b"UNA") and not any(
            s.tag == "UNA" for s in self.segments
        ):
            # We use Segment from pydifact
            self.segments.insert(0, Segment("UNA", content[3:9].decode(ENCODING)))

        # If UNZ was matched but is not in segments, add it manually
        if unz_match and not any(s.tag == "UNZ" for s in self.segments):
            unz_text = unz_match.group().decode(ENCODING)
            try:
                self.segments.extend(list(parser.parse(unz_text)))
            except Exception:
                pass

        self._wrap_segments()
        self._update_metadata()

    def _wrap_segments(self) -> None:
        """Replace standard pydifact Segment objects with our specialized ones."""
        wrapped_segments = []
        for segment in self.segments:
            if segment.tag == "UNB":
                wrapped_segments.append(UNBSegment(segment.tag, *segment.elements))
            elif segment.tag == "UNH":
                wrapped_segments.append(UNHSegment(segment.tag, *segment.elements))
            elif segment.tag == "BGM":
                wrapped_segments.append(BGMSegment(segment.tag, *segment.elements))
            elif segment.tag == "NAD":
                wrapped_segments.append(NADSegment(segment.tag, *segment.elements))
            elif segment.tag == "FTX":
                wrapped_segments.append(FTXSegment(segment.tag, *segment.elements))
            else:
                wrapped_segments.append(segment)
        self.segments = wrapped_segments

    def _update_metadata(self) -> None:
        """Update metadata from the segments (UNB, UNH, BGM, NAD)."""
        # Note: We don't recreate the instance, so it can be filled manually as well.
        # But we overwrite existing fields if segments are present.

        unb = next((s for s in self.segments if isinstance(s, UNBSegment)), None)
        if unb:
            self.metadata.sender = unb.sender
            self.metadata.receiver = unb.receiver
            self.metadata.preparation_timestamp = unb.preparation_timestamp
            self.metadata.reference = unb.control_reference

        unh = next((s for s in self.segments if isinstance(s, UNHSegment)), None)
        if unh:
            self.metadata.document_name = unh.document_name
            self.metadata.edi_version = unh.edi_version

        bgm = next((s for s in self.segments if isinstance(s, BGMSegment)), None)
        if bgm:
            self.metadata.specialty = bgm.specialty
            self.metadata.report_datetime = bgm.report_datetime
            if bgm.report_datetime:
                self.metadata.report_date = bgm.report_datetime.date()
            self.metadata.social_insurance_number = bgm.social_insurance_number
            self.metadata.patient_birth_date = bgm.patient_birth_date

        nad = next((s for s in self.segments if isinstance(s, NADSegment)), None)
        if nad:
            self.metadata.patient_name = nad.patient_name
            self.metadata.patient_city = nad.patient_city
            self.metadata.patient_address = nad.patient_address
            self.metadata.patient_zip = nad.patient_zip
            self.metadata.patient_phone = nad.patient_phone

        # Collect all FTX text content
        ftx_segments = [s for s in self.segments if isinstance(s, FTXSegment)]
        if ftx_segments:
            # For MEDREQ (ACB) or MEDRPT (BFD, ERG)
            self.metadata.findings = "".join(str(s) for s in ftx_segments)

    def get_header_segments(self) -> list[Segment]:
        """Return the segments usually considered 'header' (UNA, UNB, UNH, BGM, NAD)."""
        header_tags = {"UNA", "UNB", "UNH", "BGM", "NAD", "FTX"}
        return [s for s in self.segments if s.tag in header_tags]

    def get_trailer_segments(self) -> list[Segment]:
        """Return the segments usually considered 'trailer' (UNT, UNZ)."""
        trailer_tags = {"UNT", "UNZ"}
        return [s for s in self.segments if s.tag in trailer_tags]

    def process_payload(self) -> None:
        """Stub method to process the remaining content."""
        if self.payload:
            print(f"Processing payload of size {len(self.payload)} bytes.")
            # Implementation for specific payload types (PDF, HL7) goes here.
            pass
        else:
            print("No payload to process.")

    def get_payload(self) -> Optional[bytes]:
        return self.payload

    def write_file(self, file_path: str) -> None:
        """Write the segments and payload to a file."""
        serializer: Serializer = Serializer()

        # Separators and other settings for Serializer
        # pydifact defaults: component=':', element='+', decimal='.', release='?', space=' ', terminator="'"

        if not self.payload and self.segments:
            # Full EDIFACT document from segments
            content_str: str = serializer.serialize(self.segments)
            with open(file_path, "wb") as f:
                f.write(content_str.encode(ENCODING))
            return

        # Case with payload (e.g. PDF) or segments missing (recreate from metadata)
        # Mandatory segments: UNB (ANSI), UNH, NAD with corresponding trailers.

        # Collect header segments (UNB, UNH, BGM, NAD)
        header_segments: List[Segment] = []

        # If we have them in self.segments, use them.
        unb = next((s for s in self.segments if s.tag == "UNB"), None)
        unh = next((s for s in self.segments if s.tag == "UNH"), None)
        bgm = next((s for s in self.segments if s.tag == "BGM"), None)
        nad = next((s for s in self.segments if s.tag == "NAD"), None)

        # If missing, create them with defaults (though this might not be very useful without data)
        if not unb:
            # UNB+CHARSET:1+SENDER+RECEIVER+DATE+TIME+REF'
            unb = UNBSegment("UNB")
            unb.syntax_id = ["ANSI", "1"]  # Recommended for AEK
            unb.sender = self.metadata.sender or "SENDER"
            unb.receiver = self.metadata.receiver or "RECEIVER"

            timestamp = self.metadata.preparation_timestamp or datetime.now()
            unb.preparation_date_str = timestamp.strftime("%y%m%d")
            unb.preparation_time_str = timestamp.strftime("%H%M")
            unb.control_reference = self.metadata.reference or "1"

        if not unh:
            # "UNH+REF+MEDRPT:1:901:UN'" or "UNH+REF+MEDREQ:1:901:UN'"
            unh = UNHSegment("UNH")
            unh.reference = self.metadata.reference or "1"
            doc_name = self.metadata.document_name or "MEDRPT"
            unh.document_name = doc_name
            # EDI version components: 1, 901, UN
            # Since we only have one edi_version setter, we might need to set the list or just the version if it's the 3rd part
            unh.edi_version = "901"
            # Other elements (1 and UN) can be set manually for now, or we could add more properties.
            # Looking at the original line: UNHSegment("UNH", ref, ["MEDRPT", "1", "901", "UN"])
            # Let's make sure the whole list is initialized.
            unh.elements[1] = [doc_name, "1", "901", "UN"]

        if not bgm:
            # "BGM+SPECIALTY+++REPORT_DATE++SSN+BIRTH_DATE'"
            specialty = self.metadata.specialty or "999"
            report_date = (
                self.metadata.report_date.strftime("%Y%m%d")
                if self.metadata.report_date
                else datetime.now().strftime("%Y%m%d")
            )
            # FIXME: ssn is not in default format `NNNNDDMMYY`, but `NNNNDDMMYYYY`!
            ssn = self.metadata.social_insurance_number or ""
            birth_date = (
                self.metadata.patient_birth_date.strftime("%Y%m%d")
                if self.metadata.patient_birth_date
                else ""
            )

            # MEDREQ format: BGM+SPECIALTY+++REPORT_DATE++SSN+BIRTH_DATE'
            bgm = BGMSegment(
                "BGM", specialty, "", "", report_date, "", ssn, birth_date
            )

        if not nad:
            # "NAD+PAT++LAST:FIRST:TITLE:STREET1:STREET2+++CITY++ZIP'"
            # Parse patient_name which is typically "LAST FIRST TITLE"
            name_and_street_parts = []
            if self.metadata.patient_name:
                # Split by space to get last, first, title
                parts = self.metadata.patient_name.split()
                # Assume format is LAST FIRST TITLE (or fewer parts)
                name_and_street_parts = parts[:3] if len(parts) >= 3 else parts
                while len(name_and_street_parts) < 3:
                    name_and_street_parts.append("")
            else:
                name_and_street_parts = ["", "", ""]

            # Add address parts
            if self.metadata.patient_address:
                # Split address into street1 and street2 if needed
                addr_parts = self.metadata.patient_address.split("\n", 1)
                name_and_street_parts.append(addr_parts[0])
                if len(addr_parts) > 1:
                    name_and_street_parts.append(addr_parts[1])
                else:
                    name_and_street_parts.append("")
            else:
                name_and_street_parts.extend(["", ""])

            nad = NADSegment(
                "NAD",
                "PAT",
                "",
                name_and_street_parts,
                "",
                "",
                self.metadata.patient_city or "",
                "",
                self.metadata.patient_zip or "",
            )

        # write them in correct order.
        header_segments.append(unb)
        header_segments.append(unh)
        header_segments.append(bgm)
        header_segments.append(nad)

        # Any other header segments from self.segments that are not BGM, NAD, UNH, UNB?
        # Maybe FTX?
        for s in self.segments:
            if s.tag not in ["UNB", "UNH", "BGM", "NAD", "UNZ", "UNT", "UNA"]:
                header_segments.append(s)

        # If we have findings in metadata but no FTX segments in self.segments, add one
        if self.metadata.findings and not any(
            isinstance(s, FTXSegment) for s in header_segments
        ):
            # Ensure we use wrapped FTXSegment so it's parsed correctly on read back
            # Format: FTX+BFD++TEXT (element 0=BFD, element 1=empty, element 2=text)
            header_segments.append(
                FTXSegment("FTX", "BFD", "", self.metadata.findings)
            )

        # Re-wrap segments to ensure they are our specialized versions
        wrapped_header = []
        for s in header_segments:
            if isinstance(
                s, (UNBSegment, UNHSegment, BGMSegment, NADSegment, FTXSegment)
            ):
                wrapped_header.append(s)
            elif s.tag == "UNB":
                wrapped_header.append(UNBSegment(s.tag, *s.elements))
            elif s.tag == "UNH":
                wrapped_header.append(UNHSegment(s.tag, *s.elements))
            elif s.tag == "BGM":
                wrapped_header.append(BGMSegment(s.tag, *s.elements))
            elif s.tag == "NAD":
                wrapped_header.append(NADSegment(s.tag, *s.elements))
            elif s.tag == "FTX":
                wrapped_header.append(FTXSegment(s.tag, *s.elements))
            else:
                wrapped_header.append(s)
        header_segments = wrapped_header

        # UNT trailer for UNH
        # Count segments from UNH to UNT inclusive.
        # segments: UNH, BGM, NAD, [others], UNT
        segment_count = len(header_segments)
        unt = Segment("UNT", str(segment_count), unh.reference)

        header_segments.append(unt)

        # UNZ trailer for UNB
        # "UNZ+MESSAGE_COUNT+REF'"
        ref = unb.control_reference or "1"
        unz = Segment("UNZ", "1", ref)

        # Start writing
        with open(file_path, "wb") as f:
            # We can use UNA if needed, Serializer usually handles it if specified
            # For simplicity, we write the segments string
            header_str = serializer.serialize(header_segments)

            # Since header_segments contains UNT, the Serializer will output UNB...UNT'
            # (And possibly UNA at the start)

            f.write(header_str.encode(ENCODING))

            # Now the payload
            # Use binary mode as requested
            if self.payload:
                f.write(self.payload)

            # Now the UNZ trailer
            unz_str = serializer.serialize([unz])

            # Find the UNZ part
            unz_match = re.search(r"UNZ\+.*?'", unz_str)
            if unz_match:
                f.write(unz_match.group().encode(ENCODING))
            else:
                # Fallback if somehow not found
                # Note: unb.elements[5] is the control reference
                f.write(f"UNZ+1+{ref}'".encode(ENCODING))

    def validate(self) -> None:
        """Call the validate() method on each segment if it has one."""
        # The parser might return generic Segment objects for segments not in SegmentProvider
        # or it might return the specific SegmentProvider subclasses if registered.
        # EdifactWrapper.read_file doesn't seem to use SegmentProvider subclasses yet.

        for segment in self.segments:
            # If the segment is a SegmentProvider subclass, it has validate()
            if hasattr(segment, "validate") and callable(segment.validate):
                segment.validate()
