from enum import Enum


Specialities = {
 "010": "Radiologie",
 "100": "Praktiker",
 "020": "Interne",
 "110": "Augen",
 "030": "Orthopädie",
 "120": "HNO",
 "040": "Lunge",
 "130": "Derma",
 "050": "Urologie",
 "140": "Physikalische",
 "060": "Gynäkologie",
 "150": "Histologie",
 "070": "Chirurgie",
 "160": "Labor",
 "080": "Kinderheilkunde",
 "999": "Sonstige",
 "090": "Neurologie",
}