from datetime import datetime, date
from typing import Optional, Union, List

from pydifact import Segment

# TODO: from pydifact.exceptions import ValidationError
from pydifact_aek.exceptions import ValidationError


class UNBSegment(Segment):
    tag = "UNB"

    def validate(self) -> None:
        """Validate the UNB segment structure for AEK-EDIFACT."""
        if len(self.elements) < 6:
            raise ValidationError(
                f"UNB segment must have at least 6 elements (found {len(self.elements)}). "
                "Syntax: UNB+CHARSET:1+SENDER+RECEIVER+DATE+TIME+REF'"
            )
        # element 0: Syntax identifier (list or string)
        if not self.elements[0]:
            raise ValidationError("UNB element 0 (Syntax ID) is required.")

        # element 3: Date
        if not self.elements[3]:
            raise ValidationError("UNB element 3 (Date) is required.")

        # element 4: Time
        if not self.elements[4]:
            raise ValidationError("UNB element 4 (Time) is required.")

        # element 5: Control reference
        if not self.elements[5]:
            raise ValidationError("UNB element 5 (Control reference) is required.")

    @property
    def syntax_id(self) -> Optional[Union[str, List[str]]]:
        return self.elements[0] if len(self.elements) > 0 else None

    @syntax_id.setter
    def syntax_id(self, value: Union[str, List[str]]) -> None:
        while len(self.elements) < 1:
            self.elements.append(None)
        self.elements[0] = value

    @property
    def sender(self) -> Optional[str]:
        if len(self.elements) > 1:
            return self.elements[1]
        return None

    @sender.setter
    def sender(self, value: str) -> None:
        while len(self.elements) < 2:
            self.elements.append(None)
        self.elements[1] = value

    @property
    def receiver(self) -> Optional[str]:
        if len(self.elements) > 2:
            return self.elements[2]
        return None

    @receiver.setter
    def receiver(self, value: str) -> None:
        while len(self.elements) < 3:
            self.elements.append(None)
        self.elements[2] = value

    @property
    def preparation_date_str(self) -> Optional[str]:
        if len(self.elements) > 3:
            return str(self.elements[3])
        return None

    @preparation_date_str.setter
    def preparation_date_str(self, value: str) -> None:
        while len(self.elements) < 4:
            self.elements.append(None)
        self.elements[3] = value

    @property
    def preparation_time_str(self) -> Optional[str]:
        if len(self.elements) > 4:
            return str(self.elements[4])
        return None

    @preparation_time_str.setter
    def preparation_time_str(self, value: str) -> None:
        while len(self.elements) < 5:
            self.elements.append(None)
        self.elements[4] = value

    @property
    def preparation_timestamp(self) -> Optional[datetime]:
        dt_str = self.preparation_date_str
        tm_str = self.preparation_time_str
        if not dt_str:
            return None
        # Standard EDIFACT allows 6 (YYMMDD) or 8 (YYYYMMDD) digits (should not happen)
        fmt = "%y%m%d" if len(dt_str) == 6 else "%Y%m%d"
        try:
            if tm_str:
                # Time can be 4 digits (HHMM)
                fmt += "%H%M"
                return datetime.strptime(dt_str + tm_str, fmt)
            return datetime.strptime(dt_str, fmt)
        except (ValueError, TypeError):
            return None

    @property
    def control_reference(self) -> Optional[str]:
        if len(self.elements) > 5:
            return self.elements[5]
        return None

    @control_reference.setter
    def control_reference(self, value: str) -> None:
        while len(self.elements) <= 5:
            self.elements.append(None)
        self.elements[5] = value


class UNHSegment(Segment):
    tag = "UNH"

    def validate(self) -> None:
        # TODO
        pass

    @property
    def reference(self) -> Optional[str]:
        return str(self.elements[0]) if len(self.elements) > 0 else None

    @reference.setter
    def reference(self, value: str) -> None:
        while len(self.elements) < 1:
            self.elements.append(None)
        self.elements[0] = value

    @property
    def document_name(self) -> Optional[str]:
        if len(self.elements) > 1:
            msg_type = self.elements[1]
            if isinstance(msg_type, list):
                return msg_type[0]
            return msg_type
        return None

    @document_name.setter
    def document_name(self, value: str) -> None:
        while len(self.elements) < 2:
            self.elements.append(None)

        msg_type = self.elements[1]
        if isinstance(msg_type, list):
            msg_type[0] = value
        else:
            self.elements[1] = [value, None, None, None]

    @property
    def edi_version(self) -> Optional[str]:
        if len(self.elements) > 1:
            msg_type = self.elements[1]
            if isinstance(msg_type, list) and len(msg_type) > 2:
                return msg_type[2]
        return None

    @edi_version.setter
    def edi_version(self, value: str) -> None:
        while len(self.elements) < 2:
            self.elements.append(None)

        msg_type = self.elements[1]
        if not isinstance(msg_type, list):
            # initialize with some defaults if not a list
            self.elements[1] = [None, None, value, None]
        else:
            # Ensure list has enough space
            while len(msg_type) < 3:
                msg_type.append(None)
            msg_type[2] = value


class BGMSegment(Segment):
    tag = "BGM"

    def validate(self) -> None:
        # TODO
        pass

    @property
    def specialty(self) -> Optional[str]:
        return str(self.elements[0]) if len(self.elements) > 0 else None

    @property
    def report_date(self) -> Optional[str]:
        return str(self.elements[3]) if len(self.elements) > 3 else None

    @property
    def report_datetime(self) -> Optional[datetime]:
        dt_str = self.report_date
        if not dt_str:
            return None
        fmt = "%y%m%d" if len(dt_str) == 6 else "%Y%m%d"
        try:
            return datetime.strptime(dt_str, fmt)
        except (ValueError, TypeError):
            return None

    @property
    def social_insurance_number(self) -> Optional[str]:
        return str(self.elements[5]) if len(self.elements) > 5 else None

    @property
    def patient_birth_date(self) -> Optional[date]:
        if len(self.elements) <= 6 or self.elements[6] is None:
            return None
        dt_element = self.elements[6]
        dt_str = str(dt_element[0]) if isinstance(dt_element, list) else str(dt_element)
        if not dt_str:
            return None
        assert len(dt_str) == 8, f"Invalid date format: {dt_str}"
        fmt = "%Y%m%d"
        try:
            return datetime.strptime(dt_str, fmt).date()
        except (ValueError, TypeError):
            return None

    @patient_birth_date.setter
    def patient_birth_date(self, value: Union[date, str, None]) -> None:
        if value is None:
            if len(self.elements) > 6:
                self.elements[6] = None
            return

        if isinstance(value, date):
            formatted_date = value.strftime("%Y%m%d")
        else:
            formatted_date = str(value)

        # Ensure we have enough elements
        while len(self.elements) <= 6:
            self.elements.append(None)
        self.elements[6] = formatted_date


class NADSegment(Segment):
    tag = "NAD"

    def __init__(self, tag: str, *elements: Union[str, List[str], None]):
        super().__init__(tag, *elements)
        self._patient_first_name: Optional[str] = None
        self._patient_last_name: Optional[str] = None
        self._names_parsed: bool = False

    def validate(self) -> None:
        if self.elements[0] != "PAT":
            raise ValidationError(f"Expected 'PAT', got {self.elements[0]}")

    def _parse_names(self) -> None:
        if self._names_parsed:
            return

        name_data = None
        if len(self.elements) > 2 and self.elements[2]:
            name_data = self.elements[2]
        elif len(self.elements) > 1 and self.elements[1]:
            name_data = self.elements[1]

        if name_data == "" or name_data is None:
            self._patient_last_name = None
            self._patient_first_name = None
        elif isinstance(name_data, list):
            # We only want the first two (Surname, Forename) if it looks like AEK
            if len(name_data) > 0:
                self._patient_last_name = (
                    str(name_data[0]) if name_data[0] is not None else ""
                )
            if len(name_data) > 1:
                self._patient_first_name = (
                    str(name_data[1]) if name_data[1] is not None else ""
                )
        else:
            self._patient_last_name = str(name_data)
            self._patient_first_name = ""

        self._names_parsed = True

    @property
    def patient_first_name(self) -> Optional[str]:
        self._parse_names()
        return self._patient_first_name

    @property
    def patient_last_name(self) -> Optional[str]:
        self._parse_names()
        return self._patient_last_name

    @property
    def patient_name(self) -> Optional[str]:
        self._parse_names()
        if self._patient_last_name is None:
            return None

        name_data = None
        if len(self.elements) > 2 and self.elements[2]:
            name_data = self.elements[2]
        elif len(self.elements) > 1 and self.elements[1]:
            name_data = self.elements[1]

        # In AEK, name element is LAST:FIRST:TITLE (or more)
        title = ""
        # In AEK, name element is LAST:FIRST:TITLE:ADDRESS:CITY:ZIP:PHONE
        title = ""
        if isinstance(name_data, list) and len(name_data) > 2:
            title = str(name_data[2]) if name_data[2] is not None else ""

        return " ".join(
            filter(None, [self._patient_last_name, self._patient_first_name, title])
        )

    @property
    def patient_city(self) -> Optional[str]:
        # City (ORT) is in element index 5 in AEK BEFREQ format
        # NAD+PAT++NAME_PARTS+++ORT++PLZ'
        if len(self.elements) > 5:
            return str(self.elements[5]) if self.elements[5] else None
        return None

    @property
    def patient_address(self) -> Optional[str]:
        # Address STRASSE1 is in element 2, component index 3
        # (STRASSE2 would be at index 4, but we only return the first line)
        name_data = None
        if len(self.elements) > 2 and self.elements[2]:
            name_data = self.elements[2]

        if isinstance(name_data, list) and len(name_data) > 3:
            return str(name_data[3]) if name_data[3] else None
        return None

    @property
    def patient_zip(self) -> Optional[str]:
        # PLZ is in element index 7 in AEK BEFREQ format
        # NAD+PAT++NAME_PARTS+++ORT++PLZ'
        if len(self.elements) > 7:
            return str(self.elements[7]) if self.elements[7] else None
        return None

    @property
    def patient_phone(self) -> Optional[str]:
        # Phone is not specified in the basic NAD segment for AEK BEFREQ
        # It might be in additional segments or not present
        return None


class FTXSegment(Segment):
    tag = "FTX"

    def validate(self) -> None:
        # BFD (Befund/findings for MEDRPT and MEDREQ), ERG (results), or ACB (request info) must be the first data element
        if len(self.elements) < 1 or self.elements[0] not in ("BFD", "ERG", "ACB"):
            raise ValidationError(
                f"FTX segment must start with 'BFD' (findings), 'ERG' (results), or 'ACB' (request), got {self.elements[0] if self.elements else 'nothing'}"
            )

        # Text is in the 3rd element (index 2)
        if len(self.elements) > 2:
            text_data = self.elements[2]
            if isinstance(text_data, list):
                # Textblocks cannot exceed 70 characters
                for i, block in enumerate(text_data):
                    if block and len(str(block)) > 70:
                        raise ValidationError(
                            f"FTX text block {i} exceeds 70 characters"
                        )
            elif text_data and len(str(text_data)) > 70:
                raise ValidationError("FTX text exceeds 70 characters")

    @property
    def text_blocks(self) -> List[str]:
        # According to AEK spec: FTX+BFD++TEXT70:TEXT70:...
        # Text is always in element 2 (3rd position) for both BFD and ACB
        if len(self.elements) > 2:
            text_data = self.elements[2]
            if isinstance(text_data, list):
                return [str(b) if b is not None else "" for b in text_data]
            return [str(text_data)] if text_data is not None else []
        return []

    def __str__(self) -> str:
        return "".join(self.text_blocks)
