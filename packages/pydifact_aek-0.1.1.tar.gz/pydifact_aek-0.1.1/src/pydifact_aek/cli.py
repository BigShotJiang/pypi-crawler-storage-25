import argparse
import sys
from datetime import datetime
from typing import Any, Optional
from .wrapper import EdifactTextBefund, EdifactTextBefundMetadata
from .exceptions import ValidationError
from pydifact import Segment


def main() -> None:
    parser: argparse.ArgumentParser = argparse.ArgumentParser(
        description="Process an EDIFACT-wrapped file with non-standard payload."
    )
    parser.add_argument("file", help="Path to the EDIFACT-wrapped file to process")
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Print header and trailer info"
    )

    args: argparse.Namespace = parser.parse_args()

    wrapper: EdifactTextBefund = EdifactTextBefund()
    try:
        wrapper.read_file(args.file)
        wrapper.validate()
    except ValidationError as e:
        print(f"Error: Validation failed for file '{args.file}': {e}", file=sys.stderr)
        sys.exit(1)
    except FileNotFoundError:
        print(f"Error: File '{args.file}' not found.", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error reading file: {e}", file=sys.stderr)
        sys.exit(1)

    metadata_dict = wrapper.metadata.to_dict()
    if metadata_dict:
        sender: Any = metadata_dict.get("sender", "Unknown")
        receiver: Any = metadata_dict.get("receiver", "Unknown")
        dt: Optional[datetime] = metadata_dict.get("preparation_timestamp")
        if dt:
            dt_display = dt.strftime("%Y-%m-%d %H:%M")
        else:
            dt_display = "Unknown"

        print(f"\nSENDER: {sender}")
        print(f"RECIPIENT: {receiver}")
        print(f"DATE/TIME: {dt_display}")

        # New fields: Report Date and Patient Data
        report_dt: Optional[datetime] = metadata_dict.get("report_datetime")
        specialty = metadata_dict.get("specialty")
        if specialty:
            print(f"SPECIALTY: {specialty}")
        if report_dt:
            print(f"REPORT DATE: {report_dt.strftime('%Y-%m-%d')}")
        else:
            report_date: Any = metadata_dict.get("report_date")
            if report_date:
                print(f"REPORT DATE: {report_date}")

        patient_name: Any = metadata_dict.get("patient_name")
        if patient_name:
            patient_info = [patient_name]
            birth_date = metadata_dict.get("patient_birth_date")
            if birth_date:
                # birth_date could be a date object or a string from metadata_dict
                if hasattr(birth_date, "strftime"):
                    patient_info.append(f", {birth_date.strftime('%Y-%m-%d')}")
                else:
                    patient_info.append(f", {birth_date}")
            ssn = metadata_dict.get("social_insurance_number")
            if ssn:
                patient_info.append(f" [SSN: {ssn}]")
            print(f"PATIENT: {''.join(patient_info)}")

            # Address info
            city = metadata_dict.get("patient_city")
            zip_code = metadata_dict.get("patient_zip")
            addr = metadata_dict.get("patient_address")
            phone = metadata_dict.get("patient_phone")

            if addr or zip_code or city:
                parts = []
                if addr:
                    parts.append(addr)
                if zip_code or city:
                    loc = f"{zip_code or ''} {city or ''}".strip()
                    if loc:
                        parts.append(loc)
                print(f"ADDRESS: {', '.join(parts)}")

            if phone:
                print(f"PHONE: {phone}")

            # findings = metadata.get("findings")
            # if findings:
            #     print("\nFINDINGS:")
            #     print(findings)
    else:
        print("No metadata found in UNB header.")

    if args.verbose:
        print("--- Header Segments ---")
        segment: Segment
        for segment in wrapper.get_header_segments():
            print(f"Tag: {segment.tag}, Elements: {segment.elements}")

        print("--- Metadata ---")
        metadata = wrapper.metadata
        for k, v in metadata.to_dict().items():
            print(f"  {k}: {v}")

    wrapper.process_payload()

    if args.verbose:
        print("--- Trailer Segments ---")
        for segment in wrapper.get_trailer_segments():
            print(f"Tag: {segment.tag}, Elements: {segment.elements}")


if __name__ == "__main__":
    main()
