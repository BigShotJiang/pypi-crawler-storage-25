from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

import cv2

from visionguard.simulator.corruptions import CORRUPTION_REGISTRY, SUITE_REGISTRY
from visionguard.utils import ensure_dir


SUPPORTED_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def generate_corruption_datasets(
    source_dataset: str | Path,
    output_root: str | Path,
    suites: list[str],
    severities: list[int] | None = None,
) -> list[dict[str, Any]]:
    severities = severities or [1, 2, 3]
    source = Path(source_dataset).resolve()
    out_root = ensure_dir(output_root).resolve()
    manifest: list[dict[str, Any]] = []
    files = [p for p in source.rglob("*") if p.is_file()]

    for suite in suites:
        corruptions = SUITE_REGISTRY.get(suite, [])
        for corruption in corruptions:
            transform = CORRUPTION_REGISTRY[corruption]
            for severity in severities:
                dataset_name = f"{suite}_{corruption}_s{severity}"
                dataset_dir = out_root / dataset_name
                ensure_dir(dataset_dir)

                total = 0
                skipped = 0
                transformed = 0
                for file_path in files:
                    rel_path = file_path.relative_to(source)
                    target_path = dataset_dir / rel_path
                    ensure_dir(target_path.parent)
                    total += 1

                    if file_path.suffix.lower() not in SUPPORTED_EXT:
                        skipped += 1
                        shutil.copy2(file_path, target_path)
                        continue

                    image = cv2.imread(str(file_path))
                    if image is None:
                        skipped += 1
                        shutil.copy2(file_path, target_path)
                        continue

                    try:
                        output = transform(image, severity)
                        ok = cv2.imwrite(str(target_path), output)
                        if not ok:
                            raise RuntimeError("Failed to write transformed image")
                        transformed += 1
                    except Exception:
                        skipped += 1
                        shutil.copy2(file_path, target_path)

                manifest.append(
                    {
                        "suite": suite,
                        "corruption": corruption,
                        "severity": severity,
                        "dataset_dir": str(dataset_dir),
                        "source_dataset": str(source),
                        "files_total": total,
                        "files_transformed": transformed,
                        "files_skipped": skipped,
                    }
                )
    return manifest
