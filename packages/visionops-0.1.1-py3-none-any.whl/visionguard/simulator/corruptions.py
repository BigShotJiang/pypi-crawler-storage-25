from __future__ import annotations

from typing import Callable

import albumentations as A
import cv2
import numpy as np


ImageTransform = Callable[[np.ndarray, int], np.ndarray]


def _k(severity: int) -> int:
    return [3, 5, 7][severity - 1]


def gaussian_blur(image: np.ndarray, severity: int) -> np.ndarray:
    kernel = _k(severity)
    return cv2.GaussianBlur(image, (kernel, kernel), 0)


def motion_blur(image: np.ndarray, severity: int) -> np.ndarray:
    blur = A.MotionBlur(blur_limit=(3, 3 + severity * 4), p=1.0)
    return blur(image=image)["image"]


def gaussian_noise(image: np.ndarray, severity: int) -> np.ndarray:
    sigma = [8, 16, 24][severity - 1]
    noise = np.random.normal(0, sigma, image.shape).astype(np.float32)
    out = image.astype(np.float32) + noise
    return np.clip(out, 0, 255).astype(np.uint8)


def brightness_decrease(image: np.ndarray, severity: int) -> np.ndarray:
    alpha = [0.85, 0.7, 0.55][severity - 1]
    out = image.astype(np.float32) * alpha
    return np.clip(out, 0, 255).astype(np.uint8)


def jpeg_compression(image: np.ndarray, severity: int) -> np.ndarray:
    quality = [60, 40, 20][severity - 1]
    encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
    success, encoded = cv2.imencode(".jpg", image, encode_param)
    if not success:
        return image
    decoded = cv2.imdecode(encoded, cv2.IMREAD_COLOR)
    return decoded if decoded is not None else image


def occlusion_cutout(image: np.ndarray, severity: int) -> np.ndarray:
    h, w = image.shape[:2]
    frac = [0.08, 0.16, 0.24][severity - 1]
    mask_h = int(h * frac)
    mask_w = int(w * frac)
    y = max(0, h // 2 - mask_h // 2)
    x = max(0, w // 2 - mask_w // 2)
    out = image.copy()
    out[y : y + mask_h, x : x + mask_w] = 0
    return out


def perspective_warp(image: np.ndarray, severity: int) -> np.ndarray:
    h, w = image.shape[:2]
    offset = [0.03, 0.07, 0.12][severity - 1]
    dx = int(w * offset)
    dy = int(h * offset)
    src = np.float32([[0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1]])
    dst = np.float32([[dx, dy], [w - 1 - dx, 0], [0, h - 1 - dy], [w - 1, h - 1]])
    matrix = cv2.getPerspectiveTransform(src, dst)
    return cv2.warpPerspective(image, matrix, (w, h), borderMode=cv2.BORDER_REPLICATE)


def crop_truncation(image: np.ndarray, severity: int) -> np.ndarray:
    h, w = image.shape[:2]
    cut = [0.06, 0.12, 0.2][severity - 1]
    cut_w = int(w * cut)
    cut_h = int(h * cut)
    cropped = image[cut_h : h - cut_h or h, cut_w : w - cut_w or w]
    if cropped.size == 0:
        return image
    return cv2.resize(cropped, (w, h), interpolation=cv2.INTER_LINEAR)


def small_object_downscale(image: np.ndarray, severity: int) -> np.ndarray:
    h, w = image.shape[:2]
    factor = [0.85, 0.7, 0.55][severity - 1]
    resized = cv2.resize(image, (max(1, int(w * factor)), max(1, int(h * factor))))
    return cv2.resize(resized, (w, h), interpolation=cv2.INTER_LINEAR)


CORRUPTION_REGISTRY: dict[str, ImageTransform] = {
    "gaussian_blur": gaussian_blur,
    "motion_blur": motion_blur,
    "gaussian_noise": gaussian_noise,
    "brightness_decrease": brightness_decrease,
    "jpeg_compression": jpeg_compression,
    "occlusion_cutout": occlusion_cutout,
    "perspective_warp": perspective_warp,
    "crop_truncation": crop_truncation,
    "small_object_downscale": small_object_downscale,
}


SUITE_REGISTRY: dict[str, list[str]] = {
    "core": [
        "gaussian_blur",
        "motion_blur",
        "gaussian_noise",
        "brightness_decrease",
        "jpeg_compression",
        "occlusion_cutout",
    ],
    "ocr": ["perspective_warp", "crop_truncation"],
    "detection": ["small_object_downscale", "crop_truncation"],
    "face": ["brightness_decrease", "gaussian_blur", "jpeg_compression", "occlusion_cutout"],
}
