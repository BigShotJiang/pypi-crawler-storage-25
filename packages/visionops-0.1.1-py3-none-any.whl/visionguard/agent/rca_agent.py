from __future__ import annotations

from visionguard.agent.llm_client import LLMClient
from visionguard.models import EvidenceBundle, RCAHypothesis


class RCAAgent:
    def __init__(self, llm: LLMClient | None = None):
        self.llm = llm

    def analyze(self, evidence: EvidenceBundle) -> tuple[list[RCAHypothesis], str, bool]:
        deterministic = self._deterministic(evidence)
        if not self.llm or not self.llm.enabled:
            return deterministic, deterministic[0].explanation, False

        prompt = (
            "Use only provided evidence. Return JSON with keys summary and hypotheses[] "
            "where each hypothesis has category, explanation, confidence, likely_files.\n"
            f"Stage localization: {evidence.stage_localization.stage}\n"
            f"Reasons: {evidence.stage_localization.reasons}\n"
            f"Failing suites: {evidence.failing_suites}\n"
            f"Repo map: entry={evidence.repo_summary.entrypoints}, pre={evidence.repo_summary.preprocess_files}, "
            f"post={evidence.repo_summary.postprocess_files}, parser={evidence.repo_summary.parser_files}\n"
        )
        out = self.llm.complete_json(
            system_prompt=(
                "You are an RCA analyst for CV pipelines. Ground all claims in runtime evidence. "
                "Do not invent files or causes absent from evidence."
            ),
            user_prompt=prompt,
        )
        if not out or not isinstance(out, dict):
            return deterministic, deterministic[0].explanation, False
        hypotheses_data = out.get("hypotheses", [])
        hypotheses: list[RCAHypothesis] = []
        if isinstance(hypotheses_data, list):
            for item in hypotheses_data[:4]:
                if not isinstance(item, dict):
                    continue
                hypotheses.append(
                    RCAHypothesis(
                        category=str(item.get("category", "unknown")),
                        explanation=str(item.get("explanation", "")),
                        confidence=self._parse_confidence(item.get("confidence", 0.5)),
                        likely_files=[str(x) for x in item.get("likely_files", []) if isinstance(x, str)],
                    )
                )
        if not hypotheses:
            hypotheses = deterministic
        summary = str(out.get("summary", hypotheses[0].explanation))
        return hypotheses, summary, True

    def _deterministic(self, evidence: EvidenceBundle) -> list[RCAHypothesis]:
        stage = evidence.stage_localization.stage
        likely_files: list[str] = []
        if "preprocessing" in stage:
            likely_files = evidence.repo_summary.preprocess_files[:4]
        elif "postprocessing" in stage:
            likely_files = evidence.repo_summary.postprocess_files[:4]
        elif "parser" in stage:
            likely_files = evidence.repo_summary.parser_files[:4]
        elif "model" in stage:
            likely_files = evidence.repo_summary.model_files[:4]
        else:
            likely_files = evidence.repo_summary.entrypoints[:4]

        explanation = (
            f"Primary failure is most consistent with {stage}, based on failing suites and runtime patterns: "
            + "; ".join(evidence.stage_localization.reasons[:2])
        )
        return [
            RCAHypothesis(
                category=stage,
                explanation=explanation,
                confidence=evidence.stage_localization.confidence,
                likely_files=likely_files,
            )
        ]

    @staticmethod
    def _parse_confidence(value: object) -> float:
        if isinstance(value, (int, float)):
            return max(0.0, min(1.0, float(value)))
        if isinstance(value, str):
            text = value.strip().lower()
            label_map = {
                "very low": 0.2,
                "low": 0.35,
                "medium": 0.55,
                "moderate": 0.6,
                "high": 0.8,
                "very high": 0.92,
            }
            if text in label_map:
                return label_map[text]
            try:
                parsed = float(text)
                return max(0.0, min(1.0, parsed))
            except ValueError:
                return 0.5
        return 0.5
