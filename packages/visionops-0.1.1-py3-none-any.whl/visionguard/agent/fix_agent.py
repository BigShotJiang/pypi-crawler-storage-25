from __future__ import annotations

from visionguard.agent.llm_client import LLMClient
from visionguard.models import EvidenceBundle, FixCandidate


class FixAgent:
    def __init__(self, llm: LLMClient | None = None):
        self.llm = llm

    def suggest(self, evidence: EvidenceBundle) -> tuple[list[str], bool]:
        base = [
            f"{c.title}: {c.explanation} (confidence={c.confidence:.2f}, stage={c.related_stage})"
            for c in evidence.fix_candidates
        ]
        if not self.llm or not self.llm.enabled:
            return base, False

        prompt = (
            "Rewrite these remediation candidates into clear ranked, actionable bullets with tradeoffs. "
            "Return JSON with suggestions list.\n"
            f"Candidates: {base}\n"
            f"Stage: {evidence.stage_localization.stage}\n"
            f"Failing suites: {evidence.failing_suites}"
        )
        out = self.llm.complete_json(
            system_prompt="You are a practical CV reliability engineer. Keep suggestions evidence-grounded.",
            user_prompt=prompt,
        )
        if not out or not isinstance(out, dict):
            return base, False
        suggestions = out.get("suggestions", [])
        if not isinstance(suggestions, list) or not suggestions:
            return base, False
        normalized = [str(s).strip() for s in suggestions if str(s).strip()]
        return normalized[:10], True
