from __future__ import annotations

import json
import os
from typing import Any

import httpx

from visionguard.config import LLMConfig


class LLMClient:
    def __init__(self, config: LLMConfig):
        self.config = config
        raw_key = os.getenv(config.api_key_env, "")
        self.api_key = raw_key.strip().strip('"').strip("'")
        provider = config.provider.strip().lower()
        default_base_url = "https://api.openai.com/v1"
        if provider == "gemini":
            default_base_url = "https://generativelanguage.googleapis.com/v1beta/openai"
        self.base_url = config.base_url.strip() or default_base_url

    @property
    def enabled(self) -> bool:
        return bool(self.api_key)

    def complete_json(self, system_prompt: str, user_prompt: str) -> dict[str, Any] | None:
        if not self.enabled:
            return None
        payload: dict[str, Any] = {
            "model": self.config.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.1,
        }
        # Gemini's OpenAI-compatible endpoint can reject strict response_format payloads.
        # We keep JSON output by prompt discipline + tolerant parsing instead.
        if self.config.provider.strip().lower() != "gemini":
            payload["response_format"] = {"type": "json_object"}
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        try:
            with httpx.Client(timeout=40) as client:
                response = client.post(f"{self.base_url}/chat/completions", headers=headers, json=payload)
            if response.status_code >= 300:
                return None
            content = response.json()["choices"][0]["message"]["content"]
            try:
                return json.loads(content)
            except json.JSONDecodeError:
                start = content.find("{")
                end = content.rfind("}")
                if start >= 0 and end > start:
                    return json.loads(content[start : end + 1])
                return None
        except Exception:
            return None
