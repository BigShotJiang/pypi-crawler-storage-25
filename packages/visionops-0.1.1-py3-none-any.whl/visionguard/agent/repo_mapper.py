from __future__ import annotations

import re
import subprocess
from pathlib import Path

from visionguard.agent.llm_client import LLMClient
from visionguard.models import RepoMap
from visionguard.utils import list_text_files


PATH_KEYWORDS = {
    "entry": ("eval.py", "infer.py", "predict.py", "main.py", "serve.py", "run.py"),
    "pre": ("preprocess", "transform", "augment", "resize"),
    "post": ("postprocess", "threshold", "nms", "decode", "filter"),
    "parser": ("parser", "business", "rule", "validator"),
    "model": ("model", "network", "onnx", "detector", "segment", "classifier"),
    "setup": ("requirements.txt", "dockerfile", "config", "yaml", "pyproject.toml", "makefile"),
}

CONTENT_KEYWORDS = {
    "entry": ("argparse", "if __name__ == \"__main__\"", "click.command", "typer.Typer"),
    "pre": ("albumentations", "torchvision.transforms", "cv2.resize", "normalize", "letterbox"),
    "post": ("nms", "non_max", "threshold", "confidence", "score", "softmax"),
    "parser": ("json.loads", "parse_", "schema", "business rule", "malformed"),
    "model": ("torch.nn", "ultralytics", "onnxruntime", "model.predict", "inference"),
}

INSTRUCTION_FILENAMES = {"claw.md", "agents.md", "readme.md", "instructions.md"}
CODE_SUFFIXES = {".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs", ".java", ".cpp", ".c", ".cs"}
IGNORED_PATH_PARTS = {
    ".git",
    "__pycache__",
    "site-packages",
    "node_modules",
    "dist",
    "build",
    "target",
    ".venv",
    "venv",
    "env",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
}


class RepoMapperAgent:
    def __init__(self, llm: LLMClient | None = None):
        self.llm = llm

    def map_repo(self, repo_dir: str | Path) -> RepoMap:
        repo_path = Path(repo_dir).resolve()
        files = [f for f in list_text_files(repo_path, max_files=900) if not self._is_ignored_path(repo_path, f)]
        rel = [str(f.relative_to(repo_path)) for f in files]

        instruction_files = self._discover_instruction_files(repo_path, files)
        git_context = self._discover_git_context(repo_path)
        stage_rankings = self._score_files_by_stage(repo_path, files)

        entrypoints = stage_rankings["entry"][:10]
        preprocess = stage_rankings["pre"][:12]
        postprocess = stage_rankings["post"][:12]
        parser = stage_rankings["parser"][:12]
        model_files = stage_rankings["model"][:12]
        setup_files = [p for p in rel if any(k in p.lower() for k in PATH_KEYWORDS["setup"])][:15]
        setup_files = self._dedupe_keep_order([*setup_files, *instruction_files])

        summary = (
            f"Repo has {len(rel)} scanned text/config files and {len(instruction_files)} context files. "
            f"Likely entrypoints: {', '.join(entrypoints[:3]) or 'unknown'}. "
            f"Preprocess candidates: {', '.join(preprocess[:3]) or 'none found'}. "
            f"Postprocess candidates: {', '.join(postprocess[:2]) or 'none found'}. "
            f"Parser candidates: {', '.join(parser[:2]) or 'none found'}."
        )
        graph = self._build_pipeline_graph(preprocess, model_files, postprocess, parser)

        llm_used = False
        if self.llm and self.llm.enabled:
            context_snippets = self._build_context_snippets(repo_path, instruction_files)
            code_snippets = self._build_code_snippets(repo_path, stage_rankings)
            prompt = (
                "Summarize this CV repo map and return JSON with keys summary and pipeline_graph.\n"
                "Ground claims only in the evidence below.\n"
                f"Entrypoints: {entrypoints}\n"
                f"Preprocess: {preprocess}\n"
                f"Model: {model_files}\n"
                f"Postprocess: {postprocess}\n"
                f"Parser: {parser}\n"
                f"Setup: {setup_files}\n"
                f"Git context: {git_context}\n"
                f"Instruction snippets:\n{context_snippets}\n"
                f"Code snippets:\n{code_snippets}\n"
            )
            out = self.llm.complete_json(
                system_prompt="You summarize CV repository pipeline maps. Keep grounded to provided files.",
                user_prompt=prompt,
            )
            if out and isinstance(out, dict):
                summary = str(out.get("summary", summary))
                graph = str(out.get("pipeline_graph", graph))
                llm_used = True

        return RepoMap(
            entrypoints=entrypoints,
            preprocess_files=preprocess,
            postprocess_files=postprocess,
            parser_files=parser,
            model_files=model_files,
            setup_files=setup_files,
            summary=summary,
            pipeline_graph=graph,
            llm_used=llm_used,
        )

    def _discover_instruction_files(self, repo_path: Path, files: list[Path]) -> list[str]:
        ranked: list[tuple[int, str]] = []
        for file_path in files:
            rel = str(file_path.relative_to(repo_path))
            lower = rel.replace("\\", "/").lower()
            name = file_path.name.lower()
            if name not in INSTRUCTION_FILENAMES:
                continue
            score = 1
            if lower.endswith("claw.md") or lower.endswith("agents.md"):
                score += 3
            if "/.claw/" in lower or lower.startswith(".claw/"):
                score += 3
            if lower.count("/") <= 1:
                score += 2
            ranked.append((score, rel))
        ranked.sort(key=lambda x: (-x[0], x[1]))
        return [item[1] for item in ranked[:8]]

    def _discover_git_context(self, repo_path: Path) -> str:
        try:
            status = subprocess.run(
                ["git", "status", "--short"],
                cwd=str(repo_path),
                capture_output=True,
                text=True,
                timeout=3,
            )
            if status.returncode != 0:
                return "git_status_unavailable"
            lines = [line.strip() for line in status.stdout.splitlines() if line.strip()]
            return "clean" if not lines else f"{len(lines)} changed files"
        except Exception:
            return "git_status_unavailable"

    def _score_files_by_stage(self, repo_path: Path, files: list[Path]) -> dict[str, list[str]]:
        stage_scores: dict[str, list[tuple[float, str]]] = {
            "entry": [],
            "pre": [],
            "post": [],
            "parser": [],
            "model": [],
        }
        for file_path in files:
            rel = str(file_path.relative_to(repo_path))
            lower_rel = rel.lower().replace("\\", "/")
            path_scores = {stage: self._keyword_score(lower_rel, PATH_KEYWORDS[stage]) for stage in stage_scores}
            content_scores = {stage: 0.0 for stage in stage_scores}

            if file_path.suffix.lower() in CODE_SUFFIXES:
                text = self._safe_read(file_path, max_chars=7000).lower()
                if text:
                    for stage in stage_scores:
                        content_scores[stage] = self._keyword_score(text, CONTENT_KEYWORDS[stage])
                    content_scores["entry"] += 1.2 * (
                        ("if __name__ == \"__main__\"" in text) or ("argparse" in text) or ("typer.typer" in text)
                    )
                    content_scores["model"] += 0.8 * ("predict(" in text or "inference" in text)
                    content_scores["parser"] += 0.8 * ("json" in text and ("parse" in text or "schema" in text))

            for stage in stage_scores:
                total = path_scores[stage] * 1.0 + content_scores[stage] * 1.2
                if total > 0:
                    stage_scores[stage].append((float(total), rel))

        ranked: dict[str, list[str]] = {}
        for stage, values in stage_scores.items():
            values.sort(key=lambda x: (-x[0], x[1]))
            ranked[stage] = self._dedupe_keep_order([v[1] for v in values])

        # Fallback to path-only matching if content scoring found nothing for a stage.
        for stage in ranked:
            if not ranked[stage]:
                ranked[stage] = [str(p.relative_to(repo_path)) for p in files if self._keyword_score(str(p).lower(), PATH_KEYWORDS[stage]) > 0]
        return ranked

    @staticmethod
    def _keyword_score(text: str, keywords: tuple[str, ...]) -> float:
        score = 0.0
        for keyword in keywords:
            if keyword in text:
                score += 1.0
        return score

    @staticmethod
    def _safe_read(path: Path, max_chars: int) -> str:
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return ""
        return content[:max_chars]

    def _build_context_snippets(self, repo_path: Path, instruction_files: list[str]) -> str:
        snippets: list[str] = []
        for rel in instruction_files[:4]:
            path = repo_path / rel
            content = self._safe_read(path, max_chars=2000).strip()
            if not content:
                continue
            snippets.append(f"{rel}:\n{content[:700]}")
        return "\n\n".join(snippets) if snippets else "none"

    def _build_code_snippets(self, repo_path: Path, stage_rankings: dict[str, list[str]]) -> str:
        selected = self._dedupe_keep_order(
            stage_rankings["entry"][:2]
            + stage_rankings["pre"][:2]
            + stage_rankings["post"][:2]
            + stage_rankings["parser"][:2]
            + stage_rankings["model"][:2]
        )
        snippets: list[str] = []
        for rel in selected[:8]:
            path = repo_path / rel
            text = self._safe_read(path, max_chars=2600)
            if not text:
                continue
            signature_lines = [
                line.strip()
                for line in text.splitlines()
                if re.match(r"^\s*(def |class |function |export function |fn )", line)
            ]
            snippet = "\n".join(signature_lines[:8]) or "\n".join(text.splitlines()[:12])
            snippets.append(f"{rel}:\n{snippet[:700]}")
        return "\n\n".join(snippets) if snippets else "none"

    @staticmethod
    def _build_pipeline_graph(
        preprocess: list[str],
        model_files: list[str],
        postprocess: list[str],
        parser: list[str],
    ) -> str:
        stages = ["data_loader"]
        if preprocess:
            stages.append("preprocess")
        if model_files:
            stages.append("model_inference")
        if postprocess:
            stages.append("postprocess")
        if parser:
            stages.append("parser/business_rules")
        return " -> ".join(stages)

    @staticmethod
    def _dedupe_keep_order(values: list[str]) -> list[str]:
        seen: set[str] = set()
        out: list[str] = []
        for value in values:
            if value in seen:
                continue
            seen.add(value)
            out.append(value)
        return out

    @staticmethod
    def _is_ignored_path(repo_path: Path, path: Path) -> bool:
        try:
            parts = {p.lower() for p in path.relative_to(repo_path).parts}
        except Exception:
            parts = {p.lower() for p in path.parts}
        return any(part in IGNORED_PATH_PARTS for part in parts)
