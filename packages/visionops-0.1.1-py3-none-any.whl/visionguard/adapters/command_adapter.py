from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from visionguard.adapters.base import PipelineAdapter
from visionguard.config import VisionGuardConfig
from visionguard.utils import run_command, substitute_placeholders


class CommandAdapter(PipelineAdapter):
    def __init__(self, repo_dir: Path, config: VisionGuardConfig):
        self.repo_dir = repo_dir
        self.config = config

    def install(self):
        return run_command(self.config.build.install, cwd=self.repo_dir)

    def run_baseline(self, input_dir: Path, output_dir: Path):
        command = substitute_placeholders(
            self.config.run.baseline,
            {
                "input_dir": str(input_dir),
                "output_dir": str(output_dir),
                "gt_dir": str(Path(self.config.data.ground_truth).resolve()),
            },
        )
        result = run_command(command, cwd=self.repo_dir)
        result.output_dir = output_dir
        return result

    def run_metrics(self, output_dir: Path, gt_dir: Path) -> tuple[Any, dict[str, Any]]:
        command = substitute_placeholders(
            self.config.metrics.command,
            {
                "output_dir": str(output_dir),
                "gt_dir": str(gt_dir),
                "input_dir": str(output_dir),
            },
        )
        result = run_command(command, cwd=self.repo_dir)
        metrics = self._parse_metrics(result.stdout)
        return result, metrics

    @staticmethod
    def _parse_metrics(stdout: str) -> dict[str, Any]:
        text = stdout.strip()
        if not text:
            return {}
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            start = text.find("{")
            end = text.rfind("}")
            if start >= 0 and end > start:
                try:
                    return json.loads(text[start : end + 1])
                except json.JSONDecodeError:
                    return {}
            return {}
