from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from visionguard.models import RunResult


class PipelineAdapter(ABC):
    @abstractmethod
    def install(self) -> RunResult:
        raise NotImplementedError

    @abstractmethod
    def run_baseline(self, input_dir: Path, output_dir: Path) -> RunResult:
        raise NotImplementedError

    @abstractmethod
    def run_metrics(self, output_dir: Path, gt_dir: Path) -> tuple[RunResult, dict[str, Any]]:
        raise NotImplementedError
