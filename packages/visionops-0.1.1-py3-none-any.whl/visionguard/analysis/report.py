from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from visionguard.models import EvidenceBundle, RCAHypothesis, RegressionSummary
from visionguard.report_html import convert_report_md_to_html
from visionguard.utils import ensure_dir


def _format_table(rows: list[dict[str, Any]]) -> str:
    lines = ["| Suite | Corruption | Severity | Metric | Delta |", "|---|---:|---:|---:|---:|"]
    for row in rows:
        lines.append(
            "| {suite} | {corruption} | {severity} | {primary_metric:.4f} | {delta:.4f} |".format(
                suite=row.get("suite"),
                corruption=row.get("corruption"),
                severity=row.get("severity"),
                primary_metric=float(row.get("primary_metric", 0.0)),
                delta=float(row.get("delta", 0.0)),
            )
        )
    return "\n".join(lines)


def write_reports(
    output_dir: str | Path,
    repo: str,
    task_type: str,
    regression: RegressionSummary,
    evidence: EvidenceBundle,
    rca: list[RCAHypothesis],
    rca_summary: str,
    fixes_text: list[str],
    execution_diagnostics: dict[str, Any] | None = None,
) -> dict[str, str]:
    out = ensure_dir(output_dir)
    summary_json = out / "summary.json"
    manifest_json = out / "artifact_manifest.json"
    report_md = out / "report.md"
    report_html = out / "report.html"

    summary_payload = {
        "repo": repo,
        "task_type": task_type,
        "primary_metric_name": regression.primary_metric_name,
        "baseline_metric": regression.baseline_metric,
        "worst_suite": regression.worst_suite,
        "worst_delta": regression.worst_delta,
        "severity": regression.severity,
        "stage_localization": asdict(evidence.stage_localization),
        "rca": [asdict(h) for h in rca],
        "top_regressions": sorted(
            [
                {
                    "suite_label": row.get("suite_label"),
                    "delta": float(row.get("delta", 0.0)),
                    "primary_metric": float(row.get("primary_metric", 0.0)),
                }
                for row in regression.suite_metrics
            ],
            key=lambda x: x["delta"],
            reverse=True,
        )[:10],
        "execution_diagnostics": execution_diagnostics or {},
    }
    summary_json.write_text(json.dumps(summary_payload, indent=2), encoding="utf-8")

    manifest_json.write_text(
        json.dumps(
            {
                "artifact_paths": evidence.artifact_paths,
                "suite_metrics": evidence.suite_metrics,
                "failing_suites": evidence.failing_suites,
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    suspected = sorted(
        {
            file_path
            for hypothesis in rca
            for file_path in hypothesis.likely_files
            if isinstance(file_path, str) and file_path.strip()
        }
    )
    fixes_block = "\n".join(f"- {line}" for line in fixes_text)
    suspected_lines = [f"- `{p}`" for p in suspected] if suspected else ["- No specific files identified"]
    report_md.write_text(
        "\n".join(
            [
                "# visionguard Report",
                "",
                "## 1. Repo info",
                f"- Repo: `{repo}`",
                "",
                "## 2. Task type",
                f"- `{task_type}`",
                "",
                "## 3. Baseline metric",
                f"- {regression.primary_metric_name}: `{regression.baseline_metric:.4f}`",
                "",
                "## 4. Per-suite degradation table",
                _format_table(regression.suite_metrics),
                "",
                "## 5. Worst failure conditions",
                f"- Worst suite: `{regression.worst_suite}`",
                f"- Worst delta: `{regression.worst_delta:.4f}`",
                f"- Failure severity: `{regression.severity}`",
                "",
                "## 6. Likely failing stage",
                f"- {evidence.stage_localization.stage} (confidence {evidence.stage_localization.confidence:.2f})",
                *[f"- {reason}" for reason in evidence.stage_localization.reasons],
                "",
                "## 7. Repo understanding summary",
                f"- {evidence.repo_summary.summary}",
                "",
                "## 8. RCA summary",
                f"- {rca_summary}",
                "",
                "## 9. Suspected files/modules",
                *suspected_lines,
                "",
                "## 10. Suggested fixes",
                fixes_block,
                "",
                "## 11. LLM usage mode",
                f"- {'LLM-assisted' if evidence.llm_used else 'Rule-based fallback'}",
                "",
                "## 12. Execution diagnostics",
                f"- install return code: `{(execution_diagnostics or {}).get('install', {}).get('returncode', 'n/a')}`",
                f"- baseline return code: `{(execution_diagnostics or {}).get('baseline_run', {}).get('returncode', 'n/a')}`",
                f"- baseline metrics return code: `{(execution_diagnostics or {}).get('baseline_metrics', {}).get('returncode', 'n/a')}`",
                f"- suite failure count: `{(execution_diagnostics or {}).get('suite_failures_count', 0)}`",
                f"- install stderr tail: `{((execution_diagnostics or {}).get('install', {}).get('stderr_tail') or 'none')}`",
                f"- baseline stderr tail: `{((execution_diagnostics or {}).get('baseline_run', {}).get('stderr_tail') or 'none')}`",
                f"- baseline metrics stderr tail: `{((execution_diagnostics or {}).get('baseline_metrics', {}).get('stderr_tail') or 'none')}`",
                "",
            ]
        ),
        encoding="utf-8",
    )
    convert_report_md_to_html(
        report_md_path=report_md,
        output_html_path=report_html,
        summary_json_path=summary_json,
    )
    return {
        "summary_json": str(summary_json),
        "artifact_manifest_json": str(manifest_json),
        "report_md": str(report_md),
        "report_html": str(report_html),
    }


def pretty_print_report(output_dir: str | Path) -> str:
    path = Path(output_dir) / "report.md"
    if not path.exists():
        return f"Report not found at {path}"
    return path.read_text(encoding="utf-8")
