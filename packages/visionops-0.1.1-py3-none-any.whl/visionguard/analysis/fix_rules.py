from __future__ import annotations

from typing import Any

from visionguard.models import FixCandidate


RULES: dict[str, list[FixCandidate]] = {
    "blur": [
        FixCandidate("Inspect resize/preprocess path", "Check if resizing or interpolation is erasing high-frequency detail.", 0.68, "preprocessing"),
        FixCandidate("Add blur augmentation", "Train/evaluate with motion and gaussian blur augmentations.", 0.72, "model"),
        FixCandidate("Increase input resolution", "Small text/object details may be lost before inference.", 0.57, "preprocessing"),
    ],
    "low_light": [
        FixCandidate("Apply brightness normalization", "Normalize luminance in preprocessing to stabilize features.", 0.71, "preprocessing"),
        FixCandidate("Add low-light augmentation", "Improve robustness under darker captures.", 0.74, "model"),
        FixCandidate("Review confidence thresholds", "Low-light often lowers confidence and can trigger over-filtering.", 0.63, "postprocessing"),
    ],
    "compression": [
        FixCandidate("Train/eval on compressed images", "JPEG artifacts can shift feature distributions.", 0.72, "model"),
        FixCandidate("Reduce aggressive resize passes", "Repeated resampling amplifies compression damage.", 0.66, "preprocessing"),
        FixCandidate("Preserve text/detail paths", "OCR and small object tasks need detail-preserving transforms.", 0.64, "preprocessing"),
    ],
    "crop_warp": [
        FixCandidate("Preserve aspect ratio", "Avoid crop policies that truncate edge content.", 0.75, "preprocessing"),
        FixCandidate("Add crop/perspective augmentation", "Make geometric distortion part of validation and training.", 0.73, "model"),
        FixCandidate("Inspect ROI extraction", "ROI logic can become brittle under perspective and truncation.", 0.69, "preprocessing"),
    ],
    "occlusion": [
        FixCandidate("Add occlusion augmentation", "Improve partial-visibility robustness.", 0.74, "model"),
        FixCandidate("Preserve wider context", "Wider context can reduce brittleness under missing regions.", 0.62, "preprocessing"),
        FixCandidate("Review bbox filtering assumptions", "Strict geometry filters can remove valid partial detections.", 0.66, "postprocessing"),
    ],
    "postprocess": [
        FixCandidate("Run threshold sweep", "Calibrate score thresholds against corrupted suites.", 0.82, "postprocessing"),
        FixCandidate("Inspect NMS/score filtering", "Filtering may be too strict in degraded conditions.", 0.79, "postprocessing"),
        FixCandidate("Compare raw vs final outputs", "Verify if detections exist before postprocess pruning.", 0.84, "postprocessing"),
    ],
    "parser": [
        FixCandidate("Harden parser edge handling", "Gracefully handle empty/malformed detection payloads.", 0.83, "parser"),
        FixCandidate("Validate parser assumptions", "Check assumptions on key presence and output format.", 0.77, "parser"),
        FixCandidate("Add parser integration tests", "Add fixtures for occlusion/warp-induced malformed outputs.", 0.74, "parser"),
    ],
}


def suggest_fixes(stage: str, failing_suites: list[dict[str, Any]]) -> list[FixCandidate]:
    labels = " ".join(f"{row.get('suite','')} {row.get('corruption','')}".lower() for row in failing_suites)
    candidates: list[FixCandidate] = []

    if "blur" in labels:
        candidates.extend(RULES["blur"])
    if "brightness" in labels or "low" in labels:
        candidates.extend(RULES["low_light"])
    if "jpeg" in labels or "compression" in labels:
        candidates.extend(RULES["compression"])
    if "crop" in labels or "warp" in labels:
        candidates.extend(RULES["crop_warp"])
    if "occlusion" in labels or "cutout" in labels:
        candidates.extend(RULES["occlusion"])

    stage_key = stage.lower()
    if "postprocess" in stage_key or "threshold" in stage_key:
        candidates.extend(RULES["postprocess"])
    if "parser" in stage_key or "business-rule" in stage_key:
        candidates.extend(RULES["parser"])

    if not candidates:
        candidates.extend(
            [
                FixCandidate("Inspect failing suite artifacts", "Use generated artifacts/logs to isolate first stage where outputs diverge.", 0.5, "unknown"),
                FixCandidate("Add targeted augmentation", "Add corruption families matching observed failures.", 0.52, "model"),
            ]
        )

    deduped: dict[tuple[str, str], FixCandidate] = {}
    for c in candidates:
        key = (c.title, c.related_stage)
        if key not in deduped or deduped[key].confidence < c.confidence:
            deduped[key] = c
    ordered = sorted(deduped.values(), key=lambda x: x.confidence, reverse=True)
    return ordered[:8]
