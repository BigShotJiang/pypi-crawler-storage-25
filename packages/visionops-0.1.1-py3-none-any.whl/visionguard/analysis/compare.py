from __future__ import annotations

from typing import Any

from visionguard.models import RegressionSummary


def _severity_from_delta(delta: float, threshold: float) -> str:
    if delta <= threshold:
        return "none"
    if delta <= threshold * 1.5:
        return "moderate"
    if delta <= threshold * 2.5:
        return "high"
    return "critical"


def compute_regression_summary(
    baseline_metrics: dict[str, Any],
    suite_runs: list[dict[str, Any]],
    metric_name: str,
    max_drop: float,
) -> RegressionSummary:
    baseline_primary = float(
        baseline_metrics.get("primary_metric", baseline_metrics.get(metric_name, 0.0)) or 0.0
    )

    enriched: list[dict[str, Any]] = []
    worst_name: str | None = None
    worst_delta = 0.0
    latency_deltas: dict[str, float] = {}

    for run in suite_runs:
        metrics = run.get("metrics", {})
        suite_value = float(metrics.get("primary_metric", metrics.get(metric_name, 0.0)) or 0.0)
        delta = baseline_primary - suite_value
        suite_label = f"{run.get('suite')}/{run.get('corruption')}/s{run.get('severity')}"

        if delta > worst_delta:
            worst_delta = delta
            worst_name = suite_label

        baseline_latency = baseline_metrics.get("latency_ms")
        run_latency = metrics.get("latency_ms")
        if isinstance(baseline_latency, (int, float)) and isinstance(run_latency, (int, float)):
            latency_deltas[suite_label] = float(run_latency) - float(baseline_latency)

        enriched.append(
            {
                **run,
                "suite_label": suite_label,
                "primary_metric": suite_value,
                "delta": delta,
            }
        )

    severity = _severity_from_delta(worst_delta, max_drop)
    has_regression = worst_delta > max_drop
    return RegressionSummary(
        primary_metric_name=metric_name,
        baseline_metric=baseline_primary,
        suite_metrics=enriched,
        worst_suite=worst_name,
        worst_delta=worst_delta,
        severity=severity,
        has_regression=has_regression,
        latency_deltas=latency_deltas,
    )
