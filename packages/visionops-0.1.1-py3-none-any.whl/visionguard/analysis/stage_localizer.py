from __future__ import annotations

from typing import Any

from visionguard.models import StageLocalization


def localize_failure_stage(
    regression_rows: list[dict[str, Any]],
    baseline_run_ok: bool,
    run_logs: list[str],
    parser_errors: list[str] | None = None,
) -> StageLocalization:
    parser_errors = parser_errors or []
    reasons: list[str] = []

    if not baseline_run_ok:
        reasons.append("Baseline execution failed; likely dependency/config/environment mismatch.")
        return StageLocalization(stage="environment/config issue", reasons=reasons, confidence=0.92)

    joined_logs = "\n".join(run_logs).lower()
    if parser_errors or "parser" in joined_logs and ("error" in joined_logs or "exception" in joined_logs):
        reasons.append("Parser-related errors observed while pipeline otherwise executes.")
        return StageLocalization(stage="parser/business-rule issue", reasons=reasons, confidence=0.81)

    deltas = [float(row.get("delta", 0.0)) for row in regression_rows]
    high_count = sum(1 for d in deltas if d > 0.08)
    total = max(len(deltas), 1)
    heavy_global_drop = high_count / total >= 0.6

    suite_labels = " ".join(str(r.get("suite_label", "")) for r in regression_rows).lower()
    if any(x in suite_labels for x in ("crop", "warp", "compression", "jpeg")):
        reasons.append("Degradation concentrated in crop/warp/compression families.")
        return StageLocalization(stage="preprocessing-sensitive", reasons=reasons, confidence=0.73)

    if "raw outputs exist but final outputs vanish" in joined_logs or "threshold" in joined_logs:
        reasons.append("Evidence suggests raw outputs are filtered downstream.")
        return StageLocalization(stage="postprocessing/threshold issue", reasons=reasons, confidence=0.77)

    if heavy_global_drop:
        reasons.append("Strong degradation across most corruption families.")
        return StageLocalization(stage="model robustness issue", reasons=reasons, confidence=0.74)

    if any("module not found" in s.lower() or "no such file" in s.lower() for s in run_logs):
        reasons.append("Runtime module/file missing errors detected.")
        return StageLocalization(stage="environment/config issue", reasons=reasons, confidence=0.85)

    reasons.append("No conclusive pattern from available runtime evidence.")
    return StageLocalization(stage="unknown", reasons=reasons, confidence=0.4)
