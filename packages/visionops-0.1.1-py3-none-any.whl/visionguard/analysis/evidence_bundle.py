from __future__ import annotations

from typing import Any

from visionguard.analysis.fix_rules import suggest_fixes
from visionguard.models import EvidenceBundle, RepoMap, StageLocalization


def build_evidence_bundle(
    repo_summary: RepoMap,
    baseline_metrics: dict[str, Any],
    suite_metrics: list[dict[str, Any]],
    stage_localization: StageLocalization,
    logs: list[str],
    artifact_paths: dict[str, str],
) -> EvidenceBundle:
    failing = [row for row in suite_metrics if float(row.get("delta", 0.0)) > 0.0]
    explanations = [
        f"Worst suite: {max(suite_metrics, key=lambda x: x.get('delta', 0.0)).get('suite_label')}"
        if suite_metrics
        else "No suite metrics available.",
        *stage_localization.reasons,
    ]
    fixes = suggest_fixes(stage_localization.stage, failing)
    return EvidenceBundle(
        repo_summary=repo_summary,
        baseline_metrics=baseline_metrics,
        suite_metrics=suite_metrics,
        failing_suites=failing,
        stage_localization=stage_localization,
        log_snippets=logs[-12:],
        artifact_paths=artifact_paths,
        heuristic_explanations=explanations,
        fix_candidates=fixes,
    )
