from __future__ import annotations

import pytest

from labenv_embedding_cache.standards import (
    canonicalize_registry_key,
    get_registry_alias_map,
    registry_keys_equivalent,
)


def test_get_registry_alias_map_contains_bert_legacy_aliases() -> None:
    aliases = get_registry_alias_map()
    assert aliases["bert"] == "bert-uncased"
    assert aliases["bert_base_cased"] == "bert-cased"
    assert aliases["bert__l2"] == "bert-uncased__l2"
    assert aliases["bert_base_cased__l2"] == "bert-cased__l2"


def test_canonicalize_registry_key_accepts_new_and_legacy_keys() -> None:
    assert canonicalize_registry_key("bert") == "bert-uncased"
    assert canonicalize_registry_key("bert-uncased") == "bert-uncased"
    assert canonicalize_registry_key("bert_base_cased") == "bert-cased"
    assert canonicalize_registry_key("bert-cased") == "bert-cased"
    assert canonicalize_registry_key(None) is None


def test_registry_keys_equivalent_uses_alias_canonicalization() -> None:
    assert registry_keys_equivalent("bert", "bert-uncased")
    assert registry_keys_equivalent("bert_base_cased", "bert-cased")
    assert not registry_keys_equivalent("bert", "bert-cased")


def test_canonicalize_registry_key_strict_rejects_unknown_key() -> None:
    with pytest.raises(ValueError):
        canonicalize_registry_key("unknown-registry-key", strict=True)
