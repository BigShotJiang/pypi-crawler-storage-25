from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from labenv_embedding_cache.api import build_cache_metadata
from labenv_embedding_cache.fingerprints import build_dataset_config_hash
from labenv_embedding_cache.paths import get_embedding_cache_path


@dataclass
class DataFilesConfig:
    train: str
    test: str


@dataclass
class TokenizerObjectConfig:
    value: str


@dataclass
class DatasetConfig:
    name: str = "ag_news"
    source: str = "hf"
    hf_path: Optional[str] = None
    sklearn_dataset: Optional[str] = None
    kaggle_handle: Optional[str] = None
    data_files: Any = None
    splits: list[str] = field(default_factory=lambda: ["train", "test"])
    text_column: str = "text"
    label_column: str = "label"
    label_columns: list[str] = field(default_factory=list)
    label_delimiter: Optional[str] = None
    label_map: dict[int, str] = field(default_factory=lambda: {0: "neg", 1: "pos"})
    label_remap: dict[int, int] = field(default_factory=dict)
    drop_multi_label_samples: bool = False
    multi_label: bool = False
    trust_remote_code: bool = False
    shuffle: bool = True
    shuffle_seed: int = 42
    text_preprocess_id: Optional[str] = None
    tag: Optional[str] = None
    cache_tag: Optional[str] = None


@dataclass
class EmbeddingConfig:
    name: str = "bert-base-uncased"
    type: str = "hf_transformer"
    model_name: Optional[str] = "bert-base-uncased"
    hidden_state_layer: Optional[int] = -1
    pooling: Optional[str] = "mean"
    cache_all_layers: bool = False
    torch_dtype: Optional[str] = "bfloat16"
    embedding_seed: Optional[int] = 7
    normalize_embeddings: bool = False
    tokenizer: Any = None


@dataclass
class PathsConfig:
    embedding_cache_tag: Optional[str] = None


@dataclass
class ReproducibilityConfig:
    seed: int = 7


@dataclass
class EvaluationConfig:
    random_state: int = 42


@dataclass
class CebraConfig:
    conditional: str = "discrete"


@dataclass
class CebraLikeAppConfig:
    dataset: DatasetConfig
    embedding: EmbeddingConfig
    paths: PathsConfig = field(default_factory=PathsConfig)
    reproducibility: ReproducibilityConfig = field(default_factory=ReproducibilityConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)
    cebra: CebraConfig = field(default_factory=CebraConfig)


@dataclass
class LarmLikeAppConfig:
    dataset: DatasetConfig
    source_embedding: EmbeddingConfig
    target_embedding: EmbeddingConfig
    paths: PathsConfig = field(default_factory=PathsConfig)
    reproducibility: ReproducibilityConfig = field(default_factory=ReproducibilityConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)
    cebra: CebraConfig = field(default_factory=CebraConfig)


@dataclass
class SharedCacheConfig:
    dataset: Any
    paths: Any
    reproducibility: Any
    evaluation: Any
    cebra: Any
    embedding: Any


def _sample_payload() -> tuple[list[str], list[str], list[int]]:
    ids = ["id-1", "id-2"]
    texts = ["hello world", "typed appconfig compatibility"]
    labels = [0, 1]
    return ids, texts, labels


def test_cebra_like_typed_config_matches_dict_metadata_and_path(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("EMBEDDING_CACHE_DIR", str(tmp_path / "cache"))

    ids, texts, labels = _sample_payload()
    typed_cfg = CebraLikeAppConfig(
        dataset=DatasetConfig(
            data_files=DataFilesConfig(train="train.jsonl", test="test.jsonl"),
        ),
        embedding=EmbeddingConfig(
            tokenizer=TokenizerObjectConfig(value="unused-tokenizer-object"),
        ),
    )

    raw_cfg = {
        "dataset": {
            "name": "ag_news",
            "source": "hf",
            "data_files": {"train": "train.jsonl", "test": "test.jsonl"},
            "splits": ["train", "test"],
            "text_column": "text",
            "label_column": "label",
            "label_columns": [],
            "label_map": {0: "neg", 1: "pos"},
            "label_remap": {},
            "drop_multi_label_samples": False,
            "multi_label": False,
            "trust_remote_code": False,
            "shuffle": True,
            "shuffle_seed": 42,
            "text_preprocess_id": None,
            "tag": None,
            "cache_tag": None,
        },
        "embedding": {
            "name": "bert-base-uncased",
            "type": "hf_transformer",
            "model_name": "bert-base-uncased",
            "hidden_state_layer": -1,
            "pooling": "mean",
            "cache_all_layers": False,
            "torch_dtype": "bfloat16",
            "embedding_seed": 7,
            "normalize_embeddings": False,
            "tokenizer": {"value": "unused-tokenizer-object"},
        },
        "paths": {"embedding_cache_tag": None},
        "reproducibility": {"seed": 7},
        "evaluation": {"random_state": 42},
        "cebra": {"conditional": "discrete"},
    }

    typed_metadata = build_cache_metadata(typed_cfg, ids, texts, labels=labels)
    raw_metadata = build_cache_metadata(raw_cfg, ids, texts, labels=labels)
    assert typed_metadata == raw_metadata

    typed_path = get_embedding_cache_path(
        typed_cfg,
        dataset_key=str(typed_metadata["dataset_key"]),
        variant_tag=str(typed_metadata["variant_tag"]),
    )
    raw_path = get_embedding_cache_path(
        raw_cfg,
        dataset_key=str(raw_metadata["dataset_key"]),
        variant_tag=str(raw_metadata["variant_tag"]),
    )
    assert typed_path == raw_path


def test_larm_like_typed_config_matches_dict_cache_projection(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("EMBEDDING_CACHE_DIR", str(tmp_path / "cache"))

    ids, texts, labels = _sample_payload()
    typed_cfg = LarmLikeAppConfig(
        dataset=DatasetConfig(data_files=DataFilesConfig(train="train.jsonl", test="test.jsonl")),
        source_embedding=EmbeddingConfig(name="bert-base-uncased", model_name="bert-base-uncased"),
        target_embedding=EmbeddingConfig(name="roberta-base", model_name="roberta-base"),
    )

    raw_cfg = {
        "dataset": {
            "name": "ag_news",
            "source": "hf",
            "data_files": {"train": "train.jsonl", "test": "test.jsonl"},
            "splits": ["train", "test"],
            "text_column": "text",
            "label_column": "label",
            "label_columns": [],
            "label_map": {0: "neg", 1: "pos"},
            "label_remap": {},
            "drop_multi_label_samples": False,
            "multi_label": False,
            "trust_remote_code": False,
            "shuffle": True,
            "shuffle_seed": 42,
        },
        "source_embedding": {
            "name": "bert-base-uncased",
            "type": "hf_transformer",
            "model_name": "bert-base-uncased",
            "hidden_state_layer": -1,
            "pooling": "mean",
            "cache_all_layers": False,
            "torch_dtype": "bfloat16",
            "embedding_seed": 7,
            "normalize_embeddings": False,
        },
        "target_embedding": {
            "name": "roberta-base",
            "type": "hf_transformer",
            "model_name": "roberta-base",
        },
        "paths": {"embedding_cache_tag": None},
        "reproducibility": {"seed": 7},
        "evaluation": {"random_state": 42},
        "cebra": {"conditional": "discrete"},
    }

    typed_cache_cfg = SharedCacheConfig(
        dataset=typed_cfg.dataset,
        paths=typed_cfg.paths,
        reproducibility=typed_cfg.reproducibility,
        evaluation=typed_cfg.evaluation,
        cebra=typed_cfg.cebra,
        embedding=typed_cfg.source_embedding,
    )
    raw_cache_cfg = {
        "dataset": raw_cfg["dataset"],
        "paths": raw_cfg["paths"],
        "reproducibility": raw_cfg["reproducibility"],
        "evaluation": raw_cfg["evaluation"],
        "cebra": raw_cfg["cebra"],
        "embedding": raw_cfg["source_embedding"],
    }

    typed_metadata = build_cache_metadata(typed_cache_cfg, ids, texts, labels=labels)
    raw_metadata = build_cache_metadata(raw_cache_cfg, ids, texts, labels=labels)
    assert typed_metadata == raw_metadata

    typed_path = get_embedding_cache_path(
        typed_cache_cfg,
        dataset_key=str(typed_metadata["dataset_key"]),
        variant_tag=str(typed_metadata["variant_tag"]),
    )
    raw_path = get_embedding_cache_path(
        raw_cache_cfg,
        dataset_key=str(raw_metadata["dataset_key"]),
        variant_tag=str(raw_metadata["variant_tag"]),
    )
    assert typed_path == raw_path


def test_dataset_hash_legacy_missing_fields_match_typed_defaults() -> None:
    @dataclass
    class LegacyLikeDataset:
        name: str = "ag_news"
        source: str = "hf"
        text_column: str = "text"
        label_column: str = "label"
        splits: list[str] = field(default_factory=list)
        label_columns: list[str] = field(default_factory=list)
        label_map: dict[str, str] = field(default_factory=dict)
        label_remap: dict[str, str] = field(default_factory=dict)
        drop_multi_label_samples: bool = False
        multi_label: bool = False
        trust_remote_code: bool = False

    @dataclass
    class LegacyLikeCfg:
        dataset: LegacyLikeDataset = field(default_factory=LegacyLikeDataset)
        cebra: CebraConfig = field(default_factory=CebraConfig)

    typed_cfg = LegacyLikeCfg()
    raw_cfg = {
        "dataset": {
            "name": "ag_news",
            "source": "hf",
            "text_column": "text",
            "label_column": "label",
        },
        "cebra": {"conditional": "discrete"},
    }

    assert build_dataset_config_hash(typed_cfg) == build_dataset_config_hash(raw_cfg)
