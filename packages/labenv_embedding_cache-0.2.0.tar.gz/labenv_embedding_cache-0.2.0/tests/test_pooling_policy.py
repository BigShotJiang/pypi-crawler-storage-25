from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest

from labenv_embedding_cache.api import build_cache_metadata, get_or_compute_embeddings
from labenv_embedding_cache.identity import augment_metadata_with_identity
from labenv_embedding_cache.paths import build_embedding_variant_tag
from labenv_embedding_cache.store import load_embedding_cache


def _base_cfg(*, embedding_type: str, model_name: str, pooling=None) -> dict[str, object]:
    return {
        "dataset": {
            "name": "ag_news",
            "source": "hf",
            "shuffle": False,
            "text_column": "text",
            "label_column": "label",
        },
        "embedding": {
            "name": model_name,
            "type": embedding_type,
            "model_name": model_name,
            "pooling": pooling,
            "cache_all_layers": False,
        },
        "paths": {"embedding_cache_tag": None},
        "reproducibility": {"seed": 7},
        "evaluation": {"random_state": 7},
        "cebra": {"conditional": "discrete"},
    }


def test_build_cache_metadata_canonicalizes_missing_pooling_to_mean() -> None:
    cfg = _base_cfg(
        embedding_type="sentence_transformer",
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        pooling=None,
    )

    metadata = build_cache_metadata(cfg, ["id-1", "id-2"], ["alpha", "beta"], labels=[0, 1])

    assert metadata["pooling"] == "mean"
    assert "pool=mean" in str(metadata["variant_tag"])


def test_missing_pooling_and_explicit_mean_share_identity_hash() -> None:
    base_metadata = {
        "dataset_key": "dk",
        "dataset_config_hash": "dch",
        "text_manifest_hash": "tmh",
        "label_manifest_hash": "lmh",
        "ids_sha256": "idsh",
        "dataset_shuffle": False,
        "dataset_shuffle_seed": 7,
        "embedding_seed": 5,
        "variant_tag": "layer=final__all_layers=false__pool=mean__dtype=none__embseed=5",
        "rulebook_id": "shared_lm_embedding_cache:v1",
        "registry_key": "sentence_bert",
        "embedding_type": "sentence_transformer",
        "hidden_state_layer": None,
        "cache_all_layers": False,
        "torch_dtype": None,
        "tokenizer_id": None,
    }

    missing_pooling = augment_metadata_with_identity(dict(base_metadata))
    explicit_mean = augment_metadata_with_identity({**base_metadata, "pooling": "mean"})

    assert missing_pooling["pooling"] == "mean"
    assert missing_pooling["identity_hash"] == explicit_mean["identity_hash"]


def test_non_hf_custom_pooling_override_is_rejected() -> None:
    cfg = _base_cfg(
        embedding_type="sentence_transformer",
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        pooling="cls",
    )

    with pytest.raises(ValueError, match="does not support pooling override"):
        build_embedding_variant_tag(cfg["embedding"])

    with pytest.raises(ValueError, match="does not support pooling override"):
        build_cache_metadata(cfg, ["id-1"], ["alpha"], labels=[0])


def test_get_or_compute_embeddings_persists_canonical_pooling_header(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("EMBEDDING_CACHE_DIR", str(tmp_path / "cache"))
    cfg = _base_cfg(
        embedding_type="sentence_transformer",
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        pooling=None,
    )

    vectors, resolution = get_or_compute_embeddings(
        cfg,
        ["alpha", "beta"],
        ["id-1", "id-2"],
        labels=[0, 1],
        compute_embeddings=lambda texts, _cfg: np.asarray([[0.1, 0.2], [0.3, 0.4]], dtype=np.float32),
    )

    assert vectors.shape == (2, 2)
    assert resolution.metadata["pooling"] == "mean"

    cache = load_embedding_cache(Path(resolution.cache_path))
    assert cache is not None
    assert cache.pooling == "mean"
    assert cache.metadata["pooling"] == "mean"
