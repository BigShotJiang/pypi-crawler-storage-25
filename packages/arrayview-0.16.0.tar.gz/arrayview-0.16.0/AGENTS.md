# ArrayView

Consult `.mex/ROUTER.md` for task routing, project state, and context loading.

## Skills

Load the relevant skill before touching the corresponding area.

| Skill | When |
|-------|------|
| `frontend-designer` | Styling/layout changes to `_viewer.html` |
| `invocation-consistency` | Server startup, display-opening, env detection |
| `ui-consistency-audit` | Explicit full visual audit or pre-release validation |
| `viewer-ui-checklist` | Release prep — syncing smoke/help/docs |
| `docs-style` | README, help overlay, docstrings |

## Non-Negotiables

- Use `localhost`, not `127.0.0.1`
- Do not add logic to `_app.py` — compat shim only
- Keep `_viewer.html` as a single file — no build step
- UI visibility changes go through reconcilers (`_reconcileUI` / `_reconcileLayout` / etc.), not inline `style.display` or `classList` toggles
- Keybind changes must update both the command registry and `GUIDE_TABS`
- Do not regress working display paths when fixing another
- Avoid orphan processes; shutdown must be automatic
- For visual/animation features, propose 2–3 options before implementing

## Execution

Use **subagent-driven development**. Work in **feature branches**.

Read `CONTRIBUTING.md` before any user-facing change or PR.

## Testing

Verify narrowly — do not run the full suite unless asked.

```bash
uv run pytest tests/test_api.py -v
uv run pytest tests/test_browser.py -v
uv run pytest tests/test_mode_roundtrip.py -v
uv run pytest tests/test_command_reachability.py -v
uv run python tests/visual_smoke.py
```

## Commands

- `uv run pytest tests/<target>`
- `uv run arrayview <file>`
- `uv build`
