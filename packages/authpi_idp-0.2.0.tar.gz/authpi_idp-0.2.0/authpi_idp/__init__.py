"""AuthPI IdP SDK - Official Python SDK for AuthPI identity provider."""

from authpi_idp.agent import AgentType, AuthenticatedAgent, PrincipalType
from authpi_idp.client import IdpClient, IdpClientSync
from authpi_idp.errors import (
    AccountLinkingRequiredError,
    ConfigurationError,
    ConsentRequiredError,
    InsufficientScopeError,
    InteractionRequiredError,
    LoginRequiredError,
    OAuthError,
    RefreshError,
    SessionExpiredError,
    SubjectMismatchError,
    TokenExpiredError,
    TokenParseError,
    UserBlockedError,
)
from authpi_idp.scopes import has_access, parse_scope
from authpi_idp.types import (
    AuthorizationUrl,
    LogoutOptions,
    Organization,
    ParsedScope,
    TokenSet,
    UserInfo,
)

__all__ = [
    # Client
    "IdpClient",
    "IdpClientSync",
    # Agent
    "AuthenticatedAgent",
    "PrincipalType",
    "AgentType",
    # Types
    "AuthorizationUrl",
    "TokenSet",
    "Organization",
    "LogoutOptions",
    "UserInfo",
    "ParsedScope",
    # Errors
    "OAuthError",
    "ConfigurationError",
    "TokenExpiredError",
    "RefreshError",
    "TokenParseError",
    "SubjectMismatchError",
    "InsufficientScopeError",
    "SessionExpiredError",
    "UserBlockedError",
    "AccountLinkingRequiredError",
    "InteractionRequiredError",
    "LoginRequiredError",
    "ConsentRequiredError",
    # Scope utilities
    "has_access",
    "parse_scope",
]

__version__ = "0.2.0"
