# Changelog

## [0.2.0](https://github.com/arbfay/authpi/compare/authpi-idp-v0.1.0...authpi-idp-v0.2.0) (2026-03-28)


### Features

* SDK publishing pipeline with release-please ([#182](https://github.com/arbfay/authpi/issues/182)) ([b4f7858](https://github.com/arbfay/authpi/commit/b4f785848a973acc4f192ee737dc7c5a668ac73c))
* **sdk:** align IdP SDKs with updated INTERFACE.md spec ([#180](https://github.com/arbfay/authpi/issues/180)) ([21cc021](https://github.com/arbfay/authpi/commit/21cc021b4326edd586680f286819016322c79d99))
* **sdk:** Implement Python IdP SDK with TDD ([#91](https://github.com/arbfay/authpi/issues/91)) ([e6b7bff](https://github.com/arbfay/authpi/commit/e6b7bfffe6ffd7e28d3742a8b3589c16116e5c11))
* **sdk:** Prep work for IdP SDK implementation ([#84](https://github.com/arbfay/authpi/issues/84)) ([4f237e1](https://github.com/arbfay/authpi/commit/4f237e13bed72525aa9548f957ad009171addfd7))
