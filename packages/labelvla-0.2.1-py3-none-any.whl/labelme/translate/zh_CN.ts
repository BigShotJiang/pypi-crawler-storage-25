<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>AI-Assisted Annotation</source>
        <translation>AI辅助标注</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI在'AI-Points'和'AI-Box'模式下建议标注</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>选择'AI-Points'或'AI-Box'模式以启用AI辅助标注</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>AI Text-to-Annotation</source>
        <translation>AI提示</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>e.g., dog,cat,bird</source>
        <translation>例如：狗,猫,鸟</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Score</source>
        <translation>分数</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI根据文本提示创建标注</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>选择'Polygon'、'Rectangle'或'AI-Points'模式以启用</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <location filename="../widgets/brightness_contrast_dialog.py" line="0"/>
        <source>Brightness/Contrast</source>
        <translation>亮度/对比度</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click &amp; drag to move point</source>
        <translation>点击并拖拽以移动控制点</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click &amp; drag to move shape</source>
        <translation>点击并拖拽以移动形状</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Creating %r</source>
        <translation>正在创建 %r</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ESC to cancel</source>
        <translation>按 ESC 取消</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Enter or Space to finalize</source>
        <translation>按 Enter 或空格键完成</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Editing shapes</source>
        <translation>编辑形状</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click start point for line</source>
        <translation>点击线段起点</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click end point for line</source>
        <translation>点击线段终点</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click start point for linestrip</source>
        <translation>点击折线起点</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>点击下一个点或 Ctrl/Cmd+点击完成折线</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click center point for circle</source>
        <translation>点击圆形中心点</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click point on circumference for circle</source>
        <translation>点击圆周上的点</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click first corner for rectangle</source>
        <translation>点击矩形第一个角</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click to add point</source>
        <translation>点击以添加点</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + 点击以删除点</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + 点击在形状上创建点</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>右键点击并拖拽以复制形状</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>点击矩形对角（Shift绘制正方形）</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>点击添加包含点或Shift+Click添加排除点。Ctrl+LeftClick结束创建。</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>点击bbox的第一个角进行AI分割</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click opposite corner to segment object</source>
        <translation>点击对角以分割对象</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Flags</source>
        <translation>标记</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Annotation List</source>
        <translation>批注列表</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>选择标签类型并开始以其标注。按'Esc'取消选择。</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Label List</source>
        <translation>标签列表</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Search Filename</source>
        <translation>按文件名检索</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>File List</source>
        <translation>文件列表</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Quit</source>
        <translation>退出(&amp;Q)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Quit application</source>
        <translation>退出应用</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Open
</source>
        <translation>打开(&amp;O)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open image or label file</source>
        <translation>打开图像或标签文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open Dir</source>
        <translation>打开目录</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Next Image</source>
        <translation>下一幅(&amp;N)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>打开下一幅 (按Ctl+Shift拷贝标签)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Prev Image</source>
        <translation>上一幅(&amp;P)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>打开上一幅 (按Ctl+Shift拷贝标签)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Save
</source>
        <translation>保存(&amp;S)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save labels to file</source>
        <translation>保存标签到文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Save As</source>
        <translation>另存为(&amp;S)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save labels to a different file</source>
        <translation>保存标签到不同的文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Delete File</source>
        <translation>删除(&amp;D)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete current label file</source>
        <translation>删除当前标签文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Change Output Dir</source>
        <translation>更改输出路径(&amp;C)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Change where annotations are loaded/saved</source>
        <translation>更改载入、保存标注的路径</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save &amp;Automatically</source>
        <translation>自动保存(&amp;A)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save automatically</source>
        <translation>自动保存</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save With Image Data</source>
        <translation>同时保存图像数据</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save image data in label file</source>
        <translation>将图像数据保存到标签文件中</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Close</source>
        <translation>关闭(&amp;C)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Close current file</source>
        <translation>关闭当前文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep Previous Annotation</source>
        <translation>保留最后的标注</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing polygons</source>
        <translation>开始绘制多边形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing rectangles</source>
        <translation>开始绘制矩形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing circles</source>
        <translation>开始绘制圆形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing lines</source>
        <translation>开始创建直线</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing points</source>
        <translation>开始绘制控制点</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing linestrip. Ctrl+LeftClick ends creation.</source>
        <translation>开始绘制折线。Ctrl+单击左键结束绘制。</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Edit Shapes</source>
        <translation>编辑图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Move and edit the selected shapes</source>
        <translation>移动、编辑选中的图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete Shapes</source>
        <translation>删除图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete the selected shapes</source>
        <translation>删除选中的图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Duplicate Shapes</source>
        <translation>复制图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Create a duplicate of the selected shapes</source>
        <translation>为选中的图形创建副本</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Copy Shapes</source>
        <translation>复制图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Copy selected shapes to clipboard</source>
        <translation>复制选中图形到剪贴板</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Paste Shapes</source>
        <translation>粘贴图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Paste copied shapes</source>
        <translation>粘贴已复制的图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last point</source>
        <translation>撤销最后的控制点</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last drawn point</source>
        <translation>撤销最后一次绘制的控制点</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Remove Selected Point</source>
        <translation>移除选中的控制点</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Remove selected point from polygon</source>
        <translation>从多边形中移除选中的控制点</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo
</source>
        <translation>撤销</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last add and edit of shape</source>
        <translation>撤销最近一次添加和编辑</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Hide
Shapes</source>
        <translation>隐藏图形(&amp;H)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Hide all shapes</source>
        <translation>隐藏所有图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Show
Shapes</source>
        <translation>显示图形(&amp;S)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Show all shapes</source>
        <translation>显示所有图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Toggle
Shapes</source>
        <translation>开关图形(&amp;S)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Toggle all shapes</source>
        <translation>开关所有图形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Tutorial</source>
        <translation>教程[&amp;T]</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Show tutorial page</source>
        <translation>显示教程网页</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom</source>
        <translation>缩放</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom in or out of the image. Also accessible with {} and {} from the canvas.</source>
        <translation>缩放图像。亦可从画布的{}和{}访问</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Ctrl+Wheel</source>
        <translation>Ctrl+滚轮</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom &amp;In</source>
        <translation>放大(&amp;I)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Increase zoom level</source>
        <translation>增加缩放水平</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Zoom Out</source>
        <translation>缩小(&amp;Z)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Decrease zoom level</source>
        <translation>减小缩放水平</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Original size</source>
        <translation>原始大小(&amp;O)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom to original size</source>
        <translation>缩放至原始大小</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Keep Previous Scale</source>
        <translation>保留最后的比例(&amp;K)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep previous zoom scale</source>
        <translation>保留最后的缩放比例</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Fit Window</source>
        <translation>适应窗口(&amp;F)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom follows window size</source>
        <translation>跟随窗口大小缩放</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fit &amp;Width</source>
        <translation>适应宽度(&amp;W)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom follows window width</source>
        <translation>跟随窗口宽度缩放</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Brightness Contrast</source>
        <translation>亮度 对比度(&amp;B)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Adjust brightness and contrast</source>
        <translation>调节亮度和对比度</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Edit Label</source>
        <translation>编辑标签(&amp;E)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Modify the label of the selected shape</source>
        <translation>修改选中图形的标签</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fill Drawing Polygon</source>
        <translation>填充所绘多边形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fill polygon while drawing</source>
        <translation>绘制时填充多边形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;File</source>
        <translation>文件(&amp;F)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Edit</source>
        <translation>编辑(&amp;E)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;View</source>
        <translation>视图(&amp;V)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Help</source>
        <translation>帮助(&amp;H)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s started.</source>
        <translation>%s 启动完了</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Invalid label</source>
        <translation>无效的标签</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>无效的标签'{}'，验证类型'{}'</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error saving label data</source>
        <translation>保存标签发生错误</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error opening file</source>
        <translation>打开文件发生错误</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>文件不存在: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Loading %s...</source>
        <translation>正在载入 %s...</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error reading %s</source>
        <translation>打开文件发生错误 %s</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;Make sure &lt;i&gt;{0}&lt;/i&gt; is a valid image file.&lt;br/&gt;Supported image formats: {1}&lt;/p&gt;</source>
        <translation>lt;p&gt;请确认&lt;i&gt;{0}&lt;/i&gt;是一个合法的图像文件。&lt;br/&gt;支持的格式包括: {1}&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Loaded %s</source>
        <translation>已加载 %s</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Image &amp; Label files (%s)</source>
        <translation>图像和标签文件(%s)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - 选择图像或标签文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - 保存和加载批注的路径</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . 批注会被加载和保存在 %s</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Choose File</source>
        <translation>%s - 选择文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Label files (*%s)</source>
        <translation>标签文件(*%s)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Choose File</source>
        <translation>选择文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>You are about to permanently delete this label file, proceed anyway?</source>
        <translation>即将永久性删除此标签文件。还要继续吗?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Attention</source>
        <translation>注意</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>关闭前保存批注到&quot;{}&quot;吗?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save annotations?</source>
        <translation>保存批注吗?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>You are about to permanently delete {} shapes, proceed anyway?</source>
        <translation>即将永久性删除图形{}。还要继续吗?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Open Directory</source>
        <translation>%s - 打开目录</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>切换「保留上一个标注」模式</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>保留之前的亮度/对比度</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Preferences…</source>
        <translation>偏好设置…</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open config file in text editor</source>
        <translation>在文本编辑器中打开配置文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>No Config File</source>
        <translation>没有配置文件</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Configuration was provided as a YAML expression via command line.

To use the preferences editor, start Labelme with a config file:
  labelme --config ~/.labelmerc</source>
        <translation>配置已通过命令行以YAML表达式的形式提供。

要使用偏好设置编辑器，请使用配置文件启动Labelme：
  labelme --config ~/.labelmerc</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Configuration Errors</source>
        <translation>配置错误</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>加载配置时发现错误。请检查以下错误并重新加载配置，或忽略错误的行。</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid label file.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;请确认&lt;i&gt;%s&lt;/i&gt;是一个合法的标签文件。&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid image file.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;请确认&lt;i&gt;%s&lt;/i&gt;是一个合法的图像文件。&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Reset Layout</source>
        <translation>重置布局</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Polygon</source>
        <translation>多边形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Circle</source>
        <translation>圆形</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Line</source>
        <translation>直线</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Point</source>
        <translation>控制点</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>LineStrip</source>
        <translation>折线</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>点击添加点以分割对象。Ctrl+LeftClick结束创建。</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Draw a bounding box to segment object.</source>
        <translation>绘制边界框以分割对象。</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points 不可用</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s 不支持点提示。
请选择其他模型或使用 AI-Box 模式。</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>File list is disabled when a label file is opened</source>
        <translation>打开标签文件时，文件列表已禁用</translation>
    </message>
</context>
</TS>
