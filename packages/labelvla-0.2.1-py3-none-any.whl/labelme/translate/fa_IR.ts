<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fa_IR">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>AI-Assisted Annotation</source>
        <translation>حاشیه‌نویسی با کمک هوش مصنوعی</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI در حالت‌های 'AI-Points' و 'AI-Box' حاشیه‌نویسی پیشنهاد می‌دهد</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>حالت 'AI-Points' یا 'AI-Box' را برای فعال‌سازی حاشیه‌نویسی با کمک AI انتخاب کنید</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>AI Text-to-Annotation</source>
        <translation>پیشنهاد هوش مصنوعی</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>e.g., dog,cat,bird</source>
        <translation>مثال: سگ، گربه، پرنده</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Run</source>
        <translation>اجرا</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Score</source>
        <translation>امتیاز</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>AI creates annotations from the text prompt</source>
        <translation>هوش مصنوعی حاشیه‌نویسی‌ها را از متن ایجاد می‌کند</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>حالت 'Polygon'، 'Rectangle' یا 'AI-Points' را برای فعال‌سازی انتخاب کنید</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <location filename="../widgets/brightness_contrast_dialog.py" line="0"/>
        <source>Brightness/Contrast</source>
        <translation>روشنایی/کنتراست</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click &amp; drag to move point</source>
        <translation>کلیک و کشیدن برای جابجایی نقطه</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click &amp; drag to move shape</source>
        <translation>کلیک و کشیدن برای جابجایی شکل</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Creating %r</source>
        <translation>در حال ایجاد %r</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ESC to cancel</source>
        <translation>ESC برای لغو</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Enter or Space to finalize</source>
        <translation>Enter یا Space برای نهایی کردن</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Editing shapes</source>
        <translation>ویرایش اشکال</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click start point for line</source>
        <translation>کلیک روی نقطه شروع خط</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click end point for line</source>
        <translation>کلیک روی نقطه پایان خط</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click start point for linestrip</source>
        <translation>کلیک روی نقطه شروع خط چندتکه‌ای</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>کلیک روی نقطه بعدی یا Ctrl/Cmd+کلیک برای پایان خط چندتکه‌ای</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click center point for circle</source>
        <translation>کلیک روی نقطه مرکز دایره</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click point on circumference for circle</source>
        <translation>کلیک روی نقطه روی محیط دایره</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click first corner for rectangle</source>
        <translation>کلیک روی گوشه اول مستطیل</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click to add point</source>
        <translation>کلیک برای افزودن نقطه</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + کلیک برای حذف نقطه</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + کلیک برای ایجاد نقطه روی شکل</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>کلیک راست و کشیدن برای کپی شکل</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>کلیک روی گوشه مقابل مستطیل (Shift برای مربع)</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>روی نقاط کلیک کنید تا شامل شوند یا Shift+Click برای حذف. Ctrl+LeftClick ایجاد را پایان می‌دهد.</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>برای قطعه‌بندی AI روی اولین گوشه bbox کلیک کنید</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click opposite corner to segment object</source>
        <translation>روی گوشه مقابل برای قطعه‌بندی شیء کلیک کنید</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Flags</source>
        <translation>پرچم‌ها</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Annotation List</source>
        <translation>فهرست حاشیه‌نویسی‌ها</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>برچسب را انتخاب کنید تا شروع به حاشیه‌نویسی کنید. 'Esc' را فشار دهید تا انتخاب لغو شود.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Label List</source>
        <translation>فهرست برچسب‌ها</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Search Filename</source>
        <translation>جستجوی نام فایل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>File List</source>
        <translation>فهرست فایل‌ها</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Quit</source>
        <translation>خروج(&amp;Q)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Quit application</source>
        <translation>خروج از برنامه</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Open
</source>
        <translation>باز کردن(&amp;O)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open image or label file</source>
        <translation>باز کردن فایل تصویر یا برچسب</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open Dir</source>
        <translation>باز کردن پوشه</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Next Image</source>
        <translation>تصویر بعدی(&amp;N)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>باز کردن بعدی (Ctrl+Shift را نگه دارید تا برچسب‌ها کپی شوند)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Prev Image</source>
        <translation>تصویر قبلی(&amp;P)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>باز کردن قبلی (Ctrl+Shift را نگه دارید تا برچسب‌ها کپی شوند)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Save
</source>
        <translation>ذخیره(&amp;S)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save labels to file</source>
        <translation>ذخیره برچسب‌ها در فایل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Save As</source>
        <translation>ذخیره با نام دیگر(&amp;S)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save labels to a different file</source>
        <translation>ذخیره برچسب‌ها در فایل دیگر</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Delete File</source>
        <translation>حذف(&amp;D)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete current label file</source>
        <translation>حذف فایل برچسب فعلی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Change Output Dir</source>
        <translation>تغییر مسیر خروجی(&amp;C)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Change where annotations are loaded/saved</source>
        <translation>تغییر محل بارگذاری/ذخیره حاشیه‌نویسی‌ها</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save &amp;Automatically</source>
        <translation>ذخیره خودکار(&amp;A)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save automatically</source>
        <translation>ذخیره خودکار</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save With Image Data</source>
        <translation>ذخیره با داده تصویر</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save image data in label file</source>
        <translation>ذخیره داده تصویر در فایل برچسب</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Close</source>
        <translation>بستن(&amp;C)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Close current file</source>
        <translation>بستن فایل فعلی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep Previous Annotation</source>
        <translation>نگه داشتن حاشیه‌نویسی قبلی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing polygons</source>
        <translation>شروع رسم چندضلعی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing rectangles</source>
        <translation>شروع رسم مستطیل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing circles</source>
        <translation>شروع رسم دایره</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing lines</source>
        <translation>شروع رسم خط</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing points</source>
        <translation>شروع رسم نقطه</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing linestrip. Ctrl+LeftClick ends creation.</source>
        <translation>شروع رسم خط چندتکه‌ای. Ctrl+کلیک چپ برای پایان.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Edit Shapes</source>
        <translation>ویرایش شکل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Move and edit the selected shapes</source>
        <translation>جابجایی و ویرایش شکل‌های انتخاب شده</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete Shapes</source>
        <translation>حذف شکل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete the selected shapes</source>
        <translation>حذف شکل‌های انتخاب شده</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Duplicate Shapes</source>
        <translation>تکثیر شکل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Create a duplicate of the selected shapes</source>
        <translation>ایجاد کپی از شکل‌های انتخاب شده</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Copy Shapes</source>
        <translation>کپی شکل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Copy selected shapes to clipboard</source>
        <translation>کپی شکل‌های انتخاب شده به کلیپ‌بورد</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Paste Shapes</source>
        <translation>چسباندن شکل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Paste copied shapes</source>
        <translation>چسباندن شکل‌های کپی شده</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last point</source>
        <translation>بازگشت آخرین نقطه</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last drawn point</source>
        <translation>بازگشت آخرین نقطه رسم شده</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Remove Selected Point</source>
        <translation>حذف نقطه انتخاب شده</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Remove selected point from polygon</source>
        <translation>حذف نقطه انتخاب شده از چندضلعی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo
</source>
        <translation>بازگشت</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last add and edit of shape</source>
        <translation>بازگشت آخرین افزودن و ویرایش شکل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Hide
Shapes</source>
        <translation>مخفی کردن شکل(&amp;H)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Hide all shapes</source>
        <translation>مخفی کردن همه شکل‌ها</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Show
Shapes</source>
        <translation>نمایش شکل(&amp;S)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Show all shapes</source>
        <translation>نمایش همه شکل‌ها</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Toggle
Shapes</source>
        <translation>تغییر وضعیت شکل(&amp;S)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Toggle all shapes</source>
        <translation>تغییر وضعیت همه شکل‌ها</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Tutorial</source>
        <translation>آموزش(&amp;T)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Show tutorial page</source>
        <translation>نمایش صفحه آموزش</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom</source>
        <translation>زوم</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom in or out of the image. Also accessible with {} and {} from the canvas.</source>
        <translation>زوم کردن تصویر. همچنین از طریق {} و {} در بوم قابل دسترسی است.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Ctrl+Wheel</source>
        <translation>Ctrl+چرخ</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom &amp;In</source>
        <translation>بزرگ‌نمایی(&amp;I)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Increase zoom level</source>
        <translation>افزایش سطح زوم</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Zoom Out</source>
        <translation>کوچک‌نمایی(&amp;Z)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Decrease zoom level</source>
        <translation>کاهش سطح زوم</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Original size</source>
        <translation>اندازه اصلی(&amp;O)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom to original size</source>
        <translation>زوم به اندازه اصلی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Keep Previous Scale</source>
        <translation>نگه داشتن مقیاس قبلی(&amp;K)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep previous zoom scale</source>
        <translation>نگه داشتن مقیاس زوم قبلی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Fit Window</source>
        <translation>تناسب با پنجره(&amp;F)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom follows window size</source>
        <translation>زوم متناسب با اندازه پنجره</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fit &amp;Width</source>
        <translation>تناسب با عرض(&amp;W)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom follows window width</source>
        <translation>زوم متناسب با عرض پنجره</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Brightness Contrast</source>
        <translation>روشنایی و کنتراست(&amp;B)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Adjust brightness and contrast</source>
        <translation>تنظیم روشنایی و کنتراست</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Edit Label</source>
        <translation>ویرایش برچسب(&amp;E)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Modify the label of the selected shape</source>
        <translation>تغییر برچسب شکل انتخاب شده</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fill Drawing Polygon</source>
        <translation>پر کردن چندضلعی رسم شده</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fill polygon while drawing</source>
        <translation>پر کردن چندضلعی هنگام رسم</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;File</source>
        <translation>فایل(&amp;F)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Edit</source>
        <translation>ویرایش(&amp;E)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;View</source>
        <translation>نمایش(&amp;V)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Help</source>
        <translation>راهنما(&amp;H)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s started.</source>
        <translation>%s راه‌اندازی شد.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Invalid label</source>
        <translation>برچسب نامعتبر</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>برچسب نامعتبر '{}' با نوع اعتبارسنجی '{}'</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error saving label data</source>
        <translation>خطا در ذخیره داده برچسب</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error opening file</source>
        <translation>خطا در باز کردن فایل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>چنین فایلی وجود ندارد: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Loading %s...</source>
        <translation>در حال بارگذاری %s...</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error reading %s</source>
        <translation>خطا در خواندن %s</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;Make sure &lt;i&gt;{0}&lt;/i&gt; is a valid image file.&lt;br/&gt;Supported image formats: {1}&lt;/p&gt;</source>
        <translation>&lt;p&gt;مطمئن شوید &lt;i&gt;{0}&lt;/i&gt; یک فایل تصویر معتبر است.&lt;br/&gt;فرمت‌های تصویر پشتیبانی شده: {1}&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Loaded %s</source>
        <translation>بارگذاری شد %s</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Image &amp; Label files (%s)</source>
        <translation>فایل‌های تصویر و برچسب (%s)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - انتخاب فایل تصویر یا برچسب</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - ذخیره/بارگذاری حاشیه‌نویسی‌ها در پوشه</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . حاشیه‌نویسی‌ها در %s ذخیره/بارگذاری خواهند شد</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Choose File</source>
        <translation>%s - انتخاب فایل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Label files (*%s)</source>
        <translation>فایل‌های برچسب (*%s)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Choose File</source>
        <translation>انتخاب فایل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>You are about to permanently delete this label file, proceed anyway?</source>
        <translation>شما در حال حذف دائمی این فایل برچسب هستید، ادامه دهید؟</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Attention</source>
        <translation>توجه</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>قبل از بستن، حاشیه‌نویسی‌ها را در &quot;{}&quot; ذخیره کنید؟</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save annotations?</source>
        <translation>ذخیره حاشیه‌نویسی‌ها؟</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>You are about to permanently delete {} shapes, proceed anyway?</source>
        <translation>شما در حال حذف دائمی {} شکل هستید، ادامه دهید؟</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Open Directory</source>
        <translation>%s - باز کردن پوشه</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>تغییر وضعیت حالت &quot;نگه داشتن حاشیه‌نویسی قبلی&quot;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>نگه داشتن روشنایی/کنتراست قبلی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Preferences…</source>
        <translation>تنظیمات…</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open config file in text editor</source>
        <translation>باز کردن فایل پیکربندی در ویرایشگر متن</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>No Config File</source>
        <translation>فایل پیکربندی وجود ندارد</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Configuration was provided as a YAML expression via command line.

To use the preferences editor, start Labelme with a config file:
  labelme --config ~/.labelmerc</source>
        <translation>پیکربندی به صورت عبارت YAML از طریق خط فرمان ارائه شده است.

برای استفاده از ویرایشگر تنظیمات، Labelme را با یک فایل پیکربندی اجرا کنید:
  labelme --config ~/.labelmerc</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Configuration Errors</source>
        <translation>خطاهای پیکربندی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>هنگام بارگیری پیکربندی خطاهایی یافت شد. لطفاً خطاهای زیر را بررسی کنید و پیکربندی خود را مجدداً بارگیری کنید یا خطوط نادرست را نادیده بگیرید.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid label file.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;مطمئن شوید &lt;i&gt;%s&lt;/i&gt; یک فایل برچسب معتبر است.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid image file.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;مطمئن شوید &lt;i&gt;%s&lt;/i&gt; یک فایل تصویر معتبر است.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Reset Layout</source>
        <translation>بازنشانی چیدمان</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Polygon</source>
        <translation>چندضلعی</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Rectangle</source>
        <translation>مستطیل</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Circle</source>
        <translation>دایره</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Line</source>
        <translation>خط</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Point</source>
        <translation>نقطه</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>LineStrip</source>
        <translation>خط چندتکه‌ای</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>روی نقاط کلیک کنید تا شیء بخش‌بندی شود. Ctrl+LeftClick ایجاد را پایان می‌دهد.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Draw a bounding box to segment object.</source>
        <translation>یک کادر محصورکننده برای قطعه‌بندی شیء رسم کنید.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points در دسترس نیست</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s از دستورات نقطه‌ای پشتیبانی نمی‌کند.
لطفاً مدل دیگری انتخاب کنید یا از حالت AI-Box استفاده کنید.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>File list is disabled when a label file is opened</source>
        <translation>فهرست فایل‌ها هنگام باز بودن یک فایل برچسب غیرفعال است</translation>
    </message>
</context>
</TS>
