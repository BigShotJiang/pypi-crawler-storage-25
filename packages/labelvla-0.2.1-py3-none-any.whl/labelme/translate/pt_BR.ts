<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>AI-Assisted Annotation</source>
        <translation>Anotação Assistida por IA</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>A IA sugere anotações nos modos 'AI-Points' e 'AI-Box'</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>Selecione o modo 'AI-Points' ou 'AI-Box' para habilitar a Anotação Assistida por IA</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>AI Text-to-Annotation</source>
        <translation>Texto para Anotação IA</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>AI creates annotations from the text prompt</source>
        <translation>IA cria anotações a partir do prompt de texto</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>e.g., dog,cat,bird</source>
        <translation>ex.: cachorro, gato, pássaro</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Run</source>
        <translation>Executar</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Score</source>
        <translation>Pontuação</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Selecione o modo 'Polygon', 'Rectangle' ou 'AI-Points' para ativar</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <location filename="../widgets/brightness_contrast_dialog.py" line="0"/>
        <source>Brightness/Contrast</source>
        <translation>Brilho/Contraste</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click &amp; drag to move point</source>
        <translation>Clique e arraste para mover o ponto</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click &amp; drag to move shape</source>
        <translation>Clique e arraste para mover a forma</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Creating %r</source>
        <translation>Criando %r</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ESC to cancel</source>
        <translation>ESC para cancelar</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Enter or Space to finalize</source>
        <translation>Enter ou Espaço para finalizar</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Editing shapes</source>
        <translation>Editando formas</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click start point for line</source>
        <translation>Clique no ponto inicial da linha</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click end point for line</source>
        <translation>Clique no ponto final da linha</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click start point for linestrip</source>
        <translation>Clique no ponto inicial da linha contínua</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Clique no próximo ponto ou Ctrl/Cmd+Clique para finalizar (linha contínua)</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click center point for circle</source>
        <translation>Clique no ponto central do círculo</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click point on circumference for circle</source>
        <translation>Clique em um ponto da circunferência do círculo</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click first corner for rectangle</source>
        <translation>Clique na primeira esquina do retângulo</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click to add point</source>
        <translation>Clique para adicionar um ponto</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>ALT + SHIFT + Clique para excluir o ponto</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ALT + Click to create point on shape</source>
        <translation>ALT + Clique para criar um ponto na forma</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Clique com o botão direito e arraste para copiar a forma</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Clique na esquina oposta do retângulo (Shift para quadrado)</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Clique em pontos para incluir ou Shift+Click para excluir. Ctrl+LeftClick finaliza a criação.</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>Clique no primeiro canto do bbox para segmentação com IA</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click opposite corner to segment object</source>
        <translation>Clique no canto oposto para segmentar o objeto</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Flags</source>
        <translation>Marcadores</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Annotation List</source>
        <translation>Lista de Anotações</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Selecione um rótulo para começar a anotar. Pressione 'Esc' para desmarcar.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Label List</source>
        <translation>Lista de Rótulos</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Search Filename</source>
        <translation>Buscar Nome do Arquivo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>File List</source>
        <translation>Lista de Arquivos</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Quit</source>
        <translation>&amp;Sair</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Quit application</source>
        <translation>Sair do aplicativo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Open
</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open image or label file</source>
        <translation>Abrir arquivo de imagem ou rótulo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open Dir</source>
        <translation>Abrir Diretório</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Next Image</source>
        <translation>Imagem &amp;Seguinte</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Abrir seguinte (mantenha Ctrl+Shift para copiar rótulos)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Prev Image</source>
        <translation>Imagem &amp;Anterior</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Abrir anterior (mantenha Ctrl+Shift para copiar rótulos)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Save
</source>
        <translation>&amp;Salvar</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save labels to file</source>
        <translation>Salvar rótulos no arquivo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Save As</source>
        <translation>Salvar &amp;Como</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save labels to a different file</source>
        <translation>Salvar rótulos em um arquivo diferente</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Delete File</source>
        <translation>&amp;Excluir Arquivo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete current label file</source>
        <translation>Excluir arquivo de rótulo atual</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Change Output Dir</source>
        <translation>Alterar Diretório de &amp;Saída</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Change where annotations are loaded/saved</source>
        <translation>Alterar onde as anotações são carregadas/salvas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save &amp;Automatically</source>
        <translation>Salvar &amp;Automaticamente</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save automatically</source>
        <translation>Salvar automaticamente</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save With Image Data</source>
        <translation>Salvar com Dados da Imagem</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save image data in label file</source>
        <translation>Salvar dados da imagem no arquivo de rótulo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Close current file</source>
        <translation>Fechar arquivo atual</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep Previous Annotation</source>
        <translation>Manter Anotação Anterior</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing polygons</source>
        <translation>Começar a desenhar polígonos</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing rectangles</source>
        <translation>Começar a desenhar retângulos</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing circles</source>
        <translation>Começar a desenhar círculos</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing lines</source>
        <translation>Começar a desenhar linhas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing points</source>
        <translation>Começar a desenhar pontos</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing linestrip. Ctrl+LeftClick ends creation.</source>
        <translation>Começar a desenhar linha contínua. Ctrl+Clique esquerdo finaliza a criação.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Edit Shapes</source>
        <translation>Editar Formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Move and edit the selected shapes</source>
        <translation>Mover e editar as formas selecionadas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete Shapes</source>
        <translation>Excluir Formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete the selected shapes</source>
        <translation>Excluir as formas selecionadas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Duplicate Shapes</source>
        <translation>Duplicar Formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Criar uma cópia das formas selecionadas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Copy Shapes</source>
        <translation>Copiar Formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Copy selected shapes to clipboard</source>
        <translation>Copiar formas selecionados para a área de transferência</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Paste Shapes</source>
        <translation>Colar Formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Paste copied shapes</source>
        <translation>Colar formas copiadas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last point</source>
        <translation>Desfazer último ponto</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last drawn point</source>
        <translation>Desfazer último ponto desenhado</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Remove Selected Point</source>
        <translation>Remover Ponto Selecionado</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Remove selected point from polygon</source>
        <translation>Remover ponto selecionado do polígono</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo
</source>
        <translation>Desfazer</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last add and edit of shape</source>
        <translation>Desfazer última adição e edição de forma</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Hide
Shapes</source>
        <translation>Ocultar &amp;Formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Hide all shapes</source>
        <translation>Ocultar todas as formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Show
Shapes</source>
        <translation>Mostrar &amp;Formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Show all shapes</source>
        <translation>Mostrar todas as formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Toggle
Shapes</source>
        <translation>Alternar &amp;Formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Toggle all shapes</source>
        <translation>Alternar todas as formas</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Tutorial</source>
        <translation>&amp;Tutorial</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Show tutorial page</source>
        <translation>Mostrar página do tutorial</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom in or out of the image. Also accessible with {} and {} from the canvas.</source>
        <translation>Aproximar ou afastar a imagem. Também acessível com {} e {} a partir da tela.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Ctrl+Wheel</source>
        <translation>Ctrl+Roda</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom &amp;In</source>
        <translation>&amp;Aproximar</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Increase zoom level</source>
        <translation>Aumentar nível de zoom</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Zoom Out</source>
        <translation>&amp;Afastar</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Decrease zoom level</source>
        <translation>Diminuir nível de zoom</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Original size</source>
        <translation>Tamanho &amp;Original</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom to original size</source>
        <translation>Zoom para o tamanho original</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Keep Previous Scale</source>
        <translation>Manter Escala &amp;Anterior</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep previous zoom scale</source>
        <translation>Manter escala de zoom anterior</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Fit Window</source>
        <translation>Ajustar à &amp;Janela</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom follows window size</source>
        <translation>O zoom segue o tamanho da janela</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fit &amp;Width</source>
        <translation>Ajustar à &amp;Largura</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom follows window width</source>
        <translation>O zoom segue a largura da janela</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Brightness Contrast</source>
        <translation>Brilho e &amp;Contraste</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Adjust brightness and contrast</source>
        <translation>Ajustar brilho e contraste</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Edit Label</source>
        <translation>&amp;Editar Rótulo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Modify the label of the selected shape</source>
        <translation>Modificar o rótulo da forma selecionada</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fill Drawing Polygon</source>
        <translation>Preencher Polígono ao Desenhar</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fill polygon while drawing</source>
        <translation>Preencher polígono enquanto desenha</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;View</source>
        <translation>&amp;Visualizar</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s started.</source>
        <translation>%s iniciado.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Invalid label</source>
        <translation>Rótulo inválido</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Rótulo inválido '{}' com tipo de validação '{}'</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error saving label data</source>
        <translation>Erro ao salvar dados do rótulo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error opening file</source>
        <translation>Erro ao abrir arquivo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Arquivo não encontrado: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Loading %s...</source>
        <translation>Carregando %s...</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error reading %s</source>
        <translation>Erro ao ler %s</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;Make sure &lt;i&gt;{0}&lt;/i&gt; is a valid image file.&lt;br/&gt;Supported image formats: {1}&lt;/p&gt;</source>
        <translation>&lt;p&gt;Certifique-se de que &lt;i&gt;{0}&lt;/i&gt; seja um arquivo de imagem válido.&lt;br/&gt;Formatos de imagem suportados: {1}&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Loaded %s</source>
        <translation>Carregado %s</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Image &amp; Label files (%s)</source>
        <translation>Arquivos de Imagem e Rótulo (%s)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Escolher Arquivo de Imagem ou Rótulo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Salvar/Carregar Anotações no Diretório</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . As anotações serão salvas/carregadas em %s</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Choose File</source>
        <translation>%s - Escolher Arquivo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Label files (*%s)</source>
        <translation>Arquivos de rótulo (*%s)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Choose File</source>
        <translation>Escolher Arquivo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>You are about to permanently delete this label file, proceed anyway?</source>
        <translation>Você está prestes a excluir permanentemente este arquivo de rótulo, continuar mesmo assim?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Attention</source>
        <translation>Atenção</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Salvar anotações em &quot;{}&quot; antes de fechar?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save annotations?</source>
        <translation>Salvar anotações?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>You are about to permanently delete {} shapes, proceed anyway?</source>
        <translation>Você está prestes a excluir permanentemente {} formas, continuar mesmo assim?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Open Directory</source>
        <translation>%s - Abrir Diretório</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>Alternar modo &quot;manter anotação anterior&quot;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Manter Brilho/Contraste Anterior</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Preferences…</source>
        <translation>Preferências…</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open config file in text editor</source>
        <translation>Abrir arquivo de configuração no editor de texto</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>No Config File</source>
        <translation>Sem arquivo de configuração</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Configuration was provided as a YAML expression via command line.

To use the preferences editor, start Labelme with a config file:
  labelme --config ~/.labelmerc</source>
        <translation>A configuração foi fornecida como uma expressão YAML via linha de comando.

Para usar o editor de preferências, inicie o Labelme com um arquivo de configuração:
  labelme --config ~/.labelmerc</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Configuration Errors</source>
        <translation>Erros de Configuração</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Foram encontrados erros ao carregar a configuração. Por favor, revise os erros abaixo e recarregue sua configuração ou ignore as linhas com erro.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid label file.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Certifique-se de que &lt;i&gt;%s&lt;/i&gt; seja um arquivo de rótulo válido.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid image file.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Certifique-se de que &lt;i&gt;%s&lt;/i&gt; seja um arquivo de imagem válido.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Reset Layout</source>
        <translation>Redefinir layout</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Polygon</source>
        <translation>Polígono</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Rectangle</source>
        <translation>Retângulo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Circle</source>
        <translation>Círculo</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Line</source>
        <translation>Linha</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Point</source>
        <translation>Ponto</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>LineStrip</source>
        <translation>Linha Contínua</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Clique em pontos para segmentar o objeto. Ctrl+LeftClick finaliza a criação.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Draw a bounding box to segment object.</source>
        <translation>Desenhe uma caixa delimitadora para segmentar o objeto.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points indisponível</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s não suporta prompts de pontos.
Selecione um modelo diferente ou use o modo AI-Box.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>File list is disabled when a label file is opened</source>
        <translation>A lista de arquivos está desativada quando um arquivo de rótulos é aberto</translation>
    </message>
</context>
</TS>
