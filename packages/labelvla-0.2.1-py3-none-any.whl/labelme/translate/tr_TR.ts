<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr_TR">
<context>
    <name>AiAssistedAnnotationWidget</name>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>AI-Assisted Annotation</source>
        <translation>AI Destekli Etiketleme</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>AI suggests annotation in &apos;AI-Points&apos; and &apos;AI-Box&apos; modes</source>
        <translation>AI, 'AI-Points' ve 'AI-Box' modlarında etiketleme önerir</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_assisted_annotation_widget.py" line="0"/>
        <source>Select &apos;AI-Points&apos; or &apos;AI-Box&apos; mode to enable AI-Assisted Annotation</source>
        <translation>AI Destekli Açıklamayı etkinleştirmek için 'AI-Points' veya 'AI-Box' modunu seçin</translation>
    </message>
</context>
<context>
    <name>AiTextToAnnotationWidget</name>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>AI Text-to-Annotation</source>
        <translation>AI Metinden Etiketleme</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>e.g., dog,cat,bird</source>
        <translation>örn., köpek,kedi,kuş</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Run</source>
        <translation>Çalıştır</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Score</source>
        <translation>Skor</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>IoU</source>
        <translation>IoU</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>AI creates annotations from the text prompt</source>
        <translation>AI, metin isteminden etiketlemeler oluşturur</translation>
    </message>
    <message>
        <location filename="../widgets/_ai_text_to_annotation_widget.py" line="0"/>
        <source>Select &apos;Polygon&apos;, &apos;Rectangle&apos;, or &apos;AI-Points&apos; mode to enable</source>
        <translation>Etkinleştirmek için 'Polygon', 'Rectangle' veya 'AI-Points' modunu seçin</translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <location filename="../widgets/brightness_contrast_dialog.py" line="0"/>
        <source>Brightness/Contrast</source>
        <translation>Parlaklık/Kontrast</translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click &amp; drag to move point</source>
        <translation>Noktayı taşımak için tıkla ve sürükle</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click &amp; drag to move shape</source>
        <translation>Şekli taşımak için tıkla ve sürükle</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Creating %r</source>
        <translation>%r oluşturuluyor</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ESC to cancel</source>
        <translation>İptal için ESC</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Enter or Space to finalize</source>
        <translation>Bitirmek için Enter veya Space</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Editing shapes</source>
        <translation>Şekiller düzenleniyor</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click start point for line</source>
        <translation>Çizgi için başlangıç noktasına tıkla</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click end point for line</source>
        <translation>Çizgi için bitiş noktasına tıkla</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click start point for linestrip</source>
        <translation>Çizgi şeridi için başlangıç noktasına tıkla</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click next point or finish by Ctrl/Cmd+Click for linestrip</source>
        <translation>Çizgi şeridi için sonraki noktaya tıkla veya Ctrl/Cmd+tıkla ile bitir</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click center point for circle</source>
        <translation>Daire için merkez noktaya tıkla</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click point on circumference for circle</source>
        <translation>Daire için çevre üzerindeki bir noktaya tıkla</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click first corner for rectangle</source>
        <translation>Dikdörtgen için ilk köşeye tıkla</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click to add point</source>
        <translation>Nokta eklemek için tıkla</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ALT + SHIFT + Click to delete point</source>
        <translation>Noktayı silmek için ALT + SHIFT + tıkla</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>ALT + Click to create point on shape</source>
        <translation>Şekil üzerinde nokta oluşturmak için ALT + tıkla</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Right-click &amp; drag to copy shape</source>
        <translation>Şekli kopyalamak için sağ tıkla ve sürükle</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click opposite corner for rectangle (Shift for square)</source>
        <translation>Dikdörtgen için karşı köşeye tıkla (kare için Shift)</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click points to include or Shift+Click to exclude. Ctrl+LeftClick ends creation.</source>
        <translation>Dahil etmek için noktalara tıkla veya hariç tutmak için Shift+Click. Ctrl+LeftClick oluşturmayı bitirir.</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click first corner of bbox for AI segmentation</source>
        <translation>AI segmentasyonu için bbox'ın ilk köşesine tıklayın</translation>
    </message>
    <message>
        <location filename="../widgets/canvas.py" line="0"/>
        <source>Click opposite corner to segment object</source>
        <translation>Nesneyi segmentlemek için karşı köşeye tıklayın</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Flags</source>
        <translation>Bayraklar</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Annotation List</source>
        <translation>Etiketleme Listesi</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation>Etiketlemeye başlamak için bir etiket seçin. Seçimi kaldırmak için 'Esc' tuşuna basın.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Label List</source>
        <translation>Etiket Listesi</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Search Filename</source>
        <translation>Dosya Adı Ara</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>File List</source>
        <translation>Dosya Listesi</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Quit</source>
        <translation>&amp;Çıkış</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Quit application</source>
        <translation>Uygulamadan çık</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Open
</source>
        <translation>&amp;Aç</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open image or label file</source>
        <translation>Görüntü veya etiket dosyası aç</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open Dir</source>
        <translation>Dizin Aç</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Next Image</source>
        <translation>&amp;Sonraki Görüntü</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open next (hold Ctl+Shift to copy labels)</source>
        <translation>Sonrakini aç (etiketleri kopyalamak için Ctrl+Shift basılı tutun)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Prev Image</source>
        <translation>&amp;Önceki Görüntü</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open prev (hold Ctl+Shift to copy labels)</source>
        <translation>Öncekini aç (etiketleri kopyalamak için Ctrl+Shift basılı tutun)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Save
</source>
        <translation>&amp;Kaydet</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save labels to file</source>
        <translation>Etiketleri dosyaya kaydet</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Save As</source>
        <translation>Farklı &amp;Kaydet</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save labels to a different file</source>
        <translation>Etiketleri farklı bir dosyaya kaydet</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Delete File</source>
        <translation>Dosyayı &amp;Sil</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete current label file</source>
        <translation>Geçerli etiket dosyasını sil</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Change Output Dir</source>
        <translation>Çıktı Dizinini &amp;Değiştir</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Change where annotations are loaded/saved</source>
        <translation>Etiketlemelerin yüklendiği/kaydedildiği yeri değiştir</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save &amp;Automatically</source>
        <translation>Otomatik &amp;Kaydet</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save automatically</source>
        <translation>Otomatik kaydet</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save With Image Data</source>
        <translation>Görüntü Verisiyle Kaydet</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save image data in label file</source>
        <translation>Görüntü verisini etiket dosyasında kaydet</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Close current file</source>
        <translation>Geçerli dosyayı kapat</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep Previous Annotation</source>
        <translation>Önceki Etiketlemeyi Koru</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing polygons</source>
        <translation>Çokgen çizmeye başla</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing rectangles</source>
        <translation>Dikdörtgen çizmeye başla</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing circles</source>
        <translation>Daire çizmeye başla</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing lines</source>
        <translation>Çizgi çizmeye başla</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing points</source>
        <translation>Nokta çizmeye başla</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Start drawing linestrip. Ctrl+LeftClick ends creation.</source>
        <translation>Çizgi şeridi çizmeye başla. Ctrl+Sol Tık ile oluşturmayı bitirir.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Edit Shapes</source>
        <translation>Şekilleri Düzenle</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Move and edit the selected shapes</source>
        <translation>Seçili şekilleri taşı ve düzenle</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete Shapes</source>
        <translation>Şekilleri Sil</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Delete the selected shapes</source>
        <translation>Seçili şekilleri sil</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Duplicate Shapes</source>
        <translation>Şekilleri Çoğalt</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Create a duplicate of the selected shapes</source>
        <translation>Seçili şekillerin kopyasını oluştur</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Copy Shapes</source>
        <translation>Şekilleri Kopyala</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Copy selected shapes to clipboard</source>
        <translation>Seçili şekilleri panoya kopyala</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Paste Shapes</source>
        <translation>Şekilleri Yapıştır</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Paste copied shapes</source>
        <translation>Kopyalanan şekilleri yapıştır</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last point</source>
        <translation>Son noktayı geri al</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last drawn point</source>
        <translation>Çizilen son noktayı geri al</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Remove Selected Point</source>
        <translation>Seçili Noktayı Sil</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Remove selected point from polygon</source>
        <translation>Seçili noktayı çokgenden sil</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo
</source>
        <translation>Geri Al</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Undo last add and edit of shape</source>
        <translation>Şeklin son ekleme ve düzenlemesini geri al</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Hide
Shapes</source>
        <translation>Şekilleri &amp;Gizle</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Hide all shapes</source>
        <translation>Tüm şekilleri gizle</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Show
Shapes</source>
        <translation>Şekilleri &amp;Göster</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Show all shapes</source>
        <translation>Tüm şekilleri göster</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Toggle
Shapes</source>
        <translation>Şekilleri &amp;Aç/Kapat</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Toggle all shapes</source>
        <translation>Tüm şekilleri aç/kapat</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Tutorial</source>
        <translation>&amp;Öğretici</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Show tutorial page</source>
        <translation>Öğretici sayfasını göster</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom</source>
        <translation>Yakınlaştırma</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom in or out of the image. Also accessible with {} and {} from the canvas.</source>
        <translation>Görüntüyü yakınlaştır veya uzaklaştır. Tuvalde {} ve {} ile de erişilebilir.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Ctrl+Wheel</source>
        <translation>Ctrl+Tekerlek</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom &amp;In</source>
        <translation>&amp;Yakınlaştır</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Increase zoom level</source>
        <translation>Yakınlaştırma seviyesini artır</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Zoom Out</source>
        <translation>&amp;Uzaklaştır</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Decrease zoom level</source>
        <translation>Yakınlaştırma seviyesini azalt</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Original size</source>
        <translation>&amp;Orijinal boyut</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom to original size</source>
        <translation>Orijinal boyuta getir</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Keep Previous Scale</source>
        <translation>Önceki Ölçeği &amp;Koru</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep previous zoom scale</source>
        <translation>Önceki yakınlaştırma ölçeğini koru</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Fit Window</source>
        <translation>&amp;Pencereye Sığdır</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom follows window size</source>
        <translation>Yakınlaştırma pencere boyutunu izler</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fit &amp;Width</source>
        <translation>&amp;Genişliğe Sığdır</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Zoom follows window width</source>
        <translation>Yakınlaştırma pencere genişliğini izler</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Brightness Contrast</source>
        <translation>&amp;Parlaklık Kontrast</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Adjust brightness and contrast</source>
        <translation>Parlaklık ve kontrastı ayarla</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Edit Label</source>
        <translation>Etiketi &amp;Düzenle</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Modify the label of the selected shape</source>
        <translation>Seçili şeklin etiketini değiştir</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fill Drawing Polygon</source>
        <translation>Çizerken Çokgeni Doldur</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Fill polygon while drawing</source>
        <translation>Çizerken çokgeni doldur</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;File</source>
        <translation>&amp;Dosya</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Edit</source>
        <translation>&amp;Düzenle</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;View</source>
        <translation>&amp;Görünüm</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&amp;Help</source>
        <translation>&amp;Yardım</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s started.</source>
        <translation>%s başlatıldı.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Invalid label</source>
        <translation>Geçersiz etiket</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation>Doğrulama türü '{}' olan '{}' etiketi geçersiz</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error saving label data</source>
        <translation>Etiket verisi kaydedilirken hata</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation>&lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error opening file</source>
        <translation>Dosya açma hatası</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation>Böyle bir dosya yok: &lt;b&gt;%s&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Loading %s...</source>
        <translation>%s yükleniyor...</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Error reading %s</source>
        <translation>%s okunurken hata</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;Make sure &lt;i&gt;{0}&lt;/i&gt; is a valid image file.&lt;br/&gt;Supported image formats: {1}&lt;/p&gt;</source>
        <translation>&lt;p&gt;Lütfen &lt;i&gt;{0}&lt;/i&gt; geçerli bir görüntü dosyası olduğundan emin olun.&lt;br/&gt;Desteklenen görüntü biçimleri: {1}&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Loaded %s</source>
        <translation>%s yüklendi</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Image &amp; Label files (%s)</source>
        <translation>Görüntü ve Etiket dosyaları (%s)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Choose Image or Label file</source>
        <translation>%s - Görüntü veya Etiket dosyası seç</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation>%s - Dizinde Etiketlemeleri Kaydet/Yükle</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation>%s . Etiketlemeler %s içinde kaydedilecek/yüklenecek</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Choose File</source>
        <translation>%s - Dosya Seç</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Label files (*%s)</source>
        <translation>Etiket dosyaları (*%s)</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Choose File</source>
        <translation>Dosya Seç</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>You are about to permanently delete this label file, proceed anyway?</source>
        <translation>Bu etiket dosyasını kalıcı olarak silmek üzeresiniz, yine de devam edilsin mi?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Attention</source>
        <translation>Dikkat</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save annotations to &quot;{}&quot; before closing?</source>
        <translation>Kapatmadan önce etiketlemeler &quot;{}&quot; konumuna kaydedilsin mi?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Save annotations?</source>
        <translation>Etiketlemeler kaydedilsin mi?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>You are about to permanently delete {} shapes, proceed anyway?</source>
        <translation>{} şekli kalıcı olarak silmek üzeresiniz, yine de devam edilsin mi?</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s - Open Directory</source>
        <translation>%s - Dizini Aç</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Toggle &quot;keep previous annotation&quot; mode</source>
        <translation>&quot;önceki etiketlemeyi koru&quot; modunu değiştir</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Keep Previous Brightness/Contrast</source>
        <translation>Önceki Parlaklık/Kontrastı Koru</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Preferences…</source>
        <translation>Tercihler…</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Open config file in text editor</source>
        <translation>Yapılandırma dosyasını metin düzenleyicide aç</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>No Config File</source>
        <translation>Yapılandırma Dosyası Yok</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Configuration was provided as a YAML expression via command line.

To use the preferences editor, start Labelme with a config file:
  labelme --config ~/.labelmerc</source>
        <translation>Yapılandırma, komut satırı üzerinden bir YAML ifadesi olarak sağlandı.

Tercihler düzenleyicisini kullanmak için Labelme'i bir yapılandırma dosyasıyla başlatın:
  labelme --config ~/.labelmerc</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Configuration Errors</source>
        <translation>Yapılandırma Hataları</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Errors were found while loading the configuration. Please review the errors below and reload your configuration or ignore the erroneous lines.</source>
        <translation>Yapılandırma yüklenirken hatalar bulundu. Lütfen aşağıdaki hataları inceleyin ve yapılandırmayı yeniden yükleyin ya da hatalı satırları yok sayın.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid label file.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Lütfen &lt;i&gt;%s&lt;/i&gt; geçerli bir etiket dosyası olduğundan emin olun.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid image file.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Lütfen &lt;i&gt;%s&lt;/i&gt; geçerli bir görüntü dosyası olduğundan emin olun.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Reset Layout</source>
        <translation>Düzeni sıfırla</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Polygon</source>
        <translation>Çokgen</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Rectangle</source>
        <translation>Dikdörtgen</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Circle</source>
        <translation>Daire</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Line</source>
        <translation>Çizgi</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Point</source>
        <translation>Nokta</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>LineStrip</source>
        <translation>Çizgi Şeridi</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Points</source>
        <translation>AI-Points</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Click points to segment object. Ctrl+LeftClick ends creation.</source>
        <translation>Nesneyi bölütlemek için noktalara tıkla. Ctrl+LeftClick oluşturmayı bitirir.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Box</source>
        <translation>AI-Box</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>Draw a bounding box to segment object.</source>
        <translation>Nesneyi segmentlemek için bir sınırlayıcı kutu çizin.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>AI-Points Unavailable</source>
        <translation>AI-Points kullanılamıyor</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>%s does not support point prompts.
Please select a different model or use AI-Box mode.</source>
        <translation>%s nokta istemlerini desteklemiyor.
Lütfen farklı bir model seçin veya AI-Box modunu kullanın.</translation>
    </message>
    <message>
        <location filename="../app.py" line="0"/>
        <source>File list is disabled when a label file is opened</source>
        <translation>Bir etiket dosyası açıkken dosya listesi devre dışıdır</translation>
    </message>
</context>
</TS>
