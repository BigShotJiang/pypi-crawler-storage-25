"""
Tracks IAM authentication middleware.

Pre-signs an ``STS:GetCallerIdentity`` request with the caller's
credentials and attaches the resulting URL in the ``X-Fluid-Identity``
header. The tracks back end fetches that URL to resolve the caller's
ARN and check it against its allowlist.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from fluidattacks_tracks.auth.base import TracksAuthInterface

if TYPE_CHECKING:
    import aiohttp

try:
    import aiobotocore.session
    from botocore.auth import SigV4QueryAuth
    from botocore.awsrequest import AWSRequest
except ImportError as exception:
    message = "To use TracksIAMAuth, please install fluidattacks-tracks[auth]"
    raise RuntimeError(message) from exception

IDENTITY_HEADER = "X-Fluid-Identity"
STS_REGION = "us-east-1"
STS_URL = f"https://sts.{STS_REGION}.amazonaws.com/?Action=GetCallerIdentity&Version=2011-06-15"
# Capped at STS's 15-minute ceiling for pre-signed GetCallerIdentity.
# 5 minutes is short enough that a captured header has limited replay
# value while still tolerating clock skew and request retries.
SIGNATURE_VALIDITY_SECONDS = 300


class TracksIAMAuth(TracksAuthInterface):
    """Attach a pre-signed GetCallerIdentity URL as proof of the caller's IAM identity."""

    def __init__(self) -> None:
        """Initialize the Tracks IAM authentication."""
        self.session = aiobotocore.session.get_session()

    async def sign_request(
        self, request: aiohttp.ClientRequest, handler: aiohttp.ClientHandlerType
    ) -> aiohttp.ClientResponse:
        """Attach the identity header to the outgoing request."""
        credentials = await self.session.get_credentials()
        if credentials is None:
            return await handler(request)

        # Must be frozen to avoid SigV4 auth triggering a blocking refresh.
        frozen = await credentials.get_frozen_credentials()
        sts_request = AWSRequest(method="GET", url=STS_URL)
        SigV4QueryAuth(frozen, "sts", STS_REGION, expires=SIGNATURE_VALIDITY_SECONDS).add_auth(
            sts_request
        )
        # AWSRequest.url is typed Optional, but we just set it + add_auth
        # populates the signed query string back onto the same attribute.
        request.headers[IDENTITY_HEADER] = sts_request.url  # type: ignore[assignment]
        return await handler(request)
