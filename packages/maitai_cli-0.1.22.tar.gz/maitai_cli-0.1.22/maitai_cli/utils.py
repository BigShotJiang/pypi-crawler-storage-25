"""Shared utilities for Maitai CLI commands."""

import functools
import sys
from typing import Any

import typer
from maitai_cli.api import APIClient, APIError
from rich.console import Console

console = Console()


def get_client() -> APIClient:
    """Return an authenticated API client."""
    return APIClient()


def print_json(data: Any, pagination: dict | None = None) -> None:
    """Pretty-print JSON with optional pagination info.

    On a TTY, render with rich's syntax highlighter. When stdout is piped
    or redirected, emit plain JSON so downstream tools (`jq`, `python -c`,
    `> file`) can parse it; pagination metadata then goes to stderr so it
    doesn't contaminate the JSON stream. Without this, rich's ``Syntax``
    wraps/truncates long string values to its inferred width and the
    captured output is no longer valid JSON.
    """
    import json

    text = json.dumps(data, indent=2, default=str)

    if not sys.stdout.isatty():
        if pagination:
            p = pagination
            sys.stderr.write(
                f"total={p.get('total', '?')} "
                f"offset={p.get('offset', 0)} "
                f"limit={p.get('limit', 25)}\n"
            )
        sys.stdout.write(text + "\n")
        return

    from rich.syntax import Syntax

    if pagination:
        p = pagination
        console.print(
            f"[dim]total={p.get('total', '?')} offset={p.get('offset', 0)} limit={p.get('limit', 25)}[/dim]"
        )
    console.print(Syntax(text, "json", theme="monokai", line_numbers=False))


def handle_api_errors(f):
    """Decorator to catch APIError and print a clean message."""

    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except APIError as e:
            console.print(f"[red]API Error ({e.status_code}): {e.message}[/red]")
            if e.status_code == 401:
                console.print("Run [bold]maitai login[/bold] or set MAITAI_API_KEY.")
            raise typer.Exit(1)

    return wrapper
