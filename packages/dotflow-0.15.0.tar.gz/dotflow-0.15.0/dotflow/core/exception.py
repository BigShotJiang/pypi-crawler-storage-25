"""Exception module"""

from dotflow.utils import message_error, traceback_error

MESSAGE_UNKNOWN_ERROR = (
    "Unknown error, please check logs for more information."
)
MESSAGE_MISSING_STEP_DECORATOR = "A step function necessarily needs an '@action' decorator to circulate in the workflow. For more implementation details, access the documentation: https://dotflow-io.github.io/dotflow/#3-task-function."
MESSAGE_NOT_CALLABLE_OBJECT = "Problem validating the '{name}' object type; this is not a callable object"
MESSAGE_EXECUTION_NOT_EXIST = "The execution mode does not exist. Allowed parameter is 'sequential', 'background' and 'parallel'."
MESSAGE_IMPORT_MODULE_ERROR = "Error importing Python module '{module}'."
MESSAGE_PROBLEM_ORDERING = (
    "Problem with correctly ordering functions of the '{name}' class."
)
MESSAGE_MODULE_NOT_FOUND = (
    "Module '{module}' not found. Please install with 'pip install {library}'"
)


class MissingActionDecorator(Exception):
    def __init__(self):
        super().__init__(MESSAGE_MISSING_STEP_DECORATOR)


class ExecutionModeNotExist(Exception):
    def __init__(self):
        super().__init__(MESSAGE_EXECUTION_NOT_EXIST)


class ImportModuleError(Exception):
    def __init__(self, module: str):
        super().__init__(MESSAGE_IMPORT_MODULE_ERROR.format(module=module))


class NotCallableObject(Exception):
    def __init__(self, name: str):
        super().__init__(MESSAGE_NOT_CALLABLE_OBJECT.format(name=name))


class ProblemOrdering(Exception):
    def __init__(self, name: str):
        super().__init__(MESSAGE_PROBLEM_ORDERING.format(name=name))


class ModuleNotFound(Exception):
    def __init__(self, module: str, library: str):
        super().__init__(
            MESSAGE_MODULE_NOT_FOUND.format(module=module, library=library)
        )


class ExecutionWithClassError(Exception):
    def __init__(self):
        super().__init__("Unknown")


class TaskError:
    def __init__(self, error: Exception = None, attempt: int = None) -> None:
        self.attempt = attempt
        self.exception = type(error).__name__ if error else ""
        self.traceback = traceback_error(error=error) if error else ""
        self.message = message_error(error=error) if error else ""
