{%- if cookiecutter.enable_billing and cookiecutter.enable_teams %}
"""Billing schemas — Stripe Checkout, Portal, Plans, Subscriptions, Credits."""

from __future__ import annotations

from datetime import datetime
from typing import Any
{%- if cookiecutter.use_postgresql or cookiecutter.use_mongodb %}
from uuid import UUID
{%- endif %}

from pydantic import Field

from app.schemas.base import BaseSchema, TimestampSchema


# ---------------------------------------------------------------------------
# Plans & Prices
# ---------------------------------------------------------------------------

class PriceRead(BaseSchema):
{%- if cookiecutter.use_postgresql %}
    id: UUID
{%- else %}
    id: str
{%- endif %}
    stripe_price_id: str
    interval: str
    amount_cents: int
    currency: str
    trial_period_days: int | None = None
    is_active: bool
    billing_scheme: str
    credits_grant: int | None = None


class PlanRead(BaseSchema):
{%- if cookiecutter.use_postgresql %}
    id: UUID
{%- else %}
    id: str
{%- endif %}
    code: str
    display_name: str
    description: str | None = None
    is_active: bool
    sort_order: int
    features: dict[str, Any] = Field(default_factory=dict)
    base_amount_cents: int
    included_seats: int
    extra_seat_amount_cents: int
    seats_min: int
    seats_max: int | None = None
    monthly_credits_base: int
    monthly_credits_per_seat: int
    prices: list[PriceRead] = Field(default_factory=list)


class PlanList(BaseSchema):
    plans: list[PlanRead]


# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------

class SubscriptionRead(BaseSchema, TimestampSchema):
{%- if cookiecutter.use_postgresql %}
    id: UUID
    organization_id: UUID
    price_id: UUID
{%- else %}
    id: str
    organization_id: str
    price_id: str
{%- endif %}
    stripe_subscription_id: str
    stripe_customer_id: str
    seats_quantity: int
    status: str
    current_period_start: datetime
    current_period_end: datetime
    cancel_at_period_end: bool
    canceled_at: datetime | None = None
    trial_start: datetime | None = None
    trial_end: datetime | None = None


class SubscriptionChangePlan(BaseSchema):
{%- if cookiecutter.use_postgresql %}
    new_price_id: UUID
{%- else %}
    new_price_id: str
{%- endif %}


# ---------------------------------------------------------------------------
# Checkout & Portal
# ---------------------------------------------------------------------------

class CheckoutSessionCreate(BaseSchema):
    seats: int = Field(default=1, ge=1, le=500)
{%- if cookiecutter.use_postgresql %}
    price_id: UUID
{%- else %}
    price_id: str
{%- endif %}
    success_url: str = Field(..., description="Redirect URL on success")
    cancel_url: str = Field(..., description="Redirect URL on cancel")


class CheckoutSessionRead(BaseSchema):
    url: str
    session_id: str = ""


class PortalSessionRead(BaseSchema):
    url: str


# ---------------------------------------------------------------------------
# Credits
# ---------------------------------------------------------------------------

{%- if cookiecutter.enable_credits_system %}

class CreditBalanceRead(BaseSchema):
    balance: int
    low_threshold: int


class CreditTransactionRead(BaseSchema, TimestampSchema):
{%- if cookiecutter.use_postgresql %}
    id: UUID
    organization_id: UUID
    actor_user_id: UUID | None = None
    usage_event_id: UUID | None = None
{%- else %}
    id: str
    organization_id: str
    actor_user_id: str | None = None
    usage_event_id: str | None = None
{%- endif %}
    delta: int
    balance_after: int
    type: str
    description: str
    stripe_reference: str | None = None


class CreditTransactionList(BaseSchema):
    items: list[CreditTransactionRead]
    total: int


class UsageEventRead(BaseSchema, TimestampSchema):
{%- if cookiecutter.use_postgresql %}
    id: UUID
    organization_id: UUID
{%- else %}
    id: str
    organization_id: str
{%- endif %}
    model: str
    provider: str
    input_tokens: int
    output_tokens: int
    cached_tokens: int
    credits_charged: int
    ai_framework: str


class UsageByModelRead(BaseSchema):
    model: str
    provider: str
    input_tokens: int
    output_tokens: int
    cached_tokens: int
    credits_charged: int
    total_calls: int


class UsageAggregateRead(BaseSchema):
    total_input_tokens: int
    total_output_tokens: int
    total_cached_tokens: int
    total_credits_charged: int
    total_calls: int
    by_model: list[UsageByModelRead] = Field(default_factory=list)


class UsageDailyBucket(BaseSchema):
    day: str
    input_tokens: int
    output_tokens: int
    cached_tokens: int
    credits_charged: int
    total_calls: int


class UsageTimelineRead(BaseSchema):
    buckets: list[UsageDailyBucket]
    days: int

{%- endif %}
{%- else %}
"""Billing schemas — not configured (enable_billing or enable_teams is false)."""
{%- endif %}
