# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2025/12/22 16:36
# Description:
from typing import Sequence

import atrs
import logair
import polars as pl
import xcals

from ..transformer import as_transformer

logger = logair.get_logger(__name__)


class BacktestEngine:
    """
    回测引擎（基于 ATRS Rust 引擎）
    
    ⚡ 性能优势: 使用 Rust 原生实现，比纯 Python 快 50-150 倍
    """

    def __init__(self,
                 data: pl.DataFrame,
                 period: str = '1d',
                 buy_fee: float = 5e-4,
                 sell_fee: float = 10e-4,
                 mode: str = "rolling"):
        """
        初始化回测引擎
        
        Parameters
        ----------
        data : pl.DataFrame
            输入数据，必须包含以下列:
            - date, time, asset, price, close, prev_close, open, target_weight
            - limit (可选) - 涨跌停标记
        period : str
            持仓周期，如 '1d', '5d' 等
        buy_fee : float
            买入费率（默认万分之5）
        sell_fee : float
            卖出费率（默认万分之10，含印花税）
        mode : str
            换仓模式: "fixed" 或 "rolling"
        """
        self.index_names: Sequence[str] = ("date", "time", "asset")
        self._buy_fee = buy_fee
        self._sell_fee = sell_fee
        self.data: pl.DataFrame = data.sort(self.index_names)

        # 解析持仓周期
        self.period = period
        self.days = xcals.Timedelta(period).days
        if self.days < 1:
            logger.warning(f"{self.period} is too short, set to `1d`.")
            self.days = 1

        # 换仓模式
        self.mode = mode

        # 检查结果
        self.pos: pl.DataFrame | None = None
        self.ret: pl.DataFrame | None = None

        # 预检查
        self._check()

    def _check(self):
        """检查数据是否合法"""
        check_fields = {"target_weight", "price", "close", "prev_close", "open"}
        cols = set(self.data.columns)
        assert len(check_fields & cols) >= len(check_fields), f"Missing fields({check_fields - cols}) in data."

        # 检查是否需要涨跌停限制
        self.limit = "limit" in cols

    def run(self) -> None:
        """
        运行回测
        """
        # 调用 ATRS Rust 回测引擎
        result = atrs.backtest(
            weight_df=self.data,
            limit=self.limit,
            buy_fee=self._buy_fee,
            sell_fee=self._sell_fee,
            holding_period=self.days,
            mode=self.mode,
        )

        # 保存结果
        self.pos = result['pos']
        self.ret = result['ret']


@as_transformer
def bt(weight_df: pl.DataFrame,
       period: str = "1d",
       buy_fee: float = 5e-4,
       sell_fee: float = 10e-4,
       mode: str = "rolling", ) -> BacktestEngine:
    """
    便捷回测函数（基于 ATRS Rust 引擎）
    
    ⚡ 性能优势: 使用 Rust 原生实现，比纯 Python 快 10 倍
    
    Parameters
    ----------
    weight_df : pl.DataFrame
        输入数据
    period : str
        持仓周期，如 '1d', '5d' 等
    buy_fee : float
        买入费率（默认万分之5）
    sell_fee : float
        卖出费率（默认万分之10，含印花税）
    mode : str
        换仓模式: "fixed" 或 "rolling"

    Returns
    -------
    BacktestEngine
        回测引擎实例，包含 pos 和 ret 属性
    """
    be = BacktestEngine(data=weight_df,
                        period=period,
                        buy_fee=buy_fee,
                        sell_fee=sell_fee,
                        mode=mode)
    be.run()
    return be
