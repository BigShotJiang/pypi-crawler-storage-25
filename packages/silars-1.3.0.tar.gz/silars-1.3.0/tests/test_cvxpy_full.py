# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/04/09
# Description: CVXPY MFE 全量数据测试

import polars as pl
import time
from silars.alphalens.weight_fns import MFE


def load_and_prepare_data():
    """加载并准备真实数据"""
    print("加载真实数据...")
    df = pl.read_csv('data/mfe_prepare_data.csv')
    
    # 不删除空值，保留原始数据
    print(f"数据形状: {df.shape}")
    print(f"日期数: {df['date'].n_unique()}")
    print(f"股票数: {df['asset'].n_unique()}")
    print(f"行业数: {df['group'].n_unique()}")
    
    # 统计空值情况
    null_counts = df.null_count()
    print(f"\n空值统计:")
    for col in df.columns:
        null_cnt = null_counts[col][0]
        if null_cnt > 0:
            print(f"  {col}: {null_cnt} 个空值 ({null_cnt/len(df)*100:.1f}%)")
    
    return df


def test_cvxpy_full_data(df):
    """在全部数据上测试 CVXPY MFE"""
    
    print("\n" + "="*80)
    print("CVXPY MFE - 全量数据测试")
    print("="*80)
    
    # 约束参数（按照用户要求）
    mfe_params = {
        'weight_bias': -1.0,             # 不限制权重偏离
        'weight_limit': 0.005,            # 个股权重上限 0.5%
        'tc_rate': 20e-4,                 # 交易成本率
        'indust_bias': 0.02,              # 行业偏离 0.02
        'style_bias': {                   # 风格约束
            'SizeBarra': 0.2,
            'NLSizeBarra': 0.5,
        },
        'to_limit': -1.0,                 # 不限制换手
        'components_ratio': -1.0,         # 不限制成分股比例
    }
    
    print(f"\n约束条件:")
    print(f"  weight_bias: -1.0 (不限制权重偏离)")
    print(f"  weight_limit: 0.005 (个股权重上限)")
    print(f"  tc_rate: 20e-4 (交易成本)")
    print(f"  indust_bias: 0.02 (行业偏离)")
    print(f"  style_bias: SizeBarra=0.2, NLSizeBarra=0.5 (风格约束)")
    print(f"  to_limit: -1.0 (不限制换手)")
    
    dates = df['date'].unique().sort()
    print(f"\n总日期数: {len(dates)}")
    print(f"\n开始处理全部数据...\n")
    
    start_total = time.perf_counter()
    
    # 运行 MFE 优化
    try:
        MFE.set_params(**mfe_params)
        result = MFE.transform(df)
        total_time = time.perf_counter() - start_total
        
        print("\n" + "="*80)
        print("测试结果")
        print("="*80)
        
        print(f"\n✅ 优化完成!")
        print(f"  结果形状: {result.shape}")
        print(f"  总耗时: {total_time:.2f}s")
        print(f"  平均每天: {total_time/len(dates)*1000:.1f}ms")
        print(f"  处理速度: {len(dates)/total_time:.1f} 天/秒")
        
        # 统计每天的持仓数
        daily_stats = result.group_by('date').agg([
            pl.len().alias('n_positions'),
            pl.col('target_weight').sum().alias('total_weight'),
        ])
        
        print(f"\n📊 持仓统计:")
        print(f"  平均持仓数: {daily_stats['n_positions'].mean():.0f}")
        print(f"  最小持仓数: {daily_stats['n_positions'].min()}")
        print(f"  最大持仓数: {daily_stats['n_positions'].max()}")
        print(f"  权重总和: {daily_stats['total_weight'].mean():.4f}")
        
        print(f"\n📈 前10天详情:")
        for row in daily_stats.sort('date').head(10).iter_rows(named=True):
            print(f"  {row['date']}: 持仓 {row['n_positions']} 只, 权重 {row['total_weight']:.4f}")
        
        print(f"\n🎯 性能评估:")
        if total_time < 1.0:
            print(f"  ✅ 速度极快! (< 1s)")
        elif total_time < 5.0:
            print(f"  ✅ 速度很快! (< 5s)")
        elif total_time < 10.0:
            print(f"  ⚠️  速度一般: {total_time:.1f}s")
        else:
            print(f"  ❌ 速度较慢: {total_time:.1f}s")
        
        # 检查是否有失败的日期
        successful_dates = len(daily_stats)
        failed_dates = len(dates) - successful_dates
        
        print(f"\n📋 成功率:")
        print(f"  成功天数: {successful_dates}/{len(dates)}")
        print(f"  失败天数: {failed_dates}/{len(dates)}")
        
        if failed_dates > 0:
            print(f"  ⚠️  有 {failed_dates} 天优化失败")
        else:
            print(f"  ✅ 全部成功!")
        
        return result
        
    except Exception as e:
        total_time = time.perf_counter() - start_total
        print(f"\n❌ CVXPY MFE 失败!")
        print(f"  错误信息: {str(e)}")
        print(f"  已耗时: {total_time:.2f}s")
        import traceback
        traceback.print_exc()
        return None


if __name__ == '__main__':
    df = load_and_prepare_data()
    result = test_cvxpy_full_data(df)
