# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/04/10
# Description: 测试统一MFE接口（优化版 vs 原始版）

import polars as pl
import sys
sys.path.insert(0, '/Users/zhangyundi/ypkg/silars')

from silars.alphalens.weight_fns import MFE
import time


def test_unified_mfe_interface():
    """测试统一的MFE接口"""
    print("="*80)
    print("测试统一 MFE 接口 - 优化版 vs 原始版")
    print("="*80)
    
    # 加载数据
    print("\n加载数据...")
    df = pl.read_csv('data/mfe_prepare_data.csv')
    
    # 准备风格因子
    style_names = [col for col in df.columns if col.endswith('Barra')]
    print(f"风格因子: {style_names}")
    
    params = {
        'weight_bias': -1.0,
        'weight_limit': 0.005,
        'tc_rate': 20e-4,
        'indust_bias': 0.02,
        'style_bias': {'SizeBarra': 0.2, 'NLSizeBarra': 0.5},
        'to_limit': -1.0,
        'components_ratio': -1.0,
    }
    
    # 测试原始版本
    print("\n" + "="*80)
    print("测试原始版本 (use_optimized=False)")
    print("="*80)
    
    t0 = time.perf_counter()
    MFE.set_params(**params, use_optimized=False)
    result_original = MFE.transform(df)
    t1 = time.perf_counter()
    
    print(f"\n耗时: {t1-t0:.2f}s")
    print(f"结果行数: {len(result_original)}")
    
    daily_stats_orig = result_original.group_by('date').agg([
        pl.len().alias('n_positions'),
        pl.col('target_weight').sum().alias('total_weight'),
    ])
    print(f"平均持仓数: {daily_stats_orig['n_positions'].mean():.0f}")
    print(f"平均权重总和: {daily_stats_orig['total_weight'].mean():.4f}")
    
    # 测试优化版本
    print("\n" + "="*80)
    print("测试优化版本 (use_optimized=True, filtering_ratio=0.2)")
    print("="*80)
    
    t2 = time.perf_counter()
    MFE.set_params(**params, use_optimized=True, filtering_ratio=0.2)
    result_optimized = MFE.transform(df)
    t3 = time.perf_counter()
    
    print(f"\n耗时: {t3-t2:.2f}s")
    print(f"结果行数: {len(result_optimized)}")
    
    daily_stats_opt = result_optimized.group_by('date').agg([
        pl.len().alias('n_positions'),
        pl.col('target_weight').sum().alias('total_weight'),
    ])
    print(f"平均持仓数: {daily_stats_opt['n_positions'].mean():.0f}")
    print(f"平均权重总和: {daily_stats_opt['total_weight'].mean():.4f}")
    
    # 性能对比
    print("\n" + "="*80)
    print("性能对比")
    print("="*80)
    
    original_time = t1 - t0
    optimized_time = t3 - t2
    improvement = (original_time - optimized_time) / original_time * 100
    speedup = original_time / optimized_time
    
    print(f"\n原始版本: {original_time:.2f}s")
    print(f"优化版本: {optimized_time:.2f}s")
    print(f"性能提升: {improvement:.1f}%")
    print(f"加速比: {speedup:.2f}x")
    
    # 结果质量对比
    print("\n" + "="*80)
    print("结果质量对比")
    print("="*80)
    
    common_dates = set(daily_stats_orig['date']).intersection(set(daily_stats_opt['date']))
    
    overlap_ratios = []
    for date in sorted(common_dates):
        orig_assets = set(result_original.filter(pl.col('date') == date)['asset'])
        opt_assets = set(result_optimized.filter(pl.col('date') == date)['asset'])
        
        if len(orig_assets) > 0 and len(opt_assets) > 0:
            intersection = orig_assets.intersection(opt_assets)
            union = orig_assets.union(opt_assets)
            jaccard = len(intersection) / len(union) if len(union) > 0 else 0
            overlap_ratios.append(jaccard)
    
    if overlap_ratios:
        avg_overlap = sum(overlap_ratios) / len(overlap_ratios)
        min_overlap = min(overlap_ratios)
        max_overlap = max(overlap_ratios)
        
        print(f"\n选股重叠度 (Jaccard):")
        print(f"  平均: {avg_overlap*100:.1f}%")
        print(f"  最小: {min_overlap*100:.1f}%")
        print(f"  最大: {max_overlap*100:.1f}%")
    
    print("\n" + "="*80)
    print("✅ 统一接口测试完成！")
    print("="*80)


if __name__ == '__main__':
    test_unified_mfe_interface()
