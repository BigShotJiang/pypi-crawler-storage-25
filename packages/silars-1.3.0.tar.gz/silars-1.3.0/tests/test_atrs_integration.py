# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/04/09
# Description: 验证 ATRS 回测引擎替换后的功能

import polars as pl
from silars.alphalens import bt, BacktestEngine


def test_atrs_backtest():
    """测试 atrs 回测引擎的基本功能"""
    print("=" * 80)
    print("测试 ATRS Rust 回测引擎")
    print("=" * 80)
    
    # 读取测试数据
    data = pl.read_csv("data/target_weight.csv")
    print(f"\n✓ 加载数据: {data.shape}")
    print(f"  列名: {data.columns}")
    print(f"  日期范围: {data['date'].min()} -> {data['date'].max()}")
    
    # 测试 1: BacktestEngine 类
    print("\n" + "=" * 80)
    print("测试 1: BacktestEngine 类")
    print("=" * 80)
    engine = BacktestEngine(
        data=data,
        period='1d',
        buy_fee=5e-4,
        sell_fee=10e-4,
        mode='fixed'
    )
    engine.run()
    print(f"✓ 回测完成")
    print(f"  pos 形状: {engine.pos.shape}")
    print(f"  ret 形状: {engine.ret.shape}")
    print(f"  累计收益: {(1 + engine.ret['long']).product() - 1:.4%}")
    
    # 测试 2: bt 便捷函数
    print("\n" + "=" * 80)
    print("测试 2: bt() 便捷函数")
    print("=" * 80)
    bt.set_params(period='1d', buy_fee=5e-4, sell_fee=10e-4)
    be = bt.transform(data)
    print(f"✓ 回测完成")
    print(f"  pos 形状: {be.pos.shape}")
    print(f"  ret 形状: {be.ret.shape}")
    print(f"  累计收益: {(1 + be.ret['long']).product() - 1:.4%}")
    
    # 测试 3: rolling 模式
    print("\n" + "=" * 80)
    print("测试 3: Rolling 换仓模式 (5日)")
    print("=" * 80)
    bt.set_params(period='5d', buy_fee=5e-4, sell_fee=10e-4, mode='rolling')
    be_rolling = bt.transform(data)
    print(f"✓ 回测完成")
    print(f"  pos 形状: {be_rolling.pos.shape}")
    print(f"  ret 形状: {be_rolling.ret.shape}")
    print(f"  累计收益: {(1 + be_rolling.ret['long']).product() - 1:.4%}")
    
    print("\n" + "=" * 80)
    print("✅ 所有测试通过！ATRS Rust 回测引擎运行正常")
    print("=" * 80)


if __name__ == '__main__':
    test_atrs_backtest()
