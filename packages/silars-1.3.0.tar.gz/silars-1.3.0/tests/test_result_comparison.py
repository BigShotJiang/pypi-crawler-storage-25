# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/04/10
# Description: 对比原始版本和优化版本的MFE结果一致性

import polars as pl
import numpy as np
import sys
sys.path.insert(0, '/Users/zhangyundi/ypkg/silars')

from silars.alphalens.weight_fns import MFE as MFE_Original
from test_mfe_optimized import mfe_optimized


def compare_results():
    """对比原始版本和优化版本的结果"""
    print("="*80)
    print("MFE 结果一致性对比测试")
    print("="*80)
    
    # 加载数据
    print("\n加载数据...")
    df = pl.read_csv('data/mfe_prepare_data.csv')
    
    params = {
        'weight_bias': -1.0,
        'weight_limit': 0.005,
        'tc_rate': 20e-4,
        'indust_bias': 0.02,
        'style_bias': {'SizeBarra': 0.2, 'NLSizeBarra': 0.5},
        'to_limit': -1.0,
        'components_ratio': -1.0,
    }
    
    dates = df['date'].unique().sort()
    print(f"测试日期数: {len(dates)}")
    print(f"\n约束条件:")
    for k, v in params.items():
        print(f"  {k}: {v}")
    
    # ===== 运行原始版本 =====
    print("\n" + "-"*80)
    print("运行原始版本 (ECOS)...")
    print("-"*80)
    
    MFE_Original.set_params(**params)
    result_original = MFE_Original.transform(df)
    
    print(f"✓ 原始版本完成")
    print(f"  结果形状: {result_original.shape}")
    
    # ===== 运行优化版本 =====
    print("\n" + "-"*80)
    print("运行优化版本 (Clarabel)...")
    print("-"*80)
    
    results_optimized = []
    prev_weights = None
    
    for i, date in enumerate(dates):
        day_df = df.filter(pl.col('date') == date)
        
        # 准备 check_nan_cols
        check_nan_cols = ['date', 'time', 'asset', 'score', 'bm_w']
        if params['style_bias']:
            check_nan_cols.extend(params['style_bias'].keys())
        if params['indust_bias'] > 0:
            check_nan_cols.append('group')
        check_nan_cols.append('prev_weight')
        
        # 添加prev_weight
        if prev_weights is not None:
            day_df = day_df.join(
                prev_weights.drop('date').rename({'target_weight': 'prev_weight'}),
                on='asset',
                how='left'
            ).with_columns(pl.col('prev_weight').fill_null(0.0))
        
        result = mfe_optimized(
            day_df,
            **params,
            index=['date', 'time', 'asset'],
            check_nan_cols=check_nan_cols,
        )
        
        if result is not None and len(result) > 0:
            results_optimized.append(result.with_columns(date=pl.lit(date)))
            prev_weights = result
        
        if (i + 1) % 5 == 0 or i == 0:
            print(f"[{i+1}/{len(dates)}] {date}: {len(result) if result is not None else 0} 只持仓")
    
    result_optimized = pl.concat(results_optimized) if results_optimized else pl.DataFrame()
    print(f"\n✓ 优化版本完成")
    print(f"  结果形状: {result_optimized.shape}")
    
    # ===== 对比分析 =====
    print("\n" + "="*80)
    print("结果对比分析")
    print("="*80)
    
    # 1. 基本统计对比
    print("\n📊 基本统计对比:")
    
    orig_stats = result_original.group_by('date').agg([
        pl.len().alias('n_positions'),
        pl.col('target_weight').sum().alias('total_weight'),
        pl.col('target_weight').mean().alias('avg_weight'),
    ]).sort('date')
    
    opt_stats = result_optimized.group_by('date').agg([
        pl.len().alias('n_positions'),
        pl.col('target_weight').sum().alias('total_weight'),
        pl.col('target_weight').mean().alias('avg_weight'),
    ]).sort('date')
    
    print(f"\n{'指标':<20} {'原始版本':<15} {'优化版本':<15} {'差异':<10}")
    print("-"*60)
    
    # 平均持仓数
    orig_avg_pos = orig_stats['n_positions'].mean()
    opt_avg_pos = opt_stats['n_positions'].mean()
    pos_diff = opt_avg_pos - orig_avg_pos
    print(f"{'平均持仓数':<18} {orig_avg_pos:<15.1f} {opt_avg_pos:<15.1f} {pos_diff:+.1f}")
    
    # 权重总和
    orig_total_w = orig_stats['total_weight'].mean()
    opt_total_w = opt_stats['total_weight'].mean()
    w_diff = opt_total_w - orig_total_w
    print(f"{'平均权重总和':<18} {orig_total_w:<15.4f} {opt_total_w:<15.4f} {w_diff:+.4f}")
    
    # 2. 逐日对比
    print("\n📈 前10天详细对比:")
    print(f"\n{'日期':<12} {'原始持仓':<10} {'优化持仓':<10} {'差异':<8} {'原始权重':<10} {'优化权重':<10}")
    print("-"*70)
    
    max_compare_days = min(10, len(orig_stats))
    position_diffs = []
    weight_diffs = []
    
    for i in range(max_compare_days):
        orig_row = orig_stats[i]
        opt_row = opt_stats[i]
        
        date = str(orig_row['date'][0])
        orig_pos = int(orig_row['n_positions'][0])
        opt_pos = int(opt_row['n_positions'][0])
        pos_diff = opt_pos - orig_pos
        
        orig_w = float(orig_row['total_weight'][0])
        opt_w = float(opt_row['total_weight'][0])
        w_diff = opt_w - orig_w
        
        position_diffs.append(abs(pos_diff))
        weight_diffs.append(abs(w_diff))
        
        marker = "⚠️" if abs(pos_diff) > 5 else ""
        print(f"{str(date):<12} {orig_pos:<10} {opt_pos:<10} {pos_diff:+<8} {orig_w:<10.4f} {opt_w:<10.4f} {marker}")
    
    # 3. 选股重叠度分析
    print("\n🎯 选股重叠度分析:")
    
    overlap_ratios = []
    common_dates = set(orig_stats['date']).intersection(set(opt_stats['date']))
    
    for date in sorted(common_dates)[:10]:  # 只分析前10天
        orig_assets = set(result_original.filter(pl.col('date') == date)['asset'])
        opt_assets = set(result_optimized.filter(pl.col('date') == date)['asset'])
        
        if len(orig_assets) > 0 and len(opt_assets) > 0:
            intersection = orig_assets.intersection(opt_assets)
            union = orig_assets.union(opt_assets)
            jaccard = len(intersection) / len(union) if len(union) > 0 else 0
            overlap_ratios.append(jaccard)
    
    if overlap_ratios:
        avg_overlap = np.mean(overlap_ratios)
        min_overlap = np.min(overlap_ratios)
        max_overlap = np.max(overlap_ratios)
        
        print(f"  平均Jaccard相似系数: {avg_overlap:.4f} ({avg_overlap*100:.1f}%)")
        print(f"  最小重叠度: {min_overlap:.4f} ({min_overlap*100:.1f}%)")
        print(f"  最大重叠度: {max_overlap:.4f} ({max_overlap*100:.1f}%)")
        
        if avg_overlap >= 0.95:
            print(f"\n  ✅ 选股高度一致! (>95%)")
        elif avg_overlap >= 0.90:
            print(f"\n  ✅ 选股非常接近! (>90%)")
        elif avg_overlap >= 0.80:
            print(f"\n  ⚠️  选股有一定差异 (>80%)")
        else:
            print(f"\n  ❌ 选股差异较大! (<80%)")
    
    # 4. 个股权重差异分析（重点）
    print("\n💰 个股权重差异分析:")
    
    weight_diffs_list = []
    max_weight_diffs = []
    relative_diffs = []
    
    for date in sorted(common_dates)[:10]:
        orig_day = result_original.filter(pl.col('date') == date).select(['asset', 'target_weight']).rename({'target_weight': 'w_orig'})
        opt_day = result_optimized.filter(pl.col('date') == date).select(['asset', 'target_weight']).rename({'target_weight': 'w_opt'})
        
        merged = orig_day.join(opt_day, on='asset', how='inner')
        
        if len(merged) > 0:
            # 绝对差异
            abs_diffs = (merged['w_opt'] - merged['w_orig']).abs()
            avg_abs_diff = abs_diffs.mean()
            max_abs_diff = abs_diffs.max()
            
            # 相对差异（相对于原始权重）
            rel_diffs = ((merged['w_opt'] - merged['w_orig']).abs() / (merged['w_orig'] + 1e-10))
            avg_rel_diff = rel_diffs.mean()
            max_rel_diff = rel_diffs.max()
            
            weight_diffs_list.append(avg_abs_diff)
            max_weight_diffs.append(max_abs_diff)
            relative_diffs.append(avg_rel_diff)
            
            if date == sorted(common_dates)[0]:  # 只打印第一天的详情
                print(f"\n  第一天 ({date}) 个股权重差异详情:")
                print(f"  {'指标':<25} {'数值':<15}")
                print(f"  {'-'*40}")
                print(f"  {'共同持仓数':<23} {len(merged):<15}")
                print(f"  {'平均绝对差异':<22} {avg_abs_diff:<15.6f}")
                print(f"  {'最大绝对差异':<22} {max_abs_diff:<15.6f}")
                print(f"  {'平均相对差异':<22} {avg_rel_diff:<15.4%}")
                print(f"  {'最大相对差异':<22} {max_rel_diff:<15.4%}")
                
                # 找出差异最大的前5只股票
                merged_with_diff = merged.with_columns(
                    abs_diff=(pl.col('w_opt') - pl.col('w_orig')).abs(),
                    rel_diff=(pl.col('w_opt') - pl.col('w_orig')).abs() / (pl.col('w_orig') + 1e-10)
                ).sort('abs_diff', descending=True)
                
                print(f"\n  差异最大的前5只股票:")
                print(f"  {'股票':<15} {'原始权重':<12} {'优化权重':<12} {'绝对差异':<12} {'相对差异':<12}")
                print(f"  {'-'*65}")
                for row in merged_with_diff.head(5).iter_rows(named=True):
                    print(f"  {row['asset']:<15} {row['w_orig']:<12.6f} {row['w_opt']:<12.6f} {row['abs_diff']:<12.6f} {row['rel_diff']:<12.2%}")
    
    if weight_diffs_list:
        avg_weight_diff = np.mean(weight_diffs_list)
        avg_max_diff = np.mean(max_weight_diffs)
        avg_rel_diff_val = np.mean(relative_diffs)
        
        print(f"\n  跨天统计 (前10天平均):")
        print(f"  {'平均绝对差异':<23} {avg_weight_diff:<15.6f}")
        print(f"  {'平均最大差异':<22} {avg_max_diff:<15.6f}")
        print(f"  {'平均相对差异':<22} {avg_rel_diff_val:<15.4%}")
        
        if avg_weight_diff < 1e-5:
            print(f"\n  ✅✅✅ 权重差异极小! (<0.001%)")
        elif avg_weight_diff < 1e-4:
            print(f"\n  ✅✅ 权重差异很小! (<0.01%)")
        elif avg_weight_diff < 1e-3:
            print(f"\n  ✅ 权重差异可接受! (<0.1%)")
        else:
            print(f"\n  ⚠️  权重差异较大!")
    
    # 5. 总结
    print("\n" + "="*80)
    print("一致性评估总结")
    print("="*80)
    
    avg_pos_diff = np.mean(position_diffs) if position_diffs else 0
    avg_w_diff = np.mean(weight_diffs) if weight_diffs else 0
    avg_overlap_val = np.mean(overlap_ratios) if overlap_ratios else 0
    avg_weight_diff_val = np.mean(weight_diffs_list) if weight_diffs_list else 0
    avg_rel_diff_final = np.mean(relative_diffs) if relative_diffs else 0
    
    print(f"\n关键指标:")
    print(f"  ✓ 平均持仓差异: {avg_pos_diff:.1f} 只")
    print(f"  ✓ 选股重叠度: {avg_overlap_val*100:.1f}%")
    print(f"  ✓ 个股权重平均绝对差异: {avg_weight_diff_val:.6f}")
    print(f"  ✓ 个股权重平均相对差异: {avg_rel_diff_final:.4%}")
    
    # 综合评估
    print(f"\n🎯 综合评估:")
    if avg_overlap_val >= 0.95 and avg_weight_diff_val < 1e-4 and avg_pos_diff <= 2:
        print(f"  ✅✅✅ 结果高度一致！优化版本可以安全替换原始版本")
    elif avg_overlap_val >= 0.90 and avg_weight_diff_val < 1e-3 and avg_pos_diff <= 5:
        print(f"  ✅✅ 结果非常接近！优化版本可以使用")
    elif avg_overlap_val >= 0.80 and avg_weight_diff_val < 1e-2:
        print(f"  ✅ 结果基本一致，但有细微差异")
    else:
        print(f"  ⚠️  结果存在显著差异，需要进一步检查")


if __name__ == '__main__':
    compare_results()
