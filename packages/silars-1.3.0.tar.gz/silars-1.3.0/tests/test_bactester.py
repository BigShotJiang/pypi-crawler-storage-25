# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/1/11 15:03
# Description:

from silars.alphalens import bt
from silars.alphalens import FactorStrategy
import polars as pl

def run():
    data = pl.read_csv("data/target_weight.csv")
    bt.set_params(limit=True, buy_fee=5e-4, sell_fee=10e-4)
    be = bt.transform(data)
    print(f"回测完成！")
    print(f"pos 形状: {be.pos.shape}")
    print(f"ret 形状: {be.ret.shape}")
    print(f"累计收益: {(1 + be.ret['long']).product() - 1:.4%}")


if __name__ == '__main__':
    run()