__version__ = "0.1.7"

def __getattr__(name):
    if name == "TurboQuantEngine":
        from .host import TurboQuantEngine
        return TurboQuantEngine
    if name == "tune_all":
        from .autotune import tune_all
        return tune_all
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = ["__version__", "TurboQuantEngine", "tune_all"]
