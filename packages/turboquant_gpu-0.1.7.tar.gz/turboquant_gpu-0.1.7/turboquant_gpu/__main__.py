"""Entry point for `python -m turboquant_gpu`."""
from .autotune import main
main()
