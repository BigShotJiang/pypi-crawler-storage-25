# turboquant kernel-level autotuner
#
# searches tile sizes, occupancy, latency hints, swizzle, and precision.
# prunes by SMEM/register budget, benchmarks with CUDA events, checks
# cosine similarity, stores winners in ~/.turboquant/dispatch_table.json.
#
# usage:  python -m turboquant_gpu.autotune --seq-len 8192 --bits 3

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from itertools import product
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F

from .codebook import LloydMaxCodebook
from .constants import DEFAULT_SEED, DEFAULT_TOTAL_BITS, HEAD_DIM


# ── configs ──────────────────────────────────────────────────────────────

@dataclass
class AttentionTuneConfig:
    block_q: int = 16
    block_kv: int = 64
    occupancy: int = 2
    latency_k: int = 2
    latency_v: int = 4
    use_swizzle: bool = True
    precision_mode: str = "fast"   # "fast" = exp2+FTZ+approx, "full" = standard

    def tag(self) -> str:
        sw = "T" if self.use_swizzle else "F"
        return (f"BQ={self.block_q} BKV={self.block_kv} occ={self.occupancy} "
                f"lK={self.latency_k} lV={self.latency_v} swiz={sw} "
                f"{self.precision_mode}")


@dataclass
class CompressTuneConfig:
    block_s: int = 64
    fused_kv: bool = True   # single-launch K+V, only valid for 3-bit

    def tag(self) -> str:
        return f"BS={self.block_s} {'fused' if self.fused_kv else 'split'}"


@dataclass
class TunedResult:
    config: dict
    median_us: float
    cos_sim: float
    tuned_on: str
    tuned_at: str


DEFAULT_ATTENTION_CONFIG = AttentionTuneConfig()
DEFAULT_COMPRESS_CONFIG = CompressTuneConfig()


# ── gpu detection ────────────────────────────────────────────────────────

@dataclass
class GPUProps:
    name: str
    sm_major: int
    sm_minor: int
    smem_per_sm: int          # bytes
    regs_per_sm: int          # 32-bit regs
    max_regs_per_thread: int

    @property
    def sm_tag(self) -> str:
        return f"sm_{self.sm_major * 10 + self.sm_minor}"

    @classmethod
    def detect(cls, device: int = 0) -> GPUProps:
        props = torch.cuda.get_device_properties(device)
        cap = torch.cuda.get_device_capability(device)

        # torch reports max_shared_memory_per_multiprocessor but it's
        # sometimes wrong for newer arches, so we keep a manual table
        smem_map = {
            (10, 0): 228 * 1024,   # B200 / B300
            (10, 5): 256 * 1024,   # B300 (if reported as sm_105)
            (9, 0):  228 * 1024,   # H100
            (8, 9):  100 * 1024,   # RTX 4090
            (8, 6):  100 * 1024,   # RTX 3090
            (8, 0):  164 * 1024,   # A100
        }
        smem = smem_map.get(cap)
        if smem is None:
            for attr in ("max_shared_memory_per_multiprocessor",
                         "max_shared_memory_per_block"):
                if hasattr(props, attr):
                    smem = getattr(props, attr)
                    break
            if smem is None:
                smem = 228 * 1024

        return cls(
            name=props.name,
            sm_major=cap[0],
            sm_minor=cap[1],
            smem_per_sm=smem,
            regs_per_sm=65536,
            max_regs_per_thread=255,
        )


# ── config enumeration ───────────────────────────────────────────────────

# knob ranges — these define the search grid
# total raw combos: 3*3*3*5*7*2*2 = 7,560 for attention
ATTENTION_GRID = {
    "block_q":        [16, 32, 64],
    "block_kv":       [32, 64, 128],
    "occupancy":      [1, 2, 3],
    "latency_k":      [0, 1, 2, 3, 4],
    "latency_v":      [0, 1, 2, 3, 4, 6, 8],
    "use_swizzle":    [True, False],
    "precision_mode": ["full", "fast"],
}

COMPRESS_GRID = {
    "block_s":  [32, 64, 128],
    "fused_kv": [True, False],
}


def enumerate_attention_configs() -> list[AttentionTuneConfig]:
    keys = list(ATTENTION_GRID.keys())
    combos = product(*(ATTENTION_GRID[k] for k in keys))
    return [AttentionTuneConfig(**dict(zip(keys, vals))) for vals in combos]


def enumerate_compress_configs(bits: int) -> list[CompressTuneConfig]:
    configs = []
    for bs in COMPRESS_GRID["block_s"]:
        for fused in COMPRESS_GRID["fused_kv"]:
            # fused K+V only works at 3-bit (shared codebook path)
            if fused and bits != 3:
                continue
            configs.append(CompressTuneConfig(block_s=bs, fused_kv=fused))
    return configs


# ── constraint pruning ───────────────────────────────────────────────────

def compute_attention_smem(cfg: AttentionTuneConfig, head_dim: int = HEAD_DIM) -> int:
    # SMEM per CTA, in bytes. accounts for TMA pipeline buffers.
    # each latency=N hint means (N+1) live buffers in SMEM simultaneously.
    q_bytes = cfg.block_q * head_dim * 2
    k_bufs  = (cfg.latency_k + 1) * cfg.block_kv * head_dim * 2
    v_bufs  = (cfg.latency_v + 1) * cfg.block_kv * head_dim * 2
    signs   = cfg.block_kv * head_dim * 1    # int8
    pi      = head_dim * head_dim * 2        # rotation matrix, fp16
    norms   = cfg.block_kv * 2               # fp16 per-row norms
    return q_bytes + k_bufs + v_bufs + signs + pi + norms


def estimate_attention_regs(cfg: AttentionTuneConfig, head_dim: int = HEAD_DIM) -> int:
    # rough register estimate per thread (128 threads per warpgroup).
    # main consumer is the fp32 accumulator tile.
    threads = 128
    acc_regs = (cfg.block_q * head_dim * 4) // (threads * 4)
    overhead = 40   # control flow, addresses, temporaries
    return acc_regs + overhead


def prune_attention_configs(
    configs: list[AttentionTuneConfig],
    gpu: GPUProps,
    head_dim: int = HEAD_DIM,
) -> list[AttentionTuneConfig]:
    valid = []
    for cfg in configs:
        # SMEM check: budget = total SMEM / occupancy
        smem_budget = gpu.smem_per_sm // cfg.occupancy
        if compute_attention_smem(cfg, head_dim) > smem_budget:
            continue

        # register check
        regs_per_thread = estimate_attention_regs(cfg, head_dim)
        if regs_per_thread > gpu.max_regs_per_thread:
            continue
        regs_per_cta = regs_per_thread * 128
        reg_budget = gpu.regs_per_sm // cfg.occupancy
        if regs_per_cta > reg_budget:
            continue

        # latency hints only make sense with swizzle enabled
        if not cfg.use_swizzle and (cfg.latency_k > 0 or cfg.latency_v > 0):
            continue

        valid.append(cfg)
    return valid


def compute_compress_smem(cfg: CompressTuneConfig, head_dim: int = HEAD_DIM) -> int:
    pi_bytes = head_dim * head_dim * 2
    tile_bytes = cfg.block_s * head_dim * 2
    factor = 2 if cfg.fused_kv else 1
    return pi_bytes + tile_bytes * factor + cfg.block_s * 2 * factor


def prune_compress_configs(
    configs: list[CompressTuneConfig],
    gpu: GPUProps,
    head_dim: int = HEAD_DIM,
) -> list[CompressTuneConfig]:
    # compress kernels don't set occupancy, so full SMEM budget
    return [c for c in configs
            if compute_compress_smem(c, head_dim) <= gpu.smem_per_sm]


# ── kernel factory (template-based) ─────────────────────────────────────
#
# we generate kernel source as a string with tile sizes / occupancy / latency
# baked in, then exec() it. this gives cuTile's JIT a clean function to
# compile -- closures don't play well with the JIT.

_FUSED_ATTN_TEMPLATE = '''\
import math
try:
    import cuda.tile as ct
    from cuda.tile import RoundingMode as RMd
    _HAS_APPROX = hasattr(RMd, "APPROX")
except ImportError:
    import cutile as ct
    RMd = None
    _HAS_APPROX = False

INV_LOG_2 = 1.0 / math.log(2)
ConstBool = ct.Constant[bool]

@ct.kernel(occupancy={occupancy})
def turboquant_fused_attention(
    Q, K_mse, Signs, R_norms, Q_proj, V, Output,
    scale: float,
    correction_scale: float,
    seq_k: int,
    USE_SWIZZLE: ConstBool,
):
    zero_pad = ct.PaddingMode.ZERO

    if USE_SWIZZLE:
        half = ct.cdiv(ct.num_blocks(0), 2)
        q_block = ct.bid(0) // 2 + (ct.bid(0) % 2) * half
    else:
        q_block = ct.bid(0)

    q_tile  = ct.load(Q,      index=(q_block, 0), shape=({block_q}, {head_dim}),
                      padding_mode=zero_pad)
    qp_tile = ct.load(Q_proj, index=(q_block, 0), shape=({block_q}, {head_dim}),
                      padding_mode=zero_pad)

    m_i = ct.full(({block_q},), -1e30, dtype=ct.float32)
    l_i = ct.zeros(({block_q},), dtype=ct.float32)
    acc = ct.zeros(({block_q}, {head_dim}), dtype=ct.float32)

    scale_log2 = scale * INV_LOG_2
    num_kv_blocks = ct.num_tiles(K_mse, axis=0, shape=({block_kv}, {head_dim}))

    for kv_block in range(num_kv_blocks):
        {k_load}
        {v_load}

        s_tile = ct.load(Signs, index=(kv_block, 0),
                         shape=({block_kv}, {head_dim}), padding_mode=zero_pad)
        rn     = ct.load(R_norms, index=(kv_block,), shape=({block_kv},),
                         padding_mode=zero_pad)

        term1 = ct.mma(q_tile, ct.transpose(k_tile),
                       ct.zeros(({block_q}, {block_kv}), dtype=ct.float32))

        s_float = ct.astype(s_tile, ct.float16)
        qjl_ip  = ct.mma(qp_tile, ct.transpose(s_float),
                         ct.zeros(({block_q}, {block_kv}), dtype=ct.float32))
        rn_f32  = ct.astype(rn, ct.float32)
        term2   = correction_scale * qjl_ip * ct.expand_dims(rn_f32, axis=0)

        raw_scores = term1 + term2

        {softmax_block}

        l_i = alpha * l_i + ct.sum(p, axis=1)

        p_fp16 = ct.astype(p, ct.float16)
        acc = ct.expand_dims(alpha, axis=1) * acc + ct.mma(
            p_fp16, v_tile, ct.zeros(({block_q}, {head_dim}), dtype=ct.float32))

        m_i = m_new

    {final_div}

    ct.store(Output, index=(q_block, 0), tile=out)
'''

_COMPRESS_3BIT_TEMPLATE = '''\
try:
    import cuda.tile as ct
except ImportError:
    import cutile as ct

@ct.kernel
def turboquant_compress_values_3bit(
    V, Pi_T, Indices, Norms,
    c0: float, c1: float, c2: float, c3: float,
    c4: float, c5: float, c6: float, c7: float,
    b1: float, b2: float, b3: float, b4: float,
    b5: float, b6: float, b7: float,
    seq_v: int,
):
    block_id = ct.bid(0)
    zero_pad = ct.PaddingMode.ZERO

    v_tile = ct.load(V, index=(block_id, 0), shape=({block_s}, {head_dim}),
                     padding_mode=zero_pad)
    pi_t = ct.load(Pi_T, index=(0, 0), shape=({head_dim}, {head_dim}))

    v_f32 = ct.astype(v_tile, ct.float32)
    norms = ct.sqrt(ct.sum(v_f32 * v_f32, axis=1))
    safe_norms = ct.where(norms > 1e-8, norms, 1e-8)
    v_normed = v_f32 / ct.expand_dims(safe_norms, axis=1)

    y = ct.mma(ct.astype(v_normed, ct.float16), pi_t,
               ct.zeros(({block_s}, {head_dim}), dtype=ct.float32))

    idx = ct.zeros(({block_s}, {head_dim}), dtype=ct.float32)
    idx = ct.where(y > b1, 1.0, idx)
    idx = ct.where(y > b2, 2.0, idx)
    idx = ct.where(y > b3, 3.0, idx)
    idx = ct.where(y > b4, 4.0, idx)
    idx = ct.where(y > b5, 5.0, idx)
    idx = ct.where(y > b6, 6.0, idx)
    idx = ct.where(y > b7, 7.0, idx)

    ct.store(Indices, index=(block_id, 0), tile=ct.astype(idx, ct.uint8))
    ct.store(Norms,   index=(block_id,),   tile=ct.astype(norms, ct.float16))
'''

_DECOMPRESS_3BIT_TEMPLATE = '''\
try:
    import cuda.tile as ct
except ImportError:
    import cutile as ct

@ct.kernel
def turboquant_decompress_3bit(
    Indices, Norms, Pi, Output,
    c0: float, c1: float, c2: float, c3: float,
    c4: float, c5: float, c6: float, c7: float,
    seq_k: int,
):
    block_id = ct.bid(0)
    zero_pad = ct.PaddingMode.ZERO

    idx_tile  = ct.load(Indices, index=(block_id, 0), shape=({block_s}, {head_dim}),
                        padding_mode=zero_pad)
    norm_tile = ct.load(Norms, index=(block_id,), shape=({block_s},),
                        padding_mode=zero_pad)
    pi = ct.load(Pi, index=(0, 0), shape=({head_dim}, {head_dim}))

    idx_f32 = ct.astype(idx_tile, ct.float32)
    y_hat = ct.full(({block_s}, {head_dim}), c0, dtype=ct.float32)
    y_hat = ct.where(idx_f32 > 0.5, c1, y_hat)
    y_hat = ct.where(idx_f32 > 1.5, c2, y_hat)
    y_hat = ct.where(idx_f32 > 2.5, c3, y_hat)
    y_hat = ct.where(idx_f32 > 3.5, c4, y_hat)
    y_hat = ct.where(idx_f32 > 4.5, c5, y_hat)
    y_hat = ct.where(idx_f32 > 5.5, c6, y_hat)
    y_hat = ct.where(idx_f32 > 6.5, c7, y_hat)

    x_hat  = ct.mma(ct.astype(y_hat, ct.float16), pi,
                    ct.zeros(({block_s}, {head_dim}), dtype=ct.float32))
    result = x_hat * ct.expand_dims(ct.astype(norm_tile, ct.float32), axis=1)

    ct.store(Output, index=(block_id, 0), tile=ct.astype(result, ct.float16))
'''

_KVFUSED_ATTN_TEMPLATE = '''\
import math
try:
    import cuda.tile as ct
    from cuda.tile import RoundingMode as RMd
    _HAS_APPROX = hasattr(RMd, "APPROX")
except ImportError:
    import cutile as ct
    RMd = None
    _HAS_APPROX = False

INV_LOG_2 = 1.0 / math.log(2)
ConstBool = ct.Constant[bool]

@ct.kernel(occupancy={occupancy})
def turboquant_kvfused_attention(
    Q, K_Indices, K_Norms, Signs, R_norms, Q_proj,
    V_Indices, V_Norms, Pi, Output,
    scale: float,
    correction_scale: float,
    seq_k: int,
    kc0: float, kc1: float, kc2: float, kc3: float,
    vc0: float, vc1: float, vc2: float, vc3: float,
    vc4: float, vc5: float, vc6: float, vc7: float,
    USE_SWIZZLE: ConstBool,
):
    zero_pad = ct.PaddingMode.ZERO

    if USE_SWIZZLE:
        half = ct.cdiv(ct.num_blocks(0), 2)
        q_block = ct.bid(0) // 2 + (ct.bid(0) % 2) * half
    else:
        q_block = ct.bid(0)

    q_tile  = ct.load(Q,      index=(q_block, 0), shape=({block_q}, {head_dim}),
                      padding_mode=zero_pad)
    qp_tile = ct.load(Q_proj, index=(q_block, 0), shape=({block_q}, {head_dim}),
                      padding_mode=zero_pad)
    pi_tile = ct.load(Pi, index=(0, 0), shape=({head_dim}, {head_dim}))

    m_i = ct.full(({block_q},), -1e30, dtype=ct.float32)
    l_i = ct.zeros(({block_q},), dtype=ct.float32)
    acc = ct.zeros(({block_q}, {head_dim}), dtype=ct.float32)

    scale_log2 = scale * INV_LOG_2
    num_kv_blocks = ct.num_tiles(K_Indices, axis=0, shape=({block_kv}, {head_dim}))

    for kv_block in range(num_kv_blocks):
        {k_load}
        {v_load}

        k_nrm = ct.load(K_Norms, index=(kv_block,),
                         shape=({block_kv},), padding_mode=zero_pad)
        v_nrm = ct.load(V_Norms, index=(kv_block,),
                         shape=({block_kv},), padding_mode=zero_pad)

        ki_f32 = ct.astype(k_idx, ct.float32)
        k_hat = ct.full(({block_kv}, {head_dim}), kc0, dtype=ct.float32)
        k_hat = ct.where(ki_f32 > 0.5, kc1, k_hat)
        k_hat = ct.where(ki_f32 > 1.5, kc2, k_hat)
        k_hat = ct.where(ki_f32 > 2.5, kc3, k_hat)

        k_recon = ct.mma(ct.astype(k_hat, ct.float16), pi_tile,
                         ct.zeros(({block_kv}, {head_dim}), dtype=ct.float32))
        k_nrm_f32 = ct.astype(k_nrm, ct.float32)
        k_tile = ct.astype(
            k_recon * ct.expand_dims(k_nrm_f32, axis=1), ct.float16)

        vi_f32 = ct.astype(v_idx, ct.float32)
        v_hat = ct.full(({block_kv}, {head_dim}), vc0, dtype=ct.float32)
        v_hat = ct.where(vi_f32 > 0.5, vc1, v_hat)
        v_hat = ct.where(vi_f32 > 1.5, vc2, v_hat)
        v_hat = ct.where(vi_f32 > 2.5, vc3, v_hat)
        v_hat = ct.where(vi_f32 > 3.5, vc4, v_hat)
        v_hat = ct.where(vi_f32 > 4.5, vc5, v_hat)
        v_hat = ct.where(vi_f32 > 5.5, vc6, v_hat)
        v_hat = ct.where(vi_f32 > 6.5, vc7, v_hat)

        v_recon = ct.mma(ct.astype(v_hat, ct.float16), pi_tile,
                         ct.zeros(({block_kv}, {head_dim}), dtype=ct.float32))
        v_nrm_f32 = ct.astype(v_nrm, ct.float32)
        v_tile = ct.astype(
            v_recon * ct.expand_dims(v_nrm_f32, axis=1), ct.float16)

        s_tile = ct.load(Signs, index=(kv_block, 0),
                         shape=({block_kv}, {head_dim}), padding_mode=zero_pad)
        rn     = ct.load(R_norms, index=(kv_block,), shape=({block_kv},),
                         padding_mode=zero_pad)

        term1 = ct.mma(q_tile, ct.transpose(k_tile),
                       ct.zeros(({block_q}, {block_kv}), dtype=ct.float32))

        s_float = ct.astype(s_tile, ct.float16)
        qjl_ip  = ct.mma(qp_tile, ct.transpose(s_float),
                         ct.zeros(({block_q}, {block_kv}), dtype=ct.float32))
        rn_f32  = ct.astype(rn, ct.float32)
        term2   = correction_scale * qjl_ip * ct.expand_dims(rn_f32, axis=0)

        raw_scores = term1 + term2

        {softmax_block}

        l_i = alpha * l_i + ct.sum(p, axis=1)

        p_fp16 = ct.astype(p, ct.float16)
        acc = ct.expand_dims(alpha, axis=1) * acc + ct.mma(
            p_fp16, v_tile, ct.zeros(({block_q}, {head_dim}), dtype=ct.float32))

        m_i = m_new

    {final_div}

    ct.store(Output, index=(q_block, 0), tile=out)
'''


def _build_k_load(cfg):
    bkv, hd = cfg.block_kv, HEAD_DIM
    if cfg.use_swizzle and cfg.latency_k > 0:
        return (f"k_tile = ct.load(K_mse, index=(kv_block, 0), "
                f"shape=({bkv}, {hd}), padding_mode=zero_pad, "
                f"latency={cfg.latency_k})")
    return (f"k_tile = ct.load(K_mse, index=(kv_block, 0), "
            f"shape=({bkv}, {hd}), padding_mode=zero_pad)")


def _build_v_load(cfg):
    bkv, hd = cfg.block_kv, HEAD_DIM
    if cfg.use_swizzle and cfg.latency_v > 0:
        return (f"v_tile = ct.load(V, index=(kv_block, 0), "
                f"shape=({bkv}, {hd}), padding_mode=zero_pad, "
                f"latency={cfg.latency_v})")
    return (f"v_tile = ct.load(V, index=(kv_block, 0), "
            f"shape=({bkv}, {hd}), padding_mode=zero_pad)")


def _build_kvfused_k_load(cfg):
    bkv, hd = cfg.block_kv, HEAD_DIM
    if cfg.use_swizzle and cfg.latency_k > 0:
        return (f"k_idx = ct.load(K_Indices, index=(kv_block, 0), "
                f"shape=({bkv}, {hd}), padding_mode=zero_pad, "
                f"latency={cfg.latency_k})")
    return (f"k_idx = ct.load(K_Indices, index=(kv_block, 0), "
            f"shape=({bkv}, {hd}), padding_mode=zero_pad)")


def _build_kvfused_v_load(cfg):
    bkv, hd = cfg.block_kv, HEAD_DIM
    if cfg.use_swizzle and cfg.latency_v > 0:
        return (f"v_idx = ct.load(V_Indices, index=(kv_block, 0), "
                f"shape=({bkv}, {hd}), padding_mode=zero_pad, "
                f"latency={cfg.latency_v})")
    return (f"v_idx = ct.load(V_Indices, index=(kv_block, 0), "
            f"shape=({bkv}, {hd}), padding_mode=zero_pad)")


def _build_softmax(cfg):
    if cfg.precision_mode == "fast":
        # exp2 + FTZ: maps to a single SFU instruction on blackwell
        return (
            f"m_new = ct.maximum(m_i, ct.max(raw_scores, axis=1) * scale_log2)\n"
            f"        alpha = ct.exp2(m_i - m_new, flush_to_zero=True)\n"
            f"        p     = ct.exp2(raw_scores * scale_log2 "
            f"- ct.expand_dims(m_new, axis=1), flush_to_zero=True)"
        )
    return (
        f"scores = raw_scores * scale\n"
        f"        m_new  = ct.maximum(m_i, ct.max(scores, axis=1))\n"
        f"        alpha  = ct.exp(m_i - m_new)\n"
        f"        p      = ct.exp(scores - ct.expand_dims(m_new, axis=1))"
    )


def _build_final_div(cfg):
    if cfg.precision_mode == "fast":
        return (
            "if _HAS_APPROX:\n"
            "        out = ct.truediv(acc, ct.expand_dims(l_i, axis=1),\n"
            "                         flush_to_zero=True, rounding_mode=RMd.APPROX)\n"
            "    else:\n"
            "        out = acc / ct.expand_dims(l_i, axis=1)"
        )
    return "out = acc / ct.expand_dims(l_i, axis=1)"


import importlib.util
import tempfile

_KERNEL_TMP_DIR = None

def _get_kernel_tmp_dir():
    global _KERNEL_TMP_DIR
    if _KERNEL_TMP_DIR is None:
        _KERNEL_TMP_DIR = tempfile.mkdtemp(prefix="tq_kernels_")
    return _KERNEL_TMP_DIR

def _exec_from_file(source, name, func_name):
    # cuTile JIT uses inspect.getsourcelines() which requires a real file
    tmp_dir = _get_kernel_tmp_dir()
    fpath = os.path.join(tmp_dir, f"{name}.py")
    with open(fpath, "w") as f:
        f.write(source)
    spec = importlib.util.spec_from_file_location(name, fpath)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return getattr(mod, func_name)


def make_attention_kernel(cfg: AttentionTuneConfig, head_dim: int = HEAD_DIM):
    source = _FUSED_ATTN_TEMPLATE.format(
        occupancy=cfg.occupancy,
        block_q=cfg.block_q,
        block_kv=cfg.block_kv,
        head_dim=head_dim,
        k_load=_build_k_load(cfg),
        v_load=_build_v_load(cfg),
        softmax_block=_build_softmax(cfg),
        final_div=_build_final_div(cfg),
    )
    tag = cfg.tag().replace(" ", "_").replace("=", "")
    return _exec_from_file(source, f"attn_{tag}", "turboquant_fused_attention")


def make_compress_kernel(cfg: CompressTuneConfig, head_dim: int = HEAD_DIM):
    source = _COMPRESS_3BIT_TEMPLATE.format(block_s=cfg.block_s, head_dim=head_dim)
    tag = cfg.tag().replace(" ", "_").replace("=", "")
    return _exec_from_file(source, f"compress_{tag}", "turboquant_compress_values_3bit")


def make_decompress_kernel(cfg: CompressTuneConfig, head_dim: int = HEAD_DIM):
    source = _DECOMPRESS_3BIT_TEMPLATE.format(block_s=cfg.block_s, head_dim=head_dim)
    tag = cfg.tag().replace(" ", "_").replace("=", "")
    return _exec_from_file(source, f"decompress_{tag}", "turboquant_decompress_3bit")


# ── kvfused SMEM + factory ───────────────────────────────────────────────

def compute_kvfused_smem(cfg: AttentionTuneConfig, head_dim: int = HEAD_DIM) -> int:
    # both K and V arrive as uint8 indices (1 byte/elem instead of 2)
    q_bytes = cfg.block_q * head_dim * 2       # Q resident, fp16
    qp_bytes = cfg.block_q * head_dim * 2      # Q_proj resident, fp16
    pi_bytes = head_dim * head_dim * 2          # Pi resident, fp16

    # pipeline buffers for K_Indices and V_Indices (uint8)
    k_bufs = (cfg.latency_k + 1) * cfg.block_kv * head_dim * 1
    v_bufs = (cfg.latency_v + 1) * cfg.block_kv * head_dim * 1

    # per-iteration: K_Norms, V_Norms, Signs, R_norms
    k_norms = cfg.block_kv * 2    # fp16
    v_norms = cfg.block_kv * 2    # fp16
    signs   = cfg.block_kv * head_dim * 1  # int8
    r_norms = cfg.block_kv * 2    # fp16

    return q_bytes + qp_bytes + pi_bytes + k_bufs + v_bufs + k_norms + v_norms + signs + r_norms


def prune_kvfused_configs(
    configs: list[AttentionTuneConfig],
    gpu: GPUProps,
    head_dim: int = HEAD_DIM,
) -> list[AttentionTuneConfig]:
    valid = []
    for cfg in configs:
        smem_budget = gpu.smem_per_sm // cfg.occupancy
        if compute_kvfused_smem(cfg, head_dim) > smem_budget:
            continue

        regs_per_thread = estimate_attention_regs(cfg, head_dim)
        if regs_per_thread > gpu.max_regs_per_thread:
            continue
        regs_per_cta = regs_per_thread * 128
        reg_budget = gpu.regs_per_sm // cfg.occupancy
        if regs_per_cta > reg_budget:
            continue

        if not cfg.use_swizzle and (cfg.latency_k > 0 or cfg.latency_v > 0):
            continue

        valid.append(cfg)
    return valid


def make_kvfused_attention_kernel(cfg: AttentionTuneConfig, head_dim: int = HEAD_DIM):
    source = _KVFUSED_ATTN_TEMPLATE.format(
        occupancy=cfg.occupancy,
        block_q=cfg.block_q,
        block_kv=cfg.block_kv,
        head_dim=head_dim,
        k_load=_build_kvfused_k_load(cfg),
        v_load=_build_kvfused_v_load(cfg),
        softmax_block=_build_softmax(cfg),
        final_div=_build_final_div(cfg),
    )
    tag = cfg.tag().replace(" ", "_").replace("=", "")
    return _exec_from_file(source, f"kvfused_{tag}", "turboquant_kvfused_attention")


# ── workload generation ──────────────────────────────────────────────────

def _generate_attention_workload(seq_len, head_dim, bits, device):
    # synthetic inputs matching the fused attention kernel signature
    block_q = 16
    Q      = torch.randn(block_q, head_dim, device=device, dtype=torch.float16)
    K_mse  = torch.randn(seq_len, head_dim, device=device, dtype=torch.float16)
    Signs  = torch.randint(-1, 2, (seq_len, head_dim), device=device, dtype=torch.int8)
    R_norms = torch.rand(seq_len, device=device, dtype=torch.float16) + 0.1
    Q_proj = torch.randn(block_q, head_dim, device=device, dtype=torch.float16)
    V      = torch.randn(seq_len, head_dim, device=device, dtype=torch.float16)
    Output = torch.empty(block_q, head_dim, device=device, dtype=torch.float32)

    scale = 1.0 / math.sqrt(head_dim)
    correction_scale = math.sqrt(math.pi / 2) / head_dim

    return {
        "Q": Q, "K_mse": K_mse, "Signs": Signs, "R_norms": R_norms,
        "Q_proj": Q_proj, "V": V, "Output": Output,
        "scale": scale, "correction_scale": correction_scale,
        "seq_k": seq_len,
    }


def _generate_compress_workload(seq_len, head_dim, device):
    V = torch.randn(seq_len, head_dim, device=device, dtype=torch.float16)
    Indices = torch.empty(seq_len, head_dim, dtype=torch.uint8, device=device)
    Norms = torch.empty(seq_len, dtype=torch.float16, device=device)
    return {"V": V, "Indices": Indices, "Norms": Norms}


def _generate_kvfused_workload(seq_len, head_dim, k_bits, v_bits, device):
    block_q = 16
    Q      = torch.randn(block_q, head_dim, device=device, dtype=torch.float16)
    Q_proj = torch.randn(block_q, head_dim, device=device, dtype=torch.float16)
    Signs  = torch.randint(-1, 2, (seq_len, head_dim), device=device, dtype=torch.int8)
    R_norms = torch.rand(seq_len, device=device, dtype=torch.float16) + 0.1
    Output = torch.empty(block_q, head_dim, device=device, dtype=torch.float32)

    K_Indices = torch.randint(0, 1 << k_bits, (seq_len, head_dim), device=device, dtype=torch.uint8)
    K_Norms   = torch.rand(seq_len, device=device, dtype=torch.float16) + 0.1
    V_Indices = torch.randint(0, 1 << v_bits, (seq_len, head_dim), device=device, dtype=torch.uint8)
    V_Norms   = torch.rand(seq_len, device=device, dtype=torch.float16) + 0.1

    gen = torch.Generator().manual_seed(DEFAULT_SEED)
    G = torch.randn(head_dim, head_dim, generator=gen)
    Qm, Rm = torch.linalg.qr(G)
    ds = torch.sign(torch.diag(Rm)); ds[ds == 0] = 1.0
    Pi = (Qm * ds.unsqueeze(0)).to(device, dtype=torch.float16)

    k_cb = LloydMaxCodebook(head_dim, bits=k_bits)
    v_cb = LloydMaxCodebook(head_dim, bits=v_bits)

    scale = 1.0 / math.sqrt(head_dim)
    correction_scale = math.sqrt(math.pi / 2) / head_dim

    return {
        "Q": Q, "K_Indices": K_Indices, "K_Norms": K_Norms,
        "Signs": Signs, "R_norms": R_norms, "Q_proj": Q_proj,
        "V_Indices": V_Indices, "V_Norms": V_Norms, "Pi": Pi,
        "Output": Output,
        "scale": scale, "correction_scale": correction_scale,
        "seq_k": seq_len,
        "k_centroids": k_cb.centroids.tolist(),
        "v_centroids": v_cb.centroids.tolist(),
    }


# ── benchmark harness ────────────────────────────────────────────────────

def _cdiv(a, b):
    return (a + b - 1) // b


def benchmark_attention_kernel(kernel, cfg, workload, warmup=50, trials=200):
    import cuda.tile as ct

    seq_k = workload["seq_k"]
    grid = (_cdiv(cfg.block_q, cfg.block_q), 1, 1)
    stream = torch.cuda.current_stream()

    args = (
        workload["Q"], workload["K_mse"], workload["Signs"],
        workload["R_norms"], workload["Q_proj"], workload["V"],
        workload["Output"],
        workload["scale"], workload["correction_scale"],
        seq_k, cfg.use_swizzle,
    )

    # warmup: JIT compile, clock ramp, cache prime
    for _ in range(warmup):
        try:
            ct.launch(stream, grid, kernel, args)
        except Exception:
            return {"failed": True}
    torch.cuda.synchronize()

    # timed trials with CUDA events — we take the median because
    # it's robust to thermal throttling and scheduling jitter
    times_us = []
    for _ in range(trials):
        start = torch.cuda.Event(enable_timing=True)
        end   = torch.cuda.Event(enable_timing=True)
        start.record()
        ct.launch(stream, grid, kernel, args)
        end.record()
        torch.cuda.synchronize()
        times_us.append(start.elapsed_time(end) * 1000.0)

    times_us.sort()
    return {
        "failed": False,
        "median_us": times_us[len(times_us) // 2],
        "p90_us": times_us[int(len(times_us) * 0.9)],
        "min_us": times_us[0],
    }


def benchmark_compress_kernel(compress_kernel, decompress_kernel, cfg,
                              workload, codebook, pi, pi_t,
                              warmup=50, trials=200):
    import cuda.tile as ct

    seq_len = workload["V"].shape[0]
    grid = (_cdiv(seq_len, cfg.block_s), 1, 1)
    stream = torch.cuda.current_stream()

    c = codebook.centroids.tolist()
    b = codebook.boundaries.tolist()

    compress_args = (
        workload["V"], pi_t.half(),
        workload["Indices"], workload["Norms"],
        *c, *b, seq_len,
    )

    out = torch.empty_like(workload["V"])
    decompress_args = (
        workload["Indices"], workload["Norms"], pi.half(), out,
        *c, seq_len,
    )

    for _ in range(warmup):
        try:
            ct.launch(stream, grid, compress_kernel, compress_args)
            ct.launch(stream, grid, decompress_kernel, decompress_args)
        except Exception:
            return {"failed": True}
    torch.cuda.synchronize()

    times_us = []
    for _ in range(trials):
        start = torch.cuda.Event(enable_timing=True)
        end   = torch.cuda.Event(enable_timing=True)
        start.record()
        ct.launch(stream, grid, compress_kernel, compress_args)
        ct.launch(stream, grid, decompress_kernel, decompress_args)
        end.record()
        torch.cuda.synchronize()
        times_us.append(start.elapsed_time(end) * 1000.0)

    times_us.sort()
    return {
        "failed": False,
        "median_us": times_us[len(times_us) // 2],
        "p90_us": times_us[int(len(times_us) * 0.9)],
        "min_us": times_us[0],
        "output": out,
    }


def benchmark_kvfused_kernel(kernel, cfg, workload, warmup=50, trials=200):
    try:
        import cuda.tile as ct
    except ImportError:
        import cutile as ct

    grid = (_cdiv(cfg.block_q, cfg.block_q), 1, 1)
    stream = torch.cuda.current_stream()

    args = (
        workload["Q"], workload["K_Indices"], workload["K_Norms"],
        workload["Signs"], workload["R_norms"], workload["Q_proj"],
        workload["V_Indices"], workload["V_Norms"], workload["Pi"],
        workload["Output"],
        workload["scale"], workload["correction_scale"],
        workload["seq_k"],
        *workload["k_centroids"], *workload["v_centroids"],
        cfg.use_swizzle,
    )

    for _ in range(warmup):
        try:
            ct.launch(stream, grid, kernel, args)
        except Exception:
            return {"failed": True}
    torch.cuda.synchronize()

    times_us = []
    for _ in range(trials):
        start = torch.cuda.Event(enable_timing=True)
        end   = torch.cuda.Event(enable_timing=True)
        start.record()
        ct.launch(stream, grid, kernel, args)
        end.record()
        torch.cuda.synchronize()
        times_us.append(start.elapsed_time(end) * 1000.0)

    times_us.sort()
    return {
        "failed": False,
        "median_us": times_us[len(times_us) // 2],
        "p90_us": times_us[int(len(times_us) * 0.9)],
        "min_us": times_us[0],
    }


# ── quality gate ─────────────────────────────────────────────────────────

def check_kvfused_quality(kernel, cfg, workload, reference, threshold=0.85):
    try:
        import cuda.tile as ct
    except ImportError:
        import cutile as ct

    grid = (_cdiv(cfg.block_q, cfg.block_q), 1, 1)
    stream = torch.cuda.current_stream()

    output = torch.empty_like(workload["Output"])
    args = (
        workload["Q"], workload["K_Indices"], workload["K_Norms"],
        workload["Signs"], workload["R_norms"], workload["Q_proj"],
        workload["V_Indices"], workload["V_Norms"], workload["Pi"],
        output,
        workload["scale"], workload["correction_scale"],
        workload["seq_k"],
        *workload["k_centroids"], *workload["v_centroids"],
        cfg.use_swizzle,
    )

    ct.launch(stream, grid, kernel, args)
    torch.cuda.synchronize()

    cos = F.cosine_similarity(
        output.float().flatten(), reference.float().flatten(), dim=0).item()
    return cos >= threshold, cos


def check_attention_quality(kernel, cfg, workload, reference, threshold=0.85):
    import cuda.tile as ct

    grid = (_cdiv(cfg.block_q, cfg.block_q), 1, 1)
    stream = torch.cuda.current_stream()

    output = torch.empty_like(workload["Output"])
    args = (
        workload["Q"], workload["K_mse"], workload["Signs"],
        workload["R_norms"], workload["Q_proj"], workload["V"],
        output,
        workload["scale"], workload["correction_scale"],
        workload["seq_k"], cfg.use_swizzle,
    )

    ct.launch(stream, grid, kernel, args)
    torch.cuda.synchronize()

    cos = F.cosine_similarity(
        output.float().flatten(), reference.float().flatten(), dim=0).item()
    return cos >= threshold, cos


def check_compress_quality(output, original, threshold=0.85):
    cos = F.cosine_similarity(
        output.float().flatten(), original.float().flatten(), dim=0).item()
    return cos >= threshold, cos


# ── pytorch reference (known-correct, for quality check) ─────────────────

def _pytorch_fused_attention(workload):
    Q      = workload["Q"].float()
    K_mse  = workload["K_mse"].float()
    Signs  = workload["Signs"].float()
    R_norms = workload["R_norms"].float()
    Q_proj = workload["Q_proj"].float()
    V      = workload["V"].float()
    scale  = workload["scale"]
    cs     = workload["correction_scale"]

    term1  = Q @ K_mse.T
    term2  = cs * (Q_proj @ Signs.T) * R_norms.unsqueeze(0)
    scores = (term1 + term2) * scale
    return (torch.softmax(scores, dim=-1) @ V).float()


def _pytorch_kvfused_attention(workload):
    Q      = workload["Q"].float()
    Q_proj = workload["Q_proj"].float()
    Signs  = workload["Signs"].float()
    R_norms = workload["R_norms"].float()
    Pi     = workload["Pi"].float()
    scale  = workload["scale"]
    cs     = workload["correction_scale"]

    kc = workload["k_centroids"]
    vc = workload["v_centroids"]

    # decompress K
    ki = workload["K_Indices"].float()
    k_hat = torch.full_like(ki, kc[0])
    k_hat = torch.where(ki > 0.5, kc[1], k_hat)
    k_hat = torch.where(ki > 1.5, kc[2], k_hat)
    k_hat = torch.where(ki > 2.5, kc[3], k_hat)
    K_recon = (k_hat @ Pi) * workload["K_Norms"].float().unsqueeze(1)

    # decompress V
    vi = workload["V_Indices"].float()
    v_hat = torch.full_like(vi, vc[0])
    v_hat = torch.where(vi > 0.5, vc[1], v_hat)
    v_hat = torch.where(vi > 1.5, vc[2], v_hat)
    v_hat = torch.where(vi > 2.5, vc[3], v_hat)
    v_hat = torch.where(vi > 3.5, vc[4], v_hat)
    v_hat = torch.where(vi > 4.5, vc[5], v_hat)
    v_hat = torch.where(vi > 5.5, vc[6], v_hat)
    v_hat = torch.where(vi > 6.5, vc[7], v_hat)
    V_recon = (v_hat @ Pi) * workload["V_Norms"].float().unsqueeze(1)

    term1  = Q @ K_recon.T
    term2  = cs * (Q_proj @ Signs.T) * R_norms.unsqueeze(0)
    scores = (term1 + term2) * scale
    return (torch.softmax(scores, dim=-1) @ V_recon).float()


# ── dispatch table ───────────────────────────────────────────────────────
# JSON at ~/.turboquant/dispatch_table.json
# keyed by sm_tag -> "seq_len:head_dim:Nbit"

DISPATCH_DIR = Path.home() / ".turboquant"
DISPATCH_FILE = DISPATCH_DIR / "dispatch_table.json"


def _load_dispatch_table():
    if not DISPATCH_FILE.exists():
        return {"version": 1, "attention": {}, "compress": {}}
    with open(DISPATCH_FILE) as f:
        return json.load(f)


def _save_dispatch_table(table):
    DISPATCH_DIR.mkdir(parents=True, exist_ok=True)
    with open(DISPATCH_FILE, "w") as f:
        json.dump(table, f, indent=2)


def _workload_key(seq_len, head_dim, bits):
    return f"{seq_len}:{head_dim}:{bits}bit"


def save_tuned_attention(cfg, gpu, seq_len, head_dim, bits, median_us, cos_sim):
    table = _load_dispatch_table()
    sm = gpu.sm_tag
    key = _workload_key(seq_len, head_dim, bits)

    table["attention"].setdefault(sm, {})[key] = {
        **asdict(cfg),
        "median_us": round(median_us, 2),
        "cos_sim": round(cos_sim, 4),
        "tuned_on": gpu.name,
        "tuned_at": datetime.now(timezone.utc).isoformat(),
    }
    _save_dispatch_table(table)


def save_tuned_compress(cfg, gpu, seq_len, head_dim, bits, median_us, cos_sim):
    table = _load_dispatch_table()
    sm = gpu.sm_tag
    key = _workload_key(seq_len, head_dim, bits)

    table["compress"].setdefault(sm, {})[key] = {
        **asdict(cfg),
        "median_us": round(median_us, 2),
        "cos_sim": round(cos_sim, 4),
        "tuned_on": gpu.name,
        "tuned_at": datetime.now(timezone.utc).isoformat(),
    }
    _save_dispatch_table(table)


def get_tuned_attention_config(seq_len, head_dim, bits):
    # look up best config from dispatch table, fall back to defaults
    if not torch.cuda.is_available():
        return DEFAULT_ATTENTION_CONFIG
    try:
        gpu = GPUProps.detect()
    except Exception:
        return DEFAULT_ATTENTION_CONFIG

    table = _load_dispatch_table()
    entry = table.get("attention", {}).get(gpu.sm_tag, {}).get(
        _workload_key(seq_len, head_dim, bits))

    if entry:
        return AttentionTuneConfig(
            block_q=entry["block_q"], block_kv=entry["block_kv"],
            occupancy=entry["occupancy"],
            latency_k=entry["latency_k"], latency_v=entry["latency_v"],
            use_swizzle=entry["use_swizzle"],
            precision_mode=entry["precision_mode"],
        )
    return DEFAULT_ATTENTION_CONFIG


def get_tuned_compress_config(seq_len, head_dim, bits):
    if not torch.cuda.is_available():
        return DEFAULT_COMPRESS_CONFIG
    try:
        gpu = GPUProps.detect()
    except Exception:
        return DEFAULT_COMPRESS_CONFIG

    table = _load_dispatch_table()
    entry = table.get("compress", {}).get(gpu.sm_tag, {}).get(
        _workload_key(seq_len, head_dim, bits))

    if entry:
        return CompressTuneConfig(block_s=entry["block_s"], fused_kv=entry["fused_kv"])
    return DEFAULT_COMPRESS_CONFIG


# ── tuning orchestrators ─────────────────────────────────────────────────

def tune_attention(seq_len=8192, head_dim=HEAD_DIM, bits=DEFAULT_TOTAL_BITS,
                   warmup=50, trials=200, quality_threshold=0.90,
                   reverify_trials=500, verbose=True, dry_run=False):
    gpu = GPUProps.detect()

    if verbose:
        print("TurboQuant Kernel Autotuner")
        print("=" * 50)
        print(f"Device: {gpu.name} ({gpu.sm_tag})")
        print(f"SMEM/SM: {gpu.smem_per_sm // 1024} KB")
        print(f"Workload: seq_len={seq_len}, head_dim={head_dim}, bits={bits}\n")

    all_configs = enumerate_attention_configs()
    if verbose:
        print(f"Enumerating configs... {len(all_configs):,} total")

    valid = prune_attention_configs(all_configs, gpu, head_dim)
    if verbose:
        print(f"After SMEM + register pruning... {len(valid):,} remain\n")

    if dry_run:
        if verbose:
            print("[dry-run] stopping before GPU work.")
            for c in valid[:10]:
                print(f"  {c.tag()}  SMEM={compute_attention_smem(c, head_dim)/1024:.0f}KB")
        return None

    if not valid:
        print("no valid configs after pruning")
        return None

    workload = _generate_attention_workload(seq_len, head_dim, bits, "cuda")
    reference = _pytorch_fused_attention(workload)

    est_min = len(valid) * (warmup + trials) * 0.005 / 60
    if verbose:
        print(f"benchmarking {len(valid)} configs (est. ~{est_min:.0f} min)\n")

    results = []
    best_so_far = float("inf")

    for i, cfg in enumerate(valid):
        try:
            kernel = make_attention_kernel(cfg, head_dim)
        except Exception as e:
            if verbose:
                print(f"[{i+1:>4}/{len(valid)}] {cfg.tag()}  COMPILE FAILED: {e}")
            continue

        timing = benchmark_attention_kernel(kernel, cfg, workload, warmup, trials)
        if timing["failed"]:
            if verbose:
                print(f"[{i+1:>4}/{len(valid)}] {cfg.tag()}  LAUNCH FAILED")
            continue

        passed, cos = check_attention_quality(
            kernel, cfg, workload, reference, quality_threshold)

        median = timing["median_us"]
        marker = " *" if passed and median < best_so_far else ""
        if passed and median < best_so_far:
            best_so_far = median

        if verbose:
            tag = "pass" if passed else "FAIL"
            print(f"[{i+1:>4}/{len(valid)}] {cfg.tag()}  "
                  f"{median:8.1f}us  cos={cos:.4f}  {tag}{marker}")

        results.append({
            "cfg": cfg, "kernel": kernel,
            "median_us": median, "cos_sim": cos, "passed": passed,
            **timing,
        })

    passed_results = [r for r in results if r["passed"]]
    if not passed_results:
        if verbose:
            print("\nno config passed quality threshold")
        return None

    # sort by latency, break ties by quality
    passed_results.sort(key=lambda r: (r["median_us"], -r["cos_sim"]))

    if verbose:
        print(f"\ntop 5:")
        for j, r in enumerate(passed_results[:5]):
            print(f"  {j+1}. {r['cfg'].tag()}  {r['median_us']:8.1f}us  "
                  f"cos={r['cos_sim']:.4f}")

    # re-verify top 3 with more trials to make sure ranking is stable
    top_n = passed_results[:3]
    if verbose and len(top_n) > 1:
        print(f"\nre-verifying top {len(top_n)} ({reverify_trials} trials each)...")

    for r in top_n:
        retiming = benchmark_attention_kernel(
            r["kernel"], r["cfg"], workload, warmup, reverify_trials)
        if not retiming["failed"]:
            r["median_us"] = retiming["median_us"]
            if verbose:
                print(f"  {r['cfg'].tag()}  {retiming['median_us']:8.1f}us")

    top_n.sort(key=lambda r: (r["median_us"], -r["cos_sim"]))
    best = top_n[0]

    save_tuned_attention(best["cfg"], gpu, seq_len, head_dim, bits,
                         best["median_us"], best["cos_sim"])

    if verbose:
        print(f"\n{'=' * 50}")
        print(f"selected: {best['cfg'].tag()}")
        print(f"  median latency: {best['median_us']:.1f} us")
        print(f"  cosine similarity: {best['cos_sim']:.4f}")
        print(f"  saved to {DISPATCH_FILE}")

    return best["cfg"]


def tune_compress(seq_len=8192, head_dim=HEAD_DIM, bits=DEFAULT_TOTAL_BITS,
                  warmup=50, trials=200, quality_threshold=0.90,
                  verbose=True, dry_run=False):
    gpu = GPUProps.detect()

    if verbose:
        print("TurboQuant Autotuner — Compress/Decompress")
        print("=" * 50)
        print(f"Device: {gpu.name} ({gpu.sm_tag})")
        print(f"Workload: seq_len={seq_len}, head_dim={head_dim}, bits={bits}\n")

    all_configs = enumerate_compress_configs(bits)
    valid = prune_compress_configs(all_configs, gpu, head_dim)

    if verbose:
        print(f"{len(all_configs)} configs -> {len(valid)} after pruning\n")

    if dry_run or not valid:
        return None

    # set up rotation matrix and codebook for compress/decompress
    codebook = LloydMaxCodebook(head_dim, bits)
    gen = torch.Generator(device="cpu")
    gen.manual_seed(DEFAULT_SEED)
    G = torch.randn(head_dim, head_dim, generator=gen)
    Q, R = torch.linalg.qr(G)
    diag_sign = torch.sign(torch.diag(R))
    diag_sign[diag_sign == 0] = 1.0
    pi = (Q * diag_sign.unsqueeze(0)).cuda()
    pi_t = pi.T.contiguous()

    workload = _generate_compress_workload(seq_len, head_dim, "cuda")
    original_v = workload["V"].clone()

    results = []
    for i, cfg in enumerate(valid):
        try:
            ck = make_compress_kernel(cfg, head_dim)
            dk = make_decompress_kernel(cfg, head_dim)
        except Exception as e:
            if verbose:
                print(f"[{i+1}/{len(valid)}] {cfg.tag()}  COMPILE FAILED: {e}")
            continue

        timing = benchmark_compress_kernel(
            ck, dk, cfg, workload, codebook, pi, pi_t, warmup, trials)
        if timing["failed"]:
            if verbose:
                print(f"[{i+1}/{len(valid)}] {cfg.tag()}  LAUNCH FAILED")
            continue

        passed, cos = check_compress_quality(timing["output"], original_v, quality_threshold)
        if verbose:
            tag = "pass" if passed else "FAIL"
            print(f"[{i+1}/{len(valid)}] {cfg.tag()}  "
                  f"{timing['median_us']:8.1f}us  cos={cos:.4f}  {tag}")

        results.append({
            "cfg": cfg, "median_us": timing["median_us"],
            "cos_sim": cos, "passed": passed,
        })

    passed_results = [r for r in results if r["passed"]]
    if not passed_results:
        if verbose:
            print("\nno compress config passed quality threshold")
        return None

    passed_results.sort(key=lambda r: (r["median_us"], -r["cos_sim"]))
    best = passed_results[0]

    save_tuned_compress(best["cfg"], gpu, seq_len, head_dim, bits,
                        best["median_us"], best["cos_sim"])

    if verbose:
        print(f"\nselected: {best['cfg'].tag()}")
        print(f"  median: {best['median_us']:.1f} us  cos={best['cos_sim']:.4f}")
        print(f"  saved to {DISPATCH_FILE}")

    return best["cfg"]


def tune_all(seq_len=8192, head_dim=HEAD_DIM, bits=DEFAULT_TOTAL_BITS,
             warmup=50, trials=200, quality_threshold=0.90,
             verbose=True, dry_run=False):
    results = {}
    results["attention"] = tune_attention(
        seq_len=seq_len, head_dim=head_dim, bits=bits,
        warmup=warmup, trials=trials,
        quality_threshold=quality_threshold,
        verbose=verbose, dry_run=dry_run)

    if verbose:
        print("\n")

    results["compress"] = tune_compress(
        seq_len=seq_len, head_dim=head_dim, bits=bits,
        warmup=warmup, trials=trials,
        quality_threshold=quality_threshold,
        verbose=verbose, dry_run=dry_run)

    return results


# ── CLI ──────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(
        prog="turboquant_gpu.autotune",
        description="kernel-level autotuner for turboquant-gpu",
    )
    p.add_argument("--seq-len", type=int, default=8192)
    p.add_argument("--head-dim", type=int, default=HEAD_DIM)
    p.add_argument("--bits", type=int, default=DEFAULT_TOTAL_BITS, choices=[2, 3])
    p.add_argument("--warmup", type=int, default=50)
    p.add_argument("--trials", type=int, default=200)
    p.add_argument("--quality-threshold", type=float, default=0.90)
    p.add_argument("--output", type=str, default=None,
                   help="custom dispatch table path")
    p.add_argument("--dry-run", action="store_true",
                   help="prune only, no GPU work")
    p.add_argument("--attention-only", action="store_true")
    p.add_argument("--compress-only", action="store_true")
    p.add_argument("--quiet", action="store_true")

    args = p.parse_args()

    if args.output:
        global DISPATCH_FILE
        DISPATCH_FILE = Path(args.output)

    verbose = not args.quiet

    if not torch.cuda.is_available():
        print("error: CUDA not available")
        sys.exit(1)

    kw = dict(seq_len=args.seq_len, head_dim=args.head_dim, bits=args.bits,
              warmup=args.warmup, trials=args.trials,
              quality_threshold=args.quality_threshold,
              verbose=verbose, dry_run=args.dry_run)

    if args.attention_only:
        tune_attention(**kw)
    elif args.compress_only:
        tune_compress(**kw)
    else:
        tune_all(**kw)


if __name__ == "__main__":
    main()
