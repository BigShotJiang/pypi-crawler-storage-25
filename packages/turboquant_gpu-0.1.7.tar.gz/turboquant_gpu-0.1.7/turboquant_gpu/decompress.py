# decompression: indices -> dequant -> un-rotate(Pi) -> scale by norms

try:
    import cuda.tile as ct
except ImportError:
    import cutile as ct  # type: ignore

from .constants import BLOCK_S, HEAD_DIM


# fused K+V decompression (3-bit, shared codebook)

@ct.kernel
def turboquant_decompress_kv_3bit(
    K_Indices, K_Norms, V_Indices, V_Norms, Pi,
    K_Output, V_Output,
    c0: float, c1: float, c2: float, c3: float,
    c4: float, c5: float, c6: float, c7: float,
    seq_len: int,
):
    block_id = ct.bid(0)
    zero_pad = ct.PaddingMode.ZERO

    pi = ct.load(Pi, index=(0, 0), shape=(HEAD_DIM, HEAD_DIM))

    # keys
    k_idx = ct.load(K_Indices, index=(block_id, 0), shape=(BLOCK_S, HEAD_DIM),
                    padding_mode=zero_pad)
    k_nrm = ct.load(K_Norms, index=(block_id,), shape=(BLOCK_S,),
                    padding_mode=zero_pad)

    ki_f32 = ct.astype(k_idx, ct.float32)
    k_hat = ct.full((BLOCK_S, HEAD_DIM), c0, dtype=ct.float32)
    k_hat = ct.where(ki_f32 > 0.5, c1, k_hat)
    k_hat = ct.where(ki_f32 > 1.5, c2, k_hat)
    k_hat = ct.where(ki_f32 > 2.5, c3, k_hat)
    k_hat = ct.where(ki_f32 > 3.5, c4, k_hat)
    k_hat = ct.where(ki_f32 > 4.5, c5, k_hat)
    k_hat = ct.where(ki_f32 > 5.5, c6, k_hat)
    k_hat = ct.where(ki_f32 > 6.5, c7, k_hat)

    k_recon = ct.mma(ct.astype(k_hat, ct.float16), pi,
                     ct.zeros((BLOCK_S, HEAD_DIM), dtype=ct.float32))
    k_out = k_recon * ct.expand_dims(ct.astype(k_nrm, ct.float32), axis=1)
    ct.store(K_Output, index=(block_id, 0), tile=ct.astype(k_out, ct.float16))

    # values
    v_idx = ct.load(V_Indices, index=(block_id, 0), shape=(BLOCK_S, HEAD_DIM),
                    padding_mode=zero_pad)
    v_nrm = ct.load(V_Norms, index=(block_id,), shape=(BLOCK_S,),
                    padding_mode=zero_pad)

    vi_f32 = ct.astype(v_idx, ct.float32)
    v_hat = ct.full((BLOCK_S, HEAD_DIM), c0, dtype=ct.float32)
    v_hat = ct.where(vi_f32 > 0.5, c1, v_hat)
    v_hat = ct.where(vi_f32 > 1.5, c2, v_hat)
    v_hat = ct.where(vi_f32 > 2.5, c3, v_hat)
    v_hat = ct.where(vi_f32 > 3.5, c4, v_hat)
    v_hat = ct.where(vi_f32 > 4.5, c5, v_hat)
    v_hat = ct.where(vi_f32 > 5.5, c6, v_hat)
    v_hat = ct.where(vi_f32 > 6.5, c7, v_hat)

    v_recon = ct.mma(ct.astype(v_hat, ct.float16), pi,
                     ct.zeros((BLOCK_S, HEAD_DIM), dtype=ct.float32))
    v_out = v_recon * ct.expand_dims(ct.astype(v_nrm, ct.float32), axis=1)
    ct.store(V_Output, index=(block_id, 0), tile=ct.astype(v_out, ct.float16))


# separate decompression

@ct.kernel
def turboquant_decompress_3bit(
    Indices, Norms, Pi,
    Output,
    c0: float, c1: float, c2: float, c3: float,
    c4: float, c5: float, c6: float, c7: float,
    seq_k: int,
):
    block_id = ct.bid(0)
    zero_pad = ct.PaddingMode.ZERO

    idx_tile  = ct.load(Indices, index=(block_id, 0), shape=(BLOCK_S, HEAD_DIM),
                        padding_mode=zero_pad)
    norm_tile = ct.load(Norms, index=(block_id,), shape=(BLOCK_S,),
                        padding_mode=zero_pad)
    pi = ct.load(Pi, index=(0, 0), shape=(HEAD_DIM, HEAD_DIM))

    idx_f32 = ct.astype(idx_tile, ct.float32)

    y_hat = ct.full((BLOCK_S, HEAD_DIM), c0, dtype=ct.float32)
    y_hat = ct.where(idx_f32 > 0.5, c1, y_hat)
    y_hat = ct.where(idx_f32 > 1.5, c2, y_hat)
    y_hat = ct.where(idx_f32 > 2.5, c3, y_hat)
    y_hat = ct.where(idx_f32 > 3.5, c4, y_hat)
    y_hat = ct.where(idx_f32 > 4.5, c5, y_hat)
    y_hat = ct.where(idx_f32 > 5.5, c6, y_hat)
    y_hat = ct.where(idx_f32 > 6.5, c7, y_hat)

    x_hat  = ct.mma(ct.astype(y_hat, ct.float16), pi,
                    ct.zeros((BLOCK_S, HEAD_DIM), dtype=ct.float32))
    result = x_hat * ct.expand_dims(ct.astype(norm_tile, ct.float32), axis=1)

    ct.store(Output, index=(block_id, 0), tile=ct.astype(result, ct.float16))


@ct.kernel
def turboquant_decompress_2bit(
    Indices, Norms, Pi,
    Output,
    c0: float, c1: float, c2: float, c3: float,
    seq_k: int,
):
    block_id = ct.bid(0)
    zero_pad = ct.PaddingMode.ZERO

    idx_tile  = ct.load(Indices, index=(block_id, 0), shape=(BLOCK_S, HEAD_DIM),
                        padding_mode=zero_pad)
    norm_tile = ct.load(Norms, index=(block_id,), shape=(BLOCK_S,),
                        padding_mode=zero_pad)
    pi = ct.load(Pi, index=(0, 0), shape=(HEAD_DIM, HEAD_DIM))

    idx_f32 = ct.astype(idx_tile, ct.float32)

    y_hat = ct.full((BLOCK_S, HEAD_DIM), c0, dtype=ct.float32)
    y_hat = ct.where(idx_f32 > 0.5, c1, y_hat)
    y_hat = ct.where(idx_f32 > 1.5, c2, y_hat)
    y_hat = ct.where(idx_f32 > 2.5, c3, y_hat)

    x_hat  = ct.mma(ct.astype(y_hat, ct.float16), pi,
                    ct.zeros((BLOCK_S, HEAD_DIM), dtype=ct.float32))
    result = x_hat * ct.expand_dims(ct.astype(norm_tile, ct.float32), axis=1)

    ct.store(Output, index=(block_id, 0), tile=ct.astype(result, ct.float16))
