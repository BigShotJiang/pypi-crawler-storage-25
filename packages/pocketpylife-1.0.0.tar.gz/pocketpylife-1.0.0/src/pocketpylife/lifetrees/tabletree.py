'''The code for the Lifetree variant used to simulate custom rules.'''
#Importing modules:
import hashlib
import os
import sys
#Other project modules:
try:
    from ..genera.ruleloader import compile_rule
except ImportError:
    sys.path.append(os.path.dirname(__file__)+'/genera')
    from ruleloader import compile_rule
try:
    from ..pattern.multistatepattern import Pattern
except ImportError:
    sys.path.append(os.path.dirname(__file__)+'/../pattern')
    from multistatepattern import Pattern
try:
    from ..gridops import *
except ImportError:
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from gridops import *
#A few global variables:
CATAGOLUE_URL = 'https://catagolue.hatsya.com'
class Lifetree:
    '''Handles and simulates patterns.'''
    def __init__(self, ruletable='LifeHistory.rule'):
        self.rule, self.layers = compile_rule(ruletable)
        self.layers = int(self.layers) - 1
        sys.path.append(os.path.dirname(__file__)+'/../genera')
        customrulesim = __import__('customrulesim')
        self.advancecell = customrulesim.advancecell
        self.__file__ = __file__
    def getneighbours(self, grid):
        '''For each cell with at least one live neighbour, get a 9-bit integer.'''
        neighbours = {}
        deltas = ((0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1))
        newgrid = {x:grid[x] for x in grid}
        for x in grid:
            xcor, ycor = x[0], x[1]
            for dx, dy in deltas:
                if (xcor + dx, ycor + dy) not in grid:
                    newgrid[(xcor + dx, ycor + dy)] = 0
        grid = {x:newgrid[x] for x in newgrid}
        for x in grid:
            xcor, ycor = x[0], x[1]
            cell = grid[x]
            neighbourlist = [cell]
            for dx, dy in deltas:
                if (xcor + dx, ycor + dy) not in grid:
                    neighbourlist.append(0)
                else:
                    neighbourlist.append(grid[(xcor + dx, ycor + dy)])
            neighbourlist = [str(s) for s in neighbourlist]
            neighbours[x] = neighbourlist[:]
        return neighbours
    def advanceone(self, grid):
        '''Advance a grid of cells by one generation.'''
        neighbours = self.getneighbours(grid)
        newgrid = {}
        adv = self.advancecell
        for x in neighbours:
            ev = int(adv(neighbours[x]))
            if ev != 0:
                newgrid[x] = ev
        return newgrid
    def advance(self, grid, gens):
        '''Advance a grid a specific number of generations.'''
        adv = self.advanceone
        for _ in range(gens):
            grid = adv(grid)
        return grid
    def rle_to_grid(self, rle):
        '''Converts an RLE to a dictionary format.'''
        x = 0
        y = 0
        grid = {}
        position = -1
        digits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
        letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'U', 'V', 'W', 'X', 'Y', 'Z']
        cstring = ''
        isnum = False
        while position + 1 < len(rle):
            position += 1
            if not isnum:
                if rle[position] == '#' or rle[position] == 'x':
                    while rle[position] != '\n' and position < len(rle) - 1:
                        position += 1
                    continue
                if rle[position] in digits:
                    isnum = True
                    cstring = rle[position]
                else:
                    operator = rle[position]
                    if operator == '\n':
                        continue
                    if cstring != '':
                        try:
                            integer = int(cstring)
                        except ValueError:
                            raise Warning('Invalid RLE format, defaulting to empty pattern...')
                            return {}
                    else:
                        integer = 1
                    if operator ==  'o':
                        for n in range(integer):
                            grid[(x+n, y)] = 1
                        x += integer
                    elif operator in letters:
                        for n in range(integer):
                            grid[(x+n, y)] = letters.index(operator) + 1
                        x += integer                        
                    elif operator ==  '.' or operator == 'b':
                        x += integer
                    elif operator ==  '$':
                        x = 0
                        y += integer
                    elif operator ==  '!':
                        break
                    cstring = ''
            else:
                if rle[position] not in digits:
                    isnum = False
                    position -= 1
                else:
                    if rle[position] != '\n':
                        cstring += rle[position]
        return grid
    def grid_to_rle(self, grid, bbox):
        '''Converts a grid to the RLE of a pattern.'''
        rows = {}
        for x, y in grid:
            if y not in rows:
                rows[y] = []
            rows[y].append(x)
        for x in rows:
            rows[x] = sorted(rows[x])
        letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'U', 'V', 'W', 'X', 'Y', 'Z']
        rows = dict(sorted(rows.items()))
        rle = 'x = '+str(bbox[2])+', y = '+str(bbox[3])+', rule = '+self.rule+'\n'
        for x in range(bbox[1], bbox[1] + bbox[3]):
            if x not in rows:
                rle += '$'
                continue
            for y in range(bbox[0], bbox[0] + bbox[2]):
                if y in rows[x]:
                    rle += letters[grid[(y, x)] - 1]
                else:
                    rle += '.'
            rle += '$'
        rle = rle[:-1]
        rle += '!'
        #Compress the RLE:
        operators = ['.', '$', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
        for x in operators:
            longestchain = 1
            while rle.count(x * (longestchain)) > 0:
                longestchain += 1
            if longestchain >= 2:
                for n in range(longestchain, 1, -1):
                    rle = rle.replace(x * n, str(n)+x)
        return rle
    def hashsoup(self, instring, sym):
        '''Generates a soup based on the instring, returning a Pattern.'''
        #I borrowed this function from apgsearch Py3 - see the repo (https://github.com/PKTwentyTwo/apgsearch-Py3) for the credits for this function.
        if sym[0] in ['G', 'H'] and 'stdin' not in sym.lower() and len(sym) > 1:
            sym = sym[0].replace('G', 'C').replace('H', 'D') + sym[1:]
            #Adaptation to account for GPU symmetries.
        if 'stdin' not in sym.lower():
            s = hashlib.sha256(instring.encode('utf-8')).digest()
            thesoup = []
            if sym in ['D2_x', 'D8_1', 'D8_4']:
                d = 1
            elif sym in ['D4_x1', 'D4_x4']:
                d = 2
            else:
                d = 0
            for j in range(32):
                t = s[j]
                for k in range(8):
                    if sym in ['8x32']:
                        x = k + 8*(j % 4)
                        y = int(j / 4)
                    elif sym in ['4x64']:  
                        x = k + 8*(j % 8)
                        y = int(j / 8)
                    elif sym in ['2x128']:
                        x = k + 8*(j % 16)
                        y = int(j / 16)
                    elif sym in ['1x256']:
                        x = k + 8*(j % 32)
                        y = int(j / 32)
                    else:
                        x = k + 8*(j % 2)
                        y = int(j / 2)
                    if (t & (1 << (7 - k))):
                        if (d == 0) | (x >= y):
                            thesoup.append(x)
                            thesoup.append(y)
                        elif sym in ['D4_x1']:
                            thesoup.append(y)
                            thesoup.append(-x)
                        elif sym in ['D4_x4']:
                            thesoup.append(y)
                            thesoup.append(-x-1)
                        if (sym in ['D4_x1']) & (x == y):
                            thesoup.append(y)
                            thesoup.append(-x)
                        if (sym in ['D4_x4']) & (x == y):
                            thesoup.append(y)
                            thesoup.append(-x-1)
            # Checks for diagonal symmetries:
            if (d >= 1):
                for x in range(0, len(thesoup), 2):
                    thesoup.append(thesoup[x+1])
                    thesoup.append(thesoup[x])
                if d == 2:
                    if sym == 'D4_x1':
                        for x in range(0, len(thesoup), 2):
                            thesoup.append(-thesoup[x+1])
                            thesoup.append(-thesoup[x])
                    else:
                        for x in range(0, len(thesoup), 2):
                            thesoup.append(-thesoup[x+1] - 1)
                            thesoup.append(-thesoup[x] - 1)
            # Checks for orthogonal x symmetry:
            if sym in ['D2_+1', 'D4_+1', 'D4_+2']:
                for x in range(0, len(thesoup), 2):
                    thesoup.append(thesoup[x])
                    thesoup.append(-thesoup[x+1])
            elif sym in ['D2_+2', 'D4_+4']:
                for x in range(0, len(thesoup), 2):
                    thesoup.append(thesoup[x])
                    thesoup.append(-thesoup[x+1] - 1)
            # Checks for orthogonal y symmetry:
            if sym in ['D4_+1']:
                for x in range(0, len(thesoup), 2):
                    thesoup.append(-thesoup[x])
                    thesoup.append(thesoup[x+1])
            elif sym in ['D4_+2', 'D4_+4']:
                for x in range(0, len(thesoup), 2):
                    thesoup.append(-thesoup[x] - 1)
                    thesoup.append(thesoup[x+1])
            # Checks for rotate2 symmetry:
            if sym in ['C2_1', 'C4_1', 'D8_1']:
                for x in range(0, len(thesoup), 2):
                    thesoup.append(-thesoup[x])
                    thesoup.append(-thesoup[x+1])
            elif sym in ['C2_2']:
                for x in range(0, len(thesoup), 2):
                    thesoup.append(-thesoup[x])
                    thesoup.append(-thesoup[x+1]-1)
            elif sym in ['C2_4', 'C4_4', 'D8_4']:
                for x in range(0, len(thesoup), 2):
                    thesoup.append(-thesoup[x]-1)
                    thesoup.append(-thesoup[x+1]-1)
            # Checks for rotate4 symmetry:
            if (sym in ['C4_1', 'D8_1']):
                for x in range(0, len(thesoup), 2):
                    thesoup.append(thesoup[x+1])
                    thesoup.append(-thesoup[x])
            elif (sym in ['C4_4', 'D8_4']):
                for x in range(0, len(thesoup), 2):
                    thesoup.append(thesoup[x+1])
                    thesoup.append(-thesoup[x]-1)
            thesoup2 = {}
            for x in range(len(thesoup)//2):
                thesoup2[(thesoup[2*x], thesoup[2*x+1])] = 1
            return self.pattern(thesoup2)
        else:
            if instring.count('-') == 1:
                rle = instring.split('-')[1]
                return self.pattern(rle)
        return self.pattern('b!')
    def pattern(self, data):
        '''Creates a new Pattern given an RLE string.'''
        datatype = identifytype(data)
        if datatype == 'rle':
            grid = self.rle_to_grid(data)
        elif datatype == 'apgcode':
            grid = apgcodetogrid2(data)
        else:
            grid = data
        pt = Pattern(self, grid)
        return pt
