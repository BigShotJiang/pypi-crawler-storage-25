cd src
rm -rf pocketpylife
git clone https://github.com/PKTwentyTwo/pocketpylife
cd ..
python3 -m build
python3 -m twine upload --repository pypi dist/* --verbose
sleep 60
pip install --upgrade pocketpylife