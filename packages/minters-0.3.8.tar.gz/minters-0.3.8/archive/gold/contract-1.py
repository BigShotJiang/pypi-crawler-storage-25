# this is meant to be a simple gold contract to derive prop and compute the price delta

import asyncio
import os
import numpy as np
from harness import get_historical_ohlc, market_buy, close_all_by_symbol, get_account_snapshot, market_sell
from dotenv import load_dotenv, find_dotenv

# This automatically searches up the directory tree
load_dotenv(find_dotenv())

# Indicators
def calculate_rsi(prices, period=14):
    deltas = np.diff(prices)
    seed = deltas[:period]
    up = seed[seed >= 0].sum() / period
    down = -seed[seed < 0].sum() / period
    rs = up / down if down != 0 else 100
    rsi = 100. - 100. / (1. + rs)

    for i in range(period, len(deltas) + 1):
        diff = deltas[i - 1]
        up = (up * (period - 1) + (diff if diff > 0 else 0)) / period
        down = (down * (period - 1) + (-diff if diff < 0 else 0)) / period
        rs = up / down if down != 0 else 100
        rsi = 100. - 100. / (1. + rs)
    return rsi

def calculate_ema(prices, period=20):
    ema = np.zeros_like(prices)
    ema[0] = prices[0]
    multiplier = 2 / (period + 1)
    for i in range(1, len(prices)):
        ema[i] = (prices[i] - ema[i - 1]) * multiplier + ema[i - 1]
    return ema[-1]

class GoldContract:
    
    symbol = "BTCUSDm"
    account_id = os.getenv("MASTER_ACCOUNT_ID")
    risk_cap = 0.02  # Max 2% of balance per trade

    async def run(self):
        while True:
            print(f"[LOG] Starting cycle for {self.symbol}...")
            
            # Fetch historical ohlc data
            ohlc_data = await get_historical_ohlc(self.symbol, "1m", 1000)
            if not ohlc_data:
                print("[ERROR] No OHLC data received.")
                break
            
            closes = np.array([candle["close"] for candle in ohlc_data])
            current_price = closes[-1]
            
            # Compute Indicators
            rsi = calculate_rsi(closes)
            ema = calculate_ema(closes)
            
            print(f"[LOG] Price: {current_price} | RSI: {rsi:.2f} | EMA: {ema:.2f}")

            # Fetch balance for risk management
            snapshot = await get_account_snapshot()
            balance = snapshot.get("balance", 0)
            max_position_size = balance * self.risk_cap
            print(f"[LOG] Account Balance: {balance} | Risk Cap: {max_position_size:.2f}")

            # Entry Logic: RSI < 30 (Oversold) AND Price > EMA (Bullish Trend)
            if rsi < 30 and current_price > ema:
                print(f"[SIGNAL] Entry conditions met. Executing Buy...")
                # Simplified size calculation based on risk cap
                lot_size = 0.01 # Defaulting to 0.01 for safety, usually based on max_position_size
                order = await market_buy(self.symbol, lot_size)
                print(f"[TRADE] Market buy executed: {order}")
            elif rsi > 70:
                print(f"[SIGNAL] Overbought condition. Closing positions...")
                await close_all_by_symbol(self.symbol)
                print(f"[TRADE] Positions closed for {self.symbol}")
            else:
                print(f"[LOG] No signal detected. Skipping trade.")

            print("\n---\nCycle complete. Sleeping for 60s.")
            await asyncio.sleep(60)

if __name__ == "__main__":
    contract = GoldContract()
    asyncio.run(contract.run())