import asyncio
from datetime import datetime, timezone
from harness import get_historical_ticks, get_historical_ohlc
from dotenv import load_dotenv, find_dotenv

load_dotenv(find_dotenv())

# to calculate delta between a guessed price and the historical price of gold
async def prop(total):
    # get historical prices (prefer ticks, fallback to candles if ticks endpoint is unavailable)
    start_ts = int(datetime(2020, 1, 1, tzinfo=timezone.utc).timestamp())
    end_ts = int(datetime(2024, 1, 1, tzinfo=timezone.utc).timestamp())
    try:
        historical_prices = await get_historical_ticks("XAUUSDm", start_time=start_ts, end_time=end_ts, limit=total)
        print(f"Fetched {len(historical_prices)} historical ticks")

        if not historical_prices:
            raise RuntimeError("No historical ticks returned for XAUUSDm")

        mid_prices = [
            (float(t.get("bid", 0.0)) + float(t.get("ask", 0.0))) / 2.0
            for t in historical_prices
            if t.get("bid") is not None and t.get("ask") is not None
        ]
        if not mid_prices:
            raise RuntimeError("Historical ticks do not contain bid/ask values")

        avg_price = sum(mid_prices) / len(mid_prices)
    except RuntimeError as exc:
        err = str(exc)
        if (
            "404" not in err
            and "503" not in err
            and "Node not available" not in err
            and "Node disconnected" not in err
            and "No historical ticks returned" not in err
            and "Historical ticks do not contain bid/ask" not in err
        ):
            raise

        candles = await get_historical_ohlc("XAUUSDm", "1h", min(total, 1000))
        print(f"Ticks unavailable or empty, fetched {len(candles)} OHLC candles instead")
        close_prices = [float(c.get("close", 0.0)) for c in candles]
        avg_price = sum(close_prices) / len(close_prices)

    print(f"Average price: {avg_price}")
    return avg_price

total = 1000
# call the prop function
average_price = asyncio.run(prop(total))
print(f"Average price of gold from 2020 to 2023: {average_price}")



# class GoldContract:
#     symbol = "XAUUSDm"
#     account_id = os.getenv("MASTER_ACCOUNT_ID")
#     a,b,c = 2300, 2200, 2100
    
#     async def run(self):
#         while True:

#             if prop(self.a, self.b, self.c) > 5:
#                 snapshot = await get_account_snapshot()
#                 balance = snapshot.get("balance", 0)
#                 if balance > 20000:
#                     order=await market_buy(self.symbol, 0.1)
#                     print(f"Market buy order executed for {self.symbol}: {order}")
#                 else:
#                     print(f"\n---\nBalance is below threshold, skipping trade. Current balance: {balance}")
#             else:
#                 print(f"\n---\nProp is below threshold, skipping trade. Current prop: {prop(self.a, self.b, self.c)}")
#             print("\n---\nEnding contract execution.")
#             break
            

# # run the contract
# if __name__ == "__main__":
#     contract = GoldContract()
#     asyncio.run(contract.run())