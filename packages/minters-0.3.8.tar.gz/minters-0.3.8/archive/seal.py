from __future__ import annotations

import os
import re
import textwrap
import threading
import traceback
from pathlib import Path

from dotenv import load_dotenv
from rich.text import Text
from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Footer, Input, RichLog, Static

try:
    from regulator.model import regulator
except ModuleNotFoundError:
    from model import regulator

load_dotenv()

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MODEL = os.getenv("REGULATOR_MODEL", "1984-m3-0421")

SEAL_SYSTEM_PROMPT = textwrap.dedent(
    f"""
    You are Seal, a repository-native coding agent operating inside the Mint workspace at {ROOT}.

    Use the available client services whenever you need to inspect files, grep the repo, edit files,
    create or delete paths, run validation, execute contracts, or run sandboxed commands and Python snippets.

    When you are changing contracts, prefer this loop:
    1. Inspect with repo_tree, list_files, grep_repo, and read_file.
    2. Edit with patch_file or write_file.
    3. Validate with python_check or sandbox_run.
    4. Execute contracts with run_contract.
    5. Read the output and keep iterating until the contract is healthy.

    Keep the final answer concise and specific.
    """
).strip()


def build_task(user_task: str) -> str:
    return f"{SEAL_SYSTEM_PROMPT}\n\nUser task:\n{user_task.strip()}"


class SealApp(App[None]):
    CSS = """
    Screen {
        background: #0c0c0c;
        color: #dddddd;
    }

    #header-area {
        height: auto;
        padding: 1 3;
        border-bottom: solid #1e1e1e;
    }

    #minter-title {
        color: #ffffff;
        text-style: bold;
        height: 1;
    }

    #minter-subtitle {
        color: #444444;
        height: 1;
    }

    #feed {
        height: 1fr;
        padding: 1 3;
        background: #0c0c0c;
        border: none;
        scrollbar-color: #252525 #0c0c0c;
    }

    #stream-area {
        height: auto;
        max-height: 10;
        padding: 0 3;
        background: #0c0c0c;
    }

    #stream-content {
        color: #dddddd;
        height: auto;
    }

    #input-row {
        height: 3;
        border-top: solid #1e1e1e;
        padding: 0 2;
        align: left middle;
    }

    #input-prompt {
        width: 3;
        height: 1;
        color: #ffffff;
        text-style: bold;
        padding: 0;
    }

    #task-input {
        width: 1fr;
        height: 1;
        background: #0c0c0c;
        border: none;
        color: #dddddd;
        padding: 0;
    }

    #task-input:focus {
        border: none;
        background: #0c0c0c;
    }

    Footer {
        background: #0c0c0c;
        color: #383838;
        border-top: solid #161616;
    }
    """

    BINDINGS = [
        ("ctrl+j", "focus_prompt", "Prompt"),
        ("ctrl+l", "clear_logs", "Clear"),
        ("q", "quit", "Quit"),
    ]

    TITLE = "Minter"

    def __init__(self, model_name: str = DEFAULT_MODEL) -> None:
        super().__init__()
        self.model_name = model_name
        self.busy = False
        self._stream_buffer = ""

    def compose(self) -> ComposeResult:
        with Vertical(id="header-area"):
            yield Static("MINTER", id="minter-title")
            yield Static("welcome to the minter.", id="minter-subtitle")
        yield RichLog(id="feed", wrap=True, highlight=False, markup=False, auto_scroll=True)
        with Vertical(id="stream-area"):
            yield Static("", id="stream-content")
        with Horizontal(id="input-row"):
            yield Static("> ", id="input-prompt")
            yield Input(placeholder="", id="task-input")
        yield Footer()

    def on_mount(self) -> None:
        self._write_welcome()
        self.query_one("#task-input", Input).focus()

    def _write_welcome(self) -> None:
        feed = self.query_one("#feed", RichLog)
        t = Text()
        t.append("* welcome to the minter.\n\n", style="#666666")
        t.append("while(minting) {\n", style="#484848")
        t.append("    inspect_repo();\n", style="#484848")
        t.append("    edit_files();\n", style="#484848")
        t.append("    run_contracts();\n", style="#484848")
        t.append("    validate();\n", style="#484848")
        t.append("    iterate();\n", style="#484848")
        t.append("}\n\n", style="#484848")
        feed.write(t)

    # ── actions ──────────────────────────────────────────────────────────

    def action_focus_prompt(self) -> None:
        self.query_one("#task-input", Input).focus()

    def action_clear_logs(self) -> None:
        self.query_one("#feed", RichLog).clear()
        self._stream_buffer = ""
        self.query_one("#stream-content", Static).update("")
        self._write_welcome()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "task-input":
            self._submit_prompt()

    # ── feed helpers ─────────────────────────────────────────────────────

    def _feed(self, t: Text) -> None:
        self.query_one("#feed", RichLog).write(t)

    def _update_stream(self) -> None:
        lines = self._stream_buffer.split("\n")
        visible = "\n".join(lines[-12:]) if len(lines) > 12 else self._stream_buffer
        self.query_one("#stream-content", Static).update(Text(visible, style="#dddddd"))

    def _flush_stream(self) -> None:
        if self._stream_buffer.strip():
            t = Text()
            t.append(self._stream_buffer.rstrip("\n") + "\n", style="#dddddd")
            self._feed(t)
        self._stream_buffer = ""
        self.query_one("#stream-content", Static).update("")

    def _set_busy(self, busy: bool) -> None:
        self.busy = busy
        self.query_one("#task-input", Input).disabled = busy

    # ── submit ───────────────────────────────────────────────────────────

    def _submit_prompt(self) -> None:
        if self.busy:
            return

        input_widget = self.query_one("#task-input", Input)
        raw_task = input_widget.value.strip()
        if not raw_task:
            return

        input_widget.value = ""
        if self._handle_local_command(raw_task):
            return

        t = Text()
        t.append("> ", style="bold #ffffff")
        t.append(raw_task + "\n", style="#ffffff")
        self._feed(t)

        self._set_busy(True)
        task = build_task(raw_task)
        thread = threading.Thread(target=self._run_task, args=(task,), daemon=True)
        thread.start()

    def _handle_local_command(self, raw_task: str) -> bool:
        command = raw_task.strip()
        if command == "/clear":
            self.action_clear_logs()
            return True
        if command == "/help":
            t = Text()
            t.append("\n/help\n", style="bold #ffffff")
            examples = [
                "  inspect the contracts folder and summarize the strategies",
                "  fix the gold contract and iterate until it runs healthy",
                "  grep the repo for all uses of regulator and explain the flow",
                "  write a new contract in contracts/demo/contract.py and validate it",
            ]
            for line in examples:
                t.append(line + "\n", style="#484848")
            t.append("\n")
            self._feed(t)
            return True
        if command.startswith("/model "):
            next_model = command.split(" ", 1)[1].strip()
            if next_model:
                self.model_name = next_model
                t = Text()
                t.append(f"\nmodel → {self.model_name}\n\n", style="#484848")
                self._feed(t)
            return True
        return False

    # ── task execution ────────────────────────────────────────────────────

    def _run_task(self, task: str) -> None:
        try:
            regulator(model=self.model_name, task=task, event_handler=self._relay_event)
        except Exception as exc:
            payload = {
                "type": "runtime_error",
                "text": f"{exc}\n\n{traceback.format_exc()}".strip(),
            }
            self.call_from_thread(self._handle_stream_event, payload)

    def _relay_event(self, event: dict[str, object]) -> None:
        self.call_from_thread(self._handle_stream_event, event)

    def _handle_stream_event(self, event: dict[str, object]) -> None:
        event_type = str(event.get("type", ""))

        if event_type == "text_delta":
            self._stream_buffer += str(event.get("text", ""))
            self._update_stream()
            return

        if event_type == "service_call":
            self._flush_stream()
            call_text = str(event.get("text", "")).strip()
            m = re.search(r'name="([^"]+)"', call_text)
            svc_name = m.group(1) if m else "service"
            t = Text()
            t.append(f"  └ {svc_name}(...)\n", style="#404040")
            self._feed(t)
            return

        if event_type == "observation":
            obs_text = str(event.get("text", "")).strip()
            byte_count = len(obs_text.encode())
            t = Text()
            t.append(f"  · obs.client  {byte_count} b\n", style="#303030")
            self._feed(t)
            return

        if event_type == "awaiting_client_services":
            return

        if event_type == "response_complete":
            self._flush_stream()
            t = Text()
            t.append("  · done\n\n", style="#303030")
            self._feed(t)
            self._set_busy(False)
            self.query_one("#task-input", Input).focus()
            return

        if event_type == "runtime_error":
            message = str(event.get("text", "Unknown error"))
            self._flush_stream()
            t = Text()
            t.append(f"\n  ✗ {message}\n\n", style="#aaaaaa")
            self._feed(t)
            self._set_busy(False)
            self.query_one("#task-input", Input).focus()
            return

    def run_task_once_for_testing(self, task: str) -> None:
        self._run_task(build_task(task))


def main() -> None:
    SealApp().run()


if __name__ == "__main__":
    main()
