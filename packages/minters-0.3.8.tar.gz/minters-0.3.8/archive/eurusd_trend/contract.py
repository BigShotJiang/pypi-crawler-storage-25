"""EMA-crossover trend-following strategy on EURUSD 1-hour bars.

Algorithm
---------
1. Fetch the last ``slow + 10`` 1-hour candles for the configured symbol.
2. Compute a fast EMA (default 9) and slow EMA (default 21) over closes.
3. Signal:
     - BUY   when fast EMA crosses above slow EMA and no position is open.
     - CLOSE when fast EMA crosses below slow EMA and a position is open.

Environment variables (all optional)
-------------------------------------
MASTER_ACCOUNT_ID    Account to trade on (from .env)
CONTRACT_SYMBOL      Symbol to trade              (default: EURUSD)
CONTRACT_VOLUME      Lot size                     (default: 0.01)
CONTRACT_FAST_EMA    Fast EMA period              (default: 9)
CONTRACT_SLOW_EMA    Slow EMA period              (default: 21)
POLL_INTERVAL_SEC    Seconds between evaluations  (default: 60)
"""

import asyncio
import os
from typing import List, Optional

from harness import close_trade_position, get_historical_ohlc, market_buy


# ---------------------------------------------------------------------------
# EMA helper
# ---------------------------------------------------------------------------

def _ema(prices: List[float], period: int) -> Optional[float]:
    if len(prices) < period:
        return None
    k = 2.0 / (period + 1)
    val = sum(prices[:period]) / period
    for p in prices[period:]:
        val = p * k + val * (1 - k)
    return val


# ---------------------------------------------------------------------------
# Contract class
# ---------------------------------------------------------------------------

class EurusdTrendContract:
    symbol     = os.environ.get("CONTRACT_SYMBOL",   "EURUSD")
    volume     = float(os.environ.get("CONTRACT_VOLUME",  "0.01"))
    fast       = int(os.environ.get("CONTRACT_FAST_EMA",  "9"))
    slow       = int(os.environ.get("CONTRACT_SLOW_EMA",  "21"))
    poll_sec   = int(os.environ.get("POLL_INTERVAL_SEC",  "60"))
    account_id = os.environ.get("MASTER_ACCOUNT_ID")

    async def run(self) -> None:
        ticket: Optional[int] = None
        cycle = 0
        print(
            f"EurusdTrend  starting"
            f"  symbol={self.symbol}"
            f"  fast={self.fast}  slow={self.slow}"
            f"  volume={self.volume}  poll={self.poll_sec}s",
            flush=True,
        )
        while True:
            cycle += 1
            try:
                candles = await get_historical_ohlc(
                    self.symbol, "1h", self.slow + 10
                )
                closes  = [float(c.get("close", c.get("c", 0))) for c in candles]
                fast_v  = _ema(closes, self.fast)
                slow_v  = _ema(closes, self.slow)

                if fast_v is None or slow_v is None:
                    print(
                        f"EurusdTrend  cycle={cycle}  not enough data"
                        f"  bars={len(closes)}",
                        flush=True,
                    )
                else:
                    last   = closes[-1]
                    signal = "BUY" if fast_v > slow_v else "SELL" if fast_v < slow_v else "HOLD"
                    print(
                        f"EurusdTrend  cycle={cycle}"
                        f"  {self.symbol}  signal={signal}"
                        f"  fast={fast_v:.5f}  slow={slow_v:.5f}"
                        f"  last={last:.5f}  ticket={ticket}",
                        flush=True,
                    )

                    if signal == "BUY" and ticket is None:
                        result = await market_buy(
                            self.symbol, self.volume,
                            account_id=self.account_id,
                        )
                        ticket = (result or {}).get("order") or (result or {}).get("orderId")
                        print(f"EurusdTrend  BUY placed  ticket={ticket}", flush=True)

                    elif signal == "SELL" and ticket is not None:
                        await close_trade_position(ticket, account_id=self.account_id)
                        print(f"EurusdTrend  CLOSE  ticket={ticket}", flush=True)
                        ticket = None

            except Exception as exc:
                print(f"EurusdTrend  cycle={cycle}  error={exc}", flush=True)

            await asyncio.sleep(self.poll_sec)
