"""WTI Crude Oil (USOIL) strategy — stub.

Implement your logic here.  The only requirement is a class named
``UsoilContract`` with an ``async def run`` method containing your loop.

Environment variables (all optional)
-------------------------------------
CONTRACT_SYMBOL      Symbol to watch   (default: USOIL)
POLL_INTERVAL_SEC    Seconds between ticks (default: 60)
"""

import asyncio
import os

from harness import get_current_price


class UsoilContract:
    symbol   = os.environ.get("CONTRACT_SYMBOL",   "USOIL")
    poll_sec = int(os.environ.get("POLL_INTERVAL_SEC", "60"))

    async def run(self) -> None:
        cycle = 0
        print(f"Usoil  starting  symbol={self.symbol}  poll={self.poll_sec}s", flush=True)
        while True:
            cycle += 1
            try:
                price = await get_current_price(self.symbol)
                bid   = price.get("bid")
                ask   = price.get("ask")
                print(f"Usoil  cycle={cycle}  bid={bid}  ask={ask}", flush=True)
            except Exception as exc:
                print(f"Usoil  cycle={cycle}  error={exc}", flush=True)
            await asyncio.sleep(self.poll_sec)
