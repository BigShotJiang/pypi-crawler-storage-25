"""
USOIL (WTI Crude Oil) contract — Capital.com backend
======================================================
Strategy:  EMA-20 / EMA-50 crossover filtered by RSI-14 and client sentiment.
           Trailing stop tightens once price moves 1R in favour.

Environment variables (all optional, sensible defaults):
  USOIL_LOT_SIZE    float  0.5   Position size in barrels (lots)
  USOIL_SL_PIPS     float  100   Stop-loss distance in points (0.001 per point)
  USOIL_TP_PIPS     float  200   Take-profit distance in points
  USOIL_TRAIL_PIPS  float  60    Trailing-stop activation distance in points
  USOIL_RISK_MAX    float  2.0   Max % of account equity risked per trade
  USOIL_POLL_SECS   int    60    Main loop interval (seconds)
  DRY_RUN           bool   false Log signals but never send orders
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any

import numpy as np
from dotenv import find_dotenv, load_dotenv

from harness import capital

load_dotenv(find_dotenv())

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("usoil")

# ── Capital.com epic ──────────────────────────────────────────────────────────
EPIC = "OIL_CRUDE"

# ── Indicator helpers ─────────────────────────────────────────────────────────

def _ema(prices: np.ndarray, period: int) -> np.ndarray:
    """Exponential moving average — returns full array."""
    out = np.empty_like(prices)
    out[0] = prices[0]
    k = 2.0 / (period + 1)
    for i in range(1, len(prices)):
        out[i] = prices[i] * k + out[i - 1] * (1 - k)
    return out


def _rsi(prices: np.ndarray, period: int = 14) -> float:
    """Wilder RSI — returns latest value."""
    deltas = np.diff(prices)
    gains = np.where(deltas > 0, deltas, 0.0)
    losses = np.where(deltas < 0, -deltas, 0.0)

    avg_gain = gains[:period].mean()
    avg_loss = losses[:period].mean()

    for g, l in zip(gains[period:], losses[period:]):
        avg_gain = (avg_gain * (period - 1) + g) / period
        avg_loss = (avg_loss * (period - 1) + l) / period

    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - 100.0 / (1.0 + rs)


# ── Contract ──────────────────────────────────────────────────────────────────

class UsoilContract:
    """WTI Crude Oil momentum contract on Capital.com."""

    symbol: str = EPIC
    timeframe: str = "HOUR"
    ema_fast: int = 20
    ema_slow: int = 50
    rsi_period: int = 14
    candles_needed: int = 200  # warm-up window

    lot_size: float = float(os.getenv("USOIL_LOT_SIZE", "0.5"))
    sl_points: float = float(os.getenv("USOIL_SL_PIPS", "100"))
    tp_points: float = float(os.getenv("USOIL_TP_PIPS", "200"))
    trail_points: float = float(os.getenv("USOIL_TRAIL_PIPS", "60"))
    risk_max_pct: float = float(os.getenv("USOIL_RISK_MAX", "2.0"))
    poll_secs: int = int(os.getenv("USOIL_POLL_SECS", "60"))
    dry_run: bool = os.getenv("DRY_RUN", "false").lower() in ("1", "true", "yes")

    # ── Internal state ────────────────────────────────────────────────────────

    _last_signal: str = "NONE"   # "BUY" | "SELL" | "NONE"

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    async def run(self) -> None:
        if self.dry_run:
            log.warning("DRY RUN — no orders will be placed")

        log.info("USOIL contract starting  (epic=%s  lot=%.2f)", self.symbol, self.lot_size)

        while True:
            try:
                await self._cycle()
            except asyncio.CancelledError:
                log.info("Contract cancelled — exiting")
                break
            except Exception as exc:  # noqa: BLE001
                log.exception("Unhandled error in cycle: %s", exc)

            await asyncio.sleep(self.poll_secs)

    # ── Main cycle ────────────────────────────────────────────────────────────

    async def _cycle(self) -> None:
        # 1. Fetch data concurrently
        candles_task = asyncio.create_task(
            capital.get_historical_ohlc(self.symbol, self.timeframe, self.candles_needed)
        )
        price_task = asyncio.create_task(capital.get_current_price(self.symbol))
        account_task = asyncio.create_task(capital.get_account_snapshot())
        sentiment_task = asyncio.create_task(capital.get_client_sentiment(self.symbol))
        positions_task = asyncio.create_task(capital.get_positions())

        candles, price_data, account, sentiment, positions = await asyncio.gather(
            candles_task, price_task, account_task, sentiment_task, positions_task
        )

        if not candles:
            log.warning("No candle data — skipping cycle")
            return

        # 2. Indicators
        closes = np.array([float(c["close"]) for c in candles], dtype=np.float64)
        ema_fast_arr = _ema(closes, self.ema_fast)
        ema_slow_arr = _ema(closes, self.ema_slow)
        rsi_val = _rsi(closes, self.rsi_period)

        ema_f = ema_fast_arr[-1]
        ema_s = ema_slow_arr[-1]
        ema_f_prev = ema_fast_arr[-2]
        ema_s_prev = ema_slow_arr[-2]

        # 3. Price
        bid = float(price_data.get("bid", closes[-1]))
        ask = float(price_data.get("offer", price_data.get("ask", closes[-1])))
        mid = (bid + ask) / 2

        # 4. Account equity check
        balance = float(account.get("balance", 0))
        equity = float(account.get("equity", balance))
        risk_budget = equity * self.risk_max_pct / 100

        log.info(
            "Price %.3f  RSI %.1f  EMA(%d) %.3f  EMA(%d) %.3f  equity %.2f",
            mid, rsi_val, self.ema_fast, ema_f, self.ema_slow, ema_s, equity,
        )

        # 5. Client sentiment (long % vs short %)
        long_pct = float(sentiment.get("longPositionPercentage", 50)) if sentiment else 50.0

        # 6. Current open positions for this symbol
        open_pos = [
            p for p in (positions if isinstance(positions, list) else [])
            if str(p.get("epic", p.get("symbol", ""))).upper() == self.symbol.upper()
        ]

        # 7. Manage existing positions (trailing stop)
        for pos in open_pos:
            await self._manage_position(pos, mid)

        # 8. Signal detection (EMA crossover + RSI filter + sentiment)
        bullish_cross = ema_f_prev < ema_s_prev and ema_f >= ema_s
        bearish_cross = ema_f_prev > ema_s_prev and ema_f <= ema_s

        signal = "NONE"
        if bullish_cross and rsi_val < 70 and long_pct < 75:
            signal = "BUY"
        elif bearish_cross and rsi_val > 30 and long_pct > 25:
            signal = "SELL"

        log.info(
            "Signal: %s  (prev=%s  cross_bull=%s  cross_bear=%s  open_pos=%d)",
            signal, self._last_signal, bullish_cross, bearish_cross, len(open_pos),
        )

        # 9. Execute entry only when no open position and signal changed
        if signal != "NONE" and signal != self._last_signal and len(open_pos) == 0:
            # Risk-size the lot
            lot = self._calc_lot(risk_budget, self.sl_points, mid)
            await self._enter(signal, lot, mid, ask, bid)

        self._last_signal = signal

        # 10. Emergency exit: if RSI extreme and in wrong direction
        if open_pos:
            direction = open_pos[0].get("direction", "BUY")
            if direction == "BUY" and rsi_val > 80:
                log.warning("RSI extreme overbought (%.1f) — closing USOIL longs", rsi_val)
                await self._close_all("RSI overbought exit")
            elif direction == "SELL" and rsi_val < 20:
                log.warning("RSI extreme oversold (%.1f) — closing USOIL shorts", rsi_val)
                await self._close_all("RSI oversold exit")

    # ── Position management ───────────────────────────────────────────────────

    async def _manage_position(self, pos: dict[str, Any], current_price: float) -> None:
        """Tighten stop once 1R of profit is achieved."""
        deal_id = pos.get("dealId", pos.get("id", ""))
        direction = pos.get("direction", "BUY")
        open_price = float(pos.get("openLevel", pos.get("open_price", current_price)))
        current_sl = pos.get("stopLevel", pos.get("stop_loss"))
        if current_sl is None:
            return
        current_sl = float(current_sl)

        if direction == "BUY":
            profit_points = current_price - open_price
            if profit_points >= self.sl_points:
                # Trail: move SL to break-even + trail_points below current
                new_sl = round(current_price - self.trail_points * 0.001, 3)
                if new_sl > current_sl + 0.001:
                    log.info("Trailing stop BUY deal=%s  old_sl=%.3f  new_sl=%.3f", deal_id, current_sl, new_sl)
                    if not self.dry_run:
                        await capital.modify_position(deal_id, stop_loss=new_sl)
        else:  # SELL
            profit_points = open_price - current_price
            if profit_points >= self.sl_points:
                new_sl = round(current_price + self.trail_points * 0.001, 3)
                if new_sl < current_sl - 0.001:
                    log.info("Trailing stop SELL deal=%s  old_sl=%.3f  new_sl=%.3f", deal_id, current_sl, new_sl)
                    if not self.dry_run:
                        await capital.modify_position(deal_id, stop_loss=new_sl)

    async def _enter(
        self, signal: str, lot: float, mid: float, ask: float, bid: float
    ) -> None:
        if signal == "BUY":
            sl = round(ask - self.sl_points * 0.001, 3)
            tp = round(ask + self.tp_points * 0.001, 3)
            log.info("ENTRY BUY  epic=%s  lot=%.2f  ask=%.3f  sl=%.3f  tp=%.3f", self.symbol, lot, ask, sl, tp)
            if not self.dry_run:
                result = await capital.market_buy(self.symbol, lot, stop_loss=sl, take_profit=tp)
                log.info("Order result: %s", result)
        else:  # SELL
            sl = round(bid + self.sl_points * 0.001, 3)
            tp = round(bid - self.tp_points * 0.001, 3)
            log.info("ENTRY SELL  epic=%s  lot=%.2f  bid=%.3f  sl=%.3f  tp=%.3f", self.symbol, lot, bid, sl, tp)
            if not self.dry_run:
                result = await capital.market_sell(self.symbol, lot, stop_loss=sl, take_profit=tp)
                log.info("Order result: %s", result)

    async def _close_all(self, reason: str) -> None:
        log.info("Close all %s — reason: %s", self.symbol, reason)
        if not self.dry_run:
            await capital.close_all_by_symbol(self.symbol)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _calc_lot(self, risk_budget: float, sl_points: float, price: float) -> float:
        """
        Size lots so that sl_points * lot_value ≈ risk_budget.
        1 lot of OIL_CRUDE = 100 barrels.  Point value ≈ price * 0.001 per lot.
        Falls back to self.lot_size if risk_budget or price unavailable.
        """
        try:
            point_value = price * 0.001 * 100  # approximate USD per point per lot
            if point_value <= 0:
                return self.lot_size
            lot = risk_budget / (sl_points * point_value)
            lot = max(0.01, min(lot, 50.0))  # clamp to exchange limits
            lot = round(lot, 2)
            return lot
        except Exception:  # noqa: BLE001
            return self.lot_size


# ── Entrypoint ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    asyncio.run(UsoilContract().run())
