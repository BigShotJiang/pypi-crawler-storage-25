"""
harness/testsuite/test_farm_ext_client.py
===========================================
Unit tests for FarmExtClient — the MetaAPI cloud SDK wrapper.
All calls to the MetaAPI SDK are mocked at class level so no token or
network is needed.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

import pytest

from .conftest import (
    FAKE_ACCOUNT_ID,
    FAKE_ACCOUNT_INFO,
    FAKE_POSITION,
    FAKE_ORDER,
    FAKE_DEAL,
    FAKE_CANDLE,
    FAKE_TICK,
    FAKE_SYMBOLS,
    FAKE_SERVER_TIME,
    FAKE_MARGIN,
    FAKE_BOOK,
    FAKE_SYMBOL_INFO,
)

# ---------------------------------------------------------------------------
# Skip all tests if metaapi-cloud-sdk is not installed
# ---------------------------------------------------------------------------
pytest.importorskip("metaapi_cloud_sdk", reason="metaapi-cloud-sdk not installed")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_ext_client(account_id=FAKE_ACCOUNT_ID):
    """Build a FarmExtClient with mocked MetaAPI internals."""
    from harness.barn.core.farm_ext_client import FarmExtClient

    client = FarmExtClient.__new__(FarmExtClient)
    client._account_id = account_id
    client._user = None

    # Fake terminal state (streaming) — mirrors what MetaAPI exposes on
    # StreamingMetaApiConnection.terminal_state
    ts = MagicMock()
    ts.account_information = FAKE_ACCOUNT_INFO
    ts.positions            = [FAKE_POSITION]
    ts.orders               = [FAKE_ORDER]
    ts.price                = MagicMock(return_value=FAKE_TICK)
    ts.get_price            = MagicMock(return_value=FAKE_TICK)
    ts.specifications       = [FAKE_SYMBOL_INFO]   # for get_symbols() streaming path
    ts.specification        = MagicMock(return_value=None)  # force RPC for get_symbol_info

    # Fake streaming connection — all awaited methods need AsyncMock
    stream_conn = MagicMock()
    stream_conn.terminal_state               = ts
    stream_conn.create_market_buy_order      = AsyncMock(return_value={"orderId": "trade-001"})
    stream_conn.create_market_sell_order     = AsyncMock(return_value={"orderId": "trade-002"})
    stream_conn.create_limit_buy_order       = AsyncMock(return_value={"orderId": "trade-003"})
    stream_conn.create_limit_sell_order      = AsyncMock(return_value={"orderId": "trade-004"})
    stream_conn.create_stop_buy_order        = AsyncMock(return_value={"orderId": "trade-005"})
    stream_conn.create_stop_sell_order       = AsyncMock(return_value={"orderId": "trade-006"})
    stream_conn.create_stop_limit_buy_order  = AsyncMock(return_value={"orderId": "trade-007"})
    stream_conn.create_stop_limit_sell_order = AsyncMock(return_value={"orderId": "trade-008"})
    stream_conn.modify_position              = AsyncMock(return_value={"orderId": "trade-009"})
    stream_conn.close_position               = AsyncMock(return_value={"orderId": "trade-010"})
    stream_conn.close_position_partially     = AsyncMock(return_value={"orderId": "trade-011"})
    stream_conn.close_by                     = AsyncMock(return_value={"orderId": "trade-012"})
    stream_conn.modify_order                 = AsyncMock(return_value={"orderId": "trade-013"})
    stream_conn.cancel_order                 = AsyncMock(return_value={"orderId": "trade-014"})
    stream_conn.subscribe_to_market_data     = AsyncMock(return_value=None)
    stream_conn.unsubscribe_from_market_data = AsyncMock(return_value=None)
    client._stream_conn = stream_conn
    client._ts_obj      = ts   # kept for any direct references

    # Fake history storage
    hs = MagicMock()
    hs.deals_by_ticket               = MagicMock(return_value=[FAKE_DEAL])
    hs.deals_by_position             = MagicMock(return_value=[FAKE_DEAL])
    hs.deals_by_time_range           = AsyncMock(return_value=[FAKE_DEAL])
    hs.history_orders_by_ticket      = MagicMock(return_value=[FAKE_ORDER])
    hs.history_orders_by_position    = MagicMock(return_value=[FAKE_ORDER])
    hs.history_orders_by_time_range  = AsyncMock(return_value=[FAKE_ORDER])
    client._hs_obj = hs

    # Fake _account object — used by get_historical_candles / get_historical_ticks
    account = MagicMock()
    account.get_historical_candles = AsyncMock(return_value=[FAKE_CANDLE] * 10)
    account.get_historical_ticks   = AsyncMock(return_value=[FAKE_TICK] * 10)
    client._account = account

    # Fake RPC connection (historical queries, margin, symbol info)
    rpc = MagicMock()
    rpc.get_account_information          = AsyncMock(return_value=FAKE_ACCOUNT_INFO)
    rpc.get_positions                    = AsyncMock(return_value=[FAKE_POSITION])
    rpc.get_pending_orders               = AsyncMock(return_value=[FAKE_ORDER])
    rpc.get_symbols                      = AsyncMock(return_value=FAKE_SYMBOLS)
    rpc.get_symbol_specification         = AsyncMock(return_value=FAKE_SYMBOL_INFO)
    rpc.get_symbol_price                 = AsyncMock(return_value=FAKE_TICK)
    rpc.get_historical_candles           = AsyncMock(return_value=[FAKE_CANDLE] * 10)
    rpc.get_historical_ticks             = AsyncMock(return_value=[FAKE_TICK] * 10)
    rpc.get_server_time                  = AsyncMock(return_value=FAKE_SERVER_TIME)
    rpc.calculate_margin                 = AsyncMock(return_value=FAKE_MARGIN)
    rpc.subscribe_to_market_data         = AsyncMock(return_value=None)
    rpc.unsubscribe_from_market_data     = AsyncMock(return_value=None)
    client._rpc_conn = rpc

    return client


# ---------------------------------------------------------------------------
# Account
# ---------------------------------------------------------------------------

class TestFarmExtClientAccount:
    @pytest.mark.asyncio
    async def test_get_account_information(self):
        c = _make_ext_client()
        result = await c.get_account_information()
        assert result["balance"] == FAKE_ACCOUNT_INFO["balance"]

    @pytest.mark.asyncio
    async def test_get_account_info_alias(self):
        c = _make_ext_client()
        result = await c.get_account_info()
        assert result["login"] == FAKE_ACCOUNT_INFO["login"]


# ---------------------------------------------------------------------------
# Market data
# ---------------------------------------------------------------------------

class TestFarmExtClientMarketData:
    @pytest.mark.asyncio
    async def test_get_symbols(self):
        c = _make_ext_client()
        symbols = await c.get_symbols()
        assert "EURUSD" in symbols

    @pytest.mark.asyncio
    async def test_get_symbol_info(self):
        c = _make_ext_client()
        info = await c.get_symbol_info("EURUSD")
        assert info["symbol"] == "EURUSD"

    @pytest.mark.asyncio
    async def test_get_current_price(self):
        c = _make_ext_client()
        tick = await c.get_current_price("EURUSD")
        assert "bid" in tick or "ask" in tick

    @pytest.mark.asyncio
    async def test_get_server_time(self):
        c = _make_ext_client()
        t = await c.get_server_time()
        assert t is not None

    @pytest.mark.asyncio
    async def test_calculate_margin(self):
        c = _make_ext_client()
        margin = await c.calculate_margin({"symbol": "EURUSD", "type": "buy", "volume": 0.1})
        assert "margin" in margin

    @pytest.mark.asyncio
    async def test_get_historical_candles(self):
        c = _make_ext_client()
        candles = await c.get_historical_candles("EURUSD", "1h", 10)
        assert isinstance(candles, list)

    @pytest.mark.asyncio
    async def test_get_historical_ticks(self):
        c = _make_ext_client()
        ticks = await c.get_historical_ticks("EURUSD", None, 0, 10)
        assert isinstance(ticks, list)


# ---------------------------------------------------------------------------
# Trade execution
# ---------------------------------------------------------------------------

class TestFarmExtClientTrades:
    @pytest.mark.asyncio
    async def test_market_buy(self):
        c = _make_ext_client()
        result = await c.market_buy("EURUSD", 0.1)
        assert result is not None

    @pytest.mark.asyncio
    async def test_market_sell(self):
        c = _make_ext_client()
        result = await c.market_sell("EURUSD", 0.1)
        assert result is not None

    @pytest.mark.asyncio
    async def test_buy_limit(self):
        c = _make_ext_client()
        result = await c.buy_limit("EURUSD", 0.1, 1.095)
        assert result is not None

    @pytest.mark.asyncio
    async def test_sell_limit(self):
        c = _make_ext_client()
        result = await c.sell_limit("EURUSD", 0.1, 1.105)
        assert result is not None

    @pytest.mark.asyncio
    async def test_buy_stop(self):
        c = _make_ext_client()
        result = await c.buy_stop("EURUSD", 0.1, 1.105)
        assert result is not None

    @pytest.mark.asyncio
    async def test_sell_stop(self):
        c = _make_ext_client()
        result = await c.sell_stop("EURUSD", 0.1, 1.095)
        assert result is not None

    @pytest.mark.asyncio
    async def test_buy_stop_limit(self):
        c = _make_ext_client()
        result = await c.buy_stop_limit("EURUSD", 0.1, 1.105, 1.103)
        assert result is not None

    @pytest.mark.asyncio
    async def test_sell_stop_limit(self):
        c = _make_ext_client()
        result = await c.sell_stop_limit("EURUSD", 0.1, 1.095, 1.097)
        assert result is not None

    @pytest.mark.asyncio
    async def test_modify_position(self):
        c = _make_ext_client()
        result = await c.modify_position("pos-001", 1.09, 1.11)
        assert result is not None

    @pytest.mark.asyncio
    async def test_close_position(self):
        c = _make_ext_client()
        result = await c.close_position("pos-001")
        assert result is not None

    @pytest.mark.asyncio
    async def test_cancel_order(self):
        c = _make_ext_client()
        result = await c.cancel_order("ord-001")
        assert result is not None


# ---------------------------------------------------------------------------
# History
# ---------------------------------------------------------------------------

class TestFarmExtClientHistory:
    @pytest.mark.asyncio
    async def test_get_deals_by_ticket(self):
        c = _make_ext_client()
        deals = await c.get_deals_by_ticket("deal-001")
        assert isinstance(deals, list)

    @pytest.mark.asyncio
    async def test_get_deals_by_position(self):
        c = _make_ext_client()
        deals = await c.get_deals_by_position("pos-001")
        assert isinstance(deals, list)

    @pytest.mark.asyncio
    async def test_get_history_orders_by_ticket(self):
        c = _make_ext_client()
        orders = await c.get_history_orders_by_ticket("ord-001")
        assert isinstance(orders, list)

    @pytest.mark.asyncio
    async def test_get_history_orders_by_position(self):
        c = _make_ext_client()
        orders = await c.get_history_orders_by_position("pos-001")
        assert isinstance(orders, list)
