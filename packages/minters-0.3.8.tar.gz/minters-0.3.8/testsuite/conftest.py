"""
harness/testsuite/conftest.py
==============================
Shared pytest fixtures for the harness test suite.

- Fake account / user context
- Mock FarmClient (in-memory, no HTTP)
- Mock FarmExtClient (in-memory, no MetaAPI SDK)
- Environment variable helpers
- respx router for HTTP-level farm mocking
"""
from __future__ import annotations

import asyncio
import contextlib
import os
from contextlib import contextmanager, ExitStack
from typing import Any, AsyncGenerator, Dict, Optional
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio

# ---------------------------------------------------------------------------
# Async event-loop fixture (pytest-asyncio >= 0.21 mode)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def event_loop_policy():
    return asyncio.DefaultEventLoopPolicy()


# ---------------------------------------------------------------------------
# patch_get_client — patches all namespaces where get_client is bound
# ---------------------------------------------------------------------------

# When harness/__init__.py does `from .core import get_client`, Python binds
# the name in the harness module's own globals.  Patching only
# harness.core.dispatcher.get_client does NOT intercept those calls.
# We must patch every namespace that has imported the name.

_GET_CLIENT_TARGETS = [
    "harness.get_client",
    "harness.core.dispatcher.get_client",
    "harness.account.creds.get_client",
    "harness.account.positions.get_client",
    "harness.account.history.get_client",
    "harness.data.quotes.get_client",
]

@contextmanager
def patch_get_client(mock_client):
    """
    Context manager: replace get_client() in every module that imported it,
    so no test accidentally hits the real farm.
    """
    mock = AsyncMock(return_value=mock_client)
    with ExitStack() as stack:
        for target in _GET_CLIENT_TARGETS:
            try:
                stack.enter_context(patch(target, new=mock))
            except AttributeError:
                pass  # module not yet imported — skip
        yield mock


# ---------------------------------------------------------------------------
# Fake account context
# ---------------------------------------------------------------------------

FAKE_ACCOUNT_ID = "test-account-001"
FAKE_USER = {"id": "test-user-001", "email": "test@example.com"}

@pytest.fixture
def fake_account_id() -> str:
    return FAKE_ACCOUNT_ID

@pytest.fixture
def fake_user() -> Dict:
    return dict(FAKE_USER)


# ---------------------------------------------------------------------------
# Canonical fake data
# ---------------------------------------------------------------------------

FAKE_ACCOUNT_INFO = {
    "login": 12345678,
    "server": "Broker-MT5Live",
    "broker": "Broker",
    "currency": "USD",
    "leverage": 100,
    "balance": 10_000.0,
    "equity": 10_250.0,
    "margin": 500.0,
    "free_margin": 9_750.0,
    "margin_level": 2050.0,
    "trade_allowed": True,
    "timestamp": "2024-01-01T00:00:00Z",
}

FAKE_POSITION = {
    "id": "pos-001",
    "symbol": "EURUSD",
    "type": "buy",
    "volume": 0.1,
    "open_price": 1.10000,
    "stop_loss": 1.09000,
    "take_profit": 1.11000,
    "profit": 25.0,
    "swap": -0.5,
    "time": "2024-01-01T10:00:00Z",
    "comment": "",
}

FAKE_ORDER = {
    "id": "ord-001",
    "symbol": "EURUSD",
    "type": "buy_limit",
    "volume": 0.1,
    "open_price": 1.09500,
    "stop_loss": 1.09000,
    "take_profit": 1.10500,
    "time": "2024-01-01T09:00:00Z",
    "comment": "",
}

FAKE_DEAL = {
    "id": "deal-001",
    "symbol": "EURUSD",
    "type": "buy",
    "volume": 0.1,
    "price": 1.10000,
    "profit": 0.0,
    "commission": -0.1,
    "swap": 0.0,
    "time": "2024-01-01T10:00:00Z",
    "comment": "",
}

FAKE_CANDLE = {
    "symbol": "EURUSD",
    "timeframe": "1h",
    "time": "2024-01-01T10:00:00Z",
    "open": 1.10000,
    "high": 1.10200,
    "low": 1.09900,
    "close": 1.10100,
    "volume": 1234,
}

FAKE_TICK = {
    "symbol": "EURUSD",
    "bid": 1.10050,
    "ask": 1.10060,
    "time": "2024-01-01T10:00:01Z",
}

FAKE_SYMBOLS = ["EURUSD", "GBPUSD", "USDJPY", "XAUUSD", "USOIL"]

FAKE_SERVER_TIME = {
    "broker_time": "2024-01-01T10:00:00",
    "broker_timestamp": 1704067200,
}

FAKE_MARGIN = {
    "margin": 110.0,
    "currency": "USD",
}

FAKE_BOOK = {
    "symbol": "EURUSD",
    "bids": [{"price": 1.10040, "volume": 10.0}],
    "asks": [{"price": 1.10060, "volume": 10.0}],
}

FAKE_SYMBOL_INFO = {
    "symbol": "EURUSD",
    "description": "Euro vs US Dollar",
    "point": 0.00001,
    "digits": 5,
    "min_lot": 0.01,
    "max_lot": 100.0,
    "lot_step": 0.01,
    "contract_size": 100_000,
    "currency_base": "EUR",
    "currency_profit": "USD",
    "currency_margin": "USD",
    "spread": 10,
    "trade_allowed": True,
}

# ---------------------------------------------------------------------------
# Mock FarmClient
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_farm_client() -> MagicMock:
    """
    Return an in-memory mock that satisfies the FarmClient interface.
    All async methods return sensible fake data.
    """
    client = MagicMock()

    # Account
    client.get_account_information = AsyncMock(return_value=FAKE_ACCOUNT_INFO)
    client.get_account_info        = AsyncMock(return_value=FAKE_ACCOUNT_INFO)

    # Positions
    client.get_positions   = AsyncMock(return_value=[FAKE_POSITION])
    client.get_position    = AsyncMock(return_value=FAKE_POSITION)

    # Pending orders
    client.get_pending_orders = AsyncMock(return_value=[FAKE_ORDER])
    client.get_order          = AsyncMock(return_value=FAKE_ORDER)

    # History orders
    client.get_history_orders_by_ticket     = AsyncMock(return_value=[FAKE_ORDER])
    client.get_history_orders_by_position   = AsyncMock(return_value=[FAKE_ORDER])
    client.get_history_orders_by_time_range = AsyncMock(return_value=[FAKE_ORDER])

    # Deals
    client.get_deals_by_ticket     = AsyncMock(return_value=[FAKE_DEAL])
    client.get_deals_by_position   = AsyncMock(return_value=[FAKE_DEAL])
    client.get_deals_by_time_range = AsyncMock(return_value=[FAKE_DEAL])
    client.get_deal_history        = AsyncMock(return_value=[FAKE_DEAL])

    # Symbols / prices
    client.get_symbols            = AsyncMock(return_value=FAKE_SYMBOLS)
    client.get_symbol_info        = AsyncMock(return_value=FAKE_SYMBOL_INFO)
    client.get_symbol_specification = AsyncMock(return_value=FAKE_SYMBOL_INFO)
    client.get_current_price      = AsyncMock(return_value=FAKE_TICK)
    client.get_symbol_price       = AsyncMock(return_value=FAKE_TICK)
    client.read_candle            = AsyncMock(return_value=FAKE_CANDLE)
    client.read_tick              = AsyncMock(return_value=FAKE_TICK)
    client.read_book              = AsyncMock(return_value=FAKE_BOOK)
    client.get_server_time        = AsyncMock(return_value=FAKE_SERVER_TIME)
    client.calculate_margin       = AsyncMock(return_value=FAKE_MARGIN)
    client.get_historical_candles = AsyncMock(return_value=[FAKE_CANDLE] * 10)
    client.get_history            = AsyncMock(return_value=[FAKE_CANDLE] * 10)
    client.get_historical_ticks   = AsyncMock(return_value=[FAKE_TICK] * 10)
    client.subscribe_to_market_data   = AsyncMock(return_value=None)
    client.unsubscribe_from_market_data = AsyncMock(return_value=None)

    # Trade execution
    _trade_result = {"orderId": "trade-001", "numericCode": 10009, "message": "Request completed"}
    client.market_buy  = AsyncMock(return_value=_trade_result)
    client.market_sell = AsyncMock(return_value=_trade_result)
    client.create_market_buy_order  = AsyncMock(return_value=_trade_result)
    client.create_market_sell_order = AsyncMock(return_value=_trade_result)
    client.buy_limit   = AsyncMock(return_value=_trade_result)
    client.sell_limit  = AsyncMock(return_value=_trade_result)
    client.buy_stop    = AsyncMock(return_value=_trade_result)
    client.sell_stop   = AsyncMock(return_value=_trade_result)
    client.buy_stop_limit  = AsyncMock(return_value=_trade_result)
    client.sell_stop_limit = AsyncMock(return_value=_trade_result)
    client.create_limit_buy_order  = AsyncMock(return_value=_trade_result)
    client.create_limit_sell_order = AsyncMock(return_value=_trade_result)
    client.create_stop_buy_order   = AsyncMock(return_value=_trade_result)
    client.create_stop_sell_order  = AsyncMock(return_value=_trade_result)
    client.create_stop_limit_buy_order  = AsyncMock(return_value=_trade_result)
    client.create_stop_limit_sell_order = AsyncMock(return_value=_trade_result)
    client.modify_position    = AsyncMock(return_value=_trade_result)
    client.close_position     = AsyncMock(return_value=_trade_result)
    client.close_position_partial = AsyncMock(return_value=_trade_result)
    client.close_position_by      = AsyncMock(return_value=_trade_result)
    client.close_all_positions_by_symbol = AsyncMock(return_value={"closed": 1})
    client.modify_order  = AsyncMock(return_value=_trade_result)
    client.cancel_order  = AsyncMock(return_value=_trade_result)

    # Status / health
    client.get_status    = MagicMock(return_value={"connected": True, "mode": "farm"})
    client.close         = AsyncMock(return_value=None)

    return client


# ---------------------------------------------------------------------------
# Env-var helpers
# ---------------------------------------------------------------------------

@pytest.fixture
def farm_mode(monkeypatch):
    """Force BROKER_MODE=farm for the duration of the test."""
    monkeypatch.setenv("BROKER_MODE", "farm")
    monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
    yield "farm"


@pytest.fixture
def farm_ext_mode(monkeypatch):
    """Force BROKER_MODE=farm_ext for the duration of the test."""
    monkeypatch.setenv("BROKER_MODE", "farm_ext")
    monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
    yield "farm_ext"


@pytest.fixture
def auto_mode(monkeypatch):
    """Force BROKER_MODE=auto for the duration of the test."""
    monkeypatch.setenv("BROKER_MODE", "auto")
    monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
    yield "auto"


@pytest.fixture
def farm_ext_enabled_true(monkeypatch):
    """Set FARM_EXT_ENABLED=true."""
    monkeypatch.setenv("FARM_EXT_ENABLED", "true")
    yield


@pytest.fixture
def farm_ext_enabled_false(monkeypatch):
    """Set FARM_EXT_ENABLED=false."""
    monkeypatch.setenv("FARM_EXT_ENABLED", "false")
    yield
