from __future__ import annotations

from pathlib import Path

from minters.workspace import bootstrap_workspace, looks_like_workspace, resolve_workspace_root


def test_bootstrap_workspace_copies_runtime_tree(tmp_path: Path) -> None:
    workspace_root, created = bootstrap_workspace(tmp_path / "workspace")

    assert created is True
    assert looks_like_workspace(workspace_root)
    assert (workspace_root / "harness" / "_runner.py").exists()
    assert (workspace_root / "farm" / "main.py").exists()
    assert (workspace_root / "regulator" / "seal.py").exists()
    assert (workspace_root / "minters" / "cli.py").exists()
    assert (workspace_root / "contracts" / "gold" / "contract.py").exists()
    assert (workspace_root / "README.md").exists()
    assert not (workspace_root / "harness" / "capital" / "target").exists()


def test_resolve_workspace_root_prefers_current_workspace(tmp_path: Path, monkeypatch) -> None:
    for name in ("contracts", "harness", "regulator"):
        (tmp_path / name).mkdir()

    monkeypatch.chdir(tmp_path)

    assert resolve_workspace_root(create=False) == tmp_path.resolve()


def test_resolve_workspace_root_bootstraps_env_target(tmp_path: Path, monkeypatch) -> None:
    target = tmp_path / "custom-workspace"
    monkeypatch.setenv("MINTERS_WORKSPACE", str(target))

    resolved = resolve_workspace_root()

    assert resolved == target.resolve()
    assert looks_like_workspace(resolved)