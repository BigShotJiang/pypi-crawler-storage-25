﻿"""
testsuite/test_bundler.py
==========================
Tests for harness.bundler — contract discovery, worker lifecycle, and the
telemetry bus integration.

All tests are fully offline: a temporary directory is used as the contracts
dir and a tiny stub class acts as the "contract" so no real farm connection
is needed.
"""
from __future__ import annotations

import ast
import json
import sys
import textwrap
import time
from pathlib import Path

import pytest

from harness.telemetry import TelemetryBus, get_bus


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_tmp_contract(tmp_path: Path, folder: str, script: str) -> tuple[Path, str]:
    """
    Create ``tmp_path/<folder>/contract.py`` from *script*, detect the
    ``*Contract`` class name via AST, and return ``(Path, class_name)``.
    """
    d = tmp_path / folder
    d.mkdir(parents=True)
    p = d / "contract.py"
    p.write_text(textwrap.dedent(script))
    tree = ast.parse(textwrap.dedent(script))
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name.endswith("Contract"):
            return p, node.name
    return p, "UnknownContract"


# ---------------------------------------------------------------------------
# TelemetryBus unit tests
# ---------------------------------------------------------------------------

class TestTelemetryBus:
    def test_push_and_snapshot(self):
        bus = TelemetryBus(maxlen=10)
        bus.push({"contract": "x", "level": "INFO", "message": "hello"})
        snap = bus.snapshot()
        assert len(snap) == 1
        assert snap[0]["message"] == "hello"

    def test_snapshot_is_copy(self):
        bus = TelemetryBus()
        bus.push({"message": "a"})
        s1 = bus.snapshot()
        bus.push({"message": "b"})
        s2 = bus.snapshot()
        assert len(s1) == 1
        assert len(s2) == 2

    def test_ring_buffer_maxlen(self):
        bus = TelemetryBus(maxlen=5)
        for i in range(10):
            bus.push({"n": i})
        snap = bus.snapshot()
        assert len(snap) == 5
        assert snap[0]["n"] == 5  # oldest kept entry

    def test_push_line_plain_text(self):
        bus = TelemetryBus()
        bus.push_line("mycontract", "hello world\n")
        snap = bus.snapshot()
        assert snap[0]["contract"] == "mycontract"
        assert snap[0]["message"]  == "hello world"
        assert snap[0]["data"]     is None

    def test_push_line_json(self):
        bus = TelemetryBus()
        payload = json.dumps({"level": "WARNING", "message": "oops", "cycle": 3})
        bus.push_line("mycontract", payload + "\n")
        snap = bus.snapshot()
        assert snap[0]["level"]   == "WARNING"
        assert snap[0]["message"] == "oops"
        assert snap[0]["data"]["cycle"] == 3

    def test_push_line_empty_ignored(self):
        bus = TelemetryBus()
        bus.push_line("x", "\n")
        bus.push_line("x", "   \n")
        assert bus.entry_count() == 0

    def test_entry_count(self):
        bus = TelemetryBus()
        assert bus.entry_count() == 0
        bus.push({"x": 1})
        assert bus.entry_count() == 1

    def test_clear(self):
        bus = TelemetryBus()
        bus.push({"x": 1})
        bus.clear()
        assert bus.entry_count() == 0

    @pytest.mark.asyncio
    async def test_stream_receives_pushed_entries(self):
        bus = TelemetryBus()
        received = []

        async def _consumer():
            async for entry in bus.stream():
                received.append(entry)
                if len(received) >= 2:
                    return

        import asyncio

        task = asyncio.create_task(_consumer())
        await asyncio.sleep(0.05)  # let consumer start

        bus.push({"message": "first"})
        bus.push({"message": "second"})

        await asyncio.wait_for(task, timeout=2.0)
        assert len(received) == 2
        assert received[0]["message"] == "first"
        assert received[1]["message"] == "second"

    @pytest.mark.asyncio
    async def test_subscriber_count(self):
        import asyncio

        bus = TelemetryBus()
        assert bus.subscriber_count() == 0

        gen = bus.stream()
        task = asyncio.create_task(gen.__anext__())
        await asyncio.sleep(0.05)
        assert bus.subscriber_count() == 1

        task.cancel()
        try:
            await task
        except (asyncio.CancelledError, StopAsyncIteration):
            pass
        assert True

    def test_module_singleton(self):
        b1 = get_bus()
        b2 = get_bus()
        assert b1 is b2


# ---------------------------------------------------------------------------
# ContractWorker unit tests
# ---------------------------------------------------------------------------

class TestContractWorker:
    def test_worker_start_and_stop(self, tmp_path):
        """Worker can launch a subprocess and stop it cleanly."""
        from harness.bundler import ContractWorker

        script = """\
            import asyncio
            class HelloContract:
                async def run(self):
                    print('hello from contract', flush=True)
                    await asyncio.sleep(30)
        """
        cp, cls = _make_tmp_contract(tmp_path, "hello", script)
        w = ContractWorker(str(cp), cls)
        w.start()
        time.sleep(0.4)
        assert w.is_alive()
        w.stop()
        assert not w.is_alive()

    def test_worker_name_from_class_name(self, tmp_path):
        """Worker.name is the class name with 'Contract' stripped."""
        from harness.bundler import ContractWorker

        script = """\
            import asyncio
            class MyStrategyContract:
                async def run(self):
                    await asyncio.sleep(30)
        """
        cp, cls = _make_tmp_contract(tmp_path, "my_strategy", script)
        w = ContractWorker(str(cp), cls)
        assert w.name == "MyStrategy"

    def test_worker_output_captured_in_telemetry(self, tmp_path):
        """Lines printed by the contract land in the global telemetry bus."""
        from harness.bundler import ContractWorker

        bus = get_bus()
        bus.clear()

        script = """\
            import asyncio, json
            class PingContract:
                async def run(self):
                    entry = {"level": "INFO", "message": "contract ping", "cycle": 1}
                    print(json.dumps(entry), flush=True)
                    await asyncio.sleep(5)
        """
        cp, cls = _make_tmp_contract(tmp_path, "ping", script)
        w = ContractWorker(str(cp), cls)
        w.start()
        deadline = time.time() + 3.0
        while time.time() < deadline:
            if bus.entry_count() > 0:
                break
            time.sleep(0.1)
        w.stop()

        snap = bus.snapshot()
        assert any(e["message"] == "contract ping" for e in snap), snap

    def test_worker_restart(self, tmp_path):
        """stop() then restart() works without raising."""
        from harness.bundler import ContractWorker

        script = """\
            import asyncio
            class RestartableContract:
                async def run(self):
                    await asyncio.sleep(30)
        """
        cp, cls = _make_tmp_contract(tmp_path, "restartable", script)
        w = ContractWorker(str(cp), cls)
        w.start()
        time.sleep(0.2)
        w.stop()
        w.restart()
        time.sleep(0.2)
        assert w.is_alive()
        w.stop()

    def test_exited_worker_reports_not_alive(self, tmp_path):
        """A contract whose run() returns immediately shows is_alive() == False."""
        from harness.bundler import ContractWorker

        script = """\
            import asyncio
            class QuickExitContract:
                async def run(self):
                    pass
        """
        cp, cls = _make_tmp_contract(tmp_path, "quick_exit", script)
        w = ContractWorker(str(cp), cls)
        w.start()
        deadline = time.time() + 3.0
        while w.is_alive() and time.time() < deadline:
            time.sleep(0.05)
        assert not w.is_alive()


# ---------------------------------------------------------------------------
# discover_contracts
# ---------------------------------------------------------------------------

class TestDiscoverContracts:
    def test_finds_contract_files(self, tmp_path, monkeypatch):
        """discover_contracts() returns (path, class_name) tuples."""
        import harness.bundler as bundler_mod

        monkeypatch.setattr(bundler_mod, "CONTRACTS_DIR", tmp_path)
        (tmp_path / "stratA").mkdir()
        (tmp_path / "stratA" / "contract.py").write_text(
            "class StratAContract:\n    async def run(self): pass"
        )
        (tmp_path / "stratB").mkdir()
        (tmp_path / "stratB" / "contract.py").write_text(
            "class StratBContract:\n    async def run(self): pass"
        )

        found = bundler_mod.discover_contracts()
        class_names = {cls for _, cls in found}
        assert "StratAContract" in class_names
        assert "StratBContract" in class_names

    def test_empty_dir_returns_empty_list(self, tmp_path, monkeypatch):
        import harness.bundler as bundler_mod

        monkeypatch.setattr(bundler_mod, "CONTRACTS_DIR", tmp_path)
        assert bundler_mod.discover_contracts() == []

    def test_ignores_non_contract_files(self, tmp_path, monkeypatch):
        """Files with no *Contract class are skipped."""
        import harness.bundler as bundler_mod

        monkeypatch.setattr(bundler_mod, "CONTRACTS_DIR", tmp_path)
        (tmp_path / "readme.md").write_text("not a contract")
        (tmp_path / "helper.py").write_text("class SomeHelper:\n    pass")
        assert bundler_mod.discover_contracts() == []


# ---------------------------------------------------------------------------
# Contract smoke test — verify the eurusd_trend contract starts up
# ---------------------------------------------------------------------------

class TestEurusdTrendContract:
    def test_contract_produces_output(self):
        """
        Run the eurusd_trend contract via _runner.py for a few seconds
        (with a non-existent farm so the trade call fails fast) and verify
        that the startup line is emitted.
        """
        import os
        import subprocess

        from harness.bundler import _RUNNER

        contract_path = (
            Path(__file__).resolve().parent.parent
            / "contracts" / "eurusd_trend" / "contract.py"
        )
        if not contract_path.exists():
            pytest.skip("eurusd_trend/contract.py not found")

        env = {
            **os.environ,
            "POLL_INTERVAL_SEC":  "999",   # one cycle then block
            "FARM_HOST":          "127.0.0.1:19999",
            "MASTER_ACCOUNT_ID":  "test",
        }

        proc = subprocess.Popen(
            [sys.executable, _RUNNER, str(contract_path), "EurusdTrendContract"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            env=env,
        )

        output_lines: list[str] = []
        deadline = time.time() + 5.0
        while time.time() < deadline and proc.poll() is None:
            line = proc.stdout.readline()
            if line:
                output_lines.append(line.rstrip())
                if output_lines:
                    break

        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()

        assert output_lines, "No output from contract"
        assert any("EurusdTrend" in ln for ln in output_lines), (
            f"Expected 'EurusdTrend' in output; got: {output_lines}"
        )
