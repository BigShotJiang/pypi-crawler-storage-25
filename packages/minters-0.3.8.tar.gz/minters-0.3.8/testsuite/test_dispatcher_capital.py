"""
Test dispatcher routing to Capital backend.
"""

import os
import pytest


class _FakeBridge:
    """Mock Rust bridge for dispatcher routing tests."""

    def __init__(self, demo_override=None):
        self.demo_override = demo_override

    def account_snapshot_json(self):
        import json
        return json.dumps({
            "login": "cap-dispatcher-test",
            "server": "Capital Test",
            "broker": "Capital.com",
            "currency": "USD",
            "leverage": 30,
            "balance": 5000.0,
            "equity": 4950.0,
            "margin": 250.0,
            "free_margin": 4700.0,
            "margin_level": 1980.0,
            "trade_allowed": True,
        })

    def current_price_json(self, symbol):
        import json
        return json.dumps({
            "symbol": symbol,
            "bid": 1.0950,
            "ask": 1.0952,
            "time": "2026-01-15T10:05:00Z",
        })

    def positions_json(self, symbol=None):
        import json
        return json.dumps([])

    def pending_orders_json(self, symbol=None):
        import json
        return json.dumps([])


@pytest.fixture
def capital_mode_env(monkeypatch):
    """Set BROKER_MODE=capital and patch bridge."""
    monkeypatch.setenv("BROKER_MODE", "capital")
    from harness.barn.core import capital_client as module
    monkeypatch.setattr(module, "_load_bridge_class", lambda: _FakeBridge)


@pytest.fixture
def capital_enabled_env(monkeypatch):
    """Set CAPITAL_ENABLED=true and patch bridge."""
    monkeypatch.setenv("CAPITAL_ENABLED", "true")
    from harness.barn.core import capital_client as module
    monkeypatch.setattr(module, "_load_bridge_class", lambda: _FakeBridge)


@pytest.mark.asyncio
async def test_dispatcher_mode_resolution():
    """Test that dispatcher resolves capital mode."""
    from harness.barn.core.dispatcher import get_broker_mode
    
    # Default is farm
    mode = get_broker_mode()
    assert mode == "farm"


@pytest.mark.asyncio
async def test_dispatcher_routes_to_capital(capital_mode_env):
    """Test dispatcher routes to Capital when BROKER_MODE=capital."""
    from harness.barn.core.dispatcher import get_broker_mode, get_client
    
    mode = get_broker_mode()
    assert mode == "capital"
    
    # Get Capital client via dispatcher
    client = await get_client(account_id="test-capital")
    
    # Verify it's a CapitalClient
    from harness.barn.core.capital_client import CapitalClient
    assert isinstance(client, CapitalClient)
    
    # Verify it works
    info = await client.get_account_information()
    assert info["broker"] == "Capital.com"


@pytest.mark.asyncio
async def test_dispatcher_capital_enabled_flag(capital_enabled_env):
    """Test dispatcher routes to Capital when CAPITAL_ENABLED=true."""
    from harness.barn.core.dispatcher import get_broker_mode, get_client
    
    mode = get_broker_mode()
    assert mode == "capital"
    
    client = await get_client(account_id="test-capital-flag")
    
    from harness.barn.core.capital_client import CapitalClient
    assert isinstance(client, CapitalClient)


@pytest.mark.asyncio
async def test_capital_client_available_methods(capital_mode_env):
    """Test that all expected async methods are available on CapitalClient."""
    from harness.barn.core.dispatcher import get_client
    
    client = await get_client(account_id="method-test")
    
    # Check account methods
    assert hasattr(client, "get_account_information")
    assert hasattr(client, "get_account_info")
    assert hasattr(client, "get_positions")
    assert hasattr(client, "get_pending_orders")
    
    # Check data methods
    assert hasattr(client, "get_current_price")
    assert hasattr(client, "get_symbol_price")
    assert hasattr(client, "get_symbol_info")
    assert hasattr(client, "get_symbols")
    assert hasattr(client, "get_historical_candles")
    
    # Check trading methods
    assert hasattr(client, "market_buy")
    assert hasattr(client, "market_sell")
    assert hasattr(client, "buy_limit")
    assert hasattr(client, "sell_limit")
    assert hasattr(client, "modify_position")
    assert hasattr(client, "close_position")
    assert hasattr(client, "cancel_order")
    
    # Verify they're coroutines
    import inspect
    assert inspect.iscoroutinefunction(client.market_buy)
    assert inspect.iscoroutinefunction(client.close_position)
