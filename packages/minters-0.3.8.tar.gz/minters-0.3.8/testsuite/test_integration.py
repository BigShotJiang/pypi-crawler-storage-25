"""
testsuite/test_integration.py
=================================
End-to-end integration tests that exercise the full harness stack
using mock backends — no real network traffic.

Flow tested:
  1. Connect → get account snapshot
  2. Check open positions and pending orders
  3. Place a market buy order
  4. Modify SL/TP on the position
  5. Close the position
  6. Place a limit order, then cancel it
  7. Fetch deal history
  8. Fetch OHLC candles
"""
from __future__ import annotations

import pytest

from .conftest import FAKE_USER, patch_get_client

_TRADE_OK = {"orderId": "trade-001", "numericCode": 10009}


# ---------------------------------------------------------------------------
# Full trading flow
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_full_trading_flow(mock_farm_client, farm_mode):
    """End-to-end: connect → snapshot → trade → modify → close → history."""
    with patch_get_client(mock_farm_client):
        # 1. Account snapshot
        from harness.barn.account.creds import get_account_snapshot
        snapshot = await get_account_snapshot(user=FAKE_USER)
        assert snapshot is not None

        # 2. Open positions
        from harness.barn.account.positions import get_open_positions
        positions = await get_open_positions("EURUSD", FAKE_USER)
        assert isinstance(positions, list)

        # 3. Market buy
        from harness import market_buy
        buy_result = await market_buy("EURUSD", 0.1, user=FAKE_USER)
        assert buy_result is not None
        mock_farm_client.market_buy.assert_awaited_with("EURUSD", 0.1)

        # 4. Modify SL/TP
        from harness import modify_trade_position
        mod_result = await modify_trade_position(
            "pos-001", stop_loss=1.09, take_profit=1.11, user=FAKE_USER
        )
        assert mod_result is not None

        # 5. Close position
        from harness import close_trade_position
        close_result = await close_trade_position("pos-001", user=FAKE_USER)
        assert close_result is not None

        # 6. Place limit order then cancel it
        from harness import buy_limit, cancel_order
        limit_result = await buy_limit("EURUSD", 0.1, 1.09500, user=FAKE_USER)
        assert limit_result is not None
        cancel_result = await cancel_order("ord-001", user=FAKE_USER)
        assert cancel_result is not None

        # 7. Deal history
        from harness import get_deal_history
        deals = await get_deal_history(0, 0, user=FAKE_USER)
        assert isinstance(deals, list)

        # 8. OHLC candles
        from harness.barn.data.quotes import get_historical_ohlc
        candles = await get_historical_ohlc("EURUSD", "1h", 50, FAKE_USER)
        assert isinstance(candles, list)


# ---------------------------------------------------------------------------
# Mode switching
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_mode_switching_in_flow(mock_farm_client, monkeypatch):
    """Verify that switching BROKER_MODE mid-session does not crash."""
    monkeypatch.setenv("BROKER_MODE", "farm")
    monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)

    with patch_get_client(mock_farm_client):
        from harness import market_buy
        result = await market_buy("EURUSD", 0.1, user=FAKE_USER)
    assert result is not None

    with patch_get_client(mock_farm_client):
        from harness import market_sell
        result2 = await market_sell("GBPUSD", 0.2, user=FAKE_USER)
    assert result2 is not None


# ---------------------------------------------------------------------------
# Stop-limit orders
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_stop_limit_orders_flow(mock_farm_client, farm_mode):
    """Verify stop-limit orders can be placed and modified."""
    with patch_get_client(mock_farm_client):
        from harness import buy_stop_limit, sell_stop_limit, modify_order

        r1 = await buy_stop_limit("XAUUSD", 0.01, 2020.0, 2018.0, user=FAKE_USER)
        assert r1 is not None

        r2 = await sell_stop_limit("XAUUSD", 0.01, 1980.0, 1982.0, user=FAKE_USER)
        assert r2 is not None

        r3 = await modify_order("ord-001", price=2019.0, user=FAKE_USER)
        assert r3 is not None


# ---------------------------------------------------------------------------
# Multi-position close
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_multi_position_close_flow(mock_farm_client, farm_mode):
    """Verify partial close and close-by operations."""
    with patch_get_client(mock_farm_client):
        from harness import close_position_partial, close_by, close_all_by_symbol

        r1 = await close_position_partial("pos-001", 0.05, user=FAKE_USER)
        assert r1 is not None

        r2 = await close_by("pos-001", "pos-002", user=FAKE_USER)
        assert r2 is not None

        r3 = await close_all_by_symbol("EURUSD", user=FAKE_USER)
        assert r3 is not None
