"""
harness/testsuite/test_dispatcher.py
=====================================
Tests for harness.core.dispatcher — mode selection, env var parsing,
BROKER_MODE / FARM_EXT_ENABLED interaction, and auto fallback logic.
"""
from __future__ import annotations

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio


# ---------------------------------------------------------------------------
# get_broker_mode
# ---------------------------------------------------------------------------

class TestGetBrokerMode:
    def test_default_is_farm(self, monkeypatch):
        monkeypatch.delenv("BROKER_MODE", raising=False)
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "farm"

    def test_broker_mode_farm(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "farm")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "farm"

    def test_broker_mode_farm_ext(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "farm_ext")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "farm_ext"

    def test_broker_mode_auto(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "auto")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "auto"

    def test_broker_mode_capital(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "capital")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        monkeypatch.delenv("CAPITAL_ENABLED", raising=False)
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "capital"

    def test_capital_enabled_true_overrides_mode(self, monkeypatch):
        monkeypatch.setenv("CAPITAL_ENABLED", "true")
        monkeypatch.setenv("BROKER_MODE", "farm")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "capital"

    def test_farm_ext_enabled_true_overrides(self, monkeypatch):
        """FARM_EXT_ENABLED=true forces farm_ext regardless of BROKER_MODE."""
        monkeypatch.setenv("FARM_EXT_ENABLED", "true")
        monkeypatch.setenv("BROKER_MODE", "farm")    # should be overridden
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "farm_ext"

    def test_farm_ext_enabled_false_overrides(self, monkeypatch):
        """FARM_EXT_ENABLED=false forces farm regardless of BROKER_MODE."""
        monkeypatch.setenv("FARM_EXT_ENABLED", "false")
        monkeypatch.setenv("BROKER_MODE", "farm_ext")  # should be overridden
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "farm"

    @pytest.mark.parametrize("val", ["1", "TRUE", "True", "yes", "YES", "on", "ON"])
    def test_farm_ext_enabled_truthy_variants(self, monkeypatch, val):
        monkeypatch.setenv("FARM_EXT_ENABLED", val)
        monkeypatch.delenv("BROKER_MODE", raising=False)
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "farm_ext"

    @pytest.mark.parametrize("val", ["0", "FALSE", "False", "no", "NO", "off", "OFF"])
    def test_farm_ext_enabled_falsy_variants(self, monkeypatch, val):
        monkeypatch.setenv("FARM_EXT_ENABLED", val)
        monkeypatch.delenv("BROKER_MODE", raising=False)
        from harness.barn.core.dispatcher import get_broker_mode
        assert get_broker_mode() == "farm"

    def test_unknown_broker_mode_falls_back_to_farm(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "something_unknown")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        from harness.barn.core.dispatcher import get_broker_mode
        # Should fall back to "farm" gracefully
        result = get_broker_mode()
        assert result in ("farm", "something_unknown")  # permissive — just no crash


# ---------------------------------------------------------------------------
# is_farm_ext_enabled
# ---------------------------------------------------------------------------

class TestIsFarmExtEnabled:
    def test_false_by_default(self, monkeypatch):
        monkeypatch.delenv("BROKER_MODE", raising=False)
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        from harness.barn.core.dispatcher import is_farm_ext_enabled
        assert is_farm_ext_enabled() is False

    def test_true_when_mode_is_farm_ext(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "farm_ext")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        from harness.barn.core.dispatcher import is_farm_ext_enabled
        assert is_farm_ext_enabled() is True

    def test_true_when_enabled_env_true(self, monkeypatch):
        monkeypatch.setenv("FARM_EXT_ENABLED", "true")
        monkeypatch.delenv("BROKER_MODE", raising=False)
        from harness.barn.core.dispatcher import is_farm_ext_enabled
        assert is_farm_ext_enabled() is True

    def test_false_when_mode_farm(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "farm")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)
        from harness.barn.core.dispatcher import is_farm_ext_enabled
        assert is_farm_ext_enabled() is False


# ---------------------------------------------------------------------------
# get_client
# ---------------------------------------------------------------------------

class TestGetClient:
    @pytest.mark.asyncio
    async def test_returns_farm_client_in_farm_mode(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "farm")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)

        mock_client = MagicMock()
        mock_farm_cls = MagicMock()
        mock_farm_cls.get = AsyncMock(return_value=mock_client)

        with patch("harness.core.dispatcher._import_farm_client", return_value=mock_farm_cls):
            from harness.barn.core.dispatcher import get_client
            client = await get_client(user=None, account_id="test-001")
            mock_farm_cls.get.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_returns_farm_ext_client_in_farm_ext_mode(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "farm_ext")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)

        mock_client = MagicMock()
        mock_ext_cls = MagicMock()
        mock_ext_cls.get = AsyncMock(return_value=mock_client)

        with patch("harness.core.dispatcher._import_farm_ext_client", return_value=mock_ext_cls):
            from harness.barn.core.dispatcher import get_client
            client = await get_client(user=None, account_id="test-001")
            mock_ext_cls.get.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_auto_mode_falls_back_to_farm_on_error(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "auto")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)

        mock_farm_client = MagicMock()
        mock_farm_cls = MagicMock()
        mock_farm_cls.get = AsyncMock(return_value=mock_farm_client)

        mock_ext_cls = MagicMock()
        mock_ext_cls.get = AsyncMock(side_effect=RuntimeError("MetaAPI unavailable"))

        with (
            patch("harness.core.dispatcher._import_farm_ext_client", return_value=mock_ext_cls),
            patch("harness.core.dispatcher._import_farm_client", return_value=mock_farm_cls),
        ):
            from harness.barn.core.dispatcher import get_client
            client = await get_client(user=None, account_id="test-001")
            # Should have fallen back to farm
            mock_farm_cls.get.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_explicit_mode_parameter_overrides_env(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "farm_ext")

        mock_client = MagicMock()
        mock_farm_cls = MagicMock()
        mock_farm_cls.get = AsyncMock(return_value=mock_client)

        with patch("harness.core.dispatcher._import_farm_client", return_value=mock_farm_cls):
            from harness.barn.core.dispatcher import get_client
            client = await get_client(user=None, account_id="test-001", mode="farm")
            mock_farm_cls.get.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_returns_capital_client_in_capital_mode(self, monkeypatch):
        monkeypatch.setenv("BROKER_MODE", "capital")
        monkeypatch.delenv("FARM_EXT_ENABLED", raising=False)

        mock_client = MagicMock()
        mock_capital_cls = MagicMock()
        mock_capital_cls.get = AsyncMock(return_value=mock_client)

        with patch(
            "harness.barn.core.dispatcher._import_capital_client",
            return_value=mock_capital_cls,
        ):
            from harness.barn.core.dispatcher import get_client

            client = await get_client(user=None, account_id="test-001")
            assert client is mock_client
            mock_capital_cls.get.assert_awaited_once_with(account_id="test-001", user=None)
