"""
Integration test for Capital.com contract with mocked bridge.
"""

import json
import os
import pytest


class _FakeBridge:
    """Mock Rust bridge for testing without live Capital.com connection."""

    def __init__(self, demo_override=None):
        self.demo_override = demo_override

    def account_snapshot_json(self):
        return json.dumps({
            "login": "cap-demo-001",
            "server": "Capital Demo",
            "broker": "Capital.com",
            "currency": "USD",
            "leverage": 30,
            "balance": 10000.0,
            "equity": 9950.0,
            "margin": 500.0,
            "free_margin": 9450.0,
            "margin_level": 1990.0,
            "trade_allowed": True,
        })

    def positions_json(self, symbol=None):
        return json.dumps([
            {
                "id": "pos-cap-001",
                "symbol": "EURUSD",
                "side": "BUY",
                "volume": 0.1,
                "open_price": 1.0950,
                "current_price": 1.0960,
                "unrealized_profit": 10.0,
                "stop_loss": 1.0900,
                "take_profit": 1.1050,
                "opened_at": "2026-01-15T10:00:00Z",
                "updated_at": "2026-01-15T10:05:00Z",
            }
        ])

    def pending_orders_json(self, symbol=None):
        return json.dumps([
            {
                "id": "ord-cap-001",
                "symbol": "EURUSD",
                "side": "BUY",
                "order_type": "LIMIT",
                "status": "PENDING",
                "volume": 0.05,
                "price": 1.0900,
                "created_at": "2026-01-15T09:00:00Z",
            }
        ])

    def current_price_json(self, symbol):
        quotes = {
            "EURUSD": {"symbol": "EURUSD", "bid": 1.0950, "ask": 1.0952, "time": "2026-01-15T10:05:00Z"},
            "GBPUSD": {"symbol": "GBPUSD", "bid": 1.2750, "ask": 1.2752, "time": "2026-01-15T10:05:00Z"},
            "XAUUSD": {"symbol": "XAUUSD", "bid": 2050.0, "ask": 2050.5, "time": "2026-01-15T10:05:00Z"},
        }
        return json.dumps(quotes.get(symbol, {"symbol": symbol, "bid": 1.0, "ask": 1.001}))

    def historical_ohlc_json(self, symbol, timeframe, count=1000):
        return json.dumps([
            {
                "time": "2026-01-15T10:00:00Z",
                "open": 1.0950,
                "high": 1.0960,
                "low": 1.0940,
                "close": 1.0955,
                "volume": 1000.0,
            },
            {
                "time": "2026-01-15T10:01:00Z",
                "open": 1.0955,
                "high": 1.0965,
                "low": 1.0950,
                "close": 1.0960,
                "volume": 1200.0,
            },
        ])

    def market_buy_json(self, symbol, size, stop_loss=None, take_profit=None):
        return json.dumps({
            "success": True,
            "id": "exec-cap-001",
            "status": "ACCEPTED",
            "message": "Order accepted by Capital.com",
        })

    def modify_position_json(self, ticket, stop_loss=None, take_profit=None):
        return json.dumps({
            "success": True,
            "id": ticket,
            "status": "MODIFIED",
            "message": "Position modified",
        })

    def close_position_full_json(self, ticket):
        return json.dumps({
            "success": True,
            "id": ticket,
            "status": "CLOSED",
            "message": "Position closed",
        })

    def search_markets_json(self, query):
        return json.dumps({
            "markets": [
                {"epic": "EURUSD"},
                {"epic": "GBPUSD"},
                {"epic": "XAUUSD"},
            ]
        })

    def server_time_json(self):
        return json.dumps({"time": "2026-01-15T10:05:00Z"})

    def market_details_json(self, symbol):
        return json.dumps({
            "instrument": {"marginFactor": 1.0, "currencies": ["USD"]},
            "snapshot": {"bid": 1.0950, "offer": 1.0952},
        })

    def closed_orders_json(self, limit=100):
        return json.dumps([
            {
                "id": "deal-cap-001",
                "symbol": "EURUSD",
                "side": "BUY",
                "status": "CLOSED",
                "volume": 0.1,
                "open_price": 1.0950,
                "close_price": 1.0960,
                "profit": 10.0,
                "commission": -1.0,
                "swap": 0.0,
                "opened_at": "2026-01-14T10:00:00Z",
                "closed_at": "2026-01-14T12:00:00Z",
            }
        ])


@pytest.fixture
def patch_capital_bridge(monkeypatch):
    from harness.barn.core import capital_client as module
    monkeypatch.setattr(module, "_load_bridge_class", lambda: _FakeBridge)


@pytest.mark.asyncio
async def test_capital_contract_imports(patch_capital_bridge):
    """Test that contract module imports successfully."""
    from harness.barn.core.capital_client import CapitalClient
    client = await CapitalClient.get(account_id="test-demo")
    assert client.is_connected


@pytest.mark.asyncio
async def test_capital_contract_full_workflow(patch_capital_bridge):
    """Test full contract workflow: account → prices → positions → orders."""
    from harness.barn.core.capital_client import CapitalClient

    client = await CapitalClient.get(account_id="test-demo")

    # Step 1: Get account info
    info = await client.get_account_information()
    assert info["broker"] == "Capital.com"
    assert info["balance"] == 10000.0
    assert info["leverage"] == 30

    # Step 2: Get current price
    price = await client.get_current_price("EURUSD")
    assert price["symbol"] == "EURUSD"
    assert price["bid"] == 1.0950
    assert price["ask"] == 1.0952

    # Step 3: Get open positions
    positions = await client.get_positions()
    assert len(positions) == 1
    assert positions[0]["symbol"] == "EURUSD"
    assert positions[0]["volume"] == 0.1

    # Step 4: Get pending orders
    pending = await client.get_pending_orders()
    assert len(pending) == 1
    assert pending[0]["type"] in ["buy_limit", "sell_limit", "limit"]

    # Step 5: Place market buy
    order = await client.market_buy("EURUSD", 0.1)
    assert order["success"] is True
    assert order["ticket"] == "exec-cap-001"

    # Step 6: Modify position
    modify = await client.modify_position("exec-cap-001", stop_loss=1.09, take_profit=1.11)
    assert modify["success"] is True

    # Step 7: Close position
    close = await client.close_position("exec-cap-001")
    assert close["success"] is True

    # Step 8: Get deal history
    deals = await client.get_deal_history()
    assert len(deals) == 1
    assert deals[0]["profit"] == 10.0


@pytest.mark.asyncio
async def test_capital_contract_market_data(patch_capital_bridge):
    """Test market data retrieval for multiple symbols."""
    from harness.barn.core.capital_client import CapitalClient

    client = await CapitalClient.get(account_id="test-demo")

    symbols = ["EURUSD", "GBPUSD", "XAUUSD"]
    for symbol in symbols:
        price = await client.get_current_price(symbol)
        assert price["symbol"] == symbol
        assert price["bid"] > 0
        assert price["ask"] > 0

    # Get historical candles
    candles = await client.get_historical_candles("EURUSD", "1m", limit=2)
    assert len(candles) == 2
    assert candles[0]["close"] == 1.0955


@pytest.mark.asyncio
async def test_capital_contract_complex_order_flow(patch_capital_bridge):
    """Test complex trading flow: buy → modify → close."""
    from harness.barn.core.capital_client import CapitalClient

    client = await CapitalClient.get(account_id="test-demo")

    # 1. Place order
    buy = await client.market_buy("EURUSD", 0.2)
    assert buy["success"]
    ticket = buy["ticket"]

    # 2. Modify stops
    modify = await client.modify_position(
        ticket,
        stop_loss=1.0900,
        take_profit=1.1100,
    )
    assert modify["success"]

    # 3. Check positions
    positions = await client.get_positions()
    assert len(positions) > 0

    # 4. Close position
    close = await client.close_position(ticket)
    assert close["success"]


@pytest.mark.asyncio
async def test_capital_contract_error_handling(patch_capital_bridge):
    """Test that errors are handled gracefully."""
    from harness.barn.core.capital_client import CapitalClient

    client = await CapitalClient.get(account_id="test-demo")

    # These should not raise; bridge returns success=False
    result = await client.buy_stop_limit("EURUSD", 0.1, 1.0950, 1.0900)
    assert result["success"] is False
