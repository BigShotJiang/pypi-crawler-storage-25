"""
testsuite/test_capital_client.py
================================
Unit tests for CapitalClient adapter with a mocked Rust bridge.
"""

from __future__ import annotations

import json

import pytest


class _FakeBridge:
    def __init__(self, demo_override=None):
        self.demo_override = demo_override

    def account_snapshot_json(self):
        return json.dumps(
            {
                "login": "cap-001",
                "server": "Capital Demo",
                "broker": "Capital.com",
                "currency": "USD",
                "leverage": 30,
                "balance": 1000.0,
                "equity": 995.0,
                "margin": 50.0,
                "free_margin": 945.0,
                "margin_level": 1990.0,
                "trade_allowed": True,
            }
        )

    def positions_json(self, symbol=None):
        return json.dumps(
            [
                {
                    "id": "pos-001",
                    "symbol": "EURUSD",
                    "side": "BUY",
                    "volume": 0.5,
                    "open_price": 1.1,
                    "current_price": 1.101,
                    "unrealized_profit": 5.0,
                    "stop_loss": 1.09,
                    "take_profit": 1.12,
                    "opened_at": "2026-01-01T00:00:00",
                    "updated_at": "2026-01-01T00:05:00",
                }
            ]
        )

    def pending_orders_json(self, symbol=None):
        return json.dumps(
            [
                {
                    "id": "ord-001",
                    "symbol": "EURUSD",
                    "side": "BUY",
                    "order_type": "LIMIT",
                    "status": "PENDING",
                    "volume": 0.2,
                    "price": 1.095,
                    "created_at": "2026-01-01T00:00:00",
                }
            ]
        )

    def current_price_json(self, symbol):
        return json.dumps({"symbol": symbol, "bid": 1.1, "ask": 1.1002, "time": "2026-01-01T00:00:01Z"})

    def historical_ohlc_json(self, symbol, timeframe, count=1000):
        return json.dumps(
            [
                {
                    "time": "2026-01-01T00:00:00",
                    "open": 1.1,
                    "high": 1.101,
                    "low": 1.099,
                    "close": 1.1005,
                    "volume": 100,
                }
            ]
        )

    def historical_ohlc_range_json(self, symbol, timeframe, from_iso, to_iso):
        return self.historical_ohlc_json(symbol, timeframe, 1)

    def closed_orders_json(self, limit=100):
        return json.dumps(
            [
                {
                    "id": "deal-001",
                    "symbol": "EURUSD",
                    "side": "BUY",
                    "status": "CLOSED",
                    "volume": 0.1,
                    "open_price": 1.1,
                    "close_price": 1.1005,
                    "profit": 5.0,
                    "commission": -0.1,
                    "swap": 0.0,
                    "opened_at": "2026-01-01T00:00:00",
                    "closed_at": "2026-01-01T00:30:00",
                }
            ]
        )

    def closed_orders_range_json(self, start_iso=None, end_iso=None, tx_type=None):
        return self.closed_orders_json()

    def market_buy_json(self, symbol, size, stop_loss=None, take_profit=None):
        return json.dumps({"success": True, "id": "exec-001", "status": "ACCEPTED", "message": None})

    def market_sell_json(self, symbol, size, stop_loss=None, take_profit=None):
        return self.market_buy_json(symbol, size, stop_loss, take_profit)

    def buy_limit_json(self, symbol, size, level, stop_loss=None, take_profit=None):
        return self.market_buy_json(symbol, size, stop_loss, take_profit)

    def sell_limit_json(self, symbol, size, level, stop_loss=None, take_profit=None):
        return self.market_buy_json(symbol, size, stop_loss, take_profit)

    def buy_stop_json(self, symbol, size, level, stop_loss=None, take_profit=None):
        return self.market_buy_json(symbol, size, stop_loss, take_profit)

    def sell_stop_json(self, symbol, size, level, stop_loss=None, take_profit=None):
        return self.market_buy_json(symbol, size, stop_loss, take_profit)

    def modify_position_json(self, ticket, stop_loss=None, take_profit=None):
        return self.market_buy_json("EURUSD", 0.1)

    def close_position_full_json(self, ticket):
        return self.market_buy_json("EURUSD", 0.1)

    def modify_order_json(self, ticket, level, stop_loss=None, take_profit=None):
        return self.market_buy_json("EURUSD", 0.1)

    def cancel_order_json(self, ticket):
        return self.market_buy_json("EURUSD", 0.1)

    def search_markets_json(self, query):
        return json.dumps({"markets": [{"epic": "EURUSD"}, {"epic": "XAUUSD"}]})

    def market_details_json(self, symbol):
        return json.dumps({"instrument": {"marginFactor": 1.0, "currencies": ["USD"]}, "snapshot": {"bid": 1.1, "offer": 1.1002}})

    def server_time_json(self):
        return json.dumps({"time": "2026-01-01T00:00:00Z"})


@pytest.fixture
def patch_bridge(monkeypatch):
    from harness.barn.core import capital_client as module

    monkeypatch.setattr(module, "_load_bridge_class", lambda: _FakeBridge)


@pytest.mark.asyncio
async def test_capital_client_account_snapshot_and_positions(patch_bridge):
    from harness.barn.core.capital_client import CapitalClient

    client = await CapitalClient.get(account_id="demo")
    info = await client.get_account_information()
    positions = await client.get_positions()

    assert info["broker"] == "Capital.com"
    assert positions[0]["id"] == "pos-001"


@pytest.mark.asyncio
async def test_capital_client_market_data_and_history(patch_bridge):
    from harness.barn.core.capital_client import CapitalClient

    client = await CapitalClient.get(account_id="demo")
    price = await client.get_current_price("EURUSD")
    candles = await client.get_historical_candles("EURUSD", "1m", limit=10)
    deals = await client.get_deal_history()

    assert "bid" in price
    assert len(candles) == 1
    assert deals[0]["id"] == "deal-001"


@pytest.mark.asyncio
async def test_capital_client_trade_methods(patch_bridge):
    from harness.barn.core.capital_client import CapitalClient

    client = await CapitalClient.get(account_id="demo")

    buy = await client.market_buy("EURUSD", 0.1)
    modify = await client.modify_position("exec-001", stop_loss=1.09, take_profit=1.11)
    cancel = await client.cancel_order("exec-002")

    assert buy["success"] is True
    assert modify["success"] is True
    assert cancel["success"] is True
