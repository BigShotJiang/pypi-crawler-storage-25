"""
testsuite/test_farm_client.py
==============================
Unit tests for FarmClient — all HTTP calls intercepted with respx.
No real network traffic.
"""
from __future__ import annotations

from unittest.mock import patch

import httpx
import pytest
import respx

import harness.barn.core.farm_client as fc_module
from testsuite.conftest import (
    FAKE_ACCOUNT_ID,
    FAKE_ACCOUNT_INFO,
    FAKE_POSITION,
    FAKE_ORDER,
    FAKE_DEAL,
    FAKE_CANDLE,
    FAKE_TICK,
    FAKE_SYMBOLS,
    FAKE_SERVER_TIME,
    FAKE_MARGIN,
    FAKE_BOOK,
    FAKE_SYMBOL_INFO,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

TEST_BASE_URL = "http://testfarm"
AID = FAKE_ACCOUNT_ID

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_client(account_id: str = AID):
    """Create a bare FarmClient without going through the pool."""
    from harness.barn.core.farm_client import FarmClient

    client = FarmClient.__new__(FarmClient)
    client.account_id = account_id          # public attribute (not _account_id)
    client._session = None
    client._connected = False
    client._terminal_state = {}
    return client


def _ok(data) -> httpx.Response:
    return httpx.Response(200, json=data)


# Patch FARM_BASE_URL to the test URL for all tests in this module
@pytest.fixture(autouse=True)
def _patch_base_url():
    with patch.object(fc_module, "FARM_BASE_URL", TEST_BASE_URL):
        yield


# ---------------------------------------------------------------------------
# Account
# ---------------------------------------------------------------------------


class TestFarmClientAccount:
    @pytest.mark.asyncio
    async def test_get_account_info(self):
        client = _make_client()
        raw = {
            "login": 12345678, "balance": 10000.0, "equity": 10250.0,
            "margin": 500.0, "free_margin": 9750.0, "margin_level": 2050.0,
            "currency": "USD", "leverage": 100, "server": "Broker-MT5Live",
            "trade_allowed": True,
        }
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/account/{AID}").mock(return_value=_ok(raw))
            result = await client.get_account_info()
        assert result["balance"] == 10000.0

    @pytest.mark.asyncio
    async def test_get_account_information(self):
        """get_account_information() calls get_account_info() and remaps keys."""
        client = _make_client()
        raw = {
            "login": 12345678, "balance": 10000.0, "equity": 10250.0,
            "margin": 500.0, "free_margin": 9750.0, "margin_level": 2050.0,
            "currency": "USD", "leverage": 100, "server": "Broker-MT5Live",
            "trade_allowed": True,
        }
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/account/{AID}").mock(return_value=_ok(raw))
            result = await client.get_account_information()
        assert result["balance"] == 10000.0
        assert "freeMargin" in result  # camelCase remapping


# ---------------------------------------------------------------------------
# Positions
# ---------------------------------------------------------------------------


class TestFarmClientPositions:
    @pytest.mark.asyncio
    async def test_get_positions(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/positions/{AID}").mock(
                return_value=_ok({"positions": [FAKE_POSITION]})
            )
            positions = await client.get_positions()
        assert isinstance(positions, list)
        assert positions[0]["symbol"] == "EURUSD"

    @pytest.mark.asyncio
    async def test_get_position(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/position/{AID}/pos-001").mock(
                return_value=_ok(FAKE_POSITION)
            )
            pos = await client.get_position("pos-001")
        assert pos["id"] == "pos-001"


# ---------------------------------------------------------------------------
# Orders
# ---------------------------------------------------------------------------


class TestFarmClientOrders:
    @pytest.mark.asyncio
    async def test_get_pending_orders(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/orders/{AID}").mock(
                return_value=_ok({"orders": [FAKE_ORDER]})
            )
            orders = await client.get_pending_orders()
        assert isinstance(orders, list)
        assert orders[0]["type"] == "buy_limit"

    @pytest.mark.asyncio
    async def test_get_order(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/order/{AID}/ord-001").mock(
                return_value=_ok(FAKE_ORDER)
            )
            order = await client.get_order("ord-001")
        assert order["id"] == "ord-001"


# ---------------------------------------------------------------------------
# Deal History
# ---------------------------------------------------------------------------


class TestFarmClientHistory:
    @pytest.mark.asyncio
    async def test_get_deal_history(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/deals/{AID}").mock(
                return_value=_ok({"deals": [FAKE_DEAL]})
            )
            deals = await client.get_deal_history(0, 9_999_999)
        assert isinstance(deals, list)
        assert len(deals) == 1

    @pytest.mark.asyncio
    async def test_get_deals_by_ticket(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/deals/{AID}").mock(
                return_value=_ok({"deals": [FAKE_DEAL]})
            )
            deals = await client.get_deals_by_ticket("deal-001")
        assert isinstance(deals, list)

    @pytest.mark.asyncio
    async def test_get_deals_by_position(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/deals/{AID}").mock(
                return_value=_ok({"deals": [FAKE_DEAL]})
            )
            deals = await client.get_deals_by_position("pos-001")
        assert isinstance(deals, list)

    @pytest.mark.asyncio
    async def test_get_history_orders_by_ticket(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/history-orders/{AID}").mock(
                return_value=_ok({"orders": [FAKE_ORDER]})
            )
            orders = await client.get_history_orders_by_ticket("ord-001")
        assert isinstance(orders, list)

    @pytest.mark.asyncio
    async def test_get_history_orders_by_position(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/history-orders/{AID}").mock(
                return_value=_ok({"orders": [FAKE_ORDER]})
            )
            orders = await client.get_history_orders_by_position("pos-001")
        assert isinstance(orders, list)

    @pytest.mark.asyncio
    async def test_get_history_orders_by_time_range(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/history-orders/{AID}").mock(
                return_value=_ok({"orders": [FAKE_ORDER]})
            )
            # Pass epoch ints — the method calls int(t) on non-datetime values
            orders = await client.get_history_orders_by_time_range(1704067200, 1706745600)
        assert isinstance(orders, list)


# ---------------------------------------------------------------------------
# Market Data
# ---------------------------------------------------------------------------


class TestFarmClientMarketData:
    @pytest.mark.asyncio
    async def test_get_symbols(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/symbols/{AID}").mock(
                return_value=_ok({"symbols": FAKE_SYMBOLS})
            )
            symbols = await client.get_symbols()
        assert "EURUSD" in symbols

    @pytest.mark.asyncio
    async def test_get_symbol_info(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/symbol/{AID}/EURUSD").mock(
                return_value=_ok(FAKE_SYMBOL_INFO)
            )
            info = await client.get_symbol_info("EURUSD")
        assert info["symbol"] == "EURUSD"

    @pytest.mark.asyncio
    async def test_get_current_price(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/price/{AID}/EURUSD").mock(
                return_value=_ok(FAKE_TICK)
            )
            tick = await client.get_current_price("EURUSD")
        assert "bid" in tick
        assert "ask" in tick

    @pytest.mark.asyncio
    async def test_get_symbol_price_alias(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/price/{AID}/EURUSD").mock(
                return_value=_ok(FAKE_TICK)
            )
            tick = await client.get_symbol_price("EURUSD")
        assert "bid" in tick

    @pytest.mark.asyncio
    async def test_read_tick(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/price/{AID}/EURUSD").mock(
                return_value=_ok(FAKE_TICK)
            )
            tick = await client.read_tick("EURUSD")
        assert "bid" in tick

    @pytest.mark.asyncio
    async def test_read_candle(self):
        """read_candle() wraps get_historical_candles() which calls /history/{aid}."""
        client = _make_client()
        rate = {"time": "2024-01-01T00:00:00Z", "o": 1.1, "h": 1.11, "l": 1.09, "c": 1.105, "v": 100}
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/history/{AID}").mock(
                return_value=_ok({"rates": [rate]})
            )
            candle = await client.read_candle("EURUSD", "1h")
        assert candle is not None
        assert "open" in candle

    @pytest.mark.asyncio
    async def test_read_book(self):
        client = _make_client()
        # read_book() returns result.get("book", []) — the value must be a list
        entries = FAKE_BOOK["bids"] + FAKE_BOOK["asks"]
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/book/{AID}/EURUSD").mock(
                return_value=_ok({"book": entries})
            )
            book = await client.read_book("EURUSD")
        assert isinstance(book, list)
        assert len(book) == 2

    @pytest.mark.asyncio
    async def test_get_server_time(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/time/{AID}").mock(
                return_value=_ok(FAKE_SERVER_TIME)
            )
            t = await client.get_server_time()
        assert "broker_time" in t or "time" in t

    @pytest.mark.asyncio
    async def test_calculate_margin(self):
        client = _make_client()
        with respx.mock:
            respx.post(f"{TEST_BASE_URL}/margin/{AID}").mock(
                return_value=_ok(FAKE_MARGIN)
            )
            margin = await client.calculate_margin(
                {"symbol": "EURUSD", "type": "buy", "volume": 0.1}
            )
        assert "margin" in margin

    @pytest.mark.asyncio
    async def test_get_historical_ticks(self):
        client = _make_client()
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/ticks/{AID}").mock(
                return_value=_ok({"ticks": [FAKE_TICK] * 5})
            )
            ticks = await client.get_historical_ticks("EURUSD", None, 0, 5)
        assert isinstance(ticks, list)
        assert len(ticks) == 5

    @pytest.mark.asyncio
    async def test_get_historical_candles(self):
        client = _make_client()
        rates = [
            {"time": "2024-01-01T00:00:00Z", "o": 1.1, "h": 1.11, "l": 1.09, "c": 1.105, "v": 100}
        ] * 10
        with respx.mock:
            respx.get(f"{TEST_BASE_URL}/history/{AID}").mock(
                return_value=_ok({"rates": rates})
            )
            candles = await client.get_historical_candles("EURUSD", "1h", limit=10)
        assert isinstance(candles, list)
        assert len(candles) == 10


# ---------------------------------------------------------------------------
# Trade Execution
# ---------------------------------------------------------------------------


class TestFarmClientTrades:
    _trade_result = {"orderId": "trade-001", "numericCode": 10009}

    @pytest.mark.asyncio
    async def test_market_buy(self):
        client = _make_client()
        with respx.mock:
            respx.post(f"{TEST_BASE_URL}/trade/{AID}").mock(
                return_value=_ok(self._trade_result)
            )
            result = await client.market_buy("EURUSD", 0.1)
        assert result.get("orderId") or result.get("order_id")

    @pytest.mark.asyncio
    async def test_market_sell(self):
        client = _make_client()
        with respx.mock:
            respx.post(f"{TEST_BASE_URL}/trade/{AID}").mock(
                return_value=_ok(self._trade_result)
            )
            result = await client.market_sell("EURUSD", 0.1)
        assert result.get("orderId") or result.get("order_id")

    @pytest.mark.asyncio
    async def test_buy_limit(self):
        client = _make_client()
        with respx.mock:
            respx.post(f"{TEST_BASE_URL}/order/{AID}").mock(
                return_value=_ok(self._trade_result)
            )
            result = await client.buy_limit("EURUSD", 0.1, 1.095)
        assert result is not None

    @pytest.mark.asyncio
    async def test_sell_limit(self):
        client = _make_client()
        with respx.mock:
            respx.post(f"{TEST_BASE_URL}/order/{AID}").mock(
                return_value=_ok(self._trade_result)
            )
            result = await client.sell_limit("EURUSD", 0.1, 1.105)
        assert result is not None

    @pytest.mark.asyncio
    async def test_close_position(self):
        client = _make_client()
        with respx.mock:
            respx.post(f"{TEST_BASE_URL}/close/{AID}/pos-001").mock(
                return_value=_ok(self._trade_result)
            )
            result = await client.close_position("pos-001")
        assert result is not None

    @pytest.mark.asyncio
    async def test_modify_position(self):
        client = _make_client()
        with respx.mock:
            respx.put(f"{TEST_BASE_URL}/position/{AID}/pos-001").mock(
                return_value=_ok(self._trade_result)
            )
            result = await client.modify_position("pos-001", 1.09, 1.11)
        assert result is not None

    @pytest.mark.asyncio
    async def test_cancel_order(self):
        client = _make_client()
        with respx.mock:
            respx.delete(f"{TEST_BASE_URL}/order/{AID}/ord-001").mock(
                return_value=_ok(self._trade_result)
            )
            result = await client.cancel_order("ord-001")
        assert result is not None

    @pytest.mark.asyncio
    async def test_close_all_positions_by_symbol(self):
        client = _make_client()
        with respx.mock:
            respx.post(f"{TEST_BASE_URL}/positions/{AID}/close-all/EURUSD").mock(
                return_value=_ok({"closed": 1})
            )
            result = await client.close_all_positions_by_symbol("EURUSD")
        assert result is not None

    @pytest.mark.asyncio
    async def test_close_position_partial(self):
        client = _make_client()
        with respx.mock:
            respx.post(
                f"{TEST_BASE_URL}/position/{AID}/pos-001/close-partial"
            ).mock(return_value=_ok(self._trade_result))
            result = await client.close_position_partial("pos-001", 0.05)
        assert result is not None

    @pytest.mark.asyncio
    async def test_close_position_by(self):
        client = _make_client()
        with respx.mock:
            respx.post(
                f"{TEST_BASE_URL}/position/{AID}/pos-001/close-by/pos-002"
            ).mock(return_value=_ok(self._trade_result))
            result = await client.close_position_by("pos-001", "pos-002")
        assert result is not None

    @pytest.mark.asyncio
    async def test_modify_order(self):
        client = _make_client()
        with respx.mock:
            respx.put(f"{TEST_BASE_URL}/order/{AID}/ord-001").mock(
                return_value=_ok(self._trade_result)
            )
            result = await client.modify_order("ord-001", 1.095, 1.09, 1.10)
        assert result is not None
