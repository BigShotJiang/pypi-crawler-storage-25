"""
harness/testsuite/test_trade.py
=================================
Tests for the unified trading API exposed at harness package level:
    market_buy, market_sell, buy/sell limit/stop/stop_limit,
    modify_trade_position, close_trade_position, close_by,
    close_all_by_symbol, modify_order, cancel_order.
"""
from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from .conftest import FAKE_USER, patch_get_client

_TRADE_OK = {"orderId": "trade-001", "numericCode": 10009, "message": "Request completed"}


def _patch_dispatcher(mock_client):
    """Context manager that makes get_client() always return mock_client."""
    return patch_get_client(mock_client)


# ---------------------------------------------------------------------------
# Market orders
# ---------------------------------------------------------------------------

class TestMarketOrders:
    @pytest.mark.asyncio
    async def test_market_buy(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import market_buy
            result = await market_buy("EURUSD", 0.1, user=FAKE_USER)
        assert result is not None
        mock_farm_client.market_buy.assert_awaited_once_with("EURUSDm", 0.1)

    @pytest.mark.asyncio
    async def test_market_sell(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import market_sell
            result = await market_sell("EURUSD", 0.1, user=FAKE_USER)
        assert result is not None
        mock_farm_client.market_sell.assert_awaited_once_with("EURUSDm", 0.1)


# ---------------------------------------------------------------------------
# Limit orders
# ---------------------------------------------------------------------------

class TestLimitOrders:
    @pytest.mark.asyncio
    async def test_buy_limit(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import buy_limit
            result = await buy_limit("EURUSD", 0.1, 1.095, user=FAKE_USER)
        assert result is not None
        mock_farm_client.buy_limit.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_sell_limit(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import sell_limit
            result = await sell_limit("EURUSD", 0.1, 1.105, user=FAKE_USER)
        assert result is not None
        mock_farm_client.sell_limit.assert_awaited_once()


# ---------------------------------------------------------------------------
# Stop orders
# ---------------------------------------------------------------------------

class TestStopOrders:
    @pytest.mark.asyncio
    async def test_buy_stop(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import buy_stop
            result = await buy_stop("EURUSD", 0.1, 1.105, user=FAKE_USER)
        assert result is not None

    @pytest.mark.asyncio
    async def test_sell_stop(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import sell_stop
            result = await sell_stop("EURUSD", 0.1, 1.095, user=FAKE_USER)
        assert result is not None

    @pytest.mark.asyncio
    async def test_buy_stop_limit(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import buy_stop_limit
            result = await buy_stop_limit("EURUSD", 0.1, 1.105, 1.103, user=FAKE_USER)
        assert result is not None

    @pytest.mark.asyncio
    async def test_sell_stop_limit(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import sell_stop_limit
            result = await sell_stop_limit("EURUSD", 0.1, 1.095, 1.097, user=FAKE_USER)
        assert result is not None


# ---------------------------------------------------------------------------
# Position management
# ---------------------------------------------------------------------------

class TestPositionManagement:
    @pytest.mark.asyncio
    async def test_modify_trade_position(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import modify_trade_position
            result = await modify_trade_position(
                "pos-001", stop_loss=1.09, take_profit=1.11, user=FAKE_USER
            )
        assert result is not None
        mock_farm_client.modify_position.assert_awaited_once_with("pos-001", 1.09, 1.11)

    @pytest.mark.asyncio
    async def test_close_trade_position(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import close_trade_position
            result = await close_trade_position("pos-001", user=FAKE_USER)
        assert result is not None
        mock_farm_client.close_position.assert_awaited_once_with("pos-001")

    @pytest.mark.asyncio
    async def test_close_position_partial(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import close_position_partial
            result = await close_position_partial("pos-001", 0.05, user=FAKE_USER)
        assert result is not None

    @pytest.mark.asyncio
    async def test_close_by(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import close_by
            result = await close_by("pos-001", "pos-002", user=FAKE_USER)
        assert result is not None

    @pytest.mark.asyncio
    async def test_close_all_by_symbol(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import close_all_by_symbol
            result = await close_all_by_symbol("EURUSD", user=FAKE_USER)
        assert result is not None

    @pytest.mark.asyncio
    async def test_modify_order(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import modify_order
            result = await modify_order("ord-001", price=1.095, user=FAKE_USER)
        assert result is not None

    @pytest.mark.asyncio
    async def test_cancel_order(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import cancel_order
            result = await cancel_order("ord-001", user=FAKE_USER)
        assert result is not None
        mock_farm_client.cancel_order.assert_awaited_once_with("ord-001")


# ---------------------------------------------------------------------------
# History helpers at harness level
# ---------------------------------------------------------------------------

class TestHistoryWrappers:
    @pytest.mark.asyncio
    async def test_get_deal_history(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import get_deal_history
            deals = await get_deal_history(0, 9999999, user=FAKE_USER)
        assert isinstance(deals, list)

    @pytest.mark.asyncio
    async def test_get_deals_by_ticket(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import get_deals_by_ticket
            deals = await get_deals_by_ticket("deal-001", user=FAKE_USER)
        assert isinstance(deals, list)

    @pytest.mark.asyncio
    async def test_get_deals_by_position(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import get_deals_by_position
            deals = await get_deals_by_position("pos-001", user=FAKE_USER)
        assert isinstance(deals, list)

    @pytest.mark.asyncio
    async def test_get_history_orders_by_ticket(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import get_history_orders_by_ticket
            orders = await get_history_orders_by_ticket("ord-001", user=FAKE_USER)
        assert isinstance(orders, list)

    @pytest.mark.asyncio
    async def test_get_history_orders_by_time_range(self, mock_farm_client, farm_mode):
        with _patch_dispatcher(mock_farm_client):
            from harness import get_history_orders_by_time_range
            orders = await get_history_orders_by_time_range(
                "2024-01-01", "2024-01-31", user=FAKE_USER
            )
        assert isinstance(orders, list)
