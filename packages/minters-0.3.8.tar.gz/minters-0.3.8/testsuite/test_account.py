"""
testsuite/test_account.py
===========================
Tests for harness.account functions.
All HTTP traffic is intercepted at dispatcher level.
"""
from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from .conftest import (
    FAKE_USER,
    FAKE_ACCOUNT_INFO,
    FAKE_POSITION,
    FAKE_ORDER,
    FAKE_DEAL,
    patch_get_client,
)


# ---------------------------------------------------------------------------
# get_account_snapshot
# ---------------------------------------------------------------------------

class TestGetAccountSnapshot:
    @pytest.mark.asyncio
    async def test_returns_account_info(self, mock_farm_client):
        with patch_get_client(mock_farm_client):
            from harness.barn.account.creds import get_account_snapshot
            result = await get_account_snapshot(user=FAKE_USER)
        assert result is not None
        assert "balance" in result or "equity" in result

    @pytest.mark.asyncio
    async def test_no_user_context(self, mock_farm_client):
        with patch_get_client(mock_farm_client):
            from harness.barn.account.creds import get_account_snapshot
            result = await get_account_snapshot(user=None)
        assert result is not None


# ---------------------------------------------------------------------------
# get_open_positions
# ---------------------------------------------------------------------------

class TestGetOpenPositions:
    @pytest.mark.asyncio
    async def test_returns_list(self, mock_farm_client):
        with patch_get_client(mock_farm_client):
            from harness.barn.account.positions import get_open_positions
            positions = await get_open_positions(symbol="EURUSD", user=FAKE_USER)
        assert isinstance(positions, list)

    @pytest.mark.asyncio
    async def test_symbol_filter_none(self, mock_farm_client):
        with patch_get_client(mock_farm_client):
            from harness.barn.account.positions import get_open_positions
            positions = await get_open_positions(symbol=None, user=FAKE_USER)
        assert isinstance(positions, list)


# ---------------------------------------------------------------------------
# get_pending_orders
# ---------------------------------------------------------------------------

class TestGetPendingOrders:
    @pytest.mark.asyncio
    async def test_returns_list(self, mock_farm_client):
        with patch_get_client(mock_farm_client):
            from harness.barn.account.positions import get_pending_orders
            orders = await get_pending_orders(symbol="EURUSD", order_type=None, user=FAKE_USER)
        assert isinstance(orders, list)


# ---------------------------------------------------------------------------
# get_closed_orders
# ---------------------------------------------------------------------------

class TestGetClosedOrders:
    @pytest.mark.asyncio
    async def test_returns_list(self, mock_farm_client):
        with patch_get_client(mock_farm_client):
            from harness.barn.account.history import get_closed_orders
            orders = await get_closed_orders(
                symbol="EURUSD",
                start_time=None,
                end_time=None,
                limit=50,
                user=FAKE_USER,
            )
        assert isinstance(orders, list)
