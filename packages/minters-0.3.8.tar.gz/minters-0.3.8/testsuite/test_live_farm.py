# testsuite/test_live_farm.py  (a separate integration test file)
import pytest
import os
from harness.barn.core.farm_client import FarmClient

@pytest.mark.skipif(not os.environ.get("LIVE_FARM"), reason="LIVE_FARM not set")
async def test_live_account_snapshot():
    client = await FarmClient.get("sim")
    info = await client.get_account_information()
    assert info["balance"] > 0