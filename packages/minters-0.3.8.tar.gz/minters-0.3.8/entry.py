"""
Modal deployment entry-point — deploy with:

    modal deploy entry.py

The `api` function serves the harness FastAPI router as an ASGI app on
Modal's serverless infrastructure.  It runs inside `minter-image` which
bundles the harness, regulator, and contracts directories.

Environment secrets (configured in your Modal workspace):
    mint-secrets   — BROKER_MODE, METAAPI_TOKEN, METAAPI_ACCOUNT_ID,
                     MASTER_ACCOUNT_ID, FARM_BASE_URL, FARM_PORT …
    github         — GITHUB_TOKEN (for private package installs)
    rig            — any additional rig-specific secrets
"""

import sys
import modal

# ---------------------------------------------------------------------------
# Image — built once, cached by Modal
# ---------------------------------------------------------------------------

image = (
    modal.Image.debian_slim(python_version="3.12")
    # Install Python dependencies first so the layer is cached independently
    # of source code changes.
    .pip_install_from_requirements("requirements.txt")
    # Application source directories
    .add_local_dir("harness",   "/app/harness",   copy=True)
    .add_local_dir("regulator", "/app/regulator", copy=True)
    .add_local_dir("contracts", "/app/contracts", copy=True)
)

# ---------------------------------------------------------------------------
# Modal app
# ---------------------------------------------------------------------------

app = modal.App("minter")

# ---------------------------------------------------------------------------
# ASGI endpoint — the main FastAPI router
# ---------------------------------------------------------------------------

@app.function(
    image=image,
    timeout=3600,
    min_containers=0,
    secrets=[
        modal.Secret.from_name("mint"),
    ],
)
@modal.asgi_app()
def api():
    """Serve the harness FastAPI router as a Modal ASGI app."""
    sys.path.insert(0, "/app")
    from harness.router import app as fastapi_app
    return fastapi_app


# ---------------------------------------------------------------------------
# Local helper
# ---------------------------------------------------------------------------

@app.local_entrypoint()
def main():
    print("Deploy:  modal deploy entry.py")
    print("Serve:   modal serve entry.py")

