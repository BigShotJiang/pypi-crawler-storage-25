from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Sequence

from .workspace import bootstrap_workspace, resolve_workspace_root


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="minters", description="Run the Mint Seal application.")
    subparsers = parser.add_subparsers(dest="command")

    run_parser = subparsers.add_parser("run", help="Launch the Seal UI.")
    run_parser.add_argument("--workspace", type=Path, help="Path to the writable Mint workspace.")
    run_parser.add_argument("--model", help="Override REGULATOR_MODEL for this session.")

    workspace_parser = subparsers.add_parser("workspace", help="Print the resolved workspace path.")
    workspace_parser.add_argument("--workspace", type=Path, help="Path to the writable Mint workspace.")

    return parser


def _prepare_workspace(explicit: Path | None = None) -> Path:
    workspace_root = resolve_workspace_root(explicit)
    os.environ["MINTERS_WORKSPACE"] = str(workspace_root)
    os.environ["MINT_WORKSPACE"] = str(workspace_root)
    return workspace_root


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    command = args.command or "run"

    if command == "workspace":
        workspace_root = _prepare_workspace(getattr(args, "workspace", None))
        print(workspace_root)
        return 0

    if command != "run":
        parser.error(f"Unknown command: {command}")

    workspace_root = _prepare_workspace(args.workspace)
    if args.model:
        os.environ["REGULATOR_MODEL"] = args.model

    from regulator.seal import SealApp

    bootstrap_workspace(workspace_root)
    SealApp(model_name=os.environ.get("REGULATOR_MODEL", args.model or "1984-m3-0421")).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
