from __future__ import annotations

import importlib
import os
import shutil
from pathlib import Path

WORKSPACE_MARKERS = ("contracts", "harness", "regulator")
PACKAGE_DIRS = ("minters", "harness", "farm", "regulator")
SEED_DIRS = ("archive", "buildfile", "contracts", "testsuite")
SEED_FILES = ("README.md", "entry.py", "pyproject.toml", "requirements.txt")


def looks_like_workspace(path: Path) -> bool:
    return all((path / marker).exists() for marker in WORKSPACE_MARKERS)


def default_workspace_root() -> Path:
    data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return (data_home / "minters" / "workspace").expanduser().resolve()


def _package_dir(package_name: str) -> Path:
    module = importlib.import_module(package_name)
    module_file = getattr(module, "__file__", None)
    if not module_file:
        raise RuntimeError(f"Cannot resolve package path for {package_name}")
    return Path(module_file).resolve().parent


def _seed_root() -> Path:
    packaged_seed = Path(__file__).resolve().parent / "_seed"
    if packaged_seed.exists():
        return packaged_seed
    return Path(__file__).resolve().parent.parent


def _copy_ignores(_: str, names: list[str]) -> set[str]:
    ignored = {"__pycache__", ".pytest_cache", ".DS_Store", "target"}
    return {name for name in names if name in ignored or name.endswith((".pyc", ".pyo"))}


def _copy_path_if_missing(source: Path, target: Path) -> bool:
    if target.exists() or not source.exists():
        return False
    if source.is_dir():
        shutil.copytree(source, target, ignore=_copy_ignores)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    return True


def _seed_file_source(seed_root: Path, file_name: str) -> Path:
    if file_name == "requirements.txt":
        alternate = seed_root / "minters" / file_name
        if alternate.exists():
            return alternate
    return seed_root / file_name


def bootstrap_workspace(root: str | Path) -> tuple[Path, bool]:
    workspace_root = Path(root).expanduser().resolve()
    workspace_root.mkdir(parents=True, exist_ok=True)
    created = False

    for package_name in PACKAGE_DIRS:
        created = _copy_path_if_missing(_package_dir(package_name), workspace_root / package_name) or created

    seed_root = _seed_root()
    for directory in SEED_DIRS:
        created = _copy_path_if_missing(seed_root / directory, workspace_root / directory) or created
    for file_name in SEED_FILES:
        created = _copy_path_if_missing(_seed_file_source(seed_root, file_name), workspace_root / file_name) or created

    return workspace_root, created


def resolve_workspace_root(explicit: str | Path | None = None, *, create: bool = True) -> Path:
    candidate: Path | None = None

    if explicit:
        candidate = Path(explicit).expanduser()
    else:
        for env_name in ("MINTERS_WORKSPACE", "MINT_WORKSPACE"):
            env_value = os.environ.get(env_name, "").strip()
            if env_value:
                candidate = Path(env_value).expanduser()
                break

    if candidate is None:
        cwd = Path.cwd().resolve()
        if looks_like_workspace(cwd):
            return cwd
        candidate = default_workspace_root()

    if create:
        resolved, _ = bootstrap_workspace(candidate)
        return resolved

    return candidate.resolve()
