import os
import subprocess
import sys

commit_types = {
    "build:": "major",
    "feat:": "minor",
    "chore:": "patch",
}


def _write_github_output(key: str, value: str) -> None:
    """Write a key=value pair to $GITHUB_OUTPUT when running in CI."""
    output_file = os.environ.get("GITHUB_OUTPUT", "")
    if output_file:
        with open(output_file, "a") as f:
            f.write(f"{key}={value}\n")


try:
    # Get the commit message from command-line arguments
    commit_message = sys.argv[1]
    if not commit_message:
        raise ValueError("Please provide a commit message.")

    # Determine the type of change based on the commit message
    commit_type = next(
        (prefix for prefix in commit_types.keys() if commit_message.startswith(prefix)),
        None,
    )

    if not commit_type:
        print(
            "No recognized commit type found (expected build:, feat:, or chore:). "
            "Skipping version bump and release."
        )
        _write_github_output("released", "false")
        sys.exit(0)

    # Read the current version from pyproject.toml
    with open("pyproject.toml", "r") as toml_file:
        toml_content = toml_file.read()
        current_version = toml_content.split('version = "')[1].split('"')[0]

    # Increment the version based on the commit type
    parts = current_version.split(".")
    version_bump = commit_types[commit_type]
    if version_bump == "major":
        parts[0] = str(int(parts[0]) + 1)
        parts[1] = "0"
        parts[2] = "0"
    elif version_bump == "minor":
        parts[1] = str(int(parts[1]) + 1)
        parts[2] = "0"
    else:
        parts[2] = str(int(parts[2]) + 1)
    next_version = ".".join(parts)

    # Update pyproject.toml with the new version
    toml_content = toml_content.replace(
        f'version = "{current_version}"', f'version = "{next_version}"'
    )
    with open("pyproject.toml", "w") as toml_file:
        toml_file.write(toml_content)

    # Commit the version update and tag the commit.
    # Use a CI-skip message so the release commit does not recursively retrigger the workflow.
    subprocess.run(["git", "add", "pyproject.toml"], check=True)
    subprocess.run(
        ["git", "commit", "-m", f"chore: release v{next_version} [skip ci]"],
        check=True,
    )

    # Create the appropriate tag
    tag_name = f"v{next_version}"
    tag_message = f"{commit_type.capitalize()} release: {next_version}"
    subprocess.run(
        ["git", "tag", tag_name, "-a", "-m", tag_message], check=True
    )

    _write_github_output("released", "true")
    _write_github_output("version", next_version)
    _write_github_output("tag", tag_name)

    # # Build distribution archives
    # subprocess.run(["python", "-m", "pip", "install", "--upgrade", "build"], check=True)
    # subprocess.run(["python", "-m", "build"], check=True)

    # # Upload the distribution archives to PyPI using twine
    # subprocess.run(["python", "-m", "pip", "install", "--upgrade", "twine"], check=True)
    # subprocess.run(
    #     ["python", "-m", "twine", "upload", "--repository", "testpypi", "dist/*"],
    #     check=True,
    # )
except Exception as e:
    _write_github_output("released", "false")
    print("An error occurred:", str(e))
    sys.exit(1)

