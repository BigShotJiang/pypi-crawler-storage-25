"""
MT5 Server Farm - Automated Trading Infrastructure

A scalable, automated MT5 server farm on Windows capable of managing 
multiple accounts, executing high-frequency trades, and streaming 
real-time data to an external Python brain.

Architecture:
- Host: Windows Server 2022 (or Win 10/11 Pro) VM
- Core: Python 3.11+ Asyncio Controller
- Nodes: Multiple portable MT5 instances (one per trading account)
- Link: Localhost TCP Sockets for low latency (<0.2ms)
- Bridge: Custom C++ DLL + MQL5 Expert Advisor
- Interface: FastAPI Router (REST + WebSockets)

Modules:
- bridge/: C++ DLL and MQL5 Expert Advisor sources
- controller/: Python asyncio TCP server (the "brain")
- provisioner/: Account provisioning and instance management
- api/: FastAPI REST + WebSocket interface
- config/: Configuration schemas and templates
"""

__version__ = "0.1.0"
