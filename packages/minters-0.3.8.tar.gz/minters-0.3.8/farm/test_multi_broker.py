"""
MT5 Farm Multi-Broker Integration Test
=======================================
Full end-to-end test with multiple broker servers:
1. Clear all existing accounts
2. Reprovision 3 trial accounts (Exness-MT5Trial9)
3. Provision 1 real account (Exness-MT5Real30) - DIFFERENT BROKER
4. Test broker discovery for new server
5. Verify all accounts connect and operate
"""

import asyncio
import httpx
import time
from typing import List, Dict, Any

FARM_BASE = "http://localhost:8000/farm"

# Test accounts - 3 trial + 1 real with DIFFERENT broker server
TEST_ACCOUNTS = [
    {"login": 297102439, "password": "2Factorauth12--", "server": "Exness-MT5Trial9"},
    {"login": 297278718, "password": "2Factorauth12--", "server": "Exness-MT5Trial9"},
    {"login": 297278732, "password": "2Factorauth12--", "server": "Exness-MT5Trial9"},
    {"login": 223094595, "password": "Ayomide@2004", "server": "Exness-MT5Real30"},  # DIFFERENT BROKER
]


class MultiBrokerTest:
    """Tests farm with multiple broker servers."""
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=120.0)
        self.results = {"passed": 0, "failed": 0, "warnings": 0}
    
    async def close(self):
        await self.client.aclose()
    
    def section(self, title: str):
        print()
        print("=" * 70)
        print(title)
        print("=" * 70)
    
    def log(self, msg: str, indent: int = 0):
        print("  " * indent + msg)
    
    def success(self, msg: str):
        self.results["passed"] += 1
        self.log(f"✅ {msg}")
    
    def fail(self, msg: str):
        self.results["failed"] += 1
        self.log(f"❌ {msg}")
    
    def warn(self, msg: str):
        self.results["warnings"] += 1
        self.log(f"⚠️  {msg}")
    
    # ================
    # Phase 1: Cleanup
    # ================
    
    async def cleanup_all_accounts(self):
        """Terminate all existing accounts."""
        self.section("PHASE 1: CLEANUP ALL EXISTING ACCOUNTS")
        
        try:
            # Get current instances
            resp = await self.client.get(f"{FARM_BASE}/instances")
            instances = resp.json().get("instances", [])
            self.log(f"Found {len(instances)} existing instances")
            
            for inst in instances:
                account_id = inst.get("account_id")
                if account_id:
                    self.log(f"Terminating {account_id}...", 1)
                    try:
                        await self.client.delete(
                            f"{FARM_BASE}/provision/{account_id}",
                            params={"cleanup": "false"}
                        )
                        self.success(f"Terminated {account_id}")
                    except Exception as e:
                        self.warn(f"Could not terminate {account_id}: {e}")
            
            # Wait for processes to close
            self.log("\nWaiting for processes to terminate...")
            await asyncio.sleep(5)
            
        except Exception as e:
            self.fail(f"Cleanup failed: {e}")
    
    # ================
    # Phase 2: Broker Discovery
    # ================
    
    async def test_broker_discovery(self):
        """Test broker discovery for new server."""
        self.section("PHASE 2: BROKER DISCOVERY")
        
        # Search for Exness-MT5Real30
        self.log("Searching for 'Exness-MT5Real30'...")
        try:
            resp = await self.client.get(
                f"{FARM_BASE}/brokers/search",
                params={"query": "Exness-MT5Real30"}
            )
            if resp.status_code == 200:
                data = resp.json()
                results = data.get("results", [])
                self.success(f"Broker search returned {len(results)} results")
                for r in results[:3]:
                    self.log(f"  - {r.get('server', 'N/A')}: {r.get('company', 'N/A')}", 1)
            else:
                self.warn(f"Broker search failed: {resp.status_code}")
        except Exception as e:
            self.warn(f"Broker search error: {e}")
        
        # Prepare broker
        self.log("\nPreparing 'Exness-MT5Real30' for provisioning...")
        try:
            resp = await self.client.post(
                f"{FARM_BASE}/brokers/prepare",
                json={"server": "Exness-MT5Real30"}
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success"):
                    self.success(f"Broker prepared: {data.get('company', 'N/A')}")
                else:
                    self.warn(f"Broker not ready: {data.get('message', 'unknown')}")
            else:
                self.warn(f"Broker prepare failed: {resp.status_code}")
        except Exception as e:
            self.warn(f"Broker prepare error: {e}")
        
        # Also prepare Trial9 for completeness
        self.log("\nPreparing 'Exness-MT5Trial9'...")
        try:
            resp = await self.client.post(
                f"{FARM_BASE}/brokers/prepare",
                json={"server": "Exness-MT5Trial9"}
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success"):
                    self.success(f"Broker prepared: {data.get('company', 'N/A')}")
        except Exception as e:
            self.warn(f"Broker prepare error: {e}")
    
    # ================
    # Phase 3: Provision All Accounts
    # ================
    
    async def provision_all_accounts(self):
        """Provision all 4 test accounts."""
        self.section("PHASE 3: PROVISION ALL ACCOUNTS (4 total)")
        
        for account in TEST_ACCOUNTS:
            account_id = f"Account_{account['login']}"
            self.log(f"\nProvisioning {account_id} ({account['server']})...")
            
            try:
                resp = await self.client.post(
                    f"{FARM_BASE}/provision",
                    json={
                        "account_id": account_id,
                        "login": account["login"],
                        "password": account["password"],
                        "server": account["server"],
                        "auto_launch": True
                    }
                )
                
                if resp.status_code == 200:
                    data = resp.json()
                    self.success(f"Provisioned {account_id} (pid={data.get('pid', 'N/A')})")
                else:
                    error = resp.json().get("detail", resp.text)
                    if "being used by another process" in error:
                        self.warn(f"{account_id} already running")
                    else:
                        self.fail(f"Failed to provision {account_id}: {error[:50]}")
                        
            except Exception as e:
                self.fail(f"Exception provisioning {account_id}: {e}")
    
    # ================
    # Phase 4: Wait for Connections
    # ================
    
    async def wait_for_connections(self, timeout: int = 90) -> List[str]:
        """Wait for EA connections."""
        self.section("PHASE 4: WAIT FOR EA CONNECTIONS")
        
        expected = len(TEST_ACCOUNTS)
        start = time.time()
        connected = []
        
        while time.time() - start < timeout:
            try:
                resp = await self.client.get(f"{FARM_BASE}/status")
                data = resp.json()
                nodes = data.get("nodes", [])
                
                connected = [n["account_id"] for n in nodes if n.get("state") == "authenticated"]
                alive = len(connected)
                
                self.log(f"Connected: {alive}/{expected} accounts ({int(time.time() - start)}s)")
                
                for n in nodes:
                    state = n.get("state", "unknown")
                    acc = n.get("account_id", "unknown")
                    self.log(f"  - {acc}: {state}", 1)
                
                if alive >= expected:
                    self.success(f"All {expected} accounts connected!")
                    return connected
                
                # If we have at least 2, continue
                if alive >= 2 and time.time() - start > 30:
                    self.warn(f"Proceeding with {alive} accounts after 30s")
                    return connected
                    
            except Exception as e:
                self.warn(f"Status check error: {e}")
            
            await asyncio.sleep(5)
        
        self.warn(f"Timeout: only {len(connected)} accounts connected")
        return connected
    
    # ================
    # Phase 5: Test All Accounts
    # ================
    
    async def test_all_accounts(self, accounts: List[str]):
        """Test operations on all connected accounts."""
        self.section("PHASE 5: TEST ALL CONNECTED ACCOUNTS")
        
        for account_id in accounts:
            self.log(f"\n--- Testing {account_id} ---")
            
            # Account info
            try:
                resp = await self.client.get(f"{FARM_BASE}/account/{account_id}")
                if resp.status_code == 200:
                    data = resp.json()
                    self.success(f"Account: balance={data.get('balance')}, equity={data.get('equity')}")
                else:
                    self.fail(f"Account info failed: {resp.status_code}")
            except Exception as e:
                self.fail(f"Account info error: {e}")
            
            # Symbol info
            try:
                resp = await self.client.get(f"{FARM_BASE}/symbol/{account_id}/EURUSDm")
                if resp.status_code == 200:
                    data = resp.json()
                    self.success(f"Symbol: bid={data.get('bid')}, ask={data.get('ask')}")
                else:
                    self.fail(f"Symbol info failed: {resp.status_code}")
            except Exception as e:
                self.fail(f"Symbol info error: {e}")
            
            # Historical data
            try:
                resp = await self.client.get(
                    f"{FARM_BASE}/history/{account_id}",
                    params={"symbol": "EURUSDm", "timeframe": "H1", "count": 10}
                )
                if resp.status_code == 200:
                    data = resp.json()
                    bars = len(data.get("rates", []))
                    self.success(f"History: {bars} bars")
                else:
                    self.fail(f"History failed: {resp.status_code}")
            except Exception as e:
                self.fail(f"History error: {e}")
    
    # ================
    # Phase 6: Concurrent Multi-Broker Test
    # ================
    
    async def test_concurrent_multi_broker(self, accounts: List[str]):
        """Test concurrent operations across different broker servers."""
        self.section("PHASE 6: CONCURRENT MULTI-BROKER OPERATIONS")
        
        if len(accounts) < 2:
            self.warn("Need at least 2 accounts for concurrent test")
            return
        
        self.log(f"Testing {len(accounts)} accounts concurrently...")
        
        # Concurrent account info
        self.log("\n1. Concurrent Account Info:")
        start = time.time()
        tasks = [self.client.get(f"{FARM_BASE}/account/{acc}") for acc in accounts]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        success = sum(1 for r in results if hasattr(r, "status_code") and r.status_code == 200)
        self.success(f"{success}/{len(accounts)} accounts ({duration:.0f}ms)")
        
        # Concurrent symbol info across different symbols
        self.log("\n2. Concurrent Symbol Info (4 symbols x N accounts):")
        symbols = ["EURUSDm", "GBPUSDm", "USDJPYm", "XAUUSDm"]
        start = time.time()
        tasks = []
        for acc in accounts:
            for sym in symbols:
                tasks.append(self.client.get(f"{FARM_BASE}/symbol/{acc}/{sym}"))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        success = sum(1 for r in results if hasattr(r, "status_code") and r.status_code == 200)
        self.success(f"{success}/{len(tasks)} requests ({duration:.0f}ms)")
        
        # Concurrent historical data
        self.log("\n3. Concurrent Historical Data:")
        start = time.time()
        tasks = [
            self.client.get(f"{FARM_BASE}/history/{acc}", params={"symbol": "EURUSDm", "timeframe": "H1", "count": 50})
            for acc in accounts
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        success = sum(1 for r in results if hasattr(r, "status_code") and r.status_code == 200)
        self.success(f"{success}/{len(accounts)} history requests ({duration:.0f}ms)")
    
    # ================
    # Summary
    # ================
    
    def print_summary(self):
        self.section("TEST SUMMARY")
        
        total = self.results["passed"] + self.results["failed"]
        
        print(f"\n✅ Passed: {self.results['passed']}")
        print(f"❌ Failed: {self.results['failed']}")
        print(f"⚠️  Warnings: {self.results['warnings']}")
        print(f"\nPass Rate: {100 * self.results['passed'] // total if total else 0}%")


async def main():
    print("=" * 70)
    print("MT5 FARM MULTI-BROKER INTEGRATION TEST")
    print("=" * 70)
    print(f"Testing {len(TEST_ACCOUNTS)} accounts across 2 broker servers:")
    for acc in TEST_ACCOUNTS:
        print(f"  - {acc['login']} @ {acc['server']}")
    print()
    
    test = MultiBrokerTest()
    
    try:
        # Phase 1: Cleanup
        await test.cleanup_all_accounts()
        
        # Phase 2: Broker discovery
        await test.test_broker_discovery()
        
        # Phase 3: Provision
        await test.provision_all_accounts()
        
        # Phase 4: Wait for connections
        connected = await test.wait_for_connections(timeout=60)
        
        if not connected:
            print("\n❌ No accounts connected - check MT5 terminals")
            return
        
        # Phase 5: Test individual accounts
        await test.test_all_accounts(connected)
        
        # Phase 6: Concurrent multi-broker
        await test.test_concurrent_multi_broker(connected)
        
        # Summary
        test.print_summary()
        
    finally:
        await test.close()


if __name__ == "__main__":
    asyncio.run(main())
