"""
MT5 Farm End-to-End Test Script
================================
Tests all farm operations from provisioning to trading.

Test Accounts:
- 297102439 (Exness-MT5Trial9)
- 297278718 (Exness-MT5Trial9)
- 297278732 (Exness-MT5Trial9)
"""

import asyncio
import httpx
import time
from typing import Dict, Any

# Farm API base URL
FARM_BASE = "http://localhost:8000/farm"

# Test accounts
TEST_ACCOUNTS = [
    {"login": 297102439, "password": "2Factorauth12--", "server": "Exness-MT5Trial9"},
    {"login": 297278718, "password": "2Factorauth12--", "server": "Exness-MT5Trial9"},
    {"login": 297278732, "password": "2Factorauth12--", "server": "Exness-MT5Trial9"},
]


class FarmTestSuite:
    """Complete end-to-end test suite for MT5 Farm."""
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=60.0)
        self.results = {"passed": 0, "failed": 0, "errors": []}
        self.provisioned_accounts = []
    
    async def close(self):
        await self.client.aclose()
    
    def log(self, message: str, indent: int = 0):
        prefix = "  " * indent
        print(f"{prefix}{message}")
    
    def success(self, test_name: str, details: str = ""):
        self.results["passed"] += 1
        self.log(f"✅ {test_name}: {details}")
    
    def fail(self, test_name: str, error: str):
        self.results["failed"] += 1
        self.results["errors"].append(f"{test_name}: {error}")
        self.log(f"❌ {test_name}: {error}")
    
    # ==================
    # Health & Status
    # ==================
    
    async def test_health(self) -> bool:
        """Test health endpoint."""
        try:
            resp = await self.client.get("http://localhost:8000/health")
            if resp.status_code == 200:
                data = resp.json()
                self.success("Health Check", f"status={data.get('status')}")
                return True
            else:
                self.fail("Health Check", f"status_code={resp.status_code}")
                return False
        except Exception as e:
            self.fail("Health Check", str(e))
            return False
    
    async def test_farm_status(self) -> Dict[str, Any]:
        """Test farm status endpoint."""
        try:
            resp = await self.client.get(f"{FARM_BASE}/status")
            if resp.status_code == 200:
                data = resp.json()
                self.success("Farm Status", f"nodes={data.get('total_nodes')}, alive={data.get('alive_nodes')}")
                return data
            else:
                self.fail("Farm Status", f"status_code={resp.status_code}")
                return {}
        except Exception as e:
            self.fail("Farm Status", str(e))
            return {}
    
    # ==================
    # Provisioning
    # ==================
    
    async def test_provision_account(self, login: int, password: str, server: str) -> str:
        """Provision a new account via API."""
        account_id = f"Account_{login}"
        try:
            resp = await self.client.post(
                f"{FARM_BASE}/provision",
                json={
                    "account_id": account_id,
                    "login": login,
                    "password": password,
                    "server": server,
                    "auto_launch": False  # Don't auto-launch, we'll test launch separately
                }
            )
            if resp.status_code == 200:
                data = resp.json()
                self.success(f"Provision {login}", f"path={data.get('path', 'N/A')[:40]}...")
                self.provisioned_accounts.append(account_id)
                return account_id
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Provision {login}", f"status={resp.status_code}: {error}")
                return ""
        except Exception as e:
            self.fail(f"Provision {login}", str(e))
            return ""
    
    async def test_launch_account(self, account_id: str) -> bool:
        """Launch a provisioned account."""
        try:
            resp = await self.client.post(f"{FARM_BASE}/launch/{account_id}")
            if resp.status_code == 200:
                data = resp.json()
                self.success(f"Launch {account_id}", f"pid={data.get('pid', 'N/A')}")
                return True
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Launch {account_id}", f"status={resp.status_code}: {error}")
                return False
        except Exception as e:
            self.fail(f"Launch {account_id}", str(e))
            return False
    
    async def test_list_instances(self) -> list:
        """List all provisioned instances."""
        try:
            resp = await self.client.get(f"{FARM_BASE}/instances")
            if resp.status_code == 200:
                data = resp.json()
                instances = data.get("instances", [])
                self.success("List Instances", f"count={len(instances)}")
                return instances
            else:
                self.fail("List Instances", f"status={resp.status_code}")
                return []
        except Exception as e:
            self.fail("List Instances", str(e))
            return []
    
    # ==================
    # Account Data
    # ==================
    
    async def test_account_info(self, account_id: str) -> Dict[str, Any]:
        """Get account information."""
        try:
            resp = await self.client.get(f"{FARM_BASE}/account/{account_id}")
            if resp.status_code == 200:
                data = resp.json()
                self.success(
                    f"Account Info ({account_id})",
                    f"balance={data.get('balance')}, equity={data.get('equity')}, leverage={data.get('leverage')}"
                )
                return data
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Account Info ({account_id})", f"status={resp.status_code}: {error}")
                return {}
        except Exception as e:
            self.fail(f"Account Info ({account_id})", str(e))
            return {}
    
    async def test_positions(self, account_id: str) -> list:
        """Get open positions."""
        try:
            resp = await self.client.get(f"{FARM_BASE}/positions/{account_id}")
            if resp.status_code == 200:
                data = resp.json()
                positions = data.get("positions", [])
                self.success(f"Positions ({account_id})", f"count={len(positions)}")
                return positions
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Positions ({account_id})", f"status={resp.status_code}: {error}")
                return []
        except Exception as e:
            self.fail(f"Positions ({account_id})", str(e))
            return []
    
    async def test_pending_orders(self, account_id: str) -> list:
        """Get pending orders."""
        try:
            resp = await self.client.get(f"{FARM_BASE}/orders/{account_id}")
            if resp.status_code == 200:
                data = resp.json()
                orders = data.get("orders", [])
                self.success(f"Pending Orders ({account_id})", f"count={len(orders)}")
                return orders
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Pending Orders ({account_id})", f"status={resp.status_code}: {error}")
                return []
        except Exception as e:
            self.fail(f"Pending Orders ({account_id})", str(e))
            return []
    
    async def test_deal_history(self, account_id: str) -> list:
        """Get deal history."""
        try:
            resp = await self.client.get(f"{FARM_BASE}/deals/{account_id}")
            if resp.status_code == 200:
                data = resp.json()
                deals = data.get("deals", [])
                self.success(f"Deal History ({account_id})", f"count={len(deals)}")
                return deals
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Deal History ({account_id})", f"status={resp.status_code}: {error}")
                return []
        except Exception as e:
            self.fail(f"Deal History ({account_id})", str(e))
            return []
    
    # ==================
    # Market Data
    # ==================
    
    async def test_symbol_info(self, account_id: str, symbol: str = "EURUSDm") -> Dict[str, Any]:
        """Get symbol information."""
        try:
            resp = await self.client.get(f"{FARM_BASE}/symbol/{account_id}/{symbol}")
            if resp.status_code == 200:
                data = resp.json()
                self.success(
                    f"Symbol Info ({symbol})",
                    f"bid={data.get('bid')}, ask={data.get('ask')}, digits={data.get('digits')}"
                )
                return data
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Symbol Info ({symbol})", f"status={resp.status_code}: {error}")
                return {}
        except Exception as e:
            self.fail(f"Symbol Info ({symbol})", str(e))
            return {}
    
    async def test_current_price(self, account_id: str, symbol: str = "EURUSDm") -> Dict[str, Any]:
        """Get current price."""
        try:
            resp = await self.client.get(f"{FARM_BASE}/price/{account_id}/{symbol}")
            if resp.status_code == 200:
                data = resp.json()
                self.success(f"Current Price ({symbol})", f"bid={data.get('bid')}, ask={data.get('ask')}")
                return data
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Current Price ({symbol})", f"status={resp.status_code}: {error}")
                return {}
        except Exception as e:
            self.fail(f"Current Price ({symbol})", str(e))
            return {}
    
    async def test_historical_rates(self, account_id: str, symbol: str = "EURUSDm", timeframe: str = "H1") -> list:
        """Get historical rates."""
        try:
            resp = await self.client.get(
                f"{FARM_BASE}/history/{account_id}",
                params={"symbol": symbol, "timeframe": timeframe, "count": 10}
            )
            if resp.status_code == 200:
                data = resp.json()
                rates = data.get("rates", [])
                self.success(f"Historical Rates ({symbol}/{timeframe})", f"count={len(rates)}")
                return rates
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Historical Rates ({symbol}/{timeframe})", f"status={resp.status_code}: {error}")
                return []
        except Exception as e:
            self.fail(f"Historical Rates ({symbol}/{timeframe})", str(e))
            return []
    
    # ==================
    # Trading Operations
    # ==================
    
    async def test_market_buy(self, account_id: str, symbol: str = "EURUSDm", volume: float = 0.01) -> Dict[str, Any]:
        """Execute a market buy order."""
        try:
            resp = await self.client.post(
                f"{FARM_BASE}/trade/{account_id}",
                json={"action": "buy", "symbol": symbol, "volume": volume}
            )
            if resp.status_code == 200:
                data = resp.json()
                self.success(f"Market BUY ({symbol})", f"ticket={data.get('ticket')}, success={data.get('success')}")
                return data
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Market BUY ({symbol})", f"status={resp.status_code}: {error}")
                return {}
        except Exception as e:
            self.fail(f"Market BUY ({symbol})", str(e))
            return {}
    
    async def test_market_sell(self, account_id: str, symbol: str = "EURUSDm", volume: float = 0.01) -> Dict[str, Any]:
        """Execute a market sell order."""
        try:
            resp = await self.client.post(
                f"{FARM_BASE}/trade/{account_id}",
                json={"action": "sell", "symbol": symbol, "volume": volume}
            )
            if resp.status_code == 200:
                data = resp.json()
                self.success(f"Market SELL ({symbol})", f"ticket={data.get('ticket')}, success={data.get('success')}")
                return data
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Market SELL ({symbol})", f"status={resp.status_code}: {error}")
                return {}
        except Exception as e:
            self.fail(f"Market SELL ({symbol})", str(e))
            return {}
    
    async def test_close_position(self, account_id: str, ticket: int) -> Dict[str, Any]:
        """Close a position by ticket."""
        try:
            resp = await self.client.post(
                f"{FARM_BASE}/close/{account_id}/{ticket}"
            )
            if resp.status_code == 200:
                data = resp.json()
                self.success(f"Close Position ({ticket})", f"success={data.get('success')}")
                return data
            else:
                error = resp.json().get("detail", resp.text)
                self.fail(f"Close Position ({ticket})", f"status={resp.status_code}: {error}")
                return {}
        except Exception as e:
            self.fail(f"Close Position ({ticket})", str(e))
            return {}
    
    # ==================
    # Broker Discovery
    # ==================
    
    async def test_broker_discovery(self) -> list:
        """Test broker discovery."""
        try:
            resp = await self.client.get(f"{FARM_BASE}/brokers")
            if resp.status_code == 200:
                data = resp.json()
                brokers = data.get("brokers", [])
                self.success("Broker Discovery", f"count={len(brokers)}")
                return brokers
            else:
                self.fail("Broker Discovery", f"status={resp.status_code}")
                return []
        except Exception as e:
            self.fail("Broker Discovery", str(e))
            return []
    
    # ==================
    # Main Test Runner
    # ==================
    
    async def run_all_tests(self):
        """Run all tests in sequence."""
        print("=" * 60)
        print("MT5 FARM END-TO-END TEST SUITE")
        print("=" * 60)
        print()
        
        # Phase 1: Health & Status
        print("PHASE 1: Health & Status")
        print("-" * 40)
        await self.test_health()
        status = await self.test_farm_status()
        await self.test_broker_discovery()
        await self.test_list_instances()
        print()
        
        # Phase 2: Provisioning (using existing accounts)
        print("PHASE 2: Account Provisioning")
        print("-" * 40)
        for account in TEST_ACCOUNTS:
            await self.test_provision_account(
                account["login"],
                account["password"],
                account["server"]
            )
        print()
        
        # Wait a moment for instances to register
        print("Waiting for instances to start...")
        await asyncio.sleep(3)
        
        # Get connected accounts from status
        status = await self.test_farm_status()
        connected_nodes = status.get("nodes", [])
        
        # Find first connected account to use for tests
        connected_account = None
        for node in connected_nodes:
            if node.get("state") == "authenticated":
                connected_account = node.get("account_id")
                print(f"\nUsing connected account: {connected_account}")
                break
        
        if not connected_account:
            print("\n⚠️  No authenticated accounts available for trading tests")
            print("   (Market may be closed or EAs not connected)")
            # Try with first provisioned account anyway
            if self.provisioned_accounts:
                connected_account = self.provisioned_accounts[0]
                print(f"   Trying with: {connected_account}")
        
        if connected_account:
            # Phase 3: Account Data
            print("\nPHASE 3: Account Data Operations")
            print("-" * 40)
            await self.test_account_info(connected_account)
            await self.test_positions(connected_account)
            await self.test_pending_orders(connected_account)
            await self.test_deal_history(connected_account)
            print()
            
            # Phase 4: Market Data
            print("PHASE 4: Market Data Operations")
            print("-" * 40)
            await self.test_symbol_info(connected_account, "EURUSDm")
            await self.test_current_price(connected_account, "EURUSDm")
            await self.test_historical_rates(connected_account, "EURUSDm", "H1")
            await self.test_historical_rates(connected_account, "GBPUSDm", "M5")
            print()
            
            # Phase 5: Trading (only if market is open)
            print("PHASE 5: Trading Operations")
            print("-" * 40)
            print("⚠️  Note: Market is closed on weekends - trades may fail")
            
            # Try market buy
            buy_result = await self.test_market_buy(connected_account, "EURUSDm", 0.01)
            
            # If buy succeeded, try to close the position
            if buy_result.get("success") and buy_result.get("ticket"):
                await asyncio.sleep(1)  # Small delay
                positions = await self.test_positions(connected_account)
                if positions:
                    ticket = positions[0].get("ticket")
                    if ticket:
                        await self.test_close_position(connected_account, ticket)
            
            # Try market sell
            sell_result = await self.test_market_sell(connected_account, "EURUSDm", 0.01)
            if sell_result.get("success") and sell_result.get("ticket"):
                await asyncio.sleep(1)
                positions = await self.test_positions(connected_account)
                if positions:
                    ticket = positions[0].get("ticket")
                    if ticket:
                        await self.test_close_position(connected_account, ticket)
        
        print()
        
        # Summary
        print("=" * 60)
        print("TEST SUMMARY")
        print("=" * 60)
        print(f"✅ Passed: {self.results['passed']}")
        print(f"❌ Failed: {self.results['failed']}")
        if self.results["errors"]:
            print("\nErrors:")
            for error in self.results["errors"]:
                print(f"  - {error}")
        print()
        
        return self.results


async def main():
    """Run the test suite."""
    suite = FarmTestSuite()
    try:
        results = await suite.run_all_tests()
    finally:
        await suite.close()
    
    return results


if __name__ == "__main__":
    asyncio.run(main())
