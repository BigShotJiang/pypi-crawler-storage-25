# MT5 Farm Provisioning - Clean Setup Guide

## Problem Diagnosis

### Why Provisioning Fails

The current provisioning system copies the entire `MT5_MASTER` directory to create new account instances. However, this approach has critical flaws:

1. **Stale Configuration**: The `common.ini` file in MASTER contains login credentials and session state from whatever account was last logged in. When copied, this conflicts with the new account credentials being injected.

2. **Account-Specific Data**: Files like `accounts.dat` and `accounts64.dat` contain encrypted authentication tokens tied to specific accounts. Copying these causes "Invalid account" errors.

3. **Runtime State**: MT5 modifies configuration files while running. Copying a MASTER that has been used results in copying runtime state that doesn't match the new account.

4. **File Locking**: If MT5 is running from MASTER during copy, files may be locked or partially copied.

### The Solution: Clean Master Template

The correct approach is to maintain a **pristine MASTER** that contains:
- ✅ MT5 binaries (terminal64.exe, etc.)
- ✅ MQL5 code (MT5Bridge EA)
- ✅ Broker server data (Bases folder with symbol data)
- ✅ Global settings (EA permissions, allowed URLs)
- ❌ NO account-specific credentials
- ❌ NO runtime session state

---

## Step-by-Step Setup

### Step 1: Clean the Master

Run the cleanup script to remove all account-specific data:

```powershell
# Navigate to farm directory
cd c:\Users\tooig\play\farm

# Run cleanup script
.\tools\clean_master.ps1
```

**What this does:**
- Removes `Config/common.ini`, `Config/accounts.dat`, etc.
- Deletes `Bases/` folder (will be re-downloaded)
- Removes `Profiles/` (charts with account-specific settings)
- Keeps MT5 binaries and MQL5 code intact

**Important:** Make sure MT5 is NOT running from `C:\MT5_MASTER` before running this script!

---

### Step 2: Configure the Master

Now launch the clean MASTER and configure it manually:

```powershell
# Launch MT5 from MASTER
C:\MT5_MASTER\terminal64.exe
```

**Configuration checklist:**

1. **Expert Advisor Settings** (CRITICAL)
   - Go to: `Tools → Options → Expert Advisors`
   - ✅ Enable: "Allow algorithmic trading"
   - ✅ Enable: "Allow DLL imports"
   - ✅ Enable: "Allow WebRequest for listed URLs"
   - Click "Add URL" and enter: `127.0.0.1`
   - Click "OK"

2. **Add Broker**
   - Click "File → Open an Account"
   - Search for your broker (e.g., "Exness")
   - Select the server (e.g., "Exness-MT5Trial9")
   - Click "Next" → "Cancel" (we don't need to create an account)
   - This downloads the broker's server data to `Bases/` folder

3. **Login to Download Symbol Data** (OPTIONAL but recommended)
   - If you have a demo account, login once
   - Wait for symbol data to download (Market Watch will populate)
   - This creates the "golden seed" with market data
   - Then logout: `File → Login to Trade Account` → uncheck "Save account"

4. **Verify MT5Bridge EA**
   - Press `F4` to open MetaEditor
   - Navigate to: `Experts → MT5Bridge.mq5`
   - Press `F7` to compile
   - Verify `MT5Bridge.ex5` appears in `MQL5/Experts/`

5. **Close MT5 Completely**
   - `File → Exit`
   - Verify no `terminal64.exe` process is running

---

### Step 3: Verify the Master

Run the verification tool to ensure MASTER is ready:

```powershell
# Verify master configuration
python -m farm.tools.verify_master
```

**Expected output:**
```
✓ MT5 Terminal: terminal64.exe (XX MB)
✓ MT5Bridge EA (compiled): MT5Bridge.ex5
✓ Account config should be clean: clean
✓ Broker data found: 1 broker(s)
✓ MASTER IS READY FOR PROVISIONING
```

If any checks fail, follow the recommendations in the output.

---

### Step 4: Provision an Account

Now you can provision accounts using the API:

```powershell
# Start the farm server
python -m farm.main
```

In another terminal:

```powershell
# Provision a new account
$body = @{
    account_id = "test_12345"
    login = 12345678
    password = "your_password"
    server = "Exness-MT5Trial9"
    auto_launch = $true
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8000/farm/provision" `
    -Method POST -Body $body -ContentType "application/json"
```

**What happens during provisioning:**

1. **Clone MASTER** → `C:\MT5_FARM\Account_test_12345`
2. **Copy broker data** from `Bases/` (symbols, server config)
3. **Inject credentials** into `Config/common.ini`:
   ```ini
   [Common]
   Login=12345678
   Server=Exness-MT5Trial9
   Password=your_password
   ```
4. **Create pipe_id.txt** for EA identification:
   ```
   Account_test_12345,8888
   ```
5. **Launch MT5** from the new instance directory
6. **EA auto-connects** to the Python controller

---

## How Provisioning Works (Technical Details)

### File Structure After Provisioning

```
C:\MT5_FARM\Account_test_12345\
├── terminal64.exe          # MT5 binary (copied from MASTER)
├── Config\
│   ├── common.ini          # ✏️ MODIFIED with new credentials
│   ├── servers.dat         # 📋 COPIED from MASTER (broker IPs)
│   └── terminal.ini        # 📋 COPIED from MASTER (EA settings)
├── Bases\                  # 📋 COPIED from MASTER (symbol data)
│   └── Exness-MT5Trial9\
│       └── symbols\
│           ├── EURUSD.dat
│           └── XAUUSD.dat
├── MQL5\
│   ├── Experts\
│   │   └── MT5Bridge.ex5   # 📋 COPIED from MASTER
│   └── Files\
│       └── pipe_id.txt     # ✏️ CREATED (account ID + port)
└── Profiles\               # 📋 COPIED from MASTER (if exists)
```

### Credential Injection Process

The provisioner modifies **only** the account credentials in `common.ini`:

```python
# Read existing common.ini (UTF-16 LE encoding)
content = common_ini.read_text(encoding='utf-16-le')

# Update ONLY these fields
content = re.sub(r'^Login=.*$', f'Login={login}', content, flags=re.MULTILINE)
content = re.sub(r'^Server=.*$', f'Server={server}', content, flags=re.MULTILINE)
content = re.sub(r'^Password=.*$', f'Password={password}', content, flags=re.MULTILINE)

# Write back
common_ini.write_text(content, encoding='utf-16-le')
```

**All other settings are preserved** from the MASTER:
- EA permissions (AllowLiveTrading, AllowDllImport)
- WebRequest URLs
- Chart settings
- Broker server IPs

---

## Troubleshooting

### Issue: "Invalid account" error after provisioning

**Cause:** MASTER has stale `accounts.dat` file

**Fix:**
```powershell
# Re-run cleanup
.\tools\clean_master.ps1

# Reconfigure MASTER (Step 2)
```

---

### Issue: EA doesn't connect to controller

**Cause:** `pipe_id.txt` is missing or incorrect

**Fix:**
```powershell
# Check pipe_id.txt exists
cat C:\MT5_FARM\Account_test_12345\MQL5\Files\pipe_id.txt

# Should output: Account_test_12345,8888
```

If missing, create it manually:
```powershell
"Account_test_12345,8888" | Out-File -FilePath "C:\MT5_FARM\Account_test_12345\MQL5\Files\pipe_id.txt" -Encoding ASCII
```

---

### Issue: Symbols show "Waiting for update"

**Cause:** Broker data not downloaded in MASTER

**Fix:**
1. Launch MASTER: `C:\MT5_MASTER\terminal64.exe`
2. Login with a demo account
3. Wait for Market Watch to populate
4. Close MT5
5. Re-provision the account

---

### Issue: "WebRequest not allowed" in EA logs

**Cause:** EA permissions not set in MASTER

**Fix:**
1. Launch MASTER
2. `Tools → Options → Expert Advisors`
3. Add `127.0.0.1` to allowed URLs
4. Close MT5
5. Re-provision

---

## Best Practices

### 1. Never Run MT5 from MASTER

The MASTER should be a **template only**. Always run MT5 from provisioned instances in `C:\MT5_FARM\`.

### 2. Keep MASTER Clean

After initial configuration, **never login** to the MASTER again. This prevents account-specific data from accumulating.

### 3. Use a Golden Seed

For production, create one "golden seed" account:
1. Provision an account normally
2. Login and let it download all symbol data
3. Verify EA connects and trades work
4. Close MT5
5. Set this as the seed in provisioner:
   ```python
   provisioner = MT5Provisioner(
       master_path="C:/MT5_MASTER",
       farm_path="C:/MT5_FARM",
       seed_instance="C:/MT5_FARM/Account_golden_seed"
   )
   ```

This makes new provisions instant (no symbol download wait).

### 4. Backup MASTER

After successful configuration:
```powershell
# Create backup
Copy-Item -Recurse C:\MT5_MASTER C:\MT5_MASTER_BACKUP

# Restore if needed
Remove-Item -Recurse C:\MT5_MASTER
Copy-Item -Recurse C:\MT5_MASTER_BACKUP C:\MT5_MASTER
```

---

## Summary

The key insight is that **MT5 configuration files are dynamic**. Copying a used MASTER copies stale state. The solution is:

1. ✅ Clean MASTER → Remove all account data
2. ✅ Configure once → Set EA permissions, add brokers
3. ✅ Never login to MASTER → Keep it pristine
4. ✅ Provision copies MASTER → Inject only credentials
5. ✅ Run MT5 from farm instances → Not from MASTER

This ensures every provisioned account starts from a known-good state with only the account credentials changed.
