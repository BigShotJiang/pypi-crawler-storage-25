"""
MT5 Farm Production Simulation Test
====================================
Full end-to-end test simulating production usage:
1. Clear existing accounts
2. Provision all 3 accounts from scratch
3. Wait for EA connections
4. Test each operation individually
5. Test concurrent multi-account operations
"""

import asyncio
import httpx
import time
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

# Farm API base URL
FARM_BASE = "http://localhost:8000/farm"

# Test accounts to provision
TEST_ACCOUNTS = [
    {"login": 297102439, "password": "2Factorauth12--", "server": "Exness-MT5Trial9"},
    {"login": 297278718, "password": "2Factorauth12--", "server": "Exness-MT5Trial9"},
    {"login": 297278732, "password": "2Factorauth12--", "server": "Exness-MT5Trial9"},
]


@dataclass
class TestResult:
    name: str
    passed: bool
    details: str
    duration_ms: float


class ProductionSimulator:
    """Simulates full production usage of MT5 Farm."""
    
    def __init__(self):
        self.client = httpx.AsyncClient(timeout=120.0)
        self.results: List[TestResult] = []
        self.connected_accounts: List[str] = []
    
    async def close(self):
        await self.client.aclose()
    
    def log(self, msg: str, indent: int = 0):
        prefix = "  " * indent
        print(f"{prefix}{msg}")
    
    def section(self, title: str):
        print()
        print("=" * 60)
        print(title)
        print("=" * 60)
    
    async def run_test(self, name: str, coro) -> TestResult:
        """Run a test and record result."""
        start = time.time()
        try:
            result = await coro
            duration = (time.time() - start) * 1000
            
            if result.get("success", True):
                test_result = TestResult(name, True, str(result)[:100], duration)
                self.log(f"✅ {name} ({duration:.0f}ms)")
            else:
                test_result = TestResult(name, False, str(result)[:100], duration)
                self.log(f"⚠️  {name}: {result.get('message', 'no details')}")
        except Exception as e:
            duration = (time.time() - start) * 1000
            test_result = TestResult(name, False, str(e)[:100], duration)
            self.log(f"❌ {name}: {e}")
        
        self.results.append(test_result)
        return test_result
    
    # ================
    # Phase 1: Cleanup
    # ================
    
    async def cleanup_existing_accounts(self):
        """Terminate and cleanup all existing accounts."""
        self.section("PHASE 1: CLEANUP EXISTING ACCOUNTS")
        
        # Get list of existing instances
        try:
            resp = await self.client.get(f"{FARM_BASE}/instances")
            instances = resp.json().get("instances", [])
            self.log(f"Found {len(instances)} existing instances")
            
            for inst in instances:
                account_id = inst.get("account_id")
                if account_id:
                    self.log(f"Terminating {account_id}...", 1)
                    try:
                        await self.client.delete(
                            f"{FARM_BASE}/provision/{account_id}",
                            params={"cleanup": "false"}  # Keep files, just stop MT5
                        )
                        self.log(f"Terminated {account_id}", 2)
                    except Exception as e:
                        self.log(f"Warning: {e}", 2)
            
            # Give MT5 processes time to close
            self.log("Waiting for processes to terminate...")
            await asyncio.sleep(3)
            
        except Exception as e:
            self.log(f"Cleanup error: {e}")
    
    # ================
    # Phase 2: Provision
    # ================
    
    async def provision_account(self, login: int, password: str, server: str) -> bool:
        """Provision a single account."""
        account_id = f"Account_{login}"
        
        try:
            resp = await self.client.post(
                f"{FARM_BASE}/provision",
                json={
                    "account_id": account_id,
                    "login": login,
                    "password": password,
                    "server": server,
                    "auto_launch": True
                }
            )
            
            if resp.status_code == 200:
                data = resp.json()
                self.log(f"✅ Provisioned {account_id} (pid={data.get('pid', 'N/A')})", 1)
                return True
            else:
                error = resp.json().get("detail", resp.text)
                # Check if it's just a file lock error (already exists and running)
                if "being used by another process" in error:
                    self.log(f"⚠️  {account_id} already exists and running", 1)
                    return True
                self.log(f"❌ Failed to provision {account_id}: {error}", 1)
                return False
                
        except Exception as e:
            self.log(f"❌ Exception provisioning {account_id}: {e}", 1)
            return False
    
    async def provision_all_accounts(self):
        """Provision all test accounts."""
        self.section("PHASE 2: PROVISION ACCOUNTS")
        
        for account in TEST_ACCOUNTS:
            await self.provision_account(
                account["login"],
                account["password"],
                account["server"]
            )
    
    # ================
    # Phase 3: Wait for Connections
    # ================
    
    async def wait_for_connections(self, timeout: int = 60):
        """Wait for EA connections to establish."""
        self.section("PHASE 3: WAIT FOR EA CONNECTIONS")
        
        start = time.time()
        expected = len(TEST_ACCOUNTS)
        
        while time.time() - start < timeout:
            try:
                resp = await self.client.get(f"{FARM_BASE}/status")
                data = resp.json()
                alive = data.get("alive_nodes", 0)
                nodes = data.get("nodes", [])
                
                self.log(f"Connected: {alive}/{expected} accounts")
                
                # Collect connected account IDs
                self.connected_accounts = [
                    n["account_id"] for n in nodes 
                    if n.get("state") == "authenticated"
                ]
                
                if alive >= expected:
                    self.log(f"✅ All {expected} accounts connected!")
                    return True
                
                if alive >= 1:
                    self.log(f"Proceeding with {alive} connected accounts...")
                    return True
                    
            except Exception as e:
                self.log(f"Status check error: {e}")
            
            await asyncio.sleep(3)
        
        self.log(f"⚠️  Timeout waiting for connections")
        return len(self.connected_accounts) > 0
    
    # ================
    # Phase 4: Single Account Tests
    # ================
    
    async def test_single_account(self, account_id: str):
        """Run all tests on a single account."""
        self.section(f"PHASE 4: SINGLE ACCOUNT TEST - {account_id}")
        
        # Account Data Operations
        self.log("Account Data Operations:")
        await self.run_test("Account Info", self._get_account_info(account_id))
        await self.run_test("Node Status", self._get_node_status(account_id))
        await self.run_test("Positions", self._get_positions(account_id))
        await self.run_test("Pending Orders", self._get_orders(account_id))
        await self.run_test("Deal History", self._get_deals(account_id))
        
        # Market Data Operations
        self.log("\nMarket Data Operations:")
        await self.run_test("Symbol Info (EURUSDm)", self._get_symbol_info(account_id, "EURUSDm"))
        await self.run_test("Symbol Info (GBPUSDm)", self._get_symbol_info(account_id, "GBPUSDm"))
        await self.run_test("Current Price (EURUSDm)", self._get_price(account_id, "EURUSDm"))
        await self.run_test("Historical Data (H1)", self._get_history(account_id, "EURUSDm", "H1", 10))
        await self.run_test("Historical Data (M5)", self._get_history(account_id, "EURUSDm", "M5", 50))
        
        # Trading Operations (will fail when market closed)
        self.log("\nTrading Operations (market may be closed):")
        await self.run_test("Market BUY", self._market_buy(account_id, "EURUSDm", 0.01))
        await self.run_test("Market SELL", self._market_sell(account_id, "EURUSDm", 0.01))
    
    # ================
    # Phase 5: Concurrent Multi-Account Tests
    # ================
    
    async def test_concurrent_operations(self):
        """Test concurrent operations across all connected accounts."""
        self.section("PHASE 5: CONCURRENT MULTI-ACCOUNT OPERATIONS")
        
        if not self.connected_accounts:
            self.log("❌ No connected accounts for concurrent testing")
            return
        
        self.log(f"Testing concurrent operations on {len(self.connected_accounts)} accounts")
        
        # Concurrent account info requests
        self.log("\nConcurrent Account Info:")
        start = time.time()
        tasks = [self._get_account_info(aid) for aid in self.connected_accounts]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        success = sum(1 for r in results if isinstance(r, dict) and r.get("login"))
        self.log(f"✅ {success}/{len(tasks)} account info requests ({duration:.0f}ms total)")
        
        # Concurrent symbol info requests
        self.log("\nConcurrent Symbol Info (all accounts, multiple symbols):")
        start = time.time()
        symbols = ["EURUSDm", "GBPUSDm", "USDJPYm", "XAUUSDm"]
        tasks = []
        for aid in self.connected_accounts:
            for sym in symbols:
                tasks.append(self._get_symbol_info(aid, sym))
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        success = sum(1 for r in results if isinstance(r, dict))
        self.log(f"✅ {success}/{len(tasks)} symbol info requests ({duration:.0f}ms total)")
        
        # Concurrent historical data requests
        self.log("\nConcurrent Historical Data (all accounts):")
        start = time.time()
        tasks = [self._get_history(aid, "EURUSDm", "H1", 100) for aid in self.connected_accounts]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        success = sum(1 for r in results if isinstance(r, dict) and "rates" in r)
        self.log(f"✅ {success}/{len(tasks)} history requests ({duration:.0f}ms total)")
        
        # Concurrent trading requests (will fail when market closed)
        self.log("\nConcurrent Trading (market may be closed):")
        start = time.time()
        tasks = [self._market_buy(aid, "EURUSDm", 0.01) for aid in self.connected_accounts]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        success = sum(1 for r in results if isinstance(r, dict))
        self.log(f"✅ {success}/{len(tasks)} trade requests completed ({duration:.0f}ms total)")
    
    # ================
    # Helper Methods
    # ================
    
    async def _get_account_info(self, account_id: str) -> dict:
        resp = await self.client.get(f"{FARM_BASE}/account/{account_id}")
        resp.raise_for_status()
        return resp.json()
    
    async def _get_node_status(self, account_id: str) -> dict:
        resp = await self.client.get(f"{FARM_BASE}/status/{account_id}")
        resp.raise_for_status()
        return resp.json()
    
    async def _get_positions(self, account_id: str) -> dict:
        resp = await self.client.get(f"{FARM_BASE}/positions/{account_id}")
        resp.raise_for_status()
        return resp.json()
    
    async def _get_orders(self, account_id: str) -> dict:
        resp = await self.client.get(f"{FARM_BASE}/orders/{account_id}")
        resp.raise_for_status()
        return resp.json()
    
    async def _get_deals(self, account_id: str) -> dict:
        resp = await self.client.get(f"{FARM_BASE}/deals/{account_id}")
        resp.raise_for_status()
        return resp.json()
    
    async def _get_symbol_info(self, account_id: str, symbol: str) -> dict:
        resp = await self.client.get(f"{FARM_BASE}/symbol/{account_id}/{symbol}")
        resp.raise_for_status()
        return resp.json()
    
    async def _get_price(self, account_id: str, symbol: str) -> dict:
        resp = await self.client.get(f"{FARM_BASE}/price/{account_id}/{symbol}")
        resp.raise_for_status()
        return resp.json()
    
    async def _get_history(self, account_id: str, symbol: str, timeframe: str, count: int) -> dict:
        resp = await self.client.get(
            f"{FARM_BASE}/history/{account_id}",
            params={"symbol": symbol, "timeframe": timeframe, "count": count}
        )
        resp.raise_for_status()
        return resp.json()
    
    async def _market_buy(self, account_id: str, symbol: str, volume: float) -> dict:
        resp = await self.client.post(
            f"{FARM_BASE}/trade/{account_id}",
            json={"action": "buy", "symbol": symbol, "volume": volume, "ticket": 0}
        )
        resp.raise_for_status()
        return resp.json()
    
    async def _market_sell(self, account_id: str, symbol: str, volume: float) -> dict:
        resp = await self.client.post(
            f"{FARM_BASE}/trade/{account_id}",
            json={"action": "sell", "symbol": symbol, "volume": volume, "ticket": 0}
        )
        resp.raise_for_status()
        return resp.json()
    
    # ================
    # Summary
    # ================
    
    def print_summary(self):
        """Print test summary."""
        self.section("TEST SUMMARY")
        
        passed = sum(1 for r in self.results if r.passed)
        failed = sum(1 for r in self.results if not r.passed)
        total = len(self.results)
        
        print(f"\nTotal Tests: {total}")
        print(f"✅ Passed: {passed}")
        print(f"❌ Failed: {failed}")
        print(f"Pass Rate: {100*passed//total if total else 0}%")
        
        if failed > 0:
            print("\nFailed Tests:")
            for r in self.results:
                if not r.passed:
                    print(f"  - {r.name}: {r.details}")
        
        print(f"\nConnected Accounts: {len(self.connected_accounts)}")
        for aid in self.connected_accounts:
            print(f"  - {aid}")


async def main():
    """Run the production simulation."""
    print("=" * 60)
    print("MT5 FARM PRODUCTION SIMULATION TEST")
    print("=" * 60)
    print(f"Testing {len(TEST_ACCOUNTS)} accounts")
    print()
    
    sim = ProductionSimulator()
    
    try:
        # Phase 1: Cleanup (optional - comment out to keep existing)
        # await sim.cleanup_existing_accounts()
        
        # Phase 2: Provision all accounts
        await sim.provision_all_accounts()
        
        # Phase 3: Wait for EA connections
        connected = await sim.wait_for_connections(timeout=30)
        
        if not connected:
            print("\n❌ No accounts connected. Please ensure:")
            print("  1. MT5 terminals are launched")
            print("  2. EAs are running on charts")
            print("  3. WebRequest for 127.0.0.1 is enabled")
            return
        
        # Phase 4: Single account tests
        if sim.connected_accounts:
            await sim.test_single_account(sim.connected_accounts[0])
        
        # Phase 5: Concurrent multi-account tests
        await sim.test_concurrent_operations()
        
        # Summary
        sim.print_summary()
        
    finally:
        await sim.close()


if __name__ == "__main__":
    asyncio.run(main())
