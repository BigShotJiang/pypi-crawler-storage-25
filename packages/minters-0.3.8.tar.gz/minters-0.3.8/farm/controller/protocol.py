"""
Protocol definitions for MT5 Farm communication.

Binary packet format:
[MsgType: 1 byte][Length: 4 bytes (little-endian)][Body: N bytes (JSON)]

This module defines message types and provides serialization utilities.
"""

import struct
import json
from enum import IntEnum
from typing import Any, Tuple, Optional
from dataclasses import dataclass

# Protocol version for compatibility checking
PROTOCOL_VERSION = "1.1.0"

class MessageType(IntEnum):
    """Message types for farm protocol."""
    # Core messages (1-10)
    LOGIN = 1           # MT5 -> Python: Initial handshake with account info
    TICK = 2            # MT5 -> Python: Real-time tick data
    COMMAND_RESP = 3    # MT5 -> Python: Response to a command
    TRADE_CMD = 4       # Python -> MT5: Execute market trade (buy/sell/close)
    HISTORY_CMD = 5     # Python -> MT5: Request historical data
    PING = 6            # Python -> MT5: Heartbeat request
    PONG = 7            # MT5 -> Python: Heartbeat response
    ACCOUNT_INFO = 8    # Bidirectional: Account information
    POSITIONS = 9       # Bidirectional: Open positions
    ERROR = 10          # Bidirectional: Error message
    
    # Extended trading operations (11-20)
    PENDING_ORDER_CMD = 11    # Python -> MT5: Place pending order (limit/stop/stop-limit)
    MODIFY_POSITION_CMD = 12  # Python -> MT5: Modify position (SL/TP)
    MODIFY_ORDER_CMD = 13     # Python -> MT5: Modify pending order
    CANCEL_ORDER_CMD = 14     # Python -> MT5: Cancel pending order
    CLOSE_PARTIAL_CMD = 15    # Python -> MT5: Partial position close
    CLOSE_BY_CMD = 16         # Python -> MT5: Close position by opposite
    
    # Extended data queries (21-30)
    PENDING_ORDERS = 21       # Bidirectional: Pending orders list
    DEAL_HISTORY = 22         # Bidirectional: Trade/deal history
    SYMBOL_INFO = 23          # Bidirectional: Symbol information
    CURRENT_PRICE = 24        # Bidirectional: Current bid/ask for symbol


@dataclass
class LoginData:
    """Login handshake data from MT5."""
    account_id: str
    login: int
    server: str
    company: str
    balance: float
    currency: str
    connected: bool = False      # Terminal connected to broker
    trade_allowed: bool = False  # Trading is allowed


@dataclass
class TickData:
    """Real-time tick data."""
    symbol: str
    time: int
    bid: float
    ask: float
    last: float
    volume: int


@dataclass
class TradeCommand:
    """Trade execution command."""
    action: str  # "buy", "sell", "close"
    symbol: str
    volume: float
    ticket: int = 0
    request_id: str = ""


@dataclass
class PendingOrderCommand:
    """Pending order command (limit/stop/stop-limit)."""
    order_type: str  # "buy_limit", "sell_limit", "buy_stop", "sell_stop", "buy_stop_limit", "sell_stop_limit"
    symbol: str
    volume: float
    price: float
    stop_limit_price: float = 0.0  # For stop-limit orders
    stop_loss: float = 0.0
    take_profit: float = 0.0
    expiration: int = 0  # Unix timestamp, 0 = GTC
    magic: int = 0
    comment: str = ""
    request_id: str = ""


@dataclass
class ModifyPositionCommand:
    """Modify position SL/TP command."""
    ticket: int
    stop_loss: float = 0.0
    take_profit: float = 0.0
    trailing_stop: float = 0.0
    request_id: str = ""


@dataclass
class ModifyOrderCommand:
    """Modify pending order command."""
    ticket: int
    price: float = 0.0
    stop_limit_price: float = 0.0
    stop_loss: float = 0.0
    take_profit: float = 0.0
    expiration: int = 0
    request_id: str = ""


@dataclass
class ClosePartialCommand:
    """Partial position close command."""
    ticket: int
    volume: float
    request_id: str = ""


@dataclass
class CloseByCommand:
    """Close position by opposite command."""
    ticket: int
    opposite_ticket: int
    request_id: str = ""


@dataclass
class TradeResponse:
    """Trade execution response."""
    request_id: str
    success: bool
    ticket: int
    retcode: int
    comment: str


@dataclass
class SymbolInfo:
    """Symbol information."""
    symbol: str
    bid: float
    ask: float
    digits: int
    point: float
    spread: int
    volume_min: float
    volume_max: float
    volume_step: float
    trade_mode: int  # 0=disabled, 1=long_only, 2=short_only, 3=close_only, 4=full


class ProtocolHandler:
    """
    Handles binary protocol encoding/decoding for farm communication.
    
    Packet structure:
    - Header: [MsgType: 1 byte][Length: 4 bytes little-endian]
    - Body: JSON-encoded data (UTF-8)
    """
    
    HEADER_SIZE = 5
    MAX_BODY_SIZE = 1024 * 1024  # 1MB max
    
    @staticmethod
    def encode(msg_type: MessageType, data: dict) -> bytes:
        """
        Encode a message into binary packet format.
        
        Args:
            msg_type: Message type enum
            data: Dictionary to JSON-encode as body
            
        Returns:
            Binary packet bytes
        """
        body = json.dumps(data, separators=(',', ':')).encode('utf-8')
        header = struct.pack('<BI', msg_type, len(body))
        return header + body
    
    @staticmethod
    def decode_header(header: bytes) -> Tuple[MessageType, int]:
        """
        Decode packet header.
        
        Args:
            header: 5-byte header
            
        Returns:
            Tuple of (message_type, body_length)
        """
        if len(header) < ProtocolHandler.HEADER_SIZE:
            raise ValueError(f"Header too short: {len(header)} bytes")
        
        msg_type, body_len = struct.unpack('<BI', header[:5])
        
        if body_len > ProtocolHandler.MAX_BODY_SIZE:
            raise ValueError(f"Body too large: {body_len} bytes")
        
        return MessageType(msg_type), body_len
    
    @staticmethod
    def decode_body(body: bytes) -> dict:
        """
        Decode packet body from JSON.
        
        Args:
            body: UTF-8 encoded JSON
            
        Returns:
            Decoded dictionary
        """
        return json.loads(body.decode('utf-8'))
    
    @staticmethod
    def decode_packet(data: bytes) -> Tuple[MessageType, dict, int]:
        """
        Decode a complete packet from buffer.
        
        Args:
            data: Buffer containing at least one complete packet
            
        Returns:
            Tuple of (message_type, body_dict, total_bytes_consumed)
        """
        if len(data) < ProtocolHandler.HEADER_SIZE:
            raise ValueError("Insufficient data for header")
        
        msg_type, body_len = ProtocolHandler.decode_header(data)
        total_len = ProtocolHandler.HEADER_SIZE + body_len
        
        if len(data) < total_len:
            raise ValueError(f"Incomplete packet: need {total_len}, have {len(data)}")
        
        body = ProtocolHandler.decode_body(data[ProtocolHandler.HEADER_SIZE:total_len])
        return msg_type, body, total_len
    
    # Convenience methods for common messages
    
    @staticmethod
    def encode_ping() -> bytes:
        """Create a ping packet."""
        return ProtocolHandler.encode(MessageType.PING, {})
    
    @staticmethod
    def encode_trade(action: str, symbol: str, volume: float, 
                     ticket: int = 0, request_id: str = "") -> bytes:
        """Create a trade command packet."""
        return ProtocolHandler.encode(MessageType.TRADE_CMD, {
            "action": action,
            "symbol": symbol,
            "volume": volume,
            "ticket": ticket,
            "request_id": request_id
        })
    
    @staticmethod
    def encode_history_request(
        symbol: str,
        timeframe: str = "M1",
        count: int = 100,
        request_id: str = "",
        start_time: int = 0,
        end_time: int = 0,
        offset: int = 0,
    ) -> bytes:
        """Create a history request packet."""
        return ProtocolHandler.encode(MessageType.HISTORY_CMD, {
            "symbol": symbol,
            "timeframe": timeframe,
            "count": count,
            "request_id": request_id,
            "start_time": start_time,
            "end_time": end_time,
            "offset": offset,
        })
    
    @staticmethod
    def encode_account_info_request(request_id: str = "") -> bytes:
        """Request account information."""
        return ProtocolHandler.encode(MessageType.ACCOUNT_INFO, {"request_id": request_id})
    
    @staticmethod
    def encode_positions_request(request_id: str = "") -> bytes:
        """Request open positions."""
        return ProtocolHandler.encode(MessageType.POSITIONS, {"request_id": request_id})
    
    @staticmethod
    def encode_pending_order(
        order_type: str,
        symbol: str,
        volume: float,
        price: float,
        stop_limit_price: float = 0.0,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        magic: int = 0,
        comment: str = "",
        request_id: str = ""
    ) -> bytes:
        """Create a pending order packet (limit/stop/stop-limit)."""
        return ProtocolHandler.encode(MessageType.PENDING_ORDER_CMD, {
            "order_type": order_type,
            "symbol": symbol,
            "volume": volume,
            "price": price,
            "stop_limit_price": stop_limit_price,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "expiration": expiration,
            "magic": magic,
            "comment": comment,
            "request_id": request_id
        })
    
    @staticmethod
    def encode_modify_position(
        ticket: int,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        trailing_stop: float = 0.0,
        request_id: str = ""
    ) -> bytes:
        """Create a modify position packet."""
        return ProtocolHandler.encode(MessageType.MODIFY_POSITION_CMD, {
            "ticket": ticket,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "trailing_stop": trailing_stop,
            "request_id": request_id
        })
    
    @staticmethod
    def encode_modify_order(
        ticket: int,
        price: float = 0.0,
        stop_limit_price: float = 0.0,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        request_id: str = ""
    ) -> bytes:
        """Create a modify pending order packet."""
        return ProtocolHandler.encode(MessageType.MODIFY_ORDER_CMD, {
            "ticket": ticket,
            "price": price,
            "stop_limit_price": stop_limit_price,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "expiration": expiration,
            "request_id": request_id
        })
    
    @staticmethod
    def encode_cancel_order(ticket: int, request_id: str = "") -> bytes:
        """Create a cancel pending order packet."""
        return ProtocolHandler.encode(MessageType.CANCEL_ORDER_CMD, {
            "ticket": ticket,
            "request_id": request_id
        })
    
    @staticmethod
    def encode_close_partial(
        ticket: int,
        volume: float,
        request_id: str = ""
    ) -> bytes:
        """Create a partial close packet."""
        return ProtocolHandler.encode(MessageType.CLOSE_PARTIAL_CMD, {
            "ticket": ticket,
            "volume": volume,
            "request_id": request_id
        })
    
    @staticmethod
    def encode_close_by(
        ticket: int,
        opposite_ticket: int,
        request_id: str = ""
    ) -> bytes:
        """Create a close-by-opposite packet."""
        return ProtocolHandler.encode(MessageType.CLOSE_BY_CMD, {
            "ticket": ticket,
            "opposite_ticket": opposite_ticket,
            "request_id": request_id
        })
    
    @staticmethod
    def encode_pending_orders_request(request_id: str = "") -> bytes:
        """Request pending orders list."""
        return ProtocolHandler.encode(MessageType.PENDING_ORDERS, {"request_id": request_id})
    
    @staticmethod
    def encode_deal_history_request(
        from_date: int = 0,
        to_date: int = 0,
        request_id: str = ""
    ) -> bytes:
        """Request deal history."""
        return ProtocolHandler.encode(MessageType.DEAL_HISTORY, {
            "from_date": from_date,
            "to_date": to_date,
            "request_id": request_id
        })
    
    @staticmethod
    def encode_symbol_info_request(symbol: str, request_id: str = "") -> bytes:
        """Request symbol information."""
        return ProtocolHandler.encode(MessageType.SYMBOL_INFO, {
            "symbol": symbol,
            "request_id": request_id
        })
    
    @staticmethod
    def encode_current_price_request(symbol: str, request_id: str = "") -> bytes:
        """Request current price for a symbol."""
        return ProtocolHandler.encode(MessageType.CURRENT_PRICE, {
            "symbol": symbol,
            "request_id": request_id
        })
    
    @staticmethod
    def parse_login(data: dict) -> LoginData:
        """Parse login handshake data."""
        return LoginData(
            account_id=data.get("account_id", ""),
            login=data.get("login", 0),
            server=data.get("server", ""),
            company=data.get("company", ""),
            balance=data.get("balance", 0.0),
            currency=data.get("currency", "USD"),
            connected=data.get("connected", False),
            trade_allowed=data.get("trade_allowed", False)
        )
    
    @staticmethod
    def parse_tick(data: dict) -> TickData:
        """Parse tick data (compact format)."""
        return TickData(
            symbol=data.get("s", ""),
            time=data.get("t", 0),
            bid=data.get("b", 0.0),
            ask=data.get("a", 0.0),
            last=data.get("l", 0.0),
            volume=data.get("v", 0)
        )
    
    @staticmethod
    def parse_trade_response(data: dict) -> TradeResponse:
        """Parse trade command response."""
        return TradeResponse(
            request_id=data.get("request_id", ""),
            success=data.get("success", False),
            ticket=data.get("ticket", 0),
            retcode=data.get("retcode", 0),
            comment=data.get("comment", "")
        )
    
    @staticmethod
    def parse_symbol_info(data: dict) -> SymbolInfo:
        """Parse symbol information response."""
        return SymbolInfo(
            symbol=data.get("symbol", ""),
            bid=data.get("bid", 0.0),
            ask=data.get("ask", 0.0),
            digits=data.get("digits", 5),
            point=data.get("point", 0.00001),
            spread=data.get("spread", 0),
            volume_min=data.get("volume_min", 0.01),
            volume_max=data.get("volume_max", 100.0),
            volume_step=data.get("volume_step", 0.01),
            trade_mode=data.get("trade_mode", 4)
        )
