"""
Farm Controller - Asyncio TCP Server for MT5 Farm Management

This is the "brain" of the farm. It:
1. Accepts connections from multiple MT5 instances
2. Handles binary protocol for ticks and commands
3. Manages heartbeat/ping for zombie detection
4. Routes commands to specific nodes
5. Broadcasts ticks to subscribers

Architecture:
- Each MT5 instance connects as a client
- Controller maintains a registry of FarmNode objects
- Commands are sent via request/response with request_id
- Ticks are broadcast to WebSocket subscribers
"""

import asyncio
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Optional, Callable, Awaitable, Set, Any
from enum import Enum

from .protocol import (
    ProtocolHandler, MessageType, LoginData, TickData, 
    TradeResponse, SymbolInfo, PROTOCOL_VERSION
)

logger = logging.getLogger(__name__)


class NodeState(Enum):
    """State of a farm node."""
    CONNECTING = "connecting"
    CONNECTED = "connected"
    AUTHENTICATED = "authenticated"
    DISCONNECTED = "disconnected"
    ZOMBIE = "zombie"


@dataclass
class FarmNode:
    """
    Represents a single MT5 instance connection.
    
    Attributes:
        account_id: Unique identifier (from login or provisioner)
        reader: Asyncio stream reader
        writer: Asyncio stream writer
        state: Current connection state
        login_data: Account information from handshake
        last_ping: Timestamp of last successful ping
        missed_pings: Count of consecutive missed pings
        pending_requests: Map of request_id -> Future for command responses
        pid: OS process ID (if managed by provisioner)
    """
    account_id: str
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    state: NodeState = NodeState.CONNECTING
    login_data: Optional[LoginData] = None
    last_ping: datetime = field(default_factory=datetime.now)
    missed_pings: int = 0
    pending_requests: Dict[str, asyncio.Future] = field(default_factory=dict)
    pid: Optional[int] = None
    recv_buffer: bytearray = field(default_factory=bytearray)
    
    @property
    def is_alive(self) -> bool:
        """Check if node is responsive."""
        return self.state == NodeState.AUTHENTICATED and self.missed_pings < 3


class FarmController:
    """
    Main controller for the MT5 farm.
    
    Manages all connected MT5 instances, handles protocol communication,
    and provides APIs for trading commands and data streaming.
    """
    
    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8888,
        ping_interval: float = 5.0,
        ping_timeout: float = 3.0,
        max_missed_pings: int = 3
    ):
        """
        Initialize the farm controller.
        
        Args:
            host: IP to bind the server to
            port: Port to listen on
            ping_interval: Seconds between heartbeat pings
            ping_timeout: Seconds to wait for pong response
            max_missed_pings: Missed pings before marking zombie
        """
        self.host = host
        self.port = port
        self.ping_interval = ping_interval
        self.ping_timeout = ping_timeout
        self.max_missed_pings = max_missed_pings
        
        # Node registry
        self.nodes: Dict[str, FarmNode] = {}
        
        # Event callbacks
        self._tick_handlers: Set[Callable[[str, TickData], Awaitable[None]]] = set()
        self._connect_handlers: Set[Callable[[str, LoginData], Awaitable[None]]] = set()
        self._disconnect_handlers: Set[Callable[[str], Awaitable[None]]] = set()
        
        # Server state
        self._server: Optional[asyncio.Server] = None
        self._running = False
        self._heartbeat_task: Optional[asyncio.Task] = None
        
        logger.info(f"FarmController initialized (protocol v{PROTOCOL_VERSION})")
    
    # ===================
    # Server Lifecycle
    # ===================
    
    async def start(self):
        """Start the TCP server and heartbeat monitor."""
        if self._running:
            logger.warning("Controller already running")
            return
        
        self._running = True
        
        # Start TCP server
        self._server = await asyncio.start_server(
            self._handle_client,
            self.host,
            self.port
        )
        
        # Start heartbeat task
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        
        addr = self._server.sockets[0].getsockname()
        logger.info(f"Farm controller listening on {addr[0]}:{addr[1]}")
    
    async def stop(self):
        """Stop the server and disconnect all nodes."""
        if not self._running:
            return
        
        self._running = False
        
        # Cancel heartbeat
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
        
        # Disconnect all nodes
        for account_id in list(self.nodes.keys()):
            await self._disconnect_node(account_id)
        
        # Close server
        if self._server:
            self._server.close()
            await self._server.wait_closed()
        
        logger.info("Farm controller stopped")
    
    async def serve_forever(self):
        """Run the server until stopped."""
        await self.start()
        try:
            async with self._server:
                await self._server.serve_forever()
        except asyncio.CancelledError:
            await self.stop()
    
    # ===================
    # Client Connection
    # ===================
    
    async def _handle_client(
        self, 
        reader: asyncio.StreamReader, 
        writer: asyncio.StreamWriter
    ):
        """Handle a new client connection."""
        addr = writer.get_extra_info('peername')
        logger.info(f"New connection from {addr}")
        
        # Create temporary node (will get account_id from login)
        temp_id = f"temp_{uuid.uuid4().hex[:8]}"
        node = FarmNode(
            account_id=temp_id,
            reader=reader,
            writer=writer,
            state=NodeState.CONNECTING
        )
        
        try:
            # Wait for login handshake
            if not await self._wait_for_login(node):
                logger.warning(f"Login timeout for {addr}")
                return
            
            # ------------------------------------------------------------------
            # Duplicate-connection policy
            #
            # Two EAs on different charts of the same terminal both try to
            # connect at startup.  The original 'evict old, register new'
            # approach caused an infinite ping-pong: the evicted EA immediately
            # reconnects, evicts the second, which reconnects, etc.
            #
            # Strategy (first connection wins):
            #   1. Same account_id AND existing is alive  -> reject newcomer.
            #   2. Same account_id AND existing is dead   -> evict + register.
            #   3. Same MT5 login but different account_id (e.g. raw login
            #      number vs alias):
            #        - Existing is the raw number, newcomer has the alias
            #          -> upgrade (evict old, register alias).
            #        - Existing is alive with a proper name -> reject newcomer.
            #        - Existing is dead -> evict + register.
            # ------------------------------------------------------------------

            existing_by_id = self.nodes.get(node.account_id)

            new_login = node.login_data.login
            existing_by_login: Optional[FarmNode] = None
            for _n in self.nodes.values():
                if _n is not existing_by_id and _n.login_data and _n.login_data.login == new_login:
                    existing_by_login = _n
                    break

            def _is_raw_id(aid: str, login: int) -> bool:
                return aid == str(login)

            reject = False

            if existing_by_id is not None:
                if existing_by_id.is_alive:
                    logger.info(
                        f"Node {node.account_id} already connected -- "
                        f"rejecting duplicate (EA on multiple charts?)"
                    )
                    reject = True
                else:
                    logger.info(f"Node {node.account_id} reconnecting -- evicting stale connection")
                    await self._disconnect_node(existing_by_id.account_id)

            elif existing_by_login is not None:
                old_is_raw = _is_raw_id(existing_by_login.account_id, new_login)
                new_is_raw = _is_raw_id(node.account_id, new_login)
                if old_is_raw and not new_is_raw:
                    logger.info(
                        f"Login {new_login}: upgrading account_id "
                        f"{existing_by_login.account_id!r} -> {node.account_id!r}"
                    )
                    await self._disconnect_node(existing_by_login.account_id)
                elif existing_by_login.is_alive:
                    logger.info(
                        f"Login {new_login} already connected as "
                        f"{existing_by_login.account_id!r} -- rejecting {node.account_id!r}"
                    )
                    reject = True
                else:
                    logger.info(
                        f"Login {new_login}: evicting stale {existing_by_login.account_id!r}"
                    )
                    await self._disconnect_node(existing_by_login.account_id)

            if reject:
                # Reset to temp_id so the finally block does NOT kill the live node
                node.account_id = temp_id
                writer.close()
                try:
                    await writer.wait_closed()
                except Exception:
                    pass
                return

            self.nodes[node.account_id] = node
            node.state = NodeState.AUTHENTICATED

            logger.info(f"Node authenticated: {node.account_id} (login={node.login_data.login})")

            # Notify handlers
            for handler in self._connect_handlers:
                try:
                    await handler(node.account_id, node.login_data)
                except Exception as e:
                    logger.error(f"Connect handler error: {e}")


            # Main receive loop
            await self._receive_loop(node)
            
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Client handler error: {e}")
        finally:
            await self._disconnect_node(node.account_id)
    
    async def _wait_for_login(self, node: FarmNode, timeout: float = 10.0) -> bool:
        """Wait for login handshake from MT5."""
        try:
            async with asyncio.timeout(timeout):
                while True:
                    # Read data
                    data = await node.reader.read(4096)
                    if not data:
                        return False
                    
                    node.recv_buffer.extend(data)
                    
                    # Try to parse message
                    if len(node.recv_buffer) >= ProtocolHandler.HEADER_SIZE:
                        try:
                            msg_type, body, consumed = ProtocolHandler.decode_packet(
                                bytes(node.recv_buffer)
                            )
                            node.recv_buffer = node.recv_buffer[consumed:]
                            
                            if msg_type == MessageType.LOGIN:
                                node.login_data = ProtocolHandler.parse_login(body)
                                node.account_id = node.login_data.account_id or str(node.login_data.login)
                                return True
                                
                        except ValueError:
                            # Incomplete packet, wait for more data
                            pass
                            
        except asyncio.TimeoutError:
            return False
    
    async def _receive_loop(self, node: FarmNode):
        """Main loop to receive and process messages from a node."""
        while self._running and node.state == NodeState.AUTHENTICATED:
            try:
                data = await asyncio.wait_for(
                    node.reader.read(8192),
                    timeout=self.ping_interval * 2
                )
                
                if not data:
                    logger.info(f"Connection closed by {node.account_id}")
                    break
                
                node.recv_buffer.extend(data)
                
                # Process all complete messages
                await self._process_buffer(node)
                
            except asyncio.TimeoutError:
                # No data received, but connection might still be alive
                pass
            except ConnectionResetError:
                logger.info(f"Connection reset: {node.account_id}")
                break
            except Exception as e:
                logger.error(f"Receive error for {node.account_id}: {e}")
                break
    
    async def _process_buffer(self, node: FarmNode):
        """Process all complete messages in the receive buffer."""
        while len(node.recv_buffer) >= ProtocolHandler.HEADER_SIZE:
            try:
                msg_type, body, consumed = ProtocolHandler.decode_packet(
                    bytes(node.recv_buffer)
                )
                node.recv_buffer = node.recv_buffer[consumed:]
                
                await self._handle_message(node, msg_type, body)
                
            except ValueError:
                # Incomplete packet
                break
    
    async def _handle_message(self, node: FarmNode, msg_type: MessageType, body: dict):
        """Handle a decoded message from a node."""
        
        if msg_type == MessageType.TICK:
            tick = ProtocolHandler.parse_tick(body)
            for handler in self._tick_handlers:
                try:
                    await handler(node.account_id, tick)
                except Exception as e:
                    logger.error(f"Tick handler error: {e}")
        
        elif msg_type == MessageType.PONG:
            node.missed_pings = 0
            node.last_ping = datetime.now()
        
        elif msg_type == MessageType.COMMAND_RESP:
            request_id = body.get("request_id", "")
            if request_id in node.pending_requests:
                future = node.pending_requests.pop(request_id)
                if not future.done():
                    future.set_result(body)
        
        elif msg_type == MessageType.ACCOUNT_INFO:
            # Handle account info update
            request_id = body.get("request_id", "")
            if request_id in node.pending_requests:
                future = node.pending_requests.pop(request_id)
                if not future.done():
                    future.set_result(body)
        
        elif msg_type == MessageType.POSITIONS:
            # Handle positions update
            request_id = body.get("request_id", "")
            if request_id in node.pending_requests:
                future = node.pending_requests.pop(request_id)
                if not future.done():
                    future.set_result(body)
        
        elif msg_type == MessageType.PENDING_ORDERS:
            # Handle pending orders update
            request_id = body.get("request_id", "")
            if request_id in node.pending_requests:
                future = node.pending_requests.pop(request_id)
                if not future.done():
                    future.set_result(body)
        
        elif msg_type == MessageType.DEAL_HISTORY:
            # Handle deal history update
            request_id = body.get("request_id", "")
            if request_id in node.pending_requests:
                future = node.pending_requests.pop(request_id)
                if not future.done():
                    future.set_result(body)
        
        elif msg_type == MessageType.SYMBOL_INFO:
            # Handle symbol info response
            request_id = body.get("request_id", "")
            if request_id in node.pending_requests:
                future = node.pending_requests.pop(request_id)
                if not future.done():
                    future.set_result(body)
        
        elif msg_type == MessageType.CURRENT_PRICE:
            # Handle current price response
            request_id = body.get("request_id", "")
            if request_id in node.pending_requests:
                future = node.pending_requests.pop(request_id)
                if not future.done():
                    future.set_result(body)
        
        elif msg_type == MessageType.ERROR:
            logger.error(f"Error from {node.account_id}: {body}")
    
    async def _disconnect_node(self, account_id: str):
        """Disconnect and clean up a node."""
        node = self.nodes.pop(account_id, None)
        if not node:
            return
        
        node.state = NodeState.DISCONNECTED
        
        # Cancel pending requests
        for future in node.pending_requests.values():
            if not future.done():
                future.set_exception(ConnectionError("Node disconnected"))
        node.pending_requests.clear()
        
        # Close connection
        try:
            node.writer.close()
            await node.writer.wait_closed()
        except Exception:
            pass
        
        # Notify handlers
        for handler in self._disconnect_handlers:
            try:
                await handler(account_id)
            except Exception as e:
                logger.error(f"Disconnect handler error: {e}")
        
        logger.info(f"Node disconnected: {account_id}")
    
    # ===================
    # Heartbeat
    # ===================
    
    async def _heartbeat_loop(self):
        """Periodically ping all nodes to detect zombies."""
        while self._running:
            await asyncio.sleep(self.ping_interval)
            
            for account_id, node in list(self.nodes.items()):
                if node.state != NodeState.AUTHENTICATED:
                    continue
                
                try:
                    # Send ping
                    await self._send_raw(node, ProtocolHandler.encode_ping())
                    node.missed_pings += 1
                    
                    # Check for zombie
                    if node.missed_pings >= self.max_missed_pings:
                        if node.pending_requests:
                            # Node is busy processing a command — don't declare zombie
                            # yet; the command's own timeout will handle genuine hangs.
                            continue
                        logger.warning(f"Node zombie detected: {account_id}")
                        node.state = NodeState.ZOMBIE
                        await self._disconnect_node(account_id)
                        
                except Exception as e:
                    logger.error(f"Heartbeat error for {account_id}: {e}")
    
    # ===================
    # Command API
    # ===================
    
    async def _send_raw(self, node: FarmNode, data: bytes):
        """Send raw bytes to a node."""
        node.writer.write(data)
        await node.writer.drain()
    
    async def _send_command(
        self, 
        account_id: str, 
        packet: bytes, 
        request_id: str,
        timeout: float = 10.0
    ) -> dict:
        """Send a command and wait for response."""
        node = self.nodes.get(account_id)
        if not node or not node.is_alive:
            raise ConnectionError(f"Node not available: {account_id}")
        
        # Create future for response
        future: asyncio.Future = asyncio.Future()
        node.pending_requests[request_id] = future
        
        try:
            # Send command
            await self._send_raw(node, packet)
            
            # Wait for response
            return await asyncio.wait_for(future, timeout)
            
        except asyncio.TimeoutError:
            node.pending_requests.pop(request_id, None)
            raise TimeoutError(f"Command timeout for {account_id}")
    
    async def execute_trade(
        self,
        account_id: str,
        action: str,
        symbol: str,
        volume: float,
        ticket: int = 0,
        timeout: float = 30.0
    ) -> TradeResponse:
        """
        Execute a trade on a specific account.
        
        Args:
            account_id: Target account
            action: "buy", "sell", or "close"
            symbol: Trading symbol
            volume: Lot size
            ticket: Position ticket (for close action)
            timeout: Max wait time for response
            
        Returns:
            TradeResponse with result details
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_trade(
            action=action,
            symbol=symbol,
            volume=volume,
            ticket=ticket,
            request_id=request_id
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return ProtocolHandler.parse_trade_response(response)
    
    async def get_account_info(self, account_id: str, timeout: float = 10.0) -> dict:
        """Get account information from a node."""
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_account_info_request(request_id)
        
        node = self.nodes.get(account_id)
        if not node or not node.is_alive:
            raise ConnectionError(f"Node not available: {account_id}")
        
        # Create future
        future: asyncio.Future = asyncio.Future()
        node.pending_requests[request_id] = future
        
        await self._send_raw(node, packet)
        
        try:
            return await asyncio.wait_for(future, timeout)
        except asyncio.TimeoutError:
            node.pending_requests.pop(request_id, None)
            raise
    
    async def get_positions(self, account_id: str, timeout: float = 10.0) -> list:
        """Get open positions from a node."""
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_positions_request(request_id)
        
        node = self.nodes.get(account_id)
        if not node or not node.is_alive:
            raise ConnectionError(f"Node not available: {account_id}")
        
        future: asyncio.Future = asyncio.Future()
        node.pending_requests[request_id] = future
        
        await self._send_raw(node, packet)
        
        try:
            response = await asyncio.wait_for(future, timeout)
            return response.get("positions", [])
        except asyncio.TimeoutError:
            node.pending_requests.pop(request_id, None)
            raise
    
    async def get_history(
        self,
        account_id: str,
        symbol: str,
        timeframe: str = "M1",
        count: int = 100,
        start_time: int = 0,
        end_time: int = 0,
        offset: int = 0,
        timeout: float = 90.0
    ) -> list:
        """Get historical rates from a node."""
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_history_request(
            symbol=symbol,
            timeframe=timeframe,
            count=count,
            request_id=request_id,
            start_time=start_time,
            end_time=end_time,
            offset=offset,
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return response.get("rates", [])
    
    async def get_historical_rates(
        self,
        account_id: str,
        symbol: str,
        timeframe: str = "M1",
        count: int = 100,
        start_time: int = 0,
        end_time: int = 0,
        offset: int = 0,
        timeout: float = 30.0
    ) -> list:
        """Alias for get_history() to match router endpoint naming."""
        return await self.get_history(
            account_id,
            symbol,
            timeframe,
            count,
            start_time,
            end_time,
            offset,
            timeout,
        )

    async def get_historical_ticks(
        self,
        account_id: str,
        symbol: str,
        start_time: int = 0,
        end_time: int = 0,
        offset: int = 0,
        limit: int = 100,
        timeout: float = 120.0,
    ) -> list:
        """
        Get historical ticks for a symbol.

        This uses the existing history command channel with timeframe="TICK"
        so we do not need a separate protocol message type.
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_history_request(
            symbol=symbol,
            timeframe="TICK",
            count=limit,
            request_id=request_id,
            start_time=start_time,
            end_time=end_time,
            offset=offset,
        )

        response = await self._send_command(account_id, packet, request_id, timeout)
        return response.get("ticks", [])
    
    # ===================
    # Extended Trading API
    # ===================
    
    async def place_pending_order(
        self,
        account_id: str,
        order_type: str,
        symbol: str,
        volume: float,
        price: float,
        stop_limit_price: float = 0.0,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        magic: int = 0,
        comment: str = "",
        timeout: float = 30.0
    ) -> TradeResponse:
        """
        Place a pending order (limit/stop/stop-limit).
        
        Args:
            account_id: Target account
            order_type: "buy_limit", "sell_limit", "buy_stop", "sell_stop", 
                       "buy_stop_limit", "sell_stop_limit"
            symbol: Trading symbol
            volume: Lot size
            price: Order price (entry price for limit/stop)
            stop_limit_price: Limit price for stop-limit orders
            stop_loss: Stop loss price
            take_profit: Take profit price
            expiration: Unix timestamp for order expiration (0 = GTC)
            magic: Magic number for order identification
            comment: Order comment
            timeout: Max wait time for response
            
        Returns:
            TradeResponse with order ticket
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_pending_order(
            order_type=order_type,
            symbol=symbol,
            volume=volume,
            price=price,
            stop_limit_price=stop_limit_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            expiration=expiration,
            magic=magic,
            comment=comment,
            request_id=request_id
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return ProtocolHandler.parse_trade_response(response)
    
    async def modify_position(
        self,
        account_id: str,
        ticket: int,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        trailing_stop: float = 0.0,
        timeout: float = 30.0
    ) -> TradeResponse:
        """
        Modify a position's SL/TP.
        
        Args:
            account_id: Target account
            ticket: Position ticket
            stop_loss: New stop loss (0 = no change)
            take_profit: New take profit (0 = no change)
            trailing_stop: Trailing stop distance in points (0 = no trailing)
            timeout: Max wait time for response
            
        Returns:
            TradeResponse with result
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_modify_position(
            ticket=ticket,
            stop_loss=stop_loss,
            take_profit=take_profit,
            trailing_stop=trailing_stop,
            request_id=request_id
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return ProtocolHandler.parse_trade_response(response)
    
    async def modify_order(
        self,
        account_id: str,
        ticket: int,
        price: float = 0.0,
        stop_limit_price: float = 0.0,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        timeout: float = 30.0
    ) -> TradeResponse:
        """
        Modify a pending order.
        
        Args:
            account_id: Target account
            ticket: Order ticket
            price: New order price (0 = no change)
            stop_limit_price: New stop-limit price (0 = no change)
            stop_loss: New stop loss (0 = no change)
            take_profit: New take profit (0 = no change)
            expiration: New expiration timestamp (0 = no change)
            timeout: Max wait time for response
            
        Returns:
            TradeResponse with result
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_modify_order(
            ticket=ticket,
            price=price,
            stop_limit_price=stop_limit_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            expiration=expiration,
            request_id=request_id
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return ProtocolHandler.parse_trade_response(response)
    
    async def cancel_order(
        self,
        account_id: str,
        ticket: int,
        timeout: float = 30.0
    ) -> TradeResponse:
        """
        Cancel a pending order.
        
        Args:
            account_id: Target account
            ticket: Order ticket to cancel
            timeout: Max wait time for response
            
        Returns:
            TradeResponse with result
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_cancel_order(
            ticket=ticket,
            request_id=request_id
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return ProtocolHandler.parse_trade_response(response)
    
    async def close_position_partial(
        self,
        account_id: str,
        ticket: int,
        volume: float,
        timeout: float = 30.0
    ) -> TradeResponse:
        """
        Partially close a position.
        
        Args:
            account_id: Target account
            ticket: Position ticket
            volume: Volume to close
            timeout: Max wait time for response
            
        Returns:
            TradeResponse with result
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_close_partial(
            ticket=ticket,
            volume=volume,
            request_id=request_id
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return ProtocolHandler.parse_trade_response(response)
    
    async def close_position_by(
        self,
        account_id: str,
        ticket: int,
        opposite_ticket: int,
        timeout: float = 30.0
    ) -> TradeResponse:
        """
        Close a position by an opposite position (hedging accounts).
        
        Args:
            account_id: Target account
            ticket: Position ticket to close
            opposite_ticket: Opposite position ticket
            timeout: Max wait time for response
            
        Returns:
            TradeResponse with result
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_close_by(
            ticket=ticket,
            opposite_ticket=opposite_ticket,
            request_id=request_id
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return ProtocolHandler.parse_trade_response(response)
    
    async def get_pending_orders(self, account_id: str, timeout: float = 10.0) -> list:
        """Get pending orders from a node."""
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_pending_orders_request(request_id)
        
        node = self.nodes.get(account_id)
        if not node or not node.is_alive:
            raise ConnectionError(f"Node not available: {account_id}")
        
        future: asyncio.Future = asyncio.Future()
        node.pending_requests[request_id] = future
        
        await self._send_raw(node, packet)
        
        try:
            response = await asyncio.wait_for(future, timeout)
            return response.get("orders", [])
        except asyncio.TimeoutError:
            node.pending_requests.pop(request_id, None)
            raise
    
    async def get_deal_history(
        self,
        account_id: str,
        from_date: int = 0,
        to_date: int = 0,
        timeout: float = 30.0
    ) -> list:
        """
        Get deal/trade history from a node.
        
        Args:
            account_id: Target account
            from_date: Start date as Unix timestamp (0 = last 24h)
            to_date: End date as Unix timestamp (0 = now)
            timeout: Max wait time for response
            
        Returns:
            List of deals/trades
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_deal_history_request(
            from_date=from_date,
            to_date=to_date,
            request_id=request_id
        )
        
        node = self.nodes.get(account_id)
        if not node or not node.is_alive:
            raise ConnectionError(f"Node not available: {account_id}")
        
        future: asyncio.Future = asyncio.Future()
        node.pending_requests[request_id] = future
        
        await self._send_raw(node, packet)
        
        try:
            response = await asyncio.wait_for(future, timeout)
            return response.get("deals", [])
        except asyncio.TimeoutError:
            node.pending_requests.pop(request_id, None)
            raise
    
    async def get_symbol_info(
        self,
        account_id: str,
        symbol: str,
        timeout: float = 10.0
    ) -> SymbolInfo:
        """
        Get symbol information.
        
        Args:
            account_id: Target account
            symbol: Trading symbol
            timeout: Max wait time for response
            
        Returns:
            SymbolInfo with bid/ask, digits, etc.
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_symbol_info_request(
            symbol=symbol,
            request_id=request_id
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return ProtocolHandler.parse_symbol_info(response)
    
    async def get_current_price(
        self,
        account_id: str,
        symbol: str,
        timeout: float = 10.0
    ) -> dict:
        """
        Get current bid/ask price for a symbol.
        
        Args:
            account_id: Target account
            symbol: Trading symbol
            timeout: Max wait time for response
            
        Returns:
            Dict with bid, ask, time
        """
        request_id = str(uuid.uuid4())
        packet = ProtocolHandler.encode_current_price_request(
            symbol=symbol,
            request_id=request_id
        )
        
        response = await self._send_command(account_id, packet, request_id, timeout)
        return {
            "symbol": response.get("symbol", symbol),
            "bid": response.get("bid", 0.0),
            "ask": response.get("ask", 0.0),
            "time": response.get("time", 0)
        }
    
    async def close_all_positions_by_symbol(
        self,
        account_id: str,
        symbol: str,
        timeout: float = 60.0
    ) -> dict:
        """
        Close all positions for a symbol.
        
        Args:
            account_id: Target account
            symbol: Trading symbol
            timeout: Max wait time for response
            
        Returns:
            Dict with closed positions and results
        """
        positions = await self.get_positions(account_id)
        
        # Filter positions by symbol
        symbol_positions = [p for p in positions if p.get("symbol", "").upper() == symbol.upper()]
        
        results = []
        for pos in symbol_positions:
            ticket = pos.get("ticket", 0)
            if ticket:
                try:
                    result = await self.execute_trade(
                        account_id=account_id,
                        action="close",
                        symbol=symbol,
                        volume=0,
                        ticket=ticket,
                        timeout=timeout / len(symbol_positions)
                    )
                    results.append({
                        "ticket": ticket,
                        "success": result.success,
                        "comment": result.comment
                    })
                except Exception as e:
                    results.append({
                        "ticket": ticket,
                        "success": False,
                        "comment": str(e)
                    })
        
        return {
            "symbol": symbol,
            "total_positions": len(symbol_positions),
            "closed": sum(1 for r in results if r["success"]),
            "results": results
        }
    
    # ===================
    # Event Handlers
    # ===================
    
    def on_tick(self, handler: Callable[[str, TickData], Awaitable[None]]):
        """Register a tick handler."""
        self._tick_handlers.add(handler)
        return handler
    
    def on_connect(self, handler: Callable[[str, LoginData], Awaitable[None]]):
        """Register a connection handler."""
        self._connect_handlers.add(handler)
        return handler
    
    def on_disconnect(self, handler: Callable[[str], Awaitable[None]]):
        """Register a disconnection handler."""
        self._disconnect_handlers.add(handler)
        return handler
    
    # ===================
    # Status
    # ===================
    
    def get_connected_accounts(self) -> list[str]:
        """Get list of connected account IDs."""
        return [
            acc_id for acc_id, node in self.nodes.items()
            if node.state == NodeState.AUTHENTICATED
        ]
    
    def get_node_status(self, account_id: str) -> Optional[dict]:
        """Get status of a specific node."""
        node = self.nodes.get(account_id)
        if not node:
            return None
        
        return {
            "account_id": node.account_id,
            "state": node.state.value,
            "login": node.login_data.login if node.login_data else None,
            "server": node.login_data.server if node.login_data else None,
            "balance": node.login_data.balance if node.login_data else None,
            "connected": node.login_data.connected if node.login_data else False,
            "trade_allowed": node.login_data.trade_allowed if node.login_data else False,
            "last_ping": node.last_ping.isoformat(),
            "missed_pings": node.missed_pings,
            "is_alive": node.is_alive,
            "pid": node.pid
        }
    
    def get_farm_status(self) -> dict:
        """Get overall farm status."""
        nodes = [self.get_node_status(acc_id) for acc_id in self.nodes]
        return {
            "running": self._running,
            "host": self.host,
            "port": self.port,
            "protocol_version": PROTOCOL_VERSION,
            "total_nodes": len(self.nodes),
            "alive_nodes": sum(1 for n in nodes if n and n["is_alive"]),
            "nodes": nodes
        }


# Convenience for running standalone
async def main():
    """Run the controller standalone."""
    logging.basicConfig(level=logging.INFO)
    
    controller = FarmController()
    
    @controller.on_tick
    async def handle_tick(account_id: str, tick: TickData):
        print(f"[{account_id}] {tick.symbol}: {tick.bid}/{tick.ask}")
    
    @controller.on_connect
    async def handle_connect(account_id: str, login_data: LoginData):
        print(f"Connected: {account_id} ({login_data.login})")
    
    @controller.on_disconnect
    async def handle_disconnect(account_id: str):
        print(f"Disconnected: {account_id}")
    
    await controller.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
