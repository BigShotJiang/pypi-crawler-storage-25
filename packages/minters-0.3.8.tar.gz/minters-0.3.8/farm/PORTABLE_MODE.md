# MT5 Portable Mode - Quick Reference

## ⚠️ CRITICAL: Always Use Portable Mode!

When launching MT5 from `C:\MT5_MASTER` or any farm instance, you **MUST** use the `/portable` flag or MT5 will use the global AppData configuration instead of the local directory.

---

## The Problem You Just Encountered

**What happened:**
```powershell
# ❌ WRONG - Uses global AppData config
C:\MT5_MASTER\terminal64.exe
```

This launched MT5 using configuration from:
- `C:\Users\<username>\AppData\Roaming\MetaQuotes\Terminal\<hash>\`

That's why you saw an already logged-in instance - it was using the **global MT5 installation** config from `C:\Program Files\MetaTrader 5`, not your clean MASTER!

---

## The Solution

**Always launch in portable mode:**
```powershell
# ✅ CORRECT - Uses local Config folder
C:\MT5_MASTER\terminal64.exe /portable
```

Or use the helper script:
```powershell
.\tools\launch_master.ps1
```

This makes MT5 use configuration from:
- `C:\MT5_MASTER\Config\`

---

## How Portable Mode Works

MT5 checks for a file called `portable.dat` in its directory:

1. **If `portable.dat` exists** → Use local `Config\` folder (portable mode)
2. **If `portable.dat` missing** → Use global AppData folder (installed mode)

The cleanup script now automatically creates `portable.dat` for you.

---

## Verify Portable Mode is Active

After launching MT5, check which config it's using:

```powershell
# Should show files in C:\MT5_MASTER\Config\
Get-ChildItem "C:\MT5_MASTER\Config" -File

# Should NOT show your account in AppData
# (This would indicate non-portable mode)
Get-ChildItem "$env:APPDATA\MetaQuotes\Terminal" -ErrorAction SilentlyContinue
```

---

## Farm Provisioner Already Uses Portable Mode

Good news! The provisioner code already launches instances correctly:

```python
# From factory.py line 368
subprocess.Popen(
    [str(terminal_exe), "/portable"],  # ✅ Correct!
    cwd=str(instance_path)
)
```

So provisioned accounts in `C:\MT5_FARM\Account_*` will work correctly.

---

## Quick Commands

```powershell
# Clean the MASTER
.\tools\clean_master.ps1

# Launch MASTER in portable mode
.\tools\launch_master.ps1

# Verify MASTER is ready
python tools\verify_master.py

# Kill all MT5 instances
Stop-Process -Name terminal64 -Force
```

---

## Summary

- ✅ **Always use `/portable` flag** when launching MT5 manually
- ✅ **Use `.\tools\launch_master.ps1`** for convenience
- ✅ **`portable.dat` file** must exist in the MT5 directory
- ❌ **Never launch without `/portable`** or you'll use global config
- ✅ **Provisioner handles this automatically** for farm instances
