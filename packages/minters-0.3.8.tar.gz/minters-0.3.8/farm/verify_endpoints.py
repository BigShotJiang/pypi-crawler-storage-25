"""Quick verification of all farm API endpoints."""

import asyncio
import httpx

TESTS = [
    ("Health", "GET", "http://localhost:8000/health", None),
    ("Farm Status", "GET", "http://localhost:8000/farm/status", None),
    ("Account Info", "GET", "http://localhost:8000/farm/account/Account_297278718", None),
    ("Node Status", "GET", "http://localhost:8000/farm/status/Account_297278718", None),
    ("Positions", "GET", "http://localhost:8000/farm/positions/Account_297278718", None),
    ("Orders", "GET", "http://localhost:8000/farm/orders/Account_297278718", None),
    ("Deals", "GET", "http://localhost:8000/farm/deals/Account_297278718", None),
    ("Symbol Info", "GET", "http://localhost:8000/farm/symbol/Account_297278718/EURUSDm", None),
    ("Price", "GET", "http://localhost:8000/farm/price/Account_297278718/EURUSDm", None),
    ("History", "GET", "http://localhost:8000/farm/history/Account_297278718?symbol=EURUSDm&timeframe=H1&count=10", None),
    ("Instances", "GET", "http://localhost:8000/farm/instances", None),
    ("Brokers", "GET", "http://localhost:8000/farm/brokers", None),
    ("Trade BUY", "POST", "http://localhost:8000/farm/trade/Account_297278718", 
     {"action": "buy", "symbol": "EURUSDm", "volume": 0.01, "ticket": 0}),
]


async def test_endpoints():
    async with httpx.AsyncClient(timeout=30.0) as client:
        print("=" * 60)
        print("FARM API ENDPOINT VERIFICATION")
        print("=" * 60)
        print()
        
        passed = 0
        failed = 0
        
        for name, method, url, data in TESTS:
            try:
                if method == "GET":
                    resp = await client.get(url)
                else:
                    resp = await client.post(url, json=data)
                
                if resp.status_code == 200:
                    result = resp.json()
                    # Show key info based on response type
                    if "balance" in result:
                        info = f"balance={result.get('balance')}, equity={result.get('equity')}"
                    elif "positions" in result:
                        info = f"count={len(result.get('positions', []))}"
                    elif "orders" in result:
                        info = f"count={len(result.get('orders', []))}"
                    elif "deals" in result:
                        info = f"count={len(result.get('deals', []))}"
                    elif "rates" in result:
                        info = f"count={len(result.get('rates', []))}"
                    elif "total_nodes" in result:
                        info = f"nodes={result.get('total_nodes')}, alive={result.get('alive_nodes')}"
                    elif "is_alive" in result:
                        info = f"alive={result.get('is_alive')}, state={result.get('state')}"
                    elif "bid" in result:
                        info = f"bid={result.get('bid')}, ask={result.get('ask')}"
                    elif "instances" in result:
                        info = f"count={len(result.get('instances', []))}"
                    elif "brokers" in result:
                        info = f"count={len(result.get('brokers', []))}"
                    elif "success" in result:
                        info = f"success={result.get('success')}, ticket={result.get('ticket', 0)}"
                    else:
                        info = str(result)[:50]
                    
                    print(f"  OK  {name}: {info}")
                    passed += 1
                else:
                    print(f"FAIL  {name}: HTTP {resp.status_code}")
                    failed += 1
            except Exception as e:
                print(f"FAIL  {name}: {e}")
                failed += 1
        
        print()
        print("=" * 60)
        total = passed + failed
        print(f"RESULTS: {passed}/{total} passed ({100*passed//total}%)")
        print("=" * 60)


if __name__ == "__main__":
    asyncio.run(test_endpoints())
