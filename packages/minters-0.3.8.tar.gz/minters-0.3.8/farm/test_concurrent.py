"""Quick concurrent multi-account test."""

import asyncio
import httpx
import time


async def multi_account_test():
    async with httpx.AsyncClient(timeout=60.0) as client:
        # Get connected accounts
        resp = await client.get("http://localhost:8000/farm/status")
        data = resp.json()
        nodes = [n for n in data.get("nodes", []) if n.get("state") == "authenticated"]
        accounts = [n["account_id"] for n in nodes]
        
        print("=" * 60)
        print(f"CONCURRENT MULTI-ACCOUNT TEST ({len(accounts)} accounts)")
        print("=" * 60)
        
        for acc in accounts:
            print(f"  - {acc}")
        print()
        
        if len(accounts) == 0:
            print("No connected accounts!")
            return
        
        # Test 1: Concurrent account info from all accounts
        print("Test 1: Concurrent Account Info")
        start = time.time()
        tasks = [client.get(f"http://localhost:8000/farm/account/{acc}") for acc in accounts]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        for acc, result in zip(accounts, results):
            if hasattr(result, "json"):
                d = result.json()
                bal = d.get("balance")
                eq = d.get("equity")
                print(f"  {acc}: balance={bal}, equity={eq}")
        print(f"  Total time: {duration:.0f}ms")
        print()
        
        # Test 2: Concurrent historical data from all accounts
        print("Test 2: Concurrent Historical Data")
        start = time.time()
        tasks = [
            client.get(f"http://localhost:8000/farm/history/{acc}?symbol=EURUSDm&timeframe=H1&count=100") 
            for acc in accounts
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        for acc, result in zip(accounts, results):
            if hasattr(result, "json"):
                d = result.json()
                bars = len(d.get("rates", []))
                print(f"  {acc}: {bars} bars")
        print(f"  Total time: {duration:.0f}ms")
        print()
        
        # Test 3: Concurrent symbol info (multiple symbols per account)
        print("Test 3: Concurrent Symbol Info (4 symbols x N accounts)")
        symbols = ["EURUSDm", "GBPUSDm", "USDJPYm", "XAUUSDm"]
        start = time.time()
        tasks = []
        for acc in accounts:
            for sym in symbols:
                tasks.append(client.get(f"http://localhost:8000/farm/symbol/{acc}/{sym}"))
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        success = sum(1 for r in results if hasattr(r, "status_code") and r.status_code == 200)
        print(f"  {success}/{len(tasks)} requests successful")
        print(f"  Total time: {duration:.0f}ms")
        print()
        
        # Test 4: Concurrent positions from all accounts
        print("Test 4: Concurrent Positions Query")
        start = time.time()
        tasks = [client.get(f"http://localhost:8000/farm/positions/{acc}") for acc in accounts]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        duration = (time.time() - start) * 1000
        
        for acc, result in zip(accounts, results):
            if hasattr(result, "json"):
                d = result.json()
                count = len(d.get("positions", []))
                print(f"  {acc}: {count} positions")
        print(f"  Total time: {duration:.0f}ms")
        print()
        
        print("=" * 60)
        print("ALL CONCURRENT TESTS COMPLETED SUCCESSFULLY")
        print("=" * 60)


if __name__ == "__main__":
    asyncio.run(multi_account_test())
