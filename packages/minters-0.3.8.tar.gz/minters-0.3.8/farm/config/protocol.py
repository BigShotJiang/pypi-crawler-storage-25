"""
Protocol Constants - Re-export from controller module.
"""

from ..controller.protocol import PROTOCOL_VERSION, MessageType

__all__ = ["PROTOCOL_VERSION", "MessageType"]
