"""
Config Module - Configuration schemas and templates

Contains:
- Protocol definitions (message types, packet structures)
- Farm configuration (paths, ports, timeouts)
- MT5 templates (terminal.ini, default.tpl)
"""

from .settings import FarmSettings
from .protocol import PROTOCOL_VERSION, MessageType

__all__ = ["FarmSettings", "PROTOCOL_VERSION", "MessageType"]
