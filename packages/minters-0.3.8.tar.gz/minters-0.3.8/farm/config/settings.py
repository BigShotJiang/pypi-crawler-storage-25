"""
Farm Settings - Configuration for the MT5 Farm.

Uses Pydantic settings for environment variable support and validation.
"""

from pathlib import Path
from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings


class FarmSettings(BaseSettings):
    """
    Configuration settings for the MT5 Farm.
    
    Settings can be overridden via environment variables with FARM_ prefix.
    Example: FARM_CONTROLLER_PORT=9999
    """
    
    # Controller settings
    controller_host: str = Field("127.0.0.1", description="IP to bind the controller server")
    controller_port: int = Field(8888, description="Port for the controller server")
    
    # Heartbeat settings
    ping_interval: float = Field(5.0, description="Seconds between heartbeat pings")
    ping_timeout: float = Field(3.0, description="Seconds to wait for pong response")
    max_missed_pings: int = Field(3, description="Missed pings before marking zombie")
    
    # Provisioner settings
    master_path: Path = Field(
        Path("C:/MT5_MASTER"), 
        description="Path to golden image MT5 installation"
    )
    farm_path: Path = Field(
        Path("C:/MT5_FARM"),
        description="Path where account instances are created"
    )
    
    # API settings
    api_host: str = Field("0.0.0.0", description="IP to bind the API server")
    api_port: int = Field(8000, description="Port for the API server")
    
    # Health check settings
    health_check_interval: float = Field(
        10.0, 
        description="Seconds between automated health checks"
    )
    auto_recovery: bool = Field(
        False,  # Disabled to allow graceful termination without auto-restart
        description="Whether to automatically recover zombie instances"
    )
    golden_seed_account: Optional[str] = Field(
        None,  # No default account - MT5_MASTER is a clean golden template
        description="Protected golden seed account ID that cannot be deleted"
    )
    
    # Security
    api_key: Optional[str] = Field(
        None, 
        description="Optional API key for authentication"
    )
    
    # Logging
    log_level: str = Field("INFO", description="Logging level")
    log_file: Optional[Path] = Field(None, description="Optional log file path")
    
    class Config:
        env_prefix = "FARM_"
        env_file = ".env"
        extra = "ignore"  # Ignore extra fields from .env


# Default settings instance
settings = FarmSettings()
