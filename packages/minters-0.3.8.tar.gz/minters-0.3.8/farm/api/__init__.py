"""
API Module - FastAPI REST + WebSocket Interface

Endpoints:
- POST /provision: Create new MT5 instance
- POST /trade/{account_id}: Execute trade command
- WS /stream/{account_id}: Real-time tick streaming
- GET /status: Farm health and node status
"""

from .router import router

__all__ = ["router"]
