"""
FastAPI Router for MT5 Farm - REST + WebSocket Interface

Endpoints:
- POST /provision: Create new MT5 instance
- DELETE /provision/{account_id}: Terminate instance
- POST /launch/{account_id}: Launch provisioned instance

Market Orders:
- POST /trade/{account_id}: Execute market trade (buy/sell/close)
- POST /close/{account_id}/{ticket}: Close position by ticket

Pending Orders:
- POST /order/{account_id}: Place pending order (limit/stop/stop-limit)
- PUT /order/{account_id}/{ticket}: Modify pending order
- DELETE /order/{account_id}/{ticket}: Cancel pending order

Position Management:
- GET /positions/{account_id}: Get open positions
- PUT /position/{account_id}/{ticket}: Modify position (SL/TP)
- POST /position/{account_id}/{ticket}/close-partial: Partial close
- POST /position/{account_id}/{ticket}/close-by/{opposite_ticket}: Close by opposite
- POST /positions/{account_id}/close-all/{symbol}: Close all positions by symbol

Account & Data:
- GET /account/{account_id}: Get account info
- GET /orders/{account_id}: Get pending orders
- GET /history/{account_id}: Get deal history
- GET /history/{account_id}/rates: Get historical rates
- GET /symbol/{account_id}/{symbol}: Get symbol info
- GET /price/{account_id}/{symbol}: Get current price

Farm Management:
- GET /status: Farm health and node status
- GET /status/{account_id}: Specific node status
- GET /instances: List all provisioned instances
- GET /brokers: List available broker servers
- GET /brokers/search: Search for broker servers
- POST /brokers/prepare: Prepare a new broker for use
- POST /recover/{account_id}: Recover zombie instance
- POST /health-check: Run health check on all instances

WebSocket:
- WS /stream/{account_id}: Real-time tick streaming for account
- WS /stream: All ticks from all accounts
"""

import asyncio
import logging
from contextlib import asynccontextmanager
from typing import Optional, Set

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, HTTPException, Query, BackgroundTasks
from pydantic import BaseModel, Field

from ..controller import FarmController, TickData, LoginData
from ..provisioner import MT5Provisioner
from ..provisioner.broker_discovery import get_broker_discovery

logger = logging.getLogger(__name__)

# ================
# Pydantic Models
# ================

class ProvisionRequest(BaseModel):
    """Request to provision a new MT5 instance."""
    account_id: Optional[str] = Field(default=None, description="Unique identifier for the account (auto-generated if not provided)")
    login: int = Field(..., description="MT5 account login number")
    password: str = Field(..., description="MT5 account password")
    server: str = Field(..., description="MT5 broker server (e.g., 'Exness-MT5Trial9')")
    auto_launch: bool = Field(True, description="Whether to start the instance immediately")
    server_seed_path: Optional[str] = Field(
        None, 
        description="Optional path to existing MT5 folder with broker config. "
                    "If not provided, auto-discovers from common locations."
    )


class ProvisionResponse(BaseModel):
    """Response from provision request."""
    success: bool
    account_id: str
    message: str
    pid: Optional[int] = None


class TradeRequest(BaseModel):
    """Request to execute a trade."""
    action: str = Field(..., description="Trade action: buy, sell, or close")
    symbol: str = Field(..., description="Trading symbol (e.g., EURUSD)")
    volume: float = Field(..., description="Lot size", gt=0)
    ticket: int = Field(0, description="Position ticket (for close action)")


class TradeResponse(BaseModel):
    """Response from trade execution."""
    success: bool
    ticket: int = 0
    retcode: int = 0
    message: str = ""


class PendingOrderRequest(BaseModel):
    """Request to place a pending order."""
    order_type: str = Field(..., description="Order type: buy_limit, sell_limit, buy_stop, sell_stop, buy_stop_limit, sell_stop_limit")
    symbol: str = Field(..., description="Trading symbol (e.g., EURUSD)")
    volume: float = Field(..., description="Lot size", gt=0)
    price: float = Field(..., description="Order price")
    stop_limit_price: float = Field(0.0, description="Stop-limit trigger price (for stop-limit orders)")
    stop_loss: float = Field(0.0, description="Stop loss price")
    take_profit: float = Field(0.0, description="Take profit price")
    expiration: int = Field(0, description="Expiration as Unix timestamp (0 = GTC)")
    magic: int = Field(0, description="Magic number for order identification")
    comment: str = Field("", description="Order comment")


class ModifyPositionRequest(BaseModel):
    """Request to modify a position."""
    stop_loss: float = Field(0.0, description="New stop loss (0 = no change)")
    take_profit: float = Field(0.0, description="New take profit (0 = no change)")
    trailing_stop: float = Field(0.0, description="Trailing stop distance in points")


class ModifyOrderRequest(BaseModel):
    """Request to modify a pending order."""
    price: float = Field(0.0, description="New order price (0 = no change)")
    stop_limit_price: float = Field(0.0, description="New stop-limit price (0 = no change)")
    stop_loss: float = Field(0.0, description="New stop loss (0 = no change)")
    take_profit: float = Field(0.0, description="New take profit (0 = no change)")
    expiration: int = Field(0, description="New expiration timestamp (0 = no change)")


class PartialCloseRequest(BaseModel):
    """Request to partially close a position."""
    volume: float = Field(..., description="Volume to close", gt=0)


class StatusResponse(BaseModel):
    """Farm status response."""
    running: bool
    host: str
    port: int
    protocol_version: str
    total_nodes: int
    alive_nodes: int
    nodes: list


class AccountStatusResponse(BaseModel):
    """Account status response."""
    account_id: str
    login: Optional[int]
    server: Optional[str]
    balance: Optional[float]
    is_alive: bool
    state: str
    pid: Optional[int]


# ================
# Global State
# ================

# These will be initialized by the main app
_controller: Optional[FarmController] = None
_provisioner: Optional[MT5Provisioner] = None

# WebSocket subscribers
_ws_subscribers: dict[str, Set[WebSocket]] = {}  # account_id -> set of websockets
_ws_all_subscribers: Set[WebSocket] = set()  # subscribers to all ticks


def get_controller() -> FarmController:
    """Get the farm controller instance."""
    if _controller is None:
        raise HTTPException(status_code=503, detail="Controller not initialized")
    return _controller


def get_provisioner() -> MT5Provisioner:
    """Get the provisioner instance."""
    if _provisioner is None:
        raise HTTPException(status_code=503, detail="Provisioner not initialized")
    return _provisioner


# ================
# Router
# ================

router = APIRouter(prefix="/farm", tags=["MT5 Farm"])


@router.post("/provision", response_model=ProvisionResponse, status_code=202)
async def provision_account(request: ProvisionRequest, background_tasks: BackgroundTasks):
    """
    Provision a new MT5 instance.
    
    Creates a new MT5 installation, injects credentials, and optionally
    starts the instance. Automatically discovers broker server configuration
    from existing MT5 installations.
    """
    provisioner = get_provisioner()
    
    # Generate 16-digit UUID if account_id not provided
    account_id = request.account_id
    if not account_id:
        import secrets
        # Generate 16-digit random number
        account_id = str(secrets.randbelow(10**16)).zfill(16)
        logger.info(f"Generated account_id: {account_id}")
    
    try:
        instance = await provisioner.provision_account(
            account_id=account_id,
            login=request.login,
            password=request.password,
            server=request.server,
            auto_launch=request.auto_launch,
            server_seed_path=request.server_seed_path
        )
        
        if request.auto_launch:
            # We don't block the API response; queue the connection check as a background task
            background_tasks.add_task(_wait_for_connection, account_id, instance.path)
            message = "Account provisioned and MT5 launched. Waiting for connection in background."
        else:
            message = "Account provisioned successfully (auto-launch disabled)."
            
        return ProvisionResponse(
            success=True,
            account_id=instance.account_id,
            message=message,
            pid=instance.pid
        )
        
    except Exception as e:
        logger.error(f"Provision failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

async def _wait_for_connection(account_id: str, instance_path):
    """Background task to wait for EA connection and broker authentication."""
    import asyncio
    import time
    
    try:
        controller = get_controller()
        provisioner = get_provisioner()
        logger.info(f"Background task: Waiting for EA connection and broker authentication for {account_id}...")
        
        start_time = time.time()
        is_connected = False
        
        while time.time() - start_time < 45.0:
            node = controller.nodes.get(account_id)
            # We just need the EA to authenticate with the controller socket
            if node and node.state.name == "AUTHENTICATED":
                is_connected = True
                break
            await asyncio.sleep(1)
            
        if not is_connected:
            logger.warning(f"EA connection timeout for {account_id}, checking if broker login succeeded...")
            
            # Check MT5 logs directly for specific error (e.g., invalid password)
            login_success = await provisioner._wait_for_login_status(account_id, instance_path, timeout=5)
            
            if not login_success:
                logger.error(f"Authentication failed for {account_id}: Invalid account login or password. Terminating instance.")
                await provisioner.terminate_account(account_id, cleanup=False)
            else:
                logger.warning(f"Broker login SUCCESS for {account_id}, but MT5 Bridge EA is taking longer to connect to controller. Leaving instance running.")
        else:
            logger.info(f"Broker connection successful for {account_id}")
            
    except Exception as e:
        logger.error(f"Error in background connection wait for {account_id}: {e}")


@router.delete("/provision/{account_id}")
async def terminate_account(account_id: str, cleanup: bool = False):
    """
    Terminate an MT5 instance.
    
    Args:
        account_id: Account to terminate
        cleanup: Whether to delete the instance directory
    """
    provisioner = get_provisioner()
    
    success = await provisioner.terminate_account(account_id, cleanup=cleanup)
    if not success:
        raise HTTPException(status_code=404, detail=f"Account {account_id} not found")
    
    return {"success": True, "message": f"Account {account_id} terminated"}


@router.delete("/provision")
async def terminate_all_accounts(cleanup: bool = False, exclude_golden: bool = True):
    """
    Terminate ALL MT5 instances.
    
    Args:
        cleanup: Whether to delete instance directories
        exclude_golden: Whether to exclude the golden seed account from termination
    
    Returns:
        Summary of terminated accounts
    """
    from farm.config.settings import settings
    
    provisioner = get_provisioner()
    
    # Get list of all instances
    all_instances = provisioner.get_all_instances()
    account_ids = [inst["account_id"] for inst in all_instances]
    
    terminated = []
    failed = []
    skipped = []
    
    for account_id in account_ids:
        # Skip golden seed if requested
        if exclude_golden and settings.golden_seed_account:
            if account_id == settings.golden_seed_account:
                skipped.append(account_id)
                logger.info(f"Skipping golden seed account: {account_id}")
                continue
        
        try:
            success = await provisioner.terminate_account(account_id, cleanup=cleanup)
            if success:
                terminated.append(account_id)
                logger.info(f"Terminated account: {account_id}")
            else:
                failed.append(account_id)
                logger.warning(f"Failed to terminate account: {account_id}")
        except Exception as e:
            logger.error(f"Error terminating {account_id}: {e}")
            failed.append(account_id)
    
    return {
        "success": True,
        "terminated": terminated,
        "failed": failed,
        "skipped": skipped,
        "total_terminated": len(terminated),
        "total_failed": len(failed),
        "total_skipped": len(skipped)
    }


@router.post("/launch/{account_id}")
async def launch_account(account_id: str):
    """Launch a provisioned MT5 instance."""
    provisioner = get_provisioner()
    
    success = await provisioner.launch_account(account_id)
    if not success:
        raise HTTPException(status_code=500, detail=f"Failed to launch account {account_id}")
    
    instance = provisioner.instances.get(account_id)
    return {
        "success": True, 
        "message": f"Account {account_id} launched",
        "pid": instance.pid if instance else None
    }


@router.post("/trade/{account_id}", response_model=TradeResponse)
async def execute_trade(account_id: str, request: TradeRequest):
    """
    Execute a trade on a specific account.
    
    Supported actions:
    - buy: Open a buy position
    - sell: Open a sell position
    - close: Close a position by ticket
    """
    controller = get_controller()
    
    try:
        result = await controller.execute_trade(
            account_id=account_id,
            action=request.action,
            symbol=request.symbol,
            volume=request.volume,
            ticket=request.ticket
        )
        
        return TradeResponse(
            success=result.success,
            ticket=result.ticket,
            retcode=result.retcode,
            message=result.comment
        )
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.post("/close/{account_id}/{ticket}")
async def close_position(account_id: str, ticket: int):
    """Close a specific position by ticket."""
    controller = get_controller()
    
    try:
        result = await controller.execute_trade(
            account_id=account_id,
            action="close",
            symbol="",
            volume=0,
            ticket=ticket
        )
        
        return TradeResponse(
            success=result.success,
            ticket=result.ticket,
            retcode=result.retcode,
            message=result.comment
        )
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


# ================
# Pending Orders
# ================

@router.post("/order/{account_id}", response_model=TradeResponse)
async def place_pending_order(account_id: str, request: PendingOrderRequest):
    """
    Place a pending order on a specific account.
    
    Supported order types:
    - buy_limit: Buy when price drops to specified level
    - sell_limit: Sell when price rises to specified level
    - buy_stop: Buy when price rises to specified level
    - sell_stop: Sell when price drops to specified level
    - buy_stop_limit: Place buy limit when price reaches stop level
    - sell_stop_limit: Place sell limit when price reaches stop level
    """
    controller = get_controller()
    
    try:
        result = await controller.place_pending_order(
            account_id=account_id,
            order_type=request.order_type,
            symbol=request.symbol,
            volume=request.volume,
            price=request.price,
            stop_limit_price=request.stop_limit_price,
            stop_loss=request.stop_loss,
            take_profit=request.take_profit,
            expiration=request.expiration,
            magic=request.magic,
            comment=request.comment
        )
        
        return TradeResponse(
            success=result.success,
            ticket=result.ticket,
            retcode=result.retcode,
            message=result.comment
        )
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.put("/order/{account_id}/{ticket}", response_model=TradeResponse)
async def modify_pending_order(account_id: str, ticket: int, request: ModifyOrderRequest):
    """Modify a pending order."""
    controller = get_controller()
    
    try:
        result = await controller.modify_order(
            account_id=account_id,
            ticket=ticket,
            price=request.price,
            stop_limit_price=request.stop_limit_price,
            stop_loss=request.stop_loss,
            take_profit=request.take_profit,
            expiration=request.expiration
        )
        
        return TradeResponse(
            success=result.success,
            ticket=result.ticket,
            retcode=result.retcode,
            message=result.comment
        )
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.delete("/order/{account_id}/{ticket}", response_model=TradeResponse)
async def cancel_pending_order(account_id: str, ticket: int):
    """Cancel a pending order."""
    controller = get_controller()
    
    try:
        result = await controller.cancel_order(
            account_id=account_id,
            ticket=ticket
        )
        
        return TradeResponse(
            success=result.success,
            ticket=result.ticket,
            retcode=result.retcode,
            message=result.comment
        )
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.get("/orders/{account_id}")
async def get_pending_orders(account_id: str):
    """Get pending orders for an account."""
    controller = get_controller()
    
    try:
        orders = await controller.get_pending_orders(account_id)
        return {"account_id": account_id, "orders": orders}
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


# ================
# Position Management
# ================

@router.put("/position/{account_id}/{ticket}", response_model=TradeResponse)
async def modify_position(account_id: str, ticket: int, request: ModifyPositionRequest):
    """Modify a position's stop loss and take profit."""
    controller = get_controller()
    
    try:
        result = await controller.modify_position(
            account_id=account_id,
            ticket=ticket,
            stop_loss=request.stop_loss,
            take_profit=request.take_profit,
            trailing_stop=request.trailing_stop
        )
        
        return TradeResponse(
            success=result.success,
            ticket=result.ticket,
            retcode=result.retcode,
            message=result.comment
        )
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.post("/position/{account_id}/{ticket}/close-partial", response_model=TradeResponse)
async def close_position_partial(account_id: str, ticket: int, request: PartialCloseRequest):
    """Partially close a position."""
    controller = get_controller()
    
    try:
        result = await controller.close_position_partial(
            account_id=account_id,
            ticket=ticket,
            volume=request.volume
        )
        
        return TradeResponse(
            success=result.success,
            ticket=result.ticket,
            retcode=result.retcode,
            message=result.comment
        )
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.post("/position/{account_id}/{ticket}/close-by/{opposite_ticket}", response_model=TradeResponse)
async def close_position_by_opposite(account_id: str, ticket: int, opposite_ticket: int):
    """Close a position by an opposite position (for hedging accounts)."""
    controller = get_controller()
    
    try:
        result = await controller.close_position_by(
            account_id=account_id,
            ticket=ticket,
            opposite_ticket=opposite_ticket
        )
        
        return TradeResponse(
            success=result.success,
            ticket=result.ticket,
            retcode=result.retcode,
            message=result.comment
        )
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.post("/positions/{account_id}/close-all/{symbol}")
async def close_all_positions_by_symbol(account_id: str, symbol: str):
    """Close all positions for a specific symbol."""
    controller = get_controller()
    
    try:
        result = await controller.close_all_positions_by_symbol(
            account_id=account_id,
            symbol=symbol
        )
        return result
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.get("/positions/{account_id}")
async def get_positions(account_id: str):
    """Get open positions for an account."""
    controller = get_controller()
    
    try:
        positions = await controller.get_positions(account_id)
        return {"account_id": account_id, "positions": positions}
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.get("/account/{account_id}")
async def get_account_info(account_id: str):
    """Get account information."""
    controller = get_controller()
    
    try:
        info = await controller.get_account_info(account_id)
        return info
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


# ================
# Market Data
# ================

@router.get("/symbol/{account_id}/{symbol}")
async def get_symbol_info(account_id: str, symbol: str):
    """Get symbol information including bid/ask, digits, spread, etc."""
    controller = get_controller()
    
    try:
        info = await controller.get_symbol_info(account_id, symbol)
        return {
            "account_id": account_id,
            "symbol": info.symbol,
            "bid": info.bid,
            "ask": info.ask,
            "digits": info.digits,
            "point": info.point,
            "spread": info.spread,
            "volume_min": info.volume_min,
            "volume_max": info.volume_max,
            "volume_step": info.volume_step,
            "trade_mode": info.trade_mode
        }
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.get("/price/{account_id}/{symbol}")
async def get_current_price(account_id: str, symbol: str):
    """Get current bid/ask price for a symbol."""
    controller = get_controller()
    
    try:
        price = await controller.get_current_price(account_id, symbol)
        return {
            "account_id": account_id,
            **price
        }
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.get("/deals/{account_id}")
async def get_deal_history(
    account_id: str,
    from_date: int = Query(0, description="Start date as Unix timestamp (0 = last 24h)"),
    to_date: int = Query(0, description="End date as Unix timestamp (0 = now)")
):
    """Get deal/trade history for an account."""
    controller = get_controller()
    
    try:
        deals = await controller.get_deal_history(
            account_id=account_id,
            from_date=from_date,
            to_date=to_date
        )
        return {"account_id": account_id, "deals": deals}
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))


@router.get("/history/{account_id}")
async def get_historical_rates(
    account_id: str,
    symbol: str = Query(..., description="Trading symbol (e.g., 'EURUSDm')"),
    timeframe: str = Query("M1", description="Timeframe: M1, M5, M15, M30, H1, H4, D1, W1"),
    count: int = Query(100, description="Number of bars to fetch", ge=1, le=5000),
    start_time: int = Query(0, description="Unix start timestamp (0 = latest bars)", ge=0),
    end_time: int = Query(0, description="Unix end timestamp for range mode (0 = not set)", ge=0),
    offset: int = Query(0, description="Bar offset from current for pagination mode", ge=0),
):
    """
    Get historical OHLC rates for a symbol.
    
    Returns candle data with time, open, high, low, close, tick_volume, spread.
    """
    controller = get_controller()
    
    try:
        rates = await controller.get_historical_rates(
            account_id=account_id,
            symbol=symbol,
            timeframe=timeframe,
            count=count,
            start_time=start_time,
            end_time=end_time,
            offset=offset,
        )
        return {
            "account_id": account_id,
            "symbol": symbol,
            "timeframe": timeframe,
            "start_time": start_time,
            "end_time": end_time,
            "offset": offset,
            "count": len(rates),
            "rates": rates
        }
        
    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))
    except Exception as e:
        logger.error(f"Historical rates error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/ticks/{account_id}")
async def get_historical_ticks(
    account_id: str,
    symbol: str = Query(..., description="Trading symbol (e.g., 'XAUUSDm')"),
    offset: int = Query(0, description="Tick offset for pagination", ge=0),
    limit: int = Query(100, description="Number of ticks to fetch", ge=1, le=5000),
    start_time: int = Query(0, description="Unix start timestamp (0 = broker decides range)", ge=0),
    end_time: int = Query(0, description="Unix end timestamp (0 = up to current time)", ge=0),
):
    """Get historical ticks for a symbol."""
    controller = get_controller()

    try:
        ticks = await controller.get_historical_ticks(
            account_id=account_id,
            symbol=symbol,
            start_time=start_time,
            end_time=end_time,
            offset=offset,
            limit=limit,
        )
        return {
            "account_id": account_id,
            "symbol": symbol,
            "offset": offset,
            "limit": limit,
            "count": len(ticks),
            "ticks": ticks,
        }

    except ConnectionError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except TimeoutError as e:
        raise HTTPException(status_code=504, detail=str(e))
    except Exception as e:
        logger.error(f"Historical ticks error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/brokers")
async def list_available_brokers():
    """
    List broker servers available for provisioning.
    
    Returns brokers that have been used on this machine before.
    Brokers with 'ready=true' can be provisioned immediately.
    Brokers with 'ready=false' may need manual login first to download server config.
    
    For a new broker not in this list:
    1. Open MT5 manually
    2. Login to the new broker account once
    3. Close MT5
    4. The broker will then appear in this list with ready=true
    
    Or use /brokers/search and /brokers/prepare for automatic setup.
    """
    provisioner = get_provisioner()
    brokers = provisioner.list_available_brokers()
    
    return {
        "total": len(brokers),
        "ready_count": sum(1 for b in brokers if b['ready']),
        "brokers": brokers,
        "note": "Brokers with ready=true can be provisioned. Use /brokers/search for new brokers."
    }


@router.get("/brokers/search")
async def search_brokers(query: str = Query(..., description="Broker name or server to search for")):
    """
    Search for broker servers in MQL5's database.
    
    Use this to find the exact server name for a broker before provisioning.
    Works for any broker supported by MetaTrader 5.
    
    Example: /brokers/search?query=exness
    """
    discovery = get_broker_discovery()
    
    try:
        results = await discovery.search_brokers(query)
        return {
            "query": query,
            "total": len(results),
            "results": results,
            "usage": "Use the 'server' field when provisioning an account."
        }
    except Exception as e:
        logger.error(f"Broker search failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class BrokerPrepareRequest(BaseModel):
    """Request to prepare a broker for first-time use."""
    server: str = Field(..., description="Broker server name (e.g., 'Exness-MT5Trial9')")


@router.post("/brokers/prepare")
async def prepare_broker(request: BrokerPrepareRequest):
    """
    Prepare a new broker for provisioning.
    
    This fetches broker server configuration from MQL5's servers,
    allowing accounts to be provisioned without prior manual login.
    
    Use this for cloud deployments where manual MT5 login isn't practical.
    
    Steps:
    1. Call /brokers/search to find the exact server name
    2. Call /brokers/prepare with the server name
    3. Server will be ready for /provision calls
    """
    discovery = get_broker_discovery()
    provisioner = get_provisioner()
    
    try:
        # Fetch server config
        server = await discovery.fetch_server_config(request.server)
        
        if server:
            # Cache the config for future use
            return {
                "success": True,
                "server": request.server,
                "company": server.company,
                "addresses": len(server.addresses),
                "ready": True,
                "message": f"Broker '{request.server}' is ready for provisioning."
            }
        else:
            return {
                "success": False,
                "server": request.server,
                "ready": False,
                "message": f"Could not fetch config for '{request.server}'. "
                           "Try searching with /brokers/search to verify the server name."
            }
            
    except Exception as e:
        logger.error(f"Broker prepare failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/status", response_model=StatusResponse)
async def get_farm_status():
    """Get overall farm status."""
    controller = get_controller()
    return controller.get_farm_status()


@router.get("/status/{account_id}")
async def get_node_status(account_id: str):
    """Get status of a specific node."""
    controller = get_controller()
    
    status = controller.get_node_status(account_id)
    if not status:
        raise HTTPException(status_code=404, detail=f"Account {account_id} not found")
    
    return status


@router.get("/instances")
async def list_instances():
    """List all provisioned instances."""
    provisioner = get_provisioner()
    return {"instances": provisioner.get_all_instances()}


@router.post("/recover/{account_id}")
async def recover_zombie(account_id: str):
    """Attempt to recover a zombie instance."""
    provisioner = get_provisioner()
    
    success = await provisioner.recover_zombie(account_id)
    if not success:
        raise HTTPException(
            status_code=500, 
            detail=f"Failed to recover account {account_id}"
        )
    
    return {"success": True, "message": f"Account {account_id} recovered"}


@router.post("/health-check")
async def health_check_all():
    """Run health check on all instances."""
    provisioner = get_provisioner()
    results = await provisioner.health_check_all()
    return {"results": results}


# ================
# WebSocket Streaming
# ================

@router.websocket("/stream/{account_id}")
async def stream_ticks(websocket: WebSocket, account_id: str):
    """
    WebSocket endpoint for streaming ticks from a specific account.
    
    Messages are JSON with format:
    {"symbol": "EURUSD", "time": 1234567890, "bid": 1.2345, "ask": 1.2346}
    """
    await websocket.accept()
    
    # Add to subscribers
    if account_id not in _ws_subscribers:
        _ws_subscribers[account_id] = set()
    _ws_subscribers[account_id].add(websocket)
    
    logger.info(f"WebSocket connected for {account_id}")
    
    try:
        # Keep connection alive
        while True:
            try:
                # Wait for any message (ping/pong or commands)
                message = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=30.0
                )
                # Could handle commands here if needed
                
            except asyncio.TimeoutError:
                # Send ping to keep alive
                await websocket.send_json({"type": "ping"})
                
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error(f"WebSocket error for {account_id}: {e}")
    finally:
        _ws_subscribers[account_id].discard(websocket)
        if not _ws_subscribers[account_id]:
            del _ws_subscribers[account_id]
        logger.info(f"WebSocket disconnected for {account_id}")


@router.websocket("/stream")
async def stream_all_ticks(websocket: WebSocket):
    """
    WebSocket endpoint for streaming ticks from all accounts.
    
    Messages are JSON with format:
    {"account_id": "12345", "symbol": "EURUSD", "time": 1234567890, ...}
    """
    await websocket.accept()
    
    _ws_all_subscribers.add(websocket)
    logger.info("WebSocket connected for all ticks")
    
    try:
        while True:
            try:
                message = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=30.0
                )
            except asyncio.TimeoutError:
                await websocket.send_json({"type": "ping"})
                
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        _ws_all_subscribers.discard(websocket)
        logger.info("WebSocket disconnected for all ticks")


# ================
# Event Handlers
# ================

async def broadcast_tick(account_id: str, tick: TickData):
    """Broadcast tick to WebSocket subscribers."""
    global _ws_all_subscribers
    
    tick_data = {
        "account_id": account_id,
        "symbol": tick.symbol,
        "time": tick.time,
        "bid": tick.bid,
        "ask": tick.ask,
        "last": tick.last,
        "volume": tick.volume
    }
    
    # Send to account-specific subscribers
    if account_id in _ws_subscribers:
        dead_sockets = set()
        for ws in _ws_subscribers[account_id]:
            try:
                await ws.send_json(tick_data)
            except Exception:
                dead_sockets.add(ws)
        _ws_subscribers[account_id] -= dead_sockets
    
    # Send to all-ticks subscribers
    dead_sockets = set()
    for ws in _ws_all_subscribers:
        try:
            await ws.send_json(tick_data)
        except Exception:
            dead_sockets.add(ws)
    if dead_sockets:
        _ws_all_subscribers = _ws_all_subscribers - dead_sockets


async def handle_connect(account_id: str, login_data: LoginData):
    """Handle node connection event."""
    logger.info(f"Node connected: {account_id}")
    
    # Broadcast to all-ticks subscribers
    for ws in _ws_all_subscribers:
        try:
            await ws.send_json({
                "type": "connect",
                "account_id": account_id,
                "login": login_data.login,
                "server": login_data.server
            })
        except Exception:
            pass


async def handle_disconnect(account_id: str):
    """Handle node disconnection event."""
    logger.info(f"Node disconnected: {account_id}")
    
    # Broadcast to subscribers
    if account_id in _ws_subscribers:
        for ws in _ws_subscribers[account_id]:
            try:
                await ws.send_json({
                    "type": "disconnect",
                    "account_id": account_id
                })
            except Exception:
                pass
    
    for ws in _ws_all_subscribers:
        try:
            await ws.send_json({
                "type": "disconnect",
                "account_id": account_id
            })
        except Exception:
            pass


# ================
# Initialization
# ================

def init_farm_router(
    controller: FarmController,
    provisioner: MT5Provisioner
):
    """
    Initialize the farm router with controller and provisioner.
    
    Call this during app startup.
    """
    global _controller, _provisioner
    _controller = controller
    _provisioner = provisioner
    
    # Register event handlers
    controller.on_tick(broadcast_tick)
    controller.on_connect(handle_connect)
    controller.on_disconnect(handle_disconnect)
    
    logger.info("Farm router initialized")
