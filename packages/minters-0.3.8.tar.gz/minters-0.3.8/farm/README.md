# MT5 Farm

A Python-powered server farm for running multiple MetaTrader 5 instances with centralized control via REST API. Execute trades, stream ticks, and manage accounts programmatically.

## Features

- 🚀 **Multi-Account Management** - Run 10+ MT5 instances on a single machine
- 🔌 **Native Sockets** - No DLL required (MT5 build 2390+)
- 📡 **REST + WebSocket API** - Trade and stream via HTTP
- 🔄 **Auto-Recovery** - Detect and restart zombie instances
- 🔐 **Secure Credentials** - Windows Credential Manager integration

---

## Quick Start

### 1. Start the Farm Server

```powershell
# Activate Python environment
.venv\Scripts\Activate.ps1

# Run the farm
python -m farm.main
```

The server starts on:
- **API**: http://localhost:8000
- **Controller**: tcp://127.0.0.1:8888

### 2. Check Status

```powershell
curl http://localhost:8000/farm/status
```

### 3. Execute a Trade

```powershell
$body = '{"action":"buy","symbol":"XAUUSDm","volume":0.01}'
Invoke-RestMethod -Uri "http://localhost:8000/farm/trade/Account_test_297102439" `
  -Method POST -Body $body -ContentType "application/json"
```

Response:
```json
{
  "success": true,
  "ticket": 1573222195,
  "retcode": 10009,
  "message": "ok"
}
```

---

## API Reference

### Farm Status

```
GET /farm/status
```

Returns all connected MT5 instances and their state.

**Response:**
```json
{
  "running": true,
  "total_nodes": 1,
  "alive_nodes": 1,
  "nodes": [
    {
      "account_id": "Account_test_297102439",
      "state": "authenticated",
      "login": 297102439,
      "server": "Exness-MT5Trial9",
      "balance": 50.01,
      "trade_allowed": true,
      "is_alive": true
    }
  ]
}
```

---

### Execute Trade

```
POST /farm/trade/{account_id}
```

**Actions:**
| Action | Description |
|--------|-------------|
| `buy` | Open buy position |
| `sell` | Open sell position |
| `close` | Close position by ticket |

**Request Body:**
```json
{
  "action": "buy",
  "symbol": "XAUUSDm",
  "volume": 0.01,
  "ticket": 0
}
```

**Response:**
```json
{
  "success": true,
  "ticket": 1573222195,
  "retcode": 10009,
  "message": "ok"
}
```

**Common Return Codes:**
| Code | Meaning |
|------|---------|
| 10009 | `TRADE_RETCODE_DONE` - Success |
| 10006 | `TRADE_RETCODE_REJECT` - Rejected |
| 10014 | `TRADE_RETCODE_INVALID_VOLUME` - Bad lot size |
| 10015 | `TRADE_RETCODE_INVALID_PRICE` - Invalid price |

---

### Close Position

```
POST /farm/close/{account_id}/{ticket}
```

Close a specific position by ticket number.

**Example:**
```powershell
Invoke-RestMethod -Uri "http://localhost:8000/farm/close/Account_test_297102439/1573222195" -Method POST
```

---

### Get Positions

```
GET /farm/positions/{account_id}
```

**Response:**
```json
{
  "account_id": "Account_test_297102439",
  "positions": [
    {
      "ticket": 1573222195,
      "symbol": "XAUUSDm",
      "type": "buy",
      "volume": 0.01,
      "price_open": 2620.50,
      "price_current": 2621.00,
      "profit": 0.50,
      "swap": 0.0
    }
  ]
}
```

---

### Get Account Info

```
GET /farm/account/{account_id}
```

**Response:**
```json
{
  "login": 297102439,
  "balance": 50.01,
  "equity": 50.51,
  "margin": 2.62,
  "free_margin": 47.89,
  "leverage": 2000,
  "currency": "USD"
}
```

---

### Get Historical Rates

```
GET /farm/history/{account_id}?symbol=XAUUSDm&timeframe=H1&count=100
```

**Query Parameters:**
| Param | Default | Description |
|-------|---------|-------------|
| `symbol` | required | Trading symbol |
| `timeframe` | `M1` | M1, M5, M15, M30, H1, H4, D1, W1, MN |
| `count` | `100` | Number of bars (max 1000) |

---

### Stream Ticks (WebSocket)

```javascript
// Stream from specific account
const ws = new WebSocket('ws://localhost:8000/farm/stream/Account_test_297102439');

// Or stream from all accounts
const ws = new WebSocket('ws://localhost:8000/farm/stream');

ws.onmessage = (event) => {
  const tick = JSON.parse(event.data);
  console.log(`${tick.symbol}: ${tick.bid}/${tick.ask}`);
};
```

**Tick Message:**
```json
{
  "account_id": "Account_test_297102439",
  "symbol": "XAUUSDm",
  "time": 1733015445,
  "bid": 2620.50,
  "ask": 2620.85
}
```

---

### Provision New Account

```
POST /farm/provision
```

Creates a new MT5 instance from the master template.

**Request Body:**
```json
{
  "account_id": "my_account_123",
  "login": 12345678,
  "password": "your_password",
  "server": "Exness-MT5Trial9",
  "auto_launch": true
}
```

⚠️ **Broker Symbol Convention:** Use symbols with `m` suffix for Exness micro accounts (e.g., `XAUUSDm`, `EURUSDm`, `GBPUSDm`). Non-m symbols are reference prices only.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Python Farm                               │
│                                                                  │
│  ┌──────────────┐    ┌─────────────────┐    ┌────────────────┐  │
│  │   FastAPI    │    │  FarmController │    │  MT5Provisioner│  │
│  │   :8000      │───▶│   TCP :8888     │    │                │  │
│  │  REST + WS   │    │  Binary Proto   │    │  Clone/Launch  │  │
│  └──────────────┘    └────────┬────────┘    └────────────────┘  │
│                               │                                  │
└───────────────────────────────│──────────────────────────────────┘
                                │
            ┌───────────────────┼───────────────────┐
            │                   │                   │
            ▼                   ▼                   ▼
     ┌──────────┐        ┌──────────┐        ┌──────────┐
     │   MT5    │        │   MT5    │        │   MT5    │
     │ Account1 │        │ Account2 │        │ Account3 │
     │ ┌──────┐ │        │ ┌──────┐ │        │ ┌──────┐ │
     │ │Bridge│─┼────────┼─│Bridge│─┼────────┼─│Bridge│ │
     │ │  EA  │ │        │ │  EA  │ │        │ │  EA  │ │
     │ └──────┘ │        │ └──────┘ │        │ └──────┘ │
     └──────────┘        └──────────┘        └──────────┘
```

---

## Setup Guide

### Prerequisites

1. **Windows 10/11** (MT5 is Windows-only)
2. **Python 3.11+** with virtualenv
3. **MT5 Terminal** (build 2390+ for native sockets)

### Step 1: Create Master Installation

```powershell
# Install MT5 to master location
C:\MT5_MASTER\terminal64.exe /portable
```

In MT5:
1. Login to any demo account
2. **Tools → Options → Expert Advisors:**
   - ✅ Allow algorithmic trading
   - Add `127.0.0.1` to allowed URLs
3. Press **F4** to open MetaEditor
4. Open `farm\bridge\mql5\MT5Bridge.mq5`
5. Press **F7** to compile
6. Copy `MT5Bridge.ex5` to `C:\MT5_MASTER\MQL5\Experts\`

### Step 2: Configure Environment

Create `.env` in project root:

```env
FARM_CONTROLLER_HOST=127.0.0.1
FARM_CONTROLLER_PORT=8888
FARM_MASTER_PATH=C:/MT5_MASTER
FARM_FARM_PATH=C:/MT5_FARM
FARM_API_HOST=0.0.0.0
FARM_API_PORT=8000
FARM_LOG_LEVEL=INFO
```

### Step 3: Manual Instance Setup (First Time)

For your first account, set up manually:

1. Clone master to farm folder:
   ```powershell
   Copy-Item -Recurse C:\MT5_MASTER C:\MT5_FARM\Account_test_297102439
   ```

2. Create `pipe_id.txt` in `MQL5\Files\`:
   ```
   Account_test_297102439,8888
   ```

3. Launch MT5:
   ```powershell
   C:\MT5_FARM\Account_test_297102439\terminal64.exe /portable
   ```

4. Login to your broker account

5. Open a chart with **tradeable symbol** (e.g., `XAUUSDm` for Exness)

6. Drag `MT5Bridge` EA from Navigator to the chart

7. Verify in Experts tab:
   ```
   MT5Bridge v2.1 initialized
   Connected to controller at 127.0.0.1:8888
   ```

---

## Troubleshooting

### EA Shows "Symbol synchronization timeout"

**Cause:** Chart symbol has no data or isn't tradeable.

**Fix:** Use broker's tradeable symbols:
- Exness: Add `m` suffix → `XAUUSDm`, `EURUSDm`, `GBPUSDm`
- Check Market Watch → hover over symbol → should NOT say "Trade: Disabled"

### EA Not Connecting to Controller

1. Verify farm server is running:
   ```powershell
   curl http://localhost:8000/health
   ```

2. Check `pipe_id.txt` exists and has correct format:
   ```
   Account_test_297102439,8888
   ```

3. Verify MT5 Options → Expert Advisors → `127.0.0.1` is in allowed URLs

### Trade Rejected (retcode 10006)

- Check if trading is enabled (Algo Trading button in MT5 toolbar)
- Verify account has sufficient margin
- Confirm symbol is tradeable (not just reference price)

### Charts Show "Waiting for Update"

**Cause:** Broker hasn't synced market data yet.

**Fix:**
1. Right-click Market Watch → Show All
2. Find a symbol with live prices (green/red numbers)
3. Right-click symbol → Chart Window
4. Wait for data to load, then attach EA

---

## Files Reference

```
farm/
├── main.py               # FastAPI app + lifespan
├── bridge/
│   └── mql5/
│       └── MT5Bridge.mq5 # Expert Advisor (native sockets v2.1)
├── controller/
│   ├── protocol.py       # Binary protocol [Type:1][Len:4][JSON]
│   └── server.py         # Asyncio TCP server
├── provisioner/
│   ├── credentials.py    # Secure credential storage
│   └── factory.py        # MT5 instance factory
├── api/
│   └── router.py         # REST + WebSocket endpoints
└── config/
    └── settings.py       # Pydantic settings from .env
```

---

## Protocol Reference

### Binary Message Format

```
[MessageType: 1 byte][Length: 4 bytes LE][Body: JSON]
```

### Message Types

| Type | Value | Direction | Description |
|------|-------|-----------|-------------|
| LOGIN | 1 | EA→Python | Initial handshake with account info |
| TICK | 2 | EA→Python | Price update |
| COMMAND_RESP | 3 | EA→Python | Response to command |
| TRADE_CMD | 4 | Python→EA | Execute trade |
| HISTORY_CMD | 5 | Python→EA | Request historical data |
| PING | 6 | Python→EA | Heartbeat request |
| PONG | 7 | EA→Python | Heartbeat response |
| ACCOUNT_INFO | 8 | Both | Account information |
| POSITIONS | 9 | Both | Open positions |
| ERROR | 10 | EA→Python | Error message |

---

## Scaling

| Instances | RAM | CPU Cores | Notes |
|-----------|-----|-----------|-------|
| 1-5 | 8 GB | 4 | Default config |
| 5-10 | 16 GB | 8 | Increase desktop heap |
| 10-20 | 32 GB | 16 | Registry tweak required |
| 20-50 | 64 GB | 32 | Dedicated server |

For 10+ instances, increase desktop heap:
```
Registry: HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\SubSystems
Key: Windows → SharedSection=1024,20480,8192
```

---

## Security

- Credentials stored in Windows Credential Manager (install `keyring`)
- Controller TCP binds to localhost only
- Use API key for external access (set `FARM_API_KEY`)
- Each MT5 runs in portable mode (isolated config)
