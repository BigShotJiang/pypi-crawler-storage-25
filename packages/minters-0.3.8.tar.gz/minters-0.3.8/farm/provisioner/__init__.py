"""
Provisioner Module - MT5 Instance Factory

Handles:
- Cloning the "golden image" MT5 installation
- Credential injection via terminal.ini
- Process launching and PID tracking
- Zombie detection and recovery
- Broker discovery for cloud deployments
"""

from .factory import MT5Provisioner
from .credentials import CredentialManager
from .broker_discovery import BrokerDiscovery, get_broker_discovery

__all__ = ["MT5Provisioner", "CredentialManager", "BrokerDiscovery", "get_broker_discovery"]
