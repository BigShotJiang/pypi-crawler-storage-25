"""
Credential Manager - Secure storage for MT5 account credentials.

Uses Windows Credential Manager via the keyring library for secure
storage. Never stores passwords in plain text files.

Usage:
    manager = CredentialManager()
    manager.store_credentials("12345", "password123")
    password = manager.get_credentials("12345")
"""

import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Lazy keyring import - checked at runtime
_keyring = None
_keyring_checked = False


def _check_keyring():
    """Lazy check for keyring availability."""
    global _keyring, _keyring_checked
    if not _keyring_checked:
        try:
            import keyring
            _keyring = keyring
        except ImportError:
            _keyring = None
        _keyring_checked = True
    return _keyring is not None


class CredentialManager:
    """
    Manages secure storage of MT5 account credentials.
    
    Uses Windows Credential Manager when available, falls back to
    in-memory storage for development/testing.
    """
    
    SERVICE_NAME = "MT5_Farm"
    
    def __init__(self):
        """Initialize the credential manager."""
        self._fallback_storage: dict[str, str] = {}
        self._keyring_available = _check_keyring()
        
        if self._keyring_available:
            logger.info("Using Windows Credential Manager for secure storage")
        else:
            logger.warning("keyring not available - using in-memory storage (credentials will not persist)")
    
    def store_credentials(self, account_id: str, password: str) -> bool:
        """
        Store credentials for an account.
        
        Args:
            account_id: Unique account identifier
            password: MT5 account password
            
        Returns:
            True if stored successfully
        """
        try:
            if self._keyring_available:
                _keyring.set_password(self.SERVICE_NAME, account_id, password)
                logger.debug(f"Stored credentials for account {account_id}")
            else:
                self._fallback_storage[account_id] = password
            return True
        except Exception as e:
            logger.error(f"Failed to store credentials for {account_id}: {e}")
            return False
    
    def get_credentials(self, account_id: str) -> Optional[str]:
        """
        Retrieve credentials for an account.
        
        Args:
            account_id: Unique account identifier
            
        Returns:
            Password if found, None otherwise
        """
        if self._keyring_available:
            try:
                return _keyring.get_password(self.SERVICE_NAME, account_id)
            except Exception as e:
                logger.error(f"Failed to retrieve credentials for {account_id}: {e}")
                return None
        else:
            return self._fallback_storage.get(account_id)
    
    def delete_credentials(self, account_id: str) -> bool:
        """
        Delete credentials for an account.
        
        Args:
            account_id: Unique account identifier
            
        Returns:
            True if deleted successfully
        """
        if self._keyring_available:
            try:
                _keyring.delete_password(self.SERVICE_NAME, account_id)
                logger.debug(f"Deleted credentials for account {account_id}")
                return True
            except Exception as e:
                logger.error(f"Failed to delete credentials for {account_id}: {e}")
                return False
        else:
            self._fallback_storage.pop(account_id, None)
            logger.debug(f"Deleted credentials for account {account_id}")
            return True
    
    def has_credentials(self, account_id: str) -> bool:
        """Check if credentials exist for an account."""
        return self.get_credentials(account_id) is not None
