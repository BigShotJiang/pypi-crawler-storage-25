"""
Broker Discovery - Automatic broker server configuration fetching.

For cloud deployments where manual MT5 login isn't practical,
this module can:
1. Download broker server lists from MetaQuotes
2. Fetch server IPs/ports for specific brokers
3. Create minimal Bases folder structure for new brokers

MT5 broker discovery works via:
- trade.metatrader5.com/v1/servers (official MQL5 API)
- Broker-specific server files (.srv) 
"""

import asyncio
import logging
import os
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional
import json

try:
    import aiohttp
    AIOHTTP_AVAILABLE = True
except ImportError:
    AIOHTTP_AVAILABLE = False

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False

logger = logging.getLogger(__name__)

# MetaQuotes server discovery endpoints
MQL5_SERVERS_API = "https://trade.metatrader5.com/v1/servers"
MQL5_SERVER_DETAILS = "https://trade.metatrader5.com/v1/servers/{}"

# Common broker server patterns (for search hints)
KNOWN_BROKERS = {
    "exness": ["Exness-MT5Trial", "Exness-MT5Real", "Exness-MT5"],
    "icmarkets": ["ICMarketsSC-MT5", "ICMarketsEU-MT5", "ICMarkets-MT5"],
    "xm": ["XMGlobal-MT5", "XM.COM-MT5"],
    "fxpro": ["FxPro-MT5"],
    "pepperstone": ["Pepperstone-MT5", "Pepperstone-Demo"],
    "oanda": ["OANDA-MT5"],
    "fxcm": ["FXCM-MT5"],
    "admiral": ["AdmiralMarkets-MT5"],
}


@dataclass
class BrokerServer:
    """Represents a broker server configuration."""
    name: str
    company: str
    addresses: List[str]  # List of "ip:port" strings
    demo: bool = False
    trade: bool = True


class BrokerDiscovery:
    """
    Discovers and fetches broker server configurations.
    
    This allows cloud deployments to provision accounts for any broker
    without requiring manual MT5 login.
    """
    
    def __init__(self, cache_dir: Optional[Path] = None):
        """
        Initialize broker discovery.
        
        Args:
            cache_dir: Directory to cache server configs. Defaults to farm path.
        """
        self.cache_dir = cache_dir or Path(os.environ.get("MT5_FARM", "C:/MT5_FARM")) / ".broker_cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._server_cache: Dict[str, BrokerServer] = {}
        
    async def search_brokers(self, query: str) -> List[dict]:
        """
        Search for broker servers matching a query.
        
        Args:
            query: Search term (broker name, server name, etc.)
            
        Returns:
            List of matching broker servers
        """
        query_lower = query.lower()
        results = []
        
        # First check known brokers
        for broker_key, server_patterns in KNOWN_BROKERS.items():
            if query_lower in broker_key:
                for pattern in server_patterns:
                    results.append({
                        "server": pattern,
                        "broker": broker_key,
                        "source": "known_patterns"
                    })
        
        # Then try MQL5 API if available
        if AIOHTTP_AVAILABLE or HTTPX_AVAILABLE:
            try:
                api_results = await self._search_mql5_api(query)
                results.extend(api_results)
            except Exception as e:
                logger.warning(f"MQL5 API search failed: {e}")
        
        return results
    
    async def _search_mql5_api(self, query: str) -> List[dict]:
        """Search MQL5's server API."""
        results = []
        
        if HTTPX_AVAILABLE:
            async with httpx.AsyncClient(timeout=10.0) as client:
                try:
                    # MQL5 API endpoint for server search
                    response = await client.get(
                        MQL5_SERVERS_API,
                        params={"search": query, "limit": 20}
                    )
                    if response.status_code == 200:
                        data = response.json()
                        for server in data.get("servers", []):
                            results.append({
                                "server": server.get("name", ""),
                                "company": server.get("company", ""),
                                "demo": server.get("demo", False),
                                "source": "mql5_api"
                            })
                except Exception as e:
                    logger.debug(f"MQL5 API request failed: {e}")
        
        return results
    
    async def fetch_server_config(self, server_name: str) -> Optional[BrokerServer]:
        """
        Fetch full server configuration including IP addresses.
        
        Args:
            server_name: Exact server name (e.g., "Exness-MT5Trial9")
            
        Returns:
            BrokerServer with addresses, or None if not found
        """
        # Check cache first
        cache_file = self.cache_dir / f"{server_name}.json"
        if cache_file.exists():
            try:
                data = json.loads(cache_file.read_text())
                return BrokerServer(**data)
            except Exception:
                pass
        
        # Try to fetch from MQL5 API
        if HTTPX_AVAILABLE:
            try:
                async with httpx.AsyncClient(timeout=15.0) as client:
                    response = await client.get(
                        MQL5_SERVER_DETAILS.format(server_name)
                    )
                    if response.status_code == 200:
                        data = response.json()
                        server = BrokerServer(
                            name=data.get("name", server_name),
                            company=data.get("company", ""),
                            addresses=data.get("addresses", []),
                            demo=data.get("demo", False),
                            trade=data.get("trade", True)
                        )
                        
                        # Cache it
                        cache_file.write_text(json.dumps({
                            "name": server.name,
                            "company": server.company,
                            "addresses": server.addresses,
                            "demo": server.demo,
                            "trade": server.trade
                        }))
                        
                        return server
            except Exception as e:
                logger.warning(f"Failed to fetch server config for {server_name}: {e}")
        
        return None
    
    def create_servers_dat(self, servers: List[BrokerServer], output_path: Path):
        """
        Create a servers.dat file for MT5.
        
        MT5 uses servers.dat to cache broker server IP addresses.
        Format is binary with server entries.
        
        Args:
            servers: List of broker servers to include
            output_path: Where to write servers.dat
        """
        # servers.dat is a binary format - this is a simplified version
        # Full implementation would need reverse engineering of the format
        # For now, we'll create a minimal valid file
        
        with open(output_path, 'wb') as f:
            # Header (simplified)
            f.write(struct.pack('<I', len(servers)))  # Server count
            
            for server in servers:
                # Server name (null-terminated, padded to 64 bytes)
                name_bytes = server.name.encode('utf-8')[:63] + b'\x00'
                name_bytes = name_bytes.ljust(64, b'\x00')
                f.write(name_bytes)
                
                # Address count
                f.write(struct.pack('<I', len(server.addresses)))
                
                # Addresses (each as ip:port string, padded)
                for addr in server.addresses[:10]:  # Max 10 addresses
                    addr_bytes = addr.encode('utf-8')[:31] + b'\x00'
                    addr_bytes = addr_bytes.ljust(32, b'\x00')
                    f.write(addr_bytes)
        
        logger.info(f"Created servers.dat with {len(servers)} servers")
    
    def create_minimal_bases(self, server_name: str, instance_path: Path) -> bool:
        """
        Create minimal bases folder structure for a broker.
        
        This creates the folder structure MT5 expects, allowing it to
        connect even without pre-downloaded symbol data.
        
        Args:
            server_name: Broker server name
            instance_path: MT5 instance path
            
        Returns:
            True if created successfully
        """
        # NOTE: MT5 uses lowercase 'bases' not 'Bases'
        bases_dir = instance_path / "bases" / server_name
        
        try:
            # Create required subdirectories
            (bases_dir / "symbols").mkdir(parents=True, exist_ok=True)
            (bases_dir / "history").mkdir(parents=True, exist_ok=True)
            (bases_dir / "mail").mkdir(parents=True, exist_ok=True)
            (bases_dir / "news").mkdir(parents=True, exist_ok=True)
            
            # Create minimal symgroups.dat (symbol groups)
            symgroups = bases_dir / "symgroups.dat"
            if not symgroups.exists():
                symgroups.write_bytes(b'\x00' * 32)  # Minimal placeholder
            
            logger.info(f"Created minimal bases structure for {server_name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create bases for {server_name}: {e}")
            return False
    
    async def prepare_broker(self, server_name: str, instance_path: Path) -> bool:
        """
        Prepare a broker for first-time use.
        
        This fetches server config and creates minimal folder structure
        so MT5 can connect without prior manual login.
        
        Args:
            server_name: Broker server name (e.g., "Exness-MT5Trial9")
            instance_path: MT5 instance path
            
        Returns:
            True if broker is ready for use
        """
        logger.info(f"Preparing broker: {server_name}")
        
        # 1. Try to fetch server config
        server = await self.fetch_server_config(server_name)
        
        if server and server.addresses:
            # 2. Create servers.dat with this broker
            config_dir = instance_path / "config"
            config_dir.mkdir(exist_ok=True)
            self.create_servers_dat([server], config_dir / "servers.dat")
        else:
            logger.warning(f"Could not fetch server addresses for {server_name}")
        
        # 3. Create minimal Bases structure
        self.create_minimal_bases(server_name, instance_path)
        
        return True


# Singleton instance
_discovery: Optional[BrokerDiscovery] = None

def get_broker_discovery() -> BrokerDiscovery:
    """Get or create the broker discovery instance."""
    global _discovery
    if _discovery is None:
        _discovery = BrokerDiscovery()
    return _discovery
