"""
MT5 Provisioner - Factory for creating and managing MT5 instances.

This module handles:
1. Cloning a "golden seed" (working MT5 instance with market data)
2. Injecting credentials via terminal.ini
3. Writing pipe_id.txt for bridge identification
4. Launching MT5 processes
5. Monitoring process health
6. Zombie detection and recovery

IMPORTANT: The provisioner clones from a "golden seed" - a fully configured
MT5 instance that has:
- Connected to the broker at least once
- Downloaded symbol data (Bases folder)
- Has the MT5Bridge EA compiled

The seed can be:
1. Explicitly specified via seed_instance_path parameter
2. Auto-discovered from existing farm instances
3. The master_path as a last resort

Usage:
    provisioner = MT5Provisioner(
        master_path="C:/MT5_MASTER",
        farm_path="C:/MT5_FARM"
    )
    
    info = await provisioner.provision_account(
        account_id="12345",
        login=12345,
        password="secret",
        server="MetaQuotes-Demo"
    )
    
    # Later...
    await provisioner.terminate_account("12345")
"""

import asyncio
import logging
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, List

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

from .credentials import CredentialManager
from .broker_discovery import BrokerDiscovery, get_broker_discovery

logger = logging.getLogger(__name__)


@dataclass
class MT5Instance:
    """Represents a provisioned MT5 instance."""
    account_id: str
    login: int
    server: str
    path: Path
    pid: Optional[int] = None
    created_at: datetime = field(default_factory=datetime.now)
    last_health_check: Optional[datetime] = None
    is_running: bool = False


class MT5Provisioner:
    """
    Factory for creating and managing MT5 instances.
    
    Creates instances by cloning a "golden seed" (a working MT5 instance)
    and injecting account-specific credentials.
    """
    
    def __init__(
        self,
        master_path: str = "C:/MT5_MASTER",
        farm_path: str = "C:/MT5_FARM",
        controller_host: str = "127.0.0.1",
        controller_port: int = 8888,
        seed_instance: Optional[str] = None
    ):
        """
        Initialize the provisioner.
        
        Args:
            master_path: Path to the base MT5 installation (fallback)
            farm_path: Path where account instances will be created
            controller_host: IP of the Python controller
            controller_port: Port of the Python controller
            seed_instance: Path to a working MT5 instance to clone from.
                          If not provided, will auto-discover from farm_path
                          or fall back to master_path.
        """
        self.master_path = Path(master_path)
        self.farm_path = Path(farm_path)
        self.controller_host = controller_host
        self.controller_port = controller_port
        self._seed_instance = Path(seed_instance) if seed_instance else None
        
        # Instance registry
        self.instances: Dict[str, MT5Instance] = {}
        
        # Credential manager
        self.credentials = CredentialManager()
        
        # Ensure farm directory exists
        self.farm_path.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"MT5Provisioner initialized: master={master_path}, farm={farm_path}")
    
    def _is_instance_running(self, instance_dir: Path) -> bool:
        """Check if an MT5 instance is currently running."""
        if not PSUTIL_AVAILABLE:
            return False
        
        terminal_exe = instance_dir / "terminal64.exe"
        if not terminal_exe.exists():
            return False
        
        terminal_path_str = str(terminal_exe).lower()
        for proc in psutil.process_iter(['pid', 'name', 'exe']):
            try:
                if proc.info['exe'] and proc.info['exe'].lower() == terminal_path_str:
                    return True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return False
    
    def _find_best_seed(self, server: str, exclude_account_id: str = None) -> Path:
        """
        Find the best seed instance to clone from.
        
        Priority:
        1. Explicitly configured seed_instance (if not running)
        2. Non-running farm instance for the same broker server
        3. Non-running farm instance with market data
        4. Master path as fallback (never running)
        
        IMPORTANT: Prefers non-running instances to avoid locked files during copy.
        
        Args:
            server: Target broker server name
            exclude_account_id: Account ID to exclude from candidates (prevents self-cloning)
            
        Returns:
            Path to the best seed instance
        """
        # 1. Use explicit seed if configured AND not running
        if self._seed_instance and self._seed_instance.exists():
            if not self._is_instance_running(self._seed_instance):
                logger.debug(f"Using configured seed (not running): {self._seed_instance}")
                return self._seed_instance
            else:
                logger.warning(f"Configured seed is running, looking for alternatives")
        
        # Build the exclude pattern (the target folder name)
        exclude_name = f"acc_{exclude_account_id}" if exclude_account_id else None
        
        # 2. Look for existing instance with same broker server (prefer non-running)
        candidates = []  # List of (score, is_running, path)
        
        if self.farm_path.exists():
            for instance_dir in self.farm_path.iterdir():
                if not instance_dir.is_dir():
                    continue
                
                # Skip the target account to prevent self-cloning
                if exclude_name and instance_dir.name == exclude_name:
                    logger.debug(f"Skipping self: {instance_dir.name}")
                    continue
                
                # Skip directories without terminal64.exe (e.g., .config_cache)
                # A valid seed must be a complete MT5 installation with binaries
                terminal_exe = instance_dir / "terminal64.exe"
                if not terminal_exe.exists():
                    logger.debug(f"Skipping {instance_dir.name} - no terminal64.exe")
                    continue
                
                # Check if this instance has the broker's data
                bases_dir = instance_dir / "Bases"
                if not bases_dir.exists():
                    continue
                
                # Check if running
                is_running = self._is_instance_running(instance_dir)
                
                # Look for server-specific folder in Bases
                score = 0
                for server_folder in bases_dir.iterdir():
                    if server_folder.is_dir():
                        # Check if symbols folder has data
                        symbols_dir = server_folder / "symbols"
                        if symbols_dir.exists():
                            symbol_files = list(symbols_dir.glob("*.dat"))
                            if symbol_files:
                                # Has symbol data
                                total_size = sum(f.stat().st_size for f in symbol_files)
                                score = total_size
                                
                                # Bonus if it's for the same server
                                if server.lower() in server_folder.name.lower():
                                    score *= 10
                
                if score > 0:
                    candidates.append((score, is_running, instance_dir))
        
        # Sort by: not running first, then by score descending
        candidates.sort(key=lambda x: (x[1], -x[0]))  # is_running=False comes first
        
        if candidates:
            best = candidates[0]
            status = "running" if best[1] else "not running"
            logger.info(f"Auto-discovered seed instance: {best[2].name} ({status}, score={best[0]})")
            return best[2]
        
        # 3. Fall back to master (never running, always safe to copy)
        logger.warning(f"No suitable seed found, using master: {self.master_path}")
        return self.master_path
    
    def validate_master(self) -> bool:
        """Validate that the master installation exists and is complete."""
        if not self.master_path.exists():
            logger.error(f"Master path does not exist: {self.master_path}")
            return False
        
        # Check for essential files
        terminal = self.master_path / "terminal64.exe"
        if not terminal.exists():
            logger.error(f"terminal64.exe not found in master")
            return False
        
        # Check for MQL5 folder
        mql5 = self.master_path / "MQL5"
        if not mql5.exists():
            logger.error(f"MQL5 folder not found in master")
            return False
        
        # Check for bridge EA
        bridge_ea = mql5 / "Experts" / "MT5Bridge.ex5"
        if not bridge_ea.exists():
            logger.warning(f"MT5Bridge.ex5 not found - ensure EA is compiled")
        
        # Note: MT5Socket.dll is NOT required - we use native MQL5 sockets (build 2390+)
        
        return True
    
    async def provision_account(
        self,
        account_id: str,
        login: int,
        password: str,
        server: str,
        auto_launch: bool = True,
        server_seed_path: Optional[str] = None
    ) -> MT5Instance:
        """
        Provision a new MT5 instance for an account.
        
        The provisioner clones from a "golden seed" - a working MT5 instance
        that already has market data, symbols, and broker configuration.
        This ensures new instances can connect immediately without waiting
        for data synchronization.
        
        Args:
            account_id: Unique identifier for this instance (will be prefixed with acc_)
            login: MT5 account login number
            password: MT5 account password
            server: MT5 broker server name (e.g., "Exness-MT5Trial9")
            auto_launch: Whether to start the instance immediately
            server_seed_path: Optional path to a specific seed instance.
                              If not provided, auto-discovers the best seed.
            
        Returns:
            MT5Instance with provisioning details
        """
        # Normalize account_id (remove acc_ prefix if already present)
        if account_id.startswith("acc_"):
            account_id = account_id[4:]
        
        logger.info(f"Provisioning account {account_id} (login={login}, server={server})")
        
        # Check if already provisioned
        if account_id in self.instances:
            logger.warning(f"Account {account_id} already provisioned, terminating first")
            await self.terminate_account(account_id)
        
        # Find the best seed instance to clone from (exclude self to prevent self-cloning)
        seed_path = Path(server_seed_path) if server_seed_path else self._find_best_seed(server, exclude_account_id=account_id)
        
        # Create instance directory with 8-char uuid
        import uuid
        dir_uuid = uuid.uuid4().hex[:8]
        instance_path = self.farm_path / f"acct_{dir_uuid}"
        
        # Clone from seed (includes Bases with market data)
        await asyncio.to_thread(self._clone_seed, seed_path, instance_path)
        
        # 0. CRITICAL: Ensure broker server config exists (bases folder, servers.dat)
        await asyncio.to_thread(self._inject_server_config, instance_path, server)
        
        # Store credentials securely
        self.credentials.store_credentials(account_id, password)
        
        # CRITICAL: Copy ENTIRE config folder from seed to preserve ALL settings
        config_src = seed_path / "config"
        config_dst = instance_path / "config"
        if config_src.exists():
            try:
                import shutil
                # Remove existing config if present
                if config_dst.exists():
                    shutil.rmtree(config_dst)
                # Copy entire config folder
                shutil.copytree(config_src, config_dst)
                logger.info(f"Copied entire config folder from seed")
            except Exception as e:
                logger.warning(f"Failed to copy config folder: {e}")
        
        # CRITICAL: Copy Profiles folder to get the correct charts with EA
        profiles_src = seed_path / "Profiles"
        profiles_dst = instance_path / "Profiles"
        if profiles_src.exists():
            try:
                import shutil
                if profiles_dst.exists():
                    shutil.rmtree(profiles_dst)
                shutil.copytree(profiles_src, profiles_dst)
                logger.info(f"Copied Profiles folder from seed")
            except Exception as e:
                logger.warning(f"Failed to copy Profiles from seed: {e}")
        
        # NOW update ONLY Login/Server/Password in common.ini (inline, no function call)
        import re
        common_ini = config_dst / "common.ini"
        if common_ini.exists():
            try:
                content = common_ini.read_text(encoding='utf-16')
                
                # Update or ADD Login
                if re.search(r'^Login=', content, re.MULTILINE):
                    content = re.sub(r'^Login=.*$', f'Login={login}', content, flags=re.MULTILINE)
                else:
                    # Add Login to [Common] section
                    if '[Common]' in content:
                        content = content.replace('[Common]', f'[Common]\r\nLogin={login}')
                    else:
                        content = f'[Common]\r\nLogin={login}\r\n' + content
                
                # Update or ADD Server
                if re.search(r'^Server=', content, re.MULTILINE):
                    content = re.sub(r'^Server=.*$', f'Server={server}', content, flags=re.MULTILINE)
                else:
                    # Add Server after Login
                    content = re.sub(r'(^Login=\d+)', f'\\1\r\nServer={server}', content, flags=re.MULTILINE)
                
                # Update or ADD Password
                if re.search(r'^Password=', content, re.MULTILINE):
                    content = re.sub(r'^Password=.*$', f'Password={password}', content, flags=re.MULTILINE)
                else:
                    # Add Password after Server
                    content = re.sub(r'(^Server=.+)', f'\\1\r\nPassword={password}', content, flags=re.MULTILINE)
                
                common_ini.write_text(content, encoding='utf-16')
                logger.info(f"Updated credentials in common.ini (Login={login}, Server={server})")
            except Exception as e:
                logger.warning(f"Failed to update common.ini: {e}")
        else:
            # Create common.ini from scratch if it doesn't exist
            try:
                config_dst.mkdir(parents=True, exist_ok=True)
                common_content = f"""[Common]
Login={login}
Server={server}
Password={password}
KeepPrivate=1
NewsEnable=0
"""
                common_ini.write_text(common_content, encoding='utf-16')
                logger.info(f"Created common.ini with credentials (Login={login}, Server={server})")
            except Exception as e:
                logger.warning(f"Failed to create common.ini: {e}")
        
        # Write pipe_id.txt for EA to find controller
        pipe_file = instance_path / "MQL5" / "Files" / "pipe_id.txt"
        pipe_file.parent.mkdir(parents=True, exist_ok=True)
        pipe_file.write_text(f"{account_id},{self.controller_port}")
        
        # CRITICAL: Ensure portable.dat exists for portable mode
        portable_file = instance_path / "portable.dat"
        if not portable_file.exists():
            portable_file.touch()
            logger.info(f"Created portable.dat for portable mode")
        
        # CRITICAL: Create Default profile with BTCUSDm chart and EA
        # This ensures the EA auto-loads on startup
        self._create_default_profile(instance_path, account_id, server)
        
        # CRITICAL: Create startup.ini for auto-login
        # This enables MT5 to login automatically via /config parameter
        self._create_startup_ini(instance_path, login, password, server)
        
        # Create instance record
        instance = MT5Instance(
            account_id=account_id,
            login=login,
            server=server,
            path=instance_path
        )
        self.instances[account_id] = instance
        
        # Launch if requested
        if auto_launch:
            await self.launch_account(account_id)
        
        logger.info(f"Account {account_id} provisioned at {instance_path} (seed: {seed_path.name})")
        return instance
    
    def _clone_seed(self, seed_path: Path, target_path: Path):
        """
        Clone a seed instance to create a new instance.
        
        This copies EVERYTHING from the seed, including:
        - Bases/ (market data, symbols, history)
        - config/ (server settings, accounts)
        - MQL5/ (EA, indicators, files)
        - Profiles/ (chart templates)
        
        Only History/ and Logs/ are excluded to save space.
        
        Uses robocopy with /R:1 /W:1 to handle locked files quickly.
        
        Args:
            seed_path: Path to the seed instance to clone from
            target_path: Path for the new instance
        """
        if target_path.exists():
            logger.warning(f"Removing existing instance at {target_path}")
            shutil.rmtree(target_path, ignore_errors=True)
        
        logger.info(f"Cloning seed {seed_path.name} to {target_path.name}")
        
        # Use robocopy on Windows for better performance
        if os.name == 'nt':
            try:
                result = subprocess.run(
                    [
                        "robocopy",
                        str(seed_path),
                        str(target_path),
                        "/E",  # Copy subdirectories including empty ones
                        "/MT:8",  # Multi-threaded
                        "/R:1",  # Retry only 1 time on failed copies (locked files)
                        "/W:1",  # Wait only 1 second between retries
                        "/NFL", "/NDL", "/NJH", "/NJS",  # Reduce output
                        "/XD", "Logs",  # Exclude Logs
                        "/XF", "*.log"  # Exclude log files that might be locked
                    ],
                    capture_output=True,
                    timeout=120  # 2 minute timeout max
                )
                # Robocopy returns 0-7 for success (some skipped files is OK)
                if result.returncode > 7:
                    logger.warning(f"Robocopy had issues (code {result.returncode}), some files may be skipped")
                    # Don't raise exception - partial copy is usually OK for MT5
            except subprocess.TimeoutExpired:
                logger.error(f"Robocopy timed out - seed may have too many locked files")
                raise Exception("Clone timeout - try using a non-running seed instance")
            except FileNotFoundError:
                # Fall back to shutil
                shutil.copytree(
                    seed_path,
                    target_path,
                    ignore=shutil.ignore_patterns('Logs', '*.log'),
                    dirs_exist_ok=True
                )
        else:
            shutil.copytree(
                seed_path,
                target_path,
                ignore=shutil.ignore_patterns('Logs', '*.log'),
                dirs_exist_ok=True
            )
        
        logger.debug(f"Clone complete: {target_path}")
        
        # Explicitly copy critical config files that robocopy might skip if locked
        # These contain broker server IPs and global settings
        critical_files = ["servers.dat", "common.ini", "terminal.ini"]
        config_src = seed_path / "config"
        config_dst = target_path / "config"
        config_dst.mkdir(exist_ok=True)
        
        for filename in critical_files:
            src_file = config_src / filename
            dst_file = config_dst / filename
            if src_file.exists():
                try:
                    shutil.copy2(src_file, dst_file)
                    logger.debug(f"Copied critical config: {filename}")
                except Exception as e:
                    logger.warning(f"Failed to copy {filename}: {e}")
    
    def _inject_credentials(
        self,
        instance_path: Path,
        account_id: str,
        login: int,
        password: str,
        server: str
    ):
        """
        Inject account-specific credentials into a cloned instance.
        
        Based on official MT5 documentation:
        https://www.metatrader5.com/en/terminal/help/start_advanced/start
        
        Key insight: When using /config:<path>, MT5 reads [Common] section for credentials.
        The [StartUp] section is for auto-starting EAs/scripts on a chart.
        
        This updates:
        1. Broker Bases/<server> folder - CRITICAL for broker connection
        2. config/startup.ini - Custom config with [Common] section for login
        3. common.ini - Updated Login/Server to match
        4. Delete accounts.dat - Forces MT5 to use our credentials
        5. pipe_id.txt - Account ID for EA identification
        
        Args:
            instance_path: Path to the instance directory
            account_id: Unique account identifier
            login: MT5 login number
            password: MT5 password
            server: MT5 broker server
        """
        import re
        
        config_dir = instance_path / "config"
        config_dir.mkdir(exist_ok=True)
        
        # 0. CRITICAL: Copy broker server configuration (Bases folder, servers.dat, etc.)
        #    Without this, MT5 cannot connect to the broker!
        self._inject_server_config(instance_path, server)
        
        # 1. Create a CUSTOM config file (startup.ini) with [Common] section
        #    This is passed via /config:path and contains login credentials
        #    Per MT5 docs: "The configuration file parameters are divided into several blocks"
        #    [Common] section includes: Login, Server, Password, KeepPrivate
        #    [Experts] section matches the seed account settings for trading
        #    KeepPrivate=1 enables "Keep personal settings and data at startup"
        startup_ini = config_dir / "startup.ini"
        startup_content = f"""[Common]
Login={login}
Server={server}
Password={password}
KeepPrivate=1

[Experts]
AllowLiveTrading=1
AllowDllImport=1
Enabled=1
Account=1
Profile=0
"""
        startup_ini.write_text(startup_content)
        logger.info(f"Created startup.ini for {account_id} with [Common] credentials")
        
        # 2. DO NOT modify terminal.ini - it's already copied from seed with correct EA settings
        #    Modifying it here would destroy the WebRequest and other EA settings
        
        # 3. Update ONLY Login/Server/Password in common.ini, preserve everything else
        #    MT5 reads this file for the "last logged-in account"
        #    NOTE: MT5 uses UTF-16 LE encoding with BOM for common.ini
        common_ini = config_dir / "common.ini"
        if common_ini.exists():
            try:
                # MT5 uses UTF-16 LE with BOM for common.ini
                content = common_ini.read_text(encoding='utf-16')
            except UnicodeDecodeError:
                # Fall back to UTF-8
                content = common_ini.read_text(encoding='utf-8')
            
            # Update or ADD Login= line in [Common] section
            if re.search(r'^Login=', content, re.MULTILINE):
                content = re.sub(r'^Login=.*$', f'Login={login}', content, flags=re.MULTILINE)
            else:
                # Add Login after [Common] section header
                if '[Common]' in content:
                    content = content.replace('[Common]', f'[Common]\r\nLogin={login}')
                else:
                    content = f'[Common]\r\nLogin={login}\r\n' + content
            
            # Update or add Server= line
            if re.search(r'^Server=', content, re.MULTILINE):
                content = re.sub(r'^Server=.*$', f'Server={server}', content, flags=re.MULTILINE)
            else:
                # Add Server after Login
                content = re.sub(r'^(Login=\d+)', f'\\1\r\nServer={server}', content, flags=re.MULTILINE)
            
            # Add Password if not present (MT5 may need it for auto-connect)
            if not re.search(r'^Password=', content, re.MULTILINE):
                content = re.sub(r'^(Server=.*)', f'\\1\r\nPassword={password}', content, flags=re.MULTILINE)
            else:
                content = re.sub(r'^Password=.*$', f'Password={password}', content, flags=re.MULTILINE)
            
            # Write back with same encoding (UTF-16 with BOM)
            common_ini.write_text(content, encoding='utf-16')
            logger.debug(f"Updated common.ini with Login={login}, Server={server}, Password=***")
        else:
            # Create common.ini if it doesn't exist
            common_content = f"""[Common]
Login={login}
Server={server}
Password={password}
KeepPrivate=1
NewsEnable=0
"""
            common_ini.write_text(common_content)
            logger.debug(f"Created common.ini for {account_id}")
        
        # 3b. DO NOT call _ensure_webrequest_enabled - it modifies common.ini and destroys settings
        #     The seed's common.ini already has WebRequest enabled
        
        # NOTE: We intentionally DO NOT delete accounts.dat or accounts64.dat
        # These files contain authentication state from the golden template
        # that is required for MT5 to connect to the broker. Deleting them
        # causes "Invalid account" errors on fresh provisions.
        
        # 5. Write pipe_id.txt for EA identification
        files_dir = instance_path / "MQL5" / "Files"
        files_dir.mkdir(parents=True, exist_ok=True)
        
        pipe_id_path = files_dir / "pipe_id.txt"
        pipe_id_path.write_text(f"{account_id},{self.controller_port}")
        logger.debug(f"Written pipe_id.txt for {account_id}")
        
        # 6. Setup default.tpl template with EA for auto-loading on charts
        #    MT5 uses default.tpl when opening new charts
        #    Pass server name to determine broker-specific symbol naming
        self._setup_chart_template(instance_path, account_id, server)
    
    def _setup_chart_template(self, instance_path: Path, account_id: str, server: str = ""):
        """
        Setup chart template with MT5Bridge EA for auto-loading.
        
        MT5 uses the default.tpl template when creating new charts.
        This ensures the EA is automatically attached to charts.
        
        Also injects EA into the Default profile's chart01.chr for startup.
        
        Args:
            instance_path: Path to the instance directory
            account_id: Account identifier for logging
            server: Broker server name for dynamic symbol selection
        """
        templates_dir = instance_path / "Profiles" / "Templates"
        templates_dir.mkdir(parents=True, exist_ok=True)
        
        # Determine the primary symbol based on broker
        # Exness uses 'm' suffix (EURUSDm), others use standard (EURUSD)
        if server and "exness" in server.lower():
            primary_symbol = "EURUSDm"
            symbol_desc = "Euro vs US Dollar"
        else:
            primary_symbol = "EURUSD"
            symbol_desc = "Euro vs US Dollar"
        
        # Check if we have a default.tpl with EA in MQL5/Profiles/Templates
        mql5_default = instance_path / "MQL5" / "Profiles" / "Templates" / "default.tpl"
        profiles_default = templates_dir / "default.tpl"
        
        template_setup = False
        
        # Copy from MQL5 templates if available
        if mql5_default.exists():
            shutil.copy2(mql5_default, profiles_default)
            logger.info(f"Copied default.tpl with EA for {account_id}")
            template_setup = True
        # Copy MT5Bridge.tpl as default.tpl if available
        elif (templates_dir / "MT5Bridge.tpl").exists():
            shutil.copy2(templates_dir / "MT5Bridge.tpl", profiles_default)
            logger.info(f"Copied MT5Bridge.tpl as default.tpl for {account_id}")
            template_setup = True
        
        # Create a minimal default.tpl with EA using broker-appropriate symbol
        default_tpl_content = f"""<chart>
symbol={primary_symbol}
description={symbol_desc}
period_type=1
period_size=1
digits=5
scale=4
mode=1
fore=0
grid=1
volume=0
scroll=1
shift=0
ohlc=0
one_click=1
bidline=1
askline=0
lastline=0
days=0
descriptions=0
tradelines=1
tradehistory=1
window_left=0
window_top=0
window_right=800
window_bottom=600
window_type=1
background_color=0
foreground_color=16777215
barup_color=65280
bardown_color=65280
bullcandle_color=0
bearcandle_color=16777215
chartline_color=65280
volumes_color=3329330
grid_color=10061943
bidline_color=10061943
askline_color=255
lastline_color=49152
stops_color=255
windows_total=1

<expert>
name=MT5Bridge
path=Experts\\MT5Bridge.ex5
expertmode=5
<inputs>
CONTROLLER_HOST=127.0.0.1
DEFAULT_PORT=8888
POLL_INTERVAL_MS=50
RECONNECT_DELAY_MS=5000
ENABLE_TICK_STREAM=true
ENABLE_DEBUG=false
</inputs>
</expert>

<window>
height=100.000000
objects=0

<indicator>
name=Main
path=
apply=1
show_data=1
</indicator>
</window>
</chart>
"""
        if not template_setup:
            profiles_default.write_text(default_tpl_content)
            logger.info(f"Created default.tpl with EA for {account_id}")
        
        # Also inject EA into chart01.chr as backup (if it gets recreated before deletion)
        self._inject_ea_into_chart(instance_path, account_id)
    
    def _inject_ea_into_chart(self, instance_path: Path, account_id: str):
        """
        Inject MT5Bridge EA into the first chart of the Default profile.
        
        MT5 loads saved chart profiles on startup. To ensure the EA is loaded,
        we modify chart01.chr in the Default profile to include the EA.
        
        NOTE: MT5 chart files (.chr) use UTF-16 LE encoding with BOM.
        
        Args:
            instance_path: Path to the instance directory
            account_id: Account identifier for logging
        """
        chart_file = instance_path / "Profiles" / "Charts" / "Default" / "chart01.chr"
        
        if not chart_file.exists():
            logger.warning(f"chart01.chr not found for {account_id}")
            return
        
        # MT5 chart files use UTF-16 LE encoding
        try:
            content = chart_file.read_text(encoding='utf-16-le')
        except UnicodeDecodeError:
            try:
                content = chart_file.read_text(encoding='utf-16')
            except UnicodeDecodeError:
                content = chart_file.read_text(errors='ignore')
        
        # Check if EA is already present
        if "<expert>" in content:
            logger.debug(f"EA already present in chart01.chr for {account_id}")
            return
        
        # EA configuration to inject
        ea_block = """
<expert>
name=MT5Bridge
path=Experts\\MT5Bridge.ex5
expertmode=5
<inputs>
CONTROLLER_HOST=127.0.0.1
DEFAULT_PORT=8888
POLL_INTERVAL_MS=50
RECONNECT_DELAY_MS=5000
ENABLE_TICK_STREAM=true
ENABLE_DEBUG=false
</inputs>
</expert>
"""
        
        # Insert EA block before the first <window> tag
        if "<window>" in content:
            content = content.replace("<window>", ea_block + "\n<window>", 1)
            # Write back with UTF-16 LE encoding (same as original)
            chart_file.write_text(content, encoding='utf-16-le')
            logger.info(f"Injected EA into chart01.chr for {account_id}")
        else:
            logger.warning(f"Could not find <window> tag in chart01.chr for {account_id}")
    
    def _create_default_profile(self, instance_path: Path, account_id: str, server: str):
        """
        Create a Default profile with a single BTCUSDm chart and MT5Bridge EA.
        
        This creates the profile from scratch to ensure:
        1. Only one chart (BTCUSDm)
        2. EA is attached and configured
        3. Profile loads on MT5 startup
        
        Args:
            instance_path: Path to the instance directory
            account_id: Account identifier for logging
            server: Broker server name for symbol selection
        """
        # Create profile directories
        default_profile = instance_path / "Profiles" / "Charts" / "Default"
        default_profile.mkdir(parents=True, exist_ok=True)
        
        # Determine symbol based on broker
        if server and "exness" in server.lower():
            symbol = "BTCUSDm"
            symbol_desc = "Bitcoin vs US Dollar"
        else:
            symbol = "BTCUSD"
            symbol_desc = "Bitcoin vs US Dollar"
        
        # Create chart01.chr with EA
        chart_content = f"""<chart>
id=133734156088934055
symbol={symbol}
description={symbol_desc}
period_type=1
period_size=1
digits=2
tick_size=0.010000
position_time=0
scale_fix=0
scale_fixed_min=0.000000
scale_fixed_max=0.000000
scale_fix11=0
scale_bar=0
scale_bar_val=1.000000
scale=4
mode=1
fore=0
grid=1
volume=0
scroll=1
shift=1
shift_size=20.000000
fixed_pos=0.000000
ticker=1
ohlc=0
one_click=0
one_click_btn=1
bidline=1
askline=0
lastline=0
days=0
descriptions=0
tradelines=1
tradehistory=1
window_left=0
window_top=0
window_right=800
window_bottom=600
window_type=3
floating=0
floating_left=0
floating_top=0
floating_right=0
floating_bottom=0
floating_type=1
floating_toolbar=1
floating_tbstate=
background_color=0
foreground_color=16777215
barup_color=65280
bardown_color=255
bullcandle_color=0
bearcandle_color=16777215
chartline_color=65280
volumes_color=3329330
grid_color=10061943
bidline_color=10061943
askline_color=255
lastline_color=49152
stops_color=255
windows_total=1

<expert>
name=MT5Bridge
path=Experts\\MT5Bridge.ex5
expertmode=5
<inputs>
CONTROLLER_HOST=127.0.0.1
DEFAULT_PORT={self.controller_port}
POLL_INTERVAL_MS=50
RECONNECT_DELAY_MS=5000
ENABLE_TICK_STREAM=true
ENABLE_DEBUG=false
</inputs>
</expert>

<window>
height=100.000000
objects=0

<indicator>
name=Main
path=
apply=1
show_data=1
<graph>
name=
draw=0
style=0
width=1
arrow=0
color=
</graph>
</indicator>
</window>
</chart>
"""
        
        chart_file = default_profile / "chart01.chr"
        chart_file.write_text(chart_content, encoding='utf-16-le')
        logger.info(f"Created Default profile with {symbol} chart and EA for {account_id}")
        
        # Create order.wnd (order window settings)
        order_wnd = default_profile / "order.wnd"
        order_wnd_content = """<window>
window_type=0
</window>
"""
        order_wnd.write_text(order_wnd_content, encoding='utf-16-le')
    
    def _create_startup_ini(self, instance_path: Path, login: int, password: str, server: str):
        """
        Create startup.ini for MT5 auto-login.
        
        This file is used with the /config parameter to enable automatic login.
        Format: terminal64.exe /config:path/to/startup.ini /portable
        
        The file contains:
        - [Common] section with Login, Server, Password (plaintext)
        - [Experts] section with EA permissions copied from MASTER
        
        Args:
            instance_path: Path to the instance directory
            login: MT5 account login number
            password: MT5 account password (stored in plaintext)
            server: MT5 broker server name
        """
        config_dir = instance_path / "config"
        config_dir.mkdir(parents=True, exist_ok=True)
        
        startup_ini = config_dir / "startup.ini"
        
        # Get WebRequestUrl from MASTER's common.ini if available
        webrequest_url = ""
        master_common = self.master_path / "Config" / "common.ini"
        if master_common.exists():
            try:
                content = master_common.read_text(encoding='utf-16-le', errors='ignore')
                import re
                match = re.search(r'WebRequestUrl=(.+)', content)
                if match:
                    webrequest_url = match.group(1).strip()
            except Exception as e:
                logger.debug(f"Could not read WebRequestUrl from MASTER: {e}")
        
        # Create startup.ini with auto-login credentials
        startup_content = f"""[Common]
Login={login}
Server={server}
Password={password}
KeepPrivate=1
NewsEnable=0

[Experts]
AllowDllImport=1
Enabled=1
Account=1
Profile=0
Chart=0
Api=0
WebRequest=1"""
        
        # Add WebRequestUrl if we found it in MASTER
        if webrequest_url:
            startup_content += f"\nWebRequestUrl={webrequest_url}"
        
        startup_content += "\r\n"
        
        # Write with UTF-16 encoding (MT5 standard with BOM)
        startup_ini.write_text(startup_content, encoding='utf-16')
        logger.info(f"Created startup.ini for auto-login (Login={login}, Server={server})")
        
        return startup_ini
    
    def _ensure_webrequest_enabled(self, config_dir: Path):
        """
        Ensure WebRequest is enabled in common.ini for socket connections.
        
        MT5 requires 'Allow WebRequest for listed URLs' to be enabled for
        SocketConnect() to work. This setting is stored in common.ini under
        [Experts] section with:
        - WebRequest=1 (enable the setting)
        - WebRequestUrl=<encrypted> (list of allowed URLs)
        
        Since we can't easily generate the encrypted URL format, we try to:
        1. Ensure WebRequest=1 is set
        2. Copy WebRequestUrl from a working source if available
        
        For new deployments, the user may still need to manually add 127.0.0.1
        to the allowed URLs list in MT5 settings the first time.
        
        Args:
            config_dir: Path to the instance's config directory
        """
        common_ini = config_dir / "common.ini"
        
        if not common_ini.exists():
            logger.warning("common.ini not found, cannot ensure WebRequest settings")
            return
        
        try:
            # MT5 uses UTF-16 LE encoding for common.ini
            try:
                content = common_ini.read_text(encoding='utf-16-le')
            except UnicodeDecodeError:
                content = common_ini.read_text(encoding='utf-8')
            
            modified = False
            
            # Check if [Experts] section exists
            if "[Experts]" not in content:
                # Add [Experts] section at the end
                content += "\n[Experts]\nAllowDllImport=1\nEnabled=1\nWebRequest=1\n"
                modified = True
                logger.info("Added [Experts] section with WebRequest=1")
            else:
                # Check if WebRequest is already enabled
                if not re.search(r'^WebRequest=1', content, re.MULTILINE):
                    # Check if WebRequest line exists
                    if re.search(r'^WebRequest=', content, re.MULTILINE):
                        content = re.sub(r'^WebRequest=\d+', 'WebRequest=1', content, flags=re.MULTILINE)
                    else:
                        # Add WebRequest=1 after [Experts]
                        content = content.replace("[Experts]", "[Experts]\nWebRequest=1")
                    modified = True
                    logger.info("Enabled WebRequest=1 in [Experts] section")
            
            # Try to find and copy WebRequestUrl from a known good source
            # This contains the encrypted list of allowed URLs including 127.0.0.1
            if "WebRequestUrl=" not in content:
                golden_url = self._find_golden_webrequest_url()
                if golden_url:
                    if "[Experts]" in content:
                        content = content.replace("[Experts]", f"[Experts]\n{golden_url}")
                        modified = True
                        logger.info("Copied WebRequestUrl from golden source")
            
            if modified:
                # Write back with UTF-16 LE encoding
                common_ini.write_text(content, encoding='utf-16-le')
                logger.debug("Updated common.ini with WebRequest settings")
                
        except Exception as e:
            logger.error(f"Failed to update WebRequest settings: {e}")
    
    def _find_golden_webrequest_url(self) -> Optional[str]:
        """
        Find a WebRequestUrl value from a properly configured MT5 instance.
        
        This searches for an existing MT5 terminal that has 127.0.0.1 configured
        in the allowed URLs list. The URL list is encrypted, so we can't generate
        it programmatically - we need to copy it from a working source.
        
        Returns:
            WebRequestUrl line (e.g., "WebRequestUrl=<encrypted>") or None
        """
        import re
        
        # Search paths for configured MT5 instances
        appdata = Path(os.environ.get("APPDATA", ""))
        mq_terminals = appdata / "MetaQuotes" / "Terminal"
        
        search_paths = []
        
        # First check our config cache (preserved from previous cleanup)
        cache_dir = self.farm_path / ".config_cache"
        if cache_dir.exists():
            search_paths.append(cache_dir)
        
        if mq_terminals.exists():
            for terminal_dir in mq_terminals.iterdir():
                if terminal_dir.is_dir() and len(terminal_dir.name) == 32:
                    search_paths.append(terminal_dir)
        
        # Also check farm instances
        if self.farm_path.exists():
            for farm_dir in self.farm_path.iterdir():
                if farm_dir.is_dir() and not farm_dir.name.startswith('.'):
                    search_paths.append(farm_dir)
        
        for path in search_paths:
            common_ini = path / "config" / "common.ini"
            if common_ini.exists():
                try:
                    try:
                        content = common_ini.read_text(encoding='utf-16-le')
                    except UnicodeDecodeError:
                        content = common_ini.read_text(encoding='utf-8')
                    
                    # Look for WebRequestUrl line
                    match = re.search(r'^(WebRequestUrl=.+)$', content, re.MULTILINE)
                    if match:
                        logger.debug(f"Found WebRequestUrl in {path}")
                        return match.group(1)
                        
                except Exception:
                    continue
        
        logger.warning("No golden WebRequestUrl found - user may need to manually add 127.0.0.1 to allowed URLs")
        return None
    
    async def _cache_golden_config(self, instance_path: Path):
        """
        Cache critical config files before cleanup to preserve them for future provisioning.
        
        This saves:
        - common.ini (contains WebRequestUrl and other settings)
        - servers.dat (broker server IP cache)
        - Bases folder structure (broker-specific data)
        
        Args:
            instance_path: Path to the instance being cleaned up
        """
        cache_dir = self.farm_path / ".config_cache"
        cache_dir.mkdir(exist_ok=True)
        
        try:
            # Cache common.ini (contains the encrypted WebRequestUrl)
            common_ini = instance_path / "config" / "common.ini"
            if common_ini.exists():
                cached_common = cache_dir / "common.ini"
                await asyncio.to_thread(shutil.copy2, common_ini, cached_common)
                logger.debug(f"Cached common.ini to {cached_common}")
            
            # Cache servers.dat (broker IP addresses)
            servers_dat = instance_path / "config" / "servers.dat"
            if servers_dat.exists():
                cached_servers = cache_dir / "servers.dat"
                await asyncio.to_thread(shutil.copy2, servers_dat, cached_servers)
                logger.debug(f"Cached servers.dat to {cached_servers}")
            
            # Cache Bases folder structure (critical for broker connection)
            bases_dir = instance_path / "Bases"
            if bases_dir.exists():
                cached_bases = cache_dir / "Bases"
                if cached_bases.exists():
                    await asyncio.to_thread(shutil.rmtree, cached_bases)
                await asyncio.to_thread(shutil.copytree, bases_dir, cached_bases)
                logger.info(f"Cached Bases folder to {cached_bases}")
                
        except Exception as e:
            logger.warning(f"Failed to cache golden config: {e}")
    
    # Keep the old method name as alias for backwards compatibility
    def _clone_master(self, target_path: Path):
        """Deprecated: Use _clone_seed instead. Clones from master_path."""
        self._clone_seed(self.master_path, target_path)
    
    def _find_server_config_source(self, server: str, exclude_path: Optional[Path] = None) -> Optional[Path]:
        """
        Find an existing MT5 terminal data folder that has the broker server configured.
        
        MT5 stores server configuration (IP addresses, ports) in:
        - common.ini (contains Server=<name> and other settings)
        - config/servers.dat (binary cache of server IPs and ports)
        - bases/<server>/ (broker-specific data: symbols, history, etc.)
        
        This method searches known locations for a terminal that has connected to
        the specified broker before. Priority is given to sources that have the
        bases/<server> folder, as this contains essential broker data.
        
        Args:
            server: Broker server name (e.g., "Exness-MT5Trial9")
            exclude_path: Path to exclude from search
            
        Returns:
            Path to the data folder containing server config, or None
        """
        import re
        
        # Common MT5 data locations to search
        appdata = Path(os.environ.get("APPDATA", ""))
        search_paths = []
        
        # 0. Config cache (preserved from previous cleanup - highest priority)
        cache_dir = self.farm_path / ".config_cache"
        if cache_dir.exists():
            search_paths.append(cache_dir)
        
        # 1. AppData/Roaming/MetaQuotes/Terminal (standard location - priority)
        mq_terminals = appdata / "MetaQuotes" / "Terminal"
        if mq_terminals.exists():
            for terminal_dir in mq_terminals.iterdir():
                if terminal_dir.is_dir() and len(terminal_dir.name) == 32:  # Hash folder
                    search_paths.append(terminal_dir)
        
        # 2. Farm path instances (in case we've used this server before)
        if self.farm_path.exists():
            for farm_dir in self.farm_path.iterdir():
                if farm_dir.is_dir() and not farm_dir.name.startswith('.'):
                    search_paths.append(farm_dir)
        
        # 3. Master path itself
        if self.master_path.exists():
            search_paths.append(self.master_path)
        
        # Search each location, prioritizing those with bases/<server> folder
        candidates_with_bases = []
        candidates_without_bases = []
        
        for path in search_paths:
            if exclude_path and path.resolve() == exclude_path.resolve():
                continue
                
            common_ini = path / "config" / "common.ini"
            if common_ini.exists():
                try:
                    # MT5 uses UTF-16 encoding for common.ini, try that first
                    try:
                        content = common_ini.read_text(encoding='utf-16')
                    except (UnicodeDecodeError, UnicodeError):
                        # Fall back to ignore errors for other encodings
                        content = common_ini.read_text(errors='ignore')
                    
                    # Look for Server=<server_name> line
                    if re.search(rf'^Server={re.escape(server)}\s*$', content, re.MULTILINE | re.IGNORECASE):
                        # Check that servers.dat exists (contains the actual IP info)
                        servers_dat = path / "config" / "servers.dat"
                        if servers_dat.exists():
                            # Check if this source has the bases/<server> folder (lowercase!)
                            bases_server = path / "bases" / server
                            if bases_server.exists() and bases_server.is_dir():
                                candidates_with_bases.append(path)
                                logger.debug(f"Found server config WITH bases/{server} at {path}")
                            else:
                                candidates_without_bases.append(path)
                                logger.debug(f"Found server config (no bases/{server}) at {path}")
                except Exception as e:
                    logger.debug(f"Error reading {common_ini}: {e}")
                    continue
        
        # Prefer sources with bases folder
        if candidates_with_bases:
            best = candidates_with_bases[0]
            logger.info(f"Found server config for '{server}' at {best} (with bases folder)")
            return best
        elif candidates_without_bases:
            best = candidates_without_bases[0]
            logger.warning(f"Found server config for '{server}' at {best} (WITHOUT bases folder - broker connection may fail)")
            return best
        
        logger.warning(f"No existing server config found for '{server}'. "
                      f"You may need to login manually once to establish server config.")
        return None
    
    def _inject_server_config(
        self,
        instance_path: Path,
        server: str,
        seed_path: Optional[Path] = None
    ):
        """
        Copy broker server configuration to the instance.
        
        MT5 needs to know the IP address and port of the broker's server.
        This information is cached in:
        - config/common.ini (contains Server=<name>)
        - config/servers.dat (binary file with IP/port data)
        
        If no existing config is found, attempts to fetch from MQL5 API.
        
        Args:
            instance_path: Target instance path
            server: Broker server name
            seed_path: Optional specific path to copy from
        """
        # Find source for server config
        source_path = seed_path
        if not source_path:
            source_path = self._find_server_config_source(server, exclude_path=instance_path)
        
        if not source_path:
            # No existing config - try broker discovery for cloud deployments
            logger.info(f"No local config for '{server}', attempting broker discovery...")
            try:
                discovery = get_broker_discovery()
                # Run async prepare_broker in sync context
                import asyncio
                try:
                    loop = asyncio.get_event_loop()
                    is_running = loop.is_running()
                except RuntimeError:
                    loop = None
                    is_running = False
                
                if is_running:
                    # If we're already in an async context, create a task
                    asyncio.create_task(discovery.prepare_broker(server, instance_path))
                    logger.info(f"Broker discovery initiated for '{server}' (async)")
                else:
                    if loop:
                        loop.run_until_complete(discovery.prepare_broker(server, instance_path))
                    else:
                        asyncio.run(discovery.prepare_broker(server, instance_path))
                    logger.info(f"Broker discovery completed for '{server}'")
            except Exception as e:
                logger.warning(f"Broker discovery failed for '{server}': {e}")
                logger.warning(f"MT5 may fail to connect. Consider manual broker setup.")
            return
        
        config_dir = instance_path / "config"
        config_dir.mkdir(exist_ok=True)
        
        # Skip copying if source is the same as destination (e.g., during recovery)
        if source_path.resolve() == instance_path.resolve():
            logger.debug(f"Source and instance are same path, skipping config copy")
            return
        
        # Copy common.ini
        src_common = source_path / "config" / "common.ini"
        if src_common.exists():
            dst_common = config_dir / "common.ini"
            shutil.copy2(src_common, dst_common)
            logger.debug(f"Copied common.ini from {source_path}")
        
        # Copy servers.dat
        src_servers = source_path / "config" / "servers.dat"
        if src_servers.exists():
            dst_servers = config_dir / "servers.dat"
            shutil.copy2(src_servers, dst_servers)
            logger.debug(f"Copied servers.dat from {source_path}")
        
        # Also copy origins.dat if exists (contains server metadata)
        src_origins = source_path / "config" / "origins.dat"
        if src_origins.exists():
            dst_origins = config_dir / "origins.dat"
            shutil.copy2(src_origins, dst_origins)
            logger.debug(f"Copied origins.dat from {source_path}")
        
        # Copy the broker-specific bases subfolder (contains symbols, history, etc.)
        # This is CRITICAL - without it, MT5 can't connect to the broker
        # NOTE: MT5 uses lowercase 'bases' not 'Bases'
        src_bases_server = source_path / "bases" / server
        if src_bases_server.exists():
            dst_bases = instance_path / "bases"
            dst_bases.mkdir(exist_ok=True)
            dst_bases_server = dst_bases / server
            
            if dst_bases_server.exists():
                # Remove existing to ensure clean copy
                shutil.rmtree(dst_bases_server)
            
            # Use robocopy for faster copying with locked file handling
            import subprocess
            result = subprocess.run(
                [
                    "robocopy",
                    str(src_bases_server),
                    str(dst_bases_server),
                    "/E",      # Include subdirectories
                    "/R:1",    # 1 retry on locked files
                    "/W:1",    # 1 second wait between retries
                    "/MT:8",   # Multi-threaded
                    "/NP",     # No progress
                    "/NFL",    # No file list
                    "/NDL",    # No directory list
                    "/NJH",    # No job header
                    "/NJS",    # No job summary
                ],
                capture_output=True,
                timeout=60
            )
            
            # robocopy returns 0-7 for success/partial success
            if result.returncode <= 7:
                logger.info(f"Copied broker bases folder for '{server}' from {source_path}")
            else:
                logger.warning(f"Failed to copy bases/{server}: robocopy returned {result.returncode}")
        else:
            # No existing bases folder for this server - create minimal structure
            # This allows MT5 to connect and download symbols/data on first login
            logger.warning(f"No bases/{server} folder found in source.")
            logger.info(f"Creating minimal bases/{server} structure for first-time login...")
            
            try:
                # Use broker discovery to create minimal bases structure
                discovery = get_broker_discovery()
                success = discovery.create_minimal_bases(server, instance_path)
                if success:
                    logger.info(f"✅ Created minimal bases/{server} folder - MT5 will download data on first login")
                else:
                    logger.warning(f"⚠️  Failed to create minimal bases/{server} - MT5 may fail to connect")
            except Exception as e:
                logger.error(f"Error creating minimal bases folder: {e}")
                logger.warning(f"MT5 may fail to connect to {server}")
        
        # CRITICAL: Verify that the target server's bases folder exists
        # Even if we copied from a source, it might have a DIFFERENT server
        # (e.g., source has Exness-MT5Trial9, but we need Exness-MT5Real30)
        dst_bases_server = instance_path / "bases" / server
        if not dst_bases_server.exists():
            logger.warning(f"Target bases/{server} folder doesn't exist after copy!")
            logger.info(f"Creating minimal bases/{server} structure for new server...")
            
            try:
                discovery = get_broker_discovery()
                success = discovery.create_minimal_bases(server, instance_path)
                if success:
                    logger.info(f"✅ Created minimal bases/{server} folder for new server")
                else:
                    logger.error(f"❌ Failed to create minimal bases/{server} - MT5 WILL FAIL to connect")
            except Exception as e:
                logger.error(f"Error creating minimal bases folder: {e}")
                logger.error(f"MT5 WILL FAIL to connect to {server}")



    def _inject_config(
        self,
        instance_path: Path,
        account_id: str,
        login: int,
        password: str,
        server: str,
        port: Optional[int] = None,
        server_seed_path: Optional[Path] = None
    ):
        """
        Inject account configuration into the instance.
        
        Args:
            instance_path: Path to the instance directory
            account_id: Unique account identifier
            login: MT5 login number
            password: MT5 password
            server: MT5 broker server
            port: Controller port for this instance (defaults to controller_port)
            server_seed_path: Optional path to copy broker server config from
                              (common.ini, servers.dat). If not provided, checks
                              known MT5 terminal locations.
        """
        # Use provided port or default
        instance_port = port if port is not None else self.controller_port
        
        # 1. Copy broker server configuration (common.ini + servers.dat)
        #    MT5 needs these files to know how to connect to the broker
        self._inject_server_config(instance_path, server, server_seed_path)
        
        # 2. Write terminal.ini with credentials
        config_dir = instance_path / "config"
        config_dir.mkdir(exist_ok=True)
        
        ini_path = config_dir / "terminal.ini"
        ini_content = f"""[StartUp]
Login={login}
Password={password}
Server={server}
Enable=true

[Experts]
AllowLiveTrading=true
AllowDllImports=true
Enabled=true
Account=0
Profile=0
"""
        ini_path.write_text(ini_content)
        logger.debug(f"Written terminal.ini for {account_id}")
        
        # 2. Write pipe_id.txt for bridge identification
        #    Format: account_id,port (e.g., "acc_12345,9001")
        #    The EA reads this to know which port to connect to
        files_dir = instance_path / "MQL5" / "Files"
        files_dir.mkdir(parents=True, exist_ok=True)
        
        pipe_id_path = files_dir / "pipe_id.txt"
        pipe_id_path.write_text(f"{account_id},{instance_port}")
        logger.debug(f"Written pipe_id.txt for {account_id}: port={instance_port}")
        
        # 3. Clean up any existing profile data
        profiles_dir = instance_path / "Profiles"
        if profiles_dir.exists():
            # Keep the structure but clear user data
            for f in profiles_dir.glob("**/*.ini"):
                if f.name != "terminal.ini":
                    f.unlink()
        
        # 4. Delete the INI file after a short delay (security)
        # The terminal reads it on startup, then we remove it
        # This is handled in launch_account via a delayed task
    
    async def launch_account(self, account_id: str) -> bool:
        """
        Launch an MT5 instance.
        
        Uses custom config file with [Common] section containing Login, Server, Password.
        Based on official MT5 documentation:
        https://www.metatrader5.com/en/terminal/help/start_advanced/start
        
        Args:
            account_id: Account to launch
            
        Returns:
            True if launched successfully
        """
        instance = self.instances.get(account_id)
        if not instance:
            logger.error(f"Account {account_id} not provisioned")
            return False
        
        if instance.is_running and instance.pid:
            logger.warning(f"Account {account_id} already running (pid={instance.pid})")
            return True
        
        terminal_path = instance.path / "terminal64.exe"
        
        # Use startup.ini which has [Common] section with Login/Server/Password
        config_path = instance.path / "config" / "startup.ini"
        
        if not terminal_path.exists():
            logger.error(f"terminal64.exe not found at {terminal_path}")
            return False
        
        if not config_path.exists():
            logger.error(f"startup.ini not found at {config_path}")
            return False
        
        try:
            # Check if startup.ini still has a password
            # If the password was removed by credential cleanup, we shouldn't pass it 
            # via /config, or else MT5 will prompt. Native auth will work instead.
            import re
            has_password = False
            if config_path.exists():
                try:
                    content = config_path.read_text(encoding='utf-16')
                except UnicodeError:
                    content = config_path.read_text(errors='ignore')
                if re.search(r'^Password=.+', content, flags=re.MULTILINE):
                    has_password = True

            cmd = [str(terminal_path)]
            if has_password:
                cmd.append(f"/config:{str(config_path)}")
                logger.info(f"Launching MT5 with auto-login config: {account_id}")
            else:
                logger.info(f"Launching MT5 with native saved credentials: {account_id}")
                
            cmd.append("/portable")
            
            logger.debug(f"Command: {' '.join(cmd)}")
            
            process = await asyncio.to_thread(
                subprocess.Popen,
                cmd,
                cwd=str(instance.path),
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            
            instance.pid = process.pid
            instance.is_running = True
            
            logger.info(f"Launched account {account_id} with pid={process.pid} (auto-login enabled)")
            
            # Schedule EA attachment after broker connection
            # This ensures the EA initializes AFTER the broker is connected
            asyncio.create_task(self._delayed_ea_attachment(account_id, instance.path))
            
            # Schedule cleanup of password from startup.ini after MT5 reads it
            asyncio.create_task(self._delayed_credential_cleanup(account_id, config_path))
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to launch account {account_id}: {e}")
            raise e
    
    async def _delayed_credential_cleanup(self, account_id: str, config_path: Path):
        """
        Clean up sensitive credentials from startup.ini after MT5 has read it.
        
        MT5 reads the config file on startup, then we remove the Password line.
        The config file is in "read only" mode during MT5 operation per docs.
        
        We wait 120 seconds because:
        - MT5 takes 5-10 seconds to fully start
        - Broker authentication can take 10-30 seconds
        - When provisioning multiple accounts, there's additional delay
        """
        await asyncio.sleep(120)  # Give MT5 ample time to read config, connect, and authenticate
        
        try:
            if config_path.exists():
                try:
                    content = config_path.read_text(encoding='utf-16')
                    encoding = 'utf-16'
                except UnicodeError:
                    content = config_path.read_text()
                    encoding = None
                    
                # Remove the Password line, keep everything else
                import re
                cleaned = re.sub(r'^Password=.*$\r?\n?', '', content, flags=re.MULTILINE)
                
                if encoding:
                    config_path.write_text(cleaned, encoding=encoding)
                else:
                    config_path.write_text(cleaned)
                logger.debug(f"Removed password from {config_path.name} for {account_id}")
                
                # Also clean common.ini if it has the password
                common_ini = config_path.parent / "common.ini"
                if common_ini.exists():
                    try:
                        content_common = common_ini.read_text(encoding='utf-16')
                        enc_common = 'utf-16'
                    except UnicodeError:
                        content_common = common_ini.read_text()
                        enc_common = None
                    
                    cleaned_common = re.sub(r'^Password=.*$\r?\n?', '', content_common, flags=re.MULTILINE)
                    
                    if enc_common:
                        common_ini.write_text(cleaned_common, encoding=enc_common)
                    else:
                        common_ini.write_text(cleaned_common)
                    logger.debug(f"Removed password from common.ini for {account_id}")
        except Exception as e:
            logger.warning(f"Failed to cleanup credentials for {account_id}: {e}")
            
    async def _wait_for_login_status(self, account_id: str, instance_path: Path, timeout: int = 45) -> bool:
        """Wait for the MT5 log file to show successful login or failure."""
        log_dir = instance_path / "logs" # MT5 typically uses lowercase 'logs'
        import time
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            log_files = list(log_dir.glob("*.log"))
            
            # Find the most recently modified log file
            if log_files:
                latest_log = max(log_files, key=lambda f: f.stat().st_mtime)
                
                try:
                    # Read as bytes first to avoid blocking issues or encoding crashes
                    with open(latest_log, "rb") as f:
                        raw_data = f.read()
                        
                    content = ""
                    try:
                        content = raw_data.decode("utf-16-le")
                    except UnicodeDecodeError:
                        content = raw_data.decode("utf-8", errors="ignore")
                    
                    if "invalid account" in content.lower() or "authorization failed" in content.lower():
                        logger.error(f"MT5 Log: Invalid account or authorization failed for {account_id}")
                        return False
                    
                    if "authorized " in content.lower() or "login successful" in content.lower() or "ping:" in content.lower() or "synchronization" in content.lower():
                        logger.info(f"MT5 Log: Login successful for {account_id}")
                        return True
                except Exception as e:
                    logger.warning(f"Error reading log file {latest_log}: {e}")
                    
            await asyncio.sleep(1)
            
        logger.warning(f"Timeout waiting for login status in MT5 logs for {account_id}")
        # Default to True on timeout so we don't kill a potentially slow but successful login
        return True
    
    async def _delayed_ea_attachment(self, account_id: str, instance_path: Path):
        """
        Wait for broker connection, then programmatically reload the chart template.
        
        This forces the EA to reinitialize by sending keyboard commands to MT5
        to apply the Default template to the chart.
        
        Args:
            account_id: Account identifier
            instance_path: Path to the MT5 instance
        """
        try:
            # Wait 30 seconds for MT5 to start and broker to connect
            await asyncio.sleep(30)
            
            # Use PowerShell to send keyboard commands to MT5 window
            # This simulates: Right-click chart → Template → Load Template → Default → Enter
            ps_script = f"""
            Add-Type @"
                using System;
                using System.Runtime.InteropServices;
                public class WinAPI {{
                    [DllImport("user32.dll")]
                    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
                    [DllImport("user32.dll")]
                    public static extern bool SetForegroundWindow(IntPtr hWnd);
                    [DllImport("user32.dll")]
                    public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
                }}
"@
            
            # Find MT5 window by title (contains account_id)
            $windowTitle = "*{account_id}*"
            $hwnd = [WinAPI]::FindWindow($null, $windowTitle)
            
            if ($hwnd -eq [IntPtr]::Zero) {{
                # Try finding by process
                $process = Get-Process | Where-Object {{ $_.MainWindowTitle -like $windowTitle }} | Select-Object -First 1
                if ($process) {{
                    $hwnd = $process.MainWindowHandle
                }}
            }}
            
            if ($hwnd -ne [IntPtr]::Zero) {{
                # Bring MT5 window to foreground
                [WinAPI]::SetForegroundWindow($hwnd)
                Start-Sleep -Milliseconds 500
                
                # Send keyboard sequence to reload template
                # Alt+C (Charts menu) → T (Template) → L (Load Template) → Down → Enter
                # VK_MENU = 0x12 (Alt), VK_C = 0x43, VK_T = 0x54, VK_L = 0x4C
                # VK_DOWN = 0x28, VK_RETURN = 0x0D
                
                # Press Alt
                [WinAPI]::keybd_event(0x12, 0, 0, [UIntPtr]::Zero)
                Start-Sleep -Milliseconds 100
                # Press C (Charts menu)
                [WinAPI]::keybd_event(0x43, 0, 0, [UIntPtr]::Zero)
                [WinAPI]::keybd_event(0x43, 0, 2, [UIntPtr]::Zero)
                # Release Alt
                [WinAPI]::keybd_event(0x12, 0, 2, [UIntPtr]::Zero)
                Start-Sleep -Milliseconds 300
                
                # Press T (Template)
                [WinAPI]::keybd_event(0x54, 0, 0, [UIntPtr]::Zero)
                [WinAPI]::keybd_event(0x54, 0, 2, [UIntPtr]::Zero)
                Start-Sleep -Milliseconds 300
                
                # Press L (Load Template)
                [WinAPI]::keybd_event(0x4C, 0, 0, [UIntPtr]::Zero)
                [WinAPI]::keybd_event(0x4C, 0, 2, [UIntPtr]::Zero)
                Start-Sleep -Milliseconds 500
                
                # Press Down arrow to select Default template
                [WinAPI]::keybd_event(0x28, 0, 0, [UIntPtr]::Zero)
                [WinAPI]::keybd_event(0x28, 0, 2, [UIntPtr]::Zero)
                Start-Sleep -Milliseconds 200
                
                # Press Enter to apply
                [WinAPI]::keybd_event(0x0D, 0, 0, [UIntPtr]::Zero)
                [WinAPI]::keybd_event(0x0D, 0, 2, [UIntPtr]::Zero)
                
                Write-Host "Sent template reload commands to MT5"
            }} else {{
                Write-Host "MT5 window not found for {account_id}"
            }}
            """
            
            # Execute PowerShell script
            import subprocess
            result = await asyncio.create_subprocess_exec(
                "powershell", "-Command", ps_script,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await result.communicate()
            
            if result.returncode == 0:
                logger.info(f"Triggered EA reload via template for {account_id}")
            else:
                logger.warning(f"Failed to reload template for {account_id}: {stderr.decode()}")
                
        except Exception as e:
            logger.error(f"Failed to trigger EA reload for {account_id}: {e}")
    
    async def terminate_account(self, account_id: str, cleanup: bool = False) -> bool:
        """
        Terminate an MT5 instance.
        
        Args:
            account_id: Account to terminate
            cleanup: Whether to delete the instance directory
            
        Returns:
            True if terminated successfully
        """
        instance = self.instances.get(account_id)
        if not instance:
            logger.warning(f"Account {account_id} not found")
            return False
        
        # Kill the process
        if instance.pid and PSUTIL_AVAILABLE:
            try:
                proc = psutil.Process(instance.pid)
                proc.terminate()
                
                # Wait for graceful shutdown
                try:
                    await asyncio.to_thread(proc.wait, timeout=5)
                except psutil.TimeoutExpired:
                    proc.kill()
                    
                logger.info(f"Terminated account {account_id} (pid={instance.pid})")
                
            except psutil.NoSuchProcess:
                logger.debug(f"Process already dead for {account_id}")
            except Exception as e:
                logger.error(f"Error terminating {account_id}: {e}")
        
        instance.is_running = False
        instance.pid = None
        
        # Cleanup if requested
        if cleanup:
            try:
                if instance.path.exists():
                    # IMPORTANT: Cache golden config before deleting
                    # This preserves WebRequestUrl and broker config for future provisioning
                    await self._cache_golden_config(instance.path)
                    await asyncio.to_thread(shutil.rmtree, instance.path)
                self.credentials.delete_credentials(account_id)
                del self.instances[account_id]
                logger.info(f"Cleaned up instance directory for {account_id}")
            except Exception as e:
                logger.error(f"Failed to cleanup {account_id}: {e}")
        
        return True
    
    async def check_health(self, account_id: str) -> bool:
        """
        Check if an MT5 instance is running.
        
        Args:
            account_id: Account to check
            
        Returns:
            True if the process is running
        """
        instance = self.instances.get(account_id)
        if not instance or not instance.pid:
            return False
        
        if not PSUTIL_AVAILABLE:
            logger.warning("psutil not available, cannot check process health")
            return instance.is_running
        
        try:
            proc = psutil.Process(instance.pid)
            is_alive = proc.status() == psutil.STATUS_RUNNING
            instance.last_health_check = datetime.now()
            instance.is_running = is_alive
            return is_alive
        except psutil.NoSuchProcess:
            instance.is_running = False
            return False
    
    async def health_check_all(self) -> Dict[str, bool]:
        """Check health of all instances."""
        results = {}
        for account_id in self.instances:
            results[account_id] = await self.check_health(account_id)
        return results
    
    async def recover_zombie(self, account_id: str) -> bool:
        """
        Recover a zombie instance by restarting it.
        
        Args:
            account_id: Account to recover
            
        Returns:
            True if recovered successfully
        """
        logger.warning(f"Attempting to recover zombie: {account_id}")
        
        instance = self.instances.get(account_id)
        if not instance:
            return False
        
        # Kill any existing process
        await self.terminate_account(account_id, cleanup=False)
        
        # Re-inject credentials (password from secure storage)
        password = self.credentials.get_credentials(account_id)
        if not password:
            logger.error(f"No credentials found for {account_id}, cannot recover")
            return False
        
        # Re-inject config
        await asyncio.to_thread(
            self._inject_config,
            instance.path,
            account_id,
            instance.login,
            password,
            instance.server
        )
        
        # Relaunch
        return await self.launch_account(account_id)
    
    def get_instance_status(self, account_id: str) -> Optional[dict]:
        """Get status of a specific instance."""
        instance = self.instances.get(account_id)
        if not instance:
            return None
        
        return {
            "account_id": instance.account_id,
            "login": instance.login,
            "server": instance.server,
            "path": str(instance.path),
            "pid": instance.pid,
            "is_running": instance.is_running,
            "created_at": instance.created_at.isoformat(),
            "last_health_check": instance.last_health_check.isoformat() if instance.last_health_check else None
        }
    
    def get_all_instances(self) -> List[dict]:
        """Get status of all instances."""
        return [
            self.get_instance_status(acc_id)
            for acc_id in self.instances
        ]
    
    def list_available_brokers(self) -> List[dict]:
        """
        List all broker servers that have been used on this machine.
        
        Scans AppData/MetaQuotes/Terminal folders for broker configurations.
        This helps users know which brokers can be provisioned without
        requiring manual login first.
        
        Returns:
            List of broker info dicts with server name, path, and has_bases flag
        """
        import re
        
        brokers = []
        seen_servers = set()
        
        # Search AppData/Roaming/MetaQuotes/Terminal
        appdata = Path(os.environ.get("APPDATA", ""))
        mq_terminals = appdata / "MetaQuotes" / "Terminal"
        
        search_paths = []
        if mq_terminals.exists():
            for terminal_dir in mq_terminals.iterdir():
                if terminal_dir.is_dir() and len(terminal_dir.name) == 32:
                    search_paths.append(terminal_dir)
        
        # Also check farm instances
        if self.farm_path.exists():
            for farm_dir in self.farm_path.iterdir():
                if farm_dir.is_dir():
                    search_paths.append(farm_dir)
        
        for path in search_paths:
            common_ini = path / "config" / "common.ini"
            if common_ini.exists():
                try:
                    try:
                        content = common_ini.read_text(encoding='utf-16')
                    except (UnicodeDecodeError, UnicodeError):
                        content = common_ini.read_text(errors='ignore')
                    
                    # Extract Server= line
                    match = re.search(r'^Server=(.+?)\s*$', content, re.MULTILINE)
                    if match:
                        server = match.group(1).strip()
                        if server and server not in seen_servers:
                            seen_servers.add(server)
                            
                            # Check for Bases folder
                            bases_dir = path / "Bases" / server
                            has_bases = bases_dir.exists() and bases_dir.is_dir()
                            
                            brokers.append({
                                "server": server,
                                "source_path": str(path),
                                "has_bases": has_bases,
                                "ready": has_bases  # Ready for provisioning if has Bases
                            })
                except Exception as e:
                    logger.debug(f"Error reading {common_ini}: {e}")
                    continue
        
        # Sort by readiness (ready first) then alphabetically
        brokers.sort(key=lambda x: (not x['ready'], x['server']))
        return brokers
    
    async def discover_existing(self):
        """Discover existing instance directories and register them."""
        logger.info("Discovering existing instances...")
        
        if not self.farm_path.exists():
            return
        
        for item in self.farm_path.iterdir():
            if item.is_dir() and item.name.startswith("acct_"):
                account_id = None
                
                # Try to read config from pipe_id.txt
                # Format: account_id,port (e.g., "Account_12345,9001")
                pipe_id_path = item / "MQL5" / "Files" / "pipe_id.txt"
                if pipe_id_path.exists():
                    content = pipe_id_path.read_text().strip()
                    if "," in content:
                        # New format: account_id,port
                        parts = content.split(",", 1)
                        account_id = parts[0]
                    else:
                        # Old format: just account_id
                        account_id = content
                
                if not account_id:
                    logger.debug(f"Could not read account_id for {item.name}, skipping.")
                    continue
                
                if account_id in self.instances:
                    continue
                
                # Create instance record (we don't know login/server without config)
                instance = MT5Instance(
                    account_id=account_id,
                    login=0,
                    server="unknown",
                    path=item
                )
                self.instances[account_id] = instance
                
                # Check if running
                await self.check_health(account_id)
                
                logger.info(f"Discovered existing instance: {account_id} at {item.name}")
