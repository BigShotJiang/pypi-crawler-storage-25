"""
MT5 Farm - Main Entry Point

This is the main application that ties together:
- FarmController (TCP server for MT5 connections)
- MT5Provisioner (Instance factory)
- FastAPI Router (REST + WebSocket API)

Usage:
    python -m farm.main
    
    # Or with uvicorn directly:
    uvicorn farm.main:app --host 0.0.0.0 --port 8000
"""

import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .controller import FarmController
from .provisioner import MT5Provisioner
from .api.router import router as farm_router, init_farm_router
from .config.settings import settings

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)

if settings.log_file:
    file_handler = logging.FileHandler(settings.log_file)
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    )
    logging.getLogger().addHandler(file_handler)

logger = logging.getLogger(__name__)

# Global instances
controller: FarmController = None
provisioner: MT5Provisioner = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    global controller, provisioner
    
    logger.info("Starting MT5 Farm...")
    
    # Initialize controller
    controller = FarmController(
        host=settings.controller_host,
        port=settings.controller_port,
        ping_interval=settings.ping_interval,
        ping_timeout=settings.ping_timeout,
        max_missed_pings=settings.max_missed_pings
    )
    
    # Initialize provisioner
    provisioner = MT5Provisioner(
        master_path=str(settings.master_path),
        farm_path=str(settings.farm_path),
        controller_host=settings.controller_host,
        controller_port=settings.controller_port
    )
    
    # Validate master installation
    if not provisioner.validate_master():
        logger.warning(
            f"Master MT5 installation not found or incomplete at {settings.master_path}. "
            "Provisioning will fail until this is set up."
        )
    
    # Discover existing instances
    await provisioner.discover_existing()
    
    # Initialize API router
    init_farm_router(controller, provisioner)
    
    # Start controller
    await controller.start()
    
    # Start health check task if auto-recovery is enabled
    health_task = None
    if settings.auto_recovery:
        health_task = asyncio.create_task(health_check_loop())
    
    # Start auto-start task for disconnected instances
    auto_start_task = asyncio.create_task(auto_start_instances())
    
    logger.info(f"MT5 Farm started - API on {settings.api_host}:{settings.api_port}")
    logger.info(f"Controller listening on {settings.controller_host}:{settings.controller_port}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down MT5 Farm...")
    
    if health_task:
        health_task.cancel()
        try:
            await health_task
        except asyncio.CancelledError:
            pass
    
    if auto_start_task:
        auto_start_task.cancel()
        try:
            await auto_start_task
        except asyncio.CancelledError:
            pass
    
    await controller.stop()
    
    logger.info("MT5 Farm stopped")


async def auto_start_instances():
    """Auto-start provisioned instances that are not connected.
    
    Unlike launch_account (which passes /config:startup.ini for first-time login),
    this launches MT5 with just /portable. The instance already has saved credentials
    from when it was originally provisioned, so MT5 will auto-connect natively.
    """
    import subprocess
    import os
    
    # Give the controller time to start and existing instances to connect
    await asyncio.sleep(3)
    
    logger.info("Checking for disconnected MT5 instances...")
    
    # Check each provisioned instance
    for account_id, instance in provisioner.instances.items():
        # Check if connected to controller
        node = controller.nodes.get(account_id)
        if node and node.is_alive:
            logger.info(f"Instance {account_id} already connected - skipping")
            continue
        
        terminal_path = instance.path / "terminal64.exe"
        if not terminal_path.exists():
            logger.warning(f"Instance {account_id}: terminal64.exe not found at {instance.path}")
            continue
        
        # Check if already running (process-level)
        if instance.is_running and instance.pid:
            logger.info(f"Instance {account_id} process already running (pid={instance.pid}) but not connected yet - skipping")
            continue
        
        logger.info(f"Instance {account_id} not connected, launching MT5 in portable mode...")
        try:
            # Launch with ONLY /portable - no /config parameter
            # MT5 will use its natively saved credentials from the original provisioning
            cmd = [str(terminal_path), "/portable"]
            
            process = await asyncio.to_thread(
                subprocess.Popen,
                cmd,
                cwd=str(instance.path),
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            
            instance.pid = process.pid
            instance.is_running = True
            
            logger.info(f"Auto-started {account_id} (pid={process.pid}) - using saved credentials")
        except Exception as e:
            logger.error(f"Failed to auto-start instance {account_id}: {e}")


async def health_check_loop():
    """Periodic health check and auto-recovery."""
    while True:
        await asyncio.sleep(settings.health_check_interval)
        
        try:
            # Check all instances
            results = await provisioner.health_check_all()
            
            # Find dead instances - but only recover if:
            # 1. Instance is unhealthy (process not running)
            # 2. AND not connected to controller (EA not alive)
            # 3. AND we have credentials to recover
            for account_id, is_healthy in results.items():
                if not is_healthy:
                    # Check if EA is actually connected to controller
                    node = controller.nodes.get(account_id)
                    if node and node.is_alive:
                        # EA is connected, instance is fine even if we don't track the PID
                        logger.debug(f"Instance {account_id} process unknown but EA connected - OK")
                        continue
                    
                    # Check if we have credentials to recover
                    if not provisioner.credentials.get_credentials(account_id):
                        logger.debug(f"Instance {account_id} unhealthy but no credentials - skipping recovery")
                        continue
                    
                    logger.warning(f"Instance {account_id} is unhealthy, attempting recovery")
                    await provisioner.recover_zombie(account_id)
                    
        except Exception as e:
            logger.error(f"Health check error: {e}")


# Create FastAPI app
app = FastAPI(
    title="MT5 Farm",
    description="Automated MT5 Server Farm for High-Frequency Trading",
    version="0.1.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include farm router
app.include_router(farm_router)


@app.get("/")
async def root():
    """Health check endpoint."""
    return {
        "service": "MT5 Farm",
        "status": "running",
        "version": "0.1.0"
    }


@app.get("/health")
async def health():
    """Detailed health check."""
    return {
        "service": "MT5 Farm",
        "status": "healthy",
        "controller": {
            "running": controller._running if controller else False,
            "connected_nodes": len(controller.nodes) if controller else 0
        },
        "provisioner": {
            "instances": len(provisioner.instances) if provisioner else 0
        }
    }


# CLI entry point
if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "farm.main:app",
        host=settings.api_host,
        port=settings.api_port,
        reload=False,
        log_level=settings.log_level.lower()
    )
