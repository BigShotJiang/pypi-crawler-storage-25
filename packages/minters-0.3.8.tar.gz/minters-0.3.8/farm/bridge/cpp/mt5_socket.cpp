/*
 * MT5Socket.cpp - TCP Socket Communication DLL Implementation
 * 
 * Provides reliable TCP socket communication between MQL5 and Python.
 * Uses non-blocking sockets for the receive function to prevent
 * blocking the MT5 main thread.
 */

#define MT5SOCKET_EXPORTS
#include "mt5_socket.h"
#include <map>
#include <mutex>

// Global state
static bool g_initialized = false;
static std::map<int, SOCKET> g_sockets;
static std::mutex g_mutex;
static int g_nextHandle = 1;
static int g_lastError = 0;

MT5SOCKET_API int __stdcall SocketInit() {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    if (g_initialized) {
        return 0; // Already initialized
    }
    
    WSADATA wsaData;
    int result = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (result != 0) {
        g_lastError = result;
        return result;
    }
    
    g_initialized = true;
    return 0;
}

MT5SOCKET_API void __stdcall SocketCleanup() {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    if (!g_initialized) {
        return;
    }
    
    // Close all open sockets
    for (auto& pair : g_sockets) {
        closesocket(pair.second);
    }
    g_sockets.clear();
    
    WSACleanup();
    g_initialized = false;
}

MT5SOCKET_API int __stdcall SocketConnect(const char* host, int port) {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    if (!g_initialized) {
        g_lastError = WSANOTINITIALISED;
        return -1;
    }
    
    // Create socket
    SOCKET sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock == INVALID_SOCKET) {
        g_lastError = WSAGetLastError();
        return -1;
    }
    
    // Set up address
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    
    if (inet_pton(AF_INET, host, &addr.sin_addr) <= 0) {
        g_lastError = WSAGetLastError();
        closesocket(sock);
        return -1;
    }
    
    // Connect
    if (connect(sock, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR) {
        g_lastError = WSAGetLastError();
        closesocket(sock);
        return -1;
    }
    
    // Set non-blocking mode for receive operations
    u_long mode = 1;
    ioctlsocket(sock, FIONBIO, &mode);
    
    // Disable Nagle's algorithm for low latency
    int flag = 1;
    setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, (char*)&flag, sizeof(flag));
    
    // Store socket and return handle
    int handle = g_nextHandle++;
    g_sockets[handle] = sock;
    
    return handle;
}

MT5SOCKET_API int __stdcall SocketSend(int handle, const char* data, int size) {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    auto it = g_sockets.find(handle);
    if (it == g_sockets.end()) {
        g_lastError = WSAENOTSOCK;
        return -1;
    }
    
    SOCKET sock = it->second;
    
    // Set blocking mode temporarily for reliable send
    u_long mode = 0;
    ioctlsocket(sock, FIONBIO, &mode);
    
    int totalSent = 0;
    while (totalSent < size) {
        int sent = send(sock, data + totalSent, size - totalSent, 0);
        if (sent == SOCKET_ERROR) {
            g_lastError = WSAGetLastError();
            // Restore non-blocking mode
            mode = 1;
            ioctlsocket(sock, FIONBIO, &mode);
            return -1;
        }
        totalSent += sent;
    }
    
    // Restore non-blocking mode
    mode = 1;
    ioctlsocket(sock, FIONBIO, &mode);
    
    return totalSent;
}

MT5SOCKET_API int __stdcall SocketRecv(int handle, char* buffer, int size) {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    auto it = g_sockets.find(handle);
    if (it == g_sockets.end()) {
        g_lastError = WSAENOTSOCK;
        return -1;
    }
    
    SOCKET sock = it->second;
    
    // Non-blocking receive
    int received = recv(sock, buffer, size, 0);
    
    if (received == SOCKET_ERROR) {
        int error = WSAGetLastError();
        if (error == WSAEWOULDBLOCK) {
            // No data available (non-blocking)
            return 0;
        }
        g_lastError = error;
        return -1;
    }
    
    if (received == 0) {
        // Connection closed by server
        g_lastError = WSAECONNRESET;
        return -1;
    }
    
    return received;
}

MT5SOCKET_API int __stdcall SocketIsConnected(int handle) {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    auto it = g_sockets.find(handle);
    if (it == g_sockets.end()) {
        return 0;
    }
    
    SOCKET sock = it->second;
    
    // Check if socket is still valid by attempting a zero-byte recv
    char dummy;
    int result = recv(sock, &dummy, 0, 0);
    
    if (result == SOCKET_ERROR) {
        int error = WSAGetLastError();
        if (error != WSAEWOULDBLOCK) {
            return 0; // Disconnected
        }
    }
    
    return 1; // Connected
}

MT5SOCKET_API void __stdcall SocketClose(int handle) {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    auto it = g_sockets.find(handle);
    if (it == g_sockets.end()) {
        return;
    }
    
    closesocket(it->second);
    g_sockets.erase(it);
}

MT5SOCKET_API int __stdcall SocketGetLastError() {
    return g_lastError;
}

// DLL Entry Point
BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    switch (ul_reason_for_call) {
        case DLL_PROCESS_ATTACH:
            DisableThreadLibraryCalls(hModule);
            break;
        case DLL_PROCESS_DETACH:
            SocketCleanup();
            break;
    }
    return TRUE;
}
