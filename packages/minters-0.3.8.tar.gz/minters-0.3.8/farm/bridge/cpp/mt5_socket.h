/*
 * MT5Socket.h - TCP Socket Communication DLL for MetaTrader 5
 * 
 * This DLL provides non-blocking TCP socket functions for MQL5 to communicate
 * with the Python controller. Uses localhost sockets for reliability and
 * compatibility with Python asyncio.
 * 
 * Build Instructions:
 * 1. Create a new Visual Studio DLL project (x64)
 * 2. Add mt5_socket.h and mt5_socket.cpp to the project
 * 3. Build as Release x64
 * 4. Copy MT5Socket.dll to MT5_MASTER/MQL5/Libraries/
 * 
 * Exported Functions:
 * - SocketConnect(host, port): Connect to Python controller
 * - SocketSend(handle, data, size): Send binary data
 * - SocketRecv(handle, buffer, size): Non-blocking receive
 * - SocketClose(handle): Clean up connection
 * - SocketIsConnected(handle): Check connection status
 */

#ifndef MT5_SOCKET_H
#define MT5_SOCKET_H

#ifdef MT5SOCKET_EXPORTS
#define MT5SOCKET_API __declspec(dllexport)
#else
#define MT5SOCKET_API __declspec(dllimport)
#endif

#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")

extern "C" {

/*
 * Initialize Winsock library
 * Must be called once before any socket operations
 * Returns: 0 on success, error code on failure
 */
MT5SOCKET_API int __stdcall SocketInit();

/*
 * Cleanup Winsock library
 * Call when shutting down
 */
MT5SOCKET_API void __stdcall SocketCleanup();

/*
 * Connect to the Python controller
 * @param host: IP address (e.g., "127.0.0.1")
 * @param port: Port number (e.g., 8888)
 * Returns: Socket handle (>0) on success, -1 on failure
 */
MT5SOCKET_API int __stdcall SocketConnect(const char* host, int port);

/*
 * Send binary data to the controller
 * @param handle: Socket handle from SocketConnect
 * @param data: Pointer to data buffer
 * @param size: Number of bytes to send
 * Returns: Number of bytes sent, -1 on error
 */
MT5SOCKET_API int __stdcall SocketSend(int handle, const char* data, int size);

/*
 * Receive data from the controller (non-blocking)
 * @param handle: Socket handle from SocketConnect
 * @param buffer: Pointer to receive buffer
 * @param size: Maximum bytes to receive
 * Returns: Number of bytes received, 0 if no data, -1 on error
 */
MT5SOCKET_API int __stdcall SocketRecv(int handle, char* buffer, int size);

/*
 * Check if socket is still connected
 * @param handle: Socket handle from SocketConnect
 * Returns: 1 if connected, 0 if disconnected
 */
MT5SOCKET_API int __stdcall SocketIsConnected(int handle);

/*
 * Close the socket connection
 * @param handle: Socket handle from SocketConnect
 */
MT5SOCKET_API void __stdcall SocketClose(int handle);

/*
 * Get the last socket error code
 * Returns: Winsock error code
 */
MT5SOCKET_API int __stdcall SocketGetLastError();

}

#endif // MT5_SOCKET_H
