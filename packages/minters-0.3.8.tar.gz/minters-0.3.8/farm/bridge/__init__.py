"""
Bridge Module - C++ DLL and MQL5 Expert Advisor

This module contains the source code for:
1. MT5Pipe DLL (C++) - Handles TCP socket communication
2. MT5Bridge EA (MQL5) - Lives inside MT5, streams ticks, receives commands
"""
