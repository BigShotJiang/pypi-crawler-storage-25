//+------------------------------------------------------------------+
//|                                                    MT5Bridge.mq5 |
//|                                          Tooig Farm MT5 Bridge   |
//|                                    TCP Socket Bridge to Python   |
//+------------------------------------------------------------------+
#property copyright "Tooig"
#property version   "2.20"
#property strict

//--- Input Parameters (fallbacks if pipe_id.txt not found)
input string   CONTROLLER_HOST = "127.0.0.1";  // Python Controller IP
input int      DEFAULT_PORT = 8888;             // Default port (override by pipe_id.txt)
input int      POLL_INTERVAL_MS = 50;           // Command polling interval (ms)
input int      RECONNECT_DELAY_MS = 5000;       // Reconnect delay on disconnect
input bool     ENABLE_TICK_STREAM = true;       // Stream ticks to controller
input bool     ENABLE_DEBUG = false;            // Debug logging

// NOTE: This version uses native MQL5 sockets (no DLL required)
// Native sockets available since MT5 build 2390+
// Port and Account ID are read from pipe_id.txt (format: account_id,port)

//--- Message Types (must match Python protocol)
#define MSG_LOGIN           1
#define MSG_TICK            2
#define MSG_COMMAND_RESP    3
#define MSG_TRADE_CMD       4
#define MSG_HISTORY_CMD     5
#define MSG_PING            6
#define MSG_PONG            7
#define MSG_ACCOUNT_INFO    8
#define MSG_POSITIONS       9
#define MSG_ERROR          10

//--- Extended trading operations (11-20)
#define MSG_PENDING_ORDER_CMD   11    // Place pending order (limit/stop/stop-limit)
#define MSG_MODIFY_POSITION_CMD 12    // Modify position (SL/TP)
#define MSG_MODIFY_ORDER_CMD    13    // Modify pending order
#define MSG_CANCEL_ORDER_CMD    14    // Cancel pending order
#define MSG_CLOSE_PARTIAL_CMD   15    // Partial position close
#define MSG_CLOSE_BY_CMD        16    // Close position by opposite

//--- Extended data queries (21-30)
#define MSG_PENDING_ORDERS      21    // Pending orders list
#define MSG_DEAL_HISTORY        22    // Trade/deal history
#define MSG_SYMBOL_INFO         23    // Symbol information
#define MSG_CURRENT_PRICE       24    // Current bid/ask for symbol

//--- Global Variables
int g_socket = INVALID_HANDLE;
bool g_connected = false;
string g_accountId = "";
int g_controllerPort = 0;              // Read from pipe_id.txt
datetime g_lastPingTime = 0;
datetime g_lastReconnectAttempt = 0;
int g_missedPings = 0;

//--- Receive Buffer
uchar g_recvBuffer[];
int g_recvBufferPos = 0;

//+------------------------------------------------------------------+
//| Expert initialization function                                     |
//+------------------------------------------------------------------+
int OnInit()
{
    //--- Initialize receive buffer
    ArrayResize(g_recvBuffer, 65536);
    g_recvBufferPos = 0;
    
    //--- Read account ID and port from pipe_id.txt (set by provisioner)
    //--- Format: account_id,port (e.g., "acc_12345,9001")
    if(!ReadPipeConfig())
    {
        //--- Fallback to account number and default port
        g_accountId = IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN));
        g_controllerPort = DEFAULT_PORT;
        Print("WARNING: pipe_id.txt not found, using defaults");
    }
    
    Print("MT5Bridge v2.1 initialized");
    Print("  Account ID: ", g_accountId);
    Print("  Controller: ", CONTROLLER_HOST, ":", g_controllerPort);
    
    //--- Connect to controller
    if(!ConnectToController())
    {
        Print("WARNING: Initial connection failed, will retry...");
    }
    
    //--- Start polling timer
    EventSetMillisecondTimer(POLL_INTERVAL_MS);
    
    return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                   |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
    EventKillTimer();
    
    if(g_socket != INVALID_HANDLE)
    {
        SocketClose(g_socket);
        g_socket = INVALID_HANDLE;
    }
    
    Print("MT5Bridge deinitialized, reason: ", reason);
}

//+------------------------------------------------------------------+
//| Expert tick function                                               |
//+------------------------------------------------------------------+
void OnTick()
{
    if(!g_connected || !ENABLE_TICK_STREAM)
        return;
    
    //--- Get current tick
    MqlTick tick;
    if(!SymbolInfoTick(_Symbol, tick))
        return;
    
    //--- Send tick to controller
    SendTick(tick);
}

//+------------------------------------------------------------------+
//| Timer function - Poll for commands                                 |
//+------------------------------------------------------------------+
void OnTimer()
{
    //--- Check connection status
    if(!g_connected)
    {
        AttemptReconnect();
        return;
    }
    
    //--- Check if socket is still valid
    if(!SocketIsConnected(g_socket))
    {
        Print("Connection lost, marking disconnected");
        g_connected = false;
        SocketClose(g_socket);
        g_socket = INVALID_HANDLE;
        return;
    }
    
    //--- Receive and process commands
    ProcessIncomingData();
    
    //--- Handle heartbeat
    HandleHeartbeat();
}

//+------------------------------------------------------------------+
//| Connect to Python controller using native MQL5 sockets            |
//+------------------------------------------------------------------+
bool ConnectToController()
{
    //--- Close existing socket if any
    if(g_socket != INVALID_HANDLE)
    {
        SocketClose(g_socket);
        g_socket = INVALID_HANDLE;
    }
    
    //--- Create socket
    g_socket = SocketCreate();
    if(g_socket == INVALID_HANDLE)
    {
        if(ENABLE_DEBUG)
            Print("DEBUG: Failed to create socket, error: ", GetLastError());
        return false;
    }
    
    //--- Connect with timeout (5 seconds)
    if(!SocketConnect(g_socket, CONTROLLER_HOST, g_controllerPort, 5000))
    {
        if(ENABLE_DEBUG)
            Print("DEBUG: Connection failed to ", CONTROLLER_HOST, ":", g_controllerPort, " error: ", GetLastError());
        SocketClose(g_socket);
        g_socket = INVALID_HANDLE;
        return false;
    }
    
    //--- Set socket to non-blocking mode using timeouts
    //--- SocketTimeouts(socket, send_timeout_ms, receive_timeout_ms)
    //--- Using 0 makes operations non-blocking (return immediately)
    if(!SocketTimeouts(g_socket, 100, 0))
    {
        if(ENABLE_DEBUG)
            Print("DEBUG: Failed to set socket timeouts, error: ", GetLastError());
        // Continue anyway - not critical
    }
    
    //--- Send login handshake
    if(!SendLogin())
    {
        Print("ERROR: Failed to send login");
        SocketClose(g_socket);
        g_socket = INVALID_HANDLE;
        return false;
    }
    
    g_connected = true;
    g_missedPings = 0;
    g_lastPingTime = TimeCurrent();
    g_recvBufferPos = 0;
    
    Print("Connected to controller at ", CONTROLLER_HOST, ":", g_controllerPort);
    return true;
}

//+------------------------------------------------------------------+
//| Attempt reconnection with delay                                    |
//+------------------------------------------------------------------+
void AttemptReconnect()
{
    static datetime lastAttempt = 0;
    datetime now = TimeLocal(); // Use local time for more accurate timing
    
    if(now - lastAttempt < RECONNECT_DELAY_MS / 1000)
        return;
    
    lastAttempt = now;
    
    if(ENABLE_DEBUG)
        Print("DEBUG: Attempting reconnection...");
    
    ConnectToController();
}

//+------------------------------------------------------------------+
//| Read account ID and port from provisioner file                     |
//| Format: account_id,port (e.g., "acc_12345,9001")                   |
//+------------------------------------------------------------------+
bool ReadPipeConfig()
{
    string filename = "pipe_id.txt";
    
    if(!FileIsExist(filename))
    {
        if(ENABLE_DEBUG)
            Print("DEBUG: pipe_id.txt not found in MQL5/Files/");
        return false;
    }
    
    //--- Open as ANSI text (Python writes UTF-8/ASCII)
    int handle = FileOpen(filename, FILE_READ|FILE_TXT|FILE_ANSI);
    if(handle == INVALID_HANDLE)
    {
        Print("ERROR: Cannot open pipe_id.txt, error: ", GetLastError());
        return false;
    }
    
    string content = FileReadString(handle);
    FileClose(handle);
    
    Print("DEBUG: Raw pipe_id.txt content: [", content, "]");
    
    //--- Trim whitespace (MQL5 modifies in place)
    StringTrimLeft(content);
    StringTrimRight(content);
    
    //--- Parse format: account_id,port
    int commaPos = StringFind(content, ",");
    if(commaPos < 0)
    {
        //--- Old format: just account_id, use default port
        g_accountId = content;
        g_controllerPort = DEFAULT_PORT;
        Print("INFO: pipe_id.txt has old format (no port), using default port ", DEFAULT_PORT);
        return (g_accountId != "");
    }
    
    //--- New format: account_id,port
    g_accountId = StringSubstr(content, 0, commaPos);
    string portStr = StringSubstr(content, commaPos + 1);
    g_controllerPort = (int)StringToInteger(portStr);
    
    //--- Validate
    if(g_accountId == "" || g_controllerPort <= 0 || g_controllerPort > 65535)
    {
        Print("ERROR: Invalid pipe_id.txt format. Expected: account_id,port");
        return false;
    }
    
    if(ENABLE_DEBUG)
        Print("DEBUG: Loaded config - Account: ", g_accountId, ", Port: ", g_controllerPort);
    
    return true;
}

//+------------------------------------------------------------------+
//| Send login packet to controller                                    |
//+------------------------------------------------------------------+
bool SendLogin()
{
    //--- Check broker connection status
    bool connected = (bool)TerminalInfoInteger(TERMINAL_CONNECTED);
    bool trade_allowed = (bool)AccountInfoInteger(ACCOUNT_TRADE_ALLOWED);
    
    //--- Build login JSON with connection status
    string loginJson = StringFormat(
        "{\"account_id\":\"%s\",\"login\":%d,\"server\":\"%s\",\"company\":\"%s\",\"balance\":%.2f,\"currency\":\"%s\",\"connected\":%s,\"trade_allowed\":%s}",
        g_accountId,
        AccountInfoInteger(ACCOUNT_LOGIN),
        AccountInfoString(ACCOUNT_SERVER),
        AccountInfoString(ACCOUNT_COMPANY),
        AccountInfoDouble(ACCOUNT_BALANCE),
        AccountInfoString(ACCOUNT_CURRENCY),
        connected ? "true" : "false",
        trade_allowed ? "true" : "false"
    );
    
    Print("Sending login: ", loginJson);
    Print("  Broker connected: ", connected, ", Trade allowed: ", trade_allowed);
    bool result = SendMessage(MSG_LOGIN, loginJson);
    Print("Login send result: ", result);
    return result;
}

//+------------------------------------------------------------------+
//| Send tick data to controller                                       |
//+------------------------------------------------------------------+
void SendTick(const MqlTick &tick)
{
    //--- Build tick JSON (compact format for speed)
    string tickJson = StringFormat(
        "{\"s\":\"%s\",\"t\":%d,\"b\":%.5f,\"a\":%.5f,\"l\":%.5f,\"v\":%d}",
        _Symbol,
        (long)tick.time,
        tick.bid,
        tick.ask,
        tick.last,
        tick.volume
    );
    
    SendMessage(MSG_TICK, tickJson);
}

//+------------------------------------------------------------------+
//| Send message with header using native socket                       |
//+------------------------------------------------------------------+
bool SendMessage(int msgType, const string &body)
{
    //--- For login, only check socket handle (g_connected not set yet)
    //--- For other messages, require connected state
    if(g_socket == INVALID_HANDLE)
        return false;
    
    if(msgType != MSG_LOGIN && !g_connected)
        return false;
    
    //--- Convert body to bytes
    uchar bodyBytes[];
    int bodyLen = StringToCharArray(body, bodyBytes, 0, WHOLE_ARRAY, CP_UTF8) - 1; // Exclude null terminator
    if(bodyLen < 0) bodyLen = 0;
    
    //--- Build packet: [MsgType:1][Length:4][Body:N]
    uchar packet[];
    ArrayResize(packet, 5 + bodyLen);
    
    //--- Message type (1 byte)
    packet[0] = (uchar)msgType;
    
    //--- Body length (4 bytes, little-endian)
    packet[1] = (uchar)(bodyLen & 0xFF);
    packet[2] = (uchar)((bodyLen >> 8) & 0xFF);
    packet[3] = (uchar)((bodyLen >> 16) & 0xFF);
    packet[4] = (uchar)((bodyLen >> 24) & 0xFF);
    
    //--- Body
    for(int i = 0; i < bodyLen; i++)
        packet[5 + i] = bodyBytes[i];
    
    //--- Send using native socket
    int sent = SocketSend(g_socket, packet, ArraySize(packet));
    
    if(sent <= 0)
    {
        if(ENABLE_DEBUG)
            Print("DEBUG: Send failed, error: ", GetLastError());
        g_connected = false;
        return false;
    }
    
    return true;
}

//+------------------------------------------------------------------+
//| Process incoming data from controller                              |
//+------------------------------------------------------------------+
void ProcessIncomingData()
{
    //--- Check if data available (non-blocking)
    uint dataLen = SocketIsReadable(g_socket);
    if(dataLen == 0)
        return;
    
    //--- Read available data
    uchar tempBuffer[];
    int received = SocketRead(g_socket, tempBuffer, dataLen, 100);
    
    if(received <= 0)
    {
        if(received < 0)
        {
            //--- Connection error
            if(ENABLE_DEBUG)
                Print("DEBUG: Receive error: ", GetLastError());
            g_connected = false;
        }
        return;
    }
    
    //--- Append to receive buffer
    for(int i = 0; i < received; i++)
    {
        if(g_recvBufferPos < 65536)
            g_recvBuffer[g_recvBufferPos++] = tempBuffer[i];
    }
    
    //--- Process complete messages
    while(ProcessNextMessage())
    {
        //--- Keep processing until no more complete messages
    }
}

//+------------------------------------------------------------------+
//| Process next complete message from buffer                          |
//+------------------------------------------------------------------+
bool ProcessNextMessage()
{
    //--- Need at least header (5 bytes)
    if(g_recvBufferPos < 5)
        return false;
    
    //--- Parse header
    int msgType = g_recvBuffer[0];
    int bodyLen = g_recvBuffer[1] | 
                  (g_recvBuffer[2] << 8) | 
                  (g_recvBuffer[3] << 16) | 
                  (g_recvBuffer[4] << 24);
    
    //--- Sanity check
    if(bodyLen < 0 || bodyLen > 60000)
    {
        Print("ERROR: Invalid body length: ", bodyLen);
        g_recvBufferPos = 0; // Reset buffer
        return false;
    }
    
    //--- Check if full message available
    if(g_recvBufferPos < 5 + bodyLen)
        return false;
    
    //--- Extract body
    uchar bodyBytes[];
    ArrayResize(bodyBytes, bodyLen + 1);
    for(int i = 0; i < bodyLen; i++)
        bodyBytes[i] = g_recvBuffer[5 + i];
    bodyBytes[bodyLen] = 0; // Null terminator
    
    string body = CharArrayToString(bodyBytes, 0, bodyLen, CP_UTF8);
    
    //--- Remove processed message from buffer
    int remaining = g_recvBufferPos - (5 + bodyLen);
    for(int i = 0; i < remaining; i++)
        g_recvBuffer[i] = g_recvBuffer[5 + bodyLen + i];
    g_recvBufferPos = remaining;
    
    //--- Handle message
    HandleMessage(msgType, body);
    
    return true;
}

//+------------------------------------------------------------------+
//| Handle received message                                            |
//+------------------------------------------------------------------+
void HandleMessage(int msgType, const string &body)
{
    if(ENABLE_DEBUG)
        Print("DEBUG: Received msgType=", msgType, " body=", body);
    
    //--- Extract request_id if present (for response matching)
    string requestId = JsonGetString(body, "request_id");
    
    switch(msgType)
    {
        case MSG_PING:
            HandlePing();
            break;
            
        case MSG_TRADE_CMD:
            HandleTradeCommand(body);
            break;
            
        case MSG_HISTORY_CMD:
            HandleHistoryCommand(body);
            break;
            
        case MSG_ACCOUNT_INFO:
            SendAccountInfo(requestId);
            break;
            
        case MSG_POSITIONS:
            SendPositions(requestId);
            break;
        
        //--- Extended trading operations
        case MSG_PENDING_ORDER_CMD:
            HandlePendingOrderCommand(body);
            break;
            
        case MSG_MODIFY_POSITION_CMD:
            HandleModifyPositionCommand(body);
            break;
            
        case MSG_MODIFY_ORDER_CMD:
            HandleModifyOrderCommand(body);
            break;
            
        case MSG_CANCEL_ORDER_CMD:
            HandleCancelOrderCommand(body);
            break;
            
        case MSG_CLOSE_PARTIAL_CMD:
            HandleClosePartialCommand(body);
            break;
            
        case MSG_CLOSE_BY_CMD:
            HandleCloseByCommand(body);
            break;
        
        //--- Extended data queries
        case MSG_PENDING_ORDERS:
            SendPendingOrders(requestId);
            break;
            
        case MSG_DEAL_HISTORY:
            HandleDealHistoryRequest(body);
            break;
            
        case MSG_SYMBOL_INFO:
            HandleSymbolInfoRequest(body);
            break;
            
        case MSG_CURRENT_PRICE:
            HandleCurrentPriceRequest(body);
            break;
            
        default:
            if(ENABLE_DEBUG)
                Print("DEBUG: Unknown message type: ", msgType);
    }
}

//+------------------------------------------------------------------+
//| Handle ping request                                                |
//+------------------------------------------------------------------+
void HandlePing()
{
    g_missedPings = 0;
    g_lastPingTime = TimeCurrent();
    
    //--- Send pong response
    SendMessage(MSG_PONG, "{\"status\":\"ok\"}");
}

//+------------------------------------------------------------------+
//| Handle heartbeat (check for missed pings)                          |
//+------------------------------------------------------------------+
void HandleHeartbeat()
{
    datetime now = TimeCurrent();
    
    //--- If no ping received in 15 seconds, assume connection issue
    if(now - g_lastPingTime > 15)
    {
        g_missedPings++;
        g_lastPingTime = now;
        
        if(g_missedPings >= 3)
        {
            Print("WARNING: Missed 3 pings, disconnecting");
            g_connected = false;
        }
    }
}

//+------------------------------------------------------------------+
//| Handle trade command from controller                               |
//+------------------------------------------------------------------+
void HandleTradeCommand(const string &body)
{
    //--- Parse JSON command
    //--- Expected format: {"action":"buy|sell|close","symbol":"EURUSD","volume":0.01,"ticket":0}
    
    string action = JsonGetString(body, "action");
    string symbol = JsonGetString(body, "symbol");
    double volume = JsonGetDouble(body, "volume");
    long ticket = JsonGetLong(body, "ticket");
    string requestId = JsonGetString(body, "request_id");
    
    MqlTradeRequest request = {};
    MqlTradeResult result = {};
    
    if(action == "buy")
    {
        request.action = TRADE_ACTION_DEAL;
        request.symbol = (symbol != "") ? symbol : _Symbol;
        request.volume = volume;
        request.type = ORDER_TYPE_BUY;
        request.price = SymbolInfoDouble(request.symbol, SYMBOL_ASK);
        request.deviation = 20;
        request.magic = 12345;
        request.comment = "Farm Bridge";
    }
    else if(action == "sell")
    {
        request.action = TRADE_ACTION_DEAL;
        request.symbol = (symbol != "") ? symbol : _Symbol;
        request.volume = volume;
        request.type = ORDER_TYPE_SELL;
        request.price = SymbolInfoDouble(request.symbol, SYMBOL_BID);
        request.deviation = 20;
        request.magic = 12345;
        request.comment = "Farm Bridge";
    }
    else if(action == "close")
    {
        //--- Close position by ticket
        if(ticket > 0)
        {
            if(PositionSelectByTicket(ticket))
            {
                request.action = TRADE_ACTION_DEAL;
                request.position = ticket;
                request.symbol = PositionGetString(POSITION_SYMBOL);
                request.volume = PositionGetDouble(POSITION_VOLUME);
                
                if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
                {
                    request.type = ORDER_TYPE_SELL;
                    request.price = SymbolInfoDouble(request.symbol, SYMBOL_BID);
                }
                else
                {
                    request.type = ORDER_TYPE_BUY;
                    request.price = SymbolInfoDouble(request.symbol, SYMBOL_ASK);
                }
                request.deviation = 20;
            }
        }
    }
    
    //--- Execute trade
    bool success = OrderSend(request, result);
    
    //--- Send response
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"success\":%s,\"ticket\":%d,\"retcode\":%d,\"comment\":\"%s\"}",
        requestId,
        success ? "true" : "false",
        result.deal,
        result.retcode,
        result.comment
    );
    
    SendMessage(MSG_COMMAND_RESP, response);
}

//+------------------------------------------------------------------+
//| Handle history/rates request from controller                       |
//+------------------------------------------------------------------+
void HandleHistoryCommand(const string &body)
{
    string symbol = JsonGetString(body, "symbol");
    string timeframe = JsonGetString(body, "timeframe");
    int count = (int)JsonGetLong(body, "count");
    long startTime = JsonGetLong(body, "start_time");
    long endTime = JsonGetLong(body, "end_time");
    int offset = (int)JsonGetLong(body, "offset");
    string requestId = JsonGetString(body, "request_id");
    
    if(symbol == "") symbol = _Symbol;
    if(count <= 0) count = 100;

    if(StringCompare(timeframe, "TICK", false) == 0)
    {
        MqlTick ticks[];
        int copied = 0;

        if(startTime > 0)
        {
            // Efficient path: fetch only what we need from the start timestamp.
            // CopyTicksRange over multi-year windows can block the EA thread.
            long fromMs = (long)startTime * 1000;
            int safeOffset = (offset > 0) ? offset : 0;
            int requested = count + safeOffset;
            if(requested <= 0)
                requested = count;

            copied = CopyTicks(symbol, ticks, COPY_TICKS_ALL, fromMs, requested);

            // If caller provided end_time, trim ticks beyond that bound.
            if(copied > 0 && endTime > 0)
            {
                long endMs = (long)endTime * 1000;
                int kept = 0;
                for(int k = 0; k < copied; k++)
                {
                    if((long)ticks[k].time_msc <= endMs)
                    {
                        ticks[kept] = ticks[k];
                        kept++;
                    }
                }
                copied = kept;
            }

            // Apply logical offset after fetch.
            if(copied > 0 && safeOffset > 0)
            {
                if(safeOffset >= copied)
                {
                    copied = 0;
                }
                else
                {
                    int shifted = copied - safeOffset;
                    for(int s = 0; s < shifted; s++)
                        ticks[s] = ticks[s + safeOffset];
                    copied = shifted;
                }
            }

            if(copied > count)
                copied = count;
        }
        else
        {
            copied = CopyTicks(symbol, ticks, COPY_TICKS_ALL, offset, count);
        }

        string ticksJson = "[";
        for(int i = 0; i < copied; i++)
        {
            if(i > 0) ticksJson += ",";
            ticksJson += StringFormat(
                "{\"time\":%d,\"bid\":%.5f,\"ask\":%.5f,\"last\":%.5f,\"volume\":%I64u,\"flags\":%d}",
                (int)ticks[i].time,
                ticks[i].bid,
                ticks[i].ask,
                ticks[i].last,
                ticks[i].volume,
                ticks[i].flags
            );
        }

        // Fallback: if broker/API doesn't provide tick history, synthesize one tick per bar.
        if(copied <= 0)
        {
            MqlRates rates[];
            int bars = CopyRates(symbol, PERIOD_M1, 0, count, rates);
            ticksJson = "[";
            for(int j = 0; j < bars; j++)
            {
                if(j > 0) ticksJson += ",";
                ticksJson += StringFormat(
                    "{\"time\":%d,\"bid\":%.5f,\"ask\":%.5f,\"last\":%.5f,\"volume\":%I64u,\"flags\":0}",
                    (int)rates[j].time,
                    rates[j].close,
                    rates[j].close,
                    rates[j].close,
                    rates[j].tick_volume
                );
            }
            copied = bars;
        }

        ticksJson += "]";
        string ticksResponse = StringFormat(
            "{\"request_id\":\"%s\",\"symbol\":\"%s\",\"count\":%d,\"ticks\":%s}",
            requestId, symbol, copied, ticksJson
        );
        SendMessage(MSG_COMMAND_RESP, ticksResponse);
        return;
    }
    
    //--- Determine timeframe
    ENUM_TIMEFRAMES tf = PERIOD_M1;
    if(timeframe == "M5") tf = PERIOD_M5;
    else if(timeframe == "M15") tf = PERIOD_M15;
    else if(timeframe == "H1") tf = PERIOD_H1;
    else if(timeframe == "H4") tf = PERIOD_H4;
    else if(timeframe == "D1") tf = PERIOD_D1;
    
    //--- Get rates
    MqlRates rates[];
    int copied = 0;
    if(startTime > 0 && endTime > 0)
    {
        copied = CopyRates(symbol, tf, (datetime)startTime, (datetime)endTime, rates);
        if(copied > count)
            copied = count;
    }
    else if(startTime > 0)
    {
        copied = CopyRates(symbol, tf, (datetime)startTime, count, rates);
    }
    else
    {
        copied = CopyRates(symbol, tf, offset, count, rates);
    }
    
    //--- Build response
    string ratesJson = "[";
    int added = 0;
    for(int i = 0; i < copied; i++)
    {
        int t = (int)rates[i].time;
        if(startTime > 0 && t < (int)startTime)
            continue;
        if(endTime > 0 && t > (int)endTime)
            continue;

        if(added > 0) ratesJson += ",";
        ratesJson += StringFormat(
            "{\"t\":%d,\"o\":%.5f,\"h\":%.5f,\"l\":%.5f,\"c\":%.5f,\"v\":%d}",
            t,
            rates[i].open,
            rates[i].high,
            rates[i].low,
            rates[i].close,
            rates[i].tick_volume
        );
        added++;
    }
    ratesJson += "]";
    
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"symbol\":\"%s\",\"timeframe\":\"%s\",\"rates\":%s}",
        requestId, symbol, timeframe, ratesJson
    );
    
    SendMessage(MSG_COMMAND_RESP, response);
}

//+------------------------------------------------------------------+
//| Send account info to controller                                    |
//+------------------------------------------------------------------+
void SendAccountInfo(string requestId = "")
{
    //--- Check broker connection status
    bool connected = (bool)TerminalInfoInteger(TERMINAL_CONNECTED);
    bool trade_allowed = (bool)AccountInfoInteger(ACCOUNT_TRADE_ALLOWED);
    
    string info = StringFormat(
        "{\"request_id\":\"%s\",\"login\":%d,\"balance\":%.2f,\"equity\":%.2f,\"margin\":%.2f,\"free_margin\":%.2f,\"margin_level\":%.2f,\"currency\":\"%s\",\"leverage\":%d,\"server\":\"%s\",\"connected\":%s,\"trade_allowed\":%s,\"company\":\"%s\"}",
        requestId,
        AccountInfoInteger(ACCOUNT_LOGIN),
        AccountInfoDouble(ACCOUNT_BALANCE),
        AccountInfoDouble(ACCOUNT_EQUITY),
        AccountInfoDouble(ACCOUNT_MARGIN),
        AccountInfoDouble(ACCOUNT_MARGIN_FREE),
        AccountInfoDouble(ACCOUNT_MARGIN_LEVEL),
        AccountInfoString(ACCOUNT_CURRENCY),
        AccountInfoInteger(ACCOUNT_LEVERAGE),
        AccountInfoString(ACCOUNT_SERVER),
        connected ? "true" : "false",
        trade_allowed ? "true" : "false",
        AccountInfoString(ACCOUNT_COMPANY)
    );
    
    SendMessage(MSG_ACCOUNT_INFO, info);
}

//+------------------------------------------------------------------+
//| Send open positions to controller                                  |
//+------------------------------------------------------------------+
void SendPositions(string requestId = "")
{
    string positions = "[";
    int total = PositionsTotal();
    int count = 0;
    
    for(int i = 0; i < total; i++)
    {
        ulong posTicket = PositionGetTicket(i);
        if(posTicket == 0) continue;
        
        if(count > 0) positions += ",";
        count++;
        
        positions += StringFormat(
            "{\"ticket\":%I64u,\"symbol\":\"%s\",\"type\":\"%s\",\"volume\":%.2f,\"open_price\":%.5f,\"current_price\":%.5f,\"profit\":%.2f,\"swap\":%.2f,\"magic\":%d}",
            posTicket,
            PositionGetString(POSITION_SYMBOL),
            PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY ? "buy" : "sell",
            PositionGetDouble(POSITION_VOLUME),
            PositionGetDouble(POSITION_PRICE_OPEN),
            PositionGetDouble(POSITION_PRICE_CURRENT),
            PositionGetDouble(POSITION_PROFIT),
            PositionGetDouble(POSITION_SWAP),
            PositionGetInteger(POSITION_MAGIC)
        );
    }
    positions += "]";
    
    string response = StringFormat("{\"request_id\":\"%s\",\"positions\":%s}", requestId, positions);
    SendMessage(MSG_POSITIONS, response);
}

//+------------------------------------------------------------------+
//| Handle pending order command (limit/stop/stop-limit)               |
//+------------------------------------------------------------------+
void HandlePendingOrderCommand(const string &body)
{
    string orderType = JsonGetString(body, "order_type");
    string symbol = JsonGetString(body, "symbol");
    double volume = JsonGetDouble(body, "volume");
    double price = JsonGetDouble(body, "price");
    double stopLimitPrice = JsonGetDouble(body, "stop_limit_price");
    double stopLoss = JsonGetDouble(body, "stop_loss");
    double takeProfit = JsonGetDouble(body, "take_profit");
    long expiration = JsonGetLong(body, "expiration");
    int magic = (int)JsonGetLong(body, "magic");
    string comment = JsonGetString(body, "comment");
    string requestId = JsonGetString(body, "request_id");
    
    if(symbol == "") symbol = _Symbol;
    if(comment == "") comment = "Farm Bridge";
    
    MqlTradeRequest request = {};
    MqlTradeResult result = {};
    
    request.action = TRADE_ACTION_PENDING;
    request.symbol = symbol;
    request.volume = volume;
    request.price = price;
    request.sl = stopLoss;
    request.tp = takeProfit;
    request.magic = magic;
    request.comment = comment;
    
    //--- Set order type
    if(orderType == "buy_limit")
        request.type = ORDER_TYPE_BUY_LIMIT;
    else if(orderType == "sell_limit")
        request.type = ORDER_TYPE_SELL_LIMIT;
    else if(orderType == "buy_stop")
        request.type = ORDER_TYPE_BUY_STOP;
    else if(orderType == "sell_stop")
        request.type = ORDER_TYPE_SELL_STOP;
    else if(orderType == "buy_stop_limit")
    {
        request.type = ORDER_TYPE_BUY_STOP_LIMIT;
        request.stoplimit = stopLimitPrice;
    }
    else if(orderType == "sell_stop_limit")
    {
        request.type = ORDER_TYPE_SELL_STOP_LIMIT;
        request.stoplimit = stopLimitPrice;
    }
    
    //--- Set expiration if specified
    if(expiration > 0)
    {
        request.type_time = ORDER_TIME_SPECIFIED;
        request.expiration = (datetime)expiration;
    }
    else
    {
        request.type_time = ORDER_TIME_GTC;
    }
    
    //--- Execute
    bool success = OrderSend(request, result);
    
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"success\":%s,\"ticket\":%d,\"retcode\":%d,\"comment\":\"%s\"}",
        requestId,
        success ? "true" : "false",
        result.order,
        result.retcode,
        result.comment
    );
    
    SendMessage(MSG_COMMAND_RESP, response);
}

//+------------------------------------------------------------------+
//| Handle modify position command (SL/TP)                             |
//+------------------------------------------------------------------+
void HandleModifyPositionCommand(const string &body)
{
    long ticket = JsonGetLong(body, "ticket");
    double stopLoss = JsonGetDouble(body, "stop_loss");
    double takeProfit = JsonGetDouble(body, "take_profit");
    double trailingStop = JsonGetDouble(body, "trailing_stop");
    string requestId = JsonGetString(body, "request_id");
    
    MqlTradeRequest request = {};
    MqlTradeResult result = {};
    bool success = false;
    
    if(PositionSelectByTicket(ticket))
    {
        request.action = TRADE_ACTION_SLTP;
        request.position = ticket;
        request.symbol = PositionGetString(POSITION_SYMBOL);
        
        //--- Use existing values if not specified
        if(stopLoss == 0) stopLoss = PositionGetDouble(POSITION_SL);
        if(takeProfit == 0) takeProfit = PositionGetDouble(POSITION_TP);
        
        request.sl = stopLoss;
        request.tp = takeProfit;
        
        success = OrderSend(request, result);
    }
    
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"success\":%s,\"ticket\":%d,\"retcode\":%d,\"comment\":\"%s\"}",
        requestId,
        success ? "true" : "false",
        result.deal,
        result.retcode,
        success ? "Position modified" : "Failed to modify position"
    );
    
    SendMessage(MSG_COMMAND_RESP, response);
}

//+------------------------------------------------------------------+
//| Handle modify pending order command                                |
//+------------------------------------------------------------------+
void HandleModifyOrderCommand(const string &body)
{
    long ticket = JsonGetLong(body, "ticket");
    double price = JsonGetDouble(body, "price");
    double stopLimitPrice = JsonGetDouble(body, "stop_limit_price");
    double stopLoss = JsonGetDouble(body, "stop_loss");
    double takeProfit = JsonGetDouble(body, "take_profit");
    long expiration = JsonGetLong(body, "expiration");
    string requestId = JsonGetString(body, "request_id");
    
    MqlTradeRequest request = {};
    MqlTradeResult result = {};
    bool success = false;
    
    if(OrderSelect(ticket))
    {
        request.action = TRADE_ACTION_MODIFY;
        request.order = ticket;
        
        //--- Use existing values if not specified
        if(price == 0) price = OrderGetDouble(ORDER_PRICE_OPEN);
        if(stopLoss == 0) stopLoss = OrderGetDouble(ORDER_SL);
        if(takeProfit == 0) takeProfit = OrderGetDouble(ORDER_TP);
        if(stopLimitPrice == 0) stopLimitPrice = OrderGetDouble(ORDER_PRICE_STOPLIMIT);
        
        request.price = price;
        request.stoplimit = stopLimitPrice;
        request.sl = stopLoss;
        request.tp = takeProfit;
        
        if(expiration > 0)
        {
            request.type_time = ORDER_TIME_SPECIFIED;
            request.expiration = (datetime)expiration;
        }
        else
        {
            request.type_time = (ENUM_ORDER_TYPE_TIME)OrderGetInteger(ORDER_TYPE_TIME);
            request.expiration = (datetime)OrderGetInteger(ORDER_TIME_EXPIRATION);
        }
        
        success = OrderSend(request, result);
    }
    
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"success\":%s,\"ticket\":%d,\"retcode\":%d,\"comment\":\"%s\"}",
        requestId,
        success ? "true" : "false",
        result.order,
        result.retcode,
        success ? "Order modified" : "Failed to modify order"
    );
    
    SendMessage(MSG_COMMAND_RESP, response);
}

//+------------------------------------------------------------------+
//| Handle cancel pending order command                                |
//+------------------------------------------------------------------+
void HandleCancelOrderCommand(const string &body)
{
    long ticket = JsonGetLong(body, "ticket");
    string requestId = JsonGetString(body, "request_id");
    
    MqlTradeRequest request = {};
    MqlTradeResult result = {};
    
    request.action = TRADE_ACTION_REMOVE;
    request.order = ticket;
    
    bool success = OrderSend(request, result);
    
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"success\":%s,\"ticket\":%d,\"retcode\":%d,\"comment\":\"%s\"}",
        requestId,
        success ? "true" : "false",
        result.order,
        result.retcode,
        success ? "Order cancelled" : result.comment
    );
    
    SendMessage(MSG_COMMAND_RESP, response);
}

//+------------------------------------------------------------------+
//| Handle partial position close command                              |
//+------------------------------------------------------------------+
void HandleClosePartialCommand(const string &body)
{
    long ticket = JsonGetLong(body, "ticket");
    double volume = JsonGetDouble(body, "volume");
    string requestId = JsonGetString(body, "request_id");
    
    MqlTradeRequest request = {};
    MqlTradeResult result = {};
    bool success = false;
    
    if(PositionSelectByTicket(ticket))
    {
        request.action = TRADE_ACTION_DEAL;
        request.position = ticket;
        request.symbol = PositionGetString(POSITION_SYMBOL);
        request.volume = volume;
        request.deviation = 20;
        
        //--- Opposite type to close
        if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
        {
            request.type = ORDER_TYPE_SELL;
            request.price = SymbolInfoDouble(request.symbol, SYMBOL_BID);
        }
        else
        {
            request.type = ORDER_TYPE_BUY;
            request.price = SymbolInfoDouble(request.symbol, SYMBOL_ASK);
        }
        
        success = OrderSend(request, result);
    }
    
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"success\":%s,\"ticket\":%d,\"retcode\":%d,\"comment\":\"%s\"}",
        requestId,
        success ? "true" : "false",
        result.deal,
        result.retcode,
        success ? "Partial close executed" : "Failed to close partial"
    );
    
    SendMessage(MSG_COMMAND_RESP, response);
}

//+------------------------------------------------------------------+
//| Handle close position by opposite command                          |
//+------------------------------------------------------------------+
void HandleCloseByCommand(const string &body)
{
    long ticket = JsonGetLong(body, "ticket");
    long oppositeTicket = JsonGetLong(body, "opposite_ticket");
    string requestId = JsonGetString(body, "request_id");
    
    MqlTradeRequest request = {};
    MqlTradeResult result = {};
    
    request.action = TRADE_ACTION_CLOSE_BY;
    request.position = ticket;
    request.position_by = oppositeTicket;
    
    bool success = OrderSend(request, result);
    
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"success\":%s,\"ticket\":%d,\"retcode\":%d,\"comment\":\"%s\"}",
        requestId,
        success ? "true" : "false",
        result.deal,
        result.retcode,
        success ? "Close by executed" : result.comment
    );
    
    SendMessage(MSG_COMMAND_RESP, response);
}

//+------------------------------------------------------------------+
//| Send pending orders to controller                                  |
//+------------------------------------------------------------------+
void SendPendingOrders(string requestId = "")
{
    string orders = "[";
    int total = OrdersTotal();
    int count = 0;
    
    for(int i = 0; i < total; i++)
    {
        ulong orderTicket = OrderGetTicket(i);
        if(orderTicket == 0) continue;
        
        if(count > 0) orders += ",";
        count++;
        
        string orderType = "";
        long type = OrderGetInteger(ORDER_TYPE);
        switch(type)
        {
            case ORDER_TYPE_BUY_LIMIT: orderType = "buy_limit"; break;
            case ORDER_TYPE_SELL_LIMIT: orderType = "sell_limit"; break;
            case ORDER_TYPE_BUY_STOP: orderType = "buy_stop"; break;
            case ORDER_TYPE_SELL_STOP: orderType = "sell_stop"; break;
            case ORDER_TYPE_BUY_STOP_LIMIT: orderType = "buy_stop_limit"; break;
            case ORDER_TYPE_SELL_STOP_LIMIT: orderType = "sell_stop_limit"; break;
            default: orderType = "unknown";
        }
        
        orders += StringFormat(
            "{\"ticket\":%I64u,\"symbol\":\"%s\",\"type\":\"%s\",\"volume\":%.2f,\"price\":%.5f,\"sl\":%.5f,\"tp\":%.5f,\"magic\":%d,\"comment\":\"%s\",\"expiration\":%d}",
            orderTicket,
            OrderGetString(ORDER_SYMBOL),
            orderType,
            OrderGetDouble(ORDER_VOLUME_CURRENT),
            OrderGetDouble(ORDER_PRICE_OPEN),
            OrderGetDouble(ORDER_SL),
            OrderGetDouble(ORDER_TP),
            OrderGetInteger(ORDER_MAGIC),
            OrderGetString(ORDER_COMMENT),
            (long)OrderGetInteger(ORDER_TIME_EXPIRATION)
        );
    }
    orders += "]";
    
    string response = StringFormat("{\"request_id\":\"%s\",\"orders\":%s}", requestId, orders);
    SendMessage(MSG_PENDING_ORDERS, response);
}

//+------------------------------------------------------------------+
//| Handle deal history request                                        |
//+------------------------------------------------------------------+
void HandleDealHistoryRequest(const string &body)
{
    long fromDate = JsonGetLong(body, "from_date");
    long toDate = JsonGetLong(body, "to_date");
    string requestId = JsonGetString(body, "request_id");
    
    //--- Default: last 24 hours
    datetime now = TimeCurrent();
    datetime from = (fromDate > 0) ? (datetime)fromDate : now - 86400;
    datetime to = (toDate > 0) ? (datetime)toDate : now;
    
    //--- Select history
    HistorySelect(from, to);
    
    string deals = "[";
    int total = HistoryDealsTotal();
    int count = 0;
    
    for(int i = 0; i < total && count < 500; i++)  // Limit to 500 deals
    {
        ulong dealTicket = HistoryDealGetTicket(i);
        if(dealTicket == 0) continue;
        
        if(count > 0) deals += ",";
        count++;
        
        string dealType = "";
        long type = HistoryDealGetInteger(dealTicket, DEAL_TYPE);
        switch(type)
        {
            case DEAL_TYPE_BUY: dealType = "buy"; break;
            case DEAL_TYPE_SELL: dealType = "sell"; break;
            case DEAL_TYPE_BALANCE: dealType = "balance"; break;
            default: dealType = "other";
        }
        
        string entry = "";
        long entryType = HistoryDealGetInteger(dealTicket, DEAL_ENTRY);
        switch(entryType)
        {
            case DEAL_ENTRY_IN: entry = "in"; break;
            case DEAL_ENTRY_OUT: entry = "out"; break;
            case DEAL_ENTRY_INOUT: entry = "inout"; break;
            default: entry = "unknown";
        }
        
        deals += StringFormat(
            "{\"ticket\":%I64u,\"order\":%I64u,\"position\":%I64u,\"symbol\":\"%s\",\"type\":\"%s\",\"entry\":\"%s\",\"volume\":%.2f,\"price\":%.5f,\"profit\":%.2f,\"commission\":%.2f,\"swap\":%.2f,\"magic\":%d,\"time\":%d}",
            dealTicket,
            HistoryDealGetInteger(dealTicket, DEAL_ORDER),
            HistoryDealGetInteger(dealTicket, DEAL_POSITION_ID),
            HistoryDealGetString(dealTicket, DEAL_SYMBOL),
            dealType,
            entry,
            HistoryDealGetDouble(dealTicket, DEAL_VOLUME),
            HistoryDealGetDouble(dealTicket, DEAL_PRICE),
            HistoryDealGetDouble(dealTicket, DEAL_PROFIT),
            HistoryDealGetDouble(dealTicket, DEAL_COMMISSION),
            HistoryDealGetDouble(dealTicket, DEAL_SWAP),
            HistoryDealGetInteger(dealTicket, DEAL_MAGIC),
            (long)HistoryDealGetInteger(dealTicket, DEAL_TIME)
        );
    }
    deals += "]";
    
    string response = StringFormat("{\"request_id\":\"%s\",\"deals\":%s}", requestId, deals);
    SendMessage(MSG_DEAL_HISTORY, response);
}

//+------------------------------------------------------------------+
//| Handle symbol info request                                         |
//+------------------------------------------------------------------+
void HandleSymbolInfoRequest(const string &body)
{
    string symbol = JsonGetString(body, "symbol");
    string requestId = JsonGetString(body, "request_id");
    
    if(symbol == "") symbol = _Symbol;
    
    //--- Get symbol info
    MqlTick tick;
    SymbolInfoTick(symbol, tick);
    
    int tradeMode = 4; // Default: full access
    ENUM_SYMBOL_TRADE_MODE mode = (ENUM_SYMBOL_TRADE_MODE)SymbolInfoInteger(symbol, SYMBOL_TRADE_MODE);
    switch(mode)
    {
        case SYMBOL_TRADE_MODE_DISABLED: tradeMode = 0; break;
        case SYMBOL_TRADE_MODE_LONGONLY: tradeMode = 1; break;
        case SYMBOL_TRADE_MODE_SHORTONLY: tradeMode = 2; break;
        case SYMBOL_TRADE_MODE_CLOSEONLY: tradeMode = 3; break;
        case SYMBOL_TRADE_MODE_FULL: tradeMode = 4; break;
    }
    
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"symbol\":\"%s\",\"bid\":%.5f,\"ask\":%.5f,\"digits\":%d,\"point\":%.8f,\"spread\":%d,\"volume_min\":%.2f,\"volume_max\":%.2f,\"volume_step\":%.2f,\"trade_mode\":%d}",
        requestId,
        symbol,
        tick.bid,
        tick.ask,
        (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS),
        SymbolInfoDouble(symbol, SYMBOL_POINT),
        (int)SymbolInfoInteger(symbol, SYMBOL_SPREAD),
        SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN),
        SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX),
        SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP),
        tradeMode
    );
    
    SendMessage(MSG_SYMBOL_INFO, response);
}

//+------------------------------------------------------------------+
//| Handle current price request                                       |
//+------------------------------------------------------------------+
void HandleCurrentPriceRequest(const string &body)
{
    string symbol = JsonGetString(body, "symbol");
    string requestId = JsonGetString(body, "request_id");
    
    if(symbol == "") symbol = _Symbol;
    
    MqlTick tick;
    SymbolInfoTick(symbol, tick);
    
    string response = StringFormat(
        "{\"request_id\":\"%s\",\"symbol\":\"%s\",\"bid\":%.5f,\"ask\":%.5f,\"time\":%d}",
        requestId,
        symbol,
        tick.bid,
        tick.ask,
        (long)tick.time
    );
    
    SendMessage(MSG_CURRENT_PRICE, response);
}

//+------------------------------------------------------------------+
//| Simple JSON parser functions                                       |
//+------------------------------------------------------------------+
string JsonGetString(const string &json, const string &key)
{
    string search = "\"" + key + "\":\"";
    int start = StringFind(json, search);
    if(start < 0) return "";
    
    start += StringLen(search);
    int end = StringFind(json, "\"", start);
    if(end < 0) return "";
    
    return StringSubstr(json, start, end - start);
}

double JsonGetDouble(const string &json, const string &key)
{
    string search = "\"" + key + "\":";
    int start = StringFind(json, search);
    if(start < 0) return 0;
    
    start += StringLen(search);
    
    //--- Skip whitespace
    while(start < StringLen(json) && StringGetCharacter(json, start) == ' ')
        start++;
    
    //--- Find end of number
    int end = start;
    while(end < StringLen(json))
    {
        ushort c = StringGetCharacter(json, end);
        if(c != '-' && c != '.' && (c < '0' || c > '9'))
            break;
        end++;
    }
    
    return StringToDouble(StringSubstr(json, start, end - start));
}

long JsonGetLong(const string &json, const string &key)
{
    return (long)JsonGetDouble(json, key);
}
//+------------------------------------------------------------------+
