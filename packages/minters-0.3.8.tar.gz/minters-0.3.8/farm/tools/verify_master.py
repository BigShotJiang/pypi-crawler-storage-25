"""
Verify MT5_MASTER is properly configured for provisioning.

This tool checks:
1. Essential MT5 files exist (terminal64.exe, etc.)
2. MT5Bridge EA is compiled and present
3. No account-specific configuration exists
4. Broker data is present (Bases folder)
5. Config folder has proper structure

Usage:
    python -m farm.tools.verify_master
    python -m farm.tools.verify_master --master "C:/Custom/Path"
"""

import sys
from pathlib import Path
from typing import List, Tuple


def check_file_exists(path: Path, description: str) -> Tuple[bool, str]:
    """Check if a file exists."""
    if path.exists():
        size_kb = path.stat().st_size / 1024
        return True, f"✓ {description}: {path.name} ({size_kb:.1f} KB)"
    return False, f"✗ {description}: NOT FOUND"


def check_dir_exists(path: Path, description: str, required: bool = True) -> Tuple[bool, str]:
    """Check if a directory exists."""
    if path.exists():
        if path.is_dir():
            count = len(list(path.iterdir()))
            return True, f"✓ {description}: {count} items"
        return False, f"✗ {description}: exists but is not a directory"
    
    if required:
        return False, f"✗ {description}: NOT FOUND (required)"
    return True, f"⚠ {description}: not found (optional)"


def check_no_account_data(master_path: Path) -> List[Tuple[bool, str]]:
    """Check that no account-specific data exists."""
    results = []
    
    # Check common.ini doesn't have Login/Password (but file can exist for EA settings)
    common_ini = master_path / "Config" / "common.ini"
    if common_ini.exists():
        try:
            content = common_ini.read_text(encoding='utf-16-le', errors='ignore')
            has_login = 'Login=' in content and any(line.startswith('Login=') and line.split('=')[1].strip() for line in content.split('\n'))
            has_password = 'Password=' in content
            
            if has_login or has_password:
                results.append((False, f"✗ common.ini contains account credentials (Login/Password found)"))
            else:
                results.append((True, f"✓ common.ini exists but has no account credentials"))
        except Exception as e:
            results.append((False, f"✗ Could not read common.ini: {e}"))
    else:
        results.append((True, f"✓ common.ini: clean (will be created on first launch)"))
    
    # Files that should NOT exist in a clean master
    bad_files = [
        ("Config/accounts.dat", "Account auth data should not exist"),
        ("Config/accounts64.dat", "Account auth data should not exist"),
        ("MQL5/Files/pipe_id.txt", "Pipe ID should not exist in master"),
    ]
    
    for file_path, description in bad_files:
        full_path = master_path / file_path
        if full_path.exists():
            results.append((False, f"✗ {description}: {file_path} EXISTS (should be deleted)"))
        else:
            results.append((True, f"✓ {description}: clean"))
    
    return results


def verify_master(master_path: Path) -> bool:
    """
    Verify the MT5 master installation is ready for provisioning.
    
    Returns:
        True if master is valid, False otherwise
    """
    print("=" * 70)
    print(f"MT5 Master Verification")
    print(f"Path: {master_path}")
    print("=" * 70)
    print()
    
    all_checks = []
    
    # 1. Check master path exists
    print("1. Master Directory")
    print("-" * 70)
    if not master_path.exists():
        print(f"✗ Master path does not exist: {master_path}")
        return False
    print(f"✓ Master path exists: {master_path}")
    print()
    
    # 2. Check essential MT5 files
    print("2. Essential MT5 Files")
    print("-" * 70)
    essential_files = [
        (master_path / "terminal64.exe", "MT5 Terminal"),
        (master_path / "metaeditor64.exe", "MetaEditor"),
    ]
    
    for file_path, description in essential_files:
        success, message = check_file_exists(file_path, description)
        all_checks.append(success)
        print(message)
    print()
    
    # 3. Check MQL5 structure
    print("3. MQL5 Structure")
    print("-" * 70)
    mql5_dirs = [
        (master_path / "MQL5", "MQL5 root", True),
        (master_path / "MQL5" / "Experts", "Experts folder", True),
        (master_path / "MQL5" / "Include", "Include folder", False),
        (master_path / "MQL5" / "Libraries", "Libraries folder", False),
    ]
    
    for dir_path, description, required in mql5_dirs:
        success, message = check_dir_exists(dir_path, description, required)
        all_checks.append(success)
        print(message)
    
    # Check for MT5Bridge EA
    bridge_ea = master_path / "MQL5" / "Experts" / "MT5Bridge.ex5"
    success, message = check_file_exists(bridge_ea, "MT5Bridge EA (compiled)")
    all_checks.append(success)
    print(message)
    
    # Check for source file
    bridge_source = master_path / "MQL5" / "Experts" / "MT5Bridge.mq5"
    if bridge_source.exists():
        print(f"✓ MT5Bridge source: {bridge_source.name}")
    else:
        print(f"⚠ MT5Bridge source: not found (optional)")
    print()
    
    # 4. Check Config folder
    print("4. Configuration")
    print("-" * 70)
    config_dir = master_path / "Config"
    if config_dir.exists():
        print(f"✓ Config folder exists")
        
        # Check for servers.dat (broker server list)
        servers_dat = config_dir / "servers.dat"
        if servers_dat.exists():
            size_kb = servers_dat.stat().st_size / 1024
            print(f"✓ Broker server list: servers.dat ({size_kb:.1f} KB)")
        else:
            print(f"⚠ Broker server list: servers.dat not found")
            print(f"  → You'll need to add brokers manually in MT5")
    else:
        print(f"✓ Config folder: clean (will be created on first launch)")
    print()
    
    # 5. Check for account-specific data (should NOT exist)
    print("5. Account Data (should be clean)")
    print("-" * 70)
    account_checks = check_no_account_data(master_path)
    for success, message in account_checks:
        all_checks.append(success)
        print(message)
    print()
    
    # 6. Check for broker data
    print("6. Broker Data")
    print("-" * 70)
    bases_dir = master_path / "Bases"
    if bases_dir.exists():
        broker_folders = [d for d in bases_dir.iterdir() if d.is_dir()]
        if broker_folders:
            print(f"✓ Broker data found: {len(broker_folders)} broker(s)")
            for broker in broker_folders[:3]:  # Show first 3
                symbols_dir = broker / "symbols"
                if symbols_dir.exists():
                    symbol_count = len(list(symbols_dir.glob("*.dat")))
                    print(f"  - {broker.name}: {symbol_count} symbols")
            if len(broker_folders) > 3:
                print(f"  ... and {len(broker_folders) - 3} more")
        else:
            print(f"⚠ Bases folder exists but is empty")
            print(f"  → Launch MT5 and login to download broker data")
    else:
        print(f"⚠ Broker data: not found")
        print(f"  → Launch MT5 and login to download broker data")
    print()
    
    # 7. Summary
    print("=" * 70)
    print("Summary")
    print("=" * 70)
    
    passed = sum(all_checks)
    total = len(all_checks)
    
    print(f"Checks passed: {passed}/{total}")
    print()
    
    if all(all_checks):
        print("✓ MASTER IS READY FOR PROVISIONING")
        print()
        print("You can now provision accounts using:")
        print("  POST /farm/provision")
        print()
        return True
    else:
        print("✗ MASTER NEEDS CONFIGURATION")
        print()
        print("Recommended steps:")
        print("1. Run: farm/tools/clean_master.ps1 (if not already done)")
        print("2. Launch MT5: terminal64.exe")
        print("3. Configure Expert Advisors:")
        print("   - Tools → Options → Expert Advisors")
        print("   - ✅ Allow algorithmic trading")
        print("   - ✅ Allow DLL imports")
        print("   - Add '127.0.0.1' to allowed URLs")
        print("4. Add broker and login to download server data")
        print("5. Compile MT5Bridge.mq5 (F7 in MetaEditor)")
        print("6. Close MT5")
        print("7. Run this verification again")
        print()
        return False


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Verify MT5 master installation")
    parser.add_argument(
        "--master",
        type=str,
        default="C:/MT5_MASTER",
        help="Path to MT5 master installation"
    )
    
    args = parser.parse_args()
    master_path = Path(args.master)
    
    success = verify_master(master_path)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
