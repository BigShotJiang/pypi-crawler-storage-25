# Clean MT5_MASTER to create a pristine template
# This script removes all account-specific and runtime-generated files
# while preserving the MT5 binaries and MQL5 code

param(
    [string]$MasterPath = "C:\MT5_MASTER",
    [switch]$WhatIf = $false
)

Write-Host "=== MT5 Master Cleanup Script ===" -ForegroundColor Cyan
Write-Host "Target: $MasterPath" -ForegroundColor Yellow
Write-Host ""

if (-not (Test-Path $MasterPath)) {
    Write-Host "ERROR: Master path does not exist: $MasterPath" -ForegroundColor Red
    exit 1
}

# Check if MT5 is running from this directory
$mt5Process = Get-Process -Name "terminal64" -ErrorAction SilentlyContinue | Where-Object {
    $_.Path -and $_.Path.StartsWith($MasterPath, [System.StringComparison]::OrdinalIgnoreCase)
}

if ($mt5Process) {
    Write-Host "WARNING: MT5 is currently running from $MasterPath" -ForegroundColor Red
    Write-Host "Process ID: $($mt5Process.Id)" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Please close MT5 before running this script." -ForegroundColor Yellow
    Write-Host "Run: Stop-Process -Id $($mt5Process.Id) -Force" -ForegroundColor Cyan
    exit 1
}

Write-Host "Step 1: Identifying files to remove..." -ForegroundColor Green

# Files and folders to DELETE (account-specific and runtime data)
$itemsToDelete = @(
    # Configuration files with account data
    "Config\common.ini",
    "Config\terminal.ini",
    "Config\startup.ini",
    "Config\accounts.dat",
    "Config\accounts64.dat",
    
    # Broker server data (will be re-downloaded on first login)
    "Bases",
    
    # Profiles (charts, templates with account-specific settings)
    "Profiles",
    
    # Logs
    "logs",
    "Logs",
    
    # Temporary files
    "temp",
    
    # History files
    "History",
    
    # Tester data
    "Tester",
    
    # Cache
    "Cache",
    
    # MQL5 Files folder (runtime data, pipe_id.txt, etc.)
    "MQL5\Files"
)

# Files and folders to KEEP
$itemsToKeep = @(
    "terminal64.exe",
    "metaeditor64.exe",
    "*.dll",
    "MQL5\Experts",
    "MQL5\Indicators",
    "MQL5\Scripts",
    "MQL5\Include",
    "MQL5\Libraries",
    "Sounds"
)

Write-Host ""
Write-Host "Items that will be DELETED:" -ForegroundColor Yellow
foreach ($item in $itemsToDelete) {
    $fullPath = Join-Path $MasterPath $item
    if (Test-Path $fullPath) {
        Write-Host "  [X] $item" -ForegroundColor Red
    } else {
        Write-Host "  [ ] $item (not found)" -ForegroundColor DarkGray
    }
}

Write-Host ""
Write-Host "Items that will be PRESERVED:" -ForegroundColor Yellow
Write-Host "  [✓] terminal64.exe and other MT5 binaries" -ForegroundColor Green
Write-Host "  [✓] MQL5\Experts (including your MT5Bridge EA)" -ForegroundColor Green
Write-Host "  [✓] MQL5\Indicators, Scripts, Include, Libraries" -ForegroundColor Green
Write-Host "  [✓] Sounds" -ForegroundColor Green

Write-Host ""
if ($WhatIf) {
    Write-Host "=== DRY RUN MODE - No files will be deleted ===" -ForegroundColor Cyan
    exit 0
}

$confirmation = Read-Host "Proceed with cleanup? (yes/no)"
if ($confirmation -ne "yes") {
    Write-Host "Cleanup cancelled." -ForegroundColor Yellow
    exit 0
}

Write-Host ""
Write-Host "Step 2: Removing files..." -ForegroundColor Green

$deletedCount = 0
$errorCount = 0

foreach ($item in $itemsToDelete) {
    $fullPath = Join-Path $MasterPath $item
    if (Test-Path $fullPath) {
        try {
            Remove-Item -Path $fullPath -Recurse -Force -ErrorAction Stop
            Write-Host "  Deleted: $item" -ForegroundColor Green
            $deletedCount++
        } catch {
            Write-Host "  ERROR deleting $item : $_" -ForegroundColor Red
            $errorCount++
        }
    }
}

Write-Host ""
Write-Host "Step 3: Ensuring portable mode..." -ForegroundColor Green

# Create portable.dat to force MT5 to use local config
$portableFile = Join-Path $MasterPath "portable.dat"
if (-not (Test-Path $portableFile)) {
    New-Item -Path $portableFile -ItemType File -Force | Out-Null
    Write-Host "  Created: portable.dat (forces local config)" -ForegroundColor Green
} else {
    Write-Host "  Already exists: portable.dat" -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "=== Cleanup Complete ===" -ForegroundColor Cyan
Write-Host "Deleted: $deletedCount items" -ForegroundColor Green
Write-Host "Errors: $errorCount" -ForegroundColor $(if ($errorCount -gt 0) { "Red" } else { "Green" })

Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "1. Launch MT5 in PORTABLE mode:" -ForegroundColor Cyan
Write-Host "   .\tools\launch_master.ps1" -ForegroundColor White
Write-Host "   OR manually: $MasterPath\terminal64.exe /portable" -ForegroundColor DarkGray
Write-Host ""
Write-Host "2. Configure Expert Advisors settings:" -ForegroundColor Cyan
Write-Host "   - Tools → Options → Expert Advisors" -ForegroundColor White
Write-Host "   - ✅ Allow algorithmic trading" -ForegroundColor White
Write-Host "   - ✅ Allow DLL imports" -ForegroundColor White
Write-Host "   - Add '127.0.0.1' to allowed URLs" -ForegroundColor White
Write-Host "3. Add your broker(s) and login to download server data" -ForegroundColor Cyan
Write-Host "4. Open a chart and attach MT5Bridge EA to verify it works" -ForegroundColor Cyan
Write-Host "5. Close MT5 completely" -ForegroundColor Cyan
Write-Host "6. Now you can provision accounts from this clean MASTER" -ForegroundColor Cyan

Write-Host ""
Write-Host "To verify the MASTER is ready:" -ForegroundColor Yellow
Write-Host "  python -m farm.tools.verify_master" -ForegroundColor Cyan
