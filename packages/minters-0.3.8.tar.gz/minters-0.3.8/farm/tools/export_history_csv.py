"""
Warm up Farm history and export candles to CSV files.

This utility calls /farm/history in date chunks and writes one CSV per
account/symbol/timeframe using the naming format:

    {name}_{mm_dd_yy_to_mm_dd_yy}.csv

Example:
    python -m farm.tools.export_history_csv \
      --account sim \
      --symbol XAUUSDm \
      --timeframes H1,M15 \
      --start 2020-01-01 \
      --end 2024-01-01 \
      --name gold_dataset \
      --out contracts/gold
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple
from urllib.parse import urlencode
from urllib.request import urlopen


def _to_unix(value: str) -> int:
    value = value.strip()
    if value.isdigit():
        return int(value)
    if len(value) == 10 and value.count("-") == 2:
        dt = datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        return int(dt.timestamp())
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", value).strip("_") or "dataset"


def _range_label(start_ts: int, end_ts: int) -> str:
    s = datetime.fromtimestamp(start_ts, tz=timezone.utc).strftime("%m_%d_%y")
    e = datetime.fromtimestamp(end_ts, tz=timezone.utc).strftime("%m_%d_%y")
    return f"{s}_to_{e}"


def _next_period_boundary_ts(cursor_ts: int, split_by: str) -> int:
    dt = datetime.fromtimestamp(cursor_ts, tz=timezone.utc)
    if split_by == "month":
        year = dt.year + (1 if dt.month == 12 else 0)
        month = 1 if dt.month == 12 else dt.month + 1
        return int(datetime(year, month, 1, tzinfo=timezone.utc).timestamp())
    if split_by == "quarter":
        quarter = (dt.month - 1) // 3
        next_start_month = quarter * 3 + 4
        year = dt.year
        if next_start_month > 12:
            next_start_month -= 12
            year += 1
        return int(datetime(year, next_start_month, 1, tzinfo=timezone.utc).timestamp())
    raise ValueError("split_by must be one of: month, quarter")


def _split_windows(start_ts: int, end_ts: int, split_by: str) -> List[Tuple[int, int]]:
    windows: List[Tuple[int, int]] = []
    cursor = start_ts
    while cursor < end_ts:
        boundary = _next_period_boundary_ts(cursor, split_by)
        window_end = min(end_ts, boundary)
        if window_end <= cursor:
            break
        windows.append((cursor, window_end))
        cursor = window_end
    return windows


def _http_get_json(base_url: str, path: str, params: Dict[str, Any]) -> Dict[str, Any]:
    q = urlencode(params)
    url = f"{base_url.rstrip('/')}{path}?{q}" if q else f"{base_url.rstrip('/')}{path}"
    with urlopen(url, timeout=45) as resp:
        body = resp.read().decode("utf-8")
    return json.loads(body)


def _discover_accounts(base_url: str) -> List[str]:
    status = _http_get_json(base_url, "/farm/status", {})
    nodes = status.get("nodes", [])
    return sorted({str(n.get("account_id")) for n in nodes if n.get("account_id")})


def _normalize_rate(rate: Dict[str, Any], symbol: str, timeframe: str) -> Dict[str, Any]:
    return {
        "time": rate.get("time", rate.get("t")),
        "open": rate.get("open", rate.get("o")),
        "high": rate.get("high", rate.get("h")),
        "low": rate.get("low", rate.get("l")),
        "close": rate.get("close", rate.get("c")),
        "volume": rate.get("tick_volume", rate.get("volume", rate.get("v", 0))),
        "symbol": symbol,
        "timeframe": timeframe,
    }


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    headers = ["time", "open", "high", "low", "close", "volume", "symbol", "timeframe"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> None:
    parser = argparse.ArgumentParser(description="Warm Farm history and export candles to CSV")
    parser.add_argument("--api", default="http://127.0.0.1:8000", help="Farm API base URL")
    parser.add_argument("--account", action="append", default=[], help="Account id (repeatable)")
    parser.add_argument("--symbol", action="append", default=[], help="Symbol (repeatable)")
    parser.add_argument("--timeframes", default="H1", help="Comma-separated MT5 timeframes")
    parser.add_argument("--start", required=True, help="Start (unix or YYYY-MM-DD)")
    parser.add_argument("--end", required=True, help="End (unix or YYYY-MM-DD)")
    parser.add_argument("--chunk-days", type=int, default=30, help="Chunk size in days")
    parser.add_argument("--count", type=int, default=5000, help="Max bars per call")
    parser.add_argument("--pause-sec", type=float, default=0.1, help="Sleep between calls")
    parser.add_argument(
        "--split-by",
        choices=["none", "month", "quarter"],
        default="none",
        help="Write one file per month/quarter instead of one file for the full range",
    )
    parser.add_argument("--name", required=True, help="Base dataset name")
    parser.add_argument("--out", required=True, help="Output folder (e.g. contracts/gold)")

    args = parser.parse_args()
    start_ts = _to_unix(args.start)
    end_ts = _to_unix(args.end)
    if end_ts <= start_ts:
        raise SystemExit("--end must be greater than --start")

    out_dir = Path(args.out).resolve()
    accounts = [a.strip() for a in args.account if a.strip()] or _discover_accounts(args.api)
    symbols = [s.strip() for s in args.symbol if s.strip()] or ["XAUUSDm"]
    tfs = [t.strip().upper() for t in args.timeframes.split(",") if t.strip()]

    if not accounts:
        raise SystemExit("No accounts provided or discovered")
    if not tfs:
        raise SystemExit("No timeframes specified")

    chunk_sec = max(1, args.chunk_days) * 86400
    base = _safe_name(args.name)
    label = _range_label(start_ts, end_ts)
    split_mode = args.split_by.lower()
    windows = [(start_ts, end_ts)] if split_mode == "none" else _split_windows(start_ts, end_ts, split_mode)

    for account in accounts:
        for symbol in symbols:
            for tf in tfs:
                for window_start, window_stop in windows:
                    rows: List[Dict[str, Any]] = []
                    cursor = window_start
                    while cursor < window_stop:
                        window_end = min(window_stop, cursor + chunk_sec)
                        payload = _http_get_json(
                            args.api,
                            f"/farm/history/{account}",
                            {
                                "symbol": symbol,
                                "timeframe": tf,
                                "count": args.count,
                                "start_time": cursor,
                                "end_time": window_end,
                                "offset": 0,
                            },
                        )
                        rates = payload.get("rates", [])
                        rows.extend(_normalize_rate(r, symbol, tf) for r in rates)
                        print(f"[{account}] {symbol} {tf} {cursor}->{window_end}: {len(rates)}")
                        cursor = window_end
                        if args.pause_sec > 0:
                            time.sleep(args.pause_sec)

                    # De-duplicate by candle timestamp for clean output.
                    dedup: Dict[str, Dict[str, Any]] = {}
                    for row in rows:
                        dedup[str(row.get("time"))] = row
                    ordered = [dedup[k] for k in sorted(dedup.keys())]

                    range_tag = label if split_mode == "none" else _range_label(window_start, window_stop)
                    file_name = f"{base}_{range_tag}.csv"
                    # If multiple outputs in one run, include account/symbol/tf prefix.
                    if len(accounts) > 1 or len(symbols) > 1 or len(tfs) > 1:
                        file_name = (
                            f"{_safe_name(account)}_{_safe_name(symbol)}_"
                            f"{_safe_name(tf)}_{base}_{range_tag}.csv"
                        )

                    path = out_dir / file_name
                    _write_csv(path, ordered)
                    print(f"Wrote {len(ordered)} rows -> {path}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Interrupted")
        sys.exit(130)
