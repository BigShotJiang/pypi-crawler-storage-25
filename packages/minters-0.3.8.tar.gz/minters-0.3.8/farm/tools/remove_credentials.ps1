# Remove account credentials from MT5_MASTER while preserving settings
# This removes Login/Password from common.ini but keeps EA settings and broker data

param(
    [string]$MasterPath = "C:\MT5_MASTER"
)

Write-Host "=== Removing Account Credentials from MASTER ===" -ForegroundColor Cyan
Write-Host "Path: $MasterPath" -ForegroundColor Yellow
Write-Host ""

$configDir = Join-Path $MasterPath "Config"
if (-not (Test-Path $configDir)) {
    Write-Host "ERROR: Config folder not found: $configDir" -ForegroundColor Red
    exit 1
}

# 1. Remove accounts.dat (contains encrypted account tokens)
$accountsDat = Join-Path $configDir "accounts.dat"
if (Test-Path $accountsDat) {
    Remove-Item -Path $accountsDat -Force
    Write-Host "✓ Removed: accounts.dat" -ForegroundColor Green
} else {
    Write-Host "  accounts.dat not found (already clean)" -ForegroundColor DarkGray
}

# 2. Remove Login/Password from common.ini but keep EA settings
$commonIni = Join-Path $configDir "common.ini"
if (Test-Path $commonIni) {
    Write-Host "Processing common.ini..." -ForegroundColor Yellow
    
    try {
        # Read with UTF-16 LE encoding (MT5 standard)
        $content = Get-Content -Path $commonIni -Encoding Unicode -Raw
        
        # Remove Login line
        $content = $content -replace '(?m)^Login=.*\r?\n?', ''
        
        # Remove Password line
        $content = $content -replace '(?m)^Password=.*\r?\n?', ''
        
        # Remove Server line (will be set during provisioning)
        $content = $content -replace '(?m)^Server=.*\r?\n?', ''
        
        # Write back
        $content | Set-Content -Path $commonIni -Encoding Unicode -NoNewline
        
        Write-Host "✓ Removed Login/Password/Server from common.ini" -ForegroundColor Green
        Write-Host "  Preserved: EA settings, WebRequest URLs, other settings" -ForegroundColor Green
    } catch {
        Write-Host "ERROR processing common.ini: $_" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "  common.ini not found" -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "=== Cleanup Complete ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "MASTER is now ready for provisioning!" -ForegroundColor Green
Write-Host ""
Write-Host "What was preserved:" -ForegroundColor Yellow
Write-Host "  ✓ Broker data (Bases folder with symbols)" -ForegroundColor Green
Write-Host "  ✓ EA settings (Allow trading, DLL, WebRequest URLs)" -ForegroundColor Green
Write-Host "  ✓ Chart profiles (Default profile with BTCUSDm)" -ForegroundColor Green
Write-Host "  ✓ Broker server list (servers.dat)" -ForegroundColor Green
Write-Host ""
Write-Host "What was removed:" -ForegroundColor Yellow
Write-Host "  ✗ Login credentials" -ForegroundColor Red
Write-Host "  ✗ Account authentication tokens" -ForegroundColor Red
Write-Host ""
Write-Host "Verify MASTER is ready:" -ForegroundColor Cyan
Write-Host "  python tools\verify_master.py" -ForegroundColor White
