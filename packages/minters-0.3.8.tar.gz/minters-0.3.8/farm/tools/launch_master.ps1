# Launch MT5_MASTER in Portable Mode
# This ensures MT5 uses the local Config folder, not AppData

param(
    [string]$MasterPath = "C:\MT5_MASTER"
)

Write-Host "=== Launching MT5 Master in Portable Mode ===" -ForegroundColor Cyan
Write-Host "Path: $MasterPath" -ForegroundColor Yellow
Write-Host ""

if (-not (Test-Path $MasterPath)) {
    Write-Host "ERROR: Master path does not exist: $MasterPath" -ForegroundColor Red
    exit 1
}

$terminal = Join-Path $MasterPath "terminal64.exe"
if (-not (Test-Path $terminal)) {
    Write-Host "ERROR: terminal64.exe not found in $MasterPath" -ForegroundColor Red
    exit 1
}

# Ensure portable.dat exists (tells MT5 to use local config)
$portableFile = Join-Path $MasterPath "portable.dat"
if (-not (Test-Path $portableFile)) {
    Write-Host "Creating portable.dat file..." -ForegroundColor Yellow
    New-Item -Path $portableFile -ItemType File -Force | Out-Null
    Write-Host "✓ Created portable.dat" -ForegroundColor Green
}

Write-Host "Launching MT5 in PORTABLE mode..." -ForegroundColor Green
Write-Host "Command: $terminal /portable" -ForegroundColor Cyan
Write-Host ""
Write-Host "IMPORTANT:" -ForegroundColor Yellow
Write-Host "- MT5 will use LOCAL config: $MasterPath\Config\" -ForegroundColor White
Write-Host "- NOT global AppData config" -ForegroundColor White
Write-Host "- This is a FRESH instance with no account logged in" -ForegroundColor White
Write-Host ""

# Launch MT5 in portable mode
Start-Process -FilePath $terminal -ArgumentList "/portable" -WorkingDirectory $MasterPath

Write-Host "✓ MT5 launched successfully" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Yellow
Write-Host "1. Configure Expert Advisors (Tools → Options → Expert Advisors)" -ForegroundColor Cyan
Write-Host "   - ✅ Allow algorithmic trading" -ForegroundColor White
Write-Host "   - ✅ Allow DLL imports" -ForegroundColor White
Write-Host "   - Add '127.0.0.1' to allowed URLs" -ForegroundColor White
Write-Host "2. Add your broker (File → Open an Account → search broker → Cancel)" -ForegroundColor Cyan
Write-Host "3. (Optional) Login to download symbol data, then logout" -ForegroundColor Cyan
Write-Host "4. Close MT5 completely (File → Exit)" -ForegroundColor Cyan
Write-Host "5. Verify: python tools\verify_master.py" -ForegroundColor Cyan
