"""
Warm up broker history data through the Farm API.

This utility repeatedly calls /farm/history/{account_id} over time windows so
MT5 terminals request and cache historical candles from the broker.

Example:
    python -m farm.tools.warmup_history \
      --account sim \
      --symbol XAUUSDm \
      --timeframes H1,M15 \
      --start 2020-01-01 \
      --end 2024-01-01
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from typing import Any, Dict, List
from urllib.parse import urlencode
from urllib.request import urlopen


def _to_unix(value: str) -> int:
    """Parse unix timestamp or YYYY-MM-DD / ISO datetime into unix seconds."""
    value = value.strip()
    if value.isdigit():
        return int(value)

    if len(value) == 10 and value.count("-") == 2:
        dt = datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        return int(dt.timestamp())

    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def _http_get_json(base_url: str, path: str, params: Dict[str, Any]) -> Dict[str, Any]:
    query = urlencode(params)
    url = f"{base_url.rstrip('/')}{path}?{query}" if query else f"{base_url.rstrip('/')}{path}"
    with urlopen(url, timeout=45) as resp:
        data = resp.read().decode("utf-8")
    return json.loads(data)


def _discover_accounts(base_url: str) -> List[str]:
    status = _http_get_json(base_url, "/farm/status", {})
    nodes = status.get("nodes", [])
    accounts: List[str] = []
    for node in nodes:
        account_id = node.get("account_id")
        if account_id:
            accounts.append(str(account_id))
    return sorted(set(accounts))


def warmup_history(
    base_url: str,
    account_id: str,
    symbol: str,
    timeframe: str,
    start_ts: int,
    end_ts: int,
    chunk_days: int,
    count: int,
    pause_sec: float,
) -> int:
    """Warm up one account/symbol/timeframe over [start_ts, end_ts] in chunks."""
    chunk_sec = max(1, chunk_days) * 86400
    total_rows = 0

    cursor = start_ts
    while cursor < end_ts:
        window_end = min(end_ts, cursor + chunk_sec)
        payload = _http_get_json(
            base_url,
            f"/farm/history/{account_id}",
            {
                "symbol": symbol,
                "timeframe": timeframe,
                "count": count,
                "start_time": cursor,
                "end_time": window_end,
                "offset": 0,
            },
        )
        got = int(payload.get("count", len(payload.get("rates", []))))
        total_rows += max(got, 0)

        start_str = datetime.fromtimestamp(cursor, tz=timezone.utc).strftime("%Y-%m-%d")
        end_str = datetime.fromtimestamp(window_end, tz=timezone.utc).strftime("%Y-%m-%d")
        print(
            f"[{account_id}] {symbol} {timeframe} {start_str} -> {end_str}: {got} candles"
        )

        cursor = window_end
        if pause_sec > 0:
            time.sleep(pause_sec)

    return total_rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Warm up Farm candle history for backtesting")
    parser.add_argument("--api", default="http://127.0.0.1:8000", help="Farm API base URL")
    parser.add_argument(
        "--account",
        action="append",
        default=[],
        help="Account id to warm up (repeatable). If omitted, all farm status accounts are used.",
    )
    parser.add_argument(
        "--symbol",
        action="append",
        default=[],
        help="Trading symbol (repeatable). Default: XAUUSDm",
    )
    parser.add_argument(
        "--timeframes",
        default="H1,M15,M5",
        help="Comma-separated MT5 timeframes (M1,M5,M15,M30,H1,H4,D1,...)",
    )
    parser.add_argument("--start", required=True, help="Start timestamp/date (unix or YYYY-MM-DD)")
    parser.add_argument("--end", required=True, help="End timestamp/date (unix or YYYY-MM-DD)")
    parser.add_argument("--chunk-days", type=int, default=30, help="Chunk size in days")
    parser.add_argument("--count", type=int, default=5000, help="Max bars per request")
    parser.add_argument("--pause-sec", type=float, default=0.1, help="Sleep between requests")

    args = parser.parse_args()

    start_ts = _to_unix(args.start)
    end_ts = _to_unix(args.end)
    if end_ts <= start_ts:
        raise SystemExit("--end must be greater than --start")

    timeframes = [tf.strip().upper() for tf in args.timeframes.split(",") if tf.strip()]
    symbols = [s.strip() for s in args.symbol if s.strip()]
    if not symbols:
        symbols = ["XAUUSDm"]
    if not symbols:
        raise SystemExit("No symbols specified")
    if not timeframes:
        raise SystemExit("No timeframes specified")

    accounts = [a.strip() for a in args.account if a.strip()]
    if not accounts:
        accounts = _discover_accounts(args.api)
        if not accounts:
            raise SystemExit("No accounts found from /farm/status")

    print("Warmup configuration")
    print(f"  API: {args.api}")
    print(f"  Accounts: {', '.join(accounts)}")
    print(f"  Symbols: {', '.join(symbols)}")
    print(f"  Timeframes: {', '.join(timeframes)}")
    print(f"  Start: {start_ts}")
    print(f"  End: {end_ts}")
    print(f"  Chunk days: {args.chunk_days}")
    print(f"  Count: {args.count}")
    print()

    total_calls = 0
    total_rows = 0

    for account_id in accounts:
        for symbol in symbols:
            for timeframe in timeframes:
                rows = warmup_history(
                    base_url=args.api,
                    account_id=account_id,
                    symbol=symbol,
                    timeframe=timeframe,
                    start_ts=start_ts,
                    end_ts=end_ts,
                    chunk_days=args.chunk_days,
                    count=args.count,
                    pause_sec=args.pause_sec,
                )
                total_rows += rows
                # Approximate calls for display (window count)
                total_calls += max(1, (end_ts - start_ts + (args.chunk_days * 86400 - 1)) // (args.chunk_days * 86400))

    print()
    print("Warmup complete")
    print(f"  Calls: {total_calls}")
    print(f"  Candles returned: {total_rows}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Interrupted")
        sys.exit(130)
