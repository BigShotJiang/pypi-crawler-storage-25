"""
Farm Tools - Utilities for managing the MT5 farm.

Tools:
- verify_master: Verify MT5_MASTER is properly configured
- warmup_history: Request historical candles over date ranges to warm MT5 cache
- export_history_csv: Warm history and export CSV datasets for backtesting
- clean_master.ps1: PowerShell script to clean MT5_MASTER
"""
