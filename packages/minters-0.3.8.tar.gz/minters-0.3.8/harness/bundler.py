"""
harness/bundler.py — Contract Runner
=====================================

Discovers every ``*Contract`` class inside any ``.py`` file under
``contracts/``, spawns each in its own subprocess via ``harness/_runner.py``,
and streams their output to the console (human-readable) and the telemetry bus.

Contract authoring — no boilerplate required
--------------------------------------------
The quant creates any ``.py`` file under ``contracts/`` and defines a class
whose name ends in ``Contract``.  The class must have an ``async def run``
method that contains the strategy loop.

    # contracts/wheat/strategy.py
    import asyncio
    from harness import get_historical_ohlc, market_buy

    class WheatContract:
        async def run(self):
            while True:
                candles = await get_historical_ohlc("WHEAT", "1h", 30)
                # ... strategy logic ...
                await asyncio.sleep(60)

That is all.  No ``if __name__ == "__main__"`` block, no JSON logging
protocol, no framework-specific imports.  The bundler handles launching.

Environment variables
---------------------
CONTRACTS_DIR     Path to scan for contracts.  Default: ``contracts/``.
BUNDLER_SCAN_SEC  Seconds between discovery scans.  Default: 30.
BUNDLER_PYTHON    Python interpreter for contract processes.
                  Default: same interpreter as the bundler.
"""

from __future__ import annotations

import ast
import json
import logging
import os
import signal
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from harness.telemetry import get_bus as _get_telemetry_bus

# ---------------------------------------------------------------------------
# Logging — clean, single-line format with no redundant prefixes
# ---------------------------------------------------------------------------

class _CompactFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        ts  = time.strftime("%H:%M:%S", time.localtime(record.created))
        msg = record.getMessage()
        if record.levelno >= logging.WARNING:
            return f"{ts}  bundler  WARNING  {msg}"
        return f"{ts}  bundler  {msg}"

_handler = logging.StreamHandler(sys.stdout)
_handler.setFormatter(_CompactFormatter())

logger = logging.getLogger("bundler")
logger.addHandler(_handler)
logger.propagate = False
logger.setLevel(logging.INFO)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_HERE = Path(__file__).resolve().parent          # harness/
_ROOT = _HERE.parent                             # workspace root

CONTRACTS_DIR = Path(
    os.environ.get("CONTRACTS_DIR", str(_ROOT / "contracts"))
).resolve()

SCAN_INTERVAL = int(os.environ.get("BUNDLER_SCAN_SEC", "10"))
PYTHON_BIN    = os.environ.get("BUNDLER_PYTHON", sys.executable)
_RUNNER       = str(_HERE / "_runner.py")        # absolute path to runner script

# ---------------------------------------------------------------------------
# Global state
# ---------------------------------------------------------------------------

# Map: (abs_path, class_name) → ContractWorker
_workers: Dict[Tuple[str, str], "ContractWorker"] = {}
_workers_lock = threading.Lock()
_shutdown_event = threading.Event()
_print_lock = threading.Lock()

# ---------------------------------------------------------------------------
# Output formatter — contract stdout → human-readable lines
# ---------------------------------------------------------------------------

_SKIP_FIELDS = {"timestamp", "level", "message", "contract"}


def _format_contract_line(name: str, raw: str) -> str:
    """Format a single line from a contract subprocess for console display."""
    raw = raw.rstrip()
    if not raw:
        return ""
    try:
        obj = json.loads(raw)
        ts_str = ""
        stamp  = obj.get("timestamp")
        if stamp:
            try:
                ts_str = datetime.fromisoformat(stamp).strftime("%H:%M:%S") + "  "
            except ValueError:
                pass
        level   = f"{obj.get('level', 'INFO'):<7}"
        message = obj.get("message", "")
        extras  = {
            k: v for k, v in obj.items()
            if k not in _SKIP_FIELDS and v is not None
        }
        extra_str = "  ".join(f"{k}={v}" for k, v in extras.items())
        line = f"{ts_str}{name:<18}  {level}  {message}"
        return line + (f"  {extra_str}" if extra_str else "")
    except (json.JSONDecodeError, ValueError):
        return f"{name}  {raw}"


# ---------------------------------------------------------------------------
# Discovery — AST-based, no import required
# ---------------------------------------------------------------------------

def _find_contract_classes(py_file: Path) -> List[str]:
    """Return names of classes ending in 'Contract' found in py_file via AST."""
    try:
        tree = ast.parse(py_file.read_text(encoding="utf-8"))
    except (SyntaxError, OSError):
        return []
    return [
        node.name
        for node in ast.walk(tree)
        if isinstance(node, ast.ClassDef) and node.name.endswith("Contract")
    ]


def discover_contracts() -> List[Tuple[str, str]]:
    """
    Scan ``CONTRACTS_DIR`` recursively and return a sorted list of
    ``(abs_path, class_name)`` for every ``*Contract`` class found.
    """
    results: List[Tuple[str, str]] = []
    for py_file in sorted(CONTRACTS_DIR.rglob("*.py")):
        for class_name in _find_contract_classes(py_file):
            results.append((str(py_file), class_name))
    return results


# ---------------------------------------------------------------------------
# ContractWorker — one process + one reader thread per *Contract class
# ---------------------------------------------------------------------------

class ContractWorker:
    """Manages a single *Contract class running as a subprocess."""

    def __init__(self, path: str, class_name: str) -> None:
        self.path       = path
        self.class_name = class_name
        # Display name: strip "Contract" suffix for brevity
        self.name = class_name[:-8] if class_name.endswith("Contract") else class_name
        self._process: Optional[subprocess.Popen] = None          # type: ignore[type-arg]
        self._reader_thread: Optional[threading.Thread] = None
        self._stopped = False

    def start(self) -> None:
        if self._stopped:
            return
        env = {**os.environ, "MINT_WORKSPACE": str(_ROOT)}
        self._process = subprocess.Popen(
            [PYTHON_BIN, _RUNNER, self.path, self.class_name],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=env,
        )
        self._reader_thread = threading.Thread(
            target=self._sweep_output,
            name=f"reader-{self.name}",
            daemon=True,
        )
        self._reader_thread.start()

    def _sweep_output(self) -> None:
        assert self._process is not None
        assert self._process.stdout is not None
        bus = _get_telemetry_bus()
        try:
            for line in self._process.stdout:
                formatted = _format_contract_line(self.name, line)
                if formatted:
                    with _print_lock:
                        print(formatted, flush=True)
                bus.push_line(self.name, line)
        except ValueError:
            pass  # pipe closed on shutdown
        finally:
            rc = self._process.wait()
            if not self._stopped:
                logger.warning(f"{self.name} exited (code {rc}) — restarting on next scan")
                self._process = None

    def is_alive(self) -> bool:
        return self._process is not None and self._process.poll() is None

    def stop(self) -> None:
        self._stopped = True
        if self._process and self._process.poll() is None:
            try:
                self._process.terminate()
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
        if self._reader_thread and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=3)

    def restart(self) -> None:
        self._stopped = False
        if self.is_alive():
            self.stop()
        self.start()


# ---------------------------------------------------------------------------
# Reconcile loop
# ---------------------------------------------------------------------------

def _rel(path: str) -> str:
    """Return a short relative path for display, falling back to the full path."""
    try:
        return str(Path(path).relative_to(_ROOT))
    except ValueError:
        return path


def _reconcile() -> None:
    found = set(discover_contracts())
    with _workers_lock:
        for key in found:
            path, class_name = key
            if key not in _workers:
                logger.info(f"+ {class_name}  ({_rel(path)})")
                w = ContractWorker(path, class_name)
                _workers[key] = w
                w.start()
            elif not _workers[key].is_alive():
                logger.info(f"~ {_workers[key].name}  restarting")
                _workers[key].restart()

        stale = set(_workers.keys()) - found
        for key in stale:
            logger.info(f"- {_workers[key].class_name}  (file removed)")
            _workers[key].stop()
            del _workers[key]


def _shutdown(signum=None, frame=None) -> None:
    logger.info("Shutting down — stopping all contracts ...")
    _shutdown_event.set()
    with _workers_lock:
        for w in list(_workers.values()):
            w.stop()
        _workers.clear()
    logger.info("All stopped.")
    sys.exit(0)


def run() -> None:
    signal.signal(signal.SIGINT,  _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    if not CONTRACTS_DIR.exists():
        logger.warning(f"Contracts directory not found: {CONTRACTS_DIR}")

    try:
        rel_dir = CONTRACTS_DIR.relative_to(_ROOT)
    except ValueError:
        rel_dir = CONTRACTS_DIR

    logger.info(f"Starting  dir={rel_dir}  scan={SCAN_INTERVAL}s")

    while not _shutdown_event.is_set():
        _reconcile()
        _shutdown_event.wait(timeout=SCAN_INTERVAL)

    _shutdown()


if __name__ == "__main__":
    run()
