"""
Terminal Service Schema - Aggregated
====================================
JSON schema definitions and tool mappings for complete MetaAPI trading terminal functionality.
Aggregates Account, Data, and Trade service schemas into a unified interface.
"""

from typing import Dict, Any, List, Optional
import datetime
import logging
import sys
import os

# Handle path for direct execution
# Add the directory containing 'services' to path (the 'family' directory)
services_parent = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../'))
if services_parent not in sys.path:
    sys.path.insert(0, services_parent)

# Import all sub-service schemas and their components using absolute imports
from harness.barn.account.schema import (
    AccountServiceManager, 
    all_account_tools, 
    all_account_implementations
)
from harness.barn.data.schema import (
    DataServiceManager, 
    all_data_tools, 
    all_data_implementations
)  
from harness.barn.trade.schema import (
    TradeServiceManager, 
    get_trade_service_manager
)

# Import core client for unified access
from harness.barn.core import MetaApiClient

logger = logging.getLogger(__name__)

# Import trade operations for direct access (use Farm-based, not MetaAPI)
try:
    from harness.barn.trade.farm_orders import FarmTradingOperations
    trade_operations_available = True
except ImportError:
    FarmTradingOperations = None
    trade_operations_available = False


class TerminalServiceManager:
    """
    Unified manager that aggregates Account, Data, and Trade services
    
    This class acts as the central hub that:
    1. Initializes and manages the core Farm client
    2. Provides unified access to all sub-services
    3. Maintains session history and status tracking
    4. Exposes a simple interface for external tools
    """
    
    def __init__(self):
        # Core Farm client management
        self.client_class = MetaApiClient
        self.client = None
        
        # Initialize sub-service managers (these contain all the real functionality)
        self.account_manager = AccountServiceManager()
        self.data_manager = DataServiceManager()
        self.trade_manager = get_trade_service_manager()
        
        # Initialize trading operations for direct access (Farm-based)
        if trade_operations_available and FarmTradingOperations is not None:
            self.trading_operations = FarmTradingOperations()
        else:
            self.trading_operations = None
        
        # Session tracking (minimal, as sub-services handle their own history)
        self.trading_history = []
        self.account_sessions = []
        
    async def initialize_client(self, user: Optional[dict] = None):
        """Initialize the core Farm client with optional user context for database-backed account resolution"""
        try:
            self.client = await self.client_class.get(user=user)
            return {
                "success": True,
                "message": "Farm client initialized successfully",
                "client_status": self.client.get_status() if self.client else None
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _ensure_client_ready(self, user: Optional[dict] = None):
        """Ensure client is initialized and ready"""
        if self.client is None:
            await self.initialize_client(user=user)
        if self.client and not self.client.is_synchronized:
            await self.client.ensure_synchronized()
        return self.client is not None
    
    def get_terminal_status(self):
        """Get comprehensive terminal service status"""
        client_status = self.client.get_status() if self.client else None
        
        return {
            "success": True,
            "status": {
                "service_name": "TerminalServiceManager",
                "client_initialized": self.client is not None,
                "client_status": client_status,
                "service_ready": True,
                "sub_services": {
                    "account": {
                        "available": True, 
                        "tools": len(all_account_tools),
                        "status": self.account_manager.get_account_status()
                    },
                    "data": {
                        "available": True, 
                        "tools": len(all_data_tools),
                        "status": self.data_manager.get_data_status()
                    },
                    "trade": {
                        "available": trade_operations_available, 
                        "tools": len(self.trade_manager.get_all_tools()) if trade_operations_available else 0,
                        "trading_operations_ready": self.trading_operations is not None
                    }
                },
                "aggregated_tools": {
                    "account_tools": len(all_account_tools),
                    "data_tools": len(all_data_tools),
                    "trade_tools": len(self.trade_manager.get_all_tools()) if trade_operations_available else 0,
                    "total_tools": len(all_account_tools) + len(all_data_tools) + 
                                  (len(self.trade_manager.get_all_tools()) if trade_operations_available else 0)
                }
            }
        }
    
    async def interactive_session(self):
        """Start interactive trading session with overview of capabilities"""
        try:
            print("TerminalServiceManager Interactive Session")
            print("Initializing client...")
            
            await self.initialize_client()
            
            print("\n=== Farm Trading Terminal ===")
            print("Client initialized successfully!")
            
            print(f"\nAvailable Services:")
            print(f"📊 Account Service: {len(all_account_tools)} tools")
            print(f"📈 Data Service: {len(all_data_tools)} tools") 
            print(f"💰 Trade Service: {len(self.trade_manager.get_all_tools()) if trade_operations_available else 0} tools")
            
            if self.trading_operations:
                print(f"\n🔧 Trading Operations Available:")
                print("  • Market orders (buy/sell)")
                print("  • Pending orders (limit/stop)")
                print("  • Stop-limit orders")
                print("  • Position management")
                print("  • Order management")
                
            print(f"\n🏦 Account Operations Available:")
            for tool_name in all_account_tools.keys():
                print(f"  • {tool_name}")
                
            print(f"\n📊 Data Operations Available:")
            for tool_name in all_data_tools.keys():
                print(f"  • {tool_name}")
                
            print("\n💡 Use the chat interface to execute trading commands!")
            print("   Examples:")
            print("   • 'Get my account balance'")
            print("   • 'Show EURUSD price data'")
            print("   • 'Place a market buy order for 0.1 lots of EURUSD'")
            
            return {"success": True, "message": "Interactive trading session initialized"}
        except Exception as e:
            return {"success": False, "error": str(e)}


# === SCHEMA AGGREGATION ===
# This is where we bring together all the individual service schemas
# without duplicating their functionality

# Prefixed tools from each service to avoid naming conflicts
terminal_aggregated_tools = {}
terminal_aggregated_implementations = {}

# Account service tools (prefixed with account_)
for tool_name, tool_schema in all_account_tools.items():
    prefixed_name = f"account_{tool_name}" 
    terminal_aggregated_tools[prefixed_name] = {
        **tool_schema,
        "name": prefixed_name,
        "service": "account"
    }

for tool_name, implementation in all_account_implementations.items():
    prefixed_name = f"account_{tool_name}"
    # Wrap implementation to use account_manager
    terminal_aggregated_implementations[prefixed_name] = lambda manager, impl=implementation: impl(manager.account_manager)

# Data service tools (prefixed with data_)
for tool_name, tool_schema in all_data_tools.items():
    prefixed_name = f"data_{tool_name}"
    terminal_aggregated_tools[prefixed_name] = {
        **tool_schema,
        "name": prefixed_name,
        "service": "data"
    }

for tool_name, implementation in all_data_implementations.items():
    prefixed_name = f"data_{tool_name}"
    # Wrap implementation to use data_manager
    terminal_aggregated_implementations[prefixed_name] = lambda manager, impl=implementation: impl(manager.data_manager)

# Trade service tools (prefixed with trade_)
if trade_operations_available:
    trade_tools_dict = get_trade_service_manager().get_all_tools()
    
    for category, tools in trade_tools_dict.items():
        for tool_name, tool_schema in tools.items():
            prefixed_name = f"trade_{tool_name}"
            
            # Convert trade schema to standardized format
            terminal_aggregated_tools[prefixed_name] = {
                "name": prefixed_name,
                "description": tool_schema["description"],
                "service": "trade",
                "category": category,
                "strict": True,
                "parameters": {
                    "type": "object",
                    "properties": {
                        param_name: {
                            "type": param_def["type"],
                            "description": param_def["description"],
                            **({"default": param_def.get("default")} if "default" in param_def else {})
                        } for param_name, param_def in tool_schema["parameters"].items()
                    },
                    "required": [
                        param_name for param_name, param_def in tool_schema["parameters"].items()
                        if param_def.get("required", False)
                    ],
                    "additionalProperties": False
                }
            }
            
            # Create implementation that uses trading_operations with auto-initialization
            if hasattr(FarmTradingOperations, tool_name):
                def create_trading_implementation(method_name):
                    """Create a trading implementation with persistent connection auto-initialization"""
                    def wrapper_function(manager):
                        """Return a function that takes arguments and executes the trade"""
                        async def trading_executor(user: Optional[dict] = None, **kwargs):
                            """Auto-initializing trading executor with persistent connection management"""
                            # Ensure client is initialized and connected before trading operations
                            try:
                                # Check if we need to initialize or reconnect
                                if (manager.client is None or 
                                    not manager.client.is_synchronized or 
                                    not manager.client._connection_active):
                                    
                                    logger.info(f"Auto-initializing/reconnecting Farm client for {method_name}")
                                    
                                    if manager.client is None:
                                        # First time initialization with user context
                                        init_result = await manager.initialize_client(user=user)
                                        if not init_result.get('success', False):
                                            return {
                                                "success": False,
                                                "error": f"Failed to initialize client: {init_result.get('error', 'Unknown error')}",
                                                "auto_init_attempted": True
                                            }
                                    else:
                                        # Reconnect if client exists but is not properly connected
                                        try:
                                            await manager.client.ensure_synchronized()
                                        except Exception as sync_error:
                                            logger.warning(f"Synchronization failed, attempting reconnect: {sync_error}")
                                            await manager.client.reconnect()
                                
                                # Execute the trading operation
                                method = getattr(manager.trading_operations, method_name)
                                # ✅ CRITICAL FIX: Pass user parameter to trading method for database account resolution
                                result = await method(user=user, **kwargs)
                                
                                # Add connection status to result
                                if isinstance(result, dict) and result.get("success"):
                                    result["connection_persistent"] = True
                                    # Safe access for _heartbeat_task (FarmClient doesn't have it)
                                    heartbeat_task = getattr(manager.client, '_heartbeat_task', None)
                                    result["heartbeat_active"] = heartbeat_task is not None and not heartbeat_task.done() if heartbeat_task else False
                                
                                return result
                                
                            except Exception as e:
                                logger.error(f"Trading operation {method_name} failed: {e}")
                                
                                # Enhanced connection issue detection and handling
                                connection_keywords = ["synchronize", "connection", "timeout", "disconnect", "packet queue"]
                                if any(keyword in str(e).lower() for keyword in connection_keywords):
                                    logger.info(f"Connection issue detected for {method_name}, attempting recovery...")
                                    try:
                                        # Try to reconnect the client
                                        if manager.client:
                                            await manager.client.reconnect()
                                        else:
                                            # Reinitialize if client is None
                                            await manager.initialize_client()
                                        
                                        # Retry the operation once after reconnect
                                        logger.info(f"Retrying {method_name} after connection recovery...")
                                        method = getattr(manager.trading_operations, method_name)
                                        # ✅ CRITICAL FIX: Pass user parameter to trading method on retry
                                        result = await method(user=user, **kwargs)
                                        
                                        # Mark as recovered
                                        if isinstance(result, dict) and result.get("success"):
                                            result["connection_recovered"] = True
                                            result["retry_after_reconnect"] = True
                                        
                                        return result
                                        
                                    except Exception as retry_error:
                                        logger.error(f"Retry after reconnect failed: {retry_error}")
                                        return {
                                            "success": False,
                                            "error": f"Trading failed after reconnect attempt: {str(retry_error)}",
                                            "method": method_name,
                                            "reconnect_attempted": True,
                                            "original_error": str(e)
                                        }
                                
                                return {
                                    "success": False,
                                    "error": str(e),
                                    "method": method_name,
                                    "suggestion": "Connection may have issues. Persistent connection will auto-retry."
                                }
                        
                        return trading_executor
                    return wrapper_function
                
                terminal_aggregated_implementations[prefixed_name] = create_trading_implementation(tool_name)
# Core terminal management tools (non-prefixed, terminal-specific)
core_terminal_tools = {
    "initialize_client": {
        "name": "initialize_client",
        "description": "Initialize the Farm trading client",
        "service": "terminal",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "additionalProperties": False
        }
    },
    "get_terminal_status": {
        "name": "get_terminal_status",
        "description": "Get comprehensive terminal service status",
        "service": "terminal",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "additionalProperties": False
        }
    },
    "interactive_session": {
        "name": "interactive_session",
        "description": "Start interactive trading session",
        "service": "terminal",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "additionalProperties": False
        }
    }
}

core_terminal_implementations = {
    "initialize_client": lambda manager: manager.initialize_client,
    "get_terminal_status": lambda manager: manager.get_terminal_status,
    "interactive_session": lambda manager: manager.interactive_session,
}

# Combine everything
all_terminal_tools = {
    **terminal_aggregated_tools,
    **core_terminal_tools
}

all_terminal_implementations = {
    **terminal_aggregated_implementations,
    **core_terminal_implementations
}

def main():
    """Test the aggregated terminal schema"""
    print("=== Aggregated Terminal Service Schema ===")
    
    manager = TerminalServiceManager()
    
    print(f"Total aggregated tools: {len(all_terminal_tools)}")
    print(f"  Account tools: {len([t for t in all_terminal_tools if t.startswith('account_')])}")
    print(f"  Data tools: {len([t for t in all_terminal_tools if t.startswith('data_')])}")
    print(f"  Trade tools: {len([t for t in all_terminal_tools if t.startswith('trade_')])}")
    print(f"  Core tools: {len([t for t in all_terminal_tools if not any(t.startswith(p) for p in ['account_', 'data_', 'trade_'])])}")
    
    print(f"\nServices ready:")
    print(f"  Account manager: ✓")
    print(f"  Data manager: ✓")
    print(f"  Trade manager: {'✓' if trade_operations_available else '✗'}")
    print(f"  Trading operations: {'✓' if manager.trading_operations else '✗'}")


if __name__ == "__main__":
    main()
