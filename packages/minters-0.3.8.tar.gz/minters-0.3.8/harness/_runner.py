"""harness/_runner.py — Contract subprocess launcher.

Invoked by the bundler for each discovered *Contract class:

    python /path/to/_runner.py <contract_file> <ClassName>

The bundler sets the MINT_WORKSPACE env var so the runner can add the
workspace root to sys.path and load the .env file before importing the
contract.  The contract module itself does NOT need any special boilerplate —
just define a class whose name ends in ``Contract`` with an ``async def run``
method.
"""
import asyncio
import importlib.util
import os
import sys
from pathlib import Path


def main() -> None:
    if len(sys.argv) < 3:
        sys.exit("Usage: _runner.py <contract_file> <ClassName>")

    file_path  = Path(sys.argv[1]).resolve()
    class_name = sys.argv[2]

    # -------------------------------------------------------------------------
    # Workspace path — bundler injects MINT_WORKSPACE; fall back to walking up
    # -------------------------------------------------------------------------
    workspace = Path(os.environ.get("MINT_WORKSPACE", ""))
    if not workspace or not workspace.is_dir():
        workspace = file_path.parent
        for _ in range(10):
            if (workspace / "harness").is_dir():
                break
            parent = workspace.parent
            if parent == workspace:
                break
            workspace = parent

    if str(workspace) not in sys.path:
        sys.path.insert(0, str(workspace))

    # -------------------------------------------------------------------------
    # Load environment variables before anything in the contract runs
    # -------------------------------------------------------------------------
    try:
        from dotenv import load_dotenv
        load_dotenv(workspace / ".env", override=False)
    except ImportError:
        pass

    # -------------------------------------------------------------------------
    # Import the contract file
    # -------------------------------------------------------------------------
    spec = importlib.util.spec_from_file_location("_contract_mod", file_path)
    if spec is None or spec.loader is None:
        sys.exit(f"[runner] Cannot load module from: {file_path}")

    mod = importlib.util.module_from_spec(spec)
    sys.modules["_contract_mod"] = mod
    spec.loader.exec_module(mod)  # type: ignore[union-attr]

    # -------------------------------------------------------------------------
    # Locate and run the Contract class
    # -------------------------------------------------------------------------
    cls = getattr(mod, class_name, None)
    if cls is None:
        sys.exit(f"[runner] Class '{class_name}' not found in {file_path}")

    try:
        asyncio.run(cls().run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
