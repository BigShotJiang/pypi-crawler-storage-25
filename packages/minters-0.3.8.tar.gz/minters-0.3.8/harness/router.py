"""
Terminal Service API Router
============================
FastAPI router exposing all terminal operations via REST API.
"""

import json

from fastapi import APIRouter, FastAPI, HTTPException, Query
from fastapi.responses import StreamingResponse
from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel

# Import terminal service operations
from harness.barn.account.creds import get_account_snapshot
from harness.barn.account.positions import get_open_positions, get_pending_orders
from harness.barn.data.quotes import get_historical_ohlc
from harness.barn.core.farm_client import FarmClient

router = APIRouter(prefix="/terminal", tags=["terminal"])

# Standalone FastAPI app that mounts the router — used by Modal (entry.py)
app = FastAPI(title="Minter Terminal Service")
app.include_router(router)


# ==================
# Request/Response Models
# ==================

class MarketOrderRequest(BaseModel):
    symbol: str
    order_type: str  # 'buy' or 'sell'
    volume: float
    stop_loss: Optional[float] = 0.0
    take_profit: Optional[float] = 0.0


class LimitOrderRequest(BaseModel):
    symbol: str
    order_type: str  # 'buy' or 'sell'
    volume: float
    price: float
    stop_loss: Optional[float] = 0.0
    take_profit: Optional[float] = 0.0


class ModifyPositionRequest(BaseModel):
    ticket: int
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None


# ==================
# Account Endpoints
# ==================

@router.get("/account/snapshot")
async def account_snapshot(account_id: Optional[str] = None):
    """Get comprehensive account snapshot."""
    try:
        user = {"id": "test-user"}
        if account_id:
            user["account_id"] = account_id
        
        snapshot = await get_account_snapshot(user=user)
        return {"success": True, "data": snapshot}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/account/positions")
async def account_positions(
    symbol: Optional[str] = None,
    account_id: Optional[str] = None
):
    """Get open positions."""
    try:
        user = {"id": "test-user"}
        if account_id:
            user["account_id"] = account_id
        
        positions = await get_open_positions(symbol=symbol, user=user)
        return {"success": True, "data": positions, "count": len(positions)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/account/orders")
async def account_orders(
    symbol: Optional[str] = None,
    order_type: Optional[str] = None,
    account_id: Optional[str] = None
):
    """Get pending orders."""
    try:
        user = {"id": "test-user"}
        if account_id:
            user["account_id"] = account_id
        
        orders = await get_pending_orders(symbol=symbol, order_type=order_type, user=user)
        return {"success": True, "data": orders, "count": len(orders)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================
# Market Data Endpoints
# ==================

@router.get("/data/price/{symbol}")
async def get_price(symbol: str, account_id: Optional[str] = None):
    """Get current price for symbol."""
    try:
        client = await FarmClient.get(account_id=account_id)
        price_data = await client.get_current_price(symbol)
        return {"success": True, "data": price_data}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/data/ohlc/{symbol}")
async def get_ohlc(
    symbol: str,
    timeframe: str = Query("1h", description="Timeframe: 1m, 5m, 15m, 30m, 1h, 4h, 1d"),
    limit: int = Query(100, ge=1, le=1000),
    account_id: Optional[str] = None
):
    """Get historical OHLC data."""
    try:
        user = {"id": "test-user"}
        if account_id:
            user["account_id"] = account_id
        
        candles = await get_historical_ohlc(symbol, timeframe, limit, user=user)
        return {"success": True, "data": candles, "count": len(candles)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/data/symbol/{symbol}")
async def get_symbol_info(symbol: str, account_id: Optional[str] = None):
    """Get symbol information."""
    try:
        client = await FarmClient.get(account_id=account_id)
        symbol_info = await client.get_symbol_info(symbol)
        return {"success": True, "data": symbol_info}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================
# Trade Execution Endpoints
# ==================

@router.post("/trade/market")
async def place_market_order(request: MarketOrderRequest, account_id: Optional[str] = None):
    """Place market order."""
    try:
        client = await FarmClient.get(account_id=account_id)
        result = await client.create_market_order(
            symbol=request.symbol,
            order_type=request.order_type,
            volume=request.volume,
            stop_loss=request.stop_loss,
            take_profit=request.take_profit
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/trade/limit")
async def place_limit_order(request: LimitOrderRequest, account_id: Optional[str] = None):
    """Place limit order."""
    try:
        client = await FarmClient.get(account_id=account_id)
        result = await client.create_limit_order(
            symbol=request.symbol,
            order_type=request.order_type,
            volume=request.volume,
            price=request.price,
            stop_loss=request.stop_loss,
            take_profit=request.take_profit
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/trade/stop")
async def place_stop_order(request: LimitOrderRequest, account_id: Optional[str] = None):
    """Place stop order."""
    try:
        client = await FarmClient.get(account_id=account_id)
        result = await client.create_stop_order(
            symbol=request.symbol,
            order_type=request.order_type,
            volume=request.volume,
            price=request.price,
            stop_loss=request.stop_loss,
            take_profit=request.take_profit
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/trade/modify")
async def modify_position(request: ModifyPositionRequest, account_id: Optional[str] = None):
    """Modify position SL/TP."""
    try:
        client = await FarmClient.get(account_id=account_id)
        result = await client.modify_position(
            ticket=request.ticket,
            stop_loss=request.stop_loss,
            take_profit=request.take_profit
        )
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/trade/position/{ticket}")
async def close_position(ticket: int, account_id: Optional[str] = None):
    """Close position by ticket."""
    try:
        client = await FarmClient.get(account_id=account_id)
        result = await client.close_position(ticket)
        return {"success": True, "data": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================
# Health Check
# ==================

@router.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "terminal",
        "timestamp": datetime.now().isoformat()
    }


# ==================
# Telemetry
# ==================

@router.get("/telemetry")
async def telemetry(
    stream: bool = Query(
        False,
        description=(
            "When true, opens a Server-Sent Events (SSE) stream and pushes each "
            "new log entry from running contracts as it arrives. "
            "When false (default), returns a JSON snapshot of the last N entries."
        ),
    )
):
    """
    Bundler telemetry endpoint.

    Each entry has the shape::

        {
            "timestamp": "2026-04-24T10:00:00.000000+00:00",
            "contract":  "eurusd_trend",
            "level":     "INFO",
            "message":   "Signal: BUY EURUSD @ 1.09500",
            "data":      { ...full parsed JSON from contract stdout... }
        }

    * ``stream=false`` — returns ``{"entries": [...], "count": N}`` immediately.
    * ``stream=true``  — SSE stream; first flushes buffered entries, then pushes
      new ones in real-time until the client disconnects.
    """
    from harness.telemetry import get_bus

    bus = get_bus()

    if not stream:
        entries = bus.snapshot()
        return {
            "entries":    entries,
            "count":      len(entries),
            "subscribers": bus.subscriber_count(),
            "timestamp":  datetime.now().isoformat(),
        }

    # -- SSE streaming mode --------------------------------------------------
    async def _event_stream():
        # Replay buffered history so new clients have context
        for entry in bus.snapshot():
            yield f"data: {json.dumps(entry)}\n\n"

        # Then stream live entries as they arrive
        async for entry in bus.stream():
            yield f"data: {json.dumps(entry)}\n\n"

    return StreamingResponse(
        _event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control":      "no-cache",
            "Connection":         "keep-alive",
            "X-Accel-Buffering":  "no",        # disable nginx buffering
        },
    )
