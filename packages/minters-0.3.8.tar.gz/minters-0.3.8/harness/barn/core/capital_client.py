"""
CapitalClient - Capital.com backend via Rust PyO3 bridge

This client exposes the same async interface used by FarmClient/FarmExtClient,
backed by the `nursery_capital_py` extension built with maturin.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:
    pass

logger = logging.getLogger(__name__)

_capital_client_pool: Dict[str, "CapitalClient"] = {}
_pool_lock = asyncio.Lock()


def _load_bridge_class():
    try:
        from nursery_capital_py import CapitalBridge

        return CapitalBridge
    except ImportError as exc:
        raise ImportError(
            "nursery_capital_py is not installed. Build it with: "
            "maturin develop --manifest-path harness/capital/Cargo.toml"
        ) from exc


class CapitalClient:
    """Async adapter around the Rust `CapitalBridge` PyO3 class."""

    def __init__(self, account_id: str, user_id: str = "unknown") -> None:
        self.account_id = account_id
        self.user_id = user_id
        self._bridge = _load_bridge_class()(None)
        self._connected = False
        self._synchronized = False

    @classmethod
    async def get(
        cls,
        account_id: Optional[str] = None,
        user: Optional[dict] = None,
    ) -> "CapitalClient":
        user_id = (user or {}).get("id", "unknown")
        resolved = account_id or os.getenv("CAPITAL_ACCOUNT_ID") or "capital-default"

        async with _pool_lock:
            if resolved in _capital_client_pool:
                return _capital_client_pool[resolved]

            client = cls(resolved, user_id)
            await client._init()
            _capital_client_pool[resolved] = client
            logger.info("[Capital] Created client for account key %s", resolved)
            return client

    async def _init(self) -> None:
        await self.ensure_synchronized()

    async def _call_json(self, method: str, *args):
        fn = getattr(self._bridge, method)
        raw = await asyncio.to_thread(fn, *args)
        if isinstance(raw, str):
            return json.loads(raw)
        return raw

    @staticmethod
    def _normalize_exec(result: Dict[str, Any]) -> Dict[str, Any]:
        success = bool(result.get("success", False))
        ticket = result.get("id")
        return {
            "success": success,
            "ticket": str(ticket) if ticket is not None else "",
            "retcode": 10009 if success else 10013,
            "message": result.get("message") or result.get("status") or "",
            "status": result.get("status"),
        }

    @property
    def is_synchronized(self) -> bool:
        return self._synchronized and self._connected

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def connection(self) -> Any:
        return self if self._connected else None

    async def ensure_synchronized(self) -> bool:
        snapshot = await self._call_json("account_snapshot_json")
        self._connected = bool(snapshot)
        self._synchronized = self._connected
        return self._synchronized

    async def get_account_information(self) -> dict:
        snapshot = await self._call_json("account_snapshot_json")
        return {
            "login": snapshot.get("login", ""),
            "server": snapshot.get("server", ""),
            "broker": snapshot.get("broker", "Capital.com"),
            "currency": snapshot.get("currency", "USD"),
            "leverage": int(float(snapshot.get("leverage", 1) or 1)),
            "balance": float(snapshot.get("balance", 0.0) or 0.0),
            "equity": float(snapshot.get("equity", 0.0) or 0.0),
            "margin": float(snapshot.get("margin", 0.0) or 0.0),
            "freeMargin": float(snapshot.get("free_margin", 0.0) or 0.0),
            "marginLevel": float(snapshot.get("margin_level", 0.0) or 0.0),
            "tradeAllowed": bool(snapshot.get("trade_allowed", True)),
        }

    async def get_account_info(self) -> dict:
        info = await self.get_account_information()
        return {
            "login": info.get("login"),
            "server": info.get("server"),
            "broker": info.get("broker"),
            "currency": info.get("currency"),
            "leverage": info.get("leverage"),
            "balance": info.get("balance"),
            "equity": info.get("equity"),
            "margin": info.get("margin"),
            "free_margin": info.get("freeMargin"),
            "margin_level": info.get("marginLevel"),
            "trade_allowed": info.get("tradeAllowed"),
        }

    async def get_positions(self) -> List[dict]:
        positions = await self._call_json("positions_json", None)
        result = []
        for p in positions:
            result.append(
                {
                    "id": p.get("id", ""),
                    "symbol": p.get("symbol", ""),
                    "type": str(p.get("side", "")).lower(),
                    "volume": float(p.get("volume", 0.0) or 0.0),
                    "openPrice": float(p.get("open_price", 0.0) or 0.0),
                    "currentPrice": p.get("current_price"),
                    "unrealizedProfit": p.get("unrealized_profit"),
                    "stopLoss": p.get("stop_loss"),
                    "takeProfit": p.get("take_profit"),
                    "time": p.get("opened_at") or "",
                    "updateTime": p.get("updated_at") or "",
                    "raw": p.get("raw", {}),
                }
            )
        return result

    async def get_pending_orders(self) -> List[dict]:
        orders = await self._call_json("pending_orders_json", None)
        result = []
        for o in orders:
            side = str(o.get("side", "")).lower()
            otype = str(o.get("order_type", "")).lower()
            result.append(
                {
                    "id": o.get("id", ""),
                    "symbol": o.get("symbol", ""),
                    "type": f"{side}_{otype}" if side and otype else otype,
                    "state": o.get("status", "PENDING"),
                    "volume": float(o.get("volume", 0.0) or 0.0),
                    "openPrice": o.get("price"),
                    "currentPrice": o.get("current_price"),
                    "stopLoss": o.get("stop_loss"),
                    "takeProfit": o.get("take_profit"),
                    "time": o.get("created_at") or "",
                    "raw": o.get("raw", {}),
                }
            )
        return result

    async def _closed_orders_in_range(self, from_date: int = 0, to_date: int = 0) -> List[dict]:
        start_iso = (
            datetime.fromtimestamp(from_date, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
            if from_date
            else None
        )
        end_iso = (
            datetime.fromtimestamp(to_date, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
            if to_date
            else None
        )
        if start_iso or end_iso:
            return await self._call_json("closed_orders_range_json", start_iso, end_iso, "TRADE")
        return await self._call_json("closed_orders_json", 200)

    @staticmethod
    def _closed_to_deal(order: dict) -> dict:
        deal_time = order.get("closed_at") or order.get("opened_at") or ""
        return {
            "id": order.get("id", ""),
            "orderId": order.get("id", ""),
            "positionId": order.get("id", ""),
            "symbol": order.get("symbol", ""),
            "type": str(order.get("side", "")).lower(),
            "volume": float(order.get("volume", 0.0) or 0.0),
            "price": float(order.get("close_price") or order.get("open_price") or 0.0),
            "profit": order.get("profit"),
            "commission": order.get("commission"),
            "swap": order.get("swap"),
            "time": deal_time,
            "comment": "",
            "raw": order.get("raw", {}),
        }

    async def get_deal_history(self, from_date: int = 0, to_date: int = 0) -> List[dict]:
        orders = await self._closed_orders_in_range(from_date, to_date)
        return [self._closed_to_deal(o) for o in orders]

    async def get_deals_by_ticket(self, ticket: str) -> List[dict]:
        deals = await self.get_deal_history()
        return [d for d in deals if str(d.get("id")) == str(ticket)]

    async def get_deals_by_position(self, position_id: str) -> List[dict]:
        deals = await self.get_deal_history()
        return [d for d in deals if str(d.get("positionId")) == str(position_id)]

    async def get_deals_by_time_range(self, start_time, end_time=None) -> List[dict]:
        start_ts = int(start_time.timestamp()) if hasattr(start_time, "timestamp") else int(start_time)
        end_ts = (
            int(end_time.timestamp()) if hasattr(end_time, "timestamp") else int(end_time)
        ) if end_time is not None else 0
        return await self.get_deal_history(start_ts, end_ts)

    async def get_history_orders_by_ticket(self, ticket: str) -> List[dict]:
        orders = await self._call_json("closed_orders_json", 200)
        return [o for o in orders if str(o.get("id")) == str(ticket)]

    async def get_history_orders_by_position(self, position_id: str) -> List[dict]:
        orders = await self._call_json("closed_orders_json", 200)
        return [o for o in orders if str(o.get("id")) == str(position_id)]

    async def get_history_orders_by_time_range(self, start_time, end_time=None) -> List[dict]:
        start_ts = int(start_time.timestamp()) if hasattr(start_time, "timestamp") else int(start_time)
        end_ts = (
            int(end_time.timestamp()) if hasattr(end_time, "timestamp") else int(end_time)
        ) if end_time is not None else 0
        return await self._closed_orders_in_range(start_ts, end_ts)

    async def get_current_price(self, symbol: str) -> dict:
        quote = await self._call_json("current_price_json", symbol)
        return {
            "symbol": quote.get("symbol", symbol),
            "bid": float(quote.get("bid", 0.0) or 0.0),
            "ask": float(quote.get("ask", 0.0) or 0.0),
            "time": quote.get("time") or datetime.now(timezone.utc).isoformat(),
            "raw": quote.get("raw", {}),
        }

    async def get_symbol_price(self, symbol: str) -> dict:
        return await self.get_current_price(symbol)

    async def read_tick(self, symbol: str) -> dict:
        return await self.get_current_price(symbol)

    async def get_symbol_info(self, symbol: str) -> dict:
        return await self._call_json("market_details_json", symbol)

    async def get_symbols(self) -> List[str]:
        response = await self._call_json("search_markets_json", "USD")
        markets = response.get("markets", []) if isinstance(response, dict) else []
        symbols = []
        for market in markets:
            epic = market.get("epic")
            if epic:
                symbols.append(epic)
        return sorted(set(symbols))

    async def get_server_time(self) -> dict:
        return await self._call_json("server_time_json")

    async def get_historical_candles(
        self,
        symbol: str,
        timeframe: str,
        start_time=None,
        end_time=None,
        limit: int = 1000,
    ) -> List[dict]:
        if start_time is not None and end_time is not None:
            start_iso = (
                datetime.fromtimestamp(start_time, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
                if not hasattr(start_time, "strftime")
                else start_time.strftime("%Y-%m-%dT%H:%M:%S")
            )
            end_iso = (
                datetime.fromtimestamp(end_time, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
                if not hasattr(end_time, "strftime")
                else end_time.strftime("%Y-%m-%dT%H:%M:%S")
            )
            candles = await self._call_json(
                "historical_ohlc_range_json", symbol, timeframe, start_iso, end_iso
            )
        else:
            candles = await self._call_json("historical_ohlc_json", symbol, timeframe, int(limit))

        mapped = []
        for c in candles:
            mapped.append(
                {
                    "time": c.get("time", ""),
                    "open": float(c.get("open", 0.0) or 0.0),
                    "high": float(c.get("high", 0.0) or 0.0),
                    "low": float(c.get("low", 0.0) or 0.0),
                    "close": float(c.get("close", 0.0) or 0.0),
                    "tickVolume": float(c.get("volume", 0.0) or 0.0),
                    "volume": float(c.get("volume", 0.0) or 0.0),
                }
            )
        return mapped

    async def get_historical_ticks(
        self,
        symbol: str,
        start_time=None,
        end_time=None,
        offset: int = 0,
        limit: int = 100,
    ) -> List[dict]:
        candles = await self.get_historical_candles(
            symbol=symbol,
            timeframe="1m",
            start_time=start_time,
            end_time=end_time,
            limit=max(limit, 1),
        )
        return [
            {
                "symbol": symbol,
                "time": c.get("time"),
                "bid": c.get("close"),
                "ask": c.get("close"),
            }
            for c in candles[offset : offset + limit]
        ]

    async def read_candle(self, symbol: str, timeframe: str = "1m") -> Optional[dict]:
        candles = await self.get_historical_candles(symbol=symbol, timeframe=timeframe, limit=1)
        return candles[-1] if candles else None

    async def read_book(self, symbol: str) -> dict:
        return {"symbol": symbol, "bids": [], "asks": []}

    async def calculate_margin(self, order: dict) -> dict:
        symbol = order.get("symbol", "")
        size = float(order.get("volume", 0.0) or 0.0)
        details = await self.get_symbol_info(symbol)
        snapshot = details.get("snapshot", {}) if isinstance(details, dict) else {}
        instrument = details.get("instrument", {}) if isinstance(details, dict) else {}
        level = float(snapshot.get("offer") or snapshot.get("bid") or order.get("price") or 0.0)
        margin_factor = float(instrument.get("marginFactor") or 1.0)
        margin = abs(size * level * (margin_factor / 100.0))
        return {
            "margin": margin,
            "currency": instrument.get("currencies", ["USD"])[0] if isinstance(instrument.get("currencies"), list) else "USD",
        }

    async def market_buy(self, symbol: str, volume: float) -> Dict[str, Any]:
        result = await self._call_json("market_buy_json", symbol, volume, None, None)
        return self._normalize_exec(result)

    async def market_sell(self, symbol: str, volume: float) -> Dict[str, Any]:
        result = await self._call_json("market_sell_json", symbol, volume, None, None)
        return self._normalize_exec(result)

    async def buy_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        magic: int = 0,
        comment: str = "",
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "buy_limit_json",
            symbol,
            volume,
            price,
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
        )
        return self._normalize_exec(result)

    async def sell_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        magic: int = 0,
        comment: str = "",
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "sell_limit_json",
            symbol,
            volume,
            price,
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
        )
        return self._normalize_exec(result)

    async def buy_stop(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        magic: int = 0,
        comment: str = "",
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "buy_stop_json",
            symbol,
            volume,
            price,
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
        )
        return self._normalize_exec(result)

    async def sell_stop(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        magic: int = 0,
        comment: str = "",
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "sell_stop_json",
            symbol,
            volume,
            price,
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
        )
        return self._normalize_exec(result)

    async def buy_stop_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_limit_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        magic: int = 0,
        comment: str = "",
    ) -> Dict[str, Any]:
        return {
            "success": False,
            "ticket": "",
            "retcode": 10013,
            "message": "Capital bridge does not implement STOP_LIMIT orders",
        }

    async def sell_stop_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_limit_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        magic: int = 0,
        comment: str = "",
    ) -> Dict[str, Any]:
        return {
            "success": False,
            "ticket": "",
            "retcode": 10013,
            "message": "Capital bridge does not implement STOP_LIMIT orders",
        }

    async def modify_position(
        self,
        ticket,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        trailing_stop: float = 0.0,
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "modify_position_json",
            str(ticket),
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
        )
        return self._normalize_exec(result)

    async def close_position(self, ticket) -> Dict[str, Any]:
        result = await self._call_json("close_position_full_json", str(ticket))
        return self._normalize_exec(result)

    async def close_position_partial(self, ticket, volume: float) -> Dict[str, Any]:
        result = await self.close_position(ticket)
        if result.get("success"):
            result["message"] = "Capital bridge closed full position (partial close unsupported)"
        return result

    async def close_position_by(self, ticket, opposite_ticket) -> Dict[str, Any]:
        return {
            "success": False,
            "ticket": "",
            "retcode": 10013,
            "message": "Capital bridge does not implement close-by operation",
        }

    async def close_all_positions_by_symbol(self, symbol: str) -> Dict[str, Any]:
        positions = await self.get_positions()
        target = [p for p in positions if p.get("symbol") == symbol]
        results = []
        for pos in target:
            results.append(await self.close_position(pos.get("id")))
        return {
            "success": True,
            "symbol": symbol,
            "closed": sum(1 for r in results if r.get("success")),
            "total_positions": len(target),
            "results": results,
        }

    async def modify_order(
        self,
        ticket,
        price: float = 0.0,
        stop_limit_price: float = 0.0,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "modify_order_json",
            str(ticket),
            price,
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
        )
        return self._normalize_exec(result)

    async def cancel_order(self, ticket) -> Dict[str, Any]:
        result = await self._call_json("cancel_order_json", str(ticket))
        return self._normalize_exec(result)

    # ------------------------------------------------------------------
    # Extended execute — deal confirmation + GTD orders
    # ------------------------------------------------------------------

    async def confirm_deal(self, deal_reference: str) -> dict:
        return await self._call_json("confirm_deal_json", deal_reference)

    async def buy_limit_gtd(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        good_till_date: str = "",
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "buy_limit_gtd_json",
            symbol, volume, price,
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
            good_till_date if good_till_date else None,
        )
        return self._normalize_exec(result)

    async def sell_limit_gtd(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        good_till_date: str = "",
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "sell_limit_gtd_json",
            symbol, volume, price,
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
            good_till_date if good_till_date else None,
        )
        return self._normalize_exec(result)

    async def buy_stop_gtd(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        good_till_date: str = "",
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "buy_stop_gtd_json",
            symbol, volume, price,
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
            good_till_date if good_till_date else None,
        )
        return self._normalize_exec(result)

    async def sell_stop_gtd(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        good_till_date: str = "",
    ) -> Dict[str, Any]:
        result = await self._call_json(
            "sell_stop_gtd_json",
            symbol, volume, price,
            stop_loss if stop_loss else None,
            take_profit if take_profit else None,
            good_till_date if good_till_date else None,
        )
        return self._normalize_exec(result)

    # ------------------------------------------------------------------
    # Account — extended
    # ------------------------------------------------------------------

    async def get_account_preferences(self) -> dict:
        return await self._call_json("account_preferences_json")

    async def get_activity_history(self, last_secs: int = 600) -> dict:
        return await self._call_json("activity_history_json", last_secs)

    async def get_activity_range(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        detailed: bool = False,
    ) -> dict:
        return await self._call_json("activity_history_range_json", from_date, to_date, detailed, None)

    async def get_position_by_id(self, deal_id: str) -> dict:
        return await self._call_json("position_by_id_json", deal_id)

    async def top_up_demo(self, amount: float) -> dict:
        return await self._call_json("top_up_demo_json", amount)

    async def update_account_preferences(
        self,
        leverages: Optional[dict] = None,
        hedging_mode: Optional[bool] = None,
    ) -> dict:
        import json as _json
        leverages_json = _json.dumps(leverages) if leverages is not None else None
        return await self._call_json("update_account_preferences_json", leverages_json, hedging_mode)

    # ------------------------------------------------------------------
    # Data — extended: navigation, sentiment, watchlists
    # ------------------------------------------------------------------

    async def get_market_navigation(self) -> dict:
        return await self._call_json("market_navigation_json")

    async def get_market_navigation_node(self, node_id: str) -> dict:
        return await self._call_json("market_navigation_node_json", node_id)

    async def get_client_sentiment(self, market_id: str) -> dict:
        return await self._call_json("client_sentiment_json", market_id)

    async def get_client_sentiment_batch(self, market_ids: List[str]) -> dict:
        return await self._call_json("client_sentiment_batch_json", market_ids)

    async def get_watchlists(self) -> dict:
        return await self._call_json("watchlists_json")

    async def get_watchlist(self, watchlist_id: str) -> dict:
        return await self._call_json("watchlist_json", watchlist_id)

    async def create_watchlist(self, name: str, epics: Optional[List[str]] = None) -> dict:
        return await self._call_json("create_watchlist_json", name, epics or [])

    async def add_to_watchlist(self, watchlist_id: str, epic: str) -> dict:
        return await self._call_json("add_to_watchlist_json", watchlist_id, epic)

    async def delete_watchlist(self, watchlist_id: str) -> dict:
        return await self._call_json("delete_watchlist_json", watchlist_id)

    async def remove_from_watchlist(self, watchlist_id: str, epic: str) -> dict:
        return await self._call_json("remove_from_watchlist_json", watchlist_id, epic)

    async def search_markets(self, query: str) -> dict:
        return await self._call_json("search_markets_json", query)

    async def get_markets_by_epics(self, epics: List[str]) -> dict:
        return await self._call_json("markets_by_epics_json", epics)

    def get_status(self) -> Dict[str, Any]:
        return {
            "connected": self._connected,
            "synchronized": self._synchronized,
            "mode": "capital",
            "account_id": self.account_id,
        }

    async def close(self) -> None:
        self._connected = False
        self._synchronized = False
