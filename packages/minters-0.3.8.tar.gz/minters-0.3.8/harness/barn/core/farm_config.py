"""
Farm Configuration - Centralized farm connection settings

Provides intelligent fallback for farm connections:
1. FARM_HOST environment variable (explicit override)
2. VM external IP (34.52.189.86) - production
3. Localhost (127.0.0.1) - local development
"""

import os
import asyncio
import logging
from typing import Optional

# Load environment variables from .env file
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv not available, use system environment variables

logger = logging.getLogger(__name__)

# Farm connection settings
VM_EXTERNAL_IP = "34.52.189.86"  # Updated VM IP
LOCALHOST = "127.0.0.1"
FARM_PORT = int(os.environ.get("FARM_PORT", "8000"))


async def get_farm_url_with_fallback() -> str:
    """
    Get farm URL with intelligent fallback (async).
    
    Priority:
    1. FARM_HOST env var (explicit override)
    2. Try VM IP (if reachable via HTTP health check)
    3. Fallback to localhost
    
    Returns:
        str: Farm base URL (e.g., "http://34.77.187.212:8000")
    """
    # Priority 1: Explicit override
    if os.environ.get("FARM_HOST"):
        host = os.environ["FARM_HOST"]
        logger.info(f"[Farm Config] Using FARM_HOST from env: {host}")
        return f"http://{host}:{FARM_PORT}"
    
    # Priority 2: Try VM with HTTP health check
    vm_url = f"http://{VM_EXTERNAL_IP}:{FARM_PORT}"
    try:
        import httpx
        async with httpx.AsyncClient(timeout=2.0) as client:
            response = await client.get(f"{vm_url}/farm/status")
            if response.status_code == 200:
                logger.info(f"[Farm Config] [INFO] Connected to VM: {VM_EXTERNAL_IP}")
                return vm_url
    except Exception as e:
        logger.debug(f"[Farm Config] [ERROR] VM not reachable: {e}")
    
    # Priority 3: Localhost fallback
    localhost_url = f"http://{LOCALHOST}:{FARM_PORT}"
    logger.info(f"[Farm Config] [WARN] Falling back to localhost: {LOCALHOST}")
    return localhost_url


def get_farm_url_sync() -> str:
    """
    Get farm URL with intelligent fallback (sync).
    
    Uses socket check instead of HTTP for synchronous context.
    
    Priority:
    1. FARM_HOST env var (explicit override)
    2. Try VM IP (if port is open)
    3. Fallback to localhost
    
    Returns:
        str: Farm base URL (e.g., "http://34.77.187.212:8000")
    """
    # Priority 1: Explicit override
    if os.environ.get("FARM_HOST"):
        host = os.environ["FARM_HOST"]
        logger.info(f"[Farm Config] Using FARM_HOST from env: {host}")
        return f"http://{host}:{FARM_PORT}"
    
    # Priority 2: Try VM with socket check
    import socket
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1.0)
        result = sock.connect_ex((VM_EXTERNAL_IP, FARM_PORT))
        sock.close()
        if result == 0:
            logger.info(f"[Farm Config] [INFO] VM reachable: {VM_EXTERNAL_IP}")
            return f"http://{VM_EXTERNAL_IP}:{FARM_PORT}"
    except Exception as e:
        logger.debug(f"[Farm Config] [ERROR] Socket check failed: {e}")
    
    # Priority 3: Localhost fallback
    logger.info(f"[Farm Config] [INFO] Using localhost: {LOCALHOST}")
    return f"http://{LOCALHOST}:{FARM_PORT}"


def get_farm_base_url() -> str:
    """
    Get farm base URL with /farm prefix.
    
    Returns:
        str: Farm API base URL (e.g., "http://34.77.187.212:8000/farm")
    """
    return get_farm_url_sync() + "/farm"


# Module-level initialization
_FARM_BASE_URL = None

def get_cached_farm_url() -> str:
    """
    Get cached farm URL (computed once on first call).
    
    Returns:
        str: Cached farm base URL
    """
    global _FARM_BASE_URL
    if _FARM_BASE_URL is None:
        _FARM_BASE_URL = get_farm_base_url()
        logger.info(f"[Farm Config] Initialized farm URL: {_FARM_BASE_URL}")
    return _FARM_BASE_URL
