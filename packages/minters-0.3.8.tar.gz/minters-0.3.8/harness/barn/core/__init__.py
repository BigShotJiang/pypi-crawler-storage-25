"""
Terminal Core Module
===================
Core clients and utilities for trading terminal.

This module provides:
- FarmClient     : Self-hosted MT5 Farm Controller (primary backend).
- FarmExtClient  : MetaAPI cloud SDK wrapper (farm_ext backend).
- get_client()   : Dispatcher that picks the right backend via BROKER_MODE
                   env var (or FARM_EXT_ENABLED boolean flag).
- MetaApiClient  : Backward-compat alias for FarmClient.
- Data models    : AccountSnapshot, Position, Order, Deal, Candle.
- Utilities      : Symbol normalisation, timeframe validation.

Mode selection
--------------
Set the environment variable before running:

    BROKER_MODE=farm        # default — self-hosted farm
    BROKER_MODE=farm_ext    # MetaAPI cloud
    BROKER_MODE=auto        # try farm_ext, fall back to farm

    FARM_EXT_ENABLED=true   # shorthand for BROKER_MODE=farm_ext
    FARM_EXT_ENABLED=false  # shorthand for BROKER_MODE=farm
"""

from .farm_client import FarmClient, get_terminal_state
from .farm_ext_client import FarmExtClient
from .capital_client import CapitalClient
from .dispatcher import get_client, get_broker_mode, is_farm_ext_enabled

# Backward-compat alias — code that still uses MetaApiClient keeps working.
MetaApiClient = FarmClient

from .models import (
    AccountSnapshot, Position, Order, Deal, Candle,
    OrderType, OrderState, PositionType,
    convert_positions, convert_orders, convert_deals, convert_candles
)
from .utils import (
    normalize_symbol, validate_timeframe,
    safe_float_convert, parse_metaapi_time
)

__all__ = [
    # Client classes
    "FarmClient",
    "FarmExtClient",
    "CapitalClient",
    "MetaApiClient",       # backward compat
    "get_terminal_state",

    # Mode dispatcher
    "get_client",
    "get_broker_mode",
    "is_farm_ext_enabled",

    # Data models
    "AccountSnapshot",
    "Position",
    "Order",
    "Deal",
    "Candle",

    # Enums
    "OrderType",
    "OrderState",
    "PositionType",

    # Model converters
    "convert_positions",
    "convert_orders",
    "convert_deals",
    "convert_candles",

    # Utilities
    "normalize_symbol",
    "validate_timeframe",
    "safe_float_convert",
    "parse_metaapi_time",
]
