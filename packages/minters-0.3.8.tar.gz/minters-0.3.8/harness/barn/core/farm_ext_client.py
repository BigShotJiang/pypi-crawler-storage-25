"""
FarmExtClient  — MetaAPI Cloud SDK wrapper
==========================================

"farm_ext" is the cloud-hosted MetaTrader connector provided by
metaapi.cloud.  This module wraps the official Python SDK
(metaapi-cloud-sdk) and exposes the **same interface** as FarmClient
so the rest of harness is fully agnostic to which backend is active.

Environment variables
---------------------
METAAPI_TOKEN     — required.  Your MetaAPI cloud token.
METAAPI_ACCOUNT_ID — optional fallback account ID when no user context
                     is available.

Mode selection is handled by harness.core.dispatcher — do not import
this file directly; use dispatcher.get_client() instead.
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional SDK import — graceful degradation when not installed
# ---------------------------------------------------------------------------
try:
    from metaapi_cloud_sdk import MetaApi
    FARM_EXT_AVAILABLE = True
except ImportError:
    MetaApi = None  # type: ignore
    FARM_EXT_AVAILABLE = False
    logger.warning(
        "[farm_ext] metaapi-cloud-sdk not installed. "
        "Install with: pip install metaapi-cloud-sdk"
    )

# ---------------------------------------------------------------------------
# Module-level singletons (long-lived, per SDK best-practice)
# ---------------------------------------------------------------------------
_global_api: Optional[Any] = None
_global_api_lock = asyncio.Lock()

# Connection pool keyed by account_id
_pool: Dict[str, "FarmExtClient"] = {}
_pool_lock = asyncio.Lock()


# ---------------------------------------------------------------------------
# Account-ID resolution helpers
# ---------------------------------------------------------------------------

def _account_id_from_env() -> Optional[str]:
    return os.environ.get("METAAPI_ACCOUNT_ID")


def _account_id_from_user(user: Optional[dict]) -> Optional[str]:
    """Resolve account ID from a user dict via database lookup (optional)."""
    if not user or "id" not in user:
        return None
    try:
        from uuid import UUID
        from urllib.parse import unquote
        from lobster.utility.authentication.basedb import get_funds, get_profile_by_email

        uid_raw = user["id"]
        fid_raw = user.get("fund_id")
        uid = unquote(uid_raw)

        if "@" in uid:
            resp = get_profile_by_email(uid, use_service_role=True)
            if not (resp and resp.data):
                return None
            user_uuid = UUID(resp.data[0]["id"])
        else:
            user_uuid = UUID(uid)

        if fid_raw:
            fund_uuid = UUID(unquote(fid_raw))
            r = get_funds(user_id=user_uuid, fund_id=fund_uuid)
            if r and r.data:
                return str(r.data[0].get("account_id") or "")

        for is_default in (True, None):
            r = get_funds(user_id=user_uuid, **({} if is_default is None else {"is_default": True}))
            if r and r.data:
                acct = r.data[0].get("account_id")
                if acct:
                    return str(acct)
    except Exception as exc:
        logger.debug(f"[farm_ext] DB account resolution failed: {exc}")
    return None


# ---------------------------------------------------------------------------
# Main client
# ---------------------------------------------------------------------------

class FarmExtClient:
    """
    MetaAPI cloud client with the same interface as FarmClient.

    Uses the streaming connection (real-time, no RPC credits) for all
    live queries and the RPC connection only for operations that are
    not available via streaming (historical data, margin calc, etc.).
    """

    def __init__(
        self,
        api: Any,
        token: str,
        account_id: str,
        user_id: str = "unknown",
    ) -> None:
        self._api = api
        self.token = token
        self.account_id = account_id
        self.user_id = user_id

        self._account: Optional[Any] = None
        self._stream_conn: Optional[Any] = None   # streaming (real-time)
        self._rpc_conn: Optional[Any] = None       # RPC (for historical queries)
        self._connected = False
        self._synchronized = False
        self._connection_active = False
        self._heartbeat_task: Optional[asyncio.Task] = None

    # ------------------------------------------------------------------
    # Factory / pool
    # ------------------------------------------------------------------

    @classmethod
    async def get(
        cls,
        token: Optional[str] = None,
        account_id: Optional[str] = None,
        user: Optional[dict] = None,
    ) -> "FarmExtClient":
        if not FARM_EXT_AVAILABLE:
            raise ImportError(
                "metaapi-cloud-sdk is not installed. "
                "Run: pip install metaapi-cloud-sdk"
            )

        token = token or os.environ.get("METAAPI_TOKEN")
        if not token:
            raise ValueError("METAAPI_TOKEN env var or token parameter required")

        user_id = (user or {}).get("id", "unknown")

        # Resolve account_id
        resolved = (
            account_id
            or _account_id_from_user(user)
            or _account_id_from_env()
        )
        if not resolved:
            raise ValueError(
                "Cannot resolve account_id. Provide account_id, user dict, "
                "or set METAAPI_ACCOUNT_ID env var."
            )

        # Ensure singleton MetaApi instance
        global _global_api
        async with _global_api_lock:
            if _global_api is None:
                logger.info("[farm_ext] Creating global MetaApi SDK instance")
                _global_api = MetaApi(token)

        # Connection pool
        async with _pool_lock:
            if resolved in _pool:
                existing = _pool[resolved]
                if existing._connection_active and existing._stream_conn:
                    logger.info(f"[farm_ext] Reusing connection for {resolved}")
                    return existing
                # Dead connection — clean up
                try:
                    await existing.close()
                except Exception:
                    pass
                del _pool[resolved]

            inst = cls(_global_api, token, resolved, user_id)
            await inst._init()
            _pool[resolved] = inst
            return inst

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    async def _init(self) -> None:
        logger.info(f"[farm_ext] Initialising account {self.account_id}")

        self._account = await self._api.metatrader_account_api.get_account(
            self.account_id
        )

        if self._account.state != "DEPLOYED":
            logger.info("[farm_ext] Deploying account …")
            await asyncio.wait_for(self._account.deploy(), timeout=60)

        if self._account.connection_status != "CONNECTED":
            logger.info("[farm_ext] Waiting for broker connection …")
            await asyncio.wait_for(self._account.wait_connected(), timeout=60)

        # Streaming connection (real-time data, no CPU credits)
        self._stream_conn = self._account.get_streaming_connection()
        await asyncio.wait_for(self._stream_conn.connect(), timeout=30)

        # RPC connection (historical queries, margin calc)
        self._rpc_conn = self._account.get_rpc_connection()
        await asyncio.wait_for(self._rpc_conn.connect(), timeout=30)

        try:
            await asyncio.wait_for(self._stream_conn.wait_synchronized(), timeout=120)
            self._synchronized = True
        except asyncio.TimeoutError:
            logger.warning("[farm_ext] Sync timeout — continuing with partial state")
            self._synchronized = False

        self._connected = True
        self._connection_active = True
        self._heartbeat_task = asyncio.create_task(self._heartbeat())
        logger.info(f"[farm_ext] Ready — account {self.account_id}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _ts(self) -> Any:
        """Terminal state (streaming)."""
        return self._stream_conn.terminal_state if self._stream_conn else None

    @property
    def _hs(self) -> Any:
        """History storage (streaming)."""
        return self._stream_conn.history_storage if self._stream_conn else None

    async def ensure_synchronized(self) -> bool:
        if not self._connection_active or not self._stream_conn:
            await self._init()
        if not self._synchronized:
            try:
                await asyncio.wait_for(
                    self._stream_conn.wait_synchronized(), timeout=60
                )
                self._synchronized = True
            except asyncio.TimeoutError:
                logger.warning("[farm_ext] ensure_synchronized timeout")
        return self._synchronized

    async def _heartbeat(self) -> None:
        while self._connection_active:
            try:
                await asyncio.sleep(60)
                if self._ts is None:
                    logger.warning("[farm_ext] Heartbeat: no terminal state")
                    self._connection_active = False
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning(f"[farm_ext] Heartbeat error: {exc}")

    # Compatibility shims expected by the rest of harness
    @property
    def is_synchronized(self) -> bool:
        return self._synchronized and self._connection_active

    @property
    def is_connected(self) -> bool:
        return self._connected

    @property
    def connection(self) -> Any:
        return self if self._connected else None

    @property
    def account(self) -> Any:
        return self

    def get_terminal_state(self) -> Any:
        return self._ts

    # ------------------------------------------------------------------
    # Account information
    # ------------------------------------------------------------------

    async def get_account_information(self) -> dict:
        """Account balance, equity, margin, leverage, etc."""
        ts = self._ts
        info = ts.account_information if ts else {}
        if not info:
            # Fallback to RPC if streaming hasn't populated yet
            info = await self._rpc_conn.get_account_information()
        return {
            "login":       info.get("login"),
            "balance":     float(info.get("balance", 0)),
            "equity":      float(info.get("equity", 0)),
            "margin":      float(info.get("margin", 0)),
            "freeMargin":  float(info.get("freeMargin", 0)),
            "marginLevel": float(info.get("marginLevel") or 0),
            "currency":    info.get("currency", "USD"),
            "leverage":    int(info.get("leverage", 1)),
            "server":      info.get("server", ""),
            "broker":      info.get("broker", ""),
            "tradeAllowed": bool(info.get("tradeAllowed", True)),
        }

    # Alias kept for FarmClient compat
    async def get_account_info(self) -> dict:
        raw = await self.get_account_information()
        # FarmClient uses snake_case keys
        return {
            "login":        raw["login"],
            "balance":      raw["balance"],
            "equity":       raw["equity"],
            "margin":       raw["margin"],
            "free_margin":  raw["freeMargin"],
            "margin_level": raw["marginLevel"],
            "currency":     raw["currency"],
            "leverage":     raw["leverage"],
            "server":       raw["server"],
            "broker":       raw["broker"],
            "trade_allowed": raw["tradeAllowed"],
        }

    # ------------------------------------------------------------------
    # Positions
    # ------------------------------------------------------------------

    async def get_positions(self) -> List[dict]:
        """All open positions."""
        ts = self._ts
        if ts:
            return list(ts.positions)
        return await self._rpc_conn.get_positions()

    async def get_position(self, position_id: str) -> Optional[dict]:
        """Get a single open position by ID."""
        ts = self._ts
        if ts:
            for pos in ts.positions:
                if str(pos.get("id")) == str(position_id):
                    return pos
        return await self._rpc_conn.get_position(position_id)

    # ------------------------------------------------------------------
    # Pending orders
    # ------------------------------------------------------------------

    async def get_pending_orders(self) -> List[dict]:
        """All pending orders."""
        ts = self._ts
        if ts:
            return list(ts.orders)
        return await self._rpc_conn.get_orders()

    async def get_order(self, order_id: str) -> Optional[dict]:
        """Get a single pending order by ID."""
        ts = self._ts
        if ts:
            for o in ts.orders:
                if str(o.get("id")) == str(order_id):
                    return o
        return await self._rpc_conn.get_order(order_id)

    # ------------------------------------------------------------------
    # History orders
    # ------------------------------------------------------------------

    async def get_history_orders_by_ticket(self, ticket: str) -> List[dict]:
        """History orders filtered by ticket number."""
        hs = self._hs
        if hs:
            return list(hs.get_history_orders_by_ticket(ticket))
        return await self._rpc_conn.get_history_orders_by_ticket(ticket)

    async def get_history_orders_by_position(self, position_id: str) -> List[dict]:
        """History orders filtered by position ID."""
        hs = self._hs
        if hs:
            return list(hs.get_history_orders_by_position(position_id))
        return await self._rpc_conn.get_history_orders_by_position(position_id)

    async def get_history_orders_by_time_range(
        self,
        start_time: datetime,
        end_time: Optional[datetime] = None,
    ) -> List[dict]:
        """History orders in a time range."""
        end_time = end_time or datetime.now(timezone.utc)
        hs = self._hs
        if hs:
            return list(hs.get_history_orders_by_time_range(start_time, end_time))
        return await self._rpc_conn.get_history_orders_by_time_range(
            start_time, end_time
        )

    # ------------------------------------------------------------------
    # Deals
    # ------------------------------------------------------------------

    async def get_deals_by_ticket(self, ticket: str) -> List[dict]:
        """Deals filtered by ticket."""
        hs = self._hs
        if hs:
            return list(hs.get_deals_by_ticket(ticket))
        return await self._rpc_conn.get_deals_by_ticket(ticket)

    async def get_deals_by_position(self, position_id: str) -> List[dict]:
        """Deals filtered by position ID."""
        hs = self._hs
        if hs:
            return list(hs.get_deals_by_position(position_id))
        return await self._rpc_conn.get_deals_by_position(position_id)

    async def get_deals_by_time_range(
        self,
        start_time: datetime,
        end_time: Optional[datetime] = None,
    ) -> List[dict]:
        """Deals in a time range."""
        end_time = end_time or datetime.now(timezone.utc)
        hs = self._hs
        if hs:
            return list(hs.get_deals_by_time_range(start_time, end_time))
        return await self._rpc_conn.get_deals_by_time_range(start_time, end_time)

    # Legacy alias expected by history.py
    async def get_deal_history(
        self,
        from_date: int = 0,
        to_date: int = 0,
    ) -> List[dict]:
        from datetime import datetime
        start = datetime.fromtimestamp(from_date, tz=timezone.utc) if from_date else datetime.fromtimestamp(0, tz=timezone.utc)
        end = datetime.fromtimestamp(to_date, tz=timezone.utc) if to_date else datetime.now(timezone.utc)
        return await self.get_deals_by_time_range(start, end)

    # ------------------------------------------------------------------
    # Symbols / market data
    # ------------------------------------------------------------------

    async def get_symbols(self) -> List[str]:
        """All symbols available in this terminal."""
        ts = self._ts
        if ts and hasattr(ts, "specifications"):
            return [s.get("symbol") for s in ts.specifications]
        return await self._rpc_conn.get_symbols()

    async def get_symbol_info(self, symbol: str) -> dict:
        """Contract specification for a symbol."""
        ts = self._ts
        if ts:
            spec = ts.specification(symbol=symbol)
            if spec:
                return spec
        return await self._rpc_conn.get_symbol_specification(symbol)

    async def get_symbol_specification(self, symbol: str) -> Any:
        """Symbol specification (same as get_symbol_info, compat alias)."""
        return await self.get_symbol_info(symbol)

    async def get_current_price(self, symbol: str) -> dict:
        """Current bid/ask price from streaming state."""
        ts = self._ts
        if ts:
            price = ts.price(symbol=symbol)
            if price:
                return {
                    "bid": price.get("bid", 0.0),
                    "ask": price.get("ask", 0.0),
                    "time": price.get("time", datetime.now(timezone.utc).isoformat()),
                }
        raw = await self._rpc_conn.get_symbol_price(symbol)
        return {
            "bid": raw.get("bid", 0.0),
            "ask": raw.get("ask", 0.0),
            "time": raw.get("time", ""),
        }

    async def get_symbol_price(self, symbol: str) -> dict:
        """Explicit alias for get_current_price."""
        return await self.get_current_price(symbol)

    async def read_candle(self, symbol: str, timeframe: str) -> Optional[dict]:
        """Latest OHLCV candle for a symbol/timeframe."""
        candles = await self.get_historical_candles(symbol, timeframe, limit=1)
        return candles[0] if candles else None

    async def read_tick(self, symbol: str) -> dict:
        """Latest tick (bid/ask) for a symbol."""
        return await self.get_current_price(symbol)

    async def read_book(self, symbol: str) -> List[dict]:
        """Order book / market depth for a symbol."""
        ts = self._ts
        if ts and hasattr(ts, "book"):
            book = ts.book(symbol=symbol)
            if book:
                return book
        # RPC fallback
        try:
            return await self._rpc_conn.get_symbol_book(symbol)
        except Exception:
            return []

    async def get_server_time(self) -> dict:
        """Server time from the broker."""
        try:
            return await self._rpc_conn.get_server_time()
        except Exception:
            return {"time": datetime.now(timezone.utc).isoformat()}

    async def get_historical_candles(
        self,
        symbol: str,
        timeframe: str,
        start_time: Optional[Any] = None,
        limit: int = 100,
    ) -> List[dict]:
        """Historical OHLCV candles."""
        candles = await self._account.get_historical_candles(
            symbol=symbol,
            timeframe=timeframe,
            start_time=start_time,
            limit=limit,
        )
        result = []
        for c in (candles or []):
            result.append({
                "time":       c.get("time"),
                "open":       c.get("open"),
                "high":       c.get("high"),
                "low":        c.get("low"),
                "close":      c.get("close"),
                "tickVolume": c.get("tickVolume", 0),
                "spread":     c.get("spread", 0),
            })
        return result

    async def get_history(
        self,
        symbol: str,
        timeframe: str = "M1",
        count: int = 100,
    ) -> List[dict]:
        """Alias: get_historical_candles in farm-style (timeframe in MT5 format)."""
        tf_map = {
            "M1": "1m", "M5": "5m", "M15": "15m", "M30": "30m",
            "H1": "1h", "H4": "4h", "D1": "1d", "W1": "1w",
        }
        api_tf = tf_map.get(timeframe.upper(), timeframe.lower())
        return await self.get_historical_candles(symbol, api_tf, limit=count)

    async def get_historical_ticks(
        self,
        symbol: str,
        start_time: Optional[datetime] = None,
        offset: int = 0,
        limit: int = 100,
    ) -> List[dict]:
        """Historical tick data."""
        ticks = await self._account.get_historical_ticks(
            symbol=symbol,
            start_time=start_time,
            offset=offset,
            limit=limit,
        )
        return list(ticks or [])

    async def calculate_margin(self, order: dict) -> dict:
        """
        Calculate margin required for an order.

        order dict keys: symbol, type (ORDER_TYPE_BUY/SELL), volume, openPrice
        """
        return await self._rpc_conn.calculate_margin(order)

    # ------------------------------------------------------------------
    # Market data subscription
    # ------------------------------------------------------------------

    async def subscribe_to_market_data(self, symbol: str) -> bool:
        """Subscribe to real-time quotes for a symbol."""
        try:
            await self._stream_conn.subscribe_to_market_data(symbol=symbol)
            logger.info(f"[farm_ext] Subscribed to market data: {symbol}")
            return True
        except Exception as exc:
            logger.warning(f"[farm_ext] Subscribe failed for {symbol}: {exc}")
            return False

    async def unsubscribe_from_market_data(self, symbol: str) -> bool:
        """Unsubscribe from real-time quotes for a symbol."""
        try:
            await self._stream_conn.unsubscribe_from_market_data(symbol=symbol)
            logger.info(f"[farm_ext] Unsubscribed from market data: {symbol}")
            return True
        except Exception as exc:
            logger.warning(f"[farm_ext] Unsubscribe failed for {symbol}: {exc}")
            return False

    # ------------------------------------------------------------------
    # Trading — market orders
    # ------------------------------------------------------------------

    async def _trade(self, method_name: str, *args, **kwargs) -> dict:
        """Dispatch a trade call to the streaming connection."""
        method = getattr(self._stream_conn, method_name)
        return await method(*args, **kwargs)

    async def create_market_buy_order(
        self,
        symbol: str,
        volume: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        options: Optional[dict] = None,
    ) -> dict:
        """Market BUY order."""
        return await self._stream_conn.create_market_buy_order(
            symbol=symbol,
            volume=volume,
            stop_loss=stop_loss or None,
            take_profit=take_profit or None,
            options=options or {},
        )

    async def create_market_sell_order(
        self,
        symbol: str,
        volume: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        options: Optional[dict] = None,
    ) -> dict:
        """Market SELL order."""
        return await self._stream_conn.create_market_sell_order(
            symbol=symbol,
            volume=volume,
            stop_loss=stop_loss or None,
            take_profit=take_profit or None,
            options=options or {},
        )

    # FarmClient compat aliases
    async def market_buy(self, symbol: str, volume: float) -> dict:
        return await self.create_market_buy_order(symbol, volume)

    async def market_sell(self, symbol: str, volume: float) -> dict:
        return await self.create_market_sell_order(symbol, volume)

    # ------------------------------------------------------------------
    # Trading — pending orders
    # ------------------------------------------------------------------

    async def create_limit_buy_order(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        options: Optional[dict] = None,
    ) -> dict:
        """BUY LIMIT pending order."""
        return await self._stream_conn.create_limit_buy_order(
            symbol=symbol,
            volume=volume,
            open_price=open_price,
            stop_loss=stop_loss or None,
            take_profit=take_profit or None,
            options=options or {},
        )

    async def create_limit_sell_order(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        options: Optional[dict] = None,
    ) -> dict:
        """SELL LIMIT pending order."""
        return await self._stream_conn.create_limit_sell_order(
            symbol=symbol,
            volume=volume,
            open_price=open_price,
            stop_loss=stop_loss or None,
            take_profit=take_profit or None,
            options=options or {},
        )

    async def create_stop_buy_order(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        options: Optional[dict] = None,
    ) -> dict:
        """BUY STOP pending order."""
        return await self._stream_conn.create_stop_buy_order(
            symbol=symbol,
            volume=volume,
            open_price=open_price,
            stop_loss=stop_loss or None,
            take_profit=take_profit or None,
            options=options or {},
        )

    async def create_stop_sell_order(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        options: Optional[dict] = None,
    ) -> dict:
        """SELL STOP pending order."""
        return await self._stream_conn.create_stop_sell_order(
            symbol=symbol,
            volume=volume,
            open_price=open_price,
            stop_loss=stop_loss or None,
            take_profit=take_profit or None,
            options=options or {},
        )

    async def create_stop_limit_buy_order(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_limit_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        options: Optional[dict] = None,
    ) -> dict:
        """BUY STOP-LIMIT pending order."""
        return await self._stream_conn.create_stop_limit_buy_order(
            symbol=symbol,
            volume=volume,
            open_price=open_price,
            stop_limit_price=stop_limit_price,
            stop_loss=stop_loss or None,
            take_profit=take_profit or None,
            options=options or {},
        )

    async def create_stop_limit_sell_order(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_limit_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        options: Optional[dict] = None,
    ) -> dict:
        """SELL STOP-LIMIT pending order."""
        return await self._stream_conn.create_stop_limit_sell_order(
            symbol=symbol,
            volume=volume,
            open_price=open_price,
            stop_limit_price=stop_limit_price,
            stop_loss=stop_loss or None,
            take_profit=take_profit or None,
            options=options or {},
        )

    # FarmClient compat aliases
    async def buy_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs,
    ) -> dict:
        return await self.create_limit_buy_order(symbol, volume, price, stop_loss, take_profit)

    async def sell_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs,
    ) -> dict:
        return await self.create_limit_sell_order(symbol, volume, price, stop_loss, take_profit)

    async def buy_stop(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs,
    ) -> dict:
        return await self.create_stop_buy_order(symbol, volume, price, stop_loss, take_profit)

    async def sell_stop(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs,
    ) -> dict:
        return await self.create_stop_sell_order(symbol, volume, price, stop_loss, take_profit)

    async def buy_stop_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_limit_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs,
    ) -> dict:
        return await self.create_stop_limit_buy_order(
            symbol, volume, price, stop_limit_price, stop_loss, take_profit
        )

    async def sell_stop_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_limit_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs,
    ) -> dict:
        return await self.create_stop_limit_sell_order(
            symbol, volume, price, stop_limit_price, stop_loss, take_profit
        )

    # ------------------------------------------------------------------
    # Trading — position management
    # ------------------------------------------------------------------

    async def modify_position(
        self,
        position_id: str,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        trailing_stop: Optional[float] = None,
    ) -> dict:
        """Modify position SL/TP."""
        return await self._stream_conn.modify_position(
            position_id=str(position_id),
            stop_loss=stop_loss,
            take_profit=take_profit,
        )

    async def close_position(self, position_id: str) -> dict:
        """Close an open position fully."""
        return await self._stream_conn.close_position(position_id=str(position_id))

    async def close_position_partial(
        self, position_id: str, volume: float
    ) -> dict:
        """Partially close a position."""
        return await self._stream_conn.close_position_partially(
            position_id=str(position_id), volume=volume
        )

    async def close_position_by(
        self, position_id: str, opposite_position_id: str
    ) -> dict:
        """Close position against the opposite position."""
        return await self._stream_conn.close_by(
            position_id=str(position_id),
            opposite_position_id=str(opposite_position_id),
        )

    async def close_all_positions_by_symbol(self, symbol: str) -> dict:
        """Close all positions for a symbol."""
        return await self._stream_conn.close_positions_by_symbol(symbol=symbol)

    # ------------------------------------------------------------------
    # Trading — order management
    # ------------------------------------------------------------------

    async def modify_order(
        self,
        order_id: str,
        price: float = 0.0,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        stop_limit_price: float = 0.0,
        expiration: int = 0,
    ) -> dict:
        """Modify a pending order."""
        return await self._stream_conn.modify_order(
            order_id=str(order_id),
            open_price=price or None,
            stop_loss=stop_loss or None,
            take_profit=take_profit or None,
        )

    async def cancel_order(self, order_id: str) -> dict:
        """Cancel a pending order."""
        return await self._stream_conn.cancel_order(order_id=str(order_id))

    # Compat alias used by router.py (ticket-based)
    async def create_market_order(
        self,
        symbol: str,
        order_type: str,
        volume: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
    ) -> dict:
        if order_type.lower() == "buy":
            return await self.create_market_buy_order(symbol, volume, stop_loss, take_profit)
        return await self.create_market_sell_order(symbol, volume, stop_loss, take_profit)

    async def create_limit_order(
        self,
        symbol: str,
        order_type: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
    ) -> dict:
        if order_type.lower() == "buy":
            return await self.create_limit_buy_order(symbol, volume, price, stop_loss, take_profit)
        return await self.create_limit_sell_order(symbol, volume, price, stop_loss, take_profit)

    async def create_stop_order(
        self,
        symbol: str,
        order_type: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
    ) -> dict:
        if order_type.lower() == "buy":
            return await self.create_stop_buy_order(symbol, volume, price, stop_loss, take_profit)
        return await self.create_stop_sell_order(symbol, volume, price, stop_loss, take_profit)

    # ------------------------------------------------------------------
    # Connection health
    # ------------------------------------------------------------------

    @property
    def health_monitor(self) -> Optional[Any]:
        """MetaAPI health monitor object."""
        if self._stream_conn:
            return getattr(self._stream_conn, "health_monitor", None)
        return None

    async def close(self) -> None:
        """Close all connections and release resources."""
        logger.info(f"[farm_ext] Closing connections for {self.account_id}")
        self._connection_active = False

        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass

        for conn in (self._stream_conn, self._rpc_conn):
            if conn:
                try:
                    await conn.close()
                except Exception:
                    pass

        self._stream_conn = None
        self._rpc_conn = None
        self._connected = False
        self._synchronized = False

        async with _pool_lock:
            _pool.pop(self.account_id, None)

        logger.info(f"[farm_ext] Closed — {self.account_id}")

    def get_status(self) -> dict:
        return {
            "backend":        "farm_ext",
            "connected":      self._connected,
            "synchronized":   self._synchronized,
            "account_id":     self.account_id,
            "user_id":        self.user_id,
            "sdk_available":  FARM_EXT_AVAILABLE,
        }
