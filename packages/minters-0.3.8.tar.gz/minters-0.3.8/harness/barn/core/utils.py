"""
Core/utils.py

Essential utilities for the terminal service: symbol normalization and timeframe validation.
"""

import re
import logging
from typing import Optional, Any
from datetime import datetime

logger = logging.getLogger(__name__)

def normalize_symbol(symbol: str) -> str:
    """
    Normalize trading symbol to standard format with broker-specific suffix.
    
    Args:
        symbol: Raw symbol (e.g., "EUR/USD", "eurusd", "EURUSD")
        
    Returns:
        Normalized symbol with broker suffix (e.g., "EURUSDm")
    """
    if not symbol:
        raise ValueError("Symbol cannot be empty")
        
    # Remove common separators and convert to uppercase
    normalized = symbol.replace("/", "").replace("-", "").replace("_", "").upper()
    
    # Remove existing 'm' suffix if present to avoid duplication
    if normalized.endswith('M'):
        normalized = normalized[:-1]
    
    # Validate that it looks like a currency pair or instrument
    if not re.match(r'^[A-Z]{6,10}$', normalized):
        # Allow for indices, commodities, etc. with numbers
        if not re.match(r'^[A-Z0-9]{3,10}$', normalized):
            logger.warning(f"Symbol '{symbol}' may not be valid: '{normalized}'")
    
    # Append broker-specific lowercase 'm' suffix for all symbols
    # This broker requires all trading pairs to have an 'm' suffix (e.g., EURUSDm, GBPUSDm)
    return normalized + 'm'

def validate_timeframe(timeframe: str) -> str:
    """
    Validate and normalize timeframe string according to MetaAPI/MetaTrader standards.
    
    Args:
        timeframe: Timeframe string (e.g., "1m", "5m", "1h", "1d")
        
    Returns:
        Normalized timeframe string
        
    Raises:
        ValueError: If timeframe is invalid
    """
    if not timeframe:
        raise ValueError("Timeframe cannot be empty")
    
    # Normalize to lowercase
    tf = timeframe.lower().strip()
    
    # MetaAPI supported timeframes based on official documentation
    valid_timeframes = {
        # MetaAPI standard timeframes
        '1m': '1m', '2m': '2m', '3m': '3m', '4m': '4m', '5m': '5m', '6m': '6m',
        '10m': '10m', '12m': '12m', '15m': '15m', '20m': '20m', '30m': '30m',
        '1h': '1h', '2h': '2h', '3h': '3h', '4h': '4h', '6h': '6h', '8h': '8h', '12h': '12h',
        '1d': '1d', '1w': '1w', '1mn': '1mn',
        
        # Alternative input formats for convenience
        '1min': '1m', '5min': '5m', '15min': '15m', '30min': '30m',
        '1hour': '1h', '4hour': '4h', '1day': '1d', '1week': '1w', '1month': '1mn',
        'daily': '1d', 'weekly': '1w', 'monthly': '1mn', 'h1': '1h', 'h4': '4h', 'd1': '1d'
    }
    
    if tf in valid_timeframes:
        return valid_timeframes[tf]
    
    # Check for numeric pattern (e.g., "5", "15" for minutes)
    if tf.isdigit():
        minutes = int(tf)
        if minutes in [1, 2, 3, 4, 5, 6, 10, 12, 15, 20, 30]:
            return f"{minutes}m"
        elif minutes in [60, 120, 180, 240, 360, 480, 720]:
            return f"{minutes//60}h"
    
    valid_options = list(set(valid_timeframes.values()))
    valid_options.sort()
    raise ValueError(f"Invalid timeframe: {timeframe}. Valid options: {valid_options}")

def safe_float_convert(value: Any) -> Optional[float]:
    """
    Safely convert value to float, returning None if conversion fails.
    """
    if value is None:
        return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None

def parse_metaapi_time(time_str: str) -> datetime:
    """
    Parse MetaAPI time string to datetime object.
    """
    if not time_str:
        return datetime.utcnow()
    
    # Handle Z suffix for UTC
    if time_str.endswith('Z'):
        time_str = time_str[:-1] + '+00:00'
    
    try:
        return datetime.fromisoformat(time_str)
    except ValueError:
        logger.warning(f"Failed to parse time string: {time_str}")
        return datetime.utcnow()
