"""
Broker Mode Dispatcher
======================

Controls which trading backend is active via the ``BROKER_MODE``
environment variable.

Allowed values
--------------
``farm``        Self-hosted MT5 Farm Controller (default).
``farm_ext``    MetaAPI cloud SDK.
``capital``     Capital.com backend via Rust (PyO3/maturin).
``auto``        Try farm_ext first; silently fall back to farm.

Quick boolean toggle
--------------------
``FARM_EXT_ENABLED=true``  is equivalent to ``BROKER_MODE=farm_ext``
``FARM_EXT_ENABLED=false`` is equivalent to ``BROKER_MODE=farm``

The boolean flag overrides ``BROKER_MODE`` if both are set.

Usage
-----
    from harness.core.dispatcher import get_client, get_broker_mode

    client = await get_client(user=user_dict)
    info   = await client.get_account_information()
"""

from __future__ import annotations

import logging
import os
from typing import Optional, Union

logger = logging.getLogger(__name__)

# Lazy imports — resolved on first call to avoid circular deps and
# unnecessary SDK initialisation when only one backend is needed.
_FarmClient = None
_FarmExtClient = None
_CapitalClient = None


def _import_farm_client():
    global _FarmClient
    if _FarmClient is None:
        from harness.barn.core.farm_client import FarmClient
        _FarmClient = FarmClient
    return _FarmClient


def _import_farm_ext_client():
    global _FarmExtClient
    if _FarmExtClient is None:
        from harness.barn.core.farm_ext_client import FarmExtClient
        _FarmExtClient = FarmExtClient
    return _FarmExtClient


def _import_capital_client():
    global _CapitalClient
    if _CapitalClient is None:
        from harness.barn.core.capital_client import CapitalClient

        _CapitalClient = CapitalClient
    return _CapitalClient


# ---------------------------------------------------------------------------
# Mode resolution
# ---------------------------------------------------------------------------

def get_broker_mode() -> str:
    """
    Return the resolved broker mode.

    Priority:
    1. FARM_EXT_ENABLED env var (boolean override)
    2. CAPITAL_ENABLED env var (boolean override)
    3. BROKER_MODE env var
    4. "farm" (safe default)
    """
    ext_flag = os.environ.get("FARM_EXT_ENABLED", "").strip().lower()
    if ext_flag in ("1", "true", "yes", "on"):
        return "farm_ext"
    if ext_flag in ("0", "false", "no", "off"):
        return "farm"

    capital_flag = os.environ.get("CAPITAL_ENABLED", "").strip().lower()
    if capital_flag in ("1", "true", "yes", "on"):
        return "capital"

    mode = os.environ.get("BROKER_MODE", "farm").strip().lower()
    if mode not in ("farm", "farm_ext", "capital", "auto"):
        logger.warning(
            f"[dispatcher] Unknown BROKER_MODE '{mode}'; defaulting to 'farm'"
        )
        return "farm"
    return mode


def is_farm_ext_enabled() -> bool:
    """True when farm_ext (MetaAPI cloud) is the active or preferred backend."""
    return get_broker_mode() in ("farm_ext", "auto")


# ---------------------------------------------------------------------------
# Client factory
# ---------------------------------------------------------------------------

async def get_client(
    account_id: Optional[str] = None,
    user: Optional[dict] = None,
    *,
    mode: Optional[str] = None,
) -> Union[object, object]:
    """
    Return the appropriate backend client for the resolved broker mode.

    Parameters
    ----------
    account_id : str, optional
        Explicit account ID; overrides DB/env resolution.
    user : dict, optional
        User context dict with ``id`` key; used to resolve account ID
        from the database if configured.
    mode : str, optional
        Override the env-var mode for this specific call.
        Accepted: "farm", "farm_ext", "auto".

    Returns
    -------
    FarmClient | FarmExtClient
        Connected, ready-to-use client instance.

    Raises
    ------
    RuntimeError
        If the requested backend is unavailable and no fallback exists.
    """
    resolved_mode = mode or get_broker_mode()

    if resolved_mode == "farm_ext":
        logger.debug("[dispatcher] Using farm_ext backend")
        FarmExtClient = _import_farm_ext_client()
        return await FarmExtClient.get(account_id=account_id, user=user)

    if resolved_mode == "farm":
        logger.debug("[dispatcher] Using farm backend")
        FarmClient = _import_farm_client()
        return await FarmClient.get(account_id=account_id, user=user)

    if resolved_mode == "capital":
        logger.debug("[dispatcher] Using capital backend")
        CapitalClient = _import_capital_client()
        return await CapitalClient.get(account_id=account_id, user=user)

    # "auto" — try farm_ext first, fall back to farm
    logger.debug("[dispatcher] Auto mode — attempting farm_ext")
    try:
        FarmExtClient = _import_farm_ext_client()
        client = await FarmExtClient.get(account_id=account_id, user=user)
        logger.info("[dispatcher] Auto mode: using farm_ext")
        return client
    except Exception as exc:
        logger.warning(
            f"[dispatcher] farm_ext unavailable ({exc!r}), "
            "falling back to farm"
        )
        FarmClient = _import_farm_client()
        return await FarmClient.get(account_id=account_id, user=user)
