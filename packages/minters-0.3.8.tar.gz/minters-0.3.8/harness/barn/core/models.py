"""
Core/models.py

Typed DTOs mapping MetaAPI objects into stable shapes for the app.
Defines AccountSnapshot, Position, Order, Deal, and Candle models.
"""

from typing import Optional, Any, Dict, List
from datetime import datetime, timezone
from dataclasses import dataclass
from enum import Enum

class OrderType(Enum):
    """Order types supported by MetaTrader."""
    MARKET_BUY = "ORDER_TYPE_BUY"
    MARKET_SELL = "ORDER_TYPE_SELL"
    BUY_LIMIT = "ORDER_TYPE_BUY_LIMIT"
    SELL_LIMIT = "ORDER_TYPE_SELL_LIMIT"
    BUY_STOP = "ORDER_TYPE_BUY_STOP"
    SELL_STOP = "ORDER_TYPE_SELL_STOP"
    BUY_STOP_LIMIT = "ORDER_TYPE_BUY_STOP_LIMIT"  # MT5 only
    SELL_STOP_LIMIT = "ORDER_TYPE_SELL_STOP_LIMIT"  # MT5 only

class OrderState(Enum):
    """Order states."""
    STARTED = "ORDER_STATE_STARTED"
    PLACED = "ORDER_STATE_PLACED"
    CANCELED = "ORDER_STATE_CANCELED"
    PARTIAL = "ORDER_STATE_PARTIAL"
    FILLED = "ORDER_STATE_FILLED"
    REJECTED = "ORDER_STATE_REJECTED"
    EXPIRED = "ORDER_STATE_EXPIRED"

class PositionType(Enum):
    """Position types."""
    BUY = "POSITION_TYPE_BUY"
    SELL = "POSITION_TYPE_SELL"

@dataclass
class AccountSnapshot:
    """Account information snapshot."""
    login: str
    server: str
    broker: str
    currency: str
    leverage: int
    balance: float
    equity: float
    margin: float
    free_margin: float
    margin_level: float
    trade_allowed: bool
    timestamp: datetime
    
    @classmethod
    def from_metaapi(cls, account_info: Dict[str, Any]) -> 'AccountSnapshot':
        """Create AccountSnapshot from MetaAPI account information."""
        return cls(
            login=str(account_info.get('login', '')),
            server=account_info.get('server', ''),
            broker=account_info.get('broker', ''),
            currency=account_info.get('currency', 'USD'),
            leverage=int(account_info.get('leverage', 1)),
            balance=float(account_info.get('balance', 0.0)),
            equity=float(account_info.get('equity', 0.0)),
            margin=float(account_info.get('margin', 0.0)),
            free_margin=float(account_info.get('freeMargin', 0.0)),
            margin_level=float(account_info.get('marginLevel', 0.0)),
            trade_allowed=bool(account_info.get('tradeAllowed', True)),
            timestamp=datetime.now(timezone.utc)
        )

@dataclass
class Position:
    """Trading position."""
    id: str
    symbol: str
    type: PositionType
    volume: float
    open_price: float
    current_price: Optional[float]
    unrealized_profit: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]
    magic: Optional[int]
    comment: Optional[str]
    open_time: datetime
    update_time: Optional[datetime]
    
    @classmethod
    def from_metaapi(cls, position_data: Dict[str, Any]) -> 'Position':
        """Create Position from MetaAPI position data."""
        return cls(
            id=position_data.get('id', ''),
            symbol=position_data.get('symbol', ''),
            type=PositionType(position_data.get('type', 'POSITION_TYPE_BUY')),
            volume=float(position_data.get('volume', 0.0)),
            open_price=float(position_data.get('openPrice', 0.0)),
            current_price=float(position_data['currentPrice']) if position_data.get('currentPrice') is not None else None,
            unrealized_profit=float(position_data['unrealizedProfit']) if position_data.get('unrealizedProfit') is not None else None,
            stop_loss=float(position_data['stopLoss']) if position_data.get('stopLoss') is not None else None,
            take_profit=float(position_data['takeProfit']) if position_data.get('takeProfit') is not None else None,
            magic=int(position_data['magic']) if position_data.get('magic') is not None else None,
            comment=position_data.get('comment'),
            open_time=datetime.fromisoformat(position_data.get('time', '').replace('Z', '+00:00')),
            update_time=datetime.fromisoformat(position_data.get('updateTime', '').replace('Z', '+00:00')) if position_data.get('updateTime') else None
        )

@dataclass
class Order:
    """Trading order (pending or market)."""
    id: str
    symbol: str
    type: OrderType
    state: OrderState
    volume: float
    open_price: Optional[float]
    current_price: Optional[float]
    stop_loss: Optional[float]
    take_profit: Optional[float]
    stop_limit_price: Optional[float]  # For stop-limit orders
    magic: Optional[int]
    comment: Optional[str]
    time: datetime
    expiration_time: Optional[datetime]
    done_time: Optional[datetime]
    
    @classmethod
    def from_metaapi(cls, order_data: Dict[str, Any]) -> 'Order':
        """Create Order from MetaAPI order data."""
        return cls(
            id=order_data.get('id', ''),
            symbol=order_data.get('symbol', ''),
            type=OrderType(order_data.get('type', 'ORDER_TYPE_BUY')),
            state=OrderState(order_data.get('state', 'ORDER_STATE_STARTED')),
            volume=float(order_data.get('volume', 0.0)),
            open_price=float(order_data['openPrice']) if order_data.get('openPrice') is not None else None,
            current_price=float(order_data['currentPrice']) if order_data.get('currentPrice') is not None else None,
            stop_loss=float(order_data['stopLoss']) if order_data.get('stopLoss') is not None else None,
            take_profit=float(order_data['takeProfit']) if order_data.get('takeProfit') is not None else None,
            stop_limit_price=float(order_data['stopLimitPrice']) if order_data.get('stopLimitPrice') is not None else None,
            magic=int(order_data['magic']) if order_data.get('magic') is not None else None,
            comment=order_data.get('comment'),
            time=datetime.fromisoformat(order_data.get('time', '').replace('Z', '+00:00')),
            expiration_time=datetime.fromisoformat(order_data.get('expirationTime', '').replace('Z', '+00:00')) if order_data.get('expirationTime') else None,
            done_time=datetime.fromisoformat(order_data.get('doneTime', '').replace('Z', '+00:00')) if order_data.get('doneTime') else None
        )

@dataclass
class Deal:
    """Executed trade (deal/transaction)."""
    id: str
    order_id: str
    position_id: Optional[str]
    symbol: str
    type: str  # Deal type (buy/sell)
    volume: float
    price: float
    profit: Optional[float]
    commission: Optional[float]
    swap: Optional[float]
    magic: Optional[int]
    comment: Optional[str]
    time: datetime
    
    @classmethod
    def from_metaapi(cls, deal_data: Dict[str, Any]) -> 'Deal':
        """Create Deal from MetaAPI deal data."""
        return cls(
            id=deal_data.get('id', ''),
            order_id=deal_data.get('orderId', ''),
            position_id=deal_data.get('positionId'),
            symbol=deal_data.get('symbol', ''),
            type=deal_data.get('type', ''),
            volume=float(deal_data.get('volume', 0.0)),
            price=float(deal_data.get('price', 0.0)),
            profit=float(deal_data['profit']) if deal_data.get('profit') is not None else None,
            commission=float(deal_data['commission']) if deal_data.get('commission') is not None else None,
            swap=float(deal_data['swap']) if deal_data.get('swap') is not None else None,
            magic=int(deal_data['magic']) if deal_data.get('magic') is not None else None,
            comment=deal_data.get('comment'),
            time=datetime.fromisoformat(deal_data.get('time', '').replace('Z', '+00:00'))
        )

@dataclass
class Candle:
    """OHLC candle data."""
    time: datetime
    open: float
    high: float
    low: float
    close: float
    volume: Optional[float]
    
    @classmethod
    def from_metaapi(cls, candle_data: Dict[str, Any]) -> 'Candle':
        """Create Candle from MetaAPI candle data."""
        return cls(
            time=datetime.fromisoformat(candle_data.get('time', '').replace('Z', '+00:00')),
            open=float(candle_data.get('open', 0.0)),
            high=float(candle_data.get('high', 0.0)),
            low=float(candle_data.get('low', 0.0)),
            close=float(candle_data.get('close', 0.0)),
            volume=float(candle_data['volume']) if candle_data.get('volume') is not None else None
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary format."""
        return {
            "time": self.time.isoformat(),
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume
        }

# Utility functions for model conversion
def convert_positions(positions: List[Dict[str, Any]]) -> List[Position]:
    """Convert list of MetaAPI positions to Position objects."""
    return [Position.from_metaapi(pos) for pos in positions]

def convert_orders(orders: List[Dict[str, Any]]) -> List[Order]:
    """Convert list of MetaAPI orders to Order objects.""" 
    return [Order.from_metaapi(order) for order in orders]

def convert_deals(deals: List[Dict[str, Any]]) -> List[Deal]:
    """Convert list of MetaAPI deals to Deal objects."""
    return [Deal.from_metaapi(deal) for deal in deals]

def convert_candles(candles: List[Dict[str, Any]]) -> List[Candle]:
    """Convert list of MetaAPI candles to Candle objects."""
    return [Candle.from_metaapi(candle) for candle in candles]
