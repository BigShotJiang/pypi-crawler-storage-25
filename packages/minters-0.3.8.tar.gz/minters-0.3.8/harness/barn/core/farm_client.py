"""
Farm Client - HTTP/WebSocket client for MT5 Farm Controller

Replaces MetaAPI with self-hosted farm infrastructure.
Connects to farm with automatic fallback via centralized farm_config.
"""

import os
import asyncio
import logging
import socket
from typing import Optional, Dict, Any, List
from datetime import datetime, timezone

# Load environment variables from .env file
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv not available, use system environment variables

logger = logging.getLogger(__name__)

# Import centralized farm configuration
from .farm_config import get_farm_base_url, get_farm_url_sync

# Farm configuration with intelligent fallback
FARM_BASE_URL = get_farm_base_url()

# Log the resolved URL on module load
logger.info(f"[Farm] Using farm at {FARM_BASE_URL}")


# Connection pool
_farm_client_pool: Dict[str, "FarmClient"] = {}
_pool_lock = asyncio.Lock()


def _resolve_account_id_from_database(user: Optional[dict] = None) -> Optional[str]:
    """Kept for backward compatibility — always returns None (no database configured)."""
    return None


class FarmClient:
    """
    Client for MT5 Farm API.
    
    Provides all trading operations via REST API to the farm controller.
    Uses connection pooling for efficiency.
    Emulates MetaAPI interface for backward compatibility.
    """
    
    def __init__(self, account_id: str, user_id: str = "unknown"):
        self.account_id = account_id
        self.user_id = user_id
        self._session: Optional[Any] = None  # httpx.AsyncClient, kept for pool health checks
        self._connected = False
        self._synchronized = False
        self._last_status: Optional[dict] = None
        self._last_check_time: Optional[datetime] = None
        
        # Terminal state cache (populated by ensure_synchronized)
        self._terminal_state = {
            "account_information": {},
            "positions": [],
            "orders": []
        }
        
        logger.info(f"[Farm] Created client for account {account_id}")
    
    @classmethod
    async def get(
        cls,
        account_id: Optional[str] = None,
        user: Optional[dict] = None
    ) -> "FarmClient":
        """
        Get or create FarmClient instance.

        Resolution order:
        1. Explicit ``account_id`` parameter
        2. ``MASTER_ACCOUNT_ID`` environment variable (from .env)

        Raises
        ------
        ValueError
            If no account_id can be resolved.
        """
        user_id = user.get('id') if user else None

        # 1. Explicit account_id
        resolved_account_id: Optional[str] = account_id or None

        # 2. MASTER_ACCOUNT_ID env var
        if not resolved_account_id:
            resolved_account_id = os.getenv("MASTER_ACCOUNT_ID") or None
            if resolved_account_id:
                logger.debug(f"[Farm] Using MASTER_ACCOUNT_ID={resolved_account_id}")

        if not resolved_account_id:
            raise ValueError(
                "No account_id resolved. "
                "Pass account_id explicitly or set MASTER_ACCOUNT_ID in .env."
            )
        
        # Check pool for existing client
        async with _pool_lock:
            if resolved_account_id in _farm_client_pool:
                existing = _farm_client_pool[resolved_account_id]
                # httpx uses .is_closed instead of aiohttp's .closed
                if existing._session and not getattr(existing._session, 'is_closed', True):
                    logger.info(f"[Farm] Reusing existing client for {resolved_account_id}")
                    return existing
            
            # Create new client
            client = cls(resolved_account_id, user_id)
            await client._init()
            
            _farm_client_pool[resolved_account_id] = client
            logger.info(f"[Farm] Created new client. Pool size: {len(_farm_client_pool)}")
            
            return client
    
    async def _init(self):
        """Initialize HTTP client with httpx for better Windows support."""
        import httpx
        
        if self._session is None:
            # httpx handles Windows localhost better than aiohttp
            self._session = httpx.AsyncClient(
                timeout=httpx.Timeout(60.0, connect=10.0),
                limits=httpx.Limits(max_connections=30, max_keepalive_connections=10)
            )
            logger.info("[Farm] Initialized httpx async client")
        
        # Verify connection by checking node status
        try:
            status = await self.get_node_status()
            if status and status.get("is_alive"):
                self._connected = True
                self._last_status = status
                logger.info(f"[Farm] Connected to account {self.account_id}")
            else:
                logger.warning(f"[Farm] Node {self.account_id} not alive or not found")
                self._connected = False
        except Exception as e:
            logger.warning(f"[Farm] Failed to verify connection: {e}")
            self._connected = False
    
    @property
    def is_synchronized(self) -> bool:
        """Check if terminal state is synchronized (MetaAPI compatibility)."""
        return self._synchronized and self._connected
    
    @property
    def is_connected(self) -> bool:
        """Check if connected to farm."""
        return self._connected
    
    @property
    def connection(self) -> Any:
        """
        Get connection object (MetaAPI compatibility).
        Returns self if connected, else None.
        """
        return self if self._connected else None
    
    async def ensure_synchronized(self) -> bool:
        """
        Ensure terminal state is synchronized by fetching from farm.
        
        This is the key method for MetaAPI compatibility - it fetches
        account info, positions, and orders from the farm and caches them
        for subsequent get_terminal_state() calls.
        
        Returns:
            bool: True if synchronized successfully
        """
        if not self._session:
            await self._init()
        
        try:
            # Fetch all data from farm
            logger.info(f"[Farm] Synchronizing terminal state for {self.account_id}...")
            
            # Get account info
            account_info = await self.get_account_info()
            
            # Transform to MetaAPI format
            self._terminal_state["account_information"] = {
                "login": account_info.get("login"),
                "balance": account_info.get("balance", 0.0),
                "equity": account_info.get("equity", 0.0),
                "margin": account_info.get("margin", 0.0),
                "freeMargin": account_info.get("free_margin", 0.0),
                "marginLevel": account_info.get("margin_level", 0.0),
                "currency": account_info.get("currency", "USD"),
                "leverage": account_info.get("leverage", 1),
                "server": account_info.get("server", ""),
                "broker": account_info.get("broker", ""),
                "tradeAllowed": account_info.get("trade_allowed", True)
            }
            
            # Get positions
            self._terminal_state["positions"] = await self.get_positions()
            
            # Get orders
            self._terminal_state["orders"] = await self.get_pending_orders()
            
            self._synchronized = True
            self._last_check_time = datetime.now()
            
            balance = self._terminal_state["account_information"].get("balance", 0)
            logger.info(f"[Farm] ✅ Synchronized: balance=${balance:.2f}, "
                       f"{len(self._terminal_state['positions'])} positions, "
                       f"{len(self._terminal_state['orders'])} orders")
            
            return True
            
        except Exception as e:
            logger.error(f"[Farm] ❌ Sync failed: {e}")
            self._synchronized = False
            raise
    
    async def _request(
        self,
        method: str,
        endpoint: str,
        data: Optional[dict] = None,
        params: Optional[dict] = None,
        max_retries: int = 3,
        timeout_seconds: float = 30.0,
    ) -> dict:
        """Make HTTP request to farm API using httpx with fresh client per request."""
        import httpx
        
        url = f"{FARM_BASE_URL}{endpoint}"
        
        for attempt in range(max_retries):
            try:
                # Create fresh client for each request to avoid stale connection issues
                async with httpx.AsyncClient(timeout=httpx.Timeout(timeout_seconds)) as client:
                    if method.upper() == "GET":
                        response = await client.get(url, params=params)
                    elif method.upper() == "POST":
                        response = await client.post(url, json=data, params=params)
                    elif method.upper() == "DELETE":
                        response = await client.delete(url, params=params)
                    else:
                        response = await client.request(method, url, json=data, params=params)
                    
                    if response.status_code >= 400:
                        raise RuntimeError(f"Farm API error {response.status_code}: {response.text}")
                    
                    return response.json()
                
            except Exception as e:
                error_type = type(e).__name__
                error_msg = str(e) if str(e) else repr(e)
                if attempt < max_retries - 1:
                    wait_time = 0.5 * (2 ** attempt)
                    logger.warning(f"[Farm] HTTP error (attempt {attempt + 1}/{max_retries}): [{error_type}] {error_msg}. Retrying in {wait_time}s...")
                    await asyncio.sleep(wait_time)
                    continue
                else:
                    logger.error(f"[Farm] HTTP error after {max_retries} attempts: [{error_type}] {error_msg}")
                    raise RuntimeError(f"Farm connection error: {error_type}: {error_msg}")
    
    # ==================
    # Account Operations
    # ==================
    
    async def get_account_info(self) -> dict:
        """Get account information."""
        return await self._request("GET", f"/account/{self.account_id}")
    
    async def get_positions(self) -> List[dict]:
        """Get open positions."""
        result = await self._request("GET", f"/positions/{self.account_id}")
        return result.get("positions", [])
    
    async def get_pending_orders(self) -> List[dict]:
        """Get pending orders."""
        result = await self._request("GET", f"/orders/{self.account_id}")
        return result.get("orders", [])
    
    def get_terminal_state(self):
        """
        Get terminal state (MetaAPI compatibility).
        
        Returns a TerminalState-like object with account info, positions, orders.
        Data is populated by ensure_synchronized() - call that first.
        """
        # Return a TerminalState-like object using cached data
        class TerminalState:
            def __init__(self, state_data):
                self._state = state_data
            
            @property
            def account_information(self):
                return self._state.get("account_information", {})
            
            @property
            def positions(self):
                return self._state.get("positions", [])
            
            @property
            def orders(self):
                return self._state.get("orders", [])
        
        return TerminalState(self._terminal_state)
    
    async def get_deal_history(
        self,
        from_date: int = 0,
        to_date: int = 0
    ) -> List[dict]:
        """Get deal history."""
        params = {"from_date": from_date, "to_date": to_date}
        result = await self._request("GET", f"/deals/{self.account_id}", params=params)
        return result.get("deals", [])
    
    async def get_node_status(self) -> Optional[dict]:
        """Get node status."""
        try:
            return await self._request("GET", f"/status/{self.account_id}")
        except RuntimeError:
            return None
    
    # ==================
    # Market Data
    # ==================
    
    async def get_symbol_info(self, symbol: str) -> dict:
        """Get symbol information."""
        return await self._request("GET", f"/symbol/{self.account_id}/{symbol}")
    
    async def get_current_price(self, symbol: str) -> dict:
        """Get current bid/ask price."""
        return await self._request("GET", f"/price/{self.account_id}/{symbol}")
    
    async def get_history(
        self,
        symbol: str,
        timeframe: str = "M1",
        count: int = 100,
        start_time: Optional[Any] = None,
        end_time: Optional[Any] = None,
        offset: int = 0,
    ) -> List[dict]:
        """Get historical rates."""
        from datetime import datetime as _dt

        def _to_ts(value: Optional[Any]) -> Optional[int]:
            if value is None:
                return None
            if isinstance(value, _dt):
                return int(value.timestamp())
            return int(value)

        params = {
            "symbol": symbol,
            "timeframe": timeframe,
            "count": count,
            "offset": int(offset),
        }
        start_ts = _to_ts(start_time)
        end_ts = _to_ts(end_time)
        if start_ts is not None:
            params["start_time"] = start_ts
        if end_ts is not None:
            params["end_time"] = end_ts

        result = await self._request(
            "GET",
            f"/history/{self.account_id}",
            params=params,
            max_retries=1,
            timeout_seconds=95.0,
        )
        return result.get("rates", [])
    
    async def get_historical_candles(
        self,
        symbol: str,
        timeframe: str,
        start_time: Optional[Any] = None,
        end_time: Optional[Any] = None,
        offset: int = 0,
        limit: int = 100
    ) -> List[dict]:
        """
        Get historical candle data (MetaAPI compatibility).
        
        This wraps get_history() to match the MetaAPI interface expected by quotes.py.
        """
        # Convert timeframe format (1m -> M1, 1h -> H1, etc.)
        tf_map = {
            "1m": "M1", "5m": "M5", "15m": "M15", "30m": "M30",
            "1h": "H1", "4h": "H4", "1d": "D1", "1w": "W1"
        }
        mt5_timeframe = tf_map.get(timeframe.lower(), timeframe.upper())
        
        # Fetch from farm
        rates = await self.get_history(
            symbol=symbol,
            timeframe=mt5_timeframe,
            count=limit,
            start_time=start_time,
            end_time=end_time,
            offset=offset,
        )
        
        # Transform to candle format expected by quotes.py
        # Farm API returns short keys: t, o, h, l, c, v
        candles = []
        for rate in rates:
            candles.append({
                "time": rate.get("time") or rate.get("t"),
                "open": rate.get("open") or rate.get("o"),
                "high": rate.get("high") or rate.get("h"),
                "low": rate.get("low") or rate.get("l"),
                "close": rate.get("close") or rate.get("c"),
                "tickVolume": rate.get("tick_volume") or rate.get("volume") or rate.get("v", 0),
                "spread": rate.get("spread", 0)
            })
        
        return candles
    
    async def get_symbol_specification(self, symbol: str) -> dict:
        """
        Get symbol specification (MetaAPI compatibility).
        
        Returns dict with trade_allowed, min_volume, max_volume, volume_step, etc.
        """
        info = await self.get_symbol_info(symbol)
        
        # Return as object-like dict for compatibility
        class SymbolSpec:
            def __init__(self, data):
                self.trade_allowed = data.get("trade_mode", "TRADE_MODE_FULL") != "TRADE_MODE_DISABLED"
                self.min_volume = data.get("volume_min", 0.01)
                self.max_volume = data.get("volume_max", 100.0)
                self.volume_step = data.get("volume_step", 0.01)
                self.digits = data.get("digits", 5)
                self.point = data.get("point", 0.00001)
        
        return SymbolSpec(info)
    
    async def get_account_information(self) -> dict:
        """
        Get account information (MetaAPI compatibility).
        
        Returns dict with camelCase keys matching MetaAPI format.
        """
        info = await self.get_account_info()
        return {
            "login": info.get("login"),
            "balance": info.get("balance", 0.0),
            "equity": info.get("equity", 0.0),
            "margin": info.get("margin", 0.0),
            "freeMargin": info.get("free_margin", 0.0),
            "marginLevel": info.get("margin_level", 0.0),
            "currency": info.get("currency", "USD"),
            "leverage": info.get("leverage", 1),
            "server": info.get("server", ""),
            "tradeAllowed": info.get("trade_allowed", True)
        }
    
    @property
    def account(self):
        """
        Get account object (MetaAPI compatibility).
        
        Returns self since FarmClient has all the account methods.
        The quotes.py code calls client.account.get_historical_candles().
        """
        return self
    
    # ==================
    # Market Orders
    # ==================
    
    async def market_buy(
        self,
        symbol: str,
        volume: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        comment: str = "",
    ) -> dict:
        """Execute market buy order."""
        data = {
            "action": "buy",
            "symbol": symbol,
            "volume": volume,
            "ticket": 0,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "comment": comment,
        }
        return await self._request("POST", f"/trade/{self.account_id}", data=data)
    
    async def market_sell(
        self,
        symbol: str,
        volume: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        comment: str = "",
    ) -> dict:
        """Execute market sell order."""
        data = {
            "action": "sell",
            "symbol": symbol,
            "volume": volume,
            "ticket": 0,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "comment": comment,
        }
        return await self._request("POST", f"/trade/{self.account_id}", data=data)
    
    async def close_position(self, ticket: int) -> dict:
        """Close position by ticket."""
        return await self._request("POST", f"/close/{self.account_id}/{ticket}")
    
    # ==================
    # Pending Orders
    # ==================
    
    async def place_pending_order(
        self,
        order_type: str,
        symbol: str,
        volume: float,
        price: float,
        stop_limit_price: float = 0.0,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0,
        magic: int = 0,
        comment: str = ""
    ) -> dict:
        """
        Place a pending order.
        
        Args:
            order_type: buy_limit, sell_limit, buy_stop, sell_stop, 
                       buy_stop_limit, sell_stop_limit
            symbol: Trading symbol
            volume: Lot size
            price: Order price
            stop_limit_price: For stop-limit orders
            stop_loss: Stop loss price
            take_profit: Take profit price
            expiration: Unix timestamp (0 = GTC)
            magic: Magic number
            comment: Order comment
        """
        data = {
            "order_type": order_type,
            "symbol": symbol,
            "volume": volume,
            "price": price,
            "stop_limit_price": stop_limit_price,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "expiration": expiration,
            "magic": magic,
            "comment": comment
        }
        return await self._request("POST", f"/order/{self.account_id}", data=data)
    
    async def buy_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs
    ) -> dict:
        """Place buy limit order."""
        return await self.place_pending_order(
            "buy_limit", symbol, volume, price,
            stop_loss=stop_loss, take_profit=take_profit, **kwargs
        )
    
    async def sell_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs
    ) -> dict:
        """Place sell limit order."""
        return await self.place_pending_order(
            "sell_limit", symbol, volume, price,
            stop_loss=stop_loss, take_profit=take_profit, **kwargs
        )
    
    async def buy_stop(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs
    ) -> dict:
        """Place buy stop order."""
        return await self.place_pending_order(
            "buy_stop", symbol, volume, price,
            stop_loss=stop_loss, take_profit=take_profit, **kwargs
        )
    
    async def sell_stop(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs
    ) -> dict:
        """Place sell stop order."""
        return await self.place_pending_order(
            "sell_stop", symbol, volume, price,
            stop_loss=stop_loss, take_profit=take_profit, **kwargs
        )
    
    # MetaAPI-compatible trade execution methods
    async def create_market_order(
        self,
        symbol: str,
        order_type: str,
        volume: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0
    ) -> dict:
        """
        Create market order (MetaAPI compatibility).
        
        Args:
            symbol: Trading symbol
            order_type: 'buy' or 'sell'
            volume: Lot size
            stop_loss: Stop loss price (optional)
            take_profit: Take profit price (optional)
        """
        if order_type.lower() == 'buy':
            return await self.market_buy(symbol, volume)
        else:
            return await self.market_sell(symbol, volume)
    
    async def create_limit_order(
        self,
        symbol: str,
        order_type: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0
    ) -> dict:
        """Create limit order (MetaAPI compatibility)."""
        order_type_str = f"{order_type.lower()}_limit"
        return await self.place_pending_order(
            order_type=order_type_str,
            symbol=symbol,
            volume=volume,
            price=price,
            stop_loss=stop_loss,
            take_profit=take_profit
        )
    
    async def create_stop_order(
        self,
        symbol: str,
        order_type: str,
        volume: float,
        price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0
    ) -> dict:
        """Create stop order (MetaAPI compatibility)."""
        order_type_str = f"{order_type.lower()}_stop"
        return await self.place_pending_order(
            order_type=order_type_str,
            symbol=symbol,
            volume=volume,
            price=price,
            stop_loss=stop_loss,
            take_profit=take_profit
        )
    
    async def modify_position(
        self,
        ticket: int,
        stop_loss: float = None,
        take_profit: float = None
    ) -> dict:
        """Modify position SL/TP (MetaAPI compatibility)."""
        data = {"ticket": ticket}
        if stop_loss is not None:
            data["stop_loss"] = stop_loss
        if take_profit is not None:
            data["take_profit"] = take_profit
        return await self._request("POST", f"/modify/{self.account_id}", data=data)
    
    async def subscribe_to_market_data(self, symbol: str) -> bool:
        """
        Subscribe to market data for a symbol (MetaAPI compatibility).
        
        For Farm, this is a no-op since all symbols are automatically available.
        Returns True to indicate subscription success.
        """
        logger.info(f"[Farm] Market data subscription for {symbol} (auto-enabled)")
        return True

    
    async def buy_stop_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_limit_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs
    ) -> dict:
        """Place buy stop-limit order."""
        return await self.place_pending_order(
            "buy_stop_limit", symbol, volume, price,
            stop_limit_price=stop_limit_price,
            stop_loss=stop_loss, take_profit=take_profit, **kwargs
        )
    
    async def sell_stop_limit(
        self,
        symbol: str,
        volume: float,
        price: float,
        stop_limit_price: float,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        **kwargs
    ) -> dict:
        """Place sell stop-limit order."""
        return await self.place_pending_order(
            "sell_stop_limit", symbol, volume, price,
            stop_limit_price=stop_limit_price,
            stop_loss=stop_loss, take_profit=take_profit, **kwargs
        )
    
    async def modify_order(
        self,
        ticket: int,
        price: float = 0.0,
        stop_limit_price: float = 0.0,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        expiration: int = 0
    ) -> dict:
        """Modify a pending order."""
        data = {
            "price": price,
            "stop_limit_price": stop_limit_price,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "expiration": expiration
        }
        return await self._request("PUT", f"/order/{self.account_id}/{ticket}", data=data)
    
    async def cancel_order(self, ticket: int) -> dict:
        """Cancel a pending order."""
        return await self._request("DELETE", f"/order/{self.account_id}/{ticket}")
    
    # ==================
    # Position Management
    # ==================
    
    async def modify_position(
        self,
        ticket: int,
        stop_loss: float = 0.0,
        take_profit: float = 0.0,
        trailing_stop: float = 0.0
    ) -> dict:
        """Modify position SL/TP."""
        data = {
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "trailing_stop": trailing_stop
        }
        return await self._request("PUT", f"/position/{self.account_id}/{ticket}", data=data)
    
    async def close_position_partial(
        self,
        ticket: int,
        volume: float
    ) -> dict:
        """Partially close a position."""
        data = {"volume": volume}
        return await self._request(
            "POST",
            f"/position/{self.account_id}/{ticket}/close-partial",
            data=data
        )
    
    async def close_position_by(
        self,
        ticket: int,
        opposite_ticket: int
    ) -> dict:
        """Close position by opposite."""
        return await self._request(
            "POST",
            f"/position/{self.account_id}/{ticket}/close-by/{opposite_ticket}"
        )
    
    async def close_all_positions_by_symbol(self, symbol: str) -> dict:
        """Close all positions for a symbol."""
        return await self._request(
            "POST",
            f"/positions/{self.account_id}/close-all/{symbol}"
        )

    # ==================
    # Single-item Lookups
    # ==================

    async def get_position(self, ticket: str) -> Optional[dict]:
        """Get a single open position by ticket/ID."""
        try:
            return await self._request(
                "GET", f"/position/{self.account_id}/{ticket}"
            )
        except RuntimeError:
            return None

    async def get_order(self, order_id: str) -> Optional[dict]:
        """Get a single pending order by ID."""
        try:
            return await self._request(
                "GET", f"/order/{self.account_id}/{order_id}"
            )
        except RuntimeError:
            return None

    # ==================
    # History (extended)
    # ==================

    async def get_history_orders_by_ticket(self, ticket: str) -> List[dict]:
        """History orders filtered by ticket number."""
        result = await self._request(
            "GET",
            f"/history-orders/{self.account_id}",
            params={"ticket": ticket},
        )
        return result.get("orders", [])

    async def get_history_orders_by_position(self, position_id: str) -> List[dict]:
        """History orders filtered by position ID."""
        result = await self._request(
            "GET",
            f"/history-orders/{self.account_id}",
            params={"position_id": position_id},
        )
        return result.get("orders", [])

    async def get_history_orders_by_time_range(
        self,
        start_time: "datetime",
        end_time: Optional["datetime"] = None,
    ) -> List[dict]:
        """History orders in a time range (datetime objects or epoch ints)."""
        from datetime import datetime as _dt

        def _ts(t):
            if isinstance(t, _dt):
                return int(t.timestamp())
            return int(t)

        params = {"from_date": _ts(start_time)}
        if end_time is not None:
            params["to_date"] = _ts(end_time)
        result = await self._request(
            "GET",
            f"/history-orders/{self.account_id}",
            params=params,
        )
        return result.get("orders", [])

    async def get_deals_by_ticket(self, ticket: str) -> List[dict]:
        """Deals filtered by ticket."""
        result = await self._request(
            "GET",
            f"/deals/{self.account_id}",
            params={"ticket": ticket},
        )
        return result.get("deals", [])

    async def get_deals_by_position(self, position_id: str) -> List[dict]:
        """Deals filtered by position ID."""
        result = await self._request(
            "GET",
            f"/deals/{self.account_id}",
            params={"position_id": position_id},
        )
        return result.get("deals", [])

    async def get_deals_by_time_range(
        self,
        start_time: "datetime",
        end_time: Optional["datetime"] = None,
    ) -> List[dict]:
        """Deals in a time range (datetime objects or epoch ints)."""
        from datetime import datetime as _dt

        def _ts(t):
            if isinstance(t, _dt):
                return int(t.timestamp())
            return int(t)

        params = {"from_date": _ts(start_time)}
        if end_time is not None:
            params["to_date"] = _ts(end_time)
        result = await self._request(
            "GET",
            f"/deals/{self.account_id}",
            params=params,
        )
        return result.get("deals", [])

    # ==================
    # Symbols (extended)
    # ==================

    async def get_symbols(self) -> List[str]:
        """List all symbols available in this terminal."""
        result = await self._request("GET", f"/symbols/{self.account_id}")
        return result.get("symbols", [])

    async def get_symbol_price(self, symbol: str) -> dict:
        """Explicit alias for get_current_price."""
        return await self.get_current_price(symbol)

    async def read_tick(self, symbol: str) -> dict:
        """Latest tick (bid/ask) — alias for get_current_price."""
        return await self.get_current_price(symbol)

    async def read_candle(self, symbol: str, timeframe: str) -> Optional[dict]:
        """Latest single OHLCV candle for a symbol/timeframe."""
        candles = await self.get_historical_candles(symbol, timeframe, limit=1)
        return candles[0] if candles else None

    async def get_historical_ticks(
        self,
        symbol: str,
        start_time: Optional[Any] = None,
        end_time: Optional[Any] = None,
        offset: int = 0,
        limit: int = 100,
    ) -> List[dict]:
        """Historical tick data for a symbol."""
        from datetime import datetime as _dt
        params: dict = {"symbol": symbol, "offset": offset, "limit": limit}
        if start_time is not None:
            if isinstance(start_time, _dt):
                params["start_time"] = int(start_time.timestamp())
            else:
                params["start_time"] = int(start_time)
        if end_time is not None:
            if isinstance(end_time, _dt):
                params["end_time"] = int(end_time.timestamp())
            else:
                params["end_time"] = int(end_time)
        result = await self._request(
            "GET",
            f"/ticks/{self.account_id}",
            params=params,
            max_retries=1,
            timeout_seconds=125.0,
        )
        return result.get("ticks", [])

    async def read_book(self, symbol: str) -> List[dict]:
        """Order book / market depth for a symbol."""
        try:
            result = await self._request(
                "GET", f"/book/{self.account_id}/{symbol}"
            )
            return result.get("book", [])
        except RuntimeError:
            return []

    async def calculate_margin(self, order: dict) -> dict:
        """
        Calculate required margin for a hypothetical order.

        order dict keys: symbol, type (buy/sell), volume, open_price
        """
        return await self._request(
            "POST", f"/margin/{self.account_id}", data=order
        )

    async def get_server_time(self) -> dict:
        """Get the broker's current server time."""
        try:
            return await self._request("GET", f"/time/{self.account_id}")
        except RuntimeError:
            return {"time": datetime.now(timezone.utc).isoformat()}

    async def unsubscribe_from_market_data(self, symbol: str) -> bool:
        """
        Unsubscribe from market data (no-op for Farm; all symbols always active).
        Returns True for interface compatibility.
        """
        logger.info(f"[Farm] Unsubscribe for {symbol} is a no-op on the farm backend")
        return True

    # ==================
    # Connection Management
    # ==================
    
    async def close(self):
        """Close client and clean up resources."""
        logger.info(f"[Farm] Closing client for {self.account_id}")
        
        # httpx uses .is_closed and .aclose() instead of aiohttp's .closed and .close()
        if self._session and not getattr(self._session, 'is_closed', True):
            await self._session.aclose()
            self._session = None
        
        self._connected = False
        
        # Remove from pool
        async with _pool_lock:
            if self.account_id in _farm_client_pool:
                del _farm_client_pool[self.account_id]
        
        logger.info(f"[Farm] Client closed for {self.account_id}")
    
    @property
    def is_connected(self) -> bool:
        """Check if connected to farm."""
        return self._connected
    
    async def ensure_synchronized(self) -> bool:
        """Ensure connection is active (for compatibility with MetaAPI client)."""
        if not self._connected:
            await self._init()
        return self._connected
    
    def get_status(self) -> dict:
        """Get client status."""
        return {
            "connected": self._connected,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "farm_url": FARM_BASE_URL,
            "last_status": self._last_status,
            "last_check_time": self._last_check_time.isoformat() if self._last_check_time else None,
            "pool_size": len(_farm_client_pool)
        }


# Convenience function for getting terminal state
async def get_terminal_state(account_id: str) -> dict:
    """
    Get terminal state from farm.
    
    Compatible interface with MetaAPI terminal_state.
    """
    client = await FarmClient.get(account_id=account_id)
    
    account_info = await client.get_account_info()
    positions = await client.get_positions()
    orders = await client.get_pending_orders()
    
    return {
        "connected": True,
        "connectedToBroker": account_info.get("connected", True),
        "accountInformation": {
            "login": account_info.get("login"),
            "balance": account_info.get("balance"),
            "equity": account_info.get("equity"),
            "margin": account_info.get("margin"),
            "freeMargin": account_info.get("free_margin"),
            "marginLevel": account_info.get("margin_level"),
            "currency": account_info.get("currency"),
            "leverage": account_info.get("leverage"),
            "server": account_info.get("server"),
            "tradeAllowed": account_info.get("trade_allowed")
        },
        "positions": positions,
        "orders": orders
    }
