"""
Terminal Account Module
======================
Account management including credentials, positions, and history.
"""

from .creds import get_account_snapshot
from .positions import get_open_positions, get_pending_orders
from .history import get_closed_orders

__all__ = [
    'get_account_snapshot',
    'get_open_positions', 
    'get_pending_orders',
    'get_closed_orders'
]
