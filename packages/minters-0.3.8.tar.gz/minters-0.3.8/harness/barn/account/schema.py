"""
Account Service Schema
======================
JSON schema definitions and service mappings for MetaAPI account functionality.
Covers account credentials, positions, and history management.
"""

from typing import Dict, Any, List, Optional
import datetime

# --- JSON Schema Dictionary for Account Tools ---
account_tools = {
    "get_account_snapshot": {
        "name": "get_account_snapshot",
        "description": "Retrieves comprehensive account information including balance, equity, leverage, and trading permissions.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "additionalProperties": False
        }
    },
    "get_open_positions": {
        "name": "get_open_positions", 
        "description": "Retrieves all currently open trading positions with details like symbol, volume, profit/loss, and entry price.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string", 
                    "description": "Optional filter by trading symbol (e.g., 'EURUSD'). If not provided, returns all open positions.",
                    "default": None
                }
            },
            "additionalProperties": False
        }
    },
    "get_pending_orders": {
        "name": "get_pending_orders",
        "description": "Retrieves all pending orders (limit orders, stop orders) that have not yet been executed.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Optional filter by trading symbol (e.g., 'EURUSD'). If not provided, returns all pending orders.",
                    "default": None
                },
                "order_type": {
                    "type": "string",
                    "description": "Optional filter by order type ('LIMIT', 'STOP', 'STOP_LIMIT'). If not provided, returns all types.",
                    "default": None
                }
            },
            "additionalProperties": False
        }
    },
    "get_closed_orders": {
        "name": "get_closed_orders",
        "description": "Retrieves closed/completed trading orders from account history.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Optional filter by trading symbol (e.g., 'EURUSD'). If not provided, returns all closed orders.",
                    "default": None
                },
                "start_time": {
                    "type": "string",
                    "description": "Optional start time in ISO format (e.g., '2025-08-01T00:00:00Z'). If not provided, uses reasonable default.",
                    "default": None
                },
                "end_time": {
                    "type": "string", 
                    "description": "Optional end time in ISO format (e.g., '2025-08-25T23:59:59Z'). If not provided, uses current time.",
                    "default": None
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of orders to return. Default is 100.",
                    "default": 100,
                    "minimum": 1,
                    "maximum": 1000
                }
            },
            "additionalProperties": False
        }
    }
}

class AccountServiceManager:
    """Manager class for account service operations with tool mapping"""
    
    def __init__(self):
        # Import functions with clean path setup
        import sys
        import os

        # Add the grass root to path
        grass_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../'))
        if grass_root not in sys.path:
            sys.path.insert(0, grass_root)
        
        # Also add current directory
        current_dir = os.path.dirname(__file__)
        if current_dir not in sys.path:
            sys.path.insert(0, current_dir)
        
        # Import the account functions
        import harness.barn.account.creds as creds
        import harness.barn.account.positions as positions
        import harness.barn.account.history as history
        
        self.get_account_snapshot = creds.get_account_snapshot
        self.get_open_positions = positions.get_open_positions
        self.get_pending_orders = positions.get_pending_orders
        self.get_closed_orders = history.get_closed_orders
        
        self.request_history = []
        
    def _log_request(self, function_name: str, params: Dict[str, Any], result: Any):
        """Log account service requests for debugging"""
        self.request_history.append({
            "timestamp": datetime.datetime.now().isoformat(),
            "function": function_name,
            "parameters": params,
            "success": result.get("success", False) if isinstance(result, dict) else bool(result),
            "result_type": type(result).__name__
        })
        
    async def fetch_account_snapshot(self, user: Optional[Dict] = None):
        """Fetch comprehensive account information
        
        Args:
            user: Optional user context dict with 'id' for database-backed account resolution
        """
        try:
            result = await self.get_account_snapshot(user=user)
            self._log_request("get_account_snapshot", {"user": user.get("id") if user else None}, result)
            
            if result:
                return {
                    "success": True,
                    "account_info": result,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": "Failed to retrieve account snapshot",
                    "account_info": None
                }
                
        except Exception as e:
            error_result = {"success": False, "error": str(e)}
            self._log_request("get_account_snapshot", {}, error_result)
            return error_result
            
    async def fetch_open_positions(self, symbol: Optional[str] = None, user: Optional[Dict] = None):
        """Fetch all open trading positions
        
        Args:
            symbol: Optional filter by trading symbol
            user: Optional user context dict with 'id' for database-backed account resolution
        """
        try:
            params = {"symbol": symbol} if symbol else {}
            if user:
                params["user"] = user.get("id") if isinstance(user, dict) else None
            result = await self.get_open_positions(symbol=symbol, user=user)
            self._log_request("get_open_positions", params, result)
            
            if result is not None:
                return {
                    "success": True,
                    "positions": result,
                    "count": len(result) if isinstance(result, list) else 0,
                    "filter": {"symbol": symbol} if symbol else None,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": "Failed to retrieve open positions",
                    "positions": []
                }
                
        except Exception as e:
            error_result = {"success": False, "error": str(e), "positions": []}
            self._log_request("get_open_positions", {"symbol": symbol}, error_result)
            return error_result
            
    async def fetch_pending_orders(self, symbol: Optional[str] = None, order_type: Optional[str] = None, user: Optional[Dict] = None):
        """Fetch all pending orders
        
        Args:
            symbol: Optional filter by trading symbol
            order_type: Optional filter by order type
            user: Optional user context dict with 'id' for database-backed account resolution
        """
        params = {}
        if symbol:
            params["symbol"] = symbol
        if order_type:
            params["order_type"] = order_type
        if user:
            params["user"] = user.get("id") if isinstance(user, dict) else None
            
        try:
            result = await self.get_pending_orders(symbol=symbol, order_type=order_type, user=user)
            self._log_request("get_pending_orders", params, result)
            
            if result is not None:
                return {
                    "success": True,
                    "orders": result,
                    "count": len(result) if isinstance(result, list) else 0,
                    "filter": params if params else None,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": "Failed to retrieve pending orders",
                    "orders": []
                }
                
        except Exception as e:
            error_result = {"success": False, "error": str(e), "orders": []}
            self._log_request("get_pending_orders", params, error_result)
            return error_result
            
    async def fetch_closed_orders(self, symbol: Optional[str] = None, start_time: Optional[str] = None,
                                 end_time: Optional[str] = None, limit: int = 100, user: Optional[Dict] = None):
        """Fetch closed/completed trading orders from history
        
        Args:
            symbol: Optional filter by trading symbol
            start_time: Optional start time filter
            end_time: Optional end time filter
            limit: Maximum number of orders to return
            user: Optional user context dict with 'id' for database-backed account resolution
        """
        params = {
            "symbol": symbol,
            "start_time": start_time,
            "end_time": end_time,
            "limit": limit
        }
        # Remove None values
        params = {k: v for k, v in params.items() if v is not None}
        if user:
            params["user"] = user.get("id") if isinstance(user, dict) else None
        
        try:
            result = await self.get_closed_orders(
                symbol=symbol,
                start_time=start_time,
                end_time=end_time,
                limit=limit,
                user=user
            )
            self._log_request("get_closed_orders", params, result)
            
            if result is not None:
                return {
                    "success": True,
                    "orders": result,
                    "count": len(result) if isinstance(result, list) else 0,
                    "filter": params if params else None,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": "Failed to retrieve closed orders",
                    "orders": []
                }
                
        except Exception as e:
            error_result = {"success": False, "error": str(e), "orders": []}
            self._log_request("get_closed_orders", params, error_result)
            return error_result
    
    def get_request_history(self, limit: int = 10):
        """Get recent account service request history"""
        return {
            "success": True,
            "history": self.request_history[-limit:] if self.request_history else [],
            "total_requests": len(self.request_history)
        }
    
    def clear_request_history(self):
        """Clear request history"""
        self.request_history.clear()
        return {"success": True, "message": "Request history cleared"}
    
    def get_account_status(self):
        """Get account service status and statistics"""
        return {
            "success": True,
            "status": {
                "service_name": "AccountService",
                "functions_available": ["account_snapshot", "open_positions", "pending_orders", "closed_orders"],
                "total_requests": len(self.request_history),
                "recent_requests": len([r for r in self.request_history 
                                      if datetime.datetime.fromisoformat(r["timestamp"]) > 
                                      datetime.datetime.now() - datetime.timedelta(hours=1)]),
                "service_ready": True,
                "last_request": self.request_history[-1] if self.request_history else None
            }
        }

# Dictionary mapping tool names to their function implementations  
account_tool_implementations = {
    "get_account_snapshot": lambda manager: manager.fetch_account_snapshot,
    "get_open_positions": lambda manager: manager.fetch_open_positions,
    "get_pending_orders": lambda manager: manager.fetch_pending_orders,
    "get_closed_orders": lambda manager: manager.fetch_closed_orders,
}

# Extended tools for additional functionality
extended_account_tools = {
    "get_request_history": {
        "name": "get_request_history",
        "description": "Retrieves recent account service request history with metadata.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Number of recent requests to return.", "default": 10}
            },
            "additionalProperties": False
        }
    },
    "get_account_status": {
        "name": "get_account_status",
        "description": "Retrieves account service status and statistics.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "additionalProperties": False
        }
    },
    "clear_request_history": {
        "name": "clear_request_history", 
        "description": "Clears account service request history.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "additionalProperties": False
        }
    }
}

# Combine all tools
all_account_tools = {**account_tools, **extended_account_tools}

# Extended implementations
extended_account_implementations = {
    "get_request_history": lambda manager: manager.get_request_history,
    "get_account_status": lambda manager: manager.get_account_status,
    "clear_request_history": lambda manager: manager.clear_request_history,
}

# Combine all implementations
all_account_implementations = {**account_tool_implementations, **extended_account_implementations}

def main():
    """Main function for testing account schema"""
    print("=== Account Service Schema Test ===")
    
    print("Available account tools:")
    for tool_name, tool_schema in all_account_tools.items():
        print(f"  - {tool_name}: {tool_schema['description']}")
    
    print(f"\nTotal tools: {len(all_account_tools)}")
    
    # Example usage parameters
    print(f"\nExample parameters:")
    examples = {
        "get_account_snapshot": {},
        "get_open_positions": {"symbol": "EURUSDm"},
        "get_pending_orders": {"symbol": "GBPUSDm", "order_type": "LIMIT"},
        "get_closed_orders": {"symbol": "USDJPYm", "limit": 50}
    }
    
    for tool_name, example_params in examples.items():
        print(f"  {tool_name}: {example_params}")

if __name__ == "__main__":
    main()
