"""
Account/creds.py

Return account details including leverage, balance, equity, and other account information.
Uses the MetaAPI client to fetch real-time account data.
"""

from typing import Dict, Any, Optional
from datetime import datetime, timezone

from harness.barn.core.dispatcher import get_client
from harness.barn.core.utils import safe_float_convert

async def get_account_snapshot(user: Optional[Dict] = None) -> Dict[str, Any]:
    """
    Get comprehensive account details including balance, equity, leverage, etc.
    
    Args:
        user: Optional user context dict with 'id' for database-backed account resolution
    
    Returns:
        Dictionary containing all account details:
        - login: Account login number
        - server: Broker server name
        - broker: Broker company name
        - currency: Account base currency
        - leverage: Account leverage ratio
        - balance: Account balance
        - equity: Current equity
        - margin: Used margin
        - free_margin: Available margin
        - margin_level: Margin level percentage
        - trade_allowed: Whether trading is allowed
        - timestamp: When data was retrieved
        
    Raises:
        RuntimeError: If connection fails or account not found
    """
    client = await get_client(user=user)
    
    # Get account information directly from Farm
    # This calls /farm/account/{account_id} endpoint
    account_info = await client.get_account_information()
    
    # Extract broker from server name if not provided
    broker = account_info.get('broker', '')
    if not broker and account_info.get('server'):
        # Extract broker from server name (e.g., "Exness-MT5Trial9" -> "Exness")
        broker = account_info.get('server', '').split('-')[0]
    
    return {
        "login": str(account_info.get('login', '')),
        "server": account_info.get('server', ''),
        "broker": broker,
        "currency": account_info.get('currency', 'USD'),
        "leverage": int(account_info.get('leverage', 1)),
        "balance": safe_float_convert(account_info.get('balance')) or 0.0,
        "equity": safe_float_convert(account_info.get('equity')) or 0.0,
        "margin": safe_float_convert(account_info.get('margin')) or 0.0,
        "free_margin": safe_float_convert(account_info.get('freeMargin')) or 0.0,
        "margin_level": safe_float_convert(account_info.get('marginLevel')) or 0.0,
        "trade_allowed": bool(account_info.get('tradeAllowed', True)),
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
