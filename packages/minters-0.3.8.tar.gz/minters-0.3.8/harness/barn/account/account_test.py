"""
Account Test Module
==================

Comprehensive test for the terminal account module.
Tests all account functions: credentials, history, and positions with real MetaAPI.
"""

import os
import sys
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any

# Load environment variables from .env file
try:
    from dotenv import load_dotenv
    # Load from the family root directory
    env_path = os.path.join(os.path.dirname(__file__), '../../../.env')
    load_dotenv(env_path)
    print(f"[INFO]  Loaded .env from: {env_path}")
except ImportError:
    print("[WARN]  python-dotenv not installed. Install with: pip install python-dotenv")
except Exception as e:
    print(f"[ERROR]  Failed to load .env: {e}")

# Add the family directory to path for imports
family_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../'))
if family_root not in sys.path:
    sys.path.insert(0, family_root)

# Add current directory to path
current_dir = os.path.dirname(__file__)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Import the account functions
try:
    # Import the modules directly
    import harness.barn.account.creds as creds
    import harness.barn.account.history as history  
    import harness.barn.account.positions as positions
    
    # Get the specific functions
    get_account_snapshot = creds.get_account_snapshot
    get_closed_orders = history.get_closed_orders
    get_open_positions = positions.get_open_positions
    get_pending_orders = positions.get_pending_orders
    
    print("[INFO]  All account modules imported successfully")
    
except ImportError as e:
    print(f"[ERROR]  Import error: {e}")
    print("[ERROR]  Failed to import account modules")
    sys.exit(1)

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class AccountTester:
    """Test suite for account module functionality."""
    
    def __init__(self):
        self.test_results = {}
        
    async def test_account_details(self) -> bool:
        """Test account credentials/details function."""
        logger.info("Testing account details retrieval...")
        
        try:
            # Test get_account_snapshot function
            account_details = await get_account_snapshot()
            
            # Verify expected structure
            required_fields = [
                'login', 'server', 'broker', 'currency', 'leverage', 
                'balance', 'equity', 'margin', 'free_margin', 
                'margin_level', 'trade_allowed', 'timestamp'
            ]
            
            for field in required_fields:
                if field not in account_details:
                    logger.error(f"Missing required field: {field}")
                    return False
            
            # Log account details
            logger.info("Account Details Retrieved:")
            logger.info(f"  Login: {account_details['login']}")
            logger.info(f"  Server: {account_details['server']}")
            logger.info(f"  Broker: {account_details['broker']}")
            logger.info(f"  Currency: {account_details['currency']}")
            logger.info(f"  Leverage: 1:{account_details['leverage']}")
            logger.info(f"  Balance: ${account_details['balance']:,.2f}")
            logger.info(f"  Equity: ${account_details['equity']:,.2f}")
            logger.info(f"  Margin: ${account_details['margin']:,.2f}")
            logger.info(f"  Free Margin: ${account_details['free_margin']:,.2f}")
            logger.info(f"  Margin Level: {account_details['margin_level']:,.2f}%")
            logger.info(f"  Trade Allowed: {account_details['trade_allowed']}")
            
            # Verify data types
            assert isinstance(account_details['login'], str)
            assert isinstance(account_details['leverage'], int)
            assert isinstance(account_details['balance'], (int, float))
            assert isinstance(account_details['equity'], (int, float))
            assert isinstance(account_details['trade_allowed'], bool)
            
            logger.info("[INFO] Account details function working correctly")
            return True
            
        except Exception as e:
            logger.error(f"[ERROR] Account details test failed: {e}")
            return False
    
    async def test_closed_orders(self) -> bool:
        """Test closed orders history function."""
        logger.info("[INFO] Testing closed orders retrieval...")
        
        try:
            # Test get_closed_orders function
            closed_orders = await get_closed_orders()
            
            logger.info(f"[INFO] Retrieved {len(closed_orders)} closed orders")
            
            # Verify it returns a list
            assert isinstance(closed_orders, list)
            
            # If there are orders, verify structure
            if closed_orders:
                first_order = closed_orders[0]
                expected_fields = [
                    'id', 'symbol', 'type', 'volume', 'open_price', 
                    'close_price', 'open_time', 'close_time', 'profit', 
                    'commission', 'swap', 'state'
                ]
                
                for field in expected_fields:
                    if field not in first_order:
                        logger.warning(f"Missing field in order: {field}")
                
                # Log sample orders
                for i, order in enumerate(closed_orders[:3]):  # Show first 3 orders
                    logger.info(f"[INFO]   Order {i+1}:")
                    logger.info(f"[INFO]     ID: {order.get('id', 'N/A')}")
                    logger.info(f"[INFO]     Symbol: {order.get('symbol', 'N/A')}")
                    logger.info(f"[INFO]     Type: {order.get('type', 'N/A')}")
                    logger.info(f"[INFO]     Volume: {order.get('volume', 0)}")
                    logger.info(f"[INFO]     Profit: ${order.get('profit', 0):,.2f}")
                    logger.info(f"[INFO]     State: {order.get('state', 'N/A')}")
            else:
                logger.info("[INFO]   No closed orders found (this is normal for new accounts)")
            
            logger.info("[INFO] Closed orders function working correctly")
            return True
            
        except Exception as e:
            logger.error(f"[ERROR] Closed orders test failed: {e}")
            return False
    
    async def test_open_positions(self) -> bool:
        """Test open positions function."""
        logger.info("Testing open positions retrieval...")
        
        try:
            # Test get_open_positions function
            open_positions = await get_open_positions()
            
            logger.info(f"Retrieved {len(open_positions)} open positions")
            
            # Verify it returns a list
            assert isinstance(open_positions, list)
            
            # If there are positions, verify structure
            if open_positions:
                first_position = open_positions[0]
                expected_fields = [
                    'id', 'symbol', 'type', 'volume', 'open_price', 
                    'current_price', 'unrealized_profit', 'open_time'
                ]
                
                for field in expected_fields:
                    if field not in first_position:
                        logger.warning(f"Missing field in position: {field}")
                
                # Log sample positions
                for i, position in enumerate(open_positions):
                    logger.info(f"  Position {i+1}:")
                    logger.info(f"    ID: {position.get('id', 'N/A')}")
                    logger.info(f"    Symbol: {position.get('symbol', 'N/A')}")
                    logger.info(f"    Type: {position.get('type', 'N/A')}")
                    logger.info(f"    Volume: {position.get('volume', 0)}")
                    logger.info(f"    Open Price: {position.get('open_price', 0)}")
                    logger.info(f"    Current Price: {position.get('current_price', 0)}")
                    logger.info(f"    Unrealized P&L: ${position.get('unrealized_profit', 0):,.2f}")
            else:
                logger.info("  No open positions found (account has no active trades)")
            
            logger.info("✓ Open positions function working correctly")
            return True
            
        except Exception as e:
            logger.error(f"✗ Open positions test failed: {e}")
            return False
    
    async def test_pending_orders(self) -> bool:
        """Test pending orders function."""
        logger.info("Testing pending orders retrieval...")
        
        try:
            # Test get_pending_orders function
            pending_orders = await get_pending_orders()
            
            logger.info(f"Retrieved {len(pending_orders)} pending orders")
            
            # Verify it returns a list
            assert isinstance(pending_orders, list)
            
            # If there are pending orders, verify structure
            if pending_orders:
                first_pending = pending_orders[0]
                expected_fields = [
                    'id', 'symbol', 'type', 'volume', 'open_price', 
                    'created_time', 'state'
                ]
                
                for field in expected_fields:
                    if field not in first_pending:
                        logger.warning(f"Missing field in pending order: {field}")
                
                # Log sample pending orders
                for i, pending in enumerate(pending_orders):
                    logger.info(f"  Pending Order {i+1}:")
                    logger.info(f"    ID: {pending.get('id', 'N/A')}")
                    logger.info(f"    Symbol: {pending.get('symbol', 'N/A')}")
                    logger.info(f"    Type: {pending.get('type', 'N/A')}")
                    logger.info(f"    Volume: {pending.get('volume', 0)}")
                    logger.info(f"    Price: {pending.get('open_price', 0)}")
                    logger.info(f"    State: {pending.get('state', 'N/A')}")
            else:
                logger.info("  No pending orders found (account has no pending trades)")
            
            logger.info("✓ Pending orders function working correctly")
            return True
            
        except Exception as e:
            logger.error(f"✗ Pending orders test failed: {e}")
            return False
    
    async def run_all_tests(self) -> Dict[str, bool]:
        """Run all account tests and return results."""
        logger.info("Starting comprehensive account module tests...")
        logger.info("=" * 70)
        
        tests = [
            ("Account Details", self.test_account_details),
            ("Closed Orders History", self.test_closed_orders),
            ("Open Positions", self.test_open_positions),
            ("Pending Orders", self.test_pending_orders)
        ]
        
        results = {}
        passed = 0
        total = len(tests)
        
        for test_name, test_func in tests:
            logger.info(f"\n--- Running: {test_name} ---")
            try:
                result = await test_func()
                results[test_name] = result
                if result:
                    passed += 1
                    logger.info(f"✅ {test_name}: PASSED")
                else:
                    logger.error(f"❌ {test_name}: FAILED")
            except Exception as e:
                logger.error(f"💥 Test '{test_name}' crashed: {e}")
                results[test_name] = False
        
        logger.info("\n" + "=" * 70)
        logger.info("ACCOUNT MODULE TEST SUMMARY")
        logger.info("=" * 70)
        
        for test_name, result in results.items():
            status = "✅ PASS" if result else "❌ FAIL"
            logger.info(f"{test_name:25} {status}")
        
        logger.info(f"\nOverall: {passed}/{total} tests passed ({(passed/total)*100:.1f}%)")
        
        if passed == total:
            logger.info("🎉 ALL ACCOUNT TESTS PASSED!")
            logger.info("✅ The account module is fully functional!")
        elif passed >= total * 0.8:  # 80% success threshold
            logger.warning(f"⚠️  Most tests passed - account module is functional")
        else:
            logger.error(f"❌ Multiple tests failed")
            logger.error("🔧 Please review and fix the issues before proceeding")
        
        return results

async def main():
    """Main test execution function."""
    print("\n" + "="*70)
    print("FAMILY TRADING SYSTEM - ACCOUNT MODULE TEST")
    print("="*70)
    print(f"Test started at: {datetime.now()}")
    print(f"Python version: {sys.version}")
    
    # Check environment
    print("\nEnvironment Check:")
    token = os.environ.get('METAAPI_TOKEN')
    account_id = os.environ.get('METAAPI_ACCOUNT_ID')
    
    if token:
        print(f"METAAPI_TOKEN: Set (ends with ...{token[-10:]})")
    else:
        print("METAAPI_TOKEN: ❌ NOT SET")
        
    if account_id:
        print(f"METAAPI_ACCOUNT_ID: Set ({account_id})")
    else:
        print("METAAPI_ACCOUNT_ID: ❌ NOT SET")
    
    if not token or not account_id:
        print("\n❌ MetaAPI credentials not found!")
        print("Please set METAAPI_TOKEN and METAAPI_ACCOUNT_ID environment variables")
        return 1
    
    # Run tests
    tester = AccountTester()
    results = await tester.run_all_tests()
    
    # Exit with appropriate code
    if all(results.values()):
        print("\n🎉 All account module tests completed successfully!")
        print("🚀 The account module is ready for production use!")
        return 0
    else:
        failed_tests = [name for name, result in results.items() if not result]
        print(f"\n❌ {len(failed_tests)} test(s) failed: {', '.join(failed_tests)}")
        return 1

if __name__ == "__main__":
    # Make the script executable directly
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n⏹️  Tests interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Test execution failed: {e}")
        sys.exit(1)
