"""
Account Positions Module
========================
Functions to retrieve open positions and pending orders from the farm.
"""

import logging
from typing import List, Dict, Any, Optional

from harness.barn.core.dispatcher import get_client
from harness.barn.core.utils import normalize_symbol

logger = logging.getLogger(__name__)

async def get_open_positions(symbol: Optional[str] = None, user: Optional[Dict] = None) -> List[Dict[str, Any]]:
    """
    Get all open trading positions from the Farm account.
    
    Args:
        symbol: Optional filter by trading symbol (e.g., 'EURUSDm')
        user: Optional user context dict with 'id' for database-backed account resolution
        
    Returns:
        List of open positions with details
    """
    logger.info(f"Fetching open positions{f' for symbol {symbol}' if symbol else ''}")
    
    try:
        client = await get_client(user=user)

        # Get positions directly from Farm API
        # This calls /farm/positions/{account_id} endpoint
        positions = await client.get_positions()
        
        if not positions:
            logger.info("No open positions found")
            return []
        
        # Farm always returns dicts
        position_list = [dict(pos) for pos in positions]
        
        # Filter by symbol if provided
        if symbol:
            # Normalize the symbol to match broker format
            normalized_symbol = normalize_symbol(symbol)
            position_list = [pos for pos in position_list if pos.get('symbol') == normalized_symbol]
            logger.info(f"Filtered to {len(position_list)} positions for symbol {normalized_symbol}")
        
        logger.info(f"Found {len(position_list)} open positions")
        return position_list
        
    except Exception as e:
        logger.error(f"Error fetching open positions: {e}")
        return []

async def get_pending_orders(symbol: Optional[str] = None, order_type: Optional[str] = None, user: Optional[Dict] = None) -> List[Dict[str, Any]]:
    """
    Get all pending orders from the Farm account.
    
    Args:
        symbol: Optional filter by trading symbol (e.g., 'EURUSDm')
        order_type: Optional filter by order type ('LIMIT', 'STOP', 'STOP_LIMIT')
        user: Optional user context dict with 'id' for database-backed account resolution
        
    Returns:
        List of pending orders with details
    """
    logger.info(f"Fetching pending orders{f' for symbol {symbol}' if symbol else ''}{f' of type {order_type}' if order_type else ''}")
    
    try:
        client = await get_client(user=user)

        # Get orders directly from Farm API
        # This calls /farm/orders/{account_id} endpoint
        orders = await client.get_pending_orders()
        
        if not orders:
            logger.info("No pending orders found")
            return []
        
        # Farm always returns dicts
        order_list = [dict(order) for order in orders]
        
        # Farm API already returns only pending orders (from MT5 OrdersTotal)
        # No state filtering needed - all orders in the list are already pending
        pending_orders = order_list
        
        # Filter by symbol if provided
        if symbol:
            normalized_symbol = normalize_symbol(symbol)
            pending_orders = [order for order in pending_orders if order.get('symbol') == normalized_symbol]
            logger.info(f"Filtered to {len(pending_orders)} pending orders for symbol {normalized_symbol}")
        
        # Filter by order type if provided
        if order_type:
            type_filter = order_type.lower()
            # Farm API returns types like 'buy_limit', 'sell_limit', 'buy_stop', 'sell_stop'
            pending_orders = [order for order in pending_orders 
                            if type_filter in order.get('type', '').lower()]
            logger.info(f"Filtered to {len(pending_orders)} orders of type {order_type}")
        
        logger.info(f"Found {len(pending_orders)} pending orders")
        return pending_orders
        
    except Exception as e:
        logger.error(f"Error fetching pending orders: {e}")
        return []
