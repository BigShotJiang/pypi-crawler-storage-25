"""
Account/history.py

Fetch deal history from the farm REST API.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime, timezone

from harness.barn.core.dispatcher import get_client


async def get_closed_orders(
    symbol: Optional[str] = None,
    start_time: Optional[str] = None,
    end_time: Optional[str] = None,
    limit: int = 100,
    user: Optional[Dict] = None,
) -> List[Dict[str, Any]]:
    """
    Get deal history from the farm.

    Args:
        symbol: Optional filter by trading symbol
        start_time: ISO-8601 string or None (defaults to last 24 h)
        end_time: ISO-8601 string or None (defaults to now)
        limit: Maximum number of deals to return
        user: User context for account resolution

    Returns:
        List of deal dicts: id, symbol, type, volume, price, profit,
        commission, swap, open_time, close_time, comment
    """
    def _to_unix(dt_str: Optional[str]) -> int:
        if not dt_str:
            return 0
        try:
            dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
            return int(dt.timestamp())
        except Exception:
            return 0

    from_ts = _to_unix(start_time)
    to_ts = _to_unix(end_time)

    client = await get_client(user=user)
    deals = await client.get_deal_history(from_date=from_ts, to_date=to_ts)

    result = []
    for d in deals:
        deal_symbol = d.get("symbol", "")
        if symbol and deal_symbol != symbol:
            continue
        result.append({
            "id": d.get("id", ""),
            "symbol": deal_symbol,
            "type": d.get("type", ""),
            "volume": float(d.get("volume", 0.0)),
            "price": float(d.get("price", 0.0)),
            "profit": float(d.get("profit", 0.0)),
            "commission": float(d.get("commission", 0.0)),
            "swap": float(d.get("swap", 0.0)),
            "open_time": d.get("time", ""),
            "close_time": d.get("time", ""),
            "comment": d.get("comment", ""),
        })

    result.sort(key=lambda x: x.get("close_time", ""), reverse=True)
    return result[:limit]
