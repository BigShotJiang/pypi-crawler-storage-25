"""
Data/quotes.py
==============

Live ticks subscription and historical OHLC data fetching.
"""

import asyncio
import logging
from typing import List, Dict, Any, Optional, Callable, AsyncGenerator
from datetime import datetime, timezone, timedelta

from harness.barn.core.dispatcher import get_client
from harness.barn.core.utils import normalize_symbol, validate_timeframe

logger = logging.getLogger(__name__)


async def get_live_ticks(
    symbol: str,
    callback: Optional[Callable] = None,
    user: Optional[dict] = None,
) -> AsyncGenerator[Dict[str, Any], None]:
    """
    Poll live tick data for a symbol via the farm price endpoint.

    Yields a price dict every ~100 ms containing bid, ask, time, spread.
    """
    symbol = normalize_symbol(symbol)
    logger.info(f"Starting live tick poll for {symbol}")

    client = await get_client(user=user)
    tick_count = 0

    while True:
        try:
            price_data = await client.get_current_price(symbol)
            bid = float(price_data.get("bid", 0.0))
            ask = float(price_data.get("ask", 0.0))
            tick = {
                "symbol": symbol,
                "bid": bid,
                "ask": ask,
                "time": datetime.now(timezone.utc).isoformat(),
                "spread": round(ask - bid, 5),
                "tick_count": tick_count,
            }
            if callback:
                callback(tick)
            tick_count += 1
            yield tick
        except Exception as e:
            logger.error(f"Live tick poll error for {symbol}: {e}")
            raise

        await asyncio.sleep(0.1)


async def get_historical_ohlc(
    symbol: str,
    timeframe: str,
    limit: int = 1000,
    start_time: Optional[Any] = None,
    end_time: Optional[Any] = None,
    user: Optional[dict] = None,
) -> List[Dict[str, Any]]:
    """
    Fetch historical OHLC candle data from Farm.

    Args:
        symbol: Trading symbol (e.g., 'EURUSD')
        timeframe: Timeframe string ('1m', '5m', '15m', '30m', '1h', '4h', '1d')
        limit: Number of candles to fetch (max 5000)
        start_time: Optional Unix timestamp or datetime to start from
        end_time: Optional Unix timestamp or datetime to end at
        user: User context for account resolution

    Returns:
        List of OHLC candle dicts with keys:
        time, open, high, low, close, volume, symbol, timeframe
    """
    symbol = normalize_symbol(symbol)
    timeframe = validate_timeframe(timeframe)

    if limit <= 0 or limit > 5000:
        raise ValueError("Limit must be between 1 and 5000")

    logger.info(f"Fetching {limit} historical candles for {symbol} {timeframe}")

    client = await get_client(user=user)
    candles = await client.get_historical_candles(
        symbol=symbol,
        timeframe=timeframe,
        start_time=start_time,
        end_time=end_time,
        limit=limit,
    )

    if not candles:
        raise RuntimeError(f"No historical data available for {symbol}")

    now = datetime.now(timezone.utc)
    result = []

    def _to_ts(value: Optional[Any]) -> Optional[int]:
        if value is None:
            return None
        if isinstance(value, datetime):
            return int(value.timestamp())
        return int(value)

    start_ts = _to_ts(start_time)
    end_ts = _to_ts(end_time)

    def _candle_ts(raw_time: Any) -> Optional[int]:
        if raw_time is None:
            return None
        if isinstance(raw_time, datetime):
            return int(raw_time.timestamp())
        if isinstance(raw_time, (int, float)):
            return int(raw_time)
        if isinstance(raw_time, str):
            try:
                return int(float(raw_time))
            except ValueError:
                try:
                    parsed = datetime.fromisoformat(raw_time.replace("Z", "+00:00"))
                    return int(parsed.timestamp())
                except ValueError:
                    return None
        return None

    for candle in candles:
        t = candle.get("time", now)
        candle_ts = _candle_ts(t)
        if start_ts is not None and (candle_ts is None or candle_ts < start_ts):
            continue
        if end_ts is not None and (candle_ts is None or candle_ts > end_ts):
            continue

        time_str = t.isoformat() if hasattr(t, "isoformat") else str(t)
        result.append({
            "time": time_str,
            "open": float(candle.get("open", 0)),
            "high": float(candle.get("high", 0)),
            "low": float(candle.get("low", 0)),
            "close": float(candle.get("close", 0)),
            "volume": float(candle.get("tickVolume", candle.get("tick_volume", candle.get("volume", 0)))),
            "symbol": symbol,
            "timeframe": timeframe,
        })

    logger.info(f"Fetched {len(result)} candles for {symbol} {timeframe}")
    return result


async def get_historical_ohlc_range(
    symbol: str,
    timeframe: str,
    start_time: Any,
    end_time: Any,
    limit: int = 5000,
    user: Optional[dict] = None,
) -> List[Dict[str, Any]]:
    """
    Fetch historical OHLC candles constrained by a time range.

    Args:
        symbol: Trading symbol (e.g., 'XAUUSDm')
        timeframe: Timeframe string ('1m', '5m', '15m', '30m', '1h', '4h', '1d')
        start_time: Unix timestamp or datetime start bound (inclusive)
        end_time: Unix timestamp or datetime end bound (inclusive)
        limit: Maximum number of candles to fetch (max 5000)
        user: User context for account resolution
    """
    return await get_historical_ohlc(
        symbol=symbol,
        timeframe=timeframe,
        limit=limit,
        start_time=start_time,
        end_time=end_time,
        user=user,
    )
    current_time = datetime.now(timezone.utc)
    
    candles = []
    
    for i in range(limit):
        # Calculate candle time (going backwards from current time)
        candle_time = current_time - timedelta(minutes=minutes * (limit - i - 1))
        
        # Generate realistic OHLC progression
        open_price = base_price + random.uniform(-0.01, 0.01)
        
        # High and low relative to open
        high_range = random.uniform(0.0001, 0.005)
        low_range = random.uniform(0.0001, 0.005)
        
        high_price = open_price + high_range
        low_price = open_price - low_range
        
        # Close within the high-low range
        close_price = random.uniform(low_price, high_price)
        
        # Volume (random but realistic)
        volume = random.uniform(100, 2000)
        
        candle = {
            'time': candle_time.isoformat(),
            'open': round(open_price, 5),
            'high': round(high_price, 5),
            'low': round(low_price, 5),
            'close': round(close_price, 5),
            'volume': round(volume, 2),
            'symbol': symbol,
            'timeframe': timeframe
        }
        
        candles.append(candle)
        
        # Use close price as next base price for progression
        base_price = close_price
    
    return candles

def convert_ticks_to_ohlc(ticks: List[Dict[str, Any]], timeframe: str) -> List[Dict[str, Any]]:
    """
    Convert tick data to OHLC candles for the specified timeframe.
    
    Args:
        ticks: List of tick dictionaries
        timeframe: Target timeframe for OHLC conversion
        
    Returns:
        List of OHLC candle dictionaries
    """
    if not ticks:
        return []
    
    # Timeframe to seconds mapping
    timeframe_seconds = {
        '1m': 60, '5m': 300, '15m': 900, '30m': 1800,
        '1h': 3600, '4h': 14400, '1d': 86400
    }
    
    seconds = timeframe_seconds.get(timeframe, 60)
    candles = []
    
    # Group ticks by time periods
    current_candle = None
    
    for tick in ticks:
        tick_time = datetime.fromisoformat(tick['time'].replace('Z', '+00:00'))
        
        # Calculate candle start time
        timestamp = tick_time.timestamp()
        candle_start = datetime.fromtimestamp(
            (timestamp // seconds) * seconds, 
            tz=timezone.utc
        )
        
        # Use mid price (bid + ask) / 2 for OHLC
        mid_price = (tick['bid'] + tick['ask']) / 2
        
        # Start new candle if needed
        if current_candle is None or current_candle['time'] != candle_start:
            if current_candle is not None:
                candles.append(current_candle)
            
            current_candle = {
                'time': candle_start,
                'open': mid_price,
                'high': mid_price,
                'low': mid_price,
                'close': mid_price,
                'volume': 1,
                'symbol': tick['symbol']
            }
        else:
            # Update existing candle
            current_candle['high'] = max(current_candle['high'], mid_price)
            current_candle['low'] = min(current_candle['low'], mid_price)
            current_candle['close'] = mid_price
            current_candle['volume'] += 1
    
    # Add the last candle
    if current_candle is not None:
        candles.append(current_candle)
    
    return candles
