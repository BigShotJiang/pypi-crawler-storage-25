"""
Data/buffer.py
==============

Simple rolling market data buffer that takes a symbol, timeframe, and size.
Returns a buffer with OHLC data that you can directly use.
"""

import sys
import os
from collections import deque
from typing import Deque, List, Dict, Any, Optional
import logging
import asyncio

# Use shared utility for symbol normalization. Be resilient when running this
# file directly (so that top-level package imports still work).
try:
    from harness.barn.core.utils import normalize_symbol
except Exception:
    try:
        # Try to add the repository package root (up three levels) to sys.path
        from pathlib import Path
        pkg_root = Path(__file__).resolve().parents[3]
        if str(pkg_root) not in sys.path:
            sys.path.insert(0, str(pkg_root))
        from harness.barn.core.utils import normalize_symbol
    except Exception:
        # Last-resort fallback: simple normalizer that appends 'm' if missing.
        def normalize_symbol(s: str) -> str:
            return s if s.endswith('m') else s + 'm'

logger = logging.getLogger(__name__)


async def get_market_buffer(symbol: str, timeframe: str, size: int = 1000, user: Optional[dict] = None) -> Dict[str, Any]:
    """
    Get a simple rolling market data buffer.
    
    Args:
        symbol: Trading symbol (e.g., 'EURUSD', 'GBPUSD') - will auto-add 'm' suffix
        timeframe: Timeframe string ('1m', '5m', '15m', '30m', '1h', '4h', '1d')
        size: Number of candles in buffer (default 100)
        user: User dict with 'id' field for database-backed account resolution
        
    Returns:
        Dictionary with buffer data you can use directly:
        {
            'symbol': normalized symbol,
            'timeframe': timeframe,
            'size': buffer size,
            'data': list of OHLC candles,
            'buffer_obj': MarketBuffer instance for adding more data
        }
    """
    # Normalize symbol (add 'm' suffix)
    symbol = normalize_symbol(symbol)
    
    logger.info(f"Creating market buffer for {symbol} {timeframe} with size {size}")
    
    # Create buffer instance
    buffer = MarketBuffer(symbol, timeframe, size)

    # Try to get some historical data
    await buffer.load_initial_data(user=user)

    # Provide a simple interface expected by tests/consumers
    def add_candle(candle: Dict[str, Any]):
        return buffer.add_candle(candle)

    def get_latest(n: int = 1) -> List[Dict[str, Any]]:
        data = buffer.get_data()
        if n <= 0:
            return []
        return data[-n:]

    statistics = {
        'symbol': buffer.symbol,
        'timeframe': buffer.timeframe,
        'size': len(buffer),
        'max_size': buffer.max_size,
        'is_empty': len(buffer) == 0,
        'is_full': len(buffer) >= buffer.max_size,
    }

    # Return the interface expected by tests
    return {
        'buffer': buffer,
        'data': buffer.get_data(),
        'statistics': statistics,
        'add_candle': add_candle,
        'get_latest': get_latest,
    }


class MarketBuffer:
    """
    Simple rolling buffer for OHLC candles.
    Automatically removes oldest data when buffer reaches max size.
    """
    
    def __init__(self, symbol: str, timeframe: str, max_size: int = 100):
        """
        Initialize market buffer.
        
        Args:
            symbol: Trading symbol (already normalized)
            timeframe: Data timeframe 
            max_size: Maximum buffer size
        """
        self.symbol = symbol
        self.timeframe = timeframe
        self.max_size = max_size
        
        # Rolling buffer using deque for efficient operations
        self._buffer: Deque[Dict[str, Any]] = deque(maxlen=max_size)
        
        logger.info(f"Initialized MarketBuffer for {symbol} {timeframe} (max_size: {max_size})")
    
    async def load_initial_data(self, user: Optional[dict] = None):
        """
        Try to load some initial historical data.
        If it fails, just continue with empty buffer.
        
        Args:
            user: User dict with 'id' field for database-backed account resolution
        """
        try:
            # Try absolute import first (works when running as a module)
            try:
                from harness.barn.data.quotes import get_historical_ohlc
            except Exception:
                # Fallback to relative import when package context is available
                from .quotes import get_historical_ohlc

            logger.info(f"Fetching historical data for {self.symbol} {self.timeframe}")
            historical_candles = await get_historical_ohlc(self.symbol, self.timeframe, self.max_size, user=user)

            # Add historical data to buffer
            for candle in historical_candles:
                self._buffer.append(candle)

            logger.info(f"Loaded {len(self._buffer)} historical candles")

        except Exception as e:
            logger.warning(f"Could not load historical data: {e}. Starting with empty buffer.")
    
    def add_candle(self, candle: Dict[str, Any]):
        """
        Add a new candle to the buffer.
        
        Args:
            candle: OHLC candle dictionary with keys: time, open, high, low, close, volume
        """
        # Add symbol and timeframe to candle
        candle['symbol'] = self.symbol
        candle['timeframe'] = self.timeframe
        
        # Add to buffer (deque automatically handles max size)
        self._buffer.append(candle)
        
        logger.debug(f"Added candle to buffer (size: {len(self._buffer)})")
    
    def get_data(self) -> List[Dict[str, Any]]:
        """Get all candles in buffer as a list."""
        return list(self._buffer)
    
    def __len__(self) -> int:
        """Get number of candles in buffer."""
        return len(self._buffer)
    
    def __repr__(self) -> str:
        """String representation of buffer."""
        return f"MarketBuffer({self.symbol}, {self.timeframe}, {len(self._buffer)}/{self.max_size} candles)"


if __name__ == "__main__":
    # Enhanced async test harness with CLI options, multiple synthetic candles,
    # dynamic timestamps, and simple assertions for basic validation.
    import argparse
    import asyncio
    import json
    from datetime import datetime, timedelta
    import sys

    parser = argparse.ArgumentParser(description="Test MarketBuffer/Cli harness")
    parser.add_argument("--symbol", default="EURUSD", help="Trading symbol (e.g. EURUSD)")
    parser.add_argument("--timeframe", default="1m", help="Timeframe (e.g. 1m, 5m)")
    parser.add_argument("--size", type=int, default=10, help="Initial buffer size to request")
    parser.add_argument("--add-synthetic", type=int, default=3, help="Number of synthetic candles to add")
    args = parser.parse_args()

    async def _main():
        # If running this file directly, make sure the package root that contains
        # the `services` package is on sys.path so imports like
        # `from harness.core.utils import ...` work.
        try:
            from pathlib import Path
            pkg_root = Path(__file__).resolve().parents[3]
            pkg_root_str = str(pkg_root)
            if pkg_root_str not in sys.path:
                sys.path.insert(0, pkg_root_str)
        except Exception:
            # best-effort only; if it fails, let the import attempt raise below
            pass

        # Create a market buffer (will attempt to load historical data if available)
        result = await get_market_buffer(args.symbol, args.timeframe, size=args.size)

        print("Statistics:")
        print(json.dumps(result.get('statistics', {}), indent=2))

        data = result.get('data', [])
        print(f"Loaded {len(data)} candles")

        # Show latest candle(s)
        latest = result['get_latest'](1)
        print("Latest candle:")
        print(json.dumps(latest, indent=2))

        # Add multiple synthetic candles using current UTC timestamps
        now = datetime.utcnow()
        synthetic_count = max(0, args.add_synthetic)
        print(f"Adding {synthetic_count} synthetic candles...")

        for i in range(synthetic_count):
            ts = (now + timedelta(minutes=i)).isoformat(timespec='seconds') + 'Z'
            sample_candle = {
                'time': ts,
                'open': 1.1000 + 0.0001 * i,
                'high': 1.1005 + 0.0001 * i,
                'low': 1.0995 + 0.0001 * i,
                'close': 1.1002 + 0.0001 * i,
                'volume': 1000 + i * 10,
            }
            result['add_candle'](sample_candle)

        new_len = len(result['buffer'])
        print("After adding, buffer size:", new_len)
        print("Latest after add:")
        print(json.dumps(result['get_latest'](synthetic_count if synthetic_count>0 else 1), indent=2))

        # Simple assertions (unit-style). On failure, raise AssertionError which will
        # cause a non-zero exit code.
        try:
            # Buffer length should be original length + synthetic_count (unless historical
            # data filled to max_size in which case deque will cap it at max_size)
            orig_size = result['statistics'].get('size', 0)
            max_size = result['statistics'].get('max_size', args.size)
            expected_min = min(max_size, orig_size + synthetic_count)
            assert new_len >= expected_min, f"Buffer size {new_len} smaller than expected {expected_min}"

            # Last candle should have the symbol and timeframe set correctly
            last = result['get_latest'](1)[0]
            assert last.get('symbol') == result['buffer'].symbol, "Last candle symbol mismatch"
            assert last.get('timeframe') == result['buffer'].timeframe, "Last candle timeframe mismatch"

            print("All assertions passed.")
        except AssertionError as e:
            print("Assertion failed:", e)
            # Print a little more info for debugging
            print("Buffer repr:", repr(result['buffer']))
            print("Last 3 candles:", json.dumps(result['get_latest'](3), indent=2))
            # Exit with non-zero to signal test failure
            sys.exit(2)

    asyncio.run(_main())
