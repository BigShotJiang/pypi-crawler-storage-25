"""
Data Service Schema
===================
JSON schema definitions and tool mappings for market data functionality.
Covers live ticks, historical OHLC, and buffer management.
"""

from typing import Dict, Any, List, Optional
import datetime

# --- JSON Schema Dictionary for Data Tools ---
data_tools = {
    "get_live_ticks": {
        "name": "get_live_ticks",
        "description": "Subscribe to live tick data feed for real-time price updates.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Trading symbol (e.g., 'EURUSD', 'GBPUSD'). Will be automatically normalized with 'm' suffix for broker compatibility."
                }
            },
            "required": ["symbol"],
            "additionalProperties": False
        }
    },
    "get_historical_ohlc": {
        "name": "get_historical_ohlc",
        "description": "Fetch historical OHLC candle data for technical analysis and backtesting.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Trading symbol (e.g., 'EURUSD', 'GBPUSD'). Will be automatically normalized."
                },
                "timeframe": {
                    "type": "string",
                    "description": "Candle timeframe ('1m', '5m', '15m', '30m', '1h', '4h', '1d').",
                    "enum": ["1m", "5m", "15m", "30m", "1h", "4h", "1d"]
                },
                "limit": {
                    "type": "integer",
                    "description": "Number of candles to fetch (1-1000).",
                    "default": 1000,
                    "minimum": 1,
                    "maximum": 1000
                }
            },
            "required": ["symbol", "timeframe"],
            "additionalProperties": False
        }
    },
    "get_market_buffer": {
        "name": "get_market_buffer",
        "description": "Create a rolling market data buffer that maintains live OHLC data with automatic historical seeding.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Trading symbol (e.g., 'EURUSD', 'GBPUSD')."
                },
                "timeframe": {
                    "type": "string",
                    "description": "Candle timeframe for the buffer.",
                    "enum": ["1m", "5m", "15m", "30m", "1h", "4h", "1d"]
                },
                "buffer_size": {
                    "type": "integer",
                    "description": "Maximum number of candles in rolling buffer.",
                    "default": 1000,
                    "minimum": 10,
                    "maximum": 10000
                }
            },
            "required": ["symbol", "timeframe"],
            "additionalProperties": False
        }
    },
    "get_current_price": {
        "name": "get_current_price",
        "description": "Get the current bid/ask price for a trading symbol (uses latest OHLC candle).",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {
                    "type": "string",
                    "description": "Trading symbol (e.g., 'EURUSD', 'GBPUSD')."
                }
            },
            "required": ["symbol"],
            "additionalProperties": False
        }
    }
}

class DataServiceManager:
    """Manager class for data service operations with tool mapping"""
    
    def __init__(self):
        # Import functions with clean path setup
        import sys
        import os
        
        # Add the harness root to path
        harness_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../'))
        if harness_root not in sys.path:
            sys.path.insert(0, harness_root)
        
        # Also add current directory
        current_dir = os.path.dirname(__file__)
        if current_dir not in sys.path:
            sys.path.insert(0, current_dir)
        
        # Import the data functions (try absolute import first for script runs)
        try:
            from harness.barn.data.quotes import get_live_ticks, get_historical_ohlc
            from harness.barn.data.buffer import get_market_buffer
        except Exception:
            # Fallback to relative imports when package context is available
            from .quotes import get_live_ticks, get_historical_ohlc
            from .buffer import get_market_buffer
        
        self.get_live_ticks = get_live_ticks
        self.get_historical_ohlc = get_historical_ohlc
        self.get_market_buffer = get_market_buffer
        
        self.request_history = []
        
    def _log_request(self, function_name: str, params: Dict[str, Any], result: Any):
        """Log data service requests for debugging"""
        self.request_history.append({
            "timestamp": datetime.datetime.now().isoformat(),
            "function": function_name,
            "parameters": params,
            "success": result.get("success", False) if isinstance(result, dict) else bool(result),
            "result_type": type(result).__name__
        })
        
    async def fetch_live_ticks(self, symbol: str, user: Optional[dict] = None):
        """Fetch live tick data stream"""
        try:
            params = {"symbol": symbol}
            
            # This would return an async generator, so we handle it differently
            tick_generator = self.get_live_ticks(symbol, user=user)
            
            result = {
                "success": True,
                "stream": "active",
                "symbol": symbol,
                "timestamp": datetime.datetime.now().isoformat()
            }
            
            self._log_request("get_live_ticks", params, result)
            return result
            
        except Exception as e:
            error_result = {"success": False, "error": str(e)}
            self._log_request("get_live_ticks", {"symbol": symbol}, error_result)
            return error_result
            
    async def fetch_historical_ohlc(self, symbol: str, timeframe: str, limit: int = 1000, user: Optional[dict] = None):
        """Fetch historical OHLC candle data"""
        params = {"symbol": symbol, "timeframe": timeframe, "limit": limit}
        
        try:
            result = await self.get_historical_ohlc(symbol, timeframe, limit, user=user)
            self._log_request("get_historical_ohlc", params, result)
            
            if result:
                return {
                    "success": True,
                    "candles": result,
                    "count": len(result),
                    "symbol": symbol,
                    "timeframe": timeframe,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": "No historical data returned",
                    "candles": []
                }
                
        except Exception as e:
            error_result = {"success": False, "error": str(e), "candles": []}
            self._log_request("get_historical_ohlc", params, error_result)
            return error_result
            
    async def fetch_market_buffer(self, symbol: str, timeframe: str, buffer_size: int = 1000, user: Optional[dict] = None):
        """Create and return market data buffer"""
        params = {"symbol": symbol, "timeframe": timeframe, "buffer_size": buffer_size}
        
        try:
            result = await self.get_market_buffer(symbol, timeframe, buffer_size, user=user)
            self._log_request("get_market_buffer", params, result)
            
            if result:
                return {
                    "success": True,
                    "buffer_info": result,
                    "symbol": symbol,
                    "timeframe": timeframe,
                    "buffer_size": buffer_size,
                    "timestamp": datetime.datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": "Failed to create market buffer",
                    "buffer_info": None
                }
                
        except Exception as e:
            error_result = {"success": False, "error": str(e), "buffer_info": None}
            self._log_request("get_market_buffer", params, error_result)
            return error_result
    
    async def fetch_current_price(self, symbol: str, user: Optional[dict] = None):
        """Fetch current price using FarmClient's direct price API"""
        try:
            from harness.barn.core import FarmClient
            from harness.barn.core.utils import normalize_symbol
            
            params = {"symbol": symbol}
            normalized_symbol = normalize_symbol(symbol)
            
            # Use FarmClient's direct price API (more reliable than historical OHLC)
            client = await FarmClient.get(user=user)
            price_data = await client.get_current_price(normalized_symbol)
            
            self._log_request("get_current_price", params, price_data)
            
            if price_data:
                return {
                    "success": True,
                    "symbol": symbol,
                    "price": {
                        "bid": price_data.get("bid", 0),
                        "ask": price_data.get("ask", 0),
                        "open": price_data.get("open", 0),
                        "high": price_data.get("high", 0),
                        "low": price_data.get("low", 0),
                        "close": price_data.get("close", price_data.get("bid", 0)),
                        "timestamp": str(price_data.get("time", ""))
                    },
                    "timestamp": datetime.datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": "No price data available",
                    "symbol": symbol,
                    "price": None
                }
                
        except Exception as e:
            error_result = {"success": False, "error": str(e), "symbol": symbol, "price": None}
            self._log_request("get_current_price", {"symbol": symbol}, error_result)
            return error_result
    
    def get_request_history(self, limit: int = 10):
        """Get recent data service request history"""
        return {
            "success": True,
            "history": self.request_history[-limit:] if self.request_history else [],
            "total_requests": len(self.request_history)
        }
    
    def clear_request_history(self):
        """Clear request history"""
        self.request_history.clear()
        return {"success": True, "message": "Request history cleared"}
    
    def get_data_status(self):
        """Get data service status and statistics"""
        return {
            "success": True,
            "status": {
                "service_name": "DataService",
                "functions_available": ["live_ticks", "historical_ohlc", "market_buffer"],
                "total_requests": len(self.request_history),
                "recent_requests": len([r for r in self.request_history 
                                      if datetime.datetime.fromisoformat(r["timestamp"]) > 
                                      datetime.datetime.now() - datetime.timedelta(hours=1)]),
                "service_ready": True,
                "last_request": self.request_history[-1] if self.request_history else None
            }
        }

    def fetch_available_symbols(self, category: Optional[str] = None, user: Optional[dict] = None):
        """Get list of available symbols (hardcoded for Exness demo)"""
        # Curated list of symbols supported by Exness demo accounts
        # Note: All symbols have 'm' suffix for micro accounts
        all_symbols = {
            "forex": [
                "EURUSDm", "GBPUSDm", "USDJPYm", "USDCADm", "AUDUSDm", 
                "NZDUSDm", "USDCHFm", "EURGBPm", "EURJPYm", "GBPJPYm"
            ],
            "metals": [
                "XAUUSDm", "XAGUSDm"
            ],
            "crypto": [
                "BTCUSDm", "ETHUSDm", "LTCUSDm", "XRPUSDm"
            ],
            "indices": [
                "US30m", "USTECm", "US500m", "DE30m" 
            ]
        }
        
        result_symbols = []
        if category:
            # Return specific category
            result_symbols = all_symbols.get(category.lower(), [])
        else:
            # Return all symbols flattened
            for cat_symbols in all_symbols.values():
                result_symbols.extend(cat_symbols)
                
        return {
            "success": True,
            "count": len(result_symbols),
            "category": category or "all",
            "symbols": sorted(result_symbols)
        }

# Dictionary mapping tool names to their function implementations  
data_tool_implementations = {
    "get_live_ticks": lambda manager: manager.fetch_live_ticks,
    "get_historical_ohlc": lambda manager: manager.fetch_historical_ohlc,
    "get_market_buffer": lambda manager: manager.fetch_market_buffer,
    "get_current_price": lambda manager: manager.fetch_current_price,
}

# Extended tools for additional functionality
extended_data_tools = {
    "get_request_history": {
        "name": "get_request_history",
        "description": "Retrieves recent data service request history with metadata.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Number of recent requests to return.", "default": 10}
            },
            "additionalProperties": False
        }
    },
    "get_available_symbols": {
        "name": "get_available_symbols",
        "description": "Get list of available trading symbols supported by the broker.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string", 
                    "description": "Optional category filter (forex, crypto, metals, indices).",
                    "enum": ["forex", "crypto", "metals", "indices"]
                }
            },
            "additionalProperties": False
        }
    },
    "get_data_status": {
        "name": "get_data_status",
        "description": "Retrieves data service status and statistics.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "additionalProperties": False
        }
    },
    "clear_request_history": {
        "name": "clear_request_history", 
        "description": "Clears data service request history.",
        "strict": True,
        "parameters": {
            "type": "object",
            "properties": {},
            "additionalProperties": False
        }
    }
}

# Combine all tools
all_data_tools = {**data_tools, **extended_data_tools}

# Extended implementations
extended_data_implementations = {
    "get_request_history": lambda manager: manager.get_request_history,
    "get_data_status": lambda manager: manager.get_data_status,
    "clear_request_history": lambda manager: manager.clear_request_history,
    "get_available_symbols": lambda manager: manager.fetch_available_symbols,
}

# Combine all implementations
all_data_implementations = {**data_tool_implementations, **extended_data_implementations}

def main():
    """Main function for testing data schema"""
    print("=== Data Service Schema Test ===")
    
    print("Available data tools:")
    for tool_name, tool_schema in all_data_tools.items():
        print(f"  - {tool_name}: {tool_schema['description']}")
    
    print(f"\nTotal tools: {len(all_data_tools)}")
    
    # Example usage parameters
    print(f"\nExample parameters:")
    examples = {
        "get_live_ticks": {"symbol": "EURUSDm"},
        "get_historical_ohlc": {"symbol": "GBPUSDm", "timeframe": "1h", "limit": 500},
        "get_market_buffer": {"symbol": "USDJPYm", "timeframe": "15m", "buffer_size": 2000}
    }
    
    for tool_name, example_params in examples.items():
        print(f"  {tool_name}: {example_params}")

if __name__ == "__main__":
    main()
