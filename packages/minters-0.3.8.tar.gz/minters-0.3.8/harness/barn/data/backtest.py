"""Backtesting helpers for warming history and exporting OHLC datasets."""

from __future__ import annotations

import csv
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .quotes import get_historical_ohlc_range


def _to_ts(value: Any) -> int:
    if isinstance(value, datetime):
        dt = value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        return int(dt.timestamp())
    if isinstance(value, (int, float)):
        return int(value)
    s = str(value).strip()
    if s.isdigit():
        return int(s)
    if len(s) == 10 and s.count("-") == 2:
        dt = datetime.strptime(s, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        return int(dt.timestamp())
    dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", value).strip("_") or "dataset"


def _range_label(start_ts: int, end_ts: int) -> str:
    start = datetime.fromtimestamp(start_ts, tz=timezone.utc).strftime("%m_%d_%y")
    end = datetime.fromtimestamp(end_ts, tz=timezone.utc).strftime("%m_%d_%y")
    return f"{start}_to_{end}"


def _next_period_boundary_ts(cursor_ts: int, split_by: str) -> int:
    dt = datetime.fromtimestamp(cursor_ts, tz=timezone.utc)
    if split_by == "month":
        year = dt.year + (1 if dt.month == 12 else 0)
        month = 1 if dt.month == 12 else dt.month + 1
        return int(datetime(year, month, 1, tzinfo=timezone.utc).timestamp())
    if split_by == "quarter":
        quarter = (dt.month - 1) // 3
        next_start_month = quarter * 3 + 4
        year = dt.year
        if next_start_month > 12:
            next_start_month -= 12
            year += 1
        return int(datetime(year, next_start_month, 1, tzinfo=timezone.utc).timestamp())
    raise ValueError("split_by must be one of: month, quarter")


def _split_windows(start_ts: int, end_ts: int, split_by: Optional[str]) -> List[Tuple[int, int]]:
    if not split_by:
        return [(start_ts, end_ts)]

    windows: List[Tuple[int, int]] = []
    cursor = start_ts
    while cursor < end_ts:
        boundary = _next_period_boundary_ts(cursor, split_by)
        window_end = min(end_ts, boundary)
        if window_end <= cursor:
            break
        windows.append((cursor, window_end))
        cursor = window_end
    return windows


def _candle_ts(candle: Dict[str, Any]) -> Optional[int]:
    raw = candle.get("time")
    if raw is None:
        return None
    if isinstance(raw, datetime):
        dt = raw if raw.tzinfo else raw.replace(tzinfo=timezone.utc)
        return int(dt.timestamp())
    if isinstance(raw, (int, float)):
        return int(raw)
    s = str(raw).strip()
    try:
        return int(float(s))
    except ValueError:
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return int(dt.timestamp())
        except ValueError:
            return None


def _write_ohlc_csv(path: Path, rows: List[Dict[str, Any]]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    headers = ["time", "open", "high", "low", "close", "volume", "symbol", "timeframe"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "time": row.get("time"),
                "open": row.get("open"),
                "high": row.get("high"),
                "low": row.get("low"),
                "close": row.get("close"),
                "volume": row.get("volume"),
                "symbol": row.get("symbol"),
                "timeframe": row.get("timeframe"),
            })
    return path


async def warmup_and_export_ohlc_csv(
    *,
    contract_file: str | Path,
    name: str,
    symbol: str,
    timeframe: str,
    start_time: Any,
    end_time: Any,
    chunk_days: int = 30,
    limit_per_call: int = 5000,
    output_name: Optional[str] = None,
    split_by: Optional[str] = None,
    user: Optional[dict] = None,
) -> Path | List[Path]:
    """
    Warm up historical candles over a date range and export to CSV in contract root.

    The output file name is automatically augmented as:
    ``{name}_{mm_dd_yy_to_mm_dd_yy}.csv``

    Args:
        contract_file: Usually ``__file__`` from a contract script.
        name: Dataset base name.
        symbol: Trading symbol, e.g. ``XAUUSDm``.
        timeframe: Timeframe string, e.g. ``1h``.
        start_time: Unix timestamp/date/datetime start.
        end_time: Unix timestamp/date/datetime end.
        chunk_days: Window size per warmup request.
        limit_per_call: Max candles requested per chunk.
        output_name: Optional explicit CSV file name (without extension accepted).
        split_by: Optional period split mode: ``month`` or ``quarter``.
        user: Optional user dict for account resolution.
    """
    start_ts = _to_ts(start_time)
    end_ts = _to_ts(end_time)
    if end_ts <= start_ts:
        raise ValueError("end_time must be greater than start_time")

    contract_root = Path(contract_file).resolve().parent
    data_dir = contract_root / "data"
    base_name = _safe_name(output_name or name)
    if base_name.lower().endswith(".csv"):
        base_name = base_name[:-4]

    split_mode = split_by.strip().lower() if split_by else None
    if split_mode not in (None, "month", "quarter"):
        raise ValueError("split_by must be None, 'month', or 'quarter'")

    chunk_sec = max(1, chunk_days) * 86400

    async def _collect_window(window_start: int, window_end: int) -> List[Dict[str, Any]]:
        all_rows: List[Dict[str, Any]] = []
        cursor = window_start
        while cursor < window_end:
            call_end = min(window_end, cursor + chunk_sec)
            rows = await get_historical_ohlc_range(
                symbol=symbol,
                timeframe=timeframe,
                start_time=cursor,
                end_time=call_end,
                limit=limit_per_call,
                user=user,
            )
            all_rows.extend(rows)
            cursor = call_end

        # Deduplicate and sort by candle timestamp for clean backtesting files.
        dedup: Dict[int, Dict[str, Any]] = {}
        for row in all_rows:
            ts = _candle_ts(row)
            if ts is None:
                continue
            dedup[ts] = row
        return [dedup[k] for k in sorted(dedup.keys())]

    windows = _split_windows(start_ts, end_ts, split_mode)
    if not split_mode:
        rows = await _collect_window(start_ts, end_ts)
        file_name = f"{base_name}_{_range_label(start_ts, end_ts)}.csv"
        return _write_ohlc_csv(data_dir / file_name, rows)

    output_paths: List[Path] = []
    for window_start, window_end in windows:
        rows = await _collect_window(window_start, window_end)
        file_name = f"{base_name}_{_range_label(window_start, window_end)}.csv"
        path = _write_ohlc_csv(data_dir / file_name, rows)
        output_paths.append(path)
    return output_paths
