"""
Data Test Module
================

Comprehensive test for the terminal data module.
Tests live ticks, historical OHLC, and buffer functionality.
"""

import os
import sys
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any

# Load environment variables from .env file
try:
    from dotenv import load_dotenv
    # Load from the family root directory
    env_path = os.path.join(os.path.dirname(__file__), '../../../.env')
    load_dotenv(env_path)
    print(f"[OK] Loaded .env from: {env_path}")
except ImportError:
    print("[ERROR]  python-dotenv not installed. Install with: pip install python-dotenv")
except Exception as e:
    print(f"[ERROR]  Failed to load .env: {e}")

# Add the family directory to path for imports
harness_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../'))
if harness_root not in sys.path:
    sys.path.insert(0, harness_root)

# Add current directory to path
current_dir = os.path.dirname(__file__)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# Import the data functions
try:
    from harness.barn.data.quotes import get_live_ticks, get_historical_ohlc
    from harness.barn.data.buffer import get_market_buffer
    import harness.barn.data.schema as schema
    
    print("[OK] All data modules imported successfully")
    
except ImportError as e:
    print(f"[ERROR] Import error: {e}")
    print("[ERROR] Failed to import data modules")
    sys.exit(1)

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DataTester:
    """Test suite for data module functionality."""
    
    def __init__(self):
        self.test_results = {}
        
    async def test_historical_ohlc(self) -> bool:
        """Test historical OHLC data fetching."""
        logger.info("Testing historical OHLC data retrieval...")
        
        try:
            # Test get_historical_ohlc function
            symbol = "EURUSD"
            timeframe = "1h"
            limit = 50
            
            candles = await get_historical_ohlc(symbol, timeframe, limit)
            
            logger.info(f"Retrieved {len(candles)} candles for {symbol} {timeframe}")
            
            # Verify it returns a list
            assert isinstance(candles, list)
            
            # If there are candles, verify structure
            if candles:
                first_candle = candles[0]
                expected_fields = ['time', 'open', 'high', 'low', 'close']
                
                for field in expected_fields:
                    if field not in first_candle:
                        logger.error(f"Missing required field: {field}")
                        return False
                
                # Log sample candles
                for i, candle in enumerate(candles[:3]):  # Show first 3 candles
                    logger.info(f"  Candle {i+1}:")
                    logger.info(f"    Time: {candle.get('time', 'N/A')}")
                    logger.info(f"    OHLC: {candle.get('open', 0):.5f} / {candle.get('high', 0):.5f} / {candle.get('low', 0):.5f} / {candle.get('close', 0):.5f}")
                    logger.info(f"    Volume: {candle.get('volume', 0)}")
                
                # Verify data types and ranges
                assert isinstance(first_candle['open'], (int, float))
                assert isinstance(first_candle['high'], (int, float)) 
                assert isinstance(first_candle['low'], (int, float))
                assert isinstance(first_candle['close'], (int, float))
                assert first_candle['high'] >= first_candle['low']  # High >= Low
                
            logger.info("✓ Historical OHLC function working correctly")
            return True
            
        except Exception as e:
            logger.error(f"✗ Historical OHLC test failed: {e}")
            return False
    
    async def test_live_ticks(self) -> bool:
        """Test live tick data subscription.""" 
        logger.info("Testing live tick data subscription...")
        
        try:
            symbol = "EURUSD"
            tick_count = 0
            max_ticks = 5  # Test with just 5 ticks
            
            logger.info(f"Subscribing to live ticks for {symbol} (testing {max_ticks} ticks)")
            
            async for tick in get_live_ticks(symbol):
                tick_count += 1
                
                # Verify tick structure
                expected_fields = ['symbol', 'bid', 'ask', 'time', 'spread']
                for field in expected_fields:
                    if field not in tick:
                        logger.warning(f"Missing field in tick: {field}")
                
                logger.info(f"  Tick {tick_count}:")
                logger.info(f"    Symbol: {tick.get('symbol', 'N/A')}")
                logger.info(f"    Bid: {tick.get('bid', 0):.5f}")
                logger.info(f"    Ask: {tick.get('ask', 0):.5f}")
                logger.info(f"    Spread: {tick.get('spread', 0):.5f}")
                logger.info(f"    Time: {tick.get('time', 'N/A')}")
                
                # Verify data types and logic
                assert isinstance(tick['bid'], (int, float))
                assert isinstance(tick['ask'], (int, float))
                assert tick['ask'] >= tick['bid']  # Ask >= Bid
                assert tick['spread'] >= 0  # Spread >= 0
                
                # Stop after max_ticks for testing
                if tick_count >= max_ticks:
                    break
            
            logger.info(f"✓ Live ticks function working correctly (received {tick_count} ticks)")
            return True
            
        except Exception as e:
            logger.error(f"✗ Live ticks test failed: {e}")
            return False
    
    async def test_market_buffer(self) -> bool:
        """Test market buffer functionality."""
        logger.info("Testing market buffer functionality...")
        
        try:
            symbol = "GBPUSD"
            timeframe = "5m"
            buffer_size = 100
            
            logger.info(f"Creating market buffer for {symbol} {timeframe} with size {buffer_size}")
            
            # Create market buffer
            buffer_result = await get_market_buffer(symbol, timeframe, buffer_size)
            
            # Verify buffer structure
            expected_keys = ['buffer', 'data', 'statistics', 'add_candle', 'get_latest']
            for key in expected_keys:
                if key not in buffer_result:
                    logger.error(f"Missing key in buffer result: {key}")
                    return False
            
            # Get buffer statistics
            stats = buffer_result['statistics']
            data = buffer_result['data']
            
            logger.info("Buffer Statistics:")
            logger.info(f"  Symbol: {stats.get('symbol', 'N/A')}")
            logger.info(f"  Timeframe: {stats.get('timeframe', 'N/A')}")
            logger.info(f"  Size: {stats.get('size', 0)}")
            logger.info(f"  Max Size: {stats.get('max_size', 0)}")
            logger.info(f"  Is Empty: {stats.get('is_empty', True)}")
            logger.info(f"  Is Full: {stats.get('is_full', False)}")
            
            # Verify buffer has data
            if data:
                logger.info(f"  Buffer contains {len(data)} candles")
                
                # Test getting latest candles
                latest_3 = buffer_result['get_latest'](3)
                logger.info(f"  Latest 3 candles: {len(latest_3)} returned")
                
                # Test adding a new candle
                from datetime import datetime, timezone
                test_candle = {
                    'time': datetime.now(timezone.utc).isoformat(),
                    'open': 1.3000,
                    'high': 1.3010,
                    'low': 1.2990,
                    'close': 1.3005,
                    'volume': 100
                }
                
                buffer_result['add_candle'](test_candle)
                logger.info("  ✓ Successfully added test candle to buffer")
                
            else:
                logger.info("  Buffer is empty (this may be normal for new initialization)")
            
            logger.info("✓ Market buffer function working correctly")
            return True
            
        except Exception as e:
            logger.error(f"✗ Market buffer test failed: {e}")
            return False
    
    async def test_schema_functionality(self) -> bool:
        """Test schema and data service manager."""
        logger.info("Testing data schema functionality...")
        
        try:
            # Test creating DataServiceManager
            manager = schema.DataServiceManager()
            logger.info("✓ DataServiceManager created successfully")
            
            # Test schema tools
            tools = schema.all_data_tools
            logger.info(f"✓ Schema contains {len(tools)} tools")
            
            # Test data status
            status = manager.get_data_status()
            logger.info("Data Service Status:")
            logger.info(f"  Service Name: {status['status']['service_name']}")
            logger.info(f"  Functions Available: {status['status']['functions_available']}")
            logger.info(f"  Service Ready: {status['status']['service_ready']}")
            
            logger.info("✓ Schema functionality working correctly")
            return True
            
        except Exception as e:
            logger.error(f"✗ Schema test failed: {e}")
            return False
    
    async def run_all_tests(self) -> Dict[str, bool]:
        """Run all data tests and return results."""
        logger.info("Starting comprehensive data module tests...")
        logger.info("=" * 70)
        
        tests = [
            ("Historical OHLC", self.test_historical_ohlc),
            ("Live Ticks", self.test_live_ticks),
            ("Market Buffer", self.test_market_buffer),
            ("Schema Functionality", self.test_schema_functionality)
        ]
        
        results = {}
        passed = 0
        total = len(tests)
        
        for test_name, test_func in tests:
            logger.info(f"\n--- Running: {test_name} ---")
            try:
                result = await test_func()
                results[test_name] = result
                if result:
                    passed += 1
                    logger.info(f"✅ {test_name}: PASSED")
                else:
                    logger.error(f"❌ {test_name}: FAILED")
            except Exception as e:
                logger.error(f"💥 Test '{test_name}' crashed: {e}")
                results[test_name] = False
        
        logger.info("\n" + "=" * 70)
        logger.info("DATA MODULE TEST SUMMARY")
        logger.info("=" * 70)
        
        for test_name, result in results.items():
            status = "✅ PASS" if result else "❌ FAIL"
            logger.info(f"{test_name:25} {status}")
        
        logger.info(f"\nOverall: {passed}/{total} tests passed ({(passed/total)*100:.1f}%)")
        
        if passed == total:
            logger.info("🎉 ALL DATA TESTS PASSED!")
            logger.info("✅ The data module is fully functional!")
        elif passed >= total * 0.8:  # 80% success threshold
            logger.warning(f"⚠️  Most tests passed - data module is functional")
        else:
            logger.error(f"❌ Multiple tests failed")
            logger.error("🔧 Please review and fix the issues before proceeding")
        
        return results

async def main():
    """Main test execution function."""
    print("\n" + "="*70)
    print("FAMILY TRADING SYSTEM - DATA MODULE TEST")
    print("="*70)
    print(f"Test started at: {datetime.now()}")
    print(f"Python version: {sys.version}")
    
    # Check environment
    print("\nEnvironment Check:")
    token = os.environ.get('METAAPI_TOKEN')
    account_id = os.environ.get('METAAPI_ACCOUNT_ID')
    
    if token:
        print(f"METAAPI_TOKEN: Set (ends with ...{token[-10:]})")
    else:
        print("METAAPI_TOKEN: ❌ NOT SET")
        
    if account_id:
        print(f"METAAPI_ACCOUNT_ID: Set ({account_id})")
    else:
        print("METAAPI_ACCOUNT_ID: ❌ NOT SET")
    
    if not token or not account_id:
        print("\n⚠️  MetaAPI credentials not found!")
        print("Tests will run with mock data")
    
    # Run tests
    tester = DataTester()
    results = await tester.run_all_tests()
    
    # Exit with appropriate code
    if all(results.values()):
        print("\n🎉 All data module tests completed successfully!")
        print("🚀 The data module is ready for production use!")
        return 0
    else:
        failed_tests = [name for name, result in results.items() if not result]
        print(f"\n❌ {len(failed_tests)} test(s) failed: {', '.join(failed_tests)}")
        return 1

if __name__ == "__main__":
    # Make the script executable directly
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n⏹️  Tests interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Test execution failed: {e}")
        sys.exit(1)
