"""
Trade Test Module - Comprehensive MT5 Trading Operations Testing

Tests all trading functionality including:
- Market orders (BUY/SELL)
- Pending orders (LIMIT/STOP)
- Position management
- Order modifications and cancellations
"""

import asyncio
import sys
import os
from datetime import datetime, timedelta

# Add harness root to path
harness_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../'))
if harness_root not in sys.path:
    sys.path.insert(0, harness_root)

from harness.barn.trade.orders import (
    TradingOperations,
    create_market_buy,
    create_market_sell,
    create_buy_limit,
    create_sell_limit,
    OrderType,
    ActionType,
    ExpirationType
)
from harness.barn.trade.schema import get_trade_service_manager


async def test_market_orders():
    """Test market buy and sell orders"""
    print("\n=== Testing Market Orders ===")
    
    trader = TradingOperations()
    
    # Test market buy
    print("\n1. Testing Market BUY Order")
    try:
        result = await trader.market_buy(
            symbol="EURUSDm",
            volume=0.01,
            stop_loss=1.0800,
            take_profit=1.1200,
            comment="Test market buy order"
        )
        print(f"[INFO] Market BUY: {result}")
    except Exception as e:
        print(f"[ERROR] Market BUY failed: {e}")
    
    # Test market sell
    print("\n2. Testing Market SELL Order")
    try:
        result = await trader.market_sell(
            symbol="GBPUSDm",
            volume=0.02,
            stop_loss=1.2800,
            take_profit=1.2400,
            comment="Test market sell order"
        )
        print(f"[INFO] Market SELL: {result}")
    except Exception as e:
        print(f"[ERROR] Market SELL failed: {e}")


async def test_pending_orders():
    """Test pending limit and stop orders"""
    print("\n=== Testing Pending Orders ===")
    
    trader = TradingOperations()
    
    # Test buy limit
    print("\n1. Testing BUY LIMIT Order")
    try:
        result = await trader.buy_limit(
            symbol="USDJPYm",
            volume=0.01,
            open_price=148.50,
            stop_loss=147.00,
            take_profit=150.00,
            expiration_type=ExpirationType.ORDER_TIME_GTC,
            comment="Test buy limit order"
        )
        print(f"[INFO] BUY LIMIT: {result}")
    except Exception as e:
        print(f"[ERROR] BUY LIMIT failed: {e}")
    
    # Test sell stop
    print("\n2. Testing SELL STOP Order")
    try:
        result = await trader.sell_stop(
            symbol="AUDUSDm",
            volume=0.01,
            open_price=0.6500,
            stop_loss=0.6600,
            take_profit=0.6400,
            expiration_type=ExpirationType.ORDER_TIME_DAY,
            comment="Test sell stop order"
        )
        print(f"[INFO] SELL STOP: {result}")
    except Exception as e:
        print(f"[ERROR] SELL STOP failed: {e}")


async def test_position_management():
    """Test position modification and closing"""
    print("\n=== Testing Position Management ===")
    
    trader = TradingOperations()
    
    # Test position modification
    print("\n1. Testing Position Modification")
    try:
        result = await trader.modify_position(
            position_id="12345678",
            stop_loss=1.0850,
            take_profit=1.1150
        )
        print(f"[INFO] Position MODIFY: {result}")
    except Exception as e:
        print(f"[ERROR] Position MODIFY failed: {e}")
    
    # Test partial close
    print("\n2. Testing Partial Position Close")
    try:
        result = await trader.close_position_partial(
            position_id="12345678",
            volume=0.005
        )
        print(f"[INFO] Position PARTIAL CLOSE: {result}")
    except Exception as e:
        print(f"[ERROR] Position PARTIAL CLOSE failed: {e}")
    
    # Test full close
    print("\n3. Testing Full Position Close")
    try:
        result = await trader.close_position_full(
            position_id="87654321"
        )
        print(f"[INFO] Position FULL CLOSE: {result}")
    except Exception as e:
        print(f"[ERROR] Position FULL CLOSE failed: {e}")


async def test_order_management():
    """Test order modification and cancellation"""
    print("\n=== Testing Order Management ===")
    
    trader = TradingOperations()
    
    # Test order modification
    print("\n1. Testing Order Modification")
    try:
        result = await trader.modify_order(
            order_id="98765432",
            open_price=1.0950,
            stop_loss=1.0850,
            take_profit=1.1150
        )
        print(f"[INFO] Order MODIFY: {result}")
    except Exception as e:
        print(f"[ERROR] Order MODIFY failed: {e}")
    
    # Test order cancellation
    print("\n2. Testing Order Cancellation")
    try:
        result = await trader.cancel_order(
            order_id="98765432"
        )
        print(f"[INFO] Order CANCEL: {result}")
    except Exception as e:
        print(f"[ERROR] Order CANCEL failed: {e}")


async def test_convenience_functions():
    """Test convenience functions"""
    print("\n=== Testing Convenience Functions ===")
    
    # Test convenience market buy
    print("\n1. Testing Convenience Market BUY")
    try:
        result = await create_market_buy(
            symbol="EURGBPm",
            volume=0.01,
            stop_loss=0.8400,
            take_profit=0.8600
        )
        print(f"[INFO] Convenience Market BUY: {result}")
    except Exception as e:
        print(f"[ERROR] Convenience Market BUY failed: {e}")
    
    # Test convenience limit order
    print("\n2. Testing Convenience BUY LIMIT")
    try:
        result = await create_buy_limit(
            symbol="USDCHFm",
            volume=0.01,
            open_price=0.8800,
            stop_loss=0.8750,
            take_profit=0.8900
        )
        print(f"[INFO] Convenience BUY LIMIT: {result}")
    except Exception as e:
        print(f"[ERROR] Convenience BUY LIMIT failed: {e}")


def test_schema_validation():
    """Test schema and validation functionality"""
    print("\n=== Testing Schema Validation ===")
    
    manager = get_trade_service_manager()
    
    # Test getting tool schema
    print("\n1. Testing Tool Schema Retrieval")
    market_buy_schema = manager.get_tool_schema("market_orders", "market_buy")
    if market_buy_schema:
        print(f"[INFO] Market BUY schema: {market_buy_schema['description']}")
    else:
        print("[ERROR] Failed to get market BUY schema")
    
    # Test order validation
    print("\n2. Testing Order Validation")
    test_request = {
        "symbol": "EURUSDm",
        "volume": 0.01,
        "stopLoss": 1.0800,
        "takeProfit": 1.1200
    }
    
    validation = manager.validate_order_request("ORDER_TYPE_BUY", test_request)
    if validation["valid"]:
        print(f"[INFO] Order validation passed: {validation}")
    else:
        print(f"[ERROR] Order validation failed: {validation['errors']}")
    
    # Test invalid order validation
    print("\n3. Testing Invalid Order Validation")
    invalid_request = {
        "symbol": "EURUSDm"
        # Missing required volume
    }
    
    validation = manager.validate_order_request("ORDER_TYPE_BUY", invalid_request)
    if not validation["valid"]:
        print(f"[INFO] Invalid order correctly rejected: {validation['errors']}")
    else:
        print(f"[ERROR] Invalid order incorrectly accepted")


def test_enum_definitions():
    """Test enum definitions"""
    print("\n=== Testing Enum Definitions ===")
    
    # Test OrderType enum
    print("\n1. Testing OrderType Enum")
    try:
        buy_order = OrderType.ORDER_TYPE_BUY
        sell_limit = OrderType.ORDER_TYPE_SELL_LIMIT
        print(f"[INFO] OrderType enum: BUY={buy_order.value}, SELL_LIMIT={sell_limit.value}")
    except Exception as e:
        print(f"[ERROR] OrderType enum failed: {e}")
    
    # Test ActionType enum
    print("\n2. Testing ActionType Enum")
    try:
        position_modify = ActionType.POSITION_MODIFY
        order_cancel = ActionType.ORDER_CANCEL
        print(f"[INFO] ActionType enum: POSITION_MODIFY={position_modify.value}, ORDER_CANCEL={order_cancel.value}")
    except Exception as e:
        print(f"[ERROR] ActionType enum failed: {e}")
    
    # Test ExpirationType enum
    print("\n3. Testing ExpirationType Enum")
    try:
        gtc = ExpirationType.ORDER_TIME_GTC
        day = ExpirationType.ORDER_TIME_DAY
        print(f"[INFO] ExpirationType enum: GTC={gtc.value}, DAY={day.value}")
    except Exception as e:
        print(f"[ERROR] ExpirationType enum failed: {e}")


async def run_all_tests():
    """Run all trade module tests"""
    print("🚀 Starting Trade Module Tests...")
    print("=" * 50)
    
    # Test all functionality
    await test_market_orders()
    await test_pending_orders()
    await test_position_management()
    await test_order_management()
    await test_convenience_functions()
    
    # Test schema and validation
    test_schema_validation()
    test_enum_definitions()
    
    print("\n" + "=" * 50)
    print("[INFO] Trade Module Tests Completed!")
    print("All trading operations are properly structured and ready for use.")
    print("\nNote: Tests use mock responses. Real trading requires:")
    print("- Valid MetaAPI credentials")
    print("- Active broker connection")
    print("- Sufficient account balance")


if __name__ == "__main__":
    asyncio.run(run_all_tests())
