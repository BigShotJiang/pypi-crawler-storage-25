"""
Trade Schema Module - MT5 Trading Operations Schema

This module defines the schema for trading operations including:
- Order type definitions
- Trade action mappings
- Service integration tools
"""

from typing import Dict, Any, List, Optional
from enum import Enum


class TradeServiceManager:
    """
    Service manager for trading operations
    
    Provides schema definitions and tool mappings for all MT5 trading operations
    including market orders, pending orders, position management, and bulk operations.
    """
    
    def __init__(self):
        self.tools = {
            "market_orders": {
                "market_buy": {
                    "description": "Execute market BUY order immediately at current price",
                    "parameters": {
                        "symbol": {"type": "string", "required": True, "description": "Trading symbol (e.g., 'EURUSDm')"},
                        "volume": {"type": "number", "required": True, "description": "Order volume in lots"},
                        "stop_loss": {"type": "number", "required": False, "description": "Stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "Take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number for EA identification"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "filling_modes": {"type": "array", "required": False, "description": "Allowed filling modes in order of priority (ORDER_FILLING_FOK, ORDER_FILLING_IOC, ORDER_FILLING_RETURN)"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and execution details"
                },
                "market_sell": {
                    "description": "Execute market SELL order immediately at current price",
                    "parameters": {
                        "symbol": {"type": "string", "required": True, "description": "Trading symbol (e.g., 'EURUSDm')"},
                        "volume": {"type": "number", "required": True, "description": "Order volume in lots"},
                        "stop_loss": {"type": "number", "required": False, "description": "Stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "Take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number for EA identification"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "filling_modes": {"type": "array", "required": False, "description": "Allowed filling modes in order of priority (ORDER_FILLING_FOK, ORDER_FILLING_IOC, ORDER_FILLING_RETURN)"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and execution details"
                }
            },
            "pending_orders": {
                "buy_limit": {
                    "description": "Place BUY LIMIT order (buy when price drops to specified level)",
                    "parameters": {
                        "symbol": {"type": "string", "required": True, "description": "Trading symbol"},
                        "volume": {"type": "number", "required": True, "description": "Order volume in lots"},
                        "open_price": {"type": "number", "required": True, "description": "Price level to execute order"},
                        "stop_loss": {"type": "number", "required": False, "description": "Stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "Take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "expiration_type": {"type": "string", "required": False, "description": "Order expiration type (ORDER_TIME_GTC, ORDER_TIME_DAY, ORDER_TIME_SPECIFIED, ORDER_TIME_SPECIFIED_DAY)", "default": "ORDER_TIME_GTC"},
                        "expiration_time": {"type": "string", "required": False, "description": "Order expiration time (ISO format)"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and placement details"
                },
                "sell_limit": {
                    "description": "Place SELL LIMIT order (sell when price rises to specified level)",
                    "parameters": {
                        "symbol": {"type": "string", "required": True, "description": "Trading symbol"},
                        "volume": {"type": "number", "required": True, "description": "Order volume in lots"},
                        "open_price": {"type": "number", "required": True, "description": "Price level to execute order"},
                        "stop_loss": {"type": "number", "required": False, "description": "Stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "Take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "expiration_type": {"type": "string", "required": False, "description": "Order expiration type (ORDER_TIME_GTC, ORDER_TIME_DAY, ORDER_TIME_SPECIFIED, ORDER_TIME_SPECIFIED_DAY)", "default": "ORDER_TIME_GTC"},
                        "expiration_time": {"type": "string", "required": False, "description": "Order expiration time (ISO format)"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and placement details"
                },
                "buy_stop": {
                    "description": "Place BUY STOP order (buy when price rises to specified level)",
                    "parameters": {
                        "symbol": {"type": "string", "required": True, "description": "Trading symbol"},
                        "volume": {"type": "number", "required": True, "description": "Order volume in lots"},
                        "open_price": {"type": "number", "required": True, "description": "Price level to execute order"},
                        "stop_loss": {"type": "number", "required": False, "description": "Stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "Take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "expiration_type": {"type": "string", "required": False, "description": "Order expiration type (ORDER_TIME_GTC, ORDER_TIME_DAY, ORDER_TIME_SPECIFIED, ORDER_TIME_SPECIFIED_DAY)", "default": "ORDER_TIME_GTC"},
                        "expiration_time": {"type": "string", "required": False, "description": "Order expiration time (ISO format)"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and placement details"
                },
                "sell_stop": {
                    "description": "Place SELL STOP order (sell when price drops to specified level)",
                    "parameters": {
                        "symbol": {"type": "string", "required": True, "description": "Trading symbol"},
                        "volume": {"type": "number", "required": True, "description": "Order volume in lots"},
                        "open_price": {"type": "number", "required": True, "description": "Price level to execute order"},
                        "stop_loss": {"type": "number", "required": False, "description": "Stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "Take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "expiration_type": {"type": "string", "required": False, "description": "Order expiration type (ORDER_TIME_GTC, ORDER_TIME_DAY, ORDER_TIME_SPECIFIED, ORDER_TIME_SPECIFIED_DAY)", "default": "ORDER_TIME_GTC"},
                        "expiration_time": {"type": "string", "required": False, "description": "Order expiration time (ISO format)"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and placement details"
                }
            },
            "stop_limit_orders": {
                "buy_stop_limit": {
                    "description": "Place BUY STOP LIMIT order (two-stage order with stop and limit prices)",
                    "parameters": {
                        "symbol": {"type": "string", "required": True, "description": "Trading symbol"},
                        "volume": {"type": "number", "required": True, "description": "Order volume in lots"},
                        "open_price": {"type": "number", "required": True, "description": "Stop price level"},
                        "stop_limit_price": {"type": "number", "required": True, "description": "Limit price level"},
                        "stop_loss": {"type": "number", "required": False, "description": "Stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "Take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "expiration_type": {"type": "string", "required": False, "description": "Order expiration type (ORDER_TIME_GTC, ORDER_TIME_DAY, ORDER_TIME_SPECIFIED, ORDER_TIME_SPECIFIED_DAY)", "default": "ORDER_TIME_GTC"},
                        "expiration_time": {"type": "string", "required": False, "description": "Order expiration time (ISO format)"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and placement details"
                },
                "sell_stop_limit": {
                    "description": "Place SELL STOP LIMIT order (two-stage order with stop and limit prices)",
                    "parameters": {
                        "symbol": {"type": "string", "required": True, "description": "Trading symbol"},
                        "volume": {"type": "number", "required": True, "description": "Order volume in lots"},
                        "open_price": {"type": "number", "required": True, "description": "Stop price level"},
                        "stop_limit_price": {"type": "number", "required": True, "description": "Limit price level"},
                        "stop_loss": {"type": "number", "required": False, "description": "Stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "Take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "expiration_type": {"type": "string", "required": False, "description": "Order expiration type (ORDER_TIME_GTC, ORDER_TIME_DAY, ORDER_TIME_SPECIFIED, ORDER_TIME_SPECIFIED_DAY)", "default": "ORDER_TIME_GTC"},
                        "expiration_time": {"type": "string", "required": False, "description": "Order expiration time (ISO format)"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and placement details"
                }
            },
            "position_management": {
                "modify_position": {
                    "description": "Modify position stop loss and/or take profit levels",
                    "parameters": {
                        "position_id": {"type": "string", "required": True, "description": "Position ID to modify"},
                        "stop_loss": {"type": "number", "required": False, "description": "New stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "New take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with position ID, status, and modification details"
                },
                "close_position_partial": {
                    "description": "Partially close a position",
                    "parameters": {
                        "position_id": {"type": "string", "required": True, "description": "Position ID to partially close"},
                        "volume": {"type": "number", "required": True, "description": "Volume to close (in lots)"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "filling_modes": {"type": "array", "required": False, "description": "Allowed filling modes in order of priority"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order and position IDs, status"
                },
                "close_position_full": {
                    "description": "Close a position completely by position ID (no symbol or volume required)",
                    "parameters": {
                        "position_id": {"type": "string", "required": True, "description": "Position ID to close"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "filling_modes": {"type": "array", "required": False, "description": "Allowed filling modes in order of priority"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order and position IDs, status"
                },
                "close_position_by_opposite": {
                    "description": "Close a position by an opposite position (hedge closing)",
                    "parameters": {
                        "position_id": {"type": "string", "required": True, "description": "Position ID to close"},
                        "opposite_position_id": {"type": "string", "required": True, "description": "Opposite position ID to close by"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "filling_modes": {"type": "array", "required": False, "description": "Allowed filling modes in order of priority"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with both position IDs and status"
                },
                "close_all_positions_by_symbol": {
                    "description": "Close all positions for a specific symbol",
                    "parameters": {
                        "symbol": {"type": "string", "required": True, "description": "Trading symbol to close all positions for"},
                        "comment": {"type": "string", "required": False, "description": "Order comment"},
                        "client_id": {"type": "string", "required": False, "description": "Client-assigned ID"},
                        "magic": {"type": "integer", "required": False, "description": "Magic number"},
                        "slippage": {"type": "number", "required": False, "description": "Slippage in points"},
                        "filling_modes": {"type": "array", "required": False, "description": "Allowed filling modes in order of priority"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order and position IDs, status"
                }
            },
            "order_management": {
                "modify_order": {
                    "description": "Modify a pending order",
                    "parameters": {
                        "order_id": {"type": "string", "required": True, "description": "Order ID to modify"},
                        "open_price": {"type": "number", "required": False, "description": "New open price"},
                        "stop_loss": {"type": "number", "required": False, "description": "New stop loss price"},
                        "take_profit": {"type": "number", "required": False, "description": "New take profit price"},
                        "stop_loss_units": {"type": "string", "required": False, "description": "Stop loss units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "take_profit_units": {"type": "string", "required": False, "description": "Take profit units (ABSOLUTE_PRICE, RELATIVE_PRICE, RELATIVE_POINTS, RELATIVE_PIPS, RELATIVE_CURRENCY, RELATIVE_BALANCE_PERCENTAGE)", "default": "ABSOLUTE_PRICE"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "trailing_stop_loss": {"type": "object", "required": False, "description": "Trailing stop loss configuration with distance and/or threshold settings. Example: {'distance': {'distance': 0.1, 'units': 'RELATIVE_PRICE'}}"},
                        "stop_limit_price": {"type": "number", "required": False, "description": "New stop limit price for stop-limit orders"},
                        "expiration_type": {"type": "string", "required": False, "description": "New expiration type (ORDER_TIME_GTC, ORDER_TIME_DAY, ORDER_TIME_SPECIFIED, ORDER_TIME_SPECIFIED_DAY)"},
                        "expiration_time": {"type": "string", "required": False, "description": "New expiration time (ISO format)"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and modification details"
                },
                "cancel_order": {
                    "description": "Cancel a pending order",
                    "parameters": {
                        "order_id": {"type": "string", "required": True, "description": "Order ID to cancel"},
                        "user": {"type": "object", "required": False, "description": "User context for database-backed account resolution"},
                    },
                    "returns": "Dict with order ID, status, and cancellation details"
                }
            }
        }
        
        self.order_types = {
            "market": [
                "ORDER_TYPE_BUY",
                "ORDER_TYPE_SELL"
            ],
            "pending": [
                "ORDER_TYPE_BUY_LIMIT",
                "ORDER_TYPE_SELL_LIMIT", 
                "ORDER_TYPE_BUY_STOP",
                "ORDER_TYPE_SELL_STOP"
            ],
            "stop_limit": [
                "ORDER_TYPE_BUY_STOP_LIMIT",
                "ORDER_TYPE_SELL_STOP_LIMIT"
            ]
        }
        
        self.action_types = {
            "order_creation": [
                "ORDER_TYPE_BUY",
                "ORDER_TYPE_SELL",
                "ORDER_TYPE_BUY_LIMIT",
                "ORDER_TYPE_SELL_LIMIT",
                "ORDER_TYPE_BUY_STOP", 
                "ORDER_TYPE_SELL_STOP",
                "ORDER_TYPE_BUY_STOP_LIMIT",
                "ORDER_TYPE_SELL_STOP_LIMIT"
            ],
            "position_management": [
                "POSITION_MODIFY",
                "POSITION_PARTIAL",
                "POSITION_CLOSE_ID",
                "POSITION_CLOSE_BY",
                "POSITIONS_CLOSE_SYMBOL"
            ],
            "order_management": [
                "ORDER_MODIFY",
                "ORDER_CANCEL"
            ]
        }
        
        self.filling_modes = [
            "ORDER_FILLING_FOK",     # Fill or Kill
            "ORDER_FILLING_IOC",     # Immediate or Cancel  
            "ORDER_FILLING_RETURN"   # Return (partial fills allowed)
        ]
        
        self.expiration_types = [
            "ORDER_TIME_GTC",          # Good Till Cancelled
            "ORDER_TIME_DAY",          # Good for Day
            "ORDER_TIME_SPECIFIED",    # Good Till Specified Time
            "ORDER_TIME_SPECIFIED_DAY" # Good Till Specified Day
        ]
        
        self.price_units = [
            "ABSOLUTE_PRICE",              # Absolute price value
            "RELATIVE_PRICE",              # Relative to current price
            "RELATIVE_POINTS",             # Relative in points
            "RELATIVE_PIPS",               # Relative in pips
            "RELATIVE_CURRENCY",           # Relative in account currency
            "RELATIVE_BALANCE_PERCENTAGE"  # Relative as balance percentage
        ]
    
    def get_tool_schema(self, category: str, tool_name: str) -> Optional[Dict[str, Any]]:
        """
        Get schema for specific trading tool
        
        Args:
            category: Tool category (market_orders, pending_orders, etc.)
            tool_name: Specific tool name
            
        Returns:
            Tool schema dictionary or None if not found
        """
        if category in self.tools and tool_name in self.tools[category]:
            return self.tools[category][tool_name]
        return None
    
    def get_all_tools(self) -> Dict[str, Any]:
        """Get all available trading tools"""
        return self.tools
    
    def get_order_types(self, category: Optional[str] = None) -> List[str]:
        """
        Get order types by category or all
        
        Args:
            category: Order category (market, pending, stop_limit) or None for all
            
        Returns:
            List of order type strings
        """
        if category and category in self.order_types:
            return self.order_types[category]
        
        # Return all order types
        all_types = []
        for types in self.order_types.values():
            all_types.extend(types)
        return all_types
    
    def get_action_types(self, category: Optional[str] = None) -> List[str]:
        """
        Get action types by category or all
        
        Args:
            category: Action category (order_creation, position_management, order_management) or None for all
            
        Returns:
            List of action type strings
        """
        if category and category in self.action_types:
            return self.action_types[category]
        
        # Return all action types
        all_types = []
        for types in self.action_types.values():
            all_types.extend(types)
        return all_types
    
    def validate_order_request(self, action_type: str, request: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate trading order request
        
        Args:
            action_type: MetaAPI action type
            request: Order request dictionary
            
        Returns:
            Validation result with success status and any errors
        """
        errors = []
        
        # Check if action type is valid
        if action_type not in self.get_action_types():
            errors.append(f"Invalid action type: {action_type}")
        
        # Basic required field validation
        required_fields = {
            "ORDER_TYPE_BUY": ["symbol", "volume"],
            "ORDER_TYPE_SELL": ["symbol", "volume"],
            "ORDER_TYPE_BUY_LIMIT": ["symbol", "volume", "openPrice"],
            "ORDER_TYPE_SELL_LIMIT": ["symbol", "volume", "openPrice"],
            "ORDER_TYPE_BUY_STOP": ["symbol", "volume", "openPrice"],
            "ORDER_TYPE_SELL_STOP": ["symbol", "volume", "openPrice"],
            "ORDER_TYPE_BUY_STOP_LIMIT": ["symbol", "volume", "openPrice", "stopLimitPrice"],
            "ORDER_TYPE_SELL_STOP_LIMIT": ["symbol", "volume", "openPrice", "stopLimitPrice"],
            "POSITION_MODIFY": ["positionId"],
            "POSITION_PARTIAL": ["positionId", "volume"],
            "POSITION_CLOSE_ID": ["positionId"],
            "POSITION_CLOSE_BY": ["positionId", "closeByPositionId"],
            "POSITIONS_CLOSE_SYMBOL": ["symbol"],
            "ORDER_MODIFY": ["orderId"],
            "ORDER_CANCEL": ["orderId"]
        }
        
        if action_type in required_fields:
            for field in required_fields[action_type]:
                if field not in request:
                    errors.append(f"Missing required field: {field}")
        
        # Volume validation
        if "volume" in request:
            try:
                volume = float(request["volume"])
                if volume <= 0:
                    errors.append("Volume must be positive")
                if volume > 100:  # Reasonable upper limit
                    errors.append("Volume exceeds reasonable limit (100 lots)")
            except (ValueError, TypeError):
                errors.append("Volume must be a valid number")
        
        # Price validation
        price_fields = ["openPrice", "stopLoss", "takeProfit", "stopLimitPrice"]
        for field in price_fields:
            if field in request:
                try:
                    price = float(request[field])
                    if price <= 0:
                        errors.append(f"{field} must be positive")
                except (ValueError, TypeError):
                    errors.append(f"{field} must be a valid number")
        
        # Units validation
        if "stopLossUnits" in request and request["stopLossUnits"] not in self.price_units:
            errors.append(f"Invalid stopLossUnits: {request['stopLossUnits']}")
        if "takeProfitUnits" in request and request["takeProfitUnits"] not in self.price_units:
            errors.append(f"Invalid takeProfitUnits: {request['takeProfitUnits']}")
            
        # Filling modes validation
        if "fillingModes" in request:
            if not isinstance(request["fillingModes"], list):
                errors.append("fillingModes must be a list")
            else:
                for mode in request["fillingModes"]:
                    if mode not in self.filling_modes:
                        errors.append(f"Invalid filling mode: {mode}")
        
        # Expiration validation for pending orders
        if "expiration" in request:
            exp = request["expiration"]
            if not isinstance(exp, dict):
                errors.append("expiration must be an object")
            elif "type" not in exp:
                errors.append("expiration.type is required")
            elif exp["type"] not in self.expiration_types:
                errors.append(f"Invalid expiration type: {exp['type']}")
                
        # Slippage validation
        if "slippage" in request:
            try:
                slippage = float(request["slippage"])
                if slippage < 0:
                    errors.append("Slippage must be non-negative")
            except (ValueError, TypeError):
                errors.append("Slippage must be a valid number")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "action_type": action_type,
            "request": request
        }


def get_trade_service_manager() -> TradeServiceManager:
    """Get global trade service manager instance"""
    return TradeServiceManager()


# Export schemas for easy access
TRADE_SCHEMAS = TradeServiceManager().get_all_tools()
ORDER_TYPES = TradeServiceManager().get_order_types()
ACTION_TYPES = TradeServiceManager().get_action_types()
FILLING_MODES = TradeServiceManager().filling_modes
EXPIRATION_TYPES = TradeServiceManager().expiration_types
PRICE_UNITS = TradeServiceManager().price_units
