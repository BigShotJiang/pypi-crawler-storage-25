"""
Trade Orders - Backward-compatibility shim.

TradingOperations is now an alias for FarmTradingOperations.
All enum types are imported from .enums (single source of truth).
All standalone convenience functions delegate to FarmTradingOperations.
"""

from typing import Dict, Any, Optional

from .enums import OrderType, ActionType, FillingMode, ExpirationType
from .farm_orders import FarmTradingOperations
from harness.barn.core.utils import normalize_symbol

# Backward-compat alias
TradingOperations = FarmTradingOperations


# ---------------------------------------------------------------------------
# Convenience functions (preserve the public API)
# ---------------------------------------------------------------------------

async def create_market_buy(symbol: str, volume: float, **kwargs) -> Dict[str, Any]:
    """Create a market BUY order."""
    return await FarmTradingOperations().market_buy(normalize_symbol(symbol), volume, **kwargs)


async def create_market_sell(symbol: str, volume: float, **kwargs) -> Dict[str, Any]:
    """Create a market SELL order."""
    return await FarmTradingOperations().market_sell(normalize_symbol(symbol), volume, **kwargs)


async def create_buy_limit(symbol: str, volume: float, open_price: float, **kwargs) -> Dict[str, Any]:
    """Create a BUY LIMIT order."""
    return await FarmTradingOperations().buy_limit(normalize_symbol(symbol), volume, open_price, **kwargs)


async def create_sell_limit(symbol: str, volume: float, open_price: float, **kwargs) -> Dict[str, Any]:
    """Create a SELL LIMIT order."""
    return await FarmTradingOperations().sell_limit(normalize_symbol(symbol), volume, open_price, **kwargs)


async def create_buy_stop(symbol: str, volume: float, open_price: float, **kwargs) -> Dict[str, Any]:
    """Create a BUY STOP order."""
    return await FarmTradingOperations().buy_stop(normalize_symbol(symbol), volume, open_price, **kwargs)


async def create_sell_stop(symbol: str, volume: float, open_price: float, **kwargs) -> Dict[str, Any]:
    """Create a SELL STOP order."""
    return await FarmTradingOperations().sell_stop(normalize_symbol(symbol), volume, open_price, **kwargs)


async def modify_position_sl_tp(
    position_id: str,
    stop_loss: Optional[float] = None,
    take_profit: Optional[float] = None,
    **kwargs,
) -> Dict[str, Any]:
    """Modify position stop loss and take profit."""
    return await FarmTradingOperations().modify_position(position_id, stop_loss, take_profit, **kwargs)


async def close_position(position_id: str, volume: Optional[float] = None, **kwargs) -> Dict[str, Any]:
    """Close position (full or partial)."""
    ops = FarmTradingOperations()
    if volume is not None:
        return await ops.close_position_partial(position_id, volume, **kwargs)
    return await ops.close_position_full(position_id, **kwargs)


async def cancel_pending_order(order_id: str, **kwargs) -> Dict[str, Any]:
    """Cancel a pending order."""
    return await FarmTradingOperations().cancel_order(order_id, **kwargs)
