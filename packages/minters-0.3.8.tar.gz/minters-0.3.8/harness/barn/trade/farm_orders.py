"""
Farm Trading Operations - Complete MT5 Trading via Farm Controller

This module implements all trading operations using the farm controller
instead of MetaAPI. Provides the same interface for compatibility.
"""

import asyncio
import logging
from typing import Dict, Any, Optional, List

from ..core.dispatcher import get_client
from ..core.utils import normalize_symbol
from .enums import OrderType, ActionType, FillingMode, ExpirationType

logger = logging.getLogger(__name__)


class FarmTradingOperations:
    """
    Trading Operations via Farm Controller
    
    Provides all trading functions using the MT5 farm instead of MetaAPI.
    Interface is compatible with the MetaAPI-based TradingOperations.
    """
    
    def __init__(self):
        self.client = None
    
    async def _get_client(self, user: Optional[Dict] = None):
        """Get client via dispatcher (supports farm / farm_ext / auto mode)."""
        if user is not None:
            return await get_client(user=user)
        if self.client is None:
            self.client = await get_client()
        return self.client
    
    # ==================
    # Market Orders
    # ==================
    
    async def market_buy(
        self,
        symbol: str,
        volume: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        stop_loss_units: Optional[str] = "ABSOLUTE_PRICE",
        take_profit_units: Optional[str] = "ABSOLUTE_PRICE",
        trailing_stop_loss: Optional[Dict] = None,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        magic: Optional[int] = None,
        slippage: Optional[float] = None,
        filling_modes: Optional[List[str]] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Execute a market BUY order
        
        Args:
            symbol: Trading symbol (auto-normalized to broker format)
            volume: Order volume in lots
            stop_loss: Stop loss price (optional)
            take_profit: Take profit price (optional)
            comment: Order comment (optional)
            magic: Magic number (optional)
            user: User dict for account resolution
            
        Returns:
            Dict containing trade response
        """
        symbol = normalize_symbol(symbol)
        client = await self._get_client(user)
        
        result = await client.market_buy(symbol, volume)
        
        # Modify position to add SL/TP if specified
        if result.get("success") and (stop_loss or take_profit):
            ticket = result.get("ticket")
            if ticket:
                await client.modify_position(
                    ticket=ticket,
                    stop_loss=stop_loss or 0.0,
                    take_profit=take_profit or 0.0
                )
        
        return self._format_trade_result(result)
    
    async def market_sell(
        self,
        symbol: str,
        volume: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        stop_loss_units: Optional[str] = "ABSOLUTE_PRICE",
        take_profit_units: Optional[str] = "ABSOLUTE_PRICE",
        trailing_stop_loss: Optional[Dict] = None,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        magic: Optional[int] = None,
        slippage: Optional[float] = None,
        filling_modes: Optional[List[str]] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Execute a market SELL order"""
        symbol = normalize_symbol(symbol)
        client = await self._get_client(user)
        
        result = await client.market_sell(symbol, volume)
        
        if result.get("success") and (stop_loss or take_profit):
            ticket = result.get("ticket")
            if ticket:
                await client.modify_position(
                    ticket=ticket,
                    stop_loss=stop_loss or 0.0,
                    take_profit=take_profit or 0.0
                )
        
        return self._format_trade_result(result)
    
    # ==================
    # Pending Orders
    # ==================
    
    async def buy_limit(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        stop_loss_units: Optional[str] = "ABSOLUTE_PRICE",
        take_profit_units: Optional[str] = "ABSOLUTE_PRICE",
        expiration: Optional[Dict] = None,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        magic: Optional[int] = None,
        slippage: Optional[float] = None,
        filling_modes: Optional[List[str]] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Place a BUY LIMIT pending order"""
        symbol = normalize_symbol(symbol)
        client = await self._get_client(user)
        
        exp_time = self._parse_expiration(expiration)
        
        result = await client.buy_limit(
            symbol=symbol,
            volume=volume,
            price=open_price,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            expiration=exp_time,
            magic=magic or 0,
            comment=comment or ""
        )
        
        return self._format_trade_result(result)
    
    async def sell_limit(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        stop_loss_units: Optional[str] = "ABSOLUTE_PRICE",
        take_profit_units: Optional[str] = "ABSOLUTE_PRICE",
        expiration: Optional[Dict] = None,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        magic: Optional[int] = None,
        slippage: Optional[float] = None,
        filling_modes: Optional[List[str]] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Place a SELL LIMIT pending order"""
        symbol = normalize_symbol(symbol)
        client = await self._get_client(user)
        
        exp_time = self._parse_expiration(expiration)
        
        result = await client.sell_limit(
            symbol=symbol,
            volume=volume,
            price=open_price,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            expiration=exp_time,
            magic=magic or 0,
            comment=comment or ""
        )
        
        return self._format_trade_result(result)
    
    async def buy_stop(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        stop_loss_units: Optional[str] = "ABSOLUTE_PRICE",
        take_profit_units: Optional[str] = "ABSOLUTE_PRICE",
        expiration: Optional[Dict] = None,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        magic: Optional[int] = None,
        slippage: Optional[float] = None,
        filling_modes: Optional[List[str]] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Place a BUY STOP pending order"""
        symbol = normalize_symbol(symbol)
        client = await self._get_client(user)
        
        exp_time = self._parse_expiration(expiration)
        
        result = await client.buy_stop(
            symbol=symbol,
            volume=volume,
            price=open_price,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            expiration=exp_time,
            magic=magic or 0,
            comment=comment or ""
        )
        
        return self._format_trade_result(result)
    
    async def sell_stop(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        stop_loss_units: Optional[str] = "ABSOLUTE_PRICE",
        take_profit_units: Optional[str] = "ABSOLUTE_PRICE",
        expiration: Optional[Dict] = None,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        magic: Optional[int] = None,
        slippage: Optional[float] = None,
        filling_modes: Optional[List[str]] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Place a SELL STOP pending order"""
        symbol = normalize_symbol(symbol)
        client = await self._get_client(user)
        
        exp_time = self._parse_expiration(expiration)
        
        result = await client.sell_stop(
            symbol=symbol,
            volume=volume,
            price=open_price,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            expiration=exp_time,
            magic=magic or 0,
            comment=comment or ""
        )
        
        return self._format_trade_result(result)
    
    async def buy_stop_limit(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_limit_price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        stop_loss_units: Optional[str] = "ABSOLUTE_PRICE",
        take_profit_units: Optional[str] = "ABSOLUTE_PRICE",
        expiration: Optional[Dict] = None,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        magic: Optional[int] = None,
        slippage: Optional[float] = None,
        filling_modes: Optional[List[str]] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Place a BUY STOP LIMIT pending order"""
        symbol = normalize_symbol(symbol)
        client = await self._get_client(user)
        
        exp_time = self._parse_expiration(expiration)
        
        result = await client.buy_stop_limit(
            symbol=symbol,
            volume=volume,
            price=open_price,
            stop_limit_price=stop_limit_price,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            expiration=exp_time,
            magic=magic or 0,
            comment=comment or ""
        )
        
        return self._format_trade_result(result)
    
    async def sell_stop_limit(
        self,
        symbol: str,
        volume: float,
        open_price: float,
        stop_limit_price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        stop_loss_units: Optional[str] = "ABSOLUTE_PRICE",
        take_profit_units: Optional[str] = "ABSOLUTE_PRICE",
        expiration: Optional[Dict] = None,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        magic: Optional[int] = None,
        slippage: Optional[float] = None,
        filling_modes: Optional[List[str]] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Place a SELL STOP LIMIT pending order"""
        symbol = normalize_symbol(symbol)
        client = await self._get_client(user)
        
        exp_time = self._parse_expiration(expiration)
        
        result = await client.sell_stop_limit(
            symbol=symbol,
            volume=volume,
            price=open_price,
            stop_limit_price=stop_limit_price,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            expiration=exp_time,
            magic=magic or 0,
            comment=comment or ""
        )
        
        return self._format_trade_result(result)
    
    # ==================
    # Position Management
    # ==================
    
    async def modify_position(
        self,
        position_id: str,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        stop_loss_units: Optional[str] = "ABSOLUTE_PRICE",
        take_profit_units: Optional[str] = "ABSOLUTE_PRICE",
        trailing_stop_loss: Optional[Dict] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Modify position SL/TP"""
        client = await self._get_client(user)
        
        trailing = 0.0
        if trailing_stop_loss and isinstance(trailing_stop_loss, dict):
            trailing = trailing_stop_loss.get("distance", 0.0)
        
        result = await client.modify_position(
            ticket=int(position_id),
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            trailing_stop=trailing
        )
        
        return self._format_trade_result(result)
    
    async def close_position_partial(
        self,
        position_id: str,
        volume: float,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Partially close a position"""
        client = await self._get_client(user)
        
        result = await client.close_position_partial(
            ticket=int(position_id),
            volume=volume
        )
        
        return self._format_trade_result(result)
    
    async def close_position_full(
        self,
        position_id: str,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Close a position completely"""
        client = await self._get_client(user)
        
        result = await client.close_position(ticket=int(position_id))
        
        return self._format_trade_result(result)
    
    async def close_position_by_opposite(
        self,
        position_id: str,
        opposite_position_id: str,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Close position by opposite position (hedging accounts)"""
        client = await self._get_client(user)
        
        result = await client.close_position_by(
            ticket=int(position_id),
            opposite_ticket=int(opposite_position_id)
        )
        
        return self._format_trade_result(result)
    
    async def close_all_positions_by_symbol(
        self,
        symbol: str,
        comment: Optional[str] = None,
        client_id: Optional[str] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Close all positions for a symbol"""
        symbol = normalize_symbol(symbol)
        client = await self._get_client(user)
        
        result = await client.close_all_positions_by_symbol(symbol)
        
        return {
            "success": True,
            "symbol": symbol,
            "closed": result.get("closed", 0),
            "total": result.get("total_positions", 0),
            "results": result.get("results", [])
        }
    
    # ==================
    # Order Management
    # ==================
    
    async def modify_order(
        self,
        order_id: str,
        open_price: Optional[float] = None,
        stop_limit_price: Optional[float] = None,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        expiration: Optional[Dict] = None,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Modify a pending order"""
        client = await self._get_client(user)
        
        exp_time = self._parse_expiration(expiration)
        
        result = await client.modify_order(
            ticket=int(order_id),
            price=open_price or 0.0,
            stop_limit_price=stop_limit_price or 0.0,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            expiration=exp_time
        )
        
        return self._format_trade_result(result)
    
    async def cancel_order(
        self,
        order_id: str,
        user: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Cancel a pending order"""
        client = await self._get_client(user)
        
        result = await client.cancel_order(ticket=int(order_id))
        
        return self._format_trade_result(result)
    
    # ==================
    # Data Queries
    # ==================
    
    async def get_positions(self, user: Optional[Dict] = None) -> List[Dict]:
        """Get all open positions"""
        client = await self._get_client(user)
        return await client.get_positions()
    
    async def get_pending_orders(self, user: Optional[Dict] = None) -> List[Dict]:
        """Get all pending orders"""
        client = await self._get_client(user)
        return await client.get_pending_orders()
    
    async def get_account_info(self, user: Optional[Dict] = None) -> Dict:
        """Get account information"""
        client = await self._get_client(user)
        return await client.get_account_info()
    
    async def get_deal_history(
        self,
        from_date: int = 0,
        to_date: int = 0,
        user: Optional[Dict] = None
    ) -> List[Dict]:
        """Get deal history"""
        client = await self._get_client(user)
        return await client.get_deal_history(from_date, to_date)
    
    # ==================
    # Helpers
    # ==================
    
    def _parse_expiration(self, expiration: Optional[Dict]) -> int:
        """Parse expiration dict to Unix timestamp"""
        if not expiration:
            return 0
        
        if isinstance(expiration, dict):
            exp_type = expiration.get("type", "ORDER_TIME_GTC")
            if exp_type == "ORDER_TIME_GTC":
                return 0
            
            exp_time = expiration.get("time")
            if exp_time:
                # Parse ISO datetime string to timestamp
                from datetime import datetime
                if isinstance(exp_time, str):
                    try:
                        dt = datetime.fromisoformat(exp_time.replace("Z", "+00:00"))
                        return int(dt.timestamp())
                    except:
                        pass
                elif isinstance(exp_time, (int, float)):
                    return int(exp_time)
        
        return 0
    
    def _format_trade_result(self, result: Dict) -> Dict[str, Any]:
        """Format trade result for compatibility with MetaAPI interface"""
        return {
            "success": result.get("success", False),
            "orderId": str(result.get("ticket", 0)),
            "positionId": str(result.get("ticket", 0)),
            "retcode": result.get("retcode", 0),
            "message": result.get("message", result.get("comment", "")),
            "stringCode": "TRADE_RETCODE_DONE" if result.get("success") else "TRADE_RETCODE_ERROR"
        }


# Singleton instance for convenience
_farm_trading_ops = None

async def get_farm_trading_operations() -> FarmTradingOperations:
    """Get singleton FarmTradingOperations instance"""
    global _farm_trading_ops
    if _farm_trading_ops is None:
        _farm_trading_ops = FarmTradingOperations()
    return _farm_trading_ops
