"""
Trade module for terminal service.
Handles all MT5 trading operations including market orders, pending orders,
position management, and order modifications/cancellations.

FarmTradingOperations is the canonical implementation.
TradingOperations is a backward-compat alias for FarmTradingOperations.
"""

from .enums import OrderType, ActionType, FillingMode, ExpirationType

from .farm_orders import FarmTradingOperations, get_farm_trading_operations

# Backward-compat alias + convenience functions live in orders.py shim
from .orders import (
    TradingOperations,
    create_market_buy,
    create_market_sell,
    create_buy_limit,
    create_sell_limit,
    create_buy_stop,
    create_sell_stop,
    modify_position_sl_tp,
    close_position,
    cancel_pending_order,
)

from .schema import (
    TradeServiceManager,
    get_trade_service_manager,
    TRADE_SCHEMAS,
    ORDER_TYPES,
    ACTION_TYPES,
    FILLING_MODES,
    EXPIRATION_TYPES
)

__all__ = [
    # Trading classes
    'FarmTradingOperations',  # canonical
    'TradingOperations',      # backward-compat alias
    'get_farm_trading_operations',
    # Enums
    'OrderType',
    'ActionType',
    'FillingMode',
    'ExpirationType',
    # Convenience functions
    'create_market_buy',
    'create_market_sell',
    'create_buy_limit',
    'create_sell_limit',
    'create_buy_stop',
    'create_sell_stop',
    'modify_position_sl_tp',
    'close_position',
    'cancel_pending_order',
    # Schema
    'TradeServiceManager',
    'get_trade_service_manager',
    'TRADE_SCHEMAS',
    'ORDER_TYPES',
    'ACTION_TYPES',
    'FILLING_MODES',
    'EXPIRATION_TYPES',
]
