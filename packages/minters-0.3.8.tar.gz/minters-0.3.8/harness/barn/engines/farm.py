"""
harness.barn.engines.farm
==========================

MT5 farm engine handle. Import it and every call automatically routes
to your self-hosted MT5 farm:

    from harness import farm

    account = await farm.get_account_information()
    price   = await farm.get_current_price("EURUSD")
    order   = await farm.market_buy("EURUSD", 0.1, stop_loss=1.0800)

Credential / account override
------------------------------
Use ``farm.cred(account_id="...")`` to get a scoped copy bound to a
specific MT5 account on the farm:

    acc2 = farm.cred(account_id="123456")
    order = await acc2.market_buy("XAUUSD", 0.05)
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional


class FarmEngine:
    """Engine handle for the self-hosted MT5 Farm backend."""

    def __init__(self, account_id: Optional[str] = None) -> None:
        self._account_id = account_id

    def cred(self, *, account_id: Optional[str] = None) -> "FarmEngine":
        """Return a new engine bound to a specific farm account."""
        return FarmEngine(account_id=account_id or self._account_id)

    async def _get_client(self):
        from harness.barn.core.farm_client import FarmClient
        return await FarmClient.get(account_id=self._account_id)

    # ------------------------------------------------------------------
    # Account
    # ------------------------------------------------------------------

    async def get_account_information(self) -> dict:
        c = await self._get_client()
        return await c.get_account_information()

    async def get_account_snapshot(self) -> dict:
        return await self.get_account_information()

    async def get_positions(self, symbol: Optional[str] = None) -> List[dict]:
        c = await self._get_client()
        positions = await c.get_positions()
        if symbol:
            positions = [p for p in positions if p.get("symbol") == symbol]
        return positions

    async def get_pending_orders(self, symbol: Optional[str] = None) -> List[dict]:
        c = await self._get_client()
        orders = await c.get_pending_orders()
        if symbol:
            orders = [o for o in orders if o.get("symbol") == symbol]
        return orders

    async def get_history_orders(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
    ) -> List[dict]:
        c = await self._get_client()
        return await c.get_history_orders(from_date=from_date, to_date=to_date)

    async def get_deals(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
    ) -> List[dict]:
        c = await self._get_client()
        return await c.get_deals(from_date=from_date, to_date=to_date)

    # ------------------------------------------------------------------
    # Market data
    # ------------------------------------------------------------------

    async def get_symbols(self) -> List[str]:
        c = await self._get_client()
        return await c.get_symbols()

    async def get_symbol_info(self, symbol: str) -> dict:
        c = await self._get_client()
        return await c.get_symbol_info(symbol)

    async def get_current_price(self, symbol: str) -> dict:
        c = await self._get_client()
        return await c.get_current_price(symbol)

    async def get_server_time(self) -> dict:
        c = await self._get_client()
        return await c.get_server_time()

    async def get_historical_ohlc(
        self,
        symbol: str,
        timeframe: str,
        count: int = 1000,
    ) -> List[dict]:
        c = await self._get_client()
        return await c.get_historical_candles(symbol, timeframe, limit=count)

    async def get_historical_ohlc_range(
        self,
        symbol: str,
        timeframe: str,
        from_date: str,
        to_date: str,
    ) -> List[dict]:
        c = await self._get_client()
        return await c.get_historical_candles(
            symbol, timeframe, start_time=from_date, end_time=to_date
        )

    # ------------------------------------------------------------------
    # Trading — market orders
    # ------------------------------------------------------------------

    async def market_buy(
        self,
        symbol: str,
        size: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        comment: str = "",
    ) -> dict:
        c = await self._get_client()
        return await c.market_buy(
            symbol, size,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            comment=comment,
        )

    async def market_sell(
        self,
        symbol: str,
        size: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        comment: str = "",
    ) -> dict:
        c = await self._get_client()
        return await c.market_sell(
            symbol, size,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
            comment=comment,
        )

    # ------------------------------------------------------------------
    # Trading — pending orders
    # ------------------------------------------------------------------

    async def buy_limit(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.buy_limit(
            symbol, size, level,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
        )

    async def sell_limit(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.sell_limit(
            symbol, size, level,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
        )

    async def buy_stop(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.buy_stop(
            symbol, size, level,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
        )

    async def sell_stop(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.sell_stop(
            symbol, size, level,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
        )

    # ------------------------------------------------------------------
    # Trading — position / order management
    # ------------------------------------------------------------------

    async def modify_position(
        self,
        ticket: str,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.modify_position(str(ticket), stop_loss or 0.0, take_profit or 0.0)

    async def close_position(self, ticket: str) -> dict:
        c = await self._get_client()
        return await c.close_position(str(ticket))

    async def close_all_by_symbol(self, symbol: str) -> dict:
        c = await self._get_client()
        return await c.close_all_positions_by_symbol(symbol)

    async def modify_order(
        self,
        ticket: str,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.modify_order(str(ticket), price=level,
                                    stop_loss=stop_loss or 0.0,
                                    take_profit=take_profit or 0.0)

    async def cancel_order(self, ticket: str) -> dict:
        c = await self._get_client()
        return await c.cancel_order(str(ticket))

    def __repr__(self) -> str:
        acct = self._account_id or "env"
        return f"<FarmEngine account_id={acct!r}>"


# Pre-built singleton
farm = FarmEngine()
