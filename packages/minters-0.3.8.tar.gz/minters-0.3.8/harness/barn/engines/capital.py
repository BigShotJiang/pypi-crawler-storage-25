"""
harness.barn.engines.capital
=============================

Capital.com engine handle.  Import it and every call automatically routes
to the Capital.com backend — no env-var wrangling required:

    from harness import capital

    price   = await capital.get_current_price("OIL_CRUDE")
    account = await capital.get_account_snapshot()
    order   = await capital.market_buy("OIL_CRUDE", 0.5, stop_loss=70.0)

Credential override
-------------------
Use ``capital.cred(...)`` to get a scoped copy bound to specific credentials
(handy for multi-account contracts or switching live/demo within one script):

    live = capital.cred(demo=False, api_key="xxx", identifier="me@x.com", password="pw")
    order = await live.market_buy("OIL_CRUDE", 1.0)

The original ``capital`` singleton is unaffected.

Available methods (full Capital.com API surface)
-------------------------------------------------
Account
    get_account_snapshot()
    get_account_information()
    get_positions(symbol=None)
    get_pending_orders(symbol=None)
    get_closed_orders(limit=100)
    get_closed_orders_range(from_date, to_date, transaction_type=None)
    get_account_preferences()
    get_activity_history(last_secs=600)
    get_activity_range(from_date, to_date, detailed=False)
    get_position_by_id(deal_id)
    top_up_demo(amount)                        # demo accounts only
    update_account_preferences(leverages, hedging_mode)

Market data
    get_current_price(symbol)
    get_market_details(symbol)
    get_symbols()
    get_server_time()
    get_historical_ohlc(symbol, timeframe, count=1000)
    get_historical_ohlc_range(symbol, timeframe, from_date, to_date)
    search_markets(query)
    get_markets_by_epics(epics)
    get_market_navigation()
    get_market_navigation_node(node_id)
    get_client_sentiment(market_id)
    get_client_sentiment_batch(market_ids)

Watchlists
    get_watchlists()
    get_watchlist(watchlist_id)
    create_watchlist(name, epics=[])
    add_to_watchlist(watchlist_id, epic)
    delete_watchlist(watchlist_id)
    remove_from_watchlist(watchlist_id, epic)

Trading
    market_buy(symbol, size, stop_loss=None, take_profit=None)
    market_sell(symbol, size, stop_loss=None, take_profit=None)
    buy_limit(symbol, size, level, stop_loss=None, take_profit=None)
    sell_limit(symbol, size, level, stop_loss=None, take_profit=None)
    buy_stop(symbol, size, level, stop_loss=None, take_profit=None)
    sell_stop(symbol, size, level, stop_loss=None, take_profit=None)
    buy_limit_gtd(symbol, size, level, stop_loss, take_profit, good_till_date)
    sell_limit_gtd(symbol, size, level, stop_loss, take_profit, good_till_date)
    buy_stop_gtd(symbol, size, level, stop_loss, take_profit, good_till_date)
    sell_stop_gtd(symbol, size, level, stop_loss, take_profit, good_till_date)
    modify_position(ticket, stop_loss=None, take_profit=None)
    close_position(ticket)
    close_all_by_symbol(symbol)
    modify_order(ticket, level, stop_loss=None, take_profit=None)
    cancel_order(ticket)
    confirm_deal(deal_reference)
"""

from __future__ import annotations

import hashlib
import os
from typing import Any, Dict, List, Optional


class CapitalEngine:
    """
    Engine handle for the Capital.com backend.

    Instantiate directly or use the pre-built ``capital`` singleton:

        from harness import capital
        price = await capital.get_current_price("OIL_CRUDE")
    """

    def __init__(self, overrides: Optional[Dict[str, str]] = None) -> None:
        self._overrides: Dict[str, str] = overrides or {}

    # ------------------------------------------------------------------
    # Credential management
    # ------------------------------------------------------------------

    def cred(
        self,
        *,
        demo: Optional[bool] = None,
        api_key: Optional[str] = None,
        identifier: Optional[str] = None,
        password: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> "CapitalEngine":
        """Return a new engine bound to the given credentials.

        Unspecified parameters fall back to the current engine's credentials
        (which in turn fall back to environment variables).
        """
        new = dict(self._overrides)
        if demo is not None:
            new["CAPITAL_DEMO"] = "true" if demo else "false"
        if api_key is not None:
            new["CAPITAL_API_KEY"] = api_key
        if identifier is not None:
            new["CAPITAL_IDENTIFIER"] = identifier
        if password is not None:
            new["CAPITAL_PASSWORD"] = password
        if base_url is not None:
            new["CAPITAL_BASE_URL"] = base_url
        return CapitalEngine(new)

    # ------------------------------------------------------------------
    # Internal: resolve the underlying CapitalClient
    # ------------------------------------------------------------------

    async def _get_client(self):
        from harness.barn.core.capital_client import CapitalClient, _capital_client_pool, _pool_lock

        if not self._overrides:
            return await CapitalClient.get()

        # A unique pool key derived from the overrides
        key = "cap_cred_" + hashlib.md5(
            str(sorted(self._overrides.items())).encode()
        ).hexdigest()[:12]

        async with _pool_lock:
            if key in _capital_client_pool:
                return _capital_client_pool[key]

            # Temporarily inject overrides into env so the Rust bridge picks them up
            old: Dict[str, Optional[str]] = {}
            for k, v in self._overrides.items():
                old[k] = os.environ.get(k)
                os.environ[k] = v
            try:
                client = CapitalClient(key)
                await client._init()
                _capital_client_pool[key] = client
            finally:
                for k, old_v in old.items():
                    if old_v is None:
                        os.environ.pop(k, None)
                    else:
                        os.environ[k] = old_v

        return client

    # ------------------------------------------------------------------
    # Account
    # ------------------------------------------------------------------

    async def get_account_snapshot(self) -> dict:
        """Full account snapshot: balance, equity, leverage, etc."""
        client = await self._get_client()
        return await client.get_account_information()

    async def get_account_information(self) -> dict:
        """Alias for get_account_snapshot()."""
        return await self.get_account_snapshot()

    async def get_positions(self, symbol: Optional[str] = None) -> List[dict]:
        """Open positions, optionally filtered by symbol."""
        client = await self._get_client()
        return await client.get_positions()

    async def get_pending_orders(self, symbol: Optional[str] = None) -> List[dict]:
        """Pending (working) orders, optionally filtered by symbol."""
        client = await self._get_client()
        return await client.get_pending_orders()

    async def get_closed_orders(self, limit: int = 100) -> List[dict]:
        """Most-recent closed orders up to *limit*."""
        client = await self._get_client()
        return await client._call_json("closed_orders_json", limit)

    async def get_closed_orders_range(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        transaction_type: Optional[str] = None,
    ) -> List[dict]:
        """Closed orders within an ISO-8601 date range."""
        client = await self._get_client()
        return await client._call_json(
            "closed_orders_range_json", from_date, to_date, transaction_type
        )

    async def get_account_preferences(self) -> dict:
        """Account preferences: hedging mode, leverage by asset class."""
        client = await self._get_client()
        return await client.get_account_preferences()

    async def get_activity_history(self, last_secs: int = 600) -> dict:
        """Recent account activity (default 10-min window, max 24 h)."""
        client = await self._get_client()
        return await client.get_activity_history(last_secs)

    async def get_activity_range(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        detailed: bool = False,
    ) -> dict:
        """Account activity filtered by absolute date range."""
        client = await self._get_client()
        return await client.get_activity_range(from_date, to_date, detailed)

    async def get_position_by_id(self, deal_id: str) -> dict:
        """Fetch a single open position by its deal ID."""
        client = await self._get_client()
        return await client.get_position_by_id(deal_id)

    async def top_up_demo(self, amount: float) -> dict:
        """Top up the demo account balance (demo only)."""
        client = await self._get_client()
        return await client.top_up_demo(amount)

    async def update_account_preferences(
        self,
        leverages: Optional[dict] = None,
        hedging_mode: Optional[bool] = None,
    ) -> dict:
        """Update leverage settings and/or hedging mode.

        *leverages* is a dict mapping asset class to new leverage, e.g.::

            {"CURRENCIES": 10, "SHARES": 5}
        """
        client = await self._get_client()
        return await client.update_account_preferences(leverages, hedging_mode)

    # ------------------------------------------------------------------
    # Market data
    # ------------------------------------------------------------------

    async def get_current_price(self, symbol: str) -> dict:
        """Live bid/ask quote for *symbol*."""
        client = await self._get_client()
        return await client.get_current_price(symbol)

    async def get_market_details(self, symbol: str) -> dict:
        """Full contract specification and snapshot for *symbol*."""
        client = await self._get_client()
        return await client.get_symbol_info(symbol)

    async def get_symbols(self) -> List[str]:
        """All tradeable symbol epics on the account."""
        client = await self._get_client()
        return await client.get_symbols()

    async def get_server_time(self) -> dict:
        """Current Capital.com server time."""
        client = await self._get_client()
        return await client.get_server_time()

    async def get_historical_ohlc(
        self,
        symbol: str,
        timeframe: str,
        count: int = 1000,
    ) -> List[dict]:
        """Historical OHLCV candles (most recent *count* bars).

        *timeframe*: ``MINUTE``, ``MINUTE_5``, ``MINUTE_15``, ``MINUTE_30``,
        ``HOUR``, ``HOUR_4``, ``DAY``, ``WEEK``.
        """
        client = await self._get_client()
        return await client.get_historical_candles(symbol, timeframe, limit=count)

    async def get_historical_ohlc_range(
        self,
        symbol: str,
        timeframe: str,
        from_date: str,
        to_date: str,
    ) -> List[dict]:
        """Historical OHLCV candles between two ISO-8601 datetime strings."""
        client = await self._get_client()
        return await client.get_historical_candles(symbol, timeframe, start_time=from_date, end_time=to_date)

    async def search_markets(self, query: str) -> dict:
        """Free-text market search."""
        client = await self._get_client()
        return await client.search_markets(query)

    async def get_markets_by_epics(self, epics: List[str]) -> dict:
        """Fetch details for up to 50 known market epics."""
        client = await self._get_client()
        return await client.get_markets_by_epics(epics)

    async def get_market_navigation(self) -> dict:
        """Top-level market category tree (Currencies, Indices, Commodities…)."""
        client = await self._get_client()
        return await client.get_market_navigation()

    async def get_market_navigation_node(self, node_id: str) -> dict:
        """Sub-nodes and markets under a category node."""
        client = await self._get_client()
        return await client.get_market_navigation_node(node_id)

    async def get_client_sentiment(self, market_id: str) -> dict:
        """Long/short sentiment percentage for a single market."""
        client = await self._get_client()
        return await client.get_client_sentiment(market_id)

    async def get_client_sentiment_batch(self, market_ids: List[str]) -> dict:
        """Long/short sentiment percentages for multiple markets."""
        client = await self._get_client()
        return await client.get_client_sentiment_batch(market_ids)

    # ------------------------------------------------------------------
    # Watchlists
    # ------------------------------------------------------------------

    async def get_watchlists(self) -> dict:
        """All watchlists on the account."""
        client = await self._get_client()
        return await client.get_watchlists()

    async def get_watchlist(self, watchlist_id: str) -> dict:
        """Markets inside a specific watchlist."""
        client = await self._get_client()
        return await client.get_watchlist(watchlist_id)

    async def create_watchlist(self, name: str, epics: Optional[List[str]] = None) -> dict:
        """Create a new watchlist with an optional initial set of epics."""
        client = await self._get_client()
        return await client.create_watchlist(name, epics or [])

    async def add_to_watchlist(self, watchlist_id: str, epic: str) -> dict:
        """Add a market epic to an existing watchlist."""
        client = await self._get_client()
        return await client.add_to_watchlist(watchlist_id, epic)

    async def delete_watchlist(self, watchlist_id: str) -> dict:
        """Delete a watchlist entirely."""
        client = await self._get_client()
        return await client.delete_watchlist(watchlist_id)

    async def remove_from_watchlist(self, watchlist_id: str, epic: str) -> dict:
        """Remove a single epic from a watchlist."""
        client = await self._get_client()
        return await client.remove_from_watchlist(watchlist_id, epic)

    # ------------------------------------------------------------------
    # Trading — market orders
    # ------------------------------------------------------------------

    async def market_buy(
        self,
        symbol: str,
        size: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        """Place an immediate market BUY order."""
        client = await self._get_client()
        result = await client._call_json(
            "market_buy_json", symbol, size, stop_loss, take_profit
        )
        return client._normalize_exec(result)

    async def market_sell(
        self,
        symbol: str,
        size: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        """Place an immediate market SELL order."""
        client = await self._get_client()
        result = await client._call_json(
            "market_sell_json", symbol, size, stop_loss, take_profit
        )
        return client._normalize_exec(result)

    # ------------------------------------------------------------------
    # Trading — pending orders (GTC)
    # ------------------------------------------------------------------

    async def buy_limit(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        """Place a BUY LIMIT order (good-till-cancelled)."""
        client = await self._get_client()
        result = await client._call_json(
            "buy_limit_json", symbol, size, level, stop_loss, take_profit
        )
        return client._normalize_exec(result)

    async def sell_limit(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        """Place a SELL LIMIT order (good-till-cancelled)."""
        client = await self._get_client()
        result = await client._call_json(
            "sell_limit_json", symbol, size, level, stop_loss, take_profit
        )
        return client._normalize_exec(result)

    async def buy_stop(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        """Place a BUY STOP order (good-till-cancelled)."""
        client = await self._get_client()
        result = await client._call_json(
            "buy_stop_json", symbol, size, level, stop_loss, take_profit
        )
        return client._normalize_exec(result)

    async def sell_stop(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        """Place a SELL STOP order (good-till-cancelled)."""
        client = await self._get_client()
        result = await client._call_json(
            "sell_stop_json", symbol, size, level, stop_loss, take_profit
        )
        return client._normalize_exec(result)

    # ------------------------------------------------------------------
    # Trading — pending orders (GTD — Good Till Date)
    # ------------------------------------------------------------------

    async def buy_limit_gtd(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        good_till_date: str = "",
    ) -> dict:
        """BUY LIMIT that expires on *good_till_date* (``'YYYY-MM-DDTHH:MM:SS'``)."""
        client = await self._get_client()
        result = await client._call_json(
            "buy_limit_gtd_json", symbol, size, level, stop_loss, take_profit,
            good_till_date or None,
        )
        return client._normalize_exec(result)

    async def sell_limit_gtd(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        good_till_date: str = "",
    ) -> dict:
        """SELL LIMIT that expires on *good_till_date*."""
        client = await self._get_client()
        result = await client._call_json(
            "sell_limit_gtd_json", symbol, size, level, stop_loss, take_profit,
            good_till_date or None,
        )
        return client._normalize_exec(result)

    async def buy_stop_gtd(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        good_till_date: str = "",
    ) -> dict:
        """BUY STOP that expires on *good_till_date*."""
        client = await self._get_client()
        result = await client._call_json(
            "buy_stop_gtd_json", symbol, size, level, stop_loss, take_profit,
            good_till_date or None,
        )
        return client._normalize_exec(result)

    async def sell_stop_gtd(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
        good_till_date: str = "",
    ) -> dict:
        """SELL STOP that expires on *good_till_date*."""
        client = await self._get_client()
        result = await client._call_json(
            "sell_stop_gtd_json", symbol, size, level, stop_loss, take_profit,
            good_till_date or None,
        )
        return client._normalize_exec(result)

    # ------------------------------------------------------------------
    # Trading — position / order management
    # ------------------------------------------------------------------

    async def modify_position(
        self,
        ticket: str,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        """Update the stop-loss and/or take-profit of an open position."""
        client = await self._get_client()
        result = await client._call_json(
            "modify_position_json", str(ticket), stop_loss, take_profit
        )
        return client._normalize_exec(result)

    async def close_position(self, ticket: str) -> dict:
        """Fully close an open position."""
        client = await self._get_client()
        result = await client._call_json("close_position_full_json", str(ticket))
        return client._normalize_exec(result)

    async def close_all_by_symbol(self, symbol: str) -> dict:
        """Close ALL open positions for *symbol*."""
        client = await self._get_client()
        return await client.close_all_positions_by_symbol(symbol)

    async def modify_order(
        self,
        ticket: str,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        """Update the price level and/or stops of a pending order."""
        client = await self._get_client()
        result = await client._call_json(
            "modify_order_json", str(ticket), level, stop_loss, take_profit
        )
        return client._normalize_exec(result)

    async def cancel_order(self, ticket: str) -> dict:
        """Cancel a pending order."""
        client = await self._get_client()
        result = await client._call_json("cancel_order_json", str(ticket))
        return client._normalize_exec(result)

    async def confirm_deal(self, deal_reference: str) -> dict:
        """Fetch the deal confirmation for a ``dealReference``."""
        client = await self._get_client()
        return await client.confirm_deal(deal_reference)

    def __repr__(self) -> str:
        if self._overrides:
            masked = {k: v[:4] + "..." for k, v in self._overrides.items()}
            return f"<CapitalEngine overrides={masked}>"
        return "<CapitalEngine (env credentials)>"


# Pre-built singleton — `from harness import capital` is all you need.
capital = CapitalEngine()
