"""
harness.barn.engines.farm_ext
==============================

MetaAPI cloud MT5 engine handle. Import it and every call routes to the
MetaAPI cloud backend:

    from harness import farm_ext

    account = await farm_ext.get_account_information()
    price   = await farm_ext.get_current_price("EURUSD")
    order   = await farm_ext.market_buy("EURUSD", 0.1, stop_loss=1.0800)

Credential / account override
------------------------------
Use ``farm_ext.cred(account_id="...")`` to get a scoped copy bound to a
specific MetaAPI account:

    acc2 = farm_ext.cred(account_id="metaapi-account-uuid")
    order = await acc2.market_buy("XAUUSD", 0.05)
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional


class FarmExtEngine:
    """Engine handle for the MetaAPI cloud MT5 backend."""

    def __init__(self, account_id: Optional[str] = None) -> None:
        self._account_id = account_id

    def cred(self, *, account_id: Optional[str] = None) -> "FarmExtEngine":
        """Return a new engine bound to a specific MetaAPI account."""
        return FarmExtEngine(account_id=account_id or self._account_id)

    async def _get_client(self):
        from harness.barn.core.farm_ext_client import FarmExtClient
        return await FarmExtClient.get(account_id=self._account_id)

    # ------------------------------------------------------------------
    # Account
    # ------------------------------------------------------------------

    async def get_account_information(self) -> dict:
        c = await self._get_client()
        return await c.get_account_information()

    async def get_account_snapshot(self) -> dict:
        return await self.get_account_information()

    async def get_positions(self, symbol: Optional[str] = None) -> List[dict]:
        c = await self._get_client()
        positions = await c.get_positions()
        if symbol:
            positions = [p for p in positions if p.get("symbol") == symbol]
        return positions

    async def get_pending_orders(self, symbol: Optional[str] = None) -> List[dict]:
        c = await self._get_client()
        orders = await c.get_pending_orders()
        if symbol:
            orders = [o for o in orders if o.get("symbol") == symbol]
        return orders

    async def get_history_orders_by_time_range(
        self,
        from_date: Optional[Any] = None,
        to_date: Optional[Any] = None,
        offset: int = 0,
        limit: int = 1000,
    ) -> List[dict]:
        c = await self._get_client()
        return await c.get_history_orders_by_time_range(from_date, to_date, offset, limit)

    async def get_deals_by_time_range(
        self,
        from_date: Optional[Any] = None,
        to_date: Optional[Any] = None,
        offset: int = 0,
        limit: int = 1000,
    ) -> List[dict]:
        c = await self._get_client()
        return await c.get_deals_by_time_range(from_date, to_date, offset, limit)

    async def get_position(self, position_id: str) -> Optional[dict]:
        c = await self._get_client()
        return await c.get_position(position_id)

    async def get_order(self, order_id: str) -> Optional[dict]:
        c = await self._get_client()
        return await c.get_order(order_id)

    # ------------------------------------------------------------------
    # Market data
    # ------------------------------------------------------------------

    async def get_symbols(self) -> List[str]:
        c = await self._get_client()
        return await c.get_symbols()

    async def get_symbol_info(self, symbol: str) -> dict:
        c = await self._get_client()
        return await c.get_symbol_info(symbol)

    async def get_current_price(self, symbol: str) -> dict:
        c = await self._get_client()
        return await c.get_current_price(symbol)

    async def get_server_time(self) -> dict:
        c = await self._get_client()
        return await c.get_server_time()

    async def get_historical_ohlc(
        self,
        symbol: str,
        timeframe: str,
        count: int = 100,
    ) -> List[dict]:
        c = await self._get_client()
        return await c.get_historical_candles(symbol, timeframe, limit=count)

    async def get_historical_ohlc_range(
        self,
        symbol: str,
        timeframe: str,
        from_date: Optional[Any] = None,
        count: int = 100,
    ) -> List[dict]:
        c = await self._get_client()
        return await c.get_historical_candles(symbol, timeframe, start_time=from_date, limit=count)

    async def calculate_margin(self, order: dict) -> dict:
        c = await self._get_client()
        return await c.calculate_margin(order)

    async def subscribe_to_market_data(self, symbol: str) -> bool:
        c = await self._get_client()
        return await c.subscribe_to_market_data(symbol)

    # ------------------------------------------------------------------
    # Trading — market orders
    # ------------------------------------------------------------------

    async def market_buy(
        self,
        symbol: str,
        size: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.create_market_buy_order(
            symbol, size,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
        )

    async def market_sell(
        self,
        symbol: str,
        size: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.create_market_sell_order(
            symbol, size,
            stop_loss=stop_loss or 0.0,
            take_profit=take_profit or 0.0,
        )

    # ------------------------------------------------------------------
    # Trading — pending orders
    # ------------------------------------------------------------------

    async def buy_limit(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.buy_limit(symbol, size, level,
                                  stop_loss=stop_loss or 0.0,
                                  take_profit=take_profit or 0.0)

    async def sell_limit(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.sell_limit(symbol, size, level,
                                   stop_loss=stop_loss or 0.0,
                                   take_profit=take_profit or 0.0)

    async def buy_stop(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.buy_stop(symbol, size, level,
                                 stop_loss=stop_loss or 0.0,
                                 take_profit=take_profit or 0.0)

    async def sell_stop(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.sell_stop(symbol, size, level,
                                  stop_loss=stop_loss or 0.0,
                                  take_profit=take_profit or 0.0)

    async def buy_stop_limit(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_limit_price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.buy_stop_limit(symbol, size, level, stop_limit_price,
                                       stop_loss=stop_loss or 0.0,
                                       take_profit=take_profit or 0.0)

    async def sell_stop_limit(
        self,
        symbol: str,
        size: float,
        level: float,
        stop_limit_price: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.sell_stop_limit(symbol, size, level, stop_limit_price,
                                        stop_loss=stop_loss or 0.0,
                                        take_profit=take_profit or 0.0)

    # ------------------------------------------------------------------
    # Trading — position / order management
    # ------------------------------------------------------------------

    async def modify_position(
        self,
        ticket: str,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.modify_position(str(ticket), stop_loss=stop_loss, take_profit=take_profit)

    async def close_position(self, ticket: str) -> dict:
        c = await self._get_client()
        return await c.close_position(str(ticket))

    async def close_position_partial(self, ticket: str, volume: float) -> dict:
        c = await self._get_client()
        return await c.close_position_partial(str(ticket), volume)

    async def close_all_by_symbol(self, symbol: str) -> dict:
        c = await self._get_client()
        return await c.close_all_positions_by_symbol(symbol)

    async def modify_order(
        self,
        ticket: str,
        level: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None,
    ) -> dict:
        c = await self._get_client()
        return await c.modify_order(str(ticket), price=level,
                                    stop_loss=stop_loss or 0.0,
                                    take_profit=take_profit or 0.0)

    async def cancel_order(self, ticket: str) -> dict:
        c = await self._get_client()
        return await c.cancel_order(str(ticket))

    def __repr__(self) -> str:
        acct = self._account_id or "env"
        return f"<FarmExtEngine account_id={acct!r}>"


# Pre-built singleton
farm_ext = FarmExtEngine()
