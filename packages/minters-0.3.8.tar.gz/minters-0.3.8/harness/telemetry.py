"""
harness/telemetry.py
====================
Global telemetry bus — captures structured contract/bundler log entries
and exposes them for the ``/telemetry`` router endpoint.

Thread-safe.  Usable from both sync (bundler reader threads) and async
(FastAPI route) contexts.

Entry schema
------------
Every entry is a plain dict with at minimum:

    {
        "timestamp":  "2026-04-24T10:00:00.123456+00:00",  # ISO-8601 UTC
        "contract":   "eurusd_trend",                       # contract folder name
        "level":      "INFO",                               # DEBUG/INFO/WARNING/ERROR
        "message":    "Signal: BUY EURUSD @ 1.09500",
        "data":       { ... }   # parsed JSON payload when the line is valid JSON
    }

Contract stdout lines are pushed via ``push_line()``.  Plain text lines
result in ``data=None``; valid JSON lines have their parsed dict stored in
``data`` and ``message`` / ``level`` extracted automatically.
"""
from __future__ import annotations

import asyncio
import json
import os
import threading
from collections import deque
from datetime import datetime, timezone
from typing import Any, AsyncGenerator, Dict, List, Optional

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_MAX_ENTRIES = int(os.environ.get("TELEMETRY_MAX_ENTRIES", "1000"))


# ---------------------------------------------------------------------------
# TelemetryBus
# ---------------------------------------------------------------------------

class TelemetryBus:
    """
    Thread-safe ring buffer + async broadcaster for structured log entries.

    * Sync producers (bundler reader threads) call ``push()`` / ``push_line()``.
    * Async consumers (FastAPI route) call ``snapshot()`` or ``stream()``.
    """

    def __init__(self, maxlen: int = _MAX_ENTRIES) -> None:
        self._lock = threading.Lock()
        self._buf: deque[Dict[str, Any]] = deque(maxlen=maxlen)
        # Each SSE subscriber gets its own asyncio.Queue
        self._subscribers: List[asyncio.Queue] = []
        self._subs_lock = threading.Lock()

    # ------------------------------------------------------------------
    # Producer API (sync-safe; called from bundler reader threads)
    # ------------------------------------------------------------------

    def push(self, entry: Dict[str, Any]) -> None:
        """Append *entry* to the ring buffer and broadcast to all subscribers."""
        with self._lock:
            self._buf.append(entry)
        with self._subs_lock:
            dead: List[asyncio.Queue] = []
            for q in self._subscribers:
                try:
                    q.put_nowait(entry)
                except asyncio.QueueFull:
                    dead.append(q)
            for q in dead:
                try:
                    self._subscribers.remove(q)
                except ValueError:
                    pass

    def push_line(self, contract: str, raw_line: str) -> None:
        """
        Parse a raw stdout line from a contract subprocess and push it.

        * If the line is valid JSON, fields ``message`` and ``level`` are
          extracted and the full parsed object is stored in ``data``.
        * Plain-text lines are stored verbatim in ``message`` with ``data=None``.
        """
        line = raw_line.rstrip("\n").strip()
        if not line:
            return

        now = datetime.now(timezone.utc).isoformat()

        try:
            parsed: Dict[str, Any] = json.loads(line)
            entry: Dict[str, Any] = {
                "timestamp": parsed.get("timestamp", now),
                "contract":  contract,
                "level":     str(parsed.get("level", "INFO")).upper(),
                "message":   parsed.get("message", line),
                "data":      parsed,
            }
        except (json.JSONDecodeError, ValueError):
            entry = {
                "timestamp": now,
                "contract":  contract,
                "level":     "INFO",
                "message":   line,
                "data":      None,
            }

        self.push(entry)

    # ------------------------------------------------------------------
    # Consumer API (async)
    # ------------------------------------------------------------------

    def snapshot(self) -> List[Dict[str, Any]]:
        """Return a list copy of the ring buffer, oldest-first."""
        with self._lock:
            return list(self._buf)

    async def stream(self) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Async generator — yields entries as they arrive.

        Registers this coroutine as a subscriber and unregisters on exit
        (normal return *or* cancellation / exception).
        """
        q: asyncio.Queue = asyncio.Queue(maxsize=512)
        with self._subs_lock:
            self._subscribers.append(q)
        try:
            while True:
                entry = await q.get()
                yield entry
        finally:
            with self._subs_lock:
                try:
                    self._subscribers.remove(q)
                except ValueError:
                    pass

    def subscriber_count(self) -> int:
        with self._subs_lock:
            return len(self._subscribers)

    def entry_count(self) -> int:
        with self._lock:
            return len(self._buf)

    def clear(self) -> None:
        with self._lock:
            self._buf.clear()


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_bus: Optional[TelemetryBus] = None
_bus_lock = threading.Lock()


def get_bus() -> TelemetryBus:
    """Return the process-level TelemetryBus singleton (lazy-init)."""
    global _bus
    if _bus is None:
        with _bus_lock:
            if _bus is None:
                _bus = TelemetryBus()
    return _bus
