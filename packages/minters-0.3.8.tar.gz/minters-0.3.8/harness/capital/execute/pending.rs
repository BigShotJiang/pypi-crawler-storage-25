use anyhow::Result;
use crate::util::ExecutionResult;
use serde_json::json;

use crate::core::CapitalClient;

use super::result::map_execution_result;

pub(crate) async fn working_order(
    client: &CapitalClient,
    direction: &str,
    kind: &str,
    symbol: &str,
    size: f64,
    level: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult> {
    let epic = client.resolve_epic(symbol).await?;
    let size = client.clamp_size(&epic, size).await?;
    let response = client
        .request_value(
            reqwest::Method::POST,
            "/workingorders",
            Some(json!({
                "direction": direction,
                "epic": epic,
                "size": size,
                "level": level,
                "type": kind,
                "stopLevel": stop_loss,
                "profitLevel": take_profit,
            })),
            None,
        )
        .await?;

    Ok(map_execution_result(response))
}

/// POST /workingorders with a Good-Till-Date expiry.
/// `good_till_date` format: `"YYYY-MM-DDTHH:MM:SS"` (UTC), e.g. `"2026-04-12T23:59:59"`.
pub(crate) async fn working_order_gtd(
    client: &CapitalClient,
    direction: &str,
    kind: &str,
    symbol: &str,
    size: f64,
    level: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
    good_till_date: &str,
) -> Result<ExecutionResult> {
    let epic = client.resolve_epic(symbol).await?;
    let size = client.clamp_size(&epic, size).await?;
    let response = client
        .request_value(
            reqwest::Method::POST,
            "/workingorders",
            Some(json!({
                "direction": direction,
                "epic": epic,
                "size": size,
                "level": level,
                "type": kind,
                "stopLevel": stop_loss,
                "profitLevel": take_profit,
                "goodTillDate": good_till_date,
            })),
            None,
        )
        .await?;

    Ok(map_execution_result(response))
}
