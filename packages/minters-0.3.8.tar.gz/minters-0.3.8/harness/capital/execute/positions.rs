use anyhow::Result;
use crate::util::ExecutionResult;
use serde_json::json;

use crate::core::CapitalClient;

use super::result::{map_execution_result, resolve_ticket};

pub(crate) async fn modify_position(
    client: &CapitalClient,
    ticket_or_reference: &str,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult> {
    let ticket = resolve_ticket(client, ticket_or_reference).await?;
    let response = client
        .request_value(
            reqwest::Method::PUT,
            &format!("/positions/{ticket}"),
            Some(json!({
                "stopLevel": stop_loss,
                "profitLevel": take_profit,
            })),
            None,
        )
        .await?;

    Ok(map_execution_result(response))
}

pub(crate) async fn close_position_full(
    client: &CapitalClient,
    ticket_or_reference: &str,
) -> Result<ExecutionResult> {
    let ticket = resolve_ticket(client, ticket_or_reference).await?;
    let response = client
        .request_value(reqwest::Method::DELETE, &format!("/positions/{ticket}"), None, None)
        .await?;

    Ok(map_execution_result(response))
}
