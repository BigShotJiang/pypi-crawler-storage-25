use anyhow::Result;
use crate::util::ExecutionResult;
use serde_json::json;

use crate::core::CapitalClient;

use super::result::map_execution_result;

pub(crate) async fn market_order(
    client: &CapitalClient,
    direction: &str,
    symbol: &str,
    size: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult> {
    let epic = client.resolve_epic(symbol).await?;
    let size = client.clamp_size(&epic, size).await?;
    let response = client
        .request_value(
            reqwest::Method::POST,
            "/positions",
            Some(json!({
                "direction": direction,
                "epic": epic,
                "size": size,
                "stopLevel": stop_loss,
                "profitLevel": take_profit,
            })),
            None,
        )
        .await?;

    Ok(map_execution_result(response))
}
