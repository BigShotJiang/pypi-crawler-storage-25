mod market;
mod orders;
mod pending;
mod positions;
mod result;

use anyhow::Result;
use crate::util::ExecutionResult;
use serde_json::Value;

use crate::core::CapitalClient;

#[derive(Clone)]
pub struct CapitalExecuteApi {
    client: CapitalClient,
}

impl CapitalExecuteApi {
    pub(crate) fn new(client: CapitalClient) -> Self {
        Self { client }
    }

    pub async fn market_buy(
        &self,
        symbol: &str,
        size: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> Result<ExecutionResult> {
        market::market_order(&self.client, "BUY", symbol, size, stop_loss, take_profit).await
    }

    pub async fn market_sell(
        &self,
        symbol: &str,
        size: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> Result<ExecutionResult> {
        market::market_order(&self.client, "SELL", symbol, size, stop_loss, take_profit).await
    }

    pub async fn buy_limit(
        &self,
        symbol: &str,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> Result<ExecutionResult> {
        pending::working_order(&self.client, "BUY", "LIMIT", symbol, size, level, stop_loss, take_profit).await
    }

    pub async fn sell_limit(
        &self,
        symbol: &str,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> Result<ExecutionResult> {
        pending::working_order(&self.client, "SELL", "LIMIT", symbol, size, level, stop_loss, take_profit).await
    }

    pub async fn buy_stop(
        &self,
        symbol: &str,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> Result<ExecutionResult> {
        pending::working_order(&self.client, "BUY", "STOP", symbol, size, level, stop_loss, take_profit).await
    }

    pub async fn sell_stop(
        &self,
        symbol: &str,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> Result<ExecutionResult> {
        pending::working_order(&self.client, "SELL", "STOP", symbol, size, level, stop_loss, take_profit).await
    }

    pub async fn modify_position(
        &self,
        ticket_or_reference: &str,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> Result<ExecutionResult> {
        positions::modify_position(&self.client, ticket_or_reference, stop_loss, take_profit).await
    }

    pub async fn close_position_full(&self, ticket_or_reference: &str) -> Result<ExecutionResult> {
        positions::close_position_full(&self.client, ticket_or_reference).await
    }

    pub async fn modify_order(
        &self,
        ticket_or_reference: &str,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> Result<ExecutionResult> {
        orders::modify_order(&self.client, ticket_or_reference, level, stop_loss, take_profit).await
    }

    pub async fn cancel_order(&self, ticket_or_reference: &str) -> Result<ExecutionResult> {
        orders::cancel_order(&self.client, ticket_or_reference).await
    }

    /// Fetch the deal confirmation for a `dealReference` returned by any create/modify call.
    /// Returns the full `affectedDeals` array, final status, and level.
    pub async fn confirm_deal(&self, deal_reference: &str) -> Result<Value> {
        self.client
            .request_value(
                reqwest::Method::GET,
                &format!("/confirms/{deal_reference}"),
                None,
                None,
            )
            .await
    }

    /// Place a BUY LIMIT order that expires on a specific date/time.
    /// `good_till_date` format: `"YYYY-MM-DDTHH:MM:SS"` (UTC).
    pub async fn buy_limit_gtd(
        &self,
        symbol: &str,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
        good_till_date: &str,
    ) -> Result<ExecutionResult> {
        pending::working_order_gtd(
            &self.client,
            "BUY",
            "LIMIT",
            symbol,
            size,
            level,
            stop_loss,
            take_profit,
            good_till_date,
        )
        .await
    }

    /// Place a SELL LIMIT order that expires on a specific date/time.
    /// `good_till_date` format: `"YYYY-MM-DDTHH:MM:SS"` (UTC).
    pub async fn sell_limit_gtd(
        &self,
        symbol: &str,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
        good_till_date: &str,
    ) -> Result<ExecutionResult> {
        pending::working_order_gtd(
            &self.client,
            "SELL",
            "LIMIT",
            symbol,
            size,
            level,
            stop_loss,
            take_profit,
            good_till_date,
        )
        .await
    }

    /// Place a BUY STOP order that expires on a specific date/time.
    /// `good_till_date` format: `"YYYY-MM-DDTHH:MM:SS"` (UTC).
    pub async fn buy_stop_gtd(
        &self,
        symbol: &str,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
        good_till_date: &str,
    ) -> Result<ExecutionResult> {
        pending::working_order_gtd(
            &self.client,
            "BUY",
            "STOP",
            symbol,
            size,
            level,
            stop_loss,
            take_profit,
            good_till_date,
        )
        .await
    }

    /// Place a SELL STOP order that expires on a specific date/time.
    /// `good_till_date` format: `"YYYY-MM-DDTHH:MM:SS"` (UTC).
    pub async fn sell_stop_gtd(
        &self,
        symbol: &str,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
        good_till_date: &str,
    ) -> Result<ExecutionResult> {
        pending::working_order_gtd(
            &self.client,
            "SELL",
            "STOP",
            symbol,
            size,
            level,
            stop_loss,
            take_profit,
            good_till_date,
        )
        .await
    }
}