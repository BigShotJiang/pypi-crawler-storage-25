use anyhow::Result;
use crate::util::{ExecutionResult, first_field_string};
use serde_json::Value;

use crate::core::CapitalClient;

pub(crate) fn map_execution_result(value: Value) -> ExecutionResult {
    ExecutionResult {
        success: value
            .get("dealStatus")
            .and_then(Value::as_str)
            .map(|status| status.eq_ignore_ascii_case("ACCEPTED") || status.eq_ignore_ascii_case("OPEN"))
            .unwrap_or_else(|| value.get("status").and_then(Value::as_str) != Some("error")),
        id: first_field_string(&value, &[&["dealReference"], &["dealId"], &["id"]]),
        status: first_field_string(&value, &[&["dealStatus"], &["status"]]),
        message: first_field_string(&value, &[&["reason"], &["status"]]),
        raw: value,
    }
}

pub(crate) async fn resolve_ticket(client: &CapitalClient, ticket_or_reference: &str) -> Result<String> {
    // Capital.com deal references start with "o_" (positions) or "r_" (working orders).
    // Both must be resolved to a permanent dealId via GET /confirms/{reference}.
    if ticket_or_reference.starts_with("o_") || ticket_or_reference.starts_with("r_") {
        client.resolve_deal_reference(ticket_or_reference).await
    } else {
        Ok(ticket_or_reference.to_string())
    }
}
