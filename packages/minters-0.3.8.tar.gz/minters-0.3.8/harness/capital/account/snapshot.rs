use anyhow::Result;
use crate::util::{AccountSnapshot, first_field_f64, first_field_string, now_iso};
use serde_json::Value;

use crate::core::CapitalClient;

pub(crate) async fn fetch(client: &CapitalClient) -> Result<AccountSnapshot> {
    // Fetch sequentially to avoid a concurrent ensure_session() race on first call.
    let accounts_response = client.accounts_response().await?;
    let preferences = client
        .request_value(reqwest::Method::GET, "/accounts/preferences", None, None)
        .await
        .unwrap_or_else(|_| Value::Object(Default::default()));

    let account =
        select_current_account(&accounts_response, client.current_account_id().await?.as_deref())
            .unwrap_or_else(|| Value::Object(Default::default()));

    // ── Balance fields ─────────────────────────────────────────────────────────
    // Capital.com balance object:
    //   balance    → cash balance (deposits minus withdrawals, no P&L)
    //   deposit    → margin currently in use by open positions
    //   profitLoss → floating unrealised P&L across all open positions
    //   available  → free margin available to open new trades
    let balance     = first_field_f64(&account, &[&["balance", "balance"]]).unwrap_or_default();
    let profit_loss = first_field_f64(&account, &[&["balance", "profitLoss"]]).unwrap_or(0.0);
    let deposit     = first_field_f64(&account, &[&["balance", "deposit"]]).unwrap_or_default();
    let available   = first_field_f64(&account, &[&["balance", "available"]]).unwrap_or_default();

    // equity  = cash balance + unrealised P&L on open positions
    let equity = balance + profit_loss;

    // margin_level = (equity / margin_used) × 100  (0 when no positions are open)
    let margin_level = if deposit > 0.0 { (equity / deposit) * 100.0 } else { 0.0 };

    // ── Leverage ───────────────────────────────────────────────────────────────
    // Capital.com sets leverage per asset class, not per account.  Pick the
    // CURRENCIES class as the primary representative; fall back down the list.
    let leverage = preferences
        .get("leverages")
        .and_then(|l| {
            ["CURRENCIES", "COMMODITIES", "INDICES", "SHARES", "CRYPTOCURRENCIES"]
                .iter()
                .find_map(|&cat| l.get(cat))
        })
        .and_then(|cat| cat.get("current"))
        .and_then(Value::as_f64)
        .unwrap_or(1.0);

    // ── Currency ───────────────────────────────────────────────────────────────
    // Capital.com demo accounts append a lowercase 'd' suffix to currency codes
    // (e.g. "USDd").  Strip any non-uppercase characters to normalise.
    let currency = first_field_string(&account, &[&["currency"]])
        .map(|c| c.chars().filter(|ch| ch.is_ascii_uppercase()).collect::<String>())
        .filter(|c| !c.is_empty())
        .unwrap_or_else(|| "USD".to_string());

    // ── Trade allowed ──────────────────────────────────────────────────────────
    // Account status is "ENABLED" | "DISABLED" | "SUSPENDED".
    let trade_allowed = account
        .get("status")
        .and_then(Value::as_str)
        .map(|s| s.eq_ignore_ascii_case("ENABLED"))
        .unwrap_or(true);

    Ok(AccountSnapshot {
        login: first_field_string(&account, &[&["accountId"]]).unwrap_or_default(),
        server: if client.config().demo {
            "Capital Demo".to_string()
        } else {
            "Capital Live".to_string()
        },
        broker: "Capital.com".to_string(),
        currency,
        leverage,
        balance,
        equity,
        margin: deposit,
        free_margin: available,
        margin_level,
        trade_allowed,
        timestamp: now_iso(),
        // Raw stores the full account object plus the preferences response so
        // callers can access account name, type, symbol, hedging mode, etc.
        raw: serde_json::json!({
            "account": account,
            "preferences": preferences,
        }),
    })
}

fn select_current_account(response: &Value, current_account_id: Option<&str>) -> Option<Value> {
    let accounts = response.get("accounts")?.as_array()?;
    current_account_id
        .and_then(|wanted| {
            accounts.iter().find(|account| {
                account
                    .get("accountId")
                    .and_then(Value::as_str)
                    .map(|account_id| account_id == wanted)
                    .unwrap_or(false)
            })
        })
        .cloned()
        .or_else(|| accounts.first().cloned())
}
