use anyhow::Result;
use crate::util::{ClosedOrder, first_field_f64, first_field_string};
use serde_json::Value;

use crate::core::CapitalClient;

pub(crate) async fn fetch(client: &CapitalClient, limit: usize) -> Result<Vec<ClosedOrder>> {
    let response = match client
        .request_value(
            reqwest::Method::GET,
            "/history/transactions",
            None,
            Some(&[("max".to_string(), limit.to_string())]),
        )
        .await
    {
        Ok(value) => value,
        Err(_) => return Ok(Vec::new()),
    };

    let items = response
        .get("transactions")
        .or_else(|| response.get("activities"))
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default();

    Ok(items.into_iter().filter_map(map_closed_order).take(limit).collect())
}

/// GET /history/transactions filtered by date range and/or transaction type.
/// `from` / `to` format: `"YYYY-MM-DDTHH:MM:SS"` (UTC).
/// `transaction_type`: TRADE, SWAP, DEPOSIT, WITHDRAWAL, etc.
pub(crate) async fn fetch_range(
    client: &CapitalClient,
    from: Option<&str>,
    to: Option<&str>,
    transaction_type: Option<&str>,
) -> Result<Vec<ClosedOrder>> {
    let mut params: Vec<(String, String)> = Vec::new();
    if let Some(f) = from {
        params.push(("from".to_string(), f.to_string()));
    }
    if let Some(t) = to {
        params.push(("to".to_string(), t.to_string()));
    }
    if let Some(tt) = transaction_type {
        params.push(("type".to_string(), tt.to_string()));
    }
    let response = match client
        .request_value(
            reqwest::Method::GET,
            "/history/transactions",
            None,
            Some(&params),
        )
        .await
    {
        Ok(value) => value,
        Err(_) => return Ok(Vec::new()),
    };

    let items = response
        .get("transactions")
        .or_else(|| response.get("activities"))
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default();

    Ok(items.into_iter().filter_map(map_closed_order).collect())
}

fn map_closed_order(entry: Value) -> Option<ClosedOrder> {
    let symbol = first_field_string(&entry, &[&["epic"], &["marketName"], &["instrumentName"]])?;
    Some(ClosedOrder {
        id: first_field_string(&entry, &[&["reference"], &["dealId"], &["id"]]).unwrap_or_default(),
        symbol,
        side: first_field_string(&entry, &[&["direction"], &["type"]]).unwrap_or_default(),
        status: first_field_string(&entry, &[&["status"], &["transactionType"]]).unwrap_or_else(|| "closed".to_string()),
        volume: first_field_f64(&entry, &[&["size"]]).unwrap_or_default(),
        open_price: first_field_f64(&entry, &[&["openLevel"], &["level"]]),
        close_price: first_field_f64(&entry, &[&["closeLevel"]]),
        profit: first_field_f64(&entry, &[&["profitAndLoss"], &["profit"]]),
        commission: first_field_f64(&entry, &[&["commission"]]),
        swap: first_field_f64(&entry, &[&["funding"]]),
        opened_at: first_field_string(&entry, &[&["date"]]),
        closed_at: first_field_string(&entry, &[&["date"]]),
        raw: entry,
    })
}
