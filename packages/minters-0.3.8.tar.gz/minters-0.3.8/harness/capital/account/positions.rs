use anyhow::Result;
use crate::util::{Position, first_field_f64, first_field_string};
use serde_json::Value;

use crate::core::CapitalClient;

pub(crate) async fn fetch(client: &CapitalClient, symbol: Option<&str>) -> Result<Vec<Position>> {
    let response = client
        .request_value(reqwest::Method::GET, "/positions", None, None)
        .await?;
    let epic_filter = match symbol {
        Some(symbol) => Some(client.resolve_epic(symbol).await?),
        None => None,
    };

    Ok(response
        .get("positions")
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default()
        .into_iter()
        .filter_map(|entry| map_position(entry, epic_filter.as_deref()))
        .collect())
}

fn map_position(entry: Value, epic_filter: Option<&str>) -> Option<Position> {
    let position = entry.get("position").cloned().unwrap_or_else(|| entry.clone());
    let market = entry.get("market").cloned().unwrap_or_else(|| Value::Null);
    // Capital may expose epic under either `position.epic` or `market.epic`.
    let symbol = first_field_string(&position, &[&["epic"]])
        .or_else(|| first_field_string(&market, &[&["epic"]]))?;

    if epic_filter.is_some_and(|filter| filter != symbol) {
        return None;
    }

    Some(Position {
        id: first_field_string(&position, &[&["dealId"], &["dealReference"]]).unwrap_or_default(),
        symbol,
        side: first_field_string(&position, &[&["direction"]]).unwrap_or_default(),
        volume: first_field_f64(&position, &[&["size"]]).unwrap_or_default(),
        open_price: first_field_f64(&position, &[&["level"]]).unwrap_or_default(),
        current_price: first_field_f64(&market, &[&["bid"], &["offer"]]).or_else(|| first_field_f64(&position, &[&["level"]])),
        unrealized_profit: first_field_f64(&position, &[&["upl"], &["profit"]]),
        stop_loss: first_field_f64(&position, &[&["stopLevel"]]),
        take_profit: first_field_f64(&position, &[&["profitLevel"]]),
        opened_at: first_field_string(&position, &[&["createdDate"], &["createdDateUTC"]]),
        updated_at: first_field_string(&position, &[&["createdDate"], &["createdDateUTC"]]),
        raw: entry,
    })
}
