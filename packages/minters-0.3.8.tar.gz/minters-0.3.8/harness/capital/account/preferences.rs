use anyhow::Result;
use serde_json::Value;

use crate::core::CapitalClient;

/// GET /accounts/preferences — hedging mode, leverage settings.
pub(crate) async fn fetch_preferences(client: &CapitalClient) -> Result<Value> {
    client
        .request_value(reqwest::Method::GET, "/accounts/preferences", None, None)
        .await
}

/// GET /history/activity — recent account activity (deals, orders, edits).
/// `last_period_secs` defaults to 600 (10 min) if None; max 86400.
pub(crate) async fn fetch_activity(
    client: &CapitalClient,
    last_period_secs: Option<u64>,
) -> Result<Value> {
    let secs = last_period_secs.unwrap_or(600).to_string();
    client
        .request_value(
            reqwest::Method::GET,
            "/history/activity",
            None,
            Some(&[("lastPeriod".to_string(), secs)]),
        )
        .await
}

/// POST /accounts/topUp — add funds to the current Demo account balance.
/// Only valid on demo accounts. Amount can be negative to subtract.
pub(crate) async fn top_up_demo(client: &CapitalClient, amount: f64) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::POST,
            "/accounts/topUp",
            Some(serde_json::json!({ "amount": amount })),
            None,
        )
        .await
}

/// GET /positions/{dealId} — single open position by deal identifier.
pub(crate) async fn fetch_position_by_id(
    client: &CapitalClient,
    deal_id: &str,
) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::GET,
            &format!("/positions/{deal_id}"),
            None,
            None,
        )
        .await
}

/// PUT /accounts/preferences — update hedging mode and/or leverage settings.
/// Pass a JSON object for `leverages`, e.g. `json!({ "CURRENCIES": 10 })`.
/// Pass `None` for either parameter to leave it unchanged.
pub(crate) async fn update_preferences(
    client: &CapitalClient,
    leverages: Option<&Value>,
    hedging_mode: Option<bool>,
) -> Result<Value> {
    let mut body = serde_json::Map::new();
    if let Some(lev) = leverages {
        body.insert("leverages".to_string(), lev.clone());
    }
    if let Some(hm) = hedging_mode {
        body.insert("hedgingMode".to_string(), Value::Bool(hm));
    }
    client
        .request_value(
            reqwest::Method::PUT,
            "/accounts/preferences",
            Some(Value::Object(body)),
            None,
        )
        .await
}

/// GET /history/activity — account activity filtered by absolute date range.
/// `from` / `to` are ISO-8601 strings. Both `"2026-04-01T00:00:00"` and
/// `"2026-04-01T00:00:00.000"` are accepted; milliseconds are added automatically
/// if absent, as the Capital API requires them.
/// `filter` is an optional FIQL expression, e.g. `"type==POSITION;status==ACCEPTED"`.
pub(crate) async fn fetch_activity_range(
    client: &CapitalClient,
    from: Option<&str>,
    to: Option<&str>,
    detailed: bool,
    filter: Option<&str>,
) -> Result<Value> {
    /// Ensure the datetime string has milliseconds (Capital requires `.000`).
    fn ensure_ms(s: &str) -> String {
        if s.contains('.') { s.to_string() } else { format!("{s}.000") }
    }
    let mut params: Vec<(String, String)> = Vec::new();
    if let Some(f) = from {
        params.push(("from".to_string(), ensure_ms(f)));
    }
    if let Some(t) = to {
        params.push(("to".to_string(), ensure_ms(t)));
    }
    if detailed {
        params.push(("detailed".to_string(), "true".to_string()));
    }
    if let Some(f) = filter {
        params.push(("filter".to_string(), f.to_string()));
    }
    client
        .request_value(
            reqwest::Method::GET,
            "/history/activity",
            None,
            Some(&params),
        )
        .await
}
