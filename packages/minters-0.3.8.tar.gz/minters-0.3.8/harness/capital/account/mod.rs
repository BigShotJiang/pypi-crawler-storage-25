mod history;
mod orders;
mod positions;
mod preferences;
mod snapshot;

use anyhow::Result;
use crate::util::{AccountSnapshot, ClosedOrder, PendingOrder, Position};
use serde_json::Value;

use crate::core::CapitalClient;

#[derive(Clone)]
pub struct CapitalAccountApi {
    client: CapitalClient,
}

impl CapitalAccountApi {
    pub(crate) fn new(client: CapitalClient) -> Self {
        Self { client }
    }

    pub async fn snapshot(&self) -> Result<AccountSnapshot> {
        snapshot::fetch(&self.client).await
    }

    pub async fn positions(&self, symbol: Option<&str>) -> Result<Vec<Position>> {
        positions::fetch(&self.client, symbol).await
    }

    pub async fn position_by_id(&self, deal_id: &str) -> Result<Value> {
        preferences::fetch_position_by_id(&self.client, deal_id).await
    }

    pub async fn pending_orders(&self, symbol: Option<&str>) -> Result<Vec<PendingOrder>> {
        orders::fetch(&self.client, symbol).await
    }

    pub async fn closed_orders(&self, limit: usize) -> Result<Vec<ClosedOrder>> {
        history::fetch(&self.client, limit).await
    }

    /// Returns account preferences: hedging mode and leverage settings by asset class.
    pub async fn account_preferences(&self) -> Result<Value> {
        preferences::fetch_preferences(&self.client).await
    }

    /// Returns recent account activity (deals opened/closed, order events, edits).
    /// `last_period_secs` window defaults to 600; max is 86400 (one day).
    pub async fn activity_history(&self, last_period_secs: Option<u64>) -> Result<Value> {
        preferences::fetch_activity(&self.client, last_period_secs).await
    }

    /// Tops up the demo account balance. Only valid on demo accounts.
    pub async fn top_up_demo(&self, amount: f64) -> Result<Value> {
        preferences::top_up_demo(&self.client, amount).await
    }

    /// Update account preferences — change leverage values and/or hedging mode.
    /// `leverages` is a JSON object mapping asset class to new leverage value,
    /// e.g. `json!({ "CURRENCIES": 10, "SHARES": 5 })`.
    pub async fn update_account_preferences(
        &self,
        leverages: Option<&serde_json::Value>,
        hedging_mode: Option<bool>,
    ) -> Result<Value> {
        preferences::update_preferences(&self.client, leverages, hedging_mode).await
    }

    /// Account activity filtered by an absolute date range.
    /// `from` / `to` are ISO-8601 datetime strings: `"2026-04-01T00:00:00"`.
    /// `detailed=true` adds extra context to each event.
    pub async fn activity_history_range(
        &self,
        from: Option<&str>,
        to: Option<&str>,
        detailed: bool,
    ) -> Result<Value> {
        preferences::fetch_activity_range(&self.client, from, to, detailed, None).await
    }

    /// Closed trade history filtered by date range and/or transaction type.
    /// `transaction_type` values: TRADE, SWAP, DEPOSIT, WITHDRAWAL, etc.
    pub async fn closed_orders_range(
        &self,
        from: Option<&str>,
        to: Option<&str>,
        transaction_type: Option<&str>,
    ) -> Result<Vec<ClosedOrder>> {
        history::fetch_range(&self.client, from, to, transaction_type).await
    }
}