use anyhow::Result;
use crate::util::{PendingOrder, first_field_f64, first_field_string};
use serde_json::Value;

use crate::core::CapitalClient;

pub(crate) async fn fetch(client: &CapitalClient, symbol: Option<&str>) -> Result<Vec<PendingOrder>> {
    let response = client
        .request_value(reqwest::Method::GET, "/workingorders", None, None)
        .await?;
    let epic_filter = match symbol {
        Some(symbol) => Some(client.resolve_epic(symbol).await?),
        None => None,
    };

    Ok(response
        .get("workingOrders")
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default()
        .into_iter()
        .filter_map(|entry| map_pending_order(entry, epic_filter.as_deref()))
        .collect())
}

fn map_pending_order(entry: Value, epic_filter: Option<&str>) -> Option<PendingOrder> {
    let order = entry
        .get("workingOrderData")
        .cloned()
        .unwrap_or_else(|| entry.clone());
    let market = entry.get("marketData").cloned().unwrap_or_else(|| Value::Null);
    let symbol = first_field_string(&order, &[&["epic"]])?;

    if epic_filter.is_some_and(|filter| filter != symbol) {
        return None;
    }

    Some(PendingOrder {
        id: first_field_string(&order, &[&["dealId"], &["dealReference"]]).unwrap_or_default(),
        symbol,
        side: first_field_string(&order, &[&["direction"]]).unwrap_or_default(),
        order_type: first_field_string(&order, &[&["type"], &["orderType"]]).unwrap_or_else(|| "WORKING".to_string()),
        status: first_field_string(&order, &[&["status"]]).unwrap_or_else(|| "PENDING".to_string()),
        volume: first_field_f64(&order, &[&["orderSize"], &["size"]]).unwrap_or_default(),
        price: first_field_f64(&order, &[&["level"]]),
        current_price: first_field_f64(&market, &[&["bid"], &["offer"]]),
        stop_loss: first_field_f64(&order, &[&["stopLevel"]]),
        take_profit: first_field_f64(&order, &[&["profitLevel"]]),
        created_at: first_field_string(&order, &[&["createdDate"], &["createdDateUTC"]]),
        raw: entry,
    })
}
