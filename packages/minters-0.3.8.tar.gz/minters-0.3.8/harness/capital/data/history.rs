use anyhow::Result;
use crate::util::{Candle, first_field_f64, first_field_string};
use serde_json::Value;

use crate::core::CapitalClient;

pub(crate) async fn fetch(
    client: &CapitalClient,
    symbol: &str,
    timeframe: &str,
    count: usize,
) -> Result<Vec<Candle>> {
    let epic = client.resolve_epic(symbol).await?;
    let resolution = map_resolution(timeframe);
    let response = client
        .request_value(
            reqwest::Method::GET,
            &format!("/prices/{epic}"),
            None,
            Some(&[
                ("resolution".to_string(), resolution.to_string()),
                ("max".to_string(), count.to_string()),
            ]),
        )
        .await?;

    let prices = response
        .get("prices")
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default();

    Ok(prices.into_iter().map(map_candle).collect())
}

/// GET /prices/{epic} filtered by absolute date range instead of bar count.
/// `from` / `to` format: `"YYYY-MM-DDTHH:MM:SS"` (e.g. `"2026-04-09T00:00:00"`).
pub(crate) async fn fetch_range(
    client: &CapitalClient,
    symbol: &str,
    timeframe: &str,
    from: &str,
    to: &str,
) -> Result<Vec<Candle>> {
    let epic = client.resolve_epic(symbol).await?;
    let resolution = map_resolution(timeframe);
    let response = client
        .request_value(
            reqwest::Method::GET,
            &format!("/prices/{epic}"),
            None,
            Some(&[
                ("resolution".to_string(), resolution.to_string()),
                ("from".to_string(), from.to_string()),
                ("to".to_string(), to.to_string()),
            ]),
        )
        .await?;

    let prices = response
        .get("prices")
        .and_then(Value::as_array)
        .cloned()
        .unwrap_or_default();

    Ok(prices.into_iter().map(map_candle).collect())
}

fn map_resolution(timeframe: &str) -> &'static str {
    match timeframe.trim().to_ascii_lowercase().as_str() {
        "1m" => "MINUTE",
        "5m" => "MINUTE_5",
        "15m" => "MINUTE_15",
        "30m" => "MINUTE_30",
        "1h" => "HOUR",
        "4h" => "HOUR_4",
        "1d" => "DAY",
        "1w" => "WEEK",
        _ => "MINUTE",
    }
}

fn side_price(entry: &Value, key: &str) -> f64 {
    entry.get(key)
        .and_then(Value::as_object)
        .and_then(|price| {
            price
                .get("bid")
                .and_then(Value::as_f64)
                .or_else(|| price.get("ask").and_then(Value::as_f64))
                .or_else(|| {
                    price.get("bid").and_then(Value::as_str).and_then(|value| value.parse::<f64>().ok())
                })
                .or_else(|| {
                    price.get("ask").and_then(Value::as_str).and_then(|value| value.parse::<f64>().ok())
                })
        })
        .unwrap_or_default()
}

fn map_candle(entry: Value) -> Candle {
    Candle {
        time: first_field_string(&entry, &[&["snapshotTime"], &["snapshotTimeUTC"]]).unwrap_or_default(),
        open: side_price(&entry, "openPrice"),
        high: side_price(&entry, "highPrice"),
        low: side_price(&entry, "lowPrice"),
        close: side_price(&entry, "closePrice"),
        volume: first_field_f64(&entry, &[&["lastTradedVolume"]]).unwrap_or_default(),
        raw: entry,
    }
}
