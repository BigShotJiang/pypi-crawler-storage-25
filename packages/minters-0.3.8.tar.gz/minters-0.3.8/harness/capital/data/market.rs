use anyhow::Result;
use serde_json::Value;

use crate::core::CapitalClient;

pub(crate) async fn fetch(client: &CapitalClient, symbol: &str) -> Result<Value> {
    let epic = client.resolve_epic(symbol).await?;
    client.market_details(&epic).await
}
