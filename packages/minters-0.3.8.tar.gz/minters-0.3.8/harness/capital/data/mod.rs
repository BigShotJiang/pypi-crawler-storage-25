mod history;
mod market;
mod quotes;
mod search;

use anyhow::Result;
use crate::util::{Candle, PriceQuote};
use serde_json::Value;

use crate::core::CapitalClient;

#[derive(Clone)]
pub struct CapitalDataApi {
    client: CapitalClient,
}

impl CapitalDataApi {
    pub(crate) fn new(client: CapitalClient) -> Self {
        Self { client }
    }

    pub async fn current_price(&self, symbol: &str) -> Result<PriceQuote> {
        quotes::fetch(&self.client, symbol).await
    }

    pub async fn market_details(&self, symbol: &str) -> Result<Value> {
        market::fetch(&self.client, symbol).await
    }

    pub async fn historical_ohlc(
        &self,
        symbol: &str,
        timeframe: &str,
        count: usize,
    ) -> Result<Vec<Candle>> {
        history::fetch(&self.client, symbol, timeframe, count).await
    }

    /// Free-text market search — returns matching markets with instrument info and snapshot.
    pub async fn search_markets(&self, query: &str) -> Result<Value> {
        search::search_markets(&self.client, query).await
    }

    /// Fetch details for up to 50 known epics in a single call.
    pub async fn markets_by_epics(&self, epics: &[&str]) -> Result<Value> {
        search::markets_by_epics(&self.client, epics).await
    }

    /// Top-level market category nodes (e.g. Currencies, Indices, Commodities…).
    pub async fn market_navigation(&self) -> Result<Value> {
        search::navigation_top(&self.client).await
    }

    /// Markets / sub-nodes under a category node.
    pub async fn market_navigation_node(&self, node_id: &str) -> Result<Value> {
        search::navigation_node(&self.client, node_id).await
    }

    /// Long/short sentiment percentages for a single market.
    pub async fn client_sentiment(&self, market_id: &str) -> Result<Value> {
        search::client_sentiment(&self.client, market_id).await
    }

    /// Long/short sentiment percentages for multiple markets in one call.
    pub async fn client_sentiment_batch(&self, market_ids: &[&str]) -> Result<Value> {
        search::client_sentiment_batch(&self.client, market_ids).await
    }

    /// All watchlists belonging to the current account.
    pub async fn watchlists(&self) -> Result<Value> {
        search::all_watchlists(&self.client).await
    }

    /// Markets inside a specific watchlist.
    pub async fn watchlist(&self, watchlist_id: &str) -> Result<Value> {
        search::watchlist_by_id(&self.client, watchlist_id).await
    }

    /// Historical OHLC bars filtered by absolute date range instead of bar count.
    /// `from` / `to` format: `"YYYY-MM-DDTHH:MM:SS"` (e.g. `"2026-04-09T00:00:00"`).
    pub async fn historical_ohlc_range(
        &self,
        symbol: &str,
        timeframe: &str,
        from: &str,
        to: &str,
    ) -> Result<Vec<Candle>> {
        history::fetch_range(&self.client, symbol, timeframe, from, to).await
    }

    /// Create a new watchlist with a name and an optional initial list of market epics.
    pub async fn create_watchlist(&self, name: &str, epics: &[&str]) -> Result<Value> {
        search::create_watchlist(&self.client, name, epics).await
    }

    /// Add a single market epic to an existing watchlist.
    pub async fn add_to_watchlist(&self, watchlist_id: &str, epic: &str) -> Result<Value> {
        search::add_to_watchlist(&self.client, watchlist_id, epic).await
    }

    /// Delete a watchlist entirely.
    pub async fn delete_watchlist(&self, watchlist_id: &str) -> Result<Value> {
        search::delete_watchlist(&self.client, watchlist_id).await
    }

    /// Remove a single market epic from a watchlist without deleting the watchlist.
    pub async fn remove_from_watchlist(&self, watchlist_id: &str, epic: &str) -> Result<Value> {
        search::remove_from_watchlist(&self.client, watchlist_id, epic).await
    }
}