use anyhow::Result;
use serde_json::Value;

use crate::core::CapitalClient;

/// GET /markets?searchTerm= — free-text search across all market epics/names.
pub(crate) async fn search_markets(client: &CapitalClient, query: &str) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::GET,
            "/markets",
            None,
            Some(&[("searchTerm".to_string(), query.to_string())]),
        )
        .await
}

/// GET /markets?epics=A,B,C — fetch details for a list of known epics (max 50).
pub(crate) async fn markets_by_epics(client: &CapitalClient, epics: &[&str]) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::GET,
            "/markets",
            None,
            Some(&[("epics".to_string(), epics.join(","))]),
        )
        .await
}

/// GET /marketnavigation — top-level market category nodes.
pub(crate) async fn navigation_top(client: &CapitalClient) -> Result<Value> {
    client
        .request_value(reqwest::Method::GET, "/marketnavigation", None, None)
        .await
}

/// GET /marketnavigation/{nodeId} — sub-nodes / markets under a category.
pub(crate) async fn navigation_node(client: &CapitalClient, node_id: &str) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::GET,
            &format!("/marketnavigation/{node_id}"),
            None,
            Some(&[("limit".to_string(), "500".to_string())]),
        )
        .await
}

/// GET /clientsentiment/{marketId} — long/short percentage for a single market.
pub(crate) async fn client_sentiment(client: &CapitalClient, market_id: &str) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::GET,
            &format!("/clientsentiment/{market_id}"),
            None,
            None,
        )
        .await
}

/// GET /clientsentiment?marketIds=A,B — sentiment for multiple markets at once.
pub(crate) async fn client_sentiment_batch(
    client: &CapitalClient,
    market_ids: &[&str],
) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::GET,
            "/clientsentiment",
            None,
            Some(&[("marketIds".to_string(), market_ids.join(","))]),
        )
        .await
}

/// GET /watchlists — all watchlists for the current account.
pub(crate) async fn all_watchlists(client: &CapitalClient) -> Result<Value> {
    client
        .request_value(reqwest::Method::GET, "/watchlists", None, None)
        .await
}

/// GET /watchlists/{watchlistId} — markets in a specific watchlist.
pub(crate) async fn watchlist_by_id(client: &CapitalClient, watchlist_id: &str) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::GET,
            &format!("/watchlists/{watchlist_id}"),
            None,
            None,
        )
        .await
}

/// POST /watchlists — create a new watchlist with a name and optional initial epics.
pub(crate) async fn create_watchlist(
    client: &CapitalClient,
    name: &str,
    epics: &[&str],
) -> Result<Value> {
    use serde_json::json;
    let epics_arr: Vec<serde_json::Value> =
        epics.iter().map(|e| serde_json::Value::String(e.to_string())).collect();
    client
        .request_value(
            reqwest::Method::POST,
            "/watchlists",
            Some(json!({ "name": name, "epics": epics_arr })),
            None,
        )
        .await
}

/// PUT /watchlists/{watchlistId} — add a single market epic to an existing watchlist.
pub(crate) async fn add_to_watchlist(
    client: &CapitalClient,
    watchlist_id: &str,
    epic: &str,
) -> Result<Value> {
    use serde_json::json;
    client
        .request_value(
            reqwest::Method::PUT,
            &format!("/watchlists/{watchlist_id}"),
            Some(json!({ "epic": epic })),
            None,
        )
        .await
}

/// DELETE /watchlists/{watchlistId} — delete an entire watchlist.
pub(crate) async fn delete_watchlist(
    client: &CapitalClient,
    watchlist_id: &str,
) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::DELETE,
            &format!("/watchlists/{watchlist_id}"),
            None,
            None,
        )
        .await
}

/// DELETE /watchlists/{watchlistId}/{epic} — remove one market from a watchlist.
pub(crate) async fn remove_from_watchlist(
    client: &CapitalClient,
    watchlist_id: &str,
    epic: &str,
) -> Result<Value> {
    client
        .request_value(
            reqwest::Method::DELETE,
            &format!("/watchlists/{watchlist_id}/{epic}"),
            None,
            None,
        )
        .await
}
