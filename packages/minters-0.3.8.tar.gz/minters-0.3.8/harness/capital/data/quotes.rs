use anyhow::Result;
use crate::util::{PriceQuote, first_field_f64, first_field_string};
use serde_json::Value;

use crate::core::CapitalClient;

pub(crate) async fn fetch(client: &CapitalClient, symbol: &str) -> Result<PriceQuote> {
    let epic = client.resolve_epic(symbol).await?;
    let market = client.market_details(&epic).await?;
    let snapshot = market.get("snapshot").cloned().unwrap_or_else(|| Value::Null);
    let bid = first_field_f64(&snapshot, &[&["bid"]]).unwrap_or_default();
    let ask = first_field_f64(&snapshot, &[&["offer"]]).unwrap_or_default();

    Ok(PriceQuote {
        symbol: epic,
        bid,
        ask,
        mid: Some((bid + ask) / 2.0),
        time: first_field_string(&snapshot, &[&["updateTime"]]),
        raw: market,
    })
}
