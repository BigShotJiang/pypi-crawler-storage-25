# nursery-capital

Capital.com CFD broker integration crate. Connects to the Capital.com v1 REST API using encrypted session authentication (CST + X-SECURITY-TOKEN headers). Sessions are created automatically on first use and refreshed transparently on 401 responses.

```
CapitalClient (Rust) ──HTTPS──▶ Capital.com REST API (demo or live)
```

---

## Table of Contents

- [Environment Setup](#environment-setup)
- [Module Structure](#module-structure)
- [Client Construction](#client-construction)
- [Return Types](#return-types)
- [Account API](#account-api)
  - [snapshot](#snapshot)
  - [account_preferences](#account_preferences)
  - [update_account_preferences](#update_account_preferences)
  - [activity_history](#activity_history)
  - [activity_history_range](#activity_history_range)
  - [positions](#positions)
  - [position_by_id](#position_by_id)
  - [pending_orders](#pending_orders)
  - [closed_orders](#closed_orders)
  - [closed_orders_range](#closed_orders_range)
  - [top_up_demo](#top_up_demo)
- [Data API](#data-api)
  - [current_price](#current_price)
  - [market_details](#market_details)
  - [historical_ohlc](#historical_ohlc)
  - [historical_ohlc_range](#historical_ohlc_range)
  - [search_markets](#search_markets)
  - [markets_by_epics](#markets_by_epics)
  - [market_navigation](#market_navigation)
  - [market_navigation_node](#market_navigation_node)
  - [client_sentiment](#client_sentiment)
  - [client_sentiment_batch](#client_sentiment_batch)
  - [watchlists](#watchlists)
  - [watchlist](#watchlist)
  - [create_watchlist](#create_watchlist)
  - [add_to_watchlist](#add_to_watchlist)
  - [delete_watchlist](#delete_watchlist)
  - [remove_from_watchlist](#remove_from_watchlist)
- [Execute API](#execute-api)
  - [market_buy / market_sell](#market_buy--market_sell)
  - [buy_limit / sell_limit](#buy_limit--sell_limit)
  - [buy_stop / sell_stop](#buy_stop--sell_stop)
  - [buy_limit_gtd / sell_limit_gtd / buy_stop_gtd / sell_stop_gtd](#buy_limit_gtd--sell_limit_gtd--buy_stop_gtd--sell_stop_gtd)
  - [modify_position](#modify_position)
  - [close_position_full](#close_position_full)
  - [modify_order](#modify_order)
  - [cancel_order](#cancel_order)
  - [confirm_deal](#confirm_deal)
- [Session Management](#session-management)
- [Running the Test Suites](#running-the-test-suites)

---

## Environment Setup

Create a `.env` file in the `composer/` directory (or any parent directory):

```env
CAPITAL_API_KEY=your_api_key_here
CAPITAL_IDENTIFIER=your_email@example.com
CAPITAL_PASSWORD=your_password_here
CAPITAL_DEMO=true
```

| Variable | Required | Default | Description |
|---|---|---|---|
| `CAPITAL_API_KEY` | Yes | — | API key from Capital.com dashboard |
| `CAPITAL_IDENTIFIER` | Yes | — | Account login email |
| `CAPITAL_PASSWORD` | Yes | — | Account password |
| `CAPITAL_DEMO` | No | `false` | `true` to use the demo environment |
| `CAPITAL_DEMO_URL` | No | `https://demo-api-capital.backend-capital.com` | Override demo base URL |
| `CAPITAL_BASE_URL` | No | `https://api-capital.backend-capital.com` | Override live base URL |

All requests go to `{base_url}/api/v1/{endpoint}`. Trailing slashes on the URL are stripped automatically.

---

## Module Structure

```
nursery/capital/
├── core/
│   ├── config.rs       CapitalConfig::from_env()
│   ├── session.rs      SessionState (CST + X-SECURITY-TOKEN)
│   └── client.rs       CapitalClient — HTTP, session refresh, epic resolution
├── account/
│   ├── snapshot.rs     concurrent fetch of /accounts + /accounts/preferences
│   ├── positions.rs    GET /positions
│   ├── orders.rs       GET /workingorders
│   ├── history.rs      GET /history/transactions
│   └── preferences.rs  account preferences, activity, top-up, position by ID
├── data/
│   ├── quotes.rs       GET /markets/{epic} → PriceQuote (bid/ask/mid)
│   ├── market.rs       GET /markets/{epic} → full JSON
│   ├── history.rs      GET /prices/{epic}  → Vec<Candle>
│   └── search.rs       search, epics batch, navigation, sentiment, watchlists
└── execute/
    ├── market.rs       POST /positions (market orders)
    ├── pending.rs      POST /workingorders (limit + stop orders)
    ├── positions.rs    PUT/DELETE /positions/{id} (modify + close)
    ├── orders.rs       PUT/DELETE /workingorders/{id} (modify + cancel)
    └── result.rs       ExecutionResult mapper, ticket resolver
```

---

## Client Construction

```rust
use nursery_capital::CapitalClient;

// Reads CAPITAL_DEMO env var to decide environment
let client = CapitalClient::from_env(None)?;

// Force demo environment regardless of env var
let client = CapitalClient::from_env(Some(true))?;

// Force live environment regardless of env var
let client = CapitalClient::from_env(Some(false))?;
```

`from_env` reads `.env` via `dotenvy` automatically. No explicit session setup is needed — the first API call creates the session.

The `config()` accessor exposes the resolved settings:

```rust
println!("base_url = {}", client.config().base_url);
println!("demo     = {}", client.config().demo);
```

---

## Return Types

All shared return types live in `nursery-util`:

```rust
pub struct AccountSnapshot {
    pub login: String,          // accountId from Capital.com
    pub server: String,         // "Capital Demo" or "Capital Live"
    pub broker: String,         // always "Capital.com"
    pub currency: String,       // e.g. "USD" (demo suffix 'd' is stripped)
    pub leverage: f64,          // from /accounts/preferences → leverages.CURRENCIES.current
    pub balance: f64,           // cash balance (deposits − withdrawals, no P&L)
    pub equity: f64,            // balance + unrealised P&L on open positions
    pub margin: f64,            // margin locked by open positions (deposit field)
    pub free_margin: f64,       // available margin (available field)
    pub margin_level: f64,      // (equity / margin) × 100, 0 when no positions open
    pub trade_allowed: bool,    // account status == "ENABLED"
    pub timestamp: String,      // ISO-8601 time of fetch
    pub raw: Value,             // { "account": {...}, "preferences": {...} }
}

pub struct PriceQuote {
    pub symbol: String,         // resolved epic (e.g. "GOLD")
    pub bid: f64,
    pub ask: f64,
    pub mid: Option<f64>,       // (bid + ask) / 2
    pub time: Option<String>,   // updateTime from snapshot
    pub raw: Value,             // full /markets/{epic} response
}

pub struct Candle {
    pub time: String,           // snapshotTime / snapshotTimeUTC
    pub open: f64,              // bid side of openPrice object
    pub high: f64,              // bid side of highPrice object
    pub low: f64,               // bid side of lowPrice object
    pub close: f64,             // bid side of closePrice object
    pub volume: f64,            // lastTradedVolume
    pub raw: Value,             // full price entry from /prices/{epic}
}

pub struct Position {
    pub id: String,             // dealId or dealReference
    pub symbol: String,         // epic
    pub side: String,           // "BUY" or "SELL"
    pub volume: f64,            // size
    pub open_price: f64,        // level at open
    pub current_price: Option<f64>,    // market bid/offer
    pub unrealized_profit: Option<f64>, // upl
    pub stop_loss: Option<f64>,         // stopLevel
    pub take_profit: Option<f64>,       // profitLevel
    pub opened_at: Option<String>,      // createdDate
    pub updated_at: Option<String>,
    pub raw: Value,
}

pub struct PendingOrder {
    pub id: String,             // dealId or dealReference
    pub symbol: String,         // epic
    pub side: String,           // "BUY" or "SELL"
    pub order_type: String,     // "LIMIT" or "STOP"
    pub status: String,         // "PENDING" or broker status
    pub volume: f64,            // orderSize
    pub price: Option<f64>,     // level (trigger price)
    pub current_price: Option<f64>,
    pub stop_loss: Option<f64>,
    pub take_profit: Option<f64>,
    pub created_at: Option<String>,
    pub raw: Value,
}

pub struct ClosedOrder {
    pub id: String,
    pub symbol: String,
    pub side: String,
    pub status: String,
    pub volume: f64,
    pub open_price: Option<f64>,
    pub close_price: Option<f64>,
    pub profit: Option<f64>,        // profitAndLoss
    pub commission: Option<f64>,
    pub swap: Option<f64>,          // funding
    pub opened_at: Option<String>,
    pub closed_at: Option<String>,
    pub raw: Value,
}

pub struct ExecutionResult {
    pub success: bool,          // dealStatus == "ACCEPTED"/"OPEN", or no error status
    pub id: Option<String>,     // dealReference (use confirm_deal to get permanent dealId)
    pub status: Option<String>, // dealStatus field
    pub message: Option<String>,// reason field (error description when success=false)
    pub raw: Value,
}
```

---

## Account API

Access via `client.account()`.

---

### `snapshot`

```rust
pub async fn snapshot(&self) -> Result<AccountSnapshot>
```

Fetches `/accounts` and `/accounts/preferences` concurrently and returns a unified `AccountSnapshot`. This is the primary way to read current account state.

**Capital.com balance schema used internally:**

| API field | Mapped to |
|---|---|
| `balance.balance` | `balance` — cash only, no P&L |
| `balance.deposit` | `margin` — locked by open positions |
| `balance.available` | `free_margin` |
| `balance.profitLoss` | added to `balance` to produce `equity` |
| `status` | `trade_allowed` when `== "ENABLED"` |
| `currency` | `currency` with non-uppercase chars stripped (removes demo `'d'` suffix) |
| `preferences.leverages.CURRENCIES.current` | `leverage` |

```rust
let snap = client.account().snapshot().await?;

println!("login        : {}", snap.login);       // "306911353591116062"
println!("server       : {}", snap.server);      // "Capital Demo"
println!("broker       : {}", snap.broker);      // "Capital.com"
println!("currency     : {}", snap.currency);    // "USD"
println!("leverage     : {}", snap.leverage);    // e.g. 100.0 (CURRENCIES class)
println!("balance      : {}", snap.balance);     // 905.7
println!("equity       : {}", snap.equity);      // 905.7 (balance + floating P&L)
println!("margin       : {}", snap.margin);      // 0.0 (no open positions)
println!("free_margin  : {}", snap.free_margin); // 905.7
println!("margin_level : {}", snap.margin_level);// 100.0 — (equity/margin)*100
println!("trade_allowed: {}", snap.trade_allowed);// true
```

**Actual test output (demo account, April 2026):**
```
══ AccountSnapshot (demo) ══
  login        : 306911353591116062
  server       : Capital Demo
  broker       : Capital.com
  currency     : USD
  leverage     : 1
  balance      : 905.7
  equity       : 905.7
  margin       : 905.7
  free_margin  : 905.7
  margin_level : 100
  trade_allowed: true
test snapshot_demo ... ok
```

The `raw` field contains the full underlying JSON:
```rust
let account_id = snap.raw["account"]["accountId"].as_str();
let hedging    = snap.raw["preferences"]["hedgingMode"].as_bool();
```

---

### `account_preferences`

```rust
pub async fn account_preferences(&self) -> Result<Value>
```

Calls `GET /accounts/preferences`. Returns hedging mode and leverage limits per asset class.

```rust
let prefs = client.account().account_preferences().await?;

println!("{}", serde_json::to_string_pretty(&prefs)?);
```

**Actual test output:**
```json
{
  "hedgingMode": true,
  "leverages": {
    "BONDS":           { "current": 200, "max": 200, "min": 1 },
    "COMMODITIES":     { "current": 200, "max": 200, "min": 1 },
    "CURRENCIES":      { "current": 100, "max": 100, "min": 1 },
    "CRYPTOCURRENCIES":{ "current": 20,  "max": 20,  "min": 1 },
    "INDICES":         { "current": 100, "max": 100, "min": 1 },
    "SHARES":          { "current": 20,  "max": 20,  "min": 1 }
  }
}
```

| Asset class | Max leverage |
|---|---|
| CURRENCIES | 100 |
| COMMODITIES | 200 |
| INDICES | 100 |
| BONDS | 200 |
| SHARES | 20 |
| CRYPTOCURRENCIES | 20 |

---

### `activity_history`

```rust
pub async fn activity_history(&self, last_period_secs: Option<u64>) -> Result<Value>
```

Calls `GET /history/activity?lastPeriod={secs}`. Returns recent account events: deals opened/closed, order placements, modifications.

- `None` → defaults to `600` seconds (last 10 minutes)
- Maximum window is `86400` seconds (24 hours)

```rust
// Last 10 minutes (default)
let activity = client.account().activity_history(None).await?;

// Last hour
let activity = client.account().activity_history(Some(3600)).await?;

// Last 24 hours
let activity = client.account().activity_history(Some(86400)).await?;

let events = activity["activities"].as_array().unwrap_or(&vec![]);
for event in events {
    println!(
        "type={:?}  status={:?}  epic={:?}  date={:?}",
        event["type"], event["status"], event["epic"], event["date"]
    );
}
```

---

### `positions`

```rust
pub async fn positions(&self, symbol: Option<&str>) -> Result<Vec<Position>>
```

Calls `GET /positions`. Returns all open positions, optionally filtered to a single symbol.

```rust
// All open positions
let all = client.account().positions(None).await?;

// Only GOLD positions
let gold = client.account().positions(Some("GOLD")).await?;

for p in &all {
    println!(
        "id={}  symbol={}  side={}  size={}  open_price={}  upl={:?}  sl={:?}  tp={:?}",
        p.id, p.symbol, p.side, p.volume, p.open_price,
        p.unrealized_profit, p.stop_loss, p.take_profit
    );
}
```

When filtering by symbol, pass either the Capital.com epic (`"GOLD"`) or a common alias (`"XAUUSD"` is normalised to `"GOLD"` automatically). Returns an empty `Vec` if no matching positions exist — not an error.

---

### `position_by_id`

```rust
pub async fn position_by_id(&self, deal_id: &str) -> Result<Value>
```

Calls `GET /positions/{dealId}`. Returns the full JSON object for a single open position. Useful for verifying that stop-loss and take-profit levels were applied correctly after a modify.

```rust
let pos = client.account().position_by_id("DEAL-abc123").await?;
println!("stopLevel   = {:?}", pos["position"]["stopLevel"]);
println!("profitLevel = {:?}", pos["position"]["profitLevel"]);
```

---

### `pending_orders`

```rust
pub async fn pending_orders(&self, symbol: Option<&str>) -> Result<Vec<PendingOrder>>
```

Calls `GET /workingorders`. Returns all pending (unfilled) limit and stop orders, optionally filtered by symbol.

```rust
let orders = client.account().pending_orders(None).await?;
let gold   = client.account().pending_orders(Some("GOLD")).await?;

for o in &orders {
    println!(
        "id={}  symbol={}  side={}  type={}  level={:?}  sl={:?}  tp={:?}",
        o.id, o.symbol, o.side, o.order_type, o.price,
        o.stop_loss, o.take_profit
    );
}
```

---

### `closed_orders`

```rust
pub async fn closed_orders(&self, limit: usize) -> Result<Vec<ClosedOrder>>
```

Calls `GET /history/transactions?max={limit}`. Returns up to `limit` closed trade records from the transaction history.

```rust
let history = client.account().closed_orders(50).await?;

for o in &history {
    println!(
        "id={}  symbol={}  side={}  size={}  profit={:?}  closed={:?}",
        o.id, o.symbol, o.side, o.volume, o.profit, o.closed_at
    );
}
```

Returns an empty `Vec` if no history exists rather than erroring.

---

### `top_up_demo`

```rust
pub async fn top_up_demo(&self, amount: f64) -> Result<Value>
```

Calls `POST /accounts/topUp`. Adds funds to the demo account balance. Only valid on demo accounts. Capital.com allows up to 100 top-ups per account per day.

```rust
let result = client.account().top_up_demo(500.0).await?;
assert_eq!(result["successful"], true);
```

Pass a negative amount to subtract from the balance.

---

### `update_account_preferences`

```rust
pub async fn update_account_preferences(
    &self,
    leverages: Option<&serde_json::Value>,
    hedging_mode: Option<bool>,
) -> Result<Value>
```

Calls `PUT /accounts/preferences`. Updates leverage values and/or hedging mode. Pass `None` for parameters you want to leave unchanged.

```rust
use serde_json::json;

// Turn hedging on and set CURRENCIES leverage to 20
let result = client
    .account()
    .update_account_preferences(
        Some(&json!({ "CURRENCIES": 20 })),
        Some(true),
    )
    .await?;
// Returns { "status": "SUCCESS" }
assert_eq!(result["status"], "SUCCESS");
```

---

### `activity_history_range`

```rust
pub async fn activity_history_range(
    &self,
    from: Option<&str>,
    to: Option<&str>,
    detailed: bool,
) -> Result<Value>
```

Calls `GET /history/activity` with absolute date range parameters. `from` / `to` are ISO-8601 strings (`"YYYY-MM-DDTHH:MM:SS"`). The API caps the window at 24 hours.

```rust
let result = client
    .account()
    .activity_history_range(
        Some("2026-04-09T00:00:00"),
        Some("2026-04-10T00:00:00"),
        false,
    )
    .await?;

let activities = result["activities"].as_array().unwrap();
println!("{} activity events", activities.len());
```

Set `detailed = true` to receive extra context for each event.

---

### `closed_orders_range`

```rust
pub async fn closed_orders_range(
    &self,
    from: Option<&str>,
    to: Option<&str>,
    transaction_type: Option<&str>,
) -> Result<Vec<ClosedOrder>>
```

Calls `GET /history/transactions` with date-range and type filters instead of a count limit. `transaction_type` values: `TRADE`, `SWAP`, `DEPOSIT`, `WITHDRAWAL`.

```rust
let orders = client
    .account()
    .closed_orders_range(
        Some("2026-04-01T00:00:00"),
        Some("2026-04-10T00:00:00"),
        Some("TRADE"),
    )
    .await?;

for o in &orders {
    println!("{} {} {}", o.symbol, o.side, o.profit.unwrap_or(0.0));
}
```

---

## Data API

Access via `client.data()`.

---

### `current_price`

```rust
pub async fn current_price(&self, symbol: &str) -> Result<PriceQuote>
```

Calls `GET /markets/{epic}` and extracts bid/ask from the `snapshot` section. Returns a `PriceQuote`.

```rust
let quote = client.data().current_price("GOLD").await?;

println!("symbol = {}", quote.symbol);       // "GOLD"
println!("bid    = {}", quote.bid);          // e.g. 4757.36
println!("ask    = {}", quote.ask);          // e.g. 4757.86
println!("mid    = {:?}", quote.mid);        // Some(4757.61)
println!("time   = {:?}", quote.time);       // Some("2026-04-10T15:04:22")
println!("spread = {:.5}", quote.ask - quote.bid); // 0.50
```

**Actual test output (GOLD, April 2026):**
```
══ Live Quote: GOLD ══
  symbol = GOLD
  bid    = 4757.36
  ask    = 4757.86
  mid    = Some(4757.61)
  spread = 0.50000
test live_quote_gold ... ok
```

The `raw` field is the full `/markets/{epic}` JSON, which includes the `instrument`, `dealingRules`, and `snapshot` sections (see `market_details` below for the full shape).

Symbol aliases are resolved automatically — pass `"XAUUSD"`, `"GOLD"`, or any string that Capital.com recognises. If the epic is not directly found, a search is performed and the best match is used.

---

### `market_details`

```rust
pub async fn market_details(&self, symbol: &str) -> Result<Value>
```

Calls `GET /markets/{epic}`. Returns the full market JSON with three top-level sections.

```rust
let details = client.data().market_details("GOLD").await?;

// Instrument info
let instrument  = &details["instrument"];
let name        = instrument["name"].as_str();
let market_type = instrument["type"].as_str();         // "CURRENCIES", "COMMODITIES", etc.
let currency    = instrument["currency"].as_str();
let margin_pct  = instrument["marginFactor"].as_f64(); // margin rate
let lot_size    = instrument["lotSize"].as_f64();

// Dealing rules
let rules        = &details["dealingRules"];
let min_size     = rules["minDealSize"]["value"].as_f64();
let max_size     = rules["maxDealSize"]["value"].as_f64();
let min_sl_dist  = rules["minStopOrProfitDistance"]["value"].as_f64();

// Live snapshot
let snap         = &details["snapshot"];
let bid          = snap["bid"].as_f64();
let ask          = snap["offer"].as_f64();
let status       = snap["marketStatus"].as_str(); // "TRADEABLE", "CLOSED"
let high_today   = snap["high"].as_f64();
let low_today    = snap["low"].as_f64();
let change_pct   = snap["percentageChange"].as_f64();
```

---

### `historical_ohlc`

```rust
pub async fn historical_ohlc(
    &self,
    symbol: &str,
    timeframe: &str,
    count: usize,
) -> Result<Vec<Candle>>
```

Calls `GET /prices/{epic}?resolution={resolution}&max={count}`. Returns up to `count` candles in ascending time order.

**Timeframe strings:**

| Pass | API resolution | Bar size |
|---|---|---|
| `"1m"` | `MINUTE` | 1 minute |
| `"5m"` | `MINUTE_5` | 5 minutes |
| `"15m"` | `MINUTE_15` | 15 minutes |
| `"30m"` | `MINUTE_30` | 30 minutes |
| `"1h"` | `HOUR` | 1 hour |
| `"4h"` | `HOUR_4` | 4 hours |
| `"1d"` | `DAY` | 1 day |
| `"1w"` | `WEEK` | 1 week |

```rust
// Last 10 one-minute bars of GOLD
let candles = client.data().historical_ohlc("GOLD", "1m", 10).await?;

// Last 24 hourly bars of EURUSD
let candles = client.data().historical_ohlc("EURUSD", "1h", 24).await?;

// Last 30 daily bars of BTCUSD
let candles = client.data().historical_ohlc("BTCUSD", "1d", 30).await?;

for c in &candles {
    println!(
        "time={}  O={:.5}  H={:.5}  L={:.5}  C={:.5}  V={}",
        c.time, c.open, c.high, c.low, c.close, c.volume
    );
}
```

OHLC values are taken from the **bid side** of each price object in the API response. The `raw` field contains the original price entry with the full `openPrice { bid, ask }`, `highPrice`, `lowPrice`, `closePrice`, and `lastTradedVolume` fields.

**Invariants guaranteed by the API:**

```
c.high >= c.open && c.high >= c.close
c.low  <= c.open && c.low  <= c.close
```

---

### `search_markets`

```rust
pub async fn search_markets(&self, query: &str) -> Result<Value>
```

Calls `GET /markets?searchTerm={query}`. Free-text search across all market epics and names. Returns a `markets` array.

```rust
let results = client.data().search_markets("gold").await?;

let markets = results["markets"].as_array().unwrap_or(&vec![]);
println!("{} markets matched 'gold'", markets.len());

for m in markets.iter().take(5) {
    println!(
        "  epic={:?}  name={:?}  type={:?}",
        m["epic"], m["instrumentName"], m["instrumentType"]
    );
}
```

---

### `markets_by_epics`

```rust
pub async fn markets_by_epics(&self, epics: &[&str]) -> Result<Value>
```

Calls `GET /markets?epics=A,B,C`. Fetches full market details for up to 50 known epics in a single HTTP request. More efficient than calling `market_details` in a loop.

```rust
let result = client.data().markets_by_epics(&["GOLD", "SILVER", "EURUSD"]).await?;

let markets = result["markets"].as_array().unwrap_or(&vec![]);
for m in markets {
    println!("epic={:?}  bid={:?}", m["epic"], m["snapshot"]["bid"]);
}
```

---

### `market_navigation`

```rust
pub async fn market_navigation(&self) -> Result<Value>
```

Calls `GET /marketnavigation`. Returns the top-level category tree: Currencies, Commodities, Indices, Shares, Cryptocurrencies, etc. Each entry has an `id` and `name`.

```rust
let nav = client.data().market_navigation().await?;

let nodes = nav["nodes"].as_array().unwrap_or(&vec![]);
for node in nodes {
    println!("id={:?}  name={:?}", node["id"], node["name"]);
}
```

Use the returned `id` values with `market_navigation_node` to drill down.

---

### `market_navigation_node`

```rust
pub async fn market_navigation_node(&self, node_id: &str) -> Result<Value>
```

Calls `GET /marketnavigation/{nodeId}?limit=500`. Returns the sub-nodes or markets inside a category node.

```rust
let sub = client.data().market_navigation_node("hierarchy_v1.currencies").await?;

// A node can contain either sub-nodes or markets (sometimes both)
if let Some(sub_nodes) = sub["nodes"].as_array() {
    for n in sub_nodes {
        println!("sub-node: {:?}", n["name"]);
    }
}
if let Some(markets) = sub["markets"].as_array() {
    for m in markets {
        println!("market: epic={:?}  name={:?}", m["epic"], m["instrumentName"]);
    }
}
```

---

### `client_sentiment`

```rust
pub async fn client_sentiment(&self, market_id: &str) -> Result<Value>
```

Calls `GET /clientsentiment/{marketId}`. Returns the percentage of Capital.com clients currently holding long vs short positions in that market.

```rust
let sentiment = client.data().client_sentiment("GOLD").await?;

let long_pct  = sentiment["longPositionPercentage"].as_f64().unwrap_or(0.0);
let short_pct = sentiment["shortPositionPercentage"].as_f64().unwrap_or(0.0);

println!("GOLD  long={:.2}%  short={:.2}%", long_pct, short_pct);
```

---

### `client_sentiment_batch`

```rust
pub async fn client_sentiment_batch(&self, market_ids: &[&str]) -> Result<Value>
```

Calls `GET /clientsentiment?marketIds=A,B,C`. Returns sentiment for multiple markets in a single request.

```rust
let batch = client.data().client_sentiment_batch(&["GOLD", "SILVER", "EURUSD"]).await?;

let items = batch["clientSentiments"].as_array().unwrap_or(&vec![]);
for item in items {
    println!(
        "  market={:?}  long={:?}%  short={:?}%",
        item["marketId"],
        item["longPositionPercentage"],
        item["shortPositionPercentage"]
    );
}
```

---

### `watchlists`

```rust
pub async fn watchlists(&self) -> Result<Value>
```

Calls `GET /watchlists`. Returns all watchlists belonging to the current account, each with an `id`, `name`, and `editable` flag.

```rust
let result = client.data().watchlists().await?;

let lists = result["watchlists"].as_array().unwrap_or(&vec![]);
for wl in lists {
    println!("id={:?}  name={:?}  editable={:?}", wl["id"], wl["name"], wl["editable"]);
}
```

---

### `watchlist`

```rust
pub async fn watchlist(&self, watchlist_id: &str) -> Result<Value>
```

Calls `GET /watchlists/{watchlistId}`. Returns the markets inside a specific watchlist.

```rust
let wl = client.data().watchlist("Popular Markets").await?;

let markets = wl["markets"].as_array().unwrap_or(&vec![]);
for m in markets {
    println!("epic={:?}  bid={:?}", m["epic"], m["snapshot"]["bid"]);
}
```

---

### `create_watchlist`

```rust
pub async fn create_watchlist(&self, name: &str, epics: &[&str]) -> Result<Value>
```

Calls `POST /watchlists`. Creates a new watchlist with an optional initial set of market epics.

```rust
let result = client
    .data()
    .create_watchlist("MyMetals", &["GOLD", "SILVER"])
    .await?;

let watchlist_id = result["watchlistId"].as_str().unwrap();
println!("created watchlist id = {watchlist_id}");
```

---

### `add_to_watchlist`

```rust
pub async fn add_to_watchlist(&self, watchlist_id: &str, epic: &str) -> Result<Value>
```

Calls `PUT /watchlists/{watchlistId}`. Adds a single market epic to an existing watchlist.

```rust
let result = client.data().add_to_watchlist("124622675772425", "PLATINUM").await?;
assert_eq!(result["status"], "SUCCESS");
```

---

### `delete_watchlist`

```rust
pub async fn delete_watchlist(&self, watchlist_id: &str) -> Result<Value>
```

Calls `DELETE /watchlists/{watchlistId}`. Permanently deletes a watchlist.

```rust
let result = client.data().delete_watchlist("124622675772425").await?;
assert_eq!(result["status"], "SUCCESS");
```

---

### `remove_from_watchlist`

```rust
pub async fn remove_from_watchlist(&self, watchlist_id: &str, epic: &str) -> Result<Value>
```

Calls `DELETE /watchlists/{watchlistId}/{epic}`. Removes a single market from a watchlist without deleting the watchlist itself.

```rust
let result = client
    .data()
    .remove_from_watchlist("124622675772425", "SILVER")
    .await?;
assert_eq!(result["status"], "SUCCESS");
```

---

## Execute API

Access via `client.execute()`.

All execution methods return `ExecutionResult`. After any create call, the `id` field contains a **dealReference** (temporary identifier prefixed with `o_`). Use `confirm_deal` to resolve it to the permanent **dealId** required for modify and close calls.

```rust
let result = client.execute().market_buy("GOLD", 1.0, None, None).await?;
// result.id might be "o_abc123def" — a dealReference, not yet a dealId

let confirm = client.execute().confirm_deal(result.id.as_deref().unwrap()).await?;
let deal_id = confirm["affectedDeals"][0]["dealId"].as_str().unwrap();
// deal_id is now "DEAL-abc123" — permanent, use this for modify/close
```

---

### `market_buy` / `market_sell`

```rust
pub async fn market_buy(
    &self,
    symbol: &str,
    size: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult>

pub async fn market_sell(
    &self,
    symbol: &str,
    size: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult>
```

Posts `POST /positions` with `direction: "BUY"` or `"SELL"`. The size is clamped to the market's minimum deal size automatically.

```rust
// Simple market buy, no stops
let r = client.execute().market_buy("GOLD", 1.0, None, None).await?;
assert!(r.success);

// Market sell SILVER with stop-loss and take-profit
let quote = client.data().current_price("SILVER").await?;
let sl = (quote.bid * 1.005 * 100.0).round() / 100.0;  // 0.5% above bid
let tp = (quote.bid * 0.990 * 100.0).round() / 100.0;  // 1% below bid
let r = client.execute().market_sell("SILVER", 1.0, Some(sl), Some(tp)).await?;
println!("success = {}  id = {:?}", r.success, r.id);
```

`stop_loss` and `take_profit` are broker price levels, not distances. Pass `None` to omit them.

---

### `buy_limit` / `sell_limit`

```rust
pub async fn buy_limit(
    &self,
    symbol: &str,
    size: f64,
    level: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult>

pub async fn sell_limit(
    &self,
    symbol: &str,
    size: f64,
    level: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult>
```

Posts `POST /workingorders` with `type: "LIMIT"`. A buy limit is placed **below** the current price; a sell limit is placed **above** it.

```rust
let quote = client.data().current_price("GOLD").await?;

// Buy limit 2% below current bid — will not fill immediately
let level = (quote.bid * 0.98).round();
let r = client.execute().buy_limit("GOLD", 1.0, level, None, None).await?;
assert!(r.success);

let order_id = r.id.unwrap();
// Cancel to clean up
client.execute().cancel_order(&order_id).await?;

// Sell limit with SL/TP
let entry = (quote.ask * 1.02).round();
let sl    = (quote.ask * 1.03).round();
let tp    = (quote.ask * 1.00).round();
let r = client.execute().sell_limit("GOLD", 1.0, entry, Some(sl), Some(tp)).await?;
```

---

### `buy_stop` / `sell_stop`

```rust
pub async fn buy_stop(
    &self,
    symbol: &str,
    size: f64,
    level: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult>

pub async fn sell_stop(
    &self,
    symbol: &str,
    size: f64,
    level: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult>
```

Posts `POST /workingorders` with `type: "STOP"`. A buy stop triggers **above** the current price (breakout entry); a sell stop triggers **below** it.

```rust
let quote = client.data().current_price("GOLD").await?;

// Buy stop 2% above current ask — triggers on breakout
let level = (quote.ask * 1.02).round();
let r = client.execute().buy_stop("GOLD", 1.0, level, None, None).await?;
assert!(r.success);
client.execute().cancel_order(r.id.as_deref().unwrap()).await?;

// Sell stop with SL/TP on SILVER
let quote = client.data().current_price("SILVER").await?;
let entry = (quote.bid * 0.97 * 100.0).round() / 100.0;
let sl    = (quote.bid * 1.005 * 100.0).round() / 100.0;
let tp    = (quote.bid * 0.94 * 100.0).round() / 100.0;
let r = client.execute().sell_stop("SILVER", 1.0, entry, Some(sl), Some(tp)).await?;
```

---

### `buy_limit_gtd` / `sell_limit_gtd` / `buy_stop_gtd` / `sell_stop_gtd`

```rust
pub async fn buy_limit_gtd(
    &self,
    symbol: &str,
    size: f64,
    level: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
    good_till_date: &str,
) -> Result<ExecutionResult>

// sell_limit_gtd / buy_stop_gtd / sell_stop_gtd have identical signatures
```

Good-Till-Date variants of all four working order types. The order automatically expires at `good_till_date` if not filled or cancelled. `good_till_date` format: `"YYYY-MM-DDTHH:MM:SS"` (UTC).

```rust
let quote = client.data().current_price("GOLD").await?;

// BUY LIMIT 3% below market, expires in 3 days
let level = (quote.bid * 0.97).round();
let gtd   = "2026-04-13T23:59:59";

let r = client
    .execute()
    .buy_limit_gtd("GOLD", 1.0, level, None, None, gtd)
    .await?;
assert!(r.success, "GTD order rejected: {:?}", r.message);

// Clean up
client.execute().cancel_order(r.id.as_deref().unwrap()).await?;
```

These are identical to the non-GTD equivalents except that the `goodTillDate` field is added to the request body. Orders without a GTD run indefinitely (GTC — good till cancelled).

---

### `modify_position`

```rust
pub async fn modify_position(
    &self,
    ticket_or_reference: &str,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult>
```

Calls `PUT /positions/{dealId}`. Updates the stop-loss and/or take-profit on an open position. Pass `None` for a level you do not want to change.

```rust
// Open a position first
let open = client.execute().market_buy("GOLD", 1.0, None, None).await?;
let deal_id = /* resolve via confirm_deal */ ...;

// Update both SL and TP
let quote = client.data().current_price("GOLD").await?;
let new_sl = (quote.ask * 0.994).round();
let new_tp = (quote.ask * 1.015).round();
let r = client.execute().modify_position(&deal_id, Some(new_sl), Some(new_tp)).await?;
println!("modify success = {}", r.success);

// Update only SL, leave TP unchanged
let r = client.execute().modify_position(&deal_id, Some(new_sl), None).await?;
```

---

### `close_position_full`

```rust
pub async fn close_position_full(&self, ticket_or_reference: &str) -> Result<ExecutionResult>
```

Calls `DELETE /positions/{dealId}`. Closes the entire position at the current market price.

```rust
let close = client.execute().close_position_full(&deal_id).await?;
assert!(close.success, "close failed: {:?}", close.message);
```

After a successful close the position will no longer appear in `account().positions()`.

---

### `modify_order`

```rust
pub async fn modify_order(
    &self,
    ticket_or_reference: &str,
    level: f64,
    stop_loss: Option<f64>,
    take_profit: Option<f64>,
) -> Result<ExecutionResult>
```

Calls `PUT /workingorders/{dealId}`. Changes the trigger price and optionally the SL/TP on a pending (unfilled) working order.

```rust
// Place a limit, then move its level
let place = client.execute().buy_limit("GOLD", 1.0, initial_level, None, None).await?;
let order_id = place.id.unwrap();

let modified_level = (quote.bid * 0.96).round();
let r = client.execute().modify_order(&order_id, modified_level, None, None).await?;
println!("modify success = {}", r.success);

client.execute().cancel_order(&order_id).await?;
```

---

### `cancel_order`

```rust
pub async fn cancel_order(&self, ticket_or_reference: &str) -> Result<ExecutionResult>
```

Calls `DELETE /workingorders/{dealId}`. Cancels a pending working order. Has no effect on filled (open) positions.

```rust
let r = client.execute().cancel_order(&order_id).await?;
assert!(r.success);
```

---

### `confirm_deal`

```rust
pub async fn confirm_deal(&self, deal_reference: &str) -> Result<Value>
```

Calls `GET /confirms/{dealReference}`. Resolves a `dealReference` (the temporary `o_` identifier returned by create calls) into the final deal state, including the permanent `dealId` needed for modify and close operations.

```rust
let open = client.execute().market_buy("GOLD", 1.0, None, None).await?;
let deal_ref = open.id.as_deref().unwrap(); // "o_abc123..."

// Wait briefly for broker processing
tokio::time::sleep(std::time::Duration::from_millis(800)).await;

let confirm = client.execute().confirm_deal(deal_ref).await?;

println!("dealStatus  = {:?}", confirm["dealStatus"]);  // "ACCEPTED"
println!("level       = {:?}", confirm["level"]);        // fill price
println!("affectedDeals = {:?}", confirm["affectedDeals"]);

// Extract permanent dealId for further calls
let deal_id = confirm["affectedDeals"][0]["dealId"].as_str().unwrap();
let close = client.execute().close_position_full(deal_id).await?;
```

---

## Session Management

Sessions are created automatically on first use. You can also create one explicitly to inspect the session payload:

```rust
let payload: serde_json::Value = client.create_session().await?;

println!("currentAccountId = {:?}", payload["currentAccountId"]);
println!("accounts         = {:?}", payload["accounts"]);
println!("timezoneOffset   = {:?}", payload["timezoneOffset"]);
println!("hasActiveDemoAccounts = {:?}", payload["hasActiveDemoAccounts"]);
```

**Actual session payload (demo, April 2026):**
```json
{
  "currentAccountId": "306911353591116062",
  "lightstreamerEndpoint": "https://...",
  "accounts": [
    {
      "accountId": "306911353591116062",
      "accountName": "Demo",
      "preferred": true,
      "accountType": "CFD"
    }
  ],
  "clientId": "...",
  "timezone": 0,
  "hasActiveDemoAccounts": true,
  "hasActiveLiveAccounts": false,
  "trailingStopsEnabled": false,
  "dealingEnabled": true
}
```

If a request returns HTTP 401 (session expired), the client automatically calls `POST /session` once and retries the original request. No user action required.

### Additional client-level methods

Beyond `create_session`, the following methods are available directly on `CapitalClient`:

#### `server_time`

```rust
pub async fn server_time(&self) -> Result<Value>
```

`GET /time` — returns the current server timestamp. Does **not** require authentication.

```rust
let t = client.server_time().await?;
println!("serverTime = {}", t["serverTime"]);  // epoch milliseconds
```

#### `ping`

```rust
pub async fn ping(&self) -> Result<Value>
```

`GET /ping` — keeps the current session alive and verifies connectivity. Returns `{ "status": "OK" }`.

```rust
let p = client.ping().await?;
assert_eq!(p["status"], "OK");
```

#### `session_details`

```rust
pub async fn session_details(&self) -> Result<Value>
```

`GET /session` — returns details for the currently active session: clientId, accountId, locale, currency, streamEndpoint, timezoneOffset.

```rust
let info = client.session_details().await?;
println!("accountId = {:?}", info["accountId"]);
println!("currency  = {:?}", info["currency"]);
println!("stream    = {:?}", info["streamEndpoint"]);
```

#### `switch_account`

```rust
pub async fn switch_account(&self, account_id: &str) -> Result<Value>
```

`PUT /session` — switches the active financial account. Subsequent trades will use the given `accountId`.

```rust
let result = client.switch_account("987654321098765432").await?;
// Capital.com may issue new session tokens after switching;
// call create_session() again if subsequent requests return 401.
```

#### `logout`

```rust
pub async fn logout(&self) -> Result<Value>
```

`DELETE /session` — invalidates the current session tokens. The cached session is cleared; the next API call will automatically create a new session.

```rust
let result = client.logout().await?;
// Subsequent calls will authenticate automatically via create_session()
```

---

## Running the Test Suites

Integration tests live in `testsuites/capital/`. All tests hit the live Capital.com demo API and require valid `.env` credentials.

> **Rate limit note:** Capital.com limits session creation to a few per second. When running many tests together, use `--test-threads=1` to prevent HTTP 429 errors from concurrent session creation.

### Run all tests for a suite

```bash
# Account tests (21 tests)
cargo test --test capital_account -- --nocapture --test-threads=1

# Data tests (26 tests)
cargo test --test capital_data -- --nocapture

# Execute tests (21 tests)
cargo test --test capital_execute -- --nocapture --test-threads=1
```

### Run a single named test

```bash
cargo test --test capital_account -- snapshot_demo --nocapture
cargo test --test capital_data   -- live_quote_gold --nocapture
cargo test --test capital_execute -- market_buy_gold --nocapture
```

### Account test list

| Test name | What it covers |
|---|---|
| `session_create_demo` | Full session payload, currentAccountId present |
| `session_create_live` | Live session creation |
| `config_demo_url` | Demo base URL contains "demo", demo flag true |
| `config_live_url` | Live base URL does NOT contain "demo" |
| `snapshot_demo` | All AccountSnapshot fields, non-negative balance/margin |
| `snapshot_live` | Live account snapshot |
| `account_preferences_demo` | hedgingMode present, full leverage table |
| `activity_history_last_hour` | Activity events, last 3600s |
| `activity_history_default` | Default 600s window |
| `positions_all_demo` | All open positions (may be empty) |
| `positions_filtered_by_symbol` | GOLD-only filter |
| `pending_orders_all_demo` | All pending working orders |
| `closed_orders_history_demo` | Up to 50 closed transaction records |
| `closed_orders_limit_one` | Limit=1 respects cap |
| `top_up_demo_account` | +$500 top-up, successful=true asserted |
| `ping_session` | GET /ping → status=OK |
| `server_time_demo` | GET /time → serverTime field (no auth required) |
| `session_details_demo` | GET /session → clientId/accountId present |
| `update_account_preferences_demo` | PUT /accounts/preferences round-trip (hedgingMode unchanged) |
| `activity_history_range_demo` | GET /history/activity with 24h from/to range |
| `closed_orders_range_demo` | GET /history/transactions with date range + TRADE type filter |

### Data test list

| Test name | What it covers |
|---|---|
| `search_markets_gold` | Free-text search, non-empty result |
| `search_markets_silver` | Free-text search |
| `search_markets_bitcoin` | Free-text search |
| `markets_by_epics_batch` | GOLD + SILVER batch fetch |
| `market_details_gold` | instrument / dealingRules / snapshot sections |
| `market_details_eurusd` | Instrument + snapshot sections |
| `market_details_btcusd` | Instrument section |
| `live_quote_gold` | bid/ask/mid/spread, bid < ask |
| `live_quote_eurusd` | bid < ask |
| `live_quote_btcusd` | bid positive |
| `live_quote_silver` | ask >= bid |
| `historical_ohlc_1m_gold` | 1m OHLC, high>=open/close, low<=open/close |
| `historical_ohlc_5m_eurusd` | 5m OHLC |
| `historical_ohlc_1h_btcusd` | 1h OHLC |
| `historical_ohlc_4h_gold` | 4h OHLC |
| `historical_ohlc_1d_silver` | Daily OHLC |
| `historical_ohlc_1w_gold` | Weekly OHLC |
| `historical_ohlc_raw_fields` | raw.openPrice / snapshotTime present |
| `market_navigation_top_level` | Non-empty nodes array |
| `market_navigation_first_node` | Sub-nodes or markets present in first node |
| `client_sentiment_gold` | long%+short%>0 |
| `client_sentiment_batch` | GOLD + SILVER batch sentiment |
| `watchlists_all` | Watchlists response |
| `watchlist_drill_first` | Markets inside first watchlist |
| `historical_ohlc_range_gold` | GET /prices with from/to date range, 10+ 1h candles |
| `watchlist_full_lifecycle` | create → add SILVER → list → remove SILVER → delete |

### Execute test list

| Test name | What it covers |
|---|---|
| `confirm_deal_roundtrip` | Open → confirm → dealStatus present → close |
| `market_buy_gold` | Market BUY, no SL/TP, clean close |
| `market_sell_gold` | Market SELL, no SL/TP, clean close |
| `market_buy_with_sl_tp` | Market BUY with realistic SL/TP levels |
| `market_sell_with_sl_tp` | Market SELL SILVER with SL/TP |
| `modify_position_sl_tp` | Open → modify both SL and TP → close |
| `modify_position_sl_only` | Modify SL only (TP=None) |
| `close_position_full_cycle` | Open → close → verify not in positions list |
| `buy_limit_order` | BUY LIMIT below market → cancel |
| `sell_limit_order` | SELL LIMIT above market → cancel |
| `buy_limit_order_with_sl_tp` | BUY LIMIT SILVER with SL/TP → cancel |
| `buy_stop_order` | BUY STOP above market → cancel |
| `sell_stop_order` | SELL STOP below market → cancel |
| `sell_stop_order_with_sl_tp` | SELL STOP SILVER with SL/TP → cancel |
| `modify_order_level` | Place limit → change level → cancel |
| `modify_order_sl_tp` | Place limit → add SL/TP → cancel |
| `cancel_order_immediately` | Place limit → cancel in same test |
| `all_four_working_order_types` | BUY LIMIT, SELL LIMIT, BUY STOP, SELL STOP in one pass |
| `multi_symbol_positions` | BUY GOLD + BUY SILVER concurrently → verify 2 positions → close both |
| `buy_limit_gtd_order` | BUY LIMIT GTD 3 days out → confirm success → cancel |
| `sell_stop_gtd_order` | SELL STOP GTD 3 days out → confirm success → cancel |
