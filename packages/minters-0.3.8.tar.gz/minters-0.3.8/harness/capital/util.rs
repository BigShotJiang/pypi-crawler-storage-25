use chrono::Utc;
use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AccountSnapshot {
    pub login: String,
    pub server: String,
    pub broker: String,
    pub currency: String,
    pub leverage: f64,
    pub balance: f64,
    pub equity: f64,
    pub margin: f64,
    pub free_margin: f64,
    pub margin_level: f64,
    pub trade_allowed: bool,
    pub timestamp: String,
    pub raw: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PriceQuote {
    pub symbol: String,
    pub bid: f64,
    pub ask: f64,
    pub mid: Option<f64>,
    pub time: Option<String>,
    pub raw: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Candle {
    pub time: String,
    pub open: f64,
    pub high: f64,
    pub low: f64,
    pub close: f64,
    pub volume: f64,
    pub raw: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Position {
    pub id: String,
    pub symbol: String,
    pub side: String,
    pub volume: f64,
    pub open_price: f64,
    pub current_price: Option<f64>,
    pub unrealized_profit: Option<f64>,
    pub stop_loss: Option<f64>,
    pub take_profit: Option<f64>,
    pub opened_at: Option<String>,
    pub updated_at: Option<String>,
    pub raw: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PendingOrder {
    pub id: String,
    pub symbol: String,
    pub side: String,
    pub order_type: String,
    pub status: String,
    pub volume: f64,
    pub price: Option<f64>,
    pub current_price: Option<f64>,
    pub stop_loss: Option<f64>,
    pub take_profit: Option<f64>,
    pub created_at: Option<String>,
    pub raw: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClosedOrder {
    pub id: String,
    pub symbol: String,
    pub side: String,
    pub status: String,
    pub volume: f64,
    pub open_price: Option<f64>,
    pub close_price: Option<f64>,
    pub profit: Option<f64>,
    pub commission: Option<f64>,
    pub swap: Option<f64>,
    pub opened_at: Option<String>,
    pub closed_at: Option<String>,
    pub raw: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionResult {
    pub success: bool,
    pub id: Option<String>,
    pub status: Option<String>,
    pub message: Option<String>,
    pub raw: Value,
}

pub fn first_field_string(value: &Value, paths: &[&[&str]]) -> Option<String> {
    for path in paths {
        let mut current = value;
        let mut found = true;
        for key in *path {
            if let Some(next) = current.get(*key) {
                current = next;
            } else {
                found = false;
                break;
            }
        }
        if !found {
            continue;
        }
        if let Some(text) = current.as_str() {
            return Some(text.to_string());
        }
        if !current.is_null() {
            return Some(current.to_string());
        }
    }
    None
}

pub fn first_field_f64(value: &Value, paths: &[&[&str]]) -> Option<f64> {
    for path in paths {
        let mut current = value;
        let mut found = true;
        for key in *path {
            if let Some(next) = current.get(*key) {
                current = next;
            } else {
                found = false;
                break;
            }
        }
        if !found {
            continue;
        }
        if let Some(n) = current.as_f64() {
            return Some(n);
        }
        if let Some(text) = current.as_str() {
            if let Ok(parsed) = text.parse::<f64>() {
                return Some(parsed);
            }
        }
    }
    None
}

pub fn now_iso() -> String {
    Utc::now().to_rfc3339()
}
