use std::sync::Arc;

use anyhow::{Context, Result, anyhow};
use reqwest::{Client, Method, StatusCode};
use serde_json::{Value, json};
use tokio::sync::Mutex;

use super::{config::CapitalConfig, session::SessionState};
use crate::{account::CapitalAccountApi, data::CapitalDataApi, execute::CapitalExecuteApi};

#[derive(Clone)]
pub struct CapitalClient {
    inner: Arc<Inner>,
}

struct Inner {
    http: Client,
    config: CapitalConfig,
    session: Mutex<Option<SessionState>>,
}

impl CapitalClient {
    pub fn new(config: CapitalConfig) -> Self {
        Self {
            inner: Arc::new(Inner {
                http: Client::new(),
                config,
                session: Mutex::new(None),
            }),
        }
    }

    pub fn from_env(demo_override: Option<bool>) -> Result<Self> {
        Ok(Self::new(CapitalConfig::from_env(demo_override)?))
    }

    pub fn config(&self) -> &CapitalConfig {
        &self.inner.config
    }

    pub fn account(&self) -> CapitalAccountApi {
        CapitalAccountApi::new(self.clone())
    }

    pub fn data(&self) -> CapitalDataApi {
        CapitalDataApi::new(self.clone())
    }

    pub fn execute(&self) -> CapitalExecuteApi {
        CapitalExecuteApi::new(self.clone())
    }

    pub async fn create_session(&self) -> Result<Value> {
        let url = format!("{}/api/v1/session", self.inner.config.base_url);
        let response = self
            .inner
            .http
            .post(&url)
            .header("X-CAP-API-KEY", &self.inner.config.api_key)
            .json(&json!({
                "identifier": self.inner.config.identifier,
                "password": self.inner.config.password,
            }))
            .send()
            .await
            .with_context(|| format!("capital session request failed for {url}"))?
            .error_for_status()
            .with_context(|| format!("capital session request returned error status for {url}"))?;

        let headers = response.headers().clone();
        let payload: Value = response
            .json()
            .await
            .context("capital session response was not valid json")?;

        let cst = headers
            .get("CST")
            .and_then(|value| value.to_str().ok())
            .map(ToOwned::to_owned)
            .ok_or_else(|| anyhow!("capital session response did not include CST header"))?;
        let security_token = headers
            .get("X-SECURITY-TOKEN")
            .and_then(|value| value.to_str().ok())
            .map(ToOwned::to_owned)
            .ok_or_else(|| anyhow!("capital session response did not include X-SECURITY-TOKEN header"))?;
        let current_account_id = payload
            .get("currentAccountId")
            .and_then(Value::as_str)
            .map(ToOwned::to_owned);

        let mut session = self.inner.session.lock().await;
        *session = Some(SessionState {
            cst,
            security_token,
            current_account_id,
        });

        Ok(payload)
    }

    pub(crate) async fn ensure_session(&self) -> Result<SessionState> {
        if let Some(existing) = self.inner.session.lock().await.clone() {
            return Ok(existing);
        }

        self.create_session().await?;
        self.inner
            .session
            .lock()
            .await
            .clone()
            .ok_or_else(|| anyhow!("capital session was not initialized"))
    }

    pub(crate) async fn request_value(
        &self,
        method: Method,
        endpoint: &str,
        body: Option<Value>,
        query: Option<&[(String, String)]>,
    ) -> Result<Value> {
        self.request_value_inner(method, endpoint, body, query, true).await
    }

    async fn request_value_inner(
        &self,
        method: Method,
        endpoint: &str,
        body: Option<Value>,
        query: Option<&[(String, String)]>,
        allow_refresh: bool,
    ) -> Result<Value> {
        let session = self.ensure_session().await?;
        let url = format!("{}/api/v1{}", self.inner.config.base_url, endpoint);

        let mut request = self
            .inner
            .http
            .request(method.clone(), &url)
            .header("X-CAP-API-KEY", &self.inner.config.api_key)
            .header("CST", &session.cst)
            .header("X-SECURITY-TOKEN", &session.security_token);

        if let Some(query) = query {
            request = request.query(query);
        }

        if let Some(ref payload) = body {
            request = request.json(payload);
        }

        let response = request
            .send()
            .await
            .with_context(|| format!("capital request failed for {method} {url}"))?;

        if response.status() == StatusCode::UNAUTHORIZED && allow_refresh {
            self.create_session().await?;
            return Box::pin(self.request_value_inner(method, endpoint, body, query, false)).await;
        }

        let response = response
            .error_for_status()
            .with_context(|| format!("capital request returned error status for {method} {url}"))?;

        response
            .json::<Value>()
            .await
            .with_context(|| format!("capital response was not valid json for {method} {url}"))
    }

    pub(crate) async fn accounts_response(&self) -> Result<Value> {
        self.request_value(Method::GET, "/accounts", None, None).await
    }

    pub(crate) async fn resolve_epic(&self, symbol: &str) -> Result<String> {
        let alias = match symbol.trim().to_ascii_uppercase().as_str() {
            "XAUUSD" => "GOLD".to_string(),
            _ => symbol.trim().to_string(),
        };

        if self
            .request_value(Method::GET, &format!("/markets/{alias}"), None, None)
            .await
            .is_ok()
        {
            return Ok(alias);
        }

        let response = self
            .request_value(
                Method::GET,
                "/markets",
                None,
                Some(&[("searchTerm".to_string(), symbol.trim().to_string())]),
            )
            .await?;

        let markets = response
            .get("markets")
            .and_then(Value::as_array)
            .cloned()
            .unwrap_or_default();

        let exact = markets.iter().find(|market| {
            market
                .get("epic")
                .and_then(Value::as_str)
                .map(|epic| epic.eq_ignore_ascii_case(symbol))
                .unwrap_or(false)
        });

        exact
            .or_else(|| markets.first())
            .and_then(|market| market.get("epic").and_then(Value::as_str))
            .map(ToOwned::to_owned)
            .ok_or_else(|| anyhow!("capital could not resolve epic for symbol {symbol}"))
    }

    pub(crate) async fn market_details(&self, epic: &str) -> Result<Value> {
        self.request_value(Method::GET, &format!("/markets/{epic}"), None, None)
            .await
    }

    pub(crate) async fn clamp_size(&self, epic: &str, size: f64) -> Result<f64> {
        let market = self.market_details(epic).await?;
        let min_size = market
            .get("dealingRules")
            .and_then(|value| value.get("minDealSize"))
            .and_then(|value| value.get("value"))
            .and_then(|value| {
                value
                    .as_f64()
                    .or_else(|| value.as_str().and_then(|text| text.parse::<f64>().ok()))
            })
            .unwrap_or(size);

        Ok(size.max(min_size))
    }

    pub(crate) async fn resolve_deal_reference(&self, reference: &str) -> Result<String> {
        let response = self
            .request_value(Method::GET, &format!("/confirms/{reference}"), None, None)
            .await?;

        response
            .get("affectedDeals")
            .and_then(Value::as_array)
            .and_then(|deals| deals.first())
            .and_then(|deal| deal.get("dealId"))
            .and_then(Value::as_str)
            .map(ToOwned::to_owned)
            .ok_or_else(|| anyhow!("capital deal reference {reference} did not resolve to a dealId"))
    }

    pub(crate) async fn current_account_id(&self) -> Result<Option<String>> {
        Ok(self.ensure_session().await?.current_account_id)
    }

    /// GET /time — current server time. No authentication required.
    pub async fn server_time(&self) -> Result<Value> {
        let url = format!("{}/api/v1/time", self.inner.config.base_url);
        self.inner
            .http
            .get(&url)
            .header("X-CAP-API-KEY", &self.inner.config.api_key)
            .send()
            .await
            .with_context(|| format!("server_time request failed for {url}"))?
            .error_for_status()
            .with_context(|| format!("server_time returned error status for {url}"))?
            .json::<Value>()
            .await
            .context("server_time response was not valid json")
    }

    /// GET /ping — keeps the current session alive.
    /// Returns `{ "status": "OK" }` on success.
    pub async fn ping(&self) -> Result<Value> {
        self.request_value(Method::GET, "/ping", None, None).await
    }

    /// GET /session — details for the currently active session.
    /// Fields include: clientId, accountId, locale, currency, streamEndpoint.
    pub async fn session_details(&self) -> Result<Value> {
        self.request_value(Method::GET, "/session", None, None).await
    }

    /// PUT /session — switch the active financial account.
    /// Note: Capital.com may issue new CST/X-SECURITY-TOKEN headers after switching;
    /// call `create_session()` again if subsequent requests fail with 401.
    pub async fn switch_account(&self, account_id: &str) -> Result<Value> {
        self.request_value(
            Method::PUT,
            "/session",
            Some(json!({ "accountId": account_id })),
            None,
        )
        .await
    }

    /// DELETE /session — log out and invalidate the current session tokens.
    /// The cached session is cleared so the next request will create a new session.
    pub async fn logout(&self) -> Result<Value> {
        let result = self.request_value(Method::DELETE, "/session", None, None).await?;
        *self.inner.session.lock().await = None;
        Ok(result)
    }
}
