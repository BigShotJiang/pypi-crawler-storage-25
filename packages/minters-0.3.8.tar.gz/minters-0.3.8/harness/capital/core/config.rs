use std::env;

use anyhow::{Context, Result};

#[derive(Debug, Clone)]
pub struct CapitalConfig {
    pub api_key: String,
    pub identifier: String,
    pub password: String,
    pub base_url: String,
    pub demo: bool,
}

impl CapitalConfig {
    pub fn from_env(demo_override: Option<bool>) -> Result<Self> {
        dotenvy::dotenv().ok();

        let api_key = env::var("CAPITAL_API_KEY").context("CAPITAL_API_KEY is required")?;
        let identifier = env::var("CAPITAL_IDENTIFIER").context("CAPITAL_IDENTIFIER is required")?;
        let password = env::var("CAPITAL_PASSWORD").context("CAPITAL_PASSWORD is required")?;
        let demo = demo_override.unwrap_or_else(|| {
            env::var("CAPITAL_DEMO")
                .map(|value| matches!(value.to_ascii_lowercase().as_str(), "1" | "true" | "yes"))
                .unwrap_or(false)
        });
        let base_url = if demo {
            env::var("CAPITAL_DEMO_URL")
                .unwrap_or_else(|_| "https://demo-api-capital.backend-capital.com".to_string())
        } else {
            env::var("CAPITAL_BASE_URL")
                .unwrap_or_else(|_| "https://api-capital.backend-capital.com".to_string())
        };

        Ok(Self {
            api_key,
            identifier,
            password,
            base_url: base_url.trim_end_matches('/').to_string(),
            demo,
        })
    }
}
