#[derive(Clone, Debug)]
pub(crate) struct SessionState {
    pub cst: String,
    pub security_token: String,
    pub current_account_id: Option<String>,
}
