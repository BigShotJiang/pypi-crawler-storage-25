# Capital.com Contract API (Python)

Set these environment variables to use the Capital backend:

```env
BROKER_MODE=capital
CAPITAL_ENABLED=true
CAPITAL_API_KEY=...
CAPITAL_IDENTIFIER=...
CAPITAL_PASSWORD=...
CAPITAL_DEMO=true
```

## Contract-level functions

These top-level `harness` functions already route to Capital when `BROKER_MODE=capital`:

- `get_account_snapshot()`
- `get_open_positions(symbol=None)`
- `get_pending_orders(symbol=None, order_type=None)`
- `get_closed_orders(symbol=None, start_time=None, end_time=None, limit=100)`
- `get_current_price(symbol)`
- `get_historical_ohlc(symbol, timeframe, limit=1000, start_time=None, end_time=None)`
- `get_historical_ohlc_range(symbol, timeframe, start_time, end_time, limit=5000)`
- `market_buy(symbol, volume)`
- `market_sell(symbol, volume)`
- `buy_limit(symbol, volume, price, stop_loss=0.0, take_profit=0.0)`
- `sell_limit(symbol, volume, price, stop_loss=0.0, take_profit=0.0)`
- `buy_stop(symbol, volume, price, stop_loss=0.0, take_profit=0.0)`
- `sell_stop(symbol, volume, price, stop_loss=0.0, take_profit=0.0)`
- `modify_trade_position(ticket, stop_loss=0.0, take_profit=0.0)`
- `close_trade_position(ticket)`
- `modify_order(ticket, price=0.0, stop_loss=0.0, take_profit=0.0)`
- `cancel_order(ticket)`

## Notes on feature parity

- `buy_stop_limit(...)` and `sell_stop_limit(...)` currently return unsupported for Capital.
- `close_position_partial(...)` closes full position on Capital (partial close is not mapped yet).
- `close_by(...)` is unsupported on Capital.
- Tick-level history and order book are emulated/minimal on Capital in this adapter.

## Rust bridge methods (via PyO3)

The `nursery_capital_py.CapitalBridge` class provides JSON methods used by the Python adapter, including:

- `account_snapshot_json()`
- `positions_json(symbol=None)`
- `pending_orders_json(symbol=None)`
- `closed_orders_json(limit=100)`
- `closed_orders_range_json(from=None, to=None, transaction_type=None)`
- `current_price_json(symbol)`
- `market_details_json(symbol)`
- `historical_ohlc_json(symbol, timeframe, count=1000)`
- `historical_ohlc_range_json(symbol, timeframe, from, to)`
- `market_buy_json(...)`, `market_sell_json(...)`
- `buy_limit_json(...)`, `sell_limit_json(...)`
- `buy_stop_json(...)`, `sell_stop_json(...)`
- `modify_position_json(...)`, `close_position_full_json(...)`
- `modify_order_json(...)`, `cancel_order_json(...)`
