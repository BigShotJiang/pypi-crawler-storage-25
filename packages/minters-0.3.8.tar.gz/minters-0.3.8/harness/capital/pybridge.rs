use anyhow::Result;
use pyo3::exceptions::PyRuntimeError;
use pyo3::prelude::*;
use serde::Serialize;

use crate::core::CapitalClient;

fn to_py_err(err: anyhow::Error) -> PyErr {
    PyRuntimeError::new_err(err.to_string())
}

fn to_json<T: Serialize>(value: &T) -> PyResult<String> {
    serde_json::to_string(value).map_err(|e| PyRuntimeError::new_err(e.to_string()))
}

fn run_async<F, T>(fut: F) -> PyResult<T>
where
    F: std::future::Future<Output = Result<T>>,
{
    let rt = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
    rt.block_on(fut).map_err(to_py_err)
}

#[pyclass]
pub struct CapitalBridge {
    client: CapitalClient,
}

#[pymethods]
impl CapitalBridge {
    #[new]
    #[pyo3(signature = (demo_override=None))]
    fn new(demo_override: Option<bool>) -> PyResult<Self> {
        let client = CapitalClient::from_env(demo_override).map_err(to_py_err)?;
        Ok(Self { client })
    }

    fn account_snapshot_json(&self) -> PyResult<String> {
        let client = self.client.clone();
        let snapshot = run_async(async move { client.account().snapshot().await })?;
        to_json(&snapshot)
    }

    #[pyo3(signature = (symbol=None))]
    fn positions_json(&self, symbol: Option<String>) -> PyResult<String> {
        let client = self.client.clone();
        let positions = run_async(async move { client.account().positions(symbol.as_deref()).await })?;
        to_json(&positions)
    }

    #[pyo3(signature = (symbol=None))]
    fn pending_orders_json(&self, symbol: Option<String>) -> PyResult<String> {
        let client = self.client.clone();
        let orders = run_async(async move { client.account().pending_orders(symbol.as_deref()).await })?;
        to_json(&orders)
    }

    #[pyo3(signature = (limit=100usize))]
    fn closed_orders_json(&self, limit: usize) -> PyResult<String> {
        let client = self.client.clone();
        let orders = run_async(async move { client.account().closed_orders(limit).await })?;
        to_json(&orders)
    }

    #[pyo3(signature = (from=None, to=None, transaction_type=None))]
    fn closed_orders_range_json(
        &self,
        from: Option<String>,
        to: Option<String>,
        transaction_type: Option<String>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let orders = run_async(async move {
            client
                .account()
                .closed_orders_range(from.as_deref(), to.as_deref(), transaction_type.as_deref())
                .await
        })?;
        to_json(&orders)
    }

    fn account_preferences_json(&self) -> PyResult<String> {
        let client = self.client.clone();
        let prefs = run_async(async move { client.account().account_preferences().await })?;
        to_json(&prefs)
    }

    #[pyo3(signature = (last_period_secs=None))]
    fn activity_history_json(&self, last_period_secs: Option<u64>) -> PyResult<String> {
        let client = self.client.clone();
        let activity = run_async(async move { client.account().activity_history(last_period_secs).await })?;
        to_json(&activity)
    }

    #[pyo3(signature = (from=None, to=None, detailed=false, _filter_str=None))]
    fn activity_history_range_json(
        &self,
        from: Option<String>,
        to: Option<String>,
        detailed: bool,
        _filter_str: Option<String>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .account()
                .activity_history_range(from.as_deref(), to.as_deref(), detailed)
                .await
        })?;
        to_json(&value)
    }

    fn position_by_id_json(&self, deal_id: String) -> PyResult<String> {
        let client = self.client.clone();
        let position = run_async(async move { client.account().position_by_id(&deal_id).await })?;
        to_json(&position)
    }

    fn current_price_json(&self, symbol: String) -> PyResult<String> {
        let client = self.client.clone();
        let quote = run_async(async move { client.data().current_price(&symbol).await })?;
        to_json(&quote)
    }

    fn market_details_json(&self, symbol: String) -> PyResult<String> {
        let client = self.client.clone();
        let details = run_async(async move { client.data().market_details(&symbol).await })?;
        to_json(&details)
    }

    #[pyo3(signature = (symbol, timeframe, count = 1000))]
    fn historical_ohlc_json(&self, symbol: String, timeframe: String, count: usize) -> PyResult<String> {
        let client = self.client.clone();
        let candles =
            run_async(async move { client.data().historical_ohlc(&symbol, &timeframe, count).await })?;
        to_json(&candles)
    }

    fn historical_ohlc_range_json(
        &self,
        symbol: String,
        timeframe: String,
        from: String,
        to: String,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let candles = run_async(async move {
            client
                .data()
                .historical_ohlc_range(&symbol, &timeframe, &from, &to)
                .await
        })?;
        to_json(&candles)
    }

    fn search_markets_json(&self, query: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.data().search_markets(&query).await })?;
        to_json(&value)
    }

    fn markets_by_epics_json(&self, epics: Vec<String>) -> PyResult<String> {
        let client = self.client.clone();
        let refs = epics.iter().map(|s| s.as_str()).collect::<Vec<_>>();
        let value = run_async(async move { client.data().markets_by_epics(&refs).await })?;
        to_json(&value)
    }

    fn server_time_json(&self) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.server_time().await })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, stop_loss=None, take_profit=None))]
    fn market_buy_json(
        &self,
        symbol: String,
        size: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .execute()
                .market_buy(&symbol, size, stop_loss, take_profit)
                .await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, stop_loss=None, take_profit=None))]
    fn market_sell_json(
        &self,
        symbol: String,
        size: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .execute()
                .market_sell(&symbol, size, stop_loss, take_profit)
                .await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, level, stop_loss=None, take_profit=None))]
    fn buy_limit_json(
        &self,
        symbol: String,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .execute()
                .buy_limit(&symbol, size, level, stop_loss, take_profit)
                .await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, level, stop_loss=None, take_profit=None))]
    fn sell_limit_json(
        &self,
        symbol: String,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .execute()
                .sell_limit(&symbol, size, level, stop_loss, take_profit)
                .await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, level, stop_loss=None, take_profit=None))]
    fn buy_stop_json(
        &self,
        symbol: String,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .execute()
                .buy_stop(&symbol, size, level, stop_loss, take_profit)
                .await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, level, stop_loss=None, take_profit=None))]
    fn sell_stop_json(
        &self,
        symbol: String,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .execute()
                .sell_stop(&symbol, size, level, stop_loss, take_profit)
                .await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (ticket_or_reference, stop_loss=None, take_profit=None))]
    fn modify_position_json(
        &self,
        ticket_or_reference: String,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .execute()
                .modify_position(&ticket_or_reference, stop_loss, take_profit)
                .await
        })?;
        to_json(&value)
    }

    fn close_position_full_json(&self, ticket_or_reference: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .execute()
                .close_position_full(&ticket_or_reference)
                .await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (ticket_or_reference, level, stop_loss=None, take_profit=None))]
    fn modify_order_json(
        &self,
        ticket_or_reference: String,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client
                .execute()
                .modify_order(&ticket_or_reference, level, stop_loss, take_profit)
                .await
        })?;
        to_json(&value)
    }

    fn cancel_order_json(&self, ticket_or_reference: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.execute().cancel_order(&ticket_or_reference).await })?;
        to_json(&value)
    }

    fn confirm_deal_json(&self, deal_reference: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.execute().confirm_deal(&deal_reference).await })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, level, stop_loss=None, take_profit=None, good_till_date=None))]
    fn buy_limit_gtd_json(
        &self,
        symbol: String,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
        good_till_date: Option<String>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let gtd = good_till_date.unwrap_or_default();
        let value = run_async(async move {
            client.execute().buy_limit_gtd(&symbol, size, level, stop_loss, take_profit, &gtd).await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, level, stop_loss=None, take_profit=None, good_till_date=None))]
    fn sell_limit_gtd_json(
        &self,
        symbol: String,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
        good_till_date: Option<String>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let gtd = good_till_date.unwrap_or_default();
        let value = run_async(async move {
            client.execute().sell_limit_gtd(&symbol, size, level, stop_loss, take_profit, &gtd).await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, level, stop_loss=None, take_profit=None, good_till_date=None))]
    fn buy_stop_gtd_json(
        &self,
        symbol: String,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
        good_till_date: Option<String>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let gtd = good_till_date.unwrap_or_default();
        let value = run_async(async move {
            client.execute().buy_stop_gtd(&symbol, size, level, stop_loss, take_profit, &gtd).await
        })?;
        to_json(&value)
    }

    #[pyo3(signature = (symbol, size, level, stop_loss=None, take_profit=None, good_till_date=None))]
    fn sell_stop_gtd_json(
        &self,
        symbol: String,
        size: f64,
        level: f64,
        stop_loss: Option<f64>,
        take_profit: Option<f64>,
        good_till_date: Option<String>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let gtd = good_till_date.unwrap_or_default();
        let value = run_async(async move {
            client.execute().sell_stop_gtd(&symbol, size, level, stop_loss, take_profit, &gtd).await
        })?;
        to_json(&value)
    }

    fn top_up_demo_json(&self, amount: f64) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.account().top_up_demo(amount).await })?;
        to_json(&value)
    }

    #[pyo3(signature = (leverages_json=None, hedging_mode=None))]
    fn update_account_preferences_json(
        &self,
        leverages_json: Option<String>,
        hedging_mode: Option<bool>,
    ) -> PyResult<String> {
        let client = self.client.clone();
        let lev_value: Option<serde_json::Value> = leverages_json
            .as_deref()
            .map(|s| serde_json::from_str::<serde_json::Value>(s))
            .transpose()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        let value = run_async(async move {
            client.account().update_account_preferences(lev_value.as_ref(), hedging_mode).await
        })?;
        to_json(&value)
    }

    fn market_navigation_json(&self) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.data().market_navigation().await })?;
        to_json(&value)
    }

    fn market_navigation_node_json(&self, node_id: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.data().market_navigation_node(&node_id).await })?;
        to_json(&value)
    }

    fn client_sentiment_json(&self, market_id: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.data().client_sentiment(&market_id).await })?;
        to_json(&value)
    }

    fn client_sentiment_batch_json(&self, market_ids: Vec<String>) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            let refs: Vec<&str> = market_ids.iter().map(|s| s.as_str()).collect();
            client.data().client_sentiment_batch(&refs).await
        })?;
        to_json(&value)
    }

    fn watchlists_json(&self) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.data().watchlists().await })?;
        to_json(&value)
    }

    fn watchlist_json(&self, watchlist_id: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.data().watchlist(&watchlist_id).await })?;
        to_json(&value)
    }

    #[pyo3(signature = (name, epics=None))]
    fn create_watchlist_json(&self, name: String, epics: Option<Vec<String>>) -> PyResult<String> {
        let client = self.client.clone();
        let epics = epics.unwrap_or_default();
        let value = run_async(async move {
            let refs: Vec<&str> = epics.iter().map(|s| s.as_str()).collect();
            client.data().create_watchlist(&name, &refs).await
        })?;
        to_json(&value)
    }

    fn add_to_watchlist_json(&self, watchlist_id: String, epic: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client.data().add_to_watchlist(&watchlist_id, &epic).await
        })?;
        to_json(&value)
    }

    fn delete_watchlist_json(&self, watchlist_id: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move { client.data().delete_watchlist(&watchlist_id).await })?;
        to_json(&value)
    }

    fn remove_from_watchlist_json(&self, watchlist_id: String, epic: String) -> PyResult<String> {
        let client = self.client.clone();
        let value = run_async(async move {
            client.data().remove_from_watchlist(&watchlist_id, &epic).await
        })?;
        to_json(&value)
    }
}

#[pymodule]
pub fn nursery_capital_py(_py: Python<'_>, m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<CapitalBridge>()?;
    Ok(())
}
