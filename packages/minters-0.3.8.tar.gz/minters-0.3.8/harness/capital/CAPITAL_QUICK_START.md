# Capital.com Integration Quick Reference

## Enable Capital Backend

### Option 1: Environment Variable
```bash
export BROKER_MODE=capital
```

### Option 2: Boolean Flag
```bash
export CAPITAL_ENABLED=true
```

## Configure Credentials

Add to `.env` or environment:
```bash
CAPITAL_API_KEY=your_api_key_here
CAPITAL_IDENTIFIER=your_email@example.com
CAPITAL_PASSWORD=your_password
CAPITAL_DEMO=true        # Set to false for live trading
```

## Build Rust Extension

```bash
cd /home/barnes/mint/harness/capital
source /home/barnes/mint/.venv/bin/activate
maturin develop
```

## Usage Examples

### Get Account Information
```python
import asyncio
from harness import get_client

async def check_account():
    client = await get_client()
    info = await client.get_account_information()
    print(f"Balance: ${info['balance']}")
    print(f"Equity: ${info['equity']}")
    print(f"Leverage: {info['leverage']}x")

asyncio.run(check_account())
```

### Get Current Price
```python
async def get_price():
    client = await get_client()
    quote = await client.get_current_price("EURUSD")
    print(f"EURUSD Bid: {quote['bid']} Ask: {quote['ask']}")

asyncio.run(get_price())
```

### Place Market Order
```python
async def buy_eurusd():
    client = await get_client()
    order = await client.market_buy("EURUSD", 0.1)
    if order['success']:
        print(f"Order {order['ticket']} placed")
        ticket = order['ticket']
        
        # Modify stops
        await client.modify_position(
            ticket,
            stop_loss=1.0850,
            take_profit=1.1050
        )
    else:
        print(f"Order failed: {order['message']}")

asyncio.run(buy_eurusd())
```

### Get Positions
```python
async def check_positions():
    client = await get_client()
    positions = await client.get_positions()
    for pos in positions:
        print(f"{pos['symbol']}: {pos['volume']} @ {pos['openPrice']}")

asyncio.run(check_positions())
```

### Get Historical Data
```python
async def get_candles():
    client = await get_client()
    candles = await client.get_historical_candles(
        "EURUSD",
        "1h",
        limit=24
    )
    for c in candles:
        print(f"{c['time']} O:{c['open']} H:{c['high']} L:{c['low']} C:{c['close']}")

asyncio.run(get_candles())
```

## Run Test Suite

```bash
# All Capital tests
pytest testsuite/test_capital_client.py \
       testsuite/test_capital_contract.py \
       testsuite/test_dispatcher_capital.py -v

# Watch mode (requires pytest-watch)
ptw testsuite/test_capital*.py
```

## Run Example Contract

```bash
export BROKER_MODE=capital
export CONTRACT_DRY_RUN=true
python contracts/capital/contract.py
```

## Available Methods (Quick Summary)

| Category | Methods |
|----------|---------|
| **Account** | `get_account_information()`, `get_positions()`, `get_pending_orders()`, `get_deal_history()` |
| **Market Data** | `get_current_price()`, `get_symbols()`, `get_historical_candles()`, `get_symbol_info()` |
| **Buy** | `market_buy()`, `buy_limit()`, `buy_stop()` |
| **Sell** | `market_sell()`, `sell_limit()`, `sell_stop()` |
| **Management** | `modify_position()`, `close_position()`, `cancel_order()`, `modify_order()` |

## Dispatcher Routing

```python
from harness import get_broker_mode

mode = get_broker_mode()  # Returns: "capital", "farm", "farm_ext", or "auto"
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `ImportError: nursery_capital_py` | Run `maturin develop` to rebuild |
| `CAPITAL_API_KEY is required` | Set credentials in `.env` |
| Real API calls instead of mock | Check BROKER_MODE is set correctly |
| Timeout errors | Capital.com API may be slow; increase timeout |
| Order rejected | Check balance, leverage, symbols, market hours |

## Python Equivalent Functions (for harness contracts)

```python
# From harness module
from harness import (
    get_account_snapshot,          # → client.get_account_information()
    get_open_positions,             # → client.get_positions()
    get_pending_orders,             # → client.get_pending_orders()
    get_current_price,              # → client.get_current_price()
    get_symbols,                    # → client.get_symbols()
    market_buy,                     # → client.market_buy()
    market_sell,                    # → client.market_sell()
    buy_limit,                      # → client.buy_limit()
    sell_limit,                     # → client.sell_limit()
    modify_trade_position,          # → client.modify_position()
    close_trade_position,           # → client.close_position()
    cancel_order,                   # → client.cancel_order()
)
```

## Environment Quick Check

```bash
# Verify Capital backend is active
python -c "from harness import get_broker_mode; print(get_broker_mode())"
# Expected output: capital
```

## Integration Status

✅ **Fully Integrated**
- Rust extension: Compiled and running
- Python adapter: Complete with all methods
- Dispatcher: Routing correctly
- Tests: 12/12 passing
- Documentation: Complete
- Example contract: Working
- Live trading: Ready (with credentials)

## Learn More

See `harness/CAPITAL_INTEGRATION.md` for:
- Full architecture diagram
- Complete API reference
- Rust module breakdown
- Known limitations
- Performance notes
