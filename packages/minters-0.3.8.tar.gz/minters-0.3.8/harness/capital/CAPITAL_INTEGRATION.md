# Capital.com Integration via PyO3/Rust

## Overview

This document describes the Capital.com trading backend integration for the **harness** library. It uses a **Rust implementation** (via PyO3/maturin) to provide high-performance connectivity to Capital.com's REST API.

## Architecture

```
┌─────────────────────────┐
│  Python Contracts       │
│  (harness.core)         │
└────────────┬────────────┘
             │
┌─────────────▼────────────┐
│  Dispatcher              │  ← Routes based on BROKER_MODE/CAPITAL_ENABLED
│  (dispatcher.py)         │
└────────────┬────────────┘
             │
        ┌────┴─────┬────────┐
        │           │        │
  ┌─────▼──┐ ┌────▼───┐ ┌──▼───────┐
  │  Farm  │ │FarmExt │ │ Capital  │
  │ (MT5)  │ │(Cloud) │ │(Rust)    │
  └────────┘ └────────┘ └──┬───────┘
                           │
                    ┌──────▼────────┐
                    │ nursery_     │
                    │ capital_py   │  ← PyO3 Binding to Rust
                    └──────┬────────┘
                           │
                    ┌──────▼────────┐
                    │ Rust Modules │
                    │ (harness/    │
                    │  capital/)   │
                    └──────┬────────┘
                           │
                    ┌──────▼────────┐
                    │ Capital.com  │
                    │ REST API     │
                    └──────────────┘
```

## Quick Start

### 1. Build the PyO3 Extension

```bash
cd /home/barnes/mint
source .venv/bin/activate
cd harness/capital
maturin develop
```

This builds and installs the `nursery_capital_py` Python module from Rust.

### 2. Enable Capital Mode

Set environment variables:

```bash
export BROKER_MODE=capital
# OR
export CAPITAL_ENABLED=true
```

Credentials (from `.env`):

```
CAPITAL_API_KEY=your_api_key
CAPITAL_IDENTIFIER=your_email@example.com
CAPITAL_PASSWORD=your_password
CAPITAL_DEMO=true  # or false for live trading
CAPITAL_BASE_URL=https://api-capital.backend-capital.com
CAPITAL_DEMO_URL=https://demo-api-capital.backend-capital.com
```

### 3. Use in Contracts

```python
import asyncio
from harness.barn.core.dispatcher import get_client

async def main():
    # Get Capital client via dispatcher
    client = await get_client()
    
    # Account operations
    account = await client.get_account_information()
    positions = await client.get_positions()
    
    # Market data
    price = await client.get_current_price("EURUSD")
    candles = await client.get_historical_candles("EURUSD", "1m", limit=100)
    
    # Trading
    order = await client.market_buy("EURUSD", 0.1)
    if order["success"]:
        await client.modify_position(order["ticket"], stop_loss=1.08, take_profit=1.12)

asyncio.run(main())
```

## API Reference

### Account Operations

#### `get_account_information() → dict`
Returns account snapshot with balance, equity, leverage, etc.

```python
info = await client.get_account_information()
# {
#   'login': 'cap-001',
#   'broker': 'Capital.com',
#   'balance': 10000.0,
#   'equity': 9950.0,
#   'leverage': 30,
#   ...
# }
```

#### `get_positions(symbol: str = None) → List[dict]`
Get all open positions, optionally filtered by symbol.

```python
positions = await client.get_positions("EURUSD")
# [
#   {
#     'id': 'pos-001',
#     'symbol': 'EURUSD',
#     'type': 'buy',
#     'volume': 0.1,
#     'openPrice': 1.0950,
#     'unrealizedProfit': 15.5,
#     'stopLoss': 1.0850,
#     'takeProfit': 1.1050,
#   }
# ]
```

#### `get_pending_orders(symbol: str = None) → List[dict]`
Get all pending limit/stop orders.

```python
orders = await client.get_pending_orders()
# [
#   {
#     'id': 'ord-001',
#     'symbol': 'EURUSD',
#     'type': 'buy_limit',
#     'volume': 0.2,
#     'openPrice': 1.0900,
#   }
# ]
```

### Market Data Operations

#### `get_current_price(symbol: str) → dict`
Get current bid/ask for a symbol.

```python
quote = await client.get_current_price("EURUSD")
# {
#   'symbol': 'EURUSD',
#   'bid': 1.0950,
#   'ask': 1.0952,
#   'time': '2026-01-15T10:05:00Z',
# }
```

#### `get_symbols() → List[str]`
Get all tradeable symbols.

```python
symbols = await client.get_symbols()
# ['EURUSD', 'GBPUSD', 'XAUUSD', 'BTCUSD', ...]
```

#### `get_historical_candles(symbol: str, timeframe: str, limit: int = 1000) → List[dict]`
Get historical OHLC data.

```python
candles = await client.get_historical_candles("EURUSD", "1h", limit=24)
# [
#   {
#     'time': '2026-01-14T10:00:00Z',
#     'open': 1.0945,
#     'high': 1.0960,
#     'low': 1.0940,
#     'close': 1.0955,
#     'volume': 1500.0,
#   }
# ]
```

### Trading Operations

#### `market_buy(symbol: str, volume: float) → Dict[str, Any]`
Place a market BUY order.

```python
order = await client.market_buy("EURUSD", 0.1)
# {
#   'success': True,
#   'ticket': 'exec-001',
#   'retcode': 10009,
# }
```

#### `market_sell(symbol: str, volume: float) → Dict[str, Any]`
Place a market SELL order.

```python
order = await client.market_sell("EURUSD", 0.1)
```

#### `buy_limit(symbol: str, volume: float, price: float, stop_loss: float = 0, take_profit: float = 0) → Dict[str, Any]`
Place a BUY limit order.

```python
order = await client.buy_limit("EURUSD", 0.1, 1.0900, stop_loss=1.0850, take_profit=1.0950)
```

#### `sell_limit(symbol: str, volume: float, price: float, stop_loss: float = 0, take_profit: float = 0) → Dict[str, Any]`
Place a SELL limit order.

#### `modify_position(ticket: str, stop_loss: float = 0, take_profit: float = 0) → Dict[str, Any]`
Modify stop-loss and/or take-profit for an open position.

```python
result = await client.modify_position("exec-001", stop_loss=1.0850, take_profit=1.1050)
```

#### `close_position(ticket: str) → Dict[str, Any]`
Close an open position.

```python
result = await client.close_position("exec-001")
```

#### `cancel_order(ticket: str) → Dict[str, Any]`
Cancel a pending order.

```python
result = await client.cancel_order("ord-001")
```

## Rust Module Structure

The Rust implementation is organized as follows:

```
harness/capital/
├── lib.rs              ← Entry point, module declarations
├── pybridge.rs         ← PyO3 bridge (Python bindings)
├── Cargo.toml          ← Rust dependencies
├── util.rs             ← Shared types (AccountSnapshot, Position, etc.)
├── core/
│   ├── mod.rs          ← Client factory
│   ├── client.rs       ← HTTP client + session management
│   ├── config.rs       ← Configuration (API key, credentials)
│   └── session.rs      ← Session state (CST token, security token)
├── account/
│   ├── mod.rs          ← Account API
│   ├── snapshot.rs     ← Account snapshot
│   ├── positions.rs    ← Open positions
│   ├── orders.rs       ← Pending orders
│   └── history.rs      ← Deal history
├── data/
│   ├── mod.rs          ← Market data API
│   ├── quotes.rs       ← Current price quotes
│   ├── market.rs       ← Market search
│   └── history.rs      ← Historical candles
└── execute/
    ├── mod.rs          ← Trading execution API
    ├── market.rs       ← Market orders
    ├── orders.rs       ← Limit/stop orders
    ├── pending.rs      ← Modify/cancel pending
    └── positions.rs    ← Modify/close positions
```

## Testing

### Unit Tests (Mocked Bridge)

```bash
pytest testsuite/test_capital_client.py -v
pytest testsuite/test_capital_contract.py -v
pytest testsuite/test_dispatcher_capital.py -v
```

### Integration Tests with Fake Bridge

All tests use a `_FakeBridge` class that mocks the Rust bridge without hitting live Capital.com API.

### Example Contract

See [contracts/capital/contract.py](../contracts/capital/contract.py) for a complete example that:
- Fetches account info
- Gets market prices
- Checks open positions
- Places test market orders
- Modifies position stop-loss/take-profit
- Closes profitable positions

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `BROKER_MODE` | `farm` | Backend mode: `farm`, `farm_ext`, `capital`, or `auto` |
| `CAPITAL_ENABLED` | *(unset)* | If `true`, enables capital mode (overrides `BROKER_MODE`) |
| `CAPITAL_API_KEY` | *(required)* | Capital.com API key |
| `CAPITAL_IDENTIFIER` | *(required)* | Capital.com email/identifier |
| `CAPITAL_PASSWORD` | *(required)* | Capital.com password |
| `CAPITAL_DEMO` | `true` | Use demo environment (set to `false` for live) |
| `CAPITAL_BASE_URL` | Production URL | Custom base URL |
| `CAPITAL_DEMO_URL` | Demo URL | Custom demo URL |

## Error Handling

All trading methods return a normalized result dict:

```python
{
  'success': bool,        # Whether operation succeeded
  'ticket': str,          # Order/deal ID if successful
  'retcode': int,         # MT4-compatible return code
  'message': str,         # Status/error message
}
```

Example:

```python
order = await client.market_buy("EURUSD", 0.1)
if not order['success']:
    print(f"Order failed: {order['message']}")
```

## Limitations

- **STOP_LIMIT orders**: Capital.com API does not directly support combined STOP_LIMIT orders; these return `success=False`.
- **Partial close**: The `close_position_partial()` method closes the full position; partial closes are not supported.
- **Close-by**: The `close_position_by()` method (close one position by opening opposite) is not supported.

## Building from Source

To rebuild the Rust extension after modifying source:

```bash
source .venv/bin/activate
cd harness/capital
maturin develop
```

For release builds:

```bash
maturin build --release
```

## Performance Notes

- All Rust methods run in a dedicated tokio runtime (single-threaded).
- JSON serialization/deserialization is fast via `serde`.
- HTTP requests are multiplexed via `reqwest`.
- Session tokens are cached to minimize auth overhead.

## Support

For issues or questions:
1. Check the test suite for usage examples.
2. Review the Rust source in `harness/capital/` for implementation details.
3. Consult Capital.com API documentation at https://capital.com/
