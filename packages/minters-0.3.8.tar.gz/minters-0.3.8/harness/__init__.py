"""
harness — MT5 Trading Terminal Package
=======================================

This is the single import surface for ALL harness functionality: trading,
account data, market data, and configuration.  Every public symbol is listed
in ``__all__`` so you can rely on ``from harness import *`` or pick
individual names:

    from harness import market_buy, get_account_snapshot, get_historical_ohlc

Backends
--------
The package ships two interchangeable backends.  Switch via env var:

    BROKER_MODE=farm          # self-hosted MT5 Farm Controller (default)
    BROKER_MODE=farm_ext      # MetaAPI cloud SDK
    BROKER_MODE=capital       # Capital.com backend via Rust (PyO3/maturin)
    BROKER_MODE=auto          # try farm_ext, fall back to farm
    FARM_EXT_ENABLED=true     # shorthand for farm_ext
    FARM_EXT_ENABLED=false    # shorthand for farm

Function index
--------------
Account
~~~~~~~
    get_account_snapshot()          Full account snapshot (balance, equity …)
    get_open_positions()            List of open positions
    get_pending_orders()            List of pending orders
    get_closed_orders()             Closed order history

Market data
~~~~~~~~~~~
    get_current_price(symbol)       Live bid/ask tick
    get_symbol_info(symbol)         Contract specification
    get_symbols()                   All available symbols
    get_server_time()               Broker server time
    get_historical_ohlc(symbol, …)  Historical OHLCV candles
    get_live_ticks(symbol, …)       Async generator of live ticks
    get_historical_ticks(symbol, …) Historical tick data
    get_market_buffer(symbol, …)    Rolling OHLC buffer helper
    read_book(symbol)               Order book / market depth
    calculate_margin(order)         Margin requirement for an order

Trading
~~~~~~~
    market_buy(symbol, volume)
    market_sell(symbol, volume)
    buy_limit(symbol, volume, price, …)
    sell_limit(symbol, volume, price, …)
    buy_stop(symbol, volume, price, …)
    sell_stop(symbol, volume, price, …)
    buy_stop_limit(symbol, volume, price, stop_limit_price, …)
    sell_stop_limit(symbol, volume, price, stop_limit_price, …)
    modify_position_sl_tp(ticket, sl, tp)
    close_position(ticket)
    close_position_partial(ticket, volume)
    close_by(ticket, opposite_ticket)
    close_all_by_symbol(symbol)
    modify_order(ticket, price, sl, tp)
    cancel_order(ticket)

History (granular)
~~~~~~~~~~~~~~~~~~
    get_deal_history(from_ts, to_ts)
    get_deals_by_ticket(ticket)
    get_deals_by_position(position_id)
    get_deals_by_time_range(start, end)
    get_history_orders_by_ticket(ticket)
    get_history_orders_by_position(position_id)
    get_history_orders_by_time_range(start, end)

Low-level clients
~~~~~~~~~~~~~~~~~
    get_client(user, account_id)    Returns active backend client
    FarmClient                      Self-hosted farm
    FarmExtClient                   MetaAPI cloud wrapper
    get_broker_mode()               Current mode string
    is_farm_ext_enabled()           True if farm_ext is active/preferred
"""

# ---------------------------------------------------------------------------
# Core — clients and dispatcher
# ---------------------------------------------------------------------------
from .barn.core import (
    FarmClient,
    FarmExtClient,
    CapitalClient,
    MetaApiClient,          # backward-compat alias for FarmClient
    get_terminal_state,
    get_client,
    get_broker_mode,
    is_farm_ext_enabled,
    # Data models
    AccountSnapshot,
    Position,
    Order,
    Deal,
    Candle,
    OrderType,
    OrderState,
    PositionType,
    convert_positions,
    convert_orders,
    convert_deals,
    convert_candles,
    # Utilities
    normalize_symbol,
    validate_timeframe,
    safe_float_convert,
    parse_metaapi_time,
)

# ---------------------------------------------------------------------------
# Schema / service managers
# ---------------------------------------------------------------------------
from .schema import (
    TerminalServiceManager,
    all_terminal_tools,
    all_terminal_implementations,
    core_terminal_tools,
    core_terminal_implementations,
    terminal_aggregated_tools,
    terminal_aggregated_implementations,
)
from .barn.account.schema import AccountServiceManager
from .barn.data.schema import DataServiceManager
from .barn.trade.schema import (
    TradeServiceManager,
    TRADE_SCHEMAS,
    ORDER_TYPES,
    ACTION_TYPES,
    FILLING_MODES,
    EXPIRATION_TYPES,
    PRICE_UNITS,
)

TradingServiceManager = TradeServiceManager     # compat alias
MarketDataServiceManager = DataServiceManager   # compat alias

# ---------------------------------------------------------------------------
# Account functions
# ---------------------------------------------------------------------------
from .barn.account.creds import get_account_snapshot
from .barn.account.positions import get_open_positions, get_pending_orders
from .barn.account.history import get_closed_orders

# ---------------------------------------------------------------------------
# Data functions
# ---------------------------------------------------------------------------
from .barn.data.quotes import get_live_ticks, get_historical_ohlc, get_historical_ohlc_range
from .barn.data.backtest import warmup_and_export_ohlc_csv
from .barn.data.buffer import get_market_buffer

# ---------------------------------------------------------------------------
# Trade functions — convenience wrappers (use dispatcher internally)
# ---------------------------------------------------------------------------
from .barn.trade.orders import (
    TradingOperations,
    OrderType as TradeOrderType,
    ActionType,
    FillingMode,
    ExpirationType,
    # Standalone convenience functions
    create_market_buy,
    create_market_sell,
    create_buy_limit,
    create_sell_limit,
    create_buy_stop,
    create_sell_stop,
    modify_position_sl_tp,
    close_position,
    cancel_pending_order,
)

from .barn.trade.farm_orders import (
    FarmTradingOperations,
    get_farm_trading_operations,
)

# ---------------------------------------------------------------------------
# Unified trading API — functions that go through the active dispatcher
# ---------------------------------------------------------------------------

async def market_buy(symbol: str, volume: float, user=None, account_id=None):
    """Place a market BUY order via the active backend."""
    symbol = normalize_symbol(symbol)
    client = await get_client(account_id=account_id, user=user)
    return await client.market_buy(symbol, volume)


async def market_sell(symbol: str, volume: float, user=None, account_id=None):
    """Place a market SELL order via the active backend."""
    symbol = normalize_symbol(symbol)
    client = await get_client(account_id=account_id, user=user)
    return await client.market_sell(symbol, volume)


async def buy_limit(
    symbol: str,
    volume: float,
    price: float,
    stop_loss: float = 0.0,
    take_profit: float = 0.0,
    user=None,
    account_id=None,
):
    """Place a BUY LIMIT pending order via the active backend."""
    symbol = normalize_symbol(symbol)
    client = await get_client(account_id=account_id, user=user)
    return await client.buy_limit(symbol, volume, price, stop_loss, take_profit)


async def sell_limit(
    symbol: str,
    volume: float,
    price: float,
    stop_loss: float = 0.0,
    take_profit: float = 0.0,
    user=None,
    account_id=None,
):
    """Place a SELL LIMIT pending order via the active backend."""
    symbol = normalize_symbol(symbol)
    client = await get_client(account_id=account_id, user=user)
    return await client.sell_limit(symbol, volume, price, stop_loss, take_profit)


async def buy_stop(
    symbol: str,
    volume: float,
    price: float,
    stop_loss: float = 0.0,
    take_profit: float = 0.0,
    user=None,
    account_id=None,
):
    """Place a BUY STOP pending order via the active backend."""
    symbol = normalize_symbol(symbol)
    client = await get_client(account_id=account_id, user=user)
    return await client.buy_stop(symbol, volume, price, stop_loss, take_profit)


async def sell_stop(
    symbol: str,
    volume: float,
    price: float,
    stop_loss: float = 0.0,
    take_profit: float = 0.0,
    user=None,
    account_id=None,
):
    """Place a SELL STOP pending order via the active backend."""
    symbol = normalize_symbol(symbol)
    client = await get_client(account_id=account_id, user=user)
    return await client.sell_stop(symbol, volume, price, stop_loss, take_profit)


async def buy_stop_limit(
    symbol: str,
    volume: float,
    price: float,
    stop_limit_price: float,
    stop_loss: float = 0.0,
    take_profit: float = 0.0,
    user=None,
    account_id=None,
):
    """Place a BUY STOP-LIMIT pending order via the active backend."""
    symbol = normalize_symbol(symbol)
    client = await get_client(account_id=account_id, user=user)
    return await client.buy_stop_limit(
        symbol, volume, price, stop_limit_price, stop_loss, take_profit
    )


async def sell_stop_limit(
    symbol: str,
    volume: float,
    price: float,
    stop_limit_price: float,
    stop_loss: float = 0.0,
    take_profit: float = 0.0,
    user=None,
    account_id=None,
):
    """Place a SELL STOP-LIMIT pending order via the active backend."""
    symbol = normalize_symbol(symbol)
    client = await get_client(account_id=account_id, user=user)
    return await client.sell_stop_limit(
        symbol, volume, price, stop_limit_price, stop_loss, take_profit
    )


async def modify_trade_position(
    ticket,
    stop_loss: float = 0.0,
    take_profit: float = 0.0,
    user=None,
    account_id=None,
):
    """Modify an open position's SL/TP."""
    client = await get_client(account_id=account_id, user=user)
    return await client.modify_position(ticket, stop_loss, take_profit)


async def close_trade_position(ticket, user=None, account_id=None):
    """Close an open position."""
    client = await get_client(account_id=account_id, user=user)
    return await client.close_position(ticket)


async def close_position_partial(
    ticket, volume: float, user=None, account_id=None
):
    """Partially close a position."""
    client = await get_client(account_id=account_id, user=user)
    return await client.close_position_partial(ticket, volume)


async def close_by(ticket, opposite_ticket, user=None, account_id=None):
    """Close a position against the opposite position (hedge close)."""
    client = await get_client(account_id=account_id, user=user)
    return await client.close_position_by(ticket, opposite_ticket)


async def close_all_by_symbol(symbol: str, user=None, account_id=None):
    """Close ALL open positions for a symbol."""
    client = await get_client(account_id=account_id, user=user)
    return await client.close_all_positions_by_symbol(symbol)


async def modify_order(
    ticket,
    price: float = 0.0,
    stop_loss: float = 0.0,
    take_profit: float = 0.0,
    user=None,
    account_id=None,
):
    """Modify a pending order."""
    client = await get_client(account_id=account_id, user=user)
    return await client.modify_order(ticket, price, stop_loss, take_profit)


async def cancel_order(ticket, user=None, account_id=None):
    """Cancel a pending order."""
    client = await get_client(account_id=account_id, user=user)
    return await client.cancel_order(ticket)


# ---------------------------------------------------------------------------
# Market data API — dispatcher-aware
# ---------------------------------------------------------------------------

async def get_current_price(symbol: str, user=None, account_id=None) -> dict:
    """Get the current bid/ask price for a symbol."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_current_price(symbol)


async def get_symbol_info(symbol: str, user=None, account_id=None) -> dict:
    """Get contract specification for a symbol."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_symbol_info(symbol)


async def get_symbols(user=None, account_id=None):
    """List all symbols available in the active terminal."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_symbols()


async def get_server_time(user=None, account_id=None) -> dict:
    """Get the broker's current server time."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_server_time()


async def get_historical_ticks(
    symbol: str,
    start_time=None,
    end_time=None,
    offset: int = 0,
    limit: int = 100,
    user=None,
    account_id=None,
):
    """Retrieve historical tick data for a symbol."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_historical_ticks(symbol, start_time, end_time, offset, limit)


async def read_book(symbol: str, user=None, account_id=None):
    """Retrieve order book / market depth for a symbol."""
    client = await get_client(account_id=account_id, user=user)
    return await client.read_book(symbol)


async def calculate_margin(order: dict, user=None, account_id=None) -> dict:
    """Calculate margin required for an order dict."""
    client = await get_client(account_id=account_id, user=user)
    return await client.calculate_margin(order)


# ---------------------------------------------------------------------------
# History — dispatcher-aware
# ---------------------------------------------------------------------------

async def get_deal_history(from_ts=0, to_ts=0, user=None, account_id=None):
    """Get deal history by epoch timestamps."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_deal_history(from_ts, to_ts)


async def get_deals_by_ticket(ticket, user=None, account_id=None):
    """Get deals filtered by ticket number."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_deals_by_ticket(str(ticket))


async def get_deals_by_position(position_id, user=None, account_id=None):
    """Get deals filtered by position ID."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_deals_by_position(str(position_id))


async def get_deals_by_time_range(start_time, end_time=None, user=None, account_id=None):
    """Get deals within a time range."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_deals_by_time_range(start_time, end_time)


async def get_history_orders_by_ticket(ticket, user=None, account_id=None):
    """Get history orders filtered by ticket."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_history_orders_by_ticket(str(ticket))


async def get_history_orders_by_position(position_id, user=None, account_id=None):
    """Get history orders filtered by position ID."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_history_orders_by_position(str(position_id))


async def get_history_orders_by_time_range(
    start_time, end_time=None, user=None, account_id=None
):
    """Get history orders within a time range."""
    client = await get_client(account_id=account_id, user=user)
    return await client.get_history_orders_by_time_range(start_time, end_time)


# ---------------------------------------------------------------------------
# Engine handles — `from harness import capital / farm / farm_ext`
# ---------------------------------------------------------------------------
from .barn.engines.capital import capital, CapitalEngine
from .barn.engines.farm import farm, FarmEngine
from .barn.engines.farm_ext import farm_ext, FarmExtEngine

# ---------------------------------------------------------------------------
# __all__ — the complete public API
# ---------------------------------------------------------------------------

__all__ = [
    # ── Backends ─────────────────────────────────────────────────────────
    "FarmClient",
    "FarmExtClient",
    "CapitalClient",
    "MetaApiClient",                # compat alias
    "get_client",
    "get_broker_mode",
    "is_farm_ext_enabled",
    "get_terminal_state",

    # ── Service managers ─────────────────────────────────────────────────
    "TerminalServiceManager",
    "AccountServiceManager",
    "DataServiceManager",
    "TradeServiceManager",
    "TradingServiceManager",        # alias
    "MarketDataServiceManager",     # alias
    "all_terminal_tools",
    "all_terminal_implementations",
    "core_terminal_tools",
    "core_terminal_implementations",
    "terminal_aggregated_tools",
    "terminal_aggregated_implementations",

    # ── Trade schemas / constants ─────────────────────────────────────────
    "TRADE_SCHEMAS",
    "ORDER_TYPES",
    "ACTION_TYPES",
    "FILLING_MODES",
    "EXPIRATION_TYPES",
    "PRICE_UNITS",

    # ── Trade classes ─────────────────────────────────────────────────────
    "TradingOperations",
    "FarmTradingOperations",
    "get_farm_trading_operations",
    "TradeOrderType",
    "ActionType",
    "FillingMode",
    "ExpirationType",

    # ── Account functions ─────────────────────────────────────────────────
    "get_account_snapshot",
    "get_open_positions",
    "get_pending_orders",
    "get_closed_orders",

    # ── Market data functions ─────────────────────────────────────────────
    "get_live_ticks",
    "get_historical_ohlc",
    "get_historical_ohlc_range",
    "warmup_and_export_ohlc_csv",
    "get_market_buffer",
    "get_current_price",
    "get_symbol_info",
    "get_symbols",
    "get_server_time",
    "get_historical_ticks",
    "read_book",
    "calculate_margin",

    # ── Unified trade functions ───────────────────────────────────────────
    "market_buy",
    "market_sell",
    "buy_limit",
    "sell_limit",
    "buy_stop",
    "sell_stop",
    "buy_stop_limit",
    "sell_stop_limit",
    "modify_trade_position",
    "close_trade_position",
    "close_position_partial",
    "close_by",
    "close_all_by_symbol",
    "modify_order",
    "cancel_order",

    # ── Legacy trade helpers ──────────────────────────────────────────────
    "create_market_buy",
    "create_market_sell",
    "create_buy_limit",
    "create_sell_limit",
    "create_buy_stop",
    "create_sell_stop",
    "modify_position_sl_tp",
    "close_position",
    "cancel_pending_order",

    # ── History (granular) ────────────────────────────────────────────────
    "get_deal_history",
    "get_deals_by_ticket",
    "get_deals_by_position",
    "get_deals_by_time_range",
    "get_history_orders_by_ticket",
    "get_history_orders_by_position",
    "get_history_orders_by_time_range",

    # ── Models ────────────────────────────────────────────────────────────
    "AccountSnapshot",
    "Position",
    "Order",
    "Deal",
    "Candle",
    "OrderType",
    "OrderState",
    "PositionType",
    "convert_positions",
    "convert_orders",
    "convert_deals",
    "convert_candles",

    # ── Utilities ─────────────────────────────────────────────────────────
    "normalize_symbol",
    "validate_timeframe",
    "safe_float_convert",
    "parse_metaapi_time",

    # ── Engine handles ────────────────────────────────────────────────────
    "capital",
    "farm",
    "farm_ext",
    "CapitalEngine",
    "FarmEngine",
    "FarmExtEngine",
]
