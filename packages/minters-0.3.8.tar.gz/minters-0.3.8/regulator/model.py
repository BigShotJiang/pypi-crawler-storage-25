import inspect
import json
import os
from collections.abc import Callable
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from nineth import NinethClient
from minters.workspace import resolve_workspace_root
from .schema import WeatherServiceManager, weather_implementations

# load env variables
WORKSPACE_ROOT = resolve_workspace_root(create=False)
load_dotenv(WORKSPACE_ROOT / ".env", override=False)

client: NinethClient | None = None
weather_manager = WeatherServiceManager()


def _build_local_service_handlers():
    handlers = {}
    for service_name, implementation in weather_implementations.items():
        handler = implementation(weather_manager) if callable(implementation) else implementation
        if callable(handler):
            handlers[service_name] = handler
    return handlers


LOCAL_SERVICE_HANDLERS = _build_local_service_handlers()
LOCAL_SCHEMA_PATH = str(Path(__file__).resolve().with_name("schema.py"))
DEFAULT_MAX_ITERATIONS = 300

EventHandler = Callable[[dict[str, Any]], None]


def _ensure_api_key() -> None:
    if os.environ.get("NINETH_API_KEY", "").strip():
        return
    raise RuntimeError(
        "NINETH_API_KEY is not set. Add it to your workspace .env or export it before running minters."
    )


def _get_client() -> NinethClient:
    global client
    _ensure_api_key()
    if client is None:
        client = NinethClient()
    return client


def _supported_request_kwargs(request_callable: Callable[..., Any]) -> set[str]:
    signature = inspect.signature(request_callable)
    allowed_kinds = {
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
        inspect.Parameter.KEYWORD_ONLY,
    }
    return {
        name
        for name, parameter in signature.parameters.items()
        if name != "self" and parameter.kind in allowed_kinds
    }


def _request_model(**kwargs: Any) -> Any:
    request_callable = _get_client().model.request
    supported = _supported_request_kwargs(request_callable)
    filtered_kwargs = {key: value for key, value in kwargs.items() if key in supported}

    if "include_service" not in filtered_kwargs:
        raise RuntimeError(
            "Installed nineth client is too old for local tool calls. Upgrade nineth to 0.5.16 or newer."
        )

    return request_callable(**filtered_kwargs)


def _emit_event(event_handler: EventHandler | None, event: dict[str, Any]) -> None:
    if event_handler is None:
        event_type = str(event.get("type", ""))
        text = str(event.get("text", ""))
        if event_type in {"text_delta", "service_call", "observation"} and text:
            print(text, end="", flush=True)
        elif event_type == "newline":
            print()
        return

    event_handler(event)


def _execute_client_service_calls(pending_client_calls: list[dict[str, Any]]) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    for pending in pending_client_calls:
        call_id = str(pending.get("call_id", "")).strip()
        service_name = str(pending.get("service_name", "")).strip()
        params = pending.get("params", {}) if isinstance(pending.get("params"), dict) else {}
        handler = LOCAL_SERVICE_HANDLERS.get(service_name)

        if handler is None:
            results.append(
                {
                    "call_id": call_id,
                    "service_name": service_name,
                    "success": False,
                    "error": f"Unknown local service: {service_name}",
                }
            )
            continue

        try:
            result = handler(**params)
            success = not (isinstance(result, dict) and result.get("success") is False)
            entry = {
                "call_id": call_id,
                "service_name": service_name,
                "success": success,
                "result": result,
            }
            if not success:
                entry["error"] = str(result.get("error") or "Local service reported failure.")
            results.append(entry)
        except Exception as exc:
            results.append(
                {
                    "call_id": call_id,
                    "service_name": service_name,
                    "success": False,
                    "error": str(exc),
                }
            )

    return results


def _format_service_call_xml(service_name: str, params: dict[str, Any]) -> str:
    encoded_params = json.dumps(params, default=str)
    return f'<service_call name="{service_name}">{encoded_params}</service_call>'


def _missing_result_suffix(final_response: str, emitted_text: str) -> str:
    if not final_response:
        return ""
    if not emitted_text:
        return final_response
    if final_response == emitted_text or emitted_text.endswith(final_response) or emitted_text.startswith(final_response):
        return ""
    if final_response.startswith(emitted_text):
        return final_response[len(emitted_text):]
    return ""


def _format_client_observation(result: dict) -> str:
    payload = {
        "service_name": str(result.get("service_name", "")).strip(),
        "success": bool(result.get("success", False)),
        "params": result.get("params", {}) if isinstance(result.get("params"), dict) else {},
    }
    if payload["success"]:
        payload["result"] = result.get("result")
    else:
        payload["error"] = str(result.get("error") or "Client-managed service execution failed.")
        if "result" in result:
            payload["result"] = result.get("result")
    return f"<obs.client>\n{json.dumps(payload, indent=2, default=str)}\n</obs.client>"


def regulator(model: str, task: str, event_handler: EventHandler | None = None) -> str:
    """Run the local regulator loop with SDK-managed client service callbacks."""

    chunks: list[str] = []
    pending_process_id: str | None = None
    pending_client_results: list[dict[str, Any]] | None = None

    while True:
        pending_calls: list[dict[str, Any]] | None = None
        current_client_results = pending_client_results
        pending_client_results = None

        for event in _request_model(
            task_input=task,
            default_service=False,
            include_service=[LOCAL_SCHEMA_PATH],
            session_id=pending_process_id,
            client_service_results=current_client_results,
            model=model,
            stream=True,
            cache=True,
            max_iterations=DEFAULT_MAX_ITERATIONS,
        ):
            event_type = event.get("type")
            if event_type == "model_delta":
                text = event.get("data", {}).get("text", "")
                if text:
                    chunks.append(text)
                    _emit_event(event_handler, {"type": "text_delta", "text": text})
            elif event_type == "client_service_call":
                payload = event.get("data", {}) if isinstance(event.get("data"), dict) else {}
                service_name = str(payload.get("service_name", "")).strip()
                params = payload.get("params", {}) if isinstance(payload.get("params"), dict) else {}
                service_call = _format_service_call_xml(service_name, params)
                _emit_event(
                    event_handler,
                    {"type": "service_call", "text": service_call, "service_call": service_call},
                )
            elif event_type == "awaiting_client_services":
                pending_process_id = event.get("process_id") or event.get("session_id")
                pending_calls = event.get("data", {}).get("pending_client_calls", [])
                if not pending_process_id:
                    raise RuntimeError("awaiting_client_services event did not include a process/session id")
                _emit_event(
                    event_handler,
                    {
                        "type": "awaiting_client_services",
                        "calls": pending_calls,
                        "process_id": pending_process_id,
                    },
                )
            elif event_type == "result":
                final_text = event.get("data", {}).get("final_response", "")
                emitted_text = "".join(chunks)
                suffix = _missing_result_suffix(final_text, emitted_text)
                if suffix:
                    chunks.append(suffix)
                    _emit_event(event_handler, {"type": "text_delta", "text": suffix})

        if not pending_calls:
            break

        pending_client_results = _execute_client_service_calls(pending_calls)
        if len(pending_client_results) != len(pending_calls):
            raise RuntimeError("client service execution returned an incomplete result set")

        for pending, result in zip(pending_calls, pending_client_results):
            merged_result = dict(result)
            merged_result["params"] = pending.get("params", {}) if isinstance(pending.get("params"), dict) else {}
            observation_text = _format_client_observation(merged_result)
            _emit_event(
                event_handler,
                {
                    "type": "observation",
                    "text": observation_text,
                    "payload": merged_result,
                },
            )

    if chunks:
        _emit_event(event_handler, {"type": "newline"})

    response = "".join(chunks)
    _emit_event(event_handler, {"type": "response_complete", "response": response})
    return response

# test the function
if __name__ == "__main__":

    # define the model name by inheriting from the regulator function and passing in the model name as an argument
    model="1984-m3-0421"
    # _ = regulator(model, "What is the meaning of life?")
    while True:

        print("\n")
        task= input("What is your task? ")
        if task.lower() in ["exit", "quit"]:
            print("Exiting...")
            break

        # label model output as model name and separate with lines for readability
        print(f"\n---\n{model}:\n")
        _ = regulator(model, task)
        print("\n---\n")

    


