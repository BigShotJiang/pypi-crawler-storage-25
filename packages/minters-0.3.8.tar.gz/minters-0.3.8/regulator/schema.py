from __future__ import annotations

import ast
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict

from minters.workspace import resolve_workspace_root

ROOT = resolve_workspace_root(create=False)
CONTRACTS_DIR = ROOT / "contracts"
RUNNER_FILE = ROOT / "harness" / "_runner.py"
BAD_CONTRACT_SIGNALS = (
    "Traceback (most recent call last)",
    "SyntaxError",
    "ImportError",
    "ModuleNotFoundError",
    "TypeError:",
    "NameError:",
    "AttributeError:",
    "[runner] Class",
)
DISPLAY_FILE_LIMIT = 10
IGNORED_PATH_PARTS = {"__pycache__", ".pytest_cache", "build", "dist", "target"}
IGNORED_SUFFIXES = {".pyc", ".pyo"}


def _truncate_text(text: str, limit: int = 20000) -> str:
    if len(text) <= limit:
        return text
    clipped = len(text) - limit
    return f"{text[:limit]}\n... <truncated {clipped} characters>"


def _extract_contract_class_name(code: str) -> str | None:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return None

    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name.endswith("Contract"):
            return node.name
    return None


def _looks_contract_healthy(exit_code: int | None, timed_out: bool, output: str) -> bool:
    if any(signal in output for signal in BAD_CONTRACT_SIGNALS):
        return False
    if exit_code == 0:
        return True
    return timed_out


def _is_ignored_path(path: Path) -> bool:
    return any(part in IGNORED_PATH_PARTS for part in path.parts) or path.suffix in IGNORED_SUFFIXES


class WorkspaceServiceManager:
    def __init__(self, root: Path | None = None) -> None:
        self.root = (root or resolve_workspace_root(create=False)).resolve()
        self.contracts_dir = self.root / "contracts"
        self.runner_file = self.root / "harness" / "_runner.py"

    def _resolve_path(self, path_input: str) -> Path:
        raw = Path(path_input)
        candidate = raw.resolve() if raw.is_absolute() else (self.root / raw).resolve()
        try:
            candidate.relative_to(self.root)
        except ValueError as exc:
            raise ValueError("Path must remain inside the repository root")
        return candidate

    def _resolve_cwd(self, cwd_input: str | None) -> Path:
        target = self.root if not cwd_input else self._resolve_path(cwd_input)
        if not target.exists() or not target.is_dir():
            raise ValueError("Working directory not found")
        return target

    def _read_text(self, path: Path) -> str:
        return path.read_text(encoding="utf-8", errors="replace")

    def _visible_children(self, path: Path, limit: int = DISPLAY_FILE_LIMIT) -> list[str]:
        if not path.exists() or not path.is_dir():
            return []

        children: list[str] = []
        for child in sorted(path.iterdir()):
            rel = child.relative_to(self.root) if child != self.root else Path(child.name)
            if child.name.startswith(".") or _is_ignored_path(rel):
                continue
            suffix = "/" if child.is_dir() else ""
            children.append(f"{child.name}{suffix}")
            if len(children) >= limit:
                break
        return children

    def _nearest_existing_parent(self, requested: Path) -> Path:
        current = requested if requested.suffix == "" else requested.parent
        while True:
            candidate = current if current.is_absolute() else (self.root / current)
            if candidate.exists() and candidate.is_dir():
                return candidate.resolve()
            if current in {Path("."), current.parent}:
                return self.root
            current = current.parent

    def _file_not_found_error(self, requested: str) -> Dict[str, Any]:
        parent = self._nearest_existing_parent(Path(requested))
        rel_parent = "." if parent == self.root else str(parent.relative_to(self.root))
        children = self._visible_children(parent)
        if children:
            listing = ", ".join(children)
            error = f"File not found. Available under {rel_parent}: {listing}"
        else:
            error = f"File not found. Use list_files or repo_tree near {rel_parent} to inspect the workspace"
        return {"success": False, "error": error}

    def _run_process(
        self,
        command: list[str] | str,
        *,
        cwd: Path,
        timeout_sec: int,
        shell: bool = False,
    ) -> dict[str, Any]:
        env = {**os.environ, "MINT_WORKSPACE": str(self.root)}
        try:
            proc = subprocess.run(
                command,
                cwd=cwd,
                env=env,
                capture_output=True,
                text=True,
                shell=shell,
                timeout=max(1, int(timeout_sec)),
                check=False,
            )
            stdout = proc.stdout or ""
            stderr = proc.stderr or ""
            timed_out = False
            exit_code = proc.returncode
        except subprocess.TimeoutExpired as exc:
            stdout = exc.stdout or ""
            stderr = exc.stderr or ""
            timed_out = True
            exit_code = None

        combined = _truncate_text(f"{stdout}{stderr}")
        return {
            "success": (exit_code == 0) and not timed_out,
            "exit_code": exit_code,
            "timed_out": timed_out,
            "cwd": str(cwd.relative_to(self.root)) or ".",
            "output": combined or "<empty>",
        }

    def get_weather(self, location: str) -> Dict[str, Any]:
        return {"location": location, "forecast": "foggy", "temperature": "15°C"}

    def repo_tree(self, max_entries: int = 250) -> Dict[str, Any]:
        lines: list[str] = []
        for path in sorted(self.root.rglob("*")):
            rel = path.relative_to(self.root)
            if any(part.startswith(".") for part in rel.parts) or _is_ignored_path(rel):
                continue
            suffix = "/" if path.is_dir() else ""
            lines.append(f"{rel}{suffix}")
            if len(lines) >= max(1, int(max_entries)):
                lines.append("... (truncated)")
                break
        return {
            "root": str(self.root),
            "entries": len(lines),
            "tree": "\n".join(lines) if lines else "<repository is empty>",
        }

    def list_files(
        self,
        pattern: str = "**/*",
        max_results: int = 200,
        path: str | None = None,
        glob: str | None = None,
        recursive: bool = True,
        **_: Any,
    ) -> Dict[str, Any]:
        recursive = bool(recursive)
        active_pattern = str(glob or pattern or "**/*")
        search_root = self.root

        if path:
            resolved = self._resolve_path(path)
            if resolved.exists() and resolved.is_file():
                rel = str(resolved.relative_to(self.root))
                return {
                    "pattern": rel,
                    "count": 1,
                    "files": [rel],
                    "text": rel,
                }
            if resolved.exists() and resolved.is_dir():
                search_root = resolved
                if not glob and pattern == "**/*":
                    active_pattern = "**/*" if recursive else "*"
            else:
                active_pattern = Path(path).as_posix()

        if not recursive and active_pattern == "**/*":
            active_pattern = "*"
        elif not recursive:
            active_pattern = active_pattern.replace("**/*", "*").replace("**", "*")

        matched: list[str] = []
        for candidate in sorted(search_root.glob(active_pattern)):
            if not candidate.exists():
                continue
            rel = candidate.relative_to(self.root)
            if any(part.startswith(".") for part in rel.parts) or _is_ignored_path(rel):
                continue
            matched.append(str(rel))
            if len(matched) >= max(1, int(max_results)):
                break
        return {
            "pattern": active_pattern,
            "count": len(matched),
            "files": matched,
            "text": "\n".join(matched) if matched else "<no matches>",
        }

    def grep_repo(
        self,
        pattern: str,
        glob: str = "**/*",
        max_results: int = 200,
        case_sensitive: bool = False,
        output_type: str = "matches",
        path: str | None = None,
        **_: Any,
    ) -> Dict[str, Any]:
        if not pattern:
            return {"success": False, "error": "grep_repo requires 'pattern'"}

        if path:
            resolved = self._resolve_path(path)
            if resolved.exists() and resolved.is_dir():
                glob = f"{Path(path).as_posix()}/**/*"
            else:
                glob = Path(path).as_posix()

        limit = max(1, int(max_results))
        rg_command = [
            "rg",
            "-n",
            "--no-heading",
            "--glob",
            "!**/__pycache__/**",
            "--glob",
            "!**/.pytest_cache/**",
            "--glob",
            "!**/*.pyc",
            "--glob",
            "!**/*.pyo",
            "--glob",
            "!build/**",
            "--glob",
            "!dist/**",
            "--glob",
            glob,
            "--max-count",
            str(limit),
        ]
        if not case_sensitive:
            rg_command.append("-i")
        rg_command.extend([pattern, str(self.root)])

        try:
            proc = subprocess.run(rg_command, capture_output=True, text=True, check=False)
            output = (proc.stdout or proc.stderr or "").strip() or "<no matches>"
            files: list[str] = []
            if output_type == "files" and output != "<no matches>":
                files = list(dict.fromkeys(line.split(":", 1)[0] for line in output.splitlines()))
                output = "\n".join(files) if files else "<no matches>"
            return {
                "success": proc.returncode in (0, 1),
                "pattern": pattern,
                "glob": glob,
                "matches": _truncate_text(output),
                "files": files,
                "text": _truncate_text(output),
            }
        except FileNotFoundError:
            flags = 0 if case_sensitive else re.IGNORECASE
            try:
                compiled = re.compile(pattern, flags=flags)
            except re.error as exc:
                return {"success": False, "error": f"Invalid regex: {exc}"}

            hits: list[str] = []
            for path in sorted(self.root.glob(glob)):
                if not path.is_file():
                    continue
                rel = path.relative_to(self.root)
                if any(part.startswith(".") for part in rel.parts) or _is_ignored_path(rel):
                    continue
                try:
                    lines = self._read_text(path).splitlines()
                except OSError:
                    continue
                for index, line in enumerate(lines, start=1):
                    if compiled.search(line):
                        hits.append(f"{path.relative_to(self.root)}:{index}:{line}")
                        if len(hits) >= limit:
                            break
                if len(hits) >= limit:
                    break
            output = "\n".join(hits) if hits else "<no matches>"
            files: list[str] = []
            if output_type == "files" and hits:
                files = list(dict.fromkeys(line.split(":", 1)[0] for line in hits))
                output = "\n".join(files)
            return {
                "success": True,
                "pattern": pattern,
                "glob": glob,
                "matches": _truncate_text(output),
                "files": files,
                "text": _truncate_text(output),
            }

    def read_file(
        self,
        path: str = "",
        start_line: int = 1,
        end_line: int = 240,
        file_path: str | None = None,
        **_: Any,
    ) -> Dict[str, Any]:
        active_path = str(file_path or path).strip()
        if not active_path:
            return {"success": False, "error": "read_file requires 'path'"}

        target = self._resolve_path(active_path)
        if not target.exists() or not target.is_file():
            return self._file_not_found_error(active_path)

        start = max(1, int(start_line))
        end = max(start, int(end_line))
        lines = self._read_text(target).splitlines()
        selected = lines[start - 1 : end]
        numbered = "\n".join(f"{i + start:04d}: {line}" for i, line in enumerate(selected))
        return {
            "success": True,
            "path": str(target.relative_to(self.root)),
            "line_count": len(lines),
            "content": numbered or "<empty range>",
        }

    def write_file(self, path: str, content: str) -> Dict[str, Any]:
        target = self._resolve_path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(str(content), encoding="utf-8")
        return {"success": True, "path": str(target.relative_to(self.root)), "written": True}

    def patch_file(self, path: str, old: str, new: str, replace_all: bool = False) -> Dict[str, Any]:
        target = self._resolve_path(path)
        if not target.exists() or not target.is_file():
            return {"success": False, "error": "File not found"}

        text = self._read_text(target)
        old_text = str(old)
        new_text = str(new)
        count = text.count(old_text)
        if count == 0:
            return {"success": False, "error": "Old text not found"}

        updated = text.replace(old_text, new_text) if replace_all else text.replace(old_text, new_text, 1)
        target.write_text(updated, encoding="utf-8")
        return {
            "success": True,
            "path": str(target.relative_to(self.root)),
            "replaced": count if replace_all else 1,
        }

    def make_directory(self, path: str) -> Dict[str, Any]:
        target = self._resolve_path(path)
        target.mkdir(parents=True, exist_ok=True)
        return {"success": True, "path": str(target.relative_to(self.root)), "created": True}

    def delete_path(self, path: str, recursive: bool = False) -> Dict[str, Any]:
        target = self._resolve_path(path)
        if not target.exists():
            return {"success": False, "error": "Path not found"}

        if target.is_dir():
            if recursive:
                shutil.rmtree(target)
            else:
                target.rmdir()
        else:
            target.unlink()

        return {"success": True, "path": str(target.relative_to(self.root)), "deleted": True}

    def python_check(self, path: str) -> Dict[str, Any]:
        target = self._resolve_path(path)
        if not target.exists() or not target.is_file():
            return {"success": False, "error": "File not found"}

        result = self._run_process(
            [sys.executable, "-m", "py_compile", str(target)],
            cwd=self.root,
            timeout_sec=20,
        )
        if result["success"]:
            result["output"] = "Syntax check passed"
        result["path"] = str(target.relative_to(self.root))
        return result

    def run_contract(self, path: str, class_name: str = "", timeout_sec: int = 25) -> Dict[str, Any]:
        target = self._resolve_path(path)
        if not target.exists() or not target.is_file():
            return {"success": False, "error": "Contract file not found"}

        source = self._read_text(target)
        resolved_class = class_name.strip() or _extract_contract_class_name(source)
        if not resolved_class:
            return {"success": False, "error": "No class ending with 'Contract' found"}

        result = self._run_process(
            [sys.executable, str(self.runner_file), str(target), resolved_class],
            cwd=self.root,
            timeout_sec=timeout_sec,
        )
        healthy = _looks_contract_healthy(result["exit_code"], result["timed_out"], result["output"])
        result.update(
            {
                "path": str(target.relative_to(self.root)),
                "class_name": resolved_class,
                "healthy": healthy,
                "success": healthy,
            }
        )
        return result

    def sandbox_run(self, command: str, cwd: str = ".", timeout_sec: int = 30) -> Dict[str, Any]:
        if not command.strip():
            return {"success": False, "error": "sandbox_run requires 'command'"}
        target_cwd = self._resolve_cwd(cwd)
        result = self._run_process(command, cwd=target_cwd, timeout_sec=timeout_sec, shell=True)
        result["command"] = command
        return result

    def sandbox_python(self, code: str, cwd: str = ".", timeout_sec: int = 20) -> Dict[str, Any]:
        if not code.strip():
            return {"success": False, "error": "sandbox_python requires 'code'"}

        target_cwd = self._resolve_cwd(cwd)
        with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False, encoding="utf-8") as handle:
            handle.write(code)
            temp_name = handle.name

        try:
            result = self._run_process(
                [sys.executable, temp_name],
                cwd=target_cwd,
                timeout_sec=timeout_sec,
            )
        finally:
            Path(temp_name).unlink(missing_ok=True)

        result["code_preview"] = _truncate_text(code, limit=2000)
        return result


WeatherServiceManager = WorkspaceServiceManager


weather_services = {
    "get_weather": {
        "name": "get_weather",
        "description": "Return a tiny weather forecast.",
        "parameters": {
            "type": "object",
            "properties": {
                "location": {"type": "string"}
            },
            "required": ["location"],
            "additionalProperties": False,
        },
    },
    "repo_tree": {
        "name": "repo_tree",
        "description": "Show a trimmed tree view of the repository rooted at the workspace.",
        "parameters": {
            "type": "object",
            "properties": {
                "max_entries": {"type": "integer", "minimum": 1, "maximum": 1000, "default": 250}
            },
            "additionalProperties": False,
        },
    },
    "list_files": {
        "name": "list_files",
        "description": "List repository files or directories relative to the workspace root. Accepts pattern, path, or glob.",
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "default": "**/*"},
                "path": {"type": "string"},
                "glob": {"type": "string"},
                "recursive": {"type": "boolean", "default": True},
                "max_results": {"type": "integer", "minimum": 1, "maximum": 1000, "default": 200}
            },
            "additionalProperties": False,
        },
    },
    "grep_repo": {
        "name": "grep_repo",
        "description": "Search the entire repository for matching text or regex patterns.",
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string"},
                "path": {"type": "string"},
                "glob": {"type": "string", "default": "**/*"},
                "max_results": {"type": "integer", "minimum": 1, "maximum": 1000, "default": 200},
                "case_sensitive": {"type": "boolean", "default": False},
                "output_type": {"type": "string", "enum": ["matches", "files"], "default": "matches"}
            },
            "required": ["pattern"],
            "additionalProperties": False,
        },
    },
    "read_file": {
        "name": "read_file",
        "description": "Read a file from the repository with numbered lines.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "file_path": {"type": "string"},
                "start_line": {"type": "integer", "minimum": 1, "default": 1},
                "end_line": {"type": "integer", "minimum": 1, "default": 240}
            },
            "anyOf": [
                {"required": ["path"]},
                {"required": ["file_path"]}
            ],
            "additionalProperties": False,
        },
    },
    "write_file": {
        "name": "write_file",
        "description": "Create or replace a repository file. Parent directories are created automatically.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"}
            },
            "required": ["path", "content"],
            "additionalProperties": False,
        },
    },
    "patch_file": {
        "name": "patch_file",
        "description": "Replace text inside a repository file, once or everywhere.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "old": {"type": "string"},
                "new": {"type": "string"},
                "replace_all": {"type": "boolean", "default": False}
            },
            "required": ["path", "old", "new"],
            "additionalProperties": False,
        },
    },
    "make_directory": {
        "name": "make_directory",
        "description": "Create a directory inside the repository.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"}
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    },
    "delete_path": {
        "name": "delete_path",
        "description": "Delete a file or directory inside the repository. Directories require recursive=true when not empty.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "recursive": {"type": "boolean", "default": False}
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    },
    "python_check": {
        "name": "python_check",
        "description": "Run py_compile on a repository Python file.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"}
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    },
    "run_contract": {
        "name": "run_contract",
        "description": "Execute a Mint contract file through harness/_runner.py and report whether the run looks healthy.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "class_name": {"type": "string", "default": ""},
                "timeout_sec": {"type": "integer", "minimum": 1, "maximum": 600, "default": 25}
            },
            "required": ["path"],
            "additionalProperties": False,
        },
    },
    "sandbox_run": {
        "name": "sandbox_run",
        "description": "Run a shell command inside the repository root or a subdirectory. Use this to run tests, scripts, or entry points.",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string"},
                "cwd": {"type": "string", "default": "."},
                "timeout_sec": {"type": "integer", "minimum": 1, "maximum": 600, "default": 30}
            },
            "required": ["command"],
            "additionalProperties": False,
        },
    },
    "sandbox_python": {
        "name": "sandbox_python",
        "description": "Execute a short Python snippet inside the repository and return stdout or stderr.",
        "parameters": {
            "type": "object",
            "properties": {
                "code": {"type": "string"},
                "cwd": {"type": "string", "default": "."},
                "timeout_sec": {"type": "integer", "minimum": 1, "maximum": 600, "default": 20}
            },
            "required": ["code"],
            "additionalProperties": False,
        },
    },
}


weather_implementations = {
    "get_weather": lambda manager: manager.get_weather,
    "repo_tree": lambda manager: manager.repo_tree,
    "list_files": lambda manager: manager.list_files,
    "grep_repo": lambda manager: manager.grep_repo,
    "read_file": lambda manager: manager.read_file,
    "write_file": lambda manager: manager.write_file,
    "patch_file": lambda manager: manager.patch_file,
    "make_directory": lambda manager: manager.make_directory,
    "delete_path": lambda manager: manager.delete_path,
    "python_check": lambda manager: manager.python_check,
    "run_contract": lambda manager: manager.run_contract,
    "sandbox_run": lambda manager: manager.sandbox_run,
    "sandbox_python": lambda manager: manager.sandbox_python,
}