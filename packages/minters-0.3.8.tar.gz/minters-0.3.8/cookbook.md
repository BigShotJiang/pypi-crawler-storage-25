# Capital Harness Cookbook

A practical guide to writing trading contracts with the Capital.com harness.

## Quick Start

The harness provides a `CapitalClient` that exposes trading primitives. Every contract lives in its own directory under `contracts/` and must implement a `run(client)` function.

```python
from harness.barn.trade.capital import CapitalClient

def run(client: CapitalClient):
    # Your trading logic here
    pass
```

## Core Client Methods

### Account & Session

| Method | Purpose |
|--------|---------|
| `client.session_id` | Active session identifier |
| `client.account_id` | Current account ID |

### Orders & Positions

| Method | Purpose | Example |
|--------|---------|---------|
| `client.buy(epic, size, stop=None, limit=None)` | Open long position | `client.buy("ETHUSD", 0.5, stop=1800)` |
| `client.sell(epic, size, stop=None, limit=None)` | Open short position | `client.sell("ETHUSD", 0.3, stop=2200)` |
| `client.position(direction, epic, size, ...)` | Directional position | `client.position("SELL", "BTCUSD", 0.1)` |
| `client.close(epic)` | Close all positions for epic | `client.close("ETHUSD")` |

### Market Data

| Method | Returns |
|--------|---------|
| `client.market_details(epic)` | Instrument metadata, margins, trading hours |
| `client.price(epic)` | Current bid/ask/change |
| `client.ohlc(epic, resolution, limit)` | OHLC candles (HOUR, DAY, etc) |
| `client.prices(epic, qty)` | Raw price series for calculations |

### Economic Data (FRED)

```python
from harness.barn.data.fred import FredClient

fred = FredClient()
series = fred.get_series("DGS10", limit=30)  # 10-Year Treasury
slope = fred.calculate_slope(series, days=30)
```

## Contract Anatomy

A robust contract typically has three phases:

### 1. Setup & Data Gathering
```python
def run(client: CapitalClient):
    epic = "ETHUSD"
    
    # Fetch market context
    details = client.market_details(epic)
    current = client.price(epic)
    
    # Fetch historical data
    hourly = client.ohlc(epic, resolution="HOUR", limit=50)
    daily = client.ohlc(epic, resolution="DAY", limit=30)
```

### 2. Analysis & Signal Generation
```python
    # Calculate technicals
    closes = [c["close"] for c in daily["prices"]]
    sma20 = sum(closes[-20:]) / 20
    sma50 = sum(closes[-50:]) / 50 if len(closes) >= 50 else sma20
    
    # Macro context (optional)
    fred = FredClient()
    dgs10 = fred.get_series("DGS10", limit=30)
    dgs2 = fred.get_series("DGS2", limit=30)
    yield_spread = dgs10[-1]["value"] - dgs2[-1]["value"]
```

### 3. Execution & Risk Management
```python
    # Position sizing
    size = calculate_size(client, epic, risk_percent=0.02)
    
    # Entry with stops
    if current["bid"] > sma20:
        stop = current["bid"] * 0.95  # 5% stop
        client.buy(epic, size=size, stop=round(stop, 2))
```

## Pattern Library

### Pattern: Multi-Timeframe Analysis
```python
# Check trend on daily, entry on hourly
daily_trend = calculate_sma(daily_closes, 20)
hourly_pullback = price < calculate_sma(hourly_closes, 20)

if daily_trend == "UP" and hourly_pullback:
    client.buy(epic, size)
```

### Pattern: Volatility-Based Sizing
```python
def atr_sizing(closes, highs, lows, period=14):
    atr = calculate_atr(highs, lows, closes, period)
    risk_per_unit = atr * 2  # 2x ATR stop
    account_risk = account_value * 0.01  # 1% risk
    return account_risk / risk_per_unit
```

### Pattern: Macro Filter
```python
def check_yield_regime():
    """Only trade when yield curve is normal (10Y > 2Y)"""
    fred = FredClient()
    dgs10 = fred.get_series("DGS10", limit=5)
    dgs2 = fred.get_series("DGS2", limit=5)
    return dgs10[-1]["value"] > dgs2[-1]["value"]

if check_yield_regime():
    # Execute strategy
    pass
```

### Pattern: Kelly Criterion Sizing
```python
def kelly_size(win_rate, avg_win, avg_loss):
    """f* = (bp - q) / b where b = win/loss, p = win rate, q = loss rate"""
    if avg_loss == 0:
        return 0
    kelly = (win_rate * avg_win - (1 - win_rate) * avg_loss) / avg_win
    return max(0, kelly * 0.25)  # Quarter Kelly for safety
```

## Risk Management Checklist

- [ ] Always set stop losses based on volatility (ATR or percentage)
- [ ] Size positions to risk 1-2% of account per trade
- [ ] Check macro conditions before directional trades
- [ ] Verify market is open (`details["tradingHours"]`)
- [ ] Use limit orders in volatile conditions
- [ ] Close positions before major events if unsure

## Advanced: Multi-Instrument Contracts

For pairs trading or basket strategies:

```python
def run(client: CapitalClient):
    # Fetch correlated assets
    gold = client.ohlc("GOLD", "DAY", 30)
    silver = client.ohlc("SILVER", "DAY", 30)
    
    # Calculate ratio
    ratio = gold_close / silver_close
    z_score = (ratio - mean(ratio)) / stdev(ratio)
    
    # Mean reversion
    if z_score > 2:
        client.sell("GOLD", size)
        client.buy("SILVER", size * gold_close / silver_close)
```

## Testing Contracts

Use the runner to test before deployment:

```bash
python harness/_runner.py contracts/your_contract/contract.py
```

Or programmatically:

```python
from harness.barn.trade.capital import CapitalClient
from contracts.your_contract.contract import run

client = CapitalClient(session_id="test")
run(client)
```

## Reference: Full Featured Example

See `contracts/bitcoin/contract.py` for:
- FRED macro integration
- Multiple timeframe analysis
- ATR-based position sizing
- Market regime detection

See `contracts/gold/contract.py` for:
- Correlation analysis
- Kelly criterion sizing
- Sophisticated entry logic

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "Market closed" | Check `market_details()["tradingHours"]` |
| "Insufficient funds" | Reduce size or check margin requirements |
| "Price not found" | Verify epic symbol format |
| FRED data missing | Check series ID at fred.stlouisfed.org |
