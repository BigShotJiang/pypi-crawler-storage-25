import asyncio
import math
import numpy as np
import pandas as pd
from datetime import datetime, timezone
import os
from dotenv import load_dotenv, find_dotenv
from fredapi import Fred

# your existing harness (kept for live execution)
from harness import market_buy, market_sell, get_account_snapshot

load_dotenv(find_dotenv())

class BitcoinContractV2:
    """
    FRED-powered BTC predictor:
    - Uses CBBTCUSD from FRED (Coinbase daily)
    - Adds macro features: DXY, real yields, VIX
    - Multi-scale EMAs 36/54/89/150 (Wiley 2025)
    """
    symbol = "BTCUSDm"
    lookback = 250
    threshold_prob = 0.60
    min_edge = 0.008

    def __init__(self):
        self.fred = Fred(api_key=os.getenv('FRED_API_KEY'))
        self._cache = None

    async def get_features(self, use_fred=True):
        if use_fred:
            # Pull from FRED – runs in thread to avoid blocking
            loop = asyncio.get_event_loop()
            def _fetch():
                btc = self.fred.get_series('CBBTCUSD', observation_start='2020-01-01')
                dxy = self.fred.get_series('DTWEXBGS', observation_start='2020-01-01')
                tips = self.fred.get_series('DFII10', observation_start='2020-01-01')
                vix = self.fred.get_series('VIXCLS', observation_start='2020-01-01')

                df = pd.DataFrame({
                    'close': btc,
                    'dxy': dxy,
                    'real_yield': tips,
                    'vix': vix
                }).dropna()
                return df

            df = await loop.run_in_executor(None, _fetch)
        else:
            # fallback to harness
            from harness import get_historical_ohlc
            data = await get_historical_ohlc(self.symbol, timeframe="1h")
            df = pd.DataFrame(data)
            df['close'] = pd.to_numeric(df['close'])

        df = df.dropna(subset=['close']).copy()
        df['log_ret'] = np.log(df['close'] / df['close'].shift(1))

        # multi-scale EMAs
        for w in [36, 54, 89, 150]:
            df[f'ema{w}'] = df['close'].ewm(span=w, adjust=False).mean()

        # volatility clustering
        df['vol'] = df['log_ret'].ewm(span=24).std()
        df['vol_ewma'] = df['vol'].ewm(alpha=0.06).mean()

        # z-score
        df['zscore'] = (df['close'] - df['ema89']) / (df['close'].rolling(89).std() + 1e-9)

        # RSI
        delta = df['close'].diff()
        up = delta.clip(lower=0).ewm(span=14).mean()
        down = -delta.clip(upper=0).ewm(span=14).mean()
        df['rsi'] = 100 - 100 / (1 + up/(down + 1e-9))

        # MACRO features from FRED
        if 'dxy' in df.columns:
            df['dxy_impact'] = -0.5 * df['dxy'].pct_change()
            df['yield_impact'] = -0.7 * df['real_yield'].diff()
            df['risk_off'] = (df['vix'] > 25).astype(int)

        self._cache = df.dropna()
        return self._cache.tail(30)

    async def predict_distribution(self):
        df = await self.get_features()
        if df is None or len(df) < 10:
            return None

        S0 = float(df['close'].iloc[-1])
        ret = df['log_ret'].values

        mu_mom = float(np.nanmean(ret[-24:]))
        z = float(df['zscore'].iloc[-1])
        vol_now = float(df['vol'].iloc[-1])
        mu_mr = -0.15 * z * vol_now

        rsi = float(df['rsi'].iloc[-1])
        gate = 1.0 / (1.0 + math.exp(-(rsi - 50.0) / 10.0))

        # Add macro adjustment if available
        macro_adj = 0
        if 'dxy_impact' in df.columns:
            macro_adj = float(df['dxy_impact'].iloc[-1] + df['yield_impact'].iloc[-1])

        mu = gate * mu_mom + (1.0 - gate) * mu_mr + macro_adj

        sigma_1h = float(df['vol_ewma'].iloc[-1])
        sigma_24h = sigma_1h * math.sqrt(24)

        t = 24.0
        expected_log = math.log(S0) + (mu - 0.5 * sigma_1h**2) * t
        expected_price = math.exp(expected_log)

        target_log = math.log(S0 * 1.015)
        z_up = (target_log - expected_log) / (sigma_24h + 1e-9)
        prob_up = 0.5 * (1.0 - math.erf(z_up / math.sqrt(2.0)))

        return {
            'current': S0,
            'expected': expected_price,
            'sigma_24h': sigma_24h,
            'prob_up': prob_up,
            'prob_down': 1.0 - prob_up,
            'mu': mu,
            'gate': gate,
            'rsi': rsi,
            'zscore': z,
            'macro_adj': macro_adj
        }

    async def backtest(self):
        """Walk-forward test on FRED data"""
        print("\n=== BITCOIN BACKTEST (FRED) ===")
        df = await self.get_features()
        full_df = self._cache

        # Simple strategy: trade when prob > threshold
        full_df['pred_mu'] = full_df['log_ret'].rolling(24).mean()
        full_df['signal'] = np.where(full_df['pred_mu'] > 0, 1, -1)
        full_df['strat_ret'] = full_df['signal'].shift(1) * full_df['log_ret']

        total_bh = np.exp(full_df['log_ret'].sum()) - 1
        total_strat = np.exp(full_df['strat_ret'].sum()) - 1
        sharpe = full_df['strat_ret'].mean() / full_df['strat_ret'].std() * np.sqrt(365)
        hit = (full_df['strat_ret'] > 0).mean()

        print(f"Period: {full_df.index[0].date()} to {full_df.index[-1].date()}")
        print(f"BTC buy-hold: {total_bh:.1%}")
        print(f"Strategy: {total_strat:.1%}")
        print(f"Sharpe: {sharpe:.2f} | Hit rate: {hit:.1%}")
        print(f"Current BTC: ${full_df['close'].iloc[-1]:,.0f}")
        print(f"Real yield: {full_df['real_yield'].iloc[-1]:.2f}% | DXY: {full_df['dxy'].iloc[-1]:.1f}")

    async def run(self):
        print(f"[{datetime.now(timezone.utc).isoformat()}] Starting BitcoinContractV2 (FRED)")
        while True:
            try:
                snap = await get_account_snapshot()
                balance = float(snap.get("balance", 0))
                if balance < 1000:
                    print(f"Insufficient balance: {balance}")
                    break

                pred = await self.predict_distribution()
                if not pred:
                    await asyncio.sleep(60)
                    continue

                current = pred['current']
                expected = pred['expected']
                edge = (expected - current) / current
                variance = pred['sigma_24h'] ** 2 + 1e-6
                kelly = max(0.0, min(0.25, abs(edge) / variance))
                size = max(0.01, kelly * 0.4)

                print(f"Price: {current:.2f} | Exp24h: {expected:.2f} ({edge:+.2%}) | "
                      f"σ: {pred['sigma_24h']:.3f} | P_up: {pred['prob_up']:.2f} | "
                      f"gate: {pred['gate']:.2f} | RSI: {pred['rsi']:.1f} | "
                      f"macro: {pred['macro_adj']:+.4f} | size: {size:.3f}")

                if pred['prob_up'] > self.threshold_prob and edge > self.min_edge:
                    print("→ BULLISH")
                    await market_buy(self.symbol, round(size, 3))
                elif pred['prob_down'] > self.threshold_prob and edge < -self.min_edge:
                    print("→ BEARISH")
                    await market_sell(self.symbol, round(size, 3))
                else:
                    print("→ NEUTRAL")

            except Exception as e:
                print(f"Error: {e}")
                traceback.print_exc()

            await asyncio.sleep(300)
            print("\n---\n")

if __name__ == "__main__":
    import sys
    import traceback
    contract = BitcoinContractV2()
    if len(sys.argv) > 1 and sys.argv[1] == 'backtest':
        asyncio.run(contract.backtest())
    else:
        asyncio.run(contract.run())