import asyncio
import statistics
from harness.barn.trade.capital import CapitalClient
from harness.barn.data.fred import FredClient


class EtherContract:
    """
    Enhanced Ethereum trading contract with macro-aware positioning,
    multi-timeframe analysis, and Kelly-based sizing.
    """

    epic = "EthereumUSD"
    symbol = "ETHUSDm"
    base_lot = 0.1

    def __init__(self):
        self.client = CapitalClient()
        self.fred = FredClient()

    def calculate_atr(self, highs, lows, closes, period=14):
        """Calculate Average True Range for volatility-based sizing."""
        if len(closes) < period + 1:
            return 0
        
        trs = []
        for i in range(1, len(closes)):
            high = highs[i]
            low = lows[i]
            prev_close = closes[i-1]
            
            tr = max(
                high - low,
                abs(high - prev_close),
                abs(low - prev_close)
            )
            trs.append(tr)
        
        if len(trs) < period:
            return sum(trs) / len(trs) if trs else 0
        
        return sum(trs[-period:]) / period

    def calculate_kelly_size(self, win_rate=0.55, avg_win=1.2, avg_loss=1.0):
        """
        Kelly Criterion: f* = (bp - q) / b
        Using conservative quarter-Kelly for safety.
        """
        if avg_loss == 0 or avg_win == 0:
            return self.base_lot
        
        kelly = (win_rate * avg_win - (1 - win_rate) * avg_loss) / avg_win
        quarter_kelly = max(0, kelly * 0.25)
        return self.base_lot * (1 + quarter_kelly * 10)  # Scale to lot size

    def check_yield_regime(self):
        """
        Check if yield curve is normal (10Y > 2Y).
        Risk-off when inverted—reduce size or don't trade.
        """
        try:
            dgs10 = self.fred.get_series("DGS10", limit=5)
            dgs2 = self.fred.get_series("DGS2", limit=5)
            
            if not dgs10 or not dgs2:
                return True  # Default to normal if data missing
            
            ten_year = dgs10[-1]["value"]
            two_year = dgs2[-1]["value"]
            
            return ten_year > two_year
        except Exception:
            return True  # Default to normal on error

    def analyze_trend(self, ohlc_data):
        """
        Multi-timeframe trend analysis.
        Returns: trend direction, strength, volatility regime
        """
        if not ohlc_data or "prices" not in ohlc_data:
            return "NEUTRAL", 0, "LOW"
        
        prices = ohlc_data["prices"]
        if len(prices) < 20:
            return "NEUTRAL", 0, "LOW"
        
        closes = [p["close"] for p in prices]
        highs = [p["high"] for p in prices]
        lows = [p["low"] for p in prices]
        
        # Moving averages
        sma20 = sum(closes[-20:]) / 20
        sma50 = sum(closes[-50:]) / 50 if len(closes) >= 50 else sma20
        
        # Trend direction
        current = closes[-1]
        if current > sma20 > sma50:
            trend = "UP"
        elif current < sma20 < sma50:
            trend = "DOWN"
        else:
            trend = "NEUTRAL"
        
        # Trend strength (distance from SMA)
        strength = abs(current - sma20) / sma20 if sma20 else 0
        
        # Volatility regime via ATR
        atr = self.calculate_atr(highs, lows, closes, 14)
        atr_pct = atr / current if current else 0
        
        if atr_pct > 0.04:
            vol_regime = "HIGH"
        elif atr_pct > 0.02:
            vol_regime = "MEDIUM"
        else:
            vol_regime = "LOW"
        
        return trend, strength, vol_regime

    def calculate_position_size(self, atr, current_price, vol_regime):
        """
        Size positions based on volatility and Kelly criterion.
        Risk 1-2% of account per trade, scaled by regime.
        """
        base_size = self.base_lot
        
        # Volatility scaling
        vol_scalar = 1.0
        if vol_regime == "HIGH":
            vol_scalar = 0.5  # Reduce size in high vol
        elif vol_regime == "MEDIUM":
            vol_scalar = 0.75
        
        # Kelly adjustment
        kelly_size = self.calculate_kelly_size()
        
        # ATR-based stop distance
        if atr and current_price:
            stop_distance = atr * 2  # 2x ATR stop
            risk_scalar = min(1.0, 0.02 / (stop_distance / current_price))
        else:
            risk_scalar = 1.0
        
        final_size = base_size * vol_scalar * (kelly_size / self.base_lot) * risk_scalar
        return round(max(self.base_lot * 0.5, min(final_size, self.base_lot * 2)), 2)

    async def run(self):
        """
        Main execution loop with macro-aware positioning.
        """
        print(f"[EtherContract] Starting analysis for {self.epic}")
        
        # Check macro environment
        yield_normal = self.check_yield_regime()
        if not yield_normal:
            print("[EtherContract] Warning: Inverted yield curve - reducing exposure")
        
        # Fetch market data
        try:
            current = self.client.price(self.epic)
            daily = self.client.ohlc(self.epic, resolution="DAY", limit=50)
            hourly = self.client.ohlc(self.epic, resolution="HOUR", limit=100)
        except Exception as e:
            print(f"[EtherContract] Error fetching market data: {e}")
            return
        
        if not current or not daily or not hourly:
            print("[EtherContract] Insufficient data for analysis")
            return
        
        current_price = current.get("bid", 0)
        
        # Multi-timeframe analysis
        daily_trend, daily_strength, daily_vol = self.analyze_trend(daily)
        hourly_trend, hourly_strength, hourly_vol = self.analyze_trend(hourly)
        
        print(f"[EtherContract] Daily trend: {daily_trend} (strength: {daily_strength:.2%}, vol: {daily_vol})")
        print(f"[EtherContract] Hourly trend: {hourly_trend} (strength: {hourly_strength:.2%}, vol: {hourly_vol})")
        
        # Calculate volatility metrics
        prices = daily.get("prices", [])
        if len(prices) >= 20:
            closes = [p["close"] for p in prices]
            highs = [p["high"] for p in prices]
            lows = [p["low"] for p in prices]
            atr = self.calculate_atr(highs, lows, closes, 14)
        else:
            atr = current_price * 0.03  # Default 3% ATR
        
        print(f"[EtherContract] ATR(14): {atr:.2f} ({atr/current_price:.2%} of price)")
        
        # Determine position size
        vol_regime = "HIGH" if not yield_normal else daily_vol
        size = self.calculate_position_size(atr, current_price, vol_regime)
        
        if not yield_normal:
            size = size * 0.5  # Halve size in risky macro
        
        print(f"[EtherContract] Calculated position size: {size}")
        
        # Entry logic: trend following with pullback entry
        entry_signal = None
        stop_price = None
        limit_price = None
        
        if daily_trend == "UP" and hourly_trend == "UP":
            # Strong uptrend - buy with momentum
            entry_signal = "BUY"
            stop_price = current_price - (atr * 2)
            limit_price = current_price + (atr * 3)
            print(f"[EtherContract] Signal: BUY (trend following)")
            
        elif daily_trend == "UP" and hourly_trend == "NEUTRAL":
            # Daily up, hourly consolidating - wait for breakout or buy small
            entry_signal = "BUY"
            size = size * 0.7
            stop_price = current_price - (atr * 1.5)
            print(f"[EtherContract] Signal: BUY (cautious, hourly consolidation)")
            
        elif daily_trend == "DOWN" and hourly_trend == "DOWN":
            # Downtrend - short or stay out
            entry_signal = "SELL"
            stop_price = current_price + (atr * 2)
            limit_price = current_price - (atr * 3)
            print(f"[EtherContract] Signal: SELL (downtrend)")
            
        elif daily_trend == "NEUTRAL" and hourly_strength > 0.02:
            # Range bound but hourly momentum
            if hourly_trend == "UP":
                entry_signal = "BUY"
                stop_price = current_price - (atr * 1.5)
                size = size * 0.6
                print(f"[EtherContract] Signal: BUY (hourly momentum in range)")
            elif hourly_trend == "DOWN":
                entry_signal = "SELL"
                stop_price = current_price + (atr * 1.5)
                size = size * 0.6
                print(f"[EtherContract] Signal: SELL (hourly momentum in range)")
        
        else:
            print(f"[EtherContract] No clear signal - staying out")
            return
        
        # Execute order
        if entry_signal and size > 0:
            try:
                if entry_signal == "BUY":
                    order = self.client.buy(
                        self.epic, 
                        size=size,
                        stop=round(stop_price, 2) if stop_price else None,
                        limit=round(limit_price, 2) if limit_price else None
                    )
                else:
                    order = self.client.sell(
                        self.epic,
                        size=size,
                        stop=round(stop_price, 2) if stop_price else None,
                        limit=round(limit_price, 2) if limit_price else None
                    )
                
                print(f"[EtherContract] Order executed: {order}")
                
            except Exception as e:
                print(f"[EtherContract] Order failed: {e}")
        
        print("[EtherContract] Execution complete")


def run(client=None):
    """
    Entry point for harness runner.
    Compatible with both CapitalClient injection and standalone.
    """
    contract = EtherContract()
    if client:
        contract.client = client
    asyncio.run(contract.run())


if __name__ == "__main__":
    run()
