ALTER TABLE vulnerabilities ADD COLUMN branch_status TEXT;
UPDATE vulnerabilities SET branch_status = 'fixed' WHERE fixed_in_branch = 1;
