"""Read tools — orientation, analysis, and deterministic assessment.

All read tools follow: storage.read() → call core function → wrap in
typed response. No mutations, no side effects.
"""

from __future__ import annotations

from typing import Any

from compos.core.graph import (
    ChangeType,
)
from compos.core.graph import (
    evaluate_proposed_change as core_evaluate,
)
from compos.core.graph import (
    get_blast_radius as core_blast_radius,
)
from compos.core.graph import (
    get_component_context as core_context,
)
from compos.core.graph import (
    get_constraints_for_components as core_constraints,
)
from compos.mcp.responses import (
    AffectedComponentDetail,
    BlastRadiusResponse,
    ComponentContextResult,
    ConstraintConflictDetail,
    ConstraintsResult,
    CycleDetail,
    ErrorDetail,
    EvaluateChangeResult,
    GetObjectResult,
    ListObjectsResult,
    SnapshotResult,
    SPOFDetail,
    SystemMapResult,
    VersionListResult,
)
from compos.mcp.server import get_project_root, mcp
from compos.schema.models import (
    ConstraintStatus,
    DecisionStatus,
    ObjectStatus,
    Provenance,
    ProvenanceSource,
    Relationship,
    RiskStatus,
)
from compos.storage import local as storage

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _obj_to_dict(obj: Any) -> dict[str, Any]:
    result: dict[str, Any] = obj.model_dump(by_alias=True)
    return result


def _is_removed_component(obj: Any) -> bool:
    return getattr(obj, "status", None) == ObjectStatus.REMOVED


def _is_removed_relationship(obj: Any) -> bool:
    return getattr(obj, "status", None) == ObjectStatus.REMOVED


def _is_removed_constraint(obj: Any) -> bool:
    return getattr(obj, "status", None) == ConstraintStatus.REMOVED


def _is_removed_risk(obj: Any) -> bool:
    return getattr(obj, "status", None) == RiskStatus.REMOVED


def _is_removed_decision(obj: Any) -> bool:
    return getattr(obj, "status", None) == DecisionStatus.REMOVED


# ---------------------------------------------------------------------------
# Orientation tools
# ---------------------------------------------------------------------------


@mcp.tool(
    description=(
        "Get a single component by ID with all its fields, including provenance."
    ),
)
def get_component(
    id: str,
    include_removed: bool = False,
) -> GetObjectResult:
    root = get_project_root()
    current_map = storage.read(root)
    for comp in current_map.components:
        if comp.id == id:
            if not include_removed and _is_removed_component(comp):
                break
            return GetObjectResult(
                success=True,
                map_version=current_map.map_version,
                object=_obj_to_dict(comp),
            )
    return GetObjectResult(
        success=False,
        map_version=current_map.map_version,
        object={},
        errors=(ErrorDetail(stage="not_found", message=f"component '{id}' not found"),),
    )


@mcp.tool(
    description=("Get all relationships where a component is source or target."),
)
def get_relationships_for_component(
    component_id: str,
    include_removed: bool = False,
) -> ListObjectsResult:
    root = get_project_root()
    current_map = storage.read(root)
    rels = []
    for rel in current_map.relationships:
        if not include_removed and _is_removed_relationship(rel):
            continue
        if rel.source == component_id or rel.target == component_id:
            rels.append(_obj_to_dict(rel))
    return ListObjectsResult(
        success=True,
        map_version=current_map.map_version,
        objects=tuple(rels),
        total_count=len(rels),
    )


@mcp.tool(
    description=("Get all decisions that affected a specific component."),
)
def get_decisions_for_component(
    component_id: str,
    include_removed: bool = False,
) -> ListObjectsResult:
    root = get_project_root()
    current_map = storage.read(root)
    decs = []
    for dec in current_map.decisions:
        if not include_removed and _is_removed_decision(dec):
            continue
        if component_id in dec.components_affected:
            decs.append(_obj_to_dict(dec))
    return ListObjectsResult(
        success=True,
        map_version=current_map.map_version,
        objects=tuple(decs),
        total_count=len(decs),
    )


@mcp.tool(
    description=(
        "List all components in the map (IDs and names). "
        "Start here when you don't know which components exist."
    ),
)
def list_components(
    include_removed: bool = False,
) -> ListObjectsResult:
    root = get_project_root()
    current_map = storage.read(root)
    comps = []
    for comp in current_map.components:
        if not include_removed and _is_removed_component(comp):
            continue
        comps.append(_obj_to_dict(comp))
    return ListObjectsResult(
        success=True,
        map_version=current_map.map_version,
        objects=tuple(comps),
        total_count=len(comps),
    )


@mcp.tool(
    description=(
        "Get the full system map. Use sparingly — prefer targeted queries "
        "like get_component_context for most use cases."
    ),
)
def get_system_map(
    include_removed: bool = False,
) -> SystemMapResult:
    root = get_project_root()
    current_map = storage.read(root)

    def _filter(
        items: tuple[Any, ...],
        is_removed_fn: Any,
    ) -> tuple[dict[str, Any], ...]:
        if include_removed:
            return tuple(_obj_to_dict(o) for o in items)
        return tuple(_obj_to_dict(o) for o in items if not is_removed_fn(o))

    return SystemMapResult(
        success=True,
        map_version=current_map.map_version,
        schema_version=current_map.schema_version,
        generated_at=current_map.generated_at.isoformat(),
        components=_filter(current_map.components, _is_removed_component),
        relationships=_filter(current_map.relationships, _is_removed_relationship),
        constraints=_filter(current_map.constraints, _is_removed_constraint),
        risks=_filter(current_map.risks, _is_removed_risk),
        decisions=_filter(current_map.decisions, _is_removed_decision),
    )


# ---------------------------------------------------------------------------
# Deterministic analysis tools
# ---------------------------------------------------------------------------


@mcp.tool(
    description=(
        "Start here. Returns the subgraph around focal components: the "
        "components themselves, their direct neighbors, all connecting "
        "relationships, applicable constraints, active risks, and relevant "
        "decisions. Call this before modifying any component to understand "
        "the surrounding context. "
        "Accepts focal_component_ids, file_paths (resolved to components "
        "via longest-prefix match), or both."
    ),
)
def get_component_context(
    focal_component_ids: list[str] | None = None,
    file_paths: list[str] | None = None,
    include_removed: bool = False,
) -> ComponentContextResult:
    root = get_project_root()
    current_map = storage.read(root)

    # Resolve file_paths to component IDs
    merged_ids: list[str] = list(focal_component_ids or [])
    unresolved: tuple[str, ...] = ()
    if file_paths:
        from compos.mcp.resolve import resolve_file_paths

        resolved = resolve_file_paths(
            current_map, file_paths, include_removed=include_removed
        )
        unresolved = tuple(resolved.unresolved)
        # Merge without duplicates, preserving order
        seen = set(merged_ids)
        for cid in resolved.component_ids:
            if cid not in seen:
                seen.add(cid)
                merged_ids.append(cid)

    if not merged_ids:
        return ComponentContextResult(
            success=False,
            map_version=current_map.map_version,
            focal_components=(),
            neighbor_components=(),
            connecting_relationships=(),
            applicable_constraints=(),
            applicable_risks=(),
            applicable_decisions=(),
            unresolved_paths=unresolved,
            errors=(
                ErrorDetail(
                    stage="validation",
                    message="Provide focal_component_ids or file_paths",
                ),
            ),
        )

    try:
        ctx = core_context(
            current_map,
            merged_ids,
            include_removed=include_removed,
        )
    except KeyError as e:
        return ComponentContextResult(
            success=False,
            map_version=current_map.map_version,
            focal_components=(),
            neighbor_components=(),
            connecting_relationships=(),
            applicable_constraints=(),
            applicable_risks=(),
            applicable_decisions=(),
            unresolved_paths=unresolved,
            errors=(ErrorDetail(stage="not_found", message=str(e)),),
        )
    return ComponentContextResult(
        success=True,
        map_version=current_map.map_version,
        focal_components=tuple(_obj_to_dict(c) for c in ctx.focal_components),
        neighbor_components=tuple(_obj_to_dict(c) for c in ctx.neighbor_components),
        connecting_relationships=tuple(
            _obj_to_dict(r) for r in ctx.connecting_relationships
        ),
        applicable_constraints=tuple(
            _obj_to_dict(c) for c in ctx.applicable_constraints
        ),
        applicable_risks=tuple(_obj_to_dict(r) for r in ctx.applicable_risks),
        applicable_decisions=tuple(_obj_to_dict(d) for d in ctx.applicable_decisions),
        unresolved_paths=unresolved,
    )


@mcp.tool(
    description=(
        "Compute which components are affected by a change. "
        "change_type: 'modify' (downstream only), 'remove' (all directions), "
        "'replace' (downstream only). Returns affected components with "
        "hop distance, path, and relationship types. "
        "Accepts component_id or file_path (resolved to a single component)."
    ),
)
def get_blast_radius(
    component_id: str | None = None,
    file_path: str | None = None,
    change_type: str = "modify",
    max_hops: int | None = None,
    include_removed: bool = False,
) -> BlastRadiusResponse:
    root = get_project_root()
    current_map = storage.read(root)

    # Resolve file_path to component_id if needed
    unresolved: tuple[str, ...] = ()
    if component_id is None and file_path is not None:
        from compos.mcp.resolve import resolve_file_paths

        resolved = resolve_file_paths(
            current_map, [file_path], include_removed=include_removed
        )
        if not resolved.component_ids:
            return BlastRadiusResponse(
                success=False,
                map_version=current_map.map_version,
                source_component_id="",
                change_type=change_type,
                affected=(),
                unresolved_paths=(file_path,),
                errors=(
                    ErrorDetail(
                        stage="resolution",
                        message=f"file_path '{file_path}' did not match any component",
                    ),
                ),
            )
        if len(resolved.component_ids) > 1:
            return BlastRadiusResponse(
                success=False,
                map_version=current_map.map_version,
                source_component_id="",
                change_type=change_type,
                affected=(),
                errors=(
                    ErrorDetail(
                        stage="resolution",
                        message=(
                            f"file_path '{file_path}' matched multiple "
                            f"components: {resolved.component_ids}"
                        ),
                    ),
                ),
            )
        component_id = resolved.component_ids[0]
    elif component_id is None:
        return BlastRadiusResponse(
            success=False,
            map_version=current_map.map_version,
            source_component_id="",
            change_type=change_type,
            affected=(),
            errors=(
                ErrorDetail(
                    stage="validation",
                    message="Provide component_id or file_path",
                ),
            ),
        )

    try:
        ct = ChangeType(change_type)
        br = core_blast_radius(
            current_map,
            component_id,
            ct,
            include_removed=include_removed,
            max_hops=max_hops,
        )
    except (KeyError, ValueError) as e:
        return BlastRadiusResponse(
            success=False,
            map_version=current_map.map_version,
            source_component_id=component_id,
            change_type=change_type,
            affected=(),
            unresolved_paths=unresolved,
            errors=(ErrorDetail(stage="not_found", message=str(e)),),
        )
    return BlastRadiusResponse(
        success=True,
        map_version=current_map.map_version,
        source_component_id=component_id,
        change_type=change_type,
        affected=tuple(
            AffectedComponentDetail(
                component_id=a.component.id,
                component_name=a.component.name,
                hop_distance=a.hop_distance,
                path=a.path,
                relationship_types=tuple(str(rt) for rt in a.relationship_types),
            )
            for a in br.affected
        ),
        unresolved_paths=unresolved,
    )


@mcp.tool(
    description=(
        "Get all constraints that apply to the specified components. "
        "Returns constraints with their hardness and provenance. "
        "You decide how to interpret them. "
        "Accepts component_ids, file_paths (resolved to components "
        "via longest-prefix match), or both."
    ),
)
def get_constraints_for_components(
    component_ids: list[str] | None = None,
    file_paths: list[str] | None = None,
    include_removed: bool = False,
) -> ConstraintsResult:
    root = get_project_root()
    current_map = storage.read(root)

    # Resolve file_paths to component IDs
    merged_ids: list[str] = list(component_ids or [])
    unresolved: tuple[str, ...] = ()
    if file_paths:
        from compos.mcp.resolve import resolve_file_paths

        resolved = resolve_file_paths(
            current_map, file_paths, include_removed=include_removed
        )
        unresolved = tuple(resolved.unresolved)
        seen = set(merged_ids)
        for cid in resolved.component_ids:
            if cid not in seen:
                seen.add(cid)
                merged_ids.append(cid)

    if not merged_ids:
        return ConstraintsResult(
            success=False if not file_paths else True,
            map_version=current_map.map_version,
            constraints=(),
            unresolved_paths=unresolved,
            errors=(
                (
                    ErrorDetail(
                        stage="validation",
                        message="Provide component_ids or file_paths",
                    ),
                )
                if not file_paths
                else ()
            ),
        )

    constraints = core_constraints(
        current_map,
        merged_ids,
        include_removed=include_removed,
    )
    return ConstraintsResult(
        success=True,
        map_version=current_map.map_version,
        constraints=tuple(_obj_to_dict(c) for c in constraints),
        unresolved_paths=unresolved,
    )


@mcp.tool(
    description=(
        "Pre-flight check. Evaluate a hypothetical structural change against "
        "the current map. Detects cycles, single-points-of-failure, and "
        "constraint conflicts. Does NOT modify the map. "
        "Call this before implementing structural changes."
    ),
)
def evaluate_proposed_change(
    proposed_relationships: list[dict[str, Any]] | None = None,
    include_removed: bool = False,
) -> EvaluateChangeResult:
    root = get_project_root()
    current_map = storage.read(root)

    # Build Relationship objects from dicts
    rel_objects: list[Relationship] = []
    if proposed_relationships:
        from datetime import UTC, datetime

        prov = Provenance(
            source=ProvenanceSource.AI_ANNOTATED,
            tool="mcp",
            timestamp=datetime.now(UTC),
        )
        for r in proposed_relationships:
            try:
                rel = Relationship(
                    id=r["id"],
                    source=r["source"],
                    target=r["target"],
                    type=r["type"],
                    pattern=r["pattern"],
                    description=r.get("description", "proposed"),
                    status=ObjectStatus.CONFIRMED,
                    provenance=prov,
                    annotation_confidence=0.8,
                )
                rel_objects.append(rel)
            except Exception as e:
                return EvaluateChangeResult(
                    success=False,
                    map_version=current_map.map_version,
                    cycles=(),
                    spofs=(),
                    constraint_conflicts=(),
                    errors=(ErrorDetail(stage="validation", message=str(e)),),
                )

    eval_result = core_evaluate(
        current_map,
        proposed_relationships=rel_objects,
        include_removed=include_removed,
    )

    return EvaluateChangeResult(
        success=True,
        map_version=current_map.map_version,
        cycles=tuple(
            CycleDetail(
                component_ids=c.component_ids,
                relationship_ids=c.relationship_ids,
            )
            for c in eval_result.cycles
        ),
        spofs=tuple(
            SPOFDetail(
                component_id=s.component.id,
                component_name=s.component.name,
                dependent_count=s.dependent_count,
                synchronous_dependent_ids=tuple(d.id for d in s.synchronous_dependents),
                has_error_behavior=s.has_error_behavior,
            )
            for s in eval_result.spofs
        ),
        constraint_conflicts=tuple(
            ConstraintConflictDetail(
                constraint_id=cc.constraint.id,
                constraint_type=str(cc.constraint.type),
                description=cc.constraint.description,
                reason=cc.reason,
            )
            for cc in eval_result.constraint_conflicts
        ),
    )


# ---------------------------------------------------------------------------
# Version history tools
# ---------------------------------------------------------------------------


@mcp.tool(
    description=(
        "List all available map versions with metadata. "
        "Returns snapshot versions plus the current version, "
        "each with produced_by, component/relationship counts, and timestamp."
    ),
)
def list_versions() -> VersionListResult:
    root = get_project_root()
    current_map = storage.read(root)
    snapshot_versions = storage.list_snapshots(root)

    entries: list[dict[str, Any]] = []
    for v in snapshot_versions:
        snap = storage.read_snapshot(root, v)
        entries.append(
            {
                "version": snap.map_version,
                "produced_by": snap.produced_by,
                "generated_at": snap.generated_at.isoformat(),
                "component_count": len(snap.components),
                "relationship_count": len(snap.relationships),
            }
        )

    # Always include current version
    if current_map.map_version not in snapshot_versions:
        entries.append(
            {
                "version": current_map.map_version,
                "produced_by": current_map.produced_by,
                "generated_at": current_map.generated_at.isoformat(),
                "component_count": len(current_map.components),
                "relationship_count": len(current_map.relationships),
            }
        )

    entries.sort(key=lambda e: e["version"])

    return VersionListResult(
        success=True,
        current_version=current_map.map_version,
        versions=tuple(entries),
        total_count=len(entries),
    )


@mcp.tool(
    description=(
        "Retrieve a full map at a specific version. "
        "Omit version to get the current map. "
        "Use list_versions first to see available versions."
    ),
)
def get_snapshot(
    version: int | None = None,
) -> SnapshotResult:
    root = get_project_root()
    current_map = storage.read(root)

    if version is None or version == current_map.map_version:
        return SnapshotResult(
            success=True,
            map_version=current_map.map_version,
            map_data=current_map.model_dump(by_alias=True),
        )

    try:
        snap = storage.read_snapshot(root, version)
    except storage.SnapshotNotFoundError:
        return SnapshotResult(
            success=False,
            map_version=current_map.map_version,
            map_data={},
            errors=(
                ErrorDetail(
                    stage="not_found",
                    message=f"version {version} not found",
                ),
            ),
        )
    return SnapshotResult(
        success=True,
        map_version=snap.map_version,
        map_data=snap.model_dump(by_alias=True),
    )
