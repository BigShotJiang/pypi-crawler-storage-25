"""Resolve file paths to component IDs via longest-prefix matching."""

from __future__ import annotations

from dataclasses import dataclass

from compos.schema.models import ComposMap, ObjectStatus


@dataclass(frozen=True, slots=True)
class ResolvedPaths:
    component_ids: list[str]  # matched component IDs (deduplicated, preserving order)
    unresolved: list[str]  # input paths that matched no component


def resolve_file_paths(
    compos_map: ComposMap,
    file_paths: list[str],
    *,
    include_removed: bool = False,
) -> ResolvedPaths:
    """Map file paths to the most specific owning component.

    For each file_path, find the component whose ``paths`` field contains the
    longest prefix match.  A component path *p* matches if
    ``file_path == p`` or ``file_path.startswith(p)``.
    Longest prefix wins (most specific component).

    Returns deduplicated component IDs (preserving first-seen order) and any
    paths that matched no component.
    """
    # Build lookup: (prefix, component_id) sorted longest-first for fast match
    candidates: list[tuple[str, str]] = []
    for comp in compos_map.components:
        if not include_removed and comp.status == ObjectStatus.REMOVED:
            continue
        for p in comp.paths:
            candidates.append((p, comp.id))
    # Sort by prefix length descending so first match is longest
    candidates.sort(key=lambda pair: len(pair[0]), reverse=True)

    seen: set[str] = set()
    component_ids: list[str] = []
    unresolved: list[str] = []

    for fp in file_paths:
        matched = False
        for prefix, cid in candidates:
            if fp == prefix or fp.startswith(prefix):
                matched = True
                if cid not in seen:
                    seen.add(cid)
                    component_ids.append(cid)
                break
        if not matched:
            unresolved.append(fp)

    return ResolvedPaths(component_ids=component_ids, unresolved=unresolved)
