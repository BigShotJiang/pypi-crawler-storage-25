"""MCP package — Model Context Protocol server for Compos.

Exposes 24 tools to AI builders:
- 15 write tools: register/update/remove × 5 object types
- 9 deterministic read tools: orientation + graph analysis
"""

from compos.mcp.server import mcp

__all__ = ["mcp"]
