"""Entry point for running the Compos MCP server.

Usage:
    python -m compos.mcp
    uv run python -m compos.mcp
    uvx compos-mcp
"""

# Import tool modules so @mcp.tool() decorators register.
import compos.mcp.read_tools  # noqa: F401
import compos.mcp.write_tools  # noqa: F401
from compos.mcp import mcp


def main() -> None:
    """Run the Compos MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
