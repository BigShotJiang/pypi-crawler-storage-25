"""Write tools — register, update, remove for all 5 object types.

All tools accept flat parameters, construct schema objects internally,
and use hardcoded ai-annotated provenance. The AI builder never needs
to specify provenance, timestamps, or status fields.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from compos.core.merge_log import MergeLogEntry
from compos.core.write_pipeline import WriteResult
from compos.mcp.responses import (
    ErrorDetail,
    MergeDetail,
    RegisterResult,
    RemoveResult,
    UpdateResult,
)
from compos.mcp.server import execute_write, get_project_root, mcp
from compos.schema.models import (
    AlternativeConsidered,
    Component,
    Constraint,
    Decision,
    DecisionProvenance,
    DecisionProvenanceSource,
    ObjectStatus,
    Provenance,
    ProvenanceSource,
    Relationship,
    Risk,
)
from compos.storage import local as storage

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _now() -> datetime:
    return datetime.now(UTC)


def _provenance() -> Provenance:
    return Provenance(
        source=ProvenanceSource.AI_ANNOTATED,
        tool="mcp",
        timestamp=_now(),
    )


def _decision_provenance() -> DecisionProvenance:
    return DecisionProvenance(
        source=DecisionProvenanceSource.AI_ANNOTATED,
        tool="mcp",
        timestamp=_now(),
    )


def _to_register_result(
    result: WriteResult,
    object_id: str,
    provenance_dict: dict[str, Any],
) -> RegisterResult:
    """Translate WriteResult to RegisterResult."""
    if not result.success:
        errors = tuple(
            ErrorDetail(stage=e.stage, message=e.message) for e in result.errors
        )
        return RegisterResult(
            success=False,
            map_version=result.new_version or 0,
            object_id=object_id,
            provenance=provenance_dict,
            errors=errors,
        )
    return RegisterResult(
        success=True,
        map_version=result.new_version or 0,
        object_id=object_id,
        provenance=provenance_dict,
    )


def _to_update_result(
    result: WriteResult,
    object_id: str,
) -> UpdateResult:
    """Translate WriteResult to UpdateResult."""
    if not result.success:
        errors = tuple(
            ErrorDetail(stage=e.stage, message=e.message) for e in result.errors
        )
        return UpdateResult(
            success=False,
            map_version=result.new_version or 0,
            object_id=object_id,
            object={},
            errors=errors,
        )

    # Find the object in the new map
    obj_dict = _find_object_dict(result.new_map, object_id)

    # Extract merge details
    merge_details = _extract_merge_details(result.merge_summary)
    warnings = tuple(w for w in result.warnings)

    return UpdateResult(
        success=True,
        map_version=result.new_version or 0,
        object_id=object_id,
        object=obj_dict,
        merge_details=merge_details,
        warnings=warnings,
    )


def _to_remove_result(
    result: WriteResult,
    object_id: str,
) -> RemoveResult:
    """Translate WriteResult to RemoveResult."""
    if not result.success:
        errors = tuple(
            ErrorDetail(stage=e.stage, message=e.message) for e in result.errors
        )
        return RemoveResult(
            success=False,
            map_version=result.new_version or 0,
            object_id=object_id,
            errors=errors,
        )
    return RemoveResult(
        success=True,
        map_version=result.new_version or 0,
        object_id=object_id,
    )


def _find_object_dict(compos_map: Any, object_id: str) -> dict[str, Any]:
    """Find an object by ID across all collections and return as dict."""
    if compos_map is None:
        return {}
    for collection in (
        "components",
        "relationships",
        "constraints",
        "risks",
        "decisions",
    ):
        for obj in getattr(compos_map, collection, ()):
            if obj.id == object_id:
                result: dict[str, Any] = obj.model_dump(by_alias=True)
                return result
    return {}


def _extract_merge_details(
    entry: MergeLogEntry | None,
) -> tuple[MergeDetail, ...]:
    """Extract merge field records into MergeDetail response models."""
    if entry is None or not entry.field_records:
        return ()
    return tuple(
        MergeDetail(
            field_name=r.field_name,
            resolution=r.resolution.value,
            reason=r.reason,
        )
        for r in entry.field_records
    )


def _validation_error_detail(e: ValidationError) -> ErrorDetail:
    """Build an ErrorDetail from a Pydantic ValidationError."""
    messages = "; ".join(
        f"{'.'.join(str(p) for p in err['loc'])}: {err['msg']}" for err in e.errors()
    )
    return ErrorDetail(stage="validation", message=messages)


def _register_validation_error(
    e: ValidationError,
    object_id: str,
) -> RegisterResult:
    """Build a failed RegisterResult from a Pydantic ValidationError."""
    return RegisterResult(
        success=False,
        map_version=0,
        object_id=object_id,
        provenance={},
        errors=(_validation_error_detail(e),),
    )


def _update_validation_error(
    e: ValidationError,
    object_id: str,
) -> UpdateResult:
    """Build a failed UpdateResult from a Pydantic ValidationError."""
    return UpdateResult(
        success=False,
        map_version=0,
        object_id=object_id,
        object={},
        errors=(_validation_error_detail(e),),
    )


# ---------------------------------------------------------------------------
# Register tools
# ---------------------------------------------------------------------------


@mcp.tool(
    description=(
        "Register a new component in the architectural map. "
        "Use when you've created or identified a service, database, queue, "
        "frontend, worker, or external API in the codebase. "
        "Include description and technology if you know them — they enrich "
        "the map for future queries."
    ),
)
def register_component(
    id: str,
    name: str,
    responsibility: str,
    type: str,
    description: str | None = None,
    technology: str | None = None,
    dependencies: list[str] | None = None,
    owner: str | None = None,
    paths: list[str] | None = None,
) -> RegisterResult:
    root = get_project_root()
    prov = _provenance()
    try:
        comp = Component(
            id=id,
            name=name,
            responsibility=responsibility,
            type=type,  # type: ignore[arg-type]
            description=description,
            technology=technology,
            dependencies=tuple(dependencies or []),
            paths=tuple(paths or []),
            owner=owner,
            detection_confidence=0.9,
            status=ObjectStatus.CONFIRMED,
            provenance=prov,
            annotation_confidence=0.8,
        )
    except (ValidationError, ValueError) as e:
        if isinstance(e, ValidationError):
            return _register_validation_error(e, id)
        return RegisterResult(
            success=False,
            map_version=0,
            object_id=id,
            provenance={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import register_component as pipeline_register

    result = execute_write(root, pipeline_register, comp)
    return _to_register_result(result, id, prov.model_dump())


@mcp.tool(
    description=(
        "Register a directed relationship between two components. "
        "Both source and target components must already exist in the map. "
        "Include protocol, data_format, and error_behavior if you know them."
    ),
)
def register_relationship(
    id: str,
    source: str,
    target: str,
    type: str,
    pattern: str,
    description: str,
    protocol: str | None = None,
    data_format: str | None = None,
    error_behavior: str | None = None,
) -> RegisterResult:
    root = get_project_root()
    prov = _provenance()
    try:
        rel = Relationship(
            id=id,
            source=source,
            target=target,
            type=type,  # type: ignore[arg-type]
            pattern=pattern,  # type: ignore[arg-type]
            description=description,
            protocol=protocol,
            data_format=data_format,
            error_behavior=error_behavior,
            status=ObjectStatus.CONFIRMED,
            provenance=prov,
            annotation_confidence=0.8,
        )
    except (ValidationError, ValueError) as e:
        if isinstance(e, ValidationError):
            return _register_validation_error(e, id)
        return RegisterResult(
            success=False,
            map_version=0,
            object_id=id,
            provenance={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import (
        register_relationship as pipeline_register,
    )

    result = execute_write(root, pipeline_register, rel)
    return _to_register_result(result, id, prov.model_dump())


@mcp.tool(
    description=(
        "Register a system constraint (performance, cost, compliance, "
        "availability, security, data-residency). "
        "applies_to must list at least one existing component ID. "
        "hardness is 'hard' (must not violate) or 'soft' "
        "(prefer not to violate)."
    ),
)
def register_constraint(
    id: str,
    type: str,
    description: str,
    applies_to: list[str],
    hardness: str,
    rationale: str | None = None,
    source_decision: str | None = None,
) -> RegisterResult:
    root = get_project_root()
    prov = _provenance()
    try:
        con = Constraint(
            id=id,
            type=type,  # type: ignore[arg-type]
            description=description,
            applies_to=tuple(applies_to),
            hardness=hardness,  # type: ignore[arg-type]
            rationale=rationale,
            source_decision=source_decision,
            status="active",  # type: ignore[arg-type]
            provenance=prov,
            annotation_confidence=0.8,
        )
    except (ValidationError, ValueError) as e:
        if isinstance(e, ValidationError):
            return _register_validation_error(e, id)
        return RegisterResult(
            success=False,
            map_version=0,
            object_id=id,
            provenance={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import (
        register_constraint as pipeline_register,
    )

    result = execute_write(root, pipeline_register, con)
    return _to_register_result(result, id, prov.model_dump())


@mcp.tool(
    description=(
        "Register an identified architectural risk. "
        "Must reference at least one component or relationship. "
        "Include trigger_conditions and impact to make the risk actionable. "
        "severity: critical/high/medium/low. likelihood: high/medium/low."
    ),
)
def register_risk(
    id: str,
    description: str,
    reasoning: str,
    components_involved: list[str] | None = None,
    relationships_involved: list[str] | None = None,
    severity: str = "medium",
    likelihood: str = "medium",
    trigger_conditions: str = "",
    impact: str = "",
    mitigation: str | None = None,
) -> RegisterResult:
    root = get_project_root()
    prov = _provenance()
    try:
        risk = Risk(
            id=id,
            description=description,
            reasoning=reasoning,
            components_involved=tuple(components_involved or []),
            relationships_involved=tuple(relationships_involved or []),
            severity=severity,  # type: ignore[arg-type]
            likelihood=likelihood,  # type: ignore[arg-type]
            trigger_conditions=trigger_conditions,
            impact=impact,
            mitigation=mitigation,
            status="open",  # type: ignore[arg-type]
            provenance=prov,
            annotation_confidence=0.8,
        )
    except (ValidationError, ValueError) as e:
        if isinstance(e, ValidationError):
            return _register_validation_error(e, id)
        return RegisterResult(
            success=False,
            map_version=0,
            object_id=id,
            provenance={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import register_risk as pipeline_register

    result = execute_write(root, pipeline_register, risk)
    return _to_register_result(result, id, prov.model_dump())


@mcp.tool(
    description=(
        "Log an architectural decision. Decisions record WHY something was "
        "built a certain way — not just what. Include alternatives_considered "
        "with rejected_because to capture the full reasoning context. "
        "This is the most valuable data in the map for future AI builders."
    ),
)
def log_decision(
    id: str,
    title: str,
    decision: str,
    reasoning: str,
    alternatives_considered: list[dict[str, str]] | None = None,
    constraints_that_drove_it: list[str] | None = None,
    components_affected: list[str] | None = None,
    relationships_affected: list[str] | None = None,
    file_paths: list[str] | None = None,
) -> RegisterResult:
    root = get_project_root()
    prov = _decision_provenance()
    if file_paths:
        from compos.mcp.resolve import resolve_file_paths

        current_map = storage.read(root)
        resolved = resolve_file_paths(current_map, file_paths)
        all_affected = list(components_affected or []) + resolved.component_ids
        components_affected = all_affected
    try:
        alts = tuple(
            AlternativeConsidered(
                option=a["option"],
                rejected_because=a.get("rejected_because"),
            )
            for a in (alternatives_considered or [])
        )
        dec = Decision(
            id=id,
            title=title,
            decision=decision,
            reasoning=reasoning,
            alternatives_considered=alts,
            constraints_that_drove_it=tuple(
                constraints_that_drove_it or [],
            ),
            components_affected=tuple(components_affected or []),
            relationships_affected=tuple(relationships_affected or []),
            status="active",  # type: ignore[arg-type]
            provenance=prov,
            annotation_confidence=0.8,
        )
    except (ValidationError, ValueError, KeyError) as e:
        if isinstance(e, ValidationError):
            return _register_validation_error(e, id)
        return RegisterResult(
            success=False,
            map_version=0,
            object_id=id,
            provenance={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import (
        register_decision as pipeline_register,
    )

    result = execute_write(root, pipeline_register, dec)
    return _to_register_result(result, id, prov.model_dump())


# ---------------------------------------------------------------------------
# Update tools
# ---------------------------------------------------------------------------


def _read_existing(
    project_root: Path,
    object_id: str,
    collection: str,
) -> Any | None:
    """Read an existing object from storage by ID."""
    current_map = storage.read(project_root)
    for obj in getattr(current_map, collection, ()):
        if obj.id == object_id:
            return obj
    return None


def _overlay_fields(
    existing: Any,
    updates: dict[str, Any],
    provenance: Any,
) -> dict[str, Any]:
    """Overlay provided fields onto existing object data."""
    data: dict[str, Any] = existing.model_dump(by_alias=False)
    for key, value in updates.items():
        if value is not None:
            data[key] = value
    data["provenance"] = provenance.model_dump()
    return data


@mcp.tool(
    description=(
        "Update an existing component. Only provide fields you want to "
        "change. The merge engine will resolve conflicts based on "
        "provenance priority."
    ),
)
def update_component(
    id: str,
    name: str | None = None,
    responsibility: str | None = None,
    type: str | None = None,
    description: str | None = None,
    technology: str | None = None,
    owner: str | None = None,
    paths: list[str] | None = None,
) -> UpdateResult:
    root = get_project_root()
    prov = _provenance()
    existing = _read_existing(root, id, "components")
    if existing is None:
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(
                ErrorDetail(
                    stage="not_found",
                    message=f"component '{id}' not found",
                ),
            ),
        )
    updates: dict[str, Any] = {
        k: v
        for k, v in {
            "name": name,
            "responsibility": responsibility,
            "type": type,
            "description": description,
            "technology": technology,
            "owner": owner,
        }.items()
        if v is not None
    }
    if paths is not None:
        updates["paths"] = tuple(paths)
    try:
        data = _overlay_fields(existing, updates, prov)
        comp = Component.model_validate(data)
    except (ValidationError, ValueError) as e:
        if isinstance(e, ValidationError):
            return _update_validation_error(e, id)
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import update_component as pipeline_update

    result = execute_write(root, pipeline_update, comp)
    return _to_update_result(result, id)


@mcp.tool(
    description=(
        "Update an existing relationship. Only provide fields you want to change."
    ),
)
def update_relationship(
    id: str,
    type: str | None = None,
    pattern: str | None = None,
    description: str | None = None,
    protocol: str | None = None,
    data_format: str | None = None,
    error_behavior: str | None = None,
) -> UpdateResult:
    root = get_project_root()
    prov = _provenance()
    existing = _read_existing(root, id, "relationships")
    if existing is None:
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(
                ErrorDetail(
                    stage="not_found",
                    message=f"relationship '{id}' not found",
                ),
            ),
        )
    updates = {
        k: v
        for k, v in {
            "type": type,
            "pattern": pattern,
            "description": description,
            "protocol": protocol,
            "data_format": data_format,
            "error_behavior": error_behavior,
        }.items()
        if v is not None
    }
    try:
        data = _overlay_fields(existing, updates, prov)
        rel = Relationship.model_validate(data)
    except (ValidationError, ValueError) as e:
        if isinstance(e, ValidationError):
            return _update_validation_error(e, id)
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import (
        update_relationship as pipeline_update,
    )

    result = execute_write(root, pipeline_update, rel)
    return _to_update_result(result, id)


@mcp.tool(
    description=(
        "Update an existing constraint. Only provide fields you want to change."
    ),
)
def update_constraint(
    id: str,
    type: str | None = None,
    description: str | None = None,
    applies_to: list[str] | None = None,
    hardness: str | None = None,
    rationale: str | None = None,
    source_decision: str | None = None,
) -> UpdateResult:
    root = get_project_root()
    prov = _provenance()
    existing = _read_existing(root, id, "constraints")
    if existing is None:
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(
                ErrorDetail(
                    stage="not_found",
                    message=f"constraint '{id}' not found",
                ),
            ),
        )
    updates: dict[str, Any] = {
        k: v
        for k, v in {
            "type": type,
            "description": description,
            "hardness": hardness,
            "rationale": rationale,
            "source_decision": source_decision,
        }.items()
        if v is not None
    }
    if applies_to is not None:
        updates["applies_to"] = tuple(applies_to)
    try:
        data = _overlay_fields(existing, updates, prov)
        con = Constraint.model_validate(data)
    except (ValidationError, ValueError) as e:
        if isinstance(e, ValidationError):
            return _update_validation_error(e, id)
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import (
        update_constraint as pipeline_update,
    )

    result = execute_write(root, pipeline_update, con)
    return _to_update_result(result, id)


@mcp.tool(
    description=("Update an existing risk. Only provide fields you want to change."),
)
def update_risk(
    id: str,
    description: str | None = None,
    reasoning: str | None = None,
    severity: str | None = None,
    likelihood: str | None = None,
    trigger_conditions: str | None = None,
    impact: str | None = None,
    mitigation: str | None = None,
) -> UpdateResult:
    root = get_project_root()
    prov = _provenance()
    existing = _read_existing(root, id, "risks")
    if existing is None:
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(
                ErrorDetail(
                    stage="not_found",
                    message=f"risk '{id}' not found",
                ),
            ),
        )
    updates = {
        k: v
        for k, v in {
            "description": description,
            "reasoning": reasoning,
            "severity": severity,
            "likelihood": likelihood,
            "trigger_conditions": trigger_conditions,
            "impact": impact,
            "mitigation": mitigation,
        }.items()
        if v is not None
    }
    try:
        data = _overlay_fields(existing, updates, prov)
        risk = Risk.model_validate(data)
    except (ValidationError, ValueError) as e:
        if isinstance(e, ValidationError):
            return _update_validation_error(e, id)
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import update_risk as pipeline_update

    result = execute_write(root, pipeline_update, risk)
    return _to_update_result(result, id)


@mcp.tool(
    description=(
        "Update an existing decision. Only provide fields you want to change."
    ),
)
def update_decision(
    id: str,
    title: str | None = None,
    decision: str | None = None,
    reasoning: str | None = None,
    alternatives_considered: list[dict[str, str]] | None = None,
    constraints_that_drove_it: list[str] | None = None,
    components_affected: list[str] | None = None,
    relationships_affected: list[str] | None = None,
) -> UpdateResult:
    root = get_project_root()
    prov = _decision_provenance()
    existing = _read_existing(root, id, "decisions")
    if existing is None:
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(
                ErrorDetail(
                    stage="not_found",
                    message=f"decision '{id}' not found",
                ),
            ),
        )
    updates: dict[str, Any] = {
        k: v
        for k, v in {
            "title": title,
            "decision": decision,
            "reasoning": reasoning,
        }.items()
        if v is not None
    }
    if alternatives_considered is not None:
        updates["alternatives_considered"] = tuple(
            AlternativeConsidered(
                option=a["option"],
                rejected_because=a.get("rejected_because"),
            )
            for a in alternatives_considered
        )
    if constraints_that_drove_it is not None:
        updates["constraints_that_drove_it"] = tuple(
            constraints_that_drove_it,
        )
    if components_affected is not None:
        updates["components_affected"] = tuple(components_affected)
    if relationships_affected is not None:
        updates["relationships_affected"] = tuple(relationships_affected)
    try:
        data = _overlay_fields(existing, updates, prov)
        dec = Decision.model_validate(data)
    except (ValidationError, ValueError, KeyError) as e:
        if isinstance(e, ValidationError):
            return _update_validation_error(e, id)
        return UpdateResult(
            success=False,
            map_version=0,
            object_id=id,
            object={},
            errors=(ErrorDetail(stage="validation", message=str(e)),),
        )

    from compos.core.write_pipeline import update_decision as pipeline_update

    result = execute_write(root, pipeline_update, dec)
    return _to_update_result(result, id)


# ---------------------------------------------------------------------------
# Remove tools
# ---------------------------------------------------------------------------


@mcp.tool(
    description=(
        "Remove a component (soft-delete). Requires a reason. "
        "Will fail if the component is referenced by any relationship — "
        "remove those first."
    ),
)
def remove_component(
    id: str,
    reason: str,
) -> RemoveResult:
    root = get_project_root()
    from compos.core.write_pipeline import remove_component as pipeline_remove

    result = execute_write(
        root,
        pipeline_remove,
        id,
        reason,
        ProvenanceSource.AI_ANNOTATED,
    )
    return _to_remove_result(result, id)


@mcp.tool(
    description="Remove a relationship (soft-delete). Requires a reason.",
)
def remove_relationship(
    id: str,
    reason: str,
) -> RemoveResult:
    root = get_project_root()
    from compos.core.write_pipeline import (
        remove_relationship as pipeline_remove,
    )

    result = execute_write(
        root,
        pipeline_remove,
        id,
        reason,
        ProvenanceSource.AI_ANNOTATED,
    )
    return _to_remove_result(result, id)


@mcp.tool(
    description="Remove a constraint (soft-delete). Requires a reason.",
)
def remove_constraint(
    id: str,
    reason: str,
) -> RemoveResult:
    root = get_project_root()
    from compos.core.write_pipeline import (
        remove_constraint as pipeline_remove,
    )

    result = execute_write(
        root,
        pipeline_remove,
        id,
        reason,
        ProvenanceSource.AI_ANNOTATED,
    )
    return _to_remove_result(result, id)


@mcp.tool(
    description="Remove a risk (soft-delete). Requires a reason.",
)
def remove_risk(
    id: str,
    reason: str,
) -> RemoveResult:
    root = get_project_root()
    from compos.core.write_pipeline import remove_risk as pipeline_remove

    result = execute_write(
        root,
        pipeline_remove,
        id,
        reason,
        ProvenanceSource.AI_ANNOTATED,
    )
    return _to_remove_result(result, id)


@mcp.tool(
    description="Remove a decision (soft-delete). Requires a reason.",
)
def remove_decision(
    id: str,
    reason: str,
) -> RemoveResult:
    root = get_project_root()
    from compos.core.write_pipeline import (
        remove_decision as pipeline_remove,
    )

    result = execute_write(
        root,
        pipeline_remove,
        id,
        reason,
        ProvenanceSource.AI_ANNOTATED,
    )
    return _to_remove_result(result, id)
