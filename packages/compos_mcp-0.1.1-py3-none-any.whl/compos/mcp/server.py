"""MCP server setup and storage bridge.

The storage bridge encapsulates the load-per-call pattern:
read map → execute pipeline function → persist new map + merge log.

Project root is resolved via COMPOS_PROJECT_ROOT env var or auto-detection
(walk up from CWD looking for .compos/ or .git/).
"""

from __future__ import annotations

import os
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from compos.core.merge_log import serialize_entry
from compos.core.write_pipeline import WriteResult
from compos.schema.models import ComposMap, ProjectInfo
from compos.storage import local as storage

# ---------------------------------------------------------------------------
# FastMCP server instance
# ---------------------------------------------------------------------------

mcp = FastMCP(
    "compos",
    instructions=(
        "Architectural memory for your codebase. "
        "Use get_component_context to orient before making changes. "
        "Use evaluate_proposed_change as a pre-flight check "
        "before structural changes."
    ),
)


# ---------------------------------------------------------------------------
# Project root resolution
# ---------------------------------------------------------------------------

_MARKERS = (".compos", ".git")


def resolve_project_root() -> Path:
    """Resolve the project root directory.

    Priority:
    1. COMPOS_PROJECT_ROOT environment variable
    2. Walk up from CWD looking for .compos/ or .git/
    """
    env_root = os.environ.get("COMPOS_PROJECT_ROOT")
    if env_root:
        return Path(env_root)

    current = Path.cwd().resolve()
    for directory in (current, *current.parents):
        for marker in _MARKERS:
            if (directory / marker).exists():
                return directory

    msg = (
        f"Could not find project root from {current}. "
        "Set COMPOS_PROJECT_ROOT or run from a directory "
        "with .compos/ or .git/"
    )
    raise FileNotFoundError(msg)


_cached_root: Path | None = None


def get_project_root() -> Path:
    """Return the project root, caching after first resolution.

    Safe to cache because the MCP server is launched per-project
    via .mcp.json with COMPOS_PROJECT_ROOT set.
    """
    global _cached_root
    if _cached_root is None:
        _cached_root = resolve_project_root()
    return _cached_root


def _reset_project_root_cache() -> None:
    """Reset cache — for tests only."""
    global _cached_root
    _cached_root = None


# ---------------------------------------------------------------------------
# Storage bridge
# ---------------------------------------------------------------------------


def execute_write(
    project_root: Path,
    pipeline_fn: Callable[..., WriteResult],
    *args: Any,
    **kwargs: Any,
) -> WriteResult:
    """Load map → run pipeline function → persist on success.

    Reads the current map, passes it as the first argument to pipeline_fn,
    then persists the result if successful. Uses optimistic concurrency
    via expected_version.
    """
    current_map = storage.read(project_root)
    result = pipeline_fn(current_map, *args, **kwargs)

    if result.success and result.new_map is not None:
        merge_log_lines: list[str] = []
        if result.merge_summary is not None:
            merge_log_lines.append(serialize_entry(result.merge_summary))

        storage.persist_write_result(
            project_root,
            result.new_map,
            merge_log_lines=merge_log_lines,
            expected_version=current_map.map_version,
        )

    return result


def execute_write_with_auto_init(
    project_root: Path,
    project_name: str,
    pipeline_fn: Callable[..., WriteResult],
    *args: Any,
    **kwargs: Any,
) -> WriteResult:
    """Like execute_write, but auto-initializes .compos/ if missing."""
    if not storage.exists(project_root):
        initial_map = ComposMap(
            schema_version="1.1",
            map_version=1,
            generated_at=datetime.now(UTC),
            produced_by="compos-mcp",
            project=ProjectInfo(name=project_name, description=""),
        )
        storage.init(project_root, initial_map)
    return execute_write(project_root, pipeline_fn, *args, **kwargs)
