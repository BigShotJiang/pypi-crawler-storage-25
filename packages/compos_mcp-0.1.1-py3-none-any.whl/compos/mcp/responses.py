"""MCP response models for Compos tools.

Design principles:
- Per-tool response types give AI builders precise outputSchema per tool.
- Errors are structured in the response body (success + errors), not
  exceptions mapped to MCP isError. AI agents reason about structured
  data more reliably than parsed error text.
- Frozen Pydantic models, tuples for collections — consistent with schema/.
- Domain objects serialized to dict[str, Any] at the MCP boundary. Type
  safety is enforced inside the server by the write pipeline.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

# ---------------------------------------------------------------------------
# Shared models
# ---------------------------------------------------------------------------


class ErrorDetail(BaseModel):
    """Structured error info for AI agent consumption.

    stage: which pipeline stage failed (uniqueness, integrity, provenance, etc.)
    message: human/AI-readable description of what went wrong
    details: machine-parseable context (missing IDs, conflicting fields, etc.)
    """

    model_config = ConfigDict(frozen=True)

    stage: str
    message: str
    details: dict[str, Any] = {}


class MergeDetail(BaseModel):
    """Summary of a single field-level merge decision.

    Gives AI builders visibility into what the merge engine did — which
    fields were accepted, rejected, or overridden. Critical for the
    provenance trust model.
    """

    model_config = ConfigDict(frozen=True)

    field_name: str
    resolution: str  # "accepted" | "rejected" | "warning"
    reason: str


# ---------------------------------------------------------------------------
# Write responses
# ---------------------------------------------------------------------------


class RegisterResult(BaseModel):
    """Returned by all register_* tools."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    object_id: str
    provenance: dict[str, Any]
    errors: tuple[ErrorDetail, ...] = ()


class UpdateResult(BaseModel):
    """Returned by all update_* tools."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    object_id: str
    object: dict[str, Any]
    merge_details: tuple[MergeDetail, ...] = ()
    warnings: tuple[str, ...] = ()
    errors: tuple[ErrorDetail, ...] = ()


class RemoveResult(BaseModel):
    """Returned by all remove_* tools."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    object_id: str
    errors: tuple[ErrorDetail, ...] = ()


# ---------------------------------------------------------------------------
# Read responses — per-tool typed results
# ---------------------------------------------------------------------------


class GetObjectResult(BaseModel):
    """Returned by get_component, get_relationship, etc."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    object: dict[str, Any]
    errors: tuple[ErrorDetail, ...] = ()


class ListObjectsResult(BaseModel):
    """Returned by list_components, list_relationships, etc."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    objects: tuple[dict[str, Any], ...]
    total_count: int
    errors: tuple[ErrorDetail, ...] = ()


class AffectedComponentDetail(BaseModel):
    """One component in a blast radius result."""

    model_config = ConfigDict(frozen=True)

    component_id: str
    component_name: str
    hop_distance: int
    path: tuple[str, ...]
    relationship_types: tuple[str, ...]


class BlastRadiusResponse(BaseModel):
    """Returned by get_blast_radius tool."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    source_component_id: str
    change_type: str
    affected: tuple[AffectedComponentDetail, ...]
    unresolved_paths: tuple[str, ...] = ()
    errors: tuple[ErrorDetail, ...] = ()


class ComponentContextResult(BaseModel):
    """Returned by get_component_context tool."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    focal_components: tuple[dict[str, Any], ...]
    neighbor_components: tuple[dict[str, Any], ...]
    connecting_relationships: tuple[dict[str, Any], ...]
    applicable_constraints: tuple[dict[str, Any], ...]
    applicable_risks: tuple[dict[str, Any], ...]
    applicable_decisions: tuple[dict[str, Any], ...]
    unresolved_paths: tuple[str, ...] = ()
    errors: tuple[ErrorDetail, ...] = ()


class ConstraintsResult(BaseModel):
    """Returned by get_constraints_for_components tool."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    constraints: tuple[dict[str, Any], ...]
    unresolved_paths: tuple[str, ...] = ()
    errors: tuple[ErrorDetail, ...] = ()


class CycleDetail(BaseModel):
    """One detected dependency cycle."""

    model_config = ConfigDict(frozen=True)

    component_ids: tuple[str, ...]
    relationship_ids: tuple[str, ...]


class SPOFDetail(BaseModel):
    """One single-point-of-failure candidate."""

    model_config = ConfigDict(frozen=True)

    component_id: str
    component_name: str
    dependent_count: int
    synchronous_dependent_ids: tuple[str, ...]
    has_error_behavior: bool


class ConstraintConflictDetail(BaseModel):
    """One constraint potentially violated by a proposed change."""

    model_config = ConfigDict(frozen=True)

    constraint_id: str
    constraint_type: str
    description: str
    reason: str


class EvaluateChangeResult(BaseModel):
    """Returned by evaluate_proposed_change tool."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    cycles: tuple[CycleDetail, ...]
    spofs: tuple[SPOFDetail, ...]
    constraint_conflicts: tuple[ConstraintConflictDetail, ...]
    errors: tuple[ErrorDetail, ...] = ()


class SystemMapResult(BaseModel):
    """Returned by get_system_map tool."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    schema_version: str
    generated_at: str
    components: tuple[dict[str, Any], ...]
    relationships: tuple[dict[str, Any], ...]
    constraints: tuple[dict[str, Any], ...]
    risks: tuple[dict[str, Any], ...]
    decisions: tuple[dict[str, Any], ...]
    errors: tuple[ErrorDetail, ...] = ()


class VersionListResult(BaseModel):
    """Returned by list_versions tool."""

    model_config = ConfigDict(frozen=True)

    success: bool
    current_version: int
    versions: tuple[dict[str, Any], ...]
    total_count: int
    errors: tuple[ErrorDetail, ...] = ()


class SnapshotResult(BaseModel):
    """Returned by get_snapshot tool."""

    model_config = ConfigDict(frozen=True)

    success: bool
    map_version: int
    map_data: dict[str, Any]
    errors: tuple[ErrorDetail, ...] = ()
