"""Read/write .compos/map.json, atomic file ops.

File locking is NOT implemented. Atomic rename (os.replace) prevents
corruption from concurrent writes — the last writer wins, but neither
write is partial. A future version should add advisory file locking
(e.g. fcntl.flock) when concurrent CLI/MCP access becomes a real scenario.
"""

from __future__ import annotations

import json
import os
from collections.abc import Sequence
from pathlib import Path

from compos.schema.models import ComposMap

COMPOS_DIR = ".compos"
MAP_FILE = "map.json"
TEMP_FILE = ".map.json.tmp"
VERSIONS_DIR = "versions"


class MapNotFoundError(FileNotFoundError):
    """Raised when .compos/map.json does not exist."""

    def __init__(self, path: Path) -> None:
        super().__init__(f"Compos map not found: {path}")
        self.path = path


class SnapshotNotFoundError(FileNotFoundError):
    """Requested version snapshot does not exist."""

    def __init__(self, version: int, path: Path) -> None:
        super().__init__(f"Snapshot version {version} not found: {path}")
        self.version = version
        self.path = path


class ConcurrentWriteError(Exception):
    """Raised when expected_version does not match current map version."""

    def __init__(self, expected: int, actual: int) -> None:
        super().__init__(
            f"Concurrent write detected: expected version {expected},"
            f" but current version is {actual}"
        )
        self.expected = expected
        self.actual = actual


def exists(project_root: Path) -> bool:
    """Return True if .compos/map.json exists under project_root."""
    return (project_root / COMPOS_DIR / MAP_FILE).is_file()


def init(project_root: Path, initial_map: ComposMap) -> Path:
    """Create .compos/ directory and write initial map.json.

    Skips writing if map.json already exists (idempotent).
    Returns the path to the .compos/ directory.
    """
    compos_dir = project_root / COMPOS_DIR
    compos_dir.mkdir(exist_ok=True)

    map_path = compos_dir / MAP_FILE
    if not map_path.is_file():
        map_path.write_text(initial_map.model_dump_json(indent=2, by_alias=True) + "\n")

    return compos_dir


def read(project_root: Path) -> ComposMap:
    """Read and deserialize .compos/map.json.

    Raises MapNotFoundError if the file does not exist.
    Raises pydantic.ValidationError if the JSON is invalid schema.
    Raises json.JSONDecodeError if the file is not valid JSON.
    """
    map_path = project_root / COMPOS_DIR / MAP_FILE
    if not map_path.is_file():
        raise MapNotFoundError(map_path)

    raw = map_path.read_bytes()
    # Separate JSON parsing from schema validation so callers get
    # json.JSONDecodeError for malformed JSON (not wrapped in ValidationError).
    data = json.loads(raw)
    return ComposMap.model_validate(data)


def write(
    project_root: Path,
    compos_map: ComposMap,
    expected_version: int | None = None,
) -> None:
    """Atomically write a ComposMap to .compos/map.json.

    Uses write-to-temp-then-rename for atomic file replacement.
    If expected_version is provided, raises ConcurrentWriteError if the
    current map version does not match (optimistic concurrency control).
    Raises MapNotFoundError if .compos/ directory does not exist.
    """
    compos_dir = project_root / COMPOS_DIR
    if not compos_dir.is_dir():
        raise MapNotFoundError(compos_dir / MAP_FILE)

    map_path = compos_dir / MAP_FILE

    # Optimistic concurrency check
    if expected_version is not None and map_path.is_file():
        current = json.loads(map_path.read_bytes())
        current_version = current.get("map_version")
        if current_version != expected_version:
            raise ConcurrentWriteError(expected_version, current_version)

    temp_path = compos_dir / TEMP_FILE

    try:
        temp_path.write_text(compos_map.model_dump_json(indent=2, by_alias=True) + "\n")
        os.replace(temp_path, map_path)
    finally:
        # Clean up temp file if it still exists (e.g. serialization failed
        # after partial write, or between write_text and os.replace)
        if temp_path.is_file():
            temp_path.unlink()


def save_snapshot(project_root: Path, compos_map: ComposMap) -> Path:
    """Save a map version to .compos/versions/{version}.json."""
    compos_dir = project_root / COMPOS_DIR
    if not compos_dir.is_dir():
        raise MapNotFoundError(compos_dir / MAP_FILE)
    versions_dir = compos_dir / VERSIONS_DIR
    versions_dir.mkdir(exist_ok=True)
    snapshot_path = versions_dir / f"{compos_map.map_version}.json"
    snapshot_path.write_text(compos_map.model_dump_json(indent=2, by_alias=True) + "\n")
    return snapshot_path


def read_snapshot(project_root: Path, version: int) -> ComposMap:
    """Read .compos/versions/{version}.json."""
    compos_dir = project_root / COMPOS_DIR
    if not compos_dir.is_dir():
        raise MapNotFoundError(compos_dir / MAP_FILE)
    snapshot_path = compos_dir / VERSIONS_DIR / f"{version}.json"
    if not snapshot_path.is_file():
        raise SnapshotNotFoundError(version, snapshot_path)
    data = json.loads(snapshot_path.read_bytes())
    return ComposMap.model_validate(data)


def list_snapshots(project_root: Path) -> list[int]:
    """List available snapshot version numbers, sorted ascending."""
    versions_dir = project_root / COMPOS_DIR / VERSIONS_DIR
    if not versions_dir.is_dir():
        return []
    versions: list[int] = []
    for f in versions_dir.iterdir():
        if f.suffix == ".json" and f.stem.isdigit():
            versions.append(int(f.stem))
    return sorted(versions)


def persist_write_result(
    project_root: Path,
    new_map: ComposMap,
    merge_log_lines: Sequence[str] = (),
    expected_version: int | None = None,
) -> None:
    """Consolidated write: map + merge log, all under one lock.

    Steps (all under compos_lock):
    1. Optimistic concurrency check (if expected_version provided)
    2. Append merge log entries (log-before-map ordering)
    3. Atomic write of map.json
    4. Trigger merge log compaction if needed

    Callers are responsible for snapshotting pre-mutation state if
    diff history is needed (see cli/main.py:analyze).
    """
    from compos.storage.locking import compos_lock
    from compos.storage.merge_log import append_merge_log, compact_merge_log

    # Check before lock — compos_lock creates .compos/ via mkdir,
    # which would mask this error for uninitialized projects.
    compos_dir = project_root / COMPOS_DIR
    if not compos_dir.is_dir():
        raise MapNotFoundError(compos_dir / MAP_FILE)

    with compos_lock(project_root):
        # Optimistic concurrency check inside the lock
        if expected_version is not None:
            map_path = project_root / COMPOS_DIR / MAP_FILE
            if map_path.is_file():
                current = json.loads(map_path.read_bytes())
                current_version = current.get("map_version")
                if current_version != expected_version:
                    raise ConcurrentWriteError(expected_version, current_version)

        # Log before map — crash between these two is recoverable
        for line in merge_log_lines:
            append_merge_log(project_root, line)

        # Atomic map write (temp-then-rename)
        write(project_root, new_map)

        # Amortized compaction
        compact_merge_log(project_root)
