"""Merge log persistence (append-only local file).

Handles file I/O for the merge log. Data model and serialization
are in core/merge_log.py — this module only appends and reads lines.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from compos.storage.local import COMPOS_DIR

MERGE_LOG_FILE = "merge-log.jsonl"


def append_merge_log(project_root: Path, entry_line: str) -> None:
    """Append a single JSONL line to .compos/merge-log.jsonl.

    Creates the file if it doesn't exist.
    """
    log_path = project_root / COMPOS_DIR / MERGE_LOG_FILE
    with log_path.open("a", encoding="utf-8") as f:
        f.write(entry_line + "\n")


def read_merge_log(project_root: Path) -> list[str]:
    """Read all lines from .compos/merge-log.jsonl.

    Returns empty list if the file doesn't exist or is empty.
    """
    log_path = project_root / COMPOS_DIR / MERGE_LOG_FILE
    if not log_path.is_file():
        return []
    lines = log_path.read_text(encoding="utf-8").strip().splitlines()
    return [line for line in lines if line.strip()]


MERGE_LOG_TEMP = ".merge-log.jsonl.tmp"


def compact_merge_log(
    project_root: Path,
    keep_versions: int = 100,
) -> None:
    """Remove old entries from the merge log using amortized compaction.

    Only rewrites when line count exceeds 2 * keep_versions (amortized cost).
    Keeps lines whose map_version > (max_version - keep_versions).
    """
    log_path = project_root / COMPOS_DIR / MERGE_LOG_FILE
    if not log_path.is_file():
        return

    lines = log_path.read_text(encoding="utf-8").strip().splitlines()
    lines = [line for line in lines if line.strip()]

    if len(lines) <= 2 * keep_versions:
        return

    # Parse map_version from each line to find the cutoff
    max_version = 0
    for line in lines:
        try:
            entry = json.loads(line)
            v = entry.get("map_version", 0)
            if v > max_version:
                max_version = v
        except json.JSONDecodeError:
            continue

    cutoff = max_version - keep_versions

    kept = []
    for line in lines:
        try:
            v = json.loads(line).get("map_version", 0)
        except json.JSONDecodeError:
            kept.append(line)  # preserve unparseable lines
            continue
        if v > cutoff:
            kept.append(line)

    # Atomic rewrite via temp-then-rename
    temp_path = project_root / COMPOS_DIR / MERGE_LOG_TEMP
    try:
        temp_path.write_text("\n".join(kept) + "\n", encoding="utf-8")
        os.replace(temp_path, log_path)
    finally:
        if temp_path.is_file():
            temp_path.unlink()
