"""Advisory file locking for .compos/ directory.

Uses fcntl.flock (POSIX) for process-level advisory locks.
The OS auto-releases on process crash (kernel closes fd).
"""

from __future__ import annotations

import fcntl
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from compos.storage.local import COMPOS_DIR

LOCK_FILE = ".lock"

_held_locks: threading.local = threading.local()


class LockTimeoutError(TimeoutError):
    """Could not acquire .compos/.lock within timeout."""

    def __init__(self, path: Path, timeout: float) -> None:
        super().__init__(f"Could not acquire lock {path} within {timeout}s")
        self.path = path
        self.timeout = timeout


@contextmanager
def compos_lock(
    project_root: Path,
    *,
    timeout: float = 10.0,
) -> Iterator[None]:
    """Acquire an exclusive advisory lock on .compos/.lock.

    Reentrant within the same thread (nested calls are no-ops).
    Blocks other processes until released or timeout.
    """
    compos_dir = project_root / COMPOS_DIR
    compos_dir.mkdir(exist_ok=True)
    lock_path = compos_dir / LOCK_FILE

    if not hasattr(_held_locks, "roots"):
        _held_locks.roots = set()

    resolved = project_root.resolve()
    if resolved in _held_locks.roots:
        yield
        return

    fd = lock_path.open("w")
    try:
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise LockTimeoutError(lock_path, timeout)
                time.sleep(0.05)

        _held_locks.roots.add(resolved)
        try:
            yield
        finally:
            _held_locks.roots.discard(resolved)
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        fd.close()
