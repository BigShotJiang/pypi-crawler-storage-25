"""Schema validation logic."""
