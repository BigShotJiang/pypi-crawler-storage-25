"""Pydantic models for 5 object types + map root."""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Any, Self

from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, model_validator

# ---------------------------------------------------------------------------
# Shared type aliases
# ---------------------------------------------------------------------------

# Strings that must contain at least one character (after stripping)
NonEmptyStr = Annotated[str, Field(min_length=1)]

# Confidence scores clamped to [0.0, 1.0]
UnitConfidence = Annotated[float, Field(ge=0.0, le=1.0)]


# ---------------------------------------------------------------------------
# Enums — all StrEnum so they serialize as their string value in JSON
# ---------------------------------------------------------------------------


class ProvenanceSource(StrEnum):
    """Who produced this data: static tool, AI, or human."""

    STATIC_ANALYSIS = "static-analysis"
    AI_ANNOTATED = "ai-annotated"
    HUMAN_INPUT = "human-input"


class DecisionProvenanceSource(StrEnum):
    """Subset of ProvenanceSource — decisions can't come from static analysis."""

    AI_ANNOTATED = "ai-annotated"
    HUMAN_INPUT = "human-input"


class ComponentType(StrEnum):
    SERVICE = "service"
    DATABASE = "database"
    QUEUE = "queue"
    EXTERNAL_API = "external-api"
    FRONTEND = "frontend"
    WORKER = "worker"
    LIBRARY = "library"
    OTHER = "other"


class ObjectStatus(StrEnum):
    """Soft-deletion lifecycle for components and relationships."""

    CONFIRMED = "confirmed"
    CANDIDATE = "candidate"
    REMOVED = "removed"


class ConstraintStatus(StrEnum):
    ACTIVE = "active"
    REMOVED = "removed"


class RiskStatus(StrEnum):
    OPEN = "open"
    MITIGATED = "mitigated"
    DISMISSED = "dismissed"
    REMOVED = "removed"


class DecisionStatus(StrEnum):
    ACTIVE = "active"
    SUPERSEDED = "superseded"
    REVERSED = "reversed"
    REMOVED = "removed"


class RelationshipType(StrEnum):
    DATA_FLOW = "data-flow"
    DEPENDENCY = "dependency"
    CALL = "call"
    EVENT = "event"
    OTHER = "other"


class RelationshipPattern(StrEnum):
    SYNCHRONOUS = "synchronous"
    ASYNCHRONOUS = "asynchronous"
    PUB_SUB = "pub-sub"
    REQUEST_REPLY = "request-reply"
    FIRE_AND_FORGET = "fire-and-forget"
    STREAMING = "streaming"


class ConstraintType(StrEnum):
    PERFORMANCE = "performance"
    COST = "cost"
    COMPLIANCE = "compliance"
    AVAILABILITY = "availability"
    SECURITY = "security"
    DATA_RESIDENCY = "data-residency"
    OTHER = "other"


class Severity(StrEnum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class Likelihood(StrEnum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class Hardness(StrEnum):
    HARD = "hard"
    SOFT = "soft"


# ---------------------------------------------------------------------------
# Base model — frozen, whitespace-stripping, alias-friendly
# ---------------------------------------------------------------------------


class _ComposBase(BaseModel):
    """Shared config for all Compos models."""

    model_config = ConfigDict(
        frozen=True,
        populate_by_name=True,
        str_strip_whitespace=True,
    )


# ---------------------------------------------------------------------------
# Provenance models
# ---------------------------------------------------------------------------


class Provenance(_ComposBase):
    """Tracks who produced a piece of data and when."""

    source: ProvenanceSource
    tool: NonEmptyStr
    timestamp: AwareDatetime


class DecisionProvenance(_ComposBase):
    """Like Provenance but forbids static-analysis at the type level."""

    source: DecisionProvenanceSource
    tool: NonEmptyStr
    timestamp: AwareDatetime


# ---------------------------------------------------------------------------
# Shared validator — annotation_confidence gating
# ---------------------------------------------------------------------------


def _validate_annotation_confidence(model: Any) -> Any:
    """annotation_confidence must be None unless source is ai-annotated."""
    if model.annotation_confidence is not None:
        source = model.provenance.source
        ai_sources = {
            ProvenanceSource.AI_ANNOTATED,
            DecisionProvenanceSource.AI_ANNOTATED,
        }
        if source not in ai_sources:
            msg = (
                "annotation_confidence is only valid when"
                " provenance.source is 'ai-annotated'"
            )
            raise ValueError(msg)
    return model


def _validate_removed_fields(model: Any, removed_status: str) -> Any:
    """removed_at/removed_reason only valid when status equals the removed value."""
    status = getattr(model, "status", None)
    removed_at = getattr(model, "removed_at", None)
    removed_reason = getattr(model, "removed_reason", None)
    if str(status) != removed_status:
        if removed_at is not None:
            msg = f"removed_at is only valid when status is '{removed_status}'"
            raise ValueError(msg)
        if removed_reason is not None:
            msg = f"removed_reason is only valid when status is '{removed_status}'"
            raise ValueError(msg)
    return model


# ---------------------------------------------------------------------------
# Auxiliary models
# ---------------------------------------------------------------------------


class ProjectInfo(_ComposBase):
    """Basic project metadata."""

    name: NonEmptyStr
    description: str


class LastMerge(_ComposBase):
    """Stats from the most recent merge operation."""

    timestamp: AwareDatetime
    map_version: int
    conflicts_count: int = Field(ge=0)
    overrides_count: int = Field(ge=0)
    warnings_count: int = Field(ge=0)


class AlternativeConsidered(_ComposBase):
    """A decision alternative with optional rejection reasoning."""

    option: NonEmptyStr
    rejected_because: str | None = None


# ---------------------------------------------------------------------------
# Core object models — the 5 types
# ---------------------------------------------------------------------------


class Component(_ComposBase):
    """A system component (service, database, etc.)."""

    id: NonEmptyStr
    name: NonEmptyStr
    responsibility: NonEmptyStr
    type: ComponentType
    description: str | None = None
    technology: str | None = None
    dependencies: tuple[str, ...] = ()
    paths: tuple[str, ...] = ()
    owner: str | None = None
    detection_confidence: UnitConfidence
    status: ObjectStatus
    removed_at: AwareDatetime | None = None
    removed_reason: str | None = None
    provenance: Provenance
    annotation_confidence: UnitConfidence | None = None
    prior: dict[str, Any] | None = Field(default=None, alias="_prior")

    @model_validator(mode="after")
    def _check_constraints(self) -> Self:
        _validate_annotation_confidence(self)
        _validate_removed_fields(self, "removed")
        return self


class Relationship(_ComposBase):
    """A directed link between two components."""

    id: NonEmptyStr
    source: NonEmptyStr  # component ID
    target: NonEmptyStr  # component ID
    type: RelationshipType
    pattern: RelationshipPattern
    description: NonEmptyStr
    protocol: str | None = None
    data_format: str | None = None
    error_behavior: str | None = None
    detection_confidence: UnitConfidence | None = None
    status: ObjectStatus
    removed_at: AwareDatetime | None = None
    removed_reason: str | None = None
    provenance: Provenance
    annotation_confidence: UnitConfidence | None = None
    prior: dict[str, Any] | None = Field(default=None, alias="_prior")

    @model_validator(mode="after")
    def _check_constraints(self) -> Self:
        _validate_annotation_confidence(self)
        _validate_removed_fields(self, "removed")
        # detection_confidence required for static-analysis provenance
        if (
            self.provenance.source == ProvenanceSource.STATIC_ANALYSIS
            and self.detection_confidence is None
        ):
            msg = (
                "detection_confidence is required when"
                " provenance.source is 'static-analysis'"
            )
            raise ValueError(msg)
        return self


class Constraint(_ComposBase):
    """A system constraint (performance, compliance, etc.)."""

    id: NonEmptyStr
    type: ConstraintType
    description: NonEmptyStr
    applies_to: tuple[str, ...] = Field(min_length=1)  # at least one target
    hardness: Hardness
    rationale: str | None = None
    source_decision: str | None = None
    consequence: str | None = None
    status: ConstraintStatus
    removed_at: AwareDatetime | None = None
    removed_reason: str | None = None
    provenance: Provenance
    annotation_confidence: UnitConfidence | None = None

    @model_validator(mode="after")
    def _check_constraints(self) -> Self:
        _validate_annotation_confidence(self)
        _validate_removed_fields(self, "removed")
        return self


class Risk(_ComposBase):
    """An identified architectural risk."""

    id: NonEmptyStr
    description: NonEmptyStr
    reasoning: NonEmptyStr
    components_involved: tuple[str, ...] = ()
    relationships_involved: tuple[str, ...] = ()
    severity: Severity
    likelihood: Likelihood
    trigger_conditions: NonEmptyStr
    impact: NonEmptyStr
    status: RiskStatus
    dismissal_reason: str | None = None
    mitigation: str | None = None
    removed_at: AwareDatetime | None = None
    removed_reason: str | None = None
    provenance: Provenance
    annotation_confidence: UnitConfidence | None = None

    @model_validator(mode="after")
    def _check_constraints(self) -> Self:
        _validate_annotation_confidence(self)
        _validate_removed_fields(self, "removed")
        # dismissal_reason only valid when dismissed
        if self.dismissal_reason is not None and self.status != RiskStatus.DISMISSED:
            msg = "dismissal_reason is only valid when status is 'dismissed'"
            raise ValueError(msg)
        # Risk must be anchored to at least one component or relationship
        if not self.components_involved and not self.relationships_involved:
            msg = (
                "Risk must reference at least one component or relationship"
                " (components_involved and relationships_involved cannot"
                " both be empty)"
            )
            raise ValueError(msg)
        return self


class Decision(_ComposBase):
    """An architectural decision record (ADR-like)."""

    id: NonEmptyStr
    title: NonEmptyStr
    decision: NonEmptyStr
    reasoning: NonEmptyStr
    alternatives_considered: tuple[AlternativeConsidered, ...] = ()
    constraints_that_drove_it: tuple[str, ...] = ()
    components_affected: tuple[str, ...] = ()
    relationships_affected: tuple[str, ...] = ()
    implemented_in: str | None = None
    status: DecisionStatus
    superseded_by: str | None = None
    reversed_reason: str | None = None
    removed_at: AwareDatetime | None = None
    removed_reason: str | None = None
    provenance: DecisionProvenance  # no static-analysis allowed
    annotation_confidence: UnitConfidence | None = None

    @model_validator(mode="after")
    def _check_constraints(self) -> Self:
        _validate_annotation_confidence(self)
        _validate_removed_fields(self, "removed")
        # superseded_by only valid when superseded
        if self.superseded_by is not None and self.status != DecisionStatus.SUPERSEDED:
            msg = "superseded_by is only valid when status is 'superseded'"
            raise ValueError(msg)
        # reversed_reason only valid when reversed
        if self.reversed_reason is not None and self.status != DecisionStatus.REVERSED:
            msg = "reversed_reason is only valid when status is 'reversed'"
            raise ValueError(msg)
        return self


# ---------------------------------------------------------------------------
# Root model — the full Compos map
# ---------------------------------------------------------------------------


class ComposMap(_ComposBase):
    """The root document: a versioned snapshot of the architectural map."""

    schema_version: str = "1.1"
    map_version: int
    generated_at: AwareDatetime
    git_commit: str | None = None
    parent_version: int | None = None
    produced_by: NonEmptyStr
    project: ProjectInfo

    # Collections default to empty tuples (frozen-friendly)
    components: tuple[Component, ...] = ()
    relationships: tuple[Relationship, ...] = ()
    constraints: tuple[Constraint, ...] = ()
    risks: tuple[Risk, ...] = ()
    decisions: tuple[Decision, ...] = ()

    last_merge: LastMerge | None = None

    @model_validator(mode="after")
    def _check_map_constraints(self) -> Self:
        # parent_version must be strictly less than map_version
        if self.parent_version is not None and self.parent_version >= self.map_version:
            msg = "parent_version must be less than map_version"
            raise ValueError(msg)

        # Detect duplicate IDs within each collection
        collections = (
            "components",
            "relationships",
            "constraints",
            "risks",
            "decisions",
        )
        for field_name in collections:
            items = getattr(self, field_name)
            ids = [item.id for item in items]
            if len(ids) != len(set(ids)):
                msg = f"Duplicate IDs found in {field_name}"
                raise ValueError(msg)

        return self
