"""Schema version handling, semver checks."""
