"""Core package — shared domain logic for the Compos architectural map."""

from compos.core.graph import (
    AffectedComponent,
    BlastRadiusResult,
    ChangeEvaluation,
    ChangeType,
    ComponentContext,
    ConstraintConflict,
    CycleInfo,
    Direction,
    RelationshipGraph,
    SPOFInfo,
    evaluate_proposed_change,
    get_blast_radius,
    get_component_context,
    get_constraints_for_components,
)
from compos.core.integrity import (
    IntegrityViolation,
    RemoveBlockedDetail,
    build_reference_index,
    check_id_uniqueness,
    check_referential_integrity,
    check_remove_blocked,
)
from compos.core.merge import (
    FieldMergeRecord,
    MergeResolution,
    MergeResult,
    merge_object,
)
from compos.core.merge_log import (
    MergeLogEntry,
    create_entry,
    deserialize_entry,
    serialize_entry,
)
from compos.core.versioning import (
    VersionBump,
    increment_version,
)
from compos.core.write_pipeline import (
    OperationType,
    WriteError,
    WriteResult,
    register_component,
    register_constraint,
    register_decision,
    register_relationship,
    register_risk,
    remove_component,
    remove_constraint,
    remove_decision,
    remove_relationship,
    remove_risk,
    update_component,
    update_constraint,
    update_decision,
    update_relationship,
    update_risk,
)

__all__ = [
    # Graph
    "AffectedComponent",
    "BlastRadiusResult",
    "ChangeEvaluation",
    "ChangeType",
    "ComponentContext",
    "ConstraintConflict",
    "CycleInfo",
    "Direction",
    "RelationshipGraph",
    "SPOFInfo",
    "evaluate_proposed_change",
    "get_blast_radius",
    "get_component_context",
    "get_constraints_for_components",
    # Integrity
    "IntegrityViolation",
    "RemoveBlockedDetail",
    "build_reference_index",
    "check_id_uniqueness",
    "check_referential_integrity",
    "check_remove_blocked",
    # Merge
    "FieldMergeRecord",
    "MergeResolution",
    "MergeResult",
    "merge_object",
    # Merge log
    "MergeLogEntry",
    "create_entry",
    "deserialize_entry",
    "serialize_entry",
    # Versioning
    "VersionBump",
    "increment_version",
    # Write pipeline
    "OperationType",
    "WriteError",
    "WriteResult",
    "register_component",
    "register_constraint",
    "register_decision",
    "register_relationship",
    "register_risk",
    "remove_component",
    "remove_constraint",
    "remove_decision",
    "remove_relationship",
    "remove_risk",
    "update_component",
    "update_constraint",
    "update_decision",
    "update_relationship",
    "update_risk",
]
