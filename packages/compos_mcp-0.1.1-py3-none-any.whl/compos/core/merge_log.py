"""Merge log data model (append-only, queryable by version range).

Owns the data model and serialization only. File I/O is in storage/merge_log.py.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from pydantic import AwareDatetime

from compos.core.merge import FieldMergeRecord, MergeResolution, MergeResult
from compos.core.versioning import VersionBump
from compos.schema.models import ProvenanceSource


@dataclass(frozen=True, slots=True)
class MergeLogEntry:
    """One merge operation record — serialized as one JSONL line."""

    map_version: int
    timestamp: AwareDatetime
    operation: str
    target_id: str
    target_type: str
    source: ProvenanceSource
    field_records: tuple[FieldMergeRecord, ...]
    outcome: str  # "accepted", "partially_rejected", "fully_rejected"


def _compute_outcome(merge_result: MergeResult | None) -> str:
    """Derive outcome from merge result."""
    if merge_result is None:
        return "accepted"  # register — no merge needed
    if not merge_result.has_rejections:
        return "accepted"
    # Check if ALL fields were rejected
    if merge_result.field_records and all(
        r.resolution == MergeResolution.REJECTED for r in merge_result.field_records
    ):
        return "fully_rejected"
    return "partially_rejected"


def create_entry(
    version_bump: VersionBump,
    operation: str,
    target_id: str,
    target_type: str,
    source: ProvenanceSource,
    merge_result: MergeResult | None,
) -> MergeLogEntry:
    """Assemble a MergeLogEntry from pipeline outputs."""
    return MergeLogEntry(
        map_version=version_bump.new_version,
        timestamp=version_bump.generated_at,
        operation=operation,
        target_id=target_id,
        target_type=target_type,
        source=source,
        field_records=merge_result.field_records if merge_result else (),
        outcome=_compute_outcome(merge_result),
    )


def _field_record_to_dict(record: FieldMergeRecord) -> dict[str, Any]:
    """Serialize a FieldMergeRecord to a JSON-safe dict."""
    return {
        "field_name": record.field_name,
        "resolution": record.resolution.value,
        "reason": record.reason,
        "old_value": record.old_value,
        "new_value": record.new_value,
        "old_source": record.old_source.value,
        "new_source": record.new_source.value,
        "old_timestamp": record.old_timestamp.isoformat(),
        "new_timestamp": record.new_timestamp.isoformat(),
    }


def _field_record_from_dict(data: dict[str, Any]) -> FieldMergeRecord:
    """Deserialize a FieldMergeRecord from a dict."""
    return FieldMergeRecord(
        field_name=data["field_name"],
        resolution=MergeResolution(data["resolution"]),
        reason=data["reason"],
        old_value=data["old_value"],
        new_value=data["new_value"],
        old_source=ProvenanceSource(data["old_source"]),
        new_source=ProvenanceSource(data["new_source"]),
        old_timestamp=datetime.fromisoformat(data["old_timestamp"]),
        new_timestamp=datetime.fromisoformat(data["new_timestamp"]),
    )


def serialize_entry(entry: MergeLogEntry) -> str:
    """Serialize a MergeLogEntry to a single JSON line (no trailing newline)."""
    data = {
        "map_version": entry.map_version,
        "timestamp": entry.timestamp.isoformat(),
        "operation": entry.operation,
        "target_id": entry.target_id,
        "target_type": entry.target_type,
        "source": entry.source.value,
        "field_records": [_field_record_to_dict(r) for r in entry.field_records],
        "outcome": entry.outcome,
    }
    return json.dumps(data, separators=(",", ":"))


def deserialize_entry(line: str) -> MergeLogEntry:
    """Deserialize a single JSONL line into a MergeLogEntry."""
    data = json.loads(line)
    return MergeLogEntry(
        map_version=data["map_version"],
        timestamp=datetime.fromisoformat(data["timestamp"]),
        operation=data["operation"],
        target_id=data["target_id"],
        target_type=data["target_type"],
        source=ProvenanceSource(data["source"]),
        field_records=tuple(
            _field_record_from_dict(r) for r in data["field_records"]
        ),
        outcome=data["outcome"],
    )
