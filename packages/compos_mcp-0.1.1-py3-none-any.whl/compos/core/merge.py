"""Merge engine (3-source priority hierarchy).

Implements field-level merge logic for updates. When a write modifies a
field that already has a value from a different provenance source, the
merge engine decides whether to allow it.

Priority hierarchy (inviolable):
    human-input > ai-annotated > static-analysis

All functions are pure — no I/O, no side effects.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from pydantic import AwareDatetime

from compos.schema.models import (
    Component,
    Constraint,
    Decision,
    ObjectStatus,
    ProvenanceSource,
    Relationship,
    Risk,
)

type MapObject = Component | Relationship | Constraint | Risk | Decision

# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------

class MergeResolution(StrEnum):
    """What the merge engine decided for a field."""

    ACCEPTED = "accepted"
    REJECTED = "rejected"
    ACCEPTED_WITH_WARNING = "warning"


@dataclass(frozen=True, slots=True)
class FieldMergeRecord:
    """One field-level merge decision."""

    field_name: str
    resolution: MergeResolution
    reason: str
    old_value: Any
    new_value: Any
    old_source: ProvenanceSource
    new_source: ProvenanceSource
    old_timestamp: AwareDatetime
    new_timestamp: AwareDatetime


@dataclass(frozen=True, slots=True)
class MergeResult:
    """Result of merging a new object into the map."""

    merged_obj: Any  # the merged schema object
    field_records: tuple[FieldMergeRecord, ...]
    has_rejections: bool
    has_warnings: bool


# ---------------------------------------------------------------------------
# Priority hierarchy
# ---------------------------------------------------------------------------

# Numeric priority: higher number = higher priority
_SOURCE_PRIORITY: dict[ProvenanceSource, int] = {
    ProvenanceSource.STATIC_ANALYSIS: 1,
    ProvenanceSource.AI_ANNOTATED: 2,
    ProvenanceSource.HUMAN_INPUT: 3,
}


def _resolve_priority(
    existing_source: ProvenanceSource,
    incoming_source: ProvenanceSource,
) -> tuple[MergeResolution, str]:
    """Determine whether incoming can overwrite existing based on source priority.

    Returns (resolution, human-readable reason).
    """
    existing_pri = _SOURCE_PRIORITY[existing_source]
    incoming_pri = _SOURCE_PRIORITY[incoming_source]

    if incoming_pri > existing_pri:
        # Higher priority always wins
        return (
            MergeResolution.ACCEPTED,
            f"{incoming_source.value} overrides {existing_source.value}",
        )

    if incoming_pri == existing_pri:
        # Same source — newer timestamp wins (caller handles timestamp check)
        return (
            MergeResolution.ACCEPTED,
            f"Same source ({incoming_source.value}) — most recent wins",
        )

    # incoming_pri < existing_pri — lower priority cannot overwrite higher
    if existing_source == ProvenanceSource.HUMAN_INPUT:
        if incoming_source == ProvenanceSource.AI_ANNOTATED:
            return (
                MergeResolution.REJECTED,
                "AI attempted to overwrite a human-corrected field",
            )
        return (
            MergeResolution.REJECTED,
            "Static analysis cannot overwrite human input",
        )

    # existing is AI, incoming is static — Rule 4
    return (
        MergeResolution.REJECTED,
        "Static analysis cannot overwrite AI annotation — flagged for human review",
    )


# ---------------------------------------------------------------------------
# Field-level merge
# ---------------------------------------------------------------------------

# Fields to skip during field-level comparison — handled specially
_SKIP_FIELDS: frozenset[str] = frozenset({
    "id",                     # immutable identifier
    "provenance",             # compared separately for source/timestamp
    "annotation_confidence",  # tied to provenance, not independently merged
    "prior",                  # pipeline-controlled, never from incoming
})


def merge_object(
    existing: MapObject,
    incoming: MapObject,
) -> MergeResult:
    """Merge an incoming object update into the existing object.

    Compares fields, applies the 3-source priority hierarchy, and constructs
    the merged object with updated _prior. The incoming object's _prior is
    ignored (pipeline-controlled).

    Special case: if existing is removed by human and incoming tries to
    reinstate from a lower-priority source, the removal wins (Rule 1).
    """
    # Rule 1: Human deletion vs. lower-priority reinstatement
    if (
        hasattr(existing, "status")
        and hasattr(existing, "removed_at")
        and str(existing.status) == str(ObjectStatus.REMOVED)
        and existing.provenance.source == ProvenanceSource.HUMAN_INPUT
        and incoming.provenance.source != ProvenanceSource.HUMAN_INPUT
    ):
        record = FieldMergeRecord(
            field_name="status",
            resolution=MergeResolution.REJECTED,
            reason="Human deletion wins — component not reinstated",
            old_value=str(existing.status),
            new_value=str(incoming.status),
            old_source=ProvenanceSource(existing.provenance.source),
            new_source=ProvenanceSource(incoming.provenance.source),
            old_timestamp=existing.provenance.timestamp,
            new_timestamp=incoming.provenance.timestamp,
        )
        return MergeResult(
            merged_obj=existing,
            field_records=(record,),
            has_rejections=True,
            has_warnings=False,
        )

    # Compare fields
    field_records: list[FieldMergeRecord] = []
    merged_values: dict[str, Any] = {}
    prior_updates: dict[str, dict[str, Any]] = {}

    # Get existing _prior or empty dict
    existing_prior: dict[str, Any] = {}
    if hasattr(existing, "prior") and existing.prior is not None:
        existing_prior = dict(existing.prior)

    # Get model fields to compare
    existing_data = existing.model_dump(by_alias=False)
    incoming_data = incoming.model_dump(by_alias=False)

    existing_source = ProvenanceSource(existing.provenance.source)
    incoming_source = ProvenanceSource(incoming.provenance.source)

    has_rejections = False
    has_warnings = False

    for field_name in existing_data:
        if field_name in _SKIP_FIELDS:
            continue

        old_val = existing_data[field_name]
        new_val = incoming_data.get(field_name, old_val)

        if old_val == new_val:
            merged_values[field_name] = old_val
            continue

        # Field differs — resolve using priority hierarchy
        resolution, reason = _resolve_priority(existing_source, incoming_source)

        # Rule 5: AI vs AI confidence delta check
        if (
            resolution == MergeResolution.ACCEPTED
            and existing_source == ProvenanceSource.AI_ANNOTATED
            and incoming_source == ProvenanceSource.AI_ANNOTATED
        ):
            existing_conf = getattr(existing, "annotation_confidence", None)
            incoming_conf = getattr(incoming, "annotation_confidence", None)
            if (
                existing_conf is not None
                and incoming_conf is not None
                and abs(existing_conf - incoming_conf) > 0.3
            ):
                resolution = MergeResolution.ACCEPTED_WITH_WARNING
                reason = (
                    f"AI confidence delta {abs(existing_conf - incoming_conf):.2f}"
                    " > 0.3 — flagged for human review"
                )

        record = FieldMergeRecord(
            field_name=field_name,
            resolution=resolution,
            reason=reason,
            old_value=old_val,
            new_value=new_val,
            old_source=existing_source,
            new_source=incoming_source,
            old_timestamp=existing.provenance.timestamp,
            new_timestamp=incoming.provenance.timestamp,
        )
        field_records.append(record)

        if resolution == MergeResolution.REJECTED:
            has_rejections = True
            merged_values[field_name] = old_val  # keep existing
        else:
            if resolution == MergeResolution.ACCEPTED_WITH_WARNING:
                has_warnings = True
            merged_values[field_name] = new_val  # incoming wins
            # Record old value in _prior with provenance
            prior_updates[field_name] = {
                "value": old_val,
                "source": str(existing_source.value),
                "timestamp": existing.provenance.timestamp.isoformat(),
            }

    # Build final _prior: existing prior + new overrides
    final_prior = (
        {**existing_prior, **prior_updates}
        if (existing_prior or prior_updates)
        else None
    )

    # Construct merged object
    merged_data = existing_data.copy()
    merged_data.update(merged_values)

    # Use incoming provenance if any field was accepted, else keep existing
    _accepted = (MergeResolution.ACCEPTED, MergeResolution.ACCEPTED_WITH_WARNING)
    accepted_any = any(r.resolution in _accepted for r in field_records)
    if accepted_any:
        merged_data["provenance"] = incoming_data["provenance"]
        if incoming.annotation_confidence is not None:
            merged_data["annotation_confidence"] = incoming.annotation_confidence

    # Set _prior only for types that support it
    if hasattr(existing, "prior"):
        merged_data["prior"] = final_prior

    # Reconstruct the model
    merged_obj = type(existing).model_validate(merged_data)

    return MergeResult(
        merged_obj=merged_obj,
        field_records=tuple(field_records),
        has_rejections=has_rejections,
        has_warnings=has_warnings,
    )
