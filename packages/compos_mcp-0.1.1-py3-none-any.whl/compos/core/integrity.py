"""Referential integrity + ID uniqueness checks.

All functions are pure — no I/O, no side effects. They take a ComposMap
and a proposed change, returning violations or None. The write pipeline
calls these as stages 3 and 4 of the validation pipeline.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from compos.schema.models import (
    Component,
    ComposMap,
    Constraint,
    ConstraintStatus,
    Decision,
    DecisionStatus,
    ObjectStatus,
    Relationship,
    Risk,
    RiskStatus,
)

# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class IntegrityViolation:
    """A single integrity violation."""

    violation_type: str  # "dangling_reference", "duplicate_id", "remove_blocked"
    object_type: str  # "component", "relationship", etc.
    object_id: str
    field: str | None  # which field has the bad reference
    referenced_id: str | None  # the dangling ID
    message: str


@dataclass(frozen=True, slots=True)
class RemoveBlockedDetail:
    """An object blocking a removal — part of the impact report."""

    object_type: str  # type of the blocking object
    object_id: str  # ID of the blocking object
    field: str  # which field references the target


# ---------------------------------------------------------------------------
# ID uniqueness (pipeline stage 3)
# ---------------------------------------------------------------------------


def check_id_uniqueness(
    compos_map: ComposMap,
    new_id: str,
    collection: str,
) -> IntegrityViolation | None:
    """Check that new_id does not already exist in the named collection.

    Includes soft-deleted objects — IDs are never reused.
    Returns None if unique, an IntegrityViolation if duplicate.
    """
    items = getattr(compos_map, collection)
    for item in items:
        if item.id == new_id:
            return IntegrityViolation(
                violation_type="duplicate_id",
                object_type=collection.rstrip("s"),  # "components" → "component"
                object_id=new_id,
                field=None,
                referenced_id=None,
                message=(
                    f"ID '{new_id}' already exists in {collection}"
                    f" (use update instead of register)"
                ),
            )
    return None


# Type alias for the union of all writeable object types
type MapObject = Component | Relationship | Constraint | Risk | Decision


# ---------------------------------------------------------------------------
# Referential integrity (pipeline stage 4)
# ---------------------------------------------------------------------------


def _active_ids(compos_map: ComposMap, collection: str) -> frozenset[str]:
    """Return IDs of active (non-removed) objects in a collection.

    Works for all status enums — only ObjectStatus and ConstraintStatus
    define a REMOVED variant; other statuses always pass.
    """
    items = getattr(compos_map, collection)
    removed_statuses = {
        ObjectStatus.REMOVED,
        ConstraintStatus.REMOVED,
        RiskStatus.REMOVED,
        DecisionStatus.REMOVED,
    }
    return frozenset(item.id for item in items if item.status not in removed_statuses)


def _ref_violations(
    object_id: str,
    object_type: str,
    field_name: str,
    referenced_ids: tuple[str, ...],
    valid_ids: frozenset[str],
) -> list[IntegrityViolation]:
    """Check a tuple of referenced IDs against a set of valid IDs."""
    violations: list[IntegrityViolation] = []
    for ref_id in referenced_ids:
        if ref_id not in valid_ids:
            violations.append(
                IntegrityViolation(
                    violation_type="dangling_reference",
                    object_type=object_type,
                    object_id=object_id,
                    field=field_name,
                    referenced_id=ref_id,
                    message=(
                        f"{field_name} references '{ref_id}'"
                        " which does not exist or is removed"
                    ),
                )
            )
    return violations


def check_referential_integrity(
    compos_map: ComposMap,
    obj: MapObject,
) -> tuple[IntegrityViolation, ...]:
    """Validate all ID references in obj resolve to active objects in the map.

    Dispatches by object type:
    - Relationship: source/target must be active component IDs
    - Constraint: applies_to must be active component or relationship IDs
    - Risk: components_involved/relationships_involved must be active
    - Decision: components/relationships_affected + constraints_that_drove_it
    - Component: no outgoing references — always returns empty tuple
    """
    violations: list[IntegrityViolation] = []

    if isinstance(obj, Relationship):
        active_comps = _active_ids(compos_map, "components")
        violations.extend(
            _ref_violations(
                obj.id, "relationship", "source", (obj.source,), active_comps
            )
        )
        violations.extend(
            _ref_violations(
                obj.id, "relationship", "target", (obj.target,), active_comps
            )
        )

    elif isinstance(obj, Constraint):
        # Constraints can reference components OR relationships
        active = _active_ids(compos_map, "components") | _active_ids(
            compos_map, "relationships"
        )
        violations.extend(
            _ref_violations(obj.id, "constraint", "applies_to", obj.applies_to, active)
        )

    elif isinstance(obj, Risk):
        active_comps = _active_ids(compos_map, "components")
        active_rels = _active_ids(compos_map, "relationships")
        violations.extend(
            _ref_violations(
                obj.id,
                "risk",
                "components_involved",
                obj.components_involved,
                active_comps,
            )
        )
        violations.extend(
            _ref_violations(
                obj.id,
                "risk",
                "relationships_involved",
                obj.relationships_involved,
                active_rels,
            )
        )

    elif isinstance(obj, Decision):
        active_comps = _active_ids(compos_map, "components")
        active_rels = _active_ids(compos_map, "relationships")
        active_cons = _active_ids(compos_map, "constraints")
        violations.extend(
            _ref_violations(
                obj.id,
                "decision",
                "components_affected",
                obj.components_affected,
                active_comps,
            )
        )
        violations.extend(
            _ref_violations(
                obj.id,
                "decision",
                "relationships_affected",
                obj.relationships_affected,
                active_rels,
            )
        )
        violations.extend(
            _ref_violations(
                obj.id,
                "decision",
                "constraints_that_drove_it",
                obj.constraints_that_drove_it,
                active_cons,
            )
        )

    # Component has no outgoing references — nothing to check

    return tuple(violations)


# ---------------------------------------------------------------------------
# Remove-blocked checks (pipeline stage 5)
# ---------------------------------------------------------------------------


def build_reference_index(
    compos_map: ComposMap,
) -> dict[str, list[RemoveBlockedDetail]]:
    """Build a reverse index: {referenced_id: [objects that reference it]}.

    Single-pass over all collections. Only indexes active (non-removed)
    objects. Used by check_remove_blocked for the impact report.
    """
    removed_statuses = {
        ObjectStatus.REMOVED,
        ConstraintStatus.REMOVED,
        RiskStatus.REMOVED,
        DecisionStatus.REMOVED,
    }
    index: dict[str, list[RemoveBlockedDetail]] = defaultdict(list)

    for rel in compos_map.relationships:
        if rel.status in removed_statuses:
            continue
        index[rel.source].append(
            RemoveBlockedDetail(
                object_type="relationship",
                object_id=rel.id,
                field="source",
            )
        )
        index[rel.target].append(
            RemoveBlockedDetail(
                object_type="relationship",
                object_id=rel.id,
                field="target",
            )
        )

    for con in compos_map.constraints:
        if con.status in removed_statuses:
            continue
        for ref_id in con.applies_to:
            index[ref_id].append(
                RemoveBlockedDetail(
                    object_type="constraint",
                    object_id=con.id,
                    field="applies_to",
                )
            )

    for risk in compos_map.risks:
        if risk.status == RiskStatus.REMOVED:
            continue
        for ref_id in risk.components_involved:
            index[ref_id].append(
                RemoveBlockedDetail(
                    object_type="risk",
                    object_id=risk.id,
                    field="components_involved",
                )
            )
        for ref_id in risk.relationships_involved:
            index[ref_id].append(
                RemoveBlockedDetail(
                    object_type="risk",
                    object_id=risk.id,
                    field="relationships_involved",
                )
            )

    for dec in compos_map.decisions:
        if dec.status in {DecisionStatus.REVERSED, DecisionStatus.REMOVED}:
            continue
        for ref_id in dec.components_affected:
            index[ref_id].append(
                RemoveBlockedDetail(
                    object_type="decision",
                    object_id=dec.id,
                    field="components_affected",
                )
            )
        for ref_id in dec.relationships_affected:
            index[ref_id].append(
                RemoveBlockedDetail(
                    object_type="decision",
                    object_id=dec.id,
                    field="relationships_affected",
                )
            )
        for ref_id in dec.constraints_that_drove_it:
            index[ref_id].append(
                RemoveBlockedDetail(
                    object_type="decision",
                    object_id=dec.id,
                    field="constraints_that_drove_it",
                )
            )

    return dict(index)


def check_remove_blocked(
    compos_map: ComposMap,
    target_id: str,
    target_type: str,
) -> tuple[RemoveBlockedDetail, ...]:
    """Return all active objects that reference target_id.

    If non-empty, the removal is blocked. The returned list IS the
    impact report — it tells the caller exactly what must be removed
    or updated first.
    """
    index = build_reference_index(compos_map)
    return tuple(index.get(target_id, []))
