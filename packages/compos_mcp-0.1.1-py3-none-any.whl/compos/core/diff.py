"""Architectural diff between two ComposMap versions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from compos.schema.models import ComposMap

_IGNORED_FIELDS = frozenset({
    "_prior", "prior", "provenance",
    "annotation_confidence", "detection_confidence",
})


@dataclass(frozen=True, slots=True)
class ObjectChange:
    """A single added/removed/modified object."""
    id: str
    name: str
    change_type: str
    object_type: str
    details: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class MapDiff:
    """Structural difference between two ComposMap versions."""
    from_version: int
    to_version: int
    added_components: tuple[ObjectChange, ...]
    removed_components: tuple[ObjectChange, ...]
    modified_components: tuple[ObjectChange, ...]
    added_relationships: tuple[ObjectChange, ...]
    removed_relationships: tuple[ObjectChange, ...]
    modified_relationships: tuple[ObjectChange, ...]

    @property
    def has_changes(self) -> bool:
        return bool(
            self.added_components or self.removed_components
            or self.modified_components or self.added_relationships
            or self.removed_relationships or self.modified_relationships
        )

    def format_summary(self) -> str:
        hdr = f"Compos diff v{self.from_version}..v{self.to_version}"
        if not self.has_changes:
            return f"{hdr}: no changes"
        lines: list[str] = [f"{hdr}:"]
        for c in self.added_components:
            lines.append(f"  + component '{c.name}' ({c.id})")
        for c in self.removed_components:
            lines.append(f"  - component '{c.name}' ({c.id})")
        for c in self.modified_components:
            lines.append(f"  ~ component '{c.name}' ({c.id})")
            for d in c.details:
                lines.append(f"      {d}")
        for r in self.added_relationships:
            lines.append(f"  + relationship '{r.name}' ({r.id})")
        for r in self.removed_relationships:
            lines.append(f"  - relationship '{r.name}' ({r.id})")
        for r in self.modified_relationships:
            lines.append(f"  ~ relationship '{r.name}' ({r.id})")
            for d in r.details:
                lines.append(f"      {d}")
        return "\n".join(lines)


def _get_name(obj: Any) -> str:
    if hasattr(obj, "name"):
        return str(obj.name)
    return f"{obj.source} -> {obj.target}"


def _compare_fields(from_obj: Any, to_obj: Any) -> tuple[str, ...]:
    from_d = from_obj.model_dump(by_alias=True)
    to_d = to_obj.model_dump(by_alias=True)
    changes: list[str] = []
    for key in from_d:
        if key in _IGNORED_FIELDS:
            continue
        if from_d[key] != to_d[key]:
            changes.append(f"{key}: {from_d[key]} -> {to_d[key]}")
    return tuple(changes)


def _diff_collection(
    from_items: tuple[Any, ...],
    to_items: tuple[Any, ...],
    object_type: str,
) -> tuple[
    tuple[ObjectChange, ...], tuple[ObjectChange, ...], tuple[ObjectChange, ...],
]:
    from_by_id: dict[str, Any] = {item.id: item for item in from_items}
    to_by_id: dict[str, Any] = {item.id: item for item in to_items}
    from_ids = set(from_by_id)
    to_ids = set(to_by_id)

    added = tuple(
        ObjectChange(id=oid, name=_get_name(to_by_id[oid]),
                     change_type="added", object_type=object_type, details=())
        for oid in sorted(to_ids - from_ids)
    )
    removed = tuple(
        ObjectChange(id=oid, name=_get_name(from_by_id[oid]),
                     change_type="removed", object_type=object_type, details=())
        for oid in sorted(from_ids - to_ids)
    )
    modified_list: list[ObjectChange] = []
    for oid in sorted(from_ids & to_ids):
        changes = _compare_fields(from_by_id[oid], to_by_id[oid])
        if changes:
            modified_list.append(ObjectChange(
                id=oid, name=_get_name(from_by_id[oid]),
                change_type="modified", object_type=object_type, details=changes,
            ))
    return added, removed, tuple(modified_list)


def compute_diff(from_map: ComposMap, to_map: ComposMap) -> MapDiff:
    """Compute structural difference between two map versions."""
    ac, rc, mc = _diff_collection(from_map.components, to_map.components, "component")
    ar, rr, mr = _diff_collection(
        from_map.relationships, to_map.relationships, "relationship",
    )
    return MapDiff(
        from_version=from_map.map_version, to_version=to_map.map_version,
        added_components=ac, removed_components=rc, modified_components=mc,
        added_relationships=ar, removed_relationships=rr, modified_relationships=mr,
    )
