"""Map versioning (version increment, parent tracking).

Pure function — computes the next version state without I/O.
The write pipeline applies the VersionBump to construct the new ComposMap.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime

from pydantic import AwareDatetime

from compos.schema.models import ComposMap


@dataclass(frozen=True, slots=True)
class VersionBump:
    """The result of incrementing a map version."""

    new_version: int
    parent_version: int
    generated_at: AwareDatetime
    git_commit: str | None = None


def increment_version(
    current_map: ComposMap,
    git_commit: str | None = None,
) -> VersionBump:
    """Compute the next version from the current map.

    - new_version = current map_version + 1
    - parent_version = current map_version
    - generated_at = now (UTC)
    - git_commit = optionally attached for commit-anchored snapshots
    """
    return VersionBump(
        new_version=current_map.map_version + 1,
        parent_version=current_map.map_version,
        generated_at=datetime.now(UTC),
        git_commit=git_commit,
    )
