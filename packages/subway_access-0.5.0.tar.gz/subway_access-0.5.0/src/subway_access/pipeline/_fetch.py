"""Study area snapshot fetching for ``subway-access``."""

from __future__ import annotations

from dataclasses import asdict
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from nyc_geo_toolkit import (
    boundaries_to_geojson,
    load_nyc_boundaries,
    load_nyc_census_tracts,
)
from shapely.geometry import Point, shape
from shapely.ops import unary_union

from ..io._acs import (
    ACS_5YEAR_YEAR,
    ACS_COUNTS_API_URL,
    ACS_SUBJECT_API_URL,
    fetch_nyc_acs_tract_estimates,
)
from ..io._cache import cache_timestamp, ensure_directory, write_csv_rows, write_json
from ..io._entrances import entrances_to_geojson
from ..io._gtfs_static import (
    gtfs_pathways_snapshot_to_json,
    parse_gtfs_pathways_zip,
)
from ..io._mta import (
    MTA_ELEVATOR_AVAILABILITY_API_URL,
    MTA_EQUIPMENT_ASSET_API_URL,
    MTA_GTFS_STATIC_URL,
    MTA_SUBWAY_ENTRANCES_API_URL,
    MTA_SUBWAY_STATIONS_API_URL,
    build_entrance_snapshot_rows,
    build_outage_snapshot_rows,
    build_station_snapshot_rows,
    fetch_mta_availability_history,
    fetch_mta_equipment_assets,
    fetch_mta_gtfs_archive,
    fetch_mta_station_catalog,
    fetch_mta_subway_entrances,
)
from ..models import (
    AccessibilityQuery,
    DataSourceMetadata,
    StudyAreaSnapshot,
)
from ._load import _snapshot_paths, load_cached_snapshot

_BOROUGH_BY_COUNTY = {
    "005": "Bronx",
    "047": "Brooklyn",
    "061": "Manhattan",
    "081": "Queens",
    "085": "Staten Island",
}


def _first_day_months_ago(months: int) -> date:
    today = datetime.now(tz=timezone.utc).date()
    year = today.year
    month = today.month - months + 1
    while month <= 0:
        month += 12
        year -= 1
    return date(year, month, 1)


def _selected_boundary_geometry(
    query: AccessibilityQuery,
) -> tuple[Any, dict[str, Any]]:
    boundaries = load_nyc_boundaries(query.geography, values=query.value)
    boundary_shapes = [shape(feature.geometry) for feature in boundaries.features]
    study_area_shape = unary_union(boundary_shapes)
    return study_area_shape, boundaries_to_geojson(boundaries)


def _filter_station_rows(
    station_catalog_rows: list[dict[str, Any]],
    *,
    study_area_shape: Any,
) -> list[dict[str, Any]]:
    selected_rows = []
    for row in station_catalog_rows:
        longitude = row.get("gtfs_longitude")
        latitude = row.get("gtfs_latitude")
        if longitude is None or latitude is None:
            continue
        point = Point(float(longitude), float(latitude))
        if study_area_shape.covers(point):
            selected_rows.append(row)
    return selected_rows


def _filter_entrance_rows(
    entrance_rows: list[dict[str, Any]],
    *,
    study_area_shape: Any,
) -> list[dict[str, Any]]:
    """Keep entrance API rows whose coordinates fall inside the study area."""

    selected_rows: list[dict[str, Any]] = []
    for row in entrance_rows:
        lat = row.get("entrance_latitude")
        lon = row.get("entrance_longitude")
        if lat is None or lon is None:
            continue
        try:
            flat = float(str(lat).strip())
            flon = float(str(lon).strip())
        except (TypeError, ValueError):
            continue
        geo = row.get("entrance_georeference")
        if isinstance(geo, dict) and geo.get("type") == "Point":
            coords = geo.get("coordinates")
            if isinstance(coords, list) and len(coords) >= 2:
                flon = float(coords[0])
                flat = float(coords[1])
        point = Point(flon, flat)
        if study_area_shape.covers(point):
            selected_rows.append(row)
    return selected_rows


def _selected_tract_features(
    query: AccessibilityQuery,
    *,
    study_area_shape: Any,
) -> list[Any]:
    tract_boundaries = load_nyc_census_tracts()
    selected_features = []
    for feature in tract_boundaries.features:
        tract_shape = shape(feature.geometry)
        if study_area_shape.covers(tract_shape.centroid):
            selected_features.append(feature)
    if not selected_features:
        message = f"No census tracts intersect the requested study area {query!r}."
        raise ValueError(message)
    return selected_features


def _build_demographic_snapshot_features(
    tract_features: list[Any],
    estimates: dict[str, dict[str, object]],
) -> list[dict[str, Any]]:
    features: list[dict[str, Any]] = []
    for feature in tract_features:
        tract_id = feature.geography_value
        estimate = estimates.get(tract_id)
        if estimate is None:
            continue
        centroid = shape(feature.geometry).centroid
        county_code = tract_id[2:5]
        features.append(
            {
                "type": "Feature",
                "properties": {
                    "tract_id": tract_id,
                    "tract_name": str(estimate["tract_name"]),
                    "borough": _BOROUGH_BY_COUNTY.get(county_code, ""),
                    "centroid_latitude": centroid.y,
                    "centroid_longitude": centroid.x,
                    "disability_rate": estimate["disability_rate"],
                    "senior_rate": estimate["senior_rate"],
                    "poverty_rate": estimate["poverty_rate"],
                    "population": estimate["total_population"],
                },
                "geometry": {
                    "type": "Point",
                    "coordinates": [centroid.x, centroid.y],
                },
            }
        )
    return features


def fetch_study_area_snapshot(
    query: AccessibilityQuery,
    *,
    cache_dir: str | Path,
    refresh: bool = False,
    availability_months: int = 12,
    include_gtfs_archive: bool = True,
) -> StudyAreaSnapshot:
    """Fetch, cache, and load a real-data study-area snapshot."""

    cache_root = ensure_directory(Path(cache_dir).expanduser().resolve())
    paths = _snapshot_paths(cache_root)
    if (
        not refresh
        and paths["stations"].exists()
        and paths["accessibility"].exists()
        and paths["tracts"].exists()
        and paths["outages"].exists()
        and paths["metadata"].exists()
    ):
        return load_cached_snapshot(cache_root)

    refreshed_at = cache_timestamp()
    study_area_shape, boundary_geojson = _selected_boundary_geometry(query)
    write_json(paths["boundary"], boundary_geojson)

    station_catalog_rows = fetch_mta_station_catalog()
    write_json(paths["station_catalog"], station_catalog_rows)
    selected_station_rows = _filter_station_rows(
        station_catalog_rows,
        study_area_shape=study_area_shape,
    )
    station_rows, accessibility_rows = build_station_snapshot_rows(
        selected_station_rows
    )
    write_csv_rows(
        paths["stations"],
        [dict(row) for row in station_rows],
    )
    write_csv_rows(
        paths["accessibility"],
        [dict(row) for row in accessibility_rows],
    )

    station_complex_ids = tuple(
        sorted(
            {str(row["complex_id"]) for row in station_rows if row.get("complex_id")}
        )
    )
    asset_rows = fetch_mta_equipment_assets(station_complex_ids=station_complex_ids)
    write_json(paths["assets"], asset_rows)

    start_month = _first_day_months_ago(availability_months)
    availability_rows = fetch_mta_availability_history(
        station_complex_ids=station_complex_ids,
        start_month=start_month,
    )
    write_json(paths["availability"], availability_rows)
    write_json(paths["outages"], build_outage_snapshot_rows(availability_rows))

    entrance_catalog_rows = fetch_mta_subway_entrances()
    selected_entrance_rows = _filter_entrance_rows(
        entrance_catalog_rows,
        study_area_shape=study_area_shape,
    )
    normalized_entrances = build_entrance_snapshot_rows(selected_entrance_rows)
    write_json(paths["entrances"], entrances_to_geojson(normalized_entrances))

    pathways_snapshot = None
    if include_gtfs_archive:
        fetch_mta_gtfs_archive(paths["gtfs_archive"], refresh=refresh)
        if paths["gtfs_archive"].exists():
            pathways_snapshot = parse_gtfs_pathways_zip(paths["gtfs_archive"])
            if pathways_snapshot is not None:
                write_json(
                    paths["gtfs_pathways"],
                    gtfs_pathways_snapshot_to_json(pathways_snapshot),
                )

    tract_features = _selected_tract_features(query, study_area_shape=study_area_shape)
    tract_geoids = tuple(feature.geography_value for feature in tract_features)
    acs_estimates = fetch_nyc_acs_tract_estimates(tract_geoids=tract_geoids)
    tract_payload = {
        "type": "FeatureCollection",
        "features": _build_demographic_snapshot_features(tract_features, acs_estimates),
    }
    write_json(paths["tracts"], tract_payload)

    metadata_items: list[DataSourceMetadata] = [
        DataSourceMetadata(
            name="mta_station_catalog",
            source_url=MTA_SUBWAY_STATIONS_API_URL,
            cache_path=paths["station_catalog"],
            refreshed_at=datetime.fromisoformat(refreshed_at),
            record_count=len(selected_station_rows),
            notes="Filtered in memory against the selected study area boundary.",
        ),
        DataSourceMetadata(
            name="mta_equipment_assets",
            source_url=MTA_EQUIPMENT_ASSET_API_URL,
            cache_path=paths["assets"],
            refreshed_at=datetime.fromisoformat(refreshed_at),
            record_count=len(asset_rows),
        ),
        DataSourceMetadata(
            name="mta_availability_history",
            source_url=MTA_ELEVATOR_AVAILABILITY_API_URL,
            cache_path=paths["availability"],
            refreshed_at=datetime.fromisoformat(refreshed_at),
            record_count=len(availability_rows),
            notes=f"Monthly availability rows since {start_month.isoformat()}.",
        ),
        DataSourceMetadata(
            name="mta_subway_entrances",
            source_url=MTA_SUBWAY_ENTRANCES_API_URL,
            cache_path=paths["entrances"],
            refreshed_at=datetime.fromisoformat(refreshed_at),
            record_count=len(normalized_entrances),
            notes="Filtered in memory against the selected study area boundary.",
        ),
        DataSourceMetadata(
            name="acs_tract_demographics",
            source_url=f"{ACS_COUNTS_API_URL} and {ACS_SUBJECT_API_URL}",
            cache_path=paths["tracts"],
            refreshed_at=datetime.fromisoformat(refreshed_at),
            record_count=len(tract_payload["features"]),
            notes=f"ACS 5-year {ACS_5YEAR_YEAR} estimates merged to NYC tract centroids.",
        ),
    ]
    if pathways_snapshot is not None:
        metadata_items.append(
            DataSourceMetadata(
                name="gtfs_pathways_static",
                source_url=MTA_GTFS_STATIC_URL,
                cache_path=paths["gtfs_pathways"],
                refreshed_at=datetime.fromisoformat(refreshed_at),
                record_count=len(pathways_snapshot.pathways)
                + len(pathways_snapshot.locations),
                notes="Parsed from GTFS zip when pathways.txt or locations.txt exists.",
            ),
        )
    metadata = tuple(metadata_items)
    metadata_payload = {
        "generated_at": refreshed_at,
        "query": asdict(query),
        "sources": [
            {
                "name": item.name,
                "source_url": item.source_url,
                "cache_path": str(item.cache_path),
                "refreshed_at": item.refreshed_at.isoformat(),
                "record_count": item.record_count,
                "notes": item.notes,
            }
            for item in metadata
        ],
        "include_gtfs_archive": include_gtfs_archive,
        "gtfs_archive_path": str(paths["gtfs_archive"])
        if include_gtfs_archive
        else None,
        "gtfs_archive_url": MTA_GTFS_STATIC_URL if include_gtfs_archive else None,
    }
    write_json(paths["metadata"], metadata_payload)
    return load_cached_snapshot(cache_root)
