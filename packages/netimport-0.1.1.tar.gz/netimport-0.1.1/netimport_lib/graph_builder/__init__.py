"""Dependency graph construction helpers."""
