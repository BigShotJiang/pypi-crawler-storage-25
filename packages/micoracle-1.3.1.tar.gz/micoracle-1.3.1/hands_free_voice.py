#!/usr/bin/env python3
"""Global VoiceCode — hands-free voice input, cross-platform.

Flow:
  1. Continuously listens to the mic (no fixed windows).
  2. WebRTC VAD detects speech start/stop with a 300 ms preroll buffer.
  3. A pluggable STT backend (MLX / faster-whisper / OpenAI / Azure) transcribes
     the captured utterance.
  4. If the text starts with "claude" / "codex" (fuzzy), the remainder is pasted
     into the target app via the platform adapter (macOS / Linux / Windows).
  5. Short spoken status cues ("listening", "sent", "error") go out via the
     pluggable TTS backend (macOS say / pyttsx3 / OpenAI / Azure).

OS is auto-detected. Backends default to the best local option per platform,
override via CLI flag or env var.
"""

from __future__ import annotations

import argparse
import difflib
import os
import platform
import queue
import sys
import threading
import time
from pathlib import Path

import numpy as np

import platform_adapter as _pa
import stt as _stt
import tts as _tts
from safety import SafetyPipeline
from segmenter import VADSegmenter
from wakeword import WakeWordGate, mlx_repo_for as _mlx_repo_for


# ──────────────────────────── .env loader ─────────────────────────


def _load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _load_env_files() -> None:
    """Load runtime config from the invocation directory, then package dir.

    In a source checkout those are usually the same directory. In a PyPI install
    ``__file__`` points at site-packages, so the user's local .env must be read
    from the current working directory to preserve repo-run behavior.
    """
    seen: set[Path] = set()
    for path in (Path.cwd() / ".env", Path(__file__).resolve().parent / ".env"):
        resolved = path.resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        _load_dotenv(path)


_load_env_files()


# ──────────────────────────── constants ───────────────────────────


SAMPLE_RATE = 16000
FRAME_MS = 30
FRAME_SAMPLES = SAMPLE_RATE * FRAME_MS // 1000

MIN_SPEECH_FRAMES = 4          # ~120 ms before we lock in speech state
MAX_SILENCE_FRAMES = 28        # ~840 ms of silence ends an utterance
MAX_UTTERANCE_FRAMES = 600     # ~18 s cap per utterance
PREROLL_FRAMES = 10            # ~300 ms of audio retained before onset
VAD_AGGRESSIVENESS = 2         # 0-3; matches remote — change to 3 only in noisy rooms

FOLLOWUP_TIMEOUT_SECS = 8.0    # how long to stay armed after a bare wake word
WAKE_FUZZY_THRESHOLD = 0.72
CHECK_FIRST_N_WORDS = 1

WAKE_VARIANTS: dict[str, set[str]] = {
    "claude": {
        "claude", "clawed", "clod", "cloudy", "clyde", "claud", "cloth",
        "cloud",   # MLX medium commonly transcribes 'claude' as 'cloud'
        "clade", "clawd", "claw",
    },
    "codex": {
        "codex", "codec", "codecs", "coded", "coed", "goodx", "godex",
        "codecs", "coedx", "kotex",
    },
}

# Phrases Whisper hallucinates on silence. Swallowed before wake-word routing
# so they never consume an armed follow-up slot.
SILENCE_HALLUCINATIONS = {
    "thank you", "thank you.", "thanks", "thanks.", "thanks for watching",
    "thanks for watching.", "amen", "amen.", "you", "you.", "bye", "bye.",
    ".", "okay", "okay.", "ok", "ok.",
}


# ─────────────────────────── text utilities ───────────────────────


def detect_wake_word(text: str) -> tuple[str | None, int]:
    words = [w.strip(",.!?;:\"'") for w in text.split() if w.strip(",.!?;:\"'")]
    for idx, word in enumerate(words[:CHECK_FIRST_N_WORDS]):
        lw = word.lower()
        for wake, variants in WAKE_VARIANTS.items():
            if lw in variants:
                return wake, idx
            for variant in variants:
                if difflib.SequenceMatcher(None, lw, variant).ratio() >= WAKE_FUZZY_THRESHOLD:
                    return wake, idx
    return None, -1


def extract_command(text: str, wake_idx: int) -> str:
    return " ".join(text.split()[wake_idx + 1:]).strip(" ,.!?;:")


def looks_hallucinated(text: str) -> bool:
    words = text.lower().split()
    if len(words) < 9:
        return False
    for size in (3, 4, 5, 6):
        if len(words) < size * 3:
            continue
        for i in range(len(words) - size * 3 + 1):
            chunk = words[i:i + size]
            if (words[i + size:i + 2 * size] == chunk
                    and words[i + 2 * size:i + 3 * size] == chunk):
                return True
    return False


def is_silence_hallucination(text: str) -> bool:
    return text.strip().lower() in SILENCE_HALLUCINATIONS


# ──────────────────────────── wake state ──────────────────────────


class WakeState:
    """Remembers which wake word is 'armed' for a follow-up utterance."""

    def __init__(self) -> None:
        self._backend: str | None = None
        self._expires_at: float = 0.0

    def arm(self, backend: str, timeout_secs: float = FOLLOWUP_TIMEOUT_SECS) -> None:
        self._backend = backend
        self._expires_at = time.monotonic() + timeout_secs

    def clear(self) -> None:
        self._backend = None
        self._expires_at = 0.0

    def active_backend(self) -> str | None:
        if not self._backend:
            return None
        if time.monotonic() > self._expires_at:
            self.clear()
            return None
        return self._backend


# ──────────────────────── noise / speaker helpers ─────────────────

SPEAKER_PROFILE_PATH = Path.home() / ".config" / "micoracle" / "speaker.npy"


def measure_noise_floor(device: int | None, sample_rate: int, duration_s: float = 1.5) -> float:
    """Record ambient noise and return RMS — used to set an adaptive gate threshold."""
    import sounddevice as sd
    frames = int(sample_rate * duration_s)
    print(f"  Measuring ambient noise ({duration_s:.0f}s) — stay quiet...", flush=True)
    rec = sd.rec(frames, samplerate=sample_rate, channels=1, dtype="int16", device=device)
    sd.wait()
    return float(np.sqrt(np.mean(rec.astype(np.float32) ** 2)))


def denoise(pcm_int16: np.ndarray, sample_rate: int) -> np.ndarray:
    """Spectral noise reduction — requires `pip install noisereduce` (optional)."""
    try:
        import noisereduce as nr  # type: ignore
        audio_f32 = pcm_int16.astype(np.float32) / 32768.0
        reduced = nr.reduce_noise(y=audio_f32, sr=sample_rate, stationary=False,
                                  prop_decrease=0.75)
        return (reduced * 32768.0).clip(-32768, 32767).astype(np.int16)
    except ImportError:
        return pcm_int16


def enroll_speaker(device: int | None, sample_rate: int, duration_s: float = 8.0) -> int:
    """Record user's voice and save a speaker embedding to disk."""
    try:
        from resemblyzer import VoiceEncoder, preprocess_wav  # type: ignore
    except ImportError:
        print("resemblyzer not installed. Run: pip install resemblyzer", file=sys.stderr)
        return 1
    import sounddevice as sd

    print(f"Speak naturally for {duration_s:.0f} seconds to enroll your voice...")
    print("Recording in 2 seconds — start speaking when you see GO:")
    time.sleep(2)
    print("GO →", flush=True)
    frames = int(sample_rate * duration_s)
    rec = sd.rec(frames, samplerate=sample_rate, channels=1, dtype="float32", device=device)
    sd.wait()
    print("Done. Saving speaker profile...", flush=True)
    audio = rec.flatten()
    wav = preprocess_wav(audio, source_sr=sample_rate)
    encoder = VoiceEncoder()
    embedding = encoder.embed_utterance(wav)
    SPEAKER_PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    np.save(str(SPEAKER_PROFILE_PATH), embedding)
    print(f"Speaker profile saved → {SPEAKER_PROFILE_PATH}")
    print("Run `micoracle` to start — only your voice will be accepted.")
    return 0


def load_speaker_embedding() -> "np.ndarray | None":
    if not SPEAKER_PROFILE_PATH.exists():
        return None
    return np.load(str(SPEAKER_PROFILE_PATH))


def load_voice_encoder():
    """Load resemblyzer VoiceEncoder once at startup. Returns None if not installed."""
    try:
        from resemblyzer import VoiceEncoder  # type: ignore
        return VoiceEncoder()
    except ImportError:
        return None


def speaker_similarity(pcm_int16: np.ndarray, sample_rate: int,
                        enrolled: np.ndarray, encoder: object) -> float:
    """Return cosine similarity [0-1] between pcm audio and enrolled speaker.

    Encoder must be a pre-loaded VoiceEncoder instance — never create it per-call.
    """
    try:
        from resemblyzer import preprocess_wav  # type: ignore
        audio_f32 = pcm_int16.astype(np.float32) / 32768.0
        wav = preprocess_wav(audio_f32, source_sr=sample_rate)
        embedding = encoder.embed_utterance(wav)  # type: ignore
        dot = float(np.dot(enrolled, embedding))
        norm = float(np.linalg.norm(enrolled) * np.linalg.norm(embedding))
        return dot / norm if norm > 0 else 0.0
    except Exception:
        return 1.0


# ──────────────────────── audio / device helpers ──────────────────


def list_input_devices() -> list[tuple[int, dict]]:
    import sounddevice as sd
    return [
        (idx, d) for idx, d in enumerate(sd.query_devices())
        if d["max_input_channels"] > 0
    ]


def resolve_input_device(device_hint: str) -> int | None:
    import sounddevice as sd
    devices = list_input_devices()
    if not devices:
        raise RuntimeError(
            "No audio input devices found. Grant microphone access to your "
            "terminal and run with --list-devices to verify."
        )
    if device_hint:
        if device_hint.isdigit():
            idx = int(device_hint)
            info = sd.query_devices(idx)
            if info["max_input_channels"] <= 0:
                raise RuntimeError(f"Device {idx} is not an input.")
            return idx
        lowered = device_hint.lower()
        for idx, d in devices:
            if lowered in d["name"].lower():
                return idx
        raise RuntimeError(
            f"No input device matched '{device_hint}'. Run with --list-devices."
        )
    default = sd.default.device[0]
    if isinstance(default, int) and default >= 0:
        info = sd.query_devices(default)
        if info["max_input_channels"] > 0:
            return default
    return devices[0][0]


# ───────────────────────── hardware detection ─────────────────────

_HW_CACHE: str | None = None


def detect_hardware() -> str:
    """Return 'apple_silicon', 'cuda_gpu', or 'cpu'."""
    global _HW_CACHE
    if _HW_CACHE:
        return _HW_CACHE
    if platform.system() == "Darwin":
        is_arm = platform.machine() in ("arm64", "aarch64")
        if not is_arm:
            try:
                import subprocess
                out = subprocess.check_output(
                    ["sysctl", "-n", "hw.optional.arm64"],
                    stderr=subprocess.DEVNULL, text=True,
                ).strip()
                is_arm = (out == "1")
            except Exception:
                pass
        if is_arm:
            _HW_CACHE = "apple_silicon"
            return _HW_CACHE
    try:
        import subprocess
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=3,
        )
        if result.returncode == 0 and result.stdout.strip():
            _HW_CACHE = "cuda_gpu"
            return _HW_CACHE
    except Exception:
        pass
    _HW_CACHE = "cpu"
    return _HW_CACHE


def default_model_for_hardware() -> str:
    hw = detect_hardware()
    if hw == "apple_silicon":
        return "medium.en"
    if hw == "cuda_gpu":
        return "medium.en"
    return "tiny.en"          # CPU-only: start small


_MODEL_INFO: list[tuple[str, str, str]] = [
    ("tiny.en",   "39 MB",   "fastest  — CPU-only / low RAM"),
    ("small.en",  "150 MB",  "fast     — good accuracy, 8 GB RAM"),
    ("medium.en", "300 MB",  "balanced — best for M-chip & GPU  ✦"),
    ("large-v3",  "800 MB",  "precise  — slow on CPU, needs 16 GB"),
]


def select_model_interactive() -> str:
    """Show a numbered model menu and return the user's choice."""
    hw = detect_hardware()
    hw_label = {
        "apple_silicon": "Apple Silicon (M-chip)",
        "cuda_gpu":      "CUDA GPU",
        "cpu":           "CPU only",
    }[hw]
    default = default_model_for_hardware()

    print()
    print()
    print("  ┌─ Select Whisper model ────────────────────────────────────────┐")
    print(f"  │  Hardware: {hw_label:<52}│")
    print("  ├───┬──────────────┬──────────┬──────────────────────────────────┤")
    for i, (name, size, desc) in enumerate(_MODEL_INFO, 1):
        marker = " ← default" if name == default else ""
        print(f"  │[{i}]│ {name:<12} │ {size:<8} │ {desc}{marker}")
    print("  └───┴──────────────┴──────────┴──────────────────────────────────┘")

    default_idx = next(i for i, (n, _, _) in enumerate(_MODEL_INFO, 1) if n == default)
    while True:
        try:
            raw = input(f"\n  Enter number [default {default_idx}]: ").strip()
            if not raw:
                return default
            idx = int(raw)
            if 1 <= idx <= len(_MODEL_INFO):
                return _MODEL_INFO[idx - 1][0]
            print(f"  Please enter a number between 1 and {len(_MODEL_INFO)}.")
        except (ValueError, EOFError):
            return default


# ────────────────────────── CLI parsing ───────────────────────────


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Hands-free voice input for terminal code assistants. "
                    "Cross-platform (macOS / Linux / Windows), OS auto-detected.",
    )
    parser.add_argument(
        "--device",
        default=os.environ.get("VOICE_AGENT_INPUT_DEVICE", "").strip(),
        help="Microphone id or name fragment (see --list-devices).",
    )
    parser.add_argument(
        "--list-devices",
        action="store_true",
        help="Print available input devices and exit.",
    )
    parser.add_argument(
        "--target-app",
        default=os.environ.get("VOICE_AGENT_TARGET_APP", "").strip(),
        help="Pin dispatch to a specific app name. Defaults to the frontmost "
             "app at startup. On Wayland, this flag is required.",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("VOICE_AGENT_MODEL", "").strip() or None,
        choices=["tiny.en", "small.en", "medium.en", "large-v3"],
        help="Whisper model. Auto-selected by hardware if not set: "
             "medium.en for M-chip/GPU, tiny.en for CPU-only.",
    )
    parser.add_argument(
        "--select-model",
        action="store_true",
        help="Show an interactive model picker before starting.",
    )
    parser.add_argument(
        "--stt-backend",
        default=os.environ.get("VOICE_AGENT_STT_BACKEND", "auto").strip() or "auto",
        choices=["auto", "mlx", "faster", "openai", "azure", "elevenlabs", "gemini"],
        help="Speech-to-text backend. 'auto' picks MLX on Apple Silicon, "
             "faster-whisper elsewhere.",
    )
    parser.add_argument(
        "--tts-backend",
        default=os.environ.get("VOICE_AGENT_TTS_BACKEND", "auto").strip() or "auto",
        choices=["auto", "say", "pyttsx3", "openai", "azure", "none"],
        help="Text-to-speech backend for status cues. 'auto' picks 'say' on "
             "macOS, 'pyttsx3' elsewhere.",
    )
    parser.add_argument(
        "--no-speak",
        action="store_true",
        help="Equivalent to --tts-backend none.",
    )
    parser.add_argument(
        "--download",
        action="store_true",
        help="Download the Whisper models for your platform and exit.",
    )
    parser.add_argument(
        "--enroll",
        action="store_true",
        help="Record your voice to create a speaker profile (blocks other speakers).",
    )
    parser.add_argument(
        "--denoise",
        action="store_true",
        help="Enable spectral noise reduction via noisereduce (adds ~100ms latency).",
    )
    parser.add_argument(
        "--calibrate",
        action="store_true",
        help="Measure ambient noise floor at startup to set adaptive gate threshold.",
    )
    parser.add_argument(
        "--prewarm",
        action="store_true",
        help="Pre-warm MLX JIT at startup (adds ~3s but first command is instant).",
    )
    parser.add_argument(
        "--speaker-threshold",
        type=float,
        default=float(os.environ.get("VOICE_AGENT_SPEAKER_THRESHOLD", "0.70")),
        help="Min speaker similarity [0-1] when a profile is enrolled. Default: 0.70.",
    )
    parser.add_argument(
        "--debug-stt",
        action="store_true",
        help="Print every MLX transcription to see exactly what the model hears.",
    )
    return parser.parse_args()


# ───────────────────────── model downloader ───────────────────────


def download_models(stt_backend: str = "auto", model: str = "medium.en") -> int:
    backend = stt_backend if stt_backend != "auto" else _stt.auto_select_stt_backend()

    print("micoracle — downloading models")
    print(f"  model : {model}")
    print(f"  backend: {backend}")
    print("=" * 40)

    from huggingface_hub import snapshot_download  # type: ignore

    if backend == "mlx":
        tiny_repo = _mlx_repo_for("tiny.en")
        stt_repo  = os.environ.get("VOICE_AGENT_MLX_REPO", _mlx_repo_for(model))
        print(f"\n[1/2] Gate model  tiny.en  {tiny_repo}  (~39 MB)")
        try:
            snapshot_download(repo_id=tiny_repo)
            print("      done.")
        except Exception as exc:
            print(f"      FAILED: {exc}", file=sys.stderr)
            return 1
        print(f"\n[2/2] STT model   {model}  {stt_repo}  (~300 MB)")
        try:
            snapshot_download(repo_id=stt_repo)
            print("      done.")
        except Exception as exc:
            print(f"      FAILED: {exc}", file=sys.stderr)
            return 1
    else:
        print(f"\n[1/2] Gate model  faster-whisper/tiny.en  (~39 MB)")
        try:
            from faster_whisper import WhisperModel
            WhisperModel("tiny.en", device="cpu", compute_type="int8")
            print("      done.")
        except Exception as exc:
            print(f"      FAILED: {exc}", file=sys.stderr)
            return 1
        print(f"\n[2/2] STT model   faster-whisper/{model}  (~300 MB)")
        try:
            from faster_whisper import WhisperModel
            WhisperModel(model, device="cpu", compute_type="int8")
            print("      done.")
        except Exception as exc:
            print(f"      FAILED: {exc}", file=sys.stderr)
            return 1

    print(f"\nModel ready. Run `micoracle` to start.")
    return 0


# ───────────────────────────── main loop ──────────────────────────


def main() -> int:
    args = parse_args()

    # Resolve model: CLI flag > env var > interactive picker > hardware default
    if args.select_model:
        model = select_model_interactive()
    elif args.model:
        model = args.model
    else:
        model = default_model_for_hardware()

    if args.download:
        return download_models(args.stt_backend, model)

    if args.enroll:
        dev = resolve_input_device(args.device) if not args.list_devices else None
        return enroll_speaker(dev, SAMPLE_RATE)

    if args.list_devices:
        devs = list_input_devices()
        if not devs:
            print("No input devices found.", file=sys.stderr)
            return 1
        print("Input devices:")
        for idx, d in devs:
            print(
                f"  [{idx}] {d['name']} "
                f"(inputs={d['max_input_channels']}, "
                f"default_sr={int(d['default_samplerate'])})"
            )
        return 0

    # Platform adapter — auto-picks MacAdapter / LinuxAdapter / WindowsAdapter.
    try:
        adapter = _pa.get_platform_adapter()
    except RuntimeError as exc:
        print(f"Platform adapter error: {exc}", file=sys.stderr)
        return 1

    # Target app lock.
    target_app = args.target_app.strip()
    if not target_app:
        try:
            target_app = adapter.get_frontmost_app()
        except RuntimeError as exc:
            print(f"Unable to capture frontmost app: {exc}", file=sys.stderr)
            print(
                "Pass --target-app <name> to pin the dispatch target explicitly.",
                file=sys.stderr,
            )
            return 1
    target_app = adapter.normalize_target_app(target_app)
    if target_app not in adapter.supported_apps:
        print(
            f"[warn] target app '{target_app}' is not in the known list for this OS "
            f"(known: {', '.join(sorted(adapter.supported_apps)) or 'none'}); "
            "dispatch may still work.",
            flush=True,
        )

    # STT backend.
    try:
        stt_backend = _stt.make_stt_backend(_stt.STTConfig(
            backend=args.stt_backend,
            mlx_repo=os.environ.get("VOICE_AGENT_MLX_REPO", _mlx_repo_for(model)),
            faster_model=os.environ.get("VOICE_AGENT_FASTER_MODEL", model),
            faster_device=os.environ.get("VOICE_AGENT_FASTER_DEVICE", "auto"),
            faster_compute_type=os.environ.get("VOICE_AGENT_FASTER_COMPUTE", "int8"),
            openai_api_key=os.environ.get("OPENAI_API_KEY"),
            openai_model=os.environ.get("VOICE_AGENT_OPENAI_STT_MODEL", "whisper-1"),
            azure_endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
            azure_api_key=os.environ.get("AZURE_OPENAI_KEY"),
            azure_deployment=os.environ.get("AZURE_WHISPER_DEPLOYMENT", "whisper"),
            elevenlabs_api_key=os.environ.get("ELEVENLABS_API_KEY"),
            elevenlabs_model=os.environ.get("VOICE_AGENT_ELEVENLABS_STT_MODEL", "scribe_v1"),
            gemini_api_key=os.environ.get("GEMINI_API_KEY"),
            gemini_model=os.environ.get("VOICE_AGENT_GEMINI_STT_MODEL", "gemini-2.0-flash"),
        ))
    except Exception as exc:
        print(f"STT backend init failed: {exc}", file=sys.stderr)
        return 1

    # TTS backend.
    tts_choice = "none" if args.no_speak else args.tts_backend
    try:
        tts_backend = _tts.make_tts_backend(_tts.TTSConfig(
            backend=tts_choice,
            voice=os.environ.get("VOICE_AGENT_TTS_VOICE") or None,
            openai_api_key=os.environ.get("OPENAI_API_KEY"),
            openai_voice=os.environ.get("VOICE_AGENT_OPENAI_TTS_VOICE", "alloy"),
            azure_key=os.environ.get("AZURE_SPEECH_KEY"),
            azure_region=os.environ.get("AZURE_SPEECH_REGION"),
            azure_voice=os.environ.get("VOICE_AGENT_AZURE_TTS_VOICE", "en-US-AriaNeural"),
        ))
    except Exception as exc:
        print(f"[warn] TTS backend init failed ({exc}); running silent.", flush=True)
        tts_backend = _tts.SilentTTS()

    # Audio device.
    try:
        device = resolve_input_device(args.device)
    except RuntimeError as exc:
        print(f"Device error: {exc}", file=sys.stderr)
        return 1

    import sounddevice as sd
    import webrtcvad

    vad = webrtcvad.Vad(VAD_AGGRESSIVENESS)
    audio_q: queue.Queue[np.ndarray] = queue.Queue()
    utterance_q: queue.Queue[np.ndarray] = queue.Queue()
    wake_state = WakeState()

    # Adaptive noise floor — optional, off by default to keep startup fast
    adaptive_min_rms = 300  # default static threshold
    if args.calibrate:
        print("Calibrating noise floor...", flush=True)
        noise_floor_rms = measure_noise_floor(device, SAMPLE_RATE)
        adaptive_min_rms = max(300, int(noise_floor_rms * 3.5))
        print(f"  Noise floor: {noise_floor_rms:.0f} RMS  →  threshold: {adaptive_min_rms} RMS", flush=True)

    # Gate always uses tiny.en — fast rejection of non-wake-word audio.
    # STT uses the user's chosen model (default medium.en) for accuracy.
    gate_model = os.environ.get("VOICE_AGENT_GATE_MODEL", "tiny.en")
    gate_repo  = _mlx_repo_for(gate_model)
    print(f"Loading wake-word gate (tiny.en — fast filter)...", flush=True)
    wake_gate = WakeWordGate(model=gate_model, mlx_repo=gate_repo, min_speech_rms=adaptive_min_rms)
    print(f"  Gate ready  ({wake_gate.model_size})", flush=True)
    print(f"  STT model   ({model})", flush=True)

    # Pre-warm: optional — warms both gate (tiny) and STT (medium)
    if args.prewarm and _stt.auto_select_stt_backend() == "mlx":
        print("  Pre-warming MLX models...", flush=True)
        try:
            import mlx_whisper  # type: ignore
            _sil = np.zeros(3200, dtype=np.float32)
            mlx_whisper.transcribe(_sil, path_or_hf_repo=gate_repo,
                                   language="en", fp16=True, word_timestamps=False)
            mlx_whisper.transcribe(_sil, path_or_hf_repo=_mlx_repo_for(model),
                                   language="en", fp16=True, word_timestamps=False)
            print("  MLX ready.", flush=True)
        except Exception:
            pass

    # Speaker profile (optional — only active if user ran --enroll)
    enrolled_embedding = load_speaker_embedding()
    voice_encoder = None
    if enrolled_embedding is not None:
        print("  Loading speaker encoder...", flush=True)
        voice_encoder = load_voice_encoder()
        if voice_encoder is None:
            print("  [warn] resemblyzer not installed — speaker check disabled", flush=True)
            enrolled_embedding = None
        else:
            print(f"  Speaker profile active — threshold {args.speaker_threshold:.2f}", flush=True)
    else:
        print("  No speaker profile — tip: run `micoracle --enroll` to restrict to your voice", flush=True)

    use_denoise = False
    if args.denoise:
        try:
            import noisereduce  # type: ignore  # noqa: F401
            use_denoise = True
            print("  Spectral denoising: on", flush=True)
        except ImportError:
            print("  Spectral denoising: unavailable  (pip install noisereduce)", flush=True)

    safety = SafetyPipeline()

    def worker() -> None:
        while True:
            pcm = utterance_q.get()

            # Drain stale frames — if queue backed up, keep only the latest
            while not utterance_q.empty():
                try:
                    pcm = utterance_q.get_nowait()
                except Exception:
                    break

            # ── Stage 1: wake-word gate (fast — rejects ~95% of audio) ──
            armed = wake_state.active_backend()
            if not armed:
                gate = wake_gate.check(pcm, SAMPLE_RATE)
                if not gate.passed:
                    preview = gate.tiny_text if len(gate.tiny_text) <= 60 else gate.tiny_text[:60] + "…"
                    print(f"[gate blocked] {preview!r}", flush=True)
                    continue
                print(f"[gate passed]  {gate.tiny_text!r}", flush=True)

            # ── Speaker verification (only on gate-passed audio) ─────
            if enrolled_embedding is not None and voice_encoder is not None:
                sim = speaker_similarity(pcm, SAMPLE_RATE, enrolled_embedding, voice_encoder)
                if sim < args.speaker_threshold:
                    print(f"[speaker blocked] sim={sim:.2f}", flush=True)
                    continue

            # ── Spectral denoising (only on gate-passed audio) ───────
            if use_denoise:
                pcm = denoise(pcm, SAMPLE_RATE)

            # ── Stage 2: full STT with accurate model (medium.en) ────
            try:
                text = stt_backend.transcribe(pcm, SAMPLE_RATE)
                if args.debug_stt:
                    print(f"[stt] {text!r}", flush=True)
            except Exception as exc:
                print(f"[transcribe error] {exc}", flush=True)
                tts_backend.speak("error")
                continue
            if not text:
                continue
            if looks_hallucinated(text):
                print(f"[hallucination] {text[:60]}...", flush=True)
                continue
            if is_silence_hallucination(text):
                continue

            armed = wake_state.active_backend()
            if armed:
                wake, idx = detect_wake_word(text)
                if wake:
                    cmd = extract_command(text, idx)
                    if cmd:
                        _dispatch(adapter, target_app, wake, cmd, tts_backend, safety)
                        wake_state.clear()
                    else:
                        wake_state.arm(wake)
                        print(f"[{wake}] listening...", flush=True)
                        tts_backend.speak("listening")
                    continue
                cmd = text.strip(" ,.!?;:")
                if cmd:
                    _dispatch(adapter, target_app, armed, cmd, tts_backend, safety)
                    wake_state.clear()
                else:
                    print(f"[{armed}] empty command, ignored", flush=True)
                    tts_backend.speak("empty")
                continue

            wake, idx = detect_wake_word(text)
            if not wake:
                print(f"[ignored] {text}", flush=True)
                continue
            cmd = extract_command(text, idx)
            if cmd:
                _dispatch(adapter, target_app, wake, cmd, tts_backend, safety)
                wake_state.clear()
            else:
                wake_state.arm(wake)
                print(f"[{wake}] listening...", flush=True)
                tts_backend.speak("listening")

    threading.Thread(target=worker, daemon=True).start()

    def audio_cb(indata, frames, time_info, status):  # noqa: ARG001
        if status:
            print(f"[audio status] {status}", file=sys.stderr, flush=True)
        audio_q.put(indata.copy().flatten())

    stream = sd.InputStream(
        device=device,
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype="int16",
        blocksize=FRAME_SAMPLES,
        callback=audio_cb,
    )
    device_info = sd.query_devices(device)

    print(f"Global VoiceCode ready on {platform.system()} ({platform.machine()}).")
    print(f"  Input device: {device_info['name']}")
    print(f"  STT backend:  {stt_backend.name}")
    print(f"  TTS backend:  {tts_backend.name}")
    print(f"  Target app (locked): {target_app}")
    print("  Say:  'claude, <your prompt>'  or  'codex, <your prompt>'")
    print("  (non-wake-word speech is ignored)")
    print()

    segmenter = VADSegmenter(
        vad=vad,
        sample_rate=SAMPLE_RATE,
        preroll_frames=PREROLL_FRAMES,
        min_speech_frames=MIN_SPEECH_FRAMES,
        max_silence_frames=MAX_SILENCE_FRAMES,
        max_utterance_frames=MAX_UTTERANCE_FRAMES,
    )

    import atexit
    import signal as _signal

    _stop_event = threading.Event()

    def _cleanup():
        """Release mic and kill TTS — called from main thread only."""
        try:
            stream.stop()
        except Exception:
            pass
        try:
            stream.close()
        except Exception:
            pass
        try:
            tts_backend.stop()
        except Exception:
            pass
        # macOS: killall is the correct command (pkill -x is Linux)
        try:
            import subprocess as _sp
            _sp.run(["killall", "say"], capture_output=True)
        except Exception:
            pass
        try:
            import sounddevice as _sd
            _sd.stop()
        except Exception:
            pass

    atexit.register(_cleanup)

    _SENTINEL = None  # pushed to queue to unblock get() on shutdown

    def _signal_handler_with_sentinel(signum=None, frame=None):
        _stop_event.set()
        audio_q.put(_SENTINEL)

    for _sig in (_signal.SIGTERM, _signal.SIGINT):
        _signal.signal(_sig, _signal_handler_with_sentinel)
    try:
        _signal.signal(_signal.SIGHUP, _signal_handler_with_sentinel)
    except (AttributeError, OSError):
        pass

    stream.start()
    try:
        while True:
            frame = audio_q.get()   # blocking — zero latency, no timeout overhead
            if frame is _SENTINEL or _stop_event.is_set():
                break
            pcm = segmenter.process_frame(frame)
            if pcm is not None:
                utterance_q.put(pcm)
    except KeyboardInterrupt:
        pass
    finally:
        _cleanup()


_STOP_WORDS = {
    # articles / prepositions / conjunctions
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "as", "into", "about", "over", "under",
    # pronouns
    "this", "that", "these", "those", "it", "its",
    "i", "you", "he", "she", "we", "they", "me", "him", "her", "us", "them",
    "my", "your", "our", "their",
    # common verbs (too generic for preview)
    "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did",
    "will", "would", "could", "should", "may", "might", "can",
    "get", "got", "getting", "go", "going", "make", "making",
    # question words / adverbs
    "what", "which", "who", "when", "where", "how", "why",
    # filler / conversational
    "please", "just", "now", "here", "there", "all", "some", "any",
    "up", "out", "so", "okay", "ok", "yeah", "yes", "no", "well",
    "basically", "quickly", "simply", "easily", "really", "very",
    "quite", "pretty", "super", "also", "too", "then", "next",
    "gonna", "wanna", "gotta", "let", "lets", "need", "want",
    # coding-context fillers (don't add value to TTS preview)
    "thing", "things", "stuff", "code", "using", "use",
    "new", "old", "simple", "quick", "small", "little", "bit",
    "something", "anything", "everything", "nothing",
    "maybe", "probably", "kind", "sort", "type", "like",
}


def _preview_phrase(command: str, n_words: int = 3) -> str:
    """Return the most meaningful words for TTS confirmation.

    Filters stop words so 'write a snake game in python' speaks 'snake game'
    rather than 'write a snake'.
    """
    words = command.split()
    content = [w.strip(",.!?;:") for w in words
               if w.strip(",.!?;:").lower() not in _STOP_WORDS]
    chosen = content[:n_words] if content else words[:n_words]
    return " ".join(chosen)


def _dispatch(
    adapter: _pa.PlatformAdapter,
    target_app: str,
    wake: str,
    command: str,
    tts: _tts.TTSBackend,
    safety: "SafetyPipeline | None" = None,
) -> None:
    if safety is not None:
        result = safety.check(command)
        for w in result.warnings:
            print(f"[safety] {w}", flush=True)
        if result.blocked:
            print(f"[safety blocked] {result.reason}", flush=True)
            tts.speak("blocked")
            return
        command = result.text   # use redacted version if PII was found

    print(f"[{wake}] -> {command}", flush=True)

    # Speak a 3-4 word preview so user knows what's being sent. Do not delay
    # silent mode; PyPI users commonly run with --no-speak for fastest dispatch.
    if tts.name != "none":
        preview = _preview_phrase(command)
        tts.speak(preview)
        preview_delay = float(os.environ.get("VOICE_AGENT_TTS_PREVIEW_DELAY", "0"))
        if preview_delay > 0:
            time.sleep(preview_delay)

    try:
        adapter.paste_and_return(command, target_app)
    except Exception as exc:
        print(f"[dispatch error] {exc}", flush=True)
        tts.speak("error")
        return
    print(f"[{wake}] sent to {target_app}", flush=True)


if __name__ == "__main__":
    try:
        sys.exit(main() or 0)
    except KeyboardInterrupt:
        print("\nStopped.")
    except Exception as exc:  # pragma: no cover
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
