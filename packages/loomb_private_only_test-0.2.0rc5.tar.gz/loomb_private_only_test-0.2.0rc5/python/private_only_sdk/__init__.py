from ._native import get_magic_number

__version__ = "0.2.0rc5"


__all__ = [
    "__version__",
    "get_magic_number",
]
