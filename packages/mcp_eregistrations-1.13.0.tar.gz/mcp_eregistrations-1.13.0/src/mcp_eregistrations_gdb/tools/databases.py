"""GDB database tools — CRUD, versions, compare, duplicate."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations

from mcp_eregistrations_gdb.gdb_client import (
    GDBClient,
    GDBClientError,
    GDBNotFoundError,
    translate_error,
)
from mcp_eregistrations_gdb.server import mcp
from mcp_eregistrations_gdb.tools import _add_optional

_MAX_BATCH_CODES = 200
_VALID_INCLUDE_FIELDS = {"version", "last_modified", "row_count", "schema_hash"}


def _normalize_modify_response(raw: dict[str, Any]) -> dict[str, Any]:
    """Normalize /api/v1/database/modify response to unambiguous field names.

    The API returns 'catalog_code' which is actually the database code,
    and omits the database name entirely. This renames fields to avoid
    confusion between catalog-level and database-level identifiers.
    """
    result: dict[str, Any] = {"id": raw.get("id")}
    # catalog_code from API is actually the database/catalog shared code
    code = raw.get("catalog_code") or raw.get("code")
    if code is not None:
        result["database_code"] = code
    if raw.get("catalog_id") is not None:
        result["catalog_id"] = raw["catalog_id"]
    if raw.get("catalog_data_index_increment") is not None:
        result["catalog_data_index_increment"] = raw["catalog_data_index_increment"]
    if raw.get("group_id") is not None:
        result["group_id"] = raw["group_id"]
    return result


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_list(
    name_contains: str | None = None,
    code_contains: str | None = None,
    page: int = 1,
    page_size: int = 50,
    instance: str | None = None,
) -> dict[str, Any]:
    """List databases across all catalogs (flattened) with filtering.

    Each database includes its parent catalog_code, catalog_name, catalog_id.

    Args:
        name_contains: Filter by database name (case-insensitive substring).
        code_contains: Filter by database code (case-insensitive substring).
        page: Page number (default: 1).
        page_size: Results per page (default: 50, max: 200).
        instance: Instance name (default: auto-select).

    Returns:
        dict with total_count, page, page_size, has_next, databases.
    """
    page_size = min(page_size, 200)
    try:
        async with GDBClient.for_instance(instance) as client:
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])
            databases: list[dict[str, Any]] = []
            for catalog in catalogs:
                for db in catalog.get("databases", []):
                    databases.append(
                        {
                            "id": db.get("id"),
                            "uuid": db.get("uuid"),
                            "version": db.get("version"),
                            "name": db.get("name"),
                            "code": db.get("code"),
                            "is_draft": db.get("is_draft"),
                            "catalog_code": catalog.get("code"),
                            "catalog_name": catalog.get("name"),
                            "catalog_id": catalog.get("id"),
                        }
                    )

            # Client-side filtering
            if name_contains:
                needle = name_contains.lower()
                databases = [
                    d for d in databases if needle in (d.get("name") or "").lower()
                ]
            if code_contains:
                needle = code_contains.lower()
                databases = [
                    d for d in databases if needle in (d.get("code") or "").lower()
                ]

            total_count = len(databases)

            # Client-side pagination
            start = (page - 1) * page_size
            page_items = databases[start : start + page_size]
            has_next = (start + page_size) < total_count

            return {
                "total_count": total_count,
                "page": page,
                "page_size": page_size,
                "has_next": has_next,
                "databases": page_items,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="database") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_list_status(
    codes: list[str],
    instance: str | None = None,
    include: list[str] | None = None,
) -> dict[str, Any]:
    """Batch status for multiple databases by code. One API call.

    Args:
        codes: Database codes to look up (max 200).
        instance: Instance name (default: auto-select).
        include: Optional fields: "version", "last_modified", "row_count",
            "schema_hash" (default: ["version", "last_modified"]).

    Returns:
        dict keyed by code, each with id, latest_version, is_draft,
        or {error: "not_found"}.
    """
    if not codes:
        raise ToolError("codes list must not be empty.")
    if len(codes) > _MAX_BATCH_CODES:
        raise ToolError(f"Maximum {_MAX_BATCH_CODES} codes per call, got {len(codes)}.")

    include_set = set(include) if include else {"version", "last_modified"}
    invalid = include_set - _VALID_INCLUDE_FIELDS
    if invalid:
        raise ToolError(
            f"Invalid include fields: {sorted(invalid)}. "
            f"Valid: {sorted(_VALID_INCLUDE_FIELDS)}."
        )

    try:
        async with GDBClient.for_instance(instance) as client:
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])

            # code lives on the catalog, not on individual databases
            code_map: dict[str, dict[str, Any]] = {}
            for catalog in catalogs:
                cat_code = catalog.get("code", "")
                if cat_code not in codes:
                    continue
                for db in catalog.get("databases", []):
                    existing = code_map.get(cat_code)
                    db_version = db.get("version", 0)
                    if existing is None or db_version > existing.get(
                        "latest_version", 0
                    ):
                        entry: dict[str, Any] = {
                            "id": db.get("id"),
                            "latest_version": db_version,
                            "is_draft": db.get("is_draft"),
                        }
                        if "last_modified" in include_set:
                            entry["last_modified"] = db.get(
                                "last_modified", db.get("modified")
                            )
                        if "schema_hash" in include_set:
                            schema = db.get("schema")
                            if schema:
                                entry["schema_hash"] = (
                                    "sha256:"
                                    + hashlib.sha256(
                                        json.dumps(schema, sort_keys=True).encode()
                                    ).hexdigest()[:16]
                                )
                            else:
                                entry["schema_hash"] = None
                        code_map[cat_code] = entry

            # Fetch row_count if requested (requires per-database API call)
            if "row_count" in include_set:
                for code, entry in code_map.items():
                    try:
                        page = await client.get_page(
                            f"/api/v1/data/{code.lower()}/any",
                            page=1,
                            page_size=1,
                        )
                        entry["row_count"] = page.get("count", 0)
                    except GDBClientError:
                        entry["row_count"] = None

            # Build response: requested codes in order, missing → error
            result: dict[str, Any] = {}
            for code in codes:
                if code in code_map:
                    result[code] = code_map[code]
                else:
                    result[code] = {"error": "not_found"}

            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="database batch status") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_get_by_code(
    code: str,
    instance: str | None = None,
    version: str = "latest",
) -> dict[str, Any]:
    """Look up a database by code, returning full schema.

    Avoids paginating gdb_catalog_list (50KB+). version='latest' returns
    the highest published version.

    Args:
        code: Database code (e.g. "proc_proc_1").
        instance: Instance name (default: auto-select).
        version: Version to retrieve (default: "latest").

    Returns:
        dict with id, code, version, schema, catalog info.
    """
    try:
        async with GDBClient.for_instance(instance) as client:
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])

            # code lives on the catalog, not on individual databases
            matches: list[dict[str, Any]] = []
            for catalog in catalogs:
                if catalog.get("code") == code:
                    matches.extend(catalog.get("databases", []))

            if not matches:
                raise ToolError(
                    f"No database with code '{code}'. "
                    "Use gdb_catalog_list to discover available databases."
                )

            if version == "latest":
                # Pick the highest published version; fall back to highest draft
                published = [m for m in matches if not m.get("is_draft")]
                pool = published if published else matches
                target = max(pool, key=lambda d: float(d.get("version", 0)))
            else:
                # Find exact version match
                target_matches = [
                    m for m in matches if str(m.get("version")) == version
                ]
                if not target_matches:
                    available = ", ".join(str(m.get("version")) for m in matches)
                    raise ToolError(
                        f"Database '{code}' has no version '{version}'. "
                        f"Available versions: {available}."
                    )
                target = target_matches[0]

            # Fetch full database with schema
            result: dict[str, Any] = await client.get(f"/database/{target['id']}")
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="database", resource_id=code) from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_get(
    database_id: int,
    instance: str | None = None,
) -> dict[str, Any]:
    """Get a single database with full JSON Schema.

    Args:
        database_id: Database ID (integer).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, code, version, json_schema, catalog info.
    """
    try:
        async with GDBClient.for_instance(instance) as client:
            result: dict[str, Any] = await client.get(f"/database/{database_id}")
            return result
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_versions(
    code: str,
    instance: str | None = None,
    include_schema: bool = False,
) -> dict[str, Any]:
    """List all versions of a database code, ordered by version ASC.

    Returns lightweight version entries by default. Set include_schema=True
    to embed the full JSON Schema per version (costs one extra API call
    per version).

    Args:
        code: Database code to look up.
        instance: Instance name (default: auto-select).
        include_schema: Embed full schema per version (default: False).

    Returns:
        dict with code, count, versions.
    """
    try:
        async with GDBClient.for_instance(instance) as client:
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])

            # code lives on the catalog, not on individual databases
            versions: list[dict[str, Any]] = []
            for catalog in catalogs:
                if catalog.get("code") != code:
                    continue
                cat_name = catalog.get("name")
                for db in catalog.get("databases", []):
                    versions.append(
                        {
                            "id": db.get("id"),
                            "uuid": db.get("uuid"),
                            "version": db.get("version"),
                            "is_draft": db.get("is_draft"),
                            "name": db.get("name"),
                            "catalog_name": cat_name,
                        }
                    )

            if not versions:
                raise ToolError(
                    f"No database found with code '{code}'. "
                    "Use gdb_database_list to discover codes."
                )

            versions.sort(
                key=lambda v: float(v["version"]) if v["version"] is not None else 0.0
            )

            if include_schema:
                for v in versions:
                    detail = await client.get(f"/database/{v['id']}")
                    v["schema"] = detail.get("schema")

            return {
                "code": code,
                "count": len(versions),
                "versions": versions,
            }
    except GDBClientError as e:
        raise translate_error(e, resource_type="database") from e


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def gdb_database_compare(
    first_database_id: int | None = None,
    first_database_code: str | None = None,
    first_database_version: float | None = None,
    second_database_id: int | None = None,
    second_database_code: str | None = None,
    second_database_version: float | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Compare two databases to find field differences.

    Identify by ID or by code+version for each database.

    Args:
        first_database_id: First database ID (use OR code+version).
        first_database_code: First database code (requires version).
        first_database_version: First database version (requires code).
        second_database_id: Second database ID (use OR code+version).
        second_database_code: Second database code (requires version).
        second_database_version: Second database version (requires code).
        instance: Instance name (default: auto-select).

    Returns:
        dict with is_equals, first_database_missing_fields,
        second_database_missing_fields.
    """
    # Validate first database params
    has_first_id = first_database_id is not None
    has_first_code = (
        first_database_code is not None and first_database_version is not None
    )
    if not has_first_id and not has_first_code:
        raise ToolError(
            "Provide first_database_id OR "
            "(first_database_code + first_database_version)."
        )

    # Validate second database params
    has_second_id = second_database_id is not None
    has_second_code = (
        second_database_code is not None and second_database_version is not None
    )
    if not has_second_id and not has_second_code:
        raise ToolError(
            "Provide second_database_id OR "
            "(second_database_code + second_database_version)."
        )

    # Build request body
    body: dict[str, Any] = {}
    if has_first_id:
        body["first_database_id"] = first_database_id
    else:
        body["first_database_code"] = first_database_code
        body["first_database_version"] = first_database_version

    if has_second_id:
        body["second_database_id"] = second_database_id
    else:
        body["second_database_code"] = second_database_code
        body["second_database_version"] = second_database_version

    try:
        async with GDBClient.for_instance(instance) as client:
            result: dict[str, Any] = await client.post(
                "/api/v1/database/compare", data=body
            )
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="database comparison") from e


def _build_modify_payload(
    *,
    database_id: int | None = None,
    catalog_name: str | None = None,
    code: str | None = None,
    schema: dict[str, Any] | None = None,
    is_draft: bool | None = None,
    number_format: str | None = None,
    name: str | None = None,
    description: str | None = None,
    institution: str | None = None,
    group_id: int | None = None,
    group_name: str | None = None,
    color_hex: str | None = None,
    schema_tags: list[dict[str, Any]] | None = None,
    schema_flags: list[dict[str, Any]] | None = None,
    fields_uniques: list[list[int]] | None = None,
    order_fields: list[str] | None = None,
    indexes: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the POST /api/v1/database/modify payload.

    Only includes optional fields when they are not None.
    GDB API uses a MIX of snake_case and camelCase (matches frontend Formik form):
    - snake_case: catalog_name, code, name, description, institution, color_hex
    - camelCase: isDraft, numberFormat, schemaTags, schemaFlags
    - snake_case: group_id, group_name, schema, fields_uniques, order_fields
    """
    payload: dict[str, Any] = {}
    _add_optional(payload, "id", database_id)
    _add_optional(payload, "catalog_name", catalog_name)
    _add_optional(payload, "code", code)
    _add_optional(payload, "schema", schema)
    _add_optional(payload, "isDraft", is_draft)
    _add_optional(payload, "numberFormat", number_format)
    _add_optional(payload, "name", name)
    _add_optional(payload, "description", description)
    _add_optional(payload, "institution", institution)
    _add_optional(payload, "group_id", group_id)
    _add_optional(payload, "group_name", group_name)
    _add_optional(payload, "color_hex", color_hex)
    _add_optional(payload, "schemaTags", schema_tags)
    _add_optional(payload, "schemaFlags", schema_flags)
    _add_optional(payload, "fields_uniques", fields_uniques)
    _add_optional(payload, "order_fields", order_fields)
    _add_optional(payload, "indexes", indexes)
    return payload


@mcp.tool()
async def gdb_database_create(
    catalog_name: str,
    code: str,
    schema: dict[str, Any],
    is_draft: bool = True,
    number_format: str = "{code}{indexNoByCode}",
    name: str | None = None,
    description: str | None = None,
    institution: str | None = None,
    group_id: int | None = None,
    group_name: str | None = None,
    color_hex: str | None = None,
    schema_tags: list[dict[str, Any]] | None = None,
    schema_flags: list[dict[str, Any]] | None = None,
    fields_uniques: list[list[int]] | None = None,
    order_fields: list[str] | None = None,
    indexes: dict[str, Any] | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create a new GDB database (or auto-version an existing code).

    If a database with the given code already exists, GDB creates a new
    incremental version (1 → 1.1 → 1.2); old versions and data are
    preserved. Use gdb_database_upsert for explicit version tracking.
    group_id and group_name are mutually exclusive.

    Args:
        catalog_name: Catalog name for the database.
        code: Database code (new version created if code exists)
        schema: JSON Schema defining the database fields.
        is_draft: Create as draft (default: True).
        number_format: Number format pattern (default: "{code}{indexNoByCode}").
        name: Human-readable name.
        description: Database description.
        institution: Institution name.
        group_id: Existing group ID (mutually exclusive with group_name).
        group_name: New group name (mutually exclusive with group_id).
        color_hex: Color hex code.
        schema_tags: Tag definitions for database fields.
        schema_flags: Flag definitions for database fields.
        fields_uniques: Unique constraint groups (list of field index lists).
        order_fields: Field names used for default ordering.
        indexes: Index definitions for the database.
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, database_code, catalog_id,
        catalog_data_index_increment, group_id.
    """
    if group_id is not None and group_name is not None:
        raise ToolError(
            "group_id and group_name are mutually exclusive. "
            "Use group_id to assign to an existing group, "
            "or group_name to create a new group."
        )

    payload = _build_modify_payload(
        catalog_name=catalog_name,
        code=code,
        schema=schema,
        is_draft=is_draft,
        number_format=number_format,
        name=name,
        description=description,
        institution=institution,
        group_id=group_id,
        group_name=group_name,
        color_hex=color_hex,
        schema_tags=schema_tags,
        schema_flags=schema_flags,
        fields_uniques=fields_uniques,
        order_fields=order_fields,
        indexes=indexes,
    )

    try:
        async with GDBClient.for_instance(instance) as client:
            raw: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            return _normalize_modify_response(raw)
    except GDBClientError as e:
        raise translate_error(e, resource_type="database") from e


@mcp.tool()
async def gdb_database_update(
    database_id: int,
    schema: dict[str, Any] | None = None,
    catalog_name: str | None = None,
    code: str | None = None,
    is_draft: bool | None = None,
    number_format: str | None = None,
    name: str | None = None,
    description: str | None = None,
    institution: str | None = None,
    group_id: int | None = None,
    group_name: str | None = None,
    color_hex: str | None = None,
    schema_tags: list[dict[str, Any]] | None = None,
    schema_flags: list[dict[str, Any]] | None = None,
    fields_uniques: list[list[int]] | None = None,
    order_fields: list[str] | None = None,
    indexes: dict[str, Any] | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Update an existing draft GDB database (in-place, no new version).

    Only draft databases can be updated in place. Uses the same
    POST /api/v1/database/modify endpoint but with the database ID set.
    group_id and group_name are mutually exclusive.

    Args:
        database_id: Database ID to update.
        schema: Updated JSON Schema (optional for metadata-only updates).
        catalog_name: Catalog name.
        code: Database code.
        is_draft: Draft status.
        number_format: Number format pattern.
        name: Human-readable name.
        description: Database description.
        institution: Institution name.
        group_id: Existing group ID (mutually exclusive with group_name).
        group_name: New group name (mutually exclusive with group_id).
        color_hex: Color hex code.
        schema_tags: Tag definitions for database fields.
        schema_flags: Flag definitions for database fields.
        fields_uniques: Unique constraint groups (list of field index lists).
        order_fields: Field names used for default ordering.
        indexes: Index definitions for the database.
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, database_code, catalog_id,
        catalog_data_index_increment, group_id.
    """
    if group_id is not None and group_name is not None:
        raise ToolError(
            "group_id and group_name are mutually exclusive. "
            "Use group_id to assign to an existing group, "
            "or group_name to create a new group."
        )

    payload = _build_modify_payload(
        database_id=database_id,
        catalog_name=catalog_name,
        code=code,
        schema=schema,
        is_draft=is_draft,
        number_format=number_format,
        name=name,
        description=description,
        institution=institution,
        group_id=group_id,
        group_name=group_name,
        color_hex=color_hex,
        schema_tags=schema_tags,
        schema_flags=schema_flags,
        fields_uniques=fields_uniques,
        order_fields=order_fields,
        indexes=indexes,
    )

    try:
        async with GDBClient.for_instance(instance) as client:
            raw: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            return _normalize_modify_response(raw)
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool()
async def gdb_database_edit(
    database_id: int,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create an editable draft from a published database.

    Returns only the new draft's {id}. Call gdb_database_get(id) to fetch
    the full database with schema.

    Args:
        database_id: Database ID to create a draft from.
        instance: Instance name (default: auto-select).

    Returns:
        dict with id of the new draft database.
    """
    try:
        async with GDBClient.for_instance(instance) as client:
            result: dict[str, Any] = await client.post(
                f"/api/v1/database/{database_id}/edit", data={}
            )
            return result
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool()
async def gdb_database_publish(
    database_id: int,
    instance: str | None = None,
) -> dict[str, Any]:
    """Publish a draft database (makes it immutable and usable by services).

    Only draft databases can be published. Once published, the schema is
    locked and data views/services can reference it. Fetches current state
    first since /modify requires catalog_name, code, and schema.

    Args:
        database_id: Draft database ID to publish.
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, database_code, catalog_id.
    """
    try:
        async with GDBClient.for_instance(instance) as client:
            # /modify requires catalog_name, code, schema on every call.
            # GET /database/{id} returns name + code at top level (= catalog fields).
            db: dict[str, Any] = await client.get(f"/database/{database_id}")
            if not db.get("is_draft"):
                raise ToolError(f"Database {database_id} is already published.")
            payload = _build_modify_payload(
                database_id=database_id,
                catalog_name=db["name"],
                code=db["code"],
                schema=db["schema"],
                is_draft=False,
            )
            raw: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            return _normalize_modify_response(raw)
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool()
async def gdb_database_unpublish(
    database_id: int,
    instance: str | None = None,
) -> dict[str, Any]:
    """Revert a published database to draft (unpublish).

    Data and schema are preserved. Use when a database is orphaned
    (e.g. upstream procedure deleted) and should no longer be live.

    Args:
        database_id: Published database ID to unpublish.
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, catalog_id, catalog_code.
    """
    try:
        async with GDBClient.for_instance(instance) as client:
            db: dict[str, Any] = await client.get(f"/database/{database_id}")
            if db.get("is_draft"):
                raise ToolError(f"Database {database_id} is already a draft.")
            payload = _build_modify_payload(
                database_id=database_id,
                catalog_name=db["name"],
                code=db["code"],
                schema=db["schema"],
                is_draft=True,
            )
            result: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            return result
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool()
async def gdb_database_delete(
    database_id: int | None = None,
    database_uuid: str | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Delete a GDB database by ID or UUID.

    Provide database_id (int) or database_uuid (str) — at least one required.
    When only database_id is given, resolves the UUID via GET first.

    Args:
        database_id: Database ID (resolves UUID automatically).
        database_uuid: Database UUID (used directly).
        instance: Instance name (default: auto-select).

    Returns:
        dict with deleted, database_id, database_uuid.
    """
    if database_id is None and database_uuid is None:
        raise ToolError(
            "Provide database_id (int) or database_uuid (str). "
            "At least one is required."
        )

    try:
        async with GDBClient.for_instance(instance) as client:
            # Resolve UUID from ID if needed
            if database_uuid is None:
                db: dict[str, Any] = await client.get(f"/database/{database_id}")
                database_uuid = db.get("uuid")
                if not database_uuid:
                    raise ToolError(
                        f"Database {database_id} has no UUID. "
                        "Cannot delete without a UUID."
                    )

            await client.delete(f"/api/v1/database/{database_uuid}")
            result: dict[str, Any] = {
                "deleted": True,
                "database_uuid": database_uuid,
            }
            if database_id is not None:
                result["database_id"] = database_id
            return result
    except GDBClientError as e:
        resource_id = database_id if database_id is not None else database_uuid
        raise translate_error(
            e, resource_type="database", resource_id=resource_id
        ) from e


@mcp.tool()
async def gdb_database_duplicate(
    database_id: int,
    copy_data: bool = False,
    instance: str | None = None,
) -> dict[str, Any]:
    """Duplicate a GDB database.

    Args:
        database_id: Database ID to duplicate.
        copy_data: Whether to copy data rows (default: False).
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, database_code, catalog_id,
        catalog_data_index_increment, group_id.
    """
    try:
        async with GDBClient.for_instance(instance) as client:
            raw: dict[str, Any] = await client.post(
                f"/api/v1/database/{database_id}/duplicate",
                data={"copyData": copy_data},
            )
            return _normalize_modify_response(raw)
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


_RENAME_BATCH_SIZE = 500


@mcp.tool()
async def gdb_database_rename_column(
    database_id: int,
    old_name: str,
    new_name: str,
    instance: str | None = None,
) -> dict[str, Any]:
    """Rename a column in a database schema and migrate existing data.

    Updates the JSON Schema property name and renames the key in all
    data records. The database must be a draft. For published databases,
    call gdb_database_edit first.

    Args:
        database_id: Database ID (must be draft).
        old_name: Current column/property name.
        new_name: New column/property name.
        instance: Instance name (default: auto-select).

    Returns:
        dict with renamed, old_name, new_name, rows_migrated.
    """
    if old_name == new_name:
        raise ToolError("old_name and new_name must be different.")

    try:
        async with GDBClient.for_instance(instance) as client:
            # 1. Fetch database and validate
            db: dict[str, Any] = await client.get(f"/database/{database_id}")
            if not db.get("is_draft"):
                raise ToolError(
                    f"Database {database_id} is published. "
                    "Call gdb_database_edit first to create a draft."
                )

            schema = db.get("schema", {})
            properties = schema.get("properties", {})
            if old_name not in properties:
                available = ", ".join(sorted(properties.keys()))
                raise ToolError(
                    f"Column '{old_name}' not found in schema. Available: {available}."
                )
            if new_name in properties:
                raise ToolError(f"Column '{new_name}' already exists in schema.")

            # 2. Rename property in schema
            new_properties: dict[str, Any] = {}
            for key, value in properties.items():
                new_properties[new_name if key == old_name else key] = value
            schema["properties"] = new_properties

            # Update required list if present
            required = schema.get("required", [])
            if old_name in required:
                schema["required"] = [
                    new_name if r == old_name else r for r in required
                ]

            # 3. Update database schema
            payload = _build_modify_payload(
                database_id=database_id,
                catalog_name=db["name"],
                code=db["code"],
                schema=schema,
            )
            await client.post("/api/v1/database/modify", data=payload)

            # 4. Migrate data records (skip if no data endpoint yet)
            code = db["code"]
            version = str(db.get("version", "any"))
            rows_migrated = 0

            page = 1
            while True:
                try:
                    page_data = await client.get_page(
                        f"/api/v1/data/{code.lower()}/{version}",
                        page=page,
                        page_size=_RENAME_BATCH_SIZE,
                    )
                except GDBNotFoundError:
                    # Fresh database with no data endpoint yet — nothing to migrate
                    break
                results = page_data.get("results", [])
                if not results:
                    break

                # Filter records that have the old key
                to_update_queries: list[dict[str, Any]] = []
                to_update_records: list[dict[str, Any]] = []
                for record in results:
                    content = record.get("content", {})
                    if old_name in content:
                        new_content = {}
                        for k, v in content.items():
                            new_content[new_name if k == old_name else k] = v
                        to_update_queries.append({"id": record["id"]})
                        to_update_records.append(new_content)

                if to_update_queries:
                    await client.put(
                        f"/data/{code.lower()}/{version}/update-entries",
                        data={
                            "query": to_update_queries,
                            "write": [{"content": rec} for rec in to_update_records],
                        },
                    )
                    rows_migrated += len(to_update_queries)

                if not page_data.get("has_next"):
                    break
                page += 1

            return {
                "renamed": True,
                "old_name": old_name,
                "new_name": new_name,
                "rows_migrated": rows_migrated,
            }
    except GDBClientError as e:
        raise translate_error(
            e, resource_type="database", resource_id=database_id
        ) from e


@mcp.tool()
async def gdb_database_upsert(
    catalog_name: str,
    code: str,
    schema: dict[str, Any],
    is_draft: bool = True,
    number_format: str = "{code}{indexNoByCode}",
    name: str | None = None,
    description: str | None = None,
    institution: str | None = None,
    group_id: int | None = None,
    group_name: str | None = None,
    color_hex: str | None = None,
    schema_tags: list[dict[str, Any]] | None = None,
    schema_flags: list[dict[str, Any]] | None = None,
    fields_uniques: list[list[int]] | None = None,
    order_fields: list[str] | None = None,
    indexes: dict[str, Any] | None = None,
    instance: str | None = None,
) -> dict[str, Any]:
    """Create or auto-version a GDB database.

    If code exists, GDB creates a new version (1 → 1.1 → 1.2);
    old versions and data are preserved. Returns is_new_version flag.

    Args:
        catalog_name: Catalog name for the database.
        code: Database code (auto-versions if already exists).
        schema: JSON Schema defining the database fields.
        is_draft: Create as draft (default: True).
        number_format: Number format (default: "{code}{indexNoByCode}").
        name: Human-readable name.
        description: Database description.
        institution: Institution name.
        group_id: Existing group ID (mutually exclusive with group_name).
        group_name: New group name (mutually exclusive with group_id).
        color_hex: Color hex code.
        schema_tags: Tag definitions.
        schema_flags: Flag definitions.
        fields_uniques: Unique constraint groups.
        order_fields: Default ordering fields.
        indexes: Index definitions.
        instance: Instance name (default: auto-select).

    Returns:
        dict with id, version, is_new_version, plus API fields.
    """
    if group_id is not None and group_name is not None:
        raise ToolError(
            "group_id and group_name are mutually exclusive. "
            "Use group_id to assign to an existing group, "
            "or group_name to create a new group."
        )

    try:
        async with GDBClient.for_instance(instance) as client:
            # Check if code already exists to determine is_new_version
            catalogs = await client.get("/databases")
            if not isinstance(catalogs, list):
                catalogs = catalogs.get("catalogs", [])

            code_exists = any(
                db.get("code") == code
                for catalog in catalogs
                for db in catalog.get("databases", [])
            )

            payload = _build_modify_payload(
                catalog_name=catalog_name,
                code=code,
                schema=schema,
                is_draft=is_draft,
                number_format=number_format,
                name=name,
                description=description,
                institution=institution,
                group_id=group_id,
                group_name=group_name,
                color_hex=color_hex,
                schema_tags=schema_tags,
                schema_flags=schema_flags,
                fields_uniques=fields_uniques,
                order_fields=order_fields,
                indexes=indexes,
            )

            result: dict[str, Any] = await client.post(
                "/api/v1/database/modify", data=payload
            )
            result["is_new_version"] = code_exists
            return result
    except GDBClientError as e:
        raise translate_error(e, resource_type="database") from e
