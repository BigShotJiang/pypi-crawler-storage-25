"""GDB schema builder — flat field list → valid GDB JSON Schema."""

from __future__ import annotations

from typing import Any

from fastmcp.exceptions import ToolError

from mcp_eregistrations_gdb.server import mcp

# Field type → GDB JSON Schema type mapping
_TYPE_MAP: dict[str, dict[str, Any]] = {
    "text": {"type": "string"},
    "string": {"type": "string"},
    "number": {"type": "number"},
    "boolean": {"type": "boolean"},
    "date": {"type": "string", "format": "date"},
    "datetime": {"type": "string", "format": "date-time"},
}


def _build_field_property(field: dict[str, Any], field_id: int) -> dict[str, Any]:
    """Convert a single flat field dict to a GDB JSON Schema property."""
    field_type = field.get("type", "text")
    prop: dict[str, Any] = {"$id": field_id}

    if field_type in _TYPE_MAP:
        prop.update(_TYPE_MAP[field_type])
    elif field_type == "catalog":
        prop["type"] = "catalog"
        if "catalog_code" in field:
            prop["catalogCode"] = field["catalog_code"]
    elif field_type == "file":
        items: dict[str, Any] = {"type": "file", "antivirus": True}
        if "consumes" in field:
            items["consumes"] = field["consumes"]
        prop["type"] = "array"
        prop["items"] = items
    else:
        # Pass through unknown types as-is
        prop["type"] = field_type

    if field.get("primary_key"):
        prop["primaryKey"] = True
    if field.get("read_only"):
        prop["readOnly"] = True
    if field.get("group"):
        prop["group"] = field["group"]

    return prop


@mcp.tool()
async def gdb_schema_build(
    fields: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build a valid GDB JSON Schema from a flat field list.

    Pure utility — no API call. Handles $id counters, $incrementIndex,
    primaryKey, readOnly, format, catalog and file type shapes.

    Args:
        fields: List of field dicts with keys: name (required), type
            (text|number|boolean|date|datetime|catalog|file, default: text),
            primary_key, read_only, required, group, consumes, catalog_code.

    Returns:
        dict — valid GDB JSON Schema with type, $incrementIndex, properties,
        required.
    """
    if not fields:
        raise ToolError("fields list must not be empty.")

    seen_names: set[str] = set()
    properties: dict[str, Any] = {}
    required: list[str] = []

    for i, field in enumerate(fields, start=1):
        name = field.get("name")
        if not name:
            raise ToolError(f"Field at index {i - 1} is missing required 'name' key.")
        if name in seen_names:
            raise ToolError(f"Duplicate field name: '{name}'.")
        seen_names.add(name)

        properties[name] = _build_field_property(field, field_id=i)
        if field.get("required"):
            required.append(name)

    schema: dict[str, Any] = {
        "type": "object",
        "$incrementIndex": len(fields),
        "properties": properties,
    }
    if required:
        schema["required"] = required

    return schema
