from typing import Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar('T')


class CliServiceEnvelope(BaseModel, Generic[T]):
	code: int = 0
	msg: str | None = None
	data: T | None = None
	trace_id: str | None = Field(default=None, alias='traceId')
