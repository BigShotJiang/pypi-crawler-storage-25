from typing import Any, ClassVar, Literal

from pydantic import BaseModel

from cli_contracts.captcha.shared import MouseAction


class ReturnPayload:
	"""Shared business payload models for captcha solve responses."""

	class TokenPayload(BaseModel):
		token: str

	class MouseActionsPayload(BaseModel):
		actions: list[MouseAction]

	class DataDomeSliderPlanPayload(BaseModel):
		__redact_fields__: ClassVar[tuple[str, ...]] = ('actions',)
		slider_type: Literal['geetest', 'left-right']
		actions: list[MouseAction]

		def model_post_init(self, __context: Any) -> None:
			if not self.actions:
				raise ValueError('actions must not be empty')
			if not any(action.type == 'down' for action in self.actions):
				raise ValueError('actions must include down')
			if not any(action.type == 'up' for action in self.actions):
				raise ValueError('actions must include up')

	class HumanSecurityPlanPayload(BaseModel):
		__redact_fields__: ClassVar[tuple[str, ...]] = ('approach_actions', 'hold_actions')
		approach_actions: list[MouseAction]
		hold_actions: list[MouseAction]
		hold_timeout_ms: int
		progress_target: int = 99
		post_progress_wait_ms: int = 0

		def model_post_init(self, __context: Any) -> None:
			if not self.approach_actions:
				raise ValueError('approach_actions must not be empty')
			if self.approach_actions[-1].type != 'down':
				raise ValueError('approach_actions must end with down')
			if any(action.type == 'up' for action in self.approach_actions):
				raise ValueError('approach_actions must not include up')
			if any(action.type in {'down', 'up'} for action in self.hold_actions):
				raise ValueError('hold_actions must only contain move and wait actions')
			if self.hold_timeout_ms < 0:
				raise ValueError('hold_timeout_ms must be non-negative')
			if not 1 <= self.progress_target <= 100:
				raise ValueError('progress_target must be between 1 and 100')
			if self.post_progress_wait_ms < 0:
				raise ValueError('post_progress_wait_ms must be non-negative')

