from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from cli_contracts.captcha.enums import CF, CV, TECH
from cli_contracts.captcha.route import RouteKey


class CaptchaSolveData(BaseModel):
	model_config = ConfigDict(use_enum_values=True)

	cf: CF
	cv: CV
	tech: TECH
	v: str
	payload: dict[str, Any] = Field(default_factory=dict)

	@field_validator('v')
	@classmethod
	def _validate_semver(cls, value: str) -> str:
		parts = value.split('.')
		if len(parts) != 3 or not all(part.isdigit() for part in parts):
			raise ValueError('v must use semver format: x.y.z')
		return value

	def to_route_key(self) -> RouteKey:
		return RouteKey(
			cf=self.cf,
			cv=self.cv,
			tech=self.tech,
			v=self.v,
		)


class CaptchaSolveRequest(BaseModel):
	config: dict[str, Any] = Field(default_factory=dict)
	data: CaptchaSolveData
