from typing import Any, Literal

from pydantic import BaseModel


class BoxRectPayload(BaseModel):
	x: float
	y: float
	width: float
	height: float


class ImagePayload(BaseModel):
	base64: str
	format: Literal['png']


class ViewportPayload(BaseModel):
	width: int
	height: int


class MouseAction(BaseModel):
	type: Literal['move', 'down', 'up', 'wait']
	x: float | None = None
	y: float | None = None
	delay_ms: int = 0

	def model_post_init(self, __context: Any) -> None:
		if self.type == 'move' and (self.x is None or self.y is None):
			raise ValueError('move action requires x and y')
		if self.type == 'wait' and (self.x is not None or self.y is not None):
			raise ValueError('wait action must not include x or y')
		if self.type in {'down', 'up'} and (self.x is not None or self.y is not None):
			raise ValueError(f'{self.type} action must not include x or y')
