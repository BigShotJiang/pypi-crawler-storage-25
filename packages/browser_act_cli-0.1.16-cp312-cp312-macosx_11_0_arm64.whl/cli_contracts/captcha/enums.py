from enum import StrEnum


class CF(StrEnum):
	RECAPTCHA = 'recaptcha'
	CLOUDFLARE = 'cloudflare'
	HUMAN_SECURITY = 'human_security'
	DATADOME = 'datadome'


class CV(StrEnum):
	V2 = 'v2'
	V2_ENTERPRISE = 'v2_enterprise'
	V2_GOOGLE_SORRY = 'v2_google_sorry'
	TURNSTILE_CHALLENGE = 'turnstile_challenge'
	TURNSTILE_WIDGET = 'turnstile_widget'
	PRESS_HOLD = 'press_hold'
	SLIDER = 'slider'


class TECH(StrEnum):
	T1 = 'te1'
	T3 = 'te3'
