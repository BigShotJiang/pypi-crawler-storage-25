from typing import ClassVar

from pydantic import BaseModel

from cli_contracts.captcha.shared import BoxRectPayload, ImagePayload, ViewportPayload


class HumanSecurityPayload:
	class PressHoldTrajectory:
		class V1_0_0(BaseModel):
			__redact_fields__: ClassVar[tuple[str, ...]] = ('image',)
			page_url: str
			image: ImagePayload
			viewport: ViewportPayload
			device_pixel_ratio: float
			captcha_box: BoxRectPayload
			frame_id: str
			is_main_frame: bool
