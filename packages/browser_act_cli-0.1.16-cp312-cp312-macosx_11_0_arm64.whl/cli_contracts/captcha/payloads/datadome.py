from typing import Any, ClassVar, Literal

from pydantic import BaseModel

from cli_contracts.captcha.shared import BoxRectPayload, ImagePayload, ViewportPayload


class DataDomePayload:
	class SliderTrajectory:
		class V1_0_0(BaseModel):
			__redact_fields__: ClassVar[tuple[str, ...]] = ('background_image', 'puzzle_image')
			page_url: str
			captcha_url: str
			user_agent: str
			frame_id: str
			slider_type: Literal['geetest', 'left-right']
			viewport: ViewportPayload
			device_pixel_ratio: float
			slider_box: BoxRectPayload
			canvas_box: BoxRectPayload | None = None
			background_image: ImagePayload | None = None
			puzzle_image: ImagePayload | None = None
			target_box: BoxRectPayload | None = None

			def model_post_init(self, __context: Any) -> None:
				if self.device_pixel_ratio <= 0:
					raise ValueError('device_pixel_ratio must be positive')
				if self.slider_type == 'geetest':
					if self.background_image is None or self.puzzle_image is None:
						raise ValueError('geetest slider requires background_image and puzzle_image')
					if self.target_box is not None:
						raise ValueError('geetest slider must not include target_box')
					if self.canvas_box is not None and (self.canvas_box.width <= 0 or self.canvas_box.height <= 0):
						raise ValueError('geetest slider canvas_box must be positive when provided')
					return
				if self.target_box is None:
					raise ValueError('left-right slider requires target_box')
				if self.canvas_box is not None:
					raise ValueError('left-right slider must not include canvas_box')
				if self.background_image is not None or self.puzzle_image is not None:
					raise ValueError('left-right slider must not include geetest images')
