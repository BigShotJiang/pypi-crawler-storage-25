from pydantic import BaseModel


class CloudflarePayload:
	class TurnstileWidgetTwoCaptcha:
		class V1_0_0(BaseModel):
			site_key: str
			page_url: str

	class TurnstileChallengeTwoCaptcha:
		class V1_0_0(BaseModel):
			site_key: str
			page_url: str
			user_agent: str
			action: str
			data: str
			page_data: str

