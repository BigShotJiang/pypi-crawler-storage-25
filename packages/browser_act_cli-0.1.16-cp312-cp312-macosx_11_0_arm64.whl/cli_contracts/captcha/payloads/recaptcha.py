from pydantic import BaseModel


class ReCaptchaPayload:
	class GoogleSorryRelayProxyPayload(BaseModel):
		relay_id: int
		username: str
		password: str
		proxy_type: str

	class V2TwoCaptcha:
		class V1_0_0(BaseModel):
			site_key: str
			page_url: str

	class V2EnterpriseTwoCaptcha:
		class V1_0_0(BaseModel):
			site_key: str
			page_url: str

	class V2GoogleSorryTwoCaptcha:
		class V1_0_0(BaseModel):
			site_key: str
			page_url: str
			data_s: str
			proxy: 'ReCaptchaPayload.GoogleSorryRelayProxyPayload | None' = None

