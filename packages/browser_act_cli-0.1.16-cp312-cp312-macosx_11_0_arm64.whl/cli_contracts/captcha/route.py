from pydantic import BaseModel, ConfigDict, field_validator

from cli_contracts.captcha.enums import CF, CV, TECH


class RouteKey(BaseModel):
	"""Readable route key used by decorators and routing."""

	model_config = ConfigDict(frozen=True)

	cf: CF
	cv: CV
	tech: TECH
	v: str

	@field_validator('v')
	@classmethod
	def _validate_semver(cls, value: str) -> str:
		parts = value.split('.')
		if len(parts) != 3 or not all(part.isdigit() for part in parts):
			raise ValueError('v must use semver format: x.y.z')
		return value

