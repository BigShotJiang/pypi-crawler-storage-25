from enum import StrEnum
from typing import Generic, Literal, TypeVar

from pydantic import BaseModel

T = TypeVar('T', bound=BaseModel)


class CaptchaSolveStatus(StrEnum):
	SOLVED = 'solved'
	FAILED = 'failed'
	UNSUPPORTED = 'unsupported'
	INVALID_INPUT = 'invalid_input'
	TIMEOUT = 'timeout'


class FailurePayload(BaseModel):
	reason: str | None = None


class CaptchaRouteSuccess(BaseModel, Generic[T]):
	success: Literal[True]
	status: Literal[CaptchaSolveStatus.SOLVED]
	payload: T


class CaptchaRouteFailure(BaseModel):
	success: Literal[False]
	status: Literal[
		CaptchaSolveStatus.FAILED,
		CaptchaSolveStatus.TIMEOUT,
		CaptchaSolveStatus.INVALID_INPUT,
		CaptchaSolveStatus.UNSUPPORTED,
	]
	payload: FailurePayload


CaptchaRouteResult = CaptchaRouteSuccess[T] | CaptchaRouteFailure
