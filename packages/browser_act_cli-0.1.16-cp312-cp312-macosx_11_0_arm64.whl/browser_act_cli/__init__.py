import sys

__version__ = '0.1.16'

# ---------------------------------------------------------------------------
# Use the OS certificate store (Windows/macOS/Linux) instead of certifi's
# bundled CA list.  This lets Python trust the same CAs the browser does,
# including corporate proxy / MITM root certificates that are installed in
# the system store but absent from certifi.
#
# Must run BEFORE any module creates an ssl.SSLContext (httpx, requests,
# urllib3, aiohttp …).  Failure is non-fatal: we fall back to certifi.
# ---------------------------------------------------------------------------
try:
	import truststore

	truststore.inject_into_ssl()
except Exception:
	pass

# Force UTF-8 on stdout/stderr so web-page content (©, ™, em-dash, etc.)
# never triggers UnicodeEncodeError on Windows (default codepage is GBK).
# No-op on Linux/Mac where encoding is already utf-8.
for _s in (sys.stdout, sys.stderr):
	if hasattr(_s, 'reconfigure'):
		try:
			_s.reconfigure(encoding='utf-8')
		except Exception:
			pass

# Save references to the real terminal streams BEFORE _configure_main_logging()
# redirects sys.stderr to the log file.
_original_stdout = sys.stdout
_original_stderr = sys.stderr
