from browser_act_cli.enums import BrowserType
from browser_act_cli.session.drivers.base import BrowserDriver
from browser_act_cli.session.drivers.chromium import ChromiumDriver
from browser_act_cli.session.drivers.real_chrome import RealChromeDriver
from browser_act_cli.session.drivers.stealth import StealthDriver
from browser_act_cli.session.drivers.workbench import WorkbenchDriver

__all__ = ['BrowserDriver', 'BrowserType', 'ChromiumDriver', 'RealChromeDriver', 'StealthDriver', 'WorkbenchDriver']


def create_driver(mode: str | BrowserType, **kwargs) -> BrowserDriver:
	"""Factory: create the appropriate driver for the given browser type."""
	if isinstance(mode, BrowserType):
		browser_type = mode
	else:
		try:
			browser_type = BrowserType(mode)
		except ValueError:
			valid = ', '.join(t.value for t in BrowserType)
			msg = f'Unknown browser type: {mode}. Valid types: {valid}'
			raise ValueError(msg) from None

	if browser_type == BrowserType.STEALTH:
		return StealthDriver()
	if browser_type == BrowserType.REAL:
		return RealChromeDriver()
	if browser_type == BrowserType.CHROMIUM:
		return ChromiumDriver()

	msg = f'Unhandled browser type: {browser_type}'
	raise ValueError(msg)
