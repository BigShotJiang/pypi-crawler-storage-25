"""Packaged HTML assets for captcha runtime hooks."""
