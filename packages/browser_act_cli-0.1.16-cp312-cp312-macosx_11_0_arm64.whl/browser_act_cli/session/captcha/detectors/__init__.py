"""Captcha detectors for CLI session runtime."""

from browser_act_cli.session.captcha.detectors.cloudflare_challenge import detect_cloudflare_challenge
from browser_act_cli.session.captcha.detectors.cloudflare_widget import detect_cloudflare_widget
from browser_act_cli.session.captcha.detectors.datadome import detect_datadome_slider
from browser_act_cli.session.captcha.detectors.human_security import detect_human_security
from browser_act_cli.session.captcha.detectors.recaptcha_v2 import detect_recaptcha_v2

__all__ = [
	'detect_recaptcha_v2',
	'detect_cloudflare_challenge',
	'detect_cloudflare_widget',
	'detect_human_security',
	'detect_datadome_slider',
]
