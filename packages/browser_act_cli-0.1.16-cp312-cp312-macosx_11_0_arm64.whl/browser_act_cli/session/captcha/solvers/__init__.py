"""Captcha solvers for CLI session runtime."""

from browser_act_cli.session.captcha.solvers.cloudflare_challenge_token import solve_cloudflare_challenge_token
from browser_act_cli.session.captcha.solvers.cloudflare_widget_token import solve_cloudflare_widget_token
from browser_act_cli.session.captcha.solvers.datadome_solver import solve_datadome_slider
from browser_act_cli.session.captcha.solvers.human_security_solver import solve_human_security
from browser_act_cli.session.captcha.solvers.recaptcha_v2_token import solve_recaptcha_v2_token

__all__ = [
	'solve_recaptcha_v2_token',
	'solve_cloudflare_widget_token',
	'solve_cloudflare_challenge_token',
	'solve_human_security',
	'solve_datadome_slider',
]
