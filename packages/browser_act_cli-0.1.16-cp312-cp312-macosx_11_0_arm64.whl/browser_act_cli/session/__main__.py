"""Allow ``python -m browser_act_cli.session <session_name>`` to start the server.

This file must stay as plain .py so that ``python -m`` keeps working
after the rest of the package has been compiled to .so with Cython.
"""

from __future__ import annotations

import sys

from browser_act_cli.session.server import run_server

if len(sys.argv) < 2:
	print('Usage: python -m browser_act_cli.session <session_name>', file=sys.stderr)
	sys.exit(1)

run_server(sys.argv[1])
