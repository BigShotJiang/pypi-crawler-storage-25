"""Action enum, handler registry, and registration decorator."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from enum import StrEnum
from typing import TYPE_CHECKING, TypeVar, cast

if TYPE_CHECKING:
	from pydantic import BaseModel

	from browser_act_cli.session.server import SessionServer

# Handler signature: (server, parsed_params) -> BaseModel | None
ActionHandler = Callable[['SessionServer', 'BaseModel | None'], Awaitable['BaseModel | None']]
RegisteredHandlerT = TypeVar('RegisteredHandlerT', bound=Callable[..., Awaitable['BaseModel | None']])

# Registry populated by @action_handler decorator
ACTION_HANDLERS: dict[str, ActionHandler] = {}


class Action(StrEnum):
	"""All IPC action names. Values match the wire protocol strings."""

	# Internal
	PING = '_ping'
	STATUS = '_status'
	SHUTDOWN = '_shutdown'
	# Browser open
	OPEN = 'open'
	# Navigation
	NAVIGATE = 'navigate'
	BACK = 'back'
	FORWARD = 'forward'
	RELOAD = 'reload'
	# Tab management
	TAB_LIST = 'tab_list'
	TAB_SWITCH = 'tab_switch'
	TAB_CLOSE = 'tab_close'
	# Page state
	STATE = 'state'
	SCREENSHOT = 'screenshot'
	# Page interaction
	CLICK = 'click'
	TYPE = 'type'
	INPUT = 'input'
	HOVER = 'hover'
	SCROLL = 'scroll'
	KEYS = 'keys'
	SELECT = 'select'
	SCROLL_INTO_VIEW = 'scroll_into_view'
	UPLOAD = 'upload'
	# Page data
	EVAL = 'eval'
	GET_HTML = 'get_html'
	GET_TITLE = 'get_title'
	GET_TEXT = 'get_text'
	GET_VALUE = 'get_value'
	GET_MARKDOWN = 'get_markdown'
	GET_BBOX = 'get_bbox'
	# Wait & network
	WAIT_STABLE = 'wait_stable'
	WAIT_SELECTOR = 'wait_selector'
	GET_NETWORK = 'get_network'
	GET_NETWORK_DETAIL = 'get_network_detail'
	CLEAR_NETWORK = 'clear_network'
	SET_OFFLINE = 'set_offline'
	HAR_START = 'har_start'
	HAR_STOP = 'har_stop'
	# Dialog
	DIALOG_ACCEPT = 'dialog_accept'
	DIALOG_DISMISS = 'dialog_dismiss'
	DIALOG_STATUS = 'dialog_status'
	# Advanced
	BYPASS_CAPTCHA = 'bypass_captcha'
	# Human Assist
	HUMAN_ASSIST_URL = 'human_assist_url'
	HUMAN_ASSIST_STATUS = 'human_assist_status'
	# Cookies
	COOKIES_GET = 'cookies_get'
	COOKIES_SET = 'cookies_set'
	COOKIES_CLEAR = 'cookies_clear'
	COOKIES_EXPORT = 'cookies_export'
	COOKIES_IMPORT = 'cookies_import'


_SKIP_LAUNCH_ACTIONS: frozenset[Action] = frozenset(
	{
		Action.PING,
		Action.STATUS,
		Action.SHUTDOWN,
		Action.OPEN,
		Action.HUMAN_ASSIST_STATUS,
	}
)


def skip_launch(action: Action) -> bool:
	"""Return True when an action should bypass browser liveness auto-relaunch."""
	return action in _SKIP_LAUNCH_ACTIONS


def action_handler(action: Action) -> Callable[[RegisteredHandlerT], RegisteredHandlerT]:
	"""Register a handler for an action.

	Handler contract:
	- Receives (server, parsed_params) where parsed_params is the Pydantic model
	  from ActionSpec.params (or None if the action takes no params).
	- Returns an instance of the ActionSpec.response model, or None for no-data actions.
	- Raises an exception on error — the framework converts it to an error Response.
	"""

	def decorator(fn: RegisteredHandlerT) -> RegisteredHandlerT:
		# Preserve each handler's concrete param type while storing a unified callable in the registry.
		ACTION_HANDLERS[action.value] = cast(ActionHandler, fn)
		return fn

	return decorator
