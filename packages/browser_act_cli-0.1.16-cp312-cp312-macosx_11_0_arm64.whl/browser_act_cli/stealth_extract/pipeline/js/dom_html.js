(function() {
  "use strict";
  function isElementNotVisible(element) {
    const computedStyle = window.getComputedStyle(element);
    return computedStyle.display === "none" || computedStyle.visibility === "hidden";
  }
  const domHtml = () => {
    const ORIGINAL_TO_CLONE = /* @__PURE__ */ new WeakMap();
    function shouldExcludeElement(element) {
      const tagName = element.tagName?.toLowerCase();
      return tagName === "iframe" || tagName === "canvas" || isElementNotVisible(element);
    }
    function cloneElementWithVisibleChildren(element) {
      const clonedElement = element.cloneNode(false);
      ORIGINAL_TO_CLONE.set(element, clonedElement);
      for (let i = 0; i < element.childNodes.length; i++) {
        const childNode = element.childNodes[i];
        if (childNode.nodeType === Node.ELEMENT_NODE) {
          const childElement = childNode;
          if (!shouldExcludeElement(childElement)) {
            const clonedChild = cloneElementWithVisibleChildren(childElement);
            clonedElement.appendChild(clonedChild);
            if (childElement.shadowRoot) {
              for (let j = 0; j < childElement.shadowRoot.childNodes.length; j++) {
                const shadowChildNode = childElement.shadowRoot.childNodes[j];
                if (shadowChildNode.nodeType === Node.ELEMENT_NODE) {
                  const shadowChildElement = shadowChildNode;
                  if (!shouldExcludeElement(shadowChildElement)) {
                    const clonedShadowChild = cloneElementWithVisibleChildren(shadowChildElement);
                    clonedChild.appendChild(clonedShadowChild);
                  }
                } else {
                  const clonedShadowNode = shadowChildNode.cloneNode(true);
                  clonedChild.appendChild(clonedShadowNode);
                }
              }
            }
          }
        } else {
          const clonedNode = childNode.cloneNode(true);
          clonedElement.appendChild(clonedNode);
        }
      }
      return clonedElement;
    }
    const body = document.body;
    if (!body) {
      return "";
    }
    const clonedBody = cloneElementWithVisibleChildren(body);
    const documentElementClone = window.document.documentElement.cloneNode(
      false
    );
    documentElementClone.appendChild(clonedBody);
    return documentElementClone.outerHTML;
  };
  return domHtml;
})()
