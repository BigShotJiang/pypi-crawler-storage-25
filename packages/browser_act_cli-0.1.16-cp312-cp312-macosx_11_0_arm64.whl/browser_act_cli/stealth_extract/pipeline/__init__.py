"""Conversion pipeline: JS DOM filtering + HTML-to-Markdown."""

from __future__ import annotations

import logging
import re
from collections.abc import Generator

from browser_act_cli.stealth_extract.pipeline.converter import MarkdownLessConverter

logger = logging.getLogger(__name__)

_DEFAULT_HEADERS_TO_SPLIT = {
	'#': 'Header 1',
	'##': 'Header 2',
	'###': 'Header 3',
	'####': 'Header 4',
	'#####': 'Header 5',
	'######': 'Header 6',
}

_DEFAULT_MAX_CHUNK_LENGTH = 50_000


def _collapse_whitespace(text: str) -> str:
	"""Collapse runs of 3+ blank lines into 2 and strip trailing whitespace."""
	text = re.sub(r'\n{3,}', '\n\n', text)
	lines = [line.rstrip() for line in text.splitlines()]
	return '\n'.join(lines).strip() + '\n'


def html_to_markdown(
	html: str,
	page_url: str = '',
	iframes: list[tuple[str, str]] | None = None,
) -> str:
	"""Convert rendered HTML to clean Markdown.

	Pipeline:
		1. MarkdownLessConverter.convert() — markdownify with hidden-element filtering and URL absolutisation
		2. (optional) iframe content merging
		3. clean_garbage_for_llm — remove base64 images, leftover <style> tags
		4. _collapse_whitespace — final whitespace normalisation
	"""
	converter = MarkdownLessConverter(
		page_url=page_url,
		heading_style='ATX',
		strip=['img'],
	)
	md = converter.convert(html)

	if iframes:
		for iframe_url, iframe_html in iframes:
			if not iframe_html:
				continue
			md += f'\n\nIFRAME {iframe_url}:\n'
			converter.set_context_url(iframe_url)
			try:
				md += converter.convert(iframe_html)
			except Exception:
				logger.debug('Failed to convert iframe: %s', iframe_url)
			converter.reset_context_url()

	md = converter.clean_garbage_for_llm(md)
	return _collapse_whitespace(md)


def markdown_split(
	md_document: str,
	max_length: int = _DEFAULT_MAX_CHUNK_LENGTH,
) -> Generator[str, None, None]:
	"""Split *md_document* by Markdown headers, merging adjacent sections until *max_length* is reached."""
	from langchain_text_splitters import MarkdownHeaderTextSplitter

	splitter = MarkdownHeaderTextSplitter(
		headers_to_split_on=list(_DEFAULT_HEADERS_TO_SPLIT.items()),
		strip_headers=False,
	)
	sections = [doc.page_content for doc in splitter.split_text(md_document)]

	chunk = ''
	if sections:
		chunk = sections[0]

	for section in sections[1:]:
		if len(chunk) + len(section) < max_length:
			chunk += section
		else:
			yield chunk
			chunk = section

	if chunk:
		yield chunk
