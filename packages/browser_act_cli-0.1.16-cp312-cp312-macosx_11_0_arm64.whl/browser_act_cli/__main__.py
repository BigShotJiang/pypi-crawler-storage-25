import sys
import time as _time

# Capture process-level timing as early as possible — before heavy imports.
# Store in a shared location so main.py callback can read it without circular imports.
import browser_act_cli as _pkg

_pkg._boot_perf_start = _time.perf_counter()
_pkg._boot_started_at_ms = round(_time.time() * 1000)

import typer
from click.exceptions import UsageError

from browser_act_cli.main import app
from browser_act_cli.models.responses import ErrorResponse

# ---------------------------------------------------------------------------
# Two-phase argument parsing: extract global flags from anywhere in argv,
# then feed cleaned args to typer so global options work regardless of position.
#
# Supports both:
#   browser-act --session mysession --format json browser open ...
#   browser-act browser open ... --session mysession --format json
# ---------------------------------------------------------------------------

# Global flags that consume the next arg as their value.
_GLOBAL_FLAGS_WITH_VALUE = ('--session', '--format', '--intent')

# Global boolean flags (no value).
_GLOBAL_BOOL_FLAGS = ('--no-auto-dialog',)


def _extract_global_flags(args: list[str]) -> tuple[list[str], list[str]]:
	"""Scan *args* and separate global flags from command args.

	Returns (global_flags, clean_args).
	global_flags are re-inserted before the subcommand so typer sees them.
	"""
	global_pairs: list[str] = []
	clean: list[str] = []
	i = 0
	while i < len(args):
		arg = args[i]
		if arg in _GLOBAL_FLAGS_WITH_VALUE:
			# Consume flag + value
			if i + 1 < len(args):
				global_pairs.extend([arg, args[i + 1]])
				i += 2
			else:
				# Missing value — let typer report the error
				clean.append(arg)
				i += 1
		elif arg in _GLOBAL_BOOL_FLAGS:
			global_pairs.append(arg)
			i += 1
		else:
			clean.append(arg)
			i += 1
	return global_pairs, clean


def _main() -> int:
	# Phase 1: extract global flags from anywhere in argv
	original_args = sys.argv[1:]
	global_flags, clean_args = _extract_global_flags(original_args)

	# Phase 2: reconstruct argv with global flags before subcommand
	sys.argv = [sys.argv[0], *global_flags, *clean_args]

	try:
		rv = app(standalone_mode=False)
	except UsageError as exc:
		print(ErrorResponse(error=exc.format_message()).model_dump_json())
		raise typer.Exit(1) from None
	except SystemExit:
		raise
	return rv or 0


if __name__ == '__main__':
	sys.exit(_main())
