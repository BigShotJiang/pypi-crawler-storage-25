"""CLI settings: Pydantic model with file + env override + write support."""

from __future__ import annotations

import json
import logging
import os
import tempfile
from typing import Any

from pydantic import BaseModel

from browser_act_cli.conf.const import IDLE_TIMEOUT
from browser_act_cli.conf.paths import config_path
from browser_act_cli.enums import OutputFormat

logger = logging.getLogger(__name__)


class Settings(BaseModel):
	"""CLI configuration. Loaded from config.json with built-in defaults."""

	# API authentication
	api_key: str = ''

	# Kernel connection
	server_url: str = 'https://api.browseract.com'
	root_dir: str = ''

	# CLI behavior
	default_format: str = OutputFormat.TEXT
	idle_timeout: int = IDLE_TIMEOUT

	# Auth session (written by auth login, read by auth poll)
	session_token: str = ''
	session_expired_at: str = ''

	# Machine identifier (random UUID, persisted on first generation)
	machine_id: str = ''

	# Analytics
	analytics_disabled: bool = False
	analytics_url: str = ''

	def kernel_config(self) -> dict[str, Any]:
		"""Build config dict for kernel BrowserManager."""
		return {
			'root_dir': self.root_dir,
			'server_url': self.server_url,
			'auth_token': self.api_key,
		}


_settings: Settings | None = None


def get_settings() -> Settings:
	"""Return the global Settings singleton. Loads on first call."""
	global _settings  # noqa: PLW0603
	if _settings is None:
		_settings = _load_settings()
	return _settings


def reset_settings() -> None:
	"""Reset the cached settings singleton so the next get_settings() re-loads from disk."""
	global _settings  # noqa: PLW0603
	_settings = None


def _read_config() -> dict[str, Any]:
	"""Read config.json, returning empty dict on missing/corrupt file."""
	path = config_path()
	if not path.exists():
		return {}
	try:
		return json.loads(path.read_text())
	except (json.JSONDecodeError, OSError) as e:
		logger.warning('Failed to read config: %s', e, exc_info=True)
		return {}


def _write_config(data: dict[str, Any]) -> None:
	"""Atomic write config.json (temp file + rename)."""
	path = config_path()
	path.parent.mkdir(parents=True, exist_ok=True)
	fd, tmp_path = tempfile.mkstemp(dir=path.parent, suffix='.tmp')
	try:
		with os.fdopen(fd, 'w') as f:
			json.dump(data, f, indent=2)
			f.write('\n')
		os.replace(tmp_path, path)
	except OSError:
		try:
			os.unlink(tmp_path)
		except OSError:
			pass
		raise
	reset_settings()


def _update_config(updates: dict[str, Any], *, remove: list[str] | None = None) -> None:
	"""Merge updates into config.json and optionally remove keys."""
	data = _read_config()
	data.update(updates)
	for key in remove or []:
		data.pop(key, None)
	_write_config(data)


def save_api_key(api_key: str) -> None:
	"""Write api_key to config.json, preserving existing fields."""
	_update_config({'api_key': api_key})


def remove_api_key() -> None:
	"""Remove api_key from config.json, preserving other fields."""
	_update_config({}, remove=['api_key'])


def _normalize_utc_timestamp(ts: str) -> str:
	"""Ensure a UTC timestamp string carries an explicit timezone suffix.

	The server may return bare strings like ``"2026-03-31 07:29:59"`` which
	are UTC but lack a timezone marker.  Without the marker, readers (human
	or code) may misinterpret the value as local time.  This function
	appends ``Z`` when no timezone indicator is present.
	"""
	if not ts:
		return ts
	import re

	# Already has timezone info: trailing Z, or +HH:MM / -HH:MM offset after time part
	if re.search(r'[Zz]$|[+-]\d{2}:\d{2}$|[+-]\d{4}$', ts.rstrip()):
		return ts
	return ts + 'Z'


def save_session_token(token: str, expired_at: str = '') -> None:
	"""Write session_token (and optional expired_at) to config.json."""
	_update_config({'session_token': token, 'session_expired_at': _normalize_utc_timestamp(expired_at)})


def clear_session_token() -> None:
	"""Remove session_token and session_expired_at from config.json."""
	_update_config({}, remove=['session_token', 'session_expired_at'])


def save_machine_id(machine_id: str) -> None:
	"""Write machine_id to config.json, preserving existing fields."""
	_update_config({'machine_id': machine_id})


def _is_session_expired(expired_at: str) -> bool:
	"""Return True if the session_expired_at timestamp is in the past."""
	if not expired_at:
		return False
	try:
		from datetime import datetime, timezone

		raw = expired_at.replace('Z', '+00:00')
		exp = datetime.fromisoformat(raw)
		if exp.tzinfo is None:
			exp = exp.replace(tzinfo=timezone.utc)
		return datetime.now(timezone.utc) >= exp
	except (ValueError, TypeError):
		return False


def _load_settings() -> Settings:
	"""Load settings: defaults → config.json → env vars."""
	data: dict[str, Any] = {}

	# Read config file
	path = config_path()
	if path.exists():
		try:
			data = json.loads(path.read_text())
		except (json.JSONDecodeError, OSError) as e:
			logger.warning('Failed to load config from %s: %s', path, e, exc_info=True)

	# Auto-clean expired session tokens so they don't linger forever
	# when a user runs "auth login" but never polls to completion.
	if data.get('session_token') and _is_session_expired(data.get('session_expired_at', '')):
		data.pop('session_token', None)
		data.pop('session_expired_at', None)
		try:
			_write_config(data)
		except OSError:
			pass  # Non-critical — will retry on next load

	return Settings(**data)
