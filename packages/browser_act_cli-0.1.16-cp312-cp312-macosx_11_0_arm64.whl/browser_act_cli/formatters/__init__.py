"""Output formatters (JSON, text)."""
