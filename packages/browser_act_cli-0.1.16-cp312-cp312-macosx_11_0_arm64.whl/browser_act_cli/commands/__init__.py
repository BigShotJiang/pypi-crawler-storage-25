from __future__ import annotations

import typer

from browser_act_cli.commands import (
	auth,
	browser_mgmt,
	browser_real,
	captcha,
	cookies,
	data,
	dialog,
	human_assist,  # noqa: F401
	navigation,
	network,
	page_action,
	page_state,
	session_mgmt,
	stealth_extract,
	system,
	tab,
	upload,
)

# Panel names for rich_help_panel grouping
_NAV = 'Navigation'
_PAGE_STATE = 'Page State'
_INTERACT = 'Page Interaction'
_DATA = 'Page Data'
_JS = 'JavaScript'
_WAIT = 'Wait'
_DIALOG = 'Dialog'
_ADVANCED = 'Advanced'
_SYSTEM = 'System'
_STEALTH = 'Stealth Browser'
_REAL = 'Real Chrome'
_CHROMIUM = 'Chromium'


def register_commands(
	app: typer.Typer,
	browser_app: typer.Typer,
	session_app: typer.Typer,
	tab_app: typer.Typer,
	get_app: typer.Typer,
	wait_app: typer.Typer,
	auth_app: typer.Typer,
	network_app: typer.Typer,
	dialog_app: typer.Typer,
	cookies_app: typer.Typer,
) -> None:
	"""Wire all command handlers to their typer apps."""
	# Top-level: Navigation
	# NOTE: explicit help= is required so descriptions survive Cython docstring stripping.
	app.command('navigate', rich_help_panel=_NAV, help='Navigate to URL on current page.')(navigation.navigate)
	app.command('back', rich_help_panel=_NAV, help='Go back in history.')(navigation.back)
	app.command('forward', rich_help_panel=_NAV, help='Go forward in history.')(navigation.forward)
	app.command('reload', rich_help_panel=_NAV, help='Reload current page.')(navigation.reload_page)

	# Top-level: Page State
	app.command('state', rich_help_panel=_PAGE_STATE, help='Get URL, title, and interactive elements.')(page_state.state)
	app.command('screenshot', rich_help_panel=_PAGE_STATE, help='Take page screenshot.')(page_state.screenshot)

	# Top-level: Page Interaction
	app.command('click', rich_help_panel=_INTERACT, help='Click element by index.')(page_action.click)
	app.command('type', rich_help_panel=_INTERACT, help='Type text into focused element.')(page_action.type_text)
	app.command('input', rich_help_panel=_INTERACT, help='Click element, then type text.')(page_action.input_text)
	app.command('keys', rich_help_panel=_INTERACT, help='Send keyboard keys (Enter, Tab, etc.).')(page_action.keys)
	app.command('select', rich_help_panel=_INTERACT, help='Select dropdown option.')(page_action.select)
	app.command('scrollintoview', rich_help_panel=_INTERACT, help='Scroll element into view by CSS selector.')(
		page_action.scrollintoview
	)
	app.command('hover', rich_help_panel=_INTERACT, help='Hover over element.')(page_action.hover)
	app.command('scroll', rich_help_panel=_INTERACT, help='Scroll up or down.')(page_action.scroll)
	app.command('upload', rich_help_panel=_INTERACT, help='Upload file to a file input element.')(upload.upload)

	# Top-level: Stealth Extract
	app.command('stealth-extract', rich_help_panel=_STEALTH, help='Extract page content with anti-detection browser.')(
		stealth_extract.stealth_extract_cmd
	)

	# Top-level: JavaScript
	app.command('eval', rich_help_panel=_JS, help='Execute JavaScript and return result.')(data.eval_js)

	# Top-level: Advanced
	app.command('captcha-aid', rich_help_panel=_ADVANCED, help='Assist with captcha on current page.')(captcha.bypass_captcha)
	app.command('solve-captcha', rich_help_panel=_ADVANCED, help='Solve captcha on current page.')(captcha.bypass_captcha)
	app.command('human-assist-url', rich_help_panel=_ADVANCED, help='Get human assist URL via zlink.')(
		human_assist.human_assist_url
	)

	# Top-level: System
	# app.command('install', rich_help_panel=_SYSTEM, help='Install dependencies.')(system.install)
	# app.command('doctor', rich_help_panel=_SYSTEM, help='Run diagnostic checks.')(system.doctor)
	app.command('report-log', rich_help_panel=_SYSTEM, help='Upload logs to help diagnose issues.')(system.report_log)
	app.command('feedback', rich_help_panel=_SYSTEM, help='Send feedback to help improve this skill.')(system.feedback)

	# Tab sub-app
	tab_app.command('list', help='List open tabs.')(tab.tab_list)
	tab_app.command('switch', help='Switch to tab by ID.')(tab.tab_switch)
	tab_app.command('close', help='Close tab (current if no ID given).')(tab.tab_close)

	# Get sub-app: Page Data
	get_app.command('title', rich_help_panel=_DATA, help='Get page title.')(data.get_title)
	# get_app.command('html', rich_help_panel=_DATA, help='Get page HTML (or element by CSS selector).')(data.get_html)
	get_app.command('html', rich_help_panel=_DATA, help='Get page HTML.')(data.get_html)
	get_app.command('text', rich_help_panel=_DATA, help='Get text content of element.')(data.get_text)
	get_app.command('value', rich_help_panel=_DATA, help='Get value of input/textarea.')(data.get_value)
	get_app.command('markdown', rich_help_panel=_DATA, help='Get page as markdown.')(data.get_markdown)
	# get_app.command('bbox', rich_help_panel=_DATA, help='Get element bounding box (x, y, width, height).')(data.get_bbox)

	# Network sub-app
	network_app.command('requests', help='List captured network requests.')(network.get_network_requests)
	network_app.command('request', help='Get full detail for a single network request.')(network.get_network_request_detail)
	network_app.command('clear', help='Clear all tracked network requests.')(network.clear_network_requests)
	network_app.command('offline', help='Toggle offline mode: "on" to disconnect, "off" to restore.')(network.set_offline)

	# Network > HAR sub-app
	har_app = typer.Typer(name='har', help='HAR recording (capture network traffic)')
	har_app.command('start', help='Start recording network traffic for HAR export.')(network.har_start)
	har_app.command('stop', help='Stop recording and save captured traffic as a HAR file.')(network.har_stop)
	network_app.add_typer(har_app)

	# Wait sub-app
	wait_app.callback(invoke_without_command=True)(network.wait_callback)
	wait_app.command('stable', help='Wait for page to become stable (document ready, network idle).')(network.wait_stable)
	wait_app.command('selector', help='Wait for element to reach a target state (visible/hidden/attached/detached).')(
		network.wait_selector
	)

	# Dialog sub-app
	dialog_app.command('accept', help='Accept the current dialog (OK). Optionally provide text for prompt dialogs.')(
		dialog.dialog_accept
	)
	dialog_app.command('dismiss', help='Dismiss (cancel) the current dialog.')(dialog.dialog_dismiss)
	dialog_app.command('status', help='Check if a JavaScript dialog is currently open.')(dialog.dialog_status)

	# Browser sub-app: Stealth Browser
	browser_app.command('open', rich_help_panel=_STEALTH, help='Open URL in a stealth browser.')(browser_mgmt.browser_open)
	browser_app.command('list', rich_help_panel=_STEALTH, help='List stealth browsers.')(browser_mgmt.browser_list)
	browser_app.command('create', rich_help_panel=_STEALTH, help='Create a stealth browser.')(browser_mgmt.browser_create)
	browser_app.command('update', rich_help_panel=_STEALTH, help='Update stealth browser settings.')(browser_mgmt.browser_update)
	browser_app.command('delete', rich_help_panel=_STEALTH, help='Delete a stealth browser.')(browser_mgmt.browser_delete)
	browser_app.command('clear-profile', rich_help_panel=_STEALTH, help='Clear browser profile data.')(
		browser_mgmt.browser_clear_profile
	)
	browser_app.command('regions', rich_help_panel=_STEALTH, help='List available proxy regions for dynamic proxy.')(
		browser_mgmt.browser_regions
	)

	# Browser real sub-app
	real_app = typer.Typer(name='real', help='Real Chrome browser with your login sessions')
	real_app.command('open', help='Open in real Chrome (auto-discover).')(browser_real.browser_real_open)
	browser_app.add_typer(real_app, rich_help_panel=_REAL)

	# Browser chromium sub-app (disabled)
	# chromium_app = typer.Typer(name='chromium', help='Playwright-managed Chromium browser')
	# chromium_app.command('open', help='Open URL in Built-in Chromium.')(browser_chromium.browser_chromium_open)
	# browser_app.add_typer(chromium_app, rich_help_panel=_CHROMIUM)

	# Session sub-app
	session_app.command('list', help='List active sessions.')(session_mgmt.session_list)
	session_app.command('close', help='Close session.')(session_mgmt.session_close)

	# Auth sub-app
	auth_app.command('login', help='Get registration link.')(auth.login)
	auth_app.command('poll', help='Check registration status.')(auth.poll)
	auth_app.command('set', help='Manually set an API key.')(auth.set_key)
	auth_app.command('clear', help='Remove the API key.')(auth.clear)

	# Cookies sub-app
	cookies_app.command('get', help='Get cookies (optionally filtered by URL).')(cookies.cookies_get)
	cookies_app.command('set', help='Set a cookie.')(cookies.cookies_set)
	cookies_app.command('clear', help='Clear cookies.')(cookies.cookies_clear)
	cookies_app.command('export', help='Export cookies to a JSON file.')(cookies.cookies_export)
	cookies_app.command('import', help='Import cookies from a JSON file.')(cookies.cookies_import)
