# -*- coding: utf-8 -*-
"""
CDP Remote View: package split from monolithic `cdpwsmgr/cdp_message_processor.py`.
Importing configures logging consistent with the legacy module (see `_log`).
"""
from . import _log  # noqa: F401
from .base import (
    CDP_TARGET_CLOSED_REASON_CRASH,
    CDP_TARGET_CLOSED_REASON_DETACHED,
    CDP_TARGET_CLOSED_REASON_DISCONNECT,
)
from .constants import CDP_WEBSOCKET_MAX_MESSAGE_BYTES
from .example import example_usage
from .messages import CDPMessage, MessageType
from .peer_commands import (
    PEER_BINARY_SUBCMD_CLIPBOARD,
    PEER_BINARY_SUBCMD_CUSTOM_DATA,
    PEER_CMD_BROWSER_CLOSED,
    PEER_CMD_FORWARD_CMD,
    PEER_CMD_GEN_KEY_FRAME,
    PEER_CMD_SWITCH_CDP_DEBUGGER,
)
from .peer_custom_data import PeerCustomDataMixin
from .processor import CDPMessageProcessor
from .tab import TabMixin

__all__ = [
    "CDP_WEBSOCKET_MAX_MESSAGE_BYTES",
    "CDP_TARGET_CLOSED_REASON_CRASH",
    "CDP_TARGET_CLOSED_REASON_DETACHED",
    "CDP_TARGET_CLOSED_REASON_DISCONNECT",
    "CDPMessage",
    "CDPMessageProcessor",
    "MessageType",
    "PEER_BINARY_SUBCMD_CLIPBOARD",
    "PEER_BINARY_SUBCMD_CUSTOM_DATA",
    "PEER_CMD_BROWSER_CLOSED",
    "PEER_CMD_SWITCH_CDP_DEBUGGER",
    "PEER_CMD_GEN_KEY_FRAME",
    "PEER_CMD_FORWARD_CMD",
    "PeerCustomDataMixin",
    "TabMixin",
    "example_usage",
]
