"""Unified browser_use imports for browser_act_core consumers."""

import importlib
from typing import TYPE_CHECKING

from browser_act_core.runtime.bootstrap import ensure_vendor_patched

if TYPE_CHECKING:
	from browser_act_core.vendor.browser_use.actor.page_adapter import (
		Context,
		Frame,
		Locator,
		LocatorNode,
		Mouse,
		Page,
		UrlGlobMatcher,
	)
	from browser_act_core.vendor.browser_use.agent.views import ActionResult
	from browser_act_core.vendor.browser_use.browser.events import (
		ClickElementEvent,
		CloseTabEvent,
		ScrollEvent,
		SendKeysEvent,
		SwitchTabEvent,
		TypeTextEvent,
	)
	from browser_act_core.vendor.browser_use.browser.python_highlights import create_highlighted_screenshot
	from browser_act_core.vendor.browser_use.browser.session import BrowserSession
	from browser_act_core.vendor.browser_use.browser.views import BrowserStateSummary
	from browser_act_core.vendor.browser_use.dom.serializer.serializer import DOMTreeSerializer
	from browser_act_core.vendor.browser_use.dom.views import DOMSelectorMap, EnhancedDOMTreeNode, NodeType, SerializedDOMState
	from browser_act_core.vendor.page_ready.main import wait_for_page_ready
else:
	ensure_vendor_patched()
	# Runtime must import shared types from public aliases after patching.
	# Mixing vendor-path and browser_use-path imports creates class identity splits.
	_page_adapter = importlib.import_module('browser_use.actor.page_adapter')
	_agent_views = importlib.import_module('browser_use.agent.views')
	_events = importlib.import_module('browser_use.browser.events')
	_browser_views = importlib.import_module('browser_use.browser.views')
	_dom_serializer = importlib.import_module('browser_use.dom.serializer.serializer')
	_dom_views = importlib.import_module('browser_use.dom.views')
	_highlights = importlib.import_module('browser_use.browser.python_highlights')
	_page_ready = importlib.import_module('browser_act_core.vendor.page_ready.main')
	Context = _page_adapter.Context
	Frame = _page_adapter.Frame
	Locator = _page_adapter.Locator
	LocatorNode = _page_adapter.LocatorNode
	Mouse = _page_adapter.Mouse
	UrlGlobMatcher = _page_adapter.UrlGlobMatcher
	Page = _page_adapter.Page
	ActionResult = _agent_views.ActionResult
	ClickElementEvent = _events.ClickElementEvent
	CloseTabEvent = _events.CloseTabEvent
	ScrollEvent = _events.ScrollEvent
	SendKeysEvent = _events.SendKeysEvent
	SwitchTabEvent = _events.SwitchTabEvent
	TypeTextEvent = _events.TypeTextEvent
	create_highlighted_screenshot = _highlights.create_highlighted_screenshot
	DOMTreeSerializer = _dom_serializer.DOMTreeSerializer
	BrowserStateSummary = _browser_views.BrowserStateSummary
	DOMSelectorMap = _dom_views.DOMSelectorMap
	EnhancedDOMTreeNode = _dom_views.EnhancedDOMTreeNode
	NodeType = _dom_views.NodeType
	SerializedDOMState = _dom_views.SerializedDOMState
	wait_for_page_ready = _page_ready.wait_for_page_ready
	BrowserSession = importlib.import_module('browser_use.browser.session').BrowserSession

__all__ = [
	'ActionResult',
	'BrowserSession',
	'BrowserStateSummary',
	'ClickElementEvent',
	'CloseTabEvent',
	'Context',
	'create_highlighted_screenshot',
	'DOMTreeSerializer',
	'DOMSelectorMap',
	'EnhancedDOMTreeNode',
	'Frame',
	'Locator',
	'LocatorNode',
	'Mouse',
	'NodeType',
	'Page',
	'ScrollEvent',
	'SendKeysEvent',
	'SerializedDOMState',
	'SwitchTabEvent',
	'TypeTextEvent',
	'UrlGlobMatcher',
	'wait_for_page_ready',
]
