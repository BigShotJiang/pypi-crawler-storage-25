"""Runtime placeholders for browser_act_core."""
