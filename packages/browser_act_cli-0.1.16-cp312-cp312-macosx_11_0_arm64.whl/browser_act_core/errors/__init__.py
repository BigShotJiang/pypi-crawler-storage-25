"""Errors for browser_act_core."""

from .core_errors import (
	ActionTargetError,
	CaptureError,
	ConnectionError,
	CoreError,
	ElementNotInteractableError,
	FrameDetachedError,
	JavaScriptError,
	LocatorError,
	NavigationError,
	PageClosedError,
	SnapshotError,
	StaleNodeReferenceError,
	TimeoutError,
	WaitError,
)

__all__ = [
	'CoreError',
	'ConnectionError',
	'PageClosedError',
	'FrameDetachedError',
	'LocatorError',
	'StaleNodeReferenceError',
	'SnapshotError',
	'ActionTargetError',
	'ElementNotInteractableError',
	'NavigationError',
	'TimeoutError',
	'WaitError',
	'CaptureError',
	'JavaScriptError',
]
