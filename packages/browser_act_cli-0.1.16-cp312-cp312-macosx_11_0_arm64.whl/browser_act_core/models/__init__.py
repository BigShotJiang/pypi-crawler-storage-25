"""DTO exports for browser_act_core."""

from .action import ActionResult
from .capture import ElementCaptureArtifact
from .frame import FrameMetadata
from .node import BoxRect, NodeRef
from .page import PageMetadata, ViewportInfo
from .snapshot import ElementSnapshot, SnapshotBundle

__all__ = [
	'ActionResult',
	'BoxRect',
	'ElementCaptureArtifact',
	'ElementSnapshot',
	'FrameMetadata',
	'NodeRef',
	'PageMetadata',
	'SnapshotBundle',
	'ViewportInfo',
]
