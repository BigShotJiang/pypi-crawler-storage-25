"""browser_act_core package.

Public API exports are listed in ``__all__``.  The following types are
intentionally **not** exported — consumers obtain them indirectly:

* ``Locator`` — via ``frame.locator(selector=…)``
* ``NodeRef`` — via ``ElementSnapshot.node`` (from snapshot capture)
* ``ViewportInfo`` — via ``page.viewport_info()``

These types can still be imported directly for type annotations::

    from browser_act_core.models.node import NodeRef
    from browser_act_core.models.page import ViewportInfo
    from browser_act_core.locator import Locator
"""

from browser_act_core.actions_handle import ActionsHandle
from browser_act_core.browser_connection import BrowserConnection
from browser_act_core.capture_handle import CaptureHandle
from browser_act_core.dom_handle import DomHandle
from browser_act_core.errors.core_errors import (
	ActionTargetError,
	CaptureError,
	ConnectionError,
	CoreError,
	DomError,
	ElementNotInteractableError,
	FrameDetachedError,
	FrameError,
	JavaScriptError,
	LocatorError,
	MarkdownError,
	NavigationError,
	PageClosedError,
	SnapshotError,
	StaleNodeReferenceError,
	TimeoutError,
	WaitError,
)
from browser_act_core.frame_handle import FrameHandle
from browser_act_core.models.action import ActionResult
from browser_act_core.models.page import PageMetadata
from browser_act_core.models.snapshot import ElementSnapshot, SnapshotBundle
from browser_act_core.mouse_handle import MouseHandle
from browser_act_core.network_handle import NetworkHandle
from browser_act_core.page_handle import PageHandle
from browser_act_core.runtime.connection_logging import ConnectionLogConfig
from browser_act_core.snapshot_handle import SnapshotHandle
from browser_act_core.tabs_handle import TabsHandle
from browser_act_core.wait_handle import WaitHandle

__version__ = '0.1.0'

__all__ = [
	'BrowserConnection',
	'ConnectionLogConfig',
	'PageHandle',
	'TabsHandle',
	'CaptureHandle',
	'DomHandle',
	'FrameHandle',
	'WaitHandle',
	'NetworkHandle',
	'SnapshotHandle',
	'ActionsHandle',
	'MouseHandle',
	'SnapshotBundle',
	'ElementSnapshot',
	'PageMetadata',
	'ActionResult',
	'CoreError',
	'ConnectionError',
	'DomError',
	'PageClosedError',
	'FrameError',
	'FrameDetachedError',
	'LocatorError',
	'MarkdownError',
	'StaleNodeReferenceError',
	'SnapshotError',
	'ActionTargetError',
	'ElementNotInteractableError',
	'NavigationError',
	'TimeoutError',
	'WaitError',
	'CaptureError',
	'JavaScriptError',
]
