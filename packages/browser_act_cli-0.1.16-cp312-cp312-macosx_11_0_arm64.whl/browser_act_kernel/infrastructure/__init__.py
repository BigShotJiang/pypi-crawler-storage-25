"""Infrastructure layer: runtime, API clients, IPC, launchers."""
