"""IPC infrastructure: endpoint factories, connection pool, IPC clients."""
