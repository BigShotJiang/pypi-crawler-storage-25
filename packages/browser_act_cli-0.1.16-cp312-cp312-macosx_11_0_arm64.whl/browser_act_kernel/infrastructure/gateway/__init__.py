"""Gateway launcher infrastructure."""
