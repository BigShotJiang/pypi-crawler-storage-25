"""Browser kernel launcher infrastructure."""
