"""Runtime infrastructure: paths, record store, locks, directory management."""
