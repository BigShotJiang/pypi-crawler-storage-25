"""Server API clients: HTTP base, kernel, browser CRUD, report."""
