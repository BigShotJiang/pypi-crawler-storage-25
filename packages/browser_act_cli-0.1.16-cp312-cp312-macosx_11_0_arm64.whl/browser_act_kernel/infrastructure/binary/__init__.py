"""Binary resolution for kernel and gateway executables."""
