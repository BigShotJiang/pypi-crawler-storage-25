"""browser-act-kernel: Browser lifecycle management library."""

from browser_act_kernel.context import ManagerContext
from browser_act_kernel.application.relay_service import RelayService
from browser_act_kernel.domain.data_models import (
	BrowserPathsData,
	BrowserStatusData,
	ClearBrowserProfileData,
	CreateBrowserData,
	CreateRelayData,
	DeleteBrowserData,
	DeleteRelayData,
	InstallBinaryData,
	ListBrowsersData,
	RefreshFingerprintData,
	StartBrowserData,
	StopBrowserData,
	UpdateBrowserData,
	UpdateConfigData,
	WriteFileData,
)
from browser_act_kernel.domain.enums import BrowserProfileMode, BrowserStatus, Phase
from browser_act_kernel.domain.error_codes import ErrorCode
from browser_act_kernel.domain.result import ErrorInfo, OperationResult, ResultMeta
from browser_act_kernel.manager import BrowserManager

__all__ = [
	'BrowserManager',
	'RelayService',
	'ManagerContext',
	'OperationResult',
	'ErrorInfo',
	'ResultMeta',
	'ErrorCode',
	'BrowserStatus',
	'BrowserProfileMode',
	'Phase',
	'StartBrowserData',
	'StopBrowserData',
	'BrowserStatusData',
	'InstallBinaryData',
	'WriteFileData',
	'BrowserPathsData',
	'UpdateConfigData',
	'CreateBrowserData',
	'CreateRelayData',
	'UpdateBrowserData',
	'DeleteBrowserData',
	'DeleteRelayData',
	'ClearBrowserProfileData',
	'RefreshFingerprintData',
	'ListBrowsersData',
]
