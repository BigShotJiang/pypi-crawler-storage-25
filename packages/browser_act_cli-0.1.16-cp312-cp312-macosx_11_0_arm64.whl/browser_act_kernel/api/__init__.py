"""FastAPI entrypoints for exposing BrowserManager over HTTP.

# @file purpose: Exports the FastAPI app factory used by the standalone kernel
# HTTP server script and tests.
"""

from browser_act_kernel.api.app import create_app

__all__ = ['create_app']
