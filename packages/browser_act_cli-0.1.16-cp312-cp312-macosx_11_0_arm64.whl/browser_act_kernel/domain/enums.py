"""Domain enums: BrowserStatus, BrowserProfileMode, Phase."""

from enum import StrEnum


class BrowserStatus(StrEnum):
	IDLE = 'idle'
	STARTING = 'starting'
	RUNNING = 'running'
	STOPPING = 'stopping'
	STOPPED = 'stopped'
	FAILED = 'failed'
	CRASHED = 'crashed'


class BrowserProfileMode(StrEnum):
	NORMAL = 'normal'
	PRIVATE = 'private'


class Phase(StrEnum):
	VALIDATE_INPUT = 'validate_input'
	CHECK_BROWSER = 'check_browser'
	ACQUIRE_LOCK = 'acquire_lock'
	BUILD_IPC = 'build_ipc'
	FETCH_START_CONFIG = 'fetch_start_config'
	VALIDATE_PAYLOAD = 'validate_payload'
	CHECK_KERNEL = 'check_kernel'
	CHECK_GATEWAY = 'check_gateway'
	LAUNCH_GATEWAY = 'launch_gateway'
	WAIT_GATEWAY_IPC = 'wait_gateway_ipc'
	LAUNCH_BROWSER = 'launch_browser'
	WAIT_BROWSER_IPC = 'wait_browser_ipc'
	WAIT_START_EVENT = 'wait_start_event'
	DETECT_CDP_PORT = 'detect_cdp_port'
	PERSIST_RUNTIME = 'persist_runtime'
	CLEANUP = 'cleanup'
	LOAD_RUNTIME = 'load_runtime'
	STOP_BROWSER_PROCESS = 'stop_browser_process'
	STOP_GATEWAY_PROCESS = 'stop_gateway_process'
	CLEAR_RUNTIME = 'clear_runtime'
	PROBE_STATUS = 'probe_status'
	VERIFY_KERNEL_INTEGRITY = 'verify_kernel_integrity'
	DOWNLOAD_BINARY = 'download_binary'
	VERIFY_CHECKSUM = 'verify_checksum'
	EXTRACT_AND_INSTALL = 'extract_and_install'
	RESOLVE_BROWSER_REF = 'resolve_browser_ref'
	PERSIST_BROWSER_RECORD = 'persist_browser_record'
	CLEAR_PROFILE = 'clear_profile'
	LIST_BROWSER_RECORDS = 'list_browser_records'
	REFRESH_FINGERPRINT = 'refresh_fingerprint'
	CREATE_RELAY = 'create_relay'
	DELETE_RELAY = 'delete_relay'
	FETCH_WORKBENCH_CONFIG = 'fetch_workbench_config'
