"""Domain layer: enums, models, error codes, result types."""
