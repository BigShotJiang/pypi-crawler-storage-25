"""Workbench mode constants — fixed initjson, IPC endpoint names, public API path.

# @file purpose: Hardcoded constants for run_type=4 workbench mode.
# The encrypted initjson differs per platform because the embedded IPC pipe
# names differ (Windows named pipe vs POSIX UDS path).
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Fixed browser_id for workbench sessions
# ---------------------------------------------------------------------------
WORKBENCH_BROWSER_ID: str = 'workbench'

# ---------------------------------------------------------------------------
# Encrypted initjson — one per platform (IPC pipe names + can_webdriver baked in)
# ---------------------------------------------------------------------------
WORKBENCH_INITJSON_WINDOWS: str = (
	'1a/AUznY7RfXoUSFCDAjbGU2TG27u5uqzh0DuntzX/mu/Z7xr4fQNbsVCLKDWXlx6tPJ++Rrx3xZ'
	'Zj1BrURQhcYDeJbmvvxE+opo0EJ8PrmNV/JdbMvnqGxTwme6KEJbTTSqVzRZKMFPQd8xbQ3ZNL+7'
	'Ri49Xo0YxWiV9Dr44RK8AMdMQqlMdNh6QFLwnM3jchpRAq35UeG+GCs2c96b+deSlvzWQfaUgzNrr'
	'KEha0XNcFFOhVH9kiTPzTdbduAuXZw1AKr6mi2sPLQEsR/cjLerddZTEUBsj1QSC+G7IVwAzqMj4T'
	'AT5Dr+6OVLWDfi6JYpw8fazSCXUElXtc5vcy3bHSMjnkbnaMvIOrseDYw='
)

WORKBENCH_INITJSON_POSIX: str = (
	'/ZwRm5NEj6pgr1+/vjTEh3GCuBu6YGmwTdqhXHhFg1V/kKURmcer7fXukiIzCJY9QuHUu7IxGyIl'
	'EwIp2KtShp1rUkjXOGzLdCiFTikKvWasjknXVH6Mt8F2bI0YAnANMQCYlj+BpJD9a43PNO2jGrQQ'
	'Ze3wZHqcsDMoKt+w/XwoYR2Ki3V2SJRa4Re777WB2x/e1KUORkRuEk47ik3eiBmQSXIk2nog74DJ'
	'TkxFCTM69uS8OFd0gL25uciK3m6/yzQu3koCszTfZOyiW/QnU6zVn39ldjr16nY06pQ89Tq7Kw9x'
	'gWQWrxRL+35KoOzkGKaZL/CWSxVm9fltAOodJBwy0Uy2KxdlmYbIrB0RyOEDt55bP2qynFayaCAG'
	'I3k8AeypOJ0qPA3QIqcz8lLk1/+tyWFIHgmDRO5JmjoOQz37r1yaF1Gk7gK6Qjn6CEXb3zjLwQY'
	'Fb6Bxb5rCUxbvho6dQHLs1hTTBIdJO30qnH3F6+624I29FY3+4WlMBtw3E+EKMLXmHpqN1zcgQSp'
	'W1MBHtIl1ue36Pd8DYhJyRmo='
)

# ---------------------------------------------------------------------------
# Encrypted store_data_path — pre-encrypted profile directory per platform
# ---------------------------------------------------------------------------
WORKBENCH_STORE_PATH_WINDOWS: str = (
	'XP/ORQemdJbyYAQcBiRG5IuFiIFmlGMzg/Q502UOyJI7lhRLRFQhU4NziLeMFam9zguZI/STqz3cL'
	'OTPlCTGQH8T29/OKKjhyhwUtHEYopQ='
)

WORKBENCH_STORE_PATH_POSIX: str = (
	'YYXyxPu7aEjzjw0vggrHEkHRaSXjXOX1M9QkFw2A/9zw93XdEIWChq7EbeKwFA7B'
)

# ---------------------------------------------------------------------------
# Fixed IPC endpoint names — no nonce, deterministic per platform
# ---------------------------------------------------------------------------
WORKBENCH_IPC_LISTENER_WINDOWS: str = 'workbenchlisten'
WORKBENCH_IPC_FROM_CLIENT_WINDOWS: str = 'envkit_workbench'

WORKBENCH_IPC_LISTENER_POSIX: str = '/tmp/.superbrowser/uds_wb_workbench'
WORKBENCH_IPC_FROM_CLIENT_POSIX: str = '/tmp/.superbrowser/uds_workbench'

# ---------------------------------------------------------------------------
# Public API path (no authentication required)
# ---------------------------------------------------------------------------
PUBLIC_START_CONFIG_PATH: str = '/open/browser/start-config'
