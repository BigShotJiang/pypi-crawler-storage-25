"""Per-service data models returned inside OperationResult.data."""

from __future__ import annotations

from pydantic import BaseModel

from browser_act_kernel.domain.enums import BrowserProfileMode, BrowserStatus
from browser_act_kernel.domain.models import BrowserListItem


class StartBrowserData(BaseModel):
	browser_id: str
	name: str | None = None
	description: str | None = None
	status: BrowserStatus
	browser_pid: int | None = None
	gateway_pid: int | None = None
	cdp_port: int | None = None
	cdp_healthy: bool | None = None
	cdp_error: str | None = None
	proxy_session_id: int | None = None


class StopBrowserData(BaseModel):
	browser_id: str
	status: BrowserStatus


class BrowserStatusData(BaseModel):
	browser_id: str
	status: BrowserStatus
	browser_pid: int | None = None
	gateway_pid: int | None = None
	cdp_port: int | None = None
	ipc_connected: bool | None = None
	gateway_status: str | None = None


class InstallBinaryData(BaseModel):
	binary_type: str
	version: str
	install_path: str
	checksum: str | None = None


class WriteFileData(BaseModel):
	browser_id: str
	relative_path: str
	bytes_written: int


class BrowserPathsData(BaseModel):
	browser_id: str
	base_dir: str
	profile_dir: str
	runtime_dir: str
	record_path: str


class UpdateConfigData(BaseModel):
	config_path: str
	updated_fields: list[str]


class CreateBrowserData(BaseModel):
	browser_id: str
	name: str
	description: str | None = None
	mode: BrowserProfileMode


class UpdateBrowserData(BaseModel):
	browser_id: str
	name: str | None = None
	description: str | None = None
	mode: BrowserProfileMode | None = None


class DeleteBrowserData(BaseModel):
	browser_id: str


class ClearBrowserProfileData(BaseModel):
	browser_id: str
	profile_cleared: bool


class RefreshFingerprintData(BaseModel):
	browser_id: str


class ListBrowsersData(BaseModel):
	items: list[BrowserListItem]
	page: int
	limit: int
	total_count: int
	total_pages: int | None = None


class RelayProxy(BaseModel):
	address: str
	port: int
	username: str
	password: str
	proxy_type: str


class CreateRelayData(BaseModel):
	browser_id: str
	relay_pid: int
	config_path: str
	relay_id: int | None = None
	gateway_pid: int | None = None
	proxy: RelayProxy | None = None


class DeleteRelayData(BaseModel):
	browser_id: str
	server_deleted: bool
	process_killed: bool
	config_deleted: bool


class RestartGatewayData(BaseModel):
	gateway_pid: int
	session_id: int | None = None
