"""Domain models: RuntimeRecord, BrowserRecord, config schemas."""

from __future__ import annotations

from typing import Any

from pydantic import AliasChoices, BaseModel, Field, field_validator

from browser_act_kernel.domain.enums import BrowserProfileMode, BrowserStatus
from browser_act_kernel.domain.platform import normalize_arch, normalize_os


class IpcConfig(BaseModel):
	endpoint: str
	ipc_type: str


class WebServerInfo(BaseModel):
	host: str = '127.0.0.1'
	port: int = 0


class GatewayRuntimeOffer(BaseModel):
	ipc_endpoint: str
	ipc_type: str
	web_server_info: WebServerInfo | None = None


class AdvancedConfig(BaseModel):
	ipc_config: IpcConfig


class StartConfigIpc(BaseModel):
	browser_window_name: str
	from_client_pipe: str
	is_pipe: bool
	rnclient_window_name: str
	to_client_pipe: str


class StartConfigRaw(BaseModel):
	run_type: int = 2


class GatewayInboundInfo(BaseModel):
	port: int
	username: str
	password: str
	proxy_type: str
	address: str


class GatewayProxyInfo(BaseModel):
	proxy_type: str
	idx: str
	address: str | None = None
	port: int | None = None
	username: str | None = None
	password: str | None = None


class GatewayWebServerInfo(BaseModel):
	web_server_port: str
	web_server_token: str


class GatewayLaunchPayload(BaseModel):
	log_path: str
	named_pipe_address: str
	log_level: str
	inbound_info: GatewayInboundInfo
	proxy_infos: list[GatewayProxyInfo]
	web_server_info: GatewayWebServerInfo


class RuntimeRecord(BaseModel):
	browser_id: str
	runtime_nonce: str
	launch_generation: int
	browser_pid: int | None = None
	gateway_pid: int | None = None
	gateway_ipc_endpoint: str | None = None
	browser_ipc_endpoint: str | None = None
	cdp_port: int | None = None
	kernel_version: str | None = None
	gateway_version: str | None = None
	gateway_download_url: str | None = None
	relay_pid: int | None = None
	relay_config_path: str | None = None
	relay_version: str | None = None
	relay_download_url: str | None = None
	relay_ip: str | None = None
	relay_port: int | None = None
	relay_requested_port: int | None = None
	state: BrowserStatus = BrowserStatus.IDLE


class BrowserRecord(BaseModel):
	browser_id: str
	name: str
	description: str | None = None
	proxy: str | None = None
	proxy_type: int | None = None  # 0=BA proxy, 1=custom proxy, 2=no proxy
	proxy_region: str | None = None  # region code for BA proxy (e.g. US)
	mode: BrowserProfileMode
	created_at_ms: int
	updated_at_ms: int


class BrowserListItem(BaseModel):
	browser_id: str = Field(validation_alias=AliasChoices('browser_id', 'id'))
	name: str
	description: str | None = None
	mode: BrowserProfileMode | None = None
	status: BrowserStatus | None = None
	browser_pid: int | None = None
	gateway_pid: int | None = None
	cdp_port: int | None = None
	ipc_connected: bool | None = None
	has_local_record: bool = False


class StartConfigRequest(BaseModel):
	browser_id: str
	machine_code: str
	os_type: str
	os_arch: str
	os_version: str
	client_runtime_version: str
	user_data_path: str
	advanced: AdvancedConfig | None = None
	raw: StartConfigRaw = Field(default_factory=StartConfigRaw)
	ipc: StartConfigIpc | None = None
	proxy: dict[str, Any] | None = None
	gateway_runtime_offer: GatewayLaunchPayload | None = None

	@field_validator('os_type')
	@classmethod
	def _normalize_os_type(cls, v: str) -> str:
		return normalize_os(v)

	@field_validator('os_arch')
	@classmethod
	def _normalize_os_arch(cls, v: str) -> str:
		return normalize_arch(v)


class StartConfigResponse(BaseModel):
	model_config = {'populate_by_name': True}

	success: bool
	browser_id: str
	browser_app_version: str | None = None
	kernel_version: str | None = None
	gateway_version: str | None = None
	encrypted_initjson: str | None = None
	encrypted_user_data_path: str | None = None
	encrypted_gateway_payload: str | None = None
	kernel_download_url: str | None = None
	gateway_download_url: str | None = None
	relay_download_url: str | None = Field(default=None, validation_alias=AliasChoices('relay_download_url', 'frp_download_url'))
	relay_version: str | None = Field(default=None, validation_alias=AliasChoices('relay_version', 'frp_version'))
	session_id: int | None = None
	proxy_type: int | None = None
	error_message: str | None = None


class BinaryManifest(BaseModel):
	version: str
	type: str
	installed_at_ms: int
	checksum: str | None = None
	source_url: str | None = None
	executable: str


# ---------------------------------------------------------------------------
# Workbench mode (run_type=4) — public API models
# ---------------------------------------------------------------------------


class WorkbenchStartConfigRequest(BaseModel):
	"""Request body for POST /open/browser/start-config (no auth)."""

	os_type: str
	os_arch: str
	browser_type: str = 'chrome'
	store_data_path: str

	@field_validator('os_type')
	@classmethod
	def _normalize_os_type(cls, v: str) -> str:
		return normalize_os(v)

	@field_validator('os_arch')
	@classmethod
	def _normalize_os_arch(cls, v: str) -> str:
		return normalize_arch(v)

	@field_validator('store_data_path')
	@classmethod
	def _normalize_path(cls, v: str) -> str:
		"""Use forward slashes — the server rejects Windows backslashes."""
		return v.replace('\\', '/')


class WorkbenchStartConfigResponse(BaseModel):
	"""Response from POST /open/browser/start-config (no auth)."""

	success: bool = True
	browser_app_version: str | None = None
	kernel_download_url: str | None = None
	kernel_version: str | None = None
	gateway_download_url: str | None = None
	gateway_version: str | None = None
	frp_download_url: str | None = None
	frp_version: str | None = None
	store_data_path: str | None = None
	error_message: str | None = None
