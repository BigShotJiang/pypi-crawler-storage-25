"""Domain platform rules — OS/arch normalization as pure value-object logic.

# @file purpose: Provides deterministic normalization of OS and architecture
# identifiers without any host-platform detection.  These are domain rules that
# define which values are valid and how aliases map to canonical forms.
#
# Canonical values:
#   os   → windows | linux | darwin
#   arch → x86_64  | arm64
"""

from __future__ import annotations

_OS_MAP: dict[str, str] = {
	'windows': 'windows',
	'linux': 'linux',
	'darwin': 'darwin',
}

_ARCH_MAP: dict[str, str] = {
	'x86_64': 'x86_64',
	'amd64': 'x86_64',
	'x64': 'x86_64',
	'arm64': 'arm64',
	'aarch64': 'arm64',
}

VALID_OS_VALUES: frozenset[str] = frozenset(_OS_MAP.values())
VALID_ARCH_VALUES: frozenset[str] = frozenset(_ARCH_MAP.values())


def normalize_os(raw: str) -> str:
	"""Normalize an OS identifier to one of: ``windows``, ``linux``, ``darwin``.

	Raises :class:`ValueError` if the value is not a recognised OS or alias.
	"""
	result = _OS_MAP.get(raw.lower())
	if result is None:
		raise ValueError(f'Unsupported OS: {raw}')
	return result


def normalize_arch(raw: str) -> str:
	"""Normalize an architecture identifier to one of: ``x86_64``, ``arm64``.

	Raises :class:`ValueError` if the value is not a recognised architecture or alias.
	"""
	result = _ARCH_MAP.get(raw.lower())
	if result is None:
		raise ValueError(f'Unsupported architecture: {raw}')
	return result
