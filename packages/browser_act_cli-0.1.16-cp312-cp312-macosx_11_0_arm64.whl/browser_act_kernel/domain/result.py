"""Unified result wrapper: OperationResult[T], ErrorInfo, ResultMeta."""

from __future__ import annotations

from typing import Any, Generic, TypeVar

from pydantic import BaseModel

T = TypeVar('T')


class ErrorInfo(BaseModel):
	error_code: int
	name: str
	phase: str
	message: str
	retryable: bool = False
	next_action: str | None = None
	details: dict[str, Any] | None = None


class ResultMeta(BaseModel):
	timestamp_ms: int
	duration_ms: int | None = None
	request_id: str | None = None


class OperationResult(BaseModel, Generic[T]):
	success: bool
	data: T | None = None
	error: ErrorInfo | None = None
	meta: ResultMeta | None = None
