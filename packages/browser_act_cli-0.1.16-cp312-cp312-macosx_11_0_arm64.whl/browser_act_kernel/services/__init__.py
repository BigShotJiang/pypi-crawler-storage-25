"""Service layer: cross-cutting services (recovery, etc.)."""
