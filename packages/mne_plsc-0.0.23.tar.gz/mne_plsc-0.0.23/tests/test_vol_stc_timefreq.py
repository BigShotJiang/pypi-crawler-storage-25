
import pytest
import mne
import mne_plsc
import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
from pathlib import Path

import matplotlib
matplotlib.use('Agg', force=True)

from pdb import set_trace

@pytest.fixture
def sample_data(request):
    fixture_path = Path(request.fspath.dirpath()) / "fixtures"
    src = mne.read_source_spaces(fixture_path / 'vol-src.fif.gz')
    vertices = src[0]['vertno']
    np.random.seed(123)
    n_ptpt = 10
    between = ['b1']*n_ptpt + ['b2']*n_ptpt
    within = ['w1', 'w2']*n_ptpt
    participant = np.cumsum([1, 0]*n_ptpt)
    covariates = np.random.normal(size=(2*n_ptpt, 2))
    sfreq = 20
    times = np.arange(0, 1, 1/sfreq)
    freqs = np.linspace(3, 30, 5)
    n_vert = len(vertices)
    stcs = []
    for ptpt in range(n_ptpt*2):
        ptpt_stcs = []
        for freq in freqs:
            array_data = np.random.normal(size=(n_vert, len(freqs)))
            array_data[between == 'b2'] += 1
            array_data[between == 'w2'] += 1
            stc = mne.VolSourceEstimate(data=array_data,
                                        vertices=[vertices],
                                        tmin=times[0],
                                        tstep=1/sfreq,
                                        subject='fsaverage')
            ptpt_stcs.append(stc)
        stcs.append(ptpt_stcs)
    return stcs, covariates, between, within, participant, src

def run_result_plots(result):
    result.plot_boot_stat(0)
    result.plot_brain_sals(lv_idx=0)
    # result.plot_cluster_sizes(lv_idx=0)
    if 'plot_marginal_brain_scores' in dir(result):
        result.plot_marginal_brain_scores(lv_idx=0, margin='time')
    # Can't test cluster visualization
    result.plot_lv(lv_idx=0)
    result.plot_scores(lv_idx=0)
    plt.close('all')

def run_result_methods(result, src):
    result.add_source_info(src=src)
    result.add_adjacency()
    result.cluster()
    result.brain_sals_to_mne(0)
    result.model.permute(10)
    result.model.bootstrap(10)
    # result.cluster(which='z-scores')
    run_result_plots(result)

def test_mc_both(sample_data):
    data, _, between, within, participant, src = sample_data
    freqs = np.linspace(3, 30, 5)
    result = mne_plsc.fit_mc(data=data,
                                 between=between,
                                 within=within,
                                 participant=participant,
                                 random_state=123,
                                 source_domain='time-freq',
                                 source_freqs=freqs)
    run_result_methods(result, src)

def test_mc_within(sample_data):
    data, _, between, within, participant, src = sample_data
    freqs = np.linspace(3, 30, 5)
    result = mne_plsc.fit_mc(data=data,
                                 within=within,
                                 participant=participant,
                                 random_state=123,
                                 source_domain='time-freq',
                                 source_freqs=freqs)
    run_result_methods(result, src)

def test_beh_args(sample_data):
    # Test different methods of providing data
    data, covariates, between, within, participant, src = sample_data
    freqs = np.linspace(3, 30, 5)
    mne_plsc.fit_beh(data=data,
                     covariates=covariates[:, 0],
                     random_state=123,
                     source_domain='time-freq',
                     source_freqs=freqs)
    design = pd.DataFrame(covariates,
                          columns=['cov1', 'cov2'])
    design['group'] = between
    design['cond'] = within
    design['ptpt'] = participant
    mne_plsc.fit_beh(data=data,
                     design=design,
                     covariates='cov1',
                     between='group',
                     within='cond',
                     participant='ptpt',
                     random_state=123,
                     source_domain='time-freq',
                     source_freqs=freqs)
    mne_plsc.fit_beh(data=data,
                     covariates=design['cov1'],
                     between=design['group'],
                     within=design['cond'],
                     participant=design['ptpt'],
                     random_state=123,
                     source_domain='time-freq',
                     source_freqs=freqs)

def test_mc_args(sample_data):
    # Test different methods of providing data
    data, covariates, between, within, participant, src = sample_data
    freqs = np.linspace(3, 30, 5)
    design = pd.DataFrame(covariates,
                          columns=['cov1', 'cov2'])
    design['group'] = between
    design['cond'] = within
    design['ptpt'] = participant
    mne_plsc.fit_mc(data=data,
                    design=design,
                    between='group',
                    within='cond',
                    participant='ptpt',
                    random_state=123,
                    source_domain='time-freq',
                    source_freqs=freqs)
    mne_plsc.fit_mc(data=data,
                    between=design['group'],
                    within=design['cond'],
                    participant=design['ptpt'],
                    random_state=123,
                    source_domain='time-freq',
                    source_freqs=freqs)

def test_beh_both(sample_data):
    data, covariates, between, within, participant, src = sample_data
    freqs = np.linspace(3, 30, 5)
    result = mne_plsc.fit_beh(data=data,
                              covariates=covariates,
                              between=between,
                              within=within,
                              participant=participant,
                              source_domain='time-freq',
                              source_freqs=freqs)
    run_result_methods(result, src)
    
def test_beh_within(sample_data):
    data, covariates, between, within, participant, src = sample_data
    freqs = np.linspace(3, 30, 5)
    result = mne_plsc.fit_beh(data=data,
                              covariates=covariates,
                              within=within,
                              participant=participant,
                              source_domain='time-freq',
                              source_freqs=freqs)
    run_result_methods(result, src)