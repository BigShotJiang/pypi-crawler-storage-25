from setuptools import setup, find_packages

setup(
    name='npersona',
    version='1.0.1',
    description='AI Security Testing Framework - Comprehensive adversarial testing for AI systems',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='NPersona-AI',
    author_email='npersona.ai@gmail.com',
    url='https://github.com/siddhartth04/NPersona',
    license='MIT',
    packages=find_packages(),
    python_requires='>=3.9',
    install_requires=[
        'click>=8.0',
        'httpx>=0.24.0',
        'litellm>=1.0',
        'pydantic>=2.0',
        'rich>=13.0',
        'tenacity>=8.0',
    ],
    extras_require={
        'dev': [
            'pytest>=7.0',
            'black>=23.0',
            'ruff>=0.1.0',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Security',
        'Topic :: Software Development :: Testing',
    ],
    keywords='ai security testing adversarial testing ai safety',
)
