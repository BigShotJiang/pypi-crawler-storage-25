"""JsonPostAdapter — default shape: {request_field: prompt}."""

from __future__ import annotations

import json
from typing import Any

from npersona.adapters.base import HTTPRequest


class JsonPostAdapter:
    """POST JSON with prompt in a custom field. Default production shape."""

    def __init__(
        self,
        endpoint: str,
        headers: dict[str, str] | None = None,
        request_field: str = "message",
        response_field: str = "response",
    ) -> None:
        self.endpoint = endpoint
        self.headers = {"Content-Type": "application/json", **(headers or {})}
        self.request_field = request_field
        self.response_field = response_field

    async def build_request(self, test_case: Any) -> HTTPRequest:
        """Build {request_field: prompt} POST request."""
        return HTTPRequest(
            method="POST",
            url=self.endpoint,
            headers=self.headers,
            json={self.request_field: test_case.prompt},
            timeout=30.0,
        )

    async def parse_response(self, raw_response: str) -> str:
        """Extract response from {response_field: ...} or return full response."""
        try:
            data = json.loads(raw_response)
            if isinstance(data, dict):
                return data.get(self.response_field, raw_response)
        except (json.JSONDecodeError, AttributeError):
            pass
        return raw_response

    async def on_session_start(self) -> None:
        """No-op for stateless HTTP POST."""
        pass

    async def on_session_end(self) -> None:
        """No-op for stateless HTTP POST."""
        pass

    async def on_request_begin(self, test_case_id: str) -> None:
        """No-op for stateless HTTP POST."""
        pass

    async def on_request_end(self, test_case_id: str, success: bool) -> None:
        """No-op for stateless HTTP POST."""
        pass
