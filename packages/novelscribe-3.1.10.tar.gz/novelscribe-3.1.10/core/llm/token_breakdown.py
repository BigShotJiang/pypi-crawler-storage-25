"""SQL breakdown query helpers for token usage aggregation."""

import sqlite3
from typing import Any, Dict, List


def get_daily_breakdown(
    conn: sqlite3.Connection, where_clause: str, params: List[Any]
) -> List[Dict[str, Any]]:
    """Get daily token/cost aggregation."""
    cursor = conn.cursor()
    cursor.execute(
        f"""
        SELECT
            DATE(timestamp) as date,
            SUM(input_tokens) as input_tokens,
            SUM(output_tokens) as output_tokens,
            SUM(total_tokens) as total_tokens,
            SUM(cost_usd) as cost_usd,
            COUNT(*) as request_count
        FROM llm_requests
        WHERE {where_clause}
        GROUP BY DATE(timestamp)
        ORDER BY date DESC
    """,
        params,
    )
    rows = cursor.fetchall()
    return [
        {
            "date": row[0],
            "input_tokens": row[1],
            "output_tokens": row[2],
            "total_tokens": row[3],
            "cost_usd": round(row[4], 4),
            "request_count": row[5],
        }
        for row in rows
    ]


def get_provider_breakdown(
    conn: sqlite3.Connection, where_clause: str, params: List[Any]
) -> List[Dict[str, Any]]:
    """Get token/cost aggregation by provider."""
    cursor = conn.cursor()
    cursor.execute(
        f"""
        SELECT
            provider,
            SUM(input_tokens) as input_tokens,
            SUM(output_tokens) as output_tokens,
            SUM(total_tokens) as total_tokens,
            SUM(cost_usd) as cost_usd,
            COUNT(*) as request_count
        FROM llm_requests
        WHERE {where_clause}
        GROUP BY provider
        ORDER BY total_tokens DESC
    """,
        params,
    )
    rows = cursor.fetchall()
    return [
        {
            "provider": row[0],
            "input_tokens": row[1],
            "output_tokens": row[2],
            "total_tokens": row[3],
            "cost_usd": round(row[4], 4),
            "request_count": row[5],
        }
        for row in rows
    ]


def get_model_breakdown(
    conn: sqlite3.Connection, where_clause: str, params: List[Any]
) -> List[Dict[str, Any]]:
    """Get token/cost aggregation by model."""
    cursor = conn.cursor()
    cursor.execute(
        f"""
        SELECT
            model,
            SUM(input_tokens) as input_tokens,
            SUM(output_tokens) as output_tokens,
            SUM(total_tokens) as total_tokens,
            SUM(cost_usd) as cost_usd,
            COUNT(*) as request_count
        FROM llm_requests
        WHERE {where_clause}
        GROUP BY model
        ORDER BY total_tokens DESC
    """,
        params,
    )
    rows = cursor.fetchall()
    return [
        {
            "model": row[0],
            "input_tokens": row[1],
            "output_tokens": row[2],
            "total_tokens": row[3],
            "cost_usd": round(row[4], 4),
            "request_count": row[5],
        }
        for row in rows
    ]
