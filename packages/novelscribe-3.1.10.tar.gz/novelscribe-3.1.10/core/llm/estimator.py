"""Token estimation utilities.

Provides approximate token counting for text content.
For production, consider using tiktoken or provider-specific tokenizers.
"""

import re


class TokenEstimator:
    """Estimate token counts for text content.

    Approximation based on word count with adjustments for
    punctuation and dialogue patterns common in prose.
    """

    @staticmethod
    def estimate_tokens(text: str) -> int:
        """Estimate token count for text.

        Uses ~1.3 tokens per word for English prose with adjustments
        for punctuation and dialogue markers.
        """
        if not text:
            return 0

        words = re.findall(r"\b\w+\b", text)
        word_count = len(words)
        punctuation = len(re.findall(r"[.,!?;:]", text))
        dialogue_quotes = len(re.findall(r'"[^"]*"', text))
        estimated_tokens = int(word_count * 1.3) + punctuation + dialogue_quotes

        return max(estimated_tokens, 1)
