"""Token Usage Tracker for NovelScribe.

Provides token usage analytics and aggregation capabilities:
- Real-time token counters
- Per-project aggregation
- Per-day aggregation
- Per-provider breakdown
- Cost calculation
- Top consumers identification
"""

import sqlite3
from typing import Any, Dict, List, Optional

from .token_breakdown import get_daily_breakdown, get_model_breakdown, get_provider_breakdown


class TokenUsageTracker:
    """
    Track and aggregate token usage from logs.

    Provides methods for querying token usage with various filters
    and aggregations.
    """

    def __init__(self, db_logger):
        """
        Initialize token usage tracker.

        Args:
            db_logger: SQLiteLogger instance for database access
        """
        self.db_logger = db_logger

    def get_usage(
        self,
        project: Optional[str] = None,
        period: str = "30d",
        provider: Optional[str] = None,
        model: Optional[str] = None,
        group_by: str = "day",
    ) -> Dict[str, Any]:
        """
        Get token usage with aggregations.

        Args:
            project: Optional project name filter
            period: Time period (e.g., "7d", "30d", "90d", "all")
            provider: Optional provider filter
            model: Optional model filter
            group_by: Grouping (day, week, month, provider, model)

        Returns:
            Dictionary with usage statistics
        """
        if not self.db_logger:
            return {"error": "Database logging not enabled"}

        conn = sqlite3.connect(self.db_logger.db_path)
        cursor = conn.cursor()

        date_filter = self._build_date_filter(period)

        conditions = [date_filter]
        params = []

        if project:
            conditions.append("project_name = ?")
            params.append(project)

        if provider:
            conditions.append("provider = ?")
            params.append(provider)

        if model:
            conditions.append("model = ?")
            params.append(model)

        where_clause = " AND ".join(conditions)

        cursor.execute(
            f"""
            SELECT
                COALESCE(SUM(input_tokens), 0) as total_input,
                COALESCE(SUM(output_tokens), 0) as total_output,
                COALESCE(SUM(total_tokens), 0) as total_tokens,
                COALESCE(SUM(cost_usd), 0) as total_cost,
                COUNT(*) as request_count
            FROM llm_requests
            WHERE {where_clause}
            """,
            params,
        )

        row = cursor.fetchone()

        result = {
            "period": period,
            "project": project,
            "provider": provider,
            "model": model,
            "total_input_tokens": row[0],
            "total_output_tokens": row[1],
            "total_tokens": row[2],
            "total_cost_usd": round(row[3], 4),
            "request_count": row[4],
            "avg_tokens_per_request": round(row[2] / row[4], 2) if row[4] > 0 else 0,
            "avg_cost_per_request": round(row[3] / row[4], 6) if row[4] > 0 else 0,
        }

        if group_by == "day":
            result["daily"] = get_daily_breakdown(conn, where_clause, params)
        elif group_by == "provider":
            result["by_provider"] = get_provider_breakdown(conn, where_clause, params)
        elif group_by == "model":
            result["by_model"] = get_model_breakdown(conn, where_clause, params)

        conn.close()
        return result

    def get_cost_breakdown(
        self, project: Optional[str] = None, period: str = "month"
    ) -> Dict[str, Any]:
        """
        Get cost breakdown by provider and model.

        Args:
            project: Optional project name filter
            period: Time period

        Returns:
            Dictionary with cost breakdown
        """
        if not self.db_logger:
            return {"error": "Database logging not enabled"}

        conn = sqlite3.connect(self.db_logger.db_path)
        cursor = conn.cursor()

        date_filter = self._build_date_filter(period)

        conditions = [date_filter]
        params = []

        if project:
            conditions.append("project_name = ?")
            params.append(project)

        where_clause = " AND ".join(conditions)

        cursor.execute(
            f"""
            SELECT
                provider,
                model,
                SUM(input_tokens) as input_tokens,
                SUM(output_tokens) as output_tokens,
                SUM(total_tokens) as total_tokens,
                SUM(cost_usd) as cost_usd,
                COUNT(*) as request_count
            FROM llm_requests
            WHERE {where_clause}
            GROUP BY provider, model
            ORDER BY cost_usd DESC
        """,
            params,
        )

        rows = cursor.fetchall()

        breakdown = []
        for row in rows:
            breakdown.append(
                {
                    "provider": row[0],
                    "model": row[1],
                    "input_tokens": row[2],
                    "output_tokens": row[3],
                    "total_tokens": row[4],
                    "cost_usd": round(row[5], 4),
                    "request_count": row[6],
                }
            )

        total_cost = sum(item["cost_usd"] for item in breakdown)

        result = {
            "period": period,
            "project": project,
            "total_cost_usd": round(total_cost, 4),
            "breakdown": breakdown,
        }

        for item in breakdown:
            item["cost_percentage"] = (
                round(item["cost_usd"] / total_cost * 100, 2) if total_cost > 0 else 0
            )

        conn.close()
        return result

    def get_top_consumers(
        self, limit: int = 10, period: str = "30d", group_by: str = "agent"
    ) -> List[Dict[str, Any]]:
        """
        Get top token consumers.

        Args:
            limit: Number of top consumers to return
            period: Time period
            group_by: Group by agent, project, or model

        Returns:
            List of top consumers with usage statistics
        """
        if not self.db_logger:
            return []

        conn = sqlite3.connect(self.db_logger.db_path)
        cursor = conn.cursor()

        date_filter = self._build_date_filter(period)

        if group_by == "agent":
            group_col = "agent_name"
        elif group_by == "project":
            group_col = "project_name"
        else:
            group_col = "model"

        cursor.execute(
            f"""
            SELECT
                {group_col} as consumer,
                SUM(total_tokens) as total_tokens,
                SUM(cost_usd) as cost_usd,
                COUNT(*) as request_count,
                AVG(latency_ms) as avg_latency_ms
            FROM llm_requests
            WHERE {date_filter} AND {group_col} IS NOT NULL
            GROUP BY {group_col}
            ORDER BY total_tokens DESC
            LIMIT ?
        """,
            [limit],
        )

        rows = cursor.fetchall()

        consumers = []
        for row in rows:
            consumers.append(
                {
                    "consumer": row[0],
                    "total_tokens": row[1],
                    "cost_usd": round(row[2], 4),
                    "request_count": row[3],
                    "avg_latency_ms": round(row[4], 2) if row[4] else 0,
                }
            )

        conn.close()
        return consumers

    def get_slow_requests(self, threshold_ms: int = 5000, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get slow requests.

        Args:
            threshold_ms: Latency threshold in milliseconds
            limit: Maximum number of requests to return

        Returns:
            List of slow requests
        """
        if not self.db_logger:
            return []

        conn = sqlite3.connect(self.db_logger.db_path)
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                request_id,
                timestamp,
                project_name,
                agent_name,
                provider,
                model,
                total_tokens,
                cost_usd,
                latency_ms,
                status,
                error_message
            FROM llm_requests
            WHERE latency_ms > ?
            ORDER BY latency_ms DESC
            LIMIT ?
        """,
            [threshold_ms, limit],
        )

        rows = cursor.fetchall()

        requests = []
        for row in rows:
            requests.append(
                {
                    "request_id": row[0],
                    "timestamp": row[1],
                    "project": row[2],
                    "agent": row[3],
                    "provider": row[4],
                    "model": row[5],
                    "total_tokens": row[6],
                    "cost_usd": round(row[7], 4),
                    "latency_ms": row[8],
                    "status": row[9],
                    "error": row[10],
                }
            )

        conn.close()
        return requests

    def get_errors(self, project: Optional[str] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """
        Get failed requests.

        Args:
            project: Optional project filter
            limit: Maximum number to return

        Returns:
            List of failed requests
        """
        if not self.db_logger:
            return []

        conn = sqlite3.connect(self.db_logger.db_path)
        cursor = conn.cursor()

        if project:
            cursor.execute(
                """
                SELECT
                    request_id,
                    timestamp,
                    project_name,
                    agent_name,
                    provider,
                    model,
                    error_message,
                    latency_ms
                FROM llm_requests
                WHERE status = 'error' AND project_name = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """,
                [project, limit],
            )
        else:
            cursor.execute(
                """
                SELECT
                    request_id,
                    timestamp,
                    project_name,
                    agent_name,
                    provider,
                    model,
                    error_message,
                    latency_ms
                FROM llm_requests
                WHERE status = 'error'
                ORDER BY timestamp DESC
                LIMIT ?
            """,
                [limit],
            )

        rows = cursor.fetchall()

        errors = []
        for row in rows:
            errors.append(
                {
                    "request_id": row[0],
                    "timestamp": row[1],
                    "project": row[2],
                    "agent": row[3],
                    "provider": row[4],
                    "model": row[5],
                    "error": row[6],
                    "latency_ms": row[7],
                }
            )

        conn.close()
        return errors

    def _build_date_filter(self, period: str) -> str:
        """Build SQL date filter from period string."""
        if period == "all":
            return "1=1"

        if period.endswith("d"):
            days = int(period[:-1])
            return f"timestamp > datetime('now', '-{days} days')"
        elif period.endswith("w"):
            weeks = int(period[:-1])
            return f"timestamp > datetime('now', '-{weeks} weeks')"
        elif period.endswith("m"):
            months = int(period[:-1])
            return f"timestamp > datetime('now', '-{months} months')"
        else:
            return "1=1"

    def _get_daily_breakdown(
        self, conn: sqlite3.Connection, where_clause: str, params: List[Any]
    ) -> List[Dict[str, Any]]:
        """Get daily breakdown."""
        return get_daily_breakdown(conn, where_clause, params)

    def _get_provider_breakdown(
        self, conn: sqlite3.Connection, where_clause: str, params: List[Any]
    ) -> List[Dict[str, Any]]:
        """Get breakdown by provider."""
        return get_provider_breakdown(conn, where_clause, params)

    def _get_model_breakdown(
        self, conn: sqlite3.Connection, where_clause: str, params: List[Any]
    ) -> List[Dict[str, Any]]:
        """Get breakdown by model."""
        return get_model_breakdown(conn, where_clause, params)
