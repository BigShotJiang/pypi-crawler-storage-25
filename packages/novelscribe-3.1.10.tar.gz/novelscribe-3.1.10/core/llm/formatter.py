"""Language-aware message formatting for consistent runtime/CLI output."""

from typing import Dict, Optional

from core.i18n import LanguageCode, LanguageResolver

_MESSAGES: Dict[str, Dict[str, str]] = {
    "checkpoint_proposed": {
        "en": "Checkpoint proposed: {phase} - {description}",
        "zh-CN": "检查点提议：{phase} - {description}",
        "zh-TW": "檢查點提議：{phase} - {description}",
    },
    "checkpoint_approved": {
        "en": "Checkpoint approved: {phase}",
        "zh-CN": "检查点已批准：{phase}",
        "zh-TW": "檢查點已批准：{phase}",
    },
    "checkpoint_timeout": {
        "en": "Checkpoint timed out after {timeout}s: {phase}",
        "zh-CN": "检查点超时（{timeout}秒）：{phase}",
        "zh-TW": "檢查點超時（{timeout}秒）：{phase}",
    },
    "step_executing": {
        "en": "Executing step {step}: {name}",
        "zh-CN": "正在执行步骤 {step}：{name}",
        "zh-TW": "正在執行步驟 {step}：{name}",
    },
    "step_failed": {
        "en": "Step failed: {name} - {error}",
        "zh-CN": "步骤失败：{name} - {error}",
        "zh-TW": "步驟失敗：{name} - {error}",
    },
    "step_skipped": {
        "en": "Skipping step {step} ({name}): condition not met",
        "zh-CN": "跳过步骤 {step}（{name}）：条件未满足",
        "zh-TW": "跳過步驟 {step}（{name}）：條件未滿足",
    },
    "workflow_started": {
        "en": "Executing workflow: {name}",
        "zh-CN": "正在执行工作流：{name}",
        "zh-TW": "正在執行工作流：{name}",
    },
    "workflow_success": {
        "en": "Workflow completed successfully: {name}",
        "zh-CN": "工作流完成：{name}",
        "zh-TW": "工作流完成：{name}",
    },
    "workflow_failed": {
        "en": "Workflow failed: {name} - {error}",
        "zh-CN": "工作流失败：{name} - {error}",
        "zh-TW": "工作流失敗：{name} - {error}",
    },
    "workflow_timed_out": {
        "en": "Workflow {name} timed out after {timeout}s",
        "zh-CN": "工作流 {name} 超时（{timeout}秒）",
        "zh-TW": "工作流 {name} 超時（{timeout}秒）",
    },
    "runtime_gate_failed": {
        "en": "Runtime entry gate failed for workflow {name}",
        "zh-CN": "工作流 {name} 运行时入口检查失败",
        "zh-TW": "工作流 {name} 執行時入口檢查失敗",
    },
    "runtime_gate_compat": {
        "en": "Runtime entry gate failed for workflow {name}; continuing via compatibility layer",
        "zh-CN": "工作流 {name} 运行时入口检查失败；通过兼容层继续",
        "zh-TW": "工作流 {name} 執行時入口檢查失敗；通過相容層繼續",
    },
    "verification_passed": {
        "en": "Verification passed for {name}",
        "zh-CN": "验证通过：{name}",
        "zh-TW": "驗證通過：{name}",
    },
    "verification_failed": {
        "en": "Verification failed for {name}: {error}",
        "zh-CN": "验证失败：{name} - {error}",
        "zh-TW": "驗證失敗：{name} - {error}",
    },
    "error_generic": {
        "en": "Error: {error}",
        "zh-CN": "错误：{error}",
        "zh-TW": "錯誤：{error}",
    },
}


class MessageFormatter:
    """Format user-facing messages in the configured language.

    Uses the ``LanguageResolver`` priority chain to determine the
    effective language.  Falls back to English when no translation
    exists for a given key.
    """

    def __init__(
        self,
        language: Optional[LanguageCode] = None,
        resolver: Optional[LanguageResolver] = None,
    ) -> None:
        if resolver is not None:
            self._language = language or resolver.resolve()
        else:
            self._language = language or LanguageCode.EN

    @property
    def language(self) -> LanguageCode:
        return self._language

    def format(self, key: str, **kwargs: object) -> str:
        """Format a message by key using the configured language.

        Falls back to English if the key or language is missing.
        Falls back to the key itself if no entry exists at all.
        """
        entry = _MESSAGES.get(key)
        if entry is None:
            return key
        template = entry.get(str(self._language))
        if template is None:
            template = entry.get("en", key)
        return template.format(**{k: str(v) for k, v in kwargs.items()})

    @staticmethod
    def available_keys() -> list[str]:
        return sorted(_MESSAGES.keys())

    @staticmethod
    def available_languages(key: str) -> list[str]:
        entry = _MESSAGES.get(key, {})
        return sorted(entry.keys())
