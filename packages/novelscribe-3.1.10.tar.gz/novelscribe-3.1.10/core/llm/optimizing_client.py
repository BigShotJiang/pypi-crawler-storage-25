"""LLM client wrapper with caching via LLMOptimizer."""

from typing import Optional

from .client import LLMResponse
from .optimizer import CachePolicy, LLMOptimizer, get_llm_optimizer


class OptimizingLLMClient:
    """Wraps an LLMClient with response caching via LLMOptimizer.

    Provides the same generate()/generate_with_history() interface as LLMClient.
    On cache hits, returns the previously cached response without calling the
    underlying client. Cache policy is determined per-call from agent frontmatter.
    """

    def __init__(
        self,
        client: object,
        optimizer: Optional[LLMOptimizer] = None,
    ):
        self.client = client
        self._optimizer = optimizer or get_llm_optimizer()

    def _resolve_cache_policy(self, policy_str: Optional[str]) -> CachePolicy:
        policy_map = {
            "none": CachePolicy.NONE,
            "no_cache": CachePolicy.NO_CACHE,
            "lru": CachePolicy.LRU,
            "ttl": CachePolicy.TTL,
            "short": CachePolicy.SHORT,
            "static": CachePolicy.STATIC,
        }
        if policy_str is None:
            return CachePolicy.NO_CACHE
        return policy_map.get(policy_str.lower(), CachePolicy.NO_CACHE)

    def generate(
        self,
        system_prompt: str,
        user_prompt: str,
        cache_policy: Optional[str] = None,
    ) -> LLMResponse:
        policy = self._resolve_cache_policy(cache_policy)

        if policy in (CachePolicy.NONE, CachePolicy.NO_CACHE):
            return self.client.generate(system_prompt, user_prompt)

        combined_prompt = f"SYSTEM:\n{system_prompt}\n\nUSER:\n{user_prompt}"
        model = getattr(self.client, "model", "default")
        cache_key = self._optimizer._hash_prompt(combined_prompt, model)

        cached_entry = self._optimizer._get_cached_response(cache_key)
        if cached_entry is not None:
            response_content = str(
                cached_entry.value if hasattr(cached_entry, "value") else cached_entry
            )
            return LLMResponse(
                content=response_content,
                model=model if isinstance(model, str) else "unknown",
                provider=getattr(self.client, "provider", "unknown"),
                tokens_used=None,
                finish_reason="stop",
            )

        response = self.client.generate(system_prompt, user_prompt)

        self._optimizer._add_to_cache(cache_key, response.content, model, policy)

        return response

    def generate_with_history(
        self,
        messages: list[dict[str, str]],
        cache_policy: Optional[str] = None,
    ) -> LLMResponse:
        policy = self._resolve_cache_policy(cache_policy)

        if policy not in (CachePolicy.STATIC,):
            return self.client.generate_with_history(messages)

        combined = "\n".join(f"{m.get('role', '')}: {m.get('content', '')}" for m in messages)
        model = getattr(self.client, "model", "default")
        cache_key = self._optimizer._hash_prompt(combined, model)

        cached_entry = self._optimizer._get_cached_response(cache_key)
        if cached_entry is not None:
            response_content = str(
                cached_entry.value if hasattr(cached_entry, "value") else cached_entry
            )
            return LLMResponse(
                content=response_content,
                model=model if isinstance(model, str) else "unknown",
                provider=getattr(self.client, "provider", "unknown"),
                tokens_used=None,
                finish_reason="stop",
            )

        response = self.client.generate_with_history(messages)
        self._optimizer._add_to_cache(cache_key, response.content, model, policy)
        return response

    def reset_circuits(self) -> None:
        if hasattr(self.client, "reset_circuits") and callable(self.client.reset_circuits):
            self.client.reset_circuits()

    def get_cache_stats(self) -> dict:
        stats = self._optimizer.get_statistics()
        return {
            "total_calls": stats.total_calls,
            "cache_hits": stats.cache_hits,
            "cache_misses": stats.cache_misses,
            "tokens_saved": stats.tokens_saved,
            "cost_saved": stats.cost_saved,
        }
