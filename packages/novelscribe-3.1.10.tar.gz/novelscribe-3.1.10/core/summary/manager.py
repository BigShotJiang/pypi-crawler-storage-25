"""
Summary Manager Implementation for Phase 4.2

Manages hierarchical summary generation and retrieval using LLM-based
summarization with intelligent context assembly.
"""

import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

from core.llm.client import LLMClient

from .store import (
    ChapterSummary,
    GlobalSummary,
    GroupSummary,
    SummaryStore,
    SummaryStoreConfig,
)

logger = logging.getLogger(__name__)


class SummaryManagerConfig(BaseModel):
    """Configuration for summary manager."""

    chapter_group_size: int = 5
    max_summary_length: int = 300
    min_summary_length: int = 200
    max_context_chapters: int = 3
    global_summary_max_length: int = 3000
    enable_auto_grouping: bool = True
    enable_auto_global_update: bool = True


class SummaryManager:
    """
    Manager for hierarchical summary generation and retrieval.

    Features:
    - LLM-based chapter summary generation
    - Automatic group summary creation
    - Incremental global summary updates
    - Context assembly for chapter generation
    - Character arc tracking
    """

    def __init__(
        self,
        project_root: Path,
        llm_client: LLMClient,
        config: Optional[SummaryManagerConfig] = None,
    ):
        """
        Initialize summary manager.

        Args:
            project_root: Path to project directory
            llm_client: LLM client for summary generation
            config: Manager configuration
        """
        self.project_root = Path(project_root)
        self.llm_client = llm_client
        self.config = config or SummaryManagerConfig()

        self.store = SummaryStore(self.project_root, SummaryStoreConfig())

    def generate_chapter_summary(
        self,
        chapter_number: int,
        content: str,
        previous_summary: Optional[str] = None,
        novel_context: Optional[str] = None,
    ) -> ChapterSummary:
        """
        Generate summary for a single chapter.

        Args:
            chapter_number: Chapter number
            content: Chapter content
            previous_summary: Previous chapter summary for context
            novel_context: Optional global novel context

        Returns:
            Generated chapter summary
        """
        prompt = self._build_chapter_summary_prompt(
            chapter_number, content, previous_summary, novel_context
        )

        response = self.llm_client.generate(system_prompt="", user_prompt=prompt)

        summary_data = self._parse_summary_response(response.content)
        summary_data["chapter_number"] = chapter_number
        summary_data["created_at"] = datetime.now(timezone.utc)
        summary_data["word_count"] = len(content.split())

        chapter_summary = ChapterSummary(**summary_data)
        self.store.save_chapter_summary(chapter_summary)

        if self.config.enable_auto_grouping:
            self._check_and_create_group_summary(chapter_number)

        if self.config.enable_auto_global_update:
            self._update_global_summary_if_needed([chapter_number])

        return chapter_summary

    def _build_chapter_summary_prompt(
        self,
        chapter_number: int,
        content: str,
        previous_summary: Optional[str],
        novel_context: Optional[str],
    ) -> str:
        """Build prompt for chapter summary generation."""
        prompt_parts = [f"Generate a comprehensive summary for Chapter {chapter_number}.", ""]

        if novel_context:
            prompt_parts.extend(["## Novel Context", novel_context, ""])

        if previous_summary:
            prompt_parts.extend(["## Previous Chapter Summary", previous_summary, ""])

        prompt_parts.extend(["## Chapter Content", content[:8000], ""])  # Limit content length

        return "\n".join(prompt_parts)

    def _parse_summary_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM response into summary components."""
        import yaml

        try:
            data = yaml.safe_load(response)
            if isinstance(data, dict):
                return {
                    "summary": data.get("summary", ""),
                    "key_events": data.get("key_events", []),
                    "characters": {k: v for k, v in data.get("characters", {}).items()},
                    "locations": {k: v for k, v in data.get("locations", {}).items()},
                    "plot_advancement": data.get("plot_advancement", ""),
                    "next_chapter_setup": data.get("next_chapter_setup", ""),
                }
        except Exception:
            logger.debug("Failed to parse summary response as YAML")

        return {
            "summary": response,
            "key_events": [],
            "characters": {},
            "locations": {},
            "plot_advancement": "",
            "next_chapter_setup": "",
        }

    def generate_group_summary(self, start_chapter: int, end_chapter: int) -> GroupSummary:
        """
        Generate summary for a group of chapters.

        Args:
            start_chapter: First chapter in group
            end_chapter: Last chapter in group

        Returns:
            Generated group summary
        """
        chapter_summaries = []
        for i in range(start_chapter, end_chapter + 1):
            summary = self.store.load_chapter_summary(i)
            if summary:
                chapter_summaries.append(summary)

        if not chapter_summaries:
            raise ValueError(f"No summaries found for chapters {start_chapter}-{end_chapter}")

        prompt = self._build_group_summary_prompt(chapter_summaries)

        response = self.llm_client.generate(system_prompt="", user_prompt=prompt)

        group_data = self._parse_group_response(response.content)
        group_data["group_id"] = f"chapters_{start_chapter}_{end_chapter}"
        group_data["start_chapter"] = start_chapter
        group_data["end_chapter"] = end_chapter
        group_data["created_at"] = datetime.now(timezone.utc)
        group_data["total_word_count"] = sum(s.word_count for s in chapter_summaries)

        group_summary = GroupSummary(**group_data)
        self.store.save_group_summary(group_summary)

        return group_summary

    def _build_group_summary_prompt(self, summaries: List[ChapterSummary]) -> str:
        """Build prompt for group summary generation."""
        prompt_parts = [
            "Generate a comprehensive group summary that synthesizes these chapter summaries:",
            "",
        ]

        for summary in summaries:
            prompt_parts.extend([f"## Chapter {summary.chapter_number}", summary.summary, ""])

        prompt_parts.extend(
            [
                "Create a 500-700 word summary that:",
                "- Synthesizes the narrative arc across these chapters",
                "- Identifies key plot developments",
                "- Tracks character evolution",
                "- Notes recurring themes",
                "",
            ]
        )

        return "\n".join(prompt_parts)

    def _parse_group_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM response for group summary."""
        return {
            "summary": response,
            "combined_events": [],
            "character_arcs": {},
            "plot_developments": [],
        }

    def update_global_summary(self, new_chapters: List[int]) -> GlobalSummary:
        """
        Update global summary with new chapters.

        Args:
            new_chapters: List of new chapter numbers

        Returns:
            Updated global summary
        """
        current_global = self.store.load_global_summary()

        new_summaries = []
        for chapter_num in new_chapters:
            summary = self.store.load_chapter_summary(chapter_num)
            if summary:
                new_summaries.append(summary)

        if not new_summaries:
            raise ValueError("No valid chapter summaries found")

        prompt = self._build_global_update_prompt(current_global, new_summaries)

        response = self.llm_client.generate(system_prompt="", user_prompt=prompt)

        global_data = self._parse_global_response(response.content)
        global_data["project_name"] = self.project_root.name
        global_data["last_updated"] = datetime.now(timezone.utc)

        if current_global:
            global_data["total_chapters_covered"] = current_global.total_chapters_covered + len(
                new_chapters
            )
            global_data["total_word_count"] = current_global.total_word_count + sum(
                s.word_count for s in new_summaries
            )
        else:
            global_data["total_chapters_covered"] = len(new_summaries)
            global_data["total_word_count"] = sum(s.word_count for s in new_summaries)

        global_summary = GlobalSummary(**global_data)
        self.store.save_global_summary(global_summary)

        return global_summary

    def _build_global_update_prompt(
        self, current_global: Optional[GlobalSummary], new_summaries: List[ChapterSummary]
    ) -> str:
        """Build prompt for global summary update."""
        prompt_parts = ["Update the global novel summary with new chapters:", ""]

        if current_global:
            prompt_parts.extend(
                [
                    "## Current Global Summary",
                    current_global.summary,
                    f"\n**Main Plot Arc**: {current_global.main_plot_arc}",
                    "",
                ]
            )

        prompt_parts.extend(["## New Chapter Summaries", ""])

        for summary in new_summaries:
            prompt_parts.extend([f"### Chapter {summary.chapter_number}", summary.summary, ""])

        prompt_parts.extend(
            [
                "Create an updated global summary that:",
                "- Integrates new chapters seamlessly",
                "- Maintains narrative coherence",
                "- Updates character arcs",
                "- Identifies emerging themes",
                "- Tracks plot progression",
                "",
            ]
        )

        return "\n".join(prompt_parts)

    def _parse_global_response(self, response: str) -> Dict[str, Any]:
        """Parse LLM response for global summary."""
        return {
            "summary": response,
            "main_plot_arc": "",
            "character_arcs": {},
            "world_development": "",
            "themes": [],
        }

    def get_chapter_summary(self, chapter_number: int) -> Optional[ChapterSummary]:
        """
        Get chapter summary.

        Args:
            chapter_number: Chapter number

        Returns:
            Chapter summary or None
        """
        return self.store.load_chapter_summary(chapter_number)

    def get_group_summary(self, group_id: str) -> Optional[GroupSummary]:
        """
        Get group summary.

        Args:
            group_id: Group ID

        Returns:
            Group summary or None
        """
        return self.store.load_group_summary(group_id)

    def get_global_summary(self) -> Optional[GlobalSummary]:
        """
        Get global summary.

        Returns:
            Global summary or None
        """
        return self.store.load_global_summary()

    def get_context_for_chapter(self, chapter_number: int, context_length: int = 3) -> str:
        """
        Get summarized context for chapter generation.

        Args:
            chapter_number: Chapter to generate context for
            context_length: Number of previous chapters to include

        Returns:
            Context string for chapter generation
        """
        context_parts = []

        global_summary = self.get_global_summary()
        if global_summary:
            context_parts.extend(["## Overall Story Context", global_summary.summary, ""])

        start_chapter = max(1, chapter_number - context_length)
        previous_summaries = []

        for i in range(start_chapter, chapter_number):
            summary = self.get_chapter_summary(i)
            if summary:
                previous_summaries.append(summary)

        if previous_summaries:
            context_parts.append("## Recent Chapter Summaries")
            for summary in previous_summaries:
                context_parts.extend(
                    [f"**Chapter {summary.chapter_number}**: {summary.summary}", ""]
                )

        return "\n".join(context_parts)

    def _check_and_create_group_summary(self, chapter_number: int):
        """Check if group summary should be created."""
        if chapter_number % self.config.chapter_group_size == 0:
            start_chapter = chapter_number - self.config.chapter_group_size + 1
            end_chapter = chapter_number

            group_id = f"chapters_{start_chapter}_{end_chapter}"
            existing = self.store.load_group_summary(group_id)

            if not existing:
                try:
                    self.generate_group_summary(start_chapter, end_chapter)
                except Exception:
                    logger.debug(
                        "Failed to generate group summary for chapters %d-%d",
                        start_chapter,
                        end_chapter,
                    )

    def _update_global_summary_if_needed(self, new_chapters: List[int]):
        """Update global summary if needed."""
        try:
            self.update_global_summary(new_chapters)
        except Exception:
            pass

    def get_summary_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about summaries.

        Returns:
            Summary statistics
        """
        return self.store.get_summary_statistics()

    def list_missing_summaries(self, max_chapter: int) -> List[int]:
        """
        List chapters missing summaries.

        Args:
            max_chapter: Highest chapter number to check

        Returns:
            List of chapter numbers missing summaries
        """
        existing = set(self.store.list_chapter_summaries())
        missing = []

        for i in range(1, max_chapter + 1):
            if i not in existing:
                missing.append(i)

        return missing

    def batch_generate_summaries(
        self, chapter_files: Dict[int, str], skip_existing: bool = True
    ) -> List[ChapterSummary]:
        """
        Generate summaries for multiple chapters.

        Args:
            chapter_files: Map of chapter number to file content
            skip_existing: Skip chapters that already have summaries

        Returns:
            List of generated summaries
        """
        summaries = []

        for chapter_num in sorted(chapter_files.keys()):
            if skip_existing:
                existing = self.store.load_chapter_summary(chapter_num)
                if existing:
                    continue

            try:
                content = chapter_files[chapter_num]
                previous_summary = None

                if chapter_num > 1:
                    prev = self.store.load_chapter_summary(chapter_num - 1)
                    if prev:
                        previous_summary = prev.summary

                summary = self.generate_chapter_summary(chapter_num, content, previous_summary)

                summaries.append(summary)

            except Exception as e:
                print(f"Failed to generate summary for chapter {chapter_num}: {e}")

        return summaries
