"""Artifact manager with versioning and retention policies."""

import json
import logging
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ArtifactRecord:
    """Metadata for a single artifact version."""

    __slots__ = ("name", "version", "path", "registered_at", "artifact_type")

    def __init__(
        self,
        name: str,
        version: int,
        path: str,
        artifact_type: str = "",
        registered_at: Optional[float] = None,
    ) -> None:
        self.name = name
        self.version = version
        self.path = path
        self.artifact_type = artifact_type
        self.registered_at = registered_at or time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "path": self.path,
            "artifact_type": self.artifact_type,
            "registered_at": self.registered_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ArtifactRecord":
        return cls(
            name=data["name"],
            version=data["version"],
            path=data["path"],
            artifact_type=data.get("artifact_type", ""),
            registered_at=data.get("registered_at"),
        )


class ArtifactManager:
    """Manage versioned artifacts with retention-based cleanup.

    Artifacts are tracked in a ``.artifacts/manifest.json`` file.
    Each artifact has a name, version counter, type, and file path.
    Retention policies limit the number of versions kept per artifact.
    """

    DEFAULT_RETENTION = 10

    def __init__(
        self,
        base_dir: str | Path,
        retention: int = DEFAULT_RETENTION,
    ) -> None:
        self._dir = Path(base_dir)
        self._retention = max(1, retention)
        self._manifest_path = self._dir / "manifest.json"
        self._records: Dict[str, List[ArtifactRecord]] = {}
        self._loaded = False

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return
        self._records.clear()
        if self._manifest_path.is_file():
            try:
                data = json.loads(self._manifest_path.read_text(encoding="utf-8"))
                for name, versions in data.items():
                    self._records[name] = [ArtifactRecord.from_dict(v) for v in versions]
            except Exception as exc:
                logger.warning("Failed to load artifact manifest: %s", exc)
        self._loaded = True

    def _save(self) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        data = {}
        for name, records in self._records.items():
            data[name] = [r.to_dict() for r in records]
        self._manifest_path.write_text(
            json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    def register(
        self,
        name: str,
        path: str | Path,
        artifact_type: str = "",
    ) -> ArtifactRecord:
        """Register a new artifact version."""
        self._ensure_loaded()
        versions = self._records.setdefault(name, [])
        next_version = (versions[-1].version + 1) if versions else 1
        record = ArtifactRecord(
            name=name,
            version=next_version,
            path=str(path),
            artifact_type=artifact_type,
        )
        versions.append(record)
        self._save()
        return record

    def get_versions(self, name: str) -> List[ArtifactRecord]:
        """Return all versions of an artifact."""
        self._ensure_loaded()
        return list(self._records.get(name, []))

    def get_latest(self, name: str) -> Optional[ArtifactRecord]:
        """Return the latest version of an artifact."""
        self._ensure_loaded()
        versions = self._records.get(name)
        if not versions:
            return None
        return versions[-1]

    def prune(self, name: Optional[str] = None) -> int:
        """Prune old versions exceeding retention policy.

        Args:
            name: Prune a specific artifact, or None to prune all.

        Returns:
            Number of pruned versions.
        """
        self._ensure_loaded()
        pruned = 0
        names = [name] if name else list(self._records.keys())
        for artifact_name in names:
            versions = self._records.get(artifact_name, [])
            if len(versions) <= self._retention:
                continue
            to_remove = versions[: len(versions) - self._retention]
            for record in to_remove:
                fp = Path(record.path)
                if fp.is_file():
                    try:
                        fp.unlink()
                    except OSError:
                        pass
            self._records[artifact_name] = versions[len(versions) - self._retention :]
            pruned += len(to_remove)
        if pruned:
            self._save()
        return pruned

    def list_artifacts(self) -> Dict[str, int]:
        """Return artifact names with their version counts."""
        self._ensure_loaded()
        return {name: len(vers) for name, vers in self._records.items()}
