"""Internationalization subsystem — language configuration and resolution."""

from .config import (
    LanguageCode,
    LanguageConfig,
    LanguageResolver,
    get_current_language,
    is_supported_language,
)

__all__ = [
    "LanguageCode",
    "LanguageConfig",
    "LanguageResolver",
    "get_current_language",
    "is_supported_language",
]
