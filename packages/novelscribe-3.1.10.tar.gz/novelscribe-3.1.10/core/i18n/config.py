"""Language configuration and resolution for multi-language support."""

import logging
import os
from enum import Enum
from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class LanguageCode(str, Enum):
    """Supported language codes."""

    EN = "en"
    ZH_CN = "zh-CN"
    ZH_TW = "zh-TW"

    def __str__(self) -> str:
        return self.value


class LanguageConfig(BaseModel):
    """Language configuration settings."""

    default_language: LanguageCode = Field(
        default=LanguageCode.EN, description="Default language for new projects"
    )
    current_language: Optional[LanguageCode] = Field(
        default=None, description="Current active language (overrides default)"
    )

    def get_effective_language(self) -> LanguageCode:
        """Get the effective language to use.

        Returns current_language if set, otherwise default_language.
        """
        return self.current_language or self.default_language


class LanguageResolver:
    """Resolve language based on priority chain.

    Priority order (highest to lowest):
    1. Explicit language parameter
    2. Project META.yaml configuration
    3. User configuration file (~/.scribe/config.yaml)
    4. Environment variable (SCRIBE_LANGUAGE)
    5. System locale detection
    6. Fallback to English (en)
    """

    DEFAULT_CONFIG_PATH = Path.home() / ".scribe" / "config.yaml"
    ENV_LANGUAGE = "SCRIBE_LANGUAGE"

    def __init__(
        self,
        config_path: Optional[Path] = None,
        project_dir: Optional[Path] = None,
    ):
        """Initialize language resolver.

        Args:
            config_path: Path to user config file (default: ~/.scribe/config.yaml)
            project_dir: Path to current project directory (for META.yaml reading)
        """
        self.config_path = config_path or self.DEFAULT_CONFIG_PATH
        self.project_dir = project_dir
        self._cached_config: Optional[LanguageConfig] = None

    def resolve_language(
        self,
        explicit_language: Optional[LanguageCode] = None,
    ) -> LanguageCode:
        """Resolve language using priority chain.

        Args:
            explicit_language: Explicitly specified language (highest priority)

        Returns:
            Resolved LanguageCode
        """
        if explicit_language:
            return explicit_language

        if self.project_dir:
            project_language = self._read_project_language()
            if project_language:
                return project_language

        user_language = self._read_user_config_language()
        if user_language:
            return user_language

        env_language = self._read_environment_language()
        if env_language:
            return env_language

        locale_language = self._detect_system_locale()
        if locale_language:
            return locale_language

        return LanguageCode.EN

    def _read_project_language(self) -> Optional[LanguageCode]:
        """Read language from project's META.yaml.

        Returns:
            LanguageCode if found and valid, None otherwise
        """
        if not self.project_dir:
            return None

        meta_path = self.project_dir / "META.yaml"
        if not meta_path.exists():
            return None

        try:
            with open(meta_path, encoding="utf-8") as f:
                meta_data = yaml.safe_load(f)

            if isinstance(meta_data, dict):
                language_str = meta_data.get("language")
                if language_str:
                    return LanguageCode(language_str)
        except (yaml.YAMLError, ValueError, IOError):
            logger.debug("Failed to read language from project META.yaml: %s", meta_path)

        return None

    def _read_user_config_language(self) -> Optional[LanguageCode]:
        """Read language from user config file.

        Returns:
            LanguageCode if found and valid, None otherwise
        """
        if not self.config_path.exists():
            return None

        try:
            with open(self.config_path, encoding="utf-8") as f:
                config_data = yaml.safe_load(f)

            if isinstance(config_data, dict):
                language_str = config_data.get("default_language")
                if language_str:
                    return LanguageCode(language_str)
        except (yaml.YAMLError, ValueError, IOError):
            logger.debug("Failed to read language from user config: %s", self.config_path)

        return None

    def _read_environment_language(self) -> Optional[LanguageCode]:
        """Read language from environment variable.

        Returns:
            LanguageCode if found and valid, None otherwise
        """
        import os

        language_str = os.environ.get(self.ENV_LANGUAGE)
        if language_str:
            try:
                return LanguageCode(language_str)
            except ValueError:
                logger.debug(
                    "Invalid language code in env var %s: %s",
                    self.ENV_LANGUAGE,
                    language_str,
                )

        return None

    def _detect_system_locale(self) -> Optional[LanguageCode]:
        """Detect language from system locale.

        Returns:
            LanguageCode if detected and supported, None otherwise
        """
        try:
            lang = os.environ.get("LANG") or os.environ.get("LC_ALL") or ""
            if not lang:
                return None

            lang = lang.split(".")[0].lower()

            if lang.startswith("zh_cn"):
                return LanguageCode.ZH_CN
            elif lang.startswith("zh_tw"):
                return LanguageCode.ZH_TW
            elif lang.startswith("en"):
                return LanguageCode.EN
        except (ValueError, AttributeError):
            logger.debug("Failed to detect system locale for language resolution")

        return None

    def get_config(self) -> LanguageConfig:
        """Get or create user language configuration.

        Returns:
            LanguageConfig instance
        """
        if self._cached_config:
            return self._cached_config

        if self.config_path.exists():
            try:
                with open(self.config_path, encoding="utf-8") as f:
                    config_data = yaml.safe_load(f) or {}
                self._cached_config = LanguageConfig(**config_data)
            except (yaml.YAMLError, ValueError, IOError):
                self._cached_config = LanguageConfig()
        else:
            self._cached_config = LanguageConfig()

        return self._cached_config

    def save_config(self, config: LanguageConfig) -> None:
        """Save user language configuration to file.

        Args:
            config: LanguageConfig to save
        """
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

        with open(self.config_path, "w", encoding="utf-8") as f:
            yaml.dump(
                config.model_dump(mode="json", exclude_none=True),
                f,
                default_flow_style=False,
                allow_unicode=True,
            )

        self._cached_config = config


def get_current_language(
    explicit_language: Optional[LanguageCode] = None,
    project_dir: Optional[Path] = None,
    config_path: Optional[Path] = None,
) -> LanguageCode:
    """Convenience function to resolve current language.

    Args:
        explicit_language: Explicitly specified language
        project_dir: Project directory path
        config_path: User config file path

    Returns:
        Resolved LanguageCode
    """
    resolver = LanguageResolver(
        config_path=config_path,
        project_dir=project_dir,
    )
    return resolver.resolve_language(explicit_language=explicit_language)


def is_supported_language(language_code: str) -> bool:
    """Check if a language code is supported.

    Args:
        language_code: Language code string to check

    Returns:
        True if supported, False otherwise
    """
    try:
        LanguageCode(language_code)
        return True
    except ValueError:
        return False
