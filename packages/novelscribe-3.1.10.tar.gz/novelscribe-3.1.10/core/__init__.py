"""Novel Harness Core Components."""

from core._version import __version__  # noqa: F401 — single source of truth
