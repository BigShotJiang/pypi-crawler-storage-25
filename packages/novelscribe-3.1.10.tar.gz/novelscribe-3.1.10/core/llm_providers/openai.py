"""OpenAI provider client."""

from __future__ import annotations

import os
from collections.abc import AsyncIterator, Iterator

from core.llm.client import LLMClient, LLMConfig, LLMError, LLMResponse


class OpenAIClient(LLMClient):
    """OpenAI provider client."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import openai

            self.openai = openai
            api_key = config.api_key or os.getenv("OPENAI_API_KEY", "")
            base_url = config.base_url or os.getenv("OPENAI_API_BASE", "")

            client_kwargs = {"api_key": api_key, "timeout": config.timeout}
            if base_url:
                client_kwargs["base_url"] = base_url

            self.client = openai.OpenAI(**client_kwargs)
            self.async_client = openai.AsyncOpenAI(**client_kwargs)
        except ImportError:
            raise LLMError("OpenAI package not installed. Install with: pip install openai")

    def validate_config(self) -> bool:
        """Validate OpenAI configuration."""
        return bool(self.config.api_key or os.getenv("OPENAI_API_KEY"))

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response using OpenAI API."""
        if not self.validate_config():
            raise LLMError("OpenAI API key not configured")

        messages = self._format_messages(system_prompt, user_prompt)

        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            return LLMResponse(
                content=response.choices[0].message.content,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.total_tokens if response.usage else None,
                finish_reason=response.choices[0].finish_reason,
            )
        except Exception as e:
            raise LLMError(f"OpenAI API error: {e}") from e

    async def generate_async(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Async generate response using OpenAI API."""
        if not self.validate_config():
            raise LLMError("OpenAI API key not configured")

        messages = self._format_messages(system_prompt, user_prompt)

        try:
            response = await self.async_client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            return LLMResponse(
                content=response.choices[0].message.content,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.total_tokens if response.usage else None,
                finish_reason=response.choices[0].finish_reason,
            )
        except Exception as e:
            raise LLMError(f"OpenAI API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response using conversation history."""
        if not self.validate_config():
            raise LLMError("OpenAI API key not configured")

        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            return LLMResponse(
                content=response.choices[0].message.content,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.total_tokens if response.usage else None,
                finish_reason=response.choices[0].finish_reason,
            )
        except Exception as e:
            raise LLMError(f"OpenAI API error: {e}") from e

    async def generate_with_history_async(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Async generate response using conversation history."""
        if not self.validate_config():
            raise LLMError("OpenAI API key not configured")

        try:
            response = await self.async_client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            return LLMResponse(
                content=response.choices[0].message.content,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.total_tokens if response.usage else None,
                finish_reason=response.choices[0].finish_reason,
            )
        except Exception as e:
            raise LLMError(f"OpenAI API error: {e}") from e

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        """Stream response using OpenAI API."""
        if not self.validate_config():
            raise LLMError("OpenAI API key not configured")

        messages = self._format_messages(system_prompt, user_prompt)
        try:
            stream = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                stream=True,
            )
            for chunk in stream:
                delta = chunk.choices[0].delta.content if chunk.choices else None
                if delta:
                    yield delta
        except Exception as e:
            raise LLMError(f"OpenAI streaming error: {e}") from e

    async def generate_stream_async(
        self, system_prompt: str, user_prompt: str
    ) -> AsyncIterator[str]:
        """Async stream response using OpenAI API."""
        if not self.validate_config():
            raise LLMError("OpenAI API key not configured")

        messages = self._format_messages(system_prompt, user_prompt)
        try:
            stream = await self.async_client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                stream=True,
            )
            async for chunk in stream:
                delta = chunk.choices[0].delta.content if chunk.choices else None
                if delta:
                    yield delta
        except Exception as e:
            raise LLMError(f"OpenAI streaming error: {e}") from e
