"""Anthropic Claude provider client."""

from __future__ import annotations

import os
from collections.abc import AsyncIterator, Iterator

from core.llm.client import LLMClient, LLMConfig, LLMError, LLMResponse


class ClaudeClient(LLMClient):
    """Anthropic Claude provider client."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import anthropic

            self.client = anthropic.Anthropic(api_key=config.api_key, timeout=config.timeout)
            self.async_client = anthropic.AsyncAnthropic(
                api_key=config.api_key, timeout=config.timeout
            )
        except ImportError:
            raise LLMError("Anthropic package not installed. Install with: pip install anthropic")

    def validate_config(self) -> bool:
        """Validate Claude configuration."""
        return bool(self.config.api_key or os.getenv("ANTHROPIC_API_KEY"))

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response using Claude API."""
        if not self.validate_config():
            raise LLMError("Anthropic API key not configured")

        try:
            response = self.client.messages.create(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )

            return LLMResponse(
                content=response.content[0].text,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.input_tokens + response.usage.output_tokens,
                finish_reason=response.stop_reason,
            )
        except Exception as e:
            raise LLMError(f"Claude API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response using conversation history."""
        if not self.validate_config():
            raise LLMError("Anthropic API key not configured")

        system_prompt = ""
        formatted_messages = []

        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            else:
                formatted_messages.append(msg)

        try:
            response = self.client.messages.create(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                system=system_prompt,
                messages=formatted_messages,
            )

            return LLMResponse(
                content=response.content[0].text,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.input_tokens + response.usage.output_tokens,
                finish_reason=response.stop_reason,
            )
        except Exception as e:
            raise LLMError(f"Claude API error: {e}") from e

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        """Stream response using Claude API."""
        if not self.validate_config():
            raise LLMError("Anthropic API key not configured")

        try:
            with self.client.messages.stream(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            ) as stream:
                for text in stream.text_stream:
                    yield text
        except Exception as e:
            raise LLMError(f"Claude streaming error: {e}") from e

    async def generate_async(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Async generate response using Claude API."""
        if not self.validate_config():
            raise LLMError("Anthropic API key not configured")

        try:
            response = await self.async_client.messages.create(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )

            return LLMResponse(
                content=response.content[0].text,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.input_tokens + response.usage.output_tokens,
                finish_reason=response.stop_reason,
            )
        except Exception as e:
            raise LLMError(f"Claude API error: {e}") from e

    async def generate_with_history_async(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Async generate response using conversation history."""
        if not self.validate_config():
            raise LLMError("Anthropic API key not configured")

        system_prompt = ""
        formatted_messages = []

        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            else:
                formatted_messages.append(msg)

        try:
            response = await self.async_client.messages.create(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                system=system_prompt,
                messages=formatted_messages,
            )

            return LLMResponse(
                content=response.content[0].text,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.input_tokens + response.usage.output_tokens,
                finish_reason=response.stop_reason,
            )
        except Exception as e:
            raise LLMError(f"Claude API error: {e}") from e

    async def generate_stream_async(
        self, system_prompt: str, user_prompt: str
    ) -> AsyncIterator[str]:
        """Async stream response using Claude API."""
        if not self.validate_config():
            raise LLMError("Anthropic API key not configured")

        try:
            async with self.async_client.messages.stream(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            ) as stream:
                async for text in stream.text_stream:
                    yield text
        except Exception as e:
            raise LLMError(f"Claude streaming error: {e}") from e
