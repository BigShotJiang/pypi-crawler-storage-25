"""Git subsystem — version control integration."""

from .manager import CommitError, GitError, GitManager, RepositoryNotFoundError, create_git_manager

__all__ = [
    "GitManager",
    "GitError",
    "RepositoryNotFoundError",
    "CommitError",
    "create_git_manager",
]
