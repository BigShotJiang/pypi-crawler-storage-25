"""Step template loader for reusable workflow step definitions."""

import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

_MAX_DEPTH = 10


class StepTemplateParameter(BaseModel):
    """A parameter declaration in a step template."""

    name: str
    description: str = ""
    required: bool = True
    default: Optional[Any] = None


class StepTemplate(BaseModel):
    """A reusable step template definition."""

    name: str = Field(..., description="Template name (matches filename stem)")
    description: str = ""
    parameters: List[StepTemplateParameter] = Field(default_factory=list)
    step: Dict[str, Any] = Field(
        ..., description="Base step definition with {{param}} placeholders"
    )


class StepTemplateLoader:
    """Discover, load, and resolve workflow step templates.

    Templates live in a ``step_templates/`` directory (configurable) as YAML
    files.  Each file defines a ``StepTemplate`` with parameter declarations
    and a base step definition containing ``{{param_name}}`` placeholders.

    Resolution merges the template's base step with step-level overrides and
    substitutes all parameter placeholders.
    """

    PARAM_PATTERN = re.compile(r"\{\{(\w+)\}\}")

    def __init__(self, templates_dir: Optional[str | Path] = None) -> None:
        if templates_dir is not None:
            self._dir = Path(templates_dir)
        else:
            self._dir = Path(__file__).parent.parent / "step_templates"
        self._cache: Dict[str, StepTemplate] = {}

    def _load_template(self, name: str) -> Optional[StepTemplate]:
        if name in self._cache:
            return self._cache[name]
        path = self._dir / f"{name}.yaml"
        if not path.is_file():
            return None
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception as exc:
            logger.warning("Failed to load step template %s: %s", name, exc)
            return None
        if not isinstance(data, dict):
            return None
        tpl = StepTemplate(
            name=data.get("name", name),
            description=data.get("description", ""),
            parameters=[StepTemplateParameter(**p) for p in data.get("parameters", [])],
            step=data.get("step", {}),
        )
        self._cache[name] = tpl
        return tpl

    def list_templates(self) -> List[str]:
        if not self._dir.is_dir():
            return []
        return sorted(fp.stem for fp in self._dir.glob("*.yaml"))

    def get_template(self, name: str) -> Optional[StepTemplate]:
        return self._load_template(name)

    def resolve(
        self,
        template_name: str,
        overrides: Optional[Dict[str, Any]] = None,
        parameters: Optional[Dict[str, Any]] = None,
        resolved_stack: Optional[List[str]] = None,
        depth: int = 0,
    ) -> Dict[str, Any]:
        """Resolve a template reference into a concrete step dict.

        Args:
            template_name: Template to resolve.
            overrides: Step-level fields that override template defaults.
            parameters: Parameter values for ``{{param}}`` substitution.
            resolved_stack: Used internally for circular-reference detection.
            depth: Recursion depth guard.

        Returns:
            Merged step dict with all placeholders substituted.

        Raises:
            ValueError: Circular reference or missing required parameter.
            FileNotFoundError: Template not found.
        """
        if depth > _MAX_DEPTH:
            raise ValueError(f"Template resolution depth exceeded {_MAX_DEPTH}")

        resolved_stack = resolved_stack or []
        if template_name in resolved_stack:
            chain = " -> ".join(resolved_stack + [template_name])
            raise ValueError(f"Circular template reference: {chain}")

        tpl = self._load_template(template_name)
        if tpl is None:
            raise FileNotFoundError(f"Step template not found: {template_name}")

        params = dict(parameters or {})

        for p in tpl.parameters:
            if p.name not in params:
                if p.default is not None:
                    params[p.name] = p.default
                elif p.required:
                    raise ValueError(
                        f"Missing required parameter '{p.name}' for template '{template_name}'"
                    )

        merged = dict(tpl.step)

        if overrides:
            for key, value in overrides.items():
                if key in ("template", "template_params"):
                    continue
                merged[key] = value

        merged = self._substitute(merged, params)

        if "template" in merged:
            inner_name = merged.pop("template")
            inner_params = merged.pop("template_params", {})
            inner_params.update(params)
            return self.resolve(
                inner_name,
                overrides=merged,
                parameters=inner_params,
                resolved_stack=resolved_stack + [template_name],
                depth=depth + 1,
            )

        return merged

    def _substitute(self, data: Any, params: Dict[str, Any]) -> Any:
        if isinstance(data, str):

            def _replace(match: re.Match) -> str:
                name = match.group(1)
                if name in params:
                    return str(params[name])
                return match.group(0)

            return self.PARAM_PATTERN.sub(_replace, data)
        if isinstance(data, dict):
            return {k: self._substitute(v, params) for k, v in data.items()}
        if isinstance(data, list):
            return [self._substitute(item, params) for item in data]
        return data
