"""Template Outcome Tracker — links template selections to generation outcomes."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class TemplateOutcomeTracker:
    """Tracks which template selections lead to better generation outcomes.

    Persists per-genre, per-phase weight adjustments as JSON.
    Key format: ``"{genre}|{phase_kind}|{template_id}"``
    Value: ``{"count": N, "total_score": float, "avg_score": float}``
    """

    def __init__(self, store_path: Optional[Path] = None) -> None:
        if store_path is None:
            store_path = Path(__file__).parent / "data" / "template_outcomes.json"
        self._path = Path(store_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._data: Dict[str, dict] = self._load()
        self._last_selections: Dict[str, str] = {}

    def _load(self) -> Dict[str, dict]:
        if self._path.exists():
            try:
                with open(self._path, encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                logger.debug("Failed to load template outcomes from %s", self._path)
        return {}

    def _save(self) -> None:
        try:
            with open(self._path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2)
        except Exception:
            logger.debug("Failed to save template outcomes to %s", self._path)

    def record_selection(
        self,
        session_id: str,
        template_id: str,
        genre: str,
        phase_kind: str,
    ) -> None:
        """Record that a template was selected for a given session."""
        self._last_selections[session_id] = template_id
        key = f"{genre}|{phase_kind}|{template_id}"
        if key not in self._data:
            self._data[key] = {"count": 0, "total_score": 0.0, "avg_score": 0.0}
        self._save()

    def record_outcome(
        self,
        session_id: str,
        verification_score: float,
        genre: str = "",
        phase_kind: str = "",
    ) -> None:
        """Record a generation outcome, linking it to the last template selection."""
        template_id = self._last_selections.pop(session_id, None)
        if not template_id:
            return
        key = f"{genre}|{phase_kind}|{template_id}"
        if key not in self._data:
            self._data[key] = {"count": 0, "total_score": 0.0, "avg_score": 0.0}
        entry = self._data[key]
        entry["count"] = entry.get("count", 0) + 1
        entry["total_score"] = entry.get("total_score", 0.0) + verification_score
        entry["avg_score"] = round(entry["total_score"] / entry["count"], 3)
        self._save()

    def get_weights(self, genre: str, phase_kind: str) -> Dict[str, float]:
        """Return template_id → weight multiplier for a genre+phase combination.

        Weight is derived from avg_score relative to the global mean.
        Templates with above-average scores get boosted; below-average get deprioritized.
        """
        matching = {}
        for key, entry in self._data.items():
            parts = key.split("|", 2)
            if len(parts) != 3:
                continue
            g, p, tid = parts
            if g == genre and p == phase_kind:
                matching[tid] = entry.get("avg_score", 0.0)
        if not matching:
            return {}
        values = list(matching.values())
        global_mean = sum(values) / len(values)
        if global_mean == 0:
            return {}
        weights = {}
        for tid, score in matching.items():
            weights[tid] = score / global_mean
        return weights

    def get_stats(self) -> Dict[str, dict]:
        """Return all tracked data (for diagnostics)."""
        return dict(self._data)
