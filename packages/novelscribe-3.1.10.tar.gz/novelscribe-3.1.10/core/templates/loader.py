"""
Template Loader Module

Loads and manages story templates for different languages.
Supports:
- Plot structures (Hero's Journey, Three-Act, etc.)
- Character archetypes
- Scene structures
- Genre-specific templates
"""

from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


class TemplateLoader:
    """Load and manage story templates"""

    def __init__(self, templates_dir: str = None, language: str = "en"):
        """
        Initialize template loader.

        Args:
            templates_dir: Path to templates directory
            language: Language code (en, zh-CN, zh-TW)
        """
        if templates_dir:
            self.templates_dir = Path(templates_dir)
        else:
            self.templates_dir = Path(__file__).parent.parent / "templates"

        self.language = language
        self._cache = {}

    def _load_yaml(self, file_path: Path) -> Dict:
        """Load YAML file with caching"""
        if file_path in self._cache:
            return self._cache[file_path]

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
                self._cache[file_path] = data
                return data
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            return {}

    def _get_template_path(self, category: str, filename: str) -> Path:
        """Get template path for current language"""
        lang_path = self.templates_dir / self.language / category / filename
        if lang_path.exists():
            return lang_path

        en_path = self.templates_dir / "en" / category / filename
        if en_path.exists():
            return en_path

        bare_path = self.templates_dir / category / filename
        if bare_path.exists():
            return bare_path

        return lang_path

    def list_templates(self, category: str) -> List[str]:
        """List available templates in a category"""
        path = self.templates_dir / self.language / category
        if not path.exists():
            path = self.templates_dir / "en" / category
        if not path.exists():
            path = self.templates_dir / category

        if not path.exists():
            return []

        return [f.stem for f in path.glob("*.yaml")]

    def load_plot_template(self, template_name: str) -> Optional[Dict]:
        """Load a plot structure template"""
        path = self._get_template_path("plot", f"{template_name}.yaml")
        data = self._load_yaml(path)
        return data.get("templates", {})

    def load_character_template(self, template_name: str = "archetypes") -> Optional[Dict]:
        """Load character templates"""
        path = self._get_template_path("character", f"{template_name}.yaml")
        return self._load_yaml(path)

    def load_scene_template(self, template_name: str = "structure") -> Optional[Dict]:
        """Load scene templates"""
        path = self._get_template_path("scene", f"{template_name}.yaml")
        return self._load_yaml(path)

    def get_plot_structures(self) -> List[Dict[str, Any]]:
        """Get all available plot structures"""
        structures = []
        for name in self.list_templates("plot"):
            template = self.load_plot_template(name)
            if template:
                for key, data in template.items():
                    structures.append(
                        {
                            "name": data.get("name", key),
                            "description": data.get("description", ""),
                            "template_key": key,
                            "beats": data.get("beats", []),
                        }
                    )
        return structures

    def get_character_types(self) -> Dict[str, Any]:
        """Get all character types"""
        template = self.load_character_template()
        return template.get("character_types", {})

    def get_arc_types(self) -> Dict[str, Any]:
        """Get all arc types"""
        template = self.load_character_template()
        return template.get("arc_types", {})

    def get_scene_types(self) -> Dict[str, Any]:
        """Get all scene types"""
        template = self.load_scene_template()
        return template.get("scene_types", {})

    def get_plot_beat_for_position(self, template_name: str, position: float) -> Optional[Dict]:
        """Get the plot beat at a specific position percentage"""
        template = self.load_plot_template(template_name)
        if not template:
            return None

        # Get first (and usually only) template
        template_data = list(template.values())[0] if template else {}
        beats = template_data.get("beats", [])

        # Find the beat that covers this position
        for i, beat in enumerate(beats):
            beat_percentage = beat.get("percentage", 0)
            next_percentage = beats[i + 1].get("percentage", 100) if i + 1 < len(beats) else 100

            if beat_percentage <= position < next_percentage:
                return beat

        return beats[-1] if beats else None

    def format_template_for_prompt(self, template_name: str, template_type: str = "plot") -> str:
        """Format template for use in LLM prompts"""
        if template_type == "plot":
            data = self.load_plot_template(template_name)
            if not data:
                return ""

            template_data = list(data.values())[0] if data else {}
            beats = template_data.get("beats", [])

            formatted = f"## {template_data.get('name', template_name)}\n\n"
            formatted += f"{template_data.get('description', '')}\n\n"

            for beat in beats:
                formatted += f"### {beat.get('name', 'Unknown')}\n"
                formatted += f"{beat.get('description', '')}\n"
                formatted += f"Position: {beat.get('percentage', 0)}%\n"

                questions = beat.get("questions", [])
                if questions:
                    formatted += "Questions:\n"
                    for q in questions:
                        formatted += f"- {q}\n"
                formatted += "\n"

            return formatted

        return ""


def get_template_loader(language: str = "en") -> TemplateLoader:
    """Get a template loader instance"""
    return TemplateLoader(language=language)


# Example usage:
if __name__ == "__main__":
    loader = get_template_loader("en")

    # List available plot structures
    print("Available Plot Structures:")
    for s in loader.get_plot_structures():
        print(f"  - {s['name']}: {s['description']}")

    # Get a specific template
    template = loader.load_plot_template("heros_journey")
    print(f"\nLoaded: {list(template.keys())}")

    # Format for prompt
    formatted = loader.format_template_for_prompt("heros_journey")
    print("\nFormatted Template:")
    print(formatted[:500])
