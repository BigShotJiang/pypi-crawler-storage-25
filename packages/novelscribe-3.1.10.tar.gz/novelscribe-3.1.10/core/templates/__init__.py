"""core.templates — template management subsystem."""

from core.templates.embedding import TemplateEmbeddingIndex
from core.templates.kb import (
    GlobalTemplateWikiStore,
    TemplateHit,
    TemplateWikiRetriever,
    _LoadedPage,
)
from core.templates.loader import TemplateLoader
from core.templates.outcome_tracker import TemplateOutcomeTracker
from core.templates.step_loader import StepTemplate, StepTemplateLoader, StepTemplateParameter

__all__ = [
    "GlobalTemplateWikiStore",
    "_LoadedPage",
    "StepTemplate",
    "StepTemplateLoader",
    "StepTemplateParameter",
    "TemplateEmbeddingIndex",
    "TemplateHit",
    "TemplateLoader",
    "TemplateOutcomeTracker",
    "TemplateWikiRetriever",
]
