"""Template KB — runtime retrieval for shipped global template wiki pages."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from core.memory.models import TemplateKind  # noqa: F401 — exported for public type use

logger = logging.getLogger("scribe")


@dataclass(frozen=True)
class TemplateHit:
    """A single retrieved template match."""

    page_id: str
    template_id: str
    template_kind: str
    title: str
    lang: str
    score: float
    excerpt: str


@dataclass
class _LoadedPage:
    """Internal: parsed template wiki page."""

    page_id: str
    template_id: str
    template_kind: str
    title: str
    lang: str
    tags: List[str]
    body: str


_RE_FRONTMATTER = re.compile(r"^---\n(.*?)\n---", re.DOTALL)
_RE_SECTION = re.compile(r"^## (.+)$", re.MULTILINE)
_RE_TOKENIZE = re.compile(r"[^\w]+")
_RE_CJK_RUN = re.compile(r"[\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff]+")


def _tokenize(text: str) -> Set[str]:
    cjk_spaced = _RE_CJK_RUN.sub(lambda m: " " + m.group() + " ", text)
    return {t.lower() for t in _RE_TOKENIZE.split(cjk_spaced) if t}


def _extract_cjk_words(text: str) -> List[str]:
    return [m.group() for m in _RE_CJK_RUN.finditer(text)]


def _slugify(title: str) -> str:
    return _RE_TOKENIZE.sub("-", title.lower()).strip("-")


def _read_frontmatter(content: str) -> Dict[str, Any]:
    match = _RE_FRONTMATTER.match(content)
    if not match:
        return {}
    result: Dict[str, Any] = {}
    for line in match.group(1).split("\n"):
        if ":" in line:
            key, raw_val = line.split(":", 1)
            val = raw_val.strip().strip("\" '")
            if val.startswith("["):
                result[key.strip()] = [v.strip().strip("\" '") for v in val[1:-1].split(",")]
            else:
                result[key.strip()] = val
    return result


def _normalize_lang_code(lang: str) -> str:
    """Normalize language code to canonical form."""
    lang = lang.strip().lower()
    if lang in ("zh-cn", "zh_hans", "zh_cn", "hans"):
        return "zh"
    if lang in ("zh-tw", "zh_tw", "zhant", "hant"):
        return "zh"
    if lang in ("en-us", "en_gb"):
        return "en"
    return lang if lang else "en"


def _autodetect_lang(body: str, declared_lang: str) -> str:
    if not body:
        return declared_lang
    sample = body[:1000]
    cjk = sum(1 for ch in sample if "\u4e00" <= ch <= "\u9fff")
    ascii_chars = sum(1 for ch in sample if ch.isascii() and ch.isalpha())
    if cjk > ascii_chars and cjk > 20:
        return "zh"
    return declared_lang


class GlobalTemplateWikiStore:
    """Read-only loader for shipped global template wiki pages.

    Pages are loaded once from the package data directory on first access.
    The store exposes minimal iteration API — all filtering/ranking is
    handled by :class:`TemplateWikiRetriever`.
    """

    _instance: Optional["GlobalTemplateWikiStore"] = None

    def __init__(
        self,
        package_data_root: Optional[Path] = None,
    ) -> None:
        if package_data_root is not None:
            self._root = Path(package_data_root)
        else:
            try:
                import novel_harness

                harness_root = Path(novel_harness.__file__).parent
            except (ImportError, AttributeError):
                import core.template_kb as _self

                harness_root = Path(_self.__file__).parent.parent
            self._root = harness_root / "data" / "kb" / "wiki"
        self._templates_root = self._root / "templates"
        self._pages: Optional[List[_LoadedPage]] = None

    def _load_all(self) -> List[_LoadedPage]:
        if self._pages is not None:
            return self._pages
        pages: List[_LoadedPage] = []
        if not self._templates_root.exists():
            return pages
        for kind_dir in self._templates_root.iterdir():
            if not kind_dir.is_dir():
                continue
            kind = kind_dir.name
            for md_file in kind_dir.glob("*.md"):
                pages.append(self._parse(md_file, kind))
        pages.sort(key=lambda p: (p.template_kind, p.lang, p.title))
        self._pages = pages
        return pages

    def _parse(self, md_file: Path, kind: str) -> _LoadedPage:
        content = md_file.read_text(encoding="utf-8")
        fm = _read_frontmatter(content)
        body_start = content.find("---", 3)
        if body_start == -1:
            body_start = 3
        body = content[body_start + 3 :].strip()
        declared_lang = _normalize_lang_code(fm.get("language_code", ""))
        lang = _autodetect_lang(body, declared_lang)
        return _LoadedPage(
            page_id=fm.get("page_id", ""),
            template_id=fm.get("template_id", ""),
            template_kind=kind,
            title=fm.get("title", md_file.stem),
            lang=lang,
            tags=list(fm.get("tags", [])),
            body=body,
        )

    def pages(self, kind: Optional[str] = None, lang: Optional[str] = None) -> List[_LoadedPage]:
        """Iterate all loaded pages, optionally filtered."""
        all_pages = self._load_all()
        if kind is None and lang is None:
            return all_pages
        return [
            p
            for p in all_pages
            if (kind is None or p.template_kind == kind) and (lang is None or p.lang == lang)
        ]

    def get_page(self, page_id: str) -> Optional[_LoadedPage]:
        for page in self._load_all():
            if page.page_id == page_id:
                return page
        return None

    def count(self) -> int:
        return len(self._load_all())

    @classmethod
    def get_instance(cls) -> "GlobalTemplateWikiStore":
        """Return the singleton GlobalTemplateWikiStore instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        cls._instance = None


def _score_page(
    page: _LoadedPage,
    query_tokens: Set[str],
    query_cjk_words: List[str],
    lang_fallback_order: List[str],
    lang_index_map: Dict[str, int],
) -> float:
    """Score a page against a normalized query.

    For CJK query words: substring containment (whole-word in body).
    For non-CJK tokens: set intersection (token-based).
    """
    score = 0.0
    lower_title = page.title.lower()
    lower_body = page.body.lower()

    cjk_hits = 0
    for word in query_cjk_words:
        w = word.lower()
        in_title = w in lower_title
        in_body = w in lower_body
        if in_title:
            score += 4.0
        if in_body:
            score += 1.0
        if in_title or in_body:
            cjk_hits += 1

    if query_cjk_words and cjk_hits > 0:
        hit_ratio = cjk_hits / len(query_cjk_words)
        score *= hit_ratio
        if cjk_hits >= 2:
            score *= cjk_hits

    non_cjk_tokens = query_tokens - {w.lower() for w in query_cjk_words}
    if non_cjk_tokens:
        title_tokens = _tokenize(page.title)
        body_tokens = _tokenize(page.body)
        score += len(non_cjk_tokens & title_tokens) * 3.0
        score += len(non_cjk_tokens & set(page.tags)) * 2.0
        score += len(non_cjk_tokens & body_tokens) * 1.0

    lang_idx = lang_index_map.get(page.lang, 999)
    score += max(0, 5 - lang_idx)
    return score


def _make_excerpt(body: str, max_chars: int = 300) -> str:
    first_section = _RE_SECTION.split(body)[0]
    lines = [ln.strip() for ln in first_section.split("\n") if ln.strip()]
    excerpt = " ".join(lines[:8])
    if len(excerpt) > max_chars:
        excerpt = excerpt[: max_chars - 3].rsplit(" ", 1)[0] + "..."
    return excerpt or body[:max_chars]


def _language_fallback(lang: Optional[str]) -> List[str]:
    canonical = _normalize_lang_code(lang or "en")
    result = [canonical]
    if canonical != "en":
        result.append("en")
    if canonical != "zh":
        result.append("zh")
    return result


class TemplateWikiRetriever:
    """Keyword/tag retrieval over shipped global template wiki pages."""

    def __init__(
        self,
        store: Optional[GlobalTemplateWikiStore] = None,
        top_k: int = 3,
    ) -> None:
        self._store = store or GlobalTemplateWikiStore.get_instance()
        self._top_k = top_k
        self._embedding_index: Any = None

    def retrieve(
        self,
        query: str,
        kind: Optional[str] = None,
        lang: Optional[str] = None,
        top_k: Optional[int] = None,
        weight_overrides: Optional[Dict[str, float]] = None,
    ) -> List[TemplateHit]:
        """Return top-k template hits for a natural-language query.

        Tries semantic search first when the ``[search]`` extra is
        installed; falls back to token/substring matching otherwise.

        Args:
            query: natural-language search query
            kind: filter by template kind (default: all kinds)
            lang: filter/rank by language code (default: "en")
            top_k: maximum number of results (default: self._top_k)
            weight_overrides: optional template_id → multiplier for adaptive weighting

        Returns:
            List of :class:`TemplateHit` ordered by relevance score.
        """
        k = top_k if top_k is not None else self._top_k
        if not query or not query.strip():
            return []

        semantic_hits = self._semantic_retrieve(query, kind=kind, top_k=k)
        if semantic_hits is not None:
            if weight_overrides:
                semantic_hits = self._apply_weights(semantic_hits, weight_overrides)
            return semantic_hits

        return self._token_retrieve(
            query, kind=kind, lang=lang, top_k=k, weight_overrides=weight_overrides
        )

    def _semantic_retrieve(
        self,
        query: str,
        kind: Optional[str] = None,
        top_k: int = 3,
    ) -> Optional[List[TemplateHit]]:
        try:
            from core.template_embedding import TemplateEmbeddingIndex, is_semantic_available

            if not is_semantic_available():
                return None

            if self._embedding_index is None:
                self._embedding_index = TemplateEmbeddingIndex(store=self._store)
            self._embedding_index.build()
            return self._embedding_index.search(query, kind=kind, top_k=top_k)
        except Exception:
            logger.debug("Semantic search failed, falling back to token search", exc_info=True)
            return None

    def _token_retrieve(
        self,
        query: str,
        kind: Optional[str] = None,
        lang: Optional[str] = None,
        top_k: int = 3,
        weight_overrides: Optional[Dict[str, float]] = None,
    ) -> List[TemplateHit]:
        query_tokens = _tokenize(query)
        query_cjk_words = _extract_cjk_words(query)
        fallback_langs = _language_fallback(lang)
        lang_index_map = {lg: i for i, lg in enumerate(fallback_langs)}

        raw_pages = self._store.pages(kind=kind)
        if not raw_pages:
            return []

        candidates = [p for p in raw_pages if p.lang in fallback_langs]
        if not candidates:
            candidates = raw_pages

        scored = [
            (
                p,
                _score_page(p, query_tokens, query_cjk_words, fallback_langs, lang_index_map),
            )
            for p in candidates
        ]
        scored.sort(key=lambda x: (x[1], x[0].page_id), reverse=True)

        hits: List[TemplateHit] = []
        seen_ids: Set[str] = set()
        for page, score in scored:
            page_id = page.page_id
            if page_id in seen_ids:
                continue
            seen_ids.add(page_id)
            hits.append(
                TemplateHit(
                    page_id=page_id,
                    template_id=page.template_id,
                    template_kind=page.template_kind,
                    title=page.title,
                    lang=page.lang,
                    score=round(score, 2),
                    excerpt=_make_excerpt(page.body),
                )
            )
            if len(hits) >= top_k:
                break

        if weight_overrides:
            hits = self._apply_weights(hits, weight_overrides)

        return hits

    @staticmethod
    def _apply_weights(hits: List[TemplateHit], weights: Dict[str, float]) -> List[TemplateHit]:
        """Re-score and re-sort hits based on weight overrides."""
        adjusted = []
        for h in hits:
            w = weights.get(h.template_id, 1.0)
            new_score = round(h.score * w, 2)
            adjusted.append(
                TemplateHit(
                    page_id=h.page_id,
                    template_id=h.template_id,
                    template_kind=h.template_kind,
                    title=h.title,
                    lang=h.lang,
                    score=new_score,
                    excerpt=h.excerpt,
                )
            )
        adjusted.sort(key=lambda x: (x.score, x.page_id), reverse=True)
        return adjusted

    def retrieve_by_page_id(self, page_id: str) -> Optional[TemplateHit]:
        """Direct lookup by page_id."""
        for page in self._store.pages():
            if page.page_id == page_id:
                return TemplateHit(
                    page_id=page.page_id,
                    template_id=page.template_id,
                    template_kind=page.template_kind,
                    title=page.title,
                    lang=page.lang,
                    score=100.0,
                    excerpt=_make_excerpt(page.body),
                )
        return None

    def get_stats(self) -> Dict[str, Any]:
        all_pages = self._store.pages()
        by_kind: Dict[str, int] = {}
        by_lang: Dict[str, int] = {}
        for p in all_pages:
            by_kind[p.template_kind] = by_kind.get(p.template_kind, 0) + 1
            by_lang[p.lang] = by_lang.get(p.lang, 0) + 1
        return {"total": len(all_pages), "by_kind": by_kind, "by_lang": by_lang}

    def list_pages_by_kind(self, kind: str) -> List[Any]:
        return [p for p in self._store.pages() if p.template_kind == kind]
