"""Structured output parser for runtime model responses."""

from __future__ import annotations

import json

from .models import RuntimeTurnResult, ToolCall


class RuntimeOutputParser:
    """Parse model outputs into RuntimeTurnResult."""

    def parse(self, raw_output: str) -> RuntimeTurnResult:
        """Parse raw model text into structured runtime turn result.

        Accepts:
        - Plain text answer
        - JSON object with keys: final_answer, tool_calls, recoverable_error
        """
        text = (raw_output or "").strip()
        if not text:
            return RuntimeTurnResult(final_answer="")

        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            return RuntimeTurnResult(final_answer=text)

        if not isinstance(payload, dict):
            return RuntimeTurnResult(final_answer=text)

        tool_calls: list[ToolCall] = []
        raw_calls = payload.get("tool_calls", [])
        if isinstance(raw_calls, list):
            for item in raw_calls:
                if not isinstance(item, dict):
                    continue
                name = item.get("name")
                args = item.get("arguments", {})
                if isinstance(name, str) and isinstance(args, dict):
                    tool_calls.append(ToolCall(name=name, arguments=args))

        final_answer = payload.get("final_answer")
        recoverable_error = payload.get("recoverable_error")
        if final_answer is not None and not isinstance(final_answer, str):
            final_answer = str(final_answer)
        if recoverable_error is not None and not isinstance(recoverable_error, str):
            recoverable_error = str(recoverable_error)

        return RuntimeTurnResult(
            final_answer=final_answer,
            tool_calls=tool_calls,
            recoverable_error=recoverable_error,
        )
