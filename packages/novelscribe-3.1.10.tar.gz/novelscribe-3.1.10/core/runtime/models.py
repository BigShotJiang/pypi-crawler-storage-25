"""Data models for the Runtime kernel scaffold."""

from __future__ import annotations

from enum import Enum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class RuntimeTask(BaseModel):
    """A single runtime task request."""

    task_id: str = Field(default_factory=lambda: str(uuid4()))
    user_input: str
    system_prompt: str = ""
    agent_name: str = "runtime_agent"
    provider: str = "openai"
    llm_config: dict[str, Any] = Field(default_factory=lambda: {"max_tokens": 4096})
    tool_definitions: list[dict[str, Any]] = Field(default_factory=list)
    memory_query: str | None = None
    max_turns: int = 1
    metadata: dict[str, Any] = Field(default_factory=dict)


class RuntimeState(BaseModel):
    """Mutable state tracked across runtime turns."""

    turn_index: int = 0
    finished: bool = False
    last_system_prompt: str = ""
    last_user_prompt: str = ""
    last_raw_output: str = ""
    last_final_output: str = ""
    conversation_history: list[dict[str, str]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ToolCall(BaseModel):
    """Structured tool call emitted by model output parser."""

    name: str
    arguments: dict[str, Any] = Field(default_factory=dict)


class RuntimeTurnResult(BaseModel):
    """Structured runtime output for a single model turn."""

    final_answer: str | None = None
    tool_calls: list[ToolCall] = Field(default_factory=list)
    recoverable_error: str | None = None


class RuntimeOutcome(BaseModel):
    """Final outcome of a runtime turn loop."""

    success: bool
    turns_executed: int
    final_output: str | None = None
    error: str | None = None
    state: RuntimeState


class SubagentMode(str, Enum):
    """Subagent orchestration mode.

    Modes:
        INDEPENDENT: Runs independently without aggregating results.
            Sequential execution in current implementation; parallel execution
            planned for v4.6.
        TEAMMATE: Runs and contributes notes to the aggregate output.
        HANDOFF: Runs and transfers control to its result (first to succeed wins).
    """

    INDEPENDENT = "independent"
    TEAMMATE = "teammate"
    HANDOFF = "handoff"

    # Deprecated alias — use INDEPENDENT
    FORK = "independent"


class SubagentTask(BaseModel):
    """Subagent execution request parsed from RuntimeTask metadata."""

    name: str
    mode: SubagentMode
    user_input: str
    system_prompt: str | None = None
    max_turns: int = 1
    metadata: dict[str, Any] = Field(default_factory=dict)


class SubagentResult(BaseModel):
    """Structured execution result for a subagent run."""

    name: str
    mode: SubagentMode
    task_id: str
    success: bool
    turns_executed: int
    final_output: str | None = None
    error: str | None = None
    replay_events: list[dict[str, str]] = Field(default_factory=list)


class SubagentBatchResult(BaseModel):
    """Aggregated subagent orchestration result."""

    records: list[SubagentResult] = Field(default_factory=list)
    teammate_notes: list[str] = Field(default_factory=list)
    handoff_output: str | None = None
