"""Runtime kernel facade — public interface hiding dependency graph."""

from __future__ import annotations

import logging
from typing import Any

from core.hooks import HookEventBus

from ._agent_runtime import AgentRuntime
from ._turn_loop import TurnLoopEngine
from .models import RuntimeOutcome, RuntimeState, RuntimeTask
from .runtime_lifecycle import RuntimeConfig, ensure_checkpoint_store

InferFn = Any
_logger = logging.getLogger(__name__)


class RuntimeKernel:
    """Runtime kernel facade.

    Public interface for the runtime turn loop.
    Callers (WorkflowExecutor, AutonomousExecutor) use this, not AgentRuntime.

    Key behaviors:
        - fork() returns new kernel sharing components, independent state
        - Checkpoint store created lazily per run
        - Hook subscriptions resolved once at run() start
        - Full AgentRuntime signature preserved for backward compatibility
    """

    def __init__(
        self,
        infer_fn: InferFn,
        config: RuntimeConfig | None = None,
        **kwargs: Any,
    ) -> None:
        cfg = config or RuntimeConfig()
        for k, v in kwargs.items():
            if hasattr(cfg, k):
                setattr(cfg, k, v)
        self._infer_fn = infer_fn
        self._prompt_assembler = cfg.prompt_assembler
        self._output_parser = cfg.output_parser
        self._context_bus = cfg.context_bus
        self._memory_bridge = cfg.memory_bridge
        self._tool_registry = cfg.tool_registry
        self._tool_executor = cfg.tool_executor
        self._guardrail_engine = cfg.guardrail_engine
        self._turn_checkpoint_store = cfg.turn_checkpoint_store
        self._verification_suite = cfg.verification_suite
        self._subagent_manager = cfg.subagent_manager
        self._hook_event_bus = cfg.hook_event_bus or HookEventBus()
        self._auto_feedback_enabled = cfg.auto_feedback_enabled
        self._max_feedback_rounds = cfg.max_feedback_rounds

        self._agent_runtime: AgentRuntime | None = None

    @classmethod
    def from_llm_client(
        cls,
        llm_client: Any,
        context_bus: Any | None = None,
        memory_bus: Any | None = None,
        **kwargs: Any,
    ) -> "RuntimeKernel":
        """Create kernel from an LLM client (convenience factory)."""

        def _infer(system_prompt: str, user_prompt: str) -> str:
            response = llm_client.generate(system_prompt=system_prompt, user_prompt=user_prompt)
            return response.content

        memory_bridge = None
        if memory_bus is not None:
            from .memory_bridge import MemoryBridge

            memory_bridge = MemoryBridge(memory_bus)

        guardrail_engine = kwargs.pop("guardrail_engine", None)
        if guardrail_engine is None:
            from .guardrails import GuardrailEngine

            guardrail_engine = GuardrailEngine()

        return cls(
            infer_fn=_infer,
            context_bus=context_bus,
            memory_bridge=memory_bridge,
            guardrail_engine=guardrail_engine,
            **kwargs,
        )

    def fork(self, task: RuntimeTask) -> "RuntimeKernel":
        """Create child kernel sharing components, independent state.

        The child shares LLM inference, tools, guardrails, and hooks with the parent.
        Each fork has its own AgentRuntime instance and RuntimeState.
        """
        return RuntimeKernel(
            infer_fn=self._infer_fn,
            config=RuntimeConfig(
                prompt_assembler=self._prompt_assembler,
                output_parser=self._output_parser,
                context_bus=self._context_bus,
                memory_bridge=self._memory_bridge,
                tool_registry=self._tool_registry,
                tool_executor=self._tool_executor,
                guardrail_engine=self._guardrail_engine,
                turn_checkpoint_store=self._turn_checkpoint_store,
                verification_suite=self._verification_suite,
                subagent_manager=self._subagent_manager,
                hook_event_bus=self._hook_event_bus,
                auto_feedback_enabled=self._auto_feedback_enabled,
                max_feedback_rounds=self._max_feedback_rounds,
            ),
        )

    def run(self, task: RuntimeTask, state: RuntimeState) -> RuntimeOutcome:
        """Execute the runtime turn loop.

        Hook subscriptions are resolved once at run() start (not per-emit).
        Checkpoint store is created lazily if not provided.
        """
        if self._agent_runtime is None:
            self._agent_runtime = AgentRuntime(
                infer_fn=self._infer_fn,
                config=RuntimeConfig(
                    prompt_assembler=self._prompt_assembler,
                    output_parser=self._output_parser,
                    context_bus=self._context_bus,
                    memory_bridge=self._memory_bridge,
                    tool_registry=self._tool_registry,
                    tool_executor=self._tool_executor,
                    guardrail_engine=self._guardrail_engine,
                    turn_checkpoint_store=self._turn_checkpoint_store,
                    verification_suite=self._verification_suite,
                    subagent_manager=self._subagent_manager,
                    hook_event_bus=self._hook_event_bus,
                    auto_feedback_enabled=self._auto_feedback_enabled,
                    max_feedback_rounds=self._max_feedback_rounds,
                ),
            )

        if self._turn_checkpoint_store is None:
            self._turn_checkpoint_store = ensure_checkpoint_store(None, task)

        engine = TurnLoopEngine(
            callbacks=self._agent_runtime,
            checkpoint_store=self._turn_checkpoint_store,
        )
        return engine.execute(task, state)
