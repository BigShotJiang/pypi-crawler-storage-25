"""Runtime guardrail engine for input/output/tool protection."""

from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, Field


class GuardrailConfig(BaseModel):
    """Configurable guardrail policies."""

    blocked_input_patterns: list[str] = Field(
        default_factory=lambda: [r"rm\s+-rf", r"ignore\s+all\s+previous\s+instructions"]
    )
    blocked_output_patterns: list[str] = Field(
        default_factory=lambda: [r"api[_-]?key", r"password"]
    )
    allowed_tool_permissions: set[str] = Field(default_factory=lambda: {"default", "system"})


class GuardrailDecision(BaseModel):
    """Guardrail decision outcome."""

    allowed: bool
    reason: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class GuardrailEngine:
    """Engine implementing input/output/tool guardrails."""

    def __init__(self, config: GuardrailConfig | None = None) -> None:
        self.config = config or GuardrailConfig()

    def validate_input(self, user_input: str) -> GuardrailDecision:
        """Validate incoming user input before model invocation."""
        for pattern in self.config.blocked_input_patterns:
            if re.search(pattern, user_input, flags=re.IGNORECASE):
                return GuardrailDecision(
                    allowed=False,
                    reason=f"Input blocked by guardrail pattern: {pattern}",
                    metadata={"layer": "input", "pattern": pattern},
                )
        return GuardrailDecision(allowed=True, metadata={"layer": "input"})

    def validate_output(self, output_text: str) -> GuardrailDecision:
        """Validate model output before returning result."""
        for pattern in self.config.blocked_output_patterns:
            if re.search(pattern, output_text, flags=re.IGNORECASE):
                return GuardrailDecision(
                    allowed=False,
                    reason=f"Output blocked by guardrail pattern: {pattern}",
                    metadata={"layer": "output", "pattern": pattern},
                )
        return GuardrailDecision(allowed=True, metadata={"layer": "output"})

    def validate_tool_call(self, tool_name: str, permission: str) -> GuardrailDecision:
        """Validate tool call permission before execution."""
        if permission not in self.config.allowed_tool_permissions:
            return GuardrailDecision(
                allowed=False,
                reason=f"Tool permission denied: {permission}",
                metadata={
                    "layer": "tool",
                    "tool": tool_name,
                    "permission": permission,
                },
            )
        return GuardrailDecision(
            allowed=True,
            metadata={"layer": "tool", "tool": tool_name, "permission": permission},
        )
