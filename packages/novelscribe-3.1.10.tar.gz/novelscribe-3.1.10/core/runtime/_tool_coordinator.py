"""Tool coordination — tool call execution, permission validation, and tool-related error handling.

Extracted from AgentRuntime to allow independent testing of tool coordination.

Interface:
    ToolCoordinator(tool_executor, guardrail_engine, tool_registry)
        handle_tool_calls(turn_result, task, state, turns_executed, emit_fn)
        fail_recoverable(turn_result, state, turns_executed, task, emit_fn)
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from core.hooks import HookEvent

if TYPE_CHECKING:
    from .models import RuntimeOutcome


def handle_tool_calls(
    turn_result: Any,
    task: Any,
    state: Any,
    turns_executed: int,
    tool_executor: Any,
    guardrail_engine: Any,
    tool_registry: Any,
    emit_fn: Any,
) -> Any | None:
    """Execute tool calls from turn_result and update state.

    Returns:
        None → all tools succeeded, continue loop
        RuntimeOutcome → tool failed, short-circuit with failure
    """
    from .models import RuntimeOutcome
    from .runtime_tools import execute_tool_calls

    results = execute_tool_calls(
        turn_result,
        task,
        state,
        tool_executor,
        guardrail_engine,
        tool_registry,
    )
    state.metadata["last_tool_results"] = results
    state.conversation_history.append(
        {"role": "tool", "content": json.dumps(results, ensure_ascii=True)}
    )
    failed = [r for r in results if not r.get("success", False)]
    if failed:
        err = failed[0].get("error", "Tool execution failed")
        emit_fn(
            HookEvent.RUNTIME_TURN_FAILED.value,
            task,
            state,
            {"error": str(err), "turn_index": state.turn_index, "tool_results": results},
        )
        return RuntimeOutcome(
            success=False,
            turns_executed=turns_executed,
            final_output=state.last_final_output or None,
            error=str(err),
            state=state,
        )
    return None


def fail_recoverable(
    turn_result: Any,
    state: Any,
    turns_executed: int,
    task: Any,
    emit_fn: Any,
) -> "RuntimeOutcome":
    """Handle recoverable error from turn result (typically from tool execution)."""
    from .models import RuntimeOutcome
    from .runtime_lifecycle import RuntimeErrorCategory, build_error_payload

    ep = build_error_payload(
        message=turn_result.recoverable_error,
        category=RuntimeErrorCategory.RECOVERABLE_MODEL,
        retryable=False,
    )
    state.metadata["error"] = ep
    emit_fn(
        HookEvent.RUNTIME_TURN_FAILED.value,
        task,
        state,
        {
            "error": turn_result.recoverable_error,
            "turn_index": state.turn_index,
            "error_payload": ep,
        },
    )
    return RuntimeOutcome(
        success=False,
        turns_executed=turns_executed,
        final_output=state.last_final_output or None,
        error=turn_result.recoverable_error,
        state=state,
    )
