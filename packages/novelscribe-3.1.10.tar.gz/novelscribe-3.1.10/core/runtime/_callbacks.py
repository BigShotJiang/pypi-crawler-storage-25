"""Callback protocol for TurnLoopEngine.

Defines the interface that AgentRuntime (as the callback provider) must implement.
This is the seam between the iteration structure (TurnLoopEngine) and the
business logic (AgentRuntime methods).

Each method corresponds to a step in the original run_turn_loop().
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from .models import RuntimeOutcome, RuntimeState, RuntimeTask, RuntimeTurnResult

CONTINUE_SENTINEL = object()


@runtime_checkable
class TurnLoopCallbacks(Protocol):
    """Protocol for turn loop callbacks.

    TurnLoopEngine holds a reference to an object implementing this protocol.
    All business logic is delegated through these methods, keeping the
    loop skeleton free of domain knowledge.

    Design decisions routed through this seam:
        - Subagent execution: run_pre_turn → execute_subagents_if_needed
        - Guardrail validation: run_pre_turn → validate_input_guardrail
        - Turn execution: execute_turn → _execute_single_turn
        - Tool handling: handle_tool_calls → _handle_tool_calls
        - Error recovery: fail_recoverable → _fail_recoverable
        - Post-turn validation: run_post_turn → _run_post_turn_checks
        - Memory persistence: write_memory → write_memory
        - Checkpointing: save_checkpoint → save_checkpoint
        - Hook emission: emit → _emit
        - Max-turns failure: fail_max_turns → _fail_max_turns
        - Exception handling: fail_exception → _fail_exception
    """

    def load_latest_turn_state(self, task_id: str) -> RuntimeState | None:
        """Load checkpointed state for resume. Returns None if no checkpoint."""
        ...

    def run_pre_turn(self, task: RuntimeTask, state: RuntimeState) -> RuntimeOutcome | None:
        """Run pre-turn checks (subagent, guardrail). Return outcome to short-circuit or None."""
        ...

    def save_checkpoint(self, phase: str, task: RuntimeTask, state: RuntimeState) -> None:
        """Persist current state at the given phase (turn_start / turn_complete)."""
        ...

    def execute_turn(self, task: RuntimeTask, state: RuntimeState) -> tuple[RuntimeTurnResult, str]:
        """Execute a single turn. Returns (turn_result, final_output)."""
        ...

    def handle_tool_calls(
        self,
        turn_result: Any,
        task: RuntimeTask,
        state: RuntimeState,
        turns_executed: int,
    ) -> RuntimeOutcome | None:
        """Handle tool calls from turn_result. Return outcome to short-circuit, or None."""
        ...

    def fail_recoverable(
        self,
        turn_result: Any,
        state: RuntimeState,
        turns_executed: int,
        task: RuntimeTask,
    ) -> RuntimeOutcome:
        """Handle recoverable error from turn result."""
        ...

    def run_post_turn(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        final_output: str,
        turns_executed: int,
        feedback_rounds: int,
    ) -> RuntimeOutcome | None | tuple[type[CONTINUE_SENTINEL], int]:
        """Run post-turn checks. Return outcome, None, or (CONTINUE_SENTINEL, feedback_rounds)."""
        ...

    def write_memory(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        final_output: str,
    ) -> None:
        """Write final output to memory."""
        ...

    def emit(
        self,
        event: str,
        task: RuntimeTask,
        state: RuntimeState,
        metadata: dict[str, Any],
    ) -> None:
        """Emit a hook event."""
        ...

    def fail_max_turns(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        turns_executed: int,
    ) -> RuntimeOutcome:
        """Handle max-turns exceeded without finished flag."""
        ...

    def fail_exception(
        self,
        exc: Exception,
        task: RuntimeTask,
        state: RuntimeState,
        turns_executed: int,
    ) -> RuntimeOutcome:
        """Handle unexpected exception during loop."""
        ...
