"""Runtime verification hooks and feedback strategy."""

from __future__ import annotations

from typing import Any, Protocol

from pydantic import BaseModel, Field

from core.quality.gate import QualityGate, QualityLevel
from core.quality.metric_calculators import QualityMetricsCalculator
from core.quality.validation_engine import ValidationSystem
from core.quality.verification_engine import VerificationEngine

from .models import RuntimeState, RuntimeTask


class RuntimeVerificationFeedback(BaseModel):
    """Structured result emitted by one verification hook."""

    source: str
    passed: bool
    summary: str
    suggested_prompt: str = ""
    details: dict[str, Any] = Field(default_factory=dict)


class RuntimeVerificationBundle(BaseModel):
    """Aggregated verification results for one runtime turn."""

    passed: bool
    feedback_items: list[RuntimeVerificationFeedback] = Field(default_factory=list)


class RuntimeVerificationHook(Protocol):
    """Hook interface for runtime verification stage."""

    def verify(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        final_output: str,
    ) -> RuntimeVerificationFeedback: ...


class ValidationSystemHook:
    """ValidationSystem adapter hook."""

    def __init__(self, validator: ValidationSystem):
        self._validator = validator

    def verify(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        final_output: str,
    ) -> RuntimeVerificationFeedback:
        report = self._validator.validate_content(final_output, context=task.metadata)
        passed = report.errors == 0
        summary = (
            f"Validation {'passed' if passed else 'failed'}: "
            f"errors={report.errors}, warnings={report.warnings}"
        )
        suggestion = "" if passed else "Please fix validation errors and reduce warnings."
        return RuntimeVerificationFeedback(
            source="validation_system",
            passed=passed,
            summary=summary,
            suggested_prompt=suggestion,
            details={"errors": report.errors, "warnings": report.warnings},
        )


class QualityGateHook:
    """QualityGate adapter hook."""

    def __init__(
        self,
        quality_gate: QualityGate,
        metrics_calculator: QualityMetricsCalculator,
        target_level: QualityLevel = QualityLevel.SILVER,
    ):
        self._quality_gate = quality_gate
        self._metrics_calculator = metrics_calculator
        self._target_level = target_level

    def verify(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        final_output: str,
    ) -> RuntimeVerificationFeedback:
        chapter_number = int(task.metadata.get("chapter_number", 1))
        metrics = self._metrics_calculator.calculate_metrics(
            content=final_output,
            chapter_number=chapter_number,
            version=max(state.turn_index, 1),
        )
        result = self._quality_gate.check_quality_gate(
            project_name=task.metadata.get("project_name", "runtime_project"),
            metrics=metrics,
            target_level=self._target_level,
        )
        suggestion = "" if result.passed else "Improve failed quality criteria and regenerate."
        return RuntimeVerificationFeedback(
            source="quality_gate",
            passed=result.passed,
            summary=(
                f"Quality gate {'passed' if result.passed else 'failed'} "
                f"at {self._target_level.value}"
            ),
            suggested_prompt=suggestion,
            details={
                "failed_criteria": result.failed_criteria,
                "overall_score": result.overall_score,
            },
        )


class VerificationEngineHook:
    """VerificationEngine adapter hook using quick verification."""

    def __init__(self, engine: VerificationEngine):
        self._engine = engine

    def verify(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        final_output: str,
    ) -> RuntimeVerificationFeedback:
        _ = (task, state, final_output)
        report = self._engine.quick_verify()
        passed = str(report.status).lower().endswith("pass")
        summary = f"Verification engine status: {report.status}"
        suggestion = "" if passed else "Apply verification fixes and regenerate content."
        return RuntimeVerificationFeedback(
            source="verification_engine",
            passed=passed,
            summary=summary,
            suggested_prompt=suggestion,
            details={"total_issues": report.total_issues},
        )


class RuntimeVerificationSuite:
    """Runtime-level hook runner and feedback prompt generator."""

    def __init__(self, hooks: list[RuntimeVerificationHook] | None = None):
        self._hooks = hooks or []

    def run_hooks(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        final_output: str,
    ) -> RuntimeVerificationBundle:
        """Run all verification hooks and aggregate outputs."""
        feedback_items: list[RuntimeVerificationFeedback] = []
        overall_passed = True
        for hook in self._hooks:
            feedback = hook.verify(task=task, state=state, final_output=final_output)
            feedback_items.append(feedback)
            overall_passed = overall_passed and feedback.passed
        return RuntimeVerificationBundle(passed=overall_passed, feedback_items=feedback_items)

    def build_feedback_prompt(self, bundle: RuntimeVerificationBundle) -> str:
        """Build auto-feedback prompt injected into next runtime turn."""
        failed = [item for item in bundle.feedback_items if not item.passed]
        if not failed:
            return ""
        lines = ["Verification feedback:"]
        for item in failed:
            lines.append(f"- [{item.source}] {item.summary}")
            if item.suggested_prompt:
                lines.append(f"  Suggestion: {item.suggested_prompt}")
        return "\n".join(lines)
