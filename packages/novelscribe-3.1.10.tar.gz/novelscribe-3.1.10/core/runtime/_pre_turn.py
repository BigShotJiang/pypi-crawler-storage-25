"""Pre-turn gate — subagent execution and input guardrail validation.

Extracted from AgentRuntime to allow independent testing of the pre-turn phase.

Result:
    None — proceed to turn execution
    RuntimeOutcome — short-circuit and return failure
"""

from __future__ import annotations

from typing import Any


class PreTurnGateResult:
    __slots__ = ("outcome", "subagent_result")

    def __init__(self, outcome: Any = None, subagent_result: Any = None) -> None:
        self.outcome = outcome
        self.subagent_result = subagent_result

    @property
    def should_short_circuit(self) -> bool:
        return self.outcome is not None

    @staticmethod
    def pass_through() -> "PreTurnGateResult":
        return PreTurnGateResult(outcome=None, subagent_result=None)


def run_pre_turn_gate(
    task: Any,
    state: Any,
    subagent_manager: Any,
    guardrail_engine: Any,
    emit_fn: Any,
    parent: Any | None = None,
) -> PreTurnGateResult:
    """Run pre-turn checks: subagent execution and input guardrail validation.

    Returns PreTurnGateResult:
        - outcome is None → proceed to turn execution
        - outcome is RuntimeOutcome → short-circuit with failure
    """
    from core.hooks import HookEvent

    from .runtime_guardrails import validate_input_guardrail
    from .runtime_subagents import execute_subagents_if_needed

    if state.turn_index == 0 and parent is not None:
        sub = execute_subagents_if_needed(task, state, subagent_manager, parent)
        if sub is not None:
            if not sub.success:
                emit_fn(
                    HookEvent.RUNTIME_TURN_FAILED.value,
                    task,
                    state,
                    {
                        "error": sub.error or "Subagent execution failed",
                        "turn_index": state.turn_index,
                    },
                )
            return PreTurnGateResult(outcome=sub, subagent_result=sub)
    guard = validate_input_guardrail(guardrail_engine, task, state)
    if guard is not None:
        emit_fn(
            HookEvent.RUNTIME_TURN_FAILED.value,
            task,
            state,
            {"error": guard.error or "Input guardrail blocked", "turn_index": state.turn_index},
        )
        return PreTurnGateResult(outcome=guard)
    return PreTurnGateResult.pass_through()


def _parent_runtime(emit_fn: Any) -> Any:
    class _DummyParent:
        def _emit(self, event: str, task: Any, state: Any, metadata: Any) -> None:
            emit_fn(event, task, state, metadata)

    return _DummyParent()
