"""Subagent orchestration manager for Runtime mainline integration."""

from __future__ import annotations

from collections.abc import Callable

from .models import SubagentBatchResult, SubagentMode, SubagentResult, SubagentTask

SubagentRunner = Callable[[SubagentTask], SubagentResult]


class SubagentManager:
    """Execute Fork/Teammate/Handoff subagent runs and aggregate outputs."""

    def __init__(self, max_subagents: int = 8) -> None:
        self._max_subagents = max_subagents

    def parse_tasks(self, payload: object) -> list[SubagentTask]:
        """Parse raw subagent payload into typed tasks."""
        if not isinstance(payload, list):
            return []
        tasks: list[SubagentTask] = []
        for item in payload:
            if not isinstance(item, dict):
                continue
            tasks.append(SubagentTask(**item))
        return tasks[: self._max_subagents]

    def execute(self, tasks: list[SubagentTask], runner: SubagentRunner) -> SubagentBatchResult:
        """Run subagents and aggregate protocol-compliant orchestration outputs."""
        batch = SubagentBatchResult()
        for task in tasks:
            result = runner(task)
            batch.records.append(result)

            if task.mode == SubagentMode.TEAMMATE and result.final_output:
                batch.teammate_notes.append(f"[{task.name}] {result.final_output}")

            if task.mode == SubagentMode.HANDOFF and result.success:
                batch.handoff_output = result.final_output
                break
        return batch
