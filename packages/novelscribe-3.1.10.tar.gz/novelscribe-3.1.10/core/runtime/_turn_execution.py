"""Single turn execution — context assembly, inference, and output parsing.

Extracted from AgentRuntime. This is the core execution path: build prompt → infer → parse.

Interface:
    execute_turn(task, state, infer_fn, context_bus, memory_bridge,
                 prompt_assembler, output_parser, tool_registry, emit_fn)
    → (RuntimeTurnResult, final_output: str)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .models import RuntimeTurnResult


def execute_turn(
    task: Any,
    state: Any,
    infer_fn: Any,
    context_bus: Any,
    memory_bridge: Any,
    prompt_assembler: Any,
    output_parser: Any,
    tool_registry: Any,
    emit_fn: Any,
) -> tuple["RuntimeTurnResult", str]:
    """Execute a single turn: assemble prompts, infer, parse, update state.

    Returns (turn_result, final_output) where final_output is the cleaned answer string.
    """
    from core.hooks import HookEvent

    from .runtime_lifecycle import build_context, build_history_context, build_memory_context

    if tool_registry is not None:
        task.tool_definitions = tool_registry.list_for_model()
    ctx, ctx_meta = build_context(context_bus, task)
    mem, mem_meta = build_memory_context(memory_bridge, task, state, ctx)
    hist = build_history_context(state)
    assembly = prompt_assembler.assemble(
        task=task, state=state, memory_context=mem, history_context=hist
    )
    sys_p, usr_p = assembly.system_prompt, assembly.user_prompt
    if memory_bridge is not None:
        memory_bridge.mark_turn_start()
    emit_fn(
        HookEvent.RUNTIME_BEFORE_TURN.value,
        task,
        state,
        {"turn_index": state.turn_index + 1, "agent_name": task.agent_name},
    )
    raw = _infer_with_retry(infer_fn, sys_p, usr_p, task)
    parsed = output_parser.parse(raw)
    final = _resolve_final_output(raw, parsed)
    state.last_system_prompt = sys_p
    state.last_user_prompt = usr_p
    state.last_raw_output = raw
    state.last_final_output = final
    state.turn_index += 1
    state.metadata["prompt_sections"] = assembly.sections
    state.metadata["context_budget"] = ctx_meta
    state.metadata["memory"] = mem_meta
    state.metadata["runtime_turn_result"] = parsed.model_dump(mode="json")
    state.conversation_history.append({"role": "user", "content": usr_p})
    state.conversation_history.append({"role": "assistant", "content": raw})
    return parsed, final


def _infer_with_retry(infer_fn: Any, sys_p: str, usr_p: str, task: Any) -> str:
    """Infer with transient error retry based on task metadata."""
    auto_retry = task.metadata.get("auto_retry_transient", True)
    max_retries = task.metadata.get("auto_retry_max", 2)
    if not auto_retry:
        return infer_fn(sys_p, usr_p)
    import logging

    _logger = logging.getLogger(__name__)
    last_exc: Exception | None = None
    for attempt in range(1, max_retries + 2):
        try:
            return infer_fn(sys_p, usr_p)
        except (TimeoutError, ConnectionError, OSError) as exc:
            last_exc = exc
            if attempt <= max_retries:
                _logger.warning(
                    "Transient inference error (attempt %d/%d): %s",
                    attempt,
                    max_retries + 1,
                    exc,
                )
                continue
            break
    raise last_exc


def _resolve_final_output(raw_output: str, turn_result: Any) -> str:
    """Extract final answer from raw output and parsed result."""
    if turn_result.final_answer is not None:
        return turn_result.final_answer.strip()
    return raw_output.strip()
