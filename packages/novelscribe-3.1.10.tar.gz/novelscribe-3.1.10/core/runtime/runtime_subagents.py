"""Runtime subagent execution helpers."""

from __future__ import annotations

from typing import Any

from .models import RuntimeOutcome, RuntimeState, RuntimeTask, SubagentResult, SubagentTask
from .runtime_lifecycle import RuntimeConfig
from .subagent_manager import SubagentManager


def execute_subagents_if_needed(
    task: RuntimeTask,
    state: RuntimeState,
    subagent_manager: SubagentManager | None,
    runtime_ref: Any,
) -> RuntimeOutcome | None:
    if task.metadata.get("is_subagent"):
        return None

    manager = subagent_manager or SubagentManager()
    parsed_tasks = manager.parse_tasks(task.metadata.get("subagents"))
    if not parsed_tasks:
        return None

    batch = manager.execute(
        parsed_tasks, runner=lambda sub_task: _run_subagent(sub_task, task, runtime_ref)
    )
    state.metadata["subagent_execution"] = batch.model_dump(mode="json")

    failed = [record for record in batch.records if not record.success]
    if failed:
        first_error = failed[0].error or "Subagent execution failed"
        return RuntimeOutcome(
            success=False,
            turns_executed=0,
            final_output=None,
            error=first_error,
            state=state,
        )

    if batch.teammate_notes:
        teammate_context = "\n".join(batch.teammate_notes)
        task.user_input = f"{task.user_input}\n\nSubagent teammate context:\n{teammate_context}"

    if batch.handoff_output:
        state.last_final_output = batch.handoff_output
        state.finished = True
        return RuntimeOutcome(
            success=True,
            turns_executed=0,
            final_output=batch.handoff_output,
            state=state,
        )

    return None


def _run_subagent(
    sub_task: SubagentTask, parent_task: RuntimeTask, runtime_ref: Any
) -> SubagentResult:
    from ._agent_runtime import AgentRuntime

    child_runtime = AgentRuntime(
        infer_fn=runtime_ref._infer_fn,
        config=RuntimeConfig(
            prompt_assembler=runtime_ref._prompt_assembler,
            output_parser=runtime_ref._output_parser,
            context_bus=runtime_ref._context_bus,
            memory_bridge=runtime_ref._memory_bridge,
            tool_registry=runtime_ref._tool_registry,
            tool_executor=runtime_ref._tool_executor,
            guardrail_engine=runtime_ref._guardrail_engine,
            turn_checkpoint_store=runtime_ref._turn_checkpoint_store,
            verification_suite=runtime_ref._verification_suite,
            subagent_manager=None,
            hook_event_bus=runtime_ref._hook_event_bus,
            auto_feedback_enabled=runtime_ref._auto_feedback_enabled,
            max_feedback_rounds=runtime_ref._max_feedback_rounds,
        ),
    )
    merged_metadata = dict(parent_task.metadata)
    merged_metadata.update(sub_task.metadata)
    merged_metadata.update(
        {
            "is_subagent": True,
            "parent_task_id": parent_task.task_id,
            "subagent_name": sub_task.name,
        }
    )
    child_task = RuntimeTask(
        user_input=sub_task.user_input,
        system_prompt=sub_task.system_prompt or parent_task.system_prompt,
        agent_name=parent_task.agent_name,
        provider=parent_task.provider,
        llm_config=dict(parent_task.llm_config),
        tool_definitions=list(parent_task.tool_definitions),
        memory_query=parent_task.memory_query,
        max_turns=sub_task.max_turns,
        metadata=merged_metadata,
    )
    child_state = RuntimeState()
    outcome = child_runtime.run_turn_loop(child_task, child_state)
    return SubagentResult(
        name=sub_task.name,
        mode=sub_task.mode,
        task_id=child_task.task_id,
        success=outcome.success,
        turns_executed=outcome.turns_executed,
        final_output=outcome.final_output,
        error=outcome.error,
        replay_events=list(child_state.conversation_history),
    )
