"""Runtime guardrail validation helpers."""

from __future__ import annotations

from .guardrails import GuardrailEngine
from .models import RuntimeOutcome, RuntimeState, RuntimeTask
from .runtime_lifecycle import RuntimeErrorCategory, build_error_payload


def validate_input_guardrail(
    guardrail_engine: GuardrailEngine | None,
    task: RuntimeTask,
    state: RuntimeState,
) -> RuntimeOutcome | None:
    if guardrail_engine is None:
        return None
    decision = guardrail_engine.validate_input(task.user_input)
    if decision.allowed:
        state.metadata["input_guardrail"] = {"allowed": True}
        return None

    state.metadata["input_guardrail"] = {
        "allowed": False,
        "decision": decision.model_dump(mode="json"),
    }
    state.metadata["error"] = build_error_payload(
        message=decision.reason,
        category=RuntimeErrorCategory.USER_FIXABLE,
        retryable=False,
    )
    return RuntimeOutcome(
        success=False,
        turns_executed=0,
        final_output=None,
        error=decision.reason,
        state=state,
    )


def validate_output_guardrail(
    guardrail_engine: GuardrailEngine | None,
    final_output: str,
    state: RuntimeState,
    turns_executed: int,
) -> RuntimeOutcome | None:
    if guardrail_engine is None:
        return None
    decision = guardrail_engine.validate_output(final_output)
    if decision.allowed:
        state.metadata["output_guardrail"] = {"allowed": True}
        return None

    state.metadata["output_guardrail"] = {
        "allowed": False,
        "decision": decision.model_dump(mode="json"),
    }
    state.metadata["error"] = build_error_payload(
        message=decision.reason,
        category=RuntimeErrorCategory.USER_FIXABLE,
        retryable=False,
    )
    return RuntimeOutcome(
        success=False,
        turns_executed=turns_executed,
        final_output=None,
        error=decision.reason,
        state=state,
    )
