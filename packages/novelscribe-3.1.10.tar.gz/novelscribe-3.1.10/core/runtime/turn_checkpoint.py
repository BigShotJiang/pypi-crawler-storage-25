"""Turn-level checkpoint storage for Runtime execution."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from pydantic import BaseModel

from .models import RuntimeState, RuntimeTask


class RuntimeTurnCheckpoint(BaseModel):
    """Persisted snapshot of runtime state at turn granularity."""

    task_id: str
    timestamp: str
    turn_index: int
    phase: str
    task: RuntimeTask
    state: RuntimeState


class RuntimeTurnCheckpointStore:
    """Filesystem store for runtime turn-level snapshots."""

    def __init__(self, checkpoint_dir: Path, max_checkpoints: int = 50):
        self.checkpoint_dir = checkpoint_dir
        self.max_checkpoints = max_checkpoints

    def save(self, task: RuntimeTask, state: RuntimeState, phase: str) -> RuntimeTurnCheckpoint:
        """Save a checkpoint snapshot for current turn state."""
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        checkpoint = RuntimeTurnCheckpoint(
            task_id=task.task_id,
            timestamp=datetime.now(timezone.utc).isoformat(),
            turn_index=state.turn_index,
            phase=phase,
            task=task,
            state=state,
        )
        filename = self._checkpoint_filename(task.task_id, state.turn_index, phase)
        target = self.checkpoint_dir / filename
        target.write_text(checkpoint.model_dump_json(indent=2))
        self.prune_old_checkpoints(task.task_id)
        return checkpoint

    def prune_old_checkpoints(self, task_id: str | None = None) -> int:
        """Remove oldest checkpoints beyond max_checkpoints.

        Args:
            task_id: If provided, prune only checkpoints for this task.
                     If None, prune across all tasks.

        Returns:
            Number of checkpoints pruned.
        """
        if not self.checkpoint_dir.exists():
            return 0

        if task_id:
            all_files = sorted(self._list_task_checkpoints(task_id))
        else:
            all_files = sorted(f for f in self.checkpoint_dir.glob("runtime_turn_*.json"))

        if len(all_files) <= self.max_checkpoints:
            return 0

        to_remove = all_files[: len(all_files) - self.max_checkpoints]
        removed = 0
        for f in to_remove:
            try:
                f.unlink()
                removed += 1
            except OSError:
                pass
        return removed

    def load_latest_state(self, task_id: str) -> RuntimeState | None:
        """Load latest checkpoint state for a task."""
        checkpoints = self._list_task_checkpoints(task_id)
        if not checkpoints:
            return None
        latest = checkpoints[-1]
        data = json.loads(latest.read_text())
        return RuntimeState(**data["state"])

    def _list_task_checkpoints(self, task_id: str) -> list[Path]:
        """List checkpoint files for task ordered by filename."""
        if not self.checkpoint_dir.exists():
            return []
        pattern = f"runtime_turn_{task_id}_*.json"
        return sorted(self.checkpoint_dir.glob(pattern))

    @staticmethod
    def _checkpoint_filename(task_id: str, turn_index: int, phase: str) -> str:
        """Build deterministic checkpoint filename."""
        safe_phase = phase.replace(" ", "_")
        return f"runtime_turn_{task_id}_{turn_index:04d}_{safe_phase}.json"
