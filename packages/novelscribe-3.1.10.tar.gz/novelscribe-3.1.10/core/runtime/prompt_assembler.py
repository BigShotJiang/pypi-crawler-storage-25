"""Prompt assembly component for runtime turn execution."""

from __future__ import annotations

from pydantic import BaseModel, Field

from .models import RuntimeState, RuntimeTask


class PromptAssemblyResult(BaseModel):
    """Structured prompt assembly output."""

    system_prompt: str
    user_prompt: str
    sections: list[str] = Field(default_factory=list)


class PromptAssembler:
    """Assemble runtime prompts with fixed section ordering.

    Ordering:
        system -> tools -> memory -> history -> latest task
    """

    def assemble(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        memory_context: str = "",
        history_context: str = "",
    ) -> PromptAssemblyResult:
        """Assemble system/user prompts for one runtime turn."""
        sections = ["tools", "memory", "history", "latest_task"]
        parts: list[str] = []

        parts.append("## Tools")
        if task.tool_definitions:
            for idx, tool in enumerate(task.tool_definitions, start=1):
                name = tool.get("name", f"tool_{idx}")
                description = tool.get("description", "")
                parts.append(f"{idx}. {name}: {description}".strip())
        else:
            parts.append("(none)")

        parts.append("\n## Memory")
        parts.append(memory_context.strip() if memory_context.strip() else "(none)")

        parts.append("\n## History")
        if history_context.strip():
            parts.append(history_context.strip())
        elif state.conversation_history:
            recent = state.conversation_history[-6:]
            for item in recent:
                role = item.get("role", "unknown")
                content = item.get("content", "")
                parts.append(f"- {role}: {content}")
        else:
            parts.append("(none)")

        parts.append("\n## Latest Task")
        parts.append(task.user_input)

        return PromptAssemblyResult(
            system_prompt=task.system_prompt,
            user_prompt="\n".join(parts).strip(),
            sections=sections,
        )
