"""Post-turn gate — output guardrail, verification, and feedback retry.

Extracted from AgentRuntime to allow independent testing of the post-turn phase.

Interface:
    run_post_turn_gate(task, state, final_output, turns_executed, feedback_rounds,
                       guardrail_engine, verification_suite, auto_feedback_enabled,
                       max_feedback_rounds, checkpoint_store, emit_fn)
    → RuntimeOutcome | None | tuple[type[CONTINUE_SENTINEL], int]
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from core.hooks import HookEvent

if TYPE_CHECKING:
    from ._callbacks import CONTINUE_SENTINEL


def run_post_turn_gate(
    task: Any,
    state: Any,
    final_output: str,
    turns_executed: int,
    feedback_rounds: int,
    guardrail_engine: Any,
    verification_suite: Any,
    auto_feedback_enabled: bool,
    max_feedback_rounds: int,
    checkpoint_store: Any,
    emit_fn: Any,
) -> Any | None | tuple[type["CONTINUE_SENTINEL"], int]:
    """Run post-turn checks: output guardrail, verification, and feedback retry.

    Returns:
        None → proceed (turn complete)
        RuntimeOutcome → short-circuit with failure
        (CONTINUE_SENTINEL, feedback_rounds) → continue loop with modified task
    """
    from ._callbacks import CONTINUE_SENTINEL
    from .runtime_guardrails import validate_output_guardrail
    from .runtime_lifecycle import save_checkpoint

    state.last_final_output = final_output
    og = validate_output_guardrail(guardrail_engine, final_output, state, turns_executed)
    if og is not None:
        emit_fn(
            HookEvent.RUNTIME_TURN_FAILED.value,
            task,
            state,
            {"error": og.error or "Output guardrail blocked", "turn_index": state.turn_index},
        )
        return og
    if verification_suite is None:
        return None
    bundle = verification_suite.run_hooks(task=task, state=state, final_output=final_output)
    state.metadata["verification"] = bundle.model_dump(mode="json")
    if bundle.passed:
        return None
    if auto_feedback_enabled and feedback_rounds < max_feedback_rounds:
        feedback_prompt = verification_suite.build_feedback_prompt(bundle)
        task.user_input = f"{task.user_input}\n\n{feedback_prompt}"
        feedback_rounds += 1
        state.metadata["feedback_rounds"] = feedback_rounds
        if checkpoint_store is not None:
            save_checkpoint(checkpoint_store, task, state, "verification_retry")
        return (CONTINUE_SENTINEL, feedback_rounds)
    emit_fn(
        HookEvent.RUNTIME_TURN_FAILED.value,
        task,
        state,
        {
            "error": "Verification failed and exceeded feedback retry policy",
            "turn_index": state.turn_index,
            "verification": state.metadata.get("verification", {}),
        },
    )
    from .models import RuntimeOutcome

    return RuntimeOutcome(
        success=False,
        turns_executed=turns_executed,
        final_output=state.last_final_output or None,
        error="Verification failed and exceeded feedback retry policy",
        state=state,
    )
