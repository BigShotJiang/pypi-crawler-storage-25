"""Error handling paths — max-turns exhaustion and exception handling.

Extracted from AgentRuntime. These are stateless error paths that construct
RuntimeOutcome and emit failure events.

Functions:
    fail_max_turns(task, state, turns_executed, emit_fn) → RuntimeOutcome
    fail_exception(exc, task, state, turns_executed, emit_fn) → RuntimeOutcome
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from core.hooks import HookEvent

if TYPE_CHECKING:
    from .models import RuntimeOutcome


_logger = logging.getLogger(__name__)


def fail_max_turns(
    task: Any,
    state: Any,
    turns_executed: int,
    emit_fn: Any,
) -> "RuntimeOutcome":
    """Handle max-turns exceeded without finished flag."""
    from .models import RuntimeOutcome

    emit_fn(
        HookEvent.RUNTIME_TURN_FAILED.value,
        task,
        state,
        {"error": "Runtime loop exceeded max turns", "turn_index": state.turn_index},
    )
    return RuntimeOutcome(
        success=False,
        turns_executed=turns_executed,
        final_output=state.last_final_output or None,
        error="Runtime loop exceeded max turns without final answer",
        state=state,
    )


def fail_exception(
    exc: Exception,
    task: Any,
    state: Any,
    turns_executed: int,
    emit_fn: Any,
) -> "RuntimeOutcome":
    """Handle unexpected exception during loop."""
    from .models import RuntimeOutcome
    from .runtime_lifecycle import build_error_payload, classify_exception

    _logger.error("Runtime turn loop failed: %s", exc)
    cat, retryable = classify_exception(exc)
    state.metadata["error"] = build_error_payload(
        message=str(exc), category=cat, retryable=retryable
    )
    emit_fn(
        HookEvent.RUNTIME_TURN_FAILED.value,
        task,
        state,
        {"error": str(exc), "turn_index": state.turn_index, "error_category": cat.value},
    )
    return RuntimeOutcome(
        success=False,
        turns_executed=turns_executed,
        final_output=state.last_final_output or None,
        error=str(exc),
        state=state,
    )
