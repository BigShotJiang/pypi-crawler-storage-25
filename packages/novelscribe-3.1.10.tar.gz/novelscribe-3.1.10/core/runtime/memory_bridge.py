"""Memory bridge for runtime injection and writeback."""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone
from uuid import uuid4

from core.memory.knowledge_graph import KnowledgeGraph
from core.memory.models import ConversationEvent, GenerationOutcome

from .models import RuntimeState, RuntimeTask


class MemoryBridge:
    """Bridge runtime loop with MemoryBus read/write operations."""

    def __init__(self, memory_bus) -> None:
        self._memory_bus = memory_bus
        self._logger = logging.getLogger(__name__)
        self._turn_start_time: float = 0.0

    def mark_turn_start(self) -> None:
        """Record the start time of a turn for generation timing."""
        self._turn_start_time = time.monotonic()

    def build_memory_context(self, task: RuntimeTask, state: RuntimeState) -> tuple[str, dict]:
        """Build memory context from short-term and long-term memory."""
        metadata: dict = {"conversation_tokens": 0, "wiki_hits": 0, "insights_injected": 0}
        if self._memory_bus is None:
            return "", metadata

        sections: list[str] = []
        try:
            learning = self._memory_bus.get_learning()
            insights_text = learning.to_context_string(agent_name=task.agent_name, max_tokens=400)
            if insights_text and isinstance(insights_text, str):
                sections.append("### Learned Insights")
                sections.append(insights_text.rstrip())
                metadata["insights_injected"] = insights_text.count("\n") + 1
        except Exception as exc:
            self._logger.debug("Failed to inject learning insights: %s", exc)

        try:
            graph = self._memory_bus.get_graph()
            if graph is not None and isinstance(graph, KnowledgeGraph):
                issues = graph.check_consistency()
                high_issues = [i for i in issues if i.severity in ("error", "warning")]
                if high_issues:
                    warning_lines = []
                    for issue in high_issues[:5]:
                        warning_lines.append(f"- [{issue.severity.upper()}] {issue.description}")
                    sections.append("### Consistency Warnings")
                    sections.append("\n".join(warning_lines))
                    metadata["consistency_warnings"] = len(high_issues)
        except Exception as exc:
            self._logger.debug("Failed to run consistency checks: %s", exc)

        try:
            graph = self._memory_bus.get_graph()
            if graph is not None and isinstance(graph, KnowledgeGraph):
                graph_ctx = self._get_graph_context(task, graph, max_tokens=500)
                if graph_ctx and isinstance(graph_ctx, str):
                    sections.append("### Entity Context")
                    sections.append(graph_ctx)
                    metadata["graph_entities"] = graph_ctx.count("\n## ") + (
                        1 if graph_ctx.startswith("## ") else 0
                    )
        except Exception as exc:
            self._logger.debug("Failed to inject graph context: %s", exc)

        try:
            conversations = self._memory_bus.get_conversations()
            short_term = conversations.to_context_string(max_tokens=300)
            if short_term is not None and not isinstance(short_term, str):
                short_term = str(short_term)
            if short_term:
                sections.append("### Short-term Memory")
                sections.append(short_term)
                metadata["conversation_tokens"] = len(short_term) // 4
        except Exception as exc:
            self._logger.debug("Failed to build short-term memory context: %s", exc)

        try:
            query = task.memory_query or task.user_input
            long_term = self._memory_bus.retrieve(
                agent_name=task.agent_name,
                query=query,
                max_tokens=600,
            )
            if not isinstance(long_term, list):
                long_term = []
            if long_term:
                sections.append("### Long-term Memory")
                metadata["wiki_hits"] = len(long_term)
                for item in long_term[:5]:
                    if not isinstance(item, dict):
                        continue
                    title = item.get("title", "memory")
                    content = item.get("content", item.get("summary", ""))
                    if content is not None and not isinstance(content, str):
                        content = str(content)
                    if content:
                        sections.append(f"- {title}: {content}")
        except Exception as exc:
            self._logger.debug("Failed to build long-term memory context: %s", exc)

        return "\n".join(sections).strip(), metadata

    def writeback(self, task: RuntimeTask, state: RuntimeState, final_output: str) -> None:
        """Write runtime turn results back into memory systems."""
        if self._memory_bus is None or not final_output:
            return

        runtime_meta = {"task_id": task.task_id, "source": "runtime"}
        runtime_meta.update(task.metadata)

        try:
            self._memory_bus.index(
                artifact_type="summary",
                content=final_output,
                metadata=runtime_meta,
            )
        except Exception as exc:
            self._logger.debug("Memory index writeback failed: %s", exc)

        try:
            conversations = self._memory_bus.get_conversations()
            session_id = state.metadata.get("runtime_session_id")
            project_name = task.metadata.get("project_name", "runtime_project")
            if not session_id:
                session_id = conversations.start_session(project=project_name, mode="runtime")
                state.metadata["runtime_session_id"] = session_id

            event = ConversationEvent(
                event_id=f"{task.task_id}-{state.turn_index}",
                session_id=session_id,
                timestamp=datetime.now(timezone.utc),
                event_type="agent_response",
                agent_name=task.agent_name,
                content=final_output,
                metadata={**runtime_meta, "event_uuid": str(uuid4())},
            )
            conversations.record_event(event)
        except Exception as exc:
            self._logger.debug("Conversation writeback failed: %s", exc)

        self._record_generation_outcome(task, state, final_output)
        self._extract_entities_from_output(task, final_output)

    def _extract_entities_from_output(self, task: RuntimeTask, final_output: str) -> None:
        """Extract entities from generated content to keep the knowledge graph current."""
        try:
            extractor = self._memory_bus.get_extractor()
            if extractor is not None and hasattr(extractor, "extract_and_add"):
                extractor.extract_and_add(final_output, source_type="text")
        except Exception as exc:
            self._logger.debug("Post-generation entity extraction failed: %s", exc)

    def _get_graph_context(self, task: RuntimeTask, graph, max_tokens: int = 500) -> str:
        """Build entity context from the knowledge graph for relevant entities."""
        candidate_names = self._extract_candidate_entity_names(task)
        entity_ids = []
        for name in candidate_names:
            node = graph.find_by_name(name)
            if node is not None:
                entity_ids.append(node.node_id)
        if not entity_ids:
            return ""
        return graph.to_context_string(entity_ids, max_tokens=max_tokens)

    def _extract_candidate_entity_names(self, task: RuntimeTask) -> list[str]:
        """Extract candidate entity names from task metadata and user input."""
        names: list[str] = []
        chapter_plan = task.metadata.get("chapter_plan", "")
        if isinstance(chapter_plan, str) and chapter_plan:
            names.extend(self._split_names(chapter_plan))
        characters = task.metadata.get("characters", [])
        if isinstance(characters, list):
            for c in characters:
                if isinstance(c, str):
                    names.append(c)
                elif isinstance(c, dict):
                    n = c.get("name", "")
                    if n:
                        names.append(n)
        for source in (task.user_input, task.memory_query or ""):
            if source:
                names.extend(self._split_names(source))
        seen = set()
        unique = []
        for n in names:
            key = n.lower().strip()
            if key and key not in seen and len(key) > 1:
                seen.add(key)
                unique.append(n.strip())
        return unique[:20]

    @staticmethod
    def _split_names(text: str) -> list[str]:
        """Split text into candidate name fragments."""
        import re

        parts = re.split(r"[,;|\n]", text)
        result = []
        for part in parts:
            cleaned = part.strip().strip("\"'")
            if cleaned and 1 < len(cleaned) < 60:
                result.append(cleaned)
        return result

    def _record_generation_outcome(
        self, task: RuntimeTask, state: RuntimeState, final_output: str
    ) -> None:
        """Record generation outcome for the learning feedback loop."""
        try:
            learning = self._memory_bus.get_learning()
        except Exception:
            return

        verification = state.metadata.get("verification", {})
        if isinstance(verification, dict):
            verification_passed = verification.get("passed", True)
            verification_score = verification.get("score", 0.0)
            if isinstance(verification_score, str):
                verification_score = 0.0
        else:
            verification_passed = True
            verification_score = 0.0

        generation_time = 0.0
        if self._turn_start_time > 0:
            generation_time = time.monotonic() - self._turn_start_time

        session_id = state.metadata.get("runtime_session_id", task.task_id)
        if not isinstance(session_id, str):
            session_id = task.task_id

        outcome = GenerationOutcome(
            outcome_id=str(uuid4()),
            session_id=session_id,
            phase=task.metadata.get("phase", task.agent_name),
            agent_name=task.agent_name,
            chapter_number=task.metadata.get("chapter_number"),
            timestamp=datetime.now(timezone.utc),
            verification_passed=verification_passed,
            verification_score=float(verification_score),
            issues_found=verification.get("issues", []) if isinstance(verification, dict) else [],
            edit_rounds=state.metadata.get("feedback_rounds", 0),
            tokens_used=len((state.last_user_prompt or "") + (state.last_final_output or "")) // 4,
            generation_time_seconds=round(generation_time, 3),
            model_used=task.metadata.get("model", task.provider),
            temperature=task.llm_config.get("temperature", 0.7),
            output_word_count=len(final_output.split()),
            context_tokens_used=state.metadata.get("context_budget", {}).get("original_tokens", 0),
        )
        learning.record_outcome(outcome)
        self._record_template_outcome(task, state, session_id, verification_score)
        self._logger.debug(
            "Recorded generation outcome for %s (passed=%s, score=%.2f)",
            task.agent_name,
            verification_passed,
            verification_score,
        )

    def _record_template_outcome(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        session_id: str,
        verification_score: float,
    ) -> None:
        """Link generation outcome to the last template selection."""
        try:
            tracker = getattr(self._memory_bus, "_template_outcome_tracker", None)
            if tracker is None:
                return
            genre = task.metadata.get("genre", "")
            phase_kind = task.metadata.get("phase_kind", "")
            tracker.record_outcome(
                session_id=session_id,
                verification_score=float(verification_score),
                genre=genre,
                phase_kind=phase_kind,
            )
        except Exception:
            pass
