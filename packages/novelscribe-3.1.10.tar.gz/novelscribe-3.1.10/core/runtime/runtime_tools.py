"""Runtime tool call execution helpers."""

from __future__ import annotations

from typing import Any

from .guardrails import GuardrailEngine
from .models import RuntimeState, RuntimeTask, RuntimeTurnResult
from .runtime_lifecycle import RuntimeErrorCategory, build_error_payload
from .tool_protocol import ToolExecutor, ToolRegistry


def execute_tool_calls(
    turn_result: RuntimeTurnResult,
    task: RuntimeTask,
    state: RuntimeState,
    tool_executor: ToolExecutor | None,
    guardrail_engine: GuardrailEngine | None,
    tool_registry: ToolRegistry | None,
) -> list[dict[str, Any]]:
    if tool_executor is None:
        return [
            {
                "name": call.name,
                "success": False,
                "error": "No tool executor configured",
            }
            for call in turn_result.tool_calls
        ]

    results: list[dict[str, Any]] = []
    context = {
        "project_name": task.metadata.get("project_name", ""),
        "task_id": task.task_id,
        "turn_index": state.turn_index,
    }
    for call in turn_result.tool_calls:
        if guardrail_engine is not None and tool_registry is not None:
            spec = tool_registry.get(call.name)
            permission = spec.permission if spec is not None else "unknown"
            decision = guardrail_engine.validate_tool_call(call.name, permission)
            if not decision.allowed:
                result_payload = {
                    "name": call.name,
                    "success": False,
                    "error": decision.reason,
                    "error_category": RuntimeErrorCategory.USER_FIXABLE.value,
                    "audit": {"status": "blocked_by_guardrail", "guardrail": decision.metadata},
                }
                results.append(result_payload)
                state.metadata["error"] = build_error_payload(
                    message=decision.reason,
                    category=RuntimeErrorCategory.USER_FIXABLE,
                    retryable=False,
                )
                state.metadata["tool_guardrail"] = {
                    "allowed": False,
                    "decision": decision.model_dump(mode="json"),
                }
                continue

        result = tool_executor.execute(call, context=context)
        result_payload = result.model_dump(mode="json")
        results.append(result_payload)
        if not result.success:
            state.metadata["error"] = build_error_payload(
                message=result.error or "Tool call failed",
                category=RuntimeErrorCategory(
                    result.error_category or RuntimeErrorCategory.USER_FIXABLE.value
                ),
                retryable=False,
            )
        else:
            state.metadata["tool_guardrail"] = {"allowed": True}
    return results
