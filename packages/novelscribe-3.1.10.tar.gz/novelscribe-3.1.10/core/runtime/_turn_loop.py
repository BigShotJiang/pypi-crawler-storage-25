"""Turn loop skeleton extracted from AgentRuntime.

This module defines the minimal iteration structure of the runtime turn loop.
All business logic is delegated to injected callbacks, making the loop
independently testable.

Interface:
    TurnLoopEngine.execute(task, state, callbacks) → RuntimeOutcome

Callback protocol defined in _callbacks.py.
"""

from __future__ import annotations

import logging
from typing import Any

from core.hooks import HookEvent

from ._callbacks import CONTINUE_SENTINEL, TurnLoopCallbacks
from .models import RuntimeOutcome, RuntimeState, RuntimeTask

_logger = logging.getLogger(__name__)


class TurnLoopEngine:
    """Minimal turn loop skeleton.

    Extracts the iteration structure from AgentRuntime so it can be tested
    independently of the business logic (pre/post checks, tool handling, etc.).

    Design:
        - The loop owns only: max_turns iteration, checkpointing, hook emission,
          finished flag management, and error routing.
        - All business logic is in TurnLoopCallbacks, injected at construction.
        - State is mutated in-place; RuntimeOutcome is returned.
        - Checkpoint store is owned here (created lazily, persisted across turns).
    """

    def __init__(
        self,
        callbacks: "TurnLoopCallbacks",
        checkpoint_store: Any | None = None,
    ) -> None:
        self._callbacks = callbacks
        self._checkpoint_store = checkpoint_store

    def execute(self, task: RuntimeTask, state: RuntimeState) -> RuntimeOutcome:
        turns_executed = 0
        feedback_rounds = 0
        try:
            if state.turn_index == 0 and task.metadata.get("resume_from_checkpoint"):
                resumed = self._callbacks.load_latest_turn_state(task.task_id)
                if resumed is not None:
                    state = resumed

            for _ in range(max(task.max_turns, 1)):
                if state.finished:
                    break

                pre = self._callbacks.run_pre_turn(task, state)
                if pre is not None:
                    return pre
                self._callbacks.save_checkpoint("turn_start", task, state)

                turn_result, final_output = self._callbacks.execute_turn(task, state)
                turns_executed += 1

                if turn_result.tool_calls:
                    tool_outcome = self._callbacks.handle_tool_calls(
                        turn_result, task, state, turns_executed
                    )
                    if tool_outcome is not None:
                        return tool_outcome
                    continue

                if turn_result.recoverable_error:
                    return self._callbacks.fail_recoverable(
                        turn_result, state, turns_executed, task
                    )

                post = self._callbacks.run_post_turn(
                    task, state, final_output, turns_executed, feedback_rounds
                )
                if post is not None:
                    if isinstance(post, tuple) and post[0] is CONTINUE_SENTINEL:
                        feedback_rounds = post[1]
                        continue
                    return post

                self._callbacks.write_memory(task, state, final_output)
                self._callbacks.save_checkpoint("turn_complete", task, state)
                self._callbacks.emit(
                    HookEvent.RUNTIME_AFTER_TURN.value,
                    task,
                    state,
                    {
                        "turn_index": state.turn_index,
                        "final_output": final_output,
                        "verification": state.metadata.get("verification", {}),
                    },
                )
                state.finished = True

            if not state.finished:
                return self._callbacks.fail_max_turns(task, state, turns_executed)
            return RuntimeOutcome(
                success=True,
                turns_executed=turns_executed,
                final_output=state.last_final_output or None,
                state=state,
            )
        except Exception as exc:
            return self._callbacks.fail_exception(exc, task, state, turns_executed)
