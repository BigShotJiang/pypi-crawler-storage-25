"""Hybrid decision authority - human + AI shared control."""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Optional


class AuthorityLevel(str, Enum):
    HUMAN_ONLY = "human_only"
    HUMAN_FIRST = "human_first"
    AI_CAN_PROCEED = "ai_can_proceed"
    AI_ONLY = "ai_only"


class AutoApproveReason(str, Enum):
    HIGH_CONFIDENCE = "high_confidence"
    TIMEOUT = "timeout"
    EXPLICIT_REQUEST = "explicit_request"
    GRADUATED_AUTHORITY = "graduated_authority"


@dataclass
class AuthorityConfig:
    level: AuthorityLevel = AuthorityLevel.HUMAN_FIRST
    confidence_threshold: float = 0.90
    timeout_hours: Optional[float] = 24.0
    escalate_on_reject: bool = True
    max_auto_approves_per_session: int = 5


@dataclass
class GraduatedAuthority:
    human_approvals: int = 0
    human_modifications: int = 0
    human_rejections: int = 0
    auto_approves: int = 0
    checkpoints_passed: int = 0

    @property
    def trust_score(self) -> float:
        if self.checkpoints_passed == 0:
            return 0.5
        human_accuracy = (self.human_approvals + self.human_modifications) / self.checkpoints_passed
        consistency = 1.0 - (
            abs(self.human_rejections - self.auto_approves) / max(1, self.checkpoints_passed)
        )
        return min(1.0, (human_accuracy * 0.6 + consistency * 0.4))

    def should_auto_approve(
        self, confidence: float, config: AuthorityConfig
    ) -> tuple[bool, AutoApproveReason]:
        if config.level == AuthorityLevel.HUMAN_ONLY:
            return False, AutoApproveReason.EXPLICIT_REQUEST
        if config.level == AuthorityLevel.HUMAN_FIRST and self.checkpoints_passed < 3:
            return False, AutoApproveReason.GRADUATED_AUTHORITY
        if confidence >= config.confidence_threshold:
            if self.auto_approves < config.max_auto_approves_per_session:
                return True, AutoApproveReason.HIGH_CONFIDENCE
        return False, AutoApproveReason.GRADUATED_AUTHORITY

    def record_approval(self, was_auto: bool = False):
        self.checkpoints_passed += 1
        if was_auto:
            self.auto_approves += 1
        else:
            self.human_approvals += 1

    def record_modification(self):
        self.checkpoints_passed += 1
        self.human_modifications += 1

    def record_rejection(self):
        self.checkpoints_passed += 1
        self.human_rejections += 1


@dataclass
class CheckpointDeadline:
    checkpoint_id: str
    created_at: datetime
    deadline: Optional[datetime] = None
    reminder_sent: bool = False
    escalation_triggered: bool = False
    extensions_granted: int = 0

    def __post_init__(self):
        if self.deadline is None and self.created_at is not None:
            self.deadline = self.created_at + timedelta(hours=24)

    @property
    def is_expired(self) -> bool:
        if self.deadline is None:
            return False
        return datetime.now() > self.deadline

    @property
    def time_remaining(self) -> Optional[timedelta]:
        if self.deadline is None:
            return None
        remaining = self.deadline - datetime.now()
        return remaining if remaining.total_seconds() > 0 else timedelta(0)

    def extend(self, hours: float) -> bool:
        if self.extensions_granted >= 3:
            return False
        if self.deadline is None:
            self.deadline = datetime.now() + timedelta(hours=hours)
        else:
            self.deadline += timedelta(hours=hours)
        self.extensions_granted += 1
        return True


@dataclass
class CheckpointNotification:
    notification_id: str
    checkpoint_id: str
    event_type: str
    message: str
    created_at: datetime = field(default_factory=lambda: datetime.now())
    read: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)
