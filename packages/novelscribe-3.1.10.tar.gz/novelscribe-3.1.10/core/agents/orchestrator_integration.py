"""Agent system integration for orchestrator."""

import logging
from pathlib import Path
from typing import Any, Dict

from core.agents.executor import AgentExecutor
from core.agents.registry import AgentRegistry
from core.storage import StorageBackend


class AgentSystemIntegration:
    """Integration layer for agent system with orchestrator."""

    def __init__(
        self,
        agents_dir: str | Path,
        llm_client,
        storage: StorageBackend,
        work_dir: str | Path = None,
        context_bus=None,
    ):
        """Initialize agent system integration.

        Args:
            agents_dir: Directory containing agent definitions
            llm_client: LLM client for agent execution
            storage: Storage backend for file operations
            work_dir: Working directory for file operations
            context_bus: Optional ContextBus for context assembly
        """
        self.registry = AgentRegistry(agents_dir)
        self.executor = AgentExecutor(llm_client, storage, work_dir, context_bus=context_bus)
        self.logger = logging.getLogger("agent_system")

    def execute_agent_step(
        self,
        agent_name: str,
        project_name: str,
        step_context: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute an agent as part of a workflow step.

        Args:
            agent_name: Name of agent to execute
            project_name: Name of project
            step_context: Step context with inputs and previous outputs
            config: LLM configuration

        Returns:
            Step execution result with outputs
        """
        agent = self.registry.get_agent(agent_name)

        if not agent:
            raise ValueError(f"Agent not found: {agent_name}")

        missing = self.registry.validate_dependencies(agent_name)
        if missing:
            self.logger.warning(f"Agent {agent_name} has missing dependencies: {missing}")

        provider = config.get("provider", "openai")

        if self.executor.context_bus is None:
            from core.context.bus import ContextBus

            self.executor.context_bus = ContextBus.simple(
                llm_client=self.executor.llm_client,
            )

        result = self.executor.execute_with_bus(
            agent=agent,
            provider=provider,
            model_config=config,
            project_name=project_name,
        )

        return {
            "agent_name": result.agent_name,
            "success": result.success,
            "output": result.output,
            "output_files": result.output_files,
            "error": result.error,
            "metadata": result.metadata,
        }

    def list_available_agents(self) -> Dict[str, str]:
        """Get summary of available agents.

        Returns:
            Dictionary mapping agent names to descriptions
        """
        return self.registry.list_agents()

    def get_agent_info(self, agent_name: str) -> Dict[str, Any]:
        """Get detailed information about an agent.

        Args:
            agent_name: Name of agent

        Returns:
            Agent information dictionary
        """
        agent = self.registry.get_agent(agent_name)

        if not agent:
            return {}

        return {
            "name": agent.name,
            "version": agent.version,
            "description": agent.description,
            "category": agent.category.value,
            "input_schema": agent.input_schema,
            "output_schema": agent.output_schema,
            "dependencies": agent.dependencies,
        }

    def validate_workflow_agents(self, agent_names: list) -> Dict[str, list]:
        """Validate all agents in a workflow.

        Args:
            agent_names: List of agent names to validate

        Returns:
            Dictionary with validation results
        """
        missing_agents = []
        agents_with_missing_deps = {}

        for agent_name in agent_names:
            if not self.registry.agent_exists(agent_name):
                missing_agents.append(agent_name)
            else:
                missing_deps = self.registry.validate_dependencies(agent_name)
                if missing_deps:
                    agents_with_missing_deps[agent_name] = missing_deps

        return {"missing_agents": missing_agents, "missing_dependencies": agents_with_missing_deps}
