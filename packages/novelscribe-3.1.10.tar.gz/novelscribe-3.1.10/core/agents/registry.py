"""Agent registry for managing available agents."""

from pathlib import Path
from typing import Dict, List, Optional

from core.agents.agent import Agent, AgentCategory
from core.agents.loader import AgentLoader
from core.i18n import LanguageCode


class AgentRegistry:
    """Registry for managing available agents."""

    def __init__(self, agents_dir: str | Path, language: Optional[LanguageCode] = None):
        """Initialize agent registry.

        Args:
            agents_dir: Directory containing agent definitions
            language: Language code for agent files (default: en for backward compatibility)
        """
        self.agents_dir = Path(agents_dir)
        self.language = language or LanguageCode.EN
        self.loader = AgentLoader(agents_dir, language=self.language)
        self._agents: Dict[str, Agent] = {}
        self._load_agents()

    def _load_agents(self):
        """Load all agents from directory."""
        agents = self.loader.load_all_agents()

        for agent in agents:
            self._agents[agent.name] = agent

    def reload_all(self):
        """Reload all agents from directory."""
        self._agents.clear()
        self._load_agents()

    def reload_agent(self, agent_name: str) -> Optional[Agent]:
        """Reload a specific agent.

        Args:
            agent_name: Name of agent to reload

        Returns:
            Reloaded agent if found, None otherwise
        """
        agent = self.loader.reload_agent(agent_name)

        if agent:
            self._agents[agent.name] = agent

        return agent

    def get_agent(self, agent_name: str) -> Optional[Agent]:
        """Get agent by name.

        Args:
            agent_name: Name of agent to retrieve

        Returns:
            Agent if found, None otherwise
        """
        return self._agents.get(agent_name)

    def get_all_agents(self) -> List[Agent]:
        """Get all registered agents.

        Returns:
            List of all agents
        """
        return list(self._agents.values())

    def get_agents_by_category(self, category: AgentCategory) -> List[Agent]:
        """Get agents by category.

        Args:
            category: Agent category

        Returns:
            List of agents in category
        """
        return [agent for agent in self._agents.values() if agent.category == category]

    def validate_dependencies(self, agent_name: str) -> List[str]:
        """Validate agent dependencies.

        Args:
            agent_name: Name of agent to validate

        Returns:
            List of missing dependencies (empty if all present)
        """
        agent = self.get_agent(agent_name)

        if not agent:
            return [f"Agent not found: {agent_name}"]

        missing = []

        for dep in agent.dependencies:
            if dep not in self._agents:
                missing.append(dep)

        return missing

    def get_execution_order(self, agent_names: List[str]) -> List[str]:
        """Get topological execution order for agents.

        Args:
            agent_names: List of agent names to execute

        Returns:
            Ordered list of agent names respecting dependencies

        Raises:
            ValueError: If circular dependencies detected
        """
        order = []
        visited = set()
        visiting = set()

        def visit(name: str):
            if name in visiting:
                raise ValueError(f"Circular dependency detected: {name}")

            if name in visited:
                return

            visiting.add(name)

            agent = self.get_agent(name)

            if agent:
                for dep in agent.dependencies:
                    if dep in agent_names:
                        visit(dep)

            visiting.remove(name)
            visited.add(name)
            order.append(name)

        for name in agent_names:
            visit(name)

        return order

    def list_agents(self) -> Dict[str, str]:
        """Get summary of all agents.

        Returns:
            Dictionary mapping agent names to descriptions
        """
        return {agent.name: agent.description for agent in self._agents.values()}

    def get_agent_count(self) -> int:
        """Get total number of registered agents.

        Returns:
            Number of agents
        """
        return len(self._agents)

    def agent_exists(self, agent_name: str) -> bool:
        """Check if agent exists.

        Args:
            agent_name: Name of agent to check

        Returns:
            True if agent exists, False otherwise
        """
        return agent_name in self._agents

    def get_supported_languages(self) -> List[str]:
        """Get list of supported languages.

        Returns:
            List of language codes that have agent directories
        """
        supported = []

        for lang_code in [LanguageCode.EN, LanguageCode.ZH_CN, LanguageCode.ZH_TW]:
            lang_dir = self.agents_dir / str(lang_code)
            if lang_dir.exists() and list(lang_dir.glob("*.md")):
                supported.append(str(lang_code))

        return supported

    def switch_language(self, language: LanguageCode) -> None:
        """Switch to a different language and reload agents.

        Args:
            language: New language code to use
        """
        if language == self.language:
            return

        self.language = language
        self.loader = AgentLoader(self.agents_dir, language=language)
        self.reload_all()
