"""Agent loader for parsing Markdown agent definitions."""

import logging
from pathlib import Path
from typing import List, Optional

import yaml

from core.agents.agent import Agent, AgentCategory
from core.i18n import LanguageCode
from core.schema_versions import SchemaVersionRegistry

logger = logging.getLogger(__name__)


class AgentLoader:
    """Load agent definitions from Markdown files with YAML frontmatter."""

    def __init__(self, agents_dir: str | Path, language: Optional[LanguageCode] = None):
        """Initialize agent loader.

        Args:
            agents_dir: Directory containing agent definition files
            language: Language code for agent files (default: en for backward compatibility)
        """
        self.agents_dir = Path(agents_dir)
        self.language = language or LanguageCode.EN
        self._schema_registry = SchemaVersionRegistry()

    def load_agent(self, file_path: str | Path) -> Agent:
        """Load a single agent from Markdown file.

        Args:
            file_path: Path to agent definition file

        Returns:
            Agent object

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file format is invalid
        """
        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"Agent file not found: {file_path}")

        content = file_path.read_text(encoding="utf-8")

        return self.parse_agent(content, file_path)

    def parse_agent(self, content: str, file_path: Optional[Path] = None) -> Agent:
        """Parse agent from Markdown content with YAML frontmatter.

        Args:
            content: Markdown content with YAML frontmatter
            file_path: Optional file path for reference

        Returns:
            Agent object

        Raises:
            ValueError: If content format is invalid
        """
        content = content.strip()

        if not content.startswith("---"):
            raise ValueError("Agent file must start with YAML frontmatter (---)")

        parts = content.split("---", 2)

        if len(parts) < 3:
            raise ValueError("Agent file must have YAML frontmatter and body")

        frontmatter_text = parts[1].strip()
        instructions = self._normalize_instructions(parts[2].strip())

        try:
            frontmatter = yaml.safe_load(frontmatter_text)
        except yaml.YAMLError as e:
            raise ValueError(f"Invalid YAML frontmatter: {e}")

        if not isinstance(frontmatter, dict):
            raise ValueError("YAML frontmatter must be a dictionary")

        required_fields = ["name", "description", "category"]
        for field in required_fields:
            if field not in frontmatter:
                raise ValueError(f"Missing required field in frontmatter: {field}")

        category_str = frontmatter.get("category")
        try:
            category = AgentCategory(category_str)
        except ValueError:
            raise ValueError(f"Invalid agent category: {category_str}")

        parsed = self._schema_registry.parse_agent(frontmatter, instructions, file_path)

        input_schema = frontmatter.get("input", [])
        output_schema = frontmatter.get("output", [])
        dependencies = frontmatter.get("dependencies", [])
        if not isinstance(input_schema, list):
            input_schema = [input_schema]
        if not isinstance(output_schema, list):
            output_schema = [output_schema]
        if not isinstance(dependencies, list):
            dependencies = [dependencies]

        agent = Agent(
            name=parsed.name,
            version=parsed.version,
            description=parsed.description,
            category=category,
            input_schema=input_schema,
            output_schema=output_schema,
            dependencies=dependencies,
            instructions=parsed.instructions,
            file_path=parsed.file_path,
            context_needs=parsed.context_needs,
            cache_policy=parsed.cache_policy,
        )

        return agent

    @staticmethod
    def _normalize_instructions(instructions: str) -> str:
        """Normalize markdown body by stripping legacy duplicate schema markers."""
        if instructions.startswith("schema_version:"):
            lines = instructions.splitlines()
            if len(lines) > 1 and lines[0].strip() == "schema_version: 1":
                return "\n".join(lines[1:]).lstrip()
        return instructions

    def load_all_agents(self) -> List[Agent]:
        """Load all agent definitions from agents directory.

        Returns:
            List of Agent objects

        Note:
            Loads agents from language-specific subdirectory (e.g., agents/en/).
            Falls back to English if language-specific directory is empty or missing.
            For backward compatibility, also loads from agents_dir if no language
            subdirectories exist.
        """
        agents = []

        if not self.agents_dir.exists():
            return agents

        lang_dir = self.agents_dir / str(self.language)

        # If language directory doesn't exist or has fewer files than English, fallback to English
        en_dir = self.agents_dir / str(LanguageCode.EN)
        if (
            not lang_dir.exists()
            or not list(lang_dir.glob("*.md"))
            or (
                self.language != LanguageCode.EN
                and en_dir.exists()
                and len(list(lang_dir.glob("*.md"))) < len(list(en_dir.glob("*.md")))
            )
        ):
            if self.language != LanguageCode.EN:
                lang_dir = self.agents_dir / str(LanguageCode.EN)
                if not lang_dir.exists() or not list(lang_dir.glob("*.md")):
                    lang_dir = self.agents_dir
            else:
                lang_dir = self.agents_dir

        for file_path in lang_dir.glob("*.md"):
            try:
                agent = self.load_agent(file_path)
                agents.append(agent)
            except Exception as e:
                logger.warning("Failed to load agent from %s: %s", file_path, e)

        return agents

    def reload_agent(self, agent_name: str) -> Optional[Agent]:
        """Reload an agent by name.

        Args:
            agent_name: Name of agent to reload

        Returns:
            Agent object if found, None otherwise

        Note:
            Checks language-specific directory first, falls back to English,
            then falls back to agents_dir for backward compatibility.
        """
        lang_dir = self.agents_dir / str(self.language)
        file_path = lang_dir / f"{agent_name}.md"

        if not file_path.exists():
            if self.language != LanguageCode.EN:
                lang_dir = self.agents_dir / str(LanguageCode.EN)
                file_path = lang_dir / f"{agent_name}.md"
                if not file_path.exists():
                    file_path = self.agents_dir / f"{agent_name}.md"
            else:
                file_path = self.agents_dir / f"{agent_name}.md"

        if not file_path.exists():
            return None

        return self.load_agent(file_path)
