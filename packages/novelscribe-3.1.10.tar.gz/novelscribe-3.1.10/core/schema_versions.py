"""Schema version registry for agent and workflow definitions.

Provides version-aware parsing that routes frontmatter to the correct
parser based on the ``schema_version`` field.  Definitions without an
explicit version default to version 1 (backward compatible).

Usage::

    from core.schema_versions import SchemaVersionRegistry

    reg = SchemaVersionRegistry()
    agent = reg.parse_agent(frontmatter, instructions, file_path)
    workflow = reg.parse_workflow(data, file_path)
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Protocol

from pydantic import BaseModel


class AgentParseResult(BaseModel):
    """Normalized agent parse output shared across schema versions."""

    name: str
    version: str = "1.0.0"
    description: str
    category: str
    input_schema: list[str] = []
    output_schema: list[str] = []
    dependencies: list[str] = []
    instructions: str = ""
    context_needs: Optional[Dict[str, Any]] = None
    cache_policy: Optional[str] = None
    file_path: Optional[str] = None


class WorkflowParseResult(BaseModel):
    """Normalized workflow parse output shared across schema versions."""

    name: str
    version: str = "1.0.0"
    description: str
    variables: Dict[str, Any] = {}
    steps: list[Dict[str, Any]] = []
    file_path: Optional[str] = None


class AgentParser(Protocol):
    def __call__(
        self,
        frontmatter: Dict[str, Any],
        instructions: str,
        file_path: Optional[str],
    ) -> AgentParseResult: ...


class WorkflowParser(Protocol):
    def __call__(
        self,
        data: Dict[str, Any],
        file_path: Optional[str],
    ) -> WorkflowParseResult: ...


def parse_agent_v1(
    frontmatter: Dict[str, Any],
    instructions: str,
    file_path: Optional[str] = None,
) -> AgentParseResult:
    """Parse agent frontmatter using schema version 1 rules."""
    input_schema = frontmatter.get("input", [])
    output_schema = frontmatter.get("output", [])
    dependencies = frontmatter.get("dependencies", [])
    if isinstance(input_schema, str):
        input_schema = [input_schema]
    if isinstance(output_schema, str):
        output_schema = [output_schema]
    if isinstance(dependencies, str):
        dependencies = [dependencies]

    return AgentParseResult(
        name=frontmatter["name"],
        version=frontmatter.get("version", "1.0.0"),
        description=frontmatter["description"],
        category=frontmatter["category"],
        input_schema=input_schema,
        output_schema=output_schema,
        dependencies=dependencies,
        instructions=instructions,
        context_needs=frontmatter.get("context_needs"),
        cache_policy=frontmatter.get("cache_policy"),
        file_path=str(file_path) if file_path else None,
    )


def parse_workflow_v1(
    data: Dict[str, Any],
    file_path: Optional[str] = None,
) -> WorkflowParseResult:
    """Parse workflow data using schema version 1 rules."""
    steps = []
    for step_data in data.get("steps", []):
        if isinstance(step_data, dict):
            steps.append(step_data)

    return WorkflowParseResult(
        name=data["name"],
        version=data.get("version", "1.0.0"),
        description=data["description"],
        variables=data.get("variables", {}),
        steps=steps,
        file_path=str(file_path) if file_path else None,
    )


class SchemaVersionRegistry:
    """Registry that maps schema versions to parser functions."""

    def __init__(self) -> None:
        self._agent_parsers: Dict[int, AgentParser] = {1: parse_agent_v1}
        self._workflow_parsers: Dict[int, WorkflowParser] = {1: parse_workflow_v1}

    def register_agent_parser(self, version: int, parser: AgentParser) -> None:
        self._agent_parsers[version] = parser

    def register_workflow_parser(self, version: int, parser: WorkflowParser) -> None:
        self._workflow_parsers[version] = parser

    def parse_agent(
        self,
        frontmatter: Dict[str, Any],
        instructions: str,
        file_path: Optional[str] = None,
    ) -> AgentParseResult:
        version = int(frontmatter.get("schema_version", 1))
        parser = self._agent_parsers.get(version)
        if parser is None:
            raise ValueError(
                f"Unknown agent schema_version: {version}. "
                f"Supported: {sorted(self._agent_parsers.keys())}"
            )
        return parser(frontmatter, instructions, file_path)

    def parse_workflow(
        self,
        data: Dict[str, Any],
        file_path: Optional[str] = None,
    ) -> WorkflowParseResult:
        version = int(data.get("schema_version", 1))
        parser = self._workflow_parsers.get(version)
        if parser is None:
            raise ValueError(
                f"Unknown workflow schema_version: {version}. "
                f"Supported: {sorted(self._workflow_parsers.keys())}"
            )
        return parser(data, file_path)

    @property
    def supported_agent_versions(self) -> list[int]:
        return sorted(self._agent_parsers.keys())

    @property
    def supported_workflow_versions(self) -> list[int]:
        return sorted(self._workflow_parsers.keys())
