"""Orchestrator core for novel harness.

Implements thin orchestrator pattern that executes workflows with agents.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from core.i18n import LanguageCode, LanguageResolver
from core.llm.client import LLMClientFactory, LLMConfig, LLMError, LLMResponse
from core.storage import (
    AgentDefinition,
    StorageBackend,
    StorageConfig,
    StorageFactory,
    WorkflowDefinition,
)
from core.workflow.variable_resolver import VariableResolver as _CoreVariableResolver


class OrchestratorError(Exception):
    """Base exception for orchestrator operations."""


class StepExecutionError(OrchestratorError):
    """Raised when step execution fails."""


VariableResolver = _CoreVariableResolver


class ExecutionContext:
    """Manage execution context and state."""

    def __init__(
        self,
        project_name: str,
        workflow_name: str,
        base_path: str = ".novels",
    ):
        self.project_name = project_name
        self.workflow_name = workflow_name
        self.base_path = Path(base_path) / project_name
        self.variables: dict[str, Any] = {
            "project_name": project_name,
            "workflow_name": workflow_name,
        }
        self.history: list[dict[str, Any]] = []
        self.logger = logging.getLogger(f"orchestrator.{project_name}")

    def set_variable(self, name: str, value: Any) -> None:
        """Set a variable in context."""
        self.variables[name] = value
        self.logger.debug(f"Set variable: {name} = {value}")

    def get_variable(self, name: str, default: Any = None) -> Any:
        """Get a variable from context."""
        return self.variables.get(name, default)

    def add_history_entry(
        self,
        step_name: str,
        agent: str,
        input_files: list[str],
        output_file: str,
        response: LLMResponse,
    ) -> None:
        """Add entry to execution history."""
        self.history.append(
            {
                "step": step_name,
                "agent": agent,
                "input_files": input_files,
                "output_file": output_file,
                "content": response.content,
                "model": response.model,
                "provider": response.provider,
                "tokens_used": response.tokens_used,
            }
        )

    def get_history(self) -> list[dict[str, Any]]:
        """Get execution history."""
        return self.history.copy()


class Orchestrator:
    """Thin orchestrator for executing workflows with agents."""

    def _resolve_agent_path(self, agent_path: str) -> str:
        """Resolve agent path with language-aware fallback.

        Supports legacy `agents/<name>.md` paths by mapping to
        `agents/<lang>/<name>.md` when available.
        """
        path_obj = Path(agent_path)
        if path_obj.is_absolute():
            return str(path_obj)

        project_root = Path(__file__).parent.parent
        base_candidate = project_root / path_obj
        if base_candidate.exists():
            return str(base_candidate)

        if path_obj.parent.as_posix() == "agents":
            preferred_lang = LanguageResolver().resolve_language()
            fallback_langs = [
                preferred_lang,
                LanguageCode.EN,
                LanguageCode.ZH_CN,
                LanguageCode.ZH_TW,
            ]
            seen: set[LanguageCode] = set()
            for lang in fallback_langs:
                if lang in seen:
                    continue
                seen.add(lang)
                lang_candidate = project_root / "agents" / str(lang) / path_obj.name
                if lang_candidate.exists():
                    return str(lang_candidate)

        return str(base_candidate)

    def __init__(
        self,
        storage: StorageBackend,
        llm_config: LLMConfig,
        base_path: str = ".novels",
    ):
        self.storage = storage
        self.llm_config = llm_config
        self.llm_client = LLMClientFactory.create(llm_config)
        self.base_path = base_path
        self.logger = logging.getLogger("orchestrator")

    def load_workflow(self, workflow_path: str) -> WorkflowDefinition:
        """Load workflow definition from YAML file."""
        self.logger.info(f"Loading workflow: {workflow_path}")
        workflow = self.storage.read_workflow(workflow_path)
        self.logger.info(f"Loaded workflow: {workflow.name}")
        return workflow

    def load_agent(self, agent_path: str) -> AgentDefinition:
        """Load agent definition from Markdown file."""
        self.logger.info(f"Loading agent: {agent_path}")
        if not Path(agent_path).is_absolute():
            agent_path = self._resolve_agent_path(agent_path)

        agent = self.storage.read_agent(agent_path)
        self.logger.info(f"Loaded agent: {agent.name}")
        return agent

    def execute_workflow(
        self,
        workflow_path: str,
        project_name: str,
        initial_context: dict[str, Any] | None = None,
    ) -> ExecutionContext:
        """Execute workflow and return execution context."""
        workflow = self.load_workflow(workflow_path)

        context = ExecutionContext(
            project_name=project_name,
            workflow_name=workflow.name,
            base_path=self.base_path,
        )

        if initial_context:
            context.variables.update(initial_context)

        self.logger.info(f"Starting workflow: {workflow.name}")

        for step in workflow.steps:
            self._execute_step(step, context)

        self.logger.info(f"Completed workflow: {workflow.name}")
        return context

    def _execute_step(self, step: dict[str, Any], context: ExecutionContext) -> None:
        """Execute a single workflow step."""
        step_name = step.get("name", "unnamed")
        agent_name = step.get("agent")
        input_files = step.get("input_files", [])
        output_file = step.get("output_file")

        self.logger.info(f"Executing step: {step_name}")

        if not agent_name:
            raise StepExecutionError(f"Step '{step_name}' missing agent specification")

        condition = step.get("condition")
        if condition and not self._evaluate_condition(condition, context):
            self.logger.info(f"Step '{step_name}' skipped due to condition")
            return

        agent_path = step.get("agent_path", f"agents/{agent_name}.md")
        agent = self.load_agent(agent_path)

        resolver = VariableResolver()

        resolved_input_files = [
            resolver.resolve(f, variables=context.variables) for f in input_files
        ]
        resolved_output_file = (
            resolver.resolve(output_file, variables=context.variables) if output_file else None
        )

        input_content = self._load_input_content(resolved_input_files, context)

        system_prompt = agent.system_prompt
        user_prompt = self._construct_user_prompt(step, input_content, context)

        try:
            response = self._call_llm(agent, system_prompt, user_prompt)

            if resolved_output_file:
                self._save_output(resolved_output_file, response.content, context)

            context.add_history_entry(
                step_name=step_name,
                agent=agent_name,
                input_files=resolved_input_files,
                output_file=resolved_output_file or "",
                response=response,
            )

            self.logger.info(f"Step '{step_name}' completed successfully")

        except LLMError as e:
            self.logger.error(f"LLM error in step '{step_name}': {e}")
            raise StepExecutionError(f"Step '{step_name}' failed: {e}") from e

    def _evaluate_condition(self, condition: str, context: ExecutionContext) -> bool:
        """Evaluate step condition."""
        resolver = VariableResolver()
        resolved = resolver.resolve(condition, variables=context.variables)

        if resolved.lower() in ("true", "yes", "1"):
            return True
        if resolved.lower() in ("false", "no", "0"):
            return False

        return bool(resolved)

    def _load_input_content(
        self,
        input_files: list[str],
        context: ExecutionContext,
    ) -> dict[str, str]:
        """Load content from input files."""
        content = {}

        for file_path in input_files:
            try:
                if file_path.endswith(".md"):
                    content[file_path] = self.storage.read_markdown(file_path)
                elif file_path.endswith(".yaml") or file_path.endswith(".yml"):
                    data = self.storage.read_yaml(file_path)
                    content[file_path] = str(data)
                else:
                    content[file_path] = self.storage.read_markdown(file_path)
            except Exception as e:
                context.logger.warning(f"Failed to load input file {file_path}: {e}")
                content[file_path] = ""

        return content

    def _construct_user_prompt(
        self,
        step: dict[str, Any],
        input_content: dict[str, str],
        context: ExecutionContext,
    ) -> str:
        """Construct user prompt from step definition and input content."""
        prompt_template = step.get("prompt", "")

        resolver = VariableResolver()
        resolved_template = resolver.resolve(prompt_template, variables=context.variables)

        if input_content:
            resolved_template += "\n\n# Input Files\n\n"
            for file_path, content in input_content.items():
                resolved_template += f"## {file_path}\n{content}\n\n"

        return resolved_template.strip()

    def _call_llm(
        self,
        agent: AgentDefinition,
        system_prompt: str,
        user_prompt: str,
    ) -> LLMResponse:
        """Call LLM with agent configuration."""
        agent_config = LLMConfig(
            provider=self.llm_config.provider,
            model=agent.model,
            temperature=agent.temperature,
            max_tokens=agent.max_tokens,
        )

        agent_client = LLMClientFactory.create(agent_config)

        return agent_client.generate(system_prompt, user_prompt)

    def _save_output(
        self,
        output_file: str,
        content: str,
        context: ExecutionContext,
    ) -> None:
        """Save LLM output to file."""
        try:
            if output_file.endswith(".yaml") or output_file.endswith(".yml"):
                self.storage.write_yaml(output_file, {"content": content})
            else:
                self.storage.write_markdown(output_file, content)

            context.logger.info(f"Saved output to: {output_file}")
        except Exception as e:
            raise StepExecutionError(f"Failed to save output to {output_file}: {e}") from e

    def execute_step(
        self,
        agent_path: str,
        system_prompt: str | None = None,
        user_prompt: str = "",
        output_file: str = "",
        context: ExecutionContext | None = None,
    ) -> LLMResponse:
        """Execute a single agent call."""
        agent = self.load_agent(agent_path)

        if system_prompt is None:
            system_prompt = agent.system_prompt

        response = self._call_llm(agent, system_prompt, user_prompt)

        if output_file and context:
            self._save_output(output_file, response.content, context)

        return response


def create_orchestrator(
    storage_config: StorageConfig | None = None,
    llm_config: LLMConfig | None = None,
) -> Orchestrator:
    """Create orchestrator with default configurations."""
    storage_config = storage_config or StorageConfig()
    llm_config = llm_config or LLMConfig()

    storage = StorageFactory.create(storage_config)

    return Orchestrator(
        storage=storage,
        llm_config=llm_config,
        base_path=storage_config.base_path,
    )


__all__ = [
    "OrchestratorError",
    "StepExecutionError",
    "VariableResolver",
    "ExecutionContext",
    "Orchestrator",
    "create_orchestrator",
]
