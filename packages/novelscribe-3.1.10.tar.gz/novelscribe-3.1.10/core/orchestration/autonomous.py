"""Autonomous workflow executor facade for end-to-end novel generation."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

from core.agents.orchestrator_integration import AgentSystemIntegration  # noqa: F401
from core.autonomous._checkpoint import CheckpointHandler
from core.autonomous._checkpoint_flow import CheckpointFlow
from core.autonomous._phase_runner import AutonomousPhaseRunner
from core.autonomous._pipeline_builder import (  # noqa: F401
    AutonomousPipelineBuilder,
    PipelineComponents,
)
from core.autonomous.models import AutonomousConfig, AutonomousResult  # noqa: F401
from core.checkpoints.human import CheckpointType, HumanCheckpoint, HumanCheckpointHandler
from core.checkpoints.manager import CheckpointManager  # noqa: F401
from core.checkpoints.orchestrator import create_checkpoint_orchestrator  # noqa: F401
from core.context.bus import ContextBus  # noqa: F401
from core.git import create_git_manager  # noqa: F401
from core.llm.client import LLMConfig, MultiLLMClient, OpenAIClient  # noqa: F401
from core.logging.structured import (
    bind_project,
    bind_trace_id,
    clear_correlation,
)
from core.memory.bus import MemoryBus, MemoryConfig  # noqa: F401
from core.progress_tracker import ExecutionStatus, ProgressTracker  # noqa: F401
from core.resilience import (
    CircuitConfig,  # noqa: F401
    TimeoutHandler,  # noqa: F401
)
from core.runtime import RuntimeKernel, RuntimeOutcome, RuntimeState, RuntimeTask
from core.storage import StorageBackend, StorageConfig, StorageFactory  # noqa: F401
from core.workflow.executor import WorkflowExecutor  # noqa: F401


class AutonomousExecutor:
    """Autonomous workflow executor.

    Executes complete workflow chain from start to finish with progress tracking,
    checkpointing, and optional human-in-the-loop checkpoints.
    """

    WORKFLOW_CHAIN = [
        "new_novel",
        "worldbuilding_phase",
        "character_phase",
        "outline_phase",
        "chapter_plan_phase",
        "writing_phase",
        "continuity_phase",
        "verification_phase",
    ]

    LEGACY_HUMAN_CHECKPOINTS = [
        HumanCheckpoint(
            phase="outline_phase",
            type=CheckpointType.APPROVAL,
            message="Review generated outline. Approve to continue?",
        ),
        HumanCheckpoint(
            phase="character_phase",
            type=CheckpointType.INPUT,
            message="Enter any additional character requirements:",
            required=False,
        ),
        HumanCheckpoint(
            phase="chapter_plan_phase",
            type=CheckpointType.APPROVAL,
            message="Review chapter plan. Approve to continue writing?",
        ),
    ]

    def __init__(
        self,
        config: AutonomousConfig,
        storage_path: Path,
        memory_config: Optional[MemoryConfig] = None,
        runtime: RuntimeKernel | None = None,
    ) -> None:
        """Initialize autonomous executor."""
        self.config = config
        self.storage_path = storage_path
        self.logger = logging.getLogger("scribe")
        self.runtime = runtime
        self._last_runtime_entry_outcome: RuntimeOutcome | None = None

        self._pipeline_builder = AutonomousPipelineBuilder(
            config=config,
            storage_path=storage_path,
            memory_config=memory_config,
            llm_config_cls=LLMConfig,
            multi_llm_client_cls=MultiLLMClient,
            storage_factory=StorageFactory,
            agent_integration_cls=AgentSystemIntegration,
            git_manager_factory=create_git_manager,
            memory_bus_cls=MemoryBus,
            context_bus_cls=ContextBus,
            workflow_executor_cls=WorkflowExecutor,
            progress_tracker_cls=ProgressTracker,
            checkpoint_manager_cls=CheckpointManager,
            checkpoint_orchestrator_factory=create_checkpoint_orchestrator,
            human_checkpoint_handler_cls=HumanCheckpointHandler,
            timeout_handler_cls=TimeoutHandler,
        )
        components = self._pipeline_builder.build()

        self.llm_config = components.llm_config
        self._optimizing_client = components.optimizing_client
        self.agent_integration = components.agent_integration
        self.git_manager = components.git_manager
        self.memory_bus = components.memory_bus
        self.context_bus = components.context_bus
        self.workflow_executor = components.workflow_executor
        self.progress_tracker = components.progress_tracker
        self.checkpoint_manager = components.checkpoint_manager
        self.checkpoint_orchestrator = components.checkpoint_orchestrator
        self.human_handler = components.human_handler
        self.timeout_handler = components.timeout_handler

        self._checkpoint_handler = CheckpointHandler(self)
        self._checkpoint_flow = CheckpointFlow(self, self._checkpoint_handler)
        self._phase_runner = AutonomousPhaseRunner(self, self._checkpoint_flow)

    def _get_fallback_config(self) -> LLMConfig | None:
        """Backward-compatible accessor for fallback config."""
        return self._pipeline_builder._get_fallback_config()

    def _get_circuit_config(self) -> CircuitConfig | None:
        """Backward-compatible accessor for circuit breaker config."""
        return self._pipeline_builder._get_circuit_config()

    def pause_at_checkpoint(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> Optional[str]:
        """Pause pipeline at a checkpoint for later human review."""
        return self._checkpoint_handler.pause_at_checkpoint(phase, chapter, execution_context)

    def resume_from_checkpoint_decision(
        self,
        checkpoint_id: str,
        decision: dict[str, Any],
    ) -> AutonomousResult:
        """Resume pipeline after human makes a checkpoint decision."""
        return self._checkpoint_handler.resume_from_checkpoint_decision(checkpoint_id, decision)

    def checkpoint_waiting(self) -> Optional[dict[str, Any]]:
        """Check if there's a checkpoint waiting for decision."""
        return self._checkpoint_handler.checkpoint_waiting()

    def execute(self, resume: bool = False) -> AutonomousResult:
        """Execute autonomous pipeline."""
        import time as _time

        from core.metrics import MetricsCollector

        _trace_id = bind_trace_id()
        bind_project(self.config.project_name)
        MetricsCollector().set_trace_id(_trace_id)
        _pipeline_start = _time.perf_counter()
        _pipeline_ok = False
        try:
            runtime_entry = self._run_runtime_entry_mainline(resume=resume)
            if runtime_entry is not None and not runtime_entry.success:
                if self.config.runtime_gate_mode == "strict":
                    self.logger.error(
                        "Runtime autonomous entry gate failed; strict mode blocks execution"
                    )
                    self.progress_tracker.set_status(
                        ExecutionStatus.FAILED,
                        "Runtime entry gate failed in strict mode",
                    )
                    return AutonomousResult(
                        success=False,
                        completed_phases=[],
                        final_status=ExecutionStatus.FAILED,
                        error="Runtime entry gate failed in strict mode",
                    )
                self.logger.warning(
                    "Runtime autonomous entry gate failed; continuing via compatibility pipeline"
                )
            if resume:
                result = self._resume_from_checkpoint()
            else:
                result = self._execute_full_pipeline()
            _pipeline_ok = result.success
            return result
        except Exception as e:
            self.logger.error(f"Autonomous execution failed: {e}")
            self.progress_tracker.set_status(ExecutionStatus.FAILED, str(e))
            state = self.progress_tracker.get_state()
            completed: list[str] = state.completed_phases if state else []
            return AutonomousResult(
                success=False,
                completed_phases=completed,
                final_status=ExecutionStatus.FAILED,
                error=str(e),
            )
        finally:
            MetricsCollector().record_pipeline(
                _time.perf_counter() - _pipeline_start, success=_pipeline_ok
            )
            clear_correlation()

    def _run_runtime_entry_mainline(self, resume: bool) -> RuntimeOutcome | None:
        """Run runtime entry gate before autonomous legacy phase runner."""
        runtime = self._ensure_runtime_mainline()
        action = "resume autonomous pipeline" if resume else "start autonomous pipeline"
        task = RuntimeTask(
            user_input=f"{action} for project '{self.config.project_name}'.",
            system_prompt="Autonomous runtime entry gate",
            agent_name="autonomous_runtime_mainline",
            metadata={
                "source": "autonomous_executor_mainline",
                "project_name": self.config.project_name,
                "resume": resume,
            },
        )
        state = RuntimeState(metadata={"project_name": self.config.project_name})
        outcome = runtime.run(task, state)
        self._last_runtime_entry_outcome = outcome
        return outcome

    def _ensure_runtime_mainline(self) -> RuntimeKernel:
        """Ensure autonomous executor has a runtime instance for mainline entry."""
        if self.runtime is not None:
            return self.runtime
        self.runtime = RuntimeKernel(infer_fn=lambda _s, _u: "runtime_entry_ok")
        return self.runtime

    def run_runtime_preview(
        self,
        prompt: str,
        system_prompt: str = "Autonomous Runtime Preview",
    ) -> RuntimeOutcome:
        """Run runtime side-route without switching autonomous mainline.

        Args:
            prompt: User prompt passed to runtime.
            system_prompt: Optional system prompt for preview call.

        Returns:
            RuntimeOutcome from one turn runtime execution.
        """
        runtime = self.runtime
        if runtime is None:
            runtime = RuntimeKernel.from_llm_client(
                self._optimizing_client,
                context_bus=self.context_bus,
                memory_bus=self.memory_bus,
            )
            self.runtime = runtime

        task = RuntimeTask(
            user_input=prompt,
            system_prompt=system_prompt,
            agent_name="autonomous_runtime_preview",
            metadata={"source": "autonomous_executor"},
        )
        state = RuntimeState(metadata={"project_name": self.config.project_name})
        return runtime.run(task, state)

    def _execute_full_pipeline(self) -> AutonomousResult:
        """Execute full autonomous pipeline."""
        return self._phase_runner.execute_full_pipeline()

    def _build_checkpoint_plan_content(
        self,
        phase: str,
        chapter: Optional[int],
        execution_context: dict[str, Any],
    ) -> dict[str, Any]:
        """Build plan content for checkpoint."""
        return self._checkpoint_handler.build_checkpoint_plan_content(
            phase,
            chapter,
            execution_context,
        )

    def _present_checkpoint(
        self,
        workflow_name: str,
        chapter: Any | None,
        execution_context: dict[str, Any],
    ) -> Any | None:
        """Present checkpoint to user."""
        return self._checkpoint_handler.present_checkpoint(
            workflow_name,
            chapter,
            execution_context,
        )

    def _resume_from_checkpoint(self) -> AutonomousResult:
        """Resume execution from checkpoint."""
        return self._phase_runner.resume_from_checkpoint()

    def _get_workflow_index(self, workflow_name: str) -> int:
        """Get index of workflow in chain."""
        try:
            return self.WORKFLOW_CHAIN.index(workflow_name)
        except ValueError:
            raise ValueError(f"Unknown workflow: {workflow_name}")
