"""ManuscriptCompiler — assemble chapters and metadata into a publishable manuscript."""

from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class ManuscriptChapter(BaseModel):
    """A single chapter in a compiled manuscript."""

    title: str
    content: str
    chapter_number: int
    word_count: int = 0
    is_prologue: bool = False
    is_epilogue: bool = False


class ManuscriptMetadata(BaseModel):
    """Metadata for a compiled manuscript."""

    title: str = "Untitled"
    author: str = "Unknown"
    genre: str = ""
    language: str = "en"
    description: str = ""
    cover_image_path: Optional[str] = None
    copyright_notice: Optional[str] = None
    date: str = Field(default_factory=lambda: datetime.now().strftime("%Y-%m-%d"))


class Appendix(BaseModel):
    """An appendix section for the manuscript."""

    title: str
    content: str
    appendix_type: str = "custom"


class Manuscript(BaseModel):
    """A fully assembled manuscript ready for export."""

    metadata: ManuscriptMetadata = Field(default_factory=ManuscriptMetadata)
    chapters: List[ManuscriptChapter] = Field(default_factory=list)
    table_of_contents: List[str] = Field(default_factory=list)
    appendices: List[Appendix] = Field(default_factory=list)

    @property
    def total_word_count(self) -> int:
        """Total word count across all chapters."""
        return sum(ch.word_count for ch in self.chapters)

    @property
    def chapter_count(self) -> int:
        """Number of chapters in the manuscript."""
        return len(self.chapters)


class ManuscriptCompiler:
    """Compiles chapters and metadata into a Manuscript object.

    Reads chapter files from ``.novels/<project>/chapters/*.md`` and
    metadata from ``.novels/<project>/meta.yaml``, producing a structured
    ``Manuscript`` ready for multi-format export.
    """

    def __init__(self, novels_dir: Optional[Path] = None) -> None:
        self._novels_dir = novels_dir or Path(".novels")

    def compile(
        self,
        project_name: str,
        include_appendices: bool = False,
    ) -> Manuscript:
        """Compile a project into a Manuscript.

        Args:
            project_name: Project directory name under ``.novels/``.
            include_appendices: Whether to include character list, world
                glossary, and chapter summary appendices.

        Returns:
            Assembled ``Manuscript`` with metadata, chapters, TOC, and
            optional appendices.
        """
        project_path = self._novels_dir / project_name
        metadata = self._load_metadata(project_path)
        chapters = self._load_chapters(project_path)
        toc = self._build_toc(chapters)
        appendices = self._build_appendices(project_path) if include_appendices else []

        return Manuscript(
            metadata=metadata,
            chapters=chapters,
            table_of_contents=toc,
            appendices=appendices,
        )

    def _load_metadata(self, project_path: Path) -> ManuscriptMetadata:
        """Load manuscript metadata from project meta.yaml."""
        meta_path = project_path / "meta.yaml"
        raw: Dict[str, Any] = {}

        if meta_path.exists():
            try:
                import yaml

                with open(meta_path) as f:
                    raw = yaml.safe_load(f) or {}
            except Exception:
                logger.debug("Failed to load manuscript metadata from %s", meta_path)

        return ManuscriptMetadata(
            title=raw.get("name", raw.get("project_name", raw.get("title", "Untitled"))),
            author=raw.get("author", "Unknown"),
            genre=raw.get("genre", ""),
            language=raw.get("language", "en"),
            description=raw.get("description", ""),
            cover_image_path=raw.get("cover_image_path"),
            copyright_notice=raw.get("copyright_notice"),
            date=raw.get("date", datetime.now().strftime("%Y-%m-%d")),
        )

    def _load_chapters(self, project_path: Path) -> List[ManuscriptChapter]:
        """Load and order chapter files from the chapters directory."""
        chapters_dir = project_path / "chapters"
        if not chapters_dir.exists():
            return []

        chapter_files = sorted(chapters_dir.glob("*.md"))
        chapters: List[ManuscriptChapter] = []

        for idx, chapter_file in enumerate(chapter_files, start=1):
            content = chapter_file.read_text()
            title = self._extract_title(content, chapter_file.stem)
            word_count = len(content.split())
            is_prologue = "prologue" in chapter_file.stem.lower()
            is_epilogue = "epilogue" in chapter_file.stem.lower()

            chapters.append(
                ManuscriptChapter(
                    title=title,
                    content=content,
                    chapter_number=idx,
                    word_count=word_count,
                    is_prologue=is_prologue,
                    is_epilogue=is_epilogue,
                )
            )

        return chapters

    def _extract_title(self, content: str, fallback: str) -> str:
        """Extract chapter title from the first markdown heading."""
        match = re.match(r"^#\s+(.+)$", content, re.MULTILINE)
        if match:
            return match.group(1).strip()
        return fallback.replace("_", " ").replace("-", " ").title()

    def _build_toc(self, chapters: List[ManuscriptChapter]) -> List[str]:
        """Build a table of contents from chapter titles."""
        return [f"Chapter {ch.chapter_number}: {ch.title}" for ch in chapters]

    def _build_appendices(self, project_path: Path) -> List[Appendix]:
        """Build optional appendices from project data."""
        appendices: List[Appendix] = []

        summaries_path = project_path / "summaries"
        if summaries_path.exists():
            summary_content = self._collect_summaries(summaries_path)
            if summary_content:
                appendices.append(
                    Appendix(
                        title="Chapter Summaries",
                        content=summary_content,
                        appendix_type="summaries",
                    )
                )

        characters_path = project_path / "characters"
        if characters_path.exists():
            char_content = self._collect_characters(characters_path)
            if char_content:
                appendices.append(
                    Appendix(
                        title="Character List",
                        content=char_content,
                        appendix_type="characters",
                    )
                )

        world_path = project_path / "worldbuilding"
        if world_path.exists():
            world_content = self._collect_world(world_path)
            if world_content:
                appendices.append(
                    Appendix(
                        title="World Glossary",
                        content=world_content,
                        appendix_type="world",
                    )
                )

        return appendices

    def _collect_summaries(self, summaries_path: Path) -> str:
        """Collect chapter summaries into a single string."""
        parts: List[str] = []
        for f in sorted(summaries_path.glob("*.md")):
            parts.append(f.read_text())
        return "\n\n---\n\n".join(parts)

    def _collect_characters(self, characters_path: Path) -> str:
        """Collect character descriptions into a single string."""
        parts: List[str] = []
        for f in sorted(characters_path.glob("*.md")):
            parts.append(f.read_text())
        return "\n\n---\n\n".join(parts)

    def _collect_world(self, world_path: Path) -> str:
        """Collect world-building notes into a single string."""
        parts: List[str] = []
        for f in sorted(world_path.glob("*.md")):
            parts.append(f.read_text())
        return "\n\n---\n\n".join(parts)
