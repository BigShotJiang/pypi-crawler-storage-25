"""Exporter orchestrator — compiles a manuscript and renders it to the requested format."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from core.exporter.compiler import Manuscript, ManuscriptCompiler
from core.exporter.renderers import RendererFactory


class ExportResult:
    """Outcome of a single export operation."""

    def __init__(
        self,
        output_path: Path,
        format_name: str,
        manuscript: Manuscript,
    ) -> None:
        self.output_path = output_path
        self.format_name = format_name
        self.manuscript = manuscript

    @property
    def file_size_bytes(self) -> int:
        return self.output_path.stat().st_size if self.output_path.exists() else 0


class Exporter:
    """High-level facade that compiles a project and renders it to a chosen format.

    Usage::

        exporter = Exporter(novels_dir=Path(".novels"))
        result = exporter.export("my_novel", fmt="pdf", output_dir=Path("output"))
    """

    def __init__(self, novels_dir: Optional[Path] = None) -> None:
        self._compiler = ManuscriptCompiler(novels_dir=novels_dir)
        self._novels_dir = novels_dir or Path(".novels")

    def export(
        self,
        project_name: str,
        fmt: str = "pdf",
        output_dir: Optional[Path] = None,
        cover_image: Optional[Path] = None,
        include_appendices: bool = False,
    ) -> ExportResult:
        """Compile and render a project to the specified format.

        Args:
            project_name: Project directory name under ``.novels/``.
            fmt: Output format (``pdf``, ``epub``, ``docx``, ``md``).
            output_dir: Destination directory. Defaults to
                ``.novels/<project>/exports/``.
            cover_image: Optional cover image path.
            include_appendices: Whether to include character list, world
                glossary, and chapter summary appendices.

        Returns:
            ``ExportResult`` with the output path and manuscript metadata.
        """
        manuscript = self._compiler.compile(project_name, include_appendices=include_appendices)

        renderer = RendererFactory.get(fmt)
        out_dir = output_dir or (self._novels_dir / project_name / "exports")
        output_path = out_dir / f"{project_name}.{fmt}"

        renderer.render(manuscript, output_path, cover_image=cover_image)

        return ExportResult(
            output_path=output_path,
            format_name=fmt,
            manuscript=manuscript,
        )

    @staticmethod
    def available_formats() -> list[str]:
        """Return the list of formats that have their dependencies installed."""
        return RendererFactory.available_formats()
