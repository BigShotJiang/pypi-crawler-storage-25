"""Checkpoint management for autonomous execution."""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from pydantic import BaseModel

from core.progress_tracker import ExecutionStatus, ProgressState

logger = logging.getLogger(__name__)


class Checkpoint(BaseModel):
    """Checkpoint model.

    Attributes:
        project_name: Name of the project
        checkpoint_id: Unique checkpoint identifier
        timestamp: Checkpoint creation timestamp
        completed_workflows: List of completed workflow names
        current_workflow: Optional current workflow name
        execution_context: Execution context variables
        progress_state: Current progress state
    """

    project_name: str
    checkpoint_id: str
    timestamp: datetime
    completed_workflows: list[str]
    current_workflow: Optional[str]
    execution_context: dict[str, Any]
    progress_state: ProgressState
    quality_gate_result: Optional[dict[str, Any]] = None


class CheckpointManager:
    """Checkpoint manager for autonomous execution.

    Manages checkpoint creation, loading, and validation
    for resume capability.
    """

    def __init__(self, project_name: str, storage_path: Path, max_checkpoints: int = 50):
        """Initialize checkpoint manager.

        Args:
            project_name: Name of the project
            storage_path: Base storage path for checkpoint files
            max_checkpoints: Maximum number of checkpoints to retain
        """
        self.project_name = project_name
        self.storage_path = storage_path
        self.checkpoints_dir = storage_path / ".checkpoints"
        self.latest_symlink = self.checkpoints_dir / "checkpoint_latest.json"
        self.max_checkpoints = max_checkpoints

    def create_checkpoint(
        self,
        completed_workflows: list[str],
        current_workflow: Optional[str],
        execution_context: dict[str, Any],
        progress_state: ProgressState,
    ) -> Checkpoint:
        """Create a new checkpoint.

        Args:
            completed_workflows: List of completed workflow names
            current_workflow: Optional current workflow name
            execution_context: Current execution context variables
            progress_state: Current progress state

        Returns:
            Created checkpoint
        """
        checkpoint_id = self._generate_checkpoint_id()

        checkpoint = Checkpoint(
            project_name=self.project_name,
            checkpoint_id=checkpoint_id,
            timestamp=datetime.now(),
            completed_workflows=completed_workflows,
            current_workflow=current_workflow,
            execution_context=execution_context,
            progress_state=progress_state,
        )

        self._save_checkpoint(checkpoint)
        self._update_latest_symlink(checkpoint_id)
        self.prune_old_checkpoints()

        return checkpoint

    def prune_old_checkpoints(self) -> int:
        """Remove oldest checkpoints beyond max_checkpoints.

        Returns:
            Number of checkpoints pruned.
        """
        if not self.checkpoints_dir.exists():
            return 0

        all_files = sorted(
            f for f in self.checkpoints_dir.glob("checkpoint_*.json") if not f.is_symlink()
        )

        if len(all_files) <= self.max_checkpoints:
            return 0

        to_remove = all_files[: len(all_files) - self.max_checkpoints]
        removed = 0
        for f in to_remove:
            try:
                f.unlink()
                removed += 1
            except OSError:
                pass
        return removed

    def load_checkpoint(self, checkpoint_id: Optional[str] = None) -> Optional[Checkpoint]:
        """Load a checkpoint.

        Args:
            checkpoint_id: Optional checkpoint ID. If None, loads latest

        Returns:
            Loaded checkpoint or None if not found
        """
        if checkpoint_id is None:
            checkpoint_file = self.latest_symlink
        else:
            checkpoint_file = self.checkpoints_dir / f"checkpoint_{checkpoint_id}.json"

        if not checkpoint_file.exists():
            return None

        try:
            data = json.loads(checkpoint_file.read_text())

            data["timestamp"] = datetime.fromisoformat(data["timestamp"])

            progress_data = data["progress_state"]
            progress_data["start_time"] = datetime.fromisoformat(progress_data["start_time"])
            progress_data["last_update"] = datetime.fromisoformat(progress_data["last_update"])
            progress_data["status"] = ExecutionStatus(progress_data["status"])

            data["progress_state"] = ProgressState(**progress_data)

            return Checkpoint(**data)

        except Exception as e:
            raise RuntimeError(f"Failed to load checkpoint: {e}")

    def list_checkpoints(self) -> list[Checkpoint]:
        """List all available checkpoints.

        Returns:
            List of available checkpoints, sorted by timestamp (newest first)
        """
        if not self.checkpoints_dir.exists():
            return []

        checkpoints = []

        for checkpoint_file in self.checkpoints_dir.glob("checkpoint_*.json"):
            if checkpoint_file.is_symlink():
                continue

            try:
                data = json.loads(checkpoint_file.read_text())

                data["timestamp"] = datetime.fromisoformat(data["timestamp"])

                progress_data = data["progress_state"]
                progress_data["start_time"] = datetime.fromisoformat(progress_data["start_time"])
                progress_data["last_update"] = datetime.fromisoformat(progress_data["last_update"])
                progress_data["status"] = ExecutionStatus(progress_data["status"])

                data["progress_state"] = ProgressState(**progress_data)

                checkpoints.append(Checkpoint(**data))

            except Exception:
                continue

        return sorted(checkpoints, key=lambda c: c.timestamp, reverse=True)

    def validate_checkpoint(self, checkpoint: Checkpoint) -> bool:
        """Validate checkpoint integrity.

        Args:
            checkpoint: Checkpoint to validate

        Returns:
            True if checkpoint is valid, False otherwise
        """
        try:
            assert checkpoint.project_name == self.project_name

            assert checkpoint.progress_state.project_name == self.project_name

            assert checkpoint.progress_state.total_steps > 0

            assert 0 <= checkpoint.progress_state.progress_percentage <= 100

            return True

        except (AssertionError, AttributeError, KeyError):
            return False

    def delete_checkpoint(self, checkpoint_id: str) -> bool:
        """Delete a checkpoint.

        Args:
            checkpoint_id: Checkpoint ID to delete

        Returns:
            True if deleted, False if not found
        """
        checkpoint_file = self.checkpoints_dir / f"checkpoint_{checkpoint_id}.json"

        if not checkpoint_file.exists():
            return False

        checkpoint_file.unlink()
        return True

    def _generate_checkpoint_id(self) -> str:
        """Generate unique checkpoint ID.

        Returns:
            Checkpoint ID in format YYYYMMDD_HHMMSS
        """
        return datetime.now().strftime("%Y%m%d_%H%M%S")

    def _save_checkpoint(self, checkpoint: Checkpoint) -> None:
        """Save checkpoint to disk.

        Args:
            checkpoint: Checkpoint to save
        """
        self.checkpoints_dir.mkdir(parents=True, exist_ok=True)

        checkpoint_file = self.checkpoints_dir / f"checkpoint_{checkpoint.checkpoint_id}.json"

        data = checkpoint.model_dump(mode="json")

        data["timestamp"] = checkpoint.timestamp.isoformat()

        progress_data = checkpoint.progress_state.model_dump(mode="json")
        progress_data["start_time"] = checkpoint.progress_state.start_time.isoformat()
        progress_data["last_update"] = checkpoint.progress_state.last_update.isoformat()
        progress_data["status"] = checkpoint.progress_state.status.value

        data["progress_state"] = progress_data

        checkpoint_file.write_text(json.dumps(data, indent=2))

    def _update_latest_symlink(self, checkpoint_id: str) -> None:
        """Update latest checkpoint symlink.

        Args:
            checkpoint_id: Checkpoint ID to link as latest
        """
        self.checkpoints_dir.mkdir(parents=True, exist_ok=True)

        target_file = self.checkpoints_dir / f"checkpoint_{checkpoint_id}.json"

        if self.latest_symlink.exists():
            self.latest_symlink.unlink()

        try:
            self.latest_symlink.symlink_to(target_file.name)
        except OSError:
            logger.debug("Failed to create latest checkpoint symlink: %s", target_file.name)
