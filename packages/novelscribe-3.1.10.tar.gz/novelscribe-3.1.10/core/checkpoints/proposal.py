"""Checkpoint proposal models with confidence scoring and reasoning."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class DecisionType(str, Enum):
    """Human decision type at checkpoint."""

    APPROVE = "approve"
    MODIFY = "modify"
    REJECT = "reject"
    GUIDANCE = "guidance"
    ASK = "ask"


class ConfidenceFactor(str, Enum):
    """Factors used in confidence calculation."""

    COHERENCE = "coherence"
    CHARACTER = "character"
    PACING = "pacing"
    ORIGINALITY = "originality"
    COMPLETENESS = "completeness"


@dataclass
class PlanContent:
    """Content of a proposal plan."""

    title: str
    pov: Optional[str] = None
    word_estimate: int = 0
    scenes: list[dict[str, Any]] = field(default_factory=list)
    foreshadowing: Optional[str] = None
    pacing: str = "moderate"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Alternative:
    """Alternative proposal option."""

    option_id: str
    plan: PlanContent
    confidence: float
    tradeoff_explanation: str
    rejection_reasons: list[str] = field(default_factory=list)

    def get_confidence_percentage(self) -> str:
        """Get confidence as percentage string."""
        return f"{self.confidence * 100:.0f}%"


@dataclass
class ConfidenceBreakdown:
    """Breakdown of confidence score by factor."""

    coherence: float = 0.0
    character: float = 0.0
    pacing: float = 0.0
    originality: float = 0.0
    completeness: float = 0.0

    @property
    def total(self) -> float:
        """Calculate weighted total confidence."""
        return (
            self.coherence * 0.30
            + self.character * 0.25
            + self.pacing * 0.20
            + self.originality * 0.15
            + self.completeness * 0.10
        )


@dataclass
class CheckpointProposal:
    """AI proposal at a checkpoint with confidence and reasoning."""

    checkpoint_id: str
    phase: str
    plan: PlanContent
    confidence: float
    reasoning: str
    reasoning_trace: list[str] = field(default_factory=list)
    alternatives: list[Alternative] = field(default_factory=list)
    confidence_breakdown: Optional[ConfidenceBreakdown] = None
    context_summary: Optional[dict[str, Any]] = None
    created_at: datetime = field(default_factory=lambda: datetime.now())
    metadata: dict[str, Any] = field(default_factory=dict)

    def get_primary_reasoning(self) -> str:
        """Get the main reasoning string."""
        return self.reasoning

    def get_alternative_by_id(self, option_id: str) -> Optional[Alternative]:
        """Get alternative by option ID."""
        for alt in self.alternatives:
            if alt.option_id == option_id:
                return alt
        return None

    def get_confidence_percentage(self) -> str:
        """Get confidence as percentage string."""
        return f"{self.confidence * 100:.0f}%"


@dataclass
class CheckpointDecision:
    """Human decision at checkpoint."""

    decision_type: DecisionType
    checkpoint_id: str
    timestamp: datetime = field(default_factory=lambda: datetime.now())
    modified_content: Optional[dict[str, Any]] = None
    guidance_text: Optional[str] = None
    question: Optional[str] = None
    answer: Optional[str] = None
    selected_alternative: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CheckpointResponse:
    """AI response to human decision."""

    decision: CheckpointDecision
    applied: bool
    adjustments_made: list[str] = field(default_factory=list)
    remaining_changes: list[str] = field(default_factory=list)
    modified_proposal: Optional[CheckpointProposal] = None
    explanation: Optional[str] = None
    timestamp: datetime = field(default_factory=lambda: datetime.now())
