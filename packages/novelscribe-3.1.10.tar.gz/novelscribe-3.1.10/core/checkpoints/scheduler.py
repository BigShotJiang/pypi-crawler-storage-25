"""Checkpoint scheduler for managing comprehensive checkpoint schedule."""

from dataclasses import dataclass
from datetime import timedelta
from typing import Optional


@dataclass
class CheckpointDefinition:
    """Definition of a checkpoint in the schedule."""

    checkpoint_id: str
    phase: str
    message: str
    context_needed: list[str]
    timeout_hours: Optional[int] = None
    requires_approval: bool = True
    is_repeating: bool = False
    repeat_interval: Optional[int] = None


class CheckpointSchedule:
    """Comprehensive checkpoint schedule for human-in-the-loop authoring."""

    CHECKPOINTS = [
        CheckpointDefinition(
            checkpoint_id="cp_01",
            phase="new_novel",
            message="Review META.yaml - approve genre, tone, audience, length",
            context_needed=["genre", "target_audience", "tone", "word_count_target"],
        ),
        CheckpointDefinition(
            checkpoint_id="cp_02",
            phase="worldbuilding_phase",
            message="Review LORE.md - approve world rules, geography, magic, history",
            context_needed=["world_rules", "geography", "magic_system", "history"],
        ),
        CheckpointDefinition(
            checkpoint_id="cp_03",
            phase="character_phase",
            message="Review CHARACTERS.md - approve character arcs, relationships, backstories",
            context_needed=["character_arcs", "relationships", "backstories"],
        ),
        CheckpointDefinition(
            checkpoint_id="cp_04",
            phase="outline_phase",
            message="Review full outline - approve story structure, plot points, pacing",
            context_needed=["story_structure", "plot_points", "pacing_notes"],
        ),
        CheckpointDefinition(
            checkpoint_id="cp_05",
            phase="chapter_plan_phase",
            message="Review chapter plan - approve goals, POV, key scenes",
            context_needed=["chapter_goals", "pov_character", "key_scenes"],
            is_repeating=True,
            repeat_interval=1,
        ),
        CheckpointDefinition(
            checkpoint_id="cp_06",
            phase="writing_phase",
            message="Mid-novel review - validate direction, provide corrections",
            context_needed=["chapters_written", "current_arc", "pacing_evaluation"],
            is_repeating=True,
            repeat_interval=5,
        ),
        CheckpointDefinition(
            checkpoint_id="cp_07",
            phase="continuity_phase",
            message="Review continuity report - approve fixes or override",
            context_needed=["continuity_issues", "proposed_fixes"],
        ),
        CheckpointDefinition(
            checkpoint_id="cp_08",
            phase="verification_phase",
            message="Final review - approve quality metrics or request rewrites",
            context_needed=["quality_metrics", "verification_results"],
        ),
    ]

    def __init__(self, custom_checkpoints: Optional[list[CheckpointDefinition]] = None):
        """Initialize checkpoint schedule.

        Args:
            custom_checkpoints: Optional list of custom checkpoints to use
        """
        self._checkpoints = custom_checkpoints or self.CHECKPOINTS
        self._active_checkpoints: dict[str, str] = {}

    def should_pause_at_phase(self, phase: str, chapter: Optional[int] = None) -> bool:
        """Check if execution should pause at given phase.

        Args:
            phase: Current phase name
            chapter: Current chapter number (for repeating checkpoints)

        Returns:
            True if should pause, False otherwise
        """
        for cp in self._checkpoints:
            if cp.phase == phase:
                if cp.is_repeating and chapter is not None:
                    if chapter % cp.repeat_interval == 0:
                        return True
                elif not cp.is_repeating:
                    return True
        return False

    def get_checkpoint_for_phase(
        self, phase: str, chapter: Optional[int] = None
    ) -> Optional[CheckpointDefinition]:
        """Get checkpoint definition for phase.

        Args:
            phase: Phase name
            chapter: Current chapter number

        Returns:
            CheckpointDefinition or None
        """
        for cp in self._checkpoints:
            if cp.phase == phase:
                if cp.is_repeating:
                    if chapter is not None and chapter % cp.repeat_interval == 0:
                        return cp
                else:
                    return cp
        return None

    def get_next_checkpoint_after(
        self, current_phase: str, current_chapter: Optional[int] = None
    ) -> Optional[CheckpointDefinition]:
        """Get the next checkpoint after current phase.

        Args:
            current_phase: Current phase name
            current_chapter: Current chapter number

        Returns:
            Next CheckpointDefinition or None
        """
        phase_order = [
            "new_novel",
            "worldbuilding_phase",
            "character_phase",
            "outline_phase",
            "chapter_plan_phase",
            "writing_phase",
            "continuity_phase",
            "verification_phase",
        ]

        if current_phase not in phase_order:
            return None

        current_idx = phase_order.index(current_phase)

        if current_phase in ("chapter_plan_phase", "writing_phase") and current_chapter is not None:
            remaining_in_phase = 25 - current_chapter
            if remaining_in_phase > 0:
                for cp in self._checkpoints:
                    if cp.phase == current_phase and cp.is_repeating:
                        return cp

        for next_phase in phase_order[current_idx + 1 :]:
            for cp in self._checkpoints:
                if cp.phase == next_phase:
                    return cp

        return None

    def is_checkpoint_active(self, checkpoint_id: str) -> bool:
        """Check if checkpoint is currently active (waiting for decision).

        Args:
            checkpoint_id: Checkpoint ID to check

        Returns:
            True if active, False otherwise
        """
        return checkpoint_id in self._active_checkpoints

    def activate_checkpoint(self, checkpoint_id: str, context_hash: str):
        """Mark checkpoint as active (waiting for human decision).

        Args:
            checkpoint_id: Checkpoint ID
            context_hash: Hash of context at checkpoint time
        """
        self._active_checkpoints[checkpoint_id] = context_hash

    def deactivate_checkpoint(self, checkpoint_id: str):
        """Mark checkpoint as resolved.

        Args:
            checkpoint_id: Checkpoint ID
        """
        self._active_checkpoints.pop(checkpoint_id, None)

    def get_active_checkpoints(self) -> list[str]:
        """Get list of active (waiting) checkpoint IDs.

        Returns:
            List of active checkpoint IDs
        """
        return list(self._active_checkpoints.keys())

    def get_checkpoint_by_id(self, checkpoint_id: str) -> Optional[CheckpointDefinition]:
        """Get checkpoint definition by ID.

        Args:
            checkpoint_id: Checkpoint ID

        Returns:
            CheckpointDefinition or None
        """
        for cp in self._checkpoints:
            if cp.checkpoint_id == checkpoint_id:
                return cp
        return None

    def get_timeout_for_checkpoint(self, checkpoint_id: str) -> Optional[timedelta]:
        """Get timeout duration for checkpoint.

        Args:
            checkpoint_id: Checkpoint ID

        Returns:
            timedelta or None if no timeout
        """
        cp = self.get_checkpoint_by_id(checkpoint_id)
        if cp and cp.timeout_hours:
            return timedelta(hours=cp.timeout_hours)
        return None


def create_checkpoint_schedule() -> CheckpointSchedule:
    """Factory function to create checkpoint schedule.

    Returns:
        CheckpointSchedule instance
    """
    return CheckpointSchedule()
