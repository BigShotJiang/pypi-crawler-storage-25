"""Background checkpointer - async notification and timeout handling."""

import asyncio
import logging
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from typing import Any, Callable, Optional

from core.hybrid_authority import (
    AuthorityConfig,
    AuthorityLevel,
    AutoApproveReason,
    CheckpointDeadline,
    CheckpointNotification,
    GraduatedAuthority,
)


class BackgroundCheckpointer:
    """Background processor for checkpoint notifications and timeouts."""

    def __init__(
        self,
        authority_config: Optional[AuthorityConfig] = None,
        on_timeout: Optional[Callable[[str], None]] = None,
        on_reminder: Optional[Callable[[str, str], None]] = None,
        on_escalation: Optional[Callable[[str], None]] = None,
    ):
        self._authority = GraduatedAuthority()
        self._authority_config = authority_config or AuthorityConfig()
        self._deadlines: dict[str, CheckpointDeadline] = {}
        self._notifications: list[CheckpointNotification] = []
        self._running = False
        self._executor = ThreadPoolExecutor(max_workers=2)
        self._loop_task: Optional[asyncio.Task] = None
        self._logger = logging.getLogger("scribe")
        self._on_timeout = on_timeout
        self._on_reminder = on_reminder
        self._on_escalation = on_escalation
        self._checkpoint_callbacks: dict[str, Callable] = {}

    @property
    def authority(self) -> GraduatedAuthority:
        return self._authority

    def set_checkpoint_callback(self, checkpoint_id: str, callback: Callable[[], None]):
        self._checkpoint_callbacks[checkpoint_id] = callback

    def remove_checkpoint_callback(self, checkpoint_id: str):
        self._checkpoint_callbacks.pop(checkpoint_id, None)

    def start_monitoring(self, checkpoint_id: str, timeout_hours: Optional[float] = None):
        if timeout_hours is None:
            timeout_hours = self._authority_config.timeout_hours
        if timeout_hours is None:
            return

        deadline = CheckpointDeadline(
            checkpoint_id=checkpoint_id,
            created_at=datetime.now(),
            deadline=datetime.now() + timedelta(hours=timeout_hours),
        )
        self._deadlines[checkpoint_id] = deadline

    def stop_monitoring(self, checkpoint_id: str):
        self._deadlines.pop(checkpoint_id, None)
        self.remove_checkpoint_callback(checkpoint_id)

    def extend_deadline(self, checkpoint_id: str, hours: float) -> bool:
        deadline = self._deadlines.get(checkpoint_id)
        if deadline:
            return deadline.extend(hours)
        return False

    def get_deadline_status(self, checkpoint_id: str) -> Optional[dict[str, Any]]:
        deadline = self._deadlines.get(checkpoint_id)
        if not deadline:
            return None
        return {
            "checkpoint_id": checkpoint_id,
            "deadline": deadline.deadline.isoformat() if deadline.deadline else None,
            "is_expired": deadline.is_expired,
            "time_remaining": str(deadline.time_remaining) if deadline.time_remaining else None,
            "extensions_granted": deadline.extensions_granted,
            "reminder_sent": deadline.reminder_sent,
        }

    def should_auto_approve(
        self, checkpoint_id: str, confidence: float
    ) -> tuple[bool, AutoApproveReason]:
        if self._authority_config.level == AuthorityLevel.AI_ONLY:
            return True, AutoApproveReason.EXPLICIT_REQUEST
        return self._authority.should_auto_approve(confidence, self._authority_config)

    def record_approval(self, checkpoint_id: str, was_auto: bool = False):
        self._authority.record_approval(was_auto)
        self.stop_monitoring(checkpoint_id)

    def record_modification(self, checkpoint_id: str):
        self._authority.record_modification()
        self.stop_monitoring(checkpoint_id)

    def record_rejection(self, checkpoint_id: str):
        self._authority.record_rejection()
        if self._authority_config.escalate_on_reject:
            self._escalate(checkpoint_id)
        self.stop_monitoring(checkpoint_id)

    def _escalate(self, checkpoint_id: str):
        deadline = self._deadlines.get(checkpoint_id)
        if deadline:
            deadline.escalation_triggered = True
        if self._on_escalation:
            self._executor.submit(self._on_escalation, checkpoint_id)
        self._add_notification(
            event_type="escalation",
            checkpoint_id=checkpoint_id,
            message=f"Checkpoint {checkpoint_id} was rejected - escalation triggered",
        )

    def _add_notification(
        self,
        event_type: str,
        checkpoint_id: str,
        message: str,
        metadata: Optional[dict[str, Any]] = None,
    ):
        notification = CheckpointNotification(
            notification_id=str(uuid.uuid4())[:8],
            checkpoint_id=checkpoint_id,
            event_type=event_type,
            message=message,
            metadata=metadata or {},
        )
        self._notifications.append(notification)
        self._logger.info(f"Checkpoint notification: {event_type} for {checkpoint_id}")

    async def _check_deadlines_loop(self):
        while self._running:
            for checkpoint_id, deadline in list(self._deadlines.items()):
                if deadline.is_expired and not deadline.escalation_triggered:
                    self._handle_timeout(checkpoint_id)
                elif (
                    deadline.time_remaining
                    and deadline.time_remaining.total_seconds() <= 3600
                    and not deadline.reminder_sent
                ):
                    self._send_reminder(checkpoint_id)
            await asyncio.sleep(30)

    def _handle_timeout(self, checkpoint_id: str):
        deadline = self._deadlines.get(checkpoint_id)
        if deadline and not deadline.escalation_triggered:
            deadline.escalation_triggered = True
            if self._on_timeout:
                self._executor.submit(self._on_timeout, checkpoint_id)
            self._add_notification(
                event_type="timeout",
                checkpoint_id=checkpoint_id,
                message=f"Checkpoint {checkpoint_id} timed out - AI proceeding with best judgment",
            )
            callback = self._checkpoint_callbacks.get(checkpoint_id)
            if callback:
                self._executor.submit(callback)

    def _send_reminder(self, checkpoint_id: str):
        deadline = self._deadlines.get(checkpoint_id)
        if deadline:
            deadline.reminder_sent = True
            if self._on_reminder:
                remaining = deadline.time_remaining
                remaining_str = str(remaining).split(".")[0] if remaining else "less than 1 hour"
                self._executor.submit(self._on_reminder, checkpoint_id, remaining_str)
            self._add_notification(
                event_type="reminder",
                checkpoint_id=checkpoint_id,
                message=f"Reminder: checkpoint {checkpoint_id} expires in less than 1 hour",
            )

    def get_pending_notifications(
        self, checkpoint_id: Optional[str] = None
    ) -> list[dict[str, Any]]:
        notifications = self._notifications
        if checkpoint_id:
            notifications = [n for n in notifications if n.checkpoint_id == checkpoint_id]
        return [
            {
                "id": n.notification_id,
                "checkpoint_id": n.checkpoint_id,
                "event_type": n.event_type,
                "message": n.message,
                "created_at": n.created_at.isoformat(),
                "read": n.read,
            }
            for n in notifications[-20:]
        ]

    def mark_notification_read(self, notification_id: str):
        for n in self._notifications:
            if n.notification_id == notification_id:
                n.read = True

    def clear_notifications(self, checkpoint_id: Optional[str] = None):
        if checkpoint_id:
            self._notifications = [
                n for n in self._notifications if n.checkpoint_id != checkpoint_id
            ]
        else:
            self._notifications.clear()

    def get_trust_score(self) -> float:
        return self._authority.trust_score

    def get_authority_status(self) -> dict[str, Any]:
        return {
            "level": self._authority_config.level.value,
            "trust_score": self._authority.trust_score,
            "checkpoints_passed": self._authority.checkpoints_passed,
            "human_approvals": self._authority.human_approvals,
            "human_modifications": self._authority.human_modifications,
            "human_rejections": self._authority.human_rejections,
            "auto_approves": self._authority.auto_approves,
        }

    def shutdown(self):
        self._running = False
        if self._loop_task:
            self._loop_task.cancel()
        self._executor.shutdown(wait=False)


def create_background_checkpointer(
    authority_level: Optional[AuthorityLevel] = None,
    on_timeout: Optional[Callable[[str], None]] = None,
) -> BackgroundCheckpointer:
    config = None
    if authority_level:
        config = AuthorityConfig(level=authority_level)
    return BackgroundCheckpointer(authority_config=config, on_timeout=on_timeout)
