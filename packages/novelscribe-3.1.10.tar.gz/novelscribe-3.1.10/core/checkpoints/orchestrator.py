"""Checkpoint orchestrator - coordinates checkpoint presentation and resolution."""

import hashlib
import logging
import threading
import time
from datetime import datetime
from typing import Any, Callable, Optional

from core.checkpoints.proposal import (
    Alternative,
    CheckpointProposal,
    CheckpointResponse,
    ConfidenceBreakdown,
    DecisionType,
    PlanContent,
)
from core.checkpoints.scheduler import CheckpointSchedule, create_checkpoint_schedule
from core.quality.confidence_calculator import ConfidenceCalculator
from core.quality.decision_processor import DecisionProcessor
from core.quality.interactive_qa import InteractiveQAHandler


class CheckpointStatus(str):
    PENDING = "pending"
    APPROVED = "approved"
    MODIFIED = "modified"
    REJECTED = "rejected"
    SUPERSEDED = "superseded"
    AUTO_APPROVED = "auto_approved"


class CheckpointOrchestrator:
    def __init__(
        self,
        schedule: Optional[CheckpointSchedule] = None,
        decision_processor: Optional[DecisionProcessor] = None,
        background_checkpointer: Optional[Any] = None,
        on_auto_approve: Optional[Callable[[str, str], None]] = None,
        confidence_calculator: Optional[ConfidenceCalculator] = None,
        qa_handler: Optional[InteractiveQAHandler] = None,
    ):
        self.schedule = schedule or create_checkpoint_schedule()
        self.decision_processor = decision_processor or DecisionProcessor()
        self.background_checkpointer = background_checkpointer
        self.on_auto_approve = on_auto_approve
        self.confidence_calculator = confidence_calculator or ConfidenceCalculator()
        self.qa_handler = qa_handler or InteractiveQAHandler()
        self.logger = logging.getLogger("scribe")
        self._checkpoint_states: dict[str, dict[str, Any]] = {}
        self._state_lock = threading.RLock()
        self._state_changed = threading.Condition(self._state_lock)

    def should_pause_at_phase(self, phase: str, chapter: Optional[int] = None) -> bool:
        """Check if should pause at phase.

        Args:
            phase: Current phase
            chapter: Current chapter number

        Returns:
            True if should pause, False otherwise
        """
        return self.schedule.should_pause_at_phase(phase, chapter)

    def get_checkpoint_id(self, phase: str, chapter: Optional[int] = None) -> str:
        """Generate checkpoint ID from phase and chapter.

        Args:
            phase: Current phase
            chapter: Current chapter number

        Returns:
            Checkpoint ID string
        """
        cp = self.schedule.get_checkpoint_for_phase(phase, chapter)
        if cp:
            if chapter is not None and cp.is_repeating:
                return f"{cp.checkpoint_id}_ch{chapter}"
            return cp.checkpoint_id
        return f"cp_{phase}"

    def present_checkpoint(
        self,
        phase: str,
        chapter: Optional[int],
        plan_content: dict[str, Any],
        context_summary: Optional[dict[str, Any]] = None,
        alternatives: Optional[list[dict[str, Any]]] = None,
    ) -> CheckpointProposal:
        """Present checkpoint to human with AI proposal.

        Args:
            phase: Current phase
            chapter: Current chapter number
            plan_content: Plan content dict
            context_summary: Optional context summary
            alternatives: Optional list of alternative plans

        Returns:
            CheckpointProposal ready for display
        """
        checkpoint_id = self.get_checkpoint_id(phase, chapter)

        plan = PlanContent(**plan_content)

        alt_list = []
        if alternatives:
            for i, alt in enumerate(alternatives):
                alt_list.append(
                    Alternative(
                        option_id=chr(65 + i),
                        plan=PlanContent(**alt.get("plan", {})),
                        confidence=alt.get("confidence", 0.5),
                        tradeoff_explanation=alt.get("tradeoff", ""),
                        rejection_reasons=alt.get("rejection_reasons", []),
                    )
                )

        confidence = self._calculate_confidence(plan, alt_list)
        reasoning = self._generate_reasoning(plan, alt_list, phase)
        reasoning_trace = self._generate_reasoning_trace(plan, phase)
        confidence_breakdown = self._calculate_confidence_breakdown(plan, phase)

        proposal = CheckpointProposal(
            checkpoint_id=checkpoint_id,
            phase=phase,
            plan=plan,
            confidence=confidence,
            reasoning=reasoning,
            reasoning_trace=reasoning_trace,
            alternatives=alt_list,
            confidence_breakdown=confidence_breakdown,
            context_summary=context_summary,
        )

        self.schedule.activate_checkpoint(checkpoint_id, self._hash_context(plan_content))
        with self._state_changed:
            self._checkpoint_states[checkpoint_id] = {
                "status": CheckpointStatus.PENDING,
                "proposal": proposal,
                "presented_at": datetime.now(),
            }
            self._state_changed.notify_all()

        return proposal

    def await_decision(
        self,
        checkpoint_id: str,
        timeout: Optional[float] = None,
    ) -> Optional[dict[str, Any]]:
        """Wait for human decision on checkpoint with timeout and auto-approve support."""
        with self._state_lock:
            state = self._checkpoint_states.get(checkpoint_id)
            if not state:
                return None
        checkpointer = self.background_checkpointer

        deadline = (time.monotonic() + timeout) if timeout is not None else None

        with self._state_changed:
            while True:
                state = self._checkpoint_states.get(checkpoint_id)
                if not state:
                    return None
                if state["status"] != CheckpointStatus.PENDING:
                    return {
                        "status": state["status"],
                        "decision": state.get("decision"),
                        "response": state.get("response"),
                    }

                if checkpointer:
                    deadline_status = checkpointer.get_deadline_status(checkpoint_id)
                    if deadline_status and deadline_status.get("is_expired"):
                        auto_approved, reason = checkpointer.should_auto_approve(
                            checkpoint_id, state["proposal"].confidence
                        )
                        if auto_approved:
                            state["status"] = CheckpointStatus.AUTO_APPROVED
                            state["auto_approve_reason"] = reason.value
                            checkpointer.record_approval(checkpoint_id, was_auto=True)
                            if self.on_auto_approve:
                                self.on_auto_approve(checkpoint_id, reason.value)
                            self._state_changed.notify_all()
                            return {
                                "status": CheckpointStatus.AUTO_APPROVED,
                                "reason": reason.value,
                                "checkpoint_id": checkpoint_id,
                            }

                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return {"status": "timeout", "checkpoint_id": checkpoint_id}
                else:
                    remaining = None

                wait_for = 0.1 if remaining is None else max(0.0, min(0.1, remaining))
                self._state_changed.wait(timeout=wait_for)

    def incorporate_decision(
        self,
        checkpoint_id: str,
        decision: dict[str, Any],
    ) -> CheckpointResponse:
        with self._state_lock:
            state = self._checkpoint_states.get(checkpoint_id)
            if not state:
                raise ValueError(f"Unknown checkpoint: {checkpoint_id}")

        from core.checkpoints.proposal import CheckpointDecision

        decision_type = DecisionType(decision.get("type", "approve"))
        checkpoint_decision = CheckpointDecision(
            decision_type=decision_type,
            checkpoint_id=checkpoint_id,
            modified_content=decision.get("modified_content"),
            guidance_text=decision.get("guidance_text"),
            question=decision.get("question"),
            answer=decision.get("answer"),
            selected_alternative=decision.get("selected_alternative"),
        )

        response = self.decision_processor.process(checkpoint_decision, state["proposal"])

        status_map = {
            DecisionType.APPROVE: CheckpointStatus.APPROVED,
            DecisionType.MODIFY: CheckpointStatus.MODIFIED,
            DecisionType.REJECT: CheckpointStatus.REJECTED,
            DecisionType.GUIDANCE: CheckpointStatus.APPROVED,
            DecisionType.ASK: CheckpointStatus.PENDING,
        }
        with self._state_changed:
            state["status"] = status_map.get(decision_type, CheckpointStatus.PENDING)
            state["decision"] = checkpoint_decision
            state["response"] = response
            state["decided_at"] = datetime.now()
            self._state_changed.notify_all()

        if response.applied:
            self.schedule.deactivate_checkpoint(checkpoint_id)

        if self.background_checkpointer:
            if decision_type == DecisionType.APPROVE:
                self.background_checkpointer.record_approval(checkpoint_id)
            elif decision_type == DecisionType.MODIFY:
                self.background_checkpointer.record_modification(checkpoint_id)
            elif decision_type == DecisionType.REJECT:
                self.background_checkpointer.record_rejection(checkpoint_id)

        return response

    def get_checkpoint_state(self, checkpoint_id: str) -> Optional[dict[str, Any]]:
        """Get current state of checkpoint.

        Args:
            checkpoint_id: Checkpoint ID

        Returns:
            State dict or None
        """
        return self._checkpoint_states.get(checkpoint_id)

    def get_pending_checkpoints(self) -> list[str]:
        """Get list of pending (waiting) checkpoint IDs.

        Returns:
            List of pending checkpoint IDs
        """
        return [
            cp_id
            for cp_id, state in self._checkpoint_states.items()
            if state["status"] == CheckpointStatus.PENDING
        ]

    def _calculate_confidence(self, plan: PlanContent, alternatives: list[Alternative]) -> float:
        """Calculate confidence score for plan."""
        phase = plan.metadata.get("phase", "")
        return self.confidence_calculator.calculate(plan, phase).total

    def _calculate_confidence_breakdown(self, plan: PlanContent, phase: str) -> ConfidenceBreakdown:
        """Calculate confidence breakdown by factor."""
        return self.confidence_calculator.calculate(plan, phase)

    def _generate_reasoning(
        self, plan: PlanContent, alternatives: list[Alternative], phase: str
    ) -> str:
        """Generate reasoning explanation for proposal."""
        reasons = []

        if plan.pov:
            reasons.append(f"POV character: {plan.pov}")

        if plan.scenes:
            reasons.append(f"{len(plan.scenes)} key scenes defined")

        if plan.foreshadowing:
            reasons.append(f"Foreshadowing: {plan.foreshadowing[:50]}...")

        reasons.append(f"Pacing: {plan.pacing}")

        return "; ".join(reasons) if reasons else "Standard proposal"

    def _generate_reasoning_trace(self, plan: PlanContent, phase: str) -> list[str]:
        """Generate step-by-step reasoning trace."""
        trace = [
            f"Identified phase: {phase}",
            f"Generated plan: {plan.title}",
        ]

        if plan.pov:
            trace.append(f"Set POV to: {plan.pov}")

        if plan.scenes:
            trace.append(f"Defined {len(plan.scenes)} scenes")

        if plan.foreshadowing:
            trace.append("Added foreshadowing element")

        trace.append(f"Calculated confidence: {self._calculate_confidence(plan, []):.0%}")

        return trace

    def _hash_context(self, context: dict[str, Any]) -> str:
        """Create hash of context for comparison."""
        import json

        context_str = json.dumps(context, sort_keys=True)
        return hashlib.md5(context_str.encode()).hexdigest()[:8]

    def get_explanation(self, checkpoint_id: str, question: str) -> Optional[str]:
        """Get AI explanation for a checkpoint proposal.

        Args:
            checkpoint_id: Checkpoint to explain.
            question: User's question about the proposal.

        Returns:
            Explanation string or None if checkpoint not found.
        """
        state = self._checkpoint_states.get(checkpoint_id)
        if not state or "proposal" not in state:
            return None
        return self.qa_handler.answer_question(question, state["proposal"])

    def generate_what_if(self, checkpoint_id: str, modification: str) -> Optional[dict[str, Any]]:
        """Generate a what-if variant for a checkpoint proposal.

        Args:
            checkpoint_id: Checkpoint to modify.
            modification: Description of desired change.

        Returns:
            Dict with explanation and modification options, or None.
        """
        state = self._checkpoint_states.get(checkpoint_id)
        if not state or "proposal" not in state:
            return None

        proposal = state["proposal"]
        answer = self.qa_handler.answer_question(f"what if {modification}", proposal)
        return {
            "checkpoint_id": checkpoint_id,
            "modification": modification,
            "explanation": answer,
            "original_confidence": proposal.confidence,
        }

    def compare_alternatives(self, checkpoint_id: str) -> Optional[dict[str, Any]]:
        """Get structured comparison of all alternatives for a checkpoint.

        Args:
            checkpoint_id: Checkpoint to compare alternatives for.

        Returns:
            Dict with options list and recommendation, or None.
        """
        state = self._checkpoint_states.get(checkpoint_id)
        if not state or "proposal" not in state:
            return None

        proposal = state["proposal"]
        options = []

        # Primary plan
        options.append(
            {
                "label": "Primary",
                "title": proposal.plan.title,
                "confidence": proposal.confidence,
                "is_primary": True,
                "tradeoffs": [],
                "strengths": [proposal.reasoning] if proposal.reasoning else [],
            }
        )

        # Alternatives
        for alt in proposal.alternatives:
            options.append(
                {
                    "label": alt.option_id,
                    "title": alt.plan.title,
                    "confidence": alt.confidence,
                    "is_primary": False,
                    "tradeoffs": [alt.tradeoff_explanation] if alt.tradeoff_explanation else [],
                    "strengths": [],
                }
            )

        best = max(options, key=lambda o: o["confidence"])
        return {
            "checkpoint_id": checkpoint_id,
            "options": options,
            "recommendation": best["label"],
        }


def create_checkpoint_orchestrator() -> CheckpointOrchestrator:
    """Factory function to create checkpoint orchestrator.

    Returns:
        CheckpointOrchestrator instance
    """
    return CheckpointOrchestrator()
