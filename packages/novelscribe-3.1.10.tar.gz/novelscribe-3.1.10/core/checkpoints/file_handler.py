"""File-based checkpoint handler for batch processing and external tool integration."""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import yaml

from core.checkpoints.proposal import CheckpointDecision, CheckpointProposal, DecisionType
from core.checkpoints.scheduler import CheckpointSchedule, create_checkpoint_schedule
from core.utils import ensure_directories


class CheckpointFileHandler:
    """Handles checkpoint proposals and decisions via filesystem."""

    PROPOSAL_FILENAME = "checkpoint_proposal.json"
    DECISION_FILENAME = "checkpoint_decision.json"
    HISTORY_DIR = ".checkpoint_history"

    def __init__(
        self,
        project_path: Path,
        schedule: Optional[CheckpointSchedule] = None,
    ):
        """Initialize checkpoint file handler.

        Args:
            project_path: Path to project directory
            schedule: Checkpoint schedule to use
        """
        self.project_path = Path(project_path)
        self.schedule = schedule or create_checkpoint_schedule()
        self.logger = logging.getLogger("scribe")
        self._ensure_directories()

    def _ensure_directories(self):
        """Ensure checkpoint directories exist."""
        history_path = self.project_path / self.HISTORY_DIR
        ensure_directories(self.project_path, history_path)

    def save_proposal(self, proposal: CheckpointProposal) -> Path:
        """Save checkpoint proposal to file.

        Args:
            proposal: CheckpointProposal to save

        Returns:
            Path to saved file
        """
        filepath = self.project_path / self.PROPOSAL_FILENAME
        data = {
            "checkpoint_id": proposal.checkpoint_id,
            "phase": proposal.phase,
            "plan": {
                "title": proposal.plan.title,
                "pov": proposal.plan.pov,
                "word_estimate": proposal.plan.word_estimate,
                "scenes": proposal.plan.scenes,
                "foreshadowing": proposal.plan.foreshadowing,
                "pacing": proposal.plan.pacing,
                "metadata": proposal.plan.metadata,
            },
            "confidence": proposal.confidence,
            "reasoning": proposal.reasoning,
            "reasoning_trace": proposal.reasoning_trace,
            "alternatives": [
                {
                    "option_id": alt.option_id,
                    "plan": {
                        "title": alt.plan.title,
                        "pov": alt.plan.pov,
                        "word_estimate": alt.plan.word_estimate,
                    },
                    "confidence": alt.confidence,
                    "tradeoff_explanation": alt.tradeoff_explanation,
                    "rejection_reasons": alt.rejection_reasons,
                }
                for alt in proposal.alternatives
            ],
            "confidence_breakdown": None,
            "context_summary": proposal.context_summary,
            "created_at": proposal.created_at.isoformat(),
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        self.logger.info(f"Saved checkpoint proposal to {filepath}")
        return filepath

    def load_proposal(self) -> Optional[CheckpointProposal]:
        """Load checkpoint proposal from file.

        Returns:
            CheckpointProposal or None if no proposal exists
        """
        filepath = self.project_path / self.PROPOSAL_FILENAME
        if not filepath.exists():
            return None

        with open(filepath) as f:
            data = json.load(f)

        from core.checkpoints.proposal import (
            Alternative,
            ConfidenceBreakdown,
            PlanContent,
        )

        alternatives = []
        for alt_data in data.get("alternatives", []):
            alternatives.append(
                Alternative(
                    option_id=alt_data["option_id"],
                    plan=PlanContent(
                        title=alt_data["plan"]["title"],
                        pov=alt_data["plan"].get("pov"),
                        word_estimate=alt_data["plan"].get("word_estimate", 0),
                    ),
                    confidence=alt_data["confidence"],
                    tradeoff_explanation=alt_data["tradeoff_explanation"],
                    rejection_reasons=alt_data.get("rejection_reasons", []),
                )
            )

        breakdown = None
        if data.get("confidence_breakdown"):
            bd = data["confidence_breakdown"]
            breakdown = ConfidenceBreakdown(
                coherence=bd.get("coherence", 0.0),
                character=bd.get("character", 0.0),
                pacing=bd.get("pacing", 0.0),
                originality=bd.get("originality", 0.0),
                completeness=bd.get("completeness", 0.0),
            )

        plan = PlanContent(
            title=data["plan"]["title"],
            pov=data["plan"].get("pov"),
            word_estimate=data["plan"].get("word_estimate", 0),
            scenes=data["plan"].get("scenes", []),
            foreshadowing=data["plan"].get("foreshadowing"),
            pacing=data["plan"].get("pacing", "moderate"),
            metadata=data["plan"].get("metadata", {}),
        )

        proposal = CheckpointProposal(
            checkpoint_id=data["checkpoint_id"],
            phase=data["phase"],
            plan=plan,
            confidence=data["confidence"],
            reasoning=data["reasoning"],
            reasoning_trace=data.get("reasoning_trace", []),
            alternatives=alternatives,
            confidence_breakdown=breakdown,
            context_summary=data.get("context_summary"),
        )

        return proposal

    def save_decision(self, decision: CheckpointDecision) -> Path:
        """Save checkpoint decision to file.

        Args:
            decision: CheckpointDecision to save

        Returns:
            Path to saved file
        """
        filepath = self.project_path / self.DECISION_FILENAME
        data = {
            "decision_type": decision.decision_type.value,
            "checkpoint_id": decision.checkpoint_id,
            "timestamp": decision.timestamp.isoformat(),
            "modified_content": decision.modified_content,
            "guidance_text": decision.guidance_text,
            "question": decision.question,
            "answer": decision.answer,
            "selected_alternative": decision.selected_alternative,
        }

        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        self._archive_decision(decision)

        self.logger.info(f"Saved checkpoint decision to {filepath}")
        return filepath

    def _archive_decision(self, decision: CheckpointDecision):
        """Archive decision to history.

        Args:
            decision: Decision to archive
        """
        timestamp = decision.timestamp.strftime("%Y%m%d_%H%M%S")
        archive_name = f"{decision.checkpoint_id}_{timestamp}.json"
        archive_path = self.project_path / self.HISTORY_DIR / archive_name

        data = {
            "decision_type": decision.decision_type.value,
            "checkpoint_id": decision.checkpoint_id,
            "timestamp": decision.timestamp.isoformat(),
            "modified_content": decision.modified_content,
            "guidance_text": decision.guidance_text,
            "question": decision.question,
            "answer": decision.answer,
            "selected_alternative": decision.selected_alternative,
        }

        with open(archive_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def load_decision(self) -> Optional[CheckpointDecision]:
        """Load checkpoint decision from file.

        Returns:
            CheckpointDecision or None if no decision exists
        """
        filepath = self.project_path / self.DECISION_FILENAME
        if not filepath.exists():
            return None

        with open(filepath) as f:
            data = json.load(f)

        return CheckpointDecision(
            decision_type=DecisionType(data["decision_type"]),
            checkpoint_id=data["checkpoint_id"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            modified_content=data.get("modified_content"),
            guidance_text=data.get("guidance_text"),
            question=data.get("question"),
            answer=data.get("answer"),
            selected_alternative=data.get("selected_alternative"),
        )

    def clear_proposal(self):
        """Remove current proposal file."""
        filepath = self.project_path / self.PROPOSAL_FILENAME
        if filepath.exists():
            filepath.unlink()
            self.logger.info(f"Removed checkpoint proposal: {filepath}")

    def clear_decision(self):
        """Remove current decision file."""
        filepath = self.project_path / self.DECISION_FILENAME
        if filepath.exists():
            filepath.unlink()
            self.logger.info(f"Removed checkpoint decision: {filepath}")

    def get_history(self, checkpoint_id: Optional[str] = None) -> list[dict[str, Any]]:
        """Get decision history.

        Args:
            checkpoint_id: Optional filter by checkpoint ID

        Returns:
            List of archived decisions
        """
        history_path = self.project_path / self.HISTORY_DIR
        if not history_path.exists():
            return []

        decisions = []
        for filepath in sorted(history_path.glob("*.json")):
            if checkpoint_id and not filepath.name.startswith(checkpoint_id):
                continue

            with open(filepath) as f:
                decisions.append(json.load(f))

        return decisions

    def has_pending_proposal(self) -> bool:
        """Check if there's a pending proposal waiting for decision.

        Returns:
            True if proposal exists without corresponding decision
        """
        proposal_path = self.project_path / self.PROPOSAL_FILENAME
        decision_path = self.project_path / self.DECISION_FILENAME

        if not proposal_path.exists():
            return False

        if not decision_path.exists():
            return True

        proposal_mtime = proposal_path.stat().st_mtime
        decision_mtime = decision_path.stat().st_mtime

        return proposal_mtime > decision_mtime

    def export_to_yaml(self, proposal: CheckpointProposal, output_path: Path) -> Path:
        """Export proposal to YAML format.

        Args:
            proposal: Proposal to export
            output_path: Path to output file

        Returns:
            Path to exported file
        """
        data = {
            "checkpoint_id": proposal.checkpoint_id,
            "phase": proposal.phase,
            "title": proposal.plan.title,
            "confidence": f"{proposal.confidence:.0%}",
            "reasoning": proposal.reasoning,
            "plan_details": {
                "pov": proposal.plan.pov,
                "word_estimate": proposal.plan.word_estimate,
                "pacing": proposal.plan.pacing,
                "scenes": len(proposal.plan.scenes),
            },
            "alternatives": [
                {
                    "id": alt.option_id,
                    "title": alt.plan.title,
                    "confidence": f"{alt.confidence:.0%}",
                    "tradeoff": alt.tradeoff_explanation,
                }
                for alt in proposal.alternatives
            ],
        }

        with open(output_path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

        return output_path

    def import_decision_from_yaml(self, input_path: Path) -> Optional[CheckpointDecision]:
        """Import decision from YAML format.

        Args:
            input_path: Path to YAML decision file

        Returns:
            CheckpointDecision or None if import fails
        """
        if not input_path.exists():
            return None

        with open(input_path) as f:
            data = yaml.safe_load(f)

        decision_type_map = {
            "approve": DecisionType.APPROVE,
            "modify": DecisionType.MODIFY,
            "reject": DecisionType.REJECT,
            "guidance": DecisionType.GUIDANCE,
            "ask": DecisionType.ASK,
        }

        decision_type = decision_type_map.get(
            data.get("decision_type", "approve").lower(),
            DecisionType.APPROVE,
        )

        return CheckpointDecision(
            decision_type=decision_type,
            checkpoint_id=data.get("checkpoint_id", "unknown"),
            modified_content=data.get("modified_content"),
            guidance_text=data.get("guidance_text"),
            question=data.get("question"),
            answer=data.get("answer"),
            selected_alternative=data.get("selected_alternative"),
        )


def create_checkpoint_file_handler(
    project_path: Path,
    schedule: Optional[CheckpointSchedule] = None,
) -> CheckpointFileHandler:
    """Factory function to create checkpoint file handler.

    Args:
        project_path: Path to project directory
        schedule: Optional checkpoint schedule

    Returns:
        CheckpointFileHandler instance
    """
    return CheckpointFileHandler(project_path, schedule)
