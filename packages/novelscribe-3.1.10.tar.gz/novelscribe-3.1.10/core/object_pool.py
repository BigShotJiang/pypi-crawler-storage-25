"""
Object Pool Implementation for Phase 4.3

Provides object pooling to reduce allocation overhead for
frequently created objects.
"""

import logging
import threading
from dataclasses import dataclass
from typing import Any, Callable, Dict, Generic, List, Optional, TypeVar

from pydantic import BaseModel

T = TypeVar("T")

logger = logging.getLogger(__name__)


class PoolableObject:
    """Base class for poolable objects."""

    def reset(self):
        """Reset object to initial state."""
        raise NotImplementedError("Subclasses must implement reset()")

    def validate(self) -> bool:
        """Validate object is in good state."""
        return True


class ObjectPoolConfig(BaseModel):
    """Configuration for object pool."""

    initial_size: int = 5
    max_size: int = 50
    shrink_threshold: float = 0.3
    shrink_interval_seconds: int = 300
    enable_validation: bool = True
    enable_statistics: bool = True


@dataclass
class PoolStats:
    """Statistics for object pool."""

    total_acquired: int = 0
    total_released: int = 0
    total_created: int = 0
    current_size: int = 0
    current_available: int = 0
    peak_size: int = 0
    validation_failures: int = 0

    def utilization_rate(self) -> float:
        """Calculate pool utilization rate."""
        if self.current_size == 0:
            return 0.0
        return (self.current_size - self.current_available) / self.current_size


class ObjectPool(Generic[T]):
    """
    Generic object pool for reducing allocation overhead.

    Features:
    - Reusable objects
    - Automatic shrinking
    - Object validation
    - Statistics tracking
    - Thread-safe operations
    """

    def __init__(self, factory: Callable[[], T], config: Optional[ObjectPoolConfig] = None):
        """
        Initialize object pool.

        Args:
            factory: Function to create new objects
            config: Pool configuration
        """
        self.factory = factory
        self.config = config or ObjectPoolConfig()

        self.pool: List[T] = []
        self.in_use: Dict[int, T] = {}

        self.lock = threading.RLock()
        self.stats = PoolStats()

        self._initialize_pool()

    def _initialize_pool(self):
        """Initialize pool with initial objects."""
        for _ in range(self.config.initial_size):
            try:
                obj = self.factory()
                self.pool.append(obj)
                self.stats.total_created += 1
            except Exception:
                logger.debug("Failed to create initial pool object")

        self.stats.current_size = len(self.pool)
        self.stats.current_available = len(self.pool)
        self.stats.peak_size = len(self.pool)

    def acquire(self) -> Optional[T]:
        """
        Acquire object from pool.

        Returns:
            Object from pool or newly created object
        """
        with self.lock:
            obj = None

            if self.pool:
                obj = self.pool.pop()

                if self.config.enable_validation:
                    if hasattr(obj, "validate"):
                        if not obj.validate():
                            self.stats.validation_failures += 1
                            obj = None
            else:
                # Try to create new object, retrying on factory failures or validation failures
                max_retries = 3
                for attempt in range(max_retries):
                    if self.stats.current_size >= self.config.max_size:
                        break

                    try:
                        obj = self.factory()
                        self.stats.total_created += 1
                        self.stats.current_size += 1
                        self.stats.peak_size = max(self.stats.peak_size, self.stats.current_size)

                        # Validate newly created objects too
                        if self.config.enable_validation:
                            if hasattr(obj, "validate"):
                                if not obj.validate():
                                    self.stats.validation_failures += 1
                                    self.stats.current_size -= 1
                                    obj = None
                                    if attempt < max_retries - 1:
                                        continue  # Retry on validation failure

                        if obj is not None:
                            break  # Successfully created and validated
                    except Exception:
                        if attempt == max_retries - 1:
                            pass  # Last attempt failed, return None
                        continue  # Retry on factory exception

            if obj is not None:
                obj_id = id(obj)
                self.in_use[obj_id] = obj
                self.stats.total_acquired += 1
                self.stats.current_available = len(self.pool)

            return obj

    def release(self, obj: T):
        """
        Release object back to pool.

        Args:
            obj: Object to release
        """
        with self.lock:
            obj_id = id(obj)

            if obj_id not in self.in_use:
                return

            del self.in_use[obj_id]

            if len(self.pool) < self.config.max_size:
                try:
                    if hasattr(obj, "reset"):
                        obj.reset()

                    self.pool.append(obj)
                    self.stats.total_released += 1
                    self.stats.current_available = len(self.pool)
                except Exception:
                    self.stats.current_size -= 1
            else:
                self.stats.current_size -= 1

            self.stats.current_available = len(self.pool)

    def clear(self):
        """Clear all objects from pool."""
        with self.lock:
            self.pool.clear()
            self.in_use.clear()
            self.stats.current_size = 0
            self.stats.current_available = 0

    def get_stats(self) -> Dict[str, Any]:
        """
        Get pool statistics.

        Returns:
            Statistics dictionary
        """
        with self.lock:
            return {
                "total_acquired": self.stats.total_acquired,
                "total_released": self.stats.total_released,
                "total_created": self.stats.total_created,
                "current_size": self.stats.current_size,
                "current_available": self.stats.current_available,
                "current_in_use": len(self.in_use),
                "peak_size": self.stats.peak_size,
                "utilization_rate": f"{self.stats.utilization_rate():.2%}",
                "validation_failures": self.stats.validation_failures,
            }

    def shrink(self):
        """Shrink pool to optimal size."""
        with self.lock:
            target_size = max(
                self.config.initial_size, int(self.stats.peak_size * self.config.shrink_threshold)
            )

            while len(self.pool) > target_size:
                self.pool.pop()
                self.stats.current_size -= 1

            self.stats.current_available = len(self.pool)

    def optimize(self):
        """Optimize pool size."""
        with self.lock:
            utilization = self.stats.utilization_rate()

            if utilization < self.config.shrink_threshold:
                self.shrink()


class PooledStringBuilder:
    """Pooled string builder for efficient string concatenation."""

    def __init__(self):
        self.parts = []
        self.length = 0

    def append(self, text: str):
        """Append text to builder."""
        self.parts.append(text)
        self.length += len(text)

    def build(self) -> str:
        """Build final string."""
        return "".join(self.parts)

    def reset(self):
        """Reset builder."""
        self.parts.clear()
        self.length = 0

    def validate(self) -> bool:
        """Validate builder state."""
        return self.length == sum(len(p) for p in self.parts)


class StringBuilderPool:
    """Pool for string builders."""

    _instance: Optional["StringBuilderPool"] = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._pool = ObjectPool(
                        lambda: PooledStringBuilder(),
                        ObjectPoolConfig(initial_size=10, max_size=100),
                    )
        return cls._instance

    def acquire(self) -> PooledStringBuilder:
        """Acquire string builder from pool."""
        return self._pool.acquire() or PooledStringBuilder()

    def release(self, builder: PooledStringBuilder):
        """Release string builder back to pool."""
        self._pool.release(builder)


class PagedContentBuffer:
    """Pooled buffer for paged content."""

    def __init__(self):
        self.pages: List[str] = []
        self.metadata: Dict[str, Any] = {}

    def add_page(self, page: str):
        """Add page to buffer."""
        self.pages.append(page)

    def get_pages(self) -> List[str]:
        """Get all pages."""
        return self.pages

    def reset(self):
        """Reset buffer."""
        self.pages.clear()
        self.metadata.clear()

    def validate(self) -> bool:
        """Validate buffer state."""
        return len(self.pages) >= 0


class ContentBufferPool:
    """Pool for content buffers."""

    _instance: Optional["ContentBufferPool"] = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._pool = ObjectPool(
                        lambda: PagedContentBuffer(), ObjectPoolConfig(initial_size=5, max_size=50)
                    )
        return cls._instance

    def acquire(self) -> PagedContentBuffer:
        """Acquire buffer from pool."""
        return self._pool.acquire() or PagedContentBuffer()

    def release(self, buffer: PagedContentBuffer):
        """Release buffer back to pool."""
        self._pool.release(buffer)


class PoolManager:
    """Manager for multiple object pools."""

    def __init__(self):
        self.pools: Dict[str, ObjectPool] = {}
        self.lock = threading.RLock()

    def register_pool(self, name: str, pool: ObjectPool):
        """
        Register a pool.

        Args:
            name: Pool name
            pool: Object pool
        """
        with self.lock:
            self.pools[name] = pool

    def get_pool(self, name: str) -> Optional[ObjectPool]:
        """
        Get pool by name.

        Args:
            name: Pool name

        Returns:
            Object pool or None
        """
        with self.lock:
            return self.pools.get(name)

    def optimize_all(self):
        """Optimize all registered pools."""
        with self.lock:
            for pool in self.pools.values():
                pool.optimize()

    def clear_all(self):
        """Clear all registered pools."""
        with self.lock:
            for pool in self.pools.values():
                pool.clear()

    def get_all_stats(self) -> Dict[str, Dict[str, Any]]:
        """
        Get statistics for all pools.

        Returns:
            Dictionary of pool statistics
        """
        with self.lock:
            return {name: pool.get_stats() for name, pool in self.pools.items()}


_global_pool_manager = PoolManager()


def get_pool_manager() -> PoolManager:
    """Get global pool manager."""
    return _global_pool_manager


def register_global_pool(name: str, pool: ObjectPool):
    """Register pool with global manager."""
    _global_pool_manager.register_pool(name, pool)


def get_global_pool(name: str) -> Optional[ObjectPool]:
    """Get pool from global manager."""
    return _global_pool_manager.get_pool(name)
