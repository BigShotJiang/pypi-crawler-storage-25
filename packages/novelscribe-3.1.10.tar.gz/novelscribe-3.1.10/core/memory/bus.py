"""MemoryBus — unified facade for the memory system."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from core.memory.conversation_memory import ConversationMemory
from core.memory.entity_extractor import EntityExtractor
from core.memory.generation_learning import GenerationLearning
from core.memory.knowledge_graph import KnowledgeGraph
from core.memory.models import MemoryConfig
from core.memory.novel_wiki import NovelWiki


class MemoryBus:
    def __init__(
        self,
        project_path: Path,
        config: Optional[MemoryConfig] = None,
        llm_client: Optional[Any] = None,
    ) -> None:
        self._project = Path(project_path)
        self._config = config or MemoryConfig()
        self._llm = llm_client
        self._graph = KnowledgeGraph(self._project / "memory" / "graph")
        self._wiki = NovelWiki(self._project, graph=self._graph, llm_client=llm_client)
        self._conversations = ConversationMemory(self._project)
        self._learning = GenerationLearning(self._project)
        self._extractor = EntityExtractor(llm_client)

    def index(
        self,
        artifact_type: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
        summary: Optional[Any] = None,
    ) -> None:
        meta = metadata or {}
        if summary:
            nodes, edges = self._extractor.extract_from_summary(summary)
        elif artifact_type == "characters":
            nodes, edges = self._extractor.extract_from_characters(content)
        elif artifact_type == "world":
            nodes, edges = self._extractor.extract_from_world(content)
        elif artifact_type == "outline":
            nodes, edges = self._extractor.extract_from_outline(content)
        else:
            nodes, edges = [], []

        for node in nodes:
            self._graph.add_node(node)
        for edge in edges:
            self._graph.add_edge(edge)

        self._wiki.ingest(
            artifact_type=artifact_type,
            content=content,
            metadata={**meta, "artifact_id": meta.get("artifact_id", "")},
            summary=summary,
        )

    def retrieve(
        self,
        agent_name: str,
        query: str,
        max_tokens: int = 2000,
    ) -> List[Dict[str, Any]]:
        return self._wiki.query(query, agent_name, max_tokens)

    def get_wiki(self) -> NovelWiki:
        return self._wiki

    def get_graph(self) -> KnowledgeGraph:
        return self._graph

    def get_conversations(self) -> ConversationMemory:
        return self._conversations

    def get_learning(self) -> GenerationLearning:
        return self._learning

    def get_extractor(self) -> EntityExtractor:
        return self._extractor
