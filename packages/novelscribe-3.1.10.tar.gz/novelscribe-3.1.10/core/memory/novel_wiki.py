"""NovelWiki — LLM-maintained structured wiki for novel knowledge."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from core.memory.models import WikiIssue, WikiPage, WikiPageType
from core.utils import ensure_directories


class NovelWiki:
    WIKI_SUBDIRS = ("entities", "threads", "chapters", "concepts")

    def __init__(
        self,
        project_path: Path,
        graph: Optional[Any] = None,
        **_kwargs: Any,
    ) -> None:
        self._path = Path(project_path) / "wiki"
        self._graph = graph
        self._ensure_directories()
        self._index_cache: Optional[str] = None

    def _ensure_directories(self) -> None:
        ensure_directories(*(self._path / subdir for subdir in self.WIKI_SUBDIRS))
        if not (self._path / "index.md").exists():
            (self._path / "index.md").write_text("# Novel Wiki Index\n\n> Auto-generated index.\n")
        if not (self._path / "log.md").exists():
            (self._path / "log.md").write_text("# Wiki Change Log\n\n")

    _SUBDIR_MAP = {
        "entity": "entities",
        "thread": "threads",
        "chapter": "chapters",
        "concept": "concepts",
    }
    _SUBDIR_REVERSE = {v: k for k, v in _SUBDIR_MAP.items()}

    def _page_id_to_path(self, page_id: str) -> Path:
        if page_id == "overview":
            return self._path / "overview.md"
        parts = page_id.split(".", 1)
        if len(parts) == 2:
            subdir, filename = parts
            resolved = self._SUBDIR_MAP.get(subdir, f"{subdir}s")
            return self._path / resolved / f"{filename}.md"
        return self._path / f"{page_id}.md"

    def _path_to_page_id(self, file_path: Path) -> str:
        try:
            rel = file_path.relative_to(self._path)
            parts = rel.parts
            if len(parts) == 2:
                subdir = parts[0]
                singular = self._SUBDIR_REVERSE.get(subdir, subdir.rstrip("s"))
                return f"{singular}.{parts[1][:-3]}"
            return rel.stem
        except ValueError:
            return file_path.stem

    def get_page(self, page_id: str) -> Optional[str]:
        path = self._page_id_to_path(page_id)
        if path.exists():
            return path.read_text()
        return None

    def update_page(self, page_id: str, content: str) -> None:
        path = self._page_id_to_path(page_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        self._index_cache = None

    def search_index(self, keywords: List[str]) -> List[WikiPage]:
        results = []
        index_path = self._path / "index.md"
        if not index_path.exists():
            return results
        _ = index_path.read_text()
        pages = self.get_all_pages()
        for page in pages:
            if any(
                kw.lower() in page.title.lower() or kw.lower() in page.file_path.lower()
                for kw in keywords
            ):
                results.append(page)
        return results

    def get_all_pages(self) -> List[WikiPage]:
        results = []
        for subdir in self.WIKI_SUBDIRS:
            dir_path = self._path / subdir
            if not dir_path.exists():
                continue
            for md_file in dir_path.glob("*.md"):
                frontmatter = self._parse_frontmatter(md_file.read_text())
                if frontmatter:
                    results.append(
                        WikiPage(
                            page_id=self._path_to_page_id(md_file),
                            page_type=WikiPageType(frontmatter.get("type", "entity")),
                            title=frontmatter.get("title", md_file.stem),
                            file_path=str(md_file.relative_to(self._path)),
                            last_updated=datetime.now(),
                            tags=frontmatter.get("tags", []),
                        )
                    )
        return results

    def _parse_frontmatter(self, content: str) -> Dict[str, Any]:
        match = re.match(r"^---\n(.*?)\n---", content, re.DOTALL)
        if not match:
            return {}
        result = {}
        for line in match.group(1).split("\n"):
            if ":" in line:
                key, val = line.split(":", 1)
                result[key.strip()] = val.strip().strip('"[]')
        return result

    def rebuild_index(self) -> None:
        pages = self.get_all_pages()
        lines = ["# Novel Wiki Index\n\n"]
        by_type: Dict[str, List[WikiPage]] = {}
        for page in pages:
            by_type.setdefault(str(page.page_type.value), []).append(page)
        for ptype, ppages in by_type.items():
            lines.append(f"## {ptype.capitalize()} ({len(ppages)} pages)\n")
            for page in ppages:
                lines.append(f"- [[{page.page_id}]] — {page.title}\n")
            lines.append("\n")
        (self._path / "index.md").write_text("".join(lines))

    def append_log(self, entry: str) -> None:
        log_path = self._path / "log.md"
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_path.write_text(log_path.read_text() + f"- [{timestamp}] {entry}\n")

    def ingest(
        self,
        artifact_type: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
        summary: Optional[Any] = None,
    ) -> List[str]:
        """Ingest an artifact and create/update wiki pages.

        Handles multiple artifact types:
        - characters: creates entity pages for each character
        - outline: creates overview page with plot structure
        - world: creates concept pages for locations and concepts
        - chapter: creates chapter companion page
        - summary: updates chapter companion page with summary data

        Args:
            artifact_type: Type of artifact being ingested.
            content: The artifact content text.
            metadata: Optional metadata dict.
            summary: Optional structured summary data (e.g., ChapterSummary dict).

        Returns:
            List of updated wiki page paths.
        """
        updated = []
        meta = metadata or {}

        if artifact_type == "characters":
            updated = self._ingest_characters(content, summary)
        elif artifact_type == "outline":
            updated = self._ingest_outline(content, meta)
        elif artifact_type == "world":
            updated = self._ingest_world(content, meta)
        elif artifact_type == "chapter":
            updated = self._ingest_chapter(content, meta)
        elif artifact_type == "summary":
            updated = self._ingest_summary(content, summary, meta)

        self.append_log(f"ingest({artifact_type}): {len(updated)} pages updated")
        return updated

    def _ingest_characters(self, content: str, summary: Optional[Any] = None) -> List[str]:
        """Create entity pages for characters from summary data."""
        updated = []
        if summary:
            for char_name in summary.get("characters", {}).keys():
                page_id = f"entity.{char_name.lower().replace(' ', '-')}"
                page_content = (
                    f"---\npage_id: {page_id}\ntype: entity\n"
                    f"title: {char_name}\ntags: [character]\n---\n\n"
                    f"# {char_name}\n\nCharacter from characters.\n"
                )
                self.update_page(page_id, page_content)
                updated.append(str(self._page_id_to_path(page_id)))
        return updated

    def _ingest_outline(self, content: str, metadata: Dict[str, Any]) -> List[str]:
        """Create overview page with plot structure from outline."""
        page_id = "overview"
        title = metadata.get("title", "Plot Overview")
        page_content = (
            f"---\npage_id: {page_id}\ntype: overview\n"
            f"title: {title}\ntags: [outline, plot]\n---\n\n"
            f"# {title}\n\n{content}\n"
        )
        self.update_page(page_id, page_content)
        return [str(self._page_id_to_path(page_id))]

    def _ingest_world(self, content: str, metadata: Dict[str, Any]) -> List[str]:
        """Create concept pages for world-building elements."""
        updated = []
        # Extract location/concept headings from content
        heading_pattern = re.compile(r"^##\s+(.+)$", re.MULTILINE)
        headings = heading_pattern.findall(content)

        for heading in headings:
            name = heading.strip()
            page_id = f"concept.{name.lower().replace(' ', '-')}"
            # Extract section content under this heading
            section = self._extract_section(content, name)
            page_content = (
                f"---\npage_id: {page_id}\ntype: concept\n"
                f"title: {name}\ntags: [world]\n---\n\n"
                f"# {name}\n\n{section}\n"
            )
            self.update_page(page_id, page_content)
            updated.append(str(self._page_id_to_path(page_id)))

        # Also create a general world overview if no headings found
        if not headings:
            page_id = "concept.world-overview"
            page_content = (
                f"---\npage_id: {page_id}\ntype: concept\n"
                f"title: World Overview\ntags: [world]\n---\n\n"
                f"# World Overview\n\n{content}\n"
            )
            self.update_page(page_id, page_content)
            updated.append(str(self._page_id_to_path(page_id)))

        return updated

    def _ingest_chapter(self, content: str, metadata: Dict[str, Any]) -> List[str]:
        """Create chapter companion page."""
        chapter_num = metadata.get("chapter_number", metadata.get("artifact_id", "unknown"))
        page_id = f"chapter.chapter-{chapter_num}"
        title = metadata.get("title", f"Chapter {chapter_num}")
        page_content = (
            f"---\npage_id: {page_id}\ntype: chapter\n"
            f"title: {title}\ntags: [chapter, chapter-{chapter_num}]\n---\n\n"
            f"# {title}\n\n{content[:2000]}\n"
        )
        self.update_page(page_id, page_content)
        return [str(self._page_id_to_path(page_id))]

    def _ingest_summary(
        self,
        content: str,
        summary: Optional[Any],
        metadata: Dict[str, Any],
    ) -> List[str]:
        """Update chapter companion page with summary data."""
        updated = []
        if summary:
            chapter_num = summary.get("chapter_number", metadata.get("chapter_number", "unknown"))
        else:
            chapter_num = metadata.get("chapter_number", "unknown")
        page_id = f"chapter.chapter-{chapter_num}"

        summary_text = content if content else f"Summary for chapter {chapter_num}."
        page_content = (
            f"---\npage_id: {page_id}\ntype: chapter\n"
            f"title: Chapter {chapter_num} Summary\n"
            f"tags: [chapter, chapter-{chapter_num}, summary]\n---\n\n"
            f"# Chapter {chapter_num} Summary\n\n{summary_text}\n"
        )
        self.update_page(page_id, page_content)
        updated.append(str(self._page_id_to_path(page_id)))

        # Also create entity pages for characters mentioned in summary
        if summary and isinstance(summary, dict):
            for char_name in summary.get("characters", {}).keys():
                entity_id = f"entity.{char_name.lower().replace(' ', '-')}"
                existing = self.get_page(entity_id)
                if not existing:
                    entity_content = (
                        f"---\npage_id: {entity_id}\ntype: entity\n"
                        f"title: {char_name}\ntags: [character]\n---\n\n"
                        f"# {char_name}\n\nCharacter appearing in chapter {chapter_num}.\n"
                    )
                    self.update_page(entity_id, entity_content)
                    updated.append(str(self._page_id_to_path(entity_id)))

        return updated

    def _extract_section(self, content: str, heading: str) -> str:
        """Extract the text under a markdown heading until the next heading."""
        lines = content.split("\n")
        capturing = False
        section_lines: List[str] = []
        for line in lines:
            if line.strip().startswith("## ") and heading in line:
                capturing = True
                continue
            elif line.strip().startswith("## ") and capturing:
                break
            elif capturing:
                section_lines.append(line)
        return "\n".join(section_lines).strip() or f"Details about {heading}."

    def query(
        self,
        query_text: str,
        agent_name: str,
        max_tokens: int = 2000,
    ) -> List[Dict[str, Any]]:
        keywords = [w.strip() for w in query_text.split() if w.strip()]
        if not keywords:
            return []
        pages = self.search_index(keywords)
        results = []
        current_tokens = 0
        for page in pages:
            content = self.get_page(page.page_id)
            if content is None:
                continue
            estimated = len(content) // 4
            if current_tokens + estimated > max_tokens:
                break
            results.append(
                {
                    "source": f"wiki.{page.page_id}",
                    "content": content,
                    "token_count": estimated,
                }
            )
            current_tokens += estimated
        return results

    def lint(self) -> List[WikiIssue]:
        issues = []
        all_pages = self.get_all_pages()
        all_page_ids = {p.page_id for p in all_pages}
        wikilink_pattern = re.compile(r"\[\[([^\]]+)\]\]")
        all_links: Set[str] = set()
        for page in all_pages:
            content = self.get_page(page.page_id)
            if content:
                for match in wikilink_pattern.finditer(content):
                    linked = match.group(1)
                    all_links.add(linked)
                    if linked not in all_page_ids:
                        issues.append(
                            WikiIssue(
                                issue_type="broken_wikilink",
                                severity="error",
                                description=f"Broken wikilink: [[{linked}]]",
                                page_id=page.page_id,
                            )
                        )
        for page in all_pages:
            content = self.get_page(page.page_id)
            if content:
                linked_from_content = {m.group(1) for m in wikilink_pattern.finditer(content)}
                has_inbound = any(
                    linked in all_links and linked != page.page_id
                    for linked in [page.page_id] + list(linked_from_content)
                )
                if not has_inbound and len(all_pages) > 1:
                    issues.append(
                        WikiIssue(
                            issue_type="orphan_page",
                            severity="info",
                            description=f"Orphan page: no other pages link to {page.page_id}",
                            page_id=page.page_id,
                        )
                    )
        return issues
