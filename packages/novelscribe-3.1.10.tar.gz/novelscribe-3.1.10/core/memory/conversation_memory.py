"""Conversation Memory — append-only session journal for generation conversations.

Tracks multi-phase generation sessions with events for session lifecycle,
agent calls, phase transitions, and human feedback.

Storage:
    .novels/<project>/memory/conversations/
    ├── sessions/
    │   ├── sess-20260416-120000.jsonl
    │   └── latest.json -> sess-20260416-120000.jsonl  (symlink)
    └── index.json              # session metadata index
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from core.memory.models import ConversationEvent

logger = logging.getLogger(__name__)


class ConversationMemory:
    """Append-only session journal for generation conversations.

    Each session is a single JSONL file. Events are appended atomically.
    A latest.json symlink points to the most recent session file.
    """

    def __init__(self, project_path: Path) -> None:
        """Initialize conversation memory.

        Args:
            project_path: Path to the novel project directory.
        """
        self._path = project_path / "memory" / "conversations" / "sessions"
        self._path.mkdir(parents=True, exist_ok=True)
        self._index_path = self._path.parent / "index.json"
        self._latest_path = self._path / "latest.json"

    def start_session(self, project: str, mode: str) -> str:
        """Start a new generation session.

        Creates a new JSONL file with a session_start event. Updates
        latest.json symlink to point to this session.

        Args:
            project: Project name.
            mode: Generation mode (e.g., "autonomous", "interactive").

        Returns:
            Session ID string (e.g., "sess-20260416-120000").
        """
        session_id = f"sess-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:8]}"

        start_event = ConversationEvent(
            event_id=f"{session_id}-0",
            session_id=session_id,
            timestamp=datetime.now(timezone.utc),
            event_type="session_start",
            content=f"Session started for project '{project}' in mode '{mode}'",
            metadata={"project": project, "mode": mode},
        )
        self.record_event(start_event)

        # Update latest.json symlink
        self._update_latest(session_id)

        return session_id

    def _update_latest(self, session_id: str) -> None:
        """Update latest.json symlink to point to the given session."""
        try:
            if self._latest_path.exists() or self._latest_path.is_symlink():
                self._latest_path.unlink()
            self._latest_path.symlink_to(f"{session_id}.jsonl")
        except (OSError, NotImplementedError):
            # Fallback for environments that don't support symlinks
            with open(self._index_path, "w", encoding="utf-8") as f:
                json.dump({"latest": session_id}, f)

    def record_event(self, event: ConversationEvent) -> None:
        """Record an event to the current session.

        Appends event as a single JSON line to the session file.

        Args:
            event: ConversationEvent to record.
        """
        session_file = self._path / f"{event.session_id}.jsonl"
        with open(session_file, "a") as f:
            f.write(event.model_dump_json() + "\n")

    def get_session(self, session_id: str) -> List[ConversationEvent]:
        """Get all events for a specific session.

        Args:
            session_id: Session identifier.

        Returns:
            List of ConversationEvent instances.
        """
        session_file = self._path / f"{session_id}.jsonl"
        if not session_file.exists():
            return []
        events = []
        with open(session_file) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                events.append(ConversationEvent(**json.loads(line)))
        return events

    def get_latest_session(self) -> Optional[List[ConversationEvent]]:
        """Get events from the latest session.

        Returns:
            List of ConversationEvent instances, or None if no sessions exist.
        """
        latest_session_id = self._get_latest_session_id()
        if latest_session_id is None:
            return None
        return self.get_session(latest_session_id)

    def _get_latest_session_id(self) -> Optional[str]:
        """Resolve the latest session ID from symlink or index."""
        if self._latest_path.exists():
            try:
                target = os.readlink(str(self._latest_path))
                return target.replace(".jsonl", "")
            except (OSError, NotImplementedError):
                logger.debug("Failed to read symlink at %s", self._latest_path)
        if self._index_path.exists():
            try:
                with open(self._index_path) as f:
                    data = json.load(f)
                    return data.get("latest")
            except (json.JSONDecodeError, OSError):
                logger.debug("Failed to read session index from %s", self._index_path)
        return None

    def get_phase_history(self, phase: str) -> List[ConversationEvent]:
        """Get all events for a specific phase across sessions.

        Scans all session files for events matching the given phase.

        Args:
            phase: Phase name to filter by.

        Returns:
            List of ConversationEvent instances ordered chronologically.
        """
        all_events = []
        for session_file in self._get_all_session_files():
            try:
                with open(session_file) as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        event = ConversationEvent(**json.loads(line))
                        if event.phase == phase:
                            all_events.append(event)
            except (json.JSONDecodeError, OSError):
                continue
        all_events.sort(key=lambda e: e.timestamp)
        return all_events

    def get_agent_history(self, agent_name: str, limit: int = 10) -> List[ConversationEvent]:
        """Get recent events for a specific agent.

        Args:
            agent_name: Agent name to filter by.
            limit: Maximum number of events to return.

        Returns:
            List of most recent ConversationEvent instances for this agent.
        """
        all_events = []
        for session_file in self._get_all_session_files():
            try:
                with open(session_file) as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        event = ConversationEvent(**json.loads(line))
                        if event.agent_name == agent_name:
                            all_events.append(event)
            except (json.JSONDecodeError, OSError):
                continue
        # Most recent first
        all_events.sort(key=lambda e: e.timestamp, reverse=True)
        return all_events[:limit]

    def to_context_string(
        self,
        session_id: Optional[str] = None,
        max_tokens: int = 1000,
    ) -> str:
        """Serialize recent conversation for agent context.

        Formats the last N events as a readable summary string.
        Truncates to fit within max_tokens budget.

        Args:
            session_id: Optional session to serialize. None uses latest.
            max_tokens: Maximum token budget for the output.

        Returns:
            Formatted conversation summary string.
        """
        if session_id is None:
            events = self.get_latest_session()
            if events is None:
                return ""
        else:
            events = self.get_session(session_id)
            if not events:
                return ""

        lines = []
        current_tokens = 0
        for event in events:
            # Format: "- [{timestamp}] {event_type}: {content}"
            ts = event.timestamp.strftime("%Y-%m-%d %H:%M")
            content = event.content[:200] + ("..." if len(event.content) > 200 else "")
            line = f"- [{ts}] {event.event_type}"
            if event.agent_name:
                line += f" ({event.agent_name})"
            if content:
                line += f": {content}"
            line += "\n"

            estimated_tokens = len(line) // 4
            if current_tokens + estimated_tokens > max_tokens:
                break
            lines.append(line)
            current_tokens += estimated_tokens

        return "".join(lines) if lines else ""

    def _get_all_session_files(self) -> List[Path]:
        """Get all session JSONL files sorted by modification time.

        Returns:
            List of Path objects for session files, most recent last.
        """
        if not self._path.exists():
            return []
        files = [f for f in self._path.iterdir() if f.suffix == ".jsonl"]
        files.sort(key=lambda f: f.stat().st_mtime)
        return files
