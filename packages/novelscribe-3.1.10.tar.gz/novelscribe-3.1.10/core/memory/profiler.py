"""
Memory Profiler Implementation for Phase 4.3

Provides comprehensive memory profiling, leak detection, and
performance monitoring for the novel_harness system.
"""

import gc
import logging
import sys
import threading
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

logger = logging.getLogger(__name__)


@dataclass
class MemorySnapshot:
    """Snapshot of memory usage at a point in time."""

    timestamp: datetime
    total_memory_mb: float
    component_usage: Dict[str, float]
    object_counts: Dict[str, int]
    gc_stats: Dict[str, Any]
    available_memory_mb: float
    system_memory_mb: float

    def __sub__(self, other: "MemorySnapshot") -> Dict[str, float]:
        """Calculate memory difference between snapshots."""
        delta = self.total_memory_mb - other.total_memory_mb
        component_delta = {
            comp: self.component_usage.get(comp, 0) - other.component_usage.get(comp, 0)
            for comp in set(self.component_usage) | set(other.component_usage)
        }

        return {
            "total_delta_mb": delta,
            "component_delta_mb": component_delta,
            "time_delta_seconds": (self.timestamp - other.timestamp).total_seconds(),
        }


class MemoryProfilerConfig(BaseModel):
    """Configuration for memory profiler."""

    enabled: bool = True
    snapshot_interval_seconds: int = 60
    max_snapshots: int = 1000
    track_object_counts: bool = True
    track_gc_stats: bool = True
    component_filter: Optional[List[str]] = None
    auto_cleanup: bool = True


class MemoryProfiler:
    """
    Comprehensive memory profiling system.

    Features:
    - Real-time memory tracking
    - Component-level breakdown
    - Object instance counting
    - Garbage collection monitoring
    - Leak detection
    - Historical comparisons
    """

    def __init__(self, config: Optional[MemoryProfilerConfig] = None):
        """
        Initialize memory profiler.

        Args:
            config: Profiler configuration
        """
        self.config = config or MemoryProfilerConfig()

        self.snapshots: List[MemorySnapshot] = []
        self.component_trackers: Dict[str, float] = {}
        self.object_trackers: Dict[str, int] = {}

        self.profiling = False
        self.snapshot_thread: Optional[threading.Thread] = None
        self.stop_event = threading.Event()

        self._initialize_tracking()

    def _initialize_tracking(self):
        """Initialize tracking for known components."""
        self.component_trackers = {
            "context_manager": 0.0,
            "chapter_cache": 0.0,
            "summary_store": 0.0,
            "multi_chapter_manager": 0.0,
            "llm_client": 0.0,
        }

    def start_profiling(self, interval_seconds: Optional[int] = None):
        """
        Start automatic profiling.

        Args:
            interval_seconds: Snapshot interval (uses config if not specified)
        """
        if self.profiling:
            return

        self.profiling = True
        self.stop_event.clear()

        interval = interval_seconds or self.config.snapshot_interval_seconds

        self.snapshot_thread = threading.Thread(
            target=self._profiling_loop, args=(interval,), daemon=True
        )
        self.snapshot_thread.start()

    def stop_profiling(self):
        """Stop automatic profiling."""
        if not self.profiling:
            return

        self.profiling = False
        self.stop_event.set()

        if self.snapshot_thread:
            self.snapshot_thread.join(timeout=5.0)
            self.snapshot_thread = None

    def _profiling_loop(self, interval_seconds: int):
        """Background profiling loop."""
        while not self.stop_event.is_set():
            try:
                self.take_snapshot()
            except Exception as e:
                print(f"Error taking snapshot: {e}")

            self.stop_event.wait(interval_seconds)

    def take_snapshot(self) -> MemorySnapshot:
        """
        Take a memory snapshot.

        Returns:
            MemorySnapshot with current memory state
        """
        import os

        import psutil

        process = psutil.Process(os.getpid())
        memory_info = process.memory_info()

        snapshot = MemorySnapshot(
            timestamp=datetime.now(timezone.utc),
            total_memory_mb=memory_info.rss / 1024 / 1024,
            component_usage=self._get_component_usage(),
            object_counts=self._get_object_counts() if self.config.track_object_counts else {},
            gc_stats=self._get_gc_stats() if self.config.track_gc_stats else {},
            available_memory_mb=psutil.virtual_memory().available / 1024 / 1024,
            system_memory_mb=psutil.virtual_memory().total / 1024 / 1024,
        )

        self.snapshots.append(snapshot)

        if self.config.auto_cleanup and len(self.snapshots) > self.config.max_snapshots:
            self.snapshots = self.snapshots[-self.config.max_snapshots :]

        return snapshot

    def _get_component_usage(self) -> Dict[str, float]:
        """Get memory usage by component."""
        component_usage = {}

        for component, base_size in self.component_trackers.items():
            try:
                if component in sys.modules:
                    module = sys.modules[component]
                    size = self._estimate_module_size(module)
                    component_usage[component] = size / 1024 / 1024
            except Exception:
                component_usage[component] = base_size

        return component_usage

    def _estimate_module_size(self, obj: Any) -> int:
        """Estimate size of an object in bytes."""
        import sys

        size = sys.getsizeof(obj)

        if hasattr(obj, "__dict__"):
            size += sum(self._estimate_module_size(v) for v in obj.__dict__.values())

        if isinstance(obj, dict):
            size += sum(
                self._estimate_module_size(k) + self._estimate_module_size(v)
                for k, v in obj.items()
            )

        if isinstance(obj, (list, tuple, set)):
            size += sum(self._estimate_module_size(item) for item in obj)

        return size

    def _get_object_counts(self) -> Dict[str, int]:
        """Get object instance counts."""
        counts = {}

        for obj_type in self.object_trackers.keys():
            try:
                if obj_type in sys.modules:
                    module = sys.modules[obj_type]
                    for name, obj in vars(module).items():
                        if isinstance(obj, type):
                            count = 0
                            for ref in gc.get_referrers(obj):
                                if isinstance(ref, obj):
                                    count += 1
                            counts[name] = count
            except Exception:
                logger.debug("Failed to count object references for %s", obj_type)

        return counts

    def _get_gc_stats(self) -> Dict[str, Any]:
        """Get garbage collection statistics."""
        gc_stats = gc.get_stats()

        return {
            "collections": {
                f"gen_{i}": stats.get("collections", 0) for i, stats in enumerate(gc_stats)
            },
            "collected": {
                f"gen_{i}": stats.get("collected", 0) for i, stats in enumerate(gc_stats)
            },
            "uncollectable": {
                f"gen_{i}": stats.get("uncollectable", 0) for i, stats in enumerate(gc_stats)
            },
        }

    def get_memory_report(self) -> Dict[str, Any]:
        """
        Generate comprehensive memory report.

        Returns:
            Dictionary with memory statistics and analysis
        """
        if not self.snapshots:
            return {"error": "No snapshots available"}

        latest = self.snapshots[-1]
        oldest = self.snapshots[0]

        total_change = latest - oldest

        avg_memory = sum(s.total_memory_mb for s in self.snapshots) / len(self.snapshots)
        max_memory = max(s.total_memory_mb for s in self.snapshots)
        min_memory = min(s.total_memory_mb for s in self.snapshots)

        component_trends = {}
        for component in latest.component_usage:
            component_values = [s.component_usage.get(component, 0) for s in self.snapshots]
            component_trends[component] = {
                "current": latest.component_usage.get(component, 0),
                "average": sum(component_values) / len(component_values),
                "max": max(component_values),
                "min": min(component_values),
                "trend": (
                    "increasing" if component_values[-1] > component_values[0] else "decreasing"
                ),
            }

        return {
            "summary": {
                "current_memory_mb": latest.total_memory_mb,
                "average_memory_mb": avg_memory,
                "peak_memory_mb": max_memory,
                "min_memory_mb": min_memory,
                "total_change_mb": total_change["total_delta_mb"],
                "duration_hours": total_change["time_delta_seconds"] / 3600,
                "snapshot_count": len(self.snapshots),
            },
            "system": {
                "used_memory_mb": latest.total_memory_mb,
                "available_memory_mb": latest.available_memory_mb,
                "system_memory_mb": latest.system_memory_mb,
                "usage_percent": (latest.total_memory_mb / latest.system_memory_mb) * 100,
            },
            "components": component_trends,
            "leaks_detected": self.identify_leaks(),
        }

    def identify_leaks(self) -> List[str]:
        """
        Identify potential memory leaks.

        Returns:
            List of components or patterns that may be leaking
        """
        leaks = []

        if len(self.snapshots) < 3:
            return leaks

        recent = self.snapshots[-10:]

        for component in recent[0].component_usage:
            values = [s.component_usage.get(component, 0) for s in recent]

            if len(values) >= 3:
                if all(values[i] < values[i + 1] for i in range(len(values) - 1)):
                    increase_percent = ((values[-1] - values[0]) / max(values[0], 1)) * 100

                    if increase_percent > 20:
                        leaks.append(f"{component}: {increase_percent:.1f}% increase")

        total_values = [s.total_memory_mb for s in recent]
        if len(total_values) >= 3:
            if all(total_values[i] < total_values[i + 1] for i in range(len(total_values) - 1)):
                increase_percent = (
                    (total_values[-1] - total_values[0]) / max(total_values[0], 1)
                ) * 100

                if increase_percent > 15:
                    leaks.append(f"Total memory: {increase_percent:.1f}% increase")

        return leaks

    def get_component_stats(self) -> Dict[str, Dict[str, float]]:
        """
        Get statistics for each component.

        Returns:
            Dictionary of component statistics
        """
        if not self.snapshots:
            return {}

        component_stats = {}

        for component in self.snapshots[-1].component_usage:
            values = [s.component_usage.get(component, 0) for s in self.snapshots]

            component_stats[component] = {
                "current_mb": values[-1],
                "average_mb": sum(values) / len(values),
                "peak_mb": max(values),
                "min_mb": min(values),
                "std_dev_mb": self._calculate_std_dev(values),
            }

        return component_stats

    def _calculate_std_dev(self, values: List[float]) -> float:
        """Calculate standard deviation."""
        if len(values) < 2:
            return 0.0

        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)

        return variance**0.5

    def compare_snapshots(self, index1: int, index2: int) -> Dict[str, Any]:
        """
        Compare two snapshots.

        Args:
            index1: First snapshot index
            index2: Second snapshot index

        Returns:
            Comparison results
        """
        if index1 >= len(self.snapshots) or index2 >= len(self.snapshots):
            return {"error": "Invalid snapshot indices"}

        snapshot1 = self.snapshots[index1]
        snapshot2 = self.snapshots[index2]

        delta = snapshot2 - snapshot1

        return {
            "time_delta_seconds": delta["time_delta_seconds"],
            "memory_delta_mb": delta["total_delta_mb"],
            "component_deltas_mb": delta["component_delta_mb"],
            "snapshot1": {
                "timestamp": snapshot1.timestamp.isoformat(),
                "memory_mb": snapshot1.total_memory_mb,
            },
            "snapshot2": {
                "timestamp": snapshot2.timestamp.isoformat(),
                "memory_mb": snapshot2.total_memory_mb,
            },
        }

    def clear_snapshots(self):
        """Clear all stored snapshots."""
        self.snapshots.clear()

    def export_snapshots(self, output_path: Path):
        """
        Export snapshots to file.

        Args:
            output_path: Output file path
        """
        import json

        data = {
            "snapshots": [
                {
                    "timestamp": s.timestamp.isoformat(),
                    "total_memory_mb": s.total_memory_mb,
                    "component_usage": s.component_usage,
                    "object_counts": s.object_counts,
                    "gc_stats": s.gc_stats,
                }
                for s in self.snapshots
            ]
        }

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def track_component(self, component_name: str, size_mb: float):
        """
        Track memory usage for a component.

        Args:
            component_name: Name of component
            size_mb: Memory size in MB
        """
        self.component_trackers[component_name] = size_mb

    def get_current_usage(self) -> float:
        """
        Get current total memory usage.

        Returns:
            Memory usage in MB
        """
        if self.snapshots:
            return self.snapshots[-1].total_memory_mb

        return 0.0

    def get_memory_trend(self, window_seconds: int = 300) -> str:
        """
        Get memory usage trend.

        Args:
            window_seconds: Time window to analyze

        Returns:
            Trend: "increasing", "decreasing", or "stable"
        """
        if len(self.snapshots) < 2:
            return "stable"

        cutoff = datetime.now(timezone.utc) - timedelta(seconds=window_seconds)
        recent = [s for s in self.snapshots if s.timestamp >= cutoff]

        if len(recent) < 2:
            return "stable"

        recent = sorted(recent, key=lambda s: s.timestamp)

        increases = sum(
            1
            for i in range(1, len(recent))
            if recent[i].total_memory_mb > recent[i - 1].total_memory_mb
        )

        if increases / (len(recent) - 1) > 0.6:
            return "increasing"
        elif increases / (len(recent) - 1) < 0.4:
            return "decreasing"
        else:
            return "stable"
