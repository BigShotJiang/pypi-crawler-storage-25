"""Shared models for the NovelScribe memory system.

Pydantic models and enums used across KnowledgeGraph, NovelWiki,
ConversationMemory, and GenerationLearning components.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel


class EntityType(str, Enum):
    CHARACTER = "character"
    LOCATION = "location"
    EVENT = "event"
    OBJECT = "object"
    CONCEPT = "concept"
    ORGANIZATION = "organization"
    CHAPTER = "chapter"
    PLOT_THREAD = "plot_thread"
    RULE = "rule"


class RelationType(str, Enum):
    KNOWS = "knows"
    RELATED_TO = "related_to"
    ALLIED_WITH = "allied_with"
    OPPOSES = "opposes"
    LOVES = "loves"
    MENTORS = "mentors"
    BETRAYS = "betrays"

    # Spatial
    LOCATED_IN = "located_in"
    TRAVELS_TO = "travels_to"
    ORIGINATES_FROM = "originates_from"

    # Temporal
    OCCURS_IN = "occurs_in"
    HAPPENS_BEFORE = "happens_before"
    HAPPENS_AFTER = "happens_after"
    CAUSES = "causes"
    RESULTS_IN = "results_in"

    # Possession
    OWNS = "owns"
    USES = "uses"
    CREATES = "creates"

    # Membership
    MEMBER_OF = "member_of"
    LEADER_OF = "leader_of"

    # Plot structure
    PART_OF = "part_of"
    FORESHADOWS = "foreshadows"
    RESOLVES = "resolves"
    ADVANCES = "advances"
    CONSTRAINS = "constrains"
    VIOLATES = "violates"

    # Timeline
    PARTICIPATES_IN = "participates_in"


class WikiPageType(str, Enum):
    """Types of wiki pages."""

    ENTITY = "entity"
    THREAD = "thread"
    CHAPTER = "chapter"
    CONCEPT = "concept"
    OVERVIEW = "overview"


class TemplateKind(str, Enum):
    """Kinds of shipped global template KB pages."""

    SCENE_BLUEPRINT = "scene_blueprint"
    CHARACTER_BLUEPRINT = "character_blueprint"
    NARRATIVE_TROPE = "narrative_trope"
    PLOT_STRUCTURE = "plot_structure"


class KBContextConfig(BaseModel):
    """Configuration for global template KB context injection in writing flows."""

    enabled: bool = False
    scene_blueprint: bool = True
    character_blueprint: bool = True
    plot_structure: bool = True
    top_k: int = 3
    kb_max_tokens: int = 500

    @classmethod
    def from_meta(cls, meta: dict) -> "KBContextConfig":
        raw = meta.get("kb_context", {})
        return cls.model_validate(raw) if raw else cls()

    def to_kinds(self) -> list[str]:
        kinds = []
        if self.scene_blueprint:
            kinds.append("scene_blueprint")
        if self.character_blueprint:
            kinds.append("character_blueprint")
        if self.plot_structure:
            kinds.append("plot_structure")
        return kinds


# =============================================================================
# GRAPH MODELS
# =============================================================================


class GraphNode(BaseModel):
    """A node in the knowledge graph."""

    node_id: str
    entity_type: EntityType
    name: str
    description: str
    properties: Dict[str, Any] = {}
    first_seen_chapter: Optional[int] = None
    last_seen_chapter: Optional[int] = None
    mention_count: int = 0
    aliases: List[str] = []


class GraphEdge(BaseModel):
    """A directed edge in the knowledge graph."""

    edge_id: str
    source_id: str
    target_id: str
    relation: RelationType
    weight: float = 1.0
    chapter: Optional[int] = None
    properties: Dict[str, Any] = {}


class PlotThreadNode(GraphNode):
    """A plot thread (main plot, subplot, mystery, romance arc)."""

    thread_type: Literal["main", "subplot", "mystery", "romance", "character_arc"] = "subplot"
    status: Literal["introduced", "developing", "climax", "resolved", "abandoned"] = "introduced"
    importance: float = 0.5
    foreshadowing_ids: List[str] = []
    resolution_chapter: Optional[int] = None


class ForeshadowingEvent(BaseModel):
    """A foreshadowing plant/payoff pair."""

    event_id: str
    plant_chapter: int
    plant_content: str
    payoff_chapter: Optional[int] = None
    payoff_content: Optional[str] = None
    status: Literal["planted", "developing", "paid_off", "abandoned"] = "planted"
    thread_id: Optional[str] = None


# =============================================================================
# WIKI MODELS
# =============================================================================


class WikiPage(BaseModel):
    """Metadata for a wiki page. Content is stored as .md file."""

    page_id: str
    page_type: WikiPageType
    title: str
    file_path: str
    entity_id: Optional[str] = None
    token_count: int = 0
    last_updated: datetime
    source_artifacts: List[str] = []
    wikilinks: List[str] = []
    tags: List[str] = []
    frontmatter: Dict[str, Any] = {}


class WikiIssue(BaseModel):
    """A detected issue in the wiki."""

    issue_type: Literal[
        "orphan_page",
        "stale_page",
        "missing_entity_page",
        "broken_wikilink",
        "contradiction",
    ]
    severity: Literal["error", "warning", "info"]
    description: str
    page_id: Optional[str] = None
    suggestion: str = ""


# =============================================================================
# CONVERSATION MODELS
# =============================================================================


class ConversationEvent(BaseModel):
    """A single event in the generation conversation."""

    event_id: str
    session_id: str
    timestamp: datetime
    event_type: Literal[
        "session_start",
        "phase_start",
        "phase_complete",
        "agent_call",
        "agent_response",
        "human_feedback",
        "checkpoint",
        "session_end",
    ]
    agent_name: Optional[str] = None
    phase: Optional[str] = None
    chapter_number: Optional[int] = None
    content: str = ""
    metadata: Dict[str, Any] = {}


# =============================================================================
# LEARNING MODELS
# =============================================================================


class GenerationOutcome(BaseModel):
    """Outcome of a generation step."""

    outcome_id: str
    session_id: str
    phase: str
    agent_name: str
    chapter_number: Optional[int] = None
    timestamp: datetime
    verification_passed: bool = False
    verification_score: float = 0.0
    issues_found: List[str] = []
    issues_fixed: List[str] = []
    edit_rounds: int = 0
    human_revisions: int = 0
    tokens_used: int = 0
    generation_time_seconds: float = 0.0
    model_used: str = ""
    temperature: float = 0.7
    output_word_count: int = 0
    context_tokens_used: int = 0
    context_blocks_included: int = 0
    wiki_blocks_used: int = 0


class LearningInsight(BaseModel):
    """A learned insight from generation outcomes."""

    insight_id: str
    category: Literal[
        "model_preference",
        "temperature_tuning",
        "context_optimization",
        "agent_improvement",
        "quality_pattern",
    ]
    description: str
    confidence: float = 0.0
    evidence_count: int = 0
    applicable_agents: List[str] = []
    applicable_phases: List[str] = []
    suggestion: str = ""
    created_at: datetime
    last_reinforced: Optional[datetime] = None


# =============================================================================
# CONSISTENCY MODELS
# =============================================================================


class ConsistencyIssue(BaseModel):
    """A detected narrative inconsistency."""

    issue_type: Literal[
        "timeline_conflict",
        "character_inconsistency",
        "location_error",
        "relationship_violation",
        "plot_contradiction",
        "unresolved_reference",
        "unresolved_foreshadowing",
        "abandoned_plot_thread",
        "world_rule_violation",
    ]
    severity: Literal["error", "warning", "info"]
    description: str
    chapter: Optional[int] = None
    entity_ids: List[str] = []
    evidence: str = ""
    suggestion: str = ""


class MemoryConfig(BaseModel):
    """Memory system configuration."""

    enabled: bool = True
    wiki_path: Optional[str] = None
    graph_path: Optional[str] = None
    conversation_path: Optional[str] = None
    learning_path: Optional[str] = None
