"""Knowledge graph consistency checker — extracted from KnowledgeGraph."""

from __future__ import annotations

from typing import Any, Dict, List

from core.memory.models import (
    ConsistencyIssue,
    EntityType,
    PlotThreadNode,
    RelationType,
)


class ConsistencyChecker:
    """Validates knowledge graph consistency across 9 dimensions."""

    def __init__(
        self,
        nodes: Dict[str, Dict[str, Any]],
        edges: Dict[str, Dict[str, Any]],
        adjacency: Dict[str, List[str]],
        get_node_fn: Any,
    ) -> None:
        self._nodes = nodes
        self._edges = edges
        self._adjacency = adjacency
        self._get_node = get_node_fn

    def check_all(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        issues.extend(self.check_world_rule_violations())
        issues.extend(self.check_abandoned_plot_threads())
        issues.extend(self.check_timeline_conflicts())
        issues.extend(self.check_character_inconsistencies())
        issues.extend(self.check_location_errors())
        issues.extend(self.check_relationship_violations())
        issues.extend(self.check_plot_contradictions())
        issues.extend(self.check_unresolved_references())
        issues.extend(self.check_unresolved_foreshadowing())
        return issues

    def check_world_rule_violations(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        for edge_id, edge_data in self._edges.items():
            if edge_data.get("relation") == RelationType.VIOLATES.value:
                issues.append(
                    ConsistencyIssue(
                        issue_type="world_rule_violation",
                        severity="warning",
                        description=(
                            f"World rule violation: "
                            f"{edge_data.get('source_id', '')} violates "
                            f"{edge_data.get('target_id', '')}"
                        ),
                        entity_ids=[edge_data.get("source_id", ""), edge_data.get("target_id", "")],
                        evidence=f"Edge {edge_id}",
                    )
                )
        return issues

    def check_abandoned_plot_threads(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        for node_data in self._nodes.values():
            if node_data.get("entity_type") == EntityType.PLOT_THREAD.value:
                if node_data.get("status") == "introduced":
                    last_seen = node_data.get("last_seen_chapter")
                    if last_seen is not None and last_seen < (
                        node_data.get("first_seen_chapter", 0) + 10
                    ):
                        continue
                    issues.append(
                        ConsistencyIssue(
                            issue_type="abandoned_plot_thread",
                            severity="info",
                            description=f"Plot thread {node_data['node_id']} appears abandoned",
                            chapter=last_seen,
                            entity_ids=[node_data["node_id"]],
                        )
                    )
        return issues

    def check_timeline_conflicts(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        for edge_id, edge_data in self._edges.items():
            rel = edge_data.get("relation", "")
            ch = edge_data.get("chapter")
            if rel == RelationType.HAPPENS_BEFORE.value and ch is not None:
                source = edge_data.get("source_id", "")
                target = edge_data.get("target_id", "")
                source_node = self._get_node(source)
                target_node = self._get_node(target)
                if source_node and target_node:
                    source_last = source_node.last_seen_chapter or ch
                    target_first = target_node.first_seen_chapter or ch
                    if source_last > target_first:
                        issues.append(
                            ConsistencyIssue(
                                issue_type="timeline_conflict",
                                severity="warning",
                                description=(
                                    f"Timeline conflict: {source_node.name} "
                                    f"(last ch {source_last}) happens before "
                                    f"{target_node.name} (first ch {target_first}), "
                                    f"but appears later"
                                ),
                                chapter=ch,
                                entity_ids=[source, target],
                                evidence=f"Edge {edge_id}",
                            )
                        )
            if rel == RelationType.HAPPENS_AFTER.value and ch is not None:
                source = edge_data.get("source_id", "")
                target = edge_data.get("target_id", "")
                source_node = self._get_node(source)
                target_node = self._get_node(target)
                if source_node and target_node:
                    source_first = source_node.first_seen_chapter or ch
                    target_last = target_node.last_seen_chapter or ch
                    if source_first < target_last:
                        issues.append(
                            ConsistencyIssue(
                                issue_type="timeline_conflict",
                                severity="warning",
                                description=(
                                    f"Timeline conflict: {source_node.name} "
                                    f"(first ch {source_first}) happens after "
                                    f"{target_node.name} (last ch {target_last}), "
                                    f"but appears earlier"
                                ),
                                chapter=ch,
                                entity_ids=[source, target],
                                evidence=f"Edge {edge_id}",
                            )
                        )
        return issues

    def check_character_inconsistencies(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        character_names: Dict[str, List[str]] = {}
        for node_data in self._nodes.values():
            if node_data.get("entity_type") != EntityType.CHARACTER.value:
                continue
            name = node_data.get("name", "").lower().strip()
            node_id = node_data["node_id"]
            character_names.setdefault(name, []).append(node_id)
            for alias in node_data.get("aliases", []):
                alias_key = alias.lower().strip()
                if alias_key != name:
                    character_names.setdefault(alias_key, []).append(node_id)
        for name_key, node_ids in character_names.items():
            unique_ids = list(set(node_ids))
            if len(unique_ids) > 1:
                issues.append(
                    ConsistencyIssue(
                        issue_type="character_inconsistency",
                        severity="warning",
                        description=(
                            f"Possible character inconsistency: "
                            f"'{name_key}' refers to multiple characters: {unique_ids}"
                        ),
                        entity_ids=unique_ids,
                    )
                )
        return issues

    def check_location_errors(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        for node_data in self._nodes.values():
            if node_data.get("entity_type") != EntityType.CHARACTER.value:
                continue
            char_id = node_data["node_id"]
            locations_by_chapter: Dict[int, List[str]] = {}
            for edge_id in self._adjacency.get(char_id, []):
                edge_data = self._edges.get(edge_id)
                if not edge_data:
                    continue
                rel = edge_data.get("relation", "")
                ch = edge_data.get("chapter")
                if rel == RelationType.LOCATED_IN.value and ch is not None:
                    target = edge_data.get("target_id", "")
                    locations_by_chapter.setdefault(ch, []).append(target)
            for ch, loc_ids in locations_by_chapter.items():
                unique_locs = list(set(loc_ids))
                if len(unique_locs) > 1:
                    loc_names = []
                    for lid in unique_locs:
                        loc_node = self._get_node(lid)
                        if loc_node:
                            loc_names.append(loc_node.name)
                        else:
                            loc_names.append(lid)
                    issues.append(
                        ConsistencyIssue(
                            issue_type="location_error",
                            severity="warning",
                            description=(
                                f"Character {node_data.get('name', char_id)} is in "
                                f"multiple locations in chapter {ch}: {', '.join(loc_names)}"
                            ),
                            chapter=ch,
                            entity_ids=[char_id] + unique_locs,
                        )
                    )
        return issues

    def check_relationship_violations(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        for node_data in self._nodes.values():
            if node_data.get("entity_type") != EntityType.CHARACTER.value:
                continue
            char_id = node_data["node_id"]
            allies: Dict[str, int] = {}
            enemies: Dict[str, int] = {}
            for edge_id in self._adjacency.get(char_id, []):
                edge_data = self._edges.get(edge_id)
                if not edge_data:
                    continue
                rel = edge_data.get("relation", "")
                ch = edge_data.get("chapter")
                target = edge_data.get("target_id", "")
                if rel in (RelationType.ALLIED_WITH.value, RelationType.KNOWS.value):
                    if ch is not None:
                        allies[target] = max(allies.get(target, 0), ch)
                if rel == RelationType.OPPOSES.value:
                    if ch is not None:
                        enemies[target] = max(enemies.get(target, 0), ch)
            for enemy_id, enemy_ch in enemies.items():
                if enemy_id in allies and allies[enemy_id] > enemy_ch:
                    enemy_node = self._get_node(enemy_id)
                    name = enemy_node.name if enemy_node else enemy_id
                    issues.append(
                        ConsistencyIssue(
                            issue_type="relationship_violation",
                            severity="info",
                            description=(
                                f"Character {node_data.get('name', char_id)} is both allied with "
                                f"and opposes {name}"
                            ),
                            entity_ids=[char_id, enemy_id],
                        )
                    )
        return issues

    def check_plot_contradictions(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        for edge_id, edge_data in self._edges.items():
            rel = edge_data.get("relation", "")
            if rel not in (RelationType.CAUSES.value, RelationType.RESULTS_IN.value):
                continue
            source = edge_data.get("source_id", "")
            target = edge_data.get("target_id", "")
            ch = edge_data.get("chapter")
            for other_id, other_data in self._edges.items():
                if other_id == edge_id:
                    continue
                if other_data.get("relation") not in (RelationType.VIOLATES.value,):
                    continue
                if other_data.get("source_id") == target or other_data.get("target_id") == target:
                    source_node = self._get_node(source)
                    target_node = self._get_node(target)
                    sn = source_node.name if source_node else source
                    tn = target_node.name if target_node else target
                    issues.append(
                        ConsistencyIssue(
                            issue_type="plot_contradiction",
                            severity="warning",
                            description=(
                                f"Plot contradiction: {sn} causes/results-in {tn}, "
                                f"but {tn} is involved in a rule violation"
                            ),
                            chapter=ch,
                            entity_ids=[source, target],
                            evidence=f"Edges {edge_id}, {other_id}",
                        )
                    )
                    break
        return issues

    def check_unresolved_references(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        for edge_data in self._edges.values():
            target_id = edge_data.get("target_id", "")
            if target_id and target_id not in self._nodes:
                source_id = edge_data.get("source_id", "")
                source_node = self._get_node(source_id)
                rel = edge_data.get("relation", "")
                sn = source_node.name if source_node else source_id
                issues.append(
                    ConsistencyIssue(
                        issue_type="unresolved_reference",
                        severity="info",
                        description=(
                            f"Unresolved reference: {sn} has {rel} relationship "
                            f"to unknown entity '{target_id}'"
                        ),
                        chapter=edge_data.get("chapter"),
                        entity_ids=[source_id],
                    )
                )
        return issues

    def check_unresolved_foreshadowing(self) -> List[ConsistencyIssue]:
        issues: List[ConsistencyIssue] = []
        for node_data in self._nodes.values():
            if node_data.get("entity_type") != EntityType.PLOT_THREAD.value:
                continue
            foreshadow_ids = node_data.get("foreshadowing_ids", [])
            if not foreshadow_ids:
                continue
            for fid in foreshadow_ids:
                fs_node = self._get_node(fid)
                if fs_node is None:
                    issues.append(
                        ConsistencyIssue(
                            issue_type="unresolved_foreshadowing",
                            severity="info",
                            description=(
                                f"Plot thread {node_data.get('name', node_data['node_id'])} "
                                f"references missing foreshadowing '{fid}'"
                            ),
                            entity_ids=[node_data["node_id"]],
                        )
                    )
                elif isinstance(fs_node, PlotThreadNode):
                    if fs_node.status == "introduced" and fs_node.last_seen_chapter is not None:
                        max_ch = max(
                            (n.get("last_seen_chapter", 0) for n in self._nodes.values()),
                            default=0,
                        )
                        if isinstance(max_ch, int) and max_ch - fs_node.last_seen_chapter > 5:
                            issues.append(
                                ConsistencyIssue(
                                    issue_type="unresolved_foreshadowing",
                                    severity="info",
                                    description=(
                                        f"Foreshadowing '{fs_node.name}' has been unresolved "
                                        f"for {max_ch - fs_node.last_seen_chapter} chapters"
                                    ),
                                    chapter=fs_node.last_seen_chapter,
                                    entity_ids=[fid],
                                )
                            )
        return issues
