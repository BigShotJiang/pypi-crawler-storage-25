"""EntityExtractor — Extracts narrative entities from structured and unstructured data.

Primary path uses ChapterSummary (no LLM). LLM fallback is only for raw narrative text.
Architecture: structured-first because SummaryStore already has key_events, characters, locations.
"""

from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional, Tuple

from core.memory.models import EntityType, GraphEdge, GraphNode, PlotThreadNode, RelationType


class EntityExtractor:
    def __init__(self, llm_client: Optional[Any] = None) -> None:
        self._llm = llm_client

    def _make_node_id(self, prefix: str, name: str) -> str:
        safe = name.lower().replace(" ", "-").replace("_", "-")
        safe = re.sub(r"[^a-z0-9-]", "", safe)
        return f"{prefix}.{safe}"

    def _make_edge_id(self, source: str, target: str, relation: str) -> str:
        return f"edge.{source}.{relation}.{target}"

    def extract_from_summary(
        self,
        summary: Any,
    ) -> Tuple[List[GraphNode], List[GraphEdge]]:
        nodes: List[GraphNode] = []
        edges: List[GraphEdge] = []
        chapter_num = getattr(summary, "chapter_number", None)

        for name, role_desc in getattr(summary, "characters", {}).items():
            node_id = self._make_node_id("entity", name)
            nodes.append(
                GraphNode(
                    node_id=node_id,
                    entity_type=EntityType.CHARACTER,
                    name=name,
                    description=role_desc or f"Character in chapter {chapter_num}",
                    first_seen_chapter=chapter_num,
                    last_seen_chapter=chapter_num,
                )
            )

        for name, desc in getattr(summary, "locations", {}).items():
            node_id = self._make_node_id("loc", name)
            nodes.append(
                GraphNode(
                    node_id=node_id,
                    entity_type=EntityType.LOCATION,
                    name=name,
                    description=desc or f"Location in chapter {chapter_num}",
                    first_seen_chapter=chapter_num,
                    last_seen_chapter=chapter_num,
                )
            )

        for i, event_desc in enumerate(getattr(summary, "key_events", [])):
            node_id = self._make_node_id("event", f"ch{chapter_num}-event{i + 1}")
            nodes.append(
                GraphNode(
                    node_id=node_id,
                    entity_type=EntityType.EVENT,
                    name=f"Event in Ch{chapter_num}",
                    description=event_desc,
                    first_seen_chapter=chapter_num,
                    last_seen_chapter=chapter_num,
                )
            )

        return nodes, edges

    def extract_from_characters(
        self,
        content: str,
        chapter_num: Optional[int] = None,
    ) -> Tuple[List[GraphNode], List[GraphEdge]]:
        nodes: List[GraphNode] = []
        patterns = [
            r"(?m)^#+\s*([A-Z][a-zA-Z ]+(?:\s+[A-Z][a-zA-Z]+)*)\s*$",
            r"(?m)^\*\*(Name|Name):\*\*\s*([A-Z][a-zA-Z ]+)",
            r"(?m)^(?:[-•*])\s*([A-Z][a-zA-Z ]+):",
        ]

        for pattern in patterns:
            for match in re.finditer(pattern, content):
                groups = match.groups()
                name = groups[-1].strip() if groups else match.group(0).strip()
                if 2 < len(name) <= 30 and name[0].isupper() and len(name) >= 3:
                    node_id = self._make_node_id("entity", name)
                    start = match.start()
                    snippet = content[start : start + 200]
                    desc_match = re.search(r"(?m)^[-•]\s*(.+)$", snippet)
                    description = (
                        desc_match.group(1).strip() if desc_match else f"Character: {name}"
                    )
                    nodes.append(
                        GraphNode(
                            node_id=node_id,
                            entity_type=EntityType.CHARACTER,
                            name=name,
                            description=description,
                            first_seen_chapter=chapter_num,
                            last_seen_chapter=chapter_num,
                        )
                    )

        seen: set[str] = set()
        unique_nodes: list[GraphNode] = []
        for n in nodes:
            if n.node_id not in seen:
                seen.add(n.node_id)
                unique_nodes.append(n)

        return unique_nodes, []

    def extract_from_world(
        self,
        content: str,
        chapter_num: Optional[int] = None,
    ) -> Tuple[List[GraphNode], List[GraphEdge]]:
        nodes: List[GraphNode] = []
        patterns = [
            r"(?m)^#+\s*(?:The\s+)?([A-Z][a-zA-Z ]+(?:\s+[A-Z][a-zA-Z]+)*)\s*$",
            r"(?m)^\*\*(Location|Place|Setting):\*\*\s*([A-Z][a-zA-Z ]+)",
        ]

        for pattern in patterns:
            for match in re.finditer(pattern, content):
                groups = match.groups()
                name = groups[-1].strip() if groups else match.group(0).strip()
                if 1 < len(name) <= 40 and name[0].isupper():
                    node_id = self._make_node_id("loc", name)
                    nodes.append(
                        GraphNode(
                            node_id=node_id,
                            entity_type=EntityType.LOCATION,
                            name=name,
                            description=f"World location: {name}",
                            first_seen_chapter=chapter_num,
                            last_seen_chapter=chapter_num,
                        )
                    )

        seen: set[str] = set()
        unique_nodes: list[GraphNode] = []
        for n in nodes:
            if n.node_id not in seen:
                seen.add(n.node_id)
                unique_nodes.append(n)

        return unique_nodes, []

    def extract_from_outline(
        self,
        content: str,
        chapter_num: Optional[int] = None,
    ) -> Tuple[List[GraphNode], List[GraphEdge]]:
        nodes: List[GraphNode] = []
        patterns = [
            r"(?m)^#+\s*(Main Plot|main plot|Main Plot:)\s*$",
            r"(?m)^#+\s*(Subplot|subplot):\s*(.+)",
            r"(?m)^#+\s*(Mystery|mystery plot):\s*(.+)",
            r"(?m)^#+\s*Plot\s+(\d+):\s*(.+)",
        ]

        for pattern in patterns:
            for match in re.finditer(pattern, content):
                if len(match.groups()) >= 2:
                    thread_name = match.group(2).strip()
                elif match.group(1).strip().lower().startswith("main"):
                    thread_name = "Main Plot"
                else:
                    thread_name = match.group(1).strip()

                node_id = self._make_node_id("thread", thread_name.lower().replace(" ", "-"))
                thread_type = "main" if "main" in thread_name.lower() else "subplot"

                nodes.append(
                    PlotThreadNode(
                        node_id=node_id,
                        entity_type=EntityType.PLOT_THREAD,
                        name=thread_name,
                        description=f"Plot thread: {thread_name}",
                        thread_type=thread_type,
                        status="introduced",
                    )
                )

        seen: set[str] = set()
        unique_nodes: list[GraphNode] = []
        for n in nodes:
            if n.node_id not in seen:
                seen.add(n.node_id)
                unique_nodes.append(n)

        return unique_nodes, []

    def extract_with_llm(
        self,
        text: str,
        existing_graph: Optional[Any] = None,
    ) -> Tuple[List[GraphNode], List[GraphEdge]]:
        if self._llm is None:
            return [], []

        truncated = text[:8000] if len(text) > 8000 else text
        prompt = (
            f"Extract all named characters, locations, and significant events from this text. "
            f"For each entity include: name, type (character/location/event), description, "
            f"first_seen_chapter (if infer). For relationships: source, target, relation.\n\n"
            f"Text:\n{truncated}\n\n"
            f'Return as JSON: {{"nodes": [{{"node_id": "...", "entity_type": "...", '
            f'"name": "...", "description": "..."}}], "edges": [{{"edge_id": "...", '
            f'"source_id": "...", "target_id": "...", "relation": "..."}}]}}'
        )

        response = self._llm.generate(
            system_prompt=(
                "You are a narrative entity extraction system. Extract characters, "
                "locations, events, and their relationships from the given text. "
                "Return ONLY a JSON object with 'nodes' and 'edges' arrays."
            ),
            user_prompt=prompt,
        )

        try:
            parsed = json.loads(response.content)
            nodes = self._parse_nodes_from_json(parsed.get("nodes", []))
            edges = self._parse_edges_from_json(parsed.get("edges", []))
            return nodes, edges
        except (json.JSONDecodeError, KeyError):
            return [], []

    def _parse_nodes_from_json(self, raw_nodes: List[Dict[str, Any]]) -> List[GraphNode]:
        nodes = []
        for n in raw_nodes:
            try:
                entity_type = EntityType(n.get("entity_type", "character"))
            except ValueError:
                entity_type = EntityType.CHARACTER

            node_id = n.get("node_id") or self._make_node_id(
                entity_type.value[:4], n.get("name", "unknown")
            )

            nodes.append(
                GraphNode(
                    node_id=node_id,
                    entity_type=entity_type,
                    name=n.get("name", "Unknown"),
                    description=n.get("description", ""),
                    properties=n.get("properties", {}),
                    first_seen_chapter=n.get("first_seen_chapter"),
                    last_seen_chapter=n.get("last_seen_chapter"),
                    aliases=n.get("aliases", []),
                )
            )
        return nodes

    def _parse_edges_from_json(self, raw_edges: List[Dict[str, Any]]) -> List[GraphEdge]:
        edges = []
        for e in raw_edges:
            try:
                relation = RelationType(e.get("relation", "related_to"))
            except ValueError:
                relation = RelationType.RELATED_TO

            edge_id = e.get("edge_id") or self._make_edge_id(
                e.get("source_id", "unknown"), e.get("target_id", "unknown"), relation.value
            )

            edges.append(
                GraphEdge(
                    edge_id=edge_id,
                    source_id=e.get("source_id", ""),
                    target_id=e.get("target_id", ""),
                    relation=relation,
                    chapter=e.get("chapter"),
                    properties=e.get("properties", {}),
                )
            )
        return edges

    def extract_and_add(
        self,
        source_type: str,
        content: str,
        graph: Any,
        summary: Optional[Any] = None,
        chapter_num: Optional[int] = None,
    ) -> Tuple[int, int]:
        if source_type == "summary" and summary is not None:
            nodes, edges = self.extract_from_summary(summary)
        elif source_type == "characters":
            nodes, edges = self.extract_from_characters(content, chapter_num)
        elif source_type == "world":
            nodes, edges = self.extract_from_world(content, chapter_num)
        elif source_type == "outline":
            nodes, edges = self.extract_from_outline(content, chapter_num)
        elif source_type == "text":
            nodes, edges = self.extract_with_llm(content)
        else:
            return 0, 0

        for node in nodes:
            graph.add_node(node)
        for edge in edges:
            graph.add_edge(edge)

        return len(nodes), len(edges)
