"""Generation Learning — feedback loop for generation quality improvement."""

from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.memory.models import GenerationOutcome, LearningInsight


def _serialize_for_json(obj: Any) -> str:
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


class GenerationLearning:
    """Learning system for generation quality improvement."""

    def __init__(self, project_path: Path) -> None:
        self._path = project_path / "memory" / "learning"
        self._path.mkdir(parents=True, exist_ok=True)
        self._outcomes_file = self._path / "outcomes.jsonl"
        self._insights_file = self._path / "insights.json"
        self._stats_file = self._path / "stats.json"
        self._insights: List[Dict[str, Any]] = []
        self._load_insights()

    def record_outcome(self, outcome: GenerationOutcome) -> None:
        with open(self._outcomes_file, "a") as f:
            f.write(outcome.model_dump_json() + "\n")
        self._update_stats(outcome)

    def _load_insights(self) -> None:
        if self._insights_file.exists():
            try:
                with open(self._insights_file) as f:
                    self._insights = json.load(f)
            except (json.JSONDecodeError, OSError):
                self._insights = []

    def _load_outcomes(self, agent_name: Optional[str] = None) -> List[GenerationOutcome]:
        if not self._outcomes_file.exists():
            return []
        outcomes = []
        with open(self._outcomes_file) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                outcome = GenerationOutcome(**json.loads(line))
                if agent_name is None or outcome.agent_name == agent_name:
                    outcomes.append(outcome)
        return outcomes

    def _update_stats(self, outcome: GenerationOutcome) -> None:
        stats = {}
        if self._stats_file.exists():
            try:
                with open(self._stats_file) as f:
                    stats = json.load(f)
            except (json.JSONDecodeError, OSError):
                stats = {}

        agent = outcome.agent_name
        if agent not in stats:
            stats[agent] = {
                "total_outcomes": 0,
                "total_verification_score": 0.0,
                "total_edit_rounds": 0,
                "total_tokens": 0,
                "total_generation_time": 0.0,
                "pass_count": 0,
            }

        s = stats[agent]
        s["total_outcomes"] += 1
        s["total_verification_score"] += outcome.verification_score
        s["total_edit_rounds"] += outcome.edit_rounds
        s["total_tokens"] += outcome.tokens_used
        s["total_generation_time"] += outcome.generation_time_seconds
        if outcome.verification_passed:
            s["pass_count"] += 1

        with open(self._stats_file, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2)

    def _save_insights(self) -> None:
        with open(self._insights_file, "w", encoding="utf-8") as f:
            json.dump(self._insights, f, indent=2, default=_serialize_for_json)

    def analyze(self, agent_name: Optional[str] = None) -> List[LearningInsight]:
        new_insights: List[LearningInsight] = []
        outcomes = self._load_outcomes(agent_name)

        if not outcomes:
            return []

        by_agent: Dict[str, List[GenerationOutcome]] = defaultdict(list)
        for o in outcomes:
            by_agent[o.agent_name].append(o)

        for ag, agent_outcomes in by_agent.items():
            if len(agent_outcomes) < 5:
                continue

            by_temp: Dict[str, List[GenerationOutcome]] = defaultdict(list)
            for o in agent_outcomes:
                bucket = f"temp_{int(o.temperature * 10) / 10:.1f}"
                by_temp[bucket].append(o)

            best_temp_bucket = max(
                by_temp.keys(),
                key=lambda b: (
                    sum(o.verification_score for o in by_temp[b]) / len(by_temp[b])
                    if by_temp[b]
                    else 0
                ),
                default=None,
            )
            if best_temp_bucket and len(by_temp[best_temp_bucket]) >= 2:
                temp_val = float(best_temp_bucket.replace("temp_", ""))
                avg_score = sum(o.verification_score for o in by_temp[best_temp_bucket]) / len(
                    by_temp[best_temp_bucket]
                )
                insight = LearningInsight(
                    insight_id=f"temp-tuning-{ag}-{int(datetime.now(timezone.utc).timestamp())}",
                    category="temperature_tuning",
                    description=(
                        f"{ag} performs best at temperature "
                        f"{temp_val:.1f} (avg score: {avg_score:.2f})"
                    ),
                    confidence=min(1.0, len(agent_outcomes) / 10),
                    evidence_count=len(agent_outcomes),
                    applicable_agents=[ag],
                    applicable_phases=list({o.phase for o in agent_outcomes}),
                    suggestion=f"Consider using temperature {temp_val:.1f} for {ag}",
                    created_at=datetime.now(timezone.utc),
                )
                new_insights.append(insight)

            all_issues: Dict[str, int] = defaultdict(int)
            for o in agent_outcomes:
                for issue in o.issues_found:
                    all_issues[issue] += 1

            for issue, count in all_issues.items():
                if count >= 2:
                    insight = LearningInsight(
                        insight_id=f"quality-{ag}-{issue[:20]}-{int(datetime.now(timezone.utc).timestamp())}",
                        category="quality_pattern",
                        description=f"'{issue}' occurs {count} times with {ag}",
                        confidence=min(1.0, count / 5),
                        evidence_count=count,
                        applicable_agents=[ag],
                        applicable_phases=list({o.phase for o in agent_outcomes}),
                        suggestion=f"Review how {ag} handles '{issue}' scenarios",
                        created_at=datetime.now(timezone.utc),
                    )
                    new_insights.append(insight)

        existing_by_cat: Dict[str, Dict[str, LearningInsight]] = defaultdict(dict)
        for insight_dict in self._insights:
            try:
                ins = LearningInsight(**insight_dict)
                existing_by_cat[ins.category][ins.description[:50]] = ins
            except (KeyError, TypeError):
                continue

        for new_ins in new_insights:
            key = new_ins.description[:50]
            existing_by_cat[new_ins.category][key] = new_ins

        all_insights = []
        for cat_dict in existing_by_cat.values():
            for ins in cat_dict.values():
                all_insights.append(ins.model_dump())
        self._insights = all_insights
        if new_insights:
            self._save_insights()

        return new_insights

    def get_insights(
        self,
        agent_name: Optional[str] = None,
        phase: Optional[str] = None,
        min_confidence: float = 0.5,
    ) -> List[LearningInsight]:
        insights = []
        for insight_dict in self._insights:
            try:
                insight = LearningInsight(**insight_dict)
            except (KeyError, TypeError):
                continue
            if insight.confidence < min_confidence:
                continue
            if agent_name and agent_name not in insight.applicable_agents:
                continue
            if phase and phase not in insight.applicable_phases:
                continue
            insights.append(insight)
        return insights

    def get_agent_stats(self, agent_name: str) -> Dict[str, Any]:
        defaults = {
            "total_outcomes": 0,
            "avg_verification_score": 0.0,
            "avg_edit_rounds": 0.0,
            "total_tokens_used": 0,
            "avg_generation_time": 0.0,
            "pass_rate": 0.0,
        }
        if not self._stats_file.exists():
            return defaults
        try:
            with open(self._stats_file) as f:
                stats = json.load(f)
        except (json.JSONDecodeError, OSError):
            return defaults

        s = stats.get(agent_name)
        if s is None:
            return defaults

        count = s["total_outcomes"]
        if count == 0:
            return defaults

        return {
            "total_outcomes": count,
            "avg_verification_score": s["total_verification_score"] / count,
            "avg_edit_rounds": s["total_edit_rounds"] / count,
            "total_tokens_used": s["total_tokens"],
            "avg_generation_time": s["total_generation_time"] / count,
            "pass_rate": s["pass_count"] / count,
        }

    def to_context_string(self, agent_name: str, max_tokens: int = 500) -> str:
        insights = self.get_insights(agent_name=agent_name, min_confidence=0.5)
        if not insights:
            return ""

        lines = []
        current_tokens = 0
        for insight in insights[:5]:
            line = f"- {insight.suggestion} (confidence: {insight.confidence:.0%})\n"
            estimated_tokens = len(line) // 4
            if current_tokens + estimated_tokens > max_tokens:
                break
            lines.append(line)
            current_tokens += estimated_tokens

        return "".join(lines) if lines else ""
