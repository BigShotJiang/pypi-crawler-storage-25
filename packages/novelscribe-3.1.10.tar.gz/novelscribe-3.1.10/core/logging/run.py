"""RunLogger — structured JSONL logger for pipeline run events.

Writes one JSON object per line to ``<project>/logs/run_<timestamp>.jsonl``.
Each line is a self-contained event with a ``type`` field.

Event types::

    run_start       – pipeline begins
    phase_start     – a workflow phase begins
    agent_complete  – an agent step finishes (duration, tokens, cost)
    phase_complete  – a workflow phase finishes
    run_complete    – pipeline finishes (success or failure)
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


class RunLogger:
    """Append-only structured logger for a single pipeline run.

    Usage::

        rl = RunLogger(project_path)
        rl.emit("run_start", {"project": "my-novel"})
        rl.emit("agent_complete", {"agent": "writer", "duration_ms": 1200})
        rl.close()
    """

    def __init__(self, project_path: Path, run_id: Optional[str] = None) -> None:
        self.project_path = Path(project_path)
        self.run_id = run_id or datetime.now(timezone.utc).strftime("run_%Y%m%d_%H%M%S")
        self._file_handle: Optional[Any] = None

    def _ensure_open(self) -> Any:
        if self._file_handle is None:
            logs_dir = self.project_path / "logs"
            logs_dir.mkdir(parents=True, exist_ok=True)
            log_file = logs_dir / f"{self.run_id}.jsonl"
            self._file_handle = open(log_file, "a", encoding="utf-8")
        return self._file_handle

    def emit(self, event_type: str, data: Optional[Dict[str, Any]] = None) -> None:
        """Append a structured event line to the JSONL file."""
        entry: Dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "run_id": self.run_id,
            "type": event_type,
        }
        if data:
            entry.update(data)
        fh = self._ensure_open()
        fh.write(json.dumps(entry, default=str) + "\n")
        fh.flush()

    def close(self) -> None:
        if self._file_handle is not None:
            self._file_handle.close()
            self._file_handle = None

    @staticmethod
    def list_runs(project_path: Path) -> list[Dict[str, Any]]:
        """Return metadata for all runs in a project, newest first."""
        logs_dir = project_path / "logs"
        if not logs_dir.exists():
            return []

        runs: list[Dict[str, Any]] = []
        for f in sorted(logs_dir.glob("run_*.jsonl"), reverse=True):
            first_line: Optional[str] = None
            last_line: Optional[str] = None
            line_count = 0
            try:
                with open(f, encoding="utf-8") as fh:
                    for line in fh:
                        line = line.strip()
                        if not line:
                            continue
                        if first_line is None:
                            first_line = line
                        last_line = line
                        line_count += 1
            except Exception:
                continue

            start_event = json.loads(first_line) if first_line else {}
            end_event = json.loads(last_line) if last_line else {}

            runs.append(
                {
                    "run_id": f.stem,
                    "file": str(f),
                    "events": line_count,
                    "started_at": start_event.get("ts"),
                    "last_event": end_event.get("ts"),
                    "last_type": end_event.get("type"),
                }
            )

        return runs

    @staticmethod
    def read_run(project_path: Path, run_id: str) -> list[Dict[str, Any]]:
        """Read all events from a specific run."""
        log_file = project_path / "logs" / f"{run_id}.jsonl"
        if not log_file.exists():
            return []

        events: list[Dict[str, Any]] = []
        with open(log_file, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    try:
                        events.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return events
