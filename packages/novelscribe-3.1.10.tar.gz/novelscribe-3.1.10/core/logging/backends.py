"""
Logger Backend Implementations for Novel Harness

Provides JSON file logging and SQLite database logging backends.
"""

from __future__ import annotations

import gzip
import json
import sqlite3
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict

from .types import LLMRequest, UserAction


class JSONLogger:
    """JSON file logger for human-readable logs"""

    def __init__(self, log_dir: str = ".logs/json"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def log(self, entry: Dict[str, Any]):
        """Write log entry to JSON file"""
        with self._lock:
            date_str = datetime.now().strftime("%Y-%m-%d")
            log_file = self.log_dir / f"{date_str}.jsonl"

            with open(log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, default=str) + "\n")

    def rotate_old_logs(self, days: int = 90):
        """Compress log files older than specified days"""
        cutoff = datetime.now() - timedelta(days=days)

        for log_file in self.log_dir.glob("*.jsonl"):
            if log_file.stat().st_mtime < cutoff.timestamp():
                # Compress the file
                compressed = log_file.with_suffix(".jsonl.gz")
                with open(log_file, "rb") as f_in:
                    with gzip.open(compressed, "wb") as f_out:
                        f_out.writelines(f_in)
                log_file.unlink()


class SQLiteLogger:
    """SQLite database logger for structured queries"""

    def __init__(self, db_path: str = ".logs/logs.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
        self._lock = threading.Lock()

    def _init_db(self):
        """Initialize database schema"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # LLM Requests table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS llm_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id TEXT UNIQUE NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                project_name TEXT,
                agent_name TEXT,
                provider TEXT NOT NULL,
                model TEXT NOT NULL,
                system_prompt TEXT,
                user_prompt TEXT,
                max_tokens INTEGER,
                temperature REAL,
                input_tokens INTEGER,
                output_tokens INTEGER,
                total_tokens INTEGER,
                cost_usd REAL,
                latency_ms INTEGER,
                status TEXT NOT NULL,
                error_message TEXT,
                cache_hit INTEGER DEFAULT 0,
                metadata TEXT
            )
        """)

        # User Actions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action_id TEXT UNIQUE NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                action_type TEXT NOT NULL,
                user_command TEXT,
                project_name TEXT,
                parameters TEXT,
                result TEXT,
                execution_time_ms INTEGER,
                success INTEGER
            )
        """)

        # Token Usage Summary table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS token_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date DATE NOT NULL,
                project_name TEXT,
                provider TEXT NOT NULL,
                model TEXT NOT NULL,
                total_input_tokens INTEGER DEFAULT 0,
                total_output_tokens INTEGER DEFAULT 0,
                total_tokens INTEGER DEFAULT 0,
                total_cost_usd REAL DEFAULT 0.0,
                request_count INTEGER DEFAULT 0,
                UNIQUE(date, project_name, provider, model)
            )
        """)

        # Projects table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                project_name TEXT NOT NULL,
                action TEXT NOT NULL,
                details TEXT
            )
        """)

        # Create indexes for faster queries
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_llm_timestamp ON llm_requests(timestamp)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_llm_project ON llm_requests(project_name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_llm_provider ON llm_requests(provider)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_llm_status ON llm_requests(status)")
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_actions_timestamp ON user_actions(timestamp)"
        )
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_token_date ON token_usage(date)")

        conn.commit()
        conn.close()

    def log_llm_request(self, request: LLMRequest):
        """Log LLM request to database"""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT INTO llm_requests (
                    request_id, project_name, agent_name, provider, model,
                    system_prompt, user_prompt, max_tokens, temperature,
                    input_tokens, output_tokens, total_tokens, cost_usd,
                    latency_ms, status, error_message, cache_hit, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    request.request_id,
                    request.project_name,
                    request.agent_name,
                    request.provider,
                    request.model,
                    request.system_prompt,
                    request.user_prompt,
                    request.max_tokens,
                    request.temperature,
                    request.input_tokens,
                    request.output_tokens,
                    request.total_tokens,
                    request.cost_usd,
                    request.latency_ms,
                    request.status.value,
                    request.error_message,
                    1 if request.cache_hit else 0,
                    json.dumps(request.metadata),
                ),
            )

            conn.commit()
            conn.close()

    def log_user_action(self, action: UserAction):
        """Log user action to database"""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT INTO user_actions (
                    action_id, action_type, user_command, project_name,
                    parameters, result, execution_time_ms, success
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    action.action_id,
                    action.action_type.value,
                    action.user_command,
                    action.project_name,
                    json.dumps(action.parameters),
                    action.result,
                    action.execution_time_ms,
                    1 if action.success else 0,
                ),
            )

            conn.commit()
            conn.close()

    def log_project_event(self, project_name: str, action: str, details: Dict[str, Any]):
        """Log project event"""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT INTO projects (project_name, action, details)
                VALUES (?, ?, ?)
            """,
                (project_name, action, json.dumps(details)),
            )

            conn.commit()
            conn.close()

    def update_token_summary(self, request: LLMRequest):
        """Update daily token usage summary"""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            date_str = datetime.now().strftime("%Y-%m-%d")

            cursor.execute(
                """
                INSERT INTO token_usage (
                    date, project_name, provider, model,
                    total_input_tokens, total_output_tokens, total_tokens,
                    total_cost_usd, request_count
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(date, project_name, provider, model) DO UPDATE SET
                    total_input_tokens = total_input_tokens + excluded.total_input_tokens,
                    total_output_tokens = total_output_tokens + excluded.total_output_tokens,
                    total_tokens = total_tokens + excluded.total_tokens,
                    total_cost_usd = total_cost_usd + excluded.total_cost_usd,
                    request_count = request_count + excluded.request_count
            """,
                (
                    date_str,
                    request.project_name,
                    request.provider,
                    request.model,
                    request.input_tokens,
                    request.output_tokens,
                    request.total_tokens,
                    request.cost_usd,
                    1,
                ),
            )

            conn.commit()
            conn.close()
