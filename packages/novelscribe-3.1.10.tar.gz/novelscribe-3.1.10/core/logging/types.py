"""
Logger Type Definitions for Novel Harness

Defines enums and data classes used across the logging system.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional


class LogType(str, Enum):
    """Log entry types"""

    LLM_REQUEST = "llm_request"
    USER_ACTION = "user_action"
    SYSTEM_EVENT = "system_event"
    PROJECT_EVENT = "project_event"


class ActionType(str, Enum):
    """User action types"""

    CLI = "CLI"
    API = "API"
    WEB = "WEB"


class RequestStatus(str, Enum):
    """Request status"""

    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class LLMRequest:
    """LLM request data"""

    request_id: str
    project_name: Optional[str]
    agent_name: Optional[str]
    provider: str
    model: str
    system_prompt: str
    user_prompt: str
    max_tokens: int
    temperature: float
    input_tokens: int
    output_tokens: int
    total_tokens: int
    cost_usd: float
    latency_ms: int
    status: RequestStatus
    error_message: Optional[str] = None
    cache_hit: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class UserAction:
    """User action data"""

    action_id: str
    action_type: ActionType
    user_command: str
    project_name: Optional[str]
    parameters: Dict[str, Any]
    result: Optional[str]
    execution_time_ms: int
    success: bool
    timestamp: datetime = field(default_factory=datetime.now)
