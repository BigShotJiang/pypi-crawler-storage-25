"""Structured logging with JSON formatting and correlation context.

Provides:
- CorrelationContext: ContextVar-backed correlation ID propagation
- StructuredFormatter: JSON log record formatter
- TextFallbackFormatter: Human-readable text fallback
- configure_structured_logging(): Drop-in replacement for logging.basicConfig()
"""

import json
import logging
import sys
import uuid
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional


@dataclass
class CorrelationContext:
    """Correlation context propagated via ContextVar across async/task boundaries.

    Fields:
        trace_id: Unique identifier for the entire pipeline run
        project: Project name being processed
        phase: Current pipeline phase (e.g., 'worldbuilding', 'writing')
        step: Current step within the phase
        task_id: Task identifier for runtime execution
    """

    trace_id: str = ""
    project: str = ""
    phase: str = ""
    step: str = ""
    task_id: str = ""

    def to_dict(self) -> dict[str, str]:
        return {
            k: v
            for k, v in {
                "trace_id": self.trace_id,
                "project": self.project,
                "phase": self.phase,
                "step": self.step,
                "task_id": self.task_id,
            }.items()
            if v
        }

    def new_trace_id(self) -> "CorrelationContext":
        return CorrelationContext(
            trace_id=uuid.uuid4().hex[:16],
            project=self.project,
            phase=self.phase,
            step=self.step,
            task_id=self.task_id,
        )


_correlation_var: ContextVar[CorrelationContext] = ContextVar(
    "novelscribe_correlation",
    default=CorrelationContext(),
)


def get_correlation() -> CorrelationContext:
    return _correlation_var.get()


def set_correlation(ctx: CorrelationContext) -> None:
    _correlation_var.set(ctx)


def bind_trace_id(trace_id: Optional[str] = None) -> str:
    ctx = get_correlation()
    new_ctx = (
        ctx.new_trace_id()
        if trace_id is None
        else CorrelationContext(
            trace_id=trace_id,
            project=ctx.project,
            phase=ctx.phase,
            step=ctx.step,
            task_id=ctx.task_id,
        )
    )
    set_correlation(new_ctx)
    return new_ctx.trace_id


def bind_project(project: str) -> None:
    ctx = get_correlation()
    set_correlation(
        CorrelationContext(
            trace_id=ctx.trace_id,
            project=project,
            phase=ctx.phase,
            step=ctx.step,
            task_id=ctx.task_id,
        )
    )


def bind_phase(phase: str) -> None:
    ctx = get_correlation()
    set_correlation(
        CorrelationContext(
            trace_id=ctx.trace_id,
            project=ctx.project,
            phase=phase,
            step=ctx.step,
            task_id=ctx.task_id,
        )
    )


def bind_step(step: str) -> None:
    ctx = get_correlation()
    set_correlation(
        CorrelationContext(
            trace_id=ctx.trace_id,
            project=ctx.project,
            phase=ctx.phase,
            step=step,
            task_id=ctx.task_id,
        )
    )


def clear_correlation() -> None:
    _correlation_var.set(CorrelationContext())


class StructuredFormatter(logging.Formatter):
    """JSON log formatter enriched with correlation context.

    Output format:
    {
        "timestamp": "2026-05-04T12:34:56.789Z",
        "level": "INFO",
        "logger": "scribe",
        "message": "Starting pipeline...",
        "trace_id": "abc123",
        "project": "my_novel",
        "phase": "writing",
        "step": "chapter_1",
        "task_id": "t-001",
        "extra": {...}
    }
    """

    def format(self, record: logging.LogRecord) -> str:
        correlation = get_correlation()

        entry: dict[str, object] = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        entry.update(correlation.to_dict())

        extra_fields = {
            k: v
            for k, v in record.__dict__.items()
            if k not in logging.LogRecord("", 0, "", 0, "", (), None).__dict__
            and k not in ("message", "asctime")
        }
        if extra_fields:
            entry["extra"] = extra_fields

        if record.exc_info and record.exc_info[1] is not None:
            entry["exception"] = self.formatException(record.exc_info)

        return json.dumps(entry, default=str, ensure_ascii=False)


class TextFallbackFormatter(logging.Formatter):
    """Human-readable text formatter that appends correlation context when present."""

    def __init__(self, fmt: Optional[str] = None, datefmt: Optional[str] = None) -> None:
        if fmt is None:
            fmt = "%(levelname)s: %(message)s"
        super().__init__(fmt=fmt, datefmt=datefmt)

    def format(self, record: logging.LogRecord) -> str:
        base = super().format(record)
        correlation = get_correlation()
        ctx = correlation.to_dict()
        if ctx:
            ctx_str = " ".join(f"{k}={v}" for k, v in ctx.items())
            return f"{base} [{ctx_str}]"
        return base


def configure_structured_logging(
    *,
    level: int = logging.INFO,
    json_output: bool = False,
    stream: Optional[object] = None,
    verbose: int = 0,
    debug: bool = False,
) -> None:
    """Configure structured logging for the application.

    Args:
        level: Logging level (default INFO).
        json_output: If True, emit JSON-formatted logs via StructuredFormatter.
        stream: Output stream (default sys.stdout).
        verbose: Verbosity level for text fallback (0=message only, 1=+level, 2=+logger).
        debug: If True, set level to DEBUG.
    """
    if debug:
        level = logging.DEBUG

    if stream is None:
        stream = sys.stdout

    handler = logging.StreamHandler(stream)

    if json_output:
        handler.setFormatter(StructuredFormatter())
    else:
        if verbose == 0:
            fmt = "%(message)s"
        elif verbose == 1:
            fmt = "%(levelname)s: %(message)s"
        else:
            fmt = "%(levelname)s [%(name)s]: %(message)s"
        handler.setFormatter(TextFallbackFormatter(fmt=fmt))

    root = logging.getLogger()
    root.setLevel(level)
    root.handlers.clear()
    root.addHandler(handler)
