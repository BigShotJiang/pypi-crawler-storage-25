"""Logging subsystem — structured logging, backends, and run tracking."""

from core.llm.cost import CostCalculator
from core.llm.tracker import TokenUsageTracker

from .backends import JSONLogger, SQLiteLogger
from .logger import NovelHarnessLogger, get_logger, log_llm_request, log_user_action
from .run import RunLogger
from .structured import (
    CorrelationContext,
    StructuredFormatter,
    TextFallbackFormatter,
    bind_phase,
    bind_project,
    bind_step,
    bind_trace_id,
    clear_correlation,
    configure_structured_logging,
    get_correlation,
    set_correlation,
)
from .types import ActionType, LLMRequest, LogType, RequestStatus, UserAction

__all__ = [
    "NovelHarnessLogger",
    "get_logger",
    "log_llm_request",
    "log_user_action",
    "JSONLogger",
    "SQLiteLogger",
    "RunLogger",
    "ActionType",
    "LLMRequest",
    "LogType",
    "RequestStatus",
    "UserAction",
    "CostCalculator",
    "TokenUsageTracker",
    "CorrelationContext",
    "StructuredFormatter",
    "TextFallbackFormatter",
    "bind_trace_id",
    "bind_project",
    "bind_phase",
    "bind_step",
    "clear_correlation",
    "configure_structured_logging",
    "get_correlation",
    "set_correlation",
]
