"""
Validation System for Novel Content

This module provides a comprehensive validation framework for novel content,
including content, structure, style, and continuity validation rules.

All symbols are re-exported from focused sub-modules for backward compatibility.
"""

# Base types
# Validation engine
from core.quality.validation_engine import ValidationSystem

# Report container
from core.quality.validation_report import ValidationReport

# Concrete rule implementations
from core.quality.validation_rules import (
    AdverbOveruseRule,
    ChapterOutlineAlignmentRule,
    CharacterConsistencyRule,
    DialogueAttributionRule,
    DialogueBalanceRule,
    MaxSentenceLengthRule,
    MinimumWordCountRule,
    PassiveVoiceRule,
    SceneLengthRule,
    TimelineContinuityRule,
)
from core.quality.validation_types import RuleCategory, Severity, ValidationResult, ValidationRule

__all__ = [
    # Types
    "Severity",
    "RuleCategory",
    "ValidationRule",
    "ValidationResult",
    # Report
    "ValidationReport",
    # Rules
    "AdverbOveruseRule",
    "ChapterOutlineAlignmentRule",
    "CharacterConsistencyRule",
    "DialogueAttributionRule",
    "DialogueBalanceRule",
    "MaxSentenceLengthRule",
    "MinimumWordCountRule",
    "PassiveVoiceRule",
    "SceneLengthRule",
    "TimelineContinuityRule",
    # Engine
    "ValidationSystem",
]
