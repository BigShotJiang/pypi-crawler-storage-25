"""
Quality Gate Data Models for Novel Generation.

This module defines the Pydantic models and enums used by the quality gate system.
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class QualityLevel(str, Enum):
    """Quality gate levels."""

    BRONZE = "bronze"
    SILVER = "silver"
    GOLD = "gold"
    PLATINUM = "platinum"


class FixApproach(BaseModel):
    """Represents a fix approach for quality issues."""

    id: str
    name: str
    description: str
    best_for: List[str]
    intervention_level: str
    speed: str
    risk_level: str
    estimated_effort: str
    examples: List[str] = Field(default_factory=list)


class FixSuggestionResponse(BaseModel):
    """Response containing fix approach suggestions."""

    issue_summary: str
    failed_criteria: List[str]
    fix_approaches: List[FixApproach]
    recommended_approach: Optional[str] = None
    urgency_level: str
    estimated_fix_time: str


class GateResult(BaseModel):
    """Result of quality gate check."""

    gate_level: QualityLevel
    passed: bool
    scores: Dict[str, float]
    failed_criteria: List[str]
    recommendations: List[str]
    timestamp: datetime = Field(default_factory=datetime.now)
    overall_score: float = 0.0

    @property
    def pass_rate(self) -> float:
        """Calculate pass rate for criteria."""
        total_criteria = len(self.scores)
        if total_criteria == 0:
            return 1.0
        passed_criteria = total_criteria - len(self.failed_criteria)
        return passed_criteria / total_criteria


class QualityGateConfig(BaseModel):
    """Configuration for quality gates."""

    min_word_count: int = 1000
    max_passive_voice: float = 0.15
    min_readability_ease: float = 60.0
    min_dialogue_clarity: float = 0.7
    min_character_consistency: float = 0.8
    min_vocabulary_diversity: float = 0.4
    max_adverb_frequency: float = 0.08
    min_quality_score: float = 0.6

    def get_level_config(self, level: QualityLevel) -> "QualityGateConfig":
        """Get configuration for specific quality level."""
        if level == QualityLevel.BRONZE:
            return QualityGateConfig(
                min_word_count=800,
                max_passive_voice=0.20,
                min_readability_ease=50.0,
                min_dialogue_clarity=0.5,
                min_character_consistency=0.6,
                min_vocabulary_diversity=0.3,
                max_adverb_frequency=0.12,
                min_quality_score=0.6,
            )
        elif level == QualityLevel.SILVER:
            return QualityGateConfig(
                min_word_count=1000,
                max_passive_voice=0.15,
                min_readability_ease=60.0,
                min_dialogue_clarity=0.7,
                min_character_consistency=0.8,
                min_vocabulary_diversity=0.4,
                max_adverb_frequency=0.08,
                min_quality_score=0.7,
            )
        elif level == QualityLevel.GOLD:
            return QualityGateConfig(
                min_word_count=1500,
                max_passive_voice=0.10,
                min_readability_ease=70.0,
                min_dialogue_clarity=0.8,
                min_character_consistency=0.9,
                min_vocabulary_diversity=0.5,
                max_adverb_frequency=0.05,
                min_quality_score=0.8,
            )
        elif level == QualityLevel.PLATINUM:
            return QualityGateConfig(
                min_word_count=2000,
                max_passive_voice=0.05,
                min_readability_ease=80.0,
                min_dialogue_clarity=0.9,
                min_character_consistency=0.95,
                min_vocabulary_diversity=0.6,
                max_adverb_frequency=0.03,
                min_quality_score=0.9,
            )
        return self
