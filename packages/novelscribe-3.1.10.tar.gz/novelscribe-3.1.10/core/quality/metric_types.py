"""
Quality Metrics Type Definitions for Novel Generation

Pydantic models for quality metrics data structures.
"""

from datetime import datetime

from pydantic import BaseModel, Field


class QualityMetrics(BaseModel):
    """Comprehensive quality metrics for a chapter or scene."""

    chapter_number: int
    version: int
    timestamp: datetime = Field(default_factory=datetime.now)

    word_count: int
    sentence_count: int
    paragraph_count: int
    avg_sentence_length: float
    avg_paragraph_length: float

    flesch_kincaid: float
    gunning_fog: float
    smog_index: float

    dialogue_ratio: float
    dialogue_line_count: int
    speaker_clarity: float

    scene_variation: float
    action_frequency: float

    character_consistency: float
    plot_continuity: float

    passive_voice_ratio: float
    adverb_frequency: float
    vocabulary_diversity: float

    overall_quality_score: float


class ContentMetrics(BaseModel):
    """Basic content structure metrics."""

    word_count: int
    sentence_count: int
    paragraph_count: int
    avg_sentence_length: float
    avg_paragraph_length: float
    avg_word_length: float


class ReadabilityMetrics(BaseModel):
    """Readability assessment metrics."""

    flesch_kincaid_grade: float
    flesch_reading_ease: float
    gunning_fog_index: float
    smog_index: float
    coleman_liau_index: float


class DialogueMetrics(BaseModel):
    """Dialogue quality metrics."""

    dialogue_ratio: float
    dialogue_line_count: int
    avg_dialogue_length: float
    speaker_clarity_score: float
    dialogue_tag_diversity: float
    action_tag_ratio: float


class PacingMetrics(BaseModel):
    """Pacing and flow metrics."""

    scene_variation_score: float
    action_frequency: float
    paragraph_length_variance: float
    sentence_length_variance: float
    transition_quality: float


class StyleMetrics(BaseModel):
    """Writing style metrics."""

    passive_voice_ratio: float
    adverb_frequency: float
    vocabulary_diversity: float
    cliché_count: int
    repetition_score: float
