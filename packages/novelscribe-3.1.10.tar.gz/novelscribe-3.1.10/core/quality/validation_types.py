"""
Base types for the Validation System.

Provides core enums, abstract base class, and result container used
by validation rules, reports, and the validation engine.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional


class Severity(str, Enum):
    """Severity levels for validation issues."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class RuleCategory(str, Enum):
    """Categories of validation rules."""

    CONTENT = "content"
    STRUCTURE = "structure"
    STYLE = "style"
    CONTINUITY = "continuity"


class ValidationRule:
    """Definition of a validation rule."""

    def __init__(
        self,
        rule_id: str,
        name: str,
        description: str,
        severity: Severity,
        category: RuleCategory,
        enabled: bool = True,
    ):
        self.rule_id = rule_id
        self.name = name
        self.description = description
        self.severity = severity
        self.category = category
        self.enabled = enabled

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> "ValidationResult":
        """Validate content against this rule. Override in subclasses."""
        raise NotImplementedError

    def __call__(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> "ValidationResult":
        """Allow the rule to be called as a function."""
        return self.validate_content(content, context)


class ValidationResult:
    """Result of a validation check."""

    def __init__(
        self,
        rule: ValidationRule,
        passed: bool,
        message: str,
        location: Optional[str] = None,
        suggestion: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        timestamp: Optional[datetime] = None,
    ):
        self.rule = rule
        self.passed = passed
        self.message = message
        self.location = location
        self.suggestion = suggestion
        self.context = context
        self.timestamp = timestamp or datetime.now()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "rule_id": self.rule.rule_id,
            "rule_name": self.rule.name,
            "passed": self.passed,
            "message": self.message,
            "location": self.location,
            "suggestion": self.suggestion,
            "context": self.context,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "severity": self.rule.severity.value if self.rule.severity else None,
            "category": self.rule.category.value if self.rule.category else None,
        }
