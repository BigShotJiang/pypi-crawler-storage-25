"""Post-phase interactive revision loop for autonomous pipelines."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

import click
from pydantic import BaseModel

if TYPE_CHECKING:
    from core.llm.client import LLMConfig
    from core.llm.optimizing_client import OptimizingLLMClient

REVISION_ELIGIBLE_PHASES: frozenset[str] = frozenset(
    {
        "new_novel",
        "worldbuilding_phase",
        "character_phase",
        "outline_phase",
        "writing_phase",
    }
)

PHASE_OUTPUT_FILES: dict[str, str] = {
    "new_novel": "META.yaml",
    "worldbuilding_phase": "LORE.md",
    "character_phase": "CHARACTERS.md",
    "outline_phase": "OUTLINE.md",
    "writing_phase": "chapters",
}

_REVISION_SYSTEM_PROMPT = (
    "You are a creative revision assistant for NovelScribe. "
    "You help authors refine their novel content through iterative dialogue. "
    "When the user provides feedback, rewrite the content to address their concerns "
    "while maintaining consistency with the rest of the novel. "
    "Always preserve the overall structure unless explicitly asked to reorganize."
)

_SUMMARY_PROMPT = (
    "Summarize the following content in 3-5 bullet points. "
    "Focus on the key creative decisions: themes, characters, plot points, "
    "world rules, or writing style as appropriate. "
    "Be concise and highlight anything that might need refinement."
)

_REVISION_PROMPT = (
    "Revise the following content based on the user's feedback. "
    "Return the complete revised content. "
    "After the revision, provide a brief 1-2 sentence summary of what you changed."
)


class RevisionResult(BaseModel):
    """Outcome of a revision loop session."""

    revised: bool
    rounds: int
    change_summaries: list[str]


class RevisionLoop:
    """Interactive post-phase revision component.

    Presents a summary of phase output, accepts natural-language feedback,
    rewrites the output via LLM, and persists changes to the output file.

    Args:
        llm_config: LLM configuration for API calls.
        llm_client: Optimizing LLM client for generation.
        git_manager: Git manager for structured commits.
        storage_path: Base path to the projects directory.
    """

    def __init__(
        self,
        llm_config: LLMConfig,
        llm_client: OptimizingLLMClient,
        git_manager: Any,
        storage_path: Path,
    ) -> None:
        self._llm_config = llm_config
        self._llm_client = llm_client
        self._git_manager = git_manager
        self._storage_path = storage_path

    def run(
        self,
        phase_name: str,
        project_name: str,
        current_chapter: Optional[int] = None,
    ) -> RevisionResult:
        """Execute the revision loop for a given phase's output.

        Args:
            phase_name: Name of the completed phase.
            project_name: Name of the project.
            current_chapter: Current chapter number (for writing_phase).

        Returns:
            RevisionResult with revision metadata.
        """
        output_path = self._resolve_output_path(phase_name, project_name, current_chapter)
        if output_path is None or not output_path.exists():
            click.echo(
                click.style(
                    f"  ⚠ No output file found for {phase_name}, skipping revision", fg="yellow"
                )
            )
            return RevisionResult(revised=False, rounds=0, change_summaries=[])

        current_content = output_path.read_text(encoding="utf-8")
        if not current_content.strip():
            return RevisionResult(revised=False, rounds=0, change_summaries=[])

        summary = self._generate_summary(current_content, phase_name)
        original_content = current_content
        rounds = 0
        change_summaries: list[str] = []

        self._print_header(phase_name, summary)

        while True:
            click.echo("")
            click.echo(
                click.style("  Commands:", bold=True)
                + "  /done · /skip · /full  · or type feedback"
            )
            try:
                user_input = input(click.style("  ✏️  ", fg="cyan")).strip()
            except (EOFError, KeyboardInterrupt):
                click.echo("")
                user_input = "/done"

            if user_input in ("/done", "/continue"):
                break
            if user_input == "/skip":
                if rounds == 0:
                    if output_path.exists():
                        output_path.write_text(original_content, encoding="utf-8")
                    return RevisionResult(revised=False, rounds=0, change_summaries=[])
                break
            if user_input == "/full":
                self._print_full_content(current_content)
                continue
            if not user_input:
                continue

            revised_content, change_summary = self._apply_revision(
                current_content, user_input, phase_name
            )
            if revised_content is None:
                click.echo(click.style("  ⚠ Revision failed, keeping current content", fg="yellow"))
                continue

            current_content = revised_content
            rounds += 1
            change_summaries.append(change_summary)

            output_path.write_text(current_content, encoding="utf-8")

            click.echo("")
            click.echo(click.style("  📝 Changes:", bold=True) + f" {change_summary}")

            self._git_commit(phase_name, rounds, change_summary, project_name)

        if rounds > 0 and current_content != original_content:
            output_path.write_text(current_content, encoding="utf-8")
            click.echo(
                click.style("  ✅ Revision complete", fg="green", bold=True)
                + f" ({rounds} round{'s' if rounds != 1 else ''})"
            )
            return RevisionResult(revised=True, rounds=rounds, change_summaries=change_summaries)

        return RevisionResult(revised=False, rounds=0, change_summaries=[])

    def should_trigger(
        self,
        phase_name: str,
        interactive_revision: bool,
        revision_interval: int,
        current_chapter: Optional[int] = None,
    ) -> bool:
        """Check whether revision should trigger for this phase.

        Args:
            phase_name: Name of the phase.
            interactive_revision: Whether interactive revision is enabled.
            revision_interval: Chapter interval for writing phase (0 = first only).
            current_chapter: Current chapter number (for writing_phase).

        Returns:
            True if revision should trigger.
        """
        if not interactive_revision:
            return False
        if phase_name not in REVISION_ELIGIBLE_PHASES:
            return False
        if phase_name == "writing_phase":
            if current_chapter is None:
                return False
            if current_chapter <= 1:
                return True
            if revision_interval <= 0:
                return False
            return current_chapter % revision_interval == 0
        return True

    def _resolve_output_path(
        self,
        phase_name: str,
        project_name: str,
        current_chapter: Optional[int] = None,
    ) -> Optional[Path]:
        """Resolve the output file path for a phase.

        Args:
            phase_name: Name of the phase.
            project_name: Name of the project.
            current_chapter: Current chapter number (for writing_phase).

        Returns:
            Path to the output file, or None if not resolvable.
        """
        project_dir = self._storage_path / project_name
        filename = PHASE_OUTPUT_FILES.get(phase_name)
        if filename is None:
            return None
        if phase_name == "writing_phase":
            if current_chapter is not None and current_chapter >= 1:
                chapter_path = project_dir / "chapters" / f"chapter_{current_chapter:03d}.md"
                if chapter_path.exists():
                    return chapter_path
                chapter_path_alt = project_dir / "chapters" / f"chapter_{current_chapter}.md"
                if chapter_path_alt.exists():
                    return chapter_path_alt
            return None
        return project_dir / filename

    def _generate_summary(self, content: str, phase_name: str) -> str:
        """Generate a summary of the phase output.

        Args:
            content: The current output content.
            phase_name: Name of the phase for context.

        Returns:
            A bullet-point summary string.
        """
        truncated = content[:4000] if len(content) > 4000 else content
        prompt = f"{_SUMMARY_PROMPT}\n\nPhase: {phase_name}\n\nContent:\n{truncated}"
        try:
            from core.llm.client import LLMConfig

            config = LLMConfig(
                provider=self._llm_config.provider,
                model=self._llm_config.model,
                temperature=0.3,
                max_tokens=512,
            )
            response = self._llm_client.generate(config, prompt)
            return response.strip() if response else "Unable to generate summary."
        except Exception:
            lines = content.strip().split("\n")
            preview = "\n".join(lines[:10])
            return f"Preview:\n{preview}"

    def _apply_revision(
        self,
        current_content: str,
        feedback: str,
        phase_name: str,
    ) -> tuple[Optional[str], str]:
        """Apply user feedback to rewrite the content.

        Args:
            current_content: The current output content.
            feedback: User's natural-language feedback.
            phase_name: Name of the phase for context.

        Returns:
            Tuple of (revised_content, change_summary). revised_content is None on failure.
        """
        prompt = (
            f"{_REVISION_SYSTEM_PROMPT}\n\n"
            f"Phase: {phase_name}\n\n"
            f"Current content:\n{current_content}\n\n"
            f"User feedback: {feedback}\n\n"
            f"{_REVISION_PROMPT}"
        )
        try:
            from core.llm.client import LLMConfig

            config = LLMConfig(
                provider=self._llm_config.provider,
                model=self._llm_config.model,
                temperature=0.7,
                max_tokens=4096,
            )
            response = self._llm_client.generate(config, prompt)
            if not response or not response.strip():
                return None, "Empty response from LLM"
            parts = response.rsplit("\n\n", 1)
            if len(parts) == 2 and len(parts[1]) < 300:
                revised_content = parts[0]
                change_summary = parts[1].strip()
            else:
                revised_content = response
                change_summary = "Content revised based on feedback"
            return revised_content, change_summary
        except Exception as exc:
            return None, f"Revision failed: {exc}"

    def _print_header(self, phase_name: str, summary: str) -> None:
        """Print the revision loop header with summary.

        Args:
            phase_name: Name of the phase.
            summary: Generated summary of the output.
        """
        click.echo("")
        click.echo(click.style(f"  🔍 Revision — {phase_name}", bold=True, fg="blue"))
        click.echo(click.style("  " + "─" * 50, fg="blue"))
        click.echo("")
        click.echo(click.style("  Summary:", bold=True))
        for line in summary.split("\n"):
            click.echo(f"    {line}")

    def _print_full_content(self, content: str) -> None:
        """Print the full content for user review.

        Args:
            content: The current output content.
        """
        click.echo("")
        click.echo(click.style("  📄 Full content:", bold=True))
        click.echo(click.style("  " + "─" * 50, dim=True))
        for line in content.split("\n"):
            click.echo(f"    {line}")
        click.echo(click.style("  " + "─" * 50, dim=True))

    def _git_commit(
        self,
        phase_name: str,
        round_num: int,
        change_summary: str,
        project_name: str,
    ) -> None:
        """Create a structured git commit for the revision.

        Args:
            phase_name: Name of the phase.
            round_num: Revision round number.
            change_summary: Summary of changes in this round.
            project_name: Name of the project.
        """
        try:
            self._git_manager.auto_commit_step(
                agent="revision",
                description=f"revision: {phase_name} round {round_num}: {change_summary}",
            )
        except Exception:
            pass
