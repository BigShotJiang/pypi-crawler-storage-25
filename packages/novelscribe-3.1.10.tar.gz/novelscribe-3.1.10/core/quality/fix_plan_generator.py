"""Fix plan generator for automatic issue resolution."""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List

from pydantic import BaseModel, Field

from core.context.continuity import ContinuityIssue, ContinuityReport, IssueType, Severity


class AgentType(str, Enum):
    CHARACTER = "character_agent"
    PLOT = "outline_agent"
    WORLD = "world_agent"
    CONTINUITY = "continuity_agent"
    EDITOR = "editor_agent"


class FixInstruction(BaseModel):
    issue_id: str
    issue_type: IssueType
    severity: Severity
    agent: AgentType
    instructions: str
    context: Dict[str, Any] = Field(default_factory=dict)
    priority: int = Field(default=100, ge=1, le=100)


class FixPlan(BaseModel):
    project_name: str
    timestamp: datetime
    total_fixes: int
    critical_fixes: int
    major_fixes: int
    minor_fixes: int
    estimated_iterations: int
    instructions: List[FixInstruction]


class FixPlanGenerator:
    def __init__(self):
        self.agent_routing = {
            IssueType.CHARACTER: AgentType.CHARACTER,
            IssueType.PLOT: AgentType.PLOT,
            IssueType.WORLD: AgentType.WORLD,
            IssueType.TIMELINE: AgentType.CONTINUITY,
            IssueType.INCONSISTENCY: AgentType.EDITOR,
        }

    def generate_fix_plan(self, report: ContinuityReport, max_priority: int = 100) -> FixPlan:
        instructions = []

        for i, issue in enumerate(report.issues):
            agent = self._route_issue_to_agent(issue)
            priority = self._calculate_priority(issue, i)
            fix_instruction = self._create_fix_instruction(issue, i, agent, priority)
            instructions.append(fix_instruction)

        instructions.sort(key=lambda x: x.priority)

        critical_fixes = sum(1 for i in instructions if i.severity == Severity.CRITICAL)
        major_fixes = sum(1 for i in instructions if i.severity == Severity.MAJOR)
        minor_fixes = sum(1 for i in instructions if i.severity == Severity.MINOR)

        estimated_iterations = self._estimate_iterations(critical_fixes, major_fixes, minor_fixes)

        return FixPlan(
            project_name=report.project_name,
            timestamp=datetime.now(),
            total_fixes=len(instructions),
            critical_fixes=critical_fixes,
            major_fixes=major_fixes,
            minor_fixes=minor_fixes,
            estimated_iterations=estimated_iterations,
            instructions=instructions,
        )

    def _route_issue_to_agent(self, issue: ContinuityIssue) -> AgentType:
        if issue.issue_type in self.agent_routing:
            return self.agent_routing[issue.issue_type]

        if issue.severity == Severity.CRITICAL:
            return AgentType.EDITOR

        return AgentType.CONTINUITY

    def _calculate_priority(self, issue: ContinuityIssue, index: int) -> int:
        base_priority = 50

        if issue.severity == Severity.CRITICAL:
            base_priority = 10
        elif issue.severity == Severity.MAJOR:
            base_priority = 30
        else:
            base_priority = 70

        return min(100, max(1, base_priority + index))

    def _create_fix_instruction(
        self, issue: ContinuityIssue, issue_id: int, agent: AgentType, priority: int
    ) -> FixInstruction:
        instructions = self._generate_agent_instructions(issue, agent)

        context = {
            "issue_type": issue.issue_type.value,
            "severity": issue.severity.value,
            "location": issue.location,
            "suggestion": issue.suggestion,
        }

        return FixInstruction(
            issue_id=f"issue_{issue_id:03d}",
            issue_type=issue.issue_type,
            severity=issue.severity,
            agent=agent,
            instructions=instructions,
            context=context,
            priority=priority,
        )

    def _generate_agent_instructions(self, issue: ContinuityIssue, agent: AgentType) -> str:
        base_instruction = f"Fix the following issue:\n\n{issue.description}\n\n"

        if issue.suggestion:
            base_instruction += f"Suggested fix: {issue.suggestion}\n\n"

        if issue.location:
            base_instruction += f"Location to fix: {issue.location}\n\n"

        agent_specific = {
            AgentType.CHARACTER: (
                "Ensure character consistency with established traits, "
                "backstory, and previous actions."
            ),
            AgentType.PLOT: (
                "Maintain plot coherence and story structure while resolving this issue."
            ),
            AgentType.WORLD: "Preserve world-building consistency and established rules.",
            AgentType.CONTINUITY: (
                "Fix timeline or continuity errors while maintaining narrative flow."
            ),
            AgentType.EDITOR: "Apply editorial judgment to resolve this inconsistency.",
        }

        return base_instruction + agent_specific.get(agent, "Fix this issue.")

    def _estimate_iterations(self, critical_fixes: int, major_fixes: int, minor_fixes: int) -> int:
        estimate = 1
        estimate += (critical_fixes + 1) // 2
        estimate += (major_fixes + 2) // 3
        estimate += (minor_fixes + 4) // 5

        return min(5, max(1, estimate))

    def filter_by_agent(self, plan: FixPlan, agent: AgentType) -> List[FixInstruction]:
        return [i for i in plan.instructions if i.agent == agent]

    def filter_by_severity(self, plan: FixPlan, severity: Severity) -> List[FixInstruction]:
        return [i for i in plan.instructions if i.severity == severity]

    def get_critical_fixes(self, plan: FixPlan) -> List[FixInstruction]:
        return self.filter_by_severity(plan, Severity.CRITICAL)

    def get_major_fixes(self, plan: FixPlan) -> List[FixInstruction]:
        return self.filter_by_severity(plan, Severity.MAJOR)

    def get_minor_fixes(self, plan: FixPlan) -> List[FixInstruction]:
        return self.filter_by_severity(plan, Severity.MINOR)

    def create_batch_plan(self, plan: FixPlan, batch_size: int = 10) -> List[List[FixInstruction]]:
        batches = []
        current_batch = []

        for instruction in plan.instructions:
            current_batch.append(instruction)

            if len(current_batch) >= batch_size:
                batches.append(current_batch)
                current_batch = []

        if current_batch:
            batches.append(current_batch)

        return batches

    def save_fix_plan(self, plan: FixPlan, output_path: str) -> None:
        from pathlib import Path

        plan_file = Path(output_path)
        plan_file.parent.mkdir(parents=True, exist_ok=True)

        lines = [
            f"# Fix Plan: {plan.project_name}",
            f"**Generated:** {plan.timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "## Summary",
            f"- Total Fixes: {plan.total_fixes}",
            f"- Critical: {plan.critical_fixes}",
            f"- Major: {plan.major_fixes}",
            f"- Minor: {plan.minor_fixes}",
            f"- Estimated Iterations: {plan.estimated_iterations}",
            "",
        ]

        lines.append("## Fix Instructions")
        lines.append("")

        for i, instruction in enumerate(plan.instructions, 1):
            lines.append(f"### Fix {i}: {instruction.issue_id}")
            lines.append(f"- **Priority:** {instruction.priority}")
            lines.append(f"- **Agent:** {instruction.agent.value}")
            lines.append(f"- **Severity:** {instruction.severity.value}")
            lines.append(f"- **Type:** {instruction.issue_type.value}")
            lines.append("")
            lines.append("**Instructions:**")
            lines.append(instruction.instructions)
            lines.append("")
            if instruction.context:
                lines.append("**Context:**")
                for key, value in instruction.context.items():
                    if value:
                        lines.append(f"- {key}: {value}")
                lines.append("")

        plan_file.write_text("\n".join(lines))
