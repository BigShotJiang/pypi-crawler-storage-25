"""
Quality Gate Enforcement for Novel Generation

This module provides quality gate enforcement with multiple quality levels
(Bronze, Silver, Gold, Platinum) to ensure content meets defined standards.

Model classes are defined in ``core.quality_models`` and report generation
logic in ``core.quality_report``.  This module re-exports the model symbols
so that existing ``from core.quality.gate import …`` statements continue
to work unchanged.
"""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.quality.validation_system import ValidationReport

from .metric_types import QualityMetrics

# Re-export model symbols for backward compatibility
from .models import (  # noqa: F401
    FixApproach,
    FixSuggestionResponse,
    GateResult,
    QualityGateConfig,
    QualityLevel,
)
from .report import QualityReportGenerator

logger = logging.getLogger(__name__)


class QualityGate:
    """
    Quality gate enforcement system.

    Enforces quality standards at different levels (Bronze, Silver, Gold, Platinum)
    and provides actionable recommendations for improvement.
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize the quality gate system.

        Args:
            project_root: Path to project directory
        """
        self.project_root = project_root or Path.cwd()
        self.gate_history: Dict[str, List[GateResult]] = {}
        self._quality_dir = self.project_root / ".quality"
        self._report_generator = QualityReportGenerator(self.project_root, self)

    # ------------------------------------------------------------------
    # Fix suggestions – delegated to report generator
    # ------------------------------------------------------------------

    @property
    def _fix_suggestions_cache(self):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator._fix_suggestions_cache

    @_fix_suggestions_cache.setter
    def _fix_suggestions_cache(self, value):
        self._report_generator._fix_suggestions_cache = value

    def _load_fix_suggestions(self, data_dir=None):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator._load_fix_suggestions(data_dir or self.project_root / "data")

    def _select_relevant_fixes(self, failed_criteria, fixes):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator._select_relevant_fixes(failed_criteria, fixes)

    def _determine_urgency(self, failed_criteria, target_level):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator._determine_urgency(failed_criteria, target_level)

    def _recommend_fix_approach(self, available_fixes, failed_criteria):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator._recommend_fix_approach(available_fixes, failed_criteria)

    def _generate_issue_summary(self, failed_criteria):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator._generate_issue_summary(failed_criteria)

    def _estimate_fix_time(self, failed_criteria, target_level):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator._estimate_fix_time(failed_criteria, target_level)

    def _analyze_promotion_gap(self, metrics, result, target_level):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator.analyze_promotion_gap(metrics, result, target_level)

    def _generate_auto_fix_plan(self, failed_criteria, gap_analysis):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator.generate_auto_fix_plan(failed_criteria, gap_analysis)

    def _generate_action_plan(self, failed_criteria, recommendations):
        """Proxy: delegates to QualityReportGenerator."""
        return self._report_generator.generate_action_plan(failed_criteria, recommendations)

    def get_fix_suggestions(
        self,
        failed_criteria: List[str],
        target_level: QualityLevel = QualityLevel.SILVER,
        language: str = "en",
    ) -> FixSuggestionResponse:
        """Get fix approach suggestions for failed quality criteria."""
        return self._report_generator.get_fix_suggestions(failed_criteria, target_level, language)

    # ------------------------------------------------------------------
    # Core gate logic
    # ------------------------------------------------------------------

    def _evaluate_quality_gate(
        self,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport],
        target_level: QualityLevel,
    ) -> GateResult:
        """Pure evaluation — no side-effects.

        Does not write to :attr:`gate_history` or persist to disk.
        Use :meth:`check_quality_gate` when an official, recorded check is needed.
        """
        config = QualityGateConfig().get_level_config(target_level)

        scores: Dict[str, float] = {}
        failed_criteria: List[str] = []
        recommendations: List[str] = []

        criteria_checks = [
            ("word_count", metrics.word_count, config.min_word_count, ">="),
            ("passive_voice", metrics.passive_voice_ratio, config.max_passive_voice, "<="),
            ("readability_ease", metrics.flesch_kincaid, config.min_readability_ease, ">="),
            ("dialogue_clarity", metrics.speaker_clarity, config.min_dialogue_clarity, ">="),
            (
                "character_consistency",
                metrics.character_consistency,
                config.min_character_consistency,
                ">=",
            ),
            (
                "vocabulary_diversity",
                metrics.vocabulary_diversity,
                config.min_vocabulary_diversity,
                ">=",
            ),
            ("adverb_frequency", metrics.adverb_frequency, config.max_adverb_frequency, "<="),
            ("quality_score", metrics.overall_quality_score, config.min_quality_score, ">="),
        ]

        for criterion_name, value, threshold, operator in criteria_checks:
            passed = self._check_criterion(value, threshold, operator)
            scores[criterion_name] = value

            if not passed:
                failed_criteria.append(criterion_name)
                recommendations.extend(
                    self._generate_recommendations(criterion_name, value, threshold, target_level)
                )

        if validation_report:
            validation_passed = self._check_validation_report(validation_report, target_level)
            scores["validation"] = 1.0 if validation_passed else 0.0

            if not validation_passed:
                failed_criteria.append("validation")
                recommendations.append(
                    "Address validation errors before promoting to next quality level"
                )

        overall_score = self._calculate_overall_score(scores, config)
        passed = len(failed_criteria) == 0

        return GateResult(
            gate_level=target_level,
            passed=passed,
            scores=scores,
            failed_criteria=failed_criteria,
            recommendations=list(set(recommendations)),
            overall_score=overall_score,
        )

    def check_quality_gate(
        self,
        project_name: str,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport] = None,
        target_level: QualityLevel = QualityLevel.SILVER,
    ) -> GateResult:
        """Evaluate quality metrics against *target_level* and record the result."""
        result = self._evaluate_quality_gate(metrics, validation_report, target_level)
        self._record_gate_result(project_name, result)
        return result

    def _check_criterion(self, value: float, threshold: float, operator: str) -> bool:
        """Check if a criterion meets the threshold."""
        if operator == ">=":
            return value >= threshold
        elif operator == "<=":
            return value <= threshold
        elif operator == ">":
            return value > threshold
        elif operator == "<":
            return value < threshold
        return False

    def _check_validation_report(
        self, report: ValidationReport, target_level: QualityLevel
    ) -> bool:
        """Check if validation report meets quality gate requirements."""
        if target_level == QualityLevel.BRONZE:
            return report.errors == 0
        elif target_level == QualityLevel.SILVER:
            return report.errors == 0 and report.warnings <= 2
        elif target_level == QualityLevel.GOLD:
            return report.errors == 0 and report.warnings == 0
        elif target_level == QualityLevel.PLATINUM:
            return report.errors == 0 and report.warnings == 0 and report.success_rate >= 0.95
        return True

    def _calculate_overall_score(
        self, scores: Dict[str, float], config: QualityGateConfig
    ) -> float:
        """Calculate overall quality score from individual scores."""
        weights = {
            "quality_score": 0.30,
            "readability_ease": 0.15,
            "dialogue_clarity": 0.15,
            "character_consistency": 0.15,
            "vocabulary_diversity": 0.10,
            "passive_voice": 0.05,
            "adverb_frequency": 0.05,
            "word_count": 0.05,
        }

        normalized_scores: Dict[str, float] = {}

        for criterion, value in scores.items():
            if criterion == "validation":
                continue

            if criterion == "passive_voice":
                normalized = 1.0 - (value / 0.3)
            elif criterion == "adverb_frequency":
                normalized = 1.0 - (value / 0.2)
            elif criterion == "word_count":
                normalized = min(value / 2000, 1.0)
            else:
                normalized = min(max(value, 0.0), 1.0)

            normalized_scores[criterion] = normalized

        weighted_sum = sum(
            normalized_scores.get(criterion, 0.0) * weight for criterion, weight in weights.items()
        )

        return min(max(weighted_sum, 0.0), 1.0)

    def _generate_recommendations(
        self, criterion: str, value: float, threshold: float, target_level: QualityLevel
    ) -> List[str]:
        """Generate actionable recommendations for failed criteria."""
        recommendations = {
            "word_count": [
                f"Expand content to meet minimum word count ({int(threshold)} words)",
                "Add more descriptive details, character development, or dialogue",
                "Consider extending scenes or adding subplots",
            ],
            "passive_voice": [
                f"Reduce passive voice from {value:.1%} to {threshold:.1%} or less",
                "Rewrite passive constructions as active voice",
                "Focus on making the subject perform the action",
            ],
            "readability_ease": [
                f"Improve readability score from {value:.1f} to {threshold:.1f} or higher",
                "Use shorter sentences and simpler words",
                "Break up long paragraphs and sentences",
            ],
            "dialogue_clarity": [
                f"Improve dialogue clarity from {value:.1%} to {threshold:.1%} or higher",
                "Add clear speaker attributions to dialogue lines",
                "Use action beats or unique speech patterns to identify speakers",
            ],
            "character_consistency": [
                f"Improve character consistency from {value:.1%} to {threshold:.1%} or higher",
                "Ensure all named characters appear in the chapter",
                "Review character behavior and speech patterns for consistency",
            ],
            "vocabulary_diversity": [
                f"Increase vocabulary diversity from {value:.1%} to {threshold:.1%} or higher",
                "Use a wider variety of words and avoid repetition",
                "Replace common words with more specific or evocative alternatives",
            ],
            "adverb_frequency": [
                f"Reduce adverb frequency from {value:.2%} to {threshold:.2%} or less",
                "Replace adverbs with stronger verbs",
                "Show action and emotion rather than telling with adverbs",
            ],
            "quality_score": [
                f"Improve overall quality from {value:.1%} to {threshold:.1%} or higher",
                "Review all failed criteria and implement recommendations",
                "Consider multiple revision iterations focusing on weakest areas",
            ],
        }

        return recommendations.get(criterion, ["Review and improve this criterion"])

    # ------------------------------------------------------------------
    # Persistence helpers
    # ------------------------------------------------------------------

    def save_result(self, project_name: str, result: GateResult) -> Path:
        """Persist a gate result to disk.

        Args:
            project_name: Name of the project.
            result: Gate result to persist.

        Returns:
            Path to the written history file.
        """
        self._quality_dir.mkdir(parents=True, exist_ok=True)
        history_file = self._quality_dir / "gate_history.json"

        history = self._load_history_file(history_file)
        if project_name not in history:
            history[project_name] = []
        history[project_name].append(result.model_dump(mode="json"))

        history_file.write_text(json.dumps(history, indent=2, default=str))
        return history_file

    def load_history(self, project_name: str) -> List[GateResult]:
        """Load persisted gate results for a project.

        Args:
            project_name: Name of the project.

        Returns:
            List of historical GateResult objects.
        """
        history_file = self._quality_dir / "gate_history.json"
        history = self._load_history_file(history_file)
        results = history.get(project_name, [])
        loaded: List[GateResult] = []
        for r in results:
            if isinstance(r.get("timestamp"), str):
                r["timestamp"] = datetime.fromisoformat(r["timestamp"])
            loaded.append(GateResult(**r))
        return loaded

    def _load_history_file(self, path: Path) -> dict:
        """Load and parse the history JSON file."""
        if not path.exists():
            return {}
        try:
            data = json.loads(path.read_text())
            return data if isinstance(data, dict) else {}
        except Exception:
            logger.debug("Failed to load quality gate history from %s", path)
            return {}

    def _record_gate_result(self, project_name: str, result: GateResult) -> None:
        """Record gate result for tracking (in-memory and disk)."""
        if project_name not in self.gate_history:
            self.gate_history[project_name] = []
        self.gate_history[project_name].append(result)
        self.save_result(project_name, result)

    # ------------------------------------------------------------------
    # Level helpers
    # ------------------------------------------------------------------

    def get_highest_passing_level(
        self,
        project_name: str,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport] = None,
    ) -> QualityLevel:
        """Determine the highest quality level that content passes (read-only)."""
        levels = [
            QualityLevel.PLATINUM,
            QualityLevel.GOLD,
            QualityLevel.SILVER,
            QualityLevel.BRONZE,
        ]

        for level in levels:
            result = self._evaluate_quality_gate(metrics, validation_report, level)
            if result.passed:
                return level

        return QualityLevel.BRONZE

    def promote_to_level(
        self,
        project_name: str,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport] = None,
        target_level: QualityLevel = QualityLevel.SILVER,
        auto_fix: bool = False,
    ) -> Dict[str, Any]:
        """Attempt to promote content to *target_level*.

        Only the evaluation against *target_level* is recorded.
        The current-level lookup is a read-only query.
        """
        result = self.check_quality_gate(project_name, metrics, validation_report, target_level)

        current_level = self.get_highest_passing_level(project_name, metrics, validation_report)

        promotion_status: Dict[str, Any] = {
            "target_level": target_level,
            "current_level": current_level,
            "passed": result.passed,
            "overall_score": result.overall_score,
            "pass_rate": result.pass_rate,
            "failed_criteria": result.failed_criteria,
            "recommendations": result.recommendations,
            "can_auto_promote": False,
            "actions_needed": [],
        }

        if result.passed:
            promotion_status["can_auto_promote"] = True
            promotion_status["actions_needed"].append(
                f"Content meets {target_level.value} quality standards"
            )
        else:
            gap_analysis = self._report_generator.analyze_promotion_gap(
                metrics, result, target_level
            )
            promotion_status["gap_analysis"] = gap_analysis

            if auto_fix:
                promotion_status["auto_fix_plan"] = self._report_generator.generate_auto_fix_plan(
                    result.failed_criteria, gap_analysis
                )

            promotion_status["actions_needed"].extend(
                self._report_generator.generate_action_plan(
                    result.failed_criteria, result.recommendations
                )
            )

        return promotion_status

    # ------------------------------------------------------------------
    # Report generation – delegated
    # ------------------------------------------------------------------

    def generate_quality_report(
        self,
        project_name: str,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport] = None,
    ) -> str:
        """Generate comprehensive quality report (delegates to QualityReportGenerator)."""
        return self._report_generator.generate_quality_report(
            project_name, metrics, validation_report
        )

    def get_gate_statistics(self, project_name: str) -> Dict[str, Any]:
        """Get statistics for quality gate history (delegates to QualityReportGenerator)."""
        return self._report_generator.get_gate_statistics(project_name, self.gate_history)
