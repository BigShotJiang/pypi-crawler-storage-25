"""Interactive Q&A handler for checkpoint questions."""

import logging
from typing import Any, Optional

from core.checkpoints.proposal import CheckpointProposal


class QAContainer:
    """Container for Q&A session state."""

    def __init__(
        self,
        question: str,
        answer: Optional[str] = None,
        timestamp: Optional[Any] = None,
    ):
        self.question = question
        self.answer = answer
        self.timestamp = timestamp


class InteractiveQAHandler:
    """Handles interactive question-and-answer sessions at checkpoints."""

    def __init__(self):
        """Initialize Q&A handler."""
        self.logger = logging.getLogger("scribe")
        self._sessions: dict[str, list[QAContainer]] = {}

    def start_session(self, checkpoint_id: str) -> list[QAContainer]:
        """Start a new Q&A session for a checkpoint.

        Args:
            checkpoint_id: Checkpoint ID

        Returns:
            Empty list for new session
        """
        if checkpoint_id not in self._sessions:
            self._sessions[checkpoint_id] = []
        return self._sessions[checkpoint_id]

    def get_session(self, checkpoint_id: str) -> list[QAContainer]:
        """Get Q&A session history.

        Args:
            checkpoint_id: Checkpoint ID

        Returns:
            List of Q&A pairs
        """
        return self._sessions.get(checkpoint_id, [])

    def clear_session(self, checkpoint_id: str):
        """Clear Q&A session.

        Args:
            checkpoint_id: Checkpoint ID
        """
        if checkpoint_id in self._sessions:
            del self._sessions[checkpoint_id]

    def answer_question(
        self,
        question: str,
        proposal: CheckpointProposal,
    ) -> str:
        """Generate answer to a question about the proposal.

        Args:
            question: User's question
            proposal: Current checkpoint proposal

        Returns:
            Generated answer
        """
        question_lower = question.lower()

        if "why" in question_lower and any(
            w in question_lower for w in ["this", "plan", "proposal", "choice"]
        ):
            return self._explain_proposal_rationale(proposal)

        if "why not" in question_lower or "why didn't" in question_lower:
            return self._explain_alternatives(proposal, question_lower)

        if "what if" in question_lower:
            return self._explain_what_if(proposal, question)

        if "alternative" in question_lower or "compare" in question_lower:
            return self._compare_alternatives(proposal)

        if (
            "confidence" in question_lower
            or "sure" in question_lower
            or "confident" in question_lower
        ):
            return self._explain_confidence(proposal)

        if "change" in question_lower or "modify" in question_lower:
            return self._explain_modification_options(proposal)

        if "chapter" in question_lower:
            return self._explain_chapters(proposal)

        if "character" in question_lower:
            return self._explain_characters(proposal)

        if "pacing" in question_lower or "pace" in question_lower:
            return self._explain_pacing(proposal)

        if "ending" in question_lower or "conclusion" in question_lower:
            return self._explain_ending(proposal)

        return f"I understand you're asking about '{question}'. {proposal.reasoning}"

    def _explain_proposal_rationale(self, proposal: CheckpointProposal) -> str:
        lines = [
            f"This proposal was generated with {proposal.confidence:.0%} confidence.",
            "",
            f"Key reasoning: {proposal.reasoning}",
        ]

        if proposal.plan.pov:
            lines.append("")
            lines.append(f"The story is told from {proposal.plan.pov}'s perspective.")

        if proposal.plan.foreshadowing:
            lines.append("")
            lines.append(f"Foreshadowing: {proposal.plan.foreshadowing}")

        if proposal.reasoning_trace:
            lines.append("")
            lines.append("How this was determined:")
            for trace in proposal.reasoning_trace:
                lines.append(f"  • {trace}")

        return "\n".join(lines)

    def _explain_alternatives(self, proposal: CheckpointProposal, question: str) -> str:
        """Explain why an alternative wasn't chosen."""
        if not proposal.alternatives:
            return (
                "No alternatives were provided for this checkpoint. "
                "If you'd like to see alternatives, you can request modifications."
            )

        lines = ["Alternatives considered:"]
        for alt in proposal.alternatives:
            lines.append("")
            lines.append(f"[{alt.option_id}] {alt.plan.title}")
            lines.append(f"  Confidence: {alt.confidence:.0%}")
            lines.append(f"  Tradeoff: {alt.tradeoff_explanation}")
            if alt.rejection_reasons:
                lines.append("  Why not chosen:")
                for reason in alt.rejection_reasons:
                    lines.append(f"    - {reason}")

        return "\n".join(lines)

    def _explain_what_if(self, proposal: CheckpointProposal, question: str) -> str:
        """Explain what would change under different conditions."""
        lines = [
            "If you want to explore different directions, you can:",
            "",
            "1. Request modifications using 'scribe checkpoint modify'",
            "2. Select an alternative if available",
            "3. Provide guidance for specific changes",
            "",
            "What aspects would you like to change?",
        ]
        return "\n".join(lines)

    def _compare_alternatives(self, proposal: CheckpointProposal) -> str:
        """Compare all alternatives."""
        if not proposal.alternatives:
            return "No alternatives are available for this checkpoint."

        lines = ["Available alternatives:"]
        lines.append("")
        for alt in proposal.alternatives:
            lines.append(f"[{alt.option_id}] {alt.plan.title}")
            lines.append(f"  Confidence: {alt.confidence:.0%}")
            lines.append(f"  {alt.tradeoff_explanation}")
            lines.append("")

        return "\n".join(lines).strip()

    def _explain_confidence(self, proposal: CheckpointProposal) -> str:
        """Explain confidence calculation."""
        lines = [
            f"Overall confidence: {proposal.confidence:.0%}",
            "",
            "This confidence is based on:",
        ]

        if proposal.confidence_breakdown:
            bd = proposal.confidence_breakdown
            lines.append(f"  • Story coherence: {bd.coherence:.0%}")
            lines.append(f"  • Character development: {bd.character:.0%}")
            lines.append(f"  • Pacing: {bd.pacing:.0%}")
            lines.append(f"  • Originality: {bd.originality:.0%}")
            lines.append(f"  • Completeness: {bd.completeness:.0%}")
        else:
            lines.append("  • Story structure alignment")
            lines.append("  • Character consistency")
            lines.append("  • Pacing analysis")
            lines.append("  • Narrative flow")

        return "\n".join(lines)

    def _explain_modification_options(self, proposal: CheckpointProposal) -> str:
        """Explain available modification options."""
        lines = [
            "You can modify this proposal in several ways:",
            "",
            "1. Provide general guidance ('scribe checkpoint guidance')",
            "   - Tell me what you'd like to change",
            "   - I'll interpret and apply appropriate modifications",
            "",
            "2. Direct modifications ('scribe checkpoint modify')",
            "   - Specify exact changes with key=value pairs",
            "   - Or provide a JSON file with changes",
            "",
            "Available aspects to modify:",
        ]

        if proposal.plan.pov:
            lines.append(f"  • POV character: {proposal.plan.pov}")
        if proposal.plan.pacing:
            lines.append(f"  • Pacing: {proposal.plan.pacing}")
        if proposal.plan.word_estimate:
            lines.append(f"  • Word estimate: {proposal.plan.word_estimate:,}")
        lines.append("  • Plot elements")
        lines.append("  • Character arcs")
        lines.append("  • Scene structure")

        return "\n".join(lines)

    def _explain_chapters(self, proposal: CheckpointProposal) -> str:
        """Explain chapter structure."""
        if not proposal.plan.scenes:
            return (
                "Chapter details are not yet available. "
                "This information will be provided during the chapter planning phase."
            )

        lines = [
            f"Chapter overview ({len(proposal.plan.scenes)} key scenes):",
            "",
        ]

        for i, scene in enumerate(proposal.plan.scenes[:5], 1):
            scene_desc = scene.get("description", "Untitled scene")
            lines.append(f"  {i}. {scene_desc}")

        if len(proposal.plan.scenes) > 5:
            lines.append(f"  ... and {len(proposal.plan.scenes) - 5} more scenes")

        return "\n".join(lines)

    def _explain_characters(self, proposal: CheckpointProposal) -> str:
        """Explain character information."""
        if proposal.plan.metadata and "characters" in proposal.plan.metadata:
            chars = proposal.plan.metadata["characters"]
            lines = [f"Characters ({len(chars)}):"]
            for char in chars[:5]:
                lines.append(f"  • {char}")
            return "\n".join(lines)

        return (
            "Character details are in the CHARACTERS.md file. "
            "Use 'scribe agents show character_agent' for more info."
        )

    def _explain_pacing(self, proposal: CheckpointProposal) -> str:
        """Explain pacing analysis."""
        pacing = proposal.plan.pacing or "moderate"
        lines = [
            f"Current pacing: {pacing}",
            "",
        ]

        if pacing == "fast":
            lines.append("This story features:")
            lines.append("  • Quick scene transitions")
            lines.append("  • High tension moments")
            lines.append("  • Concise narrative")
        elif pacing == "slow":
            lines.append("This story features:")
            lines.append("  • Detailed scene development")
            lines.append("  • Rich atmospheric descriptions")
            lines.append("  • Character introspection")
        else:
            lines.append("This story balances:")
            lines.append("  • Action and reflection")
            lines.append("  • Scene variety")
            lines.append("  • Character and plot development")

        return "\n".join(lines)

    def _explain_ending(self, proposal: CheckpointProposal) -> str:
        """Explain story ending."""
        if proposal.plan.metadata and "ending_type" in proposal.plan.metadata:
            ending = proposal.plan.metadata["ending_type"]
            return f"Planned ending type: {ending}"

        return (
            "Ending details will be finalized during the outline phase. "
            "The current plan sets up narrative threads that will be resolved "
            "according to the story's arc."
        )


def create_qa_handler() -> InteractiveQAHandler:
    """Factory function to create Q&A handler.

    Returns:
        InteractiveQAHandler instance
    """
    return InteractiveQAHandler()
