"""
Validation Report container for the Validation System.

Provides the ValidationReport class that aggregates validation results
with summary statistics.
"""

from datetime import datetime
from typing import List, Optional

from core.quality.validation_types import RuleCategory, Severity, ValidationResult


class ValidationReport:
    """Complete validation report for content."""

    def __init__(
        self,
        content_path: Optional[str] = None,
        timestamp: Optional[datetime] = None,
        total_rules_checked: int = 0,
        passed_rules: int = 0,
        failed_rules: int = 0,
        warnings: int = 0,
        errors: int = 0,
        results: Optional[List[ValidationResult]] = None,
    ):
        self.content_path = content_path
        self.timestamp = timestamp or datetime.now()
        self.total_rules_checked = total_rules_checked
        self.passed_rules = passed_rules
        self.failed_rules = failed_rules
        self.warnings = warnings
        self.errors = errors
        self.results = results or []

    @property
    def success_rate(self) -> float:
        """Calculate success rate of validation."""
        if self.total_rules_checked == 0:
            return 1.0
        return self.passed_rules / self.total_rules_checked

    def get_results_by_severity(self, severity: Severity) -> List[ValidationResult]:
        """Filter results by severity level."""
        return [r for r in self.results if not r.passed and r.rule.severity == severity]

    def get_results_by_category(self, category: RuleCategory) -> List[ValidationResult]:
        """Filter results by category."""
        return [r for r in self.results if r.rule.category == category]
