"""Event bus for deterministic hook dispatch with retry and timeout controls."""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeoutError
from typing import Any, Callable

from .events import HookEventPayload
from .models import (
    HookDispatchReport,
    HookExecutionResult,
    HookExecutionStatus,
    HookSubscription,
)

HookHandler = Callable[[HookEventPayload, HookSubscription], dict[str, Any] | None]


class HookDispatchBlockedError(RuntimeError):
    """Raised when a required hook fails and dispatch must be blocked."""

    def __init__(
        self,
        message: str,
        report: HookDispatchReport,
        result: HookExecutionResult,
    ) -> None:
        super().__init__(message)
        self.report = report
        self.result = result


class HookEventBus:
    """Dispatches hook subscriptions in stable order for one event."""

    def __init__(self) -> None:
        self._handlers: dict[str, HookHandler] = {}

    def register_handler(self, name: str, handler: HookHandler) -> None:
        """Register a named hook handler implementation."""
        self._handlers[name] = handler

    def get_handler(self, name: str) -> HookHandler | None:
        """Fetch a registered hook handler by name."""
        return self._handlers.get(name)

    def dispatch(
        self,
        event: str,
        payload: HookEventPayload,
        subscriptions: list[HookSubscription],
        *,
        raise_on_required_failure: bool = True,
    ) -> HookDispatchReport:
        """Dispatch subscriptions for one event and return structured report."""
        report = HookDispatchReport(event=event)
        for subscription in subscriptions:
            if subscription.event != event:
                continue
            if not self._matches_when(subscription.when, payload):
                report.results.append(
                    HookExecutionResult(
                        name=subscription.name,
                        event=event,
                        handler=subscription.handler,
                        status=HookExecutionStatus.SKIPPED,
                        metadata={"reason": "when_condition_not_met"},
                    )
                )
                continue

            result = self._execute_with_retry(subscription=subscription, payload=payload)
            report.results.append(result)
            if result.status == HookExecutionStatus.FAILED and subscription.required:
                report.blocked = True
                report.blocked_by = subscription.name
                if raise_on_required_failure:
                    raise HookDispatchBlockedError(
                        message=f"Required hook failed: {subscription.name}",
                        report=report,
                        result=result,
                    )
        return report

    def _execute_with_retry(
        self,
        subscription: HookSubscription,
        payload: HookEventPayload,
    ) -> HookExecutionResult:
        """Execute one subscription with retry policy."""
        last_error: str | None = None
        for attempt in range(1, subscription.retry.max_attempts + 1):
            result = self._execute_once(
                subscription=subscription,
                payload=payload,
                attempt=attempt,
            )
            if result.status == HookExecutionStatus.SUCCESS:
                return result
            last_error = result.error
            if attempt < subscription.retry.max_attempts and subscription.retry.backoff_ms > 0:
                delay = self._compute_backoff(subscription.retry, attempt)
                time.sleep(delay)
        return HookExecutionResult(
            name=subscription.name,
            event=subscription.event,
            handler=subscription.handler,
            status=HookExecutionStatus.FAILED,
            attempt=subscription.retry.max_attempts,
            error=last_error or "Hook execution failed",
        )

    @staticmethod
    def _compute_backoff(policy: Any, attempt: int) -> float:
        """Compute backoff delay in seconds for the given attempt."""
        import random as _random

        if policy.backoff_strategy == "exponential":
            delay_ms = policy.backoff_ms * (2 ** (attempt - 1))
            if policy.jitter:
                delay_ms += _random.uniform(0, policy.backoff_ms / 2)
        else:
            delay_ms = policy.backoff_ms
        return min(delay_ms, 30000) / 1000.0

    def _execute_once(
        self,
        subscription: HookSubscription,
        payload: HookEventPayload,
        attempt: int,
    ) -> HookExecutionResult:
        """Execute one hook handler attempt with timeout."""
        handler = self._handlers.get(subscription.handler)
        if handler is None:
            return HookExecutionResult(
                name=subscription.name,
                event=subscription.event,
                handler=subscription.handler,
                status=HookExecutionStatus.FAILED,
                attempt=attempt,
                error=f"Unknown hook handler: {subscription.handler}",
            )

        started = time.perf_counter()
        try:
            with ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(handler, payload, subscription)
                output = future.result(timeout=subscription.timeout_sec)
            elapsed_ms = int((time.perf_counter() - started) * 1000)
            metadata = output if isinstance(output, dict) else {}
            return HookExecutionResult(
                name=subscription.name,
                event=subscription.event,
                handler=subscription.handler,
                status=HookExecutionStatus.SUCCESS,
                attempt=attempt,
                duration_ms=elapsed_ms,
                metadata=metadata,
            )
        except FutureTimeoutError:
            elapsed_ms = int((time.perf_counter() - started) * 1000)
            return HookExecutionResult(
                name=subscription.name,
                event=subscription.event,
                handler=subscription.handler,
                status=HookExecutionStatus.FAILED,
                attempt=attempt,
                duration_ms=elapsed_ms,
                error=f"Hook execution timed out after {subscription.timeout_sec}s",
            )
        except Exception as exc:  # noqa: BLE001 - preserve full failure reason for caller.
            elapsed_ms = int((time.perf_counter() - started) * 1000)
            return HookExecutionResult(
                name=subscription.name,
                event=subscription.event,
                handler=subscription.handler,
                status=HookExecutionStatus.FAILED,
                attempt=attempt,
                duration_ms=elapsed_ms,
                error=str(exc),
            )

    @staticmethod
    def _matches_when(when: str, payload: HookEventPayload) -> bool:
        """Evaluate whether a subscription should run for current dispatch.

        Supported when values:
        - "always": always fires (default)
        - "on_success": fires only when context_status == "success"
        - "on_failure": fires only when context_status == "failure"
        - "on_step:<name>": fires only when context_step_name matches
        """
        if when == "always":
            return True
        if when == "on_success":
            return payload.context_status == "success"
        if when == "on_failure":
            return payload.context_status == "failure"
        if when.startswith("on_step:"):
            target = when[len("on_step:") :]
            return payload.context_step_name == target
        return False
