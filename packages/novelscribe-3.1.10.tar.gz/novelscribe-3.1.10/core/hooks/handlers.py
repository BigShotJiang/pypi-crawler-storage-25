"""Built-in hook handlers with strict guardrail policies."""

from __future__ import annotations

import os
import re
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any

from .event_bus import HookEventBus
from .events import HookEventPayload
from .models import HookSubscription


@dataclass(frozen=True)
class HookHandlerPolicy:
    """Security policy for built-in hook handlers."""

    http_allowed_domains: tuple[str, ...] = ()
    http_allowed_methods: tuple[str, ...] = ("GET", "POST")
    http_timeout_sec_min: int = 1
    http_timeout_sec_max: int = 30
    http_max_payload_bytes: int = 8_192
    http_disallowed_headers: tuple[str, ...] = ("host", "content-length", "connection")
    shell_timeout_sec_min: int = 1
    shell_timeout_sec_max: int = 30
    shell_output_max_chars: int = 4_096
    shell_env_allowlist: tuple[str, ...] = ("PATH", "HOME", "USER", "TMPDIR")
    shell_command_deny_patterns: tuple[str, ...] = field(
        default_factory=lambda: (
            r"rm\s+-rf\s+/",
            r"mkfs",
            r"shutdown",
            r"reboot",
            r":\(\)\s*\{\s*:\|\:&\s*\};:",
        )
    )


def register_builtin_hook_handlers(
    event_bus: HookEventBus,
    policy: HookHandlerPolicy | None = None,
) -> HookHandlerPolicy:
    """Register built-in hook handlers into event bus."""
    guard_policy = policy or HookHandlerPolicy()
    event_bus.register_handler(
        "builtin.http",
        lambda payload, subscription: _execute_http_hook(payload, subscription, guard_policy),
    )
    event_bus.register_handler(
        "builtin.shell",
        lambda payload, subscription: _execute_shell_hook(payload, subscription, guard_policy),
    )
    return guard_policy


def _execute_http_hook(
    payload: HookEventPayload,
    subscription: HookSubscription,
    policy: HookHandlerPolicy,
) -> dict[str, Any]:
    """Execute a guarded HTTP hook."""
    config = subscription.config
    if not isinstance(config, dict):
        raise ValueError("HTTP hook config must be an object")

    method = str(config.get("method", "POST")).upper()
    if method not in policy.http_allowed_methods:
        raise ValueError(f"HTTP method not allowed: {method}")

    url = str(config.get("url", "")).strip()
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme != "https":
        raise ValueError("HTTP hook requires https URL")
    if not parsed.netloc:
        raise ValueError("HTTP hook URL must include host")
    if policy.http_allowed_domains and parsed.hostname not in set(policy.http_allowed_domains):
        raise ValueError(f"HTTP host not in allowlist: {parsed.hostname}")

    timeout = int(subscription.timeout_sec)
    if timeout < policy.http_timeout_sec_min or timeout > policy.http_timeout_sec_max:
        raise ValueError(
            f"HTTP timeout must be between {policy.http_timeout_sec_min}s and "
            f"{policy.http_timeout_sec_max}s"
        )

    body = config.get("body", "")
    if isinstance(body, (dict, list)):
        body = str(body)
    if not isinstance(body, str):
        raise ValueError("HTTP body must be string/dict/list")
    body_bytes = body.encode("utf-8")
    if len(body_bytes) > policy.http_max_payload_bytes:
        raise ValueError(
            f"HTTP payload exceeds limit: {len(body_bytes)} > {policy.http_max_payload_bytes}"
        )

    raw_headers = config.get("headers", {})
    if raw_headers is None:
        raw_headers = {}
    if not isinstance(raw_headers, dict):
        raise ValueError("HTTP headers must be an object")

    disallowed_headers = {h.lower() for h in policy.http_disallowed_headers}
    safe_headers: dict[str, str] = {}
    dropped_headers: list[str] = []
    for key, value in raw_headers.items():
        key_s = str(key).strip()
        if key_s.lower() in disallowed_headers:
            dropped_headers.append(key_s)
            continue
        safe_headers[key_s] = str(value)
    if body_bytes and "Content-Type" not in safe_headers:
        safe_headers["Content-Type"] = "application/json"

    request = urllib.request.Request(
        url=url, method=method, data=body_bytes or None, headers=safe_headers
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            response_status = int(getattr(response, "status", 200))
            response_body = response.read().decode("utf-8", errors="replace")
    except urllib.error.URLError as exc:
        raise ValueError(f"HTTP hook request failed: {exc}") from exc

    return {
        "event": payload.event,
        "status_code": response_status,
        "response_preview": response_body[:512],
        "dropped_headers": dropped_headers,
    }


def _execute_shell_hook(
    payload: HookEventPayload,
    subscription: HookSubscription,
    policy: HookHandlerPolicy,
) -> dict[str, Any]:
    """Execute a guarded shell hook."""
    config = subscription.config
    if not isinstance(config, dict):
        raise ValueError("Shell hook config must be an object")

    script = str(config.get("script", "")).strip()
    if not script:
        raise ValueError("Shell hook script is required")

    timeout = int(subscription.timeout_sec)
    if timeout < policy.shell_timeout_sec_min or timeout > policy.shell_timeout_sec_max:
        raise ValueError(
            f"Shell timeout must be between {policy.shell_timeout_sec_min}s and "
            f"{policy.shell_timeout_sec_max}s"
        )

    for deny_pattern in policy.shell_command_deny_patterns:
        if re.search(deny_pattern, script):
            raise ValueError(f"Shell script contains denied pattern: {deny_pattern}")

    shell_name = str(config.get("shell", "bash")).strip().lower()
    if shell_name not in {"bash", "sh"}:
        raise ValueError(f"Shell not allowed: {shell_name}")

    requested_env = config.get("env", {})
    if requested_env is None:
        requested_env = {}
    if not isinstance(requested_env, dict):
        raise ValueError("Shell env must be an object")
    allowed_env_keys = set(policy.shell_env_allowlist)
    filtered_env = {key: os.environ[key] for key in allowed_env_keys if key in os.environ}
    dropped_env_keys: list[str] = []
    for key, value in requested_env.items():
        key_s = str(key)
        if key_s not in allowed_env_keys:
            dropped_env_keys.append(key_s)
            continue
        filtered_env[key_s] = str(value)

    run_result = subprocess.run(  # noqa: S603
        [shell_name, "-c", script],  # noqa: S607
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout,
        env=filtered_env,
    )

    max_chars = policy.shell_output_max_chars
    stdout_trimmed = run_result.stdout[:max_chars]
    stderr_trimmed = run_result.stderr[:max_chars]
    return {
        "event": payload.event,
        "returncode": run_result.returncode,
        "stdout": stdout_trimmed,
        "stderr": stderr_trimmed,
        "stdout_truncated": len(run_result.stdout) > max_chars,
        "stderr_truncated": len(run_result.stderr) > max_chars,
        "dropped_env_keys": dropped_env_keys,
    }
