"""External hook plugin manager with fail-closed validation."""

from __future__ import annotations

import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
from typing import Any, Callable

import yaml
from pydantic import BaseModel, Field

from .event_bus import HookEventBus
from .events import HookEventPayload
from .models import HookSubscription


class PluginManifest(BaseModel):
    """Manifest contract for an external hook plugin."""

    name: str
    version: str
    api_version: str
    entrypoint: str
    integrity: dict[str, str] = Field(default_factory=dict)


class PluginLoadResult(BaseModel):
    """Single plugin load result."""

    name: str
    loaded: bool
    reason: str = ""
    handler_name: str | None = None


class PluginLoadReport(BaseModel):
    """Aggregate plugin load report for one manager run."""

    loaded: list[PluginLoadResult] = Field(default_factory=list)
    rejected: list[PluginLoadResult] = Field(default_factory=list)


PluginHandler = Callable[[HookEventPayload, HookSubscription], dict[str, Any] | None]


class PluginManager:
    """Loads and registers external plugin handlers under strict validation."""

    SUPPORTED_API_VERSION = "1"

    def __init__(
        self,
        plugin_dirs: list[str | Path],
        *,
        fail_closed: bool = True,
    ) -> None:
        self._plugin_dirs = [Path(directory).resolve() for directory in plugin_dirs]
        self._fail_closed = fail_closed

    def discover_manifest_paths(self) -> list[Path]:
        """Discover plugin manifest files from configured directories."""
        patterns = ("*.plugin.json", "*.plugin.yaml", "*.plugin.yml")
        paths: list[Path] = []
        for directory in self._plugin_dirs:
            if not directory.exists():
                continue
            for pattern in patterns:
                paths.extend(sorted(directory.glob(pattern)))
        return paths

    def load_plugins(self, event_bus: HookEventBus) -> PluginLoadReport:
        """Load all discovered plugins and register them into event bus."""
        report = PluginLoadReport()
        for manifest_path in self.discover_manifest_paths():
            try:
                manifest = self._load_manifest(manifest_path)
                plugin_handler = self._load_callable(manifest_path.parent, manifest)
                handler_name = f"plugin.{manifest.name}"
                event_bus.register_handler(handler_name, plugin_handler)
                report.loaded.append(
                    PluginLoadResult(
                        name=manifest.name,
                        loaded=True,
                        handler_name=handler_name,
                    )
                )
            except Exception as exc:
                plugin_name = manifest_path.stem.split(".plugin")[0]
                report.rejected.append(
                    PluginLoadResult(
                        name=plugin_name,
                        loaded=False,
                        reason=str(exc),
                    )
                )
                if self._fail_closed:
                    continue
        return report

    def _load_manifest(self, manifest_path: Path) -> PluginManifest:
        """Load and validate plugin manifest from JSON/YAML."""
        raw_data = manifest_path.read_text(encoding="utf-8")
        if manifest_path.suffix == ".json":
            parsed = json.loads(raw_data)
        else:
            parsed = yaml.safe_load(raw_data)
        if not isinstance(parsed, dict):
            raise ValueError(f"Plugin manifest must be an object: {manifest_path.name}")

        manifest = PluginManifest(**parsed)
        self._validate_manifest(manifest)
        self._verify_integrity(manifest_path.parent, manifest)
        return manifest

    def _validate_manifest(self, manifest: PluginManifest) -> None:
        """Validate semantic rules beyond schema presence."""
        if manifest.api_version != self.SUPPORTED_API_VERSION:
            raise ValueError(
                f"Unsupported plugin api_version '{manifest.api_version}', "
                f"expected '{self.SUPPORTED_API_VERSION}'"
            )
        if ":" not in manifest.entrypoint:
            raise ValueError("Entrypoint must use '<relative_file.py>:<function>' format")
        file_part, func_part = manifest.entrypoint.split(":", 1)
        if not file_part.endswith(".py"):
            raise ValueError("Entrypoint file must end with .py")
        if not func_part:
            raise ValueError("Entrypoint function name is required")

    def _verify_integrity(self, plugin_root: Path, manifest: PluginManifest) -> None:
        """Verify plugin file integrity using sha256 when provided."""
        expected_sha = manifest.integrity.get("sha256", "").strip()
        if not expected_sha:
            raise ValueError("Manifest integrity.sha256 is required for fail-closed loading")
        file_part, _ = manifest.entrypoint.split(":", 1)
        module_path = (plugin_root / file_part).resolve()
        if not module_path.exists():
            raise FileNotFoundError(f"Plugin module file not found: {module_path}")
        digest = hashlib.sha256(module_path.read_bytes()).hexdigest()
        if digest != expected_sha:
            raise ValueError("Plugin integrity check failed: sha256 mismatch")

    def _load_callable(self, plugin_root: Path, manifest: PluginManifest) -> PluginHandler:
        """Load plugin callable and validate callable interface."""
        file_part, func_name = manifest.entrypoint.split(":", 1)
        module_path = (plugin_root / file_part).resolve()

        module_name = f"hooks_plugin_{manifest.name}_{manifest.version.replace('.', '_')}"
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ValueError(f"Unable to create import spec for plugin: {manifest.name}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        plugin_func = getattr(module, func_name, None)
        if not callable(plugin_func):
            raise ValueError(f"Plugin entrypoint function not callable: {func_name}")

        signature = inspect.signature(plugin_func)
        if len(signature.parameters) < 2:
            raise ValueError("Plugin function must accept at least (payload, subscription)")

        def _wrapped_handler(
            payload: HookEventPayload,
            subscription: HookSubscription,
        ) -> dict[str, Any] | None:
            output = plugin_func(payload, subscription)
            if output is None:
                return None
            if not isinstance(output, dict):
                raise ValueError("Plugin handler output must be dict or None")
            return output

        return _wrapped_handler
