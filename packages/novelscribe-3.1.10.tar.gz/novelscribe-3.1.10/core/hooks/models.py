"""Core hook models for event subscriptions and execution results."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class HookExecutionStatus(str, Enum):
    """Status labels for a single hook invocation."""

    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


class HookRetryPolicy(BaseModel):
    """Retry policy for hook execution."""

    max_attempts: int = Field(default=1, ge=1)
    backoff_ms: int = Field(default=0, ge=0)
    backoff_strategy: str = Field(default="constant", pattern="^(constant|exponential)$")
    jitter: bool = True


class StepRetryPolicy(BaseModel):
    """Retry policy for workflow step execution."""

    max_attempts: int = Field(default=3, ge=1, le=10)
    backoff_ms: int = Field(default=1000, ge=0)
    backoff_strategy: str = Field(default="exponential", pattern="^(constant|exponential)$")
    retry_on: list[str] = Field(
        default_factory=lambda: ["transient_error", "recoverable_model_error"]
    )


class HookSubscription(BaseModel):
    """Declarative hook subscription resolved from configuration."""

    name: str
    event: str
    handler: str
    required: bool = True
    timeout_sec: int = Field(default=30, ge=1)
    when: str = "always"
    config: dict[str, Any] = Field(default_factory=dict)
    retry: HookRetryPolicy = Field(default_factory=HookRetryPolicy)


class HookExecutionResult(BaseModel):
    """Structured result emitted for one hook execution."""

    name: str
    event: str
    handler: str
    status: HookExecutionStatus
    attempt: int = Field(default=1, ge=1)
    duration_ms: int = Field(default=0, ge=0)
    error: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class HookDispatchReport(BaseModel):
    """Aggregated report for one event dispatch."""

    event: str
    blocked: bool = False
    blocked_by: str | None = None
    results: list[HookExecutionResult] = Field(default_factory=list)
