"""Secret provider protocol and built-in implementations."""

import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)

_REDACTED = "***REDACTED***"


@runtime_checkable
class SecretProvider(Protocol):
    """Protocol for resolving secret values by name."""

    def get_secret(self, name: str) -> Optional[str]:
        """Return the secret value or None if not found."""
        ...

    def available_names(self) -> List[str]:
        """Return the list of secret names available from this provider."""
        ...


class EnvSecretProvider:
    """Resolve secrets from environment variables.

    Looks up ``name`` in ``os.environ``.  An optional ``prefix``
    narrows the search (e.g. prefix ``SCRIBE_`` resolves
    ``api_key`` from ``SCRIBE_API_KEY``).
    """

    def __init__(self, prefix: str = "") -> None:
        self._prefix = prefix.upper()

    def get_secret(self, name: str) -> Optional[str]:
        key = f"{self._prefix}{name.upper()}" if self._prefix else name.upper()
        return os.environ.get(key)

    def available_names(self) -> List[str]:
        if not self._prefix:
            return sorted(os.environ.keys())
        return sorted(
            k[len(self._prefix) :].lower() for k in os.environ if k.startswith(self._prefix)
        )


class FileSecretProvider:
    """Resolve secrets from files in a directory.

    Each file in ``secrets_dir`` represents one secret; the file *name*
    (stem) is the secret name and the file *content* (stripped) is the
    value.  Files are expected to have restricted permissions (0600 on
    POSIX).
    """

    def __init__(self, secrets_dir: str | Path) -> None:
        self._dir = Path(secrets_dir)
        self._cache: Dict[str, str] = {}
        self._loaded = False

    def _load(self) -> None:
        if self._loaded:
            return
        self._cache.clear()
        if not self._dir.is_dir():
            logger.debug("Secrets directory %s does not exist", self._dir)
            self._loaded = True
            return
        for fp in self._dir.iterdir():
            if fp.is_file() and not fp.name.startswith("."):
                self._cache[fp.stem] = fp.read_text(encoding="utf-8").strip()
        self._loaded = True

    def get_secret(self, name: str) -> Optional[str]:
        self._load()
        return self._cache.get(name)

    def available_names(self) -> List[str]:
        self._load()
        return sorted(self._cache.keys())

    def invalidate(self) -> None:
        self._loaded = False
        self._cache.clear()


class CompositeSecretProvider:
    """Chain multiple providers; first non-None result wins."""

    def __init__(self, providers: Optional[List[SecretProvider]] = None) -> None:
        self._providers: List[SecretProvider] = providers or []

    def add_provider(self, provider: SecretProvider) -> None:
        self._providers.append(provider)

    def get_secret(self, name: str) -> Optional[str]:
        for provider in self._providers:
            value = provider.get_secret(name)
            if value is not None:
                return value
        return None

    def available_names(self) -> List[str]:
        names: set[str] = set()
        for provider in self._providers:
            names.update(provider.available_names())
        return sorted(names)


class SecretStore:
    """High-level secret access with resolution and redaction.

    Holds a ``CompositeSecretProvider`` and exposes:
    - ``resolve(name)`` – get a secret value
    - ``redact(text)`` – replace all known secret values with a redaction marker
    - ``resolve_variable(path)`` – resolve ``secrets.<name>`` dot-path syntax
    """

    def __init__(self, provider: Optional[SecretProvider] = None) -> None:
        if provider is None:
            composite = CompositeSecretProvider()
            composite.add_provider(FileSecretProvider(Path.cwd() / ".secrets"))
            composite.add_provider(EnvSecretProvider())
            provider = composite
        self._provider = provider
        self._known_values: Dict[str, str] = {}

    def resolve(self, name: str) -> str:
        """Return secret value or raise ``LookupError``."""
        value = self._provider.get_secret(name)
        if value is None:
            raise LookupError(f"Secret '{name}' not found in any provider")
        self._known_values[name] = value
        return value

    def resolve_variable(self, path: str) -> Optional[str]:
        """Resolve a ``secrets.<name>`` dot-path string.

        Returns None if *path* does not start with ``secrets.``.
        """
        if not path.startswith("secrets."):
            return None
        name = path[len("secrets.") :]
        return self.resolve(name)

    def redact(self, text: str) -> str:
        """Replace all previously resolved secret values in *text*."""
        for value in self._known_values.values():
            if value and value in text:
                text = text.replace(value, _REDACTED)
        return text

    @staticmethod
    def redaction_marker() -> str:
        return _REDACTED
