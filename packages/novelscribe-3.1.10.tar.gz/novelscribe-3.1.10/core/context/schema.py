"""Agent context schema and budget allocation models.

Defines how agents declare context needs (ContextNeed, AgentContextSchema)
and how token budgets are allocated per provider (TokenBudget, BudgetAllocator).
"""

from enum import Enum
from typing import TYPE_CHECKING, Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field

from core.llm.client import LLMProvider

if TYPE_CHECKING:
    from .model_registry import ModelRegistry


class ContextScope(str, Enum):
    """Scope for context artifact retrieval."""

    LATEST = "latest"
    RECENT = "recent"
    ALL = "all"
    GROUP = "group"


class ContextNeed(BaseModel):
    """A single context requirement declared by an agent.

    Attributes:
        artifact_type: Type of artifact (meta, outline, characters, world, chapter, summary, etc.)
        scope: How to select — latest (most recent), recent (last N), all, or group
        recent_count: Number of recent items when scope is 'recent'
        max_tokens: Optional cap on tokens for this context block
    """

    artifact_type: str = Field(..., description="Artifact type to retrieve")
    scope: Literal["latest", "recent", "all", "group"] = Field(
        default="latest",
        description="Selection scope",
    )
    recent_count: int = Field(
        default=3,
        ge=1,
        description="Number of recent items when scope is 'recent'",
    )
    max_tokens: Optional[int] = Field(
        default=None,
        ge=1,
        description="Maximum tokens for this context block",
    )


class AgentContextSchema(BaseModel):
    """Full context declaration for an agent.

    Parsed from YAML frontmatter `context_needs` block.

    Attributes:
        required: Context blocks that MUST be included (priority 0, non-compressible by default)
        optional: Context blocks included if budget allows (priority 1, compressible)
        budget_hint: Advisory budget preferences (max_input_tokens, etc.)
    """

    required: List[ContextNeed] = Field(
        default_factory=list,
        description="Required context blocks",
    )
    optional: List[ContextNeed] = Field(
        default_factory=list,
        description="Optional context blocks",
    )
    budget_hint: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Advisory budget preferences",
    )

    @classmethod
    def default_schema(cls) -> "AgentContextSchema":
        """Return the default schema for agents without context_needs declarations."""
        return cls(
            required=[
                ContextNeed(artifact_type="meta"),
                ContextNeed(artifact_type="outline"),
            ],
            optional=[
                ContextNeed(
                    artifact_type="summary",
                    scope="recent",
                    recent_count=2,
                ),
            ],
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AgentContextSchema":
        """Parse AgentContextSchema from a raw dict (e.g., YAML frontmatter).

        Args:
            data: Dict with 'required', 'optional', and/or 'budget_hint' keys.

        Returns:
            Parsed AgentContextSchema.
        """
        required = [ContextNeed(**r) for r in data.get("required", [])]
        optional = [ContextNeed(**o) for o in data.get("optional", [])]
        budget_hint = data.get("budget_hint")

        return cls(required=required, optional=optional, budget_hint=budget_hint)


class TokenBudget(BaseModel):
    """Token budget for a single agent call.

    Attributes:
        total_limit: Provider's context window size
        reserved_output: Tokens reserved for the LLM response (agent's max_tokens)
        available_for_input: total_limit - reserved_output — ceiling for context assembly
        allocated: Tokens already assigned during assembly
    """

    total_limit: int = Field(..., gt=0, description="Provider context window size")
    reserved_output: int = Field(..., ge=0, description="Reserved output tokens")
    available_for_input: int = Field(
        ..., ge=0, description="Total minus reserved — max input tokens"
    )
    allocated: int = Field(default=0, ge=0, description="Tokens assigned so far")

    @property
    def remaining(self) -> int:
        """Tokens still available for allocation."""
        return max(0, self.available_for_input - self.allocated)

    def can_allocate(self, token_count: int) -> bool:
        """Check if tokens can be allocated without exceeding budget."""
        return self.remaining >= token_count

    def allocate(self, token_count: int) -> bool:
        """Allocate tokens if they fit. Returns True if successful."""
        if self.can_allocate(token_count):
            self.allocated += token_count
            return True
        return False

    @classmethod
    def create(
        cls,
        total_limit: int,
        reserved_output: int,
    ) -> "TokenBudget":
        """Create a TokenBudget by computing available_for_input.

        Args:
            total_limit: Provider context window size.
            reserved_output: Tokens reserved for output.

        Returns:
            TokenBudget with computed available_for_input.
        """
        available = max(0, total_limit - reserved_output)
        return cls(
            total_limit=total_limit,
            reserved_output=reserved_output,
            available_for_input=available,
        )


class BudgetAllocator:
    """Allocates token budgets based on provider limits and agent configuration.

    Maps each LLM provider to its context window limit and computes the
    available input budget by subtracting the agent's reserved output tokens.
    """

    PROVIDER_LIMITS: Dict[str, int] = {
        LLMProvider.OPENAI.value: 128_000,
        LLMProvider.CLAUDE.value: 200_000,
        LLMProvider.GEMINI.value: 1_000_000,
        LLMProvider.OLLAMA.value: 8_192,
        LLMProvider.LM_STUDIO.value: 8_192,
    }

    DEFAULT_LIMIT: int = 8_192
    DEFAULT_OUTPUT_TOKENS: int = 4_096

    def __init__(
        self,
        custom_limits: Optional[Dict[str, int]] = None,
        registry: Optional["ModelRegistry"] = None,
    ):
        """Initialize BudgetAllocator.

        Args:
            custom_limits: Optional provider→limit overrides for custom models.
            registry: Optional ModelRegistry to source limits from.
        """
        if registry is not None:
            self._limits = dict(registry._limits)
        else:
            self._limits = dict(self.PROVIDER_LIMITS)
        if custom_limits:
            self._limits.update(custom_limits)

    def get_limit(self, provider: Union[str, LLMProvider]) -> int:
        """Get context window limit for a provider.

        Args:
            provider: Provider name (string or LLMProvider enum).

        Returns:
            Context window token limit.
        """
        key = provider.value if isinstance(provider, LLMProvider) else provider
        return self._limits.get(key, self.DEFAULT_LIMIT)

    def allocate(
        self,
        provider: Union[str, LLMProvider],
        max_tokens: Optional[int] = None,
        schema: Optional[AgentContextSchema] = None,
    ) -> TokenBudget:
        """Allocate token budget for an agent call.

        Args:
            provider: LLM provider to get limits for.
            max_tokens: Agent's max_tokens (reserved for output). Falls back to
                        budget_hint.max_input_tokens from schema, then DEFAULT_OUTPUT_TOKENS.
            schema: Optional agent schema for budget_hint advisory.

        Returns:
            TokenBudget with computed available_for_input.
        """
        total_limit = self.get_limit(provider)

        if max_tokens is not None:
            reserved = max_tokens
        elif schema and schema.budget_hint and "max_input_tokens" in schema.budget_hint:
            hint_input = schema.budget_hint["max_input_tokens"]
            reserved = max(0, total_limit - hint_input)
        else:
            reserved = self.DEFAULT_OUTPUT_TOKENS

        return TokenBudget.create(
            total_limit=total_limit,
            reserved_output=reserved,
        )
