# ruff: noqa: F401, E402, F811
"""core.context — context management subsystem."""

from core.context.assembly import (
    NON_COMPRESSIBLE_TYPES,
    ContextArtifact,
    ContextAssembler,
    ContextBlock,
    ContextNeed,
    TokenBudget,
)
from core.context.bus import (
    BudgetAllocator,
    CompressionResult,
    ContextBus,
    ContextSnapshot,
)
from core.context.cache import (
    CachedChapterManager,
    CacheEntry,
    CacheStatistics,
    ContextCache,
    ContextCacheConfig,
)
from core.context.compressor import (
    CompressionTier,
    ContextCompressor,
)
from core.context.continuity import (
    ContinuityIssue,
    ContinuityParser,
    ContinuityReport,
    IssueType,
    ReportStatus,
    Severity,
)
from core.context.phase_cache import PhaseContextCache
from core.context.schema import (
    AgentContextSchema,
    ContextScope,
)
from core.context.store import (
    CHAPTERS_PER_GROUP,
    ArtifactCorruptedError,
    ArtifactFilter,
    ArtifactNotFoundError,
    ArtifactType,
    ContextStore,
    ContextStoreConfig,
    ContextStoreError,
    IndexCorruptedError,
    ensure_directories,
)
