"""Persistent file-based artifact store for the ContextBus."""

from __future__ import annotations

import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict

from core.llm.estimator import TokenEstimator
from core.utils import ensure_directories

ArtifactType = Literal[
    "meta",
    "outline",
    "characters",
    "world",
    "chapter",
    "summary",
    "verification",
    "plan",
]

CHAPTERS_PER_GROUP = 5


class ContextArtifact(BaseModel):
    """Metadata for a context artifact. Content is stored separately as .md."""

    model_config = ConfigDict(use_enum_values=True)

    artifact_id: str
    artifact_type: ArtifactType
    source_agent: str
    token_count: int
    chapter_number: Optional[int] = None
    metadata: dict[str, Any] = {}
    version: int = 1
    created_at: datetime
    updated_at: datetime

    content: str = ""


class ArtifactFilter(BaseModel):
    """Filter for querying artifacts from the store."""

    artifact_type: Optional[str] = None
    chapter_range: Optional[tuple[int, int]] = None
    summary_group: Optional[int] = None
    version: Optional[int] = None


class ContextSnapshot(BaseModel):
    """Snapshot of store state for resume capability."""

    run_id: str
    created_at: datetime
    phase: str
    step: str
    artifact_ids: list[str]
    total_chapters_completed: int = 0


class ContextStoreConfig(BaseModel):
    """Configuration for the context store."""

    max_versions: int = 5


class ContextStoreError(Exception):
    """Base exception for context store operations."""


class ArtifactNotFoundError(ContextStoreError):
    """Raised when an artifact is not found."""


class ArtifactCorruptedError(ContextStoreError):
    """Raised when an artifact file is corrupted."""


class IndexCorruptedError(ContextStoreError):
    """Raised when the index file is corrupted."""


class ContextStore:
    """Persistent file-based store for context artifacts.

    Features:
    - JSON metadata + separate .md content files
    - Version history (last N versions per artifact)
    - Immediate index updates for consistency
    - Auto-rebuild index from files if corrupted
    - Snapshot save/restore for resume across runs
    """

    def __init__(
        self,
        context_dir: Path,
        config: Optional[ContextStoreConfig] = None,
    ):
        self.context_dir = Path(context_dir)
        self.artifacts_dir = self.context_dir / "artifacts"
        self.content_dir = self.artifacts_dir / "content"
        self.snapshots_dir = self.context_dir / "snapshots"
        self.index_path = self.context_dir / "index.json"
        self.latest_symlink = self.snapshots_dir / "latest.json"
        self.config = config or ContextStoreConfig()
        self._index: dict[str, list[str]] = {}
        self._versions: dict[str, list[int]] = {}
        self._ensure_dirs()
        self._load_or_rebuild_index()

    def _ensure_dirs(self) -> None:
        ensure_directories(self.artifacts_dir, self.content_dir, self.snapshots_dir)

    @staticmethod
    def _make_artifact_id(
        artifact_type: str,
        chapter_number: Optional[int] = None,
    ) -> str:
        if artifact_type == "summary" and chapter_number is not None:
            group = max(1, (chapter_number - 1) // CHAPTERS_PER_GROUP + 1)
            return f"summary.group-{group}"
        if chapter_number is not None:
            return f"{artifact_type}.{chapter_number}"
        seq = 1
        return f"{artifact_type}.{seq}"

    def ingest(
        self,
        artifact_type: ArtifactType,
        content: str,
        source_agent: str,
        chapter_number: Optional[int] = None,
        metadata: Optional[dict[str, Any]] = None,
    ) -> str:
        """Ingest a new artifact or new version of an existing artifact.

        Returns the artifact_id.
        """
        artifact_id = self._make_artifact_id(artifact_type, chapter_number)
        now = datetime.now(timezone.utc)
        token_count = TokenEstimator.estimate_tokens(content)

        existing = self._read_metadata(artifact_id)
        if existing is not None:
            self._version_artifact(artifact_id, existing.version)

        version = (existing.version + 1) if existing else 1

        artifact = ContextArtifact(
            artifact_id=artifact_id,
            artifact_type=artifact_type,
            source_agent=source_agent,
            token_count=token_count,
            chapter_number=chapter_number,
            metadata=metadata or {},
            version=version,
            created_at=existing.created_at if existing else now,
            updated_at=now,
        )

        self._write_artifact(artifact, content)
        self._register_artifact(artifact_id, artifact_type)
        self._prune_old_versions(artifact_id)
        self._flush_index()

        return artifact_id

    def get(self, artifact_id: str) -> ContextArtifact:
        """Retrieve an artifact by ID (latest version) with its content."""
        metadata = self._read_metadata(artifact_id)
        if metadata is None:
            raise ArtifactNotFoundError(f"Artifact not found: {artifact_id}")

        content = self._read_content(artifact_id)
        metadata.content = content
        return metadata

    def get_latest_by_type(self, artifact_type: str) -> Optional[ContextArtifact]:
        """Get the most recent artifact of a given type."""
        ids = self._index.get(artifact_type, [])
        if not ids:
            return None
        try:
            return self.get(ids[-1])
        except ArtifactNotFoundError:
            return None

    def query(self, filter: ArtifactFilter) -> list[ContextArtifact]:
        """Query artifacts by filter criteria. Returns latest versions."""
        candidates: list[str] = []

        if filter.artifact_type:
            candidates = list(self._index.get(filter.artifact_type, []))
        else:
            for ids in self._index.values():
                candidates.extend(ids)

        results: list[ContextArtifact] = []
        for aid in candidates:
            try:
                artifact = self.get(aid)
            except (ArtifactNotFoundError, ArtifactCorruptedError):
                continue

            if filter.chapter_range is not None:
                start, end = filter.chapter_range
                if artifact.chapter_number is None:
                    continue
                if not (start <= artifact.chapter_number <= end):
                    continue

            if filter.summary_group is not None:
                if artifact.artifact_type != "summary":
                    continue
                if artifact.chapter_number is None:
                    continue
                group = (artifact.chapter_number - 1) // CHAPTERS_PER_GROUP + 1
                if group != filter.summary_group:
                    continue

            results.append(artifact)

        return results

    def get_chapter_range(self, start: int, end: int) -> list[ContextArtifact]:
        """Convenience: get chapters in a range."""
        return self.query(ArtifactFilter(artifact_type="chapter", chapter_range=(start, end)))

    def get_summaries(self, chapter_group: Optional[int] = None) -> list[ContextArtifact]:
        """Convenience: get summaries, optionally filtered by group."""
        return self.query(ArtifactFilter(artifact_type="summary", summary_group=chapter_group))

    def save_snapshot(
        self,
        run_id: str,
        phase: str,
        step: str,
        total_chapters_completed: int = 0,
    ) -> ContextSnapshot:
        """Save a snapshot of the current store state."""
        all_ids: list[str] = []
        for ids in self._index.values():
            all_ids.extend(ids)

        snapshot = ContextSnapshot(
            run_id=run_id,
            created_at=datetime.now(timezone.utc),
            phase=phase,
            step=step,
            artifact_ids=all_ids,
            total_chapters_completed=total_chapters_completed,
        )

        snapshot_path = self.snapshots_dir / f"{run_id}.json"
        self._write_json_atomic(snapshot_path, snapshot.model_dump(mode="json"))
        self._update_latest_symlink(run_id)

        return snapshot

    def get_snapshot(self, run_id: Optional[str] = None) -> Optional[ContextSnapshot]:
        """Load a snapshot. Returns latest if run_id is None."""
        if run_id is None:
            target = self.latest_symlink
            if not target.exists():
                return None
            if target.is_symlink():
                resolved = target.resolve()
                if not resolved.exists():
                    return None
                target = resolved
        else:
            target = self.snapshots_dir / f"{run_id}.json"

        if not target.exists():
            return None

        try:
            data = json.loads(target.read_text(encoding="utf-8"))
            data["created_at"] = datetime.fromisoformat(data["created_at"])
            return ContextSnapshot(**data)
        except (json.JSONDecodeError, KeyError, ValueError):
            return None

    def restore_snapshot(self, run_id: Optional[str] = None) -> Optional[ContextSnapshot]:
        """Restore store state from a snapshot. Rebuilds index from disk."""
        snapshot = self.get_snapshot(run_id)
        if snapshot is None:
            return None

        self._index.clear()
        self._versions.clear()
        self._load_or_rebuild_index()

        return snapshot

    def list_artifacts(self) -> dict[str, list[str]]:
        """Return a copy of the current index."""
        return {k: list(v) for k, v in self._index.items()}

    def delete(self, artifact_id: str) -> bool:
        """Delete an artifact and all its versions."""
        meta_path = self.artifacts_dir / f"{artifact_id}.json"
        content_path = self.content_dir / f"{artifact_id}.md"

        if not meta_path.exists():
            return False

        meta_path.unlink(missing_ok=True)
        content_path.unlink(missing_ok=True)

        versions = self._versions.pop(artifact_id, [])
        for v in versions:
            vmeta = self.artifacts_dir / f"{artifact_id}.v{v}.json"
            vcontent = self.content_dir / f"{artifact_id}.v{v}.md"
            vmeta.unlink(missing_ok=True)
            vcontent.unlink(missing_ok=True)

        self._remove_from_index(artifact_id)
        self._flush_index()
        return True

    def _version_artifact(self, artifact_id: str, current_version: int) -> None:
        meta_src = self.artifacts_dir / f"{artifact_id}.json"
        content_src = self.content_dir / f"{artifact_id}.md"

        v = current_version
        meta_dst = self.artifacts_dir / f"{artifact_id}.v{v}.json"
        content_dst = self.content_dir / f"{artifact_id}.v{v}.md"

        if meta_src.exists():
            shutil.move(str(meta_src), str(meta_dst))
        if content_src.exists():
            shutil.move(str(content_src), str(content_dst))

        if artifact_id not in self._versions:
            self._versions[artifact_id] = []
        if v not in self._versions[artifact_id]:
            self._versions[artifact_id].append(v)

    def _prune_old_versions(self, artifact_id: str) -> None:
        versions = self._versions.get(artifact_id, [])
        while len(versions) > self.config.max_versions - 1:
            old_v = versions.pop(0)
            vmeta = self.artifacts_dir / f"{artifact_id}.v{old_v}.json"
            vcontent = self.content_dir / f"{artifact_id}.v{old_v}.md"
            vmeta.unlink(missing_ok=True)
            vcontent.unlink(missing_ok=True)

    def _write_artifact(self, artifact: ContextArtifact, content: str) -> None:
        meta_path = self.artifacts_dir / f"{artifact.artifact_id}.json"
        content_path = self.content_dir / f"{artifact.artifact_id}.md"

        dump = artifact.model_dump(mode="json")
        dump.pop("content", None)
        dump["created_at"] = artifact.created_at.isoformat()
        dump["updated_at"] = artifact.updated_at.isoformat()

        self._write_json_atomic(meta_path, dump)
        self._write_text_atomic(content_path, content)

    def _read_metadata(self, artifact_id: str) -> Optional[ContextArtifact]:
        meta_path = self.artifacts_dir / f"{artifact_id}.json"
        if not meta_path.exists():
            return None
        try:
            data = json.loads(meta_path.read_text(encoding="utf-8"))
            data["created_at"] = datetime.fromisoformat(data["created_at"])
            data["updated_at"] = datetime.fromisoformat(data["updated_at"])
            return ContextArtifact(**data)
        except (json.JSONDecodeError, KeyError, ValueError) as e:
            raise ArtifactCorruptedError(f"Corrupted artifact metadata: {artifact_id}: {e}") from e

    def _read_content(self, artifact_id: str) -> str:
        content_path = self.content_dir / f"{artifact_id}.md"
        if not content_path.exists():
            return ""
        return content_path.read_text(encoding="utf-8")

    def _register_artifact(self, artifact_id: str, artifact_type: str) -> None:
        if artifact_type not in self._index:
            self._index[artifact_type] = []
        if artifact_id not in self._index[artifact_type]:
            self._index[artifact_type].append(artifact_id)

    def _remove_from_index(self, artifact_id: str) -> None:
        for type_ids in self._index.values():
            if artifact_id in type_ids:
                type_ids.remove(artifact_id)
        self._index = {k: v for k, v in self._index.items() if v}

    def _flush_index(self) -> None:
        data: dict[str, Any] = dict(self._index)
        data["_versions"] = dict(self._versions)
        self._write_json_atomic(self.index_path, data)

    def _load_or_rebuild_index(self) -> None:
        if self.index_path.exists():
            try:
                data = json.loads(self.index_path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    self._versions = data.pop("_versions", {})
                    if isinstance(self._versions, dict):
                        self._versions = {
                            k: v for k, v in self._versions.items() if isinstance(v, list)
                        }
                    self._index = {
                        k: v
                        for k, v in data.items()
                        if isinstance(v, list) and not k.startswith("_")
                    }
                    return
            except (json.JSONDecodeError, ValueError):
                pass

        self._rebuild_index_from_files()

    def _rebuild_index_from_files(self) -> None:
        self._index.clear()
        self._versions.clear()

        if not self.artifacts_dir.exists():
            return

        for json_file in self.artifacts_dir.glob("*.json"):
            if ".v" in json_file.name:
                stem = json_file.stem
                parts = stem.rsplit(".v", 1)
                if len(parts) == 2:
                    aid = parts[0]
                    try:
                        v = int(parts[1])
                    except ValueError:
                        continue
                    if aid not in self._versions:
                        self._versions[aid] = []
                    if v not in self._versions[aid]:
                        self._versions[aid].append(v)
                continue

            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
                atype = data.get("artifact_type")
                aid = data.get("artifact_id", json_file.stem)
                if atype and isinstance(atype, str):
                    if atype not in self._index:
                        self._index[atype] = []
                    if aid not in self._index[atype]:
                        self._index[atype].append(aid)
            except (json.JSONDecodeError, KeyError):
                continue

        for aid in self._versions:
            self._versions[aid].sort()

        self._flush_index()

    def _update_latest_symlink(self, run_id: str) -> None:
        target = self.snapshots_dir / f"{run_id}.json"

        if self.latest_symlink.exists() or self.latest_symlink.is_symlink():
            self.latest_symlink.unlink()

        os.symlink(str(target), str(self.latest_symlink))

    def _write_json_atomic(self, path: Path, data: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(f"{path.suffix}.tmp")
        try:
            tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            shutil.move(str(tmp), str(path))
        except OSError as e:
            tmp.unlink(missing_ok=True)
            raise ContextStoreError(f"Failed to write {path}: {e}") from e

    def _write_text_atomic(self, path: Path, content: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(f"{path.suffix}.tmp")
        try:
            tmp.write_text(content, encoding="utf-8")
            shutil.move(str(tmp), str(path))
        except OSError as e:
            tmp.unlink(missing_ok=True)
            raise ContextStoreError(f"Failed to write {path}: {e}") from e
