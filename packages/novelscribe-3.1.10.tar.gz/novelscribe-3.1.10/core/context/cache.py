"""Context cache with LRU eviction for chapter/page content."""

import hashlib
import logging
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    """A cached entry with metadata for LRU tracking."""

    key: str
    content: Any
    size_bytes: int
    access_count: int = 0
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_accessed: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)

    def touch(self):
        """Update the last accessed timestamp and increment access count."""
        self.last_accessed = datetime.now(timezone.utc)
        self.access_count += 1


class ContextCacheConfig(BaseModel):
    """Configuration for context cache."""

    max_size_mb: float = 100.0
    max_entries: int = 100
    enable_compression: bool = False
    eviction_policy: str = "lru"  # lru, lfu, fifo
    track_access_patterns: bool = True
    prefetch_enabled: bool = True
    prefetch_count: int = 3


class CacheStatistics:
    """Track cache performance metrics."""

    def __init__(self):
        self.hits: int = 0
        self.misses: int = 0
        self.evictions: int = 0
        self.prefetch_hits: int = 0
        self.total_bytes_served: int = 0
        self.total_bytes_loaded: int = 0

    @property
    def hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0

    @property
    def miss_rate(self) -> float:
        """Calculate cache miss rate."""
        return 1.0 - self.hit_rate

    @property
    def total_requests(self) -> int:
        """Total number of cache requests."""
        return self.hits + self.misses

    def record_hit(self, bytes_served: int = 0):
        """Record a cache hit."""
        self.hits += 1
        self.total_bytes_served += bytes_served

    def record_miss(self):
        """Record a cache miss."""
        self.misses += 1

    def record_eviction(self):
        """Record a cache eviction."""
        self.evictions += 1

    def record_prefetch_hit(self):
        """Record a prefetch hit."""
        self.prefetch_hits += 1

    def record_bytes_loaded(self, bytes_loaded: int):
        """Record bytes loaded into cache."""
        self.total_bytes_loaded += bytes_loaded

    def get_summary(self) -> Dict[str, Any]:
        """Get cache statistics summary."""
        return {
            "total_requests": self.total_requests,
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": f"{self.hit_rate:.2%}",
            "evictions": self.evictions,
            "prefetch_hits": self.prefetch_hits,
            "total_bytes_served": self.total_bytes_served,
            "total_bytes_loaded": self.total_bytes_loaded,
            "bytes_saved": self.total_bytes_served - self.total_bytes_loaded,
        }


class ContextCache:
    """LRU cache for chapters/pages with memory and prefetch support."""

    def __init__(self, config: Optional[ContextCacheConfig] = None):
        """
        Initialize context cache.

        Args:
            config: Cache configuration
        """
        self.config = config or ContextCacheConfig()

        self.cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self.current_size_bytes: int = 0

        self.stats = CacheStatistics()

        self.access_patterns: Dict[str, List[int]] = {}

    def _calculate_size(self, content: Any) -> int:
        """
        Estimate size of content in bytes.

        Args:
            content: Content to size

        Returns:
            Estimated size in bytes
        """
        if isinstance(content, str):
            return len(content.encode("utf-8"))
        elif isinstance(content, dict):
            return len(str(content).encode("utf-8"))
        elif isinstance(content, list):
            return sum(self._calculate_size(item) for item in content)
        else:
            return len(str(content).encode("utf-8"))

    def _generate_key(self, *args) -> str:
        """
        Generate cache key from arguments.

        Args:
            *args: Arguments to key on

        Returns:
            Cache key
        """
        key_str = ":".join(str(arg) for arg in args)
        return hashlib.md5(key_str.encode()).hexdigest()

    def _evict_lru(self) -> Optional[CacheEntry]:
        """
        Evict least recently used entry.

        Returns:
            Evicted entry or None
        """
        if not self.cache:
            return None

        key, entry = self.cache.popitem(last=False)
        self.current_size_bytes -= entry.size_bytes
        self.stats.record_eviction()

        return entry

    def _evict_if_needed(self, required_bytes: int):
        """
        Evict entries if needed to make space.

        Args:
            required_bytes: Bytes needed
        """
        max_bytes = self.config.max_size_mb * 1024 * 1024

        while (
            self.current_size_bytes + required_bytes > max_bytes
            and len(self.cache) >= self.config.max_entries
        ):
            self._evict_lru()

    def _track_access(self, key: str, chapter_number: int):
        """
        Track access patterns for prefetching.

        Args:
            key: Cache key
            chapter_number: Chapter number
        """
        if not self.config.track_access_patterns:
            return

        if key not in self.access_patterns:
            self.access_patterns[key] = []

        self.access_patterns[key].append(chapter_number)

        if len(self.access_patterns[key]) > 100:
            self.access_patterns[key] = self.access_patterns[key][-50:]

    def get(self, key: str) -> Optional[Any]:
        """
        Get entry from cache.

        Args:
            key: Cache key

        Returns:
            Cached content or None
        """
        if key not in self.cache:
            self.stats.record_miss()
            return None

        entry = self.cache[key]
        entry.touch()

        self.cache.move_to_end(key)
        self.stats.record_hit(entry.size_bytes)

        return entry.content

    def put(self, key: str, content: Any, metadata: Optional[Dict[str, Any]] = None):
        """
        Put entry in cache.

        Args:
            key: Cache key
            content: Content to cache
            metadata: Optional metadata
        """
        size_bytes = self._calculate_size(content)

        if key in self.cache:
            old_entry = self.cache[key]
            self.current_size_bytes -= old_entry.size_bytes

        self._evict_if_needed(size_bytes)

        entry = CacheEntry(key=key, content=content, size_bytes=size_bytes, metadata=metadata or {})

        self.cache[key] = entry
        self.current_size_bytes += size_bytes
        self.stats.record_bytes_loaded(size_bytes)

        self.cache.move_to_end(key)

    def invalidate(self, key: str):
        """
        Invalidate cache entry.

        Args:
            key: Cache key
        """
        if key in self.cache:
            entry = self.cache.pop(key)
            self.current_size_bytes -= entry.size_bytes

    def clear(self):
        """Clear all cache entries."""
        self.cache.clear()
        self.current_size_bytes = 0

    def get_chapter(self, project_name: str, chapter_number: int) -> Optional[Any]:
        """
        Get cached chapter.

        Args:
            project_name: Project name
            chapter_number: Chapter number

        Returns:
            Cached chapter or None
        """
        key = self._generate_key("chapter", project_name, chapter_number)
        content = self.get(key)

        if content:
            self._track_access(key, chapter_number)

        return content

    def put_chapter(
        self,
        project_name: str,
        chapter_number: int,
        content: Any,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Cache chapter.

        Args:
            project_name: Project name
            chapter_number: Chapter number
            content: Chapter content
            metadata: Optional metadata
        """
        key = self._generate_key("chapter", project_name, chapter_number)
        self.put(key, content, metadata)

    def get_page(self, project_name: str, chapter_number: int, page_number: int) -> Optional[Any]:
        """
        Get cached page.

        Args:
            project_name: Project name
            chapter_number: Chapter number
            page_number: Page number

        Returns:
            Cached page or None
        """
        key = self._generate_key("page", project_name, chapter_number, page_number)
        return self.get(key)

    def put_page(
        self,
        project_name: str,
        chapter_number: int,
        page_number: int,
        content: Any,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Cache page.

        Args:
            project_name: Project name
            chapter_number: Chapter number
            page_number: Page number
            content: Page content
            metadata: Optional metadata
        """
        key = self._generate_key("page", project_name, chapter_number, page_number)
        self.put(key, content, metadata)

    def get_prefetch_candidates(self, project_name: str, current_chapter: int) -> List[int]:
        """
        Get candidate chapters for prefetching based on access patterns.

        Args:
            project_name: Project name
            current_chapter: Current chapter number

        Returns:
            List of chapter numbers to prefetch
        """
        if not self.config.prefetch_enabled:
            return []

        key = self._generate_key("chapter", project_name, current_chapter)

        if key not in self.access_patterns:
            return list(
                range(current_chapter + 1, current_chapter + 1 + self.config.prefetch_count)
            )

        return list(range(current_chapter + 1, current_chapter + 1 + self.config.prefetch_count))

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Statistics dictionary
        """
        return {
            **self.stats.get_summary(),
            "current_entries": len(self.cache),
            "current_size_bytes": self.current_size_bytes,
            "current_size_mb": self.current_size_bytes / (1024 * 1024),
            "max_size_mb": self.config.max_size_mb,
            "max_entries": self.config.max_entries,
            "utilization_percent": (
                self.current_size_bytes / (self.config.max_size_mb * 1024 * 1024) * 100
            ),
        }

    def optimize(self):
        """Optimize cache by removing stale entries."""
        max_bytes = self.config.max_size_mb * 1024 * 1024
        target_bytes = max_bytes * 0.8

        while self.current_size_bytes > target_bytes and self.cache:
            self._evict_lru()


class CachedChapterManager:
    """
    Manager for caching chapters with intelligent prefetching.

    Combines ContextCache with chapter loading for optimal performance.
    """

    def __init__(self, cache: Optional[ContextCache] = None):
        """
        Initialize cached chapter manager.

        Args:
            cache: Context cache instance
        """
        self.cache = cache or ContextCache()

    def get_chapter(
        self, project_name: str, chapter_number: int, loader_func: Optional[callable] = None
    ) -> Optional[Any]:
        """
        Get chapter with cache fallback.

        Args:
            project_name: Project name
            chapter_number: Chapter number
            loader_func: Function to load chapter if not cached

        Returns:
            Chapter content or None
        """
        content = self.cache.get_chapter(project_name, chapter_number)

        if content is None and loader_func:
            content = loader_func(chapter_number)

            if content:
                self.cache.put_chapter(
                    project_name,
                    chapter_number,
                    content,
                    {"loaded_at": datetime.now(timezone.utc).isoformat()},
                )

        return content

    def prefetch_chapters(self, project_name: str, current_chapter: int, loader_func: callable):
        """
        Prefetch likely next chapters.

        Args:
            project_name: Project name
            current_chapter: Current chapter number
            loader_func: Function to load chapters
        """
        candidates = self.cache.get_prefetch_candidates(project_name, current_chapter)

        for chapter_num in candidates:
            if not self.cache.get_chapter(project_name, chapter_num):
                try:
                    content = loader_func(chapter_num)
                    if content:
                        self.cache.put_chapter(
                            project_name, chapter_num, content, {"prefetched": True}
                        )
                except Exception:
                    logger.debug("Failed to prefetch chapter %d for %s", chapter_num, project_name)

    def invalidate_chapter(self, project_name: str, chapter_number: int):
        """
        Invalidate cached chapter.

        Args:
            project_name: Project name
            chapter_number: Chapter number
        """
        key = self.cache._generate_key("chapter", project_name, chapter_number)
        self.cache.invalidate(key)

    def invalidate_project(self, project_name: str):
        """
        Invalidate all cached chapters for project.

        Args:
            project_name: Project name
        """
        keys_to_remove = [
            key
            for key in self.cache.cache.keys()
            if f"chapter:{project_name}:" in key or f"page:{project_name}:" in key
        ]

        for key in keys_to_remove:
            self.cache.invalidate(key)

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Statistics dictionary
        """
        return self.cache.get_statistics()
