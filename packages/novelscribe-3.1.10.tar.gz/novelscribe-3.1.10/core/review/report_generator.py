"""Review report generator — aggregates agent outputs into structured reports."""

from __future__ import annotations

from typing import Any, Optional

from core.review.models import (
    ReviewCategory,
    ReviewFinding,
    ReviewReport,
    ReviewSeverity,
)


class ReviewReportGenerator:
    """Aggregates findings from continuity, editorial, and humanization agents.

    Usage::

        generator = ReviewReportGenerator(project_name="my_novel")
        generator.add_findings_from_dict(continuity_output, category=ReviewCategory.CONTINUITY)
        generator.add_findings_from_dict(editorial_output, category=ReviewCategory.EDITORIAL)
        report = generator.generate()
    """

    def __init__(self, project_name: str) -> None:
        self._project = project_name
        self._findings: list[ReviewFinding] = []

    def add_finding(
        self,
        category: ReviewCategory,
        severity: ReviewSeverity,
        description: str,
        chapter: Optional[int] = None,
        suggested_fix: str = "",
        auto_fixable: bool = False,
        location: str = "",
    ) -> None:
        """Add a single finding to the report."""
        self._findings.append(
            ReviewFinding(
                category=category,
                severity=severity,
                chapter=chapter,
                description=description,
                suggested_fix=suggested_fix,
                auto_fixable=auto_fixable,
                location=location,
            )
        )

    def add_findings_from_dict(
        self,
        agent_output: dict[str, Any],
        category: ReviewCategory,
        severity_override: Optional[ReviewSeverity] = None,
    ) -> None:
        """Parse agent output dict and add findings.

        Handles two common agent output formats:
        - ``{"issues_found": [...]}`` — list of issue dicts
        - ``{"findings": [...]}`` — alternative key

        Each issue dict may contain: ``description``, ``severity``,
        ``chapter``, ``location``, ``auto_fixable``, ``suggested_fix``.
        """
        issues_key = "issues_found" if "issues_found" in agent_output else "findings"
        issues = agent_output.get(issues_key, [])
        if not isinstance(issues, list):
            return
        for item in issues:
            if not isinstance(item, dict):
                continue
            severity = self._parse_severity(item.get("severity", ""), severity_override)
            self._findings.append(
                ReviewFinding(
                    category=category,
                    severity=severity,
                    chapter=item.get("chapter"),
                    description=item.get("description", ""),
                    suggested_fix=item.get("suggested_fix", ""),
                    auto_fixable=bool(item.get("auto_fixable", False)),
                    location=item.get("location", ""),
                )
            )

    def generate(self) -> ReviewReport:
        """Build and return the final ReviewReport."""
        return ReviewReport(project=self._project, findings=self._findings)

    def clear(self) -> None:
        """Reset findings for a fresh report."""
        self._findings.clear()

    @staticmethod
    def _parse_severity(
        value: str | ReviewSeverity | None,
        override: ReviewSeverity | None,
    ) -> ReviewSeverity:
        """Convert a severity string or enum to ReviewSeverity."""
        if override is not None:
            return override
        if isinstance(value, ReviewSeverity):
            return value
        if isinstance(value, str):
            normalized = value.lower().strip()
            for sev in ReviewSeverity:
                if sev.value == normalized:
                    return sev
        return ReviewSeverity.INFO
