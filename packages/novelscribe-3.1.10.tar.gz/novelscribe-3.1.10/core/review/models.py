"""Review data models — findings and aggregated report."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, computed_field, model_validator


class ReviewSeverity(str, Enum):
    """Severity level for review findings."""

    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


class ReviewCategory(str, Enum):
    """Category of review finding."""

    CONTINUITY = "continuity"
    EDITORIAL = "editorial"
    HUMANIZATION = "humanization"


class ReviewFinding(BaseModel):
    """A single finding from the review pipeline."""

    category: ReviewCategory
    severity: ReviewSeverity
    chapter: Optional[int] = None
    description: str
    suggested_fix: str = ""
    auto_fixable: bool = False
    location: str = ""


class ReviewReport(BaseModel):
    """Aggregated review report across all pipeline stages."""

    project: str
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    findings: list[ReviewFinding] = Field(default_factory=list)
    total_findings: int = 0
    critical_count: int = 0
    warning_count: int = 0
    info_count: int = 0
    overall_quality_score: float = 0.0

    @model_validator(mode="after")
    def _compute_counts(self) -> ReviewReport:
        self.total_findings = len(self.findings)
        self.critical_count = sum(1 for f in self.findings if f.severity == ReviewSeverity.CRITICAL)
        self.warning_count = sum(1 for f in self.findings if f.severity == ReviewSeverity.WARNING)
        self.info_count = sum(1 for f in self.findings if f.severity == ReviewSeverity.INFO)
        raw_score = (
            100.0
            - (self.critical_count * 20.0)
            - (self.warning_count * 5.0)
            - (self.info_count * 1.0)
        )
        self.overall_quality_score = max(0.0, min(100.0, raw_score))
        return self

    @computed_field
    @property
    def quality_grade(self) -> str:
        """Human-readable quality grade based on overall score."""
        score = self.overall_quality_score
        if score >= 90:
            return "Platinum"
        if score >= 75:
            return "Gold"
        if score >= 50:
            return "Silver"
        return "Bronze"
