"""
Enhanced Cache Manager Implementation for Phase 4.3

Provides advanced caching with TTL, hot/cold key identification,
cache warming, and automatic optimization.
"""

import logging
import threading
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional

from pydantic import BaseModel

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    """Enhanced cache entry with TTL and metadata."""

    key: str
    value: Any
    size_bytes: int
    access_count: int = 0
    last_accessed: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    expiration_time: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    is_hot: bool = False

    def touch(self):
        """Update access statistics."""
        self.last_accessed = datetime.now(timezone.utc)
        self.access_count += 1

    def is_expired(self) -> bool:
        """Check if entry is expired."""
        if self.expiration_time is None:
            return False
        return datetime.now(timezone.utc) > self.expiration_time

    def age_seconds(self) -> float:
        """Get age of entry in seconds."""
        return (datetime.now(timezone.utc) - self.created_at).total_seconds()


class CacheManagerConfig(BaseModel):
    """Configuration for enhanced cache manager."""

    max_size_mb: float = 100.0
    max_entries: int = 100
    default_ttl_seconds: Optional[int] = None
    enable_hot_cold_tracking: bool = True
    hot_threshold: int = 10
    cold_threshold: int = 2
    cleanup_interval_seconds: int = 300
    enable_compression: bool = False
    enable_prefetch: bool = True


class CacheManager:
    """
    Enhanced cache manager with TTL and optimization.

    Features:
    - TTL (Time-To-Live) support
    - Hot/cold key identification
    - Automatic cache warming
    - Memory-aware sizing
    - Expiration policies
    - Cache preloading
    """

    def __init__(self, config: Optional[CacheManagerConfig] = None):
        """
        Initialize cache manager.

        Args:
            config: Cache configuration
        """
        self.config = config or CacheManagerConfig()

        self.cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self.current_size_bytes: int = 0

        self.lock = threading.RLock()

        self.hits: int = 0
        self.misses: int = 0
        self.evictions: int = 0
        self.expirations: int = 0

        self.access_history: List[str] = []
        self.max_history_size: int = 1000

    def get(self, key: str) -> Optional[Any]:
        """
        Get value from cache.

        Args:
            key: Cache key

        Returns:
            Cached value or None
        """
        with self.lock:
            if key not in self.cache:
                self.misses += 1
                return None

            entry = self.cache[key]

            if entry.is_expired():
                self._remove_entry(key)
                self.expirations += 1
                self.misses += 1
                return None

            entry.touch()
            self.cache.move_to_end(key)
            self.hits += 1

            self._track_access(key)

            return entry.value

    def put(
        self,
        key: str,
        value: Any,
        ttl_seconds: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Put value in cache.

        Args:
            key: Cache key
            value: Value to cache
            ttl_seconds: Time-to-live in seconds
            metadata: Optional metadata
        """
        with self.lock:
            size_bytes = self._calculate_size(value)

            if key in self.cache:
                old_entry = self.cache[key]
                self.current_size_bytes -= old_entry.size_bytes

            self._evict_if_needed(size_bytes)

            ttl = ttl_seconds or self.config.default_ttl_seconds
            expiration = None
            if ttl:
                expiration = datetime.now(timezone.utc) + timedelta(seconds=ttl)

            entry = CacheEntry(
                key=key,
                value=value,
                size_bytes=size_bytes,
                expiration_time=expiration,
                metadata=metadata or {},
            )

            self.cache[key] = entry
            self.current_size_bytes += size_bytes

            self.cache.move_to_end(key)

    def invalidate(self, key: str):
        """
        Invalidate cache entry.

        Args:
            key: Cache key
        """
        with self.lock:
            self._remove_entry(key)

    def clear(self):
        """Clear all cache entries."""
        with self.lock:
            self.cache.clear()
            self.current_size_bytes = 0
            self.hits = 0
            self.misses = 0
            self.evictions = 0
            self.expirations = 0

    def clear_expired(self):
        """Clear all expired entries."""
        with self.lock:
            expired_keys = [key for key, entry in self.cache.items() if entry.is_expired()]

            for key in expired_keys:
                self._remove_entry(key)
                self.expirations += 1

            return len(expired_keys)

    def warm_cache(
        self, keys: List[str], loader: Callable[[str], Any], ttl_seconds: Optional[int] = None
    ):
        """
        Warm cache by preloading keys.

        Args:
            keys: Keys to preload
            loader: Function to load values
            ttl_seconds: Optional TTL for preloaded entries
        """
        for key in keys:
            if key not in self.cache:
                try:
                    value = loader(key)
                    if value is not None:
                        self.put(key, value, ttl_seconds)
                except Exception:
                    logger.debug("Failed to preload cache key '%s'", key)

    def optimize(self):
        """Optimize cache by removing cold entries and compressing."""
        with self.lock:
            if self.config.enable_hot_cold_tracking:
                self._remove_cold_entries()

            self._optimize_size()

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Statistics dictionary
        """
        with self.lock:
            hit_rate = self.hits / (self.hits + self.misses) if (self.hits + self.misses) > 0 else 0

            return {
                "entries": len(self.cache),
                "hits": self.hits,
                "misses": self.misses,
                "hit_rate": f"{hit_rate:.2%}",
                "evictions": self.evictions,
                "expirations": self.expirations,
                "current_size_mb": self.current_size_bytes / 1024 / 1024,
                "max_size_mb": self.config.max_size_mb,
                "utilization_percent": (
                    self.current_size_bytes / (self.config.max_size_mb * 1024 * 1024)
                )
                * 100,
            }

    def identify_hot_keys(self) -> List[str]:
        """
        Identify frequently accessed keys.

        Returns:
            List of hot keys
        """
        if not self.config.enable_hot_cold_tracking:
            return []

        with self.lock:
            return [
                key
                for key, entry in self.cache.items()
                if entry.access_count >= self.config.hot_threshold
            ]

    def identify_cold_keys(self) -> List[str]:
        """
        Identify infrequently accessed keys.

        Returns:
            List of cold keys
        """
        if not self.config.enable_hot_cold_tracking:
            return []

        with self.lock:
            cutoff_time = datetime.now(timezone.utc) - timedelta(hours=1)

            return [
                key
                for key, entry in self.cache.items()
                if (
                    entry.access_count <= self.config.cold_threshold
                    and entry.last_accessed < cutoff_time
                )
            ]

    def _calculate_size(self, value: Any) -> int:
        """Calculate size of value in bytes."""
        if isinstance(value, str):
            return len(value.encode("utf-8"))
        elif isinstance(value, dict):
            return len(str(value).encode("utf-8"))
        elif isinstance(value, list):
            return sum(self._calculate_size(item) for item in value)
        else:
            return len(str(value).encode("utf-8"))

    def _evict_if_needed(self, required_bytes: int):
        """Evict entries if needed to make space."""
        max_bytes = self.config.max_size_mb * 1024 * 1024

        while (
            self.current_size_bytes + required_bytes > max_bytes
            or len(self.cache) >= self.config.max_entries
        ):
            if not self.cache:
                break

            key, entry = self.cache.popitem(last=False)
            self.current_size_bytes -= entry.size_bytes
            self.evictions += 1

    def _remove_entry(self, key: str):
        """Remove entry from cache."""
        if key in self.cache:
            entry = self.cache.pop(key)
            self.current_size_bytes -= entry.size_bytes

    def _track_access(self, key: str):
        """Track key access for hot/cold identification."""
        if self.config.enable_hot_cold_tracking:
            self.access_history.append(key)

            if len(self.access_history) > self.max_history_size:
                self.access_history = self.access_history[-self.max_history_size :]

    def _remove_cold_entries(self):
        """Remove cold entries to free space."""
        cold_keys = self.identify_cold_keys()

        for key in cold_keys:
            if len(self.cache) > self.config.max_entries // 2:
                self._remove_entry(key)

    def _optimize_size(self):
        """Optimize cache size."""
        target_bytes = self.config.max_size_mb * 1024 * 1024 * 0.8

        while self.current_size_bytes > target_bytes and self.cache:
            key, entry = self.cache.popitem(last=False)
            self.current_size_bytes -= entry.size_bytes

    def get_access_pattern(self) -> Dict[str, Any]:
        """
        Analyze access patterns.

        Returns:
            Access pattern analysis
        """
        with self.lock:
            if not self.access_history:
                return {"pattern": "insufficient_data"}

            frequency = {}
            for key in self.access_history:
                frequency[key] = frequency.get(key, 0) + 1

            sorted_keys = sorted(frequency.items(), key=lambda x: x[1], reverse=True)

            top_keys = sorted_keys[:10] if len(sorted_keys) >= 10 else sorted_keys

            return {
                "total_accesses": len(self.access_history),
                "unique_keys": len(frequency),
                "top_keys": [{"key": k, "accesses": v} for k, v in top_keys],
                "pattern": "stable" if len(frequency) < len(self.cache) * 0.5 else "diverse",
            }

    def set_ttl(self, key: str, ttl_seconds: int):
        """
        Set TTL for existing entry.

        Args:
            key: Cache key
            ttl_seconds: Time-to-live in seconds
        """
        with self.lock:
            if key in self.cache:
                entry = self.cache[key]
                entry.expiration_time = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)

    def get_entry_info(self, key: str) -> Optional[Dict[str, Any]]:
        """
        Get information about cache entry.

        Args:
            key: Cache key

        Returns:
            Entry information or None
        """
        with self.lock:
            if key not in self.cache:
                return None

            entry = self.cache[key]

            return {
                "key": entry.key,
                "size_bytes": entry.size_bytes,
                "access_count": entry.access_count,
                "created_at": entry.created_at.isoformat(),
                "last_accessed": entry.last_accessed.isoformat(),
                "age_seconds": entry.age_seconds(),
                "is_expired": entry.is_expired(),
                "expiration_time": (
                    entry.expiration_time.isoformat() if entry.expiration_time else None
                ),
                "is_hot": entry.access_count >= self.config.hot_threshold,
                "is_cold": entry.access_count <= self.config.cold_threshold,
            }

    def bulk_invalidate(self, pattern: str):
        """
        Invalidate entries matching pattern.

        Args:
            pattern: Key pattern to match
        """
        import re

        with self.lock:
            regex = re.compile(pattern)
            keys_to_remove = [key for key in self.cache.keys() if regex.match(key)]

            for key in keys_to_remove:
                self._remove_entry(key)

    def get_size_by_key_type(self) -> Dict[str, int]:
        """
        Get memory usage by key type/pattern.

        Returns:
            Dictionary of key patterns to bytes
        """
        with self.lock:
            size_by_type = {}

            for key, entry in self.cache.items():
                key_type = key.split(":")[0] if ":" in key else "other"
                size_by_type[key_type] = size_by_type.get(key_type, 0) + entry.size_bytes

            return size_by_type
