"""core.kb — knowledge base subsystem."""

from core.kb.context_advisor import (
    GENRE_QUERY_MAP,
    KBContextAdvisor,
    Recommendation,
    _build_phase_keyword,
    _construct_query,
    _format_recommendation,
    _normalize_genre,
    _read_selection,
)
from core.kb.context_advisor import (
    _tokenize as _advisor_tokenize,
)
from core.kb.context_block import (
    ESTIMATED_TOKENS_PER_CHAR,
    _build_single_block,
    _count_tokens,
    _extract_section,
    _tokenize,
    _truncate_to_tokens,
    build_kb_context_block,
)
from core.kb.knowledge_harvester import _VALID_KINDS, HarvestResult, KnowledgeHarvester

__all__ = [
    "_VALID_KINDS",
    "_advisor_tokenize",
    "_build_phase_keyword",
    "_build_single_block",
    "_construct_query",
    "_count_tokens",
    "_extract_section",
    "_format_recommendation",
    "_normalize_genre",
    "_read_selection",
    "_tokenize",
    "_truncate_to_tokens",
    "build_kb_context_block",
    "ESTIMATED_TOKENS_PER_CHAR",
    "GENRE_QUERY_MAP",
    "HarvestResult",
    "KBContextAdvisor",
    "KnowledgeHarvester",
    "Recommendation",
]
