"""Knowledge Harvester — learn novel-writing knowledge from the internet."""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional
from uuid import uuid4

logger = logging.getLogger(__name__)

_VALID_KINDS = {
    "narrative_trope",
    "scene_blueprint",
    "character_blueprint",
    "plot_structure",
    "world_building",
}


@dataclass
class HarvestResult:
    """Result of a single harvest operation."""

    query: str
    sources_found: int = 0
    templates_created: int = 0
    template_ids: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class KnowledgeHarvester:
    """Harvest novel-writing knowledge from the internet and add to template KB.

    Uses ``requests`` (already a project dependency) for web fetching.
    Extracts structured content from writing guides and craft articles,
    then writes them as template wiki pages into the KB data directory.
    """

    def __init__(
        self,
        kb_templates_root: Optional[Path] = None,
        lang: str = "en",
        default_kind: str = "narrative_trope",
    ) -> None:
        if kb_templates_root is None:
            try:
                import novel_harness

                harness_root = Path(novel_harness.__file__).parent
            except (ImportError, AttributeError):
                import core.kb.knowledge_harvester as _self

                harness_root = Path(_self.__file__).parent.parent
            kb_templates_root = harness_root / "data" / "kb" / "wiki" / "templates"
        self._root = Path(kb_templates_root)
        self._lang = lang
        self._default_kind = default_kind if default_kind in _VALID_KINDS else "narrative_trope"

    def harvest(
        self,
        topic: str,
        kind: Optional[str] = None,
        max_sources: int = 3,
        interactive: bool = False,
    ) -> HarvestResult:
        """Search the web for writing knowledge on a topic and create templates.

        Args:
            topic: The writing topic to search for (e.g. "three-act structure")
            kind: Template kind to create (default: narrative_trope)
            max_sources: Maximum number of web sources to process
            interactive: If True, prompt user for confirmation before saving

        Returns:
            HarvestResult with counts and any errors.
        """
        result = HarvestResult(query=topic)
        template_kind = kind if kind in _VALID_KINDS else self._default_kind

        raw_content = self._fetch_content(topic, max_sources)
        result.sources_found = len(raw_content)

        if not raw_content:
            result.errors.append(f"No content found for topic: {topic}")
            return result

        structured = self._structure_content(topic, raw_content)
        if not structured:
            result.errors.append(f"Could not structure content for topic: {topic}")
            return result

        for title, body in structured:
            template_id = f"{template_kind}:{uuid4()}"
            page_id = f"template.{template_kind}.{self._lang}.harvested-{uuid4().hex[:8]}"

            if interactive:
                print(f"\n--- Preview: {title} ---")
                print(body[:500])
                confirm = input("\nAdd this template? [y/N]: ").strip().lower()
                if confirm != "y":
                    continue

            saved = self._save_template(
                template_id=template_id,
                page_id=page_id,
                title=title,
                body=body,
                kind=template_kind,
                tags=["harvested", template_kind, self._lang, topic.lower().replace(" ", "-")],
            )
            if saved:
                result.templates_created += 1
                result.template_ids.append(template_id)

        return result

    def _fetch_content(self, topic: str, max_sources: int) -> List[Dict[str, str]]:
        """Fetch web content for a topic using search and page retrieval."""
        try:
            import requests
        except ImportError:
            logger.error("requests library not available for web fetching")
            return []

        results: List[Dict[str, str]] = []
        search_query = f"{topic} novel writing guide craft techniques"

        search_urls = self._build_search_urls(search_query)
        for url in search_urls[:max_sources]:
            try:
                resp = requests.get(
                    url, timeout=10, headers={"User-Agent": "NovelScribe/3.0 (knowledge-harvester)"}
                )
                if resp.status_code == 200:
                    text = self._extract_text(resp.text)
                    if text and len(text) > 200:
                        results.append({"url": url, "content": text})
            except Exception as exc:
                logger.debug("Failed to fetch %s: %s", url, exc)

        return results

    @staticmethod
    def _build_search_urls(query: str) -> List[str]:
        """Build search engine result URLs. Uses DuckDuckGo HTML for no-API-key access."""
        import urllib.parse

        encoded = urllib.parse.quote_plus(query)
        return [
            f"https://html.duckduckgo.com/html/?q={encoded}+writing",
            f"https://html.duckduckgo.com/html/?q={encoded}+craft+techniques",
        ]

    @staticmethod
    def _extract_text(html: str) -> str:
        """Simple HTML-to-text extraction without BeautifulSoup dependency."""
        text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r"<[^>]+>", " ", text)
        text = re.sub(r"&nbsp;", " ", text)
        text = re.sub(r"&amp;", "&", text)
        text = re.sub(r"&lt;", "<", text)
        text = re.sub(r"&gt;", ">", text)
        text = re.sub(r"&quot;", '"', text)
        text = re.sub(r"&#\d+;", "", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    @staticmethod
    def _structure_content(topic: str, raw_items: List[Dict[str, str]]) -> List[tuple[str, str]]:
        """Structure raw web content into (title, body) pairs for templates."""
        structured: List[tuple[str, str]] = []
        combined_parts: List[str] = []

        for item in raw_items:
            content = item.get("content", "")
            url = item.get("url", "")
            if not content:
                continue

            paragraphs = [p.strip() for p in content.split(". ") if len(p.strip()) > 50]
            relevant = paragraphs[:20]
            if relevant:
                body = ". ".join(relevant)
                if len(body) > 2000:
                    body = body[:2000]
                combined_parts.append(f"Source: {url}\n\n{body}")

        if combined_parts:
            combined = "\n\n---\n\n".join(combined_parts)
            title = f"Harvested: {topic.title()}"
            structured.append((title, combined))

        return structured

    def _save_template(
        self,
        template_id: str,
        page_id: str,
        title: str,
        body: str,
        kind: str,
        tags: List[str],
    ) -> bool:
        """Write a template markdown file to the KB data directory."""
        kind_dir = self._root / kind
        kind_dir.mkdir(parents=True, exist_ok=True)
        safe_id = template_id.split(":")[-1] if ":" in template_id else template_id
        filename = f"harvested-{safe_id[:8]}.md"
        filepath = kind_dir / filename

        tags_yaml = ", ".join(tags)
        frontmatter = (
            f"---\n"
            f'page_id: "{page_id}"\n'
            f"type: template\n"
            f'template_id: "{template_id}"\n'
            f'template_kind: "{kind}"\n'
            f'title: "{title}"\n'
            f'language_code: "{self._lang}"\n'
            f"tags: [{tags_yaml}]\n"
            f"---\n\n"
        )

        try:
            filepath.write_text(frontmatter + f"# {title}\n\n{body}\n", encoding="utf-8")
            logger.info("Saved harvested template: %s -> %s", title, filepath)
            return True
        except Exception as exc:
            logger.error("Failed to save template: %s", exc)
            return False
