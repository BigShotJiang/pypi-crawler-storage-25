"""Learning Tracker — facade delegating to promotion and analytics modules."""

import asyncio
import json
from pathlib import Path
from typing import Dict, List, Optional

from core.suggestions.knowledge_base import SuggestionKnowledgeBase
from core.suggestions.learning_analytics import get_learning_insights, get_usage_analytics
from core.suggestions.learning_promotion import PromotionManager
from core.suggestions.models import (
    Suggestion,
    SuggestionCategory,
    SuggestionEvent,
)


class LearningTracker:
    """
    Tracks suggestion acceptance and manages learning analytics.

    Records events, calculates acceptance rates, identifies top suggestions,
    and manages promotion to global knowledge base.
    """

    def __init__(
        self,
        kb: SuggestionKnowledgeBase,
        events_dir: Optional[Path] = None,
        promotion_threshold: int = 5,
    ):
        self.kb = kb
        self.promotion_threshold = promotion_threshold

        if events_dir is None:
            events_dir = Path(__file__).parent.parent / "data" / "suggestions"

        self.events_dir = Path(events_dir)
        self.events_dir.mkdir(parents=True, exist_ok=True)

        self._events_file = self.events_dir / "events.jsonl"
        self._promotion_mgr = PromotionManager(kb, self.events_dir, promotion_threshold)

    @property
    def _pending_promotions(self) -> Dict[str, int]:
        """Backward-compat access to pending promotions."""
        return self._promotion_mgr._pending_promotions

    def _save_pending_promotions(self) -> None:
        """Backward-compat save delegate."""
        self._promotion_mgr._save()

    async def record_acceptance_async(self, event: SuggestionEvent) -> None:
        """Record a suggestion acceptance event asynchronously."""
        await asyncio.to_thread(self.record_acceptance, event)

    def record_acceptance(self, event: SuggestionEvent) -> None:
        """Record a suggestion acceptance event."""
        try:
            event_line = event.model_dump_json()
            with open(self._events_file, "a", encoding="utf-8") as f:
                f.write(event_line + "\n")
            self.kb.update_acceptance_rate(event.suggestion_id, event.accepted_dynamic)
            if event.accepted_dynamic and event.acceptance_prompt_response:
                self._promotion_mgr.increment(event.suggestion_id)
        except Exception:
            pass

    def get_acceptance_rate(self, suggestion_id: str) -> float:
        """Get acceptance rate for a specific suggestion."""
        suggestion = self.kb.get_suggestion(suggestion_id)
        if suggestion:
            return suggestion.acceptance_rate
        return 0.5

    def get_suggestion_events(self, suggestion_id: str, limit: int = 100) -> List[SuggestionEvent]:
        """Get recent events for a specific suggestion."""
        events: List[SuggestionEvent] = []
        if not self._events_file.exists():
            return events
        try:
            with open(self._events_file, "r", encoding="utf-8") as f:
                for line in f:
                    if len(events) >= limit:
                        break
                    try:
                        event_data = json.loads(line.strip())
                        if event_data.get("suggestion_id") == suggestion_id:
                            events.append(SuggestionEvent(**event_data))
                    except Exception:
                        continue
        except Exception:
            pass
        return events

    def get_top_suggestions(
        self, category: SuggestionCategory, language: str = "en", limit: int = 10
    ) -> List[Suggestion]:
        """Get top-performing suggestions by acceptance rate."""
        return self.kb.get_top_suggestions(category, language, limit)

    def should_promote(self, suggestion_id: str, threshold: int) -> bool:
        """Check if a suggestion should be promoted to global KB."""
        return self._promotion_mgr.should_promote(suggestion_id, threshold)

    def promote_to_knowledge_base(self, suggestion_id: str) -> bool:
        """Promote a learned suggestion to global knowledge base."""
        return self._promotion_mgr.promote(suggestion_id)

    def promote_to_learned(self, suggestion_id: str) -> bool:
        """Promote a suggestion to the learned knowledge base (backward compat)."""
        return self.promote_to_knowledge_base(suggestion_id)

    def check_and_auto_promote(self, suggestion_id: str) -> bool:
        """Check if suggestion should be auto-promoted and promote if ready."""
        return self._promotion_mgr.check_and_auto_promote(suggestion_id)

    def generate_promotion_report(self, days: int = 7) -> Dict:
        """Generate a weekly promotion report with top performers."""
        analytics = self.get_usage_analytics(days=days)
        pending = self.get_pending_promotions_detailed(
            threshold=max(1, self.promotion_threshold - 2)
        )

        ready_for_promotion = [p for p in pending if p["ready_for_promotion"]]
        near_threshold = [p for p in pending if not p["ready_for_promotion"]]

        top_performers: List[Dict] = []
        for cat in SuggestionCategory:
            suggestions = self.get_top_suggestions(cat, "en", limit=3)
            top_performers.extend(
                [
                    {
                        "id": s.id,
                        "name": s.name,
                        "category": cat.value,
                        "acceptance_rate": s.acceptance_rate,
                        "acceptance_count": s.acceptance_count,
                    }
                    for s in suggestions
                    if s.acceptance_count > 0
                ]
            )

        return {
            "period_days": days,
            "analytics": analytics,
            "ready_for_promotion": len(ready_for_promotion),
            "near_threshold": len(near_threshold),
            "promotion_candidates": ready_for_promotion[:5],
            "near_threshold_candidates": near_threshold[:5],
            "top_performers": sorted(
                top_performers, key=lambda x: x["acceptance_rate"], reverse=True
            )[:10],
        }

    def get_learning_insights(self, days: int = 30) -> Dict:
        """Get comprehensive learning insights and patterns."""
        analytics = self.get_usage_analytics(days=days)
        report = self.generate_promotion_report(days)
        return get_learning_insights(str(self._events_file), days, analytics, report)

    def get_pending_promotions(self, threshold: Optional[int] = None) -> Dict[str, int]:
        """Get suggestions pending promotion."""
        return self._promotion_mgr.get_pending()

    def get_pending_promotions_detailed(self, threshold: int = 5) -> List[Dict]:
        """Get detailed list of suggestions pending promotion."""
        return self._promotion_mgr.get_pending_detailed(threshold)

    def get_usage_analytics(self, days: int = 7) -> Dict:
        """Get usage analytics for the specified time period."""
        return get_usage_analytics(str(self._events_file), days)

    def get_suggestion_history(self, project_id: str, limit: int = 50) -> List[Dict]:
        """Get suggestion history for a specific project."""
        history: List[Dict] = []
        if not self._events_file.exists():
            return history
        try:
            with open(self._events_file, "r", encoding="utf-8") as f:
                for line in f:
                    if len(history) >= limit:
                        break
                    try:
                        event_data = json.loads(line.strip())
                        if event_data.get("project_id") == project_id:
                            suggestion = self.kb.get_suggestion(event_data.get("suggestion_id"))
                            history.append(
                                {
                                    "event": SuggestionEvent(**event_data),
                                    "suggestion_name": suggestion.name if suggestion else "Unknown",
                                }
                            )
                    except Exception:
                        continue
        except Exception:
            pass
        return history
