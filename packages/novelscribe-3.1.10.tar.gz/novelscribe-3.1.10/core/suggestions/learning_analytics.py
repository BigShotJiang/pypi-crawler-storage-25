"""Learning analytics — usage metrics, insights, and reports."""

from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional

from core.suggestions.models import SuggestionEvent


def scan_events(
    events_file: str,
    days: Optional[int] = None,
    filter_fn: Optional[Callable[[SuggestionEvent], bool]] = None,
) -> List[SuggestionEvent]:
    """Scan JSONL events file with optional date filter."""
    events: List[SuggestionEvent] = []
    cutoff = datetime.now() - timedelta(days=days) if days else None

    try:
        with open(events_file, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    event_data = json.loads(line.strip())
                    event = SuggestionEvent(**event_data)
                    if cutoff and datetime.fromisoformat(event.timestamp.isoformat()) < cutoff:
                        continue
                    if filter_fn and not filter_fn(event):
                        continue
                    events.append(event)
                except Exception:
                    continue
    except Exception:
        pass

    return events


def get_usage_analytics(events_file: str, days: int = 7) -> Dict[str, Any]:
    """Compute usage analytics for the specified time period."""
    events = scan_events(events_file, days=days)

    category_counts: Dict[str, int] = defaultdict(int)
    trigger_counts: Dict[str, int] = defaultdict(int)
    accepted_dynamic = 0

    for event in events:
        category_counts[event.suggestion_category.value] += 1
        trigger_counts[event.trigger_type.value] += 1
        if event.accepted_dynamic:
            accepted_dynamic += 1

    return {
        "period_days": days,
        "total_events": len(events),
        "category_breakdown": dict(category_counts),
        "trigger_breakdown": dict(trigger_counts),
        "dynamic_acceptance_rate": accepted_dynamic / len(events) if events else 0.0,
    }


def get_learning_insights(
    events_file: str,
    days: int,
    analytics: Dict[str, Any],
    report: Dict[str, Any],
) -> Dict[str, Any]:
    """Compute comprehensive learning insights and patterns."""
    events = scan_events(events_file, days=days)

    acceptance_by_category: Dict[str, List[bool]] = defaultdict(list)
    acceptance_by_trigger: Dict[str, List[bool]] = defaultdict(list)

    for event in events:
        acceptance_by_category[event.suggestion_category.value].append(event.accepted_dynamic)
        acceptance_by_trigger[event.trigger_type.value].append(event.accepted_dynamic)

    category_performance = {
        cat: sum(accepts) / len(accepts)
        for cat, accepts in acceptance_by_category.items()
        if accepts
    }
    trigger_performance = {
        trigger: sum(accepts) / len(accepts)
        for trigger, accepts in acceptance_by_trigger.items()
        if accepts
    }

    best_categories = sorted(category_performance.items(), key=lambda x: x[1], reverse=True)[:3]
    best_triggers = sorted(trigger_performance.items(), key=lambda x: x[1], reverse=True)[:3]

    return {
        "period_days": days,
        "total_events": analytics["total_events"],
        "overall_acceptance_rate": analytics["dynamic_acceptance_rate"],
        "category_performance": category_performance,
        "trigger_performance": trigger_performance,
        "best_categories": best_categories,
        "best_triggers": best_triggers,
        "promotion_candidates": report["ready_for_promotion"],
        "recommendations": _generate_recommendations(
            category_performance, trigger_performance, report
        ),
    }


def _generate_recommendations(
    category_performance: Dict[str, float],
    trigger_performance: Dict[str, float],
    report: Dict[str, Any],
) -> List[str]:
    """Generate actionable recommendations based on analytics."""
    recommendations: List[str] = []

    if report["ready_for_promotion"] > 0:
        recommendations.append(
            f"\u2713 {report['ready_for_promotion']} suggestion(s) ready for promotion"
        )

    low_performing = [
        cat
        for cat, rate in category_performance.items()
        if rate < 0.3 and len(category_performance) > 1
    ]
    if low_performing:
        recommendations.append(
            f"\u26a0 Consider reviewing low-performing categories: {', '.join(low_performing)}"
        )

    high_performing_triggers = [
        trigger for trigger, rate in trigger_performance.items() if rate > 0.7
    ]
    if high_performing_triggers:
        recommendations.append(
            f"\u2b50 High-performing triggers: {', '.join(high_performing_triggers)}"
        )

    if not recommendations:
        recommendations.append("\u2713 System performing well. Continue monitoring.")

    return recommendations
