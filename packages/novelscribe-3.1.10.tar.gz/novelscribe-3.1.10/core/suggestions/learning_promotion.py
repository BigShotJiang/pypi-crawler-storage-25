"""Promotion lifecycle — pending state, threshold checks, and KB promotion."""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.suggestions.knowledge_base import SuggestionKnowledgeBase


class PromotionManager:
    """Manages pending promotion state and the promotion lifecycle."""

    def __init__(
        self,
        kb: SuggestionKnowledgeBase,
        events_dir: Path,
        promotion_threshold: int = 5,
    ) -> None:
        self._kb = kb
        self._events_dir = Path(events_dir)
        self.promotion_threshold = promotion_threshold
        self._pending_promotions: Dict[str, int] = defaultdict(int)
        self._load()

    def _load(self) -> None:
        """Load pending promotion counts from disk."""
        pending_file = self._events_dir / "pending_promotions.json"
        if pending_file.exists():
            try:
                with open(pending_file, "r", encoding="utf-8") as f:
                    self._pending_promotions = defaultdict(int, json.load(f))
            except Exception:
                pass

    def _save(self) -> None:
        """Save pending promotion counts to disk."""
        pending_file = self._events_dir / "pending_promotions.json"
        try:
            with open(pending_file, "w", encoding="utf-8") as f:
                json.dump(dict(self._pending_promotions), f, indent=2)
        except Exception:
            pass

    def increment(self, suggestion_id: str) -> None:
        """Increment pending count for a suggestion."""
        self._pending_promotions[suggestion_id] += 1
        self._save()

    def should_promote(self, suggestion_id: str, threshold: Optional[int] = None) -> bool:
        """Check if a suggestion should be promoted to global KB."""
        t = threshold if threshold is not None else self.promotion_threshold
        if suggestion_id not in self._pending_promotions:
            return False
        return self._pending_promotions[suggestion_id] >= t

    def promote(self, suggestion_id: str) -> bool:
        """Promote a learned suggestion to global knowledge base."""
        if not self._kb.promote_to_global(suggestion_id):
            return False
        if suggestion_id in self._pending_promotions:
            del self._pending_promotions[suggestion_id]
            self._save()
        return True

    def check_and_auto_promote(self, suggestion_id: str) -> bool:
        """Check if suggestion should be auto-promoted and promote if ready."""
        if self.should_promote(suggestion_id):
            return self.promote(suggestion_id)
        return False

    def get_pending(self) -> Dict[str, int]:
        """Return raw pending promotions dict."""
        return dict(self._pending_promotions)

    def get_pending_detailed(self, threshold: Optional[int] = None) -> List[Dict[str, Any]]:
        """Return detailed pending promotions with suggestion metadata."""
        t = threshold if threshold is not None else self.promotion_threshold
        pending: List[Dict[str, Any]] = []

        for suggestion_id, count in self._pending_promotions.items():
            suggestion = self._kb.get_suggestion(suggestion_id)
            if not suggestion:
                continue
            ready = count >= t
            entry: Dict[str, Any] = {
                "suggestion": suggestion,
                "acceptance_count": count,
                "threshold": t,
                "ready_for_promotion": ready,
            }
            if not ready:
                entry["remaining"] = t - count
            pending.append(entry)

        return sorted(pending, key=lambda x: x["acceptance_count"], reverse=True)
