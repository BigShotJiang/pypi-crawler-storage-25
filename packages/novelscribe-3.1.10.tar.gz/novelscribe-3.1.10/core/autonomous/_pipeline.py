"""Autonomous pipeline runner — the orchestrating loop for novel generation.

Extracted from AutonomousPhaseRunner. This is the top-level orchestrator:
workflow entry → phase loop → checkpoint → context snapshot → git commit → revision.

Interface:
    run_full_pipeline(
        executor,                    # anything with executor-like interface
        checkpoint_flow,             # CheckpointFlowProtocol
        workflow_executor,           # WorkflowExecutorProtocol
        kb_recommendation_fn,        # (workflow_name: str) -> list[str]
        revision_fn,                 # (workflow_name, chapter) -> None
        include_legacy,              # bool — include human-in-the-loop checkpoints
    ) -> AutonomousResult
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional, Protocol

from core.autonomous.models import AutonomousResult
from core.context.phase_cache import PhaseContextCache
from core.logging.structured import bind_phase, bind_step
from core.metrics import PhaseTimer
from core.progress_tracker import ExecutionStatus

if TYPE_CHECKING:
    pass


class WorkflowExecutorProtocol(Protocol):
    """Minimal protocol for WorkflowExecutor — avoids import cycles."""

    def execute_workflow(
        self,
        workflow_name: str,
        project_name: str,
        variables: dict[str, Any],
        config: dict[str, Any],
    ) -> dict[str, Any]: ...


class CheckpointFlowProtocol(Protocol):
    """Minimal protocol for CheckpointFlow — avoids import cycles."""

    def handle_phase_entry(
        self,
        workflow_name: str,
        current_chapter: Optional[int],
        execution_context: dict[str, Any],
        completed_phases: list[str],
        include_legacy: bool,
    ) -> Optional[AutonomousResult]: ...


def _run_phase_once(
    executor: Any,
    workflow_name: str,
    checkpoint_flow: CheckpointFlowProtocol,
    workflow_executor: WorkflowExecutorProtocol,
    execution_context: dict[str, Any],
    completed_phases: list[str],
    current_chapter: Optional[int],
    include_legacy: bool,
) -> tuple[Optional[AutonomousResult], Optional[int]]:
    """Run a single phase: handle entry → KB → execute → checkpoint → snapshot → git → revision.

    Returns (early_return, updated_current_chapter).
    early_return is non-None when the checkpoint flow returned a result (early exit).
    """
    phase_cache = PhaseContextCache()
    bind_phase(workflow_name)
    bind_step("start")
    try:
        try:
            phase_cache.preload(executor.context_bus.store)
        except Exception:
            executor.logger.debug("Phase cache preload failed, continuing without cache")
        executor.context_bus.phase_cache = phase_cache

        checkpoint_result = checkpoint_flow.handle_phase_entry(
            workflow_name=workflow_name,
            current_chapter=current_chapter,
            execution_context=execution_context,
            completed_phases=completed_phases,
            include_legacy=include_legacy,
        )
        if checkpoint_result is not None:
            return checkpoint_result, current_chapter

        from core.autonomous._phase_runner import AutonomousPhaseRunner

        AutonomousPhaseRunner._run_kb_recommendation_static(executor, workflow_name)

        with PhaseTimer(workflow_name):
            bind_step("execute")
            result = workflow_executor.execute_workflow(
                workflow_name=workflow_name,
                project_name=executor.config.project_name,
                variables=execution_context,
                config=executor.llm_config.model_dump(),
            )

        if not result.get("success"):
            executor.logger.warning(f"⚠️  Workflow '{workflow_name}' completed with warnings")

        completed_phases.append(workflow_name)
        executor.progress_tracker.complete_phase(workflow_name)

        new_chapter = current_chapter
        if workflow_name == "chapter_plan_phase":
            plan = result.get("plan", {})
            if isinstance(plan, dict):
                chapters = plan.get("chapters", [])
                new_chapter = len(chapters) if chapters else 0
            else:
                new_chapter = 0

        state = executor.progress_tracker.get_state()
        if state is None:
            raise RuntimeError("Progress state is None after completing phase")

        executor.checkpoint_manager.create_checkpoint(
            completed_workflows=completed_phases,
            current_workflow=None,
            execution_context=execution_context,
            progress_state=state,
        )

        bind_step("snapshot")
        executor.context_bus.save_snapshot(
            run_id=executor.config.project_name,
            phase=workflow_name,
            step="complete",
        )

        executor.git_manager.auto_commit_step(
            agent="autonomous",
            description=f"Complete {workflow_name}",
        )

        bind_step("revision")
        from core.autonomous._phase_runner import AutonomousPhaseRunner

        AutonomousPhaseRunner._run_revision_loop_static(executor, workflow_name, new_chapter)

        return None, new_chapter
    except Exception as exc:
        executor.logger.error(f"Failed to execute workflow '{workflow_name}': {exc}")
        raise
    finally:
        executor.context_bus.phase_cache = None
        phase_cache.clear()


def run_full_pipeline(
    executor: Any,
    checkpoint_flow: CheckpointFlowProtocol,
    workflow_executor: WorkflowExecutorProtocol,
    kb_recommendation_fn: Any,
    revision_fn: Any,
    include_legacy: bool = True,
) -> AutonomousResult:
    """Execute the full autonomous pipeline for novel generation."""
    executor.logger.info(f"🚀 Starting autonomous pipeline for '{executor.config.project_name}'")

    total_steps = len(executor.WORKFLOW_CHAIN)
    executor.progress_tracker.initialize(total_steps, executor.config.start_phase)

    completed_phases: list[str] = []
    execution_context: dict[str, Any] = {"project_name": executor.config.project_name}
    current_chapter: Optional[int] = None

    start_index = executor._get_workflow_index(executor.config.start_phase)
    end_index = executor._get_workflow_index(executor.config.end_phase)

    for i in range(start_index, end_index + 1):
        workflow_name = executor.WORKFLOW_CHAIN[i]
        if workflow_name == "new_novel" and executor.config.start_phase != "new_novel":
            continue

        executor.progress_tracker.update_phase(workflow_name)
        executor._optimizing_client.reset_circuits()
        executor.logger.info(f"→ Executing phase: {workflow_name}")

        early_return, current_chapter = _run_phase_once(
            executor=executor,
            workflow_name=workflow_name,
            checkpoint_flow=checkpoint_flow,
            workflow_executor=workflow_executor,
            execution_context=execution_context,
            completed_phases=completed_phases,
            current_chapter=current_chapter,
            include_legacy=include_legacy,
        )
        if early_return is not None:
            return early_return

    executor.progress_tracker.set_status(ExecutionStatus.COMPLETED)
    executor.logger.info(
        f"✅ Autonomous pipeline completed successfully for '{executor.config.project_name}'"
    )
    return AutonomousResult(
        success=True,
        completed_phases=completed_phases,
        final_status=ExecutionStatus.COMPLETED,
    )


def run_resume_pipeline(
    executor: Any,
    checkpoint_flow: CheckpointFlowProtocol,
    workflow_executor: WorkflowExecutorProtocol,
    kb_recommendation_fn: Any,
    revision_fn: Any,
) -> AutonomousResult:
    """Resume autonomous pipeline from the latest checkpoint."""
    executor.logger.info(f"🔄 Resuming autonomous pipeline for '{executor.config.project_name}'")

    checkpoint = executor.checkpoint_manager.load_checkpoint()
    if not checkpoint:
        executor.logger.error("No checkpoint found to resume from")
        return AutonomousResult(
            success=False,
            completed_phases=[],
            final_status=ExecutionStatus.FAILED,
            error="No checkpoint found",
        )

    if not executor.checkpoint_manager.validate_checkpoint(checkpoint):
        executor.logger.error("Invalid checkpoint")
        return AutonomousResult(
            success=False,
            completed_phases=[],
            final_status=ExecutionStatus.FAILED,
            error="Invalid checkpoint",
        )

    executor.progress_tracker._state = checkpoint.progress_state
    executor.progress_tracker.set_status(ExecutionStatus.RUNNING)

    context_snapshot = executor.context_bus.restore_snapshot(
        run_id=executor.config.project_name,
    )
    if context_snapshot is not None:
        executor.logger.info(
            f"Restored context snapshot at phase={context_snapshot.phase} "
            f"step={context_snapshot.step}"
        )

    completed_phases: list[str] = checkpoint.completed_workflows
    execution_context: dict[str, Any] = checkpoint.execution_context
    current_chapter: Optional[int] = None

    last_completed = completed_phases[-1] if completed_phases else None
    start_index = executor._get_workflow_index(last_completed) + 1 if last_completed else 0
    end_index = executor._get_workflow_index(executor.config.end_phase)

    for i in range(start_index, end_index + 1):
        workflow_name = executor.WORKFLOW_CHAIN[i]
        executor.progress_tracker.update_phase(workflow_name)
        executor.logger.info(f"→ Executing phase: {workflow_name}")

        early_return, current_chapter = _run_phase_once(
            executor=executor,
            workflow_name=workflow_name,
            checkpoint_flow=checkpoint_flow,
            workflow_executor=workflow_executor,
            execution_context=execution_context,
            completed_phases=completed_phases,
            current_chapter=current_chapter,
            include_legacy=False,
        )
        if early_return is not None:
            return early_return

    executor.progress_tracker.set_status(ExecutionStatus.COMPLETED)
    executor.logger.info("✅ Resumed pipeline completed successfully")
    return AutonomousResult(
        success=True,
        completed_phases=completed_phases,
        final_status=ExecutionStatus.COMPLETED,
    )
