"""Phase execution runner for autonomous workflows."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from core.autonomous._checkpoint_flow import CheckpointFlow
from core.autonomous.models import AutonomousResult
from core.kb import KBContextAdvisor
from core.kb.context_block import build_kb_context_block
from core.quality.revision_loop import RevisionLoop

if TYPE_CHECKING:
    from core.orchestration.autonomous import AutonomousExecutor


class AutonomousPhaseRunner:
    """Runs autonomous phases for both fresh and resumed execution."""

    _PHASE_KIND_MAP = {
        "scene": "scene_blueprint",
        "character_phase": "character_blueprint",
        "outline_phase": "plot_structure",
    }

    _PHASE_NAME_MAP = {
        "scene": "Scene Writing",
        "character_phase": "Character Design",
        "outline_phase": "Story Outline",
    }

    def __init__(
        self,
        executor: "AutonomousExecutor",
        checkpoint_flow: "CheckpointFlow",
    ) -> None:
        self._executor = executor
        self._checkpoint_flow = checkpoint_flow
        self._advisor: Optional[KBContextAdvisor] = None
        self._kb_selected: dict[str, list[str]] = {}

    def _init_advisor(self) -> KBContextAdvisor:
        """Lazy-initialize the KBContextAdvisor once per run."""
        if self._advisor is None:
            executor = self._executor
            self._advisor = KBContextAdvisor(
                config=executor.config.kb_context,
                project_genre=executor.config.project_genre,
                project_lang=executor.config.project_lang,
            )
        return self._advisor

    def _run_kb_recommendation(self, workflow_name: str) -> list[Any]:
        """Run KB recommendation once per phase kind (caching by kind key)."""
        return self._run_kb_recommendation_static(self._executor, workflow_name)

    @staticmethod
    def _run_kb_recommendation_static(executor: Any, workflow_name: str) -> list[Any]:
        """Static version for use in _pipeline.py where no runner instance exists."""
        phase_kind = {
            "scene": "scene_blueprint",
            "character_phase": "character_blueprint",
            "outline_phase": "plot_structure",
        }.get(workflow_name)
        if not phase_kind:
            return []

        advisor = KBContextAdvisor(
            config=executor.config.kb_context,
            project_genre=executor.config.project_genre,
            project_lang=executor.config.project_lang,
        )
        hits = advisor.advise(
            phase_kind=phase_kind,
            phase_name={
                "scene": "Scene Writing",
                "character_phase": "Character Design",
                "outline_phase": "Story Outline",
            }.get(workflow_name, workflow_name),
            interactive=executor.config.human_in_loop,
        )
        page_ids = [h.page_id for h in hits]
        max_tokens = executor.config.kb_context.kb_max_tokens
        if page_ids:
            build_kb_context_block(page_ids, max_tokens=max_tokens)
            executor.logger.info(f"📚 KB selected templates for {phase_kind}: {page_ids}")
        return page_ids

    def _run_revision_loop(
        self,
        workflow_name: str,
        current_chapter: Optional[int],
    ) -> None:
        """Run revision loop after phase completion if eligible."""
        return self._run_revision_loop_static(self._executor, workflow_name, current_chapter)

    @staticmethod
    def _run_revision_loop_static(
        executor: Any,
        workflow_name: str,
        current_chapter: Optional[int],
    ) -> None:
        """Static version for use in _pipeline.py where no runner instance exists."""
        config = executor.config
        loop = RevisionLoop(
            llm_config=executor.llm_config,
            llm_client=executor._optimizing_client,
            git_manager=executor.git_manager,
            storage_path=executor.storage_path,
        )
        if not loop.should_trigger(
            phase_name=workflow_name,
            interactive_revision=config.interactive_revision,
            revision_interval=config.revision_interval,
            current_chapter=current_chapter,
        ):
            return
        result = loop.run(
            phase_name=workflow_name,
            project_name=config.project_name,
            current_chapter=current_chapter,
        )
        if result.revised:
            executor.logger.info(
                f"📝 Revision complete for {workflow_name}: {result.rounds} round(s)"
            )

    def execute_full_pipeline(self) -> AutonomousResult:
        """Execute full autonomous pipeline."""
        from core.autonomous._pipeline import run_full_pipeline

        return run_full_pipeline(
            executor=self._executor,
            checkpoint_flow=self._checkpoint_flow,
            workflow_executor=self._executor.workflow_executor,
            kb_recommendation_fn=lambda w: self._run_kb_recommendation(w),
            revision_fn=lambda w, c: self._run_revision_loop(w, c),
            include_legacy=True,
        )

    def resume_from_checkpoint(self) -> AutonomousResult:
        """Resume autonomous pipeline from the latest persisted checkpoint."""
        from core.autonomous._pipeline import run_resume_pipeline

        return run_resume_pipeline(
            executor=self._executor,
            checkpoint_flow=self._checkpoint_flow,
            workflow_executor=self._executor.workflow_executor,
            kb_recommendation_fn=lambda w: self._run_kb_recommendation(w),
            revision_fn=lambda w, c: self._run_revision_loop(w, c),
        )
