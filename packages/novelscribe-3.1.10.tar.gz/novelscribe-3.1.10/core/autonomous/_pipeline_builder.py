"""Builder for autonomous executor runtime components."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from core.agents.orchestrator_integration import AgentSystemIntegration
from core.autonomous.models import AutonomousConfig
from core.checkpoints.human import HumanCheckpointHandler
from core.checkpoints.manager import CheckpointManager
from core.checkpoints.orchestrator import create_checkpoint_orchestrator
from core.context.bus import ContextBus
from core.git import create_git_manager
from core.llm.client import LLMConfig, MultiLLMClient
from core.llm.optimizing_client import OptimizingLLMClient
from core.memory.bus import MemoryBus, MemoryConfig
from core.progress_tracker import ProgressTracker
from core.resilience import CircuitConfig, TimeoutHandler
from core.storage import StorageBackend, StorageConfig, StorageFactory
from core.workflow.executor import WorkflowExecutor


@dataclass
class PipelineComponents:
    """Bundled collaborators assembled by the pipeline builder."""

    project_path: Path
    storage: StorageBackend
    llm_config: LLMConfig
    optimizing_client: OptimizingLLMClient
    agent_integration: AgentSystemIntegration
    git_manager: Any
    memory_bus: MemoryBus
    context_bus: ContextBus
    workflow_executor: WorkflowExecutor
    progress_tracker: ProgressTracker
    checkpoint_manager: CheckpointManager
    checkpoint_orchestrator: Any | None
    human_handler: HumanCheckpointHandler | None
    timeout_handler: TimeoutHandler | None


class AutonomousPipelineBuilder:
    """Builds runtime collaborators for autonomous execution."""

    def __init__(
        self,
        config: AutonomousConfig,
        storage_path: Path,
        memory_config: Optional[MemoryConfig] = None,
        llm_config_cls: type[LLMConfig] = LLMConfig,
        multi_llm_client_cls: type[MultiLLMClient] = MultiLLMClient,
        optimizing_llm_client_cls: type[OptimizingLLMClient] = OptimizingLLMClient,
        storage_factory: type[StorageFactory] = StorageFactory,
        agent_integration_cls: type[AgentSystemIntegration] = AgentSystemIntegration,
        git_manager_factory: Any = create_git_manager,
        memory_bus_cls: type[MemoryBus] = MemoryBus,
        context_bus_cls: type[ContextBus] = ContextBus,
        workflow_executor_cls: type[WorkflowExecutor] = WorkflowExecutor,
        progress_tracker_cls: type[ProgressTracker] = ProgressTracker,
        checkpoint_manager_cls: type[CheckpointManager] = CheckpointManager,
        checkpoint_orchestrator_factory: Any = create_checkpoint_orchestrator,
        human_checkpoint_handler_cls: type[HumanCheckpointHandler] = HumanCheckpointHandler,
        timeout_handler_cls: type[TimeoutHandler] = TimeoutHandler,
    ) -> None:
        self.config = config
        self.storage_path = storage_path
        self.memory_config = memory_config
        self._llm_config_cls = llm_config_cls
        self._multi_llm_client_cls = multi_llm_client_cls
        self._optimizing_llm_client_cls = optimizing_llm_client_cls
        self._storage_factory = storage_factory
        self._agent_integration_cls = agent_integration_cls
        self._git_manager_factory = git_manager_factory
        self._memory_bus_cls = memory_bus_cls
        self._context_bus_cls = context_bus_cls
        self._workflow_executor_cls = workflow_executor_cls
        self._progress_tracker_cls = progress_tracker_cls
        self._checkpoint_manager_cls = checkpoint_manager_cls
        self._checkpoint_orchestrator_factory = checkpoint_orchestrator_factory
        self._human_checkpoint_handler_cls = human_checkpoint_handler_cls
        self._timeout_handler_cls = timeout_handler_cls
        self.llm_config = self._llm_config_cls(provider=config.provider)

    def build(self) -> PipelineComponents:
        """Build all collaborators required by the executor."""
        project_path = self.storage_path / self.config.project_name
        storage_config = StorageConfig(base_path=str(project_path))
        storage: StorageBackend = self._storage_factory.create(storage_config)

        multi_client = self._create_llm_client(self.llm_config)
        optimizing_client = self._optimizing_llm_client_cls(multi_client)
        llm_client = optimizing_client

        agents_dir = Path("agents")
        agent_integration = self._agent_integration_cls(
            agents_dir=str(agents_dir),
            llm_client=llm_client,
            storage=storage,
            work_dir=str(project_path),
        )

        workflows_dir = Path("workflows")
        git_manager = self._git_manager_factory(project_path, auto_commit=True)

        memory_bus = self._memory_bus_cls(
            project_path=project_path,
            config=self.memory_config,
            llm_client=llm_client,
        )

        context_bus = self._context_bus_cls(
            project_path=project_path,
            llm_client=llm_client,
            agent_loader=agent_integration.registry,
            memory_bus=memory_bus,
        )

        workflow_executor = self._workflow_executor_cls(
            workflows_dir=str(workflows_dir),
            agent_integration=agent_integration,
            storage=storage,
            git_manager=git_manager,
            work_dir=str(project_path),
            context_bus=context_bus,
        )

        progress_tracker = self._progress_tracker_cls(self.config.project_name, project_path)
        checkpoint_manager = self._checkpoint_manager_cls(self.config.project_name, project_path)

        if self.config.human_in_loop:
            checkpoint_orchestrator = self._checkpoint_orchestrator_factory()
            human_handler = None
        else:
            checkpoint_orchestrator = None
            human_handler = self._human_checkpoint_handler_cls(enabled=False)

        timeout_handler: TimeoutHandler | None = None
        if self.config.hybrid_mode and self.config.checkpoint_timeout:
            timeout_handler = self._timeout_handler_cls(
                action=self.config.timeout_action,
                timeout_seconds=self.config.checkpoint_timeout,
            )

        return PipelineComponents(
            project_path=project_path,
            storage=storage,
            llm_config=self.llm_config,
            optimizing_client=optimizing_client,
            agent_integration=agent_integration,
            git_manager=git_manager,
            memory_bus=memory_bus,
            context_bus=context_bus,
            workflow_executor=workflow_executor,
            progress_tracker=progress_tracker,
            checkpoint_manager=checkpoint_manager,
            checkpoint_orchestrator=checkpoint_orchestrator,
            human_handler=human_handler,
            timeout_handler=timeout_handler,
        )

    def _create_llm_client(self, llm_config: LLMConfig) -> MultiLLMClient:
        """Create MultiLLMClient with optional fallback from environment."""
        fallback_config = self._get_fallback_config()
        circuit_config = self._get_circuit_config()
        return self._multi_llm_client_cls(
            primary_config=llm_config,
            fallback_config=fallback_config,
            circuit_config=circuit_config,
        )

    def _get_fallback_config(self) -> LLMConfig | None:
        """Get fallback LLM config from environment variables."""
        provider = os.environ.get("SCRIBE_FALLBACK_PROVIDER")
        if not provider:
            return None
        return self._llm_config_cls(
            provider=provider,
            api_key=os.environ.get("SCRIBE_FALLBACK_API_KEY"),
            model=os.environ.get("SCRIBE_FALLBACK_MODEL"),
        )

    def _get_circuit_config(self) -> CircuitConfig | None:
        """Get circuit breaker config from environment or defaults."""
        threshold = os.environ.get("SCRIBE_CIRCUIT_THRESHOLD")
        cooldown = os.environ.get("SCRIBE_CIRCUIT_COOLDOWN")
        if threshold or cooldown:
            return CircuitConfig(
                failure_threshold=int(threshold) if threshold else 5,
                cooldown_seconds=float(cooldown) if cooldown else 60.0,
            )
        return None
