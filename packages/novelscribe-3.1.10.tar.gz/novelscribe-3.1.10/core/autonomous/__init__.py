# ruff: noqa: F401
"""core.autonomous — autonomous pipeline modules."""
