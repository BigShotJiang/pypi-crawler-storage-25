"""Benchmark Data Models for Novel Generation.

Defines enums and Pydantic models for the benchmarking system.
"""

import math
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, Field

from core.quality.metric_types import QualityMetrics


class BenchmarkType(str, Enum):
    """Types of benchmarks."""

    PERFORMANCE = "performance"
    QUALITY = "quality"
    STYLE = "style"
    READABILITY = "readability"


class ComparisonMetric(str, Enum):
    """Metrics for comparison."""

    GENERATION_TIME = "generation_time"
    TOKEN_USAGE = "token_usage"
    WORDS_PER_MINUTE = "words_per_minute"
    QUALITY_SCORE = "quality_score"
    READABILITY_SCORE = "readability_score"
    DIALOGUE_RATIO = "dialogue_ratio"
    VOCABULARY_DIVERSITY = "vocabulary_diversity"


class BenchmarkResult(BaseModel):
    """Single benchmark result."""

    benchmark_type: BenchmarkType
    category: str
    score: float
    percentile: Optional[float] = None
    comparison: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: Dict[str, Any] = Field(default_factory=dict)

    def __str__(self) -> str:
        """Format benchmark result for display."""
        result = f"{self.category}: {self.score:.2f}"
        if self.percentile is not None:
            result += f" (percentile: {self.percentile:.1f}%)"
        if self.comparison:
            result += f" - {self.comparison}"
        return result


class BenchmarkReport(BaseModel):
    """Complete benchmark report."""

    project_name: str
    timestamp: datetime
    results: List[BenchmarkResult]

    @property
    def performance_score(self) -> float:
        """Calculate overall performance score."""
        perf_results = [r for r in self.results if r.benchmark_type == BenchmarkType.PERFORMANCE]
        if not perf_results:
            return 0.0
        return sum(r.score for r in perf_results) / len(perf_results)

    @property
    def quality_score(self) -> float:
        """Calculate overall quality score."""
        quality_results = [r for r in self.results if r.benchmark_type == BenchmarkType.QUALITY]
        if not quality_results:
            return 0.0
        return sum(r.score for r in quality_results) / len(quality_results)

    def get_results_by_type(self, benchmark_type: BenchmarkType) -> List[BenchmarkResult]:
        """Filter results by benchmark type."""
        return [r for r in self.results if r.benchmark_type == benchmark_type]

    def get_results_by_category(self, category: str) -> List[BenchmarkResult]:
        """Filter results by category."""
        return [r for r in self.results if r.category == category]


class PerformanceMetrics(BaseModel):
    """Performance tracking metrics."""

    generation_time_seconds: float
    token_count: int
    word_count: int
    words_per_minute: float
    tokens_per_second: float
    timestamp: datetime = Field(default_factory=datetime.now)


class BenchmarkHistory(BaseModel):
    """Historical benchmark data."""

    project_name: str
    entries: List[QualityMetrics] = Field(default_factory=list)
    performance_entries: List[PerformanceMetrics] = Field(default_factory=list)

    def add_metrics(self, metrics: QualityMetrics):
        """Add quality metrics to history."""
        self.entries.append(metrics)

    def add_performance(self, performance: PerformanceMetrics):
        """Add performance metrics to history."""
        self.performance_entries.append(performance)

    def get_trend(self, metric: str) -> Tuple[float, float]:
        """Get trend for a specific metric (slope, correlation)."""
        if len(self.entries) < 2:
            return 0.0, 0.0

        values = []
        for entry in self.entries:
            if hasattr(entry, metric):
                values.append(getattr(entry, metric))

        if len(values) < 2:
            return 0.0, 0.0

        x = list(range(len(values)))
        y = values

        n = len(x)
        sum_x = sum(x)
        sum_y = sum(y)
        sum_xy = sum(xi * yi for xi, yi in zip(x, y))
        sum_x2 = sum(xi**2 for xi in x)
        sum_y2 = sum(yi**2 for yi in y)

        numerator = n * sum_xy - sum_x * sum_y
        denominator_x = n * sum_x2 - sum_x**2
        denominator_y = n * sum_y2 - sum_y**2

        slope = numerator / denominator_x if denominator_x != 0 else 0.0

        denominator = math.sqrt(denominator_x * denominator_y)
        correlation = numerator / denominator if denominator != 0 else 0.0

        return slope, correlation
