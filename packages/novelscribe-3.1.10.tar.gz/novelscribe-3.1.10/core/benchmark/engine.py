"""Benchmarking Engine for Novel Generation.

Provides the core engine for tracking performance metrics,
quality comparisons, and progress monitoring.
"""

import json
import statistics
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.quality.metric_types import QualityMetrics

from .models import (
    BenchmarkHistory,
    BenchmarkReport,
    BenchmarkResult,
    BenchmarkType,
    PerformanceMetrics,
)


class BenchmarkingEngine:
    """
    Comprehensive benchmarking engine for novel generation.

    Tracks performance metrics, compares quality against benchmarks,
    and monitors progress over time.
    """

    QUALITY_BENCHMARKS = {
        "published_novel": {
            "flesch_kincaid": (7.0, 10.0),
            "dialogue_ratio": (0.2, 0.4),
            "vocabulary_diversity": (0.4, 0.6),
            "quality_score": (0.7, 0.9),
        },
        "bestseller": {
            "flesch_kincaid": (6.0, 9.0),
            "dialogue_ratio": (0.25, 0.45),
            "vocabulary_diversity": (0.45, 0.65),
            "quality_score": (0.8, 0.95),
        },
    }

    GENRE_BENCHMARKS = {
        "fantasy": {
            "flesch_kincaid": (6.5, 9.5),
            "passive_voice_ratio": (0.0, 0.12),
            "quality_score": (0.7, 0.9),
        },
        "mystery": {
            "flesch_kincaid": (7.0, 10.0),
            "dialogue_ratio": (0.3, 0.5),
            "quality_score": (0.75, 0.92),
        },
        "romance": {
            "flesch_kincaid": (6.0, 8.5),
            "dialogue_ratio": (0.35, 0.55),
            "quality_score": (0.7, 0.9),
        },
        "scifi": {
            "flesch_kincaid": (7.5, 10.5),
            "vocabulary_diversity": (0.5, 0.7),
            "quality_score": (0.7, 0.9),
        },
    }

    def __init__(self, project_root: Optional[Path | str] = None):
        if isinstance(project_root, str):
            project_root = Path(project_root)
        self.project_root = project_root or Path.cwd()
        self.history: Dict[str, BenchmarkHistory] = {}
        self._load_history()

    def _load_history(self):
        history_path = self.project_root / ".scribe" / "benchmark_history.json"
        if history_path.exists():
            try:
                with open(history_path, "r") as f:
                    data = json.load(f)
                    for project_name, project_data in data.items():
                        self.history[project_name] = BenchmarkHistory(**project_data)
            except Exception as e:
                print(f"Warning: Could not load benchmark history: {e}")

    def _save_history(self):
        history_dir = self.project_root / ".scribe"
        history_dir.mkdir(exist_ok=True)
        history_path = history_dir / "benchmark_history.json"

        try:
            with open(history_path, "w", encoding="utf-8") as f:
                json.dump(
                    {name: history.model_dump() for name, history in self.history.items()},
                    f,
                    indent=2,
                    default=str,
                )
        except Exception as e:
            print(f"Warning: Could not save benchmark history: {e}")

    def benchmark_performance(
        self, project_name: str, generation_time: float, token_count: int, word_count: int
    ) -> BenchmarkResult:
        words_per_minute = (word_count / generation_time) * 60 if generation_time > 0 else 0
        tokens_per_second = token_count / generation_time if generation_time > 0 else 0

        performance = PerformanceMetrics(
            generation_time_seconds=generation_time,
            token_count=token_count,
            word_count=word_count,
            words_per_minute=words_per_minute,
            tokens_per_second=tokens_per_second,
        )

        if project_name not in self.history:
            self.history[project_name] = BenchmarkHistory(project_name=project_name)
        self.history[project_name].add_performance(performance)

        percentile = self._calculate_percentile(
            words_per_minute,
            [p.words_per_minute for p in self.history[project_name].performance_entries],
        )

        comparison = self._generate_comparison(words_per_minute, 100, 500)

        result = BenchmarkResult(
            benchmark_type=BenchmarkType.PERFORMANCE,
            category="words_per_minute",
            score=words_per_minute,
            percentile=percentile,
            comparison=comparison,
            metadata={
                "generation_time": generation_time,
                "token_count": token_count,
                "word_count": word_count,
                "tokens_per_second": tokens_per_second,
            },
        )

        self._save_history()
        return result

    def benchmark_quality(
        self,
        project_name: str,
        metrics: QualityMetrics,
        comparison_benchmark: str = "published_novel",
        genre: Optional[str] = None,
    ) -> List[BenchmarkResult]:
        if project_name not in self.history:
            self.history[project_name] = BenchmarkHistory(project_name=project_name)
        self.history[project_name].add_metrics(metrics)

        results = []

        benchmark = self.QUALITY_BENCHMARKS.get(comparison_benchmark, {})
        if genre and genre in self.GENRE_BENCHMARKS:
            benchmark.update(self.GENRE_BENCHMARKS[genre])

        quality_metrics = [
            ("flesch_kincaid", metrics.flesch_kincaid),
            ("dialogue_ratio", metrics.dialogue_ratio),
            ("vocabulary_diversity", metrics.vocabulary_diversity),
            ("passive_voice_ratio", metrics.passive_voice_ratio),
        ]

        for metric_name, metric_value in quality_metrics:
            if metric_name in benchmark:
                min_val, max_val = benchmark[metric_name]

                if metric_name == "passive_voice_ratio":
                    in_range = min_val <= metric_value <= max_val
                    score = (
                        1.0 - metric_value if in_range else max(0, 1.0 - (metric_value - max_val))
                    )
                else:
                    in_range = min_val <= metric_value <= max_val
                    if in_range:
                        score = 1.0
                    elif metric_value < min_val:
                        score = max(0, metric_value / min_val)
                    else:
                        score = max(0, 1.0 - (metric_value - max_val) / max_val)

                comparison = self._generate_comparison(metric_value, min_val, max_val)

                result = BenchmarkResult(
                    benchmark_type=BenchmarkType.QUALITY,
                    category=metric_name,
                    score=metric_value,
                    comparison=comparison,
                    metadata={"in_range": in_range, "score": score},
                )
                results.append(result)

        overall_result = BenchmarkResult(
            benchmark_type=BenchmarkType.QUALITY,
            category="overall_quality_score",
            score=metrics.overall_quality_score,
            comparison=self._generate_comparison(metrics.overall_quality_score, 0.7, 0.9),
            metadata={"quality_gate": self._determine_quality_gate(metrics.overall_quality_score)},
        )
        results.append(overall_result)

        self._save_history()
        return results

    def generate_benchmark_report(
        self, project_name: str, benchmark_type: Optional[BenchmarkType] = None
    ) -> BenchmarkReport:
        results = []

        if project_name in self.history:
            history = self.history[project_name]

            if benchmark_type is None or benchmark_type == BenchmarkType.PERFORMANCE:
                for perf in history.performance_entries[-10:]:
                    result = BenchmarkResult(
                        benchmark_type=BenchmarkType.PERFORMANCE,
                        category="performance",
                        score=perf.words_per_minute,
                        metadata={
                            "generation_time": perf.generation_time_seconds,
                            "token_count": perf.token_count,
                            "word_count": perf.word_count,
                        },
                    )
                    results.append(result)

            if benchmark_type is None or benchmark_type == BenchmarkType.QUALITY:
                for metrics in history.entries[-10:]:
                    result = BenchmarkResult(
                        benchmark_type=BenchmarkType.QUALITY,
                        category="quality",
                        score=metrics.overall_quality_score,
                        metadata={"chapter": metrics.chapter_number, "version": metrics.version},
                    )
                    results.append(result)

        return BenchmarkReport(project_name=project_name, timestamp=datetime.now(), results=results)

    def compare_versions(
        self, project_name: str, metrics1: QualityMetrics, metrics2: QualityMetrics
    ) -> Dict[str, Dict[str, float]]:
        comparisons = {
            "content_metrics": {
                "word_count_change": metrics2.word_count - metrics1.word_count,
                "word_count_percent_change": (
                    (metrics2.word_count - metrics1.word_count) / max(metrics1.word_count, 1)
                )
                * 100,
                "sentence_count_change": metrics2.sentence_count - metrics1.sentence_count,
            },
            "readability_metrics": {
                "flesch_kincaid_change": metrics2.flesch_kincaid - metrics1.flesch_kincaid,
                "gunning_fog_change": metrics2.gunning_fog - metrics1.gunning_fog,
            },
            "dialogue_metrics": {
                "dialogue_ratio_change": metrics2.dialogue_ratio - metrics1.dialogue_ratio,
                "speaker_clarity_change": metrics2.speaker_clarity - metrics1.speaker_clarity,
            },
            "style_metrics": {
                "passive_voice_change": metrics2.passive_voice_ratio - metrics1.passive_voice_ratio,
                "adverb_frequency_change": metrics2.adverb_frequency - metrics1.adverb_frequency,
                "vocabulary_diversity_change": metrics2.vocabulary_diversity
                - metrics1.vocabulary_diversity,
            },
            "overall": {
                "quality_score_change": metrics2.overall_quality_score
                - metrics1.overall_quality_score,
                "improved": metrics2.overall_quality_score > metrics1.overall_quality_score,
            },
        }

        return comparisons

    def track_progress(
        self, project_name: str, metric: str = "overall_quality_score"
    ) -> Dict[str, Any]:
        if project_name not in self.history or not self.history[project_name].entries:
            return {"trend": "no_data", "current": None, "average": None, "improvement": None}

        entries = self.history[project_name].entries
        values = []
        for entry in entries:
            if hasattr(entry, metric):
                values.append(getattr(entry, metric))

        if not values:
            return {"trend": "no_data", "current": None, "average": None, "improvement": None}

        current = values[-1]
        average = statistics.mean(values)

        if len(values) >= 3:
            recent_avg = statistics.mean(values[-3:])
            older_avg = statistics.mean(values[:-3]) if len(values) > 3 else average
            improvement = ((recent_avg - older_avg) / max(older_avg, 0.01)) * 100

            if values[-1] > values[-2] > values[-3]:
                trend = "improving"
            elif values[-1] < values[-2] < values[-3]:
                trend = "declining"
            else:
                trend = "stable"
        else:
            improvement = ((values[-1] - values[0]) / max(values[0], 0.01)) * 100
            trend = "improving" if values[-1] > values[0] else "declining"

        return {
            "trend": trend,
            "current": current,
            "average": average,
            "improvement": improvement,
            "total_entries": len(values),
        }

    def _calculate_percentile(self, value: float, reference_values: List[float]) -> float:
        if not reference_values:
            return 50.0

        smaller = sum(1 for v in reference_values if v < value)
        equal = sum(1 for v in reference_values if v == value)

        percentile = ((smaller + 0.5 * equal) / len(reference_values)) * 100
        return percentile

    def _generate_comparison(self, value: float, min_benchmark: float, max_benchmark: float) -> str:
        if value < min_benchmark:
            diff = min_benchmark - value
            return f"{diff:.1f} below minimum benchmark"
        elif value > max_benchmark:
            diff = value - max_benchmark
            return f"{diff:.1f} above maximum benchmark"
        else:
            return "within benchmark range"

    def _determine_quality_gate(self, score: float) -> str:
        if score >= 0.9:
            return "platinum"
        elif score >= 0.8:
            return "gold"
        elif score >= 0.7:
            return "silver"
        else:
            return "bronze"

    def export_benchmark_data(self, project_name: str, output_path: Optional[Path] = None) -> Path:
        if output_path is None:
            output_path = self.project_root / f"{project_name}_benchmarks.json"

        if project_name not in self.history:
            raise ValueError(f"No benchmark history found for project: {project_name}")

        history = self.history[project_name]

        export_data = {
            "project_name": project_name,
            "export_timestamp": datetime.now().isoformat(),
            "quality_metrics": [m.model_dump() for m in history.entries],
            "performance_metrics": [p.model_dump() for p in history.performance_entries],
            "summary": {
                "total_quality_entries": len(history.entries),
                "total_performance_entries": len(history.performance_entries),
                "latest_quality_score": (
                    history.entries[-1].overall_quality_score if history.entries else None
                ),
                "latest_words_per_minute": (
                    history.performance_entries[-1].words_per_minute
                    if history.performance_entries
                    else None
                ),
            },
        }

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(export_data, f, indent=2, default=str)

        return output_path

    def get_statistics(self, project_name: str) -> Dict[str, Any]:
        if project_name not in self.history:
            return {"error": "Project not found in benchmark history"}

        history = self.history[project_name]

        quality_scores = [m.overall_quality_score for m in history.entries]
        performance_scores = [p.words_per_minute for p in history.performance_entries]

        stats = {
            "project_name": project_name,
            "quality_metrics": {
                "total_entries": len(quality_scores),
                "average_score": statistics.mean(quality_scores) if quality_scores else None,
                "min_score": min(quality_scores) if quality_scores else None,
                "max_score": max(quality_scores) if quality_scores else None,
                "std_dev": statistics.stdev(quality_scores) if len(quality_scores) > 1 else None,
            },
            "performance_metrics": {
                "total_entries": len(performance_scores),
                "average_wpm": statistics.mean(performance_scores) if performance_scores else None,
                "min_wpm": min(performance_scores) if performance_scores else None,
                "max_wpm": max(performance_scores) if performance_scores else None,
                "std_dev": (
                    statistics.stdev(performance_scores) if len(performance_scores) > 1 else None
                ),
            },
        }

        return stats
