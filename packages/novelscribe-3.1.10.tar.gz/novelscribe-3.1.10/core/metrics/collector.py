"""Lightweight in-memory metrics collection for NovelScribe.

Thread-safe counters, gauges, and histograms for operational observability.
Designed for the /metrics API endpoint — not for Prometheus/OTel export.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Counter:
    """Thread-safe monotonic counter with optional label dimension."""

    _value: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def inc(self, amount: int = 1) -> None:
        with self._lock:
            self._value += amount

    @property
    def value(self) -> int:
        with self._lock:
            return self._value

    def reset(self) -> None:
        with self._lock:
            self._value = 0


@dataclass
class Histogram:
    """Simple histogram with configurable buckets.

    Records observations and maintains count, sum, min, max,
    and per-bucket counts for latency distribution visualization.
    """

    buckets: list[float] = field(default_factory=lambda: [10, 50, 100, 250, 500, 1000, 5000])
    _count: int = 0
    _sum: float = 0.0
    _min: float = float("inf")
    _max: float = 0.0
    _bucket_counts: list[int] = field(default_factory=list, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def __post_init__(self) -> None:
        self._bucket_counts = [0] * (len(self.buckets) + 1)

    def observe(self, value: float) -> None:
        with self._lock:
            self._count += 1
            self._sum += value
            if value < self._min:
                self._min = value
            if value > self._max:
                self._max = value
            for i, bound in enumerate(self.buckets):
                if value <= bound:
                    self._bucket_counts[i] += 1
                    return
            self._bucket_counts[-1] += 1

    @property
    def count(self) -> int:
        with self._lock:
            return self._count

    @property
    def avg(self) -> float:
        with self._lock:
            return self._sum / self._count if self._count > 0 else 0.0

    @property
    def min_val(self) -> float:
        with self._lock:
            return self._min if self._count > 0 else 0.0

    @property
    def max_val(self) -> float:
        with self._lock:
            return self._max

    def to_dict(self) -> dict[str, object]:
        with self._lock:
            result: dict[str, object] = {
                "count": self._count,
                "sum": round(self._sum, 2),
                "avg": round(self._sum / self._count, 2) if self._count > 0 else 0.0,
                "min": round(self._min, 2) if self._count > 0 else 0.0,
                "max": round(self._max, 2),
                "buckets": {},
            }
            for i, bound in enumerate(self.buckets):
                label = f"le_{int(bound)}"
                result["buckets"][label] = self._bucket_counts[i]
            result["buckets"]["le_inf"] = self._bucket_counts[-1]
            return result

    def reset(self) -> None:
        with self._lock:
            self._count = 0
            self._sum = 0.0
            self._min = float("inf")
            self._max = 0.0
            self._bucket_counts = [0] * (len(self.buckets) + 1)


@dataclass
class LabeledCounter:
    """Counter with a single label dimension (e.g., provider, status)."""

    _counters: dict[str, Counter] = field(default_factory=dict)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def inc(self, label: str, amount: int = 1) -> None:
        with self._lock:
            if label not in self._counters:
                self._counters[label] = Counter()
        self._counters[label].inc(amount)

    def to_dict(self) -> dict[str, int]:
        with self._lock:
            return {k: v.value for k, v in sorted(self._counters.items())}

    def reset(self) -> None:
        with self._lock:
            self._counters.clear()


class MetricsCollector:
    """Singleton metrics collector for NovelScribe.

    Collects:
    - LLM call counts by provider, model, status
    - LLM latency histogram (ms)
    - Phase duration histogram (seconds)
    - Pipeline count and total duration
    - Error counts by type
    """

    _instance: Optional["MetricsCollector"] = None
    _instance_lock: threading.Lock = threading.Lock()

    def __new__(cls) -> "MetricsCollector":
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    instance = super().__new__(cls)
                    instance._init_metrics()
                    cls._instance = instance
        return cls._instance

    def _init_metrics(self) -> None:
        self.llm_calls_by_provider = LabeledCounter()
        self.llm_calls_by_model = LabeledCounter()
        self.llm_calls_by_status = LabeledCounter()
        self.llm_latency_ms = Histogram(buckets=[50, 100, 250, 500, 1000, 2500, 5000, 10000, 30000])
        self.llm_tokens_in = Counter()
        self.llm_tokens_out = Counter()
        self.llm_tokens_total = Counter()

        self.phase_duration_seconds = Histogram(
            buckets=[1, 5, 10, 30, 60, 120, 300, 600, 1800, 3600]
        )
        self.phase_count = LabeledCounter()

        self.pipeline_count = Counter()
        self.pipeline_duration_seconds = Histogram(
            buckets=[10, 30, 60, 120, 300, 600, 1800, 3600, 7200]
        )
        self.pipeline_success = Counter()
        self.pipeline_failure = Counter()

        self.errors_by_type = LabeledCounter()
        self._last_trace_id: str = ""

    @classmethod
    def reset_instance(cls) -> None:
        with cls._instance_lock:
            cls._instance = None

    def record_llm_call(
        self,
        provider: str,
        model: str,
        status: str,
        latency_ms: float,
        input_tokens: int = 0,
        output_tokens: int = 0,
    ) -> None:
        self.llm_calls_by_provider.inc(provider)
        self.llm_calls_by_model.inc(model)
        self.llm_calls_by_status.inc(status)
        self.llm_latency_ms.observe(latency_ms)
        self.llm_tokens_in.inc(input_tokens)
        self.llm_tokens_out.inc(output_tokens)
        self.llm_tokens_total.inc(input_tokens + output_tokens)

    def record_phase(self, phase_name: str, duration_seconds: float) -> None:
        self.phase_count.inc(phase_name)
        self.phase_duration_seconds.observe(duration_seconds)

    def record_pipeline(self, duration_seconds: float, success: bool) -> None:
        self.pipeline_count.inc()
        self.pipeline_duration_seconds.observe(duration_seconds)
        if success:
            self.pipeline_success.inc()
        else:
            self.pipeline_failure.inc()

    def set_trace_id(self, trace_id: str) -> None:
        self._last_trace_id = trace_id

    @property
    def last_trace_id(self) -> str:
        return self._last_trace_id

    def record_error(self, error_type: str) -> None:
        self.errors_by_type.inc(error_type)

    def snapshot(self) -> dict[str, object]:
        return {
            "trace_id": self._last_trace_id,
            "llm": {
                "calls_by_provider": self.llm_calls_by_provider.to_dict(),
                "calls_by_model": self.llm_calls_by_model.to_dict(),
                "calls_by_status": self.llm_calls_by_status.to_dict(),
                "latency_ms": self.llm_latency_ms.to_dict(),
                "tokens_in": self.llm_tokens_in.value,
                "tokens_out": self.llm_tokens_out.value,
                "tokens_total": self.llm_tokens_total.value,
            },
            "phases": {
                "count_by_phase": self.phase_count.to_dict(),
                "duration_seconds": self.phase_duration_seconds.to_dict(),
            },
            "pipelines": {
                "total": self.pipeline_count.value,
                "success": self.pipeline_success.value,
                "failure": self.pipeline_failure.value,
                "duration_seconds": self.pipeline_duration_seconds.to_dict(),
            },
            "errors": {
                "by_type": self.errors_by_type.to_dict(),
            },
        }

    def reset(self) -> None:
        self._init_metrics()


class PhaseTimer:
    """Context manager that records phase duration in MetricsCollector."""

    def __init__(self, phase_name: str, collector: Optional[MetricsCollector] = None) -> None:
        self._phase_name = phase_name
        self._collector = collector or MetricsCollector()
        self._start: float = 0.0

    def __enter__(self) -> "PhaseTimer":
        self._start = time.perf_counter()
        return self

    def __exit__(self, *args: object) -> None:
        duration = time.perf_counter() - self._start
        self._collector.record_phase(self._phase_name, duration)


class PipelineTimer:
    """Context manager that records pipeline duration in MetricsCollector."""

    def __init__(self, collector: Optional[MetricsCollector] = None) -> None:
        self._collector = collector or MetricsCollector()
        self._start: float = 0.0

    def __enter__(self) -> "PipelineTimer":
        self._start = time.perf_counter()
        return self

    def __exit__(self, *args: object) -> None:
        duration = time.perf_counter() - self._start
        success = args[0] is None
        self._collector.record_pipeline(duration, success)
        if not success and args[0] is not None:
            error_type = args[0].__name__ if hasattr(args[0], "__name__") else str(args[0])
            self._collector.record_error(error_type)
