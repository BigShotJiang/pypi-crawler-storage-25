"""Shared utility functions for the core package."""

from __future__ import annotations

from pathlib import Path


def ensure_directories(*paths: Path) -> None:
    """Ensure all given directory paths exist.

    Creates each directory (and parents) if it does not already exist.

    Args:
        *paths: One or more Path objects pointing to directories to create.
    """
    for p in paths:
        Path(p).mkdir(parents=True, exist_ok=True)
