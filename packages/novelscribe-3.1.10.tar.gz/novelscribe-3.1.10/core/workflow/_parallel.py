"""Parallel step execution — DAG-based concurrent step execution.

Extracted from workflow_execution_helpers.py.

Interface:
    execute_parallel_steps(executor, parallel_steps, wf_name, proj, variables,
                          config, outputs, executed, failed,
                          dag_executor_fn=None) -> None
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass


def execute_parallel_steps(
    executor: Any,
    parallel_steps: list[Any],
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    config: dict[str, Any],
    outputs: dict[str, Any],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
    dag_executor_fn: Any = None,
) -> None:
    """Execute parallel/dependency steps concurrently.

    dag_executor_fn: injectable for testing. Defaults to
        ParallelStepExecutor(max_workers=max_concurrent).execute_dag(...).
    """
    if dag_executor_fn is None:
        from core.parallel import ParallelStepExecutor

        max_concurrent = 4
        for step in parallel_steps:
            if step.strategy and step.strategy.max_concurrent:
                max_concurrent = step.strategy.max_concurrent
                break
        dag_executor_fn = ParallelStepExecutor(max_workers=max_concurrent).execute_dag

    for result in dag_executor_fn(
        steps=parallel_steps,
        step_executor_fn=executor.step_executor.execute_step,
        project_name=proj,
        variables=variables,
        step_outputs=outputs,
        config=config,
    ):
        executed.append(result)
        if not result.get("success"):
            failed.append(result)
