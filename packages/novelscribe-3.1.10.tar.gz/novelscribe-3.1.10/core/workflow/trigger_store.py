"""Durable storage for trigger configs and invocation records.

This store uses an append-only journal plus periodic snapshots.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class TriggerStore:
    """Persist trigger state with journal replay and snapshot compaction."""

    def __init__(self, base_dir: str | Path, snapshot_interval: int = 20) -> None:
        self.base_dir = Path(base_dir)
        self.snapshot_interval = max(snapshot_interval, 1)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.journal_path = self.base_dir / "journal.jsonl"
        self.snapshot_path = self.base_dir / "snapshot.json"
        self._event_count = self._load_event_count()
        self._events_since_snapshot = 0

    def append_event(self, event_type: str, payload: dict[str, Any]) -> None:
        """Append event into the durable journal."""
        self._event_count += 1
        event = {
            "event_id": self._event_count,
            "event_type": event_type,
            "payload": payload,
        }
        with self.journal_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(event, ensure_ascii=True))
            fh.write("\n")
        self._events_since_snapshot += 1

    def load_state(self) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
        """Load state from snapshot then replay journal delta."""
        triggers: dict[str, dict[str, Any]] = {}
        invocations: dict[str, dict[str, Any]] = {}
        last_snapshot_event_id = 0

        if self.snapshot_path.exists():
            try:
                snap = json.loads(self.snapshot_path.read_text(encoding="utf-8"))
                last_snapshot_event_id = int(snap.get("last_event_id", 0))
                for item in snap.get("triggers", []):
                    if isinstance(item, dict) and isinstance(item.get("name"), str):
                        triggers[item["name"]] = item
                for item in snap.get("invocations", []):
                    if isinstance(item, dict) and isinstance(item.get("invocation_id"), str):
                        invocations[item["invocation_id"]] = item
            except Exception as exc:
                logger.warning("Failed to load trigger snapshot: %s", exc)

        if self.journal_path.exists():
            for line in self.journal_path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                    event_id = int(event.get("event_id", 0))
                    if event_id <= last_snapshot_event_id:
                        continue
                    self._apply_event(triggers, invocations, event)
                except Exception as exc:
                    logger.warning("Skipping invalid trigger journal event: %s", exc)
        return triggers, invocations

    def maybe_snapshot(
        self,
        triggers: dict[str, Any],
        invocations: dict[str, Any],
    ) -> None:
        """Persist compact snapshot every configured interval."""
        if self._events_since_snapshot < self.snapshot_interval:
            return
        data = {
            "last_event_id": self._event_count,
            "triggers": [self._to_jsonable(cfg) for cfg in triggers.values()],
            "invocations": [self._to_jsonable(res) for res in invocations.values()],
        }
        tmp = self.snapshot_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=True), encoding="utf-8")
        tmp.replace(self.snapshot_path)
        self._events_since_snapshot = 0

    @staticmethod
    def _apply_event(
        triggers: dict[str, dict[str, Any]],
        invocations: dict[str, dict[str, Any]],
        event: dict[str, Any],
    ) -> None:
        event_type = event.get("event_type")
        payload = event.get("payload", {})

        if event_type == "trigger_registered":
            config = payload.get("config")
            if isinstance(config, dict) and isinstance(config.get("name"), str):
                triggers[config["name"]] = config
        elif event_type == "trigger_unregistered":
            name = payload.get("name")
            if isinstance(name, str):
                triggers.pop(name, None)
        elif event_type == "invocation_recorded":
            result = payload.get("result")
            if isinstance(result, dict) and isinstance(result.get("invocation_id"), str):
                invocations[result["invocation_id"]] = result

    @staticmethod
    def _to_jsonable(item: Any) -> dict[str, Any]:
        if hasattr(item, "model_dump"):
            return item.model_dump(mode="json")
        if isinstance(item, dict):
            return item
        raise TypeError("Unsupported item type for trigger snapshot")

    def _load_event_count(self) -> int:
        if not self.journal_path.exists():
            return 0
        count = 0
        for line in self.journal_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                count += 1
        return count
