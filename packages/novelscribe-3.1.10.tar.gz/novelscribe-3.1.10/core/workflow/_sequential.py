"""Sequential step execution — no-dependency steps run in order.

Extracted from workflow_execution_helpers.py.

Interface:
    execute_sequential_steps(executor, steps, wf_name, proj, variables,
                             config, hooks, outputs, executed, failed, reports) -> None
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass


def execute_sequential_steps(
    executor: Any,
    steps: list[Any],
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    config: dict[str, Any],
    hooks: list[Any],
    outputs: dict[str, Any],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
    reports: list[dict[str, Any]],
) -> None:
    """Execute all steps in sequential order (no dependencies)."""
    for step in steps:
        _execute_one(
            step,
            executor,
            wf_name,
            proj,
            variables,
            config,
            hooks,
            outputs,
            executed,
            failed,
            reports,
        )


def _execute_one(
    step: Any,
    executor: Any,
    wf_name: str,
    proj: str,
    variables: dict[str, Any],
    config: dict[str, Any],
    hooks: list[Any],
    outputs: dict[str, Any],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
    reports: list[dict[str, Any]],
) -> None:
    """Execute a single step via lifecycle."""
    from core.workflow._step_lifecycle import run_step_lifecycle

    run_step_lifecycle(
        step=step,
        project_name=proj,
        context_bus=executor.context_bus,
        step_executor_fn=executor.step_executor.execute_step,
        step_outputs=outputs,
        wf_name=wf_name,
        variables=variables,
        config=config,
        hooks=hooks,
        reports=reports,
        executed=executed,
        failed=failed,
        logger=executor.logger,
        emit_fn=executor._emit_hook_event,
    )
