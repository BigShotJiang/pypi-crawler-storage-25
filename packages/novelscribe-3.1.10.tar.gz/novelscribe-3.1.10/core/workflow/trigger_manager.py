"""Trigger manager for event-driven pipeline invocation."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import queue
import random
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Optional

from pydantic import BaseModel, Field

from .trigger_store import TriggerStore

logger = logging.getLogger(__name__)


class TriggerConfig(BaseModel):
    """Configuration for a pipeline trigger."""

    name: str
    type: str = Field(pattern="^(webhook|cron|manual)$")
    workflow: str
    config: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True


class TriggerResult(BaseModel):
    """Result of a trigger invocation."""

    trigger_name: str
    invocation_id: str
    accepted: bool
    status: str = Field(default="accepted")
    attempts: int = 0
    max_attempts: int = 1
    reason: str | None = None


class TriggerManager:
    """Manage external triggers that invoke workflow execution.

    Supports webhook, cron, and manual trigger types.
    Triggered workflows are executed asynchronously via a provided callback.
    """

    def __init__(
        self,
        workflow_executor_fn: Optional[Callable[[str, dict[str, Any]], Any]] = None,
        store: TriggerStore | None = None,
    ) -> None:
        self._triggers: dict[str, TriggerConfig] = {}
        self._workflow_executor_fn = workflow_executor_fn
        self._invocations: dict[str, TriggerResult] = {}
        self._lock = threading.Lock()
        self._dispatch_queue: queue.Queue[dict[str, Any]] = queue.Queue()
        self._store = store
        self._shutdown = False
        if self._store is not None:
            self._load_persisted_state()
        self._dispatch_worker = threading.Thread(
            target=self._dispatch_worker_loop,
            daemon=True,
            name="trigger-dispatch-worker",
        )
        self._dispatch_worker.start()

    @classmethod
    def with_default_store(
        cls,
        workflow_executor_fn: Optional[Callable[[str, dict[str, Any]], Any]] = None,
        base_dir: str | Path = ".triggers",
    ) -> "TriggerManager":
        """Construct manager with local trigger persistence enabled."""
        return cls(workflow_executor_fn=workflow_executor_fn, store=TriggerStore(base_dir))

    def register_trigger(self, config: TriggerConfig) -> None:
        """Register a trigger configuration."""
        with self._lock:
            self._triggers[config.name] = config
        self._persist_event("trigger_registered", {"config": config.model_dump(mode="json")})
        logger.info(
            "Registered trigger: %s (type=%s, workflow=%s)",
            config.name,
            config.type,
            config.workflow,
        )

    def unregister_trigger(self, name: str) -> bool:
        """Unregister a trigger by name. Returns True if found."""
        with self._lock:
            removed = self._triggers.pop(name, None) is not None
        if removed:
            self._persist_event("trigger_unregistered", {"name": name})
        return removed

    def shutdown(self) -> None:
        """Stop the dispatch worker thread gracefully."""
        self._shutdown = True
        self._dispatch_queue.put_nowait({})

    def list_triggers(self) -> list[TriggerConfig]:
        """List all registered triggers."""
        with self._lock:
            return list(self._triggers.values())

    def get_trigger(self, name: str) -> Optional[TriggerConfig]:
        """Get a trigger by name."""
        with self._lock:
            return self._triggers.get(name)

    def get_invocation(self, invocation_id: str) -> Optional[TriggerResult]:
        """Get invocation record by id."""
        with self._lock:
            return self._invocations.get(invocation_id)

    def process_webhook(
        self,
        trigger_name: str,
        payload: dict[str, Any],
        signature: str | None = None,
        raw_body: bytes | None = None,
    ) -> TriggerResult:
        """Process a webhook trigger invocation.

        Args:
            trigger_name: Name of the registered trigger.
            payload: Webhook payload data.

        Returns:
            TriggerResult indicating acceptance.
        """
        config = self.get_trigger(trigger_name)

        if config is None:
            return TriggerResult(
                trigger_name=trigger_name,
                invocation_id="",
                accepted=False,
                reason=f"Unknown trigger: {trigger_name}",
            )

        if not config.enabled:
            return TriggerResult(
                trigger_name=trigger_name,
                invocation_id="",
                accepted=False,
                reason=f"Trigger disabled: {trigger_name}",
            )

        if config.type != "webhook":
            return TriggerResult(
                trigger_name=trigger_name,
                invocation_id="",
                accepted=False,
                reason=f"Trigger {trigger_name} is not a webhook trigger (type={config.type})",
            )

        auth_ok, auth_reason = self._verify_webhook_auth(config, payload, signature, raw_body)
        if not auth_ok:
            return TriggerResult(
                trigger_name=trigger_name,
                invocation_id="",
                accepted=False,
                reason=auth_reason or "Invalid webhook authentication",
            )

        invocation_id = str(uuid.uuid4())
        max_attempts, backoff_ms, jitter = self._get_dispatch_policy(config)
        merged_variables = {**config.config.get("variables", {}), **payload}
        merged_variables.pop("secret", None)
        result = TriggerResult(
            trigger_name=trigger_name,
            invocation_id=invocation_id,
            accepted=True,
            status="accepted",
            attempts=0,
            max_attempts=max_attempts,
        )
        with self._lock:
            self._invocations[invocation_id] = result
        self._persist_event("invocation_recorded", {"result": result.model_dump(mode="json")})
        self._dispatch_queue.put(
            {
                "invocation_id": invocation_id,
                "trigger_name": trigger_name,
                "workflow": config.workflow,
                "variables": merged_variables,
                "max_attempts": max_attempts,
                "backoff_ms": backoff_ms,
                "jitter": jitter,
            }
        )
        return result

    def _dispatch_worker_loop(self) -> None:
        """Run invocation jobs in background and update status with retry semantics."""
        while True:
            job = self._dispatch_queue.get()
            if self._shutdown:
                return
            try:
                self._execute_invocation_job(job)
            finally:
                self._dispatch_queue.task_done()

    def _execute_invocation_job(self, job: dict[str, Any]) -> None:
        invocation_id = str(job["invocation_id"])
        trigger_name = str(job["trigger_name"])
        workflow = str(job["workflow"])
        variables = dict(job["variables"])
        max_attempts = int(job["max_attempts"])
        backoff_ms = int(job["backoff_ms"])
        jitter = bool(job["jitter"])

        if self._workflow_executor_fn is None:
            self._set_invocation_state(
                invocation_id,
                status="succeeded",
                attempts=1,
                reason=None,
            )
            return

        for attempt in range(1, max_attempts + 1):
            self._set_invocation_state(
                invocation_id,
                status="running" if attempt == 1 else "retrying",
                attempts=attempt,
                reason=None,
            )
            try:
                self._workflow_executor_fn(workflow, variables)
                self._set_invocation_state(
                    invocation_id,
                    status="succeeded",
                    attempts=attempt,
                    reason=None,
                )
                return
            except Exception as exc:
                logger.error(
                    "Trigger %s invocation %s attempt %s failed: %s",
                    trigger_name,
                    invocation_id,
                    attempt,
                    exc,
                )
                if attempt >= max_attempts:
                    self._set_invocation_state(
                        invocation_id,
                        status="failed_permanent",
                        attempts=attempt,
                        reason=f"Execution error: {exc}",
                    )
                    return

                delay = self._compute_retry_delay(backoff_ms, attempt, jitter=jitter)
                self._set_invocation_state(
                    invocation_id,
                    status="retrying",
                    attempts=attempt,
                    reason=f"Retry scheduled after error: {exc}",
                )
                if delay > 0:
                    time.sleep(delay)

    def _verify_webhook_auth(
        self,
        config: TriggerConfig,
        payload: dict[str, Any],
        signature: str | None,
        raw_body: bytes | None,
    ) -> tuple[bool, str | None]:
        """Verify webhook auth using signature-first with legacy fallback."""
        signature_secret = config.config.get("signature_secret")
        if isinstance(signature_secret, str) and signature_secret:
            body = raw_body if raw_body is not None else self._serialize_payload(payload)
            expected = hmac.new(
                signature_secret.encode("utf-8"),
                body,
                hashlib.sha256,
            ).hexdigest()
            provided = (signature or "").strip()
            if provided.startswith("sha256="):
                provided = provided.split("=", 1)[1]

            if provided and hmac.compare_digest(expected, provided):
                return True, None

            # Temporary backward-compatible fallback during migration.
            legacy_secret = config.config.get("secret")
            if (
                isinstance(legacy_secret, str)
                and legacy_secret
                and payload.get("secret") == legacy_secret
            ):
                logger.warning(
                    "Legacy payload secret accepted for trigger %s; migrate to signature auth.",
                    config.name,
                )
                return True, None
            return False, "Invalid webhook signature"

        legacy_secret = config.config.get("secret")
        if (
            isinstance(legacy_secret, str)
            and legacy_secret
            and payload.get("secret") != legacy_secret
        ):
            return False, "Invalid webhook secret"
        return True, None

    @staticmethod
    def _serialize_payload(payload: dict[str, Any]) -> bytes:
        """Stable serialization fallback for signature verification."""
        return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def _set_invocation_state(
        self,
        invocation_id: str,
        *,
        status: str,
        attempts: int,
        reason: str | None,
    ) -> None:
        with self._lock:
            current = self._invocations.get(invocation_id)
            if current is None:
                return
            updated = current.model_copy(
                update={"status": status, "attempts": attempts, "reason": reason}
            )
            self._invocations[invocation_id] = updated
        self._persist_event("invocation_recorded", {"result": updated.model_dump(mode="json")})

    @staticmethod
    def _compute_retry_delay(backoff_ms: int, attempt: int, *, jitter: bool) -> float:
        delay = min((max(backoff_ms, 0) / 1000.0) * (2 ** max(attempt - 1, 0)), 30.0)
        if jitter and delay > 0:
            delay += random.uniform(0, delay * 0.5)
        return delay

    @staticmethod
    def _get_dispatch_policy(config: TriggerConfig) -> tuple[int, int, bool]:
        raw_max = config.config.get("dispatch_retry_max_attempts", 3)
        raw_backoff = config.config.get("dispatch_backoff_ms", 200)
        raw_jitter = config.config.get("dispatch_jitter", True)
        try:
            max_attempts = max(1, min(int(raw_max), 10))
        except (TypeError, ValueError):
            max_attempts = 3
        try:
            backoff_ms = max(0, int(raw_backoff))
        except (TypeError, ValueError):
            backoff_ms = 200
        jitter = bool(raw_jitter)
        return max_attempts, backoff_ms, jitter

    def _load_persisted_state(self) -> None:
        """Load persisted trigger and invocation state from store."""
        if self._store is None:
            return
        persisted_triggers, persisted_invocations = self._store.load_state()
        triggers: dict[str, TriggerConfig] = {}
        invocations: dict[str, TriggerResult] = {}
        for data in persisted_triggers.values():
            try:
                cfg = TriggerConfig.model_validate(data)
                triggers[cfg.name] = cfg
            except Exception as exc:
                logger.warning("Skipping invalid persisted trigger config: %s", exc)

        for data in persisted_invocations.values():
            try:
                result = TriggerResult.model_validate(data)
                if result.invocation_id:
                    invocations[result.invocation_id] = result
            except Exception as exc:
                logger.warning("Skipping invalid persisted invocation record: %s", exc)
        with self._lock:
            self._triggers = triggers
            self._invocations = invocations

    def _persist_event(self, event_type: str, payload: dict[str, Any]) -> None:
        """Persist an event and compact snapshot periodically."""
        if self._store is None:
            return
        self._store.append_event(event_type, payload)
        self._store.maybe_snapshot(self._triggers, self._invocations)
