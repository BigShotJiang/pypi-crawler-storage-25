"""Enhanced variable resolver with dot notation support."""

import ast
import operator
import re
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from .secrets import SecretStore

_SAFE_OPS: Dict[type, Any] = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.And: lambda a, b: a and b,
    ast.Or: lambda a, b: a or b,
    ast.Not: operator.not_,
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.USub: operator.neg,
}


def _safe_eval(expr: str) -> Any:
    """Evaluate a restricted expression using the AST module.

    Supports: comparisons (==, !=, <, <=, >, >=),
    boolean logic (and, or, not), and arithmetic (+, -, *).

    Args:
        expr: Expression string to evaluate.

    Returns:
        Result of evaluation.

    Raises:
        ValueError: If expression contains disallowed AST nodes.
    """
    tree = ast.parse(expr, mode="eval")

    def _eval_node(node: ast.AST) -> Any:
        if isinstance(node, ast.Expression):
            return _eval_node(node.body)
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            raise ValueError(f"Unsafe expression: unresolved name '{node.id}'")
        if isinstance(node, ast.UnaryOp):
            op_func = _SAFE_OPS.get(type(node.op))
            if op_func is None:
                raise ValueError(f"Unsafe operator: {type(node.op).__name__}")
            return op_func(_eval_node(node.operand))
        if isinstance(node, ast.BinOp):
            op_func = _SAFE_OPS.get(type(node.op))
            if op_func is None:
                raise ValueError(f"Unsafe operator: {type(node.op).__name__}")
            return op_func(_eval_node(node.left), _eval_node(node.right))
        if isinstance(node, ast.BoolOp):
            op_func = _SAFE_OPS.get(type(node.op))
            if op_func is None:
                raise ValueError(f"Unsafe operator: {type(node.op).__name__}")
            result = _eval_node(node.values[0])
            for val_node in node.values[1:]:
                result = op_func(result, _eval_node(val_node))
            return result
        if isinstance(node, ast.Compare):
            left = _eval_node(node.left)
            for op, comparator in zip(node.ops, node.comparators):
                op_func = _SAFE_OPS.get(type(op))
                if op_func is None:
                    raise ValueError(f"Unsafe operator: {type(op).__name__}")
                right = _eval_node(comparator)
                if not op_func(left, right):
                    return False
                left = right
            return True
        raise ValueError(f"Disallowed AST node: {type(node).__name__}")

    return _eval_node(tree)


class VariableResolver:
    """Resolve variables with ${variable} syntax and dot notation.

    Public methods accept explicit ``variables`` and ``step_outputs``
    parameters and never mutate instance state.  The instance-level
    ``self.variables`` / ``self.step_outputs`` are kept as backward-
    compatible defaults when callers omit the parameters.
    """

    VARIABLE_PATTERN = re.compile(r"\$\{([^}]+)\}")

    def __init__(self, secret_store: Optional["SecretStore"] = None) -> None:
        """Initialize variable resolver.

        Args:
            secret_store: Optional secret store for resolving
                ``${secrets.<name>}`` references.
        """
        self.variables: Dict[str, Any] = {}
        self.step_outputs: Dict[str, Any] = {}
        self._secret_store = secret_store

    def resolve(
        self,
        template: str | Any,
        variables: Optional[Dict[str, Any]] = None,
        step_outputs: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Resolve variables in template string.

        Args:
            template: Template string or value
            variables: Workflow variables
            step_outputs: Outputs from previous steps

        Returns:
            Resolved value
        """
        eff_vars = variables if variables is not None else self.variables
        eff_outputs = step_outputs if step_outputs is not None else self.step_outputs

        if not isinstance(template, str):
            return template

        def replace_var(match: re.Match) -> str:
            var_path = match.group(1)
            value = self._get_variable_value(var_path, eff_vars, eff_outputs, self._secret_store)

            if value is None:
                return str(match.group(0))

            return str(value)

        result = self.VARIABLE_PATTERN.sub(replace_var, template)

        return result

    def resolve_dict(
        self,
        data: Dict[str, Any],
        variables: Optional[Dict[str, Any]] = None,
        step_outputs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Resolve variables in dictionary.

        Args:
            data: Dictionary with variables
            variables: Workflow variables
            step_outputs: Outputs from previous steps

        Returns:
            Dictionary with resolved variables
        """
        resolved = {}

        for key, value in data.items():
            if isinstance(value, str):
                resolved[key] = self.resolve(value, variables, step_outputs)
            elif isinstance(value, dict):
                resolved[key] = self.resolve_dict(value, variables, step_outputs)
            elif isinstance(value, list):
                resolved[key] = self.resolve_list(value, variables, step_outputs)
            else:
                resolved[key] = value

        return resolved

    def resolve_list(
        self,
        data: List[Any],
        variables: Optional[Dict[str, Any]] = None,
        step_outputs: Optional[Dict[str, Any]] = None,
    ) -> List[Any]:
        """Resolve variables in list.

        Args:
            data: List with variables
            variables: Workflow variables
            step_outputs: Outputs from previous steps

        Returns:
            List with resolved variables
        """
        resolved = []

        for item in data:
            if isinstance(item, str):
                resolved.append(self.resolve(item, variables, step_outputs))
            elif isinstance(item, dict):
                resolved.append(self.resolve_dict(item, variables, step_outputs))
            elif isinstance(item, list):
                resolved.append(self.resolve_list(item, variables, step_outputs))
            else:
                resolved.append(item)

        return resolved

    @staticmethod
    def _get_variable_value(
        var_path: str,
        variables: Optional[Dict[str, Any]] = None,
        step_outputs: Optional[Dict[str, Any]] = None,
        secret_store: Optional["SecretStore"] = None,
    ) -> Optional[Any]:
        """Get variable value by path (supports dot notation).

        Searches in order: secrets, variables, step_outputs top-level,
        then nested within step output dicts (flattened access).

        Args:
            var_path: Variable path (e.g., "project.meta.genre")
            variables: Workflow variables dict
            step_outputs: Step outputs dict
            secret_store: Optional secret store for secrets.* paths

        Returns:
            Variable value or None
        """
        if var_path.startswith("secrets.") and secret_store is not None:
            return secret_store.resolve_variable(var_path)

        parts = var_path.split(".")
        _vars = variables or {}
        _outputs = step_outputs or {}

        value = None

        if parts[0] in _vars:
            value = _vars[parts[0]]
        elif parts[0] in _outputs:
            value = _outputs[parts[0]]
        else:
            for step_data in _outputs.values():
                if isinstance(step_data, dict) and parts[0] in step_data:
                    value = step_data[parts[0]]
                    break
            else:
                return None

        for part in parts[1:]:
            if isinstance(value, dict):
                value = value.get(part)
            else:
                return None

        return value

    def evaluate_condition(
        self,
        condition: str,
        variables: Optional[Dict[str, Any]] = None,
        step_outputs: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Evaluate conditional expression.

        Args:
            condition: Condition expression
            variables: Workflow variables
            step_outputs: Outputs from previous steps

        Returns:
            True if condition is true, False otherwise
        """
        if not condition:
            return True

        eff_vars = variables if variables is not None else self.variables
        eff_outputs = step_outputs if step_outputs is not None else self.step_outputs

        def replace_var(match):
            var_path = match.group(1)
            value = self._get_variable_value(var_path, eff_vars, eff_outputs, self._secret_store)
            if value is None:
                return match.group(0)
            if isinstance(value, str):
                return repr(value)
            return str(value)

        resolved = self.VARIABLE_PATTERN.sub(replace_var, condition)

        try:
            return bool(_safe_eval(resolved))
        except Exception:
            return False

    def clear(self) -> None:
        """Clear all variables."""
        self.variables.clear()
        self.step_outputs.clear()

    def set_variable(self, name: str, value: Any) -> None:
        """Set a variable value.

        Args:
            name: Variable name
            value: Variable value
        """
        self.variables[name] = value

    def set_step_output(self, step_name: str, output: Any) -> None:
        """Set step output.

        Args:
            step_name: Step name
            output: Step output
        """
        self.step_outputs[step_name] = output

    def get_variable(self, name: str, default: Any = None) -> Any:
        """Get variable value.

        Args:
            name: Variable name
            default: Default value if not found

        Returns:
            Variable value or default
        """
        return self.variables.get(name, default)

    def get_step_output(self, step_name: str, default: Any = None) -> Any:
        """Get step output.

        Args:
            step_name: Step name
            default: Default value if not found

        Returns:
            Step output or default
        """
        return self.step_outputs.get(step_name, default)
