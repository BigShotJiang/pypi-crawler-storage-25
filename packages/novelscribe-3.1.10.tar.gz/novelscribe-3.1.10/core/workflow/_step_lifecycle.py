"""Step lifecycle — pre/post hook dispatch, execution, context ingestion.

Extracted from workflow_execution_helpers.py. This is the unit of workflow
execution: before-hook → step → after-hook → context ingestion.

Interface:
    run_step_lifecycle(
        step, project_name, context_bus,
        step_executor_fn, step_outputs,
        wf_name, variables, config, hooks, reports, executed, failed,
        logger, emit_fn
    ) → None
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from core.hooks import HookEvent

if TYPE_CHECKING:
    from collections.abc import Callable


def run_step_lifecycle(
    step: Any,
    project_name: str,
    context_bus: Any,
    step_executor_fn: "Callable[..., Any]",
    step_outputs: dict[str, Any],
    wf_name: str,
    variables: dict[str, Any],
    config: dict[str, Any],
    hooks: list[Any],
    reports: list[dict[str, Any]],
    executed: list[dict[str, Any]],
    failed: list[dict[str, Any]],
    logger: Any,
    emit_fn: Any,
) -> None:
    """Execute one workflow step with full lifecycle: hooks + execution + context ingestion."""
    logger.info("Executing step %s: %s", step.step, step.name)
    merged_hooks = list(hooks)
    if step.hooks:
        merged_hooks.extend(step.hooks)
    emit_fn(
        HookEvent.WORKFLOW_BEFORE_STEP.value,
        merged_hooks,
        reports,
        {
            "workflow": wf_name,
            "project_name": project_name,
            "step": step.step,
            "step_name": step.name,
            "context_status": "pending",
        },
    )
    result = step_executor_fn(
        step=step,
        project_name=project_name,
        variables=variables,
        step_outputs=step_outputs,
        config=config,
    )
    executed.append(result)
    if result.get("skipped"):
        return
    if not result.get("success"):
        failed.append(result)
        logger.error("Step failed: %s", step.name)
        emit_fn(
            HookEvent.WORKFLOW_STEP_FAILED.value,
            merged_hooks,
            reports,
            {
                "workflow": wf_name,
                "project_name": project_name,
                "step": step.step,
                "step_name": step.name,
                "context_status": "failure",
                "result": result,
            },
        )
        return
    step_outputs[step.name] = result.get("output", {})
    emit_fn(
        HookEvent.WORKFLOW_AFTER_STEP.value,
        merged_hooks,
        reports,
        {
            "workflow": wf_name,
            "project_name": project_name,
            "step": step.step,
            "step_name": step.name,
            "context_status": "success",
            "result": result,
        },
    )
    _ingest_context(context_bus, step, result, project_name, variables)


def _ingest_context(
    context_bus: Any,
    step: Any,
    result: dict[str, Any],
    project_name: str,
    variables: dict[str, Any],
) -> None:
    """Ingest step output into context bus if context_type is set."""
    if context_bus is None or not step.context_type:
        return
    out = result.get("output", {})
    content = (
        out
        if isinstance(out, str)
        else "\n".join(str(v) for v in out.values())
        if isinstance(out, dict)
        else str(out)
    )
    if content:
        context_bus.ingest(
            artifact_type=step.context_type,
            content=content,
            source_agent=step.agent or step.name,
            chapter_number=variables.get("chapter_number"),
        )
