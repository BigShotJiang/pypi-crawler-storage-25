import csv
import json
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

from .types import (
    ExecutionProfile,
    ExecutionStatus,
    PerformanceReport,
    ProfileType,
)

Clock = Callable[[], float]


class PerformanceProfiler:
    def __init__(self, clock: Optional[Clock] = None):
        self.profiles: Dict[str, ExecutionProfile] = {}
        self.active_profiles: Dict[str, str] = {}
        self.profile_stack: List[str] = []
        self._clock = clock
        self.start_time: float = self._now()

    def _now(self) -> float:
        import time

        if self._clock is not None:
            return self._clock()
        return time.time()

    def start_profile(
        self, name: str, profile_type: ProfileType, metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        profile_id = str(uuid4())
        profile = ExecutionProfile(
            profile_id=profile_id,
            name=name,
            profile_type=profile_type,
            start_time=self._now(),
            metadata=metadata or {},
            status=ExecutionStatus.RUNNING,
        )

        if self.profile_stack:
            parent_id = self.profile_stack[-1]
            profile.parent_id = parent_id
            parent_profile = self.profiles.get(parent_id)
            if parent_profile:
                parent_profile.sub_profiles.append(profile_id)

        self.profiles[profile_id] = profile
        self.active_profiles[name] = profile_id
        self.profile_stack.append(profile_id)

        return profile_id

    def end_profile(
        self,
        profile_id: str,
        error: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ExecutionProfile:
        profile = self.profiles.get(profile_id)
        if not profile:
            raise ValueError(f"Profile {profile_id} not found")

        if metadata:
            profile.metadata.update(metadata)

        now = self._now()
        if error:
            profile.fail(error, now=now)
        else:
            profile.complete(now=now)

        if profile.name in self.active_profiles:
            del self.active_profiles[profile.name]

        if self.profile_stack and self.profile_stack[-1] == profile_id:
            self.profile_stack.pop()

        return profile

    def get_profile(self, profile_id: str) -> Optional[ExecutionProfile]:
        return self.profiles.get(profile_id)

    def get_profiles_by_type(self, profile_type: ProfileType) -> List[ExecutionProfile]:
        return [p for p in self.profiles.values() if p.profile_type == profile_type]

    def get_profiles_by_name(self, name: str) -> List[ExecutionProfile]:
        return [p for p in self.profiles.values() if p.name == name]

    def identify_bottlenecks(
        self, threshold: float = 5.0, profile_type: Optional[ProfileType] = None
    ) -> List[str]:
        bottlenecks: list[str] = []

        profiles = self.profiles.values()
        if profile_type:
            profiles = [p for p in profiles if p.profile_type == profile_type]

        for profile in profiles:
            if profile.duration and profile.duration >= threshold:
                bottleneck = f"{profile.name}: {profile.duration:.2f}s"
                if profile.parent_id:
                    parent = self.profiles.get(profile.parent_id)
                    if parent and parent.duration:
                        percentage = profile.duration / parent.duration * 100
                        bottleneck += f" ({percentage:.1f}% of {parent.name})"
                bottlenecks.append(bottleneck)

        bottlenecks.sort(key=lambda x: float(x.split(": ")[1].split("s")[0]), reverse=True)

        return bottlenecks

    def get_report(self) -> PerformanceReport:
        total_duration = self._now() - self.start_time

        agent_profiles = self.get_profiles_by_type(ProfileType.AGENT)
        workflow_profiles = self.get_profiles_by_type(ProfileType.WORKFLOW)
        llm_profiles = self.get_profiles_by_type(ProfileType.LLM_CALL)
        file_io_profiles = self.get_profiles_by_type(ProfileType.FILE_IO)

        bottlenecks = self.identify_bottlenecks()
        summary = self._calculate_summary()

        return PerformanceReport(
            total_duration=total_duration,
            agent_profiles=agent_profiles,
            workflow_profiles=workflow_profiles,
            llm_profiles=llm_profiles,
            file_io_profiles=file_io_profiles,
            bottlenecks=bottlenecks,
            summary=summary,
        )

    def _calculate_summary(self) -> Dict[str, Any]:
        def stats_for_profiles(profiles: List[ExecutionProfile]) -> Dict[str, Any]:
            completed = [p for p in profiles if p.duration is not None]
            if not completed:
                return {"count": len(profiles), "avg_duration": 0, "max_duration": 0}

            durations = [p.duration for p in completed]
            return {
                "count": len(completed),
                "avg_duration": sum(durations) / len(durations),
                "max_duration": max(durations),
                "min_duration": min(durations),
                "total_duration": sum(durations),
                "failed": len([p for p in profiles if p.status == ExecutionStatus.FAILED]),
            }

        return {
            "agents": stats_for_profiles(self.get_profiles_by_type(ProfileType.AGENT)),
            "workflows": stats_for_profiles(self.get_profiles_by_type(ProfileType.WORKFLOW)),
            "llm_calls": stats_for_profiles(self.get_profiles_by_type(ProfileType.LLM_CALL)),
            "file_io": stats_for_profiles(self.get_profiles_by_type(ProfileType.FILE_IO)),
            "total_profiles": len(self.profiles),
            "active_profiles": len(self.active_profiles),
        }

    def export_data(
        self, output_path: str, format: str = "json", profile_type: Optional[ProfileType] = None
    ) -> str:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if format == "json":
            return self._export_json(output_path, profile_type)
        elif format == "csv":
            return self._export_csv(output_path, profile_type)
        else:
            raise ValueError(f"Unsupported export format: {format}")

    def _export_json(self, output_path: Path, profile_type: Optional[ProfileType]) -> str:
        report = self.get_report()
        data = report.to_dict()

        if profile_type:
            data["profiles"] = [p.to_dict() for p in self.get_profiles_by_type(profile_type)]

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

        return str(output_path.absolute())

    def _export_csv(self, output_path: Path, profile_type: Optional[ProfileType]) -> str:
        profiles = list(self.profiles.values())
        if profile_type:
            profiles = self.get_profiles_by_type(profile_type)

        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(
                [
                    "Profile ID",
                    "Name",
                    "Type",
                    "Start Time",
                    "End Time",
                    "Duration",
                    "Status",
                    "Parent ID",
                    "Error",
                ]
            )

            for profile in profiles:
                writer.writerow(
                    [
                        profile.profile_id,
                        profile.name,
                        profile.profile_type.value,
                        profile.start_time,
                        profile.end_time,
                        profile.duration or "",
                        profile.status.value,
                        profile.parent_id or "",
                        profile.error or "",
                    ]
                )

        return str(output_path.absolute())

    def clear(self) -> None:
        self.profiles.clear()
        self.active_profiles.clear()
        self.profile_stack.clear()
        self.start_time = self._now()

    def get_active_profiles(self) -> List[ExecutionProfile]:
        return [self.profiles[pid] for pid in self.profile_stack if pid in self.profiles]
