from typing import Any, Dict, Optional

from .core import PerformanceProfiler
from .types import (
    ExecutionProfile,
    ExecutionStatus,
    PerformanceReport,
    ProfileType,
)


class ProfilingContext:
    def __init__(
        self,
        profiler: PerformanceProfiler,
        name: str,
        profile_type: ProfileType,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.profiler = profiler
        self.name = name
        self.profile_type = profile_type
        self.metadata = metadata
        self.profile_id: Optional[str] = None

    def __enter__(self) -> "ProfilingContext":
        self.profile_id = self.profiler.start_profile(self.name, self.profile_type, self.metadata)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self.profile_id:
            error = str(exc_val) if exc_val else None
            self.profiler.end_profile(self.profile_id, error=error)


_global_profiler: Optional[PerformanceProfiler] = None


def get_profiler() -> PerformanceProfiler:
    global _global_profiler
    if _global_profiler is None:
        _global_profiler = PerformanceProfiler()
    return _global_profiler


def profile_function(
    profiler: Optional[PerformanceProfiler] = None,
    name: Optional[str] = None,
    profile_type: ProfileType = ProfileType.CUSTOM,
):
    def decorator(func):
        def wrapper(*args, **kwargs):
            nonlocal profiler
            if profiler is None:
                profiler = get_profiler()

            profile_name = name or func.__name__
            profile_id = profiler.start_profile(profile_name, profile_type)

            try:
                result = func(*args, **kwargs)
                profiler.end_profile(profile_id)
                return result
            except Exception as e:
                profiler.end_profile(profile_id, error=str(e))
                raise

        return wrapper

    return decorator


__all__ = [
    "ExecutionProfile",
    "ExecutionStatus",
    "PerformanceReport",
    "PerformanceProfiler",
    "ProfileType",
    "ProfilingContext",
    "get_profiler",
    "profile_function",
]
