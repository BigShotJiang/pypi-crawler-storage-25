import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class ProfileType(Enum):
    AGENT = "agent"
    WORKFLOW = "workflow"
    LLM_CALL = "llm_call"
    FILE_IO = "file_io"
    CUSTOM = "custom"


class ExecutionStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class ExecutionProfile:
    profile_id: str
    name: str
    profile_type: ProfileType
    start_time: float
    end_time: Optional[float] = None
    duration: Optional[float] = None
    status: ExecutionStatus = ExecutionStatus.PENDING
    metadata: Dict[str, Any] = field(default_factory=dict)
    sub_profiles: List[str] = field(default_factory=list)
    parent_id: Optional[str] = None
    error: Optional[str] = None

    def complete(self, end_time: Optional[float] = None, now: Optional[float] = None) -> None:
        resolved = end_time if end_time is not None else (now if now is not None else time.time())
        self.end_time = resolved
        self.duration = self.end_time - self.start_time
        self.status = ExecutionStatus.COMPLETED

    def fail(
        self, error: str, end_time: Optional[float] = None, now: Optional[float] = None
    ) -> None:
        resolved = end_time if end_time is not None else (now if now is not None else time.time())
        self.end_time = resolved
        self.duration = self.end_time - self.start_time
        self.status = ExecutionStatus.FAILED
        self.error = error

    def to_dict(self) -> Dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "name": self.name,
            "type": self.profile_type.value,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration": self.duration,
            "status": self.status.value,
            "metadata": self.metadata,
            "sub_profiles": self.sub_profiles,
            "parent_id": self.parent_id,
            "error": self.error,
        }


@dataclass
class PerformanceReport:
    total_duration: float
    agent_profiles: List[ExecutionProfile]
    workflow_profiles: List[ExecutionProfile]
    llm_profiles: List[ExecutionProfile]
    file_io_profiles: List[ExecutionProfile]
    bottlenecks: List[str]
    summary: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_duration": self.total_duration,
            "agent_count": len(self.agent_profiles),
            "workflow_count": len(self.workflow_profiles),
            "llm_call_count": len(self.llm_profiles),
            "file_io_count": len(self.file_io_profiles),
            "bottlenecks": self.bottlenecks,
            "summary": self.summary,
            "agents": [p.to_dict() for p in self.agent_profiles],
            "workflows": [p.to_dict() for p in self.workflow_profiles],
            "llm_calls": [p.to_dict() for p in self.llm_profiles],
            "file_io": [p.to_dict() for p in self.file_io_profiles],
        }
