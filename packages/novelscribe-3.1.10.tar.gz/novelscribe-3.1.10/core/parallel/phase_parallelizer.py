"""
Phase Parallelizer for Parallel Agent Execution

This module identifies and executes parallelizable phases in the novel generation pipeline.
"""

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set


@dataclass
class PhaseDependency:
    """Represents a phase and its dependencies"""

    phase_name: str
    agent_name: str
    prompt_template: str
    depends_on: List[str] = field(default_factory=list)
    parallel_group: int = 0  # Phases with same group can run in parallel
    priority: int = 0
    is_optional: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PhaseGroup:
    """Group of phases that can execute in parallel"""

    group_id: int
    phases: List[PhaseDependency]
    depends_on_groups: Set[int] = field(default_factory=set)

    @property
    def can_parallel_execute(self) -> bool:
        """Check if phases can execute in parallel"""
        return len(self.phases) > 1

    @property
    def total_phases(self) -> int:
        """Get total number of phases"""
        return len(self.phases)


@dataclass
class PhaseExecutionResult:
    """Result of phase execution"""

    phase_name: str
    agent_name: str
    success: bool
    output: Optional[str] = None
    error: Optional[str] = None
    duration: float = 0.0
    parallel_group: int = 0


class PhaseParallelizer:
    """
    Identifies and executes parallelizable phases

    Features:
    - Automatic dependency analysis
    - Parallel group scheduling
    - Result aggregation
    - Error handling

    Usage:
        parallelizer = PhaseParallelizer()

        # Define phases
        parallelizer.add_phase(PhaseDependency(...))

        # Analyze and execute
        groups = parallelizer.analyze_phases()
        results = await parallelizer.execute_groups(groups, executor)
    """

    # Default parallelizable phases (can run simultaneously)
    DEFAULT_PARALLEL_PHASES = ["genre_agent", "character_agent", "world_agent"]

    def __init__(self):
        self.phases: Dict[str, PhaseDependency] = {}
        self.execution_order: List[int] = []

    def add_phase(self, phase: PhaseDependency) -> None:
        """
        Add a phase to the parallelizer

        Args:
            phase: Phase to add
        """
        self.phases[phase.phase_name] = phase

    def add_phase_batch(self, phases: List[PhaseDependency]) -> None:
        """
        Add multiple phases

        Args:
            phases: List of phases to add
        """
        for phase in phases:
            self.add_phase(phase)

    def remove_phase(self, phase_name: str) -> bool:
        """
        Remove a phase

        Args:
            phase_name: Name of phase to remove

        Returns:
            True if removed, False if not found
        """
        if phase_name in self.phases:
            del self.phases[phase_name]
            return True
        return False

    def clear_phases(self) -> None:
        """Clear all phases"""
        self.phases.clear()
        self.execution_order.clear()

    def analyze_dependencies(self) -> List[PhaseGroup]:
        """
        Analyze phase dependencies and create execution groups

        Returns:
            List of PhaseGroups in execution order

        Raises:
            ValueError: If circular dependencies detected
        """
        if not self.phases:
            return []

        # Build adjacency list
        graph: Dict[str, List[str]] = defaultdict(list)
        in_degree: Dict[str, int] = defaultdict(int)

        for phase_name, phase in self.phases.items():
            in_degree[phase_name] = len(phase.depends_on)
            for dep in phase.depends_on:
                graph[dep].append(phase_name)

        # Check for cycles
        if self._has_cycle(graph):
            raise ValueError("Circular dependency detected in phases")

        # Topological sort to determine execution groups
        execution_groups = self._topological_group_sort(graph, in_degree)

        return execution_groups

    def _has_cycle(self, graph: Dict[str, List[str]]) -> bool:
        """Check if graph has cycles using DFS"""
        visited = set()
        rec_stack = set()

        def dfs(node: str) -> bool:
            visited.add(node)
            rec_stack.add(node)

            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True

            rec_stack.remove(node)
            return False

        for node in graph:
            if node not in visited:
                if dfs(node):
                    return True

        return False

    def _topological_group_sort(
        self, graph: Dict[str, List[str]], in_degree: Dict[str, int]
    ) -> List[PhaseGroup]:
        """
        Perform topological sort and group parallelizable phases

        Returns:
            List of PhaseGroups
        """
        # Initialize group tracking
        groups: List[PhaseGroup] = []
        current_group: List[str] = []
        group_id = 0

        # Track which phases are in each group
        phase_to_group: Dict[str, int] = {}

        # Find phases with no dependencies
        queue = [p for p, d in in_degree.items() if d == 0]

        while queue:
            # Group all ready phases together
            current_group = queue.copy()
            queue.clear()

            for phase_name in current_group:
                phase = self.phases[phase_name]
                phase_to_group[phase_name] = group_id

            # Create phase group
            phases = [self.phases[p] for p in current_group]

            # Calculate dependencies on other groups
            group_deps = set()
            for phase in phases:
                for dep in phase.depends_on:
                    if dep in phase_to_group:
                        group_deps.add(phase_to_group[dep])

            group = PhaseGroup(group_id=group_id, phases=phases, depends_on_groups=group_deps)
            groups.append(group)

            # Remove processed phases from graph
            for phase_name in current_group:
                for neighbor in graph.get(phase_name, []):
                    in_degree[neighbor] -= 1
                    if in_degree[neighbor] == 0 and neighbor not in phase_to_group:
                        queue.append(neighbor)

            group_id += 1

        # Update parallel_group for each phase
        for group in groups:
            for phase in group.phases:
                phase.parallel_group = group.group_id

        return groups

    async def execute_groups(
        self, groups: List[PhaseGroup], executor_func: Callable
    ) -> Dict[str, PhaseExecutionResult]:
        """
        Execute phase groups in parallel

        Args:
            groups: Groups to execute
            executor_func: Function to execute agent (async)

        Returns:
            Dictionary of phase_name -> result
        """
        from core.agents.queue import AgentQueue, AgentTask, TaskStatus

        results: Dict[str, PhaseExecutionResult] = {}
        queue = AgentQueue(max_concurrent=3)

        # Execute groups in order
        for group in groups:
            if not group.can_parallel_execute:
                # Sequential execution
                for phase in group.phases:
                    result = await self._execute_phase(phase, executor_func)
                    results[phase.phase_name] = result
            else:
                # Parallel execution
                tasks = []
                for phase in group.phases:
                    task = AgentTask(
                        task_id=phase.phase_name,
                        agent_name=phase.agent_name,
                        prompt=phase.prompt_template,
                        priority=phase.priority,
                        timeout=300,
                    )
                    tasks.append(task)

                # Execute in parallel
                task_results = await queue.execute_parallel(
                    tasks, lambda name, prompt, **kw: executor_func(name, prompt)
                )

                # Convert to PhaseExecutionResult
                for task_id, task_result in task_results.items():
                    phase = self.phases[task_id]
                    results[task_id] = PhaseExecutionResult(
                        phase_name=phase.phase_name,
                        agent_name=phase.agent_name,
                        success=task_result.status == TaskStatus.COMPLETED,
                        output=task_result.result,
                        error=task_result.error,
                        duration=task_result.duration,
                        parallel_group=group.group_id,
                    )

        return results

    async def _execute_phase(
        self, phase: PhaseDependency, executor_func: Callable
    ) -> PhaseExecutionResult:
        """Execute a single phase"""
        import time

        start = time.time()

        try:
            output = await executor_func(phase.agent_name, phase.prompt_template)
            duration = time.time() - start

            return PhaseExecutionResult(
                phase_name=phase.phase_name,
                agent_name=phase.agent_name,
                success=True,
                output=output,
                duration=duration,
                parallel_group=phase.parallel_group,
            )
        except Exception as e:
            duration = time.time() - start
            return PhaseExecutionResult(
                phase_name=phase.phase_name,
                agent_name=phase.agent_name,
                success=False,
                error=str(e),
                duration=duration,
                parallel_group=phase.parallel_group,
            )

    def get_execution_plan(self) -> str:
        """
        Get human-readable execution plan

        Returns:
            String describing execution order
        """
        groups = self.analyze_dependencies()

        lines = ["Execution Plan:"]
        for group in groups:
            if group.can_parallel_execute:
                phase_names = [p.phase_name for p in group.phases]
                lines.append(f"  Group {group.group_id} (PARALLEL): {', '.join(phase_names)}")
            else:
                for phase in group.phases:
                    lines.append(f"  Group {group.group_id} (SEQUENTIAL): {phase.phase_name}")

        return "\n".join(lines)

    @classmethod
    def create_novel_generation_phases(
        cls, project_name: str, genre: Optional[str] = None, outline: Optional[str] = None
    ) -> "PhaseParallelizer":
        """
        Create phases for novel generation workflow

        Args:
            project_name: Name of the project
            genre: Optional genre preference
            outline: Optional outline

        Returns:
            Configured PhaseParallelizer
        """
        parallelizer = cls()

        # Phase 1: Discussion (sequential, first)
        parallelizer.add_phase(
            PhaseDependency(
                phase_name="discuss",
                agent_name="discuss_agent",
                prompt_template=f"Discuss novel for project {project_name}",
                priority=10,
            )
        )

        # Phase 2: Parallel execution (genre, characters, world)
        parallelizer.add_phase(
            PhaseDependency(
                phase_name="genre",
                agent_name="genre_agent",
                prompt_template=f"Analyze genre for {project_name}",
                depends_on=["discuss"],
                priority=5,
            )
        )

        parallelizer.add_phase(
            PhaseDependency(
                phase_name="characters",
                agent_name="character_agent",
                prompt_template=f"Develop characters for {project_name}",
                depends_on=["discuss"],
                priority=5,
            )
        )

        parallelizer.add_phase(
            PhaseDependency(
                phase_name="world",
                agent_name="world_agent",
                prompt_template=f"Build world for {project_name}",
                depends_on=["discuss"],
                priority=5,
            )
        )

        # Phase 3: Outline (sequential, depends on all above)
        parallelizer.add_phase(
            PhaseDependency(
                phase_name="outline",
                agent_name="outline_agent",
                prompt_template=f"Create outline for {project_name}",
                depends_on=["genre", "characters", "world"],
                priority=3,
            )
        )

        return parallelizer


# Global parallelizer instance
_parallelizer: Optional[PhaseParallelizer] = None


def get_phase_parallelizer() -> PhaseParallelizer:
    """Get or create global phase parallelizer"""
    global _parallelizer
    if _parallelizer is None:
        _parallelizer = PhaseParallelizer()
    return _parallelizer


def reset_phase_parallelizer() -> None:
    """Reset global parallelizer"""
    global _parallelizer
    _parallelizer = None
