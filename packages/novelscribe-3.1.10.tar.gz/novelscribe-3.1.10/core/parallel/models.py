"""
Data models for Parallel Execution System.

Contains execution status, node, result, and graph data structures
used by the parallel executor for dependency-based concurrent processing.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4


class ExecutionStatus(Enum):
    """Status of agent execution"""

    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ExecutionNode:
    """Represents a node in the execution graph"""

    agent_name: str
    agent_id: str = field(default_factory=lambda: str(uuid4()))
    dependencies: List[str] = field(default_factory=list)
    dependents: List[str] = field(default_factory=list)
    status: ExecutionStatus = ExecutionStatus.PENDING
    result: Optional[Any] = None
    error: Optional[str] = None
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    duration: Optional[float] = None
    retry_count: int = 0
    max_retries: int = 3

    @property
    def is_ready(self) -> bool:
        """Check if node is ready to execute (all dependencies completed)"""
        return all(dep_status == ExecutionStatus.COMPLETED for dep_status in self.dependencies)

    @property
    def can_run_parallel(self) -> bool:
        """Check if this node can run in parallel with others"""
        return self.status == ExecutionStatus.READY

    def to_dict(self) -> Dict[str, Any]:
        """Convert node to dictionary"""
        return {
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "dependencies": self.dependencies,
            "dependents": self.dependents,
            "status": self.status.value,
            "result": str(self.result)[:100] if self.result else None,
            "error": self.error,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration": self.duration,
            "retry_count": self.retry_count,
        }


@dataclass
class ExecutionResult:
    """Result of parallel execution"""

    success: bool
    completed_nodes: List[str]
    failed_nodes: List[str]
    skipped_nodes: List[str]
    total_duration: float
    node_results: Dict[str, Any]
    errors: Dict[str, str]
    parallel_speedup: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary"""
        return {
            "success": self.success,
            "completed_nodes": self.completed_nodes,
            "failed_nodes": self.failed_nodes,
            "skipped_nodes": self.skipped_nodes,
            "total_duration": self.total_duration,
            "node_results": self.node_results,
            "errors": self.errors,
            "parallel_speedup": f"{self.parallel_speedup:.2f}x",
        }


@dataclass
class ExecutionGraph:
    """Directed acyclic graph representing agent dependencies"""

    nodes: Dict[str, ExecutionNode] = field(default_factory=dict)
    edges: Dict[str, List[str]] = field(default_factory=dict)

    def add_node(self, node: ExecutionNode) -> None:
        """Add a node to the graph"""
        self.nodes[node.agent_id] = node
        if node.agent_id not in self.edges:
            self.edges[node.agent_id] = []

    def add_edge(self, from_id: str, to_id: str) -> None:
        """Add a directed edge (dependency) from_id -> to_id"""
        if from_id not in self.edges:
            self.edges[from_id] = []
        self.edges[from_id].append(to_id)

        # Update dependencies
        if to_id in self.nodes:
            self.nodes[to_id].dependencies.append(from_id)
        if from_id in self.nodes:
            self.nodes[from_id].dependents.append(to_id)

    def get_ready_nodes(self) -> List[ExecutionNode]:
        """Get all nodes that are ready to execute"""
        return [
            node
            for node in self.nodes.values()
            if node.status == ExecutionStatus.READY and node.is_ready
        ]

    def topological_sort(self) -> List[str]:
        """
        Perform topological sort to get execution order

        Returns:
            List of agent IDs in execution order

        Raises:
            ValueError: If graph contains cycles
        """
        in_degree = {node_id: 0 for node_id in self.nodes}

        # Calculate in-degrees
        for from_id in self.edges:
            for to_id in self.edges[from_id]:
                in_degree[to_id] += 1

        # Start with nodes having no dependencies
        queue = [node_id for node_id, degree in in_degree.items() if degree == 0]
        result = []

        while queue:
            node_id = queue.pop(0)
            result.append(node_id)

            # Reduce in-degree for dependents
            for dependent_id in self.edges.get(node_id, []):
                in_degree[dependent_id] -= 1
                if in_degree[dependent_id] == 0:
                    queue.append(dependent_id)

        # Check for cycles
        if len(result) != len(self.nodes):
            raise ValueError("Execution graph contains cycles")

        return result

    def detect_cycles(self) -> List[List[str]]:
        """
        Detect cycles in the execution graph

        Returns:
            List of cycles (each cycle is a list of node IDs)
        """
        white, gray, black = 0, 1, 2
        color = {node_id: white for node_id in self.nodes}
        cycles = []

        def dfs(node_id: str, path: List[str]) -> None:
            nonlocal cycles
            color[node_id] = gray
            path.append(node_id)

            for neighbor in self.edges.get(node_id, []):
                if color[neighbor] == gray:
                    # Found cycle
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:] + [neighbor])
                elif color[neighbor] == white:
                    dfs(neighbor, path.copy())

            color[node_id] = black

        for node_id in self.nodes:
            if color[node_id] == white:
                dfs(node_id, [])

        return cycles

    def validate(self) -> Tuple[bool, List[str]]:
        """
        Validate the execution graph

        Returns:
            Tuple of (is_valid, error_messages)
        """
        errors = []

        # Check for cycles
        cycles = self.detect_cycles()
        if cycles:
            errors.append(f"Found {len(cycles)} cycles in execution graph")
            for i, cycle in enumerate(cycles):
                errors.append(f"  Cycle {i + 1}: {' -> '.join(cycle)}")

        # Check for missing dependencies
        for node_id, node in self.nodes.items():
            for dep_id in node.dependencies:
                if dep_id not in self.nodes:
                    errors.append(f"Node {node_id} depends on non-existent node {dep_id}")

        return (len(errors) == 0, errors)
