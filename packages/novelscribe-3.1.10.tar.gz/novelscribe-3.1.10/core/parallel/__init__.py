"""core.parallel — parallel execution subsystem."""

from core.agents.queue import AgentQueue, AgentTask, TaskStatus
from core.parallel.async_executor import (
    AsyncAgentExecutor,
    ExecutionMetrics,
    _executor,
    agent_context,
    get_async_executor,
    reset_async_executor,
)
from core.parallel.executor import (
    ExecutionGraph,
    ExecutionNode,
    ExecutionResult,
    ExecutionStatus,
    ParallelExecutor,
    as_completed,
    get_parallel_executor,
    logger,
)
from core.parallel.models import Enum, uuid4
from core.parallel.orchestrator import (
    ExecutionMode,
    OrchestrationResult,
    ParallelConfig,
    ParallelOrchestrator,
    PhaseDependency,
    PhaseGroup,
    PhaseParallelizer,
    PhaseResult,
    get_parallel_orchestrator,
    reset_parallel_orchestrator,
)
from core.parallel.phase_parallelizer import (
    PhaseExecutionResult,
    get_phase_parallelizer,
    reset_phase_parallelizer,
)
from core.parallel.step_executor import ParallelStepExecutor

__all__ = [
    "AgentQueue",
    "AgentTask",
    "AsyncAgentExecutor",
    "ExecutionGraph",
    "ExecutionMetrics",
    "ExecutionMode",
    "ExecutionNode",
    "ExecutionResult",
    "ExecutionStatus",
    "Enum",
    "OrchestrationResult",
    "ParallelConfig",
    "ParallelExecutor",
    "ParallelOrchestrator",
    "PhaseDependency",
    "PhaseExecutionResult",
    "PhaseGroup",
    "PhaseParallelizer",
    "PhaseResult",
    "ParallelStepExecutor",
    "TaskStatus",
    "_executor",
    "agent_context",
    "as_completed",
    "get_async_executor",
    "get_parallel_executor",
    "get_parallel_orchestrator",
    "get_phase_parallelizer",
    "logger",
    "reset_async_executor",
    "reset_parallel_orchestrator",
    "reset_phase_parallelizer",
    "uuid4",
]
