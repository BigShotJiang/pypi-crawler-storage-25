"""
Async Agent Executor for Parallel Agent Execution

This module provides asyncio-based execution for agents with concurrency control,
context isolation, and resource management.
"""

import asyncio
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

# Context for agent isolation
agent_context: ContextVar[Dict[str, Any]] = ContextVar("agent_context", default={})


@dataclass
class ExecutionMetrics:
    """Metrics for agent execution"""

    agent_name: str
    start_time: float
    end_time: Optional[float] = None
    duration: float = 0.0
    success: bool = False
    error: Optional[str] = None
    memory_start: Optional[int] = None
    memory_end: Optional[int] = None


class AsyncAgentExecutor:
    """
    Asyncio-based executor for parallel agent execution

    Features:
    - Configurable concurrency limits
    - Context isolation per agent
    - Memory management
    - Resource monitoring
    - Error handling

    Usage:
        executor = AsyncAgentExecutor(max_concurrent=3)

        # Execute single agent
        result = await executor.execute("genre_agent", "Analyze sci-fi")

        # Execute multiple agents in parallel
        results = await executor.execute_many([
            ("genre_agent", "Analyze sci-fi"),
            ("character_agent", "Create hero"),
            ("world_agent", "Build universe")
        ])
    """

    def __init__(
        self, max_concurrent: int = 3, memory_limit_mb: int = 2048, enable_metrics: bool = True
    ):
        self.max_concurrent = max_concurrent
        self.memory_limit_mb = memory_limit_mb
        self.enable_metrics = enable_metrics

        # Concurrency control
        self.semaphore = asyncio.Semaphore(max_concurrent)

        # Thread pool for blocking operations
        self.thread_pool = ThreadPoolExecutor(max_workers=max_concurrent)

        # Metrics tracking
        self.metrics: Dict[str, List[ExecutionMetrics]] = {}

        # Lock for thread-safe operations
        self.lock = asyncio.Lock()

        # Active executions
        self.active_count = 0

        # Agent registry (maps agent names to executor functions)
        self.agent_registry: Dict[str, Callable] = {}

    def register_agent(self, agent_name: str, executor_func: Callable) -> None:
        """
        Register an agent executor function

        Args:
            agent_name: Name of the agent
            executor_func: Async function to execute the agent
        """
        self.agent_registry[agent_name] = executor_func

    def get_registered_agents(self) -> List[str]:
        """Get list of registered agents"""
        return list(self.agent_registry.keys())

    async def execute(self, agent_name: str, prompt: str, **kwargs) -> str:
        """
        Execute a single agent

        Args:
            agent_name: Name of the agent to execute
            prompt: Prompt for the agent
            **kwargs: Additional arguments for the agent

        Returns:
            Agent output as string

        Raises:
            ValueError: If agent not registered
            RuntimeError: If execution fails
        """
        if agent_name not in self.agent_registry:
            raise ValueError(f"Agent '{agent_name}' not registered")

        async with self.semaphore:
            # Create context for this execution
            ctx = {
                "agent_name": agent_name,
                "prompt": prompt,
                "kwargs": kwargs,
                "start_time": time.time(),
            }
            token = agent_context.set(ctx)

            try:
                # Track execution
                async with self.lock:
                    self.active_count += 1

                # Create metrics
                metrics = ExecutionMetrics(agent_name=agent_name, start_time=time.time())

                # Get executor function
                executor_func = self.agent_registry[agent_name]

                # Execute with timeout
                result = await asyncio.wait_for(
                    executor_func(prompt, **kwargs), timeout=kwargs.get("timeout", 300)
                )

                # Update metrics
                metrics.end_time = time.time()
                metrics.duration = metrics.end_time - metrics.start_time
                metrics.success = True

                # Store metrics
                if self.enable_metrics:
                    async with self.lock:
                        if agent_name not in self.metrics:
                            self.metrics[agent_name] = []
                        self.metrics[agent_name].append(metrics)

                return result

            except asyncio.TimeoutError:
                error = f"Agent '{agent_name}' timed out"
                metrics.end_time = time.time()
                metrics.duration = metrics.end_time - metrics.start_time
                metrics.success = False
                metrics.error = error
                raise RuntimeError(error) from None

            except Exception as e:
                error = f"Agent '{agent_name}' failed: {str(e)}\n{traceback.format_exc()}"
                metrics.end_time = time.time()
                metrics.duration = metrics.end_time - metrics.start_time
                metrics.success = False
                metrics.error = error
                raise RuntimeError(error) from e

            finally:
                # Cleanup
                agent_context.reset(token)
                async with self.lock:
                    self.active_count -= 1

    async def execute_many(
        self, tasks: List[Tuple[str, str]], stop_on_error: bool = False
    ) -> List[str]:
        """
        Execute multiple agents in parallel

        Args:
            tasks: List of (agent_name, prompt) tuples
            stop_on_error: Whether to stop on first error

        Returns:
            List of agent outputs
        """
        results = []

        if stop_on_error:
            # Execute sequentially (stop on error)
            # Create coroutines lazily to avoid unawaited coroutine warnings
            for agent_name, prompt in tasks:
                try:
                    result = await self.execute(agent_name, prompt)
                    results.append(result)
                except Exception as e:
                    results.append(f"ERROR: {str(e)}")
                    break
        else:
            # Execute in parallel
            # Create coroutines for parallel execution
            coroutines = [self.execute(agent_name, prompt) for agent_name, prompt in tasks]
            completed = await asyncio.gather(*coroutines, return_exceptions=True)

            for i, result in enumerate(completed):
                if isinstance(result, Exception):
                    results.append(f"ERROR: {str(result)}")
                else:
                    results.append(result)

        return results

    async def execute_parallel(
        self, agents: List[Dict[str, Any]], wait_all: bool = True
    ) -> Dict[str, Any]:
        """
        Execute agents with parallel processing

        Args:
            agents: List of agent configurations
                [{"name": "agent1", "prompt": "...", "dependencies": []}, ...]
            wait_all: Whether to wait for all agents

        Returns:
            Dictionary of agent_name -> output
        """
        from core.agents.queue import AgentQueue, AgentTask

        # Create agent queue
        queue = AgentQueue(max_concurrent=self.max_concurrent)

        # Create tasks
        async def executor(name: str, prompt: str, **kw) -> str:
            return await self.execute(name, prompt, **kw)

        tasks = [
            AgentTask(
                task_id=agent.get("id", f"{agent['name']}_{i}"),
                agent_name=agent["name"],
                prompt=agent["prompt"],
                priority=agent.get("priority", 0),
                dependencies=agent.get("dependencies", []),
                timeout=agent.get("timeout", 300),
                metadata=agent.get("metadata", {}),
            )
            for i, agent in enumerate(agents)
        ]

        # Execute
        results = await queue.execute_parallel(tasks, executor)

        # Convert to output dictionary
        outputs = {}
        for task_id, result in results.items():
            if result.result:
                outputs[result.agent_name] = result.result
            else:
                outputs[result.agent_name] = f"ERROR: {result.error}"

        return outputs

    def get_active_count(self) -> int:
        """Get number of active executions"""
        return self.active_count

    def get_metrics(self, agent_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Get execution metrics

        Args:
            agent_name: Optional agent name to filter metrics

        Returns:
            Metrics dictionary
        """
        if agent_name:
            metrics_list = self.metrics.get(agent_name, [])
        else:
            metrics_list = []
            for agent_metrics in self.metrics.values():
                metrics_list.extend(agent_metrics)

        if not metrics_list:
            return {"count": 0, "avg_duration": 0, "success_rate": 0}

        total = len(metrics_list)
        successful = sum(1 for m in metrics_list if m.success)

        return {
            "count": total,
            "successful": successful,
            "failed": total - successful,
            "success_rate": (successful / total * 100) if total > 0 else 0,
            "avg_duration": sum(m.duration for m in metrics_list) / total,
            "min_duration": min(m.duration for m in metrics_list),
            "max_duration": max(m.duration for m in metrics_list),
        }

    def reset_metrics(self) -> None:
        """Reset all metrics"""
        self.metrics.clear()

    async def cleanup(self) -> None:
        """Cleanup resources"""
        self.thread_pool.shutdown(wait=True)

    async def __aenter__(self):
        """Async context manager entry"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.cleanup()


# Global executor instance
_executor: Optional[AsyncAgentExecutor] = None


def get_async_executor(max_concurrent: int = 3, force_new: bool = False) -> AsyncAgentExecutor:
    """
    Get or create global async executor

    Args:
        max_concurrent: Maximum concurrent executions
        force_new: Force create new instance

    Returns:
        AsyncAgentExecutor instance
    """
    global _executor
    if _executor is None or force_new:
        _executor = AsyncAgentExecutor(max_concurrent=max_concurrent)
    return _executor


def reset_async_executor() -> None:
    """Reset global executor"""
    global _executor
    if _executor:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(_executor.cleanup())
        else:
            loop.create_task(_executor.cleanup())
    _executor = None
