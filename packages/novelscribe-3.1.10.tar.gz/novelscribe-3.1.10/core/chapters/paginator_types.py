"""
Chapter Paginator Data Types and Configuration.

Contains data models, enums, and configuration for chapter pagination.
"""

import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict


class PageSplitStrategy(str, Enum):
    """Strategies for splitting chapters into pages."""

    TOKEN_BASED = "***"
    SCENE_BASED = "scene_based"
    PARAGRAPH_BASED = "paragraph_based"
    SEMANTIC = "semantic"


@dataclass
class PageMetadata:
    """Metadata for a page within a chapter."""

    page_number: int
    start_position: int
    end_position: int
    word_count: int
    token_count: int
    scene_identifier: Optional[str] = None
    characters_present: List[str] = field(default_factory=list)
    locations_present: List[str] = field(default_factory=list)
    key_events: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "page_number": self.page_number,
            "start_position": self.start_position,
            "end_position": self.end_position,
            "word_count": self.word_count,
            "token_count": self.token_count,
            "scene_identifier": self.scene_identifier,
            "characters_present": self.characters_present,
            "locations_present": self.locations_present,
            "key_events": self.key_events,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class ChapterPage:
    """A single page within a chapter."""

    page_number: int
    content: str
    metadata: PageMetadata
    overlap_content: str = ""

    @property
    def word_count(self) -> int:
        """Get word count of page."""
        return len(re.findall(r"\b\w+\b", self.content))

    @property
    def full_content(self) -> str:
        """Get full content including overlap."""
        if self.overlap_content:
            return f"{self.overlap_content}\n\n{self.content}"
        return self.content

    def get_context_hint(self) -> str:
        """Get context hint for this page."""
        hint_parts = []

        if self.metadata.scene_identifier:
            hint_parts.append(f"Scene: {self.metadata.scene_identifier}")

        if self.metadata.characters_present:
            hint_parts.append(f"Characters: {', '.join(self.metadata.characters_present)}")

        if self.metadata.locations_present:
            hint_parts.append(f"Location: {', '.join(self.metadata.locations_present)}")

        return " | ".join(hint_parts) if hint_parts else "Continuing story..."


class PaginationConfig(BaseModel):
    """Configuration for chapter pagination."""

    strategy: PageSplitStrategy = PageSplitStrategy.SEMANTIC
    max_tokens_per_page: int = 2500
    target_tokens_per_page: int = 2000
    overlap_tokens: int = 200
    min_page_tokens: int = 500
    preserve_scene_boundaries: bool = True
    preserve_dialogue_groups: bool = True

    model_config = ConfigDict(use_enum_values=True)
