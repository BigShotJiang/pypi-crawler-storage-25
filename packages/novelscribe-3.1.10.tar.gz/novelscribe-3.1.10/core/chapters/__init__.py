"""core.chapters — chapter management subsystem."""

from core.chapters.multi_manager import (
    ChapterContent,
    ChapterIndex,
    ChapterLoadStatus,
    ChapterReference,
    MultiChapterManager,
    MultiChapterManagerConfig,
    TokenEstimator,
)
from core.chapters.paginator import (
    ChapterPage,
    ChapterPaginator,
    PageMetadata,
    PageSplitStrategy,
    PaginationConfig,
)
from core.chapters.regenerator import (
    AgentRegistry,
    ChapterRegenerator,
    DraftManager,
    RegenerationConfig,
    RegenerationResult,
    RegenerationStrategy,
    StorageConfig,
    StorageFactory,
)

__all__ = [
    "AgentRegistry",
    "ChapterContent",
    "ChapterIndex",
    "ChapterLoadStatus",
    "ChapterPage",
    "ChapterPaginator",
    "ChapterReference",
    "ChapterRegenerator",
    "DraftManager",
    "MultiChapterManager",
    "MultiChapterManagerConfig",
    "PageMetadata",
    "PageSplitStrategy",
    "PaginationConfig",
    "RegenerationConfig",
    "RegenerationResult",
    "RegenerationStrategy",
    "StorageConfig",
    "StorageFactory",
    "TokenEstimator",
]
