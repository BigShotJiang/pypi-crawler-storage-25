"""Timeout handler for checkpoint decisions.

Provides configurable timeout actions (auto-approve, escalate, pause)
and timer management for checkpoint awaiting.
"""

import asyncio
import logging
from enum import Enum
from typing import Any, Callable, Optional

from core.checkpoints.background import BackgroundCheckpointer
from core.hybrid_authority import AuthorityConfig, AuthorityLevel


class TimeoutAction(str, Enum):
    """Action to take when a checkpoint times out."""

    AUTO_APPROVE = "auto_approve"
    ESCALATE = "escalate"
    PAUSE = "pause"


class TimeoutHandler:
    """Manages checkpoint timeouts with configurable actions.

    Wraps BackgroundCheckpointer to provide a simpler timeout-focused API
    with three action modes: auto-approve, escalate, or pause indefinitely.
    """

    def __init__(
        self,
        action: TimeoutAction = TimeoutAction.PAUSE,
        timeout_seconds: Optional[int] = None,
        on_timeout: Optional[Callable[[str], None]] = None,
    ):
        self.action = action
        self.timeout_seconds = timeout_seconds
        self._on_timeout = on_timeout
        self._logger = logging.getLogger("scribe")
        self._timers: dict[str, asyncio.Task] = {}

        timeout_hours = timeout_seconds / 3600 if timeout_seconds else None
        authority_config = AuthorityConfig(
            timeout_hours=timeout_hours,
            level=AuthorityLevel.AI_CAN_PROCEED
            if action == TimeoutAction.AUTO_APPROVE
            else AuthorityLevel.HUMAN_FIRST,
        )

        self._checkpointer = BackgroundCheckpointer(
            authority_config=authority_config,
            on_timeout=self._handle_timeout_event,
        )

    @property
    def checkpointer(self) -> BackgroundCheckpointer:
        """Access the underlying BackgroundCheckpointer."""
        return self._checkpointer

    def start_timer(
        self,
        checkpoint_id: str,
        timeout_seconds: Optional[int] = None,
        callback: Optional[Callable[[], None]] = None,
    ) -> None:
        """Start a timeout timer for a checkpoint.

        Args:
            checkpoint_id: Checkpoint to monitor.
            timeout_seconds: Override timeout duration.
            callback: Optional callback on timeout.
        """
        effective_timeout = timeout_seconds or self.timeout_seconds
        timeout_hours = effective_timeout / 3600 if effective_timeout else None

        if callback:
            self._checkpointer.set_checkpoint_callback(checkpoint_id, callback)

        self._checkpointer.start_monitoring(checkpoint_id, timeout_hours=timeout_hours)
        self._logger.info(
            f"Timer started for {checkpoint_id} ({effective_timeout}s, action={self.action.value})"
        )

    def cancel_timer(self, checkpoint_id: str) -> None:
        """Cancel timeout timer for a checkpoint.

        Args:
            checkpoint_id: Checkpoint to cancel timer for.
        """
        self._checkpointer.stop_monitoring(checkpoint_id)
        self._logger.info(f"Timer cancelled for {checkpoint_id}")

    def extend_timer(self, checkpoint_id: str, additional_seconds: int) -> bool:
        """Extend timeout for a checkpoint.

        Args:
            checkpoint_id: Checkpoint to extend.
            additional_seconds: Additional time in seconds.

        Returns:
            True if extension was applied.
        """
        hours = additional_seconds / 3600
        result = self._checkpointer.extend_deadline(checkpoint_id, hours)
        if result:
            self._logger.info(f"Timer extended for {checkpoint_id} by {additional_seconds}s")
        return result

    def get_timer_status(self, checkpoint_id: str) -> Optional[dict[str, Any]]:
        """Get timer status for a checkpoint.

        Args:
            checkpoint_id: Checkpoint to check.

        Returns:
            Timer status dict or None.
        """
        return self._checkpointer.get_deadline_status(checkpoint_id)

    def _handle_timeout_event(self, checkpoint_id: str) -> None:
        """Handle timeout event from BackgroundCheckpointer."""
        self._logger.warning(f"Checkpoint {checkpoint_id} timed out — action: {self.action.value}")
        if self._on_timeout:
            self._on_timeout(checkpoint_id)

    def shutdown(self) -> None:
        """Clean up resources."""
        self._checkpointer.shutdown()


def create_timeout_handler(
    action: str = "pause",
    timeout_seconds: Optional[int] = None,
) -> TimeoutHandler:
    """Factory function to create a TimeoutHandler.

    Args:
        action: Timeout action name (auto_approve, escalate, pause).
        timeout_seconds: Timeout duration in seconds.

    Returns:
        TimeoutHandler instance.
    """
    action_enum = TimeoutAction(action)
    return TimeoutHandler(action=action_enum, timeout_seconds=timeout_seconds)
