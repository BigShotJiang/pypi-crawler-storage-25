"""Circuit breaker for LLM provider fault tolerance."""

import time
from enum import Enum
from typing import Optional

from pydantic import BaseModel


class CircuitState(str, Enum):
    """Circuit breaker states."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitConfig(BaseModel):
    """Configuration for circuit breaker behavior.

    Attributes:
        failure_threshold: Consecutive failures before opening the circuit.
        cooldown_seconds: Seconds to wait before transitioning from OPEN to HALF_OPEN.
        success_threshold: Consecutive successes in HALF_OPEN before closing.
    """

    failure_threshold: int = 5
    cooldown_seconds: float = 60.0
    success_threshold: int = 2


class CircuitBreaker:
    """Per-provider circuit breaker for LLM fault tolerance.

    State machine:
    - CLOSED: Normal operation. Counts consecutive failures.
      Transitions to OPEN when failure_count >= failure_threshold.
    - OPEN: All requests rejected. Waits for cooldown.
      Transitions to HALF_OPEN after cooldown_seconds elapsed.
    - HALF_OPEN: Allows limited requests to test recovery.
      Transitions to CLOSED on success_threshold consecutive successes.
      Transitions back to OPEN on any failure.

    Configurable via CircuitConfig (failure_threshold, cooldown_seconds,
    success_threshold). Reset to CLOSED on demand (phase boundaries).
    """

    def __init__(self, config: Optional[CircuitConfig] = None):
        """Initialize circuit breaker.

        Args:
            config: Optional configuration. Uses defaults if not provided.
        """
        self._config = config or CircuitConfig()
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time: Optional[float] = None

    @property
    def state(self) -> CircuitState:
        """Current circuit state."""
        return self._state

    @property
    def failure_count(self) -> int:
        """Current consecutive failure count."""
        return self._failure_count

    @property
    def config(self) -> CircuitConfig:
        """Circuit breaker configuration."""
        return self._config

    def can_execute(self) -> bool:
        """Check if a request should be allowed through.

        Returns:
            True if the circuit allows execution, False otherwise.
        """
        if self._state == CircuitState.CLOSED:
            return True

        if self._state == CircuitState.OPEN:
            if self._last_failure_time is None:
                return False
            elapsed = time.time() - self._last_failure_time
            if elapsed >= self._config.cooldown_seconds:
                self._state = CircuitState.HALF_OPEN
                self._success_count = 0
                return True
            return False

        if self._state == CircuitState.HALF_OPEN:
            return True

        return False

    def record_success(self) -> None:
        """Record a successful call.

        In HALF_OPEN state, increments success counter and transitions
        to CLOSED when success_threshold is reached. In CLOSED state,
        resets failure counter.
        """
        if self._state == CircuitState.HALF_OPEN:
            self._success_count += 1
            if self._success_count >= self._config.success_threshold:
                self._state = CircuitState.CLOSED
                self._failure_count = 0
                self._success_count = 0
        elif self._state == CircuitState.CLOSED:
            self._failure_count = 0

    def record_failure(self) -> None:
        """Record a failed call.

        Increments failure counter. In CLOSED state, transitions to OPEN
        when failure_threshold is reached. In HALF_OPEN state, immediately
        transitions back to OPEN.
        """
        self._failure_count += 1
        self._last_failure_time = time.time()

        if self._state == CircuitState.HALF_OPEN:
            self._state = CircuitState.OPEN
            self._success_count = 0
        elif self._state == CircuitState.CLOSED:
            if self._failure_count >= self._config.failure_threshold:
                self._state = CircuitState.OPEN

    def reset(self) -> None:
        """Reset circuit to CLOSED state.

        Called at phase boundaries to give providers a fresh start.
        """
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time = None
