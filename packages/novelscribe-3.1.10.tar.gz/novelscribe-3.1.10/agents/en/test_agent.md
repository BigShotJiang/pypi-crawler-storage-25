---
schema_version: 1
name: test_agent
description: A test agent
category: analytical
context_needs:
  required: []
  optional: []
---

You are a helpful test agent.
