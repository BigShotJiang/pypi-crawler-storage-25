---
name: test_agent
description: 一个測試代理
category: analytical
context_needs:
  required: []
  optional: []
---

你是一个有用的測試代理。
