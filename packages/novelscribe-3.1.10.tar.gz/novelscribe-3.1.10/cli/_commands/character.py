"""Character archetype exploration and management commands."""

import logging
import sys
from pathlib import Path

import click

from cli._helpers.error_handling import handle_cli_exception
from core.archetype.converter import ArchetypeConverter
from core.archetype.loader import get_archetype_loader
from core.i18n import LanguageCode, get_current_language
from core.llm.client import LLMConfig
from core.storage import StorageConfig


@click.group()
def character():
    """Character archetype exploration and management commands."""
    pass


@character.group("archetypes")
@click.pass_context
def archetypes(ctx: click.Context):
    """Explore built-in character archetypes."""
    pass


@archetypes.command("list")
@click.pass_context
def archetypes_list(ctx: click.Context):
    """List all available character archetypes."""
    logger = logging.getLogger("scribe")

    try:
        lang_str = ctx.obj.get("lang") if ctx.obj else None
        language = LanguageCode(lang_str) if lang_str else None
        project_dir = Path.cwd()

        current_language = get_current_language(
            explicit_language=language,
            project_dir=project_dir,
        )

        loader = get_archetype_loader(language=str(current_language))
        all_archetypes = loader.get_all_archetypes()

        if not all_archetypes:
            logger.warning("No archetypes found")
            return

        logger.info(
            "Available Character Archetypes (%d) [Language: %s]:",
            len(all_archetypes),
            current_language,
        )
        logger.info("")

        for slug, data in sorted(all_archetypes.items()):
            category = data.get("category", "unknown")
            name = data.get("name", slug)
            description = data.get("description", "")
            name_width = max(20, len(slug))
            logger.info(f"  {slug:<{name_width}} - {name} ({category})")
            if description:
                logger.info(f"  {'':>{name_width}}   {description}")

        logger.info("")
        logger.info("Run 'scribe character archetypes show <slug>' for detailed information.")

    except Exception as e:
        handle_cli_exception(
            logger,
            f"Failed to list archetypes: {e}",
            e,
            debug=(ctx.obj or {}).get("debug", False),
        )


@archetypes.command("show")
@click.argument("archetype_slug")
@click.pass_context
def archetypes_show(ctx: click.Context, archetype_slug: str):
    """Show detailed information about a character archetype."""
    logger = logging.getLogger("scribe")

    try:
        lang_str = ctx.obj.get("lang") if ctx.obj else None
        language = LanguageCode(lang_str) if lang_str else None
        project_dir = Path.cwd()

        current_language = get_current_language(
            explicit_language=language,
            project_dir=project_dir,
        )

        loader = get_archetype_loader(language=str(current_language))
        archetype = loader.get_archetype(archetype_slug)

        if not archetype:
            logger.error(
                "Archetype '%s' not found [Language: %s]",
                archetype_slug,
                current_language,
            )
            available = loader.list_archetypes()
            logger.info("Available archetypes: %s", ", ".join(available))
            sys.exit(1)

        detail = loader.format_archetype_detail(archetype_slug)
        if detail:
            logger.info(detail)
        else:
            logger.error("Failed to format archetype '%s'", archetype_slug)
            sys.exit(1)

    except Exception as e:
        handle_cli_exception(
            logger,
            f"Failed to show archetype: {e}",
            e,
            debug=(ctx.obj or {}).get("debug", False),
        )


@character.command("convert")
@click.argument("archetype_slug")
@click.argument("character_name")
@click.option("--project", "-p", default=None, help="Project name to append character to")
@click.option("--output", "-o", default=None, help="Output file path")
@click.option(
    "--provider",
    envvar="LLM_PROVIDER",
    default="openai",
    help="LLM provider to use",
)
@click.option("--genre", "-g", default=None, help="Genre context for character")
@click.pass_context
def character_convert(
    ctx: click.Context,
    archetype_slug: str,
    character_name: str,
    project: str | None,
    output: str | None,
    provider: str,
    genre: str | None,
) -> None:
    """Convert an archetype into an original character profile using LLM."""
    debug = (ctx.obj or {}).get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        lang_str = ctx.obj.get("lang") if ctx.obj else None
        language = LanguageCode(lang_str) if lang_str else None
        project_dir = Path.cwd()

        current_language = get_current_language(
            explicit_language=language,
            project_dir=project_dir,
        )

        llm_config = LLMConfig(provider=provider)
        converter = ArchetypeConverter(
            llm_config=llm_config,
            language=str(current_language),
        )

        logger.info(
            "Converting archetype '%s' into character '%s'...",
            archetype_slug,
            character_name,
        )

        profile = converter.convert(
            archetype_slug=archetype_slug,
            character_name=character_name,
            genre=genre,
        )

        if project:
            storage_config = StorageConfig(base_path=".novels")
            project_path = Path(storage_config.base_path) / project

            if not project_path.exists():
                logger.error("Project '%s' not found", project)
                logger.info("Create it first with: scribe new %s", project)
                sys.exit(1)

            characters_file = project_path / "CHARACTERS.md"
            if characters_file.exists():
                existing = characters_file.read_text(encoding="utf-8")
                if not existing.endswith("\n"):
                    existing += "\n"
                existing += "\n" + profile + "\n"
                characters_file.write_text(existing, encoding="utf-8")
            else:
                characters_file.write_text(profile + "\n", encoding="utf-8")

            logger.info("Character '%s' appended to %s", character_name, characters_file)

        elif output:
            output_path = Path(output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(profile + "\n", encoding="utf-8")
            logger.info("Character profile written to %s", output_path)

        else:
            logger.info(profile)

        logger.info(
            "✅ Character '%s' created from '%s' archetype",
            character_name,
            archetype_slug,
        )

    except ValueError as e:
        handle_cli_exception(logger, f"Archetype error: {e}", e, debug=debug)
    except RuntimeError as e:
        handle_cli_exception(logger, f"Generation failed: {e}", e, debug=debug)
    except Exception as e:
        handle_cli_exception(logger, f"Failed to convert archetype: {e}", e, debug=debug)
