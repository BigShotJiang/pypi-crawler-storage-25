"""Checkpoint CLI commands for human-in-the-loop management."""

import json
import sys
from pathlib import Path

import click

from core.checkpoints.scheduler import create_checkpoint_schedule
from services.checkpoint_service import CheckpointService


def get_handler(project_name: str):
    """Get CheckpointFileHandler for project (backwards-compat shim)."""
    from core.checkpoints.file_handler import CheckpointFileHandler

    svc = CheckpointService()
    return CheckpointFileHandler(svc.get_project_path(project_name), create_checkpoint_schedule())


@click.group()
def checkpoint() -> None:
    """Checkpoint management commands."""
    pass


@checkpoint.command("list")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
def list_checkpoints(project_name: str, project_dir: str) -> None:
    """List checkpoint status for project."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    try:
        result = svc.get_pending(project_name)
    except FileNotFoundError:
        click.echo(f"Error: Project '{project_name}' not found", err=True)
        sys.exit(1)

    click.echo(f"\n=== Checkpoint Status for '{project_name}' ===\n")

    if result["has_pending"] and result.get("proposal", {}).get("checkpoint_id"):
        p = result["proposal"]
        click.echo(f"✓ Pending checkpoint: {p.get('checkpoint_id')}")
        click.echo(f"  Phase: {p.get('phase')}")
        click.echo(f"  Title: {p.get('title')}")
        click.echo(f"  Confidence: {p.get('confidence')}")
        click.echo(f"  Reasoning: {p.get('reasoning')}")
        if result.get("decision", {}).get("decision_type"):
            click.echo(f"\n  Decision: {result['decision']['decision_type']}")
            click.echo(f"  Decided at: {result['decision']['timestamp']}")
        else:
            click.echo("\n  Decision: PENDING")
    else:
        click.echo("No pending checkpoints")

    try:
        history = svc.get_history(project_name)
        if history.get("decisions"):
            click.echo(f"\n=== Decision History ({len(history['decisions'])} decisions) ===")
            for h in history["decisions"][-5:]:
                click.echo(
                    f"  [{h.get('checkpoint_id')}] {h.get('decision_type')} at {h.get('timestamp')}"
                )
    except Exception:
        pass


@checkpoint.command("show")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option(
    "--format", "output_format", type=click.Choice(["text", "json", "yaml"]), default="text"
)
def show_checkpoint(project_name: str, project_dir: str, output_format: str) -> None:
    """Show current checkpoint proposal."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    try:
        proposal = svc.get_proposal(project_name)
    except FileNotFoundError:
        click.echo("No pending checkpoint proposal found")
        return

    if output_format == "json":
        click.echo(json.dumps(proposal, indent=2, default=str))
    elif output_format == "yaml":
        handler = CheckpointService()._handler(project_name)

        handler.export_to_yaml(proposal, Path("/dev/stdout"))
    else:
        click.echo(f"\n=== Checkpoint Proposal: {proposal.get('checkpoint_id')} ===\n")
        click.echo(f"Phase: {proposal.get('phase')}")
        click.echo(f"Title: {proposal.get('plan', {}).get('title')}")
        click.echo(f"Confidence: {proposal.get('confidence')}")
        click.echo(f"Reasoning: {proposal.get('reasoning')}")


@checkpoint.command("approve")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def approve_checkpoint(project_name: str, project_dir: str, yes: bool) -> None:
    """Approve current checkpoint proposal."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    try:
        proposal = svc.get_proposal(project_name)
    except FileNotFoundError:
        click.echo("No pending checkpoint proposal found")
        return

    if not yes:
        click.echo(f"Approve checkpoint '{proposal['checkpoint_id']}'?")
        if not click.confirm("Proceed?"):
            click.echo("Cancelled")
            return

    result = svc.submit_decision(project_name, "approve")
    click.echo(f"✓ Approved checkpoint '{result['checkpoint_id']}'")


@checkpoint.command("modify")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--changes", "-c", multiple=True, help="Changes as key=value pairs")
@click.option("--file", "-f", type=click.Path(exists=True), help="JSON file with modifications")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def modify_checkpoint(
    project_name: str,
    project_dir: str,
    changes: tuple[str, ...],
    file: str | None,
    yes: bool,
) -> None:
    """Modify checkpoint proposal with changes."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    try:
        proposal = svc.get_proposal(project_name)
    except FileNotFoundError:
        click.echo("No pending checkpoint proposal found")
        return

    modified_content = {}
    if file:
        with open(file) as f:
            modified_content = json.load(f)
    if changes:
        for change in changes:
            if "=" in change:
                key, value = change.split("=", 1)
                modified_content[key.strip()] = value.strip()

    if not modified_content:
        click.echo("No modifications provided. Use --changes or --file")
        return

    if not yes:
        click.echo(f"Apply modifications to checkpoint '{proposal['checkpoint_id']}'?")
        if not click.confirm("Proceed?"):
            click.echo("Cancelled")
            return

    result = svc.submit_decision(project_name, "modify", modified_content=modified_content)
    click.echo(f"✓ Modified checkpoint '{result['checkpoint_id']}' with changes")


@checkpoint.command("reject")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--reason", "-r", help="Reason for rejection")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def reject_checkpoint(project_name: str, project_dir: str, reason: str, yes: bool) -> None:
    """Reject checkpoint proposal."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    try:
        proposal = svc.get_proposal(project_name)
    except FileNotFoundError:
        click.echo("No pending checkpoint proposal found")
        return

    plan_title = proposal.get("plan", {}).get("title")
    if not yes:
        click.echo(f"Reject checkpoint '{proposal['checkpoint_id']}' ({plan_title})?")
        if reason:
            click.echo(f"Reason: {reason}")
        if not click.confirm("Proceed?"):
            click.echo("Cancelled")
            return

    result = svc.submit_decision(project_name, "reject", guidance_text=reason)
    click.echo(f"✓ Rejected checkpoint '{result['checkpoint_id']}'")


@checkpoint.command("guidance")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--text", "-t", required=True, help="Guidance text")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def guidance_checkpoint(
    project_name: str,
    project_dir: str,
    text: str,
    yes: bool,
) -> None:
    """Provide guidance for checkpoint proposal."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    try:
        proposal = svc.get_proposal(project_name)
    except FileNotFoundError:
        click.echo("No pending checkpoint proposal found")
        return

    if not yes:
        click.echo(f"Provide guidance for checkpoint '{proposal['checkpoint_id']}'?")
        if not click.confirm("Proceed?"):
            click.echo("Cancelled")
            return

    result = svc.submit_decision(project_name, "guidance", guidance_text=text)
    click.echo(f"✓ Guidance submitted for checkpoint '{result['checkpoint_id']}'")


@checkpoint.command("history")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--checkpoint-id", help="Filter by checkpoint ID")
def checkpoint_history(project_name: str, project_dir: str, checkpoint_id: str | None) -> None:
    """Show checkpoint decision history."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    try:
        result = svc.get_history(project_name, checkpoint_id)
    except FileNotFoundError:
        click.echo("No decision history found")
        return

    if not result.get("decisions"):
        click.echo("No decision history found")
        return

    click.echo("\n=== Decision History ===\n")
    for i, h in enumerate(result["decisions"], 1):
        click.echo(f"{i}. [{h.get('checkpoint_id')}] {h.get('decision_type')}")
        click.echo(f"   Timestamp: {h.get('timestamp')}")
        if h.get("guidance_text"):
            click.echo(f"   Guidance: {h['guidance_text']}")
        click.echo()


@checkpoint.command("clear")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def clear_checkpoint(project_name: str, project_dir: str, yes: bool) -> None:
    """Clear pending checkpoint proposal and decision."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    if not yes:
        if not click.confirm(f"Clear checkpoint state for '{project_name}'?"):
            click.echo("Cancelled")
            return

    svc.clear(project_name)
    click.echo(f"✓ Cleared checkpoint state for '{project_name}'")


@checkpoint.command("explain")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--question", "-q", help="Question about the checkpoint proposal")
def explain_checkpoint(project_name: str, project_dir: str, question: str) -> None:
    """Ask a question about the current checkpoint proposal."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    try:
        if question:
            result = svc.get_explanation(project_name, question)
            click.echo(f"\nQ: {question}")
            click.echo(f"A: {result['answer']}")
        else:
            click.echo("\nInteractive Q&A (type 'quit' to exit)")
            while True:
                q = click.prompt("You", default="", show_default=False)
                if not q or q.lower() in ("quit", "exit", "q"):
                    break
                result = svc.get_explanation(project_name, q)
                click.echo(f"\nAI: {result['answer']}\n")
    except FileNotFoundError:
        click.echo("No pending checkpoint proposal found")


@checkpoint.command("compare")
@click.argument("project_name")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
def compare_alternatives(project_name: str, project_dir: str) -> None:
    """Compare all alternatives for the current checkpoint."""
    svc = CheckpointService()
    svc.get_project_path(project_name)

    try:
        result = svc.compare_alternatives(project_name)
    except FileNotFoundError:
        click.echo("No pending checkpoint proposal found")
        return

    click.echo("\n=== Alternative Comparison ===\n")
    click.echo(f"Recommendation: {result.get('recommendation', 'N/A')}")
    click.echo("\nConfidence Factors:")
    for f in result.get("confidence_factors", []):
        bar = "█" * int(float(f["score"].replace("%", "")) / 5)
        click.echo(f"  {f['name']:14s} {bar:20s} {f['score']}")
