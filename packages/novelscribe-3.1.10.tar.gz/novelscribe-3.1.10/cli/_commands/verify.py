"""Verification CLI commands."""

import logging
import sys
from pathlib import Path
from typing import Optional

import click

from cli._helpers.error_handling import handle_cli_exception
from core.context.continuity import ContinuityParser
from core.quality.verification_engine import VerificationConfig, VerificationEngine


@click.group()
def verify() -> None:
    """Content verification and quality assurance commands."""
    pass


@verify.command("start")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Verify specific chapter")
@click.option("--max-iterations", type=int, default=5, help="Maximum rewrite iterations")
@click.option("--allow-major", is_flag=True, help="Allow major issues to pass")
@click.option("--allow-minor", is_flag=True, help="Allow minor issues to pass")
@click.option("--stop-on-critical", is_flag=True, help="Stop only when no critical issues")
@click.option("--max-minor", type=int, default=10, help="Maximum minor issues allowed")
@click.option("--batch-size", type=int, default=10, help="Batch size for fix application")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--report-only", is_flag=True, help="Generate report without fixes")
@click.option("--no-report", is_flag=True, help="Skip verification report generation")
@click.pass_context
def start_verification(
    ctx: click.Context,
    project_name: str,
    chapter: Optional[int],
    max_iterations: int,
    allow_major: bool,
    allow_minor: bool,
    stop_on_critical: bool,
    max_minor: int,
    batch_size: int,
    project_dir: str,
    report_only: bool,
    no_report: bool,
) -> None:
    """Run verification and fix loops."""
    debug = ctx.obj.get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        if chapter:
            logger.info(f"Verifying Chapter {chapter} of '{project_name}'")
            target_path = project_path / f"chapter_{chapter:03d}"
            if not target_path.exists():
                logger.error(f"Chapter {chapter} not found")
                sys.exit(1)
        else:
            logger.info(f"Verifying project '{project_name}'")
            target_path = project_path

        config = VerificationConfig(
            max_iterations=max_iterations,
            stop_on_pass=True,
            stop_on_critical_only=stop_on_critical,
            allow_major_issues=allow_major,
            allow_minor_issues=allow_minor,
            max_minor_issues=max_minor,
            batch_size=batch_size,
            generate_report=not no_report,
            save_iteration_log=not no_report,
        )

        engine = VerificationEngine(str(target_path), config)

        if report_only:
            logger.info("Running verification (report only)...")
            report = engine.quick_verify()

            logger.info("✅ Verification Report Generated")
            logger.info(f"   Status: {report.status.value}")
            logger.info(f"   Total Issues: {report.total_issues}")
            logger.info(f"   Critical: {report.critical_count}")
            logger.info(f"   Major: {report.major_count}")
            logger.info(f"   Minor: {report.minor_count}")
            return

        logger.info("Starting verification and fix loop...")
        logger.info("Configuration:")
        logger.info(f"  Max Iterations: {max_iterations}")
        logger.info(f"  Allow Major Issues: {allow_major}")
        logger.info(f"  Allow Minor Issues: {allow_minor}")
        logger.info(f"  Stop on Critical Only: {stop_on_critical}")
        logger.info("")

        result = engine.verify_project()

        logger.info("")
        if result.passed:
            logger.info("✅ Verification PASSED")
            logger.info(f"   Iterations: {result.total_iterations}")
            logger.info(f"   Issues Remaining: {result.issues_remaining}")
            logger.info(f"   Execution Time: {result.total_execution_time:.2f}s")
        else:
            logger.info("❌ Verification FAILED")
            logger.info(f"   Status: {result.final_status.value}")
            logger.info(f"   Issues Remaining: {result.issues_remaining}")
            logger.info(f"   Critical: {result.critical_issues}")
            logger.info(f"   Major: {result.major_issues}")
            logger.info(f"   Minor: {result.minor_issues}")
            logger.info(f"   Iterations: {result.total_iterations}")

            if result.critical_issues > 0:
                logger.info(f"   ⚠️  {result.critical_issues} critical issues must be fixed")

    except Exception as e:
        handle_cli_exception(logger, f"Verification failed: {e}", e, debug=debug)


@verify.command("report")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Report on specific chapter")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--save", is_flag=True, help="Save report to file")
@click.option("--output", help="Output file path")
@click.pass_context
def generate_report(
    ctx: click.Context,
    project_name: str,
    chapter: Optional[int],
    project_dir: str,
    save: bool,
    output: Optional[str],
) -> None:
    """Generate verification report without fixes."""
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        if chapter:
            target_path = project_path / f"chapter_{chapter:03d}"
        else:
            target_path = project_path

        parser = ContinuityParser(str(target_path))
        report = parser.parse_report()

        logger.info(f"Verification Report: {project_name}")
        logger.info("=" * 60)
        logger.info(f"Status: {report.status.value}")
        logger.info(f"Total Issues: {report.total_issues}")
        logger.info(f"  Critical: {report.critical_count}")
        logger.info(f"  Major: {report.major_count}")
        logger.info(f"  Minor: {report.minor_count}")

        if report.issues:
            logger.info("")
            logger.info("Issues:")

            for i, issue in enumerate(report.issues, 1):
                logger.info(f"{i}. [{issue.severity.value.upper()}] {issue.issue_type.value}")
                logger.info(f"   {issue.description}")
                if issue.location:
                    logger.info(f"   Location: {issue.location}")
                if issue.suggestion:
                    logger.info(f"   Suggestion: {issue.suggestion}")

        if save:
            if output:
                save_path = output
            else:
                save_path = target_path / "continuity_report.md"

            saved_path = parser.save_report(report, str(save_path))
            logger.info("")
            logger.info(f"✅ Report saved to: {saved_path}")

    except FileNotFoundError:
        logger.error(f"No continuity report found for '{project_name}'")
        logger.info("Run verification first to generate a report")
        sys.exit(1)
    except Exception as e:
        handle_cli_exception(logger, f"Failed to generate report: {e}", e, debug=False)


@verify.command("fix-plan")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Fix plan for specific chapter")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.option("--save", is_flag=True, help="Save fix plan to file")
@click.option("--output", help="Output file path")
@click.option("--show-details", is_flag=True, help="Show detailed fix instructions")
@click.pass_context
def create_fix_plan(
    ctx: click.Context,
    project_name: str,
    chapter: Optional[int],
    project_dir: str,
    save: bool,
    output: Optional[str],
    show_details: bool,
) -> None:
    """Generate fix plan from continuity report."""
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        if chapter:
            target_path = project_path / f"chapter_{chapter:03d}"
        else:
            target_path = project_path

        config = VerificationConfig()
        engine = VerificationEngine(str(target_path), config)

        fix_plan = engine.get_fix_plan()

        if not fix_plan:
            logger.error(f"No continuity report found for '{project_name}'")
            logger.info("Run verification first to generate a report")
            sys.exit(1)

        logger.info(f"Fix Plan: {project_name}")
        logger.info("=" * 60)
        logger.info(f"Total Fixes: {fix_plan.total_fixes}")
        logger.info(f"  Critical: {fix_plan.critical_fixes}")
        logger.info(f"  Major: {fix_plan.major_fixes}")
        logger.info(f"  Minor: {fix_plan.minor_fixes}")
        logger.info(f"Estimated Iterations: {fix_plan.estimated_iterations}")
        logger.info("")

        if show_details:
            for i, instruction in enumerate(fix_plan.instructions, 1):
                logger.info(f"{i}. Fix {instruction.issue_id} (Priority: {instruction.priority})")
                logger.info(f"   Agent: {instruction.agent.value}")
                logger.info(f"   Severity: {instruction.severity.value}")
                logger.info(f"   Type: {instruction.issue_type.value}")
                logger.info(f"   Instructions: {instruction.instructions[:100]}...")
                logger.info("")

        if save:
            if output:
                save_path = output
            else:
                save_path = target_path / "fix_plan.md"

            saved_path = engine.save_fix_plan(str(save_path))
            logger.info(f"✅ Fix plan saved to: {saved_path}")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to generate fix plan: {e}", e, debug=False)


@verify.command("estimate")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Estimate for specific chapter")
@click.option("--project-dir", default=".novels", help="Base directory for projects")
@click.pass_context
def get_estimate(
    ctx: click.Context, project_name: str, chapter: Optional[int], project_dir: str
) -> None:
    """Get verification progress estimate."""
    logger = logging.getLogger("scribe")

    try:
        project_path = Path(project_dir) / project_name
        if chapter:
            target_path = project_path / f"chapter_{chapter:03d}"
        else:
            target_path = project_path

        config = VerificationConfig()
        engine = VerificationEngine(str(target_path), config)

        estimate = engine.get_progress_estimate()
        logger.info(estimate)

    except Exception as e:
        handle_cli_exception(logger, f"Failed to get estimate: {e}", e, debug=False)
