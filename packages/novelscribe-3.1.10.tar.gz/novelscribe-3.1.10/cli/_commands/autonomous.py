"""Autonomous mode CLI commands."""

import logging
import sys
from pathlib import Path
from typing import Optional

import click
import yaml

from cli._commands.autonomous_checkpoints import (
    delete_checkpoint,
    list_checkpoints,
    show_checkpoint,
)
from cli._commands.autonomous_status import extend_timer, show_progress, show_status
from cli._helpers.error_handling import handle_cli_exception
from core.memory.models import KBContextConfig
from core.orchestration.autonomous import AutonomousConfig, AutonomousExecutor
from core.resilience import TimeoutAction

DEFAULT_PROJECT_DIR = ".novels"
DEFAULT_CHECKPOINT_DIR = ".checkpoints"


@click.group()
def autonomous() -> None:
    """Autonomous novel generation commands."""
    pass


autonomous.add_command(list_checkpoints)
autonomous.add_command(show_checkpoint)
autonomous.add_command(delete_checkpoint)
autonomous.add_command(show_progress)
autonomous.add_command(show_status)
autonomous.add_command(extend_timer)


@autonomous.command("start")
@click.argument("project_name")
@click.option("--start-phase", default="new_novel", help="Phase to start from")
@click.option("--end-phase", default="autonomous", help="Phase to end at")
@click.option("--human-in-loop", is_flag=True, help="Enable human-in-the-loop checkpoints")
@click.option(
    "--hybrid", "hybrid_mode", is_flag=True, help="Enable hybrid mode (AI pauses at checkpoints)"
)
@click.option("--timeout", "checkpoint_timeout", type=int, help="Checkpoint timeout in seconds")
@click.option(
    "--timeout-action",
    type=click.Choice(["pause", "auto_approve", "escalate"]),
    default="pause",
    help="Action on timeout",
)
@click.option("--max-chapters", type=int, help="Maximum number of chapters to generate")
@click.option("--provider", default="openai", help="LLM provider to use")
@click.option("--resume", is_flag=True, help="Resume from latest checkpoint")
@click.option("--checkpoint-id", help="Resume from specific checkpoint ID")
@click.option("--git-commit", is_flag=True, help="Auto-commit after each phase")
@click.option("--project-dir", default=DEFAULT_PROJECT_DIR, help="Base directory for projects")
@click.option(
    "--checkpoint-dir",
    default=DEFAULT_CHECKPOINT_DIR,
    help="Directory for checkpoints",
)
@click.option(
    "--kb",
    "kb_override",
    is_flag=True,
    default=None,
    help="Enable KB template context (overrides META.yaml setting)",
)
@click.option(
    "--no-kb",
    "no_kb_override",
    is_flag=True,
    default=None,
    help="Disable KB template context (overrides META.yaml setting)",
)
@click.option(
    "--interactive-revision",
    is_flag=True,
    help="Enable interactive revision after eligible phases",
)
@click.option(
    "--revision-interval",
    type=int,
    default=0,
    help="Chapter interval for revision during writing phase (0 = first chapter only)",
)
@click.pass_context
def start_autonomous(
    ctx: click.Context,
    project_name: str,
    start_phase: str,
    end_phase: str,
    human_in_loop: bool,
    hybrid_mode: bool,
    checkpoint_timeout: Optional[int],
    timeout_action: str,
    max_chapters: Optional[int],
    provider: str,
    resume: bool,
    checkpoint_id: Optional[str],
    git_commit: bool,
    project_dir: str,
    checkpoint_dir: str,
    kb_override: Optional[bool],
    no_kb_override: Optional[bool],
    interactive_revision: bool,
    revision_interval: int,
) -> None:
    """Run autonomous novel generation pipeline."""
    debug = (ctx.obj or {}).get("debug", False)
    logger = logging.getLogger("scribe")

    try:
        if resume:
            logger.info(f"Resuming autonomous pipeline for: {project_name}")
        else:
            logger.info(f"Starting autonomous pipeline for: {project_name}")

        project_path = Path(project_dir) / project_name
        if not project_path.exists() and not resume:
            logger.error(f"Project '{project_name}' not found")
            logger.info(f"Create it first with: scribe new {project_name}")
            sys.exit(1)

        if kb_override is not None and no_kb_override is not None:
            logger.error("Cannot use both --kb and --no-kb at the same time")
            sys.exit(1)

        meta_yaml_path = project_path / "META.yaml"
        meta = {}
        if meta_yaml_path.exists():
            try:
                raw = meta_yaml_path.read_text()
                if raw and isinstance(raw, str):
                    meta = yaml.safe_load(raw) or {}
            except Exception:
                meta = {}
        kb_cfg = KBContextConfig.from_meta(meta)

        project_genre = meta.get("genre") or meta.get("type") or None
        project_lang = meta.get("language") or None

        if kb_override is True:
            kb_cfg.enabled = True
        elif no_kb_override is True:
            kb_cfg.enabled = False

        config = AutonomousConfig(
            project_name=project_name,
            start_phase=start_phase,
            end_phase=end_phase,
            human_in_loop=human_in_loop,
            max_chapters=max_chapters,
            provider=provider,
            hybrid_mode=hybrid_mode,
            checkpoint_timeout=checkpoint_timeout,
            timeout_action=TimeoutAction(timeout_action),
            kb_context=kb_cfg,
            project_genre=project_genre,
            project_lang=project_lang,
            interactive_revision=interactive_revision,
            revision_interval=revision_interval,
        )

        executor = AutonomousExecutor(config=config, storage_path=Path(project_dir))

        logger.info("Configuration:")
        logger.info(f"  Start Phase: {start_phase}")
        logger.info(f"  End Phase: {end_phase}")
        logger.info(f"  Human-in-Loop: {human_in_loop}")
        if max_chapters:
            logger.info(f"  Max Chapters: {max_chapters}")
        logger.info(f"  Provider: {provider}")
        logger.info(f"  KB Context: {kb_cfg.enabled} (kinds: {list(kb_cfg.to_kinds())})")
        logger.info(f"  Git Commits: {git_commit}")
        if interactive_revision:
            logger.info(f"  Interactive Revision: enabled (interval: {revision_interval})")
        logger.info("")

        result = executor.execute(resume=resume)

        if result.success:
            logger.info("\u2705 Autonomous pipeline completed successfully!")
            logger.info(f"   Project: {project_name}")
            logger.info(f"   Completed Phases: {len(result.completed_phases)}")

            if result.completed_phases:
                logger.info(f"   Phases: {', '.join(result.completed_phases)}")
        else:
            logger.error("\u274c Autonomous pipeline failed")
            logger.error(f"   Status: {result.final_status.value}")
            if result.error:
                logger.error(f"   Error: {result.error}")
            logger.info(f"   Completed Phases: {len(result.completed_phases)}")
            logger.info("   Use 'scribe autonomous start --resume' to continue from checkpoint")
            sys.exit(1)

    except Exception as e:
        handle_cli_exception(logger, f"Autonomous pipeline error: {e}", e, debug=debug)
