"""Draft management CLI commands."""

import logging
import sys
from typing import Optional

import click

from core.chapters import ChapterRegenerator, RegenerationConfig, RegenerationStrategy
from core.checkpoints.rollback import RollbackManager
from core.drafts import DraftManager
from core.version_comparator import VersionComparator
from services.draft_service import DraftService

__all__ = [
    "drafts",
    "DraftManager",
    "RollbackManager",
    "VersionComparator",
    "ChapterRegenerator",
    "RegenerationConfig",
    "RegenerationStrategy",
]


@click.group()
def drafts() -> None:
    """Draft version management and regeneration commands."""
    pass


@drafts.command("regenerate")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True)
@click.option(
    "--strategy", type=click.Choice(["full", "targeted", "continuity", "style"]), default="full"
)
@click.option("--preserve-dialogue", is_flag=True, default=True)
@click.option("--preserve-action", is_flag=True, default=True)
@click.option("--fix-issues", multiple=True)
@click.option("--style-target")
@click.option("--max-words", type=int)
@click.option("--reason", default="regeneration")
@click.option("--project-dir", default=".novels")
@click.pass_context
def regenerate_chapter(
    ctx: click.Context,
    project_name: str,
    chapter: int,
    strategy: str,
    preserve_dialogue: bool,
    preserve_action: bool,
    fix_issues: tuple,
    style_target: Optional[str],
    max_words: Optional[int],
    reason: str,
    project_dir: str,
) -> None:
    """Regenerate a chapter with specified strategy."""
    logger = logging.getLogger("scribe")

    try:
        svc = DraftService()
        result = svc.regenerate_chapter(
            project_name,
            chapter,
            strategy=strategy,
            preserve_dialogue=preserve_dialogue,
            preserve_action=preserve_action,
            fix_issues=list(fix_issues),
            style_target=style_target,
            max_words=max_words,
            reason=reason,
        )

        if result["success"]:
            logger.info(f"✅ Chapter {chapter} regenerated successfully")
            logger.info(f"   New version: {result['new_version']}")
            logger.info(f"   Words changed: {result['words_changed']:+d}")
            logger.info(f"   Similarity: {result['content_similarity']:.2%}")
            logger.info(f"   Quality score: {result['quality_score']:.2f}")
            if result.get("issues_resolved"):
                logger.info(f"   Issues fixed: {', '.join(result['issues_resolved'])}")
        else:
            logger.error("❌ Regeneration failed")
            if result.get("new_issues"):
                for issue in result["new_issues"]:
                    logger.error(f"   - {issue}")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Regeneration error: {e}")
        sys.exit(1)


@drafts.command("list")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Filter by chapter number")
@click.option("--project-dir", default=".novels")
@click.pass_context
def list_drafts(
    ctx: click.Context, project_name: str, chapter: Optional[int], project_dir: str
) -> None:
    """List draft versions."""
    logger = logging.getLogger("scribe")

    try:
        svc = DraftService()
        if chapter:
            versions = svc.list_versions(project_name, chapter)
            if not versions.get("versions"):
                logger.info(f"No versions found for chapter {chapter}")
                return
            logger.info(f"Draft versions for Chapter {chapter}:")
            logger.info("")
            for v in versions["versions"]:
                status_symbol = "✓" if v["status"] == "active" else "a"
                logger.info(f"  v{v['version']:03d} [{status_symbol}] {v.get('reason', 'draft')}")
                logger.info(
                    f"    Words: {v['word_count']} | Quality: {v.get('quality_score') or 'N/A'}"
                )
                logger.info(f"    Created: {v['timestamp'][:16]}")
                logger.info("")
        else:
            summary = svc.list_drafts(project_name)
            logger.info(f"Draft summary for '{project_name}':")
            logger.info(f"  Total chapters: {summary.get('total_chapters', 0)}")
            logger.info(f"  Total drafts: {summary.get('total_drafts', 0)}")
            logger.info(f"  Total words: {summary.get('total_words', 0)}")
            logger.info("")

    except Exception as e:
        logger.error(f"Failed to list drafts: {e}")
        sys.exit(1)


@drafts.command("show")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True)
@click.option("--version", "-v", type=int)
@click.option("--project-dir", default=".novels")
@click.pass_context
def show_draft(
    ctx: click.Context, project_name: str, chapter: int, version: Optional[int], project_dir: str
) -> None:
    """Show draft details."""
    logger = logging.getLogger("scribe")

    try:
        svc = DraftService()
        if version:
            version_info = svc.get_version(project_name, chapter, version)
            version_val = version_info["version"]["version"]
            content = version_info.get("content", "")
        else:
            draft_info = svc.get_draft(project_name, chapter)
            version_val = draft_info.get("current_version", 0)
            content = draft_info.get("content", "")

        logger.info(f"Draft: Chapter {chapter}, Version {version_val}")
        logger.info("=" * 60)
        logger.info("Content preview:")
        logger.info(content[:500] + "..." if len(content) > 500 else content)

    except Exception as e:
        logger.error(f"Failed to show draft: {e}")
        sys.exit(1)


@drafts.command("compare")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True)
@click.option("--from", "from_version", type=int, required=True)
@click.option("--to", "to_version", type=int, required=True)
@click.option("--project-dir", default=".novels")
@click.pass_context
def compare_versions(
    ctx: click.Context,
    project_name: str,
    chapter: int,
    from_version: int,
    to_version: int,
    project_dir: str,
) -> None:
    """Compare two draft versions."""
    logger = logging.getLogger("scribe")

    try:
        svc = DraftService()
        report = svc.compare_versions(project_name, chapter, from_version, to_version)
        logger.info(f"Version comparison for Chapter {chapter}")
        logger.info("=" * 60)
        logger.info(report["summary"])
        if report.get("recommendations"):
            logger.info("Recommendations:")
            for rec in report["recommendations"]:
                logger.info(f"  - {rec}")
        logger.info(f"\nQuality impact: {report.get('quality_impact', 'N/A')}")

    except Exception as e:
        logger.error(f"Comparison failed: {e}")
        sys.exit(1)


@drafts.command("rollback")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True)
@click.option("--to-version", type=int, required=True)
@click.option("--create-backup", is_flag=True, default=True)
@click.option("--force", is_flag=True)
@click.option("--project-dir", default=".novels")
@click.pass_context
def rollback_version(
    ctx: click.Context,
    project_name: str,
    chapter: int,
    to_version: int,
    create_backup: bool,
    force: bool,
    project_dir: str,
) -> None:
    """Rollback to a previous version."""
    logger = logging.getLogger("scribe")

    try:
        svc = DraftService()
        result = svc.rollback(project_name, chapter, to_version, create_backup, force)

        if result["success"]:
            logger.info("✅ Rollback successful")
            logger.info(
                f"   Chapter {chapter}: v{result['from_version']} → v{result['to_version']}"
            )
            if result.get("backup_created"):
                logger.info(f"   Backup created: {result['backup_path']}")
        else:
            logger.error("❌ Rollback failed")
            if result.get("error_message"):
                logger.error(f"   {result['error_message']}")
            sys.exit(1)

    except Exception as e:
        logger.error(f"Rollback error: {e}")
        sys.exit(1)


@drafts.command("archive")
@click.argument("project_name")
@click.option("--chapter", "-c", type=int)
@click.option("--keep-recent", type=int, default=5)
@click.option("--project-dir", default=".novels")
@click.pass_context
def archive_drafts(
    ctx: click.Context,
    project_name: str,
    chapter: Optional[int],
    keep_recent: int,
    project_dir: str,
) -> None:
    """Archive old draft versions."""
    logger = logging.getLogger("scribe")

    try:
        svc = DraftService()
        result = svc.archive_versions(project_name, chapter, keep_recent)
        logger.info(f"✅ Archived {result['archived_count']} old versions")

    except Exception as e:
        logger.error(f"Archive failed: {e}")
        sys.exit(1)
