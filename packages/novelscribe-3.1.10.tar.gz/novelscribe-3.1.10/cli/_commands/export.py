"""CLI commands for manuscript export — compile and render to PDF, EPUB, DOCX, or Markdown."""

import logging
import sys
from pathlib import Path
from typing import Optional

import click

from cli._helpers.error_handling import handle_cli_exception

logger = logging.getLogger("scribe")


@click.group()
@click.pass_context
def export(ctx: click.Context) -> None:
    """Export manuscript to various formats."""
    pass


@export.command()
@click.argument("project_name")
@click.option(
    "--format",
    "-f",
    "fmt",
    type=click.Choice(["pdf", "epub", "docx", "md"]),
    default="pdf",
    help="Output format (default: pdf).",
)
@click.option("--output-dir", "-o", type=click.Path(), help="Destination directory.")
@click.option("--cover", type=click.Path(exists=True), help="Cover image path.")
@click.option(
    "--appendices", is_flag=True, help="Include character list, world glossary, and summaries."
)
@click.pass_context
def manuscript(
    ctx: click.Context,
    project_name: str,
    fmt: str,
    output_dir: Optional[str],
    cover: Optional[str],
    appendices: bool,
) -> None:
    """Export a novel project to the specified format."""
    from core.exporter.exporter import Exporter

    try:
        novels_dir = Path(".novels")
        project_path = novels_dir / project_name
        if not project_path.exists():
            logger.error(f"Project '{project_name}' not found")
            sys.exit(1)

        exporter = Exporter(novels_dir=novels_dir)
        result = exporter.export(
            project_name,
            fmt=fmt,
            output_dir=Path(output_dir) if output_dir else None,
            cover_image=Path(cover) if cover else None,
            include_appendices=appendices,
        )

        logger.info(f"✅ Exported '{project_name}' to {result.output_path}")
        logger.info(f"   Format: {fmt}")
        logger.info(f"   Chapters: {result.manuscript.chapter_count}")
        logger.info(f"   Words: {result.manuscript.total_word_count:,}")
        logger.info(f"   Size: {result.file_size_bytes:,} bytes")

    except ValueError as e:
        logger.error(str(e))
        sys.exit(1)
    except Exception as e:
        debug = ctx.obj.get("debug", False) if ctx.obj else False
        handle_cli_exception(logger, f"Export failed: {e}", e, debug=debug)


@export.command("formats")
def list_formats() -> None:
    """List available export formats."""
    from core.exporter.exporter import Exporter

    formats = Exporter.available_formats()
    click.echo("Available export formats:")
    for f in formats:
        click.echo(f"  • {f}")
