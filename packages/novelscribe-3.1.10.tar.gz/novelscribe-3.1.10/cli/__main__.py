"""Allow running cli as a module: python -m cli"""

from cli._entry import main

if __name__ == "__main__":
    main()
