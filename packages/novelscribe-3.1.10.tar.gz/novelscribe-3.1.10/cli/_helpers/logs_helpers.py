"""Helper utilities for logs CLI commands."""

from __future__ import annotations

import sqlite3
from datetime import datetime
from typing import Any


def fetch_recent_requests(log: Any, project: str | None, limit: int) -> list[dict[str, Any]]:
    """Fetch recent request rows from sqlite and normalize to dict payloads."""
    conn = sqlite3.connect(log.db_logger.db_path)
    cursor = conn.cursor()

    if project:
        cursor.execute(
            """
            SELECT
                request_id, timestamp, project_name, agent_name,
                provider, model, total_tokens, cost_usd, latency_ms,
                status, error_message
            FROM llm_requests
            WHERE project_name = ?
            ORDER BY timestamp DESC
            LIMIT ?
            """,
            [project, limit],
        )
    else:
        cursor.execute(
            """
            SELECT
                request_id, timestamp, project_name, agent_name,
                provider, model, total_tokens, cost_usd, latency_ms,
                status, error_message
            FROM llm_requests
            ORDER BY timestamp DESC
            LIMIT ?
            """,
            [limit],
        )

    rows = cursor.fetchall()
    conn.close()
    return [
        {
            "request_id": row[0],
            "timestamp": row[1],
            "project": row[2],
            "agent": row[3],
            "provider": row[4],
            "model": row[5],
            "total_tokens": row[6],
            "cost_usd": row[7],
            "latency_ms": row[8],
            "status": row[9],
            "error": row[10],
        }
        for row in rows
    ]


def render_timestamp(value: str | Any) -> str | Any:
    """Render ISO timestamp to a concise human-readable format when possible."""
    if isinstance(value, str):
        try:
            dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return dt.strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            return value
    return value


def fetch_export_rows(
    log: Any, period: str, project: str | None
) -> tuple[list[sqlite3.Row], list[str | int]]:
    """Fetch export rows and SQL parameters from sqlite."""
    conn = sqlite3.connect(log.db_logger.db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    if period == "all":
        date_filter = "1=1"
    else:
        days = int(period[:-1]) if period.endswith("d") else 30
        date_filter = f"timestamp > datetime('now', '-{days} days')"

    if project:
        where = f"{date_filter} AND project_name = ?"
        params: list[str | int] = [project]
    else:
        where = date_filter
        params = []

    cursor.execute(
        f"""
        SELECT
            request_id, timestamp, project_name, agent_name,
            provider, model, input_tokens, output_tokens, total_tokens,
            cost_usd, latency_ms, status, error_message, cache_hit
        FROM llm_requests
        WHERE {where}
        ORDER BY timestamp DESC
    """,
        params,
    )
    rows = cursor.fetchall()
    conn.close()
    return rows, params
