"""
Performance CLI Display Helpers for Novel Generation System

Contains display/formatting functions used by CLI commands.
These are separated for testability and reuse.
"""

from typing import Any, Dict, List

import click


def display_profile_report(report) -> None:
    """Display profile report in text format.

    Args:
        report: PerformanceReport object
    """
    click.echo("\n" + "=" * 60)
    click.echo("PERFORMANCE PROFILE REPORT")
    click.echo("=" * 60)
    click.echo(f"\nTotal Duration: {report.total_duration:.2f}s")
    click.echo("\nSummary:")
    display_summary(report.summary)

    if report.bottlenecks:
        click.echo("\nBottlenecks (>5s):")
        for bottleneck in report.bottlenecks:
            click.echo(f"  - {bottleneck}")
    else:
        click.echo("\nNo bottlenecks identified (all operations <5s)")

    click.echo("\n" + "=" * 60)


def display_summary(summary: Dict[str, Any]) -> None:
    """Display summary dict, handling nested dicts.

    Args:
        summary: Summary dictionary from report
    """
    for key, value in summary.items():
        if isinstance(value, dict):
            click.echo(f"  {key}:")
            for k, v in value.items():
                click.echo(f"    {k}: {v}")
        else:
            click.echo(f"  {key}: {value}")


def format_bottlenecks_list(bottlenecks: List[str], threshold: float) -> List[str]:
    """Format bottlenecks list for display.

    Args:
        bottlenecks: List of bottleneck strings
        threshold: Threshold value used

    Returns:
        Formatted list of strings
    """
    return bottlenecks


def parse_file_size(file_size: str) -> int:
    """Parse file size string to bytes.

    Args:
        file_size: Size string like "1M", "500K", "1G", or plain number

    Returns:
        Size in bytes
    """
    size_map = {"K": 1024, "M": 1024 * 1024, "G": 1024 * 1024 * 1024}
    if file_size and file_size[-1].upper() in size_map:
        multiplier = size_map[file_size[-1].upper()]
        size = int(file_size[:-1]) * multiplier
    else:
        size = int(file_size)
    return size


def display_file_stats(result: Dict[str, Any]) -> None:
    """Display file stats result.

    Args:
        result: Dict from get_file_stats()
    """
    stats = result["stats"]
    cache_info = result["cache_info"]
    write_cache_info = result["write_cache_info"]

    click.echo("\n" + "=" * 60)
    click.echo("FILE I/O STATISTICS")
    click.echo("=" * 60)

    click.echo("\nI/O Operations:")
    for key, value in stats.to_dict().items():
        click.echo(f"  {key}: {value}")

    click.echo("\nRead Cache:")
    display_cache_info(cache_info)

    click.echo("\nWrite Cache:")
    for key, value in write_cache_info.items():
        click.echo(f"  {key}: {value}")

    click.echo("\n" + "=" * 60)


def display_cache_info(cache_info: Dict[str, Any]) -> None:
    """Display cache info dict.

    Args:
        cache_info: Cache info dictionary
    """
    for key, value in cache_info.items():
        if key == "most_accessed" and value:
            click.echo(f"  {key}:")
            for path, count in value:
                click.echo(f"    - {path}: {count} hits")
        else:
            click.echo(f"  {key}: {value}")


def display_llm_stats(result: Dict[str, Any]) -> None:
    """Display LLM stats result.

    Args:
        result: Dict from get_llm_stats()
    """
    import time as _time

    stats = result["stats"]
    cache_info = result["cache_info"]
    rate_info = result["rate_info"]

    click.echo("\n" + "=" * 60)
    click.echo("LLM OPTIMIZATION STATISTICS")
    click.echo("=" * 60)

    click.echo("\nCall Statistics:")
    for key, value in stats.to_dict().items():
        click.echo(f"  {key}: {value}")

    click.echo("\nCache Information:")
    for key, value in cache_info.items():
        if key in ("oldest_entry", "newest_entry") and value:
            click.echo(f"  {key}: {_time.strftime('%Y-%m-%d %H:%M:%S', _time.localtime(value))}")
        else:
            click.echo(f"  {key}: {value}")

    if rate_info:
        click.echo("\nRate Limits:")
        for provider, info in rate_info.items():
            click.echo(f"  {provider}: {info['available']}/{info['max']} available")

    click.echo("\n" + "=" * 60)
