"""Shared plain-text output helpers for CLI commands."""

from __future__ import annotations

from collections.abc import Iterable

import click


def print_section(title: str, width: int = 60) -> None:
    """Print a standard section header."""
    click.echo(f"\n{title}")
    click.echo("=" * width)


def print_kv(key: str, value: object) -> None:
    """Print a key-value line with consistent alignment."""
    click.echo(f"{key:16}: {value}")


def print_list(items: Iterable[str], prefix: str = "- ") -> None:
    """Print a list using a consistent prefix."""
    for item in items:
        click.echo(f"{prefix}{item}")
