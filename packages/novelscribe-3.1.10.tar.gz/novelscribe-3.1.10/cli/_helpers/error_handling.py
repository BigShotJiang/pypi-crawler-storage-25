"""Shared error handling helpers for CLI command callbacks."""

from logging import Logger


def handle_cli_exception(
    logger: Logger,
    message: str,
    error: Exception,
    *,
    debug: bool = False,
    exit_code: int = 1,
) -> None:
    """Log CLI exception details with optional debug stack trace and exit.

    Args:
        logger: Logger to emit structured CLI messages.
        message: User-facing error message.
        error: The underlying exception instance.
        debug: Whether to emit full traceback for diagnostics.
        exit_code: Exit code used to terminate the command.
    """
    logger.error(message)
    if debug:
        logger.exception("Full error trace:")
    raise SystemExit(exit_code) from error
