"""CLI _memory subpackage."""
