"""CLI package — entry point is cli.main, registered as 'scribe' console script."""

from cli._entry import ScribeCLI, cli, configure_logging, main

__all__ = ["main", "cli", "configure_logging", "ScribeCLI"]
