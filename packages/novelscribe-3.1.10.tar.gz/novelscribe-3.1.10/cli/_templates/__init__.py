"""CLI _templates subpackage."""
