---
page_id: "template.character_blueprint.en.harry-potter-6c714011"
type: template
template_id: "character_blueprint:6c714011-7fb2-40a7-86df-d37657927824"
template_kind: "character_blueprint"
title: "Harry Potter"
language_code: "en"
tags: [template, character_blueprint, en, harry, potter]
---

# Harry Potter

## Summary
Harry Potter - The Chosen One

---
# 1. Core Drives
- Motivation: Protect the vulnerable and prove he deserves the love that saved him; resist tyrannical control in any form.
- External Goal: Survive, uncover the truth behind Voldemort’s return, locate/destroy Horcruxes, and end the war.
- Internal Desire: Belonging and family without strings; to be seen as himself rather than a legend or pawn.
- Deepest Fear: Becoming what he fights (power corrupting him, hurting loved ones); being abandoned or rendered useless when others need him.
- Epiphany: Love’s power is not passive sentiment but chosen self-sacrifice. Acceptance of death restores agency and breaks power’s spell; he chooses moral identity over mastery (Horcruxes over Hallows; mercy over killing).

# 2. Conflict Structure
- Internal Conflict:
  - Autonomy vs trust: reflex to act alone vs the need to rely on others.
  - Anger and grief vs compassion: traumatic losses feed rage, yet his core value is mercy.
  - Destiny vs choice: pressure of prophecy collides with his insistence on self-defined action.
- External Conflict:
  - Antagonist: Voldemort’s ideology of domination and immortality at any cost.
  - Institutions: The Ministry’s denial/projection; media manipulation; school politics and prejudice.
  - Environment: Dursleys’ neglect, social isolation, and the dangerous magical world.
- Moral Conflict:
  - Ends vs means: Rule-breaking for good; occasional use of Unforgivable Curses under duress.
  - Mercy vs retribution: Sparing enemies (Pettigrew, Draco) despite personal grievances.
  - Truth vs safety: Exposing uncomfortable facts that make life harder but align with conscience.

# 3. Backstory
- Formative Experiences:
  - Early neglect and emotional deprivation with the Dursleys; chronic invisibility and ridicule.
  - Sudden elevation to fame in a new culture; pressure of expectations and the myth of “the Boy Who Lived.”
  - Intimate encounters with death from a young age; recurrent near-fatal trials.
- Trauma:
  - Parental murder; invalidation by caregivers; witnessing Cedric’s death; loss of Sirius and Dumbledore.
  - Possession/intrusion by Voldemort; systemic disbelief and smear campaigns.
- Hidden Motivations:
  - Unconscious drive to “earn” his mother’s sacrifice by being indispensable.
  - Averse reaction to adult control rooted in childhood powerlessness; compulsion to intervene.
- Growth Arc:
  - Wonder to disillusionment to principled leadership.
  - Moves from reactive heroism to deliberate self-sacrifice; learns to prioritize mission over glory.
  - Integrates anger and grief into protective courage; chooses trust selectively but meaningfully.

# 4. Worldview & Values
- Worldview: Institutions are unreliable; individuals matter. Evil thrives in apathy and fear; courage is a communal act.
- Life Philosophy: Do what is right, even when it isolates you. Love is an action that may cost everything but redeems meaning.
- Moral Code:
  - Avoid lethal force when possible; default to disarming and protection.
  - Loyalty to friends and the marginalized; intolerance of bullying and cruelty.
  - Rule-breaking is justified when rules protect injustice.

# 5. Voice & Style
- Tone: Plainspoken, dryly humorous, modest; spikes into sharp sarcasm under stress.
- Dialect: British idiom; informal, unpretentious word choice; emotionally restrained until prodded.
- Speech Patterns:
  - Direct questions, short declaratives; resists grand speeches.
  - Deflects praise; expresses fairness/indignation (“that’s not right”).
  - Anger outbursts when stonewalled; otherwise concise and pragmatic.

# 6. Narrative Alignment
- Consistency:
  - Protective instincts and rule-breaking for ethical causes persist throughout.
  - Pattern of anger after traumatic events leads to isolation, then reconnection through purpose.
  - Combat pragmatism contrasts with mediocre academic conformity; excels under pressure and in applied defense.
  - Valorizes mercy yet will escalate when loved ones are threatened—consistent with a protector schema.
- Reasonable Inference:
  - Attachment injury from neglect → hypervigilance, discomfort with authority, “do-it-alone” bias.
  - Survivor’s guilt fuels need to be useful and self-sacrificing.
  - Identity work: resisting both villain’s narrative (power) and society’s (celebrity), crafting a third path (choice-based worth).

# 7. Basic Info
- Archetype: The Chosen One; Orphan Hero; Reluctant Leader; Sacrificial Protector.
- Role in Story: Protagonist and moral fulcrum; embodied counter-argument to Voldemort’s ideology.
- Core Identity: Protector who chooses love over power; a seeker of belonging who defines himself by choices, not destiny.
- Personality:
  - Strengths: Courage, loyalty, empathy, quick tactical adaptation, moral clarity under pressure.
  - Flaws: Impulsivity, secrecy, anger regulation issues, savior complex, suspicion of authority.
- Relationships:
  - Found family (Ron/Hermione) grounds his judgment; mentors (Dumbledore, Lupin, Sirius) shape his ethical frame, with betrayal/omission scars.
  - Antagonistic mirrors (Voldemort, Draco, Snape) sharpen themes of choice, class, and resentment.
  - Romantic bond (Ginny) provides equal partnership and normalcy, countering martyrdom.
- Symbolic Function:
  - Scar as living wound and covenant of love; stag Patronus as legacy and protection.
  - Persistent use of Expelliarmus signals moral stance: power restrained by principle.
  - Deathly Hallows conflict dramatizes mastery vs acceptance; he chooses acceptance.

# 8. Meta Analysis: Suggestions for Improvement
If adapting or refining a similar character in your own work:
- Deepen Costs of Virtue:
  - Track specific, escalating consequences of his “protect at all costs” ethic (missed cues, broken trust, collateral risk) to avoid unearned heroism.
- Calibrate Competence:
  - Differentiate instinctive combat skill from academic or strategic planning; show learning curve and failures that force collaboration.
- Make Trust a Dynamic Axis:
  - Create set-piece decisions where trusting others demonstrably improves outcomes; contrast with moments where secrecy backfires.
- Integrate Trauma, Don’t Just Trigger It:
  - Use sensory intrusions, avoidance behaviors, and meaning-making rituals to show trauma processing, not only anger spikes.
- Moral Ambiguity with Guardrails:
  - Present scenarios where every option compromises a value (e.g., mercy endangers many; ruthlessness prevents harm). Let him articulate why he chooses the harder path.
- Symbol-Action Echo:
  - Tie choices to motifs (scar pain, Patronus, disarming spell) so moral decisions resonate beyond plot beats.
- Relationship-Based Change:
  - Leverage disagreements with allies as catalysts for growth (negotiating leadership, admitting fear), then show repaired trust through action.
- Specific Behavioral Tells:
  - Small, consistent habits from deprivation (hoarding food, hyper-attentive to others’ discomfort) will concretize his backstory in scene work.
- Avoid Destiny Shortcuts:
  - When prophecy or chosen-one logic pushes him forward, ensure personal reasons drive the same choice; prophecy aligns with identity rather than replaces it.

This profile emphasizes Harry’s narrative function as a moral counterpoint to power-worship, his psychology as an attachment-injured protector, and the structural levers that keep his arc coherent and emotionally resonant.
