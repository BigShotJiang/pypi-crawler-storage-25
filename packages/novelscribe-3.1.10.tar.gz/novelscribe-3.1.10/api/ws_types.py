"""
WebSocket Data Types for Real-time Updates

Contains event types, connection models, and event structures
used by the WebSocket manager for real-time communication.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional, Set

from fastapi import WebSocket


class EventType(str, Enum):
    """Event types for real-time updates"""

    LOG = "log"
    PROGRESS = "progress"
    STATUS_CHANGE = "status_change"
    EXECUTION_START = "execution_start"
    EXECUTION_COMPLETE = "execution_complete"
    EXECUTION_ERROR = "execution_error"
    CHAPTER_COMPLETE = "chapter_complete"
    HEARTBEAT = "heartbeat"
    SYSTEM_STATUS = "system_status"
    STREAM_CHUNK = "stream_chunk"
    CHECKPOINT = "checkpoint"


@dataclass
class WSConnection:
    """Represents a WebSocket connection"""

    client_id: str
    websocket: WebSocket
    project_name: Optional[str] = None
    connected_at: datetime = field(default_factory=datetime.now)
    last_ping: datetime = field(default_factory=datetime.now)
    subscribed_events: Set[EventType] = field(default_factory=lambda: set(EventType))
    metadata: Dict[str, Any] = field(default_factory=dict)

    async def send_json(self, data: Dict[str, Any]) -> None:
        """Send JSON data to client"""
        try:
            await self.websocket.send_json(data)
        except Exception:
            raise

    async def send_text(self, text: str) -> None:
        """Send text data to client"""
        try:
            await self.websocket.send_text(text)
        except Exception:
            raise

    def update_ping(self) -> None:
        """Update last ping time"""
        self.last_ping = datetime.now()


@dataclass
class RealtimeEvent:
    """Real-time event structure"""

    type: EventType
    timestamp: datetime = field(default_factory=datetime.now)
    data: Dict[str, Any] = field(default_factory=dict)
    priority: str = "normal"
    source: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        return {
            "type": self.type.value,
            "timestamp": self.timestamp.isoformat(),
            "data": self.data,
            "priority": self.priority,
            "source": self.source,
        }

    def to_websocket_message(self) -> Dict[str, Any]:
        """Convert to WebSocket message format"""
        return {"type": self.type.value, "data": self.data, "timestamp": self.timestamp.isoformat()}
