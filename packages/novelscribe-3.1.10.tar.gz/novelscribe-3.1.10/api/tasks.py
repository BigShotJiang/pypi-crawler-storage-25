"""Background task manager for workflow execution.

Delegates real execution to WorkflowService while keeping thread pool
infrastructure, progress tracking, and WebSocket broadcasting.
"""

import asyncio
import threading
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from services.workflow_service import WorkflowService


class TaskStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ExecutionState:
    execution_id: str
    project_name: str
    workflow: str
    status: TaskStatus = TaskStatus.PENDING
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress: float = 0.0
    current_step: Optional[str] = None
    error: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    variables: Dict[str, Any] = field(default_factory=dict)
    logs: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "execution_id": self.execution_id,
            "project_name": self.project_name,
            "workflow": self.workflow,
            "status": self.status.value,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "progress": self.progress,
            "current_step": self.current_step,
            "error": self.error,
            "result": self.result,
            "variables": self.variables,
        }


class TaskManager:
    """Manages background workflow execution via WorkflowService.

    Keeps its own execution tracking, thread pool, and WebSocket
    broadcasting.  Delegates actual orchestration to WorkflowService
    so that CLI and API share the same execution path.
    """

    def __init__(self, max_workers: int = 5):
        self.executions: Dict[str, ExecutionState] = {}
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.lock = threading.Lock()
        self.active_futures: Dict[str, Any] = {}
        self.progress_callbacks: List[Callable[[str, float, str], None]] = []
        self._ws_loop: Optional[asyncio.AbstractEventLoop] = None
        self._async_executor = ThreadPoolExecutor(max_workers=1)
        self._workflow_service = WorkflowService()

    def add_progress_callback(self, callback: Callable[[str, float, str], None]) -> None:
        self.progress_callbacks.append(callback)

    def set_event_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        self._ws_loop = loop

    def _notify_progress(self, execution_id: str, progress: float, step: str) -> None:
        for callback in self.progress_callbacks:
            try:
                callback(execution_id, progress, step)
            except Exception:
                pass
        ws_loop = self._ws_loop
        if ws_loop is not None:
            try:
                state = self.get_execution_status(execution_id)
                if state:
                    ws_loop.call_soon_threadsafe(
                        self._broadcast_ws,
                        state.project_name,
                        state.workflow,
                        progress,
                        step,
                    )
            except Exception:
                pass

    def _broadcast_ws(self, project_name: str, workflow: str, progress: float, step: str) -> None:
        ws_loop = self._ws_loop
        if ws_loop is None:
            return
        try:
            from api.websocket_manager import EventType, RealtimeEvent, get_websocket_manager

            manager = get_websocket_manager()
            event = RealtimeEvent(
                type=EventType.PROGRESS,
                data={
                    "execution_id": "",
                    "project": project_name,
                    "workflow": workflow,
                    "progress": progress,
                    "current_step": step,
                },
                source=project_name,
            )
            asyncio.run_coroutine_threadsafe(
                manager.broadcast_to_project(project_name, event),
                ws_loop,
            )
        except Exception:
            pass

    def execute_workflow(
        self, project_name: str, workflow: str, variables: Dict[str, Any], background: bool = True
    ) -> ExecutionState:
        execution_id = str(uuid.uuid4())

        state = ExecutionState(
            execution_id=execution_id,
            project_name=project_name,
            workflow=workflow,
            variables=variables,
        )

        with self.lock:
            self.executions[execution_id] = state

        future = self.executor.submit(self._run_workflow, state)
        self.active_futures[execution_id] = future

        return state

    def _run_workflow(self, state: ExecutionState) -> None:
        try:
            with self.lock:
                state.status = TaskStatus.RUNNING
                state.started_at = datetime.now()
                state.current_step = "Initializing"
                state.progress = 0.0

            self._notify_progress(state.execution_id, 0.0, "Initializing")

            svc_result = self._workflow_service.execute_workflow_sync(
                project_name=state.project_name,
                workflow_path=f"workflows/{state.workflow}.yaml",
                variables=state.variables,
            )

            with self.lock:
                state.status = TaskStatus.COMPLETED
                state.completed_at = datetime.now()
                state.progress = 100.0
                state.current_step = "Completed"
                state.result = svc_result

            self._notify_progress(state.execution_id, 100.0, "Completed")

        except Exception as e:
            with self.lock:
                state.status = TaskStatus.FAILED
                state.completed_at = datetime.now()
                state.error = str(e)
                state.logs.append(f"Error: {str(e)}")
                state.logs.append(traceback.format_exc())

        finally:
            if state.execution_id in self.active_futures:
                del self.active_futures[state.execution_id]

    def cancel_execution(self, execution_id: str) -> bool:
        with self.lock:
            state = self.executions.get(execution_id)
            if not state:
                return False
            if state.status != TaskStatus.RUNNING:
                return False
            state.status = TaskStatus.CANCELLED
            state.completed_at = datetime.now()

        future = self.active_futures.get(execution_id)
        if future:
            future.cancel()
            del self.active_futures[execution_id]
            return True
        return False

    def get_execution_status(self, execution_id: str) -> Optional[ExecutionState]:
        with self.lock:
            return self.executions.get(execution_id)

    def get_all_executions(self, project_name: Optional[str] = None) -> List[ExecutionState]:
        with self.lock:
            executions = list(self.executions.values())
        if project_name:
            executions = [e for e in executions if e.project_name == project_name]
        return executions

    def cleanup_old_executions(self, max_age_hours: int = 24) -> int:
        cutoff = datetime.now().timestamp() - (max_age_hours * 3600)
        with self.lock:
            to_remove = []
            for exec_id, state in self.executions.items():
                if state.status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED]:
                    if state.completed_at and state.completed_at.timestamp() < cutoff:
                        to_remove.append(exec_id)
            for exec_id in to_remove:
                del self.executions[exec_id]
            return len(to_remove)

    def _run_autonomous_workflow(self, state: ExecutionState) -> None:
        self._run_workflow(state)

    def _run_write_chapter_workflow(self, state: ExecutionState) -> None:
        self._run_workflow(state)

    def _run_outline_workflow(self, state: ExecutionState) -> None:
        self._run_workflow(state)

    def _run_generic_workflow(self, state: ExecutionState) -> None:
        self._run_workflow(state)


_task_manager: Optional[TaskManager] = None


def get_task_manager() -> TaskManager:
    global _task_manager
    if _task_manager is None:
        _task_manager = TaskManager()
    return _task_manager
