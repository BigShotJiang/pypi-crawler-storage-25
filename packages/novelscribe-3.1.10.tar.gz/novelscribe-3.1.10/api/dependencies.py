"""FastAPI dependency injection helpers for shared services."""

from fastapi import HTTPException, status

from services.autonomous_service import AutonomousService
from services.checkpoint_service import CheckpointService
from services.draft_service import DraftService
from services.export_service import ExportService
from services.memory_service import MemoryService
from services.project_service import ProjectService
from services.quality_service import QualityService
from services.settings_service import SettingsService
from services.summary_service import SummaryService
from services.workflow_service import WorkflowService


def get_project_service() -> ProjectService:
    return ProjectService()


def get_workflow_service() -> WorkflowService:
    return WorkflowService()


def get_quality_service() -> QualityService:
    return QualityService()


def get_draft_service() -> DraftService:
    return DraftService()


def get_checkpoint_service() -> CheckpointService:
    return CheckpointService()


def get_autonomous_service() -> AutonomousService:
    return AutonomousService()


def get_export_service() -> ExportService:
    return ExportService()


def get_memory_service() -> MemoryService:
    return MemoryService()


def get_summary_service() -> SummaryService:
    return SummaryService()


def get_settings_service() -> SettingsService:
    return SettingsService()


def require_valid_project(
    project_name: str,
    svc: ProjectService | None = None,
) -> str:
    """Validate project name format and existence.

    Raises HTTPException on failure. Returns project_name on success.
    """
    if svc is None:
        svc = get_project_service()

    if not svc.validate_project_name(project_name):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid project name",
        )

    if not svc.project_exists(project_name):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project '{project_name}' not found",
        )

    return project_name
