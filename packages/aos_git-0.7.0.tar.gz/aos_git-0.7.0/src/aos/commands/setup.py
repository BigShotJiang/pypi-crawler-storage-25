import stat
import subprocess
import tomllib
from pathlib import Path
import click
import questionary
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box
from aos.config.settings import (
    load_config, save_config,
    AIConfig, DatabricksConfig, AnthropicConfig, OpenAIConfig, OllamaConfig, CustomConfig,
    BehaviorConfig, NotifyConfig, NotifyEmailConfig, NotifySlackConfig, NotifyTeamsConfig,
)
from aos.git_auth import normalize_url

console = Console()

NOTIFY_CONFIG_TEMPLATE = """\
# aos-git 알림 설정
# aos setup 으로 자동 생성됨

[notify]
branch = "{branch}"
recipients = {recipients}
mergers = {mergers}
"""

DEFAULT_MODELS = {
    "databricks": "databricks-claude-sonnet-4-6",
    "anthropic": "claude-sonnet-4-6",
    "openai": "gpt-4o",
    "ollama": "llama3",
    "custom": "gpt-4o",
}

_PRE_PUSH_HOOK = """\
#!/usr/bin/env bash
# aos pre-push hook — aos setup 으로 자동 생성됨
#
#   main push (릴리스 커밋 제외) → 팀 이메일 알림
#   feature 브랜치 push         → 병합 관리자 알림

set -e

while read -r local_ref local_sha remote_ref remote_sha; do

    if [[ "$remote_ref" == "refs/heads/main" ]]; then
        COMMIT_MSG="$(git log -1 --format='%s' "$local_sha")"
        if [[ "$COMMIT_MSG" =~ ^chore:\\ release\\ v ]]; then
            echo "[pre-push] 릴리스 커밋 감지 — 팀 알림 생략"
        else
            echo "[pre-push] main 브랜치 push 감지 → 팀 알림 발송 중..."
            export GITLAB_USER_NAME="$(git log -1 --format='%an' "$local_sha")"
            export CI_COMMIT_MESSAGE="$COMMIT_MSG"
            export CI_COMMIT_SHA="$(git log -1 --format='%H' "$local_sha")"
            export CI_PROJECT_URL="$(git remote get-url origin | sed 's/\\.git$//')"
            aos notify --event main-push || \\
                echo "[WARN] 팀 알림 발송 실패 — push는 계속 진행합니다"
        fi

    elif [[ "$remote_ref" == refs/heads/* ]]; then
        echo "[pre-push] 브랜치 push 감지 → 병합 관리자 알림 발송 중..."
        export BRANCH_NAME="${remote_ref#refs/heads/}"
        export GITLAB_USER_NAME="$(git log -1 --format='%an' "$local_sha")"
        export CI_COMMIT_MESSAGE="$(git log -1 --format='%s' "$local_sha")"
        export CI_COMMIT_SHA="$(git log -1 --format='%H' "$local_sha")"
        export CI_PROJECT_URL="$(git remote get-url origin | sed 's/\\.git$//')"
        aos notify --event branch-push || \\
            echo "[WARN] 병합 관리자 알림 발송 실패 — push는 계속 진행합니다"
    fi

done

exit 0
"""


def _banner():
    console.print()
    console.print(Panel(
        Text.assemble(
            ("  aos", "bold cyan"),
            ("  —  AI-powered Git Helper", "dim"),
        ),
        box=box.ROUNDED,
        border_style="cyan",
        padding=(0, 2),
    ))
    console.print()


def _section(n: int, total: int, title: str):
    console.print()
    console.rule(f"[bold cyan][{n}/{total}] {title}[/bold cyan]")
    console.print()


def _ok(msg: str):
    console.print(f"  [bold green]✓[/bold green]  {msg}")


def _find_repo_root() -> Path | None:
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        return Path(result.stdout.strip())
    return None


def _load_project_notify_config(repo_root: Path) -> dict:
    config_path = repo_root / "scripts" / "notify_config.toml"
    if config_path.exists():
        with open(config_path, "rb") as f:
            return tomllib.load(f).get("notify", {})
    return {}


def _install_git_hook(repo_root: Path) -> None:
    hook_dst = repo_root / ".git" / "hooks" / "pre-push"
    if hook_dst.exists() or hook_dst.is_symlink():
        hook_dst.unlink()
    hook_dst.write_text(_PRE_PUSH_HOOK)
    hook_dst.chmod(hook_dst.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    _ok("pre-push hook 설치됨")


def _generate_notify_config(branch: str, recipients: list[str], mergers: list[str], repo_root: Path) -> None:
    scripts_dir = repo_root / "scripts"
    scripts_dir.mkdir(exist_ok=True)
    recipients_toml = "[" + ", ".join(f'"{r}"' for r in recipients) + "]"
    mergers_toml = "[" + ", ".join(f'"{r}"' for r in mergers) + "]"
    config_path = scripts_dir / "notify_config.toml"
    config_path.write_text(
        NOTIFY_CONFIG_TEMPLATE.format(branch=branch, recipients=recipients_toml, mergers=mergers_toml)
    )
    _ok("scripts/notify_config.toml 생성됨")


def _setup_ai_section(cfg) -> None:
    provider = questionary.select(
        "AI Provider를 선택하세요",
        choices=[
            questionary.Choice("Anthropic Claude", value="anthropic"),
            questionary.Choice("OpenAI (GPT-4o 등)", value="openai"),
            questionary.Choice("Ollama (로컬, 인터넷 불필요)", value="ollama"),
            questionary.Choice("Databricks", value="databricks"),
            questionary.Choice("Custom endpoint (Azure, Groq, Together.ai …)", value="custom"),
        ],
        default=cfg.ai.provider if cfg.ai.provider else "anthropic",
    ).ask()

    default_model = DEFAULT_MODELS.get(provider, "")

    if provider == "databricks":
        host = click.prompt("  Databricks Host", default=cfg.databricks.host if cfg.databricks else "")
        token = click.prompt("  Databricks Token", hide_input=True)
        model = click.prompt("  모델 엔드포인트", default=cfg.ai.model or default_model)
        cfg.databricks = DatabricksConfig(host=host, token=token)
        cfg.ai = AIConfig(provider=provider, model=model)

    elif provider == "anthropic":
        api_key = click.prompt(
            "  Anthropic API Key", hide_input=True,
            default=cfg.anthropic.api_key if cfg.anthropic else "",
        )
        model = click.prompt("  모델", default=cfg.ai.model or default_model)
        cfg.anthropic = AnthropicConfig(api_key=api_key)
        cfg.ai = AIConfig(provider=provider, model=model)

    elif provider == "openai":
        api_key = click.prompt(
            "  OpenAI API Key", hide_input=True,
            default=cfg.openai.api_key if cfg.openai else "",
        )
        model = click.prompt("  모델", default=cfg.ai.model or default_model)
        cfg.openai = OpenAIConfig(api_key=api_key)
        cfg.ai = AIConfig(provider=provider, model=model)

    elif provider == "ollama":
        host = click.prompt("  Ollama Host", default=cfg.ollama.host if cfg.ollama else "http://localhost:11434")
        model = click.prompt("  모델명", default=cfg.ai.model or default_model)
        cfg.ollama = OllamaConfig(host=host)
        cfg.ai = AIConfig(provider=provider, model=model)

    elif provider == "custom":
        console.print("  [dim]Azure OpenAI, Groq, Together.ai 등 OpenAI-compatible 엔드포인트[/dim]")
        base_url = click.prompt("  Base URL", default=cfg.custom.base_url if cfg.custom else "")
        api_key = click.prompt("  API Key", hide_input=True, default=cfg.custom.api_key if cfg.custom else "")
        model = click.prompt("  모델명", default=cfg.ai.model or default_model)
        cfg.custom = CustomConfig(base_url=base_url, api_key=api_key)
        cfg.ai = AIConfig(provider=provider, model=model)


def _setup_notify_section(cfg) -> None:
    current_channel = cfg.notify.channel if cfg.notify.enabled else "none"

    channel = questionary.select(
        "알림 채널을 선택하세요",
        choices=[
            questionary.Choice("이메일 (SMTP)", value="email"),
            questionary.Choice("Slack", value="slack"),
            questionary.Choice("Microsoft Teams", value="teams"),
            questionary.Choice("사용 안함", value="none"),
        ],
        default=current_channel,
    ).ask()

    if channel == "none":
        cfg.notify.enabled = False
        cfg.notify.channel = "none"
        return

    cfg.notify.enabled = True
    cfg.notify.channel = channel

    if channel == "email":
        _setup_email_notify(cfg)
    elif channel == "slack":
        console.print("  [dim]Slack 앱 → Incoming Webhooks → webhook URL 복사[/dim]")
        webhook_url = click.prompt("  Slack Webhook URL", default=cfg.notify.slack.webhook_url)
        cfg.notify.slack = NotifySlackConfig(webhook_url=webhook_url)
    elif channel == "teams":
        console.print("  [dim]Teams 채널 → 커넥터 → Incoming Webhook → URL 복사[/dim]")
        webhook_url = click.prompt("  Teams Webhook URL", default=cfg.notify.teams.webhook_url)
        cfg.notify.teams = NotifyTeamsConfig(webhook_url=webhook_url)

    branch = click.prompt("  알림 기준 브랜치", default=cfg.notify.branch or "main")
    recipients_label = "  수신자 이메일 (콤마 구분)" if channel == "email" else "  수신자 목록 (참고용)"
    recipients_raw = click.prompt(
        recipients_label,
        default=", ".join(cfg.notify.recipients) if cfg.notify.recipients else "",
    )
    recipients = [r.strip() for r in recipients_raw.split(",") if r.strip()]
    mergers_raw = click.prompt(
        "  병합 관리자 (feature 브랜치 push 시 알림, 선택사항)",
        default=", ".join(cfg.notify.mergers) if cfg.notify.mergers else "",
    )
    mergers = [r.strip() for r in mergers_raw.split(",") if r.strip()]
    cfg.notify.branch = branch
    cfg.notify.recipients = recipients
    cfg.notify.mergers = mergers


def _setup_email_notify(cfg) -> None:
    console.print("  [dim]Gmail: smtp.gmail.com:587  /  Office365: smtp.office365.com:587[/dim]")
    console.print("  [dim]사내 SMTP 릴레이: 보통 인증 불필요 — username을 비워두면 로그인 생략[/dim]")
    console.print()
    host = click.prompt("  SMTP Host", default=cfg.notify.email.host or "smtp.gmail.com")
    port = click.prompt("  SMTP Port", default=cfg.notify.email.port or 587, type=int)
    username = click.prompt(
        "  발신자 이메일 (username, 사내 릴레이는 비워두세요)",
        default=cfg.notify.email.username or "",
        show_default=False,
        prompt_suffix=" (비워두면 인증 생략): ",
    )
    if username:
        console.print("  [dim]Gmail은 앱 비밀번호(계정 설정 → 보안 → 앱 비밀번호)를 사용하세요.[/dim]")
        password = click.prompt("  비밀번호", hide_input=True)
    else:
        password = ""
        _ok("인증 없이 SMTP 릴레이 사용")
    sender = click.prompt("  발신자 표시 이메일", default=username or f"aos@{host}")
    tls = click.confirm("  TLS(STARTTLS) 사용", default=bool(username))
    cfg.notify.email = NotifyEmailConfig(
        host=host, port=port, username=username,
        password=password, sender=sender, tls=tls,
    )


def _test_and_show_summary(cfg) -> None:
    from aos.ai.factory import build_adapter
    from aos.notify.factory import build_notifier

    table = Table(show_header=False, box=box.SIMPLE, padding=(0, 2))
    table.add_column(style="dim", width=10)
    table.add_column()
    table.add_column()

    try:
        build_adapter(cfg)
        ai_status = "[green]✓ 연결됨[/green]"
    except Exception as e:
        ai_status = f"[red]✗ {e}[/red]"

    table.add_row("AI", f"{cfg.ai.provider} / {cfg.ai.model}", ai_status)

    if cfg.notify.enabled:
        try:
            notifier = build_notifier(cfg)
            notify_ok = notifier.test_connection()
            notify_status = "[green]✓ 연결됨[/green]" if notify_ok else "[yellow]⚠ 연결 확인 필요[/yellow]"
        except Exception as e:
            notify_status = f"[red]✗ {e}[/red]"
        table.add_row("알림", cfg.notify.channel, notify_status)
    else:
        table.add_row("알림", "사용 안함", "")

    table.add_row("언어", cfg.behavior.language, "")

    console.print(Panel(table, border_style="green", box=box.ROUNDED, padding=(1, 1)))
    console.print("  설정이 [bold]~/.aos/config.toml[/bold] 에 저장되었습니다.")
    console.print()


@click.command("setup")
@click.option("--notify", "notify_only", is_flag=True, default=False, help="알림 설정만 변경한다")
def setup_cmd(notify_only: bool):
    """AI 제공자를 설정하고 git을 구성한다."""
    cfg = load_config()
    _banner()

    if notify_only:
        _section(1, 1, "알림 설정")
        _setup_notify_section(cfg)
        save_config(cfg)
        repo_root = _find_repo_root()
        if repo_root and cfg.notify.enabled:
            _generate_notify_config(cfg.notify.branch, cfg.notify.recipients, cfg.notify.mergers, repo_root)
            _install_git_hook(repo_root)
        return

    _section(1, 4, "AI 설정")
    _setup_ai_section(cfg)

    _section(2, 4, "알림 설정")
    _setup_notify_section(cfg)

    _section(3, 4, "언어 설정")
    console.print("  [bold]ko[/bold]  한국어  |  [bold]en[/bold]  English")
    console.print()
    lang = click.prompt("  언어", type=click.Choice(["ko", "en"]), default=cfg.behavior.language)
    cfg.behavior = BehaviorConfig(language=lang)

    _section(4, 4, "Git 인증 토큰 (선택사항)")
    console.print("  GitHub / GitLab Personal Access Token을 입력하면")
    console.print("  push / fetch 시 비밀번호 입력 없이 진행됩니다.")
    repo_root = _find_repo_root()
    if repo_root:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True, text=True, cwd=repo_root,
        )
        remote_url = normalize_url(result.stdout) if result.returncode == 0 else ""
        if remote_url:
            console.print(f"  [dim]현재 원격 저장소: {remote_url}[/dim]")
    else:
        remote_url = ""
    console.print()

    existing_token = cfg.git_tokens.get(remote_url, "") if remote_url else ""
    git_token = click.prompt(
        "  Token",
        default=existing_token,
        hide_input=True,
        prompt_suffix=" (비워두면 건너뜀): ",
        show_default=False,
    )
    if git_token and remote_url:
        cfg.git_tokens[remote_url] = git_token
        _ok(f"Git 토큰 저장됨 ({remote_url})")
    elif not git_token and remote_url and existing_token:
        _ok("기존 토큰 유지")

    save_config(cfg)

    subprocess.run(["git", "config", "--global", "merge.conflictstyle", "diff3"], check=False)

    if repo_root and cfg.notify.enabled:
        _generate_notify_config(cfg.notify.branch, cfg.notify.recipients, cfg.notify.mergers, repo_root)
    if repo_root:
        _install_git_hook(repo_root)

    console.print()
    console.rule("[bold cyan][4/4] 설정 완료 ✓[/bold cyan]")
    console.print()
    _test_and_show_summary(cfg)
