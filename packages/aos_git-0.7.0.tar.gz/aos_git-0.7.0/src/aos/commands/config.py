import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box
from aos.config.settings import load_config

console = Console()


@click.command("config")
@click.option("--test", "run_test", is_flag=True, default=False, help="AI 및 알림 연결 테스트 실행")
@click.option("--edit", "run_edit", is_flag=True, default=False, help="설정 다시 입력 (setup 재실행)")
def config_cmd(run_test: bool, run_edit: bool):
    """현재 설정을 확인하거나 연결을 테스트한다.

    \b
    aos config           현재 설정 요약
    aos config --test    AI + 알림 연결 테스트
    aos config --edit    설정 마법사 재실행
    """
    if run_edit:
        from aos.commands.setup import setup_cmd
        ctx = click.get_current_context()
        ctx.invoke(setup_cmd)
        return

    config = load_config()

    ai_table = Table(show_header=False, box=None, padding=(0, 1))
    ai_table.add_column(style="dim", width=12)
    ai_table.add_column()
    ai_table.add_row("Provider", config.ai.provider)
    ai_table.add_row("Model", config.ai.model)

    if run_test:
        try:
            from aos.ai.factory import build_adapter
            build_adapter(config)
            ai_table.add_row("Status", "[green]✓ 연결됨[/green]")
        except Exception as e:
            ai_table.add_row("Status", f"[red]✗ {e}[/red]")

    console.print(Panel(ai_table, title="[bold]AI Provider[/bold]", box=box.ROUNDED, border_style="cyan"))

    notify = config.notify
    notify_table = Table(show_header=False, box=None, padding=(0, 1))
    notify_table.add_column(style="dim", width=12)
    notify_table.add_column()

    if not notify.enabled:
        notify_table.add_row("채널", "사용 안함")
    else:
        notify_table.add_row("채널", notify.channel)
        if notify.channel == "email":
            notify_table.add_row("SMTP Host", notify.email.host or "(미설정)")
            notify_table.add_row("수신자", f"{len(notify.recipients)}명")
            notify_table.add_row("병합 관리자", f"{len(notify.mergers)}명")
        elif notify.channel in ("slack", "teams"):
            webhook = notify.slack.webhook_url if notify.channel == "slack" else notify.teams.webhook_url
            short = (webhook[:45] + "…") if len(webhook) > 45 else webhook
            notify_table.add_row("Webhook", short or "(미설정)")

        if run_test:
            try:
                from aos.notify.factory import build_notifier
                notifier = build_notifier(config)
                ok = notifier.test_connection()
                status = "[green]✓ 연결됨[/green]" if ok else "[yellow]⚠ 연결 확인 필요[/yellow]"
                notify_table.add_row("Status", status)
            except Exception as e:
                notify_table.add_row("Status", f"[red]✗ {e}[/red]")

    console.print(Panel(notify_table, title="[bold]알림[/bold]", box=box.ROUNDED, border_style="cyan"))

    if not run_test:
        console.print("[dim]  --test 플래그로 연결 테스트를 실행할 수 있습니다.[/dim]")
        console.print("[dim]  --edit 플래그로 설정을 변경할 수 있습니다.[/dim]")
