import json
import urllib.request
from typing import Optional, Callable

from aos.notify.adapter import NotificationAdapter


class TeamsNotifier(NotificationAdapter):
    def __init__(self, webhook_url: str):
        self._webhook_url = webhook_url

    def _post(self, text: str, _urlopen: Optional[Callable] = None) -> None:
        urlopen = _urlopen or urllib.request.urlopen
        data = json.dumps({
            "type": "message",
            "attachments": [{
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.2",
                    "body": [{"type": "TextBlock", "text": text, "wrap": True}],
                },
            }],
        }).encode()
        req = urllib.request.Request(
            self._webhook_url,
            data=data,
            headers={"Content-Type": "application/json"},
        )
        with urlopen(req, timeout=10):
            pass

    def notify_main_push(self, *, author: str, message: str, sha: str, url: str, _urlopen=None, **kwargs) -> None:
        text = (
            f"**main** 브랜치 업데이트\n\n"
            f"작업자: {author} | 커밋: `{sha[:8]}` {message}\n\n"
            f"`aos sync && aos push`"
        )
        self._post(text, _urlopen=_urlopen)

    def notify_branch_push(self, *, branch: str, author: str, message: str, sha: str, url: str, _urlopen=None, **kwargs) -> None:
        text = (
            f"**{branch}** 브랜치 업데이트\n\n"
            f"작업자: {author} | 커밋: `{sha[:8]}` {message}\n\n"
            f"`aos merge {branch}`"
        )
        self._post(text, _urlopen=_urlopen)

    def test_connection(self, _urlopen=None, **kwargs) -> bool:
        try:
            self._post("aos-git 알림 연결 테스트", _urlopen=_urlopen)
            return True
        except Exception:
            return False
