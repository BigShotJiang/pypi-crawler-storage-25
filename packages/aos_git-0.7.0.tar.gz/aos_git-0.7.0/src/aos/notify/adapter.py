from abc import ABC, abstractmethod


class NotificationAdapter(ABC):
    @abstractmethod
    def notify_main_push(self, *, author: str, message: str, sha: str, url: str, **kwargs) -> None:
        """main 브랜치 push 시 팀 전체에 알림."""

    @abstractmethod
    def notify_branch_push(self, *, branch: str, author: str, message: str, sha: str, url: str, **kwargs) -> None:
        """feature 브랜치 push 시 병합 관리자에게 알림."""

    @abstractmethod
    def test_connection(self, **kwargs) -> bool:
        """연결 가능 여부 확인. 실패 시 False 반환."""
