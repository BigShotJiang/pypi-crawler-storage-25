import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional, Type

from aos.config.settings import NotifyEmailConfig
from aos.notify.adapter import NotificationAdapter


def _build_main_push_html(*, author: str, message: str, sha: str, url: str) -> str:
    project_link = f'<a href="{url}" style="color:#4A90D9;">{url}</a>' if url else "(없음)"
    return f"""\
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#f4f6f8;font-family:'Apple SD Gothic Neo',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f8;padding:32px 0;">
    <tr><td align="center">
      <table width="580" cellpadding="0" cellspacing="0"
             style="background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
        <tr>
          <td style="background:#1a1a2e;padding:24px 32px;">
            <span style="color:#ffffff;font-size:18px;font-weight:700;">aos-git</span>
            <span style="color:#8899aa;font-size:13px;margin-left:8px;">알림</span>
          </td>
        </tr>
        <tr>
          <td style="padding:32px 32px 0;">
            <p style="margin:0 0 24px;font-size:15px;color:#333;line-height:1.6;">
              <strong>main</strong> 브랜치에 새로운 변경사항이 병합됐습니다.<br>
              각자 브랜치에 아래 명령어로 최신 버전을 반영해주세요.
            </p>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#0d1117;border-radius:6px;margin-bottom:24px;">
              <tr>
                <td style="padding:16px 20px;font-family:'Courier New',monospace;font-size:14px;color:#e6edf3;">
                  $ aos sync<br>$ aos push
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="padding:0 32px 32px;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f9fa;border-radius:6px;">
              <tr>
                <td style="padding:16px 20px;font-size:13px;color:#444;line-height:2;">
                  <strong>작업자:</strong> {author}<br>
                  <strong>커밋:</strong> <code>{sha}</code> {message}<br>
                  <strong>프로젝트:</strong> {project_link}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""


def _build_branch_push_html(*, branch: str, author: str, message: str, sha: str, url: str) -> str:
    project_link = f'<a href="{url}" style="color:#4A90D9;">{url}</a>' if url else "(없음)"
    return f"""\
<!DOCTYPE html>
<html lang="ko">
<head><meta charset="utf-8"></head>
<body style="margin:0;padding:0;background:#f4f6f8;font-family:'Apple SD Gothic Neo',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6f8;padding:32px 0;">
    <tr><td align="center">
      <table width="580" cellpadding="0" cellspacing="0"
             style="background:#ffffff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">
        <tr>
          <td style="background:#1a1a2e;padding:24px 32px;">
            <span style="color:#ffffff;font-size:18px;font-weight:700;">aos-git</span>
            <span style="color:#8899aa;font-size:13px;margin-left:8px;">알림</span>
          </td>
        </tr>
        <tr>
          <td style="padding:32px 32px 0;">
            <p style="margin:0 0 24px;font-size:15px;color:#333;line-height:1.6;">
              <strong>{branch}</strong> 브랜치에 새 변경사항이 올라왔습니다.<br>
              아래 명령어로 병합을 진행해주세요.
            </p>
            <table width="100%" cellpadding="0" cellspacing="0"
                   style="background:#0d1117;border-radius:6px;margin-bottom:24px;">
              <tr>
                <td style="padding:16px 20px;font-family:'Courier New',monospace;font-size:14px;color:#e6edf3;">
                  $ aos merge {branch}
                </td>
              </tr>
            </table>
          </td>
        </tr>
        <tr>
          <td style="padding:0 32px 32px;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8f9fa;border-radius:6px;">
              <tr>
                <td style="padding:16px 20px;font-size:13px;color:#444;line-height:2;">
                  <strong>작업자:</strong> {author}<br>
                  <strong>브랜치:</strong> <code>{branch}</code><br>
                  <strong>커밋:</strong> <code>{sha}</code> {message}<br>
                  <strong>프로젝트:</strong> {project_link}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""


class EmailNotifier(NotificationAdapter):
    def __init__(
        self,
        config: NotifyEmailConfig,
        branch: str,
        recipients: list[str],
        mergers: list[str],
    ):
        self._config = config
        self._branch = branch
        self._recipients = recipients
        self._mergers = mergers

    def _send(
        self,
        subject: str,
        html: str,
        recipients: list[str],
        _smtp_cls: Optional[Type] = None,
    ) -> None:
        smtp_cls = _smtp_cls or smtplib.SMTP
        msg = MIMEMultipart("alternative")
        msg["From"] = self._config.sender
        msg["To"] = ", ".join(recipients)
        msg["Subject"] = subject
        msg.attach(MIMEText(html, "html", "utf-8"))
        with smtp_cls(self._config.host, self._config.port) as server:
            if self._config.tls:
                server.starttls()
            if self._config.username:
                server.login(self._config.username, self._config.password)
            server.sendmail(self._config.sender, recipients, msg.as_string())

    def notify_main_push(self, *, author: str, message: str, sha: str, url: str, _smtp_cls=None, **kwargs) -> None:
        if not self._recipients:
            return
        subject = f"[aos-git] main 브랜치가 업데이트됐습니다 ({sha[:8]})"
        html = _build_main_push_html(author=author, message=message, sha=sha[:8], url=url)
        self._send(subject, html, self._recipients, _smtp_cls=_smtp_cls)

    def notify_branch_push(self, *, branch: str, author: str, message: str, sha: str, url: str, _smtp_cls=None, **kwargs) -> None:
        if not self._mergers:
            return
        subject = f"[aos-git] {branch} 브랜치에 새 변경사항이 있습니다 ({sha[:8]})"
        html = _build_branch_push_html(branch=branch, author=author, message=message, sha=sha[:8], url=url)
        self._send(subject, html, self._mergers, _smtp_cls=_smtp_cls)

    def test_connection(self, _smtp_cls=None, **kwargs) -> bool:
        smtp_cls = _smtp_cls or smtplib.SMTP
        try:
            with smtp_cls(self._config.host, self._config.port) as server:
                if self._config.tls:
                    server.starttls()
            return True
        except Exception:
            return False
