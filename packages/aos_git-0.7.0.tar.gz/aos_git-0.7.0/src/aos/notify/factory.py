from aos.config.settings import Config
from aos.notify.adapter import NotificationAdapter
from aos.notify.email import EmailNotifier
from aos.notify.slack import SlackNotifier
from aos.notify.teams import TeamsNotifier


class NullNotifier(NotificationAdapter):
    def notify_main_push(self, **kwargs) -> None:
        pass

    def notify_branch_push(self, **kwargs) -> None:
        pass

    def test_connection(self, **kwargs) -> bool:
        return True


def build_notifier(config: Config) -> NotificationAdapter:
    notify = config.notify
    if not notify.enabled or notify.channel == "none":
        return NullNotifier()
    if notify.channel == "email":
        return EmailNotifier(
            config=notify.email,
            branch=notify.branch,
            recipients=notify.recipients,
            mergers=notify.mergers,
        )
    if notify.channel == "slack":
        return SlackNotifier(webhook_url=notify.slack.webhook_url)
    if notify.channel == "teams":
        return TeamsNotifier(webhook_url=notify.teams.webhook_url)
    return NullNotifier()
