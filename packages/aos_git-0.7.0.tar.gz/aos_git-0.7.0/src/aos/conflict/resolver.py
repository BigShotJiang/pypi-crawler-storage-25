import click
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich import box

from aos.conflict.detector import find_conflict_files
from aos.conflict.parser import parse_conflicts, get_merge_timestamps
from aos.conflict.preview import show_conflict_preview, ask_apply
from aos.conflict.applier import apply_resolution
from aos.ai.adapter import AIAdapter

console = Console()


def resolve_all_conflicts(repo_root: Path, adapter: AIAdapter, behavior) -> bool:
    conflict_files = find_conflict_files(repo_root)
    if not conflict_files:
        console.print("[green][aos] 충돌이 없습니다.[/green]")
        return True

    ours_ts, theirs_ts = get_merge_timestamps(repo_root)
    all_applied = True
    total_blocks = sum(len(parse_conflicts(f)) for f in conflict_files)
    index = 0

    for file_path in conflict_files:
        blocks = parse_conflicts(file_path, context_lines=behavior.context_lines)
        decisions: list[tuple] = []
        for block in blocks:
            index += 1
            try:
                with console.status(f"[cyan]AI가 충돌을 분석 중입니다... ({index}/{total_blocks})[/cyan]"):
                    resolved = adapter.resolve_conflict(block, ours_ts=ours_ts, theirs_ts=theirs_ts)
            except Exception as e:
                console.print(Panel(
                    f"[dim]Provider:[/dim] {type(adapter).__name__}\n"
                    f"[dim]원인:[/dim] {e}\n"
                    f"[yellow]해결:[/yellow] [bold]aos config --edit[/bold] 로 설정을 확인하세요",
                    title="[bold red]오류: AI 연결 실패[/bold red]",
                    box=box.ROUNDED,
                    border_style="red",
                ))
                decisions.append((block, "", "n"))
                all_applied = False
                continue

            show_conflict_preview(block, resolved, index, total_blocks)
            choice = "y" if behavior.auto_apply else ask_apply(behavior.language)
            decisions.append((block, resolved, choice))

        for block, resolved, choice in reversed(decisions):
            if choice == "y":
                apply_resolution(file_path, block.line_start, resolved)
                console.print(f"[green]  적용됨 (라인 {block.line_start})[/green]")
            elif choice == "e":
                click.edit(filename=str(file_path))
                all_applied = False
            else:
                console.print(f"[yellow]  건너뜀 (라인 {block.line_start}) — 충돌 마커 유지됨[/yellow]")
                all_applied = False

    if not all_applied:
        console.print("[yellow][aos] 일부 충돌이 남아 있습니다. 'git merge --abort' 또는 수동 해결하세요.[/yellow]")

    return all_applied
