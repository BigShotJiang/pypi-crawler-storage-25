from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
import tomllib
import tomli_w

CONFIG_PATH = Path.home() / ".aos" / "config.toml"


@dataclass
class AIConfig:
    provider: str = "databricks"
    model: str = "databricks-claude-sonnet-4-6"


@dataclass
class DatabricksConfig:
    host: str = ""
    token: str = ""


@dataclass
class AnthropicConfig:
    api_key: str = ""


@dataclass
class OpenAIConfig:
    api_key: str = ""


@dataclass
class OllamaConfig:
    host: str = "http://localhost:11434"


@dataclass
class CustomConfig:
    base_url: str = ""
    api_key: str = ""


@dataclass
class BehaviorConfig:
    auto_apply: bool = False
    context_lines: int = 20
    language: str = "ko"


@dataclass
class NotifyEmailConfig:
    host: str = ""
    port: int = 587
    username: str = ""
    password: str = ""
    sender: str = ""
    tls: bool = True


@dataclass
class NotifySlackConfig:
    webhook_url: str = ""


@dataclass
class NotifyTeamsConfig:
    webhook_url: str = ""


@dataclass
class NotifyConfig:
    enabled: bool = False
    channel: str = "none"
    branch: str = "main"
    recipients: list = field(default_factory=list)
    mergers: list = field(default_factory=list)
    email: NotifyEmailConfig = field(default_factory=NotifyEmailConfig)
    slack: NotifySlackConfig = field(default_factory=NotifySlackConfig)
    teams: NotifyTeamsConfig = field(default_factory=NotifyTeamsConfig)


@dataclass
class Config:
    ai: AIConfig = field(default_factory=AIConfig)
    databricks: Optional[DatabricksConfig] = field(default_factory=DatabricksConfig)
    anthropic: Optional[AnthropicConfig] = field(default_factory=AnthropicConfig)
    openai: Optional[OpenAIConfig] = field(default_factory=OpenAIConfig)
    ollama: Optional[OllamaConfig] = field(default_factory=OllamaConfig)
    custom: Optional[CustomConfig] = field(default_factory=CustomConfig)
    behavior: BehaviorConfig = field(default_factory=BehaviorConfig)
    notify: NotifyConfig = field(default_factory=NotifyConfig)
    git_tokens: dict = field(default_factory=dict)


def load_config() -> Config:
    if not CONFIG_PATH.exists():
        return Config()
    with open(CONFIG_PATH, "rb") as f:
        data = tomllib.load(f)
    notify_data = data.get("notify", {})
    return Config(
        ai=AIConfig(**data.get("ai", {})),
        databricks=DatabricksConfig(**data.get("databricks", {})),
        anthropic=AnthropicConfig(**data.get("anthropic", {})),
        openai=OpenAIConfig(**data.get("openai", {})),
        ollama=OllamaConfig(**data.get("ollama", {})),
        custom=CustomConfig(**data.get("custom", {})),
        behavior=BehaviorConfig(**data.get("behavior", {})),
        git_tokens=data.get("git_tokens", {}),
        notify=NotifyConfig(
            enabled=notify_data.get("enabled", False),
            channel=notify_data.get("channel", "none"),
            branch=notify_data.get("branch", "main"),
            recipients=notify_data.get("recipients", []),
            mergers=notify_data.get("mergers", []),
            email=NotifyEmailConfig(**notify_data.get("email", {})),
            slack=NotifySlackConfig(**notify_data.get("slack", {})),
            teams=NotifyTeamsConfig(**notify_data.get("teams", {})),
        ),
    )


def save_config(config: Config) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "ai": {"provider": config.ai.provider, "model": config.ai.model},
        "databricks": {
            "host": config.databricks.host if config.databricks else "",
            "token": config.databricks.token if config.databricks else "",
        },
        "anthropic": {
            "api_key": config.anthropic.api_key if config.anthropic else "",
        },
        "openai": {
            "api_key": config.openai.api_key if config.openai else "",
        },
        "ollama": {
            "host": config.ollama.host if config.ollama else "http://localhost:11434",
        },
        "custom": {
            "base_url": config.custom.base_url if config.custom else "",
            "api_key": config.custom.api_key if config.custom else "",
        },
        "behavior": {
            "auto_apply": config.behavior.auto_apply,
            "context_lines": config.behavior.context_lines,
            "language": config.behavior.language,
        },
        "git_tokens": config.git_tokens,
        "notify": {
            "enabled": config.notify.enabled,
            "channel": config.notify.channel,
            "branch": config.notify.branch,
            "recipients": config.notify.recipients,
            "mergers": config.notify.mergers,
            "email": {
                "host": config.notify.email.host,
                "port": config.notify.email.port,
                "username": config.notify.email.username,
                "password": config.notify.email.password,
                "sender": config.notify.email.sender,
                "tls": config.notify.email.tls,
            },
            "slack": {"webhook_url": config.notify.slack.webhook_url},
            "teams": {"webhook_url": config.notify.teams.webhook_url},
        },
    }
    with open(CONFIG_PATH, "wb") as f:
        tomli_w.dump(data, f)
