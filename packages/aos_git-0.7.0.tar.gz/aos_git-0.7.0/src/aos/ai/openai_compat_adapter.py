import re
from typing import Optional
from openai import OpenAI
from aos.ai.adapter import AIAdapter, SYSTEM_PROMPT, build_user_prompt
from aos.conflict.parser import ConflictBlock


def _clean_response(content: str) -> str:
    match = re.search(r'```(?:\w+)?\n(.*?)```', content, re.DOTALL)
    if match:
        return match.group(1).strip()
    return content.strip()


class OpenAICompatibleAdapter(AIAdapter):
    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str,
        _client: Optional[object] = None,
    ):
        self.model = model
        self._client = _client or OpenAI(api_key=api_key, base_url=base_url)

    def resolve_conflict(
        self,
        block: ConflictBlock,
        ours_ts: str,
        theirs_ts: str,
    ) -> str:
        prompt = build_user_prompt(block, ours_ts, theirs_ts)
        response = self._client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        )
        return _clean_response(response.choices[0].message.content or "")
