from aos.config.settings import Config
from aos.ai.adapter import AIAdapter
from aos.ai.databricks import DatabricksAdapter
from aos.ai.anthropic_adapter import AnthropicAdapter
from aos.ai.openai_adapter import OpenAIAdapter
from aos.ai.ollama_adapter import OllamaAdapter
from aos.ai.openai_compat_adapter import OpenAICompatibleAdapter


def build_adapter(config: Config) -> AIAdapter:
    provider = config.ai.provider
    model = config.ai.model

    if provider == "databricks":
        if not config.databricks or not config.databricks.host:
            raise ValueError("Databricks 설정이 없습니다. 'aos setup'을 실행하세요.")
        return DatabricksAdapter(
            host=config.databricks.host,
            token=config.databricks.token,
            model=model,
        )
    if provider == "anthropic":
        if not config.anthropic or not config.anthropic.api_key:
            raise ValueError("Anthropic API 키가 없습니다. 'aos setup'을 실행하세요.")
        return AnthropicAdapter(api_key=config.anthropic.api_key, model=model)
    if provider == "openai":
        if not config.openai or not config.openai.api_key:
            raise ValueError("OpenAI API 키가 없습니다. 'aos setup'을 실행하세요.")
        return OpenAIAdapter(api_key=config.openai.api_key, model=model)
    if provider == "ollama":
        host = config.ollama.host if config.ollama else "http://localhost:11434"
        return OllamaAdapter(host=host, model=model)
    if provider == "custom":
        if not config.custom or not config.custom.base_url:
            raise ValueError("Custom endpoint base_url이 없습니다. 'aos setup'을 실행하세요.")
        return OpenAICompatibleAdapter(
            base_url=config.custom.base_url,
            api_key=config.custom.api_key,
            model=model,
        )
    raise ValueError(f"알 수 없는 AI 제공자: {provider}. 'aos setup'을 실행하세요.")
