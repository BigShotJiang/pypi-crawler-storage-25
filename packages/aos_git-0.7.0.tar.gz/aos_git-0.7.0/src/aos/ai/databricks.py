from typing import Optional
from aos.ai.openai_compat_adapter import OpenAICompatibleAdapter


class DatabricksAdapter(OpenAICompatibleAdapter):
    def __init__(
        self,
        host: str,
        token: str,
        model: str = "databricks-claude-sonnet-4-6",
        _client: Optional[object] = None,
    ):
        super().__init__(
            base_url=f"{host.rstrip('/')}/serving-endpoints",
            api_key=token,
            model=model,
            _client=_client,
        )
