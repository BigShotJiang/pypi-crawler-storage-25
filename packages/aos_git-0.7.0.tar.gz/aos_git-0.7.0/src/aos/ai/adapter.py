from abc import ABC, abstractmethod
from aos.conflict.parser import ConflictBlock

SYSTEM_PROMPT = """당신은 git merge conflict 해결 전문가입니다.
충돌 블록을 보고 양쪽의 변경 의도를 통합한 코드를 반환합니다.

절대 규칙:
- 코드만 출력하세요. 분석, 설명, 주석, 서문을 절대 포함하지 마세요.
- "두 변경사항을 분석합니다", "OURS의 의도는" 같은 설명 문장을 출력하지 마세요.
- 충돌 마커(<<<<<<, =======, |||||||, >>>>>>>) 없이 코드만 반환하세요.
- 코드 블록 마크다운(``` 또는 ```python 등)을 사용하지 마세요.
- 첫 글자부터 마지막 글자까지 오직 코드만 작성하세요."""

USER_TEMPLATE = """다음 충돌을 해결해주세요.

파일: {file_path}
BASE (공통 조상):
{base}

OURS (커밋 시각: {ours_ts}):
{ours}

THEIRS (커밋 시각: {theirs_ts}):
{theirs}

타임스탬프 기반 우선순위:
{timestamp_hint}

주변 코드:
{context_before}
[충돌 위치]
{context_after}

코드만 반환하세요. 설명이나 분석 텍스트 없이."""


def _timestamp_hint(ours_ts: str, theirs_ts: str) -> str:
    """두 커밋 시각을 비교해 어느 쪽이 더 최신인지 힌트를 반환한다."""
    if ours_ts and theirs_ts and ours_ts != theirs_ts:
        if ours_ts >= theirs_ts:
            return (
                f"OURS({ours_ts})가 더 최신입니다. "
                "OURS의 변경을 기준으로 통합하되, THEIRS의 독립적인 변경은 보존하세요."
            )
        else:
            return (
                f"THEIRS({theirs_ts})가 더 최신입니다. "
                "THEIRS의 변경을 기준으로 통합하되, OURS의 독립적인 변경은 보존하세요."
            )
    return "양쪽의 변경사항을 논리적으로 통합하세요."


def build_user_prompt(block: ConflictBlock, ours_ts: str, theirs_ts: str) -> str:
    return USER_TEMPLATE.format(
        file_path=block.file_path,
        base=block.base or "(없음)",
        ours=block.ours,
        theirs=block.theirs,
        ours_ts=ours_ts or "알 수 없음",
        theirs_ts=theirs_ts or "알 수 없음",
        timestamp_hint=_timestamp_hint(ours_ts, theirs_ts),
        context_before=block.context_before,
        context_after=block.context_after,
    )


class AIAdapter(ABC):
    @abstractmethod
    def resolve_conflict(
        self,
        block: ConflictBlock,
        ours_ts: str,
        theirs_ts: str,
    ) -> str:
        """통합된 코드 문자열을 반환한다."""
