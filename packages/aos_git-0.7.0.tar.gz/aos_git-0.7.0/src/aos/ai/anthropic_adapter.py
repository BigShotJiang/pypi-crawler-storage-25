import re
from typing import Optional
import anthropic
from aos.ai.adapter import AIAdapter, SYSTEM_PROMPT, build_user_prompt
from aos.conflict.parser import ConflictBlock


def _clean_response(content: str) -> str:
    match = re.search(r'```(?:\w+)?\n(.*?)```', content, re.DOTALL)
    if match:
        return match.group(1).strip()
    return content.strip()


class AnthropicAdapter(AIAdapter):
    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-6",
        _client: Optional[object] = None,
    ):
        self.model = model
        self._client = _client or anthropic.Anthropic(api_key=api_key)

    def resolve_conflict(
        self,
        block: ConflictBlock,
        ours_ts: str,
        theirs_ts: str,
    ) -> str:
        prompt = build_user_prompt(block, ours_ts, theirs_ts)
        response = self._client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
        return _clean_response(response.content[0].text)
