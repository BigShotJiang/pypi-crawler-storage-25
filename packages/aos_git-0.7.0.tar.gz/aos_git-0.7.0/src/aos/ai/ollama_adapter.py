from typing import Optional
from aos.ai.openai_compat_adapter import OpenAICompatibleAdapter


class OllamaAdapter(OpenAICompatibleAdapter):
    def __init__(self, host: str = "http://localhost:11434", model: str = "llama3", _client: Optional[object] = None):
        super().__init__(
            base_url=f"{host.rstrip('/')}/v1",
            api_key="ollama",
            model=model,
            _client=_client,
        )
