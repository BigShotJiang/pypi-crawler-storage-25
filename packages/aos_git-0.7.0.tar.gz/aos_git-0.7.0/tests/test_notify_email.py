import smtplib
from unittest.mock import MagicMock, patch
from aos.notify.email import EmailNotifier, _build_branch_push_html
from aos.config.settings import NotifyEmailConfig


def _make_email_notifier(host="smtp.gmail.com", port=587, tls=True, recipients=None, mergers=None):
    cfg = NotifyEmailConfig(
        host=host, port=port, username="sender@example.com",
        password="pw", sender="sender@example.com", tls=tls,
    )
    return EmailNotifier(
        config=cfg,
        branch="main",
        recipients=["team@example.com"] if recipients is None else recipients,
        mergers=["lead@example.com"] if mergers is None else mergers,
    )


def test_notify_main_push_calls_smtp_sendmail():
    notifier = _make_email_notifier()
    mock_smtp = MagicMock()
    mock_smtp_instance = MagicMock()
    mock_smtp.return_value.__enter__ = MagicMock(return_value=mock_smtp_instance)
    mock_smtp.return_value.__exit__ = MagicMock(return_value=False)

    notifier.notify_main_push(
        author="김철수", message="feat: add pipeline", sha="abc12345", url="https://gitlab.com/project",
        _smtp_cls=mock_smtp,
    )
    mock_smtp.assert_called_once_with("smtp.gmail.com", 587)
    mock_smtp_instance.sendmail.assert_called_once()


def test_notify_main_push_skips_when_no_recipients():
    notifier = _make_email_notifier(recipients=[])
    mock_smtp = MagicMock()
    notifier.notify_main_push(
        author="김철수", message="feat: add pipeline", sha="abc12345", url="",
        _smtp_cls=mock_smtp,
    )
    mock_smtp.assert_not_called()


def test_notify_branch_push_sends_to_mergers():
    notifier = _make_email_notifier(mergers=["lead@example.com"])
    mock_smtp = MagicMock()
    mock_smtp_instance = MagicMock()
    mock_smtp.return_value.__enter__ = MagicMock(return_value=mock_smtp_instance)
    mock_smtp.return_value.__exit__ = MagicMock(return_value=False)

    notifier.notify_branch_push(
        branch="feature/kim-data", author="김철수", message="feat: data",
        sha="abc12345", url="", _smtp_cls=mock_smtp,
    )
    call_args = mock_smtp_instance.sendmail.call_args
    assert "lead@example.com" in call_args[0][1]


def test_notify_branch_push_skips_when_no_mergers():
    notifier = _make_email_notifier(mergers=[])
    mock_smtp = MagicMock()
    notifier.notify_branch_push(
        branch="feature/test", author="test", message="test", sha="abc", url="",
        _smtp_cls=mock_smtp,
    )
    mock_smtp.assert_not_called()


def test_email_html_contains_branch_and_command():
    html = _build_branch_push_html(
        branch="feature/kim-data", author="김철수", message="feat: add data", sha="abc12345", url=""
    )
    assert "feature/kim-data" in html
    assert "aos merge feature/kim-data" in html
    assert "김철수" in html


def test_test_connection_returns_true_on_success():
    notifier = _make_email_notifier()
    mock_smtp = MagicMock()
    mock_smtp.return_value.__enter__ = MagicMock(return_value=MagicMock())
    mock_smtp.return_value.__exit__ = MagicMock(return_value=False)
    assert notifier.test_connection(_smtp_cls=mock_smtp) is True


def test_test_connection_returns_false_on_failure():
    notifier = _make_email_notifier()

    def raise_conn(*args, **kwargs):
        raise ConnectionRefusedError("refused")

    assert notifier.test_connection(_smtp_cls=raise_conn) is False
