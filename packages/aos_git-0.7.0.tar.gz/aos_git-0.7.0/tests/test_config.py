from pathlib import Path
from unittest.mock import patch
from aos.config.settings import (
    load_config, save_config, Config, AIConfig, BehaviorConfig,
    OpenAIConfig, OllamaConfig, CustomConfig,
    NotifyConfig, NotifyEmailConfig, NotifySlackConfig, NotifyTeamsConfig,
)

def test_load_config_returns_defaults_when_missing(tmp_path):
    config_path = tmp_path / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = load_config()
    assert cfg.ai.provider == "databricks"
    assert cfg.behavior.auto_apply is False
    assert cfg.behavior.context_lines == 20


def test_save_and_load_roundtrip(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = Config(
            ai=AIConfig(provider="anthropic", model="claude-opus-4-6"),
            databricks=None,
            anthropic=None,
            behavior=BehaviorConfig(auto_apply=True, context_lines=30, language="en"),
        )
        save_config(cfg)
        loaded = load_config()
    assert loaded.ai.provider == "anthropic"
    assert loaded.behavior.auto_apply is True
    assert loaded.behavior.context_lines == 30


def test_git_tokens_roundtrip(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = Config(git_tokens={"https://gitlab.lge.com/team/repo": "glpat-abc123"})
        save_config(cfg)
        loaded = load_config()
    assert loaded.git_tokens == {"https://gitlab.lge.com/team/repo": "glpat-abc123"}


def test_notify_config_mergers_defaults_to_empty(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        loaded = load_config()
    assert loaded.notify.mergers == []


def test_openai_config_roundtrip(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = Config(
            ai=AIConfig(provider="openai", model="gpt-4o"),
            openai=OpenAIConfig(api_key="sk-test"),
        )
        save_config(cfg)
        loaded = load_config()
    assert loaded.ai.provider == "openai"
    assert loaded.openai.api_key == "sk-test"


def test_ollama_config_roundtrip(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = Config(
            ai=AIConfig(provider="ollama", model="llama3"),
            ollama=OllamaConfig(host="http://localhost:11434"),
        )
        save_config(cfg)
        loaded = load_config()
    assert loaded.ollama.host == "http://localhost:11434"


def test_custom_config_roundtrip(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = Config(
            ai=AIConfig(provider="custom", model="mixtral"),
            custom=CustomConfig(base_url="https://api.groq.com/openai/v1", api_key="gsk-x"),
        )
        save_config(cfg)
        loaded = load_config()
    assert loaded.custom.base_url == "https://api.groq.com/openai/v1"
    assert loaded.custom.api_key == "gsk-x"


def test_notify_email_config_roundtrip(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = Config(
            notify=NotifyConfig(
                enabled=True,
                channel="email",
                branch="main",
                recipients=["a@example.com"],
                mergers=["lead@example.com"],
                email=NotifyEmailConfig(
                    host="smtp.gmail.com",
                    port=587,
                    username="sender@gmail.com",
                    password="app-pw",
                    sender="sender@gmail.com",
                    tls=True,
                ),
            )
        )
        save_config(cfg)
        loaded = load_config()
    assert loaded.notify.enabled is True
    assert loaded.notify.channel == "email"
    assert loaded.notify.email.host == "smtp.gmail.com"
    assert loaded.notify.email.tls is True


def test_notify_slack_config_roundtrip(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        cfg = Config(
            notify=NotifyConfig(
                enabled=True,
                channel="slack",
                slack=NotifySlackConfig(webhook_url="https://hooks.slack.com/services/TEST"),
            )
        )
        save_config(cfg)
        loaded = load_config()
    assert loaded.notify.slack.webhook_url == "https://hooks.slack.com/services/TEST"


def test_notify_disabled_by_default(tmp_path):
    config_path = tmp_path / ".aos" / "config.toml"
    with patch("aos.config.settings.CONFIG_PATH", config_path):
        loaded = load_config()
    assert loaded.notify.enabled is False
    assert loaded.notify.channel == "none"