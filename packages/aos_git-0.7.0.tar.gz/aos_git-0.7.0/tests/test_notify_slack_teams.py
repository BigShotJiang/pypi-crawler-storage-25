import json
from unittest.mock import MagicMock
from aos.notify.slack import SlackNotifier
from aos.notify.teams import TeamsNotifier


def test_slack_notifier_posts_main_push():
    notifier = SlackNotifier(webhook_url="https://hooks.slack.com/services/TEST")
    mock_response = MagicMock()
    mock_response.status = 200
    mock_urlopen = MagicMock(return_value=mock_response)
    mock_urlopen.return_value.__enter__ = MagicMock(return_value=mock_response)
    mock_urlopen.return_value.__exit__ = MagicMock(return_value=False)

    notifier.notify_main_push(
        author="김철수", message="feat: add pipeline", sha="abc12345", url="",
        _urlopen=mock_urlopen,
    )
    mock_urlopen.assert_called_once()
    request_arg = mock_urlopen.call_args[0][0]
    body = json.loads(request_arg.data.decode())
    assert "main" in body["text"]
    assert "aos sync" in body["text"]


def test_slack_notifier_posts_branch_push():
    notifier = SlackNotifier(webhook_url="https://hooks.slack.com/services/TEST")
    mock_response = MagicMock()
    mock_response.status = 200
    mock_urlopen = MagicMock(return_value=mock_response)
    mock_urlopen.return_value.__enter__ = MagicMock(return_value=mock_response)
    mock_urlopen.return_value.__exit__ = MagicMock(return_value=False)

    notifier.notify_branch_push(
        branch="feature/data", author="이영희", message="feat: data", sha="def56789", url="",
        _urlopen=mock_urlopen,
    )
    request_arg = mock_urlopen.call_args[0][0]
    body = json.loads(request_arg.data.decode())
    assert "feature/data" in body["text"]
    assert "aos merge feature/data" in body["text"]


def test_slack_test_connection_returns_true_on_success():
    notifier = SlackNotifier(webhook_url="https://hooks.slack.com/services/TEST")
    mock_response = MagicMock()
    mock_response.status = 200
    mock_urlopen = MagicMock(return_value=mock_response)
    mock_urlopen.return_value.__enter__ = MagicMock(return_value=mock_response)
    mock_urlopen.return_value.__exit__ = MagicMock(return_value=False)
    assert notifier.test_connection(_urlopen=mock_urlopen) is True


def test_slack_test_connection_returns_false_on_failure():
    notifier = SlackNotifier(webhook_url="https://hooks.slack.com/services/TEST")

    def raise_err(*args, **kwargs):
        raise Exception("network error")

    assert notifier.test_connection(_urlopen=raise_err) is False


def test_teams_notifier_posts_main_push():
    notifier = TeamsNotifier(webhook_url="https://company.webhook.office.com/TEST")
    mock_response = MagicMock()
    mock_response.status = 200
    mock_urlopen = MagicMock(return_value=mock_response)
    mock_urlopen.return_value.__enter__ = MagicMock(return_value=mock_response)
    mock_urlopen.return_value.__exit__ = MagicMock(return_value=False)

    notifier.notify_main_push(
        author="김철수", message="feat: add pipeline", sha="abc12345", url="",
        _urlopen=mock_urlopen,
    )
    mock_urlopen.assert_called_once()


def test_factory_build_notifier_returns_email_notifier():
    from aos.notify.factory import build_notifier
    from aos.config.settings import Config, NotifyConfig, NotifyEmailConfig
    from aos.notify.email import EmailNotifier

    cfg = Config(
        notify=NotifyConfig(
            enabled=True, channel="email",
            recipients=["a@example.com"], mergers=[],
            email=NotifyEmailConfig(host="smtp.gmail.com", port=587, username="u", password="p", sender="u", tls=True),
        )
    )
    assert isinstance(build_notifier(cfg), EmailNotifier)


def test_factory_build_notifier_returns_null_when_disabled():
    from aos.notify.factory import build_notifier, NullNotifier
    from aos.config.settings import Config, NotifyConfig

    cfg = Config(notify=NotifyConfig(enabled=False, channel="none"))
    assert isinstance(build_notifier(cfg), NullNotifier)
