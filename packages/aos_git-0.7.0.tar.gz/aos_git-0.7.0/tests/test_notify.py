import importlib.util
from pathlib import Path
from unittest.mock import MagicMock, patch


def _load_notify_script():
    script_path = Path(__file__).parent.parent / "scripts" / "notify.py"
    spec = importlib.util.spec_from_file_location("notify_script", script_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_notify_script_main_push_calls_notifier(monkeypatch):
    monkeypatch.setenv("GITLAB_USER_NAME", "김철수")
    monkeypatch.setenv("CI_COMMIT_MESSAGE", "feat: add pipeline")
    monkeypatch.setenv("CI_COMMIT_SHA", "abc123456789")
    monkeypatch.setenv("CI_PROJECT_URL", "https://gitlab.com/project")

    mock_notifier = MagicMock()
    mock_config = MagicMock()

    with patch("aos.config.settings.load_config", return_value=mock_config), \
         patch("aos.notify.factory.build_notifier", return_value=mock_notifier), \
         patch("sys.argv", ["notify.py", "--event", "main-push"]):

        mod = _load_notify_script()
        mod.main()

    mock_notifier.notify_main_push.assert_called_once_with(
        author="김철수",
        message="feat: add pipeline",
        sha="abc123456789",
        url="https://gitlab.com/project",
    )


def test_notify_script_branch_push_calls_notifier(monkeypatch):
    monkeypatch.setenv("GITLAB_USER_NAME", "이영희")
    monkeypatch.setenv("CI_COMMIT_MESSAGE", "feat: data pipeline")
    monkeypatch.setenv("CI_COMMIT_SHA", "def987654321")
    monkeypatch.setenv("CI_PROJECT_URL", "https://gitlab.com/project")
    monkeypatch.setenv("BRANCH_NAME", "feature/data")

    mock_notifier = MagicMock()
    mock_config = MagicMock()

    with patch("aos.config.settings.load_config", return_value=mock_config), \
         patch("aos.notify.factory.build_notifier", return_value=mock_notifier), \
         patch("sys.argv", ["notify.py", "--event", "branch-push"]):

        mod = _load_notify_script()
        mod.main()

    mock_notifier.notify_branch_push.assert_called_once_with(
        branch="feature/data",
        author="이영희",
        message="feat: data pipeline",
        sha="def987654321",
        url="https://gitlab.com/project",
    )
