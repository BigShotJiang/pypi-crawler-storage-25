from unittest.mock import MagicMock, patch
from aos.ai.databricks import DatabricksAdapter
from aos.ai.anthropic_adapter import AnthropicAdapter, _clean_response as anthropic_clean
from aos.ai.openai_adapter import OpenAIAdapter
from aos.ai.ollama_adapter import OllamaAdapter
from aos.ai.openai_compat_adapter import OpenAICompatibleAdapter, _clean_response as openai_clean
from aos.ai.adapter import _timestamp_hint, build_user_prompt
from aos.conflict.parser import ConflictBlock
from pathlib import Path


def _make_block(ours: str, base: str, theirs: str) -> ConflictBlock:
    return ConflictBlock(
        file_path=Path("app.py"),
        line_start=1,
        ours=ours,
        base=base,
        theirs=theirs,
        context_before="",
        context_after="",
    )


def test_databricks_adapter_returns_resolved_string():
    block = _make_block("def f():\n    return 1\n", "", "def f(x):\n    return x\n")
    mock_client = MagicMock()
    mock_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="def f(x=None):\n    return x\n"))]
    )
    adapter = DatabricksAdapter(
        host="https://fake.databricks.net",
        token="fake-token",
        model="databricks-claude-sonnet-4-6",
        _client=mock_client,
    )
    result = adapter.resolve_conflict(block, ours_ts="2026-04-20", theirs_ts="2026-04-21")
    assert "def f(" in result
    mock_client.chat.completions.create.assert_called_once()


def test_openai_adapter_returns_resolved_string():
    block = _make_block("x = 1\n", "", "x = 2\n")
    mock_client = MagicMock()
    mock_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="x = 1  # merged\n"))]
    )
    adapter = OpenAIAdapter(api_key="sk-test", model="gpt-4o", _client=mock_client)
    result = adapter.resolve_conflict(block, ours_ts="2026-04-20", theirs_ts="2026-04-21")
    assert "x = " in result
    mock_client.chat.completions.create.assert_called_once()


def test_ollama_adapter_returns_resolved_string():
    block = _make_block("a = 1\n", "", "a = 2\n")
    mock_client = MagicMock()
    mock_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="a = 1  # merged\n"))]
    )
    adapter = OllamaAdapter(host="http://localhost:11434", model="llama3", _client=mock_client)
    result = adapter.resolve_conflict(block, ours_ts="2026-04-20", theirs_ts="2026-04-21")
    assert "a = " in result
    mock_client.chat.completions.create.assert_called_once()


def test_openai_compat_adapter_passes_model_to_api():
    block = _make_block("b = 1\n", "", "b = 2\n")
    mock_client = MagicMock()
    mock_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="b = 1\n"))]
    )
    adapter = OpenAICompatibleAdapter(
        base_url="https://api.groq.com/openai/v1",
        api_key="gsk-x",
        model="mixtral",
        _client=mock_client,
    )
    adapter.resolve_conflict(block, ours_ts="t1", theirs_ts="t2")
    call_kwargs = mock_client.chat.completions.create.call_args
    assert call_kwargs.kwargs["model"] == "mixtral"


def test_factory_builds_openai_adapter():
    from aos.ai.factory import build_adapter
    from aos.config.settings import Config, AIConfig, OpenAIConfig

    cfg = Config(ai=AIConfig(provider="openai", model="gpt-4o"), openai=OpenAIConfig(api_key="sk-x"))
    with patch("aos.ai.openai_compat_adapter.OpenAI"):
        adapter = build_adapter(cfg)
    assert isinstance(adapter, OpenAIAdapter)


def test_factory_builds_ollama_adapter():
    from aos.ai.factory import build_adapter
    from aos.config.settings import Config, AIConfig, OllamaConfig

    cfg = Config(ai=AIConfig(provider="ollama", model="llama3"), ollama=OllamaConfig(host="http://localhost:11434"))
    with patch("aos.ai.openai_compat_adapter.OpenAI"):
        adapter = build_adapter(cfg)
    assert isinstance(adapter, OllamaAdapter)


def test_factory_builds_custom_adapter():
    from aos.ai.factory import build_adapter
    from aos.config.settings import Config, AIConfig, CustomConfig

    cfg = Config(
        ai=AIConfig(provider="custom", model="mixtral"),
        custom=CustomConfig(base_url="https://api.groq.com/openai/v1", api_key="gsk-x"),
    )
    with patch("aos.ai.openai_compat_adapter.OpenAI"):
        adapter = build_adapter(cfg)
    assert isinstance(adapter, OpenAICompatibleAdapter)


def test_anthropic_adapter_returns_resolved_string():
    block = _make_block("x = 1\n", "", "x = 2\n")
    mock_client = MagicMock()
    mock_client.messages.create.return_value = MagicMock(
        content=[MagicMock(text="x = 1  # merged\n")]
    )
    adapter = AnthropicAdapter(
        api_key="fake-key",
        model="claude-sonnet-4-6",
        _client=mock_client,
    )
    result = adapter.resolve_conflict(block, ours_ts="2026-04-20", theirs_ts="2026-04-21")
    assert "x = " in result
    mock_client.messages.create.assert_called_once()


def test_clean_response_strips_markdown_fence():
    raw = "```python\ndef f():\n    return 1\n```"
    assert openai_clean(raw) == "def f():\n    return 1"
    assert anthropic_clean(raw) == "def f():\n    return 1"


def test_clean_response_passthrough_plain_code():
    raw = "def f():\n    return 1\n"
    assert openai_clean(raw) == raw.strip()
    assert anthropic_clean(raw) == raw.strip()


def test_resolve_conflict_strips_markdown_fence():
    block = _make_block("x = 1\n", "", "x = 2\n")
    mock_client = MagicMock()
    mock_client.chat.completions.create.return_value = MagicMock(
        choices=[MagicMock(message=MagicMock(content="```python\nx = 1\n```"))]
    )
    adapter = OpenAICompatibleAdapter(
        base_url="https://api.groq.com/openai/v1",
        api_key="gsk-x",
        model="mixtral",
        _client=mock_client,
    )
    result = adapter.resolve_conflict(block, ours_ts="t1", theirs_ts="t2")
    assert result == "x = 1"
    assert "```" not in result


def test_timestamp_hint_prefers_newer_ours():
    hint = _timestamp_hint("2026-04-21", "2026-04-20")
    assert "OURS" in hint
    assert "최신" in hint


def test_timestamp_hint_prefers_newer_theirs():
    hint = _timestamp_hint("2026-04-20", "2026-04-21")
    assert "THEIRS" in hint
    assert "최신" in hint


def test_timestamp_hint_equal_timestamps():
    hint = _timestamp_hint("2026-04-20", "2026-04-20")
    assert "논리적" in hint


def test_build_user_prompt_contains_timestamp_hint():
    block = _make_block("x = 1\n", "", "x = 2\n")
    prompt = build_user_prompt(block, ours_ts="2026-04-21", theirs_ts="2026-04-20")
    assert "OURS" in prompt
    assert "최신" in prompt
