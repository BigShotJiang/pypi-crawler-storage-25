"""FastMCP server exposing archive.org search, metadata, and download."""

from __future__ import annotations

import asyncio
import fnmatch
import os
from pathlib import Path
from typing import Annotated, Any
from urllib.parse import quote

from fastmcp import FastMCP
from pydantic import Field

from mcarchive_org import __version__
from mcarchive_org.client import (
    ArchiveError,
    get_shared_client,
    validate_filename,
    validate_identifier,
)

# Per-(identifier, filename) locks to serialize concurrent downloads of the same
# file inside the same process. Cross-process races would still need an fcntl
# advisory lock; a single MCP-server process is the common case.
_download_locks: dict[str, asyncio.Lock] = {}


def _download_lock_for(identifier: str, filename: str) -> asyncio.Lock:
    """Get-or-create the in-process lock for one (identifier, filename) pair.

    Safe without an outer lock because asyncio is cooperative: there are no
    awaits between the dict check and the dict set, so two coroutines can't
    interleave inside this function.
    """
    key = f"{identifier}::{filename}"
    lock = _download_locks.get(key)
    if lock is None:
        lock = asyncio.Lock()
        _download_locks[key] = lock
    return lock


def _resolve_download_root() -> Path:
    """Resolve the download root lazily so env-var changes after import are honored."""
    return Path(
        os.environ.get("MCARCHIVE_DOWNLOAD_ROOT", str(Path.cwd() / "downloads"))
    ).expanduser()

mcp = FastMCP(
    name="mcarchive-org",
    instructions=(
        "Search and download files from the Internet Archive (archive.org). "
        "Typical flow: search_items -> get_item_metadata -> list_files -> download_file. "
        "Use scrape_items (count>=100) only for bulk cursor-paginated iteration."
    ),
)


# ---------- helpers (not exposed as tools) ----------


def _human_size(n: int | str | None) -> str:
    try:
        x = float(n)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return "?"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if x < 1024:
            return f"{x:.1f} {unit}" if unit != "B" else f"{int(x)} B"
        x /= 1024
    return f"{x:.1f} PB"


def _parse_size(raw: Any) -> int | None:
    """Best-effort int parse of archive.org size fields. None if unparseable."""
    if raw is None:
        return None
    try:
        return int(str(raw).strip())
    except (TypeError, ValueError):
        return None


def _enrich_file(identifier: str, f: dict[str, Any]) -> dict[str, Any]:
    name = f.get("name", "")
    size = _parse_size(f.get("size"))
    return {
        "name": name,
        "format": f.get("format"),
        "size": size,
        "size_human": _human_size(size if size is not None else f.get("size")),
        "md5": f.get("md5"),
        "sha1": f.get("sha1"),
        "mtime": f.get("mtime"),
        "source": f.get("source"),
        "download_url": f"https://archive.org/download/{identifier}/{quote(name, safe='/')}",
    }


def _matches(name: str, format_: str | None, name_glob: str | None, formats: list[str] | None) -> bool:
    if name_glob and not fnmatch.fnmatchcase(name, name_glob):
        return False
    return not (formats and (format_ or "").lower() not in {f.lower() for f in formats})


def _normalize_collection(value: Any) -> list[str]:
    """archive.org returns `collection` as either str or list[str]. Normalize to list.

    Stable shape lets LLMs write `if 'foo' in doc['collection']` without first
    having to remember which type they're holding.
    """
    if value is None:
        return []
    if isinstance(value, str):
        return [value] if value else []
    if isinstance(value, list):
        return [str(x) for x in value if x]
    return [str(value)]


def _enrich_doc(doc: dict[str, Any]) -> dict[str, Any]:
    """Apply normalization + derived fields to a search-result doc or metadata blob."""
    out = dict(doc)
    if "collection" in out:
        out["collection"] = _normalize_collection(out["collection"])
    out["is_collection"] = out.get("mediatype") == "collection"
    return out


def _confine_dest(identifier: str, filename: str, dest_dir: str | None) -> Path:
    """Construct + verify the download destination path.

    Validates inputs, resolves the path, and asserts it lives inside the allowed
    download root. Raises ValueError on any escape attempt — never returns an
    unsafe path.
    """
    validate_identifier(identifier)
    validate_filename(filename)

    download_root = _resolve_download_root().resolve()
    if dest_dir:
        target_dir = Path(dest_dir).expanduser().resolve()
    else:
        target_dir = (download_root / identifier).resolve()

    target_dir.mkdir(parents=True, exist_ok=True)
    if target_dir.is_symlink():
        raise ValueError(f"download directory must not be a symlink: {target_dir}")

    # Build dest, then resolve and confirm containment. Path.resolve() collapses
    # '..' even on non-existent leaves, so escape attempts surface here.
    dest = (target_dir / filename).resolve()
    if not dest.is_relative_to(target_dir):
        raise ValueError(
            f"refusing destination outside target dir: {dest} not under {target_dir}"
        )
    return dest


# ---------- tools ----------


@mcp.tool
async def search_items(
    query: Annotated[str, Field(description="Lucene/Solr query, e.g. 'mediatype:audio AND creator:\"Grateful Dead\"'")],
    fields: Annotated[
        list[str] | None,
        Field(description="Which metadata fields to return per doc. Defaults to identifier,title,mediatype,creator,date."),
    ] = None,
    sort: Annotated[
        list[str] | None,
        Field(description="Sort expressions like 'downloads desc' or 'date asc'."),
    ] = None,
    rows: Annotated[int, Field(ge=1, le=200, description="Results per page (1-200).")] = 25,
    page: Annotated[int, Field(ge=1, description="1-indexed page number.")] = 1,
) -> dict[str, Any]:
    """Search archive.org items. Good for small/interactive queries.

    Returns up to `rows` matching items plus `num_found` (total hits) and `has_more`.
    Each doc has `is_collection` derived from mediatype; `collection` is always a list.
    Use scrape_items for bulk iteration over large result sets.
    """
    c = await get_shared_client()
    result = await c.search(query=query, fields=fields, sort=sort, rows=rows, page=page)
    total = result["num_found"]
    docs = [_enrich_doc(d) for d in result["docs"]]
    seen = (page - 1) * rows + len(docs)
    return {
        "query": query,
        "num_found": total,
        "page": page,
        "rows": rows,
        "has_more": seen < total,
        "docs": docs,
    }


@mcp.tool
async def scrape_items(
    query: Annotated[str, Field(description="Lucene/Solr query.")],
    fields: Annotated[list[str] | None, Field(description="Metadata fields per item.")] = None,
    sorts: Annotated[list[str] | None, Field(description="Sort expressions, e.g. ['date asc'].")] = None,
    count: Annotated[int, Field(ge=100, le=10000, description="Items per page (>=100 required by API).")] = 500,
    cursor: Annotated[str | None, Field(description="Pass the `cursor` from a prior response to fetch next page.")] = None,
) -> dict[str, Any]:
    """Scrape API — high-throughput cursor-paginated search. count >= 100.

    Response includes `cursor` (for next page) when more results exist; missing when done.
    Each item has `is_collection` derived from mediatype; `collection` is always a list.
    """
    c = await get_shared_client()
    data = await c.scrape(query=query, fields=fields, sorts=sorts, count=count, cursor=cursor)
    return {
        "items": [_enrich_doc(d) for d in data.get("items", [])],
        "count": data.get("count"),
        "total": data.get("total"),
        "next_cursor": data.get("cursor"),
    }


@mcp.tool
async def get_item_metadata(
    identifier: Annotated[str, Field(description="Archive.org item identifier, e.g. 'nasa'.")],
    include_files: Annotated[
        bool, Field(description="If true, include the full files[] array. Can be large.")
    ] = False,
) -> dict[str, Any]:
    """Get metadata for a single item.

    By default omits the (potentially huge) files[] array — call list_files for that.
    """
    return await _fetch_item_metadata(identifier, include_files=include_files)


async def _fetch_item_metadata(identifier: str, include_files: bool) -> dict[str, Any]:
    """Shared metadata-fetching logic. Used by both the tool and the MCP resource
    so neither has to depend on the other's `.fn` attribute."""
    validate_identifier(identifier)
    c = await get_shared_client()
    data = await c.metadata(identifier)

    md = data.get("metadata", {})
    mediatype = md.get("mediatype")
    out: dict[str, Any] = {
        "identifier": md.get("identifier", identifier),
        "title": md.get("title"),
        "mediatype": mediatype,
        "is_collection": mediatype == "collection",
        "collection": _normalize_collection(md.get("collection")),
        "creator": md.get("creator"),
        "date": md.get("date"),
        "description": md.get("description"),
        "publicdate": md.get("publicdate"),
        "uploader": md.get("uploader"),
        "subject": md.get("subject"),
        "licenseurl": md.get("licenseurl"),
        "item_size_bytes": data.get("item_size"),
        "item_size_human": _human_size(data.get("item_size")),
        "files_count": data.get("files_count"),
        "server": data.get("server"),
        "dir": data.get("dir"),
        "item_url": f"https://archive.org/details/{identifier}",
    }
    if include_files:
        out["files"] = [_enrich_file(identifier, f) for f in data.get("files", [])]
    return out


@mcp.tool
async def list_files(
    identifier: Annotated[str, Field(description="Archive.org item identifier.")],
    formats: Annotated[
        list[str] | None,
        Field(description="Filter by format, e.g. ['MP3','VBR MP3','JPEG']. Case-insensitive."),
    ] = None,
    name_glob: Annotated[
        str | None,
        Field(description="fnmatch-style glob on filename, e.g. '*.mp3' or 'cover.*'."),
    ] = None,
    limit: Annotated[int, Field(ge=1, le=1000, description="Max files to return.")] = 100,
) -> dict[str, Any]:
    """List files in an item, with optional format/glob filtering.

    Each entry includes a ready-to-use `download_url`.
    """
    validate_identifier(identifier)
    c = await get_shared_client()
    files = await c.files(identifier)

    matches = [
        _enrich_file(identifier, f)
        for f in files
        if _matches(f.get("name", ""), f.get("format"), name_glob, formats)
    ]
    return {
        "identifier": identifier,
        "total_matching": len(matches),
        "returned": min(len(matches), limit),
        "files": matches[:limit],
    }


@mcp.tool
def get_file_url(
    identifier: Annotated[str, Field(description="Item identifier.")],
    filename: Annotated[str, Field(description="Exact filename as shown in list_files.")],
) -> dict[str, str]:
    """Build the canonical download URL for a file without fetching anything."""
    validate_identifier(identifier)
    validate_filename(filename)
    return {
        "url": f"https://archive.org/download/{identifier}/{quote(filename, safe='/')}",
        "item_url": f"https://archive.org/details/{identifier}",
    }


@mcp.tool
async def download_file(
    identifier: Annotated[str, Field(description="Item identifier.")],
    filename: Annotated[str, Field(description="Exact filename from list_files.")],
    dest_dir: Annotated[
        str | None,
        Field(description="Directory to save into. Defaults to $MCARCHIVE_DOWNLOAD_ROOT/{identifier}."),
    ] = None,
    verify_md5: Annotated[
        str | None,
        Field(description="Expected MD5 hex digest (from list_files). If provided, checksum is verified."),
    ] = None,
    overwrite: Annotated[
        bool,
        Field(description="If false and file exists, resume the download (Range request)."),
    ] = False,
) -> dict[str, Any]:
    """Download a file to disk. Supports resume via HTTP Range when overwrite=false.

    The destination is path-confined to either `dest_dir` (when given) or
    $MCARCHIVE_DOWNLOAD_ROOT/{identifier}. Filenames containing '..', absolute
    paths, or NUL bytes are rejected before any FS or network I/O.

    Concurrent calls for the same (identifier, filename) are serialized in-process
    so two parallel tool invocations can't race on the same destination file.
    """
    dest = _confine_dest(identifier, filename, dest_dir)
    part = dest.with_name(dest.name + ".part")

    lock = _download_lock_for(identifier, filename)
    async with lock:
        if overwrite:
            # Remove both the final file AND any leftover .part — we want to start
            # truly fresh, not resume an old partial. is_symlink check first since
            # a dangling symlink reports exists()=False.
            if dest.exists() or dest.is_symlink():
                dest.unlink()
            if part.exists() or part.is_symlink():
                part.unlink()

        try:
            c = await get_shared_client()
            result = await c.download_to_file(identifier, filename, dest, verify_md5=verify_md5)
        except ArchiveError as e:
            # Re-raise with the destination context so the caller can act on it.
            raise ArchiveError(f"{e} (dest={dest})") from e

    result["identifier"] = identifier
    result["filename"] = filename
    result["size_human"] = _human_size(result.get("bytes_written"))
    return result


# ---------- runtime configuration ----------

# Paths we refuse to use as a download root no matter what — these are system
# directories where writing junk is genuinely harmful. The user's MCP client
# can usually re-launch with MCARCHIVE_DOWNLOAD_ROOT pointing anywhere they
# want at startup; this guard is just for the LLM-driven set_download_root tool.
_FORBIDDEN_ROOTS = frozenset({
    "/", "/etc", "/usr", "/bin", "/sbin", "/var", "/sys", "/proc", "/dev", "/boot", "/root",
})


def _check_root_safety(p: Path) -> None:
    s = str(p)
    if s in _FORBIDDEN_ROOTS:
        raise ValueError(f"refusing to use system directory as download root: {s}")
    for forbidden in _FORBIDDEN_ROOTS:
        if forbidden != "/" and s.startswith(forbidden + "/"):
            raise ValueError(f"refusing to use system directory as download root: {s}")


@mcp.tool
def get_download_root() -> dict[str, Any]:
    """Report the directory where download_file writes by default.

    Useful at the start of a session to confirm where files will land. The
    `source` field tells you whether the value came from the MCARCHIVE_DOWNLOAD_ROOT
    env var or from the built-in default of `./downloads` under the server's CWD.
    """
    raw_env = os.environ.get("MCARCHIVE_DOWNLOAD_ROOT")
    root = _resolve_download_root().resolve()
    return {
        "download_root": str(root),
        "exists": root.exists(),
        "writable": os.access(root, os.W_OK) if root.exists() else None,
        "source": "MCARCHIVE_DOWNLOAD_ROOT env var" if raw_env else "default (./downloads under server CWD)",
        "raw_env_value": raw_env,
    }


@mcp.tool
def set_download_root(
    path: Annotated[
        str,
        Field(description="New download root path. '~' is expanded; the directory is created if missing."),
    ],
) -> dict[str, Any]:
    """Change the download root for the rest of this MCP server session.

    Useful when running as a stdio MCP server, since you can't otherwise
    re-export environment variables to a running child process. The change
    persists until the server process exits or set_download_root is called
    again. System directories (/etc, /usr, /var, /sys, /proc, /dev, /boot,
    /root, /bin, /sbin, /) are refused.
    """
    expanded = Path(path).expanduser().resolve()
    _check_root_safety(expanded)

    previous = _resolve_download_root().resolve()
    expanded.mkdir(parents=True, exist_ok=True)
    if not os.access(expanded, os.W_OK):
        raise ValueError(f"download root not writable: {expanded}")

    os.environ["MCARCHIVE_DOWNLOAD_ROOT"] = str(expanded)
    return {
        "download_root": str(expanded),
        "previous": str(previous),
        "changed": str(expanded) != str(previous),
    }


# ---------- resources ----------


@mcp.resource("archive://item/{identifier}")
async def item_resource(identifier: str) -> dict[str, Any]:
    """Expose item metadata as a readable MCP resource."""
    return await _fetch_item_metadata(identifier, include_files=False)


# ---------- entry point ----------


def main() -> None:
    print(f"mcarchive-org v{__version__} — Internet Archive MCP server")
    mcp.run()


if __name__ == "__main__":
    main()
