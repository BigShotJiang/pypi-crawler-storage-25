"""Low-level archive.org HTTP client (pure httpx, no MCP dependencies)."""

from __future__ import annotations

import asyncio
import errno
import hashlib
import os
import random
import re
from collections.abc import AsyncIterator
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import httpx

ARCHIVE_BASE = "https://archive.org"
DEFAULT_UA = "mcarchive-org/2026.04.21 (+https://archive.org/developers/)"
# Per-chunk read timeout (60s) means a stalled stream is caught between chunks.
# Don't relax this without thinking about hung TCP connections.
DEFAULT_TIMEOUT = httpx.Timeout(30.0, read=60.0)

# Archive.org documents identifiers as [A-Za-z0-9._-], starting with alnum, max 100 chars.
_IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$")
_MAX_FILENAME = 512

# Retry policy for archive.org's transient overload responses.
_RETRY_STATUSES = frozenset({429, 502, 503, 504})
_RETRY_MAX_ATTEMPTS = 3
_RETRY_MAX_DELAY = 30.0


def _retry_delay(response: httpx.Response, attempt: int) -> float:
    """Compute backoff for a retryable response. Honors Retry-After when present."""
    retry_after = response.headers.get("Retry-After")
    if retry_after:
        try:
            return min(float(retry_after), _RETRY_MAX_DELAY)
        except ValueError:
            try:
                # HTTP-date form
                dt = parsedate_to_datetime(retry_after)
                from datetime import datetime, timezone
                wait = (dt - datetime.now(tz=timezone.utc)).total_seconds()
                return min(max(wait, 0.0), _RETRY_MAX_DELAY)
            except (TypeError, ValueError):
                pass
    # Exponential backoff with jitter: 1s, 2s, 4s + [0,1)s
    return min((2 ** attempt) + random.random(), _RETRY_MAX_DELAY)


class ArchiveError(RuntimeError):
    """Raised when archive.org returns an error payload or unexpected status."""


# ---------- input validators (defense-in-depth) ----------


def validate_identifier(identifier: str) -> str:
    """Reject identifiers that don't match archive.org's documented grammar.

    Both archive.org and the local filesystem trust this string — '/' or '..'
    in an identifier is a path-traversal vector.
    """
    if not isinstance(identifier, str) or not _IDENTIFIER_RE.match(identifier):
        raise ValueError(
            f"invalid archive.org identifier: {identifier!r} "
            f"(must match {_IDENTIFIER_RE.pattern})"
        )
    return identifier


def validate_filename(filename: str) -> str:
    """Reject filenames that could escape a download root or attack the FS.

    archive.org files[].name CAN contain forward slashes for subdirectory files
    (e.g. 'cover/back.jpg') — that's allowed. What's rejected: '..' components,
    absolute paths, NUL bytes, Windows drive letters, and excessive length.
    """
    if not isinstance(filename, str) or not filename:
        raise ValueError(f"filename must be a non-empty string, got {filename!r}")
    if len(filename) > _MAX_FILENAME:
        raise ValueError(f"filename exceeds {_MAX_FILENAME} chars")
    if "\x00" in filename:
        raise ValueError(f"filename contains NUL byte: {filename!r}")
    if filename.startswith(("/", "\\")):
        raise ValueError(f"filename must not be absolute: {filename!r}")
    if len(filename) >= 2 and filename[1] == ":":
        raise ValueError(f"filename must not be a Windows drive path: {filename!r}")
    if any(part == ".." for part in filename.replace("\\", "/").split("/")):
        raise ValueError(f"filename must not contain '..' components: {filename!r}")
    return filename


# ---------- safe filesystem open ----------


def _safe_open_for_write(dest: Path, append: bool):
    """Open dest for writing, refusing to follow a symlink at the leaf.

    Defense against the symlink-substitution race: even if our path-confinement
    check passes, a symlink at `dest` could redirect the write. O_NOFOLLOW tells
    the kernel to fail the open instead.
    """
    flags = os.O_WRONLY | os.O_CREAT
    flags |= os.O_APPEND if append else os.O_TRUNC
    nofollow = getattr(os, "O_NOFOLLOW", 0)  # not present on Windows
    flags |= nofollow
    try:
        fd = os.open(dest, flags, 0o644)
    except OSError as e:
        if nofollow and e.errno == errno.ELOOP:
            raise ArchiveError(f"refusing to write through symlink at {dest}") from e
        raise
    return os.fdopen(fd, "ab" if append else "wb")


# ---------- client ----------


class ArchiveClient:
    """Async client for the archive.org endpoints we wrap.

    - advancedsearch.php : Solr-style queries (<= ~10,000 rows paginated)
    - services/search/v1/scrape : bulk cursor pagination (count >= 100)
    - metadata/{id} : full item manifest including files[]
    - download/{id}/{file} : byte stream with HTTP Range support
    """

    def __init__(
        self,
        base_url: str = ARCHIVE_BASE,
        user_agent: str = DEFAULT_UA,
        timeout: httpx.Timeout | float = DEFAULT_TIMEOUT,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._base = base_url.rstrip("/")
        kwargs: dict[str, Any] = {
            "headers": {"User-Agent": user_agent, "Accept": "application/json"},
            "timeout": timeout,
            "follow_redirects": True,
        }
        if transport is not None:
            kwargs["transport"] = transport
        self._client = httpx.AsyncClient(**kwargs)

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> ArchiveClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    # ---------- internal: error-surfacing fetch ----------

    async def _fetch_json(self, url: str, params: Any = None) -> Any:
        """GET + JSON decode with archive.org-friendly error messages and retry.

        Retries on 429/502/503/504 with Retry-After honored. 4xx/5xx responses
        that aren't retryable include a body preview in the exception —
        invaluable for an LLM trying to fix a bad query.
        """
        r: httpx.Response | None = None
        for attempt in range(_RETRY_MAX_ATTEMPTS):
            r = await self._client.get(url, params=params)
            if r.status_code in _RETRY_STATUSES and attempt < _RETRY_MAX_ATTEMPTS - 1:
                await asyncio.sleep(_retry_delay(r, attempt))
                continue
            break
        assert r is not None  # the loop runs at least once
        if r.is_error:
            body = r.text[:500] if r.content else ""
            raise ArchiveError(f"HTTP {r.status_code} from {r.url}: {body}".strip())
        try:
            return r.json()
        except ValueError as e:
            raise ArchiveError(
                f"invalid JSON from {r.url}: {r.text[:200]!r}"
            ) from e

    # ---------- search ----------

    async def search(
        self,
        query: str,
        fields: list[str] | None = None,
        sort: list[str] | None = None,
        rows: int = 25,
        page: int = 1,
    ) -> dict[str, Any]:
        """Advanced search — best for small result sets (<=10k total)."""
        params: list[tuple[str, str]] = [
            ("q", query),
            ("output", "json"),
            ("rows", str(rows)),
            ("page", str(page)),
        ]
        for f in fields or ["identifier", "title", "mediatype", "creator", "date"]:
            params.append(("fl[]", f))
        for s in sort or []:
            params.append(("sort[]", s))

        data = await self._fetch_json(f"{self._base}/advancedsearch.php", params=params)
        resp = data.get("response", {})
        return {
            "num_found": resp.get("numFound", 0),
            "start": resp.get("start", 0),
            "page": page,
            "rows": rows,
            "docs": resp.get("docs", []),
        }

    async def scrape(
        self,
        query: str,
        fields: list[str] | None = None,
        sorts: list[str] | None = None,
        count: int = 100,
        cursor: str | None = None,
    ) -> dict[str, Any]:
        """Scrape API — cursor-paginated; count must be >= 100."""
        if count < 100:
            raise ValueError("scrape count must be >= 100; use search() for smaller queries")

        params: dict[str, str] = {"q": query, "count": str(count)}
        if fields:
            params["fields"] = ",".join(fields)
        if sorts:
            params["sorts"] = ",".join(sorts)
        if cursor:
            params["cursor"] = cursor

        data = await self._fetch_json(f"{self._base}/services/search/v1/scrape", params=params)
        if isinstance(data, dict) and "error" in data:
            raise ArchiveError(f"{data.get('errorType', 'ScrapeError')}: {data['error']}")
        return data  # keys: items, count, total, cursor (if more pages)

    # ---------- metadata ----------

    async def metadata(self, identifier: str) -> dict[str, Any]:
        """Full metadata blob for an item. Empty {} from archive.org → not found."""
        validate_identifier(identifier)
        data = await self._fetch_json(f"{self._base}/metadata/{identifier}")
        if not data:
            raise ArchiveError(f"item not found or unavailable: {identifier}")
        return data

    async def files(self, identifier: str) -> list[dict[str, Any]]:
        """Just the files[] slice — smaller payload when that's all you want."""
        validate_identifier(identifier)
        data = await self._fetch_json(f"{self._base}/metadata/{identifier}/files")
        if isinstance(data, dict):
            if "error" in data:
                raise ArchiveError(f"archive.org error for {identifier}: {data['error']}")
            if "result" in data:
                return data["result"]
        if isinstance(data, list):
            return data
        raise ArchiveError(f"unexpected files response shape for {identifier}: {type(data).__name__}")

    # ---------- download ----------

    def download_url(self, identifier: str, filename: str) -> str:
        """Build the canonical download URL. Filename is URL-encoded but '/' preserved."""
        validate_identifier(identifier)
        validate_filename(filename)
        return f"{self._base}/download/{identifier}/{quote(filename, safe='/')}"

    async def stream_file(
        self,
        identifier: str,
        filename: str,
        resume_from: int = 0,
    ) -> AsyncIterator[bytes]:
        """Async byte iterator. If resume_from > 0, requires a 206 response.

        Retries on 429/502/503/504 BEFORE yielding any bytes (so retry never
        risks corrupting a partially-written file).

        Raises ArchiveError BEFORE yielding any bytes if:
          - the server returns a non-retryable 4xx/5xx
          - resume was requested but the server returned 200 (Range ignored)
          - the Content-Range start byte doesn't match resume_from
        """
        validate_identifier(identifier)
        validate_filename(filename)

        headers = {}
        if resume_from > 0:
            headers["Range"] = f"bytes={resume_from}-"
        url = self.download_url(identifier, filename)

        for attempt in range(_RETRY_MAX_ATTEMPTS):
            async with self._client.stream("GET", url, headers=headers) as r:
                if r.status_code in _RETRY_STATUSES and attempt < _RETRY_MAX_ATTEMPTS - 1:
                    await asyncio.sleep(_retry_delay(r, attempt))
                    continue
                if r.is_error:
                    body = (await r.aread())[:500].decode("utf-8", errors="replace")
                    raise ArchiveError(f"HTTP {r.status_code} from {r.url}: {body}".strip())
                if resume_from > 0:
                    if r.status_code != 206:
                        raise ArchiveError(
                            f"server ignored Range request (got HTTP {r.status_code}); "
                            f"local file may be stale — retry download_file with overwrite=True"
                        )
                    # Verify the byte range starts where we expect. archive.org's CDN
                    # is normally well-behaved here, but trust-but-verify.
                    cr = r.headers.get("Content-Range", "")
                    m = re.match(r"bytes\s+(\d+)-", cr)
                    if m and int(m.group(1)) != resume_from:
                        raise ArchiveError(
                            f"Content-Range start {m.group(1)} != resume_from {resume_from}; "
                            f"refusing to corrupt {filename}"
                        )
                async for chunk in r.aiter_bytes(chunk_size=1 << 16):
                    yield chunk
                return

    async def download_to_file(
        self,
        identifier: str,
        filename: str,
        dest: Path,
        verify_md5: str | None = None,
        chunk_cb=None,
    ) -> dict[str, Any]:
        """Download with resume support, atomically promoted on success.

        Writes go to a `<dest>.part` staging file. On success, that staging file
        is atomically renamed to `dest` (POSIX rename is observed all-or-nothing).
        On any failure, the `.part` file remains and a follow-up call resumes
        from it — meaning the user's directory only ever contains complete files
        or `.part` files (which clearly signal incomplete state).

        - `dest` already complete (no .part) and overwrite implied false →
          early-return with `already_complete: True` (still verifies MD5 if asked).
        - `.part` exists → resume from its size, append, then promote on success.
        - Neither exists → fresh download to `.part`, promote on success.

        Caller is responsible for path confinement; this method adds O_NOFOLLOW
        defense-in-depth but does not enforce a download root.
        """
        validate_identifier(identifier)
        validate_filename(filename)

        dest.parent.mkdir(parents=True, exist_ok=True)
        # If parent is a symlink to elsewhere, refuse — our caller's confinement
        # check should already have caught this, but redundant defense is cheap.
        if dest.parent.is_symlink():
            raise ArchiveError(f"refusing to write into symlinked directory: {dest.parent}")
        # Refuse to "download over" a symlink at dest. Even though the staging
        # rename would replace (not follow) the symlink, predictable refusal is
        # better than silent symlink removal — that surprises the user and could
        # destroy a symlink farm they intentionally set up.
        if dest.is_symlink():
            raise ArchiveError(f"refusing to write through symlink at {dest}")

        part = dest.with_name(dest.name + ".part")
        # Same protection on the staging path.
        if part.is_symlink():
            raise ArchiveError(f"refusing to write through symlink at {part}")

        # Short-circuit: dest already exists complete and no .part to resume.
        if dest.exists() and not dest.is_symlink() and not part.exists():
            size = dest.stat().st_size
            result: dict[str, Any] = {
                "path": str(dest),
                "bytes_written": size,
                "resumed_from": size,
                "already_complete": True,
            }
            if verify_md5:
                # Verify the existing file matches the expected hash.
                hasher = hashlib.md5()
                with dest.open("rb") as fh:
                    while chunk := fh.read(1 << 16):
                        hasher.update(chunk)
                actual = hasher.hexdigest()
                result["md5_actual"] = actual
                result["md5_expected"] = verify_md5
                result["md5_ok"] = actual.lower() == verify_md5.lower()
            return result

        # Resume from .part if present; otherwise fresh.
        resume_from = part.stat().st_size if part.exists() and not part.is_symlink() else 0

        hasher = hashlib.md5() if verify_md5 else None
        if hasher and resume_from:
            with part.open("rb") as fh:
                while chunk := fh.read(1 << 16):
                    hasher.update(chunk)

        bytes_written = resume_from
        f = _safe_open_for_write(part, append=resume_from > 0)
        try:
            async for chunk in self.stream_file(identifier, filename, resume_from=resume_from):
                f.write(chunk)
                bytes_written += len(chunk)
                if hasher:
                    hasher.update(chunk)
                if chunk_cb:
                    chunk_cb(bytes_written)
        except (httpx.ReadError, httpx.RemoteProtocolError, httpx.ConnectError, httpx.ReadTimeout) as e:
            # H1: surface partial-state context. The .part file stays on disk
            # so a follow-up call with overwrite=False resumes from bytes_written.
            raise ArchiveError(
                f"download interrupted after {bytes_written - resume_from} new bytes "
                f"({bytes_written} total in {part.name}, resumed from {resume_from}). "
                f"Call download_file again to resume. Cause: {e!r}"
            ) from e
        finally:
            f.close()

        # Atomic promotion — only after the stream completed cleanly.
        os.replace(part, dest)

        result = {
            "path": str(dest),
            "bytes_written": bytes_written,
            "resumed_from": resume_from,
            "already_complete": False,
        }
        if verify_md5 and hasher:
            actual = hasher.hexdigest()
            result["md5_actual"] = actual
            result["md5_expected"] = verify_md5
            result["md5_ok"] = actual.lower() == verify_md5.lower()
        return result


# ---------- H7: process-wide shared client ----------
#
# An MCP server typically lives forever serving one LLM. Spinning up a fresh
# httpx.AsyncClient per tool call wastes a TCP+TLS handshake (~200-400ms) and
# burns ephemeral ports under parallel fan-out. Share one client across calls.

_shared_client: ArchiveClient | None = None


async def get_shared_client() -> ArchiveClient:
    """Return the process-wide shared ArchiveClient, creating it on first use.

    Tests should NOT use this — construct an ArchiveClient(transport=...)
    directly so MockTransport injection works without leaking into other tests.
    """
    global _shared_client
    if _shared_client is None:
        # The race window here is small. If two coroutines both create, one
        # client gets discarded — wasteful but not corrupting.
        client = ArchiveClient()
        if _shared_client is None:
            _shared_client = client
        else:
            await client.aclose()
    return _shared_client


async def close_shared_client() -> None:
    """Close and clear the shared client. Useful for tests; safe to call many times."""
    global _shared_client
    if _shared_client is not None:
        c, _shared_client = _shared_client, None
        await c.aclose()
