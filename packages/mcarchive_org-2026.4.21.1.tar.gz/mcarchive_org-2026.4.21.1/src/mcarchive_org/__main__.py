from mcarchive_org.server import main

if __name__ == "__main__":
    main()
