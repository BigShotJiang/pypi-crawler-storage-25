"""MCP server for the Internet Archive (archive.org)."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("mcarchive-org")
except PackageNotFoundError:
    __version__ = "0.0.0"
