from .cli import MediaCLI
from .media import Media


DEFAULT_SETTINGS = '''
directory: media
'''


def install(app):
    app.cliarguments.append(MediaCLI)
    app.settings.merge('media: {}')
    app.settings['media'].merge(DEFAULT_SETTINGS)
    app.media = Media()

    @app.when
    def configure(app):
        app.media.configure(app.settings.media)
