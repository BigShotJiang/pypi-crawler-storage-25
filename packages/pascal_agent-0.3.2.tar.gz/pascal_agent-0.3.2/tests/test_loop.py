"""Test the Pascal main loop — desk → decide → act → update."""

from __future__ import annotations

import json

from conftest import MockLLM

from pascal.desk import Desk
from pascal.loop import run_loop
from pascal.state import PascalStore
from pascal.types import ActionStatus, LLMResponse, Observation, Role


class TestDeskRendering:
    def test_empty_desk(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        desk = Desk(store)
        rendered = desk.render()
        assert "empty" in rendered.lower()
        store.close()

    def test_desk_shows_tasks_and_notifications(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Review PR 42", priority="urgent")
        store.push_notification(source="slack", message="New review request")
        store.set_context("mission", "Help the team ship faster")

        desk = Desk(store)
        rendered = desk.render()

        assert "Review PR 42" in rendered
        assert "slack" in rendered
        assert "Help the team ship faster" in rendered
        store.close()


class TestMainLoop:
    async def test_pick_task_and_complete(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        task_id = store.add_task("Write hello.txt")

        llm = MockLLM([
            json.dumps({"action": "pick_task", "task_id": task_id, "reason": "only pending task"}),
            json.dumps({"action": "execute", "command": "echo hello", "reason": "writing file"}),
            json.dumps({"action": "complete_task", "summary": "Created hello.txt", "reason": "done"}),
            json.dumps({"action": "wait", "reason": "nothing left"}),
        ])

        actions = await run_loop(store, llm, max_iterations=10)

        assert len(actions) == 4
        assert actions[0]["action"] == "pick_task"
        assert actions[1]["action"] == "execute"
        assert actions[2]["action"] == "complete_task"
        assert actions[3]["action"] == "wait"

        # Task should be done
        task = store.connection.execute("SELECT status FROM tasks WHERE id = ?", (task_id,)).fetchone()
        assert task["status"] == "done"

        # History should have entries
        history = store.get_recent_history()
        assert len(history) >= 3
        store.close()

    async def test_notification_interrupts_task(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        task_id = store.add_task("Long running work")
        store.activate_task(task_id)

        # Push urgent notification mid-work
        notif_id = store.push_notification(
            source="slack", message="Server is down!", priority="urgent",
        )

        llm = MockLLM([
            # Agent sees urgent notification, pauses task
            json.dumps({"action": "pause_task", "pause_reason": "urgent notification", "reason": "server down"}),
            # Handles the notification
            json.dumps({"action": "handle_notification", "notification_id": notif_id, "response": "Checking server", "reason": "urgent"}),
            # Waits (in real life, would investigate and come back)
            json.dumps({"action": "wait", "reason": "need to investigate server"}),
        ])

        actions = await run_loop(store, llm, max_iterations=10)

        assert actions[0]["action"] == "pause_task"
        assert actions[1]["action"] == "handle_notification"

        # Task should be paused
        task = store.connection.execute("SELECT status FROM tasks WHERE id = ?", (task_id,)).fetchone()
        assert task["status"] == "paused"

        # Notification should be handled
        notif = store.connection.execute("SELECT status FROM notifications WHERE id = ?", (notif_id,)).fetchone()
        assert notif["status"] == "handled"
        store.close()

    async def test_agent_adds_rule(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Set up rules")
        store.activate_task(store.get_pending_tasks()[0]["id"])

        llm = MockLLM([
            json.dumps({
                "action": "add_rule",
                "rule": "Always check tests before marking a task complete",
                "reason": "learned from experience",
            }),
            json.dumps({"action": "complete_task", "summary": "Rules set up", "reason": "done"}),
            json.dumps({"action": "wait", "reason": "done"}),
        ])

        await run_loop(store, llm, max_iterations=10)

        rules = store.get_rules()
        assert len(rules) == 1
        assert "tests" in rules[0]["rule"]
        assert rules[0]["added_by"] == "agent"
        assert rules[0]["mutable"] == 1
        store.close()

    async def test_escalation_stops_loop(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Deploy to production")

        llm = MockLLM([
            json.dumps({"action": "pick_task", "reason": "start deploy"}),
            json.dumps({
                "action": "escalate",
                "question": "Production deploy requires manager approval. Should I proceed?",
                "reason": "security policy",
            }),
        ])

        actions = await run_loop(store, llm, max_iterations=10)

        assert len(actions) == 2
        assert actions[1]["action"] == "escalate"
        assert "manager approval" in actions[1]["result"]["question"]
        store.close()

    async def test_immutable_rule_cannot_be_removed_by_agent(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        rule_id = store.add_rule("Never delete production data", mutable=False, added_by="human")

        llm = MockLLM([
            json.dumps({"action": "remove_rule", "rule_id": rule_id, "reason": "inconvenient"}),
            json.dumps({"action": "wait", "reason": "blocked"}),
        ])

        actions = await run_loop(store, llm, max_iterations=10)

        # Rule should still exist
        rules = store.get_rules()
        assert len(rules) == 1
        assert rules[0]["rule"] == "Never delete production data"
        # Remove should have failed
        assert actions[0]["result"]["removed"] is False
        store.close()


class TestSafety:
    async def test_blocked_command_returns_error(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        task_id = store.add_task("Hack the planet")
        llm = MockLLM([
            json.dumps({"action": "pick_task", "task_id": task_id, "reason": "start"}),
            json.dumps({"action": "execute", "command": "rm -rf /", "reason": "clean up"}),
            json.dumps({"action": "wait", "reason": "blocked"}),
        ])
        actions = await run_loop(store, llm, max_iterations=10)
        # Effect gate now blocks dangerous commands in pre-execute checks,
        # so the execute action is never emitted — the loop gets error feedback instead.
        action_types = [a["action"] for a in actions]
        assert "execute" not in action_types or any(
            a.get("result", {}).get("error", "") for a in actions if a["action"] == "execute"
        ), "dangerous command should be blocked"
        store.close()

    async def test_parse_errors_retry_then_stop(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))

        class BadLLM:
            async def chat(self, messages, tools=None):
                return LLMResponse(text="this is not json at all")

        actions = await run_loop(store, BadLLM(), max_iterations=10)
        # Should stop after retries, not run forever
        assert len(actions) == 0
        store.close()


class TestActiveTaskGuard:
    async def test_pick_task_pauses_current_active(self, tmp_path):
        store = PascalStore(str(tmp_path / "test.db"))
        task1 = store.add_task("First task")
        task2 = store.add_task("Second task", priority="urgent")
        store.activate_task(task1)

        llm = MockLLM([
            # Agent picks task2 while task1 is active
            json.dumps({"action": "pick_task", "task_id": task2, "reason": "urgent task"}),
            json.dumps({"action": "wait", "reason": "done"}),
        ])
        await run_loop(store, llm, max_iterations=10)

        t1 = store.connection.execute("SELECT status FROM tasks WHERE id = ?", (task1,)).fetchone()
        t2 = store.connection.execute("SELECT status FROM tasks WHERE id = ?", (task2,)).fetchone()
        assert t1["status"] == "paused"
        assert t2["status"] == "active"
        store.close()


class TestThinkLayer:
    async def test_think_before_execute(self, tmp_path):
        """LLM can think multiple times before executing."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Deploy to staging")

        llm = MockLLM([
            json.dumps({"action": "pick_task", "reason": "start deploy"}),
            json.dumps({
                "action": "think",
                "thought": "I need to check if tests pass before deploying.",
                "reason": "planning",
            }),
            json.dumps({
                "action": "think",
                "thought": "Also need to verify the staging environment is healthy.",
                "reason": "more planning",
            }),
            json.dumps({
                "action": "execute",
                "command": "echo 'running tests && deploying'",
                "reason": "plan complete, executing",
            }),
            json.dumps({"action": "complete_task", "summary": "Deployed", "reason": "done"}),
            json.dumps({"action": "wait", "reason": "done"}),
        ])

        actions = await run_loop(store, llm, max_iterations=10)

        action_types = [a["action"] for a in actions]
        assert action_types == ["pick_task", "think", "think", "execute", "complete_task", "wait"]

        # Thoughts should be recorded in history
        history = store.get_recent_history()
        think_entries = [h for h in history if h["summary"].startswith("think:")]
        assert len(think_entries) >= 2
        store.close()

    async def test_thoughts_visible_in_next_iteration(self, tmp_path):
        """In the tool-use loop, thoughts are processed as tool calls inside
        the same LLM conversation. The LLM sees previous thoughts as TOOL
        result messages in the conversation history."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Complex task")

        all_messages_per_call: list[list] = []

        class CapturingLLM:
            def __init__(self):
                self._responses = [
                    json.dumps({"action": "pick_task", "reason": "start"}),
                    json.dumps({"action": "think", "thought": "Step 1: analyze the problem", "reason": "analyzing"}),
                    json.dumps({"action": "think", "thought": "Step 2: design the solution", "reason": "designing"}),
                    json.dumps({"action": "wait", "reason": "checking thoughts"}),
                ]
                self._index = 0

            async def chat(self, messages, tools=None):
                all_messages_per_call.append(list(messages))
                if self._index >= len(self._responses):
                    return LLMResponse(text=json.dumps({"action": "wait"}))
                text = self._responses[self._index]
                self._index += 1
                return LLMResponse(text=text)

        await run_loop(store, CapturingLLM(), max_iterations=10)

        # By the time the LLM is asked for action 4 (wait), it should have
        # seen both thoughts in the message history (as TOOL results)
        assert len(all_messages_per_call) >= 4
        last_call_msgs = all_messages_per_call[-1]
        all_content = " ".join(m.content or "" for m in last_call_msgs)
        assert "Step 1: analyze the problem" in all_content or \
               any("Step 1" in (m.content or "") for m in last_call_msgs)
        assert "Step 2: design the solution" in all_content or \
               any("Step 2" in (m.content or "") for m in last_call_msgs)
        store.close()

    async def test_thoughts_cleared_after_execution(self, tmp_path):
        """Thought buffer should clear after a non-think action."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Task A")

        captured_messages: list[str] = []

        class CapturingLLM:
            def __init__(self):
                self._responses = [
                    json.dumps({"action": "pick_task", "reason": "start"}),
                    json.dumps({"action": "think", "thought": "Old thought about task A", "reason": "thinking"}),
                    json.dumps({"action": "execute", "command": "echo done", "reason": "acting"}),
                    # After execute, thoughts should be cleared
                    json.dumps({"action": "wait", "reason": "checking"}),
                ]
                self._index = 0

            async def chat(self, messages, tools=None):
                for m in messages:
                    if m.role == Role.USER:
                        captured_messages.append(m.content)
                if self._index >= len(self._responses):
                    return LLMResponse(text=json.dumps({"action": "wait"}))
                text = self._responses[self._index]
                self._index += 1
                return LLMResponse(text=text)

        await run_loop(store, CapturingLLM(), max_iterations=10)

        # The 4th call should NOT contain the old thought (cleared after execute)
        assert len(captured_messages) >= 4
        last_prompt = captured_messages[3]
        assert "Old thought about task A" not in last_prompt
        store.close()


class TestInnerLoop:
    """Tests for the multi-turn inner thinking loop (max_inner_turns > 1)."""

    async def test_inner_loop_consumes_thinks(self, tmp_path):
        """With max_inner_turns=3, think actions are consumed inside the inner loop."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Complex task")

        llm = MockLLM([
            json.dumps({"action": "pick_task", "reason": "start"}),
            # Inner loop turn 1: think (consumed internally)
            json.dumps({"action": "think", "thought": "Let me analyze first", "reason": "analyzing"}),
            # Inner loop turn 2: think (consumed internally)
            json.dumps({"action": "think", "thought": "Now I have a plan", "reason": "planning"}),
            # Inner loop turn 3: act (returned to outer loop)
            json.dumps({"action": "execute", "command": "echo hello", "reason": "acting"}),
            json.dumps({"action": "wait", "reason": "done"}),
        ])

        actions = await run_loop(store, llm, max_iterations=10, max_inner_turns=3)

        action_types = [a["action"] for a in actions]
        # pick_task (outer), think+think (inner, recorded), execute (outer), wait (outer)
        assert "pick_task" in action_types
        assert "execute" in action_types
        # Thinks should still be recorded in actions_taken
        think_count = sum(1 for a in actions if a["action"] == "think")
        assert think_count == 2
        store.close()

    async def test_inner_loop_default_single_turn(self, tmp_path):
        """With default max_inner_turns=1, behavior is identical to before."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Simple task")

        llm = MockLLM([
            json.dumps({"action": "pick_task", "reason": "start"}),
            json.dumps({"action": "think", "thought": "thinking", "reason": "plan"}),
            json.dumps({"action": "execute", "command": "echo hi", "reason": "do it"}),
            json.dumps({"action": "wait", "reason": "done"}),
        ])

        # Default max_inner_turns=1 — think goes through outer loop as before
        actions = await run_loop(store, llm, max_iterations=10)
        action_types = [a["action"] for a in actions]
        assert action_types == ["pick_task", "think", "execute", "wait"]
        store.close()

    async def test_inner_loop_exhausted_returns_last_think(self, tmp_path):
        """If all inner turns are thinks, the last think is returned to outer loop."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Hard task")

        llm = MockLLM([
            json.dumps({"action": "pick_task", "reason": "start"}),
            # All 3 inner turns are thinks — last one goes to outer loop
            json.dumps({"action": "think", "thought": "thought 1", "reason": "t1"}),
            json.dumps({"action": "think", "thought": "thought 2", "reason": "t2"}),
            json.dumps({"action": "think", "thought": "thought 3", "reason": "t3"}),
            json.dumps({"action": "wait", "reason": "done"}),
        ])

        actions = await run_loop(store, llm, max_iterations=10, max_inner_turns=3)
        # First 2 thinks consumed in inner loop, 3rd returned to outer as action
        think_count = sum(1 for a in actions if a["action"] == "think")
        assert think_count >= 2  # at least the inner thinks + possibly the returned one
        store.close()


class TestDeltaDesk:
    """Tests for differential desk rendering."""

    def test_render_static_only_queries_identity_and_rules(self, tmp_path, monkeypatch):
        store = PascalStore(str(tmp_path / "test.db"))
        store.set_context("identity", {"name": "Pascal"})
        store.add_rule("No force push", tier="policy", mutable=False)

        desk = Desk(store)

        def _fail(name: str):
            def _inner(*args, **kwargs):
                raise AssertionError(f"{name} should not be queried by render_static()")
            return _inner

        for method_name in (
            "get_active_task",
            "get_pending_tasks",
            "get_pending_notifications",
            "get_recent_history",
            "get_todos",
            "search_memories",
            "get_memories",
        ):
            monkeypatch.setattr(store, method_name, _fail(method_name))

        rendered = desk.render_static()

        assert "Pascal" in rendered
        assert "No force push" in rendered
        store.close()

    def test_render_delta_is_shorter_than_full(self, tmp_path):
        """Delta render should produce significantly fewer chars than full render."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Review PR 42", priority="urgent")
        store.set_context("mission", "Ship fast")
        store.push_notification(source="slack", message="New review")
        store.add_rule("Always run tests", tier="policy", mutable=False)

        desk = Desk(store)
        full = desk.render()
        delta = desk.render_delta()

        assert len(delta) < len(full)
        # Delta should be at least 30% shorter
        assert len(delta) < len(full) * 0.7
        store.close()

    def test_render_delta_includes_pinned_sections(self, tmp_path):
        """Delta must include mission, active task, and policy rules."""
        store = PascalStore(str(tmp_path / "test.db"))
        task_id = store.add_task("Deploy v2")
        store.activate_task(task_id)
        store.set_context("mission", "Ship quality code")
        store.add_rule("No force push", tier="policy", mutable=False)

        desk = Desk(store)
        delta = desk.render_delta()

        assert "Ship quality code" in delta
        assert "Deploy v2" in delta
        assert "No force push" in delta
        store.close()

    def test_render_delta_includes_observation(self, tmp_path):
        """Delta render should show the last observation when provided."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Test task")

        obs = Observation(
            action_type="execute",
            status=ActionStatus.OK,
            result_summary="File created successfully",
            raw_result={"output": "ok", "status": "ok"},
        )

        desk = Desk(store)
        delta = desk.render_delta(observation=obs)

        assert "execute" in delta
        assert "File created" in delta
        store.close()

    def test_render_delta_shows_urgent_notifications(self, tmp_path):
        """Urgent notifications must appear in delta (safety critical)."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.push_notification(source="telegram", message="Server is down!", priority="urgent")

        desk = Desk(store)
        delta = desk.render_delta()

        assert "URGENT" in delta
        assert "Server is down" in delta
        store.close()

    def test_render_delta_queries_only_needed_state(self, tmp_path, monkeypatch):
        store = PascalStore(str(tmp_path / "test.db"))
        task_id = store.add_task("Deploy v2")
        store.activate_task(task_id)
        store.add_todo(task_id=task_id, title="Run tests")
        store.set_context("mission", "Ship quality code")
        store.set_context("identity", {"name": "Pascal"})
        store.push_notification(source="telegram", message="Server is down!", priority="urgent")
        store.add_rule("No force push", tier="policy", mutable=False)
        store.add_memory(kind="lesson", content="Deploys need smoke tests")

        desk = Desk(store)
        active_calls = 0
        original_get_active_task = store.get_active_task

        def _counted_get_active_task(*args, **kwargs):
            nonlocal active_calls
            active_calls += 1
            return original_get_active_task(*args, **kwargs)

        def _fail(name: str):
            def _inner(*args, **kwargs):
                raise AssertionError(f"{name} should not be queried by render_delta()")
            return _inner

        monkeypatch.setattr(store, "get_active_task", _counted_get_active_task)
        for method_name in ("get_pending_tasks", "get_recent_history"):
            monkeypatch.setattr(store, method_name, _fail(method_name))

        delta = desk.render_delta()

        assert "Deploy v2" in delta
        assert active_calls == 1
        store.close()

    async def test_subsequent_outer_iterations_use_desk_update(self, tmp_path):
        """After the first outer iteration, subsequent iterations use a
        [desk update] delta prompt instead of the full desk render.

        With max_inner_turns=2 the tool-use loop caps at 2 rounds, forcing
        a second outer iteration where the delta prompt is appended."""
        store = PascalStore(str(tmp_path / "test.db"))
        store.add_task("Complex task")

        captured_user_messages: list[str] = []

        class CapturingLLM:
            def __init__(self):
                self._responses = [
                    # Outer iteration 0, tool-use round 0
                    json.dumps({"action": "pick_task", "reason": "start"}),
                    # Outer iteration 0, tool-use round 1 -> round_cap
                    json.dumps({"action": "think", "thought": "analyzing", "reason": "t1"}),
                    # Outer iteration 1 (should get [desk update])
                    json.dumps({"action": "execute", "command": "echo done", "reason": "act"}),
                    json.dumps({"action": "wait", "reason": "done"}),
                ]
                self._index = 0

            async def chat(self, messages, tools=None):
                for m in messages:
                    if m.role == Role.USER:
                        captured_user_messages.append(m.content)
                if self._index >= len(self._responses):
                    return LLMResponse(text=json.dumps({"action": "wait"}))
                text = self._responses[self._index]
                self._index += 1
                return LLMResponse(text=text)

        # max_inner_turns=2 limits tool-use rounds to 2, forcing a second
        # outer iteration which appends [desk update].
        await run_loop(store, CapturingLLM(), max_iterations=10, max_inner_turns=2)

        # The first USER message is a full desk render ("Your desk:")
        assert any("Your desk" in m for m in captured_user_messages)
        # Subsequent outer iterations append [desk update] delta messages
        desk_update_messages = [m for m in captured_user_messages if "[desk update]" in m]
        assert len(desk_update_messages) >= 1
        store.close()


class TestTodoAndMemory:
    async def test_plan_with_todos_then_execute(self, tmp_path):
        """LLM breaks work into todos, executes each, completes."""
        store = PascalStore(str(tmp_path / "test.db"))
        task_id = store.add_task("Deploy app")

        llm = MockLLM([
            json.dumps({"action": "pick_task", "task_id": task_id, "reason": "start"}),
            json.dumps({"action": "think", "thought": "I need to break this into steps", "reason": "planning"}),
            json.dumps({"action": "add_todo", "todo_title": "Run tests", "reason": "step 1"}),
            json.dumps({"action": "add_todo", "todo_title": "Build image", "reason": "step 2"}),
            json.dumps({"action": "add_todo", "todo_title": "Push to staging", "reason": "step 3"}),
            json.dumps({"action": "execute", "command": "echo tests pass", "reason": "running tests"}),
            json.dumps({"action": "complete_todo", "todo_id": "", "reason": "tests done"}),  # will fix id below
            json.dumps({"action": "complete_task", "summary": "Deployed", "reason": "all done"}),
            json.dumps({"action": "wait", "reason": "done"}),
        ])

        # Fix: we need to know the todo IDs. Run first 5 actions to create todos.
        # Actually let's just verify todos get created and the flow works.
        await run_loop(store, llm, max_iterations=15)

        # Should have created 3 todos
        todos = store.get_todos(task_id)
        assert len(todos) == 3
        assert todos[0]["title"] == "Run tests"
        assert todos[1]["title"] == "Build image"
        assert todos[2]["title"] == "Push to staging"
        store.close()

    async def test_memorize_persists_across_tasks(self, tmp_path):
        """Memories from one task are visible in the next."""
        store = PascalStore(str(tmp_path / "test.db"))
        task1 = store.add_task("First task")

        llm = MockLLM([
            json.dumps({"action": "pick_task", "task_id": task1, "reason": "start"}),
            json.dumps({
                "action": "memorize",
                "memory_kind": "lesson",
                "memory_content": "Staging deploy requires VPN",
                "reason": "learned something",
            }),
            json.dumps({"action": "complete_task", "summary": "Done", "reason": "done"}),
            json.dumps({"action": "wait", "reason": "done"}),
        ])

        await run_loop(store, llm, max_iterations=10)

        # Memory should persist (lesson + auto-memorized procedure from complete_task)
        memories = store.get_memories()
        assert len(memories) >= 1
        lesson_memories = [m for m in memories if m["kind"] == "lesson"]
        assert len(lesson_memories) == 1
        assert "VPN" in lesson_memories[0]["content"]
        assert lesson_memories[0]["source_task_id"] == task1

        # Now start a second task — desk should include the memory
        from pascal.desk import Desk
        task2 = store.add_task("Deploy to staging again")
        store.activate_task(task2)
        desk = Desk(store)
        rendered = desk.render()
        assert "Staging deploy requires VPN" in rendered
        store.close()

    async def test_desk_renders_todo_progress(self, tmp_path):
        """Desk shows todo checklist with completion status."""
        store = PascalStore(str(tmp_path / "test.db"))
        task_id = store.add_task("Build feature")
        store.activate_task(task_id)
        t1 = store.add_todo(task_id=task_id, title="Write code")
        store.add_todo(task_id=task_id, title="Write tests")
        store.add_todo(task_id=task_id, title="Deploy")
        store.complete_todo(t1)

        from pascal.desk import Desk
        desk = Desk(store)
        rendered = desk.render()

        assert "TODO (1/3 done)" in rendered
        assert "[x] Write code" in rendered
        assert "[ ] Write tests" in rendered
        assert "[ ] Deploy" in rendered
        store.close()
