"""Sandbox -- isolated command execution.

Docker (if available) → RestrictedSandbox (fallback).
Ported from Dorothy2. Zero framework dependencies.
"""

from __future__ import annotations

import logging
import os
import re
import shlex
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

_MAX_OUTPUT = 10_000

# Env vars to strip in restricted/delegate mode
_STRIPPED_ENV_KEYS = {
    "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN",
    "GOOGLE_APPLICATION_CREDENTIALS", "AZURE_CLIENT_SECRET",
    "DATABASE_URL", "DB_PASSWORD", "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY", "GITHUB_TOKEN", "NPM_TOKEN",
    "DOCKER_HOST", "KUBECONFIG",
}


@dataclass
class SandboxResult:
    ok: bool
    stdout: str = ""
    stderr: str = ""
    return_code: int = -1
    elapsed_ms: float = 0.0
    sandbox_type: str = ""
    error: str = ""

    @property
    def status(self) -> str:
        if self.error and "timeout" in self.error.lower():
            return "unknown"
        return "ok" if self.ok else "error"

    @property
    def output(self) -> str:
        return (self.stdout + self.stderr)[:2000]


class DockerSandbox:
    """Run commands in Docker with --rm, --read-only, --network none, resource limits."""

    def __init__(self, image: str = "python:3.12-slim", workspace: str = ""):
        self._image = image
        self._workspace = workspace
        self._available: bool | None = None

    def is_available(self) -> bool:
        if self._available is not None:
            return self._available
        try:
            r = subprocess.run(["docker", "info"], capture_output=True, timeout=5)
            self._available = r.returncode == 0
        except Exception:
            self._available = False
        return self._available

    def execute(self, command: str, *, timeout: int = 60, allow_network: bool = False) -> SandboxResult:
        t0 = time.time()
        cmd = [
            "docker", "run", "--rm",
            "--memory", "512m", "--cpus", "1.0", "--pids-limit", "64",
            "--read-only", "--tmpfs", "/tmp:size=100m",
        ]
        if not allow_network:
            cmd += ["--network", "none"]
        if self._workspace and os.path.isdir(self._workspace):
            cmd += ["-v", f"{os.path.realpath(self._workspace)}:/workspace", "-w", "/workspace"]
        cmd += [self._image, "sh", "-c", command]

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                                     encoding="utf-8", errors="replace")
        except subprocess.TimeoutExpired:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="docker", error=f"Timeout ({timeout}s)")
        except Exception as e:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="docker", error=f"Docker error: {e}")

        stdout, stderr = _truncate(result.stdout or ""), _truncate(result.stderr or "")
        return SandboxResult(
            ok=result.returncode == 0, stdout=stdout, stderr=stderr,
            return_code=result.returncode, elapsed_ms=(time.time() - t0) * 1000,
            sandbox_type="docker",
        )


# Patterns that indicate shell features requiring sh -c wrapping
_SHELL_FEATURES = re.compile(r"[|><;`$&]|\b&&\b|\b\|\|\b")
# Windows shell built-ins that need cmd /c
_WIN_BUILTINS = re.compile(r"^\s*(?:start|dir|copy|move|del|type|cls|set|title|assoc|ftype)\b", re.I)


def _needs_shell(command: str) -> bool:
    """Return True if the command uses shell features or Windows built-ins."""
    if _SHELL_FEATURES.search(command):
        return True
    if os.name == "nt" and _WIN_BUILTINS.search(command):
        return True
    return False


def _check_paths_in_command(command: str, workspace: str) -> str | None:
    """Check for paths outside workspace, symlinks, and relative traversal."""
    if not workspace:
        return None
    # Block symlink/junction/hardlink creation
    if re.search(r'\bln\b\s+.*-s', command):
        return "Symlink creation is not allowed in restricted sandbox"
    if re.search(r'\bmklink\b', command, re.I):
        return "mklink is not allowed in restricted sandbox"
    if re.search(r'New-Item.*SymbolicLink', command, re.I):
        return "Symlink creation is not allowed in restricted sandbox"
    # Block relative traversal patterns
    if re.search(r'\.\.[/\\]', command):
        return "Relative path traversal (../) is not allowed in restricted sandbox"
    ws = Path(workspace).resolve()
    # Find absolute paths: unquoted, single-quoted, and double-quoted
    # Pattern 1: unquoted paths (original)
    # Pattern 2: paths inside quotes (new — catches python -c "open('/etc/passwd')")
    path_patterns = [
        r'(?:^|\s)(/[\w./-]+|[a-zA-Z]:\\[\w.\\ /-]+)',           # unquoted
        r"""['"](/[\w./ -]+|[a-zA-Z]:\\[\w.\\ /-]+)['"]""",       # quoted
    ]
    for pattern in path_patterns:
        for match in re.finditer(pattern, command):
            path_str = match.group(1) if match.lastindex else match.group().strip()
            try:
                resolved = Path(path_str).resolve()
                if not (resolved == ws or resolved.is_relative_to(ws)):
                    return f"Path '{path_str}' is outside workspace '{ws}'"
            except (OSError, ValueError):
                continue
    return None


# Track temp directories created by make_safe_env for cleanup
_sandbox_temp_dirs: list[str] = []
_SANDBOX_TEMP_MAX = 50  # trigger cleanup when this many accumulate


def make_safe_env() -> tuple[dict[str, str], str]:
    """Create a stripped env dict + temp HOME. Shared by sandbox and delegate.

    Temp directories are tracked and cleaned up periodically via cleanup_sandbox_temps().
    """
    safe_env = {}
    for k, v in os.environ.items():
        if k.upper() in _STRIPPED_ENV_KEYS:
            continue
        k_up = k.upper()
        if any(pat in k_up for pat in ("SECRET", "TOKEN", "PASSWORD", "CREDENTIAL", "PRIVATE_KEY")):
            continue
        safe_env[k] = v
    tmp_home = tempfile.mkdtemp(prefix="pascal_sandbox_")
    _sandbox_temp_dirs.append(tmp_home)
    # Proactive cleanup: remove old temp dirs when too many accumulate
    if len(_sandbox_temp_dirs) > _SANDBOX_TEMP_MAX:
        cleanup_sandbox_temps(keep_last=5)
    safe_env["HOME"] = tmp_home
    safe_env["TMPDIR"] = tmp_home
    # Windows: also override user profile and temp directories
    if os.name == "nt":
        safe_env["USERPROFILE"] = tmp_home
        safe_env["TEMP"] = tmp_home
        safe_env["TMP"] = tmp_home
        safe_env["APPDATA"] = os.path.join(tmp_home, "AppData", "Roaming")
        safe_env["LOCALAPPDATA"] = os.path.join(tmp_home, "AppData", "Local")
    return safe_env, tmp_home


def cleanup_sandbox_temps(keep_last: int = 0) -> int:
    """Remove tracked sandbox temp directories. Returns count removed."""
    import shutil
    removed = 0
    to_remove = _sandbox_temp_dirs[:-keep_last] if keep_last else list(_sandbox_temp_dirs)
    for tmp_dir in to_remove:
        try:
            if os.path.isdir(tmp_dir):
                shutil.rmtree(tmp_dir, ignore_errors=True)
                removed += 1
        except Exception:
            pass
        if tmp_dir in _sandbox_temp_dirs:
            _sandbox_temp_dirs.remove(tmp_dir)
    return removed


class RestrictedSandbox:
    """Subprocess with stripped env vars, workspace boundary, temp HOME."""

    def __init__(self, workspace: str = ""):
        self._workspace = workspace

    def execute(self, command: str, *, timeout: int = 60) -> SandboxResult:
        t0 = time.time()
        cwd = self._workspace if self._workspace and os.path.isdir(self._workspace) else None

        # Path boundary check: block absolute paths outside workspace
        path_err = _check_paths_in_command(command, self._workspace)
        if path_err:
            return SandboxResult(ok=False, elapsed_ms=0, sandbox_type="restricted",
                                 error=path_err)

        safe_env, tmp_home = make_safe_env()

        # shell=False by default; wrap with shell when needed
        if _needs_shell(command):
            cmd: list[str] | str = ["cmd", "/c", command] if os.name == "nt" else ["sh", "-c", command]
        else:
            try:
                cmd = shlex.split(command)
            except ValueError:
                # Malformed command -- fall back to platform-appropriate shell
                cmd = ["cmd", "/c", command] if os.name == "nt" else ["sh", "-c", command]

        try:
            result = subprocess.run(
                cmd, shell=False, capture_output=True, text=True,
                timeout=timeout, cwd=cwd, env=safe_env,
                encoding="utf-8", errors="replace",
            )
        except subprocess.TimeoutExpired:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="restricted", error=f"Timeout ({timeout}s)")
        except FileNotFoundError as e:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="restricted", error=f"Command not found: {e}")
        except Exception as e:
            return SandboxResult(ok=False, elapsed_ms=(time.time() - t0) * 1000,
                                 sandbox_type="restricted", error=f"Execution error: {e}")
        finally:
            # Clean up this invocation's temp dir immediately
            import shutil as _shutil
            try:
                if os.path.isdir(tmp_home):
                    _shutil.rmtree(tmp_home, ignore_errors=True)
                if tmp_home in _sandbox_temp_dirs:
                    _sandbox_temp_dirs.remove(tmp_home)
            except Exception:
                pass

        stdout, stderr = _truncate(result.stdout or ""), _truncate(result.stderr or "")
        return SandboxResult(
            ok=result.returncode == 0, stdout=stdout, stderr=stderr,
            return_code=result.returncode, elapsed_ms=(time.time() - t0) * 1000,
            sandbox_type="restricted",
        )


class SandboxManager:
    """Auto-selects Docker if available, falls back to Restricted."""

    def __init__(self, workspace: str = "", prefer_docker: bool = True):
        self._docker = DockerSandbox(workspace=workspace)
        self._restricted = RestrictedSandbox(workspace=workspace)
        self._prefer_docker = prefer_docker

    def run(self, command: str, *, timeout: int = 60, allow_network: bool = False) -> SandboxResult:
        if self._prefer_docker and self._docker.is_available():
            result = self._docker.execute(command, timeout=timeout, allow_network=allow_network)
            if not result.ok and "Docker" in result.error:
                return self._restricted.execute(command, timeout=timeout)
            return result
        return self._restricted.execute(command, timeout=timeout)



def _truncate(text: str) -> str:
    if len(text) <= _MAX_OUTPUT:
        return text
    return text[:_MAX_OUTPUT] + f"\n... [truncated, {len(text)} chars total]"
