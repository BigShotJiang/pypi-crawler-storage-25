"""Pascal -- autonomous AI employee built on a working-document loop."""

__version__ = "0.3.2"
