"""MCP client -- connect to external tool servers (Slack, Gmail, GitHub, etc.).

Usage in pascal.toml or env:
  [[pascal.mcp_servers]]
  name = "slack"
  command = "npx"
  args = ["-y", "@anthropic/slack-mcp"]
  env = {SLACK_TOKEN = "xoxb-..."}

Or programmatically:
  manager = MCPManager()
  await manager.connect_all([MCPServerConfig(name="slack", command="npx", args=[...])])
  result = await manager.call_tool("slack_post_message", {"channel": "#general", "text": "hi"})
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import AsyncExitStack
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

_CONNECT_TIMEOUT = 30.0


@dataclass
class MCPServerConfig:
    name: str
    command: str
    args: list[str] = field(default_factory=list)
    env: dict[str, str] | None = None


@dataclass
class MCPToolSpec:
    """Discovered tool from an MCP server."""
    name: str
    description: str
    parameters: dict[str, Any]
    server_name: str
    side_effects: bool = True


class MCPConnection:
    """Single MCP server connection."""

    def __init__(self, config: MCPServerConfig) -> None:
        self.config = config
        self.name = config.name
        self._session = None
        self._exit_stack: AsyncExitStack | None = None
        self._tools: list[MCPToolSpec] = []

    async def connect(self) -> None:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        stack = AsyncExitStack()
        try:
            server_params = StdioServerParameters(
                command=self.config.command,
                args=self.config.args,
                env=self.config.env or None,
            )
            transport = await asyncio.wait_for(
                stack.enter_async_context(stdio_client(server_params)),
                timeout=_CONNECT_TIMEOUT,
            )
            read_stream, write_stream = transport
            session = await stack.enter_async_context(ClientSession(read_stream, write_stream))
            await asyncio.wait_for(session.initialize(), timeout=_CONNECT_TIMEOUT)

            # Discover tools (with pagination)
            tools = []
            cursor = None
            while True:
                response = await asyncio.wait_for(
                    session.list_tools(cursor=cursor), timeout=_CONNECT_TIMEOUT,
                )
                for tool in response.tools:
                    side_effects = True
                    annotations = getattr(tool, "annotations", None)
                    if annotations and getattr(annotations, "readOnlyHint", None) is True:
                        side_effects = False
                    tools.append(MCPToolSpec(
                        name=tool.name,
                        description=tool.description or "",
                        parameters=tool.inputSchema if hasattr(tool, "inputSchema") else {},
                        server_name=self.name,
                        side_effects=side_effects,
                    ))
                cursor = getattr(response, "nextCursor", None)
                if not cursor:
                    break

            self._exit_stack = stack
            self._session = session
            self._tools = tools
            logger.info("MCP [%s]: connected, %d tools", self.name, len(tools))
        except BaseException:
            await stack.aclose()
            raise

    async def disconnect(self) -> None:
        if self._exit_stack:
            try:
                await self._exit_stack.aclose()
            except Exception:
                logger.warning("MCP [%s]: disconnect error", self.name, exc_info=True)
            finally:
                self._session = None
                self._exit_stack = None
                self._tools = []

    @property
    def tools(self) -> list[MCPToolSpec]:
        return list(self._tools)

    async def call_tool(self, name: str, params: dict[str, Any]) -> dict[str, Any]:
        if not self._session:
            return {"ok": False, "output": "", "error": f"MCP [{self.name}] not connected"}
        # Retry with backoff on transient errors
        last_exc = None
        for attempt in range(3):
            try:
                result = await self._session.call_tool(name, params)
                break
            except Exception as e:
                last_exc = e
                e_str = str(e).lower()
                if any(kw in e_str for kw in ("timeout", "connection", "reset", "broken")):
                    wait = min(2 ** attempt, 10)
                    logger.warning("MCP [%s] tool %s transient error, retry in %ds: %s", self.name, name, wait, e)
                    import asyncio
                    await asyncio.sleep(wait)
                    continue
                return {"ok": False, "output": "", "error": str(e)}
        else:
            return {"ok": False, "output": "", "error": f"MCP [{self.name}] {name} failed after retries: {last_exc}"}
        try:
            is_error = getattr(result, "isError", False)
            parts = []
            for content in result.content:
                if hasattr(content, "text"):
                    parts.append(content.text)
                elif hasattr(content, "data"):
                    parts.append(f"[binary: {getattr(content, 'mimeType', 'unknown')}]")
                else:
                    parts.append(repr(content))
            output = "\n".join(parts)
            return {"ok": not is_error, "output": output, "error": output if is_error else ""}
        except Exception as e:
            logger.error("MCP [%s] tool %s failed: %s", self.name, name, e)
            return {"ok": False, "output": "", "error": str(e)}


class MCPManager:
    """Manage multiple MCP server connections."""

    def __init__(self) -> None:
        self._connections: dict[str, MCPConnection] = {}
        self._tool_map: dict[str, MCPConnection] = {}

    async def connect_all(self, configs: list[MCPServerConfig]) -> None:
        for cfg in configs:
            conn = MCPConnection(cfg)
            try:
                await conn.connect()
                self._connections[cfg.name] = conn
                for tool in conn.tools:
                    if tool.name not in self._tool_map:
                        self._tool_map[tool.name] = conn
            except Exception:
                logger.debug("MCP [%s]: connection failed (optional)", cfg.name)

    async def disconnect_all(self) -> None:
        for conn in self._connections.values():
            await conn.disconnect()
        self._connections.clear()
        self._tool_map.clear()

    def all_tool_specs(self) -> list[MCPToolSpec]:
        seen: set[str] = set()
        specs: list[MCPToolSpec] = []
        for conn in self._connections.values():
            for tool in conn.tools:
                if tool.name not in seen:
                    specs.append(tool)
                    seen.add(tool.name)
        return specs

    async def call_tool(self, name: str, params: dict[str, Any]) -> dict[str, Any]:
        conn = self._tool_map.get(name)
        if conn is None:
            return {"ok": False, "output": "", "error": f"MCP tool '{name}' not found"}
        return await conn.call_tool(name, params)

    @property
    def connected_servers(self) -> list[str]:
        return list(self._connections.keys())

    def has_tool(self, name: str) -> bool:
        return name in self._tool_map
