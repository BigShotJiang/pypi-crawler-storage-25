# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-manifest>

import typer
from rich.console import Console

console = Console()
app = typer.Typer(help="CoReason ISV License Administration Control Plane")


@app.command("init-vault")
def distr_init_vault() -> None:
    """The Key Generation Ceremony: Generate and vault the Master Cryptographic Keys."""
    from coreason_isv_admin.auth.distr_provisioning import init_vault

    try:
        init_vault()
        console.print(
            "[bold green]✓ Key Generation Ceremony Complete. Vault initialized.[/bold green]"
        )
    except Exception as e:
        console.print(f"[bold red]✗ Vault Initialization Failed:[/bold red] {e}")


@app.command("issue-license")
def distr_issue_license(
    tenant_cid: str = typer.Option(
        ..., help="The client's Tenant ID (e.g., 'tenant-xyz')"
    ),
    entitlements: list[str] = typer.Option(
        ["COMMERCIAL_USE"],
        help="List of entitlements (e.g., 'COMMERCIAL_USE', 'PRIVATE_LEDGER')",
    ),
    valid_days: int = typer.Option(365, help="Validity duration in days"),
    hardware_zk_proof: str = typer.Option(
        None, help="Optional zk-SNARK proof for hardware binding"
    ),
) -> None:
    """Issue a CommercialOverrideReceipt (Signed VCDM v2.0 JWT) for a client."""
    from coreason_isv_admin.auth.distr_provisioning import issue_license

    try:
        token = issue_license(tenant_cid, entitlements, valid_days, hardware_zk_proof)
        console.print(
            "[bold green]✓ CommercialOverrideReceipt Issued Successfully.[/bold green]\n"
        )
        console.print(f"[bold cyan]Token:[/bold cyan] {token}")
    except Exception as e:
        console.print(f"[bold red]✗ License Issuance Failed:[/bold red] {e}")


@app.command("serve-api")
def distr_serve_api(
    port: int = typer.Option(8000, help="Port to run the Distr API on"),
    host: str = typer.Option("127.0.0.1", help="Host IP to bind to"),
) -> None:
    """Run the Distr FastAPI backend for the Vite Web Dashboard."""
    import uvicorn

    console.print(
        f"[bold green]Starting Distr API on http://{host}:{port}[/bold green]"
    )
    uvicorn.run(
        "coreason_isv_admin.auth.distr_api:app", host=host, port=port, reload=True
    )


def main() -> None:
    app()


if __name__ == "__main__":
    main()
