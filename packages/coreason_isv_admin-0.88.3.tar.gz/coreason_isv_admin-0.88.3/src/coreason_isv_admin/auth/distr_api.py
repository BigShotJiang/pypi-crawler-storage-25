# Copyright (c) 2026 CoReason, Inc

#

# This software is proprietary and dual-licensed

# Licensed under the Prosperity Public License 3.0 (the "License")

# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0

# For details, see the LICENSE file

# Commercial use beyond a 30-day trial requires a separate license

#

# Source Code: https://github.com/CoReason-AI/coreason-isv-admin


from typing import Any
import json
import nats
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.responses import StreamingResponse
import httpx

from fastapi.middleware.cors import CORSMiddleware

from pydantic import BaseModel


from coreason_isv_admin.auth.distr_provisioning import (
    init_vault,
    issue_license,
    get_master_key_file,
)


import base64

from cryptography.hazmat.primitives import serialization


from coreason_manifest.spec.ontology import CoreasonBaseState


import os

import secrets

import logging

from fastapi import Security, Depends

from fastapi.security import APIKeyHeader


logger = logging.getLogger("distr_api")


# API Key Verification setup

API_KEY_NAME = "X-API-Key"

api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)


# Load API key from environment, defaulting to a secure random one if not set

FALLBACK_API_KEY = secrets.token_hex(32)

COREASON_API_KEY = os.environ.get("COREASON_API_KEY") or FALLBACK_API_KEY


if not os.environ.get("COREASON_API_KEY"):
    logger.warning(
        f"COREASON_API_KEY not configured. Generated a dynamic fallback API key: {COREASON_API_KEY}"
    )


def verify_api_key(request: Request, api_key: str = Security(api_key_header)) -> None:
    # First check if X-API-Key is present and valid
    if api_key and api_key == COREASON_API_KEY:
        return

    # Check Authorization header for Bearer token from sensory app
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        try:
            token = auth_header.split(" ")[1]
            from coreason_isv_admin.auth import jwt_compat

            jwt_compat.decode(token, options={"verify_signature": False})
            return
        except Exception as e:
            raise HTTPException(status_code=403, detail=f"Invalid Bearer Token: {e}")

    raise HTTPException(status_code=403, detail="Could not validate credentials")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Establish persistent client pool upon server boot
    app.state.client = httpx.AsyncClient(
        limits=httpx.Limits(max_keepalive_connections=50, max_connections=200),
        timeout=httpx.Timeout(30.0, read=None),
    )
    yield
    # Safely drain and terminate connections on shutdown
    await app.state.client.aclose()


app = FastAPI(title="Distr License Provisioning API", lifespan=lifespan)


def _get_proxy_client(request: Request) -> httpx.AsyncClient:
    """Retrieve the shared client from app state or fall back if not initialized."""
    client = getattr(request.app.state, "client", None)
    if client is None or client.is_closed:
        return httpx.AsyncClient(
            limits=httpx.Limits(max_keepalive_connections=50, max_connections=200),
            timeout=httpx.Timeout(30.0, read=None),
        )
    return client


# Enable CORS for the local Vite dashboard and sensory app

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class IssueLicenseRequest(BaseModel):
    tenant_cid: str

    entitlements: list[str]

    valid_days: int = 365

    hardware_zk_proof: str | None = None


@app.get("/api/vault/status", dependencies=[Depends(verify_api_key)])
def get_vault_status() -> dict[str, Any]:
    """Check if the master key vault has been initialized."""

    return {"initialized": get_master_key_file().exists()}


@app.post("/api/vault/init", dependencies=[Depends(verify_api_key)])
def initialize_vault() -> dict[str, Any]:
    """Perform the Key Generation Ceremony."""

    try:
        init_vault()

        return {
            "status": "success",
            "message": "Key Generation Ceremony Complete. Vault initialized.",
        }

    except FileExistsError:
        raise HTTPException(status_code=400, detail="Vault already initialized.")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/license/issue", dependencies=[Depends(verify_api_key)])
def issue_new_license(request: IssueLicenseRequest) -> dict[str, Any]:
    """Issue a CommercialOverrideReceipt."""

    try:
        token = issue_license(
            tenant_cid=request.tenant_cid,
            entitlements=request.entitlements,
            valid_days=request.valid_days,
            hardware_zk_proof=request.hardware_zk_proof,
        )

        return {"status": "success", "token": token}

    except FileNotFoundError:
        raise HTTPException(status_code=400, detail="Vault not initialized.")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/v1/forge/intent", dependencies=[Depends(verify_api_key)])
async def proxy_forge_intent(intent: dict[str, Any]) -> dict[str, Any]:
    """
    Bridge GeometricSchemaIntent HTTP payload to NATS as EpistemicDeficitEvent.
    """
    # 1. Parse and extract domain type and capability name to form a valid action_space URN
    domain_val = intent.get("domain") or "solver"
    domain_parts = domain_val.split(":")
    type_str = domain_parts[-1] if domain_parts else "solver"

    allowed_types = {"oracle", "solver", "effector", "substrate", "sensory", "node"}
    if type_str not in allowed_types:
        type_str = "solver"

    capability_name = intent.get("capability") or "custom_capability"
    action_space_id = f"urn:coreason:actionspace:{type_str}:{capability_name}:v1"

    # 2. Build the EpistemicDeficitEvent payload
    geometric_schema = intent.get("schema") or {}
    metadata = intent.get("metadata") or {}

    agent_instruction = (
        metadata.get("instruction") or "Generate a logic actuator bounded by schema."
    )
    causal_affordance = (
        metadata.get("causal_affordance")
        or "Executes a defeasible cascade to resolve the deficit."
    )
    epistemic_bounds = (
        metadata.get("epistemic_bounds")
        or "Bounded by tenant-specific validation parameters."
    )

    deficit_event = {
        "action_space_id": action_space_id,
        "geometric_schema": geometric_schema,
        "agent_instruction": agent_instruction,
        "causal_affordance": causal_affordance,
        "epistemic_bounds": epistemic_bounds,
    }

    # 3. Publish to NATS
    nats_url = os.environ.get("COREASON_NATS_URL") or "nats://localhost:4222"
    try:
        nc = await nats.connect(nats_url)
        await nc.publish(
            "coreason.telemetry.epistemic_deficit",
            json.dumps(deficit_event).encode("utf-8"),
        )
        await nc.drain()
        await nc.close()
        return {
            "status": "success",
            "action_space_id": action_space_id,
            "message": "Intent published to NATS for forging",
        }
    except Exception as e:
        logger.error(f"NATS telemetry dispatch failed: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"NATS telemetry dispatch failed: {e}",
        )


@app.get("/.well-known/jwks.json")
def get_jwks() -> dict[str, Any]:
    """Provide the JWKS for Authlib in coreason-runtime."""

    try:
        with open(get_master_key_file(), "rb") as f:
            private_key = serialization.load_pem_private_key(f.read(), password=None)

        public_bytes = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
        )

        x_b64 = base64.urlsafe_b64encode(public_bytes).decode("ascii").rstrip("=")

        return {
            "keys": [
                {
                    "kty": "OKP",
                    "crv": "Ed25519",
                    "x": x_b64,
                    "use": "sig",
                    "kid": "master-key",
                }
            ]
        }

    except FileNotFoundError:
        raise HTTPException(
            status_code=404, detail="Vault not initialized. Run key generation."
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/v1/capabilities/schema")
def get_capabilities_schema() -> dict[str, Any]:
    """Serve the CoreasonBaseState ontology JSON schema for DynamicToposRenderer."""

    return {
        "schema": CoreasonBaseState.model_json_schema(),
        "uiSchema": {},
    }


# --- Gateway Reverse Proxy to coreason-runtime (Port 8080) ---


@app.api_route("/api/v1/telemetry/stream", methods=["GET"])
async def proxy_telemetry_stream(request: Request):
    """Transparently proxy the SSE telemetry stream to coreason-runtime on Port 8080."""
    headers = {k: v for k, v in request.headers.items() if k.lower() != "host"}
    client = _get_proxy_client(request)

    async def event_generator():
        try:
            async with client.stream(
                method="GET",
                url="http://localhost:8080/api/v1/telemetry/stream",
                headers=headers,
                timeout=None,
            ) as r:
                async for chunk in r.aiter_raw():
                    yield chunk
        except Exception as e:
            logger.error(f"Error proxying telemetry stream: {e}")

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.api_route("/api/v1/auth/verifications", methods=["GET"])
async def proxy_auth_verifications(request: Request):
    """Transparently proxy the SSE auth verifications stream to coreason-runtime on Port 8080."""
    headers = {k: v for k, v in request.headers.items() if k.lower() != "host"}
    client = _get_proxy_client(request)

    async def event_generator():
        try:
            async with client.stream(
                method="GET",
                url="http://localhost:8080/api/v1/auth/verifications",
                headers=headers,
                timeout=None,
            ) as r:
                async for chunk in r.aiter_raw():
                    yield chunk
        except Exception as e:
            logger.error(f"Error proxying auth verifications stream: {e}")

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.api_route("/api/v1/state/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
@app.api_route("/api/v1/oracle/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
@app.api_route("/api/v1/capabilities", methods=["GET"])
@app.api_route("/api/v1/capabilities/execute", methods=["POST"])
@app.api_route("/api/v1/crystallize", methods=["POST"])
@app.api_route("/api/v1/kb/publish", methods=["POST"])
@app.api_route("/api/v1/override", methods=["POST"])
@app.api_route("/api/v1/approve", methods=["POST"])
@app.api_route("/api/v1/telemetry/egress-blocks", methods=["GET"])
@app.api_route("/api/v1/topology/semantic-space", methods=["GET"])
@app.api_route("/api/v1/approve/challenge", methods=["POST"])
@app.api_route("/api/v1/diagnostics/{path:path}", methods=["POST"])
@app.api_route("/api/v1/assets/{path:path}", methods=["GET"])
@app.api_route("/api/v1/history/states", methods=["GET"])
@app.api_route("/api/v1/history/simulations/fork", methods=["POST"])
@app.api_route("/api/v1/auth/profile/layout", methods=["GET", "POST"])
async def catch_all_proxy(request: Request):
    """Forward requests to the backend runtime on Port 8080."""
    path = request.url.path
    query = request.url.query
    url = f"{path}?{query}" if query else path

    headers = {k: v for k, v in request.headers.items() if k.lower() != "host"}
    body = await request.body()
    client = _get_proxy_client(request)

    try:
        response = await client.request(
            method=request.method,
            url=f"http://localhost:8080{url}",
            headers=headers,
            content=body,
            timeout=30.0,
        )
        # Exclude standard headers that fastapi/uvicorn will handle or rewrite
        excluded_headers = {
            "content-length",
            "content-encoding",
            "transfer-encoding",
        }
        resp_headers = {
            k: v
            for k, v in response.headers.items()
            if k.lower() not in excluded_headers
        }
        return Response(
            content=response.content,
            status_code=response.status_code,
            headers=resp_headers,
        )
    except httpx.RequestError as exc:
        logger.error(f"Proxy connection failed to coreason-runtime on Port 8080: {exc}")
        raise HTTPException(
            status_code=502, detail=f"Runtime API proxy connection failed: {exc}"
        )
