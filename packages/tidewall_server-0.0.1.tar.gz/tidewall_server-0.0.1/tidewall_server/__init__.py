"""Placeholder for the Tidewall Server package.

The real implementation lives at https://github.com/tidewall-security/tidewall-server
and is not yet released to PyPI.
"""

__version__ = "0.0.1"
