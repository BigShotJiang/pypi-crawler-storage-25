# tidewall-server

> Placeholder release — the real Tidewall server is not yet on PyPI.

`tidewall-server` is an open-source AI security guard server: prompt-injection
detection, PII redaction, secrets scanning, malicious-entity defang, OCSF event
export, multi-policy management, and a built-in web dashboard.

Until the first PyPI release ships, install from source:

```bash
git clone https://github.com/tidewall-security/tidewall-server.git
cd tidewall-server
uv sync
uvicorn app.main:app --port 8080
```

Project home: https://tidewall.ai
