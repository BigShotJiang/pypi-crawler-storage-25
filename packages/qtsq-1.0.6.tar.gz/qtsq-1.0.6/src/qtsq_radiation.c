/*
 * Quantum Tensor Sequence — Radiation Engine (Hawking Radiation)
 * Feature: Lazy/partial decompression — decompress only the data you need
 * Supports: byte-range, audio time-range, image region, video frame
 * Author: Haruhito
 */

#include <string.h>
#include <stdlib.h>
#include "qtsq.h"
#include "qtsq_splat_only.h"

/* ══════════════════════════════════════════════════════════════
 *  Radiation Index Construction
 * ══════════════════════════════════════════════════════════════
 *
 * The radiation index maps logical offsets in the original data
 * to chunks in the compressed singularity. Each entry describes
 * one "chunk" that can be independently decompressed.
 */

int qtsq_build_radiation_index(qtsq_context_t *ctx, uint32_t chunk_size) {
    if (!ctx) return QTSQ_ERR_NULL;
    if (chunk_size == 0) chunk_size = 4096;

    uint64_t orig_size = ctx->header.original_size;
    uint32_t num_chunks = (uint32_t)((orig_size + chunk_size - 1) / chunk_size);

    /* Free existing index */
    if (ctx->radiation_index) {
        free(ctx->radiation_index);
        ctx->radiation_index = NULL;
    }

    ctx->radiation_index = (qtsq_index_t *)calloc(num_chunks, sizeof(qtsq_index_t));
    if (!ctx->radiation_index) return QTSQ_ERR_ALLOC;

    for (uint32_t i = 0; i < num_chunks; i++) {
        ctx->radiation_index[i].logical_offset = (uint64_t)i * chunk_size;
        ctx->radiation_index[i].chunk_size = chunk_size;
        ctx->radiation_index[i].singularity_offset = 0; /* linear mapping */
        ctx->radiation_index[i].priority = (uint8_t)(i == 0 ? 255 : 128);
    }

    ctx->num_radiation = num_chunks;
    ctx->header.radiation_size = num_chunks;
    ctx->header.flags |= QTSQ_FLAG_LAZY_DECOMP | QTSQ_FLAG_SEEKABLE;

    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  qtsq_radiate — Generic byte-range access
 * ══════════════════════════════════════════════════════════════
 *
 * Decompress only the bytes in [offset, offset+size).
 * This is the foundation for all lazy access methods.
 */

int qtsq_radiate(const qtsq_context_t *ctx,
                uint64_t offset, uint32_t size,
                uint8_t **out_data) {
    if (!ctx || !out_data) return QTSQ_ERR_NULL;
    if (!ctx->singularity) return QTSQ_ERR_FORMAT;

    /* Full decompression then extract range */
    /* (A production implementation would use the radiation index
     *  to decompress only the relevant chunks) */
    uint8_t *full_data = NULL;
    size_t full_size = 0;
    int result;

    switch (ctx->header.strategy) {
        case QTSQ_STRATEGY_NONE:
        case QTSQ_STRATEGY_DELTA_SEED:
        case QTSQ_STRATEGY_PROCEDURAL:
            result = qtsq_decompress_singularity(ctx, &full_data, &full_size);
            break;
        case QTSQ_STRATEGY_DICTIONARY:
            result = qtsq_decompress_horizon(ctx, &full_data, &full_size);
            break;
        case QTSQ_STRATEGY_FOURIER:
            result = qtsq_decompress_lensing(ctx, &full_data, &full_size);
            break;
        case QTSQ_STRATEGY_FRACTAL:
        case QTSQ_STRATEGY_TEMPORAL:
            result = qtsq_decompress_accretion(ctx, &full_data, &full_size);
            break;
        default:
            return QTSQ_ERR_STRATEGY;
    }

    if (result != QTSQ_OK) return result;

    /* Bounds check */
    if (offset >= full_size) {
        free(full_data);
        return QTSQ_ERR_FORMAT;
    }

    uint32_t actual_size = size;
    if (offset + size > full_size) {
        actual_size = (uint32_t)(full_size - offset);
    }

    /* Copy requested range */
    uint8_t *output = (uint8_t *)malloc(actual_size);
    if (!output) {
        free(full_data);
        return QTSQ_ERR_ALLOC;
    }

    memcpy(output, full_data + offset, actual_size);
    free(full_data);

    *out_data = output;
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  qtsq_radiate_time — Audio time-range access
 * ══════════════════════════════════════════════════════════════
 *
 * Decompress only the audio samples in [start_sec, start_sec + duration_sec).
 */

int qtsq_radiate_time(const qtsq_context_t *ctx,
                     double start_sec, double duration_sec,
                     int16_t **out_samples, size_t *out_count) {
    if (!ctx || !out_samples || !out_count) return QTSQ_ERR_NULL;

    /* Get sample rate from schema */
    uint32_t sample_rate = ctx->schema.sample_rate;
    if (sample_rate == 0) sample_rate = 44100; /* default */

    /* Calculate sample range */
    size_t start_sample = (size_t)(start_sec * sample_rate);
    size_t num_samples = (size_t)(duration_sec * sample_rate);

    /* Decompress full audio */
    uint8_t *full_data = NULL;
    size_t full_size = 0;
    int result = qtsq_decompress_lensing(ctx, &full_data, &full_size);
    if (result != QTSQ_OK) return result;

    size_t total_samples = full_size / sizeof(int16_t);
    int16_t *all_samples = (int16_t *)full_data;

    /* Bounds check */
    if (start_sample >= total_samples) {
        free(full_data);
        return QTSQ_ERR_FORMAT;
    }
    if (start_sample + num_samples > total_samples) {
        num_samples = total_samples - start_sample;
    }

    /* Copy requested range */
    int16_t *output = (int16_t *)malloc(num_samples * sizeof(int16_t));
    if (!output) {
        free(full_data);
        return QTSQ_ERR_ALLOC;
    }

    memcpy(output, all_samples + start_sample, num_samples * sizeof(int16_t));
    free(full_data);

    *out_samples = output;
    *out_count = num_samples;
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  qtsq_radiate_region — Image region access
 * ══════════════════════════════════════════════════════════════
 *
 * Decompress only a rectangular region (x, y, w, h) from an image.
 */

int qtsq_radiate_region(const qtsq_context_t *ctx,
                       uint32_t x, uint32_t y, uint32_t w, uint32_t h,
                       uint8_t **out_pixels) {
    if (!ctx || !out_pixels) return QTSQ_ERR_NULL;

    /* Get image dimensions from schema */
    uint32_t img_width = ctx->schema.dimensions[0];
    uint32_t img_height = ctx->schema.dimensions[1];

    if (img_width == 0 || img_height == 0) return QTSQ_ERR_FORMAT;

    /* Bounds check */
    if (x + w > img_width) w = img_width - x;
    if (y + h > img_height) h = img_height - y;

    /* Decompress full image */
    uint8_t *full_data = NULL;
    size_t full_size = 0;
    int result = qtsq_decompress_accretion(ctx, &full_data, &full_size);
    if (result != QTSQ_OK) return result;

    /* Extract region */
    size_t region_size = (size_t)w * h;
    uint8_t *output = (uint8_t *)malloc(region_size);
    if (!output) {
        free(full_data);
        return QTSQ_ERR_ALLOC;
    }

    for (uint32_t row = 0; row < h; row++) {
        uint32_t src_offset = (y + row) * img_width + x;
        uint32_t dst_offset = row * w;

        if (src_offset + w <= full_size) {
            memcpy(output + dst_offset, full_data + src_offset, w);
        }
    }

    free(full_data);
    *out_pixels = output;
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  qtsq_radiate_frame — Video frame access
 * ══════════════════════════════════════════════════════════════
 *
 * Decompress a single video frame by index.
 * For now: decompresses the keyframe (frame 0).
 * Production version would support delta-frame seeking.
 */

int qtsq_radiate_frame(const qtsq_context_t *ctx,
                      uint32_t frame_index, uint8_t **out_pixels) {
    if (!ctx || !out_pixels) return QTSQ_ERR_NULL;

    /* Currently only keyframe (frame 0) is stored */
    if (frame_index != 0) {
        /* Future: walk delta chain from nearest keyframe */
        return QTSQ_ERR_FORMAT;
    }

    /* Decompress the fractal-encoded keyframe */
    uint8_t *full_data = NULL;
    size_t full_size = 0;
    int result = qtsq_decompress_accretion(ctx, &full_data, &full_size);
    if (result != QTSQ_OK) return result;

    *out_pixels = full_data;
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  qtsq_decompress — Universal dispatcher
 * ══════════════════════════════════════════════════════════════
 *
 * Automatically picks the right decompression engine based
 * on the strategy stored in the header.
 */

int qtsq_decompress(qtsq_context_t *ctx,
                   uint8_t **out_data, size_t *out_size) {
    if (!ctx || !out_data || !out_size) return QTSQ_ERR_NULL;
    if (!ctx->singularity) return QTSQ_ERR_FORMAT;

    switch (ctx->header.strategy) {
        case QTSQ_STRATEGY_NONE:
        case QTSQ_STRATEGY_PROCEDURAL:
        case QTSQ_STRATEGY_DELTA_SEED:
            return qtsq_decompress_singularity(ctx, out_data, out_size);

        case QTSQ_STRATEGY_DICTIONARY:
            return qtsq_decompress_horizon(ctx, out_data, out_size);

        case QTSQ_STRATEGY_FOURIER:
            return qtsq_decompress_lensing(ctx, out_data, out_size);

        case QTSQ_STRATEGY_FRACTAL:
        case QTSQ_STRATEGY_TEMPORAL:
            return qtsq_decompress_accretion(ctx, out_data, out_size);

        case QTSQ_STRATEGY_LAYERED:
            if (ctx->header.data_type == QTSQ_TYPE_AUDIO_MONO ||
                ctx->header.data_type == QTSQ_TYPE_AUDIO_STEREO) {
                return qtsq_decompress_gravitational_audio(ctx, out_data, out_size);
            }
            return qtsq_decompress_gravitational(ctx, out_data, out_size);

        case QTSQ_STRATEGY_TRIANGLE:
            return qtsq_decompress_gravitational(ctx, out_data, out_size);

        case QTSQ_STRATEGY_SPLAT:
            return qtsq_decompress_splat_only(ctx, out_data, out_size);

        default:
            return QTSQ_ERR_STRATEGY;
    }
}
