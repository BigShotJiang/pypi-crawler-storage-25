#include "qtsq.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <zlib.h>

#include "qtsq_splat2d.h"
#ifdef __APPLE__
#include "qtsq_metal.h"
#endif

struct qtsq_video_decoder {
    const qtsq_context_t *ctx;
    uint32_t width;
    uint32_t height;
    uint8_t channels;
    
    uint32_t frame_count;
    uint32_t *frame_offsets;
    uint32_t *frame_sizes;
    uint8_t  *frame_types;
    
    const uint8_t *bitstream;
    size_t bitstream_size;
    
    /* Ring buffer (capacity 3) for output frames */
    uint8_t *ring_buffers[3];
    uint32_t ring_head;
    size_t   ring_buffer_size;
    
    /* Reference frame: last decoded I-frame for P-frame reconstruction */
    uint8_t *ref_frame;
    int has_ref_frame;
    uint32_t last_iframe_index; /* track which I-frame is loaded */
    
    /* Reference splat buffer: cached I-frame splat data for P-frame delta application */
    uint8_t *ref_splat_raw;       /* working copy: modified by P-frame deltas for rendering */
    uint8_t *ref_splat_original;  /* pristine I-frame copy: never modified after caching */
    uint32_t ref_splat_count;
};

/* ── RLE decoder for P-frame delta ──
 * Format matches the encoder:
 * [0xFF][high][low] = skip N unchanged pixels (all channels = 128)
 * [0xFE][ch0][ch1][ch2] = one changed pixel with biased delta values
 */
static int rle_decode_delta(const uint8_t *rle, size_t rle_size, uint8_t *delta, size_t delta_cap, uint8_t ch) {
    size_t ri = 0;
    size_t di = 0;
    
    while (ri < rle_size && di < delta_cap) {
        uint8_t marker = rle[ri++];
        
        if (marker == 0xFF) {
            /* Unchanged run */
            if (ri + 2 > rle_size) return -1;
            uint16_t run = ((uint16_t)rle[ri] << 8) | rle[ri + 1];
            ri += 2;
            
            for (uint16_t p = 0; p < run && di + ch <= delta_cap; p++) {
                for (uint8_t c = 0; c < ch; c++) {
                    delta[di++] = 128; /* no change */
                }
            }
        } else if (marker == 0xFE) {
            /* Raw changed pixel */
            if (ri + ch > rle_size || di + ch > delta_cap) return -1;
            for (uint8_t c = 0; c < ch; c++) {
                delta[di++] = rle[ri++];
            }
        } else {
            /* Legacy: raw byte (shouldn't happen with new encoder, but handle gracefully) */
            if (di < delta_cap) {
                delta[di++] = marker;
            }
        }
    }
    return 0;
}

/* Apply a bias-encoded delta to a reference frame:
 * output[i] = ref[i] + (delta[i] - 128) 
 */
static void apply_delta(const uint8_t *ref, const uint8_t *delta, uint8_t *output, size_t size) {
    for (size_t i = 0; i < size; i++) {
        int val = (int)ref[i] + ((int)delta[i] - 128);
        output[i] = (uint8_t)(val < 0 ? 0 : (val > 255 ? 255 : val));
    }
}

qtsq_video_decoder_t* qtsq_video_decoder_open(const qtsq_context_t *ctx) {
    if (!ctx || !ctx->singularity || ctx->singularity_size < 8) return NULL;
    if (ctx->header.data_type != QTSQ_TYPE_VIDEO_FRAMES) return NULL;

    const uint8_t *p = ctx->singularity;
    if (p[0] != 'I' || p[1] != 'D' || p[2] != 'X' || p[3] != '1') {
        fprintf(stderr, "[QTSQ Decoder] Error: Missing IDX1 chunk in video stream.\n");
        return NULL;
    }

    qtsq_video_decoder_t *dec = (qtsq_video_decoder_t *)calloc(1, sizeof(qtsq_video_decoder_t));
    if (!dec) return NULL;

    dec->ctx = ctx;
    dec->width = ctx->schema.dimensions[0];
    dec->height = ctx->schema.dimensions[1];
    dec->channels = ctx->schema.dimensions[2];

    p += 4;
    memcpy(&dec->frame_count, p, 4); p += 4;

    if (dec->frame_count > 0) {
        dec->frame_offsets = (uint32_t *)malloc(dec->frame_count * sizeof(uint32_t));
        dec->frame_sizes = (uint32_t *)malloc(dec->frame_count * sizeof(uint32_t));
        dec->frame_types = (uint8_t *)malloc(dec->frame_count * sizeof(uint8_t));

        if (!dec->frame_offsets || !dec->frame_sizes || !dec->frame_types) {
            qtsq_video_decoder_free(dec);
            return NULL;
        }

        memcpy(dec->frame_offsets, p, dec->frame_count * 4); p += dec->frame_count * 4;
        memcpy(dec->frame_sizes, p, dec->frame_count * 4); p += dec->frame_count * 4;
        memcpy(dec->frame_types, p, dec->frame_count); p += dec->frame_count;
    }

    dec->bitstream = p;
    dec->bitstream_size = ctx->singularity_size - (p - ctx->singularity);
    
    /* Initialize ring buffers lazily */
    dec->ring_head = 0;
    dec->ring_buffer_size = 0;
    
    /* Allocate reference frame buffer */
    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    dec->ref_frame = (uint8_t *)calloc(1, frame_bytes);
    dec->has_ref_frame = 0;
    dec->last_iframe_index = UINT32_MAX;

    return dec;
}

/* Simple 2x bilinear upscale for 'D' (downscaled) I-frames */
static uint8_t* upscale_2x(const uint8_t *src, uint32_t sw, uint32_t sh, uint32_t dw, uint32_t dh, uint8_t ch) {
    uint8_t *dst = (uint8_t *)malloc((size_t)dw * dh * ch);
    if (!dst) return NULL;
    
    for (uint32_t y = 0; y < dh; y++) {
        for (uint32_t x = 0; x < dw; x++) {
            /* Map destination pixel to source coordinates */
            float sx = (float)x * sw / dw;
            float sy = (float)y * sh / dh;
            uint32_t sx0 = (uint32_t)sx, sy0 = (uint32_t)sy;
            uint32_t sx1 = sx0 + 1 < sw ? sx0 + 1 : sx0;
            uint32_t sy1 = sy0 + 1 < sh ? sy0 + 1 : sy0;
            float fx = sx - sx0, fy = sy - sy0;
            
            for (uint8_t c = 0; c < ch; c++) {
                float v00 = src[(sy0 * sw + sx0) * ch + c];
                float v10 = src[(sy0 * sw + sx1) * ch + c];
                float v01 = src[(sy1 * sw + sx0) * ch + c];
                float v11 = src[(sy1 * sw + sx1) * ch + c];
                float val = v00 * (1-fx)*(1-fy) + v10 * fx*(1-fy) + v01 * (1-fx)*fy + v11 * fx*fy;
                dst[(y * dw + x) * ch + c] = (uint8_t)(val + 0.5f);
            }
        }
    }
    return dst;
}

/* Decode a keyframe.
 * 'S' = Splat keyframe (pure Gaussian Splats, Phase 10)
 * 'G' = GPU gravitational (vertices + triangles + splats, legacy)
 * 'K' = zlib raw pixels
 * 'I'/'D' = legacy gravitational
 */
static int decode_iframe(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t *output) {
    uint32_t offset = dec->frame_offsets[frame_index];
    uint32_t size = dec->frame_sizes[frame_index];
    uint8_t type = dec->frame_types[frame_index];
    
    if (offset + size > dec->bitstream_size || size < 4) return QTSQ_ERR_CORRUPT;
    
    const uint8_t *data = dec->bitstream + offset;
    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    
    if (type == 'S') {
        /* Pure Splat keyframe (Phase 10):
         * [2B: w] [2B: h] [4B: num_splats] [4B: splat_zlen]
         * [zlib: 9-byte-per-splat data] */
        if (size < 12) return QTSQ_ERR_CORRUPT;
        
        uint16_t fw, fh;
        uint32_t num_splats, splat_zlen;
        memcpy(&fw, data, 2);
        memcpy(&fh, data + 2, 2);
        memcpy(&num_splats, data + 4, 4);
        memcpy(&splat_zlen, data + 8, 4);
        
        if (num_splats == 0) {
            memset(output, 0, frame_bytes);
            return QTSQ_OK;
        }
        
        /* Decompress splat data (9 bytes per splat) */
        size_t raw_size = (size_t)num_splats * 9;
        uint8_t *raw = (uint8_t *)malloc(raw_size);
        if (!raw) return QTSQ_ERR_ALLOC;
        
        uLongf rlen = (uLongf)raw_size;
        if (uncompress(raw, &rlen, data + 12, splat_zlen) != Z_OK) {
            free(raw);
            return QTSQ_ERR_CORRUPT;
        }
        
        /* Cache reference splat data for P-frame delta decoding */
        if (dec->ref_splat_raw) free(dec->ref_splat_raw);
        if (dec->ref_splat_original) free(dec->ref_splat_original);
        dec->ref_splat_raw = (uint8_t *)malloc(raw_size);
        dec->ref_splat_original = (uint8_t *)malloc(raw_size);
        if (dec->ref_splat_raw && dec->ref_splat_original) {
            memcpy(dec->ref_splat_raw, raw, raw_size);
            memcpy(dec->ref_splat_original, raw, raw_size);
            dec->ref_splat_count = num_splats;
        } else {
            dec->ref_splat_count = 0;
        }
        
        /* Convert to splat2d_t for GPU rendering */
        memset(output, 0, frame_bytes);
        
        splat2d_t *splats = (splat2d_t *)calloc(num_splats, sizeof(splat2d_t));
        if (!splats) { free(raw); return QTSQ_ERR_ALLOC; }
        
        for (uint32_t i = 0; i < num_splats; i++) {
            uint8_t *sp = raw + i * 9;
            uint16_t sx, sy;
            memcpy(&sx, sp, 2);
            memcpy(&sy, sp + 2, 2);
            splats[i].x = (float)sx;
            splats[i].y = (float)sy;
            splats[i].z = 0;
            splats[i].r = sp[4];
            splats[i].g = sp[5];
            splats[i].b = sp[6];
            splats[i].sx = sp[7]; /* radius */
            splats[i].sy = sp[7]; /* radius (circular) */
            splats[i].alpha = sp[8];
            splats[i].theta = 0;
        }
        free(raw);
        
        /* CPU splat rasterizer — O(splats × radius²), fast painter's algorithm.
         * DO NOT use GPU render_splats here — it's O(pixels × splats) = 100B ops at 1080p. */
        for (uint32_t i = 0; i < num_splats; i++) {
            int cx = (int)splats[i].x, cy = (int)splats[i].y;
            int r = (int)splats[i].sx;
            if (r < 1) r = 1;
            uint8_t sr = splats[i].r, sg = splats[i].g, sb = splats[i].b;
            float r2f = (float)(r * r);
            
            for (int dy = -r; dy <= r; dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    float d2 = (float)(dx * dx + dy * dy);
                    if (d2 > r2f) continue;
                    int px = cx + dx, py = cy + dy;
                    if (px < 0 || px >= (int)dec->width || py < 0 || py >= (int)dec->height) continue;
                    
                    /* Gaussian-like blend: full color at center, fade at edges */
                    float w = 1.0f - (d2 / (r2f * 1.2f));
                    if (w < 0.0f) w = 0.0f;
                    
                    size_t pidx = ((size_t)py * dec->width + px) * dec->channels;
                    uint8_t er = output[pidx], eg = output[pidx + 1], eb = output[pidx + 2];
                    output[pidx]     = (uint8_t)(sr * w + er * (1.0f - w));
                    output[pidx + 1] = (uint8_t)(sg * w + eg * (1.0f - w));
                    output[pidx + 2] = (uint8_t)(sb * w + eb * (1.0f - w));
                    if (dec->channels == 4) output[pidx + 3] = 255;
                }
            }
        }
        
        free(splats);
        return QTSQ_OK;
    }
    
    if (type == 'G') {
        /* GPU gravitational keyframe:
         * [2B: w] [2B: h] [4B: num_verts] [4B: num_tris] [4B: num_splats]
         * [4B: vert_zlen] [4B: tri_zlen] [4B: splat_zlen]
         * [zlib: vert_data] [zlib: tri_data] [zlib: splat_data] */
        if (size < 28) return QTSQ_ERR_CORRUPT;
        
        uint16_t fw, fh;
        uint32_t num_verts, num_tris, num_splats;
        uint32_t vert_zlen, tri_zlen, splat_zlen;
        
        memcpy(&fw, data, 2);
        memcpy(&fh, data + 2, 2);
        memcpy(&num_verts, data + 4, 4);
        memcpy(&num_tris, data + 8, 4);
        memcpy(&num_splats, data + 12, 4);
        memcpy(&vert_zlen, data + 16, 4);
        memcpy(&tri_zlen, data + 20, 4);
        memcpy(&splat_zlen, data + 24, 4);
        
        const uint8_t *vert_z = data + 28;
        const uint8_t *tri_z = vert_z + vert_zlen;
        const uint8_t *splat_z = tri_z + tri_zlen;
        
        /* Decompress vertex data: positions(float2×N) + colors(uchar3×N) */
        size_t vert_raw_size = num_verts * 2 * sizeof(float) + num_verts * 3;
        uint8_t *vert_raw = (uint8_t *)malloc(vert_raw_size);
        if (!vert_raw) return QTSQ_ERR_ALLOC;
        
        uLongf vlen = (uLongf)vert_raw_size;
        if (uncompress(vert_raw, &vlen, vert_z, vert_zlen) != Z_OK) {
            free(vert_raw);
            return QTSQ_ERR_CORRUPT;
        }
        
        float *vert_pos = (float *)vert_raw;
        uint8_t *vert_colors = vert_raw + num_verts * 2 * sizeof(float);
        
        /* Decompress triangle indices */
        size_t tri_raw_size = num_tris * 3 * sizeof(uint32_t);
        uint32_t *tris = (uint32_t *)malloc(tri_raw_size);
        if (!tris) { free(vert_raw); return QTSQ_ERR_ALLOC; }
        
        uLongf tlen = (uLongf)tri_raw_size;
        if (uncompress((uint8_t*)tris, &tlen, tri_z, tri_zlen) != Z_OK) {
            free(tris); free(vert_raw);
            return QTSQ_ERR_CORRUPT;
        }
        
        /* Decompress splat data if present */
        uint8_t *splat_raw = NULL;
        if (num_splats > 0 && splat_zlen > 0) {
            size_t splat_raw_size = num_splats * 12;
            splat_raw = (uint8_t *)malloc(splat_raw_size);
            if (splat_raw) {
                uLongf slen = (uLongf)splat_raw_size;
                if (uncompress(splat_raw, &slen, splat_z, splat_zlen) != Z_OK) {
                    free(splat_raw);
                    splat_raw = NULL;
                    num_splats = 0;
                }
            }
        }
        
        /* Render: Build TriVertex array and rasterize using GPU */
        memset(output, 0, frame_bytes); /* Clear output */
        
        /* Build TriVertex array from positions + colors */
        /* TriVertex: float x, float y, uchar r, g, b = 13 bytes but struct-aligned */
        /* Use the existing Metal rasterization kernel via CPU struct packing */
        tri_vertex_t *vertices = (tri_vertex_t *)malloc(num_verts * sizeof(tri_vertex_t));
        tri_face_t *faces = (tri_face_t *)malloc(num_tris * sizeof(tri_face_t));
        
        if (vertices && faces) {
            for (uint32_t i = 0; i < num_verts; i++) {
                vertices[i].x = vert_pos[i * 2];
                vertices[i].y = vert_pos[i * 2 + 1];
                vertices[i].r = vert_colors[i * 3];
                vertices[i].g = vert_colors[i * 3 + 1];
                vertices[i].b = vert_colors[i * 3 + 2];
            }
            
            /* Triangle indices use pixel-linearized IDs; remap to vertex indices */
            /* The encoder stores va = seed_y * width + seed_x as the index.
             * We need to find which vertex index corresponds to each pixel ID. */
            /* Build a lookup from pixel position to vertex index */
            for (uint32_t i = 0; i < num_tris; i++) {
                /* For now, these are pixel-linearized — find matching vertex by position */
                faces[i].v0 = tris[i * 3];
                faces[i].v1 = tris[i * 3 + 1];
                faces[i].v2 = tris[i * 3 + 2];
            }
            
            uint8_t *blur_map = (uint8_t *)calloc(dec->width * dec->height, 1);
            
#ifdef __APPLE__
            qtsq_metal_ctx_t *metal = qtsq_metal_global();
            if (metal) {
                qtsq_metal_rasterize(metal, vertices, num_verts, faces, num_tris,
                                      dec->width, dec->height, dec->channels, output, blur_map, NULL);
                
                /* Render splats in smooth regions */
                if (splat_raw && num_splats > 0) {
                    /* Convert splat_raw to splat2d_t array for rendering */
                    splat2d_t *splats = (splat2d_t *)calloc(num_splats, sizeof(splat2d_t));
                    if (splats) {
                        for (uint32_t i = 0; i < num_splats; i++) {
                            uint8_t *sp = splat_raw + i * 12;
                            float sx, sy;
                            memcpy(&sx, sp, 4);
                            memcpy(&sy, sp + 4, 4);
                            splats[i].x = sx;
                            splats[i].y = sy;
                            splats[i].z = 0;
                            splats[i].r = sp[8];
                            splats[i].g = sp[9];
                            splats[i].b = sp[10];
                            /* SplatOutput layout: [float2 pos(8B)][r(1B)][g(1B)][b(1B)][radius(1B)] = 12 bytes */
                            splats[i].sx = sp[11]; /* radius as sx */
                            splats[i].sy = sp[11]; /* radius as sy */
                            splats[i].alpha = 200; /* Fixed alpha for smooth regions */
                            splats[i].theta = 0;
                        }
                        qtsq_metal_render_splats(metal, splats, num_splats,
                                                  dec->width, dec->height, dec->channels,
                                                  output, NULL);
                        free(splats);
                    }
                }
            }
#endif
            if (blur_map) free(blur_map);
        }
        
        if (vertices) free(vertices);
        if (faces) free(faces);
        if (splat_raw) free(splat_raw);
        free(tris);
        free(vert_raw);
        
        return QTSQ_OK;
    }
    
    /* Read resolution header (common to K/I/D types) */
    uint16_t comp_w, comp_h;
    memcpy(&comp_w, data, 2);
    memcpy(&comp_h, data + 2, 2);
    
    uint8_t *decoded = NULL;
    size_t decoded_size = 0;
    
    if (type == 'K') {
        /* Fast zlib keyframe: [2B: w] [2B: h] [4B: raw_size] [zlib_data] */
        if (size < 8) return QTSQ_ERR_CORRUPT;
        uint32_t raw_size;
        memcpy(&raw_size, data + 4, 4);
        
        decoded = (uint8_t *)malloc(raw_size);
        if (!decoded) return QTSQ_ERR_ALLOC;
        
        uLongf dest_len = raw_size;
        int zret = uncompress(decoded, &dest_len, data + 8, size - 8);
        if (zret != Z_OK) {
            free(decoded);
            return QTSQ_ERR_CORRUPT;
        }
        decoded_size = dest_len;
    } else {
        /* Legacy gravitational: [2B: w] [2B: h] [gravitational_data] */
        qtsq_context_t temp_ctx;
        qtsq_init(&temp_ctx);
        temp_ctx.header = dec->ctx->header;
        temp_ctx.schema = dec->ctx->schema;
        temp_ctx.schema.dimensions[0] = comp_w;
        temp_ctx.schema.dimensions[1] = comp_h;
        
        size_t payload_size = size - 4;
        temp_ctx.singularity_size = payload_size;
        temp_ctx.singularity = (uint8_t *)malloc(payload_size);
        if (!temp_ctx.singularity) return QTSQ_ERR_ALLOC;
        memcpy(temp_ctx.singularity, data + 4, payload_size);
        
        int ret = qtsq_decompress_gravitational(&temp_ctx, &decoded, &decoded_size);
        free(temp_ctx.singularity);
        temp_ctx.singularity = NULL;
        qtsq_free(&temp_ctx);
        if (ret != QTSQ_OK) {
            if (decoded) free(decoded);
            return ret;
        }
    }
    
    /* If compressed at a smaller resolution, upscale to full output size */
    if (comp_w != dec->width || comp_h != dec->height) {
        uint8_t *upscaled = upscale_2x(decoded, comp_w, comp_h, dec->width, dec->height, dec->channels);
        free(decoded);
        if (!upscaled) return QTSQ_ERR_ALLOC;
        memcpy(output, upscaled, frame_bytes);
        free(upscaled);
    } else {
        size_t copy_size = decoded_size < frame_bytes ? decoded_size : frame_bytes;
        memcpy(output, decoded, copy_size);
        free(decoded);
    }
    
    return QTSQ_OK;
}

/* Decode a P-frame: Splat Color Delta format
 * Format: [2B: w][2B: h][4B: num_changed][4B: zlen][zlib: (4B index + 3B delta_rgb) × N]
 * Apply color deltas to reference splat buffer, then re-render all splats. */
static int decode_pframe(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t *output) {
    uint32_t offset = dec->frame_offsets[frame_index];
    uint32_t size = dec->frame_sizes[frame_index];
    
    if (offset + size > dec->bitstream_size) return QTSQ_ERR_CORRUPT;
    if (!dec->ref_splat_raw || dec->ref_splat_count == 0) return QTSQ_ERR_CORRUPT;
    
    const uint8_t *data = dec->bitstream + offset;
    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    
    /* Parse header: [2B: w][2B: h][4B: num_changed][4B: zlen] */
    if (size < 12) return QTSQ_ERR_CORRUPT;
    uint32_t num_changed, zlen;
    memcpy(&num_changed, data + 4, 4);
    memcpy(&zlen, data + 8, 4);
    
    /* Reset ref_splat_raw to pristine I-frame state before applying deltas.
     * Each P-frame deltas against the I-frame's original colors, not accumulated. */
    if (dec->ref_splat_original) {
        size_t splat_data_size = (size_t)dec->ref_splat_count * 9;
        memcpy(dec->ref_splat_raw, dec->ref_splat_original, splat_data_size);
    }
    
    /* Apply color deltas to reference splat buffer */
    if (num_changed > 0 && zlen > 0) {
        size_t raw_size = (size_t)num_changed * 7;
        uint8_t *raw = (uint8_t *)malloc(raw_size);
        if (!raw) return QTSQ_ERR_ALLOC;
        
        uLongf rlen = (uLongf)raw_size;
        if (uncompress(raw, &rlen, data + 12, zlen) != Z_OK) {
            free(raw);
            return QTSQ_ERR_CORRUPT;
        }
        
        /* Apply each delta to the reference splat buffer */
        for (uint32_t i = 0; i < num_changed; i++) {
            uint32_t splat_idx;
            memcpy(&splat_idx, raw + i * 7, 4);
            if (splat_idx >= dec->ref_splat_count) continue;
            
            uint8_t dr_biased = raw[i * 7 + 4];
            uint8_t dg_biased = raw[i * 7 + 5];
            uint8_t db_biased = raw[i * 7 + 6];
            
            /* Apply bias-decoded delta to reference splat colors */
            uint8_t *sp = dec->ref_splat_raw + splat_idx * 9;
            int new_r = (int)sp[4] + ((int)dr_biased - 128);
            int new_g = (int)sp[5] + ((int)dg_biased - 128);
            int new_b = (int)sp[6] + ((int)db_biased - 128);
            sp[4] = (uint8_t)(new_r < 0 ? 0 : (new_r > 255 ? 255 : new_r));
            sp[5] = (uint8_t)(new_g < 0 ? 0 : (new_g > 255 ? 255 : new_g));
            sp[6] = (uint8_t)(new_b < 0 ? 0 : (new_b > 255 ? 255 : new_b));
        }
        free(raw);
    }
    
    /* Re-render ALL splats from the updated reference buffer */
    memset(output, 0, frame_bytes);
    
    for (uint32_t i = 0; i < dec->ref_splat_count; i++) {
        uint8_t *sp = dec->ref_splat_raw + i * 9;
        uint16_t sx, sy;
        memcpy(&sx, sp, 2);
        memcpy(&sy, sp + 2, 2);
        int cx = (int)sx, cy = (int)sy;
        int r = (int)sp[7]; /* radius */
        if (r < 1) r = 1;
        uint8_t sr = sp[4], sg = sp[5], sb = sp[6];
        float r2f = (float)(r * r);
        
        for (int dy = -r; dy <= r; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                float d2 = (float)(dx * dx + dy * dy);
                if (d2 > r2f) continue;
                int px = cx + dx, py = cy + dy;
                if (px < 0 || px >= (int)dec->width || py < 0 || py >= (int)dec->height) continue;
                
                float w = 1.0f - (d2 / (r2f * 1.2f));
                if (w < 0.0f) w = 0.0f;
                
                size_t pidx = ((size_t)py * dec->width + px) * dec->channels;
                uint8_t er = output[pidx], eg = output[pidx + 1], eb = output[pidx + 2];
                output[pidx]     = (uint8_t)(sr * w + er * (1.0f - w));
                output[pidx + 1] = (uint8_t)(sg * w + eg * (1.0f - w));
                output[pidx + 2] = (uint8_t)(sb * w + eb * (1.0f - w));
                if (dec->channels == 4) output[pidx + 3] = 255;
            }
        }
    }
    
    return QTSQ_OK;
}

int qtsq_video_decoder_get_frame(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t **out_pixels, uint32_t *width, uint32_t *height) {
    if (!dec || !out_pixels) return QTSQ_ERR_NULL;
    if (frame_index >= dec->frame_count) return QTSQ_ERR_IO;

    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    
    /* Lazy-init ring buffers */
    if (dec->ring_buffer_size == 0) {
        dec->ring_buffer_size = frame_bytes;
        for (int i = 0; i < 3; i++) {
            dec->ring_buffers[i] = (uint8_t *)malloc(dec->ring_buffer_size);
        }
    }
    
    uint8_t *local_buffer = dec->ring_buffers[dec->ring_head];
    dec->ring_head = (dec->ring_head + 1) % 3;
    *out_pixels = local_buffer;

    uint8_t type = dec->frame_types[frame_index];
    int ret = QTSQ_OK;
    
    /* 'I'/'D'/'K'/'G' = keyframe types */
    if (type == 'I' || type == 'D' || type == 'K' || type == 'G' || type == 'S') {
        ret = decode_iframe(dec, frame_index, local_buffer);
        if (ret == QTSQ_OK) {
            /* Update reference frame */
            memcpy(dec->ref_frame, local_buffer, frame_bytes);
            dec->has_ref_frame = 1;
            dec->last_iframe_index = frame_index;
        }
    } else if (type == 'P') {
        /* Ensure we have the correct reference I-frame */
        if (!dec->has_ref_frame) {
            /* Find the nearest preceding keyframe and decode it first */
            uint32_t search = frame_index;
            while (search > 0 && dec->frame_types[search] != 'I' && dec->frame_types[search] != 'S' && dec->frame_types[search] != 'D' && dec->frame_types[search] != 'K' && dec->frame_types[search] != 'G') {
                search--;
            }
            if (dec->frame_types[search] != 'I' && dec->frame_types[search] != 'S' && dec->frame_types[search] != 'D' && dec->frame_types[search] != 'K' && dec->frame_types[search] != 'G') {
                return QTSQ_ERR_CORRUPT; /* No keyframe found */
            }
            
            /* Decode the I-frame into ref_frame */
            ret = decode_iframe(dec, search, dec->ref_frame);
            if (ret != QTSQ_OK) return ret;
            dec->has_ref_frame = 1;
            dec->last_iframe_index = search;
            
            /* Now decode all frames between that keyframe and our target sequentially */
            for (uint32_t mid = search + 1; mid < frame_index; mid++) {
                if (dec->frame_types[mid] == 'I' || dec->frame_types[mid] == 'S' || dec->frame_types[mid] == 'D' || dec->frame_types[mid] == 'K' || dec->frame_types[mid] == 'G') {
                    ret = decode_iframe(dec, mid, dec->ref_frame);
                    dec->last_iframe_index = mid;
                } else {
                    /* Decode P-frame into a temp buffer, then copy to ref */
                    uint8_t *temp = (uint8_t *)malloc(frame_bytes);
                    if (!temp) return QTSQ_ERR_ALLOC;
                    ret = decode_pframe(dec, mid, temp);
                    if (ret == QTSQ_OK) {
                        memcpy(dec->ref_frame, temp, frame_bytes);
                    }
                    free(temp);
                }
                if (ret != QTSQ_OK) return ret;
            }
        }
        
        ret = decode_pframe(dec, frame_index, local_buffer);
        if (ret == QTSQ_OK) {
            /* Update reference for next P-frame in sequence */
            memcpy(dec->ref_frame, local_buffer, frame_bytes);
        }
    } else {
        ret = QTSQ_ERR_STRATEGY; /* Unknown frame type */
    }

    if (ret == QTSQ_OK) {
        if (width) *width = dec->width;
        if (height) *height = dec->height;
    }

    return ret;
}

uint32_t qtsq_video_decoder_get_frame_count(qtsq_video_decoder_t *dec) {
    if (!dec) return 0;
    return dec->frame_count;
}

const qtsq_context_t* qtsq_video_decoder_get_context(qtsq_video_decoder_t *dec) {
    if (!dec) return NULL;
    return dec->ctx;
}

void qtsq_video_decoder_free(qtsq_video_decoder_t *dec) {
    if (!dec) return;
    if (dec->frame_offsets) free(dec->frame_offsets);
    if (dec->frame_sizes) free(dec->frame_sizes);
    if (dec->frame_types) free(dec->frame_types);
    if (dec->ref_frame) free(dec->ref_frame);
    if (dec->ref_splat_raw) free(dec->ref_splat_raw);
    if (dec->ref_splat_original) free(dec->ref_splat_original);
    for (int i = 0; i < 3; i++) {
        if (dec->ring_buffers[i]) free(dec->ring_buffers[i]);
    }
    free(dec);
}
