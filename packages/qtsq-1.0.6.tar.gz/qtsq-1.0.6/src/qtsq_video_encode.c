#include "qtsq.h"
#include "qtsq_splat2d.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <zlib.h>
#include "qtsq_parallel.h"

#ifdef __APPLE__
#include "qtsq_metal.h"
#endif

#define QTSQ_VIDEO_BATCH_MAX 32
#define PFRAME_CHANGE_THRESHOLD 16    /* Per-channel diff threshold for "changed" splat color */
#define PFRAME_PROMOTE_RATIO   0.95f  /* If >95% pixels changed (scene cut), promote to I-frame */
#define MAX_PARALLEL_IFRAMES   1      /* GPU splat pipeline — serialize to avoid Metal contention */
#define IFRAME_DOWNSCALE_THRESHOLD 1920  /* Downscale I-frames if width > this */

typedef struct {
    qtsq_video_encoder_t *enc;
    uint8_t *raw_pixels;
    int frame_index;
    int ret_code;
    uint8_t *compressed_data;
    size_t compressed_size;
    uint8_t frame_type;

    /* P-frame specific: pre-computed delta buffer from GPU/CPU diff */
    uint8_t *delta_buffer;
    float change_ratio;
} batch_job_t;

struct qtsq_video_encoder {
    qtsq_context_t *ctx;
    uint32_t width;
    uint32_t height;
    uint8_t channels;
    uint32_t fps;
    int strategy_flags;
    size_t target_payload_per_frame;

    uint32_t frame_count;
    uint32_t i_frame_interval;

    uint8_t *bitstream;
    size_t bitstream_size;
    size_t bitstream_capacity;

    uint32_t *frame_offsets;
    uint32_t *frame_sizes;
    uint8_t  *frame_types;
    size_t index_capacity;

    batch_job_t batch[QTSQ_VIDEO_BATCH_MAX];
    int batch_count;
    int batch_capacity;

    /* Reference frame: PREVIOUS frame's pixels for delta computation */
    uint8_t *ref_frame;
    int has_ref_frame;

    /* Reference splat buffer: cached I-frame splat positions + colors for P-frame deltas */
    uint8_t *ref_splat_input;    /* packed splat coords [u16 x, u16 y, u8 radius] × N */
    uint8_t *ref_splat_colors;   /* packed splat colors [r, g, b] × N */
    uint32_t ref_splat_count;
};


static int append_to_bitstream(qtsq_video_encoder_t *enc, const uint8_t *data, size_t size) {
    if (enc->bitstream_size + size > enc->bitstream_capacity) {
        size_t new_cap = enc->bitstream_capacity * 2;
        if (new_cap < enc->bitstream_size + size + 1024 * 1024) {
            new_cap = enc->bitstream_size + size + 1024 * 1024;
        }
        uint8_t *new_buf = (uint8_t *)realloc(enc->bitstream, new_cap);
        if (!new_buf) return QTSQ_ERR_ALLOC;
        enc->bitstream = new_buf;
        enc->bitstream_capacity = new_cap;
    }
    memcpy(enc->bitstream + enc->bitstream_size, data, size);
    enc->bitstream_size += size;
    return QTSQ_OK;
}

static int append_to_index(qtsq_video_encoder_t *enc, uint32_t offset, uint32_t size, uint8_t type) {
    if (enc->frame_count >= enc->index_capacity) {
        size_t new_cap = enc->index_capacity == 0 ? 600 : enc->index_capacity * 2;
        uint32_t *new_offsets = (uint32_t *)realloc(enc->frame_offsets, new_cap * sizeof(uint32_t));
        uint32_t *new_sizes = (uint32_t *)realloc(enc->frame_sizes, new_cap * sizeof(uint32_t));
        uint8_t *new_types = (uint8_t *)realloc(enc->frame_types, new_cap * sizeof(uint8_t));
        if (!new_offsets || !new_sizes || !new_types) return QTSQ_ERR_ALLOC;
        
        enc->frame_offsets = new_offsets;
        enc->frame_sizes = new_sizes;
        enc->frame_types = new_types;
        enc->index_capacity = new_cap;
    }
    enc->frame_offsets[enc->frame_count] = offset;
    enc->frame_sizes[enc->frame_count] = size;
    enc->frame_types[enc->frame_count] = type;
    enc->frame_count++;
    return QTSQ_OK;
}

qtsq_video_encoder_t* qtsq_video_encoder_create(qtsq_context_t *ctx,
                                                uint32_t width, uint32_t height,
                                                uint8_t channels, uint32_t fps,
                                                int strategy_flags,
                                                size_t target_payload_per_frame) {
    if (!ctx) return NULL;
    qtsq_video_encoder_t *enc = (qtsq_video_encoder_t *)calloc(1, sizeof(qtsq_video_encoder_t));
    if (!enc) return NULL;

    enc->ctx = ctx;
    enc->width = width;
    enc->height = height;
    enc->channels = channels;
    enc->fps = fps > 0 ? fps : 24;
    enc->strategy_flags = strategy_flags;
    enc->target_payload_per_frame = target_payload_per_frame;

    /* Adaptive I-frame interval: 4 seconds for 4K+, 2 seconds otherwise */
    if (width > IFRAME_DOWNSCALE_THRESHOLD) {
        enc->i_frame_interval = enc->fps * 4; /* 4K+: I-frame every 4 seconds */
    } else {
        enc->i_frame_interval = enc->fps * 2; /* ≤1080p: I-frame every 2 seconds */
    }

    enc->batch_capacity = qtsq_num_cores();
    if (enc->batch_capacity > QTSQ_VIDEO_BATCH_MAX) enc->batch_capacity = QTSQ_VIDEO_BATCH_MAX;
    if (enc->batch_capacity < 1) enc->batch_capacity = 1;
    enc->batch_count = 0;

    /* Initialize bitstream with 1MB minimum */
    enc->bitstream_capacity = 1024 * 1024;
    enc->bitstream = (uint8_t *)malloc(enc->bitstream_capacity);
    enc->bitstream_size = 0;

    /* Pre-allocate reference frame buffer */
    size_t frame_bytes = (size_t)width * height * channels;
    enc->ref_frame = (uint8_t *)calloc(1, frame_bytes);
    enc->has_ref_frame = 0;

    /* Prep context */
    ctx->header.data_type = QTSQ_TYPE_VIDEO_FRAMES;
    ctx->header.strategy = QTSQ_STRATEGY_TEMPORAL;
    ctx->header.flags = strategy_flags;

    strcpy(ctx->schema.name, "QTSQ_VIDEO_STREAM");
    ctx->schema.data_type = QTSQ_TYPE_VIDEO_FRAMES;
    ctx->schema.dimensions[0] = width;
    ctx->schema.dimensions[1] = height;
    ctx->schema.dimensions[2] = channels;
    ctx->schema.num_dims = 3;
    ctx->schema.frame_rate = enc->fps;

    return enc;
}

/* ── RLE encoder for delta buffers ──
 * The delta is bias-encoded (128 = no change).  
 * We RLE consecutive runs of "unchanged" pixels (all channels == 128).
 * Format: [0xFF] [run_length_16bit] for unchanged runs, raw bytes for changed pixels.
 */
static size_t rle_encode_delta(const uint8_t *delta, size_t size, uint8_t *out, size_t out_cap) {
    size_t oi = 0;
    size_t i = 0;
    uint8_t ch = 3; /* RGB channels */
    
    while (i < size) {
        /* Check if current pixel is unchanged (all channels == 128) */
        int is_unchanged = 1;
        if (i + ch <= size) {
            for (uint8_t c = 0; c < ch; c++) {
                if (delta[i + c] != 128) { is_unchanged = 0; break; }
            }
        } else {
            is_unchanged = 0;
        }

        if (is_unchanged) {
            /* Count consecutive unchanged pixels */
            uint32_t run = 0;
            while (i < size && run < 65535) {
                int still_unchanged = 1;
                if (i + ch <= size) {
                    for (uint8_t c = 0; c < ch; c++) {
                        if (delta[i + c] != 128) { still_unchanged = 0; break; }
                    }
                } else break;
                if (!still_unchanged) break;
                run++;
                i += ch;
            }
            /* Emit RLE marker: [0xFF][high][low] */
            if (oi + 3 <= out_cap) {
                out[oi++] = 0xFF;
                out[oi++] = (uint8_t)(run >> 8);
                out[oi++] = (uint8_t)(run & 0xFF);
            } else return 0; /* overflow */
        } else {
            /* Emit raw changed pixel bytes */
            if (i + ch <= size && oi + 1 + ch <= out_cap) {
                out[oi++] = 0xFE; /* raw pixel marker */
                for (uint8_t c = 0; c < ch; c++) {
                    out[oi++] = delta[i + c];
                }
                i += ch;
            } else {
                /* Single byte fallback */
                if (oi < out_cap) {
                    out[oi++] = delta[i++];
                } else return 0;
            }
        }
    }
    return oi;
}

/* Forward declaration — P-frame worker may promote to I-frame on scene cuts */
static void* compress_iframe_worker(void *arg);

/* ── P-frame: Splat Color Delta Encoding ──
 * Re-uses I-frame splat positions, re-samples colors from current frame,
 * stores only changed splat indices + color deltas.
 *
 * Format:
 *   [2B: width] [2B: height] [4B: num_changed] [4B: zlen]
 *   [zlib: (4B splat_index + 3B delta_rgb) × num_changed]
 */
static void* compress_pframe_worker(void *arg) {
    batch_job_t *job = (batch_job_t*)arg;
    qtsq_video_encoder_t *enc = job->enc;
    
    uint32_t w = enc->width, h = enc->height;
    uint8_t ch = enc->channels;
    uint32_t ref_count = enc->ref_splat_count;
    
    if (ref_count == 0 || !enc->ref_splat_input || !enc->ref_splat_colors) {
        /* No reference splats — fall back to K-frame (raw zlib).
         * Do NOT call compress_iframe_worker from a P-frame thread —
         * it would modify shared enc->ref_splat_* state and cause a race condition. */
        FILE *pdbg = fopen("/tmp/qtsq_debug.log", "a");
        if (pdbg) { fprintf(pdbg, "[QTSQ] P-frame fallback to K-frame (no ref splats)\n"); fclose(pdbg); }
        
        uint32_t cw = enc->width, c_h = enc->height;
        size_t raw_sz = (size_t)cw * c_h * enc->channels;
        uLongf cbnd = compressBound((uLong)raw_sz);
        uint8_t *obuf = (uint8_t *)malloc(8 + cbnd);
        if (!obuf) { job->ret_code = QTSQ_ERR_ALLOC; free(job->raw_pixels); job->raw_pixels = NULL; return NULL; }
        uint16_t cw16 = (uint16_t)cw, ch16 = (uint16_t)c_h;
        uint32_t raw32 = (uint32_t)raw_sz;
        memcpy(obuf, &cw16, 2); memcpy(obuf + 2, &ch16, 2); memcpy(obuf + 4, &raw32, 4);
        uLongf dlen = cbnd;
        if (compress2(obuf + 8, &dlen, job->raw_pixels, (uLong)raw_sz, Z_BEST_SPEED) != Z_OK) {
            free(obuf); job->ret_code = QTSQ_ERR_IO; free(job->raw_pixels); job->raw_pixels = NULL; return NULL;
        }
        job->frame_type = 'K';
        job->compressed_data = obuf;
        job->compressed_size = 8 + dlen;
        job->ret_code = QTSQ_OK;
        free(job->raw_pixels); job->raw_pixels = NULL;
        return NULL;
    }
    
    /* Re-sample colors at reference splat positions from current frame */
    uint8_t *cur_colors = (uint8_t *)malloc(ref_count * 3);
    if (!cur_colors) { job->ret_code = QTSQ_ERR_ALLOC; free(job->raw_pixels); job->raw_pixels = NULL; return NULL; }
    
    /* Sample each splat's color from current frame (area average within radius) */
    for (uint32_t i = 0; i < ref_count; i++) {
        uint16_t sx, sy;
        uint8_t rad;
        memcpy(&sx, enc->ref_splat_input + i * 5, 2);
        memcpy(&sy, enc->ref_splat_input + i * 5 + 2, 2);
        rad = enc->ref_splat_input[i * 5 + 4];
        
        /* Average color within splat radius for better accuracy */
        int sum_r = 0, sum_g = 0, sum_b = 0, count = 0;
        int r = (rad > 0) ? rad : 1;
        int r2 = r * r;
        for (int dy = -r; dy <= r; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                if (dx * dx + dy * dy > r2) continue;
                int px = (int)sx + dx, py = (int)sy + dy;
                if (px < 0 || px >= (int)w || py < 0 || py >= (int)h) continue;
                size_t pidx = ((size_t)py * w + px) * ch;
                sum_r += job->raw_pixels[pidx];
                sum_g += job->raw_pixels[pidx + 1];
                sum_b += job->raw_pixels[pidx + 2];
                count++;
            }
        }
        if (count > 0) {
            cur_colors[i * 3]     = (uint8_t)(sum_r / count);
            cur_colors[i * 3 + 1] = (uint8_t)(sum_g / count);
            cur_colors[i * 3 + 2] = (uint8_t)(sum_b / count);
        } else {
            cur_colors[i * 3] = cur_colors[i * 3 + 1] = cur_colors[i * 3 + 2] = 0;
        }
    }
    
    /* Find changed splats (color delta > threshold) */
    uint32_t *changed_indices = (uint32_t *)malloc(ref_count * sizeof(uint32_t));
    uint8_t *changed_deltas = (uint8_t *)malloc(ref_count * 3);
    uint32_t num_changed = 0;
    
    if (!changed_indices || !changed_deltas) {
        free(cur_colors); free(changed_indices); free(changed_deltas);
        job->ret_code = QTSQ_ERR_ALLOC; free(job->raw_pixels); job->raw_pixels = NULL; return NULL;
    }
    
    for (uint32_t i = 0; i < ref_count; i++) {
        int dr = (int)cur_colors[i * 3]     - (int)enc->ref_splat_colors[i * 3];
        int dg = (int)cur_colors[i * 3 + 1] - (int)enc->ref_splat_colors[i * 3 + 1];
        int db = (int)cur_colors[i * 3 + 2] - (int)enc->ref_splat_colors[i * 3 + 2];
        
        /* Only encode if any channel changed by more than threshold */
        if (abs(dr) > PFRAME_CHANGE_THRESHOLD ||
            abs(dg) > PFRAME_CHANGE_THRESHOLD ||
            abs(db) > PFRAME_CHANGE_THRESHOLD) {
            changed_indices[num_changed] = i;
            /* Bias-encode deltas: 128 = no change */
            changed_deltas[num_changed * 3]     = (uint8_t)(dr + 128 < 0 ? 0 : (dr + 128 > 255 ? 255 : dr + 128));
            changed_deltas[num_changed * 3 + 1] = (uint8_t)(dg + 128 < 0 ? 0 : (dg + 128 > 255 ? 255 : dg + 128));
            changed_deltas[num_changed * 3 + 2] = (uint8_t)(db + 128 < 0 ? 0 : (db + 128 > 255 ? 255 : db + 128));
            num_changed++;
        }
    }
    
    /* Note: do NOT update enc->ref_splat_colors here!
     * P-frame workers run in parallel, so writing to shared state
     * would cause a race condition. Instead, all P-frames delta
     * against the I-frame's original colors (read-only). */
    free(cur_colors);
    
    /* Note: no scene-cut K-frame fallback.
     * P-frame splat deltas (7B per changed splat, max ~700KB) are ALWAYS smaller
     * than K-frame (raw pixel zlib, ~4.5MB per frame). Even with 100% changed
     * splats, P-frame is still more efficient than K-frame. */
    
    /* Pack changed splats: [index(4B) + delta_rgb(3B)] × num_changed */
    size_t raw_size = (size_t)num_changed * 7;
    uint8_t *raw_buf = (uint8_t *)malloc(raw_size > 0 ? raw_size : 1);
    if (!raw_buf) { free(changed_indices); free(changed_deltas); job->ret_code = QTSQ_ERR_ALLOC; free(job->raw_pixels); job->raw_pixels = NULL; return NULL; }
    
    for (uint32_t i = 0; i < num_changed; i++) {
        uint8_t *dst = raw_buf + i * 7;
        memcpy(dst, &changed_indices[i], 4);
        dst[4] = changed_deltas[i * 3];
        dst[5] = changed_deltas[i * 3 + 1];
        dst[6] = changed_deltas[i * 3 + 2];
    }
    free(changed_indices);
    free(changed_deltas);
    
    /* zlib compress */
    uLongf zlen = compressBound((uLong)(raw_size > 0 ? raw_size : 1));
    uint8_t *zbuf = (uint8_t *)malloc(zlen);
    if (!zbuf) { free(raw_buf); job->ret_code = QTSQ_ERR_ALLOC; free(job->raw_pixels); job->raw_pixels = NULL; return NULL; }
    
    int zret = Z_OK;
    if (raw_size > 0) {
        zret = compress2(zbuf, &zlen, raw_buf, (uLong)raw_size, Z_DEFAULT_COMPRESSION);
    } else {
        zlen = 0;
    }
    free(raw_buf);
    
    if (zret != Z_OK && raw_size > 0) { free(zbuf); job->ret_code = QTSQ_ERR_IO; free(job->raw_pixels); job->raw_pixels = NULL; return NULL; }
    
    /* Assemble frame: [2B: w][2B: h][4B: num_changed][4B: zlen][zlib data] */
    size_t hdr_size = 12;
    size_t total = hdr_size + zlen;
    uint8_t *frame_buf = (uint8_t *)malloc(total);
    if (!frame_buf) { free(zbuf); job->ret_code = QTSQ_ERR_ALLOC; free(job->raw_pixels); job->raw_pixels = NULL; return NULL; }
    
    uint16_t w16 = (uint16_t)w, h16 = (uint16_t)h;
    uint32_t nc32 = num_changed, zl32 = (uint32_t)zlen;
    memcpy(frame_buf, &w16, 2);
    memcpy(frame_buf + 2, &h16, 2);
    memcpy(frame_buf + 4, &nc32, 4);
    memcpy(frame_buf + 8, &zl32, 4);
    if (zlen > 0) memcpy(frame_buf + 12, zbuf, zlen);
    free(zbuf);
    
    job->frame_type = 'P';
    job->compressed_data = frame_buf;
    job->compressed_size = total;
    job->ret_code = QTSQ_OK;
    
    {
        FILE *pdbg = fopen("/tmp/qtsq_debug.log", "a");
        if (pdbg) { fprintf(pdbg, "[QTSQ Encode] P-frame: %u/%u splats changed, %zu bytes compressed\n", num_changed, ref_count, total); fclose(pdbg); }
    }
    
    free(job->raw_pixels);
    job->raw_pixels = NULL;
    if (job->delta_buffer) { free(job->delta_buffer); job->delta_buffer = NULL; }
    return NULL;
}

/* ── Simple 2x box-average downscale for I-frame optimization ── */
static uint8_t* downscale_2x(const uint8_t *src, uint32_t w, uint32_t h, uint8_t ch) {
    uint32_t dw = w / 2;
    uint32_t dh = h / 2;
    uint8_t *dst = (uint8_t *)malloc((size_t)dw * dh * ch);
    if (!dst) return NULL;
    
    for (uint32_t y = 0; y < dh; y++) {
        for (uint32_t x = 0; x < dw; x++) {
            uint32_t sx = x * 2, sy = y * 2;
            for (uint8_t c = 0; c < ch; c++) {
                uint32_t sum = (uint32_t)src[(sy * w + sx) * ch + c]
                             + (uint32_t)src[(sy * w + sx + 1) * ch + c]
                             + (uint32_t)src[((sy + 1) * w + sx) * ch + c]
                             + (uint32_t)src[((sy + 1) * w + sx + 1) * ch + c];
                dst[(y * dw + x) * ch + c] = (uint8_t)((sum + 2) / 4);
            }
        }
    }
    return dst;
}

/* ── I-frame: Pure Gaussian Splat Keyframe ──
 * Phase 10 Pipeline: Sobel → 3-tier Classify → Adaptive Splat Placement →
 *   GPU Color Sample → zlib pack.
 * Frame type: 'S' (Splat keyframe)
 *
 * Per-splat storage: 9 bytes
 *   [uint16: x] [uint16: y] [uint8: r] [uint8: g] [uint8: b]
 *   [uint8: radius] [uint8: alpha]
 *
 * Frame format:
 *   [2B: width] [2B: height] [4B: num_splats] [4B: splat_data_zlen]
 *   [zlib: splat_data (9 bytes × N)]
 */
static void* compress_iframe_worker(void *arg) {
    batch_job_t *job = (batch_job_t*)arg;
    qtsq_video_encoder_t *enc = job->enc;
    
#ifdef __APPLE__
    qtsq_metal_ctx_t *metal = qtsq_metal_global();
    
    FILE *dbg = fopen("/tmp/qtsq_debug.log", "a");
    if (!dbg) dbg = stderr;
    
    if (metal) {
        fprintf(dbg, "[QTSQ] Splat pipeline active, metal OK\n");
        uint32_t w = enc->width, h = enc->height;
        uint8_t ch = enc->channels;
        size_t pixel_count = (size_t)w * h;
        
        /* Step 1: Sobel Edge Detection (GPU) */
        float *gradient = (float *)calloc(pixel_count, sizeof(float));
        if (!gradient) { fprintf(dbg, "[QTSQ] FALLBACK: gradient alloc failed\n"); if(dbg!=stderr) fclose(dbg); goto fallback; }
        qtsq_metal_sobel(metal, job->raw_pixels, gradient, w, h, ch);
        
        /* Step 2: Region Classification (GPU) — 3-tier mask
         *   0 = smooth (big splats, radius 16-48)
         *   1 = medium (mid splats, radius 5-12)
         *   2 = dense  (small splats, radius 2-4) */
        uint8_t *mask = (uint8_t *)calloc(pixel_count, 1);
        if (!mask) { free(gradient); fprintf(dbg, "[QTSQ] FALLBACK: mask alloc failed\n"); if(dbg!=stderr) fclose(dbg); goto fallback; }
        float class_threshold = 30.0f;
        qtsq_metal_classify_regions(metal, gradient, mask, w, h, class_threshold);
        free(gradient); /* No longer needed */
        gradient = NULL;
        
        /* Step 3: Adaptive Splat Placement (CPU)
         * Different spacing per region tier:
         *   Dense (mask=2): spacing ~3px, radius 2
         *   Medium (mask=1): spacing ~8px, radius 6
         *   Smooth (mask=0): spacing ~24px, radius 20 */
        uint32_t max_splats = 100000; /* Budget for 1080p — 100K for high quality */
        
        /* Packed splat data: 5 bytes each for GPU input [u16 x, u16 y, u8 radius] */
        uint8_t *splat_input = (uint8_t *)malloc(max_splats * 5);
        if (!splat_input) { free(mask); fprintf(dbg, "[QTSQ] FALLBACK: splat_input alloc failed\n"); if(dbg!=stderr) fclose(dbg); goto fallback; }
        
        uint32_t num_splats = 0;
        
        /* Pass 1: Dense regions (mask=2) — small splats */
        {
            float spacing = 3.0f;
            uint8_t radius = 3; /* >= spacing * 0.71 for full coverage */
            for (float y = 1.0f; y < h - 1 && num_splats < max_splats; y += spacing) {
                for (float x = 1.0f; x < w - 1 && num_splats < max_splats; x += spacing) {
                    int ix = (int)x, iy = (int)y;
                    if (mask[iy * w + ix] == 2) {
                        uint16_t sx = (uint16_t)ix, sy = (uint16_t)iy;
                        uint8_t *sp = splat_input + num_splats * 5;
                        memcpy(sp, &sx, 2);
                        memcpy(sp + 2, &sy, 2);
                        sp[4] = radius;
                        num_splats++;
                    }
                }
            }
        }
        
        /* Pass 2: Medium regions (mask=1) — medium splats */
        {
            float spacing = 8.0f;
            uint8_t radius = 8; /* >= spacing * 0.71 for full coverage */
            for (float y = 4.0f; y < h - 4 && num_splats < max_splats; y += spacing) {
                for (float x = 4.0f; x < w - 4 && num_splats < max_splats; x += spacing) {
                    int ix = (int)x, iy = (int)y;
                    if (mask[iy * w + ix] == 1) {
                        uint16_t sx = (uint16_t)ix, sy = (uint16_t)iy;
                        uint8_t *sp = splat_input + num_splats * 5;
                        memcpy(sp, &sx, 2);
                        memcpy(sp + 2, &sy, 2);
                        sp[4] = radius;
                        num_splats++;
                    }
                }
            }
        }
        
        /* Pass 3: Smooth regions (mask=0) — large splats */
        {
            float spacing = 24.0f;
            uint8_t radius = 24; /* >= spacing * 0.71 for full coverage */
            for (float y = 12.0f; y < h - 12 && num_splats < max_splats; y += spacing) {
                for (float x = 12.0f; x < w - 12 && num_splats < max_splats; x += spacing) {
                    int ix = (int)x, iy = (int)y;
                    if (mask[iy * w + ix] == 0) {
                        uint16_t sx = (uint16_t)ix, sy = (uint16_t)iy;
                        uint8_t *sp = splat_input + num_splats * 5;
                        memcpy(sp, &sx, 2);
                        memcpy(sp + 2, &sy, 2);
                        sp[4] = radius;
                        num_splats++;
                    }
                }
            }
        }
        
        free(mask);
        fprintf(dbg, "[QTSQ Encode] Splat I-frame: %u splats placed\n", num_splats);
        
        if (num_splats == 0) {
            fprintf(dbg, "[QTSQ] FALLBACK: 0 splats placed\n");
            free(splat_input);
            if(dbg!=stderr) fclose(dbg);
            goto fallback;
        }
        
        /* Step 4: GPU Color Sampling — compute best-fit color for each splat */
        uint8_t *colors = (uint8_t *)malloc(num_splats * 3);
        if (!colors) { free(splat_input); fprintf(dbg, "[QTSQ] FALLBACK: colors alloc failed\n"); if(dbg!=stderr) fclose(dbg); goto fallback; }
        
        int cs_ret = qtsq_metal_splat_color_sample(metal, splat_input, num_splats,
                                       job->raw_pixels, colors, w, h, ch);
        
        /* CPU fallback if GPU color sampling failed */
        if (cs_ret != 0) {
            for (uint32_t i = 0; i < num_splats; i++) {
                uint16_t sx, sy;
                memcpy(&sx, splat_input + i * 5, 2);
                memcpy(&sy, splat_input + i * 5 + 2, 2);
                if (sx < w && sy < h) {
                    size_t pidx = ((size_t)sy * w + sx) * ch;
                    colors[i * 3]     = job->raw_pixels[pidx];
                    colors[i * 3 + 1] = job->raw_pixels[pidx + 1];
                    colors[i * 3 + 2] = job->raw_pixels[pidx + 2];
                }
            }
        }
        
        /* Step 5: Pack into final 9-byte-per-splat format and compress */
        size_t raw_size = (size_t)num_splats * 9;
        uint8_t *raw_buf = (uint8_t *)malloc(raw_size);
        if (!raw_buf) { free(colors); free(splat_input); fprintf(dbg, "[QTSQ] FALLBACK: raw_buf alloc failed\n"); if(dbg!=stderr) fclose(dbg); goto fallback; }
        
        for (uint32_t i = 0; i < num_splats; i++) {
            uint8_t *dst = raw_buf + i * 9;
            uint8_t *src = splat_input + i * 5;
            memcpy(dst, src, 4);       /* x, y (uint16 each) */
            dst[4] = colors[i * 3];     /* r */
            dst[5] = colors[i * 3 + 1]; /* g */
            dst[6] = colors[i * 3 + 2]; /* b */
            dst[7] = src[4];            /* radius */
            dst[8] = 255;               /* alpha (fully opaque) */
        }
        
        /* Cache splat positions + colors for P-frame delta encoding
         * MUST happen BEFORE free(colors) and free(splat_input)! */
        if (enc->ref_splat_input) free(enc->ref_splat_input);
        if (enc->ref_splat_colors) free(enc->ref_splat_colors);
        enc->ref_splat_input = (uint8_t *)malloc(num_splats * 5);
        enc->ref_splat_colors = (uint8_t *)malloc(num_splats * 3);
        if (enc->ref_splat_input && enc->ref_splat_colors) {
            memcpy(enc->ref_splat_input, splat_input, num_splats * 5);
            memcpy(enc->ref_splat_colors, colors, num_splats * 3);
            enc->ref_splat_count = num_splats;
        } else {
            enc->ref_splat_count = 0;
        }
        
        free(colors);
        free(splat_input);
        
        /* zlib compress */
        uLongf zlen = compressBound((uLong)raw_size);
        uint8_t *zbuf = (uint8_t *)malloc(zlen);
        if (!zbuf) { free(raw_buf); fprintf(dbg, "[QTSQ] FALLBACK: zbuf alloc failed\n"); if(dbg!=stderr) fclose(dbg); goto fallback; }
        
        int zret = compress2(zbuf, &zlen, raw_buf, (uLong)raw_size, Z_DEFAULT_COMPRESSION);
        free(raw_buf);
        
        if (zret != Z_OK) { free(zbuf); fprintf(dbg, "[QTSQ] FALLBACK: zlib compress failed\n"); if(dbg!=stderr) fclose(dbg); goto fallback; }
        
        /* Assemble frame: [2B: w][2B: h][4B: num_splats][4B: zlen][zlib data] */
        size_t hdr_size = 12;
        size_t total = hdr_size + zlen;
        uint8_t *frame_buf = (uint8_t *)malloc(total);
        
        if (frame_buf) {
            uint16_t w16 = (uint16_t)w, h16 = (uint16_t)h;
            uint32_t ns32 = num_splats, zl32 = (uint32_t)zlen;
            
            memcpy(frame_buf, &w16, 2);
            memcpy(frame_buf + 2, &h16, 2);
            memcpy(frame_buf + 4, &ns32, 4);
            memcpy(frame_buf + 8, &zl32, 4);
            memcpy(frame_buf + 12, zbuf, zlen);
            
            job->frame_type = 'S'; /* Splat keyframe */
            job->compressed_data = frame_buf;
            job->compressed_size = total;
            job->ret_code = QTSQ_OK;
        } else {
            fprintf(dbg, "[QTSQ] FALLBACK: frame_buf alloc failed\n");
            job->ret_code = QTSQ_ERR_ALLOC;
        }
        
        if(dbg!=stderr) fclose(dbg);
        free(zbuf);
        free(job->raw_pixels);
        job->raw_pixels = NULL;
        return NULL;
    } else {
        fprintf(dbg, "[QTSQ] FALLBACK: metal is NULL\n");
    }
    
fallback:
    fprintf(dbg, "[QTSQ] Using K-frame fallback (raw zlib)\n");
    if(dbg!=stderr) fclose(dbg);
#endif /* __APPLE__ */
    
    /* CPU fallback: direct zlib (same as 'K' frame) */
    {
        uint32_t cw = enc->width, ch_val = enc->height;
        size_t raw_size = (size_t)cw * ch_val * enc->channels;
        uLongf compressed_bound = compressBound((uLong)raw_size);
        size_t hdr_size = 8;
        uint8_t *out_buf = (uint8_t *)malloc(hdr_size + compressed_bound);
        if (!out_buf) {
            job->ret_code = QTSQ_ERR_ALLOC;
            free(job->raw_pixels);
            job->raw_pixels = NULL;
            return NULL;
        }
        uint16_t cw16 = (uint16_t)cw, ch16 = (uint16_t)ch_val;
        uint32_t raw32 = (uint32_t)raw_size;
        memcpy(out_buf, &cw16, 2);
        memcpy(out_buf + 2, &ch16, 2);
        memcpy(out_buf + 4, &raw32, 4);
        uLongf dest_len = compressed_bound;
        int zret = compress2(out_buf + hdr_size, &dest_len, job->raw_pixels, (uLong)raw_size, Z_BEST_SPEED);
        if (zret != Z_OK) {
            free(out_buf);
            job->ret_code = QTSQ_ERR_IO;
            free(job->raw_pixels);
            job->raw_pixels = NULL;
            return NULL;
        }
        job->frame_type = 'K';
        job->compressed_data = out_buf;
        job->compressed_size = hdr_size + dest_len;
        job->ret_code = QTSQ_OK;
        free(job->raw_pixels);
        job->raw_pixels = NULL;
        return NULL;
    }
}

static int flush_batch(qtsq_video_encoder_t *enc) {
    if (enc->batch_count == 0) return QTSQ_OK;

    /* Separate I-frames and P-frames for different workers */
    int i_count = 0, p_count = 0;
    for (int i = 0; i < enc->batch_count; i++) {
        if (enc->batch[i].frame_type == 'I') i_count++;
        else p_count++;
    }
    
    /* Dispatch I-frames (capped at MAX_PARALLEL_IFRAMES to limit memory) */
    if (i_count > 0) {
        batch_job_t *i_jobs = (batch_job_t *)malloc(i_count * sizeof(batch_job_t));
        int *i_indices = (int *)malloc(i_count * sizeof(int)); /* Track original positions */
        int idx = 0;
        for (int i = 0; i < enc->batch_count; i++) {
            if (enc->batch[i].frame_type == 'I') {
                i_jobs[idx] = enc->batch[i];
                i_indices[idx] = i;
                idx++;
            }
        }
        /* Process I-frames in small chunks to limit memory */
        for (int start = 0; start < i_count; start += MAX_PARALLEL_IFRAMES) {
            int chunk = i_count - start;
            if (chunk > MAX_PARALLEL_IFRAMES) chunk = MAX_PARALLEL_IFRAMES;
            qtsq_dispatch((void *(*)(void *))compress_iframe_worker, &i_jobs[start], sizeof(batch_job_t), chunk);
        }
        /* Copy results back by tracked index (frame_type may have changed to 'S'/'K') */
        for (int i = 0; i < i_count; i++) {
            enc->batch[i_indices[i]] = i_jobs[i];
        }
        free(i_indices);
        free(i_jobs);
    }
    
    /* Dispatch P-frames */
    if (p_count > 0) {
        batch_job_t *p_jobs = (batch_job_t *)malloc(p_count * sizeof(batch_job_t));
        int idx = 0;
        for (int i = 0; i < enc->batch_count; i++) {
            if (enc->batch[i].frame_type == 'P') {
                p_jobs[idx++] = enc->batch[i];
            }
        }
        qtsq_dispatch((void *(*)(void *))compress_pframe_worker, p_jobs, sizeof(batch_job_t), p_count);
        idx = 0;
        for (int i = 0; i < enc->batch_count; i++) {
            if (enc->batch[i].frame_type == 'P') {
                enc->batch[i] = p_jobs[idx++];
            }
        }
        free(p_jobs);
    }
    
    /* Merge results into bitstream IN ORDER */
    int last_error = QTSQ_OK;
    for (int i = 0; i < enc->batch_count; i++) {
        batch_job_t *job = &enc->batch[i];
        if (job->ret_code == QTSQ_OK && job->compressed_data) {
            uint32_t offset = (uint32_t)enc->bitstream_size;
            uint32_t size = (uint32_t)job->compressed_size;
            
            if (append_to_bitstream(enc, job->compressed_data, job->compressed_size) == QTSQ_OK) {
                append_to_index(enc, offset, size, job->frame_type);
            } else {
                last_error = QTSQ_ERR_ALLOC;
            }
            free(job->compressed_data);
            job->compressed_data = NULL;
            
            /* If this was an I-frame, update reference */
            /* We need to decompress to get actual pixels — but we stored raw_pixels before freeing */
            /* Actually, raw_pixels was freed in the worker. We'll update ref_frame in add_frame() instead. */
        } else {
            if (job->ret_code != QTSQ_OK) last_error = job->ret_code;
        }
        if (job->raw_pixels) {
            free(job->raw_pixels);
            job->raw_pixels = NULL;
        }
        if (job->delta_buffer) {
            free(job->delta_buffer);
            job->delta_buffer = NULL;
        }
    }
    enc->batch_count = 0;
    return last_error;
}

int qtsq_video_encoder_add_frame(qtsq_video_encoder_t *enc, const uint8_t *pixels) {
    if (!enc || !pixels) return QTSQ_ERR_NULL;

    size_t frame_bytes = (size_t)enc->width * enc->height * enc->channels;
    int logical_idx = (int)(enc->frame_count + enc->batch_count);
    
    /* Determine frame type: I-frame at interval boundaries */
    uint8_t frame_type;
    if (logical_idx == 0 ||
        (logical_idx % (int)enc->i_frame_interval) == 0) {
        frame_type = 'I'; /* Will become 'S' after worker processes it */
    } else {
        frame_type = 'P'; /* Splat color delta against reference */
    }
    
    batch_job_t *job = &enc->batch[enc->batch_count];
    memset(job, 0, sizeof(batch_job_t));
    job->enc = enc;
    job->frame_index = logical_idx;
    job->frame_type = frame_type;
    job->raw_pixels = (uint8_t*)malloc(frame_bytes);
    if (!job->raw_pixels) return QTSQ_ERR_ALLOC;
    memcpy(job->raw_pixels, pixels, frame_bytes);
    
    enc->batch_count++;

    if (enc->batch_count >= enc->batch_capacity) {
        return flush_batch(enc);
    }

    return QTSQ_OK;
}

int qtsq_video_encoder_finish(qtsq_video_encoder_t *enc) {
    if (!enc) return QTSQ_ERR_NULL;

    flush_batch(enc);

    /* Build the final payload in the context */
    /* Structure: [Frame Index] [Bitstream] */
    /* Frame Index: 
       [Magic "IDX1"] (4 bytes)
       [Num Frames] (4 bytes)
       [Offsets] (4 * num_frames)
       [Sizes] (4 * num_frames)
       [Types] (1 * num_frames)
    */

    size_t index_size = 4 + 4 + (enc->frame_count * 4) + (enc->frame_count * 4) + enc->frame_count;
    size_t total_payload = index_size + enc->bitstream_size;

    enc->ctx->singularity = (uint8_t *)malloc(total_payload);
    if (!enc->ctx->singularity) return QTSQ_ERR_ALLOC;
    enc->ctx->singularity_size = total_payload;

    uint8_t *p = enc->ctx->singularity;
    p[0] = 'I'; p[1] = 'D'; p[2] = 'X'; p[3] = '1'; p += 4;
    memcpy(p, &enc->frame_count, 4); p += 4;
    
    if (enc->frame_count > 0) {
        memcpy(p, enc->frame_offsets, enc->frame_count * 4); p += enc->frame_count * 4;
        memcpy(p, enc->frame_sizes, enc->frame_count * 4); p += enc->frame_count * 4;
        memcpy(p, enc->frame_types, enc->frame_count); p += enc->frame_count;
    }

    /* Copy bitstream */
    if (enc->bitstream_size > 0 && enc->bitstream != NULL) {
        memcpy(p, enc->bitstream, enc->bitstream_size);
    }

    /* Update header sizes */
    enc->ctx->header.original_size = (uint64_t)enc->width * enc->height * enc->channels * enc->frame_count;

    fprintf(stderr, "[QTSQ Video] Encoded %u frames (%u I-frames, %u P-frames)\n",
            enc->frame_count,
            (uint32_t)enc->frame_count / enc->i_frame_interval + 1,
            enc->frame_count > 0 ? enc->frame_count - (enc->frame_count / enc->i_frame_interval + 1) : 0);

    return QTSQ_OK;
}

qtsq_context_t* qtsq_video_encoder_get_context(qtsq_video_encoder_t *enc) {
    if (!enc) return NULL;
    return enc->ctx;
}

void qtsq_video_encoder_free(qtsq_video_encoder_t *enc) {
    if (!enc) return;
    if (enc->bitstream) free(enc->bitstream);
    if (enc->frame_offsets) free(enc->frame_offsets);
    if (enc->frame_sizes) free(enc->frame_sizes);
    if (enc->frame_types) free(enc->frame_types);
    if (enc->ref_frame) free(enc->ref_frame);
    if (enc->ref_splat_input) free(enc->ref_splat_input);
    if (enc->ref_splat_colors) free(enc->ref_splat_colors);
    for (int i = 0; i < enc->batch_count; i++) {
        if (enc->batch[i].raw_pixels) free(enc->batch[i].raw_pixels);
        if (enc->batch[i].compressed_data) free(enc->batch[i].compressed_data);
        if (enc->batch[i].delta_buffer) free(enc->batch[i].delta_buffer);
    }
    free(enc);
}
