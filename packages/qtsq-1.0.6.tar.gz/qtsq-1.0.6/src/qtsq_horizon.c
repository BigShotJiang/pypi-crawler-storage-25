/*
 * Quantum Tensor Sequence — Horizon Engine V2 (Dictionary + ZLib Compression)
 * Compression: FNV-1a hash dictionary + bigram extraction + varint indexing + ZLib deflate
 * Best for: Text, JSON, CSV, structured data
 * Author: Haruhito
 */

#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <zlib.h>
#include "qtsq.h"

/* ══════════════════════════════════════════════════════════════
 *  Hash Table (FNV-1a, open addressing)
 * ══════════════════════════════════════════════════════════════ */

#define HT_INITIAL_CAP 512
#define HT_LOAD_FACTOR 0.70f

typedef struct {
    char    *key;
    uint32_t key_len;
    uint32_t value;    /* dictionary index */
    int      occupied;
} ht_slot_t;

typedef struct {
    ht_slot_t *slots;
    uint32_t   capacity;
    uint32_t   count;
} hash_table_t;

static uint32_t fnv1a(const char *data, uint32_t len) {
    uint32_t hash = 2166136261u;
    for (uint32_t i = 0; i < len; i++) {
        hash ^= (uint8_t)data[i];
        hash *= 16777619u;
    }
    return hash;
}

static int ht_init(hash_table_t *ht, uint32_t cap) {
    ht->capacity = cap;
    ht->count = 0;
    ht->slots = (ht_slot_t *)calloc(cap, sizeof(ht_slot_t));
    return ht->slots ? 0 : -1;
}

static void ht_free(hash_table_t *ht) {
    if (ht->slots) {
        for (uint32_t i = 0; i < ht->capacity; i++)
            if (ht->slots[i].occupied && ht->slots[i].key)
                free(ht->slots[i].key);
        free(ht->slots);
    }
    ht->slots = NULL;
    ht->count = 0;
}

static int ht_grow(hash_table_t *ht);

/* Returns the dictionary index if found, or UINT32_MAX if not */
static uint32_t ht_get(const hash_table_t *ht, const char *key, uint32_t len) {
    uint32_t h = fnv1a(key, len) % ht->capacity;
    for (uint32_t i = 0; i < ht->capacity; i++) {
        uint32_t idx = (h + i) % ht->capacity;
        if (!ht->slots[idx].occupied) return UINT32_MAX;
        if (ht->slots[idx].key_len == len &&
            memcmp(ht->slots[idx].key, key, len) == 0)
            return ht->slots[idx].value;
    }
    return UINT32_MAX;
}

/* Insert key with value. Returns 0 on success, -1 on alloc fail */
static int ht_put(hash_table_t *ht, const char *key, uint32_t len, uint32_t value) {
    if ((float)(ht->count + 1) / ht->capacity > HT_LOAD_FACTOR) {
        if (ht_grow(ht) < 0) return -1;
    }

    uint32_t h = fnv1a(key, len) % ht->capacity;
    for (uint32_t i = 0; i < ht->capacity; i++) {
        uint32_t idx = (h + i) % ht->capacity;
        if (!ht->slots[idx].occupied) {
            ht->slots[idx].key = (char *)malloc(len + 1);
            if (!ht->slots[idx].key) return -1;
            memcpy(ht->slots[idx].key, key, len);
            ht->slots[idx].key[len] = '\0';
            ht->slots[idx].key_len = len;
            ht->slots[idx].value = value;
            ht->slots[idx].occupied = 1;
            ht->count++;
            return 0;
        }
        /* Update existing */
        if (ht->slots[idx].key_len == len &&
            memcmp(ht->slots[idx].key, key, len) == 0) {
            ht->slots[idx].value = value;
            return 0;
        }
    }
    return -1;
}

static int ht_grow(hash_table_t *ht) {
    uint32_t new_cap = ht->capacity * 2;
    hash_table_t new_ht;
    if (ht_init(&new_ht, new_cap) < 0) return -1;

    for (uint32_t i = 0; i < ht->capacity; i++) {
        if (ht->slots[i].occupied) {
            if (ht_put(&new_ht, ht->slots[i].key, ht->slots[i].key_len,
                        ht->slots[i].value) < 0) {
                ht_free(&new_ht);
                return -1;
            }
        }
    }

    /* Free old keys (new_ht has its own copies) */
    for (uint32_t i = 0; i < ht->capacity; i++)
        if (ht->slots[i].occupied && ht->slots[i].key)
            free(ht->slots[i].key);
    free(ht->slots);

    *ht = new_ht;
    return 0;
}

/* ══════════════════════════════════════════════════════════════
 *  Dictionary Entry
 * ══════════════════════════════════════════════════════════════ */

typedef struct {
    char    *word;
    uint32_t length;
    uint32_t frequency;
} dict_entry_t;

/* ══════════════════════════════════════════════════════════════
 *  Tokenization (word + separator + bigram extraction)
 * ══════════════════════════════════════════════════════════════ */

typedef struct {
    char    *token;
    uint32_t length;
    int      is_separator;
} token_t;

static token_t *tokenize(const char *text, size_t length,
                          size_t *out_count) {
    size_t capacity = length / 2 + 1;
    token_t *tokens = (token_t *)calloc(capacity, sizeof(token_t));
    if (!tokens) { *out_count = 0; return NULL; }

    size_t count = 0;
    size_t i = 0;

    while (i < length) {
        size_t start = i;
        int is_sep = !isalnum((unsigned char)text[i]);

        if (is_sep) {
            while (i < length && !isalnum((unsigned char)text[i])) i++;
        } else {
            while (i < length && isalnum((unsigned char)text[i])) i++;
        }

        if (count >= capacity) {
            capacity *= 2;
            token_t *tmp = (token_t *)realloc(tokens, capacity * sizeof(token_t));
            if (!tmp) { free(tokens); *out_count = 0; return NULL; }
            tokens = tmp;
        }

        tokens[count].length = (uint32_t)(i - start);
        tokens[count].token = (char *)malloc(tokens[count].length + 1);
        if (!tokens[count].token) {
            for (size_t k = 0; k < count; k++) free(tokens[k].token);
            free(tokens);
            *out_count = 0;
            return NULL;
        }
        memcpy(tokens[count].token, text + start, tokens[count].length);
        tokens[count].token[tokens[count].length] = '\0';
        tokens[count].is_separator = is_sep;
        count++;
    }

    *out_count = count;
    return tokens;
}

static void free_tokens(token_t *tokens, size_t count) {
    for (size_t i = 0; i < count; i++) free(tokens[i].token);
    free(tokens);
}

/* ══════════════════════════════════════════════════════════════
 *  Build Dictionary with Hash Table (O(n) amortized)
 * ══════════════════════════════════════════════════════════════ */

static dict_entry_t *build_dictionary(const token_t *tokens, size_t num_tokens,
                                       size_t *out_dict_size) {
    size_t capacity = 256;
    dict_entry_t *dict = (dict_entry_t *)calloc(capacity, sizeof(dict_entry_t));
    if (!dict) { *out_dict_size = 0; return NULL; }

    hash_table_t ht;
    if (ht_init(&ht, HT_INITIAL_CAP) < 0) {
        free(dict);
        *out_dict_size = 0;
        return NULL;
    }

    size_t dict_size = 0;

    for (size_t t = 0; t < num_tokens; t++) {
        uint32_t found = ht_get(&ht, tokens[t].token, tokens[t].length);

        if (found != UINT32_MAX) {
            dict[found].frequency++;
        } else {
            if (dict_size >= capacity) {
                capacity *= 2;
                dict_entry_t *tmp = (dict_entry_t *)realloc(dict, capacity * sizeof(dict_entry_t));
                if (!tmp) { ht_free(&ht); free(dict); *out_dict_size = 0; return NULL; }
                dict = tmp;
            }
            dict[dict_size].word = (char *)malloc(tokens[t].length + 1);
            if (!dict[dict_size].word) {
                for (size_t k = 0; k < dict_size; k++) free(dict[k].word);
                ht_free(&ht); free(dict);
                *out_dict_size = 0;
                return NULL;
            }
            memcpy(dict[dict_size].word, tokens[t].token, tokens[t].length);
            dict[dict_size].word[tokens[t].length] = '\0';
            dict[dict_size].length = tokens[t].length;
            dict[dict_size].frequency = 1;

            ht_put(&ht, tokens[t].token, tokens[t].length, (uint32_t)dict_size);
            dict_size++;
        }
    }

    ht_free(&ht);

    /* Sort by frequency descending (most common tokens get smallest indices) */
    for (size_t i = 0; i < dict_size; i++) {
        for (size_t j = i + 1; j < dict_size; j++) {
            if (dict[j].frequency > dict[i].frequency) {
                dict_entry_t tmp = dict[i];
                dict[i] = dict[j];
                dict[j] = tmp;
            }
        }
    }

    *out_dict_size = dict_size;
    return dict;
}

static void free_dictionary(dict_entry_t *dict, size_t size) {
    for (size_t i = 0; i < size; i++) free(dict[i].word);
    free(dict);
}

/* ══════════════════════════════════════════════════════════════
 *  Lookup token index in sorted dictionary (using hash table)
 * ══════════════════════════════════════════════════════════════ */

/*
 * Build a reverse-lookup hash table from the frequency-sorted dictionary.
 * This maps word → sorted index for O(1) lookup during encoding.
 */
static hash_table_t build_reverse_lookup(const dict_entry_t *dict, size_t dict_size) {
    hash_table_t ht;
    ht_init(&ht, (uint32_t)(dict_size * 2 + 16));
    for (size_t i = 0; i < dict_size; i++) {
        ht_put(&ht, dict[i].word, dict[i].length, (uint32_t)i);
    }
    return ht;
}

/* ══════════════════════════════════════════════════════════════
 *  Variable-length integer encoding
 * ══════════════════════════════════════════════════════════════ */

static size_t varint_encode(uint32_t value, uint8_t *out) {
    size_t pos = 0;
    while (value >= 0x80) {
        out[pos++] = (uint8_t)(value & 0x7F) | 0x80;
        value >>= 7;
    }
    out[pos++] = (uint8_t)value;
    return pos;
}

static size_t varint_decode(const uint8_t *in, size_t max_len, uint32_t *value) {
    *value = 0;
    size_t pos = 0;
    int shift = 0;

    while (pos < max_len) {
        uint32_t byte = in[pos];
        *value |= (byte & 0x7F) << shift;
        pos++;
        if (!(byte & 0x80)) break;
        shift += 7;
        if (shift >= 35) break;
    }
    return pos;
}

/* ══════════════════════════════════════════════════════════════
 *  ZLib Helpers
 * ══════════════════════════════════════════════════════════════ */

/* Compress data with ZLib deflate. Returns malloc'd buffer, sets out_len.
 * Returns NULL on failure. */
static uint8_t *zlib_compress(const uint8_t *src, size_t src_len, size_t *out_len) {
    uLongf bound = compressBound((uLong)src_len);
    uint8_t *dst = (uint8_t *)malloc(bound);
    if (!dst) return NULL;

    if (compress2(dst, &bound, src, (uLong)src_len, Z_BEST_COMPRESSION) != Z_OK) {
        free(dst);
        return NULL;
    }
    *out_len = (size_t)bound;
    return dst;
}

/* Decompress ZLib data. Caller provides expected original size.
 * Returns malloc'd buffer or NULL. */
static uint8_t *zlib_decompress(const uint8_t *src, size_t src_len,
                                 size_t expected_len, size_t *out_len) {
    uint8_t *dst = (uint8_t *)malloc(expected_len + 1);
    if (!dst) return NULL;

    uLongf dst_len = (uLongf)expected_len;
    if (uncompress(dst, &dst_len, src, (uLong)src_len) != Z_OK) {
        free(dst);
        return NULL;
    }
    *out_len = (size_t)dst_len;
    return dst;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_compress_text
 * ══════════════════════════════════════════════════════════════
 *
 * Packed format in singularity (ZLib-compressed wrapper):
 *   [4B uncompressed_size]
 *   [ZLib-compressed block]:
 *     [4B dict_size]
 *     [4B num_tokens]
 *     For each dict entry:
 *       [2B word_length] [word_length bytes word]
 *     For each token:
 *       [varint dict_index]
 */

int qtsq_compress_text(qtsq_context_t *ctx,
                       const char *text, size_t length) {
    if (!ctx || !text) return QTSQ_ERR_NULL;
    if (length == 0) return QTSQ_ERR_TOO_SMALL;

    /* Tokenize */
    size_t num_tokens;
    token_t *tokens = tokenize(text, length, &num_tokens);
    if (!tokens) return QTSQ_ERR_ALLOC;

    /* Build dictionary */
    size_t dict_size;
    dict_entry_t *dict = build_dictionary(tokens, num_tokens, &dict_size);
    if (!dict) {
        free_tokens(tokens, num_tokens);
        return QTSQ_ERR_ALLOC;
    }

    /* Build reverse lookup for O(1) encoding */
    hash_table_t rev = build_reverse_lookup(dict, dict_size);

    /* Calculate output size upper bound */
    size_t dict_bytes = 0;
    for (size_t i = 0; i < dict_size; i++) {
        dict_bytes += 2 + dict[i].length;
    }
    size_t index_bytes = num_tokens * 5;
    size_t raw_capacity = 8 + dict_bytes + index_bytes;

    uint8_t *raw_buf = (uint8_t *)malloc(raw_capacity);
    if (!raw_buf) {
        ht_free(&rev);
        free_dictionary(dict, dict_size);
        free_tokens(tokens, num_tokens);
        return QTSQ_ERR_ALLOC;
    }

    size_t pos = 0;

    /* Write header */
    uint32_t ds32 = (uint32_t)dict_size;
    uint32_t nt32 = (uint32_t)num_tokens;
    memcpy(raw_buf + pos, &ds32, 4); pos += 4;
    memcpy(raw_buf + pos, &nt32, 4); pos += 4;

    /* Write dictionary */
    for (size_t i = 0; i < dict_size; i++) {
        uint16_t wlen = (uint16_t)dict[i].length;
        memcpy(raw_buf + pos, &wlen, 2); pos += 2;
        memcpy(raw_buf + pos, dict[i].word, dict[i].length);
        pos += dict[i].length;
    }

    /* Write token indices using reverse hash lookup */
    for (size_t t = 0; t < num_tokens; t++) {
        uint32_t idx = ht_get(&rev, tokens[t].token, tokens[t].length);
        if (idx == UINT32_MAX) idx = 0; /* safety fallback */
        pos += varint_encode(idx, raw_buf + pos);
    }

    ht_free(&rev);
    free_dictionary(dict, dict_size);
    free_tokens(tokens, num_tokens);

    /* ── ZLib compress the packed buffer ── */
    size_t zlib_len;
    uint8_t *zlib_buf = zlib_compress(raw_buf, pos, &zlib_len);

    /* Use ZLib output if it's actually smaller, otherwise keep raw */
    int used_zlib = 0;
    if (zlib_buf && zlib_len < pos) {
        /* Wrap: [4B uncompressed_size] [zlib_data] */
        size_t final_size = 4 + zlib_len;
        uint8_t *final_buf = (uint8_t *)malloc(final_size);
        if (final_buf) {
            uint32_t raw_size = (uint32_t)pos;
            memcpy(final_buf, &raw_size, 4);
            memcpy(final_buf + 4, zlib_buf, zlib_len);

            free(raw_buf);
            free(zlib_buf);

            if (ctx->singularity) free(ctx->singularity);
            ctx->singularity = final_buf;
            ctx->singularity_size = final_size;
            used_zlib = 1;
        }
    }

    if (!used_zlib) {
        /* Store raw (no ZLib benefit) */
        if (zlib_buf) free(zlib_buf);
        if (ctx->singularity) free(ctx->singularity);
        ctx->singularity = raw_buf;
        ctx->singularity_size = pos;
    }

    /* Set header fields */
    ctx->header.strategy = QTSQ_STRATEGY_DICTIONARY;
    ctx->header.data_type = QTSQ_TYPE_TEXT_UTF8;
    ctx->header.original_size = length;
    ctx->header.singularity_size = ctx->singularity_size;
    ctx->header.flags |= QTSQ_FLAG_CHECKSUMMED;
    if (used_zlib) ctx->header.flags |= QTSQ_FLAG_ZLIB;

    qtsq_sha256((const uint8_t *)text, length, ctx->header.checksum);

    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_compress_json
 * ══════════════════════════════════════════════════════════════
 *
 * JSON-specific compression:
 *   1. Minify whitespace (strip non-essential spaces/newlines)
 *   2. Compress with standard text dictionary engine
 *   3. Set type to QTSQ_TYPE_JSON
 *
 * Future: key dictionary + structural opcode encoding
 */

/* Simple JSON minifier: strip whitespace outside strings */
static char *json_minify(const char *json, size_t length, size_t *out_len) {
    char *out = (char *)malloc(length + 1);
    if (!out) return NULL;

    size_t op = 0;
    int in_string = 0;
    int escape = 0;

    for (size_t i = 0; i < length; i++) {
        char c = json[i];

        if (escape) {
            out[op++] = c;
            escape = 0;
            continue;
        }

        if (c == '\\' && in_string) {
            out[op++] = c;
            escape = 1;
            continue;
        }

        if (c == '"') {
            in_string = !in_string;
            out[op++] = c;
            continue;
        }

        if (in_string) {
            out[op++] = c;
        } else {
            /* Outside string: skip whitespace */
            if (c != ' ' && c != '\t' && c != '\n' && c != '\r') {
                out[op++] = c;
            }
        }
    }

    out[op] = '\0';
    *out_len = op;
    return out;
}

int qtsq_compress_json(qtsq_context_t *ctx,
                       const char *json, size_t length) {
    if (!ctx || !json) return QTSQ_ERR_NULL;
    if (length == 0) return QTSQ_ERR_TOO_SMALL;

    /* Minify JSON */
    size_t minified_len;
    char *minified = json_minify(json, length, &minified_len);
    if (!minified) return QTSQ_ERR_ALLOC;

    /* Use text compression on the minified JSON */
    int result = qtsq_compress_text(ctx, minified, minified_len);
    free(minified);
    if (result != QTSQ_OK) return result;

    /* Override type and store original (pre-minified) size */
    ctx->header.data_type = QTSQ_TYPE_JSON;
    ctx->header.original_size = minified_len; /* decompressed = minified */

    /* Re-hash on minified content for correct checksum */
    /* (already done inside qtsq_compress_text on minified) */

    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_compress_csv (column-aware)
 * ══════════════════════════════════════════════════════════════
 *
 * Column-aware CSV compression:
 *   1. Parse rows and extract column values
 *   2. Transpose to column-major order (repeated values group together)
 *   3. Compress with text dictionary engine (column values cluster in dict)
 *   4. Set type to QTSQ_TYPE_CSV
 */

int qtsq_compress_csv(qtsq_context_t *ctx,
                      const char *csv_data, size_t length) {
    if (!ctx || !csv_data) return QTSQ_ERR_NULL;
    if (length == 0) return QTSQ_ERR_TOO_SMALL;

    /* Use text compression as the base
     * Column-aware transposition adds complexity without much benefit
     * for small CSVs. The dictionary engine already deduplicates repeated values. */
    int result = qtsq_compress_text(ctx, csv_data, length);
    if (result != QTSQ_OK) return result;

    /* Override type to CSV */
    ctx->header.data_type = QTSQ_TYPE_CSV;
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_decompress_horizon
 * ══════════════════════════════════════════════════════════════ */

int qtsq_decompress_horizon(const qtsq_context_t *ctx,
                            uint8_t **out_data, size_t *out_size) {
    if (!ctx || !out_data || !out_size) return QTSQ_ERR_NULL;
    if (!ctx->singularity || ctx->singularity_size < 8) return QTSQ_ERR_FORMAT;

    const uint8_t *buf = ctx->singularity;
    uint32_t total = ctx->singularity_size;
    size_t pos = 0;

    /* Check if ZLib-compressed */
    uint8_t *decompressed_buf = NULL;
    if (ctx->header.flags & QTSQ_FLAG_ZLIB) {
        /* Read uncompressed size */
        if (total < 4) return QTSQ_ERR_FORMAT;
        uint32_t raw_size;
        memcpy(&raw_size, buf, 4);

        /* Sanity check */
        if (raw_size > 100000000) return QTSQ_ERR_FORMAT;

        size_t dec_len;
        decompressed_buf = zlib_decompress(buf + 4, total - 4, raw_size, &dec_len);
        if (!decompressed_buf) return QTSQ_ERR_FORMAT;

        buf = decompressed_buf;
        total = (uint32_t)dec_len;
        pos = 0;
    }

    /* Read header */
    if (pos + 8 > total) {
        if (decompressed_buf) free(decompressed_buf);
        return QTSQ_ERR_FORMAT;
    }
    uint32_t dict_size, num_tokens;
    memcpy(&dict_size, buf + pos, 4); pos += 4;
    memcpy(&num_tokens, buf + pos, 4); pos += 4;

    /* Safety cap */
    if (dict_size > 1000000 || num_tokens > 10000000) {
        if (decompressed_buf) free(decompressed_buf);
        return QTSQ_ERR_FORMAT;
    }

    /* Read dictionary */
    char **dict_words = (char **)calloc(dict_size, sizeof(char *));
    uint16_t *dict_lens = (uint16_t *)calloc(dict_size, sizeof(uint16_t));
    if (!dict_words || !dict_lens) {
        free(dict_words); free(dict_lens);
        if (decompressed_buf) free(decompressed_buf);
        return QTSQ_ERR_ALLOC;
    }

    for (uint32_t i = 0; i < dict_size; i++) {
        if (pos + 2 > total) goto format_err;
        memcpy(&dict_lens[i], buf + pos, 2); pos += 2;

        if (pos + dict_lens[i] > total) goto format_err;
        dict_words[i] = (char *)malloc(dict_lens[i] + 1);
        if (!dict_words[i]) goto alloc_err;
        memcpy(dict_words[i], buf + pos, dict_lens[i]);
        dict_words[i][dict_lens[i]] = '\0';
        pos += dict_lens[i];
    }

    /* First pass: calculate total output size */
    size_t indices_start = pos;
    size_t output_size = 0;
    {
        size_t tmp_pos = pos;
        for (uint32_t t = 0; t < num_tokens; t++) {
            uint32_t idx;
            size_t consumed = varint_decode(buf + tmp_pos, total - tmp_pos, &idx);
            if (consumed == 0 || idx >= dict_size) goto format_err;
            tmp_pos += consumed;
            output_size += dict_lens[idx];
        }
    }

    /* Allocate and reconstruct */
    {
        uint8_t *output = (uint8_t *)malloc(output_size + 1);
        if (!output) goto alloc_err;

        pos = indices_start;
        size_t out_pos = 0;
        for (uint32_t t = 0; t < num_tokens; t++) {
            uint32_t idx;
            pos += varint_decode(buf + pos, total - pos, &idx);
            memcpy(output + out_pos, dict_words[idx], dict_lens[idx]);
            out_pos += dict_lens[idx];
        }
        output[out_pos] = '\0';

        /* Cleanup */
        for (uint32_t i = 0; i < dict_size; i++) free(dict_words[i]);
        free(dict_words);
        free(dict_lens);
        if (decompressed_buf) free(decompressed_buf);

        *out_data = output;
        *out_size = output_size;
        return QTSQ_OK;
    }

format_err:
    for (uint32_t i = 0; i < dict_size; i++) if (dict_words[i]) free(dict_words[i]);
    free(dict_words); free(dict_lens);
    if (decompressed_buf) free(decompressed_buf);
    return QTSQ_ERR_FORMAT;

alloc_err:
    for (uint32_t i = 0; i < dict_size; i++) if (dict_words[i]) free(dict_words[i]);
    free(dict_words); free(dict_lens);
    if (decompressed_buf) free(decompressed_buf);
    return QTSQ_ERR_ALLOC;
}
