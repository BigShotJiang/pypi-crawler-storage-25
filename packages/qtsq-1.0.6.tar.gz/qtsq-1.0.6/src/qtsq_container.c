/*
 * Quantum Tensor Sequence — Container Engine (Multi-Data .qtsq)
 * Packs multiple streams (text, image, audio, etc.) into a single .qtsq file.
 * Each stream is independently compressed with its optimal engine.
 *
 * Author: Haruhito
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <dirent.h>
#include <sys/stat.h>
#include "qtsq.h"

/* ══════════════════════════════════════════════════════════════
 *  Internal builder state (held in ctx->singularity temporarily)
 * ══════════════════════════════════════════════════════════════ */

#define CONTAINER_NAME_MAX 256

typedef struct {
    qtsq_stream_entry_t entry;
    char                name[CONTAINER_NAME_MAX];
    uint8_t            *data;       /* compressed payload */
} stream_slot_t;

typedef struct {
    stream_slot_t *streams;
    uint32_t       count;
    uint32_t       capacity;
} container_builder_t;

/* Store builder pointer in ctx->singularity (tagged with a magic prefix) */
#define BUILDER_MAGIC 0x42554C44u /* "BULD" */

static container_builder_t *get_builder(const qtsq_context_t *ctx) {
    if (!ctx || !ctx->singularity || ctx->singularity_size != sizeof(void *) + 4)
        return NULL;
    uint32_t magic;
    memcpy(&magic, ctx->singularity, 4);
    if (magic != BUILDER_MAGIC) return NULL;
    container_builder_t *b;
    memcpy(&b, ctx->singularity + 4, sizeof(void *));
    return b;
}

static void set_builder(qtsq_context_t *ctx, container_builder_t *b) {
    size_t sz = sizeof(void *) + 4;
    if (ctx->singularity) free(ctx->singularity);
    ctx->singularity = (uint8_t *)malloc(sz);
    uint32_t magic = BUILDER_MAGIC;
    memcpy(ctx->singularity, &magic, 4);
    memcpy(ctx->singularity + 4, &b, sizeof(void *));
    ctx->singularity_size = sz;
}

/* ══════════════════════════════════════════════════════════════
 *  Auto-detect file type by extension
 * ══════════════════════════════════════════════════════════════ */

typedef enum {
    FILE_CAT_TEXT,
    FILE_CAT_JSON,
    FILE_CAT_CSV,
    FILE_CAT_IMAGE,
    FILE_CAT_AUDIO,
    FILE_CAT_VIDEO,
    FILE_CAT_BINARY
} file_category_t;

static const char *get_ext(const char *path) {
    const char *dot = strrchr(path, '.');
    return dot ? dot + 1 : "";
}

static int ext_in(const char *ext, const char *list[], int n) {
    for (int i = 0; i < n; i++)
        if (strcasecmp(ext, list[i]) == 0) return 1;
    return 0;
}

static file_category_t categorize_file(const char *path) {
    const char *ext = get_ext(path);

    static const char *text_exts[] = {
        "txt", "md", "markdown", "rst", "log", "html", "htm",
        "xml", "svg", "yaml", "yml", "toml", "ini", "cfg",
        "c", "h", "cpp", "hpp", "m", "mm", "swift", "rs", "go",
        "py", "rb", "js", "ts", "jsx", "tsx", "vue", "svelte",
        "java", "kt", "kts", "cs", "dart", "lua", "sh", "bash", "zsh",
        "css", "scss", "less", "sql", "r", "pl", "php"
    };
    static const char *json_exts[] = { "json", "geojson", "jsonl" };
    static const char *csv_exts[]  = { "csv", "tsv" };
    static const char *img_exts[]  = { "png", "jpg", "jpeg", "bmp", "gif", "webp", "tiff", "tif", "ico", "heic" };
    static const char *aud_exts[]  = { "wav", "pcm", "mp3", "aac", "flac", "ogg", "m4a", "aiff" };
    static const char *vid_exts[]  = { "mp4", "mov", "mkv", "avi", "webm", "m4v", "flv", "3gp" };

    if (ext_in(ext, json_exts, 3))  return FILE_CAT_JSON;
    if (ext_in(ext, csv_exts, 2))   return FILE_CAT_CSV;
    if (ext_in(ext, text_exts, sizeof(text_exts)/sizeof(text_exts[0]))) return FILE_CAT_TEXT;
    if (ext_in(ext, img_exts, 10))  return FILE_CAT_IMAGE;
    if (ext_in(ext, aud_exts, 8))   return FILE_CAT_AUDIO;
    if (ext_in(ext, vid_exts, 8))   return FILE_CAT_VIDEO;

    return FILE_CAT_BINARY;
}

/* ══════════════════════════════════════════════════════════════
 *  Read a file into memory
 * ══════════════════════════════════════════════════════════════ */

static uint8_t *read_file_data(const char *path, size_t *out_size) {
    FILE *fp = fopen(path, "rb");
    if (!fp) { *out_size = 0; return NULL; }
    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    if (sz <= 0) { fclose(fp); *out_size = 0; return NULL; }
    uint8_t *buf = (uint8_t *)malloc((size_t)sz);
    if (!buf) { fclose(fp); *out_size = 0; return NULL; }
    fread(buf, 1, (size_t)sz, fp);
    fclose(fp);
    *out_size = (size_t)sz;
    return buf;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC: qtsq_container_create
 * ══════════════════════════════════════════════════════════════ */

int qtsq_container_create(qtsq_context_t *ctx) {
    if (!ctx) return QTSQ_ERR_NULL;

    qtsq_init(ctx);
    ctx->header.data_type = QTSQ_TYPE_CONTAINER;
    ctx->header.flags |= QTSQ_FLAG_MULTI_STREAM;

    container_builder_t *b = (container_builder_t *)calloc(1, sizeof(*b));
    if (!b) return QTSQ_ERR_ALLOC;

    b->capacity = 16;
    b->streams = (stream_slot_t *)calloc(b->capacity, sizeof(stream_slot_t));
    if (!b->streams) { free(b); return QTSQ_ERR_ALLOC; }

    set_builder(ctx, b);
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC: qtsq_container_add_file
 * ══════════════════════════════════════════════════════════════ */

int qtsq_container_add_file(qtsq_context_t *ctx, const char *path,
                             const char *stream_name) {
    if (!ctx || !path) return QTSQ_ERR_NULL;
    container_builder_t *b = get_builder(ctx);
    if (!b) return QTSQ_ERR_FORMAT;

    if (b->count >= QTSQ_MAX_STREAMS) return QTSQ_ERR_FORMAT;

    /* Grow if needed */
    if (b->count >= b->capacity) {
        b->capacity *= 2;
        stream_slot_t *tmp = (stream_slot_t *)realloc(b->streams,
                                                       b->capacity * sizeof(stream_slot_t));
        if (!tmp) return QTSQ_ERR_ALLOC;
        b->streams = tmp;
    }

    /* Read file */
    size_t file_size;
    uint8_t *raw = read_file_data(path, &file_size);
    if (!raw || file_size == 0) return QTSQ_ERR_IO;

    /* Auto-detect and compress */
    qtsq_context_t sub;
    qtsq_init(&sub);

    file_category_t cat = categorize_file(path);
    int result;

    switch (cat) {
        case FILE_CAT_TEXT:
            result = qtsq_compress_text(&sub, (const char *)raw, file_size);
            break;
        case FILE_CAT_JSON:
            result = qtsq_compress_json(&sub, (const char *)raw, file_size);
            break;
        case FILE_CAT_CSV:
            result = qtsq_compress_csv(&sub, (const char *)raw, file_size);
            break;
        default:
            /* Images, audio, video, binary — use raw Singularity for now.
             * In the container context we don't decode images/audio
             * (that requires stb_image / AVFoundation which live in tools/).
             * The CLI and Studio do the decoding + specialized compression
             * before calling qtsq_container_add_stream(). */
            result = qtsq_compress_raw(&sub, raw, file_size, 0);
            break;
    }

    free(raw);
    if (result != QTSQ_OK) { qtsq_free(&sub); return result; }

    /* Copy into builder slot */
    stream_slot_t *slot = &b->streams[b->count];
    memset(slot, 0, sizeof(*slot));

    /* Use provided stream name, or just the filename */
    const char *name = stream_name;
    if (!name) {
        name = strrchr(path, '/');
        name = name ? name + 1 : path;
    }
    strncpy(slot->name, name, CONTAINER_NAME_MAX - 1);
    slot->name[CONTAINER_NAME_MAX - 1] = '\0';

    slot->entry.data_type = sub.header.data_type;
    slot->entry.strategy = sub.header.strategy;
    slot->entry.flags = sub.header.flags;
    slot->entry.data_size = (uint32_t)sub.singularity_size;
    slot->entry.original_size = (uint32_t)sub.header.original_size;
    /* data_offset filled during pack */

    /* Steal the singularity buffer */
    slot->data = sub.singularity;
    sub.singularity = NULL;
    sub.singularity_size = 0;

    b->count++;
    qtsq_free(&sub);
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC: qtsq_container_add_stream (pre-compressed)
 * ══════════════════════════════════════════════════════════════ */

int qtsq_container_add_stream(qtsq_context_t *ctx,
                               const qtsq_context_t *sub_ctx,
                               const char *stream_name) {
    if (!ctx || !sub_ctx) return QTSQ_ERR_NULL;
    container_builder_t *b = get_builder(ctx);
    if (!b) return QTSQ_ERR_FORMAT;
    if (b->count >= QTSQ_MAX_STREAMS) return QTSQ_ERR_FORMAT;
    if (!sub_ctx->singularity || sub_ctx->singularity_size == 0) return QTSQ_ERR_NULL;

    if (b->count >= b->capacity) {
        b->capacity *= 2;
        stream_slot_t *tmp = (stream_slot_t *)realloc(b->streams,
                                                       b->capacity * sizeof(stream_slot_t));
        if (!tmp) return QTSQ_ERR_ALLOC;
        b->streams = tmp;
    }

    stream_slot_t *slot = &b->streams[b->count];
    memset(slot, 0, sizeof(*slot));

    if (stream_name) {
        strncpy(slot->name, stream_name, CONTAINER_NAME_MAX - 1);
    } else {
        snprintf(slot->name, CONTAINER_NAME_MAX, "stream_%u", b->count);
    }

    slot->entry.data_type = sub_ctx->header.data_type;
    slot->entry.strategy = sub_ctx->header.strategy;
    slot->entry.flags = sub_ctx->header.flags;
    slot->entry.data_size = (uint32_t)sub_ctx->singularity_size;
    slot->entry.original_size = (uint32_t)sub_ctx->header.original_size;

    /* Copy singularity data */
    slot->data = (uint8_t *)malloc(sub_ctx->singularity_size);
    if (!slot->data) return QTSQ_ERR_ALLOC;
    memcpy(slot->data, sub_ctx->singularity, sub_ctx->singularity_size);

    b->count++;
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC: qtsq_container_add_folder (recursive)
 * ══════════════════════════════════════════════════════════════ */

static int _add_folder_recursive(qtsq_context_t *ctx,
                                  const char *base_path,
                                  const char *rel_prefix) {
    DIR *d = opendir(base_path);
    if (!d) return QTSQ_ERR_IO;

    struct dirent *ent;
    while ((ent = readdir(d)) != NULL) {
        /* Skip . and .. and hidden files */
        if (ent->d_name[0] == '.') continue;

        char full_path[1024];
        snprintf(full_path, sizeof(full_path), "%s/%s", base_path, ent->d_name);

        char rel_name[512];
        if (rel_prefix && rel_prefix[0]) {
            snprintf(rel_name, sizeof(rel_name), "%s/%s", rel_prefix, ent->d_name);
        } else {
            snprintf(rel_name, sizeof(rel_name), "%s", ent->d_name);
        }

        struct stat st;
        if (stat(full_path, &st) != 0) continue;

        if (S_ISDIR(st.st_mode)) {
            /* Recurse into subdirectory */
            int r = _add_folder_recursive(ctx, full_path, rel_name);
            if (r != QTSQ_OK) { closedir(d); return r; }
        } else if (S_ISREG(st.st_mode)) {
            /* Skip .qtsq files to avoid double-packing */
            const char *ext = get_ext(ent->d_name);
            if (strcasecmp(ext, "qtsq") == 0 || strcasecmp(ext, "qtsw") == 0)
                continue;

            int r = qtsq_container_add_file(ctx, full_path, rel_name);
            if (r != QTSQ_OK) { closedir(d); return r; }
        }
    }

    closedir(d);
    return QTSQ_OK;
}

int qtsq_container_add_folder(qtsq_context_t *ctx, const char *folder_path) {
    if (!ctx || !folder_path) return QTSQ_ERR_NULL;
    if (!get_builder(ctx)) return QTSQ_ERR_FORMAT;
    return _add_folder_recursive(ctx, folder_path, NULL);
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC: qtsq_container_pack — serialize into singularity
 * ══════════════════════════════════════════════════════════════
 *
 * Binary layout:
 *   [4B] num_streams
 *   [16B × N] stream TOC entries
 *   For each stream:
 *     [null-terminated name, padded to 4-byte boundary]
 *     [data_size bytes of compressed data]
 */

int qtsq_container_pack(qtsq_context_t *ctx) {
    if (!ctx) return QTSQ_ERR_NULL;
    container_builder_t *b = get_builder(ctx);
    if (!b) return QTSQ_ERR_FORMAT;
    if (b->count == 0) return QTSQ_ERR_TOO_SMALL;

    /* Calculate total packed size */
    size_t toc_size = 4 + b->count * sizeof(qtsq_stream_entry_t);
    size_t data_size = 0;
    for (uint32_t i = 0; i < b->count; i++) {
        size_t name_len = strlen(b->streams[i].name) + 1;   /* null-terminated */
        size_t padded = (name_len + 3) & ~(size_t)3;         /* 4-byte align */
        data_size += padded + b->streams[i].entry.data_size;
    }

    size_t total = toc_size + data_size;
    uint8_t *buf = (uint8_t *)calloc(1, total);
    if (!buf) return QTSQ_ERR_ALLOC;

    size_t pos = 0;

    /* Write stream count */
    memcpy(buf + pos, &b->count, 4); pos += 4;

    /* First pass: calculate data offsets, then write TOC */
    uint32_t data_offset = 0;
    for (uint32_t i = 0; i < b->count; i++) {
        size_t name_len = strlen(b->streams[i].name) + 1;
        size_t padded = (name_len + 3) & ~(size_t)3;
        b->streams[i].entry.data_offset = data_offset;
        data_offset += (uint32_t)(padded + b->streams[i].entry.data_size);
    }

    /* Write TOC */
    for (uint32_t i = 0; i < b->count; i++) {
        memcpy(buf + pos, &b->streams[i].entry, sizeof(qtsq_stream_entry_t));
        pos += sizeof(qtsq_stream_entry_t);
    }

    /* Write stream data (name + payload) */
    for (uint32_t i = 0; i < b->count; i++) {
        size_t name_len = strlen(b->streams[i].name) + 1;
        size_t padded = (name_len + 3) & ~(size_t)3;
        memcpy(buf + pos, b->streams[i].name, name_len);
        pos += padded;

        if (b->streams[i].data && b->streams[i].entry.data_size > 0) {
            memcpy(buf + pos, b->streams[i].data, b->streams[i].entry.data_size);
            pos += b->streams[i].entry.data_size;
        }
    }

    /* Free builder */
    for (uint32_t i = 0; i < b->count; i++) {
        if (b->streams[i].data) free(b->streams[i].data);
    }
    free(b->streams);
    free(b);

    /* Replace singularity with packed buffer */
    if (ctx->singularity) free(ctx->singularity);
    ctx->singularity = buf;
    ctx->singularity_size = total;

    /* Update header */
    ctx->header.data_type = QTSQ_TYPE_CONTAINER;
    ctx->header.strategy = QTSQ_STRATEGY_LAYERED;
    ctx->header.flags |= QTSQ_FLAG_MULTI_STREAM;
    ctx->header.singularity_size = total;
    ctx->header.original_size = total; /* container doesn't have a single "original" */

    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC: qtsq_container_get_count
 * ══════════════════════════════════════════════════════════════ */

int qtsq_container_get_count(const qtsq_context_t *ctx, uint32_t *out_count) {
    if (!ctx || !out_count) return QTSQ_ERR_NULL;

    /* Check if it was packed (singularity starts with stream count, not builder magic) */
    if (!ctx->singularity || ctx->singularity_size < 4) return QTSQ_ERR_FORMAT;
    if (ctx->header.data_type != QTSQ_TYPE_CONTAINER) return QTSQ_ERR_TYPE;

    /* Check for builder (unpacked) */
    container_builder_t *b = get_builder(ctx);
    if (b) {
        *out_count = b->count;
        return QTSQ_OK;
    }

    /* Read from packed buffer */
    memcpy(out_count, ctx->singularity, 4);
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC: qtsq_container_get_stream — extract stream into its own context
 * ══════════════════════════════════════════════════════════════ */

int qtsq_container_get_stream(const qtsq_context_t *ctx, uint32_t index,
                               qtsq_context_t *out_ctx,
                               char *name_buf, size_t name_buf_size) {
    if (!ctx || !out_ctx) return QTSQ_ERR_NULL;
    if (ctx->header.data_type != QTSQ_TYPE_CONTAINER) return QTSQ_ERR_TYPE;
    if (!ctx->singularity || ctx->singularity_size < 4) return QTSQ_ERR_FORMAT;

    const uint8_t *buf = ctx->singularity;
    uint32_t total_size = (uint32_t)ctx->singularity_size;

    uint32_t num_streams;
    memcpy(&num_streams, buf, 4);
    if (index >= num_streams) return QTSQ_ERR_FORMAT;

    /* Read TOC entry */
    size_t toc_offset = 4 + index * sizeof(qtsq_stream_entry_t);
    if (toc_offset + sizeof(qtsq_stream_entry_t) > total_size) return QTSQ_ERR_FORMAT;

    qtsq_stream_entry_t entry;
    memcpy(&entry, buf + toc_offset, sizeof(qtsq_stream_entry_t));

    /* Data block starts after TOC */
    size_t data_block_start = 4 + num_streams * sizeof(qtsq_stream_entry_t);
    size_t stream_start = data_block_start + entry.data_offset;

    if (stream_start >= total_size) return QTSQ_ERR_FORMAT;

    /* Read name (null-terminated) */
    const char *name_ptr = (const char *)(buf + stream_start);
    size_t name_len = strnlen(name_ptr, CONTAINER_NAME_MAX);
    size_t padded_name = (name_len + 1 + 3) & ~(size_t)3;

    if (name_buf && name_buf_size > 0) {
        size_t copy_len = name_len < name_buf_size - 1 ? name_len : name_buf_size - 1;
        memcpy(name_buf, name_ptr, copy_len);
        name_buf[copy_len] = '\0';
    }

    /* Payload starts after padded name */
    size_t payload_start = stream_start + padded_name;
    if (payload_start + entry.data_size > total_size) return QTSQ_ERR_FORMAT;

    /* Build output context */
    qtsq_init(out_ctx);
    out_ctx->header.data_type = entry.data_type;
    out_ctx->header.strategy = entry.strategy;
    out_ctx->header.flags = entry.flags;
    out_ctx->header.original_size = entry.original_size;
    out_ctx->header.singularity_size = entry.data_size;

    if (entry.data_size > 0) {
        out_ctx->singularity = (uint8_t *)malloc(entry.data_size);
        if (!out_ctx->singularity) return QTSQ_ERR_ALLOC;
        memcpy(out_ctx->singularity, buf + payload_start, entry.data_size);
        out_ctx->singularity_size = entry.data_size;
    }

    return QTSQ_OK;
}
