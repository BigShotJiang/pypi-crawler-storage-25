/*
 * Quantum Tensor Sequence — File I/O (.qtsq)
 * Author: Haruhito
 */

#include "qtsq.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int qtsq_write(const qtsq_context_t *ctx, const char *filename) {
    if (!ctx || !filename) return QTSQ_ERR_NULL;

    FILE *f = fopen(filename, "wb");
    if (!f) return QTSQ_ERR_IO;

    if (fwrite(&ctx->header, sizeof(qtsq_header_t), 1, f) != 1) {
        fclose(f); return QTSQ_ERR_IO;
    }

    if (ctx->header.horizon_size > 0) {
        if (fwrite(&ctx->schema, ctx->header.horizon_size, 1, f) != 1) {
            fclose(f); return QTSQ_ERR_IO;
        }
    }

    for (uint32_t i = 0; i < ctx->num_transforms; i++) {
        fwrite(&ctx->transforms[i].type, 1, 1, f);
        fwrite(&ctx->transforms[i].param_size, 4, 1, f);
        if (ctx->transforms[i].param_size > 0 && ctx->transforms[i].params)
            fwrite(ctx->transforms[i].params, ctx->transforms[i].param_size, 1, f);
    }

    if (ctx->singularity && ctx->singularity_size > 0) {
        if (fwrite(ctx->singularity, ctx->singularity_size, 1, f) != 1) {
            fclose(f); return QTSQ_ERR_IO;
        }
    }

    if (ctx->radiation_index && ctx->num_radiation > 0) {
        fwrite(ctx->radiation_index, sizeof(qtsq_index_t), ctx->num_radiation, f);
    }

    /* Write censorship (encryption) metadata if encrypted */
    if (ctx->is_encrypted || (ctx->header.flags & QTSQ_FLAG_ENCRYPTED)) {
        fwrite(&ctx->censorship, sizeof(qtsq_censorship_t), 1, f);
    }

    /* Write recovery (ECC) data if present */
    if (ctx->has_recovery && ctx->recovery.num_chunks > 0) {
        fwrite(&ctx->recovery.num_chunks, 4, 1, f);
        fwrite(&ctx->recovery.parity_size, 4, 1, f);
        fwrite(ctx->recovery.chunk_checksums, 4, ctx->recovery.num_chunks, f);
        if (ctx->recovery.reed_solomon_parity && ctx->recovery.parity_size > 0)
            fwrite(ctx->recovery.reed_solomon_parity, ctx->recovery.parity_size, 1, f);
    }

    fclose(f);
    return QTSQ_OK;
}

int qtsq_read(qtsq_context_t *ctx, const char *filename) {
    if (!ctx || !filename) return QTSQ_ERR_NULL;

    FILE *f = fopen(filename, "rb");
    if (!f) return QTSQ_ERR_IO;

    /* Peek at version byte (offset 4) to determine header size */
    uint8_t peek_buf[5];
    if (fread(peek_buf, 1, 5, f) != 5) {
        fclose(f); return QTSQ_ERR_IO;
    }
    rewind(f);

    /* Magic check */
    if (peek_buf[0] != QTSQ_MAGIC_0 ||
        peek_buf[1] != QTSQ_MAGIC_1 ||
        peek_buf[2] != QTSQ_MAGIC_2 ||
        peek_buf[3] != QTSQ_MAGIC_3) {
        fclose(f); return QTSQ_ERR_FORMAT;
    }

    uint8_t file_version = peek_buf[4];

    if (file_version == QTSQ_VERSION_1) {
        /* Read v1 header (80 bytes) and upgrade to v2 struct */
        qtsq_header_v1_t v1;
        if (fread(&v1, sizeof(qtsq_header_v1_t), 1, f) != 1) {
            fclose(f); return QTSQ_ERR_IO;
        }
        /* Copy common fields */
        memcpy(ctx->header.magic, v1.magic, 4);
        ctx->header.version         = QTSQ_VERSION_2; /* upgrade in memory */
        ctx->header.strategy        = v1.strategy;
        ctx->header.flags           = v1.flags;
        ctx->header.data_type       = v1.data_type;
        ctx->header.num_channels    = v1.num_channels;
        ctx->header.sample_depth    = v1.sample_depth;
        ctx->header.reserved        = v1.reserved;
        ctx->header.original_size   = v1.original_size;
        ctx->header.timestamp       = v1.timestamp;
        memcpy(ctx->header.checksum, v1.checksum, 32);
        /* Zero-extend 32-bit sizes to 64-bit */
        ctx->header.horizon_size     = (uint64_t)v1.horizon_size;
        ctx->header.accretion_size   = (uint64_t)v1.accretion_size;
        ctx->header.singularity_size = (uint64_t)v1.singularity_size;
        ctx->header.radiation_size   = (uint64_t)v1.radiation_size;
    } else {
        /* Read v2 header (96 bytes) directly */
        if (fread(&ctx->header, sizeof(qtsq_header_t), 1, f) != 1) {
            fclose(f); return QTSQ_ERR_IO;
        }
    }

    if (ctx->header.horizon_size > 0) {
        size_t to_read = ctx->header.horizon_size;
        if (to_read > sizeof(qtsq_schema_t)) to_read = sizeof(qtsq_schema_t);
        if (fread(&ctx->schema, to_read, 1, f) != 1) {
            fclose(f); return QTSQ_ERR_IO;
        }
        if (ctx->header.horizon_size > to_read)
            fseek(f, ctx->header.horizon_size - to_read, SEEK_CUR);
    }

    if (ctx->header.accretion_size > 0) {
        long acc_start = ftell(f);
        long acc_end = acc_start + ctx->header.accretion_size;
        uint32_t count = 0;

        while (ftell(f) < acc_end) {
            uint8_t type; uint32_t psize;
            if (fread(&type, 1, 1, f) != 1) break;
            if (fread(&psize, 4, 1, f) != 1) break;
            fseek(f, psize, SEEK_CUR);
            count++;
        }

        ctx->num_transforms = count;
        ctx->transforms = calloc(count, sizeof(qtsq_transform_t));
        if (!ctx->transforms) { fclose(f); return QTSQ_ERR_ALLOC; }

        fseek(f, acc_start, SEEK_SET);
        for (uint32_t i = 0; i < count; i++) {
            fread(&ctx->transforms[i].type, 1, 1, f);
            fread(&ctx->transforms[i].param_size, 4, 1, f);
            if (ctx->transforms[i].param_size > 0) {
                ctx->transforms[i].params = malloc(ctx->transforms[i].param_size);
                if (!ctx->transforms[i].params) { fclose(f); return QTSQ_ERR_ALLOC; }
                fread(ctx->transforms[i].params, ctx->transforms[i].param_size, 1, f);
            }
        }
    }

    if (ctx->header.singularity_size > 0) {
        ctx->singularity_size = ctx->header.singularity_size;
        ctx->singularity = malloc(ctx->singularity_size);
        if (!ctx->singularity) { fclose(f); return QTSQ_ERR_ALLOC; }
        if (fread(ctx->singularity, ctx->singularity_size, 1, f) != 1) {
            fclose(f); return QTSQ_ERR_IO;
        }
    }

    if (ctx->header.radiation_size > 0) {
        ctx->num_radiation = ctx->header.radiation_size / sizeof(qtsq_index_t);
        ctx->radiation_index = calloc(ctx->num_radiation, sizeof(qtsq_index_t));
        if (!ctx->radiation_index) { fclose(f); return QTSQ_ERR_ALLOC; }
        fread(ctx->radiation_index, sizeof(qtsq_index_t), ctx->num_radiation, f);
    }

    ctx->is_encrypted = (ctx->header.flags & QTSQ_FLAG_ENCRYPTED) ? 1 : 0;
    ctx->has_recovery = (ctx->header.flags & QTSQ_FLAG_HAS_ECC) ? 1 : 0;

    /* Read censorship metadata if encrypted */
    if (ctx->is_encrypted) {
        if (fread(&ctx->censorship, sizeof(qtsq_censorship_t), 1, f) != 1) {
            /* If we can't read it, clear encrypted flag */
            ctx->is_encrypted = 0;
        }
    }

    /* Read recovery (ECC) data if present */
    if (ctx->has_recovery) {
        uint32_t num_chunks = 0, parity_size = 0;
        if (fread(&num_chunks, 4, 1, f) == 1 && fread(&parity_size, 4, 1, f) == 1) {
            ctx->recovery.num_chunks = num_chunks;
            ctx->recovery.parity_size = parity_size;
            ctx->recovery.chunk_checksums = (uint32_t *)calloc(num_chunks, sizeof(uint32_t));
            if (ctx->recovery.chunk_checksums) {
                fread(ctx->recovery.chunk_checksums, 4, num_chunks, f);
            }
            if (parity_size > 0) {
                ctx->recovery.reed_solomon_parity = (uint8_t *)malloc(parity_size);
                if (ctx->recovery.reed_solomon_parity) {
                    fread(ctx->recovery.reed_solomon_parity, parity_size, 1, f);
                }
            }
        }
    }

    fclose(f);
    return QTSQ_OK;
}
