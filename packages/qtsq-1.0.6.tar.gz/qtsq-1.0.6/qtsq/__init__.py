"""
qtsq — Read, write, compress, and decompress .qtsq files in Python.

Install:
    pip install .

Usage:
    import qtsq

    # ── Images ──
    qtsq.compress("photo.png", "photo.qtsq")
    qtsq.compress("photo.png", "photo.qtsq", mode="hd")
    qtsq.compress("photo.png", "photo.qtsq", mode="lossless")

    img = qtsq.decompress("photo.qtsq")        # → numpy (H, W, 3) uint8
    qtsq.render("photo.qtsq", "output.png")     # decompress + save

    # ── Text ──
    qtsq.compress_text("Hello world!", "text.qtsq")
    text = qtsq.decompress_text("text.qtsq")    # → string

    # ── Info ──
    info = qtsq.info("photo.qtsq")
    print(info)

    # ── Mesh / DTCN ──
    data = qtsq.read("photo.qtsq")
    graph = data.to_graph()

Author: haruhito
License: Proprietary
"""

import os
import numpy as np
from scipy.spatial import Delaunay

from qtsq._native import (
    read_vertices as _c_read,
    compress_image as _c_compress,
    decompress_image as _c_decompress,
    compress_text as _c_compress_text,
    decompress_raw as _c_decompress_raw,
    file_info as _c_info,
)

__version__ = "1.0.0"


# ─────────────────────────────────────────────────────────────
#  Image Compression
# ─────────────────────────────────────────────────────────────

def compress(input_path, output_path, mode="default"):
    """
    Compress an image to .qtsq format.

    Args:
        input_path:  path to input image (PNG, JPG, etc.)
        output_path: path for .qtsq file (or directory — auto-names)
        mode:
            Triangle + Splat (gravitational):
                "default"           — balanced quality/size
                "hd"                — high quality (recommended)
                "lossless"          — near-lossless
                "upscale"           — artifact cleanup for lossy inputs

            Splat-only:
                "splat"             — compact Gaussian splats
                "splat_hd"          — HD splats
                "splat_lossless"    — lossless splats

            Triangle-only:
                "triangle"          — compact mesh (for DTCN)
                "triangle_hd"       — HD mesh
                "triangle_lossless" — lossless mesh

    Example:
        qtsq.compress("photo.png", "photo.qtsq", mode="hd")
        qtsq.compress("photo.png", "photo.qtsq", mode="splat_hd")
        qtsq.compress("photo.png", "photo.qtsq", mode="triangle")
    """
    from PIL import Image

    input_path = os.path.abspath(input_path)
    output_path = os.path.abspath(output_path)

    # If output is a directory, auto-name the file
    if os.path.isdir(output_path):
        base = os.path.splitext(os.path.basename(input_path))[0]
        output_path = os.path.join(output_path, base + ".qtsq")

    img = Image.open(input_path).convert("RGB")
    pixels = np.array(img, dtype=np.uint8)
    h, w = pixels.shape[:2]
    ch = pixels.shape[2] if pixels.ndim == 3 else 1

    _c_compress(pixels.tobytes(), w, h, ch, output_path, mode)

    return output_path


def compress_bytes(pixels, width, height, channels, output_path, mode="default"):
    """
    Compress raw pixel bytes to .qtsq format.

    Args:
        pixels:      bytes or numpy array of pixel data (RGB)
        width:       image width
        height:      image height
        channels:    number of channels (1, 3, or 4)
        output_path: path for output .qtsq file
        mode:        "default", "hd", "lossless", or "upscale"
    """
    output_path = os.path.abspath(output_path)

    if isinstance(pixels, np.ndarray):
        pixels = pixels.astype(np.uint8).tobytes()

    _c_compress(pixels, width, height, channels, output_path, mode)
    return output_path


# ─────────────────────────────────────────────────────────────
#  Image Decompression
# ─────────────────────────────────────────────────────────────

def decompress(path):
    """
    Decompress a .qtsq image file to a numpy array.

    Args:
        path: path to .qtsq file

    Returns:
        numpy array (H, W, 3) uint8, RGB

    Example:
        img = qtsq.decompress("photo.qtsq")
        print(img.shape)  # (2048, 1514, 3)
    """
    path = os.path.abspath(path)
    result = _c_decompress(path)

    pixels = np.frombuffer(result["pixels"], dtype=np.uint8)
    width = result["width"]
    height = result["height"]
    ch = result["channels"]

    if ch == 0:
        ch = 3

    expected = width * height * ch
    if len(pixels) != expected:
        # Try to infer if dimensions are slightly off
        if len(pixels) % (width * ch) == 0:
            height = len(pixels) // (width * ch)
        elif len(pixels) % (height * ch) == 0:
            width = len(pixels) // (height * ch)

    if ch == 1:
        return pixels.reshape(height, width)
    return pixels.reshape(height, width, ch)


def render(qtsq_path, output_path=None):
    """
    Render a .qtsq file — display it or save it.

    Without output_path: opens a window showing the image (like QTSQStudio).
    With output_path:    saves to PNG/JPG file.

    Args:
        qtsq_path:   path to .qtsq file
        output_path:  optional — save to file instead of displaying

    Example:
        qtsq.render("photo.qtsq")              # opens window
        qtsq.render("photo.qtsq", "out.png")   # saves to file
    """
    img_array = decompress(qtsq_path)

    if output_path is not None:
        # Save to file
        from PIL import Image
        if img_array.ndim == 2:
            img = Image.fromarray(img_array, mode="L")
        else:
            img = Image.fromarray(img_array, mode="RGB")
        img.save(output_path)
        return output_path

    # Display in interactive window
    import matplotlib
    matplotlib.use('macosx')  # native macOS backend
    import matplotlib.pyplot as plt

    h, w = img_array.shape[:2]
    dpi = 100
    fig, ax = plt.subplots(1, 1, figsize=(min(w/dpi*1.2, 16), min(h/dpi*1.2, 10)))
    fig.patch.set_facecolor('#111111')

    ax.imshow(img_array, interpolation='lanczos')
    ax.axis('off')
    ax.set_position([0, 0, 1, 1])
    plt.subplots_adjust(left=0, right=1, top=1, bottom=0)

    filename = os.path.basename(qtsq_path)
    fig.canvas.manager.set_window_title(f'QTSQ — {filename}')

    # Store state for zoom/pan
    state = {'xlim': ax.get_xlim(), 'ylim': ax.get_ylim(),
             'dragging': False, 'last_xy': None}

    def on_scroll(event):
        """Scroll wheel zoom — centered on cursor."""
        if event.xdata is None or event.ydata is None:
            return
        zoom = 0.8 if event.button == 'up' else 1.25
        xl, xr = ax.get_xlim()
        yb, yt = ax.get_ylim()
        cx, cy = event.xdata, event.ydata
        ax.set_xlim(cx - (cx - xl) * zoom, cx + (xr - cx) * zoom)
        ax.set_ylim(cy - (cy - yb) * zoom, cy + (yt - cy) * zoom)
        fig.canvas.draw_idle()

    def on_press(event):
        if event.button == 1:
            state['dragging'] = True
            state['last_xy'] = (event.x, event.y)

    def on_release(event):
        state['dragging'] = False
        state['last_xy'] = None

    def on_motion(event):
        """Click-drag pan."""
        if not state['dragging'] or state['last_xy'] is None:
            return
        if event.x is None or event.y is None:
            return
        dx = event.x - state['last_xy'][0]
        dy = event.y - state['last_xy'][1]
        state['last_xy'] = (event.x, event.y)
        xl, xr = ax.get_xlim()
        yb, yt = ax.get_ylim()
        scale = (xr - xl) / fig.get_size_inches()[0] / dpi
        ax.set_xlim(xl - dx * scale, xr - dx * scale)
        ax.set_ylim(yb - dy * scale, yt - dy * scale)
        fig.canvas.draw_idle()

    def on_key(event):
        """R = reset, F = fit, Q = quit, +/- = zoom."""
        if event.key == 'r':
            ax.set_xlim(state['xlim'])
            ax.set_ylim(state['ylim'])
            fig.canvas.draw_idle()
        elif event.key == 'f':
            ax.set_xlim(-0.5, w - 0.5)
            ax.set_ylim(h - 0.5, -0.5)
            fig.canvas.draw_idle()
        elif event.key in ('+', '='):
            xl, xr = ax.get_xlim()
            yb, yt = ax.get_ylim()
            cx, cy = (xl + xr) / 2, (yb + yt) / 2
            ax.set_xlim(cx - (cx - xl) * 0.8, cx + (xr - cx) * 0.8)
            ax.set_ylim(cy - (cy - yb) * 0.8, cy + (yt - cy) * 0.8)
            fig.canvas.draw_idle()
        elif event.key in ('-', '_'):
            xl, xr = ax.get_xlim()
            yb, yt = ax.get_ylim()
            cx, cy = (xl + xr) / 2, (yb + yt) / 2
            ax.set_xlim(cx - (cx - xl) * 1.25, cx + (xr - cx) * 1.25)
            ax.set_ylim(cy - (cy - yb) * 1.25, cy + (yt - cy) * 1.25)
            fig.canvas.draw_idle()
        elif event.key == 'q':
            plt.close(fig)

    fig.canvas.mpl_connect('scroll_event', on_scroll)
    fig.canvas.mpl_connect('button_press_event', on_press)
    fig.canvas.mpl_connect('button_release_event', on_release)
    fig.canvas.mpl_connect('motion_notify_event', on_motion)
    fig.canvas.mpl_connect('key_press_event', on_key)

    plt.show()


# ─────────────────────────────────────────────────────────────
#  Text Compression
# ─────────────────────────────────────────────────────────────

def compress_text(text, output_path):
    """
    Compress text to .qtsq format.

    Args:
        text:        string to compress
        output_path: path for output .qtsq file

    Example:
        qtsq.compress_text("Hello world!", "hello.qtsq")
    """
    output_path = os.path.abspath(output_path)
    _c_compress_text(text, output_path)
    return output_path


def decompress_text(path):
    """
    Decompress a .qtsq text file to string.

    Args:
        path: path to .qtsq file

    Returns:
        string

    Example:
        text = qtsq.decompress_text("hello.qtsq")
        print(text)  # "Hello world!"
    """
    path = os.path.abspath(path)
    raw = _c_decompress_raw(path)
    return raw.decode("utf-8")


# ─────────────────────────────────────────────────────────────
#  File Info
# ─────────────────────────────────────────────────────────────

def info(path):
    """
    Get metadata from a .qtsq file without decompressing.

    Args:
        path: path to .qtsq file

    Returns:
        dict with strategy, data_type, width, height, channels,
        original_size, version, encrypted

    Example:
        info = qtsq.info("photo.qtsq")
        print(info)
    """
    path = os.path.abspath(path)
    return _c_info(path)


# ─────────────────────────────────────────────────────────────
#  Mesh / Vertex Data (for DTCN)
# ─────────────────────────────────────────────────────────────

class QTSQData:
    """Data extracted from a .qtsq file."""

    def __init__(self, path, vertices, width, height):
        self.path = path
        self.vertices = vertices
        self.width = width
        self.height = height
        self.num_vertices = len(vertices)
        self.positions = vertices[:, :2].copy()
        self.colors = vertices[:, 2:5].copy() / 255.0
        self._tri = None

    @property
    def triangles(self):
        self._ensure_tri()
        return self._tri.simplices

    @property
    def neighbors(self):
        self._ensure_tri()
        return self._tri.neighbors

    @property
    def num_triangles(self):
        return len(self.triangles)

    def _ensure_tri(self):
        if self._tri is None:
            self._tri = Delaunay(self.positions)

    def triangle_features(self):
        """9-dim features + normalized areas per triangle."""
        self._ensure_tri()
        s = self._tri.simplices
        M = len(s)
        f = np.zeros((M, 9), dtype=np.float32)
        a = np.zeros(M, dtype=np.float32)
        for i in range(M):
            v0,v1,v2 = s[i]
            p0,p1,p2 = self.positions[v0],self.positions[v1],self.positions[v2]
            c0,c1,c2 = self.colors[v0],self.colors[v1],self.colors[v2]
            f[i,0:3] = (c0+c1+c2)/3.0
            a[i] = 0.5*abs((p1[0]-p0[0])*(p2[1]-p0[1])-(p2[0]-p0[0])*(p1[1]-p0[1]))
            e01,e12,e20 = np.linalg.norm(p1-p0),np.linalg.norm(p2-p1),np.linalg.norm(p0-p2)
            f[i,4] = min(max(e01,e12,e20)/max(min(e01,e12,e20),1e-6),10.0)/10.0
            f[i,5] = (p0[0]+p1[0]+p2[0])/(3.0*max(self.width,1))
            f[i,6] = (p0[1]+p1[1]+p2[1])/(3.0*max(self.height,1))
            f[i,7] = np.stack([c0,c1,c2]).var()
            f[i,8] = max(np.linalg.norm(c1-c0),np.linalg.norm(c2-c1),np.linalg.norm(c0-c2))
        mx = max(a.max(),1e-6)
        f[:,3]=a/mx; a/=mx
        return f,a

    def edge_features(self):
        """5-dim edge features for dual graph."""
        self._ensure_tri()
        s,n = self._tri.simplices,self._tri.neighbors
        tf,_ = self.triangle_features()
        src,dst,at = [],[],[]
        md = max(self.width,self.height,1)
        for i in range(len(s)):
            for k in range(3):
                j=n[i,k]
                if j<0: continue
                sh=set(s[i])&set(s[j])
                el=(np.linalg.norm(self.positions[list(sh)[0]]-self.positions[list(sh)[1]])/md
                    if len(sh)==2 else 0.0)
                dr,dg,db=tf[i,0]-tf[j,0],tf[i,1]-tf[j,1],tf[i,2]-tf[j,2]
                ar=min(max(tf[i,3],1e-6)/max(tf[j,3],1e-6),max(tf[j,3],1e-6)/max(tf[i,3],1e-6))
                src.append(i);dst.append(j);at.append([el,dr,dg,db,ar])
        if not src:
            return np.zeros((2,0),dtype=np.int64),np.zeros((0,5),dtype=np.float32)
        return np.array([src,dst],dtype=np.int64),np.array(at,dtype=np.float32)

    def to_graph(self, label=None):
        """Convert to PyTorch Geometric Data for DTCN."""
        import torch
        from torch_geometric.data import Data
        feats,areas = self.triangle_features()
        ei,ea = self.edge_features()
        d = Data(
            x=torch.tensor(feats,dtype=torch.float32),
            edge_index=torch.tensor(ei,dtype=torch.long),
            edge_attr=torch.tensor(ea,dtype=torch.float32),
            areas=torch.tensor(areas,dtype=torch.float32))
        if label is not None:
            d.y = torch.tensor(label,dtype=torch.long)
        return d

    def __repr__(self):
        return (f"QTSQData('{os.path.basename(self.path)}', "
                f"{self.width}×{self.height}, "
                f"{self.num_vertices:,} vertices, "
                f"{self.num_triangles:,} triangles)")


def read(path, max_vertices=100000):
    """
    Read triangle mesh data from a .qtsq file.

    Args:
        path: path to .qtsq file
        max_vertices: max vertices to extract

    Returns:
        QTSQData object

    Example:
        data = qtsq.read("photo.qtsq")
        print(data.triangles.shape)
    """
    path = os.path.abspath(path)
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")
    result = _c_read(path, max_vertices)
    vertices = np.array(result['vertices'], dtype=np.float32)
    return QTSQData(path, vertices, result['width'], result['height'])
