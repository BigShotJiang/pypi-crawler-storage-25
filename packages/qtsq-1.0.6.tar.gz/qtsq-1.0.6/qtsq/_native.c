/*
 * qtsq Python C Extension — Full SDK
 *
 * Functions:
 *   qtsq._native.read_vertices(path)              → vertex data
 *   qtsq._native.compress_image(pixels, w, h, ch, path, mode)  → compress
 *   qtsq._native.decompress_image(path)            → pixel data
 *   qtsq._native.compress_text(text, path)          → compress text
 *   qtsq._native.decompress_raw(path)               → raw bytes
 *
 * Author: haruhito
 */

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include "qtsq.h"
#include <string.h>
#include <zlib.h>

#define MAX_VERTICES 100000

/* ── Helper: get TRM3 dimensions ── */
static int get_dimensions(const qtsq_context_t *ctx, uint32_t *w, uint32_t *h) {
    if (!ctx || !ctx->singularity || ctx->singularity_size < 8) return -1;
    uint32_t uncomp_sz;
    memcpy(&uncomp_sz, ctx->singularity, 4);
    uint8_t *packed = (uint8_t *)malloc(uncomp_sz);
    if (!packed) return -1;
    uLongf dl = (uLongf)uncomp_sz;
    if (uncompress(packed, &dl, ctx->singularity + 4,
                   (uLong)(ctx->singularity_size - 4)) != Z_OK) {
        free(packed);
        return -1;
    }
    if (packed[0]!='T' || packed[1]!='R' || packed[2]!='M' || packed[3]!='3') {
        free(packed);
        return -1;
    }
    memcpy(w, packed + 4, 4);
    memcpy(h, packed + 8, 4);
    free(packed);
    return 0;
}

/* ══════════════════════════════════════════════════════
 *  1. read_vertices(path, max_vertices=100000)
 * ══════════════════════════════════════════════════════ */
static PyObject* py_read_vertices(PyObject *self, PyObject *args, PyObject *kwargs) {
    const char *path;
    int max_verts = MAX_VERTICES;
    static char *kwlist[] = {"path", "max_vertices", NULL};
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "s|i", kwlist, &path, &max_verts))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }
    if (qtsq_read(&ctx, path) != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_FileNotFoundError, "Failed to read: %s", path);
        return NULL;
    }

    uint32_t width = 0, height = 0;
    get_dimensions(&ctx, &width, &height);

    float *verts = (float *)malloc((size_t)max_verts * 5 * sizeof(float));
    if (!verts) { qtsq_free(&ctx); return PyErr_NoMemory(); }

    int nv = qtsq_extract_vertices(&ctx, verts, (uint32_t)max_verts);
    qtsq_free(&ctx);

    if (nv <= 0) {
        free(verts);
        PyErr_Format(PyExc_RuntimeError, "No vertices in: %s", path);
        return NULL;
    }

    if (width == 0 || height == 0) {
        for (int i = 0; i < nv; i++) {
            if ((uint32_t)verts[i*5+0]+1 > width)  width = (uint32_t)verts[i*5+0]+1;
            if ((uint32_t)verts[i*5+1]+1 > height) height = (uint32_t)verts[i*5+1]+1;
        }
    }

    PyObject *vert_list = PyList_New(nv);
    for (int i = 0; i < nv; i++) {
        PyList_SET_ITEM(vert_list, i, Py_BuildValue("(fffff)",
            verts[i*5+0], verts[i*5+1], verts[i*5+2], verts[i*5+3], verts[i*5+4]));
    }
    free(verts);

    return Py_BuildValue("{s:O,s:I,s:I,s:i}",
        "vertices", vert_list, "width", width, "height", height, "num_vertices", nv);
}

/* ══════════════════════════════════════════════════════
 *  2. compress_image(pixels_bytes, w, h, ch, path, mode)
 * ══════════════════════════════════════════════════════ */
static PyObject* py_compress_image(PyObject *self, PyObject *args) {
    const char *pixels;
    Py_ssize_t pixels_len;
    unsigned int w, h;
    unsigned char ch;
    const char *out_path;
    const char *mode;

    if (!PyArg_ParseTuple(args, "y#IIbss",
                          &pixels, &pixels_len, &w, &h, &ch, &out_path, &mode))
        return NULL;

    if ((Py_ssize_t)(w * h * ch) != pixels_len) {
        PyErr_Format(PyExc_ValueError,
            "Pixel buffer size mismatch: expected %u, got %zd", w*h*ch, pixels_len);
        return NULL;
    }

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }

    int rc;
    size_t src_size = (size_t)pixels_len;

    /* ── Gravitational (triangle + splat) ── */
    if (strcmp(mode, "hd") == 0) {
        rc = qtsq_compress_gravitational_hd(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "lossless") == 0) {
        rc = qtsq_compress_gravitational_lossless(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "upscale") == 0) {
        rc = qtsq_compress_gravitational_upscale(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    }
    /* ── Splat-only ── */
    else if (strcmp(mode, "splat") == 0) {
        rc = qtsq_compress_splat_compact(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "splat_hd") == 0) {
        rc = qtsq_compress_splat_hd(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "splat_lossless") == 0) {
        rc = qtsq_compress_splat_lossless(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    }
    /* ── Triangle-only ── */
    else if (strcmp(mode, "triangle") == 0) {
        rc = qtsq_compress_triangle_compact(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "triangle_hd") == 0) {
        rc = qtsq_compress_triangle_hd(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "triangle_lossless") == 0) {
        rc = qtsq_compress_triangle_lossless(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    }
    /* ── Default: gravitational (triangle + splat) ── */
    else {
        rc = qtsq_compress_gravitational(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    }

    if (rc != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_RuntimeError, "Compress failed (mode=%s, err=%d)", mode, rc);
        return NULL;
    }

    rc = qtsq_write(&ctx, out_path);
    qtsq_free(&ctx);

    if (rc != 0) {
        PyErr_Format(PyExc_RuntimeError, "Write failed: %s (err=%d)", out_path, rc);
        return NULL;
    }

    Py_RETURN_NONE;
}

/* ══════════════════════════════════════════════════════
 *  3. decompress_image(path) → {pixels, width, height, channels}
 * ══════════════════════════════════════════════════════ */
static PyObject* py_decompress_image(PyObject *self, PyObject *args) {
    const char *path;
    if (!PyArg_ParseTuple(args, "s", &path))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }
    if (qtsq_read(&ctx, path) != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_FileNotFoundError, "Failed to read: %s", path);
        return NULL;
    }

    /* Get dimensions */
    uint32_t width = 0, height = 0;
    get_dimensions(&ctx, &width, &height);

    /* Decompress based on strategy */
    uint8_t *out_data = NULL;
    size_t out_size = 0;
    int rc;

    uint8_t strategy = ctx.header.strategy;
    if (strategy == QTSQ_STRATEGY_SPLAT) {
        rc = qtsq_decompress_splat_only(&ctx, &out_data, &out_size);
    } else if (strategy == QTSQ_STRATEGY_TRIANGLE ||
               strategy == QTSQ_STRATEGY_LAYERED) {
        rc = qtsq_decompress_gravitational(&ctx, &out_data, &out_size);
    } else {
        rc = qtsq_decompress(&ctx, &out_data, &out_size);
    }

    if (rc != 0 || !out_data || out_size == 0) {
        qtsq_free(&ctx);
        if (out_data) free(out_data);
        PyErr_Format(PyExc_RuntimeError, "Decompress failed: %s (err=%d)", path, rc);
        return NULL;
    }

    /* Figure out channels */
    uint8_t ch = ctx.header.num_channels;
    if (ch == 0) ch = 3;

    /* If dimensions unknown, try to figure them out */
    if (width == 0 || height == 0) {
        /* Fallback: get from schema */
        width = ctx.schema.dimensions[0];
        height = ctx.schema.dimensions[1];
    }

    /* Return as bytes + metadata */
    PyObject *result = Py_BuildValue("{s:y#,s:I,s:I,s:B}",
        "pixels", out_data, (Py_ssize_t)out_size,
        "width", width,
        "height", height,
        "channels", ch);

    free(out_data);
    qtsq_free(&ctx);
    return result;
}

/* ══════════════════════════════════════════════════════
 *  4. compress_text(text, path)
 * ══════════════════════════════════════════════════════ */
static PyObject* py_compress_text(PyObject *self, PyObject *args) {
    const char *text;
    Py_ssize_t text_len;
    const char *out_path;

    if (!PyArg_ParseTuple(args, "s#s", &text, &text_len, &out_path))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }

    int rc = qtsq_compress_text(&ctx, text, (size_t)text_len);
    if (rc != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_RuntimeError, "Text compress failed (err=%d)", rc);
        return NULL;
    }

    rc = qtsq_write(&ctx, out_path);
    qtsq_free(&ctx);

    if (rc != 0) {
        PyErr_Format(PyExc_RuntimeError, "Write failed: %s (err=%d)", out_path, rc);
        return NULL;
    }

    Py_RETURN_NONE;
}

/* ══════════════════════════════════════════════════════
 *  5. decompress_raw(path) → bytes
 * ══════════════════════════════════════════════════════ */
static PyObject* py_decompress_raw(PyObject *self, PyObject *args) {
    const char *path;
    if (!PyArg_ParseTuple(args, "s", &path))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }
    if (qtsq_read(&ctx, path) != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_FileNotFoundError, "Failed to read: %s", path);
        return NULL;
    }

    uint8_t *out_data = NULL;
    size_t out_size = 0;
    int rc = qtsq_decompress(&ctx, &out_data, &out_size);
    qtsq_free(&ctx);

    if (rc != 0 || !out_data) {
        if (out_data) free(out_data);
        PyErr_Format(PyExc_RuntimeError, "Decompress failed: %s", path);
        return NULL;
    }

    PyObject *result = PyBytes_FromStringAndSize((const char *)out_data, (Py_ssize_t)out_size);
    free(out_data);
    return result;
}

/* ══════════════════════════════════════════════════════
 *  6. file_info(path) → dict with metadata
 * ══════════════════════════════════════════════════════ */
static PyObject* py_file_info(PyObject *self, PyObject *args) {
    const char *path;
    if (!PyArg_ParseTuple(args, "s", &path))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }
    if (qtsq_read(&ctx, path) != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_FileNotFoundError, "Failed to read: %s", path);
        return NULL;
    }

    uint32_t width = 0, height = 0;
    get_dimensions(&ctx, &width, &height);

    /* Strategy name */
    const char *strategy_name = "unknown";
    switch (ctx.header.strategy) {
        case QTSQ_STRATEGY_TRIANGLE: strategy_name = "triangle"; break;
        case QTSQ_STRATEGY_SPLAT:    strategy_name = "splat"; break;
        case QTSQ_STRATEGY_LAYERED:  strategy_name = "layered"; break;
        case QTSQ_STRATEGY_PROCEDURAL: strategy_name = "procedural"; break;
        case QTSQ_STRATEGY_FRACTAL:  strategy_name = "fractal"; break;
        case QTSQ_STRATEGY_FOURIER:  strategy_name = "fourier"; break;
        case QTSQ_STRATEGY_DICTIONARY: strategy_name = "dictionary"; break;
        case QTSQ_STRATEGY_PHOTON:   strategy_name = "photon"; break;
        case QTSQ_STRATEGY_NONE:     strategy_name = "none"; break;
        default: break;
    }

    /* Data type name */
    const char *type_name = "unknown";
    switch (ctx.header.data_type) {
        case QTSQ_TYPE_IMAGE_RGB:    type_name = "image_rgb"; break;
        case QTSQ_TYPE_IMAGE_RGBA:   type_name = "image_rgba"; break;
        case QTSQ_TYPE_IMAGE_GRAY:   type_name = "image_gray"; break;
        case QTSQ_TYPE_TEXT_ASCII:   type_name = "text_ascii"; break;
        case QTSQ_TYPE_TEXT_UTF8:    type_name = "text_utf8"; break;
        case QTSQ_TYPE_AUDIO_MONO:   type_name = "audio_mono"; break;
        case QTSQ_TYPE_AUDIO_STEREO: type_name = "audio_stereo"; break;
        case QTSQ_TYPE_VIDEO_FRAMES: type_name = "video"; break;
        case QTSQ_TYPE_RAW:          type_name = "raw"; break;
        case QTSQ_TYPE_JSON:         type_name = "json"; break;
        case QTSQ_TYPE_CSV:          type_name = "csv"; break;
        default: break;
    }

    PyObject *result = Py_BuildValue(
        "{s:s, s:s, s:I, s:I, s:B, s:K, s:I, s:i}",
        "strategy", strategy_name,
        "data_type", type_name,
        "width", width,
        "height", height,
        "channels", ctx.header.num_channels,
        "original_size", (unsigned long long)ctx.header.original_size,
        "version", (unsigned int)ctx.header.version,
        "encrypted", ctx.is_encrypted
    );

    qtsq_free(&ctx);
    return result;
}

/* ── Module definition ── */

static PyMethodDef qtsq_methods[] = {
    {"read_vertices", (PyCFunction)py_read_vertices, METH_VARARGS|METH_KEYWORDS,
     "Read vertices from a .qtsq file."},
    {"compress_image", py_compress_image, METH_VARARGS,
     "Compress pixel data to .qtsq file.\n"
     "Args: pixels_bytes, width, height, channels, output_path, mode"},
    {"decompress_image", py_decompress_image, METH_VARARGS,
     "Decompress a .qtsq image file to pixel data.\n"
     "Returns dict: {pixels, width, height, channels}"},
    {"compress_text", py_compress_text, METH_VARARGS,
     "Compress text string to .qtsq file.\n"
     "Args: text, output_path"},
    {"decompress_raw", py_decompress_raw, METH_VARARGS,
     "Decompress a .qtsq file to raw bytes."},
    {"file_info", py_file_info, METH_VARARGS,
     "Get metadata from a .qtsq file without decompressing."},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef qtsq_module = {
    PyModuleDef_HEAD_INIT,
    "qtsq._native",
    "C extension for .qtsq file operations",
    -1,
    qtsq_methods
};

PyMODINIT_FUNC PyInit__native(void) {
    return PyModule_Create(&qtsq_module);
}
