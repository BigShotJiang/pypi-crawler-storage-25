"""
Nexotype MCP Server — OAuth Provider

Bridges FastMCP's OAuth flow with Nexotype's real OAuth authorization server.
Makes HTTP requests to server.nexotype.com/accounts/mcp-oauth/* endpoints.

Runs as standalone process (not mounted on FastAPI) — no mount/sub-path issues.
FastMCP handles well-known, register, authorize, token routing at root automatically.

Flow:
1. Claude calls /authorize → we redirect to server's /accounts/mcp-oauth/authorize
2. Server redirects to frontend consent page → user clicks Allow
3. Server generates auth code → redirects browser back to Claude localhost callback
4. Claude calls /token → we proxy to server's /accounts/mcp-oauth/token → get JWT
"""

import time
import logging
from dataclasses import dataclass

import httpx
from mcp.server.auth.provider import AuthorizationParams
from mcp.shared.auth import OAuthClientInformationFull, OAuthToken
from fastmcp.server.auth import OAuthProvider, AccessToken
from mcp.server.auth.settings import ClientRegistrationOptions

from .config import API_BASE_URL, REQUEST_TIMEOUT

logger = logging.getLogger(__name__)


@dataclass
class StoredAuthorizationCode:
    """Authorization code with attributes FastMCP token handler expects."""
    code: str
    client_id: str
    redirect_uri: str
    redirect_uri_provided_explicitly: bool
    code_challenge: str


class NexotypeOAuthProvider(OAuthProvider):
    """OAuth provider that proxies to Nexotype server's OAuth endpoints via HTTP."""

    def __init__(self, base_url: str) -> None:
        super().__init__(
            base_url=base_url,
            client_registration_options=ClientRegistrationOptions(enabled=True),
        )
        # In-memory cache for tokens, codes, and registered clients
        self._access_tokens: dict[str, AccessToken] = {}
        self._auth_codes: dict[str, StoredAuthorizationCode] = {}
        self._clients: dict[str, OAuthClientInformationFull] = {}

    # ==========================================
    # Client Registration
    # ==========================================

    async def register_client(self, client_info: OAuthClientInformationFull) -> None:
        """Proxy client registration to server and cache client info.
        FastMCP generates its own client_id (UUID). We also register on our server
        so the /approve endpoint can verify the client exists in DB."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.post(
                f"{API_BASE_URL}/accounts/mcp-oauth/register",
                json={
                    "client_id": client_info.client_id,
                    "client_name": client_info.client_name,
                    "redirect_uris": [str(u) for u in client_info.redirect_uris] if client_info.redirect_uris else None,
                    "grant_types": client_info.grant_types,
                    "token_endpoint_auth_method": client_info.token_endpoint_auth_method,
                },
            )
            if r.status_code == 200 or r.status_code == 201:
                logger.info(f"Client registered on server: {client_info.client_id}")
        # Cache client info so get_client() returns correct redirect_uris
        if client_info.client_id:
            self._clients[client_info.client_id] = client_info

    async def get_client(self, client_id: str) -> OAuthClientInformationFull | None:
        """Return cached client info (registered during register_client)."""
        return self._clients.get(client_id)

    # ==========================================
    # Authorization
    # ==========================================

    async def authorize(
        self, client: OAuthClientInformationFull, params: AuthorizationParams
    ) -> str:
        """Return URL to server's authorize endpoint which redirects to frontend consent page."""
        authorize_url = (
            f"{API_BASE_URL}/accounts/mcp-oauth/authorize"
            f"?client_id={client.client_id}"
            f"&redirect_uri={params.redirect_uri}"
            f"&code_challenge={params.code_challenge}"
            f"&code_challenge_method=S256"
            f"&response_type=code"
        )
        if params.state:
            authorize_url += f"&state={params.state}"
        if params.scopes:
            authorize_url += f"&scope={'+'.join(params.scopes)}"

        return authorize_url

    # ==========================================
    # Token Exchange
    # ==========================================

    async def load_authorization_code(
        self, client: OAuthClientInformationFull, authorization_code: str
    ) -> StoredAuthorizationCode | None:
        """Load auth code — we store it in memory when consent page redirects back."""
        # The auth code comes from the server's /accounts/mcp-oauth/authorize endpoint
        # We don't have the code_challenge locally — but the server does
        # Return a stub that FastMCP can pass to exchange_authorization_code
        return StoredAuthorizationCode(
            code=authorization_code,
            client_id=client.client_id or "",
            redirect_uri="",  # Server validates this
            redirect_uri_provided_explicitly=False,
            code_challenge="",  # Server validates PKCE
        )

    async def exchange_authorization_code(
        self, client: OAuthClientInformationFull, authorization_code: StoredAuthorizationCode
    ) -> OAuthToken:
        """Proxy token exchange to server."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.post(
                f"{API_BASE_URL}/accounts/mcp-oauth/token",
                data={
                    "grant_type": "authorization_code",
                    "code": authorization_code.code,
                    "client_id": client.client_id,
                    "client_secret": client.client_secret or "",
                    "redirect_uri": authorization_code.redirect_uri,
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )

            if r.status_code != 200:
                data = r.json()
                raise ValueError(data.get("error_description", "Token exchange failed"))

            data = r.json()
            access_token = data["access_token"]
            refresh_token = data.get("refresh_token")

            # Cache access token
            self._access_tokens[access_token] = AccessToken(
                token=access_token,
                client_id=client.client_id or "",
                scopes=["all"],
                expires_at=int(time.time()) + data.get("expires_in", 1800),
            )

            return OAuthToken(
                access_token=access_token,
                token_type="Bearer",
                expires_in=data.get("expires_in", 1800),
                refresh_token=refresh_token,
            )

    async def exchange_refresh_token(
        self, client: OAuthClientInformationFull, refresh_token: str, scopes: list[str]
    ) -> OAuthToken:
        """Proxy refresh token exchange to server."""
        async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT) as http:
            r = await http.post(
                f"{API_BASE_URL}/accounts/mcp-oauth/token",
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": str(refresh_token),
                    "client_id": client.client_id,
                    "client_secret": client.client_secret or "",
                },
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )

            if r.status_code != 200:
                raise ValueError("Refresh token expired or invalid")

            data = r.json()
            new_access = data["access_token"]

            self._access_tokens[new_access] = AccessToken(
                token=new_access,
                client_id=client.client_id or "",
                scopes=["all"],
                expires_at=int(time.time()) + data.get("expires_in", 1800),
            )

            return OAuthToken(
                access_token=new_access,
                token_type="Bearer",
                expires_in=data.get("expires_in", 1800),
                refresh_token=data.get("refresh_token"),
            )

    # ==========================================
    # Token Validation
    # ==========================================

    async def load_access_token(self, token: str) -> AccessToken | None:
        """Load from cache."""
        return self._access_tokens.get(token)

    async def verify_token(self, token: str) -> AccessToken | None:
        """Verify JWT by calling server's /accounts/auth/me endpoint."""
        try:
            async with httpx.AsyncClient(timeout=10.0) as http:
                r = await http.get(
                    f"{API_BASE_URL}/accounts/auth/me",
                    headers={"Authorization": f"Bearer {token}"},
                )
                if r.status_code == 200:
                    if token not in self._access_tokens:
                        self._access_tokens[token] = AccessToken(
                            token=token,
                            client_id="",
                            scopes=["all"],
                            expires_at=int(time.time()) + 1800,
                        )
                    return self._access_tokens[token]
        except httpx.HTTPError as e:
            logger.warning(f"Token verification failed: {e}")
        return None

    async def load_refresh_token(
        self, client: OAuthClientInformationFull, refresh_token: str
    ) -> str | None:
        """Accept any refresh token — server validates on exchange."""
        return refresh_token

    # ==========================================
    # Revocation
    # ==========================================

    async def revoke_token(self, token) -> None:
        """Remove from cache."""
        self._access_tokens.pop(str(token), None)
