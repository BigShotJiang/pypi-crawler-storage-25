"""RANKIGI Connector — Universal connector for governed event streams."""

from rankigi.client import RankigiConnector
from rankigi.verifier import verify_chain, verify_signature
from rankigi.stream import EventStream
from rankigi.types import (
    RankigiEvent,
    RankigiSnapshot,
    RankigiEnvelope,
    ConnectorConfig,
    OutputMode,
    VerifyResult,
    ReplayOptions,
    CompiledSummary,
    AdapterPayload,
)
from rankigi.adapters.base import BaseAdapter
from rankigi.adapters.obsidian import ObsidianAdapter
from rankigi.adapters.s3 import S3Adapter
from rankigi.adapters.postgres import PostgresAdapter
from rankigi.adapters.kafka import KafkaAdapter

__all__ = [
    "RankigiConnector",
    "verify_chain",
    "verify_signature",
    "EventStream",
    "RankigiEvent",
    "RankigiSnapshot",
    "RankigiEnvelope",
    "ConnectorConfig",
    "OutputMode",
    "VerifyResult",
    "ReplayOptions",
    "CompiledSummary",
    "AdapterPayload",
    "BaseAdapter",
    "ObsidianAdapter",
    "S3Adapter",
    "PostgresAdapter",
    "KafkaAdapter",
]
