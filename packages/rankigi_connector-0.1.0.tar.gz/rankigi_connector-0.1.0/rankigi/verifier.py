"""Hash chain verification for RANKIGI events."""

from __future__ import annotations

import hashlib
import hmac

from rankigi.types import RankigiEvent, VerifyResult


def sha256_hex(data: str) -> str:
    """Compute SHA-256 hex digest."""
    return hashlib.sha256(data.encode()).hexdigest()


def verify_chain(events: list[RankigiEvent]) -> VerifyResult:
    """Verify the hash chain integrity of a list of events."""
    if not events:
        return VerifyResult(valid=True, broken_at=None, details="Empty chain")

    sorted_events = sorted(events, key=lambda e: e.chain_index)

    for i in range(1, len(sorted_events)):
        prev = sorted_events[i - 1]
        curr = sorted_events[i]
        if curr.previous_event_hash != prev.event_hash:
            return VerifyResult(
                valid=False,
                broken_at=curr.chain_index,
                details=(
                    f"Chain broken at index {curr.chain_index}: "
                    f"expected previous_event_hash {prev.event_hash}, "
                    f"got {curr.previous_event_hash}"
                ),
            )

    return VerifyResult(
        valid=True,
        broken_at=None,
        details=f"Chain valid: {len(sorted_events)} events verified",
    )


def verify_signature(payload: str, signature: str, api_key: str) -> bool:
    """Verify HMAC-SHA256 signature of a payload."""
    expected = hmac.new(
        api_key.encode(), payload.encode(), hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature)
