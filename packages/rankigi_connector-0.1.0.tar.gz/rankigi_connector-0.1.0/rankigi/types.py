"""Shared types for the RANKIGI connector."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

from pydantic import BaseModel


class OutputMode(str, Enum):
    RAW = "raw"
    VERIFIED = "verified"
    COMPILED = "compiled"


class RankigiEvent(BaseModel):
    event_id: str
    agent_id: str
    agent_name: str
    timestamp: str
    action_type: str
    tool_invoked: str | None
    input_hash: str
    output_hash: str
    event_hash: str
    previous_event_hash: str | None
    chain_index: int
    execution_result: str
    risk_score: float | None
    policy_flags: list[str]
    data_quality_flag: str
    decision_metadata: dict[str, Any]


class RankigiSnapshot(BaseModel):
    snapshot_id: str
    date: str
    agent_id: str | None
    total_events: int
    first_event_hash: str
    last_event_hash: str
    snapshot_hash: str
    created_at: str


class RankigiEnvelope(BaseModel):
    rankigi_version: str
    envelope_id: str
    org_id: str
    event: RankigiEvent
    rankigi_signature: str


@dataclass
class VerifyResult:
    valid: bool
    broken_at: int | None
    details: str


class CompiledSummary(BaseModel):
    agent_id: str
    agent_name: str
    period_start: str
    period_end: str
    event_count: int
    tools_used: list[str]
    action_summary: str
    risk_profile: dict[str, Any]
    patterns: list[str]
    chain_valid: bool
    first_hash: str
    last_hash: str


class AdapterPayload(BaseModel):
    mode: OutputMode
    data: RankigiEvent | CompiledSummary
    metadata: dict[str, Any]


@dataclass
class ReplayOptions:
    start: str | None = None
    end: str | None = None
    agent_id: str | None = None


@dataclass
class ConnectorConfig:
    api_key: str
    org_id: str
    mode: OutputMode
    adapter: Any  # BaseAdapter instance
    on_error: Callable[[Exception], None] | None = None
    on_event: Callable[[RankigiEvent], None] | None = None
    buffer_size: int = 100
    retry_attempts: int = 3
