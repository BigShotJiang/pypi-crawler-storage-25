"""RANKIGI Connector — main client."""

from __future__ import annotations

import asyncio
import os
from collections import Counter
from collections.abc import AsyncIterator
from datetime import datetime, timezone

import aiohttp

from rankigi.stream import EventStream
from rankigi.types import (
    AdapterPayload,
    CompiledSummary,
    ConnectorConfig,
    OutputMode,
    RankigiEnvelope,
    RankigiEvent,
    RankigiSnapshot,
    ReplayOptions,
    VerifyResult,
)
from rankigi.verifier import verify_chain

API_BASE = "https://rankigi.com/api/v1"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _process_raw(event: RankigiEvent, org_id: str) -> AdapterPayload:
    return AdapterPayload(
        mode=OutputMode.RAW,
        data=event,
        metadata={
            "org_id": org_id,
            "received_at": _now_iso(),
            "verified": False,
            "chain_index": event.chain_index,
        },
    )


class _VerifiedProcessor:
    def __init__(self, on_error: callable | None = None) -> None:
        self._last_hashes: dict[str, str] = {}
        self._on_error = on_error

    def process(
        self, event: RankigiEvent, org_id: str
    ) -> AdapterPayload | None:
        last_hash = self._last_hashes.get(event.agent_id)
        if last_hash and event.previous_event_hash != last_hash:
            err = ValueError(
                f"Chain verification failed for agent {event.agent_id} "
                f"at index {event.chain_index}: expected {last_hash}, "
                f"got {event.previous_event_hash}"
            )
            if self._on_error:
                self._on_error(err)
            return None

        self._last_hashes[event.agent_id] = event.event_hash
        return AdapterPayload(
            mode=OutputMode.VERIFIED,
            data=event,
            metadata={
                "org_id": org_id,
                "received_at": _now_iso(),
                "verified": True,
                "chain_index": event.chain_index,
            },
        )


class _CompiledProcessor:
    def __init__(self, buffer_size: int) -> None:
        self._buffer_size = buffer_size
        self._buffers: dict[str, list[RankigiEvent]] = {}

    def process(
        self, event: RankigiEvent, org_id: str
    ) -> AdapterPayload | None:
        buf = self._buffers.setdefault(event.agent_id, [])
        buf.append(event)

        should_compile = len(buf) >= self._buffer_size or (
            event.action_type == "tool_result" and len(buf) > 1
        )

        if not should_compile:
            return None

        events = buf[:]
        self._buffers[event.agent_id] = []

        first, last = events[0], events[-1]
        action_counts: Counter[str] = Counter()
        tool_set: set[str] = set()
        all_flags: list[str] = []
        total_risk = 0.0
        risk_count = 0
        chain_valid = True

        for i, e in enumerate(events):
            action_counts[e.action_type] += 1
            if e.tool_invoked:
                tool_set.add(e.tool_invoked)
            all_flags.extend(e.policy_flags)
            if e.risk_score is not None:
                total_risk += e.risk_score
                risk_count += 1
            if i > 0 and e.previous_event_hash != events[i - 1].event_hash:
                chain_valid = False

        top_action, top_count = action_counts.most_common(1)[0]
        action_summary = (
            f"{len(events)} events. Most frequent: {top_action} ({top_count}x)."
        )
        if tool_set:
            action_summary += f" Tools: {', '.join(sorted(tool_set))}."

        patterns: list[str] = []
        action_seq = [e.action_type for e in events]
        for win_size in range(2, 5):
            seq_counts: Counter[str] = Counter()
            for i in range(len(action_seq) - win_size + 1):
                seq = " \u2192 ".join(action_seq[i : i + win_size])
                seq_counts[seq] += 1
            for seq, count in seq_counts.items():
                if count >= 3:
                    patterns.append(f"{seq} ({count}x)")

        summary = CompiledSummary(
            agent_id=first.agent_id,
            agent_name=first.agent_name,
            period_start=first.timestamp,
            period_end=last.timestamp,
            event_count=len(events),
            tools_used=sorted(tool_set),
            action_summary=action_summary,
            risk_profile={
                "score": round(total_risk / risk_count) if risk_count else 0,
                "flags": list(set(all_flags)),
            },
            patterns=patterns,
            chain_valid=chain_valid,
            first_hash=first.event_hash,
            last_hash=last.event_hash,
        )

        return AdapterPayload(
            mode=OutputMode.COMPILED,
            data=summary,
            metadata={
                "org_id": org_id,
                "received_at": _now_iso(),
                "verified": True,
                "chain_index": event.chain_index,
            },
        )


class RankigiConnector:
    """Main connector for streaming RANKIGI governed events to any destination."""

    def __init__(self, config: ConnectorConfig) -> None:
        self._config = config
        self._stream: EventStream | None = None

        if config.mode == OutputMode.VERIFIED:
            proc = _VerifiedProcessor(config.on_error)
            self._process = proc.process
        elif config.mode == OutputMode.COMPILED:
            proc_c = _CompiledProcessor(config.buffer_size)
            self._process = proc_c.process
        else:
            self._process = _process_raw

    async def connect(self) -> None:
        """Initialize adapter and start streaming."""
        await self._config.adapter.init()

        self._stream = EventStream(
            api_key=self._config.api_key,
            org_id=self._config.org_id,
            on_envelope=self._handle_envelope,
            on_error=lambda e: (
                self._config.on_error(e) if self._config.on_error else None
            ),
            retry_attempts=self._config.retry_attempts,
        )

        await self._stream.connect()

    def _handle_envelope(self, envelope: RankigiEnvelope) -> None:
        event = envelope.event
        if self._config.on_event:
            self._config.on_event(event)

        payload = self._process(event, envelope.org_id)
        if payload:
            asyncio.get_event_loop().create_task(self._write(payload))

    async def _write(self, payload: AdapterPayload) -> None:
        try:
            await self._config.adapter.write(payload)
        except Exception as exc:
            if self._config.on_error:
                self._config.on_error(exc)

    async def disconnect(self) -> None:
        """Flush, disconnect stream, and close adapter."""
        await self._config.adapter.flush()
        if self._stream:
            await self._stream.disconnect()
        await self._config.adapter.close()

    def verify(self, events: list[RankigiEvent]) -> VerifyResult:
        """Standalone chain verification."""
        return verify_chain(events)

    async def replay(self, options: ReplayOptions) -> AsyncIterator[RankigiEvent]:
        """Fetch historical events via REST."""
        params: dict[str, str] = {}
        if options.start:
            params["start"] = options.start
        if options.end:
            params["end"] = options.end
        if options.agent_id:
            params["agent_id"] = options.agent_id

        async with aiohttp.ClientSession() as session:
            url = f"{API_BASE}/events"
            headers = {"Authorization": f"Bearer {self._config.api_key}"}
            async with session.get(
                url, params=params, headers=headers
            ) as resp:
                resp.raise_for_status()
                data = await resp.json()
                for event_data in data.get("events", []):
                    yield RankigiEvent.model_validate(event_data)

    async def get_snapshot(self, date: str) -> RankigiSnapshot:
        """Fetch a daily snapshot."""
        async with aiohttp.ClientSession() as session:
            url = f"{API_BASE}/snapshots"
            headers = {"Authorization": f"Bearer {self._config.api_key}"}
            async with session.get(
                url, params={"date": date}, headers=headers
            ) as resp:
                resp.raise_for_status()
                data = await resp.json()
                return RankigiSnapshot.model_validate(data)

    @classmethod
    def from_env(cls) -> RankigiConnector:
        """Create a connector from environment variables."""
        api_key = os.environ.get("RANKIGI_API_KEY")
        org_id = os.environ.get("RANKIGI_ORG_ID")
        if not api_key or not org_id:
            raise ValueError(
                "RANKIGI_API_KEY and RANKIGI_ORG_ID must be set"
            )

        from rankigi.adapters.base import BaseAdapter

        class _NoopAdapter(BaseAdapter):
            async def init(self) -> None:
                pass

            async def write(self, data: AdapterPayload) -> None:
                pass

            async def flush(self) -> None:
                pass

            async def close(self) -> None:
                pass

            async def health_check(self) -> bool:
                return True

        return cls(
            ConnectorConfig(
                api_key=api_key,
                org_id=org_id,
                mode=OutputMode.RAW,
                adapter=_NoopAdapter(),
            )
        )
