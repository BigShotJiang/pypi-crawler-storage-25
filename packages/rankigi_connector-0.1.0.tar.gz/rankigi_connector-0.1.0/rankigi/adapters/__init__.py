"""RANKIGI Connector adapters."""

from rankigi.adapters.base import BaseAdapter
from rankigi.adapters.obsidian import ObsidianAdapter
from rankigi.adapters.s3 import S3Adapter
from rankigi.adapters.postgres import PostgresAdapter
from rankigi.adapters.kafka import KafkaAdapter

__all__ = [
    "BaseAdapter",
    "ObsidianAdapter",
    "S3Adapter",
    "PostgresAdapter",
    "KafkaAdapter",
]
