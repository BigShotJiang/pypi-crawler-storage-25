"""PostgreSQL adapter — coming soon."""

from __future__ import annotations

from dataclasses import dataclass

from rankigi.adapters.base import BaseAdapter
from rankigi.types import AdapterPayload


@dataclass
class PostgresConfig:
    connection_string: str
    table_name: str = "rankigi_events"
    schema: str = "public"


class PostgresAdapter(BaseAdapter):
    """PostgreSQL adapter — coming soon."""

    def __init__(self, config: PostgresConfig) -> None:
        self._config = config

    async def init(self) -> None:
        raise NotImplementedError("PostgresAdapter is not yet implemented")

    async def write(self, data: AdapterPayload) -> None:
        raise NotImplementedError("PostgresAdapter is not yet implemented")

    async def flush(self) -> None:
        pass

    async def close(self) -> None:
        pass

    async def health_check(self) -> bool:
        return False
