"""Apache Kafka adapter — coming soon."""

from __future__ import annotations

from dataclasses import dataclass

from rankigi.adapters.base import BaseAdapter
from rankigi.types import AdapterPayload


@dataclass
class KafkaConfig:
    brokers: list[str]
    topic: str
    client_id: str | None = None


class KafkaAdapter(BaseAdapter):
    """Apache Kafka adapter — coming soon."""

    def __init__(self, config: KafkaConfig) -> None:
        self._config = config

    async def init(self) -> None:
        raise NotImplementedError("KafkaAdapter is not yet implemented")

    async def write(self, data: AdapterPayload) -> None:
        raise NotImplementedError("KafkaAdapter is not yet implemented")

    async def flush(self) -> None:
        pass

    async def close(self) -> None:
        pass

    async def health_check(self) -> bool:
        return False
