"""Obsidian vault adapter for RANKIGI."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from rankigi.adapters.base import BaseAdapter
from rankigi.types import AdapterPayload, CompiledSummary, OutputMode, RankigiEvent


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class ObsidianConfig:
    vault_path: str
    folder_structure: Literal["by-date", "by-agent", "by-both"] = "by-agent"
    create_index: bool = True
    create_agent_pages: bool = True


class ObsidianAdapter(BaseAdapter):
    """Stream governed events as interlinked markdown notes in an Obsidian vault."""

    def __init__(self, config: ObsidianConfig) -> None:
        self._config = config
        self._event_counts: dict[str, int] = {}
        self._recent_events: list[dict[str, str]] = []
        self._agent_meta: dict[str, dict] = {}

    async def init(self) -> None:
        vault = Path(self._config.vault_path)
        if not vault.exists():
            raise FileNotFoundError(f"Vault path does not exist: {vault}")

        (vault / "RANKIGI").mkdir(exist_ok=True)
        (vault / "agents").mkdir(exist_ok=True)

        if self._config.create_index:
            index_path = vault / "RANKIGI" / "index.md"
            if not index_path.exists():
                index_path.write_text(
                    f"# RANKIGI \u2014 Knowledge Index\nLast updated: {_now()}\n"
                )

    async def write(self, payload: AdapterPayload) -> None:
        if payload.mode == OutputMode.COMPILED:
            await self._write_compiled(payload)
        else:
            await self._write_event(payload)

        if self._config.create_index:
            await self._update_index()

    async def _write_event(self, payload: AdapterPayload) -> None:
        event: RankigiEvent = payload.data  # type: ignore[assignment]
        verified = payload.metadata.get("verified", False)

        directory = self._get_event_dir(event)
        directory.mkdir(parents=True, exist_ok=True)

        short_id = event.event_id[:8]
        filename = f"{event.chain_index}-{short_id}.md"
        filepath = directory / filename

        flags_str = (
            "\n".join(f"- {f}" for f in event.policy_flags)
            if event.policy_flags
            else "None"
        )
        prev_link = (
            f"[[{event.chain_index - 1}-{event.previous_event_hash[:8]}]] \u2190 previous event"
            if event.previous_event_hash
            else "Genesis event \u2014 no predecessor"
        )

        content = f"""---
event_id: {event.event_id}
agent: {event.agent_name}
agent_id: {event.agent_id}
timestamp: {event.timestamp}
action_type: {event.action_type}
tool: {event.tool_invoked or "null"}
chain_index: {event.chain_index}
event_hash: {event.event_hash}
previous_hash: {event.previous_event_hash or "null"}
risk_score: {event.risk_score if event.risk_score is not None else "null"}
verified: {verified}
tags: [rankigi, agent/{event.agent_name}, {event.action_type}]
---

# {event.action_type} \u2014 {event.agent_name}

**Tool:** {event.tool_invoked or "none"}
**Result:** {event.execution_result}
**Risk:** {event.risk_score if event.risk_score is not None else "N/A"}/100

## Hashes
Event: `{event.event_hash}`
Previous: `{event.previous_event_hash or "genesis"}`
Input: `{event.input_hash}`
Output: `{event.output_hash}`

## Chain Position
Index: {event.chain_index}
Verified: {verified}

## Flags
{flags_str}

## Links
{prev_link}
[[agents/{event.agent_name}]] \u2190 agent page
"""
        filepath.write_text(content)

        self._recent_events.insert(
            0,
            {
                "file": filename,
                "agent": event.agent_name,
                "action": event.action_type,
                "timestamp": event.timestamp,
            },
        )
        if len(self._recent_events) > 20:
            self._recent_events.pop()

        self._event_counts[event.agent_name] = (
            self._event_counts.get(event.agent_name, 0) + 1
        )

        if self._config.create_agent_pages:
            await self._update_agent_page(event)

    async def _write_compiled(self, payload: AdapterPayload) -> None:
        summary: CompiledSummary = payload.data  # type: ignore[assignment]
        date = summary.period_start[:10]
        directory = Path(self._config.vault_path) / "agents" / summary.agent_name
        directory.mkdir(parents=True, exist_ok=True)

        filename = f"{summary.agent_name}-{date}-summary.md"
        filepath = directory / filename

        tools_str = "\n".join(f"- {t}" for t in summary.tools_used) or "None"
        patterns_str = (
            "\n".join(f"- {p}" for p in summary.patterns) or "None detected"
        )
        flags = summary.risk_profile.get("flags", [])
        flags_str = ", ".join(flags) if flags else "None"

        content = f"""---
type: compiled-summary
agent: {summary.agent_name}
period: {summary.period_start} to {summary.period_end}
event_count: {summary.event_count}
chain_valid: {summary.chain_valid}
tags: [rankigi, summary, agent/{summary.agent_name}]
---

# {summary.agent_name} \u2014 {date} Summary

**Events:** {summary.event_count}
**Period:** {summary.period_start} \u2192 {summary.period_end}
**Chain Valid:** {"\u2713" if summary.chain_valid else "\u2717"}

## Activity
{summary.action_summary}

## Tools Used
{tools_str}

## Patterns Detected
{patterns_str}

## Risk Profile
Score: {summary.risk_profile.get("score", 0)}/100
Flags: {flags_str}

## Hash Boundaries
First: `{summary.first_hash}`
Last: `{summary.last_hash}`
"""
        filepath.write_text(content)

        meta = self._agent_meta.setdefault(
            summary.agent_name,
            {"id": summary.agent_id, "last_seen": "", "events": [], "summaries": []},
        )
        meta["summaries"].insert(0, filename)
        if len(meta["summaries"]) > 7:
            meta["summaries"].pop()
        meta["last_seen"] = summary.period_end

    async def _update_agent_page(self, event: RankigiEvent) -> None:
        agents_dir = Path(self._config.vault_path) / "agents"
        agents_dir.mkdir(exist_ok=True)

        meta = self._agent_meta.setdefault(
            event.agent_name,
            {"id": event.agent_id, "last_seen": "", "events": [], "summaries": []},
        )
        short_id = event.event_id[:8]
        meta["events"].insert(0, f"{event.chain_index}-{short_id}")
        if len(meta["events"]) > 10:
            meta["events"].pop()
        meta["last_seen"] = event.timestamp
        meta["id"] = event.agent_id

        total_events = self._event_counts.get(event.agent_name, 0)
        events_links = "\n".join(f"- [[{e}]]" for e in meta["events"])
        summaries_links = (
            "\n".join(f"- [[{s}]]" for s in meta["summaries"])
            or "No summaries yet"
        )

        content = f"""---
agent_id: {meta["id"]}
status: active
total_events: {total_events}
last_seen: {meta["last_seen"]}
tags: [rankigi, agent]
---

# {event.agent_name}

## Recent Events
{events_links}

## Summaries
{summaries_links}
"""
        (agents_dir / f"{event.agent_name}.md").write_text(content)

    async def _update_index(self) -> None:
        index_path = Path(self._config.vault_path) / "RANKIGI" / "index.md"

        agents = "\n".join(
            f"- [[agents/{name}]] \u2014 {count} events"
            for name, count in self._event_counts.items()
        ) or "No agents observed yet"

        recent = "\n".join(
            f"- [[{e['file']}]] {e['action']} by {e['agent']} ({e['timestamp']})"
            for e in self._recent_events[:20]
        ) or "No events yet"

        content = f"""# RANKIGI \u2014 Knowledge Index
Last updated: {_now()}

## Agents
{agents}

## Recent Activity
{recent}
"""
        index_path.write_text(content)

    def _get_event_dir(self, event: RankigiEvent) -> Path:
        vault = Path(self._config.vault_path)
        date = event.timestamp[:10]
        if self._config.folder_structure == "by-date":
            return vault / "RANKIGI" / date / "events"
        elif self._config.folder_structure == "by-agent":
            return vault / "agents" / event.agent_name / "events"
        else:  # by-both
            return vault / "agents" / event.agent_name / date

    async def flush(self) -> None:
        pass

    async def close(self) -> None:
        pass

    async def health_check(self) -> bool:
        return Path(self._config.vault_path).exists()
