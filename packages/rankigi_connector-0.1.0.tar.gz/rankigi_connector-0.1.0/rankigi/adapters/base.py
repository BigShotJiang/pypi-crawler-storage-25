"""Abstract base adapter for RANKIGI connectors."""

from __future__ import annotations

from abc import ABC, abstractmethod

from rankigi.types import AdapterPayload


class BaseAdapter(ABC):
    """Base class for all RANKIGI adapters."""

    @abstractmethod
    async def init(self) -> None:
        """Initialize the adapter (verify connectivity, create structures)."""

    @abstractmethod
    async def write(self, data: AdapterPayload) -> None:
        """Write a payload to the destination."""

    @abstractmethod
    async def flush(self) -> None:
        """Flush any buffered data."""

    @abstractmethod
    async def close(self) -> None:
        """Close connections and clean up resources."""

    @abstractmethod
    async def health_check(self) -> bool:
        """Check if the destination is reachable."""
