"""Amazon S3 adapter for RANKIGI."""

from __future__ import annotations

import gzip
import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Literal

import boto3

from rankigi.adapters.base import BaseAdapter
from rankigi.types import AdapterPayload, RankigiEvent


@dataclass
class S3Config:
    bucket: str
    region: str
    prefix: str = "rankigi/"
    credentials: dict[str, str] | Literal["env"] = "env"
    format: Literal["json", "ndjson", "parquet-ready"] = "json"
    compression: bool = False
    batch_size: int = 100
    partition_by: Literal["hour", "day", "agent"] = "day"


class S3Adapter(BaseAdapter):
    """Write governed events to Amazon S3 with automatic partitioning."""

    def __init__(self, config: S3Config) -> None:
        self._config = config
        self._buffer: list[AdapterPayload] = []
        self._manifests: dict[str, list[dict]] = {}

        kwargs: dict = {"region_name": config.region}
        if isinstance(config.credentials, dict):
            kwargs["aws_access_key_id"] = config.credentials["accessKeyId"]
            kwargs["aws_secret_access_key"] = config.credentials[
                "secretAccessKey"
            ]
        self._client = boto3.client("s3", **kwargs)

    async def init(self) -> None:
        self._client.head_bucket(Bucket=self._config.bucket)

    async def write(self, data: AdapterPayload) -> None:
        self._buffer.append(data)
        if len(self._buffer) >= self._config.batch_size:
            await self.flush()

    async def flush(self) -> None:
        if not self._buffer:
            return

        batch = list(self._buffer)
        self._buffer.clear()

        now = datetime.now(timezone.utc)
        partition = self._get_partition(now, batch[0])
        ext = (
            "ndjson"
            if self._config.format in ("ndjson", "parquet-ready")
            else "json"
        )
        short_uuid = uuid.uuid4().hex[:8]
        key = (
            f"{self._config.prefix}{partition}"
            f"{now.isoformat().replace(':', '-').replace('.', '-')}"
            f"-{short_uuid}.{ext}"
        )

        events = [p.data for p in batch]

        if self._config.format in ("ndjson", "parquet-ready"):
            body_str = (
                "\n".join(
                    e.model_dump_json()
                    if hasattr(e, "model_dump_json")
                    else json.dumps(e)
                    for e in events
                )
                + "\n"
            )
        else:
            body_str = json.dumps(
                {
                    "rankigi_version": "1.0",
                    "exported_at": now.isoformat(),
                    "org_id": batch[0].metadata.get("org_id", ""),
                    "event_count": len(events),
                    "chain_valid": True,
                    "events": [
                        e.model_dump() if hasattr(e, "model_dump") else e
                        for e in events
                    ],
                }
            )

        content_type = (
            "application/x-ndjson"
            if self._config.format in ("ndjson", "parquet-ready")
            else "application/json"
        )

        put_kwargs: dict = {
            "Bucket": self._config.bucket,
            "Key": key,
            "ContentType": content_type,
        }

        if self._config.compression:
            put_kwargs["Body"] = gzip.compress(body_str.encode())
            put_kwargs["ContentEncoding"] = "gzip"
        else:
            put_kwargs["Body"] = body_str.encode()

        self._client.put_object(**put_kwargs)

        # Track manifest
        date_key = now.strftime("%Y-%m-%d")
        manifest_entries = self._manifests.setdefault(date_key, [])

        first_event = events[0]
        last_event = events[-1]
        first_hash = (
            first_event.event_hash
            if isinstance(first_event, RankigiEvent)
            else ""
        )
        last_hash = (
            last_event.event_hash
            if isinstance(last_event, RankigiEvent)
            else ""
        )

        manifest_entries.append(
            {
                "key": key,
                "count": len(events),
                "first_hash": first_hash,
                "last_hash": last_hash,
            }
        )

        manifest_key = f"{self._config.prefix}manifests/{date_key}.json"
        self._client.put_object(
            Bucket=self._config.bucket,
            Key=manifest_key,
            Body=json.dumps(
                {"date": date_key, "files": manifest_entries}
            ).encode(),
            ContentType="application/json",
        )

        if self._config.format == "parquet-ready":
            meta_key = f"{self._config.prefix}{partition}_metadata.json"
            self._client.put_object(
                Bucket=self._config.bucket,
                Key=meta_key,
                Body=json.dumps(
                    {
                        "columns": {
                            "event_id": "string",
                            "agent_id": "string",
                            "agent_name": "string",
                            "timestamp": "timestamp",
                            "action_type": "string",
                            "tool_invoked": "string",
                            "input_hash": "string",
                            "output_hash": "string",
                            "event_hash": "string",
                            "previous_event_hash": "string",
                            "chain_index": "bigint",
                            "execution_result": "string",
                            "risk_score": "double",
                            "policy_flags": "array<string>",
                            "data_quality_flag": "string",
                        }
                    }
                ).encode(),
                ContentType="application/json",
            )

    def _get_partition(self, now: datetime, sample: AdapterPayload) -> str:
        y = now.strftime("%Y")
        m = now.strftime("%m")
        d = now.strftime("%d")
        h = now.strftime("%H")

        if self._config.partition_by == "hour":
            return f"{y}/{m}/{d}/{h}/"
        elif self._config.partition_by == "agent":
            event = sample.data
            agent_id = (
                event.agent_id
                if isinstance(event, RankigiEvent)
                else "unknown"
            )
            return f"agents/{agent_id}/{y}/{m}/{d}/"
        else:
            return f"{y}/{m}/{d}/"

    async def close(self) -> None:
        await self.flush()

    async def health_check(self) -> bool:
        try:
            self._client.head_bucket(Bucket=self._config.bucket)
            return True
        except Exception:
            return False
