"""WebSocket event stream for RANKIGI."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Callable

import websockets
from websockets.asyncio.client import connect

from rankigi.types import RankigiEnvelope
from rankigi.verifier import verify_signature

logger = logging.getLogger(__name__)


class EventStream:
    """Manages a WebSocket connection to the RANKIGI event stream."""

    def __init__(
        self,
        api_key: str,
        org_id: str,
        on_envelope: Callable[[RankigiEnvelope], None],
        on_error: Callable[[Exception], None],
        retry_attempts: int = 3,
    ) -> None:
        self._api_key = api_key
        self._org_id = org_id
        self._on_envelope = on_envelope
        self._on_error = on_error
        self._retry_attempts = retry_attempts
        self._closed = False
        self._task: asyncio.Task[None] | None = None

    async def connect(self) -> None:
        """Open the WebSocket connection and start listening."""
        url = f"wss://rankigi.com/api/v1/stream?channel=org-stream-{self._org_id}"
        headers = {"Authorization": f"Bearer {self._api_key}"}

        retry_count = 0
        while True:
            try:
                self._ws = await connect(url, additional_headers=headers)
                self._task = asyncio.create_task(self._listen())
                return
            except Exception as exc:
                if retry_count >= self._retry_attempts:
                    raise
                retry_count += 1
                delay = min(2**retry_count, 30)
                logger.warning(
                    "Connection failed, retrying in %ds: %s", delay, exc
                )
                await asyncio.sleep(delay)

    async def _listen(self) -> None:
        """Listen for messages on the WebSocket."""
        try:
            async for message in self._ws:
                if self._closed:
                    break
                try:
                    data = json.loads(message)
                    envelope = RankigiEnvelope.model_validate(data)

                    payload_str = envelope.event.model_dump_json()
                    if not verify_signature(
                        payload_str,
                        envelope.rankigi_signature,
                        self._api_key,
                    ):
                        self._on_error(
                            ValueError(
                                f"Invalid signature on envelope {envelope.envelope_id}"
                            )
                        )
                        continue

                    self._on_envelope(envelope)
                except Exception as exc:
                    self._on_error(exc)
        except websockets.ConnectionClosed:
            if not self._closed:
                await self._reconnect()

    async def _reconnect(self) -> None:
        """Attempt to reconnect with exponential backoff."""
        for attempt in range(1, self._retry_attempts + 1):
            if self._closed:
                return
            delay = min(2**attempt, 30)
            await asyncio.sleep(delay)
            try:
                await self.connect()
                return
            except Exception:
                logger.warning("Reconnect attempt %d failed", attempt)

    async def disconnect(self) -> None:
        """Gracefully close the WebSocket connection."""
        self._closed = True
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        if hasattr(self, "_ws") and self._ws:
            await self._ws.close()
