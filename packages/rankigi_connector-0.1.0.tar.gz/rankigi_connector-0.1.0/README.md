# rankigi-connector

Universal connector for RANKIGI governed event streams. Stream verified hash-chain events into any destination.

## Install

```bash
pip install rankigi-connector
```

## Quick Start

```python
import asyncio
import os
from rankigi import RankigiConnector, ConnectorConfig, OutputMode
from rankigi.adapters.obsidian import ObsidianAdapter, ObsidianConfig

connector = RankigiConnector(
    ConnectorConfig(
        api_key=os.environ["RANKIGI_API_KEY"],
        org_id=os.environ["RANKIGI_ORG_ID"],
        mode=OutputMode.COMPILED,
        adapter=ObsidianAdapter(
            ObsidianConfig(
                vault_path="/path/to/vault",
                folder_structure="by-agent",
                create_index=True,
                create_agent_pages=True,
            )
        ),
    )
)

asyncio.run(connector.connect())
```

## Output Modes

- **raw** — Pure event data, no transformation
- **verified** — Chain integrity checked before every write
- **compiled** — Human-readable summaries with pattern detection

## Adapters

- `ObsidianAdapter` — Markdown notes in your Obsidian vault
- `S3Adapter` — S3 with partitioning, ndjson/json/parquet-ready
- `PostgresAdapter` — Coming soon
- `KafkaAdapter` — Coming soon
- `BaseAdapter` — Extend to build your own
