"""Tenant scoping must fail closed.

Tests the critical invariant: queries against TenantMixin entities without an
active TenantContext return zero rows. Cross-tenant reads require explicit
bypass.
"""

import uuid

import pytest
from sqlalchemy import String, delete, select, update
from sqlalchemy.orm import Mapped, mapped_column

from kestrel_feature_entities import EntityBase, TenantMixin, TenantContext, UUIDPrimaryKey
from kestrel_feature_entities.identifiers import uuid7


class _Tenant(EntityBase):
    __tablename__ = "tenants"
    id: Mapped[UUIDPrimaryKey]
    name: Mapped[str] = mapped_column(String(64))


class _Widget(EntityBase, TenantMixin):
    __tablename__ = "widgets"
    id: Mapped[UUIDPrimaryKey]
    label: Mapped[str] = mapped_column(String(64))


@pytest.mark.asyncio
async def test_no_tenant_returns_no_rows(factory):
    t1 = uuid7()
    async with factory.write_session() as s:
        s.add(_Tenant(id=t1, name="tenant-a"))
        s.add(_Widget(tenant_id=t1, label="w1"))

    async with factory.read_session() as s:
        rows = (await s.execute(select(_Widget))).scalars().all()
    assert rows == []


@pytest.mark.asyncio
async def test_active_tenant_scopes_query(factory):
    t1, t2 = uuid7(), uuid7()
    async with factory.write_session() as s:
        s.add_all([_Tenant(id=t1, name="a"), _Tenant(id=t2, name="b")])
        s.add(_Widget(tenant_id=t1, label="w-a"))
        s.add(_Widget(tenant_id=t2, label="w-b"))

    with TenantContext.use(t1):
        async with factory.read_session() as s:
            rows = (await s.execute(select(_Widget))).scalars().all()
        assert {r.label for r in rows} == {"w-a"}


@pytest.mark.asyncio
async def test_bypass_returns_all_tenants(factory):
    t1, t2 = uuid7(), uuid7()
    async with factory.write_session() as s:
        s.add_all([_Tenant(id=t1, name="a"), _Tenant(id=t2, name="b")])
        s.add(_Widget(tenant_id=t1, label="w-a"))
        s.add(_Widget(tenant_id=t2, label="w-b"))

    with TenantContext.bypass():
        async with factory.read_session() as s:
            rows = (await s.execute(select(_Widget))).scalars().all()
        assert {r.label for r in rows} == {"w-a", "w-b"}


# --- Bulk DML must respect the same fail-closed contract as SELECT.
# Regression for codex PR #1 round 2 finding: do_orm_execute previously
# early-returned for is_update / is_delete, so cross-tenant bulk writes
# leaked through.


async def _seed_two_tenants(factory):
    t1, t2 = uuid7(), uuid7()
    with TenantContext.bypass():
        async with factory.write_session() as s:
            s.add_all([_Tenant(id=t1, name="a"), _Tenant(id=t2, name="b")])
            s.add_all([
                _Widget(tenant_id=t1, label="w-a"),
                _Widget(tenant_id=t2, label="w-b"),
            ])
    return t1, t2


@pytest.mark.asyncio
async def test_bulk_delete_without_context_affects_no_rows(factory):
    t1, t2 = await _seed_two_tenants(factory)
    async with factory.write_session() as s:
        result = await s.execute(delete(_Widget))
    assert result.rowcount == 0

    with TenantContext.bypass():
        async with factory.read_session() as s:
            remaining = (await s.execute(select(_Widget))).scalars().all()
    assert {r.label for r in remaining} == {"w-a", "w-b"}


@pytest.mark.asyncio
async def test_bulk_delete_with_context_scopes_to_tenant(factory):
    t1, t2 = await _seed_two_tenants(factory)
    with TenantContext.use(t1):
        async with factory.write_session() as s:
            result = await s.execute(delete(_Widget))
        assert result.rowcount == 1

    with TenantContext.bypass():
        async with factory.read_session() as s:
            remaining = (await s.execute(select(_Widget))).scalars().all()
    assert {r.label for r in remaining} == {"w-b"}


@pytest.mark.asyncio
async def test_bulk_update_without_context_affects_no_rows(factory):
    t1, t2 = await _seed_two_tenants(factory)
    async with factory.write_session() as s:
        result = await s.execute(update(_Widget).values(label="REWRITTEN"))
    assert result.rowcount == 0

    with TenantContext.bypass():
        async with factory.read_session() as s:
            remaining = (await s.execute(select(_Widget))).scalars().all()
    assert {r.label for r in remaining} == {"w-a", "w-b"}


@pytest.mark.asyncio
async def test_bulk_update_with_context_scopes_to_tenant(factory):
    t1, t2 = await _seed_two_tenants(factory)
    with TenantContext.use(t1):
        async with factory.write_session() as s:
            result = await s.execute(update(_Widget).values(label="REWRITTEN"))
        assert result.rowcount == 1

    with TenantContext.bypass():
        async with factory.read_session() as s:
            remaining = (await s.execute(select(_Widget))).scalars().all()
    assert {r.label for r in remaining} == {"REWRITTEN", "w-b"}


@pytest.mark.asyncio
async def test_bulk_delete_under_bypass_affects_all_tenants(factory):
    await _seed_two_tenants(factory)
    with TenantContext.bypass():
        async with factory.write_session() as s:
            result = await s.execute(delete(_Widget))
        assert result.rowcount == 2

        async with factory.read_session() as s:
            remaining = (await s.execute(select(_Widget))).scalars().all()
    assert remaining == []
