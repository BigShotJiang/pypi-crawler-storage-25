"""EntitiesFeature regressions.

Covers codex PR #1 review findings:
  - Round 1: privacy_mode from another Kestrel package arrives as a foreign
    enum whose `.value` is the canonical string. Pre-coercing with
    `PrivacyMode(value)` raises ValueError; we must unwrap `.value` first.
  - Round 3: EntitiesFeature must release the async engine and ISOLATED
    tempfile in shutdown(); without an override the resources leak on
    every normal agent shutdown.
"""

import os
from enum import Enum
from types import SimpleNamespace

import pytest
from kestrel_sdk.storage.database import PrivacyMode

from kestrel_feature_entities.feature import EntitiesFeature
from kestrel_feature_entities.session import (
    get_session_factory,
    reset_session_factory,
)


def _bare_feature(agent) -> EntitiesFeature:
    """Construct without invoking Feature.__init__ — we only exercise resolver methods."""
    f = object.__new__(EntitiesFeature)
    f.agent = agent
    return f


def test_resolve_handles_native_privacy_mode():
    f = _bare_feature(SimpleNamespace(privacy_mode=PrivacyMode.ISOLATED))
    assert f._resolve_privacy_mode() is PrivacyMode.ISOLATED


def test_resolve_handles_foreign_enum_with_matching_value():
    class _OtherPrivacy(Enum):
        NORMAL = "normal"

    f = _bare_feature(SimpleNamespace(privacy_mode=_OtherPrivacy.NORMAL))
    assert f._resolve_privacy_mode() is PrivacyMode.NORMAL


def test_resolve_handles_raw_string():
    f = _bare_feature(SimpleNamespace(privacy_mode="ephemeral"))
    assert f._resolve_privacy_mode() is PrivacyMode.EPHEMERAL


def test_resolve_defaults_to_normal_when_unset():
    f = _bare_feature(SimpleNamespace())
    assert f._resolve_privacy_mode() is PrivacyMode.NORMAL


def test_resolve_defaults_to_normal_when_none():
    f = _bare_feature(SimpleNamespace(privacy_mode=None))
    assert f._resolve_privacy_mode() is PrivacyMode.NORMAL


@pytest.mark.asyncio
async def test_shutdown_disposes_factory_and_removes_isolated_tempfile():
    """Feature shutdown must release the engine and unlink ISOLATED tempfile."""
    reset_session_factory()
    factory = get_session_factory(mode=PrivacyMode.ISOLATED, fallback_url="")
    cleanup_path = factory.target.cleanup_path
    assert cleanup_path is not None
    open(cleanup_path, "a").close()
    assert os.path.exists(cleanup_path)

    f = _bare_feature(SimpleNamespace())
    await f.shutdown()

    assert not os.path.exists(cleanup_path), (
        f"shutdown() must dispose the factory and unlink {cleanup_path}"
    )
    # Subsequent get_session_factory() should rebuild a fresh factory.
    assert get_session_factory(mode=PrivacyMode.EPHEMERAL, fallback_url="") is not factory
    reset_session_factory()


@pytest.mark.asyncio
async def test_shutdown_is_safe_when_factory_never_initialized():
    """Calling shutdown() before any session activity must not raise."""
    reset_session_factory()
    f = _bare_feature(SimpleNamespace())
    await f.shutdown()  # must not raise
