"""UUIDv7 sanity checks.

Two properties matter:
  1. Version 7 (top nibble of byte 6 == 0x7).
  2. Time-ordered: earlier-generated UUIDs sort before later ones.
"""

import time

from kestrel_feature_entities.identifiers import uuid7


def test_version_is_7():
    u = uuid7()
    assert u.version == 7


def test_time_ordered():
    first = uuid7()
    time.sleep(0.002)
    second = uuid7()
    assert first.bytes < second.bytes


def test_unique():
    seen = {uuid7() for _ in range(1000)}
    assert len(seen) == 1000
