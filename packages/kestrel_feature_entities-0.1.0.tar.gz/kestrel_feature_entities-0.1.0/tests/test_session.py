"""Session factory regressions.

Covers codex PR #1 review findings:
  - Round 1: ISOLATED tempfile must be removed on factory dispose()
  - Round 4: get_session_factory() must fail fast on privacy-mode mismatch
    instead of silently returning a factory built for a different mode.
"""

import os

import pytest
from kestrel_sdk.storage.database import PrivacyMode

from kestrel_feature_entities.session import (
    SessionFactory,
    dispose_session_factory,
    get_session_factory,
    reset_session_factory,
)


@pytest.mark.asyncio
async def test_isolated_tempfile_removed_on_dispose():
    reset_session_factory()
    factory = get_session_factory(mode=PrivacyMode.ISOLATED, fallback_url="")
    target = factory.target

    assert target.cleanup_path is not None, "ISOLATED should materialise a tempfile"
    # Touch the file so we can assert dispose actually removes it.
    open(target.cleanup_path, "a").close()
    assert os.path.exists(target.cleanup_path)

    await factory.dispose()
    reset_session_factory()

    assert not os.path.exists(target.cleanup_path), (
        f"dispose() must unlink ISOLATED-mode tempfile, but {target.cleanup_path} remains"
    )


@pytest.mark.asyncio
async def test_dispose_is_idempotent_for_non_owning_targets():
    """Ephemeral (in-memory) targets have no cleanup_path; dispose must not fail."""
    reset_session_factory()
    factory = get_session_factory(mode=PrivacyMode.EPHEMERAL, fallback_url="")
    assert factory.target.cleanup_path is None

    await factory.dispose()  # must not raise
    reset_session_factory()


@pytest.mark.asyncio
async def test_mismatched_mode_raises_instead_of_silent_reuse():
    """If a consumer first initializes NORMAL, a later EPHEMERAL request must
    not silently get persistent storage. The privacy-mode routing contract
    is fail-fast on mismatch."""
    reset_session_factory()
    first = get_session_factory(mode=PrivacyMode.NORMAL, fallback_url="sqlite+aiosqlite:///:memory:")
    assert first.mode is PrivacyMode.NORMAL

    with pytest.raises(RuntimeError, match="already initialized with privacy mode"):
        get_session_factory(mode=PrivacyMode.EPHEMERAL, fallback_url="")

    await dispose_session_factory()
    reset_session_factory()


@pytest.mark.asyncio
async def test_same_mode_returns_cached_factory():
    """Repeated calls with the same mode are a no-op, not an error."""
    reset_session_factory()
    first = get_session_factory(mode=PrivacyMode.EPHEMERAL, fallback_url="")
    second = get_session_factory(mode=PrivacyMode.EPHEMERAL, fallback_url="")
    assert first is second

    await dispose_session_factory()
    reset_session_factory()


@pytest.mark.asyncio
async def test_dispose_then_request_different_mode_succeeds():
    """After explicit disposal, a fresh mode is honored."""
    reset_session_factory()
    first = get_session_factory(mode=PrivacyMode.NORMAL, fallback_url="sqlite+aiosqlite:///:memory:")
    assert first.mode is PrivacyMode.NORMAL

    await dispose_session_factory()

    second = get_session_factory(mode=PrivacyMode.EPHEMERAL, fallback_url="")
    assert second.mode is PrivacyMode.EPHEMERAL
    assert second is not first

    await dispose_session_factory()
    reset_session_factory()
