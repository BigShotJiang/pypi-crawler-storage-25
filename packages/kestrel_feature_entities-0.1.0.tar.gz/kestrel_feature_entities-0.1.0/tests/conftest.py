"""Test fixtures.

All tests run against in-memory SQLite. Each test gets a fresh schema and
a fresh session factory so tenant-scoping state doesn't bleed between tests.
"""

import pytest_asyncio
from kestrel_sdk.storage.database import PrivacyMode

from kestrel_feature_entities.base import EntityBase
from kestrel_feature_entities.session import (
    SessionFactory,
    get_session_factory,
    reset_session_factory,
)


@pytest_asyncio.fixture
async def factory() -> SessionFactory:
    reset_session_factory()
    f = get_session_factory(mode=PrivacyMode.EPHEMERAL, fallback_url="")
    async with f.engine.begin() as conn:
        await conn.run_sync(EntityBase.metadata.create_all)
    yield f
    await f.dispose()
    reset_session_factory()
