# kestrel-feature-entities

Declarative entity / ORM layer for the Kestrel ecosystem. SQLAlchemy 2.0
async + Alembic, with tenant scoping and privacy-mode integration baked in.

This is the layer that lets `kestrel-castle` and other Kestrel packages
define and persist domain objects without hand-rolling raw SQL.

## What you get

```python
from kestrel_feature_entities import (
    EntityBase, AuditMixin, SoftDeleteMixin, TenantMixin,
    UUIDPrimaryKey, TenantContext, get_session_factory,
)
from sqlalchemy.orm import Mapped, mapped_column

class Tenant(EntityBase, AuditMixin):
    __tablename__ = "tenants"
    id: Mapped[UUIDPrimaryKey]
    name: Mapped[str] = mapped_column(unique=True)

class Falconer(EntityBase, TenantMixin, AuditMixin, SoftDeleteMixin):
    __tablename__ = "falconers"
    id: Mapped[UUIDPrimaryKey]
    role: Mapped[str]   # beastmaster | master | lead | falconer
```

```python
factory = get_session_factory()

with TenantContext.use(active_tenant_id):
    async with factory.read_session() as s:
        falconers = (await s.execute(select(Falconer))).scalars().all()
```

## Design invariants

- **Fail closed on tenancy.** Queries against `TenantMixin` entities with no
  active `TenantContext` return zero rows, not all rows. Cross-tenant reads
  require explicit `TenantContext.bypass()`.
- **Privacy modes pick the engine.** `EPHEMERAL` → in-memory SQLite,
  `ISOLATED` → tempfile, `NORMAL`/`ANONYMOUS`/`PUBLIC` → configured backend.
  Sessions cannot be created bypassing this.
- **UUIDv7 primary keys.** Time-ordered for btree locality, distributed-safe.
- **Multi-head Alembic.** Each consumer registers its own migration directory.
- **Read/write session split.** Cosmetic in v0; routing replicas later requires
  the distinction now.

## Consumer wiring

In your `pyproject.toml`:

```toml
dependencies = ["kestrel-feature-entities @ git+..."]

[project.entry-points."kestrel_entities.models"]
your_pkg = "your_pkg.entities"
```

Then run migrations:

```bash
kestrel-entities revision --autogenerate -m "initial schema"
kestrel-entities upgrade head
```

## Status

v0 — framework only. The package registers as a Kestrel feature
(`EntitiesFeature`) but does not yet expose `@tool` methods for dynamic
agent-driven schema management. That's a deliberate v1 chapter that
needs its own design pass (type inference, conflict resolution, migration
semantics, destructive-op gating, rollback) — see the v1 issue on this
repo.

Greenfield consumers only. Sovereign's existing raw-SQL stores
(conversation, graph, RAG, saved_items, files) are unchanged. Migration of
those to entities is a separate, deferred project.

Privacy-mode resolution and the `DatabaseBackend` protocol come from
`kestrel-sovereign-sdk>=0.10.0` (see [kestrel-sovereign#1094](https://github.com/KestrelSovereignAI/kestrel-sovereign/issues/1094)).
