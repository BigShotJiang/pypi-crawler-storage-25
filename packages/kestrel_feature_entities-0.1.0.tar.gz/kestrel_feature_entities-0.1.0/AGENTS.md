# kestrel-feature-entities — Agent Instructions

> See [/Volumes/data2/projects/AGENTS.md](../AGENTS.md) for the Tortoise Philosophy and global standards.

## Package Structure

```
kestrel-feature-entities/
├── pyproject.toml
├── README.md
├── kestrel_feature_entities/
│   ├── __init__.py        # public surface
│   ├── feature.py         # EntitiesFeature (kestrel_sovereign.features entry point)
│   ├── base.py            # EntityBase + naming convention
│   ├── identifiers.py     # uuid7() + UUIDPrimaryKey
│   ├── mixins.py          # Audit / SoftDelete / Tenant / Timestamp
│   ├── tenancy.py         # TenantContext + with_loader_criteria filter
│   ├── session.py         # SessionFactory (read/write split)
│   ├── registry.py        # entry-point discovery of consumer entity modules
│   ├── cli.py             # `kestrel-entities` Alembic wrapper
│   └── alembic/
│       ├── env.py         # multi-head env
│       └── script.py.mako
└── tests/
```

## Entry Points

- `kestrel_sovereign.features`: `EntitiesFeature = "kestrel_feature_entities.feature:EntitiesFeature"`
- `kestrel_entities.models` (consumed): consumers register their entity modules here
- `kestrel_entities.migrations` (consumed): consumers register migration dirs here

## Key Files to Read First

1. `kestrel_feature_entities/base.py` — DeclarativeBase + naming convention
2. `kestrel_feature_entities/tenancy.py` — fail-closed tenant scoping
3. `kestrel_feature_entities/session.py` — engine setup + tenant filter installation
4. `kestrel_feature_entities/feature.py` — agent lifecycle integration

## Running Tests

```bash
uv run pytest
```

## Agent-Specific Instructions

- **Tenant scoping is fail-closed by design.** Do NOT add convenience escape
  hatches. If a query needs cross-tenant reads, the consumer uses
  `TenantContext.bypass()` explicitly.
- **Do not duplicate connection management.** Sessions are built via
  `get_session_factory()`. Do not allow consumers to construct their own
  engines that bypass privacy-mode resolution.
- **Multi-head Alembic is non-negotiable.** Do not collapse to a linear
  history. Each consumer must own its own revision lineage and merge heads
  on conflicts.
- **No HTTP/CRUD endpoints in this package.** Consumers (Castle, etc.) own
  their own API surface.
