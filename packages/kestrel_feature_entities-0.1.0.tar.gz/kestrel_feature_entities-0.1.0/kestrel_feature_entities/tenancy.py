"""Tenant scoping.

A `TenantContext` contextvar holds the active tenant for the current task. The
session installs a `with_loader_criteria` filter on every query against any
entity that includes `TenantMixin`, scoping it to the active tenant.

Critical invariant: if no tenant is set, queries against tenant-scoped entities
return no rows. Cross-tenant access requires explicit `TenantContext.bypass()`
and should only be used by privileged operations (admin, migrations).
"""

import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Iterator, Optional

from sqlalchemy import select
from sqlalchemy.orm import with_loader_criteria

from .mixins import TenantMixin

_active: ContextVar[Optional[uuid.UUID]] = ContextVar("kestrel_active_tenant", default=None)
_bypass: ContextVar[bool] = ContextVar("kestrel_tenant_bypass", default=False)

# Sentinel used to fail closed: matches no real tenant (UUIDv7 will never be 0).
_NIL_TENANT = uuid.UUID(int=0)


class TenantContext:
    @staticmethod
    def get() -> Optional[uuid.UUID]:
        return _active.get()

    @staticmethod
    @contextmanager
    def use(tenant_id: uuid.UUID) -> Iterator[None]:
        token = _active.set(tenant_id)
        try:
            yield
        finally:
            _active.reset(token)

    @staticmethod
    @contextmanager
    def bypass() -> Iterator[None]:
        """Cross-tenant access. Use sparingly: admin tooling, migrations."""
        token = _bypass.set(True)
        try:
            yield
        finally:
            _bypass.reset(token)


def tenant_filter():
    """Loader criteria that scopes any TenantMixin query to the active tenant.

    Install on a session via `session.execute(stmt, execution_options={
    "populate_existing": True})` after applying — but in practice this is
    attached at session-construction time in `session.py`.
    """
    if _bypass.get():
        return with_loader_criteria(TenantMixin, lambda cls: True, include_aliases=True)

    tenant_id = _active.get() or _NIL_TENANT
    return with_loader_criteria(
        TenantMixin,
        lambda cls: cls.tenant_id == tenant_id,
        include_aliases=True,
    )
