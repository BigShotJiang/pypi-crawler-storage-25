"""Reusable column mixins.

Each mixin is independent — combine as needed. Order in the class definition
follows MRO; keep audit columns rightmost so they don't reorder primary-key
declarations from `UUIDPrimaryKey`.

    class Tenant(EntityBase, AuditMixin):
        id: Mapped[UUIDPrimaryKey]
        name: Mapped[str]

    class Falconer(EntityBase, TenantMixin, AuditMixin, SoftDeleteMixin):
        id: Mapped[UUIDPrimaryKey]
        ...
"""

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import DateTime, ForeignKey, String, Uuid
from sqlalchemy.orm import Mapped, mapped_column


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
    )


class AuditMixin(TimestampMixin):
    created_by: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    updated_by: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)


class SoftDeleteMixin:
    deleted_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True, index=True
    )

    @property
    def is_deleted(self) -> bool:
        return self.deleted_at is not None


class TenantMixin:
    """Marks an entity as tenant-scoped.

    Auto-filtered by `TenantContext` at the session layer (see `tenancy.py`).
    Forgetting tenant scope returns no rows rather than leaking — fail closed.
    """

    tenant_id: Mapped[uuid.UUID] = mapped_column(
        Uuid,
        ForeignKey("tenants.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
