"""Async session factory.

Wraps a SQLAlchemy `AsyncEngine` chosen by privacy mode. Two factories are
exposed: `read_session()` and `write_session()`. They share an engine in v0;
the read/write split exists so consumers can write `async with read_session()`
today and have read replicas routed transparently later.

Tenant filtering is installed via a `do_orm_execute` event so every
SELECT against `TenantMixin` entities is scoped to the active tenant.
"""

from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional

from kestrel_sdk.storage.database import EngineTarget, PrivacyMode, resolve_engine_target
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy import event
from sqlalchemy.orm import Session

from .tenancy import tenant_filter

_TENANT_FILTER_INSTALLED = False


class SessionFactory:
    def __init__(self, target: EngineTarget, mode: PrivacyMode):
        self._target = target
        self._mode = mode
        self._engine: AsyncEngine = create_async_engine(
            target.url,
            echo=False,
            future=True,
            pool_pre_ping=True,
        )
        self._sessionmaker = async_sessionmaker(
            self._engine,
            expire_on_commit=False,
            class_=AsyncSession,
        )
        _install_tenant_filter()

    @property
    def target(self) -> EngineTarget:
        return self._target

    @property
    def mode(self) -> PrivacyMode:
        return self._mode

    @property
    def engine(self) -> AsyncEngine:
        return self._engine

    @asynccontextmanager
    async def read_session(self) -> AsyncIterator[AsyncSession]:
        async with self._sessionmaker() as session:
            yield session

    @asynccontextmanager
    async def write_session(self) -> AsyncIterator[AsyncSession]:
        async with self._sessionmaker() as session:
            async with session.begin():
                yield session

    async def dispose(self) -> None:
        await self._engine.dispose()
        self._target.cleanup()


def _install_tenant_filter() -> None:
    """Attach the tenant scoping filter to the global Session class.

    Idempotent — safe to call multiple times across factory rebuilds in tests.
    The filter is a no-op for entities without TenantMixin, so registering
    globally is fine.
    """
    global _TENANT_FILTER_INSTALLED
    if _TENANT_FILTER_INSTALLED:
        return

    @event.listens_for(Session, "do_orm_execute")
    def _apply(execute_state):
        # Scope SELECTs, ORM bulk UPDATEs, and ORM bulk DELETEs alike —
        # without UPDATE/DELETE the fail-closed tenancy contract is a lie
        # for writes (a bulk `session.execute(delete(Widget))` would otherwise
        # affect every tenant's rows). with_loader_criteria covers all three
        # statement kinds; non-tenant entities are unaffected.
        if not (
            execute_state.is_select
            or execute_state.is_update
            or execute_state.is_delete
        ):
            return
        execute_state.statement = execute_state.statement.options(tenant_filter())

    _TENANT_FILTER_INSTALLED = True


_factory: Optional[SessionFactory] = None


def get_session_factory(
    mode: PrivacyMode = PrivacyMode.NORMAL,
    fallback_url: str = "sqlite+aiosqlite:///kestrel_entities.db",
) -> SessionFactory:
    """Process-wide session factory. Initialized on first call.

    Consumers (Castle, etc.) should call this once at startup. The
    `EntitiesFeature` calls it during feature initialization with the
    privacy mode resolved from the active agent context.

    Fails fast on privacy-mode mismatch — if the factory was initialized
    with one mode and a later call requests a different mode, the contract
    is being violated (e.g. import-order race where defaults built a
    persistent NORMAL factory before the EPHEMERAL agent context resolved).
    Call `dispose_session_factory()` first to rebuild for a different mode.
    """
    global _factory
    if _factory is None:
        target = resolve_engine_target(mode, fallback_url)
        _factory = SessionFactory(target, mode)
        return _factory
    if _factory.mode != mode:
        raise RuntimeError(
            f"Session factory already initialized with privacy mode "
            f"{_factory.mode.value!r}; refusing to return it for "
            f"{mode.value!r}. The privacy-mode routing contract would "
            f"be violated by silent reuse. Call dispose_session_factory() "
            f"first if a rebuild is intended."
        )
    return _factory


def reset_session_factory() -> None:
    """Test-only: drop the cached factory. Production code should not call this."""
    global _factory
    _factory = None


async def dispose_session_factory() -> None:
    """Dispose and clear the process-wide factory.

    Called from `EntitiesFeature.shutdown()` so the async engine is released
    and any ISOLATED-mode tempfile is removed. Safe to call when no factory
    exists yet (no-op).
    """
    global _factory
    if _factory is not None:
        await _factory.dispose()
        _factory = None
