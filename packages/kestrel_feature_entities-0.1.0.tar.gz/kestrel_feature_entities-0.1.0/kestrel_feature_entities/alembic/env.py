"""Alembic environment.

Multi-head from day one: each consumer registers its entity module via the
`kestrel_entities.models` entry point. Alembic introspects the merged
metadata across all registered modules.

Each consumer ALSO registers a migration directory via
`kestrel_entities.migrations` so Alembic finds their revision files. This
env iterates those directories at runtime.
"""

import logging
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from kestrel_feature_entities.registry import all_metadata

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

logger = logging.getLogger("alembic.env")

target_metadata = all_metadata()
# version_locations is computed by cli.py when it writes alembic.ini, so it's
# already in `config` by the time we get here.


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        version_table="alembic_version_kestrel",
    )
    with context.begin_transaction():
        context.run_migrations()


def _to_sync_url(url: str) -> str:
    """Alembic uses sync engines. Strip async driver suffixes if present.

    `sqlite+aiosqlite:///x.db` → `sqlite:///x.db`
    `postgresql+asyncpg://...` → `postgresql+psycopg://...` (caller must have psycopg installed)
    """
    if url.startswith("sqlite+aiosqlite"):
        return "sqlite" + url[len("sqlite+aiosqlite"):]
    if url.startswith("postgresql+asyncpg"):
        return "postgresql+psycopg" + url[len("postgresql+asyncpg"):]
    return url


def run_migrations_online() -> None:
    section = config.get_section(config.config_ini_section, {}) or {}
    section["sqlalchemy.url"] = _to_sync_url(section.get("sqlalchemy.url", ""))
    connectable = engine_from_config(
        section,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            version_table="alembic_version_kestrel",
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
