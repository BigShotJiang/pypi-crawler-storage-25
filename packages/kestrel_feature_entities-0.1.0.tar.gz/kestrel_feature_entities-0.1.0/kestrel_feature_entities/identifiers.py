"""UUIDv7 primary keys.

UUIDv7 (RFC 9562) is time-ordered: 48 bits of unix-ms timestamp followed by
random bits. This gives btree locality without exposing the autoincrement
hot-spot or breaking distributed inserts.

Python stdlib doesn't ship UUIDv7 yet, so this is a small inline implementation.
"""

import os
import time
import uuid
from typing import Annotated

from sqlalchemy import Uuid
from sqlalchemy.orm import mapped_column

__all__ = ["uuid7", "UUIDPrimaryKey"]


def uuid7() -> uuid.UUID:
    ms = int(time.time() * 1000) & 0xFFFFFFFFFFFF
    rand_a = int.from_bytes(os.urandom(2), "big") & 0x0FFF
    rand_b = int.from_bytes(os.urandom(8), "big") & 0x3FFFFFFFFFFFFFFF

    value = (ms << 80) | (0x7 << 76) | (rand_a << 64) | (0x2 << 62) | rand_b
    return uuid.UUID(int=value)


UUIDPrimaryKey = Annotated[
    uuid.UUID,
    mapped_column(Uuid, primary_key=True, default=uuid7),
]
