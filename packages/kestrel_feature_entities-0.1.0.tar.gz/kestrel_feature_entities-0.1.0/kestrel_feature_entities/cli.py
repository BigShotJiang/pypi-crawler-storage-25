"""Console entry: `kestrel-entities <command>`.

Each consumer keeps its own `alembic.ini` and `migrations/versions/` directory
in its own repo. This CLI auto-generates the ini on first run with the right
shape: `script_location` points at this package (where env.py and the script
template live), while `version_locations` points at the consumer-local
`migrations/versions/` directory.

Usage from a consumer's repo root:

    kestrel-entities revision --autogenerate -m "add tenants table"
    kestrel-entities upgrade head
    kestrel-entities current
    kestrel-entities heads
"""

import importlib
import os
import sys
from importlib.metadata import entry_points
from pathlib import Path

from alembic.config import main as alembic_main


def main() -> None:
    cwd = Path.cwd()
    cfg = cwd / "alembic.ini"

    if not cfg.exists():
        _write_default_ini(cfg, cwd)

    argv = ["-c", str(cfg), *sys.argv[1:]]
    alembic_main(argv=argv)


def _consumer_version_dirs() -> list[str]:
    dirs: list[str] = []
    eps = entry_points(group="kestrel_entities.migrations")
    for ep in eps:
        mod = importlib.import_module(ep.value)
        versions = Path(mod.__file__).parent / "versions"
        versions.mkdir(parents=True, exist_ok=True)
        dirs.append(str(versions))
    return dirs


def _write_default_ini(cfg: Path, cwd: Path) -> None:
    pkg_alembic = Path(__file__).parent / "alembic"
    version_locs = os.pathsep.join(_consumer_version_dirs()) or str(pkg_alembic / "versions")

    cfg.write_text(
        f"""[alembic]
script_location = {pkg_alembic}
version_locations = {version_locs}
prepend_sys_path = .
version_path_separator = os
sqlalchemy.url = sqlite:///kestrel_entities.db

[loggers]
keys = root,sqlalchemy,alembic

[handlers]
keys = console

[formatters]
keys = generic

[logger_root]
level = WARN
handlers = console
qualname =

[logger_sqlalchemy]
level = WARN
handlers =
qualname = sqlalchemy.engine

[logger_alembic]
level = INFO
handlers =
qualname = alembic

[handler_console]
class = StreamHandler
args = (sys.stderr,)
level = NOTSET
formatter = generic

[formatter_generic]
format = %(levelname)-5.5s [%(name)s] %(message)s
datefmt = %H:%M:%S
"""
    )


if __name__ == "__main__":
    main()
