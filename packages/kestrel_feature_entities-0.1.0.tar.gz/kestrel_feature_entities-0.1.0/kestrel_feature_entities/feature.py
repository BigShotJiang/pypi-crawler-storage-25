"""Kestrel feature wrapper.

Registers the entities subsystem against the agent lifecycle so the session
factory is initialized with the correct privacy mode and the entity registry
is loaded before any consumer takes traffic.

This is an infrastructure-shaped feature: it does not currently expose
``@tool`` methods. Agent-driven dynamic schema management (define_entity,
add_field, query, etc.) is a deliberate v1 chapter that requires its own
design pass — see the v1 issue on this repo.
"""

import logging

from kestrel_sdk.features.base import Feature
from kestrel_sdk.storage.database import PrivacyMode

from .registry import discover_and_load
from .session import dispose_session_factory, get_session_factory

logger = logging.getLogger(__name__)


class EntitiesFeature(Feature):
    @property
    def tool_description(self) -> str:
        return (
            "Declarative entity / ORM layer. Provides EntityBase, mixins, and "
            "tenant-scoped async sessions to other Kestrel feature packages."
        )

    async def initialize(self) -> None:
        mode = self._resolve_privacy_mode()
        fallback_url = self._resolve_fallback_url()

        factory = get_session_factory(mode=mode, fallback_url=fallback_url)
        logger.info(
            "EntitiesFeature initialized (engine=%s, persistent=%s)",
            factory.target.description,
            factory.target.persistent,
        )

        loaded = discover_and_load()
        logger.info("Discovered %d entity module(s): %s", len(loaded), loaded)

    async def shutdown(self) -> None:
        # Releases the async engine and unlinks any ISOLATED-mode tempfile.
        # Without this, normal agent shutdown leaks both per session.
        await dispose_session_factory()
        logger.info("EntitiesFeature shut down (session factory disposed)")

    def _resolve_privacy_mode(self) -> PrivacyMode:
        value = getattr(self.agent, "privacy_mode", None)
        if value is None:
            return PrivacyMode.NORMAL
        if isinstance(value, PrivacyMode):
            return value
        # Accept enum-likes from other Kestrel packages (different class
        # identity, same .value string). Falling through to PrivacyMode(value)
        # without this would raise even when the modes are semantically equal.
        raw = value.value if hasattr(value, "value") else value
        return PrivacyMode(raw)

    def _resolve_fallback_url(self) -> str:
        url = getattr(self.agent, "entities_db_url", None)
        if url:
            return url
        return "sqlite+aiosqlite:///kestrel_entities.db"
