"""Kestrel Entities — declarative ORM for the Kestrel ecosystem.

Public surface that consumers (Castle, future feature packages) import:

    from kestrel_feature_entities import (
        EntityBase,
        AuditMixin, SoftDeleteMixin, TenantMixin, TimestampMixin,
        UUIDPrimaryKey, uuid7,
        TenantContext,
        get_session_factory,
    )
"""

from kestrel_sdk.storage.database import EngineTarget, PrivacyMode, resolve_engine_target

from .base import EntityBase
from .identifiers import UUIDPrimaryKey, uuid7
from .mixins import AuditMixin, SoftDeleteMixin, TenantMixin, TimestampMixin
from .session import SessionFactory, get_session_factory
from .tenancy import TenantContext

__all__ = [
    "EntityBase",
    "UUIDPrimaryKey",
    "uuid7",
    "AuditMixin",
    "SoftDeleteMixin",
    "TenantMixin",
    "TimestampMixin",
    "SessionFactory",
    "get_session_factory",
    "TenantContext",
    # Re-exported from kestrel_sdk.storage.database for convenience.
    "PrivacyMode",
    "EngineTarget",
    "resolve_engine_target",
]
