"""Entity discovery via entry points.

Consumers register their entity modules with:

    [project.entry-points."kestrel_entities.models"]
    castle = "kestrel_castle.entities"

The named module is imported at registry-load time. Importing the module is
sufficient to register its entities against `EntityBase.metadata` (SQLAlchemy
declarative auto-registers on class creation).

The registry's job is just to ensure all entity modules are imported before
Alembic introspects metadata or before the app starts taking traffic.
"""

import importlib
import logging
from importlib.metadata import entry_points
from typing import List

from .base import EntityBase

logger = logging.getLogger(__name__)

ENTRY_POINT_GROUP = "kestrel_entities.models"


def discover_and_load() -> List[str]:
    """Import every registered entity module. Returns names of loaded modules."""
    loaded: List[str] = []
    eps = entry_points(group=ENTRY_POINT_GROUP)
    for ep in eps:
        try:
            importlib.import_module(ep.value)
            loaded.append(ep.value)
            logger.info("Loaded entity module: %s (from %s)", ep.value, ep.name)
        except Exception:
            logger.exception("Failed to load entity module: %s", ep.value)
            raise
    return loaded


def all_metadata():
    """Return the merged metadata after loading all registered entity modules."""
    discover_and_load()
    return EntityBase.metadata
