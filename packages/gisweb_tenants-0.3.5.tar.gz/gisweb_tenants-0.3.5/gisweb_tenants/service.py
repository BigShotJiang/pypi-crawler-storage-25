# service.py

from pathlib import Path
from typing import Literal
import yaml
from .models import KeycloakAdminConfig, TenantConfig

from .models import (
    OidcBffConfig,
    EmailConfig,
    PagopaConfig,
    ProtocolloConfig,
)
from .resolvers import (
    resolve_oidc_config,
    resolve_admin_config,
    resolve_email_config,
    resolve_pagopa_config,
    resolve_protocollo_config,
)

class TenantConfigService:
    def __init__(self, tenants_file: str):
        self.tenants_file = Path(tenants_file)
        self._cache: dict[str, TenantConfig] = {}
        self._loaded = False

    def _load_all(self) -> None:
        if not self.tenants_file.exists():
            raise FileNotFoundError(
                f"Tenant config file '{self.tenants_file}' non trovato"
            )

        data = yaml.safe_load(self.tenants_file.read_text(encoding="utf-8")) or {}

        if not isinstance(data, dict):
            raise ValueError("Il file tenants.yml deve contenere una mappa tenant -> config")

        loaded: dict[str, TenantConfig] = {}

        for tenant, cfg in data.items():
            if not isinstance(tenant, str) or not tenant.strip():
                raise ValueError("Chiave tenant non valida nel file tenants.yml")

            tenant_key = tenant.strip().lower()

            if not isinstance(cfg, dict):
                raise ValueError(
                    f"La configurazione del tenant '{tenant_key}' deve essere un oggetto"
                )

            cfg.setdefault("name", tenant_key)
            loaded[tenant_key] = TenantConfig(**cfg)

        self._cache = loaded
        self._loaded = True

    def get(self, tenant: str) -> TenantConfig:
        tenant_key = tenant.strip().lower()

        if not self._loaded:
            self._load_all()

        try:
            return self._cache[tenant_key]
        except KeyError as exc:
            raise FileNotFoundError(
                f"Tenant config '{tenant_key}' non trovato"
            ) from exc

    def list_tenants(self) -> list[str]:
        if not self._loaded:
            self._load_all()
        return sorted(self._cache.keys())

    def invalidate(self) -> None:
        self._cache.clear()
        self._loaded = False


class TenantRuntimeConfigService:
    def __init__(self, tenant_service: TenantConfigService, settings):
        self.tenant_service = tenant_service
        self.settings = settings

        self._oidc_cache: dict[str, OidcBffConfig] = {}
        self._keycloak_admin_cache: dict[str, KeycloakAdminConfig] = {}
        self._email_cache: dict[tuple[str, str], EmailConfig] = {}
        self._pagopa_cache: dict[str, PagopaConfig] = {}
        self._protocollo_cache: dict[str, ProtocolloConfig] = {}

    def get_oidc(self, tenant: str) -> OidcBffConfig:
        tenant_key = tenant.strip().lower()

        if tenant_key not in self._oidc_cache:
            tenant_cfg = self.tenant_service.get(tenant_key)
            self._oidc_cache[tenant_key] = resolve_oidc_config(
                tenant_cfg,
                self.settings,
            )

        return self._oidc_cache[tenant_key]

    def get_keycloak_admin(self, tenant: str) -> KeycloakAdminConfig:
        tenant_key = tenant.strip().lower()

        if tenant_key not in self._keycloak_admin_cache:
            tenant_cfg = self.tenant_service.get(tenant_key)
            self._keycloak_admin_cache[tenant_key] = resolve_admin_config(
                tenant_cfg,
                self.settings,
            )

        return self._keycloak_admin_cache[tenant_key]

    def get_email(self, tenant: str, channel: Literal['email', 'pec'] = "email") -> EmailConfig:
        tenant_key = tenant.strip().lower()
        cache_key = (tenant_key, channel)

        if cache_key not in self._email_cache:
            tenant_cfg = self.tenant_service.get(tenant_key)
            self._email_cache[cache_key] = resolve_email_config(
                tenant_cfg,
                self.settings,
                channel=channel,
            )

        return self._email_cache[cache_key]

    def get_pagopa(self, tenant: str) -> PagopaConfig:
        tenant_key = tenant.strip().lower()

        if tenant_key not in self._pagopa_cache:
            tenant_cfg = self.tenant_service.get(tenant_key)
            self._pagopa_cache[tenant_key] = resolve_pagopa_config(
                tenant_cfg,
                self.settings,
            )

        return self._pagopa_cache[tenant_key]

    def get_protocollo(self, tenant: str) -> ProtocolloConfig:
        tenant_key = tenant.strip().lower()

        if tenant_key not in self._protocollo_cache:
            tenant_cfg = self.tenant_service.get(tenant_key)
            self._protocollo_cache[tenant_key] = resolve_protocollo_config(
                tenant_cfg,
                self.settings,
            )

        return self._protocollo_cache[tenant_key]

    def invalidate(self, tenant: str | None = None) -> None:
        if tenant is None:
            self._oidc_cache.clear()
            self._keycloak_admin_cache.clear()
            self._email_cache.clear()
            self._pagopa_cache.clear()
            self._protocollo_cache.clear()
            return

        tenant_key = tenant.strip().lower()

        self._oidc_cache.pop(tenant_key, None)
        self._keycloak_admin_cache.pop(tenant_key, None)
        self._pagopa_cache.pop(tenant_key, None)
        self._protocollo_cache.pop(tenant_key, None)

        email_keys_to_remove = [
            key for key in self._email_cache if key[0] == tenant_key
        ]
        for key in email_keys_to_remove:
            self._email_cache.pop(key, None)