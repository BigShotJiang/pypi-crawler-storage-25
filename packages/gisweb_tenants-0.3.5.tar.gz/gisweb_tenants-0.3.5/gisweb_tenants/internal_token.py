from __future__ import annotations

import time
import uuid
from typing import Literal

import jwt
from pydantic import BaseModel, Field


# =========================================================
# Exceptions
# =========================================================

class InternalTokenError(Exception):
    pass


class MissingInternalTokenError(InternalTokenError):
    pass


class InvalidInternalTokenError(InternalTokenError):
    pass


# =========================================================
# Claims model
# =========================================================

class InternalTokenClaims(BaseModel):
    iss: str
    aud: str
    sub: str
    tenant: str

    auth_type: str | None = None
    username: str | None = None
    groups: list[str] = Field(default_factory=list)

    iat: int
    exp: int
    jti: str


# =========================================================
# Encode
# =========================================================

def encode_internal_token(
    *,
    secret: str,
    audience: str,
    subject: str,
    tenant: str,
    issuer: str = "fastapi-bff",
    algorithm: Literal["HS256", "HS384", "HS512"] = "HS256",
    ttl_seconds: int = 60,
    username: str | None = None,
    groups: list[str] | None = None,
    auth_type: str | None = None,
    now: int | None = None,
    jti: str | None = None,
) -> str:
    now_ts = int(now or time.time())

    claims = InternalTokenClaims(
        iss=issuer,
        aud=audience,
        sub=subject,
        tenant=tenant,
        auth_type=auth_type,
        username=username,
        groups=[str(g) for g in (groups or []) if g],
        iat=now_ts,
        exp=now_ts + int(ttl_seconds),
        jti=jti or str(uuid.uuid4()),
    )

    return str(
        jwt.encode(
            claims.model_dump(),
            secret,
            algorithm=algorithm,
        )
    )


# =========================================================
# Decode + validate
# =========================================================

def decode_internal_token(
    token: str,
    *,
    secret: str,
    expected_audience: str,
    expected_issuer: str = "fastapi-bff",
    algorithm: Literal["HS256", "HS384", "HS512"] = "HS256",
    leeway_seconds: int = 5,
) -> InternalTokenClaims:
    if not token:
        raise MissingInternalTokenError("missing_internal_token")

    try:
        payload = jwt.decode(
            token,
            secret,
            algorithms=[algorithm],
            audience=expected_audience,
            issuer=expected_issuer,
            leeway=leeway_seconds,
            options={
                "require": [
                    "iss",
                    "aud",
                    "sub",
                    "tenant",
                    "iat",
                    "exp",
                    "jti",
                ]
            },
        )
    except jwt.ExpiredSignatureError as exc:
        raise InvalidInternalTokenError("token_expired") from exc
    except jwt.InvalidAudienceError as exc:
        raise InvalidInternalTokenError("invalid_audience") from exc
    except jwt.InvalidIssuerError as exc:
        raise InvalidInternalTokenError("invalid_issuer") from exc
    except jwt.InvalidTokenError as exc:
        raise InvalidInternalTokenError("invalid_token") from exc

    try:
        return InternalTokenClaims(**payload)
    except Exception as exc:
        raise InvalidInternalTokenError("invalid_claims") from exc


# =========================================================
# Header helper
# =========================================================

def extract_bearer_token(header_value: str | None) -> str:
    if not header_value:
        raise MissingInternalTokenError("missing_internal_authorization_header")

    scheme, _, token = header_value.partition(" ")

    if scheme.lower() != "bearer" or not token:
        raise InvalidInternalTokenError("invalid_internal_authorization_header")

    return token.strip()