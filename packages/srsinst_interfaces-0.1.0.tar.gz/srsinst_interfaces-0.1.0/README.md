# srsinst.interfaces

Shared VXI-11 and VISA interface classes for SRS instrument drivers.

This package provides `Vxi11Interface` and `VisaInterface` — thin wrappers
around `python-vxi11` and `pyvisa` respectively — for use by `srsinst.*`
instrument drivers.  It lives in the `srsinst` namespace alongside the drivers
that depend on it.

---

## Installation

```bash
pip install srsinst.interfaces
```

For development (editable install):

```bash
git clone https://github.com/thinkSRS/srsinst.interfaces.git
cd srsinst.interfaces
pip install -e .
```

---

## Backing libraries

`python-vxi11` and `pyvisa` are **not** installed automatically — only install
what your hardware actually needs:

```bash
pip install python-vxi11   # for VXI-11 (Ethernet)
pip install pyvisa         # for VISA (GPIB, USB, etc.)
```

If a backing library is missing, a clear `ImportError` is raised only when
that interface class is instantiated, not at import time.  Users who connect
exclusively over TCP/IP or RS-232 need neither library.

---

## Usage

`srsinst.interfaces` is not typically used directly — instrument drivers import
from it automatically.  If you are writing a new `srsinst.*` driver, import the
classes you need:

```python
from srsinst.interfaces import Vxi11Interface, VisaInterface
```

and add `srsinst.interfaces` to your `pyproject.toml` dependencies:

```toml
[project]
dependencies = [
    "srsgui>=0.4.5",
    "srsinst.interfaces",
]
```

---

## Contents

| Class | Backing library | Connection type |
|---|---|---|
| `Vxi11Interface` | `python-vxi11` | VXI-11 over Ethernet |
| `VisaInterface` | `pyvisa` | GPIB, USB, or any VISA resource |

Both classes inherit from `srsgui`'s `Interface` base class and integrate with
the `srsgui` instrument connection framework.

---

## License

MIT License — Copyright (c) 2026 Stanford Research Systems
