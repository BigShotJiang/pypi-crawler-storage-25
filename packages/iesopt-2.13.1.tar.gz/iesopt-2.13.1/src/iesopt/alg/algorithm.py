class Algorithm:
    pass
