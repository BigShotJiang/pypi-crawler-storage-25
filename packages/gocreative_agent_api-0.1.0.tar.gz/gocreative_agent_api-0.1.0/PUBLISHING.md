# Publishing to PyPI

One-time setup, then `pip install gocreative-agent-api` works for everyone.

## 1. Create PyPI account (~3 min)

1. Go to https://pypi.org/account/register/
2. Use email `colinhughes2005@icloud.com` (or whatever)
3. Enable 2FA (required by PyPI for new accounts)
4. Generate an API token at https://pypi.org/manage/account/token/
   - Scope: **Entire account** (we'll narrow later)
   - Save the token somewhere safe — starts with `pypi-...`

## 2. Reserve the package name

```bash
cd /Users/carlspackler/x402-api/sdk/python
python3 -m venv .venv && source .venv/bin/activate
pip install build twine
python -m build
```

That creates `dist/gocreative_agent_api-0.1.0-py3-none-any.whl` and a sdist.

## 3. Upload

```bash
twine upload dist/* -u __token__ -p <YOUR_PYPI_TOKEN>
```

(or save the token in `~/.pypirc` for future uploads)

## 4. Verify

```bash
pip install gocreative-agent-api
python -c "from gocreative_agent_api import GoCreativeClient; print('ok')"
```

## Future updates

1. Bump the `version = "..."` in `pyproject.toml`
2. `rm -rf dist/ && python -m build`
3. `twine upload dist/*`
