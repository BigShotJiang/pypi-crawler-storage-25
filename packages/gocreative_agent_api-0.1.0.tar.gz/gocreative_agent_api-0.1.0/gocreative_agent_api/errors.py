class GoCreativeError(Exception):
    """Base exception for the GoCreative SDK."""


class PaymentError(GoCreativeError):
    """Raised when x402 payment fails (insufficient balance, signing error, etc)."""


class UpstreamError(GoCreativeError):
    """Raised when the API returns a non-payment error (e.g. profile not found)."""
