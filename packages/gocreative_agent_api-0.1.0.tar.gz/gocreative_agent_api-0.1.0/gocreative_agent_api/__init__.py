"""GoCreative Agent API — pay-per-call social profile enrichment.

Usage:
    from gocreative_agent_api import GoCreativeClient

    client = GoCreativeClient(wallet_private_key="0x...")
    profile = client.enrich.instagram("nasa")
    print(profile["followers"])
"""

from .client import GoCreativeClient
from .errors import GoCreativeError, PaymentError, UpstreamError

__all__ = ["GoCreativeClient", "GoCreativeError", "PaymentError", "UpstreamError"]
__version__ = "0.1.0"
