"""GoCreative client.

Wraps the x402 buyer-side flow so devs never see HTTP 402. They just call
methods and get data back, with USDC pulled from their wallet automatically.
"""

from __future__ import annotations

import os
from typing import Any

import httpx

from .errors import GoCreativeError, PaymentError, UpstreamError

DEFAULT_BASE_URL = "https://api.gocreativeai.com/v1"


class _Enrich:
    """Single-profile enrichment endpoints."""

    def __init__(self, client: "GoCreativeClient") -> None:
        self._c = client

    def instagram(self, username: str) -> dict[str, Any]:
        """Enriched Instagram profile. Cost: $0.05 USDC."""
        return self._c._paid_get(f"/enrich/instagram/{username}")

    def tiktok(self, username: str) -> dict[str, Any]:
        """Enriched TikTok profile. Cost: $0.05 USDC."""
        return self._c._paid_get(f"/enrich/tiktok/{username}")

    def x(self, username: str) -> dict[str, Any]:
        """Enriched X/Twitter profile. Cost: $0.05 USDC."""
        return self._c._paid_get(f"/enrich/x/{username}")


class _Search:
    """Hashtag / search endpoints."""

    def __init__(self, client: "GoCreativeClient") -> None:
        self._c = client

    def instagram_hashtag(self, hashtag: str) -> dict[str, Any]:
        """Top Instagram posts for a hashtag (up to 30). Cost: $0.05 USDC."""
        return self._c._paid_get(f"/search/instagram/hashtag/{hashtag}")

    def tiktok_hashtag(self, hashtag: str) -> dict[str, Any]:
        """Top TikTok videos for a hashtag (up to 30). Cost: $0.05 USDC."""
        return self._c._paid_get(f"/search/tiktok/hashtag/{hashtag}")


class _Posts:
    """Post / tweet retrieval endpoints."""

    def __init__(self, client: "GoCreativeClient") -> None:
        self._c = client

    def x(self, username: str) -> dict[str, Any]:
        """Recent tweets from an X user (up to 30). Cost: $0.05 USDC."""
        return self._c._paid_get(f"/posts/x/{username}")


class GoCreativeClient:
    """Synchronous client for the GoCreative Agent API.

    Args:
        wallet_private_key: 0x-prefixed private key of a Base wallet with USDC.
            Falls back to the GOCREATIVE_WALLET_KEY env var.
        base_url: Override the default https://api.gocreativeai.com/v1 if you're
            proxying or self-hosting.
        max_payment_usd: Hard cap on what the SDK will auto-pay per call.
            Default: $1.00 (safety net for runaway scripts).

    Example:
        >>> client = GoCreativeClient(wallet_private_key=os.environ["MY_WALLET"])
        >>> profile = client.enrich.instagram("nasa")
        >>> profile["followers"]
        104410161
    """

    def __init__(
        self,
        wallet_private_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        max_payment_usd: float = 1.00,
        timeout: float = 60.0,
    ) -> None:
        key = wallet_private_key or os.environ.get("GOCREATIVE_WALLET_KEY")
        if not key:
            raise GoCreativeError(
                "wallet_private_key is required (or set GOCREATIVE_WALLET_KEY env var)"
            )

        self.base_url = base_url.rstrip("/")
        self.max_payment_usd = max_payment_usd
        self._timeout = timeout

        # Lazy-import x402 client SDK so import-time cost stays low.
        from x402.clients.evm import x402EvmClient  # type: ignore

        self._x402_client = x402EvmClient(private_key=key, max_value=max_payment_usd)

        # Namespaced API surface
        self.enrich = _Enrich(self)
        self.search = _Search(self)
        self.posts = _Posts(self)

    # -- HTTP --------------------------------------------------------------

    def _paid_get(self, path: str) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        with httpx.Client(timeout=self._timeout) as http:
            # First request returns HTTP 402 + payment instructions
            r = http.get(url)
            if r.status_code == 200:
                return r.json()
            if r.status_code != 402:
                raise UpstreamError(f"{r.status_code}: {r.text[:200]}")

            # Sign payment, retry
            try:
                payment_header = self._x402_client.handle_payment_required(
                    r.headers["payment-required"]
                )
            except Exception as e:
                raise PaymentError(f"failed to sign x402 payment: {e}") from e

            r2 = http.get(url, headers={"X-Payment": payment_header})
            if r2.status_code == 200:
                return r2.json()
            raise UpstreamError(
                f"after payment: {r2.status_code}: {r2.text[:200]}"
            )
