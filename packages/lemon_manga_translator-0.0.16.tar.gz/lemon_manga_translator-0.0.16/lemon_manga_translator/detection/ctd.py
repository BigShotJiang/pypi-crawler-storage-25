from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import cv2
import numpy as np
import onnxruntime as ort

from .._onnx import make_session
from ..types import BBox, TextBlock
from ._postprocess import non_max_suppression_numpy
from .ctd_utils.utils.imgproc_utils import letterbox


CONFIDENCE_THRESHOLD = 0.1
NMS_THRESHOLD = 0.2
MASK_PROB_THRESHOLD = 120  # UNet float 확률 (0..255 스케일)
DILATION_RADIUS = 3
HOLE_CLOSE_RADIUS = 10
BBOX_DILATION = 1.0


def hyperparams() -> dict:
    return {
        "confidence_threshold": CONFIDENCE_THRESHOLD,
        "nms_threshold": NMS_THRESHOLD,
        "mask_prob_threshold": MASK_PROB_THRESHOLD,
        "dilation_radius": DILATION_RADIUS,
        "hole_close_radius": HOLE_CLOSE_RADIUS,
        "bbox_dilation": BBOX_DILATION,
    }


@dataclass
class ComicTextDetection:
    mask: np.ndarray  # uint8 (H, W), 이진 0/255
    text_blocks: list[TextBlock] = field(default_factory=list)
    raw_mask: np.ndarray | None = None  # 모폴로지 전 float 마스크 (디버깅용)


class ComicTextDetector:
    def __init__(
        self,
        session: ort.InferenceSession,
        input_size: int = 1024,
    ):
        self.session = session
        self.input_size = (input_size, input_size)

    @classmethod
    def load(
        cls,
        weights_path: str | Path,
        device: str = "cpu",
        input_size: int = 1024,
    ) -> "ComicTextDetector":
        session = make_session(str(weights_path), device)
        return cls(session=session, input_size=input_size)

    def infer(self, image: np.ndarray) -> ComicTextDetection:
        # BGR/RGB 모두 수용: letterbox는 BGR 규약이지만 YOLO는 RGB로 학습됐고,
        # 아래 전처리에서 채널을 뒤집어 텐서에 넣으므로 둘 다 같은 결과가 나온다.
        if image.ndim != 3 or image.shape[2] != 3:
            raise ValueError(f"expected HxWx3 image, got {image.shape}")
        im_h, im_w = image.shape[:2]

        img_in, ratio, (dw, dh) = letterbox(
            image, new_shape=self.input_size, auto=False, stride=64
        )
        img_in = img_in.transpose((2, 0, 1))[::-1]  # HWC→CHW + BGR↔RGB
        img_in = np.ascontiguousarray(img_in, dtype=np.float32) / 255.0
        img_in = img_in[None, ...]  # (1, 3, H, W)

        blks_np, mask_np_full = self.session.run(None, {"image": img_in})

        mask_np = mask_np_full.squeeze()
        mask_np = mask_np[: mask_np.shape[0] - dh, : mask_np.shape[1] - dw]
        mask_u8 = (mask_np * 255.0).clip(0, 255).astype(np.uint8)
        mask_resized = cv2.resize(mask_u8, (im_w, im_h), interpolation=cv2.INTER_LINEAR)

        binary = (mask_resized >= MASK_PROB_THRESHOLD).astype(np.uint8) * 255
        refined = _refine_mask(binary)

        text_blocks = self._postprocess_yolo(blks_np, ratio, dw, dh, im_w, im_h)

        return ComicTextDetection(
            mask=refined,
            text_blocks=text_blocks,
            raw_mask=mask_resized,
        )

    def _postprocess_yolo(
        self,
        blks: np.ndarray,
        ratio: tuple[float, float],
        dw: int,
        dh: int,
        im_w: int,
        im_h: int,
    ) -> list[TextBlock]:
        det = non_max_suppression_numpy(blks, CONFIDENCE_THRESHOLD, NMS_THRESHOLD)[0]
        if det.shape[0] == 0:
            return []

        # letterbox()는 오른쪽/아래만 패딩한다(위/왼쪽은 0). 따라서 패딩된
        # 공간의 bbox 좌표는 이미 리사이즈된 내용과 원점을 공유하므로,
        # 리사이즈 비율로 나누기만 하면 원본 이미지 좌표가 된다.
        det[:, [0, 2]] /= ratio[0]
        det[:, [1, 3]] /= ratio[1]

        blocks: list[TextBlock] = []
        for x1, y1, x2, y2 in det[:, :4]:
            x1 = float(np.clip(x1 - BBOX_DILATION, 0, im_w))
            y1 = float(np.clip(y1 - BBOX_DILATION, 0, im_h))
            x2 = float(np.clip(x2 + BBOX_DILATION, 0, im_w))
            y2 = float(np.clip(y2 + BBOX_DILATION, 0, im_h))
            blocks.append(
                TextBlock(bbox=BBox(x=x1, y=y1, width=x2 - x1, height=y2 - y1))
            )

        # 읽기 순서 근사
        blocks.sort(key=lambda b: b.bbox.y + b.bbox.height * 0.5)
        return blocks


def _refine_mask(binary_mask: np.ndarray) -> np.ndarray:
    close_k = 2 * HOLE_CLOSE_RADIUS + 1
    dil_k = 2 * DILATION_RADIUS + 1
    close_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (close_k, close_k))
    dil_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (dil_k, dil_k))
    closed = cv2.morphologyEx(binary_mask, cv2.MORPH_CLOSE, close_kernel)
    return cv2.dilate(closed, dil_kernel)
