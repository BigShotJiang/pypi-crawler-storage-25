from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from PIL import Image


@dataclass
class TranslationResult:
    image: Image.Image
    # Vision LLM이 모든 시도(primary + fallback)에서 실패한 경우 사유. 성공/skip이면 None.
    vision_error: str | None

    def save(self, path: str | Path) -> None:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        self.image.save(str(p))
