from __future__ import annotations

import onnxruntime as ort


def make_session(path: str, device: str) -> ort.InferenceSession:
    d = device.lower()
    providers = (
        ["CUDAExecutionProvider", "CPUExecutionProvider"]
        if d in ("cuda", "gpu")
        else ["CPUExecutionProvider"]
    )
    opts = ort.SessionOptions()
    opts.enable_cpu_mem_arena = False
    return ort.InferenceSession(path, sess_options=opts, providers=providers)
