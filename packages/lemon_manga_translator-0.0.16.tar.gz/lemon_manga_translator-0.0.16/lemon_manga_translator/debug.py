from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from PIL import Image, ImageDraw

from .detection import ComicTextDetection
from .translation import VisionBlockResult
from .types import TextBlock

_BBOX_COLOR = (255, 0, 0)
_RENDER_BBOX_COLOR = (0, 200, 0)
_MASK_OVERLAY_COLOR = (255, 0, 255)
_MASK_OVERLAY_ALPHA = 0.4


def draw_bboxes(
    image: Image.Image,
    blocks: Iterable[TextBlock],
    color: tuple[int, int, int] = _BBOX_COLOR,
    width: int = 3,
) -> Image.Image:
    out = image.copy()
    draw = ImageDraw.Draw(out)
    for b in blocks:
        draw.rectangle(
            [b.bbox.x, b.bbox.y, b.bbox.x1, b.bbox.y1], outline=color, width=width
        )
    return out


def overlay_mask(
    image: Image.Image,
    mask: np.ndarray,
    color: tuple[int, int, int] = _MASK_OVERLAY_COLOR,
    alpha: float = _MASK_OVERLAY_ALPHA,
) -> Image.Image:
    base = np.asarray(image.convert("RGB"), dtype=np.uint8).copy()
    layer = base.copy()
    layer[mask > 0] = color
    blended = (base * (1 - alpha) + layer * alpha).clip(0, 255).astype(np.uint8)
    return Image.fromarray(blended, mode="RGB")


def render_bbox_debug(
    inpainted: Image.Image,
    blocks: Iterable[TextBlock],
) -> Image.Image:
    out = inpainted.copy().convert("RGB")
    draw = ImageDraw.Draw(out)
    for b in blocks:
        if not (b.translation or "").strip():
            continue
        draw.rectangle(
            [b.bbox.x, b.bbox.y, b.bbox.x1, b.bbox.y1],
            outline=_BBOX_COLOR,
            width=2,
        )
        if b.render_bbox is not None and b.render_bbox is not b.bbox:
            rb = b.render_bbox
            draw.rectangle(
                [rb.x, rb.y, rb.x1, rb.y1],
                outline=_RENDER_BBOX_COLOR,
                width=3,
            )
    return out


class PipelineDebugRecorder:
    def __init__(self, out_dir: str | Path):
        self.out_dir = Path(out_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)

    def _save(self, name: str, image: Image.Image) -> None:
        image.save(self.out_dir / name)

    def record_params(self, params: dict[str, Any]) -> None:
        path = self.out_dir / "00_params.json"
        path.write_text(json.dumps(params, ensure_ascii=False, indent=2), encoding="utf-8")

    def record_input(self, image: Image.Image) -> None:
        self._save("00_input.png", image)

    def record_detection(
        self,
        image: Image.Image,
        detection: ComicTextDetection,
        mask_restricted: np.ndarray,
    ) -> None:
        if detection.raw_mask is not None:
            self._save("01_mask_raw.png", Image.fromarray(detection.raw_mask, mode="L"))
        self._save("01_mask_refined.png", Image.fromarray(detection.mask, mode="L"))
        self._save(
            "01b_mask_bbox_restricted.png", Image.fromarray(mask_restricted, mode="L")
        )
        self._save("02_bboxes.png", draw_bboxes(image, detection.text_blocks))
        self._save("03_mask_overlay.png", overlay_mask(image, mask_restricted))

    def record_vision(
        self,
        image: Image.Image,
        vision_results: list[VisionBlockResult],
        mask_final: np.ndarray,
    ) -> None:
        if not any(r.no_translate for r in vision_results):
            return
        self._save("03b_mask_filtered.png", Image.fromarray(mask_final, mode="L"))
        self._save("03c_mask_filtered_overlay.png", overlay_mask(image, mask_final))

    def record_annotated(self, annotated: Image.Image) -> None:
        self._save("05a_annotated.png", annotated)

    def record_inpaint(self, inpainted: Image.Image) -> None:
        self._save("04_inpainted.png", inpainted)

    def record_render(
        self, inpainted: Image.Image, blocks: list[TextBlock]
    ) -> None:
        self._save("05b_render_bboxes.png", render_bbox_debug(inpainted, blocks))

    def record_final(self, final: Image.Image) -> None:
        self._save("06_final.png", final)

    def record_cost(
        self, model: str, attempts: int, usage: dict[str, Any], usd_to_krw: float = 1500.0
    ) -> None:
        cost_usd = usage.get("cost", 0.0) or 0.0
        payload = {
            "model": model,
            "attempts": attempts,
            "cost_krw": round(cost_usd * usd_to_krw, 2),
            "usage": usage,
        }
        path = self.out_dir / "05_cost.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


__all__ = [
    "PipelineDebugRecorder",
    "draw_bboxes",
    "overlay_mask",
    "render_bbox_debug",
]
