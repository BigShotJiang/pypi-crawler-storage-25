from __future__ import annotations

import logging
from dataclasses import dataclass

import cv2
import numpy as np
from PIL import Image

from .detection import ComicTextDetection, ComicTextDetector
from .detection.ctd import hyperparams as ctd_hyperparams
from .inpainting.aot import AotInpainter
from .renderer import RenderConfig, render_blocks
from .renderer.bubble import attach_render_bboxes
from .renderer.bubble import hyperparams as bubble_hyperparams
from .renderer.fonts import FontStack
from .translation import OpenRouterError, VisionBlockResult, VisionLlmClient
from .translation.openrouter import VisionPageResult
from .types import BBox, TextBlock

logger = logging.getLogger(__name__)

# YOLO bbox 밖으로 튀어나온 획 끝단까지 포함시키기 위한 여유 픽셀
DROP_BBOX_PAD = 6


@dataclass
class PipelineResult:
    detection: ComicTextDetection
    vision_results: list[VisionBlockResult]
    mask_restricted: np.ndarray
    mask_final: np.ndarray
    inpainted: Image.Image
    # vision_results가 비어있으면 inpainted와 동일
    final: Image.Image
    # LLM 호출이 실제로 실패했을 때만 설정. skip/cached/비어있음은 None.
    vision_error: str | None = None


MIN_COMPONENT_AREA = 1200
# 기존 YOLO bbox와 이 비율 이상 겹치면 복구 생략
OVERLAP_THRESHOLD = 0.3


def _iter_clipped_nonempty_bboxes(
    blocks: list[TextBlock], image_w: int, image_h: int, pad: int
):
    for block in blocks:
        x0, y0, x1, y1 = block.bbox.clip_to_image(image_w, image_h, pad)
        if x1 > x0 and y1 > y0:
            yield x0, y0, x1, y1


def _bbox_coverage_mask(
    blocks: list[TextBlock], image_h: int, image_w: int, pad: int
) -> np.ndarray:
    out = np.zeros((image_h, image_w), dtype=bool)
    for x0, y0, x1, y1 in _iter_clipped_nonempty_bboxes(blocks, image_w, image_h, pad):
        out[y0:y1, x0:x1] = True
    return out


def recover_missed_blocks(
    mask: np.ndarray,
    blocks: list[TextBlock],
    min_area: int = MIN_COMPONENT_AREA,
    overlap_threshold: float = OVERLAP_THRESHOLD,
) -> list[TextBlock]:
    if mask.max() == 0:
        return []

    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)

    H, W = mask.shape[:2]
    covered = _bbox_coverage_mask(blocks, H, W, DROP_BBOX_PAD)

    new_blocks: list[TextBlock] = []
    # label 0은 cv2 connected-component 규약상 배경
    for i in range(1, n_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area < min_area:
            continue

        component_mask = labels == i
        overlap_ratio = np.sum(component_mask & covered) / area
        if overlap_ratio > overlap_threshold:
            continue

        cx = float(stats[i, cv2.CC_STAT_LEFT])
        cy = float(stats[i, cv2.CC_STAT_TOP])
        cw = float(stats[i, cv2.CC_STAT_WIDTH])
        ch = float(stats[i, cv2.CC_STAT_HEIGHT])
        new_blocks.append(TextBlock(bbox=BBox(x=cx, y=cy, width=cw, height=ch)))

    return new_blocks


def restrict_mask_to_bboxes(
    mask: np.ndarray,
    blocks: list[TextBlock],
) -> np.ndarray:
    if not blocks:
        return np.zeros_like(mask)
    H, W = mask.shape[:2]
    allowed = _bbox_coverage_mask(blocks, H, W, DROP_BBOX_PAD)
    out = mask.copy()
    out[~allowed] = 0
    return out


def drop_no_translate_blocks(
    mask: np.ndarray,
    blocks: list[TextBlock],
    vision_results: list[VisionBlockResult],
) -> np.ndarray:
    drop_indices = {r.block_index for r in vision_results if r.no_translate}
    if not drop_indices:
        return mask
    skip_blocks = [b for i, b in enumerate(blocks) if i in drop_indices]
    out = mask.copy()
    H, W = out.shape[:2]
    for x0, y0, x1, y1 in _iter_clipped_nonempty_bboxes(skip_blocks, W, H, DROP_BBOX_PAD):
        out[y0:y1, x0:x1] = 0
    return out


def run_pipeline(
    image: Image.Image,
    ctd: ComicTextDetector,
    aot: AotInpainter,
    client: VisionLlmClient | None,
    stack: FontStack,
    *,
    skip_llm: bool = False,
    expand_bubbles: bool = True,
    cached_vision: list[VisionBlockResult] | None = None,
    recorder=None,
) -> PipelineResult:
    if recorder is not None:
        recorder.record_params({
            "image_size": list(image.size),
            "ctd": {"input_size": ctd.input_size[0], **ctd_hyperparams()},
            "pipeline": {
                "drop_bbox_pad": DROP_BBOX_PAD,
                "min_component_area": MIN_COMPONENT_AREA,
                "overlap_threshold": OVERLAP_THRESHOLD,
                "skip_llm": skip_llm,
                "expand_bubbles": expand_bubbles,
            },
            "bubble": bubble_hyperparams(),
            "vision": {
                "model": client.model if client else None,
                "max_long_edge": client.annotator.max_long_edge if client else None,
            },
        })
        recorder.record_input(image)

    logger.info("페이지 처리 시작 (크기=%dx%d)", image.size[0], image.size[1])

    image_np = np.asarray(image.convert("RGB"), dtype=np.uint8)
    detection = ctd.infer(image_np)
    logger.info("[1/7] CTD 검출 완료: YOLO %d블록", len(detection.text_blocks))

    missed = recover_missed_blocks(detection.mask, detection.text_blocks)
    if missed:
        detection.text_blocks.extend(missed)
        detection.text_blocks.sort(key=lambda b: b.bbox.y + b.bbox.height * 0.5)
        logger.info(
            "UNet 마스크에서 %d블록 추가 복구 (총 %d블록)",
            len(missed),
            len(detection.text_blocks),
        )

    mask_restricted = restrict_mask_to_bboxes(detection.mask, detection.text_blocks)
    if recorder is not None:
        recorder.record_detection(image, detection, mask_restricted)

    if not detection.text_blocks:
        logger.info("텍스트 블록 없음, LLM/인페인트/렌더 건너뜀")
        empty_mask = np.zeros_like(detection.mask)
        if recorder is not None:
            recorder.record_final(image)
        return PipelineResult(
            detection=detection,
            vision_results=[],
            mask_restricted=mask_restricted,
            mask_final=empty_mask,
            inpainted=image,
            final=image,
        )

    vision_results, vision_error = _run_vision(
        image, detection.text_blocks, client, skip_llm, cached_vision, recorder
    )

    mask_final = drop_no_translate_blocks(mask_restricted, detection.text_blocks, vision_results)
    if mask_final is not mask_restricted:
        dropped = sorted({r.block_index for r in vision_results if r.no_translate})
        logger.info("[4/7] SFX/no-translate 마스크 제외: %d블록 (인덱스=%s)", len(dropped), dropped)
    if recorder is not None:
        recorder.record_vision(image, vision_results, mask_final)

    logger.info("[5/7] AOT 인페인트 시작")
    inpainted = aot.infer(image, Image.fromarray(mask_final, mode="L"))
    logger.info("[5/7] AOT 인페인트 완료")
    if recorder is not None:
        recorder.record_inpaint(inpainted)

    final = _render(
        inpainted, detection.text_blocks, vision_results, stack, recorder,
        expand_bubbles=expand_bubbles,
    )
    if recorder is not None:
        recorder.record_final(final)

    return PipelineResult(
        detection=detection,
        vision_results=vision_results,
        mask_restricted=mask_restricted,
        mask_final=mask_final,
        inpainted=inpainted,
        final=final,
        vision_error=vision_error,
    )


def _run_vision(
    image: Image.Image,
    blocks: list[TextBlock],
    client: VisionLlmClient | None,
    skip_llm: bool,
    cached_vision: list[VisionBlockResult] | None,
    recorder=None,
) -> tuple[list[VisionBlockResult], str | None]:
    if cached_vision is not None:
        logger.info("[3/7] Vision LLM 캐시 사용: %d블록", len(cached_vision))
        return cached_vision, None
    if skip_llm or not blocks:
        return [], None
    if client is None:
        logger.info("[3/7] Vision LLM 건너뜀: API 키/모델 미설정")
        return [], None

    logger.info(
        "[3/7] Vision LLM 호출 시작 (블록=%d, 모델=%s)", len(blocks), client.model
    )
    try:
        page_result: VisionPageResult = client.run_page(image, blocks)
    except OpenRouterError as e:
        msg = str(e)
        logger.warning("[3/7] Vision LLM 실패: %s", msg)
        return [], msg

    if recorder is not None:
        if page_result.annotated is not None:
            recorder.record_annotated(page_result.annotated)
        if page_result.usage:
            recorder.record_cost(
                page_result.model or client.model,
                page_result.attempts,
                page_result.usage,
            )

    results = page_result.blocks
    dialogue_count = sum(1 for r in results if not r.no_translate)
    sfx_count = sum(1 for r in results if r.no_translate)
    logger.info(
        "[3/7] Vision LLM 완료 (시도=%d회, 대사=%d, SFX/제외=%d)",
        page_result.attempts,
        dialogue_count,
        sfx_count,
    )
    for r in results:
        tag = "제외" if r.no_translate else "대사"
        logger.debug("  블록[%d] %s -> %r", r.block_index, tag, r.ko_translation)
    return results, None


def _render(
    inpainted: Image.Image,
    blocks: list[TextBlock],
    vision_results: list[VisionBlockResult],
    stack: FontStack,
    recorder,
    *,
    expand_bubbles: bool = True,
) -> Image.Image:
    if not vision_results:
        logger.info("Vision 결과 없음, 렌더 건너뜀")
        return inpainted

    for r in vision_results:
        if 0 <= r.block_index < len(blocks):
            blocks[r.block_index].translation = r.ko_translation

    if expand_bubbles:
        inpainted_np = np.asarray(inpainted.convert("RGB"), dtype=np.uint8)
        attach_render_bboxes(inpainted_np, blocks)
        logger.info("[6/7] 말풍선 영역 확장 적용")
    if recorder is not None:
        recorder.record_render(inpainted, blocks)

    rendered_count = sum(1 for b in blocks if (b.translation or "").strip())
    final = render_blocks(inpainted, blocks, stack=stack)
    logger.info("[7/7] 텍스트 렌더 완료 (%d블록)", rendered_count)
    return final
