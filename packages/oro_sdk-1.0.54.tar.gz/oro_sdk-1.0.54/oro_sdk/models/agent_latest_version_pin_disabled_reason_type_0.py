from enum import Enum


class AgentLatestVersionPinDisabledReasonType0(str, Enum):
    BELOW_THRESHOLD = "below_threshold"
    DISCARDED = "discarded"
    ELIMINATED = "eliminated"
    NOT_ELIGIBLE = "not_eligible"

    def __str__(self) -> str:
        return str(self.value)
