from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_public import AgentPublic


T = TypeVar("T", bound="MinerAgentsResponse")


@_attrs_define
class MinerAgentsResponse:
    """
    Attributes:
        agents (list[AgentPublic]): List of agents owned by the miner
        can_submit (bool): Whether the miner is currently allowed to submit a new agent
        next_allowed_at (datetime.datetime | None | Unset): Earliest time the miner may submit again, if on cooldown
        racing_agent_version_id (None | Unset | UUID): The agent_version_id this miner would race with right now: the
            explicitly pinned version when valid, otherwise the picker's auto-pick (highest-scoring eligible version on this
            hotkey >= the qualifying threshold). None when nothing on this hotkey qualifies.
        racing_agent_id (None | Unset | UUID): The agent_id that owns racing_agent_version_id. Surfaced alongside the
            version id so the dashboard can highlight the right row even when the racing version isn't that agent's latest.
            None when racing_agent_version_id is None.
    """

    agents: list[AgentPublic]
    can_submit: bool
    next_allowed_at: datetime.datetime | None | Unset = UNSET
    racing_agent_version_id: None | Unset | UUID = UNSET
    racing_agent_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agents = []
        for agents_item_data in self.agents:
            agents_item = agents_item_data.to_dict()
            agents.append(agents_item)

        can_submit = self.can_submit

        next_allowed_at: None | str | Unset
        if isinstance(self.next_allowed_at, Unset):
            next_allowed_at = UNSET
        elif isinstance(self.next_allowed_at, datetime.datetime):
            next_allowed_at = self.next_allowed_at.isoformat()
        else:
            next_allowed_at = self.next_allowed_at

        racing_agent_version_id: None | str | Unset
        if isinstance(self.racing_agent_version_id, Unset):
            racing_agent_version_id = UNSET
        elif isinstance(self.racing_agent_version_id, UUID):
            racing_agent_version_id = str(self.racing_agent_version_id)
        else:
            racing_agent_version_id = self.racing_agent_version_id

        racing_agent_id: None | str | Unset
        if isinstance(self.racing_agent_id, Unset):
            racing_agent_id = UNSET
        elif isinstance(self.racing_agent_id, UUID):
            racing_agent_id = str(self.racing_agent_id)
        else:
            racing_agent_id = self.racing_agent_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agents": agents,
                "can_submit": can_submit,
            }
        )
        if next_allowed_at is not UNSET:
            field_dict["next_allowed_at"] = next_allowed_at
        if racing_agent_version_id is not UNSET:
            field_dict["racing_agent_version_id"] = racing_agent_version_id
        if racing_agent_id is not UNSET:
            field_dict["racing_agent_id"] = racing_agent_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_public import AgentPublic

        d = dict(src_dict)
        agents = []
        _agents = d.pop("agents")
        for agents_item_data in _agents:
            agents_item = AgentPublic.from_dict(agents_item_data)

            agents.append(agents_item)

        can_submit = d.pop("can_submit")

        def _parse_next_allowed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                next_allowed_at_type_0 = isoparse(data)

                return next_allowed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        next_allowed_at = _parse_next_allowed_at(d.pop("next_allowed_at", UNSET))

        def _parse_racing_agent_version_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                racing_agent_version_id_type_0 = UUID(data)

                return racing_agent_version_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        racing_agent_version_id = _parse_racing_agent_version_id(d.pop("racing_agent_version_id", UNSET))

        def _parse_racing_agent_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                racing_agent_id_type_0 = UUID(data)

                return racing_agent_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        racing_agent_id = _parse_racing_agent_id(d.pop("racing_agent_id", UNSET))

        miner_agents_response = cls(
            agents=agents,
            can_submit=can_submit,
            next_allowed_at=next_allowed_at,
            racing_agent_version_id=racing_agent_version_id,
            racing_agent_id=racing_agent_id,
        )

        miner_agents_response.additional_properties = d
        return miner_agents_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
