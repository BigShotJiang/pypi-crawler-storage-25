from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.agent_version_history_entry_pin_disabled_reason_type_0 import (
    AgentVersionHistoryEntryPinDisabledReasonType0,
)
from ..models.agent_version_history_entry_selection_fallback_reason_type_0 import (
    AgentVersionHistoryEntrySelectionFallbackReasonType0,
)
from ..models.agent_version_state import AgentVersionState
from ..types import UNSET, Unset

T = TypeVar("T", bound="AgentVersionHistoryEntry")


@_attrs_define
class AgentVersionHistoryEntry:
    """
    Attributes:
        agent_version_id (UUID): Version ID
        version_number (int): Version number (v1, v2, etc.)
        submitted_at (datetime.datetime): Submission timestamp
        state (AgentVersionState): State of an agent version evaluation.
        eliminated_at (datetime.datetime | None | Unset): When the agent was eliminated from future races, if any
        eliminated_in_race_number (int | None | Unset): Race number that eliminated this agent, if any
        final_score (float | None | Unset): Final score if eligible
        is_selected_for_race (bool | Unset): True when this version is the miner's pinned race candidate Default: False.
        selection_fallback_reason (AgentVersionHistoryEntrySelectionFallbackReasonType0 | None | Unset): Set on the
            pinned version only when the pin can't take effect.
        is_pinnable (bool | Unset): True when this version can be pinned as the next race candidate. Mirrors the
            admission rules used by the PUT /v1/miner/race-selection endpoint. Default: False.
        pin_disabled_reason (AgentVersionHistoryEntryPinDisabledReasonType0 | None | Unset): When `is_pinnable` is
            false, the specific precondition that fails. Same enum as `selection_fallback_reason`.
    """

    agent_version_id: UUID
    version_number: int
    submitted_at: datetime.datetime
    state: AgentVersionState
    eliminated_at: datetime.datetime | None | Unset = UNSET
    eliminated_in_race_number: int | None | Unset = UNSET
    final_score: float | None | Unset = UNSET
    is_selected_for_race: bool | Unset = False
    selection_fallback_reason: AgentVersionHistoryEntrySelectionFallbackReasonType0 | None | Unset = UNSET
    is_pinnable: bool | Unset = False
    pin_disabled_reason: AgentVersionHistoryEntryPinDisabledReasonType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        version_number = self.version_number

        submitted_at = self.submitted_at.isoformat()

        state = self.state.value

        eliminated_at: None | str | Unset
        if isinstance(self.eliminated_at, Unset):
            eliminated_at = UNSET
        elif isinstance(self.eliminated_at, datetime.datetime):
            eliminated_at = self.eliminated_at.isoformat()
        else:
            eliminated_at = self.eliminated_at

        eliminated_in_race_number: int | None | Unset
        if isinstance(self.eliminated_in_race_number, Unset):
            eliminated_in_race_number = UNSET
        else:
            eliminated_in_race_number = self.eliminated_in_race_number

        final_score: float | None | Unset
        if isinstance(self.final_score, Unset):
            final_score = UNSET
        else:
            final_score = self.final_score

        is_selected_for_race = self.is_selected_for_race

        selection_fallback_reason: None | str | Unset
        if isinstance(self.selection_fallback_reason, Unset):
            selection_fallback_reason = UNSET
        elif isinstance(self.selection_fallback_reason, AgentVersionHistoryEntrySelectionFallbackReasonType0):
            selection_fallback_reason = self.selection_fallback_reason.value
        else:
            selection_fallback_reason = self.selection_fallback_reason

        is_pinnable = self.is_pinnable

        pin_disabled_reason: None | str | Unset
        if isinstance(self.pin_disabled_reason, Unset):
            pin_disabled_reason = UNSET
        elif isinstance(self.pin_disabled_reason, AgentVersionHistoryEntryPinDisabledReasonType0):
            pin_disabled_reason = self.pin_disabled_reason.value
        else:
            pin_disabled_reason = self.pin_disabled_reason

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "version_number": version_number,
                "submitted_at": submitted_at,
                "state": state,
            }
        )
        if eliminated_at is not UNSET:
            field_dict["eliminated_at"] = eliminated_at
        if eliminated_in_race_number is not UNSET:
            field_dict["eliminated_in_race_number"] = eliminated_in_race_number
        if final_score is not UNSET:
            field_dict["final_score"] = final_score
        if is_selected_for_race is not UNSET:
            field_dict["is_selected_for_race"] = is_selected_for_race
        if selection_fallback_reason is not UNSET:
            field_dict["selection_fallback_reason"] = selection_fallback_reason
        if is_pinnable is not UNSET:
            field_dict["is_pinnable"] = is_pinnable
        if pin_disabled_reason is not UNSET:
            field_dict["pin_disabled_reason"] = pin_disabled_reason

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        version_number = d.pop("version_number")

        submitted_at = isoparse(d.pop("submitted_at"))

        state = AgentVersionState(d.pop("state"))

        def _parse_eliminated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                eliminated_at_type_0 = isoparse(data)

                return eliminated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        eliminated_at = _parse_eliminated_at(d.pop("eliminated_at", UNSET))

        def _parse_eliminated_in_race_number(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        eliminated_in_race_number = _parse_eliminated_in_race_number(d.pop("eliminated_in_race_number", UNSET))

        def _parse_final_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        final_score = _parse_final_score(d.pop("final_score", UNSET))

        is_selected_for_race = d.pop("is_selected_for_race", UNSET)

        def _parse_selection_fallback_reason(
            data: object,
        ) -> AgentVersionHistoryEntrySelectionFallbackReasonType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                selection_fallback_reason_type_0 = AgentVersionHistoryEntrySelectionFallbackReasonType0(data)

                return selection_fallback_reason_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AgentVersionHistoryEntrySelectionFallbackReasonType0 | None | Unset, data)

        selection_fallback_reason = _parse_selection_fallback_reason(d.pop("selection_fallback_reason", UNSET))

        is_pinnable = d.pop("is_pinnable", UNSET)

        def _parse_pin_disabled_reason(data: object) -> AgentVersionHistoryEntryPinDisabledReasonType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                pin_disabled_reason_type_0 = AgentVersionHistoryEntryPinDisabledReasonType0(data)

                return pin_disabled_reason_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AgentVersionHistoryEntryPinDisabledReasonType0 | None | Unset, data)

        pin_disabled_reason = _parse_pin_disabled_reason(d.pop("pin_disabled_reason", UNSET))

        agent_version_history_entry = cls(
            agent_version_id=agent_version_id,
            version_number=version_number,
            submitted_at=submitted_at,
            state=state,
            eliminated_at=eliminated_at,
            eliminated_in_race_number=eliminated_in_race_number,
            final_score=final_score,
            is_selected_for_race=is_selected_for_race,
            selection_fallback_reason=selection_fallback_reason,
            is_pinnable=is_pinnable,
            pin_disabled_reason=pin_disabled_reason,
        )

        agent_version_history_entry.additional_properties = d
        return agent_version_history_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
