from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.miner_race_selection_request import MinerRaceSelectionRequest
from ...models.not_version_owner_error import NotVersionOwnerError
from ...models.race_locked_error import RaceLockedError
from ...types import Response


def _get_kwargs(
    *,
    body: MinerRaceSelectionRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/miner/race-selection",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError | None:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 403:
        response_403 = NotVersionOwnerError.from_dict(response.json())

        return response_403

    if response.status_code == 409:
        response_409 = RaceLockedError.from_dict(response.json())

        return response_409

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: MinerRaceSelectionRequest,
) -> Response[Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError]:
    """Pin agent version as race candidate

     Pin the given agent version as this miner's race candidate.

    Args:
        body (MinerRaceSelectionRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: MinerRaceSelectionRequest,
) -> Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError | None:
    """Pin agent version as race candidate

     Pin the given agent version as this miner's race candidate.

    Args:
        body (MinerRaceSelectionRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: MinerRaceSelectionRequest,
) -> Response[Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError]:
    """Pin agent version as race candidate

     Pin the given agent version as this miner's race candidate.

    Args:
        body (MinerRaceSelectionRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: MinerRaceSelectionRequest,
) -> Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError | None:
    """Pin agent version as race candidate

     Pin the given agent version as this miner's race candidate.

    Args:
        body (MinerRaceSelectionRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | NotVersionOwnerError | RaceLockedError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
