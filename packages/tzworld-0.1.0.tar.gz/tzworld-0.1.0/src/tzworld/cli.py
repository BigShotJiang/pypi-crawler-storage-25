#!/usr/bin/env python3
"""tz — world clock TUI. Navigate time across zones with arrow keys."""

import curses
import os
import json
import argparse
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

CONFIG = os.path.expanduser("~/.config/tz/config.json")
CELL_W = 7  # " HH:MM "

MONTHS = "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()

DEFAULT_ZONES = [
    ("UTC",                 "UTC"),
    ("America/New_York",    "New York"),
    ("America/Chicago",     "Chicago"),
    ("America/Los_Angeles", "Los Angeles"),
    ("Europe/London",       "London"),
    ("Europe/Berlin",       "Berlin"),
    ("Asia/Kolkata",        "Kolkata"),
    ("Asia/Singapore",      "Singapore"),
    ("Asia/Tokyo",          "Tokyo"),
    ("Australia/Sydney",    "Sydney"),
]

# Color pair IDs
CLR_NOW  = 1  # "now" column: green
CLR_HDR  = 2  # header text: bold white
CLR_SEL  = 3  # selected cell: black on yellow
CLR_SCOL = 4  # selected column (non-selected row): white on blue
CLR_SROW = 5  # selected row (non-selected col): yellow text
CLR_DATE = 6  # day boundary label: cyan
CLR_DIFF = 7  # cell on a different date than ref zone: magenta


def load_cfg():
    if os.path.exists(CONFIG):
        try:
            with open(CONFIG) as f:
                d = json.load(f)
            zones = [(z["zone"], z.get("label", z["zone"])) for z in d.get("zones", [])]
            zones = zones or DEFAULT_ZONES
            ref   = d.get("ref_zone", zones[0][0])
            return zones, int(d.get("quantum", 15)), ref
        except Exception:
            pass
    return DEFAULT_ZONES, 15, DEFAULT_ZONES[0][0]


def floor_dt(dt: datetime, q: int) -> datetime:
    total_m = dt.hour * 60 + dt.minute
    floored = (total_m // q) * q
    return dt.replace(hour=floored // 60, minute=floored % 60, second=0, microsecond=0)


def at(base: datetime, offset: int, q: int) -> datetime:
    return base + timedelta(minutes=offset * q)


def to_local(dt: datetime, zone: str) -> datetime:
    return dt.astimezone(ZoneInfo(zone))


def init_colors():
    curses.use_default_colors()
    curses.init_pair(CLR_NOW,  curses.COLOR_GREEN,   -1)
    curses.init_pair(CLR_HDR,  curses.COLOR_WHITE,   -1)
    curses.init_pair(CLR_SEL,  curses.COLOR_BLACK,   curses.COLOR_YELLOW)
    curses.init_pair(CLR_SCOL, curses.COLOR_WHITE,   curses.COLOR_BLUE)
    curses.init_pair(CLR_SROW, curses.COLOR_YELLOW,  -1)
    curses.init_pair(CLR_DATE, curses.COLOR_CYAN,    -1)
    curses.init_pair(CLR_DIFF, curses.COLOR_MAGENTA, -1)


def label_width(zones) -> int:
    # " {name} · Mon Apr 22" — extra 14 chars for the date suffix
    return max(len(lbl) for _, lbl in zones) + 16


def draw(stdscr, zones, q, ref, base, cur_row, cur_col, scroll):
    stdscr.erase()
    H, W = stdscr.getmaxyx()

    LW = min(label_width(zones), W // 3)
    nc = max(1, (W - LW) // CELL_W)
    nr = min(len(zones), H - 2)  # header row + status bar

    def put(y, x, s, attr=0):
        if 0 <= y < H and 0 <= x < W and s:
            try:
                stdscr.addstr(y, x, s[:max(0, W - x)], attr)
            except curses.error:
                pass

    # ── Header ──────────────────────────────────────────────────────────
    put(0, 0, " " * LW, curses.color_pair(CLR_HDR) | curses.A_BOLD)

    prev_date = to_local(at(base, scroll - 1, q), ref).date()
    for i in range(nc):
        off   = scroll + i
        t     = at(base, off, q)
        loc_t = to_local(t, ref)
        today = loc_t.date()
        x     = LW + i * CELL_W

        # Day boundary: show "AprDD" instead of time
        if today != prev_date:
            label = f"{MONTHS[today.month - 1]}{today.day:02d}"
        else:
            label = loc_t.strftime("%H:%M")

        if off == cur_col:
            attr = curses.color_pair(CLR_SEL) | curses.A_BOLD
        elif off == 0:
            attr = curses.color_pair(CLR_NOW) | curses.A_BOLD
        elif today != prev_date:
            attr = curses.color_pair(CLR_DATE) | curses.A_BOLD
        else:
            attr = curses.color_pair(CLR_HDR) | curses.A_BOLD

        put(0, x, f" {label:>5} ", attr)
        prev_date = today

    # ── Zone rows ────────────────────────────────────────────────────────
    sel_t   = at(base, cur_col, q)
    max_lbl = max(len(lbl) for _, lbl in zones)

    for r in range(nr):
        zone_id, lbl = zones[r]
        y = r + 1

        # Pad name to max width so " · Date" column-aligns across all rows
        zone_date = to_local(sel_t, zone_id)
        date_str  = zone_date.strftime("%a %b %d")
        row_lbl   = f" {lbl:<{max_lbl}} · {date_str}"
        row_lbl   = f"{row_lbl:<{LW}}"[:LW]

        if r == cur_row:
            put(y, 0, row_lbl, curses.color_pair(CLR_SROW) | curses.A_BOLD)
        else:
            put(y, 0, row_lbl)

        for i in range(nc):
            off      = scroll + i
            t        = at(base, off, q)
            loc_t    = to_local(t, zone_id)
            cell_date = loc_t.date()
            col_ref_date = to_local(t, ref).date()
            time     = loc_t.strftime("%H:%M")
            cell     = f" {time} "
            x        = LW + i * CELL_W

            sel_cell  = r == cur_row and off == cur_col
            sel_col   = off == cur_col
            sel_row   = r == cur_row
            diff_date = cell_date != col_ref_date  # different date than ref zone

            if sel_cell:
                attr = curses.color_pair(CLR_SEL) | curses.A_BOLD
            elif sel_col:
                attr = curses.color_pair(CLR_SCOL)
            elif sel_row and diff_date:
                attr = curses.color_pair(CLR_DIFF) | curses.A_BOLD
            elif sel_row:
                attr = curses.color_pair(CLR_SROW) | curses.A_BOLD
            elif off == 0 and diff_date:
                attr = curses.color_pair(CLR_DIFF)
            elif off == 0:
                attr = curses.color_pair(CLR_NOW)
            elif diff_date:
                attr = curses.color_pair(CLR_DIFF)
            else:
                attr = curses.A_NORMAL

            put(y, x, cell, attr)

    # ── Status bar ───────────────────────────────────────────────────────
    utc_str  = sel_t.strftime("UTC %a %b %d %Y %H:%M")
    sel_l    = to_local(sel_t, zones[cur_row][0])
    local_str = sel_l.strftime(f"{zones[cur_row][1]}: %H:%M %Z (%a %b %d)")
    keys     = "←→ time · ↑↓ zone · t=now · +/- quantum · q=quit"
    bar      = f" {keys}  │  {utc_str}  │  {local_str}"
    put(H - 1, 0, bar.ljust(W - 1)[:W - 1], curses.color_pair(CLR_HDR) | curses.A_REVERSE)

    stdscr.refresh()


def run(stdscr, zones, q, ref):
    curses.curs_set(0)
    curses.start_color()
    init_colors()
    stdscr.keypad(True)
    stdscr.timeout(30_000)  # refresh every 30s to track live clock

    now  = datetime.now(timezone.utc)
    base = floor_dt(now, q)

    H, W = stdscr.getmaxyx()
    LW   = min(label_width(zones), W // 3)
    nc   = max(1, (W - LW) // CELL_W)

    cur_row = 0
    cur_col = 0
    scroll  = -(nc // 4)  # "now" appears ~1/4 from left

    while True:
        H, W = stdscr.getmaxyx()
        LW   = min(label_width(zones), W // 3)
        nc   = max(1, (W - LW) // CELL_W)
        nr   = min(len(zones), H - 2)

        # Keep cur_col in the visible window
        if cur_col < scroll:
            scroll = cur_col
        elif cur_col >= scroll + nc:
            scroll = cur_col - nc + 1

        draw(stdscr, zones, q, ref, base, cur_row, cur_col, scroll)

        key = stdscr.getch()

        if key in (ord('q'), ord('Q')):
            break
        elif key == curses.KEY_RIGHT:
            cur_col += 1
        elif key == curses.KEY_LEFT:
            cur_col -= 1
        elif key == curses.KEY_DOWN:
            cur_row = min(nr - 1, cur_row + 1)
        elif key == curses.KEY_UP:
            cur_row = max(0, cur_row - 1)
        elif key in (ord('t'), ord('T')):
            now  = datetime.now(timezone.utc)
            base = floor_dt(now, q)
            cur_col = 0
            scroll  = -(nc // 4)
        elif key in (ord('+'), ord('=')):
            candidates = [1, 5, 10, 15, 30, 60, 120]
            nxt = next((c for c in candidates if c > q), candidates[-1])
            cur_t  = at(base, cur_col, q)   # preserve selected moment
            q      = nxt
            base   = floor_dt(now, q)
            now    = datetime.now(timezone.utc)
            base   = floor_dt(now, q)
            # Re-anchor cur_col so selected moment stays roughly the same
            delta_m = int((cur_t - base).total_seconds() / 60)
            cur_col = round(delta_m / q)
            scroll  = cur_col - nc // 4
        elif key in (ord('-'), ord('_')):
            candidates = [1, 5, 10, 15, 30, 60, 120]
            prv = next((c for c in reversed(candidates) if c < q), candidates[0])
            cur_t = at(base, cur_col, q)
            q     = prv
            now   = datetime.now(timezone.utc)
            base  = floor_dt(now, q)
            delta_m = int((cur_t - base).total_seconds() / 60)
            cur_col = round(delta_m / q)
            scroll  = cur_col - nc // 4
        elif key == -1:
            # Timeout — advance base if a new quantum has begun
            now_new  = datetime.now(timezone.utc)
            new_base = floor_dt(now_new, q)
            now      = now_new
            base     = new_base
        elif key == curses.KEY_RESIZE:
            pass  # redraws automatically on next loop


def main():
    ap = argparse.ArgumentParser(
        description="World clock TUI — navigate time across zones with arrow keys"
    )
    ap.add_argument(
        "-q", "--quantum", type=int, metavar="MIN",
        help="Minutes per column step (default: 15)",
    )
    args = ap.parse_args()

    zones, q, ref = load_cfg()
    if args.quantum:
        q = args.quantum

    curses.wrapper(run, zones, q, ref)


if __name__ == "__main__":
    main()
