# tzworld

TUI world clock. Navigate time across configured timezones with arrow keys.

## Install

```
pipx install tzworld
# or
uv tool install tzworld
```

## Usage

```
tz                  # launch with defaults
tz -q 30            # 30-minute column steps
```

### Keys

| Key | Action |
|-----|--------|
| `←` `→` | Move through time |
| `↑` `↓` | Switch zone row |
| `t` | Jump to now |
| `+` / `-` | Increase / decrease quantum |
| `q` | Quit |

## Config

`~/.config/tz/config.json`

```json
{
  "quantum": 15,
  "ref_zone": "UTC",
  "zones": [
    { "zone": "America/New_York",    "label": "New York"    },
    { "zone": "UTC",                 "label": "UTC"         },
    { "zone": "Europe/London",       "label": "London"      },
    { "zone": "Asia/Kolkata",        "label": "Kolkata"     },
    { "zone": "Asia/Tokyo",          "label": "Tokyo"       }
  ]
}
```

`ref_zone` controls which timezone drives the column header times and the date-diff highlighting (cells on a different calendar date than the ref zone are shown in magenta).
