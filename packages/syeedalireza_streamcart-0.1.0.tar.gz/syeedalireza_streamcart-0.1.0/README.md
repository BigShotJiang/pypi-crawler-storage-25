# StreamCart: Real-time Clickstream Data Lakehouse

**StreamCart** ingests millions of user click events in real-time to build personalized shopping experiences and real-time analytics dashboards.

Developed by **Alireza Aminzadeh** ([@syeedalireza](https://github.com/syeedalireza)).

## Architecture
- **Streaming:** Apache Kafka
- **Processing:** PyFlink / Faust
- **OLAP Database:** ClickHouse
- **Pattern:** Lambda/Kappa Architecture

*(Technical implementation pending in next iteration)*
