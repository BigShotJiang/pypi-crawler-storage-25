"""StreamCart package"""
