# 🤖 AI Guidelines for brdd-python

This document provides instructions for AI agents to implement or extend the `brdd-python` library correctly.

## 🛠 Implementation Principles

1. **Minimalism:** Do not add dependencies beyond `pydantic` or standard library unless strictly necessary.
2. **Immutability:** The `ExecutionContext` should ideally be treated as a builder pattern or a data class that collects state.
3. **Traceability:** Ensure every `context.add_error` or `context.add_effect` requires a string code (e.g., `R001`).

## 🏗 Core Components to Implement

### 1. `ValidationContext`
- Must collect errors in a list of objects: `{ "code": str, "message": str }`.
- Must have a `is_valid()` method.

### 2. `ExecutionContext`
- Must contain: `data`, `errors`, `setters`, `effects`, and `status`.
- Must follow the [Unified Response Pattern](https://github.com/brdd-design/brdd/tree/main/articles/EN/BRDD-STORY.md).

### 3. Service Protocols
- Use `typing.Protocol` to define `ValidateService`, `EnrichService`, and `ClientService`.

## 📝 Example implementation snippet for AI:
```python
from typing import List, Any, Optional
from pydantic import BaseModel

class BRDDError(BaseModel):
    code: str
    message: str

class ExecutionContext(BaseModel):
    data: Optional[Any] = None
    errors: List[BRDDError] = []
    setters: List[str] = []
    effects: List[str] = []
    status: int = 200
```
