from typing import Any, List, Optional
from .core import ExecutionContext, DefaultExecutionContext, ValidationContext

class MetadataUseCaseMixin:
    """Mixin to provide metadata-driven context initialization."""
    def create_context(self, data: Optional[Any] = None) -> ExecutionContext:
        meta = getattr(self.__class__, "__brdd__", None)
        use_case_id = meta.use_case_id if meta else "UNKNOWN"
        context = DefaultExecutionContext(data=data)
        # We need a way to store the use_case_id in DefaultExecutionContext
        # Let's assume we might want to extend it later or just pass it in metadata
        context.add_setter(f"USE_CASE:{use_case_id}") 
        return context

class MetadataValidatorMixin:
    """Mixin to automatically execute methods decorated with @rule."""
    def validate_rules(self, context: ValidationContext, data: Any) -> None:
        for attr_name in dir(self):
            method = getattr(self, attr_name)
            if hasattr(method, "__brdd__"):
                meta = method.__brdd__
                for rule_id, rule_info in meta.rules.items():
                    result = method(data)
                    if not result:
                        context.add_error(rule_id, rule_info.get("message", ""))
                    # Optional: record success if needed
