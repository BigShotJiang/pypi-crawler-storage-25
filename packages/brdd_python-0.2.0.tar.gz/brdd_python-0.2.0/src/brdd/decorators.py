from typing import Any, Callable, Dict, Optional, Type
from functools import wraps

class BRDDMetadata:
    """Stores BRDD metadata for a class or method."""
    def __init__(self):
        self.use_case_id: Optional[str] = None
        self.rules: Dict[str, Dict[str, str]] = {}  # ID -> {message}
        self.effects: Dict[str, bool] = {} # ID -> True
        self.setters: Dict[str, bool] = {} # ID -> True

def get_brdd_metadata(obj: Any) -> BRDDMetadata:
    """Helper to retrieve or initialize BRDD metadata on an object."""
    if not hasattr(obj, "__brdd__"):
        obj.__brdd__ = BRDDMetadata()
    return obj.__brdd__

def use_case(id: str):
    """
    Decorator to mark a class as a BRDD Use Case.
    
    Associates a unique business identifier with the class, which can be 
    automatically retrieved during context initialization.
    """
    def decorator(cls: Type):
        meta = get_brdd_metadata(cls)
        meta.use_case_id = id
        return cls
    return decorator

def rule(id: str, message: str = ""):
    """
    Decorator to mark a method as a Business Rule validation.
    
    The method should return a boolean-like value. If the value is falsy, 
    the framework will automatically add an error to the context with 
    the provided ID and message.
    """
    def decorator(func: Callable):
        meta = get_brdd_metadata(func)
        meta.rules[id] = {"message": message}
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper
    return decorator

def effect(id: str):
    """
    Decorator to mark a method as a Side Effect trigger.
    """
    def decorator(func: Callable):
        meta = get_brdd_metadata(func)
        meta.effects[id] = True
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper
    return decorator

def setter(id: str):
    """
    Decorator to mark a method as a Data Setter.
    """
    def decorator(func: Callable):
        meta = get_brdd_metadata(func)
        meta.setters[id] = True
        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper
    return decorator
