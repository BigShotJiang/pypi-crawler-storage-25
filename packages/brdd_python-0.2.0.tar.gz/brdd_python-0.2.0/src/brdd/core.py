from typing import Any, List, Optional, Protocol, runtime_checkable
from pydantic import BaseModel, Field

@runtime_checkable
class BRDDError(BaseModel):
    """
    Standardized error object for Business Rule Driven Design.
    
    Represents a single business rule violation with a machine-readable code
    and a human-readable message.
    """
    code: str = Field(..., description="Unique business code (e.g., R001)")
    message: str = Field(..., description="Human-readable error description")

@runtime_checkable
class ValidationContext(Protocol):
    """
    A subset of the execution context focused on rule validation.
    
    Provides methods to record rule violations and check the overall
    validity of the current execution state.
    """
    def add_error(self, code: str, message: str) -> None:
        """Records a new business rule violation."""
        ...

    def is_valid(self) -> bool:
        """Returns True if no errors have been recorded."""
        ...

    @property
    def errors(self) -> List[BRDDError]:
        """Returns the list of recorded errors."""
        ...

@runtime_checkable
class ExecutionContext(ValidationContext, Protocol):
    """
    The central state container for a BRDD Use Case execution.
    
    Orchestrates data, errors, state changes (setters), and side effects.
    This object is the 'narrative' of what happened during execution.
    """
    @property
    def data(self) -> Optional[Any]: 
        """The main result data of the use case."""
        ...
    
    @property
    def setters(self) -> List[str]: 
        """History of state changes applied during execution."""
        ...
    
    @property
    def effects(self) -> List[str]: 
        """History of side effects triggered (notifications, events, etc.)."""
        ...
    
    @property
    def status(self) -> int: 
        """HTTP-compatible status code representing the result."""
        ...

    def add_effect(self, code: str) -> None:
        """Records that a side effect has been triggered."""
        ...

    def add_setter(self, code: str) -> None:
        """Records that a state change has been applied."""
        ...

    def set_data(self, data: Any) -> None:
        """Sets the final result data."""
        ...

class DefaultExecutionContext(BaseModel):
    """
    Default implementation of ExecutionContext using Pydantic.
    """
    data: Optional[Any] = Field(default=None, description="The main payload or result data")
    errors: List[BRDDError] = Field(default_factory=list, description="List of business rule violations")
    setters: List[str] = Field(default_factory=list, description="List of state changes applied")
    effects: List[str] = Field(default_factory=list, description="List of events or external effects triggered")
    status: int = Field(default=200, description="HTTP-compatible status code")

    def add_error(self, code: str, message: str) -> None:
        self.errors.append(BRDDError(code=code, message=message))
        self.status = 400

    def add_effect(self, code: str) -> None:
        self.effects.append(code)

    def add_setter(self, code: str) -> None:
        self.setters.append(code)

    def set_data(self, data: Any) -> None:
        self.data = data

    def is_valid(self) -> bool:
        return len(self.errors) == 0

@runtime_checkable
class ValidateService(Protocol):
    """
    Dedicated service for pure business logic validation.
    
    Input must be enriched data. Should never perform I/O.
    """
    def validate(self, context: ValidationContext, input_data: Any) -> None:
        ...

@runtime_checkable
class EnrichService(Protocol):
    """
    Service responsible for gathering data needed for decision making.
    
    Fetches data from DBs, APIs, or other services to prepare the context.
    """
    def enrich(self, context: ExecutionContext, input_data: Any) -> Any:
        ...

@runtime_checkable
class ClientService(Protocol):
    """
    Adapter for external domains to perform side-effects.
    """
    def execute(self, context: ExecutionContext, input_data: Any) -> None:
        ...

@runtime_checkable
class UseCase(Protocol):
    """
    The main orchestrator of a business feature.
    
    Coordinates Enrichment, Validation, and Execution roles.
    Returns a unified ExecutionContext.
    """
    def execute(self, input_data: Any) -> ExecutionContext:
        ...

