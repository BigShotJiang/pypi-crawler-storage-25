# 🐍 BRDD Python

[![PyPI](https://img.shields.io/pypi/v/brdd-python?label=pypi)](https://pypi.org/project/brdd-python/)

A minimalist implementation of the Business Rule Driven Design (BRDD) pattern for the Python ecosystem.

## 🎯 Goal
Provide core interfaces and base classes to implement BRDD with zero friction and maximum type safety.

## 🚀 Installation

```bash
pip install brdd-python
```

## 🛠 Usage

```python
from brdd.core import ExecutionContext, DefaultExecutionContext, ValidationContext

# In your UseCase
def execute(self, request_data) -> ExecutionContext:
    context = DefaultExecutionContext(request_data)
    # ... your logic
    context.add_effect("CE001")
    return context
```

## 🤖 AI-First Development
This library is designed for AI-driven development. Check the [AI Guidelines](./AI_GUIDELINES.md) for more details.

## 📚 Documentation
- [Technical Spec](https://github.com/brdd-design/brdd/blob/main/BRDD.md)
- [Practical Example](https://github.com/brdd-design/brdd/blob/main/core/articles/EN/BRDD-PRACTICAL-EXAMPLE.md)

## 📄 License
MIT
