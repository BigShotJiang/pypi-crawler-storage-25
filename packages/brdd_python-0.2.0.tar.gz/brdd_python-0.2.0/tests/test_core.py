from brdd.core import DefaultExecutionContext, BRDDError

def test_initial_context():
    ctx = DefaultExecutionContext(data={"id": 1})
    assert ctx.data == {"id": 1}
    assert ctx.is_valid() is True
    assert ctx.status == 200
    assert len(ctx.errors) == 0
    assert len(ctx.setters) == 0
    assert len(ctx.effects) == 0

def test_add_error():
    ctx = DefaultExecutionContext(data=None)
    ctx.add_error("R001", "Invalid stock")
    
    assert ctx.is_valid() is False
    assert ctx.status == 400
    assert len(ctx.errors) == 1
    assert ctx.errors[0].code == "R001"
    assert ctx.errors[0].message == "Invalid stock"

def test_add_effect_and_setter():
    ctx = DefaultExecutionContext()
    ctx.add_effect("E001")
    ctx.add_setter("S001")
    
    assert "E001" in ctx.effects
    assert "S001" in ctx.setters

def test_set_data():
    ctx = DefaultExecutionContext()
    assert ctx.data is None
    
    ctx.set_data("new_data")
    assert ctx.data == "new_data"
