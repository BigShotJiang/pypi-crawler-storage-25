# Copyright (c) 2016-2025, Matteo Cafasso
# All rights reserved.

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

# 1. Redistributions of source code must retain the above copyright notice,
# this list of conditions and the following disclaimer.

# 2. Redistributions in binary form must reproduce the above copyright notice,
# this list of conditions and the following disclaimer in the documentation
# and/or other materials provided with the distribution.

# 3. Neither the name of the copyright holder nor the names of its contributors
# may be used to endorse or promote products derived from this software without
# specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
# BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
# OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
# OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
# OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
# EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import clipspyx

from clipspyx.facts import Facts
from clipspyx.agenda import Agenda
from clipspyx.classes import Classes
from clipspyx.modules import Modules
from clipspyx.functions import Functions
from clipspyx.routers import Routers, ErrorRouter
from clipspyx.common import CLIPSError, CLIPS_MAJOR
from clipspyx.common import initialize_environment_data, delete_environment_data
from clipspyx.common import register_environment, unregister_environment

from clipspyx._clipspyx import lib

if CLIPS_MAJOR >= 7:
    from clipspyx.tables import Tables


class Environment:
    """The environment class encapsulates an independent CLIPS engine
    with its own data structures.

    """

    __slots__ = ('_env', '_facts', '_agenda', '_classes',
                 '_modules', '_functions', '_routers', '_tables',
                 '_namespaces', '_dsl_defs', '_ordering_pending',
                 '_tracing_state', '_goal_handler_state',
                 '_fact_events_state', '_periodic_functions',
                 '_sigint_state', '_loop_detection_state',
                 '_runner_ref', '__weakref__')

    def __init__(self):
        self._env = lib.CreateEnvironment()

        initialize_environment_data(self._env)

        self._runner_ref = None
        register_environment(self._env, self)

        self._dsl_defs = []
        self._ordering_pending = {}
        self._tracing_state = None
        self._goal_handler_state = None
        self._fact_events_state = None
        self._periodic_functions = {}
        self._sigint_state = None
        self._loop_detection_state = None

        self._facts = Facts(self._env)
        self._agenda = Agenda(self._env)
        self._classes = Classes(self._env)
        self._modules = Modules(self._env)
        self._functions = Functions(self._env)
        self._routers = Routers(self._env)

        self._routers.add_router(ErrorRouter())

        namespaces = (self._facts,
                      self._agenda,
                      self._classes,
                      self._modules,
                      self._functions,
                      self._routers)

        if CLIPS_MAJOR >= 7:
            self._tables = Tables(self._env)
            namespaces = namespaces + (self._tables,)
        else:
            self._tables = None

        # mapping between the namespace and the methods it exposes
        self._namespaces = {m: n for n in namespaces
                            for m in dir(n) if not m.startswith('_')}

        from clipspyx.meta import enable_meta_templates
        enable_meta_templates(self)

    def __del__(self):
        try:
            unregister_environment(getattr(self, '_env', None))
            if getattr(self, '_loop_detection_state', None) is not None:
                from clipspyx.loops import disable_loop_detection
                disable_loop_detection(self)
            if getattr(self, '_sigint_state', None) is not None:
                from clipspyx.sigint import disable_sigint_handler
                disable_sigint_handler(self)
            delete_environment_data(self._env)
            lib.DestroyEnvironment(self._env)
        except (AttributeError, KeyError, TypeError):
            pass  # mostly happening during interpreter shutdown

    def __getattr__(self, attr):
        try:
            return getattr(self._namespaces[attr], attr)
        except (KeyError, AttributeError):
            raise AttributeError("'%s' object has no attribute '%s'" %
                                 (self.__class__.__name__, attr))

    def __setattr__(self, attr, value):
        if attr in self.__slots__:
            super(Environment, self).__setattr__(attr, value)
            return

        try:
            setattr(self._namespaces[attr], attr, value)
        except (KeyError, AttributeError):
            raise AttributeError("'%s' object has no attribute '%s'" %
                                 (self.__class__.__name__, attr))

    def __dir__(self):
        return dir(self.__class__) + list(self._namespaces.keys())

    def load(self, path: str, binary: bool = False):
        """Load a set of constructs into the CLIPS data base.

        If constructs were saved in binary format,
        the binary parameter should be set to True.

        Equivalent to the CLIPS (load) function.

        """
        if binary:
            if not lib.Bload(self._env, path.encode()):
                raise CLIPSError(self._env)
        else:
            ret = lib.Load(self._env, path.encode())
            if ret != lib.LE_NO_ERROR:
                raise CLIPSError(self._env, code=ret)

    def save(self, path: str, binary=False):
        """Save a set of constructs into the CLIPS data base.

        If binary is True, the constructs will be saved in binary format.

        Equivalent to the CLIPS (load) function.

        """
        if binary:
            ret = lib.Bsave(self._env, path.encode())
        else:
            ret = lib.Save(self._env, path.encode())
        if ret == 0:
            raise CLIPSError(self._env)

    def batch_star(self, path: str):
        """Evaluate the commands contained in the specific path.

        Equivalent to the CLIPS (batch*) function.

        """
        if lib.BatchStar(self._env, path.encode()) != 1:
            raise CLIPSError(self._env)

    def build(self, construct: str):
        """Build a single construct in CLIPS.

        Equivalent to the CLIPS (build) function.

        """
        ret = lib.Build(self._env, construct.encode())
        if ret != lib.BE_NO_ERROR:
            raise CLIPSError(self._env, code=ret)

    def eval(self, expression: str) -> type:
        """Evaluate an expression returning its value.

        Equivalent to the CLIPS (eval) function.

        """
        value = clipspyx.values.clips_value(self._env)

        ret = lib.Eval(self._env, expression.encode(), value)
        if ret != lib.EE_NO_ERROR:
            raise CLIPSError(self._env, code=ret)

        return clipspyx.values.python_value(self._env, value)

    def reset(self):
        """Reset the CLIPS environment.

        Equivalent to the CLIPS (reset) function.

        """
        if lib.Reset(self._env):
            raise CLIPSError(self._env)

    def define(self, cls):
        """Define a DSL template or rule in this environment.

        Accepts classes decorated with ``@template`` or subclassing ``Rule``
        from ``clipspyx.dsl``.

        """
        from clipspyx.dsl.define import define as dsl_define
        return dsl_define(self, cls)

    def visualize(self, output=None, layout='elk', group_by_kind=False):
        """Generate a D2 diagram of defined DSL templates and rules.

        Returns the D2 text as a string. If *output* is given, renders the
        diagram to that file path via the ``d2`` CLI (requires d2 installed).

        *layout* selects the D2 layout engine (default ``'elk'``).

        When *group_by_kind* is ``True``, templates and rules are placed in
        separate sub-containers within each module.

        """
        from clipspyx.dsl.visualize import generate_d2, render_d2
        d2_text = generate_d2(self._dsl_defs, group_by_kind=group_by_kind)
        if output is not None:
            render_d2(d2_text, output, layout=layout)
        return d2_text

    def enable_tracing(self):
        """Enable fact provenance tracking."""
        from clipspyx.tracing import enable_tracing
        enable_tracing(self)

    def disable_tracing(self):
        """Disable fact provenance tracking."""
        from clipspyx.tracing import disable_tracing
        disable_tracing(self)

    def enable_fact_events(self):
        """Enable fact lifecycle event meta-facts."""
        from clipspyx.fact_events import enable_fact_events
        enable_fact_events(self)

    def disable_fact_events(self):
        """Disable fact lifecycle event meta-facts."""
        from clipspyx.fact_events import disable_fact_events
        disable_fact_events(self)

    def enable_goal_handlers(self):
        """Enable async goal handler framework (CLIPS 7.0+ only)."""
        from clipspyx.async_goals import enable_goal_handlers
        enable_goal_handlers(self)

    def disable_goal_handlers(self):
        """Disable async goal handler framework."""
        from clipspyx.async_goals import disable_goal_handlers
        disable_goal_handlers(self)

    def register_goal_handler(self, template, handler):
        """Register an async handler for goals matching a template.

        template can be a DSL Template class or a CLIPS template name string.
        """
        from clipspyx.async_goals import register_goal_handler
        register_goal_handler(self, template, handler)

    def halt_async(self):
        """Signal the async run loop to stop after the current cycle."""
        state = self._goal_handler_state
        if state is not None:
            state.halted = True

    def async_runner(self):
        """Create an AsyncRunner for this environment."""
        from clipspyx.async_goals import AsyncRunner
        return AsyncRunner(self)

    # -- periodic functions --

    def add_periodic_function(self, name, callback, priority=0):
        """Register a callback invoked periodically during rule execution.

        The callback receives ``(env,)`` as its single argument and must
        not modify CLIPS data structures (read-only access only).

        """
        from clipspyx.periodic import add_periodic_function
        add_periodic_function(self, name, callback, priority)

    def remove_periodic_function(self, name):
        """Remove a previously registered periodic callback."""
        from clipspyx.periodic import remove_periodic_function
        remove_periodic_function(self, name)

    # -- SIGINT handling --

    def enable_sigint_handler(self):
        """Enable opt-in Ctrl-C (SIGINT) handling for ``run()``.

        When enabled, pressing Ctrl-C during ``env.run()`` gracefully
        halts CLIPS rule execution and raises ``KeyboardInterrupt``.
        """
        from clipspyx.sigint import enable_sigint_handler
        enable_sigint_handler(self)

    def disable_sigint_handler(self):
        """Disable SIGINT handling for ``run()``."""
        from clipspyx.sigint import disable_sigint_handler
        disable_sigint_handler(self)

    def sigint_handler(self):
        """Context manager for scoped SIGINT handling.

        Usage::

            with env.sigint_handler():
                env.run()
        """
        from clipspyx.sigint import sigint_handler
        return sigint_handler(self)

    # -- Loop detection --

    def enable_loop_detection(self, threshold=3):
        """Enable causal loop detection for ``run()``.

        Uses transitive closure of ``RuleFiring`` provenance to detect
        cycles.  Raises ``RuleLoopError`` when a rule in a detected
        cycle fires more than *threshold* times.

        Requires tracing to be enabled first.
        """
        from clipspyx.loops import enable_loop_detection
        enable_loop_detection(self, threshold=threshold)

    def disable_loop_detection(self):
        """Disable loop detection for ``run()``."""
        from clipspyx.loops import disable_loop_detection
        disable_loop_detection(self)

    def clear(self):
        """Clear the CLIPS environment.

        Equivalent to the CLIPS (clear) function.

        """
        if not lib.Clear(self._env):
            raise CLIPSError(self._env)
        self._dsl_defs = []
        self._ordering_pending = {}
