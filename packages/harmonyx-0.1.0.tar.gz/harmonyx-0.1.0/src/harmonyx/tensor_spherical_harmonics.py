"""Implements the Tensor Spherical Harmonics (TSH) and Tensor Spherical Tensor Product (TSTP)."""

import jax
import jax.numpy as jnp
import numpy as np
import e3nn_jax as e3nn
import functools


@jax.tree_util.register_pytree_node_class
class TensorSphericalHarmonics:
    """Coefficients for the tensor spherical harmonics: lmax refers to the maximum degree l of the TSH which transforms as s x l."""

    def __init__(self, coeffs: e3nn.IrrepsArray, s: int, lmax: int, parity: int = 1):
        if parity not in [1]:
            raise ValueError(f"Invalid parity {parity}.")

        # Check that the irreps are valid.
        expected_irreps = TensorSphericalHarmonics.get_irreps(
            s=s, lmax=lmax, parity=parity
        )
        if coeffs.irreps != expected_irreps:
            raise ValueError(
                f"Invalid irreps {coeffs.irreps}, expected {expected_irreps}."
            )

        self.coeffs = coeffs
        self.s = s
        self.lmax = lmax
        self.parity = parity

    @property
    def shape(self):
        return self.coeffs.shape

    @property
    def irreps(self):
        return self.coeffs.irreps

    def __repr__(self):
        tsh_type = "TSH Coefficients"
        lines = [f"{tsh_type}"]
        for irrep, chunk in zip(self.coeffs.irreps, self.coeffs.chunks):
            lines.append(f" {irrep}: {chunk}")
        return "\n".join(lines)

    @classmethod
    def get_irreps(cls, *, s: int, lmax: int, parity: int) -> e3nn.Irreps:
        """Returns the irreps for the TSH upto some lmax."""
        return cls.get_change_of_basis_matrix(s=s, lmax=lmax, parity=parity).irreps

    @classmethod
    def zeros(cls, *, s: int, lmax: int, parity: int) -> "TensorSphericalHarmonics":
        """Creates a dictionary of all-zeros coefficients for each TSH."""
        return cls(
            e3nn.zeros(cls.get_irreps(s=s, lmax=lmax, parity=parity)),
            s=s,
            lmax=lmax,
            parity=parity,
        )

    @classmethod
    def normal(
        cls, *, s: int, lmax: int, parity: int, key: jax.random.PRNGKey
    ) -> "TensorSphericalHarmonics":
        """Creates a dictionary of random normal coefficients for each TSH."""
        return cls(
            e3nn.normal(cls.get_irreps(s=s, lmax=lmax, parity=parity), key),
            s=s,
            lmax=lmax,
            parity=parity,
        )

    def rotate(self, R: jnp.ndarray) -> "TensorSphericalHarmonics":
        """Rotates the VSH coefficients by a rotation matrix R."""
        rotated_coeffs = self.coeffs.transform_by_matrix(R)
        return TensorSphericalHarmonics(
            rotated_coeffs, s=self.s, lmax=self.lmax, parity=self.parity
        )

    def to_xyz_coeffs(self) -> e3nn.IrrepsArray:
        """Converts a dictionary of TSH coefficients to a 3D IrrepsArray."""
        rtp = self.get_change_of_basis_matrix(
            s=self.s, lmax=self.lmax, parity=self.parity
        )
        xyz_coeffs = jnp.einsum("ijk,k->ij", rtp.array, self.coeffs.array)
        xyz_coeffs = e3nn.IrrepsArray(
            e3nn.s2_irreps(self.lmax, p_arg=1, p_val=1), xyz_coeffs
        )
        return xyz_coeffs

    def at_points(self, points: jnp.ndarray) -> e3nn.IrrepsArray:
        """Evaluates the TSH at a given set of points (given in x, y, z, will be normalized to unit norm) on the sphere."""
        xyz_coeffs = self.to_xyz_coeffs()
        points = e3nn.IrrepsArray("1e", points)
        values = e3nn.to_s2point(xyz_coeffs, points, normalization="integral").array
        values = values.squeeze(-1)
        values = jnp.moveaxis(values, 0, -1)
        return e3nn.IrrepsArray(e3nn.Irrep(self.s, p=1), values)

    def to_tensor_signal(
        self, res_beta: int, res_alpha: int, quadrature: str
    ) -> e3nn.SphericalSignal:
        """Converts a dictionary of TSH coefficients to a tensor spherical signal with leading dimension [2s + 1]."""
        xyz_coeffs = self.to_xyz_coeffs()
        tensor_sig = e3nn.to_s2grid(
            xyz_coeffs,
            res_beta=res_beta,
            res_alpha=res_alpha,
            quadrature=quadrature,
            p_val=1,
            p_arg=1,
            fft=False,
            normalization="integral",
        )
        return tensor_sig

    @classmethod
    def from_tensor_signal(
        cls, sig: e3nn.SphericalSignal, s: int, lmax: int, parity: int = 1
    ) -> "TensorSphericalHarmonics":
        """Returns the coefficients of the TSH in the signal sig."""
        xyz_coeffs = e3nn.from_s2grid(
            sig, irreps=e3nn.s2_irreps(lmax, p_arg=1, p_val=1), fft=False, normalization="integral"
        )
        rtp = cls.get_change_of_basis_matrix(s=s, lmax=lmax, parity=parity)
        tsh_coeffs = e3nn.IrrepsArray(
            rtp.irreps, jnp.einsum("ijk,ij->k", rtp.array, xyz_coeffs.array)
        )
        return cls(tsh_coeffs, s=s, lmax=lmax, parity=parity)

    def coefficient_index(self, l: int, j: int, mj: int) -> int:
        """Return the flat index for a given (l, j, mj)."""
        if l < 0 or l > self.lmax:
            raise ValueError(f"l={l} out of range [0, {self.lmax}].")
        if j not in range(abs(l - self.s), l + self.s + 1):
            raise ValueError(f"j={j} invalid for l={l}, s={self.s}.")
        if mj not in range(-j, j + 1):
            raise ValueError(f"mj={mj} invalid for j={j}.")

        idx = 0
        for l_dash in range(self.lmax + 1):
            for j_dash in range(abs(l_dash - self.s), l_dash + self.s + 1):
                if l_dash == l and j_dash == j:
                    return idx + j + mj
                idx += 2 * j_dash + 1

        raise RuntimeError("Should not reach here.")

    def get_coefficient(self, *, l: int, j: int, mj: int) -> float:
        """Returns the coefficient for a given (l, j, mj)."""
        idx = self.coefficient_index(l, j, mj)
        return self.coeffs.array[idx]

    def set_coefficient(self, *, l: int, j: int, mj: int, value: float) -> "TensorSphericalHarmonics":
        """Returns a new TensorSphericalHarmonics with the coefficient for (l, j, mj) set to value."""
        idx = self.coefficient_index(l, j, mj)
        new_array = self.coeffs.array.at[idx].set(value)
        return TensorSphericalHarmonics(
            e3nn.IrrepsArray(self.coeffs.irreps, new_array),
            s=self.s,
            lmax=self.lmax,
            parity=self.parity,
        )

    def get_coefficients(self, *, l: int, j: int) -> jnp.ndarray:
        """Returns all coefficients for a given (l, j)."""
        idx = self.coefficient_index(l, j, -j)
        return self.coeffs.array[idx:idx + 2 * j + 1]

    def set_coefficients(self, *, l: int, j: int, values: jnp.ndarray) -> "TensorSphericalHarmonics":
        """Returns a new TensorSphericalHarmonics with the coefficients for (l, j) set to values."""
        if values.shape != (2 * j + 1,):
            raise ValueError(f"values should have shape {(2 * j + 1,)}, got {values.shape}.")
        idx = self.coefficient_index(l, j, -j)
        new_array = self.coeffs.array.at[idx:idx + 2 * j + 1].set(values)
        return TensorSphericalHarmonics(
            e3nn.IrrepsArray(self.coeffs.irreps, new_array),
            s=self.s,
            lmax=self.lmax,
            parity=self.parity,
        )

    @classmethod
    def tensor_spherical_harmonic(
        cls, *, s: int, l: int, j: int, mj: int, parity: int = 1
    ) -> "TensorSphericalHarmonics":
        """Returns a tensor spherical harmonic for a given (s, l, j, mj)."""
        tsh = cls.zeros(s=s, lmax=l, parity=parity)
        idx = tsh.coefficient_index(l, j, mj)
        new_array = tsh.coeffs.array.at[idx].set(1.0)
        return cls(
            e3nn.IrrepsArray(tsh.irreps, new_array),
            s=s, lmax=l, parity=parity,
        )

    def reduce_pointwise_tensor_product(
        self,
        other: "TensorSphericalHarmonics",
        *,
        s_out: int,
        res_beta: int,
        res_alpha: int,
        quadrature: str,
    ) -> "TensorSphericalHarmonics":
        """Computes the pointwise tensor product on the sphere, and converts back to TSH coefficients."""

        # Convert both TSH to signals
        self_sig = self.to_tensor_signal(res_beta, res_alpha, quadrature)
        other_sig = other.to_tensor_signal(res_beta, res_alpha, quadrature)

        # Move s dimension to the end for compatibility with e3nn.irreps
        self_val = self_sig.grid_values.transpose(1, 2, 0)
        self_sig_fake = e3nn.IrrepsArray(e3nn.Irrep(self.s, p=1), self_val)
        other_val = other_sig.grid_values.transpose(1, 2, 0)
        other_sig_fake = e3nn.IrrepsArray(e3nn.Irrep(other.s, p=1), other_val)

        # Perform the tensor product using the e3nn tensor_product
        prod_sig_fake = e3nn.tensor_product(
            self_sig_fake, other_sig_fake, filter_ir_out=e3nn.Irrep(s_out, p=1)
        )

        # Convert the result back to a SphericalSignal
        prod_sig = self_sig.replace_values(prod_sig_fake.array.transpose(2, 0, 1))

        return TensorSphericalHarmonics.from_tensor_signal(
            prod_sig,
            s=s_out,
            lmax=self.lmax + other.lmax,
            parity=self.parity * other.parity,
        )

    @classmethod
    @functools.lru_cache(maxsize=None)
    def get_change_of_basis_matrix(
        cls, *, s: int, lmax: int, parity: int
    ) -> e3nn.IrrepsArray:
        """Returns the change of basis matrix."""
        full_basis_np = np.zeros(
            (2 * s + 1, (lmax + 1) ** 2, (2 * s + 1) * (lmax + 1) ** 2)
        )
        full_basis_irreps = ""
        for l in range(lmax + 1):
            basis = e3nn.reduced_tensor_product_basis(
                "ij",
                i=e3nn.Irrep(s, p=1),
                j=e3nn.Irrep(l, p=1),
            )
            full_basis_np[
                :,
                l**2 : (l + 1) ** 2,
                (2 * s + 1) * (l**2) : (2 * s + 1) * ((l + 1) ** 2),
            ] = basis.array
            full_basis_irreps += basis.irreps

        full_basis_jnp = jnp.asarray(full_basis_np)
        full_basis_irreps = e3nn.Irreps(full_basis_irreps)
        full_basis = e3nn.IrrepsArray(full_basis_irreps, full_basis_jnp)
        return full_basis

    def tree_flatten(self):
        return (self.coeffs,), (self.s, self.lmax, self.parity)

    @classmethod
    def tree_unflatten(cls, aux_data, children):
        s, lmax, parity = aux_data
        return cls(children[0], s=s, lmax=lmax, parity=parity)

    def plot(
        self,
        dims: tuple[int, int, int] = (0, 1, 2),
        res_beta: int = 100,
        res_alpha: int = 99,
        quadrature: str = "gausslegendre",
        size_ref: float = 0.1,
    ):
        """Plot the tensor signal as arrows on a sphere."""
        try:
            import plotly.graph_objects as go
        except ImportError:
            raise ImportError(
                "Plotting requires plotly. Please install it with `pip install plotly nbformat>=4.2.0`."
            )

        dims = np.asarray(dims)
        if len(dims) != 3:
            raise ValueError(f"dims must have exactly 3 elements, got {len(dims)}.")
        
        # Convert to tensor signal and extract grid vectors and values
        tensor_signal = self.to_tensor_signal(res_beta, res_alpha, quadrature)
        n_components = tensor_signal.shape[0]
        
        for d in dims:
            if d < 0 or d >= n_components:
                raise ValueError(
                    f"dim {d} out of range for s={self.s} ({n_components} components)."
                )

        grid_vectors = tensor_signal.grid_vectors
        grid_values = tensor_signal.grid_values[dims]

        n_dim, res_beta, res_alpha = grid_values.shape
        assert n_dim == 3, (
            f"Expected grid_values to have first dimension=3 for 3D vectors; got first dimension={n_dim}"
        )

        assert grid_vectors.shape == (res_beta, res_alpha, 3), (
            f"Expected grid_vectors to have shape ({res_beta}, {res_alpha}, 3)"
        )
        x, y, z = (
            grid_vectors[:, :, 0],
            grid_vectors[:, :, 1],
            grid_vectors[:, :, 2],
        )

        assert grid_values.shape == (3, res_beta, res_alpha), (
            f"Expected grid_values to have shape (3, {res_beta}, {res_alpha})"
        )
        u, v, w = (
            grid_values[0],
            grid_values[1],
            grid_values[2],
        )

        fig = go.Figure(
            data=go.Cone(
                x=x.flatten(),
                y=y.flatten(),
                z=z.flatten(),
                u=u.flatten(),
                v=v.flatten(),
                w=w.flatten(),
                sizemode="raw",
                sizeref=size_ref,
                colorscale="RdBu",
                anchor="tail",
            )
        )
        fig.update_layout(title="Tensor Field on Sphere", scene=dict(aspectmode="data"))
        return fig

    def plot_intensity(
        self,
        res_beta: int = 100,
        res_alpha: int = 99,
        quadrature: str = "gausslegendre",
        colorscale: str = "Hot",
    ):
        """Plot the total intensity |T|^2 as a heatmap on the sphere."""
        try:
            import plotly.graph_objects as go
        except ImportError:
            raise ImportError(
                "Plotting requires plotly. Install with `pip install plotly nbformat>=4.2.0`."
            )

        signal = self.to_tensor_signal(res_beta, res_alpha, quadrature)
        intensity = jnp.sum(signal.grid_values**2, axis=0)

        x = signal.grid_vectors[:, :, 0]
        y = signal.grid_vectors[:, :, 1]
        z = signal.grid_vectors[:, :, 2]

        fig = go.Figure(
            data=go.Surface(
                x=x,
                y=y,
                z=z,
                surfacecolor=np.array(intensity),
                colorscale=colorscale,
                colorbar=dict(title="|T|²"),
            )
        )
        fig.update_layout(
            title=f"Intensity on Sphere",
            scene=dict(aspectmode="data"),
        )
        return fig