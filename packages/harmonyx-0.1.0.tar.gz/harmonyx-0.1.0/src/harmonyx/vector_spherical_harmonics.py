"""Implements the Vector Spherical Harmonics (VSH) and Vector Spherical Tensor Product (VSTP)."""

import jax
import jax.numpy as jnp
import numpy as np
import e3nn_jax as e3nn

from .tensor_spherical_harmonics import TensorSphericalHarmonics


@jax.tree_util.register_pytree_node_class
class VectorSphericalHarmonics(TensorSphericalHarmonics):
    """VSH: TSH with s=1 fixed."""

    def __init__(self, coeffs: e3nn.IrrepsArray, lmax: int, parity: int = 1):
        super().__init__(coeffs, s=1, lmax=lmax, parity=parity)

    @classmethod
    def get_irreps(cls, *, lmax: int, parity: int) -> e3nn.Irreps:
        return TensorSphericalHarmonics.get_irreps(s=1, lmax=lmax, parity=parity)

    @classmethod
    def zeros(cls, *, lmax: int, parity: int) -> "VectorSphericalHarmonics":
        return cls(
            e3nn.zeros(cls.get_irreps(lmax=lmax, parity=parity)),
            lmax=lmax,
            parity=parity,
        )

    @classmethod
    def normal(cls, *, lmax: int, parity: int, key) -> "VectorSphericalHarmonics":
        return cls(
            e3nn.normal(cls.get_irreps(lmax=lmax, parity=parity), key),
            lmax=lmax,
            parity=parity,
        )

    @classmethod
    def vector_spherical_harmonic(
        cls, *, l: int, j: int, mj: int, parity: int = 1
    ) -> "VectorSphericalHarmonics":
        tsh = TensorSphericalHarmonics.tensor_spherical_harmonic(
            s=1, l=l, j=j, mj=mj, parity=parity
        )
        return cls(tsh.coeffs, lmax=l, parity=parity)

    @classmethod
    def from_tensor_signal(cls, sig: e3nn.SphericalSignal, lmax: int, parity: int = 1):
        return super().from_tensor_signal(sig, s=1, lmax=lmax, parity=parity)

    def rotate(self, R: jnp.ndarray) -> "VectorSphericalHarmonics":
        result = super().rotate(R)
        return VectorSphericalHarmonics(
            result.coeffs, lmax=self.lmax, parity=self.parity
        )

    def set_coefficient(self, *, l: int, j: int, mj: int, value: float) -> "VectorSphericalHarmonics":
        result = super().set_coefficient(l=l, j=j, mj=mj, value=value)
        return VectorSphericalHarmonics(result.coeffs, lmax=self.lmax, parity=self.parity)

    def set_coefficients(self, *, l: int, j: int, values: jnp.ndarray) -> "VectorSphericalHarmonics":
        result = super().set_coefficients(l=l, j=j, values=values)
        return VectorSphericalHarmonics(result.coeffs, lmax=self.lmax, parity=self.parity)

    def tree_flatten(self):
        return (self.coeffs,), (self.lmax, self.parity)

    @classmethod
    def tree_unflatten(cls, aux_data, children):
        lmax, parity = aux_data
        return cls(children[0], lmax=lmax, parity=parity)

    def reduce_pointwise_cross_product(
        self,
        other: "VectorSphericalHarmonics",
        res_beta: int,
        res_alpha: int,
        quadrature: str = "gausslegendre",
    ) -> "VectorSphericalHarmonics":
        """Computes the pointwise cross product on the sphere, and converts back to VSH coefficients."""
        tsh = self.reduce_pointwise_tensor_product(
            other,
            s_out=1,
            res_beta=res_beta,
            res_alpha=res_alpha,
            quadrature=quadrature,
        )
        return VectorSphericalHarmonics(tsh.coeffs, lmax=tsh.lmax, parity=tsh.parity)
