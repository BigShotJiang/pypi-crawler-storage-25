import jax
import jax.numpy as jnp
import numpy as np
import e3nn_jax as e3nn
import pytest

from harmonyx import TensorSphericalHarmonics


@pytest.mark.parametrize("s", [0, 1, 2, 3])
@pytest.mark.parametrize("lmax", [0, 1, 2, 3])
@pytest.mark.parametrize("seed", [0, 1, 2, 3, 4])
def test_at_points_matches_grid_values(seed, s, lmax):
    tsh_key, beta_key, alpha_key = jax.random.split(jax.random.PRNGKey(seed), 3)

    res_beta = 2 * (lmax + s + 1)
    res_alpha = 2 * (lmax + s + 1) - 1
    quadrature = "gausslegendre"

    true_tsh = TensorSphericalHarmonics.normal(s=s, lmax=lmax, parity=1, key=tsh_key)
    true_signal = true_tsh.to_tensor_signal(res_beta, res_alpha, quadrature)

    max_points_to_test = 100
    random_indices_beta = jax.random.choice(beta_key, res_beta, shape=(min(int(np.sqrt(max_points_to_test)), res_beta),), replace=False)
    random_indices_alpha = jax.random.choice(alpha_key, res_alpha, shape=(min(int(np.sqrt(max_points_to_test)), res_alpha),), replace=False)

    for i in random_indices_beta:
        for j in random_indices_alpha:
            point = true_signal.grid_vectors[i, j]
            value = true_tsh.at_points(point).array
            expected = true_signal.grid_values[:, i, j]

            diff = jnp.linalg.norm(value - expected)
            assert jnp.allclose(value, expected, atol=2e-5), f"Mismatch at point {point}: value={value}, expected={expected}, diff={diff}"