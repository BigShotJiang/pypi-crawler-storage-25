import jax
import jax.numpy as jnp
import numpy as np
import e3nn_jax as e3nn
import pytest

from harmonyx import VectorSphericalHarmonics


def triangle_rule(a: int, b: int, c: int) -> bool:
    """Checks if the triangle rule is satisfied for (a, b, c)."""
    for first, second, third in [(a, b, c), (b, c, a), (c, a, b)]:
        if not (abs(first - second) <= third <= first + second):
            return False

    return True


def antisymmetry_rule(l1: int, j1: int, l2: int, j2: int, l3: int, j3: int) -> bool:
    """Checks the antisymmetry rule for the given (l1, j1), (l2, j2), and (l3, j3)."""
    ls = [l1, l2, l3]
    js = [j1, j2, j3]
    for a, b, c in [(0, 1, 2), (1, 2, 0), (2, 0, 1), (0, 2, 1), (2, 1, 0), (1, 0, 2)]:
        if (js[a] == ls[a]) and (js[b] == js[c]) and (ls[b] == ls[c]):
            return False
    return True


@pytest.mark.parametrize("seed", [0, 1])
@pytest.mark.parametrize("l1", [0, 1, 2, 3, 4])
@pytest.mark.parametrize("l2", [0, 1, 2, 3, 4])
def test_vstp_selection_rules(seed, l1, l2):
    j1_key, j2_key, x_key, y_key, beta_key, alpha_key = jax.random.split(jax.random.PRNGKey(seed), 6)

    res_beta = 100
    res_alpha = 99
    quadrature = "gausslegendre"

    # Sample j1 from [|l1 - 1|, l1 + 1] and j2 from [|l2 - 1|, l2 + 1]
    j1 = jax.random.randint(j1_key, (), minval=abs(l1 - 1), maxval=l1 + 2)
    j2 = jax.random.randint(j2_key, (), minval=abs(l2 - 1), maxval=l2 + 2)

    # Make random VSHs with the specified (l1, j1) and (l2, j2)
    x = VectorSphericalHarmonics.zeros(lmax=l1, parity=1)
    x = x.set_coefficients(
        l=l1, j=j1, values=jax.random.normal(x_key, (2 * j1 + 1,))
    )

    y = VectorSphericalHarmonics.zeros(lmax=l2, parity=1)
    y = y.set_coefficients(
        l=l2, j=j2, values=jax.random.normal(y_key, (2 * j2 + 1,))
    )

    # Compute the pointwise cross product
    z = x.reduce_pointwise_cross_product(
        y, res_beta=res_beta, res_alpha=res_alpha, quadrature=quadrature
    )

    for l3 in range(l1 + l2 + 1):  # l3 can range from 0 to l1 + l2
        for j3 in range(abs(l3 - 1), l3 + 2):  # j3 can range from |l3 - 1| to l3 + 1
            coeffs = jnp.asarray([z.get_coefficient(l=l3, j=j3, mj=mj3) for mj3 in range(-j3, j3 + 1)])
    
            if not triangle_rule(l1, l2, l3):
                assert jnp.allclose(coeffs, 0.0, atol=1e-5), f"Coefficient for (l3={l3}, j3={j3}) should be zero due to triangle rule, but got {coeffs}"
                continue

            if not triangle_rule(j1, j2, j3):
                assert jnp.allclose(coeffs, 0.0, atol=1e-5), f"Coefficient for (l3={l3}, j3={j3}) should be zero due to triangle rule, but got {coeffs}"
                continue

            if not (l1 + l2 + l3) % 2 == 0:
                assert jnp.allclose(coeffs, 0.0, atol=1e-5), f"Coefficient for (l3={l3}, j3={j3}) should be zero due to parity rule, but got {coeffs}"
                continue

            if not antisymmetry_rule(l1, j1, l2, j2, l3, j3):
                assert jnp.allclose(coeffs, 0.0, atol=1e-5), f"Coefficient for (l3={l3}, j3={j3}) should be zero due to weird equality rule, but got {coeffs}"
                continue

            # Otherwise, some coefficients should be non-zero
            assert not jnp.isclose(coeffs, 0.0, atol=1e-5).all(), f"Coefficient for (l3={l3}, j3={j3}) should be non-zero, but got {coeffs}" 
