import jax
import jax.numpy as jnp
import e3nn_jax as e3nn
import pytest

from harmonyx import TensorSphericalHarmonics, VectorSphericalHarmonics


@pytest.mark.parametrize("s", [0, 1, 2, 3])
@pytest.mark.parametrize("lmax", [0, 1, 2, 3])
@pytest.mark.parametrize("seed", [0, 1, 2, 3, 4])
def test_roundtrip_coeffs_to_signal_and_back(seed, s, lmax):
    key = jax.random.PRNGKey(seed)

    res_beta = 2 * (lmax + s + 1)
    res_alpha = 2 * (lmax + s + 1) - 1
    quadrature = "gausslegendre"

    original = TensorSphericalHarmonics.normal(s=s, lmax=lmax, parity=1, key=key)
    signal = original.to_tensor_signal(res_beta, res_alpha, quadrature)
    reconstructed = TensorSphericalHarmonics.from_tensor_signal(signal, s=s, lmax=lmax, parity=1)

    diff = jnp.linalg.norm(original.coeffs.array - reconstructed.coeffs.array)
    assert jnp.allclose(original.coeffs.array, reconstructed.coeffs.array, atol=1e-5), f"Roundtrip failed: difference = {diff}"