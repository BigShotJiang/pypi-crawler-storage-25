import os
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Tuple, Optional

import click
from rich.console import Console
from rich.tree import Tree

DEFAULT_INCLUDED = {".md", ".py", ".ts", ".js"}
DEFAULT_EXCLUDED = {
    ".DS_Store",
    ".pyc",
    ".idea",
    ".git",
    ".nuxt",
    ".gitignore",
    "node_modules",
    "__pycache__",
    "dist",
    "build",
    "coverage",
    ".mypy_cache",
    ".pytest_cache",
    ".venv",
    "venv",
}


class LastModScanner:
    """
    Expert scanner that finds the 'champion' (latest) file in any subtree.
    """

    def __init__(
        self,
        include: Tuple[str, ...],
        exclude: Tuple[str, ...],
        max_level: Optional[int],
        days: Optional[int],
    ):
        self.include = set(include) | DEFAULT_INCLUDED
        self.exclude = set(exclude) | DEFAULT_EXCLUDED
        self.max_level = max_level
        self.threshold_dt = (
            datetime.now() - timedelta(days=days) if days is not None else None
        )

    def should_exclude(self, path: Path) -> bool:
        for pattern in self.exclude:
            if pattern in path.name or re.search(pattern, path.name):
                return True
        return False

    def is_included_file(self, path: Path) -> bool:
        if not path.is_file() or self.should_exclude(path):
            return False
        for pattern in self.include:
            if pattern in path.name or path.suffix == pattern:
                return True
        return False

    def find_latest_recursive(self, directory: Path) -> Tuple[Optional[Path], float]:
        latest_file = None
        latest_mtime = -1.0
        try:
            for entry in directory.rglob("*"):
                if any(
                    self.should_exclude(p)
                    for p in entry.parents
                    if p != directory.parent
                ):
                    continue
                if self.is_included_file(entry):
                    mtime = entry.stat().st_mtime
                    if mtime > latest_mtime:
                        latest_mtime = mtime
                        latest_file = entry
                    elif mtime == latest_mtime:
                        if latest_file is None or entry.name < latest_file.name:
                            latest_file = entry
        except (PermissionError, FileNotFoundError):
            pass
        return latest_file, latest_mtime


def build_tree(
    current_path: Path, scanner: LastModScanner, tree_node: Tree, current_level: int
):
    """Recursively builds tree where labels represent subtree high-water marks."""
    latest_file, mtime = scanner.find_latest_recursive(current_path)
    if latest_file:
        file_dt = datetime.fromtimestamp(mtime)
        style = "bold cyan"
        if scanner.threshold_dt and file_dt < scanner.threshold_dt:
            style = "bold red"

        rel_path = latest_file.relative_to(current_path)
        timestamp_str = file_dt.strftime("%Y-%m-%d %H:%M:%S")
        tree_node.label = f"{tree_node.label} [{style}][{timestamp_str}][/{style}] [green]{rel_path}[/green]"

    if scanner.max_level is not None and current_level >= scanner.max_level:
        return

    try:
        subdirs = sorted(
            [d for d in current_path.iterdir() if d.is_dir()],
            key=lambda x: x.name.lower(),
        )
        for subdir in subdirs:
            if scanner.should_exclude(subdir):
                continue
            branch = tree_node.add(f"[bold blue]{subdir.name}[/bold blue]")
            build_tree(subdir, scanner, branch, current_level + 1)
    except PermissionError:
        tree_node.add("[red]Permission Denied[/red]")


@click.command()
@click.argument("directory_path", type=str, default=".")
@click.option("--exclude", "-e", multiple=True)
@click.option("--include", "-i", multiple=True)
@click.option("--level", "-l", type=int)
@click.option("--days", "-d", type=int)
def main(directory_path, exclude, include, level, days):
    """Find the latest modified file for every folder in the tree."""
    path_obj = Path(directory_path).expanduser().resolve()
    if not path_obj.exists():
        click.echo(f"Error: Path '{directory_path}' does not exist.", err=True)
        raise click.Abort()

    exc = []
    for s in exclude:
        exc.extend(s.split())
    inc = []
    for s in include:
        inc.extend(s.split())

    scanner = LastModScanner(tuple(inc), tuple(exc), level, days)

    # FIX: Use Rich's default detection, but allow override for tests
    force_color = os.getenv("FORCE_COLOR")
    if force_color == "1":
        console = Console(force_terminal=True)
    elif force_color == "0":
        console = Console(force_terminal=False)
    else:
        # Default behavior: Rich detects if terminal supports color
        console = Console()

    tree = Tree(f"[bold yellow]{path_obj}[/bold yellow]")
    build_tree(path_obj, scanner, tree, 0)
    console.print(tree)


if __name__ == "__main__":
    main()
