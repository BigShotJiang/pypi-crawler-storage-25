"""
Module entrypoint for `python -m lastmod`.
"""

from .main import main

if __name__ == "__main__":
    main()