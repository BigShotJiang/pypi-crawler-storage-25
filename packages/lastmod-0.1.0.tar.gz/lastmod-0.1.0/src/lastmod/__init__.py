def main() -> None:
    print("Hello from lastmod!")
