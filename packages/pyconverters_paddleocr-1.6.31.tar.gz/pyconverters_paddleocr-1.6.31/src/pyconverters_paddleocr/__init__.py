"""Convert PDF to structured text using PaddleOCR"""

__version__ = "1.6.31"
