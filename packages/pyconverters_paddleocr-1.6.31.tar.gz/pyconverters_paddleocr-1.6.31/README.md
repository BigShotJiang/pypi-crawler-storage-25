# pyconverters_paddleocr

[![license](https://img.shields.io/github/license/oterrier/pyconverters_paddleocr)](https://github.com/oterrier/pyconverters_paddleocr/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyconverters_paddleocr/workflows/tests/badge.svg)](https://github.com/oterrier/pyconverters_paddleocr/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyconverters_paddleocr)](https://codecov.io/gh/oterrier/pyconverters_paddleocr)
[![docs](https://img.shields.io/readthedocs/pyconverters_paddleocr)](https://pyconverters_paddleocr.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyconverters_paddleocr)](https://pypi.org/project/pyconverters_paddleocr/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyconverters_paddleocr)](https://pypi.org/project/pyconverters_paddleocr/)

Convert PDF to structured text using [PaddleOCR](https://github.com/kermitt2/paddleocr)

## Installation

You can simply `pip install pyconverters_paddleocr`.

## Developing

### Pre-requisites

You will need to install `uv` (for package management and building):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyconverters_paddleocr
```

### Install dependencies

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
