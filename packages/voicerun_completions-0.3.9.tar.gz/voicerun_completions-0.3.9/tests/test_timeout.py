"""
Integration tests for the timeout parameter of ChatCompletionRequest.

Each test sends a real API request with an impossibly short timeout (10 ms)
and asserts that the library raises a TimeoutError for that provider.
"""

import pytest

from voicerun_completions import generate_chat_completion
from voicerun_completions.types.errors import TimeoutError


SHORT_TIMEOUT = 0.01  # 10 ms — no API call can complete this fast


@pytest.mark.integration
async def test_timeout_openai(openai_api_key):
    with pytest.raises(TimeoutError) as exc_info:
        await generate_chat_completion({
            "provider": "openai",
            "api_key": openai_api_key,
            "model": "gpt-4o-mini",
            "max_tokens": 1,
            "timeout": SHORT_TIMEOUT,
            "messages": [{"role": "user", "content": "Hi"}],
        })
    assert exc_info.value.provider == "openai"


@pytest.mark.integration
async def test_timeout_anthropic(anthropic_api_key):
    with pytest.raises(TimeoutError) as exc_info:
        await generate_chat_completion({
            "provider": "anthropic",
            "api_key": anthropic_api_key,
            "model": "claude-haiku-4-5",
            "max_tokens": 1,
            "timeout": SHORT_TIMEOUT,
            "messages": [{"role": "user", "content": "Hi"}],
        })
    assert exc_info.value.provider == "anthropic"


@pytest.mark.integration
async def test_timeout_google(gemini_api_key):
    with pytest.raises(TimeoutError) as exc_info:
        await generate_chat_completion({
            "provider": "google",
            "api_key": gemini_api_key,
            "model": "gemini-2.0-flash",
            "max_tokens": 1,
            "timeout": SHORT_TIMEOUT,
            "messages": [{"role": "user", "content": "Hi"}],
        })
    assert exc_info.value.provider == "google"


@pytest.mark.integration
async def test_timeout_alibaba(dashscope_api_key):
    with pytest.raises(TimeoutError) as exc_info:
        await generate_chat_completion({
            "provider": "alibaba",
            "api_key": dashscope_api_key,
            "model": "qwen3.5-plus",
            "max_tokens": 1,
            "timeout": SHORT_TIMEOUT,
            "messages": [{"role": "user", "content": "Hi"}],
        })
    assert exc_info.value.provider == "alibaba"
