"""Integration tests: Google tool call IDs must be valid strings.

Regression test for a bug where the non-streaming Google client passed
``part.function_call.id`` straight through without a fallback. When Gemini
returns ``None`` for the ID the normalized ``ToolCall.id`` becomes ``None``,
which causes a 400 from Anthropic when the conversation is sent as fallback
(``tool_use.id: Input should be a valid string``).

These tests hit real provider APIs (Gemini + Anthropic) to verify that:
1. Google tool call IDs are always non-null strings after normalization.
2. A conversation with Google-originated tool calls can be sent to Anthropic
   without triggering a validation error.
"""

import os

import pytest

from voicerun_completions.client import (
    generate_chat_completion,
    generate_chat_completion_stream,
)
from voicerun_completions.types.messages import (
    AssistantMessage,
    ToolResultMessage,
    UserMessage,
)
from voicerun_completions.types.streaming import FinalResponseChunk


def _require_keys(*env_vars: str) -> list[str]:
    keys = []
    for var in env_vars:
        val = os.environ.get(var)
        if not val:
            pytest.skip(f"{var} not set")
        keys.append(val)
    return keys


TOOL_DEF = {
    "type": "function",
    "function": {
        "name": "get_weather",
        "description": "Get the current weather for a city",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"},
            },
            "required": ["city"],
        },
    },
}

MESSAGES_THAT_FORCE_TOOL_CALL = [
    {"role": "user", "content": "What is the weather in Paris? You must call the get_weather tool."},
]


# ---------------------------------------------------------------------------
# 1. Non-streaming: Google tool call IDs are valid strings
# ---------------------------------------------------------------------------

@pytest.mark.integration
async def test_google_non_streaming_tool_call_id_is_string():
    """Non-streaming Google response must produce ToolCall.id as a non-empty string."""
    (gemini_key,) = _require_keys("GEMINI_API_KEY")

    response = await generate_chat_completion({
        "provider": "google",
        "api_key": gemini_key,
        "model": "gemini-2.5-flash",
        "messages": MESSAGES_THAT_FORCE_TOOL_CALL,
        "tools": [TOOL_DEF],
        "tool_choice": "required",
        "max_tokens": 256,
    })

    assert response.message.tool_calls, "Expected Gemini to return a tool call"
    for tc in response.message.tool_calls:
        assert isinstance(tc.id, str), f"tool call id should be str, got {type(tc.id)}"
        assert len(tc.id) > 0, "tool call id should be non-empty"


# ---------------------------------------------------------------------------
# 2. Streaming: Google tool call IDs are valid strings
# ---------------------------------------------------------------------------

@pytest.mark.integration
async def test_google_streaming_tool_call_id_is_string():
    """Streaming Google response must produce ToolCall.id as a non-empty string."""
    (gemini_key,) = _require_keys("GEMINI_API_KEY")

    stream = await generate_chat_completion_stream(
        request={
            "provider": "google",
            "api_key": gemini_key,
            "model": "gemini-2.5-flash",
            "messages": MESSAGES_THAT_FORCE_TOOL_CALL,
            "tools": [TOOL_DEF],
            "tool_choice": "required",
            "max_tokens": 256,
        },
    )

    final_response = None
    async for chunk in stream:
        if isinstance(chunk, FinalResponseChunk):
            final_response = chunk.response

    assert final_response is not None
    assert final_response.message.tool_calls, "Expected Gemini to return a tool call"
    for tc in final_response.message.tool_calls:
        assert isinstance(tc.id, str), f"tool call id should be str, got {type(tc.id)}"
        assert len(tc.id) > 0, "tool call id should be non-empty"


# ---------------------------------------------------------------------------
# 3. Cross-provider: Google tool calls accepted by Anthropic
# ---------------------------------------------------------------------------

@pytest.mark.integration
async def test_google_tool_calls_accepted_by_anthropic():
    """A conversation with Google-originated tool calls should not 400 on Anthropic.

    This is the end-to-end regression test: get a tool call from Gemini,
    build a conversation history that includes the assistant tool-call message
    and a tool result, then send the continuation to Anthropic. Before the fix
    this would fail with ``tool_use.id: Input should be a valid string``.
    """
    gemini_key, anthropic_key = _require_keys("GEMINI_API_KEY", "ANTHROPIC_API_KEY")

    # Step 1: Get a tool call from Gemini (non-streaming)
    gemini_response = await generate_chat_completion({
        "provider": "google",
        "api_key": gemini_key,
        "model": "gemini-2.5-flash",
        "messages": MESSAGES_THAT_FORCE_TOOL_CALL,
        "tools": [TOOL_DEF],
        "tool_choice": "required",
        "max_tokens": 256,
    })

    assistant_msg = gemini_response.message
    assert assistant_msg.tool_calls, "Expected Gemini to return a tool call"
    tc = assistant_msg.tool_calls[0]

    # Step 2: Build conversation history with the Gemini tool call + a fake result
    messages = [
        UserMessage(content="What is the weather in Paris? You must call the get_weather tool."),
        assistant_msg,
        ToolResultMessage(
            tool_call_id=tc.id,
            name=tc.function.name,
            content={"temperature": 18, "condition": "partly cloudy"},
        ),
        UserMessage(content="Thanks! Summarize that in one sentence."),
    ]

    # Step 3: Send to Anthropic — this should NOT raise a 400
    anthropic_response = await generate_chat_completion({
        "provider": "anthropic",
        "api_key": anthropic_key,
        "model": "claude-haiku-4-5",
        "messages": messages,
        "tools": [TOOL_DEF],
        "max_tokens": 128,
    })

    assert anthropic_response.message is not None
    assert anthropic_response.message.content, "Expected Anthropic to return text content"
