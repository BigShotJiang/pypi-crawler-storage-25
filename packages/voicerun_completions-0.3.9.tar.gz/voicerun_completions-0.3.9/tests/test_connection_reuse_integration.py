"""Integration tests verifying CompletionsClient actually reuses connections.

Verifies on three levels:
1. SDK client object identity (same client instance returned across requests)
2. httpx connection pool reuse (same TCP connection used across requests)
3. Latency improvement (subsequent requests faster than first)
4. Cache hit/miss logs (via loguru sink interception)

Requires API keys for OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY.
"""
import time
from typing import Any

import pytest
from loguru import logger as loguru_logger

from voicerun_completions import CompletionsClient
from voicerun_completions.types.streaming import FinalResponseChunk


pytestmark = pytest.mark.integration


@pytest.fixture
def cache_log_capture():
    """Capture loguru DEBUG messages from CompletionsClient cache."""
    messages: list[str] = []
    sink_id = loguru_logger.add(
        lambda msg: messages.append(msg.record["message"]),
        level="DEBUG",
        filter=lambda r: "CompletionsClient cache" in r["message"],
    )
    yield messages
    loguru_logger.remove(sink_id)


PROVIDER_CONFIGS = [
    pytest.param("openai", "OPENAI_API_KEY", "gpt-4o-mini", id="openai"),
    pytest.param("anthropic", "ANTHROPIC_API_KEY", "claude-haiku-4-5", id="anthropic"),
    pytest.param("google", "GEMINI_API_KEY", "gemini-2.0-flash", id="google"),
]


def _api_key_or_skip(env_var: str) -> str:
    import os
    key = os.environ.get(env_var)
    if not key:
        pytest.skip(f"{env_var} not set")
    return key


def _make_request(provider: str, api_key: str, model: str) -> dict:
    return {
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [{"role": "user", "content": "Say hi in 3 words."}],
        "max_tokens": 20,
    }


def _get_httpx_client(sdk_client: Any) -> Any:
    """Extract the underlying httpx.AsyncClient from a provider SDK client."""
    # OpenAI / Anthropic SDKs expose their httpx client as ._client
    if hasattr(sdk_client, "_client"):
        return sdk_client._client
    # Google genai client wraps httpx differently — fall back to None
    return None


def _open_connection_count(httpx_client: Any) -> int:
    """Count the number of currently-open connections in the httpx pool."""
    if httpx_client is None:
        return -1
    try:
        transport = httpx_client._transport
        pool = transport._pool
        return len(pool.connections)
    except AttributeError:
        return -1


# =============================================================================
# Non-streaming connection reuse
# =============================================================================


@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_sdk_client_reused_across_non_streaming_requests(
    provider, env_var, model, cache_log_capture
):
    """Multiple non-streaming requests reuse the same SDK client instance."""
    api_key = _api_key_or_skip(env_var)
    request = _make_request(provider, api_key, model)

    client = CompletionsClient()
    try:
        r1 = await client.generate_chat_completion(request)
        r2 = await client.generate_chat_completion(request)
        r3 = await client.generate_chat_completion(request)

        assert r1.message.content
        assert r2.message.content
        assert r3.message.content

        # Exactly one SDK client cached for this (provider, api_key)
        assert len(client._sdk_clients) == 1

        # Verify cache logs: 1 MISS followed by 2 HITs
        miss_logs = [m for m in cache_log_capture if "cache MISS" in m and provider in m]
        hit_logs = [m for m in cache_log_capture if "cache HIT" in m and provider in m]
        assert len(miss_logs) == 1, f"Expected 1 MISS, got {len(miss_logs)}: {miss_logs}"
        assert len(hit_logs) == 2, f"Expected 2 HITs, got {len(hit_logs)}: {hit_logs}"
    finally:
        await client.close()


@pytest.mark.parametrize("provider,env_var,model", [
    pytest.param("openai", "OPENAI_API_KEY", "gpt-4o-mini", id="openai"),
    pytest.param("anthropic", "ANTHROPIC_API_KEY", "claude-haiku-4-5", id="anthropic"),
])
async def test_httpx_pool_reused_across_requests(provider, env_var, model):
    """Multiple non-streaming requests use the same httpx connection pool object.

    Only OpenAI and Anthropic — google-genai uses a different transport wrapper.
    """
    api_key = _api_key_or_skip(env_var)
    request = _make_request(provider, api_key, model)

    client = CompletionsClient()
    try:
        await client.generate_chat_completion(request)
        sdk_client_1 = list(client._sdk_clients.values())[0]
        httpx_client_1 = _get_httpx_client(sdk_client_1)
        pool_1_id = id(httpx_client_1._transport._pool) if httpx_client_1 else None

        await client.generate_chat_completion(request)
        sdk_client_2 = list(client._sdk_clients.values())[0]
        httpx_client_2 = _get_httpx_client(sdk_client_2)
        pool_2_id = id(httpx_client_2._transport._pool) if httpx_client_2 else None

        # Same SDK client, same httpx client, same connection pool
        assert sdk_client_1 is sdk_client_2
        assert httpx_client_1 is httpx_client_2
        assert pool_1_id == pool_2_id
        assert pool_1_id is not None

        # Should have at least one open connection in the pool after 2 requests
        open_conns = _open_connection_count(httpx_client_2)
        assert open_conns >= 1, f"Expected at least 1 open connection in pool, got {open_conns}"
    finally:
        await client.close()


@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_latency_improves_after_first_request(provider, env_var, model):
    """Second and third requests should be measurably faster than the first.

    The first request pays the TLS handshake; subsequent ones reuse the connection.
    """
    api_key = _api_key_or_skip(env_var)
    request = _make_request(provider, api_key, model)

    client = CompletionsClient()
    try:
        latencies = []
        for _ in range(3):
            t0 = time.perf_counter()
            await client.generate_chat_completion(request)
            latencies.append(time.perf_counter() - t0)

        first, second, third = latencies
        avg_subsequent = (second + third) / 2
        speedup = first / avg_subsequent if avg_subsequent > 0 else 0

        print(
            f"\n[{provider}] latencies (s): first={first:.3f}, "
            f"second={second:.3f}, third={third:.3f}, "
            f"avg_subsequent={avg_subsequent:.3f}, speedup={speedup:.2f}x"
        )

        # Subsequent requests should not be slower than first (allowing some noise).
        # We don't assert a strict speedup because LLM response time variance dominates,
        # but the average of subsequent should not exceed first by more than 50%.
        assert avg_subsequent < first * 1.5, (
            f"Subsequent requests slower than first: first={first:.3f}, "
            f"avg_subsequent={avg_subsequent:.3f}"
        )
    finally:
        await client.close()


# =============================================================================
# Streaming connection reuse
# =============================================================================


async def _drain_stream(stream) -> str:
    text = ""
    async for chunk in stream:
        if isinstance(chunk, FinalResponseChunk) and chunk.response.message.content:
            text = chunk.response.message.content
    return text


@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_sdk_client_reused_across_streaming_requests(
    provider, env_var, model, cache_log_capture
):
    """Multiple streaming requests reuse the same SDK client instance."""
    api_key = _api_key_or_skip(env_var)
    request = _make_request(provider, api_key, model)

    client = CompletionsClient()
    try:
        s1 = await client.generate_chat_completion_stream(request)
        t1 = await _drain_stream(s1)

        s2 = await client.generate_chat_completion_stream(request)
        t2 = await _drain_stream(s2)

        s3 = await client.generate_chat_completion_stream(request)
        t3 = await _drain_stream(s3)

        assert t1 and t2 and t3

        # Exactly one SDK client cached
        assert len(client._sdk_clients) == 1

        # Verify cache logs: 1 MISS, 2 HITs
        miss_logs = [m for m in cache_log_capture if "cache MISS" in m and provider in m]
        hit_logs = [m for m in cache_log_capture if "cache HIT" in m and provider in m]
        assert len(miss_logs) == 1
        assert len(hit_logs) == 2
    finally:
        await client.close()


# =============================================================================
# Multi-provider isolation
# =============================================================================


async def test_interleaved_multi_provider_calls(cache_log_capture):
    """Single CompletionsClient handles a non-trivial interleaved sequence
    of calls across all three providers, caching each independently.

    Sequence: openai, anthropic, anthropic, openai, google, google, anthropic
    Expected: 1 MISS per provider on first call, HITs on every subsequent call.
    """
    openai_key = _api_key_or_skip("OPENAI_API_KEY")
    anthropic_key = _api_key_or_skip("ANTHROPIC_API_KEY")
    gemini_key = _api_key_or_skip("GEMINI_API_KEY")

    requests = [
        ("openai", _make_request("openai", openai_key, "gpt-4o-mini")),
        ("anthropic", _make_request("anthropic", anthropic_key, "claude-haiku-4-5")),
        ("anthropic", _make_request("anthropic", anthropic_key, "claude-haiku-4-5")),
        ("openai", _make_request("openai", openai_key, "gpt-4o-mini")),
        ("google", _make_request("google", gemini_key, "gemini-2.0-flash")),
        ("google", _make_request("google", gemini_key, "gemini-2.0-flash")),
        ("anthropic", _make_request("anthropic", anthropic_key, "claude-haiku-4-5")),
    ]

    client = CompletionsClient()
    try:
        responses = []
        for _, req in requests:
            response = await client.generate_chat_completion(req)
            responses.append(response)

        # Every request returned content
        for i, response in enumerate(responses):
            assert response.message.content, f"Request {i} returned empty content"

        # Exactly 3 distinct cached SDK clients (one per provider)
        assert len(client._sdk_clients) == 3

        # Per-provider expected counts based on the sequence
        expected = {"openai": (1, 1), "anthropic": (1, 2), "google": (1, 1)}

        for provider, (expected_misses, expected_hits) in expected.items():
            misses = [m for m in cache_log_capture if "cache MISS" in m and f"provider={provider}" in m]
            hits = [m for m in cache_log_capture if "cache HIT" in m and f"provider={provider}" in m]
            assert len(misses) == expected_misses, (
                f"{provider}: expected {expected_misses} MISS, got {len(misses)}: {misses}"
            )
            assert len(hits) == expected_hits, (
                f"{provider}: expected {expected_hits} HIT, got {len(hits)}: {hits}"
            )

        # Total: 3 misses (one per provider on first call) + 4 hits (the rest)
        all_misses = [m for m in cache_log_capture if "cache MISS" in m]
        all_hits = [m for m in cache_log_capture if "cache HIT" in m]
        assert len(all_misses) == 3
        assert len(all_hits) == 4
    finally:
        await client.close()


async def test_different_providers_get_separate_clients(cache_log_capture):
    """Same CompletionsClient handling multiple providers caches each independently."""
    openai_key = _api_key_or_skip("OPENAI_API_KEY")
    anthropic_key = _api_key_or_skip("ANTHROPIC_API_KEY")

    client = CompletionsClient()
    try:
        await client.generate_chat_completion(_make_request("openai", openai_key, "gpt-4o-mini"))
        await client.generate_chat_completion(_make_request("anthropic", anthropic_key, "claude-haiku-4-5"))
        await client.generate_chat_completion(_make_request("openai", openai_key, "gpt-4o-mini"))
        await client.generate_chat_completion(_make_request("anthropic", anthropic_key, "claude-haiku-4-5"))

        # 2 distinct cached clients
        assert len(client._sdk_clients) == 2

        # OpenAI: 1 MISS + 1 HIT; Anthropic: 1 MISS + 1 HIT
        openai_miss = [m for m in cache_log_capture if "cache MISS" in m and "openai" in m]
        openai_hit = [m for m in cache_log_capture if "cache HIT" in m and "openai" in m]
        anthropic_miss = [m for m in cache_log_capture if "cache MISS" in m and "anthropic" in m]
        anthropic_hit = [m for m in cache_log_capture if "cache HIT" in m and "anthropic" in m]

        assert len(openai_miss) == 1
        assert len(openai_hit) == 1
        assert len(anthropic_miss) == 1
        assert len(anthropic_hit) == 1
    finally:
        await client.close()
