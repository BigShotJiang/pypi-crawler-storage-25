"""Unit tests for CompletionsClient connection reuse."""
import pytest

from voicerun_completions.client import (
    CompletionsClient,
    _sdk_client_cache_key,
    _build_sdk_client,
)
from voicerun_completions.types.request import CompletionsProvider, ChatCompletionRequest


def _make_request(provider="openai", api_key="test-key", **kwargs):
    return ChatCompletionRequest(
        provider=provider,
        api_key=api_key,
        model="test-model",
        messages=[{"role": "user", "content": "hello"}],
        **kwargs,
    )


class TestSdkClientCacheKey:
    def test_openai_key(self):
        req = _make_request(provider="openai", api_key="key-1")
        assert _sdk_client_cache_key(req) == (CompletionsProvider.OPENAI, "key-1")

    def test_anthropic_key(self):
        req = _make_request(provider="anthropic", api_key="key-2")
        assert _sdk_client_cache_key(req) == (CompletionsProvider.ANTHROPIC, "key-2")

    def test_google_key(self):
        req = _make_request(provider="google", api_key="key-3")
        assert _sdk_client_cache_key(req) == (CompletionsProvider.GOOGLE, "key-3")

    def test_alibaba_includes_base_url(self):
        req = _make_request(
            provider="alibaba",
            api_key="key-4",
            provider_kwargs={"alibaba": {"base_url": "https://custom.endpoint/v1"}},
        )
        key = _sdk_client_cache_key(req)
        assert key == (CompletionsProvider.ALIBABA, "key-4", "https://custom.endpoint/v1")

    def test_alibaba_default_base_url(self):
        req = _make_request(provider="alibaba", api_key="key-5")
        key = _sdk_client_cache_key(req)
        assert key == (CompletionsProvider.ALIBABA, "key-5", "")

    def test_vertex_includes_region_project_email(self):
        req = _make_request(
            provider="anthropic_vertex",
            api_key="",
            provider_kwargs={
                "anthropic_vertex": {
                    "region": "us-east5",
                    "project_id": "proj-123",
                    "service_account_credentials": {"client_email": "sa@proj.iam.gserviceaccount.com"},
                }
            },
        )
        key = _sdk_client_cache_key(req)
        assert key == (
            CompletionsProvider.ANTHROPIC_VERTEX,
            "us-east5",
            "proj-123",
            "sa@proj.iam.gserviceaccount.com",
        )

    def test_same_provider_different_keys_are_different(self):
        req1 = _make_request(provider="openai", api_key="key-a")
        req2 = _make_request(provider="openai", api_key="key-b")
        assert _sdk_client_cache_key(req1) != _sdk_client_cache_key(req2)

    def test_same_key_different_providers_are_different(self):
        req1 = _make_request(provider="openai", api_key="shared-key")
        req2 = _make_request(provider="anthropic", api_key="shared-key")
        assert _sdk_client_cache_key(req1) != _sdk_client_cache_key(req2)


class TestCompletionsClientRegistry:
    def test_get_or_create_caches_client(self):
        cc = CompletionsClient()
        req = _make_request(provider="openai", api_key="key-1")
        sdk1 = cc._get_or_create_sdk_client(req)
        sdk2 = cc._get_or_create_sdk_client(req)
        assert sdk1 is sdk2

    def test_different_keys_get_different_clients(self):
        cc = CompletionsClient()
        req1 = _make_request(provider="openai", api_key="key-a")
        req2 = _make_request(provider="openai", api_key="key-b")
        sdk1 = cc._get_or_create_sdk_client(req1)
        sdk2 = cc._get_or_create_sdk_client(req2)
        assert sdk1 is not sdk2

    def test_different_providers_get_different_clients(self):
        cc = CompletionsClient()
        req1 = _make_request(provider="openai", api_key="key-1")
        req2 = _make_request(provider="anthropic", api_key="key-1")
        sdk1 = cc._get_or_create_sdk_client(req1)
        sdk2 = cc._get_or_create_sdk_client(req2)
        assert sdk1 is not sdk2

    @pytest.mark.asyncio
    async def test_close_clears_registry(self):
        cc = CompletionsClient()
        req = _make_request(provider="openai", api_key="key-1")
        cc._get_or_create_sdk_client(req)
        assert len(cc._sdk_clients) == 1
        await cc.close()
        assert len(cc._sdk_clients) == 0

    @pytest.mark.asyncio
    async def test_context_manager(self):
        async with CompletionsClient() as cc:
            req = _make_request(provider="openai", api_key="key-1")
            cc._get_or_create_sdk_client(req)
            assert len(cc._sdk_clients) == 1
        # After __aexit__, registry should be cleared
        assert len(cc._sdk_clients) == 0


class TestBuildSdkClient:
    def test_openai(self):
        from openai import AsyncOpenAI
        req = _make_request(provider="openai", api_key="test-key")
        client = _build_sdk_client(req)
        assert isinstance(client, AsyncOpenAI)

    def test_anthropic(self):
        from anthropic import AsyncAnthropic
        req = _make_request(provider="anthropic", api_key="test-key")
        client = _build_sdk_client(req)
        assert isinstance(client, AsyncAnthropic)

    def test_google(self):
        from google.genai import Client as GoogleClient
        req = _make_request(provider="google", api_key="test-key")
        client = _build_sdk_client(req)
        assert isinstance(client, GoogleClient)

    def test_alibaba_uses_openai_with_base_url(self):
        from openai import AsyncOpenAI
        req = _make_request(
            provider="alibaba",
            api_key="test-key",
            provider_kwargs={"alibaba": {"base_url": "https://custom.endpoint/v1"}},
        )
        client = _build_sdk_client(req)
        assert isinstance(client, AsyncOpenAI)
        assert str(client.base_url) == "https://custom.endpoint/v1/"
