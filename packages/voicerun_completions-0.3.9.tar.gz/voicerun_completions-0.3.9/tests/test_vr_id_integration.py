"""Integration tests for vr_id on messages returned by providers."""

import os
import re

import pytest

from voicerun_completions.client import generate_chat_completion, generate_chat_completion_stream
from voicerun_completions.types.streaming import FinalResponseChunk


def _get_api_key_or_skip(env_var: str) -> str:
    key = os.environ.get(env_var)
    if not key:
        pytest.skip(f"{env_var} not set")
    return key


PROVIDER_CONFIGS = [
    pytest.param("openai", "OPENAI_API_KEY", "gpt-4.1-mini", id="openai"),
    pytest.param("anthropic", "ANTHROPIC_API_KEY", "claude-haiku-4-5", id="anthropic"),
    pytest.param("google", "GEMINI_API_KEY", "gemini-2.5-flash", id="google"),
]

HEX8 = re.compile(r"^[0-9a-f]{8}$")


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_non_streaming_response_has_vr_id(provider, env_var, model):
    """Non-streaming response message should have an auto-generated vr_id."""
    api_key = _get_api_key_or_skip(env_var)

    response = await generate_chat_completion({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [{"role": "user", "content": "Say hi."}],
        "max_tokens": 10,
    })

    assert response.message is not None
    assert HEX8.match(response.message.vr_id)


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_streaming_final_response_has_vr_id(provider, env_var, model):
    """Streaming final response message should have an auto-generated vr_id."""
    api_key = _get_api_key_or_skip(env_var)

    stream = await generate_chat_completion_stream(
        request={
            "provider": provider,
            "api_key": api_key,
            "model": model,
            "messages": [{"role": "user", "content": "Say hi."}],
            "max_tokens": 10,
        },
    )

    final_response = None
    async for chunk in stream:
        if isinstance(chunk, FinalResponseChunk):
            final_response = chunk.response

    assert final_response is not None
    assert HEX8.match(final_response.message.vr_id)


@pytest.mark.integration
@pytest.mark.parametrize("provider,env_var,model", PROVIDER_CONFIGS)
async def test_input_message_vr_ids_not_affected_by_completion(provider, env_var, model):
    """Input message vr_ids should remain unchanged after a completion call."""
    api_key = _get_api_key_or_skip(env_var)

    from voicerun_completions.types.messages import UserMessage
    user_msg = UserMessage(content="Say hi.")
    original_vr_id = user_msg.vr_id

    await generate_chat_completion({
        "provider": provider,
        "api_key": api_key,
        "model": model,
        "messages": [user_msg],
        "max_tokens": 10,
    })

    assert user_msg.vr_id == original_vr_id
