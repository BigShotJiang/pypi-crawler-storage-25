"""Unit tests for voicerun_completions/types/messages.py"""
import base64
import re

import pytest

from voicerun_completions.types.messages import (
    FunctionCall,
    ToolCall,
    UserMessage,
    AssistantMessage,
    SystemMessage,
    ToolResultMessage,
    ConversationHistoryMessage,
    serialize_conversation,
    deserialize_conversation,
)
from voicerun_completions.types.cache import CacheBreakpoint
from voicerun_completions.types.errors import InvalidMessageError


# =============================================================================
# FunctionCall
# =============================================================================

class TestFunctionCall:
    def test_serialize_roundtrip(self):
        fc = FunctionCall(name="get_weather", arguments={"city": "NYC"})
        data = fc.serialize()
        restored = FunctionCall.deserialize(data)
        assert restored.name == "get_weather"
        assert restored.arguments == {"city": "NYC"}

    def test_deserialize_from_dict(self):
        data = {"name": "search", "arguments": {"q": "hello"}}
        fc = FunctionCall.deserialize(data)
        assert fc.name == "search"
        assert fc.arguments == {"q": "hello"}


# =============================================================================
# ToolCall
# =============================================================================

class TestToolCall:
    def test_serialize_deserialize_basic(self):
        tc = ToolCall(
            id="call_1", type="function",
            function=FunctionCall(name="get_weather", arguments={"city": "NYC"}),
        )
        data = tc.serialize()
        restored = ToolCall.deserialize(data)
        assert restored.id == "call_1"
        assert restored.type == "function"
        assert restored.function.name == "get_weather"
        assert restored.index is None
        assert restored.thought_signature is None

    def test_serialize_with_thought_signature(self):
        sig = b"some_signature_bytes"
        tc = ToolCall(
            id="call_2", type="function",
            function=FunctionCall(name="fn", arguments={}),
            thought_signature=sig,
        )
        data = tc.serialize()
        assert "thought_signature" in data
        assert data["thought_signature"] == base64.b64encode(sig).decode("utf-8")

        restored = ToolCall.deserialize(data)
        assert restored.thought_signature == sig

    def test_serialize_with_index(self):
        tc = ToolCall(
            id="call_3", type="function",
            function=FunctionCall(name="fn", arguments={}),
            index=2,
        )
        data = tc.serialize()
        assert data["index"] == 2
        restored = ToolCall.deserialize(data)
        assert restored.index == 2

    def test_serialize_without_optional_fields_omits_them(self):
        tc = ToolCall(
            id="call_4", type="function",
            function=FunctionCall(name="fn", arguments={}),
        )
        data = tc.serialize()
        assert "index" not in data
        assert "thought_signature" not in data


# =============================================================================
# UserMessage
# =============================================================================

class TestUserMessage:
    def test_serialize_deserialize(self):
        msg = UserMessage(content="Hello")
        data = msg.serialize()
        assert data["role"] == "user"
        assert data["content"] == "Hello"
        restored = UserMessage.deserialize(data)
        assert restored.content == "Hello"
        assert restored.cache_breakpoint is None

    def test_name_defaults_to_none(self):
        msg = UserMessage(content="Hello")
        assert msg.name is None
        data = msg.serialize()
        assert "name" not in data

    def test_with_name(self):
        msg = UserMessage(content="Basket updated.", name="Order Manager")
        assert msg.name == "Order Manager"
        data = msg.serialize()
        assert data["name"] == "Order Manager"
        restored = UserMessage.deserialize(data)
        assert restored.name == "Order Manager"
        assert restored.content == "Basket updated."

    def test_with_name_and_cache_breakpoint(self):
        msg = UserMessage(
            content="Hi",
            name="System",
            cache_breakpoint=CacheBreakpoint(ttl="5m"),
        )
        data = msg.serialize()
        assert data["name"] == "System"
        assert data["cache_breakpoint"] == {"ttl": "5m"}
        restored = UserMessage.deserialize(data)
        assert restored.name == "System"
        assert restored.cache_breakpoint.ttl == "5m"

    def test_with_cache_breakpoint(self):
        msg = UserMessage(content="Hi", cache_breakpoint=CacheBreakpoint(ttl="5m"))
        data = msg.serialize()
        assert data["cache_breakpoint"] == {"ttl": "5m"}
        restored = UserMessage.deserialize(data)
        assert restored.cache_breakpoint.ttl == "5m"


# =============================================================================
# AssistantMessage
# =============================================================================

class TestAssistantMessage:
    def test_serialize_deserialize_plain_text(self):
        msg = AssistantMessage(content="I can help with that.")
        data = msg.serialize()
        assert data["role"] == "assistant"
        assert data["content"] == "I can help with that."
        restored = AssistantMessage.deserialize(data)
        assert restored.content == "I can help with that."
        assert restored.tool_calls is None

    def test_with_tool_calls(self):
        tc = ToolCall(
            id="call_1", type="function",
            function=FunctionCall(name="get_weather", arguments={"city": "NYC"}),
        )
        msg = AssistantMessage(content=None, tool_calls=[tc])
        data = msg.serialize()
        assert "tool_calls" in data
        assert len(data["tool_calls"]) == 1
        restored = AssistantMessage.deserialize(data)
        assert len(restored.tool_calls) == 1
        assert restored.tool_calls[0].function.name == "get_weather"

    def test_with_thought_signature(self):
        sig = b"assistant_sig"
        msg = AssistantMessage(content="text", thought_signature=sig)
        data = msg.serialize()
        assert "thought_signature" in data
        restored = AssistantMessage.deserialize(data)
        assert restored.thought_signature == sig

    def test_with_cache_breakpoint(self):
        msg = AssistantMessage(content="text", cache_breakpoint=CacheBreakpoint(ttl="1h"))
        data = msg.serialize()
        assert data["cache_breakpoint"] == {"ttl": "1h"}
        restored = AssistantMessage.deserialize(data)
        assert restored.cache_breakpoint.ttl == "1h"


# =============================================================================
# SystemMessage
# =============================================================================

class TestSystemMessage:
    def test_serialize_deserialize(self):
        msg = SystemMessage(content="You are helpful.")
        data = msg.serialize()
        assert data["role"] == "system"
        assert data["content"] == "You are helpful."
        restored = SystemMessage.deserialize(data)
        assert restored.content == "You are helpful."

    def test_with_cache_breakpoint(self):
        msg = SystemMessage(content="sys", cache_breakpoint=CacheBreakpoint(ttl="5m"))
        data = msg.serialize()
        assert "cache_breakpoint" in data
        restored = SystemMessage.deserialize(data)
        assert restored.cache_breakpoint.ttl == "5m"


# =============================================================================
# ToolResultMessage
# =============================================================================

class TestToolResultMessage:
    def test_serialize_deserialize(self):
        msg = ToolResultMessage(
            tool_call_id="call_1",
            content={"result": "sunny"},
        )
        data = msg.serialize()
        assert data["role"] == "tool"
        assert data["tool_call_id"] == "call_1"
        assert data["content"] == {"result": "sunny"}
        restored = ToolResultMessage.deserialize(data)
        assert restored.tool_call_id == "call_1"
        assert restored.content == {"result": "sunny"}
        assert restored.name is None

    def test_with_name(self):
        msg = ToolResultMessage(
            tool_call_id="call_2", content={"data": 42}, name="get_weather",
        )
        data = msg.serialize()
        assert data["name"] == "get_weather"
        restored = ToolResultMessage.deserialize(data)
        assert restored.name == "get_weather"

    def test_with_cache_breakpoint(self):
        msg = ToolResultMessage(
            tool_call_id="call_3", content={},
            cache_breakpoint=CacheBreakpoint(ttl="1h"),
        )
        data = msg.serialize()
        assert "cache_breakpoint" in data
        restored = ToolResultMessage.deserialize(data)
        assert restored.cache_breakpoint.ttl == "1h"


# =============================================================================
# ConversationHistoryMessage.deserialize dispatch
# =============================================================================

class TestConversationHistoryMessageDeserialize:
    def test_dispatches_to_user(self):
        msg = ConversationHistoryMessage.deserialize({"role": "user", "content": "hi"})
        assert isinstance(msg, UserMessage)

    def test_dispatches_to_assistant(self):
        msg = ConversationHistoryMessage.deserialize({"role": "assistant", "content": "hello"})
        assert isinstance(msg, AssistantMessage)

    def test_dispatches_to_system(self):
        msg = ConversationHistoryMessage.deserialize({"role": "system", "content": "sys"})
        assert isinstance(msg, SystemMessage)

    def test_dispatches_to_tool(self):
        msg = ConversationHistoryMessage.deserialize(
            {"role": "tool", "tool_call_id": "c1", "content": {}}
        )
        assert isinstance(msg, ToolResultMessage)

    def test_raises_for_unknown_role(self):
        with pytest.raises(InvalidMessageError):
            ConversationHistoryMessage.deserialize({"role": "unknown", "content": "x"})


# =============================================================================
# serialize_conversation / deserialize_conversation
# =============================================================================

class TestConversationRoundtrip:
    def test_roundtrip_multi_message(self):
        conversation = [
            SystemMessage(content="You are helpful."),
            UserMessage(content="What is 2+2?"),
            AssistantMessage(content="4"),
            UserMessage(content="Thanks!"),
        ]
        serialized = serialize_conversation(conversation)
        assert len(serialized) == 4
        assert serialized[0]["role"] == "system"
        assert serialized[1]["role"] == "user"

        restored = deserialize_conversation(serialized)
        assert len(restored) == 4
        assert isinstance(restored[0], SystemMessage)
        assert isinstance(restored[1], UserMessage)
        assert isinstance(restored[2], AssistantMessage)
        assert isinstance(restored[3], UserMessage)
        assert restored[2].content == "4"


# =============================================================================
# vr_id
# =============================================================================

class TestVrId:
    """Tests for the vr_id field on ConversationHistoryMessage subclasses."""

    def test_auto_generated_on_creation(self):
        """Each message gets a vr_id automatically without explicit assignment."""
        assert UserMessage(content="hi").vr_id
        assert AssistantMessage(content="hello").vr_id
        assert SystemMessage(content="sys").vr_id
        assert ToolResultMessage(tool_call_id="c1", content={}).vr_id

    def test_is_8_char_hex(self):
        """vr_id is an 8-character lowercase hex string."""
        hex8 = re.compile(r"^[0-9a-f]{8}$")
        assert hex8.match(UserMessage(content="hi").vr_id)
        assert hex8.match(AssistantMessage(content="hello").vr_id)
        assert hex8.match(SystemMessage(content="sys").vr_id)
        assert hex8.match(ToolResultMessage(tool_call_id="c1", content={}).vr_id)

    def test_unique_across_messages(self):
        """Different message instances get different vr_ids."""
        ids = {UserMessage(content="hi").vr_id for _ in range(50)}
        assert len(ids) == 50

    def test_explicit_vr_id(self):
        """vr_id can be explicitly set at construction time."""
        msg = UserMessage(content="hi", vr_id="custom01")
        assert msg.vr_id == "custom01"

    def test_serialize_includes_vr_id(self):
        """vr_id is always present in serialized output."""
        for msg in [
            UserMessage(content="hi"),
            AssistantMessage(content="hello"),
            SystemMessage(content="sys"),
            ToolResultMessage(tool_call_id="c1", content={}),
        ]:
            data = msg.serialize()
            assert "vr_id" in data
            assert data["vr_id"] == msg.vr_id

    def test_serialize_roundtrip_preserves_vr_id(self):
        """Serializing then deserializing preserves the original vr_id."""
        messages = [
            UserMessage(content="hi"),
            AssistantMessage(content="hello"),
            SystemMessage(content="sys"),
            ToolResultMessage(tool_call_id="c1", content={}),
        ]
        for msg in messages:
            data = msg.serialize()
            restored = type(msg).deserialize(data)
            assert restored.vr_id == msg.vr_id

    def test_deserialize_without_vr_id_generates_new(self):
        """Deserializing data without vr_id auto-generates one."""
        msg = UserMessage.deserialize({"role": "user", "content": "hi"})
        assert msg.vr_id
        assert len(msg.vr_id) == 8

    def test_conversation_roundtrip_preserves_vr_ids(self):
        """Full conversation serialize/deserialize preserves all vr_ids."""
        conversation = [
            SystemMessage(content="You are helpful."),
            UserMessage(content="What is 2+2?"),
            AssistantMessage(content="4"),
        ]
        original_ids = [m.vr_id for m in conversation]

        serialized = serialize_conversation(conversation)
        restored = deserialize_conversation(serialized)
        restored_ids = [m.vr_id for m in restored]

        assert original_ids == restored_ids

    def test_base_class_deserialize_preserves_vr_id(self):
        """Dispatching through ConversationHistoryMessage.deserialize preserves vr_id."""
        msg = UserMessage(content="hi")
        data = msg.serialize()
        restored = ConversationHistoryMessage.deserialize(data)
        assert restored.vr_id == msg.vr_id
