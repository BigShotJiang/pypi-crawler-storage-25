"""Logger proxy for voicerun_completions.

When running inside the VoiceRun sandbox, delegates to the builtins.logger
(the primfunctions Logger with SandboxLogger implementation).
When running standalone, falls back to loguru.
"""

import builtins
from loguru import logger as _loguru


class Logger:
    def _impl(self):
        return getattr(builtins, 'logger', None)

    def info(self, message, attributes=None):
        impl = self._impl()
        if impl:
            impl.info(message, attributes)
        else:
            _loguru.info(message)

    def warn(self, message, attributes=None):
        impl = self._impl()
        if impl:
            impl.warn(message, attributes)
        else:
            _loguru.warning(message)

    def error(self, message, attributes=None):
        impl = self._impl()
        if impl:
            impl.error(message, attributes)
        else:
            _loguru.error(message)

    def debug(self, message, attributes=None):
        impl = self._impl()
        if impl:
            impl.debug(message, attributes)
        else:
            _loguru.debug(message)


logger = Logger()
