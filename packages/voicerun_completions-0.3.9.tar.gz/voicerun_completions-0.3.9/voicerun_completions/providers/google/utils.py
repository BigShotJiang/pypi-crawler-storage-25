from copy import deepcopy
from typing import Any, Optional
from google.genai.types import (
    Content as GoogleMessageContent,
    Part as GoogleMessagePart,
    FunctionDeclaration as GoogleFunctionDefinition,
    Tool as GoogleToolDefinition,
    ToolConfig as GoogleToolChoice,
    FunctionCallingConfig as GoogleFunctionChoice,
)
from ...types.messages import (
    ConversationHistory,
    UserMessage,
    AssistantMessage,
    SystemMessage,
    ToolResultMessage,
)
from ...types.request import ToolChoice, ToolDefinition
from ...types.errors import InvalidToolError


def sanitize_parameters_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """Sanitize a JSON Schema for Google Gemini compatibility.

    Recursively removes or transforms fields that Google does not support:
    - ``additionalProperties: false`` is stripped
    - ``additionalProperties: true`` raises ``InvalidToolError``
    - ``const`` is converted to a single-value ``enum``
    - ``allOf`` raises ``InvalidToolError``
    - Union type arrays (``["string", "null"]``) are converted to ``nullable: true``
    - Non-string ``enum`` values raise ``InvalidToolError``
    """
    schema = deepcopy(schema)
    _sanitize_schema(schema)
    return schema


def _sanitize_schema(schema: dict[str, Any]) -> None:
    """Recursively sanitize a schema dict in place."""
    # additionalProperties: strip false, reject true
    if "additionalProperties" in schema:
        if schema["additionalProperties"]:
            raise InvalidToolError(
                "Google does not support 'additionalProperties: true' in tool parameter schemas. "
                "Consider restructuring as an array of key-value objects."
            )
        del schema["additionalProperties"]

    # const → single-value enum
    if "const" in schema:
        schema["enum"] = [str(schema.pop("const"))]

    # allOf: not supported, can't safely strip
    if "allOf" in schema:
        raise InvalidToolError(
            "Google does not support 'allOf' in tool parameter schemas."
        )

    # Union type arrays (e.g. ["string", "null"]) → nullable: true
    if isinstance(schema.get("type"), list):
        types = schema["type"]
        non_null = [t for t in types if t != "null"]
        if len(non_null) == 1:
            schema["type"] = non_null[0]
            if "null" in types:
                schema["nullable"] = True
        else:
            # Multiple non-null types — not representable, take the first
            schema["type"] = non_null[0] if non_null else types[0]
            if "null" in types:
                schema["nullable"] = True

    # Enum values must be strings
    if "enum" in schema:
        if any(not isinstance(v, str) for v in schema["enum"]):
            raise InvalidToolError(
                "Google only supports string values in 'enum'. "
                f"Got non-string values: {[v for v in schema['enum'] if not isinstance(v, str)]}"
            )

    # Recurse into properties
    if "properties" in schema:
        for prop_schema in schema["properties"].values():
            if isinstance(prop_schema, dict):
                _sanitize_schema(prop_schema)

    # Recurse into items (arrays)
    if "items" in schema and isinstance(schema["items"], dict):
        _sanitize_schema(schema["items"])

    # Recurse into anyOf
    if "anyOf" in schema:
        for variant in schema["anyOf"]:
            if isinstance(variant, dict):
                _sanitize_schema(variant)


def denormalize_conversation_history(normalized_messages: ConversationHistory) -> tuple[list[GoogleMessageContent], Optional[str]]:
    """Convert normalized Message objects to Google Content format.

    Returns:
        Tuple of (contents, system_instruction) since Google handles system prompts separately
    
    Note on thought signatures (Gemini 3):
        - Gemini 3 requires thought_signature on the first function call part in each step
        - If signature is missing (e.g., injected/transferred function calls), we use 
          "skip_thought_signature_validator" as a fallback to prevent 400 errors
        - See: https://ai.google.dev/gemini-api/docs/thought-signatures
    """
    contents: list[GoogleMessageContent] = []
    system_messages: list[str] = []

    for msg in normalized_messages:
        match msg:
            case SystemMessage():
                system_messages.append(msg.content)
            case UserMessage():
                text = msg.content or ""
                if msg.name:
                    text = f"[{msg.name}]: {text}"
                parts = [GoogleMessagePart.from_text(text=text)] if text else []

                content = GoogleMessageContent(
                    role="user",
                    parts=parts
                )
                contents.append(content)
            case AssistantMessage():
                # Assistant messages (model role in Google)
                parts = []

                # Add text content if present
                if msg.content:
                    text_part = GoogleMessagePart.from_text(text=msg.content)
                    # For text-only responses (no tool_calls), restore thought_signature on text part
                    # Gemini 3 returns signature on the last part for non-function-call responses
                    if not msg.tool_calls and hasattr(msg, 'thought_signature') and msg.thought_signature:
                        text_part.thought_signature = msg.thought_signature
                    parts.append(text_part)

                # Add function calls if present
                if msg.tool_calls:
                    for i, tc in enumerate(msg.tool_calls):
                        part = GoogleMessagePart.from_function_call(
                            name=tc.function.name,
                            args=tc.function.arguments
                        )
                        # Restore thought_signature if present (Google Gemini specific)
                        # For Gemini 3, the first function call in each step MUST have a signature
                        if hasattr(tc, 'thought_signature') and tc.thought_signature:
                            part.thought_signature = tc.thought_signature
                        elif i == 0:
                            # First function call requires signature for Gemini 3
                            # Use skip validator as fallback (e.g., for injected/transferred FCs)
                            part.thought_signature = b"skip_thought_signature_validator"
                        parts.append(part)

                content = GoogleMessageContent(
                    role="model",
                    parts=parts
                )
                contents.append(content)
            case ToolResultMessage():
                # Tool results become function_response parts in user messages
                # Need to find the corresponding function name from tool_call_id
                # For now, we'll need to track function names separately or get from context
                if msg.tool_call_id and msg.content:
                    # TODO: We need the function name from the original tool call
                    # This requires tracking the function name when processing assistant messages
                    # function_response = GoogleFunctionResponse(
                    #     id=msg.tool_call_id,
                    #     name=msg.name or "unknown_function",  # Name is required
                    #     response={"output": msg.content}
                    # )

                    content = GoogleMessageContent(
                        role="user",
                        parts=[GoogleMessagePart.from_function_response(
                            name=msg.name or "unknown_function",
                            response={"output": msg.content}
                        )]
                    )
                    contents.append(content)

    # Combine system messages with newlines
    system_instruction: Optional[str] = "\n".join(system_messages) if system_messages else None

    return contents, system_instruction


def denormalize_tools(normalized_tools: Optional[list[ToolDefinition]]) -> Optional[list[GoogleToolDefinition]]:
    """Convert normalized Tool objects to Google Tool format."""

    function_defs: Optional[list[GoogleFunctionDefinition]] = None
    if normalized_tools:
        function_defs = []
        for tool in normalized_tools:
            parameters = sanitize_parameters_schema(tool.function.parameters) if tool.function.parameters else None
            function_declaration = GoogleFunctionDefinition(
                name=tool.function.name,
                description=tool.function.description,
                parameters=parameters,
            )
            function_defs.append(function_declaration)

    # All google function calling tools are included in a single Google Tool
    return [GoogleToolDefinition(function_declarations=function_defs)] if function_defs else None


def denormalize_tool_choice(normalized_tool_choice: Optional[ToolChoice]) -> Optional[GoogleToolChoice]:
    """Convert normalized ToolChoice to Google GoogleToolChoice format."""
    if not normalized_tool_choice:
        return None

    # Google uses ToolConfig with FunctionCallingConfig
    if normalized_tool_choice == "auto":
        return GoogleToolChoice(
            function_calling_config=GoogleFunctionChoice(mode="AUTO")
        )
    elif normalized_tool_choice == "none":
        return GoogleToolChoice(
            function_calling_config=GoogleFunctionChoice(mode="NONE")
        )
    elif normalized_tool_choice == "required":
        return GoogleToolChoice(
            function_calling_config=GoogleFunctionChoice(mode="ANY")
        )
    else:
        # Specific tool name - use allowed_function_names
        return GoogleToolChoice(
            function_calling_config=GoogleFunctionChoice(
                mode="ANY",
                allowed_function_names=[normalized_tool_choice]
            )
        )
