from typing import Any, Optional, Union, AsyncIterable
from .logger import logger

from .types.request import (
    CompletionsProvider,
    ChatCompletionRequest,
    ChatCompletionRequestDict,
    StreamOptions,
    StreamOptionsDict,
)
from .types.streaming import ChatCompletionChunk, FinalResponseChunk
from .types.response import ChatCompletionResponse
from .providers.base import CompletionClient
from .providers.openai.client import OpenAiCompletionClient
from .providers.anthropic.client import AnthropicCompletionClient
from .providers.google.client import GoogleCompletionClient
from .providers.anthropic.vertex.client import AnthropicVertexCompletionClient
from .providers.alibaba.client import AlibabaCompletionClient
from .types.errors import InvalidProviderError, FallbackExhaustedError


def _get_client(provider: CompletionsProvider) -> CompletionClient:
    """Get a completion client with no SDK client reuse."""
    if provider == CompletionsProvider.OPENAI:
        return OpenAiCompletionClient()
    elif provider == CompletionsProvider.ANTHROPIC:
        return AnthropicCompletionClient()
    elif provider == CompletionsProvider.GOOGLE:
        return GoogleCompletionClient()
    elif provider == CompletionsProvider.ANTHROPIC_VERTEX:
        return AnthropicVertexCompletionClient()
    elif provider == CompletionsProvider.ALIBABA:
        return AlibabaCompletionClient()
    else:
        raise InvalidProviderError(str(provider))


def _sdk_client_cache_key(request: ChatCompletionRequest) -> tuple:
    """Build a cache key for the SDK client based on provider and auth credentials."""
    provider = request.provider
    if provider == CompletionsProvider.ALIBABA:
        provider_kwargs = (request.provider_kwargs or {}).get("alibaba", {})
        base_url = provider_kwargs.get("base_url", "")
        return (provider, request.api_key, base_url)
    elif provider == CompletionsProvider.ANTHROPIC_VERTEX:
        provider_kwargs = (request.provider_kwargs or {}).get("anthropic_vertex", {})
        return (
            provider,
            provider_kwargs.get("region", ""),
            provider_kwargs.get("project_id", ""),
            provider_kwargs.get("service_account_credentials", {}).get("client_email", ""),
        )
    else:
        return (provider, request.api_key)


def _build_sdk_client(request: ChatCompletionRequest) -> Any:
    """Create a long-lived SDK client for the given request's provider."""
    from openai import AsyncOpenAI
    from anthropic import AsyncAnthropic, AsyncAnthropicVertex
    from google.genai import Client as GoogleClient
    from google.oauth2 import service_account as google_service_account

    provider = request.provider

    if provider == CompletionsProvider.OPENAI:
        return AsyncOpenAI(api_key=request.api_key)
    elif provider == CompletionsProvider.ANTHROPIC:
        return AsyncAnthropic(api_key=request.api_key)
    elif provider == CompletionsProvider.GOOGLE:
        return GoogleClient(api_key=request.api_key)
    elif provider == CompletionsProvider.ALIBABA:
        provider_kwargs = (request.provider_kwargs or {}).get("alibaba", {})
        base_url = provider_kwargs.get("base_url", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1")
        return AsyncOpenAI(api_key=request.api_key, base_url=base_url)
    elif provider == CompletionsProvider.ANTHROPIC_VERTEX:
        provider_kwargs = (request.provider_kwargs or {}).get("anthropic_vertex", {})
        credentials = google_service_account.Credentials.from_service_account_info(
            provider_kwargs["service_account_credentials"]
        )
        client_kwargs: dict[str, Any] = {"region": provider_kwargs.get("region"), "credentials": credentials}
        if provider_kwargs.get("project_id"):
            client_kwargs["project_id"] = provider_kwargs["project_id"]
        return AsyncAnthropicVertex(**client_kwargs)
    else:
        raise InvalidProviderError(str(provider))


def _get_client_with_sdk(provider: CompletionsProvider, sdk_client: Any) -> CompletionClient:
    """Get a completion client wrapper backed by the given SDK client."""
    if provider == CompletionsProvider.OPENAI:
        return OpenAiCompletionClient(sdk_client=sdk_client)
    elif provider == CompletionsProvider.ANTHROPIC:
        return AnthropicCompletionClient(sdk_client=sdk_client)
    elif provider == CompletionsProvider.GOOGLE:
        return GoogleCompletionClient(sdk_client=sdk_client)
    elif provider == CompletionsProvider.ANTHROPIC_VERTEX:
        return AnthropicVertexCompletionClient(sdk_client=sdk_client)
    elif provider == CompletionsProvider.ALIBABA:
        return AlibabaCompletionClient(sdk_client=sdk_client)
    else:
        raise InvalidProviderError(str(provider))


class CompletionsClient:
    """LLM completions client that reuses SDK connections across requests.

    Caches underlying SDK clients (OpenAI, Anthropic, Google, etc.) so that
    repeated requests with the same provider + credentials reuse the same
    HTTP connection pool, avoiding TLS handshake overhead on every call.

    Usage::

        async with CompletionsClient() as client:
            response = await client.generate_chat_completion({...})
            stream = await client.generate_chat_completion_stream({...})

    Or with explicit lifecycle::

        client = CompletionsClient()
        response = await client.generate_chat_completion({...})
        await client.close()
    """

    def __init__(self):
        self._sdk_clients: dict[tuple, Any] = {}

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def close(self):
        """Close all cached SDK clients and release their connections."""
        from google.genai import Client as GoogleClient

        for sdk_client in self._sdk_clients.values():
            try:
                if isinstance(sdk_client, GoogleClient):
                    await sdk_client.aio.aclose()
                    sdk_client.close()
                else:
                    await sdk_client.close()
            except Exception:
                pass
        self._sdk_clients.clear()

    def _get_or_create_sdk_client(self, request: ChatCompletionRequest) -> Any:
        """Get a cached SDK client or create a new one."""
        key = _sdk_client_cache_key(request)
        if key not in self._sdk_clients:
            logger.debug(f"CompletionsClient cache MISS for provider={request.provider} — creating new SDK client")
            self._sdk_clients[key] = _build_sdk_client(request)
        else:
            logger.debug(f"CompletionsClient cache HIT for provider={request.provider} — reusing SDK client")
        return self._sdk_clients[key]

    def _get_completion_client(self, request: ChatCompletionRequest) -> CompletionClient:
        """Get a CompletionClient wrapper backed by a cached SDK client."""
        sdk_client = self._get_or_create_sdk_client(request)
        return _get_client_with_sdk(request.provider, sdk_client)

    async def generate_chat_completion(
        self,
        request: Union[ChatCompletionRequest, ChatCompletionRequestDict],
    ) -> ChatCompletionResponse:
        """Generate chat completion, reusing SDK connections.

        Args:
            request: ChatCompletionRequest object or dict with request parameters

        Returns:
            ChatCompletionResponse with the complete response

        Raises:
            VoiceRunCompletionError: On error

        Note:
            Retry logic follows OpenAI's recommended exponential backoff pattern.
        """
        if isinstance(request, dict):
            request = ChatCompletionRequest(**request)

        completion_attempts: list[ChatCompletionRequest] = request._build_completion_attempts()
        last_exception = None
        providers_tried: list[str] = []

        for completion_request in completion_attempts:
            providers_tried.append(str(completion_request.provider))
            try:
                client = self._get_completion_client(completion_request)
                response = await client.generate_chat_completion(completion_request)
                response.provider = completion_request.provider
                response.model = completion_request.model
                return response
            except Exception as e:
                logger.warn(f"Completion request failed with {str(e)}")
                last_exception = e

        if len(providers_tried) == 1:
            logger.error(f"Completion failed: {last_exception}")
            raise last_exception

        error = FallbackExhaustedError(
            message=f"All providers failed. Last error: {str(last_exception)}",
            fallback_count=len(providers_tried) - 1,
            providers_tried=providers_tried,
            last_error=last_exception,
        )
        logger.error(f"Completion failed: {error}")
        raise error

    async def generate_chat_completion_stream(
        self,
        request: Union[ChatCompletionRequest, ChatCompletionRequestDict],
        stream_options: Optional[Union[StreamOptions, StreamOptionsDict]] = None,
    ) -> AsyncIterable[ChatCompletionChunk]:
        """Generate streaming chat completion, reusing SDK connections.

        Args:
            request: ChatCompletionRequest object or dict with request parameters
            stream_options: Options for configuring streaming behavior

        Returns:
            AsyncIterable of ChatCompletionChunk objects (typed chunks)

        Raises:
            VoiceRunCompletionError: On error

        Retry Behavior:
            When retry enabled, the function will retry ONLY the initial connection
            (before streaming starts). Retries use exponential backoff (1s, 2s, 4s, etc.).
            Once streaming begins, failures are NOT retried to prevent duplicate content.

            RETRIES (Initial Connection Failures):
               - Connection failures
               - Network errors before streaming starts
               - Rate limits (429)
               - Server errors (500, 502, 503)
               - Authentication errors (401)
               - Timeout errors

            NO RETRY (Mid-Stream Failures):
               - Once streaming begins, failures are NOT retried
               - This prevents duplicate content in real-time applications
               - Mid-stream failures raise exceptions immediately

            This ensures reliability without duplicate audio/messages.
        """
        if isinstance(request, dict):
            request = ChatCompletionRequest(**request)

        if stream_options and isinstance(stream_options, dict):
            stream_options = StreamOptions(**stream_options)

        completion_attempts: list[ChatCompletionRequest] = request._build_completion_attempts()

        async def _stream() -> AsyncIterable[ChatCompletionChunk]:
            last_exception = None
            providers_tried: list[str] = []

            for completion_request in completion_attempts:
                providers_tried.append(str(completion_request.provider))
                try:
                    client = self._get_completion_client(completion_request)
                    stream = client.generate_chat_completion_stream(completion_request, stream_options)
                    aiter = stream.__aiter__()
                    first_chunk = await aiter.__anext__()
                except StopAsyncIteration:
                    continue
                except Exception as e:
                    logger.warn(f"Streaming connection failed with {str(e)}")
                    last_exception = e
                    continue

                def _stamp(chunk):
                    if isinstance(chunk, FinalResponseChunk):
                        chunk.response.provider = completion_request.provider
                        chunk.response.model = completion_request.model
                    return chunk

                yield _stamp(first_chunk)
                async for chunk in aiter:
                    yield _stamp(chunk)
                return

            if len(providers_tried) == 1 and last_exception is not None:
                logger.error(f"Streaming failed: {last_exception}")
                raise last_exception

            error = FallbackExhaustedError(
                message=f"All providers failed to stream. Last error: {str(last_exception)}",
                fallback_count=len(providers_tried) - 1,
                providers_tried=providers_tried,
                last_error=last_exception,
            )
            logger.error(f"Streaming failed: {error}")
            raise error

        return _stream()


# ---------------------------------------------------------------------------
# Backward-compatible module-level functions (no connection reuse)
# ---------------------------------------------------------------------------


async def generate_chat_completion(
    request: Union[ChatCompletionRequest, ChatCompletionRequestDict]
) -> ChatCompletionResponse:
    """
    Generate chat completion.

    Args:
        request: ChatCompletionRequest object or dict with request parameters

    Returns:
        ChatCompletionResponse with the complete response

    Raises:
        VoiceRunCompletionError: On error

    Note:
        Retry logic follows OpenAI's recommended exponential backoff pattern.
        For connection reuse across requests, use CompletionsClient instead.
    """
    if isinstance(request, dict):
        request = ChatCompletionRequest(**request)

    completion_attempts: list[ChatCompletionRequest] = request._build_completion_attempts()
    last_exception = None
    providers_tried: list[str] = []

    for completion_request in completion_attempts:
        providers_tried.append(str(completion_request.provider))
        try:
            client = _get_client(completion_request.provider)
            response = await client.generate_chat_completion(completion_request)
            response.provider = completion_request.provider
            response.model = completion_request.model
            return response
        except Exception as e:
            logger.warn(f"Completion request failed with {str(e)}")
            last_exception = e

    # If no fallbacks were configured, raise the original error directly
    if len(providers_tried) == 1:
        logger.error(f"Completion failed: {last_exception}")
        raise last_exception

    error = FallbackExhaustedError(
        message=f"All providers failed. Last error: {str(last_exception)}",
        fallback_count=len(providers_tried) - 1,
        providers_tried=providers_tried,
        last_error=last_exception,
    )
    logger.error(f"Completion failed: {error}")
    raise error


async def generate_chat_completion_stream(
    request: Union[ChatCompletionRequest, ChatCompletionRequestDict],
    stream_options: Optional[Union[StreamOptions, StreamOptionsDict]] = None,
) -> AsyncIterable[ChatCompletionChunk]:
    """
    Generate streaming chat completion.

    Args:
        request: ChatCompletionRequest object or dict with request parameters
        stream_options: Options for configuring streaming behavior

    Returns:
        AsyncIterable of ChatCompletionChunk objects (typed chunks)

    Raises:
        VoiceRunCompletionError: On error

    Retry Behavior:
        When retry enabled, the function will retry ONLY the initial connection
        (before streaming starts). Retries use exponential backoff (1s, 2s, 4s, etc.).
        Once streaming begins, failures are NOT retried to prevent duplicate content.

        RETRIES (Initial Connection Failures):
           - Connection failures
           - Network errors before streaming starts
           - Rate limits (429)
           - Server errors (500, 502, 503)
           - Authentication errors (401)
           - Timeout errors

        NO RETRY (Mid-Stream Failures):
           - Once streaming begins, failures are NOT retried
           - This prevents duplicate content in real-time applications
           - Mid-stream failures raise exceptions immediately

        This ensures reliability without duplicate audio/messages.

    Note:
        For connection reuse across requests, use CompletionsClient instead.
    """
    if isinstance(request, dict):
        request = ChatCompletionRequest(**request)

    if stream_options and isinstance(stream_options, dict):
        stream_options = StreamOptions(**stream_options)

    completion_attempts: list[ChatCompletionRequest] = request._build_completion_attempts()

    async def _stream() -> AsyncIterable[ChatCompletionChunk]:
        last_exception = None
        providers_tried: list[str] = []

        for completion_request in completion_attempts:
            providers_tried.append(str(completion_request.provider))
            try:
                client = _get_client(completion_request.provider)
                stream = client.generate_chat_completion_stream(completion_request, stream_options)
                aiter = stream.__aiter__()
                first_chunk = await aiter.__anext__()
            except StopAsyncIteration:
                # Empty stream from this provider, try next fallback
                continue
            except Exception as e:
                logger.warn(f"Streaming connection failed with {str(e)}")
                last_exception = e
                continue

            # Connection established - yield chunks, stamping provider/model on FinalResponseChunk
            def _stamp(chunk):
                if isinstance(chunk, FinalResponseChunk):
                    chunk.response.provider = completion_request.provider
                    chunk.response.model = completion_request.model
                return chunk

            yield _stamp(first_chunk)
            async for chunk in aiter:
                yield _stamp(chunk)
            return

        # If no fallbacks were configured, raise the original error directly
        if len(providers_tried) == 1 and last_exception is not None:
            logger.error(f"Streaming failed: {last_exception}")
            raise last_exception

        error = FallbackExhaustedError(
            message=f"All providers failed to stream. Last error: {str(last_exception)}",
            fallback_count=len(providers_tried) - 1,
            providers_tried=providers_tried,
            last_error=last_exception,
        )
        logger.error(f"Streaming failed: {error}")
        raise error

    return _stream()
