"""Encoder implementations."""
