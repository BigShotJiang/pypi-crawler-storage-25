# Copyright 2023 ACSONE SA/NV
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

{
    "name": "Exclude locations from immediately usable quantity",
    "version": "18.0.1.0.0",
    "website": "https://github.com/OCA/stock-logistics-availability",
    "author": "ACSONE SA/NV,Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "depends": ["stock_available_immediately", "stock_available_location_get_domain"],
    "data": ["views/stock_location.xml"],
    "category": "Hidden",
    "installable": True,
}
