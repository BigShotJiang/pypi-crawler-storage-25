"""Single module: MCP tools, registration, and stdio server (uvx / python -m)."""

from __future__ import annotations

import inspect
from collections.abc import Callable
from functools import wraps

from mcp.server.fastmcp import FastMCP


def run_uppercase(text: str) -> str:
    return text.upper()


def run_lowercase(text: str) -> str:
    return text.lower()


def _register_tool(
    mcp: FastMCP,
    *,
    name: str,
    title: str,
    description: str,
    runner: Callable[..., object],
) -> None:
    @wraps(runner)
    def tool_fn(*args: object, **kwargs: object) -> str:
        result = runner(*args, **kwargs)
        return result if isinstance(result, str) else str(result)

    tool_fn.__signature__ = inspect.signature(runner)
    mcp.tool(name=name, title=title, description=description)(tool_fn)


def main() -> None:
    mcp = FastMCP("alix-example-mcp-tool")
    _register_tool(
        mcp,
        name="uppercase_text",
        title="Uppercase text",
        description="Returns input text in uppercase.",
        runner=run_uppercase,
    )
    _register_tool(
        mcp,
        name="lowercase_text",
        title="Lowercase text",
        description="Returns input text in lowercase.",
        runner=run_lowercase,
    )
    mcp.run()
