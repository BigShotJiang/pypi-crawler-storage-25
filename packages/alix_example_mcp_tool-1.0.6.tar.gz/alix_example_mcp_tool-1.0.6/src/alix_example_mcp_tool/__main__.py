"""python -m alix_example_mcp_tool → stdio MCP."""

from alix_example_mcp_tool.mcp_server import main

if __name__ == "__main__":
    main()
