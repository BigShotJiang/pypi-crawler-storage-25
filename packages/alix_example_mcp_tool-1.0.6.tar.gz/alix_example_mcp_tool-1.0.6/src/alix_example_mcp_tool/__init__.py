__version__ = "1.0.6"

from alix_example_mcp_tool.mcp_server import run_lowercase, run_uppercase

__all__ = [
    "__version__",
    "run_lowercase",
    "run_uppercase",
]
