"""LLM client — talks to Ollama via PastaWater broker or directly to a brain."""

import json
import os
import time
import requests
from typing import Iterator


DEFAULT_API_URL = "https://pastawater.io"

# Embedding-only models (nomic-embed-text, bge-*, e5-*, gte-*) are filtered
# from "which chat model is loaded" detection — they return empty on /api/chat.
_EMBED_MARKERS = ("embed", "bge-", "-bge", "e5-", "-e5", "gte-", "-gte")

# How long to trust the last /api/ps result before re-querying in direct mode.
# Short enough to catch a mid-session swap; long enough not to hammer the brain
# on every token streamed back (chat_stream may be called many times per turn).
_REALIGN_TTL_SECONDS = 10.0


class LLMClient:
    """Client that talks to Ollama via PastaWater broker API or direct brain connection."""

    def __init__(
        self,
        token: str = "",
        device_id: str = "",
        slot: int = 0,
        model: str = "",
        api_url: str = DEFAULT_API_URL,
        brain_url: str = "",
        brain_key: str = "",
    ):
        self.token = token
        self.device_id = device_id
        self.slot = slot
        self.model = model
        self.api_url = api_url.rstrip("/")
        self.brain_url = brain_url.rstrip("/") if brain_url else ""
        self.brain_key = brain_key
        self.direct_mode = bool(brain_url)

        self.session = requests.Session()
        self.session.headers["Content-Type"] = "application/json"
        self._active_response = None  # Track active streaming response for abort
        # Auth: PW token works for both cloud API and local brain proxy
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"
        if brain_key:
            self.session.headers["X-Controller-API-Key"] = brain_key
        # Last time we re-queried /api/ps to confirm our cached model matches
        # what's actually resident. Zero means "never" — forces a check on the
        # first chat call so a stale client.model from config doesn't drive
        # Ollama into a silent model swap.
        self._last_realign_ts = 0.0
        # Background realign thread — Agent.run() fires this at turn entry
        # so the /api/ps probe overlaps with the ~500-1500ms of embed calls
        # that precede chat_stream. By the time /api/chat is hit, the probe
        # has usually completed and self.model is already aligned; chat_stream
        # then skips the synchronous fallback.
        self._realign_thread = None

    def abort(self):
        """Abort the active streaming request."""
        if self._active_response:
            try:
                self._active_response.close()
            except Exception:
                pass
            self._active_response = None

    def chat(self, messages: list[dict], temperature: float = 0.3, context_length: int = 8192, thinking: bool = False) -> str:
        """Send messages and return the full response text."""
        chunks = []
        for chunk in self.chat_stream(messages, temperature, context_length, thinking=thinking):
            chunks.append(chunk)
        return "".join(chunks)

    def realign_async(self):
        """Kick off the /api/ps probe in a background thread so it overlaps
        with the memory/codebase embed calls at the start of each turn.
        Zero user-perceived latency: by the time chat_stream hits /api/chat,
        self.model has already been aligned (usually). Safe to call at the
        top of Agent.run() on every turn.

        Skipped when a probe is already in flight or when the TTL hasn't
        expired yet.
        """
        if not self.direct_mode:
            return
        existing = self._realign_thread
        if existing is not None and existing.is_alive():
            return
        if time.time() - self._last_realign_ts < _REALIGN_TTL_SECONDS:
            return
        import threading
        t = threading.Thread(target=self._realign_model, daemon=True, name="llm-realign")
        self._realign_thread = t
        t.start()

    def _realign_model(self):
        """Re-query /api/ps and align self.model with whatever's actually
        resident in Ollama. Prevents the stale-cached-model → silent-swap
        bug: if the user pulled/started a different model after pw-agent
        launched, sending /api/chat with the old model name would cause
        Ollama to evict the new model and load the old one. We want the
        agent to talk to whatever is loaded, not force its own choice.

        Only runs in direct mode (cloud broker handles routing). Cached for
        ~10s so streaming tokens back during a long turn doesn't hammer the
        brain with /api/ps probes.

        Returns the aligned model name, or self.model unchanged if the
        probe fails / no chat model resident / already aligned.
        """
        if not self.direct_mode:
            return self.model
        now = time.time()
        if now - self._last_realign_ts < _REALIGN_TTL_SECONDS:
            return self.model
        self._last_realign_ts = now
        try:
            resp = self.session.get(f"{self.brain_url}/api/ps", timeout=3)
            if resp.status_code != 200:
                return self.model
            models = resp.json().get("models", []) or []
            chat_models = [
                m.get("name") for m in models
                if m.get("name") and not any(mk in m["name"].lower() for mk in _EMBED_MARKERS)
            ]
            if not chat_models:
                # Nothing resident (model still pulling, or Ollama just
                # booted). Keep our cached choice; the chat call will either
                # warm it or error — that's Ollama's decision, not ours.
                return self.model
            # If our cached model is one of the resident ones, nothing to do.
            if self.model in chat_models:
                return self.model
            # Otherwise realign to the single resident chat model. When
            # multiple are loaded (rare), prefer the largest VRAM footprint
            # — that's almost always the "primary" one the user cares about.
            if len(chat_models) == 1:
                new_model = chat_models[0]
            else:
                sized = [(m.get("name"), m.get("size_vram") or 0) for m in models
                         if m.get("name") in chat_models]
                sized.sort(key=lambda x: -x[1])
                new_model = sized[0][0]
            old = self.model
            self.model = new_model
            # Best-effort user notice via stderr — callers using quiet -p
            # mode see this alongside their NDJSON events. Stdout must stay
            # clean for parsers.
            try:
                import sys as _sys
                _sys.stderr.write(f"[pw-agent] realigned model: {old} → {new_model}\n")
                _sys.stderr.flush()
            except Exception:
                pass
            return new_model
        except Exception:
            return self.model

    def chat_stream(self, messages: list[dict], temperature: float = 0.3, context_length: int = 8192, thinking: bool = False) -> Iterator[str]:
        """Stream chat tokens from Ollama."""
        if self.direct_mode:
            # Agent.run() fires realign_async() at turn entry; by now the
            # bg probe has usually finished during memory/codebase embeds.
            # If it's still running we wait up to 100ms for it, then give
            # up and proceed with whatever self.model is — the worst case
            # is one stale turn, and the NEXT turn's realign catches it.
            t = self._realign_thread
            if t is not None and t.is_alive():
                t.join(timeout=0.1)
            # Fallback: if nothing ever triggered realign (e.g. caller
            # bypassed Agent.run), do a synchronous probe now so we
            # never send /api/chat with a stale cached model.
            if self._last_realign_ts == 0.0:
                self._realign_model()
            yield from self._stream_direct(messages, temperature, context_length, thinking=thinking)
        else:
            yield from self._stream_broker(messages, temperature, context_length, thinking=thinking)

    def _stream_direct(self, messages: list[dict], temperature: float, context_length: int, thinking: bool = False) -> Iterator[str]:
        """Stream directly from brain's Ollama endpoint."""
        model_lower = self.model.lower()
        is_gemma = "gemma" in model_lower

        # Thinking-capable models (gemma4, qwen3.5) expose a structured
        # `thinking` field via /api/chat — we can route think around the
        # visible stream. qwen3.6 bakes <think>...</think> into its raw
        # output but DOES NOT honor /api/chat think:false (returns empty
        # content); so keep it on /api/generate raw like qwen3-coder —
        # agent.py strips the <think> blocks before display.
        #
        # Default thinking OFF for models that support the flag cleanly;
        # users can still opt in per-session with --think.
        is_qwen35_thinking = model_lower.startswith("qwen3.5")
        is_thinking_model = is_gemma or is_qwen35_thinking
        ask_for_thinking = bool(thinking)

        if thinking or is_thinking_model:
            # Thinking mode or Gemma: use /api/chat (Gemma doesn't work with raw mode)
            payload = {
                "model": self.model,
                "messages": messages,
                "stream": True,
                "think": ask_for_thinking,
                "options": {
                    "temperature": temperature,
                    "num_ctx": context_length,
                    "num_predict": 4096,
                },
            }
            endpoint = "/api/chat"
        else:
            # Qwen/DeepSeek: use /api/generate with raw ChatML to avoid
            # Ollama's tool-call parsing, thinking EOF, and empty function name bugs
            raw_prompt = self._flatten_messages(messages)
            payload = {
                "model": self.model,
                "prompt": raw_prompt,
                "raw": True,
                "stream": True,
                "options": {
                    "temperature": temperature,
                    "num_ctx": context_length,
                    "num_predict": 4096,
                },
            }
            endpoint = "/api/generate"

        try:
            resp = self.session.post(
                f"{self.brain_url}{endpoint}",
                json=payload,
                stream=True,
                timeout=300,
            )
        except requests.exceptions.ConnectionError:
            yield f"[Error: Could not connect to brain at {self.brain_url}]"
            return
        except requests.exceptions.Timeout:
            yield "[Error: Request timed out]"
            return

        if resp.status_code != 200:
            yield f"[Error: Brain returned {resp.status_code}]"
            return

        self._active_response = resp
        for line in resp.iter_lines():
            if not line:
                continue
            try:
                data = json.loads(line)
                # Check for thinking field
                if thinking:
                    thinking_text = data.get("message", {}).get("thinking", "")
                    if thinking_text:
                        yield f"[think]{thinking_text}[/think]"
                # /api/chat uses message.content, /api/generate uses response
                if "message" in data:
                    msg = data["message"]
                    content = msg.get("content", "")
                    # Native Ollama tool_calls — serialize into the
                    # <tool_call>{...}</tool_call> text format that the
                    # agent's parser knows about. Without this, gemma /
                    # qwen3 tool-call responses come through as empty
                    # content and pw-agent prints "Empty response".
                    tool_calls = msg.get("tool_calls") or []
                    if tool_calls and not content:
                        for tc in tool_calls:
                            fn = (tc or {}).get("function") or {}
                            name = fn.get("name", "")
                            args = fn.get("arguments", {})
                            if isinstance(args, str):
                                try:
                                    args = json.loads(args)
                                except Exception:
                                    args = {"_raw": args}
                            payload_text = json.dumps({"name": name, "arguments": args})
                            content = f"<tool_call>{payload_text}</tool_call>"
                else:
                    content = data.get("response", "")
                if content:
                    yield content
                if data.get("done"):
                    return
            except json.JSONDecodeError:
                continue

    def _flatten_messages(self, messages: list[dict]) -> str:
        """Flatten chat messages into a prompt string using the model's native template.

        Different model families use different chat templates:
        - Qwen/DeepSeek: ChatML (<|im_start|>role\ncontent<|im_end|>)
        - Gemma: <start_of_turn>role\ncontent<end_of_turn>
        - Llama: [INST] content [/INST]
        """
        model_lower = self.model.lower()

        if "gemma" in model_lower:
            # Gemma format
            parts = []
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                # Gemma uses "user" and "model" (not "assistant")
                gemma_role = "model" if role == "assistant" else role
                if role == "system":
                    # Gemma has no system role — prepend to first user message
                    parts.append(f"<start_of_turn>user\n{content}<end_of_turn>")
                else:
                    parts.append(f"<start_of_turn>{gemma_role}\n{content}<end_of_turn>")
            parts.append("<start_of_turn>model\n")
            return "\n".join(parts)
        else:
            # ChatML format (Qwen, DeepSeek, most Ollama models)
            parts = []
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                parts.append(f"<|im_start|>{role}\n{content}<|im_end|>")
            parts.append("<|im_start|>assistant\n")
            return "\n".join(parts)

    def _stream_broker(self, messages: list[dict], temperature: float, context_length: int, thinking: bool = False) -> Iterator[str]:
        """Submit task asynchronously and poll for completion to avoid EOF/timeouts."""
        import time

        payload = {
            "model": "llm-chat",
            "slot": self.slot,
            "messages": messages,
            "llm_model": self.model,
            "temperature": temperature,
            "max_tokens": 4096,
            "context_length": context_length,
            "thinking": thinking,
        }

        # 1. Submit the task asynchronously (with retry on transient errors)
        task_id = None
        max_retries = 3
        for attempt in range(max_retries):
            try:
                resp = self.session.post(
                    f"{self.api_url}/api/v1/playground/generate/async",
                    json=payload,
                    timeout=30,
                )
                if resp.status_code in (200, 202):
                    data = resp.json()
                    if data.get("success"):
                        task_id = data.get("task_id")
                        break
                    err = data.get("error", "")
                    # Retryable: slot resolution failures, device offline
                    if attempt < max_retries - 1 and ("resolve device" in err or "offline" in err):
                        time.sleep(2 * (attempt + 1))
                        continue
                    yield f"[Error: {err}]"
                    return
                elif resp.status_code in (502, 503, 504):
                    # Gateway errors — retry
                    if attempt < max_retries - 1:
                        time.sleep(2 * (attempt + 1))
                        continue
                    yield f"[Error: API returned {resp.status_code} after {max_retries} retries]"
                    return
                else:
                    yield f"[Error: API returned {resp.status_code}: {resp.text[:200]}]"
                    return
            except (requests.exceptions.ConnectionError, requests.exceptions.Timeout):
                if attempt < max_retries - 1:
                    time.sleep(2 * (attempt + 1))
                    continue
                yield f"[Error: Connection failed after {max_retries} retries]"
                return
            except Exception as e:
                yield f"[Error: {str(e)}]"
                return

        if not task_id:
            yield "[Error: No task_id returned from broker]"
            return

        # 2. Poll for result
        # Most LLM tasks take 5-60s. We'll poll every 1-2s.
        max_wait = 300 # 5 minutes
        start_time = time.time()

        # Add a subtle indicator that we are polling
        import sys

        while time.time() - start_time < max_wait:
            try:
                # Use a fresh request for polling to avoid session stickiness issues
                poll_resp = self.session.get(
                    f"{self.api_url}/api/v1/playground/tasks/{task_id}",
                    timeout=10
                )
                if poll_resp.status_code == 200:
                    poll_data = poll_resp.json()
                    status = poll_data.get("status")

                    if status == "completed":
                        result = poll_data.get("result", {})
                        # Yield thinking content first (if present)
                        thinking_text = result.get("thinking", "")
                        if thinking_text:
                            yield f"[think]{thinking_text}[/think]"
                        text = result.get("text", "") or result.get("response", "") or ""
                        if not text and os.environ.get("PW_DEBUG"):
                            import sys
                            sys.stderr.write(f"DEBUG poll result: {str(result)[:300]}\n")
                        yield text
                        return

                    if status == "failed":
                        err = poll_data.get("error", "Generation failed")
                        if os.environ.get("PW_DEBUG"):
                            import sys
                            sys.stderr.write(f"DEBUG task failed: {err}\n")
                            sys.stderr.write(f"DEBUG full: {str(poll_data)[:500]}\n")
                        yield f"[Error: {err}]"
                        return

                elif poll_resp.status_code != 404: 
                    # If we get a 500 or other error during polling, report it
                    try:
                        err_data = poll_resp.json()
                        err_msg = err_data.get("error", f"Status {poll_resp.status_code}")
                    except:
                        err_msg = f"Status {poll_resp.status_code}"
                    yield f"[Error: Polling failed: {err_msg}]"
                    return

            except Exception:
                pass # Continue polling on transient network errors

            time.sleep(1.5)

        yield "[Error: Task timed out after 5 minutes]"

    def list_devices(self) -> list:
        """List online GPU devices with running LLM."""
        if self.direct_mode:
            return [{"slot": 0, "device_id": "local", "device_name": "local", "gpu": "direct", "llm_model": self.model}]

        try:
            resp = self.session.get(f"{self.api_url}/api/user/byog/slots", timeout=15)
            if resp.status_code != 200:
                return []
            data = resp.json()
            if not data.get("success"):
                return []

            devices = []
            for s in data.get("slots", []):
                if not s.get("online"):
                    continue
                running = s.get("running_services", [])
                if "llm" in running:
                    devices.append({
                        "slot": s.get("slot_number"),
                        "device_id": s.get("device_id", ""),
                        "device_name": s.get("device_name", "Unknown"),
                        "gpu": s.get("gpu_info", {}).get("name", "Unknown"),
                        "vram_gb": round(s.get("gpu_info", {}).get("memory_total_mb", 0) / 1024, 1),
                        "llm_model": s.get("llm_current_model") or "ollama",
                    })
            return devices
        except Exception:
            return []

    def test_connection(self) -> tuple[bool, str]:
        """Test connectivity and return (ok, message)."""
        if self.direct_mode:
            try:
                resp = self.session.get(f"{self.brain_url}/api/tags", timeout=10)
                if resp.status_code != 200:
                    return False, f"Brain returned {resp.status_code}"
                data = resp.json()
                models = [m["name"] for m in data.get("models", [])]
                if self.model and self.model not in models:
                    available = ", ".join(models[:5]) or "none"
                    return False, f"Model '{self.model}' not found. Available: {available}"
                return True, f"Connected to brain at {self.brain_url} ({self.model})"
            except requests.exceptions.ConnectionError:
                return False, f"Could not connect to {self.brain_url}"
            except Exception as e:
                return False, str(e)

        # Cloud mode — find our slot
        try:
            resp = self.session.get(f"{self.api_url}/api/user/byog/slots", timeout=15)
            if resp.status_code == 401:
                return False, "Invalid API token"
            if resp.status_code != 200:
                return False, f"API error: {resp.status_code}"

            data = resp.json()
            if not data.get("success"):
                return False, data.get("error", "API error")

            for s in data.get("slots", []):
                if s.get("slot_number") == self.slot:
                    if not s.get("online"):
                        return False, f"Slot {self.slot} is offline"
                    if "llm" not in s.get("running_services", []):
                        return False, f"Slot {self.slot} has no LLM running"
                    gpu = s.get("gpu_info", {}).get("name", "unknown")
                    model = s.get("llm_current_model") or self.model or "ollama"
                    return True, f"Connected to {model} on {gpu} (slot {self.slot})"

            return False, f"Slot {self.slot} not found"
        except requests.exceptions.ConnectionError:
            return False, f"Could not connect to {self.api_url}"
        except Exception as e:
            return False, str(e)
