from __future__ import annotations
from typing import Optional
from datetime import datetime, timedelta, timezone

import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.output import json_envelope, json_error


def topics(
    transcript_id: Optional[str] = typer.Argument(None, help="Transcript ID (omit for recent meetings)"),
    days: Optional[int] = typer.Option(7, "--days", help="Last N days (when no ID given)"),
    limit: int = typer.Option(20, "--limit"),
    table: bool = typer.Option(False, "--table", help="Rich table output"),
) -> None:
    """List topics discussed in meetings."""
    json_mode = not table
    config = Config()
    if not config.api_key:
        if json_mode:
            typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key not set. Run: ffx auth", err=True)
        raise typer.Exit(2)

    try:
        client = FirefliesClient(config.api_key)

        if transcript_id:
            t = client.get_transcript(transcript_id)
            if t is None:
                if json_mode:
                    typer.echo(json_error("Transcript not found", "NOT_FOUND"))
                else:
                    typer.echo(f"Transcript '{transcript_id}' not found.", err=True)
                raise typer.Exit(3)
            transcripts = [t]
        else:
            from_date = None
            if days:
                from_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
            transcripts = client.list_transcripts(limit=limit, from_date=from_date)

    except AuthError:
        if json_mode:
            typer.echo(json_error("API key may have expired", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        if json_mode:
            typer.echo(json_error(str(e), "API_ERROR"))
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    all_topics: dict[str, list[str]] = {}
    for t in transcripts:
        topic_list = t.summary.topics_list if t.summary else []
        if not topic_list and t.summary and t.summary.keywords:
            topic_list = t.summary.keywords
        for topic in topic_list:
            all_topics.setdefault(topic, []).append(t.title)

    if not all_topics:
        if json_mode:
            typer.echo(json_envelope([], {"days": days}))
        else:
            typer.echo("No topics found.")
        return

    if json_mode:
        results = [
            {"topic": topic, "count": len(meetings), "meetings": meetings}
            for topic, meetings in sorted(all_topics.items(), key=lambda x: -len(x[1]))
        ]
        typer.echo(json_envelope(results, {"days": days}))
    else:
        for topic, meetings in sorted(all_topics.items(), key=lambda x: -len(x[1])):
            count = f" ({len(meetings)})" if len(meetings) > 1 else ""
            typer.echo(f"  {topic}{count}")
