from __future__ import annotations
import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.output import json_error, print_summary_brief


def brief(
    transcript_id: str = typer.Argument(..., help="Transcript ID"),
    table: bool = typer.Option(False, "--table", help="Rich table output"),
) -> None:
    """Show a formatted AI brief for a meeting."""
    json_mode = not table
    config = Config()
    if not config.api_key:
        if json_mode:
            typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key not set. Run: ffx auth", err=True)
        raise typer.Exit(2)

    try:
        client = FirefliesClient(config.api_key)
        t = client.get_transcript(transcript_id)
    except AuthError:
        if json_mode:
            typer.echo(json_error("API key may have expired", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        if json_mode:
            typer.echo(json_error(str(e), "API_ERROR"))
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    if t is None:
        if json_mode:
            typer.echo(json_error("Transcript not found", "NOT_FOUND"))
        else:
            typer.echo(f"Transcript '{transcript_id}' not found.", err=True)
        raise typer.Exit(3)

    print_summary_brief(t, json_mode=json_mode)
