from __future__ import annotations
from typing import Optional
from datetime import datetime, timedelta, timezone

import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.output import json_envelope, json_error, transcripts_table


def search(
    query: str = typer.Argument(..., help="Search query"),
    days: Optional[int] = typer.Option(None, "--days"),
    limit: int = typer.Option(20, "--limit"),
    participant: Optional[list[str]] = typer.Option(None, "--participant", help="Filter by attendee email (repeatable)"),
    table: bool = typer.Option(False, "--table", help="Rich table output"),
) -> None:
    """Search meetings by keyword."""
    json_mode = not table
    config = Config()
    if not config.api_key:
        if json_mode:
            typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key not set. Run: ffx auth", err=True)
        raise typer.Exit(2)

    from_date = None
    if days:
        from_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")

    try:
        client = FirefliesClient(config.api_key)
        transcripts = client.search_transcripts(query, limit=limit, from_date=from_date, participants=participant or None)
    except AuthError:
        if json_mode:
            typer.echo(json_error("API key may have expired", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        if json_mode:
            typer.echo(json_error(str(e), "API_ERROR"))
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    if not transcripts:
        if json_mode:
            typer.echo(json_envelope([], {"query": query}))
        else:
            typer.echo(f"No results found for '{query}'.")
        return

    if json_mode:
        results = [
            {"id": t.id, "title": t.title, "date": t.display_date, "duration_seconds": t.duration}
            for t in transcripts
        ]
        typer.echo(json_envelope(results, {"query": query, "limit": limit}))
    else:
        transcripts_table(transcripts)
