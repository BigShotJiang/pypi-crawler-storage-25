from __future__ import annotations
import csv
import io
import json
from enum import Enum

import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.output import json_error


class ExportFormat(str, Enum):
    json = "json"
    md = "md"
    obsidian = "obsidian"
    csv = "csv"


def _to_md(t) -> str:
    lines = [f"# {t.title}", "", f"**Date:** {t.display_date}"]
    if t.organizer_email:
        lines.append(f"**Organizer:** {t.organizer_email}")
    if t.participants:
        names = ", ".join(t.participants)
        lines.append(f"**Participants:** {names}")
    lines.append("")
    if t.summary and t.summary.overview:
        lines += ["## Overview", "", t.summary.overview, ""]
    if t.summary and t.summary.bullet_gist_list:
        lines += ["## Key Points", ""]
        for b in t.summary.bullet_gist_list:
            lines.append(f"- {b}")
        lines.append("")
    if t.summary and t.summary.action_items_list:
        lines += ["## Action Items", ""]
        for item in t.summary.action_items_list:
            lines.append(f"- [ ] {item}")
        lines.append("")
    if t.summary and t.summary.keywords:
        lines.append(f"**Keywords:** {', '.join(t.summary.keywords)}")
    return "\n".join(lines)


def _yaml_str(s: str) -> str:
    if any(c in s for c in (':', '#', '"', "'", '{', '[', '>', '|', '\n')):
        escaped = s.replace('\\', '\\\\').replace('"', '\\"')
        return f'"{escaped}"'
    return s


def _to_obsidian(t) -> str:
    participants = list(t.participants)
    keywords = (t.summary.keywords if t.summary else []) or []
    frontmatter = [
        "---",
        f"title: {_yaml_str(t.title)}",
        f"date: {t.display_date}",
        f"duration: {t.duration // 60 if t.duration else 0}m",
        f"organizer: {t.organizer_email or ''}",
        "participants:",
    ]
    for p in participants:
        frontmatter.append(f"  - {p}")
    frontmatter.append("tags:")
    for k in keywords:
        frontmatter.append(f"  - {_yaml_str(k)}")
    frontmatter += ["source: fireflies", f"transcript_id: {t.id}", "---", ""]
    md_body = _to_md(t)
    # Strip the first line (# Title) since it's in frontmatter
    body_lines = md_body.split("\n")
    body = "\n".join(body_lines[1:]) if body_lines else ""
    return "\n".join(frontmatter) + body


def _to_csv(t) -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "title", "date", "duration_seconds", "organizer_email", "participants", "overview", "keywords"])
    participants_str = "|".join(t.participants)
    overview = t.summary.overview if t.summary else ""
    keywords = "|".join(t.summary.keywords if t.summary else [])
    writer.writerow([t.id, t.title, t.display_date, t.duration, t.organizer_email or "", participants_str, overview or "", keywords])
    return output.getvalue()


def export(
    transcript_id: str = typer.Argument(..., help="Transcript ID"),
    format: ExportFormat = typer.Option(ExportFormat.json, "--format", help="Output format: json|md|obsidian|csv"),
) -> None:
    """Export a meeting transcript in various formats."""
    config = Config()
    if not config.api_key:
        typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        raise typer.Exit(2)

    try:
        client = FirefliesClient(config.api_key)
        t = client.get_transcript(transcript_id)
    except AuthError:
        typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    if t is None:
        typer.echo(f"Transcript '{transcript_id}' not found.", err=True)
        raise typer.Exit(3)

    if format == ExportFormat.json:
        typer.echo(json.dumps({
            "id": t.id, "title": t.title, "date": t.display_date,
            "duration_seconds": t.duration, "organizer_email": t.organizer_email,
            "participants": t.participants,
            "summary": {
                "overview": t.summary.overview,
                "bullet_gist": t.summary.bullet_gist_list,
                "action_items": t.summary.action_items_list,
                "keywords": t.summary.keywords,
                "topics_discussed": t.summary.topics_list,
            } if t.summary else None,
        }, indent=2))
    elif format == ExportFormat.md:
        typer.echo(_to_md(t))
    elif format == ExportFormat.obsidian:
        typer.echo(_to_obsidian(t))
    elif format == ExportFormat.csv:
        typer.echo(_to_csv(t), nl=False)
