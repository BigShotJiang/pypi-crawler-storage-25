from __future__ import annotations
from typing import Optional
from datetime import datetime, timedelta, timezone

import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.models import ActionItem
from ffx.output import json_envelope, json_error


def action_items(
    days: Optional[int] = typer.Option(7, "--days", help="Last N days"),
    owner: Optional[str] = typer.Option(None, "--filter", help="Filter action items by keyword"),
    limit: int = typer.Option(20, "--limit"),
    table: bool = typer.Option(False, "--table", help="Rich table output"),
) -> None:
    """List action items from recent meetings."""
    json_mode = not table
    config = Config()
    if not config.api_key:
        if json_mode:
            typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key not set. Run: ffx auth", err=True)
        raise typer.Exit(2)

    from_date = None
    if days:
        from_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")

    try:
        client = FirefliesClient(config.api_key)
        transcripts = client.list_transcripts(limit=limit, from_date=from_date)
    except AuthError:
        if json_mode:
            typer.echo(json_error("API key may have expired", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        if json_mode:
            typer.echo(json_error(str(e), "API_ERROR"))
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    all_items: list[ActionItem] = []
    for t in transcripts:
        for item in t.action_items:
            if owner:
                text_lower = item.text.lower()
                assignee_lower = (item.assignee or "").lower()
                if owner.lower() not in text_lower and owner.lower() not in assignee_lower:
                    continue
            all_items.append(item)

    if not all_items:
        if json_mode:
            typer.echo(json_envelope([], {"days": days, "owner": owner}))
        else:
            typer.echo("No action items found.")
        return

    if json_mode:
        results = [
            {"text": i.text, "assignee": i.assignee, "transcript_id": i.transcript_id}
            for i in all_items
        ]
        typer.echo(json_envelope(results, {"days": days, "owner": owner}))
    else:
        for i, item in enumerate(all_items, 1):
            assignee = f" ({item.assignee})" if item.assignee else ""
            typer.echo(f"  {i}. {item.text}{assignee}")
