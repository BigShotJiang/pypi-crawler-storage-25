import typer
from ffx.commands.auth import auth
from ffx.commands.list_cmd import list_cmd
from ffx.commands.get import get
from ffx.commands.search import search
from ffx.commands.summary import summary
from ffx.commands.brief import brief
from ffx.commands.action_items import action_items
from ffx.commands.export import export
from ffx.commands.topics import topics
from ffx.commands.speaker import speaker
from ffx.commands.transcript import transcript
from ffx.commands.week import week, month

app = typer.Typer(name="ffx", help="Fireflies.ai CLI", no_args_is_help=True)

app.command()(auth)
app.command("list")(list_cmd)
app.command()(get)
app.command()(search)
app.command()(summary)
app.command()(brief)
app.command("action-items")(action_items)
app.command()(export)
app.command()(transcript)
app.command()(topics)
app.command()(speaker)
app.command()(week)
app.command()(month)
