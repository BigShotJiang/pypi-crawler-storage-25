from __future__ import annotations
import json
from datetime import datetime, timedelta, timezone

import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.output import json_envelope, json_error, console


def _meeting_summary(transcripts, period_label: str, json_mode: bool) -> None:
    if not transcripts:
        if json_mode:
            typer.echo(json_envelope([], {"period": period_label}))
        else:
            typer.echo(f"No meetings found for {period_label}.")
        return

    total_duration = sum(t.duration or 0 for t in transcripts)
    total_hours = total_duration / 3600

    all_action_items = []
    all_topics = {}
    speaker_time: dict[str, float] = {}

    for t in transcripts:
        all_action_items.extend(t.action_items)
        if t.summary:
            for topic in t.summary.topics_list:
                all_topics[topic] = all_topics.get(topic, 0) + 1
            for kw in t.summary.keywords:
                all_topics[kw] = all_topics.get(kw, 0) + 1
        for s in t.speakers:
            speaker_time[s.name] = speaker_time.get(s.name, 0) + s.duration

    if json_mode:
        typer.echo(json.dumps({
            "period": period_label,
            "meeting_count": len(transcripts),
            "total_hours": round(total_hours, 1),
            "meetings": [
                {"id": t.id, "title": t.title, "date": t.display_date, "duration_seconds": t.duration}
                for t in transcripts
            ],
            "action_items_count": len(all_action_items),
            "top_topics": sorted(all_topics.items(), key=lambda x: -x[1])[:10],
            "speaker_time": {k: round(v, 1) for k, v in sorted(speaker_time.items(), key=lambda x: -x[1])},
        }, indent=2))
    else:
        console.print(f"\n[bold]{period_label}[/bold]\n")
        console.print(f"  {len(transcripts)} meetings  |  {total_hours:.1f} hours  |  {len(all_action_items)} action items\n")

        console.print("  [bold]Meetings:[/bold]")
        for t in transcripts:
            dur = f"{(t.duration or 0) // 60}m"
            console.print(f"    {t.display_date}  {t.title}  ({dur})")
        console.print()

        if all_topics:
            top = sorted(all_topics.items(), key=lambda x: -x[1])[:8]
            topics_str = ", ".join(f"{t}" for t, c in top)
            console.print(f"  [bold]Top topics:[/bold] {topics_str}\n")

        if speaker_time:
            console.print("  [bold]Time by speaker:[/bold]")
            total = sum(speaker_time.values())
            for name, secs in sorted(speaker_time.items(), key=lambda x: -x[1]):
                pct = (secs / total * 100) if total > 0 else 0
                console.print(f"    {name}: {secs / 60:.0f}m ({pct:.0f}%)")
            console.print()

        if all_action_items:
            console.print(f"  [bold]Action items ({len(all_action_items)}):[/bold]")
            for i, item in enumerate(all_action_items[:10], 1):
                typer.echo(f"    {i}. {item.text}")
            if len(all_action_items) > 10:
                typer.echo(f"    ... and {len(all_action_items) - 10} more")


def week(
    table: bool = typer.Option(False, "--table", help="Rich table output"),
) -> None:
    """Show a summary of this week's meetings."""
    _run_period(7, "This Week", not table)


def month(
    table: bool = typer.Option(False, "--table", help="Rich table output"),
) -> None:
    """Show a summary of this month's meetings."""
    _run_period(30, "This Month", not table)


def _run_period(days: int, label: str, json_mode: bool) -> None:
    config = Config()
    if not config.api_key:
        if json_mode:
            typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key not set. Run: ffx auth", err=True)
        raise typer.Exit(2)

    from_date = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")

    try:
        client = FirefliesClient(config.api_key)
        transcripts = client.list_transcripts(limit=100, from_date=from_date)
    except AuthError:
        if json_mode:
            typer.echo(json_error("API key may have expired", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        if json_mode:
            typer.echo(json_error(str(e), "API_ERROR"))
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    _meeting_summary(transcripts, label, json_mode)
