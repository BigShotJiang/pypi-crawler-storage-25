from __future__ import annotations
import json

import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.output import json_error, console


def transcript(
    transcript_id: str = typer.Argument(..., help="Transcript ID"),
    table: bool = typer.Option(False, "--table", help="Rich table output"),
    timestamps: bool = typer.Option(True, "--timestamps/--no-timestamps", help="Show timestamps"),
    speakers: bool = typer.Option(True, "--speakers/--no-speakers", help="Show speaker names"),
) -> None:
    """Show the full transcript text with speaker names and timestamps."""
    json_mode = not table
    config = Config()
    if not config.api_key:
        if json_mode:
            typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key not set. Run: ffx auth", err=True)
        raise typer.Exit(2)

    try:
        client = FirefliesClient(config.api_key)
        t = client.get_transcript_with_sentences(transcript_id)
    except AuthError:
        if json_mode:
            typer.echo(json_error("API key may have expired", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        if json_mode:
            typer.echo(json_error(str(e), "API_ERROR"))
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    if t is None:
        if json_mode:
            typer.echo(json_error("Transcript not found", "NOT_FOUND"))
        else:
            typer.echo(f"Transcript '{transcript_id}' not found.", err=True)
        raise typer.Exit(3)

    if not t.sentences:
        if json_mode:
            typer.echo(json.dumps({"id": t.id, "title": t.title, "sentences": []}, indent=2))
        else:
            typer.echo("No transcript text available for this meeting.")
        return

    if json_mode:
        typer.echo(json.dumps({
            "id": t.id,
            "title": t.title,
            "date": t.display_date,
            "sentences": [
                {
                    "index": s.index,
                    "speaker": s.speaker_name,
                    "text": s.text,
                    "start_time": s.start_time,
                    "end_time": s.end_time,
                }
                for s in t.sentences
            ],
        }, indent=2))
        return

    console.print(f"\n[bold]{t.title}[/bold]  [dim]{t.display_date}[/dim]\n")

    last_speaker = None
    for s in t.sentences:
        parts = []
        if timestamps:
            parts.append(f"[dim]{s.timestamp}[/dim]")
        if speakers and s.speaker_name != last_speaker:
            parts.append(f"[bold]{s.speaker_name}:[/bold]")
            last_speaker = s.speaker_name
        elif speakers:
            parts.append(" " * (len(s.speaker_name) + 1))

        prefix = "  ".join(parts)
        if prefix:
            console.print(f"{prefix}  {s.text}")
        else:
            console.print(s.text)
