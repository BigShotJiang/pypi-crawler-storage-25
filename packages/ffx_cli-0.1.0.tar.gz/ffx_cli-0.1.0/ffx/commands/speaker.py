from __future__ import annotations
import json

import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.output import json_error, console


def speaker(
    transcript_id: str = typer.Argument(..., help="Transcript ID"),
    table: bool = typer.Option(False, "--table", help="Rich table output"),
) -> None:
    """Show speaker analytics for a meeting."""
    json_mode = not table
    config = Config()
    if not config.api_key:
        if json_mode:
            typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key not set. Run: ffx auth", err=True)
        raise typer.Exit(2)

    try:
        client = FirefliesClient(config.api_key)
        t = client.get_transcript(transcript_id)
    except AuthError:
        if json_mode:
            typer.echo(json_error("API key may have expired", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        if json_mode:
            typer.echo(json_error(str(e), "API_ERROR"))
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    if t is None:
        if json_mode:
            typer.echo(json_error("Transcript not found", "NOT_FOUND"))
        else:
            typer.echo(f"Transcript '{transcript_id}' not found.", err=True)
        raise typer.Exit(3)

    if not t.speakers:
        if json_mode:
            typer.echo(json.dumps({"id": t.id, "title": t.title, "speakers": []}, indent=2))
        else:
            typer.echo("No speaker analytics available for this meeting.")
        return

    if json_mode:
        typer.echo(json.dumps({
            "id": t.id,
            "title": t.title,
            "speakers": [
                {
                    "name": s.name,
                    "duration_seconds": s.duration,
                    "duration_pct": round(s.duration_pct, 1),
                    "word_count": s.word_count,
                    "words_per_minute": s.words_per_minute,
                    "filler_words": s.filler_words,
                    "questions": s.questions,
                    "longest_monologue_seconds": s.longest_monologue,
                    "monologues_count": s.monologues_count,
                }
                for s in t.speakers
            ],
        }, indent=2))
    else:
        console.print(f"\n[bold]{t.title}[/bold]  [dim]{t.display_date}[/dim]\n")
        for s in sorted(t.speakers, key=lambda x: x.duration_pct, reverse=True):
            pct = f"{s.duration_pct:.0f}%"
            bar_len = max(0, min(20, int(s.duration_pct / 5)))
            bar = "\u2588" * bar_len + "\u2591" * (20 - bar_len)
            console.print(f"  [bold]{s.name}[/bold]")
            console.print(f"    {bar} {pct}")
            console.print(f"    {s.word_count} words  |  {s.words_per_minute:.0f} wpm  |  {s.filler_words} fillers  |  {s.questions} questions")
            if s.longest_monologue:
                console.print(f"    Longest monologue: {s.longest_monologue:.0f}s")
            console.print()
