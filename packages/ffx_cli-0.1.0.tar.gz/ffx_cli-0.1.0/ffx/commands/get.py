from __future__ import annotations
import json
import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.output import json_error, transcript_detail


def get(
    transcript_id: str = typer.Argument(..., help="Transcript ID"),
    table: bool = typer.Option(False, "--table", help="Rich table output"),
) -> None:
    """Fetch a single transcript by ID."""
    json_mode = not table
    config = Config()
    if not config.api_key:
        if json_mode:
            typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key not set. Run: ffx auth", err=True)
        raise typer.Exit(2)

    try:
        client = FirefliesClient(config.api_key)
        t = client.get_transcript(transcript_id)
    except AuthError:
        if json_mode:
            typer.echo(json_error("API key may have expired", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        if json_mode:
            typer.echo(json_error(str(e), "API_ERROR"))
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    if t is None:
        if json_mode:
            typer.echo(json_error(f"Transcript {transcript_id!r} not found", "NOT_FOUND"))
        else:
            typer.echo(f"Transcript '{transcript_id}' not found.", err=True)
        raise typer.Exit(3)

    if json_mode:
        typer.echo(json.dumps({
            "id": t.id,
            "title": t.title,
            "date": t.display_date,
            "duration_seconds": t.duration,
            "organizer_email": t.organizer_email,
            "participants": t.participants,
            "summary": {
                "overview": t.summary.overview,
                "gist": t.summary.gist,
                "bullet_gist": t.summary.bullet_gist_list,
                "keywords": t.summary.keywords,
                "topics_discussed": t.summary.topics_list,
                "action_items": t.summary.action_items_list,
            } if t.summary else None,
        }, indent=2))
    else:
        transcript_detail(t)
