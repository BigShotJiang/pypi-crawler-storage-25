import typer
from ffx.config import Config


def auth() -> None:
    """Configure your Fireflies API key."""
    config = Config()

    if config.api_key:
        confirm = typer.confirm("An API key is already set. Overwrite?")
        if not confirm:
            raise typer.Exit(0)

    key = typer.prompt("Enter your Fireflies API key", hide_input=True)
    if not key or not key.strip():
        typer.echo("Error: API key cannot be empty.", err=True)
        raise typer.Exit(1)

    config.set("api_key", key.strip())
    typer.echo("API key saved. Run: ffx list to verify.")
