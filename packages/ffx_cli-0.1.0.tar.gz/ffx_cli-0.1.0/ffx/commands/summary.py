from __future__ import annotations
import json
import typer
from ffx.config import Config
from ffx.api_client import FirefliesClient, AuthError, ApiError
from ffx.output import json_error


def summary(
    transcript_id: str = typer.Argument(..., help="Transcript ID"),
    table: bool = typer.Option(False, "--table", help="Rich table output"),
) -> None:
    """Show the AI-generated summary for a meeting."""
    json_mode = not table
    config = Config()
    if not config.api_key:
        if json_mode:
            typer.echo(json_error("API key not configured", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key not set. Run: ffx auth", err=True)
        raise typer.Exit(2)

    try:
        client = FirefliesClient(config.api_key)
        t = client.get_transcript(transcript_id)
    except AuthError:
        if json_mode:
            typer.echo(json_error("API key may have expired", "UNAUTHENTICATED", "Run: ffx auth"))
        else:
            typer.echo("API key may have expired. Run: ffx auth", err=True)
        raise typer.Exit(2)
    except ApiError as e:
        if json_mode:
            typer.echo(json_error(str(e), "API_ERROR"))
        else:
            typer.echo(f"API error: {e}", err=True)
        raise typer.Exit(2)

    if t is None:
        if json_mode:
            typer.echo(json_error("Transcript not found", "NOT_FOUND"))
        else:
            typer.echo(f"Transcript '{transcript_id}' not found.", err=True)
        raise typer.Exit(3)

    s = t.summary
    has_content = s and (s.overview or s.gist or s.keywords or s.action_items_list or s.topics_list)
    if not has_content:
        if json_mode:
            typer.echo(json.dumps({"id": t.id, "title": t.title, "summary": None}, indent=2))
        else:
            typer.echo("No summary available for this meeting.")
        return

    if json_mode:
        typer.echo(json.dumps({
            "id": t.id,
            "title": t.title,
            "overview": t.summary.overview,
            "gist": t.summary.gist,
            "keywords": t.summary.keywords,
            "topics_discussed": t.summary.topics_list,
            "action_items": t.summary.action_items_list,
        }, indent=2))
    else:
        typer.echo(f"\n{t.title}\n")
        if t.summary.overview:
            typer.echo(f"Overview:\n{t.summary.overview}\n")
        if t.summary.gist:
            typer.echo(f"Gist: {t.summary.gist}\n")
        if t.summary.keywords:
            typer.echo(f"Keywords: {', '.join(t.summary.keywords)}\n")
        if t.summary.topics_list:
            typer.echo(f"Topics: {', '.join(t.summary.topics_list)}\n")
        if t.summary.action_items_list:
            typer.echo("Action items:")
            for item in t.summary.action_items_list:
                typer.echo(f"  - {item}")
