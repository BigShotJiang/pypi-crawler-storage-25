from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from rich.console import Console
from rich.table import Table
from rich import box

console = Console()
err_console = Console(stderr=True)


def json_envelope(results: list[Any], filters: dict | None = None) -> str:
    return json.dumps({
        "source": "fireflies",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "filters": filters or {},
        "results": results,
    }, default=str, indent=2)


def json_error(message: str, code: str, hint: str | None = None) -> str:
    obj: dict[str, Any] = {"error": message, "code": code}
    if hint:
        obj["hint"] = hint
    return json.dumps(obj, indent=2)


def print_json(data: Any) -> None:
    if isinstance(data, str):
        print(data)
    else:
        print(json.dumps(data, default=str, indent=2))


def transcripts_table(transcripts, total: int | None = None) -> None:
    table = Table(box=box.SIMPLE, show_header=True, header_style="bold")
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Title")
    table.add_column("Date", no_wrap=True)
    table.add_column("Duration", no_wrap=True)
    table.add_column("Participants", no_wrap=True)

    for t in transcripts:
        duration_str = f"{t.duration // 60}m" if t.duration else "-"
        participant_names = ", ".join(t.participants[:3])
        if len(t.participants) > 3:
            participant_names += f" +{len(t.participants) - 3}"
        table.add_row(t.id[:8] + "...", t.title, t.display_date, duration_str, participant_names)

    console.print(table)
    if total is not None:
        console.print(f"[dim]Showing {len(transcripts)} of {total} total[/dim]")


def transcript_detail(t) -> None:
    console.print(f"\n[bold]{t.title}[/bold]")
    console.print(f"[dim]{t.display_date}  |  {t.duration // 60 if t.duration else 0}m  |  {t.id}[/dim]\n")

    if t.participants:
        names = ", ".join(t.participants)
        console.print(f"[bold]Participants:[/bold] {names}\n")

    if t.summary and t.summary.overview:
        console.print(f"[bold]Overview:[/bold]\n{t.summary.overview}\n")


def print_summary_brief(t, json_mode: bool = False) -> None:
    if not t.summary:
        if json_mode:
            print_json({"error": "No summary available", "code": "NO_SUMMARY", "id": t.id})
        else:
            console.print("[dim]No summary available for this meeting.[/dim]")
        return

    if json_mode:
        print_json({
            "id": t.id,
            "title": t.title,
            "date": t.display_date,
            "overview": t.summary.overview,
            "gist": t.summary.gist,
            "bullet_gist": t.summary.bullet_gist_list,
            "action_items": t.summary.action_items_list,
            "keywords": t.summary.keywords,
            "topics_discussed": t.summary.topics_list,
        })
        return

    console.print(f"\n[bold]{t.title}[/bold]  [dim]{t.display_date}[/dim]\n")
    if t.summary.gist:
        console.print(f"[bold]In a nutshell:[/bold] {t.summary.gist}\n")
    if t.summary.bullet_gist_list:
        console.print("[bold]Key points:[/bold]")
        for point in t.summary.bullet_gist_list:
            console.print(f"  \u2022 {point}")
        console.print()
    if t.summary.action_items_list:
        console.print("[bold]Action items:[/bold]")
        for item in t.summary.action_items_list:
            console.print(f"  \u2610 {item}")
        console.print()
    if t.summary.topics_list:
        console.print(f"[bold]Topics:[/bold] {', '.join(t.summary.topics_list)}\n")
