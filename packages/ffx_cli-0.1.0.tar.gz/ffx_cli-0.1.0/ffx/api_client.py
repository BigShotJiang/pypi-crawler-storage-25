from __future__ import annotations

from gql import Client, gql
from gql.transport.httpx import HTTPXTransport

from ffx.models import (
    ActionItem,
    Sentence,
    Speaker,
    Summary,
    Topic,
    Transcript,
)

FIREFLIES_API_URL = "https://api.fireflies.ai/graphql"

# participants is [String!] (emails), not objects
# analytics.speakers is the correct path (not speaker_talk_time_percentage)
LIST_TRANSCRIPTS_QUERY = gql("""
    query Transcripts($limit: Int, $skip: Int, $keyword: String, $fromDate: DateTime, $toDate: DateTime, $participants: [String!]) {
        transcripts(limit: $limit, skip: $skip, keyword: $keyword, fromDate: $fromDate, toDate: $toDate, participants: $participants) {
            id
            title
            date
            duration
            organizer_email
            participants
            summary {
                action_items keywords overview gist bullet_gist
                shorthand_bullet outline short_summary short_overview
                meeting_type topics_discussed
            }
            analytics {
                speakers {
                    speaker_id name duration duration_pct word_count
                    words_per_minute filler_words questions
                    longest_monologue monologues_count
                }
            }
        }
    }
""")

GET_TRANSCRIPT_QUERY = gql("""
    query Transcript($id: String!) {
        transcript(id: $id) {
            id
            title
            date
            duration
            organizer_email
            participants
            summary {
                action_items keywords overview gist bullet_gist
                shorthand_bullet outline short_summary short_overview
                meeting_type topics_discussed
            }
            analytics {
                speakers {
                    speaker_id name duration duration_pct word_count
                    words_per_minute filler_words questions
                    longest_monologue monologues_count
                }
            }
        }
    }
""")


GET_TRANSCRIPT_WITH_SENTENCES_QUERY = gql("""
    query Transcript($id: String!) {
        transcript(id: $id) {
            id
            title
            date
            duration
            organizer_email
            participants
            summary {
                action_items keywords overview gist bullet_gist
                shorthand_bullet outline short_summary short_overview
                meeting_type topics_discussed
            }
            analytics {
                speakers {
                    speaker_id name duration duration_pct word_count
                    words_per_minute filler_words questions
                    longest_monologue monologues_count
                }
            }
            sentences {
                index
                speaker_name
                speaker_id
                text
                raw_text
                start_time
                end_time
            }
        }
    }
""")


class AuthError(Exception):
    pass


class ApiError(Exception):
    pass


def _parse_transcript(raw: dict) -> Transcript:
    summary_raw = raw.get("summary") or {}
    analytics_raw = raw.get("analytics") or {}

    # Most summary fields come back as strings (with newlines), not lists.
    # Only keywords is a proper list. We store raw and use .action_items_list etc.
    summary = Summary(
        overview=summary_raw.get("overview"),
        short_overview=summary_raw.get("short_overview"),
        gist=summary_raw.get("gist"),
        short_summary=summary_raw.get("short_summary"),
        bullet_gist=summary_raw.get("bullet_gist"),
        shorthand_bullet=summary_raw.get("shorthand_bullet"),
        action_items=summary_raw.get("action_items"),
        keywords=summary_raw.get("keywords") or [],
        topics_discussed=summary_raw.get("topics_discussed"),
        outline=summary_raw.get("outline"),
        meeting_type=summary_raw.get("meeting_type"),
    )

    participants = raw.get("participants") or []

    speakers = [
        Speaker(
            name=s.get("name", ""),
            speaker_id=s.get("speaker_id"),
            duration=s.get("duration", 0),
            duration_pct=s.get("duration_pct", 0.0),
            word_count=s.get("word_count", 0),
            words_per_minute=s.get("words_per_minute", 0.0),
            filler_words=s.get("filler_words", 0),
            questions=s.get("questions", 0),
            longest_monologue=s.get("longest_monologue", 0),
            monologues_count=s.get("monologues_count", 0),
        )
        for s in (analytics_raw.get("speakers") or [])
    ]

    action_items = [
        ActionItem(text=item, transcript_id=raw.get("id"))
        for item in summary.action_items_list
    ]

    topics = [
        Topic(text=t, transcript_id=raw.get("id"))
        for t in summary.topics_list
    ]

    sentences = [
        Sentence(
            index=s.get("index", 0),
            speaker_name=s.get("speaker_name", ""),
            speaker_id=s.get("speaker_id"),
            text=s.get("text", ""),
            raw_text=s.get("raw_text", ""),
            start_time=s.get("start_time", 0.0),
            end_time=s.get("end_time", 0.0),
        )
        for s in (raw.get("sentences") or [])
    ]

    return Transcript(
        id=raw["id"],
        title=raw.get("title", "Untitled"),
        date=str(raw.get("date", "")),
        duration=raw.get("duration", 0),
        organizer_email=raw.get("organizer_email"),
        participants=participants,
        summary=summary,
        speakers=speakers,
        action_items=action_items,
        topics=topics,
        sentences=sentences,
        raw=raw,
    )


class FirefliesClient:
    def __init__(self, api_key: str) -> None:
        transport = HTTPXTransport(
            url=FIREFLIES_API_URL,
            headers={"Authorization": f"Bearer {api_key}"},
        )
        self._client = Client(transport=transport, fetch_schema_from_transport=False)

    def _execute(self, query, variables: dict | None = None) -> dict:
        try:
            result = self._client.execute(query, variable_values=variables or {})
            return result
        except Exception as e:
            msg = str(e).lower()
            if "429" in str(e) or "rate limit" in msg:
                raise ApiError("rate limit exceeded — retry later") from e
            if "unauthenticated" in msg or "unauthorized" in msg or "401" in str(e):
                raise AuthError("API key missing or expired") from e
            if any(code in str(e) for code in ("500", "502", "503")):
                raise ApiError(f"Fireflies API error: {e}") from e
            raise ApiError(str(e)) from e

    def list_transcripts(
        self,
        limit: int = 10,
        skip: int = 0,
        keyword: str | None = None,
        from_date: str | None = None,
        to_date: str | None = None,
        participants: list[str] | None = None,
    ) -> list[Transcript]:
        vars: dict = {"limit": limit, "skip": skip}
        if keyword:
            vars["keyword"] = keyword
        if from_date:
            vars["fromDate"] = from_date
        if to_date:
            vars["toDate"] = to_date
        if participants:
            vars["participants"] = participants
        result = self._execute(LIST_TRANSCRIPTS_QUERY, vars)
        return [_parse_transcript(t) for t in (result.get("transcripts") or [])]

    def get_transcript(self, transcript_id: str) -> Transcript | None:
        result = self._execute(GET_TRANSCRIPT_QUERY, {"id": transcript_id})
        raw = result.get("transcript")
        if raw is None:
            return None
        return _parse_transcript(raw)

    def get_transcript_with_sentences(self, transcript_id: str) -> Transcript | None:
        result = self._execute(GET_TRANSCRIPT_WITH_SENTENCES_QUERY, {"id": transcript_id})
        raw = result.get("transcript")
        if raw is None:
            return None
        return _parse_transcript(raw)

    def search_transcripts(
        self,
        query: str,
        limit: int = 20,
        from_date: str | None = None,
        to_date: str | None = None,
        participants: list[str] | None = None,
    ) -> list[Transcript]:
        return self.list_transcripts(
            limit=limit,
            keyword=query,
            from_date=from_date,
            to_date=to_date,
            participants=participants,
        )
