import os
import stat
from pathlib import Path

import yaml


def _ffx_home() -> Path:
    home = os.environ.get("FFX_HOME")
    if home:
        return Path(home)
    return Path.home() / ".ffx"


class Config:
    def __init__(self) -> None:
        self._home = _ffx_home()
        self._home.mkdir(parents=True, exist_ok=True)
        self._path = self._home / "config.yaml"

    def _load(self) -> dict:
        if not self._path.exists():
            return {}
        with open(self._path) as f:
            return yaml.safe_load(f) or {}

    def _save(self, data: dict) -> None:
        with open(self._path, "w") as f:
            yaml.safe_dump(data, f)
        self._path.chmod(stat.S_IRUSR | stat.S_IWUSR)

    def get(self, key: str):
        return self._load().get(key)

    def set(self, key: str, value) -> None:
        data = self._load()
        data[key] = value
        self._save(data)

    @property
    def api_key(self) -> str | None:
        return os.environ.get("FIREFLIES_API_KEY") or self.get("api_key")

    @property
    def home(self) -> Path:
        return self._home
