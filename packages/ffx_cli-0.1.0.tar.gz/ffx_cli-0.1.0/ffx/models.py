from dataclasses import dataclass, field
from typing import Any


@dataclass
class ActionItem:
    text: str
    assignee: str | None = None
    speaker: str | None = None
    transcript_id: str | None = None


@dataclass
class Topic:
    text: str
    transcript_id: str | None = None


@dataclass
class Speaker:
    name: str
    speaker_id: str | None = None
    duration: float = 0.0
    duration_pct: float = 0.0
    word_count: int = 0
    words_per_minute: float = 0.0
    filler_words: int = 0
    questions: int = 0
    longest_monologue: float = 0.0
    monologues_count: int = 0


@dataclass
class Summary:
    overview: str | None = None
    short_overview: str | None = None
    gist: str | None = None
    short_summary: str | None = None
    bullet_gist: str | None = None
    shorthand_bullet: str | None = None
    action_items: str | None = None
    keywords: list[str] = field(default_factory=list)
    topics_discussed: str | None = None
    outline: str | None = None
    meeting_type: str | None = None

    @property
    def action_items_list(self) -> list[str]:
        return _split_text(self.action_items)

    @property
    def bullet_gist_list(self) -> list[str]:
        return _split_text(self.bullet_gist)

    @property
    def topics_list(self) -> list[str]:
        return _split_text(self.topics_discussed)


def _split_text(text: str | list | None) -> list[str]:
    if text is None:
        return []
    if isinstance(text, list):
        return text
    return [line.strip() for line in text.strip().split("\n") if line.strip()]


@dataclass
class Sentence:
    index: int
    speaker_name: str
    speaker_id: str | None = None
    text: str = ""
    raw_text: str = ""
    start_time: float = 0.0
    end_time: float = 0.0

    @property
    def timestamp(self) -> str:
        mins = int(self.start_time // 60)
        secs = int(self.start_time % 60)
        return f"{mins:02d}:{secs:02d}"


@dataclass
class Transcript:
    id: str
    title: str
    date: str
    duration: int = 0
    organizer_email: str | None = None
    participants: list[str] = field(default_factory=list)
    summary: Summary | None = None
    speakers: list[Speaker] = field(default_factory=list)
    action_items: list[ActionItem] = field(default_factory=list)
    topics: list[Topic] = field(default_factory=list)
    sentences: list[Sentence] = field(default_factory=list)
    raw: dict[str, Any] | None = None

    @property
    def display_date(self) -> str:
        from datetime import datetime, timezone
        try:
            ts = int(self.date) / 1000
            return datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
        except (ValueError, TypeError):
            return self.date or "unknown"
