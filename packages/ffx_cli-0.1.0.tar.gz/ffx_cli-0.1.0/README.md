# ffx — Fireflies CLI

A command-line tool for the [Fireflies.ai](https://fireflies.ai) API. List meetings, read transcripts, pull action items, view speaker analytics, and export to JSON/Markdown/Obsidian/CSV.

All commands output JSON by default — pipe to `jq`, feed to scripts, or use `--table` for human-readable output.

## Install

```bash
pip install ffx-cli
# or
uv tool install ffx-cli
```

## Setup

Get your API key from [Fireflies Settings](https://app.fireflies.ai/integrations/custom/fireflies) and either:

```bash
ffx auth                              # interactive prompt, stores in ~/.ffx/config.yaml
export FIREFLIES_API_KEY=your-key     # env var, overrides config file
```

## Commands

### Basics

```bash
ffx list                              # recent meetings (JSON)
ffx list --table                      # rich formatted table
ffx list --days 7 --limit 20          # last 7 days, up to 20
ffx list --participant alice@co.com   # filter by attendee (repeatable)

ffx get <id>                          # single meeting details
ffx search "quarterly review"         # keyword search
```

### Summaries & briefs

```bash
ffx summary <id>                      # AI-generated summary
ffx brief <id>                        # formatted brief: gist, key points, action items, topics
ffx brief <id> --table                # rich formatted version
```

### Action items & topics

```bash
ffx action-items                      # action items from last 7 days
ffx action-items --days 30 --filter alice
ffx topics                            # topics across recent meetings
ffx topics <id>                       # topics from one meeting
```

### Full transcript

```bash
ffx transcript <id>                   # full text with speakers + timestamps (JSON)
ffx transcript <id> --table           # readable format with timestamps
ffx transcript <id> --no-timestamps   # just speaker: text
ffx transcript <id> --no-speakers     # just text
```

### Speaker analytics

```bash
ffx speaker <id>                      # talk time, word count, wpm, fillers, questions
ffx speaker <id> --table              # visual bar chart
```

### Weekly & monthly rollups

```bash
ffx week                              # this week: meeting count, hours, action items, top topics
ffx month                             # this month
ffx week --table                      # rich formatted
```

### Export

```bash
ffx export <id>                       # JSON (default)
ffx export <id> --format md           # Markdown
ffx export <id> --format obsidian     # Markdown with YAML frontmatter
ffx export <id> --format csv          # CSV
```

## Scripting examples

```bash
# Get all action items from last week as JSON
ffx action-items --days 7 | jq '.results[].text'

# Export all recent meetings to markdown files
ffx list --limit 50 | jq -r '.results[].id' | while read id; do
  ffx export "$id" --format md > "meeting-$id.md"
done

# Who talks the most in a meeting?
ffx speaker <id> | jq '.speakers | sort_by(.duration_pct) | reverse | .[0].name'

# Search and get briefs
ffx search "product launch" | jq -r '.results[].id' | xargs -I{} ffx brief {}
```

## Auth

Two methods, env var takes precedence:

| Method | How |
|--------|-----|
| Config file | `ffx auth` stores key in `~/.ffx/config.yaml` (chmod 600) |
| Env var | `export FIREFLIES_API_KEY=your-key` |

## Development

```bash
git clone https://github.com/bobtista/fireflies-cli.git
cd fireflies-cli
uv sync
uv pip install -e .
uv run pytest
```

## License

MIT
