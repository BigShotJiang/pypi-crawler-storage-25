# ffx — Fireflies CLI

## Project

Python CLI tool for the Fireflies.ai GraphQL API. Wraps both primitive API operations
and higher-level workflow commands. Designed for developer scripting, shell pipelines,
and AI agent tooling.

## Dev Setup

```bash
uv sync
uv pip install -e .
```

## Tests

```bash
uv run pytest
uv run pytest --cov=ffx --cov-report=term-missing   # with coverage
```

Test strategy: HTTP requests mocked with `respx`. CLI commands tested with
`typer.testing.CliRunner`. Config tests use `tmp_path` + `FFX_HOME` env override.

## Build and Publish

```bash
uv build
uv publish   # requires PYPI_API_TOKEN env var
```

CI/CD: GitHub Actions triggers on git tag push → tests → build → publish.

## Locked Architecture Decisions

These were decided during design review. Do not change without a documented reason.

**CLI framework: Typer** (not Click)
- Type hint-driven argument parsing
- Auto-generates `--help` from docstrings
- Better DX for flat command tree design

**GraphQL client: gql[httpx]** via `HTTPXTransport` (not raw httpx)
- Handles GraphQL error envelope automatically
- Standard Python GraphQL client as of 2025

**API-direct architecture** (no local SQLite cache)
- All commands hit the Fireflies API directly
- No sync layer, no local DB, no cache
- Simpler, fewer failure modes, always-fresh data

## Dropped from Scope

- `ffx objections` — pattern-matched from summary text, unreliable. Do not add back
  without a structured Fireflies API field or explicit --llm flag.
- `ffx risks` — same reason as objections.
- `ffx sync` / local SQLite — dropped after review. API-direct is simpler and sufficient.
  Commits exist in git history if ever needed.
- `ffx serve --webhook` — cron + `ffx` commands covers this.
- MCP adapter — Fireflies already has one.
- `ffx export notion` — OAuth complexity for niche use case.

## Project Structure

```
ffx/
├── __init__.py
├── api_client.py    # Fireflies GraphQL client (gql + httpx)
├── models.py        # Dataclasses: Transcript, ActionItem, Speaker, Topic, Summary
├── config.py        # Config file (~/.ffx/config.yaml) read/write
├── output.py        # Rich terminal formatting + JSON envelope
└── commands/
    ├── __init__.py
    ├── auth.py          # ffx auth
    ├── list_cmd.py      # ffx list
    ├── get.py           # ffx get
    ├── search.py        # ffx search
    ├── summary.py       # ffx summary
    ├── export.py        # ffx export
    ├── brief.py         # ffx brief
    ├── action_items.py  # ffx action-items
    ├── topics.py        # ffx topics
    ├── speaker.py       # ffx speaker
    └── week.py          # ffx week / ffx month
tests/
├── conftest.py      # Shared fixtures
├── test_api_client.py
├── test_config.py
└── test_commands/
    └── test_*.py    # One test file per command
```

## Fireflies API Notes

- Endpoint: `https://api.fireflies.ai/graphql`
- Auth: `Authorization: Bearer <api_key>`
- `participants` field is `[String!]` (emails), not objects
- Summary fields (`action_items`, `bullet_gist`, `topics_discussed`, `outline`,
  `shorthand_bullet`) are **strings** (newline-delimited), not lists. Only `keywords`
  is a proper list. Use `Summary.*_list` properties to split into lists.
- Speaker analytics path: `analytics.speakers` (not `speaker_talk_time_percentage`)
- Speaker fields: `name`, `speaker_id`, `duration`, `duration_pct`, `word_count`,
  `words_per_minute`, `filler_words`, `questions`, `longest_monologue`, `monologues_count`

## Error Handling

Standard exit codes:
- 0: success
- 1: user error (bad flag, missing required arg)
- 2: API error (Fireflies unreachable, rate limit exhausted)
- 3: not found

JSON error envelope (always use in `--json` mode):
```json
{"error": "message", "code": "ERROR_CODE", "hint": "Run: ffx auth"}
```

On AuthError: print "API key may have expired. Run: ffx auth"

## Output Conventions

Standard JSON wrapper (all list-returning commands):
```json
{"source": "fireflies", "generated_at": "ISO_TIMESTAMP", "filters": {}, "results": []}
```

Global flags all commands support: `--json`
List commands also support: `--days N`, `--limit N`

Default `--limit` for `ffx list`: 10.

## References

- Fireflies API docs: https://docs.fireflies.ai
- CEO plan: ~/.gstack/projects/fireflies-cli/ceo-plans/2026-03-27-ffx-cli.md
