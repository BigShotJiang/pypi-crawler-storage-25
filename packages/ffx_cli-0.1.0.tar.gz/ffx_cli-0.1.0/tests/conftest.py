import pytest


@pytest.fixture
def api_key_env(tmp_path, monkeypatch):
    """Set up a temp FFX_HOME with an API key configured."""
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key-fixture")
    return tmp_path
