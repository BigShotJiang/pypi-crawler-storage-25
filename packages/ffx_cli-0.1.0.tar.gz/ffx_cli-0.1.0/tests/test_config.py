from ffx.config import Config


def test_get_set_api_key(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    config = Config()
    config.set("api_key", "test-key-123")
    assert config.get("api_key") == "test-key-123"


def test_config_file_chmod(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    config = Config()
    config.set("api_key", "test-key-123")
    config_file = tmp_path / "config.yaml"
    assert config_file.exists()
    mode = oct(config_file.stat().st_mode)[-3:]
    assert mode == "600"


def test_missing_key_returns_none(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    config = Config()
    assert config.get("api_key") is None


def test_api_key_property(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    config = Config()
    assert config.api_key is None
    config.set("api_key", "sk-abc")
    assert config.api_key == "sk-abc"


def test_env_var_overrides_config(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    monkeypatch.setenv("FIREFLIES_API_KEY", "env-key-999")
    config = Config()
    config.set("api_key", "config-key")
    assert config.api_key == "env-key-999"


def test_env_var_used_when_no_config(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    monkeypatch.setenv("FIREFLIES_API_KEY", "env-key-only")
    config = Config()
    assert config.api_key == "env-key-only"
