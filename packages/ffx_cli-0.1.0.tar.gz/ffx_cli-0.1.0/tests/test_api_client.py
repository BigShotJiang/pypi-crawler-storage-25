import pytest
import respx
import httpx
from ffx.api_client import FirefliesClient, AuthError, ApiError


GRAPHQL_URL = "https://api.fireflies.ai/graphql"

TRANSCRIPT_LIST_RESPONSE = {
    "data": {
        "transcripts": [
            {
                "id": "abc123",
                "title": "Test Meeting",
                "date": "1711497600000",
                "duration": 3600,
                "organizer_email": "user@example.com",
                "participants": ["alice@example.com"],
                "summary": {
                    "action_items": "Follow up with Bob",
                    "keywords": ["project"],
                    "overview": "Discussed Q2 plans",
                    "gist": "Planning meeting",
                    "bullet_gist": "Reviewed roadmap",
                    "shorthand_bullet": None,
                    "notes": None,
                    "topics_discussed": "roadmap",
                },
                "analytics": {
                    "speakers": [
                        {"speaker_id": "1", "name": "Alice", "duration": 1800, "word_count": 500, "filler_words": 10}
                    ]
                }
            }
        ]
    }
}


@respx.mock
def test_list_transcripts():
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=TRANSCRIPT_LIST_RESPONSE))
    client = FirefliesClient("test-key")
    transcripts = client.list_transcripts(limit=10)
    assert len(transcripts) == 1
    assert transcripts[0].id == "abc123"
    assert transcripts[0].title == "Test Meeting"


@respx.mock
def test_get_transcript():
    response = {"data": {"transcript": TRANSCRIPT_LIST_RESPONSE["data"]["transcripts"][0]}}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=response))
    client = FirefliesClient("test-key")
    t = client.get_transcript("abc123")
    assert t.id == "abc123"
    assert t.summary.overview == "Discussed Q2 plans"


@respx.mock
def test_get_transcript_not_found():
    response = {"data": {"transcript": None}}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=response))
    client = FirefliesClient("test-key")
    result = client.get_transcript("nonexistent")
    assert result is None


@respx.mock
def test_auth_error_raises():
    response = {"errors": [{"message": "Unauthorized", "extensions": {"code": "UNAUTHENTICATED"}}]}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=response))
    client = FirefliesClient("bad-key")
    with pytest.raises(AuthError):
        client.list_transcripts()


@respx.mock
def test_api_error_raises():
    response = {"errors": [{"message": "Internal server error"}]}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=response))
    client = FirefliesClient("test-key")
    with pytest.raises(ApiError):
        client.list_transcripts()


@respx.mock
def test_http_error_raises_api_error():
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(500))
    client = FirefliesClient("test-key")
    with pytest.raises(ApiError):
        client.list_transcripts()


@respx.mock
def test_rate_limit_raises_api_error():
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(429))
    client = FirefliesClient("test-key")
    with pytest.raises(ApiError, match="rate limit"):
        client.list_transcripts()


@respx.mock
def test_search_transcripts():
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=TRANSCRIPT_LIST_RESPONSE))
    client = FirefliesClient("test-key")
    results = client.search_transcripts("Q2")
    assert len(results) == 1
