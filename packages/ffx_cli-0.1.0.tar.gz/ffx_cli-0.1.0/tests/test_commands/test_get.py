import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

TRANSCRIPT = {
    "id": "abc123",
    "title": "Q2 Planning",
    "date": "1711497600000",
    "duration": 3600,
    "organizer_email": "user@example.com",
    "participants": ["alice@example.com"],
    "summary": {"action_items": "Follow up", "keywords": ["Q2"], "overview": "Discussed plans",
                "gist": "Planning", "bullet_gist": "Reviewed roadmap", "shorthand_bullet": None,
                "notes": None, "topics_discussed": "roadmap"},
    "analytics": {"speakers": []}
}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_get_transcript(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["get", "abc123"])
    assert result.exit_code == 0
    assert "Q2 Planning" in result.output


@respx.mock
def test_get_not_found(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": None}}))
    result = runner.invoke(app, ["get", "nonexistent"])
    assert result.exit_code == 3


@respx.mock
def test_get_json_mode(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["get", "abc123"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["id"] == "abc123"


def test_get_no_api_key(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    result = runner.invoke(app, ["get", "abc123"])
    assert result.exit_code == 2
    assert "ffx auth" in result.output
