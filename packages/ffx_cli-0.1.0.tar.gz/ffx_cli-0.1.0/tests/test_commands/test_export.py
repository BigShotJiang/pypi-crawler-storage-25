import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

TRANSCRIPT = {
    "id": "abc123", "title": "Q2 Planning", "date": "1711497600000", "duration": 3600,
    "organizer_email": "host@example.com",
    "participants": ["alice@example.com"],
    "summary": {
        "action_items": "Follow up with Bob",
        "keywords": ["Q2", "roadmap"],
        "overview": "Discussed Q2 plans",
        "gist": "Planning", "bullet_gist": "Reviewed roadmap",
        "shorthand_bullet": None, "notes": None,
        "topics_discussed": "roadmap"
    },
    "analytics": {"speakers": []}
}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_export_json(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["export", "abc123", "--format", "json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["id"] == "abc123"


@respx.mock
def test_export_md(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["export", "abc123", "--format", "md"])
    assert result.exit_code == 0
    assert "# Q2 Planning" in result.output
    assert "Discussed Q2 plans" in result.output


@respx.mock
def test_export_obsidian(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["export", "abc123", "--format", "obsidian"])
    assert result.exit_code == 0
    assert "---" in result.output
    assert "title:" in result.output
    assert "date:" in result.output
    assert "participants:" in result.output
    assert "tags:" in result.output


@respx.mock
def test_export_csv(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["export", "abc123", "--format", "csv"])
    assert result.exit_code == 0
    assert "id,title,date" in result.output


@respx.mock
def test_export_not_found(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": None}}))
    result = runner.invoke(app, ["export", "missing", "--format", "json"])
    assert result.exit_code == 3
