import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

LIST_RESPONSE = {
    "data": {
        "transcripts": [
            {
                "id": "abc123",
                "title": "Q2 Planning",
                "date": "1711497600000",
                "duration": 3600,
                "organizer_email": None,
                "participants": [],
                "summary": {"action_items": None, "keywords": [], "overview": None, "gist": None,
                            "bullet_gist": None, "shorthand_bullet": None, "notes": None, "topics_discussed": None},
                "analytics": {"speakers": []}
            }
        ]
    }
}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_search_returns_results(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["search", "Q2"])
    assert result.exit_code == 0
    assert "Q2 Planning" in result.output


@respx.mock
def test_search_no_results(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    empty = {"data": {"transcripts": []}}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=empty))
    result = runner.invoke(app, ["search", "zzznothing", "--table"])
    assert result.exit_code == 0
    assert "No results" in result.output


@respx.mock
def test_search_with_participant_filter(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    route = respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["search", "Q2", "--participant", "alice@example.com"])
    assert result.exit_code == 0
    request_body = json.loads(route.calls[0].request.content)
    assert request_body["variables"]["participants"] == ["alice@example.com"]
    assert request_body["variables"]["keyword"] == "Q2"


@respx.mock
def test_search_json_mode(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["search", "Q2"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["source"] == "fireflies"
