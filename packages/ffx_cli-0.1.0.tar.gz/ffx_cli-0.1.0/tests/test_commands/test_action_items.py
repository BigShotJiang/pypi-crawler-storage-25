import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

TRANSCRIPT = {
    "id": "abc123", "title": "Q2 Planning", "date": "1711497600000", "duration": 3600,
    "organizer_email": None, "participants": [],
    "summary": {
        "action_items": "@Alice: Follow up with Bob\nSchedule demo",
        "keywords": [], "overview": None, "gist": None,
        "bullet_gist": None, "shorthand_bullet": None, "notes": None, "topics_discussed": None
    },
    "analytics": {"speakers": []}
}

LIST_RESPONSE = {"data": {"transcripts": [TRANSCRIPT]}}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_action_items_shows_items(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["action-items"])
    assert result.exit_code == 0
    assert "Schedule demo" in result.output


@respx.mock
def test_action_items_json_mode(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["action-items"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["source"] == "fireflies"
    assert len(data["results"]) > 0


@respx.mock
def test_action_items_empty(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    empty = {
        "data": {
            "transcripts": [{**TRANSCRIPT, "summary": {
                "action_items": None, "keywords": [], "overview": None, "gist": None,
                "bullet_gist": None, "shorthand_bullet": None, "notes": None, "topics_discussed": None
            }}]
        }
    }
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=empty))
    result = runner.invoke(app, ["action-items", "--table"])
    assert result.exit_code == 0
    assert "No action items" in result.output
