from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()


def test_auth_stores_key(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    result = runner.invoke(app, ["auth"], input="test-api-key-123\n")
    assert result.exit_code == 0
    assert "API key saved" in result.output


def test_auth_empty_key_rejected(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    result = runner.invoke(app, ["auth"], input="\n")
    assert result.exit_code == 1


def test_auth_shows_confirmation_when_key_exists(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    runner.invoke(app, ["auth"], input="first-key\n")
    result = runner.invoke(app, ["auth"], input="y\nnew-key\n")
    assert result.exit_code == 0


def test_auth_key_stored_with_correct_permissions(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    runner.invoke(app, ["auth"], input="test-key\n")
    config_file = tmp_path / "config.yaml"
    assert config_file.exists()
    mode = oct(config_file.stat().st_mode)[-3:]
    assert mode == "600"
