import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

TRANSCRIPT = {
    "id": "abc123", "title": "Q2 Planning", "date": "1711497600000", "duration": 3600,
    "organizer_email": None, "participants": [],
    "summary": {
        "action_items": None, "keywords": [], "overview": None, "gist": None,
        "bullet_gist": None, "shorthand_bullet": None, "outline": None,
        "short_summary": None, "short_overview": None, "meeting_type": None,
        "topics_discussed": None,
    },
    "analytics": {"speakers": []},
    "sentences": [
        {"index": 0, "speaker_name": "Alice", "speaker_id": "s1",
         "text": "Hello everyone.", "raw_text": "Hello everyone.",
         "start_time": 10.5, "end_time": 12.0},
        {"index": 1, "speaker_name": "Alice", "speaker_id": "s1",
         "text": "Let's discuss Q2.", "raw_text": "Let's discuss Q2.",
         "start_time": 12.5, "end_time": 15.0},
        {"index": 2, "speaker_name": "Bob", "speaker_id": "s2",
         "text": "Sounds good.", "raw_text": "Sounds good.",
         "start_time": 15.5, "end_time": 17.0},
    ]
}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_transcript_shows_text(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["transcript", "abc123"])
    assert result.exit_code == 0
    assert "Hello everyone." in result.output
    assert "Alice" in result.output
    assert "Bob" in result.output
    assert "Sounds good." in result.output


@respx.mock
def test_transcript_json_mode(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["transcript", "abc123"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["id"] == "abc123"
    assert len(data["sentences"]) == 3
    assert data["sentences"][0]["speaker"] == "Alice"
    assert data["sentences"][0]["text"] == "Hello everyone."
    assert data["sentences"][2]["speaker"] == "Bob"


@respx.mock
def test_transcript_not_found(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": None}}))
    result = runner.invoke(app, ["transcript", "missing"])
    assert result.exit_code == 3


@respx.mock
def test_transcript_no_sentences(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    no_sentences = {**TRANSCRIPT, "sentences": []}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": no_sentences}}))
    result = runner.invoke(app, ["transcript", "abc123", "--table"])
    assert result.exit_code == 0
    assert "No transcript text" in result.output


@respx.mock
def test_transcript_no_timestamps(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["transcript", "abc123", "--no-timestamps"])
    assert result.exit_code == 0
    assert "00:10" not in result.output
    assert "Hello everyone." in result.output


@respx.mock
def test_transcript_no_speakers(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["transcript", "abc123", "--no-speakers"])
    assert result.exit_code == 0
    assert "Hello everyone." in result.output
