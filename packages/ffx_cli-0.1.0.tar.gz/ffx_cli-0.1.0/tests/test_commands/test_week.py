import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

LIST_RESPONSE = {
    "data": {
        "transcripts": [
            {
                "id": "abc123", "title": "Q2 Planning", "date": "1711497600000", "duration": 3600,
                "organizer_email": None, "participants": ["alice@example.com"],
                "summary": {
                    "action_items": "Follow up", "keywords": ["Q2"],
                    "overview": "Plans", "gist": None, "bullet_gist": None,
                    "shorthand_bullet": None, "outline": None, "short_summary": None,
                    "short_overview": None, "meeting_type": None, "topics_discussed": None,
                },
                "analytics": {"speakers": [
                    {"speaker_id": "s1", "name": "Alice", "duration": 1800, "duration_pct": 100,
                     "word_count": 500, "words_per_minute": 167, "filler_words": 10,
                     "questions": 5, "longest_monologue": 120, "monologues_count": 3}
                ]}
            }
        ]
    }
}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_week_shows_summary(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["week", "--table"])
    assert result.exit_code == 0
    assert "This Week" in result.output
    assert "1 meetings" in result.output or "1 meeting" in result.output


@respx.mock
def test_month_shows_summary(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["month", "--table"])
    assert result.exit_code == 0
    assert "This Month" in result.output


@respx.mock
def test_week_json_mode(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["week"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["meeting_count"] == 1
    assert data["period"] == "This Week"


@respx.mock
def test_week_empty(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcripts": []}}))
    result = runner.invoke(app, ["week", "--table"])
    assert result.exit_code == 0
    assert "No meetings" in result.output
