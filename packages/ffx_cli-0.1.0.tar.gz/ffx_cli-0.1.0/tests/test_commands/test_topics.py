import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

TRANSCRIPT = {
    "id": "abc123", "title": "Q2 Planning", "date": "1711497600000", "duration": 3600,
    "organizer_email": None, "participants": [],
    "summary": {
        "action_items": None, "keywords": ["roadmap", "hiring", "Q2"],
        "overview": None, "gist": None, "bullet_gist": None,
        "shorthand_bullet": None, "outline": None, "short_summary": None,
        "short_overview": None, "meeting_type": None,
        "topics_discussed": "roadmap\nhiring\nbudget",
    },
    "analytics": {"speakers": []}
}

LIST_RESPONSE = {"data": {"transcripts": [TRANSCRIPT]}}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_topics_shows_topics(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["topics"])
    assert result.exit_code == 0
    assert "roadmap" in result.output


@respx.mock
def test_topics_json_mode(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["topics"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["source"] == "fireflies"
    assert len(data["results"]) > 0


@respx.mock
def test_topics_for_single_transcript(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["topics", "abc123"])
    assert result.exit_code == 0
    assert "roadmap" in result.output


@respx.mock
def test_topics_empty(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    empty_transcript = {**TRANSCRIPT, "summary": {
        "action_items": None, "keywords": [], "overview": None, "gist": None,
        "bullet_gist": None, "shorthand_bullet": None, "outline": None,
        "short_summary": None, "short_overview": None, "meeting_type": None,
        "topics_discussed": None,
    }}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcripts": [empty_transcript]}}))
    result = runner.invoke(app, ["topics", "--table"])
    assert result.exit_code == 0
    assert "No topics" in result.output
