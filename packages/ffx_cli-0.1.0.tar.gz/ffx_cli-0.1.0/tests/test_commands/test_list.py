import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

LIST_RESPONSE = {
    "data": {
        "transcripts": [
            {
                "id": "abc123",
                "title": "Q2 Planning",
                "date": "1711497600000",
                "duration": 3600,
                "organizer_email": "user@example.com",
                "participants": ["alice@example.com"],
                "summary": {"action_items": None, "keywords": [], "overview": None, "gist": None,
                            "bullet_gist": None, "shorthand_bullet": None, "notes": None, "topics_discussed": None},
                "analytics": {"speakers": []}
            }
        ]
    }
}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_list_shows_transcripts(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    assert "Q2 Planning" in result.output


@respx.mock
def test_list_json_mode(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["source"] == "fireflies"
    assert len(data["results"]) == 1
    assert data["results"][0]["id"] == "abc123"


@respx.mock
def test_list_with_participant_filter(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    route = respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["list", "--participant", "alice@example.com"])
    assert result.exit_code == 0
    request_body = json.loads(route.calls[0].request.content)
    assert "alice@example.com" in request_body["variables"]["participants"]


@respx.mock
def test_list_with_multiple_participants(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    route = respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=LIST_RESPONSE))
    result = runner.invoke(app, ["list", "--participant", "alice@example.com", "--participant", "bob@example.com"])
    assert result.exit_code == 0
    request_body = json.loads(route.calls[0].request.content)
    assert request_body["variables"]["participants"] == ["alice@example.com", "bob@example.com"]


def test_list_no_api_key(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 2
    assert "ffx auth" in result.output


@respx.mock
def test_list_empty_results(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    empty_response = {"data": {"transcripts": []}}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=empty_response))
    result = runner.invoke(app, ["list", "--table"])
    assert result.exit_code == 0
    assert "No meetings" in result.output


@respx.mock
def test_list_json_empty(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    empty_response = {"data": {"transcripts": []}}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json=empty_response))
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["results"] == []
