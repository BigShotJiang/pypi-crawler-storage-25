import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

TRANSCRIPT = {
    "id": "abc123", "title": "Q2 Planning", "date": "1711497600000", "duration": 3600,
    "organizer_email": None, "participants": [],
    "summary": {
        "action_items": None, "keywords": [], "overview": None, "gist": None,
        "bullet_gist": None, "shorthand_bullet": None, "outline": None,
        "short_summary": None, "short_overview": None, "meeting_type": None,
        "topics_discussed": None,
    },
    "analytics": {"speakers": [
        {"speaker_id": "s1", "name": "Alice", "duration": 1800, "duration_pct": 60,
         "word_count": 500, "words_per_minute": 167, "filler_words": 10,
         "questions": 5, "longest_monologue": 120, "monologues_count": 3},
        {"speaker_id": "s2", "name": "Bob", "duration": 1200, "duration_pct": 40,
         "word_count": 300, "words_per_minute": 150, "filler_words": 5,
         "questions": 2, "longest_monologue": 60, "monologues_count": 1},
    ]}
}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_speaker_shows_analytics(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["speaker", "abc123"])
    assert result.exit_code == 0
    assert "Alice" in result.output
    assert "Bob" in result.output


@respx.mock
def test_speaker_json_mode(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["speaker", "abc123"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data["speakers"]) == 2
    assert data["speakers"][0]["name"] == "Alice"
    assert data["speakers"][0]["word_count"] == 500
    assert data["speakers"][0]["questions"] == 5


@respx.mock
def test_speaker_not_found(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": None}}))
    result = runner.invoke(app, ["speaker", "missing"])
    assert result.exit_code == 3


@respx.mock
def test_speaker_no_analytics(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    no_speakers = {**TRANSCRIPT, "analytics": {"speakers": []}}
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": no_speakers}}))
    result = runner.invoke(app, ["speaker", "abc123", "--table"])
    assert result.exit_code == 0
    assert "No speaker analytics" in result.output
