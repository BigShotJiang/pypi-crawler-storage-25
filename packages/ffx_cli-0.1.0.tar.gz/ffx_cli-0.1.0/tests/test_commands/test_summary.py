import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

TRANSCRIPT_WITH_SUMMARY = {
    "id": "abc123",
    "title": "Q2 Planning",
    "date": "1711497600000",
    "duration": 3600,
    "organizer_email": None,
    "participants": [],
    "summary": {"action_items": "Follow up", "keywords": ["Q2"], "overview": "Discussed Q2 plans",
                "gist": "Planning", "bullet_gist": None, "shorthand_bullet": None, "notes": None, "topics_discussed": None},
    "analytics": {"speakers": []}
}

TRANSCRIPT_NO_SUMMARY = {**TRANSCRIPT_WITH_SUMMARY, "summary": None}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_summary_shows_overview(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT_WITH_SUMMARY}}))
    result = runner.invoke(app, ["summary", "abc123"])
    assert result.exit_code == 0
    assert "Discussed Q2 plans" in result.output


@respx.mock
def test_summary_missing(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT_NO_SUMMARY}}))
    result = runner.invoke(app, ["summary", "abc123", "--table"])
    assert result.exit_code == 0
    assert "No summary" in result.output


@respx.mock
def test_summary_not_found(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": None}}))
    result = runner.invoke(app, ["summary", "abc123"])
    assert result.exit_code == 3
