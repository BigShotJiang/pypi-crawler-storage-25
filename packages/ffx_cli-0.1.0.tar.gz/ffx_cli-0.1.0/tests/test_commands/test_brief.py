import json
import respx
import httpx
from typer.testing import CliRunner
from ffx.commands import app

runner = CliRunner()
GRAPHQL_URL = "https://api.fireflies.ai/graphql"

TRANSCRIPT = {
    "id": "abc123", "title": "Q2 Planning", "date": "1711497600000", "duration": 3600,
    "organizer_email": None, "participants": [],
    "summary": {
        "action_items": "Follow up with Bob\nSchedule demo",
        "keywords": ["Q2", "roadmap"],
        "overview": "Discussed Q2 plans",
        "gist": "A planning meeting for Q2",
        "bullet_gist": "Reviewed roadmap\nAssigned owners",
        "shorthand_bullet": None, "notes": None,
        "topics_discussed": "roadmap\nhiring"
    },
    "analytics": {"speakers": []}
}


def make_env(tmp_path, monkeypatch):
    monkeypatch.setenv("FFX_HOME", str(tmp_path))
    from ffx.config import Config
    Config().set("api_key", "test-key")


@respx.mock
def test_brief_shows_gist_and_bullets(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["brief", "abc123"])
    assert result.exit_code == 0
    assert "A planning meeting for Q2" in result.output
    assert "Reviewed roadmap" in result.output


@respx.mock
def test_brief_json_mode(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": TRANSCRIPT}}))
    result = runner.invoke(app, ["brief", "abc123"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["gist"] == "A planning meeting for Q2"
    assert "Follow up with Bob" in data["action_items"]


@respx.mock
def test_brief_not_found(tmp_path, monkeypatch):
    make_env(tmp_path, monkeypatch)
    respx.post(GRAPHQL_URL).mock(return_value=httpx.Response(200, json={"data": {"transcript": None}}))
    result = runner.invoke(app, ["brief", "missing"])
    assert result.exit_code == 3
