"""Yahoo Finance models directory."""
