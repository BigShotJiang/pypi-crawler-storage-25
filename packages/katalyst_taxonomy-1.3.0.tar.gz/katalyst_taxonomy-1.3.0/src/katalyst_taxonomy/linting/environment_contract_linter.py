"""Cross-plugin linter that validates environment contracts.

For each layer in the taxonomy the linter:

1. Identifies the layer type and collects ``environmentContract`` declarations
   from the layer type definition, its scoped actions, and its CI/CD job
   templates.
2. Merges the required keys into a combined set.
3. Checks every declared environment for the layer against that combined set.
4. Emits **warnings** (not errors) for missing keys.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ..domain.environment_contract import EnvironmentContract
from ..services.action_service import LayerActionsPluginResult, load_layer_actions
from ..services.cicd_service import CICDPluginResult, load_cicd_templates
from ..services.template_service import LayerTypesPluginResult, load_layer_types
from ..taxonomy.environments import EnvironmentDocument
from ..taxonomy.service import (
    DiscoveryStrategy,
    build_default_strategy,
    load_taxonomy,
    qualified_name_for,
)
from ..taxonomy.utils import extract_layer_type

__all__ = [
    "EnvironmentContractLintResult",
    "EnvironmentContractWarning",
    "lint_environment_contracts",
]


@dataclass(frozen=True, slots=True)
class EnvironmentContractWarning:
    """A single missing-key warning."""

    environment_name: str
    layer_qualified_name: str
    layer_type: str
    key: str
    section: str  # "templateReplacements" or "layerTemplates"
    declared_by: str  # e.g. "LayerType 'iac-terragrunt'" or "Action 'plan'"


@dataclass(frozen=True, slots=True)
class EnvironmentContractLintResult:
    """Aggregate result for environment contract linting."""

    warnings: tuple[EnvironmentContractWarning, ...]
    checked_layers: int
    checked_environments: int

    @property
    def has_warnings(self) -> bool:
        return bool(self.warnings)


def lint_environment_contracts(
    path: Path,
    *,
    strategy: DiscoveryStrategy | None = None,
) -> EnvironmentContractLintResult:
    """Validate environment contracts across all plugins."""

    base = path.resolve()
    discovery = strategy or build_default_strategy()

    taxonomy = load_taxonomy(base, strategy=discovery)
    layer_types = load_layer_types(base)
    actions = load_layer_actions(base)
    cicd = load_cicd_templates(base)

    environments_by_name: dict[str, EnvironmentDocument] = {
        env.name: env for env in taxonomy.environments
    }

    warnings: list[EnvironmentContractWarning] = []
    checked_layers = 0
    checked_envs: set[str] = set()

    documents = [doc for doc in taxonomy.documents if doc.taxonomy_node_type == "layer"]

    for document in documents:
        declared_type = extract_layer_type(document)
        if not declared_type:
            continue

        layer_name = qualified_name_for(document, taxonomy.qualified_names)
        layer_envs = document.environments or ()
        if not layer_envs:
            continue

        checked_layers += 1

        # Collect all contracts applicable to this layer type
        contracts = _collect_contracts(declared_type, layer_types, actions, cicd)
        if not contracts:
            continue

        # Merge into combined required keys
        required_replacements: dict[str, str] = {}  # key -> declared_by
        required_layer_templates: dict[str, str] = {}  # key -> declared_by

        for contract, source_label in contracts:
            for key in contract.template_replacements:
                required_replacements.setdefault(key, source_label)
            for key in contract.layer_templates:
                required_layer_templates.setdefault(key, source_label)

        if not required_replacements and not required_layer_templates:
            continue

        # Check each environment
        for env_name in layer_envs:
            env = environments_by_name.get(env_name)
            if env is None:
                continue  # Missing environment is handled by other linters

            checked_envs.add(env_name)

            for key, declared_by in required_replacements.items():
                if key not in env.template_replacements:
                    warnings.append(
                        EnvironmentContractWarning(
                            environment_name=env_name,
                            layer_qualified_name=layer_name,
                            layer_type=declared_type,
                            key=key,
                            section="templateReplacements",
                            declared_by=declared_by,
                        ),
                    )

            layer_template_section = env.layer_templates.get(declared_type, {})
            for key, declared_by in required_layer_templates.items():
                if key not in layer_template_section:
                    warnings.append(
                        EnvironmentContractWarning(
                            environment_name=env_name,
                            layer_qualified_name=layer_name,
                            layer_type=declared_type,
                            key=key,
                            section="layerTemplates",
                            declared_by=declared_by,
                        ),
                    )

    return EnvironmentContractLintResult(
        warnings=tuple(warnings),
        checked_layers=checked_layers,
        checked_environments=len(checked_envs),
    )


def _collect_contracts(
    layer_type: str,
    layer_types: LayerTypesPluginResult,
    actions: LayerActionsPluginResult,
    cicd: CICDPluginResult,
) -> list[tuple[EnvironmentContract, str]]:
    """Return ``(contract, source_label)`` pairs for the given layer type."""

    result: list[tuple[EnvironmentContract, str]] = []

    # Layer type definition
    definition = layer_types.definition(layer_type)
    if definition is not None and not definition.environment_contract.is_empty:
        result.append(
            (definition.environment_contract, f"LayerType '{definition.name}'"),
        )

    # Actions scoped to this layer type
    for action in actions.actions_for_layer_type(layer_type):
        if not action.environment_contract.is_empty:
            result.append(
                (action.environment_contract, f"Action '{action.name}'"),
            )

    # CI/CD job templates for this layer type
    for job in cicd.jobs:
        if job.layer_type == layer_type and not job.environment_contract.is_empty:
            result.append(
                (job.environment_contract, f"JobTemplate '{job.name}'"),
            )

    return result
