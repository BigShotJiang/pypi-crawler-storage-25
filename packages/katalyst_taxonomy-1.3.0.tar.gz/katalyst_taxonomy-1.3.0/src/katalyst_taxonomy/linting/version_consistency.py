"""Bundled template version consistency linter.

Verifies that all version references across bundled template artifacts
agree with a single expected version:
- ``manifest.json`` files (root + per-plugin)
- ``metadata.version`` fields in plugin YAML documents

This is the enforcement layer for Strategy 1 (independent template
versioning): template versions are managed separately from the Python
package version, and this linter ensures they stay internally consistent.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

import yaml


@dataclass(frozen=True, slots=True)
class VersionMismatch:
    """A single version inconsistency found during linting."""

    path: Path
    kind: str  # "manifest" or "yaml_metadata"
    expected_version: str
    found_version: str
    plugin_name: str | None  # name from metadata.name if available


@dataclass(frozen=True, slots=True)
class VersionConsistencyResult:
    """Aggregated result of version consistency linting."""

    expected_version: str
    mismatches: tuple[VersionMismatch, ...]
    checked_manifests: int
    checked_yaml_docs: int

    @property
    def has_issues(self) -> bool:
        """Return True if any mismatches were found."""
        return len(self.mismatches) > 0


def _read_json_dict(path: Path) -> dict[str, Any] | None:
    """Read a JSON file and return as dict, or None on failure."""
    try:
        raw: object = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None

    if not isinstance(raw, dict):
        return None

    return cast(dict[str, Any], raw)


def lint_bundled_version_consistency(
    bundled_path: Path,
    *,
    expected_version: str,
) -> VersionConsistencyResult:
    """Lint bundled template artifacts for version consistency.

    Scans the given directory (expected to be the root of a bundled
    template tree) for ``manifest.json`` files and plugin YAML documents,
    checking that all declared versions match *expected_version*.

    Args:
        bundled_path: Root directory of the bundled template tree.
        expected_version: The version all artifacts should declare.

    Returns:
        A :class:`VersionConsistencyResult` with any mismatches found.
    """
    if not bundled_path.exists() or not bundled_path.is_dir():
        return VersionConsistencyResult(
            expected_version=expected_version,
            mismatches=(),
            checked_manifests=0,
            checked_yaml_docs=0,
        )

    mismatches: list[VersionMismatch] = []
    checked_manifests = 0
    checked_yaml_docs = 0

    # ── 1. Check manifest.json files ────────────────────────────
    for manifest_path in bundled_path.rglob("manifest.json"):
        checked_manifests += 1
        data = _read_json_dict(manifest_path)
        if data is None:
            continue

        version_val: str | None = data.get("version")
        if version_val is None:
            # No version key — nothing to check
            continue

        found = str(version_val)
        if found != expected_version:
            name_val: str | None = data.get("name")
            mismatches.append(
                VersionMismatch(
                    path=manifest_path,
                    kind="manifest",
                    expected_version=expected_version,
                    found_version=found,
                    plugin_name=str(name_val) if name_val is not None else None,
                ),
            )

    # ── 2. Check metadata.version in plugin YAML documents ─────
    for yaml_path in bundled_path.rglob("*.yaml"):
        try:
            content = yaml_path.read_text(encoding="utf-8")
            raw_docs: Any = yaml.safe_load_all(content)
            for raw_doc in raw_docs:
                if not isinstance(raw_doc, dict):
                    continue
                doc = cast(dict[str, Any], raw_doc)

                api_version: str = str(doc.get("apiVersion", ""))
                if not api_version.startswith("katalyst.taxonomy.plugins"):
                    continue

                metadata_raw: object = doc.get("metadata")
                if not isinstance(metadata_raw, dict):
                    continue
                metadata = cast(dict[str, Any], metadata_raw)

                checked_yaml_docs += 1

                version: str | None = metadata.get("version")
                if version is None:
                    continue

                if str(version) != expected_version:
                    name_raw: str = str(metadata.get("name", "<unknown>"))
                    mismatches.append(
                        VersionMismatch(
                            path=yaml_path,
                            kind="yaml_metadata",
                            expected_version=expected_version,
                            found_version=str(version),
                            plugin_name=name_raw,
                        ),
                    )
        except (yaml.YAMLError, OSError):
            continue

    return VersionConsistencyResult(
        expected_version=expected_version,
        mismatches=tuple(mismatches),
        checked_manifests=checked_manifests,
        checked_yaml_docs=checked_yaml_docs,
    )
