"""V2 registry-driven plugin linting.

Provides ``lint_v2_plugin`` which validates plugin YAML documents
against the v2 generated JSON schemas, using the node type registry
to resolve schema paths dynamically.

This is the v2 replacement for the per-plugin ``_PLUGIN_CONFIGS`` in
``plugin_linter.py``. It can lint any document whose ``kind`` is
registered in the v2 registry.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping, cast

import yaml
from jsonschema import Draft202012Validator

from katalyst_taxonomy.engine.bridge import get_default_registry
from katalyst_taxonomy.engine.generated import SCHEMAS_DIR
from katalyst_taxonomy.engine.registry import NodeTypeRegistry
from katalyst_taxonomy.linting.models import LintViolation, PluginLintResult


def lint_v2_documents(
    base_path: Path,
    directories: tuple[str, ...],
    *,
    registry: NodeTypeRegistry | None = None,
) -> PluginLintResult:
    """Lint YAML documents against v2 generated schemas.

    Scans the given directories for YAML files, identifies documents
    by their ``kind`` field, and validates each against the corresponding
    generated JSON schema from the registry.

    Args:
        base_path: Repository root path.
        directories: Relative directory paths to scan for YAML files.
        registry: Optional registry override (uses default if None).

    Returns:
        PluginLintResult with counts and errors.
    """
    reg = registry or get_default_registry()
    base = base_path.resolve()

    # Collect files
    files: list[Path] = []
    for rel_dir in directories:
        root = base / rel_dir
        if not root.exists():
            continue
        for ext in ("*.yaml", "*.yml"):
            files.extend(sorted(root.rglob(ext)))

    # Load validators lazily
    validators: dict[str, Draft202012Validator] = {}
    schema_paths: dict[str, Path] = {}
    counts: dict[str, int] = {}
    labels: dict[str, str] = {}
    errors: list[LintViolation] = []

    for candidate in files:
        try:
            with candidate.open("r", encoding="utf-8") as stream:
                for index, document in enumerate(yaml.safe_load_all(stream), start=1):
                    if not isinstance(document, dict):
                        continue
                    doc: dict[str, Any] = cast(dict[str, Any], document)

                    kind: str | None = doc.get("kind")
                    if not isinstance(kind, str):
                        continue

                    # Only lint kinds we know about
                    desc = reg.get(kind)
                    if desc is None:
                        # Try lowercase
                        desc = reg.get(kind.lower())
                    if desc is None:
                        continue

                    # Lazy-load validator for this kind
                    if desc.kind not in validators:
                        schema = _load_v2_schema(desc.kind)
                        if schema is not None:
                            validators[desc.kind] = Draft202012Validator(schema)
                            schema_paths[desc.kind] = SCHEMAS_DIR / f"{desc.kind}.schema.json"
                            labels[desc.kind] = desc.kind
                            counts[desc.kind] = 0

                    validator = validators.get(desc.kind)
                    if validator is None:
                        continue

                    counts[desc.kind] = counts.get(desc.kind, 0) + 1
                    node_name: str = _extract_name(doc)

                    # Validate the spec portion
                    spec = cast(dict[str, Any], doc.get("spec", {}))
                    for violation in validator.iter_errors(spec):  # type: ignore[arg-type]
                        errors.append(
                            LintViolation(
                                path=candidate,
                                document_index=index,
                                node_name=node_name,
                                node_type=desc.kind,
                                qualified_name=node_name,
                                message=str(violation.message),
                                group_key="schema",
                                group_label="Schema validation",
                                hint=None,
                            ),
                        )

        except yaml.YAMLError as exc:
            errors.append(
                LintViolation(
                    path=candidate,
                    document_index=0,
                    node_name="",
                    node_type="unknown",
                    qualified_name="",
                    message=f"YAML error: {exc}",
                    group_key="yaml",
                    group_label="YAML parse error",
                    hint=None,
                ),
            )

    return PluginLintResult(
        name="v2-registry",
        counts=counts,
        schema_paths=schema_paths,
        labels=labels,
        errors=tuple(errors),
    )


def _load_v2_schema(kind: str) -> dict[str, Any] | None:
    """Load a v2 generated JSON schema by kind name.

    Extension metadata fields (extends_target_kind, extends_target_names,
    activation_requires) are removed from the required list because they
    are stored in a different shape in the YAML (nested ``extends`` /
    ``metadata.requires``) and parsed by ``Document.from_dict()``.
    """
    schema_path = SCHEMAS_DIR / f"{kind}.schema.json"
    if not schema_path.exists():
        return None
    with open(schema_path) as f:
        schema = json.load(f)

    # Strip extension/activation fields from required — they live in
    # metadata or nested extends blocks, not flat in spec.
    _STRUCTURAL_FIELDS = {"extends_target_kind", "extends_target_names", "activation_requires"}
    required = schema.get("required", [])
    if required:
        schema["required"] = [r for r in required if r not in _STRUCTURAL_FIELDS]

    return schema


def _extract_name(mapping: Mapping[str, object]) -> str:
    metadata = mapping.get("metadata")
    if isinstance(metadata, dict):
        meta: dict[str, Any] = cast(dict[str, Any], metadata)
        raw_name: str = str(meta.get("name", ""))
        if raw_name:
            return raw_name
    return ""
