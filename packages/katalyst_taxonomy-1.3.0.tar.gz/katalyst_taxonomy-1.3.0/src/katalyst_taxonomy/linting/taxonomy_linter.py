"""Linting helpers for taxonomy documents."""

from __future__ import annotations

import json
from collections.abc import Mapping as MappingABC
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence, cast

import yaml
from jsonschema import Draft202012Validator, ValidationError
from referencing import Registry

from ..engine.parsing import V1_API_VERSION as API_VERSION
from ..engine.parsing import V1_KIND as KIND
from ..parsing.frontmatter import ParseError, parse_frontmatter
from ..taxonomy.discovery.filesystem import DiscoveryStrategy
from ..taxonomy.environments import ENVIRONMENT_KIND
from ..taxonomy.ignore import IGNOREFILE_NAME, load_ignore
from ..taxonomy.service import build_default_strategy, load_taxonomy, qualified_name_for
from ._shared import classify_validation_error, hint_for_group
from .models import LintViolation
from .schema_registry import find_schemas_dir, get_registry

TaxonomyLintError = LintViolation


@dataclass(frozen=True, slots=True)
class TaxonomyLintResult:
    """Summary of taxonomy linting."""

    checked_documents: int
    checked_environment_documents: int
    errors: tuple[LintViolation, ...]
    schema_path: Path
    environment_schema_path: Path


def lint_taxonomy_nodes(
    path: Path,
    *,
    schema_path: Path | None = None,
    strategy: DiscoveryStrategy | None = None,
) -> TaxonomyLintResult:
    """Validate taxonomy nodes beneath ``path`` using the taxonomy node JSON Schema."""

    base = path.resolve()
    if not base.exists():
        raise FileNotFoundError(f"Taxonomy path does not exist: {base}")

    schema, resolved_schema = _load_schema(schema_path)
    env_schema, env_schema_path = _load_environment_schema()
    registry = _build_schema_registry(resolved_schema)
    validator = Draft202012Validator(schema, registry=registry)
    env_validator = Draft202012Validator(env_schema, registry=registry)
    discovery = strategy or build_default_strategy()

    node_context = _build_node_context(base, discovery)
    candidates = _discover_candidates(base, discovery)
    ignore = load_ignore(base)

    errors: list[LintViolation] = []
    checked = 0
    checked_env = 0
    layer_directories: set[Path] = set()

    for candidate in candidates:
        if ignore and ignore.should_ignore(candidate, is_dir=candidate.is_dir()):
            continue
        if not candidate.is_file():
            continue
        if any(
            layer_dir in candidate.parents and candidate.parent != layer_dir
            for layer_dir in layer_directories
        ):
            continue

        contains_layer = False
        candidate_abs = candidate.resolve()

        if candidate.suffix.lower() == ".md":
            # --- Markdown file: single document from front matter ---
            checked, checked_env, contains_layer = _lint_markdown_file(
                candidate,
                candidate_abs,
                validator,
                env_validator,
                node_context,
                errors,
                checked,
                checked_env,
            )
        else:
            # --- YAML file: multi-document ---
            checked, checked_env, contains_layer = _lint_yaml_file(
                candidate,
                candidate_abs,
                validator,
                env_validator,
                node_context,
                errors,
                checked,
                checked_env,
            )

        if contains_layer:
            layer_directories.add(candidate.parent)

    # --- Label reference validation ------------------------------------------
    # After schema validation, check that well-known label keys reference
    # documents that actually exist in the taxonomy.
    errors.extend(_validate_label_references(base, discovery))

    return TaxonomyLintResult(
        checked_documents=checked,
        checked_environment_documents=checked_env,
        errors=tuple(errors),
        schema_path=resolved_schema,
        environment_schema_path=env_schema_path,
    )


def _extract_node_identity(mapping: Mapping[str, object]) -> tuple[str, str]:
    node_name = ""
    metadata = mapping.get("metadata")
    if isinstance(metadata, MappingABC):
        metadata_map = cast(Mapping[str, object], metadata)
        raw_name: object = metadata_map.get("name")
        if raw_name is not None:
            node_name = str(raw_name)

    node_type = ""
    node_type_value = mapping.get("taxonomyNodeType")
    if node_type_value is not None:
        node_type = str(node_type_value)
    return node_name, node_type


def _discover_candidates(base_path: Path, strategy: DiscoveryStrategy) -> Sequence[Path]:
    candidates: list[Path] = []
    raw_candidates = [
        candidate if candidate.is_absolute() else (base_path / candidate)
        for candidate in strategy.discover(base_path)
        if candidate.name != IGNOREFILE_NAME
    ]
    raw_candidates.sort(key=lambda path: (len(path.parts), str(path)))
    for candidate in raw_candidates:
        candidates.append(candidate)
    return tuple(candidates)


def _load_schema(schema_path: Path | None) -> tuple[dict[str, object], Path]:
    candidate = schema_path
    if candidate is None:
        candidate = _find_schema_file()
    try:
        raw = candidate.read_text(encoding="utf-8")
    except OSError as exc:  # pragma: no cover - surfaced to caller
        raise FileNotFoundError(f"Failed to read schema file: {candidate}") from exc
    return json.loads(raw), candidate


def _build_schema_registry(schema_path: Path) -> Registry:  # type: ignore[type-arg]
    """Build a ``referencing.Registry`` from the ``schemas/`` directory
    containing *schema_path* so that ``$ref`` pointers resolve correctly."""
    schemas_dir = schema_path.resolve().parent
    # Walk up to find the schemas root (the dir containing taxonomy-node.schema.json).
    while schemas_dir != schemas_dir.parent:
        if (schemas_dir / "taxonomy-node.schema.json").exists():
            return get_registry(schemas_dir)
        schemas_dir = schemas_dir.parent
    # Fallback: auto-discover.
    return get_registry(find_schemas_dir())


def _load_environment_schema(schema_path: Path | None = None) -> tuple[dict[str, object], Path]:
    candidate = schema_path
    if candidate is None:
        candidate = _find_environment_schema_file()
    try:
        raw = candidate.read_text(encoding="utf-8")
    except OSError as exc:  # pragma: no cover - surfaced to caller
        raise FileNotFoundError(f"Failed to read schema file: {candidate}") from exc
    return json.loads(raw), candidate


def _find_schema_file() -> Path:
    for directory in _candidate_roots(Path(__file__).resolve()):
        schema_path = directory / "schemas" / "taxonomy-node.schema.json"
        if schema_path.exists():
            return schema_path
    raise FileNotFoundError(
        "Unable to locate schemas/taxonomy-node.schema.json. Pass --schema to specify a path.",
    )


def _find_environment_schema_file() -> Path:
    for directory in _candidate_roots(Path(__file__).resolve()):
        schema_path = directory / "schemas" / "environment.schema.json"
        if schema_path.exists():
            return schema_path
    raise FileNotFoundError("Unable to locate schemas/environment.schema.json.")


def _candidate_roots(start: Path) -> Iterable[Path]:
    current = start.parent
    while True:
        yield current
        if current.parent == current:
            break
        current = current.parent


def _as_mapping(value: object) -> Mapping[str, object] | None:
    if isinstance(value, MappingABC):
        return cast(Mapping[str, object], value)
    return None


def _format_validation_error(error: ValidationError) -> str:
    return str(error.message)


def _unwrap_oneof_errors(error: ValidationError) -> list[ValidationError]:
    """When the coordinator ``oneOf`` fails, extract the sub-errors from the
    best-matching wing schema (the one whose ``taxonomyNodeType`` enum matched).

    Returns the original error in a list if it is not a ``oneOf`` coordinator
    error, preserving backwards compatibility.
    """
    validator_name = error.validator if isinstance(error.validator, str) else str(error.validator)
    if validator_name != "oneOf" or not error.context:
        return [error]

    # Each sub-error in context corresponds to one wing.
    # A wing "almost matched" if its only failures are NOT on taxonomyNodeType
    # (i.e., the type enum matched but something else failed).
    # We detect this by checking if the sub-error is a taxonomyNodeType mismatch.
    best_errors: list[ValidationError] = []
    seen_messages: set[tuple[str, str]] = set()
    for wing_error in error.context:
        path_parts = list(wing_error.absolute_path)
        wing_validator = (
            wing_error.validator
            if isinstance(wing_error.validator, str)
            else str(wing_error.validator)
        )
        # If this sub-error is a taxonomyNodeType mismatch, skip it — wrong wing.
        if wing_validator == "oneOf" and path_parts == ["taxonomyNodeType"]:
            continue
        # Deduplicate: the same error (e.g. missing name) may appear from
        # multiple wings because they share common $ref definitions.
        msg_key = (str(wing_error.message), str(list(wing_error.absolute_path)))
        if msg_key in seen_messages:
            continue
        seen_messages.add(msg_key)
        best_errors.append(wing_error)

    return best_errors if best_errors else [error]


def _lint_single_document(
    mapping: Mapping[str, object],
    *,
    candidate: Path,
    candidate_abs: Path,
    index: int,
    validator: Draft202012Validator,
    env_validator: Draft202012Validator,
    node_context: Mapping[tuple[Path, str], tuple[str, str]],
    errors: list[LintViolation],
    checked: int,
    checked_env: int,
) -> tuple[int, int, bool]:
    """Validate one taxonomy/environment mapping and return updated counters."""
    contains_layer = False
    if mapping.get("apiVersion") != API_VERSION:
        return checked, checked_env, contains_layer
    if mapping.get("kind") == KIND:
        node_name, node_type = _extract_node_identity(mapping)
        qualified_name = _lookup_qualified_name(node_context, candidate_abs, node_name)
        if node_type == "layer":
            contains_layer = True
        checked += 1
        json_instance = cast(dict[str, Any], mapping)
        for raw_violation in validator.iter_errors(json_instance):  # type: ignore[reportUnknownMemberType]
            for violation in _unwrap_oneof_errors(raw_violation):
                group_key, group_label = classify_validation_error(violation)
                hint = hint_for_group(group_key)
                errors.append(
                    TaxonomyLintError(
                        path=candidate,
                        document_index=index,
                        node_name=node_name,
                        node_type=node_type,
                        qualified_name=qualified_name or node_name,
                        message=_format_validation_error(violation),
                        group_key=group_key,
                        group_label=group_label,
                        hint=hint,
                    ),
                )
    elif mapping.get("kind") == ENVIRONMENT_KIND:
        node_name, _ = _extract_node_identity(mapping)
        checked_env += 1
        env_instance = cast(dict[str, Any], mapping)
        for violation in env_validator.iter_errors(env_instance):  # type: ignore[reportUnknownMemberType]
            group_key, group_label = classify_validation_error(violation)
            errors.append(
                TaxonomyLintError(
                    path=candidate,
                    document_index=index,
                    node_name=node_name,
                    node_type="environment",
                    qualified_name=node_name,
                    message=_format_validation_error(violation),
                    group_key=group_key,
                    group_label=group_label,
                    hint=None,
                ),
            )
    return checked, checked_env, contains_layer


def _lint_markdown_file(
    candidate: Path,
    candidate_abs: Path,
    validator: Draft202012Validator,
    env_validator: Draft202012Validator,
    node_context: Mapping[tuple[Path, str], tuple[str, str]],
    errors: list[LintViolation],
    checked: int,
    checked_env: int,
) -> tuple[int, int, bool]:
    """Lint a single markdown taxonomy file (front matter only, one document)."""
    try:
        content = candidate.read_text(encoding="utf-8")
        frontmatter, _body = parse_frontmatter(content, candidate)
        mapping = _as_mapping(frontmatter)
        if mapping:
            return _lint_single_document(
                mapping,
                candidate=candidate,
                candidate_abs=candidate_abs,
                index=1,
                validator=validator,
                env_validator=env_validator,
                node_context=node_context,
                errors=errors,
                checked=checked,
                checked_env=checked_env,
            )
    except ParseError as exc:
        errors.append(
            TaxonomyLintError(
                path=candidate,
                document_index=0,
                node_name="",
                node_type="",
                qualified_name="",
                message=f"Frontmatter error: {exc}",
                group_key="frontmatter",
                group_label="Frontmatter parse error",
                hint=None,
            ),
        )
    except OSError as exc:
        errors.append(
            TaxonomyLintError(
                path=candidate,
                document_index=0,
                node_name="",
                node_type="",
                qualified_name="",
                message=str(exc),
                group_key="io",
                group_label="Filesystem error",
                hint=None,
            ),
        )
    return checked, checked_env, False


def _lint_yaml_file(
    candidate: Path,
    candidate_abs: Path,
    validator: Draft202012Validator,
    env_validator: Draft202012Validator,
    node_context: Mapping[tuple[Path, str], tuple[str, str]],
    errors: list[LintViolation],
    checked: int,
    checked_env: int,
) -> tuple[int, int, bool]:
    """Lint a YAML taxonomy file (multi-document)."""
    contains_layer = False
    try:
        with candidate.open("r", encoding="utf-8") as handle:
            try:
                for index, document in enumerate(yaml.safe_load_all(handle), start=1):
                    mapping = _as_mapping(document)
                    if not mapping:
                        continue
                    checked, checked_env, doc_layer = _lint_single_document(
                        mapping,
                        candidate=candidate,
                        candidate_abs=candidate_abs,
                        index=index,
                        validator=validator,
                        env_validator=env_validator,
                        node_context=node_context,
                        errors=errors,
                        checked=checked,
                        checked_env=checked_env,
                    )
                    if doc_layer:
                        contains_layer = True
            except yaml.YAMLError as exc:
                errors.append(
                    TaxonomyLintError(
                        path=candidate,
                        document_index=0,
                        node_name="",
                        node_type="",
                        qualified_name="",
                        message=f"YAML error: {exc}",
                        group_key="yaml",
                        group_label="YAML parse error",
                        hint=None,
                    ),
                )
    except OSError as exc:
        errors.append(
            TaxonomyLintError(
                path=candidate,
                document_index=0,
                node_name="",
                node_type="",
                qualified_name="",
                message=str(exc),
                group_key="io",
                group_label="Filesystem error",
                hint=None,
            ),
        )
    return checked, checked_env, contains_layer


def _build_node_context(
    base_path: Path,
    strategy: DiscoveryStrategy,
) -> dict[tuple[Path, str], tuple[str, str]]:
    try:
        result = load_taxonomy(base_path, strategy=strategy)
    except FileNotFoundError:
        return {}

    context: dict[tuple[Path, str], tuple[str, str]] = {}
    for document in result.documents:
        if document.source_path is None:
            continue
        key = (document.source_path.resolve(), document.metadata.name)
        fq = qualified_name_for(document, result.qualified_names)
        context[key] = (document.taxonomy_node_type, fq)
    return context


def _lookup_qualified_name(
    context: Mapping[tuple[Path, str], tuple[str, str]],
    path: Path,
    name: str,
) -> str:
    if not name:
        return ""
    entry = context.get((path, name))
    if not entry:
        return ""
    return entry[1]


# Well-known label keys and the taxonomy node types they should reference.
# These semantic label bindings can't be fully derived from the registry
# (they encode domain knowledge about what labels mean), but the set of
# valid target types for each label can be validated against the registry.
_LABEL_REF_TYPES: dict[str, tuple[str, ...]] = {
    "organization": ("organization",),
    "client": ("organization",),
    "program": ("program",),
    "project": ("project",),
    "team": ("team",),
    "client-team": ("team",),
}


def _validate_label_references(
    base_path: Path,
    strategy: DiscoveryStrategy,
) -> list[LintViolation]:
    """Check that well-known label values reference existing taxonomy documents."""
    try:
        result = load_taxonomy(base_path, strategy=strategy)
    except FileNotFoundError:
        return []

    # Build an index of (node_type, name) -> exists
    known_nodes: set[tuple[str, str]] = set()
    for document in result.documents:
        known_nodes.add((document.taxonomy_node_type, document.metadata.name))

    violations: list[LintViolation] = []
    for document in result.documents:
        if not document.metadata.labels:
            continue
        for label_key, expected_types in _LABEL_REF_TYPES.items():
            label_value = document.metadata.labels.get(label_key)
            if not label_value:
                continue
            # Check if any of the expected types has a node with this name
            found = any(
                (expected_type, label_value) in known_nodes for expected_type in expected_types
            )
            if not found:
                type_list = " or ".join(expected_types)
                fq = qualified_name_for(document, result.qualified_names)
                violations.append(
                    LintViolation(
                        path=document.source_path or base_path,
                        document_index=0,
                        node_name=document.metadata.name,
                        node_type=document.taxonomy_node_type,
                        qualified_name=fq,
                        message=(
                            f"Label '{label_key}: {label_value}' references a "
                            f"{type_list} that does not exist in the taxonomy."
                        ),
                        group_key="label-ref",
                        group_label="Label reference",
                        hint=f"Create a {type_list} node named '{label_value}' "
                        f"or update the label.",
                    ),
                )
    return violations
