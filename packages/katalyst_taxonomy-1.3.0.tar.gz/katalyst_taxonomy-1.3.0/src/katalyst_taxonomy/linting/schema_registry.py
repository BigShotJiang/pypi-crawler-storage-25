"""Shared JSON Schema $ref resolution registry.

Builds a ``referencing.Registry`` from all ``.schema.json`` files under
the repository ``schemas/`` tree so that ``Draft202012Validator`` can
resolve cross-file ``$ref`` pointers (e.g. ``../common/plugin-requirement.schema.json``).
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable, cast

from referencing import Registry, Resource
from referencing.jsonschema import DRAFT202012


def build_registry(schemas_dir: Path) -> Registry:  # type: ignore[type-arg]
    """Create a :class:`referencing.Registry` from every ``*.schema.json`` in *schemas_dir*.

    Each schema is registered under its ``$id`` URI (if present) **and** under
    its file-URI derived from its path relative to *schemas_dir*.  The latter
    allows relative ``$ref`` paths (e.g. ``../common/plugin-requirement.schema.json``)
    to resolve correctly.
    """
    schemas_dir = schemas_dir.resolve()
    pairs: list[tuple[str, Resource]] = []  # type: ignore[type-arg]

    for schema_path in _iter_schema_files(schemas_dir):
        try:
            raw = json.loads(schema_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue

        if not isinstance(raw, dict):
            continue

        schema_dict: dict[str, Any] = cast(dict[str, Any], raw)
        resource: Resource = Resource.from_contents(schema_dict, default_specification=DRAFT202012)  # type: ignore[type-arg]

        # Register by canonical $id if present.
        schema_id: str | None = schema_dict.get("$id")  # type: ignore[assignment]
        if isinstance(schema_id, str) and schema_id:
            pairs.append((schema_id, resource))

    registry: Registry = Registry().with_resources(pairs)  # type: ignore[type-arg]
    return registry


def _iter_schema_files(root: Path) -> Iterable[Path]:
    """Yield all ``*.schema.json`` files beneath *root*."""
    for path in root.rglob("*.schema.json"):
        if path.is_file():
            yield path


# ---------------------------------------------------------------------------
# Convenience: locate the schemas directory
# ---------------------------------------------------------------------------


def find_schemas_dir(start: Path | None = None) -> Path:
    """Walk parent directories from *start* looking for a ``schemas/`` directory
    that contains ``taxonomy-node.schema.json``.

    Falls back to walking from this file's location if *start* is not provided.
    """
    origin = (start or Path(__file__)).resolve()
    for directory in _candidate_roots(origin):
        candidate = directory / "schemas"
        if (candidate / "taxonomy-node.schema.json").exists():
            return candidate
    raise FileNotFoundError(
        "Unable to locate the schemas/ directory. "
        "Ensure you are running from within the katalyst-taxonomy repository."
    )


@lru_cache(maxsize=4)
def get_registry(schemas_dir: Path | None = None) -> Registry:  # type: ignore[type-arg]
    """Return a cached :class:`referencing.Registry` for the given schemas directory.

    If *schemas_dir* is ``None``, the directory is auto-discovered.
    """
    resolved = (schemas_dir or find_schemas_dir()).resolve()
    return build_registry(resolved)


def _candidate_roots(start: Path) -> Iterable[Path]:
    current = start.parent
    while True:
        yield current
        if current.parent == current:
            break
        current = current.parent
