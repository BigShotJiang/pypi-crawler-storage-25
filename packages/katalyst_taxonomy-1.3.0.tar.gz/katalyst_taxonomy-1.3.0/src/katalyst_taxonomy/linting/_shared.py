"""Shared helpers for linting modules."""

from __future__ import annotations

from typing import Any, Sequence

from jsonschema.exceptions import ValidationError

SLUG_GROUP_KEY = "metadata.name.pattern"


def classify_validation_error(error: ValidationError) -> tuple[str, str]:
    """Map a validation error to a grouping key and human-friendly label."""

    schema_path = tuple(str(part) for part in error.schema_path)
    # Match the slug pattern rule regardless of oneOf index prefix.
    _slug_suffix = ("properties", "metadata", "properties", "name", "pattern")
    if schema_path == _slug_suffix or schema_path[-len(_slug_suffix) :] == _slug_suffix:
        return (SLUG_GROUP_KEY, "metadata.name (slug or snake_case)")

    validator = error.validator if isinstance(error.validator, str) else str(error.validator)
    group_key = f"{validator}:{'/'.join(schema_path)}"
    instance_path = format_instance_path(error.path)
    label = f"{instance_path} ({validator})" if instance_path else validator
    return group_key, label


def format_instance_path(path: Sequence[Any]) -> str:
    """Convert a JSON Pointer path to dotted notation for display."""

    parts = [str(part) for part in path]
    return ".".join(parts) if parts else "$"


def hint_for_group(group_key: str) -> str | None:
    """Return a remediation hint for well-known rule groups."""

    if group_key == SLUG_GROUP_KEY:
        return "Use lowercase kebab-case or snake_case (e.g., control-tower or control_tower) for metadata.name."
    return None
