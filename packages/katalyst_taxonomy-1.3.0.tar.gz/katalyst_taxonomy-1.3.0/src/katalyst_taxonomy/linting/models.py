"""Shared linting data structures."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class LintViolation:
    """Schema violation or parse failure encountered while linting."""

    path: Path
    document_index: int
    node_name: str
    node_type: str
    qualified_name: str
    message: str
    group_key: str
    group_label: str
    hint: str | None


@dataclass(frozen=True, slots=True)
class PluginLintResult:
    """Aggregated view of plugin linting."""

    name: str
    counts: dict[str, int]
    schema_paths: dict[str, Path]
    labels: dict[str, str]
    errors: tuple[LintViolation, ...]
