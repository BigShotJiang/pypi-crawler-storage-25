"""Linting helpers for validating layer directories against layer type templates."""

from __future__ import annotations

import fnmatch
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

from ..services.template_service import LayerTypeDefinition, PluginDocumentError, load_layer_types
from ..taxonomy.service import (
    DiscoveryStrategy,
    build_default_strategy,
    load_taxonomy,
    qualified_name_for,
)
from ..taxonomy.utils import extract_layer_type

__all__ = [
    "LayerInstanceReport",
    "LayerTemplateIssue",
    "LayerTypeTemplateLintResult",
    "LayerTypeTemplateReport",
    "lint_layer_type_templates",
]


LAYER_FILENAMES = {"layer.yaml", "layer.yml"}


@dataclass(frozen=True, slots=True)
class LayerTemplateIssue:
    """Represents a structural mismatch between a layer and its template."""

    message: str
    relative_path: str | None = None


@dataclass(frozen=True, slots=True)
class LayerInstanceReport:
    """Lint outcome for a single layer directory."""

    layer_name: str
    qualified_name: str
    path: Path | None
    declared_layer_type: str | None
    issues: tuple[LayerTemplateIssue, ...]

    @property
    def is_clean(self) -> bool:
        return not self.issues


@dataclass(frozen=True, slots=True)
class LayerTypeTemplateReport:
    """Aggregated lint results for a single layer type definition."""

    definition: LayerTypeDefinition
    layers: tuple[LayerInstanceReport, ...]

    @property
    def name(self) -> str:
        return self.definition.name

    @property
    def template_path(self) -> Path:
        return self.definition.template_path

    @property
    def has_issues(self) -> bool:
        return any(not layer.is_clean for layer in self.layers)


@dataclass(frozen=True, slots=True)
class LayerTypeTemplateLintResult:
    """Summary of linting all layer directories against their templates."""

    layer_types: tuple[LayerTypeTemplateReport, ...]
    undefined_layer_types: tuple[LayerInstanceReport, ...]
    missing_layer_type: tuple[LayerInstanceReport, ...]
    plugin_errors: tuple[PluginDocumentError, ...]

    @property
    def has_issues(self) -> bool:
        return (
            any(report.has_issues for report in self.layer_types)
            or bool(self.undefined_layer_types)
            or bool(self.missing_layer_type)
        )


@dataclass(frozen=True, slots=True)
class TemplatePlaceholder:
    """Represents a directory subtree that should be replicated per environment."""

    root: Path
    parent: Path
    files: tuple[Path, ...]
    directories: tuple[Path, ...]


@dataclass(frozen=True, slots=True)
class TemplateStructure:
    """Normalized view of a template's static files and placeholders."""

    files: tuple[Path, ...]
    directories: tuple[Path, ...]
    placeholders: tuple[TemplatePlaceholder, ...]


def lint_layer_type_templates(
    path: Path,
    *,
    strategy: DiscoveryStrategy | None = None,
) -> LayerTypeTemplateLintResult:
    """Validate all layers under ``path`` against their layer type templates."""

    base = path.resolve()
    discovery = strategy or build_default_strategy()
    taxonomy = load_taxonomy(base, strategy=discovery)
    layer_types = load_layer_types(base)

    definitions_by_name: dict[str, LayerTypeDefinition] = {
        definition.name: definition for definition in layer_types.definitions
    }
    template_cache: dict[str, TemplateStructure] = {}

    layer_reports: dict[str, list[LayerInstanceReport]] = {}
    undefined_layers: list[LayerInstanceReport] = []
    missing_layers: list[LayerInstanceReport] = []

    documents = [doc for doc in taxonomy.documents if doc.taxonomy_node_type == "layer"]
    qualified = taxonomy.qualified_names

    for document in documents:
        layer_name = document.metadata.name
        qualified_name = qualified_name_for(document, qualified)
        layer_path = document.source_path
        if not layer_path or layer_path.name.lower() not in LAYER_FILENAMES:
            continue
        layer_dir = layer_path.parent
        declared_type = extract_layer_type(document)

        if not declared_type:
            missing_layers.append(
                LayerInstanceReport(
                    layer_name=layer_name,
                    qualified_name=qualified_name,
                    path=layer_dir,
                    declared_layer_type=None,
                    issues=(
                        LayerTemplateIssue(
                            message="Layer is missing a layerType declaration.",
                        ),
                    ),
                ),
            )
            continue

        definition = definitions_by_name.get(declared_type)
        if definition is None:
            undefined_layers.append(
                LayerInstanceReport(
                    layer_name=layer_name,
                    qualified_name=qualified_name,
                    path=layer_dir,
                    declared_layer_type=declared_type,
                    issues=(
                        LayerTemplateIssue(
                            message=f"Layer declares undefined layer type '{declared_type}'.",
                        ),
                    ),
                ),
            )
            continue

        template = template_cache.get(definition.name)
        if template is None:
            template = _build_template_structure(definition.template_path)
            template_cache[definition.name] = template

        issues = _lint_layer_instance(
            layer_dir,
            template,
            document.environments,
            definition.optional_paths,
        )
        report = LayerInstanceReport(
            layer_name=layer_name,
            qualified_name=qualified_name,
            path=layer_dir,
            declared_layer_type=declared_type,
            issues=issues,
        )
        layer_reports.setdefault(definition.name, []).append(report)

    reports: list[LayerTypeTemplateReport] = []
    for definition in sorted(layer_types.definitions, key=lambda item: item.name):
        layers = tuple(
            sorted(layer_reports.get(definition.name, []), key=lambda item: item.qualified_name),
        )
        reports.append(LayerTypeTemplateReport(definition=definition, layers=layers))

    undefined_sorted = tuple(sorted(undefined_layers, key=lambda item: item.qualified_name))
    missing_sorted = tuple(sorted(missing_layers, key=lambda item: item.qualified_name))

    return LayerTypeTemplateLintResult(
        layer_types=tuple(reports),
        undefined_layer_types=undefined_sorted,
        missing_layer_type=missing_sorted,
        plugin_errors=layer_types.errors,
    )


def _lint_layer_instance(
    layer_dir: Path | None,
    template: TemplateStructure,
    environments: Sequence[str],
    optional_paths: Sequence[str],
) -> tuple[LayerTemplateIssue, ...]:
    if layer_dir is None:
        return (
            LayerTemplateIssue(
                message="Layer source path is unavailable; cannot lint template structure.",
            ),
        )

    issues: list[LayerTemplateIssue] = []

    for rel_dir in template.directories:
        target = layer_dir / rel_dir
        if _is_optional(rel_dir, optional_paths):
            continue
        if not target.exists():
            issues.append(
                LayerTemplateIssue(
                    relative_path=_display_rel_path(rel_dir),
                    message="Missing directory defined by template.",
                ),
            )
        elif not target.is_dir():
            issues.append(
                LayerTemplateIssue(
                    relative_path=_display_rel_path(rel_dir),
                    message="Expected directory but found a file.",
                ),
            )

    for rel_file in template.files:
        target = layer_dir / rel_file
        if _is_optional(rel_file, optional_paths):
            continue
        if not target.exists():
            issues.append(
                LayerTemplateIssue(
                    relative_path=_display_rel_path(rel_file),
                    message="Missing file defined by template.",
                ),
            )
        elif not target.is_file():
            issues.append(
                LayerTemplateIssue(
                    relative_path=_display_rel_path(rel_file),
                    message="Expected file but found a directory.",
                ),
            )

    env_list = tuple(dict.fromkeys(environments))
    for placeholder in template.placeholders:
        if not env_list:
            if _is_optional(placeholder.parent, optional_paths):
                continue
            issues.append(
                LayerTemplateIssue(
                    relative_path=_display_rel_path(placeholder.parent),
                    message=(
                        "Template expects environment-specific directories "
                        "but the layer does not declare any environments."
                    ),
                ),
            )
            continue

        for env in env_list:
            env_rel = _join_relative(placeholder.parent, Path(env))
            env_dir = layer_dir / env_rel
            if _is_optional(env_rel, optional_paths):
                continue
            if not env_dir.exists():
                issues.append(
                    LayerTemplateIssue(
                        relative_path=_display_rel_path(env_rel),
                        message=f"Missing environment directory for '{env}'.",
                    ),
                )
                continue
            if not env_dir.is_dir():
                issues.append(
                    LayerTemplateIssue(
                        relative_path=_display_rel_path(env_rel),
                        message=f"Expected '{env}' to be a directory but found a file.",
                    ),
                )
                continue

            for rel_dir in placeholder.directories:
                target_dir = env_dir / rel_dir
                full_rel = _join_relative(env_rel, rel_dir)
                if _is_optional(full_rel, optional_paths):
                    continue
                if not target_dir.exists():
                    issues.append(
                        LayerTemplateIssue(
                            relative_path=_display_rel_path(full_rel),
                            message="Missing directory inside environment overlay.",
                        ),
                    )
                elif not target_dir.is_dir():
                    issues.append(
                        LayerTemplateIssue(
                            relative_path=_display_rel_path(full_rel),
                            message="Expected directory inside environment overlay.",
                        ),
                    )

            for rel_file in placeholder.files:
                target_file = env_dir / rel_file
                full_rel = _join_relative(env_rel, rel_file)
                if _is_optional(full_rel, optional_paths):
                    continue
                if not target_file.exists():
                    issues.append(
                        LayerTemplateIssue(
                            relative_path=_display_rel_path(full_rel),
                            message="Missing file inside environment overlay.",
                        ),
                    )
                elif not target_file.is_file():
                    issues.append(
                        LayerTemplateIssue(
                            relative_path=_display_rel_path(full_rel),
                            message="Expected file inside environment overlay.",
                        ),
                    )

    return tuple(issues)


def _build_template_structure(path: Path) -> TemplateStructure:
    if not path.is_dir():
        return TemplateStructure(files=tuple(), directories=tuple(), placeholders=tuple())

    placeholder_roots = _discover_placeholder_roots(path)
    placeholder_builders: dict[Path, dict[str, set[Path]]] = {
        root: {"files": set(), "dirs": set()} for root in placeholder_roots
    }

    files: set[Path] = set()
    directories: set[Path] = set()

    for candidate in sorted(
        path.rglob("*"),
        key=lambda item: (len(item.relative_to(path).parts), str(item)),
    ):
        rel = candidate.relative_to(path)
        if not rel.parts:
            continue
        placeholder_root = _match_placeholder(rel, placeholder_roots)
        if placeholder_root is not None:
            sub_rel = rel.relative_to(placeholder_root)
            if not sub_rel.parts:
                continue
            section = placeholder_builders[placeholder_root]
            if candidate.is_dir():
                section["dirs"].add(sub_rel)
            else:
                section["files"].add(sub_rel)
            continue

        if candidate.is_dir():
            directories.add(rel)
        else:
            files.add(rel)

    placeholders: list[TemplatePlaceholder] = []
    for root in sorted(placeholder_roots, key=lambda item: (len(item.parts), str(item))):
        parent = root.parent if root.parts else Path()
        if str(parent) == ".":
            parent = Path()
        builder = placeholder_builders[root]
        placeholders.append(
            TemplatePlaceholder(
                root=root,
                parent=parent,
                files=tuple(
                    sorted(builder["files"], key=lambda item: (len(item.parts), str(item))),
                ),
                directories=tuple(
                    sorted(builder["dirs"], key=lambda item: (len(item.parts), str(item))),
                ),
            ),
        )

    return TemplateStructure(
        files=tuple(sorted(files, key=lambda item: (len(item.parts), str(item)))),
        directories=tuple(sorted(directories, key=lambda item: (len(item.parts), str(item)))),
        placeholders=tuple(placeholders),
    )


def _discover_placeholder_roots(path: Path) -> list[Path]:
    roots: list[Path] = []
    for directory in path.rglob("*"):
        if directory.is_dir() and _is_placeholder_dir(directory.name):
            roots.append(directory.relative_to(path))
    roots.sort(key=lambda item: (len(item.parts), str(item)))
    return roots


def _is_placeholder_dir(name: str) -> bool:
    return name.lower().endswith("template")


def _match_placeholder(rel: Path, placeholders: Iterable[Path]) -> Path | None:
    for root in placeholders:
        try:
            rel.relative_to(root)
        except ValueError:
            continue
        return root
    return None


def _join_relative(parent: Path, child: Path) -> Path:
    if not parent.parts:
        return child
    return parent / child


def _display_rel_path(path: Path) -> str:
    if not path.parts:
        return "."
    return str(path)


def _is_optional(path: Path, patterns: Sequence[str]) -> bool:
    if not patterns:
        return False
    candidate = path.as_posix()
    if candidate == "":
        candidate = "."
    return any(fnmatch.fnmatch(candidate, pattern) for pattern in patterns)
