"""Remove service for uninstalling plugins and layer types.

This module contains domain models and service logic for the `kata tax remove` command.
"""

# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Sequence

import yaml

from katalyst_taxonomy.adapters.filesystem.lock import (
    lock_from_mapping,
    lock_to_mapping,
)
from katalyst_taxonomy.domain.lock import (
    InstalledPlugin,
    KatalystLock,
)
from katalyst_taxonomy.ports.filesystem import FilesystemPort, RealFilesystem


class RemoveStatus(Enum):
    """Status of a remove operation."""

    SUCCESS = "success"
    FAILED = "failed"
    NOT_INITIALIZED = "not_initialized"
    NOT_INSTALLED = "not_installed"
    CANCELLED = "cancelled"


def _to_tuple(value: Sequence[str] | None) -> tuple[str, ...]:
    """Convert a sequence to a tuple, or return empty tuple if None."""
    from katalyst_taxonomy.services._util import to_tuple

    return to_tuple(value)


@dataclass(frozen=True)
class RemoveConfig:
    """Configuration for removing components from a taxonomy repository.

    Attributes:
        target_path: Root directory of the taxonomy repository.
        plugins: Tuple of plugin names to remove.
        layer_types: Tuple of layer type names to remove.
        force: If True, remove even if files are modified.
        interactive: If True, prompt for confirmation.
    """

    target_path: Path
    plugins: tuple[str, ...] = ()
    layer_types: tuple[str, ...] = ()
    force: bool = False
    interactive: bool = False

    def __post_init__(self) -> None:
        """Convert sequences to tuples for immutability."""
        if type(self.plugins) is not tuple:
            object.__setattr__(self, "plugins", _to_tuple(self.plugins))  # type: ignore[arg-type]
        if type(self.layer_types) is not tuple:
            object.__setattr__(self, "layer_types", _to_tuple(self.layer_types))  # type: ignore[arg-type]

    @property
    def taxonomy_root(self) -> Path:
        """Get the path to the taxonomy root directory."""
        return self.target_path / ".global" / "taxonomy"

    @property
    def lock_file_path(self) -> Path:
        """Get the path to the lock file."""
        return self.taxonomy_root / "taxonomy.lock"


@dataclass(frozen=True)
class RemovedComponent:
    """Represents a component that was removed.

    Attributes:
        name: Component name (e.g., "layer_types", "app-docker").
        component_type: Type of component ("plugin" or "layer_type").
    """

    name: str
    component_type: str


@dataclass(frozen=True)
class RemoveResult:
    """Result of a remove operation.

    Attributes:
        status: The status of the operation.
        removed: Tuple of components that were removed.
        not_found: Tuple of components that were not found.
        error: Error message if the operation failed.
    """

    status: RemoveStatus
    removed: tuple[RemovedComponent, ...] = ()
    not_found: tuple[str, ...] = ()
    error: str | None = None

    @property
    def is_success(self) -> bool:
        """Check if the operation was successful."""
        return self.status == RemoveStatus.SUCCESS


# Backwards-compatible aliases
RemoveFilesystem = FilesystemPort
RealRemoveFilesystem = RealFilesystem


class RemoveService:
    """Service for removing plugins and layer types from a taxonomy.

    This service handles uninstalling components from a repository that
    has already been initialized with `kata tax init`.

    Uses :class:`FileReader` (``exists``, ``read_file``) and
    :class:`FileWriter` (``write_file``, ``remove_directory``)
    capabilities from the filesystem port.
    """

    def __init__(self, filesystem: FilesystemPort) -> None:
        """Initialize the service.

        Args:
            filesystem: Adapter for filesystem operations.
        """
        self._filesystem = filesystem

    def remove(self, config: RemoveConfig) -> RemoveResult:
        """Remove plugins and/or layer types from a taxonomy.

        Args:
            config: Configuration for the remove operation.

        Returns:
            RemoveResult with removed components.
        """
        # Check if initialized
        if not self._filesystem.exists(config.lock_file_path):
            return RemoveResult(
                status=RemoveStatus.NOT_INITIALIZED,
                error="Taxonomy not initialized. Run 'kata tax init' first.",
            )

        # Load current lock file
        try:
            lock = self._load_lock(config.lock_file_path)
        except Exception as e:
            return RemoveResult(
                status=RemoveStatus.FAILED,
                error=f"Failed to load lock file: {e}",
            )

        removed: list[RemovedComponent] = []
        not_found: list[str] = []

        # Remove plugins
        for plugin in config.plugins:
            result = self._remove_plugin(config, lock, plugin)
            if result is None:
                not_found.append(plugin)
            else:
                removed.append(result)
                lock = self._update_lock_remove_plugin(lock, plugin)

        # Remove layer types
        if config.layer_types:
            lt_result = self._remove_layer_types(config, lock, config.layer_types)
            removed.extend(lt_result.removed)
            not_found.extend(lt_result.not_found)
            if lt_result.removed:
                lock = self._update_lock_remove_layer_types(
                    lock,
                    [c.name for c in lt_result.removed],
                )

        # Save updated lock file
        if removed:
            try:
                self._save_lock(config.lock_file_path, lock)
            except Exception as e:
                return RemoveResult(
                    status=RemoveStatus.FAILED,
                    error=f"Failed to save lock file: {e}",
                )

        # Determine final status
        if not removed and not_found:
            return RemoveResult(
                status=RemoveStatus.NOT_INSTALLED,
                not_found=tuple(not_found),
            )

        return RemoveResult(
            status=RemoveStatus.SUCCESS,
            removed=tuple(removed),
            not_found=tuple(not_found),
        )

    def _remove_plugin(
        self,
        config: RemoveConfig,
        lock: KatalystLock,
        plugin: str,
    ) -> RemovedComponent | None:
        """Remove a single plugin.

        Args:
            config: Remove configuration.
            lock: Current lock file.
            plugin: Plugin name to remove.

        Returns:
            RemovedComponent if removed, None if not installed.
        """
        # Check if installed
        if not lock.has_plugin(plugin):
            return None

        # Determine plugin directory
        if plugin == "layer_types":
            plugin_dir = config.taxonomy_root / "layer_types"
        elif plugin == "cicd":
            # cicd lives directly at cicd/ (not plugins/cicd/)
            plugin_dir = config.taxonomy_root / "cicd"
        else:
            plugin_dir = config.taxonomy_root / "plugins" / plugin

        # Remove the directory
        if self._filesystem.exists(plugin_dir):
            self._filesystem.remove_directory(plugin_dir)

        return RemovedComponent(name=plugin, component_type="plugin")

    def _remove_layer_types(
        self,
        config: RemoveConfig,
        lock: KatalystLock,
        layer_types: tuple[str, ...],
    ) -> RemoveResult:
        """Remove layer types from the taxonomy.

        Args:
            config: Remove configuration.
            lock: Current lock file.
            layer_types: Layer type names to remove.

        Returns:
            RemoveResult with removed layer types.
        """
        removed: list[RemovedComponent] = []
        not_found: list[str] = []

        # Get existing layer types from lock
        existing_layer_types: set[str] = set()
        layer_types_plugin = lock.get_plugin("layer_types")
        if layer_types_plugin:
            existing_layer_types = set(layer_types_plugin.canonical)

        # Remove each layer type
        for layer_type in layer_types:
            if layer_type not in existing_layer_types:
                not_found.append(layer_type)
                continue

            layer_type_dir = config.taxonomy_root / "layer_types" / layer_type
            if self._filesystem.exists(layer_type_dir):
                self._filesystem.remove_directory(layer_type_dir)

            removed.append(RemovedComponent(name=layer_type, component_type="layer_type"))

        return RemoveResult(
            status=RemoveStatus.SUCCESS,
            removed=tuple(removed),
            not_found=tuple(not_found),
        )

    def _load_lock(self, path: Path) -> KatalystLock:
        """Load and parse the lock file.

        Args:
            path: Path to lock file.

        Returns:
            Parsed KatalystLock.
        """
        content = self._filesystem.read_file(path)
        data = yaml.safe_load(content) or {}
        return lock_from_mapping(data, source_path=path)

    def _save_lock(self, path: Path, lock: KatalystLock) -> None:
        """Save the lock file.

        Args:
            path: Path to lock file.
            lock: Lock to save.
        """
        data = lock_to_mapping(lock)
        header = "# Auto-generated by Katalyst - do not edit manually\n"
        content = header + yaml.safe_dump(data, sort_keys=False, default_flow_style=False)
        self._filesystem.write_file(path, content)

    def _update_lock_remove_plugin(
        self,
        lock: KatalystLock,
        plugin: str,
    ) -> KatalystLock:
        """Update lock with a removed plugin.

        Args:
            lock: Current lock.
            plugin: Plugin name to remove.

        Returns:
            Updated lock.
        """
        return lock.without_plugin(plugin)

    def _update_lock_remove_layer_types(
        self,
        lock: KatalystLock,
        layer_types: list[str],
    ) -> KatalystLock:
        """Update lock with removed layer types.

        Args:
            lock: Current lock.
            layer_types: Layer type names that were removed.

        Returns:
            Updated lock.
        """
        existing = lock.get_plugin("layer_types")

        if existing is None:
            return lock

        # Remove from canonical list
        remaining = [lt for lt in existing.canonical if lt not in layer_types]

        if not remaining:
            # No more layer types, remove the plugin entry entirely
            return lock.without_plugin("layer_types")

        # Update with remaining layer types
        new_plugin = InstalledPlugin(
            version=existing.version,
            installed_at=datetime.now(UTC),
            source=existing.source,
            canonical=tuple(remaining),
            custom=existing.custom,
        )

        return lock.with_plugin("layer_types", new_plugin)
