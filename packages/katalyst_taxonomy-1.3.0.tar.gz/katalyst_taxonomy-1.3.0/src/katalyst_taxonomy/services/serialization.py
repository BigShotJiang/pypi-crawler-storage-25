"""Serialization helpers for taxonomy documents.

This module provides pure-data serialization functions with no I/O dependencies.
Used by both the CLI and MCP adapters for consistent JSON output.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.services.taxonomy import TaxonomyService
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


def serialize_document(
    doc: Document,
    service: TaxonomyService,
    base_path: Path | None = None,
) -> dict[str, Any]:
    """Serialize a Document to a JSON-compatible dict.

    Args:
        doc: The taxonomy document to serialize.
        service: The taxonomy service for resolving qualified names.
        base_path: Optional base path to make source paths relative.

    Returns:
        A dictionary suitable for JSON serialization.
    """
    result: dict[str, Any] = {
        "apiVersion": doc.api_version,
        "kind": doc.kind,
        "taxonomyNodeType": doc.taxonomy_node_type,
        "metadata": {
            "name": doc.metadata.name,
            "labels": dict(doc.metadata.labels) if doc.metadata.labels else {},
        },
        "spec": {
            "description": doc.description,
            "owners": list(doc.owners),
            "annotations": dict(doc.annotations_map) if doc.annotations_map else {},
            "environments": list(doc.environments),
        },
        "qualifiedName": service.get_qualified_name(doc),
    }

    if doc.parent is not None:
        result["spec"]["parents"] = {"node": doc.parent}

    if doc.depends_on_nodes:
        result["spec"]["dependsOn"] = {"nodes": list(doc.depends_on_nodes)}

    if doc.extensions_map:
        result["spec"]["extensions"] = dict(doc.extensions_map)

    if doc.source_path:
        if base_path:
            try:
                result["sourcePath"] = str(doc.source_path.relative_to(base_path))
            except ValueError:
                result["sourcePath"] = str(doc.source_path)
        else:
            result["sourcePath"] = str(doc.source_path)

    if doc.markdown_body is not None:
        result["markdownBody"] = doc.markdown_body

    return result


def serialize_environment(
    env: EnvironmentDocument,
    base_path: Path | None = None,
) -> dict[str, Any]:
    """Serialize an EnvironmentDocument to a JSON-compatible dict."""
    result: dict[str, Any] = {
        "name": env.name,
        "description": env.description,
        "templateReplacements": dict(env.template_replacements),
        "layerTemplates": {k: dict(v) for k, v in env.layer_templates.items()},
    }

    if env.source_path:
        if base_path:
            try:
                result["sourcePath"] = str(env.source_path.relative_to(base_path))
            except ValueError:
                result["sourcePath"] = str(env.source_path)
        else:
            result["sourcePath"] = str(env.source_path)

    if env.markdown_body is not None:
        result["markdownBody"] = env.markdown_body

    return result


def serialize_error(
    error: DocumentError,
    base_path: Path | None = None,
) -> dict[str, Any]:
    """Serialize a DocumentError to a JSON-compatible dict."""
    result: dict[str, Any] = {
        "message": error.message,
    }

    if error.path:
        if base_path:
            try:
                result["path"] = str(error.path.relative_to(base_path))
            except ValueError:
                result["path"] = str(error.path)
        else:
            result["path"] = str(error.path)

    if error.document_index:
        result["documentIndex"] = error.document_index

    return result


def serialize_taxonomy(
    service: TaxonomyService,
    base_path: Path | None = None,
) -> dict[str, Any]:
    """Serialize a full taxonomy to a JSON-compatible dict.

    Returns a dict with keys: documents, environments, qualifiedNames, errors.
    """
    return {
        "documents": [serialize_document(doc, service, base_path) for doc in service.documents],
        "environments": [serialize_environment(env, base_path) for env in service.environments],
        "qualifiedNames": service.qualified_names,
        "errors": [serialize_error(e, base_path) for e in service.errors],
    }


def build_tree_lines(service: TaxonomyService) -> list[str]:
    """Build tree representation lines from taxonomy documents.

    Returns a list of strings, each representing one line of the tree.
    Uses the engine registry's display ordering to sort nodes.
    """
    from katalyst_taxonomy.engine.bridge import get_default_registry

    registry = get_default_registry()
    kind_order = registry.sorted_kinds()

    nodes_by_fq: dict[str, Document] = {}
    for document in service.documents:
        fqtn = service.get_qualified_name(document)
        nodes_by_fq[fqtn] = document

    children: dict[str | None, list[str]] = {}
    for fqtn in nodes_by_fq:
        parent_fq: str | None = None
        if "." in fqtn:
            candidate = fqtn.rsplit(".", 1)[0]
            if candidate in nodes_by_fq:
                parent_fq = candidate
        children.setdefault(parent_fq, []).append(fqtn)

    def sort_children(fqs: list[str]) -> list[str]:
        return sorted(
            fqs,
            key=lambda item: (
                kind_order.index(nodes_by_fq[item].taxonomy_node_type)
                if nodes_by_fq[item].taxonomy_node_type in kind_order
                else len(kind_order),
                nodes_by_fq[item].metadata.name,
                item,
            ),
        )

    lines: list[str] = []

    def render_children(parent_fq: str, prefix: str) -> None:
        entries = sort_children(children.get(parent_fq, []))
        for index, child_fq in enumerate(entries):
            document = nodes_by_fq[child_fq]
            connector = (
                "\u2514\u2500\u2500 " if index == len(entries) - 1 else "\u251c\u2500\u2500 "
            )
            lines.append(
                f"{prefix}{connector}{document.metadata.name} [{document.taxonomy_node_type}]",
            )
            extension = "    " if index == len(entries) - 1 else "\u2502   "
            render_children(child_fq, prefix + extension)

    roots = sort_children(children.get(None, []))
    for root_index, root_fq in enumerate(roots):
        root_doc = nodes_by_fq[root_fq]
        lines.append(f"{root_doc.metadata.name} [{root_doc.taxonomy_node_type}]")
        render_children(root_fq, "")
        if root_index != len(roots) - 1:
            lines.append("")

    return lines
