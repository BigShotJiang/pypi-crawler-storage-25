"""Upgrade service for updating taxonomy components.

This module contains domain models and service logic for the `kata tax upgrade` command.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Protocol, Sequence, cast, runtime_checkable

import yaml

from katalyst_taxonomy.domain.diff import DiffSummary, compare_directories
from katalyst_taxonomy.domain.lock import InstalledPlugin, KatalystLock
from katalyst_taxonomy.domain.version import is_upgrade as version_is_upgrade
from katalyst_taxonomy.ports.filesystem import FilesystemPort
from katalyst_taxonomy.ports.template_source import TemplateSourceProtocol


class UpgradeStatus(Enum):
    """Status of an upgrade operation."""

    SUCCESS = "success"
    FAILED = "failed"
    UP_TO_DATE = "up_to_date"
    UPDATES_AVAILABLE = "updates_available"
    NOT_INITIALIZED = "not_initialized"
    CANCELLED = "cancelled"


def _to_tuple(value: Sequence[str] | None) -> tuple[str, ...]:
    """Convert a sequence to a tuple, or return empty tuple if None."""
    from katalyst_taxonomy.services._util import to_tuple

    return to_tuple(value)


# ── Plugin directory mapping ────────────────────────────────────
# Plugins that live at non-standard paths (not plugins/<name>/).
_SPECIAL_PLUGIN_DIRS: dict[str, str] = {
    "layer_types": "layer_types",
    "cicd": "cicd",
}


@dataclass(frozen=True)
class UpgradeConfig:
    """Configuration for upgrading taxonomy components.

    Attributes:
        target_path: Root directory of the taxonomy repository.
        source: Template source URI (default: "bundled").
        components: Specific components to upgrade, or empty for all.
        items: Specific items within a plugin to upgrade, or empty for all.
        dry_run: If True, only check for updates without applying them.
        create_backup: If True, create a backup before upgrading.
        interactive: If True, prompt for confirmation before upgrading.
        show_diff: If True, generate file diffs for updates.
    """

    target_path: Path
    source: str = "bundled"
    components: tuple[str, ...] = ()
    items: tuple[str, ...] = ()
    dry_run: bool = False
    create_backup: bool = True
    interactive: bool = False
    show_diff: bool = False

    def __post_init__(self) -> None:
        """Convert sequences to tuples for immutability."""
        if type(self.components) is not tuple:
            object.__setattr__(self, "components", _to_tuple(self.components))  # type: ignore[arg-type]
        if type(self.items) is not tuple:
            object.__setattr__(self, "items", _to_tuple(self.items))  # type: ignore[arg-type]

    @property
    def taxonomy_root(self) -> Path:
        """Get the path to the taxonomy root directory."""
        return self.target_path / ".global" / "taxonomy"

    @property
    def backup_dir(self) -> Path:
        """Get the path to the backup directory."""
        return self.taxonomy_root / ".backups"


@dataclass(frozen=True)
class ItemUpdate:
    """Represents an available update for a single item within a plugin.

    Attributes:
        name: Item name (e.g., "app-docker").
        plugin_name: Parent plugin (e.g., "layer_types").
        from_version: Currently installed version.
        to_version: Available version.
    """

    name: str
    plugin_name: str
    from_version: str
    to_version: str


@dataclass(frozen=True)
class ComponentUpdate:
    """Represents an available update for a component.

    Attributes:
        name: Component name (e.g., "core", "layer_types").
        from_version: Currently installed version.
        to_version: Available version to upgrade to.
        changelog: Optional changelog/release notes.
        item_updates: Per-item version changes within this component.
    """

    name: str
    from_version: str
    to_version: str
    changelog: str | None = None
    item_updates: tuple[ItemUpdate, ...] = ()


@dataclass(frozen=True)
class UpgradeResult:
    """Result of an upgrade operation.

    Attributes:
        status: The status of the operation.
        updates: Tuple of component updates (available or applied).
        backup_path: Path to the backup (if created).
        error: Error message if the operation failed.
        diffs: Tuple of diff summaries for each component (if requested).
    """

    status: UpgradeStatus
    updates: tuple[ComponentUpdate, ...] = ()
    backup_path: Path | None = None
    error: str | None = None
    diffs: tuple[DiffSummary, ...] = ()

    @property
    def is_success(self) -> bool:
        """Check if the operation was successful."""
        return self.status == UpgradeStatus.SUCCESS

    @property
    def has_diffs(self) -> bool:
        """Check if there are diff summaries available."""
        return len(self.diffs) > 0


@dataclass
class BackupInfo:
    """Information about a backup."""

    path: Path
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    lock_backup: Path | None = None


@runtime_checkable
class LockRepository(Protocol):
    """Protocol for lock file repository operations."""

    def exists(self) -> bool:
        """Check if a lock file exists."""
        ...

    def load(self) -> KatalystLock | None:
        """Load the lock file."""
        ...

    def save(self, lock: KatalystLock) -> Path:
        """Save the lock file.

        Args:
            lock: The lock data to persist.

        Returns:
            Path where the lock file was written.
        """
        ...


class UpgradeService:
    """Service for upgrading taxonomy components.

    This service checks for available updates and applies them.
    """

    def __init__(
        self,
        lock_repository: LockRepository,
        template_source: TemplateSourceProtocol,
        filesystem: FilesystemPort | None = None,
    ) -> None:
        """Initialize the service.

        Args:
            lock_repository: Repository for lock file operations.
            template_source: Source for fetching templates.
            filesystem: Filesystem port for file operations.  When *None*
                a :class:`~katalyst_taxonomy.adapters.filesystem.real.RealFilesystem`
                is created automatically so existing callers keep working.
        """
        self._lock_repo = lock_repository
        self._template_source = template_source

        if filesystem is None:
            from katalyst_taxonomy.ports.filesystem import RealFilesystem

            filesystem = RealFilesystem()
        self._fs = filesystem

    def check_updates(self, config: UpgradeConfig) -> UpgradeResult:
        """Check for available updates.

        Args:
            config: Configuration for the upgrade check.

        Returns:
            UpgradeResult with available updates.
        """
        # Check if initialized
        if not self._lock_repo.exists():
            return UpgradeResult(status=UpgradeStatus.NOT_INITIALIZED)

        # Load current lock
        lock = self._lock_repo.load()
        if lock is None:
            return UpgradeResult(status=UpgradeStatus.NOT_INITIALIZED)

        # Get available updates
        updates = self._find_updates(lock, config)

        if not updates:
            return UpgradeResult(status=UpgradeStatus.UP_TO_DATE, updates=())

        # Generate diffs if requested
        diffs: tuple[DiffSummary, ...] = ()
        if config.show_diff:
            diffs = self._generate_diffs(config, tuple(updates))

        return UpgradeResult(
            status=UpgradeStatus.UPDATES_AVAILABLE,
            updates=tuple(updates),
            diffs=diffs,
        )

    def upgrade(self, config: UpgradeConfig) -> UpgradeResult:
        """Perform upgrade operation.

        Args:
            config: Configuration for the upgrade.

        Returns:
            UpgradeResult with applied updates.
        """
        # First check for updates
        check_result = self.check_updates(config)

        # If no updates or not initialized, return as-is
        if check_result.status in (
            UpgradeStatus.UP_TO_DATE,
            UpgradeStatus.NOT_INITIALIZED,
        ):
            return check_result

        # Dry run - just return available updates
        if config.dry_run:
            return check_result

        # Create backup if requested
        backup_path: Path | None = None
        if config.create_backup:
            backup_info = self._create_backup(config, check_result.updates)
            if backup_info:
                backup_path = backup_info.path

        try:
            # Apply updates
            applied_updates = self._apply_updates(config, check_result.updates)

            # Update the lock file with new versions
            if applied_updates:
                self._save_updated_lock(config, applied_updates)

            return UpgradeResult(
                status=UpgradeStatus.SUCCESS,
                updates=applied_updates,
                backup_path=backup_path,
            )
        except Exception as e:
            # Rollback on failure
            if backup_path and self._fs.exists(backup_path):
                self._rollback(config, backup_path)

            return UpgradeResult(
                status=UpgradeStatus.FAILED,
                updates=(),
                backup_path=backup_path,
                error=str(e),
            )

    def _save_updated_lock(
        self,
        config: UpgradeConfig,
        applied_updates: tuple[ComponentUpdate, ...],
    ) -> None:
        """Update and save the lock file after successful upgrades.

        Args:
            config: Upgrade configuration.
            applied_updates: The updates that were successfully applied.
        """
        lock = self._lock_repo.load()
        if lock is None:
            return

        for update in applied_updates:
            if update.name == "core":
                # Update core version
                from katalyst_taxonomy.domain.lock import InstalledCore

                new_core = InstalledCore(
                    version=update.to_version,
                    schema_version=lock.installed.core.schema_version,
                    installed_at=datetime.now(timezone.utc),
                    source=lock.installed.core.source,
                )
                lock = KatalystLock(
                    api_version=lock.api_version,
                    kind=lock.kind,
                    metadata=lock.metadata,
                    installed=lock.installed.__class__(
                        core=new_core,
                        plugins=lock.installed.plugins,
                    ),
                    source_path=lock.source_path,
                )
            else:
                # Update plugin version
                existing = lock.get_plugin(update.name)
                if existing is None:
                    continue

                # Merge item_versions: update items that were upgraded
                item_dict = existing.item_versions_dict()
                for item_update in update.item_updates:
                    item_dict[item_update.name] = item_update.to_version

                new_plugin = InstalledPlugin(
                    version=update.to_version,
                    installed_at=datetime.now(timezone.utc),
                    source=existing.source,
                    canonical=existing.canonical,
                    custom=existing.custom,
                    item_versions=tuple(sorted(item_dict.items())),
                )
                lock = lock.with_plugin(update.name, new_plugin)

        self._lock_repo.save(lock)

    def _create_backup(
        self,
        config: UpgradeConfig,
        updates: tuple[ComponentUpdate, ...] = (),
    ) -> BackupInfo | None:
        """Create a backup of the current taxonomy.

        Backs up the lock file and any template directories that will be
        modified by the upgrade.

        Args:
            config: Upgrade configuration.
            updates: The updates that will be applied (used to determine
                which directories to back up).

        Returns:
            BackupInfo if backup was created, None otherwise.
        """
        taxonomy_root = config.taxonomy_root
        if not self._fs.exists(taxonomy_root):
            return None

        # Create backup directory
        backup_dir = config.backup_dir
        self._fs.create_directory(backup_dir)

        # Generate backup name with timestamp
        timestamp = datetime.now(timezone.utc)
        backup_name = f"backup_{timestamp.strftime('%Y%m%d_%H%M%S')}"
        backup_path = backup_dir / backup_name
        self._fs.create_directory(backup_path)

        # Copy lock file to backup
        lock_file = taxonomy_root / "taxonomy.lock"
        lock_backup: Path | None = None
        if self._fs.exists(lock_file):
            lock_backup = backup_path / "taxonomy.lock"
            self._fs.copy_file(lock_file, lock_backup)

        # Back up template directories that will be modified
        for update in updates:
            src_path = self._get_installed_path(config, update.name)
            if src_path is not None and update.name != "core":
                # Determine relative path within taxonomy root
                rel = src_path.name
                dest_backup = backup_path / rel
                if self._fs.exists(src_path):
                    self._fs.copy_tree(src_path, dest_backup)

        return BackupInfo(
            path=backup_path,
            timestamp=timestamp,
            lock_backup=lock_backup,
        )

    def _rollback(self, config: UpgradeConfig, backup_path: Path) -> None:
        """Rollback to a previous backup.

        Restores the lock file and any template directories that were
        backed up.

        Args:
            config: Upgrade configuration.
            backup_path: Path to the backup to restore.
        """
        taxonomy_root = config.taxonomy_root

        # Restore lock file
        lock_backup = backup_path / "taxonomy.lock"
        if self._fs.exists(lock_backup):
            lock_file = taxonomy_root / "taxonomy.lock"
            self._fs.copy_file(lock_backup, lock_file)

        # Restore template directories
        for item_path in backup_path.iterdir():
            if item_path.is_dir():
                dest = taxonomy_root / item_path.name
                if self._fs.exists(dest):
                    self._fs.remove_directory(dest)
                self._fs.copy_tree(item_path, dest)

    def _apply_updates(
        self,
        config: UpgradeConfig,
        updates: tuple[ComponentUpdate, ...],
    ) -> tuple[ComponentUpdate, ...]:
        """Apply updates to installed components.

        When ``config.items`` is set, only copies the specified items
        within a plugin instead of replacing the entire plugin directory.

        Args:
            config: Upgrade configuration.
            updates: Updates to apply.

        Returns:
            Tuple of applied updates.
        """
        applied: list[ComponentUpdate] = []

        for update in updates:
            try:
                # Fetch the new package
                fetch_result = self._template_source.fetch_package(update.name, update.to_version)
                package_path = getattr(fetch_result, "path", None)

                if package_path is None:
                    continue

                # Copy templates to the taxonomy directory
                if update.name == "core":
                    self._copy_core_templates(config, package_path)
                elif config.items:
                    # Selective item upgrade
                    self._copy_selected_items(config, update.name, package_path)
                else:
                    self._copy_plugin_templates(config, update.name, package_path)

                applied.append(update)

            except (KeyError, ValueError, OSError):
                # Skip failed updates
                continue

        return tuple(applied)

    def _copy_core_templates(self, config: UpgradeConfig, package_path: Path) -> None:
        """Copy core template files to taxonomy root.

        Args:
            config: Upgrade configuration.
            package_path: Path to the fetched core package.
        """
        taxonomy_root = config.taxonomy_root
        self._fs.create_directory(taxonomy_root)

        for item in package_path.iterdir():
            if item.is_file() and item.suffix in (".yaml", ".yml"):
                dest = taxonomy_root / item.name
                self._fs.copy_file(item, dest)

    def _copy_plugin_templates(
        self,
        config: UpgradeConfig,
        plugin_name: str,
        package_path: Path,
    ) -> None:
        """Copy plugin template files to taxonomy plugins directory.

        Args:
            config: Upgrade configuration.
            plugin_name: Name of the plugin.
            package_path: Path to the fetched plugin package.
        """
        dest_dir = self._plugin_dest_dir(config, plugin_name)

        # Remove existing and copy new
        if self._fs.exists(dest_dir):
            self._fs.remove_directory(dest_dir)

        self._fs.copy_tree(package_path, dest_dir)

    def _copy_selected_items(
        self,
        config: UpgradeConfig,
        plugin_name: str,
        package_path: Path,
    ) -> None:
        """Copy only selected items from a plugin package.

        Used for selective per-item upgrades (e.g., only ``app-docker``
        within the ``layer_types`` plugin).

        Args:
            config: Upgrade configuration.
            plugin_name: Name of the plugin.
            package_path: Path to the fetched plugin package.
        """
        dest_dir = self._plugin_dest_dir(config, plugin_name)
        self._fs.create_directory(dest_dir)

        for item_name in config.items:
            src_item = package_path / item_name
            if not src_item.exists() or not src_item.is_dir():
                continue

            dest_item = dest_dir / item_name
            # Remove existing item directory and replace
            if self._fs.exists(dest_item):
                self._fs.remove_directory(dest_item)
            self._fs.copy_tree(src_item, dest_item)

    def _plugin_dest_dir(self, config: UpgradeConfig, plugin_name: str) -> Path:
        """Get the destination directory for a plugin.

        Args:
            config: Upgrade configuration.
            plugin_name: Name of the plugin.

        Returns:
            Path to the plugin's directory within the taxonomy root.
        """
        if plugin_name in _SPECIAL_PLUGIN_DIRS:
            return config.taxonomy_root / _SPECIAL_PLUGIN_DIRS[plugin_name]
        return config.taxonomy_root / "plugins" / plugin_name

    def _find_updates(
        self,
        lock: object,
        config: UpgradeConfig,
    ) -> list[ComponentUpdate]:
        """Find available updates for installed components.

        Checks both plugin-level version changes and per-item version
        changes (using ``InstalledPlugin.item_versions`` and the source's
        ``metadata.version`` fields in YAML documents).

        Args:
            lock: Current lock file.
            config: Upgrade configuration.

        Returns:
            List of available updates.
        """
        updates: list[ComponentUpdate] = []

        # Access lock attributes dynamically since we use a protocol
        # In practice, this will be a KatalystLock
        installed = getattr(lock, "installed", None)
        if installed is None:
            return updates

        core = getattr(installed, "core", None)
        plugins: dict[str, object] = getattr(installed, "plugins", {})

        # Check which components to upgrade
        check_all = not config.components
        check_core = check_all or "core" in config.components

        # Check core version
        if check_core and core is not None:
            core_version: str = getattr(core, "version", "0.0.0")
            try:
                latest_core = self._template_source.get_latest_version("core")
                # Use semantic version comparison
                if self._is_newer_version(core_version, latest_core):
                    updates.append(
                        ComponentUpdate(
                            name="core",
                            from_version=core_version,
                            to_version=latest_core,
                        ),
                    )
            except (KeyError, ValueError):
                pass  # Source doesn't have core package

        # Check plugin versions
        if plugins:
            for plugin_name, plugin in plugins.items():
                check_plugin = check_all or plugin_name in config.components
                if not check_plugin:
                    continue

                plugin_version: str = getattr(plugin, "version", "0.0.0")
                try:
                    latest_plugin = self._template_source.get_latest_version(plugin_name)
                    has_plugin_upgrade = self._is_newer_version(plugin_version, latest_plugin)

                    # Discover per-item updates
                    item_updates = self._find_item_updates(plugin, plugin_name, latest_plugin)

                    if has_plugin_upgrade or item_updates:
                        updates.append(
                            ComponentUpdate(
                                name=plugin_name,
                                from_version=plugin_version,
                                to_version=latest_plugin,
                                item_updates=tuple(item_updates),
                            ),
                        )
                except (KeyError, ValueError):
                    pass  # Source doesn't have this plugin

        return updates

    def _find_item_updates(
        self,
        plugin: object,
        plugin_name: str,
        latest_plugin_version: str,
    ) -> list[ItemUpdate]:
        """Find per-item version differences within a plugin.

        Fetches the plugin package, reads ``metadata.version`` from each
        YAML document, and compares against the installed item_versions
        in the lock file.

        Args:
            plugin: The installed plugin data (InstalledPlugin or similar).
            plugin_name: Name of the plugin.
            latest_plugin_version: Latest available version of the plugin.

        Returns:
            List of item-level updates found.
        """
        item_updates: list[ItemUpdate] = []

        # Get installed item versions
        item_versions_method = getattr(plugin, "item_versions_dict", None)
        if item_versions_method is None:
            return item_updates
        installed_items: dict[str, str] = item_versions_method()

        if not installed_items:
            return item_updates

        # Fetch the package to read per-item versions from YAML
        try:
            fetch_result = self._template_source.fetch_package(
                plugin_name,
                latest_plugin_version,
            )
            package_path: Path | None = getattr(fetch_result, "path", None)
            if package_path is None:
                return item_updates
        except (KeyError, ValueError):
            return item_updates

        # Read item versions from YAML files
        source_items = self._read_item_versions_from_source(package_path)

        # Compare
        for item_name, installed_version in installed_items.items():
            source_version = source_items.get(item_name)
            if source_version is not None and self._is_newer_version(
                installed_version,
                source_version,
            ):
                item_updates.append(
                    ItemUpdate(
                        name=item_name,
                        plugin_name=plugin_name,
                        from_version=installed_version,
                        to_version=source_version,
                    ),
                )

        return item_updates

    def _read_item_versions_from_source(self, package_path: Path) -> dict[str, str]:
        """Read per-item versions from YAML files in a package directory.

        Scans ``*.yaml`` files for plugin documents with ``metadata.version``
        and returns a mapping of item name -> version.

        Args:
            package_path: Path to the fetched package directory.

        Returns:
            Dict of item_name -> version.
        """
        versions: dict[str, str] = {}

        for yaml_path in package_path.rglob("*.yaml"):
            try:
                content = yaml_path.read_text(encoding="utf-8")
                raw_docs: Any = yaml.safe_load_all(content)
                for raw_doc in raw_docs:
                    if not isinstance(raw_doc, dict):
                        continue
                    doc = cast(dict[str, Any], raw_doc)

                    api_version: str = str(doc.get("apiVersion", ""))
                    if not api_version.startswith("katalyst.taxonomy.plugins"):
                        continue

                    metadata_raw: object = doc.get("metadata")
                    if not isinstance(metadata_raw, dict):
                        continue
                    metadata = cast(dict[str, Any], metadata_raw)

                    name: str | None = metadata.get("name")
                    version: str | None = metadata.get("version")
                    if name and version:
                        versions[name] = version
            except (yaml.YAMLError, OSError):
                continue

        return versions

    def _is_newer_version(self, current: str, available: str) -> bool:
        """Check if available version is newer than current.

        Uses semantic version comparison.

        Args:
            current: Currently installed version.
            available: Available version.

        Returns:
            True if available is newer than current.
        """
        try:
            return version_is_upgrade(current, available)
        except ValueError:
            # Fall back to string comparison if version parsing fails
            return available != current

    def _generate_diffs(
        self,
        config: UpgradeConfig,
        updates: tuple[ComponentUpdate, ...],
    ) -> tuple[DiffSummary, ...]:
        """Generate file diffs for each update.

        Args:
            config: Upgrade configuration.
            updates: Updates to generate diffs for.

        Returns:
            Tuple of DiffSummary for each update.
        """
        diffs: list[DiffSummary] = []

        for update in updates:
            try:
                # Fetch the new package from source
                fetch_result = self._template_source.fetch_package(update.name, update.to_version)

                # Get path from fetch result
                new_path = getattr(fetch_result, "path", None)
                if new_path is None:
                    continue

                # Get current installed path
                old_path = self._get_installed_path(config, update.name)

                # Generate diff
                diff = compare_directories(
                    old_dir=old_path,
                    new_dir=new_path,
                    component=update.name,
                    from_version=update.from_version,
                    to_version=update.to_version,
                )
                diffs.append(diff)

            except (KeyError, ValueError, OSError):
                # Skip if we can't generate diff for this component
                continue

        return tuple(diffs)

    def _get_installed_path(self, config: UpgradeConfig, component: str) -> Path | None:
        """Get the path where a component is currently installed.

        Args:
            config: Upgrade configuration.
            component: Component name.

        Returns:
            Path to the installed component, or None if not installed.
        """
        taxonomy_root = config.taxonomy_root

        if component == "core":
            # Core templates are in the root taxonomy directory
            return taxonomy_root if self._fs.exists(taxonomy_root) else None

        # Use the same routing logic as _plugin_dest_dir
        plugin_path = self._plugin_dest_dir(config, component)
        return plugin_path if self._fs.exists(plugin_path) else None
