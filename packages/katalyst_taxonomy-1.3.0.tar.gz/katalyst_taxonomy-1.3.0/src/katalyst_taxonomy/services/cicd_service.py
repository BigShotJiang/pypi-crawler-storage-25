"""CICD service — typed access to CI/CD pipeline documents.

Replaces the v1 ``plugins/cicd/`` package with engine-native queries.
"""

from __future__ import annotations

# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownArgumentType=false
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from loguru import logger

from katalyst_taxonomy.domain.environment_contract import (
    EnvironmentContract,
    parse_environment_contract,
)
from katalyst_taxonomy.engine.document import Document

# --- View Models ---


@dataclass(frozen=True, slots=True)
class TemplateRenderer:
    """Renderer configuration for a CICD template."""

    type: str
    strict_undefined: bool


@dataclass(frozen=True, slots=True)
class TemplateReference:
    """Concrete template location and renderer metadata."""

    path: Path
    renderer: TemplateRenderer


@dataclass(frozen=True, slots=True)
class WorkflowParameter:
    """Declarative description of workflow parameters."""

    name: str
    description: str | None
    value_type: str | None
    required: bool
    default: Any
    has_default: bool


@dataclass(frozen=True, slots=True)
class WorkflowJob:
    """Workflow job definition referencing a job template."""

    name: str
    template_ref: str
    with_arguments: tuple[tuple[str, Any], ...]
    needs: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class StageView:
    """Typed view of a cicd_stage document."""

    name: str
    description: str | None
    depends_on: tuple[str, ...]
    path: Path
    document_index: int
    document: Document


@dataclass(frozen=True, slots=True)
class JobView:
    """Typed view of a cicd_job_template document."""

    name: str
    description: str | None
    stage: str
    layer_type: str
    template: TemplateReference
    required_inputs: tuple[str, ...]
    default_inputs: tuple[tuple[str, Any], ...]
    produces: tuple[str, ...]
    consumes: tuple[str, ...]
    path: Path
    document_index: int
    environment_contract: EnvironmentContract
    document: Document


@dataclass(frozen=True, slots=True)
class WorkflowView:
    """Typed view of a cicd_workflow_template document."""

    name: str
    description: str | None
    template: TemplateReference
    parameters: tuple[WorkflowParameter, ...]
    jobs: tuple[WorkflowJob, ...]
    path: Path
    document_index: int
    document: Document


@dataclass(frozen=True, slots=True)
class CicdServiceResult:
    """Result of loading CICD documents — drop-in for CICDPluginResult."""

    workflows: tuple[WorkflowView, ...]
    jobs: tuple[JobView, ...]
    stages: tuple[StageView, ...]
    errors: tuple[CicdError, ...]
    _workflows_by_name: dict[str, WorkflowView]
    _jobs_by_name: dict[str, JobView]
    _stages_by_name: dict[str, StageView]
    _jobs_by_layer_stage: dict[tuple[str, str], JobView]

    def workflow(self, name: str) -> WorkflowView | None:
        return self._workflows_by_name.get(name)

    def job(self, name: str) -> JobView | None:
        return self._jobs_by_name.get(name)

    def stage(self, name: str) -> StageView | None:
        return self._stages_by_name.get(name)

    def job_for_stage(self, *, layer_type: str, stage: str) -> JobView | None:
        return self._jobs_by_layer_stage.get((layer_type, stage))


@dataclass(frozen=True, slots=True)
class CicdError:
    """Error from CICD loading or cross-ref validation."""

    path: Path
    document_index: int
    message: str


# --- Loader ---


def load_cicd(
    base_path: Path,
) -> CicdServiceResult:
    """Load CICD documents from the taxonomy at ``base_path``.

    Scans ``.global/taxonomy/cicd/`` for CICD YAML files.
    """
    from katalyst_taxonomy.domain.errors import DocumentError
    from katalyst_taxonomy.engine.parsing import parse_yaml_documents

    cicd_dir = base_path / ".global" / "taxonomy" / "cicd"
    if not cicd_dir.exists():
        return CicdServiceResult(
            workflows=(),
            jobs=(),
            stages=(),
            errors=(),
            _workflows_by_name={},
            _jobs_by_name={},
            _stages_by_name={},
            _jobs_by_layer_stage={},
        )

    # Discover YAML files recursively
    yaml_files = sorted(p for p in cicd_dir.rglob("*.yaml") if p.is_file())
    yaml_files.extend(sorted(p for p in cicd_dir.rglob("*.yml") if p.is_file()))

    workflows: list[WorkflowView] = []
    jobs: list[JobView] = []
    stages: list[StageView] = []
    errors: list[CicdError] = []

    for path in yaml_files:
        env_docs: list[object] = []
        parse_errors: list[DocumentError] = []
        docs = parse_yaml_documents(
            path,
            environment_documents=env_docs,  # type: ignore[arg-type]
            errors=parse_errors,
        )

        for err in parse_errors:
            errors.append(
                CicdError(
                    path=err.path,
                    document_index=err.document_index,
                    message=err.message,
                )
            )

        for doc_index, doc in enumerate(docs, start=1):
            try:
                if doc.kind == "cicd_stage":
                    stages.append(_build_stage_view(doc, path, doc_index))
                elif doc.kind == "cicd_job_template":
                    jobs.append(_build_job_view(doc, path, doc_index, base_path))
                elif doc.kind == "cicd_workflow_template":
                    workflows.append(_build_workflow_view(doc, path, doc_index, base_path))
            except ValueError as exc:
                errors.append(
                    CicdError(
                        path=path,
                        document_index=doc_index,
                        message=str(exc),
                    )
                )

    # Cross-reference validation
    stage_names = {s.name for s in stages}
    for stage in stages:
        for dep in stage.depends_on:
            if dep not in stage_names:
                errors.append(
                    CicdError(
                        path=stage.path,
                        document_index=stage.document_index,
                        message=f"Stage '{stage.name}' depends on undefined stage '{dep}'.",
                    )
                )

    jobs_by_layer_stage: dict[tuple[str, str], JobView] = {}
    for job in jobs:
        if stage_names and job.stage not in stage_names:
            errors.append(
                CicdError(
                    path=job.path,
                    document_index=job.document_index,
                    message=f"JobTemplate '{job.name}' references unknown stage '{job.stage}'.",
                )
            )
        key = (job.layer_type, job.stage)
        if key in jobs_by_layer_stage:
            errors.append(
                CicdError(
                    path=job.path,
                    document_index=job.document_index,
                    message=(
                        f"Duplicate JobTemplate for layerType '{job.layer_type}' "
                        f"and stage '{job.stage}' (existing={jobs_by_layer_stage[key].name})."
                    ),
                )
            )
        else:
            jobs_by_layer_stage[key] = job

    workflows_by_name = {w.name: w for w in workflows}
    jobs_by_name = {j.name: j for j in jobs}
    stages_by_name = {s.name: s for s in stages}

    logger.info(
        "Loaded CICD: {} workflows, {} jobs, {} stages",
        len(workflows),
        len(jobs),
        len(stages),
    )

    return CicdServiceResult(
        workflows=tuple(workflows),
        jobs=tuple(jobs),
        stages=tuple(stages),
        errors=tuple(errors),
        _workflows_by_name=workflows_by_name,
        _jobs_by_name=jobs_by_name,
        _stages_by_name=stages_by_name,
        _jobs_by_layer_stage=jobs_by_layer_stage,
    )


# --- Builders ---


def _build_stage_view(doc: Document, path: Path, index: int) -> StageView:
    spec = doc.spec
    depends_on_raw = spec.get("stage_depends_on")
    depends_on: tuple[str, ...] = ()
    if isinstance(depends_on_raw, (list, tuple)):
        depends_on = tuple(str(d) for d in depends_on_raw if isinstance(d, str))

    return StageView(
        name=doc.name,
        description=doc.description,
        depends_on=depends_on,
        path=path,
        document_index=index,
        document=doc,
    )


def _build_job_view(doc: Document, path: Path, index: int, base_path: Path) -> JobView:
    spec = doc.spec

    stage = spec.get("stage")
    if not isinstance(stage, str) or not stage:
        raise ValueError(f"spec.stage is required (path={path}, document={index})")

    # Extract layer_type from extends target
    layer_type = ""
    if doc.extends is not None and doc.extends.target_names:
        first = doc.extends.target_names[0]
        if first != "*":
            layer_type = first

    template = _build_template_reference(spec.get("template"), path, index, base_path)

    inputs = spec.get("inputs", {})
    required_inputs: tuple[str, ...] = ()
    default_inputs: tuple[tuple[str, Any], ...] = ()
    if isinstance(inputs, dict):
        req_raw = inputs.get("required")
        if isinstance(req_raw, (list, tuple)):
            required_inputs = tuple(str(r) for r in req_raw if isinstance(r, str))
        def_raw = inputs.get("defaults")
        if isinstance(def_raw, dict):
            default_inputs = tuple(sorted((str(k), v) for k, v in def_raw.items()))

    artifacts = spec.get("artifacts", {})
    produces: tuple[str, ...] = ()
    consumes: tuple[str, ...] = ()
    if isinstance(artifacts, dict):
        p_raw = artifacts.get("produces")
        if isinstance(p_raw, (list, tuple)):
            produces = tuple(str(p) for p in p_raw if isinstance(p, str))
        c_raw = artifacts.get("consumes")
        if isinstance(c_raw, (list, tuple)):
            consumes = tuple(str(c) for c in c_raw if isinstance(c, str))

    environment_contract = parse_environment_contract(spec.get("environmentContract"))

    return JobView(
        name=doc.name,
        description=doc.description,
        stage=stage,
        layer_type=layer_type,
        template=template,
        required_inputs=required_inputs,
        default_inputs=default_inputs,
        produces=produces,
        consumes=consumes,
        path=path,
        document_index=index,
        environment_contract=environment_contract,
        document=doc,
    )


def _build_workflow_view(doc: Document, path: Path, index: int, base_path: Path) -> WorkflowView:
    spec = doc.spec

    template = _build_template_reference(spec.get("template"), path, index, base_path)
    parameters = _parse_parameters(spec.get("parameters"), path, index)
    jobs = _parse_workflow_jobs(spec.get("jobs"), path, index)

    return WorkflowView(
        name=doc.name,
        description=doc.description,
        template=template,
        parameters=parameters,
        jobs=jobs,
        path=path,
        document_index=index,
        document=doc,
    )


def _build_template_reference(
    config: object,
    path: Path,
    index: int,
    base_path: Path,
) -> TemplateReference:
    if not isinstance(config, dict):
        raise ValueError(f"spec.template must be a mapping (path={path}, document={index})")

    template_path_value = config.get("path")
    if not isinstance(template_path_value, str) or not template_path_value:
        raise ValueError(f"spec.template.path is required (path={path}, document={index})")

    renderer_raw = config.get("renderer")
    if not isinstance(renderer_raw, dict):
        raise ValueError(f"spec.template.renderer is required (path={path}, document={index})")

    renderer_type = renderer_raw.get("type")
    if not isinstance(renderer_type, str) or not renderer_type:
        raise ValueError(f"spec.template.renderer.type is required (path={path}, document={index})")

    strict = renderer_raw.get("strictUndefined", False)
    if not isinstance(strict, bool):
        strict = False

    resolved_path = _resolve_template_file(template_path_value, path, base_path)

    return TemplateReference(
        path=resolved_path,
        renderer=TemplateRenderer(type=renderer_type, strict_undefined=strict),
    )


def _resolve_template_file(
    template_value: str,
    document_path: Path,
    base_path: Path,
) -> Path:
    """Resolve a template file path."""
    template_path = Path(template_value)
    candidates: list[Path] = []
    if template_path.is_absolute():
        candidates.append(template_path)
    else:
        candidates.extend(
            [
                document_path.parent / template_path,
                base_path / template_path,
                base_path / ".global" / "taxonomy" / "cicd" / template_path,
            ]
        )

    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate.resolve()

    raise ValueError(
        f"spec.template.path references '{template_value}' which does not exist "
        f"(path={document_path}, document=?)"
    )


def _parse_parameters(
    raw_parameters: object,
    path: Path,
    index: int,
) -> tuple[WorkflowParameter, ...]:
    if raw_parameters is None:
        return ()
    if not isinstance(raw_parameters, dict):
        raise ValueError(f"spec.parameters must be a mapping (path={path}, document={index})")

    _SENTINEL = object()
    parameters: list[WorkflowParameter] = []
    for name, raw in raw_parameters.items():
        if not isinstance(raw, dict):
            continue
        description = raw.get("description")
        value_type = raw.get("type")
        required = raw.get("required", True)
        default_token = raw.get("default", _SENTINEL)
        has_default = default_token is not _SENTINEL
        default_value = default_token if has_default else None

        parameters.append(
            WorkflowParameter(
                name=str(name),
                description=str(description) if description is not None else None,
                value_type=str(value_type) if value_type is not None else None,
                required=bool(required),
                default=default_value,
                has_default=has_default,
            )
        )
    parameters.sort(key=lambda p: p.name)
    return tuple(parameters)


def _parse_workflow_jobs(
    raw_jobs: object,
    path: Path,
    index: int,
) -> tuple[WorkflowJob, ...]:
    if raw_jobs is None:
        raise ValueError(f"spec.jobs is required (path={path}, document={index})")
    if not isinstance(raw_jobs, (list, tuple)):
        raise ValueError(f"spec.jobs must be an array (path={path}, document={index})")

    jobs: list[WorkflowJob] = []
    for _pos, raw in enumerate(raw_jobs, start=1):
        if not isinstance(raw, dict):
            continue
        name = raw.get("name")
        template_ref = raw.get("templateRef")
        if not isinstance(name, str) or not isinstance(template_ref, str):
            continue

        with_raw = raw.get("with")
        with_arguments: tuple[tuple[str, Any], ...] = ()
        if isinstance(with_raw, dict):
            with_arguments = tuple(sorted((str(k), v) for k, v in with_raw.items()))

        needs_raw = raw.get("needs")
        needs: tuple[str, ...] = ()
        if isinstance(needs_raw, (list, tuple)):
            needs = tuple(str(n) for n in needs_raw if isinstance(n, str))

        jobs.append(
            WorkflowJob(
                name=str(name),
                template_ref=str(template_ref),
                with_arguments=with_arguments,
                needs=needs,
            )
        )
    return tuple(jobs)


# --- Backward-compatible aliases ---
StageDefinition = StageView
JobTemplateDefinition = JobView
WorkflowTemplateDefinition = WorkflowView
CICDPluginResult = CicdServiceResult
load_cicd_templates = load_cicd


# ─────────────────────────────────────────────────────────────────────────────
# Render service
# ─────────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class CicdRenderResult:
    """Result of rendering a workflow template."""

    success: bool
    rendered: str | None = None
    error: str | None = None
    missing_params: tuple[str, ...] = ()


def render_workflow(
    base_path: Path,
    workflow_name: str,
    params: dict[str, str] | None = None,
) -> CicdRenderResult:
    """Load a workflow template and render it with the given parameters.

    Args:
        base_path: Path to the repository root.
        workflow_name: Name of the workflow to render.
        params: Parameter values as a dict.

    Returns:
        A CicdRenderResult with the rendered content or an error.
    """
    cicd_path = base_path / ".global" / "taxonomy" / "cicd"
    try:
        result = load_cicd(cicd_path)
    except Exception as exc:
        return CicdRenderResult(success=False, error=f"Failed to load CICD templates: {exc}")

    workflow = result.workflow(workflow_name)
    if workflow is None:
        return CicdRenderResult(success=False, error=f"Workflow '{workflow_name}' not found")

    param_dict: dict[str, str] = dict(params) if params else {}

    # Check for missing required params
    missing_required: list[str] = []
    for p in workflow.parameters:
        if p.required and not p.has_default and p.name not in param_dict:
            missing_required.append(p.name)

    if missing_required:
        return CicdRenderResult(
            success=False,
            error="Missing required parameters",
            missing_params=tuple(missing_required),
        )

    # Build context
    context: dict[str, Any] = dict(param_dict)
    for p in workflow.parameters:
        if p.name in param_dict:
            context[p.name] = param_dict[p.name]
        elif p.has_default:
            context[p.name] = p.default

    # Load template
    template_path = workflow.template.path
    if not template_path.exists():
        return CicdRenderResult(
            success=False,
            error=f"Template file not found: {template_path}",
        )

    try:
        template_content = template_path.read_text()
    except OSError as exc:
        return CicdRenderResult(success=False, error=f"Failed to read template: {exc}")

    # Render
    renderer = workflow.template.renderer
    if renderer.type in ("jinja", "jinja2"):
        try:
            from jinja2 import Environment, StrictUndefined, Undefined

            jinja_env = Environment(
                undefined=StrictUndefined if renderer.strict_undefined else Undefined,
            )
            template = jinja_env.from_string(template_content)
            rendered = template.render(**context)
        except ImportError:
            return CicdRenderResult(
                success=False,
                error="Jinja2 is required for rendering. Install with: pip install jinja2",
            )
        except Exception as exc:
            return CicdRenderResult(success=False, error=f"Template rendering failed: {exc}")
    else:
        return CicdRenderResult(
            success=False,
            error=f"Unsupported renderer type: {renderer.type}",
        )

    return CicdRenderResult(success=True, rendered=rendered)
