"""Agent management service — structured operations on the .agents/ directory.

Provides service-layer functions for agent init, list, show, validate,
sync, create, and generate operations. Returns structured results
instead of writing to streams.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from loguru import logger

from katalyst_taxonomy.agents.bundled import copy_bundled_to
from katalyst_taxonomy.agents.discovery import (
    AgentsDirectory,
    discover_agents_directory,
    find_git_root,
    scan_agents_directory,
)
from katalyst_taxonomy.agents.models import Agent, AgentsConfig, Scope, Skill
from katalyst_taxonomy.agents.parser import serialize_agent, serialize_config
from katalyst_taxonomy.agents.resolution import resolve_for_layer_type
from katalyst_taxonomy.agents.symlinks import check_symlinks, create_symlinks

KEBAB_CASE_PATTERN = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


# ─────────────────────────────────────────────────────────────────────────────
# Agent templates (relocated from cli/commands/agents.py)
# ─────────────────────────────────────────────────────────────────────────────

AGENT_TEMPLATES: dict[str, dict[str, object]] = {
    "layer-helper": {
        "name_suffix": "-helper",
        "description": "Use this agent when working with {layer_type} layers",
        "mode": "subagent",
        "tools": {"read": True, "edit": True, "bash": True},
        "prompt": """# {layer_type_title} Layer Helper

You are a specialized assistant for working with **{layer_type}** layers in the Katalyst taxonomy.

## Reference Material

Load the `katalyst-{layer_type}` skill for detailed reference material about this layer type's directory structure, available actions, patterns, and troubleshooting guides.

## Your Responsibilities

1. **Understand the layer structure** - Know the typical files and directories in {layer_type} layers
2. **Follow best practices** - Apply {layer_type}-specific patterns and conventions
3. **Assist with common tasks** - Help with configuration, deployment, and troubleshooting

## Layer Type Context

This agent is scoped to `{layer_type}` layers. When activated, focus on:
- Files specific to this layer type
- Configuration patterns for {layer_type}
- Common issues and their solutions

## Guidelines

- Always check the layer's `layer.yaml` for context
- Respect the taxonomy structure and naming conventions
- Suggest improvements that align with the layer type's purpose
""",
    },
    "code-reviewer": {
        "name_suffix": "-reviewer",
        "description": "Use this agent to review code changes in {layer_type} layers",
        "mode": "subagent",
        "tools": {"read": True, "edit": False, "bash": False},
        "prompt": """# {layer_type_title} Code Reviewer

You are a code review specialist for **{layer_type}** layers.

## Reference Material

Load the `katalyst-{layer_type}` skill for detailed reference material.

## Review Focus Areas

1. **Code Quality** - Check for clean, maintainable code
2. **Best Practices** - Ensure {layer_type}-specific patterns are followed
3. **Security** - Identify potential security issues
4. **Performance** - Spot performance concerns
5. **Documentation** - Verify adequate comments and docs
""",
    },
    "debugger": {
        "name_suffix": "-debugger",
        "description": "Use this agent to debug issues in {layer_type} layers",
        "mode": "subagent",
        "tools": {"read": True, "edit": True, "bash": True},
        "prompt": """# {layer_type_title} Debugger

You are a debugging specialist for **{layer_type}** layers.

## Reference Material

Load the `katalyst-{layer_type}` skill for detailed reference material.

## Debugging Approach

1. **Gather Information** - Collect logs, error messages, and context
2. **Reproduce the Issue** - Understand the steps to reproduce
3. **Isolate the Problem** - Narrow down the root cause
4. **Propose Solutions** - Suggest fixes with clear explanations
5. **Verify the Fix** - Ensure the solution works
""",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# Result types
# ─────────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class AgentsInitResult:
    success: bool
    agents_dir: Path | None = None
    already_existed: bool = False
    agents_seeded: int = 0
    skills_seeded: int = 0
    agents_skipped: int = 0
    skills_skipped: int = 0
    symlink_errors: tuple[str, ...] = ()
    error: str | None = None


@dataclass(frozen=True, slots=True)
class AgentsShowResult:
    agent: Agent | None = None
    skill: Skill | None = None
    available_agents: tuple[str, ...] = ()
    available_skills: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class AgentsValidationResult:
    agents_checked: int = 0
    skills_checked: int = 0
    errors: tuple[str, ...] = ()

    @property
    def is_valid(self) -> bool:
        return len(self.errors) == 0


@dataclass(frozen=True, slots=True)
class AgentsSyncResult:
    agents_copied: tuple[str, ...] = ()
    skills_copied: tuple[str, ...] = ()
    agents_skipped: tuple[str, ...] = ()
    skills_skipped: tuple[str, ...] = ()

    @property
    def total_copied(self) -> int:
        return len(self.agents_copied) + len(self.skills_copied)

    @property
    def total_skipped(self) -> int:
        return len(self.agents_skipped) + len(self.skills_skipped)


@dataclass(frozen=True, slots=True)
class AgentCreateResult:
    success: bool
    agent_path: Path | None = None
    error: str | None = None


@dataclass(frozen=True, slots=True)
class AgentsGenerateResult:
    created: tuple[str, ...] = ()
    skipped: tuple[str, ...] = ()
    errors: tuple[str, ...] = ()
    available_templates: tuple[str, ...] | None = None


class AgentsNotFoundError(Exception):
    """Raised when .agents/ directory does not exist."""


# ─────────────────────────────────────────────────────────────────────────────
# Service functions
# ─────────────────────────────────────────────────────────────────────────────


def agents_init(
    path: Path,
    *,
    force: bool = False,
    no_seed: bool = False,
) -> AgentsInitResult:
    """Initialize .agents/ directory, seed bundled content, create symlinks."""
    git_root = find_git_root(path)
    root = git_root if git_root else path.resolve()
    agents_dir = root / ".agents"

    if agents_dir.exists() and not force:
        existing = scan_agents_directory(agents_dir, include_bundled=False)
        return AgentsInitResult(
            success=True,
            agents_dir=agents_dir,
            already_existed=True,
            agents_seeded=len(existing.agents),
            skills_seeded=len(existing.skills),
        )

    try:
        agents_dir.mkdir(parents=True, exist_ok=True)
        (agents_dir / "agents").mkdir(exist_ok=True)
        (agents_dir / "skills").mkdir(exist_ok=True)
        (agents_dir / "context").mkdir(exist_ok=True)
    except OSError as e:
        return AgentsInitResult(success=False, error=str(e))

    config_path = agents_dir / "agents.yaml"
    if not config_path.exists() or force:
        default_config = AgentsConfig(version="1")
        config_content = serialize_config(default_config)
        config_path.write_text(config_content, encoding="utf-8")

    agents_seeded = 0
    skills_seeded = 0
    agents_skipped = 0
    skills_skipped = 0

    if not no_seed:
        try:
            sync_result = copy_bundled_to(agents_dir, force=force)
            agents_seeded = len(sync_result.agents_copied)
            skills_seeded = len(sync_result.skills_copied)
            agents_skipped = len(sync_result.agents_skipped)
            skills_skipped = len(sync_result.skills_skipped)
        except FileNotFoundError:
            pass

    symlink_errors: list[str] = []
    results = create_symlinks(agents_dir, force=force)
    for result in results:
        if not result.is_ok:
            symlink_errors.append(f"{result.name}: {result.message}")

    return AgentsInitResult(
        success=True,
        agents_dir=agents_dir,
        agents_seeded=agents_seeded,
        skills_seeded=skills_seeded,
        agents_skipped=agents_skipped,
        skills_skipped=skills_skipped,
        symlink_errors=tuple(symlink_errors),
    )


def agents_list(
    path: Path,
    *,
    layer_type: str | None = None,
) -> AgentsDirectory:
    """List all agents and skills.

    Raises:
        AgentsNotFoundError: If .agents/ does not exist.
    """
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        raise AgentsNotFoundError("No .agents/ directory found.")

    directory = scan_agents_directory(agents_dir)

    if layer_type:
        bindings = directory.config.bindings if directory.config else None
        resolved = resolve_for_layer_type(
            layer_type,
            agents=directory.agents,
            skills=directory.skills,
            bindings=bindings,
        )
        directory.agents = list(resolved.agents)
        directory.skills = list(resolved.skills)

    return directory


def agents_show(path: Path, name: str) -> AgentsShowResult:
    """Look up a specific agent or skill by name.

    Raises:
        AgentsNotFoundError: If .agents/ does not exist.
    """
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        raise AgentsNotFoundError("No .agents/ directory found.")

    directory = scan_agents_directory(agents_dir)
    agent = directory.get_agent(name)
    skill = directory.get_skill(name)

    return AgentsShowResult(
        agent=agent,
        skill=skill,
        available_agents=tuple(a.name for a in directory.agents),
        available_skills=tuple(s.name for s in directory.skills),
    )


def agents_validate(path: Path) -> AgentsValidationResult:
    """Validate all agent/skill definitions and symlinks.

    Raises:
        AgentsNotFoundError: If .agents/ does not exist.
    """
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        raise AgentsNotFoundError("No .agents/ directory found.")

    directory = scan_agents_directory(agents_dir)
    errors: list[str] = []

    for error in directory.errors:
        errors.append(f"Parse error: {error}")

    for agent in directory.agents:
        if not agent.description:
            errors.append(f"Agent '{agent.name}': missing description")
        if not re.match(r"^[a-z0-9]+(-[a-z0-9]+)*$", agent.name):
            errors.append(f"Agent '{agent.name}': invalid name format (must be kebab-case)")
        if agent.temperature is not None and (agent.temperature < 0 or agent.temperature > 2):
            errors.append(f"Agent '{agent.name}': temperature must be 0-2")
        if agent.mode not in ("primary", "subagent", "all"):
            errors.append(f"Agent '{agent.name}': invalid mode '{agent.mode}'")

    for skill in directory.skills:
        if not skill.description:
            errors.append(f"Skill '{skill.name}': missing description")
        if skill.source_path:
            expected_name = skill.source_path.parent.name
            if skill.name != expected_name:
                errors.append(f"Skill '{skill.name}': name must match directory '{expected_name}'")

    results = check_symlinks(agents_dir)
    for result in results:
        if not result.is_ok:
            errors.append(f"Symlink '{result.name}': {result.message}")

    return AgentsValidationResult(
        agents_checked=len(directory.agents),
        skills_checked=len(directory.skills),
        errors=tuple(errors),
    )


def agents_sync(
    path: Path,
    *,
    force: bool = False,
) -> AgentsSyncResult:
    """Sync bundled agents/skills into .agents/.

    Raises:
        AgentsNotFoundError: If .agents/ does not exist.
    """
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        raise AgentsNotFoundError("No .agents/ directory found.")

    try:
        sync_result = copy_bundled_to(agents_dir, force=force)
    except FileNotFoundError:
        return AgentsSyncResult()

    return AgentsSyncResult(
        agents_copied=tuple(sync_result.agents_copied),
        skills_copied=tuple(sync_result.skills_copied),
        agents_skipped=tuple(sync_result.agents_skipped),
        skills_skipped=tuple(sync_result.skills_skipped),
    )


def agents_create(
    path: Path,
    name: str,
    description: str,
    *,
    mode: str = "all",
    tools: dict[str, bool] | None = None,
    scope_layers: list[str] | None = None,
    scope_systems: list[str] | None = None,
    scope_stacks: list[str] | None = None,
    scope_layer_types: list[str] | None = None,
) -> AgentCreateResult:
    """Create a new agent definition file.

    Raises:
        AgentsNotFoundError: If .agents/ does not exist.
    """
    if not KEBAB_CASE_PATTERN.match(name):
        return AgentCreateResult(success=False, error=f"Invalid agent name: '{name}'")

    if mode not in ("primary", "subagent", "all"):
        return AgentCreateResult(success=False, error=f"Invalid mode: '{mode}'")

    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        raise AgentsNotFoundError("No .agents/ directory found.")

    agent_file = agents_dir / "agents" / f"{name}.md"
    if agent_file.exists():
        return AgentCreateResult(success=False, error=f"Agent '{name}' already exists")

    scope_global = not any([scope_layers, scope_systems, scope_stacks, scope_layer_types])
    scope = Scope(
        global_=scope_global,
        systems=tuple(scope_systems or []),
        stacks=tuple(scope_stacks or []),
        layers=tuple(scope_layers or []),
        layer_types=tuple(scope_layer_types or []),
    )

    agent = Agent(
        name=name,
        description=description,
        mode=mode,  # type: ignore[arg-type]
        tools=tools or {},
        scope=scope,
        prompt=f"# {name.replace('-', ' ').title()}\n\nYour instructions here...\n",
        source_path=agent_file,
    )

    try:
        content = serialize_agent(agent)
        agent_file.write_text(content, encoding="utf-8")
        logger.debug(f"Created agent file: {agent_file}")
    except OSError as e:
        return AgentCreateResult(success=False, error=str(e))

    return AgentCreateResult(success=True, agent_path=agent_file)


def agents_generate(
    path: Path,
    *,
    template: str = "layer-helper",
    layer_type: str | None = None,
    all_layer_types: bool = False,
    list_templates: bool = False,
    force: bool = False,
) -> AgentsGenerateResult:
    """Generate agents from templates, bound to layer types.

    Raises:
        AgentsNotFoundError: If .agents/ does not exist (unless list_templates=True).
    """
    if list_templates:
        return AgentsGenerateResult(available_templates=tuple(sorted(AGENT_TEMPLATES.keys())))

    if template not in AGENT_TEMPLATES:
        available = tuple(sorted(AGENT_TEMPLATES.keys()))
        return AgentsGenerateResult(
            errors=(f"Unknown template: '{template}'. Available: {', '.join(available)}",),
            available_templates=available,
        )

    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        raise AgentsNotFoundError("No .agents/ directory found.")

    layer_types_to_generate: list[tuple[str, str | None]] = []

    if layer_type:
        layer_types_to_generate.append((layer_type, None))
    elif all_layer_types:
        try:
            from katalyst_taxonomy.services.template_service import load_layer_types

            result = load_layer_types(path)
            if result.definitions:
                for defn in result.definitions:
                    layer_types_to_generate.append((defn.name, defn.description))
            else:
                return AgentsGenerateResult(
                    errors=("No layer types found in the taxonomy.",),
                )
        except ImportError:
            return AgentsGenerateResult(
                errors=("Could not load layer types plugin.",),
            )
    else:
        return AgentsGenerateResult(
            errors=("Must specify layer_type or all_layer_types.",),
        )

    created: list[str] = []
    skipped: list[str] = []
    errors: list[str] = []

    for lt_name, lt_description in layer_types_to_generate:
        try:
            agent = _generate_agent_from_template(template, lt_name, lt_description)
            agent_file = agents_dir / "agents" / f"{agent.name}.md"

            if agent_file.exists() and not force:
                skipped.append(agent.name)
                continue

            content = serialize_agent(agent)
            agent_file.write_text(content, encoding="utf-8")
            created.append(agent.name)
            logger.debug(f"Generated agent: {agent_file}")

        except (ValueError, OSError) as e:
            errors.append(f"{lt_name}: {e}")

    return AgentsGenerateResult(
        created=tuple(created),
        skipped=tuple(skipped),
        errors=tuple(errors),
    )


def _generate_agent_from_template(
    template_name: str,
    layer_type: str,
    layer_type_description: str | None = None,
) -> Agent:
    """Generate an Agent from a template for a specific layer type."""
    if template_name not in AGENT_TEMPLATES:
        available = ", ".join(sorted(AGENT_TEMPLATES.keys()))
        raise ValueError(f"Unknown template '{template_name}'. Available: {available}")

    tmpl = AGENT_TEMPLATES[template_name]

    layer_type_title = layer_type.replace("-", " ").title()
    context = {
        "layer_type": layer_type,
        "layer_type_title": layer_type_title,
        "layer_type_description": layer_type_description or f"A {layer_type} layer",
    }

    name_suffix = str(tmpl.get("name_suffix", ""))
    name = f"{layer_type}{name_suffix}"
    description = str(tmpl.get("description", "")).format(**context)
    prompt = str(tmpl.get("prompt", "")).format(**context)

    scope = Scope(global_=False, layer_types=(layer_type,))

    tools_raw = tmpl.get("tools", {})
    tools: dict[str, bool] = {}
    if isinstance(tools_raw, dict):
        typed_raw = cast(dict[str, Any], tools_raw)
        tools = {str(k): bool(v) for k, v in typed_raw.items()}

    return Agent(
        name=name,
        description=description,
        mode=str(tmpl.get("mode", "subagent")),  # type: ignore[arg-type]
        tools=tools,
        scope=scope,
        prompt=prompt,
    )
