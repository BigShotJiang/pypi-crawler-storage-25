"""Status service — structured taxonomy installation status."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from katalyst_taxonomy.adapters.filesystem.lock import LOCK_FILE_PATH, LockFileRepository
from katalyst_taxonomy.domain.lock import KatalystLock


class StatusCode(Enum):
    """Overall taxonomy installation status."""

    OK = "ok"
    NOT_INITIALIZED = "not_initialized"
    ERROR = "error"


@dataclass(frozen=True, slots=True)
class StatusResult:
    """Structured result from a status check."""

    status: StatusCode
    lock: KatalystLock | None
    lock_file_path: Path
    error: str | None = None

    @property
    def is_initialized(self) -> bool:
        return self.status == StatusCode.OK


def get_status(path: Path) -> StatusResult:
    """Load the lock file and return structured status information.

    Args:
        path: Path to the repository root.

    Returns:
        A StatusResult with the lock data or an error description.
    """
    lock_full_path = path / LOCK_FILE_PATH

    repo = LockFileRepository(base_path=path)

    if not repo.exists():
        return StatusResult(
            status=StatusCode.NOT_INITIALIZED,
            lock=None,
            lock_file_path=lock_full_path,
        )

    try:
        lock = repo.load()
    except ValueError as e:
        return StatusResult(
            status=StatusCode.ERROR,
            lock=None,
            lock_file_path=lock_full_path,
            error=str(e),
        )

    if lock is None:
        return StatusResult(
            status=StatusCode.NOT_INITIALIZED,
            lock=None,
            lock_file_path=lock_full_path,
        )

    return StatusResult(
        status=StatusCode.OK,
        lock=lock,
        lock_file_path=lock_full_path,
    )
