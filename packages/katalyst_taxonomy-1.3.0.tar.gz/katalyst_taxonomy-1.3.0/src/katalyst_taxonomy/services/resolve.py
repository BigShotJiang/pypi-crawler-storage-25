"""Service for resolving file paths to their parent taxonomy layers.

This module provides the bridge between git's changed-file lists and
Katalyst's layer FQTN system.  Given a list of file paths relative to
the repository root, it determines which layers are affected and returns
their FQTNs, layer types, and the files that map to each layer.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from loguru import logger

LAYER_FILENAMES = ("layer.yaml", "layer.yml")


@dataclass(frozen=True, slots=True)
class ResolvedLayer:
    """A layer that was resolved from one or more file paths."""

    fqtn: str
    layer_type: str | None
    layer_dir: str
    changed_files: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ResolveResult:
    """Result of resolving file paths to layers."""

    layers: tuple[ResolvedLayer, ...]
    unmapped: tuple[str, ...]


def find_enclosing_layer_yaml(file_path: Path, repo_root: Path) -> Path | None:
    """Walk up from *file_path* toward *repo_root* looking for ``layer.yaml``.

    Returns the path to the ``layer.yaml`` file if found, otherwise ``None``.
    Both *file_path* and *repo_root* are resolved to absolute paths before the
    traversal begins.
    """
    current = file_path.parent if file_path.is_file() or not file_path.exists() else file_path
    repo_root = repo_root.resolve()
    current = current.resolve()

    while current != repo_root and current != current.parent:
        for candidate_name in LAYER_FILENAMES:
            candidate = current / candidate_name
            if candidate.is_file():
                return candidate
        current = current.parent

    # Also check repo_root itself (unlikely but be thorough)
    for candidate_name in LAYER_FILENAMES:
        candidate = repo_root / candidate_name
        if candidate.is_file():
            return candidate

    return None


def resolve_affected_layers(
    changed_files: list[str],
    repo_root: Path,
) -> ResolveResult:
    """Map a list of changed file paths to their parent taxonomy layers.

    Args:
        changed_files: Relative file paths (from git, pre-commit, etc.)
        repo_root: Absolute path to the repository root.

    Returns:
        A :class:`ResolveResult` containing resolved layers and unmapped files.
    """
    from katalyst_taxonomy.cli.loaders import load_from_filesystem
    from katalyst_taxonomy.taxonomy.utils import extract_layer_type

    repo_root = repo_root.resolve()

    # Load the taxonomy to get FQTNs
    try:
        service = load_from_filesystem(repo_root)
    except Exception:
        logger.warning("Could not load taxonomy from {}", repo_root)
        return ResolveResult(
            layers=(),
            unmapped=tuple(changed_files),
        )

    # Build a reverse index: layer_dir (resolved) -> (doc, fqtn)
    path_index: dict[Path, tuple[Any, str]] = {}
    for doc in service.documents:
        if doc.source_path is not None:
            layer_dir = doc.source_path.parent.resolve()
            fqtn = service.get_qualified_name(doc)
            if fqtn:
                path_index[layer_dir] = (doc, fqtn)

    # Group changed files by layer
    layer_files: dict[str, _LayerAccumulator] = {}
    unmapped: list[str] = []

    for file_str in changed_files:
        file_path = repo_root / file_str
        layer_yaml = find_enclosing_layer_yaml(file_path, repo_root)

        if layer_yaml is None:
            unmapped.append(file_str)
            continue

        layer_dir = layer_yaml.parent.resolve()
        entry = path_index.get(layer_dir)

        if entry is None:
            unmapped.append(file_str)
            continue

        doc, fqtn = entry
        if fqtn not in layer_files:
            layer_type = extract_layer_type(doc)
            rel_dir = str(layer_dir.relative_to(repo_root))
            layer_files[fqtn] = _LayerAccumulator(
                fqtn=fqtn,
                layer_type=layer_type,
                layer_dir=rel_dir,
            )
        layer_files[fqtn].files.append(file_str)

    resolved = tuple(
        ResolvedLayer(
            fqtn=acc.fqtn,
            layer_type=acc.layer_type,
            layer_dir=acc.layer_dir,
            changed_files=tuple(acc.files),
        )
        for acc in layer_files.values()
    )

    return ResolveResult(layers=resolved, unmapped=tuple(unmapped))


@dataclass
class _LayerAccumulator:
    """Mutable helper for grouping files by layer during resolution."""

    fqtn: str
    layer_type: str | None
    layer_dir: str
    files: list[str] = field(default_factory=lambda: list[str]())
