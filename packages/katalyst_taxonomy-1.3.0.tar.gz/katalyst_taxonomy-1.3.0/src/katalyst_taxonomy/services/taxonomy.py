"""Taxonomy service - computes fully qualified names and provides taxonomy operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Sequence

from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.bridge import get_default_registry
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.registry import NodeTypeRegistry
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


def _build_parent_node_types(
    registry: NodeTypeRegistry | None = None,
) -> dict[str, tuple[str, ...] | None]:
    """Build the PARENT_NODE_TYPES dict from the v2 registry.

    Falls back to the default generated registry if none is provided.
    """
    reg = registry or get_default_registry()
    result: dict[str, tuple[str, ...] | None] = {}
    for kind in reg.all_kinds():
        desc = reg.get(kind)
        if desc is None:
            continue
        result[kind] = desc.parent_types
    return result


# Parent type hierarchy for FQTN resolution — now driven by the v2 registry.
# Kept as a module-level dict for backward compatibility with code that imports it.
PARENT_NODE_TYPES: dict[str, tuple[str, ...] | None] = _build_parent_node_types()


def document_lookup_key(document: Document) -> str:
    """Generate a stable lookup key for ``document`` within qualified-name caches."""
    parent = document.parent if document.parent is not None else ""
    source = str(document.source_path) if document.source_path else ""
    return f"{document.taxonomy_node_type}:{parent}:{document.metadata.name}:{source}"


def qualified_name_for(document: Document, qualified_names: Mapping[str, str]) -> str:
    """Return the fully qualified taxonomy name for ``document`` if known."""
    return qualified_names.get(document_lookup_key(document), document.metadata.name)


def build_qualified_names(documents: Sequence[Document]) -> dict[str, str]:
    """Build a mapping of document lookup keys to fully qualified names."""
    index: dict[tuple[str, str], list[Document]] = {}
    for document in documents:
        key = (document.taxonomy_node_type, document.metadata.name)
        index.setdefault(key, []).append(document)

    cache: dict[str, str] = {}
    in_progress: set[str] = set()

    def resolve(document: Document) -> str:
        key = document_lookup_key(document)
        if key in cache:
            return cache[key]
        if key in in_progress:
            cache[key] = document.metadata.name
            return cache[key]
        in_progress.add(key)

        parent_fq = ""
        parent_types = PARENT_NODE_TYPES.get(document.taxonomy_node_type)
        parent_ref = document.parent if document.parent is not None else None
        if parent_types and parent_ref:
            # Collect candidates across all allowed parent types
            candidates: list[Document] = []
            for pt in parent_types:
                candidates.extend(index.get((pt, parent_ref), []))
            selected = _select_parent(document, candidates)
            if selected:
                parent_fq = resolve(selected)
            elif candidates:
                parent_fq = resolve(candidates[0])
            else:
                parent_fq = parent_ref

        fqtn = f"{parent_fq}.{document.metadata.name}" if parent_fq else document.metadata.name
        cache[key] = fqtn
        in_progress.remove(key)
        return fqtn

    for document in documents:
        resolve(document)

    return cache


def _select_parent(
    document: Document,
    candidates: list[Document],
) -> Document | None:
    """Select the best parent candidate based on filesystem proximity."""
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]

    best: Document | None = None
    best_score: tuple[int, int] | None = None

    for candidate in candidates:
        score = _parent_match_score(document, candidate)
        if score is None:
            continue
        if best_score is None or score < best_score:
            best = candidate
            best_score = score
        elif score == best_score:
            # tie: fall back to consistent ordering by path/name
            if best is not None and candidate.source_path and best.source_path:
                if str(candidate.source_path) < str(best.source_path):
                    best = candidate

    return best


def _parent_match_score(
    document: Document,
    candidate: Document,
) -> tuple[int, int] | None:
    """Calculate proximity score between document and potential parent."""
    if document.source_path is None or candidate.source_path is None:
        return None

    doc_parent = document.source_path.parent
    candidate_dir = candidate.source_path.parent

    try:
        relative = doc_parent.relative_to(candidate_dir)
    except ValueError:
        return None

    distance = len(relative.parts)
    depth = len(candidate_dir.parts)
    return (distance, depth)


@dataclass
class TaxonomyService:
    """Service for taxonomy operations including FQTN computation."""

    documents: tuple[Document, ...] = ()
    environments: tuple[EnvironmentDocument, ...] = ()
    errors: tuple[DocumentError, ...] = ()
    _qualified_names: dict[str, str] = field(default_factory=lambda: {}, init=False)

    def __post_init__(self) -> None:
        """Compute qualified names after initialization."""
        self._qualified_names = build_qualified_names(self.documents)

    @property
    def qualified_names(self) -> dict[str, str]:
        """Return the computed qualified names mapping."""
        return self._qualified_names

    def get_qualified_name(self, document: Document) -> str:
        """Get the fully qualified name for a document."""
        return qualified_name_for(document, self._qualified_names)

    def get_document_by_name(self, name: str) -> Document | None:
        """Find a document by its simple name."""
        return next(
            (doc for doc in self.documents if doc.metadata.name == name),
            None,
        )

    def get_documents_by_type(self, node_type: str) -> tuple[Document, ...]:
        """Get all documents of a specific type."""
        return tuple(doc for doc in self.documents if doc.taxonomy_node_type == node_type)

    def sorted_documents(self) -> list[Document]:
        """Return documents sorted by type order and name.

        Uses the v2 registry display_order instead of a hardcoded dict.
        """
        registry = get_default_registry()
        return sorted(
            self.documents,
            key=lambda d: (
                (registry.get(d.taxonomy_node_type) or _FallbackDesc()).display_order,
                d.metadata.name,
            ),
        )

    def group_documents_by_type(self) -> dict[str, list[Document]]:
        """Group documents by their taxonomy node type."""
        grouped: dict[str, list[Document]] = {}
        for doc in self.documents:
            grouped.setdefault(doc.taxonomy_node_type, []).append(doc)
        # Sort each group by name
        for docs in grouped.values():
            docs.sort(key=lambda d: d.metadata.name)
        return grouped


class _FallbackDesc:
    """Fallback for unknown types in display ordering."""

    display_order: int = 99999
