"""Action service — typed access to action documents.

Replaces the v1 ``plugins/actions.py`` loader with engine-native queries.
"""

from __future__ import annotations

# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownArgumentType=false
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from katalyst_taxonomy.domain.environment_contract import (
    EnvironmentContract,
    parse_environment_contract,
)
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.services.template_service import PluginDocumentError


@dataclass(frozen=True, slots=True)
class ActionView:
    """Typed view of an action document.

    Provides the same fields as the old ``LayerAction`` but
    backed by a v2 engine ``Document``.
    """

    name: str
    description: str | None
    action_type: str
    when: str
    run: str
    timeout_seconds: int | None
    environment: tuple[tuple[str, str], ...]
    tags: tuple[str, ...]
    layer_type: str | None
    path: Path
    document_index: int
    environment_contract: EnvironmentContract

    # Keep the underlying document for consumers that need raw access
    document: Document


def load_actions(
    base_path: Path,
) -> ActionServiceResult:
    """Load action documents from the taxonomy at ``base_path``.

    Scans ``.global/taxonomy/actions/`` and ``.global/taxonomy/layer_actions/``
    for action YAML files.
    """
    from katalyst_taxonomy.domain.errors import DocumentError
    from katalyst_taxonomy.engine.parsing import parse_yaml_documents

    # Actions live in .global/taxonomy/actions/ or .global/taxonomy/layer_actions/
    actions_dirs: list[Path] = []
    for dirname in ("actions", "layer_actions"):
        d = base_path / ".global" / "taxonomy" / dirname
        if d.exists():
            actions_dirs.append(d)

    if not actions_dirs:
        return ActionServiceResult(
            actions=(),
            errors=(),
            _actions_by_name={},
            _actions_by_layer_type={},
        )

    # Discover YAML files recursively (actions can be in subdirs like tools/)
    yaml_files: list[Path] = []
    for actions_dir in actions_dirs:
        for pattern in ("**/*.yaml", "**/*.yml"):
            yaml_files.extend(actions_dir.glob(pattern))
    yaml_files = sorted(set(yaml_files))

    views: list[ActionView] = []
    errors: list[PluginDocumentError] = []

    for path in yaml_files:
        # Skip Just recipes and non-plugin files
        if path.name == "Justfile" or path.suffix not in (".yaml", ".yml"):
            continue

        env_docs: list[object] = []
        parse_errors: list[DocumentError] = []
        docs = parse_yaml_documents(
            path,
            environment_documents=env_docs,  # type: ignore[arg-type]
            errors=parse_errors,
        )

        for err in parse_errors:
            errors.append(
                PluginDocumentError(
                    path=err.path,
                    document_index=err.document_index,
                    message=err.message,
                )
            )

        for doc_index, doc in enumerate(docs, start=1):
            if doc.kind != "action":
                continue
            try:
                view = _build_action_view(doc, path, doc_index)
                views.append(view)
            except ValueError as exc:
                errors.append(
                    PluginDocumentError(
                        path=path,
                        document_index=doc_index,
                        message=str(exc),
                    )
                )

    # Build indexes
    by_name: dict[str, ActionView] = {}
    by_layer_type: dict[str, tuple[ActionView, ...]] = {}
    for view in views:
        by_name[view.name] = view
        lt_key = view.layer_type or ""
        existing = by_layer_type.get(lt_key, ())
        by_layer_type[lt_key] = existing + (view,)

    logger.info("Loaded {} actions", len(views))

    return ActionServiceResult(
        actions=tuple(views),
        errors=tuple(errors),
        _actions_by_name=by_name,
        _actions_by_layer_type=by_layer_type,
    )


@dataclass(frozen=True, slots=True)
class ActionServiceResult:
    """Result of loading actions — drop-in replacement for LayerActionsPluginResult."""

    actions: tuple[ActionView, ...]
    errors: tuple[PluginDocumentError, ...]
    _actions_by_name: dict[str, ActionView]
    _actions_by_layer_type: dict[str, tuple[ActionView, ...]]

    def action(self, name: str) -> ActionView | None:
        return self._actions_by_name.get(name)

    def actions_for_layer_type(self, layer_type: str) -> tuple[ActionView, ...]:
        return self._actions_by_layer_type.get(layer_type, ())

    def layer_types(self) -> tuple[str, ...]:
        return tuple(sorted(self._actions_by_layer_type.keys()))

    def unscoped_actions(self) -> tuple[ActionView, ...]:
        return self._actions_by_layer_type.get("", ())


def _build_action_view(
    doc: Document,
    path: Path,
    index: int,
) -> ActionView:
    """Build an ActionView from a v2 Document."""
    spec = doc.spec

    action_type = spec.get("action_type")
    if not isinstance(action_type, str) or not action_type:
        raise ValueError(f"spec.action_type is required (path={path}, document={index})")

    when = spec.get("when")
    if not isinstance(when, str) or not when:
        raise ValueError(f"spec.when is required (path={path}, document={index})")

    run = spec.get("run")
    if not isinstance(run, str) or not run:
        raise ValueError(f"spec.run is required (path={path}, document={index})")

    timeout_seconds = spec.get("timeout_seconds")
    if timeout_seconds is not None:
        if not isinstance(timeout_seconds, int) or timeout_seconds <= 0:
            raise ValueError(
                f"spec.timeout_seconds must be a positive integer (path={path}, document={index})"
            )

    # Extract environment key-value pairs
    env_raw = spec.get("action_environment")
    environment: tuple[tuple[str, str], ...] = ()
    if isinstance(env_raw, dict):
        environment = tuple(sorted((str(k), str(v)) for k, v in env_raw.items()))

    tags_raw = spec.get("action_tags")
    tags: tuple[str, ...] = ()
    if isinstance(tags_raw, (list, tuple)):
        tags = tuple(str(t) for t in tags_raw if isinstance(t, str))

    # Extract layer type from extends target
    layer_type: str | None = None
    if doc.extends is not None:
        if doc.extends.target_kind == "template" and doc.extends.target_names:
            first_target = doc.extends.target_names[0]
            if first_target != "*":
                layer_type = first_target

    environment_contract = parse_environment_contract(spec.get("environment_contract"))

    return ActionView(
        name=doc.name,
        description=doc.description,
        action_type=action_type,
        when=when,
        run=run,
        timeout_seconds=timeout_seconds,
        environment=environment,
        tags=tags,
        layer_type=layer_type,
        path=path,
        document_index=index,
        environment_contract=environment_contract,
        document=doc,
    )


# --- Backward-compatible aliases ---
LayerAction = ActionView
LayerActionsPluginResult = ActionServiceResult
load_layer_actions = load_actions
