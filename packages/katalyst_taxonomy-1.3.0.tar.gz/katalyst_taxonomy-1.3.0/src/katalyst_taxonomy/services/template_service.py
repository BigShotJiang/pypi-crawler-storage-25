"""Template service — typed access to template (layer type) documents.

Replaces the v1 ``plugins/templates.py`` loader with engine-native queries.
"""

from __future__ import annotations

# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownArgumentType=false
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from katalyst_taxonomy.domain.environment_contract import (
    EnvironmentContract,
    parse_environment_contract,
)
from katalyst_taxonomy.engine.document import Document


@dataclass(frozen=True, slots=True)
class TemplateView:
    """Typed view of a template document.

    Provides the same fields as the old ``LayerTypeDefinition`` but
    backed by a v2 engine ``Document``.
    """

    name: str
    description: str | None
    template_path: Path
    default_layer_dir: str
    optional_paths: tuple[str, ...]
    environment_contract: EnvironmentContract
    global_template_path: Path | None
    path: Path
    document_index: int

    # Keep the underlying document for consumers that need raw access
    document: Document


def load_templates(
    base_path: Path,
) -> TemplateServiceResult:
    """Load template documents from the taxonomy at ``base_path``.

    Scans ``.global/taxonomy/layer_types/`` for template YAML files,
    parses them through the v2 engine, and returns typed views.
    """
    from katalyst_taxonomy.domain.errors import DocumentError
    from katalyst_taxonomy.engine.parsing import parse_yaml_documents

    # Template definitions live in .global/taxonomy/layer_types/
    # We scan only top-level YAML files (not Jinja2 template subdirs)
    layer_types_dir = base_path / ".global" / "taxonomy" / "layer_types"
    if not layer_types_dir.exists():
        # Also check the old path before giving up
        layer_types_dir = base_path / ".global" / "taxonomy" / "layerTypes"
        if not layer_types_dir.exists():
            return TemplateServiceResult(
                definitions=(),
                errors=(),
                _definitions_by_name={},
            )

    # Discover top-level YAML files only (skip template subdirectories)
    yaml_files = sorted(
        p for p in layer_types_dir.iterdir() if p.is_file() and p.suffix in (".yaml", ".yml")
    )

    views: list[TemplateView] = []
    errors: list[PluginDocumentError] = []

    for path in yaml_files:
        env_docs: list[object] = []
        parse_errors: list[DocumentError] = []
        docs = parse_yaml_documents(
            path,
            environment_documents=env_docs,  # type: ignore[arg-type]
            errors=parse_errors,
        )

        for err in parse_errors:
            errors.append(
                PluginDocumentError(
                    path=err.path,
                    document_index=err.document_index,
                    message=err.message,
                )
            )

        for doc_index, doc in enumerate(docs, start=1):
            if doc.kind != "template":
                continue
            try:
                view = _build_template_view(doc, path, doc_index, base_path)
                views.append(view)
            except ValueError as exc:
                errors.append(
                    PluginDocumentError(
                        path=path,
                        document_index=doc_index,
                        message=str(exc),
                    )
                )

    by_name = {v.name: v for v in views}
    logger.info("Loaded {} templates, {} errors", len(views), len(errors))

    return TemplateServiceResult(
        definitions=tuple(views),
        errors=tuple(errors),
        _definitions_by_name=by_name,
    )


@dataclass(frozen=True, slots=True)
class PluginDocumentError:
    """Error encountered while parsing a plugin document."""

    path: Path
    document_index: int
    message: str


@dataclass(frozen=True, slots=True)
class TemplateServiceResult:
    """Result of loading templates — drop-in replacement for LayerTypesPluginResult."""

    definitions: tuple[TemplateView, ...]
    errors: tuple[PluginDocumentError, ...]
    _definitions_by_name: dict[str, TemplateView]

    def definition(self, name: str) -> TemplateView | None:
        return self._definitions_by_name.get(name)


def _build_template_view(
    doc: Document,
    path: Path,
    index: int,
    base_path: Path,
) -> TemplateView:
    """Build a TemplateView from a v2 Document."""
    spec = doc.spec

    template_value = spec.get("template_path")
    if not isinstance(template_value, str) or not template_value:
        raise ValueError(f"spec.template_path is required (path={path}, document={index})")

    template_path = _resolve_template_path(template_value, path, base_path)

    default_layer_dir = spec.get("default_layer_dir")
    if not isinstance(default_layer_dir, str) or not default_layer_dir.strip():
        raise ValueError(f"spec.default_layer_dir is required (path={path}, document={index})")

    optional_paths_raw = spec.get("optional_paths")
    optional_paths: tuple[str, ...] = ()
    if isinstance(optional_paths_raw, (list, tuple)):
        optional_paths = tuple(str(p) for p in optional_paths_raw if isinstance(p, str))

    environment_contract = parse_environment_contract(spec.get("environment_contract"))

    global_template_path = _resolve_global_template_path(
        spec.get("global_template_path"), path, base_path
    )

    return TemplateView(
        name=doc.name,
        description=doc.description,
        template_path=template_path,
        default_layer_dir=default_layer_dir.strip(),
        optional_paths=optional_paths,
        environment_contract=environment_contract,
        global_template_path=global_template_path,
        path=path,
        document_index=index,
        document=doc,
    )


def _resolve_template_path(
    template_value: str,
    document_path: Path,
    base_path: Path,
) -> Path:
    """Resolve a template path relative to the document or base."""
    candidates = [
        document_path.parent / template_value,
        base_path / template_value,
    ]
    taxonomy_dir = base_path / ".global" / "taxonomy" / "layerTypes"
    if taxonomy_dir.exists():
        candidates.append(taxonomy_dir / template_value)
    taxonomy_dir2 = base_path / ".global" / "taxonomy" / "layer_types"
    if taxonomy_dir2.exists():
        candidates.append(taxonomy_dir2 / template_value)

    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate

    raise ValueError(f"spec.template_path references '{template_value}' which does not exist")


def _resolve_global_template_path(
    value: object,
    document_path: Path,
    base_path: Path,
) -> Path | None:
    """Resolve optional global template path."""
    if value is None or not isinstance(value, str) or not value.strip():
        return None
    candidates = [document_path.parent / value, base_path / value]
    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate
    return None


# --- Backward-compatible aliases ---
# These allow gradual migration of callers.
LayerTypeDefinition = TemplateView
LayerTypesPluginResult = TemplateServiceResult
load_layer_types = load_templates
