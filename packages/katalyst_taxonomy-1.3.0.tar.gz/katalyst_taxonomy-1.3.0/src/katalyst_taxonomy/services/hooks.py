"""Service for managing git hooks that integrate with kata actions.

This module provides:
- Loading and validating ``.katalyst-hooks.yaml`` configuration
- Generating native tool configs (pre-commit, Husky, lefthook)
- Running kata actions dispatched by file-to-layer resolution
- Detecting the configured hook tool
"""

from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import IO, Any, cast

import yaml
from loguru import logger

HOOKS_CONFIG_FILENAME = ".katalyst-hooks.yaml"
HOOKS_API_VERSION = "katalyst.taxonomy.hooks/v1alpha"
HOOKS_KIND = "HookConfig"
SUPPORTED_TOOLS = ("pre-commit", "husky", "lefthook")


# ---------------------------------------------------------------------------
# Domain models
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class KataActionEntry:
    """A single kata action reference in the hooks config."""

    action: str
    stage: str = "pre-commit"
    tags: tuple[str, ...] = ()
    env_required: bool = False


@dataclass(frozen=True, slots=True)
class AdditionalHookEntry:
    """A direct tool invocation (not a kata action)."""

    name: str
    stage: str
    run: str
    files: str = ".*"
    description: str = ""


@dataclass(frozen=True, slots=True)
class HookConfig:
    """Parsed .katalyst-hooks.yaml configuration."""

    tool: str
    kata_actions: dict[str, tuple[KataActionEntry, ...]]  # layer_type -> actions
    additional_hooks: tuple[AdditionalHookEntry, ...]
    path: Path


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


def load_hooks_config(repo_root: Path) -> HookConfig | None:
    """Load the hooks config from the repository root.

    Returns ``None`` if no config file is found.
    """
    config_path = repo_root / HOOKS_CONFIG_FILENAME
    if not config_path.is_file():
        return None

    raw_yaml: Any = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    if not isinstance(raw_yaml, dict):
        return None

    raw = cast(dict[str, Any], raw_yaml)
    spec = cast(dict[str, Any], raw.get("spec", {}))
    tool: str = str(spec.get("tool", "pre-commit"))
    if tool not in SUPPORTED_TOOLS:
        logger.warning("Unsupported hook tool '{}', defaulting to pre-commit", tool)
        tool = "pre-commit"

    # Parse kata_actions
    kata_actions: dict[str, tuple[KataActionEntry, ...]] = {}
    raw_actions = spec.get("kata_actions", {})
    if isinstance(raw_actions, dict):
        raw_actions_typed = cast(dict[str, Any], raw_actions)
        for layer_type_key, entries_val in raw_actions_typed.items():
            if isinstance(entries_val, list):
                entries_list = cast(list[Any], entries_val)
                parsed: list[KataActionEntry] = []
                for entry_val in entries_list:
                    if isinstance(entry_val, dict):
                        entry = cast(dict[str, Any], entry_val)
                        tags_raw = entry.get("tags", [])
                        tags_list = cast(list[Any], tags_raw) if isinstance(tags_raw, list) else []
                        parsed.append(
                            KataActionEntry(
                                action=str(entry.get("action", "")),
                                stage=str(entry.get("stage", "pre-commit")),
                                tags=tuple(str(t) for t in tags_list),
                                env_required=bool(entry.get("env_required", False)),
                            )
                        )
                kata_actions[layer_type_key] = tuple(parsed)

    # Parse additional_hooks
    additional_hooks: list[AdditionalHookEntry] = []
    raw_hooks = spec.get("additional_hooks", [])
    if isinstance(raw_hooks, list):
        raw_hooks_typed = cast(list[Any], raw_hooks)
        for hook_val in raw_hooks_typed:
            if isinstance(hook_val, dict):
                hook_entry = cast(dict[str, Any], hook_val)
                additional_hooks.append(
                    AdditionalHookEntry(
                        name=str(hook_entry.get("name", "")),
                        stage=str(hook_entry.get("stage", "pre-commit")),
                        run=str(hook_entry.get("run", "")),
                        files=str(hook_entry.get("files", ".*")),
                        description=str(hook_entry.get("description", "")),
                    )
                )

    return HookConfig(
        tool=tool,
        kata_actions=kata_actions,
        additional_hooks=tuple(additional_hooks),
        path=config_path,
    )


# ---------------------------------------------------------------------------
# Detection
# ---------------------------------------------------------------------------


def detect_tool(repo_root: Path) -> str | None:
    """Detect the configured hook tool from .katalyst-hooks.yaml."""
    config = load_hooks_config(repo_root)
    if config is None:
        return None
    return config.tool


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def validate_hooks_config(
    repo_root: Path,
    out: IO[str] = sys.stdout,
    err: IO[str] = sys.stderr,
) -> int:
    """Validate the hooks config against installed actions.

    Returns 0 on success, 1 on validation failure.
    """
    config = load_hooks_config(repo_root)
    if config is None:
        err.write("Error: no hooks config found (.katalyst-hooks.yaml)\n")
        return 1

    # Load available actions
    from katalyst_taxonomy.services.action_service import load_layer_actions

    actions_result = load_layer_actions(repo_root)
    all_actions = {a.name for a in actions_result.actions}

    errors: list[str] = []
    for layer_type, entries in config.kata_actions.items():
        for entry in entries:
            if entry.action and entry.action not in all_actions:
                errors.append(
                    f"Action '{entry.action}' (layer type: {layer_type}) not found "
                    f"in installed actions"
                )

    if errors:
        err.write("Hooks config validation failed:\n")
        for error in errors:
            err.write(f"  - {error}\n")
        return 1

    out.write("Hooks config is valid.\n")
    return 0


# ---------------------------------------------------------------------------
# Generation
# ---------------------------------------------------------------------------


def generate_native_config(
    repo_root: Path,
    tool_override: str | None = None,
    out: IO[str] = sys.stdout,
    err: IO[str] = sys.stderr,
) -> int:
    """Generate native hook tool config from .katalyst-hooks.yaml.

    Returns 0 on success, 1 on error.
    """
    config = load_hooks_config(repo_root)
    if config is None:
        err.write("Error: no hooks config found (.katalyst-hooks.yaml)\n")
        return 1

    tool = tool_override or config.tool

    if tool == "pre-commit":
        return _generate_pre_commit(config, repo_root, out)
    elif tool == "husky":
        return _generate_husky(config, repo_root, out)
    elif tool == "lefthook":
        return _generate_lefthook(config, repo_root, out)
    else:
        err.write(f"Error: unsupported tool '{tool}'\n")
        return 1


def _generate_pre_commit(config: HookConfig, repo_root: Path, out: IO[str]) -> int:
    """Generate .pre-commit-config.yaml."""
    hooks: list[dict[str, Any]] = []

    # Kata action-backed hooks
    for layer_type, entries in config.kata_actions.items():
        for entry in entries:
            if not entry.action:
                continue
            hooks.append(
                {
                    "id": f"kata-{entry.action}",
                    "name": f"kata: {entry.action} ({layer_type})",
                    "entry": f"kata tax hooks run --action {entry.action}",
                    "language": "system",
                    "pass_filenames": True,
                }
            )

    # Additional hooks
    for hook in config.additional_hooks:
        hooks.append(
            {
                "id": hook.name,
                "name": hook.name,
                "entry": hook.run,
                "language": "system",
                "files": hook.files,
                "pass_filenames": False,
            }
        )

    pre_commit_config: dict[str, Any] = {
        "repos": [
            {
                "repo": "local",
                "hooks": hooks,
            }
        ]
    }

    output_path = repo_root / ".pre-commit-config.yaml"
    output_path.write_text(
        yaml.dump(pre_commit_config, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    out.write(f"Generated {output_path}\n")
    return 0


def _generate_husky(config: HookConfig, repo_root: Path, out: IO[str]) -> int:
    """Generate .husky/pre-commit shell script."""
    husky_dir = repo_root / ".husky"
    husky_dir.mkdir(parents=True, exist_ok=True)

    lines = ["#!/usr/bin/env sh", '. "$(dirname -- "$0")/_/husky.sh"', ""]

    # Kata action hooks
    action_names: list[str] = []
    for _layer_type, entries in config.kata_actions.items():
        for entry in entries:
            if entry.action:
                action_names.append(entry.action)
    if action_names:
        action_args = " ".join(f"--action {a}" for a in action_names)
        lines.append(f"kata tax hooks run {action_args}")
        lines.append("")

    # Additional hooks
    for hook in config.additional_hooks:
        lines.append(f"# {hook.name}")
        lines.append(hook.run)
        lines.append("")

    script_path = husky_dir / "pre-commit"
    script_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    script_path.chmod(0o755)
    out.write(f"Generated {script_path}\n")
    return 0


def _generate_lefthook(config: HookConfig, repo_root: Path, out: IO[str]) -> int:
    """Generate lefthook.yml."""
    commands: dict[str, Any] = {}

    # Kata action hooks
    for _layer_type, entries in config.kata_actions.items():
        for entry in entries:
            if not entry.action:
                continue
            commands[f"kata-{entry.action}"] = {
                "run": f"kata tax hooks run --action {entry.action} {{staged_files}}",
            }

    # Additional hooks
    for hook in config.additional_hooks:
        commands[hook.name] = {
            "run": hook.run,
        }
        if hook.files and hook.files != ".*":
            commands[hook.name]["glob"] = hook.files

    lefthook_config: dict[str, Any] = {
        "pre-commit": {
            "commands": commands,
        }
    }

    output_path = repo_root / "lefthook.yml"
    output_path.write_text(
        yaml.dump(lefthook_config, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    out.write(f"Generated {output_path}\n")
    return 0


# ---------------------------------------------------------------------------
# Hook execution
# ---------------------------------------------------------------------------


def run_hooks(
    repo_root: Path,
    actions: list[str],
    files: list[str],
    *,
    dry_run: bool = False,
    environment: str | None = None,
    out: IO[str] = sys.stdout,
    err: IO[str] = sys.stderr,
) -> int:
    """Run kata actions against layers affected by the given files.

    This is the entry point called by all hook tools.  It resolves files to
    layers, filters actions by layer type, and dispatches ``kata tax action run``
    for each affected layer.

    Returns 0 if all actions pass, 1 if any fail.
    """
    from katalyst_taxonomy.services.resolve import resolve_affected_layers

    result = resolve_affected_layers(files, repo_root)

    if not result.layers:
        out.write("No layers affected by changed files — skipped.\n")
        if result.unmapped:
            out.write(f"  Unmapped files: {', '.join(result.unmapped[:5])}")
            if len(result.unmapped) > 5:
                out.write(f" (and {len(result.unmapped) - 5} more)")
            out.write("\n")
        return 0

    # Load available actions to filter by layer type
    from katalyst_taxonomy.services.action_service import load_layer_actions

    actions_result = load_layer_actions(repo_root)
    action_names_set = {a.name for a in actions_result.actions}

    exit_code = 0
    for layer in result.layers:
        # Filter requested actions to those that apply to this layer's type
        applicable_actions: list[str] = []
        for action_name in actions:
            if action_name not in action_names_set:
                continue
            # Check if action is scoped to this layer type or unscoped
            typed = actions_result.actions_for_layer_type(layer.layer_type or "")
            unscoped = actions_result.unscoped_actions()
            available = {a.name for a in typed + unscoped}
            if action_name in available:
                applicable_actions.append(action_name)

        for action_name in applicable_actions:
            if dry_run:
                out.write(f"Would run: kata tax action run {action_name} {layer.fqtn}\n")
            else:
                out.write(f"Running: kata tax action run {action_name} {layer.fqtn}\n")
                cmd: list[str] = [
                    "kata",
                    "tax",
                    "--path",
                    str(repo_root),
                    "action",
                    "run",
                    action_name,
                    layer.fqtn,
                ]
                if environment:
                    cmd.extend(["--env", environment])

                proc = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                )
                if proc.stdout:
                    out.write(proc.stdout)
                if proc.returncode != 0:
                    if proc.stderr:
                        err.write(proc.stderr)
                    exit_code = 1

    return exit_code
