"""Scaffolding service — resolves scaffolding plans with extension merging.

Replaces the v1 ``plugins/scaffolding.py`` with engine-native queries.
"""

from __future__ import annotations

# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownArgumentType=false
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.parsing import parse_yaml_documents
from katalyst_taxonomy.engine.store import DocumentStore


@dataclass(frozen=True, slots=True)
class ExtensionContribution:
    """Describes files contributed by an extension.

    Attributes:
        extension_name: Name of the contributing extension
        extension_path: Path to the extension definition file
        template_path: Path to template directory (if using template mode)
        files: Explicit file mappings (source, destination) if specified
    """

    extension_name: str
    extension_path: Path
    template_path: Path | None
    files: tuple[tuple[str, str], ...]


@dataclass(frozen=True, slots=True)
class ScaffoldingPlan:
    """A plan for scaffolding a layer with extensions.

    Attributes:
        layer_type_name: Name of the layer type being scaffolded
        base_template_path: Path to the base layer type template
        extensions: Active extension contributions in order
        inactive_extensions: Names of extensions that were not activated
    """

    layer_type_name: str
    base_template_path: Path
    extensions: tuple[ExtensionContribution, ...]
    inactive_extensions: tuple[str, ...]

    @property
    def has_extensions(self) -> bool:
        return len(self.extensions) > 0

    @property
    def extension_names(self) -> tuple[str, ...]:
        return tuple(ext.extension_name for ext in self.extensions)


def resolve_scaffolding_plan(
    layer_type_name: str,
    base_template_path: Path,
    plugins_path: Path,
) -> ScaffoldingPlan:
    """Resolve a scaffolding plan for a layer type.

    Loads all documents from ``plugins_path`` into a DocumentStore,
    resolves active extensions for the given template, and builds
    contribution records.

    Args:
        layer_type_name: Name of the template being scaffolded
        base_template_path: Path to the base template directory
        plugins_path: Path to the plugins directory (.global/taxonomy)
    """
    # Build a store from all YAML files in the plugins path
    store = _build_store(plugins_path)

    # Find all extensions targeting this template
    all_extensions = store.extensions_for("template", layer_type_name)
    active_extensions = store.active_extensions_for("template", layer_type_name)

    active_names = {doc.name for doc in active_extensions}
    inactive_names = tuple(doc.name for doc in all_extensions if doc.name not in active_names)

    # Build contributions from active extensions
    contributions = tuple(_build_contribution(doc, plugins_path) for doc in active_extensions)

    logger.debug(
        "Scaffolding plan for '{}': {} active, {} inactive extensions",
        layer_type_name,
        len(contributions),
        len(inactive_names),
    )

    return ScaffoldingPlan(
        layer_type_name=layer_type_name,
        base_template_path=base_template_path,
        extensions=contributions,
        inactive_extensions=inactive_names,
    )


def _build_store(plugins_path: Path) -> DocumentStore:
    """Build a DocumentStore from all YAML files in plugins_path.

    Skips files deep inside layer_types/ subdirectories (Jinja2 templates).
    """
    store = DocumentStore()
    if not plugins_path.exists():
        return store

    _TEMPLATE_PARENTS = {"layer_types", "layerTypes"}

    yaml_files: list[Path] = []
    for pattern in ("**/*.yaml", "**/*.yml"):
        for path in plugins_path.glob(pattern):
            try:
                rel = path.relative_to(plugins_path)
            except ValueError:
                continue
            parts = rel.parts
            if len(parts) >= 3 and parts[0] in _TEMPLATE_PARENTS:
                continue
            yaml_files.append(path)

    from katalyst_taxonomy.domain.errors import DocumentError
    from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

    for yaml_file in sorted(yaml_files):
        env_docs: list[EnvironmentDocument] = []
        errors: list[DocumentError] = []
        docs = parse_yaml_documents(yaml_file, environment_documents=env_docs, errors=errors)
        store.add_many(docs)

    return store


def _build_contribution(doc: Document, plugins_path: Path) -> ExtensionContribution:
    """Build an ExtensionContribution from a template_overlay Document."""
    spec = doc.spec

    # Resolve template path
    template_path: Path | None = None
    provides_template = spec.get("provides_template")
    if isinstance(provides_template, str) and provides_template:
        # Try relative to extension file's directory
        if doc.source_path is not None:
            candidate = doc.source_path.parent / provides_template
            if candidate.exists():
                template_path = candidate
        # Try relative to plugins_path
        if template_path is None:
            candidate = plugins_path / provides_template
            if candidate.exists():
                template_path = candidate

    # Parse explicit file mappings
    files: list[tuple[str, str]] = []
    provides_files = spec.get("provides_files")
    if isinstance(provides_files, (list, tuple)):
        for entry in provides_files:
            if isinstance(entry, str) and ":" in entry:
                parts = entry.split(":", 1)
                files.append((parts[0], parts[1]))
            elif isinstance(entry, dict):
                src = entry.get("source", "")
                dest = entry.get("destination", "")
                if src and dest:
                    files.append((str(src), str(dest)))

    return ExtensionContribution(
        extension_name=doc.name,
        extension_path=doc.source_path or Path("unknown"),
        template_path=template_path,
        files=tuple(files),
    )
