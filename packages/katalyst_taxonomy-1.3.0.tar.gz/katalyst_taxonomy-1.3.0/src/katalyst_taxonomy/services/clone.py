"""Clone service for copying taxonomy nodes."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Protocol, cast, runtime_checkable

import yaml

from katalyst_taxonomy.ports.filesystem import FilesystemPort, RealFilesystem

# Type alias for YAML document dicts from taxonomy parsing
TaxonomyDict = dict[str, Any]


class CloneStatus(Enum):
    """Status of a clone operation."""

    SUCCESS = "success"
    FAILED = "failed"
    SOURCE_NOT_FOUND = "source_not_found"
    TARGET_EXISTS = "target_exists"
    AMBIGUOUS = "ambiguous"
    INVALID_HIERARCHY = "invalid_hierarchy"
    CANCELLED = "cancelled"


@dataclass(frozen=True)
class ClonedNode:
    """Information about a cloned node."""

    name: str
    node_type: str
    source_path: Path
    target_path: Path


@dataclass(frozen=True)
class CloneConfig:
    """Configuration for cloning a taxonomy node."""

    target_path: Path
    node_type: str  # "layer", "stack"
    source_name: str
    target_name: str

    # Source hierarchy hints for disambiguation
    source_system: str | None = None
    source_stack: str | None = None

    # Target hierarchy (defaults to source if not specified)
    target_system: str | None = None
    target_stack: str | None = None

    # Overrides
    description: str | None = None
    owners: tuple[str, ...] = ()
    environments: tuple[str, ...] = ()
    layer_type: str | None = None

    # Auto-create descriptions
    stack_description: str | None = None

    # Behavior flags
    scaffold: bool = False
    interactive: bool = False

    def __post_init__(self) -> None:
        """Convert sequences to tuples for immutability."""
        if isinstance(self.owners, list):
            object.__setattr__(self, "owners", tuple(self.owners))
        if isinstance(self.environments, list):
            object.__setattr__(self, "environments", tuple(self.environments))


@dataclass(frozen=True)
class CloneResult:
    """Result of a clone operation."""

    status: CloneStatus
    cloned: ClonedNode | None = None
    created_parents: tuple[str, ...] = ()
    matches: tuple[str, ...] = ()  # For ambiguous results
    error: str | None = None

    @property
    def is_success(self) -> bool:
        """Check if the operation was successful."""
        return self.status == CloneStatus.SUCCESS


# Use FilesystemPort from ports.filesystem for filesystem operations
# These aliases are kept for backwards compatibility with existing code
CloneFilesystem = FilesystemPort
RealCloneFilesystem = RealFilesystem


@runtime_checkable
class TaxonomyLoader(Protocol):
    """Protocol for loading taxonomy documents."""

    def load(self, path: Path) -> TaxonomyDict:
        """Load taxonomy and return documents."""
        ...

    def find_by_name(self, name: str, node_type: str | None = None) -> list[TaxonomyDict]:
        """Find documents by name and optional type."""
        ...


class CloneService:
    """Service for cloning taxonomy nodes."""

    def __init__(
        self,
        filesystem: CloneFilesystem,
        taxonomy_loader: TaxonomyLoader,
    ) -> None:
        """Initialize the service with adapters."""
        self._filesystem = filesystem
        self._taxonomy_loader = taxonomy_loader

    def clone(self, config: CloneConfig) -> CloneResult:
        """Clone a taxonomy node.

        Args:
            config: Clone configuration.

        Returns:
            CloneResult with status and details.
        """
        # Load taxonomy to find source
        taxonomy_data = self._taxonomy_loader.load(config.target_path)
        documents = taxonomy_data.get("documents", [])

        # Find source node
        source_result = self._find_source_node(documents, config)
        if source_result.status != CloneStatus.SUCCESS:
            return source_result

        # The cloned field temporarily holds the source dict (see _find_source_node)
        if source_result.cloned is None:
            return CloneResult(
                status=CloneStatus.FAILED,
                error="Internal error: source document not found",
            )
        source_doc = cast(TaxonomyDict, source_result.cloned)

        # Get source path
        source_path_str = source_doc.get("sourcePath")
        if not source_path_str:
            return CloneResult(
                status=CloneStatus.FAILED,
                error=f"Source node '{config.source_name}' has no file path",
            )
        source_path = Path(source_path_str).parent  # Directory containing the yaml

        # Determine target path
        target_path = self._compute_target_path(config, source_path)

        # Check if target exists
        if self._filesystem.exists(target_path):
            return CloneResult(
                status=CloneStatus.TARGET_EXISTS,
                error=f"Target '{config.target_name}' already exists at {target_path}",
            )

        # Handle scaffold mode
        if config.scaffold:
            return self._clone_with_scaffold(config, source_doc, source_path, target_path)

        # Regular clone - copy files with replacements
        return self._clone_with_copy(config, source_doc, source_path, target_path)

    def _find_source_node(
        self,
        documents: list[TaxonomyDict],
        config: CloneConfig,
    ) -> CloneResult:
        """Find the source node in the taxonomy.

        Returns CloneResult with:
        - SUCCESS and source doc in a wrapper if found uniquely
        - AMBIGUOUS if multiple matches
        - SOURCE_NOT_FOUND if no matches
        """
        # Filter by name and type
        matches = [
            doc
            for doc in documents
            if doc.get("metadata", {}).get("name") == config.source_name
            and doc.get("taxonomyNodeType") == config.node_type
        ]

        if not matches:
            return CloneResult(
                status=CloneStatus.SOURCE_NOT_FOUND,
                error=f"{config.node_type.title()} '{config.source_name}' not found",
            )

        # Apply hierarchy hints to narrow down
        if len(matches) > 1:
            matches = self._filter_by_hierarchy(matches, config)

        if not matches:
            return CloneResult(
                status=CloneStatus.SOURCE_NOT_FOUND,
                error=f"{config.node_type.title()} '{config.source_name}' not found with specified hierarchy",
            )

        if len(matches) > 1:
            # Still ambiguous - return matches for user feedback
            match_names = tuple(
                doc.get("sourcePath", doc.get("metadata", {}).get("name", "unknown"))
                for doc in matches
            )
            return CloneResult(
                status=CloneStatus.AMBIGUOUS,
                error=f"Found {len(matches)} {config.node_type}s named '{config.source_name}'",
                matches=match_names,
            )

        # Found exactly one - return it wrapped in a fake ClonedNode for transport
        # (We'll extract the doc in the caller)
        return CloneResult(
            status=CloneStatus.SUCCESS,
            cloned=matches[0],  # type: ignore[arg-type] - temporary hack
        )

    def _filter_by_hierarchy(
        self,
        documents: list[TaxonomyDict],
        config: CloneConfig,
    ) -> list[TaxonomyDict]:
        """Filter documents by hierarchy hints."""
        filtered = documents

        # For now, use source path matching as a simple heuristic
        if config.source_stack:
            filtered = [
                doc for doc in filtered if config.source_stack in str(doc.get("sourcePath", ""))
            ]

        if config.source_system:
            filtered = [
                doc for doc in filtered if config.source_system in str(doc.get("sourcePath", ""))
            ]

        return filtered

    def _compute_target_path(self, config: CloneConfig, source_path: Path) -> Path:
        """Compute the target path for the clone."""
        # Replace source name with target name in the path
        source_path_str = str(source_path)
        target_path_str = source_path_str.replace(config.source_name, config.target_name)

        # Handle cross-stack/system cloning
        if config.target_stack and config.source_stack:
            target_path_str = target_path_str.replace(config.source_stack, config.target_stack)

        if config.target_system and config.source_system:
            target_path_str = target_path_str.replace(config.source_system, config.target_system)

        return Path(target_path_str)

    def _clone_with_copy(
        self,
        config: CloneConfig,
        source_doc: TaxonomyDict,
        source_path: Path,
        target_path: Path,
    ) -> CloneResult:
        """Clone by copying files with replacements."""
        # Build replacements
        replacements = self._build_replacements(config, source_doc)

        # Copy the tree
        self._filesystem.copy_tree_with_replacements(source_path, target_path, replacements)

        # Update the taxonomy YAML in the target
        self._update_target_yaml(config, source_doc, target_path)

        return CloneResult(
            status=CloneStatus.SUCCESS,
            cloned=ClonedNode(
                name=config.target_name,
                node_type=config.node_type,
                source_path=source_path,
                target_path=target_path,
            ),
        )

    def _clone_with_scaffold(
        self,
        config: CloneConfig,
        source_doc: TaxonomyDict,
        source_path: Path,
        target_path: Path,
    ) -> CloneResult:
        """Clone by scaffolding from layer type template with extension support."""
        from katalyst_taxonomy.services.scaffolding_service import resolve_scaffolding_plan

        # Get layer type
        layer_type = config.layer_type or source_doc.get("spec", {}).get("layerType")
        if not layer_type:
            return CloneResult(
                status=CloneStatus.FAILED,
                error="Cannot scaffold: no layer type specified",
            )

        # Check if layer type is installed
        layer_type_path = config.target_path / ".global" / "taxonomy" / "layer_types" / layer_type
        if not self._filesystem.exists(layer_type_path):
            return CloneResult(
                status=CloneStatus.FAILED,
                error=f"Layer type '{layer_type}' is not installed. Use 'kata tax add --layer-type {layer_type}' first.",
            )

        # Build replacements
        replacements = self._build_replacements(config, source_doc)

        # Copy from layer type template (base)
        self._filesystem.copy_tree_with_replacements(layer_type_path, target_path, replacements)

        # Resolve scaffolding plan to get active extensions
        plugins_path = config.target_path / ".global" / "taxonomy"
        plan = resolve_scaffolding_plan(
            layer_type_name=layer_type,
            base_template_path=layer_type_path,
            plugins_path=plugins_path,
        )

        # Apply active extension templates (merge on top of base)
        for contribution in plan.extensions:
            if contribution.template_path and self._filesystem.exists(contribution.template_path):
                # Copy extension template, merging with existing files
                self._filesystem.copy_tree_with_replacements(
                    contribution.template_path,
                    target_path,
                    replacements,
                )
            # Handle explicit file mappings if any
            for source_file, dest_file in contribution.files:
                source_full = contribution.extension_path.parent / source_file
                if self._filesystem.exists(source_full):
                    content = self._filesystem.read_file(source_full)
                    # Apply replacements to content
                    for old, new in replacements:
                        content = content.replace(old, new)
                    dest_full = target_path / dest_file
                    self._filesystem.write_file(dest_full, content)

        # Update the taxonomy YAML
        self._update_target_yaml(config, source_doc, target_path)

        return CloneResult(
            status=CloneStatus.SUCCESS,
            cloned=ClonedNode(
                name=config.target_name,
                node_type=config.node_type,
                source_path=source_path,
                target_path=target_path,
            ),
        )

    def _build_replacements(
        self,
        config: CloneConfig,
        source_doc: TaxonomyDict,
    ) -> list[tuple[str, str]]:
        """Build text replacement pairs for the clone operation."""
        replacements: list[tuple[str, str]] = []

        # Basic name replacement
        replacements.append((config.source_name, config.target_name))

        # Add variations with different separators
        source_parts = config.source_name.replace("-", "_").replace(".", "_").split("_")
        target_parts = config.target_name.replace("-", "_").replace(".", "_").split("_")

        if len(source_parts) == len(target_parts):
            # Add kebab-case, snake_case variations
            source_kebab = "-".join(source_parts)
            target_kebab = "-".join(target_parts)
            if source_kebab != config.source_name:
                replacements.append((source_kebab, target_kebab))

            source_snake = "_".join(source_parts)
            target_snake = "_".join(target_parts)
            replacements.append((source_snake, target_snake))

        # Add uppercase variations
        replacements.append((config.source_name.upper(), config.target_name.upper()))

        # Sort by length (longest first) to avoid partial replacements
        replacements.sort(key=lambda x: len(x[0]), reverse=True)

        return replacements

    def _update_target_yaml(
        self,
        config: CloneConfig,
        source_doc: TaxonomyDict,
        target_path: Path,
    ) -> None:
        """Update the taxonomy YAML in the target directory."""
        # Determine yaml filename based on node type
        yaml_filename = {
            "layer": "layer.yaml",
            "stack": "stack.yaml",
        }.get(config.node_type, "layer.yaml")

        yaml_path = target_path / yaml_filename

        # Copy or override spec fields
        source_spec: TaxonomyDict = source_doc.get("spec", {}) or {}

        # Build spec dict
        spec: TaxonomyDict = {}

        # Description
        spec["description"] = config.description or source_spec.get("description", "")

        # Owners
        spec["owners"] = list(config.owners) if config.owners else source_spec.get("owners", [])

        # Environments
        spec["environments"] = (
            list(config.environments)
            if config.environments
            else source_spec.get("environments", [])
        )

        # Parents - update to target hierarchy
        parents: TaxonomyDict = source_spec.get("parents", {}) or {}
        if config.node_type == "layer":
            parent_node = config.target_stack or parents.get("node")
            if parent_node:
                spec["parents"] = {"node": parent_node}
        elif config.node_type == "stack":
            parent_node = config.target_system or parents.get("node")
            if parent_node:
                spec["parents"] = {"node": parent_node}
        elif config.node_type == "system":
            parent_node = config.target_system or parents.get("node")
            if parent_node:
                spec["parents"] = {"node": parent_node}

        # Layer type (for layers)
        if config.node_type == "layer":
            layer_type = config.layer_type or source_spec.get("layerType")
            if layer_type:
                spec["layerType"] = layer_type

        # Build new document
        new_doc: TaxonomyDict = {
            "apiVersion": source_doc.get("apiVersion", "katalyst.taxonomy/v1alpha"),
            "kind": source_doc.get("kind", "TaxonomyNode"),
            "metadata": {"name": config.target_name},
            "taxonomyNodeType": config.node_type,
            "spec": spec,
        }

        # Write the YAML
        yaml_content = yaml.dump(new_doc, default_flow_style=False, sort_keys=False)
        self._filesystem.write_file(yaml_path, yaml_content)
