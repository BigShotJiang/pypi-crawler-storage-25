"""Add service for installing new plugins and layer types.

This module contains domain models and service logic for the `kata tax add` command.
"""

# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Sequence

import yaml

from katalyst_taxonomy.adapters.filesystem.lock import (
    lock_from_mapping,
    lock_to_mapping,
)
from katalyst_taxonomy.domain.lock import (
    InstalledPlugin,
    KatalystLock,
)
from katalyst_taxonomy.ports.filesystem import FilesystemPort, RealFilesystem
from katalyst_taxonomy.ports.template_source import TemplateSourceProtocol
from katalyst_taxonomy.templates.sources.local import KNOWN_PLUGINS


class AddStatus(Enum):
    """Status of an add operation."""

    SUCCESS = "success"
    FAILED = "failed"
    NOT_INITIALIZED = "not_initialized"
    ALREADY_INSTALLED = "already_installed"
    CANCELLED = "cancelled"
    NOT_FOUND = "not_found"


# Known valid plugin names — derived from bundled manifest
VALID_PLUGINS = set(KNOWN_PLUGINS)


def discover_available_layer_types(fetch_result: object) -> set[str]:
    """Discover available layer type names from a fetched package.

    Checks the ``FetchResult.manifest.canonical_items`` first, then
    falls back to scanning subdirectories of the fetched package path.
    """
    # Try manifest canonical_items
    manifest = getattr(fetch_result, "manifest", None)
    if manifest is not None:
        canonical = getattr(manifest, "canonical_items", None)
        if canonical:
            return set(canonical)

    # Fallback: scan subdirectories of the package path
    path = getattr(fetch_result, "path", None)
    if path is not None and hasattr(path, "iterdir"):
        return {
            item.name for item in path.iterdir() if item.is_dir() and not item.name.startswith(".")
        }

    return set()


def _to_tuple(value: Sequence[str] | None) -> tuple[str, ...]:
    """Convert a sequence to a tuple, or return empty tuple if None."""
    from katalyst_taxonomy.services._util import to_tuple

    return to_tuple(value)


@dataclass(frozen=True)
class AddConfig:
    """Configuration for adding components to a taxonomy repository.

    Attributes:
        target_path: Root directory of the taxonomy repository.
        source: Template source URI (default: "bundled").
        plugins: Tuple of plugin names to add.
        layer_types: Tuple of layer type names to add.
        force: If True, overwrite existing components.
        interactive: If True, prompt for confirmation.
    """

    target_path: Path
    source: str = "bundled"
    plugins: tuple[str, ...] = ()
    layer_types: tuple[str, ...] = ()
    force: bool = False
    interactive: bool = False

    def __post_init__(self) -> None:
        """Convert sequences to tuples for immutability."""
        if type(self.plugins) is not tuple:
            object.__setattr__(self, "plugins", _to_tuple(self.plugins))  # type: ignore[arg-type]
        if type(self.layer_types) is not tuple:
            object.__setattr__(self, "layer_types", _to_tuple(self.layer_types))  # type: ignore[arg-type]

    @property
    def taxonomy_root(self) -> Path:
        """Get the path to the taxonomy root directory."""
        return self.target_path / ".global" / "taxonomy"

    @property
    def lock_file_path(self) -> Path:
        """Get the path to the lock file."""
        return self.taxonomy_root / "taxonomy.lock"


@dataclass(frozen=True)
class AddedComponent:
    """Represents a component that was added.

    Attributes:
        name: Component name (e.g., "layer_types", "app-docker").
        component_type: Type of component ("plugin" or "layer_type").
        version: Version that was installed.
    """

    name: str
    component_type: str
    version: str


@dataclass(frozen=True)
class AddResult:
    """Result of an add operation.

    Attributes:
        status: The status of the operation.
        added: Tuple of components that were added.
        skipped: Tuple of components that were skipped (already installed).
        error: Error message if the operation failed.
    """

    status: AddStatus
    added: tuple[AddedComponent, ...] = ()
    skipped: tuple[str, ...] = ()
    error: str | None = None

    @property
    def is_success(self) -> bool:
        """Check if the operation was successful."""
        return self.status == AddStatus.SUCCESS


# Use FilesystemPort from ports.filesystem for filesystem operations
# This alias is kept for backwards compatibility with existing code
AddFilesystem = FilesystemPort

# Use RealFilesystem from ports.filesystem
# This alias is kept for backwards compatibility with existing code
RealAddFilesystem = RealFilesystem


def _extract_lt_versions(
    yaml_content: str,
    layer_types: list[str],
    item_versions: dict[str, str],
    default_version: str,
) -> None:
    """Extract metadata.version from LayerType YAML documents.

    Pyright-safe helper that properly casts yaml.safe_load_all output.
    """
    from typing import Any, cast

    layer_type_set = set(layer_types)
    docs: Any = yaml.safe_load_all(yaml_content)
    for doc in docs:
        if not isinstance(doc, dict):
            continue
        doc_dict = cast(dict[str, Any], doc)
        if doc_dict.get("kind") != "LayerType":
            continue
        metadata_raw = doc_dict.get("metadata")
        if not isinstance(metadata_raw, dict):
            continue
        meta = cast(dict[str, Any], metadata_raw)
        name: Any = meta.get("name")
        version: Any = meta.get("version")
        if isinstance(name, str) and name in layer_type_set:
            item_versions[name] = str(version) if version else default_version


class AddService:
    """Service for adding plugins and layer types to an existing taxonomy.

    This service handles installing new components to a repository that
    has already been initialized with `kata tax init`.
    """

    def __init__(
        self,
        filesystem: AddFilesystem,
        template_source: TemplateSourceProtocol,
    ) -> None:
        """Initialize the service.

        Args:
            filesystem: Adapter for filesystem operations.
            template_source: Source for fetching templates.
        """
        self._filesystem = filesystem
        self._template_source = template_source

    def add(self, config: AddConfig) -> AddResult:
        """Add plugins and/or layer types to an existing taxonomy.

        Args:
            config: Configuration for the add operation.

        Returns:
            AddResult with added components.
        """
        # Check if initialized
        if not self._filesystem.exists(config.lock_file_path):
            return AddResult(
                status=AddStatus.NOT_INITIALIZED,
                error="Taxonomy not initialized. Run 'kata tax init' first.",
            )

        # Load current lock file
        try:
            lock = self._load_lock(config.lock_file_path)
        except Exception as e:
            return AddResult(
                status=AddStatus.FAILED,
                error=f"Failed to load lock file: {e}",
            )

        # Determine what to add
        added: list[AddedComponent] = []
        skipped: list[str] = []
        not_found: list[str] = []

        # Validate plugin names first
        for plugin in config.plugins:
            if plugin not in VALID_PLUGINS:
                not_found.append(plugin)

        if not_found:
            return AddResult(
                status=AddStatus.NOT_FOUND,
                error=f"Unknown plugin(s): {', '.join(not_found)}. "
                f"Valid plugins are: {', '.join(sorted(VALID_PLUGINS))}",
            )

        # Add plugins
        for plugin in config.plugins:
            result = self._add_plugin(config, lock, plugin)
            if result is None:
                if not config.force:
                    skipped.append(plugin)
                else:
                    # Force reinstall
                    result = self._install_plugin(config, plugin)
                    if result:
                        added.append(result)
                        lock = self._update_lock_with_plugin(lock, plugin, result.version)
            else:
                added.append(result)
                lock = self._update_lock_with_plugin(lock, plugin, result.version)

        # Add layer types (requires layer_types plugin)
        if config.layer_types:
            lt_result = self._add_layer_types(config, lock, config.layer_types)
            if lt_result.status in (AddStatus.NOT_FOUND, AddStatus.FAILED):
                return lt_result
            added.extend(lt_result.added)
            skipped.extend(lt_result.skipped)
            if lt_result.added:
                lock = self._update_lock_with_layer_types(lock, [c.name for c in lt_result.added])
                # If actions were installed alongside the layer types, record
                # a layer_actions plugin entry in the lock file.
                lock = self._update_lock_with_actions(lock, [c.name for c in lt_result.added])

        # Save updated lock file
        if added:
            try:
                self._save_lock(config.lock_file_path, lock)
            except Exception as e:
                return AddResult(
                    status=AddStatus.FAILED,
                    error=f"Failed to save lock file: {e}",
                )

        # Determine final status
        if not added and skipped:
            return AddResult(
                status=AddStatus.ALREADY_INSTALLED,
                skipped=tuple(skipped),
            )

        return AddResult(
            status=AddStatus.SUCCESS,
            added=tuple(added),
            skipped=tuple(skipped),
        )

    def _add_plugin(
        self,
        config: AddConfig,
        lock: KatalystLock,
        plugin: str,
    ) -> AddedComponent | None:
        """Add a single plugin.

        Args:
            config: Add configuration.
            lock: Current lock file.
            plugin: Plugin name to add.

        Returns:
            AddedComponent if added, None if already installed.
        """
        # Check if already installed
        if lock.has_plugin(plugin) and not config.force:
            return None

        return self._install_plugin(config, plugin)

    def _install_plugin(self, config: AddConfig, plugin: str) -> AddedComponent | None:
        """Install a plugin from the template source.

        Args:
            config: Add configuration.
            plugin: Plugin name to install.

        Returns:
            AddedComponent if successful, None otherwise.
        """
        try:
            fetch_result = self._template_source.fetch_package(plugin)
            package_path = getattr(fetch_result, "path", None)
            package_info = getattr(fetch_result, "package", None)

            if package_path is None:
                return None

            version = getattr(package_info, "version", "1.0.0") if package_info else "1.0.0"

            # Copy plugin to taxonomy
            if plugin == "layer_types":
                # layer_types goes to layer_types/
                dest = config.taxonomy_root / "layer_types"
                self._filesystem.create_directory(dest.parent)
                self._filesystem.copy_tree(package_path, dest)
            elif plugin == "cicd":
                # cicd goes to cicd/
                dest = config.taxonomy_root / "cicd"
                self._filesystem.create_directory(dest.parent)
                self._filesystem.copy_tree(package_path, dest)
            elif plugin == "layer_actions":
                # Merge action YAMLs into actions/ (preserves existing just/ subdir)
                dest = config.taxonomy_root / "actions"
                self._filesystem.create_directory(dest)
                for item in package_path.iterdir():
                    if item.name == "manifest.json":
                        continue
                    target = dest / item.name
                    if item.is_file():
                        self._filesystem.write_file(target, item.read_text(encoding="utf-8"))
                    elif item.is_dir():
                        self._filesystem.copy_tree(item, target)
            elif plugin == "just":
                # just recipes go to actions/just/
                dest = config.taxonomy_root / "actions" / "just"
                self._filesystem.create_directory(dest.parent)
                self._filesystem.copy_tree(package_path, dest)
            elif plugin == "extensions":
                # extensions go to extensions/
                dest = config.taxonomy_root / "extensions"
                self._filesystem.create_directory(dest.parent)
                self._filesystem.copy_tree(package_path, dest)
            elif plugin == "capabilities":
                # capabilities go to capabilities/
                dest = config.taxonomy_root / "capabilities"
                self._filesystem.create_directory(dest.parent)
                self._filesystem.copy_tree(package_path, dest)
            else:
                dest = config.taxonomy_root / "plugins" / plugin
                self._filesystem.create_directory(dest.parent)
                self._filesystem.copy_tree(package_path, dest)

            return AddedComponent(
                name=plugin,
                component_type="plugin",
                version=version,
            )
        except (KeyError, ValueError, OSError):
            return None

    def _add_layer_types(
        self,
        config: AddConfig,
        lock: KatalystLock,
        layer_types: tuple[str, ...],
    ) -> AddResult:
        """Add layer types to the taxonomy.

        Args:
            config: Add configuration.
            lock: Current lock file.
            layer_types: Layer type names to add.

        Returns:
            AddResult with added layer types.
        """
        added: list[AddedComponent] = []
        skipped: list[str] = []

        # Get existing layer types from lock
        existing_layer_types: set[str] = set()
        layer_types_plugin = lock.get_plugin("layer_types")
        if layer_types_plugin:
            existing_layer_types = set(layer_types_plugin.canonical)

        # Fetch the layer_types package
        try:
            fetch_result = self._template_source.fetch_package("layer_types")
            package_path = getattr(fetch_result, "path", None)
            package_info = getattr(fetch_result, "package", None)

            if package_path is None:
                return AddResult(
                    status=AddStatus.FAILED,
                    error="Could not fetch layer_types package",
                )

            version = getattr(package_info, "version", "1.0.0") if package_info else "1.0.0"

            # Discover available layer types from the source
            available = discover_available_layer_types(fetch_result)

            # Validate requested layer types against what the source provides
            invalid = [lt for lt in layer_types if lt not in available]
            if invalid:
                return AddResult(
                    status=AddStatus.NOT_FOUND,
                    error=f"Unknown layer type(s): {', '.join(invalid)}. "
                    f"Available from source: {', '.join(sorted(available))}",
                )

            # Install each layer type
            for layer_type in layer_types:
                if layer_type in existing_layer_types and not config.force:
                    skipped.append(layer_type)
                    continue

                src = package_path / layer_type
                if not src.exists() or not src.is_dir():
                    skipped.append(layer_type)
                    continue

                dest = config.taxonomy_root / "layer_types" / layer_type
                self._filesystem.create_directory(dest.parent)
                self._filesystem.copy_tree(src, dest)

                # Install global template files if the layer type ships them
                global_src = src / "global"
                if global_src.exists() and global_src.is_dir():
                    global_dest = config.target_path / ".global"
                    self._filesystem.copy_tree_no_overwrite(global_src, global_dest)

                added.append(
                    AddedComponent(
                        name=layer_type,
                        component_type="layer_type",
                        version=version,
                    ),
                )

            # After installing layer type templates, also install matching actions,
            # companion Just recipes, and CI/CD templates.
            if added:
                added_names = [c.name for c in added]
                self._install_actions_for_layer_types(config, added_names)
                self._install_just_for_layer_types(config, added_names)
                self._install_cicd_for_layer_types(config, added_names)

        except (KeyError, ValueError, OSError) as e:
            return AddResult(
                status=AddStatus.FAILED,
                error=f"Failed to add layer types: {e}",
            )

        return AddResult(
            status=AddStatus.SUCCESS,
            added=tuple(added),
            skipped=tuple(skipped),
        )

    def _install_actions_for_layer_types(
        self,
        config: AddConfig,
        layer_types: list[str],
    ) -> None:
        """Install action definitions that match the newly added layer types.

        Fetches the ``layer_actions`` package from the template source and
        copies YAML files whose stem matches one of the given *layer_types*
        into ``.global/taxonomy/actions/``.  Subdirectories such as ``tools/``
        are also copied (they contain unscoped actions shared across types).

        If the source does not provide a ``layer_actions`` package the method
        returns silently — action installation is best-effort.
        """
        try:
            actions_result = self._template_source.fetch_package("layer_actions")
            actions_path = getattr(actions_result, "path", None)
            if actions_path is None:
                return
        except (KeyError, ValueError, OSError):
            # Source doesn't provide actions — that's fine
            return

        dest = config.taxonomy_root / "actions"
        self._filesystem.create_directory(dest)

        layer_type_set = set(layer_types)

        for item in actions_path.iterdir():
            if item.name == "manifest.json":
                continue

            if item.is_file():
                # Only install action files matching the added layer types
                stem = item.stem  # e.g. "app-bun" from "app-bun.yaml"
                if stem in layer_type_set:
                    self._filesystem.write_file(dest / item.name, item.read_text(encoding="utf-8"))
            elif item.is_dir():
                # Copy tool directories (e.g. tools/) — these contain shared actions
                self._filesystem.copy_tree(item, dest / item.name)

    def _install_just_for_layer_types(
        self,
        config: AddConfig,
        layer_types: list[str],
    ) -> None:
        """Install companion Just recipes from the template source.

        Fetches the ``just`` package and installs:
        - ``common.just`` — shared helpers (always installed)
        - ``tools/*.just`` — tool-level recipes (always installed)
        - ``layerTypes/<layer-type>.just`` — only for matching *layer_types*

        Files are installed into ``.global/taxonomy/actions/just/``.
        If the source does not provide a ``just`` package the method
        returns silently — Just recipe installation is best-effort.
        """
        try:
            just_result = self._template_source.fetch_package("just")
            just_path = getattr(just_result, "path", None)
            if just_path is None:
                return
        except (KeyError, ValueError, OSError):
            return

        dest = config.taxonomy_root / "actions" / "just"
        self._filesystem.create_directory(dest)

        layer_type_set = set(layer_types)

        for item in just_path.iterdir():
            if item.name in ("manifest.json", "manifest.yaml"):
                continue

            if item.is_file() and item.suffix == ".just":
                # Top-level .just files like common.just
                self._filesystem.write_file(
                    dest / item.name,
                    item.read_text(encoding="utf-8"),
                )
            elif item.is_dir() and item.name in ("layerTypes", "layer_types"):
                # Layer-type specific recipes — only install matching ones
                lt_dest = dest / "layer_types"
                self._filesystem.create_directory(lt_dest)
                for recipe in item.iterdir():
                    if recipe.is_file() and recipe.suffix == ".just":
                        stem = recipe.stem  # e.g. "app-bun" from "app-bun.just"
                        if stem in layer_type_set:
                            self._filesystem.write_file(
                                lt_dest / recipe.name,
                                recipe.read_text(encoding="utf-8"),
                            )
            elif item.is_dir():
                # Other directories like tools/ — merge without overwriting existing files
                self._filesystem.copy_tree_no_overwrite(item, dest / item.name)

    def _install_cicd_for_layer_types(
        self,
        config: AddConfig,
        layer_types: list[str],
    ) -> None:
        """Install companion CI/CD templates from the template source.

        Fetches the ``cicd`` package and installs:
        - ``jobs.yaml`` — appended to existing CI/CD jobs
        - ``workflows.yaml`` — appended to existing CI/CD workflows
        - ``templates/`` — Jinja2 template directory (merged)

        Skips ``manifest.json`` and ``stages.yaml`` (already installed by
        ``kata tax init``).

        If the source does not provide a ``cicd`` package the method returns
        silently — CI/CD installation is best-effort.
        """
        try:
            cicd_result = self._template_source.fetch_package("cicd")
            cicd_path = getattr(cicd_result, "path", None)
            if cicd_path is None:
                return
        except (KeyError, ValueError, OSError):
            return

        dest = config.taxonomy_root / "cicd"
        self._filesystem.create_directory(dest)

        skip_files = {"manifest.json", "manifest.yaml", "stages.yaml"}

        for item in cicd_path.iterdir():
            if item.name in skip_files:
                continue

            if item.is_file():
                # Append YAML documents (jobs.yaml, workflows.yaml) to existing files
                existing_content = ""
                target = dest / item.name
                try:
                    existing_content = self._filesystem.read_file(target)
                except (FileNotFoundError, OSError):
                    pass

                new_content = item.read_text(encoding="utf-8")
                if existing_content and not existing_content.endswith("\n"):
                    existing_content += "\n"
                if existing_content:
                    merged = existing_content + "---\n" + new_content
                else:
                    merged = new_content

                self._filesystem.write_file(target, merged)
            elif item.is_dir():
                # Copy template directories (e.g. templates/) — merge without overwriting
                self._filesystem.copy_tree_no_overwrite(item, dest / item.name)

    def _load_lock(self, path: Path) -> KatalystLock:
        """Load and parse the lock file.

        Args:
            path: Path to lock file.

        Returns:
            Parsed KatalystLock.
        """
        content = self._filesystem.read_file(path)
        data = yaml.safe_load(content) or {}
        return lock_from_mapping(data, source_path=path)

    def _save_lock(self, path: Path, lock: KatalystLock) -> None:
        """Save the lock file.

        Args:
            path: Path to lock file.
            lock: Lock to save.
        """
        data = lock_to_mapping(lock)
        header = "# Auto-generated by Katalyst - do not edit manually\n"
        content = header + yaml.safe_dump(data, sort_keys=False, default_flow_style=False)
        self._filesystem.write_file(path, content)

    def _update_lock_with_plugin(
        self,
        lock: KatalystLock,
        plugin: str,
        version: str,
    ) -> KatalystLock:
        """Update lock with a newly installed plugin.

        Args:
            lock: Current lock.
            plugin: Plugin name.
            version: Plugin version.

        Returns:
            Updated lock.
        """
        new_plugin = InstalledPlugin(
            version=version,
            installed_at=datetime.now(timezone.utc),
            source="bundled",
            canonical=(),
            custom=(),
        )
        return lock.with_plugin(plugin, new_plugin)

    def _update_lock_with_layer_types(
        self,
        lock: KatalystLock,
        layer_types: list[str],
    ) -> KatalystLock:
        """Update lock with newly installed layer types.

        Args:
            lock: Current lock.
            layer_types: Layer type names that were added.

        Returns:
            Updated lock.
        """
        # Get existing layer_types plugin or create new one
        existing = lock.get_plugin("layer_types")

        # Resolve per-item versions from the template source
        new_item_versions = self._resolve_item_versions(layer_types)

        if existing:
            # Merge with existing canonical list
            existing_canonical = set(existing.canonical)
            existing_canonical.update(layer_types)
            # Merge item versions: keep existing, add new
            merged_iv = dict(existing.item_versions)
            merged_iv.update(new_item_versions)
            new_plugin = InstalledPlugin(
                version=existing.version,
                installed_at=datetime.now(timezone.utc),
                source=existing.source,
                canonical=tuple(sorted(existing_canonical)),
                custom=existing.custom,
                item_versions=tuple(sorted(merged_iv.items())),
            )
        else:
            # Create new plugin entry
            new_plugin = InstalledPlugin(
                version="1.0.0",
                installed_at=datetime.now(timezone.utc),
                source="bundled",
                canonical=tuple(sorted(layer_types)),
                custom=(),
                item_versions=tuple(sorted(new_item_versions.items())),
            )

        return lock.with_plugin("layer_types", new_plugin)

    def _update_lock_with_actions(
        self,
        lock: KatalystLock,
        layer_types: list[str],
    ) -> KatalystLock:
        """Update lock with layer_actions plugin entry for newly added actions.

        Merges the given *layer_types* into the ``canonical`` list of the
        existing ``layer_actions`` plugin or creates a new entry.

        Args:
            lock: Current lock.
            layer_types: Layer type names whose actions were installed.

        Returns:
            Updated lock.
        """
        existing = lock.get_plugin("layer_actions")

        if existing:
            existing_canonical = set(existing.canonical)
            existing_canonical.update(layer_types)
            new_plugin = InstalledPlugin(
                version=existing.version,
                installed_at=datetime.now(timezone.utc),
                source=existing.source,
                canonical=tuple(sorted(existing_canonical)),
                custom=existing.custom,
            )
        else:
            new_plugin = InstalledPlugin(
                version="1.0.0",
                installed_at=datetime.now(timezone.utc),
                source="bundled",
                canonical=tuple(sorted(layer_types)),
                custom=(),
            )

        return lock.with_plugin("layer_actions", new_plugin)

    def _resolve_item_versions(self, layer_types: list[str]) -> dict[str, str]:
        """Resolve per-item versions for layer types from the template source.

        Reads ``metadata.version`` from LayerType YAML definitions in the
        bundled templates.  Falls back to ``"0.1.0"`` for items without a
        ``metadata.version``.

        Args:
            layer_types: Names of the layer types to resolve versions for.

        Returns:
            Dict mapping layer type name to its version string.
        """
        item_versions: dict[str, str] = {}
        default_version = "0.1.0"

        try:
            fetch_result = self._template_source.fetch_package("layer_types")
            package_path = getattr(fetch_result, "path", None)
            if package_path is not None:
                lt_yaml = package_path / "layer-types.yaml"
                if lt_yaml.exists():
                    content = lt_yaml.read_text(encoding="utf-8")
                    _extract_lt_versions(content, layer_types, item_versions, default_version)
        except (KeyError, ValueError, OSError):
            pass

        # Fill in missing layer types with default version
        for lt in layer_types:
            if lt not in item_versions:
                item_versions[lt] = default_version

        return item_versions
