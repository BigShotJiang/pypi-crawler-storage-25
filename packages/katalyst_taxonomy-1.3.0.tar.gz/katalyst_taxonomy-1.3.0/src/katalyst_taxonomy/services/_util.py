"""Shared utility functions for Katalyst service modules."""

from __future__ import annotations

from typing import Sequence


def to_tuple(value: Sequence[str] | None) -> tuple[str, ...]:
    """Convert a sequence to a tuple, or return empty tuple if None.

    This utility is used across multiple service modules (init, add,
    remove, upgrade) to normalize sequence arguments into tuples for
    immutable dataclass fields.
    """
    if value is None:
        return ()
    return tuple(value)
