"""Export service — orchestrates taxonomy export to external systems."""

from __future__ import annotations

from pathlib import Path

from loguru import logger

from katalyst_taxonomy.engine.bridge import get_default_registry
from katalyst_taxonomy.engine.resolver import build_qualified_names
from katalyst_taxonomy.ports.backend import TaxonomyBackend
from katalyst_taxonomy.ports.export import ExportData, ExportPort, ExportResult


class ExportService:
    """Orchestrates taxonomy export to external systems.

    Loads taxonomy data from the backend, resolves FQTNs, and delegates
    the actual export to an ``ExportPort`` implementation.
    """

    def __init__(
        self,
        repository: TaxonomyBackend,
        export_port: ExportPort,
    ) -> None:
        self._repository = repository
        self._export_port = export_port

    def _load_export_data(self) -> ExportData:
        """Load taxonomy data and build the ExportData bundle."""
        documents = self._repository.load_documents()
        environments = self._repository.load_environments()

        registry = get_default_registry()
        qualified_names = build_qualified_names(documents, registry)

        return ExportData(
            documents=documents,
            environments=environments,
            qualified_names=qualified_names,
        )

    async def full_export(self, base_path: Path | None = None) -> ExportResult:
        """Load taxonomy and perform full export.

        Args:
            base_path: Deprecated — ignored. Config is on the backend.
        """
        logger.info("Starting full export")
        data = self._load_export_data()
        logger.info(
            "Loaded {} documents, {} environments",
            len(data.documents),
            len(data.environments),
        )
        return await self._export_port.full_export(data)

    async def incremental_sync(self, base_path: Path | None = None) -> ExportResult:
        """Load taxonomy and perform incremental sync.

        Args:
            base_path: Deprecated — ignored. Config is on the backend.
        """
        logger.info("Starting incremental sync")
        data = self._load_export_data()
        logger.info(
            "Loaded {} documents, {} environments",
            len(data.documents),
            len(data.environments),
        )
        return await self._export_port.incremental_sync(data)

    async def health_check(self) -> bool:
        """Check export target health."""
        return await self._export_port.health_check()

    async def close(self) -> None:
        """Close export port resources."""
        await self._export_port.close()
