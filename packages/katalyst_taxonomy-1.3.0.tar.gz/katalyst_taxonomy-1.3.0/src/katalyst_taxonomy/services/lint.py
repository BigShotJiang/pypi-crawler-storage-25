"""Lint service — unified taxonomy validation.

Orchestrates all linting passes (document errors, environment contracts,
plugin schemas, version constraints) and returns a structured result.
No I/O — callers are responsible for formatting the output.
"""

# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from katalyst_taxonomy.cli.loaders import load_from_filesystem
from katalyst_taxonomy.domain.errors import DocumentError


@dataclass(frozen=True, slots=True)
class VersionConstraintError:
    """A version constraint that is not satisfied."""

    plugin_name: str
    dep_kind: str
    dep_name: str
    constraint: str
    found_version: str | None
    message: str


@dataclass(frozen=True, slots=True)
class VersionConstraintWarning:
    """A version constraint that cannot be verified."""

    plugin_name: str
    dep_kind: str
    dep_name: str
    constraint: str
    message: str


@dataclass(frozen=True, slots=True)
class LintResult:
    """Unified result from all linting passes."""

    # Document-level errors from the taxonomy loader
    document_errors: tuple[DocumentError, ...]

    # Environment contract warnings
    contract_warnings: tuple[Any, ...] = ()
    contract_checked_layers: int = 0
    contract_checked_environments: int = 0

    # Plugin schema errors (from v2 linter)
    plugin_schema_errors: tuple[Any, ...] = ()
    plugin_document_count: int = 0

    # Version constraint results
    version_constraint_errors: tuple[VersionConstraintError, ...] = ()
    version_constraint_warnings: tuple[VersionConstraintWarning, ...] = ()

    # Document counts
    document_count: int = 0
    environment_count: int = 0

    @property
    def is_valid(self) -> bool:
        """True if no errors were found (warnings are OK)."""
        return (
            len(self.document_errors) == 0
            and len(self.plugin_schema_errors) == 0
            and len(self.version_constraint_errors) == 0
        )

    @property
    def total_errors(self) -> int:
        return (
            len(self.document_errors)
            + len(self.plugin_schema_errors)
            + len(self.version_constraint_errors)
        )


def lint_taxonomy(path: Path) -> LintResult:
    """Run all linting passes and return a unified result.

    This loads the taxonomy from the filesystem directly (no HTTP server),
    then runs document validation, environment contracts, plugin schemas,
    and version constraint checks.

    Args:
        path: Path to the repository root.

    Returns:
        A LintResult with all validation findings.
    """
    # Load taxonomy
    service = load_from_filesystem(path)

    # Run environment contract linting
    contract_warnings: tuple[Any, ...] = ()
    contract_checked_layers = 0
    contract_checked_environments = 0
    try:
        from katalyst_taxonomy.linting.environment_contract_linter import (
            lint_environment_contracts,
        )

        contract_result = lint_environment_contracts(path)
        contract_warnings = tuple(contract_result.warnings)
        contract_checked_layers = contract_result.checked_layers
        contract_checked_environments = contract_result.checked_environments
    except Exception:
        pass

    # Run plugin schema validation
    plugin_schema_errors: tuple[Any, ...] = ()
    plugin_document_count = 0
    try:
        from katalyst_taxonomy.linting.v2_linter import lint_v2_documents

        plugin_result = lint_v2_documents(
            path,
            directories=(
                ".global/taxonomy/design",
                ".global/taxonomy/practices",
                ".global/taxonomy/capabilities",
                ".global/taxonomy/actions",
                ".global/taxonomy/layer_actions",
                ".global/taxonomy/extensions",
                ".global/taxonomy/cicd",
                ".global/taxonomy/layer_types",
                ".global/taxonomy/tools",
            ),
        )
        plugin_schema_errors = tuple(plugin_result.errors)
        plugin_document_count = sum(plugin_result.counts.values())
    except Exception:
        pass

    # Run version constraint checks
    vc_errors, vc_warnings = _check_version_constraints(path)

    return LintResult(
        document_errors=service.errors,
        contract_warnings=contract_warnings,
        contract_checked_layers=contract_checked_layers,
        contract_checked_environments=contract_checked_environments,
        plugin_schema_errors=plugin_schema_errors,
        plugin_document_count=plugin_document_count,
        version_constraint_errors=tuple(vc_errors),
        version_constraint_warnings=tuple(vc_warnings),
        document_count=len(service.documents),
        environment_count=len(service.environments),
    )


def _check_version_constraints(
    path: Path,
) -> tuple[list[VersionConstraintError], list[VersionConstraintWarning]]:
    """Check version constraints on plugin requirements.

    Returns (errors, warnings) tuples.

    Note: pyright suppressions are at the file level because yaml.safe_load_all
    returns Iterator[Any] and the dicts accessed from parsed YAML are all untyped.
    """
    errors: list[VersionConstraintError] = []
    warnings: list[VersionConstraintWarning] = []

    try:
        import yaml as _yaml

        V2_API_VERSION = "katalyst.taxonomy/v2alpha"

        taxonomy_root = path / ".global" / "taxonomy"
        if not taxonomy_root.exists():
            return errors, warnings

        yaml_files: list[Path] = []
        for ext in (".yaml", ".yml"):
            yaml_files.extend(taxonomy_root.rglob(f"*{ext}"))

        if not yaml_files:
            return errors, warnings

        # Build index
        from typing import cast

        _index: dict[tuple[str, str, str], str | None] = {}
        for yf in yaml_files:
            try:
                raw_all: Any = _yaml.safe_load_all(yf.read_text(encoding="utf-8"))
                for raw_doc in raw_all:
                    if not isinstance(raw_doc, dict):
                        continue
                    doc = cast(dict[str, Any], raw_doc)
                    av = str(doc.get("apiVersion", ""))
                    if av != V2_API_VERSION:
                        continue
                    kind_val = doc.get("kind")
                    meta = doc.get("metadata")
                    if not isinstance(meta, dict) or not isinstance(kind_val, str):
                        continue
                    name_val = meta.get("name")
                    if not isinstance(name_val, str):
                        continue
                    ver = meta.get("version")
                    _index[(av, kind_val, name_val)] = str(ver) if ver else None
            except (_yaml.YAMLError, OSError):
                continue

        # Check constraints
        for yaml_file in yaml_files:
            try:
                content = yaml_file.read_text(encoding="utf-8")
                raw_docs: Any = _yaml.safe_load_all(content)
                for raw_doc in raw_docs:
                    if not isinstance(raw_doc, dict):
                        continue
                    doc = cast(dict[str, Any], raw_doc)
                    api_version: str = str(doc.get("apiVersion", ""))
                    if api_version != V2_API_VERSION:
                        continue

                    metadata_raw = doc.get("metadata")
                    if not isinstance(metadata_raw, dict):
                        continue
                    metadata = cast(dict[str, Any], metadata_raw)

                    requires_raw: Any = metadata.get("requires")
                    if not requires_raw or not isinstance(requires_raw, list):
                        continue

                    plugin_name: str = str(metadata.get("name", "<unknown>"))

                    for req_raw in requires_raw:
                        if not isinstance(req_raw, dict):
                            continue
                        req_api = str(req_raw.get("apiVersion", ""))
                        req_kind = str(req_raw.get("kind", ""))
                        req_name = str(req_raw.get("name", ""))
                        version_str = req_raw.get("version")
                        if not version_str or not isinstance(version_str, str):
                            continue
                        version_str = version_str.strip()
                        if not version_str:
                            continue

                        try:
                            from katalyst_taxonomy.domain.version import parse_constraint

                            constraint = parse_constraint(version_str)
                        except ValueError:
                            errors.append(
                                VersionConstraintError(
                                    plugin_name=plugin_name,
                                    dep_kind=req_kind,
                                    dep_name=req_name,
                                    constraint=version_str,
                                    found_version=None,
                                    message=f"Invalid version constraint '{version_str}'",
                                )
                            )
                            continue

                        dep_key = (req_api, req_kind, req_name)
                        dep_version_str = _index.get(dep_key)
                        if dep_key not in _index:
                            continue

                        if dep_version_str is None:
                            warnings.append(
                                VersionConstraintWarning(
                                    plugin_name=plugin_name,
                                    dep_kind=req_kind,
                                    dep_name=req_name,
                                    constraint=version_str,
                                    message=f"Cannot verify: dependency '{req_name}' has no version",
                                )
                            )
                            continue

                        from katalyst_taxonomy.domain.version import parse_version

                        try:
                            dep_version = parse_version(dep_version_str)
                        except ValueError:
                            warnings.append(
                                VersionConstraintWarning(
                                    plugin_name=plugin_name,
                                    dep_kind=req_kind,
                                    dep_name=req_name,
                                    constraint=version_str,
                                    message=f"Dependency '{req_name}' has invalid version '{dep_version_str}'",
                                )
                            )
                            continue

                        if not constraint.matches(dep_version):
                            errors.append(
                                VersionConstraintError(
                                    plugin_name=plugin_name,
                                    dep_kind=req_kind,
                                    dep_name=req_name,
                                    constraint=version_str,
                                    found_version=dep_version_str,
                                    message=(
                                        f"Plugin '{plugin_name}' requires {req_kind} '{req_name}' "
                                        f"version '{version_str}', but found '{dep_version_str}'"
                                    ),
                                )
                            )

            except (_yaml.YAMLError, OSError):
                continue

    except Exception:
        pass

    return errors, warnings
