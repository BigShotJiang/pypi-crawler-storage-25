"""Dependency graph service — build and query dependency graphs.

Relocated from cli/commands/deps/graph.py to the service layer so that
both CLI and MCP adapters can access it without adapter-to-adapter coupling.
"""

from __future__ import annotations

from katalyst_taxonomy.domain.deps import DependencyGraph, DependencyNode
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.services.taxonomy import TaxonomyService

__all__ = [
    "DependencyGraph",
    "DependencyNode",
    "build_dependency_graph",
    "detect_cycles",
    "resolve_dependency",
]


def build_dependency_graph(service: TaxonomyService) -> DependencyGraph:
    """Build a dependency graph from the taxonomy service.

    Args:
        service: The taxonomy service with loaded documents.

    Returns:
        A DependencyGraph containing nodes, cycles, and unresolved dependencies.
    """
    graph = DependencyGraph()

    # Build lookup maps
    fqtn_to_doc: dict[str, Document] = {}
    name_to_fqtns: dict[str, list[str]] = {}

    for doc in service.documents:
        fqtn = service.get_qualified_name(doc)
        fqtn_to_doc[fqtn] = doc
        name_to_fqtns.setdefault(doc.metadata.name, []).append(fqtn)

        graph.nodes[fqtn] = DependencyNode(
            fqtn=fqtn,
            name=doc.metadata.name,
            node_type=doc.taxonomy_node_type,
        )

    for doc in service.documents:
        fqtn = service.get_qualified_name(doc)
        if not doc.depends_on_nodes:
            continue

        for dep_ref in doc.depends_on_nodes:
            resolved_fqtn = resolve_dependency(dep_ref, fqtn, fqtn_to_doc, name_to_fqtns)

            if resolved_fqtn:
                graph.nodes[fqtn].dependencies.append(resolved_fqtn)
                graph.nodes[resolved_fqtn].dependents.append(fqtn)
            else:
                graph.unresolved.setdefault(fqtn, []).append(dep_ref)

    graph.cycles = detect_cycles(graph)
    return graph


def resolve_dependency(
    dep_ref: str,
    source_fqtn: str,
    fqtn_to_doc: dict[str, Document],
    name_to_fqtns: dict[str, list[str]],
) -> str | None:
    """Resolve a dependency reference to an FQTN."""
    if dep_ref in fqtn_to_doc:
        return dep_ref

    candidates = name_to_fqtns.get(dep_ref, [])

    if not candidates:
        return None

    if len(candidates) == 1:
        return candidates[0]

    source_system = source_fqtn.split(".")[0] if "." in source_fqtn else source_fqtn
    same_system = [c for c in candidates if c.startswith(f"{source_system}.")]

    if len(same_system) == 1:
        return same_system[0]

    source_parts = source_fqtn.split(".")
    best_match: str | None = None
    best_overlap = -1

    for candidate in candidates:
        cand_parts = candidate.split(".")
        overlap = sum(1 for a, b in zip(source_parts, cand_parts, strict=False) if a == b)
        if overlap > best_overlap:
            best_overlap = overlap
            best_match = candidate

    return best_match


def detect_cycles(graph: DependencyGraph) -> list[list[str]]:
    """Detect cycles in the dependency graph using DFS."""
    cycles: list[list[str]] = []
    visited: set[str] = set()
    rec_stack: set[str] = set()
    path: list[str] = []

    def dfs(node: str) -> None:
        visited.add(node)
        rec_stack.add(node)
        path.append(node)

        for dep in graph.nodes.get(
            node,
            DependencyNode(fqtn="", name="", node_type=""),
        ).dependencies:
            if dep not in visited:
                dfs(dep)
            elif dep in rec_stack:
                cycle_start = path.index(dep)
                cycle = path[cycle_start:] + [dep]
                min_idx = cycle.index(min(cycle[:-1]))
                normalized = cycle[min_idx:-1] + cycle[:min_idx] + [cycle[min_idx]]
                if normalized not in cycles:
                    cycles.append(normalized)

        path.pop()
        rec_stack.remove(node)

    for node in graph.nodes:
        if node not in visited:
            dfs(node)

    return cycles
