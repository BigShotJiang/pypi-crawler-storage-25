"""Ports (interfaces) for exporting taxonomy data to external systems."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


@dataclass(frozen=True, slots=True)
class ExportData:
    """Complete taxonomy data prepared for export."""

    documents: tuple[Document, ...]
    environments: tuple[EnvironmentDocument, ...]
    qualified_names: dict[str, str]  # lookup_key -> FQTN


@dataclass(frozen=True, slots=True)
class ExportResult:
    """Result of an export operation."""

    success: bool
    nodes_created: int = 0
    nodes_updated: int = 0
    nodes_deleted: int = 0
    relationships_created: int = 0
    relationships_deleted: int = 0
    errors: tuple[str, ...] = field(default_factory=tuple)


class ExportPort(Protocol):
    """Port for exporting taxonomy data to external systems."""

    async def full_export(self, data: ExportData) -> ExportResult:
        """Full export: clear existing data and recreate from scratch."""
        ...

    async def incremental_sync(self, data: ExportData) -> ExportResult:
        """Incremental sync: upsert nodes/relationships, prune stale entries."""
        ...

    async def health_check(self) -> bool:
        """Check if the export target is reachable and ready."""
        ...

    async def close(self) -> None:
        """Clean up resources (close connections, etc.)."""
        ...
