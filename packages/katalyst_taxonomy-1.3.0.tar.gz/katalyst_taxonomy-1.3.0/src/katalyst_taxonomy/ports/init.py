"""Ports (interfaces) for init operations.

This module defines the protocols (ports) that the init service depends on,
following the hexagonal architecture pattern. Adapters implement these protocols.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol, runtime_checkable


@dataclass(frozen=True)
class PluginChoice:
    """Represents a plugin option for selection.

    Attributes:
        name: Plugin identifier (e.g., "layer_types", "cicd").
        description: Human-readable description of the plugin.
        selected: Whether this plugin is selected for installation.
    """

    name: str
    description: str
    selected: bool = False


@dataclass(frozen=True)
class LayerTypeChoice:
    """Represents a layer type option for selection.

    Attributes:
        name: Layer type identifier (e.g., "app-docker", "iac-terragrunt").
        description: Human-readable description of the layer type.
        plugin: Name of the plugin this layer type belongs to.
        selected: Whether this layer type is selected for installation.
    """

    name: str
    description: str
    plugin: str
    selected: bool = False


@dataclass(frozen=True)
class EnvironmentChoice:
    """Represents an environment option for selection.

    Attributes:
        name: Environment identifier (e.g., "dev", "staging", "prod").
        description: Human-readable description of the environment.
        selected: Whether this environment is selected for creation.
    """

    name: str
    description: str
    selected: bool = True  # Environments are selected by default


@dataclass(frozen=True)
class EnvironmentValuePrompt:
    """A single environment value to collect from the user.

    Attributes:
        key: The configuration key (e.g., "namespace", "remote_state_bucket").
        layer_type: Layer type this key belongs to, or empty string for shared
            templateReplacements keys.
        environment: Environment this value applies to (e.g., "dev").
        description: Human-readable hint for the user.
        default: Smart default value (may be empty).
    """

    key: str
    layer_type: str
    environment: str
    description: str = ""
    default: str = ""


@dataclass(frozen=True)
class CollectedEnvironmentValues:
    """Collected values for one environment.

    Attributes:
        environment: Environment name (e.g., "dev").
        template_replacements: Shared templateReplacements key-value pairs.
        layer_templates: Per-layer-type key-value pairs, keyed by layer type name.
    """

    environment: str
    template_replacements: dict[str, str] = field(
        default_factory=lambda: dict[str, str](),
    )
    layer_templates: dict[str, dict[str, str]] = field(
        default_factory=lambda: dict[str, dict[str, str]](),
    )


@runtime_checkable
class InitPrompt(Protocol):
    """Port for user interaction during initialization.

    This protocol abstracts user prompts, allowing different implementations:
    - InteractivePromptAdapter: Uses rich/questionary for terminal prompts
    - NonInteractivePromptAdapter: Uses defaults without prompting
    - TestPromptAdapter: Returns predefined values for testing
    """

    def confirm(self, message: str, default: bool = True) -> bool:
        """Ask user for yes/no confirmation.

        Args:
            message: The confirmation message to display.
            default: Default value if user just presses enter.

        Returns:
            True if confirmed, False otherwise.
        """
        ...

    def select_plugins(self, choices: list[PluginChoice]) -> list[PluginChoice]:
        """Prompt user to select plugins to install.

        Args:
            choices: Available plugin choices with defaults.

        Returns:
            List of choices with updated selection status.
        """
        ...

    def select_layer_types(self, choices: list[LayerTypeChoice]) -> list[LayerTypeChoice]:
        """Prompt user to select layer types to install.

        Args:
            choices: Available layer type choices with defaults.

        Returns:
            List of choices with updated selection status.
        """
        ...

    def select_environments(self, choices: list[EnvironmentChoice]) -> list[EnvironmentChoice]:
        """Prompt user to select environments to create.

        Args:
            choices: Available environment choices with defaults.

        Returns:
            List of choices with updated selection status.
        """
        ...

    def collect_environment_values(
        self,
        prompts: list[EnvironmentValuePrompt],
        environments: list[str],
        layer_types: list[str],
    ) -> list[CollectedEnvironmentValues]:
        """Prompt user for environment-specific values required by layer types.

        After the user selects environments and layer types, each layer type
        declares an environment contract specifying keys it needs.  This method
        collects those values — one set per environment — so they can be written
        to ``environments.yaml``.

        Args:
            prompts: Flat list of value prompts (key + layer_type + environment +
                default) to present.
            environments: Ordered list of selected environment names.
            layer_types: Ordered list of selected layer type names.

        Returns:
            One :class:`CollectedEnvironmentValues` per environment with the
            user-supplied (or default-accepted) values.
        """
        ...

    def display_summary(self, config: object) -> None:
        """Display a summary of the initialization configuration.

        Args:
            config: The InitConfig object to summarize.
        """
        ...


@runtime_checkable
class InitFilesystem(Protocol):
    """Port for filesystem operations during initialization.

    This protocol abstracts filesystem access, allowing:
    - Real filesystem adapter for production
    - In-memory adapter for testing
    """

    def exists(self, path: Path) -> bool:
        """Check if a path exists.

        Args:
            path: Path to check.

        Returns:
            True if path exists, False otherwise.
        """
        ...

    def create_directory(self, path: Path) -> None:
        """Create a directory and any parent directories.

        Args:
            path: Directory path to create.
        """
        ...

    def copy_template(self, src: Path, dest: Path) -> None:
        """Copy a template file or directory to destination.

        Args:
            src: Source template path.
            dest: Destination path.
        """
        ...

    def write_file(self, path: Path, content: str) -> None:
        """Write content to a file.

        Args:
            path: File path to write to.
            content: String content to write.
        """
        ...
