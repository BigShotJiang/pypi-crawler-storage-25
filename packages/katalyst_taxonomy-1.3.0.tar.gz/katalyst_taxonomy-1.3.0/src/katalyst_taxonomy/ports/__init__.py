"""Ports (interfaces) for Katalyst taxonomy operations."""

from katalyst_taxonomy.ports.backend import (
    DeleteResult,
    SaveResult,
    SyncResult,
    TaxonomyBackend,
)
from katalyst_taxonomy.ports.export import ExportData, ExportPort, ExportResult
from katalyst_taxonomy.ports.filesystem import (
    FileReader,
    FilesystemPort,
    FileWriter,
    TemplateRenderer,
    TreeCopier,
)
from katalyst_taxonomy.ports.linting import (
    LintingService,
    LintResult,
    LintViolation,
)
from katalyst_taxonomy.ports.taxonomy import (
    CreationRequest,
    CreationResult,
    TaxonomyRepository,
    TaxonomyResult,
    TaxonomyWriter,
)
from katalyst_taxonomy.ports.template_source import TemplateSourceProtocol

__all__ = [
    # Unified backend port
    "TaxonomyBackend",
    "SaveResult",
    "DeleteResult",
    "SyncResult",
    # Taxonomy ports (deprecated — use TaxonomyBackend)
    "TaxonomyRepository",
    "TaxonomyWriter",
    "TaxonomyResult",
    "CreationRequest",
    "CreationResult",
    # Filesystem ports (focused sub-protocols)
    "FileReader",
    "FileWriter",
    "TreeCopier",
    "TemplateRenderer",
    "FilesystemPort",
    # Linting ports
    "LintViolation",
    "LintResult",
    "LintingService",
    # Export ports
    "ExportPort",
    "ExportData",
    "ExportResult",
    # Template source port
    "TemplateSourceProtocol",
]
