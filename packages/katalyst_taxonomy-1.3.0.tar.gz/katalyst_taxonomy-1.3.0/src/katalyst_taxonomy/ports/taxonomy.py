"""Ports (interfaces) for taxonomy operations."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


@dataclass(frozen=True, slots=True)
class TaxonomyResult:
    """Result of loading a taxonomy."""

    documents: tuple[Document, ...]
    environments: tuple[EnvironmentDocument, ...]
    qualified_names: dict[str, str]
    errors: tuple[DocumentError, ...]


@dataclass(frozen=True, slots=True)
class CreationRequest:
    """Request to create a new taxonomy node."""

    node_type: str
    name: str
    description: str | None = None
    owners: tuple[str, ...] = ()
    environments: tuple[str, ...] = ()
    parent: str | None = None
    parent_system: str | None = None
    layer_type: str | None = None
    target_dir: str | None = None


@dataclass(frozen=True, slots=True)
class CreationResult:
    """Result of creating a taxonomy node."""

    success: bool
    path: Path | None = None
    error: str | None = None


class TaxonomyRepository(Protocol):
    """Port for loading taxonomy data."""

    def load_documents(self, path: Path) -> tuple[Document, ...]:
        """Load all taxonomy documents from path."""
        ...

    def load_environments(self, path: Path) -> tuple[EnvironmentDocument, ...]:
        """Load environment documents from path."""
        ...

    def get_document(self, path: Path, name: str) -> Document | None:
        """Get a single document by name."""
        ...


class TaxonomyWriter(Protocol):
    """Port for writing taxonomy data."""

    def write_document(self, document: Document, path: Path) -> None:
        """Write a taxonomy document to the filesystem."""
        ...

    def create_node(
        self,
        path: Path,
        node_type: str,
        name: str,
        **kwargs: object,
    ) -> Path:
        """Create a new taxonomy node, returning the created path."""
        ...
