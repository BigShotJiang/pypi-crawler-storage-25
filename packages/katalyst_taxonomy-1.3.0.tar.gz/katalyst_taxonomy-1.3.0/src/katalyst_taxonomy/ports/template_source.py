"""Protocol for template source operations.

This protocol is shared across init, add, and upgrade services to avoid
duplicating the same interface definition in each module.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class TemplateSourceProtocol(Protocol):
    """Protocol for template source operations.

    Used by init, add, and upgrade services to fetch template packages
    from various sources (bundled, git, GitHub, etc.).
    """

    def fetch_package(self, name: str, version: str | None = None) -> object:
        """Fetch a package from this source."""
        ...

    def get_latest_version(self, name: str) -> str:
        """Get the latest version of a package."""
        ...
