"""Filesystem ports for service operations.

This module provides focused protocols following the Interface Segregation
Principle. Each protocol groups related filesystem operations so that
services can declare only the capabilities they actually need.

The combined ``FilesystemPort`` protocol retains all methods for
backwards compatibility and for callers that need the full interface.

The ``RealFilesystem`` concrete adapter is re-exported here for
backwards compatibility but its canonical location is
``katalyst_taxonomy.adapters.filesystem.real``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Mapping, Protocol, Sequence, runtime_checkable

# Re-export for backwards compatibility — canonical location is
# adapters.filesystem.real
from katalyst_taxonomy.adapters.filesystem.real import RealFilesystem

# ---------------------------------------------------------------------------
# Focused sub-protocols (Interface Segregation Principle)
# ---------------------------------------------------------------------------


@runtime_checkable
class FileReader(Protocol):
    """Read-only filesystem queries."""

    def exists(self, path: Path) -> bool:
        """Check if a path exists."""
        ...

    def is_directory(self, path: Path) -> bool:
        """Check if a path is a directory."""
        ...

    def read_file(self, path: Path) -> str:
        """Read content from a file."""
        ...

    def list_directory(self, path: Path) -> list[Path]:
        """List contents of a directory."""
        ...


@runtime_checkable
class FileWriter(Protocol):
    """Primitive file/directory mutation operations."""

    def write_file(self, path: Path, content: str) -> None:
        """Write content to a file, creating parent directories if needed."""
        ...

    def create_directory(self, path: Path) -> None:
        """Create a directory and any parent directories."""
        ...

    def remove_directory(self, path: Path) -> None:
        """Remove a directory and all its contents."""
        ...


@runtime_checkable
class TreeCopier(Protocol):
    """File and directory copy operations."""

    def copy_file(self, src: Path, dest: Path) -> None:
        """Copy a single file verbatim (no rendering). Creates parent dirs."""
        ...

    def copy_tree(self, src: Path, dest: Path) -> None:
        """Copy a directory tree, replacing destination if it exists."""
        ...

    def copy_tree_with_replacements(
        self,
        src: Path,
        dest: Path,
        replacements: list[tuple[str, str]],
    ) -> None:
        """Copy a directory tree with text replacements applied to paths and content."""
        ...

    def copy_tree_no_overwrite(
        self,
        src: Path,
        dest: Path,
    ) -> None:
        """Copy a directory tree, skipping files that already exist at the destination."""
        ...


@runtime_checkable
class TemplateRenderer(Protocol):
    """Template-aware copy operations for scaffolding."""

    def copy_tree_rendered(
        self,
        src: Path,
        dest: Path,
        context: Mapping[str, str],
        *,
        skip_names: frozenset[str] = frozenset(),
        skip_root_file: str | None = None,
    ) -> None:
        """Copy *src* into *dest*, rendering ``{{ key }}`` tokens in file content.

        Args:
            src: Source directory.
            dest: Destination directory (created if absent).
            context: Token -> value mapping for ``{{ key }}`` substitution.
            skip_names: Top-level directory names to exclude entirely.
            skip_root_file: A single root-level filename to skip.
        """
        ...

    def copy_tree_rendered_per_env(
        self,
        src: Path,
        dest: Path,
        context: Mapping[str, str],
        environments: Sequence[str],
    ) -> None:
        """Copy *src* once per environment under ``dest/<env_name>/``.

        For each environment, the context is augmented with
        ``{"environment": env_name}`` before rendering ``{{ key }}`` tokens.

        Args:
            src: Source environment-template directory.
            dest: Parent layer directory. Each env gets ``dest/<env_name>/``.
            context: Base token -> value mapping.
            environments: Ordered sequence of environment names.
        """
        ...


# ---------------------------------------------------------------------------
# Combined protocol — retained for backwards compatibility
# ---------------------------------------------------------------------------


@runtime_checkable
class FilesystemPort(FileReader, FileWriter, TreeCopier, TemplateRenderer, Protocol):
    """Combined filesystem port with all capabilities.

    Services that need only a subset of operations should declare the
    narrower sub-protocol (e.g. ``FileReader``, ``FileWriter``) instead.
    This combined type is kept for backwards compatibility and for callers
    that genuinely need the full interface.
    """

    ...


__all__ = [
    # Focused sub-protocols
    "FileReader",
    "FileWriter",
    "TreeCopier",
    "TemplateRenderer",
    # Combined protocol
    "FilesystemPort",
    # Concrete adapter (re-exported)
    "RealFilesystem",
]
