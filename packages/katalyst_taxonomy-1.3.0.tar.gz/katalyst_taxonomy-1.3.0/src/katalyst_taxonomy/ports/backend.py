"""Unified backend protocol for taxonomy data storage."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


@dataclass(frozen=True, slots=True)
class SaveResult:
    """Result of saving a document."""

    success: bool
    created: bool = False  # True if new, False if updated
    path: Path | None = None
    error: str | None = None


@dataclass(frozen=True, slots=True)
class DeleteResult:
    """Result of deleting a document."""

    success: bool
    error: str | None = None


@dataclass(frozen=True, slots=True)
class SyncResult:
    """Result of syncing data between backends."""

    success: bool
    nodes_created: int = 0
    nodes_updated: int = 0
    nodes_deleted: int = 0
    relationships_created: int = 0
    relationships_deleted: int = 0
    errors: tuple[str, ...] = field(default_factory=tuple)


class TaxonomyBackend(Protocol):
    """Unified read/write backend for taxonomy data.

    All configuration (filesystem path, database URI, etc.) is injected
    at construction time.  Methods operate against the configured store
    without requiring per-call path or connection arguments.

    Implementations:
        - ``FilesystemBackend`` — reads/writes YAML files on disk
        - ``Neo4jBackend`` — reads/writes a Neo4j graph database
        - ``PostgresBackend`` — reads/writes PostgreSQL tables
    """

    @property
    def name(self) -> str:
        """Backend identifier (e.g., 'filesystem', 'neo4j', 'postgres')."""
        ...

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def load_documents(self) -> tuple[Document, ...]:
        """Load all taxonomy documents."""
        ...

    def load_environments(self) -> tuple[EnvironmentDocument, ...]:
        """Load all environment documents."""
        ...

    def get_document(self, name: str) -> Document | None:
        """Get a single document by name."""
        ...

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def create_node(
        self,
        node_type: str,
        name: str,
        **kwargs: object,
    ) -> SaveResult:
        """Create a new taxonomy node.

        Returns a ``SaveResult`` with ``created=True`` on success.
        """
        ...

    # ------------------------------------------------------------------
    # Sync operations
    # ------------------------------------------------------------------

    def sync_from(
        self,
        source: TaxonomyBackend,
        *,
        full: bool = False,
    ) -> SyncResult:
        """Sync data from another backend.

        Args:
            source: The backend to pull data from.
            full: If True, clear and recreate. If False, incremental upsert + prune.
        """
        ...

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def health_check(self) -> bool:
        """Check if the backend is reachable and ready."""
        ...

    def close(self) -> None:
        """Release resources (connections, file handles, etc.)."""
        ...

    def errors(self) -> tuple[DocumentError, ...]:
        """Return errors from the last load operation."""
        ...
