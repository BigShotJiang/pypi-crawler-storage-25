"""Semantic version parsing and comparison.

This module provides utilities for parsing and comparing semantic versions
following the SemVer 2.0.0 specification (https://semver.org/).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from functools import total_ordering

# Regex pattern for semantic versions
# Matches: 1.2.3, v1.2.3, 1.2.3-alpha, 1.2.3-beta.1, etc.
VERSION_PATTERN = re.compile(
    r"^v?"  # Optional v prefix
    r"(?P<major>\d+)"  # Major version (required)
    r"(?:\.(?P<minor>\d+))?"  # Minor version (optional)
    r"(?:\.(?P<patch>\d+))?"  # Patch version (optional)
    r"(?:-(?P<prerelease>[a-zA-Z0-9.-]+))?"  # Prerelease (optional)
    r"(?:\+(?P<build>[a-zA-Z0-9.-]+))?$",  # Build metadata (optional, ignored)
)


@total_ordering
@dataclass(frozen=True, slots=True)
class Version:
    """Represents a semantic version.

    Attributes:
        major: Major version number.
        minor: Minor version number.
        patch: Patch version number.
        prerelease: Prerelease identifier (e.g., "alpha", "beta.1").
    """

    major: int
    minor: int = 0
    patch: int = 0
    prerelease: str | None = None

    def __str__(self) -> str:
        """Return string representation of version."""
        base = f"{self.major}.{self.minor}.{self.patch}"
        if self.prerelease:
            return f"{base}-{self.prerelease}"
        return base

    def __eq__(self, other: object) -> bool:
        """Check equality with another version."""
        if not isinstance(other, Version):
            return NotImplemented
        return (
            self.major == other.major
            and self.minor == other.minor
            and self.patch == other.patch
            and self.prerelease == other.prerelease
        )

    def __lt__(self, other: object) -> bool:
        """Check if this version is less than another.

        Comparison rules (per SemVer):
        1. Compare major, minor, patch numerically
        2. A version with prerelease is less than the same version without
        3. Prerelease identifiers are compared lexicographically
        """
        if not isinstance(other, Version):
            return NotImplemented

        # Compare major.minor.patch
        if (self.major, self.minor, self.patch) != (other.major, other.minor, other.patch):
            return (self.major, self.minor, self.patch) < (other.major, other.minor, other.patch)

        # Same base version - compare prerelease
        # A version without prerelease is greater than one with prerelease
        if self.prerelease is None and other.prerelease is None:
            return False  # Equal
        if self.prerelease is None:
            return False  # self (release) > other (prerelease)
        if other.prerelease is None:
            return True  # self (prerelease) < other (release)

        # Both have prerelease - compare lexicographically
        return self.prerelease < other.prerelease

    def __hash__(self) -> int:
        """Return hash of version."""
        return hash((self.major, self.minor, self.patch, self.prerelease))


def parse_version(version_str: str) -> Version:
    """Parse a version string into a Version object.

    Args:
        version_str: Version string (e.g., "1.2.3", "v1.0.0-alpha").

    Returns:
        Version object.

    Raises:
        ValueError: If the version string is invalid.

    Examples:
        >>> parse_version("1.2.3")
        Version(major=1, minor=2, patch=3, prerelease=None)
        >>> parse_version("v1.0.0-alpha")
        Version(major=1, minor=0, patch=0, prerelease='alpha')
    """
    if not version_str or not version_str.strip():
        raise ValueError("Version string cannot be empty")

    match = VERSION_PATTERN.match(version_str.strip())
    if not match:
        raise ValueError(f"Invalid version string: {version_str}")

    groups = match.groupdict()
    return Version(
        major=int(groups["major"]),
        minor=int(groups["minor"]) if groups["minor"] else 0,
        patch=int(groups["patch"]) if groups["patch"] else 0,
        prerelease=groups["prerelease"],
    )


def compare_versions(version1: str, version2: str) -> int:
    """Compare two version strings.

    Args:
        version1: First version string.
        version2: Second version string.

    Returns:
        -1 if version1 < version2
        0 if version1 == version2
        1 if version1 > version2

    Raises:
        ValueError: If either version string is invalid.
    """
    v1 = parse_version(version1)
    v2 = parse_version(version2)

    if v1 < v2:
        return -1
    if v1 > v2:
        return 1
    return 0


def is_upgrade(from_version: str, to_version: str) -> bool:
    """Check if upgrading from one version to another is an upgrade.

    Args:
        from_version: Currently installed version.
        to_version: Version to upgrade to.

    Returns:
        True if to_version is newer than from_version.

    Raises:
        ValueError: If either version string is invalid.
    """
    return compare_versions(from_version, to_version) < 0


# ---------------------------------------------------------------------------
# Version Constraints
# ---------------------------------------------------------------------------

# Regex for a single constraint: operator + version
_CONSTRAINT_RE = re.compile(r"^\s*(?P<op>>=|<=|!=|>|<|==|\^|~)\s*(?P<version>.+?)\s*$")


@dataclass(frozen=True, slots=True)
class VersionConstraint:
    """A set of version constraints joined by AND semantics.

    Each individual constraint is an (operator, version) pair.
    A version satisfies the constraint only if it satisfies *all* pairs.

    Supported operators:
        ==   exact match
        !=   not equal
        >    greater than
        <    less than
        >=   greater than or equal
        <=   less than or equal
        ^    caret (compatible with major) — allows changes that do not
             modify the left-most non-zero digit
        ~    tilde (compatible with minor) — allows patch-level changes

    Multiple constraints are separated by commas and combined with AND.

    Examples:
        ">=1.0.0"              — any version >= 1.0.0
        ">=1.0.0, <2.0.0"     — 1.x range
        "^1.2.3"              — >=1.2.3, <2.0.0
        "~1.2.3"              — >=1.2.3, <1.3.0
    """

    constraints: tuple[tuple[str, Version], ...]

    def matches(self, version: Version | str) -> bool:
        """Check whether *version* satisfies all constraints.

        Args:
            version: A Version instance or a parseable version string.

        Returns:
            True if the version satisfies every constraint.
        """
        if isinstance(version, str):
            version = parse_version(version)

        return all(_check_single(op, target, version) for op, target in self.constraints)

    def __str__(self) -> str:
        parts: list[str] = []
        for op, ver in self.constraints:
            parts.append(f"{op}{ver}")
        return ", ".join(parts)


def parse_constraint(constraint_str: str) -> VersionConstraint:
    """Parse a version constraint expression.

    Args:
        constraint_str: Constraint expression, e.g. ``">=1.0.0, <2.0.0"``.

    Returns:
        A :class:`VersionConstraint` instance.

    Raises:
        ValueError: If the expression is syntactically invalid.
    """
    if not constraint_str or not constraint_str.strip():
        raise ValueError("Version constraint string cannot be empty")

    parts = [p.strip() for p in constraint_str.split(",")]
    parsed: list[tuple[str, Version]] = []

    for part in parts:
        if not part:
            continue
        match = _CONSTRAINT_RE.match(part)
        if not match:
            raise ValueError(f"Invalid version constraint: {part!r}")
        op = match.group("op")
        ver = parse_version(match.group("version"))
        parsed.append((op, ver))

    if not parsed:
        raise ValueError(f"No valid constraints in: {constraint_str!r}")

    return VersionConstraint(constraints=tuple(parsed))


def _check_single(op: str, target: Version, actual: Version) -> bool:
    """Evaluate a single (operator, target) constraint against *actual*."""
    if op == "==":
        return actual == target
    if op == "!=":
        return actual != target
    if op == ">":
        return actual > target
    if op == "<":
        return actual < target
    if op == ">=":
        return actual >= target
    if op == "<=":
        return actual <= target
    if op == "^":
        return _caret_match(target, actual)
    if op == "~":
        return _tilde_match(target, actual)
    raise ValueError(f"Unknown operator: {op}")


def _caret_match(target: Version, actual: Version) -> bool:
    """Caret (^) — compatible with the left-most non-zero digit.

    ^1.2.3 → >=1.2.3, <2.0.0
    ^0.2.3 → >=0.2.3, <0.3.0
    ^0.0.3 → >=0.0.3, <0.0.4
    """
    if actual < target:
        return False
    if target.major != 0:
        return actual.major == target.major
    if target.minor != 0:
        return actual.major == 0 and actual.minor == target.minor
    return actual.major == 0 and actual.minor == 0 and actual.patch == target.patch


def _tilde_match(target: Version, actual: Version) -> bool:
    """Tilde (~) — allows patch-level changes.

    ~1.2.3 → >=1.2.3, <1.3.0
    """
    if actual < target:
        return False
    return actual.major == target.major and actual.minor == target.minor
