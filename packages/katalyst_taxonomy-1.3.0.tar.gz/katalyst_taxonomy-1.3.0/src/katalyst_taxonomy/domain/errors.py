"""Error types for Katalyst domain."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


class KatalystError(Exception):
    """Base exception for all Katalyst errors."""


class ValidationError(KatalystError):
    """Raised when validation fails."""

    def __init__(self, message: str, *, field: str | None = None) -> None:
        self.field = field
        if field:
            message = f"{field}: {message}"
        super().__init__(message)


@dataclass(frozen=True, slots=True)
class DocumentError:
    """Represents an error encountered while loading a document."""

    path: Path
    message: str
    document_index: int = 0

    def __str__(self) -> str:
        if self.document_index:
            return f"{self.path} (document {self.document_index}): {self.message}"
        return f"{self.path}: {self.message}"
