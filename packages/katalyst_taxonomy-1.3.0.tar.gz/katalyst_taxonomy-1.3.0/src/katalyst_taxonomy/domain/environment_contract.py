"""Environment contract declarations for plugins.

An environment contract declares what keys a plugin requires from
Environment documents (templateReplacements and layerTemplates).
"""

from __future__ import annotations

# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownArgumentType=false
from dataclasses import dataclass
from typing import Mapping

__all__ = [
    "EMPTY_CONTRACT",
    "EnvironmentContract",
    "parse_environment_contract",
]


@dataclass(frozen=True, slots=True)
class EnvironmentContract:
    """Declares environment keys that a plugin requires.

    ``template_replacements`` lists keys expected in
    ``Environment.spec.templateReplacements``.

    ``layer_templates`` lists keys expected in
    ``Environment.spec.layerTemplates.<layerType>``.
    """

    template_replacements: tuple[str, ...]
    layer_templates: tuple[str, ...]

    @property
    def is_empty(self) -> bool:
        return not self.template_replacements and not self.layer_templates


EMPTY_CONTRACT = EnvironmentContract(template_replacements=(), layer_templates=())


def parse_environment_contract(
    value: object,
) -> EnvironmentContract:
    """Parse an ``environment_contract`` block from a document spec.

    Returns :data:`EMPTY_CONTRACT` when *value* is ``None``.
    """
    if value is None:
        return EMPTY_CONTRACT

    if not isinstance(value, (dict, Mapping)):
        return EMPTY_CONTRACT

    template_replacements = _collect_strings(value.get("templateReplacements"))  # type: ignore[union-attr]
    layer_templates = _collect_strings(value.get("layerTemplates"))  # type: ignore[union-attr]

    return EnvironmentContract(
        template_replacements=template_replacements,
        layer_templates=layer_templates,
    )


def _collect_strings(value: object) -> tuple[str, ...]:
    """Collect a sequence of strings, returning empty tuple for None."""
    if value is None:
        return ()
    if isinstance(value, (list, tuple)):
        return tuple(str(item) for item in value if isinstance(item, str) and item)
    return ()
