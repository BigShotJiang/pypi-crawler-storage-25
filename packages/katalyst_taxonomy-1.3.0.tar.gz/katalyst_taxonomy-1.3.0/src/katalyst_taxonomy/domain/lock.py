"""Domain models for the Katalyst lock file (taxonomy.lock)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping

from katalyst_taxonomy.templates.sources.local import KNOWN_PLUGINS as _KNOWN_TUPLE

LOCK_API_VERSION = "katalyst.taxonomy/v1alpha"
LOCK_KIND = "KatalystLock"

# Known plugin names — derived from bundled manifest
KNOWN_PLUGINS = frozenset(_KNOWN_TUPLE)


def _empty_plugin_dict() -> dict[str, InstalledPlugin]:
    """Factory for empty plugin dict."""
    return {}


def _utc_now() -> datetime:
    """Get current UTC timestamp."""
    return datetime.now(timezone.utc)


@dataclass(frozen=True, slots=True)
class LockMetadata:
    """Metadata for the lock file."""

    generated_at: datetime
    generated_by: str
    katalyst_version: str

    def __post_init__(self) -> None:
        if not self.generated_by or not self.generated_by.strip():
            raise ValueError("metadata.generatedBy cannot be blank")
        if not self.katalyst_version or not self.katalyst_version.strip():
            raise ValueError("metadata.katalystVersion cannot be blank")


@dataclass(frozen=True, slots=True)
class InstalledCore:
    """Represents the installed core framework."""

    version: str
    schema_version: str
    installed_at: datetime
    source: str = "bundled"

    def __post_init__(self) -> None:
        if not self.version or not self.version.strip():
            raise ValueError("core.version cannot be blank")
        if not self.schema_version or not self.schema_version.strip():
            raise ValueError("core.schemaVersion cannot be blank")
        if not self.source or not self.source.strip():
            raise ValueError("core.source cannot be blank")


@dataclass(frozen=True, slots=True)
class InstalledPlugin:
    """Represents an installed plugin."""

    version: str
    installed_at: datetime
    source: str = "bundled"
    canonical: tuple[str, ...] = ()
    custom: tuple[str, ...] = ()
    item_versions: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        if not self.version or not self.version.strip():
            raise ValueError("plugin.version cannot be blank")
        if not self.source or not self.source.strip():
            raise ValueError("plugin.source cannot be blank")
        # Ensure tuples (for when lists are passed)
        object.__setattr__(self, "canonical", tuple(self.canonical))
        object.__setattr__(self, "custom", tuple(self.custom))
        # Ensure item_versions is a tuple of (name, version) pairs
        if isinstance(self.item_versions, dict):
            object.__setattr__(
                self,
                "item_versions",
                tuple(sorted(self.item_versions.items())),  # type: ignore[arg-type]
            )
        else:
            object.__setattr__(self, "item_versions", tuple(self.item_versions))

    def get_item_version(self, item_name: str) -> str | None:
        """Get the version for a specific item."""
        for name, version in self.item_versions:
            if name == item_name:
                return version
        return None

    def item_versions_dict(self) -> dict[str, str]:
        """Get item versions as a dict."""
        return dict(self.item_versions)


@dataclass(frozen=True, slots=True)
class InstalledComponents:
    """All installed components tracked by the lock file."""

    core: InstalledCore
    plugins: Mapping[str, InstalledPlugin] = field(default_factory=_empty_plugin_dict)

    def __post_init__(self) -> None:
        # Create immutable copy of plugins
        plugins_copy: dict[str, InstalledPlugin] = dict(self.plugins) if self.plugins else {}
        object.__setattr__(self, "plugins", plugins_copy)


@dataclass(frozen=True, slots=True)
class KatalystLock:
    """
    Top-level lock file document.

    This tracks all installed components and their versions in a taxonomy repository.
    Location: .global/taxonomy/taxonomy.lock
    """

    api_version: str
    kind: str
    metadata: LockMetadata
    installed: InstalledComponents
    source_path: Path | None = None

    def __post_init__(self) -> None:
        if self.api_version != LOCK_API_VERSION:
            raise ValueError(f"Unsupported apiVersion: {self.api_version}")
        if self.kind != LOCK_KIND:
            raise ValueError(f"Unsupported kind: {self.kind}")

    @classmethod
    def create_new(
        cls,
        *,
        katalyst_version: str,
        core_version: str,
        schema_version: str,
        generated_by: str = "kata tax init",
        plugins: Mapping[str, InstalledPlugin] | None = None,
    ) -> KatalystLock:
        """
        Factory method to create a new lock file with sensible defaults.

        Args:
            katalyst_version: Version of the kata CLI that created this lock
            core_version: Version of the core framework installed
            schema_version: Version of the schemas installed
            generated_by: Command that generated this lock file
            plugins: Optional dict of installed plugins

        Returns:
            A new KatalystLock instance
        """
        now = _utc_now()

        return cls(
            api_version=LOCK_API_VERSION,
            kind=LOCK_KIND,
            metadata=LockMetadata(
                generated_at=now,
                generated_by=generated_by,
                katalyst_version=katalyst_version,
            ),
            installed=InstalledComponents(
                core=InstalledCore(
                    version=core_version,
                    schema_version=schema_version,
                    installed_at=now,
                    source="bundled",
                ),
                plugins=plugins or {},
            ),
        )

    def get_plugin(self, name: str) -> InstalledPlugin | None:
        """Get an installed plugin by name."""
        return self.installed.plugins.get(name)

    def has_plugin(self, name: str) -> bool:
        """Check if a plugin is installed."""
        return name in self.installed.plugins

    def plugin_names(self) -> frozenset[str]:
        """Get the names of all installed plugins."""
        return frozenset(self.installed.plugins.keys())

    def with_plugin(
        self,
        name: str,
        plugin: InstalledPlugin,
    ) -> KatalystLock:
        """Return a new lock with the given plugin added or updated."""
        new_plugins = dict(self.installed.plugins)
        new_plugins[name] = plugin

        return KatalystLock(
            api_version=self.api_version,
            kind=self.kind,
            metadata=LockMetadata(
                generated_at=_utc_now(),
                generated_by=self.metadata.generated_by,
                katalyst_version=self.metadata.katalyst_version,
            ),
            installed=InstalledComponents(
                core=self.installed.core,
                plugins=new_plugins,
            ),
            source_path=self.source_path,
        )

    def without_plugin(self, name: str) -> KatalystLock:
        """Return a new lock with the given plugin removed."""
        new_plugins = {k: v for k, v in self.installed.plugins.items() if k != name}

        return KatalystLock(
            api_version=self.api_version,
            kind=self.kind,
            metadata=LockMetadata(
                generated_at=_utc_now(),
                generated_by=self.metadata.generated_by,
                katalyst_version=self.metadata.katalyst_version,
            ),
            installed=InstalledComponents(
                core=self.installed.core,
                plugins=new_plugins,
            ),
            source_path=self.source_path,
        )
