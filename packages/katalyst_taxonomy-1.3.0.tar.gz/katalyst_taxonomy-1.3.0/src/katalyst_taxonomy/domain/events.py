"""Event system for Katalyst."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable


class EventType(str, Enum):
    """Types of events that can be published."""

    # Taxonomy lifecycle
    TAXONOMY_LOADED = "taxonomy.loaded"
    TAXONOMY_ERROR = "taxonomy.error"

    # Node events
    NODE_CREATED = "node.created"
    NODE_UPDATED = "node.updated"
    NODE_DELETED = "node.deleted"
    NODE_CLONED = "node.cloned"

    # Linting events
    LINT_STARTED = "lint.started"
    LINT_COMPLETED = "lint.completed"

    # Action events
    ACTION_STARTED = "action.started"
    ACTION_COMPLETED = "action.completed"
    ACTION_FAILED = "action.failed"

    # Server events
    SERVER_CONNECTED = "server.connected"
    SERVER_HEARTBEAT = "server.heartbeat"


@dataclass(frozen=True)
class Event:
    """An event that can be published to the event bus."""

    type: EventType
    properties: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary for serialization."""
        return {
            "type": self.type.value,
            "properties": self.properties,
        }


class EventBus:
    """Simple in-process pub/sub event bus."""

    def __init__(self) -> None:
        self._handlers: list[Callable[[Event], None]] = []

    def subscribe(self, handler: Callable[[Event], None]) -> Callable[[], None]:
        """Subscribe to events. Returns an unsubscribe function."""
        self._handlers.append(handler)

        def unsubscribe() -> None:
            if handler in self._handlers:
                self._handlers.remove(handler)

        return unsubscribe

    def publish(self, event: Event) -> None:
        """Publish an event to all subscribers."""
        for handler in self._handlers:
            try:
                handler(event)
            except Exception:
                # Don't let one handler break others
                pass
