"""Domain models for the dependency graph."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class DependencyNode:
    """A node in the dependency graph."""

    fqtn: str
    name: str
    node_type: str
    dependencies: list[str] = field(default_factory=lambda: list[str]())
    dependents: list[str] = field(default_factory=lambda: list[str]())


@dataclass
class DependencyGraph:
    """Represents the full dependency graph."""

    nodes: dict[str, DependencyNode] = field(default_factory=lambda: dict[str, DependencyNode]())
    cycles: list[list[str]] = field(default_factory=lambda: list[list[str]]())
    unresolved: dict[str, list[str]] = field(default_factory=lambda: dict[str, list[str]]())
