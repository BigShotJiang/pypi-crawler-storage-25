"""Bundled agent/skill resource access and seeding utilities.

Provides runtime access to the default agents and skills shipped inside the
``katalyst-taxonomy`` Python package, and helpers to copy them into a local
``.agents/`` directory.
"""

from __future__ import annotations

import importlib.resources
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator

from loguru import logger

__all__ = [
    "BundledContent",
    "SyncResult",
    "copy_bundled_to",
    "get_bundled_path",
    "scan_bundled",
]


def get_bundled_path() -> Path | None:
    """Return the filesystem path to the bundled agents/skills directory.

    Uses ``importlib.resources`` to locate the ``_bundled`` package directory.
    Returns ``None`` when the bundled content is unavailable (e.g. the package
    was installed without the data files).
    """
    try:
        ref = importlib.resources.files("katalyst_taxonomy.agents._bundled")
        # Traverse to get a concrete path.  On editable installs the
        # traversable *is* already a Path; on wheel installs we fall
        # back to as_posix / joinpath resolution.
        bundled = Path(str(ref))
        if bundled.is_dir():
            return bundled
    except (ModuleNotFoundError, TypeError, FileNotFoundError):
        pass

    return None


# ─────────────────────────────────────────────────────────────────────────────
# Bundled content scanning
# ─────────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class BundledContent:
    """Summary of what is available in the bundled package."""

    path: Path
    agent_files: tuple[Path, ...]
    skill_dirs: tuple[Path, ...]
    config_file: Path | None


def _iter_bundled_agents(agents_dir: Path) -> Iterator[Path]:
    """Iterate ``.md`` files in the bundled agents directory."""
    if not agents_dir.is_dir():
        return
    for p in sorted(agents_dir.glob("*.md")):
        if p.is_file():
            yield p


def _iter_bundled_skills(skills_dir: Path) -> Iterator[Path]:
    """Iterate skill directories (containing ``SKILL.md``) in the bundled skills directory."""
    if not skills_dir.is_dir():
        return
    for d in sorted(skills_dir.iterdir()):
        if d.is_dir() and (d / "SKILL.md").is_file():
            yield d


def scan_bundled() -> BundledContent | None:
    """Scan the bundled package and return a summary of its contents.

    Returns ``None`` when no bundled content is available.
    """
    bundled = get_bundled_path()
    if bundled is None:
        return None

    agent_files = tuple(_iter_bundled_agents(bundled / "agents"))
    skill_dirs = tuple(_iter_bundled_skills(bundled / "skills"))

    config_file: Path | None = None
    for name in ("agents.yaml", "agents.yml", "agents.json"):
        candidate = bundled / name
        if candidate.is_file():
            config_file = candidate
            break

    return BundledContent(
        path=bundled,
        agent_files=agent_files,
        skill_dirs=skill_dirs,
        config_file=config_file,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Seeding / syncing bundled content into a local .agents/ directory
# ─────────────────────────────────────────────────────────────────────────────


@dataclass(frozen=True, slots=True)
class SyncResult:
    """Result of a copy/sync operation."""

    agents_copied: tuple[str, ...]
    agents_skipped: tuple[str, ...]
    skills_copied: tuple[str, ...]
    skills_skipped: tuple[str, ...]

    @property
    def total_copied(self) -> int:
        return len(self.agents_copied) + len(self.skills_copied)

    @property
    def total_skipped(self) -> int:
        return len(self.agents_skipped) + len(self.skills_skipped)


def copy_bundled_to(
    target: Path,
    *,
    force: bool = False,
) -> SyncResult:
    """Copy bundled agents and skills into a target ``.agents/`` directory.

    Args:
        target: Path to the ``.agents/`` directory to populate.
        force: If ``True``, overwrite existing files.  Otherwise skip them.

    Returns:
        A :class:`SyncResult` summarising what was copied/skipped.

    Raises:
        FileNotFoundError: If the bundled content is not available.
    """
    content = scan_bundled()
    if content is None:
        raise FileNotFoundError("Bundled agents/skills not found in package")

    agents_dir = target / "agents"
    skills_dir = target / "skills"
    agents_dir.mkdir(parents=True, exist_ok=True)
    skills_dir.mkdir(parents=True, exist_ok=True)

    agents_copied: list[str] = []
    agents_skipped: list[str] = []
    skills_copied: list[str] = []
    skills_skipped: list[str] = []

    # Copy agent files
    for src_file in content.agent_files:
        dst_file = agents_dir / src_file.name
        if dst_file.exists() and not force:
            agents_skipped.append(src_file.stem)
            logger.debug(f"Skipped existing agent: {dst_file}")
            continue
        shutil.copy2(src_file, dst_file)
        agents_copied.append(src_file.stem)
        logger.debug(f"Copied bundled agent: {dst_file}")

    # Copy skill directories
    for src_dir in content.skill_dirs:
        skill_name = src_dir.name
        dst_dir = skills_dir / skill_name
        if dst_dir.exists() and not force:
            skills_skipped.append(skill_name)
            logger.debug(f"Skipped existing skill: {dst_dir}")
            continue
        # Remove old version when forcing
        if dst_dir.exists() and force:
            shutil.rmtree(dst_dir)
        shutil.copytree(src_dir, dst_dir)
        skills_copied.append(skill_name)
        logger.debug(f"Copied bundled skill: {dst_dir}")

    return SyncResult(
        agents_copied=tuple(agents_copied),
        agents_skipped=tuple(agents_skipped),
        skills_copied=tuple(skills_copied),
        skills_skipped=tuple(skills_skipped),
    )
