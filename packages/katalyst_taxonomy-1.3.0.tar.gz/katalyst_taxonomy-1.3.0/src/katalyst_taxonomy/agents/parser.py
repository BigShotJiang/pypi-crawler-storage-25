"""Parser for markdown files with YAML frontmatter.

This module handles parsing agent and skill definition files that use the
markdown + YAML frontmatter format:

```markdown
---
name: my-agent
description: Does something useful
mode: subagent
---

# Agent Title

Prompt content here...
```
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from katalyst_taxonomy.agents.models import Agent, AgentsConfig, Skill
from katalyst_taxonomy.parsing.frontmatter import (
    ParseError,
    parse_frontmatter,
    serialize_frontmatter,
)

__all__ = [
    "ParseError",
    "parse_agent_file",
    "parse_config_file",
    "parse_frontmatter",
    "parse_skill_file",
    "serialize_agent",
    "serialize_skill",
]


def parse_agent_file(path: Path) -> Agent:
    """Parse an agent definition file.

    Args:
        path: Path to the agent markdown file.

    Returns:
        An Agent instance.

    Raises:
        ParseError: If the file cannot be parsed.
        FileNotFoundError: If the file doesn't exist.
    """
    content = path.read_text(encoding="utf-8")
    frontmatter, body = parse_frontmatter(content, path)

    try:
        return Agent.from_dict(frontmatter, prompt=body, source_path=path)
    except ValueError as e:
        raise ParseError(str(e), path) from e


def parse_skill_file(path: Path) -> Skill:
    """Parse a skill definition file (SKILL.md).

    Args:
        path: Path to the SKILL.md file.

    Returns:
        A Skill instance.

    Raises:
        ParseError: If the file cannot be parsed.
        FileNotFoundError: If the file doesn't exist.
    """
    content = path.read_text(encoding="utf-8")
    frontmatter, body = parse_frontmatter(content, path)

    # Validate that name matches directory name
    expected_name = path.parent.name
    actual_name = frontmatter.get("name")

    if actual_name and actual_name != expected_name:
        raise ParseError(
            f"Skill name '{actual_name}' must match directory name '{expected_name}'",
            path,
        )

    # Use directory name if name not specified
    if not actual_name:
        frontmatter["name"] = expected_name

    try:
        return Skill.from_dict(frontmatter, content=body, source_path=path)
    except ValueError as e:
        raise ParseError(str(e), path) from e


def parse_config_file(path: Path) -> AgentsConfig:
    """Parse an agents configuration file (agents.yaml or agents.json).

    Args:
        path: Path to the config file.

    Returns:
        An AgentsConfig instance.

    Raises:
        ParseError: If the file cannot be parsed.
        FileNotFoundError: If the file doesn't exist.
    """
    content = path.read_text(encoding="utf-8")

    if path.suffix in (".yaml", ".yml"):
        try:
            data = yaml.safe_load(content)
        except yaml.YAMLError as e:
            raise ParseError(f"Invalid YAML: {e}", path) from e
    elif path.suffix == ".json":
        import json

        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            raise ParseError(f"Invalid JSON: {e}", path) from e
    else:
        raise ParseError(f"Unsupported config file format: {path.suffix}", path)

    if data is None:
        data = {}

    if not isinstance(data, dict):
        raise ParseError(f"Config must be a mapping, got {type(data).__name__}", path)

    config_data: dict[str, Any] = data  # type: ignore[assignment]
    return AgentsConfig.from_dict(config_data, source_path=path)


def serialize_agent(agent: Agent) -> str:
    """Serialize an agent to markdown with frontmatter.

    Args:
        agent: The agent to serialize.

    Returns:
        The complete markdown content.
    """
    frontmatter = agent.to_frontmatter_dict()
    return serialize_frontmatter(frontmatter, agent.prompt or "")


def serialize_skill(skill: Skill) -> str:
    """Serialize a skill to markdown with frontmatter.

    Args:
        skill: The skill to serialize.

    Returns:
        The complete markdown content.
    """
    frontmatter = skill.to_frontmatter_dict()
    return serialize_frontmatter(frontmatter, skill.content or "")


def serialize_config(config: AgentsConfig) -> str:
    """Serialize a config to YAML.

    Args:
        config: The config to serialize.

    Returns:
        The YAML content.
    """
    data = config.to_dict()
    return yaml.dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True)
