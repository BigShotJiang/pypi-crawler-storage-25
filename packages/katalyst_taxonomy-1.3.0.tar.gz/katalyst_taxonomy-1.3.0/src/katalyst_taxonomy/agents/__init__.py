"""Agents module for managing AI coding assistant definitions.

This module provides:
- Models for Agent, Skill, and Config definitions
- Parser for markdown frontmatter
- Directory discovery for .agents/
- Symlink management for OpenCode compatibility
- Bundled agent/skill access and seeding
- Validation against JSON schemas
- Resolution of agents/skills by taxonomy context (layer type, etc.)
"""

from __future__ import annotations

from katalyst_taxonomy.agents.models import (
    Agent,
    AgentMode,
    AgentsConfig,
    AgentSource,
    Bindings,
    KatalystExtension,
    PermissionLevel,
    Permissions,
    Scope,
    Skill,
    SymlinksConfig,
)
from katalyst_taxonomy.agents.resolution import (
    ResolvedContext,
    resolve_for_layer_type,
)

__all__ = [
    "Agent",
    "AgentMode",
    "AgentSource",
    "AgentsConfig",
    "Bindings",
    "KatalystExtension",
    "PermissionLevel",
    "Permissions",
    "ResolvedContext",
    "Scope",
    "Skill",
    "SymlinksConfig",
    "resolve_for_layer_type",
]
