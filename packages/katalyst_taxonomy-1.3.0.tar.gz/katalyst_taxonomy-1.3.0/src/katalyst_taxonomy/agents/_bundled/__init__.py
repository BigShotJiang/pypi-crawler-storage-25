"""Bundled agent and skill definitions.

This package is the **authoritative source** for the default agents and
skills that ship with the katalyst-taxonomy package.  Edit the files here
directly -- there is no separate copy step.

The repository-root ``.agents/`` directory is reserved for development
agents used by contributors working on the katalyst-taxonomy codebase
itself; it is **not** bundled into the package.

At runtime the ``bundled`` module (``agents/bundled.py``) uses
``importlib.resources`` to locate these files so they are accessible
even after ``pip install``.
"""
