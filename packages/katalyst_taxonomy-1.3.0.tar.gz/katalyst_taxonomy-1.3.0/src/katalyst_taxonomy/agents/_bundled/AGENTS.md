# Katalyst Taxonomy

AI-powered architecture management. This package provides skills and agents
for working with the Katalyst Taxonomy system -- a hierarchical modeling
framework for organizing systems, stacks, and layers, plus
portfolio and organizational structures (organizations, programs, projects,
teams, and team members).

These agents and skills are **bundled in the Python package** and automatically
seeded into your `.agents/` directory when you run `kata tax agents init`. After
upgrading, run `kata tax agents sync` to pick up new additions. Local customizations
in `.agents/` always take precedence over bundled defaults.

## Skills

| Skill | Description |
|-------|-------------|
| **katalyst-taxonomy** | Core concepts, YAML schema, technical/portfolio/organizational hierarchies, CLI commands |
| **katalyst-navigator** | Browse and query taxonomy structure, FQTN resolution, dependencies |
| **katalyst-actions** | Run 57 canonical layer actions, Just recipe framework |
| **katalyst-environments** | Environment-aware operations, promotion targets, template replacements |
| **katalyst-cicd** | CI/CD pipeline generation from taxonomy metadata |
| **katalyst-action-builder** | Author new Action YAML definitions, extend the canonical set |
| **katalyst-layer-type-builder** | Create new layer type templates with scaffolding |
| **katalyst-plugin-builder** | Create plugins: capabilities, extensions, tools, CI/CD templates |

## Agents

| Agent | Description |
|-------|-------------|
| **taxonomy-builder** | Create taxonomy nodes interactively (system/stack/layer/organization/program/project/team/team_member) |
| **plugin-builder** | Create plugins interactively (actions, capabilities, CI/CD, tools) |
| **layer-type-builder** | Create complete layer type template packages |
| **agent-maker** | Meta-agent that creates other agents and skills |
| **validator-fixer** | Deep validation and auto-fixing of taxonomy issues |
| **dependency-analyzer** | Dependency graph analysis, cycle detection, impact analysis |
| **taxonomy-refactorer** | Rename, move, merge, split, delete taxonomy nodes |
| **doc-generator** | Generate READMEs, architecture docs, service catalogs |
| **cicd-generator** | Generate GitHub Actions workflows from taxonomy |
| **taxonomy-cloner** | Clone existing nodes as templates |
| **example-builder** | Create documentation examples from live taxonomy |
