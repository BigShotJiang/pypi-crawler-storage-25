"""Data models for agent and skill definitions.

These models represent the in-memory structure of agents, skills, and configuration
as defined in the agents spec. They are designed to be compatible with OpenCode's
agent format while supporting additional Katalyst-specific extensions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Mapping, cast

__all__ = [
    "Agent",
    "AgentMode",
    "AgentSource",
    "AgentsConfig",
    "Bindings",
    "KatalystExtension",
    "PermissionLevel",
    "Permissions",
    "Scope",
    "Skill",
    "SymlinksConfig",
]

# Type aliases
AgentMode = Literal["primary", "subagent", "all"]
AgentSource = Literal["local", "bundled"]
PermissionLevel = Literal["allow", "ask", "deny"]


def _to_dict_str_bool(raw: Any) -> dict[str, bool]:
    """Safely convert a raw value to dict[str, bool]."""
    if isinstance(raw, dict):
        src = cast(dict[str, Any], raw)
        return {str(k): bool(v) for k, v in src.items()}
    return {}


def _to_dict_str_str(raw: Any) -> dict[str, str]:
    """Safely convert a raw value to dict[str, str]."""
    if isinstance(raw, dict):
        src = cast(dict[str, Any], raw)
        return {str(k): str(v) for k, v in src.items()}
    return {}


def _to_dict_str_any(raw: Any) -> dict[str, Any]:
    """Safely convert a raw value to dict[str, Any]."""
    if isinstance(raw, dict):
        src = cast(dict[str, Any], raw)
        return {str(k): v for k, v in src.items()}
    return {}


def _to_dict_str_dict(raw: Any) -> dict[str, dict[str, Any]]:
    """Safely convert a raw value to dict[str, dict[str, Any]]."""
    if isinstance(raw, dict):
        src = cast(dict[str, Any], raw)
        return {str(k): (v if isinstance(v, dict) else {}) for k, v in src.items()}
    return {}


@dataclass(frozen=True, slots=True)
class Scope:
    """Taxonomy binding scope - defines where an agent/skill is available.

    Attributes:
        global_: If True, available system-wide (all taxonomy nodes).
        systems: System names where available.
        stacks: Stack FQTNs where available.
        layers: Layer FQTNs where available.
        layer_types: Layer type names (e.g., app-python) where available.
    """

    global_: bool = True
    systems: tuple[str, ...] = ()
    stacks: tuple[str, ...] = ()
    layers: tuple[str, ...] = ()
    layer_types: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> Scope:
        """Create a Scope from a dictionary."""
        if data is None:
            return cls()
        return cls(
            global_=data.get("global", True),
            systems=tuple(data.get("systems", [])),
            stacks=tuple(data.get("stacks", [])),
            layers=tuple(data.get("layers", [])),
            layer_types=tuple(data.get("layerTypes", [])),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        result: dict[str, Any] = {}
        if not self.global_:
            result["global"] = False
        if self.systems:
            result["systems"] = list(self.systems)
        if self.stacks:
            result["stacks"] = list(self.stacks)
        if self.layers:
            result["layers"] = list(self.layers)
        if self.layer_types:
            result["layerTypes"] = list(self.layer_types)
        return result

    def is_empty(self) -> bool:
        """Return True if scope has no bindings (global only)."""
        return (
            self.global_
            and not self.systems
            and not self.stacks
            and not self.layers
            and not self.layer_types
        )


@dataclass(frozen=True, slots=True)
class Permissions:
    """Tool permission configuration.

    Attributes:
        edit: Permission for file edits.
        bash: Permission for bash commands (level or pattern-based dict).
        webfetch: Permission for URL fetching.
        task: Pattern-based permissions for dispatching to agents.
        skill: Pattern-based permissions for loading skills.
    """

    edit: PermissionLevel | None = None
    bash: PermissionLevel | Mapping[str, PermissionLevel] | None = None
    webfetch: PermissionLevel | None = None
    task: Mapping[str, PermissionLevel] | None = None
    skill: Mapping[str, PermissionLevel] | None = None

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> Permissions:
        """Create Permissions from a dictionary."""
        if data is None:
            return cls()

        bash_raw: object = data.get("bash")
        bash: PermissionLevel | Mapping[str, PermissionLevel] | None = None
        if isinstance(bash_raw, str):
            bash = bash_raw  # type: ignore[assignment]
        elif isinstance(bash_raw, dict):
            bash = {str(k): str(v) for k, v in bash_raw.items()}  # type: ignore[union-attr]

        return cls(
            edit=data.get("edit"),
            bash=bash,
            webfetch=data.get("webfetch"),
            task=data.get("task"),
            skill=data.get("skill"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        result: dict[str, Any] = {}
        if self.edit is not None:
            result["edit"] = self.edit
        if self.bash is not None:
            result["bash"] = dict(self.bash) if isinstance(self.bash, Mapping) else self.bash
        if self.webfetch is not None:
            result["webfetch"] = self.webfetch
        if self.task is not None:
            result["task"] = dict(self.task)
        if self.skill is not None:
            result["skill"] = dict(self.skill)
        return result


@dataclass(frozen=True, slots=True)
class KatalystExtension:
    """Katalyst-specific extension fields.

    Attributes:
        category: Agent/skill category for organization.
        priority: Display priority in listings.
        tags: Tags for filtering and search.
        extra: Additional extension data.
    """

    category: str | None = None
    priority: Literal["low", "medium", "high"] | None = None
    tags: tuple[str, ...] = ()
    extra: Mapping[str, Any] = field(default_factory=lambda: cast(dict[str, Any], {}))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> KatalystExtension:
        """Create KatalystExtension from a dictionary."""
        if data is None:
            return cls()

        # Extract known fields
        category = data.get("category")
        priority = data.get("priority")
        tags = tuple(data.get("tags", []))

        # Collect extra fields
        known_keys = {"category", "priority", "tags"}
        extra: dict[str, Any] = {str(k): v for k, v in data.items() if k not in known_keys}

        return cls(
            category=category,
            priority=priority,
            tags=tags,
            extra=extra,
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        result: dict[str, Any] = {}
        if self.category is not None:
            result["category"] = self.category
        if self.priority is not None:
            result["priority"] = self.priority
        if self.tags:
            result["tags"] = list(self.tags)
        result.update(self.extra)
        return result


@dataclass(slots=True)
class Agent:
    """Agent definition.

    Represents a complete agent definition including frontmatter and prompt content.
    Compatible with OpenCode's agent format while supporting Katalyst extensions.

    Attributes:
        name: Unique identifier (kebab-case).
        description: Trigger description - when to invoke this agent.
        prompt: The markdown prompt content (body of the file).
        mode: Interaction mode (primary, subagent, or all).
        temperature: LLM temperature setting.
        model: Model override in provider/model format.
        max_steps: Maximum agentic iterations.
        hidden: Hide from @ autocomplete menu.
        disabled: Disable this agent entirely.
        tools: Tool availability configuration.
        permission: Permission configuration.
        scope: Taxonomy binding scope.
        metadata: Arbitrary key-value metadata.
        x_katalyst: Katalyst-specific extensions.
        x_opencode: OpenCode-specific extensions.
        x_claude: Claude-specific extensions.
        x_cursor: Cursor-specific extensions.
        source_path: Path to the source file.
        source: Where the agent was loaded from ("local" or "bundled").
    """

    name: str
    description: str
    prompt: str = ""
    mode: AgentMode = "all"
    temperature: float | None = None
    model: str | None = None
    max_steps: int | None = None
    hidden: bool = False
    disabled: bool = False
    tools: dict[str, bool] = field(default_factory=lambda: cast(dict[str, bool], {}))
    permission: Permissions = field(default_factory=Permissions)
    scope: Scope = field(default_factory=Scope)
    metadata: dict[str, str] = field(default_factory=lambda: cast(dict[str, str], {}))
    x_katalyst: KatalystExtension = field(default_factory=KatalystExtension)
    x_opencode: dict[str, Any] = field(default_factory=lambda: cast(dict[str, Any], {}))
    x_claude: dict[str, Any] = field(default_factory=lambda: cast(dict[str, Any], {}))
    x_cursor: dict[str, Any] = field(default_factory=lambda: cast(dict[str, Any], {}))
    source_path: Path | None = None
    source: AgentSource = "local"

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
        prompt: str = "",
        source_path: Path | None = None,
    ) -> Agent:
        """Create an Agent from frontmatter dictionary and prompt content.

        Args:
            data: The frontmatter dictionary.
            prompt: The markdown prompt content.
            source_path: Path to the source file.

        Returns:
            An Agent instance.
        """
        # Derive name from filename if not provided
        name = data.get("name")
        if name is None and source_path is not None:
            name = source_path.stem

        if not name:
            raise ValueError("Agent name is required")

        description = data.get("description", "")
        if not description:
            raise ValueError(f"Agent '{name}' missing required field: description")

        return cls(
            name=name,
            description=description,
            prompt=prompt,
            mode=data.get("mode", "all"),
            temperature=data.get("temperature"),
            model=data.get("model"),
            max_steps=data.get("maxSteps"),
            hidden=data.get("hidden", False),
            disabled=data.get("disable", False),
            tools=_to_dict_str_bool(data.get("tools", {})),
            permission=Permissions.from_dict(data.get("permission")),
            scope=Scope.from_dict(data.get("scope")),
            metadata=_to_dict_str_str(data.get("metadata", {})),
            x_katalyst=KatalystExtension.from_dict(data.get("x-katalyst")),
            x_opencode=_to_dict_str_any(data.get("x-opencode", {})),
            x_claude=_to_dict_str_any(data.get("x-claude", {})),
            x_cursor=_to_dict_str_any(data.get("x-cursor", {})),
            source_path=source_path,
        )

    def to_frontmatter_dict(self) -> dict[str, Any]:
        """Convert to frontmatter dictionary (excludes prompt)."""
        result: dict[str, Any] = {
            "description": self.description,
        }

        # Only include non-default values
        if self.mode != "all":
            result["mode"] = self.mode
        if self.temperature is not None:
            result["temperature"] = self.temperature
        if self.model is not None:
            result["model"] = self.model
        if self.max_steps is not None:
            result["maxSteps"] = self.max_steps
        if self.hidden:
            result["hidden"] = True
        if self.disabled:
            result["disable"] = True
        if self.tools:
            result["tools"] = self.tools
        if perm := self.permission.to_dict():
            result["permission"] = perm
        if scope := self.scope.to_dict():
            result["scope"] = scope
        if self.metadata:
            result["metadata"] = self.metadata
        if katalyst := self.x_katalyst.to_dict():
            result["x-katalyst"] = katalyst
        if self.x_opencode:
            result["x-opencode"] = self.x_opencode
        if self.x_claude:
            result["x-claude"] = self.x_claude
        if self.x_cursor:
            result["x-cursor"] = self.x_cursor

        return result


@dataclass(slots=True)
class Skill:
    """Skill definition.

    Represents a reusable skill package that agents can load on-demand.

    Attributes:
        name: Unique identifier (kebab-case, must match directory name).
        description: Brief description of the skill.
        content: The markdown content of SKILL.md.
        license: License identifier (e.g., MIT).
        compatibility: Compatible tools (opencode, claude, etc.).
        scope: Taxonomy binding scope.
        metadata: Arbitrary key-value metadata.
        x_katalyst: Katalyst-specific extensions.
        x_opencode: OpenCode-specific extensions.
        x_claude: Claude-specific extensions.
        x_cursor: Cursor-specific extensions.
        source_path: Path to the SKILL.md file.
        source: Where the skill was loaded from ("local" or "bundled").
    """

    name: str
    description: str
    content: str = ""
    license: str | None = None
    compatibility: tuple[str, ...] = ()
    scope: Scope = field(default_factory=Scope)
    metadata: dict[str, str] = field(default_factory=lambda: cast(dict[str, str], {}))
    x_katalyst: KatalystExtension = field(default_factory=KatalystExtension)
    x_opencode: dict[str, Any] = field(default_factory=lambda: cast(dict[str, Any], {}))
    x_claude: dict[str, Any] = field(default_factory=lambda: cast(dict[str, Any], {}))
    x_cursor: dict[str, Any] = field(default_factory=lambda: cast(dict[str, Any], {}))
    source_path: Path | None = None
    source: AgentSource = "local"

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
        content: str = "",
        source_path: Path | None = None,
    ) -> Skill:
        """Create a Skill from frontmatter dictionary and content.

        Args:
            data: The frontmatter dictionary.
            content: The markdown content.
            source_path: Path to the SKILL.md file.

        Returns:
            A Skill instance.
        """
        name = data.get("name")
        if not name:
            raise ValueError("Skill name is required")

        description = data.get("description", "")
        if not description:
            raise ValueError(f"Skill '{name}' missing required field: description")

        return cls(
            name=name,
            description=description,
            content=content,
            license=data.get("license"),
            compatibility=tuple(data.get("compatibility", [])),
            scope=Scope.from_dict(data.get("scope")),
            metadata=_to_dict_str_str(data.get("metadata", {})),
            x_katalyst=KatalystExtension.from_dict(data.get("x-katalyst")),
            x_opencode=_to_dict_str_any(data.get("x-opencode", {})),
            x_claude=_to_dict_str_any(data.get("x-claude", {})),
            x_cursor=_to_dict_str_any(data.get("x-cursor", {})),
            source_path=source_path,
        )

    def to_frontmatter_dict(self) -> dict[str, Any]:
        """Convert to frontmatter dictionary (excludes content)."""
        result: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
        }

        if self.license:
            result["license"] = self.license
        if self.compatibility:
            result["compatibility"] = list(self.compatibility)
        if scope := self.scope.to_dict():
            result["scope"] = scope
        if self.metadata:
            result["metadata"] = self.metadata
        if katalyst := self.x_katalyst.to_dict():
            result["x-katalyst"] = katalyst
        if self.x_opencode:
            result["x-opencode"] = self.x_opencode
        if self.x_claude:
            result["x-claude"] = self.x_claude
        if self.x_cursor:
            result["x-cursor"] = self.x_cursor

        return result


@dataclass(frozen=True, slots=True)
class Bindings:
    """Taxonomy bindings configuration.

    Maps agents to taxonomy nodes at various levels.

    Attributes:
        system: Agents available system-wide.
        systems: Agents bound to specific systems (key=system name).
        stacks: Agents bound to stacks (key=stack FQTN).
        layers: Agents bound to layers (key=layer FQTN).
        layer_types: Agents bound to layer types (key=layer type name).
    """

    system: tuple[str, ...] = ()
    systems: Mapping[str, tuple[str, ...]] = field(
        default_factory=lambda: cast(dict[str, tuple[str, ...]], {})
    )
    stacks: Mapping[str, tuple[str, ...]] = field(
        default_factory=lambda: cast(dict[str, tuple[str, ...]], {})
    )
    layers: Mapping[str, tuple[str, ...]] = field(
        default_factory=lambda: cast(dict[str, tuple[str, ...]], {})
    )
    layer_types: Mapping[str, tuple[str, ...]] = field(
        default_factory=lambda: cast(dict[str, tuple[str, ...]], {})
    )

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> Bindings:
        """Create Bindings from a dictionary."""
        if data is None:
            return cls()

        def _to_tuple_dict(raw: Mapping[str, Any] | None) -> dict[str, tuple[str, ...]]:
            if raw is None:
                return {}
            return {k: tuple(v) for k, v in raw.items()}

        return cls(
            system=tuple(data.get("system", [])),
            systems=_to_tuple_dict(data.get("systems")),
            stacks=_to_tuple_dict(data.get("stacks")),
            layers=_to_tuple_dict(data.get("layers")),
            layer_types=_to_tuple_dict(data.get("layerTypes")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        result: dict[str, Any] = {}
        if self.system:
            result["system"] = list(self.system)
        if self.systems:
            result["systems"] = {k: list(v) for k, v in self.systems.items()}
        if self.stacks:
            result["stacks"] = {k: list(v) for k, v in self.stacks.items()}
        if self.layers:
            result["layers"] = {k: list(v) for k, v in self.layers.items()}
        if self.layer_types:
            result["layerTypes"] = {k: list(v) for k, v in self.layer_types.items()}
        return result


@dataclass(frozen=True, slots=True)
class SymlinksConfig:
    """Symlink management configuration.

    Attributes:
        enabled: Whether automatic symlink management is enabled.
        targets: Symlink target directories (key=adapter name, value=path).
    """

    enabled: bool = True
    targets: Mapping[str, str] = field(default_factory=lambda: {"opencode": ".opencode"})

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> SymlinksConfig:
        """Create SymlinksConfig from a dictionary."""
        if data is None:
            return cls()
        return cls(
            enabled=data.get("enabled", True),
            targets=dict(data.get("targets", {"opencode": ".opencode"})),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        result: dict[str, Any] = {}
        if not self.enabled:
            result["enabled"] = False
        if self.targets != {"opencode": ".opencode"}:
            result["targets"] = dict(self.targets)
        return result


@dataclass(slots=True)
class AgentsConfig:
    """Configuration for .agents directory.

    Attributes:
        version: Spec version (always "1").
        tools: Global tool availability defaults.
        permission: Global permission defaults.
        agents: Agent-specific configuration overrides.
        skills: Skill-specific configuration overrides.
        bindings: Taxonomy bindings.
        symlinks: Symlink management configuration.
        adapters: Adapter-specific configuration.
        source_path: Path to the config file.
    """

    version: str = "1"
    tools: dict[str, bool] = field(default_factory=lambda: cast(dict[str, bool], {}))
    permission: Permissions = field(default_factory=Permissions)
    agents: dict[str, dict[str, Any]] = field(
        default_factory=lambda: cast(dict[str, dict[str, Any]], {})
    )
    skills: dict[str, dict[str, Any]] = field(
        default_factory=lambda: cast(dict[str, dict[str, Any]], {})
    )
    bindings: Bindings = field(default_factory=Bindings)
    symlinks: SymlinksConfig = field(default_factory=SymlinksConfig)
    adapters: dict[str, dict[str, Any]] = field(
        default_factory=lambda: cast(dict[str, dict[str, Any]], {})
    )
    source_path: Path | None = None

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
        source_path: Path | None = None,
    ) -> AgentsConfig:
        """Create AgentsConfig from a dictionary.

        Args:
            data: The configuration dictionary.
            source_path: Path to the config file.

        Returns:
            An AgentsConfig instance.
        """
        return cls(
            version=data.get("version", "1"),
            tools=_to_dict_str_bool(data.get("tools", {})),
            permission=Permissions.from_dict(data.get("permission")),
            agents=_to_dict_str_dict(data.get("agents", {})),
            skills=_to_dict_str_dict(data.get("skills", {})),
            bindings=Bindings.from_dict(data.get("bindings")),
            symlinks=SymlinksConfig.from_dict(data.get("symlinks")),
            adapters=_to_dict_str_dict(data.get("adapters", {})),
            source_path=source_path,
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        result: dict[str, Any] = {"version": self.version}

        if self.tools:
            result["tools"] = self.tools
        if perm := self.permission.to_dict():
            result["permission"] = perm
        if self.agents:
            result["agents"] = self.agents
        if self.skills:
            result["skills"] = self.skills
        if bindings := self.bindings.to_dict():
            result["bindings"] = bindings
        if symlinks := self.symlinks.to_dict():
            result["symlinks"] = symlinks
        if self.adapters:
            result["adapters"] = self.adapters

        return result
