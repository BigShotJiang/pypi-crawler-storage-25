"""Symlink management for OpenCode compatibility.

This module manages symlinks from .opencode/ to .agents/, allowing the same
agent and skill files to be read by both systems without duplication.

Directory structure:
    .agents/                    # Canonical (source of truth)
    ├── agents/                 # Agent definitions
    └── skills/                 # Skill packages

    .opencode/                  # Symlinked for OpenCode compatibility
    ├── agents -> ../.agents/agents
    ├── skills -> ../.agents/skills
    ├── package.json            # OpenCode-specific (not symlinked)
    └── plugins/                # OpenCode-specific (not symlinked)
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from loguru import logger

__all__ = [
    "SymlinkError",
    "SymlinkResult",
    "SymlinkStatus",
    "check_symlinks",
    "create_symlinks",
    "remove_symlinks",
]


class SymlinkError(Exception):
    """Error managing symlinks."""

    pass


SymlinkStatus = Literal["ok", "missing", "wrong_target", "not_symlink", "error"]


@dataclass
class SymlinkResult:
    """Result of a symlink operation.

    Attributes:
        name: Name of the symlink (e.g., "agents", "skills").
        link_path: Path where the symlink should be.
        target_path: Path the symlink should point to.
        status: Status of the symlink.
        message: Human-readable status message.
    """

    name: str
    link_path: Path
    target_path: Path
    status: SymlinkStatus
    message: str

    @property
    def is_ok(self) -> bool:
        """Return True if the symlink is correct."""
        return self.status == "ok"


def _relative_target(link_path: Path, target_path: Path) -> Path:
    """Compute the relative path from link to target.

    Args:
        link_path: Path where the symlink will be created.
        target_path: Path the symlink should point to.

    Returns:
        Relative path from link_path's parent to target_path.
    """
    # Both paths should be resolved for accurate relative computation
    link_parent = link_path.parent.resolve()
    target_resolved = target_path.resolve()

    return Path(os.path.relpath(target_resolved, link_parent))


def check_symlinks(
    agents_dir: Path,
    opencode_dir: Path | None = None,
) -> list[SymlinkResult]:
    """Check the status of symlinks from .opencode/ to .agents/.

    Args:
        agents_dir: Path to the .agents/ directory.
        opencode_dir: Path to the .opencode/ directory. Defaults to sibling of agents_dir.

    Returns:
        List of SymlinkResult for each expected symlink.
    """
    if opencode_dir is None:
        opencode_dir = agents_dir.parent / ".opencode"

    results: list[SymlinkResult] = []

    # Define expected symlinks
    symlinks = [
        ("agents", opencode_dir / "agents", agents_dir / "agents"),
        ("skills", opencode_dir / "skills", agents_dir / "skills"),
    ]

    for name, link_path, target_path in symlinks:
        result = _check_single_symlink(name, link_path, target_path)
        results.append(result)

    return results


def _check_single_symlink(name: str, link_path: Path, target_path: Path) -> SymlinkResult:
    """Check a single symlink."""
    try:
        if not link_path.exists() and not link_path.is_symlink():
            return SymlinkResult(
                name=name,
                link_path=link_path,
                target_path=target_path,
                status="missing",
                message=f"Symlink does not exist: {link_path}",
            )

        if not link_path.is_symlink():
            return SymlinkResult(
                name=name,
                link_path=link_path,
                target_path=target_path,
                status="not_symlink",
                message=f"Path exists but is not a symlink: {link_path}",
            )

        # Check if symlink points to correct target
        actual_target = link_path.resolve()
        expected_target = target_path.resolve()

        if actual_target != expected_target:
            return SymlinkResult(
                name=name,
                link_path=link_path,
                target_path=target_path,
                status="wrong_target",
                message=f"Symlink points to {actual_target}, expected {expected_target}",
            )

        return SymlinkResult(
            name=name,
            link_path=link_path,
            target_path=target_path,
            status="ok",
            message="Symlink is correct",
        )

    except OSError as e:
        return SymlinkResult(
            name=name,
            link_path=link_path,
            target_path=target_path,
            status="error",
            message=f"Error checking symlink: {e}",
        )


def create_symlinks(
    agents_dir: Path,
    opencode_dir: Path | None = None,
    force: bool = False,
) -> list[SymlinkResult]:
    """Create symlinks from .opencode/ to .agents/.

    Args:
        agents_dir: Path to the .agents/ directory.
        opencode_dir: Path to the .opencode/ directory. Defaults to sibling of agents_dir.
        force: If True, replace existing files/symlinks with wrong targets.

    Returns:
        List of SymlinkResult for each symlink operation.
    """
    if opencode_dir is None:
        opencode_dir = agents_dir.parent / ".opencode"

    results: list[SymlinkResult] = []

    # Ensure .opencode directory exists
    opencode_dir.mkdir(parents=True, exist_ok=True)

    # Define symlinks to create
    symlinks = [
        ("agents", opencode_dir / "agents", agents_dir / "agents"),
        ("skills", opencode_dir / "skills", agents_dir / "skills"),
    ]

    for name, link_path, target_path in symlinks:
        result = _create_single_symlink(name, link_path, target_path, force=force)
        results.append(result)

    return results


def _create_single_symlink(
    name: str,
    link_path: Path,
    target_path: Path,
    force: bool = False,
) -> SymlinkResult:
    """Create a single symlink."""
    try:
        # Check if target exists
        if not target_path.exists():
            # Create target directory if it doesn't exist
            target_path.mkdir(parents=True, exist_ok=True)
            logger.debug(f"Created target directory: {target_path}")

        # Check current state
        if link_path.exists() or link_path.is_symlink():
            if link_path.is_symlink():
                actual_target = link_path.resolve()
                expected_target = target_path.resolve()

                if actual_target == expected_target:
                    return SymlinkResult(
                        name=name,
                        link_path=link_path,
                        target_path=target_path,
                        status="ok",
                        message="Symlink already exists and is correct",
                    )

                if force:
                    link_path.unlink()
                    logger.debug(f"Removed existing symlink: {link_path}")
                else:
                    return SymlinkResult(
                        name=name,
                        link_path=link_path,
                        target_path=target_path,
                        status="wrong_target",
                        message="Symlink exists with wrong target. Use force=True to replace.",
                    )
            else:
                if force:
                    # It's a file or directory, not a symlink
                    if link_path.is_dir():
                        import shutil

                        shutil.rmtree(link_path)
                    else:
                        link_path.unlink()
                    logger.debug(f"Removed existing path: {link_path}")
                else:
                    return SymlinkResult(
                        name=name,
                        link_path=link_path,
                        target_path=target_path,
                        status="not_symlink",
                        message="Path exists and is not a symlink. Use force=True to replace.",
                    )

        # Create the symlink with relative path
        relative_target = _relative_target(link_path, target_path)
        link_path.symlink_to(relative_target)
        logger.info(f"Created symlink: {link_path} -> {relative_target}")

        return SymlinkResult(
            name=name,
            link_path=link_path,
            target_path=target_path,
            status="ok",
            message=f"Created symlink: {link_path} -> {relative_target}",
        )

    except OSError as e:
        logger.error(f"Failed to create symlink {link_path}: {e}")
        return SymlinkResult(
            name=name,
            link_path=link_path,
            target_path=target_path,
            status="error",
            message=f"Failed to create symlink: {e}",
        )


def remove_symlinks(
    agents_dir: Path,
    opencode_dir: Path | None = None,
) -> list[SymlinkResult]:
    """Remove symlinks from .opencode/ that point to .agents/.

    Args:
        agents_dir: Path to the .agents/ directory.
        opencode_dir: Path to the .opencode/ directory. Defaults to sibling of agents_dir.

    Returns:
        List of SymlinkResult for each removal operation.
    """
    if opencode_dir is None:
        opencode_dir = agents_dir.parent / ".opencode"

    results: list[SymlinkResult] = []

    # Define symlinks to remove
    symlinks = [
        ("agents", opencode_dir / "agents", agents_dir / "agents"),
        ("skills", opencode_dir / "skills", agents_dir / "skills"),
    ]

    for name, link_path, target_path in symlinks:
        result = _remove_single_symlink(name, link_path, target_path)
        results.append(result)

    return results


def _remove_single_symlink(name: str, link_path: Path, target_path: Path) -> SymlinkResult:
    """Remove a single symlink."""
    try:
        if not link_path.exists() and not link_path.is_symlink():
            return SymlinkResult(
                name=name,
                link_path=link_path,
                target_path=target_path,
                status="missing",
                message="Symlink does not exist",
            )

        if not link_path.is_symlink():
            return SymlinkResult(
                name=name,
                link_path=link_path,
                target_path=target_path,
                status="not_symlink",
                message="Path is not a symlink, not removing",
            )

        link_path.unlink()
        logger.info(f"Removed symlink: {link_path}")

        return SymlinkResult(
            name=name,
            link_path=link_path,
            target_path=target_path,
            status="ok",
            message=f"Removed symlink: {link_path}",
        )

    except OSError as e:
        logger.error(f"Failed to remove symlink {link_path}: {e}")
        return SymlinkResult(
            name=name,
            link_path=link_path,
            target_path=target_path,
            status="error",
            message=f"Failed to remove symlink: {e}",
        )
