"""Data models for client responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping


def _empty_str_mapping() -> dict[str, str]:
    """Typed factory for empty str->str dict."""
    return {}


@dataclass(frozen=True)
class NodeMetadata:
    """Metadata for a taxonomy node."""

    name: str
    labels: Mapping[str, str] = field(default_factory=_empty_str_mapping)


@dataclass(frozen=True)
class NodeSpec:
    """Specification for a taxonomy node."""

    description: str | None = None
    owners: tuple[str, ...] = ()
    environments: tuple[str, ...] = ()
    annotations: Mapping[str, str] = field(default_factory=_empty_str_mapping)
    parents: Mapping[str, str] | None = None
    depends_on: Mapping[str, Any] | None = None


@dataclass(frozen=True)
class NodeResponse:
    """Response for a single taxonomy node."""

    api_version: str
    kind: str
    taxonomy_node_type: str
    metadata: NodeMetadata
    spec: NodeSpec
    source_path: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NodeResponse:
        """Create from API response dict."""
        metadata_data = data.get("metadata", {})
        spec_data = data.get("spec", {})

        metadata = NodeMetadata(
            name=metadata_data.get("name", ""),
            labels=metadata_data.get("labels", {}),
        )
        spec = NodeSpec(
            description=spec_data.get("description"),
            owners=tuple(spec_data.get("owners", [])),
            environments=tuple(spec_data.get("environments", [])),
            annotations=spec_data.get("annotations", {}),
            parents=spec_data.get("parents"),
            depends_on=spec_data.get("dependsOn"),
        )
        return cls(
            api_version=data.get("apiVersion", ""),
            kind=data.get("kind", ""),
            taxonomy_node_type=data.get("taxonomyNodeType", ""),
            metadata=metadata,
            spec=spec,
            source_path=data.get("sourcePath"),
        )


@dataclass(frozen=True)
class EnvironmentResponse:
    """Response for an environment."""

    name: str
    description: str | None
    template_replacements: Mapping[str, str]
    layer_templates: Mapping[str, Mapping[str, Any]]
    source_path: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EnvironmentResponse:
        """Create from API response dict."""
        return cls(
            name=data.get("name", ""),
            description=data.get("description"),
            template_replacements=data.get("templateReplacements", {}),
            layer_templates=data.get("layerTemplates", {}),
            source_path=data.get("sourcePath"),
        )


@dataclass(frozen=True)
class ErrorResponse:
    """Response for a document error."""

    message: str
    path: str | None = None
    document_index: int | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ErrorResponse:
        """Create from API response dict."""
        return cls(
            message=data.get("message", ""),
            path=data.get("path"),
            document_index=data.get("documentIndex"),
        )


@dataclass(frozen=True)
class TaxonomyResponse:
    """Response for full taxonomy."""

    documents: tuple[NodeResponse, ...]
    environments: tuple[EnvironmentResponse, ...]
    qualified_names: Mapping[str, str]
    errors: tuple[ErrorResponse, ...] = ()
    error_count: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaxonomyResponse:
        """Create from API response dict."""
        documents = tuple(NodeResponse.from_dict(d) for d in data.get("documents", []))
        environments = tuple(EnvironmentResponse.from_dict(e) for e in data.get("environments", []))
        errors = tuple(ErrorResponse.from_dict(e) for e in data.get("errors", []))
        return cls(
            documents=documents,
            environments=environments,
            qualified_names=data.get("qualified_names", {}),
            errors=errors,
            error_count=data.get("error_count", 0),
        )


@dataclass
class CreateNodeRequest:
    """Request to create a new node."""

    node_type: str
    name: str
    description: str = ""
    owners: list[str] = field(default_factory=lambda: ["team@example.com"])
    environments: list[str] = field(default_factory=lambda: ["dev"])
    parent: str | None = None
    parent_system: str | None = None
    layer_type: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API request dict."""
        result: dict[str, Any] = {
            "node_type": self.node_type,
            "name": self.name,
            "description": self.description,
            "owners": self.owners,
            "environments": self.environments,
        }
        if self.parent:
            result["parent"] = self.parent
        if self.parent_system:
            result["parent_system"] = self.parent_system
        if self.layer_type:
            result["layer_type"] = self.layer_type
        return result


@dataclass(frozen=True)
class CreateNodeResponse:
    """Response from node creation."""

    success: bool
    path: str | None = None
    error: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CreateNodeResponse:
        """Create from API response dict."""
        return cls(
            success=data.get("success", False),
            path=data.get("path"),
            error=data.get("error"),
        )
