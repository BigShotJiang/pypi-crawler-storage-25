"""FastMCP server instance and lifespan management."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from katalyst_taxonomy.adapters.filesystem import FilesystemBackend
from katalyst_taxonomy.domain.events import EventBus
from katalyst_taxonomy.services.taxonomy import TaxonomyService


@dataclass
class AppContext:
    """Application context available to all MCP tools via lifespan."""

    base_path: Path
    backend: FilesystemBackend
    event_bus: EventBus

    def load_taxonomy(self) -> TaxonomyService:
        """Load the taxonomy service from the backend."""
        documents = self.backend.load_documents()
        environments = self.backend.load_environments()
        errors = self.backend.errors()
        return TaxonomyService(
            documents=documents,
            environments=environments,
            errors=errors,
        )

    # Backward compatibility — some MCP tools reference ctx.repository
    @property
    def repository(self) -> FilesystemBackend:
        return self.backend


def _build_lifespan(
    base_path: Path,
):  # type: ignore[no-untyped-def]
    """Build a lifespan context manager bound to the given base_path."""

    @asynccontextmanager
    async def lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
        repo = FilesystemBackend(base_path=base_path)
        event_bus = EventBus()
        ctx = AppContext(
            base_path=base_path,
            backend=repo,
            event_bus=event_bus,
        )
        # Make context available to resources (which can't take Context params)
        from katalyst_taxonomy.mcp.resources import set_app_ctx

        set_app_ctx(ctx)
        yield ctx

    return lifespan


def create_mcp_server(base_path: Path | None = None) -> FastMCP:
    """Create and configure the MCP server with all tools, resources, and prompts.

    Args:
        base_path: Root of the taxonomy repository. Defaults to CWD.

    Returns:
        A fully configured FastMCP instance.
    """
    resolved_path = (base_path or Path.cwd()).resolve()

    mcp = FastMCP(
        "katalyst-taxonomy",
        instructions=(
            "Katalyst Taxonomy MCP server. Provides tools to discover, query, "
            "and manipulate a software architecture taxonomy. Use taxonomy_tree "
            "or taxonomy_list to explore the structure, taxonomy_get to fetch a "
            "specific node, and taxonomy_create to add new nodes."
        ),
        lifespan=_build_lifespan(resolved_path),
    )

    # Register all tool groups
    from katalyst_taxonomy.mcp.tools.agents import register_agents_tools
    from katalyst_taxonomy.mcp.tools.cicd import register_cicd_tools
    from katalyst_taxonomy.mcp.tools.engine import register_engine_tools
    from katalyst_taxonomy.mcp.tools.hooks import register_hooks_tools
    from katalyst_taxonomy.mcp.tools.lifecycle import register_lifecycle_tools
    from katalyst_taxonomy.mcp.tools.taxonomy import register_taxonomy_tools

    register_taxonomy_tools(mcp)
    register_lifecycle_tools(mcp)
    register_agents_tools(mcp)
    register_hooks_tools(mcp)
    register_cicd_tools(mcp)
    register_engine_tools(mcp)

    # Register resources and prompts
    from katalyst_taxonomy.mcp.prompts import register_prompts
    from katalyst_taxonomy.mcp.resources import register_resources

    register_resources(mcp)
    register_prompts(mcp)

    return mcp
