"""Read-only MCP resources for taxonomy data."""

from __future__ import annotations

import json

from mcp.server.fastmcp import FastMCP

from katalyst_taxonomy.mcp.server import AppContext

# Module-level reference set during lifespan startup.
# Resources can't receive Context params for non-template URIs in FastMCP,
# so we use this holder as a workaround.
_app_ctx_holder: list[AppContext] = []


def set_app_ctx(ctx: AppContext) -> None:
    """Store the app context for resource access."""
    _app_ctx_holder.clear()
    _app_ctx_holder.append(ctx)


def _get_app_ctx() -> AppContext | None:
    """Get the stored app context, if any."""
    return _app_ctx_holder[0] if _app_ctx_holder else None


def register_resources(mcp: FastMCP) -> None:
    """Register read-only resources on the MCP server."""

    @mcp.resource("taxonomy://node/{name}")
    def taxonomy_node_resource(name: str) -> str:
        """Single taxonomy node document as JSON."""
        app = _get_app_ctx()
        if app is None:
            return json.dumps({"error": "Server not initialized."})

        from katalyst_taxonomy.services.serialization import serialize_document

        service = app.load_taxonomy()
        doc = service.get_document_by_name(name)
        if doc is None:
            return json.dumps({"error": f"Node '{name}' not found."})

        payload = serialize_document(doc, service, app.base_path)
        return json.dumps(payload, indent=2)

    @mcp.resource("taxonomy://tree")
    def taxonomy_tree_resource() -> str:
        """Full taxonomy tree in text format."""
        app = _get_app_ctx()
        if app is None:
            return "Server not initialized."

        from katalyst_taxonomy.services.serialization import build_tree_lines

        service = app.load_taxonomy()
        if not service.documents:
            return "No taxonomy documents found."

        return "\n".join(build_tree_lines(service))

    @mcp.resource("taxonomy://environments")
    def taxonomy_environments_resource() -> str:
        """Environment configurations as JSON."""
        app = _get_app_ctx()
        if app is None:
            return json.dumps([])

        from katalyst_taxonomy.services.serialization import serialize_environment

        repo = app.backend
        environments = repo.load_environments()

        data = [serialize_environment(env) for env in environments]
        return json.dumps(data, indent=2)

    @mcp.resource("taxonomy://registry")
    def taxonomy_registry_resource() -> str:
        """Node type registry metadata as JSON."""
        from katalyst_taxonomy.engine.bridge import get_default_registry

        registry = get_default_registry()
        data: list[dict[str, object]] = []
        for kind in registry.all_kinds():
            desc = registry.get(kind)
            if desc is None:
                continue
            data.append(
                {
                    "kind": desc.kind,
                    "wing": desc.wing,
                    "displayOrder": desc.display_order,
                    "directoryName": desc.directory_name,
                    "parentTypes": list(desc.parent_types) if desc.parent_types else None,
                    "isLeaf": desc.is_leaf,
                    "isRoot": desc.is_root,
                    "isExtension": desc.is_extension,
                }
            )

        return json.dumps(data, indent=2)

    @mcp.resource("taxonomy://status")
    def taxonomy_status_resource() -> str:
        """Installed components and versions."""
        app = _get_app_ctx()
        if app is None:
            return "Server not initialized."

        from katalyst_taxonomy.services.status import StatusCode, get_status

        result = get_status(app.base_path)

        if result.status == StatusCode.NOT_INITIALIZED:
            return f"No Katalyst lock file found.\nExpected: {result.lock_file_path}"

        if result.status == StatusCode.ERROR:
            return f"Error reading lock file: {result.error}"

        lock = result.lock
        assert lock is not None
        return (
            f"Katalyst Taxonomy Status\n"
            f"  Version: {lock.installed.core.version}\n"
            f"  Schema: {lock.installed.core.schema_version}\n"
            f"  Source: {lock.installed.core.source}"
        )

    @mcp.resource("taxonomy://agents")
    def taxonomy_agents_resource() -> str:
        """Agent definitions list as JSON."""
        app = _get_app_ctx()
        if app is None:
            return json.dumps({"agents": [], "skills": [], "error": "Server not initialized."})

        from katalyst_taxonomy.agents.discovery import (
            discover_agents_directory,
            scan_agents_directory,
        )

        agents_dir = discover_agents_directory(app.base_path)
        if not agents_dir:
            return json.dumps({"agents": [], "skills": [], "error": "No .agents/ directory found."})

        directory = scan_agents_directory(agents_dir)
        data = {
            "path": str(directory.path),
            "agents": [
                {
                    "name": a.name,
                    "description": a.description,
                    "mode": a.mode,
                    "source": a.source,
                }
                for a in directory.agents
            ],
            "skills": [
                {"name": s.name, "description": s.description, "source": s.source}
                for s in directory.skills
            ],
        }
        return json.dumps(data, indent=2)

    _ = taxonomy_node_resource
    _ = taxonomy_tree_resource
    _ = taxonomy_environments_resource
    _ = taxonomy_registry_resource
    _ = taxonomy_status_resource
    _ = taxonomy_agents_resource
