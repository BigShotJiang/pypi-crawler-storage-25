"""MCP (Model Context Protocol) server adapter for katalyst-taxonomy.

This package exposes taxonomy operations as MCP tools, resources, and prompts
so AI coding assistants can discover, query, and manipulate taxonomy data.
"""

from __future__ import annotations

from katalyst_taxonomy.mcp.server import create_mcp_server

__all__ = ["create_mcp_server"]
