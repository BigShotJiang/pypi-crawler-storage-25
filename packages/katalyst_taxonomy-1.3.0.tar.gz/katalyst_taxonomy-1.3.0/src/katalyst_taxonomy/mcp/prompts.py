"""MCP prompt templates for interactive taxonomy operations."""

from mcp.server.fastmcp import FastMCP


def register_prompts(mcp: FastMCP) -> None:
    """Register prompt templates on the MCP server."""

    @mcp.prompt()
    def create_node(node_type: str, name: str) -> str:
        """Interactive node creation wizard with type-specific guidance.

        Args:
            node_type: The type of taxonomy node to create (e.g., system, stack, layer).
            name: The name for the new node.
        """
        type_guidance = {
            "system": (
                "A system is a top-level organizational unit in the taxonomy. "
                "It groups related stacks and layers that form a coherent platform.\n\n"
                "Required fields:\n"
                "- description: What this system represents\n"
                "- owners: Team email addresses responsible for this system\n"
                "- environments: Which environments this system deploys to (e.g., dev, staging, prod)"
            ),
            "stack": (
                "A stack is a logical grouping of layers within a system. "
                "It represents a deployable unit or service boundary.\n\n"
                "Required fields:\n"
                "- parent: The system this stack belongs to\n"
                "- description: What this stack does\n"
                "- owners: Team email addresses\n"
                "- environments: Deployment environments"
            ),
            "layer": (
                "A layer is the lowest-level building block in the taxonomy. "
                "It represents a specific workload type (Docker app, Terraform infra, etc.).\n\n"
                "Required fields:\n"
                "- parent: The stack this layer belongs to\n"
                "- layer_type: The workload type (e.g., app-docker, infra-terraform)\n"
                "- description: What this layer does\n"
                "- owners: Team email addresses\n"
                "- environments: Deployment environments"
            ),
        }

        guidance = type_guidance.get(
            node_type,
            f"Creating a '{node_type}' node. Check the registry for required fields.",
        )

        return (
            f"I need to create a new {node_type} node named '{name}' in the taxonomy.\n\n"
            f"{guidance}\n\n"
            f"Please use the taxonomy_create tool to create this node. "
            f"Ask me for any missing required fields before proceeding."
        )

    @mcp.prompt()
    def explain_taxonomy() -> str:
        """Explain the taxonomy structure for the current repository.

        Provides context about what the taxonomy contains and how it's organized.
        """
        return (
            "Please explain the taxonomy structure of this repository. "
            "Start by using the taxonomy_tree tool to show the hierarchy, "
            "then use taxonomy_status to show installed components. "
            "Summarize:\n"
            "1. How many systems, stacks, and layers exist\n"
            "2. What environments are configured\n"
            "3. The overall architecture the taxonomy describes\n"
            "4. Any notable patterns (shared libraries, extensions, etc.)"
        )

    @mcp.prompt()
    def suggest_layer_type(workload_description: str) -> str:
        """Recommend a layer type based on a workload description.

        Args:
            workload_description: A description of the workload or service to model.
        """
        return (
            f"Based on this workload description: '{workload_description}'\n\n"
            "Please recommend an appropriate layer type. First, use the taxonomy_status "
            "tool to see what layer types are already installed. Then suggest the best "
            "match, explaining:\n"
            "1. Which layer type fits best and why\n"
            "2. What directory structure it will create\n"
            "3. What actions (build, deploy, test) are available for it\n"
            "4. If no existing type fits, suggest creating a custom one"
        )

    _ = create_node
    _ = explain_taxonomy
    _ = suggest_layer_type
