"""Lifecycle tools — init, upgrade, rollback, add, remove."""

from pathlib import Path

from mcp.server.fastmcp import Context, FastMCP

from katalyst_taxonomy.mcp.server import AppContext


def _get_ctx(ctx: Context) -> AppContext:  # type: ignore[type-arg]
    """Extract the AppContext from the MCP context."""
    return ctx.request_context.lifespan_context  # type: ignore[union-attr,return-value]


def register_lifecycle_tools(mcp: FastMCP) -> None:
    """Register lifecycle management tools on the MCP server."""

    @mcp.tool()
    def taxonomy_init(
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Initialize a new taxonomy repository at the given path.

        Args:
            path: Path to initialize. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.adapters.init.prompt import NonInteractivePrompt
        from katalyst_taxonomy.ports.filesystem import RealFilesystem
        from katalyst_taxonomy.services.init import InitConfig, InitService, InitStatus
        from katalyst_taxonomy.templates.sources import create_source

        service = InitService(
            prompt=NonInteractivePrompt(),
            filesystem=RealFilesystem(),
            template_source=create_source("bundled"),
        )
        config = InitConfig(target_path=base)
        result = service.initialize(config)

        if result.status == InitStatus.SUCCESS:
            return "Taxonomy initialized successfully."
        elif result.status == InitStatus.ALREADY_INITIALIZED:
            return "Taxonomy already initialized."
        return f"Error: {result.error}"

    @mcp.tool()
    def taxonomy_upgrade(
        check_only: bool = False,
        dry_run: bool = False,
        item: str | None = None,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Upgrade installed taxonomy components to the latest version.

        Args:
            check_only: Only check for available updates without applying them.
            dry_run: Show what would change without making modifications.
            item: Specific item to upgrade (e.g., "app-docker"). Omit to upgrade all.
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.adapters.filesystem.lock import LockFileRepository
        from katalyst_taxonomy.ports.filesystem import RealFilesystem
        from katalyst_taxonomy.services.upgrade import UpgradeConfig, UpgradeService, UpgradeStatus
        from katalyst_taxonomy.templates.sources import create_source

        service = UpgradeService(
            lock_repository=LockFileRepository(base_path=base),
            template_source=create_source("bundled"),
            filesystem=RealFilesystem(),
        )

        config = UpgradeConfig(
            target_path=base,
            items=(item,) if item else (),
            dry_run=dry_run or check_only,
        )

        if check_only:
            result = service.check_updates(config)
        else:
            result = service.upgrade(config)

        if result.status == UpgradeStatus.UPDATES_AVAILABLE:
            lines = ["Updates available:"]
            for u in result.updates:
                lines.append(f"  {u.name}: {u.from_version} -> {u.to_version}")
            return "\n".join(lines)
        elif result.status == UpgradeStatus.SUCCESS:
            return "Upgrade complete."
        elif result.status == UpgradeStatus.UP_TO_DATE:
            return "Everything is up to date."
        return f"Error: {result.error}"

    @mcp.tool()
    def taxonomy_rollback(
        list_backups: bool = False,
        backup_name: str | None = None,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Rollback or list taxonomy backups.

        Args:
            list_backups: If true, list available backups instead of restoring.
            backup_name: Specific backup to restore. If omitted, restores the latest.
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.adapters.filesystem.lock import LockFileRepository
        from katalyst_taxonomy.services.rollback import (
            RollbackConfig,
            RollbackService,
            RollbackStatus,
        )

        service = RollbackService(
            lock_repository=LockFileRepository(base_path=base),
        )

        config = RollbackConfig(
            target_path=base,
            backup_name=backup_name,
        )

        if list_backups:
            result = service.list_backups(config)
            if not result.backups:
                return "No backups available."
            lines = ["Available backups:"]
            for b in result.backups:
                lines.append(f"  {b.name} ({b.timestamp})")
            return "\n".join(lines)

        result = service.rollback(config)
        if result.status == RollbackStatus.SUCCESS:
            return "Rollback complete."
        return f"Error: {result.error}"

    @mcp.tool()
    def taxonomy_add(
        plugin: str | None = None,
        layer_type: str | None = None,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Add a plugin or layer type to the taxonomy.

        Args:
            plugin: Name of the plugin to add.
            layer_type: Name of the layer type to add.
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        if not plugin and not layer_type:
            return "Error: specify either 'plugin' or 'layer_type'."

        from katalyst_taxonomy.services.add import (
            AddConfig,
            AddService,
            AddStatus,
            RealAddFilesystem,
        )
        from katalyst_taxonomy.templates.sources import create_source

        service = AddService(
            filesystem=RealAddFilesystem(),
            template_source=create_source("bundled"),
        )
        config = AddConfig(
            target_path=base,
            plugins=(plugin,) if plugin else (),
            layer_types=(layer_type,) if layer_type else (),
            force=False,
        )

        result = service.add(config)
        if result.status == AddStatus.SUCCESS:
            return "Added successfully."
        return f"Error: {result.error}"

    @mcp.tool()
    def taxonomy_remove(
        plugin: str | None = None,
        layer_type: str | None = None,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Remove a plugin or layer type from the taxonomy.

        Args:
            plugin: Name of the plugin to remove.
            layer_type: Name of the layer type to remove.
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        if not plugin and not layer_type:
            return "Error: specify either 'plugin' or 'layer_type'."

        from katalyst_taxonomy.services.remove import (
            RealRemoveFilesystem,
            RemoveConfig,
            RemoveService,
            RemoveStatus,
        )

        service = RemoveService(filesystem=RealRemoveFilesystem())
        config = RemoveConfig(
            target_path=base,
            plugins=(plugin,) if plugin else (),
            layer_types=(layer_type,) if layer_type else (),
        )

        result = service.remove(config)
        if result.status == RemoveStatus.SUCCESS:
            return "Removed successfully."
        return f"Error: {result.error}"

    _ = taxonomy_init
    _ = taxonomy_upgrade
    _ = taxonomy_rollback
    _ = taxonomy_add
    _ = taxonomy_remove
