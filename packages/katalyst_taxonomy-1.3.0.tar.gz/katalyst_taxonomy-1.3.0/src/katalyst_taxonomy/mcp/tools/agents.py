"""Agent management tools — init, list, show, validate, sync, create, generate."""

import json
from pathlib import Path

from mcp.server.fastmcp import Context, FastMCP

from katalyst_taxonomy.mcp.server import AppContext


def _get_ctx(ctx: Context) -> AppContext:  # type: ignore[type-arg]
    """Extract the AppContext from the MCP context."""
    return ctx.request_context.lifespan_context  # type: ignore[union-attr,return-value]


def register_agents_tools(mcp: FastMCP) -> None:
    """Register agent management tools on the MCP server."""

    @mcp.tool()
    def agents_init(
        force: bool = False,
        no_seed: bool = False,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Initialize the .agents/ directory with bundled agents and skills.

        Args:
            force: If true, overwrite existing files and symlinks.
            no_seed: If true, skip seeding bundled agents/skills.
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.agents import agents_init as do_init

        result = do_init(base, force=force, no_seed=no_seed)

        if not result.success:
            return f"Error: {result.error}"

        if result.already_existed:
            return (
                f"Agents directory already initialized at {result.agents_dir}.\n"
                f"  Agents: {result.agents_seeded}, Skills: {result.skills_seeded}\n"
                "Use --force to reinitialize."
            )

        lines = ["Agents directory initialized."]
        if result.agents_seeded:
            lines.append(f"  Seeded {result.agents_seeded} agent(s)")
        if result.skills_seeded:
            lines.append(f"  Seeded {result.skills_seeded} skill(s)")
        if result.symlink_errors:
            lines.append(f"  Warning: {len(result.symlink_errors)} symlink error(s)")
        return "\n".join(lines)

    @mcp.tool()
    def agents_list(
        output_format: str = "json",
        layer_type: str | None = None,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """List all agents and skills in the .agents/ directory.

        Args:
            output_format: Output format — "json" or "table".
            layer_type: Filter results to agents/skills matching this layer type.
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.agents import AgentsNotFoundError
        from katalyst_taxonomy.services.agents import agents_list as do_list

        try:
            directory = do_list(base, layer_type=layer_type)
        except AgentsNotFoundError as e:
            return f"Error: {e}"

        data = {
            "path": str(directory.path),
            "agents": [
                {"name": a.name, "description": a.description, "mode": a.mode, "source": a.source}
                for a in directory.agents
            ],
            "skills": [
                {"name": s.name, "description": s.description, "source": s.source}
                for s in directory.skills
            ],
            "errors": [str(e) for e in directory.errors],
        }
        return json.dumps(data, indent=2)

    @mcp.tool()
    def agents_show(
        name: str,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Show details of a specific agent or skill.

        Args:
            name: Name of the agent or skill to show.
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.agents import AgentsNotFoundError
        from katalyst_taxonomy.services.agents import agents_show as do_show

        try:
            result = do_show(base, name)
        except AgentsNotFoundError as e:
            return f"Error: {e}"

        if result.agent:
            data = {
                "type": "agent",
                "name": result.agent.name,
                "description": result.agent.description,
                "mode": result.agent.mode,
                "source": result.agent.source,
                "tools": result.agent.tools,
                "scope": result.agent.scope.to_dict(),
            }
            return json.dumps(data, indent=2)

        if result.skill:
            data = {
                "type": "skill",
                "name": result.skill.name,
                "description": result.skill.description,
                "source": result.skill.source,
            }
            return json.dumps(data, indent=2)

        return f"Agent or skill '{name}' not found.\nAvailable: {', '.join(result.available_agents + result.available_skills)}"

    @mcp.tool()
    def agents_validate(
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Validate all agent definitions in the .agents/ directory.

        Args:
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.agents import AgentsNotFoundError
        from katalyst_taxonomy.services.agents import agents_validate as do_validate

        try:
            result = do_validate(base)
        except AgentsNotFoundError as e:
            return f"Error: {e}"

        if result.is_valid:
            return (
                f"Validated {result.agents_checked} agent(s) and "
                f"{result.skills_checked} skill(s). No errors found."
            )

        lines = [f"Found {len(result.errors)} error(s):"]
        for error in result.errors:
            lines.append(f"  - {error}")
        return "\n".join(lines)

    @mcp.tool()
    def agents_sync(
        force: bool = False,
        dry_run: bool = False,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Sync bundled agents and skills into the local .agents/ directory.

        Args:
            force: If true, overwrite existing files with bundled versions.
            dry_run: If true, show what would be done without making changes.
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.agents import AgentsNotFoundError
        from katalyst_taxonomy.services.agents import agents_sync as do_sync

        try:
            result = do_sync(base, force=force)
        except AgentsNotFoundError as e:
            return f"Error: {e}"

        if result.total_copied == 0:
            return "Everything is up to date."

        lines = [f"Synced {result.total_copied} item(s)."]
        if result.agents_copied:
            lines.append(f"  Agents: {', '.join(result.agents_copied)}")
        if result.skills_copied:
            lines.append(f"  Skills: {', '.join(result.skills_copied)}")
        return "\n".join(lines)

    @mcp.tool()
    def agents_create(
        name: str,
        description: str,
        mode: str = "all",
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Create a new agent definition file.

        Args:
            name: Agent name (kebab-case, e.g., "my-agent").
            description: A description of when to use this agent.
            mode: Interaction mode — "primary", "subagent", or "all".
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.agents import AgentsNotFoundError
        from katalyst_taxonomy.services.agents import agents_create as do_create

        try:
            result = do_create(base, name, description, mode=mode)
        except AgentsNotFoundError as e:
            return f"Error: {e}"

        if result.success:
            return f"Created agent '{name}' at {result.agent_path}"
        return f"Error: {result.error}"

    @mcp.tool()
    def agents_generate(
        template: str = "layer-helper",
        layer_type: str | None = None,
        all_layer_types: bool = False,
        list_templates: bool = False,
        force: bool = False,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Generate agents from templates, optionally bound to layer types.

        Args:
            template: Template name (e.g., "layer-helper", "code-reviewer", "debugger").
            layer_type: Specific layer type to generate for.
            all_layer_types: If true, generate for all discovered layer types.
            list_templates: If true, list available templates and return.
            force: If true, overwrite existing agent files.
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.agents import AgentsNotFoundError
        from katalyst_taxonomy.services.agents import agents_generate as do_generate

        try:
            result = do_generate(
                base,
                template=template,
                layer_type=layer_type,
                all_layer_types=all_layer_types,
                list_templates=list_templates,
                force=force,
            )
        except AgentsNotFoundError as e:
            return f"Error: {e}"

        if result.available_templates is not None and list_templates:
            return "Available templates:\n" + "\n".join(
                f"  - {t}" for t in result.available_templates
            )

        if result.errors:
            return "Errors:\n" + "\n".join(f"  - {e}" for e in result.errors)

        lines: list[str] = []
        if result.created:
            lines.append(f"Generated {len(result.created)} agent(s): {', '.join(result.created)}")
        if result.skipped:
            lines.append(f"Skipped {len(result.skipped)} existing (use force to overwrite)")
        return "\n".join(lines) or "No agents generated."

    _ = agents_init
    _ = agents_list
    _ = agents_show
    _ = agents_validate
    _ = agents_sync
    _ = agents_create
    _ = agents_generate
