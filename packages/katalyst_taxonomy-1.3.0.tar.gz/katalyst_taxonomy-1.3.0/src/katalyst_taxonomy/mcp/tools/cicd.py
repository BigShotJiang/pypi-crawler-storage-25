"""CICD template tools — workflows, jobs, stages, validate, render."""

import json
from pathlib import Path

from mcp.server.fastmcp import Context, FastMCP

from katalyst_taxonomy.mcp.server import AppContext


def _get_ctx(ctx: Context) -> AppContext:  # type: ignore[type-arg]
    """Extract the AppContext from the MCP context."""
    return ctx.request_context.lifespan_context  # type: ignore[union-attr,return-value]


def register_cicd_tools(mcp: FastMCP) -> None:
    """Register CICD template tools on the MCP server."""

    @mcp.tool()
    def cicd_workflows(
        output_format: str = "json",
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """List all CICD workflow templates.

        Args:
            output_format: Output format — "json" or "table".
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.cicd_service import load_cicd

        cicd_path = base / ".global" / "taxonomy" / "cicd"
        try:
            result = load_cicd(cicd_path)
        except Exception as exc:
            return f"Error: {exc}"

        data = [
            {
                "name": w.name,
                "description": w.description,
                "jobs": len(w.jobs),
                "parameters": len(w.parameters),
            }
            for w in result.workflows
        ]
        return json.dumps(data, indent=2) if data else "No workflow templates found."

    @mcp.tool()
    def cicd_jobs(
        output_format: str = "json",
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """List all CICD job templates.

        Args:
            output_format: Output format — "json" or "table".
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.cicd_service import load_cicd

        cicd_path = base / ".global" / "taxonomy" / "cicd"
        try:
            result = load_cicd(cicd_path)
        except Exception as exc:
            return f"Error: {exc}"

        data = [
            {
                "name": j.name,
                "layerType": j.layer_type,
                "stage": j.stage,
                "description": j.description,
            }
            for j in result.jobs
        ]
        return json.dumps(data, indent=2) if data else "No job templates found."

    @mcp.tool()
    def cicd_stages(
        output_format: str = "json",
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """List all CICD stages.

        Args:
            output_format: Output format — "json" or "table".
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.cicd_service import load_cicd

        cicd_path = base / ".global" / "taxonomy" / "cicd"
        try:
            result = load_cicd(cicd_path)
        except Exception as exc:
            return f"Error: {exc}"

        data = [
            {
                "name": s.name,
                "description": s.description,
                "dependsOn": list(s.depends_on),
            }
            for s in result.stages
        ]
        return json.dumps(data, indent=2) if data else "No stages defined."

    @mcp.tool()
    def cicd_validate(
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Validate all CICD templates for correctness.

        Args:
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.cicd_service import load_cicd

        cicd_path = base / ".global" / "taxonomy" / "cicd"
        try:
            result = load_cicd(cicd_path)
        except Exception as exc:
            return f"Error: {exc}"

        validation_errors: list[str] = []

        for error in result.errors:
            validation_errors.append(f"{error.path}:{error.document_index}: {error.message}")

        job_names = {j.name for j in result.jobs}
        for w in result.workflows:
            for job in w.jobs:
                if job.template_ref not in job_names:
                    validation_errors.append(
                        f"Workflow '{w.name}' references unknown job template '{job.template_ref}'"
                    )

        stage_names = {s.name for s in result.stages}
        for j in result.jobs:
            if stage_names and j.stage not in stage_names:
                validation_errors.append(f"Job '{j.name}' references unknown stage '{j.stage}'")

        for s in result.stages:
            for dep in s.depends_on:
                if dep not in stage_names:
                    validation_errors.append(f"Stage '{s.name}' depends on unknown stage '{dep}'")

        if not validation_errors:
            return (
                f"All CICD templates valid: {len(result.workflows)} workflow(s), "
                f"{len(result.jobs)} job(s), {len(result.stages)} stage(s)."
            )

        lines = [f"Found {len(validation_errors)} error(s):"]
        for e in validation_errors:
            lines.append(f"  - {e}")
        return "\n".join(lines)

    @mcp.tool()
    def cicd_render(
        workflow_name: str,
        params: list[str] | None = None,
        output_file: str | None = None,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Render a CICD workflow template with the given parameters.

        Args:
            workflow_name: Name of the workflow template to render.
            params: Parameter values as "key=value" strings.
            output_file: Optional file path to write the rendered output.
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.cicd_service import render_workflow

        param_dict: dict[str, str] = {}
        if params:
            for p in params:
                if "=" not in p:
                    return f"Error: Invalid parameter format: '{p}' (expected key=value)"
                key, value = p.split("=", 1)
                param_dict[key] = value

        result = render_workflow(base, workflow_name, param_dict or None)

        if not result.success:
            msg = f"Error: {result.error}"
            if result.missing_params:
                msg += f"\nMissing required parameters: {', '.join(result.missing_params)}"
            return msg

        if output_file:
            try:
                Path(output_file).write_text(result.rendered or "")
                return f"Rendered workflow written to: {output_file}"
            except OSError as exc:
                return f"Error writing output file: {exc}"

        return result.rendered or ""

    _ = cicd_workflows
    _ = cicd_jobs
    _ = cicd_stages
    _ = cicd_validate
    _ = cicd_render
