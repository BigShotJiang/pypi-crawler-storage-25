"""Hook management tools — detect, generate, validate, run."""

import io
from pathlib import Path

from mcp.server.fastmcp import Context, FastMCP

from katalyst_taxonomy.mcp.server import AppContext


def _get_ctx(ctx: Context) -> AppContext:  # type: ignore[type-arg]
    """Extract the AppContext from the MCP context."""
    return ctx.request_context.lifespan_context  # type: ignore[union-attr,return-value]


def register_hooks_tools(mcp: FastMCP) -> None:
    """Register hook management tools on the MCP server."""

    @mcp.tool()
    def hooks_detect(
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Detect the configured git hook tool from .katalyst-hooks.yaml.

        Args:
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.hooks import detect_tool

        tool = detect_tool(base)
        if tool is None:
            return "No hooks config found (.katalyst-hooks.yaml)."
        return f"Detected hook tool: {tool}"

    @mcp.tool()
    def hooks_generate(
        tool_override: str | None = None,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Generate native hook tool configuration from .katalyst-hooks.yaml.

        Args:
            tool_override: Override the detected tool (e.g., "pre-commit").
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        buf_out = io.StringIO()
        buf_err = io.StringIO()

        from katalyst_taxonomy.services.hooks import generate_native_config

        exit_code = generate_native_config(
            base, tool_override=tool_override, out=buf_out, err=buf_err
        )

        result = buf_out.getvalue()
        errors = buf_err.getvalue()
        if exit_code == 0:
            return result.strip() or "Hook config generated."
        return f"Error: {errors}".strip()

    @mcp.tool()
    def hooks_validate(
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Validate hooks configuration against installed actions.

        Args:
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        buf_out = io.StringIO()
        buf_err = io.StringIO()

        from katalyst_taxonomy.services.hooks import validate_hooks_config

        exit_code = validate_hooks_config(base, out=buf_out, err=buf_err)

        result = buf_out.getvalue()
        errors = buf_err.getvalue()
        if exit_code == 0:
            return result.strip() or "Hooks configuration is valid."
        return f"Error: {errors}".strip()

    @mcp.tool()
    def hooks_run(
        actions: list[str],
        files: list[str],
        dry_run: bool = False,
        environment: str | None = None,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Run kata actions against layers affected by the given files.

        Args:
            actions: List of action names to run (e.g., ["lint", "test"]).
            files: List of changed file paths to resolve to layers.
            dry_run: If true, show what would be run without executing.
            environment: Target environment name.
            path: Path to the repository root. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        buf_out = io.StringIO()
        buf_err = io.StringIO()

        from katalyst_taxonomy.services.hooks import run_hooks

        exit_code = run_hooks(
            base,
            actions,
            files,
            dry_run=dry_run,
            environment=environment,
            out=buf_out,
            err=buf_err,
        )

        result = buf_out.getvalue()
        errors = buf_err.getvalue()
        if exit_code == 0:
            return result.strip() or "Hooks executed successfully."
        return f"Error: {errors}".strip()

    _ = hooks_detect
    _ = hooks_generate
    _ = hooks_validate
    _ = hooks_run
