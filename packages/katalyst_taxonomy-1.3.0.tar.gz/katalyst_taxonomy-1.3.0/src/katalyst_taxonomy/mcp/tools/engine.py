"""Engine tools — build-types, migrate."""

from pathlib import Path
from typing import Any

from mcp.server.fastmcp import Context, FastMCP

from katalyst_taxonomy.mcp.server import AppContext


def _get_ctx(ctx: Context) -> AppContext:  # type: ignore[type-arg]
    """Extract the AppContext from the MCP context."""
    return ctx.request_context.lifespan_context  # type: ignore[union-attr,return-value]


def register_engine_tools(mcp: FastMCP) -> None:
    """Register v2 engine tools on the MCP server."""

    @mcp.tool()
    def build_types(
        verify_only: bool = False,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Rebuild the node type registry and JSON schemas from LinkML definitions.

        Args:
            verify_only: If true, only verify that generated/ is up to date (CI mode).
        """
        try:
            from katalyst_taxonomy.engine.build.pipeline import build_types as do_build
            from katalyst_taxonomy.engine.generated import GENERATED_DIR

            # Find node_types directory relative to the package
            node_types_dir = GENERATED_DIR.parent.parent / "node_types"
            if not node_types_dir.exists():
                # Fallback: try relative to CWD
                node_types_dir = Path("node_types")

            registry_data: dict[str, Any] = do_build(
                node_types_dir=node_types_dir,
                output_dir=GENERATED_DIR,
                verbose=False,
            )
            type_count = len(registry_data.get("types", {}))
            return f"Build complete. Generated {type_count} type(s)."
        except Exception as exc:
            return f"Error: {exc}"

    @mcp.tool()
    def migrate(
        dry_run: bool = False,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Migrate taxonomy documents from v1alpha to v2alpha YAML format.

        Args:
            dry_run: If true, preview changes without writing files.
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        try:
            from katalyst_taxonomy.engine.migrate import migrate_directory

            results = migrate_directory(base, dry_run=dry_run)
            total_migrated = sum(r.documents_migrated for r in results)
            total_skipped = sum(r.skipped for r in results)
            total_already_v2 = sum(r.already_v2 for r in results)
            errors = [r for r in results if r.error is not None]

            if dry_run:
                files_needing_migration = [r for r in results if r.documents_migrated > 0]
                if files_needing_migration:
                    lines = [f"Would migrate {len(files_needing_migration)} file(s):"]
                    for r in files_needing_migration:
                        lines.append(f"  - {r.path} ({r.documents_migrated} doc(s))")
                    return "\n".join(lines)
                return "No files need migration."

            parts = [f"Migration complete. {len(results)} file(s) processed."]
            parts.append(f"  Migrated: {total_migrated} document(s)")
            if total_already_v2:
                parts.append(f"  Already v2: {total_already_v2}")
            if total_skipped:
                parts.append(f"  Skipped: {total_skipped}")
            if errors:
                parts.append(f"  Errors: {len(errors)}")
                for r in errors:
                    parts.append(f"    - {r.path}: {r.error}")
            return "\n".join(parts)
        except Exception as exc:
            return f"Error: {exc}"

    _ = build_types
    _ = migrate
