"""Taxonomy read and write tools — show, get, list, tree, lint, deps, status, resolve, create, clone."""

import io
import json
from pathlib import Path

from mcp.server.fastmcp import Context, FastMCP

from katalyst_taxonomy.mcp.server import AppContext
from katalyst_taxonomy.services.taxonomy import TaxonomyService


def _get_ctx(ctx: Context) -> AppContext:  # type: ignore[type-arg]
    """Extract the AppContext from the MCP context."""
    return ctx.request_context.lifespan_context  # type: ignore[union-attr,return-value]


def _load_service(app: AppContext, base: Path) -> TaxonomyService:
    """Load taxonomy service from the backend.

    If ``base`` differs from the backend's configured path, update
    the backend so it reads from the requested location.
    """
    backend = app.backend
    if backend.base_path != base:
        backend.base_path = base
    documents = backend.load_documents()
    environments = backend.load_environments()
    errors = backend.errors()
    return TaxonomyService(documents=documents, environments=environments, errors=errors)


def register_taxonomy_tools(mcp: FastMCP) -> None:
    """Register taxonomy read/write tools on the MCP server."""

    @mcp.tool()
    def taxonomy_tree(path: str | None = None, ctx: Context = None) -> str:  # type: ignore[type-arg,assignment]
        """Show the taxonomy as a tree structure.

        Args:
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path
        service = _load_service(app, base)

        if not service.documents:
            return "No taxonomy documents found."

        from katalyst_taxonomy.services.serialization import build_tree_lines

        return "\n".join(build_tree_lines(service))

    @mcp.tool()
    def taxonomy_list(path: str | None = None, ctx: Context = None) -> str:  # type: ignore[type-arg,assignment]
        """List all taxonomy nodes grouped by type.

        Args:
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path
        service = _load_service(app, base)

        if not service.documents:
            return "No taxonomy documents found."

        grouped = service.group_documents_by_type()
        lines: list[str] = []
        for kind, docs in grouped.items():
            lines.append(f"\n{kind.upper()} ({len(docs)})")
            for doc in docs:
                fqtn = service.get_qualified_name(doc)
                desc = doc.description or ""
                if desc and len(desc) > 60:
                    desc = desc[:57] + "..."
                lines.append(f"  {fqtn}" + (f" - {desc}" if desc else ""))
        return "\n".join(lines)

    @mcp.tool()
    def taxonomy_get(name: str, path: str | None = None, ctx: Context = None) -> str:  # type: ignore[type-arg,assignment]
        """Get a single taxonomy node by name, returned as JSON.

        Args:
            name: The name of the taxonomy node to retrieve.
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path
        service = _load_service(app, base)

        doc = service.get_document_by_name(name)
        if doc is None:
            return f"Error: Node '{name}' not found."

        from katalyst_taxonomy.services.serialization import serialize_document

        payload = serialize_document(doc, service, base)
        return json.dumps(payload, indent=2)

    @mcp.tool()
    def taxonomy_show(
        output_format: str = "tree",
        name: str | None = None,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Show the taxonomy in the specified format (tree, list, or json).

        Args:
            output_format: Output format — one of "tree", "list", or "json".
            name: Optional node name to filter the output to.
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path
        service = _load_service(app, base)

        if name:
            doc = service.get_document_by_name(name)
            if doc is None:
                return f"Error: Node '{name}' not found."
            service = TaxonomyService(
                documents=(doc,),
                environments=service.environments,
                errors=(),
            )

        if output_format == "tree":
            from katalyst_taxonomy.services.serialization import build_tree_lines

            if not service.documents:
                return "No taxonomy documents found."
            return "\n".join(build_tree_lines(service))
        elif output_format == "list":
            return taxonomy_list(path=path, ctx=ctx)
        elif output_format == "json":
            from katalyst_taxonomy.services.serialization import serialize_taxonomy

            payload = serialize_taxonomy(service, base)
            return json.dumps(payload, indent=2)
        else:
            return f"Error: Unknown format '{output_format}'. Use 'tree', 'list', or 'json'."

    @mcp.tool()
    def taxonomy_lint(
        path: str | None = None,
        verbose: bool = False,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Validate the taxonomy against its schema. Reports errors and warnings.

        Args:
            path: Path to the taxonomy directory. Defaults to the server's configured path.
            verbose: If true, include detailed schema violation information.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.lint import lint_taxonomy

        result = lint_taxonomy(base)

        if result.is_valid:
            return (
                f"Validated {result.document_count} document(s) and "
                f"{result.environment_count} environment(s). No errors found."
            )

        lines: list[str] = []
        if result.document_errors:
            for error in result.document_errors:
                rel_path = error.path.name if error.path else "<unknown>"
                lines.append(f"[{rel_path}] {error.message}")

        if result.plugin_schema_errors:
            for violation in result.plugin_schema_errors:
                lines.append(
                    f"[plugin/{violation.node_type}] "
                    f"{violation.node_name or '<unnamed>'}: "
                    f"{violation.message}"
                )

        if result.version_constraint_errors:
            for vc_err in result.version_constraint_errors:
                lines.append(vc_err.message)

        if result.contract_warnings:
            for warning in result.contract_warnings:
                lines.append(
                    f"Warning: Environment '{warning.environment_name}' missing "
                    f"{warning.section} key '{warning.key}'"
                )

        return f"Found {result.total_errors} error(s):\n" + "\n".join(lines)

    @mcp.tool()
    def taxonomy_deps(
        output_format: str = "tree",
        node: str | None = None,
        reverse: bool = False,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Show the dependency graph for taxonomy nodes.

        Args:
            output_format: Output format — one of "tree", "list", "json", or "mermaid".
            node: Optional node name or FQTN to filter to.
            reverse: If true, show dependents instead of dependencies.
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path
        service = _load_service(app, base)

        from katalyst_taxonomy.services.deps import build_dependency_graph

        graph = build_dependency_graph(service)

        if output_format == "json":
            data: dict[str, object] = {
                "nodes": {
                    fqtn: {
                        "name": n.name,
                        "nodeType": n.node_type,
                        "dependencies": n.dependencies,
                        "dependents": n.dependents,
                    }
                    for fqtn, n in graph.nodes.items()
                },
                "cycles": graph.cycles,
                "unresolved": graph.unresolved,
            }
            return json.dumps(data, indent=2)

        # For other formats, use the CLI formatters (pure functions on domain model)
        from katalyst_taxonomy.cli.commands.deps.formatters import (
            output_list,
            output_mermaid,
            output_tree,
        )

        buf = io.StringIO()
        if output_format == "tree":
            output_tree(graph, service, node, reverse, buf)
        elif output_format == "list":
            output_list(graph, service, buf)
        elif output_format == "mermaid":
            output_mermaid(graph, service, node, buf)
        else:
            return f"Error: Unknown format '{output_format}'."

        return buf.getvalue().strip() or "No dependencies found."

    @mcp.tool()
    def taxonomy_status(
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Show installed Katalyst components and versions.

        Args:
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.services.status import StatusCode, get_status

        result = get_status(base)

        if result.status == StatusCode.NOT_INITIALIZED:
            return f"No Katalyst lock file found.\nExpected: {result.lock_file_path}"

        if result.status == StatusCode.ERROR:
            return f"Error reading lock file: {result.error}"

        lock = result.lock
        assert lock is not None
        lines = [
            "Katalyst Taxonomy Status",
            f"  Version:   {lock.installed.core.version}",
            f"  Schema:    {lock.installed.core.schema_version}",
            f"  Source:    {lock.installed.core.source}",
        ]

        if lock.installed.plugins:
            lines.append(f"\nPlugins ({len(lock.installed.plugins)}):")
            for pname in sorted(lock.installed.plugins.keys()):
                plugin = lock.get_plugin(pname)
                if plugin:
                    lines.append(f"  {pname}: {plugin.version} ({plugin.source})")

        lines.append(f"\nLock file: {result.lock_file_path}")
        return "\n".join(lines)

    @mcp.tool()
    def taxonomy_resolve(
        files: list[str],
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Map file paths to their parent taxonomy layers.

        Args:
            files: List of file paths to resolve (relative to repo root).
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        if not files:
            return "Error: no files provided."

        from katalyst_taxonomy.services.resolve import resolve_affected_layers

        result = resolve_affected_layers(files, base)

        output = {
            "layers": [
                {
                    "fqtn": layer.fqtn,
                    "layerType": layer.layer_type,
                    "layerDir": layer.layer_dir,
                    "changedFiles": list(layer.changed_files),
                }
                for layer in result.layers
            ],
            "unmapped": list(result.unmapped),
        }
        return json.dumps(output, indent=2)

    @mcp.tool()
    def taxonomy_create(
        node_type: str,
        name: str,
        description: str | None = None,
        owners: list[str] | None = None,
        environments: list[str] | None = None,
        parent: str | None = None,
        parent_system: str | None = None,
        layer_type: str | None = None,
        target_dir: str | None = None,
        output_format: str = "yaml",
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Create a new taxonomy node.

        Args:
            node_type: Type of node to create (system, stack, layer, etc.).
            name: Name of the new node.
            description: Optional description for the node.
            owners: Optional list of owner emails.
            environments: Optional list of environment names.
            parent: Direct parent name (required for stack/layer).
            parent_system: Parent system name for disambiguation.
            layer_type: Layer type (for layer nodes, e.g. "app-docker").
            target_dir: Override computed directory for node placement.
            output_format: File format — "yaml" or "markdown".
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.adapters.filesystem import FilesystemWriter
        from katalyst_taxonomy.ports.filesystem import RealFilesystem
        from katalyst_taxonomy.ports.taxonomy import CreationRequest
        from katalyst_taxonomy.services.creation import CreationService

        request = CreationRequest(
            node_type=node_type,
            name=name,
            description=description,
            owners=tuple(owners) if owners else (),
            environments=tuple(environments) if environments else (),
            parent=parent,
            parent_system=parent_system,
            layer_type=layer_type,
            target_dir=target_dir,
        )

        writer = FilesystemWriter(output_format=output_format)
        filesystem = RealFilesystem()
        service = CreationService(writer=writer, filesystem=filesystem)

        result = service.create(base, request)

        if result.success:
            rel_path = str(result.path)
            if result.path:
                try:
                    rel_path = str(result.path.relative_to(base))
                except ValueError:
                    pass
            return f"Created {node_type} '{name}' at {rel_path}"
        return f"Error: {result.error}"

    @mcp.tool()
    def taxonomy_clone(
        node_type: str,
        source_name: str,
        target_name: str,
        source_system: str | None = None,
        source_stack: str | None = None,
        target_system: str | None = None,
        target_stack: str | None = None,
        description: str | None = None,
        owners: list[str] | None = None,
        environments: list[str] | None = None,
        layer_type: str | None = None,
        scaffold: bool = False,
        path: str | None = None,
        ctx: Context = None,  # type: ignore[type-arg,assignment]
    ) -> str:
        """Clone a taxonomy node (layer or stack).

        Args:
            node_type: Type of node to clone ("layer" or "stack").
            source_name: Name of the source node.
            target_name: Name for the cloned node.
            source_system: Source system name for disambiguation.
            source_stack: Source stack name for disambiguation.
            target_system: Target system (defaults to source).
            target_stack: Target stack (defaults to source).
            description: Description override for the cloned node.
            owners: Owner overrides for the cloned node.
            environments: Environment overrides for the cloned node.
            layer_type: Layer type override (for layers).
            scaffold: If true, re-scaffold from template instead of copying files.
            path: Path to the taxonomy directory. Defaults to the server's configured path.
        """
        app = _get_ctx(ctx)
        base = Path(path) if path else app.base_path

        from katalyst_taxonomy.adapters.taxonomy_loader import SimpleTaxonomyLoader
        from katalyst_taxonomy.services.clone import (
            CloneConfig,
            CloneService,
            CloneStatus,
            RealCloneFilesystem,
        )

        config = CloneConfig(
            target_path=base,
            node_type=node_type,
            source_name=source_name,
            target_name=target_name,
            source_system=source_system,
            source_stack=source_stack,
            target_system=target_system,
            target_stack=target_stack,
            description=description,
            owners=tuple(owners) if owners else (),
            environments=tuple(environments) if environments else (),
            layer_type=layer_type,
            scaffold=scaffold,
        )

        service = CloneService(
            filesystem=RealCloneFilesystem(),
            taxonomy_loader=SimpleTaxonomyLoader(base),
        )
        result = service.clone(config)

        if result.status == CloneStatus.SUCCESS:
            return f"Cloned {node_type} '{source_name}' to '{target_name}'"
        return f"Error: {result.error}"

    _ = taxonomy_tree
    _ = taxonomy_list
    _ = taxonomy_get
    _ = taxonomy_show
    _ = taxonomy_lint
    _ = taxonomy_deps
    _ = taxonomy_status
    _ = taxonomy_resolve
    _ = taxonomy_create
    _ = taxonomy_clone
