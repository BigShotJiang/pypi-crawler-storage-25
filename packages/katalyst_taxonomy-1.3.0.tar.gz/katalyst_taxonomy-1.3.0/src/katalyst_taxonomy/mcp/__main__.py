"""Entry point for the MCP server — runs with stdio transport."""

from __future__ import annotations

import sys
from pathlib import Path


def main() -> None:
    """Run the MCP server over stdio."""
    # Accept an optional --path argument
    base_path: Path | None = None
    args = sys.argv[1:]
    i = 0
    while i < len(args):
        if args[i] == "--path" and i + 1 < len(args):
            base_path = Path(args[i + 1])
            i += 2
        else:
            i += 1

    from katalyst_taxonomy.mcp.server import create_mcp_server

    mcp = create_mcp_server(base_path=base_path)
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
