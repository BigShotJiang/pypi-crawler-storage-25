"""Katalyst Taxonomy - A taxonomy management system for software architecture."""

from katalyst_taxonomy.domain.errors import (
    DocumentError,
    KatalystError,
    ValidationError,
)
from katalyst_taxonomy.domain.events import Event, EventBus, EventType
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.document import Document as TaxonomyDocument
from katalyst_taxonomy.ports.backend import (
    DeleteResult,
    SaveResult,
    SyncResult,
    TaxonomyBackend,
)
from katalyst_taxonomy.ports.export import (
    ExportData,
    ExportPort,
    ExportResult,
)
from katalyst_taxonomy.ports.linting import (
    LintingService,
    LintResult,
    LintViolation,
)
from katalyst_taxonomy.ports.taxonomy import (
    CreationRequest,
    CreationResult,
    TaxonomyRepository,
    TaxonomyResult,
    TaxonomyWriter,
)
from katalyst_taxonomy.services.creation import CreationService
from katalyst_taxonomy.services.export import ExportService
from katalyst_taxonomy.services.taxonomy import (
    TaxonomyService,
    build_qualified_names,
    document_lookup_key,
    qualified_name_for,
)
from katalyst_taxonomy.taxonomy.documents import (
    API_VERSION,
    KIND,
)
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

__version__ = "1.3.0"

__all__ = [
    # Version
    "__version__",
    # Constants
    "API_VERSION",
    "KIND",
    # Domain models
    "Document",
    "TaxonomyDocument",
    "EnvironmentDocument",
    # Events
    "Event",
    "EventType",
    "EventBus",
    # Errors
    "KatalystError",
    "ValidationError",
    "DocumentError",
    # Ports
    "TaxonomyRepository",
    "TaxonomyWriter",
    "TaxonomyResult",
    "CreationRequest",
    "CreationResult",
    "LintViolation",
    "LintResult",
    "LintingService",
    "ExportPort",
    "ExportData",
    "ExportResult",
    "TaxonomyBackend",
    "SaveResult",
    "DeleteResult",
    "SyncResult",
    # Services
    "CreationService",
    "ExportService",
    "TaxonomyService",
    "build_qualified_names",
    "document_lookup_key",
    "qualified_name_for",
]
