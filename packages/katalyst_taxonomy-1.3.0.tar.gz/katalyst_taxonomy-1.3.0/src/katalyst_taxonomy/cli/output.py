"""Console output formatting helpers."""

from __future__ import annotations

import sys
from typing import TextIO

# ANSI color codes
ANSI_RESET = "\033[0m"
HEADING_COLOR = "\033[96m"  # Cyan
ERROR_COLOR = "\033[91m"  # Red
WARNING_COLOR = "\033[93m"  # Yellow
SUCCESS_COLOR = "\033[92m"  # Green
PATH_COLOR = "\033[94m"  # Blue
DIM_COLOR = "\033[2m"  # Dim


def supports_color(stream: TextIO | None = None) -> bool:
    """Check if the given stream supports ANSI colors."""
    target: TextIO = stream if stream is not None else sys.stdout
    if not hasattr(target, "isatty"):
        return False
    try:
        return bool(target.isatty())
    except Exception:
        return False


def colorize(text: str, color: str, stream: TextIO | None = None) -> str:
    """Apply ANSI color to text if the stream supports it."""
    if not color or not supports_color(stream):
        return text
    return f"{color}{text}{ANSI_RESET}"


def write_heading(
    title: str,
    stream: TextIO | None = None,
    *,
    color: str = HEADING_COLOR,
) -> None:
    """Write a formatted heading to the stream."""
    target: TextIO = stream if stream is not None else sys.stdout
    line = f"{'=' * 6} {title.upper()} {'=' * 6}"
    target.write(colorize(line, color, target) + "\n")


def write_error(message: str, stream: TextIO | None = None) -> None:
    """Write an error message to stderr."""
    target: TextIO = stream if stream is not None else sys.stderr
    target.write(colorize(f"Error: {message}", ERROR_COLOR, target) + "\n")


def write_warning(message: str, stream: TextIO | None = None) -> None:
    """Write a warning message to stderr."""
    target: TextIO = stream if stream is not None else sys.stderr
    target.write(colorize(f"Warning: {message}", WARNING_COLOR, target) + "\n")


def write_success(message: str, stream: TextIO | None = None) -> None:
    """Write a success message to stdout."""
    target: TextIO = stream if stream is not None else sys.stdout
    target.write(colorize(message, SUCCESS_COLOR, target) + "\n")


# Node type ordering for display — now driven by the v2 registry.


def _build_kind_order() -> tuple[str, ...]:
    """Build the kind ordering from the v2 registry."""
    from katalyst_taxonomy.engine.bridge import get_default_registry

    registry = get_default_registry()
    return registry.sorted_kinds()


def _build_section_titles() -> dict[str, str]:
    """Build section titles from the v2 registry."""
    from katalyst_taxonomy.engine.bridge import get_default_registry

    registry = get_default_registry()
    titles: dict[str, str] = {}
    for kind in registry.all_kinds():
        # Convert kind to title: "team_member" -> "Team Members"
        words = kind.replace("_", " ").title()
        # Pluralize simply
        if words.endswith("y") and not words.endswith("ey"):
            titles[kind] = words[:-1] + "ies"
        elif words.endswith("s") or words.endswith("x"):
            titles[kind] = words + "es"
        else:
            titles[kind] = words + "s"
    return titles


# Lazy initialization to avoid import-time registry loading.
_kind_order_cache: tuple[str, ...] | None = None
_kind_section_titles_cache: dict[str, str] | None = None


def get_kind_order() -> tuple[str, ...]:
    """Get the kind ordering (lazy-loaded from registry)."""
    global _kind_order_cache
    if _kind_order_cache is None:
        _kind_order_cache = _build_kind_order()
    return _kind_order_cache


def get_section_titles() -> dict[str, str]:
    """Get the section titles (lazy-loaded from registry)."""
    global _kind_section_titles_cache
    if _kind_section_titles_cache is None:
        _kind_section_titles_cache = _build_section_titles()
    return _kind_section_titles_cache


# Backward-compatible aliases — these are populated lazily on first access.
# Code should prefer the getter functions above.
KIND_ORDER: tuple[str, ...] = ()
KIND_SECTION_TITLES: dict[str, str] = {}
