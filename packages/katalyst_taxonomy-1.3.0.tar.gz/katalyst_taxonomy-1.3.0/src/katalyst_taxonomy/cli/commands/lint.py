"""lint command - validate taxonomy against schema."""

from __future__ import annotations

# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownArgumentType=false
import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.loaders import load_taxonomy
from katalyst_taxonomy.cli.output import write_error, write_success, write_warning
from katalyst_taxonomy.linting.environment_contract_linter import lint_environment_contracts


def run_lint(
    path: Path,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
    *,
    verbose: bool = False,
) -> int:
    """Execute the lint command."""
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    try:
        service = load_taxonomy(path)
    except FileNotFoundError as exc:
        write_error(str(exc), err)
        return 1
    except Exception as exc:
        write_error(f"Failed to load taxonomy: {exc}", err)
        return 1

    # Report errors
    if service.errors:
        for error in service.errors:
            rel_path = error.path.name if error.path else "<unknown>"
            if verbose:
                write_warning(
                    f"[{rel_path}] (doc #{error.document_index}) {error.message}",
                    err,
                )
            else:
                write_warning(f"[{rel_path}] {error.message}", err)

        err.write(f"\nFound {len(service.errors)} error(s) in taxonomy.\n")

        # In verbose mode, run schema linting to provide detailed violation info
        if verbose:
            _run_verbose_linting(path, service, err)

        return 1

    # Environment contract warnings
    contract_result = lint_environment_contracts(path)
    for warning in contract_result.warnings:
        write_warning(
            f"Environment '{warning.environment_name}' is missing "
            f"{warning.section} key '{warning.key}' "
            f"required by {warning.declared_by} "
            f"(layer: {warning.layer_qualified_name})",
            err,
        )
    if contract_result.has_warnings:
        err.write(
            f"\n{len(contract_result.warnings)} environment contract warning(s) "
            f"across {contract_result.checked_layers} layer(s) and "
            f"{contract_result.checked_environments} environment(s).\n",
        )

    # Plugin schema validation (design, practices, cicd, etc.)
    plugin_exit = _run_plugin_schema_checks(path, out, err, verbose=verbose)

    # Version constraint validation
    version_exit = _run_version_constraint_checks(path, out, err)

    # In verbose mode, also run schema linting even on success
    if verbose:
        _run_verbose_linting(path, service, err)
        _run_bundled_version_consistency_check(err)

    if plugin_exit != 0:
        return plugin_exit
    if version_exit != 0:
        return version_exit

    # Success
    doc_count = len(service.documents)
    env_count = len(service.environments)
    write_success(
        f"Validated {doc_count} document(s) and {env_count} environment(s). No errors found.",
        out,
    )
    return 0


def _run_plugin_schema_checks(
    path: Path,
    out: TextIO,
    err: TextIO,
    *,
    verbose: bool = False,
) -> int:
    """Validate plugin documents against their JSON Schemas.

    Runs the design and practices plugin linters to catch schema violations
    in plugin YAML files under .global/taxonomy/.

    Returns:
        0 if all plugin documents are valid (or no plugin documents exist).
        1 if any schema violations were found.
    """
    try:
        from katalyst_taxonomy.linting.v2_linter import lint_v2_documents

        # Scan all plugin directories using v2 registry-driven validation
        result = lint_v2_documents(
            path,
            directories=(
                ".global/taxonomy/design",
                ".global/taxonomy/practices",
                ".global/taxonomy/capabilities",
                ".global/taxonomy/actions",
                ".global/taxonomy/layer_actions",
                ".global/taxonomy/extensions",
                ".global/taxonomy/cicd",
                ".global/taxonomy/layer_types",
                ".global/taxonomy/tools",
            ),
        )

        total_docs = sum(result.counts.values())
        total_errors = len(result.errors)

        if result.errors:
            for violation in result.errors:
                write_warning(
                    f"[{result.name}/{violation.node_type}] "
                    f"{violation.node_name or '<unnamed>'}: "
                    f"{violation.message} ({violation.group_label})",
                    err,
                )
                if verbose and violation.hint:
                    err.write(f"    Hint: {violation.hint}\n")

        if total_errors > 0:
            err.write(
                f"\nFound {total_errors} plugin schema error(s) "
                f"across {total_docs} plugin document(s).\n",
            )
            return 1

        return 0

    except Exception:
        # Best-effort: don't fail the entire lint if plugin linting breaks
        return 0


def _run_verbose_linting(
    path: Path,
    service: object,
    err: TextIO,
) -> None:
    """Run detailed schema linting and output verbose violation information."""
    try:
        from katalyst_taxonomy.linting.taxonomy_linter import lint_taxonomy_nodes

        result = lint_taxonomy_nodes(path)

        if result.errors:
            err.write(f"\nSchema violations ({len(result.errors)}):\n")
            for v in result.errors:
                err.write(f"  [{v.node_type}] {v.qualified_name}: {v.message} ({v.group_label})\n")
                if v.hint:
                    err.write(f"    Hint: {v.hint}\n")
        else:
            err.write("\nNo schema violations found.\n")
    except Exception as exc:
        err.write(f"\nVerbose linting unavailable: {exc}\n")


def _run_bundled_version_consistency_check(err: TextIO) -> None:
    """Check that bundled template versions are internally consistent.

    This is a development/CI sanity check: it verifies that
    BUNDLED_VERSION, manifest.json files, and metadata.version fields
    all agree within the bundled template tree.
    """
    try:
        from katalyst_taxonomy.linting.version_consistency import (
            lint_bundled_version_consistency,
        )
        from katalyst_taxonomy.templates.sources.local import (
            BUNDLED_VERSION,
            get_bundled_templates_path,
        )

        bundled_path = get_bundled_templates_path()
        result = lint_bundled_version_consistency(bundled_path, expected_version=BUNDLED_VERSION)

        if result.has_issues:
            err.write(
                f"\nBundled template version inconsistencies ({len(result.mismatches)}):\n",
            )
            for m in result.mismatches:
                label = m.plugin_name or m.path.name
                err.write(
                    f"  [{m.kind}] {label}: expected {m.expected_version}, "
                    f"found {m.found_version} ({m.path.name})\n",
                )
        else:
            err.write(
                f"\nBundled template versions consistent "
                f"(v{BUNDLED_VERSION}, "
                f"{result.checked_manifests} manifests, "
                f"{result.checked_yaml_docs} YAML docs).\n",
            )
    except Exception as exc:
        err.write(f"\nBundled version consistency check unavailable: {exc}\n")


def _run_version_constraint_checks(
    path: Path,
    out: TextIO,
    err: TextIO,
) -> int:
    """Validate version constraints on plugin requirements.

    Scans all plugin YAML files under .global/taxonomy/, builds a plugin
    index, and checks that any ``metadata.requires[].version`` constraints
    are satisfied by the resolved dependency's ``metadata.version``.

    Returns:
        0 if all constraints are satisfied (or no constraints exist).
        1 if a hard error was found (unsatisfied constraint, invalid syntax).
        0 with warnings written to *err* for soft issues (unversioned deps).
    """
    try:
        import yaml as _yaml

        # Version constraint linting uses the v2 engine format now
        V2_API_VERSION = "katalyst.taxonomy/v2alpha"

        taxonomy_root = path / ".global" / "taxonomy"
        if not taxonomy_root.exists():
            return 0

        # Collect all taxonomy YAML files
        yaml_files: list[Path] = []
        for ext in (".yaml", ".yml"):
            yaml_files.extend(taxonomy_root.rglob(f"*{ext}"))

        if not yaml_files:
            return 0

        # Build a lightweight index: (apiVersion, kind, name) -> version
        from typing import Any, cast

        _index: dict[tuple[str, str, str], str | None] = {}
        for yf in yaml_files:
            try:
                raw_all: Any = _yaml.safe_load_all(yf.read_text(encoding="utf-8"))
                for raw_doc in raw_all:
                    if not isinstance(raw_doc, dict):
                        continue
                    doc = cast(dict[str, Any], raw_doc)
                    av = str(doc.get("apiVersion", ""))
                    if av != V2_API_VERSION:
                        continue
                    kind_val = doc.get("kind")
                    meta = doc.get("metadata")
                    if not isinstance(meta, dict) or not isinstance(kind_val, str):
                        continue
                    name_val = meta.get("name")
                    if not isinstance(name_val, str):
                        continue
                    ver = meta.get("version")
                    _index[(av, kind_val, name_val)] = str(ver) if ver else None
            except (_yaml.YAMLError, OSError):
                continue

        # Now scan for requirements with version constraints
        has_error = False
        for yaml_file in yaml_files:
            try:
                content = yaml_file.read_text(encoding="utf-8")
                raw_docs: Any = _yaml.safe_load_all(content)
                for _doc_index, raw_doc in enumerate(raw_docs, start=1):
                    if not isinstance(raw_doc, dict):
                        continue
                    doc = cast(dict[str, Any], raw_doc)
                    api_version: str = str(doc.get("apiVersion", ""))
                    if api_version != V2_API_VERSION:
                        continue

                    metadata_raw = doc.get("metadata")
                    if not isinstance(metadata_raw, dict):
                        continue
                    metadata = cast(dict[str, Any], metadata_raw)

                    requires_raw: Any = metadata.get("requires")
                    if not requires_raw or not isinstance(requires_raw, list):
                        continue

                    plugin_name: str = str(metadata.get("name", "<unknown>"))

                    # Parse requirements inline (replaces plugins.models.parse_requirements)
                    for req_raw in requires_raw:
                        if not isinstance(req_raw, dict):
                            continue
                        req_api = str(req_raw.get("apiVersion", ""))
                        req_kind = str(req_raw.get("kind", ""))
                        req_name = str(req_raw.get("name", ""))
                        version_str = req_raw.get("version")
                        if not version_str or not isinstance(version_str, str):
                            continue
                        version_str = version_str.strip()
                        if not version_str:
                            continue

                        # Validate constraint syntax
                        try:
                            from katalyst_taxonomy.domain.version import parse_constraint

                            constraint = parse_constraint(version_str)
                        except ValueError:
                            write_error(
                                f"Invalid version constraint '{version_str}' on "
                                f"dependency {req_kind} '{req_name}' "
                                f"in plugin '{plugin_name}'",
                                err,
                            )
                            has_error = True
                            continue

                        # Look up the dependency in the index
                        dep_key = (req_api, req_kind, req_name)
                        dep_version_str = _index.get(dep_key)
                        if dep_key not in _index:
                            # Dependency not found -- the regular resolver
                            # already handles this; skip.
                            continue

                        # Check if the dependency has a version
                        if dep_version_str is None:
                            write_warning(
                                f"Version constraint '{version_str}' on "
                                f"dependency {req_kind} '{req_name}' "
                                f"cannot be verified: dependency has no version "
                                f"(unversioned plugin '{req_name}')",
                                err,
                            )
                            continue

                        # Check if the constraint is satisfied
                        from katalyst_taxonomy.domain.version import parse_version

                        try:
                            dep_version = parse_version(dep_version_str)
                        except ValueError:
                            write_warning(
                                f"Dependency {req_kind} '{req_name}' has "
                                f"invalid version '{dep_version_str}'",
                                err,
                            )
                            continue

                        if not constraint.matches(dep_version):
                            write_error(
                                f"Version constraint not satisfied: "
                                f"plugin '{plugin_name}' requires "
                                f"{req_kind} '{req_name}' version "
                                f"'{version_str}', but found '{dep_version_str}'",
                                err,
                            )
                            has_error = True

            except (_yaml.YAMLError, OSError):
                continue

        return 1 if has_error else 0

    except Exception:
        # Best-effort: don't fail the entire lint if version checking breaks
        return 0
