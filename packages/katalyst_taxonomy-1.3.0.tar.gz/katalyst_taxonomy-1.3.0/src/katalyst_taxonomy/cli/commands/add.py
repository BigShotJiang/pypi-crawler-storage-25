"""add command - add plugins and layer types to an existing taxonomy."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from katalyst_taxonomy.services.add import (
    AddConfig,
    AddResult,
    AddService,
    AddStatus,
    RealAddFilesystem,
)
from katalyst_taxonomy.templates.sources import create_source


def _check_contracts_for_layer_types(
    path: Path,
    layer_types: tuple[str, ...],
    out: TextIO,
    inp: TextIO,
) -> None:
    """Check environment contracts for each added layer type and prompt if needed."""
    from katalyst_taxonomy.cli.commands.create import prompt_missing_contract_keys
    from katalyst_taxonomy.services.environment import get_configured_environments

    envs = get_configured_environments(path)
    if not envs:
        return

    for lt in layer_types:
        prompt_missing_contract_keys(path, lt, envs, out, inp)


# Fallback descriptions for well-known layer types.
_LAYER_TYPE_DESCRIPTIONS: dict[str, str] = {
    "app-docker": "Docker application scaffolding",
    "iac-terragrunt": "Terraform/Terragrunt infrastructure as code",
    "k8s-argocd": "Kubernetes with ArgoCD GitOps",
    "k8s-kustomize": "Kubernetes with Kustomize overlays",
}


def _discover_layer_type_menu(source_uri: str) -> dict[str, str]:
    """Query the template source for available layer types.

    Returns a dict mapping name -> description, falling back to
    the built-in descriptions when the source can't be queried.
    """
    try:
        source = create_source(source_uri)
        fetch_result = source.fetch_package("layer_types")
        manifest = getattr(fetch_result, "manifest", None)
        names: list[str] = []
        if manifest is not None:
            canonical = getattr(manifest, "canonical_items", ())
            if canonical:
                names = list(canonical)
        if not names:
            path = getattr(fetch_result, "path", None)
            if path is not None and path.is_dir():
                names = sorted(
                    item.name
                    for item in path.iterdir()
                    if item.is_dir() and not item.name.startswith(".")
                )
        if names:
            return {
                name: _LAYER_TYPE_DESCRIPTIONS.get(name, f"Layer type template: {name}")
                for name in names
            }
    except (KeyError, ValueError, OSError, ConnectionError, PermissionError):
        pass
    return dict(_LAYER_TYPE_DESCRIPTIONS)


def _interactive_select_layer_types(
    out: TextIO,
    inp: TextIO,
    available: dict[str, str],
) -> list[str]:
    """Interactively select layer types to add.

    Args:
        out: Output stream.
        inp: Input stream.

    Returns:
        List of selected layer type names.
    """
    console = Console(file=out)

    console.print()
    console.print("[bold cyan]Katalyst Add - Select Layer Types[/bold cyan]")
    console.print()

    # Build table
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Num", style="dim", width=4)
    table.add_column("Name", style="bold")
    table.add_column("Description", style="dim")

    layer_type_list = list(available.items())
    for i, (name, desc) in enumerate(layer_type_list):
        table.add_row(f"{i + 1}.", name, desc)

    panel = Panel(table, title="[bold]Available Layer Types[/bold]", border_style="blue")
    console.print(panel)

    console.print()
    console.print(
        "[dim]Enter numbers separated by spaces (e.g., '1 3'), 'a' for all, or press Enter to cancel:[/dim]",
    )
    console.print()

    try:
        line = inp.readline().strip().lower()
    except (EOFError, KeyboardInterrupt):
        return []

    if not line:
        return []

    if line == "a":
        return [name for name, _ in layer_type_list]

    # Parse numbers
    selected: list[str] = []
    for part in line.split():
        try:
            num = int(part)
            if 1 <= num <= len(layer_type_list):
                name = layer_type_list[num - 1][0]
                if name not in selected:
                    selected.append(name)
        except ValueError:
            continue

    return selected


def _print_not_initialized(stream: TextIO) -> None:
    """Print message when not initialized."""
    stream.write("Error: Repository not initialized.\n")
    stream.write("\n")
    stream.write("Run 'kata tax init' first to initialize a taxonomy repository.\n")


def _print_already_installed(result: AddResult, stream: TextIO) -> None:
    """Print message when components are already installed."""
    stream.write("\n")
    stream.write("Katalyst Add\n")
    stream.write("=" * 40 + "\n\n")
    stream.write("The following components are already installed:\n\n")
    for name in result.skipped:
        stream.write(f"  - {name}\n")
    stream.write("\n")
    stream.write("Use --force to reinstall existing components.\n")
    stream.write("\n")


def _print_success(result: AddResult, stream: TextIO) -> None:
    """Print success message."""
    stream.write("\n")
    stream.write("Katalyst Add Complete\n")
    stream.write("=" * 40 + "\n\n")

    if result.added:
        # Group by component type
        plugins = [c for c in result.added if c.component_type == "plugin"]
        layer_types = [c for c in result.added if c.component_type == "layer_type"]

        if plugins:
            stream.write("Added plugins:\n\n")
            for component in plugins:
                stream.write(f"  - {component.name} (v{component.version})\n")
            stream.write("\n")

        if layer_types:
            stream.write("Added layer types:\n\n")
            for component in layer_types:
                stream.write(f"  - {component.name} (v{component.version})\n")
            stream.write("\n")
            stream.write("Actions for the above layer types were also installed.\n")
            stream.write("\n")

    if result.skipped:
        stream.write("Skipped (already installed):\n\n")
        for name in result.skipped:
            stream.write(f"  - {name}\n")
        stream.write("\n")

    stream.write("Run 'kata tax status' to see the current configuration.\n")
    stream.write("\n")


def _print_failed(result: AddResult, stream: TextIO) -> None:
    """Print failure message."""
    stream.write("Error: Add failed.\n")
    if result.error:
        stream.write(f"Reason: {result.error}\n")


def _confirm_add(
    plugins: tuple[str, ...],
    layer_types: tuple[str, ...],
    stream: TextIO,
    in_stream: TextIO,
) -> bool:
    """Prompt user to confirm add operation.

    Args:
        plugins: Plugins to be added.
        layer_types: Layer types to be added.
        stream: Output stream.
        in_stream: Input stream for reading confirmation.

    Returns:
        True if user confirms, False otherwise.
    """
    stream.write("\nThe following will be added:\n\n")
    if plugins:
        stream.write("  Plugins:\n")
        for p in plugins:
            stream.write(f"    - {p}\n")
    if layer_types:
        stream.write("  Layer types:\n")
        for lt in layer_types:
            stream.write(f"    - {lt}\n")
    stream.write("\n")
    stream.write("Proceed? [y/N] ")
    stream.flush()

    response = in_stream.readline().strip().lower()
    return response in ("y", "yes")


def run_add(
    path: Path,
    *,
    plugins: tuple[str, ...] | None = None,
    layer_types: tuple[str, ...] | None = None,
    source: str = "bundled",
    force: bool = False,
    yes: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
    in_stream: TextIO | None = None,
) -> int:
    """Run the add command.

    Args:
        path: Path to the repository root.
        plugins: Plugin names to add.
        layer_types: Layer type names to add.
        source: Template source URI (default: "bundled").
        force: If True, overwrite existing components.
        yes: If True, skip confirmation prompts.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).
        in_stream: Input stream for interactive prompts.

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr
    inp: TextIO = in_stream if in_stream is not None else sys.stdin

    plugins = plugins or ()
    layer_types = layer_types or ()

    # If no components specified, offer interactive selection or show usage
    if not plugins and not layer_types:
        if not yes and sys.stdin.isatty():
            # Interactive mode - discover available types from source
            available = _discover_layer_type_menu(source)
            selected = _interactive_select_layer_types(out, inp, available)
            if not selected:
                out.write("\nNo layer types selected. Add cancelled.\n")
                return 0
            layer_types = tuple(selected)
        else:
            # Non-interactive - show usage
            err.write("Error: No plugins or layer types specified.\n")
            err.write("\n")
            err.write("Usage:\n")
            err.write("  kata tax add --plugin <name>      Add a plugin\n")
            err.write("  kata tax add --layer-type <name>  Add a layer type\n")
            err.write("\n")
            err.write("Available plugins:\n")
            err.write("  - layer_types     Layer type templates\n")
            err.write("  - cicd            CI/CD pipeline templates\n")
            err.write("\n")
            err.write("Use interactive mode or specify --layer-type <name>.\n")
            err.write("Use --source to specify a custom template source.\n")
            return 1

    # Ask for confirmation if interactive
    if not yes and sys.stdin.isatty():
        if not _confirm_add(plugins, layer_types, out, inp):
            out.write("\nAdd cancelled.\n")
            return 0

    # Create adapters
    filesystem = RealAddFilesystem()

    # Create template source from URI
    try:
        template_source = create_source(source)
    except ValueError as e:
        err.write(f"Error: Invalid source URI: {e}\n")
        return 1
    except (ConnectionError, PermissionError) as e:
        err.write(f"Error: Failed to connect to source: {e}\n")
        return 1

    # Create service
    service = AddService(
        filesystem=filesystem,
        template_source=template_source,
    )

    # Build config
    config = AddConfig(
        target_path=path,
        source=source,
        plugins=plugins,
        layer_types=layer_types,
        force=force,
        interactive=not yes,
    )

    # Run add
    result = service.add(config)

    # Handle result
    if result.status == AddStatus.NOT_INITIALIZED:
        _print_not_initialized(err)
        return 1

    if result.status == AddStatus.NOT_FOUND:
        err.write(f"Error: {result.error}\n")
        return 1

    if result.status == AddStatus.ALREADY_INSTALLED:
        _print_already_installed(result, out)
        return 0

    if result.status == AddStatus.SUCCESS:
        _print_success(result, out)

        # Check environment contracts for newly-added layer types
        if layer_types and not yes:
            _check_contracts_for_layer_types(path, layer_types, out, inp)

        return 0

    if result.status == AddStatus.FAILED:
        _print_failed(result, err)
        return 1

    # Should not reach here
    err.write(f"Unexpected status: {result.status}\n")
    return 1
