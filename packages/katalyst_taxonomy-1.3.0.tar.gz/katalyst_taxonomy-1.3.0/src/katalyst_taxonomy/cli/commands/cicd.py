"""cicd command - view, render, and validate CICD templates."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, TextIO

from katalyst_taxonomy.cli.output import (
    ERROR_COLOR,
    HEADING_COLOR,
    SUCCESS_COLOR,
    colorize,
    write_error,
    write_warning,
)
from katalyst_taxonomy.services.cicd_service import (
    CICDPluginResult,
    load_cicd_templates,
)


def _load_cicd(path: Path, err: TextIO) -> CICDPluginResult | None:
    """Load CICD templates and report any errors."""
    # CICD templates are installed in .global/taxonomy/cicd/
    cicd_path = path / ".global" / "taxonomy" / "cicd"
    try:
        result = load_cicd_templates(cicd_path)
    except Exception as exc:
        write_error(f"Failed to load CICD templates: {exc}", err)
        return None

    # Report parsing errors as warnings
    for error in result.errors:
        write_warning(f"{error.path}:{error.document_index}: {error.message}", err)

    return result


# --- Workflows ---


def run_cicd_workflows(
    path: Path,
    *,
    output_format: str = "table",
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """List all workflow templates.

    Args:
        path: Path to the repository root.
        output_format: Output format (table or json).
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    result = _load_cicd(path, err)
    if result is None:
        return 1

    workflows = result.workflows

    if output_format == "json":
        data = [
            {
                "name": w.name,
                "description": w.description,
                "jobs": len(w.jobs),
                "parameters": len(w.parameters),
                "templatePath": str(w.template.path),
                "renderer": w.template.renderer.type,
                "path": str(w.path),
            }
            for w in workflows
        ]
        out.write(json.dumps(data, indent=2) + "\n")
    else:
        if not workflows:
            out.write("No workflow templates found.\n")
            return 0

        out.write(f"{'WORKFLOW':<30} {'JOBS':<6} {'TEMPLATE':<40} DESCRIPTION\n")
        for w in sorted(workflows, key=lambda x: x.name):
            desc = (w.description or "")[:30]
            template = str(w.template.path)[:38]
            out.write(f"{w.name:<30} {len(w.jobs):<6} {template:<40} {desc}\n")

    return 0


def run_cicd_workflow_show(
    path: Path,
    *,
    workflow_name: str,
    output_format: str = "table",
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Show details of a specific workflow template.

    Args:
        path: Path to the repository root.
        workflow_name: Name of the workflow to show.
        output_format: Output format (table or json).
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 2 for not found).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    result = _load_cicd(path, err)
    if result is None:
        return 1

    workflow = result.workflow(workflow_name)
    if workflow is None:
        write_error(f"Workflow '{workflow_name}' not found", err)
        err.write("\nUse 'kata tax cicd workflows' to see available workflows.\n")
        return 2

    if output_format == "json":
        data: dict[str, Any] = {
            "name": workflow.name,
            "description": workflow.description,
            "template": {
                "path": str(workflow.template.path),
                "renderer": workflow.template.renderer.type,
                "strictUndefined": workflow.template.renderer.strict_undefined,
            },
            "parameters": [
                {
                    "name": p.name,
                    "type": p.value_type,
                    "required": p.required,
                    "default": p.default if p.has_default else None,
                    "hasDefault": p.has_default,
                    "description": p.description,
                }
                for p in workflow.parameters
            ],
            "jobs": [
                {
                    "name": j.name,
                    "templateRef": j.template_ref,
                    "needs": list(j.needs),
                    "with": dict(j.with_arguments),
                }
                for j in workflow.jobs
            ],
            "path": str(workflow.path),
            "documentIndex": workflow.document_index,
        }
        out.write(json.dumps(data, indent=2) + "\n")
    else:
        out.write(colorize(f"Workflow: {workflow.name}\n\n", HEADING_COLOR, out))
        out.write(f"  Template:    {workflow.template.path}\n")
        renderer = workflow.template.renderer
        strict = "yes" if renderer.strict_undefined else "no"
        out.write(f"  Renderer:    {renderer.type} (strict: {strict})\n")
        out.write(f"  Jobs:        {len(workflow.jobs)}\n")
        out.write(f"  Source:      {workflow.path}\n")

        if workflow.parameters:
            out.write("\n  Parameters:\n")
            out.write(
                f"    {'NAME':<20} {'TYPE':<10} {'REQUIRED':<10} {'DEFAULT':<15} DESCRIPTION\n",
            )
            for p in workflow.parameters:
                req = "yes" if p.required else "no"
                default = str(p.default)[:13] if p.has_default else "-"
                ptype = p.value_type or "-"
                desc = (p.description or "")[:30]
                out.write(f"    {p.name:<20} {ptype:<10} {req:<10} {default:<15} {desc}\n")

        if workflow.jobs:
            out.write("\n  Jobs:\n")
            out.write(f"    {'NAME':<20} {'TEMPLATE REF':<25} {'NEEDS':<20} ARGUMENTS\n")
            for j in workflow.jobs:
                needs = ", ".join(j.needs) if j.needs else "-"
                args = (
                    ", ".join(f"{k}={v}" for k, v in j.with_arguments)[:25]
                    if j.with_arguments
                    else "-"
                )
                out.write(f"    {j.name:<20} {j.template_ref:<25} {needs:<20} {args}\n")

        if workflow.description:
            out.write(f"\n  Description:\n    {workflow.description}\n")

    return 0


# --- Jobs ---


def run_cicd_jobs(
    path: Path,
    *,
    output_format: str = "table",
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """List all job templates.

    Args:
        path: Path to the repository root.
        output_format: Output format (table or json).
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    result = _load_cicd(path, err)
    if result is None:
        return 1

    jobs = result.jobs

    if output_format == "json":
        data = [
            {
                "name": j.name,
                "layerType": j.layer_type,
                "stage": j.stage,
                "description": j.description,
                "templatePath": str(j.template.path),
                "renderer": j.template.renderer.type,
                "requiredInputs": list(j.required_inputs),
                "produces": list(j.produces),
                "consumes": list(j.consumes),
                "path": str(j.path),
            }
            for j in jobs
        ]
        out.write(json.dumps(data, indent=2) + "\n")
    else:
        if not jobs:
            out.write("No job templates found.\n")
            return 0

        out.write(f"{'JOB TEMPLATE':<25} {'LAYER TYPE':<18} {'STAGE':<10} TEMPLATE\n")
        for j in sorted(jobs, key=lambda x: (x.layer_type, x.stage, x.name)):
            template = str(j.template.path)[:35]
            out.write(f"{j.name:<25} {j.layer_type:<18} {j.stage:<10} {template}\n")

    return 0


def run_cicd_job_show(
    path: Path,
    *,
    job_name: str,
    output_format: str = "table",
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Show details of a specific job template.

    Args:
        path: Path to the repository root.
        job_name: Name of the job to show.
        output_format: Output format (table or json).
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 2 for not found).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    result = _load_cicd(path, err)
    if result is None:
        return 1

    job = result.job(job_name)
    if job is None:
        write_error(f"Job template '{job_name}' not found", err)
        err.write("\nUse 'kata tax cicd jobs' to see available job templates.\n")
        return 2

    if output_format == "json":
        data: dict[str, Any] = {
            "name": job.name,
            "layerType": job.layer_type,
            "stage": job.stage,
            "description": job.description,
            "template": {
                "path": str(job.template.path),
                "renderer": job.template.renderer.type,
                "strictUndefined": job.template.renderer.strict_undefined,
            },
            "requiredInputs": list(job.required_inputs),
            "defaultInputs": dict(job.default_inputs),
            "produces": list(job.produces),
            "consumes": list(job.consumes),
            "path": str(job.path),
            "documentIndex": job.document_index,
        }
        out.write(json.dumps(data, indent=2) + "\n")
    else:
        out.write(colorize(f"Job Template: {job.name}\n\n", HEADING_COLOR, out))
        out.write(f"  Layer Type:  {job.layer_type}\n")
        out.write(f"  Stage:       {job.stage}\n")
        out.write(f"  Template:    {job.template.path}\n")
        renderer = job.template.renderer
        strict = "yes" if renderer.strict_undefined else "no"
        out.write(f"  Renderer:    {renderer.type} (strict: {strict})\n")
        out.write(f"  Source:      {job.path}\n")

        if job.required_inputs:
            out.write(f"\n  Required Inputs:   {', '.join(job.required_inputs)}\n")
        if job.default_inputs:
            out.write("  Default Inputs:    ")
            defaults = ", ".join(f"{k}={v}" for k, v in job.default_inputs)
            out.write(f"{defaults}\n")

        if job.produces or job.consumes:
            out.write("\n  Artifacts:\n")
            if job.produces:
                out.write(f"    Produces:  {', '.join(job.produces)}\n")
            if job.consumes:
                out.write(f"    Consumes:  {', '.join(job.consumes)}\n")

        if job.description:
            out.write(f"\n  Description:\n    {job.description}\n")

    return 0


# --- Stages ---


def run_cicd_stages(
    path: Path,
    *,
    output_format: str = "table",
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """List all CICD stages.

    Args:
        path: Path to the repository root.
        output_format: Output format (table or json).
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    result = _load_cicd(path, err)
    if result is None:
        return 1

    stages = result.stages

    if output_format == "json":
        data = [
            {
                "name": s.name,
                "description": s.description,
                "dependsOn": list(s.depends_on),
                "path": str(s.path),
            }
            for s in stages
        ]
        out.write(json.dumps(data, indent=2) + "\n")
    else:
        if not stages:
            out.write("No stages defined.\n")
            return 0

        out.write(f"{'STAGE':<20} {'DEPENDS ON':<30} DESCRIPTION\n")
        for s in sorted(stages, key=lambda x: x.name):
            deps = ", ".join(s.depends_on) if s.depends_on else "-"
            desc = (s.description or "")[:40]
            out.write(f"{s.name:<20} {deps:<30} {desc}\n")

    return 0


# --- Validate ---


def run_cicd_validate(
    path: Path,
    *,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Validate CICD templates.

    Args:
        path: Path to the repository root.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 if valid, 1 if errors found).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    out.write("Validating CICD templates...\n\n")

    result = _load_cicd(path, err)
    if result is None:
        return 1

    errors = result.errors
    workflows = result.workflows
    jobs = result.jobs
    stages = result.stages

    # Additional validation
    validation_errors: list[str] = []

    # Check that all job template refs in workflows exist
    job_names = {j.name for j in jobs}
    for w in workflows:
        for job in w.jobs:
            if job.template_ref not in job_names:
                validation_errors.append(
                    f"Workflow '{w.name}' references unknown job template '{job.template_ref}'",
                )

    # Check that stage refs in jobs exist
    stage_names = {s.name for s in stages}
    for j in jobs:
        if stage_names and j.stage not in stage_names:
            validation_errors.append(f"Job '{j.name}' references unknown stage '{j.stage}'")

    # Check stage dependencies
    for s in stages:
        for dep in s.depends_on:
            if dep not in stage_names:
                validation_errors.append(f"Stage '{s.name}' depends on unknown stage '{dep}'")

    # Report results
    total_errors = len(errors) + len(validation_errors)

    if total_errors == 0:
        out.write(f"  Workflows:     {len(workflows)} valid\n")
        out.write(f"  Job Templates: {len(jobs)} valid\n")
        out.write(f"  Stages:        {len(stages)} valid\n")
        out.write("\n")
        out.write(colorize("All CICD templates are valid.\n", SUCCESS_COLOR, out))
        return 0
    if errors:
        out.write("Parse Errors:\n")
        for e in errors:
            out.write(
                colorize(f"  {e.path}:{e.document_index} - {e.message}\n", ERROR_COLOR, out),
            )

    if validation_errors:
        out.write("Validation Errors:\n")
        for e in validation_errors:
            out.write(colorize(f"  {e}\n", ERROR_COLOR, out))

    out.write(f"\nFound {total_errors} error(s) in CICD templates.\n")
    return 1


# --- Render ---


def run_cicd_render(
    path: Path,
    *,
    workflow_name: str,
    params: tuple[str, ...] | None = None,
    output_file: str | None = None,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
    in_stream: TextIO | None = None,
) -> int:
    """Render a workflow template.

    Args:
        path: Path to the repository root.
        workflow_name: Name of the workflow to render.
        params: Parameter values as key=value strings.
        output_file: Optional output file path.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).
        in_stream: Input stream for interactive prompts.

    Returns:
        Exit code (0 for success, 1 for failure, 2 for not found).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr
    inp: TextIO = in_stream if in_stream is not None else sys.stdin

    result = _load_cicd(path, err)
    if result is None:
        return 1

    workflow = result.workflow(workflow_name)
    if workflow is None:
        write_error(f"Workflow '{workflow_name}' not found", err)
        err.write("\nUse 'kata tax cicd workflows' to see available workflows.\n")
        return 2

    # Parse provided params
    param_dict: dict[str, str] = {}
    if params:
        for p in params:
            if "=" not in p:
                write_error(f"Invalid parameter format: '{p}' (expected key=value)", err)
                return 1
            key, value = p.split("=", 1)
            param_dict[key] = value

    # Check for missing required params
    missing_required: list[str] = []
    for p in workflow.parameters:
        if p.required and not p.has_default and p.name not in param_dict:
            missing_required.append(p.name)

    # If interactive and missing params, prompt
    is_interactive = sys.stdin.isatty()
    if missing_required:
        if is_interactive:
            err.write("Missing required parameters. Please provide values:\n\n")
            for param_name in missing_required:
                param_def = next((p for p in workflow.parameters if p.name == param_name), None)
                desc = f" ({param_def.description})" if param_def and param_def.description else ""
                err.write(f"  {param_name}{desc}: ")
                err.flush()
                value = inp.readline().strip()
                if not value:
                    write_error(f"Required parameter '{param_name}' cannot be empty", err)
                    return 1
                param_dict[param_name] = value
            err.write("\n")
        else:
            write_error("Missing required parameters", err)
            err.write("\nRequired parameters:\n")
            for p in missing_required:
                err.write(f"  --param {p}=<value>\n")
            return 1

    # Build context for rendering — start with all extra params so that
    # templates can reference variables not declared in the workflow spec.
    context: dict[str, Any] = dict(param_dict)
    for p in workflow.parameters:
        if p.name in param_dict:
            context[p.name] = param_dict[p.name]
        elif p.has_default:
            context[p.name] = p.default

    # Load and render template
    template_path = workflow.template.path
    if not template_path.exists():
        write_error(f"Template file not found: {template_path}", err)
        return 1

    try:
        template_content = template_path.read_text()
    except OSError as exc:
        write_error(f"Failed to read template: {exc}", err)
        return 1

    # Render based on renderer type
    renderer = workflow.template.renderer
    if renderer.type == "jinja" or renderer.type == "jinja2":
        try:
            from jinja2 import Environment, StrictUndefined, Undefined

            jinja_env = Environment(
                undefined=StrictUndefined if renderer.strict_undefined else Undefined,
            )
            template = jinja_env.from_string(template_content)
            rendered = template.render(**context)
        except ImportError:
            write_error("Jinja2 is required for rendering. Install with: pip install jinja2", err)
            return 1
        except Exception as exc:
            write_error(f"Template rendering failed: {exc}", err)
            return 1
    else:
        write_error(f"Unsupported renderer type: {renderer.type}", err)
        return 1

    # Output
    if output_file:
        try:
            Path(output_file).write_text(rendered)
            out.write(f"Rendered workflow written to: {output_file}\n")
        except OSError as exc:
            write_error(f"Failed to write output file: {exc}", err)
            return 1
    else:
        out.write(rendered)
        if not rendered.endswith("\n"):
            out.write("\n")

    return 0
