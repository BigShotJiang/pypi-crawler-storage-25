"""remove command - remove plugins and layer types from an existing taxonomy."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from katalyst_taxonomy.services.remove import (
    RealRemoveFilesystem,
    RemoveConfig,
    RemoveResult,
    RemoveService,
    RemoveStatus,
)


def _interactive_select_for_removal(
    lock_path: Path,
    out: TextIO,
    inp: TextIO,
) -> tuple[list[str], list[str]]:
    """Interactively select plugins and layer types to remove.

    Args:
        lock_path: Path to the lock file.
        inp: Input stream.
        out: Output stream.

    Returns:
        Tuple of (plugins, layer_types) to remove.
    """
    import yaml

    console = Console(file=out)

    # Load lock file to see what's installed
    if not lock_path.exists():
        console.print("[red]Error: Taxonomy not initialized.[/red]")
        return [], []

    try:
        lock_data = yaml.safe_load(lock_path.read_text())
    except Exception:
        console.print("[red]Error: Failed to parse lock file.[/red]")
        return [], []

    plugins_data = lock_data.get("installed", {}).get("plugins", {})
    if not plugins_data:
        console.print("[yellow]No plugins or layer types are installed.[/yellow]")
        return [], []

    console.print()
    console.print("[bold cyan]Katalyst Remove - Select Components[/bold cyan]")
    console.print()

    # Build table of installed components
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Num", style="dim", width=4)
    table.add_column("Type", style="bold cyan", width=12)
    table.add_column("Name", style="bold")
    table.add_column("Details", style="dim")

    items: list[tuple[str, str, str]] = []  # (type, name, details)

    for plugin_name, plugin_data in plugins_data.items():
        if plugin_name == "layer_types":
            # Show individual layer types
            canonical = plugin_data.get("canonical", [])
            for lt_name in canonical:
                items.append(("layer_type", lt_name, ""))
        else:
            # Regular plugin
            version = plugin_data.get("version", "?")
            items.append(("plugin", plugin_name, f"v{version}"))

    if not items:
        console.print("[yellow]No removable components found.[/yellow]")
        return [], []

    for i, (item_type, name, details) in enumerate(items):
        table.add_row(f"{i + 1}.", item_type, name, details)

    panel = Panel(table, title="[bold]Installed Components[/bold]", border_style="blue")
    console.print(panel)

    console.print()
    console.print(
        "[dim]Enter numbers separated by spaces (e.g., '1 3'), "
        "'a' for all, or press Enter to cancel:[/dim]",
    )
    console.print()

    try:
        line = inp.readline().strip().lower()
    except (EOFError, KeyboardInterrupt):
        return [], []

    if not line:
        return [], []

    if line == "a":
        plugins = [name for typ, name, _ in items if typ == "plugin"]
        layer_types = [name for typ, name, _ in items if typ == "layer_type"]
        return plugins, layer_types

    # Parse numbers
    selected_plugins: list[str] = []
    selected_layer_types: list[str] = []

    for part in line.split():
        try:
            num = int(part)
            if 1 <= num <= len(items):
                item_type, name, _ = items[num - 1]
                if item_type == "plugin" and name not in selected_plugins:
                    selected_plugins.append(name)
                elif item_type == "layer_type" and name not in selected_layer_types:
                    selected_layer_types.append(name)
        except ValueError:
            continue

    return selected_plugins, selected_layer_types


def _print_not_initialized(stream: TextIO) -> None:
    """Print message when not initialized."""
    stream.write("Error: Repository not initialized.\n")
    stream.write("\n")
    stream.write("Run 'kata tax init' first to initialize a taxonomy repository.\n")


def _print_not_installed(result: RemoveResult, stream: TextIO) -> None:
    """Print message when components are not installed."""
    stream.write("\n")
    stream.write("Katalyst Remove\n")
    stream.write("=" * 40 + "\n\n")
    stream.write("The following components are not installed:\n\n")
    for name in result.not_found:
        stream.write(f"  - {name}\n")
    stream.write("\n")


def _print_success(result: RemoveResult, stream: TextIO) -> None:
    """Print success message."""
    stream.write("\n")
    stream.write("Katalyst Remove Complete\n")
    stream.write("=" * 40 + "\n\n")

    if result.removed:
        # Group by component type
        plugins = [c for c in result.removed if c.component_type == "plugin"]
        layer_types = [c for c in result.removed if c.component_type == "layer_type"]

        if plugins:
            stream.write("Removed plugins:\n\n")
            for component in plugins:
                stream.write(f"  - {component.name}\n")
            stream.write("\n")

        if layer_types:
            stream.write("Removed layer types:\n\n")
            for component in layer_types:
                stream.write(f"  - {component.name}\n")
            stream.write("\n")

    if result.not_found:
        stream.write("Not found (skipped):\n\n")
        for name in result.not_found:
            stream.write(f"  - {name}\n")
        stream.write("\n")

    stream.write("Run 'kata tax status' to see the current configuration.\n")
    stream.write("\n")


def _print_failed(result: RemoveResult, stream: TextIO) -> None:
    """Print failure message."""
    stream.write("Error: Remove failed.\n")
    if result.error:
        stream.write(f"Reason: {result.error}\n")


def _confirm_remove(
    plugins: tuple[str, ...],
    layer_types: tuple[str, ...],
    stream: TextIO,
    in_stream: TextIO,
) -> bool:
    """Prompt user to confirm remove operation.

    Args:
        plugins: Plugins to be removed.
        layer_types: Layer types to be removed.
        stream: Output stream.
        in_stream: Input stream for reading confirmation.

    Returns:
        True if user confirms, False otherwise.
    """
    stream.write("\nThe following will be removed:\n\n")
    if plugins:
        stream.write("  Plugins:\n")
        for p in plugins:
            stream.write(f"    - {p}\n")
    if layer_types:
        stream.write("  Layer types:\n")
        for lt in layer_types:
            stream.write(f"    - {lt}\n")
    stream.write("\n")
    stream.write("[bold red]This action cannot be undone.[/bold red]\n")
    stream.write("Proceed? [y/N] ")
    stream.flush()

    response = in_stream.readline().strip().lower()
    return response in ("y", "yes")


def run_remove(
    path: Path,
    *,
    plugins: tuple[str, ...] | None = None,
    layer_types: tuple[str, ...] | None = None,
    force: bool = False,
    yes: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
    in_stream: TextIO | None = None,
) -> int:
    """Run the remove command.

    Args:
        path: Path to the repository root.
        plugins: Plugin names to remove.
        layer_types: Layer type names to remove.
        force: If True, remove even if files are modified.
        yes: If True, skip confirmation prompts.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).
        in_stream: Input stream for interactive prompts.

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr
    inp: TextIO = in_stream if in_stream is not None else sys.stdin

    plugins = plugins or ()
    layer_types = layer_types or ()

    # If no components specified, offer interactive selection or show usage
    if not plugins and not layer_types:
        if not yes and sys.stdin.isatty():
            # Interactive mode - let user select components
            lock_path = path / ".global" / "taxonomy" / "taxonomy.lock"
            selected_plugins, selected_layer_types = _interactive_select_for_removal(
                lock_path,
                out,
                inp,
            )
            if not selected_plugins and not selected_layer_types:
                out.write("\nNo components selected. Remove cancelled.\n")
                return 0
            plugins = tuple(selected_plugins)
            layer_types = tuple(selected_layer_types)
        else:
            # Non-interactive - show usage
            err.write("Error: No plugins or layer types specified.\n")
            err.write("\n")
            err.write("Usage:\n")
            err.write("  kata tax remove --plugin <name>      Remove a plugin\n")
            err.write("  kata tax remove --layer-type <name>  Remove a layer type\n")
            err.write("\n")
            err.write("Run 'kata tax status' to see installed components.\n")
            return 1

    # Ask for confirmation if interactive
    if not yes and sys.stdin.isatty():
        if not _confirm_remove(plugins, layer_types, out, inp):
            out.write("\nRemove cancelled.\n")
            return 0

    # Create adapters
    filesystem = RealRemoveFilesystem()

    # Create service
    service = RemoveService(filesystem=filesystem)

    # Build config
    config = RemoveConfig(
        target_path=path,
        plugins=plugins,
        layer_types=layer_types,
        force=force,
        interactive=not yes,
    )

    # Run remove
    result = service.remove(config)

    # Handle result
    if result.status == RemoveStatus.NOT_INITIALIZED:
        _print_not_initialized(err)
        return 1

    if result.status == RemoveStatus.NOT_INSTALLED:
        _print_not_installed(result, out)
        return 0

    if result.status == RemoveStatus.SUCCESS:
        _print_success(result, out)
        return 0

    if result.status == RemoveStatus.FAILED:
        _print_failed(result, err)
        return 1

    # Should not reach here
    err.write(f"Unexpected status: {result.status}\n")
    return 1
