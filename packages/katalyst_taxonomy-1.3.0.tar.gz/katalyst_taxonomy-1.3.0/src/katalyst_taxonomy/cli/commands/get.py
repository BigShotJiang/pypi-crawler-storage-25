"""get command - retrieve a single taxonomy node."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.loaders import load_taxonomy
from katalyst_taxonomy.cli.output import write_error
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.services.serialization import serialize_document
from katalyst_taxonomy.services.taxonomy import TaxonomyService

# Format constants
FORMAT_JSON = "json"
FORMAT_LIST = "list"


def _output_json(
    doc: Document,
    service: TaxonomyService,
    out: TextIO,
    base_path: Path | None = None,
) -> None:
    """Output document as JSON."""
    payload = serialize_document(doc, service, base_path)
    json.dump(payload, out, indent=2)
    out.write("\n")


def _output_list(
    doc: Document,
    service: TaxonomyService,
    out: TextIO,
) -> None:
    """Output document in human-readable format."""
    fqtn = service.get_qualified_name(doc)

    out.write(f"Name:        {doc.metadata.name}\n")
    out.write(f"Type:        {doc.taxonomy_node_type}\n")
    out.write(f"Qualified:   {fqtn}\n")

    if doc.description:
        out.write(f"Description: {doc.description}\n")

    if doc.owners:
        out.write(f"Owners:      {', '.join(doc.owners)}\n")

    if doc.environments:
        out.write(f"Environments: {', '.join(doc.environments)}\n")

    if doc.parent is not None:
        out.write(f"Parent:      {doc.parent}\n")

    if doc.depends_on_nodes:
        out.write(f"Depends On:  {', '.join(doc.depends_on_nodes)}\n")

    if doc.metadata.labels:
        labels_str = ", ".join(f"{k}={v}" for k, v in doc.metadata.labels.items())
        out.write(f"Labels:      {labels_str}\n")

    if doc.source_path:
        out.write(f"Source:      {doc.source_path}\n")


def run_get(
    path: Path,
    name: str,
    output_format: str = FORMAT_JSON,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Execute the get command."""
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    try:
        service = load_taxonomy(path)
        base_path = path
    except FileNotFoundError as exc:
        write_error(str(exc), err)
        return 1
    except Exception as exc:
        write_error(f"Failed to load taxonomy: {exc}", err)
        return 1

    # Find the document by name
    doc = service.get_document_by_name(name)
    if doc is None:
        write_error(f"Node '{name}' not found", err)
        return 1

    # Output in requested format
    if output_format == FORMAT_JSON:
        _output_json(doc, service, out, base_path)
    elif output_format == FORMAT_LIST:
        _output_list(doc, service, out)
    else:
        write_error(f"Unknown format: {output_format}", err)
        return 1

    return 0
