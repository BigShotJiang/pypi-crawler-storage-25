"""server command - manage the katalyst server."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.output import colorize, write_error
from katalyst_taxonomy.server.manager import (
    DEFAULT_IDLE_TIMEOUT,
    ServerError,
    check_server_health,
    get_running_server,
    start_server,
    stop_server,
)


def run_server_start(
    path: Path,
    port: int | None = None,
    idle_timeout: int = DEFAULT_IDLE_TIMEOUT,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Start the server explicitly.

    Args:
        path: Path to the taxonomy directory.
        port: Port to bind to. If None, finds an available port.
        idle_timeout: Idle timeout in seconds.
        output: Output stream (default: stdout).
        err_output: Error output stream (default: stderr).

    Returns:
        Exit code (0 for success, 1 for error).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    try:
        state = start_server(path, port=port, idle_timeout=idle_timeout)
        out.write(f"Server started on {state.url}\n")
        out.write(f"  PID: {state.pid}\n")
        out.write(f"  Path: {state.path}\n")
        out.write(f"  Idle timeout: {idle_timeout}s\n")
        return 0
    except ServerError as e:
        write_error(str(e), err)
        return 1


def run_server_stop(
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Stop the running server.

    Args:
        output: Output stream (default: stdout).
        err_output: Error output stream (default: stderr).

    Returns:
        Exit code (0 for success, 1 if no server running).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    stopped = stop_server(force=True)
    if stopped:
        out.write("Server stopped\n")
        return 0
    write_error("No server is running", err)
    return 1


def run_server_status(
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Show the server status.

    Args:
        output: Output stream (default: stdout).
        err_output: Error output stream (default: stderr).

    Returns:
        Exit code (0 for running, 1 for not running).
    """
    out: TextIO = output if output is not None else sys.stdout

    state = get_running_server()
    if state is None:
        out.write("Server is not running\n")
        return 1

    healthy = check_server_health(state.host, state.port)
    status_text = (
        colorize("healthy", "green", out) if healthy else colorize("unhealthy", "red", out)
    )

    out.write(f"Server is running ({status_text})\n")
    out.write(f"  URL: {state.url}\n")
    out.write(f"  PID: {state.pid}\n")
    out.write(f"  Path: {state.path}\n")
    out.write(f"  Started: {state.started_at}\n")
    return 0


def run_server_restart(
    path: Path,
    port: int | None = None,
    idle_timeout: int = DEFAULT_IDLE_TIMEOUT,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Restart the server.

    Args:
        path: Path to the taxonomy directory.
        port: Port to bind to. If None, uses existing port or finds available.
        idle_timeout: Idle timeout in seconds.
        output: Output stream (default: stdout).
        err_output: Error output stream (default: stderr).

    Returns:
        Exit code (0 for success, 1 for error).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Get existing state for port reuse
    existing = get_running_server()
    if existing and port is None:
        port = existing.port

    # Stop existing server
    stop_server(force=True)

    try:
        state = start_server(path, port=port, idle_timeout=idle_timeout)
        out.write(f"Server restarted on {state.url}\n")
        out.write(f"  PID: {state.pid}\n")
        out.write(f"  Path: {state.path}\n")
        return 0
    except ServerError as e:
        write_error(str(e), err)
        return 1


def run_server(
    action: str,
    path: Path,
    port: int | None = None,
    idle_timeout: int = DEFAULT_IDLE_TIMEOUT,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Execute server subcommand.

    Args:
        action: The server action (start, stop, status, restart).
        path: Path to the taxonomy directory.
        port: Port to bind to (for start/restart).
        idle_timeout: Idle timeout in seconds (for start/restart).
        output: Output stream (default: stdout).
        err_output: Error output stream (default: stderr).

    Returns:
        Exit code.
    """
    err: TextIO = err_output if err_output is not None else sys.stderr

    if action == "start":
        return run_server_start(path, port, idle_timeout, output, err_output)
    if action == "stop":
        return run_server_stop(output, err_output)
    if action == "status":
        return run_server_status(output, err_output)
    if action == "restart":
        return run_server_restart(path, port, idle_timeout, output, err_output)
    write_error(f"Unknown server action: {action}", err)
    return 1
