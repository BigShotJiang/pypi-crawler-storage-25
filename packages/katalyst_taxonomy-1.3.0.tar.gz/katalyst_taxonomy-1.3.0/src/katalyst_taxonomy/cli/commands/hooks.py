"""CLI command for git hooks management."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import IO


def run_hooks_detect_tool(
    path: Path,
    out: IO[str] = sys.stdout,
    err: IO[str] = sys.stderr,
) -> int:
    """Detect the configured hook tool from .katalyst-hooks.yaml."""
    from katalyst_taxonomy.services.hooks import detect_tool

    tool = detect_tool(path)
    if tool is None:
        err.write("Error: no hooks config found (.katalyst-hooks.yaml)\n")
        return 1

    out.write(f"{tool}\n")
    return 0


def run_hooks_generate(
    path: Path,
    tool_override: str | None = None,
    out: IO[str] = sys.stdout,
    err: IO[str] = sys.stderr,
) -> int:
    """Generate native hook tool config from .katalyst-hooks.yaml."""
    from katalyst_taxonomy.services.hooks import generate_native_config

    return generate_native_config(path, tool_override=tool_override, out=out, err=err)


def run_hooks_validate(
    path: Path,
    out: IO[str] = sys.stdout,
    err: IO[str] = sys.stderr,
) -> int:
    """Validate hooks config against installed actions."""
    from katalyst_taxonomy.services.hooks import validate_hooks_config

    return validate_hooks_config(path, out=out, err=err)


def run_hooks_run(
    path: Path,
    actions: list[str],
    files: list[str],
    *,
    dry_run: bool = False,
    environment: str | None = None,
    out: IO[str] = sys.stdout,
    err: IO[str] = sys.stderr,
) -> int:
    """Run kata actions against layers affected by the given files."""
    from katalyst_taxonomy.services.hooks import run_hooks

    return run_hooks(
        path,
        actions,
        files,
        dry_run=dry_run,
        environment=environment,
        out=out,
        err=err,
    )
