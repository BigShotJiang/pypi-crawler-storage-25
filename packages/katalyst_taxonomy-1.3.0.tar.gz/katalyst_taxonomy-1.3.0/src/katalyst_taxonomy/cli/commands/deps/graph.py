"""Dependency graph building logic.

.. deprecated::
    This module has been relocated to ``katalyst_taxonomy.services.deps``.
    Import directly from there instead. This file will be removed in a future version.
"""

from __future__ import annotations

from katalyst_taxonomy.services.deps import (
    build_dependency_graph,
    detect_cycles,
    resolve_dependency,
)

__all__ = ["build_dependency_graph", "detect_cycles", "resolve_dependency"]
