"""Output formatters for the dependency graph."""

from __future__ import annotations

import json
from typing import Any, TextIO

from katalyst_taxonomy.cli.output import (
    HEADING_COLOR,
    colorize,
    write_heading,
)
from katalyst_taxonomy.domain.deps import DependencyGraph
from katalyst_taxonomy.services.taxonomy import TaxonomyService


def output_tree(
    graph: DependencyGraph,
    service: TaxonomyService,
    node_filter: str | None,
    reverse: bool,
    out: TextIO,
) -> None:
    """Output dependency graph as a tree.

    Args:
        graph: The dependency graph.
        service: The taxonomy service.
        node_filter: Optional node name/FQTN to filter to.
        reverse: If True, show dependents (what depends on this) instead of dependencies.
        out: Output stream.
    """
    if not graph.nodes:
        out.write("No taxonomy documents found.\n")
        return

    # Determine which nodes to show
    if node_filter:
        # Find matching node
        root_nodes = [
            fqtn
            for fqtn in graph.nodes
            if fqtn == node_filter or graph.nodes[fqtn].name == node_filter
        ]
        if not root_nodes:
            out.write(f"Node '{node_filter}' not found.\n")
            return
    else:
        # Show all nodes that have dependencies or dependents
        if reverse:
            root_nodes = sorted(
                [fqtn for fqtn, node in graph.nodes.items() if node.dependents],
                key=lambda f: (graph.nodes[f].node_type, f),
            )
        else:
            root_nodes = sorted(
                [fqtn for fqtn, node in graph.nodes.items() if node.dependencies],
                key=lambda f: (graph.nodes[f].node_type, f),
            )

    if not root_nodes:
        direction = "dependents" if reverse else "dependencies"
        out.write(f"No nodes with {direction} found.\n")
        return

    direction_label = "Dependents (what depends on this)" if reverse else "Dependencies"
    write_heading(f"Dependency Graph ({direction_label})", out)
    out.write("\n")

    for root in root_nodes:
        _print_dependency_tree(graph, root, reverse, out, set(), "")
        out.write("\n")


def _print_dependency_tree(
    graph: DependencyGraph,
    fqtn: str,
    reverse: bool,
    out: TextIO,
    visited: set[str],
    prefix: str,
) -> None:
    """Recursively print a dependency tree.

    Args:
        graph: The dependency graph.
        fqtn: Current node FQTN.
        reverse: If True, traverse dependents instead of dependencies.
        out: Output stream.
        visited: Set of already visited nodes (to detect cycles in output).
        prefix: Current line prefix for tree formatting.
    """
    node = graph.nodes.get(fqtn)
    if not node:
        return

    # Print current node
    type_label = f"[{node.node_type}]"
    cycle_marker = " (cycle)" if fqtn in visited else ""
    out.write(f"{prefix}{node.name} {type_label}{cycle_marker}\n")

    if fqtn in visited:
        return

    visited = visited | {fqtn}

    # Get children (dependencies or dependents)
    children = node.dependents if reverse else node.dependencies

    for i, child in enumerate(sorted(children)):
        is_last = i == len(children) - 1
        connector = "\u2514\u2500\u2500 " if is_last else "\u251c\u2500\u2500 "
        extension = "    " if is_last else "\u2502   "
        out.write(f"{prefix}{connector}")
        _print_dependency_tree(graph, child, reverse, out, visited, prefix + extension)


def output_list(
    graph: DependencyGraph,
    service: TaxonomyService,
    out: TextIO,
) -> None:
    """Output dependency graph as a list.

    Args:
        graph: The dependency graph.
        service: The taxonomy service.
        out: Output stream.
    """
    if not graph.nodes:
        out.write("No taxonomy documents found.\n")
        return

    write_heading("Dependency Summary", out)
    out.write("\n")

    # Nodes with dependencies
    with_deps = [(fqtn, node) for fqtn, node in graph.nodes.items() if node.dependencies]
    with_deps.sort(key=lambda x: (x[1].node_type, x[0]))

    if with_deps:
        out.write(colorize("Nodes with dependencies:\n", HEADING_COLOR, out))
        for fqtn, node in with_deps:
            deps_str = ", ".join(sorted(node.dependencies))
            out.write(f"  {fqtn} [{node.node_type}]\n")
            out.write(f"    \u2192 {deps_str}\n")
        out.write("\n")

    # Nodes that are depended upon
    with_dependents = [(fqtn, node) for fqtn, node in graph.nodes.items() if node.dependents]
    with_dependents.sort(key=lambda x: (-len(x[1].dependents), x[0]))

    if with_dependents:
        out.write(colorize("Most depended-upon nodes:\n", HEADING_COLOR, out))
        for fqtn, node in with_dependents[:10]:  # Top 10
            out.write(f"  {fqtn} [{node.node_type}] - {len(node.dependents)} dependent(s)\n")
        out.write("\n")

    # Summary stats
    total_deps = sum(len(n.dependencies) for n in graph.nodes.values())
    nodes_with_deps = len([n for n in graph.nodes.values() if n.dependencies])
    out.write(f"Total: {total_deps} dependencies across {nodes_with_deps} nodes\n")


def output_json(
    graph: DependencyGraph,
    service: TaxonomyService,
    out: TextIO,
) -> None:
    """Output dependency graph as JSON.

    Args:
        graph: The dependency graph.
        service: The taxonomy service.
        out: Output stream.
    """
    nodes_data: list[dict[str, Any]] = []

    for fqtn, node in sorted(graph.nodes.items()):
        node_data: dict[str, Any] = {
            "fqtn": fqtn,
            "name": node.name,
            "type": node.node_type,
            "dependencies": sorted(node.dependencies),
            "dependents": sorted(node.dependents),
        }
        nodes_data.append(node_data)

    output: dict[str, Any] = {
        "nodes": nodes_data,
        "cycles": graph.cycles,
        "unresolved": {k: sorted(v) for k, v in sorted(graph.unresolved.items())},
        "summary": {
            "totalNodes": len(graph.nodes),
            "totalDependencies": sum(len(n.dependencies) for n in graph.nodes.values()),
            "nodesWithDependencies": len([n for n in graph.nodes.values() if n.dependencies]),
            "nodesWithDependents": len([n for n in graph.nodes.values() if n.dependents]),
            "cycleCount": len(graph.cycles),
            "unresolvedCount": sum(len(v) for v in graph.unresolved.values()),
        },
    }

    json.dump(output, out, indent=2)
    out.write("\n")


def output_mermaid(
    graph: DependencyGraph,
    service: TaxonomyService,
    node_filter: str | None,
    out: TextIO,
) -> None:
    """Output dependency graph as a Mermaid diagram.

    Args:
        graph: The dependency graph.
        service: The taxonomy service.
        node_filter: Optional node to focus on.
        out: Output stream.
    """
    out.write("```mermaid\ngraph LR\n")

    # Collect relevant nodes
    if node_filter:
        # Find the node and its direct connections
        target_nodes = {
            fqtn
            for fqtn in graph.nodes
            if fqtn == node_filter or graph.nodes[fqtn].name == node_filter
        }
        if not target_nodes:
            out.write(f"  %% Node '{node_filter}' not found\n")
            out.write("```\n")
            return

        # Include dependencies and dependents
        relevant: set[str] = set()
        for fqtn in target_nodes:
            relevant.add(fqtn)
            relevant.update(graph.nodes[fqtn].dependencies)
            relevant.update(graph.nodes[fqtn].dependents)
    else:
        # All nodes with dependencies
        relevant = {
            fqtn for fqtn, node in graph.nodes.items() if node.dependencies or node.dependents
        }

    if not relevant:
        out.write("  %% No dependencies found\n")
        out.write("```\n")
        return

    # Define node styles by type
    type_styles = {
        "system": ":::system",
        "stack": ":::stack",
        "layer": ":::layer",
    }

    # Output nodes
    for fqtn in sorted(relevant):
        node = graph.nodes[fqtn]
        # Sanitize node ID for Mermaid (replace dots with underscores)
        node_id = fqtn.replace(".", "_").replace("-", "_")
        style = type_styles.get(node.node_type, "")
        out.write(f"  {node_id}[{node.name}]{style}\n")

    out.write("\n")

    # Output edges
    edges_written: set[tuple[str, str]] = set()
    for fqtn in relevant:
        node = graph.nodes[fqtn]
        from_id = fqtn.replace(".", "_").replace("-", "_")
        for dep in node.dependencies:
            if dep in relevant:
                to_id = dep.replace(".", "_").replace("-", "_")
                edge = (from_id, to_id)
                if edge not in edges_written:
                    out.write(f"  {from_id} --> {to_id}\n")
                    edges_written.add(edge)

    # Add style definitions
    out.write("\n")
    out.write("  classDef system fill:#e1f5fe,stroke:#01579b\n")
    out.write("  classDef system fill:#e3f2fd,stroke:#0d47a1\n")
    out.write("  classDef stack fill:#e8f5e9,stroke:#1b5e20\n")
    out.write("  classDef layer fill:#fff3e0,stroke:#e65100\n")
    out.write("```\n")
