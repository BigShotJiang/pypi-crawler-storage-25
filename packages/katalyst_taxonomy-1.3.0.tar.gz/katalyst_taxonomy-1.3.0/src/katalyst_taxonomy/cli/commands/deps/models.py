"""Data models for the dependency graph.

.. deprecated::
    This module has been relocated to ``katalyst_taxonomy.domain.deps``.
    Import directly from there instead. This file will be removed in a future version.
"""

from __future__ import annotations

from katalyst_taxonomy.domain.deps import DependencyGraph, DependencyNode

__all__ = ["DependencyGraph", "DependencyNode"]
