"""CLI command for resolving file paths to taxonomy layers."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import IO


def run_resolve(
    path: Path,
    files: list[str],
    out: IO[str] = sys.stdout,
    err: IO[str] = sys.stderr,
) -> int:
    """Resolve file paths to their parent taxonomy layers.

    Returns 0 on success, 1 on error.
    """
    from katalyst_taxonomy.services.resolve import resolve_affected_layers

    if not files:
        err.write("Error: no files provided. Use --files <file1> [file2] ...\n")
        return 1

    result = resolve_affected_layers(files, path)

    output = {
        "layers": [
            {
                "fqtn": layer.fqtn,
                "layerType": layer.layer_type,
                "layerDir": layer.layer_dir,
                "changedFiles": list(layer.changed_files),
            }
            for layer in result.layers
        ],
        "unmapped": list(result.unmapped),
    }

    out.write(json.dumps(output, indent=2) + "\n")
    return 0
