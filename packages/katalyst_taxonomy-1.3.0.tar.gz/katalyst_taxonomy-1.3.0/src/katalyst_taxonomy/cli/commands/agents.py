"""agents command - manage AI coding assistant definitions.

This module provides CLI commands for managing agents and skills defined
in the .agents/ directory:

  kata tax agents init       Initialize .agents/ directory and create symlinks
  kata tax agents list       List all agents and skills
  kata tax agents show       Show details of a specific agent/skill
  kata tax agents validate   Validate all agent definitions
  kata tax agents sync       Sync bundled agents/skills into local .agents/
"""

from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any, TextIO, cast

from loguru import logger

from katalyst_taxonomy.agents.bundled import copy_bundled_to, scan_bundled
from katalyst_taxonomy.agents.discovery import (
    AgentsDirectory,
    discover_agents_directory,
    find_git_root,
    scan_agents_directory,
)
from katalyst_taxonomy.agents.models import Agent, AgentsConfig, Scope, Skill
from katalyst_taxonomy.agents.parser import serialize_agent, serialize_config
from katalyst_taxonomy.agents.resolution import resolve_for_layer_type
from katalyst_taxonomy.agents.symlinks import (
    check_symlinks,
    create_symlinks,
)

__all__ = [
    "run_agents_create",
    "run_agents_generate",
    "run_agents_init",
    "run_agents_list",
    "run_agents_show",
    "run_agents_sync",
    "run_agents_validate",
]


# ─────────────────────────────────────────────────────────────────────────────
# AGENT TEMPLATES (Built-in)
# ─────────────────────────────────────────────────────────────────────────────

# Templates for generating agents, keyed by template name
AGENT_TEMPLATES: dict[str, dict[str, object]] = {
    "layer-helper": {
        "name_suffix": "-helper",
        "description": "Use this agent when working with {layer_type} layers",
        "mode": "subagent",
        "tools": {"read": True, "edit": True, "bash": True},
        "prompt": """# {layer_type_title} Layer Helper

You are a specialized assistant for working with **{layer_type}** layers in the Katalyst taxonomy.

## Reference Material

Load the `katalyst-{layer_type}` skill for detailed reference material about this layer type's directory structure, available actions, patterns, and troubleshooting guides.

## Your Responsibilities

1. **Understand the layer structure** - Know the typical files and directories in {layer_type} layers
2. **Follow best practices** - Apply {layer_type}-specific patterns and conventions
3. **Assist with common tasks** - Help with configuration, deployment, and troubleshooting

## Layer Type Context

This agent is scoped to `{layer_type}` layers. When activated, focus on:
- Files specific to this layer type
- Configuration patterns for {layer_type}
- Common issues and their solutions

## Guidelines

- Always check the layer's `layer.yaml` for context
- Respect the taxonomy structure and naming conventions
- Suggest improvements that align with the layer type's purpose
""",
    },
    "code-reviewer": {
        "name_suffix": "-reviewer",
        "description": "Use this agent to review code changes in {layer_type} layers",
        "mode": "subagent",
        "tools": {"read": True, "edit": False, "bash": False},
        "prompt": """# {layer_type_title} Code Reviewer

You are a code review specialist for **{layer_type}** layers.

## Reference Material

Load the `katalyst-{layer_type}` skill for detailed reference material about this layer type's directory structure, available actions, patterns, and troubleshooting guides.

## Review Focus Areas

1. **Code Quality** - Check for clean, maintainable code
2. **Best Practices** - Ensure {layer_type}-specific patterns are followed
3. **Security** - Identify potential security issues
4. **Performance** - Spot performance concerns
5. **Documentation** - Verify adequate comments and docs

## Review Guidelines

- Be constructive and specific in feedback
- Provide examples when suggesting improvements
- Prioritize issues by severity (critical, major, minor)
- Consider the layer's purpose within the taxonomy

## Layer Type Context

This reviewer is specialized for `{layer_type}` layers and understands:
- Typical file structures
- Common configuration patterns
- Expected testing approaches
""",
    },
    "debugger": {
        "name_suffix": "-debugger",
        "description": "Use this agent to debug issues in {layer_type} layers",
        "mode": "subagent",
        "tools": {"read": True, "edit": True, "bash": True},
        "prompt": """# {layer_type_title} Debugger

You are a debugging specialist for **{layer_type}** layers.

## Reference Material

Load the `katalyst-{layer_type}` skill for detailed reference material about this layer type's directory structure, available actions, patterns, and troubleshooting guides.

## Debugging Approach

1. **Gather Information** - Collect logs, error messages, and context
2. **Reproduce the Issue** - Understand the steps to reproduce
3. **Isolate the Problem** - Narrow down the root cause
4. **Propose Solutions** - Suggest fixes with clear explanations
5. **Verify the Fix** - Ensure the solution works

## Common {layer_type_title} Issues

Be aware of typical problems in {layer_type} layers:
- Configuration errors
- Dependency issues
- Environment-specific problems
- Integration failures

## Guidelines

- Ask clarifying questions before diving in
- Check logs and error outputs first
- Consider the layer's dependencies and integrations
- Document the fix for future reference
""",
    },
}


# ─────────────────────────────────────────────────────────────────────────────
# INIT COMMAND
# ─────────────────────────────────────────────────────────────────────────────


def run_agents_init(
    path: Path,
    *,
    force: bool = False,
    no_seed: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Initialize .agents/ directory, seed bundled agents, and create OpenCode symlinks.

    Creates the following structure:
        .agents/
        ├── agents.yaml       # Configuration file
        ├── agents/           # Agent definitions (seeded from bundled)
        ├── skills/           # Skill packages (seeded from bundled)
        └── context/          # Context rules

        .opencode/
        ├── agents -> ../.agents/agents
        └── skills -> ../.agents/skills

    Args:
        path: Repository root path.
        force: If True, overwrite existing files/symlinks.
        no_seed: If True, skip seeding bundled agents/skills.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Find git root
    git_root = find_git_root(path)
    if git_root:
        root = git_root
        logger.debug(f"Using git root: {root}")
    else:
        root = path.resolve()
        logger.debug(f"Not in git repo, using path: {root}")

    agents_dir = root / ".agents"

    # Check if already initialized
    if agents_dir.exists() and not force:
        existing = scan_agents_directory(agents_dir, include_bundled=False)
        out.write("Agents directory already initialized.\n")
        out.write(f"  Path: {agents_dir}\n")
        out.write(f"  Agents: {len(existing.agents)}\n")
        out.write(f"  Skills: {len(existing.skills)}\n")
        out.write("\nUse --force to reinitialize.\n")
        return 0

    # Create directory structure
    out.write("Initializing .agents/ directory...\n\n")

    try:
        agents_dir.mkdir(parents=True, exist_ok=True)
        (agents_dir / "agents").mkdir(exist_ok=True)
        (agents_dir / "skills").mkdir(exist_ok=True)
        (agents_dir / "context").mkdir(exist_ok=True)

        out.write("  Created .agents/\n")
        out.write("  Created .agents/agents/\n")
        out.write("  Created .agents/skills/\n")
        out.write("  Created .agents/context/\n")

    except OSError as e:
        err.write(f"Error creating directories: {e}\n")
        return 1

    # Create default config file
    config_path = agents_dir / "agents.yaml"
    if not config_path.exists() or force:
        default_config = AgentsConfig(
            version="1",
        )
        config_content = serialize_config(default_config)
        config_path.write_text(config_content, encoding="utf-8")
        out.write("  Created .agents/agents.yaml\n")

    # Seed bundled agents and skills
    if not no_seed:
        out.write("\nSeeding bundled agents and skills...\n")
        try:
            sync_result = copy_bundled_to(agents_dir, force=force)
            if sync_result.agents_copied:
                out.write(f"  Seeded {len(sync_result.agents_copied)} agent(s)\n")
            if sync_result.skills_copied:
                out.write(f"  Seeded {len(sync_result.skills_copied)} skill(s)\n")
            if sync_result.agents_skipped:
                out.write(f"  Skipped {len(sync_result.agents_skipped)} existing agent(s)\n")
            if sync_result.skills_skipped:
                out.write(f"  Skipped {len(sync_result.skills_skipped)} existing skill(s)\n")
            if sync_result.total_copied == 0 and sync_result.total_skipped == 0:
                out.write("  No bundled content available.\n")
        except FileNotFoundError:
            out.write("  No bundled content available (package may be incomplete).\n")

    # Detect installed layer types and report matching skills
    _report_layer_type_skills(root, agents_dir, out)

    # Create symlinks
    out.write("\nCreating OpenCode symlinks...\n")
    results = create_symlinks(agents_dir, force=force)

    for result in results:
        if result.is_ok:
            out.write(f"  {result.name}: {result.message}\n")
        else:
            err.write(f"  {result.name}: {result.message}\n")

    # Check for errors
    errors = [r for r in results if not r.is_ok]
    if errors:
        err.write(f"\nWarning: {len(errors)} symlink(s) could not be created.\n")
        err.write("Use --force to overwrite existing files.\n")

    out.write("\nAgents directory initialized successfully.\n")
    out.write("\nNext steps:\n")
    out.write("  - Run 'kata tax agents list' to see available agents\n")
    out.write("  - Customize agents in .agents/agents/\n")
    out.write("  - Run 'kata tax agents validate' to check for errors\n")

    return 0


# ─────────────────────────────────────────────────────────────────────────────
# LAYER-TYPE SKILL DETECTION
# ─────────────────────────────────────────────────────────────────────────────


# Canonical layer-type skill naming convention: katalyst-<layer-type>
_LAYER_TYPE_SKILL_PREFIX = "katalyst-"


def _report_layer_type_skills(
    root: Path,
    agents_dir: Path,
    out: TextIO,
) -> None:
    """Detect installed layer types and report matching skills.

    Best-effort: any failure is silently ignored (this is informational only).
    """
    try:
        from katalyst_taxonomy.services.template_service import load_layer_types

        result = load_layer_types(root)
        if not result.definitions:
            return

        layer_type_names = [d.name for d in result.definitions]
        skills_dir = agents_dir / "skills"

        # Find matching skills for detected layer types
        matches: list[tuple[str, str]] = []  # (skill_name, layer_type)
        for lt in layer_type_names:
            skill_name = f"{_LAYER_TYPE_SKILL_PREFIX}{lt}"
            if (skills_dir / skill_name / "SKILL.md").is_file():
                matches.append((skill_name, lt))

        if matches:
            out.write("\nLayer-type skills detected:\n")
            for skill_name, lt in matches:
                out.write(f"  - {skill_name} ({lt})\n")
        elif layer_type_names:
            out.write(f"\nLayer types found: {', '.join(layer_type_names)}\n")
            out.write("  Run 'kata tax agents sync' to install matching layer-type skills.\n")
    except Exception:
        # Best-effort: taxonomy may not be initialized yet
        logger.debug("Could not detect layer types during agents init")


# ─────────────────────────────────────────────────────────────────────────────
# LIST COMMAND
# ─────────────────────────────────────────────────────────────────────────────


def _format_agent_row(agent: Agent, verbose: bool = False) -> str:
    """Format an agent for display."""
    mode = f"[{agent.mode}]" if agent.mode != "all" else ""
    source_tag = f"({agent.source})" if agent.source == "bundled" else ""
    desc = agent.description.split("\n")[0][:60]
    if len(agent.description) > 60:
        desc += "..."

    if verbose:
        path = str(agent.source_path) if agent.source_path else "unknown"
        return f"  {agent.name:<25} {mode:<12} {source_tag:<10} {desc}\n    Path: {path}"
    return f"  {agent.name:<25} {mode:<12} {source_tag:<10} {desc}"


def _format_skill_row(skill: Skill, verbose: bool = False) -> str:
    """Format a skill for display."""
    source_tag = f"({skill.source})" if skill.source == "bundled" else ""
    desc = skill.description[:60]
    if len(skill.description) > 60:
        desc += "..."

    if verbose:
        path = str(skill.source_path) if skill.source_path else "unknown"
        return f"  {skill.name:<25} {source_tag:<10} {desc}\n    Path: {path}"
    return f"  {skill.name:<25} {source_tag:<10} {desc}"


def run_agents_list(
    path: Path,
    *,
    format: str = "table",
    verbose: bool = False,
    layer_type: str | None = None,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """List all agents and skills.

    Args:
        path: Repository root path.
        format: Output format ("table" or "json").
        verbose: Show additional details.
        layer_type: Filter results to those matching a specific layer type.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Discover agents directory
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        err.write("No .agents/ directory found.\n")
        err.write("Run 'kata tax agents init' to initialize.\n")
        return 1

    # Scan directory
    directory = scan_agents_directory(agents_dir)

    # Apply layer-type filter if specified
    if layer_type:
        bindings = directory.config.bindings if directory.config else None
        resolved = resolve_for_layer_type(
            layer_type,
            agents=directory.agents,
            skills=directory.skills,
            bindings=bindings,
        )
        directory.agents = list(resolved.agents)
        directory.skills = list(resolved.skills)

    if format == "json":
        return _list_json(directory, out, layer_type=layer_type)

    return _list_table(directory, verbose, out, err, layer_type=layer_type)


def _list_table(
    directory: AgentsDirectory,
    verbose: bool,
    out: TextIO,
    err: TextIO,
    *,
    layer_type: str | None = None,
) -> int:
    """List agents/skills in table format."""
    out.write(f"Agents Directory: {directory.path}\n")
    if layer_type:
        out.write(f"Filtered by layer type: {layer_type}\n")
    out.write("\n")

    # Agents section
    if directory.agents:
        out.write(f"Agents ({len(directory.agents)}):\n")
        out.write(f"  {'NAME':<25} {'MODE':<12} {'SOURCE':<10} DESCRIPTION\n")
        out.write(f"  {'-' * 25} {'-' * 10}   {'-' * 8}   {'-' * 40}\n")
        for agent in directory.agents:
            out.write(_format_agent_row(agent, verbose) + "\n")
        out.write("\n")
    else:
        out.write("No agents found.\n\n")

    # Skills section
    if directory.skills:
        out.write(f"Skills ({len(directory.skills)}):\n")
        out.write(f"  {'NAME':<25} {'SOURCE':<10} DESCRIPTION\n")
        out.write(f"  {'-' * 25} {'-' * 8}   {'-' * 40}\n")
        for skill in directory.skills:
            out.write(_format_skill_row(skill, verbose) + "\n")
        out.write("\n")
    else:
        out.write("No skills found.\n\n")

    # Errors section
    if directory.errors:
        err.write(f"Parse Errors ({len(directory.errors)}):\n")
        for error in directory.errors:
            err.write(f"  - {error}\n")
        err.write("\n")

    # Symlink status
    results = check_symlinks(directory.path)
    issues = [r for r in results if not r.is_ok]
    if issues:
        err.write("Symlink Issues:\n")
        for result in issues:
            err.write(f"  - {result.name}: {result.message}\n")
        err.write("\nRun 'kata tax agents init --force' to fix symlinks.\n")

    return 0


def _list_json(
    directory: AgentsDirectory,
    out: TextIO,
    *,
    layer_type: str | None = None,
) -> int:
    """List agents/skills in JSON format."""
    import json

    data: dict[str, object] = {
        "path": str(directory.path),
        "agents": [
            {
                "name": a.name,
                "description": a.description,
                "mode": a.mode,
                "source": a.source,
                "path": str(a.source_path) if a.source_path else None,
            }
            for a in directory.agents
        ],
        "skills": [
            {
                "name": s.name,
                "description": s.description,
                "source": s.source,
                "path": str(s.source_path) if s.source_path else None,
            }
            for s in directory.skills
        ],
        "errors": [str(e) for e in directory.errors],
    }
    if layer_type:
        data["layer_type"] = layer_type

    out.write(json.dumps(data, indent=2) + "\n")
    return 0


# ─────────────────────────────────────────────────────────────────────────────
# SHOW COMMAND
# ─────────────────────────────────────────────────────────────────────────────


def run_agents_show(
    path: Path,
    name: str,
    *,
    format: str = "table",
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Show details of a specific agent or skill.

    Args:
        path: Repository root path.
        name: Name of the agent or skill to show.
        format: Output format ("table" or "json").
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Discover agents directory
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        err.write("No .agents/ directory found.\n")
        return 1

    # Scan directory
    directory = scan_agents_directory(agents_dir)

    # Find agent or skill
    agent = directory.get_agent(name)
    skill = directory.get_skill(name)

    if not agent and not skill:
        err.write(f"Agent or skill '{name}' not found.\n")
        err.write("\nAvailable agents:\n")
        for a in directory.agents:
            err.write(f"  - {a.name}\n")
        err.write("\nAvailable skills:\n")
        for s in directory.skills:
            err.write(f"  - {s.name}\n")
        return 1

    if format == "json":
        return _show_json(agent, skill, out)

    return _show_table(agent, skill, out)


def _show_table(agent: Agent | None, skill: Skill | None, out: TextIO) -> int:
    """Show agent/skill in table format."""
    if agent:
        out.write(f"Agent: {agent.name}\n")
        out.write("=" * 60 + "\n\n")

        out.write(f"Description:\n  {agent.description}\n\n")
        out.write(f"Mode: {agent.mode}\n")
        out.write(f"Source: {agent.source}\n")

        if agent.temperature is not None:
            out.write(f"Temperature: {agent.temperature}\n")
        if agent.model:
            out.write(f"Model: {agent.model}\n")
        if agent.max_steps:
            out.write(f"Max Steps: {agent.max_steps}\n")

        if agent.tools:
            out.write("\nTools:\n")
            for tool, enabled in sorted(agent.tools.items()):
                status = "enabled" if enabled else "disabled"
                out.write(f"  {tool}: {status}\n")

        perm = agent.permission.to_dict()
        if perm:
            out.write("\nPermissions:\n")
            for key, value in perm.items():
                out.write(f"  {key}: {value}\n")

        scope = agent.scope.to_dict()
        if scope:
            out.write("\nScope:\n")
            for key, value in scope.items():
                out.write(f"  {key}: {value}\n")

        if agent.source_path:
            out.write(f"\nSource: {agent.source_path}\n")

        if agent.prompt:
            out.write("\n" + "-" * 60 + "\n")
            out.write("Prompt:\n")
            out.write("-" * 60 + "\n")
            out.write(agent.prompt[:2000])
            if len(agent.prompt) > 2000:
                out.write("\n... (truncated)")
            out.write("\n")

    if skill:
        out.write(f"Skill: {skill.name}\n")
        out.write("=" * 60 + "\n\n")

        out.write(f"Description:\n  {skill.description}\n\n")
        out.write(f"Origin: {skill.source}\n")

        if skill.license:
            out.write(f"License: {skill.license}\n")
        if skill.compatibility:
            out.write(f"Compatibility: {', '.join(skill.compatibility)}\n")

        if skill.source_path:
            out.write(f"\nSource: {skill.source_path}\n")

        if skill.content:
            out.write("\n" + "-" * 60 + "\n")
            out.write("Content:\n")
            out.write("-" * 60 + "\n")
            out.write(skill.content[:2000])
            if len(skill.content) > 2000:
                out.write("\n... (truncated)")
            out.write("\n")

    return 0


def _show_json(agent: Agent | None, skill: Skill | None, out: TextIO) -> int:
    """Show agent/skill in JSON format."""
    import json

    if agent:
        data = {
            "type": "agent",
            "name": agent.name,
            "description": agent.description,
            "mode": agent.mode,
            "source": agent.source,
            "temperature": agent.temperature,
            "model": agent.model,
            "maxSteps": agent.max_steps,
            "hidden": agent.hidden,
            "disabled": agent.disabled,
            "tools": agent.tools,
            "permission": agent.permission.to_dict(),
            "scope": agent.scope.to_dict(),
            "metadata": agent.metadata,
            "path": str(agent.source_path) if agent.source_path else None,
            "prompt": agent.prompt,
        }
    elif skill:
        data = {
            "type": "skill",
            "name": skill.name,
            "description": skill.description,
            "source": skill.source,
            "license": skill.license,
            "compatibility": list(skill.compatibility),
            "scope": skill.scope.to_dict(),
            "metadata": skill.metadata,
            "path": str(skill.source_path) if skill.source_path else None,
            "content": skill.content,
        }
    else:
        data = {}

    out.write(json.dumps(data, indent=2) + "\n")
    return 0


# ─────────────────────────────────────────────────────────────────────────────
# VALIDATE COMMAND
# ─────────────────────────────────────────────────────────────────────────────


def run_agents_validate(
    path: Path,
    *,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Validate all agent definitions.

    Args:
        path: Repository root path.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for errors found).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Discover agents directory
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        err.write("No .agents/ directory found.\n")
        return 1

    # Scan directory
    out.write(f"Validating .agents/ at {agents_dir}...\n\n")
    directory = scan_agents_directory(agents_dir)

    errors: list[str] = []

    # Check for parse errors
    for error in directory.errors:
        errors.append(f"Parse error: {error}")

    # Validate agents
    for agent in directory.agents:
        # Check required fields
        if not agent.description:
            errors.append(f"Agent '{agent.name}': missing description")

        # Check name format
        if not re.match(r"^[a-z0-9]+(-[a-z0-9]+)*$", agent.name):
            errors.append(f"Agent '{agent.name}': invalid name format (must be kebab-case)")

        # Check temperature range
        if agent.temperature is not None and (agent.temperature < 0 or agent.temperature > 2):
            errors.append(f"Agent '{agent.name}': temperature must be 0-2")

        # Check mode
        if agent.mode not in ("primary", "subagent", "all"):
            errors.append(f"Agent '{agent.name}': invalid mode '{agent.mode}'")

    # Validate skills
    for skill in directory.skills:
        if not skill.description:
            errors.append(f"Skill '{skill.name}': missing description")

        # Check name matches directory
        if skill.source_path:
            expected_name = skill.source_path.parent.name
            if skill.name != expected_name:
                errors.append(f"Skill '{skill.name}': name must match directory '{expected_name}'")

    # Check symlinks
    results = check_symlinks(agents_dir)
    for result in results:
        if not result.is_ok:
            errors.append(f"Symlink '{result.name}': {result.message}")

    # Report results
    if errors:
        err.write(f"Found {len(errors)} error(s):\n\n")
        for error in errors:
            err.write(f"  - {error}\n")
        err.write("\n")
        return 1

    out.write(f"Validated {len(directory.agents)} agent(s) and {len(directory.skills)} skill(s).\n")
    out.write("No errors found.\n")
    return 0


# ─────────────────────────────────────────────────────────────────────────────
# CREATE COMMAND
# ─────────────────────────────────────────────────────────────────────────────

# Regex for validating kebab-case names (re imported in validate section)
KEBAB_CASE_PATTERN = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


def run_agents_create(
    path: Path,
    name: str,
    description: str,
    *,
    mode: str = "all",
    tools: dict[str, bool] | None = None,
    scope_layers: list[str] | None = None,
    scope_systems: list[str] | None = None,
    scope_stacks: list[str] | None = None,
    scope_layer_types: list[str] | None = None,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Create a new agent definition file.

    Args:
        path: Repository root path.
        name: Agent name (kebab-case).
        description: Agent description.
        mode: Interaction mode (primary, subagent, or all).
        tools: Tool availability configuration.
        scope_layers: Layer FQTNs for scope binding.
        scope_systems: System names for scope binding.
        scope_stacks: Stack FQTNs for scope binding.
        scope_layer_types: Layer type names for scope binding.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Validate name format
    if not KEBAB_CASE_PATTERN.match(name):
        err.write(f"Invalid agent name: '{name}'\n")
        err.write("Name must be kebab-case (lowercase letters, numbers, and hyphens).\n")
        err.write("Examples: my-agent, code-reviewer, test-helper-1\n")
        return 1

    # Validate mode
    if mode not in ("primary", "subagent", "all"):
        err.write(f"Invalid mode: '{mode}'\n")
        err.write("Mode must be one of: primary, subagent, all\n")
        return 1

    # Discover agents directory
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        err.write("No .agents/ directory found.\n")
        err.write("Run 'kata tax agents init' to initialize.\n")
        return 1

    # Check if agent already exists
    agent_file = agents_dir / "agents" / f"{name}.md"
    if agent_file.exists():
        err.write(f"Agent '{name}' already exists at {agent_file}\n")
        return 1

    # Build scope from parameters
    scope_global = True
    if scope_layers or scope_systems or scope_stacks or scope_layer_types:
        scope_global = False

    scope = Scope(
        global_=scope_global,
        systems=tuple(scope_systems or []),
        stacks=tuple(scope_stacks or []),
        layers=tuple(scope_layers or []),
        layer_types=tuple(scope_layer_types or []),
    )

    # Create agent
    agent = Agent(
        name=name,
        description=description,
        mode=mode,  # type: ignore[arg-type]
        tools=tools or {},
        scope=scope,
        prompt=f"# {name.replace('-', ' ').title()}\n\nYour instructions here...\n",
        source_path=agent_file,
    )

    # Serialize and write
    try:
        content = serialize_agent(agent)
        agent_file.write_text(content, encoding="utf-8")
        logger.debug(f"Created agent file: {agent_file}")
    except OSError as e:
        err.write(f"Error creating agent file: {e}\n")
        return 1

    out.write(f"Created agent '{name}' at {agent_file}\n")
    out.write("\nNext steps:\n")
    out.write(f"  - Edit {agent_file} to customize the prompt\n")
    out.write("  - Run 'kata tax agents validate' to check for errors\n")
    out.write("  - Run 'kata tax agents show {name}' to view details\n")

    return 0


# ─────────────────────────────────────────────────────────────────────────────
# SYNC COMMAND
# ─────────────────────────────────────────────────────────────────────────────


def run_agents_sync(
    path: Path,
    *,
    force: bool = False,
    dry_run: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Sync bundled agents and skills into the local .agents/ directory.

    Copies any bundled agents/skills that are missing from the local
    directory.  Useful after upgrading the katalyst-taxonomy package to
    pick up new default agents.

    Args:
        path: Repository root path.
        force: Overwrite existing files with bundled versions.
        dry_run: Show what would be done without making changes.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # Discover agents directory
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        err.write("No .agents/ directory found.\n")
        err.write("Run 'kata tax agents init' to initialize.\n")
        return 1

    # Check what's available
    content = scan_bundled()
    if content is None:
        err.write("No bundled agents/skills found in package.\n")
        return 1

    if dry_run:
        out.write("Dry run — no changes will be made.\n\n")
        out.write(
            f"Bundled content: {len(content.agent_files)} agents, "
            f"{len(content.skill_dirs)} skills\n\n"
        )

        # Check what would be copied
        existing_agents = {p.stem for p in (agents_dir / "agents").glob("*.md")}
        existing_skills: set[str] = (
            {
                d.name
                for d in (agents_dir / "skills").iterdir()
                if d.is_dir() and (d / "SKILL.md").is_file()
            }
            if (agents_dir / "skills").is_dir()
            else set()
        )

        new_agents = [f.stem for f in content.agent_files if f.stem not in existing_agents or force]
        new_skills = [d.name for d in content.skill_dirs if d.name not in existing_skills or force]
        skip_agents = [
            f.stem for f in content.agent_files if f.stem in existing_agents and not force
        ]
        skip_skills = [
            d.name for d in content.skill_dirs if d.name in existing_skills and not force
        ]

        if new_agents:
            action = "Would overwrite" if force else "Would copy"
            out.write(f"{action} {len(new_agents)} agent(s):\n")
            for name in sorted(new_agents):
                out.write(f"  + {name}\n")
            out.write("\n")

        if new_skills:
            action = "Would overwrite" if force else "Would copy"
            out.write(f"{action} {len(new_skills)} skill(s):\n")
            for name in sorted(new_skills):
                out.write(f"  + {name}\n")
            out.write("\n")

        if skip_agents:
            out.write(f"Would skip {len(skip_agents)} existing agent(s):\n")
            for name in sorted(skip_agents):
                out.write(f"  = {name}\n")
            out.write("\n")

        if skip_skills:
            out.write(f"Would skip {len(skip_skills)} existing skill(s):\n")
            for name in sorted(skip_skills):
                out.write(f"  = {name}\n")
            out.write("\n")

        if not new_agents and not new_skills:
            out.write("Everything is up to date.\n")

        return 0

    # Actually sync
    out.write("Syncing bundled agents and skills...\n\n")
    try:
        sync_result = copy_bundled_to(agents_dir, force=force)
    except FileNotFoundError:
        err.write("No bundled agents/skills found in package.\n")
        return 1

    if sync_result.agents_copied:
        out.write(f"Copied {len(sync_result.agents_copied)} agent(s):\n")
        for name in sorted(sync_result.agents_copied):
            out.write(f"  + {name}\n")
        out.write("\n")

    if sync_result.skills_copied:
        out.write(f"Copied {len(sync_result.skills_copied)} skill(s):\n")
        for name in sorted(sync_result.skills_copied):
            out.write(f"  + {name}\n")
        out.write("\n")

    if sync_result.agents_skipped:
        out.write(f"Skipped {len(sync_result.agents_skipped)} existing agent(s)")
        if not force:
            out.write(" (use --force to overwrite)")
        out.write("\n")

    if sync_result.skills_skipped:
        out.write(f"Skipped {len(sync_result.skills_skipped)} existing skill(s)")
        if not force:
            out.write(" (use --force to overwrite)")
        out.write("\n")

    if sync_result.total_copied == 0 and sync_result.total_skipped == 0:
        out.write("No bundled content to sync.\n")
    elif sync_result.total_copied == 0:
        out.write("\nEverything is up to date.\n")
    else:
        out.write(f"\nSync complete: {sync_result.total_copied} item(s) copied.\n")

    return 0


# ─────────────────────────────────────────────────────────────────────────────
# GENERATE COMMAND
# ─────────────────────────────────────────────────────────────────────────────


def _get_available_templates() -> list[str]:
    """Return list of available template names."""
    return sorted(AGENT_TEMPLATES.keys())


def _generate_agent_from_template(
    template_name: str,
    layer_type: str,
    layer_type_description: str | None = None,
) -> Agent:
    """Generate an Agent from a template for a specific layer type.

    Args:
        template_name: Name of the template to use.
        layer_type: Layer type to bind the agent to.
        layer_type_description: Optional description of the layer type.

    Returns:
        An Agent instance (not yet saved).

    Raises:
        ValueError: If template not found.
    """
    if template_name not in AGENT_TEMPLATES:
        available = ", ".join(_get_available_templates())
        raise ValueError(f"Unknown template '{template_name}'. Available: {available}")

    template = AGENT_TEMPLATES[template_name]

    # Build substitution context
    layer_type_title = layer_type.replace("-", " ").title()
    context = {
        "layer_type": layer_type,
        "layer_type_title": layer_type_title,
        "layer_type_description": layer_type_description or f"A {layer_type} layer",
    }

    # Generate agent name
    name_suffix = str(template.get("name_suffix", ""))
    name = f"{layer_type}{name_suffix}"

    # Format description and prompt
    description = str(template.get("description", "")).format(**context)
    prompt = str(template.get("prompt", "")).format(**context)

    # Build scope
    scope = Scope(
        global_=False,
        layer_types=(layer_type,),
    )

    # Build tools dict
    tools_raw = template.get("tools", {})
    tools: dict[str, bool] = {}
    if isinstance(tools_raw, dict):
        typed_raw = cast(dict[str, Any], tools_raw)
        tools = {str(k): bool(v) for k, v in typed_raw.items()}

    return Agent(
        name=name,
        description=description,
        mode=str(template.get("mode", "subagent")),  # type: ignore[arg-type]
        tools=tools,
        scope=scope,
        prompt=prompt,
    )


def run_agents_generate(
    path: Path,
    *,
    template: str | None = None,
    layer_type: str | None = None,
    all_layer_types: bool = False,
    list_templates: bool = False,
    force: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Generate agents from templates, optionally bound to layer types.

    Args:
        path: Repository root path.
        template: Template name to use (default: layer-helper).
        layer_type: Specific layer type to generate for.
        all_layer_types: Generate for all discovered layer types.
        list_templates: List available templates and exit.
        force: Overwrite existing agent files.
        output: Output stream (defaults to stdout).
        err_output: Error output stream (defaults to stderr).

    Returns:
        Exit code (0 for success, 1 for failure).
    """
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    # List templates mode
    if list_templates:
        out.write("Available agent templates:\n\n")
        for name in _get_available_templates():
            tmpl = AGENT_TEMPLATES[name]
            desc = str(tmpl.get("description", "")).replace("{layer_type}", "<layer-type>")
            out.write(f"  {name}\n")
            out.write(f"    {desc}\n\n")
        return 0

    # Default template
    if template is None:
        template = "layer-helper"

    # Validate template
    if template not in AGENT_TEMPLATES:
        available = ", ".join(_get_available_templates())
        err.write(f"Unknown template: '{template}'\n")
        err.write(f"Available templates: {available}\n")
        return 1

    # Discover agents directory
    agents_dir = discover_agents_directory(path)
    if not agents_dir:
        err.write("No .agents/ directory found.\n")
        err.write("Run 'kata tax agents init' to initialize.\n")
        return 1

    # Determine which layer types to generate for
    layer_types_to_generate: list[tuple[str, str | None]] = []

    if layer_type:
        # Single layer type specified
        layer_types_to_generate.append((layer_type, None))

    elif all_layer_types:
        # Discover all layer types from taxonomy
        try:
            from katalyst_taxonomy.services.template_service import load_layer_types

            result = load_layer_types(path)
            if result.definitions:
                for defn in result.definitions:
                    layer_types_to_generate.append((defn.name, defn.description))
            else:
                err.write("No layer types found in the taxonomy.\n")
                err.write("Use --layer-type to specify one manually.\n")
                return 1
        except ImportError:
            err.write("Could not load layer types plugin.\n")
            err.write("Use --layer-type to specify one manually.\n")
            return 1

    else:
        err.write("Must specify --layer-type or --all-layer-types\n")
        err.write("\nUsage:\n")
        err.write("  kata tax agents generate --template layer-helper --layer-type app-docker\n")
        err.write("  kata tax agents generate --all-layer-types\n")
        err.write("  kata tax agents generate --list-templates\n")
        return 1

    # Generate agents
    created: list[str] = []
    skipped: list[str] = []
    errors: list[str] = []

    for lt_name, lt_description in layer_types_to_generate:
        try:
            agent = _generate_agent_from_template(template, lt_name, lt_description)
            agent_file = agents_dir / "agents" / f"{agent.name}.md"

            if agent_file.exists() and not force:
                skipped.append(agent.name)
                continue

            # Write the agent file
            content = serialize_agent(agent)
            agent_file.write_text(content, encoding="utf-8")
            created.append(agent.name)
            logger.debug(f"Generated agent: {agent_file}")

        except (ValueError, OSError) as e:
            errors.append(f"{lt_name}: {e}")

    # Report results
    if created:
        out.write(f"Generated {len(created)} agent(s):\n")
        for name in created:
            out.write(f"  - {name}\n")
        out.write("\n")

    if skipped:
        out.write(f"Skipped {len(skipped)} existing agent(s):\n")
        for name in skipped:
            out.write(f"  - {name} (use --force to overwrite)\n")
        out.write("\n")

    if errors:
        err.write(f"Errors ({len(errors)}):\n")
        for error in errors:
            err.write(f"  - {error}\n")
        return 1

    if not created and not skipped:
        err.write("No agents generated.\n")
        return 1

    out.write("Run 'kata tax agents list' to see all agents.\n")
    return 0
