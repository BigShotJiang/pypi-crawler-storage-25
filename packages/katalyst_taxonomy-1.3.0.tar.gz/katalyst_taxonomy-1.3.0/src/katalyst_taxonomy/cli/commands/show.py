"""show command - unified taxonomy viewing with multiple output formats."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, TextIO

from katalyst_taxonomy.cli.loaders import load_taxonomy
from katalyst_taxonomy.cli.output import (
    HEADING_COLOR,
    KIND_ORDER,
    KIND_SECTION_TITLES,
    colorize,
    write_error,
    write_heading,
    write_warning,
)
from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.services.serialization import serialize_document
from katalyst_taxonomy.services.taxonomy import TaxonomyService
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

# Format constants
FORMAT_TREE = "tree"
FORMAT_LIST = "list"
FORMAT_JSON = "json"


def _print_warnings(errors: tuple[DocumentError, ...], stream: TextIO) -> None:
    """Print warnings for document errors."""
    for error in errors:
        rel_path = error.path.name if error.path else "<unknown>"
        msg = f"[{rel_path}] {error.message}"
        write_warning(msg, stream)


# --- Tree format ---


def _build_tree_lines(service: TaxonomyService) -> list[str]:
    """Build tree representation lines from taxonomy documents."""
    nodes_by_fq: dict[str, Document] = {}
    for document in service.documents:
        fqtn = service.get_qualified_name(document)
        nodes_by_fq[fqtn] = document

    children: dict[str | None, list[str]] = {}
    for fqtn in nodes_by_fq:
        parent_fq: str | None = None
        if "." in fqtn:
            candidate = fqtn.rsplit(".", 1)[0]
            if candidate in nodes_by_fq:
                parent_fq = candidate
        children.setdefault(parent_fq, []).append(fqtn)

    def sort_children(fqs: list[str]) -> list[str]:
        return sorted(
            fqs,
            key=lambda item: (
                KIND_ORDER.index(nodes_by_fq[item].taxonomy_node_type)
                if nodes_by_fq[item].taxonomy_node_type in KIND_ORDER
                else len(KIND_ORDER),
                nodes_by_fq[item].metadata.name,
                item,
            ),
        )

    lines: list[str] = []

    def render_children(parent_fq: str, prefix: str) -> None:
        entries = sort_children(children.get(parent_fq, []))
        for index, child_fq in enumerate(entries):
            document = nodes_by_fq[child_fq]
            connector = (
                "\u2514\u2500\u2500 " if index == len(entries) - 1 else "\u251c\u2500\u2500 "
            )
            lines.append(
                f"{prefix}{connector}{document.metadata.name} [{document.taxonomy_node_type}]",
            )
            extension = "    " if index == len(entries) - 1 else "\u2502   "
            render_children(child_fq, prefix + extension)

    roots = sort_children(children.get(None, []))
    for root_index, root_fq in enumerate(roots):
        root_doc = nodes_by_fq[root_fq]
        lines.append(f"{root_doc.metadata.name} [{root_doc.taxonomy_node_type}]")
        render_children(root_fq, "")
        if root_index != len(roots) - 1:
            lines.append("")

    return lines


def _output_tree(service: TaxonomyService, out: TextIO) -> None:
    """Output taxonomy as tree."""
    if not service.documents:
        out.write("No taxonomy documents found.\n")
        return

    lines = _build_tree_lines(service)
    for line in lines:
        out.write(f"{line}\n")


# --- List format ---


def _print_environments(documents: tuple[Document, ...], stream: TextIO) -> None:
    """Print environment summary."""
    environments: set[str] = set()
    for doc in documents:
        environments.update(doc.environments)

    if environments:
        sorted_envs = sorted(environments)
        stream.write(f"Environments: {', '.join(sorted_envs)}\n\n")


def _format_document(doc: Document, service: TaxonomyService) -> str:
    """Format a document for display."""
    fqtn = service.get_qualified_name(doc)
    description = doc.description or ""

    if len(description) > 60:
        description = description[:57] + "..."

    owners = ", ".join(doc.owners) if doc.owners else ""
    if owners and len(owners) > 40:
        owners = owners[:37] + "..."

    parts = [fqtn]
    if description:
        parts.append(f"- {description}")
    if owners:
        parts.append(f"[{owners}]")

    return " ".join(parts)


def _output_list(service: TaxonomyService, out: TextIO) -> None:
    """Output taxonomy as grouped list."""
    if not service.documents:
        out.write("No taxonomy documents found.\n")
        return

    write_heading("Taxonomy Overview", out)
    _print_environments(service.documents, out)

    grouped = service.group_documents_by_type()
    for kind in KIND_ORDER:
        docs = grouped.get(kind, [])
        if not docs:
            continue

        title = KIND_SECTION_TITLES.get(kind, kind.title())
        out.write(colorize(f"{title}\n", HEADING_COLOR, out))

        for doc in docs:
            formatted = _format_document(doc, service)
            out.write(f"  {formatted}\n")

        out.write("\n")


# --- JSON format ---


def _serialize_environment(
    env: EnvironmentDocument,
    base_path: Path | None = None,
) -> dict[str, Any]:
    """Serialize an EnvironmentDocument to a JSON-compatible dict."""
    result: dict[str, Any] = {
        "name": env.name,
        "description": env.description,
        "templateReplacements": dict(env.template_replacements),
        "layerTemplates": {k: dict(v) for k, v in env.layer_templates.items()},
    }

    if env.source_path:
        if base_path:
            try:
                result["sourcePath"] = str(env.source_path.relative_to(base_path))
            except ValueError:
                result["sourcePath"] = str(env.source_path)
        else:
            result["sourcePath"] = str(env.source_path)

    if env.markdown_body is not None:
        result["markdownBody"] = env.markdown_body

    return result


def _serialize_error(error: DocumentError, base_path: Path | None = None) -> dict[str, Any]:
    """Serialize a DocumentError to a JSON-compatible dict."""
    result: dict[str, Any] = {
        "message": error.message,
    }

    if error.path:
        if base_path:
            try:
                result["path"] = str(error.path.relative_to(base_path))
            except ValueError:
                result["path"] = str(error.path)
        else:
            result["path"] = str(error.path)

    if error.document_index:
        result["documentIndex"] = error.document_index

    return result


def _output_json(
    service: TaxonomyService,
    out: TextIO,
    base_path: Path | None = None,
) -> None:
    """Output taxonomy as JSON."""
    payload: dict[str, Any] = {
        "documents": [serialize_document(doc, service, base_path) for doc in service.documents],
        "environments": [_serialize_environment(env, base_path) for env in service.environments],
        "qualifiedNames": service.qualified_names,
        "errors": [_serialize_error(e, base_path) for e in service.errors],
    }

    json.dump(payload, out, indent=2)
    out.write("\n")


# --- Main entry point ---


def run_show(
    path: Path,
    name: str | None = None,
    output_format: str = FORMAT_TREE,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Execute the show command."""
    out: TextIO = output if output is not None else sys.stdout
    err: TextIO = err_output if err_output is not None else sys.stderr

    try:
        service = load_taxonomy(path)
        base_path = path
    except FileNotFoundError as exc:
        write_error(str(exc), err)
        return 1
    except Exception as exc:
        write_error(f"Failed to load taxonomy: {exc}", err)
        return 1

    # Print warnings to stderr (except for JSON format)
    if output_format != FORMAT_JSON:
        _print_warnings(service.errors, err)

    # If a specific name is requested, filter to that node
    if name:
        doc = service.get_document_by_name(name)
        if doc is None:
            write_error(f"Node '{name}' not found", err)
            return 1
        # Create a filtered service with just this document
        service = TaxonomyService(
            documents=(doc,),
            environments=service.environments,
            errors=(),
        )

    # Output in requested format
    if output_format == FORMAT_TREE:
        _output_tree(service, out)
    elif output_format == FORMAT_LIST:
        _output_list(service, out)
    elif output_format == FORMAT_JSON:
        _output_json(service, out, base_path)
    else:
        write_error(f"Unknown format: {output_format}", err)
        return 1

    return 0
