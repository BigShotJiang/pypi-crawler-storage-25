"""CLI command for exporting taxonomy data to external systems."""

# pyright: reportMissingImports=false
# pyright: reportUnusedImport=false

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import TextIO

from katalyst_taxonomy.cli.output import write_error, write_success, write_warning


def run_export_neo4j(
    *,
    path: Path,
    uri: str = "bolt://localhost:7687",
    username: str = "neo4j",
    password: str = "password",
    database: str = "neo4j",
    full: bool = False,
    dry_run: bool = False,
    batch_size: int = 5000,
    verbose: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Export taxonomy data to Neo4j.

    Args:
        path: Path to the taxonomy directory.
        uri: Neo4j bolt URI.
        username: Neo4j username.
        password: Neo4j password.
        database: Neo4j database name.
        full: Perform full export (clear + recreate) instead of incremental sync.
        dry_run: Show what would be exported without writing to Neo4j.
        batch_size: Batch size for UNWIND operations.
        verbose: Show detailed progress.
        output: Output stream (default: stdout).
        err_output: Error stream (default: stderr).

    Returns:
        Exit code (0 for success, 1 for error).
    """
    out = output if output is not None else sys.stdout
    err = err_output if err_output is not None else sys.stderr

    # Check neo4j dependency early
    try:
        import neo4j as _neo4j  # noqa: F401
    except ImportError:
        write_error(
            "The 'neo4j' package is required for Neo4j export.\n"
            "Install it with: pip install katalyst-taxonomy[neo4j]",
            err,
        )
        return 1

    # Lazy imports to avoid loading neo4j for other commands
    from katalyst_taxonomy.adapters.filesystem import FilesystemBackend
    from katalyst_taxonomy.adapters.neo4j.adapter import Neo4jExportAdapter
    from katalyst_taxonomy.adapters.neo4j.config import Neo4jConfig
    from katalyst_taxonomy.engine.bridge import get_default_registry
    from katalyst_taxonomy.services.export import ExportService

    config = Neo4jConfig(
        uri=uri,
        username=username,
        password=password,
        database=database,
        batch_size=batch_size,
    )

    if dry_run:
        return _dry_run(path=path, config=config, full=full, out=out, err=err)

    registry = get_default_registry()
    backend = FilesystemBackend(base_path=path)
    adapter = Neo4jExportAdapter(config=config, registry=registry)
    service = ExportService(repository=backend, export_port=adapter)

    async def _run() -> int:
        try:
            # Health check first
            healthy = await service.health_check()
            if not healthy:
                write_error(f"Cannot connect to Neo4j at {config.uri}", err)
                return 1

            if verbose:
                out.write(f"Connected to Neo4j at {config.uri}\n")

            if full:
                result = await service.full_export(path)
            else:
                result = await service.incremental_sync(path)

            if not result.success:
                for error in result.errors:
                    write_error(error, err)
                return 1

            mode = "Full export" if full else "Incremental sync"
            write_success(f"{mode} complete", out)
            out.write(f"  Nodes created/updated: {result.nodes_created}\n")
            if result.nodes_deleted:
                out.write(f"  Nodes pruned: {result.nodes_deleted}\n")
            out.write(f"  Relationships created: {result.relationships_created}\n")
            return 0
        finally:
            await service.close()

    return asyncio.run(_run())


def _dry_run(
    *,
    path: Path,
    config: object,
    full: bool,
    out: TextIO,
    err: TextIO,
) -> int:
    """Preview what would be exported without writing to Neo4j."""
    from katalyst_taxonomy.adapters.filesystem import FilesystemBackend
    from katalyst_taxonomy.adapters.neo4j.mapper import TaxonomyGraphMapper
    from katalyst_taxonomy.engine.bridge import get_default_registry
    from katalyst_taxonomy.engine.resolver import build_qualified_names, qualified_name_for

    try:
        registry = get_default_registry()
        backend = FilesystemBackend(base_path=path)

        documents = backend.load_documents()
        environments = backend.load_environments()
        qualified_names = build_qualified_names(documents, registry)

        mapper = TaxonomyGraphMapper(_registry=registry)

        mode = "Full export" if full else "Incremental sync"
        out.write(f"DRY RUN — {mode}\n\n")
        out.write(f"Taxonomy path: {path}\n")
        out.write(f"Documents: {len(documents)}\n")
        out.write(f"Environments: {len(environments)}\n\n")

        out.write("Nodes that would be created:\n")
        for doc in documents:
            fqtn = qualified_name_for(doc, qualified_names)
            graph_node = mapper.map_document(doc, fqtn)
            labels_str = ":".join(graph_node.labels)
            out.write(f'  (:{labels_str} {{fqtn: "{fqtn}"}})\n')

        for env in environments:
            graph_node = mapper.map_environment(env)
            out.write(f'  (:Environment {{name: "{env.name}"}})\n')

        relationships = mapper.extract_relationships(documents, qualified_names)
        out.write(f"\nRelationships that would be created: {len(relationships)}\n")

        rel_counts: dict[str, int] = {}
        for rel in relationships:
            rel_counts[rel.rel_type] = rel_counts.get(rel.rel_type, 0) + 1
        for rel_type, count in sorted(rel_counts.items()):
            out.write(f"  {rel_type}: {count}\n")

        write_warning("No data was written (dry run)", err)
        return 0
    except FileNotFoundError as exc:
        write_error(str(exc), err)
        return 1


def run_export_postgres(
    *,
    path: Path,
    host: str = "localhost",
    port: int = 5432,
    database: str = "katalyst",
    username: str = "katalyst",
    password: str = "",
    dsn: str | None = None,
    full: bool = False,
    dry_run: bool = False,
    batch_size: int = 1000,
    verbose: bool = False,
    output: TextIO | None = None,
    err_output: TextIO | None = None,
) -> int:
    """Export taxonomy data to PostgreSQL.

    Args:
        path: Path to the taxonomy directory.
        host: PostgreSQL host.
        port: PostgreSQL port.
        database: PostgreSQL database name.
        username: PostgreSQL username.
        password: PostgreSQL password.
        dsn: Full DSN string — overrides individual connection params.
        full: Perform full export (clear + recreate) instead of incremental sync.
        dry_run: Show what would be exported without writing to PostgreSQL.
        batch_size: Batch size for bulk operations.
        verbose: Show detailed progress.
        output: Output stream (default: stdout).
        err_output: Error stream (default: stderr).

    Returns:
        Exit code (0 for success, 1 for error).
    """
    out = output if output is not None else sys.stdout
    err = err_output if err_output is not None else sys.stderr

    # Check asyncpg dependency early
    try:
        import asyncpg as _asyncpg  # noqa: F401
    except ImportError:
        write_error(
            "The 'asyncpg' package is required for PostgreSQL export.\n"
            "Install it with: pip install katalyst-taxonomy[postgres]",
            err,
        )
        return 1

    # Lazy imports to avoid loading postgres for other commands
    from katalyst_taxonomy.adapters.filesystem import FilesystemBackend
    from katalyst_taxonomy.adapters.postgres.backend import PostgresBackend
    from katalyst_taxonomy.adapters.postgres.config import PostgresConfig

    if dsn:
        config = PostgresConfig.from_dsn(dsn)
    else:
        config = PostgresConfig(
            host=host,
            port=port,
            database=database,
            username=username,
            password=password,
            batch_size=batch_size,
        )

    if dry_run:
        return _dry_run_postgres(path=path, config=config, full=full, out=out, err=err)

    fs_backend = FilesystemBackend(base_path=path)
    pg_backend = PostgresBackend(config=config)

    try:
        healthy = pg_backend.health_check()
        if not healthy:
            write_error(f"Cannot connect to PostgreSQL at {config.host}:{config.port}", err)
            return 1

        if verbose:
            out.write(f"Connected to PostgreSQL at {config.host}:{config.port}/{config.database}\n")

        result = pg_backend.sync_from(fs_backend, full=full)

        if not result.success:
            for error in result.errors:
                write_error(error, err)
            return 1

        mode = "Full export" if full else "Incremental sync"
        write_success(f"{mode} complete", out)
        out.write(f"  Nodes created/updated: {result.nodes_created + result.nodes_updated}\n")
        if result.nodes_deleted:
            out.write(f"  Nodes pruned: {result.nodes_deleted}\n")
        out.write(f"  Relationships created: {result.relationships_created}\n")
        return 0
    except Exception as exc:
        write_error(f"PostgreSQL export failed: {exc}", err)
        return 1
    finally:
        pg_backend.close()


def _dry_run_postgres(
    *,
    path: Path,
    config: object,
    full: bool,
    out: TextIO,
    err: TextIO,
) -> int:
    """Preview what would be exported without writing to PostgreSQL."""
    from katalyst_taxonomy.adapters.filesystem import FilesystemBackend

    try:
        backend = FilesystemBackend(base_path=path)

        documents = backend.load_documents()
        environments = backend.load_environments()

        mode = "Full export" if full else "Incremental sync"
        out.write(f"DRY RUN — {mode} (PostgreSQL)\n\n")
        out.write(f"Taxonomy path: {path}\n")
        out.write(f"Documents: {len(documents)}\n")
        out.write(f"Environments: {len(environments)}\n\n")

        out.write("Nodes that would be synced:\n")
        for doc in documents:
            out.write(f"  {doc.kind}: {doc.name}\n")

        for env in environments:
            out.write(f"  environment: {env.name}\n")

        write_warning("No data was written (dry run)", err)
        return 0
    except FileNotFoundError as exc:
        write_error(str(exc), err)
        return 1
