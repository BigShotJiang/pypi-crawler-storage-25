"""Main entry point for the Katalyst CLI."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import cast

from katalyst_taxonomy.cli.output import write_error, write_success
from katalyst_taxonomy.cli.parser import (
    FORMAT_JSON,
    FORMAT_LIST,
    FORMAT_TREE,
    create_parser,
)


def _opt_tuple(val: object) -> tuple[str, ...] | None:
    """Convert a list to a tuple, or return None if falsy."""
    if val:
        return tuple(cast(list[str], val))
    return None


# ---------------------------------------------------------------------------
# Individual handler functions — each extracts typed args from parsed namespace
# ---------------------------------------------------------------------------


def _handle_show(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.show import run_show

    return run_show(
        path=parsed.path,  # type: ignore[attr-defined]
        name=getattr(parsed, "name", None),
        output_format=parsed.format,  # type: ignore[attr-defined]
    )


def _handle_get(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.get import run_get

    return run_get(
        path=parsed.path,  # type: ignore[attr-defined]
        name=cast(str, parsed.name),  # type: ignore[attr-defined]
        output_format=parsed.format,  # type: ignore[attr-defined]
    )


def _handle_lint(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.lint import run_lint

    return run_lint(
        path=parsed.path,  # type: ignore[attr-defined]
        verbose=getattr(parsed, "verbose", False),
    )


def _handle_create(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.create import run_create

    return run_create(
        path=parsed.path,  # type: ignore[attr-defined]
        node_type=parsed.type,  # type: ignore[attr-defined]
        name=cast(str, parsed.name),  # type: ignore[attr-defined]
        description=parsed.description,  # type: ignore[attr-defined]
        owners=_opt_tuple(getattr(parsed, "owners", None)),
        environments=_opt_tuple(getattr(parsed, "environments", None)),
        parent=parsed.parent,  # type: ignore[attr-defined]
        parent_system=getattr(parsed, "parent_system", None),
        layer_type=getattr(parsed, "layer_type", None),
        target_dir=getattr(parsed, "target_dir", None),
        output_format=getattr(parsed, "output_format", "yaml"),
    )


def _handle_deps(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.deps import run_deps

    return run_deps(
        path=parsed.path,  # type: ignore[attr-defined]
        output_format=getattr(parsed, "output_format", "tree"),
        node=getattr(parsed, "node", None),
        reverse=getattr(parsed, "reverse", False),
    )


def _handle_status(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.status import run_status

    return run_status(path=parsed.path)  # type: ignore[attr-defined]


def _handle_init(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.init import run_init

    return run_init(
        path=parsed.path,  # type: ignore[attr-defined]
        source=parsed.source,  # type: ignore[attr-defined]
        plugins=_opt_tuple(getattr(parsed, "plugins", None)),
        layer_types=_opt_tuple(getattr(parsed, "layer_types", None)),
        environments=_opt_tuple(getattr(parsed, "environments", None)),
        interactive=not parsed.yes,  # type: ignore[attr-defined]
    )


def _handle_upgrade(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.upgrade import run_upgrade

    return run_upgrade(
        path=parsed.path,  # type: ignore[attr-defined]
        source=parsed.source,  # type: ignore[attr-defined]
        components=_opt_tuple(getattr(parsed, "components", None)),
        items=_opt_tuple(getattr(parsed, "items", None)),
        dry_run=parsed.dry_run,  # type: ignore[attr-defined]
        check_only=parsed.check,  # type: ignore[attr-defined]
        yes=parsed.yes,  # type: ignore[attr-defined]
        no_backup=parsed.no_backup,  # type: ignore[attr-defined]
        show_diff=parsed.diff,  # type: ignore[attr-defined]
    )


def _handle_rollback(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.rollback import run_rollback

    return run_rollback(
        path=parsed.path,  # type: ignore[attr-defined]
        list_backups=parsed.list_backups,  # type: ignore[attr-defined]
        backup_name=parsed.backup_name,  # type: ignore[attr-defined]
        yes=parsed.yes,  # type: ignore[attr-defined]
    )


def _handle_add(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.add import run_add

    return run_add(
        path=parsed.path,  # type: ignore[attr-defined]
        plugins=_opt_tuple(getattr(parsed, "plugins", None)),
        layer_types=_opt_tuple(getattr(parsed, "layer_types", None)),
        source=parsed.source,  # type: ignore[attr-defined]
        force=parsed.force,  # type: ignore[attr-defined]
        yes=parsed.yes,  # type: ignore[attr-defined]
    )


def _handle_remove(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.remove import run_remove

    return run_remove(
        path=parsed.path,  # type: ignore[attr-defined]
        plugins=_opt_tuple(getattr(parsed, "plugins", None)),
        layer_types=_opt_tuple(getattr(parsed, "layer_types", None)),
        force=parsed.force,  # type: ignore[attr-defined]
        yes=parsed.yes,  # type: ignore[attr-defined]
    )


def _handle_clone(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.clone import run_clone

    return run_clone(
        path=parsed.path,  # type: ignore[attr-defined]
        node_type=parsed.type,  # type: ignore[attr-defined]
        source_name=parsed.source,  # type: ignore[attr-defined]
        target_name=parsed.target,  # type: ignore[attr-defined]
        source_system=getattr(parsed, "source_system", None),
        source_stack=getattr(parsed, "source_stack", None),
        target_system=getattr(parsed, "target_system", None),
        target_stack=getattr(parsed, "target_stack", None),
        description=parsed.description,  # type: ignore[attr-defined]
        owners=_opt_tuple(getattr(parsed, "owners", None)),
        environments=_opt_tuple(getattr(parsed, "environments", None)),
        layer_type=getattr(parsed, "layer_type", None),
        scaffold=parsed.scaffold,  # type: ignore[attr-defined]
        yes=parsed.yes,  # type: ignore[attr-defined]
    )


# ---------------------------------------------------------------------------
# Sub-dispatchers for commands with their own subcommands
# ---------------------------------------------------------------------------


def _handle_server(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.server import run_server

    server_action = getattr(parsed, "server_action", None)
    if server_action is None:
        sys.stderr.write("Usage: kata tax server {start|stop|status|restart}\n")
        sys.stderr.write("\nSubcommands:\n")
        sys.stderr.write("  start    Start the server\n")
        sys.stderr.write("  stop     Stop the running server\n")
        sys.stderr.write("  status   Show server status\n")
        sys.stderr.write("  restart  Restart the server\n")
        return 1

    return run_server(
        action=server_action,
        path=parsed.path,  # type: ignore[attr-defined]
        port=getattr(parsed, "port", None),
        idle_timeout=getattr(parsed, "idle_timeout", 300),
    )


def _handle_action(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.action import (
        run_action_list,
        run_action_run,
        run_action_show,
    )

    _ACTION_HANDLERS: dict[str, object] = {
        "run": lambda: run_action_run(
            path=parsed.path,  # type: ignore[attr-defined]
            action_name=parsed.action_name,  # type: ignore[attr-defined]
            layer_fqtn=parsed.layer,  # type: ignore[attr-defined]
            environment=getattr(parsed, "environment", None),
            dry_run=getattr(parsed, "dry_run", False),
            quiet=getattr(parsed, "quiet", False),
            timeout=getattr(parsed, "timeout", None),
        ),
        "list": lambda: run_action_list(
            path=parsed.path,  # type: ignore[attr-defined]
            layer_type=getattr(parsed, "layer_type", None),
            layer_fqtn=getattr(parsed, "layer_fqtn", None),
            output_format=getattr(parsed, "output_format", "table"),
        ),
        "show": lambda: run_action_show(
            path=parsed.path,  # type: ignore[attr-defined]
            action_name=parsed.action_name,  # type: ignore[attr-defined]
            output_format=getattr(parsed, "output_format", "table"),
        ),
    }

    action_cmd = getattr(parsed, "action_command", None)
    handler = _ACTION_HANDLERS.get(action_cmd) if action_cmd else None  # type: ignore[arg-type]
    if handler is not None and callable(handler):
        return handler()  # type: ignore[return-value]

    sys.stderr.write("Usage: kata tax action {run|list|show} ...\n")
    sys.stderr.write("\nSubcommands:\n")
    sys.stderr.write("  run   Run a layer action\n")
    sys.stderr.write("  list  List available actions\n")
    sys.stderr.write("  show  Show action details\n")
    return 1


def _handle_cicd(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.cicd import (
        run_cicd_job_show,
        run_cicd_jobs,
        run_cicd_render,
        run_cicd_stages,
        run_cicd_validate,
        run_cicd_workflow_show,
        run_cicd_workflows,
    )

    _CICD_HANDLERS: dict[str, object] = {
        "workflows": lambda: run_cicd_workflows(
            path=parsed.path,  # type: ignore[attr-defined]
            output_format=getattr(parsed, "output_format", "table"),
        ),
        "workflow": lambda: run_cicd_workflow_show(
            path=parsed.path,  # type: ignore[attr-defined]
            workflow_name=parsed.workflow_name,  # type: ignore[attr-defined]
            output_format=getattr(parsed, "output_format", "table"),
        ),
        "jobs": lambda: run_cicd_jobs(
            path=parsed.path,  # type: ignore[attr-defined]
            output_format=getattr(parsed, "output_format", "table"),
        ),
        "job": lambda: run_cicd_job_show(
            path=parsed.path,  # type: ignore[attr-defined]
            job_name=parsed.job_name,  # type: ignore[attr-defined]
            output_format=getattr(parsed, "output_format", "table"),
        ),
        "stages": lambda: run_cicd_stages(
            path=parsed.path,  # type: ignore[attr-defined]
            output_format=getattr(parsed, "output_format", "table"),
        ),
        "validate": lambda: run_cicd_validate(path=parsed.path),  # type: ignore[attr-defined]
        "render": lambda: run_cicd_render(
            path=parsed.path,  # type: ignore[attr-defined]
            workflow_name=parsed.workflow_name,  # type: ignore[attr-defined]
            params=_opt_tuple(getattr(parsed, "params", None)),
            output_file=getattr(parsed, "output_file", None),
        ),
    }

    cicd_cmd = getattr(parsed, "cicd_command", None)
    handler = _CICD_HANDLERS.get(cicd_cmd) if cicd_cmd else None  # type: ignore[arg-type]
    if handler is not None and callable(handler):
        return handler()  # type: ignore[return-value]

    sys.stderr.write(
        "Usage: kata tax cicd {workflows|workflow|jobs|job|stages|validate|render} ...\n",
    )
    sys.stderr.write("\nSubcommands:\n")
    sys.stderr.write("  workflows  List workflow templates\n")
    sys.stderr.write("  workflow   Show workflow details\n")
    sys.stderr.write("  jobs       List job templates\n")
    sys.stderr.write("  job        Show job template details\n")
    sys.stderr.write("  stages     List CICD stages\n")
    sys.stderr.write("  validate   Validate CICD templates\n")
    sys.stderr.write("  render     Render a workflow template\n")
    return 1


def _handle_agents(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.agents import (
        run_agents_create,
        run_agents_generate,
        run_agents_init,
        run_agents_list,
        run_agents_show,
        run_agents_sync,
        run_agents_validate,
    )

    def _agents_create() -> int:
        tools: dict[str, bool] | None = None
        raw_tools = getattr(parsed, "tools", None)
        if raw_tools:
            tools = {}
            for tool_spec in raw_tools:
                if ":" in tool_spec:
                    tool_name, enabled = tool_spec.split(":", 1)
                    tools[tool_name] = enabled.lower() in ("true", "1", "yes")
                else:
                    tools[tool_spec] = True

        return run_agents_create(
            path=parsed.path,  # type: ignore[attr-defined]
            name=cast(str, parsed.name),  # type: ignore[attr-defined]
            description=cast(str, parsed.description),  # type: ignore[attr-defined]
            mode=getattr(parsed, "mode", "all"),
            tools=tools,
            scope_layers=getattr(parsed, "scope_layers", None),
            scope_systems=getattr(parsed, "scope_systems", None),
            scope_stacks=getattr(parsed, "scope_stacks", None),
            scope_layer_types=getattr(parsed, "scope_layer_types", None),
        )

    _AGENTS_HANDLERS: dict[str, object] = {
        "init": lambda: run_agents_init(
            path=parsed.path,  # type: ignore[attr-defined]
            force=getattr(parsed, "force", False),
            no_seed=getattr(parsed, "no_seed", False),
        ),
        "list": lambda: run_agents_list(
            path=parsed.path,  # type: ignore[attr-defined]
            format=getattr(parsed, "output_format", "table"),
            verbose=getattr(parsed, "verbose", False),
            layer_type=getattr(parsed, "layer_type", None),
        ),
        "show": lambda: run_agents_show(
            path=parsed.path,  # type: ignore[attr-defined]
            name=cast(str, parsed.name),  # type: ignore[attr-defined]
            format=getattr(parsed, "output_format", "table"),
        ),
        "validate": lambda: run_agents_validate(path=parsed.path),  # type: ignore[attr-defined]
        "sync": lambda: run_agents_sync(
            path=parsed.path,  # type: ignore[attr-defined]
            force=getattr(parsed, "force", False),
            dry_run=getattr(parsed, "dry_run", False),
        ),
        "create": _agents_create,
        "generate": lambda: run_agents_generate(
            path=parsed.path,  # type: ignore[attr-defined]
            template=getattr(parsed, "template", None),
            layer_type=getattr(parsed, "layer_type", None),
            all_layer_types=getattr(parsed, "all_layer_types", False),
            list_templates=getattr(parsed, "list_templates", False),
            force=getattr(parsed, "force", False),
        ),
    }

    agents_cmd = getattr(parsed, "agents_command", None)
    handler = _AGENTS_HANDLERS.get(agents_cmd) if agents_cmd else None  # type: ignore[arg-type]
    if handler is not None and callable(handler):
        return handler()  # type: ignore[return-value]

    sys.stderr.write("Usage: kata tax agents {init|list|show|validate|sync|create|generate} ...\n")
    sys.stderr.write("\nSubcommands:\n")
    sys.stderr.write("  init      Initialize .agents/ directory and create symlinks\n")
    sys.stderr.write("  list      List all agents and skills\n")
    sys.stderr.write("  show      Show details of an agent or skill\n")
    sys.stderr.write("  validate  Validate all agent definitions\n")
    sys.stderr.write("  sync      Sync bundled agents/skills into local .agents/\n")
    sys.stderr.write("  create    Create a new agent definition\n")
    sys.stderr.write("  generate  Generate agents from templates for layer types\n")
    return 1


def _handle_resolve(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.resolve import run_resolve

    files: list[str] = getattr(parsed, "files", None) or []
    return run_resolve(
        path=parsed.path,  # type: ignore[attr-defined]
        files=files,
    )


def _handle_hooks(parsed: object) -> int:
    from katalyst_taxonomy.cli.commands.hooks import (
        run_hooks_detect_tool,
        run_hooks_generate,
        run_hooks_run,
        run_hooks_validate,
    )

    _HOOKS_HANDLERS: dict[str, object] = {
        "detect-tool": lambda: run_hooks_detect_tool(
            path=parsed.path,  # type: ignore[attr-defined]
        ),
        "generate": lambda: run_hooks_generate(
            path=parsed.path,  # type: ignore[attr-defined]
            tool_override=getattr(parsed, "tool", None),
        ),
        "validate": lambda: run_hooks_validate(
            path=parsed.path,  # type: ignore[attr-defined]
        ),
        "run": lambda: run_hooks_run(
            path=parsed.path,  # type: ignore[attr-defined]
            actions=getattr(parsed, "actions", []) or [],
            files=getattr(parsed, "files", []) or [],
            dry_run=getattr(parsed, "dry_run", False),
            environment=getattr(parsed, "environment", None),
        ),
    }

    hooks_cmd = getattr(parsed, "hooks_command", None)
    handler = _HOOKS_HANDLERS.get(hooks_cmd) if hooks_cmd else None  # type: ignore[arg-type]
    if handler is not None and callable(handler):
        return handler()  # type: ignore[return-value]

    sys.stderr.write("Usage: kata tax hooks {detect-tool|generate|run|validate} ...\n")
    sys.stderr.write("\nSubcommands:\n")
    sys.stderr.write("  detect-tool  Detect the configured hook tool\n")
    sys.stderr.write("  generate     Generate native hook tool config\n")
    sys.stderr.write("  run          Run kata actions for affected layers\n")
    sys.stderr.write("  validate     Validate hooks config against installed actions\n")
    return 1


def _handle_export(parsed: object) -> int:
    """Handle the 'export' command — export taxonomy to external systems."""
    export_target = getattr(parsed, "export_target", None)
    if export_target is None:
        sys.stderr.write("Usage: kata tax export {neo4j|postgres} ...\n")
        sys.stderr.write("\nExport targets:\n")
        sys.stderr.write("  neo4j      Export taxonomy to a Neo4j graph database\n")
        sys.stderr.write("  postgres   Export taxonomy to a PostgreSQL database\n")
        return 1

    if export_target == "neo4j":
        import os

        from katalyst_taxonomy.cli.commands.export import run_export_neo4j

        return run_export_neo4j(
            path=parsed.path,  # type: ignore[attr-defined]
            uri=os.environ.get("NEO4J_URI", getattr(parsed, "uri", "bolt://localhost:7687")),
            username=os.environ.get("NEO4J_USERNAME", getattr(parsed, "username", "neo4j")),
            password=os.environ.get("NEO4J_PASSWORD", getattr(parsed, "password", "password")),
            database=os.environ.get("NEO4J_DATABASE", getattr(parsed, "database", "neo4j")),
            full=getattr(parsed, "full", False),
            dry_run=getattr(parsed, "dry_run", False),
            batch_size=getattr(parsed, "batch_size", 5000),
            verbose=getattr(parsed, "verbose", False),
        )

    if export_target == "postgres":
        import os

        from katalyst_taxonomy.cli.commands.export import run_export_postgres

        return run_export_postgres(
            path=parsed.path,  # type: ignore[attr-defined]
            host=os.environ.get("POSTGRES_HOST", getattr(parsed, "host", "localhost")),
            port=int(os.environ.get("POSTGRES_PORT", str(getattr(parsed, "port", 5432)))),
            database=os.environ.get("POSTGRES_DB", getattr(parsed, "database", "katalyst")),
            username=os.environ.get("POSTGRES_USER", getattr(parsed, "username", "katalyst")),
            password=os.environ.get("POSTGRES_PASSWORD", getattr(parsed, "password", "")),
            dsn=os.environ.get("POSTGRES_DSN", getattr(parsed, "dsn", None)),
            full=getattr(parsed, "full", False),
            dry_run=getattr(parsed, "dry_run", False),
            batch_size=getattr(parsed, "batch_size", 1000),
            verbose=getattr(parsed, "verbose", False),
        )

    sys.stderr.write(f"Unknown export target: {export_target}\n")
    return 1


def _handle_sync(parsed: object) -> int:
    """Handle the 'sync' command — sync taxonomy to backend mirrors."""
    import os

    from katalyst_taxonomy.cli.output import write_warning

    target = getattr(parsed, "target", None)
    full = getattr(parsed, "full", False)
    dry_run = getattr(parsed, "dry_run", False)
    verbose = getattr(parsed, "verbose", False)
    path = cast(Path, getattr(parsed, "path", Path.cwd()))

    if dry_run:
        from katalyst_taxonomy.adapters.filesystem import FilesystemBackend

        backend = FilesystemBackend(base_path=path)
        documents = backend.load_documents()
        environments = backend.load_environments()

        mode = "Full sync" if full else "Incremental sync"
        sys.stdout.write(f"DRY RUN — {mode}\n\n")
        sys.stdout.write(f"Taxonomy path: {path}\n")
        sys.stdout.write(f"Documents: {len(documents)}\n")
        sys.stdout.write(f"Environments: {len(environments)}\n")

        write_warning("No data was written (dry run)", sys.stderr)
        return 0

    # Build a BackendRouter from available config
    from katalyst_taxonomy.adapters.filesystem import FilesystemBackend
    from katalyst_taxonomy.adapters.router import BackendRouter

    primary = FilesystemBackend(base_path=path)
    mirrors: dict[str, object] = {}

    # Check for Neo4j env vars
    neo4j_uri = os.environ.get("NEO4J_URI")
    if neo4j_uri:
        try:
            from katalyst_taxonomy.adapters.neo4j.backend import Neo4jBackend
            from katalyst_taxonomy.adapters.neo4j.config import Neo4jConfig

            neo4j_config = Neo4jConfig(
                uri=neo4j_uri,
                username=os.environ.get("NEO4J_USERNAME", "neo4j"),
                password=os.environ.get("NEO4J_PASSWORD", "password"),
                database=os.environ.get("NEO4J_DATABASE", "neo4j"),
            )
            mirrors["neo4j"] = Neo4jBackend(config=neo4j_config)
        except ImportError:
            if verbose:
                sys.stderr.write("neo4j package not installed, skipping neo4j mirror\n")

    # Check for Postgres env vars
    pg_host = os.environ.get("POSTGRES_HOST")
    pg_dsn = os.environ.get("POSTGRES_DSN")
    if pg_host or pg_dsn:
        try:
            from katalyst_taxonomy.adapters.postgres.backend import PostgresBackend
            from katalyst_taxonomy.adapters.postgres.config import PostgresConfig

            pg_config = PostgresConfig.from_env()
            mirrors["postgres"] = PostgresBackend(config=pg_config)
        except ImportError:
            if verbose:
                sys.stderr.write("asyncpg package not installed, skipping postgres mirror\n")

    if not mirrors:
        write_error("No mirrors configured. Set NEO4J_URI or POSTGRES_HOST environment variables.")
        return 1

    router = BackendRouter(primary=primary, mirrors=mirrors)  # type: ignore[arg-type]
    targets = [target] if target else None

    try:
        results = router.sync(full=full, targets=targets)

        all_ok = True
        for mirror_name, result in results.items():
            if result.success:
                mode = "Full sync" if full else "Incremental sync"
                write_success(f"{mode} to {mirror_name} complete")
                sys.stdout.write(f"  Nodes created: {result.nodes_created}\n")
                sys.stdout.write(f"  Nodes updated: {result.nodes_updated}\n")
                if result.nodes_deleted:
                    sys.stdout.write(f"  Nodes pruned: {result.nodes_deleted}\n")
                sys.stdout.write(f"  Relationships created: {result.relationships_created}\n")
            else:
                all_ok = False
                write_error(f"Sync to {mirror_name} failed")
                for err in result.errors:
                    sys.stderr.write(f"  {err}\n")

        return 0 if all_ok else 1
    finally:
        router.close()


def _handle_build_types(parsed: object) -> int:
    """Handle the 'build-types' command — generate registry + schemas from LinkML."""
    from katalyst_taxonomy.engine.build.pipeline import BuildError, build_types

    node_types_dir = getattr(parsed, "node_types_dir", Path("node_types"))
    output_dir = getattr(parsed, "output_dir", Path("src/katalyst_taxonomy/engine/generated"))
    verbose = getattr(parsed, "verbose", False)
    verify_only = getattr(parsed, "verify_only", False)

    if verify_only:
        import json
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            try:
                result = build_types(
                    node_types_dir=node_types_dir,
                    output_dir=Path(tmpdir),
                    verbose=verbose,
                )
            except BuildError as e:
                write_error(str(e))
                return 1

            # Compare registry.json
            generated_reg = output_dir / "registry.json"
            tmp_reg = Path(tmpdir) / "registry.json"
            if not generated_reg.exists():
                write_error(f"Generated registry not found at {generated_reg}")
                return 1

            with open(generated_reg) as f:
                existing = json.load(f)
            with open(tmp_reg) as f:
                fresh = json.load(f)

            # Compare ignoring generated_at timestamp
            existing.pop("generated_at", None)
            fresh.pop("generated_at", None)

            if existing != fresh:
                write_error(
                    "generated/ is out of date. Run 'kata tax build-types' and commit the result."
                )
                return 1

            count = len(result.get("node_types", {}))
            write_success(f"Verified: {count} node types up to date")
            return 0

    try:
        result = build_types(
            node_types_dir=node_types_dir,
            output_dir=output_dir,
            verbose=verbose,
        )
        count = len(result.get("node_types", {}))
        write_success(f"Build successful: {count} node types generated")
        return 0
    except BuildError as e:
        write_error(str(e))
        return 1


def _handle_migrate(parsed: object) -> int:
    """Handle the 'migrate' command — rewrite v1alpha YAML to v2alpha."""
    from katalyst_taxonomy.engine.migrate import migrate_directory

    base_path = getattr(parsed, "path", None) or Path(".")
    dry_run = getattr(parsed, "dry_run", False)
    no_backup = getattr(parsed, "no_backup", False)

    results = migrate_directory(
        Path(base_path),
        dry_run=dry_run,
        backup=not no_backup,
    )

    total_migrated = sum(r.documents_migrated for r in results)
    total_errors = sum(1 for r in results if r.error)

    if total_errors > 0:
        write_error(f"{total_errors} files had errors during migration")
        return 1

    if total_migrated == 0:
        write_success("No v1alpha documents found to migrate")
        return 0

    action = "Would migrate" if dry_run else "Migrated"
    write_success(f"{action} {total_migrated} documents across {len(results)} files")
    return 0


# ---------------------------------------------------------------------------
# Command registry — maps tax subcommand names to handler functions
# ---------------------------------------------------------------------------

_TAX_COMMAND_HANDLERS: dict[str, object] = {
    "show": _handle_show,
    "get": _handle_get,
    "lint": _handle_lint,
    "create": _handle_create,
    "deps": _handle_deps,
    "status": _handle_status,
    "init": _handle_init,
    "upgrade": _handle_upgrade,
    "rollback": _handle_rollback,
    "add": _handle_add,
    "remove": _handle_remove,
    "clone": _handle_clone,
    "server": _handle_server,
    "action": _handle_action,
    "cicd": _handle_cicd,
    "agents": _handle_agents,
    "resolve": _handle_resolve,
    "hooks": _handle_hooks,
    "export": _handle_export,
    "sync": _handle_sync,
    "build-types": _handle_build_types,
    "migrate": _handle_migrate,
}


def main(args: list[str] | None = None) -> int:
    """Main entry point."""
    parser = create_parser()
    parsed = parser.parse_args(args)

    # Top-level command dispatch
    if not parsed.command:
        parser.print_help()
        return 0

    # TUI stays at top level
    if parsed.command == "tui":
        from katalyst_taxonomy.tui import run as run_tui

        run_tui(path=parsed.path)
        return 0

    # Everything else is under 'tax'
    if parsed.command == "tax":
        return _dispatch_tax(parsed)

    parser.print_help()
    return 1


def _dispatch_tax(parsed: object) -> int:
    """Dispatch taxonomy subcommands via the command registry."""
    tax_command = getattr(parsed, "tax_command", None)

    if not tax_command:
        sys.stderr.write("Usage: kata tax <command> ...\n")
        sys.stderr.write("\nRun 'kata tax --help' for available taxonomy commands.\n")
        return 1

    # Handle format aliases (tree, list, json -> show with format)
    if tax_command in ("tree", "list", "json"):
        format_map = {"tree": FORMAT_TREE, "list": FORMAT_LIST, "json": FORMAT_JSON}
        parsed.format = format_map[tax_command]  # type: ignore[attr-defined]
        tax_command = "show"

    handler = _TAX_COMMAND_HANDLERS.get(tax_command)
    if handler is not None and callable(handler):
        return handler(parsed)  # type: ignore[return-value]

    sys.stderr.write(f"Unknown tax command: {tax_command}\n")
    sys.stderr.write("Run 'kata tax --help' for available commands.\n")
    return 1


if __name__ == "__main__":
    sys.exit(main())
