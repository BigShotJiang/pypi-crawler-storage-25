"""Shared taxonomy loading utilities for CLI commands."""

from __future__ import annotations

from pathlib import Path

from katalyst_taxonomy.server.manager import ServerError, ensure_server
from katalyst_taxonomy.services.taxonomy import TaxonomyService


def load_from_filesystem(path: Path) -> TaxonomyService:
    """Load taxonomy data from the filesystem.

    This is used internally by the server and for testing.
    CLI commands should use load_taxonomy() instead.
    """
    from katalyst_taxonomy.adapters.filesystem import FilesystemBackend

    backend = FilesystemBackend(base_path=path)
    documents = backend.load_documents()
    environments = backend.load_environments()
    errors = backend.errors()

    return TaxonomyService(
        documents=documents,
        environments=environments,
        errors=errors,
    )


def load_from_server(server_url: str) -> TaxonomyService:
    """Load taxonomy data from the server."""
    import asyncio

    from katalyst_taxonomy.client import KatalystClient
    from katalyst_taxonomy.client.models import ErrorResponse, NodeResponse
    from katalyst_taxonomy.domain.errors import DocumentError
    from katalyst_taxonomy.engine.document import V2_API_VERSION, Document, Metadata
    from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

    def _convert_node(node: NodeResponse) -> Document:
        """Convert a NodeResponse to a Document."""
        spec: dict[str, object] = {}
        if node.spec.description is not None:
            spec["description"] = node.spec.description
        if node.spec.owners:
            spec["owners"] = list(node.spec.owners)
        if node.spec.annotations:
            spec["annotations"] = dict(node.spec.annotations)
        if node.spec.environments:
            spec["environments"] = list(node.spec.environments)
        if node.spec.parents:
            spec["parents"] = dict(node.spec.parents)
        if node.spec.depends_on:
            spec["dependsOn"] = dict(node.spec.depends_on)

        return Document(
            api_version=V2_API_VERSION,
            kind=node.taxonomy_node_type,
            metadata=Metadata(
                name=node.metadata.name,
                labels=dict(node.metadata.labels) if node.metadata.labels else {},
            ),
            spec=spec,
            source_path=Path(node.source_path) if node.source_path else None,
        )

    def _convert_error(err: ErrorResponse) -> DocumentError:
        """Convert an ErrorResponse to a DocumentError."""
        return DocumentError(
            message=err.message,
            path=Path(err.path) if err.path else Path("<unknown>"),
            document_index=err.document_index or 0,
        )

    async def fetch() -> TaxonomyService:
        async with KatalystClient(base_url=server_url) as client:
            response = await client.get_taxonomy()

        # Convert response models to domain objects
        documents: list[Document] = [_convert_node(node) for node in response.documents]

        # Convert environment responses
        env_documents: list[EnvironmentDocument] = []
        for env in response.environments:
            env_doc = EnvironmentDocument(
                name=env.name,
                description=env.description,
                template_replacements=dict(env.template_replacements),
                layer_templates={k: dict(v) for k, v in env.layer_templates.items()},
                source_path=Path(env.source_path) if env.source_path else None,
            )
            env_documents.append(env_doc)

        # Convert errors
        errors: list[DocumentError] = [_convert_error(e) for e in response.errors]

        return TaxonomyService(
            documents=tuple(documents),
            environments=tuple(env_documents),
            errors=tuple(errors),
        )

    return asyncio.run(fetch())


def load_taxonomy(path: Path) -> TaxonomyService:
    """Load taxonomy data, ensuring the server is running.

    This is the primary entry point for CLI commands. It:
    1. Ensures the server is running for the given path
    2. Loads taxonomy data via HTTP from the server

    Args:
        path: Path to the taxonomy directory.

    Returns:
        TaxonomyService with loaded taxonomy data.

    Raises:
        ServerError: If the server fails to start.
    """
    state = ensure_server(path)
    return load_from_server(state.url)


def get_base_path_from_server(path: Path) -> Path | None:
    """Get the base path that the server is using.

    Args:
        path: Path to ensure server is running for.

    Returns:
        The resolved base path the server is using, or None if server isn't running.
    """
    try:
        state = ensure_server(path)
        return Path(state.path)
    except ServerError:
        return None
