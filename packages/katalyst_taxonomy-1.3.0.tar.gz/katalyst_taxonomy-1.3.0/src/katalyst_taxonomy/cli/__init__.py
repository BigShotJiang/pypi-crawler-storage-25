"""Katalyst CLI package."""

from katalyst_taxonomy import __version__

__all__ = ["__version__"]
