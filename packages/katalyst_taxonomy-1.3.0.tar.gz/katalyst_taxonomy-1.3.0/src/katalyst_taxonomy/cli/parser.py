"""Argument parser for the Katalyst CLI."""

# pyright: reportPrivateUsage=false

from __future__ import annotations

import argparse
from pathlib import Path

# Output format constants
FORMAT_TREE = "tree"
FORMAT_LIST = "list"
FORMAT_JSON = "json"
FORMAT_MARKDOWN = "markdown"

# --- Registry-driven type lists ---
_creatable_types_cache: list[str] | None = None
_clonable_types_cache: list[str] | None = None


def _get_creatable_types() -> list[str]:
    """Get the list of node types that can be created, from the registry."""
    global _creatable_types_cache
    if _creatable_types_cache is None:
        try:
            from katalyst_taxonomy.engine.bridge import get_default_registry

            registry = get_default_registry()
            _creatable_types_cache = [
                desc.kind
                for desc in sorted(registry.all_descriptors(), key=lambda d: d.display_order)
                if not desc.is_extension
            ]
        except Exception:
            _creatable_types_cache = [
                "system",
                "stack",
                "library",
                "layer",
                "organization",
                "program",
                "project",
                "team",
                "team_member",
            ]
    return _creatable_types_cache


def _get_clonable_types() -> list[str]:
    """Get the list of node types that can be cloned.

    Clonable types are non-root, non-extension types (you clone children, not roots).
    """
    global _clonable_types_cache
    if _clonable_types_cache is None:
        try:
            from katalyst_taxonomy.engine.bridge import get_default_registry

            registry = get_default_registry()
            _clonable_types_cache = [
                desc.kind
                for desc in sorted(registry.all_descriptors(), key=lambda d: d.display_order)
                if not desc.is_extension and not desc.is_root and desc.parent_required
            ]
        except Exception:
            _clonable_types_cache = ["layer", "stack"]
    return _clonable_types_cache


def create_parser() -> argparse.ArgumentParser:
    """Create the main argument parser with subcommands.

    Top-level structure:
        kata tui          - Launch interactive TUI
        kata tax <command> - All taxonomy operations
    """
    parser = argparse.ArgumentParser(
        prog="kata",
        description="Katalyst CLI - manage and explore taxonomy documents",
    )
    parser.add_argument(
        "--path",
        "-p",
        type=Path,
        default=Path.cwd(),
        help="Path to the repository root (default: current directory)",
    )
    parser.add_argument(
        "--backend",
        choices=["filesystem", "neo4j", "postgres"],
        default="filesystem",
        help="Primary backend",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Top-level commands (non-taxonomy)
    _add_tui_command(subparsers)

    # Taxonomy command group
    _add_tax_group(subparsers)

    return parser


def _add_tax_group(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add the 'tax' command group containing all taxonomy operations."""
    tax_parser = subparsers.add_parser(
        "tax",
        help="Taxonomy operations",
        description="Katalyst taxonomy operations - view, create, manage, and validate taxonomy nodes",
    )
    # Allow --path on the tax subcommand too (in addition to the root parser)
    # so both `kata --path /foo tax init` and `kata tax --path /foo init` work.
    # Using SUPPRESS as default so that when --path is NOT provided on the tax
    # subparser, it doesn't set the attribute at all, preserving the root parser's
    # value (or the root parser's default of cwd).
    tax_parser.add_argument(
        "--path",
        "-p",
        type=Path,
        default=argparse.SUPPRESS,
        help="Path to the repository root (default: current directory)",
    )
    tax_subparsers = tax_parser.add_subparsers(dest="tax_command", help="Taxonomy commands")

    _add_show_commands(tax_subparsers)
    _add_get_command(tax_subparsers)
    _add_lint_command(tax_subparsers)
    _add_create_command(tax_subparsers)
    _add_deps_command(tax_subparsers)
    _add_action_command(tax_subparsers)
    _add_cicd_command(tax_subparsers)
    _add_status_command(tax_subparsers)
    _add_init_command(tax_subparsers)
    _add_upgrade_command(tax_subparsers)
    _add_rollback_command(tax_subparsers)
    _add_add_command(tax_subparsers)
    _add_remove_command(tax_subparsers)
    _add_clone_command(tax_subparsers)
    _add_agents_command(tax_subparsers)
    _add_resolve_command(tax_subparsers)
    _add_hooks_command(tax_subparsers)
    _add_server_command(tax_subparsers)
    _add_export_command(tax_subparsers)
    _add_sync_command(tax_subparsers)


def _add_tui_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add TUI command."""
    subparsers.add_parser(
        "tui",
        help="Launch the interactive TUI",
    )


def _add_server_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add server command and subcommands."""
    server_parser = subparsers.add_parser(
        "server",
        help="Manage the Katalyst server",
    )
    server_subparsers = server_parser.add_subparsers(dest="server_action", help="Server actions")

    # server start
    server_start_parser = server_subparsers.add_parser(
        "start",
        help="Start the server",
    )
    server_start_parser.add_argument(
        "--port",
        type=int,
        default=None,
        help="Port to bind to (default: auto-find available)",
    )
    server_start_parser.add_argument(
        "--idle-timeout",
        type=int,
        default=300,
        help="Idle timeout in seconds (default: 300)",
    )

    # server stop
    server_subparsers.add_parser(
        "stop",
        help="Stop the running server",
        description="Stop the running server",
    )

    # server status
    server_subparsers.add_parser(
        "status",
        help="Show server status",
        description="Show server status",
    )

    # server restart
    server_restart_parser = server_subparsers.add_parser(
        "restart",
        help="Restart the server",
    )
    server_restart_parser.add_argument(
        "--port",
        type=int,
        default=None,
        help="Port to bind to (default: reuse current or auto-find)",
    )
    server_restart_parser.add_argument(
        "--idle-timeout",
        type=int,
        default=300,
        help="Idle timeout in seconds (default: 300)",
    )


def _add_show_commands(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add show command and format aliases (tree, list, json)."""
    # show command - primary viewing command
    show_parser = subparsers.add_parser(
        "show",
        help="Show taxonomy (default: tree format)",
    )
    show_parser.add_argument(
        "name",
        nargs="?",
        default=None,
        help="Name of a specific node to show",
    )
    show_parser.add_argument(
        "--format",
        "-o",
        choices=[FORMAT_TREE, FORMAT_LIST, FORMAT_JSON],
        default=FORMAT_TREE,
        help="Output format (default: tree)",
    )

    # tree command - alias for show --format=tree
    tree_parser = subparsers.add_parser(
        "tree",
        help="Show taxonomy as a tree (alias for: show --format=tree)",
    )
    tree_parser.add_argument(
        "name",
        nargs="?",
        default=None,
        help="Name of a specific node to show",
    )

    # list command - alias for show --format=list
    list_parser = subparsers.add_parser(
        "list",
        help="Show taxonomy as grouped list (alias for: show --format=list)",
    )
    list_parser.add_argument(
        "name",
        nargs="?",
        default=None,
        help="Name of a specific node to show",
    )

    # json command - alias for show --format=json
    json_parser = subparsers.add_parser(
        "json",
        help="Show taxonomy as JSON (alias for: show --format=json)",
    )
    json_parser.add_argument(
        "name",
        nargs="?",
        default=None,
        help="Name of a specific node to show",
    )


def _add_get_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add get command."""
    get_parser = subparsers.add_parser(
        "get",
        help="Get a specific taxonomy node (default: JSON output)",
    )
    get_parser.add_argument(
        "name",
        help="Name of the node to get",
    )
    get_parser.add_argument(
        "--format",
        "-o",
        choices=[FORMAT_JSON, FORMAT_LIST],
        default=FORMAT_JSON,
        help="Output format (default: json)",
    )


def _add_lint_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add lint command."""
    lint_parser = subparsers.add_parser(
        "lint",
        help="Validate taxonomy against schema",
        description="Validate taxonomy against schema",
    )
    lint_parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Show detailed error information including hints and qualified names",
    )


def _add_create_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add create command."""
    create_parser = subparsers.add_parser(
        "create",
        help="Create a new taxonomy node",
        description="Create a new taxonomy node",
    )
    create_parser.add_argument(
        "type",
        choices=_get_creatable_types(),
        help="Type of node to create",
    )
    create_parser.add_argument(
        "name",
        help="Name for the new node",
    )
    create_parser.add_argument(
        "--description",
        "-d",
        help="Description for the node",
    )
    create_parser.add_argument(
        "--owner",
        "-O",
        dest="owners",
        action="append",
        help="Owner email (can be specified multiple times)",
    )
    create_parser.add_argument(
        "--env",
        "-e",
        dest="environments",
        action="append",
        help="Environment (can be specified multiple times)",
    )
    create_parser.add_argument(
        "--parent",
        help="Direct parent name (required for stack/layer, optional for nested system)",
    )
    create_parser.add_argument(
        "--parent-system",
        help="Parent system name (for nested system/stack/layer)",
    )
    create_parser.add_argument(
        "--layer-type",
        help="Layer type (for layer nodes, e.g., aws-lambda, app-docker)",
    )
    create_parser.add_argument(
        "--target-dir",
        help="Override computed directory — place the node YAML file in this directory instead",
    )
    create_parser.add_argument(
        "--output-format",
        choices=["yaml", "markdown"],
        default="yaml",
        help="Output format for the created file (default: yaml)",
    )


def _add_deps_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add deps command."""
    deps_parser = subparsers.add_parser(
        "deps",
        help="Show dependency graph",
    )
    deps_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["tree", "list", "json", "mermaid"],
        default="tree",
        help="Output format (default: tree)",
    )
    deps_parser.add_argument(
        "--node",
        "-n",
        help="Filter to a specific node (name or FQTN)",
    )
    deps_parser.add_argument(
        "--reverse",
        "-r",
        action="store_true",
        help="Show dependents (what depends on this) instead of dependencies",
    )


def _add_action_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add action command and subcommands."""
    action_parser = subparsers.add_parser(
        "action",
        help="Run, list, or show layer actions",
    )
    action_subparsers = action_parser.add_subparsers(
        dest="action_command",
        help="Action subcommands",
    )

    # action run
    action_run_parser = action_subparsers.add_parser(
        "run",
        help="Run a layer action",
    )
    action_run_parser.add_argument(
        "action_name",
        help="Name of the action to run",
    )
    action_run_parser.add_argument(
        "layer",
        help="Layer FQTN (e.g., system.stack.layer)",
    )
    action_run_parser.add_argument(
        "--env",
        "-e",
        dest="environment",
        help="Environment to inject as ENV variable",
    )
    action_run_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be run without executing",
    )
    action_run_parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Only show command output, no headers",
    )
    action_run_parser.add_argument(
        "--timeout",
        type=int,
        help="Override action timeout (seconds)",
    )

    # action list
    action_list_parser = action_subparsers.add_parser(
        "list",
        help="List available layer actions",
    )
    action_list_parser.add_argument(
        "--layer-type",
        help="Filter by layer type",
    )
    action_list_parser.add_argument(
        "--layer",
        dest="layer_fqtn",
        help="Show actions for a specific layer (FQTN)",
    )
    action_list_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )

    # action show
    action_show_parser = action_subparsers.add_parser(
        "show",
        help="Show details of a specific action",
    )
    action_show_parser.add_argument(
        "action_name",
        help="Name of the action to show",
    )
    action_show_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )


def _add_cicd_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add cicd command and subcommands."""
    cicd_parser = subparsers.add_parser(
        "cicd",
        help="View, render, and validate CICD templates",
    )
    cicd_subparsers = cicd_parser.add_subparsers(dest="cicd_command", help="CICD subcommands")

    # cicd workflows
    cicd_workflows_parser = cicd_subparsers.add_parser(
        "workflows",
        help="List workflow templates",
    )
    cicd_workflows_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )

    # cicd workflow <name>
    cicd_workflow_parser = cicd_subparsers.add_parser(
        "workflow",
        help="Show details of a specific workflow template",
    )
    cicd_workflow_parser.add_argument(
        "workflow_name",
        help="Name of the workflow to show",
    )
    cicd_workflow_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )

    # cicd jobs
    cicd_jobs_parser = cicd_subparsers.add_parser(
        "jobs",
        help="List job templates",
    )
    cicd_jobs_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )

    # cicd job <name>
    cicd_job_parser = cicd_subparsers.add_parser(
        "job",
        help="Show details of a specific job template",
    )
    cicd_job_parser.add_argument(
        "job_name",
        help="Name of the job template to show",
    )
    cicd_job_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )

    # cicd stages
    cicd_stages_parser = cicd_subparsers.add_parser(
        "stages",
        help="List CICD stages",
    )
    cicd_stages_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )

    # cicd validate
    cicd_subparsers.add_parser(
        "validate",
        help="Validate CICD templates",
    )

    # cicd render
    cicd_render_parser = cicd_subparsers.add_parser(
        "render",
        help="Render a workflow template",
    )
    cicd_render_parser.add_argument(
        "workflow_name",
        help="Name of the workflow to render",
    )
    cicd_render_parser.add_argument(
        "--param",
        "-p",
        dest="params",
        action="append",
        help="Parameter as key=value (can be specified multiple times)",
    )
    cicd_render_parser.add_argument(
        "--output",
        "-o",
        dest="output_file",
        help="Output file (default: stdout)",
    )


def _add_status_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add status command."""
    subparsers.add_parser(
        "status",
        help="Show installed Katalyst components and versions",
        description="Show installed Katalyst components and versions",
    )


def _add_init_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add init command."""
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize a new taxonomy repository",
        description="Initialize a new taxonomy repository",
    )
    init_parser.add_argument(
        "--source",
        default="bundled",
        help="Template source URI (default: bundled)",
    )
    init_parser.add_argument(
        "--plugin",
        dest="plugins",
        action="append",
        help="Plugin to install (can be specified multiple times)",
    )
    init_parser.add_argument(
        "--layer-type",
        dest="layer_types",
        action="append",
        help="Layer type to install (can be specified multiple times)",
    )
    init_parser.add_argument(
        "--env",
        "-e",
        dest="environments",
        action="append",
        help="Environment to include (can be specified multiple times, default: dev/staging/prod)",
    )
    init_parser.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompts (non-interactive mode)",
    )


def _add_upgrade_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add upgrade command."""
    upgrade_parser = subparsers.add_parser(
        "upgrade",
        help="Upgrade installed taxonomy components",
    )
    upgrade_parser.add_argument(
        "--source",
        default="bundled",
        help="Template source URI (default: bundled)",
    )
    upgrade_parser.add_argument(
        "--component",
        dest="components",
        action="append",
        help="Component to upgrade (can be specified multiple times)",
    )
    upgrade_parser.add_argument(
        "--item",
        dest="items",
        action="append",
        help="Specific item to upgrade within a plugin (can be specified multiple times)",
    )
    upgrade_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be upgraded without making changes",
    )
    upgrade_parser.add_argument(
        "--check",
        action="store_true",
        help="Only check for available updates",
    )
    upgrade_parser.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompts",
    )
    upgrade_parser.add_argument(
        "--no-backup",
        action="store_true",
        help="Skip creating backup before upgrade",
    )
    upgrade_parser.add_argument(
        "--diff",
        action="store_true",
        help="Show file diffs for available updates",
    )


def _add_rollback_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add rollback command."""
    rollback_parser = subparsers.add_parser(
        "rollback",
        help="Restore from a previous backup",
        description="Restore from a previous backup",
    )
    rollback_parser.add_argument(
        "--list",
        "-l",
        dest="list_backups",
        action="store_true",
        help="List available backups",
    )
    rollback_parser.add_argument(
        "--backup",
        "-b",
        dest="backup_name",
        help="Specific backup to restore (default: latest)",
    )
    rollback_parser.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompt",
    )


def _add_add_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add add command."""
    add_parser = subparsers.add_parser(
        "add",
        help="Add plugins and layer types to an existing taxonomy",
    )
    add_parser.add_argument(
        "--plugin",
        dest="plugins",
        action="append",
        help="Plugin to add (can be specified multiple times)",
    )
    add_parser.add_argument(
        "--layer-type",
        dest="layer_types",
        action="append",
        help="Layer type to add (can be specified multiple times)",
    )
    add_parser.add_argument(
        "--source",
        default="bundled",
        help="Template source URI (default: bundled)",
    )
    add_parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Overwrite existing components",
    )
    add_parser.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompts",
    )


def _add_remove_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add remove command."""
    remove_parser = subparsers.add_parser(
        "remove",
        help="Remove plugins and layer types from an existing taxonomy",
    )
    remove_parser.add_argument(
        "--plugin",
        dest="plugins",
        action="append",
        help="Plugin to remove (can be specified multiple times)",
    )
    remove_parser.add_argument(
        "--layer-type",
        dest="layer_types",
        action="append",
        help="Layer type to remove (can be specified multiple times)",
    )
    remove_parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Remove even if files are modified",
    )
    remove_parser.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompts",
    )


def _add_agents_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add agents command and subcommands."""
    agents_parser = subparsers.add_parser(
        "agents",
        help="Manage AI coding assistant definitions",
    )
    agents_subparsers = agents_parser.add_subparsers(
        dest="agents_command",
        help="Agents subcommands",
    )

    # agents init
    agents_init_parser = agents_subparsers.add_parser(
        "init",
        help="Initialize .agents/ directory and create OpenCode symlinks",
    )
    agents_init_parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Force overwrite existing files/symlinks",
    )
    agents_init_parser.add_argument(
        "--no-seed",
        action="store_true",
        help="Skip seeding bundled agents/skills (create empty structure only)",
    )

    # agents list
    agents_list_parser = agents_subparsers.add_parser(
        "list",
        help="List all agents and skills",
    )
    agents_list_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )
    agents_list_parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Show additional details",
    )
    agents_list_parser.add_argument(
        "--layer-type",
        dest="layer_type",
        help="Filter agents/skills by layer type (e.g. app-docker)",
    )

    # agents show
    agents_show_parser = agents_subparsers.add_parser(
        "show",
        help="Show details of a specific agent or skill",
    )
    agents_show_parser.add_argument(
        "name",
        help="Name of the agent or skill to show",
    )
    agents_show_parser.add_argument(
        "--format",
        "-o",
        dest="output_format",
        choices=["table", "json"],
        default="table",
        help="Output format (default: table)",
    )

    # agents validate
    agents_subparsers.add_parser(
        "validate",
        help="Validate all agent definitions",
    )

    # agents sync
    agents_sync_parser = agents_subparsers.add_parser(
        "sync",
        help="Sync bundled agents/skills into local .agents/ directory",
    )
    agents_sync_parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Overwrite existing files with bundled versions",
    )
    agents_sync_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without making changes",
    )

    # agents generate
    agents_generate_parser = agents_subparsers.add_parser(
        "generate",
        help="Generate agents from templates for layer types",
    )
    agents_generate_parser.add_argument(
        "--template",
        "-t",
        help="Template to use (default: layer-helper)",
    )
    agents_generate_parser.add_argument(
        "--layer-type",
        help="Layer type to generate agent for",
    )
    agents_generate_parser.add_argument(
        "--all-layer-types",
        action="store_true",
        help="Generate agents for all discovered layer types",
    )
    agents_generate_parser.add_argument(
        "--list-templates",
        action="store_true",
        help="List available templates and exit",
    )
    agents_generate_parser.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Overwrite existing agent files",
    )

    # agents create
    agents_create_parser = agents_subparsers.add_parser(
        "create",
        help="Create a new agent definition",
    )
    agents_create_parser.add_argument(
        "name",
        help="Agent name (kebab-case, e.g., my-agent)",
    )
    agents_create_parser.add_argument(
        "--description",
        "-d",
        required=True,
        help="Agent description (trigger condition)",
    )
    agents_create_parser.add_argument(
        "--mode",
        "-m",
        choices=["primary", "subagent", "all"],
        default="all",
        help="Interaction mode (default: all)",
    )
    agents_create_parser.add_argument(
        "--tool",
        "-t",
        dest="tools",
        action="append",
        help="Enable/disable tools as tool:true/false (can be specified multiple times)",
    )
    agents_create_parser.add_argument(
        "--scope-layer",
        dest="scope_layers",
        action="append",
        help="Layer FQTN for scope binding (can be specified multiple times)",
    )
    agents_create_parser.add_argument(
        "--scope-system",
        dest="scope_systems",
        action="append",
        help="System name for scope binding (can be specified multiple times)",
    )
    agents_create_parser.add_argument(
        "--scope-stack",
        dest="scope_stacks",
        action="append",
        help="Stack FQTN for scope binding (can be specified multiple times)",
    )
    agents_create_parser.add_argument(
        "--scope-layer-type",
        dest="scope_layer_types",
        action="append",
        help="Layer type for scope binding (can be specified multiple times)",
    )


def _add_clone_command(subparsers: argparse._SubParsersAction[argparse.ArgumentParser]) -> None:
    """Add clone command."""
    clone_parser = subparsers.add_parser(
        "clone",
        help="Clone a taxonomy node (layer or stack)",
    )
    clone_parser.add_argument(
        "type",
        choices=_get_clonable_types(),
        help="Type of node to clone",
    )
    clone_parser.add_argument(
        "source",
        help="Name of the source node to clone",
    )
    clone_parser.add_argument(
        "target",
        help="Name for the cloned node",
    )
    # Source hierarchy hints for disambiguation
    clone_parser.add_argument(
        "--source-system",
        help="Source system name (for disambiguation)",
    )
    clone_parser.add_argument(
        "--source-stack",
        help="Source stack name (for disambiguation)",
    )
    # Target hierarchy (defaults to source if not specified)
    clone_parser.add_argument(
        "--target-system",
        help="Target system (defaults to source)",
    )
    clone_parser.add_argument(
        "--target-stack",
        help="Target stack (defaults to source)",
    )
    # Overrides
    clone_parser.add_argument(
        "--description",
        "-d",
        help="Description override for cloned node",
    )
    clone_parser.add_argument(
        "--owner",
        "-O",
        dest="owners",
        action="append",
        help="Owner override (can be specified multiple times)",
    )
    clone_parser.add_argument(
        "--env",
        "-e",
        dest="environments",
        action="append",
        help="Environment override (can be specified multiple times)",
    )
    clone_parser.add_argument(
        "--layer-type",
        dest="layer_type",
        help="Layer type override (for layers)",
    )
    # Behavior flags
    clone_parser.add_argument(
        "--scaffold",
        action="store_true",
        help="Re-scaffold from layer type template instead of copying files",
    )
    clone_parser.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Skip confirmation prompts",
    )


def _add_resolve_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    """Add the ``resolve`` subcommand for mapping files to layers."""
    resolve_parser = subparsers.add_parser(
        "resolve",
        help="Resolve file paths to taxonomy layers",
        description=(
            "Map file paths to their parent taxonomy layers. "
            "Returns a JSON object with resolved layers (FQTN, layerType, changed files) "
            "and unmapped files."
        ),
    )
    resolve_parser.add_argument(
        "--files",
        nargs="+",
        metavar="FILE",
        help="File paths to resolve (relative to repo root)",
    )


def _add_hooks_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    """Add the ``hooks`` subcommand for git hook management."""
    hooks_parser = subparsers.add_parser(
        "hooks",
        help="Git hooks management",
        description=(
            "Manage pre-commit hooks that integrate with kata actions. "
            "Supports pre-commit, Husky, and lefthook."
        ),
    )
    hooks_subparsers = hooks_parser.add_subparsers(
        dest="hooks_command",
        help="Hooks subcommands",
    )

    # hooks detect-tool
    hooks_subparsers.add_parser(
        "detect-tool",
        help="Detect the configured hook tool from .katalyst-hooks.yaml",
    )

    # hooks generate
    generate_parser = hooks_subparsers.add_parser(
        "generate",
        help="Generate native hook tool config from .katalyst-hooks.yaml",
    )
    generate_parser.add_argument(
        "--tool",
        choices=["pre-commit", "husky", "lefthook"],
        default=None,
        help="Override the tool (default: from .katalyst-hooks.yaml)",
    )

    # hooks validate
    hooks_subparsers.add_parser(
        "validate",
        help="Validate hooks config against installed actions",
    )

    # hooks run
    run_parser = hooks_subparsers.add_parser(
        "run",
        help="Run kata actions against layers affected by changed files",
    )
    run_parser.add_argument(
        "--action",
        dest="actions",
        action="append",
        default=[],
        help="Action to run (repeatable)",
    )
    run_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be run without executing",
    )
    run_parser.add_argument(
        "--env",
        "-e",
        dest="environment",
        default=None,
        help="Environment for action execution",
    )
    run_parser.add_argument(
        "files",
        nargs="*",
        metavar="FILE",
        help="Changed file paths",
    )


def _add_sync_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    """Add the ``sync`` subcommand for syncing taxonomy to backend mirrors."""
    sync_parser = subparsers.add_parser(
        "sync",
        help="Sync taxonomy to backend mirrors",
    )
    sync_parser.add_argument(
        "--target",
        help="Specific mirror to sync (default: all)",
    )
    sync_parser.add_argument(
        "--full",
        action="store_true",
        help="Full sync (clear + recreate)",
    )
    sync_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview only",
    )
    sync_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
    )


def _add_export_command(
    subparsers: argparse._SubParsersAction[argparse.ArgumentParser],
) -> None:
    """Add the ``export`` subcommand for exporting taxonomy to external systems."""
    export_parser = subparsers.add_parser(
        "export",
        help="Export taxonomy to external systems",
        description="Export the taxonomy graph to external systems like Neo4j.",
    )
    export_subparsers = export_parser.add_subparsers(
        dest="export_target",
        help="Export target",
    )

    # export neo4j
    neo4j_parser = export_subparsers.add_parser(
        "neo4j",
        help="Export taxonomy to a Neo4j graph database",
    )
    neo4j_parser.add_argument(
        "--uri",
        default="bolt://localhost:7687",
        help="Neo4j URI (default: bolt://localhost:7687, env: NEO4J_URI)",
    )
    neo4j_parser.add_argument(
        "--username",
        default="neo4j",
        help="Neo4j username (default: neo4j, env: NEO4J_USERNAME)",
    )
    neo4j_parser.add_argument(
        "--password",
        default="password",
        help="Neo4j password (env: NEO4J_PASSWORD)",
    )
    neo4j_parser.add_argument(
        "--database",
        default="neo4j",
        help="Neo4j database (default: neo4j, env: NEO4J_DATABASE)",
    )
    neo4j_parser.add_argument(
        "--full",
        action="store_true",
        help="Perform full export (clear + recreate) instead of incremental sync",
    )
    neo4j_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be exported without writing to Neo4j",
    )
    neo4j_parser.add_argument(
        "--batch-size",
        type=int,
        default=5000,
        help="Batch size for UNWIND operations (default: 5000)",
    )
    neo4j_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Show detailed progress",
    )

    # export postgres
    postgres_parser = export_subparsers.add_parser(
        "postgres",
        help="Export taxonomy to a PostgreSQL database",
    )
    postgres_parser.add_argument(
        "--host",
        default="localhost",
        help="PostgreSQL host (default: localhost, env: POSTGRES_HOST)",
    )
    postgres_parser.add_argument(
        "--port",
        type=int,
        default=5432,
        help="PostgreSQL port (default: 5432, env: POSTGRES_PORT)",
    )
    postgres_parser.add_argument(
        "--database",
        default="katalyst",
        help="PostgreSQL database (default: katalyst, env: POSTGRES_DB)",
    )
    postgres_parser.add_argument(
        "--username",
        default="katalyst",
        help="PostgreSQL username (default: katalyst, env: POSTGRES_USER)",
    )
    postgres_parser.add_argument(
        "--password",
        default="",
        help="PostgreSQL password (env: POSTGRES_PASSWORD)",
    )
    postgres_parser.add_argument(
        "--dsn",
        default=None,
        help="PostgreSQL DSN — overrides individual params (env: POSTGRES_DSN)",
    )
    postgres_parser.add_argument(
        "--full",
        action="store_true",
        help="Perform full export (clear + recreate) instead of incremental sync",
    )
    postgres_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be exported without writing to PostgreSQL",
    )
    postgres_parser.add_argument(
        "--batch-size",
        type=int,
        default=1000,
        help="Batch size for bulk operations (default: 1000)",
    )
    postgres_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Show detailed progress",
    )

    build_parser = subparsers.add_parser(
        "build-types",
        help="Build taxonomy type artifacts from LinkML schemas",
        description=(
            "Generate registry.json and JSON schemas from LinkML node type "
            "definitions in node_types/."
        ),
    )
    build_parser.add_argument(
        "--node-types-dir",
        type=Path,
        default=Path("node_types"),
        help="Directory containing LinkML YAML schemas (default: node_types/)",
    )
    build_parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("src/katalyst_taxonomy/engine/generated"),
        help="Output directory for generated artifacts",
    )
    build_parser.add_argument(
        "--verify-only",
        action="store_true",
        help="Only verify generated/ is up to date, don't write",
    )
    build_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Verbose output",
    )

    # --- migrate command ---
    migrate_parser = subparsers.add_parser(
        "migrate",
        help="Migrate taxonomy YAML files from v1alpha to v2alpha format",
        description=(
            "Rewrite v1alpha taxonomy documents to v2alpha format. "
            "Transforms apiVersion, promotes taxonomyNodeType to kind, "
            "and restructures the document."
        ),
    )
    migrate_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be migrated without writing changes",
    )
    migrate_parser.add_argument(
        "--no-backup",
        action="store_true",
        help="Don't create .bak backup files",
    )
