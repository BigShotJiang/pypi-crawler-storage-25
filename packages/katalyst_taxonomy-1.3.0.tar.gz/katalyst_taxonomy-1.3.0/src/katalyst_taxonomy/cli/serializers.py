"""Serialization helpers for taxonomy documents.

.. deprecated::
    This module has been relocated to ``katalyst_taxonomy.services.serialization``.
    Import directly from there instead. This file will be removed in a future version.
"""

from __future__ import annotations

from katalyst_taxonomy.services.serialization import serialize_document

__all__ = ["serialize_document"]
