"""Filesystem-based adapter for creating taxonomy documents."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import yaml

from katalyst_taxonomy.adapters.filesystem._parsing import (
    document_to_mapping as _document_to_mapping,
)
from katalyst_taxonomy.adapters.filesystem._parsing import (
    serialize_taxonomy_markdown as _serialize_taxonomy_markdown,
)

from ..documents import TaxonomyDocument
from ..management import TaxonomyWriter


def _build_kind_directories() -> dict[str, str]:
    """Build the kind→directory mapping from the v2 registry."""
    from katalyst_taxonomy.engine.bridge import get_default_registry

    registry = get_default_registry()
    return {desc.kind: desc.directory_name for desc in registry.all_descriptors()}


# Lazily populated on first access to avoid import-time registry loading.
_kind_directories_cache: dict[str, str] | None = None


def _get_kind_directories() -> dict[str, str]:
    global _kind_directories_cache
    if _kind_directories_cache is None:
        _kind_directories_cache = _build_kind_directories()
    return _kind_directories_cache


# Kept as an empty dict for backward compatibility.
# All internal usage goes through _get_kind_directories().
KIND_DIRECTORIES: dict[str, str] = {}


@dataclass(slots=True)
class FilesystemTaxonomyWriter(TaxonomyWriter):
    """Persist taxonomy documents to the filesystem."""

    base_path: Path
    default_filename: str = "taxonomy.yaml"
    output_format: str = "yaml"  # "yaml" or "markdown"

    def create(self, document: TaxonomyDocument) -> None:
        layout = self._determine_layout()
        if layout == "single-file":
            if self.output_format == "markdown":
                # Markdown does not support multi-document append.
                target = self._target_path_for_kind_md(document)
                self._write_markdown_file(target, document)
                return
            target = self._single_file_path()
            self._append_to_file(target, document)
            return
        if layout == "by-kind":
            if self.output_format == "markdown":
                target = self._target_path_for_kind_md(document)
                self._write_markdown_file(target, document)
            else:
                target = self._target_path_for_kind(document)
                self._write_new_file(target, document)
            return

        if self.output_format == "markdown":
            target = self._target_path_for_kind_md(document)
            self._write_markdown_file(target, document)
        else:
            target = self._single_file_path()
            self._append_to_file(target, document)

    # layout helpers -----------------------------------------------------

    def _determine_layout(self) -> str:
        if self.base_path.is_file():
            return "single-file"

        directory = self.base_path.resolve()
        if (directory / self.default_filename).exists():
            return "single-file"

        kind_dirs = _get_kind_directories()
        if any((directory / child).is_dir() for child in kind_dirs.values()):
            return "by-kind"

        return "single-file"

    def _single_file_path(self) -> Path:
        if self.base_path.is_file():
            return self.base_path
        directory = self.base_path
        directory.mkdir(parents=True, exist_ok=True)
        return directory / self.default_filename

    def _target_path_for_kind(self, document: TaxonomyDocument) -> Path:
        kind_dirs = _get_kind_directories()
        directory_name = kind_dirs.get(document.taxonomy_node_type)
        if directory_name is None:
            raise ValueError(f"Unsupported taxonomy node type: {document.taxonomy_node_type}")
        directory = self.base_path / directory_name
        directory.mkdir(parents=True, exist_ok=True)
        filename = f"{document.metadata.name}.yaml"
        return directory / filename

    # file writing -------------------------------------------------------

    def _append_to_file(self, path: Path, document: TaxonomyDocument) -> None:
        existing: list[Mapping[str, Any]] = []
        if path.exists():
            with path.open("r", encoding="utf-8") as handle:
                existing = [doc for doc in yaml.safe_load_all(handle) if doc]

        existing.append(_document_to_mapping(document))
        with path.open("w", encoding="utf-8") as handle:
            yaml.safe_dump_all(existing, handle, sort_keys=False)

    def _write_new_file(self, path: Path, document: TaxonomyDocument) -> None:
        if path.exists():
            raise FileExistsError(f"Taxonomy document already exists: {path}")
        with path.open("w", encoding="utf-8") as handle:
            yaml.safe_dump(_document_to_mapping(document), handle, sort_keys=False)

    def _target_path_for_kind_md(self, document: TaxonomyDocument) -> Path:
        """Compute target path for a markdown taxonomy file in by-kind layout."""
        kind_dirs = _get_kind_directories()
        directory_name = kind_dirs.get(document.taxonomy_node_type)
        if directory_name is None:
            raise ValueError(f"Unsupported taxonomy node type: {document.taxonomy_node_type}")
        directory = self.base_path / directory_name
        directory.mkdir(parents=True, exist_ok=True)
        filename = f"{document.metadata.name}.md"
        return directory / filename

    def _write_markdown_file(self, path: Path, document: TaxonomyDocument) -> None:
        """Write a taxonomy document as markdown with YAML front matter."""
        if path.exists():
            raise FileExistsError(f"Taxonomy document already exists: {path}")
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(_serialize_taxonomy_markdown(document), encoding="utf-8")
