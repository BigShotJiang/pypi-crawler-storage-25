"""Domain models for representing the Prima taxonomy hierarchy."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import ClassVar, cast

_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slugify(value: str) -> str:
    slug = _SLUG_RE.sub("-", value.lower()).strip("-")
    return slug or "_"


@dataclass(frozen=True, slots=True)
class TaxonomyContext:
    """Resolved taxonomy coordinates for a node.

    Systems are self-referential and can nest to any depth, so
    ``systems`` is a variable-length tuple of all system ancestors.
    """

    systems: tuple[System, ...] = ()
    stack: Stack | None = None
    layer: Layer | None = None

    # Convenience: the deepest (most-specific) system in the chain.
    @property
    def system(self) -> System | None:
        return self.systems[-1] if self.systems else None

    def as_tuple(self) -> tuple[TaxonomyNode, ...]:
        nodes: list[TaxonomyNode] = []
        for node in self.systems:
            nodes.append(node)
        if self.stack is not None:
            nodes.append(self.stack)
        if self.layer is not None:
            nodes.append(self.layer)
        return tuple(nodes)

    @property
    def path(self) -> tuple[str, ...]:
        return tuple(node.slug for node in self.as_tuple())

    @property
    def qualified_name(self) -> str:
        return ".".join(node.slug for node in self.as_tuple())


@dataclass(frozen=True, slots=True, kw_only=True)
class TaxonomyNode:
    """Base taxonomy element with shared behaviours."""

    name: str
    description: str | None = None
    parent: TaxonomyNode | None = field(default=None, repr=False)
    _taxonomy_context: TaxonomyContext | None = field(
        init=False,
        default=None,
        repr=False,
        compare=False,
    )

    kind: ClassVar[str] = "taxonomy"

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("name cannot be blank")

    @property
    def slug(self) -> str:
        return _slugify(self.name)

    @property
    def hierarchy(self) -> tuple[TaxonomyNode, ...]:
        if self.parent is None:
            return (self,)
        return (*self.parent.hierarchy, self)

    @property
    def depth(self) -> int:
        return len(self.hierarchy) - 1

    @property
    def path(self) -> tuple[str, ...]:
        return tuple(node.slug for node in self.hierarchy)

    @property
    def qualified_name(self) -> str:
        return ".".join(self.path)

    @property
    def root(self) -> TaxonomyNode:
        return self.hierarchy[0]

    def ancestors(self) -> tuple[TaxonomyNode, ...]:
        return self.hierarchy[:-1]

    def is_root(self) -> bool:
        return self.parent is None

    @property
    def lineage(self) -> TaxonomyContext:
        """Resolved taxonomy context for this node."""

        context = self._taxonomy_context
        if context is None:
            context = _build_taxonomy_context(self)
            object.__setattr__(self, "_taxonomy_context", context)
        return context


@dataclass(frozen=True, slots=True, kw_only=True)
class System(TaxonomyNode):
    """A system boundary. Systems can nest under other systems (self-referential)."""

    kind: ClassVar[str] = "system"

    def __post_init__(self) -> None:
        if self.parent is not None and not isinstance(self.parent, System):
            raise ValueError("System nodes can only have another System as parent")
        TaxonomyNode.__post_init__(self)

    @property
    def system(self) -> System:
        return self

    @property
    def parent_system(self) -> System | None:
        """The parent system, if this is a nested system."""
        if isinstance(self.parent, System):
            return self.parent
        return None


@dataclass(frozen=True, slots=True, kw_only=True)
class Stack(TaxonomyNode):
    kind: ClassVar[str] = "stack"

    def __post_init__(self) -> None:
        if not isinstance(self.parent, System):
            raise ValueError("Stack nodes require a System parent")
        TaxonomyNode.__post_init__(self)

    @property
    def system(self) -> System:
        return cast(System, self.parent)


@dataclass(frozen=True, slots=True, kw_only=True)
class Layer(TaxonomyNode):
    kind: ClassVar[str] = "layer"

    def __post_init__(self) -> None:
        if not isinstance(self.parent, Stack):
            raise ValueError("Layer nodes require a Stack parent")
        TaxonomyNode.__post_init__(self)

    @property
    def stack(self) -> Stack:
        stack = self.lineage.stack
        if stack is None:
            raise RuntimeError("Layer nodes require a Stack ancestor")
        return stack

    @property
    def system(self) -> System:
        system = self.lineage.system
        if system is None:
            raise RuntimeError("Layer nodes require a System ancestor")
        return system


def _build_taxonomy_context(node: TaxonomyNode) -> TaxonomyContext:
    systems: list[System] = []
    stack: Stack | None = None
    layer: Layer | None = None

    for entry in node.hierarchy:
        if entry.kind == "system":
            systems.append(cast(System, entry))
        elif entry.kind == "stack":
            stack = cast(Stack, entry)
        elif entry.kind == "layer":
            layer = cast(Layer, entry)

    return TaxonomyContext(systems=tuple(systems), stack=stack, layer=layer)
