"""Taxonomy package exposing node types and builder abstractions."""

from .builders import (
    BuiltTaxonomy,
    InMemoryTaxonomyBuilder,
    LayerDefinition,
    StackDefinition,
    SystemDefinition,
    TaxonomyBuilder,
)
from .discovery.filesystem import (
    ByKindStrategy,
    CompositeDiscoveryStrategy,
    DiscoveryStrategy,
    DocumentError,
    FilesystemTaxonomyLoader,
    RecursiveStrategy,
    SingleFileStrategy,
)
from .documents import (
    API_VERSION,
    KIND,
    InMemoryTaxonomyDocumentStore,
    TaxonomyDocument,
    TaxonomyGraphSource,
    TaxonomyNodeSource,
)
from .environments import ENVIRONMENT_KIND, EnvironmentDocument
from .ignore import IGNOREFILE_NAME, TaxonomyIgnore, load_ignore
from .management import TaxonomyManager, TaxonomyWriter
from .nodes import Layer, Stack, System, TaxonomyContext, TaxonomyNode
from .persistence.filesystem import FilesystemTaxonomyWriter
from .service import (
    TaxonomyResult,
    build_default_strategy,
    document_lookup_key,
    load_taxonomy,
    qualified_name_for,
)

__all__ = [
    "API_VERSION",
    "ENVIRONMENT_KIND",
    "IGNOREFILE_NAME",
    "KIND",
    "BuiltTaxonomy",
    "ByKindStrategy",
    "CompositeDiscoveryStrategy",
    "DiscoveryStrategy",
    "DocumentError",
    "EnvironmentDocument",
    "FilesystemTaxonomyLoader",
    "FilesystemTaxonomyWriter",
    "InMemoryTaxonomyBuilder",
    "InMemoryTaxonomyDocumentStore",
    "Layer",
    "LayerDefinition",
    "RecursiveStrategy",
    "SingleFileStrategy",
    "Stack",
    "StackDefinition",
    "System",
    "SystemDefinition",
    "TaxonomyBuilder",
    "TaxonomyContext",
    "TaxonomyDocument",
    "TaxonomyGraphSource",
    "TaxonomyIgnore",
    "TaxonomyManager",
    "TaxonomyNode",
    "TaxonomyNodeSource",
    "TaxonomyResult",
    "TaxonomyWriter",
    "build_default_strategy",
    "document_lookup_key",
    "load_ignore",
    "load_taxonomy",
    "qualified_name_for",
]
