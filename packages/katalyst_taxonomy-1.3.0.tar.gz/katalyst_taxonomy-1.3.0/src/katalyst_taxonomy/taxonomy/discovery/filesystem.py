"""Filesystem-backed discovery for taxonomy documents.

This module re-exports discovery strategies from the canonical location in
``adapters.filesystem.discovery`` and provides the ``FilesystemTaxonomyLoader``
which wires everything together for the legacy ``load_taxonomy`` code-path.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from loguru import logger

from katalyst_taxonomy.adapters.filesystem._document_parsing import parse_documents
from katalyst_taxonomy.adapters.filesystem.discovery import (  # noqa: F401 — re-exports
    LAYER_FILENAMES,
    ByKindStrategy,
    CompositeDiscoveryStrategy,
    DiscoveryStrategy,
    RecursiveStrategy,
    SingleFileStrategy,
    find_layer_document,
)
from katalyst_taxonomy.adapters.filesystem.ignore import IGNOREFILE_NAME, load_ignore
from katalyst_taxonomy.domain.errors import DocumentError

from ..documents import (
    TaxonomyDocument,
)
from ..environments import (
    EnvironmentDocument,
)

# Re-export for backward compatibility — all consumers should eventually
# migrate their imports to ``adapters.filesystem.discovery``.
__all__ = [
    "ByKindStrategy",
    "CompositeDiscoveryStrategy",
    "DiscoveryStrategy",
    "DocumentError",
    "FilesystemTaxonomyLoader",
    "LAYER_FILENAMES",
    "RecursiveStrategy",
    "SingleFileStrategy",
    "find_layer_document",
]


def _document_error_list() -> list[DocumentError]:
    return []


def _environment_document_list() -> list[EnvironmentDocument]:
    return []


@dataclass
class FilesystemTaxonomyLoader:
    """Filesystem-backed loader that implements taxonomy sources."""

    base_path: Path
    strategy: DiscoveryStrategy

    _documents: tuple[TaxonomyDocument, ...] | None = None
    _environment_documents: list[EnvironmentDocument] = field(
        init=False,
        repr=False,
        default_factory=_environment_document_list,
    )
    _errors: list[DocumentError] = field(
        init=False,
        repr=False,
        default_factory=_document_error_list,
    )

    def _load_documents(self) -> tuple[TaxonomyDocument, ...]:
        base = self.base_path
        if not base.exists():
            raise FileNotFoundError(f"Taxonomy path does not exist: {base}")

        documents: list[TaxonomyDocument] = []
        self._errors = []
        self._environment_documents = []

        layer_directories: set[Path] = set()
        candidates = [path for path in self.strategy.discover(base) if path.name != IGNOREFILE_NAME]
        candidates.sort(key=lambda p: (len(p.parts), str(p)))

        ignore = load_ignore(base)

        for path in candidates:
            if any(
                layer_dir in path.parents and path.parent != layer_dir
                for layer_dir in layer_directories
            ):
                continue

            if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
                logger.debug("Skipping ignored path {}", path)
                continue

            parsed = parse_documents(
                path,
                environment_documents=self._environment_documents,
                errors=self._errors,
            )
            documents.extend(parsed)

            if any(doc.taxonomy_node_type == "layer" for doc in parsed):
                layer_directories.add(path.parent)

        return tuple(documents)

    def load_graph(self) -> tuple[TaxonomyDocument, ...]:
        if self._documents is None:
            self._documents = self._load_documents()
        return self._documents

    def environments(self) -> tuple[EnvironmentDocument, ...]:
        if self._documents is None:
            self._documents = self._load_documents()
        return tuple(self._environment_documents)

    def get_node(self, name: str) -> TaxonomyDocument | None:
        graph = self.load_graph()
        return next((doc for doc in graph if doc.metadata.name == name), None)

    def errors(self) -> tuple[DocumentError, ...]:
        return tuple(self._errors)
