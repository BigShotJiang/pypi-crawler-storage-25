"""Ignore file support for taxonomy discovery.

This module re-exports from the canonical location in
``adapters.filesystem.ignore`` for backward compatibility.
"""

from __future__ import annotations

from katalyst_taxonomy.adapters.filesystem.ignore import (
    IGNOREFILE_NAME,
    IgnoreRule,
    TaxonomyIgnore,
    load_ignore,
    parse_rule,
)

# Keep the old private name available for anyone importing it directly.
_parse_rule = parse_rule

__all__ = [
    "IGNOREFILE_NAME",
    "IgnoreRule",
    "TaxonomyIgnore",
    "_parse_rule",
    "load_ignore",
    "parse_rule",
]
