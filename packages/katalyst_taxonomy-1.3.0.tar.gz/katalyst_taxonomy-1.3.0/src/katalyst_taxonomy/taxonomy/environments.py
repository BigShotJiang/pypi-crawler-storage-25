"""Environment document models and helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping, cast

API_VERSION = "katalyst.taxonomy/v1alpha"
ENVIRONMENT_KIND = "Environment"


@dataclass(frozen=True, slots=True)
class EnvironmentDocument:
    """Represents an Environment resource used to drive templating."""

    name: str
    description: str | None
    template_replacements: Mapping[str, str]
    layer_templates: Mapping[str, Mapping[str, object]] = field(
        default_factory=lambda: cast(Mapping[str, Mapping[str, object]], {}),
    )
    source_path: Path | None = None
    markdown_body: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "template_replacements", dict(self.template_replacements))
        normalized: dict[str, dict[str, object]] = {}
        for key, value in self.layer_templates.items():
            normalized[key] = dict(value)
        object.__setattr__(self, "layer_templates", normalized)


def environment_from_mapping(
    payload: Mapping[str, object],
    *,
    source_path: Path,
    markdown_body: str | None = None,
) -> EnvironmentDocument:
    """Create an :class:`EnvironmentDocument` from a raw mapping."""

    api_version = str(payload.get("apiVersion", ""))
    kind = str(payload.get("kind", ""))
    if api_version != API_VERSION or kind != ENVIRONMENT_KIND:
        raise ValueError(
            f"Unsupported environment document (apiVersion={api_version!r}, kind={kind!r})",
        )

    metadata_raw = payload.get("metadata")
    if not isinstance(metadata_raw, Mapping):
        raise ValueError("Environment metadata must be a mapping.")
    metadata_mapping = cast(Mapping[str, object], metadata_raw)

    name_value = metadata_mapping.get("name")
    name = str(name_value if name_value is not None else "").strip()
    if not name:
        raise ValueError("Environment metadata.name cannot be blank.")

    spec_raw = payload.get("spec")
    if not isinstance(spec_raw, Mapping):
        raise ValueError("Environment spec must be a mapping.")
    spec_mapping = cast(Mapping[str, object], spec_raw)

    description_value = spec_mapping.get("description")
    description = str(description_value) if description_value is not None else None

    replacements_raw = spec_mapping.get("templateReplacements") or {}  # type: ignore[assignment]
    if not isinstance(replacements_raw, Mapping):
        raise ValueError("spec.templateReplacements must be an object.")
    replacements_mapping = cast(Mapping[str, object], replacements_raw)

    replacements: dict[str, str] = {}
    for raw_key, raw_value in replacements_mapping.items():
        key = str(raw_key).strip()
        if not key:
            continue
        replacements[key] = "" if raw_value is None else str(raw_value)

    layer_templates_raw = spec_mapping.get("layerTemplates") or {}  # type: ignore[assignment]
    if not isinstance(layer_templates_raw, Mapping):
        raise ValueError("spec.layerTemplates must be an object when provided.")
    layer_templates_mapping = cast(Mapping[str, object], layer_templates_raw)
    layer_templates: dict[str, dict[str, object]] = {}
    for raw_key, raw_value in layer_templates_mapping.items():
        if not raw_key:
            continue
        template_key = str(raw_key).strip()
        if not template_key:
            continue
        if not isinstance(raw_value, Mapping):
            raise ValueError(
                f"spec.layerTemplates.{template_key} must be an object "
                f"(environment={name}, path={source_path})",
            )
        canonical = template_key
        layer_templates[canonical] = dict(cast(Mapping[str, object], raw_value))

    return EnvironmentDocument(
        name=name,
        description=description,
        template_replacements=replacements,
        layer_templates=layer_templates,
        source_path=source_path,
        markdown_body=markdown_body,
    )
