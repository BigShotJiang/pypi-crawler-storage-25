"""Builder abstractions for constructing taxonomy hierarchies."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Protocol, Sequence, runtime_checkable

from .nodes import Layer, Stack, System


@dataclass(frozen=True, slots=True)
class LayerDefinition:
    """Definition data for constructing a Layer node."""

    name: str
    description: str | None = None
    layer_type: str | None = None
    template: str | None = None


@dataclass(frozen=True, slots=True)
class StackDefinition:
    """Definition data for a Stack node and its child Layers."""

    name: str
    layers: Sequence[LayerDefinition] = field(default_factory=tuple)
    description: str | None = None
    template: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "layers", tuple(self.layers))


@dataclass(frozen=True, slots=True)
class SystemDefinition:
    """Definition data for a System node and child Systems/Stacks.

    Systems are self-referential: a system can contain nested systems
    (which themselves can contain stacks) as well as direct stacks.
    """

    name: str
    systems: Sequence[SystemDefinition] = field(default_factory=tuple)
    stacks: Sequence[StackDefinition] = field(default_factory=tuple)
    description: str | None = None
    template: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "systems", tuple(self.systems))
        object.__setattr__(self, "stacks", tuple(self.stacks))


@dataclass(frozen=True, slots=True)
class BuiltTaxonomy:
    """Concrete taxonomy produced by a builder."""

    systems: tuple[System, ...]
    stacks: tuple[Stack, ...]
    layers: tuple[Layer, ...]

    def __iter__(self) -> Iterable[System]:
        return iter(self.systems)


@runtime_checkable
class TaxonomyBuilder(Protocol):
    """Port that produces a fully-hydrated taxonomy."""

    def build(self) -> BuiltTaxonomy:
        """Construct and return the taxonomy."""
        ...


@dataclass(frozen=True, slots=True)
class InMemoryTaxonomyBuilder:
    """Build a taxonomy from in-memory definition objects."""

    system_definitions: Sequence[SystemDefinition] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        object.__setattr__(self, "system_definitions", tuple(self.system_definitions))

    def build(self) -> BuiltTaxonomy:
        systems: list[System] = []
        stacks: list[Stack] = []
        layers: list[Layer] = []

        def _build_system(
            system_def: SystemDefinition,
            parent: System | None,
        ) -> None:
            system = System(
                name=system_def.name,
                description=system_def.description,
                parent=parent,
            )
            systems.append(system)

            # Recursively build nested systems
            for nested_def in system_def.systems:
                _build_system(nested_def, parent=system)

            # Build direct stacks under this system
            for stack_def in system_def.stacks:
                stack = Stack(
                    name=stack_def.name,
                    description=stack_def.description,
                    parent=system,
                )
                stacks.append(stack)

                for layer_def in stack_def.layers:
                    layer = Layer(
                        name=layer_def.name,
                        description=layer_def.description,
                        parent=stack,
                    )
                    layers.append(layer)

        for system_def in self.system_definitions:
            _build_system(system_def, parent=None)

        return BuiltTaxonomy(
            systems=tuple(systems),
            stacks=tuple(stacks),
            layers=tuple(layers),
        )
