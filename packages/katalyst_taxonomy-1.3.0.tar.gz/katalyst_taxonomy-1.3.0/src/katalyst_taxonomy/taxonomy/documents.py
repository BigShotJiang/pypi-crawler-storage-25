"""Taxonomy document ports and backward-compatible re-exports.

The canonical document model is ``engine.document.Document``.
This module provides:
- Protocol definitions for taxonomy sources (``TaxonomyNodeSource``, ``TaxonomyGraphSource``)
- ``InMemoryTaxonomyDocumentStore`` for testing
- Backward-compatible re-exports (``TaxonomyDocument``, ``API_VERSION``, ``KIND``)
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from katalyst_taxonomy.engine.document import Document

# Backward-compatible constants (used by v1 linting and legacy parsers)
API_VERSION = "katalyst.taxonomy/v1alpha"
KIND = "TaxonomyNode"

# Backward-compatible alias
TaxonomyDocument = Document


@runtime_checkable
class TaxonomyNodeSource(Protocol):
    """Port for retrieving individual taxonomy documents."""

    def get_node(self, name: str) -> Document | None:
        """Return the document identified by metadata.name, if present."""
        ...


@runtime_checkable
class TaxonomyGraphSource(Protocol):
    """Port for retrieving the full taxonomy document set."""

    def load_graph(self) -> tuple[Document, ...]:
        """Return all known taxonomy documents."""
        ...


class InMemoryTaxonomyDocumentStore(TaxonomyNodeSource, TaxonomyGraphSource):
    """Simple in-memory adapter suitable for testing."""

    def __init__(self, *, documents: tuple[Document, ...] | None = None) -> None:
        ordered = tuple(documents or ())
        lookup = {doc.name: doc for doc in ordered}
        if len(lookup) != len(ordered):
            raise ValueError("Duplicate taxonomy document names detected")
        self._documents: tuple[Document, ...] = ordered
        self._lookup: dict[str, Document] = lookup

    def get_node(self, name: str) -> Document | None:
        return self._lookup.get(name)

    def load_graph(self) -> tuple[Document, ...]:
        return self._documents
