"""Helper utilities for working with taxonomy documents."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Mapping, cast

import yaml

from .documents import TaxonomyDocument

__all__ = ["extract_layer_type", "load_raw_document_spec"]


@lru_cache(maxsize=512)
def _load_source_documents(path: Path) -> tuple[Mapping[str, object], ...]:
    documents: list[Mapping[str, object]] = []
    try:
        with path.open("r", encoding="utf-8") as stream:
            for document in yaml.safe_load_all(stream):
                if isinstance(document, Mapping):
                    documents.append(cast(Mapping[str, object], document))
    except OSError:
        return tuple()
    return tuple(documents)


def load_raw_document_spec(document: TaxonomyDocument) -> Mapping[str, object] | None:
    """Return the raw spec mapping for ``document`` if the source file is available."""

    path = document.source_path
    if path is None:
        return None
    resolved = path.resolve()
    for raw in _load_source_documents(resolved):
        metadata = raw.get("metadata")
        if not isinstance(metadata, Mapping):
            continue
        metadata_mapping = cast(Mapping[str, object], metadata)
        name = metadata_mapping.get("name")
        if not isinstance(name, str) or name != document.metadata.name:
            continue
        node_type = raw.get("taxonomyNodeType")
        if isinstance(node_type, str) and node_type != document.taxonomy_node_type:
            continue
        spec_raw = raw.get("spec")
        if isinstance(spec_raw, Mapping):
            return cast(Mapping[str, object], spec_raw)
    return None


def extract_layer_type(document: TaxonomyDocument) -> str | None:
    """Best-effort extraction of the layer type annotation."""

    annotations = document.annotations_map or {}
    raw_annotation = annotations.get("layerType")
    if isinstance(raw_annotation, str) and raw_annotation:
        return raw_annotation
    extensions = document.extensions_map or {}
    extension_value = extensions.get("layerType") if extensions else None
    if isinstance(extension_value, str) and extension_value:
        return extension_value
    spec_mapping = load_raw_document_spec(document)
    if spec_mapping is not None:
        spec_value = spec_mapping.get("layerType")
        if isinstance(spec_value, str) and spec_value:
            return spec_value
    return None
