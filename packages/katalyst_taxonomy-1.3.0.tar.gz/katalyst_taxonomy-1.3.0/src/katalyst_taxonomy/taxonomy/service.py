"""Application-layer utilities for loading taxonomy data."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from katalyst_taxonomy.services.taxonomy import (
    build_qualified_names,
    document_lookup_key,
    qualified_name_for,
)

from .discovery.filesystem import (
    ByKindStrategy,
    CompositeDiscoveryStrategy,
    DiscoveryStrategy,
    DocumentError,
    FilesystemTaxonomyLoader,
    RecursiveStrategy,
    SingleFileStrategy,
)
from .documents import TaxonomyDocument
from .environments import EnvironmentDocument

# Re-export for backwards compatibility
__all__ = [
    "TaxonomyResult",
    "build_default_strategy",
    "document_lookup_key",
    "load_taxonomy",
    "qualified_name_for",
]


def build_default_strategy() -> CompositeDiscoveryStrategy:
    """Construct the default discovery strategy used throughout the CLI."""

    return CompositeDiscoveryStrategy(
        strategies=(
            SingleFileStrategy(),
            ByKindStrategy(),
            RecursiveStrategy(),
        ),
    )


@dataclass(frozen=True)
class TaxonomyResult:
    """Represents the outcome of loading taxonomy documents from the filesystem."""

    documents: tuple[TaxonomyDocument, ...]
    errors: tuple[DocumentError, ...]
    qualified_names: dict[str, str]
    environments: tuple[EnvironmentDocument, ...] = ()


def load_taxonomy(path: Path, *, strategy: DiscoveryStrategy | None = None) -> TaxonomyResult:
    """Load taxonomy documents from ``path`` using the provided strategy."""

    loader = FilesystemTaxonomyLoader(
        base_path=path,
        strategy=strategy or build_default_strategy(),
    )
    documents = loader.load_graph()
    environments = loader.environments()
    qualified = build_qualified_names(documents)
    result = TaxonomyResult(
        documents=documents,
        errors=loader.errors(),
        qualified_names=qualified,
        environments=environments,
    )
    logger.info(
        "Loaded taxonomy: {} documents, {} errors (path={})",
        len(result.documents),
        len(result.errors),
        path,
    )
    return result
