"""Management operations for taxonomy entities."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from .documents import TaxonomyDocument, TaxonomyNodeSource


class TaxonomyWriter(Protocol):
    """Port for persisting taxonomy documents."""

    def create(self, document: TaxonomyDocument) -> None:
        """Persist a new taxonomy document."""


@dataclass(slots=True)
class TaxonomyManager:
    """Application service responsible for mutating taxonomy entities."""

    node_source: TaxonomyNodeSource
    writer: TaxonomyWriter

    def create_node(self, document: TaxonomyDocument) -> None:
        """Create a new taxonomy node if it does not already exist."""

        if self.node_source.get_node(document.metadata.name):
            raise ValueError(f"Taxonomy node '{document.metadata.name}' already exists")
        self.writer.create(document)
