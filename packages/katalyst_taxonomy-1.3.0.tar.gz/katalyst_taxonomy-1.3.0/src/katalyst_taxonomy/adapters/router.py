"""BackendRouter — composes multiple TaxonomyBackend implementations."""

from __future__ import annotations

from dataclasses import dataclass, field

from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.ports.backend import SaveResult, SyncResult, TaxonomyBackend
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


@dataclass
class BackendRouter:
    """Routes operations across multiple backends.

    - Reads go to the primary backend by default
    - Writes go to the primary backend
    - sync() pushes primary data to all mirrors
    """

    primary: TaxonomyBackend
    mirrors: dict[str, TaxonomyBackend] = field(
        default_factory=lambda: dict[str, TaxonomyBackend]()
    )

    @property
    def name(self) -> str:
        names = [self.primary.name]
        names.extend(self.mirrors.keys())
        return f"router({', '.join(names)})"

    def load_documents(self) -> tuple[Document, ...]:
        return self.primary.load_documents()

    def load_environments(self) -> tuple[EnvironmentDocument, ...]:
        return self.primary.load_environments()

    def get_document(self, name: str) -> Document | None:
        return self.primary.get_document(name)

    def create_node(self, node_type: str, name: str, **kwargs: object) -> SaveResult:
        return self.primary.create_node(node_type, name, **kwargs)

    def sync(
        self, *, full: bool = False, targets: list[str] | None = None
    ) -> dict[str, SyncResult]:
        """Sync primary data to mirrors.

        Args:
            full: Full sync (clear + recreate) vs incremental.
            targets: Specific mirror names to sync. None = all mirrors.
        """
        results: dict[str, SyncResult] = {}
        for mirror_name, mirror in self.mirrors.items():
            if targets and mirror_name not in targets:
                continue
            results[mirror_name] = mirror.sync_from(self.primary, full=full)
        return results

    def health_check(self) -> bool:
        return self.primary.health_check()

    def close(self) -> None:
        self.primary.close()
        for mirror in self.mirrors.values():
            mirror.close()

    def errors(self) -> tuple[DocumentError, ...]:
        return self.primary.errors()
