"""Katalyst Adapters - Filesystem, Neo4j, PostgreSQL, and schema loading implementations.

Note: The Neo4j adapter (adapters.neo4j) is not imported here because it
depends on the optional ``neo4j`` package.  Import it directly when needed::

    from katalyst_taxonomy.adapters.neo4j import Neo4jExportAdapter, Neo4jConfig

Note: The PostgreSQL adapter (adapters.postgres) is not imported here because it
depends on the optional ``asyncpg`` / ``psycopg`` package.  Import it directly when needed::

    from katalyst_taxonomy.adapters.postgres import PostgresBackend, PostgresConfig
"""

from katalyst_taxonomy.adapters.filesystem.backend import FilesystemBackend
from katalyst_taxonomy.adapters.filesystem.ignore import TaxonomyIgnore, load_ignore
from katalyst_taxonomy.adapters.filesystem.writer import FilesystemWriter

# Backward compatibility alias
FilesystemTaxonomyRepository = FilesystemBackend

__all__ = [
    "FilesystemBackend",
    "FilesystemTaxonomyRepository",
    "FilesystemWriter",
    "TaxonomyIgnore",
    "load_ignore",
]
