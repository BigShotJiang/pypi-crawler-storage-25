"""PostgreSQL connection configuration."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class PostgresConfig:
    """PostgreSQL connection configuration."""

    host: str = "localhost"
    port: int = 5432
    database: str = "katalyst"
    username: str = "katalyst"
    password: str = ""
    schema_: str = "public"
    pool_size: int = 5
    max_overflow: int = 10
    pool_timeout: float = 30.0
    batch_size: int = 1000

    @property
    def dsn(self) -> str:
        """Build the asyncpg-compatible DSN string."""
        return f"postgresql+asyncpg://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"

    @classmethod
    def from_env(cls) -> PostgresConfig:
        """Load config from environment variables.

        Reads:
            POSTGRES_HOST, POSTGRES_PORT, POSTGRES_DB, POSTGRES_USER,
            POSTGRES_PASSWORD, POSTGRES_SCHEMA, POSTGRES_DSN

        If ``POSTGRES_DSN`` is set it overrides the individual host/port/db/user/password
        parameters (the DSN is parsed to extract them).
        """
        dsn = os.environ.get("POSTGRES_DSN")
        if dsn:
            return cls.from_dsn(dsn)

        return cls(
            host=os.environ.get("POSTGRES_HOST", "localhost"),
            port=int(os.environ.get("POSTGRES_PORT", "5432")),
            database=os.environ.get("POSTGRES_DB", "katalyst"),
            username=os.environ.get("POSTGRES_USER", "katalyst"),
            password=os.environ.get("POSTGRES_PASSWORD", ""),
            schema_=os.environ.get("POSTGRES_SCHEMA", "public"),
        )

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> PostgresConfig:
        """Load config from a dict (e.g., from YAML config file)."""
        return cls(
            host=str(data.get("host", "localhost")),
            port=int(str(data.get("port", 5432))),
            database=str(data.get("database", "katalyst")),
            username=str(data.get("username", "katalyst")),
            password=str(data.get("password", "")),
            schema_=str(data.get("schema_", "public")),
            pool_size=int(str(data.get("pool_size", 5))),
            max_overflow=int(str(data.get("max_overflow", 10))),
            pool_timeout=float(str(data.get("pool_timeout", 30.0))),
            batch_size=int(str(data.get("batch_size", 1000))),
        )

    @classmethod
    def from_dsn(cls, dsn: str) -> PostgresConfig:
        """Parse a DSN string into config fields.

        Expected format: ``postgresql+asyncpg://user:pass@host:port/dbname``
        or ``postgresql://user:pass@host:port/dbname``.
        """
        from urllib.parse import urlparse

        parsed = urlparse(dsn)
        return cls(
            host=parsed.hostname or "localhost",
            port=parsed.port or 5432,
            database=(parsed.path or "/katalyst").lstrip("/") or "katalyst",
            username=parsed.username or "katalyst",
            password=parsed.password or "",
        )
