"""SQL query constants for PostgreSQL taxonomy backend.

All parameterised queries use asyncpg ``$N`` placeholders.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Upsert nodes
# ---------------------------------------------------------------------------

UPSERT_NODE = """
INSERT INTO taxonomy_nodes (
    fqtn, name, kind, api_version, wing, description,
    owners, environments, labels, annotations, spec_annotations,
    layer_type, is_extension, extends_kind, extends_names,
    source_path, _spec_json, sync_id, synced_at
) VALUES (
    $1, $2, $3, $4, $5, $6,
    $7, $8, $9, $10, $11,
    $12, $13, $14, $15,
    $16, $17, $18, now()
)
ON CONFLICT (fqtn) DO UPDATE SET
    name = EXCLUDED.name,
    kind = EXCLUDED.kind,
    api_version = EXCLUDED.api_version,
    wing = EXCLUDED.wing,
    description = EXCLUDED.description,
    owners = EXCLUDED.owners,
    environments = EXCLUDED.environments,
    labels = EXCLUDED.labels,
    annotations = EXCLUDED.annotations,
    spec_annotations = EXCLUDED.spec_annotations,
    layer_type = EXCLUDED.layer_type,
    is_extension = EXCLUDED.is_extension,
    extends_kind = EXCLUDED.extends_kind,
    extends_names = EXCLUDED.extends_names,
    source_path = EXCLUDED.source_path,
    _spec_json = EXCLUDED._spec_json,
    sync_id = EXCLUDED.sync_id,
    synced_at = now(),
    updated_at = now()
"""

# ---------------------------------------------------------------------------
# Upsert environments
# ---------------------------------------------------------------------------

UPSERT_ENVIRONMENT = """
INSERT INTO environments (
    name, description, template_replacements, layer_templates,
    source_path, _spec_json, sync_id, synced_at
) VALUES (
    $1, $2, $3, $4,
    $5, $6, $7, now()
)
ON CONFLICT (name) DO UPDATE SET
    description = EXCLUDED.description,
    template_replacements = EXCLUDED.template_replacements,
    layer_templates = EXCLUDED.layer_templates,
    source_path = EXCLUDED.source_path,
    _spec_json = EXCLUDED._spec_json,
    sync_id = EXCLUDED.sync_id,
    synced_at = now(),
    updated_at = now()
"""

# ---------------------------------------------------------------------------
# Upsert relationships
# ---------------------------------------------------------------------------

UPSERT_RELATIONSHIP = """
INSERT INTO node_relationships (
    source_fqtn, target_fqtn, rel_type, properties, sync_id
) VALUES (
    $1, $2, $3, $4, $5
)
ON CONFLICT (source_fqtn, target_fqtn, rel_type) DO UPDATE SET
    properties = EXCLUDED.properties,
    sync_id = EXCLUDED.sync_id
"""

# ---------------------------------------------------------------------------
# Pruning stale data
# ---------------------------------------------------------------------------

PRUNE_STALE_NODES = """
DELETE FROM taxonomy_nodes
WHERE sync_id != $1 OR sync_id IS NULL
"""

PRUNE_STALE_ENVIRONMENTS = """
DELETE FROM environments
WHERE sync_id != $1 OR sync_id IS NULL
"""

PRUNE_STALE_RELATIONSHIPS = """
DELETE FROM node_relationships
WHERE sync_id != $1 OR sync_id IS NULL
"""

# ---------------------------------------------------------------------------
# Full clear
# ---------------------------------------------------------------------------

TRUNCATE_ALL = "TRUNCATE taxonomy_nodes, environments, node_relationships CASCADE"

# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

HEALTH_CHECK = "SELECT 1"

# ---------------------------------------------------------------------------
# Read queries
# ---------------------------------------------------------------------------

LOAD_ALL_NODES = """
SELECT n.*, p.name AS parent_name
FROM taxonomy_nodes n
LEFT JOIN node_relationships r
    ON r.source_fqtn = n.fqtn AND r.rel_type = 'CHILD_OF'
LEFT JOIN taxonomy_nodes p
    ON p.fqtn = r.target_fqtn
ORDER BY n.kind, n.name
"""

LOAD_ALL_ENVIRONMENTS = "SELECT * FROM environments ORDER BY name"

GET_NODE_BY_NAME = """
SELECT n.*, p.name AS parent_name
FROM taxonomy_nodes n
LEFT JOIN node_relationships r
    ON r.source_fqtn = n.fqtn AND r.rel_type = 'CHILD_OF'
LEFT JOIN taxonomy_nodes p
    ON p.fqtn = r.target_fqtn
WHERE n.name = $1
LIMIT 1
"""

COUNT_NODES = "SELECT count(*) FROM taxonomy_nodes"
COUNT_RELATIONSHIPS = "SELECT count(*) FROM node_relationships"
