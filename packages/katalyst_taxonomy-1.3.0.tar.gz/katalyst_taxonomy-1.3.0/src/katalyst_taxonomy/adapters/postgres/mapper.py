"""Document-to-row mapper — converts taxonomy Documents to relational table rows."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from katalyst_taxonomy.adapters.neo4j.mapper import (
    GraphRelationship,
    TaxonomyGraphMapper,
)
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.registry import NodeTypeRegistry
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


@dataclass(slots=True)
class TaxonomyRelationalMapper:
    """Maps taxonomy Documents to flat dicts suitable for PostgreSQL rows.

    Reuses ``TaxonomyGraphMapper.extract_relationships()`` from the Neo4j
    adapter so relationship extraction logic lives in a single place.
    """

    _registry: NodeTypeRegistry

    def map_document(self, doc: Document, fqtn: str) -> dict[str, Any]:
        """Map a single Document to a dict of column values."""
        # Get wing from registry
        descriptor = self._registry.get(doc.kind)
        wing = descriptor.wing if descriptor else None

        # Layer-specific properties
        layer_type = doc.spec.get("layerType") or doc.spec.get("layer_type")

        # Extension-specific properties
        is_extension = doc.is_extension
        extends_kind: str | None = None
        extends_names: list[str] | None = None
        if doc.extends:
            extends_kind = doc.extends.target_kind
            extends_names = list(doc.extends.target_names)

        return {
            "fqtn": fqtn,
            "name": doc.name,
            "kind": doc.kind,
            "api_version": doc.api_version,
            "wing": wing,
            "description": doc.description,
            "owners": list(doc.owners),
            "environments": list(doc.environments),
            "labels": json.dumps(dict(doc.metadata.labels)),
            "annotations": json.dumps(dict(doc.metadata.annotations)),
            "spec_annotations": json.dumps(doc.annotations_map),
            "layer_type": str(layer_type) if layer_type else None,
            "is_extension": is_extension,
            "extends_kind": extends_kind,
            "extends_names": extends_names,
            "source_path": str(doc.source_path) if doc.source_path else None,
            "_spec_json": json.dumps(dict(doc.spec)),
        }

    def map_environment(self, env: EnvironmentDocument) -> dict[str, Any]:
        """Map an EnvironmentDocument to a dict of column values."""
        return {
            "name": env.name,
            "description": env.description,
            "template_replacements": json.dumps(dict(env.template_replacements)),
            "layer_templates": json.dumps({k: dict(v) for k, v in env.layer_templates.items()}),
            "source_path": str(env.source_path) if env.source_path else None,
            "_spec_json": None,
        }

    def extract_relationships(
        self,
        documents: tuple[Document, ...],
        qualified_names: dict[str, str],
    ) -> list[dict[str, Any]]:
        """Extract all relationships, reusing the Neo4j mapper logic.

        Returns a list of dicts with keys: source_fqtn, target_fqtn,
        rel_type, properties (JSON string).
        """
        graph_mapper = TaxonomyGraphMapper(_registry=self._registry)
        graph_rels: list[GraphRelationship] = graph_mapper.extract_relationships(
            documents, qualified_names
        )

        return [
            {
                "source_fqtn": rel.source_fqtn,
                "target_fqtn": rel.target_fqtn,
                "rel_type": rel.rel_type,
                "properties": json.dumps(rel.properties),
            }
            for rel in graph_rels
        ]
