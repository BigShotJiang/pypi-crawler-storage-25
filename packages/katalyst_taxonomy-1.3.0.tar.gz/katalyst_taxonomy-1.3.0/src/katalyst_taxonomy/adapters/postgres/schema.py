"""PostgreSQL schema setup — table and index DDL."""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Table creation (idempotent via IF NOT EXISTS)
# ---------------------------------------------------------------------------

CREATE_TAXONOMY_NODES_TABLE = """
CREATE TABLE IF NOT EXISTS taxonomy_nodes (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    fqtn        TEXT UNIQUE NOT NULL,
    name        TEXT NOT NULL,
    kind        TEXT NOT NULL,
    api_version TEXT,
    wing        TEXT,
    description TEXT,
    owners      TEXT[],
    environments TEXT[],
    labels      JSONB DEFAULT '{}',
    annotations JSONB DEFAULT '{}',
    spec_annotations JSONB DEFAULT '{}',
    layer_type  TEXT,
    is_extension BOOLEAN DEFAULT FALSE,
    extends_kind TEXT,
    extends_names TEXT[],
    source_path TEXT,
    _spec_json  TEXT,
    sync_id     UUID,
    synced_at   TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT now(),
    updated_at  TIMESTAMPTZ DEFAULT now()
)
"""

CREATE_ENVIRONMENTS_TABLE = """
CREATE TABLE IF NOT EXISTS environments (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        TEXT UNIQUE NOT NULL,
    description TEXT,
    template_replacements JSONB DEFAULT '{}',
    layer_templates JSONB DEFAULT '{}',
    source_path TEXT,
    _spec_json  TEXT,
    sync_id     UUID,
    synced_at   TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT now(),
    updated_at  TIMESTAMPTZ DEFAULT now()
)
"""

CREATE_RELATIONSHIPS_TABLE = """
CREATE TABLE IF NOT EXISTS node_relationships (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_fqtn TEXT NOT NULL,
    target_fqtn TEXT NOT NULL,
    rel_type    TEXT NOT NULL,
    properties  JSONB DEFAULT '{}',
    sync_id     UUID,
    created_at  TIMESTAMPTZ DEFAULT now(),
    UNIQUE (source_fqtn, target_fqtn, rel_type)
)
"""

# ---------------------------------------------------------------------------
# Index creation (idempotent via IF NOT EXISTS)
# ---------------------------------------------------------------------------

CREATE_INDEX_NODES_FQTN = (
    "CREATE INDEX IF NOT EXISTS idx_taxonomy_nodes_fqtn ON taxonomy_nodes (fqtn)"
)
CREATE_INDEX_NODES_NAME = (
    "CREATE INDEX IF NOT EXISTS idx_taxonomy_nodes_name ON taxonomy_nodes (name)"
)
CREATE_INDEX_NODES_KIND = (
    "CREATE INDEX IF NOT EXISTS idx_taxonomy_nodes_kind ON taxonomy_nodes (kind)"
)
CREATE_INDEX_NODES_WING = (
    "CREATE INDEX IF NOT EXISTS idx_taxonomy_nodes_wing ON taxonomy_nodes (wing)"
)
CREATE_INDEX_NODES_SYNC_ID = (
    "CREATE INDEX IF NOT EXISTS idx_taxonomy_nodes_sync_id ON taxonomy_nodes (sync_id)"
)
CREATE_INDEX_RELS_SOURCE = (
    "CREATE INDEX IF NOT EXISTS idx_rels_source_fqtn ON node_relationships (source_fqtn)"
)
CREATE_INDEX_RELS_TARGET = (
    "CREATE INDEX IF NOT EXISTS idx_rels_target_fqtn ON node_relationships (target_fqtn)"
)
CREATE_INDEX_RELS_TYPE = (
    "CREATE INDEX IF NOT EXISTS idx_rels_rel_type ON node_relationships (rel_type)"
)

# ---------------------------------------------------------------------------
# All DDL statements in creation order
# ---------------------------------------------------------------------------

SCHEMA_STATEMENTS: tuple[str, ...] = (
    CREATE_TAXONOMY_NODES_TABLE,
    CREATE_ENVIRONMENTS_TABLE,
    CREATE_RELATIONSHIPS_TABLE,
    CREATE_INDEX_NODES_FQTN,
    CREATE_INDEX_NODES_NAME,
    CREATE_INDEX_NODES_KIND,
    CREATE_INDEX_NODES_WING,
    CREATE_INDEX_NODES_SYNC_ID,
    CREATE_INDEX_RELS_SOURCE,
    CREATE_INDEX_RELS_TARGET,
    CREATE_INDEX_RELS_TYPE,
)
