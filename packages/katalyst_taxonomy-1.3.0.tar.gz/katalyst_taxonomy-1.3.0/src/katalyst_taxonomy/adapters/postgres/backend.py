"""PostgreSQL taxonomy backend — unified read/write implementation."""

# pyright: reportMissingImports=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownParameterType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

import asyncio
import uuid
from typing import Any

from loguru import logger

from katalyst_taxonomy.adapters.neo4j.reverse_mapper import (
    env_node_to_document,
    node_to_document,
)
from katalyst_taxonomy.adapters.postgres.config import PostgresConfig
from katalyst_taxonomy.adapters.postgres.queries import (
    GET_NODE_BY_NAME,
    HEALTH_CHECK,
    LOAD_ALL_ENVIRONMENTS,
    LOAD_ALL_NODES,
    PRUNE_STALE_ENVIRONMENTS,
    PRUNE_STALE_NODES,
    PRUNE_STALE_RELATIONSHIPS,
    TRUNCATE_ALL,
    UPSERT_ENVIRONMENT,
    UPSERT_NODE,
    UPSERT_RELATIONSHIP,
)
from katalyst_taxonomy.adapters.postgres.schema import SCHEMA_STATEMENTS
from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.ports.backend import SaveResult, SyncResult
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


class PostgresBackend:
    """PostgreSQL implementation of the TaxonomyBackend protocol.

    Uses asyncpg directly for connection pooling and query execution.
    Supports read operations (load_documents, get_document) and sync_from
    for bulk import from another backend.
    """

    def __init__(self, config: PostgresConfig) -> None:
        self._config = config
        self._pool: Any = None
        self._schema_ensured = False

    @property
    def name(self) -> str:
        return "postgres"

    # ------------------------------------------------------------------
    # Internal connection management
    # ------------------------------------------------------------------

    async def _ensure_pool(self) -> Any:
        """Lazily create the asyncpg connection pool."""
        if self._pool is None:
            try:
                import asyncpg
            except ImportError as exc:
                raise ImportError(
                    "The 'asyncpg' package is required for the Postgres backend. "
                    "Install it with: pip install katalyst-taxonomy[postgres]"
                ) from exc

            dsn = (
                f"postgresql://{self._config.username}:{self._config.password}"
                f"@{self._config.host}:{self._config.port}/{self._config.database}"
            )
            self._pool = await asyncpg.create_pool(
                dsn,
                min_size=1,
                max_size=self._config.pool_size,
            )
        return self._pool

    async def _ensure_schema(self) -> None:
        """Create tables and indexes if not already done."""
        if self._schema_ensured:
            return
        pool = await self._ensure_pool()
        async with pool.acquire() as conn:
            for statement in SCHEMA_STATEMENTS:
                await conn.execute(statement)
        self._schema_ensured = True
        logger.info("PostgreSQL schema (tables/indexes) ensured")

    def _run_async(self, coro: Any) -> Any:
        """Run an async coroutine synchronously.

        The TaxonomyBackend protocol is synchronous, but asyncpg is async.
        This bridges the gap.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # Already in an async context — create a new thread
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor() as executor:
                return executor.submit(asyncio.run, coro).result()
        else:
            return asyncio.run(coro)

    # ------------------------------------------------------------------
    # Read operations (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def load_documents(self) -> tuple[Document, ...]:
        """Load all taxonomy documents from PostgreSQL."""
        return self._run_async(self._load_documents_async())

    async def _load_documents_async(self) -> tuple[Document, ...]:
        """Async implementation of load_documents."""
        await self._ensure_schema()
        pool = await self._ensure_pool()

        documents: list[Document] = []
        async with pool.acquire() as conn:
            rows = await conn.fetch(LOAD_ALL_NODES)
            for row in rows:
                props = dict(row)
                parent_name = props.pop("parent_name", None)
                doc = node_to_document(props, parent_name)
                documents.append(doc)

        logger.info("Loaded {} documents from PostgreSQL", len(documents))
        return tuple(documents)

    def load_environments(self) -> tuple[EnvironmentDocument, ...]:
        """Load all environment documents from PostgreSQL."""
        return self._run_async(self._load_environments_async())

    async def _load_environments_async(self) -> tuple[EnvironmentDocument, ...]:
        """Async implementation of load_environments."""
        await self._ensure_schema()
        pool = await self._ensure_pool()

        envs: list[EnvironmentDocument] = []
        async with pool.acquire() as conn:
            rows = await conn.fetch(LOAD_ALL_ENVIRONMENTS)
            for row in rows:
                env = env_node_to_document(dict(row))
                envs.append(env)

        return tuple(envs)

    def get_document(self, name: str) -> Document | None:
        """Get a single document by name from PostgreSQL."""
        return self._run_async(self._get_document_async(name))

    async def _get_document_async(self, name: str) -> Document | None:
        """Async implementation of get_document."""
        await self._ensure_schema()
        pool = await self._ensure_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow(GET_NODE_BY_NAME, name)
            if row is None:
                return None

            props = dict(row)
            parent_name = props.pop("parent_name", None)
            return node_to_document(props, parent_name)

    # ------------------------------------------------------------------
    # Write operations (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def create_node(
        self,
        node_type: str,
        name: str,
        **kwargs: object,
    ) -> SaveResult:
        """Create a node in PostgreSQL.

        For full-featured node creation with templates, use FilesystemBackend.
        """
        return SaveResult(
            success=False,
            error="Use FilesystemBackend for node creation, then sync to Postgres",
        )

    # ------------------------------------------------------------------
    # Sync operations (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def sync_from(
        self,
        source: object,
        *,
        full: bool = False,
    ) -> SyncResult:
        """Sync data from another backend into PostgreSQL."""
        return self._run_async(self._sync_from_async(source, full=full))

    async def _sync_from_async(
        self,
        source: object,
        *,
        full: bool = False,
    ) -> SyncResult:
        """Async implementation of sync_from."""
        from katalyst_taxonomy.adapters.postgres.mapper import TaxonomyRelationalMapper
        from katalyst_taxonomy.engine.bridge import get_default_registry
        from katalyst_taxonomy.engine.resolver import build_qualified_names, qualified_name_for

        # The source must have load_documents and load_environments
        if not hasattr(source, "load_documents") or not hasattr(source, "load_environments"):
            return SyncResult(
                success=False,
                errors=("Source backend must implement load_documents() and load_environments()",),
            )

        try:
            await self._ensure_schema()
            pool = await self._ensure_pool()

            documents: tuple[Document, ...] = source.load_documents()  # type: ignore[union-attr]
            environments: tuple[EnvironmentDocument, ...] = source.load_environments()  # type: ignore[union-attr]

            registry = get_default_registry()
            qualified_names = build_qualified_names(documents, registry)
            mapper = TaxonomyRelationalMapper(_registry=registry)

            sync_id = uuid.uuid4()
            nodes_created = 0
            rels_created = 0

            async with pool.acquire() as conn:
                if full:
                    await conn.execute(TRUNCATE_ALL)
                    logger.info("Truncated all taxonomy tables (full sync)")

                # --- Upsert taxonomy nodes ---
                batch_size = self._config.batch_size
                node_rows: list[tuple[Any, ...]] = []
                for doc in documents:
                    fqtn = qualified_name_for(doc, qualified_names)
                    row = mapper.map_document(doc, fqtn)
                    node_rows.append(
                        (
                            row["fqtn"],
                            row["name"],
                            row["kind"],
                            row["api_version"],
                            row["wing"],
                            row["description"],
                            row["owners"],
                            row["environments"],
                            row["labels"],
                            row["annotations"],
                            row["spec_annotations"],
                            row["layer_type"],
                            row["is_extension"],
                            row["extends_kind"],
                            row["extends_names"],
                            row["source_path"],
                            row["_spec_json"],
                            sync_id,
                        )
                    )

                for i in range(0, len(node_rows), batch_size):
                    batch = node_rows[i : i + batch_size]
                    await conn.executemany(UPSERT_NODE, batch)
                nodes_created += len(node_rows)

                # --- Upsert environment nodes ---
                env_rows: list[tuple[Any, ...]] = []
                for env in environments:
                    row = mapper.map_environment(env)
                    env_rows.append(
                        (
                            row["name"],
                            row["description"],
                            row["template_replacements"],
                            row["layer_templates"],
                            row["source_path"],
                            row["_spec_json"],
                            sync_id,
                        )
                    )

                for i in range(0, len(env_rows), batch_size):
                    batch = env_rows[i : i + batch_size]
                    await conn.executemany(UPSERT_ENVIRONMENT, batch)
                nodes_created += len(env_rows)

                # --- Upsert relationships ---
                rel_dicts = mapper.extract_relationships(documents, qualified_names)
                rel_rows: list[tuple[Any, ...]] = []
                for rd in rel_dicts:
                    rel_rows.append(
                        (
                            rd["source_fqtn"],
                            rd["target_fqtn"],
                            rd["rel_type"],
                            rd["properties"],
                            str(sync_id),
                        )
                    )

                for i in range(0, len(rel_rows), batch_size):
                    batch = rel_rows[i : i + batch_size]
                    await conn.executemany(UPSERT_RELATIONSHIP, batch)
                rels_created += len(rel_rows)

                # --- Prune stale data (incremental only) ---
                nodes_deleted = 0
                if not full:
                    result = await conn.execute(PRUNE_STALE_NODES, sync_id)
                    nodes_deleted += _extract_row_count(result)
                    await conn.execute(PRUNE_STALE_ENVIRONMENTS, sync_id)
                    await conn.execute(PRUNE_STALE_RELATIONSHIPS, sync_id)

            logger.info(
                "PostgreSQL sync complete: {} nodes upserted, {} pruned, {} relationships",
                nodes_created,
                nodes_deleted,
                rels_created,
            )
            return SyncResult(
                success=True,
                nodes_created=nodes_created,
                nodes_deleted=nodes_deleted,
                relationships_created=rels_created,
            )
        except Exception as exc:
            logger.error("PostgreSQL sync failed: {}", exc)
            return SyncResult(success=False, errors=(str(exc),))

    # ------------------------------------------------------------------
    # Lifecycle (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def health_check(self) -> bool:
        """Verify connectivity with a lightweight query."""
        return self._run_async(self._health_check_async())

    async def _health_check_async(self) -> bool:
        """Async implementation of health_check."""
        try:
            pool = await self._ensure_pool()
            async with pool.acquire() as conn:
                row = await conn.fetchval(HEALTH_CHECK)
                return row == 1
        except Exception as exc:
            logger.warning("PostgreSQL health check failed: {}", exc)
            return False

    def close(self) -> None:
        """Close the connection pool."""
        if self._pool is not None:
            self._run_async(self._pool.close())
            self._pool = None

    def errors(self) -> tuple[DocumentError, ...]:
        """PostgreSQL backend doesn't track parse errors."""
        return ()


def _extract_row_count(result: Any) -> int:
    """Extract row count from asyncpg command status string.

    asyncpg returns status strings like ``DELETE 5``.
    """
    if isinstance(result, str):
        parts = result.split()
        if len(parts) >= 2 and parts[-1].isdigit():
            return int(parts[-1])
    return 0
