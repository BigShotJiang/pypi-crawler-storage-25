"""PostgreSQL taxonomy backend — maps taxonomy data to relational tables."""

from katalyst_taxonomy.adapters.postgres.backend import PostgresBackend
from katalyst_taxonomy.adapters.postgres.config import PostgresConfig

__all__ = [
    "PostgresBackend",
    "PostgresConfig",
]
