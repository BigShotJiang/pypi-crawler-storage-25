"""Taxonomy loader adapter for services that need document dictionaries.

Relocated from cli/commands/clone.py so that both CLI and MCP adapters
can use it without adapter-to-adapter coupling.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

DocumentDict = dict[str, Any]
TaxonomyData = dict[str, Any]


class SimpleTaxonomyLoader:
    """Simple taxonomy loader using the taxonomy service."""

    def __init__(self, path: Path) -> None:
        """Initialize with repository path."""
        self._path = path

    def load(self, path: Path) -> TaxonomyData:
        """Load taxonomy and return documents."""
        from katalyst_taxonomy.taxonomy.service import load_taxonomy
        from katalyst_taxonomy.taxonomy.utils import extract_layer_type

        result = load_taxonomy(path)
        # Convert TaxonomyDocument objects to dicts for compatibility
        documents: list[DocumentDict] = []
        for doc in result.documents:
            spec_dict: dict[str, Any] = {}
            if doc.spec:
                if doc.description:
                    spec_dict["description"] = doc.description
                if doc.owners:
                    spec_dict["owners"] = list(doc.owners)
                if doc.environments:
                    spec_dict["environments"] = list(doc.environments)
                if doc.parent is not None:
                    spec_dict["parents"] = {"node": doc.parent}

            doc_dict: DocumentDict = {
                "apiVersion": doc.api_version,
                "kind": doc.kind,
                "metadata": {"name": doc.metadata.name},
                "taxonomyNodeType": doc.taxonomy_node_type,
                "spec": spec_dict,
                "sourcePath": str(doc.source_path) if doc.source_path else None,
            }

            layer_type = extract_layer_type(doc)
            if layer_type:
                spec_dict["layerType"] = layer_type
            documents.append(doc_dict)

        return {
            "documents": documents,
            "errors": [str(e) for e in result.errors],
        }

    def find_by_name(self, name: str, node_type: str | None = None) -> list[DocumentDict]:
        """Find documents by name and optional type."""
        result = self.load(self._path)
        documents: list[DocumentDict] = result.get("documents", [])
        matches: list[DocumentDict] = []
        for doc in documents:
            metadata: dict[str, Any] | None = doc.get("metadata")
            if isinstance(metadata, dict) and metadata.get("name") == name:
                if node_type is None or doc.get("taxonomyNodeType") == node_type:
                    matches.append(doc)
        return matches
