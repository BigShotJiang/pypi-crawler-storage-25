"""Neo4j taxonomy backend — unified read/write implementation."""

# pyright: reportMissingImports=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownParameterType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

import asyncio
from typing import Any

from loguru import logger

from katalyst_taxonomy.adapters.neo4j.config import Neo4jConfig
from katalyst_taxonomy.adapters.neo4j.connection import create_async_driver
from katalyst_taxonomy.adapters.neo4j.queries import (
    GET_DOCUMENT_BY_NAME,
    HEALTH_CHECK,
    LOAD_ALL_ENVIRONMENTS,
    LOAD_ALL_TAXONOMY_NODES,
)
from katalyst_taxonomy.adapters.neo4j.reverse_mapper import (
    env_node_to_document,
    node_to_document,
)
from katalyst_taxonomy.adapters.neo4j.schema import SCHEMA_STATEMENTS
from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.ports.backend import SaveResult, SyncResult
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


class Neo4jBackend:
    """Neo4j implementation of the TaxonomyBackend protocol.

    Supports read operations (load_documents, get_document) via Cypher queries,
    write operations (create_node) via MERGE, and sync_from for bulk export.
    """

    def __init__(self, config: Neo4jConfig) -> None:
        self._config = config
        self._driver: Any = None
        self._schema_ensured = False

    @property
    def name(self) -> str:
        return "neo4j"

    # ------------------------------------------------------------------
    # Internal connection management
    # ------------------------------------------------------------------

    async def _ensure_driver(self) -> Any:
        """Lazily create the async Neo4j driver."""
        if self._driver is None:
            self._driver = await create_async_driver(self._config)
        return self._driver

    async def _ensure_schema(self) -> None:
        """Create indexes and constraints if not already done."""
        if self._schema_ensured:
            return
        driver = await self._ensure_driver()
        async with driver.session(database=self._config.database) as session:
            for statement in SCHEMA_STATEMENTS:
                await session.run(statement)
        self._schema_ensured = True

    def _run_async(self, coro: Any) -> Any:
        """Run an async coroutine synchronously.

        The TaxonomyBackend protocol is synchronous, but the Neo4j
        driver is async. This bridges the gap.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # Already in an async context — create a new thread
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, coro).result()
        else:
            return asyncio.run(coro)

    # ------------------------------------------------------------------
    # Read operations (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def load_documents(self) -> tuple[Document, ...]:
        """Load all taxonomy documents from Neo4j."""
        return self._run_async(self._load_documents_async())

    async def _load_documents_async(self) -> tuple[Document, ...]:
        """Async implementation of load_documents."""
        await self._ensure_schema()
        driver = await self._ensure_driver()

        documents: list[Document] = []
        async with driver.session(database=self._config.database) as session:
            result = await session.run(LOAD_ALL_TAXONOMY_NODES)
            records = await result.data()

            for record in records:
                node = record["n"]
                parent_name = record.get("parent_name")
                props = dict(node)
                doc = node_to_document(props, parent_name)
                documents.append(doc)

        logger.info("Loaded {} documents from Neo4j", len(documents))
        return tuple(documents)

    def load_environments(self) -> tuple[EnvironmentDocument, ...]:
        """Load all environment documents from Neo4j."""
        return self._run_async(self._load_environments_async())

    async def _load_environments_async(self) -> tuple[EnvironmentDocument, ...]:
        """Async implementation of load_environments."""
        await self._ensure_schema()
        driver = await self._ensure_driver()

        envs: list[EnvironmentDocument] = []
        async with driver.session(database=self._config.database) as session:
            result = await session.run(LOAD_ALL_ENVIRONMENTS)
            records = await result.data()

            for record in records:
                node = record["e"]
                env = env_node_to_document(dict(node))
                envs.append(env)

        return tuple(envs)

    def get_document(self, name: str) -> Document | None:
        """Get a single document by name from Neo4j."""
        return self._run_async(self._get_document_async(name))

    async def _get_document_async(self, name: str) -> Document | None:
        """Async implementation of get_document."""
        await self._ensure_schema()
        driver = await self._ensure_driver()

        async with driver.session(database=self._config.database) as session:
            result = await session.run(GET_DOCUMENT_BY_NAME, name=name)
            record = await result.single()

            if record is None:
                return None

            node = record["n"]
            parent_name = record.get("parent_name")
            return node_to_document(dict(node), parent_name)

    # ------------------------------------------------------------------
    # Write operations (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def create_node(
        self,
        node_type: str,
        name: str,
        **kwargs: object,
    ) -> SaveResult:
        """Create a node in Neo4j.

        For graph backends, this creates a node with the given properties.
        For full-featured node creation with templates, use FilesystemBackend.
        """
        return SaveResult(
            success=False,
            error="Neo4jBackend.create_node is not yet implemented. "
            "Use FilesystemBackend for node creation, then sync to Neo4j.",
        )

    # ------------------------------------------------------------------
    # Sync operations (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def sync_from(
        self,
        source: object,
        *,
        full: bool = False,
    ) -> SyncResult:
        """Sync data from another backend into Neo4j.

        This replaces the old ExportPort.full_export / incremental_sync.
        """
        return self._run_async(self._sync_from_async(source, full=full))

    async def _sync_from_async(
        self,
        source: object,
        *,
        full: bool = False,
    ) -> SyncResult:
        """Async implementation of sync_from."""
        # Import here to avoid circular imports
        from katalyst_taxonomy.adapters.neo4j.adapter import Neo4jExportAdapter
        from katalyst_taxonomy.engine.bridge import get_default_registry
        from katalyst_taxonomy.engine.resolver import build_qualified_names
        from katalyst_taxonomy.ports.export import ExportData

        # The source must have load_documents and load_environments
        if not hasattr(source, "load_documents") or not hasattr(source, "load_environments"):
            return SyncResult(
                success=False,
                errors=("Source backend must implement load_documents() and load_environments()",),
            )

        documents = source.load_documents()  # type: ignore[union-attr]
        environments = source.load_environments()  # type: ignore[union-attr]

        registry = get_default_registry()
        qualified_names = build_qualified_names(documents, registry)

        data = ExportData(
            documents=documents,
            environments=environments,
            qualified_names=qualified_names,
        )

        # Use the existing export adapter for the heavy lifting
        adapter = Neo4jExportAdapter(config=self._config, registry=registry)
        try:
            if full:
                result = await adapter.full_export(data)
            else:
                result = await adapter.incremental_sync(data)

            return SyncResult(
                success=result.success,
                nodes_created=result.nodes_created,
                nodes_updated=result.nodes_updated,
                nodes_deleted=result.nodes_deleted,
                relationships_created=result.relationships_created,
                relationships_deleted=result.relationships_deleted,
                errors=result.errors,
            )
        finally:
            await adapter.close()

    # ------------------------------------------------------------------
    # Lifecycle (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def health_check(self) -> bool:
        """Verify connectivity with a lightweight query."""
        return self._run_async(self._health_check_async())

    async def _health_check_async(self) -> bool:
        """Async implementation of health_check."""
        try:
            driver = await self._ensure_driver()
            async with driver.session(database=self._config.database) as session:
                result = await session.run(HEALTH_CHECK)
                record = await result.single()
                return record is not None and record["ok"] == 1
        except Exception as exc:
            logger.warning("Neo4j health check failed: {}", exc)
            return False

    def close(self) -> None:
        """Close the async driver."""
        if self._driver is not None:
            self._run_async(self._driver.close())
            self._driver = None

    def errors(self) -> tuple[DocumentError, ...]:
        """Neo4j backend doesn't track parse errors."""
        return ()
