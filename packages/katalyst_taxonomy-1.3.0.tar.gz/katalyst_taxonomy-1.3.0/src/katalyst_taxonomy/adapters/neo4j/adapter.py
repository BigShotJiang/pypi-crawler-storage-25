"""Neo4j export adapter — implements the ExportPort for Neo4j graph database."""

# pyright: reportMissingImports=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownParameterType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

import uuid
from typing import Any

from loguru import logger

from katalyst_taxonomy.adapters.neo4j.config import Neo4jConfig
from katalyst_taxonomy.adapters.neo4j.connection import create_async_driver
from katalyst_taxonomy.adapters.neo4j.mapper import (
    GraphRelationship,
    TaxonomyGraphMapper,
)
from katalyst_taxonomy.adapters.neo4j.queries import (
    CLEAR_ENVIRONMENTS,
    CLEAR_TAXONOMY_NODES,
    HEALTH_CHECK,
    PRUNE_STALE_ENVIRONMENTS,
    PRUNE_STALE_TAXONOMY_NODES,
    SET_KIND_LABEL,
    UPSERT_CHILD_OF,
    UPSERT_DEPENDS_ON,
    UPSERT_ENVIRONMENT_NODES,
    UPSERT_EXTENDS,
    UPSERT_GENERIC_REFERENCE,
    UPSERT_HAS_ENVIRONMENT,
    UPSERT_TAXONOMY_NODES,
)
from katalyst_taxonomy.adapters.neo4j.schema import SCHEMA_STATEMENTS
from katalyst_taxonomy.engine.registry import NodeTypeRegistry
from katalyst_taxonomy.engine.resolver import qualified_name_for
from katalyst_taxonomy.ports.export import ExportData, ExportResult


class Neo4jExportAdapter:
    """Neo4j implementation of the ExportPort.

    Supports both full export (clear + recreate) and incremental sync
    (upsert + prune stale) modes.
    """

    def __init__(self, config: Neo4jConfig, registry: NodeTypeRegistry) -> None:
        self._config = config
        self._registry = registry
        self._mapper = TaxonomyGraphMapper(_registry=registry)
        self._driver: Any = None
        self._schema_ensured = False

    async def _ensure_driver(self) -> Any:
        """Lazily create the async Neo4j driver."""
        if self._driver is None:
            self._driver = await create_async_driver(self._config)
        return self._driver

    async def _ensure_schema(self) -> None:
        """Create indexes and constraints if not already done."""
        if self._schema_ensured:
            return
        driver = await self._ensure_driver()
        async with driver.session(database=self._config.database) as session:
            for statement in SCHEMA_STATEMENTS:
                await session.run(statement)
        self._schema_ensured = True
        logger.info("Neo4j schema (constraints/indexes) ensured")

    async def full_export(self, data: ExportData) -> ExportResult:
        """Full export: clear existing data and recreate from scratch."""
        try:
            await self._ensure_schema()
            driver = await self._ensure_driver()

            sync_id = str(uuid.uuid4())
            nodes_created = 0
            relationships_created = 0

            async with driver.session(database=self._config.database) as session:
                # Clear existing data
                await session.run(CLEAR_TAXONOMY_NODES)
                await session.run(CLEAR_ENVIRONMENTS)
                logger.info("Cleared existing taxonomy and environment nodes")

                # Create taxonomy nodes
                nodes_created += await self._upsert_taxonomy_nodes(session, data, sync_id)

                # Create environment nodes
                nodes_created += await self._upsert_environment_nodes(session, data, sync_id)

                # Create relationships
                relationships_created = await self._upsert_relationships(session, data)

            logger.info(
                "Full export complete: {} nodes, {} relationships",
                nodes_created,
                relationships_created,
            )
            return ExportResult(
                success=True,
                nodes_created=nodes_created,
                relationships_created=relationships_created,
            )
        except Exception as exc:
            logger.error("Full export failed: {}", exc)
            return ExportResult(success=False, errors=(str(exc),))

    async def incremental_sync(self, data: ExportData) -> ExportResult:
        """Incremental sync: upsert nodes/relationships, prune stale entries."""
        try:
            await self._ensure_schema()
            driver = await self._ensure_driver()

            sync_id = str(uuid.uuid4())
            nodes_created = 0
            nodes_deleted = 0
            relationships_created = 0

            async with driver.session(database=self._config.database) as session:
                # Upsert taxonomy nodes
                nodes_created += await self._upsert_taxonomy_nodes(session, data, sync_id)

                # Upsert environment nodes
                nodes_created += await self._upsert_environment_nodes(session, data, sync_id)

                # Upsert relationships
                relationships_created = await self._upsert_relationships(session, data)

                # Prune stale nodes
                result = await session.run(PRUNE_STALE_TAXONOMY_NODES, sync_id=sync_id)
                record = await result.single()
                if record:
                    nodes_deleted += record["deleted"]

                result = await session.run(PRUNE_STALE_ENVIRONMENTS, sync_id=sync_id)
                record = await result.single()
                if record:
                    nodes_deleted += record["deleted"]

            logger.info(
                "Incremental sync complete: {} upserted, {} pruned, {} relationships",
                nodes_created,
                nodes_deleted,
                relationships_created,
            )
            return ExportResult(
                success=True,
                nodes_created=nodes_created,
                nodes_deleted=nodes_deleted,
                relationships_created=relationships_created,
            )
        except Exception as exc:
            logger.error("Incremental sync failed: {}", exc)
            return ExportResult(success=False, errors=(str(exc),))

    async def health_check(self) -> bool:
        """Verify connectivity with a lightweight query."""
        try:
            driver = await self._ensure_driver()
            async with driver.session(database=self._config.database) as session:
                result = await session.run(HEALTH_CHECK)
                record = await result.single()
                return record is not None and record["ok"] == 1
        except Exception as exc:
            logger.warning("Neo4j health check failed: {}", exc)
            return False

    async def close(self) -> None:
        """Close the async driver."""
        if self._driver is not None:
            await self._driver.close()
            self._driver = None
            logger.info("Neo4j driver closed")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _upsert_taxonomy_nodes(
        self,
        session: Any,
        data: ExportData,
        sync_id: str,
    ) -> int:
        """Batch-upsert taxonomy document nodes. Returns count."""
        batch_size = self._config.batch_size
        node_payloads: list[dict[str, Any]] = []
        # Track fqtns grouped by label for SET_KIND_LABEL
        label_groups: dict[str, list[str]] = {}

        for doc in data.documents:
            fqtn = qualified_name_for(doc, data.qualified_names)
            graph_node = self._mapper.map_document(doc, fqtn)

            node_payloads.append(
                {
                    "fqtn": graph_node.fqtn,
                    "name": graph_node.name,
                    "kind": graph_node.kind,
                    "properties": graph_node.properties,
                }
            )

            for label in graph_node.labels:
                if label != "TaxonomyNode":
                    label_groups.setdefault(label, []).append(graph_node.fqtn)

        # Batch upsert nodes
        for i in range(0, len(node_payloads), batch_size):
            batch = node_payloads[i : i + batch_size]
            await session.run(UPSERT_TAXONOMY_NODES, nodes=batch, sync_id=sync_id)

        # Set kind-specific labels
        for label, fqtns in label_groups.items():
            query = SET_KIND_LABEL.format(label=label)
            for i in range(0, len(fqtns), batch_size):
                batch = fqtns[i : i + batch_size]
                await session.run(query, fqtns=batch)

        return len(node_payloads)

    async def _upsert_environment_nodes(
        self,
        session: Any,
        data: ExportData,
        sync_id: str,
    ) -> int:
        """Batch-upsert environment nodes. Returns count."""
        batch_size = self._config.batch_size
        env_payloads: list[dict[str, Any]] = []

        for env in data.environments:
            graph_node = self._mapper.map_environment(env)
            env_payloads.append(
                {
                    "name": graph_node.name,
                    "properties": graph_node.properties,
                }
            )

        for i in range(0, len(env_payloads), batch_size):
            batch = env_payloads[i : i + batch_size]
            await session.run(UPSERT_ENVIRONMENT_NODES, nodes=batch, sync_id=sync_id)

        return len(env_payloads)

    async def _upsert_relationships(
        self,
        session: Any,
        data: ExportData,
    ) -> int:
        """Upsert all relationships. Returns count."""
        batch_size = self._config.batch_size
        relationships = self._mapper.extract_relationships(data.documents, data.qualified_names)

        # Structural relationship types have dedicated Cypher queries.
        _STRUCTURAL_QUERIES: dict[str, str] = {
            "CHILD_OF": UPSERT_CHILD_OF,
            "DEPENDS_ON": UPSERT_DEPENDS_ON,
            "EXTENDS": UPSERT_EXTENDS,
            "DEPLOYS_TO": UPSERT_HAS_ENVIRONMENT,
        }

        # Group relationships by type
        grouped: dict[str, list[dict[str, Any]]] = {}
        for rel in relationships:
            edge = self._rel_to_edge(rel)
            grouped.setdefault(rel.rel_type, []).append(edge)

        count = 0

        for rel_type, edges in grouped.items():
            if rel_type in _STRUCTURAL_QUERIES:
                # Use the dedicated Cypher query
                query = _STRUCTURAL_QUERIES[rel_type]
            else:
                # Generic cross-reference: format the rel type into the query
                query = UPSERT_GENERIC_REFERENCE.format(rel_type=rel_type)

            for i in range(0, len(edges), batch_size):
                await session.run(query, edges=edges[i : i + batch_size])
            count += len(edges)

        return count

    @staticmethod
    def _rel_to_edge(rel: GraphRelationship) -> dict[str, Any]:
        """Convert a GraphRelationship to a dict payload for Cypher."""
        edge: dict[str, Any] = {
            "source_fqtn": rel.source_fqtn,
            "target_fqtn": rel.target_fqtn,
        }
        # DEPLOYS_TO uses target_name (strip "env:" prefix)
        if rel.rel_type == "DEPLOYS_TO":
            target_name = rel.target_fqtn
            if target_name.startswith("env:"):
                target_name = target_name[4:]
            edge["target_name"] = target_name

        # EXTENDS needs target_kind
        if rel.rel_type == "EXTENDS" and "target_kind" in rel.properties:
            edge["target_kind"] = rel.properties["target_kind"]

        return edge
