"""Neo4j connection configuration."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Neo4jConfig:
    """Neo4j connection configuration."""

    uri: str = "bolt://localhost:7687"
    username: str = "neo4j"
    password: str = "password"
    database: str = "neo4j"
    max_connection_pool_size: int = 50
    connection_timeout: float = 30.0
    max_transaction_retry_time: float = 30.0
    batch_size: int = 5000

    @classmethod
    def from_env(cls) -> Neo4jConfig:
        """Load config from environment variables.

        Reads:
            NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD, NEO4J_DATABASE,
            NEO4J_POOL_SIZE, NEO4J_TIMEOUT, NEO4J_RETRY_TIME, NEO4J_BATCH_SIZE
        """
        return cls(
            uri=os.environ.get("NEO4J_URI", "bolt://localhost:7687"),
            username=os.environ.get("NEO4J_USERNAME", "neo4j"),
            password=os.environ.get("NEO4J_PASSWORD", "password"),
            database=os.environ.get("NEO4J_DATABASE", "neo4j"),
            max_connection_pool_size=int(os.environ.get("NEO4J_POOL_SIZE", "50")),
            connection_timeout=float(os.environ.get("NEO4J_TIMEOUT", "30.0")),
            max_transaction_retry_time=float(os.environ.get("NEO4J_RETRY_TIME", "30.0")),
            batch_size=int(os.environ.get("NEO4J_BATCH_SIZE", "5000")),
        )

    @classmethod
    def from_dict(cls, data: dict[str, object]) -> Neo4jConfig:
        """Load config from a dict (e.g., from YAML config file)."""
        return cls(
            uri=str(data.get("uri", "bolt://localhost:7687")),
            username=str(data.get("username", "neo4j")),
            password=str(data.get("password", "password")),
            database=str(data.get("database", "neo4j")),
            max_connection_pool_size=int(str(data.get("max_connection_pool_size", 50))),
            connection_timeout=float(str(data.get("connection_timeout", 30.0))),
            max_transaction_retry_time=float(str(data.get("max_transaction_retry_time", 30.0))),
            batch_size=int(str(data.get("batch_size", 5000))),
        )
