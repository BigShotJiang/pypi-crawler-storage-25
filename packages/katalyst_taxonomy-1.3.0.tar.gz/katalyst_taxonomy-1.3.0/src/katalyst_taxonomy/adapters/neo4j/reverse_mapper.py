"""Reverse mapper — reconstructs Documents from Neo4j node properties."""

# pyright: reportMissingImports=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from katalyst_taxonomy.engine.document import (
    V2_API_VERSION,
    Document,
    ExtensionTarget,
    Metadata,
)
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument


def node_to_document(
    node_props: dict[str, Any],
    parent_name: str | None = None,
) -> Document:
    """Reconstruct a Document from Neo4j node properties.

    Uses ``_spec_json`` for lossless round-tripping when available,
    otherwise reconstructs the spec from individual properties.
    """
    name = str(node_props.get("name", ""))
    kind = str(node_props.get("kind", ""))
    api_version = str(node_props.get("api_version", V2_API_VERSION))

    # Try to use the full spec JSON for lossless round-trip
    spec_json_raw = node_props.get("_spec_json")
    if spec_json_raw and isinstance(spec_json_raw, str):
        spec: dict[str, object] = json.loads(spec_json_raw)
    else:
        # Reconstruct spec from individual properties
        spec = _reconstruct_spec(node_props, parent_name)

    # Parse metadata labels
    labels_raw = node_props.get("labels", "{}")
    labels = json.loads(labels_raw) if isinstance(labels_raw, str) else {}

    # Parse metadata annotations
    annotations_raw = node_props.get("annotations", "{}")
    annotations = json.loads(annotations_raw) if isinstance(annotations_raw, str) else {}

    # Source path
    source_path_str = node_props.get("source_path")
    source_path = Path(source_path_str) if source_path_str else None

    # Extension target
    extends: ExtensionTarget | None = None
    extends_kind = node_props.get("extends_target_kind")
    extends_names = node_props.get("extends_target_names")
    if extends_kind and extends_names:
        extends = ExtensionTarget(
            target_kind=str(extends_kind),
            target_names=tuple(str(n) for n in extends_names),
        )

    return Document(
        api_version=api_version,
        kind=kind,
        metadata=Metadata(
            name=name,
            labels=labels,
            annotations=annotations,
        ),
        spec=spec,
        source_path=source_path,
        extends=extends,
    )


def _reconstruct_spec(
    node_props: dict[str, Any],
    parent_name: str | None,
) -> dict[str, object]:
    """Reconstruct a basic spec dict from node properties (lossy fallback)."""
    spec: dict[str, object] = {}

    if node_props.get("description"):
        spec["description"] = str(node_props["description"])

    owners = node_props.get("owners")
    if owners and isinstance(owners, list):
        spec["owners"] = [str(o) for o in owners]

    environments = node_props.get("environments")
    if environments and isinstance(environments, list):
        spec["environments"] = [str(e) for e in environments]

    if parent_name:
        spec["parent"] = parent_name

    layer_type = node_props.get("layer_type")
    if layer_type:
        spec["layerType"] = str(layer_type)

    return spec


def env_node_to_document(node_props: dict[str, Any]) -> EnvironmentDocument:
    """Reconstruct an EnvironmentDocument from Neo4j Environment node properties."""
    name = str(node_props.get("name", ""))
    description = str(node_props.get("description", ""))

    # Parse JSON fields
    replacements_raw = node_props.get("template_replacements", "{}")
    replacements = json.loads(replacements_raw) if isinstance(replacements_raw, str) else {}

    templates_raw = node_props.get("layer_templates", "{}")
    templates = json.loads(templates_raw) if isinstance(templates_raw, str) else {}

    source_path_str = node_props.get("source_path")
    source_path = Path(source_path_str) if source_path_str else None

    return EnvironmentDocument(
        name=name,
        description=description,
        template_replacements=replacements,
        layer_templates=templates,
        source_path=source_path,
    )
