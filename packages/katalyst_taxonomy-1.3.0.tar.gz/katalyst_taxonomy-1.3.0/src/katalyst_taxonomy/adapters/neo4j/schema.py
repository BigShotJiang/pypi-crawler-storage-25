"""Neo4j schema setup — constraints and indexes."""

from __future__ import annotations

# Constraint and index creation queries.
# These are idempotent (IF NOT EXISTS).

SCHEMA_STATEMENTS: tuple[str, ...] = (
    # Unique constraints (also create implicit indexes)
    (
        "CREATE CONSTRAINT taxonomy_node_fqtn IF NOT EXISTS "
        "FOR (n:TaxonomyNode) REQUIRE n.fqtn IS UNIQUE"
    ),
    (
        "CREATE CONSTRAINT environment_name IF NOT EXISTS "
        "FOR (e:Environment) REQUIRE e.name IS UNIQUE"
    ),
    # Lookup indexes for common query patterns
    ("CREATE INDEX taxonomy_node_name IF NOT EXISTS FOR (n:TaxonomyNode) ON (n.name)"),
    ("CREATE INDEX taxonomy_node_kind IF NOT EXISTS FOR (n:TaxonomyNode) ON (n.kind)"),
    ("CREATE INDEX taxonomy_node_sync_id IF NOT EXISTS FOR (n:TaxonomyNode) ON (n._sync_id)"),
)
