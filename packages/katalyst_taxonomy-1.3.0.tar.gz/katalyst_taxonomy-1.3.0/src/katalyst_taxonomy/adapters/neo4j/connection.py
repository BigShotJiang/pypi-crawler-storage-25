"""Neo4j connection factory and health-check helpers."""

# pyright: reportMissingImports=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownParameterType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from katalyst_taxonomy.adapters.neo4j.config import Neo4jConfig

if TYPE_CHECKING:
    pass


async def create_async_driver(config: Neo4jConfig) -> Any:
    """Create an async Neo4j driver from configuration.

    Raises ``ImportError`` if the ``neo4j`` package is not installed.
    """
    try:
        from neo4j import AsyncGraphDatabase
    except ImportError as exc:
        raise ImportError(
            "The 'neo4j' package is required for Neo4j export. "
            "Install it with: pip install katalyst-taxonomy[neo4j]"
        ) from exc

    return AsyncGraphDatabase.driver(
        config.uri,
        auth=(config.username, config.password),
        max_connection_pool_size=config.max_connection_pool_size,
        connection_timeout=config.connection_timeout,
        max_transaction_retry_time=config.max_transaction_retry_time,
    )
