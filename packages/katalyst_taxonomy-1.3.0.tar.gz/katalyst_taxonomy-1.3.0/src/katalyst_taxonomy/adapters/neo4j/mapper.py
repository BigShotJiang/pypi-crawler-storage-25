"""Document-to-graph mapper — converts taxonomy Documents to Neo4j graph primitives."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, cast

from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.registry import NodeTypeRegistry
from katalyst_taxonomy.engine.resolver import qualified_name_for
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

# Spec keys that are handled structurally (not cross-references).
_STRUCTURAL_KEYS: frozenset[str] = frozenset(
    {
        "description",
        "owners",
        "annotations",
        "environments",
        "parents",
        "dependsOn",
        "parent",
        "layerType",
        "layer_type",
        "_markdown_body",
    }
)


@dataclass(frozen=True, slots=True)
class GraphNode:
    """A node ready for Neo4j insertion."""

    fqtn: str
    name: str
    kind: str
    labels: tuple[str, ...]  # ("TaxonomyNode", "System")
    properties: dict[str, Any]


@dataclass(frozen=True, slots=True)
class GraphRelationship:
    """A relationship ready for Neo4j insertion."""

    source_fqtn: str
    target_fqtn: str
    rel_type: str  # "CHILD_OF", "DEPENDS_ON", "HAS_CAPABILITY", …
    properties: dict[str, Any] = field(default_factory=lambda: dict[str, Any]())


def _kind_to_label(kind: str) -> str:
    """Convert a taxonomy kind to a PascalCase Neo4j label.

    Examples:
        system -> System
        team_member -> TeamMember
        app_docker -> AppDocker
    """
    return "".join(part.capitalize() for part in kind.split("_"))


def _field_to_rel_type(field_name: str) -> str:
    """Derive a Neo4j relationship type from a spec field name.

    Converts camelCase/snake_case field names to UPPER_SNAKE_CASE
    and prepends ``HAS_`` when the name is a bare noun.

    Examples:
        capabilities       -> HAS_CAPABILITY
        specification_ref  -> HAS_SPECIFICATION
        user_type_ref      -> HAS_USER_TYPE
        stories            -> HAS_STORY
        tools              -> HAS_TOOL
        blocked_by         -> BLOCKED_BY
        blocks             -> BLOCKS
        depends_on_capabilities -> DEPENDS_ON_CAPABILITY
        stage_depends_on   -> STAGE_DEPENDS_ON
    """
    # Strip trailing _ref / _id suffixes — they indicate a foreign-key style reference
    cleaned = re.sub(r"(_ref|_id)$", "", field_name)

    # De-pluralise simple cases (capabilities -> capability, stories -> story, etc.)
    if cleaned.endswith("ies"):
        cleaned = cleaned[:-3] + "y"
    elif cleaned.endswith("s") and not cleaned.endswith("ss"):
        cleaned = cleaned[:-1]

    # Already snake_case, just upper it
    upper = cleaned.upper()

    # If the result is a bare noun (no verb prefix), add HAS_
    verb_prefixes = ("DEPENDS", "BLOCKED", "BLOCKS", "STAGE", "REQUIRES", "INCLUDES")
    if not any(upper.startswith(prefix) for prefix in verb_prefixes):
        upper = f"HAS_{upper}"

    return upper


@dataclass(slots=True)
class TaxonomyGraphMapper:
    """Maps taxonomy Documents to Neo4j graph nodes and relationships.

    Cross-reference relationships are driven by the ``cross_references``
    metadata in the node type registry, which is generated from
    ``annotations: { references: <kind> }`` in LinkML schemas.
    """

    _registry: NodeTypeRegistry

    def map_document(self, doc: Document, fqtn: str) -> GraphNode:
        """Map a single Document to a GraphNode."""
        kind_label = _kind_to_label(doc.kind)
        labels: list[str] = ["TaxonomyNode", kind_label]

        if doc.is_extension:
            labels.append("Extension")

        # Get wing from registry
        descriptor = self._registry.get(doc.kind)
        wing = descriptor.wing if descriptor else None

        properties: dict[str, Any] = {
            "api_version": doc.api_version,
            "description": doc.description,
            "owners": list(doc.owners),
            "environments": list(doc.environments),
            "labels": json.dumps(dict(doc.metadata.labels)),
            "annotations": json.dumps(dict(doc.metadata.annotations)),
            "spec_annotations": json.dumps(doc.annotations_map),
            "source_path": str(doc.source_path) if doc.source_path else None,
            # Full spec JSON for lossless round-trip reads
            "_spec_json": json.dumps(dict(doc.spec)),
        }

        if wing:
            properties["wing"] = wing

        # Layer-specific properties
        layer_type = doc.spec.get("layerType") or doc.spec.get("layer_type")
        if layer_type:
            properties["layer_type"] = str(layer_type)

        # Extension-specific properties
        if doc.extends:
            properties["extends_target_kind"] = doc.extends.target_kind
            properties["extends_target_names"] = list(doc.extends.target_names)

        return GraphNode(
            fqtn=fqtn,
            name=doc.name,
            kind=doc.kind,
            labels=tuple(labels),
            properties=properties,
        )

    def map_environment(self, env: EnvironmentDocument) -> GraphNode:
        """Map an EnvironmentDocument to a GraphNode."""
        return GraphNode(
            fqtn=f"env:{env.name}",
            name=env.name,
            kind="environment",
            labels=("Environment",),
            properties={
                "description": env.description,
                "template_replacements": json.dumps(dict(env.template_replacements)),
                "layer_templates": json.dumps({k: dict(v) for k, v in env.layer_templates.items()}),
                "source_path": str(env.source_path) if env.source_path else None,
            },
        )

    def extract_relationships(
        self,
        documents: tuple[Document, ...],
        qualified_names: dict[str, str],
    ) -> list[GraphRelationship]:
        """Extract all relationships from taxonomy documents.

        Structural relationships (always extracted):
        - CHILD_OF from doc.parent
        - DEPENDS_ON from doc.depends_on_nodes
        - EXTENDS from doc.extends
        - HAS_ENVIRONMENT from doc.environments

        Cross-references (registry-driven):
        For each node type, the registry declares which spec fields reference
        other node types (via ``cross_references``).  The mapper reads
        the declared fields and creates relationships for values that
        resolve to known node names.
        """
        relationships: list[GraphRelationship] = []

        # Build a name-to-fqtn lookup for resolving references
        name_to_fqtn = self._build_name_to_fqtn(documents, qualified_names)
        known_names = set(name_to_fqtn.keys())

        for doc in documents:
            source_fqtn = qualified_name_for(doc, qualified_names)

            # --- Structural relationships ---

            # CHILD_OF
            if doc.parent:
                parent_fqtn = name_to_fqtn.get(doc.parent, doc.parent)
                relationships.append(
                    GraphRelationship(
                        source_fqtn=source_fqtn,
                        target_fqtn=parent_fqtn,
                        rel_type="CHILD_OF",
                    )
                )

            # DEPENDS_ON
            for dep_name in doc.depends_on_nodes:
                dep_fqtn = name_to_fqtn.get(dep_name, dep_name)
                relationships.append(
                    GraphRelationship(
                        source_fqtn=source_fqtn,
                        target_fqtn=dep_fqtn,
                        rel_type="DEPENDS_ON",
                    )
                )

            # EXTENDS
            if doc.extends:
                for target_name in doc.extends.target_names:
                    target_fqtn = name_to_fqtn.get(target_name, target_name)
                    relationships.append(
                        GraphRelationship(
                            source_fqtn=source_fqtn,
                            target_fqtn=target_fqtn,
                            rel_type="EXTENDS",
                            properties={
                                "target_kind": doc.extends.target_kind,
                            },
                        )
                    )

            # HAS_ENVIRONMENT — only for system-wing nodes where
            # environment deployment is meaningful.
            descriptor = self._registry.get(doc.kind)
            if descriptor and descriptor.wing == "system":
                for env_name in doc.environments:
                    relationships.append(
                        GraphRelationship(
                            source_fqtn=source_fqtn,
                            target_fqtn=f"env:{env_name}",
                            rel_type="DEPLOYS_TO",
                        )
                    )

            # --- Registry-driven cross-references ---
            self._extract_registry_references(
                doc, source_fqtn, name_to_fqtn, known_names, relationships
            )

        return relationships

    def _extract_registry_references(
        self,
        doc: Document,
        source_fqtn: str,
        name_to_fqtn: dict[str, str],
        known_names: set[str],
        relationships: list[GraphRelationship],
    ) -> None:
        """Extract cross-references declared in the registry for this node type.

        Reads ``cross_references`` from the ``NodeTypeDescriptor`` and
        looks up each declared field in the document's spec.
        """
        descriptor = self._registry.get(doc.kind)
        if descriptor is None or descriptor.cross_references is None:
            return

        for attr_name, _target_kind, rel_type_override in descriptor.cross_references:
            # Spec keys use camelCase; attribute names from LinkML use snake_case.
            # Try both the snake_case name and a camelCase variant.
            value = doc.spec.get(attr_name)
            if value is None:
                camel = _snake_to_camel(attr_name)
                value = doc.spec.get(camel)
            if value is None:
                continue

            # Use the schema-defined rel_type if available, otherwise derive it
            rel_type = rel_type_override if rel_type_override else _field_to_rel_type(attr_name)

            # Single string reference
            if isinstance(value, str) and value in known_names:
                target_fqtn = name_to_fqtn.get(value, value)
                relationships.append(
                    GraphRelationship(
                        source_fqtn=source_fqtn,
                        target_fqtn=target_fqtn,
                        rel_type=rel_type,
                        properties={"source_field": attr_name},
                    )
                )

            # List of string references
            elif isinstance(value, list):
                ref_names: list[str] = [
                    str(v) for v in cast(list[object], value) if str(v) in known_names
                ]
                for ref_name in ref_names:
                    target_fqtn = name_to_fqtn.get(ref_name, ref_name)
                    relationships.append(
                        GraphRelationship(
                            source_fqtn=source_fqtn,
                            target_fqtn=target_fqtn,
                            rel_type=rel_type,
                            properties={"source_field": attr_name},
                        )
                    )

    def _build_name_to_fqtn(
        self,
        documents: tuple[Document, ...],
        qualified_names: dict[str, str],
    ) -> dict[str, str]:
        """Build a simple name -> FQTN mapping for reference resolution.

        When multiple documents share the same name, the last one wins.
        This is used for resolving parent/dependency references.
        """
        name_to_fqtn: dict[str, str] = {}
        for doc in documents:
            fqtn = qualified_name_for(doc, qualified_names)
            name_to_fqtn[doc.name] = fqtn
        return name_to_fqtn


def _snake_to_camel(name: str) -> str:
    """Convert snake_case to camelCase.

    Examples:
        specification_ref -> specificationRef
        user_type_ref -> userTypeRef
        depends_on_capabilities -> dependsOnCapabilities
    """
    parts = name.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])
