"""Cypher query constants for Neo4j taxonomy export."""

# ---------------------------------------------------------------------------
# Batch upsert nodes
# ---------------------------------------------------------------------------

UPSERT_TAXONOMY_NODES = """
UNWIND $nodes AS node
MERGE (n:TaxonomyNode {fqtn: node.fqtn})
ON CREATE SET n._created_at = datetime()
SET n += node.properties,
    n.kind = node.kind,
    n.name = node.name,
    n.fqtn = node.fqtn,
    n._sync_id = $sync_id,
    n._synced_at = datetime()
"""

UPSERT_ENVIRONMENT_NODES = """
UNWIND $nodes AS node
MERGE (e:Environment {name: node.name})
ON CREATE SET e._created_at = datetime()
SET e += node.properties,
    e.name = node.name,
    e._sync_id = $sync_id,
    e._synced_at = datetime()
"""

# ---------------------------------------------------------------------------
# Set kind-specific labels (run per-kind batch)
# The {label} placeholder must be formatted into the query string since
# Cypher doesn't support parameterized labels.
# ---------------------------------------------------------------------------

SET_KIND_LABEL = """
UNWIND $fqtns AS fqtn
MATCH (n:TaxonomyNode {{fqtn: fqtn}})
SET n:{label}
"""

# ---------------------------------------------------------------------------
# Relationship upserts
# ---------------------------------------------------------------------------

UPSERT_CHILD_OF = """
UNWIND $edges AS edge
MATCH (child:TaxonomyNode {fqtn: edge.source_fqtn})
MATCH (parent:TaxonomyNode {fqtn: edge.target_fqtn})
MERGE (child)-[r:CHILD_OF]->(parent)
ON CREATE SET r.created_at = datetime()
"""

UPSERT_DEPENDS_ON = """
UNWIND $edges AS edge
MATCH (a:TaxonomyNode {fqtn: edge.source_fqtn})
MATCH (b:TaxonomyNode {fqtn: edge.target_fqtn})
MERGE (a)-[r:DEPENDS_ON]->(b)
ON CREATE SET r.created_at = datetime()
"""

UPSERT_EXTENDS = """
UNWIND $edges AS edge
MATCH (ext:TaxonomyNode {fqtn: edge.source_fqtn})
MATCH (target:TaxonomyNode {fqtn: edge.target_fqtn})
MERGE (ext)-[r:EXTENDS]->(target)
ON CREATE SET r.created_at = datetime()
SET r.target_kind = edge.target_kind
"""

UPSERT_HAS_ENVIRONMENT = """
UNWIND $edges AS edge
MATCH (n:TaxonomyNode {fqtn: edge.source_fqtn})
MATCH (e:Environment {name: edge.target_name})
MERGE (n)-[r:DEPLOYS_TO]->(e)
ON CREATE SET r.created_at = datetime()
"""

# ---------------------------------------------------------------------------
# Generic cross-reference relationship upsert
# The {rel_type} placeholder is formatted at runtime with the relationship
# type derived from the spec field name (e.g., HAS_CAPABILITY, BLOCKED_BY).
# ---------------------------------------------------------------------------

UPSERT_GENERIC_REFERENCE = """
UNWIND $edges AS edge
MATCH (a:TaxonomyNode {{fqtn: edge.source_fqtn}})
MATCH (b:TaxonomyNode {{fqtn: edge.target_fqtn}})
MERGE (a)-[r:{rel_type}]->(b)
ON CREATE SET r.created_at = datetime()
"""

# ---------------------------------------------------------------------------
# Pruning stale data
# ---------------------------------------------------------------------------

PRUNE_STALE_TAXONOMY_NODES = """
MATCH (n:TaxonomyNode)
WHERE n._sync_id <> $sync_id OR n._sync_id IS NULL
DETACH DELETE n
RETURN count(n) AS deleted
"""

PRUNE_STALE_ENVIRONMENTS = """
MATCH (e:Environment)
WHERE e._sync_id <> $sync_id OR e._sync_id IS NULL
DETACH DELETE e
RETURN count(e) AS deleted
"""

# ---------------------------------------------------------------------------
# Full clear (for full export mode)
# ---------------------------------------------------------------------------

CLEAR_TAXONOMY_NODES = "MATCH (n:TaxonomyNode) DETACH DELETE n"
CLEAR_ENVIRONMENTS = "MATCH (e:Environment) DETACH DELETE e"

# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

HEALTH_CHECK = "RETURN 1 AS ok"

# ---------------------------------------------------------------------------
# Count queries (for result reporting)
# ---------------------------------------------------------------------------

COUNT_TAXONOMY_NODES = "MATCH (n:TaxonomyNode) RETURN count(n) AS count"
COUNT_ENVIRONMENTS = "MATCH (e:Environment) RETURN count(e) AS count"
COUNT_RELATIONSHIPS = """
MATCH ()-[r]->()
WHERE type(r) IN [
    'CHILD_OF', 'DEPENDS_ON', 'EXTENDS', 'HAS_ENVIRONMENT',
    'REQUIRES_CAPABILITY', 'SPECIFIES', 'FOR_USER_TYPE', 'INCLUDES_STORY'
]
RETURN count(r) AS count
"""

# ---------------------------------------------------------------------------
# Read queries (for Neo4jBackend read operations)
# ---------------------------------------------------------------------------

LOAD_ALL_TAXONOMY_NODES = """
MATCH (n:TaxonomyNode)
OPTIONAL MATCH (n)-[:CHILD_OF]->(parent:TaxonomyNode)
RETURN n, parent.name AS parent_name
ORDER BY n.kind, n.name
"""

LOAD_ALL_ENVIRONMENTS = """
MATCH (e:Environment)
RETURN e
ORDER BY e.name
"""

GET_DOCUMENT_BY_NAME = """
MATCH (n:TaxonomyNode {name: $name})
OPTIONAL MATCH (n)-[:CHILD_OF]->(parent:TaxonomyNode)
RETURN n, parent.name AS parent_name
LIMIT 1
"""

GET_DOCUMENT_BY_FQTN = """
MATCH (n:TaxonomyNode {fqtn: $fqtn})
OPTIONAL MATCH (n)-[:CHILD_OF]->(parent:TaxonomyNode)
RETURN n, parent.name AS parent_name
LIMIT 1
"""

GET_DOCUMENT_DEPENDENCIES = """
MATCH (n:TaxonomyNode {fqtn: $fqtn})-[:DEPENDS_ON]->(dep:TaxonomyNode)
RETURN dep.name AS dep_name
"""
