"""Interactive prompt adapter for init service.

This module provides a rich terminal UI for user interaction during initialization.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from typing import TextIO

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.table import Table

from katalyst_taxonomy.ports.init import (
    CollectedEnvironmentValues,
    EnvironmentChoice,
    EnvironmentValuePrompt,
    LayerTypeChoice,
    PluginChoice,
)


def _read_selection(
    choices: list[tuple[str, str]],
    selected: set[int],
    console: Console,
    in_stream: TextIO,
) -> set[int]:
    """Read user selection input.

    Args:
        choices: List of choice tuples (name, description).
        selected: Currently selected indices.
        console: Rich console for output.
        in_stream: Input stream for reading.

    Returns:
        Updated set of selected indices.
    """
    console.print()
    console.print(
        "[dim]Enter numbers to toggle (e.g., '1 3'), 'a' for all, 'n' for none, or press Enter to continue:[/dim]",
    )
    console.print()

    try:
        line = in_stream.readline().strip().lower()
    except (EOFError, KeyboardInterrupt):
        return selected

    if not line:
        return selected

    if line == "a":
        return set(range(len(choices)))

    if line == "n":
        return set()

    # Parse numbers
    new_selected = set(selected)
    for part in line.split():
        try:
            num = int(part)
            if 1 <= num <= len(choices):
                idx = num - 1
                if idx in new_selected:
                    new_selected.discard(idx)
                else:
                    new_selected.add(idx)
        except ValueError:
            continue

    return new_selected


def _display_checkbox_menu(
    title: str,
    choices: list[tuple[str, str]],  # (name, description)
    selected: set[int],
    console: Console,
) -> None:
    """Display a checkbox-style menu.

    Args:
        title: Menu title.
        choices: List of (name, description) tuples.
        selected: Set of selected indices.
        console: Rich console for output.
    """
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Num", style="dim", width=4)
    table.add_column("Check", width=3)
    table.add_column("Name", style="bold")
    table.add_column("Description", style="dim")

    for i, (name, desc) in enumerate(choices):
        check = "[green]✓[/green]" if i in selected else "[ ]"
        num = f"{i + 1}."
        table.add_row(num, check, name, desc)

    panel = Panel(table, title=f"[bold]{title}[/bold]", border_style="blue")
    console.print(panel)


@dataclass
class InteractivePrompt:
    """Interactive prompt adapter using rich for terminal UI.

    This adapter provides a rich terminal interface for selecting plugins
    and layer types during initialization.

    Attributes:
        console: Rich console for output.
        in_stream: Input stream for reading user input.
    """

    console: Console = field(default_factory=lambda: Console())
    in_stream: TextIO = field(default_factory=lambda: sys.stdin)

    def confirm(self, message: str, default: bool = True) -> bool:
        """Ask user for yes/no confirmation.

        Args:
            message: The confirmation message to display.
            default: Default value if user just presses enter.

        Returns:
            True if confirmed, False otherwise.
        """
        return Confirm.ask(message, default=default, console=self.console)

    def select_plugins(self, choices: list[PluginChoice]) -> list[PluginChoice]:
        """Prompt user to select plugins to install.

        Args:
            choices: Available plugin choices with defaults.

        Returns:
            List of choices with updated selection status.
        """
        if not choices:
            return choices

        # Build display choices
        display_choices = [(c.name, c.description) for c in choices]

        # Initial selection based on pre-selected choices
        selected: set[int] = {i for i, c in enumerate(choices) if c.selected}

        # Interactive selection loop
        while True:
            self.console.clear()
            self.console.print()
            self.console.print("[bold cyan]Katalyst Taxonomy Setup[/bold cyan]")
            self.console.print()

            _display_checkbox_menu(
                "Select Plugins to Install",
                display_choices,
                selected,
                self.console,
            )

            prev_selected = set(selected)
            selected = _read_selection(display_choices, selected, self.console, self.in_stream)

            # If no change, user pressed Enter to continue
            if selected == prev_selected:
                break

        # Build result
        return [
            PluginChoice(
                name=c.name,
                description=c.description,
                selected=i in selected,
            )
            for i, c in enumerate(choices)
        ]

    def select_layer_types(self, choices: list[LayerTypeChoice]) -> list[LayerTypeChoice]:
        """Prompt user to select layer types to install.

        Args:
            choices: Available layer type choices with defaults.

        Returns:
            List of choices with updated selection status.
        """
        if not choices:
            return choices

        # Build display choices
        display_choices = [(c.name, c.description) for c in choices]

        # Initial selection based on pre-selected choices
        selected: set[int] = {i for i, c in enumerate(choices) if c.selected}

        # Interactive selection loop
        while True:
            self.console.clear()
            self.console.print()
            self.console.print("[bold cyan]Katalyst Taxonomy Setup[/bold cyan]")
            self.console.print()

            _display_checkbox_menu(
                "Select Layer Types to Install",
                display_choices,
                selected,
                self.console,
            )

            prev_selected = set(selected)
            selected = _read_selection(display_choices, selected, self.console, self.in_stream)

            # If no change, user pressed Enter to continue
            if selected == prev_selected:
                break

        # Build result
        return [
            LayerTypeChoice(
                name=c.name,
                description=c.description,
                plugin=c.plugin,
                selected=i in selected,
            )
            for i, c in enumerate(choices)
        ]

    def select_environments(self, choices: list[EnvironmentChoice]) -> list[EnvironmentChoice]:
        """Prompt user to select environments to create.

        Args:
            choices: Available environment choices with defaults.

        Returns:
            List of choices with updated selection status.
        """
        if not choices:
            return choices

        # Build display choices
        display_choices = [(c.name, c.description) for c in choices]

        # Initial selection based on pre-selected choices (environments default to selected)
        selected: set[int] = {i for i, c in enumerate(choices) if c.selected}

        # Interactive selection loop
        while True:
            self.console.clear()
            self.console.print()
            self.console.print("[bold cyan]Katalyst Taxonomy Setup[/bold cyan]")
            self.console.print()

            _display_checkbox_menu(
                "Select Environments to Create",
                display_choices,
                selected,
                self.console,
            )

            prev_selected = set(selected)
            selected = _read_selection(display_choices, selected, self.console, self.in_stream)

            # If no change, user pressed Enter to continue
            if selected == prev_selected:
                break

        # Build result
        return [
            EnvironmentChoice(
                name=c.name,
                description=c.description,
                selected=i in selected,
            )
            for i, c in enumerate(choices)
        ]

    def collect_environment_values(
        self,
        prompts: list[EnvironmentValuePrompt],
        environments: list[str],
        layer_types: list[str],
    ) -> list[CollectedEnvironmentValues]:
        """Prompt user for environment-specific values required by layer types.

        Displays an editable form where each key shows its smart default in
        brackets.  Pressing Enter accepts the default.

        Args:
            prompts: Flat list of value prompts.
            environments: Ordered list of selected environment names.
            layer_types: Ordered list of selected layer type names.

        Returns:
            One CollectedEnvironmentValues per environment.
        """
        if not prompts:
            return [CollectedEnvironmentValues(environment=env) for env in environments]

        self.console.clear()
        self.console.print()
        self.console.print("[bold cyan]Katalyst Taxonomy Setup[/bold cyan]")
        self.console.print()
        self.console.print(
            Panel(
                "[bold]Configure Environment Values[/bold]\n\n"
                "Each selected layer type requires certain configuration values per environment.\n"
                "Press Enter to accept the [dim]default[/dim] shown in brackets.",
                border_style="blue",
            ),
        )

        return _collect_env_values_interactive(
            prompts, environments, layer_types, self.console, self.in_stream
        )

    def display_summary(self, config: object) -> None:
        """Display a summary of the initialization configuration.

        Args:
            config: The InitConfig object to summarize.
        """
        self.console.print()

        # Get config attributes
        target_path = getattr(config, "target_path", "unknown")
        source = getattr(config, "source", "bundled")
        plugins = getattr(config, "plugins", ())
        layer_types = getattr(config, "layer_types", ())
        environments = getattr(config, "environments", ())

        # Build summary table
        table = Table(show_header=False, box=None, padding=(0, 2))
        table.add_column("Property", style="bold")
        table.add_column("Value")

        table.add_row("Target Path:", str(target_path))
        table.add_row("Source:", source)

        if plugins:
            table.add_row("Plugins:", ", ".join(plugins))
        else:
            table.add_row("Plugins:", "[dim]none[/dim]")

        if layer_types:
            table.add_row("Layer Types:", ", ".join(layer_types))
        else:
            table.add_row("Layer Types:", "[dim]none[/dim]")

        if environments:
            table.add_row("Environments:", ", ".join(environments))
        else:
            table.add_row("Environments:", "[dim]none[/dim]")

        panel = Panel(table, title="[bold]Configuration Summary[/bold]", border_style="green")
        self.console.print(panel)
        self.console.print()


@dataclass
class SimpleInteractivePrompt:
    """Simpler interactive prompt without screen clearing.

    This is better for non-TTY environments or when you want simpler output.
    """

    console: Console = field(default_factory=lambda: Console())
    in_stream: TextIO = field(default_factory=lambda: sys.stdin)

    def confirm(self, message: str, default: bool = True) -> bool:
        """Ask user for yes/no confirmation."""
        return Confirm.ask(message, default=default, console=self.console)

    def select_plugins(self, choices: list[PluginChoice]) -> list[PluginChoice]:
        """Prompt user to select plugins."""
        if not choices:
            return choices

        self.console.print()
        self.console.print("[bold]Available Plugins:[/bold]")
        self.console.print()

        for i, c in enumerate(choices):
            default_mark = "[green]✓[/green]" if c.selected else "[ ]"
            self.console.print(f"  {i + 1}. {default_mark} [bold]{c.name}[/bold] - {c.description}")

        self.console.print()
        self.console.print(
            "[dim]Enter numbers separated by spaces (e.g., '1 2'), 'a' for all, 'n' for none:[/dim]",
        )

        selected = self._read_numbers(
            len(choices),
            {i for i, c in enumerate(choices) if c.selected},
        )

        return [
            PluginChoice(name=c.name, description=c.description, selected=i in selected)
            for i, c in enumerate(choices)
        ]

    def select_layer_types(self, choices: list[LayerTypeChoice]) -> list[LayerTypeChoice]:
        """Prompt user to select layer types."""
        if not choices:
            return choices

        self.console.print()
        self.console.print("[bold]Available Layer Types:[/bold]")
        self.console.print()

        for i, c in enumerate(choices):
            default_mark = "[green]✓[/green]" if c.selected else "[ ]"
            self.console.print(f"  {i + 1}. {default_mark} [bold]{c.name}[/bold] - {c.description}")

        self.console.print()
        self.console.print(
            "[dim]Enter numbers separated by spaces (e.g., '1 2 3'), 'a' for all, 'n' for none:[/dim]",
        )

        selected = self._read_numbers(
            len(choices),
            {i for i, c in enumerate(choices) if c.selected},
        )

        return [
            LayerTypeChoice(
                name=c.name,
                description=c.description,
                plugin=c.plugin,
                selected=i in selected,
            )
            for i, c in enumerate(choices)
        ]

    def select_environments(self, choices: list[EnvironmentChoice]) -> list[EnvironmentChoice]:
        """Prompt user to select environments to create."""
        if not choices:
            return choices

        self.console.print()
        self.console.print("[bold]Available Environments:[/bold]")
        self.console.print()

        for i, c in enumerate(choices):
            default_mark = "[green]✓[/green]" if c.selected else "[ ]"
            self.console.print(f"  {i + 1}. {default_mark} [bold]{c.name}[/bold] - {c.description}")

        self.console.print()
        self.console.print(
            "[dim]Enter numbers separated by spaces (e.g., '1 2 3'), 'a' for all, 'n' for none:[/dim]",
        )

        selected = self._read_numbers(
            len(choices),
            {i for i, c in enumerate(choices) if c.selected},
        )

        return [
            EnvironmentChoice(name=c.name, description=c.description, selected=i in selected)
            for i, c in enumerate(choices)
        ]

    def collect_environment_values(
        self,
        prompts: list[EnvironmentValuePrompt],
        environments: list[str],
        layer_types: list[str],
    ) -> list[CollectedEnvironmentValues]:
        """Prompt user for environment-specific values required by layer types.

        Uses the shared interactive collection helper with simple output.

        Args:
            prompts: Flat list of value prompts.
            environments: Ordered list of selected environment names.
            layer_types: Ordered list of selected layer type names.

        Returns:
            One CollectedEnvironmentValues per environment.
        """
        if not prompts:
            return [CollectedEnvironmentValues(environment=env) for env in environments]

        self.console.print()
        self.console.print("[bold]Configure Environment Values[/bold]")
        self.console.print(
            "[dim]Press Enter to accept defaults shown in brackets.[/dim]",
        )

        return _collect_env_values_interactive(
            prompts, environments, layer_types, self.console, self.in_stream
        )

    def _read_numbers(self, max_num: int, default: set[int]) -> set[int]:
        """Read number selection from user."""
        try:
            line = self.in_stream.readline().strip().lower()
        except (EOFError, KeyboardInterrupt):
            return default

        if not line:
            return default

        if line == "a":
            return set(range(max_num))

        if line == "n":
            return set()

        selected: set[int] = set()
        for part in line.split():
            try:
                num = int(part)
                if 1 <= num <= max_num:
                    selected.add(num - 1)
            except ValueError:
                continue

        return selected if selected else default

    def display_summary(self, config: object) -> None:
        """Display configuration summary."""
        self.console.print()

        target_path = getattr(config, "target_path", "unknown")
        source = getattr(config, "source", "bundled")
        plugins = getattr(config, "plugins", ())
        layer_types = getattr(config, "layer_types", ())
        environments = getattr(config, "environments", ())

        self.console.print("[bold]Configuration Summary:[/bold]")
        self.console.print(f"  Target Path:  {target_path}")
        self.console.print(f"  Source:       {source}")
        self.console.print(f"  Plugins:      {', '.join(plugins) if plugins else 'none'}")
        self.console.print(f"  Layer Types:  {', '.join(layer_types) if layer_types else 'none'}")
        self.console.print(f"  Environments: {', '.join(environments) if environments else 'none'}")
        self.console.print()


def _collect_env_values_interactive(
    prompts: list[EnvironmentValuePrompt],
    environments: list[str],
    layer_types: list[str],
    console: Console,
    in_stream: TextIO,
) -> list[CollectedEnvironmentValues]:
    """Shared implementation for collecting environment values interactively.

    Groups prompts by environment, then by layer type, and asks the user for
    each value.  The default is shown in brackets; pressing Enter accepts it.

    Args:
        prompts: Flat list of value prompts.
        environments: Ordered list of selected environment names.
        layer_types: Ordered list of selected layer type names.
        console: Rich console for output.
        in_stream: Input stream for reading.

    Returns:
        One CollectedEnvironmentValues per environment.
    """
    # Index prompts by (environment, layer_type)
    by_env: dict[str, list[EnvironmentValuePrompt]] = {}
    for p in prompts:
        by_env.setdefault(p.environment, []).append(p)

    results: list[CollectedEnvironmentValues] = []

    for env_name in environments:
        env_prompts = by_env.get(env_name, [])
        if not env_prompts:
            results.append(CollectedEnvironmentValues(environment=env_name))
            continue

        console.print()
        console.print(f"  [bold yellow]Environment: {env_name}[/bold yellow]")

        template_replacements: dict[str, str] = {}
        layer_templates: dict[str, dict[str, str]] = {}

        # Group by layer_type for display
        current_lt: str | None = None
        for prompt in env_prompts:
            if prompt.layer_type != (current_lt or ""):
                current_lt = prompt.layer_type
                if current_lt:
                    console.print()
                    console.print(f"    [bold]{current_lt}:[/bold]")

            default_display = f" [{prompt.default}]" if prompt.default else ""
            console.print(
                f"      {prompt.key}{default_display}: ",
                end="",
            )

            try:
                user_input = in_stream.readline().strip()
            except (EOFError, KeyboardInterrupt):
                user_input = ""

            value = user_input if user_input else prompt.default

            if prompt.layer_type:
                if prompt.layer_type not in layer_templates:
                    layer_templates[prompt.layer_type] = {}
                layer_templates[prompt.layer_type][prompt.key] = value
            else:
                template_replacements[prompt.key] = value

        results.append(
            CollectedEnvironmentValues(
                environment=env_name,
                template_replacements=template_replacements,
                layer_templates=layer_templates,
            ),
        )

    return results
