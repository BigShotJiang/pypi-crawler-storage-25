"""Prompt adapters for init service.

This module contains adapters implementing the InitPrompt protocol.
"""

from __future__ import annotations

from dataclasses import dataclass

from katalyst_taxonomy.ports.init import (
    CollectedEnvironmentValues,
    EnvironmentChoice,
    EnvironmentValuePrompt,
    LayerTypeChoice,
    PluginChoice,
)


@dataclass
class NonInteractivePrompt:
    """Non-interactive prompt adapter that uses defaults.

    This adapter is used when running in non-interactive mode (e.g., CI/CD).
    It returns pre-selected choices without prompting the user.

    Attributes:
        select_all_plugins: If True, select all plugins by default.
        select_all_layer_types: If True, select all layer types by default.
        select_all_environments: If True, select all environments by default.
    """

    select_all_plugins: bool = False
    select_all_layer_types: bool = False
    select_all_environments: bool = True

    def confirm(self, message: str, default: bool = True) -> bool:
        """Return the default value without prompting.

        Args:
            message: The confirmation message (ignored).
            default: Default value to return.

        Returns:
            The default value.
        """
        return default

    def select_plugins(self, choices: list[PluginChoice]) -> list[PluginChoice]:
        """Return plugin choices with default selections.

        If select_all_plugins is True, all plugins are selected.
        Otherwise, returns choices with their pre-set selected values.

        Args:
            choices: Available plugin choices.

        Returns:
            Plugin choices with selection status.
        """
        if self.select_all_plugins:
            return [
                PluginChoice(
                    name=c.name,
                    description=c.description,
                    selected=True,
                )
                for c in choices
            ]
        return choices

    def select_layer_types(self, choices: list[LayerTypeChoice]) -> list[LayerTypeChoice]:
        """Return layer type choices with default selections.

        If select_all_layer_types is True, all layer types are selected.
        Otherwise, returns choices with their pre-set selected values.

        Args:
            choices: Available layer type choices.

        Returns:
            Layer type choices with selection status.
        """
        if self.select_all_layer_types:
            return [
                LayerTypeChoice(
                    name=c.name,
                    description=c.description,
                    plugin=c.plugin,
                    selected=True,
                )
                for c in choices
            ]
        return choices

    def select_environments(self, choices: list[EnvironmentChoice]) -> list[EnvironmentChoice]:
        """Return environment choices with default selections.

        If select_all_environments is True, all environments are selected.
        Otherwise, returns choices with their pre-set selected values.

        Args:
            choices: Available environment choices.

        Returns:
            Environment choices with selection status.
        """
        if self.select_all_environments:
            return [
                EnvironmentChoice(
                    name=c.name,
                    description=c.description,
                    selected=True,
                )
                for c in choices
            ]
        return choices

    def display_summary(self, config: object) -> None:
        """No-op in non-interactive mode.

        Args:
            config: The configuration (ignored).
        """

    def collect_environment_values(
        self,
        prompts: list[EnvironmentValuePrompt],
        environments: list[str],
        layer_types: list[str],
    ) -> list[CollectedEnvironmentValues]:
        """Return defaults without prompting.

        In non-interactive mode, all smart defaults are accepted as-is.

        Args:
            prompts: Flat list of value prompts.
            environments: Ordered list of selected environment names.
            layer_types: Ordered list of selected layer type names.

        Returns:
            One CollectedEnvironmentValues per environment with defaults.
        """
        result: dict[str, CollectedEnvironmentValues] = {}
        for env in environments:
            result[env] = CollectedEnvironmentValues(environment=env)

        for prompt in prompts:
            env = prompt.environment
            if env not in result:
                result[env] = CollectedEnvironmentValues(environment=env)
            values = result[env]
            if prompt.layer_type:
                if prompt.layer_type not in values.layer_templates:
                    values.layer_templates[prompt.layer_type] = {}
                values.layer_templates[prompt.layer_type][prompt.key] = prompt.default
            else:
                values.template_replacements[prompt.key] = prompt.default

        return list(result.values())
