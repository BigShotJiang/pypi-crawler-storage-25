"""Filesystem adapter for init service.

This module contains adapters implementing the InitFilesystem protocol.
"""

from __future__ import annotations

import shutil
from pathlib import Path


class InitFilesystemAdapter:
    """Filesystem adapter implementing InitFilesystem protocol.

    This adapter provides real filesystem operations for initialization:
    - Checking path existence
    - Creating directories
    - Writing files
    - Copying templates (files or directories)
    """

    def exists(self, path: Path) -> bool:
        """Check if a path exists.

        Args:
            path: Path to check.

        Returns:
            True if path exists, False otherwise.
        """
        return path.exists()

    def create_directory(self, path: Path) -> None:
        """Create a directory and any parent directories.

        This operation is idempotent - it will not fail if the directory
        already exists.

        Args:
            path: Directory path to create.
        """
        path.mkdir(parents=True, exist_ok=True)

    def write_file(self, path: Path, content: str) -> None:
        """Write content to a file.

        Creates parent directories if they don't exist.
        Overwrites existing files.

        Args:
            path: File path to write to.
            content: String content to write.
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)

    def copy_template(self, src: Path, dest: Path) -> None:
        """Copy a template file or directory to destination.

        Creates parent directories if they don't exist.
        Handles both files and directories (recursive copy).

        Args:
            src: Source template path.
            dest: Destination path.
        """
        dest.parent.mkdir(parents=True, exist_ok=True)

        if src.is_dir():
            shutil.copytree(src, dest)
        else:
            shutil.copy2(src, dest)
