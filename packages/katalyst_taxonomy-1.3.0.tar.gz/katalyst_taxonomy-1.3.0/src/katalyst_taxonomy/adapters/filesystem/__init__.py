"""Filesystem adapter for Katalyst taxonomy."""

from katalyst_taxonomy.adapters.filesystem.backend import FilesystemBackend
from katalyst_taxonomy.adapters.filesystem.discovery import (
    ByKindStrategy,
    CompositeDiscoveryStrategy,
    DiscoveryStrategy,
    RecursiveStrategy,
    SingleFileStrategy,
)
from katalyst_taxonomy.adapters.filesystem.ignore import TaxonomyIgnore, load_ignore
from katalyst_taxonomy.adapters.filesystem.lock import LOCK_FILE_PATH, LockFileRepository
from katalyst_taxonomy.adapters.filesystem.real import RealFilesystem
from katalyst_taxonomy.adapters.filesystem.writer import FilesystemWriter

# Backward compatibility alias
FilesystemTaxonomyRepository = FilesystemBackend

__all__ = [
    "ByKindStrategy",
    "CompositeDiscoveryStrategy",
    "LOCK_FILE_PATH",
    "DiscoveryStrategy",
    "FilesystemBackend",
    "FilesystemTaxonomyRepository",
    "FilesystemWriter",
    "LockFileRepository",
    "RealFilesystem",
    "RecursiveStrategy",
    "SingleFileStrategy",
    "TaxonomyIgnore",
    "load_ignore",
]
