"""Real filesystem adapter implementing FilesystemPort.

This adapter provides actual filesystem operations for production use.
It was moved out of ``ports/filesystem.py`` so that the port module
contains only the protocol (interface), following hexagonal architecture.
"""

from __future__ import annotations

import shutil
from collections.abc import Callable
from pathlib import Path
from typing import Mapping, Sequence

from katalyst_taxonomy.templates.rendering import render_tokens


class RealFilesystem:
    """Real filesystem adapter implementing FilesystemPort.

    This adapter provides actual filesystem operations for production use.
    """

    def exists(self, path: Path) -> bool:
        """Check if a path exists."""
        return path.exists()

    def is_directory(self, path: Path) -> bool:
        """Check if a path is a directory."""
        return path.is_dir()

    def read_file(self, path: Path) -> str:
        """Read content from a file."""
        return path.read_text()

    def write_file(self, path: Path, content: str) -> None:
        """Write content to a file, creating parent directories if needed."""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)

    def create_directory(self, path: Path) -> None:
        """Create a directory and any parent directories."""
        path.mkdir(parents=True, exist_ok=True)

    def copy_tree(self, src: Path, dest: Path) -> None:
        """Copy a directory tree, replacing destination if it exists."""
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(src, dest)

    def copy_tree_with_replacements(
        self,
        src: Path,
        dest: Path,
        replacements: list[tuple[str, str]],
    ) -> None:
        """Copy a directory tree with text replacements applied to paths and content."""
        self._walk_and_transform(
            src,
            dest,
            content_transform=lambda c: self._apply_replacements(c, replacements),
            path_transform=lambda p: self._apply_replacements(p, replacements),
        )

    def copy_tree_no_overwrite(
        self,
        src: Path,
        dest: Path,
    ) -> None:
        """Copy a directory tree, skipping files that already exist at the destination."""
        for src_path in src.rglob("*"):
            rel_path = src_path.relative_to(src)
            dest_path = dest / rel_path

            if src_path.is_dir():
                dest_path.mkdir(parents=True, exist_ok=True)
            elif not dest_path.exists():
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_path, dest_path)

    def remove_directory(self, path: Path) -> None:
        """Remove a directory and all its contents."""
        if path.exists():
            shutil.rmtree(path)

    def list_directory(self, path: Path) -> list[Path]:
        """List contents of a directory."""
        if not path.exists():
            return []
        return list(path.iterdir())

    def copy_file(self, src: Path, dest: Path) -> None:
        """Copy a single file verbatim (no rendering). Creates parent dirs."""
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)

    def copy_tree_rendered(
        self,
        src: Path,
        dest: Path,
        context: Mapping[str, str],
        *,
        skip_names: frozenset[str] = frozenset(),
        skip_root_file: str | None = None,
    ) -> None:
        """Copy *src* into *dest*, rendering ``{{ key }}`` tokens in file content."""

        def _should_skip(rel: Path) -> bool:
            if rel.parts and rel.parts[0] in skip_names:
                return True
            if skip_root_file and rel == Path(skip_root_file):
                return True
            return False

        self._walk_and_transform(
            src,
            dest,
            content_transform=lambda c: render_tokens(c, context),
            skip_fn=_should_skip,
        )

    def copy_tree_rendered_per_env(
        self,
        src: Path,
        dest: Path,
        context: Mapping[str, str],
        environments: Sequence[str],
    ) -> None:
        """Copy *src* once per environment under ``dest/<env_name>/``."""
        for env_name in environments:
            env_context = {**context, "environment": env_name}
            env_dir = dest / env_name
            self._walk_and_transform(
                src,
                env_dir,
                content_transform=lambda c, ctx=env_context: render_tokens(c, ctx),
            )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _apply_replacements(text: str, replacements: list[tuple[str, str]]) -> str:
        for old, new in replacements:
            text = text.replace(old, new)
        return text

    @staticmethod
    def _walk_and_transform(
        src: Path,
        dest: Path,
        *,
        content_transform: Callable[[str], str] | None = None,
        path_transform: Callable[[str], str] | None = None,
        skip_fn: Callable[[Path], bool] | None = None,
    ) -> None:
        """Walk a source tree, optionally transforming paths and content.

        Args:
            src: Source directory.
            dest: Destination directory.
            content_transform: Callable(str) -> str for file contents.
            path_transform: Callable(str) -> str for relative path strings.
            skip_fn: Callable(Path) -> bool to skip entries.
        """
        for src_path in src.rglob("*"):
            rel = src_path.relative_to(src)

            if skip_fn is not None and skip_fn(rel):
                continue

            rel_str = str(rel)
            if path_transform is not None:
                rel_str = path_transform(rel_str)

            dest_path = dest / rel_str

            if src_path.is_dir():
                dest_path.mkdir(parents=True, exist_ok=True)
            else:
                dest_path.parent.mkdir(parents=True, exist_ok=True)
                try:
                    content = src_path.read_text()
                    if content_transform is not None:
                        content = content_transform(content)
                    dest_path.write_text(content)
                except UnicodeDecodeError:
                    shutil.copy2(src_path, dest_path)
