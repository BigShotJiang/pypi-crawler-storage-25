"""Discovery strategies for finding taxonomy files (YAML and markdown)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, Sequence

#: File extensions recognised as taxonomy document sources.
TAXONOMY_EXTENSIONS: tuple[str, ...] = (".yaml", ".yml", ".md")

#: Filenames that mark a directory as a layer (sentinel files).
LAYER_FILENAMES: tuple[str, ...] = ("layer.yaml", "layer.yml", "layer.md")


class DiscoveryStrategy(Protocol):
    """Strategy for discovering taxonomy files within a filesystem layout."""

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        """Return the taxonomy file paths relative to the base directory."""
        ...


@dataclass(frozen=True, slots=True)
class SingleFileStrategy:
    """Treat the provided base path as a single file or directory with taxonomy files."""

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        if base_path.is_file():
            return (base_path,)

        if base_path.is_dir():
            candidates = tuple(
                path
                for path in base_path.iterdir()
                if path.is_file() and path.suffix.lower() in TAXONOMY_EXTENSIONS
            )
            if candidates:
                return tuple(sorted(candidates))

        for candidate in (
            base_path / "taxonomy.yaml",
            base_path / "taxonomy.yml",
            base_path / "taxonomy.md",
        ):
            if candidate.exists():
                return (candidate,)

        return ()


@dataclass(frozen=True, slots=True)
class RecursiveStrategy:
    """Search all taxonomy files recursively beneath the base path."""

    extensions: tuple[str, ...] = TAXONOMY_EXTENSIONS
    ignore_dirs: tuple[str, ...] = (
        ".git",
        ".venv",
        "node_modules",
        "__pycache__",
        ".tox",
        ".mypy_cache",
        ".ruff_cache",
        "charts",
        "templates",
        "tests",
        "layer_types",  # Katalyst layer type templates (contain Jinja2 placeholders)
    )

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        if not base_path.exists():
            return ()

        matched: list[Path] = []
        stack: list[Path] = [base_path]

        while stack:
            current = stack.pop()

            if current.is_dir():
                if current != base_path and current.name in self.ignore_dirs:
                    continue

                layer_document = find_layer_document(current)
                if layer_document is not None:
                    matched.append(layer_document)
                    continue

                try:
                    children = list(current.iterdir())
                except OSError:
                    continue

                for child in children:
                    stack.append(child)
                continue

            if current.is_file() and current.suffix.lower() in self.extensions:
                matched.append(current)

        return tuple(matched)


@dataclass(frozen=True, slots=True)
class ByKindStrategy:
    """Expect directories organised by taxonomy node type.

    Directory names are read from the v2 node type registry instead
    of being hardcoded, so new node types are automatically discovered.
    """

    extensions: tuple[str, ...] = TAXONOMY_EXTENSIONS

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        if not base_path.is_dir():
            return ()

        from katalyst_taxonomy.engine.bridge import get_default_registry

        registry = get_default_registry()
        paths: list[Path] = []
        for descriptor in registry.all_descriptors():
            directory = base_path / descriptor.directory_name
            if not directory.is_dir():
                continue
            for path in directory.iterdir():
                if path.is_file() and path.suffix.lower() in self.extensions:
                    paths.append(path)
        return tuple(paths)


@dataclass(frozen=True, slots=True)
class CompositeDiscoveryStrategy:
    """Combine multiple strategies, deduplicating discovered paths."""

    strategies: Sequence[DiscoveryStrategy]

    def discover(self, base_path: Path) -> tuple[Path, ...]:
        seen: set[Path] = set()
        discovered: list[Path] = []
        for strategy in self.strategies:
            for path in strategy.discover(base_path):
                absolute = path.resolve()
                if absolute not in seen:
                    seen.add(absolute)
                    discovered.append(path)
        return tuple(discovered)


def find_layer_document(directory: Path) -> Path | None:
    """Find layer document in a directory."""
    for candidate_name in LAYER_FILENAMES:
        candidate = directory / candidate_name
        if candidate.is_file():
            return candidate
    return None


# Backward-compatible alias
_find_layer_document = find_layer_document
