"""Shared parsing and serialisation utilities for filesystem adapters."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Sequence, cast

from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.parsing.frontmatter import serialize_frontmatter
from katalyst_taxonomy.taxonomy.environments import (
    API_VERSION as ENV_API_VERSION,
)
from katalyst_taxonomy.taxonomy.environments import (
    ENVIRONMENT_KIND,
    EnvironmentDocument,
)

# Re-export for backward compatibility
TaxonomyDocument = Document


def as_mapping(value: object) -> dict[str, Any]:
    """Convert a value to a string-keyed mapping.

    This utility is shared between the repository and lock file adapters
    to normalize raw YAML data into typed dictionaries.
    """
    if isinstance(value, Mapping):
        mapping_value = cast(Mapping[Any, Any], value)
        result: dict[str, Any] = {}
        for raw_key, raw_value in mapping_value.items():
            result[str(raw_key)] = raw_value
        return result
    return {}


def as_string_list(value: object) -> list[str]:
    """Convert a value to a list of strings.

    Used to normalize YAML sequences into typed string lists.
    """
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [str(item) for item in cast(Sequence[object], value) if item]
    return []


def document_from_mapping(
    mapping: Mapping[str, Any],
    *,
    source_path: Path,
    markdown_body: str | None = None,
) -> Document:
    """Convert a raw YAML mapping to a :class:`Document`.

    Handles both v1alpha and v2alpha formats via Document.from_dict().
    Markdown body is injected into spec as description override.
    """
    doc = Document.from_dict(mapping, source_path=source_path)

    # Inject markdown body into spec if present
    if markdown_body:
        spec = dict(doc.spec)
        spec["_markdown_body"] = markdown_body
        # Markdown body overrides front matter description when non-empty
        if markdown_body.strip():
            spec["description"] = markdown_body
        object.__setattr__(doc, "spec", spec)

    return doc


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------


def document_to_mapping(document: Document) -> dict[str, Any]:
    """Convert a :class:`Document` to a plain dict suitable for YAML output.

    The mapping excludes internal fields (``_markdown_body``, ``source_path``).
    Outputs in v2 format (kind is the node type directly).
    """
    result = document.to_dict()

    # Remove internal fields from spec
    spec = result.get("spec", {})
    spec.pop("_markdown_body", None)
    result["spec"] = spec

    return result


def serialize_taxonomy_markdown(document: Document) -> str:
    """Serialise a :class:`Document` as markdown with YAML front matter.

    The front matter contains the full taxonomy YAML mapping (minus any
    ``description`` that is better represented as the markdown body).
    When the document carries a ``markdown_body`` the body is used as-is;
    otherwise ``description`` is placed in the body and removed from
    the front matter so the document round-trips cleanly.
    """
    mapping = document_to_mapping(document)

    # Decide what goes into the markdown body vs the front matter.
    body = document.markdown_body or ""
    if not body and document.description:
        body = document.description

    # When the body *is* the description, remove it from the front matter
    # to avoid duplication.
    spec: dict[str, Any] = mapping.get("spec", {})
    if body and spec.get("description") == body:
        del spec["description"]

    return serialize_frontmatter(mapping, body)


def environment_to_mapping(document: EnvironmentDocument) -> dict[str, Any]:
    """Convert an :class:`EnvironmentDocument` to a plain dict suitable for YAML output."""
    spec_mapping: dict[str, Any] = {}
    if document.description is not None:
        spec_mapping["description"] = document.description
    if document.template_replacements:
        spec_mapping["templateReplacements"] = dict(document.template_replacements)
    if document.layer_templates:
        layer_templates: dict[str, Any] = {}
        for key, value in document.layer_templates.items():
            layer_templates[key] = dict(value)
        spec_mapping["layerTemplates"] = layer_templates

    return {
        "apiVersion": ENV_API_VERSION,
        "kind": ENVIRONMENT_KIND,
        "metadata": {"name": document.name},
        "spec": spec_mapping,
    }


def serialize_environment_markdown(document: EnvironmentDocument) -> str:
    """Serialise an :class:`EnvironmentDocument` as markdown with YAML front matter."""
    mapping = environment_to_mapping(document)

    body = document.markdown_body or ""
    if not body and document.description:
        body = document.description

    spec: dict[str, Any] = mapping.get("spec", {})
    if body and spec.get("description") == body:
        del spec["description"]

    return serialize_frontmatter(mapping, body)
