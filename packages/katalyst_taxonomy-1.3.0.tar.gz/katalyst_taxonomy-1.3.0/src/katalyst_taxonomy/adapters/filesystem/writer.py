"""Filesystem writer for taxonomy nodes."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Sequence, cast

import yaml

from katalyst_taxonomy.adapters.filesystem._parsing import serialize_taxonomy_markdown
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.parsing.frontmatter import serialize_frontmatter
from katalyst_taxonomy.templates.rendering import render_tokens


def _get_node_type_files() -> dict[str, str]:
    """Build the node_type→filename mapping from the registry."""
    from katalyst_taxonomy.engine.bridge import get_default_registry

    registry = get_default_registry()
    result: dict[str, str] = {}
    for desc in registry.all_descriptors():
        if not desc.is_extension:
            result[desc.kind] = f"{desc.kind}.yaml"
    return result


# Lazily populated
_node_type_files_cache: dict[str, str] | None = None


def get_node_type_files() -> dict[str, str]:
    """Get the node_type→filename mapping (lazy-loaded from registry)."""
    global _node_type_files_cache
    if _node_type_files_cache is None:
        _node_type_files_cache = _get_node_type_files()
    return _node_type_files_cache


# Backward-compatible alias (empty — callers should use get_node_type_files()).
NODE_TYPE_FILES: dict[str, str] = {}

# Default templates embedded in the adapter
DEFAULT_TEMPLATES: dict[str, str] = {
    "system": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: system
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    layout: root
    templateVersion: "{{ template_version }}"
  environments:
{{ environments_block }}
  dependsOn:
    nodes: []
""",
    "stack": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: stack
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    layout: root
    templateVersion: "{{ template_version }}"
  parents:
    node: "{{ parent_system }}"
  environments:
{{ environments_block }}
  dependsOn:
    nodes:
      - "{{ parent_system }}"
""",
    "layer": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: layer
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    layout: root
    layerType: "{{ layer_type }}"
    templateVersion: "{{ template_version }}"
    layerTypeVersion: "{{ layer_type_version }}"
  parents:
    node: "{{ parent_stack }}"
  environments:
{{ environments_block }}
  dependsOn:
    nodes:
      - "{{ parent_stack }}"
  extensions: {}
""",
    "organization": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: organization
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    templateVersion: "{{ template_version }}"
  environments:
{{ environments_block }}
""",
    "program": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: program
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    templateVersion: "{{ template_version }}"
  parents:
    node: "{{ parent }}"
  environments:
{{ environments_block }}
""",
    "project": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: project
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    templateVersion: "{{ template_version }}"
  parents:
    node: "{{ parent }}"
  environments:
{{ environments_block }}
  project:
    status: active
""",
    "team": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: team
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    templateVersion: "{{ template_version }}"
  parents:
    node: "{{ parent }}"
  environments:
{{ environments_block }}
  team:
    unitType: squad
""",
    "team_member": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: team_member
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    templateVersion: "{{ template_version }}"
  parents:
    node: "{{ parent }}"
  environments:
{{ environments_block }}
  teamMember:
    role: engineer
    email: "{{ primary_owner }}"
""",
    "library": """\
apiVersion: katalyst.taxonomy/v1alpha
kind: TaxonomyNode
metadata:
  name: "{{ name }}"
taxonomyNodeType: library
spec:
  description: "{{ description }}"
  owners:
    - "{{ primary_owner }}"
  annotations:
    templateVersion: "{{ template_version }}"
  environments:
{{ environments_block }}
""",
}


class FilesystemWriter:
    """Adapter for writing taxonomy nodes to the filesystem.

    Implements the TaxonomyWriter protocol from katalyst-core.
    """

    def __init__(
        self,
        template_dir: Path | None = None,
        output_format: str = "yaml",
    ) -> None:
        """Initialize the writer.

        Args:
            template_dir: Optional directory containing custom templates.
                If not provided, uses built-in default templates.
            output_format: File format for created nodes ("yaml" or "markdown").
                When "markdown", nodes are written as ``.md`` files with YAML
                front matter and the description as the markdown body.
        """
        self._template_dir = template_dir
        self._output_format = output_format

    def write_document(
        self,
        document: Document,
        path: Path,
        *,
        output_format: str = "yaml",
    ) -> None:
        """Write a taxonomy document to the specified path.

        When *output_format* is ``"markdown"`` (or when *path* ends with
        ``.md``), the document is serialised as markdown with YAML front
        matter.  Otherwise a plain YAML file is emitted.
        """
        path.parent.mkdir(parents=True, exist_ok=True)

        use_markdown = output_format == "markdown" or path.suffix.lower() == ".md"
        if use_markdown:
            path.write_text(serialize_taxonomy_markdown(document), encoding="utf-8")
            return

        # --- Default: plain YAML output ---
        spec: dict[str, Any] = {
            "description": document.description or "",
            "owners": list(document.owners) if document.owners else [],
            "environments": (list(document.environments) if document.environments else []),
        }

        # Add optional spec fields
        if document.parent is not None:
            spec["parents"] = {"node": document.parent}
        if document.annotations_map:
            spec["annotations"] = dict(document.annotations_map)
        if document.depends_on_nodes:
            spec["dependsOn"] = {"nodes": list(document.depends_on_nodes or [])}

        data: dict[str, Any] = {
            "apiVersion": document.api_version,
            "kind": document.kind,
            "metadata": {"name": document.metadata.name},
            "taxonomyNodeType": document.taxonomy_node_type,
            "spec": spec,
        }

        with path.open("w", encoding="utf-8") as f:
            yaml.safe_dump(data, f, sort_keys=False)

    def create_node(
        self,
        path: Path,
        node_type: str,
        name: str,
        **kwargs: object,
    ) -> Path:
        """Create a new taxonomy node from a template.

        Args:
            path: Base path for the taxonomy (repo root).
            node_type: Type of node (system, stack, layer).
            name: Name of the node.
            **kwargs: Additional fields (description, owners, environments,
                parent, parent_system, layer_type).

        Returns:
            Path to the created file.

        Raises:
            FileExistsError: If the target file already exists.
            ValueError: If the node_type is invalid.
        """
        if node_type not in get_node_type_files():
            raise ValueError(f"Invalid node type: {node_type}")

        # Determine the target directory and file
        # If target_dir is provided via kwargs, use it as an override
        target_dir_override = kwargs.pop("target_dir", None)
        if target_dir_override:
            target_dir = path / str(target_dir_override)
        else:
            target_dir = self._compute_target_dir(path, node_type, name, kwargs)

        node_files = get_node_type_files()
        if self._output_format == "markdown":
            target_file = target_dir / node_files[node_type].replace(".yaml", ".md")
        else:
            target_file = target_dir / node_files[node_type]

        if target_file.exists():
            raise FileExistsError(f"Node already exists at: {target_file}")

        # Build the context for template rendering
        kwargs["path"] = path  # Make base path available for version resolution
        context = self._build_context(name, node_type, kwargs)

        # Get and render the template
        template = self._get_template(node_type)
        rendered = render_tokens(template, context)

        # For library nodes with a parent, inject the parents block into the spec
        if node_type == "library" and "parent" in context:
            parent_block = f'  parents:\n    node: "{context["parent"]}"\n'
            rendered = rendered.replace(
                "  environments:",
                f"{parent_block}  environments:",
            )

        # Write the file
        target_dir.mkdir(parents=True, exist_ok=True)

        if self._output_format == "markdown":
            self._write_as_markdown(target_file, rendered)
        else:
            target_file.write_text(rendered, encoding="utf-8")

        return target_file

    def _compute_target_dir(
        self,
        base_path: Path,
        node_type: str,
        name: str,
        kwargs: dict[str, object],
    ) -> Path:
        """Compute the target directory for a node.

        Uses registry metadata to determine directory structure:
        - Root types (is_root=True, no parent_required): placed at base_path
        - Types with a parent: placed under parent's directory / name
        - Technical hierarchy: uses the specific parent refs (system/stack)

        Falls back to hardcoded logic for the well-known technical hierarchy
        (system→stack→layer) which has deeper nesting semantics.
        """
        try:
            from katalyst_taxonomy.engine.bridge import get_default_registry

            registry = get_default_registry()
            desc = registry.get(node_type)

            if desc and desc.is_root and not desc.parent_required:
                return base_path
        except Exception:
            pass

        # Technical hierarchy — deep nesting based on parent chain
        if node_type == "system":
            # Systems can nest: parent_system means nested system
            parent_system = kwargs.get("parent_system") or kwargs.get("parent")
            if parent_system:
                return base_path / str(parent_system) / name
            return base_path / name

        if node_type == "stack":
            parent_system = kwargs.get("parent_system") or kwargs.get("parent")
            if parent_system:
                return base_path / str(parent_system) / name
            return base_path / name

        if node_type == "layer":
            parent_system = kwargs.get("parent_system")
            parent_stack = kwargs.get("parent")
            if parent_system and parent_stack:
                return base_path / str(parent_system) / str(parent_stack) / name
            if parent_stack:
                return base_path / str(parent_stack) / name
            return base_path / name

        # Generic: types with a parent go under parent_name/name
        parent = kwargs.get("parent")
        if parent:
            return base_path / str(parent) / name

        return base_path / name

    def _build_context(
        self,
        name: str,
        node_type: str,
        kwargs: dict[str, object],
    ) -> dict[str, str]:
        """Build the template context from creation parameters.

        Uses registry metadata to determine which parent references
        to include, falling back to hardcoded logic for the technical
        hierarchy (system nesting, stack→parent_system, etc.).
        """
        # Extract values from kwargs
        description = kwargs.get("description")
        owners = kwargs.get("owners", ())
        environments = kwargs.get("environments", ())
        parent = kwargs.get("parent")
        parent_system = kwargs.get("parent_system")
        layer_type = kwargs.get("layer_type")

        # Determine primary values
        if isinstance(owners, (list, tuple)) and owners:
            owners_seq = cast(Sequence[object], owners)
            primary_owner = str(owners_seq[0])
        else:
            primary_owner = "team@example.com"

        if isinstance(environments, (list, tuple)) and environments:
            envs_seq = cast(Sequence[object], environments)
            primary_environment = str(envs_seq[0])
            # Build YAML block for all environments
            environments_block = "\n".join(f'    - "{env}"' for env in envs_seq)
        else:
            primary_environment = "dev"
            environments_block = '    - "dev"'

        context: dict[str, str] = {
            "name": name,
            "description": str(description) if description else f"{node_type.title()} {name}",
            "primary_owner": primary_owner,
            "primary_environment": primary_environment,
            "environments_block": environments_block,
        }

        # Resolve version stamping from the lock file
        template_version, layer_type_ver = self._resolve_versions(
            kwargs.get("path"),
            str(layer_type) if layer_type else None,
        )
        context["template_version"] = template_version
        context["layer_type_version"] = layer_type_ver

        # Add parent references — technical hierarchy has specific parent ref names
        if node_type == "system":
            # Nested system: parent is another system
            if parent or parent_system:
                context["parent_system"] = str(parent or parent_system or "")

        elif node_type == "stack":
            context["parent_system"] = str(parent or parent_system or "")
            if parent_system:
                context["parent_system"] = str(parent_system)

        elif node_type == "layer":
            context["parent_stack"] = str(parent or "")
            context["layer_type"] = str(layer_type) if layer_type else "app-docker"
            if parent_system:
                context["parent_system"] = str(parent_system)

        else:
            # Generic: use registry to determine if this type needs a parent
            try:
                from katalyst_taxonomy.engine.bridge import get_default_registry

                registry = get_default_registry()
                desc = registry.get(node_type)
                if desc and desc.parent_types and parent:
                    context["parent"] = str(parent)
            except Exception:
                # Fallback: known types that use generic parent
                if node_type in ("program", "project", "team", "team_member") and parent:
                    context["parent"] = str(parent)
                elif node_type == "library" and parent:
                    context["parent"] = str(parent)

        return context

    def _resolve_versions(
        self,
        base_path: object,
        layer_type: str | None,
    ) -> tuple[str, str]:
        """Resolve template version and layer type version from the lock file.

        Args:
            base_path: The base taxonomy path (may be a Path or None).
            layer_type: The layer type name (for layer nodes).

        Returns:
            Tuple of (template_version, layer_type_version).
        """
        default_version = "0.1.0"
        template_version = default_version
        layer_type_version = default_version

        if not isinstance(base_path, Path) or not base_path:
            return template_version, layer_type_version

        try:
            from katalyst_taxonomy.adapters.filesystem.lock import LockFileRepository

            lock_repo = LockFileRepository(base_path=base_path)
            lock = lock_repo.load()
            if lock is None:
                return template_version, layer_type_version

            # Template version from core
            template_version = lock.installed.core.version

            # Layer type version from lock itemVersions
            if layer_type:
                lt_plugin = lock.get_plugin("layer_types")
                if lt_plugin is not None:
                    iv = lt_plugin.get_item_version(layer_type)
                    if iv:
                        layer_type_version = iv

        except Exception:  # noqa: BLE001 - best-effort
            pass

        return template_version, layer_type_version

    def _get_template(self, node_type: str) -> str:
        """Get the template content for a node type.

        Resolution order:
        1. Custom template from template_dir
        2. Built-in DEFAULT_TEMPLATES (v1 format, covers core types)
        3. Auto-generated generic template from registry metadata (for new types)
        """
        # If a template directory is configured, try to load from there
        if self._template_dir:
            template_file = self._template_dir / f"{node_type}.yaml"
            if template_file.exists():
                return template_file.read_text(encoding="utf-8")

        # Fall back to default embedded templates
        if node_type in DEFAULT_TEMPLATES:
            return DEFAULT_TEMPLATES[node_type]

        # Auto-generate a generic template for any registered type
        return self._generate_generic_template(node_type)

    @staticmethod
    def _generate_generic_template(node_type: str) -> str:
        """Generate a generic YAML template for any registered node type.

        This allows creating nodes of new types without adding
        a hand-written template for each one.
        """
        try:
            from katalyst_taxonomy.engine.bridge import get_default_registry

            registry = get_default_registry()
            desc = registry.get(node_type)
            if desc is None:
                raise ValueError(f"No template found for node type: {node_type}")
        except ImportError as exc:
            raise ValueError(f"No template found for node type: {node_type}") from exc

        lines = [
            "apiVersion: katalyst.taxonomy/v1alpha",
            "kind: TaxonomyNode",
            "metadata:",
            '  name: "{{ name }}"',
            f"taxonomyNodeType: {node_type}",
            "spec:",
            '  description: "{{ description }}"',
            "  owners:",
            '    - "{{ primary_owner }}"',
            "  annotations:",
            '    templateVersion: "{{ template_version }}"',
        ]

        # Add parents block if the type has parent_types
        if desc.parent_required:
            lines.extend(
                [
                    "  parents:",
                    '    node: "{{ parent }}"',
                ]
            )

        lines.extend(
            [
                "  environments:",
                "{{ environments_block }}",
            ]
        )

        return "\n".join(lines) + "\n"

    @staticmethod
    def _write_as_markdown(target_file: Path, rendered_yaml: str) -> None:
        """Convert rendered YAML content to markdown with YAML frontmatter.

        Parses the rendered template YAML, extracts the ``description`` from
        ``spec`` to use as the markdown body, and writes the result as a
        ``.md`` file with YAML front matter.
        """
        raw = yaml.safe_load(rendered_yaml)
        if not isinstance(raw, dict):
            # Fallback: write as-is if template isn't valid YAML
            target_file.write_text(rendered_yaml, encoding="utf-8")
            return

        data: dict[str, Any] = cast(dict[str, Any], raw)

        # Extract description from spec to use as the markdown body
        spec: dict[str, Any] = cast(dict[str, Any], data.get("spec", {}))
        body = ""
        if spec.get("description"):
            body = str(spec["description"])
            del spec["description"]

        target_file.write_text(serialize_frontmatter(data, body), encoding="utf-8")
