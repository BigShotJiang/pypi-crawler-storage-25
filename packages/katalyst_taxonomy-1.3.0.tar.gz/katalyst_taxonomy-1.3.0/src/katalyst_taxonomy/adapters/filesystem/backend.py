"""Filesystem-backed taxonomy backend — unified read/write implementation."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.ports.backend import SaveResult, SyncResult
from katalyst_taxonomy.taxonomy.environments import EnvironmentDocument

from ._document_parsing import parse_documents
from .discovery import DiscoveryStrategy, RecursiveStrategy
from .ignore import IGNOREFILE_NAME, load_ignore
from .writer import FilesystemWriter


def _document_error_list() -> list[DocumentError]:
    return []


def _environment_document_list() -> list[EnvironmentDocument]:
    return []


@dataclass
class FilesystemBackend:
    """Filesystem-backed taxonomy backend implementing ``TaxonomyBackend``.

    Configuration (base path) is injected at construction time.
    All read/write operations work against the configured path.
    """

    base_path: Path
    strategy: DiscoveryStrategy = field(default_factory=RecursiveStrategy)

    _writer: FilesystemWriter = field(init=False, repr=False, default_factory=FilesystemWriter)
    _documents: tuple[Document, ...] | None = field(init=False, repr=False, default=None)
    _environment_documents: list[EnvironmentDocument] = field(
        init=False,
        repr=False,
        default_factory=_environment_document_list,
    )
    _errors: list[DocumentError] = field(
        init=False,
        repr=False,
        default_factory=_document_error_list,
    )

    @property
    def name(self) -> str:
        return "filesystem"

    # ------------------------------------------------------------------
    # Internal loading
    # ------------------------------------------------------------------

    def _load_all(self) -> tuple[Document, ...]:
        """Load all documents from the filesystem."""
        base = self.base_path
        if not base.exists():
            raise FileNotFoundError(f"Taxonomy path does not exist: {base}")

        documents: list[Document] = []
        self._errors = []
        self._environment_documents = []

        layer_directories: set[Path] = set()
        candidates = [path for path in self.strategy.discover(base) if path.name != IGNOREFILE_NAME]
        candidates.sort(key=lambda p: (len(p.parts), str(p)))

        ignore = load_ignore(base)

        for path in candidates:
            if any(
                layer_dir in path.parents and path.parent != layer_dir
                for layer_dir in layer_directories
            ):
                continue

            if ignore and ignore.should_ignore(path, is_dir=path.is_dir()):
                continue

            parsed = parse_documents(
                path,
                environment_documents=self._environment_documents,
                errors=self._errors,
            )
            documents.extend(parsed)

            if any(doc.taxonomy_node_type == "layer" for doc in parsed):
                layer_directories.add(path.parent)

        return tuple(documents)

    def _ensure_loaded(self) -> None:
        """Ensure documents are loaded (lazy init)."""
        if self._documents is None:
            self._documents = self._load_all()

    # ------------------------------------------------------------------
    # Read operations (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def load_documents(self) -> tuple[Document, ...]:
        """Load all taxonomy documents."""
        self._documents = self._load_all()
        return self._documents

    def load_environments(self) -> tuple[EnvironmentDocument, ...]:
        """Load all environment documents."""
        self._ensure_loaded()
        return tuple(self._environment_documents)

    def get_document(self, name: str) -> Document | None:
        """Get a single document by name."""
        self._ensure_loaded()
        if self._documents is None:
            return None
        return next((doc for doc in self._documents if doc.metadata.name == name), None)

    # ------------------------------------------------------------------
    # Write operations (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def create_node(
        self,
        node_type: str,
        name: str,
        **kwargs: object,
    ) -> SaveResult:
        """Create a new taxonomy node.

        Delegates to the internal ``FilesystemWriter`` for template
        rendering and file creation.
        """
        try:
            created_path = self._writer.create_node(self.base_path, node_type, name, **kwargs)
            # Invalidate cached documents so next read picks up the new node
            self._documents = None
            return SaveResult(success=True, created=True, path=created_path)
        except (FileExistsError, ValueError) as exc:
            return SaveResult(success=False, error=str(exc))

    # ------------------------------------------------------------------
    # Sync operations (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def sync_from(
        self,
        source: object,
        *,
        full: bool = False,
    ) -> SyncResult:
        """Sync data from another backend.

        For the filesystem backend, syncing means writing YAML files
        from the source's documents.  Not yet implemented.
        """
        raise NotImplementedError("Filesystem sync_from is not yet implemented")

    # ------------------------------------------------------------------
    # Lifecycle (TaxonomyBackend protocol)
    # ------------------------------------------------------------------

    def health_check(self) -> bool:
        """Check if the base path exists and is readable."""
        return self.base_path.exists() and self.base_path.is_dir()

    def close(self) -> None:
        """No-op for filesystem backend."""
        pass

    def errors(self) -> tuple[DocumentError, ...]:
        """Return errors from the last load operation."""
        return tuple(self._errors)

    # ------------------------------------------------------------------
    # Backward compatibility: TaxonomyRepository protocol methods
    # These accept (and ignore) a path parameter so existing code
    # continues to work during the migration period.
    # ------------------------------------------------------------------

    def load_documents_compat(self, path: Path) -> tuple[Document, ...]:
        """Backward-compatible load_documents that accepts a path parameter."""
        self.base_path = path
        return self.load_documents()

    def load_environments_compat(self, path: Path) -> tuple[EnvironmentDocument, ...]:
        """Backward-compatible load_environments that accepts a path parameter."""
        if self._documents is None:
            self.load_documents_compat(path)
        return tuple(self._environment_documents)

    def get_document_compat(self, path: Path, name: str) -> Document | None:
        """Backward-compatible get_document that accepts a path parameter."""
        if self._documents is None:
            self.load_documents_compat(path)
        return self.get_document(name)
