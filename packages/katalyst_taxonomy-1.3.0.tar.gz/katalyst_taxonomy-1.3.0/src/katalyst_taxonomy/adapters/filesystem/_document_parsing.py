"""Shared document-parsing helpers for filesystem-backed loaders.

This module delegates to ``engine.parsing`` for the canonical v2 parser.
It exists as a thin compatibility layer so existing callers don't need
to change their import paths.

Supports both v1alpha and v2alpha document formats transparently.
"""

from __future__ import annotations

from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.parsing import (
    parse_documents,
    parse_markdown_document,
    parse_yaml_documents,
)

# Re-export Document as TaxonomyDocument for backward compat
TaxonomyDocument = Document

__all__ = [
    "Document",
    "TaxonomyDocument",
    "parse_documents",
    "parse_markdown_document",
    "parse_yaml_documents",
]
