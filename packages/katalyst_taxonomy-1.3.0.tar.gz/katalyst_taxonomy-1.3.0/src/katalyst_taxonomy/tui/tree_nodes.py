"""Data structures for taxonomy tree representation in the TUI."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from katalyst_taxonomy.engine.document import Document


def get_kind_order() -> tuple[str, ...]:
    """Get the kind ordering from the v2 registry."""
    try:
        from katalyst_taxonomy.engine.bridge import get_default_registry

        return get_default_registry().sorted_kinds()
    except Exception:
        return ()


# Backward-compatible alias (empty — callers should use get_kind_order()).
KIND_ORDER: tuple[str, ...] = ()


@dataclass(frozen=True)
class TreeNode:
    """Represents a node within the taxonomy tree view."""

    label: str
    node_type: str
    document: Document | None
    extra: Mapping[str, object]
    children: tuple[TreeNode, ...] = ()


@dataclass(frozen=True)
class NodeView(TreeNode):
    """Specialised tree node that always references a document."""

    document: Document  # type: ignore[assignment]
    children: tuple[NodeView, ...] = ()
