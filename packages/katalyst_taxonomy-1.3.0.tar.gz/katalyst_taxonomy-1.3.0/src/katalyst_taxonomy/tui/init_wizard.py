"""Init wizard for guiding users through taxonomy initialization."""

# pyright: reportUnknownMemberType=false

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path

from textual import on
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Button, Checkbox, Input, Label, Static

from katalyst_taxonomy.services.init import (
    AVAILABLE_LAYER_TYPES,
    AVAILABLE_PLUGINS,
)

# Default environments to pre-populate (users can add/remove freely)
DEFAULT_ENVIRONMENTS = ("dev", "staging", "prod")

# Default environment descriptions
DEFAULT_ENV_DESCRIPTIONS: dict[str, str] = {
    "dev": "Development environment",
    "staging": "Pre-production staging environment",
    "prod": "Production environment",
}


class WizardStep(Enum):
    """Steps in the init wizard."""

    WELCOME = auto()
    ENVIRONMENTS = auto()
    PLUGINS = auto()
    LAYER_TYPES = auto()
    SYSTEM = auto()
    SUMMARY = auto()


@dataclass
class WizardState:
    """Holds the current state of the wizard."""

    environments: list[str] = field(default_factory=lambda: list[str]())
    environment_descriptions: dict[str, str] = field(default_factory=lambda: dict[str, str]())
    plugins: dict[str, bool] = field(default_factory=lambda: dict[str, bool]())
    layer_types: dict[str, bool] = field(default_factory=lambda: dict[str, bool]())
    template_source: str = "bundled"  # "bundled" or "github" (future)
    system_name: str = ""
    system_description: str = ""
    system_owner: str = ""
    # Optional stack to create under the system
    stack_name: str = ""
    stack_description: str = ""

    def __post_init__(self) -> None:
        # Initialize with defaults if empty
        if not self.environments:
            self.environments = list(DEFAULT_ENVIRONMENTS)
            self.environment_descriptions = dict(DEFAULT_ENV_DESCRIPTIONS)
        if not self.plugins:
            self.plugins = dict.fromkeys(AVAILABLE_PLUGINS, True)
        if not self.layer_types:
            for plugin_types in AVAILABLE_LAYER_TYPES.values():
                for lt_name in plugin_types:
                    self.layer_types[lt_name] = True

    @property
    def selected_environments(self) -> tuple[str, ...]:
        return tuple(self.environments)

    @property
    def selected_environment_descriptions(self) -> dict[str, str]:
        """Return descriptions for selected environments."""
        return {env: self.environment_descriptions.get(env, "") for env in self.environments}

    @property
    def selected_plugins(self) -> tuple[str, ...]:
        return tuple(name for name, selected in self.plugins.items() if selected)

    @property
    def selected_layer_types(self) -> tuple[str, ...]:
        return tuple(name for name, selected in self.layer_types.items() if selected)

    def add_environment(self, name: str, description: str = "") -> bool:
        """Add an environment. Returns True if added, False if already exists."""
        normalized = name.strip().lower()
        if not normalized:
            return False
        if normalized in self.environments:
            return False
        self.environments.append(normalized)
        self.environment_descriptions[normalized] = description
        return True

    def remove_environment(self, name: str) -> bool:
        """Remove an environment. Returns True if removed."""
        if name in self.environments:
            self.environments.remove(name)
            self.environment_descriptions.pop(name, None)
            return True
        return False

    def set_environment_description(self, name: str, description: str) -> bool:
        """Set the description for an environment. Returns True if successful."""
        if name in self.environments:
            self.environment_descriptions[name] = description
            return True
        return False


@dataclass
class InitWizardResult:
    """Result from the init wizard."""

    cancelled: bool = False
    environments: tuple[str, ...] = ()
    environment_descriptions: dict[str, str] = field(default_factory=lambda: dict[str, str]())
    plugins: tuple[str, ...] = ()
    layer_types: tuple[str, ...] = ()
    template_source: str = "bundled"
    system_name: str = ""
    system_description: str = ""
    system_owner: str = ""
    # Optional stack
    stack_name: str = ""
    stack_description: str = ""


class InitWizard(ModalScreen[InitWizardResult]):
    """Multi-step wizard for initializing a taxonomy repository."""

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
    ]

    def __init__(self, *, path: Path) -> None:
        super().__init__()
        self._path = path
        self._step = WizardStep.WELCOME
        self._state = WizardState()

    def compose(self) -> ComposeResult:
        with Vertical(id="init-wizard"):
            yield Static("Initialize Taxonomy", id="wizard-title")
            yield Static("", id="wizard-step-indicator")
            with VerticalScroll(id="wizard-content"):
                yield Static("", id="wizard-body")
            with Horizontal(id="wizard-actions"):
                yield Button("Cancel", id="wizard-cancel", variant="default")
                yield Button("Back", id="wizard-back", variant="default")
                yield Button("Next", id="wizard-next", variant="primary")

    async def on_mount(self) -> None:
        self._render_step()

    def action_cancel(self) -> None:
        self.dismiss(InitWizardResult(cancelled=True))

    @on(Button.Pressed, "#wizard-cancel")
    def _handle_cancel(self) -> None:
        self.action_cancel()

    @on(Button.Pressed, "#wizard-back")
    def _handle_back(self) -> None:
        self._go_back()

    @on(Button.Pressed, "#wizard-next")
    def _handle_next(self) -> None:
        self._go_next()

    def _go_back(self) -> None:
        steps = list(WizardStep)
        current_idx = steps.index(self._step)
        if current_idx > 0:
            self._step = steps[current_idx - 1]
            self._render_step()

    def _go_next(self) -> None:
        # Validate current step
        if not self._validate_step():
            return

        # Save current step state
        self._save_step_state()

        steps = list(WizardStep)
        current_idx = steps.index(self._step)
        if current_idx < len(steps) - 1:
            self._step = steps[current_idx + 1]
            self._render_step()
        else:
            # Last step - finish wizard
            self._finish()

    def _validate_step(self) -> bool:
        """Validate the current step. Returns True if valid."""
        if self._step == WizardStep.ENVIRONMENTS:
            if not self._state.environments:
                self.app.notify("Add at least one environment.", severity="error")
                return False
        elif self._step == WizardStep.SYSTEM:
            name_input = self.query_one("#system-name", Input)
            name = name_input.value.strip()
            validation_error = self._validate_system_name(name)
            if validation_error:
                self.app.notify(validation_error, severity="error")
                return False
        return True

    def _validate_system_name(self, name: str) -> str | None:
        """Validate system name and return error message if invalid."""
        if not name:
            return "System name is required."

        # Check minimum length
        if len(name) < 2:
            return "System name must be at least 2 characters."

        # Check maximum length
        if len(name) > 64:
            return "System name must be at most 64 characters."

        # Check for valid characters (alphanumeric, hyphens, underscores)
        if not all(c.isalnum() or c in "-_" for c in name):
            return "System name can only contain letters, numbers, hyphens, and underscores."

        # Check that it doesn't start with a number
        if name[0].isdigit():
            return "System name cannot start with a number."

        # Check that it doesn't start or end with a hyphen/underscore
        if name[0] in "-_" or name[-1] in "-_":
            return "System name cannot start or end with a hyphen or underscore."

        # Recommend lowercase (but don't enforce it)
        if name != name.lower():
            # Auto-convert to lowercase - update the input
            name_input = self.query_one("#system-name", Input)
            name_input.value = name.lower()
            self.app.notify("System name converted to lowercase.", severity="information")

        return None

    def _save_step_state(self) -> None:
        """Save the current step's input state."""
        if self._step == WizardStep.ENVIRONMENTS:
            # Environments are saved immediately via add/remove buttons
            pass
        elif self._step == WizardStep.PLUGINS:
            for name in self._state.plugins:
                try:
                    checkbox = self.query_one(f"#plugin-{name}", Checkbox)
                    self._state.plugins[name] = checkbox.value
                except Exception:
                    pass
        elif self._step == WizardStep.LAYER_TYPES:
            for name in self._state.layer_types:
                try:
                    checkbox = self.query_one(f"#lt-{name}", Checkbox)
                    self._state.layer_types[name] = checkbox.value
                except Exception:
                    pass
        elif self._step == WizardStep.SYSTEM:
            try:
                self._state.system_name = self.query_one("#system-name", Input).value.strip()
                self._state.system_description = self.query_one(
                    "#system-description",
                    Input,
                ).value.strip()
                self._state.system_owner = self.query_one("#system-owner", Input).value.strip()
                # Optional stack
                self._state.stack_name = self.query_one("#stack-name", Input).value.strip()
                self._state.stack_description = self.query_one(
                    "#stack-description",
                    Input,
                ).value.strip()
            except Exception:
                pass

    def _finish(self) -> None:
        """Complete the wizard and return the result."""
        result = InitWizardResult(
            cancelled=False,
            environments=self._state.selected_environments,
            environment_descriptions=self._state.selected_environment_descriptions,
            plugins=self._state.selected_plugins,
            layer_types=self._state.selected_layer_types,
            template_source=self._state.template_source,
            system_name=self._state.system_name,
            system_description=self._state.system_description,
            system_owner=self._state.system_owner or "team@example.com",
            stack_name=self._state.stack_name,
            stack_description=self._state.stack_description,
        )
        self.dismiss(result)

    def _render_step(self) -> None:
        """Render the current step."""
        # Update step indicator
        steps = list(WizardStep)
        step_names = ["Welcome", "Environments", "Plugins", "Layer Types", "System", "Summary"]
        current_idx = steps.index(self._step)
        indicator_parts: list[str] = []
        for i, name in enumerate(step_names):
            if i == current_idx:
                indicator_parts.append(f"[bold cyan]{name}[/bold cyan]")
            elif i < current_idx:
                indicator_parts.append(f"[green]{name}[/green]")
            else:
                indicator_parts.append(f"[dim]{name}[/dim]")
        self.query_one("#wizard-step-indicator", Static).update(" > ".join(indicator_parts))

        # Update button states
        back_btn = self.query_one("#wizard-back", Button)
        next_btn = self.query_one("#wizard-next", Button)

        back_btn.disabled = self._step == WizardStep.WELCOME
        if self._step == WizardStep.SUMMARY:
            next_btn.label = "Initialize"
            next_btn.variant = "success"
        else:
            next_btn.label = "Next"
            next_btn.variant = "primary"

        # Render content
        content = self.query_one("#wizard-content", VerticalScroll)
        content.remove_children()

        if self._step == WizardStep.WELCOME:
            self._render_welcome(content)
        elif self._step == WizardStep.ENVIRONMENTS:
            self._render_environments(content)
        elif self._step == WizardStep.PLUGINS:
            self._render_plugins(content)
        elif self._step == WizardStep.LAYER_TYPES:
            self._render_layer_types(content)
        elif self._step == WizardStep.SYSTEM:
            self._render_system(content)
        elif self._step == WizardStep.SUMMARY:
            self._render_summary(content)

    def _render_welcome(self, container: VerticalScroll) -> None:
        """Render the welcome step."""
        container.mount(
            Static(
                f"[bold]Welcome to Katalyst Taxonomy Setup[/bold]\n\n"
                f"This wizard will help you initialize a new taxonomy repository at:\n"
                f"[cyan]{self._path}[/cyan]\n\n"
                f"You will configure:\n"
                f"  1. [bold]Environments[/bold] - Define your deployment environments\n"
                f"  2. [bold]Plugins[/bold] - Layer type templates\n"
                f"  3. [bold]Layer Types[/bold] - app-docker, k8s-argocd, etc.\n"
                f"  4. [bold]Initial System[/bold] - Your first taxonomy system\n\n"
                f"Press [bold]Next[/bold] to begin.",
                id="welcome-text",
            ),
        )

    def _render_environments(self, container: VerticalScroll) -> None:
        """Render the environment definition step."""
        container.mount(
            Static(
                "[bold]Define Environments[/bold]\n\n"
                "Add the environments for your taxonomy. Common examples: dev, staging, "
                "prod, qa, uat, sandbox.\n",
                id="env-intro",
            ),
        )

        # Add environment input row - compose children first
        add_row = Horizontal(classes="env-add-row")
        env_input = Input(
            placeholder="Environment name (e.g., qa)",
            id="env-new-input",
            classes="env-name-input",
        )
        desc_input = Input(
            placeholder="Description (optional)",
            id="env-new-desc",
            classes="env-desc-input",
        )
        add_btn = Button("Add", id="env-add-btn", variant="success")
        add_row.compose_add_child(env_input)
        add_row.compose_add_child(desc_input)
        add_row.compose_add_child(add_btn)
        container.mount(add_row)

        # Current environments list
        container.mount(Static("\n[bold]Current Environments:[/bold]", id="env-list-header"))

        env_list = Vertical(id="env-list")
        container.mount(env_list)
        self._refresh_environment_list()

    def _refresh_environment_list(self) -> None:
        """Refresh the environment list display."""
        try:
            env_list = self.query_one("#env-list", Vertical)
        except Exception:
            return

        env_list.remove_children()

        if not self._state.environments:
            env_list.mount(Static("[dim]No environments defined yet.[/dim]"))
            return

        for env_name in self._state.environments:
            row = Horizontal(classes="env-item-row")
            description = self._state.environment_descriptions.get(env_name, "")
            display_text = f"  {env_name}"
            if description:
                display_text += f" - [dim]{description}[/dim]"
            name_label = Static(display_text, classes="env-item-name")
            remove_btn = Button(
                "Remove",
                id=f"env-remove-{env_name}",
                variant="error",
                classes="env-remove-btn",
            )
            row.compose_add_child(name_label)
            row.compose_add_child(remove_btn)
            env_list.mount(row)

    @on(Button.Pressed, "#env-add-btn")
    def _handle_add_environment(self) -> None:
        """Handle adding a new environment."""
        try:
            name_input = self.query_one("#env-new-input", Input)
            desc_input = self.query_one("#env-new-desc", Input)
            env_name = name_input.value.strip().lower()
            env_desc = desc_input.value.strip()

            if not env_name:
                self.app.notify("Enter an environment name.", severity="warning")
                return

            if not env_name.replace("-", "").replace("_", "").isalnum():
                self.app.notify(
                    "Environment name should be alphanumeric (dashes/underscores allowed).",
                    severity="error",
                )
                return

            if self._state.add_environment(env_name, env_desc):
                name_input.value = ""
                desc_input.value = ""
                self._refresh_environment_list()
                self.app.notify(f"Added environment: {env_name}", severity="information")
            else:
                self.app.notify(f"Environment '{env_name}' already exists.", severity="warning")
        except Exception:
            pass

    @on(Button.Pressed)
    def _handle_remove_environment(self, event: Button.Pressed) -> None:
        """Handle removing an environment."""
        button_id = event.button.id or ""
        if not button_id.startswith("env-remove-"):
            return

        env_name = button_id.replace("env-remove-", "")
        if self._state.remove_environment(env_name):
            self._refresh_environment_list()
            self.app.notify(f"Removed environment: {env_name}", severity="information")

    def _render_plugins(self, container: VerticalScroll) -> None:
        """Render the plugin selection step."""
        container.mount(
            Static(
                "[bold]Select Plugins[/bold]\n\n"
                "Plugins provide additional functionality like layer templates, "
                "CI/CD workflows, and capabilities.\n",
                id="plugin-intro",
            ),
        )

        if not AVAILABLE_PLUGINS:
            container.mount(Static("[dim]No plugins available.[/dim]"))
            return

        for name, description in AVAILABLE_PLUGINS.items():
            checkbox = Checkbox(
                f"{name} - {description}",
                value=self._state.plugins.get(name, True),
                id=f"plugin-{name}",
            )
            container.mount(checkbox)

    def _render_layer_types(self, container: VerticalScroll) -> None:
        """Render the layer type selection step."""
        container.mount(
            Static(
                "[bold]Select Layer Types[/bold]\n\n"
                "Layer types provide templates for different infrastructure patterns. "
                "Select the types you plan to use.\n",
                id="lt-intro",
            ),
        )

        for plugin_name, types in AVAILABLE_LAYER_TYPES.items():
            if plugin_name not in self._state.selected_plugins:
                continue

            for lt_name, lt_desc in types.items():
                checkbox = Checkbox(
                    f"{lt_name} - {lt_desc}",
                    value=self._state.layer_types.get(lt_name, True),
                    id=f"lt-{lt_name}",
                )
                container.mount(checkbox)

        # If no layer types available (no plugins selected)
        if not any(plugin in self._state.selected_plugins for plugin in AVAILABLE_LAYER_TYPES):
            container.mount(
                Static(
                    "[dim]No layer types available. "
                    "Go back and select the layer_types plugin.[/dim]",
                ),
            )

    def _render_system(self, container: VerticalScroll) -> None:
        """Render the initial system creation step."""
        container.mount(
            Static(
                "[bold]Create Initial System[/bold]\n\n"
                "A system is the top-level node in your taxonomy. "
                "It typically represents a product, platform, or major component.\n",
                id="system-intro",
            ),
        )

        container.mount(Label("System Name (required):"))
        container.mount(
            Input(
                value=self._state.system_name,
                placeholder="e.g., platform, myapp, infrastructure",
                id="system-name",
            ),
        )

        container.mount(Label("Description:"))
        container.mount(
            Input(
                value=self._state.system_description,
                placeholder="Brief description of this system",
                id="system-description",
            ),
        )

        container.mount(Label("Owner Email:"))
        container.mount(
            Input(
                value=self._state.system_owner,
                placeholder="team@example.com",
                id="system-owner",
            ),
        )

        # Optional stack creation
        container.mount(
            Static(
                "\n[bold]Optional: Create Initial Stack[/bold]\n[dim]Leave blank to skip.[/dim]\n",
                id="stack-intro",
            ),
        )

        container.mount(Label("Stack Name (optional):"))
        container.mount(
            Input(
                value=self._state.stack_name,
                placeholder="e.g., api, web, database",
                id="stack-name",
            ),
        )

        container.mount(Label("Stack Description:"))
        container.mount(
            Input(
                value=self._state.stack_description,
                placeholder="Brief description of this stack",
                id="stack-description",
            ),
        )

    def _render_summary(self, container: VerticalScroll) -> None:
        """Render the summary/confirmation step."""
        # Save state before showing summary
        self._save_step_state()

        # Format environments with descriptions
        env_lines: list[str] = []
        for env in self._state.selected_environments:
            desc = self._state.environment_descriptions.get(env, "")
            if desc:
                env_lines.append(f"  • {env} - {desc}")
            else:
                env_lines.append(f"  • {env}")
        envs_text = "\n".join(env_lines) if env_lines else "(none)"

        plugins = ", ".join(self._state.selected_plugins) or "(none)"
        layer_types = ", ".join(self._state.selected_layer_types) or "(none)"

        template_source_display = (
            "Bundled templates" if self._state.template_source == "bundled" else "GitHub"
        )

        # Build hierarchy text
        hierarchy_lines = [
            f"  System: {self._state.system_name}",
            f"    Description: {self._state.system_description or '(none)'}",
            f"    Owner: {self._state.system_owner}",
        ]
        if self._state.stack_name:
            hierarchy_lines.append(f"  └─ Stack: {self._state.stack_name}")
            if self._state.stack_description:
                hierarchy_lines.append(
                    f"       Description: {self._state.stack_description}",
                )
        hierarchy_text = "\n".join(hierarchy_lines)

        summary_text = (
            f"[bold]Ready to Initialize[/bold]\n\n"
            f"[bold]Path:[/bold] {self._path}\n\n"
            f"[bold]Template Source:[/bold] {template_source_display}\n\n"
            f"[bold]Environments:[/bold]\n{envs_text}\n\n"
            f"[bold]Plugins:[/bold] {plugins}\n\n"
            f"[bold]Layer Types:[/bold] {layer_types}\n\n"
            f"[bold]Initial Hierarchy:[/bold]\n{hierarchy_text}\n\n"
            f"Press [bold green]Initialize[/bold green] to create the taxonomy."
        )

        container.mount(Static(summary_text, id="summary-text"))
