"""Tree construction logic for the taxonomy TUI."""

# pyright: reportUnnecessaryComparison=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownMemberType=false

from __future__ import annotations

from dataclasses import replace
from typing import Mapping, Sequence

from katalyst_taxonomy.agents.discovery import AgentsDirectory
from katalyst_taxonomy.domain.lock import InstalledPlugin, KatalystLock
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.services.action_service import LayerActionsPluginResult
from katalyst_taxonomy.services.cicd_service import (
    CICDPluginResult,
    JobTemplateDefinition,
    WorkflowParameter,
    WorkflowTemplateDefinition,
)
from katalyst_taxonomy.services.template_service import LayerTypesPluginResult
from katalyst_taxonomy.taxonomy.service import qualified_name_for

from .tree_nodes import NodeView, TreeNode


def build_taxonomy_tree(
    *,
    documents: Sequence[Document],
    qualified_names: Mapping[str, str],
    layer_actions: LayerActionsPluginResult | None = None,
    layer_types: LayerTypesPluginResult | None = None,
    cicd: CICDPluginResult | None = None,
    lock: KatalystLock | None = None,
    agents: AgentsDirectory | None = None,
) -> TreeNode:
    """Construct an immutable tree describing the taxonomy hierarchy segmented by type."""

    builders: dict[str, _NodeBuilder] = {}
    for doc in documents:
        fqtn = qualified_name_for(doc, qualified_names)
        view = NodeView(
            label=doc.metadata.name,
            node_type=doc.taxonomy_node_type,
            document=doc,
            extra={
                "fqtn": fqtn,
                "environments": doc.environments,
                "owners": doc.owners,
                "path": str(doc.source_path) if doc.source_path else None,
            },
            children=(),
        )
        builders[fqtn] = _NodeBuilder(view=view)

    ordered_fqtns = sorted(
        builders.keys(),
        key=lambda fq: (
            len(fq.split(".")),
            _sort_key(builders[fq].view.document),
        ),
    )

    root_children: list[_NodeBuilder] = []
    for fqtn in ordered_fqtns:
        builder = builders[fqtn]
        parent_fqtn = fqtn.rsplit(".", 1)[0] if "." in fqtn else None
        if parent_fqtn and parent_fqtn in builders:
            builders[parent_fqtn].children.append(builder)
        else:
            root_children.append(builder)

    ordered_roots = sorted(root_children, key=lambda item: _sort_key(item.view.document))

    # Classify root nodes by wing using the registry.
    # Falls back to hardcoded dispatch if registry is unavailable.
    wing_buckets: dict[str, list[NodeView]] = {}
    other_nodes: list[NodeView] = []
    try:
        from katalyst_taxonomy.engine.bridge import get_default_registry

        registry = get_default_registry()
        for builder in ordered_roots:
            node_view = builder.freeze()
            desc = registry.get(node_view.node_type)
            if desc:
                wing_buckets.setdefault(desc.wing, []).append(node_view)
            else:
                other_nodes.append(node_view)
    except Exception:
        # Fallback to hardcoded dispatch
        for builder in ordered_roots:
            node_view = builder.freeze()
            node_type = node_view.node_type
            if node_type == "system":
                wing_buckets.setdefault("technical", []).append(node_view)
            elif node_type == "user":
                wing_buckets.setdefault("organizational", []).append(node_view)
            elif node_type == "organization":
                wing_buckets.setdefault("portfolio", []).append(node_view)
            elif node_type == "library":
                wing_buckets.setdefault("technical_library", []).append(node_view)
            else:
                other_nodes.append(node_view)

    # Map wing names to display labels
    _wing_labels = {
        "system": "Systems",
        "org": "Organization",
        "practices": "Practices",
        "design": "Design",
        "dx": "Developer Experience",
        "pipeline": "Pipeline",
        "delivery": "Delivery",
    }

    # Extract specific buckets for backward-compatible segment ordering
    system_nodes = wing_buckets.pop("system", [])
    portfolio_nodes = wing_buckets.pop("org", [])
    library_nodes = [n for n in system_nodes if n.node_type == "library"]
    system_nodes = [n for n in system_nodes if n.node_type != "library"]
    user_nodes = wing_buckets.pop("practices", [])

    taxonomy_segments: list[TreeNode] = []

    if portfolio_nodes:
        taxonomy_segments.append(
            TreeNode(
                label="Portfolio",
                node_type="segment",
                document=None,
                extra={"count": len(portfolio_nodes)},
                children=tuple(portfolio_nodes),
            ),
        )

    if system_nodes or other_nodes:
        # Include any non-classified nodes beneath systems for now to avoid data loss.
        systems_children = tuple(system_nodes + other_nodes)
        taxonomy_segments.append(
            TreeNode(
                label="Systems",
                node_type="segment",
                document=None,
                extra={"count": len(systems_children)},
                children=systems_children,
            ),
        )

    if library_nodes:
        taxonomy_segments.append(
            TreeNode(
                label="Libraries",
                node_type="segment",
                document=None,
                extra={"count": len(library_nodes)},
                children=tuple(library_nodes),
            ),
        )

    if user_nodes:
        taxonomy_segments.append(
            TreeNode(
                label="Users",
                node_type="segment",
                document=None,
                extra={"count": len(user_nodes)},
                children=tuple(user_nodes),
            ),
        )

    # Add any remaining wing buckets (design, infrastructure, etc.)
    for wing, nodes in sorted(wing_buckets.items()):
        if nodes:
            taxonomy_segments.append(
                TreeNode(
                    label=_wing_labels.get(wing, wing.title()),
                    node_type="segment",
                    document=None,
                    extra={"count": len(nodes)},
                    children=tuple(nodes),
                ),
            )

    plugin_segments: list[TreeNode] = _build_plugins_children(
        lock=lock,
        layer_types=layer_types,
        layer_actions=layer_actions,
        cicd=cicd,
    )

    top_children: list[TreeNode] = []
    if taxonomy_segments:
        taxonomy_total = sum(_segment_count(segment) for segment in taxonomy_segments)
        top_children.append(
            TreeNode(
                label="Taxonomy",
                node_type="segment",
                document=None,
                extra={"count": taxonomy_total},
                children=tuple(taxonomy_segments),
            ),
        )

    if plugin_segments:
        plugin_total = sum(_segment_count(segment) for segment in plugin_segments)
        top_children.append(
            TreeNode(
                label="Plugins",
                node_type="segment",
                document=None,
                extra={"count": plugin_total},
                children=tuple(plugin_segments),
            ),
        )

    # Build Agents segment
    agents_segment = _build_agents_segment(agents)
    if agents_segment is not None:
        top_children.append(agents_segment)

    return TreeNode(
        label="Catalog",
        node_type="root",
        document=None,
        extra={"count": sum(_segment_count(segment) for segment in top_children)},
        children=tuple(top_children),
    )


def _segment_count(node: TreeNode) -> int:
    count = node.extra.get("count")
    if isinstance(count, int):
        return count
    return len(node.children)


def _build_plugins_children(
    *,
    lock: KatalystLock | None,
    layer_types: LayerTypesPluginResult | None,
    layer_actions: LayerActionsPluginResult | None,
    cicd: CICDPluginResult | None,
) -> list[TreeNode]:
    """Build plugin tree nodes from lock file and runtime plugin data."""
    children: list[TreeNode] = []

    if lock is not None:
        # Build nodes from lock file with runtime content merged in
        plugins = lock.installed.plugins

        # layer_types plugin
        layer_types_plugin = plugins.get("layer_types")
        if layer_types_plugin is not None:
            node = _build_layer_types_plugin_node(layer_types_plugin, layer_types)
            if node is not None:
                children.append(node)

        # layer_actions plugin
        layer_actions_plugin = plugins.get("layer_actions")
        if layer_actions_plugin is not None:
            node = _build_layer_actions_plugin_node(layer_actions_plugin, layer_actions)
            if node is not None:
                children.append(node)

        # cicd plugin
        cicd_plugin = plugins.get("cicd")
        if cicd_plugin is not None:
            node = _build_cicd_plugin_node(cicd_plugin, cicd)
            if node is not None:
                children.append(node)

        # Other plugins without runtime content (capabilities, tools, etc.)
        for plugin_name in sorted(plugins.keys()):
            if plugin_name in ("layer_types", "layer_actions", "cicd"):
                continue
            plugin = plugins[plugin_name]
            children.append(_build_empty_plugin_node(plugin_name, plugin))
    else:
        # No lock file - fall back to legacy behavior
        action_segment = _build_action_segment(layer_actions)
        if action_segment is not None:
            children.append(action_segment)
        cicd_segment = _build_cicd_segment(cicd)
        if cicd_segment is not None:
            children.append(cicd_segment)

    return children


def _build_layer_types_plugin_node(
    plugin: InstalledPlugin,
    layer_types: LayerTypesPluginResult | None,
) -> TreeNode:
    """Build a tree node for the layer_types plugin."""
    type_children: list[TreeNode] = []

    # Build children from layer type definitions
    if layer_types is not None:
        for definition in sorted(layer_types.definitions, key=lambda d: d.name):
            type_children.append(
                TreeNode(
                    label=definition.name,
                    node_type="layer_type",
                    document=None,
                    extra={
                        "description": definition.description or "",
                        "template_path": str(definition.template_path),
                        "default_layer_dir": definition.default_layer_dir,
                        "optional_paths": definition.optional_paths,
                        "path": str(definition.path),
                        "is_custom": definition.name in plugin.custom,
                    },
                    children=(),
                ),
            )

    # Add any items from lock that don't have definitions
    defined_names = {d.name for d in (layer_types.definitions if layer_types else [])}
    for name in plugin.canonical:
        if name not in defined_names:
            type_children.append(
                TreeNode(
                    label=name,
                    node_type="layer_type",
                    document=None,
                    extra={"description": "", "is_custom": False},
                    children=(),
                ),
            )
    for name in plugin.custom:
        if name not in defined_names:
            type_children.append(
                TreeNode(
                    label=name,
                    node_type="layer_type",
                    document=None,
                    extra={"description": "", "is_custom": True},
                    children=(),
                ),
            )

    version_label = f"layer_types ({plugin.version})"
    return TreeNode(
        label=version_label,
        node_type="installed_plugin",
        document=None,
        extra={
            "plugin_name": "layer_types",
            "version": plugin.version,
            "installed_at": plugin.installed_at.isoformat(),
            "source": plugin.source,
            "canonical": plugin.canonical,
            "custom": plugin.custom,
            "count": len(type_children),
        },
        children=tuple(type_children),
    )


def _build_layer_actions_plugin_node(
    plugin: InstalledPlugin,
    layer_actions: LayerActionsPluginResult | None,
) -> TreeNode:
    """Build a tree node for the layer_actions plugin."""
    action_children: list[TreeNode] = []
    total = 0

    if layer_actions is not None and layer_actions.actions:
        for layer_type in layer_actions.layer_types():
            actions = layer_actions.actions_for_layer_type(layer_type)
            action_nodes = [
                TreeNode(
                    label=action.name,
                    node_type="action",
                    document=None,
                    extra={
                        "description": action.description or "",
                        "type": action.action_type,
                        "when": action.when,
                        "run": action.run,
                        "timeout": action.timeout_seconds,
                        "environment": {key: value for key, value in action.environment},
                        "tags": action.tags,
                        "layerType": layer_type,
                        "path": str(action.path),
                    },
                    children=(),
                )
                for action in sorted(actions, key=lambda item: item.name)
            ]
            total += len(action_nodes)
            action_children.append(
                TreeNode(
                    label=f"{layer_type} ({len(action_nodes)})",
                    node_type="action_group",
                    document=None,
                    extra={"layerType": layer_type},
                    children=tuple(action_nodes),
                ),
            )

        unscoped = layer_actions.unscoped_actions()
        if unscoped:
            action_nodes = [
                TreeNode(
                    label=action.name,
                    node_type="action",
                    document=None,
                    extra={
                        "description": action.description or "",
                        "type": action.action_type,
                        "when": action.when,
                        "run": action.run,
                        "timeout": action.timeout_seconds,
                        "environment": {key: value for key, value in action.environment},
                        "tags": action.tags,
                        "layerType": None,
                        "path": str(action.path),
                    },
                    children=(),
                )
                for action in sorted(unscoped, key=lambda item: item.name)
            ]
            total += len(action_nodes)
            action_children.append(
                TreeNode(
                    label=f"(unscoped) ({len(action_nodes)})",
                    node_type="action_group",
                    document=None,
                    extra={"layerType": None},
                    children=tuple(action_nodes),
                ),
            )

    version_label = f"layer_actions ({plugin.version})"
    return TreeNode(
        label=version_label,
        node_type="installed_plugin",
        document=None,
        extra={
            "plugin_name": "layer_actions",
            "version": plugin.version,
            "installed_at": plugin.installed_at.isoformat(),
            "source": plugin.source,
            "canonical": plugin.canonical,
            "custom": plugin.custom,
            "count": total,
        },
        children=tuple(action_children),
    )


def _build_cicd_plugin_node(
    plugin: InstalledPlugin,
    cicd: CICDPluginResult | None,
) -> TreeNode:
    """Build a tree node for the cicd plugin."""
    cicd_children: list[TreeNode] = []
    total = 0

    if cicd is not None:
        workflow_nodes = _build_cicd_workflow_nodes(cicd.workflows)
        job_template_nodes = _build_cicd_job_nodes(cicd.jobs)

        if workflow_nodes:
            cicd_children.append(
                TreeNode(
                    label="Workflows",
                    node_type="segment",
                    document=None,
                    extra={"count": len(workflow_nodes)},
                    children=tuple(workflow_nodes),
                ),
            )
            total += len(workflow_nodes)
        if job_template_nodes:
            cicd_children.append(
                TreeNode(
                    label="Job Templates",
                    node_type="segment",
                    document=None,
                    extra={"count": len(job_template_nodes)},
                    children=tuple(job_template_nodes),
                ),
            )
            total += len(job_template_nodes)

    version_label = f"cicd ({plugin.version})"
    return TreeNode(
        label=version_label,
        node_type="installed_plugin",
        document=None,
        extra={
            "plugin_name": "cicd",
            "version": plugin.version,
            "installed_at": plugin.installed_at.isoformat(),
            "source": plugin.source,
            "canonical": plugin.canonical,
            "custom": plugin.custom,
            "count": total,
        },
        children=tuple(cicd_children),
    )


def _build_empty_plugin_node(name: str, plugin: InstalledPlugin) -> TreeNode:
    """Build a tree node for a plugin without runtime content."""
    version_label = f"{name} ({plugin.version})"
    return TreeNode(
        label=version_label,
        node_type="installed_plugin",
        document=None,
        extra={
            "plugin_name": name,
            "version": plugin.version,
            "installed_at": plugin.installed_at.isoformat(),
            "source": plugin.source,
            "canonical": plugin.canonical,
            "custom": plugin.custom,
            "count": len(plugin.canonical) + len(plugin.custom),
        },
        children=(),
    )


def _build_action_segment(layer_actions: LayerActionsPluginResult | None) -> TreeNode | None:
    if layer_actions is None or not layer_actions.actions:
        return None

    children: list[TreeNode] = []
    total = 0

    for layer_type in layer_actions.layer_types():
        actions = layer_actions.actions_for_layer_type(layer_type)
        action_nodes = [
            TreeNode(
                label=action.name,
                node_type="action",
                document=None,
                extra={
                    "description": action.description or "",
                    "type": action.action_type,
                    "when": action.when,
                    "run": action.run,
                    "timeout": action.timeout_seconds,
                    "environment": {key: value for key, value in action.environment},
                    "tags": action.tags,
                    "layerType": layer_type,
                    "path": str(action.path),
                },
                children=(),
            )
            for action in sorted(actions, key=lambda item: item.name)
        ]
        total += len(action_nodes)
        children.append(
            TreeNode(
                label=f"{layer_type} ({len(action_nodes)})",
                node_type="action_group",
                document=None,
                extra={"layerType": layer_type},
                children=tuple(action_nodes),
            ),
        )

    unscoped = layer_actions.unscoped_actions()
    if unscoped:
        action_nodes = [
            TreeNode(
                label=action.name,
                node_type="action",
                document=None,
                extra={
                    "description": action.description or "",
                    "type": action.action_type,
                    "when": action.when,
                    "run": action.run,
                    "timeout": action.timeout_seconds,
                    "environment": {key: value for key, value in action.environment},
                    "tags": action.tags,
                    "layerType": None,
                    "path": str(action.path),
                },
                children=(),
            )
            for action in sorted(unscoped, key=lambda item: item.name)
        ]
        total += len(action_nodes)
        children.append(
            TreeNode(
                label=f"(unscoped) ({len(action_nodes)})",
                node_type="action_group",
                document=None,
                extra={"layerType": None},
                children=tuple(action_nodes),
            ),
        )

    if not children:
        return None

    return TreeNode(
        label="Layer Actions",
        node_type="segment",
        document=None,
        extra={"count": total},
        children=tuple(children),
    )


def _build_cicd_segment(cicd: CICDPluginResult | None) -> TreeNode | None:
    if cicd is None:
        return None

    workflow_nodes = _build_cicd_workflow_nodes(cicd.workflows)
    job_template_nodes = _build_cicd_job_nodes(cicd.jobs)

    if not workflow_nodes and not job_template_nodes:
        return None

    children: list[TreeNode] = []
    total = 0

    if workflow_nodes:
        children.append(
            TreeNode(
                label="Workflows",
                node_type="segment",
                document=None,
                extra={"count": len(workflow_nodes)},
                children=tuple(workflow_nodes),
            ),
        )
        total += len(workflow_nodes)
    if job_template_nodes:
        children.append(
            TreeNode(
                label="Job Templates",
                node_type="segment",
                document=None,
                extra={"count": len(job_template_nodes)},
                children=tuple(job_template_nodes),
            ),
        )
        total += len(job_template_nodes)

    return TreeNode(
        label="CICD",
        node_type="segment",
        document=None,
        extra={"count": total},
        children=tuple(children),
    )


def _build_agents_segment(agents: AgentsDirectory | None) -> TreeNode | None:
    """Build an Agents segment with agents and skills."""
    if agents is None:
        return None

    if not agents.agents and not agents.skills:
        return None

    children: list[TreeNode] = []
    total = 0

    # Build agent nodes
    if agents.agents:
        agent_nodes: list[TreeNode] = []
        for agent in sorted(agents.agents, key=lambda a: a.name):
            # Gather scope info
            scope_info: list[str] = []
            if agent.scope.layer_types:
                scope_info.extend(agent.scope.layer_types)
            if agent.scope.systems:
                scope_info.extend(agent.scope.systems)
            if agent.scope.layers:
                scope_info.extend(agent.scope.layers)

            agent_nodes.append(
                TreeNode(
                    label=agent.name,
                    node_type="agent",
                    document=None,
                    extra={
                        "description": agent.description,
                        "mode": agent.mode,
                        "temperature": agent.temperature,
                        "model": agent.model,
                        "max_steps": agent.max_steps,
                        "hidden": agent.hidden,
                        "disabled": agent.disabled,
                        "tools": agent.tools,
                        "scope_global": agent.scope.global_,
                        "scope_layer_types": list(agent.scope.layer_types),
                        "scope_systems": list(agent.scope.systems),
                        "scope_layers": list(agent.scope.layers),
                        "path": str(agent.source_path) if agent.source_path else None,
                    },
                    children=(),
                ),
            )

        children.append(
            TreeNode(
                label=f"Agents ({len(agent_nodes)})",
                node_type="segment",
                document=None,
                extra={"count": len(agent_nodes)},
                children=tuple(agent_nodes),
            ),
        )
        total += len(agent_nodes)

    # Build skill nodes
    if agents.skills:
        skill_nodes: list[TreeNode] = []
        for skill in sorted(agents.skills, key=lambda s: s.name):
            skill_nodes.append(
                TreeNode(
                    label=skill.name,
                    node_type="skill",
                    document=None,
                    extra={
                        "description": skill.description,
                        "license": skill.license,
                        "compatibility": list(skill.compatibility),
                        "scope_global": skill.scope.global_,
                        "scope_layer_types": list(skill.scope.layer_types),
                        "path": str(skill.source_path) if skill.source_path else None,
                    },
                    children=(),
                ),
            )

        children.append(
            TreeNode(
                label=f"Skills ({len(skill_nodes)})",
                node_type="segment",
                document=None,
                extra={"count": len(skill_nodes)},
                children=tuple(skill_nodes),
            ),
        )
        total += len(skill_nodes)

    return TreeNode(
        label="Agents",
        node_type="segment",
        document=None,
        extra={"count": total, "path": str(agents.path)},
        children=tuple(children),
    )


def _build_cicd_workflow_nodes(
    workflows: Sequence[WorkflowTemplateDefinition],
) -> list[TreeNode]:
    nodes: list[TreeNode] = []
    for workflow in sorted(workflows, key=lambda item: item.name):
        job_children = [
            TreeNode(
                label=job.name,
                node_type="cicd_workflow_job",
                document=None,
                extra={
                    "workflow": workflow.name,
                    "template_ref": job.template_ref,
                    "with": {key: value for key, value in job.with_arguments},
                    "needs": list(job.needs),
                },
                children=(),
            )
            for job in workflow.jobs
        ]
        nodes.append(
            TreeNode(
                label=workflow.name,
                node_type="cicd_workflow",
                document=None,
                extra={
                    "description": workflow.description or "",
                    "template_path": str(workflow.template.path),
                    "renderer": workflow.template.renderer.type,
                    "strict_renderer": workflow.template.renderer.strict_undefined,
                    "parameters": [
                        _workflow_parameter_payload(parameter) for parameter in workflow.parameters
                    ],
                    "job_count": len(job_children),
                    "path": str(workflow.path),
                },
                children=tuple(job_children),
            ),
        )
    return nodes


def _build_cicd_job_nodes(jobs: Sequence[JobTemplateDefinition]) -> list[TreeNode]:
    nodes: list[TreeNode] = []
    for job in sorted(jobs, key=lambda item: item.name):
        default_inputs = {key: value for key, value in job.default_inputs}
        nodes.append(
            TreeNode(
                label=job.name,
                node_type="cicd_job_template",
                document=None,
                extra={
                    "description": job.description or "",
                    "template_path": str(job.template.path),
                    "renderer": job.template.renderer.type,
                    "strict_renderer": job.template.renderer.strict_undefined,
                    "required_inputs": list(job.required_inputs),
                    "default_inputs": default_inputs,
                    "produces": list(job.produces),
                    "consumes": list(job.consumes),
                    "path": str(job.path),
                },
                children=(),
            ),
        )
    return nodes


def _workflow_parameter_payload(parameter: WorkflowParameter) -> dict[str, object]:
    payload: dict[str, object] = {
        "name": parameter.name,
        "type": parameter.value_type,
        "required": parameter.required,
        "has_default": parameter.has_default,
    }
    if parameter.description:
        payload["description"] = parameter.description
    if parameter.has_default:
        payload["default"] = parameter.default
    return payload


class _NodeBuilder:
    """Mutable helper used while constructing immutable ``TreeNode`` instances."""

    __slots__ = ("children", "view")

    def __init__(self, *, view: NodeView) -> None:
        self.view = view
        self.children: list[_NodeBuilder] = []

    def freeze(self) -> NodeView:
        frozen_children = tuple(
            child.freeze() for child in sorted(self.children, key=lambda item: item.view.label)
        )
        return replace(self.view, children=frozen_children)


def _sort_key(document: Document) -> tuple[int, str]:
    try:
        from katalyst_taxonomy.engine.bridge import get_default_registry

        registry = get_default_registry()
        desc = registry.get(document.taxonomy_node_type)
        kind_index = desc.display_order if desc else 99999
    except Exception:
        kind_index = 99999
    return kind_index, document.metadata.name
