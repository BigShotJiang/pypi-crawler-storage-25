"""Textual TUI package for the Katalyst taxonomy toolkit."""

from .app import run

__all__ = ["run"]
