"""Pure view-model helpers for the taxonomy Textual UI.

This module re-exports types and functions from the split submodules
for backward compatibility.
"""

from __future__ import annotations

# Re-export defaults types and builders
from katalyst_taxonomy.tui.defaults import (
    DEFAULT_LAYER_TYPES,
    CloneDefaults,
    CreationContext,
    CreationDefaults,
    build_clone_defaults,
    build_creation_defaults,
)

# Re-export tree builder
from katalyst_taxonomy.tui.tree_builder import build_taxonomy_tree

# Re-export tree node types
from katalyst_taxonomy.tui.tree_nodes import (
    KIND_ORDER,
    NodeView,
    TreeNode,
)

__all__ = [
    # Tree nodes
    "KIND_ORDER",
    "NodeView",
    "TreeNode",
    # Defaults
    "DEFAULT_LAYER_TYPES",
    "CloneDefaults",
    "CreationContext",
    "CreationDefaults",
    "build_clone_defaults",
    "build_creation_defaults",
    # Tree builder
    "build_taxonomy_tree",
]
