"""Ports and adapters backing the taxonomy Textual UI."""

# pyright: reportUnknownMemberType=false

from __future__ import annotations

import io
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from katalyst_taxonomy.adapters.filesystem.lock import LockFileRepository
from katalyst_taxonomy.agents.discovery import (
    AgentsDirectory,
    discover_agents_directory,
    scan_agents_directory,
)
from katalyst_taxonomy.cli.commands.clone import run_clone
from katalyst_taxonomy.cli.commands.create import run_create
from katalyst_taxonomy.cli.commands.init import run_init
from katalyst_taxonomy.domain.lock import KatalystLock
from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.linting import lint_taxonomy_nodes
from katalyst_taxonomy.services.action_service import (
    LayerActionsPluginResult,
    load_layer_actions,
)
from katalyst_taxonomy.services.cicd_service import (
    CICDPluginResult,
    WorkflowTemplateDefinition,
    load_cicd_templates,
)
from katalyst_taxonomy.services.template_service import (
    LayerTypesPluginResult,
    load_layer_types,
)
from katalyst_taxonomy.taxonomy import DocumentError
from katalyst_taxonomy.taxonomy.service import load_taxonomy


@dataclass(frozen=True)
class TaxonomyLoadResult:
    """Data returned when loading taxonomy documents."""

    documents: tuple[Document, ...]
    qualified_names: dict[str, str]
    errors: tuple[DocumentError, ...]
    layer_actions: LayerActionsPluginResult | None
    layer_types: LayerTypesPluginResult | None
    cicd: CICDPluginResult | None
    lock: KatalystLock | None
    agents: AgentsDirectory | None = None


@dataclass(frozen=True)
class CreationRequest:
    """Command object describing a taxonomy node that should be created."""

    path: Path
    node_type: str
    name: str
    description: str
    owners: Sequence[str]
    environments: Sequence[str]
    parent: str | None
    parent_system: str | None
    layer_type: str | None = None
    annotations: Sequence[str] = ()
    depends_on: Sequence[str] = ()
    stack_description: str | None = None


@dataclass(frozen=True)
class CloneRequest:
    """Command object describing a clone operation."""

    path: Path
    node_type: str
    name: str
    description: str | None
    owners: Sequence[str]
    environments: Sequence[str]
    parent: str | None
    parent_system: str | None
    source_system: str
    source_stack: str | None = None
    source_layer: str | None = None
    layer_type: str | None = None
    stack_description: str | None = None


@dataclass(frozen=True)
class CreationOutcome:
    """Result from attempting to create a taxonomy node."""

    success: bool
    stdout: str
    stderr: str
    exit_code: int


@dataclass(frozen=True)
class ActionRunRequest:
    """Command parameters for executing a layer action."""

    workdir: Path
    action_name: str
    command: str
    environment: str | None = None


@dataclass(frozen=True)
class ActionRunOutcome:
    """Result payload from running a layer action."""

    success: bool
    stdout: str
    stderr: str
    exit_code: int


@dataclass(frozen=True)
class LintOutcome:
    """Result from running taxonomy linting."""

    checked_documents: int
    checked_environment_documents: int
    errors: tuple[str, ...]
    schema_path: str
    environment_schema_path: str


@dataclass(frozen=True)
class RenderOutcome:
    """Result from rendering a workflow template."""

    success: bool
    rendered: str
    error: str | None


@dataclass(frozen=True)
class StatusInfo:
    """Status information about the taxonomy installation."""

    path: str
    document_count: int
    system_count: int
    stack_count: int
    layer_count: int
    environment_count: int
    layer_action_count: int
    layer_type_count: int
    workflow_count: int
    job_template_count: int
    stage_count: int
    error_count: int


class FilesystemTaxonomyService:
    """Concrete adapter that delegates to the CLI implementation."""

    def load(self, path: Path) -> TaxonomyLoadResult:
        result = load_taxonomy(path)
        layer_actions = load_layer_actions(path)
        layer_types = load_layer_types(path)
        cicd = load_cicd_templates(path)

        # Load lock file if it exists
        lock_repo = LockFileRepository(base_path=path)
        lock = lock_repo.load() if lock_repo.exists() else None

        # Load agents if .agents/ directory exists
        agents_dir = discover_agents_directory(path)
        agents = scan_agents_directory(agents_dir) if agents_dir else None

        return TaxonomyLoadResult(
            documents=result.documents,
            qualified_names=dict(result.qualified_names),
            errors=result.errors,
            layer_actions=layer_actions,
            layer_types=layer_types,
            cicd=cicd,
            lock=lock,
            agents=agents,
        )

    def create(self, request: CreationRequest) -> CreationOutcome:
        stdout = io.StringIO()
        stderr = io.StringIO()
        exit_code = run_create(
            path=request.path,
            node_type=request.node_type,
            name=request.name,
            description=request.description,
            owners=tuple(request.owners) if request.owners else None,
            environments=tuple(request.environments) if request.environments else None,
            parent=request.parent,
            parent_system=request.parent_system,
            layer_type=request.layer_type,
            output=stdout,
            err_output=stderr,
        )
        return CreationOutcome(
            success=exit_code == 0,
            stdout=stdout.getvalue(),
            stderr=stderr.getvalue(),
            exit_code=exit_code,
        )

    def clone(self, request: CloneRequest) -> CreationOutcome:
        stdout = io.StringIO()
        stderr = io.StringIO()
        # The new clone command uses source_name for the source layer/stack
        source_name = request.source_layer or request.source_stack or request.source_system
        exit_code = run_clone(
            path=request.path,
            node_type=request.node_type,
            source_name=source_name or "",
            target_name=request.name,
            source_system=request.source_system,
            source_stack=request.source_stack,
            target_system=request.parent_system,
            target_stack=request.parent,
            description=request.description,
            owners=tuple(request.owners) if request.owners else None,
            environments=tuple(request.environments) if request.environments else None,
            layer_type=request.layer_type,
            yes=True,  # Skip confirmation prompts in TUI
            output=stdout,
            err_output=stderr,
        )
        return CreationOutcome(
            success=exit_code == 0,
            stdout=stdout.getvalue(),
            stderr=stderr.getvalue(),
            exit_code=exit_code,
        )

    def run_action(self, request: ActionRunRequest) -> ActionRunOutcome:
        env = os.environ.copy()
        if request.environment:
            env["ENV"] = request.environment
        env["LAYER_DIR"] = str(request.workdir)
        env["STACK_DIR"] = str(request.workdir.parent)
        process = subprocess.run(
            request.command,
            cwd=request.workdir,
            shell=True,
            capture_output=True,
            text=False,
            env=env,
        )
        return ActionRunOutcome(
            success=process.returncode == 0,
            stdout=process.stdout.decode("utf-8", errors="replace"),
            stderr=process.stderr.decode("utf-8", errors="replace"),
            exit_code=process.returncode,
        )

    def lint(self, path: Path) -> LintOutcome:
        """Run taxonomy linting and return results."""
        result = lint_taxonomy_nodes(path)
        error_messages: list[str] = []
        for error in result.errors:
            location = f"{error.path}:{error.document_index}"
            node_info = f" [{error.qualified_name}]" if error.qualified_name else ""
            error_messages.append(f"{location}{node_info}: {error.message}")
        return LintOutcome(
            checked_documents=result.checked_documents,
            checked_environment_documents=result.checked_environment_documents,
            errors=tuple(error_messages),
            schema_path=str(result.schema_path),
            environment_schema_path=str(result.environment_schema_path),
        )

    def get_status(self, path: Path) -> StatusInfo:
        """Get status information about the taxonomy at the given path."""
        try:
            load_result = self.load(path)
        except FileNotFoundError:
            return StatusInfo(
                path=str(path),
                document_count=0,
                system_count=0,
                stack_count=0,
                layer_count=0,
                environment_count=0,
                layer_action_count=0,
                layer_type_count=0,
                workflow_count=0,
                job_template_count=0,
                stage_count=0,
                error_count=1,
            )

        documents = load_result.documents
        system_count = sum(1 for d in documents if d.taxonomy_node_type == "system")
        stack_count = sum(1 for d in documents if d.taxonomy_node_type == "stack")
        layer_count = sum(1 for d in documents if d.taxonomy_node_type == "layer")

        # Collect unique environments
        all_envs: set[str] = set()
        for doc in documents:
            all_envs.update(doc.environments)

        layer_action_count = 0
        if load_result.layer_actions:
            layer_action_count = len(load_result.layer_actions.actions)

        layer_type_count = 0
        if load_result.layer_types:
            layer_type_count = len(load_result.layer_types.definitions)

        workflow_count = 0
        job_template_count = 0
        stage_count = 0
        if load_result.cicd:
            workflow_count = len(load_result.cicd.workflows)
            job_template_count = len(load_result.cicd.jobs)
            stage_count = len(load_result.cicd.stages)

        error_count = len(load_result.errors)
        if load_result.layer_actions:
            error_count += len(load_result.layer_actions.errors)
        if load_result.layer_types:
            error_count += len(load_result.layer_types.errors)
        if load_result.cicd:
            error_count += len(load_result.cicd.errors)

        return StatusInfo(
            path=str(path),
            document_count=len(documents),
            system_count=system_count,
            stack_count=stack_count,
            layer_count=layer_count,
            environment_count=len(all_envs),
            layer_action_count=layer_action_count,
            layer_type_count=layer_type_count,
            workflow_count=workflow_count,
            job_template_count=job_template_count,
            stage_count=stage_count,
            error_count=error_count,
        )

    def render_workflow(
        self,
        path: Path,
        workflow: WorkflowTemplateDefinition,
        params: dict[str, Any],
    ) -> RenderOutcome:
        """Render a workflow template with the given parameters."""
        template_path = workflow.template.path
        if not template_path.exists():
            return RenderOutcome(
                success=False,
                rendered="",
                error=f"Template file not found: {template_path}",
            )

        try:
            template_content = template_path.read_text()
        except OSError as exc:
            return RenderOutcome(
                success=False,
                rendered="",
                error=f"Failed to read template: {exc}",
            )

        renderer = workflow.template.renderer
        if renderer.type in ("jinja", "jinja2"):
            try:
                from jinja2 import Environment, StrictUndefined, Undefined

                jinja_env = Environment(
                    undefined=StrictUndefined if renderer.strict_undefined else Undefined,
                )
                template = jinja_env.from_string(template_content)
                rendered = template.render(**params)
                return RenderOutcome(success=True, rendered=rendered, error=None)
            except ImportError:
                return RenderOutcome(
                    success=False,
                    rendered="",
                    error="Jinja2 is required for rendering. Install with: pip install jinja2",
                )
            except Exception as exc:
                return RenderOutcome(
                    success=False,
                    rendered="",
                    error=f"Template rendering failed: {exc}",
                )
        else:
            return RenderOutcome(
                success=False,
                rendered="",
                error=f"Unsupported renderer type: {renderer.type}",
            )

    def is_taxonomy_initialized(self, path: Path) -> bool:
        """Check if the path contains a taxonomy repository."""
        # Check for common indicators of a taxonomy repo
        if not path.exists():
            return False

        # Look for .global/taxonomy directory or any taxonomy.yaml files
        global_taxonomy = path / ".global" / "taxonomy"
        if global_taxonomy.exists():
            return True

        # Look for any taxonomy node files
        for yaml_file in path.rglob("*.yaml"):
            try:
                import yaml

                with yaml_file.open() as f:
                    for doc in yaml.safe_load_all(f):
                        if isinstance(doc, dict):
                            if doc.get("apiVersion") == "katalyst.io/v1":
                                return True
            except Exception:
                continue
            # Only check the first few files
            break

        return False

    def init_taxonomy(
        self,
        path: Path,
        *,
        plugins: tuple[str, ...] | None = None,
        layer_types: tuple[str, ...] | None = None,
    ) -> CreationOutcome:
        """Initialize a new taxonomy repository at the given path.

        Args:
            path: Path to initialize the taxonomy at.
            plugins: Optional tuple of plugin names to install.
            layer_types: Optional tuple of layer type names to install.

        Returns:
            CreationOutcome with success status and output.
        """
        stdout = io.StringIO()
        stderr = io.StringIO()
        exit_code = run_init(
            path=path,
            plugins=plugins,
            layer_types=layer_types,
            interactive=False,
            output=stdout,
            err_output=stderr,
        )
        return CreationOutcome(
            success=exit_code == 0,
            stdout=stdout.getvalue(),
            stderr=stderr.getvalue(),
            exit_code=exit_code,
        )
