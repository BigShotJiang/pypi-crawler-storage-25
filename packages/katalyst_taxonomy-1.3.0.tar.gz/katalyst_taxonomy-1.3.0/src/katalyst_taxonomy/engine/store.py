"""Document store — in-memory collection of validated documents.

Provides indexed access by name, kind, wing, and extension targeting.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Sequence

from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.registry import NodeTypeRegistry


@dataclass
class DocumentStore:
    """In-memory document collection with indexed lookups.

    The store holds all loaded documents and provides efficient queries
    without knowing anything about specific node types — it delegates
    type knowledge to the registry.
    """

    _documents: list[Document] = field(default_factory=lambda: list[Document]())
    _by_name: dict[str, Document] = field(default_factory=lambda: dict[str, Document]())
    _by_kind: dict[str, list[Document]] = field(default_factory=lambda: dict[str, list[Document]]())
    _extensions_by_target: dict[str, list[Document]] = field(
        default_factory=lambda: dict[str, list[Document]]()
    )

    @property
    def documents(self) -> tuple[Document, ...]:
        """All documents in insertion order."""
        return tuple(self._documents)

    def __len__(self) -> int:
        return len(self._documents)

    def __contains__(self, name: str) -> bool:
        return name in self._by_name

    def add(self, document: Document) -> None:
        """Add a document to the store, updating indexes."""
        self._documents.append(document)
        self._by_name[document.name] = document
        self._by_kind.setdefault(document.kind, []).append(document)

        # Index extensions by target for fast lookup
        if document.extends is not None:
            key = document.extends.target_kind
            self._extensions_by_target.setdefault(key, []).append(document)

    def add_many(self, documents: Sequence[Document]) -> None:
        """Add multiple documents to the store."""
        for doc in documents:
            self.add(doc)

    def get_by_name(self, name: str) -> Document | None:
        """Find a document by metadata.name."""
        return self._by_name.get(name)

    def get_by_kind(self, kind: str) -> tuple[Document, ...]:
        """Return all documents of a specific kind."""
        return tuple(self._by_kind.get(kind, []))

    def get_by_wing(self, wing: str, registry: NodeTypeRegistry) -> tuple[Document, ...]:
        """Return all documents belonging to a wing (requires registry for kind→wing mapping)."""
        kinds = registry.kinds_in_wing(wing)
        results: list[Document] = []
        for kind in kinds:
            results.extend(self._by_kind.get(kind, []))
        return tuple(results)

    def extensions_for(
        self,
        target_kind: str,
        target_name: str,
        *,
        extension_kind: str | None = None,
    ) -> tuple[Document, ...]:
        """Find all extension documents targeting (kind, name).

        Args:
            target_kind: The kind of the target node (e.g., "LayerType").
            target_name: The name of the target node (e.g., "app-docker").
            extension_kind: Optional filter to only return extensions of a specific kind.

        Returns:
            Tuple of extension documents whose ``extends`` target matches.
        """
        candidates = self._extensions_by_target.get(target_kind, [])
        results: list[Document] = []
        for doc in candidates:
            if doc.extends is None:
                continue
            if not doc.extends.matches(target_kind, target_name):
                continue
            if extension_kind is not None and doc.kind != extension_kind:
                continue
            results.append(doc)
        return tuple(results)

    def active_extensions_for(
        self,
        target_kind: str,
        target_name: str,
        *,
        extension_kind: str | None = None,
    ) -> tuple[Document, ...]:
        """Find extensions whose activation requirements are satisfied.

        An extension is active if:
        - It targets (target_kind, target_name)
        - All ``required`` activation requirements have matching documents in the store
        - ``conditional`` requirements that are missing cause the extension to be excluded
        - ``optional`` requirements that are missing are ignored

        Returns:
            Tuple of active extension documents.
        """
        candidates = self.extensions_for(target_kind, target_name, extension_kind=extension_kind)
        active: list[Document] = []
        for doc in candidates:
            if self._is_active(doc):
                active.append(doc)
        return tuple(active)

    def _is_active(self, doc: Document) -> bool:
        """Check if an extension document's activation requirements are met."""
        if doc.activation is None:
            return True  # No requirements means always active

        for req in doc.activation:
            # Check if a document with the required (kind, name) exists
            found = any(
                d.kind == req.kind and d.name == req.name for d in self._by_kind.get(req.kind, [])
            )
            if not found:
                if req.mode == "required":
                    return False  # Hard fail
                if req.mode == "conditional":
                    return False  # Silently deactivate
                # "optional" — continue, it's fine

        return True

    def sorted_documents(self, registry: NodeTypeRegistry) -> list[Document]:
        """Return all documents sorted by display order then name."""
        return sorted(
            self._documents,
            key=lambda d: (
                (registry.get(d.kind) or _FALLBACK_DESC).display_order,
                d.name,
            ),
        )

    def group_by_kind(self) -> dict[str, list[Document]]:
        """Group documents by kind."""
        grouped: dict[str, list[Document]] = {}
        for kind, docs in self._by_kind.items():
            grouped[kind] = sorted(docs, key=lambda d: d.name)
        return grouped

    def group_by_wing(self, registry: NodeTypeRegistry) -> dict[str, list[Document]]:
        """Group documents by wing (requires registry for kind→wing mapping)."""
        grouped: dict[str, list[Document]] = {}
        for doc in self._documents:
            desc = registry.get(doc.kind)
            wing = desc.wing if desc else "unknown"
            grouped.setdefault(wing, []).append(doc)
        for docs in grouped.values():
            docs.sort(key=lambda d: d.name)
        return grouped

    def clear(self) -> None:
        """Remove all documents from the store."""
        self._documents.clear()
        self._by_name.clear()
        self._by_kind.clear()
        self._extensions_by_target.clear()


# Fallback descriptor for unknown kinds (sorts to end)


class _FallbackDesc:
    display_order: int = 99999


_FALLBACK_DESC = _FallbackDesc()
