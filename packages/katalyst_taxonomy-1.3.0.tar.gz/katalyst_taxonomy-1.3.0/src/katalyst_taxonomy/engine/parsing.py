"""Document parsing — produces v2 Document objects from YAML and markdown files.

Handles both v1alpha and v2alpha formats transparently:
- v2alpha: ``kind`` is the node type directly
- v1alpha: ``kind: TaxonomyNode`` + ``taxonomyNodeType`` → converted to v2

This is the canonical parser. All filesystem loading goes through here.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, cast

import yaml
from loguru import logger

from katalyst_taxonomy.domain.errors import DocumentError
from katalyst_taxonomy.engine.document import V2_API_VERSION, Document
from katalyst_taxonomy.parsing.frontmatter import ParseError, parse_frontmatter
from katalyst_taxonomy.taxonomy.environments import (
    ENVIRONMENT_KIND,
    EnvironmentDocument,
    environment_from_mapping,
)

V1_API_VERSION = "katalyst.taxonomy/v1alpha"
V1_KIND = "TaxonomyNode"
ENVIRONMENT_API_VERSION = V1_API_VERSION  # environments still use v1


def _as_mapping(data: object) -> dict[str, Any]:
    """Ensure data is a dict, or return empty dict."""
    if isinstance(data, dict):
        return cast(dict[str, Any], data)
    return {}


def _is_taxonomy_document(mapping: Mapping[str, Any]) -> bool:
    """Check if a mapping is a taxonomy document (v1 or v2)."""
    api_version = str(mapping.get("apiVersion", ""))
    kind = str(mapping.get("kind", ""))

    # v2: any apiVersion=v2alpha
    if api_version == V2_API_VERSION:
        return True

    # v1: apiVersion=v1alpha + kind=TaxonomyNode
    if api_version == V1_API_VERSION and kind == V1_KIND:
        return True

    return False


def _is_environment_document(mapping: Mapping[str, Any]) -> bool:
    """Check if a mapping is an environment document."""
    api_version = str(mapping.get("apiVersion", ""))
    kind = str(mapping.get("kind", ""))
    return api_version == V1_API_VERSION and kind == ENVIRONMENT_KIND


def document_from_mapping(
    mapping: Mapping[str, Any],
    *,
    source_path: Path | None = None,
    markdown_body: str | None = None,
) -> Document:
    """Parse a single YAML mapping into a Document.

    Handles both v1alpha and v2alpha formats via Document.from_dict().
    """
    doc = Document.from_dict(mapping, source_path=source_path)

    # Inject markdown body into spec if present
    if markdown_body is not None:
        spec = dict(doc.spec)
        spec["_markdown_body"] = markdown_body
        # Markdown body overrides front matter description when non-empty
        if markdown_body.strip():
            spec["description"] = markdown_body
        object.__setattr__(doc, "spec", spec)

    return doc


def parse_yaml_documents(
    path: Path,
    *,
    environment_documents: list[EnvironmentDocument],
    errors: list[DocumentError],
) -> tuple[Document, ...]:
    """Parse all documents from a YAML file (multi-document supported).

    Taxonomy documents are returned; environment documents are appended to
    *environment_documents* as a side-effect, and any parse errors are
    appended to *errors*.
    """
    documents: list[Document] = []
    index = 0
    try:
        with path.open("r", encoding="utf-8") as stream:
            try:
                for index, raw in enumerate(yaml.safe_load_all(stream), start=1):
                    if not raw:
                        continue
                    try:
                        mapping = _as_mapping(raw)

                        if _is_taxonomy_document(mapping):
                            documents.append(document_from_mapping(mapping, source_path=path))
                        elif _is_environment_document(mapping):
                            environment_documents.append(
                                environment_from_mapping(mapping, source_path=path),
                            )
                        else:
                            logger.debug(
                                "Skipping non-taxonomy document in {} (apiVersion={}, kind={})",
                                path,
                                mapping.get("apiVersion"),
                                mapping.get("kind"),
                            )
                    except Exception as exc:
                        errors.append(
                            DocumentError(path=path, document_index=index, message=str(exc)),
                        )
            except yaml.YAMLError as exc:
                errors.append(
                    DocumentError(path=path, document_index=index, message=str(exc)),
                )
                logger.warning(
                    "YAML parse error in {} (document {}): {}",
                    path,
                    index,
                    exc,
                )
    except OSError as exc:
        errors.append(DocumentError(path=path, document_index=0, message=str(exc)))
        logger.warning("Failed to open {}: {}", path, exc)

    return tuple(documents)


def parse_markdown_document(
    path: Path,
    *,
    environment_documents: list[EnvironmentDocument],
    errors: list[DocumentError],
) -> tuple[Document, ...]:
    """Parse a single taxonomy document from a markdown file with YAML front matter."""
    documents: list[Document] = []
    try:
        content = path.read_text(encoding="utf-8")
        frontmatter, body = parse_frontmatter(content, path)
        mapping = _as_mapping(frontmatter)

        if _is_taxonomy_document(mapping):
            documents.append(
                document_from_mapping(mapping, source_path=path, markdown_body=body or None),
            )
        elif _is_environment_document(mapping):
            environment_documents.append(
                environment_from_mapping(mapping, source_path=path, markdown_body=body or None),
            )
        else:
            logger.debug(
                "Skipping non-taxonomy markdown document in {} (apiVersion={}, kind={})",
                path,
                mapping.get("apiVersion"),
                mapping.get("kind"),
            )
    except ParseError as exc:
        errors.append(DocumentError(path=path, document_index=1, message=str(exc)))
    except Exception as exc:
        errors.append(DocumentError(path=path, document_index=1, message=str(exc)))
    return tuple(documents)


def parse_documents(
    path: Path,
    *,
    environment_documents: list[EnvironmentDocument],
    errors: list[DocumentError],
) -> tuple[Document, ...]:
    """Parse taxonomy documents from a file, dispatching by extension."""
    if path.suffix.lower() == ".md":
        return parse_markdown_document(
            path,
            environment_documents=environment_documents,
            errors=errors,
        )
    return parse_yaml_documents(
        path,
        environment_documents=environment_documents,
        errors=errors,
    )
