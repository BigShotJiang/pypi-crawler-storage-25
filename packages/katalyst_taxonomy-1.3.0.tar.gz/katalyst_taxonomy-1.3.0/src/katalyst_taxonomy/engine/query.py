"""Query interface — high-level queries over the document graph.

Provides a composable query API that delegates type knowledge
to the registry and document lookup to the store.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Sequence

from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.registry import NodeTypeRegistry
from katalyst_taxonomy.engine.store import DocumentStore


@dataclass(frozen=True, slots=True)
class QueryFilter:
    """A composable filter for querying documents."""

    kind: str | None = None
    wing: str | None = None
    name_pattern: str | None = None
    is_root: bool | None = None
    is_leaf: bool | None = None
    is_extension: bool | None = None
    label: tuple[str, str] | None = None  # (key, value) pair
    custom: Callable[[Document], bool] | None = None


class QueryEngine:
    """Composable query interface over the document store.

    Example usage::

        engine = QueryEngine(store, registry)

        # All layers
        layers = engine.query(kind="layer")

        # All root documents in the technical wing
        roots = engine.query(wing="technical", is_root=True)

        # All extensions targeting LayerType "app-docker"
        exts = engine.extensions_for("LayerType", "app-docker")
    """

    def __init__(self, store: DocumentStore, registry: NodeTypeRegistry) -> None:
        self._store = store
        self._registry = registry

    @property
    def store(self) -> DocumentStore:
        """The underlying document store."""
        return self._store

    @property
    def registry(self) -> NodeTypeRegistry:
        """The node type registry."""
        return self._registry

    def query(self, **filters: object) -> tuple[Document, ...]:
        """Query documents with optional filters.

        Supported keyword arguments match ``QueryFilter`` fields:
        ``kind``, ``wing``, ``name_pattern``, ``is_root``, ``is_leaf``,
        ``is_extension``, ``label``, ``custom``.
        """
        qf = QueryFilter(**filters)  # type: ignore[arg-type]
        return self._apply_filter(qf)

    def query_filter(self, qf: QueryFilter) -> tuple[Document, ...]:
        """Query documents using an explicit QueryFilter object."""
        return self._apply_filter(qf)

    def extensions_for(
        self,
        target_kind: str,
        target_name: str,
        *,
        extension_kind: str | None = None,
    ) -> tuple[Document, ...]:
        """Find all extension documents targeting (kind, name)."""
        return self._store.extensions_for(target_kind, target_name, extension_kind=extension_kind)

    def active_extensions_for(
        self,
        target_kind: str,
        target_name: str,
        *,
        extension_kind: str | None = None,
    ) -> tuple[Document, ...]:
        """Find active extensions (requirements satisfied) targeting (kind, name)."""
        return self._store.active_extensions_for(
            target_kind, target_name, extension_kind=extension_kind
        )

    def sorted_documents(self) -> list[Document]:
        """Return all documents sorted by display order then name."""
        return self._store.sorted_documents(self._registry)

    def group_by_kind(self) -> dict[str, list[Document]]:
        """Group documents by kind."""
        return self._store.group_by_kind()

    def group_by_wing(self) -> dict[str, list[Document]]:
        """Group documents by wing."""
        return self._store.group_by_wing(self._registry)

    def _apply_filter(self, qf: QueryFilter) -> tuple[Document, ...]:
        """Apply a QueryFilter to the document store."""
        # Start with the most selective index
        if qf.kind is not None:
            candidates: Sequence[Document] = self._store.get_by_kind(qf.kind)
        elif qf.wing is not None:
            candidates = self._store.get_by_wing(qf.wing, self._registry)
        else:
            candidates = self._store.documents

        results: list[Document] = []
        for doc in candidates:
            if not self._matches(doc, qf):
                continue
            results.append(doc)

        return tuple(results)

    def _matches(self, doc: Document, qf: QueryFilter) -> bool:
        """Check if a document matches all filter criteria."""
        if qf.kind is not None and doc.kind != qf.kind:
            return False

        if qf.wing is not None:
            desc = self._registry.get(doc.kind)
            if desc is None or desc.wing != qf.wing:
                return False

        if qf.name_pattern is not None:
            if qf.name_pattern not in doc.name:
                return False

        if qf.is_root is not None:
            if self._registry.is_root(doc.kind) != qf.is_root:
                return False

        if qf.is_leaf is not None:
            if self._registry.is_leaf(doc.kind) != qf.is_leaf:
                return False

        if qf.is_extension is not None:
            if doc.is_extension != qf.is_extension:
                return False

        if qf.label is not None:
            key, value = qf.label
            if doc.metadata.labels.get(key) != value:
                return False

        if qf.custom is not None:
            if not qf.custom(doc):
                return False

        return True
