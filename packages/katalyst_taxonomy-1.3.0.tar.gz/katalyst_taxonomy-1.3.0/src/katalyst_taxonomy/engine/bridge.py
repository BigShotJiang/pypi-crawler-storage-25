"""Bridge between v1 Document and v2 engine Document.

Also provides a default registry loader for the generated artifacts,
so existing adapters can migrate incrementally.
"""

# pyright: reportConstantRedefinition=false
# pyright: reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

from katalyst_taxonomy.engine.document import (
    V2_API_VERSION,
    Document,
    Metadata,
)
from katalyst_taxonomy.engine.generated import REGISTRY_PATH
from katalyst_taxonomy.engine.registry import NodeTypeRegistry

_DEFAULT_REGISTRY: NodeTypeRegistry | None = None


def get_default_registry() -> NodeTypeRegistry:
    """Load and cache the default registry from the generated artifacts.

    This is the main entry point for existing adapters that need
    registry access without wiring it through explicitly.
    """
    global _DEFAULT_REGISTRY
    if _DEFAULT_REGISTRY is None:
        _DEFAULT_REGISTRY = NodeTypeRegistry.from_json(REGISTRY_PATH)
    return _DEFAULT_REGISTRY


def reset_default_registry() -> None:
    """Reset the cached default registry (for testing)."""
    global _DEFAULT_REGISTRY
    _DEFAULT_REGISTRY = None


def v1_to_v2_document(doc: Document) -> Document:
    """Convert a v1 Document to a v2 engine Document.

    Since Document is now an alias for Document, this function
    acts as a normalizing pass: it re-creates the document ensuring the
    api_version is V2_API_VERSION and the kind is set to the node type.

    If the document already uses the v2 API version, it is returned as-is.
    """
    if doc.api_version == V2_API_VERSION:
        return doc

    # Legacy v1 documents carried kind="TaxonomyNode" with the actual type
    # in taxonomy_node_type.  Now kind *is* the node type.
    spec = dict(doc.spec)

    return Document(
        api_version=V2_API_VERSION,
        kind=doc.taxonomy_node_type,
        metadata=Metadata(
            name=doc.metadata.name,
            labels=dict(doc.metadata.labels or {}),
        ),
        spec=spec,
        source_path=doc.source_path,
    )


def v2_to_v1_document(doc: Document) -> Document:
    """Convert a v2 engine Document back to a v1 Document.

    Since Document is now an alias for Document, this is
    essentially an identity operation.  The returned document preserves
    all v2 fields as-is.
    """
    return doc
