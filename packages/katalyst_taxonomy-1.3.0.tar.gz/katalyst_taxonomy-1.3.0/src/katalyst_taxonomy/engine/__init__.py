"""Katalyst Taxonomy v2 Modeling Engine.

A fully agnostic modeling engine where the core has zero knowledge
of specific node types. All type knowledge is loaded from a generated
registry at startup.
"""

from katalyst_taxonomy.engine.document import Document, Metadata
from katalyst_taxonomy.engine.registry import NodeTypeDescriptor, NodeTypeRegistry
from katalyst_taxonomy.engine.store import DocumentStore
from katalyst_taxonomy.engine.validator import SchemaValidator, ValidationResult

__all__ = [
    "Document",
    "DocumentStore",
    "Metadata",
    "NodeTypeDescriptor",
    "NodeTypeRegistry",
    "SchemaValidator",
    "ValidationResult",
]
