"""Document model — the universal envelope for all taxonomy resources.

Every document in the system uses the apiVersion/kind/metadata/spec shape.
The ``kind`` field is the sole discriminator — it maps to a schema in the registry.
"""

# pyright: reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false
# pyright: reportUnnecessaryIsInstance=false

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

V2_API_VERSION = "katalyst.taxonomy/v2alpha"


@dataclass(frozen=True, slots=True)
class Metadata:
    """Metadata block of a taxonomy document."""

    name: str
    labels: Mapping[str, str] = field(default_factory=dict)
    annotations: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        name = self.name.strip() if self.name else ""
        if not name:
            raise ValueError("metadata.name cannot be blank")
        object.__setattr__(self, "name", name)
        # Ensure immutable copies
        object.__setattr__(self, "labels", dict(self.labels))
        object.__setattr__(self, "annotations", dict(self.annotations))


@dataclass(frozen=True, slots=True)
class ExtensionTarget:
    """Declares what a NodeExtension targets."""

    target_kind: str
    target_names: tuple[str, ...]

    def __post_init__(self) -> None:
        if not self.target_kind:
            raise ValueError("target_kind cannot be blank")
        if not self.target_names:
            raise ValueError("target_names cannot be empty")
        object.__setattr__(self, "target_names", tuple(self.target_names))

    def matches(self, kind: str, name: str) -> bool:
        """Check if this target matches a given (kind, name) pair."""
        if self.target_kind != kind:
            return False
        if "*" in self.target_names:
            return True
        return name in self.target_names


@dataclass(frozen=True, slots=True)
class ActivationRequirement:
    """A single prerequisite for extension activation."""

    kind: str
    name: str
    mode: str = "required"  # "required" | "optional" | "conditional"

    def __post_init__(self) -> None:
        if self.mode not in ("required", "optional", "conditional"):
            raise ValueError(
                f"Invalid activation mode: {self.mode!r}. "
                "Must be 'required', 'optional', or 'conditional'."
            )


@dataclass(frozen=True, slots=True)
class Document:
    """Universal document envelope — every resource in the taxonomy uses this shape.

    The ``kind`` field is the sole discriminator. The registry maps ``kind`` to
    the JSON schema used for validating ``spec``.
    """

    api_version: str
    kind: str
    metadata: Metadata
    spec: Mapping[str, Any]
    source_path: Path | None = None

    # Extension fields (only populated for NodeExtension subtypes)
    extends: ExtensionTarget | None = None
    activation: tuple[ActivationRequirement, ...] | None = None

    def __post_init__(self) -> None:
        if not self.kind:
            raise ValueError("kind cannot be blank")
        # Ensure spec is a dict copy
        object.__setattr__(self, "spec", dict(self.spec))
        # Normalize source_path
        if self.source_path is not None and not isinstance(self.source_path, Path):
            object.__setattr__(self, "source_path", Path(self.source_path))  # type: ignore[arg-type]
        if self.activation is not None:
            object.__setattr__(self, "activation", tuple(self.activation))

    @property
    def name(self) -> str:
        """Shortcut to metadata.name."""
        return self.metadata.name

    @property
    def is_extension(self) -> bool:
        """Whether this document is a NodeExtension (has extends target)."""
        return self.extends is not None

    # ── Typed convenience properties ─────────────────────────────────
    # These provide clean attribute access for consumers so they don't
    # need to do dict lookups into spec. They match the access patterns
    # that TaxonomyDocument provided via its nested dataclasses.

    @property
    def taxonomy_node_type(self) -> str:
        """Alias for ``kind`` — backward compat with v1 consumers."""
        return self.kind

    @property
    def description(self) -> str | None:
        """The node description from spec."""
        val = self.spec.get("description")
        return str(val) if val is not None else None

    @property
    def owners(self) -> tuple[str, ...]:
        """Owner list from spec."""
        raw = self.spec.get("owners")
        if isinstance(raw, (list, tuple)):
            return tuple(str(o) for o in raw)
        return ()

    @property
    def environments(self) -> tuple[str, ...]:
        """Environment list from spec."""
        raw = self.spec.get("environments")
        if isinstance(raw, (list, tuple)):
            return tuple(str(e) for e in raw)
        return ()

    @property
    def parent(self) -> str | None:
        """Parent node reference (from spec.parents.node or spec.parent)."""
        # v2 shape: spec.parent
        p = self.spec.get("parent")
        if isinstance(p, str) and p:
            return p
        # v1 shape: spec.parents.node
        parents = self.spec.get("parents")
        if isinstance(parents, dict):
            node = parents.get("node")
            if node:
                return str(node)
        return None

    @property
    def depends_on_nodes(self) -> tuple[str, ...]:
        """Dependency node names from spec."""
        # v2 shape: spec.depends_on
        raw = self.spec.get("depends_on")
        if isinstance(raw, (list, tuple)):
            return tuple(str(n) for n in raw)
        # v1 shape: spec.dependsOn.nodes
        dep = self.spec.get("dependsOn")
        if isinstance(dep, dict):
            nodes = dep.get("nodes")
            if isinstance(nodes, (list, tuple)):
                return tuple(str(n) for n in nodes)
        return ()

    @property
    def annotations_map(self) -> dict[str, str]:
        """Spec-level annotations (not metadata annotations)."""
        raw = self.spec.get("annotations")
        if isinstance(raw, dict):
            return {str(k): str(v) for k, v in raw.items()}
        return {}

    @property
    def extensions_map(self) -> dict[str, object]:
        """Extensions block from spec."""
        raw = self.spec.get("extensions")
        if isinstance(raw, dict):
            return dict(raw)
        return {}

    @property
    def markdown_body(self) -> str | None:
        """Markdown body content (set during markdown file parsing)."""
        raw = self.spec.get("_markdown_body")
        return str(raw) if raw is not None else None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a dictionary (for YAML/JSON output)."""
        result: dict[str, Any] = {
            "apiVersion": self.api_version,
            "kind": self.kind,
            "metadata": {
                "name": self.metadata.name,
            },
            "spec": dict(self.spec),
        }
        if self.metadata.labels:
            result["metadata"]["labels"] = dict(self.metadata.labels)
        if self.metadata.annotations:
            result["metadata"]["annotations"] = dict(self.metadata.annotations)
        if self.extends is not None:
            result["spec"]["extends"] = {
                "targetKind": self.extends.target_kind,
                "targetNames": list(self.extends.target_names),
            }
        if self.activation:
            result["metadata"]["requires"] = [
                {"kind": req.kind, "name": req.name, "mode": req.mode} for req in self.activation
            ]
        return result

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
        *,
        source_path: Path | None = None,
    ) -> Document:
        """Deserialize from a dictionary (from YAML/JSON).

        Handles both v1alpha and v2alpha formats:
        - v2: ``kind`` is the node type directly
        - v1: ``kind: TaxonomyNode`` + ``taxonomyNodeType`` field
        """
        metadata_raw = data.get("metadata", {})
        spec_raw = dict(data.get("spec", {}))

        # Determine kind — handle v1 format where kind is "TaxonomyNode"
        api_version = data.get("apiVersion", "")
        kind = data.get("kind", "")
        if kind == "TaxonomyNode" and "taxonomyNodeType" in data:
            kind = str(data["taxonomyNodeType"])
            api_version = V2_API_VERSION  # normalize to v2

        # Parse extension target from spec if present
        extends: ExtensionTarget | None = None
        extends_raw = spec_raw.pop("extends", None)
        if extends_raw and isinstance(extends_raw, dict):
            extends = ExtensionTarget(
                target_kind=extends_raw["targetKind"],
                target_names=tuple(extends_raw.get("targetNames", [])),
            )

        # Parse activation requirements from metadata if present
        activation: tuple[ActivationRequirement, ...] | None = None
        requires_raw = metadata_raw.get("requires")
        if requires_raw and isinstance(requires_raw, list):
            activation = tuple(
                ActivationRequirement(
                    kind=req["kind"],
                    name=req["name"],
                    mode=req.get("mode", "required"),
                )
                for req in requires_raw
            )

        return cls(
            api_version=api_version or V2_API_VERSION,
            kind=kind,
            metadata=Metadata(
                name=metadata_raw.get("name", ""),
                labels=metadata_raw.get("labels", {}),
                annotations=metadata_raw.get("annotations", {}),
            ),
            spec=spec_raw,
            source_path=source_path,
            extends=extends,
            activation=activation,
        )
