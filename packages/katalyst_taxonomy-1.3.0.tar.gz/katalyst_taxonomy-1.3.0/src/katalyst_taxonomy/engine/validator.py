"""Schema validation — validates document specs against JSON Schema.

Uses ``jsonschema`` for validation, loading per-kind schemas from the
generated schemas directory.
"""

# pyright: reportUnknownMemberType=false

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import jsonschema

from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.registry import NodeTypeRegistry


@dataclass(frozen=True, slots=True)
class ValidationIssue:
    """A single validation issue found in a document."""

    path: str
    message: str
    severity: str = "error"  # "error" | "warning"

    def __str__(self) -> str:
        if self.path:
            return f"{self.path}: {self.message}"
        return self.message


@dataclass(frozen=True, slots=True)
class ValidationResult:
    """Result of validating a document against its schema."""

    document_name: str
    document_kind: str
    issues: tuple[ValidationIssue, ...] = ()

    @property
    def is_valid(self) -> bool:
        """Whether validation passed with no errors."""
        return not any(i.severity == "error" for i in self.issues)

    @property
    def errors(self) -> tuple[ValidationIssue, ...]:
        """Return only error-level issues."""
        return tuple(i for i in self.issues if i.severity == "error")

    @property
    def warnings(self) -> tuple[ValidationIssue, ...]:
        """Return only warning-level issues."""
        return tuple(i for i in self.issues if i.severity == "warning")


class SchemaValidator:
    """Validates documents against per-kind JSON Schemas.

    Loads schemas lazily from the generated schemas directory.
    """

    def __init__(
        self,
        registry: NodeTypeRegistry,
        schemas_dir: Path,
    ) -> None:
        self._registry = registry
        self._schemas_dir = schemas_dir
        self._schema_cache: dict[str, dict[str, Any]] = {}

    def validate(self, document: Document) -> ValidationResult:
        """Validate a document's spec against its kind's JSON Schema."""
        issues: list[ValidationIssue] = []

        # Check kind is registered
        descriptor = self._registry.get(document.kind)
        if descriptor is None:
            issues.append(
                ValidationIssue(
                    path="kind",
                    message=f"Unknown node type: {document.kind!r}",
                )
            )
            return ValidationResult(
                document_name=document.name,
                document_kind=document.kind,
                issues=tuple(issues),
            )

        # Load schema
        schema = self._load_schema(descriptor.schema_path)
        if schema is None:
            issues.append(
                ValidationIssue(
                    path="",
                    message=f"Schema not found: {descriptor.schema_path}",
                    severity="warning",
                )
            )
            return ValidationResult(
                document_name=document.name,
                document_kind=document.kind,
                issues=tuple(issues),
            )

        # Validate spec against schema
        validator = jsonschema.Draft202012Validator(schema)
        for error in validator.iter_errors(dict(document.spec)):
            path = ".".join(str(p) for p in error.absolute_path) if error.absolute_path else ""
            issues.append(ValidationIssue(path=path, message=error.message))

        # Structural validation: extension documents must have extends
        if descriptor.is_extension and document.extends is None:
            issues.append(
                ValidationIssue(
                    path="spec.extends",
                    message=(
                        f"Node type {document.kind!r} is an extension type "
                        "and must declare spec.extends"
                    ),
                )
            )

        # Structural validation: check extends.targetKind is valid
        if document.extends is not None and descriptor.extends_kinds:
            if document.extends.target_kind not in descriptor.extends_kinds:
                issues.append(
                    ValidationIssue(
                        path="spec.extends.targetKind",
                        message=(
                            f"Extension {document.kind!r} cannot target "
                            f"{document.extends.target_kind!r}. "
                            f"Allowed: {descriptor.extends_kinds}"
                        ),
                    )
                )

        return ValidationResult(
            document_name=document.name,
            document_kind=document.kind,
            issues=tuple(issues),
        )

    def validate_many(self, documents: tuple[Document, ...]) -> tuple[ValidationResult, ...]:
        """Validate multiple documents."""
        return tuple(self.validate(doc) for doc in documents)

    def _load_schema(self, schema_path: str) -> dict[str, Any] | None:
        """Load a JSON Schema, caching by path."""
        if schema_path in self._schema_cache:
            return self._schema_cache[schema_path]

        full_path = self._schemas_dir / schema_path
        if not full_path.exists():
            return None

        with open(full_path) as f:
            schema = json.load(f)

        self._schema_cache[schema_path] = schema
        return schema
