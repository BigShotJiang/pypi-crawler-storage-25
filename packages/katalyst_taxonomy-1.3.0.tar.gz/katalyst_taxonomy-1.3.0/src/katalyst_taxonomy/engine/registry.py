"""Node type registry — loaded from generated registry.json.

The registry is the single source of truth for all node type metadata
at runtime. It replaces every hardcoded type list in the v1 codebase.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, cast


@dataclass(frozen=True, slots=True)
class RelationshipType:
    """Describes a relationship type in the taxonomy graph."""

    name: str
    description: str
    source_base: str | None = None
    target_base: str | None = None
    cardinality: str | None = None
    activation_supported: bool = False


@dataclass(frozen=True, slots=True)
class NodeTypeDescriptor:
    """Complete description of a node type, extracted from LinkML annotations.

    This is the runtime representation of a node type — the engine uses
    this to drive validation, discovery, FQTN resolution, display ordering,
    and extension resolution without any hardcoded type knowledge.
    """

    kind: str
    class_name: str
    schema_path: str
    wing: str
    display_order: int
    directory_name: str
    parent_types: tuple[str, ...] | None
    is_leaf: bool
    is_root: bool
    is_extension: bool
    extends_kinds: tuple[str, ...] | None
    parent_required: bool = False
    cross_references: tuple[tuple[str, str, str | None], ...] | None = None

    @property
    def has_parent(self) -> bool:
        """Whether this node type can have a parent."""
        return self.parent_types is not None and len(self.parent_types) > 0


def _parse_cross_references(
    raw: dict[str, Any],
) -> tuple[tuple[str, str, str | None], ...]:
    """Parse cross_references from JSON into typed tuples."""
    result: list[tuple[str, str, str | None]] = []
    for k, v in raw.items():
        if isinstance(v, dict):
            v_dict = cast(dict[str, object], v)
            target = str(v_dict["target"])
            rel_type_raw = v_dict.get("rel_type")
            rel_type: str | None = str(rel_type_raw) if rel_type_raw else None
            result.append((k, target, rel_type))
        else:
            result.append((k, str(v), None))
    return tuple(result)


class NodeTypeRegistry:
    """Registry of all known node types, loaded from generated/registry.json.

    Replaces:
    - PARENT_NODE_TYPES dict
    - ByKindStrategy hardcoded directory names
    - CreationService._validate_request() type set
    - sorted_documents() type order
    - _PLUGIN_CONFIGS in linter
    """

    def __init__(
        self,
        descriptors: Mapping[str, NodeTypeDescriptor],
        relationship_types: Mapping[str, RelationshipType] | None = None,
        version: str = "1.0.0",
    ) -> None:
        self._descriptors: dict[str, NodeTypeDescriptor] = dict(descriptors)
        self._relationship_types: dict[str, RelationshipType] = dict(relationship_types or {})
        self._version = version

        # Pre-compute indexes for fast lookup
        self._by_wing: dict[str, list[NodeTypeDescriptor]] = {}
        self._by_directory: dict[str, NodeTypeDescriptor] = {}
        self._extension_index: dict[str, list[str]] = {}

        for kind, desc in self._descriptors.items():
            self._by_wing.setdefault(desc.wing, []).append(desc)
            self._by_directory[desc.directory_name] = desc
            if desc.extends_kinds:
                for target_kind in desc.extends_kinds:
                    self._extension_index.setdefault(target_kind, []).append(kind)

    @property
    def version(self) -> str:
        """Return the registry version."""
        return self._version

    def __contains__(self, kind: str) -> bool:
        """Check if a kind is registered."""
        return kind in self._descriptors

    def __len__(self) -> int:
        """Return the number of registered types."""
        return len(self._descriptors)

    def get(self, kind: str) -> NodeTypeDescriptor | None:
        """Get the descriptor for a node type, or None if not registered."""
        return self._descriptors.get(kind)

    def require(self, kind: str) -> NodeTypeDescriptor:
        """Get the descriptor for a node type, raising if not found."""
        desc = self._descriptors.get(kind)
        if desc is None:
            raise KeyError(f"Unknown node type: {kind!r}")
        return desc

    def all_kinds(self) -> tuple[str, ...]:
        """Return all registered kind names."""
        return tuple(self._descriptors.keys())

    def all_descriptors(self) -> tuple[NodeTypeDescriptor, ...]:
        """Return all registered descriptors."""
        return tuple(self._descriptors.values())

    def allowed_parents(self, kind: str) -> tuple[str, ...] | None:
        """Return allowed parent types for a kind, or None for root types."""
        desc = self._descriptors.get(kind)
        if desc is None:
            return None
        return desc.parent_types

    def is_root(self, kind: str) -> bool:
        """Whether this kind is a root node (no parents)."""
        desc = self._descriptors.get(kind)
        return desc.is_root if desc else False

    def is_leaf(self, kind: str) -> bool:
        """Whether this kind is a leaf node (no children)."""
        desc = self._descriptors.get(kind)
        return desc.is_leaf if desc else False

    def is_extension(self, kind: str) -> bool:
        """Whether this kind is a NodeExtension subtype."""
        desc = self._descriptors.get(kind)
        return desc.is_extension if desc else False

    def kinds_in_wing(self, wing: str) -> tuple[str, ...]:
        """Return all kinds belonging to a wing, sorted by display order."""
        descs = self._by_wing.get(wing, [])
        return tuple(d.kind for d in sorted(descs, key=lambda d: d.display_order))

    def wings(self) -> tuple[str, ...]:
        """Return all known wing names."""
        return tuple(sorted(self._by_wing.keys()))

    def sorted_kinds(self) -> tuple[str, ...]:
        """Return all kinds sorted by display order."""
        return tuple(
            d.kind for d in sorted(self._descriptors.values(), key=lambda d: d.display_order)
        )

    def extensions_for_kind(self, target_kind: str) -> tuple[str, ...]:
        """Return extension kinds that can target the given kind."""
        return tuple(self._extension_index.get(target_kind, []))

    def kind_for_directory(self, directory_name: str) -> str | None:
        """Reverse lookup: directory name → kind."""
        desc = self._by_directory.get(directory_name)
        return desc.kind if desc else None

    def relationship_types(self) -> tuple[RelationshipType, ...]:
        """Return all known relationship types."""
        return tuple(self._relationship_types.values())

    def get_relationship_type(self, name: str) -> RelationshipType | None:
        """Get a relationship type by name."""
        return self._relationship_types.get(name)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the registry to a dictionary (for JSON output)."""
        return {
            "version": self._version,
            "node_types": {
                kind: {
                    "class_name": desc.class_name,
                    "schema": desc.schema_path,
                    "wing": desc.wing,
                    "display_order": desc.display_order,
                    "directory_name": desc.directory_name,
                    "parent_types": list(desc.parent_types) if desc.parent_types else None,
                    "is_leaf": desc.is_leaf,
                    "is_root": desc.is_root,
                    "is_extension": desc.is_extension,
                    "extends_kinds": (list(desc.extends_kinds) if desc.extends_kinds else None),
                    "parent_required": desc.parent_required,
                    "cross_references": (
                        {
                            attr: {"target": target, "rel_type": rel_type}
                            for attr, target, rel_type in desc.cross_references
                        }
                        if desc.cross_references
                        else None
                    ),
                }
                for kind, desc in self._descriptors.items()
            },
            "relationship_types": {
                name: {
                    "description": rt.description,
                    "source_base": rt.source_base,
                    "target_base": rt.target_base,
                    "cardinality": rt.cardinality,
                    "activation_supported": rt.activation_supported,
                }
                for name, rt in self._relationship_types.items()
            },
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NodeTypeRegistry:
        """Deserialize a registry from a dictionary (from JSON)."""
        version = data.get("version", "1.0.0")
        descriptors: dict[str, NodeTypeDescriptor] = {}

        for kind, info in data.get("node_types", {}).items():
            parent_types_raw = info.get("parent_types")
            extends_kinds_raw = info.get("extends_kinds")
            descriptors[kind] = NodeTypeDescriptor(
                kind=kind,
                class_name=info["class_name"],
                schema_path=info["schema"],
                wing=info["wing"],
                display_order=info["display_order"],
                directory_name=info["directory_name"],
                parent_types=(tuple(parent_types_raw) if parent_types_raw is not None else None),
                is_leaf=info.get("is_leaf", False),
                is_root=info.get("is_root", False),
                is_extension=info.get("is_extension", False),
                extends_kinds=(tuple(extends_kinds_raw) if extends_kinds_raw is not None else None),
                parent_required=info.get("parent_required", False),
                cross_references=(
                    _parse_cross_references(info["cross_references"])
                    if info.get("cross_references")
                    else None
                ),
            )

        relationship_types: dict[str, RelationshipType] = {}
        for name, rt_info in data.get("relationship_types", {}).items():
            relationship_types[name] = RelationshipType(
                name=name,
                description=rt_info["description"],
                source_base=rt_info.get("source_base"),
                target_base=rt_info.get("target_base"),
                cardinality=rt_info.get("cardinality"),
                activation_supported=rt_info.get("activation_supported", False),
            )

        return cls(
            descriptors=descriptors,
            relationship_types=relationship_types,
            version=version,
        )

    @classmethod
    def from_json(cls, path: Path) -> NodeTypeRegistry:
        """Load a registry from a JSON file."""
        with open(path) as f:
            data = json.load(f)
        return cls.from_dict(data)

    @classmethod
    def empty(cls) -> NodeTypeRegistry:
        """Create an empty registry (useful for testing)."""
        return cls(descriptors={})

    @classmethod
    def merge(cls, *registries: NodeTypeRegistry) -> NodeTypeRegistry:
        """Merge multiple registries. Later registries override earlier ones."""
        descriptors: dict[str, NodeTypeDescriptor] = {}
        relationship_types: dict[str, RelationshipType] = {}
        version = "1.0.0"

        for registry in registries:
            descriptors.update(registry._descriptors)
            relationship_types.update(registry._relationship_types)
            version = registry._version

        return cls(
            descriptors=descriptors,
            relationship_types=relationship_types,
            version=version,
        )
