"""FQTN resolver — computes fully qualified taxonomy names.

This is the registry-driven replacement for the hardcoded
``build_qualified_names()`` and ``PARENT_NODE_TYPES`` in v1.
"""

# pyright: reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

from typing import Mapping, Sequence

from katalyst_taxonomy.engine.document import Document
from katalyst_taxonomy.engine.registry import NodeTypeRegistry


def document_lookup_key(document: Document) -> str:
    """Generate a stable lookup key for a document within qualified-name caches."""
    parent = ""
    if "parents" in document.spec and isinstance(document.spec["parents"], dict):
        parent = document.spec["parents"].get("node", "")
    elif "parent" in document.spec:
        parent = str(document.spec.get("parent", ""))
    source = str(document.source_path) if document.source_path else ""
    return f"{document.kind}:{parent}:{document.name}:{source}"


def qualified_name_for(document: Document, qualified_names: Mapping[str, str]) -> str:
    """Return the fully qualified taxonomy name for a document if known."""
    return qualified_names.get(document_lookup_key(document), document.name)


def build_qualified_names(
    documents: Sequence[Document],
    registry: NodeTypeRegistry,
) -> dict[str, str]:
    """Build a mapping of document lookup keys to fully qualified names.

    This is the registry-driven equivalent of the v1 ``build_qualified_names()``.
    Parent type rules come from the registry instead of a hardcoded dict.
    """
    # Build index: (kind, name) -> list of documents
    index: dict[tuple[str, str], list[Document]] = {}
    for doc in documents:
        key = (doc.kind, doc.name)
        index.setdefault(key, []).append(doc)

    cache: dict[str, str] = {}
    in_progress: set[str] = set()

    def _get_parent_ref(doc: Document) -> str | None:
        """Extract parent reference from spec (supports both v1 and v2 shapes)."""
        # v2 shape: spec.parent
        if "parent" in doc.spec and isinstance(doc.spec["parent"], str):
            return doc.spec["parent"] or None
        # v1 shape: spec.parents.node
        parents = doc.spec.get("parents")
        if isinstance(parents, dict):
            node = parents.get("node")
            return str(node) if node else None
        return None

    def resolve(doc: Document) -> str:
        key = document_lookup_key(doc)
        if key in cache:
            return cache[key]
        if key in in_progress:
            cache[key] = doc.name
            return cache[key]
        in_progress.add(key)

        parent_fq = ""
        parent_types = registry.allowed_parents(doc.kind)
        parent_ref = _get_parent_ref(doc)

        if parent_types and parent_ref:
            # Collect candidates across all allowed parent types
            candidates: list[Document] = []
            for pt in parent_types:
                candidates.extend(index.get((pt, parent_ref), []))

            selected = _select_parent(doc, candidates)
            if selected:
                parent_fq = resolve(selected)
            elif candidates:
                parent_fq = resolve(candidates[0])
            else:
                parent_fq = parent_ref

        fqtn = f"{parent_fq}.{doc.name}" if parent_fq else doc.name
        cache[key] = fqtn
        in_progress.remove(key)
        return fqtn

    for doc in documents:
        resolve(doc)

    return cache


def _select_parent(
    document: Document,
    candidates: list[Document],
) -> Document | None:
    """Select the best parent candidate based on filesystem proximity."""
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]

    best: Document | None = None
    best_score: tuple[int, int] | None = None

    for candidate in candidates:
        score = _parent_match_score(document, candidate)
        if score is None:
            continue
        if best_score is None or score < best_score:
            best = candidate
            best_score = score
        elif score == best_score:
            if best is not None and candidate.source_path and best.source_path:
                if str(candidate.source_path) < str(best.source_path):
                    best = candidate

    return best


def _parent_match_score(
    document: Document,
    candidate: Document,
) -> tuple[int, int] | None:
    """Calculate proximity score between document and potential parent."""
    if document.source_path is None or candidate.source_path is None:
        return None

    doc_parent = document.source_path.parent
    candidate_dir = candidate.source_path.parent

    try:
        relative = doc_parent.relative_to(candidate_dir)
    except ValueError:
        return None

    distance = len(relative.parts)
    depth = len(candidate_dir.parts)
    return (distance, depth)
