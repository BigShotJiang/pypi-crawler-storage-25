"""Migration tool — rewrites v1alpha taxonomy YAML to v2alpha format.

Usage:
    kata tax migrate --path <repo-root> [--dry-run]

Transforms:
    - apiVersion: katalyst.taxonomy/v1alpha  →  katalyst.taxonomy/v2alpha
    - kind: TaxonomyNode  →  <taxonomyNodeType value>
    - Removes top-level taxonomyNodeType field (merged into kind)
    - Restructures spec for v2 schema compatibility
"""

# pyright: reportUnknownMemberType=false
# pyright: reportUnknownVariableType=false
# pyright: reportUnknownArgumentType=false

from __future__ import annotations

import copy
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml
from loguru import logger


@dataclass(frozen=True, slots=True)
class MigrationResult:
    """Result of migrating a single file."""

    path: Path
    documents_migrated: int
    already_v2: int
    skipped: int
    error: str | None = None


V1_API_VERSION = "katalyst.taxonomy/v1alpha"
V2_API_VERSION = "katalyst.taxonomy/v2alpha"


def migrate_document(doc: dict[str, Any]) -> dict[str, Any] | None:
    """Migrate a single YAML document dict from v1 to v2 format.

    Returns the migrated document, or None if it's not a v1 taxonomy doc.
    """
    api_version = doc.get("apiVersion", "")
    kind = doc.get("kind", "")

    # Already v2
    if api_version == V2_API_VERSION:
        return None

    # Not a v1 taxonomy doc
    if api_version != V1_API_VERSION:
        return None
    if kind != "TaxonomyNode":
        return None

    node_type = doc.get("taxonomyNodeType", "")
    if not node_type:
        return None

    # Build the v2 document
    migrated: dict[str, Any] = {
        "apiVersion": V2_API_VERSION,
        "kind": node_type,
    }

    # Copy metadata
    if "metadata" in doc:
        migrated["metadata"] = copy.deepcopy(doc["metadata"])

    # Copy spec
    if "spec" in doc:
        migrated["spec"] = copy.deepcopy(doc["spec"])

    return migrated


def migrate_file(
    path: Path,
    *,
    dry_run: bool = False,
    backup: bool = True,
) -> MigrationResult:
    """Migrate a single YAML file from v1 to v2 format.

    Args:
        path: Path to the YAML file.
        dry_run: If True, don't write changes.
        backup: If True, create a .bak file before overwriting.

    Returns:
        MigrationResult with counts and any errors.
    """
    if not path.exists():
        return MigrationResult(
            path=path,
            documents_migrated=0,
            already_v2=0,
            skipped=0,
            error=f"File not found: {path}",
        )

    try:
        content = path.read_text(encoding="utf-8")
        documents = list(yaml.safe_load_all(content))
    except Exception as e:
        return MigrationResult(
            path=path,
            documents_migrated=0,
            already_v2=0,
            skipped=0,
            error=f"Failed to parse {path}: {e}",
        )

    migrated_count = 0
    already_v2_count = 0
    skipped_count = 0
    output_docs: list[dict[str, Any]] = []

    for doc in documents:
        if not isinstance(doc, dict):
            skipped_count += 1
            continue

        api_version = doc.get("apiVersion", "")
        if api_version == V2_API_VERSION:
            already_v2_count += 1
            output_docs.append(doc)
            continue

        migrated = migrate_document(doc)
        if migrated is None:
            skipped_count += 1
            output_docs.append(doc)
            continue

        migrated_count += 1
        output_docs.append(migrated)

    if migrated_count == 0:
        return MigrationResult(
            path=path,
            documents_migrated=0,
            already_v2=already_v2_count,
            skipped=skipped_count,
        )

    if dry_run:
        return MigrationResult(
            path=path,
            documents_migrated=migrated_count,
            already_v2=already_v2_count,
            skipped=skipped_count,
        )

    # Write the migrated file
    if backup:
        backup_path = path.with_suffix(path.suffix + ".bak")
        path.rename(backup_path)

    with path.open("w", encoding="utf-8") as f:
        yaml.safe_dump_all(output_docs, f, sort_keys=False)

    return MigrationResult(
        path=path,
        documents_migrated=migrated_count,
        already_v2=already_v2_count,
        skipped=skipped_count,
    )


def migrate_directory(
    directory: Path,
    *,
    dry_run: bool = False,
    backup: bool = True,
) -> list[MigrationResult]:
    """Migrate all YAML files in a directory tree from v1 to v2.

    Args:
        directory: Root directory to scan.
        dry_run: If True, don't write changes.
        backup: If True, create .bak files before overwriting.

    Returns:
        List of MigrationResult for each processed file.
    """
    results: list[MigrationResult] = []

    for ext in ("*.yaml", "*.yml"):
        for path in sorted(directory.rglob(ext)):
            result = migrate_file(path, dry_run=dry_run, backup=backup)
            if result.documents_migrated > 0 or result.error:
                results.append(result)
                if result.error:
                    logger.warning("Migration error in {}: {}", path, result.error)
                else:
                    action = "Would migrate" if dry_run else "Migrated"
                    logger.info(
                        "{} {} documents in {}",
                        action,
                        result.documents_migrated,
                        path,
                    )

    return results
