# Agent Instructions for {{ layer_name }}

## Layer Context

- **Layer Name:** {{ layer_name }}
- **Layer Type:** {{ layer_type }}
- **Description:** {{ description }}

## Working Principles

When modifying this layer, follow these principles:

1. Run existing tests before and after making changes
2. Follow the established patterns in this layer type
3. Check for environment-specific configurations
4. Use `kata tax action run` to execute layer actions
