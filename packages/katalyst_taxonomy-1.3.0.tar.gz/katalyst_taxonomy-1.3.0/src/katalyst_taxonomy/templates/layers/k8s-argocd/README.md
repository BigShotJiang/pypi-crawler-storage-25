# {{ system_name }}/{{ stack_name }}/k8s layer

Layer type: argocd

Structure mirrors the existing Kubernetes layers:

- `layer.yaml` – taxonomy descriptor.
- `base/` – manifests shared across environments.
- `<environment>/` – Argo CD application overlays (kustomize patches, parameters).

Copy the `environment-template/` directory for each target environment and update
the placeholders in `patch-argocd-application.yaml`.

<!-- BEGIN AUTO-LAYER -->
<!-- This section is managed by scripts. Manual edits inside may be overwritten. -->
<!-- END AUTO-LAYER -->
