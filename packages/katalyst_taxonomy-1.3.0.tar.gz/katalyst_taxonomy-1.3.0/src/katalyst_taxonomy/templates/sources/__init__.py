"""Template source adapters for fetching templates from various locations."""

from katalyst_taxonomy.templates.sources.git import GitRepoSource
from katalyst_taxonomy.templates.sources.github import GitHubPagesSource, GitHubSource
from katalyst_taxonomy.templates.sources.local import LocalFilesystemSource
from katalyst_taxonomy.templates.sources.protocol import (
    FetchResult,
    PackageInfo,
    PackageManifest,
    SourceManifest,
    TemplateSource,
    create_source,
    parse_source_uri,
)

__all__ = [
    # Protocol and data classes
    "TemplateSource",
    "SourceManifest",
    "PackageInfo",
    "PackageManifest",
    "FetchResult",
    "parse_source_uri",
    "create_source",
    # Adapters
    "LocalFilesystemSource",
    "GitHubSource",
    "GitHubPagesSource",
    "GitRepoSource",
]
