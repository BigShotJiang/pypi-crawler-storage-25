"""Route handlers for Katalyst server."""

from katalyst_taxonomy.server.routes import events, taxonomy

__all__ = ["events", "taxonomy"]
