"""Server state management for ~/.katalyst directory."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any


def get_state_dir() -> Path:
    """Get the katalyst state directory (~/.katalyst)."""
    return Path.home() / ".katalyst"


def ensure_state_dir() -> Path:
    """Ensure the state directory exists and return its path."""
    state_dir = get_state_dir()
    state_dir.mkdir(parents=True, exist_ok=True)
    return state_dir


@dataclass
class ServerState:
    """Server state information stored in ~/.katalyst/server.json."""

    pid: int
    port: int
    host: str
    path: str
    started_at: str  # ISO format timestamp

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "pid": self.pid,
            "port": self.port,
            "host": self.host,
            "path": self.path,
            "started_at": self.started_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ServerState:
        """Create from dictionary."""
        return cls(
            pid=data["pid"],
            port=data["port"],
            host=data["host"],
            path=data["path"],
            started_at=data["started_at"],
        )

    @classmethod
    def create(cls, pid: int, port: int, host: str, path: Path) -> ServerState:
        """Create a new server state with current timestamp."""
        return cls(
            pid=pid,
            port=port,
            host=host,
            path=str(path.resolve()),
            started_at=datetime.now().isoformat(),
        )

    @property
    def url(self) -> str:
        """Get the server URL."""
        return f"http://{self.host}:{self.port}"


def get_state_file() -> Path:
    """Get the path to the server state file."""
    return get_state_dir() / "server.json"


def save_server_state(state: ServerState) -> None:
    """Save server state to disk."""
    state_file = get_state_file()
    ensure_state_dir()
    state_file.write_text(json.dumps(state.to_dict(), indent=2))


def load_server_state() -> ServerState | None:
    """Load server state from disk, or None if not found."""
    state_file = get_state_file()
    if not state_file.exists():
        return None
    try:
        data = json.loads(state_file.read_text())
        return ServerState.from_dict(data)
    except (json.JSONDecodeError, KeyError, TypeError):
        return None


def clear_server_state() -> None:
    """Remove the server state file."""
    state_file = get_state_file()
    if state_file.exists():
        state_file.unlink()


def is_process_running(pid: int) -> bool:
    """Check if a process with the given PID is running."""
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False
