"""Entry point for running the server."""

from __future__ import annotations

import argparse
import os
from pathlib import Path

import uvicorn
from loguru import logger

from katalyst_taxonomy.server.app import create_app
from katalyst_taxonomy.server.state import ServerState, save_server_state

DEFAULT_IDLE_TIMEOUT = 300  # 5 minutes


def main() -> None:
    """Run the Katalyst server."""
    parser = argparse.ArgumentParser(description="Katalyst Taxonomy Server")
    parser.add_argument(
        "--path",
        type=Path,
        default=Path.cwd(),
        help="Path to taxonomy directory (default: current directory)",
    )
    parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to bind to (default: 8000)",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload for development",
    )
    parser.add_argument(
        "--idle-timeout",
        type=int,
        default=DEFAULT_IDLE_TIMEOUT,
        help=f"Idle timeout in seconds before auto-shutdown (default: {DEFAULT_IDLE_TIMEOUT}, 0 to disable)",
    )
    parser.add_argument(
        "--background",
        action="store_true",
        help="Run in background mode (used by server manager)",
    )

    args = parser.parse_args()

    resolved_path = args.path.resolve()

    # Save server state for the manager to track
    state = ServerState.create(
        pid=os.getpid(),
        port=args.port,
        host=args.host,
        path=resolved_path,
    )
    save_server_state(state)

    if args.background:
        # Suppress uvicorn logging in background mode
        log_config = {
            "version": 1,
            "disable_existing_loggers": True,
            "handlers": {},
            "loggers": {"uvicorn": {"level": "WARNING"}, "uvicorn.error": {"level": "WARNING"}},
        }
    else:
        log_config = None
        logger.info(f"Starting Katalyst server on {args.host}:{args.port}")
        logger.info(f"Taxonomy path: {resolved_path}")
        if args.idle_timeout > 0:
            logger.info(f"Idle timeout: {args.idle_timeout}s")
        else:
            logger.info("Idle timeout: disabled")

    app = create_app(base_path=resolved_path, idle_timeout=args.idle_timeout)

    uvicorn_kwargs: dict[str, object] = {
        "host": args.host,
        "port": args.port,
    }

    if log_config is not None:
        uvicorn_kwargs["log_config"] = log_config

    if args.reload:
        uvicorn_kwargs["reload"] = True

    uvicorn.run(app, **uvicorn_kwargs)  # type: ignore[arg-type]


if __name__ == "__main__":
    main()
