"""Shared YAML frontmatter parsing for markdown files.

Provides functions to split a markdown file into its YAML frontmatter and
body content, and to serialize them back.

The frontmatter format is::

    ---
    key: value
    ---

    Body content here...

An alternative closing delimiter (``...``) is also supported.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

__all__ = [
    "ParseError",
    "parse_frontmatter",
    "serialize_frontmatter",
]

# Regex pattern for frontmatter delimiters
# Matches: --- at start of file, followed by content, followed by --- or ...
FRONTMATTER_PATTERN = re.compile(
    r"^---\s*\n(.*?)\n---\s*\n?(.*)$",
    re.DOTALL,
)

# Alternative pattern with ... as closing delimiter
FRONTMATTER_PATTERN_ALT = re.compile(
    r"^---\s*\n(.*?)\n\.\.\.\s*\n?(.*)$",
    re.DOTALL,
)


class ParseError(Exception):
    """Error parsing a markdown frontmatter file."""

    def __init__(self, message: str, path: Path | None = None, line: int | None = None):
        self.path = path
        self.line = line
        location = ""
        if path:
            location = f" in {path}"
        if line:
            location += f" at line {line}"
        super().__init__(f"{message}{location}")


def parse_frontmatter(content: str, path: Path | None = None) -> tuple[dict[str, Any], str]:
    """Parse YAML frontmatter from markdown content.

    Args:
        content: The full markdown content with frontmatter.
        path: Optional path for error messages.

    Returns:
        A tuple of (frontmatter_dict, body_content).

    Raises:
        ParseError: If the frontmatter is missing or malformed.
    """
    content = content.lstrip()

    # Try standard --- delimiter
    match = FRONTMATTER_PATTERN.match(content)
    if not match:
        # Try ... closing delimiter
        match = FRONTMATTER_PATTERN_ALT.match(content)

    if not match:
        # Check if file starts with ---
        if content.startswith("---"):
            raise ParseError("Frontmatter not properly closed (missing --- or ...)", path)
        raise ParseError("No frontmatter found (file must start with ---)", path)

    frontmatter_str: str = match.group(1)
    body: str = match.group(2)

    try:
        frontmatter = yaml.safe_load(frontmatter_str)
    except yaml.YAMLError as e:
        raise ParseError(f"Invalid YAML in frontmatter: {e}", path) from e

    if frontmatter is None:
        frontmatter = {}

    if not isinstance(frontmatter, dict):
        raise ParseError(f"Frontmatter must be a mapping, got {type(frontmatter).__name__}", path)

    return frontmatter, body.strip()  # type: ignore[return-value]


def serialize_frontmatter(data: dict[str, Any], body: str = "") -> str:
    """Serialize a dict and body string into markdown with YAML frontmatter.

    Args:
        data: The frontmatter mapping to serialize as YAML.
        body: The markdown body content (placed after the closing ``---``).

    Returns:
        The complete markdown content with frontmatter.
    """
    yaml_str = yaml.dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True)

    parts = ["---", yaml_str.rstrip(), "---", ""]
    if body:
        parts.append(body)

    return "\n".join(parts)
