


import plotly.graph_objects as go
import numpy as np

def obtener_estructura(modelo):
    estructura = []

    for capa in modelo.capas:  # ajusta si usas otro nombre
        if hasattr(capa, "out_features"):
            if len(estructura) == 0:
                estructura.append(capa.in_features)
            estructura.append(capa.out_features)

    return estructura


def dibujar_red_desde_modelo(modelo):
    estructura = obtener_estructura(modelo)

    pos = {}
    edges = []
    separacion_x = 4

    # posiciones
    for i, n_neuronas in enumerate(estructura):
        for j in range(n_neuronas):
            x = i * separacion_x
            y = (j - n_neuronas / 2) * 1.5
            z = 0
            pos[(i, j)] = (x, y, z)

    # conexiones
    for i in range(len(estructura) - 1):
        for j in range(estructura[i]):
            for k in range(estructura[i + 1]):
                edges.append(((i, j), (i + 1, k)))

    # nodos
    x_nodes, y_nodes, z_nodes, colores = [], [], [], []

    for (i, j), (x, y, z) in pos.items():
        x_nodes.append(x)
        y_nodes.append(y)
        z_nodes.append(z)

        if i == 0:
            colores.append("blue")
        elif i == len(estructura) - 1:
            colores.append("green")
        else:
            colores.append("red")

    # líneas y flechas
    x_edges, y_edges, z_edges = [], [], []
    x_cone, y_cone, z_cone = [], [], []
    u_cone, v_cone, w_cone = [], [], []

    L = 0.8

    for (n1, n2) in edges:
        x0, y0, z0 = pos[n1]
        x1, y1, z1 = pos[n2]

        x_edges += [x0, x1, None]
        y_edges += [y0, y1, None]
        z_edges += [z0, z1, None]

        dx, dy, dz = x1 - x0, y1 - y0, z1 - z0
        norm = np.sqrt(dx**2 + dy**2 + dz**2)

        if norm == 0:
            continue

        ux, uy, uz = dx / norm, dy / norm, dz / norm
        offset = 0.7

        x_cone.append(x1 - ux * offset)
        y_cone.append(y1 - uy * offset)
        z_cone.append(z1 - uz * offset)

        u_cone.append(ux * L)
        v_cone.append(uy * L)
        w_cone.append(uz * L)

    fig = go.Figure()

    fig.add_trace(go.Scatter3d(
        x=x_edges, y=y_edges, z=z_edges,
        mode='lines',
        line=dict(width=2, color='gray'),
        hoverinfo='none'
    ))

    fig.add_trace(go.Cone(
        x=x_cone, y=y_cone, z=z_cone,
        u=u_cone, v=v_cone, w=w_cone,
        sizemode="absolute",
        sizeref=0.2,
        showscale=False,
        colorscale=[[0, 'black'], [1, 'black']]
    ))

    fig.add_trace(go.Scatter3d(
        x=x_nodes, y=y_nodes, z=z_nodes,
        mode='markers',
        marker=dict(size=8, color=colores),
        hoverinfo='none'
    ))

    fig.update_layout(
        scene=dict(
            xaxis=dict(visible=False),
            yaxis=dict(visible=False),
            zaxis=dict(visible=False)
        ),
        margin=dict(l=0, r=0, b=0, t=40),
        title=f"Arquitectura: {estructura}"
    )

    fig.show()