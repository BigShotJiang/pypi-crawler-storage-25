import numpy as np

def train_test_split(X, y, test_size=0.2, shuffle=True):
    n = len(X)

    indices = np.arange(n)

    if shuffle:
        np.random.shuffle(indices)

    test_count = int(n * test_size)

    test_idx = indices[:test_count]
    train_idx = indices[test_count:]

    X_train = X[train_idx]
    y_train = y[train_idx]

    X_test = X[test_idx]
    y_test = y[test_idx]

    return X_train, X_test, y_train, y_test