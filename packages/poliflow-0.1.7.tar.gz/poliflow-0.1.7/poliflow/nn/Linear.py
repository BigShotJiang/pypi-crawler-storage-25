import numpy as np
from .Module import Module
from ..core.Tensor import Tensor


class Linear(Module):
    
    def __init__(self, in_features, out_features):
        super().__init__()
        
        # Inicialización de pesos (pequeños valores aleatorios)
        W_data = np.random.randn(in_features, out_features) * 0.5
        b_data = np.zeros((1, out_features))
        
        # Crear tensores con gradiente
        self.W = Tensor(W_data, requires_grad=True)
        self.b = Tensor(b_data, requires_grad=True)
        
        # Registrar parámetros en el módulo
        self.add_parameter(self.W)
        self.add_parameter(self.b)
    
    
    def forward(self, x):
        # x: (batch_size, in_features)
        # W: (in_features, out_features)
        # b: (1, out_features)
        
        return x @ self.W + self.b