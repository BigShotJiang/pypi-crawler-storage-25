import numpy as np
from .Module import Module
from ..core.Tensor import Tensor


class ReLU(Module):
    
    def forward(self, x):
        
        # Aplicar ReLU: max(0, x)
        out = Tensor(
            np.maximum(0, x.data),
            requires_grad=x.requires_grad,
            children=(x,),
            op='relu'
        )

        def _backward():
            if x.requires_grad:
                grad = (x.data > 0).astype(float)
                x.grad += grad * out.grad

        out._backward = _backward

        return out



class Sigmoid(Module):
    
    def forward(self, x):
        
        # σ(x) = 1 / (1 + e^-x)
        sig = 1 / (1 + np.exp(-x.data))

        out = Tensor(
            sig,
            requires_grad=x.requires_grad,
            children=(x,),
            op='sigmoid'
        )

        def _backward():
            if x.requires_grad:
                x.grad += (sig * (1 - sig)) * out.grad

        out._backward = _backward

        return out