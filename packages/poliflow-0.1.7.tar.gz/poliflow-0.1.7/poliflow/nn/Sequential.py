from .Module import Module


class Sequential(Module):
    
    def __init__(self, *modules):
        super().__init__()
        
        self.layers = []
        
        for m in modules:
            self.layers.append(m)
            self.add_module(m)
    
    
    def forward(self, x):
        
        for layer in self.layers:
            x = layer(x)
        
        return x