import pickle

class Module:
    
    def __init__(self):
        self._parameters = []
        self._modules = []
    
    
    def parameters(self):
        params = []
        
        # parámetros propios
        for p in self._parameters:
            params.append(p)
        
        # parámetros de submódulos
        for m in self._modules:
            params.extend(m.parameters())
        
        return params
    
    
    def add_parameter(self, param):
        self._parameters.append(param)
    
    
    def add_module(self, module):
        self._modules.append(module)
    
    
    def zero_grad(self):
        for p in self.parameters():
            if p.requires_grad:
                p.grad = 0 * p.grad
    
    
    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)
    
    
    def forward(self, *args, **kwargs):
        raise NotImplementedError("Debe implementar forward()")
    
    #-----------****** save ******-------
    def save(self, path):
        params = self.parameters()
        weights = [p.data for p in params]

        with open(path, "wb") as f:
            pickle.dump(weights, f)


    def load(self, path):
        params = self.parameters()

        with open(path, "rb") as f:
            weights = pickle.load(f)

        for p, w in zip(params, weights):
            p.data = w