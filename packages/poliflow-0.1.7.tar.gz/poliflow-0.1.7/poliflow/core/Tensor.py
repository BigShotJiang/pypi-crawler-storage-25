import numpy as np



def _match_shape(grad, shape):
    # Reducir dimensiones extra
    while len(grad.shape) > len(shape):
        grad = grad.sum(axis=0)
    
    # Reducir dimensiones donde el tensor original tenía size 1
    for i, dim in enumerate(shape):
        if dim == 1:
            grad = grad.sum(axis=i, keepdims=True)
    
    return grad


class Tensor:
    
    def __init__(self, data, requires_grad = False, children = (), op = ''):
        # constructor
        self.data = np.array(data, dtype=float)
        self.requires_grad = requires_grad
        self.grad = np.zeros_like(self.data) if requires_grad else None
        self._backward = lambda: None
        self._prev = set(children)
        self.op = op
        
       
    
    
    
    # funcion de suma
    def __add__(self, other):
        if not isinstance(other, Tensor):
            other = Tensor(other)

        out = Tensor(
            self.data + other.data,
            requires_grad=self.requires_grad or other.requires_grad,
            children=(self, other),
            op='+'
        )

        def _backward():

            if self.requires_grad:
                self.grad += _match_shape(out.grad, self.data.shape)

            if other.requires_grad:
                other.grad += _match_shape(out.grad, other.data.shape)

        out._backward = _backward

        return out
    
    
    
    
    def __sub__(self, other):
        if not isinstance(other, Tensor):
            other = Tensor(other)

        out = Tensor(
            self.data - other.data,
            requires_grad=self.requires_grad or other.requires_grad,
            children=(self, other),
            op='-'
        )

        def _backward():
            if self.requires_grad:
                self.grad += _match_shape(out.grad, self.data.shape)

            if other.requires_grad:
                other.grad -= _match_shape(out.grad, other.data.shape)

        out._backward = _backward

        return out
    
    
    
    
    def __mul__(self, other):
        if not isinstance(other, Tensor):
            other = Tensor(other)

        out = Tensor(
            self.data * other.data,
            requires_grad=self.requires_grad or other.requires_grad,
            children=(self, other),
            op='*'
        )

        def _backward():

            if self.requires_grad:
                grad_self = other.data * out.grad
                self.grad += _match_shape(grad_self, self.data.shape)

            if other.requires_grad:
                grad_other = self.data * out.grad
                other.grad += _match_shape(grad_other, other.data.shape)

        out._backward = _backward

        return out
    
    
    
    
    def __truediv__(self, other):
        if not isinstance(other, Tensor):
            other = Tensor(other)

        out = Tensor(
            self.data / other.data,
            requires_grad=self.requires_grad or other.requires_grad,
            children=(self, other),
            op='/'
        )

        def _backward():
            if self.requires_grad:
                grad_self = (1 / other.data) * out.grad
                self.grad += _match_shape(grad_self, self.data.shape)

            if other.requires_grad:
                grad_other = (-self.data / (other.data ** 2)) * out.grad
                other.grad += _match_shape(grad_other, other.data.shape)

        out._backward = _backward

        return out
    
    
    
    
    def __pow__(self, power):

        out = Tensor(
            self.data ** power,
            requires_grad=self.requires_grad,
            children=(self,),
            op='pow'
        )

        def _backward():
            if self.requires_grad:
                self.grad += (power * self.data ** (power - 1)) * out.grad

        out._backward = _backward

        return out
    
    
    
    
    def __neg__(self):

        out = Tensor(
            -self.data,
            requires_grad=self.requires_grad,
            children=(self,),
            op='neg'
        )

        def _backward():
            if self.requires_grad:
                self.grad -= out.grad

        out._backward = _backward

        return out
    
    
    def sum(self):

        out = Tensor(
            self.data.sum(),
            requires_grad=self.requires_grad,
            children=(self,),
            op='sum'
        )

        def _backward():

            if self.requires_grad:
                self.grad += np.ones_like(self.data) * out.grad

        out._backward = _backward

        return out
    
    
    
    def mean(self):

        out = Tensor(
            self.data.mean(),
            requires_grad=self.requires_grad,
            children=(self,),
            op='mean'
        )

        def _backward():

            if self.requires_grad:
                n = self.data.size
                self.grad += (1.0 / n) * np.ones_like(self.data) * out.grad

        out._backward = _backward

        return out
    
    
    
    def __matmul__(self, other):

        if not isinstance(other, Tensor):
            other = Tensor(other)
        # tensor resultante
        out = Tensor(
            self.data @ other.data,
            requires_grad=self.requires_grad or other.requires_grad,
            children=(self, other),
            op='@'
        )
        # define cómo se propaga el gradiente de esa operación específica.
        def _backward():

            if self.requires_grad:
                self.grad += out.grad @ other.data.T

            if other.requires_grad:
                other.grad += self.data.T @ out.grad

        out._backward = _backward

        return out
    
    
    
    
    def backward(self):

        topo = []
        visited = set()

        def build_topo(v):
            if v not in visited:
                visited.add(v)
                for child in v._prev:
                    build_topo(child)
                topo.append(v)

        build_topo(self)

        self.grad = np.ones_like(self.data)

        for node in reversed(topo):
            node._backward()
    
    
    
    