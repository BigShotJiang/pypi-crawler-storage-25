from .Loss import Loss

class CrossEntropyLoss(Loss):

    def forward(self, y_pred, y_true):
        exp = y_pred.exp()
        probs = exp / exp.sum(axis=1, keepdims=True)

        eps = 1e-9
        log_probs = (probs + eps).log()

        return -(y_true * log_probs).sum(axis=1).mean()