from .Loss import Loss

class MAELoss(Loss):

    def forward(self, y_pred, y_true):
        diff = y_pred - y_true
        return diff.abs().mean()