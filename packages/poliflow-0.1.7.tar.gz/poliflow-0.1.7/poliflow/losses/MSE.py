from .Loss import Loss

class MSELoss(Loss):

    def forward(self, y_pred, y_true):
        diff = y_pred - y_true
        return (diff * diff).mean()