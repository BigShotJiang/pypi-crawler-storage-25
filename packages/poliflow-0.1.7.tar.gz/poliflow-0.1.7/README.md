# Poliflow

Poliflow es un framework de Deep Learning desarrollado en Python desde cero, diseñado con fines educativos y de investigación.  
Incluye tensores, capas neuronales, funciones de activación, optimizadores y entrenamiento de modelos.

---

# Instalación

```bash
pip install poliflow
```

---

# Características

- Tensores personalizados
- Redes neuronales secuenciales
- Capas Dense / Linear
- Funciones de activación
- Función de pérdida MSE
- Optimizador SGD
- División de datasets
- Entrenamiento de modelos
- Predicción de datos

---

# Ejemplo básico

```python
from poliflow.nn.Linear import Linear
from poliflow.nn.Sequential import Sequential
from poliflow.nn.Activation import ReLU

model = Sequential(
    Linear(10, 32),
    ReLU(),
    Linear(32, 1)
)
```

---

# Entrenamiento de un modelo

```python
from poliflow.losses.MSE import MSELoss
from poliflow.optim.SGD import SGD

criterion = MSELoss()
optimizer = SGD(model.parameters(), lr=0.01)
```

---

# Predicción

```python
y_pred = model.predict(X_test)
print(y_pred)
```

---

# Clase Linear

La capa `Linear` implementa una capa completamente conectada.

## Parámetros

- `in_features` : número de entradas
- `out_features` : número de salidas

## Ejemplo

```python
layer = Linear(10, 5)
```

---

# Función ReLU

La función de activación ReLU elimina valores negativos.

## Ejemplo

```python
from poliflow.nn.Activation import ReLU

activation = ReLU()
```

---

# Función de pérdida MSE

Calcula el error cuadrático medio.

## Ejemplo

```python
from poliflow.losses.MSE import MSELoss

loss = MSELoss()
```

---

# Optimizador SGD

Implementa descenso de gradiente estocástico.

## Ejemplo

```python
from poliflow.optim.SGD import SGD

optimizer = SGD(model.parameters(), lr=0.01)
```

---

# División de datos

Poliflow incluye una utilidad para dividir datasets.

## Ejemplo

```python
from poliflow.data.split import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2
)
```

---

# Proyecto

Repositorio oficial:

https://github.com/Th3copolo0X/Poliflow2

---

# Licencia

MIT License