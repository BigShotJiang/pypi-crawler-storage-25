import pandas as pd
import numpy as np
import sys
import os

# Para que encuentre poliflow
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Importar tu framework
from poliflow.core.Tensor import Tensor
from poliflow.nn.Linear import Linear
from poliflow.nn.Sequential import Sequential
from poliflow.losses.MSE import MSELoss
from poliflow.optim.SGD import SGD
from poliflow.nn.Activation import ReLU
from poliflow.data.split import train_test_split

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# =========================
# 1. Cargar datos
# =========================
ruta_csv = os.path.join(
    os.path.dirname(__file__),
    "house_dataset 2.csv"
)

df = pd.read_csv(ruta_csv)

# Features y target
X = df.drop(columns=["House_Price"]).values
y = df["House_Price"].values.reshape(-1, 1)

# 🔥 LOG TRANSFORM (CLAVE)
y = np.log1p(y)

# =========================
# 2. Split
# =========================
X_train, X_test, y_train, y_test = train_test_split(X, y)

# =========================
# 3. Normalización (solo TRAIN)
# =========================
X_mean = X_train.mean(axis=0)
X_std = X_train.std(axis=0) + 1e-8  

y_mean = y_train.mean()
y_std = y_train.std() + 1e-8

# Normalizar TRAIN
X_train = (X_train - X_mean) / X_std
y_train = (y_train - y_mean) / y_std

# Normalizar TEST
X_test = (X_test - X_mean) / X_std
y_test = (y_test - y_mean) / y_std

# =========================
# 4. Tensor
# =========================
X_tensor = Tensor(X_train)
y_tensor = Tensor(y_train)

X_test_tensor = Tensor(X_test)

# =========================
# 5. Modelo
# =========================
input_size = X.shape[1]

model = Sequential(
    Linear(input_size, 16),
    ReLU(),
    Linear(16, 8),
    ReLU(),
    Linear(8, 1)
)

# =========================
# 6. Loss y optimizador
# =========================
criterion = MSELoss()
optimizer = SGD(model.parameters(), lr=0.01)

# =========================
# 7. Entrenamiento
# =========================
epochs = 10000  # 🔥 bajamos epochs (10000 era excesivo)

for epoch in range(epochs):
    pred = model(X_tensor)
    loss = criterion(pred, y_tensor)

    loss.backward()
    optimizer.step()
    optimizer.zero_grad()

    if epoch % 500 == 0:
        print(f"Epoch {epoch}, Loss: {loss.data}")

# =========================
# 8. Predicción en TEST
# =========================
pred_test = model(X_test_tensor).data

# 🔄 Desnormalizar
y_pred_log = pred_test * y_std + y_mean
y_true_log = y_test * y_std + y_mean

# 🔄 Invertir log
y_pred = np.expm1(y_pred_log)
y_true = np.expm1(y_true_log)

# =========================
# 9. Métricas
# =========================
mse = mean_squared_error(y_true, y_pred)
rmse = np.sqrt(mse)
mae = mean_absolute_error(y_true, y_pred)
r2 = r2_score(y_true, y_pred)

print("\n=== RESULTADOS ===")
print(f"RMSE: {rmse:.2f}")
print(f"MAE: {mae:.2f}")
print(f"R²: {r2:.4f}")
