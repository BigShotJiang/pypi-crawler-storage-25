from poliflow.core.Tensor import Tensor
from poliflow.losses import MSELoss
from poliflow.optim import SGD

# datos
x = Tensor(2.0)
y_true = Tensor(4.0)

# parametro (peso)
w = Tensor(1.0, requires_grad=True)

# loss y optimizador
loss_fn = MSELoss()
optimizer = SGD([w], lr=0.15)

for epoch in range(10):

    y_pred = w * x

    loss = loss_fn(y_pred, y_true)

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    print(f"Epoch {epoch}: w={w.data}, loss={loss.data}")