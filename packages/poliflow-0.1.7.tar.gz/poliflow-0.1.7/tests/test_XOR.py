import numpy as np
from poliflow.core.Tensor import Tensor
from poliflow.nn.Linear import Linear
from poliflow.nn.Activation import Sigmoid
from poliflow.nn.Sequential import Sequential
from poliflow.losses.MSE import MSELoss
from poliflow.optim.SGD import SGD

# Datos XOR
X = Tensor(np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
]), requires_grad=False)

y = Tensor(np.array([
    [0],
    [1],
    [1],
    [0]
]), requires_grad=False)

# Modelo (con capa oculta)
model = Sequential(
    Linear(2, 4),
    Sigmoid(),
    Linear(4, 1),
    Sigmoid()
)

loss_fn = MSELoss()
optimizer = SGD(model.parameters(), lr=0.5)

# Entrenamiento
for epoch in range(5000):
    y_pred = model(X)
    
    loss = loss_fn(y_pred, y)
    
    loss.backward()
    optimizer.step()
    optimizer.zero_grad()
    
    if epoch % 500 == 0:
        print(f"Epoch {epoch}, Loss: {loss.data}")

# Resultados
print("\nPredicciones XOR:")
print(model(X).data)