# tests/test_sum_mean.py

from poliflow.core.Tensor import Tensor

x = Tensor([1.0, 2.0, 3.0], requires_grad=True)

y = x.sum()
y.backward()

print("sum grad:", x.grad)

x = Tensor([1.0, 2.0, 3.0], requires_grad=True)

y = x.mean()
y.backward()

print("mean grad:", x.grad)