import pandas as pd
import numpy as np
import sys
import os


# Para que encuentre poliflow
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Importar tu framework
from poliflow.grafica.grafo import dibujar_red_desde_modelo
from poliflow.core.Tensor import Tensor
from poliflow.nn.Linear import Linear
from poliflow.nn.Sequential import Sequential
from poliflow.losses.MSE import MSELoss
from poliflow.optim.SGD import SGD
from poliflow.nn.Activation import ReLU
from poliflow.data.split import train_test_split

# =========================
# 1. Cargar datos
# =========================
ruta_csv = os.path.join(
    os.path.dirname(__file__),
    "house_dataset 2.csv"
)

df = pd.read_csv(ruta_csv)

# Features y target
X = df.drop(columns=["House_Price"]).values
y = df["House_Price"].values.reshape(-1, 1)



X_train, X_test, y_train, y_test = train_test_split(X, y)

# Calcular con TRAIN
X_mean = X_train.mean(axis=0)
X_std = X_train.std(axis=0)

y_mean = y_train.mean()
y_std = y_train.std()

# Normalizar TRAIN
X_train = (X_train - X_mean) / X_std
y_train = (y_train - y_mean) / y_std

# Normalizar TEST con los mismos valores
X_test = (X_test - X_mean) / X_std
y_test = (y_test - y_mean) / y_std

# =========================
# 2. Convertir a Tensor
# =========================
X_tensor = Tensor(X_train)
y_tensor = Tensor(y_train)

X_test_tensor = Tensor(X_test)
y_test_tensor = Tensor(y_test)

# =========================
# 3. Definir modelo
# =========================
input_size = X.shape[1]

model = Sequential(
    Linear(input_size, 16),
    ReLU(),
    Linear(16, 8),
    ReLU(),
    Linear(8, 1)
)

# =========================
# 4. Loss y optimizador
# =========================
criterion = MSELoss()
optimizer = SGD(model.parameters(), lr=0.01)

# =========================
# 5. Entrenamiento
# =========================
epochs = 10000

for epoch in range(epochs):
    pred = model(X_tensor)
    loss = criterion(pred, y_tensor)

    loss.backward()
    optimizer.step()
    optimizer.zero_grad()

    if epoch % 1000 == 0:
        try:
            print(f"Epoch {epoch}, Loss: {loss.data}")
        except:
            print(f"Epoch {epoch}, Loss: {loss}")

# =========================
# 6. Predicción
# =========================
pred_final = model(X_tensor)

try:
    print("Predicciones:", pred_final.data[:5])
except:
    print("Predicciones:", pred_final[:5])


for i in range(5):
    print("Pred:", pred_final.data[i][0],
          "| Real:", y_tensor.data[i][0])
    
