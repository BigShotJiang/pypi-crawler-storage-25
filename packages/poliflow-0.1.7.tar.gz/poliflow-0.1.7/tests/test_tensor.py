from poliflow.core.tensor import Tensor

a = Tensor(2.0, requires_grad=True)
b = Tensor(3.0, requires_grad=True)

c = a * b
d = c + a

d.backward()

print("a.grad:", a.grad)
print("b.grad:", b.grad)



