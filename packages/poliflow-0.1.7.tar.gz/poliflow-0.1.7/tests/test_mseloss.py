from poliflow.core.Tensor import Tensor
from poliflow.losses import MSELoss, MAELoss

y_pred = Tensor([2.0, 3.0], requires_grad=True)
y_true = Tensor([1.0, 5.0])

# MSE
mse = MSELoss()
loss1 = mse(y_pred, y_true)

loss1.backward()

print("MSE loss:", loss1.data)
print("grad:", y_pred.grad)