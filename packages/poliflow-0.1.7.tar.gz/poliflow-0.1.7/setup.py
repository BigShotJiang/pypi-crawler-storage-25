from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as readme:
    long_description = readme.read()

setup(
    name="poliflow",
    version="0.1.6",
    packages=find_packages(),
    description="Framework de Machine Learning desarrollado en Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Eduardo Hernandez,Gerardo Hernandez",
    url="https://github.com/Th3copolo0X/Poliflow2",
    download_url="https://github.com/Th3copolo0X/Poliflow2/archive/refs/tags/v0.1.tar.gz",
    keywords=[
        "machine learning",
        "deep learning",
        "framework",
        "neural networks",
        "python"
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    license="MIT",
    include_package_data=True,
    install_requires=[
        "numpy",
    ],
    python_requires=">=3.10",
)