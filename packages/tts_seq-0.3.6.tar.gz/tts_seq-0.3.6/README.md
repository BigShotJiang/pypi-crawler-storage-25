# Teamtools Studio Seq

![Project logo](https://github.com/NASA-JPL-Teamtools-Studio/teamtools_documentation/blob/main/docs/images/tts_image_artifacts/tts_seq.png)

## About Teamtools Studio

Teamtools Studio Utilities is part of JPL's Teamtools Studio (TTS).

TTS is an effort originated in JPL's Planning and Execution section to centralize shared repositories across missions. This benefits JPL by reducing cost through reducing duplicated code, collaborating across missions, and unifying standards for development and design across JPL.

Although Planning and Execution is primarily concerned with flight operations, the TTS suite has been generalized and atomized to the point where many of these tools are applicable during other mission phases and even in non-spaceflight contexts. Through our work flying space missions, we hope to provide tools to the open source community that have utility in data analysis or planning for any complex system where failure is not an option.

For more infomation on how to contribute, and how these libraries form a complete ecosystem for high reliability data analysis, see the [Full TTS Documentation](https://nasa-jpl-teamtools-studio.github.io/teamtools_documentation/).

## What is Teamtools Studio Seq?

### Overview

TTS Seq is the central library for interacting with command sequences at JPL. It includes IO methods for common sequencing languages including 
SeqJSON, .seq, RML, and SCR. VML is not currently supported, but that contribution would be very much welcomed.

TTS Seq also includes classes for managing collections of sequences, usually most important for modeling the state of sequences currently
onboard a spacecraft or expected to be onboard at a given moment.

Finally, TTS Seq also includes a simulation engine for simulating the state of a spacecraft given a particular sequence load. It is 
currently fairly modest and only appropriate for relatively simple simulations, but it is currently being expanded.

### Projects Currently Supported

* DemoSat
* Orbiting Carbon Observatory 2 (OCO-2)
* NISAR

## Architecture

### TTS dependencies

* TTS Dicitonary Interface
* TTS Utilities
* Data Utilities
* HTML Utilities
