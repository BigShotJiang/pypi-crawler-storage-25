"""Client HTTP vers l'API Phield (Railway)."""

from __future__ import annotations

import os
from typing import Any

import httpx

API_URL = os.environ.get(
    "PHIELD_API_URL", "https://pharos-production-624e.up.railway.app"
)
API_KEY = os.environ.get("PHIELD_API_KEY", "")

TIMEOUT = httpx.Timeout(connect=30, read=60, write=30, pool=30)
RETRY_STATUSES = {502, 503, 504}


class PhieldClient:
    """Async HTTP client wrapping the Phield REST API."""

    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            base_url=API_URL,
            headers={"X-API-Key": API_KEY},
            timeout=TIMEOUT,
        )

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any] | list[Any]:
        """Execute an HTTP request with 1 retry on 502/503/504."""
        for attempt in range(2):
            resp = await self._client.request(
                method, path, params=params, json=json
            )
            if resp.status_code in RETRY_STATUSES and attempt == 0:
                continue
            if resp.status_code == 204:
                return {"ok": True}
            if resp.status_code >= 400:
                try:
                    detail = resp.json().get("detail", resp.text)
                except Exception:
                    detail = resp.text
                return {"erreur": f"HTTP {resp.status_code} — {detail}"}
            return resp.json()
        return {"erreur": "Le serveur est temporairement indisponible (502/503/504)"}

    async def get(self, path: str, **params: Any) -> Any:
        clean = {k: v for k, v in params.items() if v is not None}
        return await self._request("GET", path, params=clean or None)

    async def post(self, path: str, data: dict[str, Any] | None = None) -> Any:
        return await self._request("POST", path, json=data)

    async def patch(self, path: str, data: dict[str, Any] | None = None) -> Any:
        return await self._request("PATCH", path, json=data)

    async def put(self, path: str, data: dict[str, Any] | None = None) -> Any:
        return await self._request("PUT", path, json=data)

    async def delete(self, path: str) -> Any:
        return await self._request("DELETE", path)

    async def close(self) -> None:
        await self._client.aclose()


# Singleton
api = PhieldClient()
