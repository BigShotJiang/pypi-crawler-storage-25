# phield-mcp

Connecteur MCP (Model Context Protocol) pour le CRM Phield. Permet aux commerciaux d'interagir avec le CRM directement depuis Claude Desktop.

## Installation

```bash
uvx phield-mcp
```

## Configuration Claude Desktop

```json
{
  "mcpServers": {
    "phield": {
      "command": "uvx",
      "args": ["phield-mcp"],
      "env": {
        "PHIELD_API_KEY": "<votre clé API>",
        "PHIELD_API_URL": "https://pharos-production-624e.up.railway.app"
      }
    }
  }
}
```

## Tools disponibles

| Tool | Description |
|------|-------------|
| `tableau_de_bord` | Dashboard du jour (actions, retards, alertes, fiches) |
| `mes_actions_en_retard` | Actions en retard uniquement |
| `rechercher_pharmacie` | Recherche par nom/ville/SIRET + filtres |
| `fiche_pharmacie` | Fiche complète (coordonnées, financier, produits, historique) |
| `ehpad_proximite` | EHPADs proches (lits, distance, référencement) |
| `get_template_visite` | Template Markdown pré-rempli pour préparer une visite |
| `modifier_pharmacie` | Mettre à jour coordonnées (titulaire, tél, email, site) |
| `marquer_opposition_prospection` | Activer/lever l'opposition RGPD (avec motif) |
| `enregistrer_interet_produit` | Upsert statut produit (robot, agencement, grossiste) |
| `creer_action` | Planifier une action (appel, visite, relance, demo...) |
| `completer_action` | Marquer une action faite/annulée/reportée |
| `enregistrer_interaction` | Logger un CR de visite/appel/email |
| `changer_statut` | Changer le statut pipeline d'une pharmacie |
| `alertes_veille` | Alertes BODACC/BOAMP non lues |

## Changelog

- **0.2.0** — Ajout `marquer_opposition_prospection`, `enregistrer_interet_produit`, `modifier_pharmacie`, `get_template_visite`.
- **0.1.0** — Release initiale.
