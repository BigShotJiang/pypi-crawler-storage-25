# SPDX-License-Identifier: Apache-2.0
# Copyright © 2026 Bijan Mousavi
"""JSON canonical helpers."""

from __future__ import annotations

from typing import Any

from bijux_canon_reason.core.fingerprints import canonical_dumps


def canonical_json_line(obj: Any) -> str:
    """
    Canonical JSON line (no trailing spaces), always ends with newline when used by writers.
    """
    return canonical_dumps(obj)
