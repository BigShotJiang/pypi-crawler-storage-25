# SPDX-License-Identifier: Apache-2.0
# Copyright © 2026 Bijan Mousavi
"""Main helpers for the CLI interface."""

from __future__ import annotations

import json
from pathlib import Path
from typing import NoReturn, no_type_check

import typer

from bijux_canon_reason.application.run_artifacts import (
    RunArtifacts,
    RunBuilder,
    RunInputs,
)
from bijux_canon_reason.core.types import (
    Plan,
    ProblemSpec,
    ReplayResult,
    VerificationReport,
)
from bijux_canon_reason.evaluation.suite_workflow import EvalResult, run_eval_suite
from bijux_canon_reason.interfaces.serialization.json_file import (
    read_json_file,
    write_json_file,
)
from bijux_canon_reason.interfaces.serialization.trace_jsonl import read_trace_jsonl
from bijux_canon_reason.traces.replay import replay_from_artifacts
from bijux_canon_reason.verification.verifier import verify_trace

app = typer.Typer(
    add_completion=False,
    help="bijux-canon-reason: deterministic CLI + artifacts + verification gates.",
)

SPEC_PATH_OPTION = typer.Option(
    ..., "--spec", exists=True, dir_okay=False, help="Path to ProblemSpec JSON."
)
PRESET_OPTION = typer.Option("default", "--preset", help="Pipeline preset name.")
SEED_OPTION = typer.Option(0, "--seed", help="Deterministic seed.")
ARTIFACTS_DIR_OPTION = typer.Option(
    Path("artifacts/bijux-canon-reason"),
    "--artifacts-dir",
    help="Base artifacts directory.",
)
FAIL_ON_VERIFY_OPTION = typer.Option(
    False,
    "--fail-on-verify/--no-fail-on-verify",
    help="Exit non-zero if verify fails.",
)
TRACE_PATH_OPTION = typer.Option(
    ..., "--trace", exists=True, dir_okay=False, help="Path to trace.jsonl"
)
PLAN_PATH_OPTION = typer.Option(
    ...,
    "--plan",
    exists=True,
    dir_okay=False,
    help="Plan JSON required for verification",
)
FAIL_ON_DIFF_OPTION = typer.Option(
    True,
    "--fail-on-diff/--no-fail-on-diff",
    help="Exit non-zero when replay fingerprint differs.",
)
EVAL_SUITE_OPTION = typer.Option(
    "small", "--suite", help="Eval suite name (placeholder until eval suites land)."
)


def _exit(code: int, msg: str | None = None) -> NoReturn:
    """Handle exit."""
    if msg:
        typer.echo(msg, err=(code != 0))
    raise typer.Exit(code=code)


def _emit_json(payload: dict[str, object]) -> None:
    """Handle emit JSON."""
    typer.echo(json.dumps(payload, sort_keys=True))


@app.command()
@no_type_check
def run(
    spec: Path = SPEC_PATH_OPTION,
    preset: str = PRESET_OPTION,
    seed: int = SEED_OPTION,
    artifacts_dir: Path = ARTIFACTS_DIR_OPTION,
    fail_on_verify: bool = FAIL_ON_VERIFY_OPTION,
    json_output: bool = typer.Option(
        False, "--json", help="Emit structured JSON instead of plain output."
    ),
) -> None:
    """Run the requested operation."""
    raw = read_json_file(spec)
    spec_obj = ProblemSpec.model_validate(raw)

    inputs = RunInputs(spec=spec_obj, preset=preset, seed=seed)
    builder = RunBuilder()
    arts: RunArtifacts = builder.build(inputs=inputs, artifacts_root=artifacts_dir)
    trace_id = arts.trace.id
    if trace_id is None:
        _exit(2, "run failed: trace id missing (invariant violation)")

    report = arts.verify_report
    if report.failures and fail_on_verify:
        _exit(
            2,
            f"run failed verification ({len(report.failures)} issues). see: {arts.verify_path}",
        )

    if json_output:
        _emit_json(_run_payload(arts))
        _exit(0)

    typer.echo(str(arts.run_dir))
    _exit(0)


@app.command()
@no_type_check
def verify(
    trace: Path = TRACE_PATH_OPTION,
    plan: Path = PLAN_PATH_OPTION,
    fail_on_verify: bool = FAIL_ON_VERIFY_OPTION,
    json_output: bool = typer.Option(
        False, "--json", help="Emit structured JSON instead of plain output."
    ),
) -> None:
    """Handle verify."""
    tr = read_trace_jsonl(trace)
    trace_id = tr.id
    if trace_id is None:
        _exit(2, "verification failed: trace id missing (invariant violation)")

    pl_raw = read_json_file(plan)
    pl = Plan.model_validate(pl_raw)

    report = verify_trace(trace=tr, plan=pl, artifacts_dir=trace.parent)

    out = trace.parent / "verify.verify.json"
    write_json_file(out, report.model_dump(mode="json"))

    if report.failures and fail_on_verify:
        _exit(2, f"verification failed ({len(report.failures)} issues). see: {out}")

    if json_output:
        _emit_json(_verify_payload(report))
        _exit(0 if not report.failures else 2)

    typer.echo("ok")
    _exit(0)


@app.command()
@no_type_check
def replay(
    trace: Path = TRACE_PATH_OPTION,
    fail_on_diff: bool = FAIL_ON_DIFF_OPTION,
    json_output: bool = typer.Option(
        False, "--json", help="Emit structured JSON instead of plain output."
    ),
) -> None:
    """Handle replay."""
    res, replay_trace = replay_from_artifacts(trace)
    payload = _replay_payload(replay_trace=replay_trace, result=res)
    _emit_json(payload)

    if (
        fail_on_diff
        and res.original_trace_fingerprint != res.replayed_trace_fingerprint
    ):
        _exit(
            2,
            "replay mismatch: fingerprints differ. "
            f"Replay trace: {payload['replay_trace_path']}. Diff: {res.diff_summary}",
        )

    _exit(0)


@app.command(name="eval")
@no_type_check
def eval_suite(
    suite: str = EVAL_SUITE_OPTION,
    artifacts_dir: Path = ARTIFACTS_DIR_OPTION,
    preset: str = PRESET_OPTION,
    seed: int = SEED_OPTION,
    json_output: bool = typer.Option(
        False, "--json", help="Emit structured JSON instead of plain output."
    ),
) -> None:
    """Handle eval suite."""
    res, out_path = run_eval_suite(
        suite=suite, artifacts_dir=artifacts_dir, preset=preset, seed=seed
    )
    payload = _eval_payload(summary_path=out_path, result=res)
    _emit_json(payload if json_output else {"summary": str(out_path)})
    if res.failed:
        _exit(2, f"eval failed ({res.failed}/{res.total} cases). see: {out_path}")
    _exit(0)


def _run_payload(artifacts: RunArtifacts) -> dict[str, object]:
    """Handle run payload."""
    return {
        "run_dir": str(artifacts.run_dir),
        "verify_failures": len(artifacts.verify_report.failures),
        "summary": artifacts.verify_report.summary_metrics,
    }


def _verify_payload(report: VerificationReport) -> dict[str, object]:
    """Handle verify payload."""
    return {
        "status": "ok" if not report.failures else "failed",
        "failures": [failure.message for failure in report.failures],
        "checks": [check.model_dump(mode="json") for check in report.checks],
    }


def _replay_payload(
    *,
    replay_trace: Path,
    result: ReplayResult,
) -> dict[str, object]:
    """Handle replay payload."""
    payload = {
        "original_trace_fingerprint": result.original_trace_fingerprint,
        "replayed_trace_fingerprint": result.replayed_trace_fingerprint,
        "diff_summary": result.diff_summary,
        "replay_trace_path": str(replay_trace),
    }
    payload["original_fingerprint"] = payload["original_trace_fingerprint"]
    payload["replayed_fingerprint"] = payload["replayed_trace_fingerprint"]
    payload["diff"] = payload["diff_summary"]
    return payload


def _eval_payload(*, summary_path: Path, result: EvalResult) -> dict[str, object]:
    """Handle eval payload."""
    return {"summary": str(summary_path), **result.to_json()}
