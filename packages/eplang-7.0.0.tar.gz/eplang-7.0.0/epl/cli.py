"""
EPL - English Programming Language CLI (v7.0)
Standalone command-line interface for the EPL programming language.

This is the primary entry point for the `epl` command.
Usage:
    epl run <file.epl>           Run an EPL program
    epl new <name> [--template]  Create a new EPL project
    epl build <file.epl>         Compile to native executable
    epl wasm <file.epl>          Compile to WebAssembly
    epl test [dir|file]          Run tests
    epl repl                     Interactive REPL
    epl install [--frozen] [package] Install project deps or a package
    epl gitinstall <owner/repo>  Install/save a GitHub package dependency
    epl gitremove <name>         Remove a GitHub dependency declaration
    epl gitdeps                  List GitHub package dependencies
    epl pyinstall <import> [spec] Install/save a Python package
    epl pyremove <import>        Remove a Python package declaration
    epl pydeps                   List Python ecosystem dependencies
    epl github <cmd>             Clone/pull/push GitHub projects
    epl serve <file.epl>         Start production server
    epl desktop <file.epl>       Generate desktop app project
    epl web <file.epl>           Generate web app bundle
    epl <file.epl>               Shorthand for 'epl run'
    epl --version                Show version
    epl --help                   Show help
"""

import sys
import os

# Python version guard
if sys.version_info < (3, 9):
    print(f"EPL requires Python 3.9 or later (found {sys.version_info.major}.{sys.version_info.minor}).")
    print("Please upgrade Python: https://python.org/downloads/")
    sys.exit(1)

# Ensure EPL root is on the path
_EPL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _EPL_ROOT not in sys.path:
    sys.path.insert(0, _EPL_ROOT)

from epl import __version__

# ─── ANSI Colors ──────────────────────────────────────────

def _color(code, text):
    if os.environ.get('NO_COLOR') or not sys.stdout.isatty():
        return text
    return f"\033[{code}m{text}\033[0m"

def _bold(t):    return _color('1', t)
def _green(t):   return _color('32', t)
def _cyan(t):    return _color('36', t)
def _yellow(t):  return _color('33', t)
def _red(t):     return _color('31', t)
def _dim(t):     return _color('2', t)


# ─── Banner ───────────────────────────────────────────────

BANNER = f"""\
{_bold('EPL')} - English Programming Language {_dim(f'v{__version__}')}
Write code in plain English. Build anything.
"""

HELP = f"""\
{_bold('EPL')} - English Programming Language {_dim(f'v{__version__}')}

{_bold('Usage:')}
  epl <file.epl>                   Run an EPL program
  epl run <file.epl> [flags]       Run an EPL program
  epl new <name> [--template T]    Create a new EPL project
  epl build <file.epl>             Compile to native executable (.exe)
  epl wasm <file.epl>              Compile to WebAssembly (.wasm)
  epl test [dir|file]              Run EPL test suite
  epl repl                         Start interactive REPL
  epl install [--frozen] [package] Install project deps or a package
  epl uninstall <package>          Remove a package
  epl packages                     List installed packages
  epl search <query>               Search available and installed packages
  epl lock                         Generate epl.lock
  epl update [package] [--major]   Update package dependencies
  epl outdated                     Show outdated dependencies
  epl audit                        Verify installed dependency integrity
  epl gitinstall <owner/repo> [as] Install/save a GitHub package dependency
  epl gitremove <name>             Remove a GitHub dependency declaration
  epl gitdeps                      List declared GitHub dependencies
  epl pyinstall <import> [spec]    Install/save a Python package for `Use python`
  epl pyremove <import>            Remove a Python dependency declaration
  epl pydeps                       List declared Python dependencies
  epl modules                      List standard library modules
  epl github clone <owner/repo> [dir]
  epl github pull [path]
  epl github push [path] [-m msg] [--remote name] [--branch name]
  epl serve <file.epl> [options]   Start production web server
  epl deploy <target>              Generate deployment configs
  epl check [file|dir]            Static type checking
  epl fmt <file|dir> [options]     Format EPL source code
  epl lint [dir|file]              Lint EPL source code
  epl docs [dir|file]              Generate API documentation
  epl upgrade                      Update EPL to latest version
  epl version                      Show EPL version
  epl debug <file.epl>             Debug with breakpoints
  epl js <file.epl>                Transpile to JavaScript
  epl node <file.epl>              Transpile to Node.js
  epl kotlin <file.epl>            Transpile to Kotlin
  epl python <file.epl>            Transpile to Python
  epl android <file.epl>           Generate Android project
  epl desktop <file.epl>           Generate desktop app project
  epl web <file.epl>               Generate web app bundle
  epl gui <file.epl>               Run with GUI support
  epl ir <file.epl>                Show LLVM IR
  epl vm <file.epl>                Run with bytecode VM (fast)
  epl micropython <file.epl>       Transpile to MicroPython
  epl benchmark <file.epl>         Benchmark VM vs interpreter
  epl profile <file.epl>           Profile execution
  epl bench                        Run benchmark suite
  epl site [dir]                   Generate docs site
  epl playground                   Start the web playground
  epl notebook                     Start the EPL notebook
  epl blocks                       Start the visual block editor
  epl copilot                      Start AI copilot
  epl lsp                          Start LSP server for IDE
  epl ai <prompt>                  AI code assistant
  epl gen <description>            AI-generate EPL code
  epl explain <file.epl>           AI-explain what code does

{_bold('Flags:')}
  --strict       Enable static type checking
  --check        Run type checker before execution
  --no-color     Disable colored output
  --verbose      Show debug output
  --quiet        Suppress all output except errors
  --sandbox      Disable dangerous builtins
  --interpret    Force tree-walking interpreter
  --json         Output errors as JSON

{_bold('Formatter Options:')}
  --check        Exit with code 1 if formatting would change files
  --in-place     Write formatted output back to files

{_bold('Serve Options:')}
  --port N         Server port (default: 8000)
  --workers N      Number of workers (default: 4)
  --reload         Enable hot-reload (dev mode)
  --store TYPE     Store backend: memory|sqlite|redis
  --session TYPE   Session backend: memory|sqlite|redis

{_bold('Package Ecosystem:')}
  epl resolve                      Resolve all dependencies (backtracking)
  epl workspace <cmd>              Workspace/monorepo (init, list, install, validate)
  epl ci [generate|preview]        Generate CI/CD workflows
  epl sync-index [--force]         Sync package index

{_bold('Examples:')}
  epl hello.epl                    Run a program
  epl new myapp --template web     Create a web starter
  epl build myapp/main.epl         Compile to .exe
  epl wasm myapp/main.epl          Compile to .wasm
  epl test tests/                  Run all tests
  epl serve webapp.epl --reload    Dev server with hot-reload
  epl install github:user/lib      Install package from GitHub
  epl install user/lib             Same as GitHub install shorthand
  epl gitinstall epl-lang/web-kit
  epl pyinstall yaml pyyaml>=6     Save/import a pip package with different name
  epl github clone epl-lang/epl
  epl desktop examples/text_editor.epl
  epl workspace init               Initialize monorepo workspace

{_dim(f'EPL v{__version__} | https://github.com/epl-lang/epl')}
"""


def _print_version():
    print(f"epl {__version__}")


def _print_help():
    print(HELP)


# ─── Project Helpers ──────────────────────────────────────

def _load_project_manifest(path='.'):
    """Load epl.toml/epl.json project metadata if present."""
    from epl.package_manager import load_manifest
    try:
        return load_manifest(path)
    except Exception:
        return None


def _default_project_target():
    """Return the configured project entrypoint, if the current directory is a project."""
    manifest = _load_project_manifest('.')
    if not manifest:
        return None
    return manifest.get('entry') or manifest.get('main') or 'main.epl'


_TARGET_OPTION_FLAGS = {
    '--opt',
    '--target',
    '--port',
    '--workers',
    '--store',
    '--session',
}


def _resolve_target_args(args):
    """Use the explicit file argument, otherwise fall back to the project manifest entry."""
    if args:
        i = 0
        while i < len(args):
            arg = args[i]
            if arg.startswith('-'):
                if arg in _TARGET_OPTION_FLAGS and i + 1 < len(args):
                    i += 2
                else:
                    i += 1
                continue
            return list(args)
        target = _default_project_target()
        if target:
            return [target] + list(args)
        return list(args)
    target = _default_project_target()
    if target:
        return [target]
    return None


_GLOBAL_FLAG_ORDER = (
    '--strict',
    '--sandbox',
    '--interpret',
    '--json',
    '--no-color',
    '--verbose',
    '--quiet',
)


def _resolve_main_module():
    """Resolve the source-checkout main module without re-importing when possible."""
    main_mod = sys.modules.get('main')
    if main_mod is None:
        main_mod = sys.modules.get('__main__')
    if main_mod is not None and hasattr(main_mod, 'legacy_main'):
        return main_mod

    import importlib

    return importlib.import_module('main')


def _legacy_dispatch(argv):
    """Run a legacy command through the compatibility dispatcher in main.py."""
    return _resolve_main_module().legacy_main(list(argv))


def _append_global_flags(argv, flags):
    if not flags:
        return list(argv)
    return list(argv) + [flag for flag in _GLOBAL_FLAG_ORDER if flag in flags]


# ─── Command Dispatch ─────────────────────────────────────

def cli_main(argv=None):
    """Main CLI entry point for the `epl` command."""
    if argv is None:
        argv = sys.argv[1:]

    # No args → REPL
    if not argv:
        _run_repl([])
        return 0

    # Global flags
    if '--version' in argv or '-V' in argv:
        _print_version()
        return 0

    if argv[0] in ('--help', '-h', 'help'):
        _print_help()
        return 0

    # Extract global flags
    flags = set()
    clean_args = []
    i = 0
    while i < len(argv):
        if argv[i] in ('--strict', '--no-color', '--verbose', '--quiet', '--sandbox', '--interpret', '--json'):
            flags.add(argv[i])
        else:
            clean_args.append(argv[i])
        i += 1

    if '--no-color' in flags:
        os.environ['NO_COLOR'] = '1'

    # Setup logging
    import logging
    if '--verbose' in flags:
        logging.basicConfig(level=logging.DEBUG, format='%(name)s: %(message)s')
    elif '--quiet' in flags:
        logging.basicConfig(level=logging.ERROR, format='%(message)s')
    else:
        logging.basicConfig(level=logging.WARNING, format='%(message)s')

    if not clean_args:
        _run_repl(flags)
        return 0

    command = clean_args[0]
    rest = clean_args[1:]

    # Command dispatch table
    commands = {
        'run':       lambda: _run_file(rest, flags),
        'new':       lambda: _new_project(rest),
        'build':     lambda: _build(rest, flags, 'build'),
        'compile':   lambda: _build(rest, flags, 'compile'),
        'wasm':      lambda: _wasm(rest),
        'test':      lambda: _run_tests(rest, flags),
        'repl':      lambda: _run_repl(flags),
        'install':   lambda: _pkg_install(rest),
        'uninstall': lambda: _pkg_uninstall(rest),
        'packages':  lambda: _pkg_list(),
        'gitinstall': lambda: _git_install(rest),
        'gitremove': lambda: _git_remove(rest),
        'gitdeps':   lambda: _git_list(),
        'pyinstall': lambda: _py_install(rest),
        'pyremove':  lambda: _py_remove(rest),
        'pydeps':    lambda: _py_list(),
        'modules':   lambda: _list_modules(),
        'github':    lambda: _github(rest),
        'init':      lambda: _init_project(rest),
        'search':    lambda: _pkg_search(rest),
        'add':       lambda: _delegate('add', rest),
        'remove':    lambda: _delegate('remove', rest),
        'lock':      lambda: _pkg_lock(rest),
        'update':    lambda: _pkg_update(rest),
        'tree':      lambda: _delegate('tree', rest),
        'outdated':  lambda: _pkg_outdated(rest),
        'audit':     lambda: _pkg_audit(rest),
        'migrate':   lambda: _delegate('migrate', rest),
        'cache':     lambda: _delegate('cache', rest),
        'publish':   lambda: _delegate('publish', rest),
        'info':      lambda: _delegate('info', rest),
        'stats':     lambda: _delegate('stats', rest),
        'serve':     lambda: _serve(rest),
        'deploy':    lambda: _deploy(rest),
        'fmt':       lambda: _format(rest),
        'lint':      lambda: _lint(rest),
        'check':     lambda: _check(rest, flags),
        'docs':      lambda: _docs(rest),
        'debug':     lambda: _debug(rest, flags),
        'js':        lambda: _transpile_js(rest),
        'node':      lambda: _transpile_node(rest),
        'kotlin':    lambda: _transpile_kotlin(rest),
        'python':    lambda: _transpile_python(rest),
        'android':   lambda: _android(rest),
        'desktop':   lambda: _desktop(rest),
        'web':       lambda: _web(rest),
        'gui':       lambda: _gui(rest),
        'ir':        lambda: _show_ir(rest),
        'vm':        lambda: _run_vm(rest, flags),
        'micropython': lambda: _micropython(rest),
        'benchmark': lambda: _benchmark(rest),
        'profile':   lambda: _profile(rest),
        'bench':     lambda: _bench(rest, flags),
        'site':      lambda: _site(rest),
        'playground': lambda: _playground(rest),
        'notebook':  lambda: _notebook(rest),
        'blocks':    lambda: _blocks(rest),
        'copilot':   lambda: _copilot(rest),
        'lsp':       lambda: _start_lsp(rest),
        'ai':        lambda: _ai(rest),
        'gen':       lambda: _ai_gen(rest),
        'explain':   lambda: _ai_explain(rest),
        'package':   lambda: _package(rest),
        'cloud':     lambda: _cloud(),
        'train':     lambda: _train(),
        'model':     lambda: _model(),
        'resolve':   lambda: _resolve(),
        'workspace': lambda: _workspace(rest),
        'ci':        lambda: _ci(rest),
        'sync-index': lambda: _sync_index(rest),
        'upgrade':   lambda: _upgrade(),
        'version':   lambda: print(f'EPL v{__version__}'),
    }

    if command in commands:
        try:
            return commands[command]() or 0
        except KeyboardInterrupt:
            print(f"\n{_dim('Interrupted.')}")
            return 130
        except SystemExit as e:
            return e.code if isinstance(e.code, int) else 1
        except Exception as e:
            from epl.errors import EPLError
            if isinstance(e, EPLError):
                print(str(e), file=sys.stderr)
            else:
                print(f"{_red('Error:')} {e}", file=sys.stderr)
            return 1

    # Default: treat as filename
    if command.endswith('.epl') or os.path.isfile(command):
        try:
            return _run_file([command] + rest, flags) or 0
        except KeyboardInterrupt:
            print(f"\n{_dim('Interrupted.')}")
            return 130
        except Exception as e:
            from epl.errors import EPLError
            if isinstance(e, EPLError):
                print(str(e), file=sys.stderr)
            else:
                print(f"{_red('Error:')} {e}", file=sys.stderr)
            return 1

    print(f"{_red('Unknown command:')} {command}")
    print(f"Run {_bold('epl --help')} for usage.")
    return 1


# ─── Run ──────────────────────────────────────────────────

def _run_file(args, flags):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        print("Usage: epl run <file.epl>")
        print("       or run from a directory containing epl.toml / epl.json")
        return 1

    filename = args[0]
    if not os.path.isfile(filename):
        print(f"{_red('Error:')} File not found: {filename}")
        return 1

    main_mod = _resolve_main_module()
    main_mod.run_file(
        filename,
        strict='--strict' in flags,
        safe_mode='--sandbox' in flags,
        force_interpret='--interpret' in flags,
        json_errors='--json' in flags,
    )
    return 0


# ─── New Project ──────────────────────────────────────────

def _new_project(args):
    """Create a new EPL project with full structure."""
    if not args:
        print(f"{_red('Error:')} No project name specified.")
        print(f"Usage: epl new <project-name> [--template basic|web|api|cli|lib]")
        return 1

    name = args[0]
    template = 'basic'
    if '--template' in args:
        idx = args.index('--template')
        if idx + 1 >= len(args):
            print(f"{_red('Error:')} Missing template name after --template.")
            return 1
        template = args[idx + 1].lower()

    valid_templates = {'basic', 'web', 'api', 'cli', 'lib'}
    if template not in valid_templates:
        print(f"{_red('Error:')} Unknown template: {template}")
        print("Available templates: basic, web, api, cli, lib")
        return 1

    # Validate project name
    import re
    if not re.match(r'^[a-zA-Z][a-zA-Z0-9_-]*$', name):
        print(f"{_red('Error:')} Invalid project name: {name}")
        print("Use letters, digits, hyphens, underscores. Must start with a letter.")
        return 1

    if os.path.exists(name):
        print(f"{_red('Error:')} Directory '{name}' already exists.")
        return 1

    # Create project structure
    os.makedirs(name)
    os.makedirs(os.path.join(name, 'src'))
    os.makedirs(os.path.join(name, 'tests'))
    os.makedirs(os.path.join(name, 'lib'))

    manifest_data, main_source, test_source, readme_body = _project_template(name, template)

    # epl.toml manifest
    from epl.package_manager import _dump_toml, _manifest_to_toml
    toml_data = _manifest_to_toml(manifest_data)
    with open(os.path.join(name, 'epl.toml'), 'w', encoding='utf-8') as f:
        f.write(_dump_toml(toml_data) + '\n')

    with open(os.path.join(name, 'src', 'main.epl'), 'w', encoding='utf-8') as f:
        f.write(main_source)

    with open(os.path.join(name, 'tests', 'test_main.epl'), 'w', encoding='utf-8') as f:
        f.write(test_source)

    with open(os.path.join(name, 'README.md'), 'w', encoding='utf-8') as f:
        f.write(readme_body)

    # .gitignore
    with open(os.path.join(name, '.gitignore'), 'w', encoding='utf-8') as f:
        f.write('# EPL\nepl_modules/\n*.exe\n*.o\nbuild/\ndist/\n')
        f.write('# Python\n__pycache__/\n*.pyc\n.venv/\n')
        f.write('# IDE\n.vscode/\n.idea/\n')

    print(f"\n  {_green('Created')} EPL project: {_bold(name)} {_dim(f'[{template}]')}")
    print(f"\n  {_dim('Project structure:')}")
    print(f"    {name}/")
    print(f"    ├── epl.toml          Project manifest")
    print(f"    ├── README.md         Documentation")
    print(f"    ├── .gitignore        Git ignore rules")
    print(f"    ├── src/")
    print(f"    │   └── main.epl      Entry point")
    print(f"    ├── tests/")
    print(f"    │   └── test_main.epl Test file")
    print(f"    └── lib/              Local libraries")
    print(f"\n  {_dim('Get started:')}")
    print(f"    cd {name}")
    print(f"    epl install                  {_dim('# sync EPL, GitHub, and Python dependencies')}")
    print(f"    epl run                      {_dim('# uses the manifest entrypoint')}")
    if template in ('web', 'api', 'lib'):
        print(f"    epl test tests/             {_dim('# run the starter tests')}")
    if template in ('web', 'api'):
        print(f"    epl serve                   {_dim('# boot the generated web app')}")
    print(f"    epl pyinstall requests       {_dim('# add a Python package for `Use python`')}")
    print(f"    epl gitinstall owner/repo    {_dim('# add a GitHub EPL package')}")
    print()
    return 0


def _project_template(name, template):
    dependencies = {}
    scripts = {
        "start": "epl run src/main.epl",
        "test": "epl test tests/",
        "build": "epl build src/main.epl",
    }
    description = f"{name} — an EPL project"

    if template == 'web':
        description = f"{name} — EPL web application"
        dependencies = {"epl-web": "^7.0.0"}
        scripts["serve"] = "epl serve src/main.epl"
        main_source = (
            f'Note: {name} web app template\n'
            'Import "epl-web"\n\n'
            f'Create app equal to create_app("{name}")\n\n'
            'Call get_route(app, "/", Function()\n'
            f'    Return html_response("<h1>{name}</h1><p>EPL web template ready.</p>", 200)\n'
            'End)\n\n'
            'Call get_route(app, "/api/health", Function()\n'
            f'    Return json_response(Map with status = "ok" and app = "{name}", 200)\n'
            'End)\n'
        )
        test_source = (
            'Import "epl-test"\n\n'
            'Call test("web template smoke", Function()\n'
            '    Call expect_equal(1 + 1, 2, "basic arithmetic still works")\n'
            'End)\n\n'
            'Call test_summary()\n'
        )
        readme_body = _template_readme(
            name,
            template,
            [
                "epl install",
                "epl serve",
                "epl run",
            ],
            "Starter web app using the supported `epl-web` facade package.",
        )
    elif template == 'api':
        description = f"{name} — EPL API service"
        dependencies = {"epl-web": "^7.0.0", "epl-db": "^7.0.0"}
        scripts["serve"] = "epl serve src/main.epl"
        main_source = (
            f'Note: {name} API template\n'
            'Import "epl-web"\n'
            'Import "epl-db"\n\n'
            'db = open(":memory:")\n'
            'Call create_table(db, "items", Map with id = "INTEGER" and name = "TEXT")\n'
            'Call execute(db, "INSERT INTO items (id, name) VALUES (1, \'example item\')")\n\n'
            f'Create app equal to create_app("{name}")\n\n'
            'Call get_route(app, "/api/health", Function()\n'
            f'    Return json_response(Map with status = "ok" and service = "{name}", 200)\n'
            'End)\n\n'
            'Call get_route(app, "/api/items", Function()\n'
            '    items = query(db, "SELECT id, name FROM items ORDER BY id")\n'
            '    Return json_response(Map with items = items, 200)\n'
            'End)\n'
        )
        test_source = (
            'Import "epl-test"\n\n'
            'Call test("api template smoke", Function()\n'
            '    Call expect_true(True, "starter API test")\n'
            'End)\n\n'
            'Call test_summary()\n'
        )
        readme_body = _template_readme(
            name,
            template,
            [
                "epl install",
                "epl serve",
                "epl run",
            ],
            "Starter API app using the supported `epl-web` and `epl-db` facade packages.",
        )
    elif template == 'cli':
        description = f"{name} — EPL CLI tool"
        main_source = (
            f'Note: {name} CLI template\n\n'
            f'Say "Welcome to {name}."\n'
            'Say "Edit src/main.epl to add your CLI behavior."\n'
        )
        test_source = (
            f'Note: Tests for {name}\n\n'
            'Assert 1 + 1 == 2\n'
            'Assert length("hello") == 5\n'
            'Say "All tests passed!"\n'
        )
        readme_body = _template_readme(
            name,
            template,
            [
                "epl run",
                "epl build",
                "epl test tests/",
            ],
            "Starter CLI project with a simple command-line oriented entrypoint.",
        )
    elif template == 'lib':
        description = f"{name} — EPL library package"
        dependencies = {"epl-test": "^7.0.0"}
        main_source = (
            f'Note: {name} library template\n\n'
            'Define Function greet Takes name\n'
            '    Return "Hello, " + name + "!"\n'
            'End\n'
        )
        test_source = (
            'Import "src/main.epl"\n'
            'Import "epl-test"\n\n'
            'Call test("greet returns a message", Function()\n'
            f'    Call expect_equal(greet("EPL"), "Hello, EPL!", "{name} greet helper")\n'
            'End)\n\n'
            'Call test_summary()\n'
        )
        readme_body = _template_readme(
            name,
            template,
            [
                "epl install",
                "epl test tests/",
                "epl run src/main.epl",
            ],
            "Starter reusable EPL library with tests using the supported `epl-test` facade package.",
        )
    else:
        main_source = (
            f'Note: {name} — Created with EPL v{__version__}\n\n'
            f'Say "Hello from {name}!"\n'
            'Say "Edit src/main.epl to get started."\n'
        )
        test_source = (
            f'Note: Tests for {name}\n\n'
            'Assert 1 + 1 == 2\n'
            'Assert length("hello") == 5\n'
            'Say "All tests passed!"\n'
        )
        readme_body = _template_readme(
            name,
            template,
            [
                "epl run",
                "epl test tests/",
                "epl build",
            ],
            "Starter EPL project.",
        )

    manifest = {
        "name": name,
        "version": "1.0.0",
        "description": description,
        "entry": "src/main.epl",
        "author": "",
        "scripts": scripts,
        "dependencies": dependencies,
    }
    return manifest, main_source, test_source, readme_body


def _template_readme(name, template, commands, summary):
    command_block = '\n'.join(commands)
    return (
        f'# {name}\n\n'
        f'{summary}\n\n'
        f'## Template\n\n'
        f'- `{template}`\n\n'
        f'## Getting Started\n\n'
        f'```bash\n'
        f'cd {name}\n'
        f'{command_block}\n'
        f'```\n\n'
        f'## Project Workflows\n\n'
        f'```bash\n'
        f'# Sync manifest-managed dependencies\n'
        f'epl install\n\n'
        f'# Add a Python package for `Use python`\n'
        f'epl pyinstall requests\n\n'
        f'# Add a GitHub EPL package dependency\n'
        f'epl gitinstall owner/repo alias\n\n'
        f'# Clone, pull, or push GitHub projects\n'
        f'epl github clone owner/repo\n'
        f'epl github pull\n'
        f'epl github push . -m "Update project"\n'
        f'```\n'
    )


# ─── Build / Compile ─────────────────────────────────────

def _build(args, flags, command='build'):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified and no epl.toml/epl.json project was found.")
        return 1

    return _legacy_dispatch(_append_global_flags([command] + args, flags))


def _run_tests(args, flags):
    if not args:
        if os.path.isdir('tests'):
            args = ['tests/']
        else:
            print(f"{_red('Error:')} No test directory found.")
            return 1

    # ─── Gap 10-11 Fix: Auto-discover and run .epl test files ───
    epl_results = {'passed': 0, 'failed': 0, 'errors': []}
    for test_dir in args:
        if os.path.isdir(test_dir):
            import glob
            patterns = [
                os.path.join(test_dir, 'test_*.epl'),
                os.path.join(test_dir, '*_test.epl'),
            ]
            epl_files = []
            for pattern in patterns:
                epl_files.extend(glob.glob(pattern))
            epl_files = sorted(set(epl_files))

            if epl_files:
                print(f"\n{_bold('Running EPL test files...')}")
                for test_file in epl_files:
                    try:
                        from epl.lexer import Lexer
                        from epl.parser import Parser
                        from epl.interpreter import Interpreter

                        with open(test_file, 'r', encoding='utf-8') as f:
                            source = f.read()
                        tokens = Lexer(source).tokenize()
                        program = Parser(tokens).parse()
                        interp = Interpreter()
                        interp.execute(program)
                        print(f"  {_green('PASS')}: {os.path.basename(test_file)}")
                        epl_results['passed'] += 1
                    except Exception as e:
                        print(f"  {_red('FAIL')}: {os.path.basename(test_file)} — {e}")
                        epl_results['failed'] += 1
                        epl_results['errors'].append((test_file, str(e)))

                total = epl_results['passed'] + epl_results['failed']
                print(f"\n  EPL Tests: {epl_results['passed']}/{total} passed")
                if epl_results['errors']:
                    for f, err in epl_results['errors']:
                        print(f"    {_red('✗')} {f}: {err}")
                print()

    # Run Python tests via legacy dispatch
    return _legacy_dispatch(_append_global_flags(['test'] + args, flags))


def _run_repl(flags):
    return _legacy_dispatch(_append_global_flags([], flags))


def _pkg_install(args):
    from epl.package_manager import install_dependencies, install_package

    frozen = '--frozen' in args
    no_save = '--no-save' in args
    local = '--local' in args
    clean_args = [a for a in args if a not in ('--frozen', '--no-save', '--local')]

    if not clean_args:
        return 0 if install_dependencies('.', frozen=frozen) else 1

    if frozen:
        print(f"{_red('Error:')} `--frozen` applies to project dependency installs, not ad hoc package installs.")
        return 1

    return 0 if install_package(clean_args[0], save=not no_save, local=local, project_path='.') else 1


def _pkg_uninstall(args):
    if not args:
        print(f"{_red('Error:')} No package specified.")
        return 1
    return _legacy_dispatch(['uninstall'] + args)


def _pkg_list():
    return _legacy_dispatch(['packages'])


def _pkg_search(args):
    from epl.package_manager import search_packages

    if not args:
        print(f"{_red('Error:')} No search query specified.")
        print("Usage: epl search <query>")
        return 1

    results = search_packages(' '.join(args))
    if not results:
        print("  No packages found.")
        return 0

    print(f"\n  {_bold('Package Search Results')} ({len(results)}):")
    print("  " + "-" * 72)
    for result in results:
        version = result.get('latest') or result.get('version', '?')
        source = result.get('source', 'unknown')
        description = result.get('description', '')
        print(f"  {result['name']:<24} {version:<12} {source:<12} {description}")
    print()
    return 0


def _pkg_lock(args):
    from epl.package_manager import create_lockfile

    if args:
        print(f"{_red('Error:')} `epl lock` does not accept positional arguments.")
        return 1
    return 0 if create_lockfile('.') is not None else 1


def _pkg_update(args):
    from epl.package_manager import update_all, update_package

    allow_major = '--major' in args
    clean_args = [a for a in args if a != '--major']
    if clean_args:
        return 0 if update_package(clean_args[0], '.', allow_major=allow_major) else 1
    return 0 if update_all('.', allow_major=allow_major) else 1


def _pkg_outdated(args):
    from epl.package_manager import outdated_packages

    if args:
        print(f"{_red('Error:')} `epl outdated` does not accept positional arguments.")
        return 1

    results = outdated_packages('.')
    if not results:
        print("  All packages up to date.")
        return 0

    print(f"  {'Package':<24} {'Current':<12} {'Latest':<12} {'Constraint':<14}")
    print(f"  {'─' * 68}")
    for item in results:
        note = " major" if item.get('major_update') else ""
        print(
            f"  {item['name']:<24} {item['current']:<12} {item['latest']:<12} "
            f"{item.get('constraint', '*'):<14}{note}"
        )
    print("\n  Run `epl update` to update compatible versions or `epl update --major` to allow major bumps.")
    return 0


def _pkg_audit(args):
    from epl.package_manager import audit_packages

    if args:
        print(f"{_red('Error:')} `epl audit` does not accept positional arguments.")
        return 1

    results = audit_packages('.')
    print(f"\n  {_bold('Package Audit')}")
    print(f"  {'─' * 40}")
    print(f"  Packages OK: {results['ok']}")
    if results['warnings']:
        print(f"  Warnings: {len(results['warnings'])}")
        for warning in results['warnings']:
            print(f"    - {warning}")
    if results['errors']:
        print(f"  Errors: {len(results['errors'])}")
        for error in results['errors']:
            print(f"    - {error}")
        return 1
    if not results['warnings']:
        print("  No problems found.")
    return 0


def _git_install(args):
    if not args:
        print(f"{_red('Error:')} No GitHub repository specified.")
        print("Usage: epl gitinstall <owner/repo> [alias]")
        return 1
    from epl.package_manager import add_github_dependency
    repo = args[0]
    alias = args[1] if len(args) > 1 and not args[1].startswith('--') else None
    return 0 if add_github_dependency(repo, alias=alias, save='--no-save' not in args, path='.') else 1


def _git_remove(args):
    if not args:
        print(f"{_red('Error:')} No GitHub dependency name specified.")
        print("Usage: epl gitremove <name-or-owner/repo>")
        return 1
    from epl.package_manager import remove_github_dependency
    return 0 if remove_github_dependency(args[0], '.') else 1


def _git_list():
    from epl.package_manager import list_github_dependencies

    deps = list_github_dependencies('.')
    if not deps:
        print("  No GitHub dependencies declared.")
        return 0

    print(f"\n  {_bold('Declared GitHub Dependencies')} ({len(deps)}):")
    print("  " + "-" * 40)
    for alias, repo in deps:
        print(f"  {alias:20s} -> {repo}")
    print()
    return 0


def _py_install(args):
    from epl.package_manager import install_python_dependencies, install_python_package

    if not args:
        return 0 if install_python_dependencies('.') else 1

    no_save = '--no-save' in args
    clean_args = [a for a in args if a != '--no-save']
    import_name = clean_args[0]
    requirement = clean_args[1] if len(clean_args) > 1 else None
    return 0 if install_python_package(import_name, requirement, save=not no_save, project_path='.') else 1


def _py_remove(args):
    if not args:
        print(f"{_red('Error:')} No Python import name specified.")
        print("Usage: epl pyremove <import-name>")
        return 1
    from epl.package_manager import remove_python_dependency
    return 0 if remove_python_dependency(args[0], '.') else 1


def _py_list():
    from epl.package_manager import list_python_dependencies

    deps = list_python_dependencies('.')
    if not deps:
        print("  No Python dependencies declared.")
        return 0

    print(f"\n  {_bold('Declared Python Dependencies')} ({len(deps)}):")
    print("  " + "-" * 40)
    for import_name, requirement in deps:
        display = import_name if requirement in ('', '*') else requirement
        print(f"  {import_name:20s} -> {display}")
    print()
    return 0


def _github(args):
    if not args:
        print(f"{_red('Error:')} No GitHub subcommand specified.")
        print("Usage: epl github <clone|pull|push> ...")
        return 1

    from epl.github_tools import clone_repo, pull_repo, push_repo

    subcommand = args[0]
    if subcommand == 'clone':
        if len(args) < 2:
            print("Usage: epl github clone <owner/repo> [dir]")
            return 1
        repo = args[1]
        dest = args[2] if len(args) > 2 and not args[2].startswith('--') else None
        return 0 if clone_repo(repo, dest=dest) else 1

    if subcommand == 'pull':
        path = args[1] if len(args) > 1 else '.'
        return 0 if pull_repo(path) else 1

    if subcommand == 'push':
        path = '.'
        message = 'Update via EPL'
        remote = 'origin'
        branch = None
        i = 1
        if i < len(args) and not args[i].startswith('-'):
            path = args[i]
            i += 1
        while i < len(args):
            arg = args[i]
            if arg in ('-m', '--message') and i + 1 < len(args):
                message = args[i + 1]
                i += 2
                continue
            if arg == '--remote' and i + 1 < len(args):
                remote = args[i + 1]
                i += 2
                continue
            if arg == '--branch' and i + 1 < len(args):
                branch = args[i + 1]
                i += 2
                continue
            print(f"{_red('Error:')} Unknown github push option: {arg}")
            return 1
        return 0 if push_repo(path=path, message=message, remote=remote, branch=branch) else 1

    print(f"{_red('Error:')} Unknown github subcommand: {subcommand}")
    return 1


def _init_project(args):
    name = args[0] if args else None
    argv = ['init']
    if name:
        argv.append(name)
    return _legacy_dispatch(argv)


def _upgrade():
    """Self-update EPL to the latest version."""
    import subprocess
    print("  Checking for EPL updates...")
    
    # Try pip upgrade (works if EPL was installed via pip)
    try:
        result = subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '--upgrade', 'epl-lang'],
            capture_output=True, text=True, timeout=60
        )
        if result.returncode == 0 and 'already satisfied' not in result.stdout.lower():
            print("  EPL updated successfully via pip!")
            return 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    
    # Try git pull (works if EPL was cloned from GitHub)
    epl_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    git_dir = os.path.join(epl_root, '.git')
    if os.path.isdir(git_dir):
        try:
            result = subprocess.run(
                ['git', 'pull', '--rebase'],
                cwd=epl_root, capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                print(f"  EPL updated via git: {result.stdout.strip()}")
                return 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
    
    print(f"  EPL is at v{__version__}. No update method available.")
    print("  To update manually: git pull  or  pip install --upgrade epl-lang")
    return 0


def _delegate(command, args):
    """Delegate a command to main.py for commands not yet ported to cli.py."""
    return _legacy_dispatch([command] + list(args))


def _serve(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified and no epl.toml/epl.json project was found.")
        return 1
    return _legacy_dispatch(['serve'] + args)


def _deploy(args):
    return _legacy_dispatch(['deploy'] + args)


def _format(args):
    from pathlib import Path
    from epl.formatter import format_source

    check_only = '--check' in args
    in_place = '--in-place' in args
    targets = [a for a in args if a not in ('--check', '--in-place')]

    if not targets:
        if os.path.isdir('src'):
            targets = ['src']
        elif os.path.isfile(_default_project_target() or ''):
            targets = [_default_project_target()]
        else:
            print(f"{_red('Error:')} No file or directory specified.")
            print("Usage: epl fmt <file|dir> [--check] [--in-place]")
            return 1

    files = []
    seen = set()
    for target in targets:
        path = Path(target)
        if path.is_dir():
            for child in sorted(path.rglob('*.epl')):
                child_key = str(child.resolve())
                if child_key not in seen:
                    files.append(child)
                    seen.add(child_key)
        elif path.is_file():
            child_key = str(path.resolve())
            if child_key not in seen:
                files.append(path)
                seen.add(child_key)
        else:
            print(f"{_yellow('Skip:')} {target} not found")

    if not files:
        print(f"{_red('Error:')} No .epl files found.")
        return 1

    changed = []
    unchanged = []
    outputs = []

    for filepath in files:
        original = filepath.read_text(encoding='utf-8')
        formatted = format_source(original)
        if formatted != original:
            changed.append(str(filepath))
            if in_place:
                filepath.write_text(formatted, encoding='utf-8')
            elif not check_only:
                outputs.append((str(filepath), formatted))
        else:
            unchanged.append(str(filepath))

    if check_only:
        for filepath in changed:
            print(f"  NEEDS FORMATTING: {filepath}")
        if not changed:
            print(f"  {_green('All files already formatted.')}")
        return 1 if changed else 0

    if in_place:
        for filepath in changed:
            print(f"  FORMATTED: {filepath}")
        for filepath in unchanged:
            print(f"  OK: {filepath}")
        return 0

    if len(outputs) == 1:
        print(outputs[0][1], end='')
        return 0

    for idx, (filepath, content) in enumerate(outputs):
        if idx:
            print()
        print(f"--- {filepath} ---")
        print(content, end='')
    return 0


def _lint(args):
    return _legacy_dispatch(['lint'] + args)


def _check(args, flags):
    """Run static type checking on EPL files."""
    import glob

    strict = '--strict' in flags
    targets = [a for a in args if not a.startswith('--')]

    if not targets:
        # Auto-discover: check for epl.toml entry or src/ directory
        target = _default_project_target()
        if target and os.path.isfile(target):
            targets = [target]
        elif os.path.isdir('src'):
            targets = glob.glob('src/**/*.epl', recursive=True)
        else:
            targets = glob.glob('**/*.epl', recursive=True)

    if not targets:
        print(f"{_red('Error:')} No .epl files found.")
        return 1

    from epl.type_checker import type_check_file

    total_errors = 0
    total_warnings = 0
    total_infos = 0

    for filepath in sorted(targets):
        if not os.path.isfile(filepath):
            # Might be a directory
            if os.path.isdir(filepath):
                targets.extend(glob.glob(os.path.join(filepath, '**/*.epl'), recursive=True))
                continue
            print(f"{_yellow('Skip:')} {filepath} not found")
            continue

        try:
            checker = type_check_file(filepath, strict=strict)
            errors = [w for w in checker.warnings if w.severity == 'error']
            warns = [w for w in checker.warnings if w.severity == 'warning']
            infos = [w for w in checker.warnings if w.severity == 'info']

            total_errors += len(errors)
            total_warnings += len(warns)
            total_infos += len(infos)

            if checker.warnings:
                print(f"\n  {_bold(filepath)}")
                print(checker.format_report())
        except Exception as e:
            print(f"\n  {_bold(filepath)}")
            print(f"  {_red('Parse Error:')} {e}")
            total_errors += 1

    # Summary
    print(f"\n{'─' * 50}")
    print(f"  {_bold('Type Check Summary')}: "
          f"{len(targets)} file(s) checked")
    if total_errors:
        print(f"  {_red(f'{total_errors} error(s)')}, "
              f"{_yellow(f'{total_warnings} warning(s)')}, "
              f"{total_infos} info(s)")
    elif total_warnings:
        print(f"  {_green('No errors.')} "
              f"{_yellow(f'{total_warnings} warning(s)')}, "
              f"{total_infos} info(s)")
    else:
        print(f"  {_green('All checks passed!')} "
              f"{total_infos} info(s)")

    return 1 if total_errors > 0 else 0


def _docs(args):
    return _legacy_dispatch(['docs'] + args)


def _debug(args, flags):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(_append_global_flags(['debug'] + args, flags))


def _transpile_js(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['js'] + args)


def _transpile_node(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['node'] + args)


def _transpile_kotlin(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['kotlin'] + args)


def _transpile_python(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['python'] + args)


def _android(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['android'] + args)


def _desktop(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['desktop'] + args)


def _web(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['web'] + args)


def _gui(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['gui'] + args)


def _show_ir(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['ir'] + args)


def _run_vm(args, flags):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(_append_global_flags(['vm'] + args, flags))


def _wasm(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['wasm'] + args)


def _micropython(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['micropython'] + args)


def _benchmark(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['benchmark'] + args)


def _profile(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['profile'] + args)


def _bench(args, flags):
    return _legacy_dispatch(_append_global_flags(['bench'] + args, flags))


def _site(args):
    return _legacy_dispatch(['site'] + args)


def _playground(args):
    return _legacy_dispatch(['playground'] + args)


def _notebook(args):
    return _legacy_dispatch(['notebook'] + args)


def _blocks(args):
    return _legacy_dispatch(['blocks'] + args)


def _copilot(args):
    return _legacy_dispatch(['copilot'] + args)


def _start_lsp(args):
    return _legacy_dispatch(['lsp'] + args)


def _ai(args):
    return _legacy_dispatch(['ai'] + args)


def _ai_gen(args):
    return _legacy_dispatch(['gen'] + args)


def _ai_explain(args):
    return _legacy_dispatch(['explain'] + args)


def _package(args):
    args = _resolve_target_args(args)
    if not args:
        print(f"{_red('Error:')} No file specified.")
        return 1
    return _legacy_dispatch(['package'] + args)


def _cloud():
    return _legacy_dispatch(['cloud'])


def _train():
    return _legacy_dispatch(['train'])


def _model():
    return _legacy_dispatch(['model'])


# ─── Phase 7 Commands ────────────────────────────────────

def _resolve():
    from epl.resolver import resolve_from_manifest, print_resolution
    result = resolve_from_manifest()
    print_resolution(result)


def _workspace(args):
    from epl.workspace import workspace_cli
    workspace_cli(list(args))


def _ci(args):
    from epl.ci_gen import ci_cli
    ci_cli(list(args))


def _sync_index(args):
    from epl.package_index import PackageIndex
    idx = PackageIndex()
    force = '--force' in args
    if idx.sync_index(force=force):
        print("  Package index synced successfully.")
    else:
        print("  Failed to sync package index.")


def _list_modules():
    """List available EPL standard library modules."""
    import json
    registry_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'stdlib', 'registry.json')
    try:
        with open(registry_path, 'r', encoding='utf-8') as f:
            registry = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        print(f"{_red('Error:')} stdlib registry not found.")
        return 1

    print(f"\n{_bold('EPL Standard Library Modules')}")
    print(_dim('Use: Import "name" to load a module') + "\n")
    for name, info in registry['modules'].items():
        print(f"  {_green(name):30s} {info['description']}")
    count = len(registry['modules'])
    print(f"\n{_dim(f'{count} modules available | EPL v{__version__}')}\n")
    return 0


# ─── Entry Point ──────────────────────────────────────────

def main():
    """CLI entry point for setuptools console_scripts."""
    sys.exit(cli_main())


if __name__ == '__main__':
    main()
