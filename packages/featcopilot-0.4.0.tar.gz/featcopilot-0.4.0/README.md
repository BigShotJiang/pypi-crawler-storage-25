# FeatCopilot 🚀

**Next-Generation LLM-Powered Auto Feature Engineering Framework**

[![Tests](https://github.com/thinkall/featcopilot/actions/workflows/tests.yml/badge.svg)](https://github.com/thinkall/featcopilot/actions/workflows/tests.yml)
[![codecov](https://codecov.io/gh/thinkall/featcopilot/graph/badge.svg)](https://codecov.io/gh/thinkall/featcopilot)

FeatCopilot automatically generates, selects, and explains predictive features using semantic understanding. It analyzes column meanings, applies domain-aware transformations, and provides human-readable explanations—turning raw data into ML-ready features in seconds.

## 🎬 Introduction Video

[![FeatCopilot Introduction](https://img.youtube.com/vi/H7m50TLGHFk/0.jpg)](https://www.youtube.com/watch?v=H7m50TLGHFk)

## 📊 Benchmark Highlights

### Simple Models Benchmark (63 Datasets)

| Configuration | Improved | Avg Improvement | Best Improvement |
|---------------|----------|-----------------|------------------|
| **Tabular Engine** | 31 (49%) | **+7.52%** | +144% (triple_interaction) |

Models: RandomForest (n_estimators=200, max_depth=20), LogisticRegression/Ridge

### AutoML Benchmark (FLAML + AutoGluon, 120s budget)

| Framework | Datasets | Improved | Avg Improvement |
|-----------|----------|----------|-----------------|
| **FLAML** | 10 | 9 (90%) | **+1.85%** |
| **AutoGluon** | 10 | 9 (90%) | **+1.55%** |

### FE Tools Comparison (FeatCopilot vs autofeat vs featuretools)

| Metric | FeatCopilot | autofeat | featuretools |
|--------|-------------|----------|--------------|
| **Win Rate** | **80%** 🏆 | 40% | 0% |
| **Avg Improvement** | **+1.89%** 🏆 | +1.46% | -2.71% |
| **Coverage** | **100%** 🏆 | 50% | 100% |
| **Composite Score** | **0.606** 🥇 | 0.351 🥉 | 0.397 🥈 |

### Key Results

- 🔥 **+144% improvement** on triple_interaction_regression (tabular only)
- 📈 **+104%** on xor_regression, **+70%** on pairwise_product_regression
- 🏆 **#1 FE tool** — beats autofeat and featuretools across 10 datasets
- 🚀 **90% AutoML improvement rate** across FLAML and AutoGluon

[View Full Benchmark Results](https://thinkall.github.io/featcopilot/user-guide/benchmarks/)

## Key Features

- 🔧 **Multi-Engine Architecture**: Tabular, time series, relational, and text feature engines
- 🤖 **LLM-Powered Intelligence**: Semantic feature discovery, domain-aware generation, and code synthesis
- 📊 **Intelligent Selection**: Statistical testing, importance ranking, and redundancy elimination
- 🔌 **Scikit-learn Compatible**: Drop-in replacement for sklearn transformers
- 📝 **Interpretable**: Every feature comes with human-readable explanations

## Installation

```bash
# Basic installation
pip install featcopilot

# With LLM capabilities
pip install featcopilot[llm]

# Full installation
pip install featcopilot[full]
```

## Quick Start

### Fast Mode (Tabular Only)

```python
from featcopilot import AutoFeatureEngineer

# Sub-second feature engineering
engineer = AutoFeatureEngineer(
    engines=['tabular'],
    max_features=50
)

X_transformed = engineer.fit_transform(X, y)  # <1 second
print(f"Features: {X.shape[1]} -> {X_transformed.shape[1]}")
```

### LLM Mode (With LiteLLM)

```python
from featcopilot import AutoFeatureEngineer

# LLM-powered semantic features
engineer = AutoFeatureEngineer(
    engines=['tabular', 'llm'],
    max_features=50
)

X_transformed = engineer.fit_transform(
    X, y,
    column_descriptions={
        'age': 'Customer age in years',
        'income': 'Annual household income in USD',
        'tenure': 'Months as customer',
    },
    task_description="Predict customer churn"
)  # 30-60 seconds

# Get LLM-generated explanations
for feature, explanation in engineer.explain_features().items():
    print(f"{feature}: {explanation}")
```

## Command-Line Interface

FeatCopilot ships a `featcopilot` CLI for shell, scripting, and agentic
(LLM tool-use) workflows — no Python glue required. All subcommands accept
`--json` for machine-readable stdout; errors are written to stderr with a
non-zero exit code so agents can parse failures deterministically.

```bash
# Discover capabilities (engines, selection methods, I/O formats)
featcopilot info --json

# Run feature engineering on a CSV / JSON file
featcopilot transform \
    --input data.csv --target label --output features.csv \
    --engines tabular --max-features 50 --json

# Inspect generated features (name, explanation, code) as JSON for an LLM
featcopilot explain --input data.csv --target label

# Equivalent module form
python -m featcopilot info --json
```

Pass `--config config.json` to provide nested keys such as `llm_config`;
explicit CLI flags override values from the config file.

> **Parquet I/O.** FeatCopilot's base install does not pin a parquet engine.
> To use `--input file.parquet` / `--output file.parquet` (or the
> `parquet` value in `--input-format` / `--output-format`), install one of
> `pyarrow` or `fastparquet`. `featcopilot info --json` reports
> `"parquet_available": true` only when an engine is importable in the
> current environment.

## Engines

### Tabular Engine
Generates polynomial features, interaction terms, and mathematical transformations.

```python
from featcopilot.engines import TabularEngine

engine = TabularEngine(
    polynomial_degree=2,
    interaction_only=False,
    include_transforms=['log', 'sqrt', 'square']
)
```

### Time Series Engine
Extracts statistical, frequency, and temporal features from time series data.

```python
from featcopilot.engines import TimeSeriesEngine

engine = TimeSeriesEngine(
    features=['mean', 'std', 'skew', 'autocorr', 'fft_coefficients']
)
```

### LLM Engine
Uses GitHub Copilot SDK (default) or LiteLLM (100+ providers) for intelligent feature generation.

```python
from featcopilot.llm import SemanticEngine

# Default: GitHub Copilot SDK
engine = SemanticEngine(
    model='gpt-5.2',
    max_suggestions=20,
    validate_features=True
)

# Alternative: LiteLLM backend
engine = SemanticEngine(
    model='gpt-4o',
    backend='litellm',
    max_suggestions=20
)
```

## Feature Selection

```python
from featcopilot.selection import FeatureSelector

selector = FeatureSelector(
    methods=['mutual_info', 'importance', 'correlation'],
    max_features=30,
    correlation_threshold=0.95
)

X_selected = selector.fit_transform(X, y)
```

## Comparison with Existing Libraries

| Feature | FeatCopilot | Featuretools | TSFresh | AutoFeat | OpenFE | CAAFE |
|---------|-------------|--------------|---------|----------|--------|-------|
| Tabular Features | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ |
| Time Series | ✅ | ⚠️ | ✅ | ❌ | ❌ | ❌ |
| Relational | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| LLM-Powered | ✅ | ❌ | ❌ | ❌ | ❌ | ✅ |
| Semantic Understanding | ✅ | ❌ | ❌ | ❌ | ❌ | ⚠️ |
| Code Generation | ✅ | ❌ | ❌ | ❌ | ❌ | ⚠️ |
| Sklearn Compatible | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ |
| Interpretable | ✅ | ✅ | ⚠️ | ⚠️ | ❌ | ✅ |

## Documentation

📖 **Full Documentation**: [https://thinkall.github.io/featcopilot/](https://thinkall.github.io/featcopilot/)

## Requirements

- Python 3.10+
- NumPy, Pandas, Scikit-learn
- GitHub Copilot SDK (default) or LiteLLM (for 100+ LLM providers)

## License

MIT License
