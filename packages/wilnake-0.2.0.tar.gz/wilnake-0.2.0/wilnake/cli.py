import argparse
import os
import sys
from pathlib import Path

# ANSI color codes
class Colors:
    RESET = "\033[0m"
    GRAY = "\033[90m"
    DARK_GRAY = "\033[2m"
    CYAN = "\033[36m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    BOLD = "\033[1m"
    DIM = "\033[2m"

def c(text: str, color: str) -> str:
    return f"{color}{text}{Colors.RESET}"

def print_banner() -> None:
    print(c("\n  >> Wilnake CLI", Colors.CYAN + Colors.BOLD))
    print(c("  └─ утилита для создания Discord ботов\n", Colors.DIM))

def main() -> None:
    parser = argparse.ArgumentParser(
        prog="wilnake",
        description="Wilnake CLI - утилита для создания Discord ботов",
        add_help=False
    )
    
    parser.add_argument("--help", action="store_true", help="Показать справку")
    subparsers = parser.add_subparsers(dest="command", help="Доступные команды")
    
    subparsers.add_parser("version", help="Показать версию")
    
    init_parser = subparsers.add_parser("init", help="Создать новый проект бота")
    init_parser.add_argument("--name", required=True, help="Имя бота")
    init_parser.add_argument("--prefix", required=True, help="Префикс команд")
    
    args = parser.parse_args()
    
    if args.help or len(sys.argv) == 1:
        print_banner()
        print_help()
        return
    
    if args.command == "version":
        print_version()
    elif args.command == "init":
        init_project(args.name, args.prefix)
    else:
        print_banner()
        print_help()


def print_help() -> None:
    print(f"""
{c('Использование:', Colors.BOLD)}
  {c('wilnake --help', Colors.CYAN)}              {c('Показать эту справку', Colors.DIM)}
  {c('wilnake version', Colors.CYAN)}             {c('Показать версию', Colors.DIM)}
  {c('wilnake init --name NAME --prefix PREFIX', Colors.CYAN)}   {c('Создать новый проект', Colors.DIM)}

{c('Пример:', Colors.BOLD)}
  {c('wilnake init --name my_bot --prefix .', Colors.GREEN)}

{c('Структура проекта:', Colors.BOLD)}
  {c('my_bot/', Colors.BLUE)}
  {c('  ├── bot.py', Colors.GRAY)}
  {c('  ├── .env', Colors.GRAY)}
  {c('  └── README.md', Colors.GRAY)}
""")


def print_version() -> None:
    try:
        from wilnake import __version__
        print(c(f"wilnake v{__version__}", Colors.GREEN + Colors.BOLD))
    except ImportError:
        print(c("wilnake v0.1.5", Colors.YELLOW + Colors.BOLD))


def init_project(name: str, prefix: str) -> None:
    project_dir = Path.cwd() / name
    
    if project_dir.exists():
        print(c(f"\n  x Ошибка: Папка '{name}' уже существует", Colors.RESET))
        sys.exit(1)
    
    print(c(f"\n  >> Создание проекта '{name}'...", Colors.CYAN))
    
    project_dir.mkdir()
    
    bot_file = project_dir / "bot.py"
    bot_code = f'''import os
from wilnake import Bot, Intents
from dotenv import load_dotenv

load_dotenv()

bot = Bot(
    prefix="{prefix}",
    status="online",
    activity="wilnake bot",
    intents=Intents.default()
)

@bot.event
async def on_ready():
    print(f"Бот {{bot.username}} запущен!")

@bot.slash_command(name="ping", description="Проверка связи")
async def ping(ctx):
    await ctx.respond("Pong!")

if __name__ == "__main__":
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        print("Ошибка: DISCORD_TOKEN не найден в .env файле")
        sys.exit(1)
    bot.run(token)
'''
    bot_file.write_text(bot_code, encoding='utf-8')
    print(c(f"  ├── bot.py", Colors.GRAY))
    
    env_file = project_dir / ".env"
    env_file.write_text("DISCORD_TOKEN=your_token_here\n", encoding='utf-8')
    print(c(f"  ├── .env", Colors.GRAY))
    
    gitignore = project_dir / ".gitignore"
    gitignore.write_text(".env\n__pycache__/\n*.pyc\n", encoding='utf-8')
    print(c(f"  ├── .gitignore", Colors.GRAY))
    
    readme = project_dir / "README.md"
    readme.write_text(f"# {name}\n\nDiscord бот, созданный с помощью Wilnake\n\n## Запуск\n\n```bash\npython bot.py\n```\n", encoding='utf-8')
    print(c(f"  └── README.md", Colors.GRAY))
    
    print(c(f"\n  ✓ Проект '{name}' успешно создан", Colors.GREEN))
    print(c(f"\n  Далее:", Colors.BOLD + Colors.YELLOW))
    print(c(f"    cd {name}", Colors.CYAN))
    print(c(f"    # Отредактируйте .env и добавьте токен бота", Colors.DIM))
    print(c(f"    pip install python-dotenv", Colors.CYAN))
    print(c(f"    python bot.py", Colors.CYAN))
    print()


if __name__ == "__main__":
    main()