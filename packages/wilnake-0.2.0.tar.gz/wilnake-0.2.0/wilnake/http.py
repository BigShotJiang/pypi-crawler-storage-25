from __future__ import annotations

import json
import time
from typing import Any
from urllib.parse import quote

import aiohttp


class DiscordHTTPClient:
    BASE_URL = "https://discord.com/api/v10"

    def __init__(self, token: str) -> None:
        self.token = token
        self.session: aiohttp.ClientSession | None = None
        self.last_latency: float = 0.0

    async def open(self) -> None:
        self.session = aiohttp.ClientSession()

    async def close(self) -> None:
        if self.session is not None:
            await self.session.close()
            self.session = None

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        data: aiohttp.FormData | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        use_bot_auth: bool = True,
    ) -> Any:
        if self.session is None:
            raise RuntimeError("HTTP session is not open")

        request_headers = {
            "User-Agent": "DiscordBot (https://discord.com, 0.2.0)",
        }
        if data is None:
            request_headers["Content-Type"] = "application/json"
        if use_bot_auth:
            request_headers["Authorization"] = f"Bot {self.token}"
        if headers:
            request_headers.update(headers)

        started_at = time.perf_counter()
        async with self.session.request(
            method,
            f"{self.BASE_URL}{path}",
            json=json,
            data=data,
            params=params,
            headers=request_headers,
        ) as response:
            self.last_latency = time.perf_counter() - started_at
            if response.status >= 400:
                text = await response.text()
                raise RuntimeError(f"Discord API error {response.status}: {text}")

            if response.content_type == "application/json":
                return await response.json()
            return None

    async def get_gateway(self) -> dict[str, Any]:
        return await self.request("GET", "/gateway/bot")

    async def get_current_application(self) -> dict[str, Any]:
        return await self.request("GET", "/oauth2/applications/@me")

    async def get_user(self, user_id: int) -> dict[str, Any]:
        return await self.request("GET", f"/users/{user_id}")

    async def get_member(self, guild_id: int, user_id: int) -> dict[str, Any]:
        return await self.request("GET", f"/guilds/{guild_id}/members/{user_id}")

    async def get_channel_messages(
        self,
        channel_id: int,
        *,
        limit: int = 50,
        before: int | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": max(1, min(limit, 100))}
        if before is not None:
            params["before"] = before
        return await self.request("GET", f"/channels/{channel_id}/messages", params=params)

    async def create_message(self, channel_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("POST", f"/channels/{channel_id}/messages", json=payload)

    async def create_message_with_files(
        self,
        channel_id: int,
        payload: dict[str, Any],
        files: list[dict[str, Any]],
    ) -> dict[str, Any]:
        form = aiohttp.FormData()
        form.add_field("payload_json", json.dumps(payload))
        for index, file in enumerate(files):
            raw = file["data"]
            filename = file.get("filename") or f"file-{index}.dat"
            content_type = file.get("content_type") or "application/octet-stream"
            form.add_field(
                f"files[{index}]",
                raw,
                filename=filename,
                content_type=content_type,
            )
        return await self.request("POST", f"/channels/{channel_id}/messages", data=form)

    async def create_dm_channel(self, recipient_id: int) -> dict[str, Any]:
        return await self.request("POST", "/users/@me/channels", json={"recipient_id": str(recipient_id)})

    async def edit_message(
        self,
        channel_id: int,
        message_id: int,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self.request("PATCH", f"/channels/{channel_id}/messages/{message_id}", json=payload)

    async def delete_message(self, channel_id: int, message_id: int) -> None:
        await self.request("DELETE", f"/channels/{channel_id}/messages/{message_id}")

    async def bulk_delete_messages(self, channel_id: int, message_ids: list[int]) -> None:
        await self.request(
            "POST",
            f"/channels/{channel_id}/messages/bulk-delete",
            json={"messages": [str(message_id) for message_id in message_ids]},
        )

    async def trigger_typing(self, channel_id: int) -> None:
        await self.request("POST", f"/channels/{channel_id}/typing")

    async def add_reaction(self, channel_id: int, message_id: int, emoji: str) -> None:
        await self.request(
            "PUT",
            f"/channels/{channel_id}/messages/{message_id}/reactions/{quote(emoji, safe='')}/@me",
        )

    async def pin_message(self, channel_id: int, message_id: int) -> None:
        await self.request("PUT", f"/channels/{channel_id}/pins/{message_id}")

    async def unpin_message(self, channel_id: int, message_id: int) -> None:
        await self.request("DELETE", f"/channels/{channel_id}/pins/{message_id}")

    async def modify_channel(self, channel_id: int, payload: dict[str, Any]) -> dict[str, Any]:
        return await self.request("PATCH", f"/channels/{channel_id}", json=payload)

    async def kick_member(self, guild_id: int, user_id: int, *, reason: str | None = None) -> None:
        await self.request(
            "DELETE",
            f"/guilds/{guild_id}/members/{user_id}",
            headers=self._reason_headers(reason),
        )

    async def ban_member(
        self,
        guild_id: int,
        user_id: int,
        *,
        reason: str | None = None,
        delete_message_seconds: int = 0,
    ) -> None:
        await self.request(
            "PUT",
            f"/guilds/{guild_id}/bans/{user_id}",
            json={"delete_message_seconds": max(0, min(delete_message_seconds, 604800))},
            headers=self._reason_headers(reason),
        )

    async def unban_member(self, guild_id: int, user_id: int, *, reason: str | None = None) -> None:
        await self.request(
            "DELETE",
            f"/guilds/{guild_id}/bans/{user_id}",
            headers=self._reason_headers(reason),
        )

    async def edit_member(
        self,
        guild_id: int,
        user_id: int,
        payload: dict[str, Any],
        *,
        reason: str | None = None,
    ) -> dict[str, Any]:
        return await self.request(
            "PATCH",
            f"/guilds/{guild_id}/members/{user_id}",
            json=payload,
            headers=self._reason_headers(reason),
        )

    async def bulk_overwrite_global_commands(
        self,
        application_id: int,
        payload: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        return await self.request("PUT", f"/applications/{application_id}/commands", json=payload)

    async def bulk_overwrite_guild_commands(
        self,
        application_id: int,
        guild_id: int,
        payload: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        return await self.request(
            "PUT",
            f"/applications/{application_id}/guilds/{guild_id}/commands",
            json=payload,
        )

    async def create_interaction_response(
        self,
        interaction_id: str,
        interaction_token: str,
        payload: dict[str, Any],
    ) -> None:
        await self.request(
            "POST",
            f"/interactions/{interaction_id}/{interaction_token}/callback",
            json=payload,
            use_bot_auth=False,
        )

    async def create_followup_message(
        self,
        application_id: int,
        interaction_token: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self.request(
            "POST",
            f"/webhooks/{application_id}/{interaction_token}",
            json=payload,
            use_bot_auth=False,
        )

    async def edit_original_interaction_response(
        self,
        application_id: int,
        interaction_token: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self.request(
            "PATCH",
            f"/webhooks/{application_id}/{interaction_token}/messages/@original",
            json=payload,
            use_bot_auth=False,
        )

    async def delete_original_interaction_response(
        self,
        application_id: int,
        interaction_token: str,
    ) -> None:
        await self.request(
            "DELETE",
            f"/webhooks/{application_id}/{interaction_token}/messages/@original",
            use_bot_auth=False,
        )

    def _reason_headers(self, reason: str | None) -> dict[str, str] | None:
        if not reason:
            return None
        return {"X-Audit-Log-Reason": quote(reason, safe="")}
