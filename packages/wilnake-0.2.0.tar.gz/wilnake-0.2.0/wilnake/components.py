from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

from .command import Callback


class ButtonStyle:
    PRIMARY = 1
    SECONDARY = 2
    SUCCESS = 3
    DANGER = 4
    LINK = 5


class SelectMenuType:
    STRING = 3
    USER = 5
    ROLE = 6
    MENTIONABLE = 7
    CHANNEL = 8


@dataclass(slots=True)
class Button:
    style: int
    label: str | None = None
    custom_id: str | None = None
    url: str | None = None
    disabled: bool = False
    emoji: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"type": 2, "style": self.style}
        if self.label is not None:
            payload["label"] = self.label
        if self.custom_id is not None:
            payload["custom_id"] = self.custom_id
        if self.url is not None:
            payload["url"] = self.url
        if self.disabled:
            payload["disabled"] = True
        if self.emoji is not None:
            payload["emoji"] = self.emoji
        return payload


@dataclass(slots=True)
class SelectOption:
    label: str
    value: str
    description: str | None = None
    emoji: dict[str, Any] | None = None
    default: bool = False

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"label": self.label, "value": self.value}
        if self.description is not None:
            payload["description"] = self.description
        if self.emoji is not None:
            payload["emoji"] = self.emoji
        if self.default:
            payload["default"] = True
        return payload


@dataclass(slots=True)
class BaseSelectMenu:
    custom_id: str
    placeholder: str | None = None
    min_values: int | None = None
    max_values: int | None = None
    disabled: bool = False

    def _base_payload(self, *, component_type: int) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "type": component_type,
            "custom_id": self.custom_id,
        }
        if self.placeholder is not None:
            payload["placeholder"] = self.placeholder
        if self.min_values is not None:
            payload["min_values"] = self.min_values
        if self.max_values is not None:
            payload["max_values"] = self.max_values
        if self.disabled:
            payload["disabled"] = True
        return payload

    def to_dict(self) -> dict[str, Any]:
        raise NotImplementedError


@dataclass(slots=True)
class StringSelectMenu(BaseSelectMenu):
    options: tuple[SelectOption, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if not self.options:
            raise ValueError("StringSelectMenu must contain at least one option")
        if len(self.options) > 25:
            raise ValueError("StringSelectMenu may contain at most 25 options")

    def to_dict(self) -> dict[str, Any]:
        payload = self._base_payload(component_type=SelectMenuType.STRING)
        payload["options"] = [option.to_dict() for option in self.options]
        return payload


@dataclass(slots=True)
class EntitySelectMenu(BaseSelectMenu):
    component_type: int = SelectMenuType.USER
    default_values: tuple[dict[str, Any], ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        payload = self._base_payload(component_type=self.component_type)
        if self.default_values:
            payload["default_values"] = list(self.default_values)
        return payload


@dataclass(slots=True)
class UserSelectMenu(EntitySelectMenu):
    component_type: int = SelectMenuType.USER


@dataclass(slots=True)
class RoleSelectMenu(EntitySelectMenu):
    component_type: int = SelectMenuType.ROLE


@dataclass(slots=True)
class MentionableSelectMenu(EntitySelectMenu):
    component_type: int = SelectMenuType.MENTIONABLE


@dataclass(slots=True)
class ChannelSelectMenu(EntitySelectMenu):
    channel_types: tuple[int, ...] = field(default_factory=tuple)
    component_type: int = SelectMenuType.CHANNEL

    def to_dict(self) -> dict[str, Any]:
        payload = super().to_dict()
        if self.channel_types:
            payload["channel_types"] = list(self.channel_types)
        return payload


@dataclass(slots=True)
class ActionRow:
    components: tuple[Any, ...]

    def __post_init__(self) -> None:
        if not self.components:
            raise ValueError("ActionRow must contain at least one component")
        if len(self.components) > 5:
            raise ValueError("ActionRow may contain at most 5 components")

    def to_dict(self) -> dict[str, Any]:
        return {"type": 1, "components": [component.to_dict() for component in self.components]}


@dataclass(slots=True)
class ComponentListener:
    custom_id: str
    callback: Callback
    component_types: tuple[int, ...] = field(default_factory=tuple)
    metadata: dict[str, Any] = field(default_factory=dict)


ButtonListener = ComponentListener


def button(*, custom_id: str, **metadata: Any) -> Callable[[Callback], Callback]:
    def decorator(callback: Callback) -> Callback:
        callback.__wilnake_component__ = {
            "custom_id": custom_id,
            "component_types": (2,),
            "metadata": metadata,
        }
        return callback

    return decorator


def select(
    *,
    custom_id: str,
    types: Iterable[int] | None = None,
    **metadata: Any,
) -> Callable[[Callback], Callback]:
    def decorator(callback: Callback) -> Callback:
        callback.__wilnake_component__ = {
            "custom_id": custom_id,
            "component_types": tuple(types or ()),
            "metadata": metadata,
        }
        return callback

    return decorator
