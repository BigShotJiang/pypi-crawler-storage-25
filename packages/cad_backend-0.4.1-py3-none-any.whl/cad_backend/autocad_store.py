#!/usr/bin/env python3
"""
AutoCAD SQLite API store — query engine for the prebuilt API index.

Provides lexical search, hybrid search, type/member lookup, and
symbol resolution against the autocad_api.sqlite database.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
from pathlib import Path
from typing import Any


DEFAULT_DB = Path(__file__).parent / "autocad_api.sqlite"
DEFAULT_ACAD_VERSION = "2018"

# ─── Domain configuration ─────────────────────────────────────────────

DOMAIN_HINTS: dict[str, dict[str, Any]] = {
    "database": {
        "assembly": "acdbmgd.dll",
        "keywords": [
            "entity", "block", "layer", "table", "xref", "database", "dbobject",
            "实体", "图块", "块", "图层", "数据库", "对象", "图纸",
        ],
        "semantic": ["DBObject", "Entity", "BlockTable", "LayerTable", "Database", "Transaction"],
    },
    "application": {
        "assembly": "acmgd.dll",
        "keywords": [
            "application", "document", "doc", "app",
            "应用", "文档",
        ],
        "semantic": ["Application", "Document", "DocumentManager"],
    },
    "editor": {
        "assembly": "AcCoreMgd.dll",
        "keywords": [
            "editor", "command", "prompt", "commandmethod",
            "编辑器", "命令", "提示",
        ],
        "semantic": ["Editor", "CommandMethod", "PromptResult"],
    },
    "geometry": {
        "assembly": "acdbmgd.dll",
        "keywords": [
            "point", "vector", "curve", "line", "circle", "arc", "polyline",
            "spline", "ellipse", "ray", "xline",
            "点", "线", "圆", "弧", "多段线", "样条",
        ],
        "semantic": ["Point3d", "Vector3d", "Curve", "Line", "Circle", "Arc", "Polyline"],
    },
    "ui": {
        "assembly": "AcWindows.dll",
        "keywords": [
            "palette", "toolbar", "ribbon", "menu", "winform", "wpf",
            "界面", "工具栏", "菜单", "面板",
        ],
        "semantic": ["PaletteSet", "RibbonTab", "RibbonPanel"],
    },
    "interop": {
        "assembly": "Autodesk.AutoCAD.Interop.dll",
        "keywords": ["com", "interop", "autocad object"],
        "semantic": ["AcadDocument", "AcadModelSpace"],
    },
    "selection": {
        "assembly": "AcCoreMgd.dll",
        "keywords": [
            "select", "pick", "filter", "selection",
            "选择", "过滤", "拾取",
        ],
        "semantic": ["SelectionSet", "PromptSelectionResult", "SelectionFilter"],
    },
    "dimension": {
        "assembly": "acdbmgd.dll",
        "keywords": [
            "dimension", "annotate", "text", "mtext", "tolerance",
            "标注", "文字", "注释", "公差",
        ],
        "semantic": ["Dimension", "DBText", "MText", "AlignedDimension", "RotatedDimension"],
    },
    "hatch": {
        "assembly": "acdbmgd.dll",
        "keywords": ["hatch", "fill", "pattern", "填充", "图案"],
        "semantic": ["Hatch", "HatchPattern"],
    },
    "table": {
        "assembly": "acdbmgd.dll",
        "keywords": ["table", "cell", "表格", "单元格"],
        "semantic": ["Table", "TableStyle"],
    },
    "solid": {
        "assembly": "acdbmgd.dll",
        "keywords": [
            "solid", "3dsolid", "body", "face", "edge", "vertex",
            "subentity", "extrude", "revolve", "boolean", "union", "subtract", "intersect",
            "chamfer", "fillet", "shell", "taper", "offset",
            "实体", "面", "边", "顶点", "拉伸", "旋转", "布尔", "倒角", "圆角",
        ],
        "semantic": ["Solid3d", "SubentityId", "SubentityType", "FullSubentityPath", "Extents3d", "NurbSurface"],
    },
}

# Canonical term mapping (lowercase -> correct casing)
CANONICAL_TERMS: dict[str, str] = {
    # Core types
    "point3d": "Point3d",
    "vector3d": "Vector3d",
    "matrix3d": "Matrix3d",
    "extents3d": "Extents3d",
    # Database
    "entity": "Entity",
    "dbobject": "DBObject",
    "database": "Database",
    "transaction": "Transaction",
    "blocktable": "BlockTable",
    "blocktablerecord": "BlockTableRecord",
    "layertable": "LayerTable",
    "layertablerecord": "LayerTableRecord",
    "linetypetable": "LinetypeTable",
    "dimstyletable": "DimStyleTable",
    "textstyletable": "TextStyleTable",
    "ucs": "UcsTable",
    "viewport": "ViewportTable",
    "regapp": "RegAppTable",
    "xref": "Xref",
    "xrecord": "Xrecord",
    "dictionary": "DBDictionary",
    # Geometry
    "curve": "Curve",
    "line": "Line",
    "circle": "Circle",
    "arc": "Arc",
    "polyline": "Polyline",
    "polyline2d": "Polyline2d",
    "polyline3d": "Polyline3d",
    "spline": "Spline",
    "ellipse": "Ellipse",
    "ray": "Ray",
    "xline": "Xline",
    "region": "Region",
    "solid3d": "Solid3d",
    "3dsolid": "Solid3d",
    "body": "Solid3d",
    "surface": "Surface",
    "nurbssurface": "NurbSurface",
    "nurbssurface": "NurbSurface",
    # Face / Subentity
    "face": "Face",
    "faces": "Face",
    "subentity": "SubentityId",
    "subentityid": "SubentityId",
    "subentitytype": "SubentityType",
    "fullsubentitypath": "FullSubentityPath",
    # Bounding box
    "boundingbox": "Extents3d",
    "extents": "Extents3d",
    "geometricextents": "GeometricExtents",
    # Annotations
    "dimension": "Dimension",
    "aligneddimension": "AlignedDimension",
    "rotateddimension": "RotatedDimension",
    "dbtext": "DBText",
    "mtext": "MText",
    "leader": "Leader",
    "mleader": "MLeader",
    "table": "Table",
    "hatch": "Hatch",
    "solid": "Solid",
    # Blocks & References
    "blockreference": "BlockReference",
    "attribute": "AttributeReference",
    "attdef": "AttributeDefinition",
    "externalreference": "ExternalReference",
    # Application
    "application": "Application",
    "document": "Document",
    "documentmanager": "DocumentManager",
    "editor": "Editor",
    # Selection
    "selectionset": "SelectionSet",
    "promptresult": "PromptResult",
    "promptselectionresult": "PromptSelectionResult",
    "selectionfilter": "SelectionFilter",
    "promptoptions": "PromptPointOptions",
    "promptpointresult": "PromptPointResult",
    "promptstringresult": "PromptStringResult",
    "promptdoubleoptions": "PromptDoubleOptions",
    "promptkeywordoptions": "PromptKeywordOptions",
    # Model space
    "modelspace": "ModelSpace",
    "paperspace": "PaperSpace",
    # Common methods
    "addline": "AddLine",
    "addcircle": "AddCircle",
    "addarc": "AddArc",
    "addpolyline": "AddPolyline",
    "addtext": "AddText",
    "addmtext": "AddMText",
    "addblockreference": "AddBlockReference",
    "addhatch": "AddHatch",
    "addpoint": "AddPoint",
    "adddimension": "AddDimension",
    "getpoint": "GetPoint",
    "getstring": "GetString",
    "getinteger": "GetInteger",
    "getdouble": "GetDouble",
    "getentity": "GetEntity",
    "getselection": "GetSelection",
    "getboundingbox": "GetBoundingBox",
    "transformby": "TransformBy",
    "erase": "Erase",
    "highlight": "Highlight",
    "close": "Close",
    "save": "Save",
    "saveas": "SaveAs",
    "open": "Open",
    "zoomextents": "ZoomExtents",
    "zoomall": "ZoomAll",
    # Interop
    "acaddocument": "AcadDocument",
    "acadmodelspace": "AcadModelSpace",
    "acadentity": "AcadEntity",
}

# Skip words (noise)
SKIP_WORDS = frozenset({
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "as", "into", "about", "how", "what",
    "which", "who", "when", "where", "why", "this", "that", "these", "those",
    "it", "its", "and", "or", "not", "no", "but", "if", "then", "else",
    "get", "set", "add", "remove", "delete", "create", "new", "find",
    "用", "的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都",
    "一", "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会",
    "着", "没有", "看", "好", "自己", "这",
})


# ─── Database access ──────────────────────────────────────────────────

_conn_cache: dict[str, sqlite3.Connection] = {}


def open_database(db_path: str | Path | None = None) -> sqlite3.Connection:
    path = str(db_path or DEFAULT_DB)
    if path in _conn_cache:
        return _conn_cache[path]
    if not os.path.exists(path):
        raise FileNotFoundError(f"SQLite database not found: {path}")
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    _conn_cache[path] = conn
    return conn


def index_status(db_path: str | Path | None = None, acad_version: str = DEFAULT_ACAD_VERSION) -> dict:
    conn = open_database(db_path)
    rows = conn.execute(
        "SELECT assembly, record_type, COUNT(*) as cnt FROM api_records WHERE acad_version=? GROUP BY assembly, record_type",
        (acad_version,),
    ).fetchall()
    if not rows:
        return {"status": "empty", "db": str(db_path or DEFAULT_DB), "acadVersion": acad_version}
    by_assembly: dict[str, dict[str, int]] = {}
    totals: dict[str, int] = {}
    for row in rows:
        asm = row["assembly"]
        rt = row["record_type"]
        cnt = row["cnt"]
        by_assembly.setdefault(asm, {})[rt] = cnt
        totals[rt] = totals.get(rt, 0) + cnt
    return {
        "status": "ready",
        "db": str(db_path or DEFAULT_DB),
        "acadVersion": acad_version,
        "totals": totals,
        "byAssembly": by_assembly,
    }


# ─── Search terms ─────────────────────────────────────────────────────

# Chinese to English API term mapping
_CHINESE_TO_ENGLISH: dict[str, list[str]] = {
    "体": ["Solid3d", "Body"],
    "面": ["Face"],
    "边": ["Edge"],
    "点": ["Point3d"],
    "线": ["Line", "Curve"],
    "圆": ["Circle"],
    "弧": ["Arc"],
    "实体": ["Solid3d"],
    "直线": ["Line"],
    "圆弧": ["Arc"],
    "多段线": ["Polyline"],
    "样条": ["Spline"],
    "椭圆": ["Ellipse"],
    "图块": ["BlockTable", "BlockReference"],
    "块": ["BlockTable", "BlockReference"],
    "图纸": ["Database", "Document"],
    "图层": ["LayerTable"],
    "文字": ["DBText", "MText"],
    "标注": ["Dimension"],
    "填充": ["Hatch"],
    "选择": ["SelectionSet", "PromptSelectionResult"],
    "过滤": ["SelectionFilter"],
    "文档": ["Document"],
    "编辑器": ["Editor"],
    "命令": ["CommandMethod"],
    "事务": ["Transaction"],
    "数据库": ["Database"],
    "几何": ["Geometry"],
    "拉伸": ["ExtrudeFaces"],
    "旋转": ["TaperFaces"],
    "倒角": ["ChamferEdges"],
    "圆角": ["FilletEdges"],
    "偏移": ["OffsetFaces"],
    "复制": ["CopyFace", "CopyEdge"],
    "删除": ["RemoveFaces", "Erase"],
    "布尔": ["BooleanOperation"],
    "并集": ["BooleanOperationType"],
    "获取": ["Get"],
    "所有": [],
    "求": ["Get"],
    "最大": ["Max"],
    "方向": ["Vector3d"],
    "包围盒": ["Extents3d", "GetBoundingBox"],
    "边界框": ["Extents3d", "GetBoundingBox"],
}


def _extract_identifiers(query: str) -> list[str]:
    """Extract CamelCase splits and raw tokens from query."""
    tokens = re.findall(r"[A-Za-z_][A-Za-z0-9_]*|[一-鿿]+", query)
    result = []
    for tok in tokens:
        lower = tok.lower()
        if lower in SKIP_WORDS and len(tok) <= 3:
            continue
        # CamelCase split
        parts = re.sub(r"([a-z])([A-Z])", r"\1 \2", tok).split()
        result.extend(parts)
        result.append(tok)
        # Chinese: map to English API terms
        if re.match(r"[一-鿿]", tok):
            for i in range(len(tok)):
                for length in range(min(4, len(tok) - i), 0, -1):
                    segment = tok[i:i+length]
                    if segment in _CHINESE_TO_ENGLISH:
                        result.extend(_CHINESE_TO_ENGLISH[segment])
                        break
    return list(dict.fromkeys(result))  # dedupe preserving order


def _build_search_terms(query: str) -> list[str]:
    """Build canonical search terms from a query string."""
    identifiers = _extract_identifiers(query)
    terms = []
    seen = set()
    for ident in identifiers:
        lower = ident.lower()
        canonical = CANONICAL_TERMS.get(lower)
        if canonical and canonical.lower() not in seen:
            terms.append(canonical)
            seen.add(canonical.lower())
        elif lower not in seen and lower not in SKIP_WORDS:
            terms.append(ident)
            seen.add(lower)
    return terms[:14]


def _infer_intent(query: str) -> dict[str, Any]:
    """Infer domain and assembly intent from query text."""
    query_lower = query.lower()
    domains = set()
    assemblies = set()
    for domain, cfg in DOMAIN_HINTS.items():
        for kw in cfg["keywords"]:
            if kw in query_lower:
                domains.add(domain)
                assemblies.add(cfg["assembly"])
                break
    return {"domains": list(domains), "assemblies": list(assemblies)}


# ─── Lexical search ───────────────────────────────────────────────────

def _score_search_row(row: sqlite3.Row, query: str, terms: list[str]) -> int:
    """Score a single search result row."""
    score = 0
    member_name = (row["member_name"] or "")
    full_name = (row["full_name"] or "")
    type_name = (row["type_name"] or "")
    record_type = (row["record_type"] or "")
    query_lower = query.lower()
    member_lower = member_name.lower()
    full_lower = full_name.lower()
    type_lower = type_name.lower()

    # Exact match bonuses
    if query_lower == member_lower:
        score += 700
    elif query_lower == full_lower:
        score += 650
    elif query_lower == type_lower:
        score += 560

    # Containment bonuses
    if query_lower in member_lower:
        score += 650
    elif query_lower in full_lower:
        score += 560
    elif query_lower in type_lower:
        score += 420

    # Per-term matching
    hits = 0
    for term in terms:
        t_lower = term.lower()
        if t_lower == member_lower:
            score += 360
            hits += 1
        elif t_lower == full_lower:
            score += 300
            hits += 1
        elif t_lower == type_lower:
            score += 280
            hits += 1
        elif member_lower.startswith(t_lower):
            score += 170
            hits += 1
        elif full_lower.startswith(t_lower):
            score += 120
            hits += 1
        elif t_lower in member_lower:
            score += 80
            hits += 1
        elif t_lower in full_lower:
            score += 45
            hits += 1

    # Multi-term bonus
    if hits >= 2:
        score += 80 + 20 * hits

    # Record type bonus
    if record_type == "method":
        score += 30
    elif record_type == "type":
        score += 20

    # Visibility bonus
    vis = (row["visibility"] or "")
    if vis == "public":
        score += 12

    # Penalty for internal names
    if member_name.startswith("_"):
        score -= 140

    # ─── Pattern bonuses (AutoCAD-specific) ───
    ql = query_lower
    ml = member_lower
    tl = type_lower

    # Solid3d face/subentity operations
    if ("solid" in ql or "face" in ql or "体" in ql or "面" in ql) and "solid3d" in tl:
        score += 400
    if ("face" in ql or "面" in ql) and ("subentity" in ml or "face" in ml):
        score += 500
    if "bounding" in ql and ("extents" in ml or "geometric" in ml):
        score += 600
    if "explode" in ql and ml == "explode":
        score += 500

    # Entity creation methods
    if ("直线" in ql or "line" in ql) and ml == "addline":
        score += 600
    if ("圆" in ql or "circle" in ql) and ml == "addcircle":
        score += 600
    if ("弧" in ql or "arc" in ql) and ml == "addarc":
        score += 600
    if ("多段线" in ql or "polyline" in ql) and ml == "addpolyline":
        score += 600
    if ("文字" in ql or "text" in ql) and ml == "addtext":
        score += 500
    if ("标注" in ql or "dimension" in ql) and "adddimension" in ml:
        score += 500

    # Block/Layer operations
    if ("图块" in ql or "block" in ql or "块" in ql) and "block" in tl:
        score += 400
    if ("图块" in ql or "block" in ql or "块" in ql) and "blockreferenc" in tl:
        score += 400
    if ("图层" in ql or "layer" in ql) and "layer" in tl:
        score += 300

    # Transaction/Database
    if ("事务" in ql or "transaction" in ql) and "transaction" in tl:
        score += 400
    if ("数据库" in ql or "database" in ql) and "database" in tl:
        score += 400

    # Selection
    if ("选择" in ql or "select" in ql) and ("selection" in ml or "prompt" in ml):
        score += 400

    return score


def search_api(
    query: str,
    limit: int = 20,
    assembly: str | None = None,
    kind: str | None = None,
    db_path: str | Path | None = None,
    acad_version: str = DEFAULT_ACAD_VERSION,
) -> list[dict]:
    """Multi-stage cascading lexical search."""
    conn = open_database(db_path)
    terms = _build_search_terms(query)
    results: dict[str, dict] = {}

    def _add_rows(rows: list[sqlite3.Row], bonus: int):
        for row in rows:
            key = f"{row['record_type']}|{row['assembly']}|{row['full_name']}|{row['member_name']}"
            if key not in results:
                payload = json.loads(row["payload_json"])
                score = _score_search_row(row, query, terms) + bonus
                results[key] = {"score": score, "payload": payload, "assembly": row["assembly"], "record_type": row["record_type"]}

    # Build WHERE clauses
    version_clause = "acad_version=?"
    version_params: list[Any] = [acad_version]
    asm_clause = ""
    asm_params: list[str] = []
    if assembly:
        asm_clause = " AND assembly=?"
        asm_params = [assembly]
    kind_clause = ""
    kind_params: list[str] = []
    if kind:
        kind_clause = " AND record_type=?"
        kind_params = [kind]

    base_where = version_clause + asm_clause + kind_clause
    base_params = version_params + asm_params + kind_params

    # Stage 1: Exact match
    if terms:
        placeholders = ",".join("?" * len(terms))
        for col in ("member_name", "full_name", "type_name"):
            rows = conn.execute(
                f"SELECT * FROM api_records WHERE {base_where} AND {col} IN ({placeholders}) LIMIT 500",
                base_params + terms,
            ).fetchall()
            _add_rows(rows, 160)

    # Stage 2: Case-insensitive exact
    if terms:
        for col in ("member_name", "full_name", "type_name"):
            for term in terms:
                rows = conn.execute(
                    f"SELECT * FROM api_records WHERE {base_where} AND {col}=? COLLATE NOCASE LIMIT 200",
                    base_params + [term],
                ).fetchall()
                _add_rows(rows, 130)

    # Stage 3: Prefix match
    for term in terms[:6]:
        pattern = f"{term}%"
        for col in ("member_name", "full_name", "type_name"):
            rows = conn.execute(
                f"SELECT * FROM api_records WHERE {base_where} AND {col} LIKE ? LIMIT 100",
                base_params + [pattern],
            ).fetchall()
            _add_rows(rows, 90)

    # Stage 4: Contains match
    for term in terms[:4]:
        pattern = f"%{term}%"
        for col in ("member_name", "full_name", "type_name"):
            rows = conn.execute(
                f"SELECT * FROM api_records WHERE {base_where} AND {col} LIKE ? LIMIT 50",
                base_params + [pattern],
            ).fetchall()
            _add_rows(rows, 35)

    # Stage 5: Signature match
    for term in terms[:3]:
        pattern = f"%{term}%"
        rows = conn.execute(
            f"SELECT * FROM api_records WHERE {base_where} AND signature LIKE ? LIMIT 30",
            base_params + [pattern],
        ).fetchall()
        _add_rows(rows, 5)

    # Sort by score, return top N
    sorted_results = sorted(results.values(), key=lambda x: x["score"], reverse=True)
    return sorted_results[:limit]


# ─── Hybrid search ────────────────────────────────────────────────────

def hybrid_search_api(
    query: str,
    limit: int = 20,
    assembly: str | None = None,
    domain: str | None = None,
    kind: str | None = None,
    type_name: str | None = None,
    db_path: str | Path | None = None,
    acad_version: str = DEFAULT_ACAD_VERSION,
) -> dict:
    """Combined lexical + semantic search with reranking."""
    intent = _infer_intent(query)
    assemblies = [assembly] if assembly else intent["assemblies"]
    domains = [domain] if domain else intent["domains"]

    # Phase 1: Lexical search
    all_results: dict[str, dict] = {}

    if assemblies:
        for asm in assemblies:
            for r in search_api(query, limit=limit * 2, assembly=asm, kind=kind, db_path=db_path, acad_version=acad_version):
                key = f"{r['record_type']}|{r['assembly']}|{r['payload'].get('fullName', '')}|{r['payload'].get('name', '')}"
                if key not in all_results:
                    r["lexical"] = True
                    all_results[key] = r
    else:
        for r in search_api(query, limit=limit * 2, kind=kind, db_path=db_path, acad_version=acad_version):
            key = f"{r['record_type']}|{r['assembly']}|{r['payload'].get('fullName', '')}|{r['payload'].get('name', '')}"
            if key not in all_results:
                r["lexical"] = True
                all_results[key] = r

    # Phase 2: Semantic alias search
    semantic_terms = []
    for d in domains:
        cfg = DOMAIN_HINTS.get(d, {})
        semantic_terms.extend(cfg.get("semantic", []))

    if semantic_terms:
        for term in semantic_terms[:5]:
            for r in search_api(term, limit=10, kind=kind, db_path=db_path, acad_version=acad_version):
                key = f"{r['record_type']}|{r['assembly']}|{r['payload'].get('fullName', '')}|{r['payload'].get('name', '')}"
                if key in all_results:
                    all_results[key]["semantic"] = True
                    all_results[key]["score"] += 250
                else:
                    r["semantic"] = True
                    r["score"] += 250
                    all_results[key] = r

    # Phase 3: Reranking
    for key, r in all_results.items():
        payload = r["payload"]
        name = payload.get("name", "")
        full_name = payload.get("fullName", payload.get("type", ""))
        record_type = r["record_type"]

        # Lexical bonus
        if r.get("lexical"):
            r["score"] += 1000
        elif not r.get("semantic"):
            r["score"] -= 450

        # Both channels bonus
        if r.get("lexical") and r.get("semantic"):
            r["score"] += 360

        # Record type bonus
        if record_type == "method":
            r["score"] += 90
        elif record_type == "type":
            r["score"] += 40

        # Name-in-query bonus
        query_lower = query.lower()
        if name and name.lower() in query_lower:
            r["score"] += 260
        if full_name and full_name.lower() in query_lower:
            r["score"] += 200

        # Domain bonus
        asm = r["assembly"]
        for d in domains:
            cfg = DOMAIN_HINTS.get(d, {})
            if cfg.get("assembly") == asm:
                r["score"] += 260

    sorted_results = sorted(all_results.values(), key=lambda x: x["score"], reverse=True)

    # Filter by typeName if specified
    if type_name:
        sorted_results = [r for r in sorted_results if r["payload"].get("type", "") == type_name or r["payload"].get("fullName", "") == type_name]

    return {
        "query": query,
        "inferred": {"domains": domains, "assemblies": assemblies},
        "results": sorted_results[:limit],
    }


# ─── Type / Member lookup ─────────────────────────────────────────────

def get_type(
    type_name: str,
    assembly: str | None = None,
    db_path: str | Path | None = None,
    acad_version: str = DEFAULT_ACAD_VERSION,
) -> dict | None:
    conn = open_database(db_path)
    params: list[Any] = [acad_version, type_name]
    asm_clause = ""
    if assembly:
        asm_clause = " AND assembly=?"
        params.append(assembly)
    row = conn.execute(
        f"SELECT payload_json, assembly FROM api_records WHERE acad_version=? AND record_type='type' AND full_name=?{asm_clause}",
        params,
    ).fetchone()
    if not row:
        return None
    payload = json.loads(row["payload_json"])
    return {"status": "ready", "type": payload, "assembly": row["assembly"]}


def get_members(
    type_name: str,
    kind: str | None = None,
    name: str | None = None,
    assembly: str | None = None,
    limit: int = 50,
    db_path: str | Path | None = None,
    acad_version: str = DEFAULT_ACAD_VERSION,
) -> list[dict]:
    conn = open_database(db_path)
    where = "acad_version=? AND type_name=?"
    params: list[Any] = [acad_version, type_name]
    if kind:
        where += " AND record_type=?"
        params.append(kind)
    if assembly:
        where += " AND assembly=?"
        params.append(assembly)
    if name:
        # Cascading name match
        results = []
        # Exact
        rows = conn.execute(
            f"SELECT * FROM api_records WHERE {where} AND member_name=? LIMIT ?", params + [name, limit]
        ).fetchall()
        if rows:
            results.extend(rows)
        else:
            # Case-insensitive
            rows = conn.execute(
                f"SELECT * FROM api_records WHERE {where} AND member_name=? COLLATE NOCASE LIMIT ?", params + [name, limit]
            ).fetchall()
            if rows:
                results.extend(rows)
            else:
                # Prefix
                rows = conn.execute(
                    f"SELECT * FROM api_records WHERE {where} AND member_name LIKE ? LIMIT ?", params + [f"{name}%", limit]
                ).fetchall()
                if rows:
                    results.extend(rows)
                else:
                    # Contains
                    rows = conn.execute(
                        f"SELECT * FROM api_records WHERE {where} AND member_name LIKE ? LIMIT ?", params + [f"%{name}%", limit]
                    ).fetchall()
                    results.extend(rows)
        return [_compact_member(r) for r in results[:limit]]

    rows = conn.execute(
        f"SELECT * FROM api_records WHERE {where} LIMIT ?", params + [limit]
    ).fetchall()
    return [_compact_member(r) for r in rows]


def _compact_member(row: sqlite3.Row) -> dict:
    payload = json.loads(row["payload_json"])
    result = {
        "record": row["record_type"],
        "name": row["member_name"],
        "signature": row["signature"],
        "visibility": row["visibility"],
    }
    if row["record_type"] == "method":
        result["returnType"] = payload.get("returnType")
        result["parameters"] = payload.get("parameters", [])
        result["static"] = payload.get("static", False)
        result["virtual"] = payload.get("virtual", False)
        result["abstract"] = payload.get("abstract", False)
        result["constructor"] = payload.get("constructor", False)
    elif row["record_type"] == "field":
        result["fieldType"] = payload.get("fieldType")
        result["static"] = payload.get("static", False)
        result["literal"] = payload.get("literal", False)
    elif row["record_type"] == "property":
        result["propertyType"] = payload.get("propertyType")
        result["parameters"] = payload.get("parameters", [])
    elif row["record_type"] == "enum_value":
        result["value"] = payload.get("value")
    return result


def get_method_signatures(
    type_name: str,
    method_name: str,
    assembly: str | None = None,
    limit: int = 100,
    db_path: str | Path | None = None,
    acad_version: str = DEFAULT_ACAD_VERSION,
) -> dict:
    members = get_members(type_name, kind="method", name=method_name, assembly=assembly, limit=limit, db_path=db_path, acad_version=acad_version)
    return {
        "status": "ready" if members else "not_found",
        "type": type_name,
        "method": method_name,
        "overloads": members,
    }


# ─── Symbol resolution ────────────────────────────────────────────────

def resolve_type_token(
    token: str,
    db_path: str | Path | None = None,
    acad_version: str = DEFAULT_ACAD_VERSION,
) -> dict | None:
    """Walk up namespace hierarchy to find a type."""
    conn = open_database(db_path)
    parts = token.split(".")
    for i in range(len(parts), 0, -1):
        candidate = ".".join(parts[:i])
        row = conn.execute(
            "SELECT payload_json FROM api_records WHERE acad_version=? AND record_type='type' AND full_name=?",
            (acad_version, candidate),
        ).fetchone()
        if row:
            return json.loads(row["payload_json"])
    return None


def infer_required_assemblies(code: str) -> list[str]:
    """Infer which AutoCAD DLLs are needed based on code content."""
    code_lower = code.lower()
    required = []
    # Check for namespace/keyword patterns
    checks = [
        ("Autodesk.AutoCAD.DatabaseServices", "acdbmgd.dll"),
        ("Autodesk.AutoCAD.ApplicationServices", "acmgd.dll"),
        ("Autodesk.AutoCAD.EditorInput", "AcCoreMgd.dll"),
        ("Autodesk.AutoCAD.Geometry", "acdbmgd.dll"),
        ("Autodesk.AutoCAD.Windows", "AcWindows.dll"),
        ("Autodesk.AutoCAD.Interop", "Autodesk.AutoCAD.Interop.dll"),
        ("Autodesk.AutoCAD.Colors", "acdbmgd.dll"),
        ("AcDb", "acdbmgd.dll"),
        ("AcMg", "acmgd.dll"),
        ("AcCore", "AcCoreMgd.dll"),
    ]
    for pattern, dll in checks:
        if pattern.lower() in code_lower and dll not in required:
            required.append(dll)
    return required
