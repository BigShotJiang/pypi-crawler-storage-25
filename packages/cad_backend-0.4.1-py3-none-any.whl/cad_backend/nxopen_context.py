#!/usr/bin/env python3
"""
NXOpen project context detection.

Finds .sln/.csproj files, detects NXOpen DLL references, and
determines the active project context.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any
from xml.etree import ElementTree

from .autocad_context import (
    SKIP_DIRS,
    _collect_assemblies,
    _find_files,
    default_project_root,
    _parse_sln,
)


NX_DLL_NAMES = [
    "nxopen.dll",
    "nxopen.uf.dll",
    "nxopenui.dll",
    "nxopen.utilities.dll",
]

NX_OPTIONAL_ASSEMBLIES = [
    "NXOpen.UF.dll",
    "NXOpenUI.dll",
    "NXOpen.Utilities.dll",
]


def resolve_nx_project_context(project_root: str | Path | None = None) -> dict:
    root = default_project_root(str(project_root) if project_root else None)
    if not root or not root.exists():
        return {"status": "not_found", "error": "No project root specified or found."}

    # 1. Check for nxopen.json config
    config_path = root / "nxopen.json"
    if config_path.exists():
        return _from_config(root, config_path)

    # 2. Find .sln files
    sln_files = _find_files(root, "*.sln")
    if len(sln_files) == 1:
        return _from_solution(root, sln_files[0])
    if len(sln_files) > 1:
        return {
            "status": "ambiguous",
            "projectRoot": str(root),
            "solutions": [str(f) for f in sln_files],
            "message": "Multiple .sln files found. Specify project root or create nxopen.json.",
        }

    # 3. Find .csproj files
    csproj_files = _find_files(root, "*.csproj")
    if len(csproj_files) == 1:
        return _from_csproj(root, csproj_files[0])
    if len(csproj_files) > 1:
        return {
            "status": "collection",
            "projectRoot": str(root),
            "projects": [_analyze_nx_csproj(f) for f in csproj_files],
        }

    # 4. Recursive search for NXOpen.dll
    dll = _find_nx_dll(root)
    if dll:
        return _from_dll(root, dll)

    return {"status": "not_found", "projectRoot": str(root), "error": "No NXOpen project or DLL references found."}


def list_nx_projects(project_root: str | Path | None = None) -> dict:
    root = default_project_root(str(project_root) if project_root else None)
    if not root or not root.exists():
        return {"status": "not_found", "error": "No project root specified or found."}

    csproj_files = _find_files(root, "*.csproj")
    projects = [_analyze_nx_csproj(f) for f in csproj_files]
    return {
        "status": "ready",
        "projectRoot": str(root),
        "projectCount": len(projects),
        "projects": projects,
    }


def _find_nx_dll(root: Path) -> Path | None:
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for f in filenames:
            if f.lower() == "nxopen.dll":
                return Path(dirpath) / f
    return None


def _from_config(root: Path, config_path: Path) -> dict:
    try:
        import json
        config = json.loads(config_path.read_text(encoding="utf-8"))
        assembly_dir = config.get("nxOpen", {}).get("assemblyDir")
        if assembly_dir:
            asm_dir = (root / assembly_dir).resolve()
            assemblies = _scan_nx_assembly_dir(asm_dir)
            nx_version = _detect_nx_version(asm_dir)
            return {
                "status": "ready",
                "projectRoot": str(root),
                "configFile": str(config_path),
                "assemblyDir": str(asm_dir),
                "nxVersion": nx_version,
                "assemblies": assemblies,
            }
    except Exception as e:
        return {"status": "error", "projectRoot": str(root), "error": str(e)}
    return {"status": "error", "projectRoot": str(root), "error": "Invalid nxopen.json"}


def _from_solution(root: Path, sln_path: Path) -> dict:
    csproj_paths = _parse_sln(sln_path)
    project_details = []
    for csproj in csproj_paths:
        resolved = (sln_path.parent / csproj).resolve()
        if resolved.exists():
            project_details.append(_analyze_nx_csproj(resolved))

    assemblies = _collect_nx_assemblies(project_details)
    nx_version = _infer_nx_version(assemblies)
    return {
        "status": "ready",
        "projectRoot": str(root),
        "solution": str(sln_path),
        "nxVersion": nx_version,
        "projectCount": len(project_details),
        "projectDetails": project_details,
        "assemblies": assemblies,
    }


def _from_csproj(root: Path, csproj_path: Path) -> dict:
    info = _analyze_nx_csproj(csproj_path)
    assemblies = _collect_nx_assemblies([info])
    nx_version = _infer_nx_version(assemblies)
    return {
        "status": "ready",
        "projectRoot": str(root),
        "nxVersion": nx_version,
        "projectDetails": [info],
        "assemblies": assemblies,
    }


def _from_dll(root: Path, dll_path: Path) -> dict:
    assembly_dir = dll_path.parent
    assemblies = _scan_nx_assembly_dir(assembly_dir)
    nx_version = _detect_nx_version(assembly_dir)
    return {
        "status": "ready",
        "projectRoot": str(root),
        "assemblyDir": str(assembly_dir),
        "nxVersion": nx_version,
        "assemblies": assemblies,
    }


def _analyze_nx_csproj(csproj_path: Path) -> dict:
    info: dict[str, Any] = {
        "path": str(csproj_path),
        "name": csproj_path.stem,
        "nxReferences": [],
        "hintPaths": [],
    }
    try:
        content = csproj_path.read_text(encoding="utf-8-sig", errors="replace")
        ref_pattern = r'<Reference\s+Include="([^"]*)"[^>]*>(.*?)</Reference>'
        for match in re.finditer(ref_pattern, content, re.DOTALL | re.IGNORECASE):
            include = match.group(1)
            body = match.group(2)
            hint_match = re.search(r'<HintPath>([^<]*)</HintPath>', body, re.IGNORECASE)
            if hint_match:
                hint_path = hint_match.group(1).strip()
                include_lower = include.lower()
                hint_lower = hint_path.lower()
                is_nx = any(dll.replace(".dll", "") in include_lower or dll in hint_lower for dll in NX_DLL_NAMES)
                if is_nx or "nxopen" in include_lower:
                    info["nxReferences"].append(include)
                    resolved = (csproj_path.parent / hint_path).resolve()
                    info["hintPaths"].append(str(resolved))
    except Exception as e:
        info["error"] = str(e)
    return info


def _scan_nx_assembly_dir(directory: Path) -> list[str]:
    found = []
    if directory.exists():
        for f in directory.iterdir():
            if f.is_file() and f.suffix.lower() == ".dll" and f.name.lower() in NX_DLL_NAMES:
                found.append(f.name)
    return sorted(found)


def _collect_nx_assemblies(project_details: list[dict]) -> list[str]:
    all_assemblies: set[str] = set()
    for detail in project_details:
        for hint in detail.get("hintPaths", []):
            p = Path(hint)
            if p.exists() and p.suffix.lower() == ".dll":
                all_assemblies.add(p.name)
    return sorted(all_assemblies)


def _detect_nx_version(assembly_dir: Path) -> str | None:
    """Try to detect NX version from DLL file version info."""
    try:
        import ctypes
        from ctypes import wintypes
        nxopen_path = assembly_dir / "NXOpen.dll"
        if not nxopen_path.exists():
            return None
        # Get file version info size
        path_str = str(nxopen_path)
        size = ctypes.windll.version.GetFileVersionInfoSizeW(path_str, None)
        if not size:
            return None
        buf = ctypes.create_string_buffer(size)
        if not ctypes.windll.version.GetFileVersionInfoW(path_str, 0, size, buf):
            return None
        # Query ProductVersion
        p_len = wintypes.UINT()
        p_data = ctypes.c_void_p()
        if ctypes.windll.version.VerQueryValueW(buf, "\\StringFileInfo\\040904b0\\ProductVersion", ctypes.byref(p_data), ctypes.byref(p_len)):
            version = ctypes.wstring_at(p_data.value, p_len.value - 1)
            if "2312" in version:
                return "NX2312"
            if "12" in version:
                return "NX12"
            return version
    except Exception:
        pass
    return None


def _infer_nx_version(assemblies: list[str]) -> str | None:
    """Infer NX version from assembly paths (heuristic)."""
    for asm in assemblies:
        asm_lower = asm.lower()
        if "2312" in asm_lower:
            return "NX2312"
        if "nx12" in asm_lower or "nx_open_12" in asm_lower:
            return "NX12"
    return None
