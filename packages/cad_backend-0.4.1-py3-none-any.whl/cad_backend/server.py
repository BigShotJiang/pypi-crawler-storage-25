#!/usr/bin/env python3
"""
Unified Backend HTTP Server (FastAPI + uvicorn).

Loads ALL configured databases at startup. Requests specify version.
No version switching needed — all versions available simultaneously.

Usage:
    cad-backend [--port 9222] [--init] [--list]
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .autocad_store import (
    get_members as acad_get_members,
    get_method_signatures as acad_get_method_sigs,
    get_type as acad_get_type,
    hybrid_search_api as acad_hybrid_search,
    index_status as acad_index_status,
    resolve_type_token as acad_resolve_token,
)
from .autocad_context import (
    list_projects as acad_list_projects,
    resolve_project_context as acad_resolve_context,
)
from .nxopen_store import (
    DEFAULT_NX_VERSION,
    nx_get_members,
    nx_get_method_signatures,
    nx_get_type,
    nx_hybrid_search_api,
    nx_index_status,
    nx_resolve_type_token,
)
from .nxopen_context import (
    list_nx_projects,
    resolve_nx_project_context,
)

# ─── Thread pool ──────────────────────────────────────────────────────

executor = ThreadPoolExecutor(max_workers=8, thread_name_prefix="sqlite")


async def run_sync(func, *args, **kwargs) -> Any:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(executor, lambda: func(*args, **kwargs))


# ─── App ──────────────────────────────────────────────────────────────

app = FastAPI(title="AutoCAD + NX Backend", version="0.4.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


# ─── Database registry ────────────────────────────────────────────────
# Loaded at startup from config. All versions available simultaneously.

db_registry: dict[str, dict[str, str]] = {
    "acad": {},   # { "2018": "/path/to/autocad_2018.sqlite", ... }
    "nx": {},     # { "NX12": "/path/to/nx12.sqlite", "NX2312": "/path/to/nx2312.sqlite" }
}


def _get_acad_db(version: str) -> str:
    """Get AutoCAD db path by version. Raises 404 if not found."""
    db = db_registry["acad"].get(version)
    if not db:
        available = list(db_registry["acad"].keys())
        raise HTTPException(400, f"AutoCAD version '{version}' not configured. Available: {available}")
    return db


def _get_nx_db(version: str) -> str:
    """Get NX db path by version. Raises 404 if not found."""
    db = db_registry["nx"].get(version)
    if not db:
        available = list(db_registry["nx"].keys())
        raise HTTPException(400, f"NX version '{version}' not configured. Available: {available}")
    return db


# ─── Request models ────────────────────────────────────────────────────

class AcadSearchRequest(BaseModel):
    query: str
    version: str = "2018"
    limit: int = Field(default=20, ge=1, le=200)
    assembly: str | None = None
    domain: str | None = None
    kind: str | None = None
    typeName: str | None = None


class AcadTypeRequest(BaseModel):
    typeName: str
    version: str = "2018"
    assembly: str | None = None


class AcadMembersRequest(BaseModel):
    typeName: str
    version: str = "2018"
    kind: str | None = None
    name: str | None = None
    assembly: str | None = None
    limit: int = Field(default=50, ge=1, le=500)


class AcadMethodSigsRequest(BaseModel):
    typeName: str
    methodName: str
    version: str = "2018"
    assembly: str | None = None
    limit: int = Field(default=100, ge=1, le=500)


class AcadTokenRequest(BaseModel):
    token: str
    version: str = "2018"


class NxSearchRequest(BaseModel):
    query: str
    version: str = DEFAULT_NX_VERSION
    limit: int = Field(default=20, ge=1, le=200)
    assembly: str | None = None
    domain: str | None = None
    kind: str | None = None
    typeName: str | None = None


class NxTypeRequest(BaseModel):
    typeName: str
    version: str = DEFAULT_NX_VERSION
    assembly: str | None = None


class NxMembersRequest(BaseModel):
    typeName: str
    version: str = DEFAULT_NX_VERSION
    kind: str | None = None
    name: str | None = None
    assembly: str | None = None
    limit: int = Field(default=50, ge=1, le=500)


class NxMethodSigsRequest(BaseModel):
    typeName: str
    methodName: str
    version: str = DEFAULT_NX_VERSION
    assembly: str | None = None
    limit: int = Field(default=100, ge=1, le=500)


class NxTokenRequest(BaseModel):
    token: str
    version: str = DEFAULT_NX_VERSION


class ContextRequest(BaseModel):
    projectRoot: str | None = None


# ─── Health ────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok"}


@app.get("/status")
async def status():
    """Return all loaded database versions."""
    result = {"acad": {}, "nx": {}}
    for ver, db_path in db_registry["acad"].items():
        try:
            s = await run_sync(acad_index_status, db_path)
            result["acad"][ver] = {"status": s.get("status"), "totals": s.get("totals")}
        except Exception as e:
            result["acad"][ver] = {"status": "error", "error": str(e)}
    for ver, db_path in db_registry["nx"].items():
        try:
            s = await run_sync(nx_index_status, db_path, ver)
            result["nx"][ver] = {"status": s.get("status"), "totals": s.get("totals")}
        except Exception as e:
            result["nx"][ver] = {"status": "error", "error": str(e)}
    return result


# ─── AutoCAD endpoints ────────────────────────────────────────────────

@app.get("/autocad/status")
async def acad_status(version: str = "2018"):
    return await run_sync(acad_index_status, _get_acad_db(version))


@app.post("/autocad/search")
async def acad_search(req: AcadSearchRequest):
    return await run_sync(
        acad_hybrid_search,
        query=req.query, limit=req.limit,
        assembly=req.assembly, domain=req.domain,
        kind=req.kind, type_name=req.typeName,
        db_path=_get_acad_db(req.version),
    )


@app.post("/autocad/type")
async def acad_type(req: AcadTypeRequest):
    result = await run_sync(acad_get_type, req.typeName, assembly=req.assembly, db_path=_get_acad_db(req.version))
    return result or {"status": "not_found", "typeName": req.typeName}


@app.post("/autocad/members")
async def acad_members(req: AcadMembersRequest):
    return await run_sync(
        acad_get_members,
        type_name=req.typeName, kind=req.kind,
        name=req.name, assembly=req.assembly,
        limit=req.limit, db_path=_get_acad_db(req.version),
    )


@app.post("/autocad/method_sigs")
async def acad_method_sigs(req: AcadMethodSigsRequest):
    return await run_sync(
        acad_get_method_sigs,
        type_name=req.typeName, method_name=req.methodName,
        assembly=req.assembly, limit=req.limit,
        db_path=_get_acad_db(req.version),
    )


@app.post("/autocad/resolve_token")
async def acad_resolve(req: AcadTokenRequest):
    result = await run_sync(acad_resolve_token, req.token, db_path=_get_acad_db(req.version))
    return result or {"status": "not_found"}


@app.post("/autocad/context")
async def acad_context(req: ContextRequest):
    return await run_sync(acad_resolve_context, req.projectRoot)


@app.post("/autocad/list_projects")
async def acad_list(req: ContextRequest):
    return await run_sync(acad_list_projects, req.projectRoot)


# ─── NX endpoints ─────────────────────────────────────────────────────

@app.get("/nx/status")
async def nx_status(version: str = DEFAULT_NX_VERSION):
    return await run_sync(nx_index_status, _get_nx_db(version), version)


@app.post("/nx/search")
async def nx_search(req: NxSearchRequest):
    return await run_sync(
        nx_hybrid_search_api,
        query=req.query, limit=req.limit,
        assembly=req.assembly, domain=req.domain,
        kind=req.kind, type_name=req.typeName,
        db_path=_get_nx_db(req.version), nx_version=req.version,
    )


@app.post("/nx/type")
async def nx_type(req: NxTypeRequest):
    result = await run_sync(
        nx_get_type, req.typeName,
        assembly=req.assembly, db_path=_get_nx_db(req.version), nx_version=req.version,
    )
    return result or {"status": "not_found", "typeName": req.typeName}


@app.post("/nx/members")
async def nx_members(req: NxMembersRequest):
    return await run_sync(
        nx_get_members,
        type_name=req.typeName, kind=req.kind,
        name=req.name, assembly=req.assembly,
        limit=req.limit, db_path=_get_nx_db(req.version), nx_version=req.version,
    )


@app.post("/nx/method_sigs")
async def nx_method_sigs(req: NxMethodSigsRequest):
    return await run_sync(
        nx_get_method_signatures,
        type_name=req.typeName, method_name=req.methodName,
        assembly=req.assembly, limit=req.limit,
        db_path=_get_nx_db(req.version), nx_version=req.version,
    )


@app.post("/nx/resolve_token")
async def nx_resolve(req: NxTokenRequest):
    result = await run_sync(
        nx_resolve_type_token, req.token,
        db_path=_get_nx_db(req.version), nx_version=req.version,
    )
    return result or {"status": "not_found"}


@app.post("/nx/context")
async def nx_context(req: ContextRequest):
    return await run_sync(resolve_nx_project_context, req.projectRoot)


@app.post("/nx/list_projects")
async def nx_list(req: ContextRequest):
    return await run_sync(list_nx_projects, req.projectRoot)


# ─── Config ───────────────────────────────────────────────────────────

CONFIG_DIR_NAME = ".cad-backend"
CONFIG_FILE_NAME = "config.json"

DEFAULT_CONFIG = {
    "acad": {
        "2018": None,
    },
    "nx": {
        "NX12": None,
        "NX2312": None,
    },
    "default_acad_version": "2018",
    "default_nx_version": "NX2312",
    "port": 9222,
    "host": "0.0.0.0",
    "workers": 1,
}


def _config_dir() -> Path:
    return Path.home() / CONFIG_DIR_NAME


def _config_path() -> Path:
    return _config_dir() / CONFIG_FILE_NAME


def _load_config_file() -> dict:
    path = _config_path()
    if not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception as e:
        print(f"WARNING: Failed to read {path}: {e}", file=sys.stderr)
        return {}


def _save_default_config():
    path = _config_path()
    if path.exists():
        return
    try:
        _config_dir().mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2, ensure_ascii=False)
        print(f"Default config created: {path}", file=sys.stderr)
    except Exception as e:
        print(f"WARNING: Could not create config: {e}", file=sys.stderr)


def _resolve_path(p: str | None) -> str | None:
    if not p:
        return None
    path = Path(p)
    return str(path.resolve()) if path.exists() else None


def _load_all_databases(file_cfg: dict):
    """Load ALL database paths from config into registry."""
    for ver, path in file_cfg.get("acad", {}).items():
        resolved = _resolve_path(path)
        if resolved:
            db_registry["acad"][ver] = resolved
    for ver, path in file_cfg.get("nx", {}).items():
        resolved = _resolve_path(path)
        if resolved:
            db_registry["nx"][ver] = resolved


# ─── Main ─────────────────────────────────────────────────────────────

def main():
    file_cfg = _load_config_file()
    if not file_cfg:
        _save_default_config()
        file_cfg = {}

    parser = argparse.ArgumentParser(description="Unified AutoCAD + NX Backend Server")
    parser.add_argument("--port", type=int, default=None)
    parser.add_argument("--host", default=None)
    parser.add_argument("--workers", type=int, default=None)
    parser.add_argument("--init", action="store_true", help="Generate default config.json and exit")
    parser.add_argument("--list", action="store_true", help="List configured versions and exit")
    args = parser.parse_args()

    if args.init:
        _save_default_config()
        print(f"Config file: {_config_path()}", file=sys.stderr)
        return

    # Load ALL databases
    _load_all_databases(file_cfg)

    if args.list:
        result = {"acad": {}, "nx": {}}
        for ver, path in db_registry["acad"].items():
            result["acad"][ver] = path
        for ver, path in db_registry["nx"].items():
            result["nx"][ver] = path
        # Show configured but not found
        for ver, path in file_cfg.get("acad", {}).items():
            if ver not in result["acad"]:
                result["acad"][ver] = f"NOT FOUND: {path}"
        for ver, path in file_cfg.get("nx", {}).items():
            if ver not in result["nx"]:
                result["nx"][ver] = f"NOT FOUND: {path}"
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return

    if not db_registry["acad"] and not db_registry["nx"]:
        print("", file=sys.stderr)
        print("ERROR: No database files found.", file=sys.stderr)
        print(f"Edit config: {_config_path()}", file=sys.stderr)
        print("", file=sys.stderr)
        print("Config format:", file=sys.stderr)
        print('  "acad": { "2018": "/path/to/autocad_api.sqlite" }', file=sys.stderr)
        print('  "nx": { "NX2312": "/path/to/nxopen_nx2312_api.sqlite" }', file=sys.stderr)
        print("", file=sys.stderr)
        print("Generate default config: cad-backend --init", file=sys.stderr)
        sys.exit(1)

    port = args.port or file_cfg.get("port") or DEFAULT_CONFIG["port"]
    host = args.host or file_cfg.get("host") or DEFAULT_CONFIG["host"]
    workers = args.workers or file_cfg.get("workers") or DEFAULT_CONFIG["workers"]

    print(f"Config: {_config_path()}", file=sys.stderr)
    print(f"Backend: http://{host}:{port}", file=sys.stderr)
    print(f"  AutoCAD versions: {list(db_registry['acad'].keys())}", file=sys.stderr)
    print(f"  NX versions: {list(db_registry['nx'].keys())}", file=sys.stderr)

    if workers > 1:
        uvicorn.run("cad_backend.server:app", host=host, port=port, workers=workers, log_level="warning")
    else:
        uvicorn.run(app, host=host, port=port, workers=1, log_level="warning")


if __name__ == "__main__":
    main()
