#!/usr/bin/env python3
"""
NXOpen SQLite API store — Python port of the Node.js nxopen-sqlite-store.

Provides lexical search, hybrid search, type/member lookup against
the NXOpen SQLite API databases (NX12, NX2312).
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

from .autocad_store import (
    CANONICAL_TERMS as ACAD_CANONICAL,
    SKIP_WORDS as ACAD_SKIP,
    _compact_member,
    _extract_identifiers,
    _score_search_row as _acad_score,
)

# ─── NX-specific configuration ────────────────────────────────────────

DEFAULT_NX_VERSION = "NX2312"

NX_DB_PATHS: dict[str, Path] = {
    "NX12": Path(r"F:\Company\NXmcp\nxopen_nx12_api.sqlite"),
    "NX2312": Path(r"F:\Company\NXmcp\nxopen_nx2312_api.sqlite"),
}

NX_DOMAIN_HINTS: dict[str, dict[str, Any]] = {
    "cam": {
        "assembly": "NXOpen.dll",
        "keywords": ["cam", "machining", "operation", "toolpath", "加工", "刀路", "工序"],
        "semantic": ["NXOpen.CAM", "Operation", "CAMSetup", "NCGroup"],
    },
    "ui": {
        "assembly": "NXOpenUI.dll",
        "keywords": ["ui", "select", "selection", "dialog", "选择", "拾取", "界面"],
        "semantic": ["Selection", "SelectTaggedObject", "MaskTriple"],
    },
    "uf": {
        "assembly": "NXOpen.UF.dll",
        "keywords": ["uf", "ufsession", "ufmodl", "tag", "bounding box", "bbox", "边界框", "包围盒"],
        "semantic": ["UFSession", "UFModl"],
    },
    "body": {
        "assembly": "NXOpen.dll",
        "keywords": ["body", "bodies", "solid", "实体", "体"],
        "semantic": ["Body"],
    },
    "face": {
        "assembly": "NXOpen.dll",
        "keywords": ["face", "faces", "surface", "面", "曲面"],
        "semantic": ["Face"],
    },
    "edge": {
        "assembly": "NXOpen.dll",
        "keywords": ["edge", "edges", "curve", "line", "边", "线"],
        "semantic": ["Edge"],
    },
    "feature": {
        "assembly": "NXOpen.dll",
        "keywords": ["feature", "builder", "create", "block", "box", "cube", "特征", "创建", "长方体"],
        "semantic": [],
    },
    "session": {
        "assembly": "NXOpen.dll",
        "keywords": ["session", "part", "work part", "display part", "会话", "部件"],
        "semantic": ["Session", "GetSession", "Part"],
    },
}

NX_CANONICAL_TERMS: dict[str, str] = {
    "askboundingbox": "AskBoundingBox",
    "askboundingboxaligned": "AskBoundingBoxAligned",
    "askboundingboxexact": "AskBoundingBoxExact",
    "body": "Body",
    "bodies": "Body",
    "edge": "Edge",
    "edges": "Edge",
    "face": "Face",
    "faces": "Face",
    "getedges": "GetEdges",
    "getfaces": "GetFaces",
    "highlight": "Highlight",
    "masktriple": "MaskTriple",
    "selection": "Selection",
    "selecttaggedobject": "SelectTaggedObject",
    "ufmodl": "UFModl",
    "ufsession": "UFSession",
    "session": "Session",
    "part": "Part",
    "feature": "Feature",
    "bodycollector": "BodyCollector",
    "nxobject": "NXObject",
    "tag": "Tag",
    "taggedobject": "TaggedObject",
    "point3d": "Point3d",
    "vector3d": "Vector3d",
    "matrix3x3": "Matrix3x3",
    "axis": "Axis",
    "plane": "Plane",
    "coordinatesystem": "CoordinateSystem",
    "expression": "Expression",
    "sketch": "Sketch",
    "featurebuilder": "FeatureBuilder",
    "blockfeaturebuilder": "BlockFeatureBuilder",
    "extrudebuilder": "ExtrudeBuilder",
    "revolvebuilder": "RevolveBuilder",
    "holefeaturebuilder": "HolePackageBuilder",
    "booleanbuilder": "BooleanBuilder",
    "edgebuilder": "EdgeBuilder",
    "facebuilder": "FaceBuilder",
    "cambuilder": "CAMBuilder",
    "operation": "Operation",
    "ncgroup": "NCGroup",
    "toolpath": "ToolPath",
    "ufsession": "UFSession",
    "ufmodl": "UFModl",
    "ufobj": "UFObj",
}

NX_SKIP_WORDS = ACAD_SKIP | {
    "nxopen", "api", "cs", "c", "value", "values", "max", "min", "maximum", "minimum",
    "using", "from", "into", "exact", "find",
}

# ─── Database access ──────────────────────────────────────────────────

_nx_conn_cache: dict[str, Any] = {}


def nx_open_database(db_path: str | Path | None = None, nx_version: str = DEFAULT_NX_VERSION) -> Any:
    if db_path:
        path = str(db_path)
    else:
        path = str(NX_DB_PATHS.get(nx_version, NX_DB_PATHS[DEFAULT_NX_VERSION]))
    if path in _nx_conn_cache:
        return _nx_conn_cache[path]
    if not os.path.exists(path):
        raise FileNotFoundError(f"NX SQLite database not found: {path}")
    import sqlite3
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA query_only=ON")
    _nx_conn_cache[path] = conn
    return conn


def nx_index_status(db_path: str | Path | None = None, nx_version: str = DEFAULT_NX_VERSION) -> dict:
    conn = nx_open_database(db_path, nx_version)
    rows = conn.execute(
        "SELECT assembly, record_type, COUNT(*) as cnt FROM api_records WHERE nx_version=? GROUP BY assembly, record_type",
        (nx_version,),
    ).fetchall()
    if not rows:
        return {"status": "empty", "db": str(db_path or NX_DB_PATHS.get(nx_version)), "nxVersion": nx_version}
    by_assembly: dict[str, dict[str, int]] = {}
    totals: dict[str, int] = {}
    for row in rows:
        asm = row["assembly"]
        rt = row["record_type"]
        cnt = row["cnt"]
        by_assembly.setdefault(asm, {})[rt] = cnt
        totals[rt] = totals.get(rt, 0) + cnt
    return {
        "status": "ready",
        "db": str(db_path or NX_DB_PATHS.get(nx_version)),
        "nxVersion": nx_version,
        "totals": totals,
        "byAssembly": by_assembly,
    }


# ─── Search terms ─────────────────────────────────────────────────────

def _nx_build_search_terms(query: str) -> list[str]:
    """Build canonical search terms from a query string."""
    identifiers = _extract_identifiers(query)
    terms = []
    seen: set[str] = set()
    for ident in identifiers:
        lower = ident.lower()
        canonical = NX_CANONICAL_TERMS.get(lower) or ACAD_CANONICAL.get(lower)
        if canonical and canonical.lower() not in seen:
            terms.append(canonical)
            seen.add(canonical.lower())
        elif lower not in seen and lower not in NX_SKIP_WORDS:
            terms.append(ident)
            seen.add(lower)
    return terms[:14]


def _nx_infer_intent(query: str) -> dict[str, Any]:
    query_lower = query.lower()
    domains: set[str] = set()
    assemblies: set[str] = set()
    for domain, cfg in NX_DOMAIN_HINTS.items():
        for kw in cfg["keywords"]:
            if kw in query_lower:
                domains.add(domain)
                assemblies.add(cfg["assembly"])
                break
    return {"domains": list(domains), "assemblies": list(assemblies)}


# ─── Lexical search ───────────────────────────────────────────────────

def nx_search_api(
    query: str,
    limit: int = 20,
    assembly: str | None = None,
    kind: str | None = None,
    db_path: str | Path | None = None,
    nx_version: str = DEFAULT_NX_VERSION,
) -> list[dict]:
    """Multi-stage cascading lexical search for NX."""
    import sqlite3
    conn = nx_open_database(db_path, nx_version)
    terms = _nx_build_search_terms(query)
    results: dict[str, dict] = {}

    def _add_rows(rows: list, bonus: int):
        for row in rows:
            key = f"{row['record_type']}|{row['assembly']}|{row['full_name']}|{row['member_name']}"
            if key not in results:
                payload = json.loads(row["payload_json"])
                score = _acad_score(row, query, terms) + bonus
                results[key] = {"score": score, "payload": payload, "assembly": row["assembly"], "record_type": row["record_type"]}

    version_clause = "nx_version=?"
    version_params: list[Any] = [nx_version]
    asm_clause = ""
    asm_params: list[str] = []
    if assembly:
        asm_clause = " AND assembly=?"
        asm_params = [assembly]
    kind_clause = ""
    kind_params: list[str] = []
    if kind:
        kind_clause = " AND record_type=?"
        kind_params = [kind]

    base_where = version_clause + asm_clause + kind_clause
    base_params = version_params + asm_params + kind_params

    # Stage 1: Exact match
    if terms:
        placeholders = ",".join("?" * len(terms))
        for col in ("member_name", "full_name", "type_name"):
            rows = conn.execute(
                f"SELECT * FROM api_records WHERE {base_where} AND {col} IN ({placeholders}) LIMIT 500",
                base_params + terms,
            ).fetchall()
            _add_rows(rows, 160)

    # Stage 2: Case-insensitive exact
    if terms:
        for col in ("member_name", "full_name", "type_name"):
            for term in terms:
                rows = conn.execute(
                    f"SELECT * FROM api_records WHERE {base_where} AND {col}=? COLLATE NOCASE LIMIT 200",
                    base_params + [term],
                ).fetchall()
                _add_rows(rows, 130)

    # Stage 3: Prefix match
    for term in terms[:6]:
        pattern = f"{term}%"
        for col in ("member_name", "full_name", "type_name"):
            rows = conn.execute(
                f"SELECT * FROM api_records WHERE {base_where} AND {col} LIKE ? LIMIT 100",
                base_params + [pattern],
            ).fetchall()
            _add_rows(rows, 90)

    # Stage 4: Contains match
    for term in terms[:4]:
        pattern = f"%{term}%"
        for col in ("member_name", "full_name", "type_name"):
            rows = conn.execute(
                f"SELECT * FROM api_records WHERE {base_where} AND {col} LIKE ? LIMIT 50",
                base_params + [pattern],
            ).fetchall()
            _add_rows(rows, 35)

    # Stage 5: Signature match
    for term in terms[:3]:
        pattern = f"%{term}%"
        rows = conn.execute(
            f"SELECT * FROM api_records WHERE {base_where} AND signature LIKE ? LIMIT 30",
            base_params + [pattern],
        ).fetchall()
        _add_rows(rows, 5)

    sorted_results = sorted(results.values(), key=lambda x: x["score"], reverse=True)
    return sorted_results[:limit]


# ─── Hybrid search ────────────────────────────────────────────────────

def nx_hybrid_search_api(
    query: str,
    limit: int = 20,
    assembly: str | None = None,
    domain: str | None = None,
    kind: str | None = None,
    type_name: str | None = None,
    db_path: str | Path | None = None,
    nx_version: str = DEFAULT_NX_VERSION,
) -> dict:
    """Combined lexical + semantic search with reranking for NX."""
    intent = _nx_infer_intent(query)
    assemblies = [assembly] if assembly else intent["assemblies"]
    domains = [domain] if domain else intent["domains"]

    all_results: dict[str, dict] = {}

    # Phase 1: Lexical search
    search_assemblies = assemblies if assemblies else [None]
    for asm in search_assemblies:
        for r in nx_search_api(query, limit=limit * 2, assembly=asm, kind=kind, db_path=db_path, nx_version=nx_version):
            key = f"{r['record_type']}|{r['assembly']}|{r['payload'].get('fullName', '')}|{r['payload'].get('name', '')}"
            if key not in all_results:
                r["lexical"] = True
                all_results[key] = r

    # Phase 2: Semantic alias search
    semantic_terms: list[str] = []
    for d in domains:
        cfg = NX_DOMAIN_HINTS.get(d, {})
        semantic_terms.extend(cfg.get("semantic", []))

    if semantic_terms:
        for term in semantic_terms[:5]:
            for r in nx_search_api(term, limit=10, kind=kind, db_path=db_path, nx_version=nx_version):
                key = f"{r['record_type']}|{r['assembly']}|{r['payload'].get('fullName', '')}|{r['payload'].get('name', '')}"
                if key in all_results:
                    all_results[key]["semantic"] = True
                    all_results[key]["score"] += 250
                else:
                    r["semantic"] = True
                    r["score"] += 250
                    all_results[key] = r

    # Phase 3: Reranking
    for key, r in all_results.items():
        payload = r["payload"]
        name = payload.get("name", "")
        full_name = payload.get("fullName", payload.get("type", ""))
        record_type = r["record_type"]

        if r.get("lexical"):
            r["score"] += 1000
        elif not r.get("semantic"):
            r["score"] -= 450

        if r.get("lexical") and r.get("semantic"):
            r["score"] += 360

        if record_type == "method":
            r["score"] += 90
        elif record_type == "type":
            r["score"] += 40

        query_lower = query.lower()
        if name and name.lower() in query_lower:
            r["score"] += 260
        if full_name and full_name.lower() in query_lower:
            r["score"] += 200

        asm = r["assembly"]
        for d in domains:
            cfg = NX_DOMAIN_HINTS.get(d, {})
            if cfg.get("assembly") == asm:
                r["score"] += 260

    sorted_results = sorted(all_results.values(), key=lambda x: x["score"], reverse=True)

    if type_name:
        sorted_results = [r for r in sorted_results if r["payload"].get("type", "") == type_name or r["payload"].get("fullName", "") == type_name]

    return {
        "query": query,
        "inferred": {"domains": domains, "assemblies": assemblies, "semanticTerms": semantic_terms, "strategy": "lexical+semantic_alias"},
        "results": sorted_results[:limit],
    }


# ─── Type / Member lookup ─────────────────────────────────────────────

def nx_get_type(
    type_name: str,
    assembly: str | None = None,
    db_path: str | Path | None = None,
    nx_version: str = DEFAULT_NX_VERSION,
) -> dict | None:
    conn = nx_open_database(db_path, nx_version)
    params: list[Any] = [nx_version, type_name]
    asm_clause = ""
    if assembly:
        asm_clause = " AND assembly=?"
        params.append(assembly)
    row = conn.execute(
        f"SELECT payload_json, assembly FROM api_records WHERE nx_version=? AND record_type='type' AND full_name=?{asm_clause}",
        params,
    ).fetchone()
    if not row:
        return None
    payload = json.loads(row["payload_json"])
    return {"status": "ready", "type": payload, "assembly": row["assembly"]}


def nx_get_members(
    type_name: str,
    kind: str | None = None,
    name: str | None = None,
    assembly: str | None = None,
    limit: int = 50,
    db_path: str | Path | None = None,
    nx_version: str = DEFAULT_NX_VERSION,
) -> list[dict]:
    conn = nx_open_database(db_path, nx_version)
    where = "nx_version=? AND type_name=?"
    params: list[Any] = [nx_version, type_name]
    if kind:
        where += " AND record_type=?"
        params.append(kind)
    if assembly:
        where += " AND assembly=?"
        params.append(assembly)
    if name:
        results = []
        rows = conn.execute(f"SELECT * FROM api_records WHERE {where} AND member_name=? LIMIT ?", params + [name, limit]).fetchall()
        if rows:
            results.extend(rows)
        else:
            rows = conn.execute(f"SELECT * FROM api_records WHERE {where} AND member_name=? COLLATE NOCASE LIMIT ?", params + [name, limit]).fetchall()
            if rows:
                results.extend(rows)
            else:
                rows = conn.execute(f"SELECT * FROM api_records WHERE {where} AND member_name LIKE ? LIMIT ?", params + [f"{name}%", limit]).fetchall()
                if rows:
                    results.extend(rows)
                else:
                    rows = conn.execute(f"SELECT * FROM api_records WHERE {where} AND member_name LIKE ? LIMIT ?", params + [f"%{name}%", limit]).fetchall()
                    results.extend(rows)
        return [_compact_member(r) for r in results[:limit]]

    rows = conn.execute(f"SELECT * FROM api_records WHERE {where} LIMIT ?", params + [limit]).fetchall()
    return [_compact_member(r) for r in rows]


def nx_get_method_signatures(
    type_name: str,
    method_name: str,
    assembly: str | None = None,
    limit: int = 100,
    db_path: str | Path | None = None,
    nx_version: str = DEFAULT_NX_VERSION,
) -> dict:
    members = nx_get_members(type_name, kind="method", name=method_name, assembly=assembly, limit=limit, db_path=db_path, nx_version=nx_version)
    return {
        "status": "ready" if members else "not_found",
        "type": type_name,
        "method": method_name,
        "overloads": members,
    }


def nx_resolve_type_token(
    token: str,
    db_path: str | Path | None = None,
    nx_version: str = DEFAULT_NX_VERSION,
) -> dict | None:
    """Walk up namespace hierarchy to find a type."""
    conn = nx_open_database(db_path, nx_version)
    current = token
    while current.startswith("NXOpen."):
        row = conn.execute(
            "SELECT payload_json FROM api_records WHERE nx_version=? AND record_type='type' AND full_name=?",
            (nx_version, current),
        ).fetchone()
        if row:
            return json.loads(row["payload_json"])
        last_dot = current.rfind(".")
        if last_dot < 0:
            break
        current = current[:last_dot]
    return None


def nx_infer_required_assemblies(code: str) -> list[str]:
    code_lower = code.lower()
    required: list[str] = []
    checks = [
        ("NXOpen.CAM", "NXOpen.dll"),
        ("NXOpen.Body", "NXOpen.dll"),
        ("NXOpen.Face", "NXOpen.dll"),
        ("NXOpen.Edge", "NXOpen.dll"),
        ("NXOpen.Feature", "NXOpen.dll"),
        ("NXOpen.Session", "NXOpen.dll"),
        ("NXOpenUF", "NXOpen.UF.dll"),
        ("UFSession", "NXOpen.UF.dll"),
        ("UFModl", "NXOpen.UF.dll"),
        ("NXOpenUI", "NXOpenUI.dll"),
        ("BlockStyler", "NXOpenUI.dll"),
        ("NXOpen.Utilities", "NXOpen.Utilities.dll"),
    ]
    for pattern, dll in checks:
        if pattern.lower() in code_lower and dll not in required:
            required.append(dll)
    return required
