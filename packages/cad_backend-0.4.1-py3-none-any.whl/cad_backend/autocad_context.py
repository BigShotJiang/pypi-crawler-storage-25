#!/usr/bin/env python3
"""
AutoCAD project context detection.

Finds .sln/.csproj files, detects AutoCAD DLL references, and
determines the active project context for MCP tools.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any
from xml.etree import ElementTree


AUTOCAD_DLL_NAMES = [
    "acdbmgd.dll",
    "acmgd.dll",
    "accoremgd.dll",
    "accui.dll",
    "acwindows.dll",
    "aduimgd.dll",
    "adwindows.dll",
    "acdotnettool.dll",
    "cautocad.dll",
    "autodesk.autocad.interop.dll",
    "autodesk.autocad.interop.common.dll",
]

OPTIONAL_ASSEMBLIES = [
    "AcCui.dll",
    "AcWindows.dll",
    "AdUIMgd.dll",
    "AdWindows.dll",
    "AcDotNetTool.dll",
    "CAutoCAD.dll",
    "Autodesk.AutoCAD.Interop.dll",
    "Autodesk.AutoCAD.Interop.Common.dll",
]

SKIP_DIRS = frozenset({"bin", "obj", ".git", ".vs", "packages", "node_modules", "__pycache__", "dll", "indexes"})


def default_project_root(explicit: str | None = None) -> Path | None:
    if explicit:
        return Path(explicit).expanduser().resolve()
    env = os.environ.get("CLAUDE_PROJECT_DIR")
    if env:
        return Path(env).expanduser().resolve()
    return None


def resolve_project_context(project_root: str | Path | None = None) -> dict:
    root = default_project_root(str(project_root) if project_root else None)
    if not root or not root.exists():
        return {"status": "not_found", "error": "No project root specified or found."}

    # 1. Check for acadopen.json config
    config_path = root / "acadopen.json"
    if config_path.exists():
        return _from_config(root, config_path)

    # 2. Find .sln files
    sln_files = _find_files(root, "*.sln")
    if len(sln_files) == 1:
        return _from_solution(root, sln_files[0])
    if len(sln_files) > 1:
        return {
            "status": "ambiguous",
            "projectRoot": str(root),
            "solutions": [str(f) for f in sln_files],
            "message": "Multiple .sln files found. Specify project root or create acadopen.json.",
        }

    # 3. Find .csproj files
    csproj_files = _find_files(root, "*.csproj")
    if len(csproj_files) == 1:
        return _from_csproj(root, csproj_files[0])
    if len(csproj_files) > 1:
        return {
            "status": "collection",
            "projectRoot": str(root),
            "projects": [_analyze_csproj(f) for f in csproj_files],
        }

    # 4. Recursive search for acdbmgd.dll
    dll = _find_autocad_dll(root)
    if dll:
        return _from_dll(root, dll)

    return {"status": "not_found", "projectRoot": str(root), "error": "No AutoCAD project or DLL references found."}


def list_projects(project_root: str | Path | None = None) -> dict:
    root = default_project_root(str(project_root) if project_root else None)
    if not root or not root.exists():
        return {"status": "not_found", "error": "No project root specified or found."}

    csproj_files = _find_files(root, "*.csproj")
    projects = []
    for csproj in csproj_files:
        info = _analyze_csproj(csproj)
        projects.append(info)

    return {
        "status": "ready",
        "projectRoot": str(root),
        "projectCount": len(projects),
        "projects": projects,
    }


# ─── Internal helpers ─────────────────────────────────────────────────

def _find_files(root: Path, pattern: str) -> list[Path]:
    results = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for f in filenames:
            if f.lower().endswith(pattern.replace("*", "").lower()):
                results.append(Path(dirpath) / f)
    return results


def _find_autocad_dll(root: Path) -> Path | None:
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for f in filenames:
            if f.lower() == "acdbmgd.dll":
                return Path(dirpath) / f
    return None


def _from_config(root: Path, config_path: Path) -> dict:
    try:
        import json
        config = json.loads(config_path.read_text(encoding="utf-8"))
        assembly_dir = config.get("autocad", {}).get("assemblyDir")
        if assembly_dir:
            asm_dir = (root / assembly_dir).resolve()
            assemblies = _scan_assembly_dir(asm_dir)
            return {
                "status": "ready",
                "projectRoot": str(root),
                "configFile": str(config_path),
                "assemblyDir": str(asm_dir),
                "assemblies": assemblies,
            }
    except Exception as e:
        return {"status": "error", "projectRoot": str(root), "error": str(e)}
    return {"status": "error", "projectRoot": str(root), "error": "Invalid acadopen.json"}


def _from_solution(root: Path, sln_path: Path) -> dict:
    csproj_paths = _parse_sln(sln_path)
    project_details = []
    for csproj in csproj_paths:
        resolved = (sln_path.parent / csproj).resolve()
        if resolved.exists():
            project_details.append(_analyze_csproj(resolved))

    assemblies = _collect_assemblies(project_details)
    return {
        "status": "ready",
        "projectRoot": str(root),
        "solution": str(sln_path),
        "projectCount": len(project_details),
        "projectDetails": project_details,
        "assemblies": assemblies,
    }


def _from_csproj(root: Path, csproj_path: Path) -> dict:
    info = _analyze_csproj(csproj_path)
    assemblies = _collect_assemblies([info])
    return {
        "status": "ready",
        "projectRoot": str(root),
        "projectDetails": [info],
        "assemblies": assemblies,
    }


def _from_dll(root: Path, dll_path: Path) -> dict:
    assembly_dir = dll_path.parent
    assemblies = _scan_assembly_dir(assembly_dir)
    return {
        "status": "ready",
        "projectRoot": str(root),
        "assemblyDir": str(assembly_dir),
        "assemblies": assemblies,
    }


def _parse_sln(sln_path: Path) -> list[str]:
    """Extract .csproj paths from a .sln file."""
    try:
        content = sln_path.read_text(encoding="utf-8-sig", errors="replace")
    except Exception:
        return []
    # Match Project lines: Project("...") = "Name", "path.csproj", "..."
    pattern = r'Project\([^)]*\)\s*=\s*"[^"]*"\s*,\s*"([^"]*\.csproj)"'
    return re.findall(pattern, content, re.IGNORECASE)


def _analyze_csproj(csproj_path: Path) -> dict:
    """Analyze a .csproj file for AutoCAD references."""
    info: dict[str, Any] = {
        "path": str(csproj_path),
        "name": csproj_path.stem,
        "autocadReferences": [],
        "hintPaths": [],
    }
    try:
        content = csproj_path.read_text(encoding="utf-8-sig", errors="replace")
        # Handle both old-style and SDK-style csproj
        # Look for Reference elements with HintPath
        # Pattern: <Reference Include="..."><HintPath>...</HintPath></Reference>
        ref_pattern = r'<Reference\s+Include="([^"]*)"[^>]*>(.*?)</Reference>'
        for match in re.finditer(ref_pattern, content, re.DOTALL | re.IGNORECASE):
            include = match.group(1)
            body = match.group(2)
            hint_match = re.search(r'<HintPath>([^<]*)</HintPath>', body, re.IGNORECASE)
            if hint_match:
                hint_path = hint_match.group(1).strip()
                # Check if this is an AutoCAD reference
                include_lower = include.lower()
                hint_lower = hint_path.lower()
                is_autocad = any(dll.replace(".dll", "") in include_lower or dll in hint_lower for dll in AUTOCAD_DLL_NAMES)
                if is_autocad or "autocad" in include_lower or "acdb" in include_lower:
                    info["autocadReferences"].append(include)
                    resolved = (csproj_path.parent / hint_path).resolve()
                    info["hintPaths"].append(str(resolved))

        # Also try to parse as XML for SDK-style projects
        try:
            tree = ElementTree.fromstring(content)
            ns = {"msbuild": "http://schemas.microsoft.com/developer/msbuild/2003"}
            for ref in tree.iter():
                if ref.tag.endswith("Reference") or ref.tag == "Reference":
                    include = ref.get("Include", "")
                    for child in ref:
                        if child.tag.endswith("HintPath") or child.tag == "HintPath":
                            hint_path = (child.text or "").strip()
                            include_lower = include.lower()
                            hint_lower = hint_path.lower()
                            is_autocad = any(dll.replace(".dll", "") in include_lower or dll in hint_lower for dll in AUTOCAD_DLL_NAMES)
                            if is_autocad or "autocad" in include_lower or "acdb" in include_lower:
                                if include not in info["autocadReferences"]:
                                    info["autocadReferences"].append(include)
                                    resolved = (csproj_path.parent / hint_path).resolve()
                                    info["hintPaths"].append(str(resolved))
        except ElementTree.ParseError:
            pass

    except Exception as e:
        info["error"] = str(e)
    return info


def _scan_assembly_dir(directory: Path) -> list[str]:
    """List AutoCAD DLLs found in a directory."""
    found = []
    if directory.exists():
        for f in directory.iterdir():
            if f.is_file() and f.suffix.lower() == ".dll":
                if f.name.lower() in AUTOCAD_DLL_NAMES:
                    found.append(f.name)
    return sorted(found)


def _collect_assemblies(project_details: list[dict]) -> list[str]:
    """Collect unique assemblies from project details."""
    all_assemblies = set()
    for detail in project_details:
        for hint in detail.get("hintPaths", []):
            p = Path(hint)
            if p.exists() and p.suffix.lower() == ".dll":
                all_assemblies.add(p.name)
    return sorted(all_assemblies)
