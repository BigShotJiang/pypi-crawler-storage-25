# Contribution guidelines

Contributing to this project should be as easy and transparent as possible, whether it's:

- Reporting a bug
- Discussing the current state of the code
- Submitting a fix
- Proposing new features

## Project Maintenance

The project owner [@foxey](https://github.com/foxey) currently lacks the time to actively review and support this project on a day-to-day basis.

To keep the project moving, review duties have been delegated to **Ada**, an AI assistant powered by [NanoClaw](https://github.com/foxey/nanoclaw). Ada will handle:

- Reviewing pull requests and posting feedback
- Triaging issues
- Merging approved contributions

Ada acts on behalf of @foxey. Final decisions on architectural changes or significant new features may still be escalated to @foxey directly.

If you're unsure whether your question needs a human, just open an issue or PR as usual — Ada will respond.

## Github is used for everything

Github is used to host code, to track issues and feature requests, as well as accept pull requests.

Pull requests are the best way to propose changes to the codebase.

1. Fork the repo and create your branch from `main`.
2. If you've changed something, update the documentation.
3. Make sure your code lints (using `scripts/lint`).
4. Test you contribution.
5. Issue that pull request!

## Any contributions you make will be under the Apache License

In short, when you submit code changes, your submissions are understood to be under the same [Apache License](https://www.apache.org/licenses/LICENSE-2.0) that covers the project. Feel free to contact the maintainers if that's a concern.

## Report bugs using Github's [issues](../../issues)

GitHub issues are used to track public bugs.
Report a bug by [opening a new issue](../../issues/new/choose); it's that easy!

## Write bug reports with detail, background, and sample code

**Great Bug Reports** tend to have:

- A quick summary and/or background
- Steps to reproduce
  - Be specific!
  - Give sample code if you can.
- What you expected would happen
- What actually happens
- Notes (possibly including why you think this might be happening, or stuff you tried that didn't work)

People *love* thorough bug reports. I'm not even kidding.

## Use a Consistent Coding Style

Use [black](https://github.com/ambv/black) to make sure the code follows the style.

## Test your code modification

It comes with development environment in a container, easy to launch
if you use Visual Studio Code.

## License

By contributing, you agree that your contributions will be licensed under its Apache License.
