"""Environment and validation helpers for config loading."""

from __future__ import annotations

import os
from typing import Any

from inspire.config.models import SOURCE_ENV, SOURCE_PROJECT, ConfigError
from inspire.config.schema import CONFIG_OPTIONS


def _apply_env_layer(
    *,
    config_dict: dict[str, Any],
    sources: dict[str, str],
    prefer_source: str,
) -> str | None:
    env_password = os.getenv("INSPIRE_PASSWORD")

    for option in CONFIG_OPTIONS:
        if option.env_var == "INSPIRE_PASSWORD":
            continue

        value = os.getenv(option.env_var)
        if value is None and option.env_var == "INSP_LOG_CACHE_DIR":
            value = os.getenv("INSPIRE_LOG_CACHE_DIR")
        if value is None:
            continue

        field_name = option.field_name
        if field_name not in config_dict:
            continue

        if option.parser:
            try:
                parsed_value = option.parser(value)
            except (ValueError, TypeError) as e:
                raise ConfigError(f"Invalid {option.env_var} value: {value}") from e
            new_value = parsed_value
        else:
            new_value = value

        # Cross-account / cross-repo guard: if the active project's
        # `[context].project` already resolved to a value, refuse to let
        # an `INSPIRE_PROJECT_ID` env var silently shadow it. Two repos
        # with different projects sharing the same shell would otherwise
        # have one of them quietly running against the wrong project.
        # User can override explicitly by clearing the project setting in
        # the repo or unsetting the env var.
        if (
            option.env_var == "INSPIRE_PROJECT_ID"
            and sources.get(field_name) == SOURCE_PROJECT
            and config_dict.get(field_name)
            and str(config_dict[field_name]) != str(new_value)
        ):
            raise ConfigError(
                "INSPIRE_PROJECT_ID conflicts with the project resolved from "
                f"this repo's [context].project ({config_dict[field_name]!r} "
                f"vs env {new_value!r}). Pick one: unset the env var, or "
                "remove [context].project from ./.inspire/config.toml."
            )

        if prefer_source == "toml" and sources.get(field_name) == SOURCE_PROJECT:
            continue

        config_dict[field_name] = new_value
        sources[field_name] = SOURCE_ENV

    return env_password


def _apply_password_and_token_fallbacks(
    *,
    config_dict: dict[str, Any],
    sources: dict[str, str],
    env_password: str | None,
) -> None:
    """Apply env-var fallbacks for password and github_token.

    The account-layer file is the primary source of ``password``; this
    stage only handles the env-var overrides that CI / scripts rely on.
    """
    if not config_dict.get("password") and env_password:
        config_dict["password"] = env_password
        sources["password"] = SOURCE_ENV

    if not config_dict.get("github_token"):
        github_token_fallback = os.getenv("GITHUB_TOKEN")
        if github_token_fallback:
            config_dict["github_token"] = github_token_fallback
            sources["github_token"] = SOURCE_ENV


def _validate_required_config(
    *,
    config_dict: dict[str, Any],
    require_credentials: bool,
) -> None:
    if require_credentials:
        if not config_dict["username"] or not config_dict["password"]:
            raise ConfigError(
                "Missing platform credentials for the active account. Run "
                "`inspire account add <name>` to (re)configure them."
            )


__all__ = [
    "_apply_env_layer",
    "_apply_password_and_token_fallbacks",
    "_validate_required_config",
]
