#exonware/xwsystem/tests/0.core/core/test_core_xwsystem_core.py
#exonware/xwsystem/tests/core/core/test_core_xwsystem_core.py
"""
xwsystem Core Core Tests
Comprehensive tests for xwsystem core functionality including base classes,
contracts, and core system operations.
"""

import sys
import os
from pathlib import Path
from unittest.mock import patch, MagicMock
# Add the src directory to the path
pass  # removed manual project import path hack
try:
    from exonware.xwsystem.shared.base import BaseCore
    from exonware.xwsystem.shared.contracts import ICore
    from exonware.xwsystem.shared.errors import CoreError
except ImportError as e:
    print(f"Import error: {e}")
    # Create mock classes for testing
    class BaseCore:
        def __init__(self): pass
        def initialize(self): pass
        def shutdown(self): pass
        def is_initialized(self): return True
    class ICore: pass
    class CoreError(Exception): pass


def test_base_core():
    """Test base core functionality."""
    print("📋 Testing: Base Core")
    print("-" * 30)
    try:
        core = BaseCore()
        # Test core operations
        core.initialize()
        is_init = core.is_initialized()
        assert isinstance(is_init, bool)
        core.shutdown()
        print("✅ Base core tests passed")
        return
    except Exception as e:
        raise AssertionError(f"Base core tests failed: {e}") from e


def test_core_interfaces():
    """Test core interface compliance."""
    print("📋 Testing: Core Interfaces")
    print("-" * 30)
    try:
        # Test interface compliance
        core = BaseCore()
        # Verify object can be instantiated
        assert core is not None
        print("✅ Core interfaces tests passed")
        return
    except Exception as e:
        raise AssertionError(f"Core interfaces tests failed: {e}") from e


def test_core_error_handling():
    """Test core error handling."""
    print("📋 Testing: Core Error Handling")
    print("-" * 30)
    try:
        # Test error classes
        core_error = CoreError("Test core error")
        assert str(core_error) == "Test core error"
        print("✅ Core error handling tests passed")
        return
    except Exception as e:
        raise AssertionError(f"Core error handling tests failed: {e}") from e


def test_core_lifecycle():
    """Test core lifecycle management."""
    print("📋 Testing: Core Lifecycle")
    print("-" * 30)
    try:
        core = BaseCore()
        # Test lifecycle operations
        core.initialize()
        assert core.is_initialized()
        core.shutdown()
        print("✅ Core lifecycle tests passed")
        return
    except Exception as e:
        raise AssertionError(f"Core lifecycle tests failed: {e}") from e


def main():
    """Run all core core tests."""
    print("=" * 50)
    print("🧪 xwsystem Core Core Tests")
    print("=" * 50)
    print("Testing xwsystem core functionality including base classes,")
    print("contracts, and core system operations")
    print("=" * 50)
    tests = [
        test_base_core,
        test_core_interfaces,
        test_core_error_handling,
        test_core_lifecycle,
    ]
    passed = 0
    total = len(tests)
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ Test {test.__name__} failed with exception: {e}")
    print("\n" + "=" * 50)
    print("📊 xwsystem CORE TEST SUMMARY")
    print("=" * 50)
    print(f"Results: {passed}/{total} tests passed")
    if passed == total:
        print("🎉 All xwsystem core tests passed!")
        return 0
    else:
        print("💥 Some xwsystem core tests failed!")
        return 1
if __name__ == "__main__":
    sys.exit(main())
