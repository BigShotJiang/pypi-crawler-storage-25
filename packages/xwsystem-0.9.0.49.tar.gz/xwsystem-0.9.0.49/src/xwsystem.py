# src/xwsystem.py
"""
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Top-level ``xwsystem`` import alias: same module object as ``exonware.xwsystem``.

This shim preserves backward compatibility for ``import xwsystem`` by mapping the
top-level module entry to ``exonware.xwsystem`` inside ``sys.modules``.
"""

from __future__ import annotations

import importlib
import sys

_pkg = importlib.import_module("exonware.xwsystem")

# Root cause fix: the compatibility import must return the exact same module
# object so identity checks and module-global singletons behave consistently.
sys.modules[__name__] = _pkg
