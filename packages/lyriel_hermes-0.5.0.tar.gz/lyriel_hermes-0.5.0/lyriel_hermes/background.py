"""Background turn invocation. Runs the agent's LLM for a single turn
without touching the user's main session or surfacing anything to
their chat.

Used by inbox.py to handle Lyriel plan rounds autonomously: the
agent receives the plan-round dispatch, calls lyriel_plan_reply via
its normal tool dispatch (stay-silent or contribute), and returns.
The user's main conversation is unaffected; they only see the final
plan_locked / plan_cancelled notification, never the rounds.

Implementation note: replicates the AIAgent construction from
hermes_cli.oneshot._run_agent WITHOUT the oneshot-CLI global side
effects:
  - _run_agent calls logging.disable(CRITICAL), which would silence
    the entire gateway process. We don't touch logging.
  - _run_agent sets HERMES_YOLO_MODE=1 and HERMES_ACCEPT_HOOKS=1
    process-wide, auto-approving every dangerous-command prompt and
    shell hook. We don't set those — the plugin doesn't need shell
    or destructive tools, and the user shouldn't lose hook gating
    because a plan round fired in the background.
  - _run_agent redirects stdout/stderr to /dev/null. We rely on
    quiet_mode + nulled streaming callbacks instead, which is what
    keeps the gateway's normal logging working.

Threading: called from the inbox poll loop's daemon thread. Each
background turn blocks the loop until the LLM completes — this is
intentional for v0 simplicity (plans are infrequent and sequential
is easier to reason about than concurrent agent invocations).
Memory writes from concurrent AIAgent instances would be a real
race; staying sequential dodges it.

Memory: AIAgent loads memory via the user's configured provider
(file-based or remote). Same provider across invocations = the
background turn sees the user's persistent memory. Session-scoped
chat history is per-session_id; we pass None for now, so background
turns get a fresh session_id and see persistent memory but not the
user's current chat scroll. Acceptable for v0; revisit if plan
decisions need recent chat context.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


# Prepended to every plan-round dispatch before handing to the LLM.
# Tight wording — every additional token is paid for on every plan
# round and matters at scale.
BACKGROUND_PROMPT_PREFIX = (
    "[Lyriel background plan turn. Your user is NOT watching this turn "
    "and you must not ask them clarifying questions. Use what you "
    "already know about them; if a constraint is missing, accept wide "
    "constraints and let other participants narrow. Respond by calling "
    "the lyriel_plan_reply tool concisely (stay_silent=true if you "
    "have nothing to add). Do not produce filler text.]\n\n"
)


def run_background_turn(prompt: str) -> str | None:
    """Run a single agent turn with `prompt`. Returns the agent's text
    response (often empty or short — the real work happens via the
    lyriel_plan_reply tool call), or None on error.

    All errors are logged + swallowed. A failed background turn means
    the round goes unanswered; Lyriel's server-side timeout takes
    over from there.
    """
    try:
        from hermes_cli.config import load_config
        from hermes_cli.runtime_provider import resolve_runtime_provider
        from hermes_cli.tools_config import _get_platform_tools
        from run_agent import AIAgent
    except ImportError as e:
        logger.error("background turn: Hermes runtime not importable: %s", e)
        return None

    try:
        cfg = load_config()
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: load_config failed: %s", e)
        return None

    model_cfg = cfg.get("model") or {}
    if isinstance(model_cfg, str):
        cfg_model = model_cfg
    else:
        cfg_model = model_cfg.get("default") or model_cfg.get("model") or ""

    try:
        runtime = resolve_runtime_provider(
            requested=None,
            target_model=cfg_model or None,
        )
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: resolve_runtime_provider failed: %s", e)
        return None

    try:
        toolsets_list = sorted(_get_platform_tools(cfg, "cli"))
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: failed to resolve toolsets: %s", e)
        return None

    try:
        agent = AIAgent(
            api_key=runtime.get("api_key"),
            base_url=runtime.get("base_url"),
            provider=runtime.get("provider"),
            api_mode=runtime.get("api_mode"),
            model=cfg_model,
            enabled_toolsets=toolsets_list,
            quiet_mode=True,
            platform="lyriel-background",
            credential_pool=runtime.get("credential_pool"),
        )
        # Defensive: kill streaming callbacks so the agent never tries
        # to render to a terminal that isn't there. quiet_mode handles
        # most of this; explicit None covers everything else.
        agent.suppress_status_output = True
        agent.stream_delta_callback = None
        agent.tool_gen_callback = None
        agent.thinking_callback = None
        agent.reasoning_callback = None
        agent.status_callback = None
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: failed to build AIAgent: %s", e)
        return None

    try:
        return agent.chat(prompt) or ""
    except Exception as e:  # noqa: BLE001
        logger.error("background turn: agent.chat failed: %s", e)
        return None
