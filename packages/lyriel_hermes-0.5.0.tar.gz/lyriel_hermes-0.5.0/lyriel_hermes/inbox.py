"""Background poll loop: long-polls Lyriel /api/inbox, then routes each
dispatch by direction:

  - dispatch / forward (1:1 asks) — surface to the user via CLI
    inject_message OR whichever gateway platform Hermes is routing
    through (Telegram, Discord, Signal, Slack, etc.).

  - plan rounds (non-terminal) — handle autonomously via a background
    agent turn (background.run_background_turn). The user is NOT
    surfaced these rounds; their agent processes the round, calls
    lyriel_plan_reply on their behalf, and the loop moves on. This
    is the load-bearing change for agent-mediated plan coordination
    — the user sees the lock, not the back-and-forth.

  - plan_locked / plan_cancelled — surface to the user (final
    outcome they need to see).

  - friend events (request / accept / decline / unfriend) — surface
    to the user.

Runs on a daemon thread spawned from `register(ctx)`. Background
plan turns block the loop until the LLM completes — sequential by
design at v0; plans are infrequent and concurrent AIAgent instances
would race on memory writes.
"""

from __future__ import annotations

import logging
import threading
import time

from . import api, background, pending, surfacing

logger = logging.getLogger(__name__)

_RECONNECT_BACKOFF_S = 5
_INBOX_TIMEOUT_S = 30
_POLL_INTERVAL_AFTER_BATCH = 0.5  # the GET above already long-polled


def _poll_forever(ctx) -> None:
    """Main poll loop. ctx is the PluginContext captured at register()."""
    logger.info("lyriel inbox poll loop started (base=%s)", api.base_url())

    while True:
        try:
            dispatches = api.long_poll_inbox(timeout=_INBOX_TIMEOUT_S)
        except api.LyrielApiError as e:
            logger.warning("inbox poll error: %s", e)
            time.sleep(_RECONNECT_BACKOFF_S)
            continue
        except Exception as e:  # noqa: BLE001
            logger.warning("inbox poll unexpected error: %s", e)
            time.sleep(_RECONNECT_BACKOFF_S)
            continue

        for d in dispatches:
            ask_id = d.get("ask_id")
            plan_id = d.get("plan_id")
            direction = d.get("direction", "?")
            prompt_text = d.get("prompt", "") or ""
            correlation = plan_id or ask_id or "?"

            # Remember the callback BEFORE surfacing so the LLM tool can
            # find it even if the surface call races.
            if direction == "dispatch" and ask_id:
                if not pending.remember(ask_id, prompt_text):
                    logger.warning(
                        "could not extract callback URL/token for ask %s — "
                        "user replies via the LLM tool will fail",
                        ask_id,
                    )

            if direction == "plan" and plan_id:
                if not pending.remember_plan(plan_id, prompt_text):
                    # Plans go through multiple rounds; if it's a terminal
                    # locked envelope, there's no callback to extract and
                    # this is expected. Only warn on non-locked envelopes.
                    is_locked = "[Lyriel group plan — LOCKED]" in prompt_text
                    if not is_locked:
                        logger.warning(
                            "could not extract callback for plan %s — "
                            "user contributions via the LLM tool will fail",
                            plan_id,
                        )
                    else:
                        # Plan locked — drop any prior pending entry.
                        pending.forget_plan(plan_id)

            # Synchronous-completion suppression: if the lyriel_send_ask
            # tool already inlined this ask's response into its own tool
            # result (system_responder case — @lyriel responds instantly),
            # the user has already seen the reply via the LLM's
            # confirmation turn. Skip surfacing to avoid duplicate.
            if direction == "forward" and ask_id and pending.was_absorbed(ask_id):
                logger.info(
                    "skipped forward ask_id=%s (already absorbed by tool)",
                    ask_id,
                )
                continue

            # Plan-round dispatches: handle in a background agent turn
            # without surfacing to the user. The agent's LLM picks up
            # lyriel_plan_reply and responds autonomously based on what
            # it already knows about the user. Plan_locked and
            # plan_cancelled envelopes ARE surfaced (those are the
            # outcomes the user needs to see) — detect them by the
            # canonical markers from the server-side prompt builder.
            if direction == "plan" and plan_id:
                is_terminal = (
                    "[Lyriel group plan — LOCKED]" in prompt_text
                    or "[Lyriel group plan — CANCELLED]" in prompt_text
                )
                if not is_terminal:
                    bg_prompt = background.BACKGROUND_PROMPT_PREFIX + prompt_text
                    try:
                        result = background.run_background_turn(bg_prompt)
                        logger.info(
                            "ran background plan turn for plan_id=%s (response_len=%d)",
                            plan_id,
                            len(result or ""),
                        )
                    except Exception as e:  # noqa: BLE001
                        logger.error(
                            "background plan turn failed for plan_id=%s: %s",
                            plan_id,
                            e,
                        )
                    continue

            surface_text = surfacing.format_dispatch(d)

            # Try CLI surface first. inject_message returns True iff the
            # plugin is running under a CLI session (not under the
            # gateway). Cheap to attempt either way.
            cli_ok = surfacing.surface_to_cli(ctx, surface_text)

            if cli_ok:
                logger.info(
                    "surfaced %s id=%s via CLI inject_message",
                    direction,
                    correlation,
                )
                continue

            # Not in CLI mode — try whichever messaging platform the
            # gateway is configured to route through.
            target = surfacing.resolve_surface_target()
            if not target:
                logger.warning(
                    "no surface available for %s id=%s — neither "
                    "CLI inject_message nor a configured gateway chat "
                    "(set plugins.entries.lyriel.surface_chat_id). "
                    "Dispatch claimed from Lyriel but user won't see "
                    "it until they query manually.",
                    direction,
                    correlation,
                )
                continue

            platform, chat_id = target
            try:
                surfacing.send_via_gateway(platform, chat_id, surface_text)
                logger.info(
                    "surfaced %s id=%s via %s chat %s",
                    direction,
                    correlation,
                    platform,
                    chat_id,
                )
            except Exception as e:  # noqa: BLE001
                logger.error(
                    "surfacing dispatch %s via %s failed: %s",
                    correlation,
                    platform,
                    e,
                )

        # If the GET already long-polled but returned empty, loop straight
        # back. If it returned data, brief pause so we batch tightly without
        # tight-looping a hot CPU.
        if dispatches:
            time.sleep(_POLL_INTERVAL_AFTER_BATCH)


def start(ctx) -> threading.Thread:
    """Spawn the poll loop on a daemon thread. Caller (register) holds
    a reference if it wants to introspect; the thread is daemon so the
    Hermes process can exit cleanly without joining.
    """
    t = threading.Thread(
        target=_poll_forever,
        args=(ctx,),
        daemon=True,
        name="lyriel-inbox",
    )
    t.start()
    return t
