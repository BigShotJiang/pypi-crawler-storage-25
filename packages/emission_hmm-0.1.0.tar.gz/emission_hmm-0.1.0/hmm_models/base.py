import numpy as np
from abc import ABC, abstractmethod
from itertools import product
from tqdm import tqdm
from typing import Tuple


class HMM(ABC):
    """
    Abstract base class for Hidden Markov Models.

    Subclasses must implement the `emission_matrices` property returning an ndarray
    of shape (d_vocab, num_hidden_states, num_hidden_states) where
    E[j, i, k] = P(observe token j AND transition to state k | currently in state i).
    """

    def __init__(self):
        pass

    @property
    @abstractmethod
    def emission_matrices(self) -> np.ndarray:
        pass

    @property
    def num_hidden_states(self) -> int:
        return self.emission_matrices.shape[1]

    @property
    def d_vocab(self) -> int:
        return self.emission_matrices.shape[0]

    def get_stationary_distribution(self) -> np.ndarray:
        """Calculate the stationary distribution (initial belief state) for the HMM."""
        T = np.sum(self.emission_matrices, axis=0)
        eigenvalues, eigenvectors = np.linalg.eig(T.T)
        idx = np.argmin(np.abs(eigenvalues - 1.0))
        stationary = np.real(eigenvectors[:, idx])
        stationary = stationary / np.sum(stationary)
        return stationary

    def generate_sequence(
        self, length: int, init_state: int | None = None, use_tqdm: bool = False
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Generate a single (states, observations) sequence.

        Args:
            length: Sequence length.
            init_state: Initial hidden state index. If None, sample from stationary distribution.
            use_tqdm: Show progress bar.

        Returns:
            Tuple of (states, observations) as numpy arrays of shape (length,).
        """
        if init_state is None:
            stationary = self.get_stationary_distribution()
            init_state = np.random.choice(self.num_hidden_states, p=stationary)

        states = np.zeros(length, dtype=np.int64)
        obs = np.zeros(length, dtype=np.int64)
        current_state = init_state

        for t_idx in tqdm(range(length), desc="Generating sequence") if use_tqdm else range(length):
            states[t_idx] = current_state
            probs = self.emission_matrices[:, current_state, :].flatten()
            if t_idx <= 10:
                assert abs(probs.sum() - 1.0) < 1e-6, f"Probs sum to {probs.sum()}"

            generated_sample = np.random.choice(len(probs), p=probs)
            generated_observation = generated_sample // self.num_hidden_states
            generated_next_state = generated_sample % self.num_hidden_states

            obs[t_idx] = generated_observation
            current_state = generated_next_state

        return states, obs

    def mixed_state_presentation(self, obs: np.ndarray) -> np.ndarray:
        """
        Compute belief states from observation sequences.

        Args:
            obs: Observation sequences, shape (length,) or (batch_size, length).

        Returns:
            Belief states, shape (length, num_hidden_states) or (batch_size, length, num_hidden_states).
        """
        if obs.ndim == 1:
            obs = obs[np.newaxis, :]
            squeeze_output = True
        else:
            squeeze_output = False

        batch_size, length = obs.shape
        stationary = self.get_stationary_distribution()
        belief = np.tile(stationary, (batch_size, 1))
        beliefs = []

        for t_idx in range(length):
            obs_t = obs[:, t_idx]
            emission_mats = self.emission_matrices[obs_t]
            belief = np.einsum('bi,bij->bj', belief, emission_mats)
            belief = belief / belief.sum(axis=1, keepdims=True)
            beliefs.append(belief)

        result = np.stack(beliefs, axis=1)
        if squeeze_output:
            result = np.squeeze(result, axis=0)
        return result

    def generate_data(
        self,
        batch_size: int,
        length: int,
        init_state: int | None = None,
        use_tqdm: bool = False,
        as_torch: bool = False,
    ) -> np.ndarray:
        """
        Generate a batch of observation sequences.

        Args:
            batch_size: Number of sequences.
            length: Length of each sequence.
            init_state: If -1, use random init state per sequence.
                        If None, sample from stationary distribution.
                        If int >= 0, use that specific state for all sequences.
            use_tqdm: Show progress bar.
            as_torch: If True, return a torch.Tensor instead of np.ndarray.

        Returns:
            Array of shape (batch_size, length).
        """
        import random as _random

        obs_batch = []
        for _ in tqdm(range(batch_size), desc="Generating data") if use_tqdm else range(batch_size):
            if init_state == -1:
                seq_init_state = _random.randint(0, self.num_hidden_states - 1)
            else:
                seq_init_state = init_state
            _, obs = self.generate_sequence(length, init_state=seq_init_state)
            obs_batch.append(obs)

        result = np.stack(obs_batch, axis=0)

        if as_torch:
            import torch
            return torch.from_numpy(result)

        return result

    def entropy_rate_theory_estimate(self) -> float:
        """Calculate theoretical entropy rate."""
        stationary = self.get_stationary_distribution()
        entropy_rate = 0.0
        for i in range(self.num_hidden_states):
            prob = stationary[i]
            for j, k in product(range(self.d_vocab), range(self.num_hidden_states)):
                if self.emission_matrices[j, i, k] != 0:
                    entropy_rate += -prob * self.emission_matrices[j, i, k] * np.log(self.emission_matrices[j, i, k])
        return float(entropy_rate)

    def entropy_rate_empirical_estimate(self, length: int, burn_in: int = 0) -> float:
        """Calculate empirical entropy rate estimate."""
        stationary = self.get_stationary_distribution()
        _, obs = self.generate_sequence(length + burn_in)

        current_belief = stationary
        entropy = 0.0
        count = 0
        for i in range(len(obs)):
            if i >= burn_in:
                entropy_term = np.einsum('i,jik->jk', current_belief, self.emission_matrices)
                entropy_term = entropy_term.sum(axis=1)
                entropy += -np.sum(entropy_term * np.log(entropy_term + 1e-6))
                count += 1

            current_belief = current_belief @ self.emission_matrices[obs[i]]
            current_belief = current_belief / current_belief.sum()

        return float(entropy / count)
