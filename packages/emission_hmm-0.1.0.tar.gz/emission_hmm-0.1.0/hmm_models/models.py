import numpy as np

from .base import HMM


class RRXOR(HMM):
    """5-state, 2-token RRXOR process."""

    def __init__(self):
        pass

    @property
    def emission_matrices(self) -> np.ndarray:
        E = np.zeros((2, 5, 5))
        E[0] = np.array([
            [0, 0.5, 0, 0, 0],
            [0, 0, 0, 0, 0.5],
            [0, 0, 0, 0.5, 0],
            [0, 0, 0, 0, 0],
            [1, 0, 0, 0, 0],
        ])
        E[1] = np.array([
            [0, 0, 0.5, 0, 0],
            [0, 0, 0, 0.5, 0],
            [0, 0, 0, 0, 0.5],
            [1, 0, 0, 0, 0],
            [0, 0, 0, 0, 0],
        ])
        return E


class Z1R(HMM):
    """3-state, 2-token Z1R process."""

    def __init__(self):
        pass

    @property
    def emission_matrices(self) -> np.ndarray:
        E = np.zeros((2, 3, 3))
        E[0, 0, 1] = 1.0
        E[0, 2, 0] = 1 / 2
        E[1, 1, 2] = 1.0
        E[1, 2, 0] = 1 / 2
        return E


class Mess3Proc(HMM):
    """3-state, 3-token Mess3 process."""

    def __init__(self):
        pass

    @property
    def emission_matrices(self) -> np.ndarray:
        E = np.zeros((3, 3, 3))
        E[0] = np.array([
            [0.765, 0.00375, 0.00375],
            [0.0425, 0.0675, 0.00375],
            [0.0425, 0.00375, 0.0675],
        ])
        E[1] = np.array([
            [0.0675, 0.0425, 0.00375],
            [0.00375, 0.765, 0.00375],
            [0.00375, 0.0425, 0.0675],
        ])
        E[2] = np.array([
            [0.0675, 0.00375, 0.0425],
            [0.00375, 0.0675, 0.0425],
            [0.00375, 0.00375, 0.765],
        ])
        return E


class PSL7HMM(HMM):
    """HMM loaded from a .npy emission matrix file."""

    def __init__(self, path: str):
        """
        Args:
            path: Path to .npy file containing the emission matrix
                  of shape (d_vocab, num_hidden_states, num_hidden_states).
        """
        self._emission_matrices = np.load(path)

    @property
    def emission_matrices(self) -> np.ndarray:
        return self._emission_matrices


class DirectedCycleHMM(HMM):
    """
    HMM on a directed cycle with noisy emissions.

    Hidden states sit on a cycle of length num_states.
    Transition: state i -> (i+1)%N with prob `bias`, (i-1)%N with prob `1-bias`.
    Emission: state i emits token i with prob `1-emission_noise`, uniform noise elsewhere.
    d_vocab = num_states.
    """

    def __init__(self, num_states: int = 5, bias: float = 0.9, emission_noise: float = 0.3):
        self.num_states = num_states
        self.bias = bias
        self.emission_noise = emission_noise
        self._E = self._build_emission_matrices()

    def _build_emission_matrices(self):
        N = self.num_states
        b = self.bias
        eps = self.emission_noise

        T = np.zeros((N, N))
        for i in range(N):
            T[i, (i + 1) % N] = b
            T[i, (i - 1) % N] = 1 - b

        O = np.full((N, N), eps / (N - 1))
        np.fill_diagonal(O, 1 - eps)

        E = np.einsum('ji,ik->jik', O, T)
        return E

    @property
    def emission_matrices(self):
        return self._E


class CylinderGraphHMM(HMM):
    """
    HMM based on a cylinder graph structure with depth and nodes per level.

    Requires `networkx` and `einops` (install with `pip install hmm-models[cylinder]`).
    """

    def __init__(
        self,
        n: int,
        depth: int,
        tokens_per_cluster: int = 16,
        dirichlet_alpha: float = 0.5,
        p: float = 0.1,
        seed: int | None = None,
    ):
        """
        Args:
            n: Number of nodes per level (width of cylinder).
            depth: Number of levels (height of cylinder).
            tokens_per_cluster: Number of tokens per depth level.
            dirichlet_alpha: Concentration parameter for Dirichlet prior on token distributions.
            p: Probability of transitioning to next layer (vs staying in current layer).
            seed: Random seed for reproducibility.
        """
        import itertools

        try:
            import networkx as nx
        except ImportError:
            raise ImportError(
                "CylinderGraphHMM requires networkx and einops. "
                "Install with: pip install hmm-models[cylinder]"
            )

        self.n = n
        self.depth = depth
        self.tokens_per_cluster = tokens_per_cluster
        self.dirichlet_alpha = dirichlet_alpha
        self.p = p
        self.seed = seed

        self._nx = nx
        self._itertools = itertools
        self.graph = self._build_cylinder_graph()

    def _build_cylinder_graph(self):
        nx = self._nx
        itertools = self._itertools

        if self.seed is not None:
            np.random.seed(self.seed)

        G = nx.DiGraph()

        for i, (l, j) in enumerate(itertools.product(range(self.depth), range(self.n))):
            G.add_node(i, depth=l, position=j)

        for l in range(self.depth):
            for j in range(self.n):
                current_node = l * self.n + j
                NN_node = l * self.n + (j + 1) % self.n
                NNN_node = l * self.n + (j + 2) % self.n
                next_layer_node = ((l + 1) % self.depth) * self.n + j

                random_weight = np.random.uniform(0, 1 - self.p)
                G.add_edge(current_node, NN_node, weight=random_weight)
                G.add_edge(current_node, NNN_node, weight=1 - self.p - random_weight)
                G.add_edge(current_node, next_layer_node, weight=self.p)

        self._add_token_distributions(G)
        return G

    def _add_token_distributions(self, G) -> None:
        d_vocab = self.tokens_per_cluster * self.depth

        for node, attrs in G.nodes(data=True):
            token_dist = np.random.dirichlet(
                np.ones(self.tokens_per_cluster) * self.dirichlet_alpha
            )
            token_dist_all = np.zeros(d_vocab)
            start_idx = attrs['depth'] * self.tokens_per_cluster
            end_idx = (attrs['depth'] + 1) * self.tokens_per_cluster
            token_dist_all[start_idx:end_idx] = token_dist
            attrs['token_dist'] = token_dist_all

    def _get_emission_matrix(self) -> np.ndarray:
        import einops

        nx = self._nx
        state_transition = nx.adjacency_matrix(self.graph, weight='weight').todense()

        d_vocab = self.graph.nodes(data=True)[0]['token_dist'].shape[0]
        emission = np.zeros((d_vocab, self.graph.number_of_nodes()))
        for i in range(self.graph.number_of_nodes()):
            emission[:, i] = self.graph.nodes(data=True)[i]['token_dist']

        tot_emission_matrix = einops.einsum(
            state_transition, emission,
            "current_state next_state, d_vocab current_state -> d_vocab current_state next_state",
        )
        return tot_emission_matrix

    @property
    def emission_matrices(self):
        return self._get_emission_matrix()
