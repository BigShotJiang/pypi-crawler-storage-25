import inspect
from .base import HMM
from .models import RRXOR, Z1R, Mess3Proc, PSL7HMM, DirectedCycleHMM, CylinderGraphHMM


PROCESS_REGISTRY: dict[str, type[HMM]] = {
    "rrxor": RRXOR,
    "z1r": Z1R,
    "mess3": Mess3Proc,
    "psl7": PSL7HMM,
    "directed_cycle": DirectedCycleHMM,
    "cylinder_graph": CylinderGraphHMM,
}


def create_process_from_dict(process_config: dict) -> HMM:
    """
    Factory function to create HMM process from config dictionary.

    Args:
        process_config: Dict with 'name' and optional 'params' keys.

    Returns:
        Instantiated HMM process.

    Example:
        config = {"name": "mess3"}
        proc = create_process_from_dict(config)

        config = {"name": "cylinder_graph", "params": {"n": 6, "depth": 3}}
        proc = create_process_from_dict(config)
    """
    process_name = process_config["name"]
    all_params = process_config.get("params", {})

    if process_name not in PROCESS_REGISTRY:
        available = ", ".join(PROCESS_REGISTRY.keys())
        raise ValueError(f"Unknown process '{process_name}'. Available: {available}")

    process_cls = PROCESS_REGISTRY[process_name]

    sig = inspect.signature(process_cls.__init__)
    valid_params = set(sig.parameters.keys()) - {"self"}

    filtered_params = {k: v for k, v in all_params.items() if k in valid_params}

    ignored_params = set(all_params.keys()) - valid_params
    if ignored_params:
        print(f"Note: Process '{process_name}' ignoring parameters: {ignored_params}")

    return process_cls(**filtered_params)
