# LaraFastAPI

A framework for FastAPI similar to Laravel

## install

(1) install: `pip install LaraFastAPI`

(2) build application directories: `lara_post_install`

(3) run the app: `uvicorn main:app --reload`

## usage

### (1) command

① create controller : `python larafast make:controller User`

② create api-controller : `python larafast make:api User`

③ create restful-controller : `python larafast make:rest User`

④ create model : `python larafast make:model User`

⑤ run app : `python larafast dev`

### (2) model

the database config file is in the `/config.py`, you can specify your own database information.

the model documentation is in [https://tortoise.github.io](https://tortoise.github.io).

### (3) controller & views

the controller file is in the `/app/controllers` directory, and the view files are in the `/app/views` directory.

the view enginer is using `jinja2` template.

### (4) publish

```bash
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000 --timeout 120
```