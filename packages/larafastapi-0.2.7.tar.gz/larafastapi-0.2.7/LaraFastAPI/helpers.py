from fastapi import APIRouter
from jinja2 import Environment, FileSystemLoader
from fastapi.responses import HTMLResponse

def view(htmlfile: str, render_vars: dict = None):
    """渲染HTML视图
    Args:
        htmlfile: HTML模板文件路径，相对于app/views目录，例如"msgs/show.html"
        render_vars: 模板渲染变量字典，例如{"msg": msg}
    Returns:
        HTMLResponse: 渲染后的HTML响应
    """
    template = Environment(loader=FileSystemLoader("app/views")).get_template(htmlfile)
    return HTMLResponse(content=template.render(**(render_vars or {})))

def resource_router(controller, prefix: str):
    """生成RESTful资源路由
    Args:
        controller: 控制器实例, 必须实现index、show、store、update、destroy方法
        prefix: 路由前缀，例如"/users"
    Returns:
        APIRouter: 包含资源路由的APIRouter实例
    """
    router = APIRouter(prefix=prefix, tags=[prefix.strip("/")])

    # 绑定路由 -> rest方法
    router.add_api_route('', controller.index, methods=["GET"], name=f"{prefix} Index")
    router.add_api_route('/{item_id}', controller.show, methods=["GET"], name=f"{prefix} Show")
    router.add_api_route('', controller.store, methods=["POST"], name=f"{prefix} Store")
    router.add_api_route('/{item_id}', controller.update, methods=["PUT"], name=f"{prefix} Update")
    router.add_api_route('/{item_id}', controller.destroy, methods=["DELETE"], name=f"{prefix} Destroy")

    return router

def controller_router(controller, prefix: str):
    """生成控制器路由
    Args:
        controller: 控制器实例，必须实现对应方法
        prefix: 路由前缀，例如"users"
    Returns:
        APIRouter: 包含控制器路由的APIRouter实例
    """
    router = APIRouter(prefix=prefix, tags=[prefix.strip("/")])

    # 绑定路由 -> 控制器方法
    for method_name in dir(controller):
        if not method_name.startswith("_"):
            method = getattr(controller, method_name)
            if callable(method):
                router.add_api_route(f"/{method_name}", method)

    return router