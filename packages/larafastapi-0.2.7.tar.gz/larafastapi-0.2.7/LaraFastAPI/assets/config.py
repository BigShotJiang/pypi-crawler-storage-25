# application configuration
PROJECT_NAME = "FastAPI-App"
DEBUG = True
SECRET_KEY = "my-secret-key"

# DB configuration
DB_URL = "mysql://root:123456@localhost:3306/msgs"
GENERATE_SCHEMAS = True
ADD_EXCEPTION_HANDLERS = True
MODULES = ["app.models"]
