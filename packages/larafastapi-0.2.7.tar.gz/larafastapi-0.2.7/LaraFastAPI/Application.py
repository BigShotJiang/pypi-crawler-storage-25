from fastapi import FastAPI
from routes.controller import routes as controller_routes
from routes.api import routes as api_routes
from routes.rest import routes as rest_routes
from routes.web import router as web_router
from LaraFastAPI.helpers import controller_router, resource_router
from contextlib import asynccontextmanager
from tortoise.contrib.fastapi import register_tortoise
from config import DB_URL, MODULES, GENERATE_SCHEMAS, ADD_EXCEPTION_HANDLERS

class Application:
    """创建FastAPI应用实例"""
    app = None
    def __init__(self, title: str = "FastAPI MVC Example"):
        # lifespan
        @asynccontextmanager
        async def lifespan(app: FastAPI):
            # 在应用启动时执行的代码（例如连接数据库、加载配置等）
            print("application is starting...")

            # 应用运行中......
            yield

            # 在应用关闭时执行的代码
            print("application is shutting down...")

        # 创建FastAPI应用实例
        self.app = FastAPI(title=title, lifespan=lifespan)

        # 注册Tortoise ORM        
        register_tortoise(
            self.app,
            db_url=DB_URL,
            modules={"models": MODULES},
            generate_schemas=GENERATE_SCHEMAS,
            add_exception_handlers=ADD_EXCEPTION_HANDLERS,
        )

        # 注册web路由
        self.app.include_router(web_router)
        # 注册controller路由
        for router in controller_routes:
            self.app.include_router(controller_router(router[1], router[0]))
        # 注册api路由
        for router in api_routes:
            self.app.include_router(controller_router(router[1], router[0]))
        # 注册rest路由
        for router in rest_routes:
            self.app.include_router(resource_router(router[1], router[0]))
