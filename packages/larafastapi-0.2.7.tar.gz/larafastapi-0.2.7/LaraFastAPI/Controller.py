from LaraFastAPI.helpers import view

class Controller:

    @staticmethod
    def render(htmlfile: str, render_vars: dict = None):
        """渲染HTML视图
        Args:
            htmlfile: HTML模板文件路径，相对于app/views目录，例如"msgs/show.html"
            render_vars: 模板渲染变量字典，例如{"msg": msg}
        Returns:
            HTMLResponse: 渲染后的HTML响应
        """
        return view(htmlfile, render_vars)