# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable
from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["TaskCreateParams"]


class TaskCreateParams(TypedDict, total=False):
    fields: Required[
        Union[
            Dict[
                str,
                Union[
                    str,
                    float,
                    bool,
                    SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                    Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                    None,
                ],
            ]
        ]
    ]
    """Field values for the new task.

    System fields use a `$` prefix (e.g. `$title`, `$status`); custom attributes use
    their bare slug. Required: `$title` (string) and `$status` (one of `TODO`,
    `IN_PROGRESS`, `COMPLETE`, `CANCELLED`). Call the
    <u>[definitions endpoint](/api/resources/task/methods/definitions)</u> to
    discover available fields and options. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Required[Union[Dict[str, Union[str, SequenceNotStr[str]]]]]
    """Relationships to set on the new task.

    System relationships use a `$` prefix (e.g. `$account`, `$assignedTo`); custom
    relationships use their bare slug. `$assignedTo` is required. Each value is a
    single entity ID or an array of IDs. Call the
    <u>[definitions endpoint](/api/resources/task/methods/definitions)</u> to list
    available relationship keys.
    """
