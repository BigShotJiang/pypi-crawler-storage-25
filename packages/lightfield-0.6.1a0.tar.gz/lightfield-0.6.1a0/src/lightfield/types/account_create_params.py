# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable
from typing_extensions import Required, TypedDict

from .._types import SequenceNotStr

__all__ = ["AccountCreateParams"]


class AccountCreateParams(TypedDict, total=False):
    fields: Required[
        Union[
            Dict[
                str,
                Union[
                    str,
                    float,
                    bool,
                    SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                    Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                    None,
                ],
            ]
        ]
    ]
    """Field values for the new account.

    System fields use a `$` prefix (e.g. `$name`, `$website`); custom attributes use
    their bare slug (e.g. `tier`, `renewalDate`). Required: `$name` (string). Fields
    of type `SINGLE_SELECT` or `MULTI_SELECT` accept either an option ID or label
    from the field's `typeConfiguration.options` — call the
    <u>[definitions endpoint](/api/resources/account/methods/definitions)</u> to
    discover available fields and options. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Union[Dict[str, Union[str, SequenceNotStr[str]]]]
    """Relationships to set on the new account.

    System relationships use a `$` prefix (e.g. `$owner`, `$contact`); custom
    relationships use their bare slug. Each value is a single entity ID or an array
    of IDs. Call the
    <u>[definitions endpoint](/api/resources/account/methods/definitions)</u> to
    list available relationship keys.
    """
