# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["OpportunityDefinitionsResponse", "FieldDefinitions", "RelationshipDefinitions"]


class FieldDefinitions(BaseModel):
    description: Optional[str] = None
    """Description of the field, or null."""

    label: str
    """Human-readable display name of the field."""

    type_configuration: Dict[
        str,
        Union[
            str,
            float,
            bool,
            List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
            Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
            None,
        ],
    ] = FieldInfo(alias="typeConfiguration")
    """Type-specific configuration (e.g. select options, currency code)."""

    value_type: Literal[
        "ADDRESS",
        "CHECKBOX",
        "CURRENCY",
        "DATETIME",
        "EMAIL",
        "FULL_NAME",
        "MARKDOWN",
        "MULTI_SELECT",
        "NUMBER",
        "SINGLE_SELECT",
        "SOCIAL_HANDLE",
        "TELEPHONE",
        "TEXT",
        "URL",
    ] = FieldInfo(alias="valueType")
    """Data type of the field."""

    id: Optional[str] = None
    """Unique identifier of the field definition."""

    read_only: Optional[bool] = FieldInfo(alias="readOnly", default=None)
    """`true` for fields that are not writable via the API (e.g.

    AI-generated summaries). `false` or absent for writable fields.
    """


class RelationshipDefinitions(BaseModel):
    cardinality: Literal["HAS_ONE", "HAS_MANY"]
    """Whether this is a `has_one` or `has_many` relationship."""

    description: Optional[str] = None
    """Description of the relationship, or null."""

    label: str
    """Human-readable display name of the relationship."""

    object_type: str = FieldInfo(alias="objectType")
    """The type of the related object (e.g. `account`, `contact`)."""

    id: Optional[str] = None
    """Unique identifier of the relationship definition."""


class OpportunityDefinitionsResponse(BaseModel):
    field_definitions: Dict[str, FieldDefinitions] = FieldInfo(alias="fieldDefinitions")
    """
    Map of field keys to their definitions, including both system and custom fields.
    """

    object_type: str = FieldInfo(alias="objectType")
    """The object type these definitions belong to (e.g. `account`)."""

    relationship_definitions: Dict[str, RelationshipDefinitions] = FieldInfo(alias="relationshipDefinitions")
    """Map of relationship keys to their definitions."""
