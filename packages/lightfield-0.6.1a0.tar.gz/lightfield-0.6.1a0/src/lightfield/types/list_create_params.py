# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Required, Annotated, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "ListCreateParams",
    "Relationships",
    "RelationshipsAccounts",
    "RelationshipsContacts",
    "RelationshipsOpportunities",
]


class ListCreateParams(TypedDict, total=False):
    fields: Required[Union[object]]
    """Field values for the new list. Required: `$name` (string) and `$objectType`."""

    relationships: Relationships
    """Relationships to set on the new list."""


class RelationshipsAccounts(TypedDict, total=False):
    accounts: Required[Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$accounts")]]
    """Account ID(s) to add as initial members. List `$objectType` must be `account`."""


class RelationshipsContacts(TypedDict, total=False):
    contacts: Required[Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$contacts")]]
    """Contact ID(s) to add as initial members. List `$objectType` must be `contact`."""


class RelationshipsOpportunities(TypedDict, total=False):
    opportunities: Required[Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$opportunities")]]
    """Opportunity ID(s) to add as initial members.

    List `$objectType` must be `opportunity`.
    """


Relationships: TypeAlias = Union[RelationshipsAccounts, RelationshipsContacts, RelationshipsOpportunities]
