# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import TYPE_CHECKING, Dict, List, Union, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["AccountRetrieveResponse", "Fields", "Relationships"]


class Fields(BaseModel):
    value: Union[
        str,
        float,
        bool,
        List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        None,
    ] = None
    """The field value, or null if unset."""

    value_type: Literal[
        "ADDRESS",
        "CHECKBOX",
        "CURRENCY",
        "DATETIME",
        "EMAIL",
        "FULL_NAME",
        "MARKDOWN",
        "MULTI_SELECT",
        "NUMBER",
        "SINGLE_SELECT",
        "SOCIAL_HANDLE",
        "TELEPHONE",
        "TEXT",
        "URL",
    ] = FieldInfo(alias="valueType")
    """The data type of the field."""


class Relationships(BaseModel):
    cardinality: str
    """Whether the relationship is `has_one` or `has_many`."""

    object_type: str = FieldInfo(alias="objectType")
    """The type of the related object (e.g. `account`, `contact`)."""

    values: List[str]
    """IDs of the related entities."""


class AccountRetrieveResponse(BaseModel):
    id: str
    """Unique identifier for the entity."""

    created_at: str = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp of when the entity was created."""

    fields: Dict[str, Fields]
    """Map of field names to their typed values.

    System fields are prefixed with `$` (e.g. `$name`, `$email`); custom attributes
    use their bare slug.
    """

    http_link: Optional[str] = FieldInfo(alias="httpLink", default=None)
    """URL to view the entity in the Lightfield web app, or null."""

    relationships: Dict[str, Relationships]
    """Map of relationship names to their associated entities.

    System relationships are prefixed with `$` (e.g. `$owner`, `$contact`).
    """

    updated_at: Optional[str] = FieldInfo(alias="updatedAt", default=None)
    """ISO 8601 timestamp of when the entity was last updated, or null."""

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[
            str,
            Union[
                str,
                float,
                bool,
                List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                None,
            ],
        ] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(
            self, attr: str
        ) -> Union[
            str,
            float,
            bool,
            List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
            Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
            None,
        ]: ...
    else:
        __pydantic_extra__: Dict[
            str,
            Union[
                str,
                float,
                bool,
                List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                None,
            ],
        ]
