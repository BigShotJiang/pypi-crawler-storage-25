# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import TYPE_CHECKING, Dict, List, Union, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ListListResponse", "Data", "DataFields"]


class DataFields(BaseModel):
    value: Union[
        str,
        float,
        bool,
        List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        None,
    ] = None
    """The field value, or null if unset."""

    value_type: Literal[
        "ADDRESS",
        "CHECKBOX",
        "CURRENCY",
        "DATETIME",
        "EMAIL",
        "FULL_NAME",
        "MARKDOWN",
        "MULTI_SELECT",
        "NUMBER",
        "SINGLE_SELECT",
        "SOCIAL_HANDLE",
        "TELEPHONE",
        "TEXT",
        "URL",
    ] = FieldInfo(alias="valueType")
    """The data type of the field."""


class Data(BaseModel):
    id: str
    """Unique identifier for the list."""

    created_at: str = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp of when the list was created."""

    fields: Dict[str, DataFields]
    """Map of field names to their typed values.

    System fields are prefixed with `$` (e.g. `$name`, `$objectType`).
    """

    http_link: Optional[str] = FieldInfo(alias="httpLink", default=None)
    """URL to view the list in the Lightfield web app, or null."""

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[
            str,
            Union[
                str,
                float,
                bool,
                List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                None,
            ],
        ] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(
            self, attr: str
        ) -> Union[
            str,
            float,
            bool,
            List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
            Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
            None,
        ]: ...
    else:
        __pydantic_extra__: Dict[
            str,
            Union[
                str,
                float,
                bool,
                List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                None,
            ],
        ]


class ListListResponse(BaseModel):
    data: List[Data]
    """Array of list objects for the current page."""

    object: str
    """The object type, always `"list"`."""

    total_count: int = FieldInfo(alias="totalCount")
    """Total number of lists matching the query."""
