# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import Required, TypedDict

__all__ = ["NoteCreateParams"]


class NoteCreateParams(TypedDict, total=False):
    fields: Required[Union[object]]
    """Field values for the new note.

    `$title` is required; `$content` is optional. See
    **[Fields and relationships](/using-the-api/fields-and-relationships/)** for
    value type details.
    """

    relationships: Union[object]
    """Relationships to set on the new note.

    System relationships use a `$` prefix (e.g. `$account`, `$opportunity`). Each
    value is a single entity ID or an array of IDs. The note author is automatically
    set to the API key owner.
    """
