# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable
from typing_extensions import TypedDict

from .._types import SequenceNotStr

__all__ = ["AccountUpdateParams", "RelationshipsUnionMember0RelationshipsUnionMember0Item"]


class AccountUpdateParams(TypedDict, total=False):
    fields: Union[
        Dict[
            str,
            Union[
                str,
                float,
                bool,
                SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
                None,
            ],
        ]
    ]
    """
    Field values to update — only provided fields are modified; omitted fields are
    left unchanged. System fields use a `$` prefix (e.g. `$name`); custom attributes
    use their bare slug. `SINGLE_SELECT` and `MULTI_SELECT` fields accept an option
    ID or label — call the
    <u>[definitions endpoint](/api/resources/account/methods/definitions)</u> for
    available options. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Union[Dict[str, RelationshipsUnionMember0RelationshipsUnionMember0Item]]
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$owner`, `$contact`). Each value is
    an operation object with `add`, `remove`, or `replace`.
    """


class RelationshipsUnionMember0RelationshipsUnionMember0Item(TypedDict, total=False):
    """An operation to modify a relationship.

    Provide one of `add`, `remove`, or `replace`.
    """

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """
