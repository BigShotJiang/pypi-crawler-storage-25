# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import TypedDict

__all__ = ["NoteUpdateParams"]


class NoteUpdateParams(TypedDict, total=False):
    fields: Union[object]
    """
    Field values to update — only provided fields are modified; omitted fields are
    left unchanged. See
    **[Fields and relationships](/using-the-api/fields-and-relationships/)** for
    value type details.
    """

    relationships: Union[object]
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$account`, `$opportunity`). Each
    value is an operation object with `add` or `remove`.
    """
