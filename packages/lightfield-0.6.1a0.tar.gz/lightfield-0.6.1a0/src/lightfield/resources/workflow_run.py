# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .._types import Body, Query, Headers, NotGiven, not_given
from .._utils import path_template
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.workflow_run_status_response import WorkflowRunStatusResponse

__all__ = ["WorkflowRunResource", "AsyncWorkflowRunResource"]


class WorkflowRunResource(SyncAPIResource):
    """Workflow runs represent executions of automated workflows."""

    @cached_property
    def with_raw_response(self) -> WorkflowRunResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return WorkflowRunResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> WorkflowRunResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return WorkflowRunResourceWithStreamingResponse(self)

    def status(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WorkflowRunStatusResponse:
        """
        Returns the current status of a workflow run.

        Args:
          run_id: Unique identifier of the workflow run.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        return self._get(
            path_template("/v1/workflowRun/{run_id}/status", run_id=run_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WorkflowRunStatusResponse,
        )


class AsyncWorkflowRunResource(AsyncAPIResource):
    """Workflow runs represent executions of automated workflows."""

    @cached_property
    def with_raw_response(self) -> AsyncWorkflowRunResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return AsyncWorkflowRunResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncWorkflowRunResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return AsyncWorkflowRunResourceWithStreamingResponse(self)

    async def status(
        self,
        run_id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> WorkflowRunStatusResponse:
        """
        Returns the current status of a workflow run.

        Args:
          run_id: Unique identifier of the workflow run.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not run_id:
            raise ValueError(f"Expected a non-empty value for `run_id` but received {run_id!r}")
        return await self._get(
            path_template("/v1/workflowRun/{run_id}/status", run_id=run_id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=WorkflowRunStatusResponse,
        )


class WorkflowRunResourceWithRawResponse:
    def __init__(self, workflow_run: WorkflowRunResource) -> None:
        self._workflow_run = workflow_run

        self.status = to_raw_response_wrapper(
            workflow_run.status,
        )


class AsyncWorkflowRunResourceWithRawResponse:
    def __init__(self, workflow_run: AsyncWorkflowRunResource) -> None:
        self._workflow_run = workflow_run

        self.status = async_to_raw_response_wrapper(
            workflow_run.status,
        )


class WorkflowRunResourceWithStreamingResponse:
    def __init__(self, workflow_run: WorkflowRunResource) -> None:
        self._workflow_run = workflow_run

        self.status = to_streamed_response_wrapper(
            workflow_run.status,
        )


class AsyncWorkflowRunResourceWithStreamingResponse:
    def __init__(self, workflow_run: AsyncWorkflowRunResource) -> None:
        self._workflow_run = workflow_run

        self.status = async_to_streamed_response_wrapper(
            workflow_run.status,
        )
