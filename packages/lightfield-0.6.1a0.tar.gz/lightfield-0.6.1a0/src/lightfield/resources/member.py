# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import member_list_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.member_list_response import MemberListResponse
from ..types.member_retrieve_response import MemberRetrieveResponse

__all__ = ["MemberResource", "AsyncMemberResource"]


class MemberResource(SyncAPIResource):
    """Members represent users in your Lightfield workspace.

    Members can own accounts and opportunities, and are referenced in relationships like `$owner` and `$createdBy`.
    """

    @cached_property
    def with_raw_response(self) -> MemberResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return MemberResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> MemberResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return MemberResourceWithStreamingResponse(self)

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MemberRetrieveResponse:
        """
        Retrieves a single member by their ID.

        **[Required scope](/using-the-api/scopes/):** `members:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the member to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v1/members/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MemberRetrieveResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MemberListResponse:
        """Returns a paginated list of members in your workspace.

        Use `offset` and `limit`
        to paginate through results. See
        <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more information
        about pagination.

        **[Required scope](/using-the-api/scopes/):** `members:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/members",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    member_list_params.MemberListParams,
                ),
            ),
            cast_to=MemberListResponse,
        )


class AsyncMemberResource(AsyncAPIResource):
    """Members represent users in your Lightfield workspace.

    Members can own accounts and opportunities, and are referenced in relationships like `$owner` and `$createdBy`.
    """

    @cached_property
    def with_raw_response(self) -> AsyncMemberResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return AsyncMemberResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncMemberResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return AsyncMemberResourceWithStreamingResponse(self)

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MemberRetrieveResponse:
        """
        Retrieves a single member by their ID.

        **[Required scope](/using-the-api/scopes/):** `members:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the member to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v1/members/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MemberRetrieveResponse,
        )

    async def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MemberListResponse:
        """Returns a paginated list of members in your workspace.

        Use `offset` and `limit`
        to paginate through results. See
        <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more information
        about pagination.

        **[Required scope](/using-the-api/scopes/):** `members:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/members",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    member_list_params.MemberListParams,
                ),
            ),
            cast_to=MemberListResponse,
        )


class MemberResourceWithRawResponse:
    def __init__(self, member: MemberResource) -> None:
        self._member = member

        self.retrieve = to_raw_response_wrapper(
            member.retrieve,
        )
        self.list = to_raw_response_wrapper(
            member.list,
        )


class AsyncMemberResourceWithRawResponse:
    def __init__(self, member: AsyncMemberResource) -> None:
        self._member = member

        self.retrieve = async_to_raw_response_wrapper(
            member.retrieve,
        )
        self.list = async_to_raw_response_wrapper(
            member.list,
        )


class MemberResourceWithStreamingResponse:
    def __init__(self, member: MemberResource) -> None:
        self._member = member

        self.retrieve = to_streamed_response_wrapper(
            member.retrieve,
        )
        self.list = to_streamed_response_wrapper(
            member.list,
        )


class AsyncMemberResourceWithStreamingResponse:
    def __init__(self, member: AsyncMemberResource) -> None:
        self._member = member

        self.retrieve = async_to_streamed_response_wrapper(
            member.retrieve,
        )
        self.list = async_to_streamed_response_wrapper(
            member.list,
        )
