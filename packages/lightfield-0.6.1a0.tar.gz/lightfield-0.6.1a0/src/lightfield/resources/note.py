# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union

import httpx

from ..types import note_list_params, note_create_params, note_update_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template, maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.note_list_response import NoteListResponse
from ..types.note_create_response import NoteCreateResponse
from ..types.note_update_response import NoteUpdateResponse
from ..types.note_retrieve_response import NoteRetrieveResponse

__all__ = ["NoteResource", "AsyncNoteResource"]


class NoteResource(SyncAPIResource):
    """Notes represent free-form text records in Lightfield.

    Each note can be associated with zero or more accounts and opportunities.
    """

    @cached_property
    def with_raw_response(self) -> NoteResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return NoteResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> NoteResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return NoteResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        fields: Union[object],
        relationships: Union[object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NoteCreateResponse:
        """
        Creates a new note record.

        The note author is automatically set to the API key owner.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `notes:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          fields: Field values for the new note. `$title` is required; `$content` is optional. See
              **[Fields and relationships](/using-the-api/fields-and-relationships/)** for
              value type details.

          relationships: Relationships to set on the new note. System relationships use a `$` prefix
              (e.g. `$account`, `$opportunity`). Each value is a single entity ID or an array
              of IDs. The note author is automatically set to the API key owner.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/notes",
            body=maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                note_create_params.NoteCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoteCreateResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NoteRetrieveResponse:
        """
        Retrieves a single note by its ID.

        **[Required scope](/using-the-api/scopes/):** `notes:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the note to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            path_template("/v1/notes/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoteRetrieveResponse,
        )

    def update(
        self,
        id: str,
        *,
        fields: Union[object] | Omit = omit,
        relationships: Union[object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NoteUpdateResponse:
        """Updates an existing note by ID.

        Only included fields and relationships are
        modified.

        Both `$account` and `$opportunity` relationships can be modified via `add` or
        `remove` operations.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `notes:update`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the note to update.

          fields: Field values to update — only provided fields are modified; omitted fields are
              left unchanged. See
              **[Fields and relationships](/using-the-api/fields-and-relationships/)** for
              value type details.

          relationships: Relationship operations to apply. System relationships use a `$` prefix (e.g.
              `$account`, `$opportunity`). Each value is an operation object with `add` or
              `remove`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            path_template("/v1/notes/{id}", id=id),
            body=maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                note_update_params.NoteUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoteUpdateResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NoteListResponse:
        """Returns a paginated list of notes.

        Use `offset` and `limit` to paginate through
        results. See <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more
        information about pagination.

        **[Required scope](/using-the-api/scopes/):** `notes:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/notes",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    note_list_params.NoteListParams,
                ),
            ),
            cast_to=NoteListResponse,
        )


class AsyncNoteResource(AsyncAPIResource):
    """Notes represent free-form text records in Lightfield.

    Each note can be associated with zero or more accounts and opportunities.
    """

    @cached_property
    def with_raw_response(self) -> AsyncNoteResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return AsyncNoteResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncNoteResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return AsyncNoteResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        fields: Union[object],
        relationships: Union[object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NoteCreateResponse:
        """
        Creates a new note record.

        The note author is automatically set to the API key owner.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `notes:create`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          fields: Field values for the new note. `$title` is required; `$content` is optional. See
              **[Fields and relationships](/using-the-api/fields-and-relationships/)** for
              value type details.

          relationships: Relationships to set on the new note. System relationships use a `$` prefix
              (e.g. `$account`, `$opportunity`). Each value is a single entity ID or an array
              of IDs. The note author is automatically set to the API key owner.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/notes",
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                note_create_params.NoteCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoteCreateResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NoteRetrieveResponse:
        """
        Retrieves a single note by its ID.

        **[Required scope](/using-the-api/scopes/):** `notes:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Read

        Args:
          id: Unique identifier of the note to retrieve.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            path_template("/v1/notes/{id}", id=id),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoteRetrieveResponse,
        )

    async def update(
        self,
        id: str,
        *,
        fields: Union[object] | Omit = omit,
        relationships: Union[object] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NoteUpdateResponse:
        """Updates an existing note by ID.

        Only included fields and relationships are
        modified.

        Both `$account` and `$opportunity` relationships can be modified via `add` or
        `remove` operations.

        Supports idempotency via the `Idempotency-Key` header.

        **[Required scope](/using-the-api/scopes/):** `notes:update`

        **[Rate limit category](/using-the-api/rate-limits/):** Write

        Args:
          id: Unique identifier of the note to update.

          fields: Field values to update — only provided fields are modified; omitted fields are
              left unchanged. See
              **[Fields and relationships](/using-the-api/fields-and-relationships/)** for
              value type details.

          relationships: Relationship operations to apply. System relationships use a `$` prefix (e.g.
              `$account`, `$opportunity`). Each value is an operation object with `add` or
              `remove`.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            path_template("/v1/notes/{id}", id=id),
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                note_update_params.NoteUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=NoteUpdateResponse,
        )

    async def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> NoteListResponse:
        """Returns a paginated list of notes.

        Use `offset` and `limit` to paginate through
        results. See <u>[List endpoints](/using-the-api/list-endpoints/)</u> for more
        information about pagination.

        **[Required scope](/using-the-api/scopes/):** `notes:read`

        **[Rate limit category](/using-the-api/rate-limits/):** Search

        Args:
          limit: Maximum number of records to return. Defaults to 25, maximum 25.

          offset: Number of records to skip for pagination. Defaults to 0.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/notes",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    note_list_params.NoteListParams,
                ),
            ),
            cast_to=NoteListResponse,
        )


class NoteResourceWithRawResponse:
    def __init__(self, note: NoteResource) -> None:
        self._note = note

        self.create = to_raw_response_wrapper(
            note.create,
        )
        self.retrieve = to_raw_response_wrapper(
            note.retrieve,
        )
        self.update = to_raw_response_wrapper(
            note.update,
        )
        self.list = to_raw_response_wrapper(
            note.list,
        )


class AsyncNoteResourceWithRawResponse:
    def __init__(self, note: AsyncNoteResource) -> None:
        self._note = note

        self.create = async_to_raw_response_wrapper(
            note.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            note.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            note.update,
        )
        self.list = async_to_raw_response_wrapper(
            note.list,
        )


class NoteResourceWithStreamingResponse:
    def __init__(self, note: NoteResource) -> None:
        self._note = note

        self.create = to_streamed_response_wrapper(
            note.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            note.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            note.update,
        )
        self.list = to_streamed_response_wrapper(
            note.list,
        )


class AsyncNoteResourceWithStreamingResponse:
    def __init__(self, note: AsyncNoteResource) -> None:
        self._note = note

        self.create = async_to_streamed_response_wrapper(
            note.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            note.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            note.update,
        )
        self.list = async_to_streamed_response_wrapper(
            note.list,
        )
