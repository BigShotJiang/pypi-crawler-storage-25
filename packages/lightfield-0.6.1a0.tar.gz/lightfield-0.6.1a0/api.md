# Account

Types:

```python
from lightfield.types import (
    AccountCreateResponse,
    AccountDefinitionsResponse,
    AccountListResponse,
    AccountRetrieveResponse,
    AccountUpdateResponse,
)
```

Methods:

- <code title="post /v1/accounts">client.account.<a href="./src/lightfield/resources/account.py">create</a>(\*\*<a href="src/lightfield/types/account_create_params.py">params</a>) -> <a href="./src/lightfield/types/account_create_response.py">AccountCreateResponse</a></code>
- <code title="get /v1/accounts/{id}">client.account.<a href="./src/lightfield/resources/account.py">retrieve</a>(id) -> <a href="./src/lightfield/types/account_retrieve_response.py">AccountRetrieveResponse</a></code>
- <code title="post /v1/accounts/{id}">client.account.<a href="./src/lightfield/resources/account.py">update</a>(id, \*\*<a href="src/lightfield/types/account_update_params.py">params</a>) -> <a href="./src/lightfield/types/account_update_response.py">AccountUpdateResponse</a></code>
- <code title="get /v1/accounts">client.account.<a href="./src/lightfield/resources/account.py">list</a>(\*\*<a href="src/lightfield/types/account_list_params.py">params</a>) -> <a href="./src/lightfield/types/account_list_response.py">AccountListResponse</a></code>
- <code title="get /v1/accounts/definitions">client.account.<a href="./src/lightfield/resources/account.py">definitions</a>() -> <a href="./src/lightfield/types/account_definitions_response.py">AccountDefinitionsResponse</a></code>

# Contact

Types:

```python
from lightfield.types import (
    ContactCreateResponse,
    ContactDefinitionsResponse,
    ContactListResponse,
    ContactRetrieveResponse,
    ContactUpdateResponse,
)
```

Methods:

- <code title="post /v1/contacts">client.contact.<a href="./src/lightfield/resources/contact.py">create</a>(\*\*<a href="src/lightfield/types/contact_create_params.py">params</a>) -> <a href="./src/lightfield/types/contact_create_response.py">ContactCreateResponse</a></code>
- <code title="get /v1/contacts/{id}">client.contact.<a href="./src/lightfield/resources/contact.py">retrieve</a>(id) -> <a href="./src/lightfield/types/contact_retrieve_response.py">ContactRetrieveResponse</a></code>
- <code title="post /v1/contacts/{id}">client.contact.<a href="./src/lightfield/resources/contact.py">update</a>(id, \*\*<a href="src/lightfield/types/contact_update_params.py">params</a>) -> <a href="./src/lightfield/types/contact_update_response.py">ContactUpdateResponse</a></code>
- <code title="get /v1/contacts">client.contact.<a href="./src/lightfield/resources/contact.py">list</a>(\*\*<a href="src/lightfield/types/contact_list_params.py">params</a>) -> <a href="./src/lightfield/types/contact_list_response.py">ContactListResponse</a></code>
- <code title="get /v1/contacts/definitions">client.contact.<a href="./src/lightfield/resources/contact.py">definitions</a>() -> <a href="./src/lightfield/types/contact_definitions_response.py">ContactDefinitionsResponse</a></code>

# List

Types:

```python
from lightfield.types import (
    ListCreateResponse,
    ListRetrieveResponse,
    ListUpdateResponse,
    ListListResponse,
    ListListAccountsResponse,
    ListListContactsResponse,
    ListListOpportunitiesResponse,
)
```

Methods:

- <code title="post /v1/lists">client.list.<a href="./src/lightfield/resources/list.py">create</a>(\*\*<a href="src/lightfield/types/list_create_params.py">params</a>) -> <a href="./src/lightfield/types/list_create_response.py">ListCreateResponse</a></code>
- <code title="get /v1/lists/{id}">client.list.<a href="./src/lightfield/resources/list.py">retrieve</a>(id) -> <a href="./src/lightfield/types/list_retrieve_response.py">ListRetrieveResponse</a></code>
- <code title="post /v1/lists/{id}">client.list.<a href="./src/lightfield/resources/list.py">update</a>(id, \*\*<a href="src/lightfield/types/list_update_params.py">params</a>) -> <a href="./src/lightfield/types/list_update_response.py">ListUpdateResponse</a></code>
- <code title="get /v1/lists">client.list.<a href="./src/lightfield/resources/list.py">list</a>(\*\*<a href="src/lightfield/types/list_list_params.py">params</a>) -> <a href="./src/lightfield/types/list_list_response.py">ListListResponse</a></code>
- <code title="get /v1/lists/{listId}/accounts">client.list.<a href="./src/lightfield/resources/list.py">list_accounts</a>(list_id, \*\*<a href="src/lightfield/types/list_list_accounts_params.py">params</a>) -> <a href="./src/lightfield/types/list_list_accounts_response.py">ListListAccountsResponse</a></code>
- <code title="get /v1/lists/{listId}/contacts">client.list.<a href="./src/lightfield/resources/list.py">list_contacts</a>(list_id, \*\*<a href="src/lightfield/types/list_list_contacts_params.py">params</a>) -> <a href="./src/lightfield/types/list_list_contacts_response.py">ListListContactsResponse</a></code>
- <code title="get /v1/lists/{listId}/opportunities">client.list.<a href="./src/lightfield/resources/list.py">list_opportunities</a>(list_id, \*\*<a href="src/lightfield/types/list_list_opportunities_params.py">params</a>) -> <a href="./src/lightfield/types/list_list_opportunities_response.py">ListListOpportunitiesResponse</a></code>

# Note

Types:

```python
from lightfield.types import (
    NoteCreateResponse,
    NoteListResponse,
    NoteRetrieveResponse,
    NoteUpdateResponse,
)
```

Methods:

- <code title="post /v1/notes">client.note.<a href="./src/lightfield/resources/note.py">create</a>(\*\*<a href="src/lightfield/types/note_create_params.py">params</a>) -> <a href="./src/lightfield/types/note_create_response.py">NoteCreateResponse</a></code>
- <code title="get /v1/notes/{id}">client.note.<a href="./src/lightfield/resources/note.py">retrieve</a>(id) -> <a href="./src/lightfield/types/note_retrieve_response.py">NoteRetrieveResponse</a></code>
- <code title="post /v1/notes/{id}">client.note.<a href="./src/lightfield/resources/note.py">update</a>(id, \*\*<a href="src/lightfield/types/note_update_params.py">params</a>) -> <a href="./src/lightfield/types/note_update_response.py">NoteUpdateResponse</a></code>
- <code title="get /v1/notes">client.note.<a href="./src/lightfield/resources/note.py">list</a>(\*\*<a href="src/lightfield/types/note_list_params.py">params</a>) -> <a href="./src/lightfield/types/note_list_response.py">NoteListResponse</a></code>

# Opportunity

Types:

```python
from lightfield.types import (
    OpportunityCreateResponse,
    OpportunityDefinitionsResponse,
    OpportunityListResponse,
    OpportunityRetrieveResponse,
    OpportunityUpdateResponse,
)
```

Methods:

- <code title="post /v1/opportunities">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">create</a>(\*\*<a href="src/lightfield/types/opportunity_create_params.py">params</a>) -> <a href="./src/lightfield/types/opportunity_create_response.py">OpportunityCreateResponse</a></code>
- <code title="get /v1/opportunities/{id}">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">retrieve</a>(id) -> <a href="./src/lightfield/types/opportunity_retrieve_response.py">OpportunityRetrieveResponse</a></code>
- <code title="post /v1/opportunities/{id}">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">update</a>(id, \*\*<a href="src/lightfield/types/opportunity_update_params.py">params</a>) -> <a href="./src/lightfield/types/opportunity_update_response.py">OpportunityUpdateResponse</a></code>
- <code title="get /v1/opportunities">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">list</a>(\*\*<a href="src/lightfield/types/opportunity_list_params.py">params</a>) -> <a href="./src/lightfield/types/opportunity_list_response.py">OpportunityListResponse</a></code>
- <code title="get /v1/opportunities/definitions">client.opportunity.<a href="./src/lightfield/resources/opportunity.py">definitions</a>() -> <a href="./src/lightfield/types/opportunity_definitions_response.py">OpportunityDefinitionsResponse</a></code>

# Task

Types:

```python
from lightfield.types import (
    TaskCreateResponse,
    TaskRetrieveResponse,
    TaskUpdateResponse,
    TaskListResponse,
    TaskDefinitionsResponse,
)
```

Methods:

- <code title="post /v1/tasks">client.task.<a href="./src/lightfield/resources/task.py">create</a>(\*\*<a href="src/lightfield/types/task_create_params.py">params</a>) -> <a href="./src/lightfield/types/task_create_response.py">TaskCreateResponse</a></code>
- <code title="get /v1/tasks/{id}">client.task.<a href="./src/lightfield/resources/task.py">retrieve</a>(id) -> <a href="./src/lightfield/types/task_retrieve_response.py">TaskRetrieveResponse</a></code>
- <code title="post /v1/tasks/{id}">client.task.<a href="./src/lightfield/resources/task.py">update</a>(id, \*\*<a href="src/lightfield/types/task_update_params.py">params</a>) -> <a href="./src/lightfield/types/task_update_response.py">TaskUpdateResponse</a></code>
- <code title="get /v1/tasks">client.task.<a href="./src/lightfield/resources/task.py">list</a>(\*\*<a href="src/lightfield/types/task_list_params.py">params</a>) -> <a href="./src/lightfield/types/task_list_response.py">TaskListResponse</a></code>
- <code title="get /v1/tasks/definitions">client.task.<a href="./src/lightfield/resources/task.py">definitions</a>() -> <a href="./src/lightfield/types/task_definitions_response.py">TaskDefinitionsResponse</a></code>

# Member

Types:

```python
from lightfield.types import MemberListResponse, MemberRetrieveResponse
```

Methods:

- <code title="get /v1/members/{id}">client.member.<a href="./src/lightfield/resources/member.py">retrieve</a>(id) -> <a href="./src/lightfield/types/member_retrieve_response.py">MemberRetrieveResponse</a></code>
- <code title="get /v1/members">client.member.<a href="./src/lightfield/resources/member.py">list</a>(\*\*<a href="src/lightfield/types/member_list_params.py">params</a>) -> <a href="./src/lightfield/types/member_list_response.py">MemberListResponse</a></code>

# WorkflowRun

Types:

```python
from lightfield.types import WorkflowRunStatusResponse
```

Methods:

- <code title="get /v1/workflowRun/{runId}/status">client.workflow_run.<a href="./src/lightfield/resources/workflow_run.py">status</a>(run_id) -> <a href="./src/lightfield/types/workflow_run_status_response.py">WorkflowRunStatusResponse</a></code>
