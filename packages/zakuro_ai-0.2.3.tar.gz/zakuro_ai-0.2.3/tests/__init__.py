"""Zakuro test suite."""
