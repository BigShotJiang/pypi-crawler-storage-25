"""CLI entry point: python -m liberty_parser  or  liberty-parser (installed script)."""

import argparse
import sys

from .parser import LP


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="liberty-parser",
        description="Parse a Liberty (.lib) file and print cell/pin data.",
        epilog=(
            "Examples:\n"
            "  liberty-parser cells.lib\n"
            "  liberty-parser cells.lib --cell INV_X1\n"
            "  liberty-parser cells.lib --cell INV_X1 --pins\n"
            "  liberty-parser cells.lib --cells\n"
            "  liberty-parser cells.lib --attr voltage_unit\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("path", help="Path to a .lib Liberty file")
    parser.add_argument(
        "--cells",
        action="store_true",
        help="List all cell names in the library",
    )
    parser.add_argument(
        "--cell", "-c",
        metavar="CELLNAME",
        help="Target a specific cell",
    )
    parser.add_argument(
        "--pins",
        action="store_true",
        help="List pins for the selected cell (requires --cell)",
    )
    parser.add_argument(
        "--attr", "-a",
        metavar="ATTR",
        help="Print a library-level simple attribute (e.g. voltage_unit)",
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Print package version and exit",
    )
    args = parser.parse_args()

    if args.version:
        from liberty_parser import __version__
        print(__version__)
        return

    try:
        lib = LP(args.path)
    except (FileNotFoundError, IOError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    if args.cells:
        for name in lib.get_cell_list():
            print(name)
        return

    if args.attr:
        result = lib.navigate_single('library', args.attr)
        if result is None:
            print(f"Attribute '{args.attr}' not found.", file=sys.stderr)
            sys.exit(1)
        print(f"{args.attr} : {result.get_val()}")
        return

    if args.cell:
        cell = lib.navigate_single('library', f'cell:{args.cell}')
        if cell is None:
            print(f"Cell '{args.cell}' not found.", file=sys.stderr)
            sys.exit(1)
        if args.pins:
            for pin in lib.get_pin_list(cell=args.cell):
                print(pin)
        else:
            pins = lib.get_pin_list(cell=args.cell)
            print(f"{args.cell}: {', '.join(pins)}")
        return

    # Default: print summary
    cells = lib.get_cell_list()
    print(f"Cells ({len(cells)}):")
    for name in cells:
        pins = lib.get_pin_list(cell=name)
        print(f"  {name}: {', '.join(pins)}")


if __name__ == "__main__":
    main()
