"""Core Liberty file parser.

The ``LP`` class parses Liberty (``.lib``) files into an in-memory dictionary
model, supports hierarchical navigation, read-back to file, and in-place edits.

Example::

    from liberty_parser import LP

    lib = LP("cells.lib")
    print(lib.get_cell_list())
    # ['INV_X1', 'AND2_X1']

    inv = lib.navigate_single('library', 'cell:INV_X1')
    print(inv.get_pin_list())
    # ['A', 'ZN']
"""

from __future__ import annotations

import os
import re
from io import StringIO
from typing import Any, Dict, List, Optional, Union

from .utils import colored, warning


# ---------------------------------------------------------------------------
# Internal key-compression maps (keeps the stored dict compact)
# ---------------------------------------------------------------------------

to_dct: Dict[str, str] = {
    'elements': 'E',
    'filename': 'F',
    'template': 'M',
    'name':     'N',
    'parent':   'P',
    'type':     'T',
    'value':    'V',
}

from_dct: Dict[str, str] = {v: k for k, v in to_dct.items()}

to_tmplt: Dict[str, str] = {
    ' ':   's',
    "\t":  't',
    "\n":  'n',
    '{':   'B',
}

from_tmplt: Dict[str, str] = {v: k for k, v in to_tmplt.items()}


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------

class LP:
    """Liberty Parser — the central object for reading, navigating, and editing
    Liberty (``.lib``) files.

    Construction:

    * ``LP()`` — empty object
    * ``LP(filepath)`` — parse a ``.lib`` file
    * ``LP(text_string)`` — parse a Liberty block from a string
    * ``LP(dict_pointer)`` — wrap an existing internal dict (used internally)
    * ``LP(lp_object)`` — shallow copy (shares the same internal dict)
    """

    def __init__(self, arg: Optional[Union[str, dict, "LP"]] = None) -> None:
        if arg is None:
            self.lib_dict: dict = {}
        elif isinstance(arg, str):
            self.lib_dict = LP.parse_liberty(arg)
        elif isinstance(arg, dict):
            self.lib_dict = arg
        elif isinstance(arg, LP):
            self.lib_dict = arg.lib_dict
        else:
            raise TypeError(
                "LP requires a file path string, a Liberty text string, "
                "an internal dict, or an existing LP object."
            )

    # ------------------------------------------------------------------
    # Parsing (file → dict)
    # ------------------------------------------------------------------

    @staticmethod
    def parse_liberty(lib_input: str) -> dict:
        """Parse a Liberty file or Liberty text block into an internal dict.

        Args:
            lib_input: Path to a ``.lib`` file **or** a Liberty text string.

        Returns:
            Internal dictionary representation of the Liberty data.

        Raises:
            FileNotFoundError: If *lib_input* looks like a file path but does
                not exist.
            IOError: If the file exists but cannot be opened.
        """
        lib_dict: dict = {to_dct['elements']: []}

        if os.path.isfile(lib_input):
            try:
                lib_reader = open(lib_input, 'r')
            except IOError as exc:
                raise IOError(f"Could not read file: {lib_input}") from exc
            lib_dict[to_dct['type']] = 'file'
            lib_dict[to_dct['filename']] = lib_input
        elif lib_input.endswith('.lib') or os.sep in lib_input:
            raise FileNotFoundError(f"File not found: {lib_input}")
        else:
            lib_reader = StringIO(lib_input)
            lib_dict[to_dct['type']] = 'block'

        state      = 'template'
        in_quote   = False
        lib_char   = ''
        last_char  = ''
        line_num   = 1
        lib_string: list = []
        indexes    = [0]
        lib_block  = LP()
        block_ptr  = lib_dict

        while True:
            last_char = lib_char
            lib_char  = lib_reader.read(1)
            if not lib_char:
                if to_dct['template'] not in block_ptr:
                    block_ptr[to_dct['template']] = ''
                block_ptr[to_dct['template']] += LP._convert_template(lib_string)
                break

            if lib_char == "\n":
                line_num += 1

            # ---- template state: collect whitespace ----
            if state == 'template':
                if lib_char in (' ', "\t", "\n"):
                    lib_string.append(lib_char)
                    continue
                else:
                    if to_dct['template'] not in block_ptr:
                        block_ptr[to_dct['template']] = ''
                    block_ptr[to_dct['template']] += LP._convert_template(lib_string)
                    lib_string = []
                    state = 'element'

            # ---- comment state (highest priority) ----
            if state == 'comment':
                lib_string.append(lib_char)
                if lib_char == '/' and last_char == '*':
                    lib_block.lib_dict = {
                        to_dct['type']:   'comment',
                        to_dct['value']:  ''.join(lib_string),
                        to_dct['parent']: block_ptr,
                    }
                    block_ptr[to_dct['elements']].append(lib_block)
                    indexes[-1] += 1
                    lib_block  = LP()
                    lib_string = []
                    state = 'template'

            elif in_quote:
                lib_string.append(lib_char)
                if lib_char == '"':
                    in_quote = False

            elif state == 'parens':
                if lib_char == ')':
                    lib_block.lib_dict[to_dct['name']] = ''.join(lib_string)
                    lib_string = []
                    state = 'complex'
                else:
                    lib_string.append(lib_char)

            elif lib_char == ';':
                if state == 'simple':
                    lib_block.lib_dict[to_dct['value']] = ''.join(lib_string)
                elif state == 'complex':
                    lib_block.lib_dict[to_dct['template']] = LP._convert_template(lib_string)
                lib_block.lib_dict[to_dct['parent']] = block_ptr
                block_ptr[to_dct['elements']].append(lib_block)
                block_ptr[to_dct['template']] += 'E' + str(indexes[-1])
                indexes[-1] += 1
                lib_block  = LP()
                lib_string = []
                state = 'template'

            elif lib_char == '}':
                block_ptr = block_ptr[to_dct['parent']]
                indexes.pop()
                block_ptr[to_dct['template']] += 'E' + str(indexes[-1])
                indexes[-1] += 1
                state = 'template'

            elif lib_char == '{':
                if state == 'simple':
                    raise SyntaxError(
                        f"New block opened before previous attribute was closed "
                        f"(missing ';') [line {line_num}]"
                    )
                lib_block.lib_dict[to_dct['elements']] = []
                lib_block.lib_dict[to_dct['parent']]   = block_ptr
                block_ptr[to_dct['elements']].append(lib_block)
                lib_block  = LP()
                block_ptr  = block_ptr[to_dct['elements']][indexes[-1]].lib_dict
                indexes.append(0)
                lib_string.append(lib_char)
                state = 'template'

            elif lib_char == '*':
                if last_char == '/':
                    lib_string = ['/*']
                    state = 'comment'
                    block_ptr[to_dct['template']] += 'E' + str(indexes[-1])
                else:
                    lib_string.append(lib_char)

            elif lib_char == '(':
                if state == 'complex':
                    raise SyntaxError(
                        f"New complex attribute opened before previous one was "
                        f"closed (missing ';') [line {line_num}]"
                    )
                if state == 'simple':
                    lib_string.append(lib_char)
                else:
                    lib_block.lib_dict[to_dct['type']] = ''.join(lib_string)
                    lib_string = []
                    state = 'parens'

            elif lib_char == '"':
                lib_string.append(lib_char)
                in_quote = True

            elif lib_char == ':':
                if state in ('simple', 'complex'):
                    raise SyntaxError(
                        f"New simple attribute opened before previous one was "
                        f"closed (missing ';') [line {line_num}]"
                    )
                lib_block.lib_dict[to_dct['name']] = ''.join(lib_string)
                lib_string = []
                state = 'simple'

            elif lib_char == "\n":
                if state in ('simple', 'complex'):
                    warning(
                        f"Newline (\\n) in {state} attribute before closing ';' "
                        f"[line {line_num}] — only allowed for 3rd-party imports."
                    )
                    if state == 'simple':
                        lib_block.lib_dict[to_dct['value']] = ''.join(lib_string)
                    else:
                        lib_block.lib_dict[to_dct['template']] = LP._convert_template(lib_string)
                    lib_block.lib_dict[to_dct['parent']] = block_ptr
                    block_ptr[to_dct['elements']].append(lib_block)
                    block_ptr[to_dct['template']] += 'E' + str(indexes[-1])
                    indexes[-1] += 1
                    lib_block  = LP()
                    lib_string = []
                    state = 'template'
                lib_string.append(lib_char)

            else:
                lib_string.append(lib_char)

        lib_reader.close()
        return lib_dict

    # ------------------------------------------------------------------
    # Template helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_template(tmplt_string: list) -> str:
        """Compress a list of whitespace/bracket chars into an encoded string."""
        tmplt_cnvrt = ''
        last_char   = ''
        char_cnt    = 1

        for tmplt_char in tmplt_string:
            if last_char:
                if tmplt_char == last_char:
                    char_cnt += 1
                else:
                    if last_char not in to_tmplt:
                        raise ValueError(
                            f"Expected whitespace character, got: {last_char!r}\n"
                            f"Context: {tmplt_string}"
                        )
                    tmplt_cnvrt += to_tmplt[last_char]
                    if char_cnt != 1:
                        tmplt_cnvrt += str(char_cnt)
                    char_cnt = 1
            last_char = tmplt_char

        if last_char:
            if last_char not in to_tmplt:
                raise ValueError(
                    f"Expected whitespace character, got: {last_char!r}\n"
                    f"Context: {tmplt_string}"
                )
            tmplt_cnvrt += to_tmplt[last_char]
            if char_cnt != 1:
                tmplt_cnvrt += str(char_cnt)

        return tmplt_cnvrt

    # ------------------------------------------------------------------
    # Writing (dict → file)
    # ------------------------------------------------------------------

    def write_liberty(self, out_path: str) -> None:
        """Write the parsed Liberty data back to a file, preserving formatting.

        Args:
            out_path: Destination file path.

        Raises:
            ValueError: If this LP object does not represent a file-level dict.
            IOError: If the file cannot be written.
        """
        if (to_dct['type'] not in self.lib_dict) or (self.lib_dict[to_dct['type']] != 'file'):
            raise ValueError("write_liberty() requires an LP object parsed from a file.")
        try:
            lib_fh = open(out_path, 'w')
        except IOError as exc:
            raise IOError(f"Could not write file: {out_path}") from exc

        LP._write_elements(self.lib_dict, lib_fh)
        lib_fh.close()

    @staticmethod
    def _write_elements(dict_to_write: dict, lib_fh: Any) -> None:
        is_file = False

        if to_dct['type'] in dict_to_write:
            if dict_to_write[to_dct['type']] == 'comment':
                lib_fh.write(dict_to_write[to_dct['value']])
                return
            elif dict_to_write[to_dct['type']] == 'file':
                is_file = True
            else:
                lib_fh.write(dict_to_write[to_dct['type']])
                if to_dct['name'] in dict_to_write:
                    lib_fh.write('(' + dict_to_write[to_dct['name']] + ')')
        elif to_dct['name'] in dict_to_write:
            lib_fh.write(dict_to_write[to_dct['name']])

        if to_dct['value'] in dict_to_write:
            lib_fh.write(':' + dict_to_write[to_dct['value']] + ';')
        elif to_dct['template'] in dict_to_write:
            tmplt_items = re.findall(r'(\D\d*)', dict_to_write[to_dct['template']])
            for tmplt_item in tmplt_items:
                item_type = tmplt_item[0]
                item_num  = int(tmplt_item[1:]) if len(tmplt_item) > 1 else 1

                if item_type in from_tmplt:
                    lib_fh.write(from_tmplt[item_type] * item_num)
                elif item_type == to_dct['elements']:
                    LP._write_elements(
                        dict_to_write[to_dct['elements']][item_num].lib_dict, lib_fh
                    )
                else:
                    raise ValueError(
                        f"Unrecognized item in Liberty template: "
                        f"{item_type!r} in {tmplt_item!r}"
                    )

            if is_file:
                return
            if to_dct['elements'] in dict_to_write:
                lib_fh.write('}')
            else:
                lib_fh.write(';')
        else:
            lib_fh.write(';')

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def navigate(
        self,
        *args: str,
        stop_last_at_result: bool = False,
        stop_all_at_result: bool  = False,
    ) -> List["LP"]:
        """Return all LP objects matching a sequence of hierarchical filters.

        Each positional argument is a filter for the next hierarchy level.
        A filter may be:

        * ``"type"`` — match elements whose *type* equals the string.
        * ``"type:name"`` — additionally match on *name* (or *value*).
        * ``"{RE}pattern"`` — use a regex match instead of equality.

        Args:
            *args: One filter string per hierarchy level.
            stop_last_at_result: Stop after the first match at the **last**
                filter (faster for single-result lookups).
            stop_all_at_result: Stop after the first match at **every** filter
                (fastest; use when you know there is exactly one result).

        Returns:
            List of :class:`LP` objects pointing into the parsed dict.
        """
        elements_filtered = [self]
        args_end = len(args) - 1

        for ndx, arg in enumerate(args):
            attr1, attr2 = arg, None
            col_count = arg.count(':')
            if col_count == 1:
                attr1, attr2 = arg.split(':')
            elif col_count > 1:
                raise ValueError(
                    f"LP.navigate() filter may have at most one colon: {arg!r}"
                )

            elements_to_filter: list = []
            for element in elements_filtered:
                if to_dct['elements'] in element.lib_dict:
                    elements_to_filter.extend(element.lib_dict[to_dct['elements']])
                else:
                    elements_to_filter.extend(
                        element.lib_dict[to_dct['parent']][to_dct['elements']]
                    )

            elements_filtered = []
            for element in elements_to_filter:
                if to_dct['type'] in element.lib_dict:
                    if LP._is_val_match(attr1, element.lib_dict[to_dct['type']]):
                        if attr2 is None:
                            elements_filtered.append(element)
                        elif LP._is_val_match(attr2, element.lib_dict[to_dct['name']]):
                            elements_filtered.append(element)
                elif to_dct['name'] in element.lib_dict and LP._is_val_match(
                    attr1, element.lib_dict[to_dct['name']]
                ):
                    if attr2 is None:
                        elements_filtered.append(element)
                    elif LP._is_val_match(attr2, element.lib_dict[to_dct['value']]):
                        elements_filtered.append(element)

                if elements_filtered and (
                    stop_all_at_result or (stop_last_at_result and ndx == args_end)
                ):
                    break

        return [LP(element) for element in elements_filtered]

    def navigate_single(self, *args: str) -> Optional["LP"]:
        """Like :meth:`navigate` but stops at the first result on the last filter.

        Returns:
            The first matching :class:`LP` object, or ``None`` if not found.
        """
        results = self.navigate(*args, stop_last_at_result=True)
        return results[0] if results else None

    def navigate_singles(self, *args: str) -> Optional["LP"]:
        """Like :meth:`navigate` but stops at the first result at every filter
        (fastest single-item lookup).

        Returns:
            The first matching :class:`LP` object, or ``None`` if not found.
        """
        results = self.navigate(*args, stop_all_at_result=True)
        return results[0] if results else None

    def navigate_to_base(self) -> "LP":
        """Walk up all ``parent`` pointers to the file-level root.

        Returns:
            :class:`LP` pointing at the top-level library dict.
        """
        lp_base = LP(self)
        while lp_base.lib_dict.get(to_dct['type']) != 'file':
            if to_dct['parent'] not in lp_base.lib_dict:
                break
            lp_base = LP(lp_base.lib_dict[to_dct['parent']])
        return lp_base

    @staticmethod
    def _is_val_match(val_re: str, val_el: str) -> bool:
        val_el = val_el.strip(' "')
        if val_re == val_el:
            return True
        if val_re.startswith('{RE}') and re.search(val_re[4:], val_el):
            return True
        return False

    # ------------------------------------------------------------------
    # Getters
    # ------------------------------------------------------------------

    def get_type(self) -> str:
        """Return this element's *type* string (stripped of surrounding whitespace/quotes)."""
        return self.lib_dict[to_dct['type']].strip(' "')

    def get_val(self, nav_to: Optional[str] = None) -> Optional[str]:
        """Return the *value* (simple attr) or *name* (complex attr / block) of
        this node, optionally navigating to a child first.

        Args:
            nav_to: Optional single-level navigation filter applied before
                reading.  Equivalent to ``self.navigate_single(nav_to).get_val()``.

        Returns:
            Stripped string value, or ``None`` if the navigation target was not
            found.

        Raises:
            KeyError: If the node has neither a *value* nor a *name* field.
        """
        new_lp = self.navigate_single(nav_to) if nav_to else LP(self)
        if new_lp is None:
            return None
        if to_dct['value'] in new_lp.lib_dict:
            return new_lp.lib_dict[to_dct['value']].strip(' "')
        elif to_dct['name'] in new_lp.lib_dict:
            return new_lp.lib_dict[to_dct['name']].strip(' "')
        raise KeyError("Node has no 'value' or 'name' field to return.")

    def get_vals(self, nav_to: Optional[str] = None) -> Optional[List[str]]:
        """Return a comma-separated value split into a list.

        Args:
            nav_to: Optional navigation filter (see :meth:`get_val`).

        Returns:
            List of value strings, or ``None`` if navigation target not found.

        Raises:
            KeyError: If the node has neither a *value* nor a *name* field.
        """
        new_lp = self.navigate_single(nav_to) if nav_to else LP(self)
        if new_lp is None:
            return None
        if to_dct['value'] in new_lp.lib_dict:
            raw = new_lp.lib_dict[to_dct['value']]
        elif to_dct['name'] in new_lp.lib_dict:
            raw = new_lp.lib_dict[to_dct['name']]
        else:
            raise KeyError("Node has no 'value' or 'name' field to return.")
        return re.sub(r'["\s\\\n]', '', raw).split(',')

    def get_LU_matrix(self, nav_to: Optional[str] = None) -> Optional[List[List[str]]]:
        """Parse a Liberty lookup-table value string into a 2-D matrix.

        Args:
            nav_to: Optional navigation filter (see :meth:`get_val`).

        Returns:
            2-D list of value strings (rows × columns), or ``None`` if not found.

        Raises:
            KeyError: If the node has neither a *value* nor a *name* field.
        """
        new_lp = self.navigate_single(nav_to) if nav_to else LP(self)
        if new_lp is None:
            return None
        if to_dct['value'] in new_lp.lib_dict:
            raw = new_lp.lib_dict[to_dct['value']]
        elif to_dct['name'] in new_lp.lib_dict:
            raw = new_lp.lib_dict[to_dct['name']]
        else:
            raise KeyError("Node has no 'value' or 'name' field to return.")
        raw = re.sub(r'[\s\\\n]', '', raw).strip('"')
        return [row.split(',') for row in raw.split('","')]

    def map_LU_indexes(self) -> dict:
        """Build a transition/load index mapping from all ``*_template`` blocks.

        Assumes that ``variable_*`` attributes containing ``tran``/``time``
        correspond to transition indexes, and those containing ``cap``/``load``
        correspond to load (capacitance) indexes.

        Returns:
            Dict mapping template name → ``{"tran": var_num, "cap": var_num}``.
        """
        lu_indexes: dict = {}
        for lu_tmpl in self.navigate('library', '{RE}_template$'):
            name = lu_tmpl.get_val()
            lu_indexes[name] = {}
            for var in lu_tmpl.navigate('{RE}^variable'):
                var_num = re.sub(r'^[^\d]+(\d+)\s*$', r'\1', var.lib_dict[to_dct['name']])
                var_val = var.get_val()
                if re.search(r'(tran|time)', var_val):
                    lu_indexes[name]['tran'] = var_num
                elif re.search(r'(cap|load)', var_val):
                    lu_indexes[name]['cap'] = var_num
        return lu_indexes

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def set_val(self, arg1: str, arg2: Optional[str] = None) -> None:
        """Set the value of a node, preserving surrounding whitespace/quote formatting.

        Call as ``lp.set_val(new_value)`` or ``lp.set_val(nav_to, new_value)``.

        Args:
            arg1: New value, **or** navigation filter when *arg2* is given.
            arg2: New value when *arg1* is used as a navigation filter.

        Raises:
            KeyError: If the target node has neither a *value* nor a *name* field.
        """
        nav_to  = None
        new_val = arg1
        if arg2 is not None:
            nav_to  = arg1
            new_val = arg2

        new_lp = self.navigate_single(nav_to) if nav_to else LP(self)
        if to_dct['value'] in new_lp.lib_dict:
            key = 'value'
        elif to_dct['name'] in new_lp.lib_dict:
            key = 'name'
        else:
            raise KeyError("Node has no 'value' or 'name' field to set.")
        old_val = new_lp.lib_dict[to_dct[key]]
        new_lp.lib_dict[to_dct[key]] = re.sub(
            r'^(\s*"?\s*).*?(\s*"?\s*)$',
            r'\g<1>' + str(new_val) + r'\g<2>',
            old_val,
        )

    def set_vals(self, arg1: Any, arg2: Any = None) -> None:
        """Replace a comma-separated value list with a new list, keeping formatting.

        Call as ``lp.set_vals(new_list)`` or ``lp.set_vals(nav_to, new_list)``.

        Args:
            arg1: New value list, **or** navigation filter when *arg2* is given.
            arg2: New value list when *arg1* is used as a navigation filter.

        Raises:
            KeyError: If the target node has neither a *value* nor a *name* field.
        """
        nav_to   = None
        new_vals = arg1
        if arg2 is not None:
            nav_to   = arg1
            new_vals = arg2

        new_lp = self.navigate_single(nav_to) if nav_to else LP(self)
        if to_dct['value'] in new_lp.lib_dict:
            key = 'value'
        elif to_dct['name'] in new_lp.lib_dict:
            key = 'name'
        else:
            raise KeyError("Node has no 'value' or 'name' field to set.")

        parts    = re.split(r"[\d\.e\-]+", new_lp.lib_dict[to_dct[key]])
        new_str  = ''
        for ndx, part in enumerate(parts):
            new_str += part
            if ndx != len(parts) - 1:
                new_str += str(new_vals[ndx])
        new_lp.lib_dict[to_dct[key]] = new_str

    def set_LU_matrix(self, arg1: Any, arg2: Any = None) -> None:
        """Replace a lookup-table 2-D matrix, keeping surrounding formatting.

        Call as ``lp.set_LU_matrix(matrix)`` or ``lp.set_LU_matrix(nav_to, matrix)``.

        Args:
            arg1: 2-D list of new values, **or** navigation filter when *arg2* is
                given.
            arg2: 2-D list of new values when *arg1* is used as a navigation filter.

        Raises:
            KeyError: If the target node has neither a *value* nor a *name* field.
        """
        nav_to        = None
        new_lu_matrix = arg1
        if arg2 is not None:
            nav_to        = arg1
            new_lu_matrix = arg2

        new_lp = self.navigate_single(nav_to) if nav_to else LP(self)
        if to_dct['value'] in new_lp.lib_dict:
            key = 'value'
        elif to_dct['name'] in new_lp.lib_dict:
            key = 'name'
        else:
            raise KeyError("Node has no 'value' or 'name' field to set.")

        flat  = [item for row in new_lu_matrix for item in row]
        parts = re.split(r"[\d\.e\-]+", new_lp.lib_dict[to_dct[key]])
        new_str = ''
        for ndx, part in enumerate(parts):
            new_str += part
            if ndx != len(parts) - 1:
                new_str += str(flat[ndx])
        new_lp.lib_dict[to_dct[key]] = new_str

    # ------------------------------------------------------------------
    # Block manipulation
    # ------------------------------------------------------------------

    def add_simple(self, simple_name: str, simple_value: str, insert_ndx: Any = 0) -> None:
        """Insert a new ``name : value;`` simple attribute into this block.

        Args:
            simple_name:  Attribute name (e.g. ``"time_unit"``).
            simple_value: Attribute value (e.g. ``"1ns"``).
            insert_ndx:   Position index, negative int, or ``"last"``.
        """
        if insert_ndx == 'last' or (isinstance(insert_ndx, int) and insert_ndx < 0):
            insert_ndx = self._convert_index(insert_ndx)
        lp_block = LP({
            to_dct['name']:  str(simple_name) + ' ',
            to_dct['value']: ' ' + str(simple_value) + ' ',
        })
        self.lib_dict[to_dct['elements']].insert(insert_ndx, lp_block)
        self._template_insert(insert_ndx)

    def add_complex(self, complex_type: str, complex_name: str, insert_ndx: Any = 0) -> None:
        """Insert a new ``type(name);`` complex attribute into this block.

        Args:
            complex_type: Attribute type keyword (e.g. ``"related_pin"``).
            complex_name: Attribute name/value inside the parentheses.
            insert_ndx:   Position index, negative int, or ``"last"``.
        """
        if insert_ndx == 'last' or (isinstance(insert_ndx, int) and insert_ndx < 0):
            insert_ndx = self._convert_index(insert_ndx)
        lp_block = LP({
            to_dct['type']:     complex_type,
            to_dct['name']:     complex_name,
            to_dct['template']: '',
        })
        self.lib_dict[to_dct['elements']].insert(insert_ndx, lp_block)
        self._template_insert(insert_ndx)

    def add_blocks(self, blocks_input: Any, insert_ndx: Any = 0) -> None:
        """Parse a Liberty text string or file and insert all top-level elements.

        Args:
            blocks_input: Liberty file path or text string (not an LP object).
            insert_ndx:   Starting insertion index, negative int, or ``"last"``.

        Raises:
            TypeError: If *blocks_input* is an LP object.
        """
        if isinstance(blocks_input, LP):
            raise TypeError("add_blocks() requires a file path or text string, not an LP object.")
        if insert_ndx == 'last' or (isinstance(insert_ndx, int) and insert_ndx < 0):
            insert_ndx = self._convert_index(insert_ndx)
        lp_blocks = LP.parse_liberty(blocks_input)
        for ndx, lp_block in enumerate(lp_blocks[to_dct['elements']]):
            self.add_block(lp_block, insert_ndx=insert_ndx + ndx)

    def add_block(self, lp_block: "LP", insert_ndx: Any = 0) -> None:
        """Insert an existing LP block element into this block.

        Args:
            lp_block:   An :class:`LP` object to insert.
            insert_ndx: Position index, negative int, or ``"last"``.

        Raises:
            TypeError: If *lp_block* is not an LP object.
        """
        if not isinstance(lp_block, LP):
            raise TypeError("add_block() requires an LP object.")
        if insert_ndx == 'last' or (isinstance(insert_ndx, int) and insert_ndx < 0):
            insert_ndx = self._convert_index(insert_ndx)

        self.lib_dict[to_dct['elements']].insert(insert_ndx, lp_block)
        self._template_insert(insert_ndx)

        if is_block(lp_block):
            self_m  = re.search(r"n([st\d]+)E", self.lib_dict[to_dct['template']])
            block_m = re.search(
                r"n([st\d]+)E",
                self.lib_dict[to_dct['elements']][insert_ndx].lib_dict.get(to_dct['template'], ''),
            )
            self_indent  = self_m[1]  if self_m  else ''
            block_indent = block_m[1] if block_m else ''

            if not self_indent:
                return
            if not block_indent or LP._indent_greater_than(self_indent, block_indent):
                old_t = self.lib_dict[to_dct['elements']][insert_ndx].lib_dict[to_dct['template']]
                self.lib_dict[to_dct['elements']][insert_ndx].lib_dict[to_dct['template']] = (
                    old_t.replace('E', f'{self_indent}E') + self_indent
                )

    def remove_block(self, remove_ndx: Optional[int] = None) -> None:
        """Remove a block element from this LP node.

        Args:
            remove_ndx: Index of the element inside *this* block to remove.
                        If ``None``, removes *this* node from its parent.
        """
        if remove_ndx is not None:
            del self.lib_dict[to_dct['elements']][remove_ndx]
            self._template_remove(remove_ndx)
        else:
            self.lib_dict['to_remove'] = True
            parent = LP(self.lib_dict[to_dct['parent']])
            for ndx in range(len(parent.lib_dict[to_dct['elements']])):
                if 'to_remove' in parent.lib_dict[to_dct['elements']][ndx].lib_dict:
                    del parent.lib_dict[to_dct['elements']][ndx]
                    parent._template_remove(ndx)
                    break

    def move_block(self, from_index: int, to_index: int) -> None:
        """Move an element from one position to another inside this block.

        Args:
            from_index: Current index of the element.
            to_index:   Destination index.

        Raises:
            IndexError: If either index exceeds the element count.
        """
        max_index = len(self.lib_dict[to_dct['elements']]) - 1
        if from_index > max_index:
            raise IndexError(f"from_index {from_index} > max index {max_index}")
        if to_index > max_index:
            raise IndexError(f"to_index {to_index} > max index {max_index}")
        block = self.lib_dict[to_dct['elements']].pop(from_index)
        self.lib_dict[to_dct['elements']].insert(to_index, block)

    def merge_blocks(self, blocks_input: Any) -> None:
        """Merge elements from another Liberty block into this one.

        * Simple/complex attributes are **replaced** if they already exist, or
          **inserted** after the last attribute of the same type.
        * Named blocks are merged **recursively**.
        * Unnamed blocks are compared by their simple/complex attributes; if a
          duplicate is found it is replaced, otherwise it is inserted.
        * Comments are inserted after other attribute types.

        Args:
            blocks_input: Liberty file path, text string, or :class:`LP` object.
        """
        self_blocks = LP(self) if isinstance(self, LP) else LP(self)
        lp_blocks   = blocks_input if isinstance(blocks_input, LP) else LP(blocks_input)

        last_ndx = {'comment': -1, 'simple': -1, 'complex': -1, 'block': {None: 'last'}}
        none_blocks: list = []
        merge_with: dict = {
            'comment': {}, 'simple': {}, 'complex_sngl': {}, 'complex_mult': {}, 'block': {}
        }

        for ndx, element in enumerate(self_blocks.lib_dict[to_dct['elements']]):
            if is_comment(element):
                tag = element.lib_dict[to_dct['value']]
                if tag in merge_with['comment']:
                    raise ValueError(f"Duplicate comment: {tag!r}")
                merge_with['comment'][tag] = ndx
                last_ndx['comment'] = ndx

            elif is_simple_attribute(element):
                tag = element.lib_dict[to_dct['name']]
                if tag in merge_with['simple']:
                    raise ValueError(f"Duplicate simple attribute: {tag!r}")
                merge_with['simple'][tag] = ndx
                last_ndx['simple'] = ndx

            elif is_complex_attribute(element):
                tag       = element.lib_dict[to_dct['type']]
                first_val = LP._first_of_mult(element.lib_dict[to_dct['name']])
                if first_val and tag != 'values':
                    full_tag = f"{tag}__{first_val}"
                    if full_tag in merge_with['complex_mult']:
                        raise ValueError(f"Duplicate complex attribute: {full_tag!r}")
                    merge_with['complex_mult'][full_tag] = ndx
                else:
                    if tag in merge_with['complex_sngl']:
                        raise ValueError(f"Duplicate complex attribute: {tag!r}")
                    merge_with['complex_sngl'][tag] = ndx
                last_ndx['complex'] = ndx

            elif is_block(element):
                tag  = element.lib_dict[to_dct['type']]
                name = element.lib_dict[to_dct['name']]
                last_ndx['block'][tag] = ndx
                last_ndx['block'][None] = ndx
                if name == '':
                    none_blocks.append(ndx)
                else:
                    full_tag = f"{tag}__{name}"
                    if full_tag in merge_with['block']:
                        raise ValueError(f"Duplicate block: {full_tag!r}")
                    merge_with['block'][full_tag] = ndx

        if last_ndx['block'][None] == 'last':
            last_ndx['block'][None] = self._convert_index('last') - 1

        for element in lp_blocks.lib_dict[to_dct['elements']]:
            if is_comment(element):
                tag = element.lib_dict[to_dct['value']]
                if tag not in merge_with['comment']:
                    ndx = last_ndx['comment']
                    if ndx == -1: ndx = last_ndx['simple']
                    if ndx == -1: ndx = last_ndx['complex']
                    self.add_block(element, insert_ndx=ndx + 1)
                    LP._update_ndxs(last_ndx, none_blocks, merge_with, ndx)

            elif is_simple_attribute(element):
                tag = element.lib_dict[to_dct['name']]
                if tag in merge_with['simple']:
                    ndx = merge_with['simple'][tag]
                    self.lib_dict[to_dct['elements']][ndx].lib_dict[to_dct['value']] = (
                        element.lib_dict[to_dct['value']]
                    )
                else:
                    ndx = last_ndx['simple']
                    self.add_block(element, insert_ndx=ndx + 1)
                    LP._update_ndxs(last_ndx, none_blocks, merge_with, ndx)

            elif is_complex_attribute(element):
                tag       = element.lib_dict[to_dct['type']]
                first_val = LP._first_of_mult(element.lib_dict[to_dct['name']])
                if first_val and tag != 'values':
                    full_tag = f"{tag}__{first_val}"
                    if full_tag in merge_with['complex_mult']:
                        ndx = merge_with['complex_mult'][full_tag]
                        self.lib_dict[to_dct['elements']][ndx].lib_dict[to_dct['name']] = (
                            element.lib_dict[to_dct['name']]
                        )
                    else:
                        ndx = last_ndx['complex']
                        self.add_block(element, insert_ndx=ndx + 1)
                        LP._update_ndxs(last_ndx, none_blocks, merge_with, ndx)
                else:
                    if tag in merge_with['complex_sngl']:
                        ndx = merge_with['complex_sngl'][tag]
                        self.lib_dict[to_dct['elements']][ndx].lib_dict[to_dct['name']] = (
                            element.lib_dict[to_dct['name']]
                        )
                    else:
                        ndx = last_ndx['complex']
                        self.add_block(element, insert_ndx=ndx + 1)
                        LP._update_ndxs(last_ndx, none_blocks, merge_with, ndx)
                    merge_with['complex_sngl'][tag] = ndx

            elif is_block(element):
                tag  = element.lib_dict[to_dct['type']]
                name = element.lib_dict[to_dct['name']]
                ndx  = last_ndx['block'].get(tag, last_ndx['block'][None])
                if name == '':
                    duplicate = next(
                        (i for i in none_blocks if LP._similar_blocks(element, self.lib_dict[to_dct['elements']][i])),
                        None,
                    )
                    if duplicate is None:
                        self.add_block(element, insert_ndx=ndx + 1)
                        LP._update_ndxs(last_ndx, none_blocks, merge_with, ndx)
                    else:
                        self.lib_dict[to_dct['elements']][duplicate] = element
                else:
                    full_tag = f"{tag}__{name}"
                    if full_tag in merge_with['block']:
                        ndx = merge_with['block'][full_tag]
                        LP.merge_blocks(self.lib_dict[to_dct['elements']][ndx], element)
                    else:
                        self.add_block(element, insert_ndx=ndx + 1)
                        LP._update_ndxs(last_ndx, none_blocks, merge_with, ndx)

    # ------------------------------------------------------------------
    # Convenience helpers (common Liberty operations)
    # ------------------------------------------------------------------

    def get_cell_list(self) -> List[str]:
        """Return a list of all cell names in the library.

        Returns:
            List of cell-name strings.
        """
        base = self.navigate_to_base()
        return [lp_cell.get_val() for lp_cell in base.navigate('library', 'cell')]

    def get_pin_list(self, cell: Optional[str] = None):
        """Return pin names for one cell, the current cell block, or all cells.

        Args:
            cell: Cell name to look up.  If ``None`` and this LP points at a
                  ``cell`` block, returns pins for that cell.  If ``None`` and
                  this LP is at the library root, returns a dict mapping every
                  cell name to its pin list.

        Returns:
            * ``list[str]`` when a specific cell is queried.
            * ``dict[str, list[str]]`` when called without arguments at the
              library root.
        """
        if cell is not None:
            base   = self.navigate_to_base()
            lp_cell = base.navigate_single('library', f'cell:{cell}')
            return [lp_pin.get_val() for lp_pin in lp_cell.navigate('{RE}pg_pin|pin')]

        if self.lib_dict.get(to_dct['type'], '').strip(' "') == 'cell':
            return [lp_pin.get_val() for lp_pin in self.navigate('{RE}pg_pin|pin')]

        base = self.navigate_to_base()
        pins: dict = {}
        for lp_cell in base.navigate('library', 'cell'):
            name = lp_cell.get_val()
            pins[name] = [lp_pin.get_val() for lp_pin in lp_cell.navigate('{RE}pg_pin|pin')]
        return pins

    # ------------------------------------------------------------------
    # Debug / printing
    # ------------------------------------------------------------------

    def print(self, indent: int = 0) -> None:
        """Pretty-print the internal dict as indented JSON-like output."""
        print('   ' * indent + '{')
        to_print = self.lib_dict if isinstance(self, LP) else self

        for dict_ndx, (key, val) in enumerate(to_print.items()):
            if dict_ndx:
                print(',')
            display_key = from_dct.get(key, key)
            if display_key == 'parent':
                print('   ' * (indent + 1) + '"' + colored('parent', 'red') + '" :', colored('{...}', 'blue'), end='')
                continue
            print('   ' * (indent + 1) + '"' + colored(str(display_key), 'red') + '" : ', end='')
            if isinstance(val, str):
                val = val.replace('"', '\\"')
                print('"' + colored(str(val), 'red') + '"', end='')
            elif isinstance(val, dict):
                LP.print(val, indent + 1)
            elif isinstance(val, list):
                print('[')
                for list_ndx, item in enumerate(val):
                    if list_ndx:
                        print(',')
                    LP.print(item, indent + 2)
                print("\n" + '   ' * (indent + 1) + ']', end='')
            else:
                print('"' + colored(str(val), 'red') + '"', end='')

        print("\n" + '   ' * indent + '}', end='')

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _update_ndxs(last_ndx, none_blocks, merge_with, update_from):
        for key in ('comment', 'simple', 'complex'):
            if last_ndx[key] != 'last' and last_ndx[key] > update_from:
                last_ndx[key] += 1
        for key in last_ndx['block']:
            if last_ndx['block'][key] != 'last' and last_ndx['block'][key] > update_from:
                last_ndx['block'][key] += 1
        for i in range(len(none_blocks)):
            if none_blocks[i] > update_from:
                none_blocks[i] += 1
        for category in merge_with:
            for tag in merge_with[category]:
                if merge_with[category][tag] > update_from:
                    merge_with[category][tag] += 1

    @staticmethod
    def _first_of_mult(complex_name: str) -> Optional[str]:
        if '"' in complex_name:
            parts = re.findall(r'("[^"]*")', complex_name)
            return parts[0] if parts else None
        if ',' in complex_name:
            return complex_name.split(',')[0]
        return None

    @staticmethod
    def _indent_greater_than(indent1: str, indent2: str) -> bool:
        if indent1 == indent2:
            return False
        spaces: dict = {indent1: 0, indent2: 0}
        for indent in (indent1, indent2):
            for item in re.findall(r'(\D\d*)', indent):
                if item.startswith('s'):
                    spaces[indent] += int(item[1:]) if len(item) > 1 else 1
                else:
                    spaces[indent] += (int(item[1:]) if len(item) > 1 else 1) * 2
        return spaces[indent1] > spaces[indent2]

    def _template_insert(self, insert_ndx: int) -> None:
        tmplt_items = re.findall(r'(\D\d*)', self.lib_dict[to_dct['template']])
        new_piece   = ''
        inserted    = False

        for i, item in enumerate(tmplt_items):
            if not inserted:
                if item.startswith('n'):
                    new_piece = ''
                elif item == 'E' + str(insert_ndx):
                    tmplt_items[i] = item + 'sn' + new_piece + 'E' + str(insert_ndx + 1)
                    inserted = True
                else:
                    new_piece += item
            else:
                if item.startswith('E'):
                    tmplt_items[i] = 'E' + str(int(item[1:]) + 1)

        if not inserted:
            tmplt_items[-1] += 's2E' + str(insert_ndx) + 'sn' + new_piece

        self.lib_dict[to_dct['template']] = ''.join(tmplt_items)

    def _template_remove(self, ndx: int) -> None:
        tmplt_items   = re.findall(r'(\D\d*)', self.lib_dict[to_dct['template']])
        start_remove  = False
        done_remove   = False
        last_indent   = ''

        for i, item in enumerate(tmplt_items):
            if not start_remove:
                if item == 'E' + str(ndx):
                    tmplt_items[i] = ''
                    start_remove = True
            else:
                if item.startswith('E'):
                    tmplt_items[i] = 'E' + str(int(item[1:]) - 1)
                    done_remove = True
                elif not done_remove:
                    tmplt_items[i] = ''
                    if item.startswith('n'):
                        last_indent = ''
                    else:
                        last_indent += item

        new_template = ''.join(tmplt_items)
        if not done_remove:
            new_template = re.sub(r's\d+$', '', new_template) + last_indent
        self.lib_dict[to_dct['template']] = new_template

    def _convert_index(self, ndx: Any) -> int:
        last_ndx = int(re.findall(r"E(\d+)", self.lib_dict[to_dct['template']])[-1])
        if ndx == 'last':
            return last_ndx + 1
        return last_ndx + int(ndx) + 1

    @staticmethod
    def _similar_blocks(block1: "LP", block2: "LP") -> bool:
        if block1.lib_dict[to_dct['type']] != block2.lib_dict[to_dct['type']]:
            return False
        comp: list = [{'simple': {}, 'complx': {}}, {'simple': {}, 'complx': {}}]
        for bi, block in enumerate((block1, block2)):
            for element in block.lib_dict[to_dct['elements']]:
                if is_simple_attribute(element):
                    n = element.lib_dict[to_dct['name']]
                    v = element.lib_dict[to_dct['value']]
                    if not re.search(r'^value', n, flags=re.I):
                        comp[bi]['simple'][n] = v
                elif is_complex_attribute(element):
                    t = element.lib_dict[to_dct['type']]
                    n = element.lib_dict[to_dct['name']]
                    if not re.search(r'^value', t, flags=re.I):
                        comp[bi]['complx'][t] = n
        for key in ('simple', 'complx'):
            for attr in comp[0][key]:
                if attr not in comp[1][key] or comp[0][key][attr] != comp[1][key][attr]:
                    return False
            for attr in comp[1][key]:
                if attr not in comp[0][key]:
                    return False
        return True


# ---------------------------------------------------------------------------
# Module-level element-type predicates
# ---------------------------------------------------------------------------

def is_comment(element: LP) -> bool:
    """Return ``True`` if *element* is a Liberty comment block."""
    d = element.lib_dict
    if to_dct['name'] in d or to_dct['elements'] in d:
        return False
    if to_dct['type'] in d and to_dct['value'] in d:
        return True
    raise ValueError(f"Cannot categorize element as comment:\n{element.lib_dict}")


def is_simple_attribute(element: LP) -> bool:
    """Return ``True`` if *element* is a simple ``name : value;`` attribute."""
    d = element.lib_dict
    if to_dct['type'] in d or to_dct['elements'] in d:
        return False
    if to_dct['name'] in d and to_dct['value'] in d:
        return True
    raise ValueError(f"Cannot categorize element as simple attribute:\n{element.lib_dict}")


def is_complex_attribute(element: LP) -> bool:
    """Return ``True`` if *element* is a complex ``type(name);`` attribute."""
    d = element.lib_dict
    if to_dct['value'] in d or to_dct['elements'] in d:
        return False
    if to_dct['type'] in d and to_dct['name'] in d:
        return True
    raise ValueError(f"Cannot categorize element as complex attribute:\n{element.lib_dict}")


def is_block(element: LP) -> bool:
    """Return ``True`` if *element* is a hierarchical block (``type(name) {{ … }}``)."""
    d = element.lib_dict
    if to_dct['value'] in d or to_dct['elements'] not in d:
        return False
    if to_dct['type'] in d and to_dct['name'] in d:
        return True
    raise ValueError(f"Cannot categorize element as block:\n{element.lib_dict}")
