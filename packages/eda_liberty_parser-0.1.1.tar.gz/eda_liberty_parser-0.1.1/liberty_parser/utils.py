"""Utility helpers for liberty_parser."""

from __future__ import annotations

try:
    from termcolor import colored
except ImportError:
    def colored(text, color=None, **kwargs):  # type: ignore[misc]
        return text


def warning(message: str) -> None:
    """Print a yellow warning message (requires ``termcolor``; graceful fallback)."""
    print(colored(f"WARNING: {message}", "yellow"))


def error(message: str) -> None:
    """Print a red error message (requires ``termcolor``; graceful fallback)."""
    print(colored(f"ERROR: {message}", "red"))
