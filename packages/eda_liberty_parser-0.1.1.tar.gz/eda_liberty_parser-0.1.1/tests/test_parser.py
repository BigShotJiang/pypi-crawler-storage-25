"""Tests for liberty_parser."""

import os
import tempfile
import pytest

from liberty_parser import (
    LP,
    is_comment,
    is_simple_attribute,
    is_complex_attribute,
    is_block,
)

SAMPLE_LIB = os.path.join(os.path.dirname(__file__), "sample.lib")


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def lib():
    return LP(SAMPLE_LIB)


# ---------------------------------------------------------------------------
# Basic parsing
# ---------------------------------------------------------------------------

class TestBasicParsing:
    def test_returns_lp_instance(self, lib):
        assert isinstance(lib, LP)

    def test_lib_dict_populated(self, lib):
        assert lib.lib_dict

    def test_type_is_file(self, lib):
        from liberty_parser.parser import to_dct
        assert lib.lib_dict[to_dct['type']] == 'file'

    def test_filename_stored(self, lib):
        from liberty_parser.parser import to_dct
        assert lib.lib_dict[to_dct['filename']] == SAMPLE_LIB

    def test_elements_present(self, lib):
        from liberty_parser.parser import to_dct
        assert len(lib.lib_dict[to_dct['elements']]) > 0


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrors:
    def test_missing_file_raises(self):
        with pytest.raises(FileNotFoundError):
            LP("/nonexistent/path/cells.lib")

    def test_bad_type_raises(self):
        with pytest.raises(TypeError):
            LP(12345)

    def test_navigate_bad_filter_raises(self, lib):
        with pytest.raises(ValueError, match="at most one colon"):
            lib.navigate("a:b:c")

    def test_write_non_file_raises(self):
        lp = LP()
        with pytest.raises(ValueError, match="parsed from a file"):
            lp.write_liberty("/tmp/out.lib")

    def test_add_blocks_lp_raises(self, lib):
        cell = lib.navigate_single('library', 'cell:INV_X1')
        with pytest.raises(TypeError, match="file path or text string"):
            lib.add_blocks(cell)

    def test_add_block_non_lp_raises(self, lib):
        with pytest.raises(TypeError, match="LP object"):
            lib.navigate_single('library').add_block("not an LP")


# ---------------------------------------------------------------------------
# Navigation — navigate()
# ---------------------------------------------------------------------------

class TestNavigate:
    def test_find_library(self, lib):
        results = lib.navigate('library')
        assert len(results) == 1
        assert results[0].get_type() == 'library'

    def test_find_all_cells(self, lib):
        cells = lib.navigate('library', 'cell')
        assert len(cells) == 3

    def test_find_specific_cell(self, lib):
        cells = lib.navigate('library', 'cell:INV_X1')
        assert len(cells) == 1
        assert cells[0].get_val() == 'INV_X1'

    def test_find_pins_of_cell(self, lib):
        pins = lib.navigate('library', 'cell:AND2_X1', 'pin')
        assert {p.get_val() for p in pins} == {'A1', 'A2', 'Z'}

    def test_regex_filter(self, lib):
        templates = lib.navigate('library', '{RE}_template$')
        assert len(templates) >= 1

    def test_no_match_returns_empty(self, lib):
        result = lib.navigate('library', 'cell:NONEXISTENT')
        assert result == []


# ---------------------------------------------------------------------------
# Navigation — navigate_single / navigate_singles
# ---------------------------------------------------------------------------

class TestNavigateSingle:
    def test_returns_first_match(self, lib):
        result = lib.navigate_single('library', 'cell')
        assert result is not None
        assert isinstance(result, LP)

    def test_returns_none_on_no_match(self, lib):
        result = lib.navigate_single('library', 'cell:GHOST')
        assert result is None

    def test_navigate_singles_returns_lp(self, lib):
        result = lib.navigate_singles('library', 'cell:INV_X1')
        assert result is not None


# ---------------------------------------------------------------------------
# navigate_to_base
# ---------------------------------------------------------------------------

class TestNavigateToBase:
    def test_returns_file_root(self, lib):
        from liberty_parser.parser import to_dct
        inv = lib.navigate_single('library', 'cell:INV_X1')
        base = inv.navigate_to_base()
        assert base.lib_dict[to_dct['type']] == 'file'


# ---------------------------------------------------------------------------
# get_val / get_vals / get_type
# ---------------------------------------------------------------------------

class TestGetters:
    def test_get_val_simple(self, lib):
        result = lib.navigate_single('library', 'time_unit')
        assert result.get_val() == '1ns'

    def test_get_val_with_nav_to(self, lib):
        library = lib.navigate_single('library')
        val = library.get_val('voltage_unit')
        assert val == '1V'

    def test_get_val_returns_none_on_miss(self, lib):
        library = lib.navigate_single('library')
        assert library.get_val('nonexistent_attr') is None

    def test_get_val_cell_name(self, lib):
        cell = lib.navigate_single('library', 'cell:AND2_X1')
        assert cell.get_val() == 'AND2_X1'

    def test_get_type(self, lib):
        cell = lib.navigate_single('library', 'cell:INV_X1')
        assert cell.get_type() == 'cell'

    def test_get_vals_splits_comma_list(self, lib):
        idx = lib.navigate_single('library', '{RE}_template$', '{RE}^index_1')
        vals = idx.get_vals()
        assert len(vals) == 3


# ---------------------------------------------------------------------------
# get_cell_list / get_pin_list
# ---------------------------------------------------------------------------

class TestConvenienceHelpers:
    def test_get_cell_list(self, lib):
        cells = lib.get_cell_list()
        assert set(cells) == {'INV_X1', 'AND2_X1', 'DFFS_X2'}

    def test_get_cell_list_count(self, lib):
        assert len(lib.get_cell_list()) == 3

    def test_get_pin_list_single_cell(self, lib):
        pins = lib.get_pin_list(cell='INV_X1')
        assert set(pins) == {'A', 'ZN'}

    def test_get_pin_list_all_cells(self, lib):
        pins = lib.get_pin_list()
        assert isinstance(pins, dict)
        assert 'INV_X1' in pins
        assert 'AND2_X1' in pins

    def test_get_pin_list_and2(self, lib):
        pins = lib.get_pin_list(cell='AND2_X1')
        assert set(pins) == {'A1', 'A2', 'Z'}

    def test_get_pin_list_dffs_includes_pg_pins(self, lib):
        # pg_pin and pin are both returned by navigate('{RE}pg_pin|pin')
        pins = lib.get_pin_list(cell='DFFS_X2')
        assert 'D' in pins
        assert 'Q' in pins
        assert 'VDD' in pins

    def test_get_pin_list_from_cell_block(self, lib):
        cell = lib.navigate_single('library', 'cell:INV_X1')
        pins = cell.get_pin_list()
        assert set(pins) == {'A', 'ZN'}


# ---------------------------------------------------------------------------
# Element type predicates
# ---------------------------------------------------------------------------

class TestPredicates:
    def test_is_comment(self, lib):
        from liberty_parser.parser import to_dct
        # First element at lib level should be a comment
        first = lib.lib_dict[to_dct['elements']][0]
        assert is_comment(first)

    def test_is_simple_attribute(self, lib):
        result = lib.navigate_single('library', 'time_unit')
        assert is_simple_attribute(result)

    def test_simple_is_not_block(self, lib):
        result = lib.navigate_single('library', 'time_unit')
        assert not is_block(result)

    def test_is_block(self, lib):
        cell = lib.navigate_single('library', 'cell:INV_X1')
        assert is_block(cell)

    def test_block_is_not_simple(self, lib):
        cell = lib.navigate_single('library', 'cell:INV_X1')
        assert not is_simple_attribute(cell)

    def test_is_complex_attribute(self, lib):
        # index_1 is a complex attribute: index_1("0.1, 0.5, 1.0")
        idx = lib.navigate_single('library', '{RE}_template$', '{RE}^index_1')
        assert is_complex_attribute(idx)


# ---------------------------------------------------------------------------
# set_val — in-place editing
# ---------------------------------------------------------------------------

class TestSetVal:
    def test_set_val_changes_value(self):
        lib = LP(SAMPLE_LIB)
        lib.navigate_single('library', 'time_unit').set_val('2ns')
        assert lib.navigate_single('library', 'time_unit').get_val() == '2ns'

    def test_set_val_with_nav_to(self):
        lib = LP(SAMPLE_LIB)
        library = lib.navigate_single('library')
        library.set_val('voltage_unit', '1.8V')
        assert library.get_val('voltage_unit') == '1.8V'

    def test_set_val_does_not_affect_original(self):
        lib1 = LP(SAMPLE_LIB)
        lib2 = LP(SAMPLE_LIB)
        lib1.navigate_single('library', 'time_unit').set_val('99ns')
        # lib2 was parsed independently
        assert lib2.navigate_single('library', 'time_unit').get_val() == '1ns'


# ---------------------------------------------------------------------------
# write_liberty — round-trip
# ---------------------------------------------------------------------------

class TestWriteLiberty:
    def test_roundtrip_produces_file(self):
        lib = LP(SAMPLE_LIB)
        with tempfile.NamedTemporaryFile(suffix='.lib', delete=False) as fh:
            out = fh.name
        try:
            lib.write_liberty(out)
            assert os.path.isfile(out)
            assert os.path.getsize(out) > 0
        finally:
            os.unlink(out)

    def test_roundtrip_reparseable(self):
        lib = LP(SAMPLE_LIB)
        with tempfile.NamedTemporaryFile(suffix='.lib', delete=False) as fh:
            out = fh.name
        try:
            lib.write_liberty(out)
            lib2 = LP(out)
            assert lib2.get_cell_list() == lib.get_cell_list()
        finally:
            os.unlink(out)

    def test_roundtrip_cell_pins_preserved(self):
        lib = LP(SAMPLE_LIB)
        with tempfile.NamedTemporaryFile(suffix='.lib', delete=False) as fh:
            out = fh.name
        try:
            lib.write_liberty(out)
            lib2 = LP(out)
            assert set(lib2.get_pin_list(cell='AND2_X1')) == {'A1', 'A2', 'Z'}
        finally:
            os.unlink(out)


# ---------------------------------------------------------------------------
# add_simple / add_complex
# ---------------------------------------------------------------------------

class TestAddElements:
    def test_add_simple(self):
        lib = LP(SAMPLE_LIB)
        library = lib.navigate_single('library')
        library.add_simple('nom_voltage', '1.8')
        result = lib.navigate_single('library', 'nom_voltage')
        assert result is not None
        assert result.get_val() == '1.8'

    def test_add_complex(self):
        lib = LP(SAMPLE_LIB)
        library = lib.navigate_single('library')
        library.add_complex('operating_conditions', 'typical')
        result = lib.navigate_single('library', 'operating_conditions')
        assert result is not None
        assert result.get_val() == 'typical'


# ---------------------------------------------------------------------------
# String parsing (non-file input)
# ---------------------------------------------------------------------------

class TestStringParsing:
    def test_parse_simple_block(self):
        text = 'library (my_lib) { time_unit : "1ps"; }'
        lib = LP(text)
        assert isinstance(lib, LP)
        result = lib.navigate_single('library', 'time_unit')
        assert result is not None
        assert result.get_val() == '1ps'

    def test_string_type_is_block(self):
        from liberty_parser.parser import to_dct
        text = 'library (mini) { voltage_unit : "1V"; }'
        lib = LP(text)
        assert lib.lib_dict[to_dct['type']] == 'block'
