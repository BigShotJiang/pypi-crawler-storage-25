from eagle.stores import get_store_class
from eagle.memory.shared.shared_objects_memory import SharedObjectsMemory
from eagle.settings import get_settings

def create_shared_objects_space(embedding_model):

    settings = get_settings()

    # Create shared memory instance
    store_class = get_store_class(settings.agents_vectorstore_kind)
    shared_objects_space = SharedObjectsMemory(
        store_class=store_class,
        embedding_model=embedding_model,
        embedding_dims=settings.agents_shared_memory_embedding_dims,
        embedding_name=settings.agents_shared_memory_embedding_name,
        storage_dir=settings.agents_shared_memory_storage_dir
    )
    return shared_objects_space