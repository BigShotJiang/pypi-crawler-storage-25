from eagle.agents.definitions.react.react_agent import (
    ReactPlanningAgent,
    ReportModeratorReactPlanningAgent,
    observe_bypass_node as react_observe_bypass_node,
    plan_bypass_node as react_plan_bypass_node,
    supervisor_observe_bypass_node as react_supervisor_observe_bypass_node,
    supervisor_plan_bypass_node as react_supervisor_plan_bypass_node
)
from eagle.agents.memory.agent_memory_templates.conversation_basic import (
    ConversationBasicAgentMemoryStackTemplate,
    ModerationConversationBasicAgentMemoryStackTemplate
)
from typing import Literal, Any, Union

def create_agent(
    name: str,
    description: str,
    agent_type: Literal["react"],
    role: Literal["agent", "report_moderator"] = "agent",
    checkpointer: Union[Any, None] = None,
    exclude_observe: bool = False,
    exclude_plan: bool = False,
    memory_stack: Any = None
):

    if agent_type != "react":
        raise ValueError("Unknown agent type.")

    # 🔀 escolha dos nós
    if "moderator" in role:
        observe_bypass = react_supervisor_observe_bypass_node
        plan_bypass = react_supervisor_plan_bypass_node
    else:
        observe_bypass = react_observe_bypass_node
        plan_bypass = react_plan_bypass_node

    # 🧬 escolha da classe base
    if role == "report_moderator":
        agent_class = ReportModeratorReactPlanningAgent
    elif role == "agent":
        agent_class = ReactPlanningAgent
    else:
        raise ValueError("Unknown role.")

    # 🧱 overrides declarativos
    overrides = {}

    if exclude_observe:
        overrides["OBSERVE_NODE"] = observe_bypass

    if exclude_plan:
        overrides["PLAN_NODE"] = plan_bypass

    # 🏗️ criação da classe dinâmica
    new_class = type(
        f"Custom{agent_class.__name__}_{id(overrides)}",
        (agent_class,),
        overrides
    )

    agent = new_class(
        name=name,
        description=description,
        checkpointer=checkpointer
    )

    if "_moderator" in role:
        default_memory_stack = ModerationConversationBasicAgentMemoryStackTemplate(
            shared_memory=None,  # Será injetado posteriormente
            chat_history_window_size=15,
            plan_execution_batch_size=15
        )
    else:
        default_memory_stack = ConversationBasicAgentMemoryStackTemplate(
            shared_memory=None,  # Será injetado posteriormente
            chat_history_window_size=15,
            plan_execution_batch_size=15
        )

    if memory_stack is not None:
        agent.load_memory("agent_memory_stack", memory_stack)
    else:
        agent.load_memory("agent_memory_stack", default_memory_stack)

    return agent