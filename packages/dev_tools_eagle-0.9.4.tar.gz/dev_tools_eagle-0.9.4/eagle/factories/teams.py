
from pydantic import BaseModel
from typing import List, Literal, Any
from langchain_core.embeddings import Embeddings
from eagle.factories.agents import create_agent
from eagle.factories.shared_memories import create_shared_objects_space
from eagle.agents.memory.agent_memory_templates.conversation_basic import (
    ConversationBasicAgentMemoryStackTemplate,
    ModerationConversationBasicAgentMemoryStackTemplate
)

class AgentSpec(BaseModel):
    name: str
    description: str
    role: Literal["agent"] = "agent"
    agent_type: Literal["react"] = "react"
    exclude_observe: bool = False
    exclude_plan: bool = False
    chat_history_window_size: int = 15
    plan_execution_batch_size: int = 15


class ModeratorSpec(BaseModel):
    name: str
    description: str
    role: Literal["report_moderator"] = "report_moderator"
    agent_type: Literal["react"] = "react"
    exclude_observe: bool = False
    exclude_plan: bool = False
    chat_history_window_size: int = 15
    plan_execution_batch_size: int = 15

def create_agent_team(
    agents: List[AgentSpec],
    moderator: ModeratorSpec,
    chat_id: str,
    embedding_model: Embeddings,
    delete_old_memories: bool = True
):

    # Create shared memory instance
    shared_objects_space = create_shared_objects_space(embedding_model=embedding_model)

    # Limpar memórias antigas para o chat_id
    if delete_old_memories:
        shared_objects_space.delete_memories_by_namespace(chat_id=chat_id)

    # Criar stacks de memória para agentes
    agent_instances = {}
    for agent_spec in agents:
        agent = create_agent(
            name=agent_spec.name,
            description=agent_spec.description,
            agent_type=agent_spec.agent_type,
            role=agent_spec.role,
            exclude_observe=agent_spec.exclude_observe,
            exclude_plan=agent_spec.exclude_plan,
            memory_stack=ConversationBasicAgentMemoryStackTemplate(
                shared_memory=shared_objects_space,
                chat_history_window_size=agent_spec.chat_history_window_size,
                plan_execution_batch_size=agent_spec.plan_execution_batch_size
            )
        )

        agent_instances[agent.name] = agent

    # Criar moderador
    moderator_agent = create_agent(
        name=moderator.name,
        description=moderator.description,
        agent_type=moderator.agent_type,
        role=moderator.role,
        exclude_observe=moderator.exclude_observe,
        exclude_plan=moderator.exclude_plan,
        memory_stack=ModerationConversationBasicAgentMemoryStackTemplate(
            shared_memory=shared_objects_space,
            chat_history_window_size=moderator.chat_history_window_size,
            plan_execution_batch_size=moderator.plan_execution_batch_size
        )
    )

    # Criar schema baseado no tipo do moderador
    if moderator.role == "report_moderator":
        from eagle.chat_schemas.report_schemas.schemas import ReportChatSchema
        schema = ReportChatSchema(moderator=moderator_agent)

        # Adicionar agentes ao schema
        for agent in agent_instances.values():
            schema.add_agent(agent)
    else:
        raise ValueError(f"Unsupported moderator role: {moderator.role}")

    return schema, shared_objects_space