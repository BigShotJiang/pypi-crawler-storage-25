import pytest
import io
import base64
from unittest.mock import MagicMock, patch

# Patch PIL and plotly imports in the module under test
import types
class FakeImage:
    pass
FakeImage.__module__ = "PIL.Image"

# Patch PIL.Image.Image to be the FakeImage class itself
fake_pil_image_mod = types.SimpleNamespace(Image=FakeImage)
with patch.dict("sys.modules", {
    "PIL": MagicMock(),
    "PIL.Image": types.SimpleNamespace(Image=FakeImage),
    "plotly": MagicMock(),
    "plotly.graph_objects": MagicMock(),
    "plotly.graph_objects.go": MagicMock(),
}):
    from image_utils import object_to_image_url, normalized_crop

def test_normalized_crop_basic(monkeypatch):
    # Arrange
    mock_img = MagicMock()
    mock_img.size = (100, 100)
    # Simula crop retornando um novo mock com size correto
    def fake_crop(box):
        cropped = MagicMock()
        cropped.size = (box[2] - box[0], box[3] - box[1])
        return cropped
    mock_img.crop.side_effect = fake_crop

    # Act
    cropped = normalized_crop(mock_img, 0.0, 0.0, 1.0, 1.0)

    # Assert
    assert cropped.size == (100, 100)

@pytest.mark.parametrize(
    "size, crop_args, expected_size, description",
    [
        ((100, 100), (0.1, 0.1, 0.9, 0.9), (80, 80), "center crop"),
        ((50, 50), (0.0, 0.0, 0.5, 0.5), (25, 25), "bottom-left quarter"),
        ((10, 10), (0.0, 0.5, 0.5, 1.0), (5, 5), "top-left quarter"),
    ],
    ids=["center-crop", "bottom-left", "top-left"]
)
def test_normalized_crop_various(monkeypatch, size, crop_args, expected_size, description):
    # Arrange
    mock_img = MagicMock()
    mock_img.size = size
    def fake_crop(box):
        cropped = MagicMock()
        cropped.size = (box[2] - box[0], box[3] - box[1])
        return cropped
    mock_img.crop.side_effect = fake_crop

    # Act
    cropped = normalized_crop(mock_img, *crop_args)

    # Assert
    assert cropped.size == expected_size, f"Failed: {description}"

@pytest.mark.parametrize(
    "x1, y1, x2, y2, description",
    [
        (-0.5, -0.5, 1.5, 1.5, "out of bounds, should clamp"),
        (0.0, 0.0, 0.0, 0.0, "zero area, should clamp to min size"),
        (1.0, 1.0, 0.0, 0.0, "reversed coordinates, should clamp"),
    ],
    ids=["out-of-bounds", "zero-area", "reversed"]
)
def test_normalized_crop_edge_cases(monkeypatch, x1, y1, x2, y2, description):
    # Arrange
    mock_img = MagicMock()
    mock_img.size = (10, 10)
    def fake_crop(box):
        cropped = MagicMock()
        cropped.size = (box[2] - box[0], box[3] - box[1])
        return cropped
    mock_img.crop.side_effect = fake_crop

    # Act
    cropped = normalized_crop(mock_img, x1, y1, x2, y2)

    # Assert
    assert cropped.size[0] > 0 and cropped.size[1] > 0, f"Failed: {description}"
