import pytest
from classes_utils import get_all_subclasses

# Define a class hierarchy for testing
class Base: pass
class ChildA(Base): pass
class ChildB(Base): pass
class GrandChildA1(ChildA): pass
class GrandChildA2(ChildA): pass
class GreatGrandChildA1(GrandChildA1): pass
class Unrelated: pass

@pytest.mark.parametrize(
    "cls, expected, description",
    [
        # Happy path: direct subclasses
        (Base, {ChildA, ChildB, GrandChildA1, GrandChildA2, GreatGrandChildA1}, "base-all-descendants"),
        (ChildA, {GrandChildA1, GrandChildA2, GreatGrandChildA1}, "childA-descendants"),
        (ChildB, set(), "childB-no-descendants"),
        (GrandChildA1, {GreatGrandChildA1}, "grandchildA1-descendants"),
        (GrandChildA2, set(), "grandchildA2-no-descendants"),
        (GreatGrandChildA1, set(), "greatgrandchildA1-no-descendants"),
        # Edge case: class with no subclasses
        (Unrelated, set(), "unrelated-no-descendants"),
    ],
    ids=[
        "base-all-descendants",
        "childA-descendants",
        "childB-no-descendants",
        "grandchildA1-descendants",
        "grandchildA2-no-descendants",
        "greatgrandchildA1-no-descendants",
        "unrelated-no-descendants",
    ]
)
def test_get_all_subclasses(cls, expected, description):
    # Act
    result = get_all_subclasses(cls)

    # Assert
    assert result.issuperset(expected), f"Failed: {description}"
    if cls is not object:
        assert result == expected, f"Failed: {description}"

@pytest.mark.parametrize(
    "bad_cls, error_type, description",
    [
        (None, AttributeError, "none-input"),
        (42, AttributeError, "int-input"),
        ("str", AttributeError, "str-input"),
        (lambda x: x, AttributeError, "function-input"),
    ],
    ids=[
        "none-input",
        "int-input",
        "str-input",
        "function-input",
    ]
)
def test_get_all_subclasses_error_cases(bad_cls, error_type, description):
    # Act & Assert
    with pytest.raises(error_type):
        get_all_subclasses(bad_cls)
