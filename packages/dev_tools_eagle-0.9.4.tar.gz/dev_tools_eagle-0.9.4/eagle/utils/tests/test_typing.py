from typing import TypedDict
from eagle.utils.typing import initialize_nested


class Address(TypedDict, total=False):
    street: str
    city: str


class User(TypedDict, total=False):
    name: str
    age: int
    address: Address


def test_initialize_nested_uses_provided_values():
    data = {"name": "Lu", "age": 35, "address": {"street": "Rua A", "city": "RJ"}}
    result = initialize_nested(User, data)

    assert result == {
        "name": "Lu",
        "age": 35,
        "address": {"street": "Rua A", "city": "RJ"},
    }


def test_initialize_nested_fills_missing_nested_with_empty_dict():
    # address não veio -> deve criar address com defaults (None para street/city)
    data = {"name": "Lu"}
    result = initialize_nested(User, data)

    assert result["name"] == "Lu"
    assert result["age"] is None
    assert result["address"] == {"street": None, "city": None}


def test_initialize_nested_ignores_extra_keys_in_data():
    data = {"name": "Lu", "unknown": 123, "address": {"street": "X", "zip": "999"}}
    result = initialize_nested(User, data)

    # unknown e zip não existem nos type hints → não aparecem
    assert "unknown" not in result
    assert "zip" not in result["address"]
    assert result["address"]["street"] == "X"
    assert result["address"]["city"] is None


def test_initialize_nested_uses_schema_default_when_data_missing():
    # TypedDict é class e dá pra setar atributo na classe
    class SchemaWithDefaults(TypedDict, total=False):
        name: str
        age: int

    SchemaWithDefaults.name = "default-name"
    SchemaWithDefaults.age = 99

    result = initialize_nested(SchemaWithDefaults, data={})

    assert result == {"name": "default-name", "age": 99}
