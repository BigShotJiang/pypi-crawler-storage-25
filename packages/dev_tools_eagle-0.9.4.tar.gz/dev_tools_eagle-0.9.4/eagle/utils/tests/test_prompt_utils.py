"""
WARNING:
    The EagleJSONOutputParser tests have been moved to test_output_json.py,
    beacause they depend on the convert_schema function defined there.
    Please refer to test_output_json.py for the relevant tests.
"""

import pytest
import yaml
import sys
import types
from unittest.mock import MagicMock

# Mock langchain.output_parsers before importing output parsers
mock_output_parsers = types.ModuleType("langchain.output_parsers")
sys.modules["langchain.output_parsers"] = mock_output_parsers

# Mock eagle.utils.output with convert_schema before importing EagleJsonOutputParser
mock_output_mod = types.ModuleType("eagle.utils.output")
mock_output_mod.convert_schema = MagicMock()
sys.modules["eagle.utils.output"] = mock_output_mod

from langchain_core.language_models.chat_models import BaseChatModel


# Dummy output parser for testing
class DummyParser:
    def __init__(self, source_lang, llm, use_structured_output=False):
        self.source_lang = source_lang
        self.llm = llm
        self.use_structured_output = use_structured_output

class DummyLLM(BaseChatModel):
    def _generate(self, *args, **kwargs):
        pass
    @property
    def _llm_type(self):
        return "dummy"

class DummyMessage:
    def __init__(self, content):
        self.content = content

@pytest.fixture
def prompts_dict():
    return {
        "greet": {
            "languages": {
                "en": "Hello!",
                "pt": "Olá!"
            },
            "output_parser": lambda source_lang, llm, use_structured_output=False: DummyParser(source_lang, llm, use_structured_output)
        },
        "bye": {
            "languages": {
                "en": "Goodbye!",
            },
            "output_parser": lambda source_lang, llm, use_structured_output=False: DummyParser(source_lang, llm, use_structured_output)
        }
    }

@pytest.mark.parametrize(
    "prompt_name, language, use_structured_output, expected_prompt, expected_lang, description",
    [
        ("greet", "en", False, "Hello!", "en", "happy-path-en"),
        ("greet", "pt", True, "Olá!", "pt", "happy-path-pt-structured"),
        ("bye", "en", False, "Goodbye!", "en", "happy-path-bye"),
    ],
    ids=["happy-path-en", "happy-path-pt-structured", "happy-path-bye"]
)
def test_generate_prompt_happy_path(prompts_dict, prompt_name, language, use_structured_output, expected_prompt, expected_lang, description):
    # Arrange
    llm = MagicMock(spec=BaseChatModel)
    
    from prompt_utils import PromptGenerator
    gen = PromptGenerator(prompts_dict)

    # Act
    result = gen.generate_prompt(prompt_name, language, llm, use_structured_output=use_structured_output)

    # Assert
    assert result["prompt"] == expected_prompt, f"Failed: {description}"
    assert isinstance(result["output_parser"], DummyParser)
    assert result["output_parser"].source_lang == expected_lang
    assert result["output_parser"].llm is llm
    assert result["output_parser"].use_structured_output == use_structured_output

@pytest.mark.parametrize(
    "prompt_name, language, expected_error, expected_msg, description",
    [
        ("unknown", "en", ValueError, "Prompt 'unknown' is not supported", "invalid-prompt"),
        ("greet", "es", ValueError, "Language 'es' is not supported for prompt 'greet'", "invalid-language"),
        ("bye", "pt", ValueError, "Language 'pt' is not supported for prompt 'bye'", "invalid-language-bye"),
    ],
    ids=["invalid-prompt", "invalid-language", "invalid-language-bye"]
)
def test_generate_prompt_error_cases(prompts_dict, prompt_name, language, expected_error, expected_msg, description):
    # Arrange
    llm = MagicMock(spec=BaseChatModel)
    
    from prompt_utils import PromptGenerator
    gen = PromptGenerator(prompts_dict)

    # Act & Assert
    with pytest.raises(expected_error, match=expected_msg):
        gen.generate_prompt(prompt_name, language, llm)
