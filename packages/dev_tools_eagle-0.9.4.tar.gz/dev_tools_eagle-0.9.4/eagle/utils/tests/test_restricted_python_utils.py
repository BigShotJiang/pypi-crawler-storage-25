"""
WARNING:
    These tests use mocks for RestrictedPython and func_timeout. As such, they
    do not fully validate the actual security features provided by
    RestrictedPython and func_timeout. They mainly ensure that the
    SafePythonCompiler class integrates correctly with these libraries and
    handles various scenarios as expected. For full security validation,
    integration tests with the real RestrictedPython and func_timeout libraries
    should be implemented.
WARNING:
    The safe_for function, which should limit the number of items in the for
    loop, is not being used in the tests. In real RestrictedPython, the for loop
    bytecode is rewritten to use the built-in _getiter_ (which points to
    safe_for). In the mock, since you're using the normal Python compile() (in
    your fake_compile_restricted), the bytecode is not rewritten and the loop
    uses Python's standard range and iterator, completely ignoring your
    safe_for. This can cause memory overflows and crashes locally.
"""

import pytest
from unittest.mock import patch, MagicMock
import sys
import types

# Mock RestrictedPython and its submodules before importing the code under test
mock_restrictedpython = types.ModuleType("RestrictedPython")

def fake_compile_restricted(source, filename, mode):
    return compile(source, filename, mode)
mock_restrictedpython.compile_restricted = fake_compile_restricted

mock_restrictedpython.safe_builtins = {
    "range": range,
    "sum": sum,
    "min": min,
    "max": max,
    "list": list,
    "tuple": tuple,
    "dict": dict,
    "enumerate": enumerate,
    "sorted": sorted,
    "next": next,
    "__import__": __import__,
    "ValueError": ValueError,
    # ... add other safe builtins as needed
}
mock_restrictedpython.limited_builtins = {
    "range": range,
    "sum": sum,
    "min": min,
    "max": max,
    "list": list,
    "tuple": tuple,
    "dict": dict,
    "enumerate": enumerate,
    "sorted": sorted,
    "next": next,
    "__import__": __import__,
    "ValueError": ValueError,
    # ... add other limited builtins as needed
}
mock_restrictedpython.utility_builtins = {
    "range": range,
    "sum": sum,
    "min": min,
    "max": max,
    "list": list,
    "tuple": tuple,
    "dict": dict,
    "enumerate": enumerate,
    "sorted": sorted,
    "next": next,
    "__import__": __import__,
    "ValueError": ValueError,
    # ... add other utility builtins as needed
}

mock_guards = types.ModuleType("RestrictedPython.Guards")
mock_guards.guarded_iter_unpack_sequence = MagicMock()
mock_guards.guarded_unpack_sequence = MagicMock()

mock_eval = types.ModuleType("RestrictedPython.Eval")
mock_eval.default_guarded_getiter = lambda x, *a, **k: iter(x)

# Mock func_timeout before importing the code under test
mock_func_timeout_mod = types.ModuleType("func_timeout")

def fake_func_timeout(timeout, func, *args, **kwargs):
    return func(*args, **kwargs)
mock_func_timeout_mod.func_timeout = fake_func_timeout
sys.modules["func_timeout"] = mock_func_timeout_mod

sys.modules["RestrictedPython"] = mock_restrictedpython
sys.modules["RestrictedPython.Guards"] = mock_guards
sys.modules["RestrictedPython.Eval"] = mock_eval

from restricted_python_utils import (
    SafePythonCompiler,
    SafePythonCompilerException,
)

# --- Fixtures and helpers ---

@pytest.fixture
def compiler():
    return SafePythonCompiler(
        safe_import_modules=["math"],
        forbidden_modules=["pip.main"],
        max_for=3,
        exec_timeout=2
    )

def make_func_source(func_name, body):
    return f"def {func_name}():\n    {body}"

# --- Tests ---

@pytest.mark.parametrize(
    "source_code, func_name, expected, description",
    [
        ("def foo():\n    return 42", "foo", 42, "simple return"),
        ("def bar():\n    return sum([1,2,3])", "bar", 6, "use safe builtins"),
        ("def baz():\n    return min([5,2,7])", "baz", 2, "use min builtin"),
        ("def qux():\n    return max([5,2,7])", "qux", 7, "use max builtin"),
        ("def tup():\n    return tuple([1,2])", "tup", (1,2), "use tuple builtin"),
        ("def l():\n    return list((1,2))", "l", [1,2], "use list builtin"),
    ],
    ids=["simple", "sum", "min", "max", "tuple", "list"]
)
def test_compile_and_exec_happy_path(compiler, source_code, func_name, expected, description):
    # Act
    compiler.compile(source_code)
    result = compiler.exec_function(func_name)

    # Assert
    assert result == expected, f"Failed: {description}"

def test_compile_and_exec_for_loop_allowed(compiler):
    # Arrange
    source_code = (
        "def foo():\n"
        "    s = 0\n"
        "    for i in range(3):\n"
        "        s += i\n"
        "    return s"
    )
    # Act
    compiler.compile(source_code)
    result = compiler.exec_function("foo")
    # Assert
    assert result == 3

def test_compile_and_exec_for_loop_typeerror(compiler):
    # Arrange
    source_code = (
        "def foo():\n"
        "    return sum(i for i in enumerate([1,2,3]))"
    )
    # Act
    compiler.compile(source_code)
    # Assert
    with pytest.raises(SafePythonCompilerException) as excinfo:
        compiler.exec_function("foo")
    assert "unsupported operand type" in str(excinfo.value)

def test_compile_and_exec_forbidden_import(compiler):
    # Arrange
    source_code = (
        "def foo():\n"
        "    import pip\n"
        "    return 1"
    )
    # Act
    compiler.compile(source_code)
    # Assert
    with pytest.raises(Exception):
        compiler.exec_function("foo")

def test_compile_and_exec_forbidden_module_patch(compiler):
    # Arrange
    source_code = (
        "def foo():\n"
        "    pip.main()\n"
        "    return 1"
    )
    # Act
    compiler.compile(source_code)
    # Assert
    with pytest.raises(Exception):
        compiler.exec_function("foo")
