import pytest
from unittest.mock import MagicMock, patch
import sys
import types

# Mock langchain.chains and submodules before importing stores
mock_langchain_chains = types.ModuleType("langchain.chains")
mock_query_constructor = types.ModuleType("langchain.chains.query_constructor")
mock_query_constructor_schema = types.ModuleType("langchain.chains.query_constructor.schema")
mock_query_constructor_base = types.ModuleType("langchain.chains.query_constructor.base")

class MockAttributeInfo:
    def __init__(self, name):
        self.name = name

class MockStructuredQueryOutputParser:
    @staticmethod
    def from_components(**kwargs):
        return MagicMock(**kwargs)

mock_query_constructor_schema.AttributeInfo = MockAttributeInfo
mock_query_constructor_base.StructuredQueryOutputParser = MockStructuredQueryOutputParser

sys.modules["langchain.chains"] = mock_langchain_chains
sys.modules["langchain.chains.query_constructor"] = mock_query_constructor
sys.modules["langchain.chains.query_constructor.schema"] = mock_query_constructor_schema
sys.modules["langchain.chains.query_constructor.base"] = mock_query_constructor_base

import stores

AttributeInfo = sys.modules["langchain.chains.query_constructor.schema"].AttributeInfo
class DummyAttributeInfo(AttributeInfo):
    pass

class DummyVisitor:
    def __init__(self, new_query, search_kwargs):
        self._new_query = new_query
        self._search_kwargs = search_kwargs
    def visit_structured_query(self, structured_query):
        return self._new_query, self._search_kwargs

class DummyStructuredQuery:
    def __init__(self, limit=None):
        self.limit = limit

# Test cases for eagle.utils.stores module
@pytest.mark.parametrize(
    "attribute_info, allowed_comparators, allowed_operators, fix_invalid, expected_attrs, description",
    [
        ([DummyAttributeInfo("foo"), DummyAttributeInfo("bar")], ["eq"], ["and"], False, ["foo", "bar"], "attributeinfo objects"),
        ([{"name": "foo"}, {"name": "bar"}], ["eq"], ["and"], True, ["foo", "bar"], "dicts"),
        ([DummyAttributeInfo("foo"), {"name": "bar"}], None, None, False, ["foo", "bar"], "mixed"),
    ],
    ids=["objs", "dicts", "mixed"]
)
def test_get_structured_query_output_parser(attribute_info, allowed_comparators, allowed_operators, fix_invalid, expected_attrs, description, monkeypatch):
    # Arrange
    called = {}
    class DummyParser:
        @staticmethod
        def from_components(**kwargs):
            called.update(kwargs)
            return "parser"
    monkeypatch.setattr(stores, "StructuredQueryOutputParser", DummyParser)

    # Act
    result = stores._get_structured_query_output_parser(
        attribute_info=attribute_info,
        allowed_comparators=allowed_comparators,
        allowed_operators=allowed_operators,
        fix_invalid=fix_invalid
    )

    # Assert
    assert result == "parser"
    assert called["allowed_attributes"] == expected_attrs
    assert called["allowed_comparators"] == allowed_comparators
    assert called["allowed_operators"] == allowed_operators
    assert called["fix_invalid"] == fix_invalid

@pytest.mark.parametrize(
    "limit, expected_k, description",
    [
        (None, None, "no limit"),
        (10, 10, "with limit"),
    ],
    ids=["no-limit", "with-limit"]
)
def test_prepare_search_kwargs(limit, expected_k, description):
    # Arrange
    structured_query = DummyStructuredQuery(limit=limit)
    translator = DummyVisitor("new_query", {"foo": "bar"})

    # Act
    new_query, search_kwargs = stores._prepare_search_kwargs(structured_query, translator)

    # Assert
    assert new_query == "new_query"
    if expected_k is not None:
        assert search_kwargs["k"] == expected_k
    else:
        assert "k" not in search_kwargs

def test_translate_to_structured_query(monkeypatch):
    # Arrange
    dummy_parser = MagicMock()
    dummy_structured_query = MagicMock()
    dummy_structured_query.limit = 5
    dummy_new_query = "translated_query"
    dummy_search_kwargs = {"k": 5, "foo": "bar"}

    # Patch _get_structured_query_output_parser to return a dummy parser
    monkeypatch.setattr(stores, "_get_structured_query_output_parser", lambda **kwargs: dummy_parser)
    # Patch parser.parse to return a dummy structured query
    dummy_parser.parse.return_value = dummy_structured_query
    # Patch _prepare_search_kwargs to return dummy values
    monkeypatch.setattr(stores, "_prepare_search_kwargs", lambda sq, tr: (dummy_new_query, dummy_search_kwargs))

    # Act
    result_query, result_kwargs = stores.translate_to_structured_query(
        query="find this",
        filter_as_str="foo=1",
        limit=5,
        translator="dummy_translator",
        attribute_info=[{"name": "foo"}],
        allowed_comparators=["eq"],
        allowed_operators=["and"],
        fix_invalid=True
    )

    # Assert
    assert result_query == dummy_new_query
    assert result_kwargs == dummy_search_kwargs
    dummy_parser.parse.assert_called_once()
