import pytest
from pydantic import BaseModel
from langchain_core.messages import AIMessage

from eagle.utils.output import convert_schema


class SourceModel(BaseModel):
    x: int
    y: str


class TargetModel(BaseModel):
    a: int
    b: str


def test_convert_schema_real_full_flow():
    message = AIMessage(content="""
    {
        x: 1,
        y: 'foo',
    }
    """)

    conversion_schema = {
        "en": {
            "class_for_parsing": SourceModel,
            "convertion_schema": {
                "x": {"target_key": "a"},
                "y": {"target_key": "b"}
            }
        }
    }

    result = convert_schema(
        message=message,
        conversion_schema=conversion_schema,
        source_lang="en",
        target_schema=TargetModel,
        llm=None,
        use_structured_output=False
    )

    assert result.a == 1
    assert result.b == "foo"


def test_convert_schema_with_text_around_json():
    message = AIMessage(content="""
    texto antes

    {"x": 1, "y": "foo"}

    texto depois
    """)

    conversion_schema = {
        "en": {
            "class_for_parsing": SourceModel,
            "convertion_schema": {
                "x": {"target_key": "a"},
                "y": {"target_key": "b"}
            }
        }
    }

    result = convert_schema(
        message=message,
        conversion_schema=conversion_schema,
        source_lang="en",
        target_schema=TargetModel,
        llm=None,
        use_structured_output=False
    )

    assert result.a == 1
    assert result.b == "foo"


def test_convert_schema_no_json_found():
    message = AIMessage(content="não existe json aqui")

    conversion_schema = {
        "en": {
            "class_for_parsing": SourceModel,
            "convertion_schema": {
                "x": {"target_key": "a"},
                "y": {"target_key": "b"}
            }
        }
    }

    with pytest.raises(Exception):
        convert_schema(
            message=message,
            conversion_schema=conversion_schema,
            source_lang="en",
            target_schema=TargetModel,
            llm=None,
            use_structured_output=False
        )
