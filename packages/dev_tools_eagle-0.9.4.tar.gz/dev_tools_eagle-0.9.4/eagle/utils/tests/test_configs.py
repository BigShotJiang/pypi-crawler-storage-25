import pytest
from pathlib import Path
from unittest import mock

from configs import find_env_upwards

@pytest.mark.parametrize(
    "env_filename, env_locations, start_path, expected_result, description",
    [
        # Happy path: .env in current directory
        (".env", {"cwd": True, "parent": False, "grandparent": False}, "cwd", True, "env-in-cwd"),
        # Happy path: .env in parent directory
        (".env", {"cwd": False, "parent": True, "grandparent": False}, "cwd", True, "env-in-parent"),
        # Happy path: .env in grandparent directory
        (".env", {"cwd": False, "parent": False, "grandparent": True}, "cwd", True, "env-in-grandparent"),
        # Edge case: custom filename in parent
        ("custom.env", {"cwd": False, "parent": True, "grandparent": False}, "cwd", True, "custom-env-in-parent"),
        # Edge case: start_path is None (should use Path.cwd)
        (".env", {"cwd": True, "parent": False, "grandparent": False}, None, True, "env-in-cwd-none-start"),
    ],
    ids=[
        "env-in-cwd",
        "env-in-parent",
        "env-in-grandparent",
        "custom-env-in-parent",
        "env-in-cwd-none-start",
    ]
)
def test_find_env_upwards_happy_and_edge_cases(env_filename, env_locations, start_path, expected_result, description, monkeypatch):
    # Arrange
    # Create a fake directory structure: /grandparent/parent/cwd
    grandparent = Path("/grandparent")
    parent = grandparent / "parent"
    cwd = parent / "cwd"
    fake_paths = {
        "cwd": cwd,
        "parent": parent,
        "grandparent": grandparent,
    }

    # Patch Path.cwd() if start_path is None
    if start_path is None:
        monkeypatch.setattr("pathlib.Path.cwd", lambda: cwd)
        test_start_path = None
    else:
        test_start_path = fake_paths[start_path]

    # Patch Path.exists to simulate where the env file exists
    def fake_exists(self):
        if env_locations["cwd"] and self == cwd / env_filename:
            return True
        if env_locations["parent"] and self == parent / env_filename:
            return True
        if env_locations["grandparent"] and self == grandparent / env_filename:
            return True
        return False

    monkeypatch.setattr("pathlib.Path.exists", fake_exists)

    # Patch load_dotenv to just record the call
    load_dotenv_calls = []
    def fake_load_dotenv(path):
        load_dotenv_calls.append(path)
    monkeypatch.setattr("configs.load_dotenv", fake_load_dotenv)

    # Act
    result = find_env_upwards(env_filename, test_start_path)

    # Assert
    assert result is True
    # Check that load_dotenv was called with the correct path
    if env_locations["cwd"]:
        assert load_dotenv_calls[0] == cwd / env_filename
    elif env_locations["parent"]:
        assert load_dotenv_calls[0] == parent / env_filename
    elif env_locations["grandparent"]:
        assert load_dotenv_calls[0] == grandparent / env_filename

@pytest.mark.parametrize(
    "env_filename, env_locations, start_path, expected_exception, expected_msg, description",
    [
        # Error case: .env not found anywhere
        (".env", {"cwd": False, "parent": False, "grandparent": False}, "cwd", FileNotFoundError, "Could not find .env in", "env-not-found"),
        # Error case: custom filename not found
        ("custom.env", {"cwd": False, "parent": False, "grandparent": False}, "cwd", FileNotFoundError, "Could not find custom.env in", "custom-env-not-found"),
    ],
    ids=[
        "env-not-found",
        "custom-env-not-found",
    ]
)
def test_find_env_upwards_error_cases(env_filename, env_locations, start_path, expected_exception, expected_msg, description, monkeypatch):
    # Arrange
    grandparent = Path("/grandparent")
    parent = grandparent / "parent"
    cwd = parent / "cwd"
    fake_paths = {
        "cwd": cwd,
        "parent": parent,
        "grandparent": grandparent,
    }
    test_start_path = fake_paths[start_path]

    def fake_exists(self):
        return False

    monkeypatch.setattr("pathlib.Path.exists", fake_exists)
    monkeypatch.setattr("eagle.utils.configs.load_dotenv", lambda path: None)

    # Act & Assert
    with pytest.raises(expected_exception, match=expected_msg):
        find_env_upwards(env_filename, test_start_path)
