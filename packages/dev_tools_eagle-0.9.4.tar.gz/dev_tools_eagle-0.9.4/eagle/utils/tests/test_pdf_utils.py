import pytest
from unittest.mock import patch, MagicMock
import sys
import types

# Mock pdf2image and PIL modules before importing the function under test
mock_pdf2image = types.ModuleType("pdf2image")
def dummy_convert_from_path(*args, **kwargs):
    pass
mock_pdf2image.convert_from_path = dummy_convert_from_path
sys.modules["pdf2image"] = mock_pdf2image

mock_pil = types.ModuleType("PIL")
mock_pil_image = types.ModuleType("PIL.Image")
sys.modules["PIL"] = mock_pil
sys.modules["PIL.Image"] = mock_pil_image

from pdf_utils import convert_pdf_page_to_image_with_max_bytes

@pytest.mark.parametrize(
    "images_per_dpi, max_bytes, expected_img_id, description",
    [
        # Happy path: only 100 fits (900 < 1000)
        (
            {100: [("img100", 900)], 50: [("img50", 400)]},
            1000,
            "img50",
            "fits at first try"
        ),
        # Happy path: 137 fits (800 < 1000), 225 and 400 are too big
        (
            {400: [("img400", 2000)], 225: [("img225", 1200)], 137: [("img137", 800)], 50: [("img50", 400)]},
            1000,
            "img50",
            "binary search, fits at 50"
        ),
        # Edge case: only 50 fits (900 < 1000)
        (
            {400: [("img400", 5000)], 225: [("img225", 3000)], 137: [("img137", 2000)], 50: [("img50", 900)]},
            1000,
            "img50",
            "only fits at lowest dpi"
        ),
        # Edge case: none fit, must return lowest dpi (even though it's too big)
        (
            {400: [("img400", 5000)], 225: [("img225", 3000)], 137: [("img137", 2000)], 50: [("img50", 1500)]},
            1000,
            "img50",
            "never fits, returns lowest dpi"
        ),
    ],
    ids=[
        "fits-first-try",
        "binary-search-fits",
        "only-lowest-dpi",
        "never-fits-lowest-dpi"
    ]
)
def test_convert_pdf_page_to_image_with_max_bytes_happy_and_edge_cases(
    images_per_dpi, max_bytes, expected_img_id, description, monkeypatch
):
    mock_pdf2image = types.ModuleType("pdf2image")
    def fake_convert_from_path(pdf_path, first_page, last_page, dpi):
        # Return the image only if dpi is in images_per_dpi
        if dpi in images_per_dpi:
            img_id, size = images_per_dpi[dpi][0]
            mock_img = MagicMock()
            mock_img.img_id = img_id
            def fake_save(buf, format=None):
                buf.write(b"x" * size)
            mock_img.save.side_effect = fake_save
            return [mock_img]
        return []

    mock_pdf2image.convert_from_path = fake_convert_from_path
    sys.modules["pdf2image"] = mock_pdf2image

    # Agora importe a função sob teste (depois do mock)
    from eagle.utils.pdf_utils import convert_pdf_page_to_image_with_max_bytes

    # Act
    result = convert_pdf_page_to_image_with_max_bytes("fake.pdf", 1, max_bytes, dpi_min=50, dpi_max=400, output_format="PNG")

    # Assert
    assert hasattr(result, "img_id")
    assert result.img_id == expected_img_id, f"Failed: {description}"

@pytest.mark.parametrize(
    "images_per_dpi, max_bytes, description",
    [
        # Error case: no images returned at any dpi
        ({}, 1000, "no images at any dpi"),
        ({50: []}, 1000, "empty list at lowest dpi"),
    ],
    ids=["no-images", "empty-list-lowest-dpi"]
)
def test_convert_pdf_page_to_image_with_max_bytes_error_cases(
    images_per_dpi, max_bytes, description, monkeypatch
):
    # Arrange
    def fake_convert_from_path(pdf_path, first_page, last_page, dpi):
        return images_per_dpi.get(dpi, [])

    monkeypatch.setattr("eagle.utils.pdf_utils.convert_from_path", fake_convert_from_path)

    # Act & Assert
    with pytest.raises(ValueError, match="Não foi possível converter a página do PDF."):
        convert_pdf_page_to_image_with_max_bytes("fake.pdf", 1, max_bytes, dpi_min=50, dpi_max=400, output_format="PNG")
