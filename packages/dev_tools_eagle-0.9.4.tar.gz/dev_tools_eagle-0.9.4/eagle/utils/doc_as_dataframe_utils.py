import pandas as pd


def doc_as_dataframe_to_text(file_as_df: pd.DataFrame) -> str:
    """
    Converts the DataFrame representation of a document into text, preserving the
    original DataFrame indices to keep positional references visible in the
    rendered text.
    """

    processed_text = ""
    last_block_label = None

    for idx, row in file_as_df.iterrows():
        block_label = row.get("block_label")

        # Only include figure_title if the immediately prior block in iteration was a figure.
        if block_label == "figure_title" and last_block_label != "figure":
            last_block_label = block_label
            continue

        prefix = f"\n[IDX {idx}]"

        if block_label == "image":
            image_data = row.get("block_content", {})
            image_description = image_data.get("image_description")
            processed_text += f"{prefix} [Imagem oculta / caminho arquivo:'{image_data.get('image_path')}"  # keep path always
            if image_description not in (None, ""):
                processed_text += f" / descricao:'{image_description}']"
            else:
                processed_text += "']"
        elif block_label == "table":
            table_data = row.get("block_content", {})
            processed_text += f"{prefix} [Tabela '{table_data.get('table_name')}']"
            processed_text += f"\n{table_data.get('table_description')}"
            processed_text += f"\n{table_data.get('table_html')}\n"
        elif block_label in ["header", "footer"]:
            last_block_label = block_label
            continue
        else:
            processed_text += f"{prefix} " + str(row.get("block_content", "")) + "\n"

        last_block_label = block_label

    return processed_text