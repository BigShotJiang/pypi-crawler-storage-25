#
import nltk

try:
    nltk.data.find("stemmers/rslp")
except LookupError:
    nltk.download("rslp")
#

from rank_bm25 import BM25Okapi
import pandas as pd
import numpy as np
import re

# --- STEMMERS (PT + EN) ---
from nltk.stem import RSLPStemmer, PorterStemmer

stem_pt = RSLPStemmer()
stem_en = PorterStemmer()

def stem_token(tok: str):
    if not tok:
        return tok
    # heurística simples: se tiver acentos, é PT
    if re.search(r"[áéíóúàâêôãõç]", tok):
        return stem_pt.stem(tok)
    # heurística: palavras longas tendem a inglês
    if len(tok) > 3:
        return stem_en.stem(tok)
    return tok


# ----------------------------------
# STOPWORDS (mantive as suas)
# ----------------------------------

# Stopwords para pt-br
STOP_WORDS_PT_BR = {
    "a", "à", "ao", "aos", "as", "às", "com", "da", "das", "de", "dela", "dele", "deles", "delas",
    "do", "dos", "e", "em", "entre", "essa", "esse", "esta", "este", "eu", "ela", "ele", "eles",
    "elas", "isso", "isto", "já", "lhe", "lhes", "mais", "mas", "me", "mesmo", "meu", "meus",
    "minha", "minhas", "na", "nas", "não", "nem", "no", "nos", "nós", "nossa", "nossas", "nosso",
    "nossos", "num", "numa", "o", "os", "ou", "para", "pela", "pelas", "pelo", "pelos", "por",
    "qual", "quando", "que", "quem", "se", "sem", "seu", "seus", "sua", "suas", "são", "também",
    "te", "tem", "tendo", "tenho", "ter", "teu", "teus", "tua", "tuas", "um", "uma", "você", "vocês"
}

# Stopwords para inglês
STOP_WORDS_EN = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are",
    "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but",
    "by", "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for", "from",
    "further", "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him",
    "himself", "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself", "just", "me",
    "more", "most", "my", "myself", "no", "nor", "not", "now", "of", "off", "on", "once", "only",
    "or", "other", "our", "ours", "ourselves", "out", "over", "own", "same", "she", "should", "so",
    "some", "such", "than", "that", "the", "their", "theirs", "them", "themselves", "then", "there",
    "these", "they", "this", "those", "through", "to", "too", "under", "until", "up", "very", "was",
    "we", "were", "what", "when", "where", "which", "while", "who", "whom", "why", "with", "would",
    "you", "your", "yours", "yourself", "yourselves"
}


# ==================================================================================
#                                  FUNÇÃO PRINCIPAL
# ==================================================================================

def bm25_rank_dataframe(
    df: pd.DataFrame,
    query: str,
    columns: list[str],
    weights: list[float] | None = None,
    stopwords: set[str] | None = None,
    remove_tokens: set[str] | None = None,
    normalize: bool = True,
    apply_stemming: bool = True,
):
    """
    Versão v2 seletiva:
    - Regex generalizadas e seguras
    - Tag industrial com expansão robusta
    - Stemming opcional (PT + EN)
    - Normalização revisada
    """

    stopwords = stopwords or set()
    remove_tokens = remove_tokens or set()
    stopwords = {s.lower() for s in stopwords}

    # -------------------------------------
    # Pesos
    # -------------------------------------
    if weights is None:
        weights = np.linspace(1.0, 0.3, len(columns))
    else:
        weights = np.array(weights)
        if len(weights) != len(columns):
            raise ValueError("weights deve ter o mesmo tamanho que columns")

    # -------------------------------------
    # REGEX mais generalizadas e seguras
    # -------------------------------------

    # alfanumérico industrial (AQ30100J, LIT-1231023A, P74_30100F)
    alphanum_pattern = re.compile(r"[A-Za-z]+[0-9]+[A-Za-z]?")

    # números puros
    numeric_pattern = re.compile(r"\d+")

    # normalização segura (sem erro \s-_)
    normalization_regex = re.compile(r"[^0-9a-zA-Záéíóúàâêôãõç\s\-\_]")

    splitter = re.compile(r"[\s\-\_]+")

    # -------------------------------------
    # GERA PREFIXOS NUMÉRICOS
    # -------------------------------------
    def generate_numeric_prefixes(num: str):
        return [num[:i] for i in range(len(num), 0, -1)]

    # -------------------------------------
    # EXPANSÃO INDUSTRIAL GENERALIZADA
    # -------------------------------------
    def expand_equipment_tags(word: str):
        w = word.lower()
        tokens = set([w])

        # 1) grupos alfanuméricos ABC1234X
        for match in alphanum_pattern.findall(w):
            tokens.add(match)

            alpha = "".join(re.findall(r"[A-Za-z]+", match))
            numeric = "".join(re.findall(r"\d+", match))

            if alpha:
                tokens.add(alpha)
            if numeric:
                tokens.add(numeric)
                for p in generate_numeric_prefixes(numeric):
                    tokens.add(p)

            # se houver letra no final (1234f)
            if match[-1].isalpha():
                base = match[:-1]
                tokens.add(base)
                num2 = "".join(re.findall(r"\d+", base))
                for p in generate_numeric_prefixes(num2):
                    tokens.add(p)

        # 2) números isolados
        for num in numeric_pattern.findall(w):
            tokens.add(num)
            for p in generate_numeric_prefixes(num):
                tokens.add(p)

        # 3) splits por "-" ou "_"
        for part in splitter.split(w):
            if not part:
                continue
            tokens.add(part)
            if part.isdigit():
                for p in generate_numeric_prefixes(part):
                    tokens.add(p)

        return list(tokens)

    # -------------------------------------
    # PRÉ-PROCESSAMENTO + STEMMING
    # -------------------------------------
    def preprocess(text: str):
        if pd.isna(text):
            return ""

        t = str(text).lower()

        if normalize:
            t = normalization_regex.sub(" ", t)

        # remove tokens proibidos
        for tok in remove_tokens:
            t = t.replace(tok.lower(), " ")

        return t

    # -------------------------------------
    # TOKENIZAÇÃO FINAL
    # -------------------------------------
    def tokenize(text: str):
        t = preprocess(text)
        base_tokens = splitter.split(t)

        expanded = []
        for tok in base_tokens:
            if not tok:
                continue
            expanded.extend(expand_equipment_tags(tok))

        # remove stopwords
        expanded = [t for t in expanded if t not in stopwords]

        # stemming
        if apply_stemming:
            expanded = [stem_token(t) for t in expanded]

        return expanded

    # ==================================================================================
    #                              EXECUÇÃO DO BM25
    # ==================================================================================

    query_tokens = tokenize(query)

    total_score = np.zeros(len(df))

    for col, weight in zip(columns, weights):
        docs = df[col].fillna("").astype(str).map(tokenize).tolist()
        bm25 = BM25Okapi(docs)
        scores = np.array(bm25.get_scores(query_tokens))

        if scores.max() > 0:
            scores /= scores.max()

        total_score += scores * weight

    result = df.copy()
    result["bm25_score"] = total_score
    result = result.sort_values("bm25_score", ascending=False).reset_index(drop=True)
    return result
