from pdf2image import convert_from_path
import io
import os
from PyPDF2 import PdfReader, PdfWriter


def convert_pdf_page_to_image_with_max_bytes(pdf_path, page_number, max_bytes, dpi_min=50, dpi_max=400, output_format="PNG"):
    """
    Converte uma página do PDF em imagem, tentando limitar o tamanho em bytes ajustando o DPI.
    Retorna a imagem PIL.Image.
    """
    best_img = None
    best_dpi = dpi_min
    low, high = dpi_min, dpi_max
    while low <= high:
        dpi = (low + high) // 2
        images = convert_from_path(pdf_path, first_page=page_number, last_page=page_number, dpi=dpi)
        if not images:
            break
        img = images[0]
        buf = io.BytesIO()
        img.save(buf, format=output_format)
        size = buf.tell()
        if size <= max_bytes:
            best_img = img
            best_dpi = dpi
            low = dpi + 1  # tentar dpi maior
        else:
            high = dpi - 1  # tentar dpi menor
    if best_img is None:
        # Não conseguiu atingir o limite, retorna menor possível
        images = convert_from_path(pdf_path, first_page=page_number, last_page=page_number, dpi=dpi_min)
        if not images:
            raise ValueError("Não foi possível converter a página do PDF.")
        return images[0]
    return best_img

def split_pdf_by_size(input_pdf_path, output_dir, max_part_mb=20):
    """
    Divide o PDF em chunks de páginas, cada chunk <= max_part_mb.
    Se uma página for maior que o limite, salva em ignored_pages e loga o problema.
    Retorna (lista de caminhos dos chunks válidos, dict chunk->páginas originais).
    """
    os.makedirs(output_dir, exist_ok=True)
    reader = PdfReader(input_pdf_path)
    total_pages = len(reader.pages)
    ignored_dir = os.path.join(output_dir, "ignored_pages")
    os.makedirs(ignored_dir, exist_ok=True)
    log_path = os.path.join(ignored_dir, "ignored_pages.log")
    valid_chunks = []
    chunk_pages = []
    chunk_writer = PdfWriter()
    chunk_idx = 1
    chunk_to_pages = {}  # Mapeamento chunk -> páginas originais

    def save_chunk(pages, idx):
        if not pages:
            return None
        writer = PdfWriter()
        for p in pages:
            writer.add_page(reader.pages[p])
        chunk_filename = f"{os.path.splitext(os.path.basename(input_pdf_path))[0]}_chunk{idx}.pdf"
        chunk_path = os.path.join(output_dir, chunk_filename)
        with open(chunk_path, "wb") as f:
            writer.write(f)
        # Salva o mapeamento deste chunk para as páginas originais
        chunk_to_pages[chunk_filename] = pages.copy()
        return chunk_path

    with open(log_path, "w", encoding="utf-8") as logf:
        for i in range(total_pages):
            writer = PdfWriter()
            writer.add_page(reader.pages[i])
            import io
            buf = io.BytesIO()
            writer.write(buf)
            page_size_mb = buf.tell() / (1024 * 1024)
            if page_size_mb > max_part_mb:
                # Página sozinha já excede o limite
                page_path = os.path.join(ignored_dir, f"page_{i+1}.pdf")
                with open(page_path, "wb") as pf:
                    writer.write(pf)
                logf.write(
                    f"Página {i+1} ({page_size_mb:.2f} MB) excede o limite de {max_part_mb} MB e foi ignorada: {page_path}\n"
                )
                continue
            # Tenta adicionar ao chunk atual
            chunk_pages.append(i)
            chunk_writer.add_page(reader.pages[i])
            buf_chunk = io.BytesIO()
            chunk_writer.write(buf_chunk)
            new_chunk_size = buf_chunk.tell() / (1024 * 1024)
            if new_chunk_size > max_part_mb:
                # Remove última página, salva chunk, inicia novo
                chunk_pages.pop()
                chunk_writer = PdfWriter()
                for p in chunk_pages:
                    chunk_writer.add_page(reader.pages[p])
                chunk_path = save_chunk(chunk_pages, chunk_idx)
                if chunk_path:
                    valid_chunks.append(chunk_path)
                chunk_idx += 1
                # Inicia novo chunk com a página atual
                chunk_pages = [i]
                chunk_writer = PdfWriter()
                chunk_writer.add_page(reader.pages[i])
            # else: continua adicionando páginas ao chunk atual

        # Salva último chunk se houver páginas restantes
        if chunk_pages:
            chunk_path = save_chunk(chunk_pages, chunk_idx)
            if chunk_path:
                valid_chunks.append(chunk_path)

    # Não salva mais o chunk_page_map.json aqui!
    return valid_chunks, chunk_to_pages

