import logging
import asyncio
import time
from typing import List, Optional, Callable

async def async_ignore_error_with_these_strings(
    function: Callable,
    *args,
    errors_to_ignore: List[str],
    max_retrials: Optional[int] = None,
    time_to_wait: int = 1,
    **kwargs
):
    """
    Executa uma função async, ignorando erros que contenham certas strings, com opção de retrials e espera entre tentativas.
    """
    retrials = 0
    while True:
        try:
            return await function(*args, **kwargs)
        except Exception as e:
            error_str = str(e).lower()
            if any(err in error_str for err in errors_to_ignore):
                logging.error(e)
                retrials += 1
                if max_retrials is not None and retrials > max_retrials:
                    raise
                await asyncio.sleep(time_to_wait)
            else:
                raise


def sync_ignore_error_with_these_strings(
    function: Callable,
    *args,
    errors_to_ignore: List[str],
    max_retrials: Optional[int] = None,
    time_to_wait: int = 1,
    **kwargs
):
    """
    Executa uma função sync, ignorando erros que contenham certas strings, com opção de retrials e espera entre tentativas.
    """
    retrials = 0
    while True:
        try:
            return function(*args, **kwargs)
        except Exception as e:
            error_str = str(e).lower()
            if any(err in error_str for err in errors_to_ignore):
                logging.error(e)
                retrials += 1
                if max_retrials is not None and retrials > max_retrials:
                    raise
                time.sleep(time_to_wait)
            else:
                raise
