import re
from typing import Dict, List


DATE_LIKE = re.compile(
    r"""
    ^\d{1,2}[-/]
    (?:
        jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec|
        january|february|march|april|may|june|july|august|september|october|november|december|
        jan|fev|mar|abr|mai|jun|jul|ago|set|out|nov|dez|
        janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro
    )
    [-/]\d{2,4}$
    """,
    re.IGNORECASE | re.VERBOSE,
)
ITEMIZATION_LIKE = re.compile(r"^\d{1,3}(?:[.\-]\d{1,3})+[A-Z].*$", re.IGNORECASE)
PAGE_LIKE = re.compile(r"^PAGE\d+_[A-Z]+\d+$", re.IGNORECASE)
HEADER_LIKE = re.compile(r"^\d{1,3}[A-Z]{3,}(?:[/\-][A-Z]{3,})*$", re.IGNORECASE)
UPPER_WORD_LIKE = re.compile(r"^[A-Z]{6,}\d{0,3}$")

TAG_REGEX_STRINGS = [
    r"\b[A-Za-z]{4}-\d{8}\b",
    r"[A-Z0-9-]+-\d{6,}[A-Z0-9-]*",
    r"[A-Z]{1,4}\d{7}[A-Z]?",
    r"\b[A-Z]{2,4}-\d{7}(?:[A-Z]{1,2})?\b",
    r"\b[A-Z]{3,4}-\d{7}-\d{2}\b",
    r"\b[A-Z]{2}-\d{7}[A-Z]\d\b",
    r"\b[A-Z]{1,4}-\d{6}[A-Z]?\b",
    r"\b[A-Z]{1,4}-\d{1,3}[A-Z]\d{1,3}\b",
    r"\b\d{1,2}/\d{1,2}\"-[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}\b",
    r"\b\d{1,2}/\d{1,2}\"-[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}-[A-Z]{1,5}\b",
    r"\b\d{1,2} \d{1,2}/\d{1,2}\"-[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}\b",
    r"\b\d{1,2} \d{1,2}/\d{1,2}\"-[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}-[A-Z]{1,5}\b",
    r"\b\d{1,2}\"-[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}\b",
    r"\b\d{1,2}\"-[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}-[A-Z]{1,5}\b",
    r"\b\d{1,2}/\d{1,2}\"[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}-[A-Z]{1,5}\b",
    r"\b[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}\b",
    r"\b[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}-[A-Z]{1,5}\b",
    r"[A-Z]\d-\w\d{2}-\d{4}",
    r"[A-Z0-9]{1,5}-[A-Z0-9]{1,2}-\d{1,4}",
    r"\b\d+ \d/\d+\"-[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}\b",
    r"\b\d+ \d/\d+\"-[A-Z]{1,4}-[A-Z0-9]{1,5}-\d{1,4}-[A-Z]{1,5}\b",
]

TAG_PATTERNS = [re.compile(expr, re.IGNORECASE) for expr in TAG_REGEX_STRINGS]


def find_tag_spans(text: str) -> Dict[str, List[List[int]]]:
    """
    Extract industrial tag codes using the curated patterns from tags_regex.py.

    Returns a mapping from the normalized tag (uppercased) to the list of [start, end)
    spans (Python slicing semantics) where it appears in the input.
    """

    if not text:
        return {}

    tags: Dict[str, List[List[int]]] = {}

    for pattern in TAG_PATTERNS:
        for match in pattern.finditer(text):
            raw_tag = match.group(0)

            # Skip obvious non-tags that resemble itemization numbers or dates.
            if ITEMIZATION_LIKE.match(raw_tag):
                continue
            if DATE_LIKE.match(raw_tag):
                continue
            if PAGE_LIKE.match(raw_tag):
                continue
            if HEADER_LIKE.match(raw_tag):
                continue
            # Skip plain uppercase words (optionally ending with digits) when no separators are present.
            if not any(sep in raw_tag for sep in "-_.+/") and UPPER_WORD_LIKE.match(raw_tag):
                continue

            # Skip very short tokens without separators to avoid false positives like "A1".
            if not any(sep in raw_tag for sep in "-_. /") and len(raw_tag) < 4:
                continue

            tag_key = raw_tag.upper()
            start, end = match.span()
            spans = tags.setdefault(tag_key, [])
            if [start, end] not in spans:
                spans.append([start, end])

    return tags
