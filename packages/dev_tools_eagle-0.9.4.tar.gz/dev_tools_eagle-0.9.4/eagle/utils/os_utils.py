import os

def ensure_dir_exists(dir_path):
    """
    Create the directory if it does not exist.
    """
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
