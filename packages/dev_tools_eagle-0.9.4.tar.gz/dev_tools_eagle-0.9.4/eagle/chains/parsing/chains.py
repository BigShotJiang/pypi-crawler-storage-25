import os
from typing import ClassVar, Dict, List, Literal, Optional

from eagle.utils.image_utils import object_to_image_url
from eagle.utils.prompt_utils import EagleJsonOutputParser, load_prompt
from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.messages import HumanMessage
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda, RunnableSequence
from pydantic import BaseModel, Field, model_validator

PROMPT_DIR = os.path.join(os.path.dirname(__file__), "prompts")

PPTX_PROMPT_TEMPLATES: Dict[str, str] = {
	"pt-br": load_prompt(PROMPT_DIR, "page_parsing_pptx_pt_br.txt"),
	"en": load_prompt(PROMPT_DIR, "page_parsing_pptx_en.txt"),
}

PDF_PROMPT_TEMPLATES: Dict[str, str] = {
	"pt-br": load_prompt(PROMPT_DIR, "page_parsing_pdf_pt_br.txt"),
	"en": load_prompt(PROMPT_DIR, "page_parsing_pdf_en.txt"),
}


class ParsingBlock(BaseModel):
	type: Literal["text", "image"]
	content: Optional[str] = Field(
		default=None,
		description="Extracted text when the block type is text, or image description when the block type is image.",
	)

	@model_validator(mode="after")
	def validate_block(self) -> "ParsingBlock":
		if self.type == "text":
			if not self.content or not self.content.strip():
				raise ValueError("Text blocks must contain non-empty content")
			return self

		if self.type == "image":
			if not self.content or not self.content.strip():
				raise ValueError("Image blocks must contain non-empty content (description)")
			return self

		return self


class PageParsingOutputSchemaPTBR(BaseModel):
	blocos: List[ParsingBlock]


class PageParsingOutputSchemaEN(BaseModel):
	blocks: List[ParsingBlock]


class PageParsingOutputParser(EagleJsonOutputParser):
	CONVERTION_SCHEMA: ClassVar[dict] = {
		"pt-br": {
			"class_for_parsing": PageParsingOutputSchemaPTBR,
			"convertion_schema": {
				"blocos": {"target_key": "blocos", "value_mapping": {}},
			},
		},
		"en": {
			"class_for_parsing": PageParsingOutputSchemaEN,
			"convertion_schema": {
				"blocks": {"target_key": "blocos", "value_mapping": {}},
			},
		},
	}

	TARGET_SCHEMA: BaseModel = PageParsingOutputSchemaPTBR


def create_parsing_chain(
	prompt_language: str,
	llm: BaseLanguageModel,
	use_structured_output: bool = False,
	extension: Optional[str] = "pptx",
) -> RunnableSequence:
	PROMPT_TEMPLATES = {
		"pptx": PPTX_PROMPT_TEMPLATES,
		"pdf": PDF_PROMPT_TEMPLATES,
	}
	if extension not in PROMPT_TEMPLATES:
		raise ValueError(f"Unsupported extension: {extension}. Supported extensions are: {list(PROMPT_TEMPLATES.keys())}")

	prompt = PromptTemplate.from_template(
		PROMPT_TEMPLATES[extension][prompt_language],
		template_format="jinja2",
	)

	output_parser = PageParsingOutputParser(
		source_lang=prompt_language,
		llm=llm,
		use_structured_output=use_structured_output,
	)

	_parse = RunnableLambda(lambda x: output_parser.parse(x))

	def _prepare_message(inputs: Dict[str, object]) -> List[HumanMessage]:
		image = inputs["image"]
		context = str(inputs.get("context", "") or "")
		image_b64_url = object_to_image_url(image, format="JPEG")
		prompt_text = prompt.format(context=context)

		message_content = [{"type": "text", "text": prompt_text}]
		if image_b64_url:
			message_content.append(
				{"type": "image_url", "image_url": {"url": image_b64_url}}
			)

		return [HumanMessage(content=message_content)]

	chain = RunnableLambda(_prepare_message) | llm | _parse
	return chain


__all__ = ["create_parsing_chain"]