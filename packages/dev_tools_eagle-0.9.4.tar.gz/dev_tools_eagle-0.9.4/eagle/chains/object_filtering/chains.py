import os
from typing import ClassVar, Dict, List

from eagle.utils.prompt_utils import EagleJsonOutputParser, load_prompt
from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda, RunnableSequence
from pydantic import BaseModel

PROMPT_DIR = os.path.join(os.path.dirname(__file__), "prompts")

OBJECT_FILTERING_PROMPT_TEMPLATES: Dict[str, str] = {
    "pt-br": load_prompt(PROMPT_DIR, "object_filtering_pt_br.txt"),
    "en": load_prompt(PROMPT_DIR, "object_filtering_en.txt"),
}


class KeepObject(BaseModel):
    index: int
    name: str
    description: str


class ObjectFilteringOutputSchema(BaseModel):
    keep_objects: List[KeepObject]


class ObjectFilteringOutputParser(EagleJsonOutputParser):
    CONVERTION_SCHEMA: ClassVar[dict] = {
        "pt-br": {
            "class_for_parsing": ObjectFilteringOutputSchema,
            "convertion_schema": {
                "keep_objects": {"target_key": "keep_objects", "value_mapping": {}},
            },
        },
        "en": {
            "class_for_parsing": ObjectFilteringOutputSchema,
            "convertion_schema": {
                "keep_objects": {"target_key": "keep_objects", "value_mapping": {}},
            },
        },
    }

    TARGET_SCHEMA: BaseModel = ObjectFilteringOutputSchema


def create_object_filtering_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
    use_structured_output: bool = False,
) -> RunnableSequence:
    if prompt_language not in OBJECT_FILTERING_PROMPT_TEMPLATES:
        raise ValueError(f"Unsupported language: {prompt_language}. Supported languages are: {list(OBJECT_FILTERING_PROMPT_TEMPLATES.keys())}")

    prompt = PromptTemplate.from_template(
        OBJECT_FILTERING_PROMPT_TEMPLATES[prompt_language],
        template_format="jinja2",
    )

    output_parser = ObjectFilteringOutputParser(
        source_lang=prompt_language,
        llm=llm,
        use_structured_output=use_structured_output,
    )

    _parse = RunnableLambda(lambda x: output_parser.parse(x))

    def _prepare_input(inputs: Dict[str, object]) -> str:
        response_input = inputs["response_input"]
        response_output = inputs["response_output"]
        objects = inputs["objects"]

        objects_str = "\n".join([
            f"Object {i}: name='{obj['object_name']}', description='{obj['description']}', type='{obj['object_type']}'"
            for i, obj in enumerate(objects)
        ])

        prompt_text = prompt.format(
            response_input=response_input,
            response_output=response_output,
            objects=objects_str
        )

        return prompt_text

    chain = RunnableLambda(_prepare_input) | llm | _parse
    return chain


__all__ = ["create_object_filtering_chain"]