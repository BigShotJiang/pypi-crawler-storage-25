import os
from typing import Dict

from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda, RunnableSequence

JSON_CORRECTION_PROMPT_TEMPLATES: Dict[str, str] = {
    "pt-br": """Corrija o JSON fornecido que apresenta o seguinte erro: {{error}}.

JSON: {{json_string}}

Retorne apenas o JSON corrigido, pronto para carregamento, sem marcações ```json...``` nem nada do tipo.""",
    "en": """Correct the provided JSON that has the following error: {{error}}.

JSON: {{json_string}}

Return only the corrected JSON, ready for loading, without any ```json...``` markings or anything like that.""",
}


def create_json_correction_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
) -> RunnableSequence:
    if prompt_language not in JSON_CORRECTION_PROMPT_TEMPLATES:
        raise ValueError(f"Unsupported language: {prompt_language}. Supported languages are: {list(JSON_CORRECTION_PROMPT_TEMPLATES.keys())}")

    prompt = PromptTemplate.from_template(
        JSON_CORRECTION_PROMPT_TEMPLATES[prompt_language],
        template_format="jinja2",
    )

    output_parser = StrOutputParser()

    def _prepare_message(inputs: Dict[str, str]) -> str:
        json_string = inputs["json_string"]
        error = inputs["error"]
        prompt_text = prompt.format(json_string=json_string, error=error)
        return prompt_text

    chain = RunnableLambda(_prepare_message) | llm | output_parser
    return chain


__all__ = ["create_json_correction_chain"]