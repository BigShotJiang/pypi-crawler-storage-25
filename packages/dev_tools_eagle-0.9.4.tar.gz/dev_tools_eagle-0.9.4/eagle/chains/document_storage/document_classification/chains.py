import json
import os
from typing import ClassVar, Dict
from operator import itemgetter

from eagle.utils.prompt_utils import EagleJsonOutputParser
from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda, RunnableSequence
from pydantic import BaseModel

from eagle.utils.prompt_utils import load_prompt


PROMPT_DIR = os.path.join(os.path.dirname(__file__), "prompts")

PROMPT_TEMPLATES: Dict[str, Dict[str, str]] = {
    "pt-br": {
        "extract_document_metadata": load_prompt(
            PROMPT_DIR,
            "extract_document_metadata_pt_br.txt",
        ),
    },
    "en": {
        "extract_document_metadata": load_prompt(
            PROMPT_DIR,
            "extract_document_metadata_en.txt",
        ),
    },
}

class DocumentMetadataOutputModel(BaseModel):
    """Container to hold arbitrary document metadata JSON."""

    model_config = {"extra": "allow"}

class DocumentMetadataOutputParser(EagleJsonOutputParser):
    """Parse the raw JSON metadata returned by the LLM."""

    CONVERTION_SCHEMA: ClassVar[dict] = {
        "pt-br": {
            "class_for_parsing": DocumentMetadataOutputModel,
            "convertion_schema": {},
        },
        "en": {
            "class_for_parsing": DocumentMetadataOutputModel,
            "convertion_schema": {},
        },
    }

    TARGET_SCHEMA: BaseModel = DocumentMetadataOutputModel

def create_extract_document_metadata_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
) -> RunnableSequence:
    templates = PROMPT_TEMPLATES[prompt_language]
    prompt = PromptTemplate.from_template(
        templates["extract_document_metadata"],
        template_format="jinja2",
    )

    output_parser = DocumentMetadataOutputParser(
        source_lang=prompt_language,
        llm=llm,
        use_structured_output=False,
    )

    def output_parse(x):
        return output_parser.parse(x)

    _parse = RunnableLambda(output_parse)

    chain = (
        {
            "document_as_text": itemgetter("document_as_text"),
            "metadata_schema": itemgetter("metadata_schema"),
            "metadata_schema_str": RunnableLambda(lambda x: json.dumps(x["metadata_schema"], indent=2)),
        }
        | prompt
        | llm
        | _parse
        | RunnableLambda(lambda output: output.model_dump())
    )

    return chain
