import pytest
from pydantic import BaseModel
from langchain_core.messages import AIMessage
from langchain_core.runnables import RunnableLambda
from eagle.chains.plan_evaluation import  create_plan_evaluation_chain, PlanEvaluationOutputSchemaEN

from langchain_core.messages import AIMessage

class RunnableLLMAdapter:
    """
    Adapter usado só em teste:
    - torna a FakeLLM "pipeável" (callable) para `| llm`
    - mantém `with_structured_output` para o parser
    """
    def __init__(self, fake_llm):
        self._fake = fake_llm

    def __call__(self, _input):
        # O pipe vai chamar isso. A gente ignora o input e devolve o que a FakeLLM devolveria.
        # Tentamos os jeitos mais comuns sem forçar mudança na FakeLLM.
        if hasattr(self._fake, "invoke"):
            return self._fake.invoke(_input)
        if hasattr(self._fake, "__call__"):
            return self._fake(_input)

        # fallback: se sua FakeLLM só guarda json_text internamente
        json_text = getattr(self._fake, "json_text", None) or getattr(self._fake, "_json_text", None)
        if json_text is None:
            raise RuntimeError("FakeLLM não tem invoke/__call__ nem atributo json_text/_json_text.")
        return AIMessage(content=json_text)

    def with_structured_output(self, schema):
        # O output parser chama isso quando use_structured_output=True
        if not hasattr(self._fake, "with_structured_output"):
            raise RuntimeError("Sua FakeLLM não implementa with_structured_output(), mas o teste pediu structured_output=True.")
        return self._fake.with_structured_output(schema)


class FakeLLM:
    """
    Fake LLM compatível com o pipe do LangChain.
    - No modo normal: retorna AIMessage(content=<json>).
    - No modo structured: retorna um model Pydantic já validado (via invoke).
    """

    def __init__(self, json_text: str = None, structured_obj: BaseModel = None):
        self._json_text = json_text
        self._structured_obj = structured_obj

    # permite: | llm
    def __or__(self, other):
        return RunnableLambda(lambda x: self.invoke(x)) | other

    # permite: prompt | llm
    def invoke(self, _input, config=None, **kwargs):
        if self._json_text is None:
            raise RuntimeError("FakeLLM(json_text=...) não foi configurado.")
        return AIMessage(content=self._json_text)

    def with_structured_output(self, schema):
        # devolve um "LLM" que ignora o input e retorna o objeto structured
        parent = self

        class _StructuredLLM:
            def invoke(self, messages, config=None, **kwargs):
                if parent._structured_obj is None:
                    raise RuntimeError("FakeLLM(structured_obj=...) não foi configurado.")
                # garante tipo compatível com schema esperado
                if isinstance(parent._structured_obj, schema):
                    return parent._structured_obj
                # tenta converter se vier em dict
                if isinstance(parent._structured_obj, dict):
                    return schema(**parent._structured_obj)
                raise TypeError(f"structured_obj incompatível. Esperado {schema}, veio {type(parent._structured_obj)}")

        return _StructuredLLM()


def test_language_invalida_dispara_value_error():
    llm = FakeLLM(json_text='{"description":"ok","score":1}')
    with pytest.raises(ValueError) as e:
        create_plan_evaluation_chain(prompt_language="es", llm=llm)
    assert "Unsupported prompt language" in str(e.value)


def test_ptbr_sem_structured_converte_para_schema_alvo():
    # resposta em PT-BR como a prompt manda
    fake = FakeLLM(json_text='{"descricao":"Plano coerente e completo.","nota":0.9}')
    llm = RunnableLLMAdapter(fake)

    chain = create_plan_evaluation_chain(prompt_language="pt-br", llm=llm, use_structured_output=False)

    out = chain.invoke({"plan": "Passo 1... Passo 2...", "evaluation_criteria": "Clareza, completude, viabilidade"})
    # o parser converte para TARGET_SCHEMA (EN)
    assert isinstance(out, PlanEvaluationOutputSchemaEN)
    assert out.description == "Plano coerente e completo."
    assert out.score == 0.9


def test_en_sem_structured_retorna_schema_alvo_direto():
    fake = FakeLLM(json_text='{"description":"Good plan.","score":0.7}')
    llm = RunnableLLMAdapter(fake)

    chain = create_plan_evaluation_chain(prompt_language="en", llm=llm, use_structured_output=False)

    out = chain.invoke({"plan": "Step 1... Step 2...", "evaluation_criteria": "Clarity, completeness, feasibility"})
    assert isinstance(out, PlanEvaluationOutputSchemaEN)
    assert out.description == "Good plan."
    assert out.score == 0.7


def test_structured_output_true_usa_with_structured_output():
    structured = PlanEvaluationOutputSchemaEN(description="Excelente.", score=1.0)

    fake = FakeLLM(
        json_text='{"ignored":"because structured is used"}',
        structured_obj=structured
    )
    llm = RunnableLLMAdapter(fake)

    chain = create_plan_evaluation_chain(prompt_language="en", llm=llm, use_structured_output=True)

    out = chain.invoke({"plan": "Do X then Y", "evaluation_criteria": "All good"})
    assert isinstance(out, PlanEvaluationOutputSchemaEN)
    assert out.description == "Excelente."
    assert out.score == 1.0


def test_ptbr_json_invalido_dispara_erro_de_parse():
    fake = FakeLLM(json_text='{"descricao":"faltou a nota"}')  # nota ausente
    llm = RunnableLLMAdapter(fake)

    chain = create_plan_evaluation_chain(prompt_language="pt-br", llm=llm, use_structured_output=False)

    with pytest.raises(Exception):
        chain.invoke({"plan": "xpto", "evaluation_criteria": "xpto"})