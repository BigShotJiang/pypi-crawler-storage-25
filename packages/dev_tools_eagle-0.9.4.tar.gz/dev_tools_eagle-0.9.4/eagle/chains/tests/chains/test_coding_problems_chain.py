import pytest
from langchain.schema import AIMessage
from eagle.chains.coding_problems_chain import create_explanation_chain
from eagle.models.tests.models.test_chat_model import FakeChatModel


def patch_fake_to_return_message(monkeypatch):
    original = FakeChatModel._agenerate

    async def wrapped(self, messages, **kwargs):
        return await original(self, messages, **kwargs)

    monkeypatch.setattr(FakeChatModel, "_agenerate", wrapped)

@pytest.mark.asyncio
async def test_explanation_chain_pt_br(monkeypatch):
    patch_fake_to_return_message(monkeypatch)

    fake_llm = FakeChatModel(
        responses=[
            "A execução falhou porque o código depende de uma variável inexistente."
        ]
    )

    chain = create_explanation_chain(
        prompt_language="pt-br",
        llm=fake_llm
    )

    result = await chain.ainvoke({
        "plan": "Criar função X que usa variável Y",
        "previous_error_explanation": "NameError: Y is not defined"
    })

    assert "variável inexistente" in result


@pytest.mark.asyncio
async def test_explanation_chain_en(monkeypatch):
    patch_fake_to_return_message(monkeypatch)

    fake_llm = FakeChatModel(
        responses=[
            "The execution failed because the code relies on an undefined variable."
        ]
    )

    chain = create_explanation_chain(
        prompt_language="en",
        llm=fake_llm
    )

    result = await chain.ainvoke({
        "plan": "Create function X using variable Y",
        "previous_error_explanation": "NameError: Y is not defined"
    })

    assert "undefined variable" in result

def test_explanation_chain_invalid_language():
    fake_llm = FakeChatModel(responses=["irrelevant"])

    with pytest.raises(ValueError) as exc:
        create_explanation_chain(
            prompt_language="es",
            llm=fake_llm
        )

    assert "Unsupported prompt language" in str(exc.value)
