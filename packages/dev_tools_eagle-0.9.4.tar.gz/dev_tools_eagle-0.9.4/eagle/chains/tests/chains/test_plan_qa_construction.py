import pytest

from eagle.chains.plan_processing import (
    create_plan_processing_chain,
    PlanProcessingOutputSchemaEN,
)

class FakeLLM:
    def __init__(self, json_text: str, structured_obj=None):
        self.json_text = json_text
        self.structured_obj = structured_obj

    def invoke(self, _input, config=None):
        class _Msg:
            def __init__(self, content):
                self.content = content
        return _Msg(self.json_text)

    def with_structured_output(self, _schema):
        fake = self

        class _Structured:
            def invoke(self, _input, config=None):
                return fake.structured_obj

        return _Structured()


class RunnableLLMAdapter:
    def __init__(self, fake_llm):
        self.fake_llm = fake_llm

    def invoke(self, input, config=None):
        return self.fake_llm.invoke(input, config=config)

    def with_structured_output(self, schema):
        return self.fake_llm.with_structured_output(schema)

    def __call__(self, input):
        return self.invoke(input)


def _dump(model):
    if hasattr(model, "model_dump"):
        return model.model_dump()

    return dict(model)


def test_language_invalida_dispara_value_error():
    llm = RunnableLLMAdapter(FakeLLM(json_text="{}"))
    with pytest.raises(ValueError):
        create_plan_processing_chain(prompt_language="xx", llm=llm)


def test_ptbr_sem_structured_converte_para_schema_alvo():
    fake = FakeLLM(
        json_text="""
        {
          "planos": [
            {"plano": "Fazer A depois B", "pergunta": "Qual a ordem correta?"},
            {"plano": "Checar pré-requisitos", "pergunta": "O que precisa antes?"}
          ]
        }
        """
    )
    llm = RunnableLLMAdapter(fake)

    chain = create_plan_processing_chain(
        prompt_language="pt-br",
        llm=llm,
        use_structured_output=False,
    )

    out = chain.invoke({"text": "Algum texto", "number_of_questions": 2})

    assert isinstance(out, PlanProcessingOutputSchemaEN)

    data = _dump(out)
    assert "plans" in data
    assert isinstance(data["plans"], list)
    assert len(data["plans"]) == 2

    first = data["plans"][0]
    assert first.get("plan") == "Fazer A depois B"
    assert first.get("question") == "Qual a ordem correta?"


def test_en_sem_structured_retorna_schema_alvo_direto():
    fake = FakeLLM(
        json_text="""
        {
          "plans": [
            {"plan": "Do X then Y", "question": "What comes first?"},
            {"plan": "Validate inputs", "question": "What should be validated?"}
          ]
        }
        """
    )
    llm = RunnableLLMAdapter(fake)

    chain = create_plan_processing_chain(
        prompt_language="en",
        llm=llm,
        use_structured_output=False,
    )

    out = chain.invoke({"text": "Some text", "number_of_questions": 2})

    assert isinstance(out, PlanProcessingOutputSchemaEN)

    data = _dump(out)
    assert len(data["plans"]) == 2
    assert data["plans"][0]["plan"] == "Do X then Y"
    assert data["plans"][0]["question"] == "What comes first?"


def test_structured_output_true_retorna_objeto_structurado():
    structured = PlanProcessingOutputSchemaEN.model_validate(
        {
            "plans": [
                {"plan": "Structured plan", "question": "Structured question?"}
            ]
        }
    )

    fake = FakeLLM(
        json_text='{"ignored":"because structured output is used"}',
        structured_obj=structured,
    )
    llm = RunnableLLMAdapter(fake)

    chain = create_plan_processing_chain(
        prompt_language="en",
        llm=llm,
        use_structured_output=True,
    )

    out = chain.invoke({"text": "Anything", "number_of_questions": 1})

    assert isinstance(out, PlanProcessingOutputSchemaEN)
    data = _dump(out)

    assert data["plans"][0]["plan"] == "Structured plan"
    assert data["plans"][0]["question"] == "Structured question?"


def test_ptbr_json_invalido_dispara_erro_de_parse():
    fake = FakeLLM(
        json_text="""
        {
          "planos": [
            {"plano": "Plano sem pergunta"}
          ]
        }
        """
    )
    llm = RunnableLLMAdapter(fake)

    chain = create_plan_processing_chain(
        prompt_language="pt-br",
        llm=llm,
        use_structured_output=False,
    )

    with pytest.raises(Exception):
        chain.invoke({"text": "Algum texto", "number_of_questions": 1})