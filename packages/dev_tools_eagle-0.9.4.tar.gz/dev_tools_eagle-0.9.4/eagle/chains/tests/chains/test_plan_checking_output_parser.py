import pytest
from langchain_core.messages import AIMessage

from eagle.chains.plan_processing import (
    PlanProcessingOutputParser,
    PlanCheckingOutputParser,
)


def test_plan_processing_parser_ptbr_real_llm_style():
    parser = PlanProcessingOutputParser(
        source_lang="pt-br",
        llm=None,
        use_structured_output=False
    )

    fake_llm_output = """
    Aqui está o resultado solicitado:

    ```json
    {
        "planos": [
            {
                "pergunta": "O que fazer em caso de incêndio?",
                "plano": "Evacuar imediatamente.",
                "lixo": "campo que não existe"
            },
            {
                "pergunta": "Como agir em caso de fumaça?",
                "plano": "Rastejar pelo chão."
            }
        ]
    }
    ```

    Espero que ajude!
    """

    result = parser.parse(AIMessage(content=fake_llm_output))

    assert len(result.plans) == 2
    assert result.plans[0].question == "O que fazer em caso de incêndio?"
    assert result.plans[0].plan == "Evacuar imediatamente."


def test_plan_processing_parser_en_real_llm_style():
    parser = PlanProcessingOutputParser(
        source_lang="en",
        llm=None,
        use_structured_output=False
    )

    fake_llm_output = """
    Sure! Here is the JSON:

    {
        "plans": [
            {
                "question": "What to do in case of fire?",
                "plan": "Evacuate immediately."
            },
            {
                "question": "What to do if trapped?",
                "plan": "Signal for help at the window."
            }
        ]
    }

    Let me know if you need anything else.
    """

    result = parser.parse(AIMessage(content=fake_llm_output))

    assert len(result.plans) == 2
    assert result.plans[1].question == "What to do if trapped?"


def test_plan_checking_parser_ptbr_real_llm_style():
    parser = PlanCheckingOutputParser(
        source_lang="pt-br",
        llm=None,
        use_structured_output=False
    )

    fake_llm_output = """
    Resultado da análise:

    ```json
    {
        "perguntas_a_remover": ["Pergunta X"],
        "planos_a_adicionar": [
            {
                "pergunta": "Nova pergunta",
                "plano": "Novo plano detalhado"
            }
        ]
    }
    ```
    """

    result = parser.parse(AIMessage(content=fake_llm_output))

    assert result.questions_to_remove == ["Pergunta X"]
    assert result.plans_to_add[0].question == "Nova pergunta"


def test_plan_processing_parser_invalid_json():
    parser = PlanProcessingOutputParser(
        source_lang="pt-br",
        llm=None,
        use_structured_output=False
    )

    fake_llm_output = "isso aqui não é json nem com reza brava"

    with pytest.raises(Exception):
        parser.parse(AIMessage(content=fake_llm_output))

@pytest.mark.asyncio
async def test_plan_processing_chain_full_flow(monkeypatch):
    from eagle.chains.plan_processing import create_plan_processing_chain
    from eagle.models.tests.models.test_chat_model import FakeChatModel

    fake_llm = FakeChatModel(
        responses=["""
        {
            "planos": [
                {
                    "pergunta": "O que fazer em caso de incêndio?",
                    "plano": "Evacuar imediatamente."
                }
            ]
        }
        """]
    )

    chain = create_plan_processing_chain(
        prompt_language="pt-br",
        llm=fake_llm
    )

    result = await chain.ainvoke({
        "question": "incêndio"
    })

    assert result.plans[0].question == "O que fazer em caso de incêndio?"
