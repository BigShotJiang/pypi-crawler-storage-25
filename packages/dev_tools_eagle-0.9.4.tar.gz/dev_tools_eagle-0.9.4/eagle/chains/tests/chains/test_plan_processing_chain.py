import pytest
from eagle.chains.plan_processing import create_plan_processing_chain
from eagle.chains.plan_qa import create_qa_chain

@pytest.mark.asyncio
async def test_plan_processing_chain_en(fake_llm):    
    chain = create_plan_processing_chain(
        prompt_language="en",
        llm=fake_llm
    )

@pytest.mark.asyncio
async def test_plan_processing_chain_pt_br(fake_llm_plan_ptbr):
    chain = create_plan_processing_chain(
        prompt_language="pt-br",
        llm=fake_llm_plan_ptbr
    )


@pytest.mark.asyncio
async def test_qa_chain_pt_br(fake_llm_qa_ptbr):
    chain = create_qa_chain(
        prompt_language="pt-br",
        llm=fake_llm_qa_ptbr
    )
