import pytest
from eagle.models.tests.models.test_chat_model import FakeChatModel

@pytest.fixture
def fake_llm():
    return FakeChatModel(responses=["ok"])

@pytest.fixture(autouse=True)
def patch_llm_model(monkeypatch):
    from eagle.models import generators

    def _factory(*args, **kwargs):
        # SEMPRE cria um fake novo, limpo
        return FakeChatModel()

    monkeypatch.setattr(
        generators,
        "get_llm_model",
        _factory
    )

@pytest.fixture
def fake_llm_plan_ptbr():
    return FakeChatModel(
        responses=[
            """
            [
              {"question": "O que fazer em caso de incêndio?", "plan": "Evacuar imediatamente."},
              {"question": "Para quem ligar?", "plan": "Ligar para emergência."}
            ]
            """
        ]
    )


@pytest.fixture
def fake_llm_qa_ptbr():
    return FakeChatModel(
        responses=[
            "Use um extintor adequado para eletricidade e chame os serviços de emergência."
        ]
    )
