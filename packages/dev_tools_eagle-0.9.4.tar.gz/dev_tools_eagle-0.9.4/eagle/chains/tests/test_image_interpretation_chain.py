import pytest
from unittest.mock import MagicMock

from langchain_core.runnables import RunnableLambda
from langchain_core.messages import HumanMessage

from eagle.chains.image_interpretation import (
    create_image_interpretation_chain,
    create_image_crop_suggestion_chain,
    ImageInterpretationOutputParser,
    ImageCropSuggestionOutputParser,
)

# Um "LLM" fake: é só um Runnable callable que ignora o conteúdo e retorna um JSON string
def make_fake_llm(json_text: str):
    return RunnableLambda(lambda _messages: json_text)

@pytest.fixture
def fake_image():
    # pode ser qualquer objeto, porque object_to_image_url vai ser mockado
    return object()

@pytest.fixture
def patch_image_url(monkeypatch):
    monkeypatch.setattr(
        "eagle.chains.image_interpretation.object_to_image_url",
        lambda _img, format="JPEG": "data:image/jpeg;base64,FAKE",
    )

@pytest.fixture
def patch_interpretation_parse(monkeypatch):
    parse_mock = MagicMock(return_value={"name": "N", "description": "D", "answer": "A"})
    monkeypatch.setattr(ImageInterpretationOutputParser, "parse", parse_mock)
    return parse_mock

@pytest.fixture
def patch_crop_parse(monkeypatch):
    parse_mock = MagicMock(return_value={"x1": 0.1, "y1": 0.2, "x2": 0.9, "y2": 0.8})
    monkeypatch.setattr(ImageCropSuggestionOutputParser, "parse", parse_mock)
    return parse_mock


# -----------------------
# create_image_interpretation_chain
# -----------------------

def test_create_image_interpretation_chain_invalid_language_raises(fake_image):
    llm = make_fake_llm('{"name":"x","description":"y","answer":"z"}')
    with pytest.raises(ValueError) as exc:
        create_image_interpretation_chain("es", llm)
    assert "Unsupported prompt language" in str(exc.value)

def test_image_interpretation_chain_builds_human_message_and_parses(
    fake_image, patch_image_url, patch_interpretation_parse
):
    llm = make_fake_llm('{"name":"x","description":"y","answer":"z"}')
    chain = create_image_interpretation_chain("en", llm, use_structured_output=False)

    out = chain.invoke({"image": fake_image, "context": "ctx"})

    # retorno final vem do parse mockado
    assert out == {"name": "N", "description": "D", "answer": "A"}

    # garante que parse foi chamado com o retorno do llm
    patch_interpretation_parse.assert_called_once()
    called_with = patch_interpretation_parse.call_args[0][0]
    assert isinstance(called_with, str)
    assert '"name"' in called_with

def test_image_interpretation_chain_includes_text_and_image(fake_image, patch_image_url, monkeypatch):
    # aqui a gente testa o prepare_message sem "acessar" função interna:
    # intercepta o LLM para inspecionar os messages que chegam nele.
    received = {}

    def spy_llm(messages):
        received["messages"] = messages
        return '{"name":"x","description":"y","answer":"z"}'

    llm = RunnableLambda(spy_llm)

    # mock do parse pra não depender do parser real
    monkeypatch.setattr(ImageInterpretationOutputParser, "parse", lambda self, x: {"ok": True})

    chain = create_image_interpretation_chain("pt-br", llm)
    out = chain.invoke({"image": fake_image, "context": "meu contexto"})

    assert out == {"ok": True}
    assert "messages" in received
    msgs = received["messages"]
    assert isinstance(msgs, list) and len(msgs) == 1
    assert isinstance(msgs[0], HumanMessage)

    content = msgs[0].content
    assert isinstance(content, list) and len(content) == 2
    assert content[0]["type"] == "text"
    assert "meu contexto" in content[0]["text"]
    assert content[1]["type"] == "image_url"
    assert content[1]["image_url"]["url"].startswith("data:image/jpeg;base64,")


# -----------------------
# create_image_crop_suggestion_chain
# -----------------------

def test_create_image_crop_suggestion_chain_invalid_language_raises(fake_image):
    llm = make_fake_llm('{"x1":0,"y1":0,"x2":1,"y2":1}')
    with pytest.raises(ValueError) as exc:
        create_image_crop_suggestion_chain("fr", llm)
    assert "Unsupported prompt language" in str(exc.value)

def test_image_crop_suggestion_chain_builds_and_parses(
    fake_image, patch_image_url, patch_crop_parse
):
    llm = make_fake_llm('{"x1":0.1,"y1":0.2,"x2":0.9,"y2":0.8}')
    chain = create_image_crop_suggestion_chain("en", llm)

    out = chain.invoke({"image": fake_image, "context": "crop pls"})

    assert out == {"x1": 0.1, "y1": 0.2, "x2": 0.9, "y2": 0.8}
    patch_crop_parse.assert_called_once()
