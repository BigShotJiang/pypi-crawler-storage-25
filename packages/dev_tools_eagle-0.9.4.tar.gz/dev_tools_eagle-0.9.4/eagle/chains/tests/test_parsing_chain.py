from unittest.mock import MagicMock

import pytest
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.runnables import RunnableLambda

from eagle.chains.parsing.chains import (
    PageParsingOutputParser,
    create_parsing_chain,
)


@pytest.fixture
def fake_image():
    return object()


@pytest.fixture
def patch_image_url(monkeypatch):
    monkeypatch.setattr(
        "eagle.chains.parsing.chains.object_to_image_url",
        lambda _img, format="JPEG": "data:image/jpeg;base64,FAKE",
    )


def test_create_parsing_chain_invalid_language_raises():
    llm = RunnableLambda(lambda _messages: AIMessage(content='{"blocks": []}'))

    with pytest.raises(ValueError) as exc:
        create_parsing_chain("es", llm)

    assert "Unsupported prompt language" in str(exc.value)


def test_page_parsing_output_parser_converts_en_to_canonical_schema():
    parser = PageParsingOutputParser(source_lang="en", llm=MagicMock())
    message = AIMessage(
        content='{"blocks": [{"type": "text", "content": "Title"}, {"type": "image", "content": "A chart showing sales data"}]}'
    )

    result = parser.parse(message)

    assert result.model_dump() == {
        "blocos": [
            {"type": "text", "content": "Title"},
            {
                "type": "image",
                "content": "A chart showing sales data",
            },
        ]
    }


def test_parsing_chain_builds_multimodal_message_and_returns_canonical_output(
    fake_image, patch_image_url
):
    received = {}

    def spy_llm(messages):
        received["messages"] = messages
        return AIMessage(
            content='{"blocks": [{"type": "text", "content": "Heading"}, {"type": "image", "content": "A diagram illustrating the process"}]}'
        )

    llm = RunnableLambda(spy_llm)
    chain = create_parsing_chain("en", llm)

    result = chain.invoke({"image": fake_image, "context": "focus on diagrams"})

    assert result.model_dump() == {
        "blocos": [
            {"type": "text", "content": "Heading"},
            {
                "type": "image",
                "content": "A diagram illustrating the process",
            },
        ]
    }
    assert "messages" in received
    assert len(received["messages"]) == 1
    assert isinstance(received["messages"][0], HumanMessage)

    content = received["messages"][0].content
    assert isinstance(content, list)
    assert content[0]["type"] == "text"
    assert "focus on diagrams" in content[0]["text"]
    assert content[1]["type"] == "image_url"
    assert content[1]["image_url"]["url"].startswith("data:image/jpeg;base64,")