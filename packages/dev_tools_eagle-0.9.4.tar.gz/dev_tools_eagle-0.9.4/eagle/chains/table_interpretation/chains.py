from pydantic import BaseModel, Field
from typing import List, ClassVar
from langchain_core.runnables import RunnableSequence, RunnableLambda
from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.prompts import ChatPromptTemplate, SystemMessagePromptTemplate, HumanMessagePromptTemplate
from eagle.utils.prompt_utils import EagleJsonOutputParser
import os
from operator import itemgetter
from eagle.utils.prompt_utils import load_prompt

PROMPT_DIR = os.path.dirname(__file__) + "/prompts"

PROMPT_TEMPLATES = {
    "pt-br": {
        "create_table_interpretation_chain": {
            "system": load_prompt(PROMPT_DIR,"table_corrector_agent_system_prompt_pt_br.txt"),
            "user": load_prompt(PROMPT_DIR, "table_corrector_agent_decision_pt_br.txt")
        }
    },
    "en": {
        "create_table_interpretation_chain": {
            "system": load_prompt(PROMPT_DIR, "table_corrector_agent_system_prompt_en.txt"),
            "user": load_prompt(PROMPT_DIR, "table_corrector_agent_decision_en.txt")
        }
    }
}

# LLM output models
class DataFrameCorrectionParametersOutputModel_PT_BR(BaseModel):
    nome_tabela: str = Field(
        description="Nome da tabela baseado apenas em seu conteúdo."
    )
    descricao_tabela: str = Field(
        description="Descrição resumida do conteúdo da tabela."
    )

class DataFrameCorrectionParametersOutputModel_EN(BaseModel):
    table_name: str = Field(
        description="Name of the table based only on its content."
    )
    table_description: str = Field(
        description="Brief description of the content of the table."
    )

# Output parsers
class TableInterpretationOutputParser(EagleJsonOutputParser):

    CONVERTION_SCHEMA: ClassVar[dict] = {
        "pt-br": {
            "class_for_parsing": DataFrameCorrectionParametersOutputModel_PT_BR,
            "convertion_schema": {
                "nome_tabela": {
                    "target_key": "table_name",
                    "value_mapping": {}
                },
                "descricao_tabela": {
                    "target_key": "table_description",
                    "value_mapping": {}
                }
            }
        },
        "en": {
            "class_for_parsing": DataFrameCorrectionParametersOutputModel_EN,
            "convertion_schema": {
                "table_name": {
                    "target_key": "table_name",
                    "value_mapping": {}
                },
                "table_description": {
                    "target_key": "table_description",
                    "value_mapping": {}
                }
            }
        },
    }

    TARGET_SCHEMA: BaseModel = DataFrameCorrectionParametersOutputModel_EN

# Chains

def create_table_interpretation_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
) -> RunnableSequence:
    templates = PROMPT_TEMPLATES[prompt_language]
    system_prompt = SystemMessagePromptTemplate.from_template(templates["create_table_interpretation_chain"]["system"], template_format="jinja2")
    human_prompt = HumanMessagePromptTemplate.from_template(templates["create_table_interpretation_chain"]["user"], template_format="jinja2")
    prompt = ChatPromptTemplate.from_messages([system_prompt, human_prompt])
    output_parser = TableInterpretationOutputParser(
        source_lang=prompt_language,
        llm=llm,
        use_structured_output=True
    )
    _parse = RunnableLambda(lambda x: output_parser.parse(x))
    chain = (
        {
            "table_as_html": itemgetter("table_as_html")
        }
        | prompt
        | llm
        | _parse
    )
    return chain
