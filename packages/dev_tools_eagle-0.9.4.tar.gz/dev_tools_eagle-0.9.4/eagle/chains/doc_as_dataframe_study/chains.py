import os
from operator import itemgetter
from typing import ClassVar, Dict

from eagle.utils.prompt_utils import EagleJsonOutputParser
from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda, RunnableSequence
from pydantic import BaseModel

from eagle.utils.prompt_utils import load_prompt


PROMPT_DIR = os.path.join(os.path.dirname(__file__), "prompts")

PROMPT_TEMPLATES: Dict[str, Dict[str, str]] = {
    "pt-br": {
        "extract_document_structure": load_prompt(
            PROMPT_DIR,
            "extract_document_structure_pt_br.txt",
        ),
        "unify_document_structure": load_prompt(
            PROMPT_DIR,
            "unify_document_structure_pt_br.txt",
        ),
        "section_descriptions": load_prompt(
            PROMPT_DIR,
            "section_descriptions_pt_br.txt",
        ),
        "document_title": load_prompt(
            PROMPT_DIR,
            "document_title_pt_br.txt",
        ),
    },
    "en": {
        "extract_document_structure": load_prompt(
            PROMPT_DIR,
            "extract_document_structure_en.txt",
        ),
        "unify_document_structure": load_prompt(
            PROMPT_DIR,
            "unify_document_structure_en.txt",
        ),
        "section_descriptions": load_prompt(
            PROMPT_DIR,
            "section_descriptions_en.txt",
        ),
        "document_title": load_prompt(
            PROMPT_DIR,
            "document_title_en.txt",
        ),
    },
}

class DocumentStructureOutputModel(BaseModel):
    """Container to hold arbitrary document structure JSON."""

    model_config = {"extra": "allow"}

class DocumentStructureOutputParser(EagleJsonOutputParser):
    """Parse the raw JSON structure returned by the LLM."""

    CONVERTION_SCHEMA: ClassVar[dict] = {
        "pt-br": {
            "class_for_parsing": DocumentStructureOutputModel,
            "convertion_schema": {},
        },
        "en": {
            "class_for_parsing": DocumentStructureOutputModel,
            "convertion_schema": {},
        },
    }

    TARGET_SCHEMA: BaseModel = DocumentStructureOutputModel

def create_extract_document_structure_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
) -> RunnableSequence:
    templates = PROMPT_TEMPLATES[prompt_language]
    prompt = PromptTemplate.from_template(
        templates["extract_document_structure"],
        template_format="jinja2",
    )

    output_parser = DocumentStructureOutputParser(
        source_lang=prompt_language,
        llm=llm,
        use_structured_output=False,
    )

    def output_parse(x):
        return output_parser.parse(x)

    _parse = RunnableLambda(output_parse)

    chain = (
        {"document_as_text": itemgetter("document_as_text")}
        | prompt
        | llm
        | _parse
        | RunnableLambda(lambda output: [output.model_dump()])
    )

    return chain


def create_unify_document_structure_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
) -> RunnableSequence:
    templates = PROMPT_TEMPLATES[prompt_language]
    prompt = PromptTemplate.from_template(
        templates["unify_document_structure"],
        template_format="jinja2",
    )

    output_parser = DocumentStructureOutputParser(
        source_lang=prompt_language,
        llm=llm,
        use_structured_output=False,
    )

    def output_parse(x):
        return output_parser.parse(x)

    _parse = RunnableLambda(output_parse)

    chain = (
        {"structure_list": itemgetter("structure_list")}
        | prompt
        | llm
        | _parse
        | RunnableLambda(lambda output: output.model_dump())
    )

    return chain


def create_section_descriptions_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
) -> RunnableSequence:
    templates = PROMPT_TEMPLATES[prompt_language]
    prompt = PromptTemplate.from_template(
        templates["section_descriptions"],
        template_format="jinja2",
    )

    chain = (
        {
            "title": itemgetter("title"),
            "section_text": itemgetter("section_text"),
        }
        | prompt
        | llm
        | StrOutputParser()
        | RunnableLambda(lambda x: x.strip())
    )

    return chain


def create_document_title_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
) -> RunnableSequence:
    templates = PROMPT_TEMPLATES[prompt_language]
    prompt = PromptTemplate.from_template(
        templates["document_title"],
        template_format="jinja2",
    )

    chain = (
        {
            "document_excerpt": itemgetter("document_excerpt"),
        }
        | prompt
        | llm
        | StrOutputParser()
        | RunnableLambda(lambda x: x.strip())
    )

    return chain
