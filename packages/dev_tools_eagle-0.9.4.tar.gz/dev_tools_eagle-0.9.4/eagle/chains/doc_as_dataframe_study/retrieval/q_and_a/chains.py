import os
from operator import itemgetter
from typing import Any, ClassVar, Dict, List, Tuple

from eagle.utils.prompt_utils import EagleJsonOutputParser, load_prompt
from langchain_core.messages import HumanMessage
from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda, RunnableSequence
from pydantic import BaseModel

PROMPT_DIR = os.path.join(os.path.dirname(__file__), "prompts")

PROMPT_TEMPLATES: Dict[str, str] = {
    "pt-br": load_prompt(PROMPT_DIR, "question_answer_pt_br.txt"),
    "en": load_prompt(PROMPT_DIR, "question_answer_en.txt"),
}

CONTEXT_MARKER = "__CONTEXT__"


class ReferenceEntry(BaseModel):
    file_id: str
    idx_range: list[int]


class QAOutputSchemaEN(BaseModel):
    answer: str
    references: Dict[str, ReferenceEntry]


class QAOutputSchemaPTBR(BaseModel):
    resposta: str
    referencias: Dict[str, ReferenceEntry]


class QAOutputParser(EagleJsonOutputParser):
    CONVERTION_SCHEMA: ClassVar[dict] = {
        "pt-br": {
            "class_for_parsing": QAOutputSchemaPTBR,
            "convertion_schema": {
                "resposta": {"target_key": "answer", "value_mapping": {}},
                "referencias": {"target_key": "references", "value_mapping": {}},
            },
        },
        "en": {
            "class_for_parsing": QAOutputSchemaEN,
            "convertion_schema": {
                "answer": {"target_key": "answer", "value_mapping": {}},
                "references": {"target_key": "references", "value_mapping": {}},
            },
        },
    }

    TARGET_SCHEMA: BaseModel = QAOutputSchemaEN


def create_q_and_a_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
    use_structured_output: bool = False,
) -> RunnableSequence:
    if prompt_language not in PROMPT_TEMPLATES:
        raise ValueError(f"Unsupported prompt language: {prompt_language}")

    prompt_template = PROMPT_TEMPLATES[prompt_language]

    prompt = PromptTemplate.from_template(
        prompt_template,
        template_format="jinja2",
    )

    def _split_prefix_suffix(rendered: str) -> Tuple[str, str]:
        if CONTEXT_MARKER not in rendered:
            raise ValueError("Context marker not found in prompt template")
        return rendered.split(CONTEXT_MARKER, 1)

    output_parser = QAOutputParser(
        source_lang=prompt_language,
        llm=llm,
        use_structured_output=use_structured_output,
    )

    _parse = RunnableLambda(lambda x: output_parser.parse(x))

    # Always build a HumanMessage; presence of image_url entries triggers multimodal handling by the LLM
    def _build_messages(inputs: Dict[str, Any]) -> List[HumanMessage]:  # type: ignore[name-defined]
        question_val = inputs.get("question")
        context_items = inputs.get("context_items") or []
        rendered = prompt.format(question=question_val)
        prefix, suffix = _split_prefix_suffix(rendered)

        content: List[Dict[str, Any]] = []
        if prefix.strip():
            content.append({"type": "text", "text": prefix})
        for item in context_items:
            item_type = item.get("type")
            if item_type == "image_url":
                image_url = item.get("image_url")
                if image_url:
                    content.append({"type": "image_url", "image_url": image_url})
            else:
                text_val = item.get("text")
                if text_val:
                    content.append({"type": "text", "text": str(text_val)})
        if suffix.strip():
            content.append({"type": "text", "text": suffix})

        return [HumanMessage(content=content)]

    chain = (
        {
            "question": itemgetter("question"),
            "context_items": itemgetter("context_items"),
        }
        | RunnableLambda(_build_messages)
        | llm
        | _parse
    )

    return chain