import os
from operator import itemgetter
from typing import ClassVar, Dict, List

from eagle.utils.prompt_utils import EagleJsonOutputParser, load_prompt
from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableLambda, RunnableSequence
from pydantic import BaseModel

PROMPT_DIR = os.path.join(os.path.dirname(__file__), "prompts")

PROMPT_TEMPLATES: Dict[str, str] = {
    "pt-br": load_prompt(PROMPT_DIR, "ask_for_the_best_files_and_sections_pt_br.txt"),
    "en": load_prompt(PROMPT_DIR, "ask_for_the_best_files_and_sections_en.txt"),
}


class BestFilesAndSectionsOutputSchemaEN(BaseModel):
    paths: List[List[str]]


class BestFilesAndSectionsOutputSchemaPTBR(BaseModel):
    caminhos: List[List[str]]


class BestFilesAndSectionsOutputParser(EagleJsonOutputParser):
    CONVERTION_SCHEMA: ClassVar[dict] = {
        "pt-br": {
            "class_for_parsing": BestFilesAndSectionsOutputSchemaPTBR,
            "convertion_schema": {
                "caminhos": {"target_key": "paths", "value_mapping": {}},
            },
        },
        "en": {
            "class_for_parsing": BestFilesAndSectionsOutputSchemaEN,
            "convertion_schema": {
                "paths": {"target_key": "paths", "value_mapping": {}},
            },
        },
    }

    TARGET_SCHEMA: BaseModel = BestFilesAndSectionsOutputSchemaEN


def create_best_files_and_sections_chain(
    prompt_language: str,
    llm: BaseLanguageModel,
    use_structured_output: bool = False,
) -> RunnableSequence:
    if prompt_language not in PROMPT_TEMPLATES:
        raise ValueError(f"Unsupported prompt language: {prompt_language}")

    prompt = PromptTemplate.from_template(
        PROMPT_TEMPLATES[prompt_language],
        template_format="jinja2",
    )

    output_parser = BestFilesAndSectionsOutputParser(
        source_lang=prompt_language,
        llm=llm,
        use_structured_output=use_structured_output,
    )

    _parse = RunnableLambda(lambda x: output_parser.parse(x))

    chain = (
        {
            "question": itemgetter("question"),
            "sections_and_descriptions": itemgetter("sections_and_descriptions"),
        }
        | prompt
        | llm
        | _parse
    )

    return chain