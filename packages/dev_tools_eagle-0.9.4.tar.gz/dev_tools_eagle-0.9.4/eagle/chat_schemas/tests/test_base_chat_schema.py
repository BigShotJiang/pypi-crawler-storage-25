import pytest
from types import SimpleNamespace
from datetime import datetime, timezone


class FakeCallbackManager:
    def __init__(self):
        self.on_supervisor_end_calls = []
        self.on_agent_end_calls = []

    def on_supervisor_end(self, state, config):
        self.on_supervisor_end_calls.append((state, config))

    def on_agent_end(self, state, config):
        self.on_agent_end_calls.append((state, config))


class FakeWorkingState:

    def __init__(self):
        self.messages = []
        self.messages_with_requester = []
        self.messages_with_agents = []
        self.participants = []
        self.flow_direction = None
        self.interaction_initial_datetime = datetime.now(timezone.utc)
        self.other_registers = {"anything": True}

    def model_dump(self):
        return {
            "messages": self.messages,
            "messages_with_requester": self.messages_with_requester,
            "messages_with_agents": self.messages_with_agents,
            "participants": self.participants,
            "flow_direction": self.flow_direction,
            "interaction_initial_datetime": self.interaction_initial_datetime,
            "other_registers": self.other_registers,
        }


class FakeAgent:

    def __init__(self, name, description=""):
        self.name = name
        self.description = description
        self._config_set = None
        self.compile_calls = 0
        self.run_calls = []
        self.current_state = FakeWorkingState()

    def set_config(self, cfg):
        self._config_set = cfg

    def compile(self):
        self.compile_calls += 1

    def run(self, state, config):
        self.run_calls.append((state, config))


class FakeCompiledGraph:
    def __init__(self, events=None, snapshot=None):
        self._events = events or []
        self._snapshot = snapshot or {"ok": True}
        self.stream_calls = []
        self.get_state_calls = []

    def stream(self, state, config, stream_mode="update"):
        self.stream_calls.append((state, config, stream_mode))
        for ev in self._events:
            yield ev

    def get_state(self, config):
        self.get_state_calls.append(config)
        return self._snapshot


class FakeStateGraph:

    def __init__(self, state_schema, config_schema=None):
        self.state_schema = state_schema
        self.config_schema = config_schema
        self.nodes = {}
        self.edges = []
        self.cond_edges = []
        self._compiled = None

    def add_node(self, name, fn):
        self.nodes[name] = fn

    def add_edge(self, src, dst):
        self.edges.append((src, dst))

    def add_conditional_edges(self, src, router_fn, mapping):
        self.cond_edges.append((src, router_fn, mapping))

    def compile(self, checkpointer=None):
        if self._compiled is None:
            self._compiled = FakeCompiledGraph(events=[{"step": "x"}])
        return self._compiled


@pytest.fixture
def module_under_test(monkeypatch):
    import eagle.chat_schemas.base as m
    monkeypatch.setattr(m, "StateGraph", FakeStateGraph)
    return m


@pytest.fixture
def supervisor():
    return FakeAgent("Supervisor", "Supervisão geral")


@pytest.fixture
def agent_a():
    return FakeAgent("Agent-A", "Agente A")


@pytest.fixture
def schema(module_under_test, supervisor):
    return module_under_test.BasicChatSchema(supervisor=supervisor, checkpointer=SimpleNamespace())


def test_chat_state_callback_manager_register_and_fire(module_under_test):
    mgr = module_under_test.ChatStateCallbackManager()
    calls = []

    def cb1(state, cfg): calls.append(("cb1", state, cfg))
    def cb2(state, cfg): calls.append(("cb2", state, cfg))

    mgr.register_callback("on_supervisor_end", cb1)
    mgr.register_callback("on_supervisor_end", cb2)

    st = {"a": 1}
    cfg = {"b": 2}
    mgr.on_supervisor_end(st, cfg)

    assert [c[0] for c in calls] == ["cb1", "cb2"]



def test_basic_chat_config_schema_model_dump_preserves_agent_configs(module_under_test):
    cfg = module_under_test.BasicChatConfigSchema(
        agent_configs={"x": {"y": 1}},
        chat_id="c1",
        chat_name="n",
        chat_description="d",
    )

    dumped = cfg.model_dump()
    assert dumped["agent_configs"] == {"x": {"y": 1}}
    assert dumped["chat_id"] == "c1"


def test_set_node_callable_name(schema):
    assert schema._set_node_callable_name("Agent A") == "agent_a"
    assert schema._set_node_callable_name("Agent-A") == "agent_a"
    assert schema._set_node_callable_name("AGENT A-1") == "agent_a_1"


def test_add_agent_adds_to_multiagent_index(schema, agent_a):
    schema.add_agent(agent_a)
    assert "Agent-A" in schema._multiagent_index


def test_after_supervisor_node_routes_agents_and_calls_callback(schema):
    cb = FakeCallbackManager()
    st = SimpleNamespace(flow_direction="agents")
    cfg = {"configurable": {"callback_manager": cb}}

    out = schema.after_supervisor_node(st, cfg, store=None)

    assert out == "agents"
    assert len(cb.on_supervisor_end_calls) == 1


def test_after_supervisor_node_routes_end_when_requester(schema):
    cb = FakeCallbackManager()
    st = SimpleNamespace(flow_direction="requester")
    cfg = {"configurable": {"callback_manager": cb}}

    out = schema.after_supervisor_node(st, cfg, store=None)

    assert out == "end"
    assert len(cb.on_supervisor_end_calls) == 1


def test_after_supervisor_node_raises_when_flow_direction_none(schema):
    cb = FakeCallbackManager()
    st = SimpleNamespace(flow_direction=None)
    cfg = {"configurable": {"callback_manager": cb}}

    with pytest.raises(ValueError, match="Flow direction is not set"):
        schema.after_supervisor_node(st, cfg, store=None)



def test_supervisor_node_returns_agents_dict(schema, supervisor):
    node = schema.supervisor_agent_node_generator()

    # faz o "run" escrever o resultado depois do mapeamento de state
    def fake_run(state, config):
        supervisor.current_state.flow_direction = "agents"
        supervisor.current_state.messages_with_agents = ["m-agent"]

    supervisor.run = fake_run

    st = SimpleNamespace(
        messages_with_requester=["m-req"],
        messages_with_agents=[],
        participants=[],
        interaction_initial_datetime=datetime.now(timezone.utc),
    )
    cb = FakeCallbackManager()
    cfg = {
        "configurable": {
            "callback_manager": cb,
            "agent_configs": {supervisor.name: {"k": "v"}},
        }
    }

    out = node(st, cfg, store=None)

    assert out["flow_direction"] == "agents"
    assert out["messages_with_agents"] == ["m-agent"]


def test_supervisor_node_returns_requester_dict(schema, supervisor):
    node = schema.supervisor_agent_node_generator()

    def fake_run(state, config):
        supervisor.current_state.flow_direction = "requester"
        supervisor.current_state.messages_with_requester = ["m-req-out"]

    supervisor.run = fake_run

    st = SimpleNamespace(
        messages_with_requester=[],
        messages_with_agents=[],
        participants=[],
        interaction_initial_datetime=datetime.now(timezone.utc),
    )
    cb = FakeCallbackManager()
    cfg = {
        "configurable": {
            "callback_manager": cb,
            "agent_configs": {supervisor.name: {"k": "v"}},
        }
    }

    out = node(st, cfg, store=None)

    assert out["flow_direction"] == "requester"
    assert out["messages_with_requester"] == ["m-req-out"]


def test_supervisor_node_invalid_flow_raises(schema, supervisor):
    supervisor.current_state.flow_direction = "banana"

    node = schema.supervisor_agent_node_generator()

    st = SimpleNamespace(
        messages_with_requester=[],
        messages_with_agents=[],
        participants=[],
        interaction_initial_datetime=datetime.now(timezone.utc),
    )
    cfg = {"configurable": {"agent_configs": {supervisor.name: {}}, "callback_manager": FakeCallbackManager()}}

    with pytest.raises(ValueError, match="Invalid flow direction"):
        node(st, cfg, store=None)


def test_multiagent_agent_node_generator_runs_agent_and_calls_callback(schema, agent_a):
    schema.add_agent(agent_a)

    node = schema.multiagent_agent_node_generator(agent_a.name)

    # depois do mapeamento (messages = ["in-msg"]), o run troca pra saída final
    def fake_run(state, config):
        agent_a.current_state.messages = ["agent-msg-1"]

    agent_a.run = fake_run

    st = SimpleNamespace(
        messages_with_agents=["in-msg"],
        interaction_initial_datetime=datetime.now(timezone.utc),
    )
    cb = FakeCallbackManager()
    cfg = {
        "configurable": {
            "callback_manager": cb,
            "agent_configs": {agent_a.name: {"param": 1}},
        }
    }

    out = node(st, cfg, store=None)

    assert out == {"messages_with_agents": ["agent-msg-1"]}
    assert len(cb.on_agent_end_calls) == 1


def test_initialize_config(schema):
    config = {
        "configurable": {"thread_id": "T1"},
        "agent_configs": {"Supervisor": {"x": 1}},
        "chat_id": "c1",
        "chat_name": "n1",
        "chat_description": "d1",
    }
    out = schema._initialize_config(config)
    assert out["chat_id"] == "c1"
    assert out["agent_configs"] == {"Supervisor": {"x": 1}}


def test_initialize_state_adds_participants_excluding_supervisor(schema, agent_a):
    schema.add_agent(agent_a)

    state = {
        "messages_with_requester": [],
        "messages_with_agents": [],
        "flow_direction": "requester",
    }
    out = schema._initialize_state(state)

    names = [p["name"] for p in out["participants"]]
    assert "Agent-A" in names
    assert "Supervisor" not in names


def test_run_compiles_if_needed_and_consumes_stream(schema, monkeypatch):
    compiled = FakeCompiledGraph(events=[
        {"e1": "v1"},
        {"e2": "v2"},
    ])

    def fake_compile():
        schema._compiled_graph = compiled
    monkeypatch.setattr(schema, "compile", fake_compile)

    calls = []
    monkeypatch.setattr(schema, "use_event_and_value", lambda event, value: calls.append((event, value)))

    config = {
        "configurable": {
            "thread_id": "1",
            "agent_configs": {"Supervisor": {}},
            "callback_manager": FakeCallbackManager(),
        },
        "agent_configs": {"Supervisor": {}},
        "chat_id": "c",
        "chat_name": "n",
        "chat_description": "d",
    }

    state = {
        "messages_with_requester": [],
        "messages_with_agents": [],
        "flow_direction": "requester",
    }

    schema.run(state, config, stream_mode="update")

    assert len(calls) == 2
    assert calls[0][0] == {"e1": "v1"}
    assert calls[0][1] == "v1"


def test_state_snapshot_returns_compiled_graph_state(schema):
    schema._compiled_graph = FakeCompiledGraph(snapshot={"snap": 123})
    schema._config = {"configurable": {"thread_id": "1"}}

    snap = schema.state_snapshot
    assert snap == {"snap": 123}
