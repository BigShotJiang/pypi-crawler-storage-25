import json
from unittest.mock import Mock
from datetime import datetime

def target_schema_func(**kwargs):
    return kwargs

class DummyParser:
    CONVERTION_SCHEMA = {
        "pt": {
            "class_for_parsing": None,
            "convertion_schema": {
                "acao": {"target_key": "action", "value_mapping": {"encerrar_relay": "end_relay", "continuar_relay": "continue_relay"}},
                "mensagem": {"target_key": "message", "value_mapping": {}}
            }
        }
    }
    TARGET_SCHEMA = staticmethod(target_schema_func)

    def __init__(self, source_lang="pt", llm=None):
        self.source_lang = source_lang
        self.llm = llm
        self.use_structured_output = False

    def parse(self, message):
        data = json.loads(message.content)
        converted = {}
        for k, v in self.CONVERTION_SCHEMA[self.source_lang]["convertion_schema"].items():
            converted[v["target_key"]] = v["value_mapping"].get(data.get(k), data.get(k))
        return self.TARGET_SCHEMA(**converted)

class DummyAgent:
    def __init__(self, name, description):
        self.name = name
        self.description = description

    def run(self, state, config):
        return {"status": "ran"}

class DummyMsg:
    type = "ai"
    content = '{"acao": "encerrar_relay", "mensagem": "fim"}'

def test_parser_maps_pt_br_to_en_schema():
    parser = DummyParser(source_lang="pt", llm=Mock())
    parsed = parser.parse(DummyMsg())
    assert parsed["action"] == "end_relay"
    assert parsed["message"] == "fim"

def test_supervisor_node_returns_agents():
    supervisor = DummyAgent(name="Supervisor", description="test")
    # Dummy schema apenas para simular a chamada
    def dummy_node(state, config, store=None):
        return supervisor.run(state, config)

    state = {
        "messages_with_requester": [{"name": "User", "content": "hi"}],
        "messages_with_agents": [],
        "participants": [],
        "interaction_initial_datetime": datetime.utcnow()
    }
    config = {"configurable": {"agent_configs": {supervisor.name: {}}}}

    node = dummy_node
    result = node(state, config)
    assert result["status"] == "ran"