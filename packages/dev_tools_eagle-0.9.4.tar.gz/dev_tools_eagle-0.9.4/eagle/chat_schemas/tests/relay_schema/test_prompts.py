from eagle.chat_schemas.relay_schemas.agents.moderator_simple_agent.prompts import ObserveRelayPromptOutputParser
from langchain_core.messages import AIMessage
import eagle.chat_schemas.relay_schemas.agents.moderator_simple_agent.prompts as prompts
from unittest.mock import Mock

def test_generate_prompt_for_observe_relay_en(monkeypatch):
    class DummyPrompt:
        def partial(self, *a, **k): return self
        def format_messages(self): return []

    monkeypatch.setattr(
        prompts.prompt_generator,
        "generate_prompt",
        lambda *a, **k: {"prompt": DummyPrompt(), "output_parser": object}
    )

    data = prompts.prompt_generator.generate_prompt("observe_relay", "en", llm=None, use_structured_output=False)
    assert "prompt" in data
    assert "output_parser" in data


def test_parser_maps_pt_br_to_en_schema():
    parser = ObserveRelayPromptOutputParser(
        source_lang="pt-br",
        llm=Mock()
    )

    class DummyMsg:
        type = "ai"
        content = '{"acao": "encerrar_relay", "mensagem": "fim"}'

    parsed = parser.parse(DummyMsg())

    assert parsed.action == "end_relay"
    assert parsed.message == "fim"