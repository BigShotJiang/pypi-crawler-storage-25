import pytest
from langchain.schema import AIMessage
from langchain_core.runnables.base import Runnable
from langchain_core.runnables import RunnableConfig, RunnableLambda
from eagle.memory.shared.shared_objects_memory import SharedObjectsMemory
from eagle.chat_schemas.relay_schemas.agents.moderator_simple_agent.supervisor import observe_node, RelayModeratorSimpleAgentWorkingMemoryState, AIMessage

class DummyCallback:
    def on_observe_node_start(self, state, config):
        pass
    def on_observe_node_end(self, state, config):
        pass

class DummyStore:
    def get_memory(self, name):
        return DummyMemory()

class DummyMemory:
    def get_last_memories_metadata(self, chat_id, k):
        return []
    def generate_summary_from_object_ids(self, chat_id, object_ids, language):
        return "dummy summary"

class DummyPrompt:
    def partial(self, **kwargs):
        return self
    def format_messages(self):
        return [{"role": "assistant", "content": "dummy response"}]

class DummyResponse:
    def __init__(self, action="end_relay", message="dummy response"):
        self.action = action
        self.message = message

class DummyParser:
    def parse(self, text):
        return DummyResponse()

class DummyLLM(Runnable):
    def invoke(self, input):
        return AIMessage(content="dummy llm response", name="TestAgent")


@pytest.mark.parametrize("chat_id", ["123"])
def test_observe_node_end_relay(monkeypatch, chat_id):
    state = type(
        "DummyState", (), {
            "messages_with_requester": [{"name": "User", "content": "hi"}],
            "messages_with_agents": [],
            "participants": [],
            "plan": None,
            "observation": None,
            "interaction_initial_datetime": None
        }
    )()

    config = {
        "configurable": {
            "agent_name": "TestAgent",
            "agent_description": "A test agent",
            "observe_node_callback_manager": DummyCallback(),
            "observe_node_llm": DummyLLM(),
            "observe_node_llm_prompt_language": "en",
            "chat_id": chat_id,
            "chat_history_window_size": 5,
            "execute_shared_objects_config": {"k": 5, "language": "en"},
        }
    }

    monkeypatch.setattr(
        "eagle.chat_schemas.relay_schemas.agents.moderator_simple_agent.supervisor.prompt_generator.generate_prompt",
        lambda *a, **k: {"prompt": DummyPrompt(), "output_parser": DummyParser()}
    )

    monkeypatch.setattr(
        "eagle.chat_schemas.relay_schemas.agents.moderator_simple_agent.supervisor.process_graph_stream",
        lambda *a, **k: (a[1], AIMessage(content="{}", name="mock")))
    
    store = DummyStore()

    result = observe_node(state, config, store=store)

    assert result is not None
