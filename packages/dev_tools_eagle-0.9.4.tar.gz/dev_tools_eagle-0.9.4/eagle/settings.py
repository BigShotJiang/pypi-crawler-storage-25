from __future__ import annotations

import os
from functools import lru_cache
from typing import Any, Optional

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from eagle.utils.configs import find_env_upwards


def _load_dotenv() -> None:
    """Load .env or .test.env if present anywhere above the cwd."""
    for candidate in (".env", ".test.env"):
        try:
            find_env_upwards(candidate)
            return
        except FileNotFoundError:
            continue

_load_dotenv()

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(".env", ".test.env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Tornado
    tornado_base_url: str = "http://localhost:8000/"
    tornado_username: str = ""
    tornado_password: str = ""
    tornado_max_part_mb: int = 20
    tornado_extracted_files_dir: str = "tornado_extracted_files"

    # Document storage
    document_storage_kind: str = "mongo"
    mongo_uri: str = "mongodb://localhost:27017"
    mongo_database: str = "eagle"
    mongo_persistence_dir: str = "ingested_files"
    mongo_replica_set: Optional[str] = None
    mongo_auth_source: Optional[str] = None
    mongo_documents_collection: str = "eagle-documents"
    mongo_documents_studies_collection: str = "eagle-document-studies"
    document_storage_vectorstore_kind: str = "opensearch"

    # Agent team configuration
    agents_vectorstore_kind: str = "opensearch"
    agents_shared_memory_storage_dir: str = "agents_shared_memory"
    agents_shared_memory_embedding_dims: int = 384
    agents_shared_memory_embedding_name: str = "text-embedding-3-small"

    # OpenSearch
    opensearch_host: str = "http://localhost"
    opensearch_port: Optional[int] = None
    opensearch_username: Optional[str] = None
    opensearch_password: Optional[str] = None
    opensearch_use_ssl: bool = False
    opensearch_verify_certs: bool = True
    opensearch_ssl_assert_hostname: bool = True
    opensearch_ssl_show_warn: bool = True
    opensearch_general_index_prefix: str = ""

    # SSL / certificates
    ssl_cert_file: Optional[str] = None
    ssl_cert_file2: Optional[str] = None

    # OpenAI / Azure OpenAI
    openai_api_key: Optional[str] = None
    openai_base_url: Optional[str] = None
    openai_api_type: Optional[str] = None
    openai_api_version: Optional[str] = None
    azure_openai_api_key: Optional[str] = None
    azure_openai_endpoint: Optional[str] = None
    azure_openai_deployment: Optional[str] = None

    # Langfuse
    langfuse_host: str = "http://localhost:3000"
    langfuse_public_key: str = ""
    langfuse_secret_key: str = ""

    # Test fixtures / embeddings
    tests_embedding_model_name: Optional[str] = None
    tests_embedding_dim: Optional[int] = None
    tests_llm_model_name: Optional[str] = None

    # Neo4j
    neo4j_uri: str = "neo4j://localhost:7687"
    neo4j_username: str = "neo4j"
    neo4j_password: str = "password"

    @field_validator('opensearch_port', mode='before')
    @classmethod
    def validate_opensearch_port(cls, v):
        if v == '':
            return None
        return v

    def model_post_init(self, __context: Any) -> None:
        # Keep HTTP clients aligned with the provided CA bundle when present.
        if self.ssl_cert_file2:
            os.environ.setdefault("SSL_CERT_FILE", self.ssl_cert_file2)
            os.environ.setdefault("PRIMP_CA_BUNDLE", self.ssl_cert_file2)
            os.environ.setdefault("REQUESTS_CA_BUNDLE", self.ssl_cert_file2)

        # Mirror Azure/OpenAI env vars expected by downstream SDKs.
        if self.openai_api_type == "azure":
            if self.openai_api_key:
                os.environ.setdefault("AZURE_OPENAI_API_KEY", self.openai_api_key)
            if self.openai_base_url:
                os.environ.setdefault("AZURE_OPENAI_ENDPOINT", self.openai_base_url)

    @property
    def opensearch_url(self) -> str:
        return (
            f"{self.opensearch_host}:{self.opensearch_port}"
            if self.opensearch_port
            else self.opensearch_host
        )

    @property
    def opensearch_connection_kwargs(self) -> dict[str, Any]:
        auth = None
        if self.opensearch_username and self.opensearch_password:
            auth = (self.opensearch_username, self.opensearch_password)
        return {
            "http_auth": auth,
            "use_ssl": self.opensearch_use_ssl,
            "verify_certs": self.opensearch_verify_certs,
            "ssl_assert_hostname": self.opensearch_ssl_assert_hostname,
            "ssl_show_warn": self.opensearch_ssl_show_warn,
        }


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()


__all__ = ["settings", "get_settings", "Settings"]