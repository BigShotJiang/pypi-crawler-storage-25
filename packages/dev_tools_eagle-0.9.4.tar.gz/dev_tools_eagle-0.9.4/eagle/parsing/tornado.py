from pathlib import Path
import pandas as pd
import os
import requests
import time
import zipfile
import logging
import json
import re
import unicodedata
from langchain_core.language_models.base import BaseLanguageModel

from eagle.utils.pdf_utils import split_pdf_by_size
from eagle.utils.os_utils import ensure_dir_exists
from eagle.utils.errors_handling import async_ignore_error_with_these_strings
from eagle.chains.table_interpretation.chains import create_table_interpretation_chain


# Constants
EMPTY_PDF_FILE_PATH = os.path.join(os.path.dirname(__file__), "empty_pdf.pdf")

# Auxiliar functions

def calculate_insufficient_extraction_stats(data: dict) -> dict:
    pages = data.get("pages", [])
    total_pages = len(pages)
    insufficient_extraction_pages = 0
    pages_details = []

    for page_idx, page in enumerate(pages, start=1):
        parsing_res_list = page.get("parsing_res_list", [])
        block_labels = [item.get("block_label") for item in parsing_res_list if item.get("block_label")]
        unique_block_labels = set(block_labels)
        has_insufficient_extraction = bool(unique_block_labels) and unique_block_labels.issubset({"table", "image", "header", "footer"})

        if has_insufficient_extraction:
            insufficient_extraction_pages += 1

        pages_details.append({
            "page": page_idx,
            "blocks_count": len(parsing_res_list),
            "block_labels": block_labels,
            "unique_block_labels": sorted(unique_block_labels),
            "has_insufficient_extraction": has_insufficient_extraction,
        })

    insufficient_extraction_percentage = (insufficient_extraction_pages / total_pages * 100) if total_pages else 0.0

    return {
        "total_pages": total_pages,
        "insufficient_extraction_pages": insufficient_extraction_pages,
        "insufficient_extraction_percentage": insufficient_extraction_percentage,
        "pages_details": pages_details,
    }

def sanitize_string(s):
    # Remove acentos, troca ç por c, mantém números, letras, _
    if isinstance(s, tuple):
        s = s[0]
    s = str(s)
    s = s.replace("ç", "c").replace("Ç", "C")
    s = unicodedata.normalize('NFKD', s)
    s = "".join([c for c in s if not unicodedata.combining(c)])
    sanitized = re.sub(r"[^a-zA-Z0-9]", "_", s)
    sanitized = re.sub(r"_+", "_", sanitized)
    sanitized = sanitized.strip("_")
    return sanitized.lower()

def sanitize_chunk_dir_key(key):
    return key.replace(".", "")

def col_label(col):
    if isinstance(col, tuple):
        # Se todos os membros forem iguais, retorna só um
        if all(str(x) == str(col[0]) for x in col):
            return str(col[0])
        else:
            return "_".join(str(x) for x in col)
    return str(col)

def col_to_edge_name(col):
    return sanitize_string(col)

def build_table_node(table_id, table_name, table_description):
    return {
        "id": sanitize_string(table_id),
        "type": "Table",
        "name": table_name,
        "description": table_description
    }

def build_entity_node(entity_id, entity_type, name, description):
    return {
        "id": entity_id,
        "type": entity_type,
        "name": str(name),
        "description": str(description)
    }

def generate_output_json_filename(dir_path: Path) -> Path:
    file_name = f"{dir_path.name}_layout.json"
    return dir_path / file_name

def generate_image_block_index_filename(dir_path: Path, block_bbox: list, substring_representation: str) -> Path:
    return dir_path / "imgs" / f"img_in_{substring_representation}_box_{block_bbox[0]}_{block_bbox[1]}_{block_bbox[2]}_{block_bbox[3]}.jpg"

class TornadoService:
    def __init__(self, base_url, username, password, max_part_mb: int = 20, collection_id: int = None):
        self.username = username
        self.password = password
        self.base_url = base_url
        self.token = None
        self.collection_id = collection_id
        self.max_part_mb = max_part_mb
        self._chunk_page_map = None  # Armazena o dicionário temporariamente
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(levelname)s] %(message)s"
        )
        self.logger = logging.getLogger("TornadoService")
        self.login()

    def _request_with_retry(self, method, url, **kwargs):
        max_retries = 5
        retry_exceptions = (requests.exceptions.ConnectionError,)
        for attempt in range(1, max_retries + 1):
            try:
                return method(url, **kwargs)
            except retry_exceptions as e:
                self.logger.warning(f"Tentativa {attempt} falhou com erro: {e}. Retentando em 5s...")
                if attempt == max_retries:
                    self.logger.error(f"Falha após {max_retries} tentativas.")
                    raise
                time.sleep(5)

    def login(self):
        url = self.base_url + 'api/login'
        data = {'username': self.username, 'password': self.password, 'ssoId': False}
        headers = {'Content-Type': 'application/json'}
        self.logger.info("Realizando login no Tornado...")
        response = self._request_with_retry(requests.post, url, json=data, headers=headers, verify=False)
        if response.status_code == 200:
            self.token = response.json().get('token')
            self.logger.info("Login realizado com sucesso.")
        else:
            self.logger.error(f"Login failed: {response.status_code} {response.text}")
            raise Exception(f"Login failed: {response.status_code} {response.text}")
        
    def submit_pdf_run(self, pdf_path: str, collection_title: str = "Tornado PaddlePaddleOCR", method: str = "paddle"):
        METHOD_TO_ENDPOINT_DICT = {
            "paddle": "runpaddle",
            "tbe": "runtbe"
        }
        try:
            method_endpoint = METHOD_TO_ENDPOINT_DICT.get(method)
        except KeyError:
            raise Exception(f"Método desconhecido: {method}. Você pode escolher um desses: {list(METHOD_TO_ENDPOINT_DICT.keys())}")
        self.logger.info("Criando coleção no Tornado...")
        url = self.base_url + 'api/jobs_tornado'
        data = {'user': self.username, 'title': collection_title, 'token': self.token}
        headers = {'Content-Type': 'application/json'}
        response = self._request_with_retry(requests.post, url, json=data, headers=headers, verify=False)
        if response.status_code == 200:
            self.collection_id = response.json()['id']
            self.logger.info(f"Coleção criada com id: {self.collection_id}")
        else:
            self.logger.error(f"Erro ao criar coleção: {response.status_code} {response.text}")
            raise Exception(f"Erro ao criar coleção: {response.status_code} {response.text}")

        pdf_size_mb = os.path.getsize(pdf_path) / (1024 * 1024)
        if pdf_size_mb > self.max_part_mb:
            self.logger.info(f"PDF maior que {self.max_part_mb} MB, dividindo em partes...")
            parts_dir = os.path.join(os.path.dirname(pdf_path), "pdf_parts")
            ensure_dir_exists(parts_dir)
            part_files, chunk_page_map = split_pdf_by_size(pdf_path, parts_dir, max_part_mb=self.max_part_mb)
            self._chunk_page_map = chunk_page_map  # Guarda para uso posterior
        else:
            part_files = [pdf_path]
            self._chunk_page_map = None

        part_files.insert(0, EMPTY_PDF_FILE_PATH)  # Adiciona o PDF vazio como primeira parte
        self.logger.info(f"Enviando {len(part_files)} arquivo(s) para a coleção (um por vez)...")
        url = self.base_url + f'api/jobs_tornado/{self.collection_id}/files'
        for f in part_files:
            with open(f, 'rb') as file_obj:
                files = [('files', (os.path.basename(f), file_obj))]
                resp = self._request_with_retry(requests.post, url, files=files, verify=False)
                if resp.status_code != 200:
                    self.logger.error(f"Erro ao enviar arquivo {f}: {resp.status_code} {resp.text}")
                    raise Exception(f"Erro ao enviar arquivo {f}: {resp.status_code} {resp.text}")
                self.logger.info(f"Arquivo {f} enviado com sucesso.")

        self.logger.info("Submetendo job runpaddle para toda a coleção...")
        url = self.base_url + f'api/jobs_tornado/{self.collection_id}/{method_endpoint}'
        headers = {'Content-Type': 'application/json', 'jwttoken': self.token}
        response = self._request_with_retry(requests.post, url, headers=headers, verify=False)
        if response.status_code == 200:
            slurm_id = response.text
            self.logger.info(f"Job submetido com slurm_id: {slurm_id}")
            return slurm_id
        else:
            self.logger.error(f"Erro ao enviar job: {response.status_code} {response.text}")
            raise Exception(f"Erro ao enviar job: {response.status_code} {response.text}")

    def wait_for_completion(self, slurm_id, poll_interval=10, timeout=1800):
        url = self.base_url + f'api/jobs_tornado/{slurm_id}/status'
        headers = {'Content-Type': 'application/json', 'jwttoken': self.token}
        elapsed = 0
        self.logger.info(f"Aguardando job {slurm_id} completar...")
        while elapsed < timeout:
            response = self._request_with_retry(requests.get, url, headers=headers, verify=False)
            status = response.text.strip().upper()
            self.logger.info(f"Status atual do job: {status}")
            if status == "COMPLETED":
                self.logger.info("Job COMPLETED.")
                return True
            elif status in ("FAILED", "CANCELLED"):
                self.logger.error(f"Job terminou com status: {status}")
                raise Exception(f"Job terminou com status: {status}")
            time.sleep(poll_interval)
            elapsed += poll_interval
        self.logger.error("Timeout esperando job completar.")
        raise TimeoutError("Timeout esperando job completar.")

    def download_and_extract_result(self, output_dir: str):
        results_dir = os.path.join(output_dir, self.collection_id)
        ensure_dir_exists(results_dir)
        url = self.base_url + f'api/jobs_tornado/{self.collection_id}/download'
        headers = {'Content-Type': 'application/json', 'jwttoken': self.token}
        self.logger.info("Baixando resultado do job...")
        response = self._request_with_retry(requests.get, url, headers=headers, verify=False)
        if response.status_code == 200:
            content_disposition = response.headers.get('content-disposition')
            if content_disposition:
                filename = content_disposition.split("filename=")[-1].strip('\"')
            else:
                filename = 'downloaded_file.zip'
            zip_path = os.path.join(output_dir, filename)
            with open(zip_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=128):
                    f.write(chunk)
            self.logger.info(f"Arquivo baixado em {zip_path}. Extraindo...")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(results_dir)
            self.logger.info(f"Arquivo extraído em {results_dir}")
            # Salva o chunk_page_map.json na raiz do diretório de resultados, se existir
            if self._chunk_page_map:
                chunk_map_dst = os.path.join(results_dir, "chunk_page_map.json")
                with open(chunk_map_dst, "w", encoding="utf-8") as f:
                    json.dump(self._chunk_page_map, f, ensure_ascii=False, indent=2)
                self.logger.info(f"chunk_page_map.json salvo em {chunk_map_dst}")
            else:
                self.logger.info("Nenhum chunk_page_map.json a salvar (PDF não foi dividido).")
            return zip_path
        else:
            self.logger.error(f"Erro ao fazer download: {response.status_code} {response.text}")
            raise Exception(f"Erro ao fazer download: {response.status_code} {response.text}")

class TornadoPaddleReader:
    """
    Lê resultados extraídos do Tornado (estrutura em pastas, com output.json e image_block_index.json)
    e gera YAMLs por página.
    """

    def __init__(self, results_root_dir: str, source: str, page_based_metadata: dict = None, table_interpretation_prompt_language: str = "pt-br", llm_model: BaseLanguageModel = None, insufficient_extraction_threshold: float = 20.0):
        self.results_root_dir = Path(results_root_dir)
        self.tables_processing_register_path = self.results_root_dir / "tables_processing_register.json"
        self.source = Path(source)
        self.page_based_metadata = page_based_metadata or {}
        # Busca automática do chunk_page_map.json na raiz do diretório de resultados
        self.chunk_page_map = None
        chunk_page_map_path = self.results_root_dir / "chunk_page_map.json"
        if chunk_page_map_path.exists():
            with open(chunk_page_map_path, "r", encoding="utf-8") as f:
                loaded_map = json.load(f)
            # Sanitize keys to match Tornado's directory naming
            self.chunk_page_map = {sanitize_chunk_dir_key(k): v for k, v in loaded_map.items()}
        self.table_interpretation_prompt_language = table_interpretation_prompt_language
        self.llm_model = llm_model
        self.insufficient_extraction_threshold = insufficient_extraction_threshold

    def save_to_tables_processing_register(self, page_dir, page, table_idx, kwargs):
        page_dir = str(page_dir)
        # Garante que sempre começa com um dicionário vazio se o arquivo não existir ou estiver inválido
        if self.tables_processing_register_path.exists():
            with open(self.tables_processing_register_path, "r", encoding="utf-8") as f:
                self.tables_processing_register = json.load(f)
        else:
            self.tables_processing_register = {}

        if page_dir not in self.tables_processing_register:
            self.tables_processing_register[page_dir] = {}
        if str(page) not in self.tables_processing_register[page_dir]:
            self.tables_processing_register[page_dir][str(page)] = {}
        self.tables_processing_register[page_dir][str(page)][str(table_idx)] = kwargs

        with open(self.tables_processing_register_path, "w", encoding="utf-8") as f:
            json.dump(self.tables_processing_register, f, ensure_ascii=False, indent=2)

    def get_table_load_kwargs(self, page_dir, page, table_idx):
        page_dir = str(page_dir)
        if not self.tables_processing_register_path.exists():
            return None
        with open(self.tables_processing_register_path, "r", encoding="utf-8") as f:
            self.tables_processing_register = json.load(f)

        return self.tables_processing_register.get(page_dir, {}).get(str(page), {}).get(str(table_idx))

    async def process(self) -> pd.DataFrame:
        """
        Processa os resultados do Tornado e retorna uma lista de dicionários flat (um por página).
        Cada dicionário contém todos os metadados e conteúdos de texto no mesmo nível.
        """
        insufficient_extraction_stats = self.calculate_insufficient_extraction_stats()
        insufficient_extraction_percentage = insufficient_extraction_stats["insufficient_extraction_percentage"]
        if (
            self.insufficient_extraction_threshold is not None
            and insufficient_extraction_percentage > self.insufficient_extraction_threshold
        ):
            logging.getLogger("TornadoPaddleReader").warning(
                "Insufficient extraction percentage %.2f is above threshold %.2f. Returning empty DataFrame.",
                insufficient_extraction_percentage,
                self.insufficient_extraction_threshold,
            )
            return pd.DataFrame()

        results = []
        for page_dir, page_idx, page_json in self.iter_pages():
            # Novo: determina página original se chunk_page_map estiver disponível
            original_page = None
            if self.chunk_page_map:
                chunk_name = page_dir.name + ".pdf" if not page_dir.name.endswith(".pdf") else page_dir.name
                page_list = self.chunk_page_map.get(sanitize_chunk_dir_key(chunk_name))
                if page_list and page_idx < len(page_list):
                    original_page = page_list[page_idx]
            flat_dicts = await self.page_to_flat_dicts(page_dir, page_idx, page_json, original_page=original_page)
            results.extend(flat_dicts)
        return pd.DataFrame.from_records(results)

    def calculate_insufficient_extraction_stats(self) -> dict:
        total_pages = 0
        insufficient_extraction_pages = 0
        pages_details = []

        for subdir in sorted(self.results_root_dir.iterdir()):
            if not subdir.is_dir():
                continue

            output_json_path = generate_output_json_filename(subdir)
            if not output_json_path.exists():
                continue

            with open(output_json_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            file_stats = calculate_insufficient_extraction_stats(data)
            total_pages += file_stats["total_pages"]
            insufficient_extraction_pages += file_stats["insufficient_extraction_pages"]
            pages_details.extend(file_stats["pages_details"])

        insufficient_extraction_percentage = (
            insufficient_extraction_pages / total_pages * 100
        ) if total_pages else 0.0

        return {
            "total_pages": total_pages,
            "insufficient_extraction_pages": insufficient_extraction_pages,
            "insufficient_extraction_percentage": insufficient_extraction_percentage,
            "pages_details": pages_details,
        }

    def iter_pages(self):
        """
        Itera sobre todos os diretórios de páginas, lendo o output.json e retornando (page_dir, page_idx, page_json).
        """
        for subdir in sorted(self.results_root_dir.iterdir()):
            if not subdir.is_dir():
                continue
            output_json_path = generate_output_json_filename(subdir)
            if not output_json_path.exists():
                continue
            with open(output_json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            layout_results = data.get("pages", [])
            for page_idx, page_json in enumerate(layout_results):
                yield subdir, page_idx, page_json

    async def page_to_flat_dicts(self, page_dir: Path, page_idx: int, page_json: dict, original_page: int = None):
        """
        Constrói um dicionário flat com todos os metadados e conteúdos de texto no mesmo nível.
        """
        metadata = self.page_based_metadata.get(
            int(page_idx),
            {
                "page": int(page_idx),
                "source": str(self.source),
                "page_dir": str(page_dir)
            }
        )
        # Adiciona página original à metadata, se disponível
        if original_page is not None:
            metadata["original_page"] = int(original_page)

        parsing_res_list = page_json.get("parsing_res_list", [])
        table_counter = 0

        flat_dicts = []
        for block_idx, block in enumerate(parsing_res_list):
            flat_dict = dict(metadata)
            block_label = block.get("block_label")
            block_content = block.get("block_content", "")
            block_bbox = block.get("block_bbox", [])
            flat_dict.update({
                "block_content": "",
                "block_label": block_label
            })

            if block_label in ["image", "chart"]:
                # img_info = next(image_iter, None)
                img_path = str(generate_image_block_index_filename(page_dir, block_bbox, block_label))
                flat_dict["block_label"] = "image"
                flat_dict['block_content'] = {
                    "image_path": img_path,
                    "image_description": block_content
                }
            elif block_label == "table":
                block_content_already_processed = self.get_table_load_kwargs(page_dir, page_idx, table_counter)
                if block_content_already_processed is not None:
                    table_name = block_content_already_processed.get("table_name", "")
                    table_description = block_content_already_processed.get("table_description", "")
                    table_id = block_content_already_processed.get('table_id')
                else:
                    response = await self.extract_dataframe_features(block_content)
                    table_id = f"page{page_idx}_table{table_counter}"
                    table_name = response.table_name
                    table_description = response.table_description
                flat_dict['block_content'] = {
                    "table_id": table_id,
                    "table_name": table_name,
                    "table_description": table_description,
                    "table_html": block_content
                }
                self.save_to_tables_processing_register(
                    page_dir=page_dir,
                    page=page_idx,
                    table_idx=table_counter,
                    kwargs=flat_dict['block_content']
                )
                table_counter += 1
                # flat_dict['block_content'] = block_content
            else:
                flat_dict['block_content'] = block_content

            flat_dicts.append(flat_dict)

        return flat_dicts

    async def extract_dataframe_features(self, table_as_html: str):
        chain = create_table_interpretation_chain(
            prompt_language=self.table_interpretation_prompt_language,
            llm=self.llm_model
        )
        # Executa a cadeia de prompts e retorna o modelo pydantic
        
        response = await async_ignore_error_with_these_strings(
            chain.ainvoke,
            {"table_as_html": table_as_html},
            errors_to_ignore=['connection error'],
            time_to_wait=2,
            max_retrials=None,
        )

        return response
    