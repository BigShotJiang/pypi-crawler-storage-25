from __future__ import annotations

import hashlib
import io
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import pandas as pd
from pdf2image import convert_from_path
from PIL import Image
from langchain_core.language_models.base import BaseLanguageModel

from eagle.chains.parsing.chains import create_parsing_chain
from eagle.utils.errors_handling import async_ignore_error_with_these_strings


class PPTXParser:
    """Parse .pptx files into a flat dataframe of blocks.

    Each slide is rendered as an image and interpreted by a multimodal parsing
    chain. The chain output is converted into document blocks (`text` and
    `image`) with image descriptions. At the end of each slide, the full slide
    image is saved as an image block.
    """

    def __init__(
        self,
        path: str,
        *,
        llm: BaseLanguageModel | None = None,
        prompt_language: str = "pt-br",
        img_dir: str | Path | None = None,
    ) -> None:
        self.path = path
        self.source = os.path.basename(path)
        self.img_dir = Path(img_dir) if img_dir is not None else Path(path).with_suffix("") / "images"
        self.llm = llm
        self.prompt_language = prompt_language

    # --- helpers ---------------------------------------------------------

    @staticmethod
    def _clean_text(text: str) -> str:
        return (text or "").strip()

    def _save_image(self, image: Image.Image) -> str:
        self.img_dir.mkdir(parents=True, exist_ok=True)

        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        image_bytes = buffer.getvalue()

        digest = hashlib.sha256(image_bytes).hexdigest()
        file_path = self.img_dir / f"{digest}.png"

        if not file_path.exists():
            with open(file_path, "wb") as f:
                f.write(image_bytes)

        return str(file_path)

    @staticmethod
    def _model_to_dict(value: Any) -> dict[str, Any]:
        if hasattr(value, "model_dump"):
            return value.model_dump()
        if isinstance(value, dict):
            return value
        return {}

    def _convert_to_pdf(self, output_dir: Path) -> Path:
        output_dir.mkdir(parents=True, exist_ok=True)
        command = [
            "soffice",
            "--headless",
            "--convert-to",
            "pdf",
            "--outdir",
            str(output_dir),
            self.path,
        ]
        try:
            subprocess.run(command, check=True, capture_output=True, text=True)
        except FileNotFoundError as exc:
            raise RuntimeError("LibreOffice (soffice) is required to parse PPTX as images.") from exc
        except subprocess.CalledProcessError as exc:
            stderr = (exc.stderr or "").strip()
            raise RuntimeError(f"Failed to convert PPTX to PDF: {stderr}") from exc

        expected_pdf = output_dir / f"{Path(self.path).stem}.pdf"
        if not expected_pdf.exists():
            raise RuntimeError("PPTX to PDF conversion did not produce the expected output file.")
        return expected_pdf

    def _render_slides_as_images(self) -> list[Image.Image]:
        with tempfile.TemporaryDirectory(prefix="eagle_pptx_") as temp_dir:
            pdf_path = self._convert_to_pdf(Path(temp_dir))
            slides = convert_from_path(str(pdf_path), dpi=200)
        return slides

    async def _parse_slide_blocks(self, slide_image: Image.Image, context: str = "") -> list[dict[str, Any]]:
        if not self.llm:
            return []

        chain = create_parsing_chain(
            prompt_language=self.prompt_language,
            llm=self.llm,
        )
        response = await async_ignore_error_with_these_strings(
            chain.ainvoke,
            {"image": slide_image, "context": context},
            errors_to_ignore=["connection error"],
            time_to_wait=2,
            max_retrials=None,
        )
        response_dict = self._model_to_dict(response)
        blocks = response_dict.get("blocos", [])
        return blocks if isinstance(blocks, list) else []

    # --- public API ------------------------------------------------------
    async def process(self) -> pd.DataFrame:
        records: list[dict[str, Any]] = []
        page_dir = ""

        slides = self._render_slides_as_images()

        for slide_idx, slide_image in enumerate(slides):
            blocks = await self._parse_slide_blocks(slide_image)

            for block in blocks:
                block_type = block.get("type")

                if block_type == "text":
                    content = self._clean_text(str(block.get("content", "")))
                    if not content:
                        continue
                    records.append(
                        {
                            "page": slide_idx,
                            "original_page": slide_idx,
                            "source": self.source,
                            "page_dir": page_dir,
                            "block_label": "text",
                            "block_content": content,
                        }
                    )
                    continue

                if block_type == "image":
                    content = self._clean_text(str(block.get("content", "")))
                    if not content:
                        continue
                    records.append(
                        {
                            "page": slide_idx,
                            "original_page": slide_idx,
                            "source": self.source,
                            "page_dir": page_dir,
                            "block_label": "text",
                            "block_content": f"[IMAGE] desc={content}"
                        }
                    )
                    continue

            # Add summary text and full slide image
            records.append(
                {
                    "page": slide_idx,
                    "original_page": slide_idx,
                    "source": self.source,
                    "page_dir": page_dir,
                    "block_label": "text",
                    "block_content": "Todo o conteúdo dessa página acima descrito pode ser visto na figura abaixo",
                }
            )
            image_path = self._save_image(slide_image)
            records.append(
                {
                    "page": slide_idx,
                    "original_page": slide_idx,
                    "source": self.source,
                    "page_dir": page_dir,
                    "block_label": "pinned-image",
                    "block_content": {
                        "image_path": image_path,
                        "image_description": "",
                    },
                }
            )

        return pd.DataFrame.from_records(records)


__all__ = ["PPTXParser"]
