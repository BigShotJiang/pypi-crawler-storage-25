from __future__ import annotations

import base64
import json
import os
import re
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
from langchain_core.language_models.base import BaseLanguageModel

from docling.document_converter import DocumentConverter

from eagle.chains.table_interpretation.chains import create_table_interpretation_chain
from eagle.utils.errors_handling import async_ignore_error_with_these_strings


class DocxParser:
    """Parse .docx files into a flat dataframe of blocks.

    This implementation is a lightweight port of the docx service used in another
    project. It uses Docling to convert the document into a structured tree and
    flattens the result into records with basic labels (text, table, image). When
    an LLM is provided, table interpretation is run to produce table name and
    description metadata.
    """

    def __init__(
        self,
        path: str,
        *,
        llm: BaseLanguageModel | None = None,
        prompt_language: str = "pt-br",
        img_dir: str | Path | None = None,
    ) -> None:
        self.path = path
        self.source = os.path.basename(path)
        self.img_dir = Path(img_dir) if img_dir is not None else Path(path).with_suffix("") / "images"
        self.llm = llm
        self.prompt_language = prompt_language
        self.sections: list[dict[str, Any]] | None = None

    # --- helpers ---------------------------------------------------------
    @staticmethod
    def parse_table_cells(table_cells: Iterable[dict[str, Any]]) -> tuple[list[list[str]], list[list[str]]]:
        """Convert Docling table cell spans into headers and data matrices."""
        cells = list(table_cells)
        if not cells:
            return [], []

        max_row = 0
        max_col = 0
        for cell in cells:
            max_row = max(max_row, cell.get("end_row_offset_idx", 0))
            max_col = max(max_col, cell.get("end_col_offset_idx", 0))

        matrix: list[list[str | None]] = [[None for _ in range(max_col)] for _ in range(max_row)]
        header_rows: set[int] = set()
        header_cols: set[int] = set()

        for cell in cells:
            text = cell.get("text", "")
            sr = cell.get("start_row_offset_idx", 0)
            er = cell.get("end_row_offset_idx", 0)
            sc = cell.get("start_col_offset_idx", 0)
            ec = cell.get("end_col_offset_idx", 0)
            if cell.get("column_header", False):
                for r in range(sr, er):
                    header_rows.add(r)
            if cell.get("row_header", False):
                for c in range(sc, ec):
                    header_cols.add(c)
            for r in range(sr, er):
                for c in range(sc, ec):
                    matrix[r][c] = text

        headers: list[list[str]] = []
        for r in sorted(header_rows):
            headers.append([(matrix[r][c] or "") for c in range(max_col)])

        data: list[list[str]] = []
        for r in range(max_row):
            if r in header_rows:
                continue
            data.append([(matrix[r][c] or "") for c in range(max_col)])

        return headers, data

    @staticmethod
    def _classify_block(text: str) -> str:
        text = text or ""
        if re.match(r"^\d+(\.\d+)*\s+\S+", text):
            return "title"
        if re.match(r"^[IVXLCDM]+\.\s+\S+", text):
            return "title"
        if re.match(r"^[-\*\•]\s+\S+", text):
            return "list_item"
        if re.match(r"^\d+[\)\.]\s+\S+", text):
            return "list_item"
        if text.isupper() and len(text.split()) < 10:
            return "title"
        if len(text.split()) < 8 and text.istitle():
            return "subtitle"
        return "paragraph"

    def _resolve_ref(self, ref: str, doc_dict: dict[str, Any]) -> Any:
        if not isinstance(ref, str) or not ref.startswith("#/"):
            return None
        parts = ref[2:].split("/")
        obj: Any = doc_dict
        for part in parts:
            if isinstance(obj, list):
                try:
                    obj = obj[int(part)]
                except Exception:
                    return None
            else:
                obj = obj.get(part)
                if obj is None:
                    return None
        return obj

    def _save_image(self, uri: str, mimetype: str, idx: int) -> str:
        ext = {
            "image/png": ".png",
            "image/jpeg": ".jpg",
            "image/jpg": ".jpg",
            "image/gif": ".gif",
            "image/bmp": ".bmp",
            "image/tiff": ".tiff",
        }.get(mimetype, ".img")

        self.img_dir.mkdir(parents=True, exist_ok=True)

        if uri.startswith("data:"):
            base64_data = uri.split(",", 1)[-1]
            image_bytes = base64.b64decode(base64_data)
        else:
            image_bytes = b""

        # Deduplicate by hashing image bytes so identical images share the same filename.
        import hashlib

        digest = hashlib.sha256(image_bytes).hexdigest() if image_bytes else f"img_{idx}"
        file_path = self.img_dir / f"{digest}{ext}"

        if image_bytes and not file_path.exists():
            with open(file_path, "wb") as f:
                f.write(image_bytes)

        return str(file_path)

    # --- doc structure ---------------------------------------------------
    def extract_docling_hierarchical(self) -> list[dict[str, Any]]:
        converter = DocumentConverter()
        doc = converter.convert(self.path).document
        doc_dict = doc.export_to_dict()

        ref_index: dict[str, Any] = {}
        for key in ["groups", "texts", "tables", "pictures"]:
            for item in doc_dict.get(key, []) or []:
                ref = item.get("self_ref") if isinstance(item, dict) else None
                if ref:
                    ref_index[ref] = item

        body_children = (doc_dict.get("body") or {}).get("children", [])

        sections: list[dict[str, Any]] = []
        current_section: dict[str, Any] | None = None
        image_counter = 0

        for child in body_children:
            ref = child.get("$ref") if isinstance(child, dict) else None
            block = self._resolve_ref(ref, doc_dict) if ref else child
            if not isinstance(block, dict):
                continue

            block_type = None
            block_content: list[dict[str, Any]] = []

            # Lists
            if block.get("label") == "list":
                for text_ref in block.get("children", []) or []:
                    text_block = self._resolve_ref(text_ref.get("$ref"), doc_dict) if isinstance(text_ref, dict) else text_ref
                    if text_block and text_block.get("label") == "list_item":
                        block_content.append({"type": "list_item", "text": text_block.get("text", "")})
                block_type = "list"

            # Tables
            elif str(block.get("self_ref", "")).startswith("#/tables/"):
                table_data = block.get("data", {})
                table_cells = table_data.get("table_cells", [])
                headers, data = self.parse_table_cells(table_cells)
                block_content.append({"type": "table", "headers": headers, "data": data})
                block_type = "table"

            # Images
            elif str(block.get("self_ref", "")).startswith("#/pictures/"):
                image_info = block.get("image", {}) or {}
                uri = image_info.get("uri", "")
                mimetype = image_info.get("mimetype", "image/png")
                image_file = self._save_image(uri, mimetype, image_counter)
                image_counter += 1
                block_content.append({"type": "image", "file": image_file})
                block_type = "image"

            # Texts
            elif str(block.get("self_ref", "")).startswith("#/texts/"):
                label = block.get("label", "")
                text = block.get("text", "")
                if label == "list_item":
                    block_content.append({"type": "list_item", "text": text})
                    block_type = "list_item"
                elif label in ("text", "paragraph"):
                    block_content.append({"type": "paragraph", "text": text})
                    block_type = "paragraph"
                else:
                    block_type = self._classify_block(text)
                    block_content.append({"type": block_type, "text": text})

            # Groups (ignore inline)
            elif str(block.get("self_ref", "")).startswith("#/groups/"):
                if block.get("label") == "inline":
                    continue
                # Other group types are not handled explicitly here.
                continue

            if not block_content:
                continue

            if block_type == "title" or (block_content and block_content[0].get("type") == "title"):
                if current_section:
                    sections.append(current_section)
                title_text = block_content[0].get("text", "")
                current_section = {"title": title_text, "content": []}
            else:
                if current_section is None:
                    current_section = {"title": "", "content": []}
                current_section["content"].extend(block_content)

        if current_section:
            sections.append(current_section)

        return sections

    # --- table enrichment -----------------------------------------------
    async def extract_dataframe_features(self, table_as_html: str) -> Any:
        if not self.llm:
            return None
        chain = create_table_interpretation_chain(
            prompt_language=self.prompt_language,
            llm=self.llm,
        )
        response = await async_ignore_error_with_these_strings(
            chain.ainvoke,
            {"table_as_html": table_as_html},
            errors_to_ignore=["connection error"],
            time_to_wait=2,
            max_retrials=None,
        )
        return response

    # --- public API ------------------------------------------------------
    async def process(self) -> pd.DataFrame:
        self.sections = self.extract_docling_hierarchical()
        records: list[dict[str, Any]] = []
        page = 0
        page_dir = ""
        table_counter = 0

        for section in self.sections:
            records.append(
                {
                    "page": page,
                    "original_page": page,
                    "source": self.source,
                    "page_dir": page_dir,
                    "block_label": "paragraph_title",
                    "block_content": section.get("title", ""),
                }
            )
            for block in section.get("content", []):
                btype = block.get("type")
                if btype in ("paragraph", "list_item"):
                    records.append(
                        {
                            "page": page,
                            "source": self.source,
                            "page_dir": page_dir,
                            "block_label": "text",
                            "block_content": block.get("text", ""),
                        }
                    )
                elif btype in ("title", "subtitle"):
                    records.append(
                        {
                            "page": page,
                            "source": self.source,
                            "page_dir": page_dir,
                            "block_label": "paragraph_title",
                            "block_content": block.get("text", ""),
                        }
                    )
                elif btype == "table":
                    headers = block.get("headers", []) or []
                    data = block.get("data", []) or []
                    df = pd.DataFrame(data)
                    if headers:
                        first_header = headers[0]
                        if len(first_header) == len(df.columns):
                            df.columns = first_header
                    table_as_html = df.to_html(index=False, header=True)
                    response = await self.extract_dataframe_features(table_as_html)
                    table_id = f"page{page}_table{table_counter}"
                    table_name = getattr(response, "table_name", "") if response is not None else ""
                    table_description = getattr(response, "table_description", "") if response is not None else ""
                    records.append(
                        {
                            "page": page,
                            "source": self.source,
                            "page_dir": page_dir,
                            "block_label": "table",
                            "block_content": {
                                "table_id": table_id,
                                "table_name": table_name,
                                "table_description": table_description,
                                "table_html": table_as_html,
                            },
                        }
                    )
                    table_counter += 1
                elif btype == "image":
                    records.append(
                        {
                            "page": page,
                            "source": self.source,
                            "page_dir": page_dir,
                            "block_label": "image",
                            "block_content": {
                                "image_path": block.get("file", ""),
                                "image_description": "",
                            },
                        }
                    )

        return pd.DataFrame.from_records(records)


__all__ = ["DocxParser"]
