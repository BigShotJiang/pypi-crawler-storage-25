from pydantic import BaseModel, Field, ConfigDict
from typing import Union, List, Dict

class AgentNodeCognitiveResponse(BaseModel):
    model_config = ConfigDict(extra='allow')

    action: str = Field(description="Action to be taken by the agent.")
    message: Union[List[Dict], str] = Field(description="Message associated with the action.")