from eagle.agents.memory.base import AgentMemory
from eagle.utils.agents_utils import extract_node_prefix
from jinja2 import Template
from langchain_core.messages import HumanMessage

# Prompts
OBSERVATION_STR_PT_BR = """
{%- if observation %}
Há pouco, você anotou a seguinte observação:
-------------------- Observação ------------------------
{{ observation }}
--------------------------------------------------------
{%- endif %}
"""
OBSERVATION_STR_EN = """
{%- if observation %}
You noted the following observation a moment ago:
-------------------- Observation --------------------
{{ observation }}
-----------------------------------------------------
{%- endif %}
"""

OBSERVATION_PROMPT_DICT = {
    "pt-br": Template(OBSERVATION_STR_PT_BR),
    "en": Template(OBSERVATION_STR_EN),
}

# Memory class
class SimpleObservationAgentMemory(AgentMemory):
    """
    A simple observation memory.
    """

    @staticmethod
    def _process_observation(observation):
        if isinstance(observation, str):
            return observation
        elif isinstance(observation, list):
            return "\n".join([x['text'] for x in observation if x['type'] == 'text'])
        
    def store_memory(self, state, config, node_name: str, step: str):
        return state

    def manifest_memory(self, state, config, node_name: str):
        """Return the most recent observation formatted as a prompt."""
        node_prefix = extract_node_prefix(node_name)
        prompt_language = config.get("configurable").get(f"{node_prefix}_node_llm_prompt_language")
        template = OBSERVATION_PROMPT_DICT.get(prompt_language, OBSERVATION_PROMPT_DICT["en"])
        rendered_observations = template.render(
            observation=self._process_observation(state.observation)
        )
        if rendered_observations.strip() == "":
            return None
        return HumanMessage(
            content=[{
                "type": "text",
                "text": rendered_observations
            }]
        )