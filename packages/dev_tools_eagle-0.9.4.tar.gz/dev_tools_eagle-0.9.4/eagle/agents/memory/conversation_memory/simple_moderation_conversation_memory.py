from eagle.agents.memory.base import AgentMemory
from eagle.utils.agents_utils import extract_node_prefix
import pandas as pd
from datetime import datetime
from jinja2 import Template
from langchain_core.messages import HumanMessage

MODERATION_CONVERSATION_PROMPT_STR_PT_BR = """
Você coordena duas conversas: uma com o **DEMANDANTE** e outra com os **PARTICIPANTES**.

{%- if messages_with_requester_past or messages_with_requester_current %}
Abaixo, sua conversa com o **DEMANDANTE**:
-----------------------------------------------
{%- if messages_with_requester_past %}
------- De interações passadas -------
{%- for message in messages_with_requester_past %}
[{{ message['timestamp'] }}] - {{ message['name'] }}: {{ message['content'] }}
{%- endfor %}
----------------------------------
{%- endif %}
{%- if messages_with_requester_current %}
------- Da interação atual -------
{%- for message in messages_with_requester_current %}
[{{ message['timestamp'] }}] - {{ message['name'] }}: {{ message['content'] }}
{%- endfor %}
----------------------------------
{%- endif %}
-----------------------------------------------
{%- else %}
Nenhuma mensagem trocada com o demandante ainda.
{%- endif %}

{%- if messages_with_agents_past or messages_with_agents_current %}
Abaixo, as mensagens trocadas entre os **PARTICIPANTES**:
-----------------------------------------------------
{%- if messages_with_agents_past %}
------- De interações passadas -------
{%- for message in messages_with_agents_past %}
[{{ message['timestamp'] }}] - {{ message['name'] }}: {{ message['content'] }}
{%- endfor %}
----------------------------------
{%- endif %}
{%- if messages_with_agents_current %}
------- Da interação atual -------
{%- for message in messages_with_agents_current %}
[{{ message['timestamp'] }}] - {{ message['name'] }}: {{ message['content'] }}
{%- endfor %}
----------------------------------
{%- endif %}
-----------------------------------------------------
{%- else %}
Nenhuma mensagem trocada entre os participantes ainda.
{%- endif %}
"""

MODERATION_CONVERSATION_PROMPT_STR_EN = """
You coordinate two conversations: one with the **REQUESTER** and another with the **PARTICIPANTS**.

{%- if messages_with_requester_past or messages_with_requester_current %}
Below, your conversation with the **REQUESTER**:
-----------------------------------------------
{%- if messages_with_requester_past %}
------- From past interactions -------
{%- for message in messages_with_requester_past %}
[{{ message['timestamp'] }}] - {{ message['name'] }}: {{ message['content'] }}
{%- endfor %}
----------------------------------
{%- endif %}
{%- if messages_with_requester_current %}
------- From current interaction -------
{%- for message in messages_with_requester_current %}
[{{ message['timestamp'] }}] - {{ message['name'] }}: {{ message['content'] }}
{%- endfor %}
----------------------------------
{%- endif %}
-----------------------------------------------
{%- else %}
No messages exchanged with the requester yet.
{%- endif %}

{%- if messages_with_agents_past or messages_with_agents_current %}
Below, messages exchanged among the **PARTICIPANTS**:
-----------------------------------------------------
{%- if messages_with_agents_past %}
------- From past interactions -------
{%- for message in messages_with_agents_past %}
[{{ message['timestamp'] }}] - {{ message['name'] }}: {{ message['content'] }}
{%- endfor %}
----------------------------------
{%- endif %}
{%- if messages_with_agents_current %}
------- From current interaction -------
{%- for message in messages_with_agents_current %}
[{{ message['timestamp'] }}] - {{ message['name'] }}: {{ message['content'] }}
{%- endfor %}
----------------------------------
{%- endif %}
-----------------------------------------------------
{%- else %}
No messages exchanged among the participants yet.
{%- endif %}
"""

MODERATION_CONVERSATION_PROMPT_DICT = {
    "pt-br": Template(MODERATION_CONVERSATION_PROMPT_STR_PT_BR),
    "en": Template(MODERATION_CONVERSATION_PROMPT_STR_EN),
}

class SimpleModerationConversationAgentMemory(AgentMemory):
    """
    Memória para agentes moderadores, separando mensagens com o demandante e entre participantes.
    """

    def __init__(self, chat_history_window_size: int = 10):
        self._chat_history_window_size = chat_history_window_size

    def _read_messages(self, state, target_name: str):
        messages_as_df_json = state.persistent_registers.get(f"{target_name}_df_json", {})
        messages_as_df = pd.read_json(messages_as_df_json, orient="records") if messages_as_df_json else pd.DataFrame(columns=["id", "name", "type", "content", "timestamp"])
        return messages_as_df

    def _add_messages(self, state, target_name: str):
        messages = getattr(state, target_name, [])
        if not messages:
            return state
        messages_as_df = self._read_messages(state, target_name)
        _new_messages = []
        for msg in messages:
            if msg.id not in messages_as_df['id'].values:
                msg_dict = {
                    "id": msg.id,
                    "name": msg.name,
                    "type": msg.type,
                    "content": msg.content,
                    "timestamp": datetime.utcnow(),
                }
                _new_messages.append(msg_dict)
        messages_as_df = pd.concat([messages_as_df, pd.DataFrame(_new_messages)], ignore_index=False)
        state.persistent_registers[f"{target_name}_df_json"] = messages_as_df.to_json(orient='records')
        return state

    def store_memory(self, state, config, node_name: str, step: str):
        """
        Armazena as mensagens separando entre demandante e participantes.
        Espera que state.messages_with_requester e state.messages_with_agents existam.
        """
        if step in ['start', 'end']:
            state = self._add_messages(state, "messages_with_requester")
            state = self._add_messages(state, "messages_with_agents")

        return state

    def manifest_memory(self, state, config, node_name: str):
        """
        Retorna as N mensagens mais recentes de cada grupo como string formatada.
        """
        node_prefix = extract_node_prefix(node_name)
        prompt_language = config.get("configurable", {}).get(f"{node_prefix}_node_llm_prompt_language", "en")
        template = MODERATION_CONVERSATION_PROMPT_DICT.get(prompt_language, MODERATION_CONVERSATION_PROMPT_DICT["en"])

        requester_df = self._read_messages(state, "messages_with_requester")
        agents_df = self._read_messages(state, "messages_with_agents")

        window_size = self._chat_history_window_size or config.get("configurable", {}).get("chat_history_window_size", 10)
        last_requester_msgs = requester_df.tail(window_size).copy()
        last_agents_msgs = agents_df.tail(window_size).copy()

        # Certifique-se de que a coluna 'timestamp' está no tipo correto e formato string
        if not last_requester_msgs.empty:
            last_requester_msgs['timestamp'] = pd.to_datetime(last_requester_msgs['timestamp'], utc=True)
        if not last_agents_msgs.empty:
            last_agents_msgs['timestamp'] = pd.to_datetime(last_agents_msgs['timestamp'], utc=True)

        requester_current = last_requester_msgs[last_requester_msgs['timestamp'] >= state.interaction_initial_datetime] if not last_requester_msgs.empty else last_requester_msgs
        requester_past = last_requester_msgs[last_requester_msgs['timestamp'] < state.interaction_initial_datetime] if not last_requester_msgs.empty else last_requester_msgs
        agents_current = last_agents_msgs[last_agents_msgs['timestamp'] >= state.interaction_initial_datetime] if not last_agents_msgs.empty else last_agents_msgs
        agents_past = last_agents_msgs[last_agents_msgs['timestamp'] < state.interaction_initial_datetime] if not last_agents_msgs.empty else last_agents_msgs

        # Formatar timestamps para string
        requester_current = requester_current.copy()
        requester_past = requester_past.copy()
        agents_current = agents_current.copy()
        agents_past = agents_past.copy()
        for df in [requester_current, requester_past, agents_current, agents_past]:
            if not df.empty:
                df['timestamp'] = df['timestamp'].dt.strftime('%Y-%m-%d %H:%M:%S')

        rendered = template.render(
            messages_with_requester_current=requester_current.to_dict('records'),
            messages_with_requester_past=requester_past.to_dict('records'),
            messages_with_agents_current=agents_current.to_dict('records'),
            messages_with_agents_past=agents_past.to_dict('records'),
        )
        return HumanMessage(
            content=[{
                "type": "text",
                "text": rendered
            }]
        )
