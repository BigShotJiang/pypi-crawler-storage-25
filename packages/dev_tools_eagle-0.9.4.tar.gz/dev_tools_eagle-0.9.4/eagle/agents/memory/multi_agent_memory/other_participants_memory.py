from eagle.agents.memory.base import AgentMemory
from eagle.chat_schemas.base import BasicChatSupervisorWorkingMemoryState
from eagle.utils.agents_utils import extract_node_prefix
from jinja2 import Template
from langchain_core.messages import HumanMessage

# Templates (assumindo que já existem no arquivo, mas incluindo aqui para referência)
THESE_ARE_THE_SOME_PARTICIPANTS_STR_PT_BR = """
{%- if participants %}
Abaixo, uma descrição dos **PARTICIPANTES**:
-----------------------------------------------------
{%- for participant in participants %}
Nome: {{ participant.name }}
Descrição: {{ participant.description }}

{%- endfor %}
-----------------------------------------------------
{%- endif %}
"""

THESE_ARE_THE_SOME_PARTICIPANTS_STR_EN = """
{%- if participants %}
Below is a description of the **PARTICIPANTS**:
-----------------------------------------------------
{%- for participant in participants %}
Name: {{ participant.name }}
Description: {{ participant.description }}

{%- endfor %}
-----------------------------------------------------
{%- endif %}
"""

THESE_ARE_THE_SOME_PARTICIPANTS_PROMPT_DICT = {
    "pt-br": Template(THESE_ARE_THE_SOME_PARTICIPANTS_STR_PT_BR),
    "en": Template(THESE_ARE_THE_SOME_PARTICIPANTS_STR_EN),
}

class OtherParticipantsMemory(AgentMemory):
    """
    Memory to manifest the participants present in the conversation.
    """

    def store_memory(self, state: BasicChatSupervisorWorkingMemoryState, config, node_name: str, step: str):
        # This memory does not store state between steps.
        return state

    def manifest_memory(self, state: BasicChatSupervisorWorkingMemoryState, config, node_name: str):
        node_prefix = extract_node_prefix(node_name)
        prompt_language = config.get("configurable", {}).get(f"{node_prefix}_node_llm_prompt_language", "en")
        template = THESE_ARE_THE_SOME_PARTICIPANTS_PROMPT_DICT.get(prompt_language, THESE_ARE_THE_SOME_PARTICIPANTS_PROMPT_DICT["en"])
        rendered = template.render(participants=state.participants)
        return HumanMessage(content=rendered)
