
from typing import List, Union, Tuple
from langchain_core.messages.base import BaseMessage
from eagle.agents.base import AgentNodeCognitiveResponse

class AgentMemory:
    """Base class for agent memory implementations."""
    
    def __init__(self):
        """Initialize the agent memory."""
        pass

    def store_memory(self, state, config, node_name: str, step: str = 'start'):

        return state

    def manifest_memory(self, state, config, node_name: str) -> Union[BaseMessage, None]:
        return None
    
    def is_it_done(self, state, config, node_name: str, message: str) -> Tuple[bool, List[dict], bool]:
        return True, [], False

class AgentMemoryStack:
    
    def __init__(self):
        self.memories = []

    def add_memories(self, memories: List[AgentMemory]):
        _memories = []
        for memory in memories:
            if memory and isinstance(memory, AgentMemory):
                _memories.append(memory)
        self.memories.extend(_memories)

    def store_memories(self, state, config, node_name: str, step: str = 'start'):
        for memory in self.memories:
            state = memory.store_memory(state, config, node_name, step=step)

        return state
    
    def is_it_done(self, state, config, node_name: str, response: AgentNodeCognitiveResponse) -> Tuple[bool, AgentNodeCognitiveResponse, bool]:
        overall_done = True
        overall_jump_to_execute = False
        combined_list = []
        for memory in self.memories:
            if hasattr(memory, "is_it_done"):
                done, lst, jump_to_execute = memory.is_it_done(state, config, node_name, response.message)
                overall_done = overall_done and done
                overall_jump_to_execute = overall_jump_to_execute or jump_to_execute
                combined_list.extend(lst)
        return overall_done, AgentNodeCognitiveResponse(**{**response.model_dump(), 'message': combined_list}) if combined_list else response, overall_jump_to_execute
        
    def manifest_memories(self, state, config, node_name: str) -> List[BaseMessage]:
        manifested = []
        for memory in self.memories:
            if memory and hasattr(memory, "manifest_memory"):
                manifested.append(memory.manifest_memory(state, config, node_name))
        return [m for m in manifested if m is not None]