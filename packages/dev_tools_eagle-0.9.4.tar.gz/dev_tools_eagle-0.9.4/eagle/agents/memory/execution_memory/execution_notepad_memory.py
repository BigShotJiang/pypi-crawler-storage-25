from eagle.agents.memory.base import AgentMemory
from typing import List, Tuple, Dict, Set


class ExecutionNotepadMemory(AgentMemory):
    """Memory implementation that acts as a notepad/cache for messages from is_it_done calls."""

    def __init__(self):
        """Initialize the execution notepad memory."""
        super().__init__()
        self._cache: Set[str] = []

    def store_memory(self, state, config, node_name: str, step: str):
        """Store memory: reset cache if step is 'start'."""
        if step == "start":
            self._cache = set()
        return state

    def manifest_memory(self, state, config, node_name):
        """Manifest memory: returns None as per requirements."""
        return None

    def is_it_done(self, state, config, node_name: str, message: str) -> Tuple[bool, List[Dict]]:
        """Always return True and the cached messages in the specified format."""
        self._cache.add(message)
        return True, [{"type": "text", "text": "\n".join(self._cache)}], False