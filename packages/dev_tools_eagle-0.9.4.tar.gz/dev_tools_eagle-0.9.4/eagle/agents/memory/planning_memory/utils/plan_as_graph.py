import networkx as nx
from typing import List, Dict, Any
from pydantic import BaseModel, Field


class Dependency(BaseModel):
    name: str = Field(..., description="Name of the task this depends on")
    mandatory: bool = Field(..., description="Whether this dependency is mandatory")
    info: str = Field(..., description="Descriptive string of information transferred from source to destination")


class Task(BaseModel):
    name: str = Field(..., description="Name of the task")
    description: str = Field(..., description="Description of the task")
    status: str = Field(..., description="Status of the task: 'not_started', 'completed', 'with_issues'")
    notes: str = Field("", description="Additional notes")
    dependencies: List[Dependency] = Field(default_factory=list, description="List of dependencies")


class PlanGraph:
    """
    Utility class to represent a task execution plan as a directed graph in NetworkX.

    Each node represents an activity with properties:
    - name: Task name
    - description: Task description
    - status: Task status ('not_started', 'completed', 'with_issues')
    - notes: Additional notes

    Directed edges represent dependencies between tasks, with properties:
    - mandatory: Boolean indicating if the dependency is mandatory
    - info: Descriptive string of information flowing from source to destination
    """

    def __init__(self):
        """
        Initializes an empty graph.
        """
        self.graph = nx.DiGraph()
        self.collected_nodes = set()  # Track nodes already collected in subgraphs

    def add_tasks_from_data(self, data: List[Task]):
        """
        Feeds the graph with new tasks from a structured data list.

        Expected structure for each task in data: A Task Pydantic model instance.

        :param data: List of Task models representing the tasks
        """
        for task in data:
            # Add node with properties
            self.graph.add_node(task.name,
                                description=task.description,
                                status=task.status,
                                notes=task.notes)

            # Add edges for dependencies
            for dep in task.dependencies:
                self.graph.add_edge(task.name, dep.name, mandatory=dep.mandatory, info=dep.info)

    def get_graph(self) -> nx.DiGraph:
        """
        Returns the NetworkX graph.

        :return: The directed graph
        """
        return self.graph

    def get_subgraph(self, num_tasks: int, status_filter: List[str] = None, nodes_to_visit_again: List[str] = ["not_started"]) -> nx.DiGraph:
        """
        Returns a subgraph by navigating from root nodes (nodes with no incoming edges),
        collecting up to num_tasks nodes that match the status_filter and have not been collected before,
        unless their status is in nodes_to_visit_again, in which case they can be collected again.

        Navigation starts from root nodes and explores successors in BFS order.
        If multiple roots exist, they are all considered starting points.
        This allows progressive consumption of the graph.

        :param num_tasks: Maximum number of tasks to include in the subgraph
        :param status_filter: List of allowed statuses (e.g., ['not_started', 'completed']).
                              If None, all statuses are allowed.
        :param nodes_to_visit_again: List of statuses that allow nodes to be visited again even if previously collected.
                                     Defaults to ['not_started'].
        :return: A subgraph as nx.DiGraph
        """
        if status_filter is None:
            status_filter = ['not_started', 'completed', 'with_issues']
        if nodes_to_visit_again is None:
            nodes_to_visit_again = ['not_started']

        # Find root nodes (nodes with no incoming edges)
        roots = [n for n in self.graph.nodes if self.graph.in_degree(n) == 0]

        # BFS to collect nodes
        queue = list(roots)
        collected = []
        processed = set()  # To avoid processing the same node multiple times in this BFS traversal

        while queue and len(collected) < num_tasks:
            current = queue.pop(0)
            if current in processed:
                continue
            processed.add(current)

            # Check if this node should be collected
            node_status = self.graph.nodes[current].get('status')
            if node_status in status_filter and (current not in self.collected_nodes or node_status in nodes_to_visit_again):
                collected.append(current)
                self.collected_nodes.add(current)

            # Add successors to queue if not yet processed
            for successor in self.graph.successors(current):
                if successor not in processed:
                    queue.append(successor)

        # Create subgraph induced by newly collected nodes
        subgraph = self.graph.subgraph(collected).copy()
        return subgraph

    def reset_collected(self):
        """
        Resets the collected nodes state, allowing the graph to be consumed again from the beginning.
        """
        self.collected_nodes.clear()
