from eagle.agents.memory.base import AgentMemory
from eagle.utils.agents_utils import extract_node_prefix
from eagle.utils.prompt_utils import EagleJsonOutputParser
from eagle.agents.memory.conversation_memory.simple_conversation_memory import SimpleConversationAgentMemory
from eagle.agents.memory.conversation_memory.simple_moderation_conversation_memory import SimpleModerationConversationAgentMemory
from eagle.agents.memory.planning_memory.utils.plan_as_graph import PlanGraph, Task, Dependency
from eagle.utils.errors_handling import sync_ignore_error_with_these_strings
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableSequence, RunnableLambda
from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.messages import HumanMessage
from pydantic import BaseModel, Field
from jinja2 import Template
from typing import List, ClassVar
from operator import itemgetter

# Prompts
CREATE_TODO_LIST_STR_PT_BR = """
Você é um agente de planejamento que cria listas de tarefas para atingir objetivos específicos. Com base nas informações fornecidas, elabore uma lista de tarefas detalhada e organizada que ajude a alcançar o objetivo proposto.
Observe o histórico de interações abaixo e o plano proposto:
------------------ Histórico de Interações ------------------
{{ history }}
-------------------------------------------------------------
{%- if last_plan %}
------------------ Plano Proposto ANTERIORMENTE -------------
{{ last_plan }}
-------------------------------------------------------------
{%- endif %}
{%- if observation %}
------------------ Observações Recentes ------------------
{{ observation }}
----------------------------------------------------------
{%- endif %}
------------------ Plano Proposto AGORA ------------------
{{ proposed_plan }}
----------------------------------------------------------
Com base nessas informações, defina ou atualize a lista ORDENADA de tarefas com a seguinte estrutura:
{
  "tarefas": [
    {
      "nome": "Nome único da tarefa",
      "descricao": "Descrição detalhada da tarefa",
      "status": "not_started" ou "completed" ou "with_issues",
      "anotacoes": "Anotações sobre problemas, caso status seja 'with_issues', ou de conclusões importantes, caso o status seja 'completed'.",
      "tarefas_dependentes": [
        {
          "name": "nome de outra tarefa futura da lista 'tarefas' que depende da execução prévia desta tarefa 'Nome único da tarefa'.",
          "mandatory": true, # ou false, se não for uma dependência obrigatória.
          "info": "informação sobre a dependência"
        }, ...
      ]
    },
    {
    ... outra tarefa ...
    }... e assim por diante ...
  ]
}
Diretrizes importantes:
- Mantenha as tarefas concluídas na lista para registro.
- Indique claramente as tarefas problemáticas com anotações apropriadas.
- Para uma lista de tarefas sequencial, cada tarefa (exceto a primeira) deve ter uma dependência para a tarefa anterior na lista.
RESPOSTA:
"""

CREATE_TODO_LIST_STR_EN = """
You are a planning agent that creates task lists to achieve specific goals. Based on the provided information, craft a detailed and organized task list that helps accomplish the proposed objective.
Review the interaction history below and the proposed plan:
------------------ Interaction History ------------------
{{ history }}
---------------------------------------------------------
{%- if last_plan %}
------------------ Previously Proposed Plan -------------
{{ last_plan }}
---------------------------------------------------------
{%- endif %}
{%- if observation %}
------------------ Recent Observations ------------------
{{ observation }}
----------------------------------------------------------
{%- endif %}
------------------ Currently Proposed Plan ------------------
{{ proposed_plan }}
----------------------------------------------------------
Based on this information, define or update the ORDERED list of tasks with the following structure:
{
  "tasks": [
    {
      "name": "Unique name of the task",
      "description": "Detailed description of the task",
      "status": "not_started" or "completed" or "with_issues",
      "annotations": "Notes about problems, if status is 'with_issues', or important conclusions, if status is 'completed'.",
      "dependent_tasks": [
        {
          "name": "Name of another future task in the 'tasks' list that depends on the prior execution of this task 'Unique name of the task'",
          "mandatory": true, # or false, if it's not a mandatory dependency.
          "info": "information about the dependency"
        }, ...
      ]
    },
    { ... another task ...
    }... and so on ...
  ]
}
Important guidelines:
- Maintain the completed tasks in the list for record-keeping.
- Clearly indicate problematic tasks with appropriate annotations.
- For a sequential task list, each task (except the first) should have a dependency on the previous task in the list.
RESPONSE:
"""

CREATE_TO_DO_LIST_PROMPTS = {
    "en": PromptTemplate.from_template(CREATE_TODO_LIST_STR_EN, template_format="jinja2"),
    "pt-br": PromptTemplate.from_template(CREATE_TODO_LIST_STR_PT_BR, template_format="jinja2"),
}


MANIFEST_TODO_LIST_STR_PT_BR = """
----------- Plano a ser Executado ------------
Lista de Tarefas:
{%- for item in plan.tasks %}
- Descrição: {{ item.description }}
  Status: {{ item.status }}
  Anotações: {{ item.annotations }}
{%- endfor %}
----------------------------------------------
"""

MANIFEST_TODO_LIST_STR_EN = """
------------ Plan to be Executed -------------
Task List:
{%- for item in plan.tasks %}
- Description: {{ item.description }}
  Status: {{ item.status }}
  Annotations: {{ item.annotations }}
{%- endfor %}
----------------------------------------------
"""

MANIFEST_TO_DO_LIST_PROMPTS = {
    "en": Template(MANIFEST_TODO_LIST_STR_EN),
    "pt-br": Template(MANIFEST_TODO_LIST_STR_PT_BR),
}

MANIFEST_PLAN_STR_EN = """
------------ Plan to be Executed -------------
{%- if summary %}
Summary of tasks already executed:
{{ summary }}
{%- endif %}
{%- if tasks %}
Task list yet to be executed:
{%- for item in tasks %}
- Name: {{ item.name }}
  Description: {{ item.description }}
  Status: {{ item.status }}
  Annotations: {{ item.annotations }}
{%- endfor %}
{%- else %}
Plan execution is complete.
{%- endif %}
----------------------------------------------
"""

MANIFEST_PLAN_STR_PT_BR = """
----------- Plano a ser Executado ------------
{%- if summary %}
Sumário das tarefas já realizadas:
{{ summary }}
{%- endif %}
{%- if tasks %}
Lista de Tarefas a serem realizadas:
{%- for item in tasks %}
- Nome: {{ item.name }}
  Descrição: {{ item.description }}
  Status: {{ item.status }}
  Anotações: {{ item.annotations }}
{%- endfor %}
{%- else %}
A execução do plano está completa.
{%- endif %}
----------------------------------------------
"""

MANIFEST_PLAN_TEMPLATES = {
    "en": Template(MANIFEST_PLAN_STR_EN),
    "pt-br": Template(MANIFEST_PLAN_STR_PT_BR),
}

EXECUTED_TASKS_ANNOTATIONS_STR_EN = """\
------------ Executed Tasks Annotations -------------
{%- for item in tasks %}
- {{ item.name }}: {{ item.annotations }}
{%- endfor %}
------------------------------------------------------
"""

EXECUTED_TASKS_ANNOTATIONS_STR_PT_BR = """\
----------- Anotações das Tarefas Executadas ---------
{%- for item in tasks %}
- {{ item.name }}: {{ item.annotations }}
{%- endfor %}
------------------------------------------------------
"""

EXECUTED_TASKS_ANNOTATIONS_TEMPLATES = {
    "en": Template(EXECUTED_TASKS_ANNOTATIONS_STR_EN),
    "pt-br": Template(EXECUTED_TASKS_ANNOTATIONS_STR_PT_BR),
}

# Update Plan Prompts
UPDATE_PLAN_STR_EN = """
You are an agent that updates the plan based on new information from the agent.

Current Plan:
{%- for item in current_plan.tasks %}
{{ item.name }}: Description: {{ item.description }}
  Status: {{ item.status }}
  Annotations: {{ item.annotations }}
{%- endfor %}

Message from agent: {{ message }}

Based on the message, update the tasks that have been addressed, completed, or should be considered processed. Provide a summary of these items and list the updated tasks with their new statuses and annotations.
IMPORTANT POINTS: 
- The only possible statuses are 'not_started', 'completed', and 'with_issues'.
- Include in "updated_tasks" those tasks that, although not explicitly mentioned in the agent’s message, can have their status and notes inferred from the context of the message.
- Therefore, define the status of all tasks referenced in the current plan.

Output in JSON format:
{
  "updated_tasks": [
    {
      "name": "task_name",
      "status": "completed",
      "annotations": "DETAILED notes extracted from the agent's message regarding the task. This is the only memory that will remain of what was done in this task."
    },
    {
      "name": "another_task",
      "status": "with_issues",
      "annotations": "DETAILED description of the problem, extracted from the agent's message, regarding the task. This is the only memory that will remain of what was done in this task."
    },...
  ],
  "summary": "string summary of the processed items"
}
RESPONSE:
"""

UPDATE_PLAN_STR_PT_BR = """
Você é um agente que atualiza o plano com base em novas informações do agente.

Plano Atual:
{%- for item in current_plan.tasks %}
{{ item.name }}: Descrição: {{ item.description }}
  Status: {{ item.status }}
  Anotações: {{ item.annotations }}
{%- endfor %}

Mensagem do agente: {{ message }}

Com base na mensagem, identifique os itens que foram abordados, concluídos ou devem ser considerados processados. Forneça um resumo desses itens e liste as tarefas atualizadas com seus novos status e anotações.
PONTOS IMPORTANTES: 
- Os únicos status possíveis são 'not_started', 'completed' e 'with_issues'.
- Inclua no "updated_tasks" aquelas tarefas que, embora não estejam explicitamente citadas na mensagem do agente, podem ter seu status e anotações inferidos a partir do contexto da mensagem.
- Defina, portanto, o status de todas as tarefas citadas no plano atual.

Saída em formato JSON:
{
  "updated_tasks": [
    {
      "name": "nome_da_tarefa",
      "status": "completed",
      "annotations": "Notas DETALHADAS, extraídas da mensagem do agente, referentes à tarefa. Essa é a única memória que restará do que foi feito nesta tarefa."
    },
    {
      "name": "outra_tarefa",
      "status": "with_issues",
      "annotations": "Descrição DETALHADA do problema, extraída da mensagem do agente, referente à tarefa. Essa é a única memória que restará do que foi feito nesta tarefa."
    }, ...
  ],
  "summary": "resumo em string dos itens processados"
}
RESPOSTA:
"""

UPDATE_PLAN_PROMPTS = {
    "en": PromptTemplate.from_template(UPDATE_PLAN_STR_EN, template_format="jinja2"),
    "pt-br": PromptTemplate.from_template(UPDATE_PLAN_STR_PT_BR, template_format="jinja2"),
}

# Schemas
class ToDoListItemSchemaPT_BR(BaseModel):
    nome: str = Field(..., description="Nome único da tarefa")
    descricao: str = Field(..., description="Descrição detalhada da tarefa")
    status: str = Field(..., description="Status da tarefa: 'not_started', 'completed' ou 'with_issues'")
    anotacoes: str = Field("", description="Anotações sobre problemas ou conclusões importantes")
    tarefas_dependentes: List[Dependency] = Field(default_factory=list, description="Lista de tarefas dependentes desta.")

class ToDoListItemSchemaEN(BaseModel):
    name: str = Field(..., description="Unique name of the task")
    description: str = Field(..., description="Detailed description of the task")
    status: str = Field(..., description="Task status: 'not_started', 'completed' or 'with_issues'")
    annotations: str = Field("", description="Notes about problems or important conclusions")
    dependent_tasks: List[Dependency] = Field(default_factory=list, description="List of depentent tasks.")

class ToDoListSchemaPT_BR(BaseModel):
    tarefas: List[ToDoListItemSchemaPT_BR] = Field(..., description="Lista de tarefas") 

class ToDoListSchemaEN(BaseModel):
    tasks: List[ToDoListItemSchemaEN] = Field(..., description="List of tasks")

# Updated Task Schema
class UpdatedTaskSchema(BaseModel):
    name: str = Field(..., description="Name of the task")
    status: str = Field(..., description="Updated status of the task")
    annotations: str = Field("", description="Updated annotations for the task")

# Update Plan Schema
class UpdatePlanSchema(BaseModel):
    updated_tasks: List[UpdatedTaskSchema] = Field(..., description="List of updated tasks")
    summary: str = Field(..., description="Summary of the processed items")

# Update Plan Output Parser
class UpdatePlanOutputParser(EagleJsonOutputParser):
    
    CONVERTION_SCHEMA: ClassVar[dict] = {
        "pt-br": {
            "class_for_parsing": UpdatePlanSchema,
            "convertion_schema": {
                "updated_tasks": {
                    "target_key": "updated_tasks",
                    "value_mapping": {
                        "name": {
                            "target_key": "name",
                            "value_mapping": {}
                        },
                        "status": {
                            "target_key": "status",
                            "value_mapping": {}
                        },
                        "annotations": {
                            "target_key": "annotations",
                            "value_mapping": {}
                        }
                    }
                },
                "summary": {
                    "target_key": "summary",
                    "value_mapping": {}
                }
            }
        },
        "en": {
            "class_for_parsing": UpdatePlanSchema,
            "convertion_schema": {
                "updated_tasks": {
                    "target_key": "updated_tasks",
                    "value_mapping": {
                        "name": {
                            "target_key": "name",
                            "value_mapping": {}
                        },
                        "status": {
                            "target_key": "status",
                            "value_mapping": {}
                        },
                        "annotations": {
                            "target_key": "annotations",
                            "value_mapping": {}
                        }
                    }
                },
                "summary": {
                    "target_key": "summary",
                    "value_mapping": {}
                }
            }
        },
    }

    TARGET_SCHEMA: BaseModel = UpdatePlanSchema

# Output Parsers
class ToDoListOutputParser(EagleJsonOutputParser):
    
    CONVERTION_SCHEMA: ClassVar[dict] = {
        "pt-br": {
            "class_for_parsing": ToDoListSchemaPT_BR,
            "convertion_schema": {
                "tarefas": {
                    "target_key": "tasks",
                    "value_mapping": {
                        "nome": {
                            "target_key": "name",
                            "value_mapping": {}
                        },
                        "descricao": {
                            "target_key": "description",
                            "value_mapping": {}
                        },
                        "status": {
                            "target_key": "status",
                            "value_mapping": {}
                        },
                        "anotacoes": {
                            "target_key": "annotations",
                            "value_mapping": {}
                        },
                        "tarefas_dependentes": {
                            "target_key": "dependent_tasks",
                            "value_mapping": {
                                "name": {
                                    "target_key": "name",
                                    "value_mapping": {}
                                },
                                "mandatory": {
                                    "target_key": "mandatory",
                                    "value_mapping": {}
                                },
                                "info": {
                                    "target_key": "info",
                                    "value_mapping": {}
                                }
                            }
                        }
                    }
                }
            }
        },
        "en": {
            "class_for_parsing": ToDoListSchemaEN,
            "convertion_schema": {
                "tasks": {
                    "target_key": "tasks",
                    "value_mapping": {
                        "name": {
                            "target_key": "name",
                            "value_mapping": {}
                        },
                        "description": {
                            "target_key": "description",
                            "value_mapping": {}
                        },
                        "status": {
                            "target_key": "status",
                            "value_mapping": {}
                        },
                        "annotations": {
                            "target_key": "annotations",
                            "value_mapping": {}
                        },
                        "dependent_tasks": {
                            "target_key": "dependent_tasks",
                            "value_mapping": {
                                "name": {
                                    "target_key": "name",
                                    "value_mapping": {}
                                },
                                "mandatory": {
                                    "target_key": "mandatory",
                                    "value_mapping": {}
                                },
                                "info": {
                                    "target_key": "info",
                                    "value_mapping": {}
                                }
                            }
                        }
                    }
                }
            }
        },
    }

    TARGET_SCHEMA: BaseModel = ToDoListSchemaEN

# Chains
def _get_create_a_todo_list_chain(prompt_language: str, llm: BaseLanguageModel, use_structured_output: bool = False) -> RunnableSequence:
    if prompt_language not in CREATE_TO_DO_LIST_PROMPTS:
        raise ValueError(f"Unsupported prompt language: {prompt_language}")
    prompt = CREATE_TO_DO_LIST_PROMPTS[prompt_language]
    output_parser = ToDoListOutputParser(
        source_lang=prompt_language,
        llm=llm,
        use_structured_output=use_structured_output
    )
    _parse = RunnableLambda(lambda x: output_parser.parse(x))
    chain = (
        {"history": itemgetter("history"), "last_plan": itemgetter("last_plan"), "observation": itemgetter("observation"), "proposed_plan": itemgetter("proposed_plan")}
        | prompt
        | llm
        | _parse
    )
    return chain

def _get_update_plan_chain(prompt_language: str, llm: BaseLanguageModel, use_structured_output: bool = False) -> RunnableSequence:
    if prompt_language not in UPDATE_PLAN_PROMPTS:
        raise ValueError(f"Unsupported prompt language: {prompt_language}")
    prompt = UPDATE_PLAN_PROMPTS[prompt_language]
    if use_structured_output:
        chain = prompt | llm.with_structured_output(UpdatePlanSchema)
    else:
        output_parser = UpdatePlanOutputParser(
            source_lang=prompt_language,
            llm=llm,
            use_structured_output=use_structured_output
        )
        _parse = RunnableLambda(lambda x: output_parser.parse(x))
        chain = prompt | llm | _parse
    return chain

# Memory class
class ToDoListPlanningAgentMemory(AgentMemory):
    """Memory implementation for to-do list planning."""

    def __init__(
            self,
            nodes_to_plan_on: List[str] = ["plan"],
            llm: BaseLanguageModel = None,
            use_structured_output: bool = False,
            chat_history_window_size: int = None,
            is_moderator: bool = False,
            batch_size: int = 1,
        ):
        """Initialize the to-do list planning memory."""
        super().__init__()
        self._nodes_to_plan_on = nodes_to_plan_on
        self._llm = llm
        self._use_structured_output = use_structured_output
        self._is_moderator = is_moderator
        self._conversation_memory = SimpleModerationConversationAgentMemory(chat_history_window_size) if self._is_moderator else SimpleConversationAgentMemory(chat_history_window_size)
        self._batch_size = batch_size
        self._already_seen_plan_items_summary = ""
        self.reset_plan()

    def reset_plan(self):
        self._plan_graph = PlanGraph()
        self._tasks_in_batch = None

    @staticmethod
    def _process_plan(plan):

        if isinstance(plan, str):
            return plan
        elif isinstance(plan, list):
            return "\n".join([x['text'] for x in plan if x['type'] == 'text'])

    @staticmethod
    def _process_observation(observation):
        if isinstance(observation, str):
            return observation
        elif isinstance(observation, list):
            return "\n".join([x['text'] for x in observation if x['type'] == 'text'])

    def store_memory(self, state, config, node_name: str, step: str):
        """Store memory if the node is in the nodes to plan on."""
        node_prefix = extract_node_prefix(node_name)
        self._conversation_memory.store_memory(state, config, node_name, step)
        if node_prefix in self._nodes_to_plan_on and step == 'end' and state.plan:
            # Implement logic to store to-do list planning memory
            llm = self._llm or config.get("configurable").get(f"{node_prefix}_node_llm")
            use_structured_output = self._use_structured_output or config.get("configurable").get(f"{node_prefix}_node_llm_use_structured_output")
            prompt_language = config.get("configurable").get(f"{node_prefix}_node_llm_prompt_language")
            history = self._conversation_memory.manifest_memory(state, config, node_name)
            last_plan = self.manifest_memory(state, config, node_name)
            chain = _get_create_a_todo_list_chain(prompt_language, llm, use_structured_output)
            inputs = {
                "history": history.content if history else "",
                "last_plan": last_plan.content if last_plan else "",
                "observation": self._process_observation(state.observation) if state.observation else "",
                "proposed_plan": self._process_plan(state.plan) or ""
            }

            plan_result = sync_ignore_error_with_these_strings(
                chain.invoke,
                inputs,
                errors_to_ignore=[
                    "content filter"
                ],
                max_retrials=5,
                time_to_wait=1
            )
            self.reset_plan()
            # Create Task objects using dependencies from the chain
            tasks = []
            for task_item in plan_result.tasks:
                task = Task(
                    name=task_item.name,
                    description=task_item.description,
                    status=task_item.status,
                    notes=task_item.annotations,
                    dependencies=task_item.dependent_tasks
                )
                tasks.append(task)
            self._plan_graph.add_tasks_from_data(tasks)
        return state

    def manifest_memory(self, state, config, node_name):
        """Manifest the current to-do list plan."""
        if self._plan_graph.get_graph().number_of_nodes() > 0:
            node_prefix = extract_node_prefix(node_name)
            prompt_language = config.get("configurable").get(f"{node_prefix}_node_llm_prompt_language")
            if prompt_language not in MANIFEST_PLAN_TEMPLATES:
                raise ValueError(f"Unsupported prompt language: {prompt_language}")
            
            # Get subgraph for current batch
            subgraph = self._plan_graph.get_subgraph(self._batch_size, status_filter=['not_started', 'completed', 'with_issues'])
            self._tasks_in_batch = []
            for node in subgraph.nodes:
                node_data = subgraph.nodes[node]
                self._tasks_in_batch.append({
                    'name': node,
                    'description': node_data['description'],
                    'status': node_data['status'],
                    'annotations': node_data['notes']
                })
            
            # Render the plan manifest
            template = MANIFEST_PLAN_TEMPLATES[prompt_language]
            rendered = template.render(summary=self._already_seen_plan_items_summary, tasks=self._tasks_in_batch)
            return HumanMessage(
                content=[{
                    "type": "text",
                    "text": rendered
                }]
            )
        else:
            return None
        
    def get_executed_tasks_annotations(self, prompt_language: str) -> str:
        if prompt_language not in EXECUTED_TASKS_ANNOTATIONS_TEMPLATES:
            raise ValueError(f"Unsupported prompt language: {prompt_language}")
        executed_tasks = [
            {'name': node, 'annotations': self._plan_graph.get_graph().nodes[node]['notes']}
            for node in self._plan_graph.get_graph().nodes
            if self._plan_graph.get_graph().nodes[node]['status'] != 'not_started'
        ]
        template = EXECUTED_TASKS_ANNOTATIONS_TEMPLATES[prompt_language]
        return template.render(tasks=executed_tasks)

    def is_it_done(self, state, config, node_name, message):
        """Check if the plan is done and update seen items based on the message."""
        if self._tasks_in_batch and len(self._tasks_in_batch) > 0 and "execute" in node_name:
            node_prefix = extract_node_prefix(node_name)
            llm = self._llm or config.get("configurable").get(f"{node_prefix}_node_llm")
            use_structured_output = self._use_structured_output or config.get("configurable").get(f"{node_prefix}_node_llm_use_structured_output")
            prompt_language = config.get("configurable").get(f"{node_prefix}_node_llm_prompt_language")
            
            # Get tasks in batch for update
            current_plan = type('obj', (object,), {'tasks': self._tasks_in_batch})
            
            chain = _get_update_plan_chain(prompt_language, llm, use_structured_output)
            inputs = {
                "current_plan": current_plan,
                "message": message
            }
            result = sync_ignore_error_with_these_strings(
                chain.invoke,
                inputs,
                errors_to_ignore=[
                    "content filter"
                ],
                max_retrials=5,
                time_to_wait=1
            )
            
            updated_tasks = result.updated_tasks
            summary = result.summary
            
            # Update statuses and notes in graph
            for updated_task in updated_tasks:
                if updated_task.name in self._plan_graph.get_graph().nodes:
                    self._plan_graph.get_graph().nodes[updated_task.name]['status'] = updated_task.status
                    self._plan_graph.get_graph().nodes[updated_task.name]['notes'] = updated_task.annotations
            
            # Append to summary
            if summary:
                self._already_seen_plan_items_summary += summary + "\n"
            
            # Check if all tasks are not 'not_started'
            all_steps_started = all(
                    self._plan_graph.get_graph().nodes[node]['status'] != 'not_started'
                    for node in self._plan_graph.get_graph().nodes
                )
            if self._is_moderator:
                return True, [], True if not all_steps_started else False
            else:
                
                return all_steps_started, [{"type": "text", "text": self.get_executed_tasks_annotations(prompt_language)}], False
        else:
            return True, [], False
        