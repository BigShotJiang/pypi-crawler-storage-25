from eagle.agents.memory.base import AgentMemoryStack
from eagle.agents.reasoning.enums import AgentRoleEnum
from eagle.agents.base import AgentNodeCognitiveResponse

class AgentNodeCognitiveModel:
    """
    Base class for agent cognitive models.
    """

    def __init__(
            self,
            agent_role: AgentRoleEnum = AgentRoleEnum.AGENT,
            agent_memory_stack: AgentMemoryStack = None):
        """Initialize the cognitive model."""
        self._agent_memory_stack = agent_memory_stack
        self._agent_role = agent_role

    def get_prompt_name(self, node_prefix: str) -> str:
        return f"{node_prefix}{self._agent_role.value}"

    def think(self, state, config, node_name: str, response_actions_to_flag_is_done: list = []) -> AgentNodeCognitiveResponse:
        """
        Generate thoughts based on the current state, configuration, and node name.

        Args:
            state: The current state of the agent.
            config: The configuration settings for the agent.
            node_name (str): The name of the current node.

        Returns:
            AgentNodeCognitiveResponse: The generated response.
        """
        return AgentNodeCognitiveResponse(action="none", message="")