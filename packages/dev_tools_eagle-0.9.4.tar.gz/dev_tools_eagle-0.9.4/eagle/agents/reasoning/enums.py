from enum import Enum

# Agent Roles ENUM
class AgentRoleEnum(str, Enum):
    AGENT = ""
    MODERATOR_REPORT = "_moderator_report"
    MODERATOR_RELAY = "_moderator_relay"