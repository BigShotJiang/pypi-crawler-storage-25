def _check_open(*args, **kwargs):
    """
    Blocks any attempt to open files for writing.
    Returns True if the operation should be blocked.
    """
    # Verifica se o modo foi passado como argumento posicional
    if len(args) > 1:
        mode = args[1]
    else:
        mode = kwargs.get('mode', 'r')
    # Se o modo contém qualquer letra de escrita, bloqueia
    if any(m in mode for m in ('w', 'a', 'x', '+')):
        if args[0] in ['/dev/null']:
            return False
        return True
    return False

def _check_os_environ_get(*args, **kwargs):
    ENV_VARS_ALLOWED = {'PLOTLY_DIR'}
    if args[0] in ENV_VARS_ALLOWED:
        return False
    return True