"""Agent for working with pandas objects."""

import warnings
from typing import Any, Dict, List, Literal, Optional, Sequence, Union, cast, cast

from langchain.agents import (
    AgentType,
    create_openai_tools_agent,
    create_react_agent,
    create_tool_calling_agent,
)
from langchain.agents.agent import (
    AgentExecutor,
    BaseMultiActionAgent,
    BaseSingleActionAgent,
    RunnableAgent,
    RunnableMultiActionAgent,
)
from langchain.agents.mrkl.prompt import FORMAT_INSTRUCTIONS
from langchain.agents.openai_functions_agent.base import (
    OpenAIFunctionsAgent,
    create_openai_functions_agent,
)
from langchain_core.callbacks import BaseCallbackManager
from langchain_core.language_models import BaseLanguageModel, LanguageModelLike
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.prompts import (
    BasePromptTemplate,
    ChatPromptTemplate,
    PromptTemplate,
)
from langchain_core.tools import BaseTool
from langchain_core.callbacks import BaseCallbackHandler
from eagle.utils.image_utils import object_to_image_url
from eagle.toolkits_adapters.langchain_experimental.tools.python.tool import SafePythonAstREPLTool
from eagle.toolkits_adapters.langchain_experimental.agents.agent_toolkits.objects_handling.prompts import (
   SUFFIX_WITH_MULTI_OBJ,
   SUFFIX_NO_OBJ,
   SUFFIX_WITH_OBJ,
   MULTI_OBJ_PREFIX,
   PREFIX,
   PREFIX_FUNCTIONS,
   FUNCTIONS_WITH_OBJ,
   MULTI_OBJ_PREFIX_FUNCTIONS,
   FUNCTIONS_WITH_MULTI_OBJ
)
import plotly.graph_objects as go
import pandas as pd
from PIL import Image


class VisualOutputException(Exception):
    """Exception raised when visual output is detected and dynamic multimodal is enabled."""
    def __init__(self, message, captured_objects):
        super().__init__(message)
        self.captured_objects = captured_objects


class DynamicMultimodalCallback(BaseCallbackHandler):
    """Callback to capture visual objects and interrupt execution if dynamic multimodal is enabled."""
    
    def __init__(self, dynamic_multimodal=False):
        self.dynamic_multimodal = dynamic_multimodal
        self.captured_objects = []
    
    def on_tool_end(self, output, **kwargs):
        if not isinstance(output, tuple):
            output = (output,)
        
        for item in output:
            if isinstance(item, go.Figure):
                image_url = object_to_image_url(item, format="JPEG")
                if image_url:
                    self.captured_objects.append({
                        "object_name": item.layout.title.text if item.layout.title and item.layout.title.text else None,
                        "description": f"Plotly Figure with {len(item.data)} traces",
                        "obj": item,
                        "image_url": image_url,
                        "object_type": type(item).__name__
                    })
            elif isinstance(item, Image.Image):
                image_url = object_to_image_url(item, format="JPEG")
                if image_url:
                    self.captured_objects.append({
                        "object_name": None,
                        "description": f"PIL Image with size {item.size}",
                        "obj": item,
                        "image_url": image_url,
                        "object_type": type(item).__name__
                    })
            # Capture other objects too
            elif isinstance(item, pd.DataFrame):
                self.captured_objects.append({
                    "object_name": None,
                    "description": f"DataFrame with {len(item)} rows",
                    "obj": item,
                    "object_type": type(item).__name__
                })
        
        # After processing all items, check if we have visual objects and should interrupt
        if self.dynamic_multimodal and any('image_url' in obj for obj in self.captured_objects):
            raise VisualOutputException("Visual output detected", self.captured_objects)


def _get_object_description(obj: Any, number_of_items: int = 5) -> Union[str, Dict[str, Any]]:
    """Generate a description of the object for context."""
    try:
        # Check for visual objects first
        image_url = object_to_image_url(obj)
        if image_url:
            # For visual objects, return dict with image_url and text description
            text_desc = f"Object of type {type(obj).__name__}"
            if hasattr(obj, 'data') and hasattr(obj, 'layout'):  # Plotly Figure
                text_desc += f" with {len(obj.data)} traces and layout properties."
            elif hasattr(obj, 'size'):  # PIL Image
                text_desc += f" with size {obj.size}."
            return {"image_url": image_url, "text_description": text_desc}
        
        # For DataFrames
        if hasattr(obj, 'head') and callable(getattr(obj, 'head')):
            total_rows = len(obj)
            head = obj.head(number_of_items).to_markdown()
            column_types = dict(obj.dtypes)
            description = f"DataFrame with {total_rows} rows."
            if total_rows > number_of_items:
                description += f" Showing head of {number_of_items} rows."
            description += f"\nColumn types:\n" + "\n".join(f"{k}: {v}" for k, v in column_types.items()) + "\n"
            try:
                stats = obj.describe(include='all').to_markdown()
                description += f"\nBasic statistics:\n{stats}\n"
            except:
                pass
            description += f"\nSample head:\n{head}"
            return description
        
        # Other objects
        elif isinstance(obj, list):
            return f"List with {len(obj)} items: {obj[:number_of_items]}"
        elif isinstance(obj, dict):
            return f"Dict with {len(obj)} keys: {list(obj.keys())[:number_of_items]}"
        elif isinstance(obj, set):
            return f"Set with {len(obj)} items: {list(obj)[:number_of_items]}"
        elif hasattr(obj, '__len__') and hasattr(obj, '__getitem__'):
            try:
                length = len(obj)
                items = [obj[i] for i in range(min(number_of_items, length))]
                return f"Sequence-like object with {length} items: {items}"
            except:
                pass
        return f"Object of type {type(obj).__name__}"
    except Exception as e:
        return f"Object of type {type(obj).__name__} (error getting description: {str(e)})"


def _get_multi_prompt(
    objs: List[Any],
    *,
    prefix: Optional[str] = None,
    suffix: Optional[str] = None,
    include_obj_in_prompt: Optional[bool] = True,
    number_of_items: int = 5,
) -> BasePromptTemplate:
    if suffix is not None:
        suffix_to_use = suffix
    elif include_obj_in_prompt:
        suffix_to_use = SUFFIX_WITH_MULTI_OBJ
    else:
        suffix_to_use = SUFFIX_NO_OBJ
    prefix = prefix if prefix is not None else MULTI_OBJ_PREFIX

    template = "\n\n".join([prefix, "{tools}", FORMAT_INSTRUCTIONS, suffix_to_use])
    prompt = PromptTemplate.from_template(template)
    partial_prompt = prompt.partial()
    if "objs_descriptions" in partial_prompt.input_variables:
        objs_descriptions = "\n\n".join([_get_object_description(obj, number_of_items) for obj in objs])
        partial_prompt = partial_prompt.partial(objs_descriptions=objs_descriptions)
    if "num_objs" in partial_prompt.input_variables:
        partial_prompt = partial_prompt.partial(num_objs=str(len(objs)))
    return partial_prompt


def _get_single_prompt(
    obj: Any,
    *,
    prefix: Optional[str] = None,
    suffix: Optional[str] = None,
    include_obj_in_prompt: Optional[bool] = True,
    number_of_items: int = 5,
) -> BasePromptTemplate:
    if suffix is not None:
        suffix_to_use = suffix
    elif include_obj_in_prompt:
        suffix_to_use = SUFFIX_WITH_OBJ
    else:
        suffix_to_use = SUFFIX_NO_OBJ
    prefix = prefix if prefix is not None else PREFIX

    template = "\n\n".join([prefix, "{tools}", FORMAT_INSTRUCTIONS, suffix_to_use])
    prompt = PromptTemplate.from_template(template)

    partial_prompt = prompt.partial()
    if "obj_description" in partial_prompt.input_variables:
        obj_description = _get_object_description(obj, number_of_items)
        partial_prompt = partial_prompt.partial(obj_description=obj_description)
    return partial_prompt


def _get_prompt(obj: Any, **kwargs: Any) -> BasePromptTemplate:
    return (
        _get_multi_prompt(obj, **kwargs)
        if isinstance(obj, list)
        else _get_single_prompt(obj, **kwargs)
    )


def _get_functions_single_prompt(
    obj: Any,
    *,
    prefix: Optional[str] = None,
    suffix: str = "",
    include_obj_in_prompt: Optional[bool] = True,
    number_of_items: int = 5,
    multimodal: bool = False,
) -> ChatPromptTemplate:
    obj_description = _get_object_description(obj, number_of_items) if include_obj_in_prompt else ""
    
    if multimodal and isinstance(obj_description, dict) and "image_url" in obj_description:
        # Multimodal: create messages with mixed content
        content = [
            {"type": "text", "text": f"{obj_description['text_description']}\nVeja a representação visual:"},
            {"type": "image_url", "image_url": obj_description["image_url"]},
            {"type": "text", "text": "{input}"}
        ]
        messages = [
            ("system", prefix or PREFIX_FUNCTIONS),
            ("human", content),
            ("assistant", "{agent_scratchpad}"),
        ]
        prompt = ChatPromptTemplate.from_messages(messages)
    else:
        # Textual
        if isinstance(obj_description, dict):
            obj_description = obj_description.get("text_description", str(obj_description))
        suffix = (suffix or FUNCTIONS_WITH_OBJ).format(obj_description=obj_description)
        prefix = prefix if prefix is not None else PREFIX_FUNCTIONS
        system_message = SystemMessage(content=prefix + suffix)
        prompt = OpenAIFunctionsAgent.create_prompt(system_message=system_message)
    
    return prompt


def _get_functions_multi_prompt(
    objs: Any,
    *,
    prefix: str = "",
    suffix: str = "",
    include_obj_in_prompt: Optional[bool] = True,
    number_of_items: int = 5,
    multimodal: bool = False,
) -> ChatPromptTemplate:
    if include_obj_in_prompt:
        objs_descriptions = []
        has_visual = False
        for obj in objs:
            desc = _get_object_description(obj, number_of_items)
            if isinstance(desc, dict) and "image_url" in desc:
                has_visual = True
                objs_descriptions.append(desc)
            else:
                objs_descriptions.append(desc)
        
        if multimodal and has_visual:
            # Multimodal: build mixed content
            content = []
            for desc in objs_descriptions:
                if isinstance(desc, dict):
                    content.append({"type": "text", "text": desc["text_description"]})
                    content.append({"type": "image_url", "image_url": desc["image_url"]})
                else:
                    content.append({"type": "text", "text": desc})
            content.append({"type": "text", "text": "{input}"})
            messages = [
                ("system", (prefix or MULTI_OBJ_PREFIX_FUNCTIONS).format(num_objs=str(len(objs)))),
                ("human", content),
                ("assistant", "{agent_scratchpad}"),
            ]
            prompt = ChatPromptTemplate.from_messages(messages)
        else:
            # Textual
            text_descriptions = []
            for desc in objs_descriptions:
                if isinstance(desc, dict):
                    text_descriptions.append(desc.get("text_description", str(desc)))
                else:
                    text_descriptions.append(desc)
            suffix = (suffix or FUNCTIONS_WITH_MULTI_OBJ).format(objs_descriptions="\n\n".join(text_descriptions))
            prefix = (prefix or MULTI_OBJ_PREFIX_FUNCTIONS).format(num_objs=str(len(objs)))
            system_message = SystemMessage(content=prefix + suffix)
            prompt = OpenAIFunctionsAgent.create_prompt(system_message=system_message)
    else:
        prefix = (prefix or MULTI_OBJ_PREFIX_FUNCTIONS).format(num_objs=str(len(objs)))
        system_message = SystemMessage(content=prefix + suffix)
        prompt = OpenAIFunctionsAgent.create_prompt(system_message=system_message)
    
    return prompt


def _get_functions_prompt(obj: Any, **kwargs: Any) -> ChatPromptTemplate:
    return (
        _get_functions_multi_prompt(obj, **kwargs)
        if isinstance(obj, list)
        else _get_functions_single_prompt(obj, **kwargs)
    )


class DynamicMultimodalAgentExecutor:
    """Wrapper for AgentExecutor that handles dynamic multimodal interruptions and restarts."""
    
    def __init__(self, agent_executor, original_objs, llm, agent_type, multimodal, dynamic_multimodal, agent_kwargs):
        self.agent_executor = agent_executor
        self.original_objs = original_objs
        self.llm = llm
        self.agent_type = agent_type
        self.multimodal = multimodal
        self.dynamic_multimodal = dynamic_multimodal
        self.agent_kwargs = agent_kwargs
    
    def invoke(self, input, config=None, **kwargs):
        if self.dynamic_multimodal:
            callback = DynamicMultimodalCallback(dynamic_multimodal=True)
            config = config or {}
            config["callbacks"] = [callback] + config.get("callbacks", [])
        try:
            return self.agent_executor.invoke(input, config, **kwargs)
        except VisualOutputException as e:
            # Update objects with captured ones
            new_objs = self.original_objs + [obj['obj'] for obj in e.captured_objects]
            # Recreate agent with updated objects
            new_agent = create_object_agent(
                llm=self.llm,
                obj=new_objs,
                agent_type=self.agent_type,
                multimodal=self.multimodal,
                dynamic_multimodal=self.dynamic_multimodal,
                **self.agent_kwargs
            )
            # Continue with updated agent
            return new_agent.invoke(input, config, **kwargs)
    
    # Delegate other methods to the internal agent_executor
    def __getattr__(self, name):
        return getattr(self.agent_executor, name)


def create_object_agent(
    llm: LanguageModelLike,
    obj: Any,
    agent_type: Union[
        AgentType, Literal["openai-tools", "tool-calling"]
    ] = AgentType.ZERO_SHOT_REACT_DESCRIPTION,
    callback_manager: Optional[BaseCallbackManager] = None,
    prefix: Optional[str] = None,
    suffix: Optional[str] = None,
    input_variables: Optional[List[str]] = None,
    verbose: bool = False,
    return_intermediate_steps: bool = False,
    max_iterations: Optional[int] = 15,
    max_execution_time: Optional[float] = None,
    early_stopping_method: str = "force",
    agent_executor_kwargs: Optional[Dict[str, Any]] = None,
    include_obj_in_prompt: Optional[bool] = True,
    number_of_items: int = 5,
    extra_tools: Sequence[BaseTool] = (),
    multimodal: bool = False,
    dynamic_multimodal: bool = False,
    allow_dangerous_code: bool = False,
    **kwargs: Any,
) -> Union[AgentExecutor, DynamicMultimodalAgentExecutor]:
    """Construct an object agent from an LLM and Python object(s).

    Security Notice:
        This agent relies on access to a python repl tool which can execute
        arbitrary code. This can be dangerous and requires a specially sandboxed
        environment to be safely used. Failure to run this code in a properly
        sandboxed environment can lead to arbitrary code execution vulnerabilities,
        which can lead to data breaches, data loss, or other security incidents.

        Do not use this code with untrusted inputs, with elevated permissions,
        or without consulting your security team about proper sandboxing!

        You must opt-in to use this functionality by setting allow_dangerous_code=True.

    Args:
        llm: Language model to use for the agent. If agent_type is "tool-calling" then
            llm is expected to support tool calling.
        obj: Python object or list of Python objects.
        agent_type: One of "tool-calling", "openai-tools", "openai-functions", or
            "zero-shot-react-description". Defaults to "zero-shot-react-description".
            "tool-calling" is recommended over the legacy "openai-tools" and
            "openai-functions" types.
        callback_manager: DEPRECATED. Pass "callbacks" key into 'agent_executor_kwargs'
            instead to pass constructor callbacks to AgentExecutor.
        prefix: Prompt prefix string.
        suffix: Prompt suffix string.
        input_variables: DEPRECATED. Input variables automatically inferred from
            constructed prompt.
        verbose: AgentExecutor verbosity.
        return_intermediate_steps: Passed to AgentExecutor init.
        max_iterations: Passed to AgentExecutor init.
        max_execution_time: Passed to AgentExecutor init.
        early_stopping_method: Passed to AgentExecutor init.
        agent_executor_kwargs: Arbitrary additional AgentExecutor args.
        include_obj_in_prompt: Whether to include object descriptions in the
            prompt. Must be None if suffix is not None.
        number_of_items: Number of initial items to include in description if
            include_obj_in_prompt is True.
        extra_tools: Additional tools to give to agent on top of a PythonAstREPLTool.
        multimodal: Whether to include visual representations (images) for visual objects
            like PIL Images or Plotly Figures. Requires a multimodal LLM. Defaults to False.
        dynamic_multimodal: Whether to enable dynamic multimodal interpretation. If True,
            execution pauses when visual objects are generated, allowing reinjection of images
            into the context. Requires multimodal=True. Defaults to False.
        allow_dangerous_code: bool, default False
            This agent relies on access to a python repl tool which can execute
            arbitrary code. This can be dangerous and requires a specially sandboxed
            environment to be safely used.
            Failure to properly sandbox this class can lead to arbitrary code execution
            vulnerabilities, which can lead to data breaches, data loss, or
            other security incidents.
            You must opt in to use this functionality by setting
            allow_dangerous_code=True.

        **kwargs: DEPRECATED. Not used, kept for backwards compatibility.

    Returns:
        An AgentExecutor with the specified agent_type agent and access to
        a PythonAstREPLTool with the object(s) and any user-provided extra_tools.

    Example:
        .. code-block:: python

            from langchain_openai import ChatOpenAI
            from langchain_experimental.agents import create_object_agent
            import pandas as pd

            df = pd.read_csv("titanic.csv")
            llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)
            agent_executor = create_object_agent(
                llm,
                df,
                agent_type="tool-calling",
                multimodal=True,  # Enable for visual objects
                verbose=True
            )

    """
    if not allow_dangerous_code:
        raise ValueError(
            "This agent relies on access to a python repl tool which can execute "
            "arbitrary code. This can be dangerous and requires a specially sandboxed "
            "environment to be safely used. Please read the security notice in the "
            "doc-string of this function. You must opt-in to use this functionality "
            "by setting allow_dangerous_code=True."
            "For general security guidelines, please see: "
            "https://python.langchain.com/docs/security/"
        )

    if input_variables:
        kwargs = kwargs or {}
        kwargs["input_variables"] = input_variables
    if kwargs:
        warnings.warn(
            f"Received additional kwargs {kwargs} which are no longer supported."
        )

    obj_locals = {}
    if isinstance(obj, list):
        for i, object_item in enumerate(obj):
            obj_locals[f"obj{i + 1}"] = object_item
    else:
        obj_locals["obj"] = obj
    tools = [SafePythonAstREPLTool(locals=obj_locals)] + list(extra_tools)

    if agent_type == AgentType.ZERO_SHOT_REACT_DESCRIPTION:
        if include_obj_in_prompt is not None and suffix is not None:
            raise ValueError(
                "If suffix is specified, include_obj_in_prompt should not be."
            )
        prompt = _get_prompt(
            obj,
            prefix=prefix,
            suffix=suffix,
            include_obj_in_prompt=include_obj_in_prompt,
            number_of_items=number_of_items,
        )
        agent: Union[BaseSingleActionAgent, BaseMultiActionAgent] = RunnableAgent(
            runnable=create_react_agent(llm, tools, prompt),  # type: ignore
            input_keys_arg=["input"],
            return_keys_arg=["output"],
        )
    elif agent_type in (AgentType.OPENAI_FUNCTIONS, "openai-tools", "tool-calling"):
        prompt = _get_functions_prompt(
            obj,
            prefix=prefix,
            suffix=suffix,
            include_obj_in_prompt=include_obj_in_prompt,
            number_of_items=number_of_items,
            multimodal=multimodal,
        )
        if agent_type == AgentType.OPENAI_FUNCTIONS:
            runnable = create_openai_functions_agent(
                cast(BaseLanguageModel, llm), tools, prompt
            )
            agent = RunnableAgent(
                runnable=runnable,
                input_keys_arg=["input"],
                return_keys_arg=["output"],
            )
        else:
            if agent_type == "openai-tools":
                runnable = create_openai_tools_agent(
                    cast(BaseLanguageModel, llm), tools, prompt
                )
            else:
                runnable = create_tool_calling_agent(
                    cast(BaseLanguageModel, llm), tools, prompt
                )
            agent = RunnableMultiActionAgent(
                runnable=runnable,
                input_keys_arg=["input"],
                return_keys_arg=["output"],
            )
    else:
        raise ValueError(
            f"Agent type {agent_type} not supported at the moment. Must be one of "
            "'tool-calling', 'openai-tools', 'openai-functions', or "
            "'zero-shot-react-description'."
        )
    
    # Add dynamic multimodal callback if enabled
    callbacks = list(agent_executor_kwargs.get("callbacks", [])) if agent_executor_kwargs else []
    # Note: DynamicMultimodalCallback is now handled per-invoke in DynamicMultimodalAgentExecutor
    
    agent_executor_kwargs = agent_executor_kwargs or {}
    agent_executor_kwargs["callbacks"] = callbacks
    
    if dynamic_multimodal:
        agent_executor = AgentExecutor(
            agent=agent,
            tools=tools,
            callback_manager=callback_manager,
            verbose=verbose,
            return_intermediate_steps=return_intermediate_steps,
            max_iterations=max_iterations,
            max_execution_time=max_execution_time,
            early_stopping_method=early_stopping_method,
            **agent_executor_kwargs,
        )
        return DynamicMultimodalAgentExecutor(
            agent_executor=agent_executor,
            original_objs=obj if isinstance(obj, list) else [obj],
            llm=llm,
            agent_type=agent_type,
            multimodal=multimodal,
            dynamic_multimodal=dynamic_multimodal,
            agent_kwargs={
                'callback_manager': callback_manager,
                'prefix': prefix,
                'suffix': suffix,
                'input_variables': input_variables,
                'return_intermediate_steps': return_intermediate_steps,
                'max_iterations': max_iterations,
                'max_execution_time': max_execution_time,
                'early_stopping_method': early_stopping_method,
                'agent_executor_kwargs': agent_executor_kwargs,
                'include_obj_in_prompt': include_obj_in_prompt,
                'number_of_items': number_of_items,
                'extra_tools': extra_tools,
                'allow_dangerous_code': allow_dangerous_code,
            }
        )
    else:
        return AgentExecutor(
            agent=agent,
            tools=tools,
            callback_manager=callback_manager,
            verbose=verbose,
            return_intermediate_steps=return_intermediate_steps,
            max_iterations=max_iterations,
            max_execution_time=max_execution_time,
            early_stopping_method=early_stopping_method,
            **agent_executor_kwargs,
        )
