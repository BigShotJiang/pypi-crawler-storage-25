# flake8: noqa

PREFIX = """
You are working with Python objects in memory. The name of the object is `obj`.
You should use the tools below to answer the question posed of you:"""

MULTI_OBJ_PREFIX = """
You are working with {num_objs} Python objects in memory named obj1, obj2, etc. You 
should use the tools below to answer the question posed of you:"""

SUFFIX_NO_OBJ = """
Begin!
Question: {input}
{agent_scratchpad}"""

SUFFIX_WITH_OBJ = """
This is the description of the object:
{obj_description}

Begin!
Question: {input}
{agent_scratchpad}"""

SUFFIX_WITH_MULTI_OBJ = """
This is the description of each object:
{objs_descriptions}

Begin!
Question: {input}
{agent_scratchpad}"""

PREFIX_FUNCTIONS = """
You are working with a Python object in memory. The name of the object is `obj`."""

MULTI_OBJ_PREFIX_FUNCTIONS = """
You are working with {num_objs} Python objects in memory named obj1, obj2, etc."""

FUNCTIONS_WITH_OBJ = """
This is the description of the object:
{obj_description}"""

FUNCTIONS_WITH_MULTI_OBJ = """
This is the description of each object:
{objs_descriptions}"""
