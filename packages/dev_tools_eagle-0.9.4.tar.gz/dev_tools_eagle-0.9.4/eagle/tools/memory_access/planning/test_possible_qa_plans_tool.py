import pytest
import hashlib
from eagle.tools.memory_access.planning.possible_qa_plans import PossiblePlansQATool, PlansQASourcesByTitleTool
from time import sleep
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


@pytest.fixture(scope="function")
def qa_memory_with_data(possible_qa_memory):
    """
    Fixture que popula a memória QA com um plans_set_id exclusivo para os testes e limpa ao final.
    """
    plans_set_id = "test-tool-qa-plans-set"
    plans = [
        {
            "plan": "Paris is the capital of France.",
            "question": "What is the capital of France?",
            "short_description": "Capital cities knowledge",
            "source": "GeographyBook",
            "title": "France Capital"
        },
        {
            "plan": "The Amazon is the largest rainforest.",
            "question": "What is the largest rainforest?",
            "short_description": "Rainforest knowledge",
            "source": "BiologyBook",
            "title": "Amazon Rainforest"
        },
        {
            "plan": "Water boils at 100°C.",
            "question": "At what temperature does water boil?",
            "short_description": "Boiling point knowledge",
            "source": "ChemistryBook",
            "title": "Water Boiling"
        },
        {
            "plan": "The rains are good for nature.",
            "question": "Are rains something good?",
            "short_description": "Rains knowledge",
            "source": "WheaterBook",
            "title": "Rains are good."
        }
    ]
    # Limpa antes
    for plan in plans:
        plan_id = hashlib.sha256(plan["question"].encode("utf-8")).hexdigest()
        possible_qa_memory.delete_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    # Popula
    for plan in plans:
        plan_id = hashlib.sha256(plan["question"].encode("utf-8")).hexdigest()
        possible_qa_memory.put_memory(
            plans_set_id=plans_set_id,
            plan_id=plan_id,
            question=plan["question"],
            plan=plan["plan"],
            short_description=plan["short_description"],
            source=plan["source"],
            title=plan["title"]
        )
    sleep(3)
    yield possible_qa_memory, plans_set_id, plans
    # Limpa depois
    possible_qa_memory.delete_memories_by_namespace(plans_set_id)

def test_possible_plans_qa_tool_basic(qa_memory_with_data):
    memory, plans_set_id, plans = qa_memory_with_data
    tool = PossiblePlansQATool(
        memory=memory,
        prompt_language="en",
        limit=2,
        plans_set_id=plans_set_id,
        filter_sources=None
    )
    # Busca por "rainforest"
    result = tool._run(question="rainforest")
    assert "Amazon" in result
    assert "Rainforest knowledge" in result
    assert "What is the capital of France?" not in result  # sanity check

def test_possible_plans_qa_tool_no_results(qa_memory_with_data):
    memory, plans_set_id, _ = qa_memory_with_data
    tool = PossiblePlansQATool(
        memory=memory,
        prompt_language="en",
        limit=3,
        plans_set_id=plans_set_id,
        filter_sources=None
    )
    result = tool._run(question="xyznotfound")
    assert all(x in result for x in ["Result 1", "Result 2", "Result 3"])

def test_plans_qa_sources_by_title_tool_basic(qa_memory_with_data):
    memory, plans_set_id, plans = qa_memory_with_data
    tool = PlansQASourcesByTitleTool(
        memory=memory,
        plans_set_id=plans_set_id,
        prompt_language="en"
    )
    # Busca por um título existente
    result = tool._run(titles=["Amazon Rainforest"])
    assert "Amazon Rainforest" in result
    assert "The Amazon is the largest rainforest." in result
    assert "Rainforest knowledge" in result
    # Busca múltipla
    result = tool._run(titles=["France Capital", "Water Boiling"])
    assert "Paris is the capital of France." in result
    assert "Water boils at 100°C." in result
    assert "France Capital" in result and "Water Boiling" in result

def test_plans_qa_sources_by_title_tool_no_results(qa_memory_with_data):
    memory, plans_set_id, _ = qa_memory_with_data
    tool = PlansQASourcesByTitleTool(
        memory=memory,
        plans_set_id=plans_set_id,
        prompt_language="en"
    )
    result = tool._run(titles=["NotARealTitle"])
    assert "No source found." in result
