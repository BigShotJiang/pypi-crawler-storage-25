import pytest
from pydantic import ValidationError

from eagle.tools.memory_access.planning.possible_plans import PossiblePlansToolInput


# -----------------------------
# PossiblePlansToolInput Tests
# -----------------------------


@pytest.mark.parametrize(
    "question",
    [
        pytest.param(
            "How can I learn Python effectively?",
            id="happy-how-can-i-learn-python",
        ),
        pytest.param(
            "What is the best way to prepare for a data science interview?",
            id="happy-best-way-data-science-interview",
        ),
        pytest.param(
            "How to organize my daily work tasks efficiently?",
            id="happy-how-to-organize-daily-tasks",
        ),
    ],
)
def test_possible_plans_tool_input_happy_paths(question):

    # Act
    model = PossiblePlansToolInput(question=question)

    # Assert
    assert model.question == question


# -----------------------------
# Edge case tests
# -----------------------------


@pytest.mark.parametrize(
    "question",
    [
        pytest.param(
            "",
            id="edge-empty-question-allowed",
        ),
        pytest.param(
            " " * 10,
            id="edge-whitespace-only-question",
        ),
        pytest.param(
            "a",
            id="edge-single-character-question",
        ),
        pytest.param(
            "How to do something very complex?" * 50,
            id="edge-very-long-question",
        ),
    ],
)
def test_possible_plans_tool_input_edge_cases(question):

    # Act
    model = PossiblePlansToolInput(question=question)

    # Assert
    assert model.question == question


# -----------------------------
# Error case tests
# -----------------------------


@pytest.mark.parametrize(
    "input_value, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "error-missing-question-field",
            id="error-missing-question-field",
        ),
        pytest.param(
            {"question": None},
            "Input should be a valid string",
            "error-question-none",
            id="error-question-none",
        ),
        pytest.param(
            {"question": 123},
            "Input should be a valid string",
            "error-question-not-a-string",
            id="error-question-not-a-string",
        ),
    ],
)
def test_possible_plans_tool_input_error_cases(input_value, expected_error_fragment, case_id):

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        PossiblePlansToolInput(**input_value)

    # Assert
    errors_text = str(exc_info.value)
    assert expected_error_fragment in errors_text
