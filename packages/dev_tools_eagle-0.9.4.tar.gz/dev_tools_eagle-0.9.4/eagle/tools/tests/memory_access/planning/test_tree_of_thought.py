import sys
import types
import inspect
import textwrap
from typing import Any, Dict, List

import pytest
from pydantic import ValidationError

# ------------------------------------------------------------------------------
# Import-time shims to avoid BaseTool / args_schema issues
# ------------------------------------------------------------------------------


# Arrange
base_tool_module_name = "langchain_core.tools"

# Create a stub module if necessary
if base_tool_module_name not in sys.modules:
    stub_mod = types.ModuleType(base_tool_module_name)
    sys.modules[base_tool_module_name] = stub_mod
else:
    stub_mod = sys.modules[base_tool_module_name]


class BaseToolStub:
    """Minimal BaseTool stub to avoid pydantic field conflicts during import."""
    def __init__(self, *args, **kwargs):
        # store kwargs so they are accessible if needed
        for k, v in kwargs.items():
            setattr(self, k, v)


# Inject stub BaseTool into the module
setattr(stub_mod, "BaseTool", BaseToolStub)

from eagle.tools.memory_access.planning.tree_of_thought import (
    TreeOfThoughtTool,
    TreeOfThoughtToolInput,
)

# -----------------------------
# TreeOfThoughtToolInput tests
# -----------------------------
@pytest.mark.parametrize(
    "question",
    [
        pytest.param(
            "How can I design a study plan for learning Python?",
            id="happy-python-study-plan",
        ),
        pytest.param(
            "What is the best way to organize my tasks for a large project?",
            id="happy-organize-tasks-large-project",
        ),
        pytest.param(
            "How to prepare for a data science interview in two months?",
            id="happy-data-science-interview-plan",
        ),
    ],
)
def test_tree_of_thought_tool_input_happy_paths(question):

    # Act
    model = TreeOfThoughtToolInput(question=question)

    # Assert
    assert model.question == question


# -----------------------------
# Edge case tests
# -----------------------------


@pytest.mark.parametrize(
    "question",
    [
        pytest.param(
            "",
            id="edge-empty-question-allowed",
        ),
        pytest.param(
            " " * 8,
            id="edge-whitespace-only-question",
        ),
        pytest.param(
            "?",
            id="edge-single-character-question",
        ),
        pytest.param(
            "How to do something extremely complex and long-winded?" * 50,
            id="edge-very-long-question",
        ),
    ],
)
def test_tree_of_thought_tool_input_edge_cases(question):

    # Act
    model = TreeOfThoughtToolInput(question=question)

    # Assert
    assert model.question == question


# -----------------------------
# Error case tests
# -----------------------------


@pytest.mark.parametrize(
    "input_value, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "error-missing-question-field",
            id="error-missing-question-field",
        ),
        pytest.param(
            {"question": None},
            "Input should be a valid string",
            "error-question-none",
            id="error-question-none",
        ),
        pytest.param(
            {"question": 42},
            "Input should be a valid string",
            "error-question-not-a-string",
            id="error-question-not-a-string",
        ),
    ],
)
def test_tree_of_thought_tool_input_error_cases(input_value, expected_error_fragment, case_id):

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        TreeOfThoughtToolInput(**input_value)

    # Assert
    errors_text = str(exc_info.value)
    assert expected_error_fragment in errors_text

# -----------------------------
# TreeOfThoughtTool tests
# -----------------------------
# ------------------------------------------------------------------------------
# Simple QA chain stub
# ------------------------------------------------------------------------------


class DummyQAResult:
    def __init__(self, response: str, sources: List[str] | None = None):
        self.response = response
        self.sources = sources or []


class DummyQAChain:
    def __init__(self, response: str):
        self.response = response
        self.calls: List[Dict[str, Any]] = []

    def invoke(self, inputs: Dict[str, Any]) -> DummyQAResult:
        self.calls.append(inputs)
        return DummyQAResult(self.response)


# ------------------------------------------------------------------------------
# Helper fixture: build tool with patched QA chain creator
# ------------------------------------------------------------------------------


@pytest.fixture
def patched_tool(monkeypatch):
    # Arrange
    def make_tool_with_qa_response(response_text: str):
        chain = DummyQAChain(response_text)

        def fake_create_qa_chain(prompt_language, llm):
            return chain

        monkeypatch.setattr(
            "eagle.tools.memory_access.planning.tree_of_thought.create_qa_chain",
            fake_create_qa_chain,
        )
        tool = TreeOfThoughtTool(
            memory=None,
            prompt_language="en",
            chain_llm=None,
            limit=5,
            plans_set_id="set",
            filter_sources=None,
        )
        return tool, chain

    return make_tool_with_qa_response


# ------------------------------------------------------------------------------
# TreeOfThoughtToolInput tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "question",
    [
        pytest.param(
            "How can I design a study plan for learning Python?",
            id="input-happy-python-study-plan",
        ),
        pytest.param(
            "What is the best way to organize my tasks for a large project?",
            id="input-happy-organize-tasks-project",
        ),
        pytest.param(
            "How to prepare for a data science interview in two months?",
            id="input-happy-data-science-plan",
        ),
    ],
)
def test_tree_of_thought_tool_input_happy_paths(question):

    # Act
    model = TreeOfThoughtToolInput(question=question)

    # Assert
    assert model.question == question


@pytest.mark.parametrize(
    "question",
    [
        pytest.param("", id="input-edge-empty-question-allowed"),
        pytest.param(" " * 4, id="input-edge-whitespace-only-question"),
        pytest.param("?", id="input-edge-single-character-question"),
        pytest.param(
            "How to do something extremely complex and long-winded?" * 50,
            id="input-edge-very-long-question",
        ),
    ],
)
def test_tree_of_thought_tool_input_edge_cases(question):

    # Act
    model = TreeOfThoughtToolInput(question=question)

    # Assert
    assert model.question == question


@pytest.mark.parametrize(
    "input_value, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "input-error-missing-question",
            id="input-error-missing-question",
        ),
        pytest.param(
            {"question": None},
            "Input should be a valid string",
            "input-error-question-none",
            id="input-error-question-none",
        ),
        pytest.param(
            {"question": 42},
            "Input should be a valid string",
            "input-error-question-not-string",
            id="input-error-question-not-string",
        ),
    ],
)
def test_tree_of_thought_tool_input_error_cases(
    input_value, expected_error_fragment, case_id
):

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        TreeOfThoughtToolInput(**input_value)

    # Assert
    assert expected_error_fragment in str(exc_info.value)


# ------------------------------------------------------------------------------
# extract_code_ToT tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "text, expected_codes, test_id",
    [
        pytest.param(
            "[Code 1]: print('hello')\n[Code 2]: x = 1 + 2",
            ["print('hello')", "x = 1 + 2"],
            "extract-codes-tot-two-blocks",
            id="extract-codes-tot-two-blocks",
        ),
        pytest.param(
            "Some text\n```python\nx = 1 + 2\n```\nMore text\n```print('hi')```",
            ["x = 1 + 2", "print('hi')"],
            "extract-codes-markdown",
            id="extract-codes-markdown",
        ),
        pytest.param(
            "No code here at all.",
            [],
            "extract-codes-no-code",
            id="extract-codes-no-code",
        ),
    ],
)
def test_tree_of_thought_extract_code_tot(text, expected_codes, test_id, patched_tool):

    # Arrange
    tool, _ = patched_tool(response_text="")

    # Act
    codes = tool.extract_code_ToT(text)

    # Assert
    assert codes == expected_codes


# ------------------------------------------------------------------------------
# build_prompt tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "user_message",
    [
        pytest.param("Write a function to sum a list.", id="build-prompt-basic"),
        pytest.param("Explain how to sort a list.", id="build-prompt-sort"),
    ],
)
def test_tree_of_thought_build_prompt(user_message, patched_tool):

    # Arrange
    tool, _ = patched_tool(response_text="")

    # Act
    prompt = tool.build_prompt(user_message)

    # Assert
    assert isinstance(prompt, list)
    assert len(prompt) == 2
    roles = [r for r, _ in prompt]
    assert roles == ["system", "human"]
    assert user_message in prompt[1][1]


# ------------------------------------------------------------------------------
# preprocess_code tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "raw_code, expected_snippets, not_expected_snippets, test_id",
    [
        pytest.param(
            textwrap.dedent(
                """
                ```python
                import sympy as sp
                def foo(x):
                    print("debug")
                    return x + 1

                # Example:
                foo(1)
                ```
                """
            ),
            ["def foo(x):", "return x + 1"],
            ["import sympy", "print("],
            "preprocess-removes-sympy-print-example",
            id="preprocess-removes-sympy-print-example",
        ),
        pytest.param(
            "   'def bar(text):\\n    return text.upper()'   ",
            ["def bar(text):", "return text.upper()"],
            [],
            "preprocess-stripped-quotes",
            id="preprocess-stripped-quotes",
        ),
    ],
)
def test_tree_of_thought_preprocess_code(
    raw_code, expected_snippets, not_expected_snippets, test_id, patched_tool
):

    # Arrange
    tool, _ = patched_tool(response_text="")

    # Act
    cleaned = tool.preprocess_code(raw_code)

    # Assert
    for snippet in expected_snippets:
        assert snippet in cleaned
    for snippet in not_expected_snippets:
        assert snippet not in cleaned


# ------------------------------------------------------------------------------
# get_code_score tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "code, expected_score, test_id",
    [
        pytest.param(
            textwrap.dedent(
                """
                def add_numbers(a, b):
                    return a + b
                """
            ),
            1,
            "code-score-simple-function",
            id="code-score-simple-function",
        ),
        pytest.param(
            textwrap.dedent(
                """
                def will_fail():
                    raise RuntimeError("fail")
                """
            ),
            0,
            "code-score-function-raises",
            id="code-score-function-raises",
        ),
        pytest.param(
            "print('no functions here')",
            0,
            "code-score-no-functions",
            id="code-score-no-functions",
        ),
        pytest.param(
            "def bad_syntax(:\n    pass",
            0,
            "code-score-bad-syntax",
            id="code-score-bad-syntax",
        ),
    ],
)
def test_tree_of_thought_get_code_score(code, expected_score, test_id, patched_tool):

    # Arrange
    tool, _ = patched_tool(response_text="")

    # Act
    score = tool.get_code_score(code)

    # Assert
    assert score == expected_score


# ------------------------------------------------------------------------------
# Helper for state
# ------------------------------------------------------------------------------


def make_initial_state(input_text: str) -> Dict[str, Any]:
    return {
        "input": input_text,
        "solutions_tree": {},
        "solutions": {},
        "evaluations": [],
        "new_solutions": [],
        "seeds": [],
        "solutions_to_evaluate": [],
        "round": 0,
        "best_solution": "",
    }


# ------------------------------------------------------------------------------
# generate_initial_solutions tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "qa_response_text, expected_codes_count, test_id",
    [
        pytest.param(
            "[Code 1]: def f():\n    return 1\n[Code 2]: def g():\n    return 2\n",
            2,
            "generate-initial-two-solutions",
            id="generate-initial-two-solutions",
        ),
        pytest.param(
            "No code here",
            0,
            "generate-initial-no-code",
            id="generate-initial-no-code",
        ),
    ],
)
def test_tree_of_thought_generate_initial_solutions(
    qa_response_text, expected_codes_count, test_id, patched_tool
):

    # Arrange
    tool, chain = patched_tool(response_text=qa_response_text)
    state = make_initial_state("How to do X?")

    # Act
    result = tool.generate_initial_solutions(state)

    # Assert
    assert "solutions" in result
    assert "solutions_tree" in result
    assert "new_solutions" in result

    solutions = result["solutions"]
    new_solutions = result["new_solutions"]
    assert len(solutions) == expected_codes_count
    assert len(new_solutions) == expected_codes_count
    if expected_codes_count > 0:
        assert "root" in result["solutions_tree"]
        assert len(result["solutions_tree"]["root"]) == expected_codes_count

    assert len(chain.calls) == 1
    call_input = chain.calls[0]
    assert "question" in call_input and "plans" in call_input


# ------------------------------------------------------------------------------
# update_tree tests
# ------------------------------------------------------------------------------


def test_tree_of_thought_update_tree_basic(patched_tool):

    # Arrange
    tool, _ = patched_tool(response_text="")
    state = make_initial_state("input")
    parent_id = "parent"
    state["solutions"] = {parent_id: {"id": parent_id, "code": "def f(): pass", "score": 2}}
    state["solutions_tree"] = {"root": [parent_id]}
    state["new_solutions"] = [
        {"id": "child1", "code": "def c1(): pass", "parent_id": parent_id},
        {"id": "child2", "code": "def c2(): pass", "parent_id": parent_id},
    ]

    # Act
    updated = tool.update_tree(state)

    # Assert
    solutions_tree = updated["solutions_tree"]
    solutions = updated["solutions"]
    assert parent_id in solutions_tree
    assert set(solutions_tree[parent_id]) == {"child1", "child2"}
    assert solutions["child1"]["score"] == 2
    assert solutions["child2"]["score"] == 2
    assert "child1" in solutions_tree and solutions_tree["child1"] == []
    assert "child2" in solutions_tree and solutions_tree["child2"] == []


# ------------------------------------------------------------------------------
# select_seeds tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "solutions, evaluations, expected_seeds, test_id",
    [
        pytest.param(
            {"s1": {"id": "s1", "score": 0}, "s2": {"id": "s2", "score": 0}},
            [{"id": "s1", "score": 1}],
            ["s1"],
            "select-seeds-single-positive",
            id="select-seeds-single-positive",
        ),
        pytest.param(
            {"s1": {"id": "s1", "score": 0}},
            [{"id": "s1", "score": 0}],
            ["s1"],
            "select-seeds-no-positive-uses-first-eval",
            id="select-seeds-no-positive-uses-first-eval",
        ),
        pytest.param(
            {"s1": {"id": "s1", "score": 0}},
            [],
            ["s1"],
            "select-seeds-no-evals-uses-first-solution",
            id="select-seeds-no-evals-uses-first-solution",
        ),
        pytest.param(
            {},
            [],
            [],
            "select-seeds-no-solutions",
            id="select-seeds-no-solutions",
        ),
    ],
)
def test_tree_of_thought_select_seeds(
    solutions, evaluations, expected_seeds, test_id, patched_tool
):

    # Arrange
    tool, _ = patched_tool(response_text="")
    state = make_initial_state("input")
    state["solutions"] = solutions
    state["evaluations"] = evaluations

    # Act
    result = tool.select_seeds(state)

    # Assert
    assert result["seeds"] == expected_seeds
    assert state["evaluations"] == []
    assert state["new_solutions"] == []


# ------------------------------------------------------------------------------
# increment_round tests
# ------------------------------------------------------------------------------


def test_tree_of_thought_increment_round(patched_tool):

    # Arrange
    tool, _ = patched_tool(response_text="")
    state = make_initial_state("x")
    state["round"] = 2

    # Act
    new_state = tool.increment_round(state)

    # Assert
    assert new_state["round"] == 3


# ------------------------------------------------------------------------------
# generate_solutions_by_seed tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "qa_response_text, expected_count, test_id",
    [
        pytest.param(
            "[Code 1]: def f_seed():\n    return 1\n[Code 2]: def g_seed():\n    return 2\n",
            2,
            "generate-by-seed-two",
            id="generate-by-seed-two",
        ),
        pytest.param(
            "No code here",
            0,
            "generate-by-seed-none",
            id="generate-by-seed-none",
        ),
    ],
)
def test_tree_of_thought_generate_solutions_by_seed(
    qa_response_text, expected_count, test_id, patched_tool
):

    # Arrange
    tool, chain = patched_tool(response_text=qa_response_text)
    seed_state = {"input": "Q", "solution": "def base(): pass", "solution_id": "base-id"}

    # Act
    result = tool.generate_solutions_by_seed(seed_state)

    # Assert
    new_solutions = result["new_solutions"]
    assert len(new_solutions) == expected_count
    for ns in new_solutions:
        assert ns["parent_id"] == "base-id"

    assert len(chain.calls) == 1
    assert "question" in chain.calls[0] and "plans" in chain.calls[0]


# ------------------------------------------------------------------------------
# should_continue tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "round_value, expected_next, test_id",
    [
        pytest.param(0, "increment_round", "continue-round-0", id="continue-round-0"),
        pytest.param(1, "increment_round", "continue-round-1", id="continue-round-1"),
        pytest.param(2, "select_best_solution", "continue-round-2", id="continue-round-2"),
        pytest.param(3, "select_best_solution", "continue-round-3", id="continue-round-3"),
    ],
)
def test_tree_of_thought_should_continue(round_value, expected_next, test_id, patched_tool):

    # Arrange
    tool, _ = patched_tool(response_text="")
    state = make_initial_state("x")
    state["round"] = round_value

    # Act
    nxt = tool.should_continue(state)

    # Assert
    assert nxt == expected_next


# ------------------------------------------------------------------------------
# select_best_solution tests
# ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    "solutions, expected_response_prefix, expected_sources_len, test_id",
    [
        pytest.param(
            {
                "s1": {"id": "s1", "code": "code1", "score": 1},
                "s2": {"id": "s2", "code": "code2", "score": 3},
                "s3": {"id": "s3", "code": "code3", "score": 2},
            },
            "code2",
            3,
            "best-solution-s2",
            id="best-solution-s2",
        ),
        pytest.param(
            {},
            "",
            0,
            "best-solution-empty",
            id="best-solution-empty",
        ),
    ],
)
def test_tree_of_thought_select_best_solution(
    solutions, expected_response_prefix, expected_sources_len, test_id, patched_tool
):

    # Arrange
    tool, _ = patched_tool(response_text="")
    state = make_initial_state("Q")
    state["solutions"] = solutions

    # Act
    result = tool.select_best_solution(state)

    # Assert
    assert result["response"].startswith(expected_response_prefix)
    assert len(result["sources"]) == expected_sources_len


# ------------------------------------------------------------------------------
# print_solutions_tree smoke test
# ------------------------------------------------------------------------------


def test_tree_of_thought_print_solutions_tree_smoke(patched_tool, capsys):

    # Arrange
    tool, _ = patched_tool(response_text="")
    state = make_initial_state("Q")
    state["solutions_tree"] = {"root": ["s1"], "s1": ["s2"], "s2": []}
    state["solutions"] = {
        "s1": {"id": "s1", "code": "def f1(): pass", "score": 1},
        "s2": {"id": "s2", "code": "def f2(): pass", "score": 2},
    }
    state["round"] = 1

    # Act
    tool.print_solutions_tree(state)
    captured = capsys.readouterr()

    # Assert
    assert "Tree of Thought — Round 1" in captured.out
    assert "s1"[:8] in captured.out
    assert "s2"[:8] in captured.out


# ------------------------------------------------------------------------------
# _run and _arun orchestration smoke tests
# ------------------------------------------------------------------------------


def test_tree_of_thought_run_smoke(monkeypatch, patched_tool):
    # Arrange
    tool, chain = patched_tool(
        response_text="[Code 1]: def f(text):\n    return text.upper()\n"
    )

    monkeypatch.setattr(
        tool,
        "select_best_solution",
        lambda state: {"response": "final-code", "sources": ["s1", "s2"]},
    )
    monkeypatch.setattr(tool, "print_solutions_tree", lambda state: None)

    # Act
    result = tool._run(question="Some question")

    # Assert
    assert result["response"] == "final-code"
    assert result["sources"] == ["s1", "s2"]


@pytest.mark.asyncio
async def test_tree_of_thought_arun_smoke(monkeypatch, patched_tool):
    # Arrange
    tool, chain = patched_tool(
        response_text="[Code 1]: def f2(text):\n    return text.lower()\n"
    )

    monkeypatch.setattr(
        tool,
        "select_best_solution",
        lambda state: {"response": "async-final", "sources": ["sx"]},
    )
    monkeypatch.setattr(tool, "print_solutions_tree", lambda state: None)

    # Act
    result = await tool._arun(question="Async question")

    # Assert
    assert result["response"] == "async-final"
    assert result["sources"] == ["sx"]
