import pytest
from pydantic import ValidationError

from eagle.tools.memory_access.planning.possible_qa_plans import (
    PossiblePlansQAToolInput,
    PlansQASourcesByTitleToolInput,
    PossiblePlansQATool,
    PlansQASourcesByTitleTool,
)
from eagle.memory.planning.plans_qa_memory import PlansQAMemory


# -----------------------------
# PossiblePlansQAToolInput Tests
# -----------------------------


@pytest.mark.parametrize(
    "question",
    [
        pytest.param(
            "How can I improve my daily productivity?",
            id="happy-productivity-plan-question",
        ),
        pytest.param(
            "What is the best way to prepare for a machine learning interview?",
            id="happy-ml-interview-plan-question",
        ),
        pytest.param(
            "How to create a study plan for learning Python in 3 months?",
            id="happy-python-study-plan-question",
        ),
    ],
)
def test_possible_plans_qa_tool_input_happy_paths(question):

    # Act
    model = PossiblePlansQAToolInput(question=question)

    # Assert
    assert model.question == question


@pytest.mark.parametrize(
    "question",
    [
        pytest.param(
            "",
            id="edge-empty-question-allowed",
        ),
        pytest.param(
            " " * 10,
            id="edge-whitespace-only-question",
        ),
        pytest.param(
            "?",
            id="edge-single-character-question",
        ),
        pytest.param(
            "How to do something extremely complex and long-winded?" * 50,
            id="edge-very-long-question",
        ),
    ],
)
def test_possible_plans_qa_tool_input_edge_cases(question):

    # Act
    model = PossiblePlansQAToolInput(question=question)

    # Assert
    assert model.question == question


@pytest.mark.parametrize(
    "input_value, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "error-missing-question-field",
            id="error-missing-question-field",
        ),
        pytest.param(
            {"question": None},
            "Input should be a valid string",
            "error-question-none",
            id="error-question-none",
        ),
        pytest.param(
            {"question": 123},
            "Input should be a valid string",
            "error-question-not-a-string",
            id="error-question-not-a-string",
        ),
    ],
)
def test_possible_plans_qa_tool_input_error_cases(input_value, expected_error_fragment, case_id):

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        PossiblePlansQAToolInput(**input_value)

    # Assert
    errors_text = str(exc_info.value)
    assert expected_error_fragment in errors_text


# -----------------------------
# PlansQASourcesByTitleToolInput tests
# -----------------------------


@pytest.mark.parametrize(
    "titles",
    [
        pytest.param(
            ["How to learn Python effectively"],
            id="happy-single-title",
        ),
        pytest.param(
            [
                "Best practices for unit testing",
                "Scaling microservices in production",
                "Introduction to distributed systems",
            ],
            id="happy-multiple-titles",
        ),
        pytest.param(
            [
                "Plano de estudos para ciência de dados",
                "Como melhorar a produtividade diária",
            ],
            id="happy-multiple-titles-ptbr",
        ),
    ],
)
def test_plans_qa_sources_by_title_tool_input_happy_paths(titles):

    # Act
    model = PlansQASourcesByTitleToolInput(titles=titles)

    # Assert
    assert model.titles == titles


@pytest.mark.parametrize(
    "titles",
    [
        pytest.param(
            [],
            id="edge-empty-titles-list",
        ),
        pytest.param(
            [""],
            id="edge-single-empty-title",
        ),
        pytest.param(
            [" " * 5],
            id="edge-single-whitespace-title",
        ),
        pytest.param(
            ["a" * 1024],
            id="edge-very-long-single-title",
        ),
        pytest.param(
            ["t1", "", "t3"],
            id="edge-mixed-valid-and-empty-titles",
        ),
    ],
)
def test_plans_qa_sources_by_title_tool_input_edge_cases(titles):

    # Act
    model = PlansQASourcesByTitleToolInput(titles=titles)

    # Assert
    assert model.titles == titles


@pytest.mark.parametrize(
    "input_value, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "error-missing-titles-field",
            id="error-missing-titles-field",
        ),
        pytest.param(
            {"titles": None},
            "Input should be a valid list",
            "error-titles-none",
            id="error-titles-none",
        ),
        pytest.param(
            {"titles": "not-a-list"},
            "Input should be a valid list",
            "error-titles-not-a-list",
            id="error-titles-not-a-list",
        ),
        pytest.param(
            {"titles": [1, 2, 3]},
            "Input should be a valid string",
            "error-titles-elements-not-strings",
            id="error-titles-elements-not-strings",
        ),
    ],
)
def test_plans_qa_sources_by_title_tool_input_error_cases(
    input_value, expected_error_fragment, case_id
):

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        PlansQASourcesByTitleToolInput(**input_value)

    # Assert
    errors_text = str(exc_info.value)
    assert expected_error_fragment in errors_text


# -----------------------------
# Dummy PlansQAMemory for PossiblePlansQATool tests
# -----------------------------


class DummyPlansQAMemory(PlansQAMemory):
    """Minimal in-memory implementation used for testing both sync and async methods."""

    def __init__(self, sync_plans=None, async_plans=None):
        self._sync_plans = sync_plans or []
        self._async_plans = async_plans or []

    def search_memories(self, plans_set_id, query, limit, filter_sources=None):
        plans = list(self._sync_plans)
        if filter_sources:
            plans = [p for p in plans if p.get("source") in filter_sources]
        return plans[:limit]

    async def asearch_memories(self, plans_set_id, query, limit, filter_sources=None):
        plans = list(self._async_plans)
        if filter_sources:
            plans = [p for p in plans if p.get("source") in filter_sources]
        return plans[:limit]


@pytest.fixture
def memory():
    # Arrange
    return DummyPlansQAMemory()


# -----------------------------
# _get_text tests for PossiblePlansQATool
# -----------------------------


@pytest.mark.parametrize(
    "prompt_language, key, expected_substring, test_id",
    [
        pytest.param("en", "no_results", "No plan found.", "get-text-en-no-results", id="get-text-en-no-results"),
        pytest.param("pt-br", "no_results", "Nenhum plano encontrado.", "get-text-ptbr-no-results", id="get-text-ptbr-no-results"),
        pytest.param("en", "result_sep", "Result", "get-text-en-result-sep", id="get-text-en-result-sep"),
        pytest.param("pt-br", "result_sep", "Resultado", "get-text-ptbr-result-sep", id="get-text-ptbr-result-sep"),
        pytest.param("xx", "no_results", "Nenhum plano encontrado.", "get-text-unsupported-lang-fallback", id="get-text-unsupported-lang-fallback"),
    ],
)
def test_possible_plans_qa_tool_get_text(memory, prompt_language, key, expected_substring, test_id):

    # Arrange
    tool = PossiblePlansQATool(
        memory=memory,
        prompt_language=prompt_language,
        limit=5,
        plans_set_id="set",
        filter_sources=None,
    )

    # Act
    text = tool._get_text(key)

    # Assert
    assert expected_substring in text


# -----------------------------
# _format_results tests for PossiblePlansQATool
# -----------------------------


@pytest.mark.parametrize(
    "prompt_language, plans, expected_snippets, test_id",
    [
        pytest.param(
            "en",
            [],
            ["No plan found."],
            "format-en-no-plans",
            id="format-en-no-plans",
        ),
        pytest.param(
            "pt-br",
            [],
            ["Nenhum plano encontrado."],
            "format-ptbr-no-plans",
            id="format-ptbr-no-plans",
        ),
        pytest.param(
            "en",
            [
                {"title": "T1", "short_description": "S1", "question": "Q1"},
                {"title": "T1", "short_description": "S1", "question": "Q2"},
                {"title": "T2", "short_description": "S2", "question": "Q3"},
            ],
            [
                "------------ Result 1 ------------",
                "For the questions below:",
                "Q1",
                "Q2",
                "We have the following knowledge source:",
                "Title: T1",
                "Short description: S1",
                "------------ Result 2 ------------",
                "Title: T2",
                "Short description: S2",
            ],
            "format-en-grouping",
            id="format-en-grouping",
        ),
        pytest.param(
            "pt-br",
            [
                {"title": "Título 1", "short_description": "Desc 1", "question": "Pergunta 1"},
            ],
            [
                "------------ Resultado 1 ------------",
                "Para as perguntas abaixo:",
                "Pergunta 1",
                "Temos a seguinte fonte de conhecimento:",
                "Título: Título 1",
                "Descrição resumida: Desc 1",
            ],
            "format-ptbr-single-result",
            id="format-ptbr-single-result",
        ),
        pytest.param(
            "en",
            [
                {"question": "Q1"},
                {"question": "Q2"},
            ],
            [
                "------------ Result 1 ------------",
                "Q1",
                "Q2",
                "Title: ",
                "Short description: ",
            ],
            "format-en-missing-fields",
            id="format-en-missing-fields",
        ),
    ],
)
def test_possible_plans_qa_tool_format_results(
    memory, prompt_language, plans, expected_snippets, test_id
):

    # Arrange
    tool = PossiblePlansQATool(
        memory=memory,
        prompt_language=prompt_language,
        limit=5,
        plans_set_id="set",
        filter_sources=None,
    )

    # Act
    formatted = tool._format_results(plans)

    # Assert
    for snippet in expected_snippets:
        assert snippet in formatted


# -----------------------------
# _run happy path & edge cases for PossiblePlansQATool
# -----------------------------


@pytest.mark.parametrize(
    "prompt_language, plans, filter_sources, expected_snippets, test_id",
    [
        pytest.param(
            "en",
            [
                {"title": "Plan A", "short_description": "Desc A", "question": "Q1", "source": "S1"},
                {"title": "Plan A", "short_description": "Desc A", "question": "Q2", "source": "S2"},
            ],
            None,
            ["Result 1", "Q1", "Q2", "Plan A", "Desc A"],
            "run-en-basic",
            id="run-en-basic",
        ),
        pytest.param(
            "pt-br",
            [
                {"title": "Plano B", "short_description": "Desc B", "question": "P1", "source": "S1"},
                {"title": "Plano B", "short_description": "Desc B", "question": "P2", "source": "S2"},
            ],
            ["S1"],
            ["Resultado 1", "P1", "Plano B", "Desc B"],
            "run-ptbr-filtered",
            id="run-ptbr-filtered",
        ),
        pytest.param(
            "en",
            [],
            None,
            ["No plan found."],
            "run-en-no-plans",
            id="run-en-no-plans",
        ),
    ],
)
def test_possible_plans_qa_tool_run_happy_and_edge(
    prompt_language, plans, filter_sources, expected_snippets, test_id
):

    # Arrange
    memory = DummyPlansQAMemory(sync_plans=plans)
    tool = PossiblePlansQATool(
        memory=memory,
        prompt_language=prompt_language,
        limit=10,
        plans_set_id="set-123",
        filter_sources=filter_sources,
    )

    # Act
    result = tool._run(question="How to do X?")

    # Assert
    assert isinstance(result, str)
    for snippet in expected_snippets:
        assert snippet in result


@pytest.mark.parametrize(
    "kwargs, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "run-error-missing-question",
            id="run-error-missing-question",
        ),
        pytest.param(
            {"question": None},
            "Input should be a valid string",
            "run-error-question-none",
            id="run-error-question-none",
        ),
        pytest.param(
            {"question": 123},
            "Input should be a valid string",
            "run-error-question-not-string",
            id="run-error-question-not-string",
        ),
    ],
)
def test_possible_plans_qa_tool_run_validation_errors(
    kwargs, expected_error_fragment, case_id, memory
):

    # Arrange
    tool = PossiblePlansQATool(
        memory=memory,
        prompt_language="en",
        limit=5,
        plans_set_id="set",
        filter_sources=None,
    )

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        tool._run(**kwargs)

    # Assert
    assert expected_error_fragment in str(exc_info.value)


# -----------------------------
# _arun happy path & edge cases for PossiblePlansQATool
# -----------------------------


@pytest.mark.parametrize(
    "prompt_language, plans, filter_sources, expected_snippets, test_id",
    [
        pytest.param(
            "en",
            [
                {"title": "Async Plan", "short_description": "Async Desc", "question": "AQ1", "source": "AS1"},
            ],
            None,
            ["Result 1", "AQ1", "Async Plan", "Async Desc"],
            "arun-en-basic",
            id="arun-en-basic",
        ),
        pytest.param(
            "pt-br",
            [],
            None,
            ["Nenhum plano encontrado."],
            "arun-ptbr-no-plans",
            id="arun-ptbr-no-plans",
        ),
    ],
)
@pytest.mark.asyncio
async def test_possible_plans_qa_tool_arun_happy_and_edge(
    prompt_language, plans, filter_sources, expected_snippets, test_id
):

    # Arrange
    memory = DummyPlansQAMemory(async_plans=plans)
    tool = PossiblePlansQATool(
        memory=memory,
        prompt_language=prompt_language,
        limit=10,
        plans_set_id=("set",),
        filter_sources=filter_sources,
    )

    # Act
    result = await tool._arun(question="Async question?")

    # Assert
    assert isinstance(result, str)
    for snippet in expected_snippets:
        assert snippet in result


@pytest.mark.parametrize(
    "kwargs, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "arun-error-missing-question",
            id="arun-error-missing-question",
        ),
        pytest.param(
            {"question": None},
            "Input should be a valid string",
            "arun-error-question-none",
            id="arun-error-question-none",
        ),
    ],
)
@pytest.mark.asyncio
async def test_possible_plans_qa_tool_arun_validation_errors(
    kwargs, expected_error_fragment, case_id, memory
):

    # Arrange
    tool = PossiblePlansQATool(
        memory=memory,
        prompt_language="en",
        limit=5,
        plans_set_id="set",
        filter_sources=None,
    )

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        await tool._arun(**kwargs)

    # Assert
    assert expected_error_fragment in str(exc_info.value)


# -----------------------------
# Dummy PlansQAMemory for PlansQASourcesByTitleTool tests
# -----------------------------


class DummyPlansQAMemoryForSources(PlansQAMemory):
    """In-memory fake PlansQAMemory used for testing PlansQASourcesByTitleTool."""

    def __init__(self, sync_plans=None, async_plans=None):
        self._sync_plans = sync_plans or []
        self._async_plans = async_plans or []

    def search_memories(self, plans_set_id, filter_titles, limit):
        titles_set = set(filter_titles or [])
        if titles_set:
            return [p for p in self._sync_plans if p.get("title") in titles_set][:limit]
        return self._sync_plans[:limit]

    async def asearch_memories(self, plans_set_id, filter_titles, limit):
        titles_set = set(filter_titles or [])
        if titles_set:
            return [p for p in self._async_plans if p.get("title") in titles_set][:limit]
        return self._async_plans[:limit]


@pytest.fixture
def memory_sources():
    # Arrange
    return DummyPlansQAMemoryForSources()


# -----------------------------
# PlansQASourcesByTitleTool tests
# -----------------------------


@pytest.mark.parametrize(
    "prompt_language, key, expected_substring, test_id",
    [
        pytest.param("en", "no_results", "No source found.", "sources-get-text-en-no-results", id="sources-get-text-en-no-results"),
        pytest.param("pt-br", "no_results", "Nenhuma fonte encontrada.", "sources-get-text-ptbr-no-results", id="sources-get-text-ptbr-no-results"),
        pytest.param("en", "result_sep", "Source", "sources-get-text-en-result-sep", id="sources-get-text-en-result-sep"),
        pytest.param("pt-br", "result_sep", "Fonte", "sources-get-text-ptbr-result-sep", id="sources-get-text-ptbr-result-sep"),
        pytest.param("xx", "no_results", "Nenhuma fonte encontrada.", "sources-get-text-unsupported-lang-fallback", id="sources-get-text-unsupported-lang-fallback"),
    ],
)
def test_plans_qa_sources_by_title_tool_get_text(memory_sources, prompt_language, key, expected_substring, test_id):

    # Arrange
    tool = PlansQASourcesByTitleTool(
        memory=memory_sources,
        plans_set_id="set",
        prompt_language=prompt_language,
    )

    # Act
    text = tool._get_text(key)

    # Assert
    assert expected_substring in text


@pytest.mark.parametrize(
    "prompt_language, plans, titles_input, expected_snippets, test_id",
    [
        pytest.param(
            "en",
            [
                {
                    "title": "Plan A",
                    "short_description": "Short A",
                    "plan": "Full text A",
                },
                {
                    "title": "Plan B",
                    "short_description": "Short B",
                    "plan": "Full text B",
                },
            ],
            ["Plan A", "Plan B"],
            [
                "------------ Source 1 ------------",
                "Title: Plan A",
                "Short description: Short A",
                "Full text:",
                "Full text A",
                "------------ Source 2 ------------",
                "Title: Plan B",
                "Short description: Short B",
                "Full text B",
            ],
            "sources-run-en-basic-two-plans",
            id="sources-run-en-basic-two-plans",
        ),
        pytest.param(
            "pt-br",
            [
                {
                    "title": "Plano X",
                    "short_description": "Desc X",
                    "plan": "Texto completo X",
                },
                {
                    "title": "Plano X",
                    "short_description": "Desc X atualizada",
                    "plan": "Texto completo X atualizado",
                },
                {
                    "title": "Plano Y",
                    "short_description": "Desc Y",
                    "plan": "Texto completo Y",
                },
            ],
            ["Plano X", "Plano Y"],
            [
                "------------ Fonte 1 ------------",
                "Título: Plano X",
                "Descrição resumida: Desc X atualizada",
                "Texto completo:",
                "Texto completo X atualizado",
                "------------ Fonte 2 ------------",
                "Título: Plano Y",
                "Descrição resumida: Desc Y",
                "Texto completo Y",
            ],
            "sources-run-ptbr-grouped-by-title",
            id="sources-run-ptbr-grouped-by-title",
        ),
        pytest.param(
            "en",
            [],
            ["Nonexistent"],
            ["No source found."],
            "sources-run-en-no-plans",
            id="sources-run-en-no-plans",
        ),
        pytest.param(
            "pt-br",
            [],
            [],
            ["Nenhuma fonte encontrada."],
            "sources-run-ptbr-no-plans-empty-titles",
            id="sources-run-ptbr-no-plans-empty-titles",
        ),
        pytest.param(
            "en",
            [
                {
                    "title": "Plan Z",
                }
            ],
            ["Plan Z"],
            [
                "------------ Source 1 ------------",
                "Title: Plan Z",
                "Short description: ",
                "Full text:",
                "",
            ],
            "sources-run-en-missing-fields",
            id="sources-run-en-missing-fields",
        ),
    ],
)
def test_plans_qa_sources_by_title_tool_run_happy_and_edge(
    prompt_language,
    plans,
    titles_input,
    expected_snippets,
    test_id,
):

    # Arrange
    memory = DummyPlansQAMemoryForSources(sync_plans=plans)
    tool = PlansQASourcesByTitleTool(
        memory=memory,
        plans_set_id="plans-set-id",
        prompt_language=prompt_language,
    )

    # Act
    result = tool._run(titles=titles_input)

    # Assert
    assert isinstance(result, str)
    for snippet in expected_snippets:
        assert snippet in result


@pytest.mark.parametrize(
    "kwargs, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "sources-run-error-missing-titles",
            id="sources-run-error-missing-titles",
        ),
        pytest.param(
            {"titles": None},
            "Input should be a valid list",
            "sources-run-error-titles-none",
            id="sources-run-error-titles-none",
        ),
        pytest.param(
            {"titles": "not-a-list"},
            "Input should be a valid list",
            "sources-run-error-titles-not-list",
            id="sources-run-error-titles-not-list",
        ),
        pytest.param(
            {"titles": [1, 2]},
            "Input should be a valid string",
            "sources-run-error-titles-elements-not-string",
            id="sources-run-error-titles-elements-not-string",
        ),
    ],
)
def test_plans_qa_sources_by_title_tool_run_validation_errors(
    kwargs, expected_error_fragment, case_id, memory_sources
):

    # Arrange
    tool = PlansQASourcesByTitleTool(
        memory=memory_sources,
        plans_set_id="set",
        prompt_language="en",
    )

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        tool._run(**kwargs)

    # Assert
    assert expected_error_fragment in str(exc_info.value)


@pytest.mark.parametrize(
    "prompt_language, plans, titles_input, expected_snippets, test_id",
    [
        pytest.param(
            "en",
            [
                {
                    "title": "Async Plan",
                    "short_description": "Async Desc",
                    "plan": "Async full text",
                }
            ],
            ["Async Plan"],
            [
                "------------ Source 1 ------------",
                "Title: Async Plan",
                "Short description: Async Desc",
                "Async full text",
            ],
            "sources-arun-en-basic",
            id="sources-arun-en-basic",
        ),
        pytest.param(
            "pt-br",
            [],
            ["Any"],
            ["Nenhuma fonte encontrada."],
            "sources-arun-ptbr-no-plans",
            id="sources-arun-ptbr-no-plans",
        ),
    ],
)
@pytest.mark.asyncio
async def test_plans_qa_sources_by_title_tool_arun_happy_and_edge(
    prompt_language, plans, titles_input, expected_snippets, test_id
):

    # Arrange
    memory = DummyPlansQAMemoryForSources(async_plans=plans)
    tool = PlansQASourcesByTitleTool(
        memory=memory,
        plans_set_id="async-set",
        prompt_language=prompt_language,
    )

    # Act
    result = await tool._arun(titles=titles_input)

    # Assert
    assert isinstance(result, str)
    for snippet in expected_snippets:
        assert snippet in result


@pytest.mark.parametrize(
    "kwargs, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "sources-arun-error-missing-titles",
            id="sources-arun-error-missing-titles",
        ),
        pytest.param(
            {"titles": None},
            "Input should be a valid list",
            "sources-arun-error-titles-none",
            id="sources-arun-error-titles-none",
        ),
    ],
)
@pytest.mark.asyncio
async def test_plans_qa_sources_by_title_tool_arun_validation_errors(
    kwargs, expected_error_fragment, case_id, memory_sources
):

    # Arrange
    tool = PlansQASourcesByTitleTool(
        memory=memory_sources,
        plans_set_id="set",
        prompt_language="en",
    )

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        await tool._arun(**kwargs)

    # Assert
    assert expected_error_fragment in str(exc_info.value)
