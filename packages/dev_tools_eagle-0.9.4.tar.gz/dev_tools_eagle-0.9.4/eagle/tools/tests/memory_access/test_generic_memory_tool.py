import pytest
from pydantic import ValidationError

from eagle.tools.memory_access.generic_memory_tool import GenericMemoryToolInput


# -----------------------------
# Happy path tests
# -----------------------------


@pytest.mark.parametrize(
    "query, namespace_prefix, limit, offset, filter_value",
    [
        pytest.param(
            "find project documents",
            ["projects", "2024"],
            10,
            0,
            None,
            id="happy-basic-query-defaults-no-filter",
        ),
        pytest.param(
            "user settings",
            ["users", "settings"],
            5,
            2,
            "status:active",
            id="happy-query-with-filter-and-pagination",
        ),
        pytest.param(
            "error logs",
            ["logs", "errors"],
            100,
            10,
            "level:critical",
            id="happy-large-limit-with-filter",
        ),
    ],
)
def test_generic_memory_tool_input_happy_paths(
    query, namespace_prefix, limit, offset, filter_value
):

    # Act
    model = GenericMemoryToolInput(
        query=query,
        namespace_prefix=namespace_prefix,
        limit=limit,
        offset=offset,
        filter=filter_value,
    )

    # Assert
    assert model.query == query
    assert model.namespace_prefix == namespace_prefix
    assert model.limit == limit
    assert model.offset == offset
    assert model.filter == filter_value


# -----------------------------
# Edge case tests
# -----------------------------


@pytest.mark.parametrize(
    "query, namespace_prefix, limit, offset, filter_value",
    [
        pytest.param(
            "",
            [],
            10,
            0,
            None,
            id="edge-empty-query-and-empty-namespace",
        ),
        pytest.param(
            "a",
            ["root"],
            0,
            0,
            "",
            id="edge-zero-limit-empty-filter",
        ),
        pytest.param(
            " " * 20,
            ["deep", "nested", "namespace"],
            1_000_000,
            1_000_000,
            "status:archived",
            id="edge-whitespace-query-huge-pagination",
        ),
        pytest.param(
            "special characters !@#$%^&*()",
            ["ns", "sub_ns"],
            10,
            5,
            None,
            id="edge-special-characters-in-query",
        ),
    ],
)
def test_generic_memory_tool_input_edge_cases(
    query, namespace_prefix, limit, offset, filter_value
):

    # Act
    model = GenericMemoryToolInput(
        query=query,
        namespace_prefix=namespace_prefix,
        limit=limit,
        offset=offset,
        filter=filter_value,
    )

    # Assert
    assert model.query == query
    assert model.namespace_prefix == namespace_prefix
    assert model.limit == limit
    assert model.offset == offset
    assert model.filter == filter_value


def test_generic_memory_tool_input_defaults_for_limit_and_offset():

    # Act
    model = GenericMemoryToolInput(
        query="default pagination",
        namespace_prefix=["default", "ns"],
    )

    # Assert
    assert model.limit == 10
    assert model.offset == 0
    assert model.filter is None


# -----------------------------
# Error case tests
# -----------------------------


@pytest.mark.parametrize(
    "input_value, expected_error_fragment, case_id",
    [
        pytest.param(
            {
                # Missing query
                "namespace_prefix": ["ns"],
            },
            "Field required",
            "error-missing-query",
            id="error-missing-query",
        ),
        pytest.param(
            {
                "query": "some query",
                # Missing namespace_prefix
            },
            "Field required",
            "error-missing-namespace-prefix",
            id="error-missing-namespace-prefix",
        ),
        pytest.param(
            {
                "query": None,
                "namespace_prefix": ["ns"],
            },
            "Input should be a valid string",
            "error-query-none",
            id="error-query-none",
        ),
        pytest.param(
            {
                "query": 123,
                "namespace_prefix": ["ns"],
            },
            "Input should be a valid string",
            "error-query-not-string",
            id="error-query-not-string",
        ),
        pytest.param(
            {
                "query": "q",
                "namespace_prefix": "not-a-list",
            },
            "Input should be a valid list",
            "error-namespace-prefix-not-list",
            id="error-namespace-prefix-not-list",
        ),
        pytest.param(
            {
                "query": "q",
                "namespace_prefix": [1, 2, 3],
            },
            "Input should be a valid string",
            "error-namespace-prefix-elements-not-string",
            id="error-namespace-prefix-elements-not-string",
        ),
        pytest.param(
            {
                "query": "q",
                "namespace_prefix": ["ns"],
                "limit": "ten",
            },
            "Input should be a valid integer",
            "error-limit-not-int",
            id="error-limit-not-int",
        ),
        pytest.param(
            {
                "query": "q",
                "namespace_prefix": ["ns"],
                "offset": "zero",
            },
            "Input should be a valid integer",
            "error-offset-not-int",
            id="error-offset-not-int",
        ),
    ],
)
def test_generic_memory_tool_input_error_cases(
    input_value, expected_error_fragment, case_id
):

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        GenericMemoryToolInput(**input_value)

    # Assert
    errors_text = str(exc_info.value)
    assert expected_error_fragment in errors_text
