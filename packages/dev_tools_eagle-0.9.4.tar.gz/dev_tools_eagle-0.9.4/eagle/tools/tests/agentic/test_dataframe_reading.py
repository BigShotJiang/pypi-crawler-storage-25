import types
import pytest
import pandas as pd

from eagle.tools.agentic.dataframe_analysis.dataframe_reading import DataFrameReadingTool


class FakeSharedObject:
    def __init__(self, obj):
        self.object = obj


class FakeSharedObjectsMemory:
    def __init__(self, obj_or_none):
        self._obj_or_none = obj_or_none
        self.calls = []

    def get_memory_object(self, chat_id: str, object_id: str):
        self.calls.append((chat_id, object_id))
        return self._obj_or_none


class FakeSummarizationChain:
    def __init__(self):
        self.invocations = []

    def invoke(self, text: str):
        self.invocations.append(text)
        return f"SUMMARY::{text}"


class FakePromptGenerator:
    """mimics prompt_generator.generate_prompt(...) return payload"""
    def __init__(self, output_parser):
        self.output_parser = output_parser
        self.calls = []

    def generate_prompt(self, prompt_name: str, language: str, llm, use_structured_output: bool):
        self.calls.append((prompt_name, language, use_structured_output))
        return {"output_parser": self.output_parser}


class FakeOutputParser:
    def __init__(self):
        self.calls = []

    def parse(self, message):
        # message is whatever agent_instance.state_snapshot.values['messages'][-1] returns
        self.calls.append(message)
        # Agent will store "comments" in message["content"]
        return types.SimpleNamespace(comments=message["content"])


class FakeRowsReaderAgent:
    """Replaces DataFrameRowsReaderAgent."""
    created = []

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.loaded = []
        self.runs = []
        # create minimal snapshot structure expected by tool
        self.state_snapshot = types.SimpleNamespace(values={"messages": []})
        FakeRowsReaderAgent.created.append(self)

    def load_memory(self, key: str, memory):
        self.loaded.append((key, memory))

    def run(self, state: dict, config: dict):
        self.runs.append((state, config))
        idx = config.get("dataframe_shared_object_list_of_idx_to_analyse", [])
        # last message must exist; tool reads [-1]
        self.state_snapshot.values["messages"].append(
            {"role": "assistant", "name": self.name, "content": f"read rows {idx}"}
        )


class FakeTool:
    def __init__(self, name: str):
        self.name = name


def _make_tool(
    monkeypatch,
    *,
    shared_obj,
    max_rows_per_call=2,
    prompt_language="en",
    has_compiled_graph=False,
    tools_available=None,
):
    """
    Create DataFrameReadingTool instance bypassing pydantic validation using model_construct,
    and patch external collaborators.
    """
    # patch agent class used by DataFrameReadingTool
    monkeypatch.setattr(
        "eagle.tools.agentic.dataframe_analysis.dataframe_reading.DataFrameRowsReaderAgent",
        FakeRowsReaderAgent,
    )

    # patch create_summarization_chain
    fake_chain = FakeSummarizationChain()
    monkeypatch.setattr(
        "eagle.tools.agentic.dataframe_analysis.dataframe_reading.create_summarization_chain",
        lambda prompt_language, llm: fake_chain,
    )

    # patch prompt_generator.generate_prompt
    output_parser = FakeOutputParser()
    fake_pg = FakePromptGenerator(output_parser=output_parser)
    monkeypatch.setattr(
        "eagle.tools.agentic.dataframe_analysis.dataframe_reading.prompt_generator",
        fake_pg,
    )

    # Build tool instance without BaseTool validation headaches
    mem = FakeSharedObjectsMemory(shared_obj)

    calling_agent = types.SimpleNamespace()
    if has_compiled_graph:
        # just needs attribute "_compiled_graph" to flip the branch
        calling_agent._compiled_graph = object()
        calling_agent.state_snapshot = types.SimpleNamespace(
            values={"messages": [types.SimpleNamespace(name="User", content="from snapshot msg")]}
        )

    tool = DataFrameReadingTool.model_construct(
        prompt_language=prompt_language,
        chat_id="chat-1",
        max_rows_per_call=max_rows_per_call,
        shared_objects_memory=mem,
        llm=object(),  # not used by our fakes
        calling_agent=calling_agent,
        tools_available=tools_available or [],
        chat_history_window_size=10,
        has_vision=False,
        shared_objects_memory_configs=object(),
        callback_manager=object(),
    )

    # IMPORTANT: class has bug calling dict as function -> override on instance as callables
    tool.shared_object_not_found_error_response_by_prompt_language = (
        lambda lang: f"NOT_FOUND::{lang}"
    )
    tool.not_a_dataframe_error_response_by_prompt_language = (
        lambda lang: f"NOT_A_DF::{lang}"
    )

    return tool, mem, fake_pg, output_parser, fake_chain


# -------------------------
# Tests
# -------------------------

def test_run_returns_not_found_when_shared_object_none(monkeypatch):
    tool, mem, *_ = _make_tool(monkeypatch, shared_obj=None)

    out = tool._run(
        tools_to_use=[],
        analysis_demands="read stuff",
        dataframe_shared_object_id="df-1",
    )

    assert out == "NOT_FOUND::en"
    assert mem.calls == [("chat-1", "df-1")]


def test_run_returns_not_a_dataframe_when_object_is_not_df(monkeypatch):
    shared_obj = FakeSharedObject(obj={"not": "a dataframe"})
    tool, mem, *_ = _make_tool(monkeypatch, shared_obj=shared_obj)

    out = tool._run(
        tools_to_use=[],
        analysis_demands="read stuff",
        dataframe_shared_object_id="df-1",
    )

    assert out == "NOT_A_DF::en"
    assert mem.calls == [("chat-1", "df-1")]


def test_run_happy_path_chunks_and_summary_no_compiled_graph(monkeypatch):
    df = pd.DataFrame({"a": [10, 20, 30]})
    shared_obj = FakeSharedObject(obj=df)

    # tools_available empty => executing_tools = [] => execute_important_guidelines == analysis_demands
    tool, mem, fake_pg, output_parser, chain = _make_tool(
        monkeypatch,
        shared_obj=shared_obj,
        max_rows_per_call=2,
        has_compiled_graph=False,
        tools_available=[],
    )

    out = tool._run(
        tools_to_use=["functions.anything"],  # will be normalized but irrelevant
        analysis_demands="PLEASE READ THIS",
        dataframe_shared_object_id="df-1",
    )

    # prompt called
    assert fake_pg.calls[0][0] == "execute_reading"
    assert fake_pg.calls[0][1] == "en"

    # shared memory read
    assert mem.calls == [("chat-1", "df-1")]

    # agent ran twice: rows [0,1] then [2]
    assert len(FakeRowsReaderAgent.created) >= 2
    first_agent = FakeRowsReaderAgent.created[-2]
    second_agent = FakeRowsReaderAgent.created[-1]

    first_run_state, first_run_config = first_agent.runs[0]
    second_run_state, second_run_config = second_agent.runs[0]

    assert first_run_config["dataframe_shared_object_list_of_idx_to_analyse"] == [0, 1]
    assert second_run_config["dataframe_shared_object_list_of_idx_to_analyse"] == [2]

    # since calling_agent has NO _compiled_graph branch, state has default single message with execute_important_guidelines
    assert first_run_state["messages"][0]["content"] == "PLEASE READ THIS"

    # output_parser sees agent last messages
    assert "read rows [0, 1]" in output_parser.calls[0]["content"]
    assert "read rows [2]" in output_parser.calls[1]["content"]

    # summarization_chain invoked once; and tool returns its output
    assert len(chain.invocations) == 1
    assert out.startswith("SUMMARY::")
    # summary prompt must contain demand and per-batch comments
    invoked = chain.invocations[0]
    assert "PLEASE READ THIS" in invoked
    assert "--> rows idx: [0, 1]:" in invoked
    assert "--> rows idx: [2]:" in invoked


def test_run_uses_calling_agent_snapshot_when_compiled_graph_present(monkeypatch):
    df = pd.DataFrame({"a": [1, 2]})
    shared_obj = FakeSharedObject(obj=df)

    tool, _, _, _, chain = _make_tool(
        monkeypatch,
        shared_obj=shared_obj,
        max_rows_per_call=10,
        has_compiled_graph=True,
        tools_available=[],
    )

    out = tool._run(
        tools_to_use=[],
        analysis_demands="IGNORED IN THIS BRANCH",
        dataframe_shared_object_id="df-1",
    )

    # It should have pulled "from snapshot msg" into the agent state
    agent = FakeRowsReaderAgent.created[-1]
    run_state, _ = agent.runs[0]
    assert run_state["messages"][0]["content"] == "from snapshot msg"

    # Summary should include the execute_important_guidelines (here: analysis_demands, because tools_available empty)
    assert "IGNORED IN THIS BRANCH" in chain.invocations[0]
    assert out.startswith("SUMMARY::")


def test_run_tools_to_use_strips_functions_prefix(monkeypatch):
    df = pd.DataFrame({"a": [1]})
    shared_obj = FakeSharedObject(obj=df)

    tools_available = [FakeTool("t1")]
    tool, _, _, _, chain = _make_tool(
        monkeypatch,
        shared_obj=shared_obj,
        max_rows_per_call=10,
        has_compiled_graph=False,
        tools_available=tools_available,
    )

    tool._run(
        tools_to_use=["functions.t1"],
        analysis_demands="DEMAND",
        dataframe_shared_object_id="df-1",
    )

    # Because tools_available has a matching tool, the tool wraps the demand
    assert "Use the tools you have to accomplish the following:" in chain.invocations[0]


def test_run_executing_tools_truthy_even_when_all_none_current_behavior(monkeypatch):
    """
    Captures current behavior:
    executing_tools is built as [tool if match else None for tool in tools_available]
    If tools_available has elements but none match, list becomes [None] which is truthy -> it wraps demands.
    """
    df = pd.DataFrame({"a": [1]})
    shared_obj = FakeSharedObject(obj=df)

    tools_available = [FakeTool("real_tool")]
    tool, _, _, _, chain = _make_tool(
        monkeypatch,
        shared_obj=shared_obj,
        max_rows_per_call=10,
        has_compiled_graph=False,
        tools_available=tools_available,
    )

    tool._run(
        tools_to_use=["functions.no_match"],
        analysis_demands="DEMAND",
        dataframe_shared_object_id="df-1",
    )

    # Current behavior (bug/quirk): still wraps demands
    assert "Use the tools you have to accomplish the following:" in chain.invocations[0]
