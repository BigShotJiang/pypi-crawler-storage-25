import pytest
from types import SimpleNamespace
import pandas as pd

from eagle.tools.agentic.dataframe_analysis.dataframe_analysis import DataFrameAnalysisTool
from eagle.agents.specialists.data_analysis.dataframe_rows_analyst.base import NewColumnProposal


class FakeSharedObject:
    def __init__(self, obj):
        self.object = obj


class FakeSharedObjectsMemory:
    def __init__(self, shared_obj):
        self._shared_obj = shared_obj
        self.put_calls = []

    def get_memory_object(self, chat_id, object_id):
        return self._shared_obj

    def put_memory(self, chat_id, object_name, description, obj, object_type):
        self.put_calls.append(
            dict(
                chat_id=chat_id,
                object_name=object_name,
                description=description,
                obj=obj,
                object_type=object_type,
            )
        )
        return "new_obj_id_999"


class FakeOutputParser:
    def __init__(self, responses):
        self._responses = list(responses)
        self.calls = []

    def parse(self, message):
        self.calls.append(message)
        return self._responses.pop(0)


class FakeSummarizationChain:
    def __init__(self, summary_text="SUM"):
        self.summary_text = summary_text
        self.invocations = []

    def invoke(self, prompt):
        self.invocations.append(prompt)
        return self.summary_text


class FakeAgentInstance:
    def __init__(self, name, description):
        self.name = name
        self.description = description
        self.loaded = []
        self.runs = []
        self.state_snapshot = SimpleNamespace(values={"messages": []})

    def load_memory(self, key, memory):
        self.loaded.append((key, memory))

    def run(self, state, config):
        self.runs.append((state, config))
        self.state_snapshot.values["messages"].append("FINAL_MESSAGE")


class FakeCallingAgent:
    def __init__(self):
        self.state_snapshot = SimpleNamespace(
            values={
                "messages": [
                    SimpleNamespace(name="u", content="hello"),
                    SimpleNamespace(name="u", content="more"),
                ]
            }
        )


@pytest.fixture
def patch_prompt_and_summarizer(monkeypatch):
    import eagle.tools.agentic.dataframe_analysis.dataframe_analysis as mod

    # 2 chunks
    resp1 = SimpleNamespace(
        rows_to_maintain=[0, 1],
        new_columns={"flag": ["a", "b"]},
        comments="c1",
    )
    resp2 = SimpleNamespace(
        rows_to_maintain=[2],  # CORRETO
        new_columns={"flag": ["c"]},
        comments="c2",
    )
    output_parser = FakeOutputParser([resp1, resp2])

    monkeypatch.setattr(
        mod.prompt_generator,
        "generate_prompt",
        lambda **kwargs: {"output_parser": output_parser},
    )

    summarizer = FakeSummarizationChain(summary_text="SUMMARY_OK")
    monkeypatch.setattr(
        mod,
        "create_summarization_chain",
        lambda **kwargs: summarizer,
    )

    monkeypatch.setattr(mod, "DataFrameRowsAnalystAgent", FakeAgentInstance)

    return output_parser, summarizer


@pytest.fixture
def fake_df():
    return pd.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})


def make_tool(shared_memory):
    tool = DataFrameAnalysisTool.model_construct()

    tool.prompt_language = "en"
    tool.chat_id = "chat1"
    tool.llm = object() 
    tool.max_rows_per_call = 2
    tool.shared_objects_memory = shared_memory
    tool.calling_agent = FakeCallingAgent()

    fake_tool = SimpleNamespace(name="describe_statistics")
    tool.tools_available = [fake_tool]

    return tool



def test_run_returns_not_found_when_shared_object_none():
    mem = FakeSharedObjectsMemory(shared_obj=None)
    tool = make_tool(mem)

    with pytest.raises(TypeError):
        tool._run(
            tools_to_use=[],
            analysis_demands="x",
            dataframe_shared_object_id="dfid",
            new_columns_proposals=[],
            new_dataframe_name="newdf",
            new_dataframe_description="desc",
        )


def test_run_returns_not_a_dataframe_when_object_is_not_df():
    mem = FakeSharedObjectsMemory(shared_obj=FakeSharedObject(obj={"not": "df"}))
    tool = make_tool(mem)

    with pytest.raises(TypeError):
        tool._run(
            tools_to_use=[],
            analysis_demands="x",
            dataframe_shared_object_id="dfid",
            new_columns_proposals=[],
            new_dataframe_name="newdf",
            new_dataframe_description="desc",
        )


def test_run_happy_path_chunks_concat_puts_memory_and_returns_final(
    fake_df, patch_prompt_and_summarizer
):
    output_parser, summarizer = patch_prompt_and_summarizer

    mem = FakeSharedObjectsMemory(shared_obj=FakeSharedObject(obj=fake_df))
    tool = make_tool(mem)

    out = tool._run(
        tools_to_use=["functions.describe_statistics"],  
        analysis_demands="Do X and Y",
        dataframe_shared_object_id="dfid",
        new_columns_proposals=[
            NewColumnProposal(column_name="flag", column_description="x", column_type="str")
        ],
        new_dataframe_name="newdf",
        new_dataframe_description="desc",
    )

    assert summarizer.invocations
    assert "c1" in summarizer.invocations[0]
    assert "c2" in summarizer.invocations[0]

    assert len(mem.put_calls) == 1
    stored = mem.put_calls[0]["obj"]
    assert isinstance(stored, pd.DataFrame)
    assert len(stored) == 3
    assert "flag" in stored.columns

    assert "new_obj_id_999" in out
    assert "SUMMARY_OK" in out

    assert len(output_parser.calls) == 2
