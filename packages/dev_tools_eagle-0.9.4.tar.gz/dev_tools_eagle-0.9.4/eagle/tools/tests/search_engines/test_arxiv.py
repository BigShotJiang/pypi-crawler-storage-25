import pytest
from pydantic import ValidationError

from eagle.tools.search_engines.arxiv import ArvixModifiedInput, ArxivModifiedQueryRun


# --------------------
# Tests for ArvixModifiedInput
# --------------------


@pytest.mark.parametrize(
    "query, top_k_results",
    [
        pytest.param(
            "quantum computing",
            5,
            id="input-happy-basic-default-top-k",
        ),
        pytest.param(
            "deep learning optimization",
            3,
            id="input-happy-custom-small-top-k",
        ),
        pytest.param(
            "graph neural networks",
            10,
            id="input-happy-custom-large-top-k",
        ),
    ],
)
def test_arvix_modified_input_happy_path(query, top_k_results):

    # Act
    model = ArvixModifiedInput(
        query=query,
        top_k_results=top_k_results,
    )

    # Assert
    assert model.query == query
    assert model.top_k_results == top_k_results


def test_arvix_modified_input_uses_default_top_k_when_not_provided():

    # Act
    model = ArvixModifiedInput(query="transformer architectures")

    # Assert
    assert model.top_k_results == 5


@pytest.mark.parametrize(
    "top_k_results, expected",
    [
        pytest.param(0, 0, id="input-edge-top-k-zero-allowed"),
        pytest.param(1, 1, id="input-edge-top-k-one-allowed"),
        pytest.param(1000, 1000, id="input-edge-top-k-large-allowed"),
    ],
)
def test_arvix_modified_input_edge_top_k_results_values(top_k_results, expected):

    # Act
    model = ArvixModifiedInput(query="test edge top_k_results", top_k_results=top_k_results)

    # Assert
    assert model.top_k_results == expected


@pytest.mark.parametrize(
    "kwargs, expect_error, expected_fragment, case_id",
    [
        pytest.param(
            {},
            True,
            "Field required",
            "input-error-missing-query",
            id="input-error-missing-query",
        ),
        pytest.param(
            {"query": ""},
            False,
            None,
            "input-no-error-empty-query-allowed",
            id="input-no-error-empty-query-allowed",
        ),
    ],
)
def test_arvix_modified_input_error_cases(kwargs, expect_error, expected_fragment, case_id):

    if expect_error:

        # Act / Assert
        with pytest.raises(ValidationError) as exc_info:
            ArvixModifiedInput(**kwargs)

        # Assert
        errors_text = str(exc_info.value)
        assert expected_fragment in errors_text

    else:

        # Act
        model = ArvixModifiedInput(**kwargs)

        # Assert
        assert model.query == kwargs["query"]
