import pytest
from types import SimpleNamespace
import eagle.tools as tools_mod


def _mf(name_default, desc_default):
    # simula estrutura: cls.model_fields['name'].default
    return {
        "name": SimpleNamespace(default=name_default),
        "description": SimpleNamespace(default=desc_default),
    }


class FakeToolA:
    __name__ = "FakeToolA"
    model_fields = _mf("tool_a", "A tool")


class FakeToolB:
    __name__ = "FakeToolB"
    model_fields = _mf("tool_b", "B tool")


class FakeBadTool:
    __name__ = "FakeBadTool"
    model_fields = _mf(123, "bad tool")  # name.default não-string => deve ser filtrado


def test_generate_tools_dict_builds_expected_dict(mocker):
    mocker.patch.object(
        tools_mod,
        "get_all_subclasses",
        return_value=[FakeToolA, FakeToolB, FakeBadTool],
    )

    d = tools_mod._generate_tools_dict()

    assert set(d.keys()) == {"tool_a", "tool_b"}
    assert d["tool_a"]["class"] is FakeToolA
    assert d["tool_a"]["name"] == "tool_a"
    assert d["tool_a"]["description"] == "A tool"


def test_get_tool_returns_dict_entry_when_found(mocker):
    mocker.patch.object(tools_mod, "get_all_subclasses", return_value=[FakeToolA])

    tool_entry = tools_mod.get_tool("tool_a")

    assert tool_entry is not None
    assert tool_entry["class"] is FakeToolA
    assert tool_entry["name"] == "tool_a"
    assert tool_entry["description"] == "A tool"


def test_get_tool_returns_none_when_not_found(mocker):
    mocker.patch.object(tools_mod, "get_all_subclasses", return_value=[FakeToolA])

    tool_entry = tools_mod.get_tool("does_not_exist")
    assert tool_entry is None
