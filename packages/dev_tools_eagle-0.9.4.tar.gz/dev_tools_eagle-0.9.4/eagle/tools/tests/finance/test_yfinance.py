import pytest
import pandas as pd

from pydantic import ValidationError

from eagle.tools.finance.yfinance import YFinanceTool, YFinanceInput, YFinanceAPIWrapper


# -----------------------------
# Tests for load_custom_session
# -----------------------------


def test_yfinance_api_wrapper_load_custom_session_sets_session():

    # Arrange
    wrapper = YFinanceAPIWrapper()
    fake_session = object()

    # Act
    wrapper.load_custom_session(fake_session)

    # Assert
    assert wrapper.session is fake_session


# -----------------------------
# Tests for get_stock_info
# -----------------------------


class DummyTicker:
    """Dummy Ticker class used to simulate yfinance.Ticker behavior."""

    def __init__(self, info_data, history_df):
        self._info_data = info_data
        self._history_df = history_df

    @property
    def info(self):
        return self._info_data

    def history(self, period="1mo", interval="1d"):
        return self._history_df


@pytest.mark.parametrize(
    "ticker, info_data, expected_result, test_id",
    [
        pytest.param(
            "AAPL",
            {"symbol": "AAPL", "price": 150.0},
            {"symbol": "AAPL", "price": 150.0},
            "happy-stock-info-aapl",
            id="happy-stock-info-aapl",
        ),
        pytest.param(
            "MSFT",
            {"symbol": "MSFT", "price": 320.5, "currency": "USD"},
            {"symbol": "MSFT", "price": 320.5, "currency": "USD"},
            "happy-stock-info-msft",
            id="happy-stock-info-msft",
        ),
    ],
)
def test_get_stock_info_happy_paths(monkeypatch, ticker, info_data, expected_result, test_id):

    # Arrange
    dummy_ticker = DummyTicker(info_data=info_data, history_df=pd.DataFrame())
    def fake_ticker_constructor(t, session=None):
        assert t == ticker
        return dummy_ticker

    monkeypatch.setattr("eagle.tools.finance.yfinance.yf.Ticker", fake_ticker_constructor)
    wrapper = YFinanceAPIWrapper()

    # Act
    result = wrapper.get_stock_info(ticker)

    # Assert
    assert result == expected_result


@pytest.mark.parametrize(
    "info_data, expected_error_msg, test_id",
    [
        pytest.param(
            {},
            "No data found for ticker: INVALID",
            "edge-empty-info-dict",
            id="edge-empty-info-dict",
        ),
        pytest.param(
            None,
            "No data found for ticker: INVALID",
            "edge-none-info",
            id="edge-none-info",
        ),
    ],
)
def test_get_stock_info_edge_cases_no_data(monkeypatch, info_data, expected_error_msg, test_id):

    # Arrange
    dummy_ticker = DummyTicker(info_data=info_data, history_df=pd.DataFrame())
    def fake_ticker_constructor(t, session=None):
        assert t == "INVALID"
        return dummy_ticker

    monkeypatch.setattr("eagle.tools.finance.yfinance.yf.Ticker", fake_ticker_constructor)
    wrapper = YFinanceAPIWrapper()

    # Act
    result = wrapper.get_stock_info("INVALID")

    # Assert
    assert result == {"error": expected_error_msg}


def test_get_stock_info_uses_custom_session(monkeypatch):

    # Arrange
    dummy_session = object()
    captured_session = {"value": None}

    dummy_ticker = DummyTicker(info_data={"symbol": "TSLA"}, history_df=pd.DataFrame())

    def fake_ticker_constructor(t, session=None):
        captured_session["value"] = session
        return dummy_ticker

    monkeypatch.setattr("eagle.tools.finance.yfinance.yf.Ticker", fake_ticker_constructor)
    wrapper = YFinanceAPIWrapper()
    wrapper.load_custom_session(dummy_session)

    # Act
    result = wrapper.get_stock_info("TSLA")

    # Assert
    assert result == {"symbol": "TSLA"}
    assert captured_session["value"] is dummy_session


# -----------------------------
# Tests for get_stock_history
# -----------------------------


@pytest.mark.parametrize(
    "ticker, period, interval, history_df, test_id",
    [
        pytest.param(
            "AAPL",
            "1mo",
            "1d",
            pd.DataFrame({"Close": [150.0, 152.0], "Volume": [1000, 2000]}),
            "happy-history-aapl-1mo-1d",
            id="happy-history-aapl-1mo-1d",
        ),
        pytest.param(
            "MSFT",
            "5d",
            "1h",
            pd.DataFrame({"Close": [320.0, 321.5], "Volume": [500, 800]}),
            "happy-history-msft-5d-1h",
            id="happy-history-msft-5d-1h",
        ),
    ],
)
def test_get_stock_history_happy_paths(
    monkeypatch, ticker, period, interval, history_df, test_id
):

    # Arrange
    class HistoryTicker(DummyTicker):
        def history(self, period="1mo", interval="1d"):
            assert period == period_param
            assert interval == interval_param
            return history_df

    period_param = period
    interval_param = interval
    dummy_ticker = HistoryTicker(info_data={}, history_df=history_df)

    def fake_ticker_constructor(t, session=None):
        assert t == ticker
        return dummy_ticker

    monkeypatch.setattr("eagle.tools.finance.yfinance.yf.Ticker", fake_ticker_constructor)
    wrapper = YFinanceAPIWrapper()

    # Act
    result_df = wrapper.get_stock_history(ticker, period=period, interval=interval)

    # Assert
    pd.testing.assert_frame_equal(result_df, history_df)


@pytest.mark.parametrize(
    "history_df, test_id",
    [
        pytest.param(
            pd.DataFrame(),
            "edge-empty-history-dataframe",
            id="edge-empty-history-dataframe",
        ),
        pytest.param(
            pd.DataFrame({"Close": [], "Volume": []}),
            "edge-history-no-rows",
            id="edge-history-no-rows",
        ),
    ],
)
def test_get_stock_history_edge_cases(monkeypatch, history_df, test_id):

    # Arrange
    dummy_ticker = DummyTicker(info_data={}, history_df=history_df)

    def fake_ticker_constructor(t, session=None):
        assert t == "EDGE"
        return dummy_ticker

    monkeypatch.setattr("eagle.tools.finance.yfinance.yf.Ticker", fake_ticker_constructor)
    wrapper = YFinanceAPIWrapper()

    # Act
    result_df = wrapper.get_stock_history("EDGE", period="1d", interval="1m")

    # Assert
    pd.testing.assert_frame_equal(result_df, history_df)


def test_get_stock_history_uses_custom_session(monkeypatch):

    # Arrange
    dummy_session = object()
    captured_session = {"value": None}
    history_df = pd.DataFrame({"Close": [1.0], "Volume": [10]})

    dummy_ticker = DummyTicker(info_data={}, history_df=history_df)

    def fake_ticker_constructor(t, session=None):
        captured_session["value"] = session
        return dummy_ticker

    monkeypatch.setattr("eagle.tools.finance.yfinance.yf.Ticker", fake_ticker_constructor)
    wrapper = YFinanceAPIWrapper()
    wrapper.load_custom_session(dummy_session)

    # Act
    result_df = wrapper.get_stock_history("SESSION_TEST", period="1d", interval="1d")

    # Assert
    pd.testing.assert_frame_equal(result_df, history_df)
    assert captured_session["value"] is dummy_session

# -----------------------------
# Tests for YFinanceInput
# -----------------------------
# Happy path tests
# -----------------------------


@pytest.mark.parametrize(
    "ticker, period, interval",
    [
        pytest.param(
            "AAPL",
            "1mo",
            "1d",
            id="happy-aapl-default-like-period-interval",
        ),
        pytest.param(
            "MSFT",
            "1y",
            "1wk",
            id="happy-msft-one-year-weekly",
        ),
        pytest.param(
            "TSLA",
            "5d",
            "1h",
            id="happy-tsla-five-days-hourly",
        ),
    ],
)
def test_yfinance_input_happy_paths(ticker, period, interval):

    # Act
    model = YFinanceInput(ticker=ticker, period=period, interval=interval)

    # Assert
    assert model.ticker == ticker
    assert model.period == period
    assert model.interval == interval


def test_yfinance_input_uses_default_period_and_interval():

    # Act
    model = YFinanceInput(ticker="GOOG")

    # Assert
    assert model.ticker == "GOOG"
    assert model.period == "1mo"
    assert model.interval == "1d"


# -----------------------------
# Edge case tests
# -----------------------------


@pytest.mark.parametrize(
    "ticker, period, interval",
    [
        pytest.param(
            "BRK-A",
            "",
            "",
            id="edge-empty-period-and-interval",
        ),
        pytest.param(
            "",
            "1mo",
            "1d",
            id="edge-empty-ticker",
        ),
        pytest.param(
            "X" * 10,
            "Y" * 20,
            "Z" * 5,
            id="edge-long-arbitrary-strings",
        ),
        pytest.param(
            "usd=x",
            None,
            None,
            id="edge-forex-like-ticker-none-period-interval",
        ),
    ],
)
def test_yfinance_input_edge_cases(ticker, period, interval):

    # Arrange
    kwargs = {"ticker": ticker}
    if period is not None:
        kwargs["period"] = period
    if interval is not None:
        kwargs["interval"] = interval

    # Act
    model = YFinanceInput(**kwargs)

    # Assert
    assert model.ticker == ticker
    # If period/interval are omitted, defaults should be used
    if period is None:
        assert model.period == "1mo"
    else:
        assert model.period == period
    if interval is None:
        assert model.interval == "1d"
    else:
        assert model.interval == interval


# -----------------------------
# Error case tests
# -----------------------------


@pytest.mark.parametrize(
    "kwargs, expected_error_fragment, case_id",
    [
        pytest.param(
            {},
            "Field required",
            "error-missing-ticker",
            id="error-missing-ticker",
        ),
    ],
)
def test_yfinance_input_error_cases(kwargs, expected_error_fragment, case_id):

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        YFinanceInput(**kwargs)

    # Assert
    errors_text = str(exc_info.value)
    assert expected_error_fragment in errors_text
    
# -----------------------------
# Tests for YFinanceTool
# -----------------------------
class DummyAPIWrapper:
    """Dummy implementation of YFinanceAPIWrapper to control behavior in tests."""

    def __init__(self):
        self.history_calls = []
        self.info_calls = []
        self.raise_in_history = False
        self.history_result = pd.DataFrame({"Close": [1.0, 2.0], "Volume": [10, 20]})
        self.info_result = {"symbol": "DUMMY", "price": 123}

    def get_stock_history(self, ticker: str, period: str, interval: str) -> pd.DataFrame:
        self.history_calls.append({"ticker": ticker, "period": period, "interval": interval})
        if self.raise_in_history:
            raise RuntimeError("history error")
        return self.history_result

    def get_stock_info(self, ticker: str):
        self.info_calls.append({"ticker": ticker})
        return self.info_result


@pytest.fixture
def api_wrapper():
    # Arrange
    return DummyAPIWrapper()


@pytest.fixture
def tool(api_wrapper, monkeypatch):
    # Arrange
    # Patch the default factory so that BaseTool / Pydantic construction never tries
    # to instantiate a real YFinanceAPIWrapper.
    monkeypatch.setattr(
        "eagle.tools.finance.yfinance.YFinanceAPIWrapper",
        lambda *args, **kwargs: api_wrapper,
    )

    # Act
    t = YFinanceTool()
    # Overwrite api_wrapper explicitly to our dummy (in case base class reassigns)
    t.api_wrapper = api_wrapper

    # Assert
    assert isinstance(t.api_wrapper, DummyAPIWrapper)
    return t


# -----------------------------
# Happy path tests
# -----------------------------


@pytest.mark.parametrize(
    "ticker, period, interval",
    [
        pytest.param(
            "AAPL",
            "1mo",
            "1d",
            id="happy-aapl-1mo-1d",
        ),
        pytest.param(
            "MSFT",
            "1y",
            "1wk",
            id="happy-msft-1y-1wk",
        ),
        pytest.param(
            "TSLA",
            "5d",
            "1h",
            id="happy-tsla-5d-1h",
        ),
    ],
)
def test_yfinance_tool_run_happy_paths(tool, api_wrapper, ticker, period, interval):

    # Act
    result = tool._run(ticker=ticker, period=period, interval=interval)

    # Assert
    assert isinstance(result, pd.DataFrame)
    pd.testing.assert_frame_equal(result, api_wrapper.history_result)
    assert api_wrapper.history_calls == [{"ticker": ticker, "period": period, "interval": interval}]
    # Default action is "history", so info should not be called
    assert api_wrapper.info_calls == []


def test_yfinance_tool_run_uses_input_defaults(tool, api_wrapper):

    # Act
    result = tool._run(ticker="GOOG")

    # Assert
    assert isinstance(result, pd.DataFrame)
    pd.testing.assert_frame_equal(result, api_wrapper.history_result)
    # Should use default period="1mo" and interval="1d"
    assert api_wrapper.history_calls == [
        {"ticker": "GOOG", "period": "1mo", "interval": "1d"}
    ]


# -----------------------------
# Edge case tests
# -----------------------------


@pytest.mark.parametrize(
    "ticker, period, interval",
    [
        pytest.param(
            "",
            "1mo",
            "1d",
            id="edge-empty-ticker",
        ),
        pytest.param(
            "BRK-A",
            "",
            "",
            id="edge-empty-period-interval",
        ),
        pytest.param(
            "usd=x",
            None,
            None,
            id="edge-none-period-interval",
        ),
    ],
)
def test_yfinance_tool_run_edge_cases(tool, api_wrapper, ticker, period, interval):

    # Arrange
    kwargs = {"ticker": ticker}
    if period is not None:
        kwargs["period"] = period
    if interval is not None:
        kwargs["interval"] = interval

    # Act
    result = tool._run(**kwargs)

    # Assert
    assert isinstance(result, pd.DataFrame)
    pd.testing.assert_frame_equal(result, api_wrapper.history_result)

    # Determine expected period/interval considering defaults
    expected_period = period if period is not None else "1mo"
    expected_interval = interval if interval is not None else "1d"
    assert api_wrapper.history_calls == [
        {"ticker": ticker, "period": expected_period, "interval": expected_interval}
    ]


# -----------------------------
# Error case tests
# -----------------------------


@pytest.mark.parametrize(
    "output_evaluator, should_wrap, expected_message, case_id",
    [
        pytest.param(
            None,
            False,
            "history error",
            "error-history-raises-runtime-no-evaluator",
            id="error-history-raises-runtime-no-evaluator",
        ),
        pytest.param(
            lambda exc, inputs: {"error": str(exc), "inputs": inputs},
            True,
            "history error",
            "error-history-raises-with-evaluator",
            id="error-history-raises-with-evaluator",
        ),
    ],
)
def test_yfinance_tool_run_history_error_handling(
    monkeypatch,
    api_wrapper,
    output_evaluator,
    should_wrap,
    expected_message,
    case_id,
):

    # Arrange
    monkeypatch.setattr(
        "eagle.tools.finance.yfinance.YFinanceAPIWrapper",
        lambda *args, **kwargs: api_wrapper,
    )
    tool = YFinanceTool(output_evaluation_callable=output_evaluator)
    tool.api_wrapper = api_wrapper
    api_wrapper.raise_in_history = True

    # Act
    result = tool._run(ticker="ERR", period="1mo", interval="1d")

    # Assert
    if should_wrap:
        assert isinstance(result, dict)
        assert expected_message in result["error"]
        assert result["inputs"]["ticker"] == "ERR"
    else:
        # No evaluator: _run should return the raw exception object (no raise)
        assert isinstance(result, RuntimeError)
        assert expected_message in str(result)


def test_yfinance_tool_arun_not_implemented(tool):

    # Act / Assert
    with pytest.raises(NotImplementedError) as exc_info:
        tool._arun()

    # Assert
    assert "does not support async operations" in str(exc_info.value)


def test_yfinance_tool_name_description_and_schema(monkeypatch, api_wrapper):

    # Arrange
    monkeypatch.setattr(
        "eagle.tools.finance.yfinance.YFinanceAPIWrapper",
        lambda *args, **kwargs: api_wrapper,
    )
    tool = YFinanceTool()

    # Act
    tool_name = tool.name
    desc = tool.description
    schema = tool.args_schema

    # Assert
    assert tool_name == "yahoo_finance"
    assert "Yahoo Finance" in desc
    assert schema is YFinanceInput