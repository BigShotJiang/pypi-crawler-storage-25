import pytest
import pandas as pd
from pydantic import ValidationError

from eagle.tools.pandas_handling.pandas_dataframe_query import (
    PandasDataFrameQuery,
    PandasDataFrameQueryInput,
)

@pytest.mark.parametrize(
    "df_id, query",
    [
        pytest.param(
            "orders_df",
            "amount > 100",
            id="happy-orders-amount-greater-than-100",
        ),
        pytest.param(
            "users_df",
            "age >= 18 and country == 'US'",
            id="happy-users-adults-in-us",
        ),
        pytest.param(
            "transactions_2023",
            "status == 'completed'",
            id="happy-transactions-completed-status",
        ),
    ],
)
def test_pandas_dataframe_query_input_happy_paths(df_id, query):

    # Act
    model = PandasDataFrameQueryInput(df_id=df_id, query=query)

    # Assert
    assert model.df_id == df_id
    assert model.query == query


@pytest.mark.parametrize(
    "df_id, query",
    [
        pytest.param(
            "df_123",
            "",
            id="edge-empty-query-string",
        ),
        pytest.param(
            "",
            "col > 0",
            id="edge-empty-df-id",
        ),
        pytest.param(
            "x" * 1024,
            "value < 10",
            id="edge-long-df-id",
        ),
        pytest.param(
            "metrics_df",
            " " * 256,
            id="edge-whitespace-only-query",
        ),
    ],
)
def test_pandas_dataframe_query_input_edge_cases(df_id, query):

    # Act
    model = PandasDataFrameQueryInput(df_id=df_id, query=query)

    # Assert
    assert model.df_id == df_id
    assert model.query == query


@pytest.mark.parametrize(
    "kwargs, expected_error_fragment, case_id",
    [
        pytest.param(
            {"query": "col > 0"},
            "Field required",
            "error-missing-df-id",
            id="error-missing-df-id",
        ),
        pytest.param(
            {"df_id": "df_missing_query"},
            "Field required",
            "error-missing-query",
            id="error-missing-query",
        ),
        pytest.param(
            {},
            "Field required",
            "error-missing-both-fields",
            id="error-missing-both-fields",
        ),
    ],
)
def test_pandas_dataframe_query_input_error_cases(kwargs, expected_error_fragment, case_id):

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        PandasDataFrameQueryInput(**kwargs)

    # Assert
    errors_text = str(exc_info.value)
    assert expected_error_fragment in errors_text

