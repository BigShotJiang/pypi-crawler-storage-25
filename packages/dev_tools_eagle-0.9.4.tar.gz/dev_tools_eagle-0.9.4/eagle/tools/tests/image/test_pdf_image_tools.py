import pytest
from pydantic import ValidationError

from eagle.tools.image.pdf_image_tools import (
    PdfPageToImageTool,
    PdfPageToImageInput,
)

from eagle.memory.shared.shared_objects_memory import SharedObjectsMemory
from langchain_core.language_models.chat_models import BaseChatModel

# -----------------------------
# Tests to PdfPageToImageInput
# -----------------------------
# Happy path tests
# -----------------------------


@pytest.mark.parametrize(
    "pdf_id, page_number, context_about_the_image, crop_context",
    [
        pytest.param(
            "invoice_2024_01",
            1,
            "First page of the January 2024 invoice.",
            "Focus on the header and totals.",
            id="happy-first-page-invoice-with-context-and-crop",
        ),
        pytest.param(
            "research_paper_abc",
            5,
            "Page with key experimental results.",
            "",
            id="happy-middle-page-with-context-no-crop",
        ),
        pytest.param(
            "slides_deck_xyz",
            10,
            "",
            "Crop to the central slide area.",
            id="happy-page-with-crop-no-context",
        ),
    ],
)
def test_pdf_page_to_image_input_happy_paths(
    pdf_id, page_number, context_about_the_image, crop_context
):

    # Act
    model = PdfPageToImageInput(
        pdf_id=pdf_id,
        page_number=page_number,
        context_about_the_image=context_about_the_image,
        crop_context=crop_context,
    )

    # Assert
    assert model.pdf_id == pdf_id
    assert model.page_number == page_number
    assert model.context_about_the_image == context_about_the_image
    assert model.crop_context == crop_context


def test_pdf_page_to_image_input_uses_default_optional_fields():

    # Act
    model = PdfPageToImageInput(pdf_id="default_pdf", page_number=2)

    # Assert
    assert model.pdf_id == "default_pdf"
    assert model.page_number == 2
    assert model.context_about_the_image == ""
    assert model.crop_context == ""


# -----------------------------
# Edge case tests
# -----------------------------


@pytest.mark.parametrize(
    "pdf_id, page_number, context_about_the_image, crop_context",
    [
        pytest.param(
            "a",
            1,
            "",
            "",
            id="edge-minimal-pdf-id-and-page-one-empty-contexts",
        ),
        pytest.param(
            "x" * 256,
            9999,
            "y" * 512,
            "z" * 512,
            id="edge-long-strings-and-large-page-number",
        ),
        pytest.param(
            "",
            1,
            "",
            "",
            id="edge-empty-pdf-id-allowed",
        ),
        pytest.param(
            "negative-page-pdf",
            -1,
            "",
            "",
            id="edge-negative-page-number-allowed",
        ),
    ],
)
def test_pdf_page_to_image_input_edge_cases(
    pdf_id, page_number, context_about_the_image, crop_context
):

    # Act
    model = PdfPageToImageInput(
        pdf_id=pdf_id,
        page_number=page_number,
        context_about_the_image=context_about_the_image,
        crop_context=crop_context,
    )

    # Assert
    assert model.pdf_id == pdf_id
    assert model.page_number == page_number
    assert model.context_about_the_image == context_about_the_image
    assert model.crop_context == crop_context


# -----------------------------
# Error case tests
# -----------------------------


@pytest.mark.parametrize(
    "kwargs, expected_error_fragment, case_id",
    [
        pytest.param(
            {
                # Missing pdf_id
                "page_number": 1,
                "context_about_the_image": "",
                "crop_context": "",
            },
            "Field required",
            "error-missing-pdf-id",
            id="error-missing-pdf-id",
        ),
        pytest.param(
            {
                "pdf_id": "missing_page_number_pdf",
                # Missing page_number
                "context_about_the_image": "",
                "crop_context": "",
            },
            "Field required",
            "error-missing-page-number",
            id="error-missing-page-number",
        ),
        pytest.param(
            {
                # Missing both required fields
                "context_about_the_image": "",
                "crop_context": "",
            },
            "Field required",
            "error-missing-pdf-id-and-page-number",
            id="error-missing-pdf-id-and-page-number",
        ),
    ],
)
def test_pdf_page_to_image_input_error_cases(kwargs, expected_error_fragment, case_id):

    # Act / Assert
    with pytest.raises(ValidationError) as exc_info:
        PdfPageToImageInput(**kwargs)

    # Assert
    errors_text = str(exc_info.value)
    assert expected_error_fragment in errors_text

