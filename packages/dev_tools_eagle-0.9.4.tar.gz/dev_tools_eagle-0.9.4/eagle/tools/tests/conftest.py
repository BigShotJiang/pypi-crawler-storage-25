import sys
import types
import enum

# If the new namespace langchain_core exists, don't do anything (let it use the real implementation)
try:
    import langchain_core  # noqa: F401
    HAS_LANGCHAIN_CORE = True
except Exception:
    HAS_LANGCHAIN_CORE = False


def _ensure_module(name: str) -> types.ModuleType:
    """Create a empty module in sys.modules if it doesn't exist, and return it."""
    if name in sys.modules:
        return sys.modules[name]
    module = types.ModuleType(name)
    sys.modules[name] = module
    return module

# Create a mock for the module tree langchain.chains.query_constructor
langchain_mod = _ensure_module("langchain")
chains_mod = _ensure_module("langchain.chains")
qc_mod = _ensure_module("langchain.chains.query_constructor")
ir_mod = _ensure_module("langchain.chains.query_constructor.ir")
base_mod = _ensure_module("langchain.chains.query_constructor.base")
schema_mod = _ensure_module("langchain.chains.query_constructor.schema")

# Only define stubs if they haven't been defined yet
# Only define stubs if they haven't been defined yet
if not hasattr(ir_mod, "Comparator"):
    # Definimos enums simples, apenas para que tuple(Comparator) funcione.
    class _Comparator(str, enum.Enum):
        EQ = "eq"
        NE = "ne"
        GT = "gt"
        GTE = "gte"
        LT = "lt"
        LTE = "lte"
        LIKE = "like"
        CONTAIN = "contain"

    class _Operator(str, enum.Enum):
        AND = "and"
        OR = "or"
        NOT = "not"

    class _Comparison:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            # atributos usados em OpenSearchTranslatorModified
            self.attribute = kwargs.get("attribute", "")
            self.comparator = kwargs.get("comparator", _Comparator.EQ)
            self.value = kwargs.get("value", None)

    class _StructuredQuery:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

    ir_mod.Comparator = _Comparator
    ir_mod.Operator = _Operator
    ir_mod.Comparison = _Comparison
    ir_mod.StructuredQuery = _StructuredQuery

# AttributeInfo aparece em `base` e em `schema` em código legado; vamos expor
# a mesma classe em ambos os módulos.
if not hasattr(base_mod, "AttributeInfo") or not hasattr(schema_mod, "AttributeInfo"):
    class _AttributeInfo:
        def __init__(self, name: str = "", description: str = "", type: str = "string", **kwargs):
            self.name = name
            self.description = description
            self.type = type
            self.extra = kwargs

    base_mod.AttributeInfo = _AttributeInfo
    schema_mod.AttributeInfo = _AttributeInfo

# Também há código que importa StructuredQueryOutputParser de
# langchain.chains.query_constructor.base; criamos um stub mínimo aqui.
if not hasattr(base_mod, "StructuredQueryOutputParser"):
    class _StructuredQueryOutputParser:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def parse(self, *args, **kwargs):
            # implementação fake só para satisfazer chamadas; ajuste se precisar
            return {"parsed": True, "args": args, "kwargs": kwargs}

    base_mod.StructuredQueryOutputParser = _StructuredQueryOutputParser