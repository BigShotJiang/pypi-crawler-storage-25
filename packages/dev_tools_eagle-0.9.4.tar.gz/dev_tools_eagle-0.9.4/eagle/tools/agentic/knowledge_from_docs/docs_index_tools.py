from typing import Optional, List, Dict, Any, Type, Callable
from pydantic import BaseModel, Field
from langchain_core.tools import BaseTool
from pathlib import Path

from eagle.ingestors.docs_index.strategy import DocsIndexStrategy
from eagle.stores.document_storage.base import DocumentStorage, DocumentStorageSearchQuery


def example_markdown_link_formatter(response: Dict[str, Any]) -> str:
    """
    Example response processor that formats the QA output with Markdown links integrated into the text.
    Replaces numeric references like [1], [2] in the qa_output.answer with Markdown links using enriched references.
    Assumes [1] corresponds to the first reference in qa_output.references, etc.
    This is a sample implementation; customize as needed for your use case.
    """
    qa_output = response.get("qa_output")
    
    text = qa_output.get('answer', '')
    references = qa_output.get('references', {})
    
    # Replace numeric references [1], [2], etc., with Markdown links using references
    for i, ref in references.items(): 
        path = ref.get('path', '')
        page_range = ref.get('page_range', [])
        if path:
            link_text = f"Arquivo: {Path(path).name}"
            if page_range:
                link_text += f" (páginas: {', '.join(map(str, [p + 1 for p in page_range]))})"
            url = f"file://{path}"  # URL pointing to the original file path
            text = text.replace(f"[{i}]", f"[{link_text}]({url})")
    
    return text


class DocsIndexAskToolInput(BaseModel):
    question: str = Field(description="The question to ask the DocsIndexStrategy.")


class DocsIndexAskTool(BaseTool):
    name: str = "docs_index_ask_tool"
    description: str = "Uma ferramenta para fazer perguntas usando o DocsIndexStrategy para recuperação de documentos e Q&A."
    args_schema: Type[BaseModel] = DocsIndexAskToolInput
    docs_index_strategy: DocsIndexStrategy
    storage: DocumentStorage
    file_ids: List[str]
    query: Optional[DocumentStorageSearchQuery]
    limit_vector: int
    limit_tags: int
    multimodal: bool

    prompt_language: str

    response_processor: Optional[Callable[[Dict[str, Any]], str]]
    async def _arun(self, **kwargs) -> Dict[str, Any]:
        inputs = DocsIndexAskToolInput(**kwargs)
        
        # Combine file_ids from direct list and search query
        combined_file_ids = list(self.file_ids)  # Start with the direct file_ids
        if self.query:
            results = await self.storage.asearch(self.query)
            additional_file_ids = [metadata.get("file_id") for metadata, _ in results if metadata.get("file_id")]
            combined_file_ids.extend(additional_file_ids)
        # Remove duplicates
        combined_file_ids = list(set(combined_file_ids))
        
        result = await self.docs_index_strategy.ask(
            question=inputs.question,
            file_ids=combined_file_ids,
            limit_vector=self.limit_vector,
            limit_tags=self.limit_tags,
            multimodal=self.multimodal,
        )
        if self.response_processor:
            response = self.response_processor(result)
        else:
            response = result["qa_output"]["answer"]
        return response
    
    def _run(self, **kwargs) -> Dict[str, Any]:
        """
        Synchronous version of _arun. Runs the async method in a new event loop.
        """
        import asyncio
        return asyncio.run(self._arun(**kwargs))