from typing import Optional, List, Dict, Any, Type, Union, Callable, Tuple
from pydantic import BaseModel, Field
from langchain_core.tools import BaseTool
from langchain_core.language_models.chat_models  import BaseChatModel
import pandas as pd
from eagle.memory.shared.shared_objects_memory import SharedObjectsMemory
from eagle.agents.definitions.base import BasicAgent
from eagle.chat_schemas.base import BasicChatSchema
from eagle.chains.summarization import create_summarization_chain

class DataFrameAnalysisToolInput(BaseModel):
    analysis_demands: str = Field(description="List of important guidelines for the analysis.")
    dataframe_shared_object_id: str = Field(description="The alphanumeric 'id' (NOT THE NAME) of the dataframe object to analyze.")

class DataFrameAnalysisTool(BaseTool):
    # Tools properties
    name: str = "dataframe_analysis_tool"
    description: str = (
        "A tool designed to analyze ALL rows of a DataFrame, leaving none unanalyzed, "
        "and providing detailed comments for each decision made."
    )
    args_schema: Type[BaseModel] = DataFrameAnalysisToolInput
    agent_or_team_and_configs_for_analysis_factory: Callable[..., Union[Tuple[BasicAgent, Dict], Tuple[BasicChatSchema, Dict]]]
    agent_or_team_and_configs_for_summarization_factory: Callable[..., Union[Tuple[BasicAgent, Dict], Tuple[BasicChatSchema, Dict]]]

    max_rows_per_call: int

    not_a_dataframe_error_response_by_prompt_language: dict = {
        "en": "The object for this 'dataframe_shared_object_id' is not a DataFrame.",
        "pt-br": "O objeto referente a este 'dataframe_shared_object_id' não é um DataFrame."
    }

    shared_object_not_found_error_response_by_prompt_language: dict = {
        "en": "DataFrame not found by this 'dataframe_shared_object_id'.",
        "pt-br": "DataFrame não encontrado para este 'dataframe_shared_object_id'."
    }

    # Agents properties
    prompt_language: str
    chat_id: str
    shared_objects_memory: SharedObjectsMemory
    agent_configs_by_prompt_language: dict = {
        "en": {
            "name": "Dataframe Analyst",
            "description": "An agent specialized in analyzing dataframe rows, making decisions on whether to maintain or delete each row, and proposing new columns based on the analysis.",
        },
        "pt-br": {
            "name": "Analista de Dataframe",
            "description": "Um agente especializado em analisar linhas de dataframe, tomando decisões sobre manter ou excluir cada linha, e propondo novas colunas com base na análise.",
        }
    }
    
    fixed_instruction: dict = {
        "en": "If you have nothing to say about these rows, return an empty string ''.",
        "pt-br": "Se você não tiver nada a dizer sobre essas linhas, retorne uma string vazia ''."
    }

    fixed_moderation_instruction: dict = {
        "en": "Remember to pass on to the agents the data you see from the table whose analysis is demanded, because they don't have direct access to it.",
        "pt-br": "Lembre-se de repassar aos agentes os dados que você vê da tabela cuja análise é demandada, porque eles não têm acesso direto a ela."
    }
    
    analysis_range_instruction: dict = {
        "en": "Analyzing rows from {start} to {end}.",
        "pt-br": "Analisando linhas de {start} a {end}."
    }
    
    comment_format: dict = {
        "en": "From line {start} to line {end}:\n{response}\n",
        "pt-br": "Da linha {start} à linha {end}:\n{response}\n"
    }
    
    summarization_demands: dict = {
        "en": """
A detailed analysis of a dataframe was demanded, where various comments were generated for each analyzed section.
```Demands
{analysis_demands}
```
```Generated comments
{comments}
```
Now, answer the demands definitively.
""",
        "pt-br": """Foi demandada uma análise detalhada de um dataframe, onde diversos comentários foram gerados para cada trecho analisado.
```Demanda
{analysis_demands}
```
```Comentários gerados
{comments}
```
Agora, responda as demandas de modo definitivo.
"""
    }
    
    def _run(self, **_inputs: DataFrameAnalysisToolInput) -> Dict[str, Any]:
        """
        Run the tool synchronously.

        Args:
            inputs (DataFrameAnalysisToolInput): Input object containing the configuration for the analysis.

        Returns:
            Dict[str, Any]: The analysis results including decisions and comments for each row.
        """
        # Extract arguments from inputs
        inputs = DataFrameAnalysisToolInput(**_inputs)

        # Checking dataframe shape from shared objects memory
        shared_object = self.shared_objects_memory.get_memory_object(
            chat_id=self.chat_id,
            object_id=inputs.dataframe_shared_object_id
        )

        if shared_object is None:
            return self.shared_object_not_found_error_response_by_prompt_language[self.prompt_language]
        if not isinstance(shared_object.object, pd.DataFrame):
            return self.not_a_dataframe_error_response_by_prompt_language[self.prompt_language]

        df = shared_object.object

        # Divide df rows based on self.max_rows_per_call
        df_length = len(df)

        def analyze_chunk(sub_df, demands, factory):
            agent, config = factory()
            sub_df_str = sub_df.to_string()
            key = "messages" if isinstance(agent, BasicAgent) else "messages_with_requester"
            if key == "messages_with_requester":
                demands = demands + "\n\n" + self.fixed_moderation_instruction[self.prompt_language]
            state = {key: [{"role": "user", "content": demands + "\n\nDataFrame:\n" + sub_df_str}]}
            agent.run(state, config=config)
            messages = agent.state_snapshot.values.get(key, [])
            if messages:
                response = messages[-1].content
            else:
                response = ""
            return response

        responses = []
        for start_idx in range(0, df_length, self.max_rows_per_call):
            end_idx = min(start_idx + self.max_rows_per_call, df_length)
            idx_to_analyse = list(range(start_idx, end_idx))
            sub_df = df.iloc[idx_to_analyse]
            full_demands = inputs.analysis_demands + "\n" + self.analysis_range_instruction[self.prompt_language].format(start=start_idx, end=end_idx-1) + "\n" + self.fixed_instruction[self.prompt_language]
            response = analyze_chunk(sub_df, full_demands, self.agent_or_team_and_configs_for_analysis_factory)
            responses.append((start_idx, end_idx-1, response))
        
        non_empty_responses = [(start, end, r) for start, end, r in responses if r.strip()]
        summarization_demands = self.summarization_demands[self.prompt_language]
        agent_sum, config_sum = self.agent_or_team_and_configs_for_summarization_factory()
        key_sum = "messages" if isinstance(agent_sum, BasicAgent) else "messages_with_requester"
        comments = "\n\n".join(self.comment_format[self.prompt_language].format(start=start, end=end, response=r) for start, end, r in non_empty_responses)
        state_sum = {key_sum: [{"role": "user", "content": summarization_demands.format(analysis_demands=inputs.analysis_demands, comments=comments)}]}
        agent_sum.run(state_sum, config=config_sum)
        final_messages = agent_sum.state_snapshot.values.get(key_sum, [])
        if final_messages:
            summary = final_messages[-1].content
        else:
            summary = ""
        return summary
        