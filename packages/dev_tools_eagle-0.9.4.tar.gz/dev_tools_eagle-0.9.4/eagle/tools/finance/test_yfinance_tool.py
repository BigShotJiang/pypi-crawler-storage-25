import pytest
from eagle.tools.finance.yfinance import YFinanceTool, YFinanceAPIWrapper

def test_yfinance_tool_info(yfinance_session):
    pytest.skip("Skipping test_yfinance_tool_info due to yfinance info 401 error.")
    # Initialize the API wrapper with the session
    api_wrapper = YFinanceAPIWrapper(
        session=yfinance_session  # Pass the session to the API wrapper

    )

    # Initialize the tool
    tool = YFinanceTool(
        api_wrapper=api_wrapper,  # Pass the API wrapper to the tool
    )

    # Define the input for fetching stock info
    input_data = {
        "ticker": "AAPL",
        "action": "info"
    }

    # Run the tool synchronously
    result = tool._run(**input_data)

    # Verify the result contains expected keys
    assert "symbol" in result
    assert result["symbol"] == "AAPL"
    assert "longName" in result

def test_yfinance_tool_history(yfinance_session):

    # Initialize the API wrapper with the session
    api_wrapper = YFinanceAPIWrapper(
        session=yfinance_session  # Pass the session to the API wrapper

    )

    # Initialize the tool
    tool = YFinanceTool(
        api_wrapper=api_wrapper,  # Pass the API wrapper to the tool
    )

    # Define the input for fetching historical data
    input_data = {
        "ticker": "AAPL",
        "action": "history",
        "period": "1mo",
        "interval": "1d"
    }

    # Run the tool synchronously
    result = tool._run(**input_data)

    # Verify the result is a DataFrame with expected columns
    assert not result.empty
    assert "Open" in result.columns
    assert "Close" in result.columns

@pytest.mark.asyncio
async def test_yfinance_tool_async_not_implemented(yfinance_session):
   
   # Initialize the API wrapper with the session
    api_wrapper = YFinanceAPIWrapper(
        session=yfinance_session  # Pass the session to the API wrapper

    )

    # Initialize the tool
    tool = YFinanceTool(
        api_wrapper=api_wrapper,  # Pass the API wrapper to the tool
    )

    # Verify that async run raises NotImplementedError
    with pytest.raises(NotImplementedError):
        await tool._arun()
