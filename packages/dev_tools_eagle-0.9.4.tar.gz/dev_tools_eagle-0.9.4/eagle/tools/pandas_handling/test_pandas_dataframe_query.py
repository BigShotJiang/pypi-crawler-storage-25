import pytest
import pandas as pd
from eagle.tools.pandas_handling.pandas_dataframe_query import PandasDataFrameQuery
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


def test_pandas_dataframe_query(shared_objects_memory):
    # Initialize shared memory and tool
    memory = shared_objects_memory
    chat_id = "test-chat-pandas-query"
    tool = PandasDataFrameQuery(memory=memory, chat_id=chat_id)

    # Create a DataFrame and store it in shared memory
    df = pd.DataFrame({"col1": [1, 2, 3], "col2": ["A", "B", "C"]})
    object_id = memory.put_memory(
        chat_id=chat_id,
        object_name="test_dataframe",
        obj=df,
        description="A test DataFrame",
        object_type="DataFrame"
    )

    # Define the query input
    query_input = {
        "df_id": object_id,
        "query": "col1 > 1"
    }

    # Run the tool synchronously
    result = tool._run(**query_input)

    # Verify the result
    assert "col1 col2" in result["result"]
    assert "2    B" in result["result"]
    assert "3    C" in result["result"]
    assert "1    A" not in result["result"]

@pytest.mark.asyncio
async def test_pandas_dataframe_query_async(shared_objects_memory):
    # Initialize shared memory and tool
    memory = shared_objects_memory
    chat_id = "test-chat-pandas-query-async"
    tool = PandasDataFrameQuery(memory=memory, chat_id=chat_id)

    # Create a DataFrame and store it in shared memory
    df = pd.DataFrame({"col1": [1, 2, 3], "col2": ["A", "B", "C"]})
    object_id = await memory.aput_memory(
        chat_id=chat_id,
        object_name="test_dataframe",
        obj=df,
        description="A test DataFrame",
        object_type="DataFrame"
    )

    # Define the query input
    query_input = {
        "df_id": object_id,
        "query": "col1 > 1"
    }

    # Run the tool asynchronously
    result = await tool._arun(**query_input)

    # Verify the result
    assert "col1 col2" in result["result"]
    assert "2    B" in result["result"]
    assert "3    C" in result["result"]
    assert "1    A" not in result["result"]
