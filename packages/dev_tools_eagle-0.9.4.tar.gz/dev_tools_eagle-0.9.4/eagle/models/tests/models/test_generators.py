import importlib
import types
import pytest
import sys


@pytest.fixture()
def module_under_test(monkeypatch):
    """
    Importa o módulo real com os imports externos mockados ANTES do import,
    para não depender de Azure/credenciais/Config real.
    """

    fake_langchain_openai = types.ModuleType("langchain_openai")
    fake_langchain_openai_embeddings = types.ModuleType("langchain_openai.embeddings")

    class FakeAzureChatOpenAI:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class FakeAzureOpenAIEmbeddings:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self._embedded_texts = None

        def embed_documents(self, texts):
            self._embedded_texts = list(texts)
            return [[float(i)] for i, _ in enumerate(texts)]

    fake_langchain_openai.AzureChatOpenAI = FakeAzureChatOpenAI
    fake_langchain_openai_embeddings.AzureOpenAIEmbeddings = FakeAzureOpenAIEmbeddings


    monkeypatch.setitem(sys.modules, "langchain_openai", fake_langchain_openai)
    monkeypatch.setitem(sys.modules, "langchain_openai.embeddings", fake_langchain_openai_embeddings)

    fake_config_mod = types.ModuleType("eagle.models.config")

    class FakeConfig:
        def __init__(self):
            self.loaded = True

    fake_config_mod.Config = FakeConfig
    monkeypatch.setitem(sys.modules, "eagle.models.config", fake_config_mod)

    import eagle.models.generators as m  

    m = importlib.reload(m)
    return m

def test_get_llm_model_valid_returns_azure_chat(module_under_test):
    m = module_under_test

    model = "gpt-4o"
    llm = m.get_llm_model(model_name=model, temperature=0.7, max_response_tokens=123)

    assert llm.__class__.__name__ == "FakeAzureChatOpenAI"
    assert llm.kwargs["azure_deployment"] == model
    assert llm.kwargs["model"] == model
    assert llm.kwargs["temperature"] == 0.7
    assert llm.kwargs["max_tokens"] == 123


def test_get_llm_model_invalid_raises(module_under_test):
    m = module_under_test
    with pytest.raises(ValueError) as e:
        m.get_llm_model("nao-existe")
    assert "Model name must be one of" in str(e.value)


def test_get_vision_model_valid_returns_azure_chat(module_under_test):
    m = module_under_test

    model = "gpt-4o"  
    llm = m.get_vision_model(model_name=model, temperature=0.2, max_response_tokens=999)

    assert llm.__class__.__name__ == "FakeAzureChatOpenAI"
    assert llm.kwargs["azure_deployment"] == model
    assert llm.kwargs["model"] == model
    assert llm.kwargs["temperature"] == 0.2
    assert llm.kwargs["max_tokens"] == 999


def test_get_vision_model_invalid_raises(module_under_test):
    m = module_under_test
    with pytest.raises(ValueError):
        m.get_vision_model("mistral-7b-instruct") 


def test_get_embedding_model_valid_returns_embeddings(module_under_test):
    m = module_under_test

    model = "text-embedding-3-small"
    emb = m.get_embedding_model(model)

    assert emb.__class__.__name__ == "FakeAzureOpenAIEmbeddings"
    assert emb.kwargs["azure_deployment"] == model
    assert emb.kwargs["model"] == model


def test_get_embedding_model_invalid_raises(module_under_test):
    m = module_under_test
    with pytest.raises(ValueError):
        m.get_embedding_model("embedding-xyz")


def test_get_embedding_model_dims_valid(module_under_test):
    m = module_under_test
    assert m.get_embedding_model_dims("text-embedding-3-large") == 2048
    assert m.get_embedding_model_dims("text-embedding-3-small") == 1536


def test_get_embedding_model_dims_invalid_raises(module_under_test):
    m = module_under_test
    with pytest.raises(ValueError):
        m.get_embedding_model_dims("embedding-xyz")

def test_embed_texts_generator_calls_embed_documents(module_under_test, monkeypatch):
    m = module_under_test

    created = {"count": 0, "last_model": None}

    real_get_embedding_model = m.get_embedding_model

    def spy_get_embedding_model(model_name):
        created["count"] += 1
        created["last_model"] = model_name
        return real_get_embedding_model(model_name)

    monkeypatch.setattr(m, "get_embedding_model", spy_get_embedding_model)

    fn = m.embed_texts_generator("text-embedding-3-small")

    out = fn(["a", "b", "c"])
    assert created["count"] == 1
    assert created["last_model"] == "text-embedding-3-small"

    assert out == [[0.0], [1.0], [2.0]]
