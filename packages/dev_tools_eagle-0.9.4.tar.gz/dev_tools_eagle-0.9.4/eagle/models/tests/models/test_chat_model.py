from typing import List, Optional
from pydantic import Field
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage
from langchain_core.outputs import ChatGeneration, ChatResult


class FakeChatModel(BaseChatModel):
    responses: List[str] = Field(default_factory=list)
    _idx: int = 0

    @property
    def _llm_type(self) -> str:
        return "fake-chat-model"

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager=None,
        **kwargs,
    ) -> ChatResult:

        if self.responses and self._idx < len(self.responses):
            content = self.responses[self._idx]
            self._idx += 1

        else:
            prompt_text = messages[-1].content.lower()

            if "plano" in prompt_text and "pergunta" in prompt_text:
                content = """
                {
                  "pergunta": "Como agir em caso de incêndio?",
                  "plano": "Evacuar o prédio imediatamente."
                }
                """

            elif "resposta" in prompt_text and "fontes" in prompt_text:
                content = """
                {
                  "resposta": "Desligue a energia e utilize extintor apropriado.",
                  "fontes": ["Plano de Emergência", "Procedimento de Evacuação"]
                }
                """

            else:
                content = """
                {
                  "question": "What to do in case of fire?",
                  "plan": "Evacuate the building."
                }
                """

        message = AIMessage(content=content)
        generation = ChatGeneration(message=message)

        return ChatResult(generations=[generation])
