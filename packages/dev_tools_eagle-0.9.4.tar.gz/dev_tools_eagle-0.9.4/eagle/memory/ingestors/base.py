from eagle.memory.base import StoredMemory
from langchain.chains.query_constructor.base import AttributeInfo


class IngestorMemory(StoredMemory):
	"""Base class for ingestor memories using a persistent vector store."""

	MEMORY_NAME = "eagle-ingestor-memory"

	EMBEDDED_FIELDS = ["description"]

	VALUE_EXAMPLE = {
		"description": "Example description",
		"type": "ingestor_memory",
	}

	ATTRIBUTE_INFO = [
		AttributeInfo(name="value.description", type="string", description="Description of the memory"),
		AttributeInfo(name="value.type", type="string", description="Type of the memory"),
	]


__all__ = ["IngestorMemory"]