from typing import Any, Dict, Iterable, List, Optional, Tuple
import hashlib

from langchain_core.embeddings import Embeddings
from langchain.chains.query_constructor.base import AttributeInfo

from .base import IngestorMemory


class DocsSectionsDescriptionsMemory(IngestorMemory):
	"""
	Vector store memory for section descriptions produced by DocsIndexStudyStrategy.

	Each entry stores the section description, its hierarchical path, and the
	originating file_id so we can filter searches per document set.
	"""

	MEMORY_NAME = "eagle-docs-sections-descriptions-memory"

	EMBEDDED_FIELDS = ["section_title", "description"]

	VALUE_EXAMPLE = {
		"file_id": "doc-123",
		"path": ["Root", "Child"],
		"section_title": "Child",
		"description": "Resumo da seção",
	}

	ATTRIBUTE_INFO = [
		AttributeInfo(name="value.file_id", type="string", description="ID do documento"),
		AttributeInfo(name="value.path", type="list", description="Caminho hierárquico das chaves"),
		AttributeInfo(name="value.section_title", type="string", description="Título da seção"),
		AttributeInfo(name="value.description", type="string", description="Descrição da seção"),
	]

	def __init__(self, store_class: type, embedding_model: Embeddings, embedding_dims: int, embedding_name: str) -> None:
		super().__init__(store_class, embedding_model, embedding_dims, embedding_name)

	@staticmethod
	def _iter_nodes(structure: Dict[str, Any], path_prefix: Optional[List[str]] = None) -> Iterable[Tuple[List[str], Dict[str, Any]]]:
		path_prefix = path_prefix or []
		for title, node in structure.items():
			if not isinstance(node, dict):
				continue
			current_path = path_prefix + [str(title)]
			yield current_path, node
			yield from DocsSectionsDescriptionsMemory._iter_nodes(node, current_path)

	@staticmethod
	def _make_key(file_id: str, path: List[str]) -> str:
		return hashlib.sha256("|".join([file_id, *path]).encode("utf-8")).hexdigest()

	def delete_description(self, file_id: str, path: List[str]) -> None:
		namespace = (self.MEMORY_NAME,)
		key = self._make_key(file_id, path)
		self.delete_memory(namespace=namespace, key=key)

	async def adelete_description(self, file_id: str, path: List[str]) -> None:
		namespace = (self.MEMORY_NAME,)
		key = self._make_key(file_id, path)
		await self.adelete_memory(namespace=namespace, key=key)

	def put_description(
		self,
		file_id: str,
		path: List[str],
		description: str,
		idx_range: Optional[List[int]] = None,
		ttl: Optional[float] = None,
	) -> None:
		namespace = (self.MEMORY_NAME,)
		key = self._make_key(file_id, path)
		value = {
			"file_id": file_id,
			"path": path,
			"section_title": path[-1] if path else "",
			"description": description,
		}
		super().put_memory(namespace=namespace, key=key, value=value, ttl=ttl)

	async def aput_description(
		self,
		file_id: str,
		path: List[str],
		description: str,
		idx_range: Optional[List[int]] = None,
		ttl: Optional[float] = None,
	) -> None:
		namespace = (self.MEMORY_NAME,)
		key = self._make_key(file_id, path)
		value = {
			"file_id": file_id,
			"path": path,
			"section_title": path[-1] if path else "",
			"description": description,
		}
		await super().aput_memory(namespace=namespace, key=key, value=value, ttl=ttl)

	def build_from_structure(
		self,
		file_id: str,
		structure_tree: Dict[str, Any],
		ttl: Optional[float] = None,
	) -> None:
		if not isinstance(structure_tree, dict):
			raise ValueError("structure_tree deve ser um dicionário com nós de seções")

		items: List[Tuple[tuple[str, ...], str, Dict[str, Any]]] = []
		for path, node in self._iter_nodes(structure_tree):
			description = node.get("description")
			if not description:
				continue
			namespace = (self.MEMORY_NAME,)
			key = self._make_key(file_id, path)
			value = {
				"file_id": file_id,
				"path": path,
				"section_title": path[-1] if path else "",
				"description": description,
			}
			items.append((namespace, key, value))

		if not items:
			return

		# Mantém compatibilidade: se ttl for usado, cai no caminho individual
		if ttl is None:
			self.put_memories(items)
		else:
			for namespace, key, value in items:
				self.put_memory(namespace=namespace, key=key, value=value, ttl=ttl)

	async def abuild_from_structure(
		self,
		file_id: str,
		structure_tree: Dict[str, Any],
		ttl: Optional[float] = None,
	) -> None:
		if not isinstance(structure_tree, dict):
			raise ValueError("structure_tree deve ser um dicionário com nós de seções")

		items: List[Tuple[tuple[str, ...], str, Dict[str, Any]]] = []
		for path, node in self._iter_nodes(structure_tree):
			description = node.get("description")
			if not description:
				continue
			namespace = (self.MEMORY_NAME,)
			key = self._make_key(file_id, path)
			value = {
				"file_id": file_id,
				"path": path,
				"section_title": path[-1] if path else "",
				"description": description,
			}
			items.append((namespace, key, value))

		if not items:
			return

		if ttl is None:
			await self.aput_memories(items)
		else:
			for namespace, key, value in items:
				await self.aput_memory(namespace=namespace, key=key, value=value, ttl=ttl)

	def search_memories(
		self,
		query: Optional[str] = None,
		limit: int = 10,
		offset: int = 0,
		filter_file_ids: Optional[List[str]] = None,
	) -> List[Dict[str, Any]]:
		namespace_prefix = (self.MEMORY_NAME,)
		filter_list: List[str] = []
		if filter_file_ids:
			ids_expr = "or(" + ",".join([f'eq("value.file_id", "{fid}")' for fid in filter_file_ids]) + ")"
			filter_list.append(ids_expr)
		filter_expr = "and(" + ",".join(filter_list) + ")" if filter_list else None

		items = super().search_memories(
			namespace_prefix=namespace_prefix,
			query=query,
			filter=filter_expr,
			limit=limit,
			offset=offset,
		)
		return [item.value for item in items]

	async def asearch_memories(
		self,
		query: Optional[str] = None,
		limit: int = 10,
		offset: int = 0,
		filter_file_ids: Optional[List[str]] = None,
	) -> List[Dict[str, Any]]:
		namespace_prefix = (self.MEMORY_NAME,)
		filter_list: List[str] = []
		if filter_file_ids:
			ids_expr = "or(" + ",".join([f'eq("value.file_id", "{fid}")' for fid in filter_file_ids]) + ")"
			filter_list.append(ids_expr)
		filter_expr = "and(" + ",".join(filter_list) + ")" if filter_list else None

		items = await super().asearch_memories(
			namespace_prefix=namespace_prefix,
			query=query,
			filter=filter_expr,
			limit=limit,
			offset=offset,
		)
		return [item.value for item in items]


__all__ = ["DocsSectionsDescriptionsMemory"]