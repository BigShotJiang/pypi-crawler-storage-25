import pytest
import os
from langchain.chains.query_constructor.base import AttributeInfo
from eagle.utils.configs import find_env_upwards
from eagle.stores.opensearch import OpenSearchStore, OpenSearchIndexConfig
from eagle.memory.episodic.conversation_history_memory import ConversationHistoryMemory
from eagle.memory.planning.possible_plans_and_tools_memory import PossiblePlansAndToolsMemory
from eagle.memory.planning.possible_tools_memory import PossibleToolsMemory
from eagle.memory.planning.possible_plans_memory import PossiblePlansMemory
from eagle.memory.shared.shared_objects_memory import SharedObjectsMemory
from eagle.memory.planning.plans_qa_memory import PlansQAMemory
from eagle.models.generators import embed_texts_generator

# Load environment variables from .test.env
find_env_upwards(".test.env")

# ENVIRONMENT VARIABLES
TESTS_EMBEDDING_DIM = int(os.getenv("TESTS_EMBEDDING_DIM"))
TESTS_EMBEDDING_MODEL_NAME = os.getenv("TESTS_EMBEDDING_MODEL_NAME")
TESTS_LLM_MODEL_NAME = os.getenv("TESTS_LLM_MODEL_NAME")

def create_yfinance_session():
    """
    Create a yfinance session with custom headers and SSL verification.
    """
    from curl_cffi import requests
    import os
    import random
    import string

    session = requests.Session()

    session.verify = os.getenv('SSL_CERT_FILE2', None)
    random_user_agent = ''.join(random.choices(string.ascii_letters + string.digits, k=10)) + '/1.0'
    session.headers['User-agent'] = random_user_agent

    return session

@pytest.fixture(scope="module", autouse=True)
def yfinance_session():
    return create_yfinance_session()

@pytest.fixture(scope="module")
def opensearch_store():
    """
    Fixture to provide a connected OpenSearchStore instance for tests.
    Ensures cleanup of the index after tests.
    """

    index = OpenSearchIndexConfig(
        index_name="eagle-test",
        dims=TESTS_EMBEDDING_DIM,
        embed=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        fields=["text", "title"],  # Specify fields for embedding
        value_example={
            "text": "This is a test document.",
            "title": "Test Title",
            "type": "type_test",
            "timestamp": 1123123  # Ensure timestamp is included
        },
        attribute_info=[
            AttributeInfo(name="value.text", type="string", description="Document text"),
            AttributeInfo(name="value.title", type="string", description="Document title"),
            AttributeInfo(name="value.type", type="string", description="Document type"),
            AttributeInfo(name="value.timestamp", type="integer", description="Timestamp of the document"),
        ],
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    store = OpenSearchStore(
        index=index
    )
    
    # Ensure the index is deleted and recreated before each test
    try:
        store.delete_index()
    except Exception:
        pass  # Ignore if the index does not exist
    store.create_index()

    yield store

    # Cleanup after the test
    try:
        store.delete_index()
    except Exception:
        pass

@pytest.fixture(scope="function")
def opensearch_store_async(event_loop):
    """
    Fixture to provide a connected OpenSearchStore instance for async tests.
    Ensures cleanup of the index after each test.
    """
    index = OpenSearchIndexConfig(
        index_name="eagle-test-async",
        dims=TESTS_EMBEDDING_DIM,
        embed=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        fields=["text", "title"],  # Specify fields for embedding
        value_example={
            "text": "This is a test document.",
            "title": "Test Title",
            "type": "type_test",
            "timestamp": 1123123  # Ensure timestamp is included
        },
        attribute_info=[
            AttributeInfo(name="value.text", type="string", description="Document text"),
            AttributeInfo(name="value.title", type="string", description="Document title"),
            AttributeInfo(name="value.type", type="string", description="Document type"),
            AttributeInfo(name="value.timestamp", type="integer", description="Timestamp of the document"),
        ],
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    store = OpenSearchStore(index=index)

    # Ensure the index is deleted and recreated before each test
    try:
        store.delete_index()
    except Exception:
        pass  # Ignore if the index does not exist
    store.create_index()

    yield store

    # Cleanup after the test
    async def cleanup():
        try:
            await store.aclose()  # Ensure async client is closed
        except Exception:
            pass
        try:
            store.delete_index()
        except Exception:
            pass

    event_loop.run_until_complete(cleanup())

@pytest.fixture(scope="function")
def conversation_history_memory():
    """
    Fixture to provide a ConversationHistoryMemory instance for tests.
    Ensures cleanup of the index after tests.
    """

    # Create memory to remove store:
    memory = ConversationHistoryMemory(
        store_class=OpenSearchStore, 
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    try:
        memory.store.delete_index()
    except Exception:
        pass

     # Create memory to remove store:
    memory = ConversationHistoryMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    yield memory

    # Cleanup after the test
    try:
        memory.store.delete_index()
    except Exception:
        pass

@pytest.fixture(scope="function")
def possible_plans_and_tools_memory():
    """
    Fixture to provide a PossiblePlansAndToolsMemory instance for tests.
    Ensures cleanup of the index after tests.
    """
    memory = PossiblePlansAndToolsMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    try:
        memory.store.delete_index()
    except Exception:
        pass

    memory = PossiblePlansAndToolsMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    yield memory

    # Cleanup after the test
    try:
        memory.store.delete_index()
    except Exception:
        pass

@pytest.fixture(scope="function")
def possible_tools_memory():
    """
    Fixture to provide a PossibleToolsMemory instance for tests.
    Ensures cleanup of the index after tests.
    """
    memory = PossibleToolsMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    try:
        memory.store.delete_index()
    except Exception:
        pass

    memory = PossibleToolsMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )
    
    yield memory

    # Cleanup after the test
    try:
        memory.store.delete_index()
    except Exception:
        pass

@pytest.fixture(scope="function")
def possible_plans_memory():
    """
    Fixture to provide a PossiblePlansMemory instance for tests.
    Ensures cleanup of the index after tests.
    """
    memory = PossiblePlansMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    try:
        memory.store.delete_index()
    except Exception:
        pass

    memory = PossiblePlansMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    yield memory

    # Cleanup after the test
    try:
        memory.store.delete_index()
    except Exception:
        pass

@pytest.fixture(scope="function")
def shared_objects_memory(tmp_path):
    """
    Fixture to provide a SharedObjectsMemory instance for tests.
    Ensures cleanup of the index and temporary directory after tests.
    """
    storage_dir = tmp_path / "shared_objects"
    memory = SharedObjectsMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        storage_dir=str(storage_dir),
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    try:
        memory.store.delete_index()
    except Exception:
        pass
    
    memory = SharedObjectsMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        storage_dir=str(storage_dir),
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )


    yield memory

    # Cleanup after the test
    try:
        memory.store.delete_index()
    except Exception:
        pass

@pytest.fixture(scope="function")
def hierarchical_memory():
    """
    Fixture to provide a HierarchicalMemory instance for tests.
    Ensures cleanup of the index after tests.
    """
    from eagle.memory.generic.hierarchical_memory import HierarchicalMemory
    from eagle.stores.opensearch import OpenSearchStore
    from eagle.models.generators import embed_texts_generator

    memory = HierarchicalMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    try:
        memory.store.delete_index()
    except Exception:
        pass

    memory = HierarchicalMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    yield memory

    # Cleanup after the test
    try:
        memory.store.delete_index()
    except Exception:
        pass

@pytest.fixture(scope="function")
def possible_qa_memory():
    """
    Fixture to provide a PlansQAMemory instance for tests.
    Ensures cleanup of the index after tests.
    """
    memory = PlansQAMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    try:
        memory.store.delete_index()
    except Exception:
        pass

    memory = PlansQAMemory(
        store_class=OpenSearchStore,
        embedding_model=embed_texts_generator(TESTS_EMBEDDING_MODEL_NAME),
        embedding_dims=TESTS_EMBEDDING_DIM,
        embedding_name=TESTS_EMBEDDING_MODEL_NAME
    )

    yield memory

    # Cleanup after the test
    try:
        memory.store.delete_index()
    except Exception:
        pass

