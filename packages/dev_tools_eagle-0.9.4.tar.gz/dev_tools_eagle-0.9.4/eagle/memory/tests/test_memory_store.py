# eagle/memory/tests/fakes/fake_memory_store.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import pytest
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]



@dataclass
class MemoryDoc:
    id: str
    namespace: str
    title: str
    text: str
    metadata: Dict[str, Any]


class FakeMemoryStore:
    """
    Fake in-memory que simula o comportamento mínimo do repositório/DAO
    que hoje fala com OpenSearch.
    """
    def __init__(self):
        self._docs: Dict[str, MemoryDoc] = {}

    def put(self, *, id: str, namespace: str, title: str, text: str, metadata: Optional[dict] = None) -> None:
        self._docs[id] = MemoryDoc(
            id=id,
            namespace=namespace,
            title=title,
            text=text,
            metadata=metadata or {},
        )

    def get(self, *, id: str, namespace: str) -> Optional[dict]:
        doc = self._docs.get(id)
        if not doc or doc.namespace != namespace:
            return None
        return {
            "id": doc.id,
            "namespace": doc.namespace,
            "title": doc.title,
            "text": doc.text,
            "metadata": doc.metadata,
        }

    def delete(self, *, id: str, namespace: str) -> bool:
        doc = self._docs.get(id)
        if not doc or doc.namespace != namespace:
            return False
        del self._docs[id]
        return True

    def delete_by_namespace(self, *, namespace: str) -> int:
        to_delete = [k for k, v in self._docs.items() if v.namespace == namespace]
        for k in to_delete:
            del self._docs[k]
        return len(to_delete)

    def search(self, *, namespace: str, query: str, k: int = 5, title_filter: Optional[str] = None) -> List[dict]:
        q = (query or "").lower()

        hits: List[MemoryDoc] = []
        for doc in self._docs.values():
            if doc.namespace != namespace:
                continue
            if title_filter and title_filter.lower() not in doc.title.lower():
                continue
            blob = f"{doc.title}\n{doc.text}".lower()
            if q in blob:
                hits.append(doc)

        # ranking tosco porém determinístico (tamanho do match, etc.)
        hits = hits[:k]

        return [
            {
                "id": d.id,
                "namespace": d.namespace,
                "title": d.title,
                "text": d.text,
                "metadata": d.metadata,
                "score": 1.0,
            }
            for d in hits
        ]
