import pytest
import asyncio
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


@pytest.mark.asyncio
async def test_async_put_and_get_memory(possible_plans_and_tools_memory):
    """Test storing and retrieving a memory asynchronously."""
    memory = possible_plans_and_tools_memory
    agent_id = "agent123"
    plan_id = "plan456"
    description = "Test plan description"
    plan = "Test plan details"
    tools = {
        "tool1": {"description": "Tool 1 description"},
        "tool2": {"description": "Tool 2 description"}
    }

    await memory.aput_memory(agent_id, plan_id, description, plan, tools)

    result = await memory.aget_memory(agent_id, plan_id)
    assert result == {
        "description": description,
        "plan": plan,
        "type": "possible_plans_and_tools_memory",
        "tools": tools
    }

@pytest.mark.asyncio
async def test_async_delete_memory(possible_plans_and_tools_memory):
    """Test deleting a memory asynchronously."""
    memory = possible_plans_and_tools_memory
    agent_id = "agent123"
    plan_id = "plan456"
    description = "Test plan description"
    plan = "Test plan details"
    tools = {
        "tool1": {"description": "Tool 1 description"},
        "tool2": {"description": "Tool 2 description"}
    }

    await memory.aput_memory(agent_id, plan_id, description, plan, tools)
    await memory.adelete_memory(agent_id, plan_id)

    result = await memory.aget_memory(agent_id, plan_id)
    assert result is None

@pytest.mark.asyncio
async def test_async_search_memories(possible_plans_and_tools_memory):
    """Test searching for memories asynchronously."""
    memory = possible_plans_and_tools_memory
    agent_id = "agent123"

    # Add multiple memories with semantically different descriptions and plans
    await asyncio.gather(
        memory.aput_memory(agent_id, "plan1", "Description about AI", "Plan for AI development", {"tool1": {"description": "AI Tool"}}),
        memory.aput_memory(agent_id, "plan2", "Description about ML", "Plan for ML research", {"tool2": {"description": "ML Tool"}}),
        memory.aput_memory(agent_id, "plan3", "Description about robotics", "Plan for robotics design", {"tool3": {"description": "Robotics Tool"}}),
        memory.aput_memory(agent_id, "plan4", "Description about data science", "Plan for data analysis", {"tool4": {"description": "Data Science Tool"}}),
        memory.aput_memory(agent_id, "plan5", "Description about cloud computing", "Plan for cloud infrastructure", {"tool5": {"description": "Cloud Tool"}})
    )

    await asyncio.sleep(3)  # Aguarda a indexação

    # Search for memories with a query related to AI and ML
    results = await memory.asearch_memories(agent_id, query="AI and ML", limit=2)

    # Assert that the correct plans and tools are returned
    assert len(results) == 2
    assert {"description": "Description about AI", "plan": "Plan for AI development", "type": "possible_plans_and_tools_memory", "tools": {"tool1": {"description": "AI Tool"}}} in results
    assert {"description": "Description about ML", "plan": "Plan for ML research", "type": "possible_plans_and_tools_memory", "tools": {"tool2": {"description": "ML Tool"}}} in results
