import pytest
import asyncio
import hashlib
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


@pytest.mark.asyncio
async def test_async_put_and_get_memory(possible_plans_memory):
    memory = possible_plans_memory
    plans_set_id = "test-plans-set"
    plan_id = "Plan1"
    question = "A plan for optimizing resource allocation."
    plan = "Optimize resources"
    source = "System"

    # Ensure the namespace is clean before the test
    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)

    # Put memory
    await memory.aput_memory(plans_set_id=plans_set_id, plan_id=plan_id, question=question, plan=plan, source=source)

    # Get memory
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result == {
        "question": question,
        "plan": plan,
        "source": source,
        "type": "possible_plans_memory",
    }


@pytest.mark.asyncio
async def test_async_delete_memory(possible_plans_memory):
    memory = possible_plans_memory
    plans_set_id = "test-plans-set"
    plan_id = "Plan1"
    question = "A plan for optimizing resource allocation."
    plan = "Optimize resources"
    source = "System"

    # Ensure the namespace is clean before the test
    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)

    # Put memory
    await memory.aput_memory(plans_set_id=plans_set_id, plan_id=plan_id, question=question, plan=plan, source=source)

    # Confirm memory exists
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result is not None

    # Delete memory
    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)

    # Verify deletion
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result is None


@pytest.mark.asyncio
async def test_async_search_memories(possible_plans_memory):
    memory = possible_plans_memory
    plans_set_id = "test-plans-set"

    # Ensure the namespace is clean before the test
    for plan in ["Plan1", "Plan2", "Plan3"]:
        await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan)

    # Add multiple plans
    plans_descriptors = [
        {"plan": "Plan1", "question": "A plan for optimizing resource allocation.", "source": "System"},
        {"plan": "Plan2", "question": "A strategy for improving team collaboration.", "source": "Manager"},
        {"plan": "Plan3", "question": "A roadmap for AI-based automation.", "source": "AI System"},
    ]
    await asyncio.gather(
        *(memory.aput_memory(plans_set_id=plans_set_id, plan_id=plan["plan"], question=plan["question"], plan=plan["plan"], source=plan["source"]) for plan in plans_descriptors)
    )

    await asyncio.sleep(4)

    # Perform a semantic search
    query = "automation"
    results = await memory.asearch_memories(plans_set_id=plans_set_id, query=query, limit=1)

    # Assert results
    assert len(results) > 0
    assert any("AI-based automation" in result["question"] for result in results)


@pytest.mark.asyncio
async def test_async_build_memory(possible_plans_memory):
    memory = possible_plans_memory
    plans_set_id = "test-plans-set"

    # Ensure the namespace is clean before the test
    for plan in ["Plan1", "Plan2", "Plan3"]:
        await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan)

    # Define plans descriptors
    plans_descriptors = [
        {"plan": "Plan1", "question": "A plan for optimizing resource allocation.", "source": "System"},
        {"plan": "Plan2", "question": "A strategy for improving team collaboration.", "source": "Manager"},
        {"plan": "Plan3", "question": "A roadmap for AI-based automation.", "source": "AI System"},
    ]

    # Build the memory with the plans
    await memory.abuild(
        plans_set_id=plans_set_id,
        plans_descriptors=plans_descriptors
    )

    await asyncio.sleep(4)  # Wait for indexing

    # Verify that the plans were added
    for plan in plans_descriptors:
        plan_id = hashlib.sha256(plan["question"].encode("utf-8")).hexdigest()
        result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
        assert result is not None
        assert result["question"] == plan["question"]
        assert result["plan"] == plan["plan"]
        assert result["source"] == plan["source"]

    # Perform a semantic search
    query = "automation"
    results = await memory.asearch_memories(plans_set_id=plans_set_id, query=query, limit=1)

    # Assert results
    assert len(results) > 0
    assert any("AI-based automation" in result["question"] for result in results)


@pytest.mark.asyncio
async def test_async_multilevel_plans_set_id(possible_plans_memory):
    memory = possible_plans_memory
    plans_set_id = ("levelA", "levelB", "levelC")
    plan_id = "AsyncPlanMulti"
    question = "An async multi-level plan."
    plan = "Async multi-level plan details"
    source = "AsyncMultiSource"

    # Clean up before test
    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)

    # Put memory
    await memory.aput_memory(plans_set_id=plans_set_id, plan_id=plan_id, question=question, plan=plan, source=source)
    await asyncio.sleep(3)  # Wait for indexing
    # Get memory
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result == {
        "question": question,
        "plan": plan,
        "source": source,
        "type": "possible_plans_memory",
    }

    # Search memory
    results = await memory.asearch_memories(plans_set_id=plans_set_id, query="async multi-level", limit=1)
    assert len(results) > 0
    assert any("async multi-level" in result["plan"].lower() for result in results)

    # Delete memory
    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result is None
