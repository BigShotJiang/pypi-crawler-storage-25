import importlib
import os
import sys
import types
import hashlib
import pytest


# --------
# Helper: encontra o módulo real
# --------
CANDIDATE_MODULES = [
    "eagle.memory.planning.plans_qa_memory",
    "eagle.memory.planning.qa_plans_memory",
    "eagle.memory.planning.plans_qa",
    "eagle.memory.planning.qa",
]


def _import_first_existing(module_names):
    last_err = None
    for name in module_names:
        try:
            return importlib.import_module(name)
        except Exception as e:
            last_err = e
    raise ModuleNotFoundError(
        "Não encontrei o módulo real com PlansQAMemory. "
        f"Tentei: {module_names}. Último erro: {last_err}"
    )


# --------
# Fakes: Store + Item
# --------
class _Item:
    def __init__(self, namespace, key, value):
        self.namespace = namespace
        self.key = key
        self.value = value


class _FakeStore:
    """
    Simula o mínimo necessário do store usado por PlanningMemory:
    put/get/delete/delete_by_namespace/search + async variants.
    """

    def __init__(self):
        self._db = {}  # (namespace, key) -> _Item

    def put(self, namespace, key, value, ttl=None):
        self._db[(tuple(namespace), key)] = _Item(tuple(namespace), key, value)

    def get(self, namespace, key):
        return self._db.get((tuple(namespace), key))

    def delete(self, namespace, key):
        self._db.pop((tuple(namespace), key), None)

    def delete_by_namespace(self, namespace):
        ns = tuple(namespace)
        to_delete = [k for k in self._db.keys() if k[0] == ns]
        for k in to_delete:
            self._db.pop(k, None)

    def search(self, namespace_prefix, query=None, filter=None, limit=10, offset=0):
        """
        Busca fake:
        - filtra por prefixo de namespace
        - aplica filtro mínimo do formato:
          eq("value.source","X"), eq("value.title","Y")
          e combinação and(or(...), or(...))
        """
        ns_prefix = tuple(namespace_prefix)

        def _matches_prefix(item):
            ns = item.namespace
            return len(ns) >= len(ns_prefix) and ns[: len(ns_prefix)] == ns_prefix

        items = [it for it in self._db.values() if _matches_prefix(it)]

        if filter:
            def parse_eq(expr):
                if 'eq("value.source"' in expr:
                    field = "source"
                elif 'eq("value.title"' in expr:
                    field = "title"
                else:
                    return None
                val = expr.split(",")[1].strip().strip(')"').strip('"').strip()
                val = val.replace('")', "")
                return field, val

            def match_expr(expr, value):
                parsed = parse_eq(expr)
                if not parsed:
                    return True
                field, val = parsed
                return value.get(field) == val

            def match_filter(filter_str, value):
                fs = filter_str.strip()
                if fs.startswith("and(") and fs.endswith(")"):
                    inner = fs[4:-1]
                    parts = _split_top_level(inner)
                    return all(match_filter(p, value) for p in parts)
                if fs.startswith("or(") and fs.endswith(")"):
                    inner = fs[3:-1]
                    parts = _split_top_level(inner)
                    return any(match_filter(p, value) for p in parts)
                return match_expr(fs, value)

            items = [it for it in items if match_filter(filter, it.value)]

        return items[offset : offset + limit]

    async def aput(self, namespace, key, value, ttl=None):
        return self.put(namespace, key, value, ttl=ttl)

    async def aget(self, namespace, key):
        return self.get(namespace, key)

    async def adelete(self, namespace, key):
        return self.delete(namespace, key)

    async def adelete_by_namespace(self, namespace):
        return self.delete_by_namespace(namespace)

    async def asearch(self, namespace_prefix, query=None, filter=None, limit=10, offset=0):
        return self.search(namespace_prefix, query=query, filter=filter, limit=limit, offset=offset)


def _split_top_level(s: str):
    """Split por vírgula respeitando parênteses."""
    out, buf, depth = [], [], 0
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            out.append("".join(buf).strip())
            buf = []
        else:
            buf.append(ch)
    if buf:
        out.append("".join(buf).strip())
    return out


# --------
# Fixture: importa módulo real + injeta PlanningMemory fake
# --------
@pytest.fixture()
def module_under_test(monkeypatch):
    """
    1) Cria um PlanningMemory fake antes do import do módulo real
       para não depender de OpenSearch etc.
    2) Também cria um create_plan_processing_chain fake para ser monkeypatchado.
    """

    fake_planning_base = types.ModuleType("eagle.memory.planning.base")

    class FakePlanningMemory:
        def __init__(self, *args, **kwargs):
            self.store = _FakeStore()

        def put_memory(self, namespace, key, value, ttl=None):
            self.store.put(namespace, key, value, ttl=ttl)

        async def aput_memory(self, namespace, key, value, ttl=None):
            await self.store.aput(namespace, key, value, ttl=ttl)

        def get_memory(self, namespace, key):
            return self.store.get(namespace, key)

        async def aget_memory(self, namespace, key):
            return await self.store.aget(namespace, key)

        def delete_memory(self, namespace, key):
            self.store.delete(namespace, key)

        async def adelete_memory(self, namespace, key):
            await self.store.adelete(namespace, key)

        def delete_memories_by_namespace(self, namespace):
            self.store.delete_by_namespace(namespace)

        def search_memories(self, namespace_prefix, query=None, filter=None, limit=10, offset=0):
            return self.store.search(namespace_prefix, query=query, filter=filter, limit=limit, offset=offset)

        async def asearch_memories(self, namespace_prefix, query=None, filter=None, limit=10, offset=0):
            return await self.store.asearch(namespace_prefix, query=query, filter=filter, limit=limit, offset=offset)

    fake_planning_base.PlanningMemory = FakePlanningMemory
    monkeypatch.setitem(sys.modules, "eagle.memory.planning.base", fake_planning_base)

    fake_chain_mod = types.ModuleType("eagle.chains.plan_qa_construction")

    def create_plan_processing_chain(prompt_language, llm):
        raise RuntimeError("Não deveria chamar o chain real nos testes sem mock")

    fake_chain_mod.create_plan_processing_chain = create_plan_processing_chain
    monkeypatch.setitem(sys.modules, "eagle.chains.plan_qa_construction", fake_chain_mod)

    # ---- fake AttributeInfo (LangChain mudou de lugar entre versões) ----
    fake_qc_base = types.ModuleType("langchain.chains.query_constructor.base")

    class AttributeInfo:
        def __init__(self, name: str, type: str, description: str):
            self.name = name
            self.type = type
            self.description = description

    fake_qc_base.AttributeInfo = AttributeInfo
    monkeypatch.setitem(sys.modules, "langchain.chains.query_constructor.base", fake_qc_base)

    # (Opcional, mas recomendado) também cobre o caminho "novo"
    fake_qc_schema = types.ModuleType("langchain.chains.query_constructor.schema")
    fake_qc_schema.AttributeInfo = AttributeInfo
    monkeypatch.setitem(sys.modules, "langchain.chains.query_constructor.schema", fake_qc_schema)

    m = _import_first_existing(CANDIDATE_MODULES)
    return importlib.reload(m)


@pytest.fixture()
def memory(module_under_test):
    return module_under_test.PlansQAMemory()


# ----------------------------
# Tests: namespace
# ----------------------------
def test_get_namespace_str(memory):
    assert memory._get_namespace("abc") == (memory.MEMORY_NAME, "abc")


def test_get_namespace_tuple(memory):
    assert memory._get_namespace(("abc", "tenant1")) == (memory.MEMORY_NAME, "abc", "tenant1")


# ----------------------------
# put/get/delete sync
# ----------------------------
def test_put_and_get_memory_roundtrip(memory):
    memory.put_memory("set1", "p1", "Q?", "Plano", "Curto", "src", "Titulo")
    got = memory.get_memory("set1", "p1")
    assert got["question"] == "Q?"
    assert got["plan"] == "Plano"
    assert got["short_description"] == "Curto"
    assert got["source"] == "src"
    assert got["title"] == "Titulo"
    assert got["type"] == "qa_plans"


def test_delete_memory(memory):
    memory.put_memory("set1", "p1", "Q", "P", "S", "src", "T")
    assert memory.get_memory("set1", "p1") is not None
    memory.delete_memory("set1", "p1")
    assert memory.get_memory("set1", "p1") is None


def test_delete_memories_by_namespace(memory):
    memory.put_memory("set1", "p1", "Q1", "P1", "S1", "A", "T1")
    memory.put_memory("set1", "p2", "Q2", "P2", "S2", "B", "T2")
    memory.delete_memories_by_namespace("set1")
    assert memory.get_memory("set1", "p1") is None
    assert memory.get_memory("set1", "p2") is None


# ----------------------------
# search: filtro por source/title
# ----------------------------
def test_search_memories_filter_sources_and_titles(memory):
    memory.put_memory("set1", "p1", "Q1", "P1", "S1", "srcA", "tA")
    memory.put_memory("set1", "p2", "Q2", "P2", "S2", "srcB", "tA")
    memory.put_memory("set1", "p3", "Q3", "P3", "S3", "srcB", "tB")
    out = memory.search_memories("set1", filter_sources=["srcB"], filter_titles=["tA"])
    assert len(out) == 1
    assert out[0]["question"] == "Q2"


def test_search_memories_no_filters_returns_all(memory):
    memory.put_memory("set1", "p1", "Q1", "P1", "S1", "srcA", "tA")
    memory.put_memory("set1", "p2", "Q2", "P2", "S2", "srcB", "tB")
    out = memory.search_memories("set1")
    assert {x["question"] for x in out} == {"Q1", "Q2"}


# ----------------------------
# async variants
# ----------------------------
@pytest.mark.asyncio
async def test_async_put_get_delete(memory):
    await memory.aput_memory("setA", "pX", "Q", "P", "S", "src", "T")
    got = await memory.aget_memory("setA", "pX")
    assert got["question"] == "Q"
    await memory.adelete_memory("setA", "pX")
    assert await memory.aget_memory("setA", "pX") is None


@pytest.mark.asyncio
async def test_async_search(memory):
    await memory.aput_memory("setA", "p1", "Q1", "P1", "S1", "srcA", "tA")
    await memory.aput_memory("setA", "p2", "Q2", "P2", "S2", "srcB", "tB")
    out = await memory.asearch_memories("setA", filter_sources=["srcB"])
    assert len(out) == 1
    assert out[0]["question"] == "Q2"


# ----------------------------
# build/abuild: caminho chain_llm is None
# ----------------------------
def test_build_chain_llm_none_stores_descriptors(module_under_test, memory):
    PlanDescriptorSchema = module_under_test.PlanDescriptorSchema

    plans = [
        PlanDescriptorSchema(plan="Plano 1", question="Pergunta 1", short_description="Curto 1", source="src", title="Titulo 1"),
        PlanDescriptorSchema(plan="Plano 2", question="Pergunta 2", short_description="Curto 2", source=None, title="Titulo 2"),
    ]

    memory.build("set1", plans, config={"chain_llm": None, "number_of_questions": 5})
    id1 = hashlib.sha256("Pergunta 1".encode("utf-8")).hexdigest()
    id2 = hashlib.sha256("Pergunta 2".encode("utf-8")).hexdigest()

    m1 = memory.get_memory("set1", id1)
    m2 = memory.get_memory("set1", id2)

    assert m1["short_description"] == "Curto 1"
    assert m2["source"] == "unknown"


@pytest.mark.asyncio
async def test_abuild_chain_llm_none_stores_descriptors(module_under_test, memory):
    PlanDescriptorSchema = module_under_test.PlanDescriptorSchema
    plans = [PlanDescriptorSchema(plan="Plano 1", question="Pergunta 1", short_description="Curto 1", source="src", title="Titulo 1")]

    await memory.abuild("set1", plans, config={"chain_llm": None, "number_of_questions": 2})
    pid = hashlib.sha256("Pergunta 1".encode("utf-8")).hexdigest()
    m1 = memory.get_memory("set1", pid)
    assert m1["title"] == "Titulo 1"


# ----------------------------
# build/abuild: caminho chain_llm != None (mock do processing_chain)
# ----------------------------
def test_build_chain_llm_generates_questions(monkeypatch, module_under_test):
    m = module_under_test
    mem = m.PlansQAMemory()

    from langchain_core.language_models.chat_models import BaseChatModel
    from langchain_core.messages import AIMessage
    from langchain_core.outputs import ChatGeneration, ChatResult

    class FakeLLM(BaseChatModel):
        @property
        def _llm_type(self) -> str:
            return "fake"

        def _generate(self, messages, stop=None, run_manager=None, **kwargs):
            return ChatResult(generations=[ChatGeneration(message=AIMessage(content="ok"))])

    class FakeChain:
        def invoke(self, payload):
            class Out:
                short_description = "SD gerado"
                questions = ["Qx", "Qy"]
            return Out()

    monkeypatch.setattr(m, "create_plan_processing_chain", lambda prompt_language, llm: FakeChain())

    plans = [m.PlanDescriptorSchema(plan="Texto do plano", question="Original", short_description="ignorar", source="src", title="Titulo")]

    mem.build("set1", plans, config={"chain_llm": FakeLLM(), "chain_llm_prompt_language": "pt-br", "number_of_questions": 2})

    id_x = hashlib.sha256("Qx".encode("utf-8")).hexdigest()
    id_y = hashlib.sha256("Qy".encode("utf-8")).hexdigest()

    mx = mem.get_memory("set1", id_x)
    my = mem.get_memory("set1", id_y)

    assert mx["short_description"] == "SD gerado"
    assert my["question"] == "Qy"
    assert mx["title"] == "Titulo"


@pytest.mark.asyncio
async def test_abuild_chain_llm_generates_questions(monkeypatch, module_under_test):
    m = module_under_test
    mem = m.PlansQAMemory()

    from langchain_core.language_models.chat_models import BaseChatModel
    from langchain_core.messages import AIMessage
    from langchain_core.outputs import ChatGeneration, ChatResult

    class FakeLLM(BaseChatModel):
        @property
        def _llm_type(self) -> str:
            return "fake"

        def _generate(self, messages, stop=None, run_manager=None, **kwargs):
            return ChatResult(generations=[ChatGeneration(message=AIMessage(content="ok"))])

    class FakeChain:
        async def ainvoke(self, payload):
            return {"short_description": "SD async", "questions": ["Qa", "Qb"]}

    monkeypatch.setattr(m, "create_plan_processing_chain", lambda prompt_language, llm: FakeChain())

    plans = [m.PlanDescriptorSchema(plan="Texto", question="Original", short_description="desc", source="src", title="Titulo")]

    await mem.abuild("set1", plans, config={"chain_llm": FakeLLM(), "chain_llm_prompt_language": "pt-br", "number_of_questions": 2})

    ida = hashlib.sha256("Qa".encode("utf-8")).hexdigest()
    idb = hashlib.sha256("Qb".encode("utf-8")).hexdigest()

    ma = mem.get_memory("set1", ida)
    mb = mem.get_memory("set1", idb)

    assert ma["short_description"] == "SD async"
    assert mb["question"] == "Qb"


# ----------------------------
# study: lê YAML e chama build (mock)
# ----------------------------
def test_study_reads_yaml_and_calls_build(tmp_path, monkeypatch, module_under_test):
    m = module_under_test
    mem = m.PlansQAMemory()

    d = tmp_path / "plans"
    d.mkdir()

    (d / "a.yaml").write_text(
        "source: srcA\n"
        "text: Plano A\n"
        "title: Titulo A\n"
        "short_description: Curto A\n",
        encoding="utf-8",
    )

    captured = {}

    def fake_build(plans_set_id, plans_descriptors, config):
        captured["plans_set_id"] = plans_set_id
        captured["count"] = len(plans_descriptors)
        captured["first"] = plans_descriptors[0]

    monkeypatch.setattr(mem, "build", fake_build)

    mem.study("set1", [str(d)], config={"chain_llm": None, "number_of_questions": 5})

    assert captured["plans_set_id"] == "set1"
    assert captured["count"] == 1
    assert captured["first"].title == "Titulo A"
    assert captured["first"].short_description == "Curto A"
