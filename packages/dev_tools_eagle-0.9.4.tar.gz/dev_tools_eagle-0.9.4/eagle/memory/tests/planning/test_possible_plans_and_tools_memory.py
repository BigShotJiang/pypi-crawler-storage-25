import time
import pytest
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


def test_put_and_get_memory(possible_plans_and_tools_memory):
    """Test storing and retrieving a memory."""
    memory = possible_plans_and_tools_memory
    agent_id = "agent123"
    plan_id = "plan456"
    description = "Test plan description"
    plan = "Test plan details"
    tools = {
        "tool1": {"description": "Tool 1 description"},
        "tool2": {"description": "Tool 2 description"}
    }

    memory.put_memory(agent_id, plan_id, description, plan, tools)

    result = memory.get_memory(agent_id, plan_id)
    assert result == {
        "description": description,
        "plan": plan,
        "type": "possible_plans_and_tools_memory",
        "tools": tools
    }

def test_delete_memory(possible_plans_and_tools_memory):
    """Test deleting a memory."""
    memory = possible_plans_and_tools_memory
    agent_id = "agent123"
    plan_id = "plan456"
    description = "Test plan description"
    plan = "Test plan details"
    tools = {
        "tool1": {"description": "Tool 1 description"},
        "tool2": {"description": "Tool 2 description"}
    }

    memory.put_memory(agent_id, plan_id, description, plan, tools)
    memory.delete_memory(agent_id, plan_id)

    result = memory.get_memory(agent_id, plan_id)
    assert result is None

def test_search_memories(possible_plans_and_tools_memory):
    """Test searching for memories."""
    memory = possible_plans_and_tools_memory
    agent_id = "agent123"

    # Add multiple memories with semantically different descriptions and plans
    memory.put_memory(agent_id, "plan1", "Description about AI", "Plan for AI development", {"tool1": {"description": "AI Tool"}})
    memory.put_memory(agent_id, "plan2", "Description about ML", "Plan for ML research", {"tool2": {"description": "ML Tool"}})
    memory.put_memory(agent_id, "plan3", "Description about robotics", "Plan for robotics design", {"tool3": {"description": "Robotics Tool"}})
    memory.put_memory(agent_id, "plan4", "Description about data science", "Plan for data analysis", {"tool4": {"description": "Data Science Tool"}})
    memory.put_memory(agent_id, "plan5", "Description about cloud computing", "Plan for cloud infrastructure", {"tool5": {"description": "Cloud Tool"}})

    time.sleep(3)  # Wait for indexing

    # Search for memories with a query related to AI and ML
    results = memory.search_memories(agent_id, query="AI and ML", limit=2)

    # Assert that the correct plans and tools are returned
    assert len(results) == 2
    assert {"description": "Description about AI", "plan": "Plan for AI development", "type": "possible_plans_and_tools_memory", "tools": {"tool1": {"description": "AI Tool"}}} in results
    assert {"description": "Description about ML", "plan": "Plan for ML research", "type": "possible_plans_and_tools_memory", "tools": {"tool2": {"description": "ML Tool"}}} in results

def test_delete_memories_by_namespace(possible_plans_and_tools_memory):
    """Test deleting all memories in a namespace."""
    memory = possible_plans_and_tools_memory
    agent_id = "agent123"

    # Add multiple memories
    memory.put_memory(agent_id, "plan1", "Description about AI", "Plan for AI development", {"tool1": {"description": "AI Tool"}})
    memory.put_memory(agent_id, "plan2", "Description about ML", "Plan for ML research", {"tool2": {"description": "ML Tool"}})

    # Verify memories exist
    assert memory.get_memory(agent_id, "plan1") is not None
    assert memory.get_memory(agent_id, "plan2") is not None

    time.sleep(3)  # Wait for indexing

    # Delete all memories in the namespace
    memory.delete_memories_by_namespace(agent_id)

    # Verify memories are deleted
    assert memory.get_memory(agent_id, "plan1") is None
    assert memory.get_memory(agent_id, "plan2") is None
