import time
from eagle.tools import _generate_tools_dict
import pytest
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


_TOOLS_DICT = _generate_tools_dict()

def test_put_and_get_memory(possible_tools_memory):
    memory = possible_tools_memory
    tools_set_id = "test-tools-set"
    tool_name = "Tool1"
    description = "A tool for data analysis and visualization."

    # Ensure the namespace is clean before the test
    memory.delete_memory(tools_set_id=tools_set_id, tool_name=tool_name)

    # Put memory
    memory.put_memory(tools_set_id=tools_set_id, tool_name=tool_name, description=description)

    # Get memory
    result = memory.get_memory(tools_set_id=tools_set_id, tool_name=tool_name)
    assert result == {
        "name": tool_name,
        "description": description,
        "type": "possible_tools_memory",
    }


def test_delete_memory(possible_tools_memory):
    memory = possible_tools_memory
    tools_set_id = "test-tools-set"
    tool_name = "Tool1"
    description = "A tool for data analysis and visualization."

    # Ensure the namespace is clean before the test
    memory.delete_memory(tools_set_id=tools_set_id, tool_name=tool_name)

    # Put memory
    memory.put_memory(tools_set_id=tools_set_id, tool_name=tool_name, description=description)
    
    # Confirm memory was added
    result = memory.get_memory(tools_set_id=tools_set_id, tool_name=tool_name)
    assert result is not None

    # Delete memory
    memory.delete_memory(tools_set_id=tools_set_id, tool_name=tool_name)

    # Verify deletion
    result = memory.get_memory(tools_set_id=tools_set_id, tool_name=tool_name)
    assert result is None


def test_search_memories(possible_tools_memory):
    memory = possible_tools_memory
    tools_set_id = "test-tools-set"

    # Ensure the namespace is clean before the test
    for tool in ["Tool1", "Tool2", "Tool3"]:
        memory.delete_memory(tools_set_id=tools_set_id, tool_name=tool)

    # Add multiple tools
    tools_descriptors = [
        {"name": "Tool1", "description": "A tool for data analysis and visualization."},
        {"name": "Tool2", "description": "A software for managing cloud infrastructure."},
        {"name": "Tool3", "description": "An application for AI-based image recognition."},
    ]
    for tool in tools_descriptors:
        memory.put_memory(tools_set_id=tools_set_id, tool_name=tool["name"], description=tool["description"])

    time.sleep(4)

    # Perform a semantic search
    query = "image recognition"
    results = memory.search_memories(tools_set_id=tools_set_id, query=query, limit=1)

    # Assert results
    assert len(results) > 0
    assert any("AI-based image recognition" in result["description"] for result in results)


def test_build_memory(possible_tools_memory):
    memory = possible_tools_memory
    tools_set_id = "test-tools-set"

    # Ensure the namespace is clean before the test
    for tool in ["Tool1", "Tool2", "Tool3"]:
        memory.delete_memory(tools_set_id=tools_set_id, tool_name=tool)

    # Define tools descriptors
    tools_descriptors = [
        {"name": "Tool1", "description": "A tool for data analysis and visualization."},
        {"name": "Tool2", "description": "A software for managing cloud infrastructure."},
        {"name": "Tool3", "description": "An application for AI-based image recognition."},
    ]

    # Build the memory with the tools
    memory.build(tools_set_id=tools_set_id, tools_descriptors=tools_descriptors)

    time.sleep(4)  # Wait for indexing

    # Verify that the tools were added
    for tool in tools_descriptors:
        result = memory.get_memory(tools_set_id=tools_set_id, tool_name=tool["name"])
        assert result is not None
        assert result["name"] == tool["name"]
        assert result["description"] == tool["description"]

    # Perform a semantic search
    query = "image recognition"
    results = memory.search_memories(tools_set_id=tools_set_id, query=query, limit=1)

    # Assert results
    assert len(results) > 0
    assert any("AI-based image recognition" in result["description"] for result in results)

def test_delete_memories_by_namespace(possible_tools_memory):
    tools_set_id = "test-tools-set"

    # Add multiple memories
    possible_tools_memory.put_memory(tools_set_id, "Tool1", "Description for Tool1")
    possible_tools_memory.put_memory(tools_set_id, "Tool2", "Description for Tool2")

    # Verify memories exist
    assert possible_tools_memory.get_memory(tools_set_id, "Tool1") is not None
    assert possible_tools_memory.get_memory(tools_set_id, "Tool2") is not None

    time.sleep(3)  # Wait for indexing

    # Delete all memories in the namespace
    possible_tools_memory.delete_memories_by_namespace(tools_set_id)

    # Verify memories are deleted
    assert possible_tools_memory.get_memory(tools_set_id, "Tool1") is None
    assert possible_tools_memory.get_memory(tools_set_id, "Tool2") is None
