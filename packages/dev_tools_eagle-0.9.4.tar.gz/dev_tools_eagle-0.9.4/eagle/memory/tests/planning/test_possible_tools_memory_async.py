import os
import pytest
import asyncio
from eagle.models.generators import get_llm_model
from eagle.models.tests.models.test_chat_model import FakeChatModel
from eagle.memory.tests.conftest import TESTS_LLM_MODEL_NAME
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]

@pytest.mark.asyncio
async def test_async_put_and_get_memory(possible_tools_memory):
    memory = possible_tools_memory
    tools_set_id = "test-tools-set"
    tool_name = "Tool1"
    description = "A tool for data analysis and visualization."

    # Ensure the namespace is clean before the test
    await memory.adelete_memory(tools_set_id=tools_set_id, tool_name=tool_name)

    # Put memory
    await memory.aput_memory(tools_set_id=tools_set_id, tool_name=tool_name, description=description)

    # Get memory
    result = await memory.aget_memory(tools_set_id=tools_set_id, tool_name=tool_name)
    assert result == {
        "name": tool_name,
        "description": description,
        "type": "possible_tools_memory",
    }


@pytest.mark.asyncio
async def test_async_delete_memory(possible_tools_memory):
    memory = possible_tools_memory
    tools_set_id = "test-tools-set"
    tool_name = "Tool1"
    description = "A tool for data analysis and visualization."

    # Ensure the namespace is clean before the test
    await memory.adelete_memory(tools_set_id=tools_set_id, tool_name=tool_name)

    # Put memory
    await memory.aput_memory(tools_set_id=tools_set_id, tool_name=tool_name, description=description)

    # Confirm the memory was added
    result = await memory.aget_memory(tools_set_id=tools_set_id, tool_name=tool_name)

    assert result is not None

    # Delete memory
    await memory.adelete_memory(tools_set_id=tools_set_id, tool_name=tool_name)

    # Verify deletion
    result = await memory.aget_memory(tools_set_id=tools_set_id, tool_name=tool_name)
    assert result is None


@pytest.mark.asyncio
async def test_async_search_memories(possible_tools_memory):
    memory = possible_tools_memory
    tools_set_id = "test-tools-set"

    # Ensure the namespace is clean before the test
    for tool in ["Tool1", "Tool2", "Tool3"]:
        await memory.adelete_memory(tools_set_id=tools_set_id, tool_name=tool)

    # Add multiple tools
    tools_descriptors = [
        {"name": "Tool1", "description": "A tool for data analysis and visualization."},
        {"name": "Tool2", "description": "A software for managing cloud infrastructure."},
        {"name": "Tool3", "description": "An application for AI-based image recognition."},
    ]
    await asyncio.gather(
        *(memory.aput_memory(tools_set_id=tools_set_id, tool_name=tool["name"], description=tool["description"]) for tool in tools_descriptors)
    )

    asyncio.sleep(10)

    # Perform a semantic search
    query = "image recognition"
    results = await memory.asearch_memories(tools_set_id=tools_set_id, query=query, limit=1)

    # Assert results
    assert len(results) > 0
    assert any("AI-based image recognition" in result["description"] for result in results)

@pytest.mark.asyncio
async def test_async_build_memory(possible_tools_memory):
    memory = possible_tools_memory
    tools_set_id = "test-tools-set"

    # Ensure the namespace is clean before the test
    for tool in ["Tool1", "Tool2", "Tool3"]:
        await memory.adelete_memory(tools_set_id=tools_set_id, tool_name=tool)

    # Define tools descriptors
    tools_descriptors = [
        {"name": "Tool1", "description": "A tool for data analysis and visualization."},
        {"name": "Tool2", "description": "A software for managing cloud infrastructure."},
        {"name": "Tool3", "description": "An application for AI-based image recognition."},
    ]

    # Build the memory with the tools
    await memory.abuild(tools_set_id=tools_set_id, tools_descriptors=tools_descriptors)

    await asyncio.sleep(4)  # Wait for indexing

    # Verify that the tools were added
    for tool in tools_descriptors:
        result = await memory.aget_memory(tools_set_id=tools_set_id, tool_name=tool["name"])
        assert result is not None
        assert result["name"] == tool["name"]
        assert result["description"] == tool["description"]

    # Perform a semantic search
    query = "image recognition"
    results = await memory.asearch_memories(tools_set_id=tools_set_id, query=query, limit=1)

    # Assert results
    assert len(results) > 0
    assert any("AI-based image recognition" in result["description"] for result in results)


@pytest.mark.asyncio
async def test_async_build_with_translation(possible_tools_memory):
    memory = possible_tools_memory
    tools_set_id = "test-tools-set"

    # Ensure the namespace is clean before the test
    for tool in ["Tool1", "Tool2", "Tool3"]:
        await memory.adelete_memory(tools_set_id=tools_set_id, tool_name=tool)

    # Define tools descriptors in English
    tools_descriptors = [
        {"name": "Tool1", "description": "A tool for data analysis and visualization."},
        {"name": "Tool2", "description": "A software for managing cloud infrastructure."},
        {"name": "Tool3", "description": "An application for AI-based image recognition."},
    ]

    # Configure the build to use translation with GPT-4o
    config = {
        "chain_llm": get_llm_model(
            model_name=TESTS_LLM_MODEL_NAME,
            temperature=0.1,
            max_tokens=100,
        ),
        "chain_llm_prompt_language": "pt-br",
    }

    # Build the memory with the tools
    await memory.abuild(tools_set_id=tools_set_id, tools_descriptors=tools_descriptors, config=config)

    await asyncio.sleep(4)  # Wait for indexing

    # Perform a semantic search in Portuguese
    query = "reconhecimento de imagens"
    results = await memory.asearch_memories(tools_set_id=tools_set_id, query=query, limit=1)

    # Assert that the most relevant document is returned and is in Portuguese
    assert len(results) > 0
    top_result = results[0]
    assert "reconhecimento de image" in top_result["description"]
