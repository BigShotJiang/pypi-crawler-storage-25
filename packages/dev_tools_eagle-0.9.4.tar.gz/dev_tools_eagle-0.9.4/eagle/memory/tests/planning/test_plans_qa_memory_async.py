import pytest
import asyncio
import hashlib
from eagle.memory.planning.plans_qa_memory import PlanDescriptorSchema
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


@pytest.mark.asyncio
async def test_async_put_and_get_memory(possible_qa_memory):
    memory = possible_qa_memory
    plans_set_id = "test-qa-plans-set"
    plan_id = "PlanQA1"
    question = "What is the capital of France?"
    plan = "Paris is the capital of France."
    short_description = "Capital cities knowledge"
    source = "GeographyBook"
    title = "France Capital"

    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    await memory.aput_memory(
        plans_set_id=plans_set_id,
        plan_id=plan_id,
        question=question,
        plan=plan,
        short_description=short_description,
        source=source,
        title=title
    )
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result == {
        "question": question,
        "plan": plan,
        "short_description": short_description,
        "source": source,
        "title": title,
        "type": "qa_plans",
    }

@pytest.mark.asyncio
async def test_async_delete_memory(possible_qa_memory):
    memory = possible_qa_memory
    plans_set_id = "test-qa-plans-set"
    plan_id = "PlanQA1"
    question = "What is the capital of France?"
    plan = "Paris is the capital of France."
    short_description = "Capital cities knowledge"
    source = "GeographyBook"
    title = "France Capital"

    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    await memory.aput_memory(
        plans_set_id=plans_set_id,
        plan_id=plan_id,
        question=question,
        plan=plan,
        short_description=short_description,
        source=source,
        title=title
    )
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result is not None

    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result is None

@pytest.mark.asyncio
async def test_async_search_memories(possible_qa_memory):
    memory = possible_qa_memory
    plans_set_id = "test-qa-plans-set"
    for plan in ["PlanQA1", "PlanQA2", "PlanQA3"]:
        await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan)

    plans_descriptors = [
        {
            "plan": "Paris is the capital of France.",
            "question": "What is the capital of France?",
            "short_description": "Capital cities knowledge",
            "source": "GeographyBook",
            "title": "France Capital"
        },
        {
            "plan": "The Amazon is the largest rainforest.",
            "question": "What is the largest rainforest?",
            "short_description": "Rainforest knowledge",
            "source": "BiologyBook",
            "title": "Amazon Rainforest"
        },
        {
            "plan": "Water boils at 100°C.",
            "question": "At what temperature does water boil?",
            "short_description": "Boiling point knowledge",
            "source": "ChemistryBook",
            "title": "Water Boiling"
        },
    ]
    await asyncio.gather(
        *(memory.aput_memory(
            plans_set_id=plans_set_id,
            plan_id=plan["plan"],
            question=plan["question"],
            plan=plan["plan"],
            short_description=plan["short_description"],
            source=plan["source"],
            title=plan["title"]
        ) for plan in plans_descriptors)
    )
    await asyncio.sleep(4)
    query = "rainforest"
    results = await memory.asearch_memories(plans_set_id=plans_set_id, query=query, limit=1)
    assert len(results) > 0
    assert any("rainforest" in result["question"].lower() for result in results)
    # Testa se o campo title está presente
    assert all("title" in result for result in results)

@pytest.mark.asyncio
async def test_async_search_memories_filter_title(possible_qa_memory):
    memory = possible_qa_memory
    plans_set_id = "test-qa-plans-set"
    for plan in ["PlanQA1", "PlanQA2", "PlanQA3"]:
        await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan)

    plans_descriptors = [
        {
            "plan": "Paris is the capital of France.",
            "question": "What is the capital of France?",
            "short_description": "Capital cities knowledge",
            "source": "GeographyBook",
            "title": "France Capital"
        },
        {
            "plan": "The Amazon is the largest rainforest.",
            "question": "What is the largest rainforest?",
            "short_description": "Rainforest knowledge",
            "source": "BiologyBook",
            "title": "Amazon Rainforest"
        },
        {
            "plan": "Water boils at 100°C.",
            "question": "At what temperature does water boil?",
            "short_description": "Boiling point knowledge",
            "source": "ChemistryBook",
            "title": "Water Boiling"
        },
    ]
    await asyncio.gather(
        *(memory.aput_memory(
            plans_set_id=plans_set_id,
            plan_id=plan["plan"],
            question=plan["question"],
            plan=plan["plan"],
            short_description=plan["short_description"],
            source=plan["source"],
            title=plan["title"]
        ) for plan in plans_descriptors)
    )
    await asyncio.sleep(2)
    # Filtro por title
    results = await memory.asearch_memories(plans_set_id=plans_set_id, filter_titles=["Amazon Rainforest"])
    assert len(results) == 1
    assert results[0]["title"] == "Amazon Rainforest"
    # Filtro múltiplo
    results = await memory.asearch_memories(plans_set_id=plans_set_id, filter_titles=["Amazon Rainforest", "Water Boiling"])
    assert len(results) == 2
    titles = [r["title"] for r in results]
    assert "Amazon Rainforest" in titles and "Water Boiling" in titles

@pytest.mark.asyncio
async def test_async_build_memory(possible_qa_memory):
    memory = possible_qa_memory
    plans_set_id = "test-qa-plans-set"
    for plan in ["PlanQA1", "PlanQA2", "PlanQA3"]:
        await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan)

    plans_descriptors = [
        {
            "plan": "Paris is the capital of France.",
            "question": "What is the capital of France?",
            "short_description": "Capital cities knowledge",
            "source": "GeographyBook",
            "title": "France Capital"
        },
        {
            "plan": "The Amazon is the largest rainforest.",
            "question": "What is the largest rainforest?",
            "short_description": "Rainforest knowledge",
            "source": "BiologyBook",
            "title": "Amazon Rainforest"
        },
        {
            "plan": "Water boils at 100°C.",
            "question": "At what temperature does water boil?",
            "short_description": "Boiling point knowledge",
            "source": "ChemistryBook",
            "title": "Water Boiling"
        },
    ]
    await memory.abuild(plans_set_id=plans_set_id, plans_descriptors=[PlanDescriptorSchema(**p) for p in plans_descriptors])
    await asyncio.sleep(4)
    for plan in plans_descriptors:
        plan_id = hashlib.sha256(plan["question"].encode("utf-8")).hexdigest()
        result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
        assert result is not None
        assert result["question"] == plan["question"]
        assert result["plan"] == plan["plan"]
        assert result["short_description"] == plan["short_description"]
        assert result["source"] == plan["source"]
        assert result["title"] == plan["title"]

    query = "boil"
    results = await memory.asearch_memories(plans_set_id=plans_set_id, query=query, limit=1)
    assert len(results) > 0
    assert any("boil" in result["question"].lower() for result in results)
    # Testa se o campo title está presente
    assert all("title" in result for result in results)

@pytest.mark.asyncio
async def test_async_multilevel_plans_set_id(possible_qa_memory):
    memory = possible_qa_memory
    plans_set_id = ("level1", "level2", "level3")
    plan_id = "PlanQAMulti"
    question = "A multi-level QA plan."
    plan = "Multi-level QA plan details"
    short_description = "Multi-level QA"
    source = "MultiSource"
    title = "MultiLevel Title"

    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    await memory.aput_memory(
        plans_set_id=plans_set_id,
        plan_id=plan_id,
        question=question,
        plan=plan,
        short_description=short_description,
        source=source,
        title=title
    )
    await asyncio.sleep(3)
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result == {
        "question": question,
        "plan": plan,
        "short_description": short_description,
        "source": source,
        "title": title,
        "type": "qa_plans",
    }
    results = await memory.asearch_memories(plans_set_id=plans_set_id, query="multi-level", limit=1)
    assert len(results) > 0
    assert any("multi-level" in result["plan"].lower() for result in results)
    # Testa filtro por title
    results = await memory.asearch_memories(plans_set_id=plans_set_id, filter_titles=["MultiLevel Title"])
    assert len(results) == 1
    assert results[0]["title"] == "MultiLevel Title"
    await memory.adelete_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    result = await memory.aget_memory(plans_set_id=plans_set_id, plan_id=plan_id)
    assert result is None
