import copy
import hashlib
import os
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import pytest

from eagle.memory.planning.possible_plans_memory import (  # ajuste se o path real for outro
    PossiblePlansMemory,
    PossiblePlansMemoryConfigSchema,
)

# ---------------------------------------------------------
# Fake store compatível com PlanningMemory/SharedMemoryBase
# ---------------------------------------------------------

@dataclass
class _FakeItem:
    key: str
    value: Dict[str, Any]


class _FakeStore:
    """
    Store fake com a API que as memórias base usam:
      - put/get/search/delete/delete_by_namespace
      - aput/aget/asearch/adelete/adelete_by_namespace
    """
    def __init__(self):
        self.db: Dict[Tuple[Tuple[Any, ...], str], _FakeItem] = {}

    def put(self, namespace: Tuple[Any, ...], key: str, value: Dict[str, Any], ttl: Optional[float] = None):
        self.db[(namespace, key)] = _FakeItem(key=key, value=copy.deepcopy(value))

    def get(self, namespace: Tuple[Any, ...], key: str) -> Optional[_FakeItem]:
        item = self.db.get((namespace, key))
        if item is None:
            return None
        return _FakeItem(key=item.key, value=copy.deepcopy(item.value))

    def delete(self, namespace: Tuple[Any, ...], key: str):
        self.db.pop((namespace, key), None)

    def delete_namespace(self, namespace_prefix: Tuple[Any, ...]):
        to_del = [k for k in self.db if k[0][: len(namespace_prefix)] == namespace_prefix]
        for k in to_del:
            self.db.pop(k, None)

    def delete_by_namespace(self, namespace_prefix: Tuple[Any, ...]):
        return self.delete_namespace(namespace_prefix)

    def search(
        self,
        namespace_prefix: Tuple[Any, ...],
        query: Optional[str] = None,
        filter: Optional[str] = None,
        limit: int = 10,
        offset: int = 0,
        sort: Optional[Dict[str, str]] = None,
    ) -> List[_FakeItem]:
        # 1) namespace
        items = [
            item
            for (ns, _), item in self.db.items()
            if ns[: len(namespace_prefix)] == namespace_prefix
        ]

        # 2) filtro DSL mínima: eq("value.type","...") e or(eq("value.source","A"),...)
        if filter:
            # type fixo
            required_type = None
            m = re.search(r'eq\("value\.type",\s*"([^"]+)"\)', filter)
            if m:
                required_type = m.group(1)

            allowed_sources = set(re.findall(r'eq\("value\.source",\s*"([^"]+)"\)', filter))

            def _ok(it: _FakeItem) -> bool:
                ok_type = True if required_type is None else it.value.get("type") == required_type
                ok_source = True if not allowed_sources else it.value.get("source") in allowed_sources
                # quando vem os dois, o filtro é and(...)
                return ok_type and ok_source

            items = [it for it in items if _ok(it)]

        # 3) query (bem simples): se query existe, casa em question/plan/source
        if query:
            q = query.lower()
            def _match(it: _FakeItem) -> bool:
                return (
                    q in (it.value.get("question") or "").lower()
                    or q in (it.value.get("plan") or "").lower()
                    or q in (it.value.get("source") or "").lower()
                )
            items = [it for it in items if _match(it)]

        paged = items[offset : offset + limit]
        return [_FakeItem(key=it.key, value=copy.deepcopy(it.value)) for it in paged]

    # ---- async ----
    async def aput(self, namespace: Tuple[Any, ...], key: str, value: Dict[str, Any], ttl: Optional[float] = None):
        self.put(namespace, key, value, ttl)

    async def aget(self, namespace: Tuple[Any, ...], key: str) -> Optional[_FakeItem]:
        return self.get(namespace, key)

    async def adelete(self, namespace: Tuple[Any, ...], key: str):
        self.delete(namespace, key)

    async def adelete_namespace(self, namespace_prefix: Tuple[Any, ...]):
        self.delete_namespace(namespace_prefix)

    async def adelete_by_namespace(self, namespace_prefix: Tuple[Any, ...]):
        return await self.adelete_namespace(namespace_prefix)

    async def asearch(
        self,
        namespace_prefix: Tuple[Any, ...],
        query: Optional[str] = None,
        filter: Optional[str] = None,
        limit: int = 10,
        offset: int = 0,
        sort: Optional[Dict[str, str]] = None,
    ) -> List[_FakeItem]:
        return self.search(namespace_prefix, query=query, filter=filter, limit=limit, offset=offset, sort=sort)


# -----------------------------
# Fixtures
# -----------------------------

@pytest.fixture()
def fake_store():
    return _FakeStore()


@pytest.fixture()
def memory(monkeypatch, fake_store):
    # patcha a criação do store na classe base (mesma estratégia do outro teste)
    base_with_create = next(cls for cls in PossiblePlansMemory.__mro__ if hasattr(cls, "_create_store"))
    monkeypatch.setattr(
        base_with_create,
        "_create_store",
        lambda self, store_class, embedding_model, embedding_dims, embedding_name: fake_store,
        raising=True,
    )

    class DummyEmbeddings:
        pass

    class DummyStore:
        pass

    return PossiblePlansMemory(
        store_class=DummyStore,
        embedding_model=DummyEmbeddings(),
        embedding_dims=8,
        embedding_name="dummy-emb",
    )


# -----------------------------
# Tests: namespace helper
# -----------------------------

def test_get_namespace_with_str(memory):
    assert memory._get_namespace("set1") == (memory.MEMORY_NAME, "set1")


def test_get_namespace_with_tuple(memory):
    assert memory._get_namespace(("tenant", "set1")) == (memory.MEMORY_NAME, "tenant", "set1")


# -----------------------------
# Tests: config schema validation
# -----------------------------

def test_config_allows_none_llm():
    c = PossiblePlansMemoryConfigSchema(chain_llm=None)
    assert c.chain_llm is None


def test_config_rejects_non_llm_object():
    class NotLLM:
        pass

    with pytest.raises(TypeError):
        PossiblePlansMemoryConfigSchema(chain_llm=NotLLM())


# -----------------------------
# Tests: put/get/delete
# -----------------------------

def test_put_get_delete_roundtrip(memory):
    memory.put_memory("set1", "p1", "Q1", "Plan 1", "srcA", ttl=1)

    got = memory.get_memory("set1", "p1")
    assert got is not None
    assert got["question"] == "Q1"
    assert got["plan"] == "Plan 1"
    assert got["source"] == "srcA"
    assert got["type"] == "possible_plans_memory"

    memory.delete_memory("set1", "p1")
    assert memory.get_memory("set1", "p1") is None


@pytest.mark.asyncio
async def test_aput_aget_adelete_roundtrip(memory):
    await memory.aput_memory("set1", "p1", "Q1", "Plan 1", "srcA", ttl=1)

    got = await memory.aget_memory("set1", "p1")
    assert got is not None
    assert got["question"] == "Q1"

    await memory.adelete_memory("set1", "p1")
    assert await memory.aget_memory("set1", "p1") is None


def test_delete_memories_by_namespace(memory):
    memory.put_memory("set1", "p1", "Q1", "Plan 1", "srcA")
    memory.put_memory("set1", "p2", "Q2", "Plan 2", "srcB")

    memory.delete_memories_by_namespace("set1")
    assert memory.get_memory("set1", "p1") is None
    assert memory.get_memory("set1", "p2") is None


# -----------------------------
# Tests: search / asearch (filtros + query)
# -----------------------------

def test_search_memories_filters_by_source_and_type(memory):
    # type é sempre "possible_plans_memory" (a classe garante) – testamos o filtro do search
    memory.put_memory("set1", "p1", "como fazer X", "passo a passo", "srcA")
    memory.put_memory("set1", "p2", "como fazer Y", "passo a passo", "srcB")

    res = memory.search_memories("set1", query="fazer", filter_sources=["srcA"])
    assert len(res) == 1
    assert res[0]["source"] == "srcA"
    assert res[0]["type"] == "possible_plans_memory"


@pytest.mark.asyncio
async def test_asearch_memories_filters_by_source(memory):
    memory.put_memory("set1", "p1", "Q1", "Plan 1", "srcA")
    memory.put_memory("set1", "p2", "Q2", "Plan 2", "srcB")

    res = await memory.asearch_memories("set1", query="Plan", filter_sources=["srcB"])
    assert len(res) == 1
    assert res[0]["source"] == "srcB"


# -----------------------------
# Tests: build / abuild caminho simples (chain_llm=None)
# -----------------------------

def test_build_with_chain_llm_none_inserts_using_hash(memory):
    descriptors = [
        {"plan": "Plano A", "question": "Pergunta A", "source": "S1"},
        {"plan": "Plano B", "question": "Pergunta B", "source": "S2"},
    ]

    memory.build(plans_set_id="set1", plans_descriptors=descriptors, config={"chain_llm": None})

    pida = hashlib.sha256("Pergunta A".encode("utf-8")).hexdigest()
    pidb = hashlib.sha256("Pergunta B".encode("utf-8")).hexdigest()

    a = memory.get_memory("set1", pida)
    b = memory.get_memory("set1", pidb)

    assert a is not None and a["plan"] == "Plano A" and a["source"] == "S1"
    assert b is not None and b["plan"] == "Plano B" and b["source"] == "S2"


@pytest.mark.asyncio
async def test_abuild_with_chain_llm_none_inserts_using_hash(monkeypatch, memory):
    # evita asyncio.sleep(1) no abuild
    import eagle.memory.planning.possible_plans_memory as module_under_test
    monkeypatch.setattr(module_under_test.asyncio, "sleep", lambda *_args, **_kwargs: asyncio_sleep_noop())

    descriptors = [
        {"plan": "Plano A", "question": "Pergunta A", "source": "S1"},
        {"plan": "Plano B", "question": "Pergunta B", "source": "S2"},
    ]

    await memory.abuild(
        plans_set_id="set1",
        plans_descriptors=descriptors,
        config={"chain_llm": None, "k_review_candidates": 5, "rounds": 1},
    )

    pida = hashlib.sha256("Pergunta A".encode("utf-8")).hexdigest()
    pidb = hashlib.sha256("Pergunta B".encode("utf-8")).hexdigest()

    assert await memory.aget_memory("set1", pida) is not None
    assert await memory.aget_memory("set1", pidb) is not None


# helper para monkeypatch do sleep
async def asyncio_sleep_noop():
    return None
