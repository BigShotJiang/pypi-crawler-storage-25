from eagle.agents.agent_memory.planning_memory.todo_list_planning_memory import ToDoListPlanningAgentMemory, ToDoListSchemaEN
from langchain_core.messages import HumanMessage, AIMessage
from eagle.memory.tests.conftest import TESTS_LLM_MODEL_NAME
from eagle.models.generators import get_llm_model
import pytest
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]

class DummyLLM:
    def __call__(self, *args, **kwargs):
        return self

    def invoke(self, inputs):
        # Retorna um plano de to-do list no schema esperado (EN)
        return {
            "tasks": [
                {
                    "description": "Define project requirements",
                    "status": "Pending",
                    "annotations": "",
                },
                {
                    "description": "Develop initial prototype",
                    "status": "Completed",
                    "annotations": "Prototype finished and reviewed.",
                },
                {
                    "description": "Test prototype with users",
                    "status": "Problematic",
                    "annotations": "User feedback indicates major issues.",
                },
            ]
        }


class DummyState:
    def __init__(self, messages, observation, plan):
        self.messages = messages
        self.observation = observation
        self.plan = plan


def test_todo_list_planning_agent_memory_manifest():
    """
    Test the ToDoListPlanningMemory manifest_memory functionality.
    """
    # Instancia a memória com o LLM mockado
    todo_list_planning_memory = ToDoListPlanningAgentMemory(llm=DummyLLM())
    # Usa HumanMessage e AIMessage do langchain
    messages = [
        HumanMessage(content="Start project"),
        AIMessage(content="Project started"),
    ]
    state = DummyState(
        messages=messages,
        observation="Initial observation",
        plan="Initial plan",
    )
    config = {
        "configurable": {
            "plan_node_llm_prompt_language": "en",
            "chat_history_window_size": 5,
        }
    }
    # Força o plano para garantir que manifest_memory funcione isoladamente
    todo_list_planning_memory._plan = {
        "tasks": [
            {
                "description": "Define project requirements",
                "status": "Pending",
                "annotations": "",
            },
            {
                "description": "Develop initial prototype",
                "status": "Completed",
                "annotations": "Prototype finished and reviewed.",
            },
            {
                "description": "Test prototype with users",
                "status": "Problematic",
                "annotations": "User feedback indicates major issues.",
            },
        ]
    }
    result = todo_list_planning_memory.manifest_memory(state, config, "plan_node")
    assert result == '\n------------ Plan to be Executed -------------\nTask List:\n- Description: Define project requirements\n  Status: Pending\n  Annotations: \n- Description: Develop initial prototype\n  Status: Completed\n  Annotations: Prototype finished and reviewed.\n- Description: Test prototype with users\n  Status: Problematic\n  Annotations: User feedback indicates major issues.\n----------------------------------------------'

def test_todo_list_planning_agent_memory_store_en():

    """
    Test the ToDoListPlanningMemory store_memory functionality.
    """
    # Instancia a memória com o LLM mockado
    todo_list_planning_memory = ToDoListPlanningAgentMemory(
        llm=get_llm_model(
            model_name=TESTS_LLM_MODEL_NAME,
            temperature=0,
            max_tokens=2000
        )
    )

    # Usa HumanMessage e AIMessage do langchain
    messages = [
        HumanMessage(content="How can we get to the moon?", name="user"),
        AIMessage(content="First, we need to gather financial resources. Then, we need to buy the rocket and, finally, we can fly to the moon.", name="assistant"),
        HumanMessage(content="Great! I've already got the money needed.", name="user")
    ]
    state = DummyState(
        messages=messages,
        observation="Initial observation",
        plan="Initial plan",
    )
    config = {
        "configurable": {
            "plan_node_llm_prompt_language": "en",
            "chat_history_window_size": 5,
        }
    }
    # Armazena a memória
    todo_list_planning_memory.store_memory(state, config, "plan_node")
    # Verifica se o plano foi armazenado corretamente
    assert isinstance(todo_list_planning_memory._plan, ToDoListSchemaEN)
    assert len(todo_list_planning_memory._plan.tasks) >= 3
    assert todo_list_planning_memory._plan.tasks[0].status == "Completed"
    assert "financial" in todo_list_planning_memory._plan.tasks[0].description.lower()

def test_todo_list_planning_agent_memory_store_pt_br():

    """
    Test the ToDoListPlanningMemory store_memory functionality.
    """
    # Instancia a memória com o LLM mockado
    todo_list_planning_memory = ToDoListPlanningAgentMemory(
        llm=get_llm_model(
            model_name=TESTS_LLM_MODEL_NAME,
            temperature=0,
            max_tokens=2000
        )
    )

    # Usa HumanMessage e AIMessage do langchain
    messages = [
        HumanMessage(content="Como podemos chegar à Lua?", name="user"),
        AIMessage(content="Primeiro, precisamos reunir recursos financeiros. Depois, precisamos comprar o foguete e, finalmente, podemos voar para a Lua.", name="assistant"),
        HumanMessage(content="Ótimo! Já consegui o dinheiro necessário.", name="user")
    ]
    state = DummyState(
        messages=messages,
        observation="Initial observation",
        plan="Initial plan",
    )
    config = {
        "configurable": {
            "plan_node_llm_prompt_language": "pt-br",
            "chat_history_window_size": 5,
        }
    }
    # Armazena a memória
    todo_list_planning_memory.store_memory(state, config, "plan_node")
    # Verifica se o plano foi armazenado corretamente
    assert isinstance(todo_list_planning_memory._plan, ToDoListSchemaEN)
    assert len(todo_list_planning_memory._plan.tasks) >= 3
    assert todo_list_planning_memory._plan.tasks[0].status == "Completed"
    assert "financeiro" in todo_list_planning_memory._plan.tasks[0].description.lower()