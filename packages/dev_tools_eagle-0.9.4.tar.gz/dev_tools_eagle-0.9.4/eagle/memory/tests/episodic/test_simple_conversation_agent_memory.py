from eagle.agents.agent_memory.conversation_memory.simple_conversation_memory import SimpleConversationAgentMemory
from langchain_core.messages import HumanMessage, AIMessage
from datetime import datetime, timedelta
import uuid
import pytest
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]

class DummyState:
    def __init__(self, messages, interaction_initial_datetime):
        self.messages = messages
        self.interaction_initial_datetime = interaction_initial_datetime

def _make_msgs_ptbr():
    # 3 mensagens: duas antigas, uma atual
    return [
        HumanMessage(content="Olá!", name="user", id=str(uuid.uuid4())),
        AIMessage(content="Oi, como posso ajudar?", name="assistant", id=str(uuid.uuid4())),
        HumanMessage(content="Quero saber sobre o tempo.", name="user", id=str(uuid.uuid4())),
    ]

def _make_msgs_en():
    return [
        HumanMessage(content="Hello!", name="user", id=str(uuid.uuid4())),
        AIMessage(content="Hi, how can I help?", name="assistant", id=str(uuid.uuid4())),
        HumanMessage(content="I want to know about the weather.", name="user", id=str(uuid.uuid4())),
    ]

def test_store_and_manifest_memory_pt_br():
    mem = SimpleConversationAgentMemory(chat_history_window_size=5)
    now = datetime.utcnow()
    interaction_initial_datetime = now - timedelta(seconds=1)
    msgs = _make_msgs_ptbr()
    # Simula timestamps: as duas primeiras são antigas, a última é atual
    mem._messages = [
        {"id": msgs[0].id, "name": "user", "type": "human", "content": "Olá!", "timestamp": now - timedelta(minutes=10)},
        {"id": msgs[1].id, "name": "assistant", "type": "ai", "content": "Oi, como posso ajudar?", "timestamp": now - timedelta(minutes=9)},
    ]
    state = DummyState(messages=msgs, interaction_initial_datetime=interaction_initial_datetime)
    config = {
        "configurable": {
            "chat_history_window_size": 5,
            "main_node_llm_prompt_language": "pt-br"
        }
    }
    # Adiciona a mensagem atual
    mem.store_memory(state, config, "observe_node", step="start")
    result = mem.manifest_memory(state, config, "main_node")
    # Mensagens antigas devem aparecer em "interações passadas", a última em "interação atual"
    assert "De interações passadas" in result
    assert "Da interação atual" in result
    assert "Olá!" in result
    assert "Quero saber sobre o tempo." in result
    assert "[20" in result  # timestamp
    # Checa se a mensagem mais recente está na seção correta
    idx_atual = result.index("Da interação atual")
    idx_passada = result.index("De interações passadas")
    assert idx_atual > idx_passada

def test_store_and_manifest_memory_en():
    mem = SimpleConversationAgentMemory(chat_history_window_size=5)
    now = datetime.utcnow()
    interaction_initial_datetime = now - timedelta(seconds=1)
    msgs = _make_msgs_en()
    mem._messages = [
        {"id": msgs[0].id, "name": "user", "type": "human", "content": "Hello!", "timestamp": now - timedelta(minutes=10)},
        {"id": msgs[1].id, "name": "assistant", "type": "ai", "content": "Hi, how can I help?", "timestamp": now - timedelta(minutes=9)},
    ]
    state = DummyState(messages=msgs, interaction_initial_datetime=interaction_initial_datetime)
    config = {
        "configurable": {
            "chat_history_window_size": 5,
            "main_node_llm_prompt_language": "en"
        }
    }
    mem.store_memory(state, config, "main_node", step="start")
    result = mem.manifest_memory(state, config, "main_node")
    assert "From past interactions" in result
    assert "From current interaction" in result
    assert "Hello!" in result
    assert "I want to know about the weather." in result
    # Checa se a mensagem mais recente está na seção correta
    idx_current = result.index("From current interaction")
    idx_past = result.index("From past interactions")
    assert idx_current > idx_past

def test_manifest_memory_window_size():
    mem = SimpleConversationAgentMemory(chat_history_window_size=2)
    now = datetime.utcnow()
    interaction_initial_datetime = now - timedelta(seconds=1)
    msgs = [
        HumanMessage(content="msg1", name="user", id=str(uuid.uuid4())),
        AIMessage(content="msg2", name="assistant", id=str(uuid.uuid4())),
        HumanMessage(content="msg3", name="user", id=str(uuid.uuid4())),
    ]
    mem._messages = [
        {"id": msgs[0].id, "name": "user", "type": "human", "content": "msg1", "timestamp": now - timedelta(minutes=10)},
        {"id": msgs[1].id, "name": "assistant", "type": "ai", "content": "msg2", "timestamp": now - timedelta(minutes=9)},
        {"id": msgs[2].id, "name": "user", "type": "human", "content": "msg3", "timestamp": now},
    ]
    state = DummyState(messages=msgs, interaction_initial_datetime=interaction_initial_datetime)
    config = {
        "configurable": {
            "chat_history_window_size": 2,
            "main_node_llm_prompt_language": "en"
        }
    }
    result = mem.manifest_memory(state, config, "main_node")
    # Só as duas últimas mensagens aparecem
    assert "msg1" not in result
    assert "msg2" in result
    assert "msg3" in result
