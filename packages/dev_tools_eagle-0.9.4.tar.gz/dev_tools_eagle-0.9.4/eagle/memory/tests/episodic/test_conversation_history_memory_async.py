import pytest
import asyncio
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]

@pytest.mark.asyncio
async def test_async_put_memory(conversation_history_memory):
    chat_id = "chat123"
    memory_id = "memory456"
    messages = [{"role": "user", "content": "Hello"}]
    description = "Test memory"

    await conversation_history_memory.aput_memory(chat_id, memory_id, messages, description)

    result = await conversation_history_memory.aget_memory(chat_id, memory_id)
    assert result == {"messages": messages, "description": description, "type": "conversation_history"}

@pytest.mark.asyncio
async def test_async_get_memory_not_found(conversation_history_memory):
    chat_id = "chat123"
    memory_id = "nonexistent"

    result = await conversation_history_memory.aget_memory(chat_id, memory_id)
    assert result is None

@pytest.mark.asyncio
async def test_async_delete_memory(conversation_history_memory):
    chat_id = "chat123"
    memory_id = "memory456"
    messages = [{"role": "user", "content": "Hello"}]
    description = "Test memory"

    await conversation_history_memory.aput_memory(chat_id, memory_id, messages, description)
    await conversation_history_memory.adelete_memory(chat_id, memory_id)

    result = await conversation_history_memory.aget_memory(chat_id, memory_id)
    assert result is None

@pytest.mark.asyncio
async def test_async_search_memories(conversation_history_memory):
    chat_id = "chat123"

    # Conjunto 1: Assunto sobre tecnologia
    memory1_id = "memory1"
    messages1 = [
        {"role": "user", "content": "What is the latest in AI?"},
        {"role": "assistant", "content": "AI is advancing rapidly in natural language processing."}
    ]
    description1 = "Discussion about artificial intelligence advancements"

    # Conjunto 2: Assunto sobre culinária
    memory2_id = "memory2"
    messages2 = [
        {"role": "user", "content": "How do I bake a cake?"},
        {"role": "assistant", "content": "You need flour, eggs, sugar, and butter."}
    ]
    description2 = "Conversation about baking recipes"

    # Conjunto 3: Assunto sobre esportes
    memory3_id = "memory3"
    messages3 = [
        {"role": "user", "content": "Who won the last World Cup?"},
        {"role": "assistant", "content": "Argentina won the last World Cup."}
    ]
    description3 = "Chat about recent sports events"

    # Adiciona as memórias
    await asyncio.gather(
        conversation_history_memory.aput_memory(chat_id, memory1_id, messages1, description1),
        conversation_history_memory.aput_memory(chat_id, memory2_id, messages2, description2),
        conversation_history_memory.aput_memory(chat_id, memory3_id, messages3, description3),
    )

    await asyncio.sleep(3)  # Aguarda a indexação

    # Busca 1: Query sobre inteligência artificial
    results = await conversation_history_memory.asearch_memories(chat_id, query="AI advancements", limit=1)
    assert len(results) == 1
    assert results[0] == {"messages": messages1, "description": description1, "type": "conversation_history"}

    # Busca 2: Query sobre receitas de bolo
    results = await conversation_history_memory.asearch_memories(chat_id, query="baking a cake", limit=1)
    assert len(results) == 1
    assert results[0] == {"messages": messages2, "description": description2, "type": "conversation_history"}

    # Busca 3: Query sobre esportes
    results = await conversation_history_memory.asearch_memories(chat_id, query="recent sports events", limit=1)
    assert len(results) == 1
    assert results[0] == {"messages": messages3, "description": description3, "type": "conversation_history"}
