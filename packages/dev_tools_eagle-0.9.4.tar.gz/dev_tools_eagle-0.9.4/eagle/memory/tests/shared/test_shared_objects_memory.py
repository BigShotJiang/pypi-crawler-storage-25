import copy
import json
import os
import pickle
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import pytest

from eagle.memory.shared.shared_objects_memory import (
    SharedObjectsMemory,
    generate_summary_with_processing_history,
)


@dataclass
class _FakeItem:
    key: str
    value: Dict[str, Any]


class _FakeStore:
    """
    FakeStore compatível com eagle.memory.base.SharedMemoryBase.

    Pelo stacktrace, o base chama:
      - self.store.put(...)
      - self.store.get(...)
      - self.store.search(...)
      - self.store.delete(...)
      - self.store.delete_by_namespace(...)

    E variantes async:
      - aput/aget/asearch/adelete
    """
    def __init__(self):
        self.db: Dict[Tuple[Tuple[Any, ...], str], _FakeItem] = {}

    def put(self, namespace: Tuple[Any, ...], key: str, value: Dict[str, Any], ttl: Optional[float] = None):
        self.db[(namespace, key)] = _FakeItem(key=key, value=copy.deepcopy(value))

    def get(self, namespace: Tuple[Any, ...], key: str) -> Optional[_FakeItem]:
        item = self.db.get((namespace, key))
        if item is None:
            return None
        return _FakeItem(key=item.key, value=copy.deepcopy(item.value))

    def delete(self, namespace: Tuple[Any, ...], key: str):
        self.db.pop((namespace, key), None)

    def delete_namespace(self, namespace_prefix: Tuple[Any, ...]):
        to_del = [k for k in self.db if k[0][: len(namespace_prefix)] == namespace_prefix]
        for k in to_del:
            self.db.pop(k, None)

    def delete_by_namespace(self, namespace_prefix: Tuple[Any, ...]):
        return self.delete_namespace(namespace_prefix)

    def search(
        self,
        namespace_prefix: Tuple[Any, ...],
        query: Optional[str] = None,
        filter: Optional[str] = None,
        limit: int = 10,
        offset: int = 0,
        sort: Optional[Dict[str, str]] = None,
    ) -> List[_FakeItem]:
        items = [
            item
            for (ns, _), item in self.db.items()
            if ns[: len(namespace_prefix)] == namespace_prefix
        ]

        # DSL mínima suficiente pro filtro gerado pela SharedObjectsMemory:
        # or(eq("value.object_type","X"),...) e or(eq("value.object_id","Y"),...) dentro de and(...)
        if filter:
            allowed_types = set(re.findall(r'eq\("value\.object_type",\s*"([^"]+)"\)', filter))
            allowed_ids = set(re.findall(r'eq\("value\.object_id",\s*"([^"]+)"\)', filter))

            def _ok(it: _FakeItem) -> bool:
                ok_type = True if not allowed_types else it.value.get("object_type") in allowed_types
                ok_id = True if not allowed_ids else it.value.get("object_id") in allowed_ids
                # quando vem os dois, o filtro é and(...)
                if allowed_types and allowed_ids:
                    return ok_type and ok_id
                return ok_type and ok_id

            items = [it for it in items if _ok(it)]

        # sort: {"value.created_at": "desc"}
        if sort and "value.created_at" in sort:
            reverse = sort["value.created_at"].lower() == "desc"
            items.sort(key=lambda it: it.value.get("created_at", 0), reverse=reverse)

        paged = items[offset : offset + limit]
        return [_FakeItem(key=it.key, value=copy.deepcopy(it.value)) for it in paged]

    async def aput(self, namespace: Tuple[Any, ...], key: str, value: Dict[str, Any], ttl: Optional[float] = None):
        self.put(namespace, key, value, ttl)

    async def aget(self, namespace: Tuple[Any, ...], key: str) -> Optional[_FakeItem]:
        return self.get(namespace, key)

    async def adelete(self, namespace: Tuple[Any, ...], key: str):
        self.delete(namespace, key)

    async def adelete_namespace(self, namespace_prefix: Tuple[Any, ...]):
        self.delete_namespace(namespace_prefix)

    async def adelete_by_namespace(self, namespace_prefix: Tuple[Any, ...]):
        return await self.adelete_namespace(namespace_prefix)

    async def asearch(
        self,
        namespace_prefix: Tuple[Any, ...],
        query: Optional[str] = None,
        filter: Optional[str] = None,
        limit: int = 10,
        offset: int = 0,
        sort: Optional[Dict[str, str]] = None,
    ) -> List[_FakeItem]:
        return self.search(namespace_prefix, query=query, filter=filter, limit=limit, offset=offset, sort=sort)


@pytest.fixture()
def fake_store():
    return _FakeStore()


@pytest.fixture()
def memory(tmp_path, monkeypatch, fake_store):
    import eagle.memory.shared.shared_objects_memory as module_under_test
    monkeypatch.setattr(module_under_test, "sleep", lambda _: None)

    base_with_create = next(cls for cls in SharedObjectsMemory.__mro__ if hasattr(cls, "_create_store"))
    monkeypatch.setattr(
        base_with_create,
        "_create_store",
        lambda self, store_class, embedding_model, embedding_dims, embedding_name: fake_store,
        raising=True,
    )

    class DummyEmbeddings:
        pass

    class DummyStore:
        pass

    mem = SharedObjectsMemory(
        store_class=DummyStore,
        embedding_model=DummyEmbeddings(),
        embedding_dims=8,
        storage_dir=str(tmp_path),
        embedding_name="dummy-emb",
    )
    return mem


def _read_pickle(path: str) -> Any:
    with open(path, "rb") as f:
        return pickle.load(f)

def test_build_namespace_without_additional_levels(memory):
    ns = memory._build_namespace("chat1", None)
    assert ns == (memory.MEMORY_NAME, "chat1")


def test_build_namespace_with_additional_levels(memory):
    ns = memory._build_namespace("chat1", ("levelA", "levelB"))
    assert ns == (memory.MEMORY_NAME, "chat1", "levelA", "levelB")

def test_put_memory_stores_pickle_and_metadata(memory):
    obj = {"x": 1}
    object_id = memory.put_memory(
        chat_id="c1",
        object_name="meu_obj",
        obj=obj,
        description="desc",
        object_type="dict",
        function_generator="func-123",
        objects_args=["a1", "a2"],
        function_generator_kwargs={"k": 10},
        ttl=None,
    )

    ns = (memory.MEMORY_NAME, "c1")
    item = memory.store.get(ns, object_id)
    assert item is not None
    assert item.value["object_id"] == object_id
    assert item.value["name"] == "meu_obj"
    assert item.value["object_type"] == "dict"
    assert item.value["function_generator"] == "func-123"
    assert item.value["objects_args"] == ["a1", "a2"]

    assert isinstance(item.value["function_generator_kwargs"], str)
    assert json.loads(item.value["function_generator_kwargs"]) == {"k": 10}

    disk_path = item.value["disk_path"]
    assert os.path.exists(disk_path)
    assert _read_pickle(disk_path) == obj


def test_put_memory_python_callable_stores_source_and_clears_generator_fields(memory):
    def my_fun(a: int) -> int:
        return a + 1

    object_id = memory.put_memory(
        chat_id="c1",
        object_name="minha_func",
        obj=my_fun,
        description="func desc",
        object_type="python-callable",
        function_generator="should_be_cleared",
        objects_args=["x"],
        function_generator_kwargs={"a": 1},
    )

    ns = (memory.MEMORY_NAME, "c1")
    item = memory.store.get(ns, object_id)
    assert item is not None

    # python-callable: limpa generator fields
    assert item.value["function_generator"] is None
    assert item.value["objects_args"] == []

    code = _read_pickle(item.value["disk_path"])
    assert isinstance(code, str)
    assert "def my_fun" in code


def test_get_memory_loads_object_and_parses_kwargs_json(memory):
    obj = [1, 2, 3]
    object_id = memory.put_memory(
        chat_id="c1",
        object_name="lista",
        obj=obj,
        description="desc",
        object_type="list",
        function_generator_kwargs={"x": "y"},
    )

    got = memory.get_memory(chat_id="c1", object_id=object_id)
    assert got is not None
    assert got.object == obj
    assert got.metadata.object_id == object_id
    assert got.metadata.function_generator_kwargs == {"x": "y"}


def test_search_memories_filter_types_and_ids_combined(memory):
    _ = memory.put_memory("c1", "obj1", {"a": 1}, "d1", "typeA")
    id2 = memory.put_memory("c1", "obj2", {"a": 2}, "d2", "typeB")

    res = memory.search_memories(
        "c1",
        filter_object_types=["typeB"],
        filter_object_ids=[id2],
        limit=10,
    )
    assert [r.metadata.object_id for r in res] == [id2]


def test_get_memory_object_returns_first_match(memory):
    oid = memory.put_memory("c1", "x", 123, "d", "number")
    obj = memory.get_memory_object("c1", oid)
    assert obj is not None
    assert obj.metadata.object_id == oid
    assert obj.object == 123


def test_get_memory_metadata_returns_metadata(memory):
    oid = memory.put_memory("c1", "x", 123, "d", "number")
    meta = memory.get_memory_metadata("c1", oid)
    assert meta is not None
    assert meta.object_id == oid
    assert meta.name == "x"
    assert meta.object_type == "number"


def test_delete_memory_when_missing_does_not_crash(memory):
    memory.delete_memory("c1", "does-not-exist")


def test_delete_memories_by_namespace_with_additional_levels(memory):
    oid = memory.put_memory(
        "c1", "x", 1, "d", "number", additional_namespace_levels=("tenant1",)
    )

    ns = (memory.MEMORY_NAME, "c1", "tenant1")
    item = memory.store.get(ns, oid)
    assert item is not None
    assert os.path.exists(item.value["disk_path"])

    memory.delete_memories_by_namespace("c1", additional_namespace_levels=("tenant1",))

    assert memory.store.get(ns, oid) is None
    assert not os.path.exists(item.value["disk_path"])


def test_generate_summary_from_object_ids_includes_dependencies(memory):
    def f(a: int, b: int) -> int:
        return a + b

    fid = memory.put_memory("c1", "somar", f, "Soma", "python-callable")
    a_id = memory.put_memory("c1", "a", 10, "primeiro", "number")
    b_id = memory.put_memory("c1", "b", 20, "segundo", "number")

    out_id = memory.put_memory(
        "c1",
        "resultado",
        30,
        "a+b",
        "number",
        function_generator=fid,
        objects_args=[a_id, b_id],
        function_generator_kwargs={"modo": "rapido"},
    )

    text = memory.generate_summary_from_object_ids("c1", [out_id], language="pt-br")
    assert "Lista de objetos:" in text
    assert "resultado" in text
    assert "somar" in text
    assert "a" in text
    assert "b" in text


@pytest.mark.asyncio
async def test_adelete_memory_removes_file(memory):
    oid = await memory.aput_memory("c1", "x", {"k": 1}, "d", "dict")
    got = await memory.aget_memory("c1", oid)
    assert got is not None
    disk_path = got.metadata.disk_path
    assert os.path.exists(disk_path)

    await memory.adelete_memory("c1", oid)
    assert not os.path.exists(disk_path)

def test_generate_summary_with_processing_history_basic_ptbr():
    now_ms = 1_700_000_000_000
    objects = [
        {
            "object_id": "f1",
            "object_type": "python-callable",
            "SharedObjectMetadata": {
                "name": "somar",
                "description": "Soma dois números",
                "object_type": "python-callable",
                "disk_path": "/tmp/f1.pkl",
                "object_id": "f1",
                "function_generator": None,
                "objects_args": [],
                "function_generator_kwargs": {},
                "created_at": now_ms,
            },
            "function_generator": None,
            "objects_args": [],
            "function_generator_kwargs": {},
            "object": "def somar(a,b):\n    return a+b",
        },
        {
            "object_id": "n1",
            "object_type": "number",
            "SharedObjectMetadata": {
                "name": "x",
                "description": "primeiro número",
                "object_type": "number",
                "disk_path": "/tmp/n1.pkl",
                "object_id": "n1",
                "function_generator": None,
                "objects_args": [],
                "function_generator_kwargs": {},
                "created_at": now_ms + 1,
            },
            "function_generator": None,
            "objects_args": [],
            "function_generator_kwargs": {},
            "object": 10,
        },
        {
            "object_id": "n2",
            "object_type": "number",
            "SharedObjectMetadata": {
                "name": "y",
                "description": "segundo número",
                "object_type": "number",
                "disk_path": "/tmp/n2.pkl",
                "object_id": "n2",
                "function_generator": None,
                "objects_args": [],
                "function_generator_kwargs": {},
                "created_at": now_ms + 2,
            },
            "function_generator": None,
            "objects_args": [],
            "function_generator_kwargs": {},
            "object": 20,
        },
        {
            "object_id": "out",
            "object_type": "number",
            "SharedObjectMetadata": {
                "name": "resultado",
                "description": "x+y",
                "object_type": "number",
                "disk_path": "/tmp/out.pkl",
                "object_id": "out",
                "function_generator": "f1",
                "objects_args": ["n1", "n2"],
                "function_generator_kwargs": {"modo": "rapido"},
                "created_at": now_ms + 3,
            },
            "function_generator": "f1",
            "objects_args": ["n1", "n2"],
            "function_generator_kwargs": {"modo": "rapido"},
            "object": 30,
        },
    ]

    text = generate_summary_with_processing_history(objects, language="pt_br")
    assert "Lista de objetos:" in text
    assert "Etapas de processamento:" in text
    assert "Funções utilizadas:" in text
    assert "somar" in text
    assert "resultado" in text
    assert "```python" in text
