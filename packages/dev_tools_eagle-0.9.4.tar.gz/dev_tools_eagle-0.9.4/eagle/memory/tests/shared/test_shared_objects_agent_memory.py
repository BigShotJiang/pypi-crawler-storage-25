import pandas as pd
from time import sleep
from eagle.agents.agent_memory.shared_memory.shared_objects_memory import SharedObjectsAgentMemory
from eagle.agents.react_agent.base import ReactPlanningAgentWorkingMemoryState
import pytest
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


def test_shared_objects_agent_memory_no_must_cite(shared_objects_memory):
    """
    Test the SharedObjectsAgentMemory functionality.
    """
    shared_objects_agent_memory = SharedObjectsAgentMemory(
        shared_memory=shared_objects_memory,
        include_must_cite=False
    )

    # Config and state for testing
    state = ReactPlanningAgentWorkingMemoryState()
    config = {
        "configurable": {
            "chat_id": "12345",
            "chat_history_window_size": 15,
            "observe_shared_objects_config": {
                "language": "en",
                "k": 2
            },
            "plan_shared_objects_config": {
                "language": "pt-br",
                "k": 3
            },
            "execute_shared_objects_config": {
                "language": "en",
                "k": 4
            },
            "observe_node_llm_prompt_language": "en",
            "plan_node_llm_prompt_language": "pt-br",
            "execute_node_llm_prompt_language": "en"
        }
    }

    # Putting objects into shared memory
    df = pd.DataFrame({
        "name": ["Alice", "Bob", "Charlie"],
        "age": [30, 25, 35]
    })
    object_id_1 = shared_objects_agent_memory._shared_memory.put_memory(
        chat_id=config.get("configurable").get("chat_id"),
        object_name="user_data",
        obj=df,
        object_type=type(df).__name__,
        description="User data with names and ages.",
    )

    object_id_2 = shared_objects_agent_memory._shared_memory.put_memory(
        chat_id=config.get("configurable").get("chat_id"),
        object_name="number_data",
        obj=1000    ,
        object_type=type(1000).__name__,
        description="Number data representing a count.",
    )

    # Test manifest_memory for 'observe' node
    manifest_observe = shared_objects_agent_memory.manifest_memory(
        state=state,
        config=config,
        node_name="observe_node"
    )

    assert f"Below is a summary of the last created objects and the relationships between them:\n------------------ Objects Summary ------------------\nObject list:\n\n" in manifest_observe
    assert f"- user_data (id: {object_id_1})\n    type: DataFrame\n    description: User data with names and ages.\n    created at:" in manifest_observe
    assert f"- number_data (id: {object_id_2})\n    type: int\n    description: Number data representing a count.\n    created at:" in manifest_observe
    
    # Test manifest_memory for 'plan' node
    manifest_plan = shared_objects_agent_memory.manifest_memory(
        state=state,
        config=config,
        node_name="plan_node"
    )

    assert f"Abaixo está um resumo dos últimos objetos criados e as relações entre eles:\n------------------ Sumário de Objetos ------------------\nLista de objetos:\n\n" in manifest_plan
    assert f"- user_data (id: {object_id_1})\n    tipo: DataFrame\n    descrição: User data with names and ages.\n    criado em:" in manifest_plan
    assert f"- number_data (id: {object_id_2})\n    tipo: int\n    descrição: Number data representing a count.\n    criado em:" in manifest_plan
    
    # Test manifest_memory for 'execute' node
    manifest_execute = shared_objects_agent_memory.manifest_memory(
        state=state,
        config=config,
        node_name="execute_node"
    )

    assert manifest_execute == manifest_observe

def test_shared_objects_agent_memory_with_must_cite(shared_objects_memory):
    """
    Test the SharedObjectsAgentMemory functionality.
    """
    shared_objects_agent_memory = SharedObjectsAgentMemory(
        shared_memory=shared_objects_memory,
        include_must_cite=True
    )

    # Config and state for testing
    config = {
        "configurable": {
            "chat_id": "12345",
            "chat_history_window_size": 15,
            "observe_shared_objects_config": {
                "language": "en",
                "k": 2
            },
            "plan_shared_objects_config": {
                "language": "pt-br",
                "k": 3
            },
            "execute_shared_objects_config": {
                "language": "en",
                "k": 4
            },
            "observe_node_llm_prompt_language": "en",
            "plan_node_llm_prompt_language": "pt-br",
            "execute_node_llm_prompt_language": "en"
        }
    }

    # Putting objects into shared memory
    df = pd.DataFrame({
        "name": ["Alice", "Bob", "Charlie"],
        "age": [30, 25, 35]
    })
    object_id_1 = shared_objects_agent_memory._shared_memory.put_memory(
        chat_id=config.get("configurable").get("chat_id"),
        object_name="user_data",
        obj=df,
        object_type=type(df).__name__,
        description="User data with names and ages.",
    )

    sleep(10) #Wait for timestamp difference

    state = ReactPlanningAgentWorkingMemoryState()

    object_id_2 = shared_objects_agent_memory._shared_memory.put_memory(
        chat_id=config.get("configurable").get("chat_id"),
        object_name="number_data",
        obj=1000    ,
        object_type=type(1000).__name__,
        description="Number data representing a count.",
    )

    # Test manifest_memory for 'observe' node
    manifest_observe = shared_objects_agent_memory.manifest_memory(
        state=state,
        config=config,
        node_name="observe_node"
    )

    assert f"Below is a summary of the last created objects and the relationships between them:\n------------------ Objects Summary ------------------\nObject list:\n\n- user_data (id: {object_id_1})\n    type: DataFrame\n    description: User data with names and ages.\n    created at:" in manifest_observe
    assert f"The following objects must be cited in the response, with their respective IDs:\n--------------- Objects to be cited -----------------\nObject list:\n\n- number_data (id: {object_id_2})\n    type: int\n    description: Number data representing a count.\n    created at:" in manifest_observe
