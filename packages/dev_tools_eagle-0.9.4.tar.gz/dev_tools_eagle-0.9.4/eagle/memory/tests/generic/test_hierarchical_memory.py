import time
import pytest
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


def test_put_and_get_memory(hierarchical_memory):
    memory = hierarchical_memory
    hierarchy = ("projectA", "subA")
    key = "item1"
    value = {"description": "Test item", "type": "generic_memory"}

    memory.delete_memory(hierarchy, key)
    memory.put_memory(hierarchy, key, value)
    result = memory.get_memory(hierarchy, key)
    assert result == value

def test_delete_memory(hierarchical_memory):
    memory = hierarchical_memory
    hierarchy = ("projectA", "subA")
    key = "item1"
    value = {"description": "Test item", "type": "generic_memory"}

    memory.put_memory(hierarchy, key, value)
    assert memory.get_memory(hierarchy, key) is not None
    memory.delete_memory(hierarchy, key)
    assert memory.get_memory(hierarchy, key) is None

def test_search_memories(hierarchical_memory):
    memory = hierarchical_memory
    hierarchy = ("projectA", "subA")
    items = [
        ("item1", {"description": "First item", "type": "generic_memory"}),
        ("item2", {"description": "Second item", "type": "generic_memory"}),
        ("item3", {"description": "Third item", "type": "generic_memory"}),
    ]
    for key, value in items:
        memory.put_memory(hierarchy, key, value)
    time.sleep(2)
    results = memory.search_memories(hierarchy, query="Second", limit=2)
    assert any("Second item" in r["description"] for r in results)

def test_delete_memories_by_namespace(hierarchical_memory):
    memory = hierarchical_memory
    hierarchy = ("projectA", "subA")
    memory.put_memory(hierarchy, "item1", {"description": "Item1", "type": "generic_memory"})
    memory.put_memory(hierarchy, "item2", {"description": "Item2", "type": "generic_memory"})
    time.sleep(2)
    memory.delete_memories_by_namespace(hierarchy)
    assert memory.get_memory(hierarchy, "item1") is None
    assert memory.get_memory(hierarchy, "item2") is None

def test_get_memory_hierarchy_levels(hierarchical_memory):
    """
    Testa se o get_memory só retorna o valor quando a hierarquia é exatamente igual à usada no put_memory.
    """
    memory = hierarchical_memory
    key = "item_ns"
    value_base = {"description": "Base level", "type": "generic_memory"}
    value_lvl1 = {"description": "Level 1", "type": "generic_memory"}
    value_lvl2 = {"description": "Level 2", "type": "generic_memory"}

    # Hierarquias
    h_base = ("projectB",)
    h_lvl1 = ("projectB", "level1")
    h_lvl2 = ("projectB", "level1", "level2")

    # Limpa antes
    memory.delete_memory(h_base, key)
    memory.delete_memory(h_lvl1, key)
    memory.delete_memory(h_lvl2, key)

    # Adiciona em diferentes níveis
    memory.put_memory(h_base, key, value_base)
    memory.put_memory(h_lvl1, key, value_lvl1)
    memory.put_memory(h_lvl2, key, value_lvl2)

    # Espera indexação se necessário
    import time; time.sleep(2)

    # Só retorna se a hierarquia for exata
    assert memory.get_memory(h_base, key) == value_base
    assert memory.get_memory(h_lvl1, key) == value_lvl1
    assert memory.get_memory(h_lvl2, key) == value_lvl2

    # Não retorna valores de outros níveis
    assert memory.get_memory(("projectB",), key) == value_base
    assert memory.get_memory(("projectB", "level1"), key) == value_lvl1
    assert memory.get_memory(("projectB", "level1", "level2"), key) == value_lvl2

    # Testa que não encontra em hierarquias erradas
    assert memory.get_memory(("projectB", "level1", "wrong"), key) is None
    assert memory.get_memory(("projectB", "wrong"), key) is None
    assert memory.get_memory(("projectB", "level1", "level2", "extra"), key) is None
