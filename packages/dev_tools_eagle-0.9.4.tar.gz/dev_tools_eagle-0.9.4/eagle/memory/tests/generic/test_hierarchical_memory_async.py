import pytest
import asyncio
import time
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


@pytest.mark.asyncio
async def test_async_put_and_get_memory(hierarchical_memory):
    memory = hierarchical_memory
    hierarchy = ("projectA", "subA")
    key = "item1"
    value = {"description": "Async item", "type": "generic_memory"}

    await memory.adelete_memory(hierarchy, key)
    await memory.aput_memory(hierarchy, key, value)
    result = await memory.aget_memory(hierarchy, key)
    assert result == value

@pytest.mark.asyncio
async def test_async_delete_memory(hierarchical_memory):
    memory = hierarchical_memory
    hierarchy = ("projectA", "subA")
    key = "item1"
    value = {"description": "Async item", "type": "generic_memory"}

    await memory.aput_memory(hierarchy, key, value)
    assert await memory.aget_memory(hierarchy, key) is not None
    await memory.adelete_memory(hierarchy, key)
    assert await memory.aget_memory(hierarchy, key) is None

@pytest.mark.asyncio
async def test_async_search_memories(hierarchical_memory):
    memory = hierarchical_memory
    hierarchy = ("projectA", "subA")
    items = [
        ("item1", {"description": "First async item", "type": "generic_memory"}),
        ("item2", {"description": "Second async item", "type": "generic_memory"}),
        ("item3", {"description": "Third async item", "type": "generic_memory"}),
    ]
    await asyncio.gather(*(memory.aput_memory(hierarchy, key, value) for key, value in items))
    await asyncio.sleep(2)
    results = await memory.asearch_memories(hierarchy, query="Second", limit=2)
    assert any("Second async item" in r["description"] for r in results)

@pytest.mark.asyncio
async def test_async_delete_memories_by_namespace(hierarchical_memory):
    memory = hierarchical_memory
    hierarchy = ("projectA", "subA")
    await memory.aput_memory(hierarchy, "item1", {"description": "Async Item1", "type": "generic_memory"})
    await memory.aput_memory(hierarchy, "item2", {"description": "Async Item2", "type": "generic_memory"})
    await asyncio.sleep(2)
    memory.delete_memories_by_namespace(hierarchy)
    time.sleep(1)
    assert await memory.aget_memory(hierarchy, "item1") is None
    assert await memory.aget_memory(hierarchy, "item2") is None
