from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, Sequence

import pandas as pd
from langchain_core.embeddings import Embeddings
from langchain_core.language_models.base import BaseLanguageModel

from eagle.settings import get_settings
from eagle.stores.document_storage.base import DocumentStorage
from eagle.stores.document_storage.mongodb import MongoDocumentStorage


class StudyStep(Protocol):
    """A single, reusable processing unit for a study pipeline."""

    name: str

    async def run(self, ctx: "StudyContext") -> "StudyContext":
        ...

    async def undo(self, ctx: "StudyContext") -> "StudyContext":
        ...


@dataclass
class StudyContext:
    """Carries the dataframe, metadata and shared resources across steps."""

    metadata: dict[str, Any]
    df: pd.DataFrame
    storage: DocumentStorage
    settings: Any
    llm: BaseLanguageModel | None = None
    embedding_model: Embeddings | None = None
    embedding_dims: int | None = None
    embedding_name: str | None = None
    # Mutable cache to share derived objects across steps without touching metadata.
    cache: dict[str, Any] = field(default_factory=dict)

    # --- docs_index helpers ---
    def docs_index_meta(self) -> dict[str, Any]:
        studies = self.metadata.setdefault("studies", {})
        return studies.setdefault("docs_index", {})

    def step_is_done(self, step_name: str) -> bool:
        status = self.docs_index_meta().get("steps", {}).get(step_name, {})
        return status.get("status") == "done"

    def mark_step_done(self, step_name: str, *, updated_at: str) -> None:
        steps = self.docs_index_meta().setdefault("steps", {})
        steps[step_name] = {"status": "done", "updated_at": updated_at}

    def mark_step_pending(self, step_name: str, *, updated_at: str) -> None:
        steps = self.docs_index_meta().setdefault("steps", {})
        steps[step_name] = {"status": "pending", "updated_at": updated_at}


class PipelineRunner:
    """Executes a sequence of StudySteps, persisting after each step."""

    def __init__(self, steps: Sequence[StudyStep]) -> None:
        self.steps: list[StudyStep] = list(steps)

    async def run(self, ctx: StudyContext) -> StudyContext:
        for step in self.steps:
            ctx = await step.run(ctx)
            await ctx.storage.asave(ctx.df, ctx.metadata)
        return ctx

    async def undo_step(self, step_name: str, ctx: StudyContext) -> StudyContext:
        step = next((s for s in self.steps if s.name == step_name), None)
        if step is None:
            raise ValueError(f"Step '{step_name}' not found in pipeline")
        ctx = await step.undo(ctx)
        await ctx.storage.asave(ctx.df, ctx.metadata)
        return ctx


def build_document_storage(kind: str | None = None, *, collection: str | None = None) -> DocumentStorage:
    """Factory for DocumentStorage mirroring the legacy selection logic."""

    settings = get_settings()
    target_collection = collection or settings.mongo_documents_studies_collection
    selected_kind = kind or settings.document_storage_kind

    if selected_kind == "mongo":
        mongo_kwargs: dict[str, Any] = {}
        if settings.mongo_replica_set:
            mongo_kwargs["replicaSet"] = settings.mongo_replica_set
        if settings.mongo_auth_source:
            mongo_kwargs["authSource"] = settings.mongo_auth_source
        return MongoDocumentStorage(
            mongo_uri=settings.mongo_uri,
            database=settings.mongo_database,
            collection=target_collection,
            persistence_dir=settings.mongo_persistence_dir,
            mongo_kwargs=mongo_kwargs or None,
        )

    raise ValueError(f"Unsupported document storage kind: {selected_kind}")


__all__ = [
    "StudyStep",
    "StudyContext",
    "PipelineRunner",
    "build_document_storage",
]
