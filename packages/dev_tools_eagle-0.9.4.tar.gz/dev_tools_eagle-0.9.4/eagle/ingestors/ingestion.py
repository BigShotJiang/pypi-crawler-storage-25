from __future__ import annotations

import hashlib
import os
import uuid
from typing import Any, Callable, Dict, Iterable

import pandas as pd
from langchain_core.language_models.base import BaseLanguageModel

from eagle.ingestors.file_type_ingestors.pdf import PDFIngestor
from eagle.ingestors.file_type_ingestors.docx import DocxIngestor
from eagle.ingestors.file_type_ingestors.pptx import PptxIngestor
from eagle.settings import get_settings
from eagle.stores.document_storage.base import DocumentStorage, DocumentStorageSearchQuery

from eagle.chains.document_storage.document_classification.chains import (
    create_extract_document_metadata_chain,
)
from eagle.utils.doc_as_dataframe_utils import doc_as_dataframe_to_text
from eagle.ingestors.base import StudyContext, build_document_storage

FileTypeIngestorFactory = Callable[[Any, BaseLanguageModel], Any]


class UnsupportedFileTypeError(Exception):
    """Raised when the provided file type cannot be handled."""


class Ingestion:
    """Ingestion pipeline that is compatible with StudyStep/DocsIndexStrategy.

    - Handles file-type routing (PDF today) and persists the parsed dataframe
      into the chosen DocumentStorage.
    - Executes a list of strategies (new or legadas) that expose ``run(metadata)``
      returning ``(metadata, df)``. Each strategy may carry its own storage; if
      absent, the ingestion storage is used.
    """

    def __init__(
        self,
        *,
        llm: BaseLanguageModel,
        storage: DocumentStorage | None = None,
        file_type_ingestors: Dict[str, FileTypeIngestorFactory] | None = None,
        study_strategies: Iterable[Any] | None = None,
        prompt_language: str = "pt-br",
    ) -> None:
        self.llm = llm
        self.settings = get_settings()
        self.prompt_language = prompt_language
        self.storage = storage or build_document_storage(
            collection=self.settings.mongo_documents_collection
        )
        # Optional reference list so we can run undo flows without callers passing the strategies again.
        self.study_strategies = list(study_strategies) if study_strategies is not None else []
        default_ingestors: Dict[str, FileTypeIngestorFactory] = {
            "pdf": lambda settings, llm: PDFIngestor(settings=settings, llm=llm),
            "docx": lambda settings, llm: DocxIngestor(settings=settings, llm=llm),
            "pptx": lambda settings, llm: PptxIngestor(settings=settings, llm=llm),
        }
        # Merge custom ingestors so callers can extend or override the defaults.
        self.file_type_ingestors = {**default_ingestors, **(file_type_ingestors or {})}

    @staticmethod
    def infer_file_type(file_path: str) -> str:
        ext = os.path.splitext(file_path)[1].lower()
        if ext == ".pdf":
            return "pdf"
        if ext == ".docx":
            return "docx"
        if ext == ".pptx":
            return "pptx"
        return ext.lstrip(".")

    @staticmethod
    def get_file_content_uuid(file_path: str, chunk_size: int = 8192) -> uuid.UUID:
        hasher = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(chunk_size), b""):
                hasher.update(chunk)
        return uuid.uuid5(uuid.NAMESPACE_OID, hasher.hexdigest())

    def _get_ingestor_for_type(self, file_type: str):
        factory = self.file_type_ingestors.get(file_type)
        if not factory:
            raise UnsupportedFileTypeError(f"File type '{file_type}' is not supported for ingestion.")
        return factory(self.settings, self.llm)

    async def persist_ingestion_parsed_data(self, file_as_df: pd.DataFrame, metadata: dict[str, Any]) -> str:
        return await self.storage.asave(file_as_df, metadata)

    async def ingest(self, file_path: str, metadata: dict[str, Any] | None = None, metadata_schema: dict[str, Any] | None = None) -> str:
        safe_metadata: dict[str, Any] = dict(metadata or {})
        file_type = self.infer_file_type(file_path)
        file_id = str(self.get_file_content_uuid(file_path))
        safe_metadata.setdefault("file_id", file_id)

        try:
            existing_metadata, existing_df = await self.storage.aload(file_id)
            if existing_df is not None and not existing_df.empty:
                safe_metadata.update(existing_metadata or {})
                return file_id
        except KeyError:
            pass

        ingestor = self._get_ingestor_for_type(file_type)
        file_as_df = await ingestor.ingest(file_path, safe_metadata)

        if metadata_schema:
            document_text = doc_as_dataframe_to_text(file_as_df)
            metadata_chain = create_extract_document_metadata_chain(
                prompt_language="pt-br",  # TODO: get from settings or metadata
                llm=self.llm,
            )
            extracted_metadata = await metadata_chain.ainvoke({
                "document_as_text": document_text,
                "metadata_schema": metadata_schema,
            })
            safe_metadata.update(extracted_metadata)

        await self.persist_ingestion_parsed_data(file_as_df, safe_metadata)
        return file_id

    async def study_file(
        self,
        file_path: str,
        study_strategies: Iterable[Any],
        metadata: dict[str, Any] | None = None,
        metadata_schema: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Execute a sequence of study strategies for the given file."""

        safe_metadata: dict[str, Any] = dict(metadata or {})
        file_id = str(self.get_file_content_uuid(file_path))
        safe_metadata.setdefault("file_id", file_id)
        safe_metadata.setdefault("path", file_path)

        try:
            stored_metadata, file_as_df = await self.storage.aload(file_id)
        except KeyError:
            await self.ingest(file_path, metadata=safe_metadata, metadata_schema=metadata_schema)
            stored_metadata, file_as_df = await self.storage.aload(file_id)

        merged_metadata: dict[str, Any] = dict(stored_metadata or {})
        merged_metadata.update(safe_metadata)


        for strategy in study_strategies:
            target_storage: DocumentStorage = (
                getattr(strategy, "storage", None)
                or getattr(strategy, "document_storage", None)
                or self.storage
            )

            try:
                await target_storage.aload(file_id)
            except KeyError:
                await target_storage.asave(file_as_df, merged_metadata)

            result = await strategy.run(merged_metadata)
            if isinstance(result, tuple) and len(result) == 2:
                merged_metadata, file_as_df = result
            else:
                # Fallback for strategies that only return metadata
                merged_metadata = result  # type: ignore[assignment]

        return merged_metadata

    async def delete(self, file_path: str, study_strategies: Iterable[Any] | None = None) -> None:
        """Undo all registered study strategies and remove the stored artifacts for ``file_path``.

        Order of operations:
        1) For each provided/registered study strategy, run undo for every step in reverse order.
        2) Remove the study storage entry (strategy-level storage) for ``file_id``.
        3) Remove the ingestion storage entry (ingestion-level storage) for ``file_id``.
        """
        file_id = str(self.get_file_content_uuid(file_path))

        strategies = list(study_strategies) if study_strategies is not None else list(self.study_strategies)

        for strategy in strategies:
            # Prefer explicit storage attributes, fallback to ingestion storage.
            target_storage: DocumentStorage = (
                getattr(strategy, "storage", None)
                or getattr(strategy, "document_storage", None)
                or self.storage
            )

            step_names: list[str] = []
            if hasattr(strategy, "steps") and isinstance(getattr(strategy, "steps"), list):
                step_names = [getattr(step, "name", None) for step in getattr(strategy, "steps")]
            elif hasattr(strategy, "pipeline") and hasattr(getattr(strategy, "pipeline"), "steps"):
                pipeline_steps = getattr(strategy, "pipeline").steps
                if isinstance(pipeline_steps, list):
                    step_names = [getattr(step, "name", None) for step in pipeline_steps]

            # Filter out missing names and ensure reverse order.
            step_names = [name for name in step_names if isinstance(name, str)]

            for step_name in reversed(step_names):
                if hasattr(strategy, "undo_step") and callable(getattr(strategy, "undo_step")):
                    await strategy.undo_step(step_name, {"file_id": file_id})

            # Remove study-level stored artifacts once all undos ran.
            try:
                await target_storage.aremove(file_id)
            except Exception:
                # Best-effort cleanup; undo already executed.
                pass

        # Finally remove the ingestion-level stored dataframe/metadata.
        await self.storage.aremove(file_id)

    async def search_file_ids(self, query: DocumentStorageSearchQuery) -> list[str]:
        """Search for file IDs based on metadata criteria using the provided query."""
        results = await self.storage.asearch(query)
        file_ids = [metadata.get("file_id") for metadata, _ in results if metadata.get("file_id")]
        return file_ids

    async def update_metadata(self, file_id: str, new_metadata: dict[str, Any]) -> None:
        """Update the metadata for an ingested file.

        Loads the existing metadata and dataframe, updates the metadata with the new values,
        and saves it back to storage.
        """
        try:
            existing_metadata, df = await self.storage.aload(file_id)
        except KeyError:
            raise ValueError(f"File with ID '{file_id}' not found in storage.")

        existing_metadata.update(new_metadata)
        await self.storage.asave(df, existing_metadata)


__all__ = ["Ingestion", "UnsupportedFileTypeError"]
