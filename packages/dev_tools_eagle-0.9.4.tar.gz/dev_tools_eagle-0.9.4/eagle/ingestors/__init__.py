"""Experimental ingestion/study orchestration v2.

This module introduces a pluggable pipeline/ask architecture intended to
keep strategies small and composable. It lives alongside the legacy
`ingestors` package without changing its behavior.
"""

from eagle.ingestors.base import StudyContext, StudyStep, PipelineRunner, build_document_storage
from eagle.ingestors.ingestion import Ingestion, UnsupportedFileTypeError

__all__ = [
    "StudyContext",
    "StudyStep",
    "PipelineRunner",
    "build_document_storage",
    "Ingestion",
    "UnsupportedFileTypeError",
]
