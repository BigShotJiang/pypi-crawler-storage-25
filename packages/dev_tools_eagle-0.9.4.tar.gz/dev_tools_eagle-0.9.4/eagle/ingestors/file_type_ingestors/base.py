
from eagle.settings import Settings
import pandas as pd

class IngestionByFileTypeBase:

    def __init__(self, settings: Settings):

        self.settings = settings

    async def parse(self, file_path: str, metadata: dict = {}) -> pd.DataFrame:
        """
        Parses the document and extracts its content and metadata.
        """
        raise NotImplementedError("This method should be implemented by subclasses.")

    async def ingest(self, file_path: str, metadata: dict = {}):
        """
        Ingests a document, extracting its content and metadata, and stores it in the system.
        """
        parsed_df = await self.parse(file_path, metadata)
        return parsed_df