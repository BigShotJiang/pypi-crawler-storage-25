from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import pandas as pd
from langchain_core.language_models.base import BaseLanguageModel

from eagle.ingestors.file_type_ingestors.base import IngestionByFileTypeBase
from eagle.parsing.tornado import TornadoPaddleReader, TornadoService
from eagle.parsing.pdf_llm_parser import PDFLLMParser
from eagle.settings import Settings


logger = logging.getLogger(__name__)


class PDFIngestor(IngestionByFileTypeBase):

	def __init__(self, settings: Settings, llm: BaseLanguageModel):
		super().__init__(settings=settings)
		self.llm = llm

	async def parse(self, file_path: str, metadata: dict[str, Any] | None = None) -> pd.DataFrame:
		parse_folder = Path(self.settings.tornado_extracted_files_dir)
		base_url = (
			self.settings.tornado_base_url
			if self.settings.tornado_base_url.endswith("/")
			else f"{self.settings.tornado_base_url}/"
		)
		tornado = TornadoService(
			base_url=base_url,
			username=self.settings.tornado_username,
			password=self.settings.tornado_password,
			max_part_mb=self.settings.tornado_max_part_mb,
		)
		slurm_id = tornado.submit_pdf_run(file_path, method="paddle")
		tornado.wait_for_completion(slurm_id)
		tornado.download_and_extract_result(str(parse_folder))
		reader = TornadoPaddleReader(
			results_root_dir=str(parse_folder / str(tornado.collection_id)),
			source=file_path,
			llm_model=self.llm,
		)
		parsed_df = await reader.process()
		if not parsed_df.empty:
			return parsed_df

		logger.warning(
			"TornadoPaddleReader returned an empty DataFrame for %s. Falling back to PDFLLMParser.",
			file_path,
		)
		fallback_parser = PDFLLMParser(
			path=file_path,
			llm=self.llm,
			img_dir=parse_folder / str(tornado.collection_id) / "llm_images",
		)
		return await fallback_parser.process()

__all__ = ["PDFIngestor"]