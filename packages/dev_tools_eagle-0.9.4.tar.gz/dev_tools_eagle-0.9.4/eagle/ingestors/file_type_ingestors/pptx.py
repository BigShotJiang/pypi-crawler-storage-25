from __future__ import annotations

import os
from typing import Any

import pandas as pd
from langchain_core.language_models.base import BaseLanguageModel

from eagle.ingestors.file_type_ingestors.base import IngestionByFileTypeBase
from eagle.parsing.pptx import PPTXParser
from eagle.settings import Settings


class PptxIngestor(IngestionByFileTypeBase):
    def __init__(self, settings: Settings, llm: BaseLanguageModel):
        super().__init__(settings=settings)
        self.llm = llm

    async def parse(self, file_path: str, metadata: dict[str, Any] | None = None) -> pd.DataFrame:
        img_dir = os.path.join(self.settings.mongo_persistence_dir, "images")
        parser = PPTXParser(
            path=file_path,
            llm=self.llm,
            prompt_language=getattr(
                self.settings,
                "parsing_prompt_language",
                getattr(self.settings, "table_interpretation_prompt_language", "pt-br"),
            ),
            img_dir=img_dir,
        )
        return await parser.process()

__all__ = ["PptxIngestor"]
