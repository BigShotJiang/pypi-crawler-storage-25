from eagle.ingestors.file_type_ingestors.pdf import PDFIngestor
from eagle.ingestors.file_type_ingestors.docx import DocxIngestor
from eagle.ingestors.file_type_ingestors.pptx import PptxIngestor

__all__ = ["PDFIngestor", "DocxIngestor", "PptxIngestor"]
