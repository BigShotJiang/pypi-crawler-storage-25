from __future__ import annotations

import copy
from typing import Any, Dict, List, Tuple

import pandas as pd
from langchain_core.embeddings import Embeddings
from langchain_core.language_models.base import BaseLanguageModel

from eagle.chains.doc_as_dataframe_study.retrieval.search_doc_sections.chains import (
    create_best_files_and_sections_chain,
)
from eagle.chains.doc_as_dataframe_study.retrieval.q_and_a.chains import (
    create_q_and_a_chain,
)
from eagle.chains.doc_as_dataframe_study.retrieval.question_decomposition.chains import (
    create_question_decomposition_chain,
)
from eagle.memory.ingestors.docs_sections_descriptions_memory import (
    DocsSectionsDescriptionsMemory,
)
from eagle.settings import get_settings
from eagle.stores.opensearch import OpenSearchStore

from eagle.ingestors.base import PipelineRunner, StudyContext, build_document_storage
from eagle.ingestors.docs_index.ask_components import (
    QAResponder,
    MetadataFormatter,
    QuestionDescriptionsSplitter,
    SectionsRanker,
    TagSectionsRetriever,
    VectorSectionsRetriever,
    build_context,
    format_sections_for_prompt,
    _build_context_snippets,
)
from .steps import (
    DescribeSectionsStep,
    ExtractDocStructureStep,
    ExtractIndustrialTagsStep,
    StoreSectionDescriptionsStep,
    UnifyDocStructureStep,
    _get_node_by_path,
    ExtractDocumentTitleStep,
    StudyStep
)


class DocsIndexStrategy:
    """Pluggable, layered implementation of DocsIndex using StudyStep pipeline and modular ask."""

    def __init__(
        self,
        *,
        llm: BaseLanguageModel,
        embedding_model: Embeddings,
        embedding_dims: int,
        embedding_name: str,
        prompt_language: str = "pt-br",
        storage: Any | None = None,
        docs_sections_memory: DocsSectionsDescriptionsMemory | None = None,
        extra_steps: List[StudyStep] = [],
        weight_vector: float = 0.6,
        weight_tags: float = 0.4,
    ) -> None:
        self.settings = get_settings()
        self.llm = llm
        self.embedding_model = embedding_model
        self.embedding_dims = embedding_dims
        self.embedding_name = embedding_name
        self.prompt_language = prompt_language

        self.storage = storage or build_document_storage(collection=self.settings.mongo_documents_studies_collection)
        self.docs_sections_memory = docs_sections_memory or self._select_docs_sections_memory()

        self.best_files_and_sections_chain = create_best_files_and_sections_chain(
            prompt_language=prompt_language,
            llm=llm,
        )
        self.q_and_a_chain = create_q_and_a_chain(
            prompt_language=prompt_language,
            llm=llm,
            use_structured_output=False,
        )
        self.question_splitter_chain = create_question_decomposition_chain(
            prompt_language=prompt_language,
            llm=llm,
            use_structured_output=False,
        )

        default_steps = [
            ExtractDocumentTitleStep(llm=llm, prompt_language=prompt_language),
            ExtractDocStructureStep(llm=llm, prompt_language=prompt_language),
            UnifyDocStructureStep(llm=llm, prompt_language=prompt_language),
            DescribeSectionsStep(llm=llm, prompt_language=prompt_language),
            StoreSectionDescriptionsStep(docs_sections_memory=self.docs_sections_memory),
            ExtractIndustrialTagsStep(),
        ]
        self.steps = default_steps + extra_steps
        self.pipeline = PipelineRunner(self.steps)

        self.vector_retriever = VectorSectionsRetriever(self.docs_sections_memory)
        self.tag_retriever = TagSectionsRetriever(self.storage)
        self.ranker = SectionsRanker(weight_vector=weight_vector, weight_tags=weight_tags)
        self.qa_responder = QAResponder(self.q_and_a_chain)
        self.question_splitter = QuestionDescriptionsSplitter(self.question_splitter_chain)
        self.metadata_formatter = MetadataFormatter()

    # --- public API ---
    async def run(self, metadata: Dict[str, Any]) -> Tuple[Dict[str, Any], pd.DataFrame]:
        if not isinstance(metadata, dict) or "file_id" not in metadata:
            raise ValueError("metadata must contain file_id to run study strategies")

        file_id = metadata["file_id"]
        path = metadata["path"]

        stored_metadata, df = await self._load_dataframe(metadata)
        merged_metadata: dict[str, Any] = dict(stored_metadata or {})
        merged_metadata["file_id"] = file_id
        merged_metadata["path"] = path
        merged_metadata.update(metadata)

        ctx = StudyContext(
            metadata=merged_metadata,
            df=df,
            storage=self.storage,
            settings=self.settings,
            llm=self.llm,
            embedding_model=self.embedding_model,
            embedding_dims=self.embedding_dims,
            embedding_name=self.embedding_name,
        )

        ctx = await self.pipeline.run(ctx)
        return ctx.metadata, ctx.df

    async def undo_step(self, step_name: str, metadata: Dict[str, Any]) -> Tuple[Dict[str, Any], pd.DataFrame]:
        if not metadata.get("file_id"):
            raise ValueError("metadata must contain file_id to undo a step")

        try:
            stored_metadata, df = await self._load_dataframe(metadata)
        except KeyError:
            stored_metadata = {}
            df = pd.DataFrame()
        merged_metadata: dict[str, Any] = dict(stored_metadata or {})
        merged_metadata["file_id"] = metadata["file_id"]
        ctx = StudyContext(
            metadata=merged_metadata,
            df=df,
            storage=self.storage,
            settings=self.settings,
            llm=self.llm,
            embedding_model=self.embedding_model,
            embedding_dims=self.embedding_dims,
            embedding_name=self.embedding_name,
        )
        ctx = await self.pipeline.undo_step(step_name, ctx)
        return ctx.metadata, ctx.df

    async def ask(
        self,
        question: str,
        file_ids: List[str],
        limit_vector: int = 10,
        limit_tags: int = 10,
        multimodal: bool = False,
    ) -> Dict[str, Any]:
        if not question:
            raise ValueError("question must be provided")
        if not file_ids:
            raise ValueError("file_ids must be provided")

        descriptions = await self.question_splitter.split(question)
        if not descriptions:
            descriptions = [question]

        # Aggregate vector results across descriptions
        vector_path_scores: Dict[Tuple[str, ...], float] = {}
        vector_memory_hits: List[Any] = []
        per_description_results: List[Dict[str, Any]] = []

        for desc in descriptions:
            desc_result = await self.vector_retriever.retrieve(desc, file_ids, limit_vector)
            per_description_results.append({"description": desc, **desc_result})
            vector_memory_hits.extend(desc_result.get("memory_hits", []))
            for key, score in desc_result.get("path_scores", {}).items():
                vector_path_scores[key] = vector_path_scores.get(key, 0.0) + score

        vector_ranked_paths = sorted(vector_path_scores.items(), key=lambda kv: (-kv[1], kv[0]))
        vector_result = {
            "descriptions": descriptions,
            "per_description": per_description_results,
            "memory_hits": vector_memory_hits,
            "path_scores": vector_path_scores,
            "ranked_paths": vector_ranked_paths,
            "normalized_scores": (
                {k: v / max(vector_path_scores.values()) for k, v in vector_path_scores.items()}
                if vector_path_scores and max(vector_path_scores.values()) > 0
                else {k: 0.0 for k in vector_path_scores}
            ),
        }
        tag_result = await self.tag_retriever.retrieve(question, file_ids, limit_tags)

        structures, file_dfs, metadata_map = await self._load_structures_and_dfs(file_ids)

        # Vector sections -> selector chain
        vector_sections: List[Dict[str, Any]] = []
        for path_tuple, score in vector_result.get("ranked_paths", []):
            if not path_tuple:
                continue
            file_id, *section_path = path_tuple
            structure = structures.get(file_id)
            if not structure:
                continue
            node = _get_node_by_path(structure, list(section_path))
            if node is None:
                continue
            vector_sections.append(
                {
                    "file_id": file_id,
                    "path": list(section_path),
                    "score": score,
                    "node": copy.deepcopy(node),
                }
            )

        sections_for_prompt_vector = format_sections_for_prompt(vector_sections)
        chain_output_vector = await self.best_files_and_sections_chain.ainvoke(
            {"question": question, "sections_and_descriptions": sections_for_prompt_vector}
        )
        best_paths_vector: List[List[str]] = chain_output_vector.paths or []

        # Tag sections -> selector chain
        tag_sections: List[Dict[str, Any]] = []
        tag_entries_map = tag_result.get("path_entries", {})
        for path_tuple, score in tag_result.get("ranked_paths", []):
            if not path_tuple:
                continue
            file_id, *section_path = path_tuple
            structure = structures.get(file_id)
            if not structure:
                continue
            node = _get_node_by_path(structure, list(section_path))
            if node is None:
                continue

            entries = tag_entries_map.get(tuple(path_tuple), [])
            context_snippets = _build_context_snippets(file_id, entries, file_dfs)

            tag_sections.append(
                {
                    "file_id": file_id,
                    "path": list(section_path),
                    "score": score,
                    "node": copy.deepcopy(node),
                    "context_snippets": context_snippets,
                }
            )

        sections_for_prompt_tags = format_sections_for_prompt(tag_sections)
        chain_output_tags = await self.best_files_and_sections_chain.ainvoke(
            {"question": question, "sections_and_descriptions": sections_for_prompt_tags}
        )
        best_paths_tags: List[List[str]] = chain_output_tags.paths or []

        allowed_vector = {tuple(p) for p in best_paths_vector} if best_paths_vector else None
        allowed_tags = {tuple(p) for p in best_paths_tags} if best_paths_tags else None

        combined_ranked_paths = self.ranker.fuse(
            vector_result.get("normalized_scores", {}),
            tag_result.get("normalized_scores", {}),
            allowed_vector=allowed_vector,
            allowed_tags=allowed_tags,
        )

        ranked_sections: List[Dict[str, Any]] = []
        for path_tuple, score in combined_ranked_paths:
            if not path_tuple:
                continue
            file_id, *section_path = path_tuple
            structure = structures.get(file_id)
            if not structure:
                continue
            node = _get_node_by_path(structure, list(section_path))
            if node is None:
                continue

            entries = tag_entries_map.get(tuple(path_tuple), [])
            context_snippets = _build_context_snippets(file_id, entries, file_dfs)

            ranked_sections.append(
                {
                    "file_id": file_id,
                    "path": list(section_path),
                    "score": score,
                    "node": copy.deepcopy(node),
                    "context_snippets": context_snippets,
                }
            )

        sections_for_prompt = format_sections_for_prompt(ranked_sections)
        combined_best_paths: List[List[str]] = [list(p) for p in dict.fromkeys([tuple(p) for p in best_paths_vector + best_paths_tags]).keys()]

        filtered_structure = self._filter_structure_for_paths(structures, combined_best_paths)
        context_items = build_context(
            combined_best_paths,
            structures,
            file_dfs,
            metadata_formatter=self.metadata_formatter,
            metadata_map=metadata_map,
            multimodal=multimodal
        )

        qa_output = await self.qa_responder.answer(question, context_items)

        qa_output = qa_output.model_dump()

        # Enrich qa_output.references with path and page_range
        for i, ref in qa_output['references'].items():
            file_id = ref.get('file_id')
            if file_id:
                metadata = metadata_map.get(file_id, {})
                ref['path'] = metadata.get('path')
                
                df = file_dfs.get(file_id)
                if df is not None and 'idx_range' in ref:
                    start_idx, end_idx = ref['idx_range']
                    try:
                        pages = df.loc[start_idx:end_idx, 'original_page'].dropna().unique().tolist()
                        ref['page_range'] = pages
                    except KeyError:
                            ref['page_range'] = []

        return {
            "vector_result": vector_result,
            "tag_result": tag_result,
            "vector_chain_output": chain_output_vector,
            "tags_chain_output": chain_output_tags,
            "combined_ranked_paths": [list(key) for key, _ in combined_ranked_paths],
            "ranked_sections": ranked_sections,
            "best_paths_vector": best_paths_vector,
            "best_paths_tags": best_paths_tags,
            "filtered_structure": filtered_structure,
            "sections_for_prompt": sections_for_prompt,
            "context_items": context_items,
            "qa_output": qa_output,
        }

    # --- internals ---
    async def _load_dataframe(self, metadata: Dict[str, Any]) -> Tuple[Dict[str, Any], pd.DataFrame]:
        if not metadata.get("file_id"):
            raise ValueError("metadata must contain file_id to load dataframe")

        file_id = metadata["file_id"]
        try:
            stored_metadata, stored_df = await self.storage.aload(file_id)
            return stored_metadata or {}, stored_df
        except KeyError:
            pass

        if metadata.get("df_path"):
            df = pd.read_pickle(metadata["df_path"])
            return metadata, df

        raise KeyError(f"Dataframe not found for file_id {file_id}")

    async def _load_structures_and_dfs(self, file_ids: List[str]) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, pd.DataFrame], Dict[str, Dict[str, Any]]]:
        structures: Dict[str, Dict[str, Any]] = {}
        file_dfs: Dict[str, pd.DataFrame] = {}
        metadata_map: Dict[str, Dict[str, Any]] = {}
        for file_id in file_ids:
            try:
                stored_metadata, file_df = await self.storage.aload(file_id)
            except KeyError:
                continue

            if isinstance(stored_metadata, dict):
                metadata_map[file_id] = stored_metadata

            structure_tree = (
                stored_metadata.get("studies", {})
                .get("docs_index", {})
                .get("structure_list")
            )
            if isinstance(structure_tree, dict):
                structures[file_id] = structure_tree
            if file_df is not None:
                file_dfs[file_id] = file_df
        return structures, file_dfs, metadata_map

    def _select_docs_sections_memory(self) -> DocsSectionsDescriptionsMemory:
        vector_store_class_to_use = {
            "opensearch": OpenSearchStore,
        }
        store_class = vector_store_class_to_use.get(self.settings.document_storage_vectorstore_kind)
        if not store_class:
            raise ValueError(
                f"Unsupported vector store kind: {self.settings.document_storage_vectorstore_kind}"
            )
        return DocsSectionsDescriptionsMemory(
            store_class=store_class,
            embedding_model=self.embedding_model,
            embedding_dims=self.embedding_dims,
            embedding_name=self.embedding_name,
        )

    @staticmethod
    def _filter_structure_for_paths(
        structures: Dict[str, Dict[str, Any]], paths: List[List[str]]
    ) -> Dict[str, Dict[str, Any]]:
        filtered: Dict[str, Dict[str, Any]] = {}
        for path in paths:
            if not path:
                continue
            file_id, *section_path = path
            if not section_path:
                continue
            structure = structures.get(file_id)
            if not isinstance(structure, dict):
                continue
            node = _get_node_by_path(structure, section_path)
            if node is None:
                continue
            dest_tree = filtered.setdefault(file_id, {})
            DocsIndexStrategy._insert_subtree(dest_tree, section_path, node)
        return filtered

    @staticmethod
    def _insert_subtree(target: Dict[str, Any], path: List[str], node: Dict[str, Any]) -> None:
        cursor = target
        for idx, key in enumerate(path):
            if idx == len(path) - 1:
                cursor[key] = copy.deepcopy(node)
                return
            cursor = cursor.setdefault(key, {})


__all__ = ["DocsIndexStrategy"]
