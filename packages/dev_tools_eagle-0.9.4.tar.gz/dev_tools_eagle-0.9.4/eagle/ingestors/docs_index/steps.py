from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd
from langchain_core.language_models.base import BaseLanguageModel

from eagle.chains.doc_as_dataframe_study.chains import (
    create_document_title_chain,
    create_extract_document_structure_chain,
    create_section_descriptions_chain,
    create_unify_document_structure_chain,
)
from eagle.memory.ingestors.docs_sections_descriptions_memory import (
    DocsSectionsDescriptionsMemory,
)
from eagle.utils.doc_as_dataframe_utils import doc_as_dataframe_to_text
from eagle.utils.domain_utils.industrial_processes.text_extraction_utils import find_tag_spans
from eagle.utils.errors_handling import async_ignore_error_with_these_strings

from eagle.ingestors.base import StudyContext, StudyStep


ERRORS_TO_IGNORE = [
    "failed to parse output:",
    "litellm.ContentPolicyViolationError",
]


# --- helpers shared across steps ---
def _iter_slices(file_as_df: pd.DataFrame, step: int, overlap: int) -> Iterable[Tuple[int, int, pd.DataFrame]]:
    if step <= 0:
        raise ValueError("STRUCTURE_READING_SECTION_STEP must be positive")
    if overlap < 0:
        raise ValueError("STRUCTURE_READING_SECTION_OVERLAP cannot be negative")

    stride = max(step - overlap, 1)
    start = 0
    total_rows = len(file_as_df)

    while start < total_rows:
        end = min(start + step, total_rows)
        yield start, end, file_as_df.iloc[start:end]
        start += stride


def _get_node_by_path(structure: Dict[str, Any], path: List[str]) -> Optional[Dict[str, Any]]:
    if not structure or not path:
        return None

    node: Any = structure
    for key in path:
        if not isinstance(node, dict):
            node = None
            break
        node = node.get(key)
        if node is None:
            break
    return node if isinstance(node, dict) else None


def _find_section_path_for_idx(structure: Dict[str, Any], idx: int) -> Optional[List[str]]:
    best_path: Optional[List[str]] = None

    def _dfs(tree: Dict[str, Any], prefix: List[str]) -> None:
        nonlocal best_path

        for title, node in tree.items():
            if not isinstance(node, dict):
                continue

            current_path = prefix + [str(title)]

            idx_range = node.get("idx_range")
            has_range = isinstance(idx_range, (list, tuple)) and len(idx_range) == 2
            in_range = False
            skip_children = False

            if has_range:
                try:
                    start_idx = int(idx_range[0])
                    end_idx = int(idx_range[1])
                except Exception:
                    has_range = False
                else:
                    if start_idx <= idx <= end_idx:
                        in_range = True
                    else:
                        skip_children = True

            if skip_children:
                continue

            if in_range:
                if best_path is None or len(current_path) > len(best_path):
                    best_path = current_path

            for key, child in node.items():
                if key in {"idx_range", "description"}:
                    continue
                if isinstance(child, dict):
                    _dfs(child, current_path + [str(key)])
                elif isinstance(child, list):
                    for elem in child:
                        if isinstance(elem, dict):
                            _dfs(elem, current_path + [str(key)])

    if isinstance(structure, dict):
        _dfs(structure, [])

    return best_path


# --- step implementations ---
@dataclass
class ExtractDocStructureStep(StudyStep):
    llm: BaseLanguageModel
    prompt_language: str = "pt-br"
    step_size: int = 1500
    overlap: int = 300
    name: str = "extract_doc_structure"

    def __post_init__(self) -> None:
        self.structure_chain = create_extract_document_structure_chain(
            prompt_language=self.prompt_language,
            llm=self.llm,
        )

    async def run(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        if ctx.step_is_done(self.name):
            return ctx

        structure_list: List[Dict[str, Any]] = docs_index_meta.get("structure_list", [])

        for idx, (start, end, df_slice) in enumerate(_iter_slices(ctx.df, self.step_size, self.overlap), start=1):
            result = await async_ignore_error_with_these_strings(
                self.structure_chain.ainvoke,
                {"document_as_text": doc_as_dataframe_to_text(df_slice)},
                errors_to_ignore=ERRORS_TO_IGNORE,
                max_retrials=3,
                time_to_wait=1,
            )
            structures = result if isinstance(result, list) else [result]
            structure_list.append(
                {
                    "section_id": idx,
                    "start_row": start,
                    "end_row": end - 1,
                    "structures": structures,
                }
            )

        docs_index_meta.update(
            {
                "structure_list": structure_list,
                "structure_count": len(structure_list),
                "language": self.prompt_language,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
        )
        ctx.mark_step_done(self.name, updated_at=docs_index_meta["updated_at"])
        return ctx

    async def undo(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        for key in ["structure_list", "structure_count", "language", "industrial_tags", "stored_sections"]:
            docs_index_meta.pop(key, None)
        for step_name in [
            "extract_doc_structure",
            "unify_doc_structure",
            "create_section_descriptions",
            "store_section_descriptions",
            "extract_industrial_tags",
        ]:
            docs_index_meta.setdefault("steps", {})[step_name] = {
                "status": "pending",
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
        return ctx


@dataclass
class ExtractDocumentTitleStep(StudyStep):
    llm: BaseLanguageModel
    prompt_language: str = "pt-br"
    max_rows: int = 200
    name: str = "extract_document_title"

    def __post_init__(self) -> None:
        self.title_chain = create_document_title_chain(
            prompt_language=self.prompt_language,
            llm=self.llm,
        )

    async def run(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        if ctx.step_is_done(self.name):
            return ctx

        if ctx.df is None or ctx.df.empty:
            raise ValueError("Dataframe is required to extract document title")

        df_excerpt = ctx.df.iloc[: min(len(ctx.df), self.max_rows)]
        document_excerpt = doc_as_dataframe_to_text(df_excerpt)

        title = await async_ignore_error_with_these_strings(
            self.title_chain.ainvoke,
            {"document_excerpt": document_excerpt},
            errors_to_ignore=ERRORS_TO_IGNORE,
            max_retrials=3,
            time_to_wait=1,
        )

        docs_index_meta["document_title"] = title
        docs_index_meta["updated_at"] = datetime.now(timezone.utc).isoformat()
        ctx.mark_step_done(self.name, updated_at=docs_index_meta["updated_at"])
        return ctx

    async def undo(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        docs_index_meta.pop("document_title", None)
        docs_index_meta.setdefault("steps", {})[self.name] = {
            "status": "pending",
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        return ctx


@dataclass
class UnifyDocStructureStep(StudyStep):
    llm: BaseLanguageModel
    prompt_language: str = "pt-br"
    name: str = "unify_doc_structure"

    def __post_init__(self) -> None:
        self.unify_chain = create_unify_document_structure_chain(
            prompt_language=self.prompt_language,
            llm=self.llm,
        )

    async def run(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        if ctx.step_is_done(self.name):
            return ctx

        structure_list: List[Dict[str, Any]] = docs_index_meta.get("structure_list", [])
        result = await async_ignore_error_with_these_strings(
            self.unify_chain.ainvoke,
            {"structure_list": structure_list},
            errors_to_ignore=ERRORS_TO_IGNORE,
            max_retrials=3,
            time_to_wait=1,
        )

        docs_index_meta["structure_list"] = result
        docs_index_meta["structure_count"] = len(docs_index_meta.get("structure_list", []))
        docs_index_meta["language"] = self.prompt_language
        docs_index_meta["updated_at"] = datetime.now(timezone.utc).isoformat()
        ctx.mark_step_done(self.name, updated_at=docs_index_meta["updated_at"])
        return ctx

    async def undo(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        for step_name in [
            "unify_doc_structure",
            "create_section_descriptions",
            "store_section_descriptions",
            "extract_industrial_tags",
        ]:
            docs_index_meta.setdefault("steps", {})[step_name] = {
                "status": "pending",
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
        return ctx


@dataclass
class DescribeSectionsStep(StudyStep):
    llm: BaseLanguageModel
    prompt_language: str = "pt-br"
    name: str = "create_section_descriptions"

    def __post_init__(self) -> None:
        self.section_description_chain = create_section_descriptions_chain(
            prompt_language=self.prompt_language,
            llm=self.llm,
        )

    async def run(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        if ctx.step_is_done(self.name):
            return ctx

        if not docs_index_meta.get("structure_list"):
            raise ValueError("structure_list is required to describe sections")

        structure_tree = docs_index_meta["structure_list"]

        async def describe_node(title: str, node: Dict[str, Any]) -> Tuple[Dict[str, Any], str]:
            idx_range = node.get("idx_range")
            child_keys = [k for k in node.keys() if k not in {"idx_range", "description"}]

            if node.get("description"):
                return node, node["description"]

            described_children: Dict[str, Any] = {}
            child_summaries: list[str] = []

            for child_title in child_keys:
                child_node, child_summary = await describe_node(child_title, node[child_title])
                described_children[child_title] = child_node
                child_summaries.append(f"{child_title}: {child_summary}")

            if child_keys:
                section_text = "\n".join(child_summaries)
            else:
                if not idx_range or len(idx_range) != 2:
                    raise ValueError(f"Missing idx_range for section '{title}'")
                start_idx, end_idx = idx_range
                try:
                    df_slice = ctx.df.loc[start_idx:end_idx]
                except Exception:
                    df_slice = ctx.df.iloc[start_idx : end_idx + 1]
                section_text = doc_as_dataframe_to_text(df_slice)

            summary = await async_ignore_error_with_these_strings(
                self.section_description_chain.ainvoke,
                {"title": title, "section_text": section_text},
                errors_to_ignore=ERRORS_TO_IGNORE,
                max_retrials=3,
                time_to_wait=1,
            )

            node["description"] = summary
            node.update(described_children)
            docs_index_meta["updated_at"] = datetime.now(timezone.utc).isoformat()
            await ctx.storage.asave(ctx.df, ctx.metadata)

            return node, summary

        for title, node in structure_tree.items():
            await describe_node(title, node)

        docs_index_meta["structure_list"] = structure_tree
        docs_index_meta["updated_at"] = datetime.now(timezone.utc).isoformat()
        ctx.mark_step_done(self.name, updated_at=docs_index_meta["updated_at"])
        return ctx

    async def undo(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        _clear_descriptions(docs_index_meta.get("structure_list"))
        docs_index_meta.pop("industrial_tags", None)
        for step_name in [
            "create_section_descriptions",
            "extract_industrial_tags",
            "store_section_descriptions",
        ]:
            docs_index_meta.setdefault("steps", {})[step_name] = {
                "status": "pending",
                "updated_at": datetime.now(timezone.utc).isoformat(),
            }
        return ctx


@dataclass
class StoreSectionDescriptionsStep(StudyStep):
    docs_sections_memory: DocsSectionsDescriptionsMemory
    name: str = "store_section_descriptions"

    async def run(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        if ctx.step_is_done(self.name):
            return ctx

        if not self.docs_sections_memory:
            raise ValueError("docs_sections_memory is required to store descriptions")

        structure = docs_index_meta.get("structure_list")
        if not isinstance(structure, dict):
            raise ValueError("structure_list must be a unified dict with descriptions")

        await self.docs_sections_memory.abuild_from_structure(
            file_id=ctx.metadata["file_id"],
            structure_tree=structure,
        )

        docs_index_meta["updated_at"] = datetime.now(timezone.utc).isoformat()
        ctx.mark_step_done(self.name, updated_at=docs_index_meta["updated_at"])
        return ctx

    async def undo(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        structure = docs_index_meta.get("structure_list")
        file_id = ctx.metadata.get("file_id")

        if structure and isinstance(structure, dict) and file_id:
            for path, node in DocsSectionsDescriptionsMemory._iter_nodes(structure):
                if node.get("description"):
                    await self.docs_sections_memory.adelete_description(file_id=file_id, path=path)

        docs_index_meta.pop("stored_sections", None)
        docs_index_meta.setdefault("steps", {})[self.name] = {
            "status": "pending",
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        return ctx


@dataclass
class ExtractIndustrialTagsStep(StudyStep):
    name: str = "extract_industrial_tags"

    async def run(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        if ctx.step_is_done(self.name):
            return ctx

        industrial_tags: Dict[str, List[Dict[str, int]]] = {}

        structure_tree = docs_index_meta.get("structure_list") if isinstance(docs_index_meta.get("structure_list"), dict) else None
        file_id = ctx.metadata.get("file_id")

        for pos_idx, row in enumerate(ctx.df.itertuples(index=False), start=0):
            text = str(getattr(row, "block_content", ""))

            section_path: Optional[List[str]] = None
            if structure_tree is not None and file_id:
                found_path = _find_section_path_for_idx(structure_tree, int(pos_idx))
                if found_path:
                    section_path = [file_id, *found_path]

            spans = find_tag_spans(text)
            for tag, positions in spans.items():
                for start, end in positions:
                    entry: Dict[str, Any] = {"df_idx": int(pos_idx), "start": int(start), "end": int(end)}
                    if section_path:
                        entry["path"] = section_path
                    industrial_tags.setdefault(tag, []).append(entry)

        docs_index_meta["industrial_tags"] = industrial_tags
        docs_index_meta["updated_at"] = datetime.now(timezone.utc).isoformat()
        ctx.mark_step_done(self.name, updated_at=docs_index_meta["updated_at"])
        return ctx

    async def undo(self, ctx: StudyContext) -> StudyContext:
        docs_index_meta = ctx.docs_index_meta()
        docs_index_meta.pop("industrial_tags", None)
        docs_index_meta.setdefault("steps", {})[self.name] = {
            "status": "pending",
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        return ctx


# --- utilities ---
def _clear_descriptions(structure: Any) -> None:
    if isinstance(structure, dict):
        structure.pop("description", None)
        for _, value in list(structure.items()):
            _clear_descriptions(value)
    elif isinstance(structure, list):
        for item in structure:
            _clear_descriptions(item)


__all__ = [
    "ExtractDocumentTitleStep",
    "ExtractDocStructureStep",
    "UnifyDocStructureStep",
    "DescribeSectionsStep",
    "StoreSectionDescriptionsStep",
    "ExtractIndustrialTagsStep",
    "_get_node_by_path",
    "_find_section_path_for_idx",
]
