from __future__ import annotations

import copy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Set

import pandas as pd
from PIL import Image

from eagle.utils.domain_utils.industrial_processes.text_extraction_utils import find_tag_spans
from eagle.utils.ranking_utils import bm25_rank_dataframe, STOP_WORDS_EN, STOP_WORDS_PT_BR
from eagle.utils.doc_as_dataframe_utils import doc_as_dataframe_to_text
from eagle.utils.image_utils import object_to_image_url

from eagle.ingestors.docs_index.steps import _get_node_by_path

STOP_WORDS = STOP_WORDS_EN.union(STOP_WORDS_PT_BR)


def _normalize_scores(scores: Dict[Tuple[str, ...], float]) -> Dict[Tuple[str, ...], float]:
    if not scores:
        return {}
    max_val = max(scores.values())
    if max_val <= 0:
        return {k: 0.0 for k in scores}
    return {k: v / max_val for k, v in scores.items()}


def _build_context_snippets(
    file_id: str,
    entries: List[Dict[str, Any]],
    file_dfs: Dict[str, pd.DataFrame],
    window: int = 80,
) -> List[Dict[str, str]]:
    df = file_dfs.get(file_id)
    if df is None:
        return []

    snippets: List[Dict[str, str]] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        idx = entry.get("df_idx")
        if idx is None:
            continue
        try:
            row = df.iloc[int(idx)]
        except Exception:
            try:
                row = df.loc[idx]
            except Exception:
                continue

        text = str(row.get("block_content", ""))
        if not text:
            continue
        text_len = len(text)

        try:
            start_raw = int(entry.get("start", 0))
            end_raw = int(entry.get("end", start_raw + 1))
        except Exception:
            continue

        start = max(0, start_raw)
        if start >= text_len:
            start = text_len - 1 if text_len > 0 else 0
        end = max(start + 1, end_raw)
        end = min(end, text_len)
        start_ctx = max(0, start - window)
        end_ctx = min(text_len, end + window)

        tag_text = text[start:end]
        prefix = text[start_ctx:start]
        suffix = text[end:end_ctx]
        snippet_text = f"{prefix}<{tag_text}>{suffix}".strip()
        if not snippet_text:
            continue

        snippets.append(
            {
                "tag": entry.get("tag"),
                "snippet": f"...{snippet_text}...",
            }
        )

    return snippets


def _build_context_from_paths(
    paths: List[List[str]],
    structures: Dict[str, Dict[str, Any]],
    file_dfs: Dict[str, pd.DataFrame],
    metadata_formatter: Optional["MetadataFormatter"] = None,
    metadata_map: Optional[Dict[str, Dict[str, Any]]] = None,
) -> str:
    contexts: List[str] = []
    metadata_added: Set[str] = set()
    for path in paths:
        if not path:
            continue
        file_id, *section_path = path
        if not section_path:
            continue

        if metadata_formatter and metadata_map is not None and file_id not in metadata_added:
            meta_text = metadata_formatter.format(file_id, metadata_map.get(file_id))
            if meta_text:
                contexts.append(meta_text)
            metadata_added.add(file_id)

        structure = structures.get(file_id)
        df = file_dfs.get(file_id)
        if structure is None or df is None:
            continue
        node = _get_node_by_path(structure, list(section_path))
        if not isinstance(node, dict):
            continue
        idx_range = node.get("idx_range")
        if not isinstance(idx_range, (list, tuple)) or len(idx_range) != 2:
            continue
        try:
            start_idx = int(idx_range[0])
            end_idx = int(idx_range[1])
        except Exception:
            continue
        try:
            df_slice = df.loc[start_idx:end_idx]
        except Exception:
            df_slice = df.iloc[start_idx : end_idx + 1]
        text = doc_as_dataframe_to_text(df_slice)
        if text:
            path_text = " > ".join([str(file_id), *[str(p) for p in section_path]])
            header = f"[PATH {path_text} | idx_range: {start_idx}-{end_idx}]"
            contexts.append(f"{header}\n{text.strip()}")
    separator = "\n\n----\n\n"
    return separator.join(contexts)


def _image_path_to_url(image_path: str, format_hint: Optional[str] = None) -> Optional[str]:
    try:
        with Image.open(Path(image_path)) as img:
            return object_to_image_url(img, format=format_hint)
    except Exception:
        return None


def _format_row_with_idx(idx: Any, row: pd.Series) -> Optional[str]:
    block_label = row.get("block_label")
    if block_label == "image":
        image_data = row.get("block_content") or {}
        image_description = image_data.get("image_description")
        base = f"[IDX {idx}] [Imagem]"
        if image_description not in (None, ""):
            base += f" {image_description}"
        return base
    if block_label == "table":
        table_data = row.get("block_content") or {}
        parts: List[str] = [f"[IDX {idx}] [Tabela '{table_data.get('table_name', '')}']"]
        table_desc = table_data.get("table_description")
        table_html = table_data.get("table_html")
        if table_desc:
            parts.append(str(table_desc))
        if table_html:
            parts.append(str(table_html))
        return "\n".join([p for p in parts if p])
    if block_label in ["header", "footer", "figure_title"]:
        return None
    text = str(row.get("block_content", ""))
    if not text:
        return None
    return f"[IDX {idx}] {text}"


def _build_context_items(
    paths: List[List[str]],
    structures: Dict[str, Dict[str, Any]],
    file_dfs: Dict[str, pd.DataFrame],
    *,
    metadata_formatter: Optional["MetadataFormatter"] = None,
    metadata_map: Optional[Dict[str, Dict[str, Any]]] = None,
    image_detail: str = "high",
    multimodal: bool = True,
) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    metadata_added: Set[str] = set()

    for path in paths:
        if not path:
            continue
        file_id, *section_path = path
        if not section_path:
            continue

        if metadata_formatter and metadata_map is not None and file_id not in metadata_added:
            meta_text = metadata_formatter.format(file_id, metadata_map.get(file_id))
            if meta_text:
                items.append({"type": "text", "text": meta_text})
            metadata_added.add(file_id)

        structure = structures.get(file_id)
        df = file_dfs.get(file_id)
        if structure is None or df is None:
            continue
        node = _get_node_by_path(structure, list(section_path))
        if not isinstance(node, dict):
            continue
        idx_range = node.get("idx_range")
        if not isinstance(idx_range, (list, tuple)) or len(idx_range) != 2:
            continue
        try:
            start_idx = int(idx_range[0])
            end_idx = int(idx_range[1])
        except Exception:
            continue

        path_text = " > ".join([str(file_id), *[str(p) for p in section_path]])
        items.append({"type": "text", "text": f"[PATH {path_text} | idx_range: {start_idx}-{end_idx}]"})

        try:
            df_slice = df.loc[start_idx:end_idx]
        except Exception:
            df_slice = df.iloc[start_idx : end_idx + 1]

        for idx, row in df_slice.iterrows():
            block_label = row.get("block_label")
            if block_label in ["header", "footer", "figure_title"]:
                continue

            row_text = _format_row_with_idx(idx, row)
            if row_text:
                items.append({"type": "text", "text": row_text})

            if block_label in ["image", "pinned-image"]:
                image_data = row.get("block_content") or {}
                image_path = image_data.get("image_path")
                image_description = image_data.get("image_description")

                if multimodal:
                    if image_path:
                        image_url = _image_path_to_url(image_path)
                        if image_url:
                            items.append(
                                {
                                    "type": "image_url",
                                    "image_url": {"url": image_url, "detail": image_detail},
                                }
                            )
                else:
                    details: List[str] = []
                    if image_path:
                        details.append(f"path={image_path}")
                    if image_description not in (None, ""):
                        details.append(f"desc={image_description}")
                    if details:
                        items.append({"type": "text", "text": "[IMAGE] " + " | ".join(details)})

        # Add all pinned-images from the same page after the section content
        if not df_slice.empty:
            page = df_slice.iloc[-1]['page']
            pinned_rows = df[(df['page'] == page) & (df['block_label'] == 'pinned-image') & (df.index > end_idx)]
            for _, pinned_row in pinned_rows.iterrows():
                image_data = pinned_row.get("block_content") or {}
                image_path = image_data.get("image_path")
                image_description = image_data.get("image_description")

                if multimodal:
                    if image_path:
                        image_url = _image_path_to_url(image_path)
                        if image_url:
                            items.append(
                                {
                                    "type": "image_url",
                                    "image_url": {"url": image_url, "detail": image_detail},
                                }
                            )
                else:
                    details: List[str] = []
                    if image_path:
                        details.append(f"path={image_path}")
                    if image_description not in (None, ""):
                        details.append(f"desc={image_description}")
                    if details:
                        items.append({"type": "text", "text": "[IMAGE] " + " | ".join(details)})

        return items

def build_context(
    paths: List[List[str]],
    structures: Dict[str, Dict[str, Any]],
    file_dfs: Dict[str, pd.DataFrame],
    *,
    metadata_formatter: Optional["MetadataFormatter"] = None,
    metadata_map: Optional[Dict[str, Dict[str, Any]]] = None,
    multimodal: bool = False,
) -> List[Dict[str, Any]]:
    return _build_context_items(
        paths,
        structures,
        file_dfs,
        metadata_formatter=metadata_formatter,
        metadata_map=metadata_map,
        multimodal=multimodal,
    )


@dataclass
class VectorSectionsRetriever:
    docs_sections_memory: Any

    async def retrieve(self, question: str, file_ids: List[str], limit: int) -> Dict[str, Any]:
        memory_hits = await self.docs_sections_memory.asearch_memories(
            query=question,
            limit=limit,
            filter_file_ids=file_ids,
        )

        path_scores: Dict[Tuple[str, ...], float] = {}
        for hit in memory_hits:
            file_id = hit.get("file_id")
            path = hit.get("path") or []
            if not file_id or not path:
                continue
            key: Tuple[str, ...] = tuple([file_id, *[str(p) for p in path]])
            path_scores[key] = path_scores.get(key, 0.0) + 1.0

        ranked_paths = sorted(path_scores.items(), key=lambda kv: (-kv[1], kv[0]))
        return {
            "memory_hits": memory_hits,
            "path_scores": path_scores,
            "ranked_paths": ranked_paths,
            "normalized_scores": _normalize_scores(path_scores),
        }


@dataclass
class TagSectionsRetriever:
    storage: Any

    async def retrieve(self, question: str, file_ids: List[str], limit: int) -> Dict[str, Any]:
        spans = find_tag_spans(question)
        detected_tags = list(spans.keys()) if isinstance(spans, dict) else []
        if not detected_tags:
            return {
                "detected_tags": [],
                "path_scores": {},
                "ranked_paths": [],
                "path_entries": {},
                "per_tag_results": [],
                "normalized_scores": {},
            }

        rows: List[Dict[str, Any]] = []
        for file_id in file_ids:
            try:
                stored_metadata, _ = await self.storage.aload(file_id)
            except KeyError:
                continue

            tags = (
                stored_metadata.get("studies", {})
                .get("docs_index", {})
                .get("industrial_tags", {})
            )

            if not isinstance(tags, dict):
                continue

            for tag, entries in tags.items():
                if not isinstance(entries, list):
                    continue
                for entry in entries:
                    if not isinstance(entry, dict):
                        continue
                    path = entry.get("path")
                    if not path:
                        continue
                    rows.append(
                        {
                            "tag": str(tag),
                            "path": path,
                            "df_idx": entry.get("df_idx"),
                            "start": entry.get("start"),
                            "end": entry.get("end"),
                        }
                    )

        if not rows:
            return {
                "detected_tags": detected_tags,
                "path_scores": {},
                "ranked_paths": [],
                "path_entries": {},
                "per_tag_results": [],
                "normalized_scores": {},
            }

        df = pd.DataFrame(rows)
        path_scores: Dict[Tuple[str, ...], float] = {}
        path_entries: Dict[Tuple[str, ...], List[Dict[str, Any]]] = {}
        per_tag_results: List[Dict[str, Any]] = []

        for tag in detected_tags:
            ranked_df = bm25_rank_dataframe(
                df=df,
                query=str(tag),
                columns=["tag"],
                weights=[1.0],
                stopwords=STOP_WORDS,
                apply_stemming=True,
            )

            top_df = ranked_df.head(limit)
            tag_paths: List[List[str]] = []
            for _, row in top_df.iterrows():
                path = row.get("path")
                if not path:
                    continue
                key = tuple([str(p) for p in path])
                score = float(row.get("bm25_score", 0.0))
                path_scores[key] = max(path_scores.get(key, 0.0), score)

                try:
                    df_idx_val = int(row.get("df_idx")) if row.get("df_idx") is not None else None
                except Exception:
                    df_idx_val = None
                try:
                    start_val = int(row.get("start")) if row.get("start") is not None else None
                except Exception:
                    start_val = None
                try:
                    end_val = int(row.get("end")) if row.get("end") is not None else None
                except Exception:
                    end_val = None

                path_entries.setdefault(key, []).append(
                    {
                        "tag": row.get("tag"),
                        "df_idx": df_idx_val,
                        "start": start_val,
                        "end": end_val,
                    }
                )
                tag_paths.append([str(p) for p in path])

            per_tag_results.append({"tag": tag, "top_paths": tag_paths})

        ranked_paths = sorted(path_scores.items(), key=lambda kv: (-kv[1], kv[0]))
        return {
            "detected_tags": detected_tags,
            "path_scores": path_scores,
            "ranked_paths": ranked_paths,
            "path_entries": path_entries,
            "per_tag_results": per_tag_results,
            "normalized_scores": _normalize_scores(path_scores),
        }


@dataclass
class SectionsRanker:
    weight_vector: float = 0.6
    weight_tags: float = 0.4

    def fuse(
        self,
        vector_scores: Dict[Tuple[str, ...], float],
        tag_scores: Dict[Tuple[str, ...], float],
        allowed_vector: set[Tuple[str, ...]] | None = None,
        allowed_tags: set[Tuple[str, ...]] | None = None,
    ) -> List[Tuple[Tuple[str, ...], float]]:
        combined_scores: Dict[Tuple[str, ...], float] = {}

        for key, score in vector_scores.items():
            if allowed_vector and key not in allowed_vector:
                continue
            combined_scores[key] = combined_scores.get(key, 0.0) + self.weight_vector * score

        for key, score in tag_scores.items():
            if allowed_tags and key not in allowed_tags:
                continue
            combined_scores[key] = combined_scores.get(key, 0.0) + self.weight_tags * score

        return sorted(combined_scores.items(), key=lambda kv: (-kv[1], kv[0]))


def format_sections_for_prompt(sections: List[Dict[str, Any]]) -> str:
    lines: List[str] = []
    for item in sections:
        path_text = " > ".join([item["file_id"], *item["path"]])
        description = item.get("description_override") or item["node"].get("description") or ""

        context_lines: List[str] = []
        for ctx in item.get("context_snippets", []):
            tag = ctx.get("tag")
            snippet = ctx.get("snippet")
            if not snippet:
                continue
            prefix = f"Tag {tag}: " if tag else "Contexto: "
            context_lines.append(prefix + snippet)

        body_parts = [f"Descrição: {description}".strip()]
        if context_lines:
            body_parts.append("Contexto detectado:\n- " + "\n- ".join(context_lines))

        lines.append(f"[{item['file_id']}] {path_text}\n" + "\n".join(body_parts))

    return "\n\n".join(lines)

@dataclass
class MetadataFormatter:
    include_keys: Tuple[str, ...] = (
        "file_id",
        "path"
    )
    max_items: int = 6

    def format(self, file_id: str, metadata: Optional[Dict[str, Any]]) -> Optional[str]:
        if not isinstance(metadata, dict):
            return None

        meta_source = metadata.get("metadata") if isinstance(metadata.get("metadata"), dict) else metadata
        lines: List[str] = []

        for key in self.include_keys:
            val = None
            if isinstance(meta_source, dict):
                val = meta_source.get(key)
            if val is None and key in metadata:
                val = metadata.get(key)
            if val is None:
                continue
            lines.append(f"{key}: {val}")
            if len(lines) >= self.max_items:
                break

        if not lines:
            return None

        return f"[METADATA {file_id}]\n" + "\n".join(lines)


@dataclass
class QAResponder:
    q_and_a_chain: Any

    async def answer(self, question: str, context_items: List[Dict[str, Any]]) -> Any:
        return await self.q_and_a_chain.ainvoke({"question": question, "context_items": context_items})


@dataclass
class QuestionDescriptionsSplitter:
    split_chain: Any

    async def split(self, question: str) -> List[str]:
        result = await self.split_chain.ainvoke({"question": question})

        return result.descriptions

__all__ = [
    "VectorSectionsRetriever",
    "TagSectionsRetriever",
    "SectionsRanker",
    "format_sections_for_prompt",
    "build_context",
    "build_multimodal_context",
    "QAResponder",
    "QuestionDescriptionsSplitter",
    "_build_context_snippets",
    "MetadataFormatter",
]
