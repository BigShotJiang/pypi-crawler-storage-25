from __future__ import annotations

import asyncio
import re
from abc import ABC, abstractmethod
from enum import Enum
from pathlib import Path
from typing import Any

import pandas as pd
from pydantic import BaseModel, ConfigDict, Field, field_validator


class ComparisonOperator(str, Enum):
	"""Supported comparison operators for metadata filtering."""

	EQUALS = "equals"
	NOT_EQUALS = "not_equals"
	GREATER_THAN = "greater_than"
	GREATER_THAN_OR_EQUALS = "greater_than_or_equals"
	LESS_THAN = "less_than"
	LESS_THAN_OR_EQUALS = "less_than_or_equals"
	CONTAINS = "contains"
	IN_LIST = "in"
	REGEX_MATCH = "regex_match"


class DocumentStorageSearchItem(BaseModel):
	"""Single search clause applied to a metadata path."""

	metadata_path: str = Field(..., description="Dot-separated path, e.g. author.name")
	metadata_value: Any = Field(..., description="Value to compare against the metadata field")
	comparison_operator: ComparisonOperator = Field(
		default=ComparisonOperator.EQUALS,
		description="Logical comparison operator to apply",
	)

	model_config = ConfigDict(str_strip_whitespace=True)

	@field_validator("metadata_path")
	@classmethod
	def _validate_metadata_path(cls, value: str) -> str:
		if not value:
			raise ValueError("metadata_path must not be empty")
		return value


class DocumentStorageSearchQuery(BaseModel):
	"""Nested search query combining items with AND/OR logic."""

	search_items: list[DocumentStorageSearchItem | DocumentStorageSearchQuery] = Field(
		default_factory=list, description="Clauses or sub-queries to evaluate",
	)
	logical_operator: str = Field(
		default="AND", description="How to combine the contained clauses (AND/OR)",
	)

	model_config = ConfigDict(str_strip_whitespace=True)

	@field_validator("logical_operator")
	@classmethod
	def _normalize_operator(cls, value: str) -> str:
		normalized = value.upper()
		if normalized not in {"AND", "OR"}:
			raise ValueError("logical_operator must be either 'AND' or 'OR'")
		return normalized


# Enable forward references for the self-referential query model
DocumentStorageSearchQuery.model_rebuild()

_NOT_FOUND = object()


def _get_nested_value(metadata: dict[str, Any], path: str) -> Any:
	"""Safely fetch a nested value from a metadata dict using dotted paths."""

	current: Any = metadata
	for part in path.split("."):
		if isinstance(current, dict) and part in current:
			current = current[part]
		else:
			return _NOT_FOUND
	return current


def _compare_values(value: Any, expected: Any, operator: ComparisonOperator) -> bool:
	"""Apply the configured comparison operator to the values."""

	try:
		if operator is ComparisonOperator.EQUALS:
			return value == expected
		if operator is ComparisonOperator.NOT_EQUALS:
			return value != expected
		if operator is ComparisonOperator.GREATER_THAN:
			return float(value) > float(expected)
		if operator is ComparisonOperator.GREATER_THAN_OR_EQUALS:
			return float(value) >= float(expected)
		if operator is ComparisonOperator.LESS_THAN:
			return float(value) < float(expected)
		if operator is ComparisonOperator.LESS_THAN_OR_EQUALS:
			return float(value) <= float(expected)
		if operator is ComparisonOperator.CONTAINS:
			if isinstance(value, (list, tuple, set, str)):
				return expected in value
			return False
		if operator is ComparisonOperator.IN_LIST:
			if isinstance(expected, (list, tuple, set)):
				return value in expected
			return False
		if operator is ComparisonOperator.REGEX_MATCH:
			if value is None:
				return False
			return re.search(str(expected), str(value)) is not None
	except (TypeError, ValueError):
		return False

	return False


def evaluate_search_item(metadata: dict[str, Any], item: DocumentStorageSearchItem) -> bool:
	"""Evaluate a single search item against provided metadata."""

	current_value = _get_nested_value(metadata, item.metadata_path)
	if current_value is _NOT_FOUND:
		return False
	return _compare_values(current_value, item.metadata_value, item.comparison_operator)


def evaluate_search_query(metadata: dict[str, Any], query: DocumentStorageSearchQuery) -> bool:
	"""Evaluate a nested search query against provided metadata."""

	if not query.search_items:
		return True

	evaluations: list[bool] = []
	for child in query.search_items:
		if isinstance(child, DocumentStorageSearchItem):
			evaluations.append(evaluate_search_item(metadata, child))
		else:
			evaluations.append(evaluate_search_query(metadata, child))

	if query.logical_operator == "AND":
		return all(evaluations)
	return any(evaluations)


_TOKEN_PATTERN = re.compile(
	r"""
		(\()|(\))|                              # parentheses
		(>=|<=|!=|==|>|<|~=|~)|                    # comparison operators
		(CONTAINS|IN|AND|OR)|                     # keywords
		("[^"]*"|'[^']*')|                      # quoted strings
		([A-Za-z_][A-Za-z0-9_.]*)|               # identifiers / dotted paths
		([0-9]+(?:\.[0-9]+)?)                    # numbers
	""",
	re.IGNORECASE | re.VERBOSE,
)


def _tokenize_query(query_str: str) -> list[str]:
	return [m.group(0) for m in _TOKEN_PATTERN.finditer(query_str)]


def _parse_value(tok: str) -> Any:
	if tok.startswith("'") or tok.startswith('"'):
		return tok[1:-1]
	if re.fullmatch(r"[0-9]+", tok):
		return int(tok)
	if re.fullmatch(r"[0-9]+\.[0-9]+", tok):
		return float(tok)
	return tok


def _operator_from_token(tok: str) -> ComparisonOperator:
	up = tok.upper()
	if up == "==":
		return ComparisonOperator.EQUALS
	if up == "!=":
		return ComparisonOperator.NOT_EQUALS
	if up == ">":
		return ComparisonOperator.GREATER_THAN
	if up == ">=":
		return ComparisonOperator.GREATER_THAN_OR_EQUALS
	if up == "<":
		return ComparisonOperator.LESS_THAN
	if up == "<=":
		return ComparisonOperator.LESS_THAN_OR_EQUALS
	if up == "CONTAINS":
		return ComparisonOperator.CONTAINS
	if up == "IN":
		return ComparisonOperator.IN_LIST
	if up in {"~", "~=", "REGEX"}:
		return ComparisonOperator.REGEX_MATCH
	raise ValueError(f"Unsupported operator token: {tok}")


def _merge_nodes(
	left: DocumentStorageSearchItem | DocumentStorageSearchQuery,
	right: DocumentStorageSearchItem | DocumentStorageSearchQuery,
	logical_op: str,
) -> DocumentStorageSearchQuery:
	logical = logical_op.upper()
	if logical not in {"AND", "OR"}:
		raise ValueError(f"Invalid logical operator: {logical_op}")

	def wrap(node):
		return node if isinstance(node, DocumentStorageSearchQuery) else DocumentStorageSearchQuery(search_items=[node])

	left_q = wrap(left)
	right_q = wrap(right)

	if left_q.logical_operator == logical:
		items = list(left_q.search_items)
	else:
		items = [left_q]

	items.append(right_q if isinstance(right, DocumentStorageSearchQuery) else right)

	return DocumentStorageSearchQuery(search_items=items, logical_operator=logical)


def _parse_comparison(tokens: list[str], idx: int) -> tuple[DocumentStorageSearchItem, int]:
	if idx + 2 >= len(tokens):
		raise ValueError("Incomplete comparison expression")
	field = tokens[idx]
	op_tok = tokens[idx + 1]
	value_tok = tokens[idx + 2]
	item = DocumentStorageSearchItem(
		metadata_path=field,
		metadata_value=_parse_value(value_tok),
		comparison_operator=_operator_from_token(op_tok),
	)
	return item, idx + 3


def _parse_factor(tokens: list[str], idx: int) -> tuple[DocumentStorageSearchItem | DocumentStorageSearchQuery, int]:
	if tokens[idx] == "(":
		node, next_idx = _parse_expression(tokens, idx + 1)
		if next_idx >= len(tokens) or tokens[next_idx] != ")":
			raise ValueError("Unbalanced parentheses")
		return node, next_idx + 1
	return _parse_comparison(tokens, idx)


def _parse_conjunction(tokens: list[str], idx: int) -> tuple[DocumentStorageSearchItem | DocumentStorageSearchQuery, int]:
	node, idx = _parse_factor(tokens, idx)
	while idx < len(tokens) and tokens[idx].upper() == "AND":
		right, idx = _parse_factor(tokens, idx + 1)
		node = _merge_nodes(node, right, "AND")
	return node, idx


def _parse_expression(tokens: list[str], idx: int = 0) -> tuple[DocumentStorageSearchQuery | DocumentStorageSearchItem, int]:
	node, idx = _parse_conjunction(tokens, idx)
	while idx < len(tokens) and tokens[idx].upper() == "OR":
		right, idx = _parse_conjunction(tokens, idx + 1)
		node = _merge_nodes(node, right, "OR")
	return node, idx


class DocumentStorage(ABC):
	"""Base contract for document persistence backends."""

	@staticmethod
	def parse_query_str(query_str: str) -> DocumentStorageSearchQuery:
		"""Parse a simple query string into a DocumentStorageSearchQuery.

		Supported syntax (case-insensitive logicals/operators):
		- Logical: AND, OR, parentheses for grouping
		- Comparisons: ==, !=, >, >=, <, <=, CONTAINS, IN, ~ or ~= (regex)
		- Values: numbers, bare words, or quoted strings ('..." or "...")

		Example:
		"author.age > 25 AND tags CONTAINS ml"
		"version == 1 AND (author.age <= 35 OR author.name == 'Jane Doe')"
		"""

		tokens = _tokenize_query(query_str)
		if not tokens:
			return DocumentStorageSearchQuery()

		node, idx = _parse_expression(tokens, 0)
		if idx != len(tokens):
			raise ValueError(f"Unexpected tokens at position {idx}: {tokens[idx:]}")

		return node if isinstance(node, DocumentStorageSearchQuery) else DocumentStorageSearchQuery(search_items=[node])

	def __init__(self, persistence_dir: str | Path):
		self.persistence_dir = Path(persistence_dir)
		self.persistence_dir.mkdir(parents=True, exist_ok=True)

	def _dataframe_path(self, file_id: str) -> Path:
		return self.persistence_dir / f"{file_id}.pkl"

	def save_dataframe_pickle(self, file_as_df: pd.DataFrame, file_id: str) -> Path:
		path = self._dataframe_path(file_id)
		file_as_df.to_pickle(path)
		return path

	def load_dataframe_pickle(self, file_id: str) -> pd.DataFrame:
		path = self._dataframe_path(file_id)
		return pd.read_pickle(path)

	def remove_dataframe_pickle(self, file_id: str) -> None:
		path = self._dataframe_path(file_id)
		if path.exists():
			path.unlink()

	@abstractmethod
	def save(self, file_as_df: pd.DataFrame, metadata: dict[str, Any]) -> str:
		"""Persist a document and return its storage identifier."""

	@abstractmethod
	def load(self, file_id: str) -> tuple[dict[str, Any], pd.DataFrame]:
		"""Retrieve a document's metadata and dataframe by its identifier."""

	@abstractmethod
	def remove(self, file_id: str) -> None:
		"""Remove a document and its metadata from the storage backend."""

	@abstractmethod
	def search(
		self, query: DocumentStorageSearchQuery
	) -> list[tuple[dict[str, Any], pd.DataFrame]]:
		"""Search documents using nested metadata queries."""

	async def asave(self, file_as_df: pd.DataFrame, metadata: dict[str, Any]) -> str:
		"""Async wrapper around save for convenience."""

		return await asyncio.to_thread(self.save, file_as_df, metadata)

	async def aload(self, file_id: str) -> tuple[dict[str, Any], pd.DataFrame]:
		"""Async wrapper around load for convenience."""

		return await asyncio.to_thread(self.load, file_id)

	async def aremove(self, file_id: str) -> None:
		"""Async wrapper around remove for convenience."""

		await asyncio.to_thread(self.remove, file_id)

	async def asearch(
		self, query: DocumentStorageSearchQuery
	) -> list[tuple[dict[str, Any], pd.DataFrame]]:
		"""Async wrapper around search for convenience."""

		return await asyncio.to_thread(self.search, query)


__all__ = [
	"ComparisonOperator",
	"DocumentStorage",
	"DocumentStorageSearchItem",
	"DocumentStorageSearchQuery",
	"evaluate_search_item",
	"evaluate_search_query",
]