from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
from pymongo import MongoClient
from pymongo.collection import Collection

from eagle.stores.document_storage.base import (
	ComparisonOperator,
	DocumentStorage,
	DocumentStorageSearchQuery,
	evaluate_search_query,
)


def _mongo_condition_for_item(item) -> dict[str, Any]:
	"""Translate a DocumentStorageSearchItem into a MongoDB filter fragment."""

	field = f"metadata.{item.metadata_path}"
	op = item.comparison_operator
	val = item.metadata_value

	if op is ComparisonOperator.EQUALS:
		return {field: val}
	if op is ComparisonOperator.NOT_EQUALS:
		return {field: {"$ne": val}}
	if op is ComparisonOperator.GREATER_THAN:
		return {field: {"$gt": val}}
	if op is ComparisonOperator.GREATER_THAN_OR_EQUALS:
		return {field: {"$gte": val}}
	if op is ComparisonOperator.LESS_THAN:
		return {field: {"$lt": val}}
	if op is ComparisonOperator.LESS_THAN_OR_EQUALS:
		return {field: {"$lte": val}}
	if op is ComparisonOperator.IN_LIST:
		if not isinstance(val, (list, tuple, set)):
			raise ValueError("IN operator expects an iterable value")
		return {field: {"$in": list(val)}}
	if op is ComparisonOperator.CONTAINS:
		# If value is iterable on the field side, $in checks membership
		return {field: {"$in": [val]}}
	if op is ComparisonOperator.REGEX_MATCH:
		return {field: {"$regex": val}}

	raise ValueError(f"Unsupported comparison operator: {op}")


def _mongo_query_from_search_query(query: DocumentStorageSearchQuery) -> dict[str, Any]:
	"""Recursively build a MongoDB filter from a nested search query."""

	if not query.search_items:
		return {}

	clauses: list[dict[str, Any]] = []
	for child in query.search_items:
		if hasattr(child, "metadata_path"):
			clauses.append(_mongo_condition_for_item(child))
		else:
			clauses.append(_mongo_query_from_search_query(child))

	if query.logical_operator == "AND":
		return {"$and": clauses}
	return {"$or": clauses}

class MongoDocumentStorage(DocumentStorage):
	"""DocumentStorage implementation backed by MongoDB and local pickle files."""

	def __init__(
		self,
		*,
		mongo_uri: str = "mongodb://localhost:27017",
		database: str = "eagle",
		collection: str = "documents",
		persistence_dir: str | Path = "ingested_files",
		mongo_kwargs: dict[str, Any] | None = None,
	) -> None:
		super().__init__(persistence_dir)
		self.client = MongoClient(mongo_uri, **(mongo_kwargs or {}))
		self.db = self.client[database]
		self.collection: Collection = self.db[collection]
		self.collection.create_index("file_id", unique=True)

	def save(self, file_as_df: pd.DataFrame, metadata: dict[str, Any]) -> str:
		file_id = metadata.get("file_id")
		if not file_id:
			raise ValueError("metadata must contain a 'file_id'")

		df_path = self.save_dataframe_pickle(file_as_df, file_id)
		document = {
			"file_id": file_id,
			"metadata": metadata,
			"df_path": str(df_path),
			"updated_at": datetime.now(timezone.utc),
		}
		# upsert to allow idempotent saves
		self.collection.update_one(
			{"file_id": file_id}, {"$set": document, "$setOnInsert": {"created_at": datetime.now(timezone.utc)}}, upsert=True
		)
		return file_id

	def load(self, file_id: str) -> tuple[dict[str, Any], pd.DataFrame]:
		document = self.collection.find_one({"file_id": file_id}, {"metadata": 1, "df_path": 1})
		if not document:
			raise KeyError(f"File ID '{file_id}' not found in MongoDB.")
		metadata = document.get("metadata", {})
		return metadata, self.load_dataframe_pickle(file_id)

	def remove(self, file_id: str) -> None:
		self.collection.delete_one({"file_id": file_id})
		self.remove_dataframe_pickle(file_id)

	def search(
		self, query: DocumentStorageSearchQuery
	) -> list[tuple[dict[str, Any], pd.DataFrame]]:
		mongo_filter = _mongo_query_from_search_query(query)
		# Fallback to in-memory evaluation for any edge cases the translation misses
		cursor = self.collection.find(mongo_filter or {}, {"metadata": 1, "df_path": 1, "file_id": 1})
		results: list[tuple[dict[str, Any], pd.DataFrame]] = []
		for doc in cursor:
			metadata = doc.get("metadata", {})
			if evaluate_search_query(metadata, query):
				file_id = doc.get("file_id")
				if not file_id:
					continue
				results.append((metadata, self.load_dataframe_pickle(file_id)))
		return results

	def close(self) -> None:
		self.client.close()

	def __del__(self) -> None:
		try:
			self.close()
		except Exception:
			pass


__all__ = ["MongoDocumentStorage"]