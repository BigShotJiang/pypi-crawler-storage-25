# eagle/stores/tests/test_opensearch_store.py

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

import pytest
pytestmark = [pytest.mark.integration, pytest.mark.opensearch]


import eagle.stores.opensearch as m

class FakeTransport:
    def __init__(self):
        self.closed = False

    def close(self):
        self.closed = True


class FakeIndices:
    def __init__(self):
        self._exists = set()
        self.created: List[tuple[str, dict]] = []

    def exists(self, index: str):
        return index in self._exists

    def create(self, index: str, body: dict):
        self._exists.add(index)
        self.created.append((index, body))


class FakeOpenSearchClient:
    def __init__(self):
        self.indices = FakeIndices()
        self.transport = FakeTransport()

        # controle de respostas
        self._search_hits: List[dict] = []

        # rastreio de chamadas
        self.search_calls: List[tuple[str, dict, Optional[int]]] = []
        self.index_calls: List[tuple[str, str, dict]] = []

    def set_search_hits(self, hits: List[dict]):
        self._search_hits = hits

    def search(self, index: str, body: dict, size: int = None, **kwargs):
        self.search_calls.append((index, body, size))
        return {"hits": {"hits": self._search_hits}}

    def index(self, index: str, id: str, body: dict, **kwargs):
        self.index_calls.append((index, id, body))
        return {"result": "created"}


@dataclass
class FakeEmbeddings:
    embed_query_calls: List[str] = field(default_factory=list)

    def embed_query(self, text: str):
        self.embed_query_calls.append(text)
        return [0.1, 0.2, 0.3]


def _make_store_for_cache_tests(monkeypatch, client: FakeOpenSearchClient):
    """
    Cria store sem depender de ensure_embeddings (porque index=None).
    A gente injeta manualmente index_config e embeddings.
    """
    # patch do factory usado por OpenSearchStore.with_client()
    monkeypatch.setattr(m, "_get_opensearch_client", lambda *a, **k: client)

    store = m.OpenSearchStore(index=None)

    # garante config mínima pro cache
    store.general_index_prefix = ""
    store.index_config = {"embedding_name": "ModelX"}

    # injeta embeddings fake
    store.embeddings = FakeEmbeddings()

    # opcional: deixa previsível
    store.full_url = "http://fake"
    store.connection_kwargs = {}

    return store


def test_embed_text_with_cache_hit(monkeypatch):
    client = FakeOpenSearchClient()
    store = _make_store_for_cache_tests(monkeypatch, client)

    # se o índice de cache não existir, o método vai criar (ok).
    # aqui tanto faz, mas vamos marcar como existente pra ficar “limpo”
    cache_index = store.get_embedding_cache_index_name()
    client.indices._exists.add(cache_index)

    # HIT: search devolve embedding
    client.set_search_hits([{"_source": {"embedding": [9.0, 8.0, 7.0]}}])

    out = store.embed_text_with_cache("hello")

    assert out == [9.0, 8.0, 7.0]
    assert store.embeddings.embed_query_calls == []          # não embedou
    assert client.index_calls == []                          # não gravou nada
    assert client.transport.closed is True                   # with_client fechou transporte


def test_embed_text_with_cache_miss_stores(monkeypatch):
    client = FakeOpenSearchClient()
    store = _make_store_for_cache_tests(monkeypatch, client)

    cache_index = store.get_embedding_cache_index_name()
    # MISS: sem hits
    client.set_search_hits([])

    out = store.embed_text_with_cache("hello")

    assert out == [0.1, 0.2, 0.3]
    assert store.embeddings.embed_query_calls == ["hello"]

    # deve ter gravado no cache
    assert len(client.index_calls) == 1
    idx, doc_id, body = client.index_calls[0]

    assert idx == cache_index
    assert body["text"] == "hello"
    assert body["embedding"] == [0.1, 0.2, 0.3]
    assert "created_at" in body
    assert isinstance(body["created_at"], datetime)

    assert client.transport.closed is True
