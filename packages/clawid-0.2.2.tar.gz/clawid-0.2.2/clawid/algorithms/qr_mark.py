"""
QR-Mark: AI-readable invisible watermarking via perceptually-adaptive tiled QR codes.

Embedding model: additive bipolar perturbation with JND adaptive strength.

WHY additive, not blending:
  Old model: result = orig*(1−m) + qr_bw*m
  Problem on dark images: white QR module at 5% on dark pixel (value=25):
    25*0.95 + 255*0.05 = 36.5  →  +46% relative increase  →  clearly visible
  Problem on bright images: black QR module at 5% on bright pixel (value=230):
    230*0.95 + 0*0.05 = 218.5  →  −5% on an already-bright pixel  →  visible

  New model: result = orig + (qr − 128) * strength / 128
  White module on ANY pixel: +strength (e.g. ±6px at default — symmetric, content-independent)
  Black module on ANY pixel: −strength
  The perturbation is independent of background brightness → works on dark, bright, mid-tone.

JND masking: strength scales with local edge density and luminance mid-tonedness:
  - Smooth/flat areas: minimum strength → barely perceptible even on close inspection
  - Edge/texture areas: up to peak strength → hidden in the visual complexity the eye ignores
  - Dark/bright extremes: reduced further (Weber's law: JND threshold is lower near extremes)

Properties:
  - Invisible on dark, mid-tone, AND bright backgrounds
  - Directly readable by AI vision models (GPT-4V, Gemini, Grok, Claude)
  - Readable by QR scanners after CLAHE contrast enhancement
  - Survives: PNG lossless, JPEG q≥80, screenshots, 50% crop (2×2 tiling)
"""

import json
import numpy as np
from PIL import Image, ImageFilter
from typing import Optional

try:
    import qrcode
    import qrcode.constants
    _QRCODE_OK = True
except ImportError:
    _QRCODE_OK = False

try:
    import cv2
    _CV2_OK = True
except ImportError:
    _CV2_OK = False

try:
    from pyzbar import pyzbar as _pyzbar
    _PYZBAR_OK = True
except ImportError:
    _PYZBAR_OK = False


DEFAULT_OPACITY = 0.06   # base perturbation strength (±7.7 pixels on flat regions)
_JND_PEAK_RATIO = 2.0    # textured regions get up to 2× strength (±15 pixels max)
_JND_MAX_OPACITY = 0.12  # hard cap on strength
MIN_QR_DIM = 100         # minimum pixel size per QR tile to stay decodable


def embed_qr(
    image: Image.Image,
    metadata: dict,
    opacity: float = DEFAULT_OPACITY,
) -> Image.Image:
    """
    Embed metadata as an invisible tiled QR code using additive bipolar perturbation.

    The watermark adds/subtracts a small symmetric perturbation (±strength pixels)
    centered on the local image content — completely independent of whether the
    background is dark, bright, or mid-tone. JND masking further concentrates energy
    in textured regions and suppresses it on smooth/extreme areas.

    Args:
        image:    RGB PIL Image (min 256×256)
        metadata: dict — serialised as compact JSON into the QR
        opacity:  perturbation strength 0.0–0.20 (default 0.06 = ±7.7px)
                  0.04 = near-invisible everywhere, PNG-only detection
                  0.06 = default: invisible, reliable PNG detection
                  0.10 = slightly visible on flat backgrounds, JPEG q≥80 robust
                  0.15 = clearly detectable by all scanners, JPEG q≥70

    Returns:
        Watermarked RGB PIL Image (visually identical to input at default strength)
    """
    if not _QRCODE_OK:
        raise ImportError("qrcode required: pip install 'qrcode[pil]'")

    img = image.convert('RGB')
    w, h = img.size

    # Compact keys → smaller QR version → larger modules → better detection
    _KEY_MAP = {'clawid': 'c', 'uid': 'u', 'platform': 'p', 'asset_id': 'a', 'ts': 't'}
    compact = {_KEY_MAP.get(k, k): v for k, v in metadata.items()}
    payload = json.dumps(compact, separators=(',', ':'), ensure_ascii=False)

    # QR with HIGH error correction (tolerates 30% module damage)
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=10,
        border=3,
    )
    qr.add_data(payload)
    qr.make(fit=True)
    qr_raw = qr.make_image(fill_color='black', back_color='white').convert('L')

    # Resize to one quadrant, re-binarise (LANCZOS blurs edges; threshold restores them)
    tile_w = max(w // 2, MIN_QR_DIM)
    tile_h = max(h // 2, MIN_QR_DIM)
    qr_tile = qr_raw.resize((tile_w, tile_h), Image.LANCZOS)
    qr_tile = qr_tile.point(lambda p: 0 if p < 128 else 255, '1').convert('L')

    # 2×2 tiled overlay — one full QR per quadrant for crop robustness
    tiled = Image.new('L', (w, h), 255)
    for row in range(2):
        for col in range(2):
            tiled.paste(qr_tile, (col * tile_w, row * tile_h))

    orig_arr = np.array(img, dtype=np.float32)           # H×W×3

    # ── Bipolar QR signal: black module = −1, white module = +1 ──────────────
    # This is the critical difference from blending: the perturbation magnitude
    # is SYMMETRIC and INDEPENDENT of background brightness.
    qr_arr     = np.array(tiled, dtype=np.float32)       # H×W, values 0 or 255
    qr_bipolar = (qr_arr - 128.0) / 128.0                # H×W, values −1 or +1

    # ── JND adaptive strength: concentrate energy in textures ────────────────
    # strength(x,y) = opacity × jnd_factor(x,y) × 128
    # Max perturbation = _JND_MAX_OPACITY × 128 ≈ ±15 pixels in highly textured areas
    jnd_strength = _jnd_strength(img, base=opacity)       # H×W, pixel-unit strength

    # ── Apply symmetric additive perturbation ─────────────────────────────────
    perturbation = qr_bipolar * jnd_strength               # H×W
    result_arr   = orig_arr + perturbation[:, :, np.newaxis]
    return Image.fromarray(np.clip(result_arr, 0, 255).astype(np.uint8), 'RGB')


def detect_qr(image: Image.Image) -> Optional[dict]:
    """
    Detect and decode the QR watermark from an image.

    Tries multiple preprocessing strategies to maximise detection rate
    even after JPEG compression, screenshots, or colour shifts.

    Returns:
        Metadata dict if a valid clawID QR watermark is found, None otherwise.
    """
    if not (_CV2_OK or _PYZBAR_OK):
        raise ImportError(
            "OpenCV or pyzbar required: "
            "pip install opencv-python-headless   OR   pip install pyzbar"
        )

    arr = np.array(image.convert('RGB'))

    # Build a pipeline of increasingly aggressive preprocessing variants
    # Most watermarked images will decode on the first or second pass
    variants = _preprocessing_pipeline(arr)

    for variant in variants:
        result = _try_decode(variant)
        if result is not None:
            return result

    return None


# ── JND strength map ─────────────────────────────────────────────────────────

def _jnd_strength(img: Image.Image, base: float) -> np.ndarray:
    """
    Compute per-pixel additive perturbation strength (pixel units, 0–128 scale).

    Combines two perceptual factors:

    Factor 1 — Spatial masking:
      High edge/texture density → HVS less sensitive → allow more perturbation.
      Smooth/flat areas → minimum strength.

    Factor 2 — Luminance masking (Weber's law):
      Mid-tone pixels (≈128) can hide ±perturbation better than very dark or
      very bright pixels. Bell-curve weight, peak at mid-tone, floor at 0.25
      (never fully suppress — even dark areas need some signal for detection).

    Returns:
        H×W float32 array; multiply by qr_bipolar [-1,+1] for final perturbation.
    """
    if base == 0.0:
        return np.zeros((img.size[1], img.size[0]), dtype=np.float32)

    gray = img.convert('L')
    luma = np.array(gray, dtype=np.float32)  # [0, 255]

    # Factor 1: spatial masking
    edges = gray.filter(ImageFilter.FIND_EDGES)
    blur_r = max(img.size[0] // 64, 8)
    edges_smooth = edges.filter(ImageFilter.GaussianBlur(radius=blur_r))
    texture_factor = np.array(edges_smooth, dtype=np.float32) / 255.0  # [0, 1]

    # Factor 2: luminance masking — bell curve, peak at 128
    luma_norm = luma / 128.0 - 1.0                           # [−1, +1]
    luma_factor = np.clip(1.0 - luma_norm ** 2, 0.25, 1.0)  # [0.25, 1.0]

    # Combined opacity map (fractional, [base, peak])
    peak = min(base * _JND_PEAK_RATIO, _JND_MAX_OPACITY)
    opacity_map = (base + (peak - base) * texture_factor) * luma_factor

    # Convert to pixel-unit strength: opacity 1.0 → 128px (half the full 255 range)
    return (opacity_map * 128.0).astype(np.float32)


# ── internal helpers ──────────────────────────────────────────────────────────

def _try_decode(arr: np.ndarray) -> Optional[dict]:
    """Attempt QR decode with pyzbar (preferred) then OpenCV."""
    gray = _to_gray_cv(arr) if _CV2_OK else _to_gray_np(arr)

    # ── pyzbar ────────────────────────────────────────────────────────────────
    if _PYZBAR_OK:
        codes = _pyzbar.decode(Image.fromarray(gray))
        for code in codes:
            if code.type == 'QRCODE':
                data = _parse_payload(code.data)
                if data is not None:
                    return data

    # ── OpenCV ────────────────────────────────────────────────────────────────
    if _CV2_OK:
        detector = cv2.QRCodeDetector()
        # Standard detect
        raw, _, _ = detector.detectAndDecode(gray)
        if raw:
            data = _parse_payload(raw.encode())
            if data is not None:
                return data
        # detectAndDecodeMulti catches tiled copies
        ok, raws, _, _ = detector.detectAndDecodeMulti(gray)
        if ok:
            for raw in raws:
                if raw:
                    data = _parse_payload(raw.encode())
                    if data is not None:
                        return data

    return None


_KEY_EXPAND = {'c': 'clawid', 'u': 'uid', 'p': 'platform', 'a': 'asset_id', 't': 'ts'}


def _parse_payload(raw: bytes) -> Optional[dict]:
    """Parse QR payload bytes → metadata dict (expands compact keys)."""
    try:
        text = raw.decode('utf-8') if isinstance(raw, bytes) else raw
        data = json.loads(text)
        # Expand compact keys back to full names
        return {_KEY_EXPAND.get(k, k): v for k, v in data.items()}
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError):
        return None


def _preprocessing_pipeline(arr: np.ndarray):
    """
    Generate preprocessing variants from least to most aggressive.
    Each is a numpy uint8 RGB array.

    Key insight: we tile the QR 2×2, so averaging the 4 quadrants
    reinforces the QR signal (same in all 4) while cancelling the
    background image (different in each quadrant). This dramatically
    improves detection after JPEG compression or on noisy images.
    """
    variants = [arr]  # 1. raw

    # 2. Tile-averaged: average all 4 quadrants → QR signal coherently adds,
    #    background content partially cancels → best for JPEG/noisy images
    h, w = arr.shape[:2]
    th, tw = h // 2, w // 2
    if th >= MIN_QR_DIM and tw >= MIN_QR_DIM:
        q1 = arr[:th,   :tw  ].astype(np.float32)
        q2 = arr[:th,   tw:tw*2].astype(np.float32) if tw*2 <= w else q1
        q3 = arr[th:th*2, :tw  ].astype(np.float32) if th*2 <= h else q1
        q4 = arr[th:th*2, tw:tw*2].astype(np.float32) if th*2 <= h and tw*2 <= w else q1
        averaged = np.clip((q1 + q2 + q3 + q4) / 4, 0, 255).astype(np.uint8)
        variants.append(averaged)

        # 3. Tile-averaged + aggressive CLAHE (boosts local contrast by ~6–8×)
        if _CV2_OK:
            clahe_strong = cv2.createCLAHE(clipLimit=8.0, tileGridSize=(4, 4))
            clahe_mild   = cv2.createCLAHE(clipLimit=4.0, tileGridSize=(4, 4))

            lab = cv2.cvtColor(averaged, cv2.COLOR_RGB2LAB)
            lc, a, b = cv2.split(lab)
            enhanced = cv2.merge([clahe_strong.apply(lc), a, b])
            variants.append(cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB))

            # 4. Tile-averaged + histogram stretching (global contrast amplification)
            gray_avg = _to_gray_cv(averaged)
            lo, hi = np.percentile(gray_avg, [2, 98])
            if hi > lo:
                stretched = np.clip((gray_avg.astype(np.float32) - lo) / (hi - lo) * 255, 0, 255).astype(np.uint8)
            else:
                stretched = gray_avg
            variants.append(cv2.cvtColor(stretched, cv2.COLOR_GRAY2RGB))

            # 5. Tile-averaged + median blur (removes texture noise, preserves QR modules)
            blurred = cv2.medianBlur(averaged, 5)
            variants.append(blurred)

            # 6. Tile-averaged + median blur + strong CLAHE
            lab2 = cv2.cvtColor(blurred, cv2.COLOR_RGB2LAB)
            lc2, a2, b2 = cv2.split(lab2)
            enhanced2 = cv2.merge([clahe_strong.apply(lc2), a2, b2])
            variants.append(cv2.cvtColor(enhanced2, cv2.COLOR_LAB2RGB))

            # 7. Tile-averaged + histogram stretch + median blur
            gray_blur = cv2.medianBlur(gray_avg, 5)
            lo2, hi2 = np.percentile(gray_blur, [2, 98])
            if hi2 > lo2:
                stretched2 = np.clip((gray_blur.astype(np.float32) - lo2) / (hi2 - lo2) * 255, 0, 255).astype(np.uint8)
            else:
                stretched2 = gray_blur
            variants.append(cv2.cvtColor(stretched2, cv2.COLOR_GRAY2RGB))

            # 8. Tile-averaged + Otsu threshold
            _, otsu = cv2.threshold(gray_blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            variants.append(cv2.cvtColor(otsu, cv2.COLOR_GRAY2RGB))

            # 9. Tile-averaged + upscale 4× + unsharp mask (enhances tiny QR modules)
            up = cv2.resize(averaged, (tw * 4, th * 4), interpolation=cv2.INTER_CUBIC)
            blur_up = cv2.GaussianBlur(up, (0, 0), 2.0)
            unsharp = cv2.addWeighted(up, 2.5, blur_up, -1.5, 0)
            variants.append(np.clip(unsharp, 0, 255).astype(np.uint8))

    if not _CV2_OK:
        return variants

    clahe_mild = cv2.createCLAHE(clipLimit=4.0, tileGridSize=(8, 8))
    clahe_strong = cv2.createCLAHE(clipLimit=8.0, tileGridSize=(4, 4))

    # 10. Original + strong CLAHE (fallback if tiling doesn't help)
    lab = cv2.cvtColor(arr, cv2.COLOR_RGB2LAB)
    lc, a, b = cv2.split(lab)
    enhanced = cv2.merge([clahe_strong.apply(lc), a, b])
    variants.append(cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB))

    # 11. Original + unsharp mask
    blur = cv2.GaussianBlur(arr, (0, 0), 2.0)
    unsharp = cv2.addWeighted(arr, 2.5, blur, -1.5, 0)
    variants.append(np.clip(unsharp, 0, 255).astype(np.uint8))

    return variants


def _to_gray_cv(arr: np.ndarray) -> np.ndarray:
    return cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY)


def _to_gray_np(arr: np.ndarray) -> np.ndarray:
    return (0.299 * arr[:, :, 0] + 0.587 * arr[:, :, 1]
            + 0.114 * arr[:, :, 2]).astype(np.uint8)
