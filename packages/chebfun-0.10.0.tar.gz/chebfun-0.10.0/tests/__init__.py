"""Tests for chebpy."""
