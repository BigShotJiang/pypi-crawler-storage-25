"""Tests for foundry.cleaning — shared name/address normalisation and fuzzy matching."""

from __future__ import annotations

from bartram_foundry.cleaning import (
    fuzzy_score,
    names_match,
    normalise_address_line,
    normalise_name,
    normalise_postcode,
)

# ---------------------------------------------------------------------------
# Name normalisation
# ---------------------------------------------------------------------------


class TestNormaliseName:
    def test_surname_forename_flip(self) -> None:
        assert normalise_name("MURPHY, Ken") == "Ken Murphy"

    def test_all_caps(self) -> None:
        assert normalise_name("JOHN SMITH") == "John Smith"

    def test_strips_title(self) -> None:
        assert normalise_name("Mr John Smith") == "John Smith"
        assert normalise_name("DR. JANE DOE") == "Jane Doe"

    def test_strips_honours(self) -> None:
        assert normalise_name("John Smith OBE") == "John Smith"
        assert normalise_name("JANE DOE, MBE") == "Jane Doe"

    def test_strips_title_and_honours(self) -> None:
        assert normalise_name("Sir John Smith KBE") == "John Smith"

    def test_collapses_whitespace(self) -> None:
        assert normalise_name("  John   Smith  ") == "John Smith"

    def test_empty_string(self) -> None:
        assert normalise_name("") == ""
        assert normalise_name("   ") == ""

    def test_preserves_hyphenated_names(self) -> None:
        assert normalise_name("SMITH-JONES, Mary") == "Mary Smith-Jones"


class TestNamesMatch:
    def test_exact_after_normalisation(self) -> None:
        assert names_match("MURPHY, Ken", "Ken Murphy")

    def test_with_title_difference(self) -> None:
        assert names_match("Mr Ken Murphy", "MURPHY, Ken")

    def test_middle_name_difference(self) -> None:
        # Middle name adds enough distance to drop below default threshold (85).
        # At 75 it catches this common CH variation.
        assert names_match("Ken Murphy", "Ken James Murphy", threshold=75)
        assert not names_match("Ken Murphy", "Ken James Murphy", threshold=85)

    def test_clearly_different_names(self) -> None:
        assert not names_match("Ken Murphy", "Jane Smith")

    def test_empty_names(self) -> None:
        assert not names_match("", "Ken Murphy")
        assert not names_match("Ken Murphy", "")

    def test_threshold_control(self) -> None:
        # Very loose threshold should match more.
        assert names_match("Ken Murphy", "K Murphy", threshold=60)
        # Very strict threshold should reject near-matches.
        assert not names_match("Ken Murphy", "K Murphy", threshold=95)


# ---------------------------------------------------------------------------
# Address normalisation
# ---------------------------------------------------------------------------


class TestNormalisePostcode:
    def test_standard_format(self) -> None:
        assert normalise_postcode("AL7 1GA") == "AL7 1GA"

    def test_missing_space(self) -> None:
        assert normalise_postcode("AL71GA") == "AL7 1GA"

    def test_lowercase(self) -> None:
        assert normalise_postcode("al7 1ga") == "AL7 1GA"

    def test_extra_spaces(self) -> None:
        assert normalise_postcode("  AL7  1GA  ") == "AL7 1GA"

    def test_empty(self) -> None:
        assert normalise_postcode("") == ""


class TestNormaliseAddressLine:
    def test_title_case(self) -> None:
        assert normalise_address_line("KESTREL WAY") == "Kestrel Way"

    def test_expands_abbreviations(self) -> None:
        assert normalise_address_line("HIGH ST") == "High Street"
        assert normalise_address_line("CHURCH RD") == "Church Road"

    def test_empty(self) -> None:
        assert normalise_address_line("") == ""


# ---------------------------------------------------------------------------
# Fuzzy score
# ---------------------------------------------------------------------------


class TestFuzzyScore:
    def test_identical_strings(self) -> None:
        assert fuzzy_score("John Smith", "John Smith") == 100

    def test_empty_string(self) -> None:
        assert fuzzy_score("", "John Smith") == 0

    def test_similar_strings(self) -> None:
        score = fuzzy_score("John Smith", "Jon Smith")
        assert 70 <= score <= 100
