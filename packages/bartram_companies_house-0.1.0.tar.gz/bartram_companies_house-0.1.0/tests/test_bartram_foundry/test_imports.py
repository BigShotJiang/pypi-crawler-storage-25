"""Smoke tests — confirm the bartram_foundry package imports cleanly."""

import bartram_foundry


def test_version():
    """The bartram_foundry package has a version string."""
    assert bartram_foundry.__version__ == "0.1.0"


def test_submodule_imports():
    """All bartram_foundry submodules are importable."""
    import bartram_foundry.cache
    import bartram_foundry.cleaning
    import bartram_foundry.http
    import bartram_foundry.mcp
    import bartram_foundry.monitoring
    import bartram_foundry.types

    # Confirm each module loaded (not just imported).
    modules = [
        bartram_foundry.cache,
        bartram_foundry.cleaning,
        bartram_foundry.http,
        bartram_foundry.mcp,
        bartram_foundry.monitoring,
        bartram_foundry.types,
    ]
    assert len(modules) == 6
