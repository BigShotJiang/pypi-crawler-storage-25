"""Tests for foundry.cache — SQLite TTL response cache."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

import pytest

from bartram_foundry.cache import ResponseCache

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
def cache(tmp_path: Path) -> ResponseCache:
    """Create a ResponseCache with a temporary database."""
    return ResponseCache(tmp_path / "test_cache.db")


class TestCachePutGet:
    def test_put_and_get(self, cache: ResponseCache) -> None:
        data = {"items": [{"name": "Tesco"}]}
        cache.put("ch", "/search", data, ttl_seconds=3600)
        result = cache.get("ch", "/search")
        assert result == data

    def test_cache_miss_returns_none(self, cache: ResponseCache) -> None:
        assert cache.get("ch", "/search") is None

    def test_expired_entry_returns_none(self, cache: ResponseCache) -> None:
        data = {"items": []}
        cache.put("ch", "/search", data, ttl_seconds=0)
        # TTL=0 means it's already expired (created_at == expires_at).
        time.sleep(0.01)
        assert cache.get("ch", "/search") is None

    def test_params_differentiate_entries(self, cache: ResponseCache) -> None:
        data_a = {"company": "A"}
        data_b = {"company": "B"}
        cache.put("ch", "/company", data_a, params={"number": "111"})
        cache.put("ch", "/company", data_b, params={"number": "222"})
        assert cache.get("ch", "/company", {"number": "111"}) == data_a
        assert cache.get("ch", "/company", {"number": "222"}) == data_b

    def test_namespace_isolation(self, cache: ResponseCache) -> None:
        cache.put("ch", "/search", {"source": "ch"})
        cache.put("fca", "/search", {"source": "fca"})
        assert cache.get("ch", "/search")["source"] == "ch"
        assert cache.get("fca", "/search")["source"] == "fca"

    def test_overwrite_existing_entry(self, cache: ResponseCache) -> None:
        cache.put("ch", "/search", {"version": 1})
        cache.put("ch", "/search", {"version": 2})
        assert cache.get("ch", "/search")["version"] == 2


class TestCacheAge:
    def test_returns_age_for_cached_entry(self, cache: ResponseCache) -> None:
        cache.put("ch", "/search", {"items": []}, ttl_seconds=3600)
        age = cache.get_age_seconds("ch", "/search")
        assert age is not None
        assert age < 1.0  # Just created.

    def test_returns_none_for_missing_entry(self, cache: ResponseCache) -> None:
        assert cache.get_age_seconds("ch", "/search") is None


class TestCacheClear:
    def test_clear_expired(self, cache: ResponseCache) -> None:
        cache.put("ch", "/old", {"old": True}, ttl_seconds=0)
        cache.put("ch", "/new", {"new": True}, ttl_seconds=3600)
        time.sleep(0.01)
        removed = cache.clear_expired()
        assert removed == 1
        assert cache.get("ch", "/old") is None
        assert cache.get("ch", "/new") is not None

    def test_clear_namespace(self, cache: ResponseCache) -> None:
        cache.put("ch", "/a", {"a": True})
        cache.put("ch", "/b", {"b": True})
        cache.put("fca", "/c", {"c": True})
        removed = cache.clear_namespace("ch")
        assert removed == 2
        assert cache.get("fca", "/c") is not None


class TestCacheStats:
    def test_stats_empty(self, cache: ResponseCache) -> None:
        stats = cache.stats()
        assert stats["total_entries"] == 0
        assert stats["active_entries"] == 0

    def test_stats_with_entries(self, cache: ResponseCache) -> None:
        cache.put("ch", "/a", {"a": True}, ttl_seconds=3600)
        cache.put("ch", "/b", {"b": True}, ttl_seconds=0)
        time.sleep(0.01)
        stats = cache.stats()
        assert stats["total_entries"] == 2
        assert stats["active_entries"] == 1
        assert stats["expired_entries"] == 1


class TestTableCreation:
    def test_idempotent_init(self, tmp_path: Path) -> None:
        db = tmp_path / "idem.db"
        ResponseCache(db)
        ResponseCache(db)  # Should not raise.
