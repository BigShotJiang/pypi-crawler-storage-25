"""Tests for foundry.monitoring — metrics store, health checks, and recording."""

from __future__ import annotations

import sqlite3
import time
from typing import TYPE_CHECKING

import pytest

from bartram_foundry.monitoring import (
    HealthCheckResult,
    MetricsStore,
    record_tool_call,
)

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture
def store(tmp_path: Path) -> MetricsStore:
    """Create a MetricsStore with a temporary database."""
    return MetricsStore(tmp_path / "test_monitoring.db")


# ---------------------------------------------------------------------------
# MetricsStore — recording
# ---------------------------------------------------------------------------


class TestRecordCall:
    def test_records_successful_call(self, store: MetricsStore) -> None:
        store.record_call("uk_company_search", 42.5, success=True)
        summary = store.get_call_summary(last_minutes=5)
        assert len(summary) == 1
        assert summary[0]["tool_name"] == "uk_company_search"
        assert summary[0]["total_calls"] == 1
        assert summary[0]["error_calls"] == 0

    def test_records_failed_call(self, store: MetricsStore) -> None:
        store.record_call(
            "uk_company_profile",
            100.0,
            success=False,
            error_type="NotFoundError",
            error_message="Not found: /company/99999999",
        )
        summary = store.get_call_summary(last_minutes=5)
        assert summary[0]["error_calls"] == 1
        assert summary[0]["error_rate"] == 1.0

    def test_records_multiple_calls(self, store: MetricsStore) -> None:
        store.record_call("uk_company_search", 30.0, success=True)
        store.record_call("uk_company_search", 50.0, success=True)
        store.record_call("uk_company_search", 100.0, success=False, error_type="Timeout")
        summary = store.get_call_summary(last_minutes=5)
        assert summary[0]["total_calls"] == 3
        assert summary[0]["error_calls"] == 1
        assert summary[0]["error_rate"] == pytest.approx(0.333, abs=0.01)
        assert summary[0]["avg_duration_ms"] == pytest.approx(60.0, abs=0.1)

    def test_groups_by_tool_name(self, store: MetricsStore) -> None:
        store.record_call("uk_company_search", 30.0, success=True)
        store.record_call("uk_company_profile", 50.0, success=True)
        summary = store.get_call_summary(last_minutes=5)
        assert len(summary) == 2
        names = {s["tool_name"] for s in summary}
        assert names == {"uk_company_profile", "uk_company_search"}

    def test_filter_by_tool_name(self, store: MetricsStore) -> None:
        store.record_call("uk_company_search", 30.0, success=True)
        store.record_call("uk_company_profile", 50.0, success=True)
        summary = store.get_call_summary("uk_company_search", last_minutes=5)
        assert len(summary) == 1
        assert summary[0]["tool_name"] == "uk_company_search"


class TestRecordHealthCheck:
    def test_records_healthy_check(self, store: MetricsStore) -> None:
        store.record_health_check(
            "companies_house",
            healthy=True,
            response_ms=120.5,
            status_code=200,
        )
        latest = store.get_latest_health()
        assert len(latest) == 1
        assert latest[0]["healthy"] == 1
        assert latest[0]["response_ms"] == 120.5
        assert latest[0]["status_code"] == 200

    def test_records_unhealthy_check(self, store: MetricsStore) -> None:
        store.record_health_check(
            "companies_house",
            healthy=False,
            response_ms=15000.0,
            error_message="Timeout",
        )
        latest = store.get_latest_health()
        assert latest[0]["healthy"] == 0
        assert latest[0]["error_message"] == "Timeout"

    def test_latest_returns_most_recent(self, store: MetricsStore) -> None:
        store.record_health_check("companies_house", healthy=False, error_message="Down")
        store.record_health_check(
            "companies_house", healthy=True, response_ms=50.0, status_code=200
        )
        latest = store.get_latest_health()
        assert len(latest) == 1
        assert latest[0]["healthy"] == 1

    def test_filter_by_tool_name(self, store: MetricsStore) -> None:
        store.record_health_check("companies_house", healthy=True, response_ms=50.0)
        store.record_health_check("other_tool", healthy=True, response_ms=30.0)
        latest = store.get_latest_health("companies_house")
        assert len(latest) == 1
        assert latest[0]["tool_name"] == "companies_house"


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------


class TestRecentErrors:
    def test_returns_only_errors(self, store: MetricsStore) -> None:
        store.record_call("uk_company_search", 30.0, success=True)
        store.record_call(
            "uk_company_search", 100.0, success=False, error_type="Timeout"
        )
        errors = store.get_recent_errors()
        assert len(errors) == 1
        assert errors[0]["error_type"] == "Timeout"

    def test_respects_limit(self, store: MetricsStore) -> None:
        for i in range(10):
            store.record_call(
                "uk_company_search", 100.0, success=False, error_type=f"Error{i}"
            )
        errors = store.get_recent_errors(limit=3)
        assert len(errors) == 3

    def test_filter_by_tool(self, store: MetricsStore) -> None:
        store.record_call("uk_company_search", 100.0, success=False, error_type="E1")
        store.record_call("uk_company_profile", 100.0, success=False, error_type="E2")
        errors = store.get_recent_errors(tool_name="uk_company_profile")
        assert len(errors) == 1
        assert errors[0]["error_type"] == "E2"


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


class TestRecordToolCallContextManager:
    def test_records_success(self, store: MetricsStore) -> None:
        with record_tool_call(store, "test_tool"):
            pass  # simulate work
        summary = store.get_call_summary(last_minutes=5)
        assert summary[0]["total_calls"] == 1
        assert summary[0]["error_calls"] == 0

    def test_records_failure_and_reraises(self, store: MetricsStore) -> None:
        with pytest.raises(ValueError, match="boom"), record_tool_call(store, "test_tool"):
            raise ValueError("boom")
        summary = store.get_call_summary(last_minutes=5)
        assert summary[0]["error_calls"] == 1

    def test_records_duration(self, store: MetricsStore) -> None:
        with record_tool_call(store, "test_tool"):
            time.sleep(0.01)  # 10ms
        summary = store.get_call_summary(last_minutes=5)
        assert summary[0]["avg_duration_ms"] >= 5.0  # at least a few ms


# ---------------------------------------------------------------------------
# Error rate alerts
# ---------------------------------------------------------------------------


class TestErrorRateAlerts:
    def test_no_alert_below_threshold(self, store: MetricsStore) -> None:
        for _ in range(10):
            store.record_call("test_tool", 30.0, success=True)
        alerts = store.check_error_rate_alert(last_minutes=5, threshold=0.1)
        assert alerts == []

    def test_alert_above_threshold(self, store: MetricsStore) -> None:
        for _ in range(4):
            store.record_call("test_tool", 30.0, success=True)
        for _ in range(2):
            store.record_call("test_tool", 30.0, success=False, error_type="Err")
        # 2/6 = 33% error rate, threshold 10%
        alerts = store.check_error_rate_alert(last_minutes=5, threshold=0.1)
        assert len(alerts) == 1
        assert alerts[0]["tool_name"] == "test_tool"
        assert alerts[0]["error_rate"] > 0.1

    def test_no_alert_with_insufficient_calls(self, store: MetricsStore) -> None:
        # Fewer than 5 calls — don't alert (not enough data).
        for _ in range(3):
            store.record_call("test_tool", 30.0, success=False, error_type="Err")
        alerts = store.check_error_rate_alert(last_minutes=5, threshold=0.1)
        assert alerts == []

    def test_filters_by_tool_name(self, store: MetricsStore) -> None:
        for _ in range(5):
            store.record_call("good_tool", 30.0, success=True)
        for _ in range(5):
            store.record_call("bad_tool", 30.0, success=False, error_type="Err")
        alerts = store.check_error_rate_alert("good_tool", last_minutes=5, threshold=0.1)
        assert alerts == []


# ---------------------------------------------------------------------------
# HealthCheckResult
# ---------------------------------------------------------------------------


class TestHealthCheckResult:
    def test_healthy_result(self) -> None:
        r = HealthCheckResult(
            tool_name="companies_house",
            healthy=True,
            response_ms=120.0,
            status_code=200,
        )
        assert r.healthy is True
        assert r.tool_name == "companies_house"

    def test_unhealthy_result(self) -> None:
        r = HealthCheckResult(
            tool_name="companies_house",
            healthy=False,
            error_message="Timeout",
        )
        assert r.healthy is False
        assert r.error_message == "Timeout"


# ---------------------------------------------------------------------------
# Table creation is idempotent
# ---------------------------------------------------------------------------


class TestTableCreation:
    def test_creates_tables_on_init(self, tmp_path: Path) -> None:
        db_path = tmp_path / "new.db"
        MetricsStore(db_path)
        conn = sqlite3.connect(str(db_path))
        tables = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        conn.close()
        assert "tool_calls" in tables
        assert "health_checks" in tables

    def test_idempotent_init(self, tmp_path: Path) -> None:
        db_path = tmp_path / "idem.db"
        MetricsStore(db_path)
        MetricsStore(db_path)  # should not raise
