"""Tests for Companies House API client.

Uses httpx mock transport to return fixture data without hitting the real API.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from bartram_companies_house.access import (
    AuthenticationError,
    CompaniesHouseClient,
    CompaniesHouseConfig,
    NotFoundError,
    RateLimitError,
)

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    """Load a JSON fixture file."""
    return json.loads((FIXTURES / name).read_text())


# ---------------------------------------------------------------------------
# Mock transport — returns fixture data based on the request path
# ---------------------------------------------------------------------------


class MockTransport(httpx.BaseTransport):
    """Returns canned responses for known paths, 404 for unknown."""

    def __init__(self) -> None:
        self.routes: dict[str, tuple[int, dict]] = {}

    def add_route(self, path: str, fixture_name: str, status: int = 200) -> None:
        self.routes[path] = (status, load_fixture(fixture_name))

    def add_error_route(self, path: str, status: int, body: str = "") -> None:
        self.routes[path] = (status, {"error": body})

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        path = request.url.raw_path.decode().split("?")[0]
        if path in self.routes:
            status, data = self.routes[path]
            return httpx.Response(status, json=data)
        return httpx.Response(404, json={"error": "Not found"})


def make_client(transport: MockTransport) -> CompaniesHouseClient:
    """Create a client with a mock transport (caching disabled)."""
    config = CompaniesHouseConfig(api_key="test-key", cache_enabled=False)
    client = CompaniesHouseClient(config)
    # Replace the httpx client with one using our mock transport.
    client._client = httpx.Client(transport=transport, base_url=config.base_url)
    return client


# ---------------------------------------------------------------------------
# Tests — search
# ---------------------------------------------------------------------------


class TestSearchCompanies:
    def test_search_returns_results(self) -> None:
        transport = MockTransport()
        transport.add_route("/search/companies", "search_tesco.json")
        client = make_client(transport)

        result = client.search_companies("Tesco")

        assert result["total_results"] == 356
        assert len(result["items"]) == 2  # fixture has 2 items
        assert result["items"][0]["company_number"] == "00445790"
        assert result["items"][0]["title"] == "TESCO PLC"

    def test_search_returns_company_status(self) -> None:
        transport = MockTransport()
        transport.add_route("/search/companies", "search_tesco.json")
        client = make_client(transport)

        result = client.search_companies("Tesco")

        assert result["items"][0]["company_status"] == "active"
        assert result["items"][1]["company_status"] == "dissolved"


# ---------------------------------------------------------------------------
# Tests — company profile
# ---------------------------------------------------------------------------


class TestGetCompany:
    def test_get_company_profile(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/00445790", "company_00445790.json")
        client = make_client(transport)

        result = client.get_company("00445790")

        assert result["company_name"] == "TESCO PLC"
        assert result["company_number"] == "00445790"
        assert result["company_status"] == "active"
        assert result["type"] == "plc"
        assert result["sic_codes"] == ["47110"]

    def test_get_company_has_address(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/00445790", "company_00445790.json")
        client = make_client(transport)

        result = client.get_company("00445790")
        address = result["registered_office_address"]

        assert address["postal_code"] == "AL7 1GA"
        assert "Welwyn Garden City" in address["locality"]

    def test_get_company_not_found(self) -> None:
        transport = MockTransport()
        client = make_client(transport)

        with pytest.raises(NotFoundError):
            client.get_company("99999999")


# ---------------------------------------------------------------------------
# Tests — officers
# ---------------------------------------------------------------------------


class TestGetOfficers:
    def test_get_officers_returns_list(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/00445790/officers", "officers_00445790.json")
        client = make_client(transport)

        result = client.get_officers("00445790")

        assert result["total_results"] == 2
        assert len(result["items"]) == 2
        assert result["items"][0]["name"] == "MURPHY, Ken"
        assert result["items"][0]["officer_role"] == "director"

    def test_get_officers_has_appointment_date(self) -> None:
        transport = MockTransport()
        transport.add_route("/company/00445790/officers", "officers_00445790.json")
        client = make_client(transport)

        result = client.get_officers("00445790")

        assert result["items"][0]["appointed_on"] == "2020-10-01"


# ---------------------------------------------------------------------------
# Tests — PSCs
# ---------------------------------------------------------------------------


class TestGetPscs:
    def test_get_pscs_returns_list(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/company/00445790/persons-with-significant-control",
            "pscs_00445790.json",
        )
        client = make_client(transport)

        result = client.get_pscs("00445790")

        assert result["total_results"] == 1
        assert result["items"][0]["name"] == "Tesco Holdings Limited"
        assert result["items"][0]["kind"] == "corporate-entity-person-with-significant-control"

    def test_get_pscs_has_natures_of_control(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/company/00445790/persons-with-significant-control",
            "pscs_00445790.json",
        )
        client = make_client(transport)

        result = client.get_pscs("00445790")

        natures = result["items"][0]["natures_of_control"]
        assert "ownership-of-shares-75-to-100-percent" in natures


# ---------------------------------------------------------------------------
# Tests — filing history
# ---------------------------------------------------------------------------


class TestGetFilingHistory:
    def test_get_filings_returns_list(self) -> None:
        transport = MockTransport()
        transport.add_route(
            "/company/00445790/filing-history",
            "filings_00445790.json",
        )
        client = make_client(transport)

        result = client.get_filing_history("00445790")

        assert result["total_results"] == 3
        assert result["items"][0]["category"] == "accounts"
        assert result["items"][1]["category"] == "confirmation-statement"


# ---------------------------------------------------------------------------
# Tests — error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_401_raises_auth_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("/company/00445790", 401, "Invalid API key")
        client = make_client(transport)

        with pytest.raises(AuthenticationError) as exc_info:
            client.get_company("00445790")
        assert exc_info.value.status_code == 401

    def test_403_raises_auth_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("/company/00445790", 403, "Forbidden")
        client = make_client(transport)

        with pytest.raises(AuthenticationError) as exc_info:
            client.get_company("00445790")
        assert exc_info.value.status_code == 403

    def test_429_raises_rate_limit_error(self) -> None:
        transport = MockTransport()
        transport.add_error_route("/search/companies", 429, "Rate limit exceeded")
        client = make_client(transport)

        with pytest.raises(RateLimitError) as exc_info:
            client.search_companies("test")
        assert exc_info.value.status_code == 429

    def test_404_raises_not_found(self) -> None:
        transport = MockTransport()
        client = make_client(transport)

        with pytest.raises(NotFoundError):
            client.get_company("99999999")


# ---------------------------------------------------------------------------
# Tests — config
# ---------------------------------------------------------------------------


class TestConfig:
    def test_from_env_raises_without_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("COMPANIES_HOUSE_API_KEY", raising=False)
        with pytest.raises(ValueError, match="COMPANIES_HOUSE_API_KEY"):
            CompaniesHouseConfig.from_env()

    def test_from_env_reads_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("COMPANIES_HOUSE_API_KEY", "test-key-123")
        config = CompaniesHouseConfig.from_env()
        assert config.api_key == "test-key-123"
