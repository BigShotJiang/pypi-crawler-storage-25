"""Tests for Companies House MCP tool definitions.

Tests the full access -> clean -> serve pipeline using mock HTTP transport.
"""

from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest

from bartram_companies_house import serve
from bartram_companies_house.access import CompaniesHouseClient, CompaniesHouseConfig

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text())


# ---------------------------------------------------------------------------
# Mock transport (same pattern as test_access.py)
# ---------------------------------------------------------------------------


class MockTransport(httpx.BaseTransport):
    def __init__(self) -> None:
        self.routes: dict[str, tuple[int, dict]] = {}

    def add_route(self, path: str, fixture_name: str, status: int = 200) -> None:
        self.routes[path] = (status, load_fixture(fixture_name))

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        path = request.url.raw_path.decode().split("?")[0]
        if path in self.routes:
            status, data = self.routes[path]
            return httpx.Response(status, json=data)
        return httpx.Response(404, json={"error": "Not found"})


@pytest.fixture(autouse=True)
def _mock_client(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Replace the serve module's client and metrics with test instances."""
    transport = MockTransport()
    transport.add_route("/search/companies", "search_tesco.json")
    transport.add_route("/company/00445790", "company_00445790.json")
    transport.add_route("/company/00445790/officers", "officers_00445790.json")
    transport.add_route(
        "/company/00445790/persons-with-significant-control",
        "pscs_00445790.json",
    )
    transport.add_route("/company/00445790/filing-history", "filings_00445790.json")

    config = CompaniesHouseConfig(api_key="test-key", cache_enabled=False)
    client = CompaniesHouseClient(config)
    client._client = httpx.Client(transport=transport, base_url=config.base_url)

    # Inject mock client and test metrics store into serve module.
    monkeypatch.setattr(serve, "_client", client)

    from bartram_foundry.monitoring import MetricsStore

    monkeypatch.setattr(serve, "_metrics", MetricsStore(tmp_path / "test_metrics.db"))


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestServerSetup:
    def test_server_exists(self) -> None:
        assert serve.server.name == "bartram-companies-house"


class TestSearch:
    @pytest.mark.asyncio
    async def test_search_returns_json_with_results(self) -> None:
        result = await serve.uk_company_search("Tesco", 10)
        parsed = json.loads(result)
        assert "data" in parsed
        assert "metadata" in parsed
        assert parsed["data"]["total_results"] == 356
        assert parsed["data"]["items"][0]["title"] == "TESCO PLC"

    @pytest.mark.asyncio
    async def test_search_includes_attribution(self) -> None:
        result = await serve.uk_company_search("Tesco", 10)
        parsed = json.loads(result)
        assert "OGL v3.0" in parsed["metadata"]["licence"]
        assert "Companies House" in parsed["metadata"]["source"]

    @pytest.mark.asyncio
    async def test_search_addresses_are_cleaned(self) -> None:
        result = await serve.uk_company_search("Tesco", 10)
        parsed = json.loads(result)
        address = parsed["data"]["items"][0].get("address", {})
        # If address has a postal_code, it should be normalised.
        if "postal_code" in address:
            # No lowercase letters in a normalised postcode.
            assert address["postal_code"] == address["postal_code"].upper()


class TestProfile:
    @pytest.mark.asyncio
    async def test_profile_returns_company_data(self) -> None:
        result = await serve.uk_company_profile("00445790")
        parsed = json.loads(result)
        assert parsed["data"]["company_name"] == "TESCO PLC"
        assert parsed["data"]["company_status"] == "active"

    @pytest.mark.asyncio
    async def test_profile_address_is_cleaned(self) -> None:
        result = await serve.uk_company_profile("00445790")
        parsed = json.loads(result)
        address = parsed["data"]["registered_office_address"]
        assert "formatted" in address
        assert "AL7 1GA" in address["formatted"]

    @pytest.mark.asyncio
    async def test_profile_not_found_returns_error(self) -> None:
        result = await serve.uk_company_profile("99999999")
        parsed = json.loads(result)
        assert "error" in parsed
        assert parsed["status_code"] == 404


class TestOfficers:
    @pytest.mark.asyncio
    async def test_officers_returns_list(self) -> None:
        result = await serve.uk_company_officers("00445790")
        parsed = json.loads(result)
        assert len(parsed["data"]["items"]) > 0
        assert parsed["data"]["items"][0]["name"] == "MURPHY, Ken"

    @pytest.mark.asyncio
    async def test_officers_includes_cleaning_metadata(self) -> None:
        result = await serve.uk_company_officers("00445790")
        parsed = json.loads(result)
        assert "_cleaning" in parsed["data"]
        assert "original_count" in parsed["data"]["_cleaning"]


class TestPsc:
    @pytest.mark.asyncio
    async def test_psc_returns_annotated_records(self) -> None:
        result = await serve.uk_company_psc("00445790")
        parsed = json.loads(result)
        items = parsed["data"]["items"]
        assert len(items) > 0
        assert "_cleaning" in items[0]

    @pytest.mark.asyncio
    async def test_psc_corporate_entity_typed(self) -> None:
        result = await serve.uk_company_psc("00445790")
        parsed = json.loads(result)
        # Our fixture has a corporate entity PSC.
        assert parsed["data"]["items"][0]["_cleaning"]["entity_type"] == "corporate"


class TestFilings:
    @pytest.mark.asyncio
    async def test_filings_returns_history(self) -> None:
        result = await serve.uk_company_filings("00445790", 20)
        parsed = json.loads(result)
        assert parsed["data"]["total_results"] == 3
        assert parsed["data"]["items"][0]["category"] == "accounts"

    @pytest.mark.asyncio
    async def test_filings_includes_metadata(self) -> None:
        result = await serve.uk_company_filings("00445790", 20)
        parsed = json.loads(result)
        assert parsed["metadata"]["endpoint"] == "/company/00445790/filing-history"


class TestFilingDescriptions:
    @pytest.mark.asyncio
    async def test_filings_have_rendered_descriptions(self) -> None:
        result = await serve.uk_company_filings("00445790", 20)
        parsed = json.loads(result)
        for item in parsed["data"]["items"]:
            assert "description_rendered" in item
            assert len(item["description_rendered"]) > 0

    @pytest.mark.asyncio
    async def test_filing_description_is_readable(self) -> None:
        result = await serve.uk_company_filings("00445790", 20)
        parsed = json.loads(result)
        desc = parsed["data"]["items"][0]["description_rendered"]
        # Should be human-readable (spaces, not hyphens).
        assert " " in desc


class TestCompanyNumberNormalisation:
    @pytest.mark.asyncio
    async def test_unpadded_number_gets_padded(self) -> None:
        # 445790 should become 00445790, which our mock has a route for.
        result = await serve.uk_company_profile("445790")
        parsed = json.loads(result)
        assert parsed["data"]["company_name"] == "TESCO PLC"

    @pytest.mark.asyncio
    async def test_prefixed_number_unchanged(self) -> None:
        # SC prefix should not be padded.
        normalised = serve._normalise_company_number("sc311560")
        assert normalised == "SC311560"

    @pytest.mark.asyncio
    async def test_already_padded_unchanged(self) -> None:
        normalised = serve._normalise_company_number("00445790")
        assert normalised == "00445790"


class TestEmptySearch:
    @pytest.mark.asyncio
    async def test_empty_query_returns_error(self) -> None:
        result = await serve.uk_company_search("", 10)
        parsed = json.loads(result)
        assert "error" in parsed
        assert "required" in parsed["error"].lower()

    @pytest.mark.asyncio
    async def test_whitespace_query_returns_error(self) -> None:
        result = await serve.uk_company_search("   ", 10)
        parsed = json.loads(result)
        assert "error" in parsed


class TestCacheMetadata:
    @pytest.mark.asyncio
    async def test_response_includes_cached_field(self) -> None:
        result = await serve.uk_company_profile("00445790")
        parsed = json.loads(result)
        assert "cached" in parsed["metadata"]


class TestErrorHandling:
    @pytest.mark.asyncio
    async def test_not_found_returns_structured_error(self) -> None:
        result = await serve.uk_company_officers("99999999")
        parsed = json.loads(result)
        assert "error" in parsed
        assert parsed["status_code"] == 404
        assert "attribution" in parsed
