"""Tests for Companies House data cleaning logic."""

from __future__ import annotations

from bartram_companies_house.clean import (
    clean_address,
    clean_company_profile,
    clean_officer_list,
    clean_psc_list,
    clean_pscs,
    clean_search_results,
    deduplicate_officers,
)

# ---------------------------------------------------------------------------
# Officer deduplication
# ---------------------------------------------------------------------------


class TestDeduplicateOfficers:
    def test_no_duplicates(self) -> None:
        officers = [
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
            {"name": "SMITH, Jane", "officer_role": "director", "appointed_on": "2021-05-01"},
        ]
        result = deduplicate_officers(officers)
        assert len(result) == 2

    def test_exact_duplicate_merged(self) -> None:
        officers = [
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2018-06-15"},
        ]
        result = deduplicate_officers(officers)
        assert len(result) == 1
        assert result[0]["_cleaning"]["deduplicated"] is True
        assert result[0]["_cleaning"]["duplicate_count"] == 2

    def test_name_variation_merged(self) -> None:
        """Different formatting of the same name should be merged."""
        officers = [
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
            {"name": "Mr Ken Murphy", "officer_role": "director", "appointed_on": "2018-06-15"},
        ]
        result = deduplicate_officers(officers)
        assert len(result) == 1
        assert result[0]["appointed_on"] == "2020-10-01"  # most recent kept

    def test_different_roles_not_merged(self) -> None:
        """Same person in different roles should not be merged."""
        officers = [
            {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
            {"name": "MURPHY, Ken", "officer_role": "secretary", "appointed_on": "2018-06-15"},
        ]
        result = deduplicate_officers(officers)
        assert len(result) == 2

    def test_empty_list(self) -> None:
        assert deduplicate_officers([]) == []

    def test_keeps_most_recent_appointment(self) -> None:
        officers = [
            {"name": "SMITH, John", "officer_role": "director", "appointed_on": "2015-01-01"},
            {"name": "Smith, John", "officer_role": "director", "appointed_on": "2022-03-15"},
            {"name": "SMITH, J", "officer_role": "director", "appointed_on": "2010-06-01"},
        ]
        result = deduplicate_officers(officers, threshold=70)
        assert len(result) == 1
        assert result[0]["appointed_on"] == "2022-03-15"


# ---------------------------------------------------------------------------
# PSC filtering
# ---------------------------------------------------------------------------


class TestCleanPscs:
    def test_corporate_entity_annotated(self) -> None:
        pscs = [
            {
                "name": "Tesco Holdings Limited",
                "kind": "corporate-entity-person-with-significant-control",
                "natures_of_control": ["ownership-of-shares-75-to-100-percent"],
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["entity_type"] == "corporate"

    def test_individual_annotated(self) -> None:
        pscs = [
            {
                "name": "John Smith",
                "kind": "individual-person-with-significant-control",
                "natures_of_control": ["ownership-of-shares-25-to-50-percent"],
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["entity_type"] == "individual"

    def test_misclassified_corporate_as_individual(self) -> None:
        """Corporate entity filed as individual should be flagged."""
        pscs = [
            {
                "name": "ACME HOLDINGS LIMITED",
                "kind": "individual-person-with-significant-control",
                "natures_of_control": ["ownership-of-shares-75-to-100-percent"],
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["misclassified"] is True
        assert result[0]["_cleaning"]["expected_kind"] == "corporate-entity"

    def test_misclassified_with_identification_field(self) -> None:
        """Individual with identification data is likely a corporate entity."""
        pscs = [
            {
                "name": "Some Entity",
                "kind": "individual-person-with-significant-control",
                "identification": {
                    "legal_authority": "Companies Act 2006",
                    "legal_form": "Limited Company",
                },
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["misclassified"] is True

    def test_ceased_psc_flagged(self) -> None:
        pscs = [
            {
                "name": "John Smith",
                "kind": "individual-person-with-significant-control",
                "ceased_on": "2023-06-01",
            }
        ]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["ceased"] is True

    def test_unknown_kind_flagged(self) -> None:
        pscs = [{"name": "Mystery", "kind": "some-new-kind"}]
        result = clean_pscs(pscs)
        assert result[0]["_cleaning"]["entity_type"] == "unknown"


# ---------------------------------------------------------------------------
# Address cleaning
# ---------------------------------------------------------------------------


class TestCleanAddress:
    def test_normalises_postcode(self) -> None:
        address = {"postal_code": "al71ga", "address_line_1": "Kestrel Way"}
        result = clean_address(address)
        assert result["postal_code"] == "AL7 1GA"

    def test_title_cases_fields(self) -> None:
        address = {"locality": "WELWYN GARDEN CITY", "country": "UNITED KINGDOM"}
        result = clean_address(address)
        assert result["locality"] == "Welwyn Garden City"

    def test_builds_formatted_line(self) -> None:
        address = {
            "premises": "Tesco House",
            "address_line_1": "Kestrel Way",
            "locality": "Welwyn Garden City",
            "postal_code": "AL7 1GA",
        }
        result = clean_address(address)
        assert result["formatted"] == "Tesco House, Kestrel Way, Welwyn Garden City, AL7 1GA"

    def test_empty_address(self) -> None:
        assert clean_address({}) == {}
        assert clean_address(None) == {}


# ---------------------------------------------------------------------------
# Top-level cleaning functions
# ---------------------------------------------------------------------------


class TestCleanCompanyProfile:
    def test_cleans_address(self) -> None:
        profile = {
            "company_name": "TESCO PLC",
            "registered_office_address": {
                "address_line_1": "KESTREL WAY",
                "postal_code": "al71ga",
            },
        }
        result = clean_company_profile(profile)
        assert result["registered_office_address"]["postal_code"] == "AL7 1GA"
        assert result["company_name"] == "TESCO PLC"  # unchanged


class TestCleanOfficerList:
    def test_adds_cleaning_metadata(self) -> None:
        response = {
            "items": [
                {"name": "MURPHY, Ken", "officer_role": "director", "appointed_on": "2020-10-01"},
                {"name": "Mr Ken Murphy", "officer_role": "director", "appointed_on": "2018-06-15"},
            ],
            "total_results": 2,
        }
        result = clean_officer_list(response)
        assert result["_cleaning"]["original_count"] == 2
        assert result["_cleaning"]["deduplicated_count"] == 1
        assert result["_cleaning"]["duplicates_removed"] == 1


class TestCleanPscList:
    def test_annotates_items(self) -> None:
        response = {
            "items": [
                {
                    "name": "Tesco Holdings Limited",
                    "kind": "corporate-entity-person-with-significant-control",
                }
            ]
        }
        result = clean_psc_list(response)
        assert "_cleaning" in result["items"][0]


class TestCleanFilingHistory:
    def test_renders_simple_description(self) -> None:
        from bartram_companies_house.clean import clean_filing_history

        response = {
            "items": [
                {
                    "description": "capital-return-purchase-own-shares",
                    "category": "capital",
                    "date": "2026-03-09",
                }
            ]
        }
        result = clean_filing_history(response)
        item = result["items"][0]
        assert "description_rendered" in item
        assert item["description_rendered"] == "Capital return purchase own shares"

    def test_renders_description_with_values(self) -> None:
        from bartram_companies_house.clean import clean_filing_history

        response = {
            "items": [
                {
                    "description": "termination-director-company-with-name-termination-date",
                    "description_values": {
                        "officer_name": "James Watt",
                        "termination_date": "2026-03-24",
                    },
                    "category": "officers",
                }
            ]
        }
        result = clean_filing_history(response)
        rendered = result["items"][0]["description_rendered"]
        assert "James Watt" in rendered
        assert "2026-03-24" in rendered

    def test_renders_capital_values(self) -> None:
        from bartram_companies_house.clean import clean_filing_history

        response = {
            "items": [
                {
                    "description": "capital-cancellation-shares",
                    "description_values": {
                        "date": "2026-01-21",
                        "capital": [{"currency": "GBP", "figure": "404,394,910.41"}],
                    },
                }
            ]
        }
        result = clean_filing_history(response)
        rendered = result["items"][0]["description_rendered"]
        assert "GBP" in rendered
        assert "404,394,910.41" in rendered

    def test_empty_description(self) -> None:
        from bartram_companies_house.clean import clean_filing_history

        response = {"items": [{"description": "", "category": "other"}]}
        result = clean_filing_history(response)
        assert result["items"][0]["description_rendered"] == ""


class TestCleanSearchResults:
    def test_normalises_addresses(self) -> None:
        response = {
            "items": [
                {
                    "title": "TESCO PLC",
                    "address": {"postal_code": "al71ga", "locality": "WELWYN GARDEN CITY"},
                }
            ]
        }
        result = clean_search_results(response)
        assert result["items"][0]["address"]["postal_code"] == "AL7 1GA"
