"""MCP tool definitions for Companies House -- what agents call.

Tools exposed:
- uk_company_search: Search for companies by name
- uk_company_profile: Get company details by number
- uk_company_officers: Get officer records with deduplication
- uk_company_psc: Get beneficial ownership data with filtering
- uk_company_filings: Get filing history summary
"""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from typing import Any

from mcp.server.fastmcp import FastMCP

from bartram_companies_house.access import (
    CompaniesHouseClient,
    CompaniesHouseConfig,
    CompaniesHouseError,
)
from bartram_companies_house.clean import (
    clean_company_profile,
    clean_filing_history,
    clean_officer_list,
    clean_psc_list,
    clean_search_results,
)
from bartram_foundry.monitoring import MetricsStore

# ---------------------------------------------------------------------------
# Server setup
# ---------------------------------------------------------------------------

server = FastMCP(
    "bartram-companies-house",
    instructions="UK Companies House data with cleaning and deduplication. "
    "Source: Companies House API (companies-house.gov.uk). Licence: OGL v3.0.",
)

# Module-level client and metrics -- created lazily on first use.
_client: CompaniesHouseClient | None = None
_metrics: MetricsStore | None = None


def _get_client() -> CompaniesHouseClient:
    """Get or create the API client (lazy initialisation)."""
    global _client
    if _client is None:
        _client = CompaniesHouseClient(CompaniesHouseConfig.from_env())
    return _client


def _get_metrics() -> MetricsStore:
    """Get or create the metrics store (lazy initialisation)."""
    global _metrics
    if _metrics is None:
        _metrics = MetricsStore()
    return _metrics


# ---------------------------------------------------------------------------
# Response formatting
# ---------------------------------------------------------------------------

_ATTRIBUTION = (
    "Data source: Companies House (companies-house.gov.uk). "
    "Licence: Open Government Licence v3.0. "
    "Crown copyright."
)


def _format_response(data: Any, *, endpoint: str, cached: bool = False) -> str:
    """Format a cleaned API response as a JSON string with metadata."""
    envelope = {
        "data": data,
        "metadata": {
            "source": "Companies House",
            "licence": "OGL v3.0",
            "retrieved_at": datetime.now(tz=timezone.utc).isoformat(),
            "endpoint": endpoint,
            "cached": cached,
            "attribution": _ATTRIBUTION,
        },
    }
    return json.dumps(envelope, indent=2, default=str)


def _format_error(error: CompaniesHouseError) -> str:
    """Format an API error as a JSON string."""
    return json.dumps({
        "error": str(error),
        "status_code": error.status_code,
        "attribution": _ATTRIBUTION,
    })


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


def _normalise_company_number(number: str) -> str:
    """Normalise a company number to the format Companies House expects.

    Numeric-only numbers are zero-padded to 8 digits (e.g. '445790' -> '00445790').
    Prefixed numbers (SC, NI, OC, etc.) are uppercased and left as-is.
    """
    stripped = number.strip().upper()
    if stripped.isdigit():
        return stripped.zfill(8)
    return stripped


def _record(tool_name: str, start: float, *, success: bool, error: Exception | None = None) -> None:
    """Record a tool call metric."""
    duration_ms = (time.monotonic() - start) * 1000
    _get_metrics().record_call(
        tool_name,
        duration_ms,
        success=success,
        error_type=type(error).__name__ if error else None,
        error_message=str(error)[:500] if error else None,
    )


@server.tool()
async def uk_company_search(query: str, max_results: int = 10) -> str:
    """Search for UK companies by name or number.

    Returns company name, number, status, type, and incorporation date
    for each match. Addresses are normalised.
    Data source: Companies House (OGL v3.0).
    """
    if not query or not query.strip():
        return json.dumps({
            "error": "Search query is required. Provide a company name or number.",
            "attribution": _ATTRIBUTION,
        })
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.search_companies(query, items_per_page=max_results)
        cleaned = clean_search_results(raw)
        result = _format_response(cleaned, endpoint="/search/companies")
        _record("uk_company_search", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_company_search", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_company_profile(company_number: str) -> str:
    """Get the profile of a UK company by its company number (e.g. '00445790').

    Returns registered address, status, SIC codes, accounts info, and key dates.
    Data source: Companies House (OGL v3.0).
    """
    company_number = _normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_company(company_number)
        cleaned = clean_company_profile(raw)
        result = _format_response(cleaned, endpoint=f"/company/{company_number}")
        _record("uk_company_profile", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_company_profile", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_company_officers(company_number: str) -> str:
    """Get officers (directors, secretaries) of a UK company.

    Includes name deduplication -- flags likely duplicate records caused by
    name formatting variations in Companies House data. The response includes
    _cleaning metadata showing how many duplicates were merged.
    Data source: Companies House (OGL v3.0).
    """
    company_number = _normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_officers(company_number)
        cleaned = clean_officer_list(raw)
        result = _format_response(cleaned, endpoint=f"/company/{company_number}/officers")
        _record("uk_company_officers", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_company_officers", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_company_psc(company_number: str) -> str:
    """Get persons with significant control (beneficial owners) of a UK company.

    Flags corporate entities incorrectly filed as natural persons and annotates
    each record with entity type and any data quality issues.
    Data source: Companies House (OGL v3.0).
    """
    company_number = _normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_pscs(company_number)
        cleaned = clean_psc_list(raw)
        result = _format_response(
            cleaned, endpoint=f"/company/{company_number}/persons-with-significant-control"
        )
        _record("uk_company_psc", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_company_psc", start, success=False, error=exc)
        return _format_error(exc)


@server.tool()
async def uk_company_filings(company_number: str, max_results: int = 20) -> str:
    """Get recent filing history for a UK company.

    Returns filing type, date, category, and description.
    Data source: Companies House (OGL v3.0).
    """
    company_number = _normalise_company_number(company_number)
    start = time.monotonic()
    try:
        client = _get_client()
        raw = client.get_filing_history(company_number, items_per_page=max_results)
        cleaned = clean_filing_history(raw)
        result = _format_response(cleaned, endpoint=f"/company/{company_number}/filing-history")
        _record("uk_company_filings", start, success=True)
        return result
    except CompaniesHouseError as exc:
        _record("uk_company_filings", start, success=False, error=exc)
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run the Companies House MCP server."""
    server.run()


if __name__ == "__main__":
    main()
