"""Companies House data cleaning logic.

CH-specific cleaning:
- Officer name deduplication (handle ~614K known duplicates from name variations)
- Fictitious PSC record filtering (corporate entities filed as natural persons)
- Address normalisation for CH-specific formats
- Data quality annotations
"""

from __future__ import annotations

from typing import Any

from bartram_foundry.cleaning import (
    names_match,
    normalise_address_line,
    normalise_name,
    normalise_postcode,
)

# ---------------------------------------------------------------------------
# Officer deduplication
# ---------------------------------------------------------------------------


def _officer_key(officer: dict[str, Any]) -> str:
    """Build a grouping key for an officer from role + normalised name.

    Officers with the same name and role are candidates for deduplication.
    """
    name = normalise_name(officer.get("name", ""))
    role = officer.get("officer_role", "unknown")
    return f"{role}::{name}"


def _merge_officer_group(officers: list[dict[str, Any]]) -> dict[str, Any]:
    """Given a group of likely-duplicate officer records, produce one merged record.

    Strategy: keep the most recently appointed record as the primary,
    annotate with dedup metadata.
    """
    if len(officers) == 1:
        return officers[0]

    # Sort by appointment date descending (most recent first).
    # Records without a date go to the end.
    def sort_key(o: dict[str, Any]) -> str:
        return o.get("appointed_on", "0000-00-00")

    sorted_officers = sorted(officers, key=sort_key, reverse=True)
    primary = dict(sorted_officers[0])  # shallow copy

    # Add deduplication annotation.
    primary["_cleaning"] = {
        "deduplicated": True,
        "duplicate_count": len(officers),
        "original_names": [o.get("name", "") for o in officers],
        "note": (
            f"Merged {len(officers)} records with similar names. "
            "Showing most recently appointed."
        ),
    }

    return primary


def deduplicate_officers(
    officers: list[dict[str, Any]],
    *,
    threshold: int = 85,
) -> list[dict[str, Any]]:
    """Deduplicate officer records by fuzzy name matching.

    Companies House has ~614K duplicate officer records caused by name
    formatting variations (different capitalisation, title inclusion,
    middle name presence). This groups likely duplicates and merges them.

    Args:
        officers: Raw officer records from the API.
        threshold: Fuzzy match threshold (0-100). Default 85.

    Returns:
        Deduplicated list of officer records, with _cleaning annotations
        on any merged records.
    """
    if not officers:
        return []

    # Group by exact normalised key first (fast path).
    groups: dict[str, list[dict[str, Any]]] = {}
    for officer in officers:
        key = _officer_key(officer)
        groups.setdefault(key, []).append(officer)

    # Second pass: merge groups whose keys are fuzzy-similar.
    merged_keys: list[list[str]] = []
    key_list = list(groups.keys())

    # Track which keys have already been merged.
    consumed: set[str] = set()

    for i, key_a in enumerate(key_list):
        if key_a in consumed:
            continue
        cluster = [key_a]
        for key_b in key_list[i + 1 :]:
            if key_b in consumed:
                continue
            # Only compare names within the same role.
            role_a, name_a = key_a.split("::", 1)
            role_b, name_b = key_b.split("::", 1)
            if role_a == role_b and names_match(name_a, name_b, threshold=threshold):
                cluster.append(key_b)
                consumed.add(key_b)
        consumed.add(key_a)
        merged_keys.append(cluster)

    # Build the deduplicated result.
    result = []
    for cluster in merged_keys:
        all_officers = []
        for key in cluster:
            all_officers.extend(groups[key])
        result.append(_merge_officer_group(all_officers))

    return result


# ---------------------------------------------------------------------------
# PSC filtering
# ---------------------------------------------------------------------------

# PSC 'kind' values that indicate a corporate entity, not a natural person.
_CORPORATE_PSC_KINDS = frozenset({
    "corporate-entity-person-with-significant-control",
    "corporate-entity-beneficial-owner",
    "legal-person-person-with-significant-control",
    "legal-person-beneficial-owner",
    "super-secure-person-with-significant-control",
    "super-secure-beneficial-owner",
})

# PSC 'kind' values that indicate a natural person.
_INDIVIDUAL_PSC_KINDS = frozenset({
    "individual-person-with-significant-control",
    "individual-beneficial-owner",
})


def _looks_like_corporate_entity(psc: dict[str, Any]) -> bool:
    """Detect a corporate entity incorrectly filed as a natural person.

    Heuristics:
    1. Has an 'identification' field (which natural persons shouldn't have).
    2. Name contains corporate indicators (Ltd, Limited, LLP, PLC, etc.).
    """
    # Corporate entities have identification data.
    if psc.get("identification"):
        return True

    name = psc.get("name", "").upper()
    corporate_indicators = [
        " LTD", " LIMITED", " PLC", " LLP", " LP",
        " INC", " CORP", " CORPORATION",
        " TRUST", " FUND", " FOUNDATION",
        " GMBH", " AG", " SA", " BV", " NV",
    ]
    return any(indicator in name for indicator in corporate_indicators)


def clean_pscs(pscs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Clean PSC records: flag misclassified entities and annotate.

    Companies House PSC data has known issues:
    - Corporate entities sometimes filed as natural persons
    - Missing or inconsistent 'kind' fields

    Each record gets a _cleaning annotation describing what was found.

    Args:
        pscs: Raw PSC records from the API.

    Returns:
        Annotated PSC records with _cleaning metadata.
    """
    result = []
    for psc in pscs:
        cleaned = dict(psc)  # shallow copy
        kind = psc.get("kind", "")
        annotations: dict[str, Any] = {}

        if kind in _INDIVIDUAL_PSC_KINDS and _looks_like_corporate_entity(psc):
            annotations["misclassified"] = True
            annotations["expected_kind"] = "corporate-entity"
            annotations["note"] = (
                "Record filed as individual but appears to be a corporate entity. "
                "Check 'identification' field and name for corporate indicators."
            )
        elif kind in _CORPORATE_PSC_KINDS:
            annotations["entity_type"] = "corporate"
        elif kind in _INDIVIDUAL_PSC_KINDS:
            annotations["entity_type"] = "individual"
        else:
            annotations["entity_type"] = "unknown"
            annotations["note"] = f"Unrecognised PSC kind: {kind}"

        # Flag ceased PSCs.
        if psc.get("ceased_on"):
            annotations["ceased"] = True

        cleaned["_cleaning"] = annotations
        result.append(cleaned)

    return result


# ---------------------------------------------------------------------------
# Address cleaning (CH-specific)
# ---------------------------------------------------------------------------


def clean_address(address: dict[str, Any]) -> dict[str, Any]:
    """Normalise a Companies House address record.

    Applies postcode formatting, line normalisation, and adds a
    formatted single-line version.

    Args:
        address: Raw address dict from the API.

    Returns:
        Cleaned address dict with normalised fields and a 'formatted' key.
    """
    if not address:
        return {}

    cleaned = {}

    # Normalise individual fields.
    for key in ("premises", "address_line_1", "address_line_2", "locality", "region", "country"):
        if address.get(key):
            cleaned[key] = normalise_address_line(address[key])

    if address.get("postal_code"):
        cleaned["postal_code"] = normalise_postcode(address["postal_code"])

    # Build a single formatted line.
    parts = []
    for key in ("premises", "address_line_1", "address_line_2", "locality", "region", "country"):
        if cleaned.get(key):
            parts.append(cleaned[key])
    if "postal_code" in cleaned:
        parts.append(cleaned["postal_code"])
    cleaned["formatted"] = ", ".join(parts)

    return cleaned


# ---------------------------------------------------------------------------
# Filing description rendering
# ---------------------------------------------------------------------------


def render_filing_description(filing: dict[str, Any]) -> str:
    """Render a filing description from its code and values into readable text.

    Companies House returns descriptions as hyphenated codes like
    'termination-director-company-with-name-termination-date' with separate
    description_values containing the variable data. This converts the code
    to a readable sentence and interpolates the values.
    """
    desc = filing.get("description", "")
    values = filing.get("description_values", {})

    if not desc:
        return ""

    # Convert hyphenated code to sentence: replace hyphens with spaces, capitalise.
    readable = desc.replace("-", " ").capitalize()

    # Interpolate known values into the description.
    if values:
        parts = [readable]
        for key, value in values.items():
            if key == "capital" and isinstance(value, list):
                # Capital entries: [{currency, figure}, ...]
                cap_parts = [f"{c.get('currency', '')} {c.get('figure', '')}" for c in value]
                parts.append(f"Capital: {', '.join(cap_parts)}")
            elif isinstance(value, str):
                label = key.replace("_", " ").capitalize()
                parts.append(f"{label}: {value}")
        readable = ". ".join(parts)

    return readable


def clean_filing_history(response: dict[str, Any]) -> dict[str, Any]:
    """Clean a filing history response: render descriptions into readable text."""
    cleaned = dict(response)
    for item in cleaned.get("items", []):
        item["description_rendered"] = render_filing_description(item)
    return cleaned


# ---------------------------------------------------------------------------
# Top-level cleaning functions (called from serve.py)
# ---------------------------------------------------------------------------


def clean_company_profile(profile: dict[str, Any]) -> dict[str, Any]:
    """Clean a company profile response."""
    cleaned = dict(profile)
    if "registered_office_address" in cleaned:
        cleaned["registered_office_address"] = clean_address(
            cleaned["registered_office_address"]
        )
    return cleaned


def clean_officer_list(response: dict[str, Any], *, threshold: int = 85) -> dict[str, Any]:
    """Clean an officer list response: deduplicate and normalise."""
    cleaned = dict(response)
    raw_items = cleaned.get("items", [])
    cleaned["items"] = deduplicate_officers(raw_items, threshold=threshold)
    cleaned["_cleaning"] = {
        "original_count": len(raw_items),
        "deduplicated_count": len(cleaned["items"]),
        "duplicates_removed": len(raw_items) - len(cleaned["items"]),
    }
    return cleaned


def clean_psc_list(response: dict[str, Any]) -> dict[str, Any]:
    """Clean a PSC list response: flag misclassified entities."""
    cleaned = dict(response)
    cleaned["items"] = clean_pscs(cleaned.get("items", []))
    return cleaned


def clean_search_results(response: dict[str, Any]) -> dict[str, Any]:
    """Clean search results: normalise addresses."""
    cleaned = dict(response)
    for item in cleaned.get("items", []):
        if "address" in item:
            item["address"] = clean_address(item["address"])
    return cleaned
