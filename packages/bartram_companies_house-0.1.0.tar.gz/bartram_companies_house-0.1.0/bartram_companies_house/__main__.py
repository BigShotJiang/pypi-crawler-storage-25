"""Entry point for running the Companies House MCP server.

Usage:
    python -m bartram_companies_house
    uvx bartram-companies-house
"""

from bartram_companies_house.serve import main

if __name__ == "__main__":
    main()
