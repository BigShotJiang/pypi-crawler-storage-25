"""Companies House API client.

Endpoints: company search, company profile, officer list, PSC list, filing history.
Auth: API key via Basic Auth (key as username, no password).
Rate limit: 600 requests per 5 minutes.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx
import yaml

from bartram_foundry.cache import ResponseCache

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_BASE_URL = "https://api.company-information.service.gov.uk"
DEFAULT_RATE_LIMIT = 600
DEFAULT_RATE_WINDOW = 300  # seconds


# Cache TTLs per endpoint (seconds). Loaded from config.yaml if available.
_DEFAULT_CACHE_TTLS: dict[str, int] = {
    "company_search": 3600,
    "company_profile": 86400,
    "officer_list": 21600,
    "psc_list": 21600,
    "filing_history": 3600,
}


def _load_cache_ttls() -> dict[str, int]:
    """Load cache TTLs from config.yaml if it exists."""
    config_path = Path(__file__).parent / "config.yaml"
    if config_path.exists():
        with open(config_path) as f:
            config = yaml.safe_load(f)
        return config.get("cache", {}).get("ttl_seconds", _DEFAULT_CACHE_TTLS)
    return dict(_DEFAULT_CACHE_TTLS)


@dataclass
class CompaniesHouseConfig:
    """Configuration for the Companies House API client."""

    api_key: str = ""
    base_url: str = DEFAULT_BASE_URL
    rate_limit: int = DEFAULT_RATE_LIMIT
    rate_window: int = DEFAULT_RATE_WINDOW
    timeout: float = 30.0
    cache_enabled: bool = True

    @classmethod
    def from_env(cls) -> CompaniesHouseConfig:
        """Create config from environment variables.

        The API key is a server-side configuration — users of the MCP tool
        do not need to provide their own key. The key is set as an environment
        variable in the deployment configuration.
        """
        api_key = os.environ.get("COMPANIES_HOUSE_API_KEY", "")
        if not api_key:
            msg = (
                "COMPANIES_HOUSE_API_KEY environment variable is not set. "
                "This is a server-side configuration — set it in the deployment environment."
            )
            raise ValueError(msg)
        return cls(api_key=api_key)


# ---------------------------------------------------------------------------
# Rate limiter (simple sliding window)
# ---------------------------------------------------------------------------


@dataclass
class RateLimiter:
    """Simple sliding-window rate limiter.

    Tracks request timestamps and sleeps if the limit would be exceeded.
    """

    max_requests: int = DEFAULT_RATE_LIMIT
    window_seconds: int = DEFAULT_RATE_WINDOW
    _timestamps: list[float] = field(default_factory=list)

    def wait_if_needed(self) -> None:
        """Block until a request slot is available."""
        now = time.monotonic()
        # Drop timestamps outside the window.
        cutoff = now - self.window_seconds
        self._timestamps = [t for t in self._timestamps if t > cutoff]

        if len(self._timestamps) >= self.max_requests:
            # Sleep until the oldest timestamp falls out of the window.
            sleep_time = self._timestamps[0] - cutoff
            if sleep_time > 0:
                time.sleep(sleep_time)

        self._timestamps.append(time.monotonic())


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class CompaniesHouseError(Exception):
    """Base exception for Companies House API errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class NotFoundError(CompaniesHouseError):
    """Resource not found (404)."""


class RateLimitError(CompaniesHouseError):
    """Rate limit exceeded (429)."""


class AuthenticationError(CompaniesHouseError):
    """Authentication failed (401/403)."""


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class CompaniesHouseClient:
    """Client for the Companies House REST API.

    Usage::

        client = CompaniesHouseClient.from_env()
        results = client.search_companies("Tesco")
        profile = client.get_company("00445790")
        officers = client.get_officers("00445790")
        pscs = client.get_pscs("00445790")
        filings = client.get_filing_history("00445790")
    """

    def __init__(self, config: CompaniesHouseConfig) -> None:
        self.config = config
        self._rate_limiter = RateLimiter(
            max_requests=config.rate_limit,
            window_seconds=config.rate_window,
        )
        self._client = httpx.Client(
            base_url=config.base_url,
            auth=(config.api_key, ""),
            timeout=config.timeout,
            headers={"Accept": "application/json"},
        )
        self._cache: ResponseCache | None = None
        self._cache_ttls: dict[str, int] = {}
        if config.cache_enabled:
            self._cache = ResponseCache()
            self._cache_ttls = _load_cache_ttls()

    @classmethod
    def from_env(cls) -> CompaniesHouseClient:
        """Create a client from environment variables."""
        return cls(CompaniesHouseConfig.from_env())

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> CompaniesHouseClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    # -- internal request helper -------------------------------------------

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Make a GET request with rate limiting and error handling.

        Returns the parsed JSON response body.
        Raises CompaniesHouseError subclasses on failure.
        """
        self._rate_limiter.wait_if_needed()

        try:
            response = self._client.get(path, params=params)
        except httpx.TimeoutException as exc:
            msg = f"Request to {path} timed out"
            raise CompaniesHouseError(msg) from exc
        except httpx.HTTPError as exc:
            msg = f"HTTP error requesting {path}: {exc}"
            raise CompaniesHouseError(msg) from exc

        if response.status_code == 200:
            return response.json()

        # Map status codes to specific exceptions.
        status = response.status_code
        body = response.text

        if status == 404:
            raise NotFoundError(f"Not found: {path}", status_code=status)
        if status == 429:
            raise RateLimitError(
                f"Rate limit exceeded (retry after {response.headers.get('Retry-After', '?')}s)",
                status_code=status,
            )
        if status in (401, 403):
            raise AuthenticationError(
                f"Authentication failed ({status}): {body}",
                status_code=status,
            )

        # Generic error for anything else.
        raise CompaniesHouseError(
            f"API error {status}: {body}",
            status_code=status,
        )

    def _cached_get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
        *,
        cache_key: str = "",
    ) -> tuple[dict[str, Any], bool]:
        """GET with cache. Returns (response, from_cache)."""
        ttl = self._cache_ttls.get(cache_key, 0)
        if self._cache and ttl > 0:
            cached = self._cache.get("companies_house", path, params)
            if cached is not None:
                return cached, True

        result = self._get(path, params)

        if self._cache and ttl > 0:
            self._cache.put(
                "companies_house", path, result, ttl_seconds=ttl, params=params
            )

        return result, False

    # -- public API methods ------------------------------------------------

    def search_companies(
        self,
        query: str,
        *,
        items_per_page: int = 20,
        start_index: int = 0,
    ) -> dict[str, Any]:
        """Search for companies by name or number.

        Args:
            query: Search term (company name or number).
            items_per_page: Number of results per page (max 100).
            start_index: Offset for pagination.

        Returns:
            Raw API response dict with 'items', 'total_results', etc.
        """
        params = {
            "q": query,
            "items_per_page": items_per_page,
            "start_index": start_index,
        }
        result, _ = self._cached_get(
            "/search/companies", params, cache_key="company_search"
        )
        return result

    def get_company(self, company_number: str) -> dict[str, Any]:
        """Get the profile of a company by its number.

        Args:
            company_number: The Companies House company number (e.g. '00445790').

        Returns:
            Raw API response dict with company profile data.
        """
        result, _ = self._cached_get(
            f"/company/{company_number}", cache_key="company_profile"
        )
        return result

    def get_officers(
        self,
        company_number: str,
        *,
        items_per_page: int = 50,
        start_index: int = 0,
    ) -> dict[str, Any]:
        """Get the officers (directors, secretaries) of a company.

        Automatically paginates to fetch all officer records when the total
        exceeds the page size. The complete result is cached.

        Args:
            company_number: The Companies House company number.
            items_per_page: Number of results per page.
            start_index: Offset for pagination.

        Returns:
            Raw API response dict with 'items', 'total_results', etc.
            Items contains all officers (across all pages).
        """
        # Check cache for the complete (paginated) result.
        cache_params = {"company_number": company_number}
        if self._cache:
            ttl = self._cache_ttls.get("officer_list", 0)
            if ttl > 0:
                cached = self._cache.get(
                    "companies_house", f"/officers/{company_number}", cache_params
                )
                if cached is not None:
                    return cached

        first_page = self._get(
            f"/company/{company_number}/officers",
            params={
                "items_per_page": items_per_page,
                "start_index": start_index,
            },
        )

        total = first_page.get("total_results", 0)
        all_items = list(first_page.get("items", []))

        # Fetch remaining pages if needed.
        fetched = start_index + len(all_items)
        while fetched < total:
            page = self._get(
                f"/company/{company_number}/officers",
                params={
                    "items_per_page": items_per_page,
                    "start_index": fetched,
                },
            )
            page_items = page.get("items", [])
            if not page_items:
                break  # Safety: stop if API returns empty page.
            all_items.extend(page_items)
            fetched += len(page_items)

        first_page["items"] = all_items

        # Cache the complete paginated result.
        if self._cache:
            ttl = self._cache_ttls.get("officer_list", 0)
            if ttl > 0:
                self._cache.put(
                    "companies_house", f"/officers/{company_number}",
                    first_page, ttl_seconds=ttl, params=cache_params,
                )

        return first_page

    def get_pscs(
        self,
        company_number: str,
        *,
        items_per_page: int = 25,
        start_index: int = 0,
    ) -> dict[str, Any]:
        """Get persons with significant control (beneficial owners) of a company.

        Args:
            company_number: The Companies House company number.
            items_per_page: Number of results per page.
            start_index: Offset for pagination.

        Returns:
            Raw API response dict with 'items', 'total_results', etc.
        """
        params = {
            "items_per_page": items_per_page,
            "start_index": start_index,
        }
        result, _ = self._cached_get(
            f"/company/{company_number}/persons-with-significant-control",
            params,
            cache_key="psc_list",
        )
        return result

    def get_filing_history(
        self,
        company_number: str,
        *,
        items_per_page: int = 25,
        start_index: int = 0,
        category: str | None = None,
    ) -> dict[str, Any]:
        """Get filing history for a company.

        Args:
            company_number: The Companies House company number.
            items_per_page: Number of results per page.
            start_index: Offset for pagination.
            category: Optional filing category filter (e.g. 'accounts', 'annual-return').

        Returns:
            Raw API response dict with 'items', 'total_results', etc.
        """
        params: dict[str, Any] = {
            "items_per_page": items_per_page,
            "start_index": start_index,
        }
        if category:
            params["category"] = category
        result, _ = self._cached_get(
            f"/company/{company_number}/filing-history",
            params,
            cache_key="filing_history",
        )
        return result
