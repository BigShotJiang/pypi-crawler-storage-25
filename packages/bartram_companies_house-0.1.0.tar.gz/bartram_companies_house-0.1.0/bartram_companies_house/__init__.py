"""Companies House MCP tool — UK company data with data cleaning."""
