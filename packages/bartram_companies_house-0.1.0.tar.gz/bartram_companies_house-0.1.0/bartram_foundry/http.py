"""HTTP client: rate limiting, retries, auth injection.

Thin wrapper around httpx for government API access. Handles:
- Rate limiting (respects per-API limits with backoff)
- Automatic retries with exponential backoff for transient failures
- API key injection from environment variables
- Response validation
- Request/response logging
"""
