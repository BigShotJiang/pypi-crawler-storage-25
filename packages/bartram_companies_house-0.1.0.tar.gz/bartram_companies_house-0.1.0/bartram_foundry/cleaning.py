"""Common data cleaning utilities.

Shared patterns that apply across multiple government data sources:
- Name normalisation
- Address normalisation
- Record deduplication heuristics (fuzzy matching)

Tool-specific cleaning logic lives in each tool's own clean.py.
"""

from __future__ import annotations

import re

from rapidfuzz import fuzz

# ---------------------------------------------------------------------------
# Name normalisation
# ---------------------------------------------------------------------------

# Common title prefixes found in UK government data.
_TITLES = frozenset({
    "mr", "mrs", "ms", "miss", "dr", "prof", "professor",
    "sir", "dame", "lord", "lady", "baron", "baroness",
    "rev", "reverend", "hon", "honourable",
})

# Suffixes that sometimes appear after names.
_SUFFIXES = frozenset({
    "obe", "mbe", "cbe", "dbe", "kbe", "gbe",
    "qc", "kc", "mp", "phd", "md", "jp",
    "jr", "sr", "ii", "iii", "iv",
})


def normalise_name(name: str) -> str:
    """Normalise a person's name for consistent comparison.

    Handles:
    - UPPERCASE to Title Case conversion
    - Title/honour stripping (Mr, Mrs, Dr, OBE, etc.)
    - Extra whitespace collapse
    - Comma-separated "SURNAME, Forename" → "Forename Surname"

    Returns:
        Normalised name string in Title Case.
    """
    if not name or not name.strip():
        return ""

    text = name.strip()

    # If the name is in "SURNAME, Forename" format, flip it.
    if "," in text:
        parts = [p.strip() for p in text.split(",", 1)]
        if len(parts) == 2 and parts[0] and parts[1]:
            text = f"{parts[1]} {parts[0]}"

    # Normalise to title case.
    text = text.title()

    # Split into tokens and filter out titles and suffixes.
    tokens = text.split()
    cleaned = []
    for token in tokens:
        # Strip trailing dots for comparison (e.g. "Dr." → "Dr").
        bare = token.rstrip(".").lower()
        if bare in _TITLES or bare in _SUFFIXES:
            continue
        cleaned.append(token)

    result = " ".join(cleaned).strip()

    # Clean up any double spaces.
    result = re.sub(r"\s+", " ", result)

    return result


def names_match(name_a: str, name_b: str, *, threshold: int = 85) -> bool:
    """Check whether two names likely refer to the same person.

    Uses fuzzy matching on normalised forms. The threshold (0-100) controls
    how strict the match is. Default 85 catches common variations (middle
    name included/excluded, minor spelling differences) while avoiding
    false positives.

    Returns:
        True if the normalised names are similar enough.
    """
    norm_a = normalise_name(name_a)
    norm_b = normalise_name(name_b)

    if not norm_a or not norm_b:
        return False

    # Exact match after normalisation — fast path.
    if norm_a == norm_b:
        return True

    # Token-sort ratio handles word-order differences well
    # (e.g. "John Smith" vs "Smith John").
    score = fuzz.token_sort_ratio(norm_a, norm_b)
    return score >= threshold


# ---------------------------------------------------------------------------
# Address normalisation
# ---------------------------------------------------------------------------

# Common UK address abbreviations → full forms.
_ADDRESS_REPLACEMENTS = {
    r"\bSt\b\.?": "Street",
    r"\bRd\b\.?": "Road",
    r"\bAve\b\.?": "Avenue",
    r"\bDr\b\.?": "Drive",
    r"\bLn\b\.?": "Lane",
    r"\bCt\b\.?": "Court",
    r"\bPl\b\.?": "Place",
    r"\bCres\b\.?": "Crescent",
    r"\bTce\b\.?": "Terrace",
    r"\bGdns\b\.?": "Gardens",
}


def normalise_postcode(postcode: str) -> str:
    """Normalise a UK postcode to standard format: 'AB1 2CD'.

    Handles missing spaces, extra spaces, and lowercase input.
    """
    if not postcode or not postcode.strip():
        return ""

    clean = re.sub(r"\s+", "", postcode.strip().upper())

    # UK postcodes: outward (2-4 chars) + inward (always 3 chars).
    if len(clean) < 5:
        return clean  # Too short to be valid — return as-is.

    # Insert space before the last 3 characters.
    return f"{clean[:-3]} {clean[-3:]}"


def normalise_address_line(line: str) -> str:
    """Normalise an address line: expand abbreviations, title case, collapse whitespace."""
    if not line or not line.strip():
        return ""

    text = line.strip().title()

    # Expand common abbreviations.
    for pattern, replacement in _ADDRESS_REPLACEMENTS.items():
        text = re.sub(pattern, replacement, text)

    return re.sub(r"\s+", " ", text).strip()


# ---------------------------------------------------------------------------
# Deduplication helpers
# ---------------------------------------------------------------------------


def fuzzy_score(a: str, b: str) -> int:
    """Return a 0-100 similarity score between two strings.

    Uses token-sort ratio which is order-independent.
    """
    if not a or not b:
        return 0
    return fuzz.token_sort_ratio(a, b)
