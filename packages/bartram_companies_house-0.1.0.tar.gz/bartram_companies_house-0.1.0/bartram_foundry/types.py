"""Shared type definitions and response schemas.

Pydantic models for common structures across tools:
- UK addresses
- Company identifiers
- Officer names
- Date ranges
- Standard MCP response envelope

Tool-specific types live in each tool's directory.
"""
