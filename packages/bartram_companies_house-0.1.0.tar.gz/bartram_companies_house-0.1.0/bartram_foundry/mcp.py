"""MCP base layer: tool registration, schema helpers, response formatting.

Built on the official MCP Python SDK. Provides:
- Tool registration helpers and decorators
- Consistent response formatting (data, metadata, attribution, errors)
- Attribution metadata (source, licence, timestamp, cache status)
- Error handling for upstream API failures
"""
