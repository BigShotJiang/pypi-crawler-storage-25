"""SQLite TTL cache for API responses.

Key = hash of (tool name + endpoint + parameters).
Value = JSON response.
TTL = configurable per tool and per endpoint.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import time
from pathlib import Path
from typing import Any

_DATA_DIR = Path(os.environ.get("BARTRAM_DATA_DIR", "."))
DEFAULT_DB_PATH = _DATA_DIR / "cache.db"
DEFAULT_TTL_SECONDS = 3600  # 1 hour


class ResponseCache:
    """SQLite-backed TTL cache for API responses.

    Each entry is keyed by a hash of (namespace + endpoint + params) and
    stores the JSON response with an expiry timestamp.
    """

    def __init__(self, db_path: str | Path = DEFAULT_DB_PATH) -> None:
        self._db_path = Path(db_path)
        self._ensure_table()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_table(self) -> None:
        with self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS cache_entries (
                    cache_key TEXT PRIMARY KEY,
                    namespace TEXT NOT NULL,
                    endpoint TEXT NOT NULL,
                    response_json TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    expires_at REAL NOT NULL
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_cache_expires
                ON cache_entries (expires_at)
            """)

    @staticmethod
    def _make_key(namespace: str, endpoint: str, params: dict[str, Any] | None = None) -> str:
        """Build a cache key from namespace, endpoint, and parameters."""
        key_data = f"{namespace}:{endpoint}"
        if params:
            # Sort params for consistent hashing.
            sorted_params = json.dumps(params, sort_keys=True)
            key_data += f":{sorted_params}"
        return hashlib.sha256(key_data.encode()).hexdigest()

    def get(
        self,
        namespace: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Retrieve a cached response if it exists and hasn't expired.

        Returns None on cache miss or expired entry.
        """
        key = self._make_key(namespace, endpoint, params)
        now = time.time()

        with self._connect() as conn:
            row = conn.execute(
                "SELECT response_json, expires_at FROM cache_entries WHERE cache_key = ?",
                (key,),
            ).fetchone()

        if row is None:
            return None

        if row["expires_at"] < now:
            # Expired — clean it up.
            self._delete_key(key)
            return None

        return json.loads(row["response_json"])

    def get_age_seconds(
        self,
        namespace: str,
        endpoint: str,
        params: dict[str, Any] | None = None,
    ) -> float | None:
        """Return the age in seconds of a cached entry, or None if not cached."""
        key = self._make_key(namespace, endpoint, params)
        now = time.time()

        with self._connect() as conn:
            row = conn.execute(
                "SELECT created_at, expires_at FROM cache_entries WHERE cache_key = ?",
                (key,),
            ).fetchone()

        if row is None or row["expires_at"] < now:
            return None

        return now - row["created_at"]

    def put(
        self,
        namespace: str,
        endpoint: str,
        response: dict[str, Any],
        *,
        ttl_seconds: int = DEFAULT_TTL_SECONDS,
        params: dict[str, Any] | None = None,
    ) -> None:
        """Store a response in the cache."""
        key = self._make_key(namespace, endpoint, params)
        now = time.time()

        with self._connect() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO cache_entries
                   (cache_key, namespace, endpoint, response_json, created_at, expires_at)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (key, namespace, endpoint, json.dumps(response), now, now + ttl_seconds),
            )

    def _delete_key(self, key: str) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM cache_entries WHERE cache_key = ?", (key,))

    def clear_expired(self) -> int:
        """Remove all expired entries. Returns the number of entries removed."""
        now = time.time()
        with self._connect() as conn:
            cursor = conn.execute(
                "DELETE FROM cache_entries WHERE expires_at < ?", (now,)
            )
            return cursor.rowcount

    def clear_namespace(self, namespace: str) -> int:
        """Remove all entries for a given namespace."""
        with self._connect() as conn:
            cursor = conn.execute(
                "DELETE FROM cache_entries WHERE namespace = ?", (namespace,)
            )
            return cursor.rowcount

    def stats(self) -> dict[str, Any]:
        """Return cache statistics."""
        now = time.time()
        with self._connect() as conn:
            total = conn.execute("SELECT COUNT(*) FROM cache_entries").fetchone()[0]
            active = conn.execute(
                "SELECT COUNT(*) FROM cache_entries WHERE expires_at >= ?", (now,)
            ).fetchone()[0]
            expired = total - active
        return {"total_entries": total, "active_entries": active, "expired_entries": expired}
