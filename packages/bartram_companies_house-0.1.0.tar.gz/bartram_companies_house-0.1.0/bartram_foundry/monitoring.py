"""Health checks, error rate tracking, call volume logging.

Per-tool metrics: call count, error count, average response time, cache hit rate.
Stored in SQLite. Queryable for the steady (monthly) review.
"""

from __future__ import annotations

import os
import sqlite3
import time
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Default paths
# ---------------------------------------------------------------------------

_DATA_DIR = Path(os.environ.get("BARTRAM_DATA_DIR", "."))
DEFAULT_DB_PATH = _DATA_DIR / "monitoring.db"


# ---------------------------------------------------------------------------
# Metrics store
# ---------------------------------------------------------------------------


class MetricsStore:
    """SQLite-backed storage for tool call metrics and health check results."""

    def __init__(self, db_path: str | Path = DEFAULT_DB_PATH) -> None:
        self._db_path = Path(db_path)
        self._ensure_tables()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_tables(self) -> None:
        with self._connect() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tool_calls (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tool_name TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    duration_ms REAL NOT NULL,
                    success INTEGER NOT NULL,
                    error_type TEXT,
                    error_message TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS health_checks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tool_name TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    healthy INTEGER NOT NULL,
                    response_ms REAL,
                    status_code INTEGER,
                    error_message TEXT
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_tool_calls_name_ts
                ON tool_calls (tool_name, timestamp)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_health_checks_name_ts
                ON health_checks (tool_name, timestamp)
            """)

    # -- Recording ----------------------------------------------------------

    def record_call(
        self,
        tool_name: str,
        duration_ms: float,
        *,
        success: bool = True,
        error_type: str | None = None,
        error_message: str | None = None,
    ) -> None:
        """Record a single tool call."""
        now = datetime.now(tz=timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO tool_calls
                   (tool_name, timestamp, duration_ms, success, error_type, error_message)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (tool_name, now, duration_ms, int(success), error_type, error_message),
            )

    def record_health_check(
        self,
        tool_name: str,
        *,
        healthy: bool,
        response_ms: float | None = None,
        status_code: int | None = None,
        error_message: str | None = None,
    ) -> None:
        """Record a health check result."""
        now = datetime.now(tz=timezone.utc).isoformat()
        with self._connect() as conn:
            conn.execute(
                """INSERT INTO health_checks
                   (tool_name, timestamp, healthy, response_ms, status_code, error_message)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (tool_name, now, int(healthy), response_ms, status_code, error_message),
            )

    # -- Queries ------------------------------------------------------------

    def get_call_summary(
        self, tool_name: str | None = None, *, last_minutes: int = 60
    ) -> list[dict[str, Any]]:
        """Get call metrics summary, optionally filtered by tool name.

        Returns one row per tool: tool_name, total_calls, error_calls,
        error_rate, avg_duration_ms, max_duration_ms.
        """
        from datetime import timedelta

        cutoff_dt = datetime.now(tz=timezone.utc) - timedelta(minutes=last_minutes)
        cutoff_str = cutoff_dt.isoformat()

        query = """
            SELECT
                tool_name,
                COUNT(*) as total_calls,
                SUM(CASE WHEN success = 0 THEN 1 ELSE 0 END) as error_calls,
                ROUND(AVG(duration_ms), 1) as avg_duration_ms,
                ROUND(MAX(duration_ms), 1) as max_duration_ms
            FROM tool_calls
            WHERE timestamp >= ?
        """
        params: list[Any] = [cutoff_str]

        if tool_name:
            query += " AND tool_name = ?"
            params.append(tool_name)

        query += " GROUP BY tool_name ORDER BY tool_name"

        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()

        results = []
        for row in rows:
            total = row["total_calls"]
            errors = row["error_calls"]
            results.append({
                "tool_name": row["tool_name"],
                "total_calls": total,
                "error_calls": errors,
                "error_rate": round(errors / total, 3) if total > 0 else 0.0,
                "avg_duration_ms": row["avg_duration_ms"],
                "max_duration_ms": row["max_duration_ms"],
            })
        return results

    def get_latest_health(self, tool_name: str | None = None) -> list[dict[str, Any]]:
        """Get the most recent health check result per tool."""
        query = """
            SELECT h.*
            FROM health_checks h
            INNER JOIN (
                SELECT tool_name, MAX(timestamp) as max_ts
                FROM health_checks
                GROUP BY tool_name
            ) latest ON h.tool_name = latest.tool_name AND h.timestamp = latest.max_ts
        """
        params: list[Any] = []
        if tool_name:
            query += " WHERE h.tool_name = ?"
            params.append(tool_name)

        query += " ORDER BY h.tool_name"

        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()

        return [dict(row) for row in rows]

    def check_error_rate_alert(
        self,
        tool_name: str | None = None,
        *,
        last_minutes: int = 60,
        threshold: float = 0.1,
    ) -> list[dict[str, Any]]:
        """Check if any tool's error rate exceeds the threshold.

        Returns a list of alerts for tools that are above the threshold.
        Each alert includes tool_name, error_rate, total_calls, and error_calls.
        """
        summaries = self.get_call_summary(tool_name, last_minutes=last_minutes)
        alerts = []
        for s in summaries:
            if s["total_calls"] >= 5 and s["error_rate"] > threshold:
                alerts.append({
                    "tool_name": s["tool_name"],
                    "error_rate": s["error_rate"],
                    "total_calls": s["total_calls"],
                    "error_calls": s["error_calls"],
                    "alert": (
                        f"Error rate {s['error_rate']:.1%} exceeds threshold {threshold:.1%} "
                        f"({s['error_calls']}/{s['total_calls']} calls failed "
                        f"in the last {last_minutes} minutes)"
                    ),
                })
        return alerts

    def get_recent_errors(
        self, *, limit: int = 20, tool_name: str | None = None
    ) -> list[dict[str, Any]]:
        """Get recent error calls."""
        query = "SELECT * FROM tool_calls WHERE success = 0"
        params: list[Any] = []
        if tool_name:
            query += " AND tool_name = ?"
            params.append(tool_name)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]


# ---------------------------------------------------------------------------
# Call recording context manager
# ---------------------------------------------------------------------------


@contextmanager
def record_tool_call(store: MetricsStore, tool_name: str):
    """Context manager that records timing and success/failure of a tool call.

    Usage::

        with record_tool_call(metrics, "uk_company_search"):
            result = do_the_work()
    """
    start = time.monotonic()
    try:
        yield
        duration_ms = (time.monotonic() - start) * 1000
        store.record_call(tool_name, duration_ms, success=True)
    except Exception as exc:
        duration_ms = (time.monotonic() - start) * 1000
        store.record_call(
            tool_name,
            duration_ms,
            success=False,
            error_type=type(exc).__name__,
            error_message=str(exc)[:500],
        )
        raise


# ---------------------------------------------------------------------------
# Health checker
# ---------------------------------------------------------------------------


@dataclass
class HealthCheckResult:
    """Result of a single health check."""

    tool_name: str
    healthy: bool
    response_ms: float | None = None
    status_code: int | None = None
    error_message: str | None = None


def check_companies_house_health(api_key: str, *, timeout: float = 15.0) -> HealthCheckResult:
    """Run a health check against the Companies House API.

    Performs a lightweight search query and checks for a 200 response.
    """
    import httpx

    url = "https://api.company-information.service.gov.uk/search/companies"
    start = time.monotonic()

    try:
        response = httpx.get(
            url,
            params={"q": "test", "items_per_page": 1},
            auth=(api_key, ""),
            timeout=timeout,
        )
        elapsed_ms = (time.monotonic() - start) * 1000
        healthy = response.status_code == 200
        return HealthCheckResult(
            tool_name="companies_house",
            healthy=healthy,
            response_ms=round(elapsed_ms, 1),
            status_code=response.status_code,
            error_message=None if healthy else f"HTTP {response.status_code}",
        )
    except httpx.TimeoutException:
        elapsed_ms = (time.monotonic() - start) * 1000
        return HealthCheckResult(
            tool_name="companies_house",
            healthy=False,
            response_ms=round(elapsed_ms, 1),
            error_message="Timeout",
        )
    except httpx.HTTPError as exc:
        elapsed_ms = (time.monotonic() - start) * 1000
        return HealthCheckResult(
            tool_name="companies_house",
            healthy=False,
            response_ms=round(elapsed_ms, 1),
            error_message=str(exc)[:500],
        )
