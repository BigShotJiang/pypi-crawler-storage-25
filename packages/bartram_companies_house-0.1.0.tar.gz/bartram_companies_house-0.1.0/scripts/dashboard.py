#!/usr/bin/env python3
"""Monitoring dashboard -- print tool health and call metrics.

Usage: python scripts/dashboard.py
       python scripts/dashboard.py --db monitoring.db --hours 24
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bartram_foundry.monitoring import MetricsStore


def main() -> None:
    parser = argparse.ArgumentParser(description="Bartram Foundry monitoring dashboard.")
    parser.add_argument(
        "--db",
        default="monitoring.db",
        help="Path to the monitoring SQLite database (default: monitoring.db)",
    )
    parser.add_argument(
        "--hours",
        type=int,
        default=24,
        help="Look-back window in hours (default: 24)",
    )
    args = parser.parse_args()

    db_path = Path(args.db)
    if not db_path.exists():
        print(f"No monitoring database found at {db_path}.")
        print("Run health_check.py or use the MCP tools to generate data first.")
        sys.exit(0)

    store = MetricsStore(db_path)
    last_minutes = args.hours * 60

    # -- Health status -----------------------------------------------------
    print("=" * 60)
    print("  BARTRAM FOUNDRY — Monitoring Dashboard")
    print("=" * 60)
    print()

    latest = store.get_latest_health()
    if latest:
        print("HEALTH STATUS")
        print("-" * 40)
        for h in latest:
            status = "HEALTHY" if h["healthy"] else "UNHEALTHY"
            ts = h["timestamp"][:19]
            line = f"  {h['tool_name']:<20} {status:<10}"
            if h["response_ms"] is not None:
                line += f"  {h['response_ms']:.0f}ms"
            if h["status_code"] is not None:
                line += f"  HTTP {h['status_code']}"
            line += f"  (checked {ts})"
            print(line)
        print()
    else:
        print("No health check data. Run: python scripts/health_check.py\n")

    # -- Call metrics ------------------------------------------------------
    summaries = store.get_call_summary(last_minutes=last_minutes)
    if summaries:
        print(f"CALL METRICS (last {args.hours}h)")
        print("-" * 60)
        print(f"  {'Tool':<25} {'Calls':>6} {'Errors':>7} {'Rate':>6} {'Avg ms':>7} {'Max ms':>7}")
        print(f"  {'─' * 25} {'─' * 6} {'─' * 7} {'─' * 6} {'─' * 7} {'─' * 7}")
        for s in summaries:
            rate_str = f"{s['error_rate']:.1%}"
            print(
                f"  {s['tool_name']:<25} {s['total_calls']:>6} "
                f"{s['error_calls']:>7} {rate_str:>6} "
                f"{s['avg_duration_ms']:>7.1f} {s['max_duration_ms']:>7.1f}"
            )
        print()
    else:
        print(f"No call data in the last {args.hours}h.\n")

    # -- Recent errors -----------------------------------------------------
    errors = store.get_recent_errors(limit=5)
    if errors:
        print("RECENT ERRORS (last 5)")
        print("-" * 60)
        for e in errors:
            ts = e["timestamp"][:19]
            print(f"  {ts}  {e['tool_name']:<25} {e['error_type']}: {e['error_message']}")
        print()

    print("=" * 60)


if __name__ == "__main__":
    main()
