# Schema Reference

Complete tool reference for the UK Companies House MCP server. Each tool follows the `access → clean → serve` pattern: raw API data is fetched, cleaned, and returned in a consistent envelope.

## Response envelope

Every successful response wraps data in this structure:

```json
{
  "data": { ... },
  "metadata": {
    "source": "Companies House",
    "licence": "OGL v3.0",
    "retrieved_at": "2026-04-03T14:30:00+00:00",
    "endpoint": "/search/companies",
    "cached": false,
    "attribution": "Data source: Companies House (companies-house.gov.uk). Licence: Open Government Licence v3.0. Crown copyright."
  }
}
```

Error responses:

```json
{
  "error": "Company not found: 99999999",
  "status_code": 404,
  "attribution": "Data source: Companies House ..."
}
```

---

## uk_company_search

Search for UK companies by name or number.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | yes | — | Company name or number to search for |
| `max_results` | int | no | 10 | Maximum number of results (1–100) |

### Returns

`data` contains the Companies House search response with cleaned addresses. Each item includes: `title` (company name), `company_number`, `company_status`, `company_type`, `date_of_creation`, and `address` (normalised with a `formatted` single-line version).

### Cleaning applied

- Addresses normalised: postcode formatting, line standardisation, `formatted` single-line field added.
- Empty query rejected with a descriptive error.

### Example call

```json
{"name": "uk_company_search", "arguments": {"query": "Tesco", "max_results": 3}}
```

---

## uk_company_profile

Get the full profile of a UK company by its company number.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number (e.g. `00445790`). Numeric values are automatically zero-padded to 8 digits. Prefixed numbers (SC, NI, OC) are uppercased. |

### Returns

`data` contains the full company profile: `company_name`, `company_number`, `company_status`, `type`, `date_of_creation`, `registered_office_address` (cleaned), `sic_codes`, `accounts` (next due, last made up to), `confirmation_statement` (next due), and more.

### Cleaning applied

- Company number normalised (zero-padded, uppercased).
- Registered office address cleaned: postcode formatting, line normalisation, `formatted` field.

### Example call

```json
{"name": "uk_company_profile", "arguments": {"company_number": "445790"}}
```

Note: `445790` is automatically normalised to `00445790`.

---

## uk_company_officers

Get officers (directors, secretaries, etc.) of a UK company with name deduplication.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number. Automatically normalised. |

### Returns

`data` contains the officer list with `items` (deduplicated officer records) and `_cleaning` metadata showing original count, deduplicated count, and duplicates removed.

Each officer record includes: `name`, `officer_role`, `appointed_on`, `resigned_on` (if applicable), `nationality`, `occupation`, `country_of_residence`, and `address`.

Deduplicated records include a `_cleaning` annotation with `duplicate_count`, `original_names`, and a human-readable `note`.

### Cleaning applied

- **Full pagination**: fetches all pages of officers, not just the first 50.
- **Name deduplication**: fuzzy matching (threshold 85/100) groups records like "SMITH, John David" and "John Smith" when they share the same role. The most recently appointed record is kept as primary.
- Company number normalised.

### Example call

```json
{"name": "uk_company_officers", "arguments": {"company_number": "00445790"}}
```

---

## uk_company_psc

Get persons with significant control (beneficial owners) of a UK company with entity classification.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number. Automatically normalised. |

### Returns

`data` contains the PSC list with `items`. Each PSC record includes: `name`, `kind`, `natures_of_control`, `notified_on`, `ceased_on` (if applicable), and `address`.

Each record carries a `_cleaning` annotation with `entity_type` (`individual`, `corporate`, or `unknown`), and flags for `misclassified` (corporate entity filed as individual) and `ceased`.

### Cleaning applied

- **Entity classification**: each record is annotated as individual, corporate, or unknown.
- **Misclassification detection**: flags corporate entities incorrectly filed as natural persons, using identification fields and corporate name indicators (Ltd, PLC, LLP, GmbH, etc.).
- **Ceased flagging**: marks PSCs that are no longer active.
- Company number normalised.

### Example call

```json
{"name": "uk_company_psc", "arguments": {"company_number": "00445790"}}
```

---

## uk_company_filings

Get recent filing history for a UK company with readable descriptions.

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `company_number` | string | yes | — | Companies House number. Automatically normalised. |
| `max_results` | int | no | 20 | Maximum number of filings to return |

### Returns

`data` contains the filing history with `items`. Each filing includes: `category`, `type`, `date`, `description` (raw code), `description_rendered` (readable text), and `description_values` (interpolated data).

### Cleaning applied

- **Description rendering**: converts hyphenated filing codes into readable sentences, interpolating variable values (names, dates, capital figures).
- Company number normalised.

### Example call

```json
{"name": "uk_company_filings", "arguments": {"company_number": "00445790", "max_results": 5}}
```

---

## Data source

All data from the [Companies House API](https://developer.company-information.service.gov.uk/). Published under the [Open Government Licence v3.0](https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/). Crown copyright.
