# git-commit-msg-ai

AI-powered git commit message generator that follows the [Conventional Commits](https://www.conventionalcommits.org/) specification.

## Prerequisites

- Python 3.10+
- An Anthropic API key set as an environment variable:

  ```sh
  export ANTHROPIC_API_KEY=sk-ant-...   # macOS/Linux
  ```

  ```powershell
  [System.Environment]::SetEnvironmentVariable('ANTHROPIC_API_KEY', 'sk-ant-...', 'User')   # Windows
  ```

## Development Setup

Clone the repository, create a virtual environment, and install the project in editable mode with all dev dependencies:

```sh
python -m venv .venv
```

Activate the virtual environment:

```sh
# macOS/Linux
source .venv/bin/activate

# Windows PowerShell
.venv\Scripts\Activate.ps1
```

Install the project and dev dependencies:

```sh
pip install -e ".[dev]"
```

After activation the `git-commit-msg-ai` entry-point is on your PATH. You can also run the dev toolchain:

```sh
pytest          # run tests with coverage
ruff check .    # lint
mypy .          # type-check
```

## Installation

```sh
pip install git-commit-msg-ai
```

## Usage

Stage your changes, then run the tool from inside any git repository:

```sh
git add <files>
git-commit-msg-ai
```

The tool will:
1. Read your staged diff
2. Generate a commit message using Claude AI
3. Print the message and prompt you to choose:

```
[a]ccept / [e]dit / [r]eject:
```

- **a** - commits immediately with the generated message
- **e** - opens the message in your `$EDITOR` (defaults to `notepad` on Windows, `vi` on Linux/macOS), lets you modify it, then commits
- **r** - exits without committing

## Commit message format

Generated messages follow the Conventional Commits specification:

```
<type>(<optional scope>): <short subject>

- Bullet explaining why this change was made
- Another reason if applicable
```

For breaking changes, the subject line gets a `!` and a footer is added:

```
feat(api)!: remove deprecated endpoint

- Endpoint was unused and blocking the new auth rollout

BREAKING CHANGE: /v1/legacy is no longer available
```

Supported types: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`
