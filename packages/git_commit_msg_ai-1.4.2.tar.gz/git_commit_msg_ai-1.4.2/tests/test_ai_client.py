from contextlib import ExitStack
from unittest.mock import MagicMock, patch

import anthropic
import pytest

from git_commit_msg_ai.ai_client import generate_commit_message
from git_commit_msg_ai.exceptions import AIError


def _make_api_response(text: str) -> MagicMock:
    mock_text_block = MagicMock(spec=anthropic.types.TextBlock)
    mock_text_block.text = text

    mock_response = MagicMock(spec=anthropic.types.Message)
    mock_response.content = [mock_text_block]

    return mock_response


def _make_status_error(exception_class: type[anthropic.APIStatusError], status_code: int) -> anthropic.APIStatusError:
    mock_response = MagicMock()
    mock_response.status_code = status_code

    return exception_class('error', response=mock_response, body={})


class TestGenerateCommitMessage:
    def test_returns_stripped_commit_message(self) -> None:
        with ExitStack() as stack:
            mock_anthropic_class = stack.enter_context(patch('git_commit_msg_ai.ai_client.anthropic.Anthropic'))
            mock_client = MagicMock()
            mock_client.messages.create.return_value = _make_api_response('  feat: add feature  ')
            mock_anthropic_class.return_value = mock_client

            result = generate_commit_message('diff content')

        assert result == 'feat: add feature'

    def test_raises_ai_error_on_authentication_error(self) -> None:
        with ExitStack() as stack:
            mock_anthropic_class = stack.enter_context(patch('git_commit_msg_ai.ai_client.anthropic.Anthropic'))
            mock_client = MagicMock()
            mock_client.messages.create.side_effect = _make_status_error(anthropic.AuthenticationError, 401)
            mock_anthropic_class.return_value = mock_client

            with pytest.raises(AIError, match='ANTHROPIC_API_KEY'):
                generate_commit_message('diff content')

    def test_raises_ai_error_on_rate_limit_error(self) -> None:
        with ExitStack() as stack:
            mock_anthropic_class = stack.enter_context(patch('git_commit_msg_ai.ai_client.anthropic.Anthropic'))
            mock_client = MagicMock()
            mock_client.messages.create.side_effect = _make_status_error(anthropic.RateLimitError, 429)
            mock_anthropic_class.return_value = mock_client

            with pytest.raises(AIError, match='rate limit'):
                generate_commit_message('diff content')

    def test_raises_ai_error_on_api_connection_error(self) -> None:
        mock_request = MagicMock()

        with ExitStack() as stack:
            mock_anthropic_class = stack.enter_context(patch('git_commit_msg_ai.ai_client.anthropic.Anthropic'))
            mock_client = MagicMock()
            mock_client.messages.create.side_effect = anthropic.APIConnectionError(request=mock_request)
            mock_anthropic_class.return_value = mock_client

            with pytest.raises(AIError, match='network'):
                generate_commit_message('diff content')

    def test_raises_ai_error_on_api_status_error_with_status_code(self) -> None:
        with ExitStack() as stack:
            mock_anthropic_class = stack.enter_context(patch('git_commit_msg_ai.ai_client.anthropic.Anthropic'))
            mock_client = MagicMock()
            mock_client.messages.create.side_effect = _make_status_error(anthropic.APIStatusError, 500)
            mock_anthropic_class.return_value = mock_client

            with pytest.raises(AIError, match='500'):
                generate_commit_message('diff content')
