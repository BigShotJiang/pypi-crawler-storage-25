from contextlib import ExitStack
from unittest.mock import MagicMock, patch

import pytest

from git_commit_msg_ai.cli import main
from git_commit_msg_ai.exceptions import AIError, GitError

COMMIT_MESSAGE = 'feat: add feature'
EDITED_COMMIT_MESSAGE = 'edited commit message'
STAGED_DIFF = 'diff content'
GENERIC_COMMIT_MESSAGE = 'generic commit message'


class TestMain:
    def _run_with_input(self, user_input: str, commit_message: str = COMMIT_MESSAGE) -> tuple[MagicMock, MagicMock, MagicMock]:
        mock_git_ops = MagicMock()
        mock_git_ops.get_staged_diff.return_value = STAGED_DIFF

        mock_ai_client = MagicMock()
        mock_ai_client.generate_commit_message.return_value = commit_message

        mock_editor = MagicMock()
        mock_editor.open_in_editor.return_value = EDITED_COMMIT_MESSAGE

        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.cli.git_ops', mock_git_ops))
            stack.enter_context(patch('git_commit_msg_ai.cli.ai_client', mock_ai_client))
            stack.enter_context(patch('git_commit_msg_ai.cli.editor', mock_editor))
            stack.enter_context(patch('builtins.input', return_value=user_input))
            main()

        return mock_git_ops, mock_ai_client, mock_editor

    def test_accept_calls_commit_with_generated_message(self) -> None:
        mock_git_ops, _, _ = self._run_with_input('a', COMMIT_MESSAGE)

        mock_git_ops.commit.assert_called_once_with(COMMIT_MESSAGE)

    def test_edit_opens_editor_then_commits_edited_message(self) -> None:
        mock_git_ops, _, mock_editor = self._run_with_input('e', COMMIT_MESSAGE)

        mock_editor.open_in_editor.assert_called_once_with(COMMIT_MESSAGE)
        mock_git_ops.commit.assert_called_once_with(EDITED_COMMIT_MESSAGE)

    def test_reject_does_not_commit(self) -> None:
        mock_git_ops, _, _ = self._run_with_input('r')

        mock_git_ops.commit.assert_not_called()

    def test_invalid_input_exits_with_code_1(self) -> None:
        mock_git_ops = MagicMock()
        mock_git_ops.get_staged_diff.return_value = STAGED_DIFF

        mock_ai_client = MagicMock()
        mock_ai_client.generate_commit_message.return_value = GENERIC_COMMIT_MESSAGE

        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.cli.git_ops', mock_git_ops))
            stack.enter_context(patch('git_commit_msg_ai.cli.ai_client', mock_ai_client))
            stack.enter_context(patch('git_commit_msg_ai.cli.editor'))
            stack.enter_context(patch('builtins.input', return_value='x'))
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1

    def test_git_error_from_get_staged_diff_exits_with_message(self, capsys: pytest.CaptureFixture[str]) -> None:
        mock_git_ops = MagicMock()
        mock_git_ops.get_staged_diff.side_effect = GitError('staged error')

        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.cli.git_ops', mock_git_ops))
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1
        assert 'staged error' in capsys.readouterr().out

    def test_ai_error_from_generate_commit_message_exits_with_message(self, capsys: pytest.CaptureFixture[str]) -> None:
        mock_git_ops = MagicMock()
        mock_git_ops.get_staged_diff.return_value = STAGED_DIFF

        mock_ai_client = MagicMock()
        mock_ai_client.generate_commit_message.side_effect = AIError('ai error')

        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.cli.git_ops', mock_git_ops))
            stack.enter_context(patch('git_commit_msg_ai.cli.ai_client', mock_ai_client))
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1
        assert 'ai error' in capsys.readouterr().out

    def test_git_error_from_commit_exits_with_message(self, capsys: pytest.CaptureFixture[str]) -> None:
        mock_git_ops = MagicMock()
        mock_git_ops.get_staged_diff.return_value = STAGED_DIFF
        mock_git_ops.commit.side_effect = GitError('commit error')

        mock_ai_client = MagicMock()
        mock_ai_client.generate_commit_message.return_value = GENERIC_COMMIT_MESSAGE

        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.cli.git_ops', mock_git_ops))
            stack.enter_context(patch('git_commit_msg_ai.cli.ai_client', mock_ai_client))
            stack.enter_context(patch('git_commit_msg_ai.cli.editor'))
            stack.enter_context(patch('builtins.input', return_value='a'))
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1
        assert 'commit error' in capsys.readouterr().out

    def test_keyboard_interrupt_exits_with_aborted_message(self, capsys: pytest.CaptureFixture[str]) -> None:
        mock_git_ops = MagicMock()
        mock_git_ops.get_staged_diff.return_value = STAGED_DIFF

        mock_ai_client = MagicMock()
        mock_ai_client.generate_commit_message.return_value = GENERIC_COMMIT_MESSAGE

        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.cli.git_ops', mock_git_ops))
            stack.enter_context(patch('git_commit_msg_ai.cli.ai_client', mock_ai_client))
            stack.enter_context(patch('git_commit_msg_ai.cli.editor'))
            stack.enter_context(patch('builtins.input', side_effect=KeyboardInterrupt))
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1
        assert 'Aborted.' in capsys.readouterr().out

    def test_eof_error_exits_with_aborted_message(self, capsys: pytest.CaptureFixture[str]) -> None:
        mock_git_ops = MagicMock()
        mock_git_ops.get_staged_diff.return_value = STAGED_DIFF

        mock_ai_client = MagicMock()
        mock_ai_client.generate_commit_message.return_value = GENERIC_COMMIT_MESSAGE

        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.cli.git_ops', mock_git_ops))
            stack.enter_context(patch('git_commit_msg_ai.cli.ai_client', mock_ai_client))
            stack.enter_context(patch('git_commit_msg_ai.cli.editor'))
            stack.enter_context(patch('builtins.input', side_effect=EOFError))
            with pytest.raises(SystemExit) as exc_info:
                main()

        assert exc_info.value.code == 1
        assert 'Aborted.' in capsys.readouterr().out
