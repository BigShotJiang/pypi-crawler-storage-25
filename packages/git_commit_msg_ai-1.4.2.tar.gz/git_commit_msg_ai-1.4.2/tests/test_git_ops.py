import subprocess
from contextlib import ExitStack
from unittest.mock import MagicMock, patch

import pytest

from git_commit_msg_ai.exceptions import GitError
from git_commit_msg_ai.git_ops import COMMIT_SUBCOMMAND, GIT_COMMAND, MESSAGE_FLAG, commit, get_staged_diff

COMMIT_MESSAGE = 'my message'


class TestGetStagedDiff:
    def test_returns_decoded_diff(self) -> None:
        with ExitStack() as stack:
            mock_check_output = stack.enter_context(patch('git_commit_msg_ai.git_ops.subprocess.check_output'))
            mock_check_output.return_value = b'diff content'

            result = get_staged_diff()

        assert result == 'diff content'

    def test_raises_git_error_when_git_not_found(self) -> None:
        with ExitStack() as stack:
            mock_check_output = stack.enter_context(patch('git_commit_msg_ai.git_ops.subprocess.check_output'))
            mock_check_output.side_effect = FileNotFoundError

            with pytest.raises(GitError, match='not installed'):
                get_staged_diff()

    def test_raises_git_error_on_called_process_error(self) -> None:
        with ExitStack() as stack:
            mock_check_output = stack.enter_context(patch('git_commit_msg_ai.git_ops.subprocess.check_output'))
            mock_check_output.side_effect = subprocess.CalledProcessError(1, 'git')

            with pytest.raises(GitError, match='git repository'):
                get_staged_diff()

    def test_raises_git_error_on_unicode_decode_error(self) -> None:
        mock_bytes = MagicMock()
        mock_bytes.decode.side_effect = UnicodeDecodeError('utf-8', b'', 0, 1, 'reason')

        with ExitStack() as stack:
            mock_check_output = stack.enter_context(patch('git_commit_msg_ai.git_ops.subprocess.check_output'))
            mock_check_output.return_value = mock_bytes

            with pytest.raises(GitError, match='UTF-8'):
                get_staged_diff()

    def test_raises_git_error_when_diff_is_empty(self) -> None:
        with ExitStack() as stack:
            mock_check_output = stack.enter_context(patch('git_commit_msg_ai.git_ops.subprocess.check_output'))
            mock_check_output.return_value = b''

            with pytest.raises(GitError, match='No staged changes'):
                get_staged_diff()


class TestCommit:
    def test_calls_subprocess_run_with_correct_args(self) -> None:
        with ExitStack() as stack:
            mock_run = stack.enter_context(patch('git_commit_msg_ai.git_ops.subprocess.run'))
            commit(COMMIT_MESSAGE)

        mock_run.assert_called_once_with([GIT_COMMAND, COMMIT_SUBCOMMAND, MESSAGE_FLAG, COMMIT_MESSAGE], check=True)

    def test_raises_git_error_when_git_not_found(self) -> None:
        with ExitStack() as stack:
            mock_run = stack.enter_context(patch('git_commit_msg_ai.git_ops.subprocess.run'))
            mock_run.side_effect = FileNotFoundError

            with pytest.raises(GitError, match='not installed'):
                commit(COMMIT_MESSAGE)

    def test_raises_git_error_on_called_process_error(self) -> None:
        with ExitStack() as stack:
            mock_run = stack.enter_context(patch('git_commit_msg_ai.git_ops.subprocess.run'))
            mock_run.side_effect = subprocess.CalledProcessError(1, GIT_COMMAND)

            with pytest.raises(GitError, match='git commit failed'):
                commit(COMMIT_MESSAGE)
