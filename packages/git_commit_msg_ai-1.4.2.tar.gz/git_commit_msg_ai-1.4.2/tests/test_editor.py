import os
import subprocess
import tempfile
from contextlib import ExitStack
from unittest.mock import MagicMock, patch

import pytest

from git_commit_msg_ai.editor import get_default_editor, open_in_editor
from git_commit_msg_ai.exceptions import EditorError

TEMP_FILE_PATH = os.path.join(tempfile.gettempdir(), 'tmpfile.txt')
INITIAL_TEXT = 'initial text'
EDITED_TEXT_WITH_WHITESPACE = '  edited text  '
EDITED_TEXT = 'edited text'
GENERIC_TEXT = 'text'
VIM_EDITOR = 'vim'


def _make_named_temporary_file_mock() -> MagicMock:
    mock_temp_file = MagicMock()
    mock_temp_file.name = TEMP_FILE_PATH
    mock_temp_file.__enter__ = MagicMock(return_value=mock_temp_file)
    mock_temp_file.__exit__ = MagicMock(return_value=False)

    return mock_temp_file


def _make_open_mock(text: str) -> MagicMock:
    mock_file = MagicMock()
    mock_file.read.return_value = text
    mock_file.__enter__ = MagicMock(return_value=mock_file)
    mock_file.__exit__ = MagicMock(return_value=False)

    return mock_file


class TestOpenInEditor:
    def test_returns_stripped_edited_text(self) -> None:
        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()))
            stack.enter_context(patch('git_commit_msg_ai.editor.subprocess.run'))
            stack.enter_context(patch('git_commit_msg_ai.editor.open', return_value=_make_open_mock(EDITED_TEXT_WITH_WHITESPACE)))
            stack.enter_context(patch('git_commit_msg_ai.editor.os.unlink'))

            result = open_in_editor(INITIAL_TEXT)

        assert result == EDITED_TEXT

    def test_uses_editor_env_var(self) -> None:
        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()))
            mock_run = stack.enter_context(patch('git_commit_msg_ai.editor.subprocess.run'))
            stack.enter_context(patch('git_commit_msg_ai.editor.open', return_value=_make_open_mock(GENERIC_TEXT)))
            stack.enter_context(patch('git_commit_msg_ai.editor.os.unlink'))
            stack.enter_context(patch('git_commit_msg_ai.editor.os.environ.get', return_value=VIM_EDITOR))

            open_in_editor(INITIAL_TEXT)

        mock_run.assert_called_once_with([VIM_EDITOR, TEMP_FILE_PATH], check=True)

    def test_falls_back_to_platform_default_when_editor_not_set(self) -> None:
        sentinel_editor = 'test-sentinel-editor'

        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()))
            mock_run = stack.enter_context(patch('git_commit_msg_ai.editor.subprocess.run'))
            stack.enter_context(patch('git_commit_msg_ai.editor.open', return_value=_make_open_mock(GENERIC_TEXT)))
            stack.enter_context(patch('git_commit_msg_ai.editor.os.unlink'))
            stack.enter_context(patch('git_commit_msg_ai.editor.get_default_editor', return_value=sentinel_editor))
            stack.enter_context(patch.dict('os.environ', {}, clear=True))

            open_in_editor(INITIAL_TEXT)

        mock_run.assert_called_once_with([sentinel_editor, TEMP_FILE_PATH], check=True)

    def test_raises_editor_error_on_temp_file_creation_failure(self) -> None:
        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', side_effect=OSError))
            mock_unlink = stack.enter_context(patch('git_commit_msg_ai.editor.os.unlink'))

            with pytest.raises(EditorError, match='temporary file'):
                open_in_editor(INITIAL_TEXT)

        mock_unlink.assert_not_called()

    def test_raises_editor_error_when_editor_not_found(self) -> None:
        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()))
            stack.enter_context(patch('git_commit_msg_ai.editor.subprocess.run', side_effect=FileNotFoundError))
            mock_unlink = stack.enter_context(patch('git_commit_msg_ai.editor.os.unlink'))
            stack.enter_context(patch('git_commit_msg_ai.editor.os.environ.get', return_value=VIM_EDITOR))

            with pytest.raises(EditorError, match='was not found'):
                open_in_editor(INITIAL_TEXT)

        mock_unlink.assert_called_once_with(TEMP_FILE_PATH)

    def test_raises_editor_error_when_editor_exits_with_error(self) -> None:
        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()))
            stack.enter_context(patch('git_commit_msg_ai.editor.subprocess.run', side_effect=subprocess.CalledProcessError(1, VIM_EDITOR)))
            mock_unlink = stack.enter_context(patch('git_commit_msg_ai.editor.os.unlink'))
            stack.enter_context(patch('git_commit_msg_ai.editor.os.environ.get', return_value=VIM_EDITOR))

            with pytest.raises(EditorError, match='exited with an error'):
                open_in_editor(INITIAL_TEXT)

        mock_unlink.assert_called_once_with(TEMP_FILE_PATH)

    def test_raises_editor_error_when_file_read_fails(self) -> None:
        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.editor.tempfile.NamedTemporaryFile', return_value=_make_named_temporary_file_mock()))
            stack.enter_context(patch('git_commit_msg_ai.editor.subprocess.run'))
            stack.enter_context(patch('git_commit_msg_ai.editor.open', side_effect=OSError))
            mock_unlink = stack.enter_context(patch('git_commit_msg_ai.editor.os.unlink'))

            with pytest.raises(EditorError, match='Could not read'):
                open_in_editor(INITIAL_TEXT)

        mock_unlink.assert_called_once_with(TEMP_FILE_PATH)


class TestGetDefaultEditor:
    def test_returns_notepad_on_windows(self) -> None:
        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.editor.platform.system', return_value='Windows'))
            result = get_default_editor()

        assert result == 'notepad'

    def test_returns_vi_on_non_windows(self) -> None:
        with ExitStack() as stack:
            stack.enter_context(patch('git_commit_msg_ai.editor.platform.system', return_value='Linux'))
            result = get_default_editor()

        assert result == 'vi'
