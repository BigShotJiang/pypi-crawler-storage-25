import subprocess
from typing import Final

from git_commit_msg_ai.exceptions import GitError

GIT_COMMAND: Final[str] = 'git'
DIFF_SUBCOMMAND: Final[str] = 'diff'
CACHED_FLAG: Final[str] = '--cached'
COMMIT_SUBCOMMAND: Final[str] = 'commit'
MESSAGE_FLAG: Final[str] = '-m'
UTF8_ENCODING: Final[str] = 'utf-8'


def get_staged_diff() -> str:
    try:
        staged_diff = subprocess.check_output([GIT_COMMAND, DIFF_SUBCOMMAND, CACHED_FLAG]).decode(UTF8_ENCODING)
    except FileNotFoundError:
        raise GitError('git is not installed or not on PATH.')
    except subprocess.CalledProcessError:
        raise GitError('Failed to get staged diff. Are you inside a git repository?')
    except UnicodeDecodeError:
        raise GitError('Staged diff contains bytes that could not be decoded as UTF-8.')

    if not staged_diff:
        raise GitError('No staged changes found. Stage files with git add before running.')

    return staged_diff


def commit(message: str) -> None:
    try:
        subprocess.run([GIT_COMMAND, COMMIT_SUBCOMMAND, MESSAGE_FLAG, message], check=True)
    except FileNotFoundError:
        raise GitError('git is not installed or not on PATH.')
    except subprocess.CalledProcessError:
        raise GitError('git commit failed.')
