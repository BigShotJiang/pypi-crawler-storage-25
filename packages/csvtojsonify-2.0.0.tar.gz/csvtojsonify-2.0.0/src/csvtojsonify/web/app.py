from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator

from csvtojsonify.core import ConversionError, csv_to_json

_STATIC = Path(__file__).resolve().parent / "static"

app = FastAPI(title="csvtojsonify", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ConvertRequest(BaseModel):
    csv: str = Field(..., description="Raw CSV text")
    indent: int | None = Field(
        2,
        description="JSON indent (0–8 spaces); null for minified output",
    )

    @field_validator("indent")
    @classmethod
    def _indent_range(cls, v: int | None) -> int | None:
        if v is not None and not 0 <= v <= 8:
            raise ValueError("indent must be between 0 and 8, or null")
        return v


class ConvertResponse(BaseModel):
    output: str


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/api/convert", response_model=ConvertResponse)
def convert(body: ConvertRequest) -> ConvertResponse:
    try:
        text = csv_to_json(body.csv, indent=body.indent)
    except ConversionError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return ConvertResponse(output=text)


@app.get("/")
def index() -> FileResponse:
    return FileResponse(_STATIC / "index.html")


app.mount(
    "/assets",
    StaticFiles(directory=str(_STATIC)),
    name="assets",
)
