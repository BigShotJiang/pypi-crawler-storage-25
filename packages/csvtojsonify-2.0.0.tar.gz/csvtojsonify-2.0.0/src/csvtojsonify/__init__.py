"""CSV to JSON conversion — library, CLI, and optional web UI."""

from csvtojsonify.core import ConversionError, csv_rows, csv_to_json

__all__ = ["ConversionError", "csv_rows", "csv_to_json", "__version__"]

__version__ = "2.0.0"
