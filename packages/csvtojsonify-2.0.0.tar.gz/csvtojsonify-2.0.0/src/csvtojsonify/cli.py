from __future__ import annotations

import argparse
import sys

from csvtojsonify.core import ConversionError, csv_to_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert CSV to JSON (stdout).")
    parser.add_argument(
        "path",
        nargs="?",
        help="CSV file path; omit to read stdin",
    )
    parser.add_argument(
        "--compact",
        action="store_true",
        help="Minified JSON (no indentation)",
    )
    args = parser.parse_args()

    if args.path:
        with open(args.path, encoding="utf-8") as f:
            text = f.read()
    else:
        text = sys.stdin.read()

    try:
        out = csv_to_json(text, indent=None if args.compact else 2)
    except ConversionError as e:
        print(f"csvtojsonify: {e}", file=sys.stderr)
        raise SystemExit(1) from e

    sys.stdout.write(out)
    if not out.endswith("\n"):
        sys.stdout.write("\n")


def main_web() -> None:
    """Run the web UI (requires optional [web] dependencies)."""
    try:
        import uvicorn
    except ImportError as e:
        print(
            "The web UI needs extra packages. Install with: pip install 'csvtojsonify[web]'",
            file=sys.stderr,
        )
        raise SystemExit(1) from e

    uvicorn.run(
        "csvtojsonify.web.app:app",
        host="127.0.0.1",
        port=8765,
        reload=False,
    )
