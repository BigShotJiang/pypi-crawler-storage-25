from __future__ import annotations

import csv
import io
import json


class ConversionError(Exception):
    """Raised when CSV input cannot be parsed."""


def _strip_bom(text: str) -> str:
    if text.startswith("\ufeff"):
        return text[1:]
    return text


def csv_rows(csv_text: str) -> list[dict[str, str | None]]:
    """
    Parse CSV text into a list of row dicts (header keys, string values).
    Empty fields become None when using non-empty restkey handling — we keep
    empty strings as "" for JSON-friendly output.
    """
    text = _strip_bom(csv_text).strip()
    if not text:
        return []

    stream = io.StringIO(text)
    try:
        sample = stream.read(4096)
        stream.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",\t;|")
        except csv.Error:
            dialect = csv.excel
        reader = csv.DictReader(stream, dialect=dialect)
        rows: list[dict[str, str | None]] = []
        for row in reader:
            rows.append(
                {k: (v if v is not None else "") for k, v in row.items() if k is not None}
            )
        return rows
    except csv.Error as e:
        raise ConversionError(str(e)) from e


def csv_to_json(
    csv_text: str,
    *,
    indent: int | None = 2,
    ensure_ascii: bool = False,
) -> str:
    """Return pretty-printed JSON for the given CSV string."""
    rows = csv_rows(csv_text)
    return json.dumps(rows, indent=indent, ensure_ascii=ensure_ascii)
