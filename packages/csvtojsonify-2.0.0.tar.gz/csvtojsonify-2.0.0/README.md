# csvtojsonify

Convert CSV to JSON as a Python library, CLI, or browser UI.

## Install from PyPI

```bash
pip install csvtojsonify
```

Web UI (FastAPI + Uvicorn):

```bash
pip install csvtojsonify[web]
```

## Install from source

```bash
pip install .
pip install ".[web]"
```

## Library

```python
from csvtojsonify import csv_to_json

json_str = csv_to_json("name,age\nAlice,30")
```

## CLI

```bash
csvtojsonify < input.csv > out.json
csvtojsonify path/to/file.csv
csvtojsonify --compact < data.csv
```

## Web UI

```bash
csvtojsonify-web
```

Open http://127.0.0.1:8765 — paste CSV on the left, JSON appears on the right.

## Publishing to PyPI (maintainers)

1. [Create a PyPI account](https://pypi.org/account/register/) and [API token](https://pypi.org/manage/account/token/) (scope: entire account or this project only).
2. Install build tools: `pip install build twine`
3. Bump the `version` in `pyproject.toml` (and `__version__` in `src/csvtojsonify/__init__.py`) to a **new** number; PyPI rejects re-uploading the same version.
5. Build artifacts:

   ```bash
   python -m build
   ```

6. Upload to the **test** index first (recommended):

   ```bash
   python -m twine upload --repository testpypi dist/*
   ```

   Verify: `pip install -i https://test.pypi.org/simple/ csvtojsonify`

7. Upload to **production** PyPI:

   ```bash
   python -m twine upload dist/*
   ```

   Configure credentials via `~/.pypirc` or environment variables `TWINE_USERNAME=__token__` and `TWINE_PASSWORD=pypi-...`.

After the first release, users install with `pip install csvtojsonify`.
