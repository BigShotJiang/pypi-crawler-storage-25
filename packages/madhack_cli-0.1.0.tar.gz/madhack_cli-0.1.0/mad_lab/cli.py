import os
import shutil
import questionary
from pathlib import Path

def main():
    # 1. Find the path to the templates folder INSIDE the installed package
    package_dir = Path(__file__).parent
    templates_dir = package_dir / "templates"

    if not templates_dir.exists():
        print("Error: Templates directory not found!")
        return

    # 2. Get a list of all available template folders
    options = sorted([d.name for d in templates_dir.iterdir() if d.is_dir()])

    if not options:
        print("No templates found.")
        return

    # 3. Show the interactive terminal menu
    choice = questionary.select(
        "Which Android component do you want to generate?",
        choices=options
    ).ask()

    # If the user presses Ctrl+C to cancel
    if not choice:
        print("Operation cancelled.")
        return

    # 4. Set destination to the user's current terminal path
    target_dir = Path.cwd() / choice
    source_dir = templates_dir / choice

    if target_dir.exists():
        print(f"Error: A directory named '{choice}' already exists here.")
        return

    # 5. Copy the folder!
    try:
        shutil.copytree(source_dir, target_dir)
        print(f"✅ Successfully created '{choice}' in {Path.cwd()}")
    except Exception as e:
        print(f"❌ Failed to generate template: {e}")

if __name__ == "__main__":
    main()
