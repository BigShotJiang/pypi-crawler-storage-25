package com.example.mad

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
    }

    fun exit(view: View) {

        val alert = AlertDialog.Builder(this)

        alert.setTitle("Confirm Exit")

        alert.setIcon(android.R.drawable.ic_dialog_alert)

        alert.setMessage(
            "Are you sure you want to exit?"
        )

        alert.setCancelable(false)

        alert.setPositiveButton("Yes") { _, _ ->

            finish()
        }

        alert.setNegativeButton("No") { _, _ ->

            Toast.makeText(
                this,
                "You clicked No",
                Toast.LENGTH_LONG
            ).show()
        }

        alert.setNeutralButton("Cancel") { _, _ ->

            Toast.makeText(
                this,
                "You clicked Cancel",
                Toast.LENGTH_LONG
            ).show()
        }

        alert.create().show()
    }
}
