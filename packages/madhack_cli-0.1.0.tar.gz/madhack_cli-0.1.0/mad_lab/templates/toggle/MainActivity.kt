package com.example.mad

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.ToggleButton
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var image: ImageView
    private lateinit var result: TextView
    private lateinit var toggleButton: ToggleButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        image = findViewById(R.id.image)
        result = findViewById(R.id.result)
        toggleButton = findViewById(R.id.toggleButton)

        toggleButton.setOnCheckedChangeListener { _, isChecked ->

            if (isChecked) {

                image.visibility = View.INVISIBLE
                result.text = "The image is Invisible"

            } else {

                image.visibility = View.VISIBLE
                result.text = "The image is Visible"
            }
        }
    }
}
