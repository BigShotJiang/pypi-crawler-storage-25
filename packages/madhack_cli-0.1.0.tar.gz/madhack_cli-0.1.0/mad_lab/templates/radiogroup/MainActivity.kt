package com.example.mad

import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var radioGroup: RadioGroup
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        radioGroup = findViewById(R.id.radioGroup1)
        submitButton = findViewById(R.id.submitButton)

        submitButton.setOnClickListener {

            val selectedId = radioGroup.checkedRadioButtonId

            if (selectedId == -1) {

                Toast.makeText(
                    this,
                    "Please select an option",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                val radioButton =
                    findViewById<RadioButton>(selectedId)

                Toast.makeText(
                    this,
                    "Selected: ${radioButton.text}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}
