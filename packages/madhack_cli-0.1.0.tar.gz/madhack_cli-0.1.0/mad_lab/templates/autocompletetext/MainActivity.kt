package com.example.mad

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val fruits = arrayOf(
        "Apple",
        "Banana",
        "Cherry",
        "Date",
        "Grape",
        "Kiwi",
        "Mango",
        "Pear"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        title = "KotlinApp"

        val autoTxtView: AutoCompleteTextView =
            findViewById(R.id.text)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            fruits
        )

        autoTxtView.threshold = 1

        autoTxtView.setAdapter(adapter)
    }
}
