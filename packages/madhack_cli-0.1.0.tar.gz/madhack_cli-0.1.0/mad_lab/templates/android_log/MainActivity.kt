package com.example.mad

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val tag = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d(tag, "onCreate")
    }

    override fun onStart() {
        super.onStart()

        Log.d(tag, "onStart")
    }

    override fun onResume() {
        super.onResume()

        Log.d(tag, "onResume")
    }

    override fun onPause() {
        super.onPause()

        Log.d(tag, "onPause")
    }

    override fun onStop() {
        super.onStop()

        Log.d(tag, "onStop")
    }

    override fun onRestart() {
        super.onRestart()

        Log.d(tag, "onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()

        Log.d(tag, "onDestroy")
    }
}
