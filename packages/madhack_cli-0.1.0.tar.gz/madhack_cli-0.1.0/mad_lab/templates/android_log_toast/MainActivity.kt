package com.example.mad

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val tag = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        Log.d(tag, "onCreate method call")

        Toast.makeText(
            applicationContext,
            "onCreate",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onStart() {
        super.onStart()

        Log.d(tag, "onStart method call")

        Toast.makeText(
            applicationContext,
            "onStart",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onResume() {
        super.onResume()

        Log.d(tag, "onResume method call")

        Toast.makeText(
            applicationContext,
            "onResume",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onPause() {
        super.onPause()

        Log.d(tag, "onPause method call")

        Toast.makeText(
            applicationContext,
            "onPause",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onStop() {
        super.onStop()

        Log.d(tag, "onStop method call")

        Toast.makeText(
            applicationContext,
            "onStop",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onRestart() {
        super.onRestart()

        Log.d(tag, "onRestart method call")

        Toast.makeText(
            applicationContext,
            "onRestart",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onDestroy() {
        super.onDestroy()

        Log.d(tag, "onDestroy method call")

        Toast.makeText(
            applicationContext,
            "onDestroy",
            Toast.LENGTH_LONG
        ).show()
    }
}
