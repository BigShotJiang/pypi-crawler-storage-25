from setuptools import setup, find_packages

setup(
    name='madhack-cli',
    version='0.1.0',
    description='A CLI tool to generate Android MAD lab templates',
    packages=find_packages(),
    include_package_data=True, # Crucial: tells pip to include your template files
    install_requires=[
        'questionary', # A great library for interactive terminal menus
    ],
    entry_points={
        'console_scripts': [
            'madhack = mad_lab.cli:main', # Maps the 'mad-lab' command to your python function
        ],
    },
)


