"""Fetch Google Search Console data for the Regula website."""

import argparse
import csv
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

TOKEN_PATH = Path(__file__).resolve().parent.parent / "token.json"
SITE_URL = "sc-domain:getregula.com"


def load_credentials():
    creds = Credentials.from_authorized_user_file(str(TOKEN_PATH))
    if creds.expired and creds.refresh_token:
        creds.refresh(Request())
        TOKEN_PATH.write_text(creds.to_json())
    return creds


def fetch_data(creds, start_date, end_date, dimensions, page_filter=None,
               query_filter=None, row_limit=1000):
    service = build("searchconsole", "v1", credentials=creds)

    body = {
        "startDate": start_date,
        "endDate": end_date,
        "dimensions": dimensions,
        "rowLimit": row_limit,
    }

    filters = []
    if page_filter:
        filters.append({
            "dimension": "page",
            "operator": "contains",
            "expression": page_filter,
        })
    if query_filter:
        filters.append({
            "dimension": "query",
            "operator": "contains",
            "expression": query_filter,
        })
    if filters:
        body["dimensionFilterGroups"] = [{"filters": filters}]

    response = service.searchanalytics().query(
        siteUrl=SITE_URL, body=body
    ).execute()

    return response.get("rows", [])


def format_rows(rows, dimensions):
    formatted = []
    for row in rows:
        entry = {}
        for i, dim in enumerate(dimensions):
            entry[dim] = row["keys"][i]
        entry["clicks"] = row["clicks"]
        entry["impressions"] = row["impressions"]
        entry["ctr"] = round(row["ctr"] * 100, 2)
        entry["position"] = round(row["position"], 1)
        formatted.append(entry)
    return formatted


def output_csv(data, out=sys.stdout):
    if not data:
        print("No data found.", file=sys.stderr)
        return
    writer = csv.DictWriter(out, fieldnames=data[0].keys())
    writer.writeheader()
    writer.writerows(data)


def output_json(data):
    print(json.dumps(data, indent=2))


def main():
    parser = argparse.ArgumentParser(description="Fetch GSC data for Regula")
    parser.add_argument("--days", type=int, default=28,
                        help="Number of days to look back (default: 28)")
    parser.add_argument("--start", help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end", help="End date (YYYY-MM-DD)")
    parser.add_argument("--dimensions", default="query,page",
                        help="Comma-separated: query,page,date,device,country")
    parser.add_argument("--page-filter", help="Filter pages containing this string")
    parser.add_argument("--query-filter", help="Filter queries containing this string")
    parser.add_argument("--limit", type=int, default=1000,
                        help="Max rows to return (default: 1000)")
    parser.add_argument("--format", choices=["csv", "json"], default="csv",
                        help="Output format (default: csv)")
    parser.add_argument("--site", help="Override GSC site URL")
    args = parser.parse_args()

    global SITE_URL
    if args.site:
        SITE_URL = args.site

    if args.start and args.end:
        start_date = args.start
        end_date = args.end
    else:
        end_date = (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d")
        start_date = (datetime.now() - timedelta(days=args.days + 3)).strftime("%Y-%m-%d")

    dimensions = [d.strip() for d in args.dimensions.split(",")]

    creds = load_credentials()
    rows = fetch_data(creds, start_date, end_date, dimensions,
                      page_filter=args.page_filter,
                      query_filter=args.query_filter,
                      row_limit=args.limit)
    data = format_rows(rows, dimensions)

    if args.format == "json":
        output_json(data)
    else:
        output_csv(data)


if __name__ == "__main__":
    main()
