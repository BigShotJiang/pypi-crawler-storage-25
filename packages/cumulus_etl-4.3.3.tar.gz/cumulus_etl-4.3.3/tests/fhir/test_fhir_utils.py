"""Tests for fhir_utils.py"""

import datetime

import cumulus_fhir_support as cfs
import ddt

from cumulus_etl import common, fhir
from tests import utils


@ddt.ddt
class TestReferenceHandlers(utils.AsyncTestCase):
    """Tests for the unref_ and ref_ methods"""

    @ddt.data(
        ({"reference": "Patient/123"}, "Patient", "123"),
        ({"reference": "123", "type": "Patient"}, "Patient", "123"),
        ({"reference": "#123"}, None, "#123"),
        # Synthea style reference
        (
            {"reference": "Patient?identifier=http://example.com|123"},
            "Patient",
            "identifier=http://example.com|123",
        ),
    )
    @ddt.unpack
    def test_unref_successes(self, full_reference, expected_type, expected_id):
        parsed = fhir.unref_resource(full_reference)
        self.assertEqual((expected_type, expected_id), parsed)

    @ddt.data(
        None,
        "",
        "123",  # with no type field
        "?/123",
        "http://example.com/Patient/123",
    )
    def test_unref_failures(self, reference):
        with self.assertRaises(ValueError):
            fhir.unref_resource({"reference": reference})

    @ddt.data(
        ("Patient", "123", "Patient/123"),
        (None, "#123", "#123"),
    )
    @ddt.unpack
    def test_ref_resource(self, resource_type, resource_id, expected):
        self.assertEqual({"reference": expected}, fhir.ref_resource(resource_type, resource_id))

    def test_ref_resource_no_id(self):
        with self.assertRaisesRegex(ValueError, "Missing resource ID"):
            fhir.ref_resource(None, "")


@ddt.ddt
class TestDateParsing(utils.AsyncTestCase):
    """Tests for the parse_datetime method"""

    @ddt.data(
        (None, None),
        ("", None),
        ("abc", None),
        ("abc-de", None),
        ("abc-de-fg", None),
        ("2018", datetime.datetime(2018, 1, 1)),  # naive
        ("2021-07", datetime.datetime(2021, 7, 1)),  # naive
        ("1992-11-06", datetime.datetime(1992, 11, 6)),  # naive
        (
            "1992-11-06T13:28:17.239+02:00",
            datetime.datetime(
                1992,
                11,
                6,
                13,
                28,
                17,
                239000,
                tzinfo=datetime.timezone(datetime.timedelta(hours=2)),
            ),
        ),
        (
            "1992-11-06T13:28:17.239Z",
            datetime.datetime(1992, 11, 6, 13, 28, 17, 239000, tzinfo=datetime.UTC),
        ),
    )
    @ddt.unpack
    def test_parse_datetime(self, input_value, expected_value):
        parsed = fhir.parse_datetime(input_value)
        self.assertEqual(expected_value, parsed)


@ddt.ddt
class TestUrlParsing(utils.AsyncTestCase):
    """Tests for URL parsing"""

    @ddt.data(
        ("//host", SystemExit),
        ("https://host", ""),
        ("https://host/root", ""),
        ("https://Group/MyGroup", ""),  # Group is hostname here
        ("https://host/root/?key=/Group/Testing/", ""),
        ("https://host/root/Group/MyGroup", "MyGroup"),
        ("https://host/root/Group/MyGroup/", "MyGroup"),
        ("https://host/Group/MyGroup/$export", "MyGroup"),
        ("https://host/Group/MyGroup?key=value", "MyGroup"),
        ("https://host/root/Group/Group/", "Group"),
    )
    @ddt.unpack
    def test_parse_group_from_url(self, url, expected_group):
        if isinstance(expected_group, str):
            group = fhir.FhirUrl(url).group
            assert expected_group == group
        else:
            with self.assertRaises(expected_group):
                fhir.FhirUrl(url)

    @ddt.data(
        "http://host/root/",
        "http://host/root/$export?",
        "http://host/root/Group/xxx",
        "http://host/root/Group/xxx#fragment",
        "http://host/root/Group/xxx/$export?_type=Patient",
        "http://host/root/Patient",
        "http://host/root/Patient/$export",
    )
    def test_parse_base_url_from_url(self, url):
        """Verify that we detect the auth root for an input URL"""
        parsed = fhir.FhirUrl(url)
        self.assertEqual(parsed.full_url, url)
        self.assertEqual(parsed.root_url, "http://host/root")


@ddt.ddt
class TestDocrefNotesUtils(utils.AsyncTestCase):
    """Tests for the utility methods dealing with document reference clinical notes"""

    def test_role_info_wrong_type(self):
        with self.assertRaisesRegex(ValueError, "Condition is not a supported clinical note type"):
            fhir.get_clinical_note_role_info({"resourceType": "Condition"}, "/tmp/nope")

    def test_role_info_bad_person_link_ignored(self):
        info = fhir.get_clinical_note_role_info(
            {
                "resourceType": "DocumentReference",
                "author": [{"display": "Missing link"}, {"reference": "Practitioner/A"}],
            },
            "/tmp/nope",
        )
        self.assertEqual(info, "Authors:\n* Practitioner/A")

    def test_role_info_wrong_role_target_ignored(self):
        tmpdir = self.make_tempdir()

        with common.NdjsonWriter(cfs.FsPath(f"{tmpdir}/roles.ndjson")) as writer:
            writer.write(
                {
                    "resourceType": "PractitionerRole",
                    "practitioner": {"reference": "Organization/A"},
                    "code": [{"text": "Wrong Type"}],
                }
            )
            writer.write(
                {
                    "resourceType": "PractitionerRole",
                    "practitioner": {"display": "No ref"},
                    "code": [{"text": "No Ref"}],
                }
            )
            writer.write(
                {
                    "resourceType": "PractitionerRole",
                    "practitioner": {"reference": "Practitioner/A"},
                    "code": [{"text": "Right"}],
                }
            )

        info = fhir.get_clinical_note_role_info(
            {"resourceType": "DocumentReference", "author": [{"reference": "Practitioner/A"}]},
            tmpdir,
        )
        self.assertEqual(info, "Authors:\n* Practitioner/A\n  - Role: Right")

    def test_role_info_names(self):
        tmpdir = self.make_tempdir()

        with common.NdjsonWriter(cfs.FsPath(f"{tmpdir}/people.ndjson")) as writer:
            writer.write(
                {
                    "resourceType": "Practitioner",
                    "id": "NoNames",
                }
            )
            writer.write(
                {
                    "resourceType": "Practitioner",
                    "id": "Official",
                    "name": [
                        {"use": "temp", "text": "temp"},
                        {"use": "old", "text": "old"},
                        {"use": "usual", "text": "usual"},
                        {"use": "official", "text": "official"},
                    ],
                }
            )
            writer.write(
                {
                    "resourceType": "Practitioner",
                    "id": "Usual",
                    "name": [
                        {"use": "temp", "text": "temp"},
                        {"use": "old", "text": "old"},
                        {"use": "usual", "text": "usual"},
                    ],
                }
            )
            writer.write(
                {
                    "resourceType": "Practitioner",
                    "id": "Other",
                    "name": [
                        {"use": "temp", "text": "temp"},
                        {"use": "old", "text": "old"},
                    ],
                }
            )

        info = fhir.get_clinical_note_role_info(
            {
                "resourceType": "DiagnosticReport",
                "performer": [
                    {"reference": "Practitioner/NoNames"},
                    {"reference": "Practitioner/Official"},
                    {"reference": "Practitioner/Usual"},
                    {"reference": "Practitioner/Other"},
                ],
            },
            tmpdir,
        )
        self.assertEqual(info, "Performers:\n* Practitioner/NoNames\n* official\n* usual\n* temp")
