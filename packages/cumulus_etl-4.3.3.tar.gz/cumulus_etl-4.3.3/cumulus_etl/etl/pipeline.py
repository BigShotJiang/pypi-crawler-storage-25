import argparse
import datetime
import logging
from collections.abc import Iterable

import cumulus_fhir_support as cfs
import rich
import rich.table

from cumulus_etl import cli_utils, common, deid, errors, feedback, loaders
from cumulus_etl.etl import tasks
from cumulus_etl.etl.config import JobConfig, JobSummary, validate_etl_output_folder
from cumulus_etl.etl.tasks import task_factory

TaskList = list[type[tasks.EtlTask]]


async def etl_job(
    config: JobConfig, selected_tasks: TaskList, scrubber: deid.Scrubber
) -> list[JobSummary]:
    """
    :param config: job config
    :param selected_tasks: the tasks to run
    :param scrubber: de-id scrubber to use for jobs
    :return: a list of job summaries
    """
    summary_list = []

    for task_class in selected_tasks:
        task = task_class(config, scrubber)
        task_summaries = await task.run()
        summary_list.extend(task_summaries)

        for summary in task_summaries:
            path = config.dir_job_config().joinpath(f"{summary.label}.json")
            path.write_json(summary.as_json(), indent=4)

    return summary_list


def add_common_etl_args(
    parser: argparse.ArgumentParser, *, outputs: list[str], batch_size: int = 100_000
) -> None:
    parser.add_argument(
        "--input-format",
        default="ndjson",
        choices=["i2b2", "ndjson"],
        help="input format (default is ndjson)",
    )
    cli_utils.add_output_format(parser, choices=outputs)
    parser.add_argument(
        "--batch-size",
        type=int,
        metavar="SIZE",
        default=batch_size,
        help="how many entries to process at once and thus "
        f"how many to put in one output file (default is {batch_size // 1000}k)",
    )
    parser.add_argument(
        "--errors-to",
        metavar="DIR",
        type=cfs.FsPath,
        help="where to put resources that could not be processed",
    )

    cli_utils.add_auth(parser)
    cli_utils.add_debugging(parser)


def print_config(
    args: argparse.Namespace, job_datetime: datetime.datetime, all_tasks: TaskList
) -> None:
    """
    Prints the ETL configuration to the console.

    This is often redundant with command line arguments, but it's helpful if you are looking at a
    docker container's logs after the fact.

    This is different from printing a JobConfig's json to the console, because on a broad level,
    this here is to inform the user at the console, while JobConfig's purpose is to inform task
    code how to operate.

    But more specifically:
    (A) we want to print this as early as possible and a JobConfig needs some computed config
    (B) we may want to print some options here that don't particularly need to go into the
        JobConfig/**.json file in the output folder (e.g. export dir)
    (C) this formatting can be very user-friendly, while the other should be more
        machine-processable (e.g. skipping some default-value prints, or formatting time)
    """
    common.print_header("Configuration:")
    table = rich.table.Table("", rich.table.Column(overflow="fold"), box=None, show_header=False)
    table.add_row("Input path:", args.dir_input)
    if args.input_format != "ndjson":
        table.add_row(" Format:", args.input_format)
    if args.dir_output:
        table.add_row("Output path:", args.dir_output)
        table.add_row(" Format:", args.output_format)
    table.add_row("PHI/Build path:", args.dir_phi)
    if args.errors_to:
        table.add_row("Errors path:", args.errors_to)
    table.add_row("Current time:", f"{common.timestamp_datetime(job_datetime)} UTC")
    table.add_row("Batch size:", f"{args.batch_size:,}")
    table.add_row("Tasks:", ", ".join(sorted(t.name for t in all_tasks)))
    if "comment" in args and args.comment:
        table.add_row("Comment:", args.comment)
    rich.get_console().print(table)
    common.print_header()


async def check_available_resources(
    loader: loaders.Loader,
    *,
    selected_tasks: list[type[task_factory.AnyTask]],
    args: argparse.Namespace,
    is_default_tasks: bool,
    progress: feedback.Progress,
) -> set[str]:
    # Here we try to reconcile which resources the user requested and which resources are actually
    # available in the input root.
    # - If the user didn't specify a specific task, we'll scope down the requested resources to
    #   what is actually present in the input.
    # - If they did, we'll complain if their required resources are not available.
    #
    # Reconciling is helpful for performance reasons (don't need to finalize untouched tables),
    # UX reasons (can tell user if they made a CLI mistake), and completion tracking (don't
    # mark a resource as complete if we didn't even export it)
    all_possible_resources = set().union(*(t.get_resource_types() for t in selected_tasks))

    has_allow_missing = hasattr(args, "allow_missing_resources")
    if has_allow_missing and args.allow_missing_resources:
        return all_possible_resources

    detected = await loader.detect_resources(progress=progress)
    available_resources = all_possible_resources & detected

    missing_resources = set()
    for task in selected_tasks:
        if not task.get_resource_types() & detected:
            missing_resources |= task.get_resource_types()

    if missing_resources:
        for resource in sorted(missing_resources):
            # Log the same message we would print if in common.py if we ran tasks anyway
            logging.warning("No %s files found in %s", resource, str(loader.root))

        if is_default_tasks:
            if not available_resources:
                errors.fatal("No supported resources found.", errors.MISSING_REQUESTED_RESOURCES)
        else:
            msg = "Required resources not found.\n"
            if has_allow_missing:
                msg += "Add --allow-missing-resources to run related tasks anyway with no input."
            errors.fatal(msg, errors.MISSING_REQUESTED_RESOURCES)

    return available_resources


async def prepare_pipeline(
    args: argparse.Namespace, job_datetime: datetime.datetime, *, nlp: bool
) -> tuple[deid.Scrubber, loaders.LoaderResults, list[type[task_factory.AnyTask]]]:
    # record filesystem options like --s3-region before creating Roots
    common.set_user_fs_options(vars(args))

    root_input = cli_utils.process_input_dir(args.dir_input)
    args.dir_phi.makedirs()  # create PHI folder, if needed

    selected_tasks = task_factory.get_selected_tasks(args.task, nlp=nlp)
    is_default_tasks = not args.task

    # Print configuration
    print_config(args, job_datetime, selected_tasks)

    if args.errors_to:
        args.errors_to.makedirs()
        cli_utils.confirm_dir_is_empty(args.errors_to)

    # Check that cTAKES is running and any other services or binaries we require
    if not args.skip_init_checks:
        rich.print("Initializing…")
        for task in selected_tasks:
            await task.init_check()

    if args.input_format == "i2b2":
        config_loader = loaders.I2b2Loader(root_input)
    else:
        config_loader = loaders.FhirNdjsonLoader(root_input)

    with feedback.Progress() as progress:
        available_resources = await check_available_resources(
            config_loader,
            args=args,
            is_default_tasks=is_default_tasks,
            selected_tasks=selected_tasks,
            progress=progress,
        )

        # Drop any tasks that we didn't find resources for
        selected_tasks = [t for t in selected_tasks if t.get_resource_types() & available_resources]

        # Load resources from a remote location (like s3), convert from i2b2, or do a bulk export
        loader_results = await config_loader.load_resources(available_resources, progress=progress)

        with progress.show_indeterminate_task("Loading codebook"):
            if nlp:
                scrub_args = {"mask_notes": False, "keep_stats": False, "cache_ids": False}
            else:
                scrub_args = {"use_philter": args.philter}
            scrubber = deid.Scrubber(args.dir_phi, **scrub_args)

        if args.dir_output:
            # Make sure the output folder matches the PHI folder.
            # If we weren't given an output folder, don't bother (which happens in the NLP Athena
            # upload flow, but that confirms the codebook ID a different way.)
            validate_etl_output_folder(args.dir_output, scrubber.codebook.get_codebook_id())

    return scrubber, loader_results, selected_tasks


def print_summary(summaries: Iterable[JobSummary]) -> None:
    # Flag final status to user
    common.print_header()
    if any(s.had_errors for s in summaries):
        errors.fatal("🚨 One or more tasks above did not 100% complete! 🚨", errors.TASK_FAILED)
    else:
        rich.print("⭐ All tasks completed successfully! ⭐")
