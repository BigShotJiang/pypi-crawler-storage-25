"""Tests for llm-cache. Run: pytest tests/ -v"""

from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

import pytest

from llm_cache import CacheEntry, CacheStats, LLMCache, MatchType


@pytest.fixture
def cache(tmp_path):
    c = LLMCache(db_path=str(tmp_path / "test.db"), fuzzy_threshold=0.8)
    yield c
    c.close()


PROMPT = "What is retrieval augmented generation?"
RESPONSE = "RAG combines retrieval with generation."


class TestExactMatch:
    def test_miss_on_empty(self, cache):
        r, m = cache.get(PROMPT)
        assert r is None
        assert m == MatchType.MISS

    def test_set_and_get(self, cache):
        cache.set(PROMPT, RESPONSE)
        r, m = cache.get(PROMPT)
        assert r == RESPONSE
        assert m == MatchType.EXACT

    def test_case_insensitive(self, cache):
        cache.set(PROMPT, RESPONSE)
        r, m = cache.get(PROMPT.upper())
        assert m == MatchType.EXACT

    def test_whitespace_normalised(self, cache):
        cache.set(PROMPT, RESPONSE)
        r, m = cache.get(PROMPT.replace(" ", "  "))
        assert m == MatchType.EXACT

    def test_punctuation_normalised(self, cache):
        cache.set("What is RAG?", RESPONSE)
        _, m = cache.get("What is RAG")
        assert m == MatchType.EXACT

    def test_returns_correct_response(self, cache):
        cache.set(PROMPT, RESPONSE)
        r, _ = cache.get(PROMPT)
        assert r == RESPONSE

    def test_model_filter_matches(self, cache):
        cache.set(PROMPT, RESPONSE, model="claude-opus-4-5")
        _, m = cache.get(PROMPT, model="claude-opus-4-5")
        assert m == MatchType.EXACT

    def test_model_filter_miss(self, cache):
        cache.set(PROMPT, RESPONSE, model="claude-opus-4-5")
        _, m = cache.get(PROMPT, model="gpt-4")
        assert m == MatchType.MISS


class TestFuzzyMatch:
    def test_similar_prompt_hits(self, cache):
        cache.set("What is retrieval augmented generation?", RESPONSE)
        _, m = cache.get("What is retrieval augmented generation")
        assert m in (MatchType.EXACT, MatchType.FUZZY)

    def test_rephrased_hits(self, cache):
        cache.set("What is retrieval augmented generation?", RESPONSE)
        _, m = cache.get("What is retrieval augmented generation")
        # Very similar — should match above fuzzy threshold of 0.8
        assert m in (MatchType.EXACT, MatchType.FUZZY)

    def test_completely_different_misses(self, cache):
        cache.set(PROMPT, RESPONSE)
        _, m = cache.get("What is the capital of France?")
        assert m == MatchType.MISS

    def test_no_fuzzy_when_disabled(self, cache):
        cache.set(PROMPT, RESPONSE)
        _, m = cache.get("Explain retrieval augmented generation", use_fuzzy=False)
        assert m == MatchType.MISS

    def test_below_threshold_misses(self, tmp_path):
        c = LLMCache(db_path=str(tmp_path / "strict.db"), fuzzy_threshold=0.99)
        c.set(PROMPT, RESPONSE)
        _, m = c.get("Explain retrieval augmented generation")
        assert m == MatchType.MISS
        c.close()


class TestDecorator:
    def test_decorator_caches_result(self, cache):
        call_count = 0

        @cache.cached()
        def ask(prompt: str) -> str:
            nonlocal call_count
            call_count += 1
            return "answer"

        ask(PROMPT)
        ask(PROMPT)
        assert call_count == 1

    def test_decorator_returns_correct_value(self, cache):
        @cache.cached()
        def ask(prompt: str) -> str:
            return "the answer is 42"

        r1 = ask(PROMPT)
        r2 = ask(PROMPT)
        assert r1 == r2 == "the answer is 42"

    def test_decorator_different_prompts(self, cache):
        call_count = 0

        @cache.cached()
        def ask(prompt: str) -> str:
            nonlocal call_count
            call_count += 1
            return f"answer to {prompt}"

        ask("question one")
        ask("question two")
        assert call_count == 2

    def test_decorator_with_model(self, cache):
        @cache.cached(model="test-model")
        def ask(prompt: str) -> str:
            return "response"

        ask(PROMPT)
        _, m = cache.get(PROMPT, model="test-model")
        assert m == MatchType.EXACT


class TestManagement:
    def test_delete_by_prompt(self, cache):
        cache.set(PROMPT, RESPONSE)
        deleted = cache.delete(prompt=PROMPT)
        assert deleted == 1
        _, m = cache.get(PROMPT)
        assert m == MatchType.MISS

    def test_delete_by_model(self, cache):
        cache.set(PROMPT, RESPONSE, model="m1")
        cache.set("other question", "other answer", model="m2")
        deleted = cache.delete(model="m1")
        assert deleted == 1

    def test_delete_by_tag(self, cache):
        cache.set(PROMPT, RESPONSE, tags=["legal"])
        cache.set("other", "answer", tags=["general"])
        deleted = cache.delete(tags=["legal"])
        assert deleted == 1

    def test_clear(self, cache):
        cache.set(PROMPT, RESPONSE)
        cache.set("other", "answer")
        cache.clear()
        _, m = cache.get(PROMPT)
        assert m == MatchType.MISS

    def test_list_entries(self, cache):
        cache.set(PROMPT, RESPONSE)
        entries = cache.list_entries()
        assert len(entries) == 1
        assert isinstance(entries[0], CacheEntry)

    def test_list_entries_limit(self, cache):
        for i in range(5):
            cache.set(f"prompt {i}", f"response {i}")
        entries = cache.list_entries(limit=3)
        assert len(entries) == 3

    def test_context_manager(self, tmp_path):
        with LLMCache(db_path=str(tmp_path / "ctx.db")) as c:
            c.set(PROMPT, RESPONSE)
            r, m = c.get(PROMPT)
            assert m == MatchType.EXACT


class TestStats:
    def test_initial_stats(self, cache):
        s = cache.stats()
        assert isinstance(s, CacheStats)
        assert s.total_entries == 0
        assert s.total_hits == 0

    def test_stats_after_hit(self, cache):
        cache.set(PROMPT, RESPONSE)
        cache.get(PROMPT)
        s = cache.stats()
        assert s.exact_hits >= 1
        assert s.total_hits >= 1

    def test_stats_after_miss(self, cache):
        cache.get("unknown prompt xyz")
        s = cache.stats()
        assert s.misses >= 1

    def test_hit_rate(self, cache):
        cache.set(PROMPT, RESPONSE)
        cache.get(PROMPT)
        cache.get("miss 1")
        s = cache.stats()
        assert 0 < s.hit_rate <= 1.0

    def test_tokens_saved_positive(self, cache):
        cache.set(PROMPT, RESPONSE)
        cache.get(PROMPT)
        s = cache.stats()
        assert s.estimated_tokens_saved > 0

    def test_cost_savings_estimate(self, cache):
        cache.set(PROMPT, RESPONSE * 1000)
        cache.get(PROMPT)
        s = cache.stats()
        assert s.cost_savings_estimate >= 0.0

    def test_stats_repr(self, cache):
        assert "CacheStats" in repr(cache.stats())

    def test_entry_count_tracks(self, cache):
        for i in range(5):
            cache.set(f"p{i}", f"r{i}")
        assert cache.stats().total_entries == 5


class TestTTL:
    def test_ttl_expires_entries(self, tmp_path):
        c = LLMCache(db_path=str(tmp_path / "ttl.db"), ttl_seconds=1)
        c.set(PROMPT, RESPONSE)
        _, m = c.get(PROMPT)
        assert m == MatchType.EXACT
        time.sleep(1.1)
        _, m = c.get(PROMPT)
        assert m == MatchType.MISS
        c.close()


class TestMaxEntries:
    def test_evicts_when_full(self, tmp_path):
        c = LLMCache(db_path=str(tmp_path / "max.db"), max_entries=3)
        for i in range(5):
            c.set(f"prompt {i}", f"response {i}")
        assert c.stats().total_entries <= 3
        c.close()
