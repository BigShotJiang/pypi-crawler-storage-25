"""
LLMCache — SQLite-backed LLM response cache.

Two layers:
  1. Exact match  — SHA-256 hash of normalised prompt. O(1) lookup.
  2. Fuzzy match  — normalised token overlap similarity. No embeddings needed.

Both layers use a single SQLite database file. No Redis, no vector store, no server.
"""

from __future__ import annotations

import functools
import hashlib
import json
import re
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from llm_cache.models import CacheEntry, CacheStats, MatchType

DEFAULT_DB = ".llm_cache.db"
_SCHEMA = """
CREATE TABLE IF NOT EXISTS cache (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    prompt_hash  TEXT NOT NULL,
    prompt_norm  TEXT NOT NULL,
    prompt_raw   TEXT NOT NULL,
    response     TEXT NOT NULL,
    model        TEXT NOT NULL DEFAULT '',
    hit_count    INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL,
    last_hit_at  TEXT,
    tags         TEXT NOT NULL DEFAULT '[]',
    metadata     TEXT NOT NULL DEFAULT '{}'
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_hash ON cache(prompt_hash);
CREATE INDEX IF NOT EXISTS idx_model ON cache(model);

CREATE TABLE IF NOT EXISTS stats (
    key   TEXT PRIMARY KEY,
    value INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO stats VALUES ('total_hits', 0);
INSERT OR IGNORE INTO stats VALUES ('exact_hits', 0);
INSERT OR IGNORE INTO stats VALUES ('fuzzy_hits', 0);
INSERT OR IGNORE INTO stats VALUES ('misses', 0);
INSERT OR IGNORE INTO stats VALUES ('tokens_saved', 0);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalise(text: str) -> str:
    """Normalise a prompt for comparison: lowercase, collapse whitespace, strip punctuation."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _hash(normalised: str) -> str:
    return hashlib.sha256(normalised.encode()).hexdigest()


def _token_overlap(a: str, b: str) -> float:
    """Jaccard similarity on word tokens."""
    ta = set(a.split())
    tb = set(b.split())
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


class LLMCache:
    """
    SQLite-backed LLM response cache with exact + fuzzy matching.

    Example:
        cache = LLMCache("my_app.db", fuzzy_threshold=0.85)

        @cache.cached(model="claude-opus-4-5")
        def call_llm(prompt: str) -> str:
            return client.messages.create(...).content[0].text

        # Or use directly:
        result = cache.get("What is RAG?")
        if result is None:
            answer = call_api("What is RAG?")
            cache.set("What is RAG?", answer)
    """

    def __init__(
        self,
        db_path: str = DEFAULT_DB,
        fuzzy_threshold: float = 0.85,
        ttl_seconds: int | None = None,
        max_entries: int | None = None,
    ) -> None:
        """
        Args:
            db_path:         Path to SQLite database file
            fuzzy_threshold: Minimum token overlap for a fuzzy cache hit (0–1)
            ttl_seconds:     Auto-expire entries older than this (None = never)
            max_entries:     Evict oldest entries when cache exceeds this size
        """
        self.db_path = Path(db_path)
        self.fuzzy_threshold = fuzzy_threshold
        self.ttl_seconds = ttl_seconds
        self.max_entries = max_entries
        self._conn: sqlite3.Connection | None = None
        self._init_db()

    # ── Database ───────────────────────────────────────────────

    def _init_db(self) -> None:
        conn = self._get_conn()
        conn.executescript(_SCHEMA)
        conn.commit()

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
        return self._conn

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self) -> "LLMCache":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ── Core get/set ───────────────────────────────────────────

    def get(
        self,
        prompt: str,
        model: str = "",
        use_fuzzy: bool = True,
    ) -> tuple[str | None, MatchType]:
        """
        Look up a prompt in the cache.

        Args:
            prompt:    The LLM prompt to look up
            model:     Filter by model name (empty = any model)
            use_fuzzy: Whether to try fuzzy matching after exact miss

        Returns:
            Tuple of (response, MatchType).
            response is None on MISS.

        Example:
            response, match = cache.get("What is RAG?")
            if match == MatchType.MISS:
                response = call_api("What is RAG?")
                cache.set("What is RAG?", response)
        """
        # Expire stale entries first
        if self.ttl_seconds:
            self._expire_stale()

        norm = _normalise(prompt)
        h = _hash(norm)
        conn = self._get_conn()

        # ── Layer 1: exact match ───────────────────────────────
        query = "SELECT * FROM cache WHERE prompt_hash = ?"
        params: list[Any] = [h]
        if model:
            query += " AND (model = ? OR model = '')"
            params.append(model)

        row = conn.execute(query, params).fetchone()
        if row:
            self._record_hit(conn, row["id"], MatchType.EXACT, row["response"])
            return row["response"], MatchType.EXACT

        if not use_fuzzy:
            self._increment(conn, "misses")
            conn.commit()
            return None, MatchType.MISS

        # ── Layer 2: fuzzy match ───────────────────────────────
        model_filter = "WHERE model = ?" if model else ""
        rows = conn.execute(
            f"SELECT id, prompt_norm, response FROM cache {model_filter}",
            [model] if model else [],
        ).fetchall()

        best_score = 0.0
        best_row = None
        for r in rows:
            score = _token_overlap(norm, r["prompt_norm"])
            if score > best_score:
                best_score = score
                best_row = r

        if best_row and best_score >= self.fuzzy_threshold:
            self._record_hit(conn, best_row["id"], MatchType.FUZZY, best_row["response"])
            return best_row["response"], MatchType.FUZZY

        self._increment(conn, "misses")
        conn.commit()
        return None, MatchType.MISS

    def set(
        self,
        prompt: str,
        response: str,
        model: str = "",
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> CacheEntry:
        """
        Store a prompt-response pair in the cache.

        Args:
            prompt:   The LLM prompt
            response: The LLM response to cache
            model:    Model name (e.g. 'claude-opus-4-5')
            tags:     Optional tags for filtering/deletion
            metadata: Any additional metadata to store

        Returns:
            The stored CacheEntry
        """
        norm = _normalise(prompt)
        h = _hash(norm)
        now = _now()
        conn = self._get_conn()

        conn.execute(
            """INSERT OR REPLACE INTO cache
               (prompt_hash, prompt_norm, prompt_raw, response, model,
                hit_count, created_at, last_hit_at, tags, metadata)
               VALUES (?, ?, ?, ?, ?, 0, ?, NULL, ?, ?)""",
            (
                h,
                norm,
                prompt,
                response,
                model,
                now,
                json.dumps(tags or []),
                json.dumps(metadata or {}),
            ),
        )
        # Track tokens saved (rough estimate: response tokens)
        tokens_approx = max(1, len(response) // 4)
        conn.execute(
            "UPDATE stats SET value = value + ? WHERE key = 'tokens_saved'", [tokens_approx]
        )
        conn.commit()

        if self.max_entries:
            self._evict_oldest(conn)

        return CacheEntry(
            prompt=prompt,
            response=response,
            model=model,
            tags=tags or [],
            metadata=metadata or {},
            created_at=now,
        )

    def cached(
        self,
        model: str = "",
        use_fuzzy: bool = True,
        tags: list[str] | None = None,
    ) -> Callable:
        """
        Decorator that wraps an LLM call function with caching.

        The decorated function must accept `prompt` as its first argument
        and return a string.

        Example:
            @cache.cached(model="claude-opus-4-5")
            def ask(prompt: str) -> str:
                return client.messages.create(
                    model="claude-opus-4-5",
                    messages=[{"role": "user", "content": prompt}],
                ).content[0].text

            ask("What is RAG?")   # API call on first request
            ask("What is RAG?")   # cache hit, no API call
        """

        def decorator(fn: Callable) -> Callable:
            @functools.wraps(fn)
            def wrapper(prompt: str, *args: Any, **kwargs: Any) -> str:
                response, match = self.get(prompt, model=model, use_fuzzy=use_fuzzy)
                if match != MatchType.MISS:
                    return response  # type: ignore[return-value]
                result = fn(prompt, *args, **kwargs)
                self.set(prompt, str(result), model=model, tags=tags)
                return result

            return wrapper

        return decorator

    # ── Management ─────────────────────────────────────────────

    def delete(
        self,
        prompt: str | None = None,
        model: str | None = None,
        tags: list[str] | None = None,
        older_than_seconds: int | None = None,
    ) -> int:
        """
        Delete cache entries. Returns number of rows deleted.

        Args:
            prompt:             Delete specific prompt (exact match)
            model:              Delete all entries for a model
            tags:               Delete entries with ANY of these tags
            older_than_seconds: Delete entries older than N seconds
        """
        conn = self._get_conn()
        conditions = []
        params: list[Any] = []

        if prompt:
            norm = _normalise(prompt)
            conditions.append("prompt_hash = ?")
            params.append(_hash(norm))
        if model:
            conditions.append("model = ?")
            params.append(model)
        if older_than_seconds:
            cutoff = datetime.fromtimestamp(
                time.time() - older_than_seconds, tz=timezone.utc
            ).isoformat()
            conditions.append("created_at < ?")
            params.append(cutoff)

        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""

        if tags:
            # SQLite JSON: filter entries that contain any of the given tags
            tag_conditions = " OR ".join("json_each.value = ?" for _ in tags)
            query = f"""
                DELETE FROM cache WHERE id IN (
                    SELECT cache.id FROM cache, json_each(cache.tags)
                    WHERE ({tag_conditions})
                    {(' AND ' + ' AND '.join(conditions)) if conditions else ''}
                )
            """
            params = list(tags) + params
        else:
            query = f"DELETE FROM cache {where}"

        cursor = conn.execute(query, params)
        conn.commit()
        return cursor.rowcount

    def clear(self) -> None:
        """Remove all cache entries and reset stats."""
        conn = self._get_conn()
        conn.execute("DELETE FROM cache")
        conn.execute("UPDATE stats SET value = 0")
        conn.commit()

    def stats(self) -> CacheStats:
        """Return cache statistics."""
        conn = self._get_conn()
        rows = {
            r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM stats").fetchall()
        }
        entry_count = conn.execute("SELECT COUNT(*) FROM cache").fetchone()[0]
        db_size = self.db_path.stat().st_size if self.db_path.exists() else 0

        return CacheStats(
            total_entries=entry_count,
            total_hits=rows.get("exact_hits", 0) + rows.get("fuzzy_hits", 0),
            exact_hits=rows.get("exact_hits", 0),
            fuzzy_hits=rows.get("fuzzy_hits", 0),
            misses=rows.get("misses", 0),
            estimated_tokens_saved=rows.get("tokens_saved", 0),
            size_bytes=db_size,
        )

    def list_entries(
        self,
        model: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[CacheEntry]:
        """List cache entries, most recently created first."""
        conn = self._get_conn()
        query = "SELECT * FROM cache"
        params: list[Any] = []
        if model:
            query += " WHERE model = ?"
            params.append(model)
        query += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        params += [limit, offset]

        rows = conn.execute(query, params).fetchall()
        return [
            CacheEntry(
                prompt=r["prompt_raw"],
                response=r["response"],
                model=r["model"],
                hit_count=r["hit_count"],
                created_at=r["created_at"],
                last_hit_at=r["last_hit_at"] or "",
                tags=json.loads(r["tags"]),
                metadata=json.loads(r["metadata"]),
            )
            for r in rows
        ]

    # ── Private helpers ────────────────────────────────────────

    def _record_hit(
        self, conn: sqlite3.Connection, row_id: int, match_type: MatchType, response: str
    ) -> None:
        conn.execute(
            "UPDATE cache SET hit_count = hit_count + 1, last_hit_at = ? WHERE id = ?",
            [_now(), row_id],
        )
        self._increment(conn, "total_hits")
        self._increment(conn, f"{match_type.value}_hits")
        tokens_approx = max(1, len(response) // 4)
        conn.execute(
            "UPDATE stats SET value = value + ? WHERE key = 'tokens_saved'",
            [tokens_approx],
        )
        conn.commit()

    def _increment(self, conn: sqlite3.Connection, key: str, by: int = 1) -> None:
        conn.execute("UPDATE stats SET value = value + ? WHERE key = ?", [by, key])

    def _expire_stale(self) -> None:
        if not self.ttl_seconds:
            return
        conn = self._get_conn()
        cutoff = datetime.fromtimestamp(time.time() - self.ttl_seconds, tz=timezone.utc).isoformat()
        conn.execute("DELETE FROM cache WHERE created_at < ?", [cutoff])
        conn.commit()

    def _evict_oldest(self, conn: sqlite3.Connection) -> None:
        if not self.max_entries:
            return
        count = conn.execute("SELECT COUNT(*) FROM cache").fetchone()[0]
        if count > self.max_entries:
            excess = count - self.max_entries
            conn.execute(
                """DELETE FROM cache WHERE id IN (
                    SELECT id FROM cache ORDER BY last_hit_at ASC, created_at ASC LIMIT ?
                )""",
                [excess],
            )
            conn.commit()
