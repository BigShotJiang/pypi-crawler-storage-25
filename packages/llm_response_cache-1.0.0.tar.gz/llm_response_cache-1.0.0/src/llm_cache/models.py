"""Data models for llm-cache."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class MatchType(str, Enum):
    EXACT = "exact"  # identical prompt
    FUZZY = "fuzzy"  # normalised near-match
    MISS = "miss"  # not cached


@dataclass
class CacheEntry:
    prompt: str
    response: str
    model: str = ""
    hit_count: int = 0
    created_at: str = ""
    last_hit_at: str = ""
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        return (
            f"CacheEntry(model={self.model!r}, hits={self.hit_count}, prompt={self.prompt[:40]!r})"
        )


@dataclass
class CacheStats:
    total_entries: int
    total_hits: int
    exact_hits: int
    fuzzy_hits: int
    misses: int
    estimated_tokens_saved: int
    size_bytes: int

    @property
    def hit_rate(self) -> float:
        total = self.total_hits + self.misses
        return round(self.total_hits / total, 4) if total > 0 else 0.0

    @property
    def cost_savings_estimate(self) -> float:
        """Rough estimate in USD at $3 per 1M tokens (Sonnet pricing)."""
        return round(self.estimated_tokens_saved / 1_000_000 * 3.0, 4)

    def __repr__(self) -> str:
        return (
            f"CacheStats(entries={self.total_entries}, "
            f"hit_rate={self.hit_rate:.0%}, "
            f"tokens_saved≈{self.estimated_tokens_saved:,})"
        )
