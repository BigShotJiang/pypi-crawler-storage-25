"""
llm-cache
=========
SQLite-backed LLM response cache. Exact match + fuzzy match.
Decorator API. Zero mandatory server dependencies.

Quick start:
    from llm_cache import LLMCache

    cache = LLMCache()  # stores in .llm_cache.db

    # Decorator — wraps any LLM call function
    @cache.cached
    def ask(prompt: str) -> str:
        return anthropic_client.messages.create(...).content[0].text

    ask("What is RAG?")   # hits API
    ask("What is RAG?")   # served from cache instantly

    # Direct get/set
    cached = cache.get("What is RAG?")
    cache.set("What is RAG?", "RAG stands for...")

    # Stats
    print(cache.stats())
"""

from llm_cache.cache import LLMCache
from llm_cache.models import CacheEntry, CacheStats, MatchType

__version__ = "1.0.0"
__author__ = "Linda Oraegbunam"
__all__ = ["LLMCache", "CacheEntry", "CacheStats", "MatchType"]
