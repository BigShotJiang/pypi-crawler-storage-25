"""Tests for the `agentberlin report` CLI subcommand group.

Covers manifest-shape validation, kind enforcement, id-writeback, and URL
routing across `apply`, `publish`, `get`, and `list`. HTTP calls are stubbed
via the `responses` library so tests don't hit a real backend.
"""

import io
import json
import tarfile
from pathlib import Path
from typing import Any

import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _write_manifest(tmp_path: Path, data: dict[str, Any], name: str = "manifest.json") -> Path:
    path = tmp_path / name
    path.write_text(json.dumps(data))
    return path


def _read_manifest(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def _write(path: Path, text: str) -> Path:
    path.write_text(text)
    return path


def _make_bundle_dir(
    root: Path,
    pages: list[dict[str, Any]],
    default_page: str | None = None,
    add_data: bool = False,
    add_spec: bool = False,
) -> Path:
    """Build a valid report bundle directory at root/. Returns root."""
    root.mkdir(parents=True, exist_ok=True)
    structure: dict[str, Any] = {"version": 1, "pages": pages}
    if default_page is not None:
        structure["default_page"] = default_page
    (root / "structure.json").write_text(json.dumps(structure))
    for page in pages:
        slug = page["slug"]
        page_dir = root / slug
        page_dir.mkdir(parents=True, exist_ok=True)
        (page_dir / "index.html").write_text(f"<html><body>{slug}</body></html>")
        if add_spec:
            (page_dir / "spec.json").write_text('{"version":1}')
        if add_data:
            (page_dir / "data.json").write_text('{}')
    return root


def _read_uploaded_tarball(call_body: bytes) -> dict[str, bytes]:
    """Extract the tarball bytes embedded in a multipart body and return
    a name->contents map. Naive but sufficient for tests — finds the file
    part between boundary markers and parses it as tar.gz."""
    # The multipart body has the bundle bytes in the `file` field. Locate
    # them between the field's Content-Type header and the next boundary.
    marker = b"\r\n\r\n"
    idx = call_body.find(b'name="file"')
    if idx < 0:
        raise AssertionError("multipart body has no 'file' field")
    payload_start = call_body.find(marker, idx)
    if payload_start < 0:
        raise AssertionError("could not find file payload start")
    payload_start += len(marker)
    # Find the next boundary (lines starting with --).
    boundary_idx = call_body.find(b"\r\n--", payload_start)
    if boundary_idx < 0:
        boundary_idx = len(call_body)
    tar_bytes = call_body[payload_start:boundary_idx]
    out: dict[str, bytes] = {}
    with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode="r:gz") as tf:
        for member in tf.getmembers():
            if member.isreg():
                f = tf.extractfile(member)
                if f is not None:
                    out[member.name] = f.read()
    return out


# ---------------------------------------------------------------------------
# report apply
# ---------------------------------------------------------------------------


class TestReportApply:
    @responses.activate
    def test_apply_without_id_creates_and_writes_back(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "slug": "audit",
                "name": "Audit",
                "description": "Weekly",
                "details": "Workflow X produces { rows: [...] }; render as a table.",
            },
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports",
            json={
                "success": True,
                "report_id": "rpt_abc",
            },
            status=202,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert "rpt_abc" in result.output
        assert "metadata applied" in result.output.lower()
        assert _read_manifest(manifest)["id"] == "rpt_abc"

        body = json.loads(responses.calls[0].request.body)
        assert body == {
            "slug": "audit",
            "project_domain": "example.com",
            "title": "Audit",
            "description": "Weekly",
            "details": "Workflow X produces { rows: [...] }; render as a table.",
        }

    @responses.activate
    def test_apply_with_id_patches_with_details(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "kind": "report",
                "id": "rpt_abc",
                "slug": "audit",
                "details": "Workflow Y now produces a score field; surface it as a dial.",
            },
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={"success": True, "report_id": "rpt_abc"},
            status=202,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "metadata applied" in result.output.lower()
        body = json.loads(responses.calls[0].request.body)
        assert body["details"] == "Workflow Y now produces a score field; surface it as a dial."
        assert body["project_domain"] == "example.com"
        assert "slug" not in body

    def test_apply_first_time_requires_details(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"kind": "report", "slug": "audit", "name": "Audit"}
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "details" in result.output.lower()

    def test_apply_rejects_manifest_without_slug(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"kind": "report", "details": "..."})
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "slug" in result.output.lower()

    def test_apply_rejects_manifest_with_wrong_kind(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"kind": "workflow", "name": "X", "details": "..."}
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "kind" in result.output.lower()

    @responses.activate
    def test_apply_surfaces_409_duplicate(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {"kind": "report", "slug": "audit", "details": "x"},
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports",
            json={"error": "Report with slug 'audit' already exists. The manifest needs an 'id' to update an existing report."},
            status=409,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report",
                "apply",
                "-m",
                str(manifest),
                "--project-domain",
                "example.com",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "already exists" in result.output


# ---------------------------------------------------------------------------
# report publish (bundle)
# ---------------------------------------------------------------------------


class TestReportPublish:
    @responses.activate
    def test_publish_uploads_tarball_of_dir(self, tmp_path: Path) -> None:
        bundle_dir = _make_bundle_dir(
            tmp_path / "audit",
            pages=[
                {"slug": "overview", "title": "Overview"},
                {"slug": "keywords", "title": "Keywords"},
            ],
            default_page="overview",
            add_data=True,
            add_spec=True,
        )
        responses.add(
            responses.PUT,
            f"{DEFAULT_BASE_URL}/reports/audit/bundle",
            json={"success": True, "report_id": "rpt_abc", "url": "https://cdn/x"},
            status=200,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish", "audit",
                "--dir", str(bundle_dir),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "2 page" in result.output

        files = _read_uploaded_tarball(responses.calls[0].request.body)
        assert "structure.json" in files
        assert "overview/index.html" in files
        assert "keywords/index.html" in files
        assert "overview/data.json" in files
        assert "overview/spec.json" in files
        # manifest.json must not be in the uploaded bundle.
        assert "manifest.json" not in files

    def test_publish_rejects_missing_structure_json(self, tmp_path: Path) -> None:
        bundle_dir = tmp_path / "audit"
        bundle_dir.mkdir()
        (bundle_dir / "overview").mkdir()
        (bundle_dir / "overview" / "index.html").write_text("<html></html>")
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish", "audit",
                "--dir", str(bundle_dir),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "structure.json" in result.output

    def test_publish_rejects_missing_page_index_html(self, tmp_path: Path) -> None:
        bundle_dir = tmp_path / "audit"
        bundle_dir.mkdir()
        (bundle_dir / "structure.json").write_text(
            json.dumps({"version": 1, "pages": [{"slug": "overview"}]})
        )
        (bundle_dir / "overview").mkdir()
        # No index.html
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish", "audit",
                "--dir", str(bundle_dir),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "index.html" in result.output

    def test_publish_rejects_orphan_directory(self, tmp_path: Path) -> None:
        bundle_dir = _make_bundle_dir(
            tmp_path / "audit",
            pages=[{"slug": "overview"}],
        )
        # Add an orphan page directory not declared in structure.json.
        (bundle_dir / "stale").mkdir()
        (bundle_dir / "stale" / "index.html").write_text("<html></html>")
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish", "audit",
                "--dir", str(bundle_dir),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "stale" in result.output

    def test_publish_rejects_invalid_default_page(self, tmp_path: Path) -> None:
        bundle_dir = tmp_path / "audit"
        bundle_dir.mkdir()
        (bundle_dir / "structure.json").write_text(
            json.dumps(
                {
                    "version": 1,
                    "default_page": "missing",
                    "pages": [{"slug": "overview"}],
                }
            )
        )
        (bundle_dir / "overview").mkdir()
        (bundle_dir / "overview" / "index.html").write_text("<html></html>")
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish", "audit",
                "--dir", str(bundle_dir),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "default_page" in result.output

    def test_publish_rejects_invalid_slug(self, tmp_path: Path) -> None:
        bundle_dir = _make_bundle_dir(tmp_path / "audit", pages=[{"slug": "overview"}])
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish", "Bad Slug",
                "--dir", str(bundle_dir),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "slug" in result.output.lower()


# ---------------------------------------------------------------------------
# report list / get
# ---------------------------------------------------------------------------


class TestReportList:
    @responses.activate
    def test_list_renders_markdown(self, tmp_path: Path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/list",
            json={
                "reports": [
                    {
                        "id": "rpt_abc",
                        "slug": "audit",
                        "name": "Audit Report",
                        "updated_at": "2025-04-01T00:00:00Z",
                    },
                    {"id": "rpt_def", "slug": "weekly"},
                ]
            },
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "list", "--project-domain", "example.com", "--token", "t"],
        )
        assert result.exit_code == 0, result.output
        assert "audit" in result.output
        assert "weekly" in result.output
        assert "Audit Report" in result.output

        body = json.loads(responses.calls[0].request.body)
        assert body == {"project_domain": "example.com"}


def _build_bundle_tarball(files: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for name, body in files.items():
            data = body.encode("utf-8")
            info = tarfile.TarInfo(name=name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
    return buf.getvalue()


class TestReportGet:
    @responses.activate
    def test_get_extracts_tarball(self, tmp_path: Path) -> None:
        tarball = _build_bundle_tarball(
            {
                "manifest.json": json.dumps({"kind": "report", "slug": "audit"}),
                "structure.json": json.dumps(
                    {"version": 1, "pages": [{"slug": "overview"}]}
                ),
                "overview/index.html": "<html></html>",
                "overview/data.json": "{}",
            }
        )
        responses.add(
            responses.GET,
            f"{DEFAULT_BASE_URL}/reports/audit/bundle",
            body=tarball,
            content_type="application/gzip",
            status=200,
        )
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                main,
                [
                    "report", "get", "audit",
                    "--project-domain", "example.com",
                    "--token", "t",
                ],
            )
            assert result.exit_code == 0, result.output
            target = Path("reports") / "audit"
            assert (target / "manifest.json").is_file()
            assert (target / "structure.json").is_file()
            assert (target / "overview" / "index.html").read_text() == "<html></html>"
            assert (target / "overview" / "data.json").read_text() == "{}"

    @responses.activate
    def test_get_scaffold_when_no_published_bundle(self, tmp_path: Path) -> None:
        """A freshly-applied row returns a scaffold tarball: manifest + empty
        structure.json. Extraction should succeed without any page files."""
        tarball = _build_bundle_tarball(
            {
                "manifest.json": json.dumps({"kind": "report", "slug": "audit"}),
                "structure.json": json.dumps({"version": 1, "pages": []}),
            }
        )
        responses.add(
            responses.GET,
            f"{DEFAULT_BASE_URL}/reports/audit/bundle",
            body=tarball,
            content_type="application/gzip",
            status=200,
        )
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                main,
                [
                    "report", "get", "audit",
                    "--project-domain", "example.com",
                    "--token", "t",
                ],
            )
            assert result.exit_code == 0, result.output
            target = Path("reports") / "audit"
            assert (target / "structure.json").is_file()
            assert not (target / "overview").exists()

    @responses.activate
    def test_get_404_friendly_error(self, tmp_path: Path) -> None:
        responses.add(
            responses.GET,
            f"{DEFAULT_BASE_URL}/reports/missing/bundle",
            json={"error": "Report not found"},
            status=404,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            ["report", "get", "missing", "--project-domain", "example.com", "--token", "t"],
        )
        assert result.exit_code != 0
        assert "missing" in result.output

    @responses.activate
    def test_get_passes_project_domain_as_query_param(self, tmp_path: Path) -> None:
        """The new endpoint accepts project_domain on the query string."""
        tarball = _build_bundle_tarball(
            {"manifest.json": "{}", "structure.json": json.dumps({"version": 1, "pages": []})}
        )
        responses.add(
            responses.GET,
            f"{DEFAULT_BASE_URL}/reports/audit/bundle",
            body=tarball,
            content_type="application/gzip",
            status=200,
        )
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(
                main,
                [
                    "report", "get", "audit",
                    "--project-domain", "example.com",
                    "--token", "t",
                ],
            )
            assert result.exit_code == 0, result.output
            call = responses.calls[0]
            assert "project_domain=example.com" in call.request.url
