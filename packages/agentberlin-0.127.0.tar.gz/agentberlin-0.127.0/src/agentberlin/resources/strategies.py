"""Strategies resource for Agent Berlin SDK.

Read-only access to the curated SEO strategy catalog. Strategies live in the
backend's `strategies` table; the SDK exposes them so agents and humans can
list available strategies and fetch a single strategy's full body.
"""

from typing import Any, Dict, List, Optional

from .._http import HTTPClient
from ..models.strategies import Strategy, StrategyListResponse


class StrategiesResource:
    """Resource for fetching SEO strategies.

    Example:
        all_strategies = client.strategies.list()
        for s in all_strategies:
            print(f"{s.id}: {s.name}")

        # Project-scoped shortlist — only strategies that fit this project's
        # connected integrations and brand profile.
        fit = client.strategies.list(shortlist=True, project_domain="acme.test")

        s = client.strategies.get("keyword-rank-tracking")
        print(s.cadence)
        print(s.details)
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(
        self,
        *,
        shortlist: bool = False,
        project_domain: Optional[str] = None,
    ) -> List[Strategy]:
        """Return strategies from the catalog, ordered by ID.

        By default returns every strategy. Pass ``shortlist=True`` together
        with ``project_domain`` to receive only strategies whose required
        capabilities and applicability match the project.
        """
        body: Dict[str, Any] = {}
        if shortlist:
            if not project_domain:
                raise ValueError("project_domain is required when shortlist=True")
            body = {"shortlist": True, "project_domain": project_domain}
        data = self._http.post("/strategies/list", json=body)
        return StrategyListResponse.model_validate(data).strategies

    def get(self, id: str) -> Strategy:
        """Fetch a single strategy by ID.

        Raises:
            AgentBerlinNotFoundError: If the ID does not match any strategy.
        """
        data = self._http.post("/strategies/get", json={"id": id})
        return Strategy.model_validate(data)
