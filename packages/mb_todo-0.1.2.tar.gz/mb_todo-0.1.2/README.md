# mb-todo

Personal todo manager with CLI and TUI interfaces. Local SQLite storage, `--json` flag for scripting.

## Install

```bash
uv tool install mb-todo
```

## Quick Start

```bash
mb-todo add "Buy groceries" -p personal -P high
mb-todo add "Fix login bug" -p work -t backend
mb-todo list
mb-todo list -p work
mb-todo close 1
mb-todo tui
```

## JSON Mode

All commands support `--json` for machine-readable output:

```json
{"ok": true, "data": {...}}
{"ok": false, "error": "CODE", "message": "..."}
```

## Documentation

- [CLI Architecture](docs/cli-architecture.md) — project structure and patterns (from mm-clikit)
- [Data Model](docs/data-model.md) — schema design decisions
- [Configuration](docs/configuration.md) — config.toml, TUI columns, filter persistence
