"""Core business logic."""
