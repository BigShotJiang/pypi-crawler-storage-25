"""Composition root — holds config, database, and service layer."""

from mb_todo.config import Config
from mb_todo.core.db import Db
from mb_todo.core.service import Service


class Core:
    """Application composition root.

    Creates and owns all shared resources (database, services).
    Passed to CLI commands via ``CoreContext``.
    """

    def __init__(self, config: Config) -> None:
        """Initialize core with config, database, and service layer."""
        self.config = config  # Application configuration
        self.db = Db(config.db_path)  # SQLite database connection
        self.service = Service(self.db, config)  # Business logic layer

    def close(self) -> None:
        """Release resources."""
        self.db.close()
