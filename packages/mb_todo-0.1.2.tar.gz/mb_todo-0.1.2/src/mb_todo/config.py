"""Centralized application configuration."""

import tomllib
from pathlib import Path
from typing import ClassVar, Literal

import tomli_w
from mm_clikit import BaseDataDirConfig
from pydantic import BaseModel, ConfigDict, Field, computed_field

from mb_todo.core.db import Priority

TuiColumn = Literal["status", "priority", "project", "tags", "age", "body"]
"""Valid optional column names for the TUI table."""

StatusFilter = Literal["open", "closed"]
"""Valid status filter values for the TUI. None means all."""


class TuiFilters(BaseModel):
    """Persisted TUI filter state."""

    model_config = ConfigDict(frozen=True)

    project: str | None = None  # Active project filter, None = all
    status: StatusFilter | None = "open"  # Status filter: open/closed or None = all
    priority: Priority | None = None  # Priority filter: low/medium/high or None = all
    tag: str | None = None  # Tag filter: exact tag string or None = all


class TuiConfig(BaseModel):
    """TUI-specific configuration."""

    model_config = ConfigDict(frozen=True)

    hide_columns: list[TuiColumn] = []  # Force-hidden columns (overrides auto-visibility)
    filters: TuiFilters = Field(default_factory=TuiFilters)  # Persisted filter state


class Config(BaseDataDirConfig):
    """Application-wide configuration."""

    app_name: ClassVar[str] = "mb-todo"

    tui: TuiConfig = Field(default_factory=TuiConfig)  # TUI display settings

    @computed_field(description="SQLite database file")
    @property
    def db_path(self) -> Path:
        """SQLite database file."""
        return self.data_dir / "todo.db"

    @computed_field(description="Rotating log file")
    @property
    def log_path(self) -> Path:
        """Rotating log file."""
        return self.data_dir / "todo.log"

    def save_tui_filters(
        self, *, project: str | None, status: StatusFilter | None, priority: Priority | None, tag: str | None
    ) -> None:
        """Write current filter state back to config.toml, preserving other settings."""
        config_file = self.data_dir / "config.toml"
        raw: dict[str, object] = {}
        if config_file.is_file():
            try:
                raw = tomllib.loads(config_file.read_text())
            except tomllib.TOMLDecodeError:
                return  # Don't overwrite a file we can't parse

        tui_section: dict[str, object] = raw.setdefault("tui", {})  # type: ignore[assignment]

        filters: dict[str, object] = {}
        if status is not None:
            filters["status"] = status
        if project is not None:
            filters["project"] = project
        if priority is not None:
            filters["priority"] = priority
        if tag is not None:
            filters["tag"] = tag
        tui_section["filters"] = filters

        config_file.write_text(tomli_w.dumps(raw))

    @staticmethod
    def build(data_dir: Path | None = None) -> Config:
        """Build a Config from CLI arg / env var / default, then overlay config.toml if present."""
        resolved = Config.resolve_data_dir(data_dir)

        # Load config.toml overlay
        tui = TuiConfig()
        config_file = resolved / "config.toml"
        if config_file.is_file():
            try:
                raw = tomllib.loads(config_file.read_text())
                if "tui" in raw:
                    tui = TuiConfig(**raw["tui"])
            except (tomllib.TOMLDecodeError, ValueError) as e:
                msg = f"Invalid config file {config_file}: {e}"
                raise SystemExit(msg) from e

        return Config(data_dir=resolved, tui=tui)
