"""Close one or more todos."""

import logging
from typing import Annotated

import typer
from mm_clikit import CliError

from mb_todo.cli.context import use_context

logger = logging.getLogger(__name__)


def close(
    ctx: typer.Context,
    todo_ids: Annotated[list[int], typer.Argument(help="Todo ID(s) to close.")],
) -> None:
    """Close one or more todos."""
    app = use_context(ctx)

    # Single ID — preserve original behavior and JSON contract
    if len(todo_ids) == 1:
        todo_id = todo_ids[0]
        todo = app.core.service.get_todo(todo_id)
        app.core.service.close_todo(todo_id)
        app.out.print_todo_closed(todo_id, todo.title)
        logger.info("Todo closed id=%d", todo_id)
        return

    # Multiple IDs — best-effort
    results: list[tuple[int, str]] = []
    errors: list[tuple[int, str, str]] = []
    for todo_id in todo_ids:
        try:
            todo = app.core.service.get_todo(todo_id)
            app.core.service.close_todo(todo_id)
            results.append((todo_id, todo.title))
            logger.info("Todo closed id=%d", todo_id)
        except CliError as e:
            errors.append((todo_id, e.code, str(e)))
            logger.warning("Failed to close todo id=%d: [%s] %s", todo_id, e.code, e)
    app.out.print_todos_closed(results, errors)
    if errors:
        raise typer.Exit(1)
