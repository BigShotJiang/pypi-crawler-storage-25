"""Show a single todo."""

from typing import Annotated

import typer

from mb_todo.cli.context import use_context


def show(
    ctx: typer.Context,
    todo_id: Annotated[int, typer.Argument(help="Todo ID.")],
) -> None:
    """Show a single todo with all fields."""
    app = use_context(ctx)
    todo = app.core.service.get_todo(todo_id)
    app.out.print_todo(todo)
