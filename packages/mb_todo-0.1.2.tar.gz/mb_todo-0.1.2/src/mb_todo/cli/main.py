"""CLI app definition and initialization."""

from pathlib import Path
from typing import Annotated

import typer
from mm_clikit import CoreContext, TyperPlus, setup_logging

from mb_todo.cli.commands.add import add
from mb_todo.cli.commands.close import close
from mb_todo.cli.commands.delete import delete
from mb_todo.cli.commands.edit import edit
from mb_todo.cli.commands.list import list_
from mb_todo.cli.commands.project import project_app
from mb_todo.cli.commands.reopen import reopen
from mb_todo.cli.commands.show import show
from mb_todo.cli.output import Output
from mb_todo.config import Config
from mb_todo.core.core import Core
from mb_todo.tui.app import TodoApp

app = TyperPlus(package_name="mb-todo", no_args_is_help=False)
"""Root CLI application instance."""


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    *,
    data_dir: Annotated[
        Path | None,
        typer.Option("--data-dir", help="Data directory. Env: MB_TODO_DATA_DIR."),
    ] = None,
) -> None:
    """CLI-first todo manager. Run without a command to launch the TUI."""
    config = Config.build(data_dir)
    setup_logging("mb_todo", file_path=config.log_path)
    core = Core(config)
    ctx.call_on_close(core.close)
    ctx.obj = CoreContext[Core, Output](core=core, out=Output())

    # Launch TUI when no subcommand is given
    if ctx.invoked_subcommand is None:
        TodoApp(core=core).run()


app.command(aliases=["a"])(add)
app.command(name="list", aliases=["l", "ls"])(list_)
app.command(aliases=["s"])(show)
app.command(aliases=["e"])(edit)
app.command(aliases=["c"])(close)
app.command(aliases=["r"])(reopen)
app.command(aliases=["rm"])(delete)
app.add_typer(project_app, name="project", aliases=["p"], help="Manage projects.")
