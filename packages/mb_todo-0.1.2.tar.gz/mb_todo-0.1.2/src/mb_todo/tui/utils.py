"""TUI utility functions."""

import time
from datetime import UTC, datetime

from mb_todo.config import StatusFilter
from mb_todo.core.db import Priority

# --- Formatting ---


def relative_age(ts: int) -> str:
    """Convert unix timestamp to a short relative age string."""
    diff = int(time.time()) - ts
    if diff < 60:
        return "now"
    if diff < 3600:
        return f"{diff // 60}m"
    if diff < 86400:
        return f"{diff // 3600}h"
    if diff < 86400 * 30:
        return f"{diff // 86400}d"
    if diff < 86400 * 365:
        return f"{diff // (86400 * 30)}mo"
    return f"{diff // (86400 * 365)}y"


def fmt_timestamp(ts: int) -> str:
    """Format a unix timestamp as a human-readable datetime string."""
    return datetime.fromtimestamp(ts, tz=UTC).strftime("%Y-%m-%d %H:%M UTC")


# --- Rich markup colors ---


def status_color(closed: bool) -> str:
    """Colored status text: 'open' or 'closed'."""
    return "[red]closed[/]" if closed else "[green]open[/]"


def status_color_short(closed: bool) -> str:
    """Short colored status label: O (open) or C (closed)."""
    return "[red]C[/]" if closed else "[green]O[/]"


def status_filter_color(status: StatusFilter | None) -> str:
    """Colored status filter label: open/closed or 'all' when None."""
    if status is None:
        return "[yellow]all[/]"
    return {"open": "[green]open[/]", "closed": "[red]closed[/]"}[status]


def priority_color(p: Priority) -> str:
    """Colored priority text: high/medium/low."""
    return {"high": "[bold red]high[/]", "medium": "[yellow]medium[/]", "low": "[dim]low[/]"}[p]


def priority_color_short(p: Priority) -> str:
    """Short colored priority label: H, M, or L."""
    return {"high": "[bold red]H[/]", "medium": "[yellow]M[/]", "low": "[dim]L[/]"}[p]
