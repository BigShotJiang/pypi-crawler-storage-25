"""Multi-select project picker screen."""

from typing import ClassVar

from textual.app import ComposeResult
from textual.binding import Binding, BindingType
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, SelectionList
from textual.widgets.selection_list import Selection


class MultiProjectPickerScreen(ModalScreen[list[str] | None]):
    """Pick one or more projects. Returns selected list, or None on cancel."""

    DEFAULT_CSS = """
    MultiProjectPickerScreen {
        align: center middle;
    }
    MultiProjectPickerScreen .modal-dialog {
        width: 1fr;
        height: auto;
        max-height: 80%;
        margin: 0 4;
        padding: 0 1;
        background: $surface;
    }
    MultiProjectPickerScreen #picker-hint {
        margin-top: 1;
        color: $text-muted;
    }
    MultiProjectPickerScreen SelectionList {
        height: auto;
        max-height: 20;
    }
    """

    BINDINGS: ClassVar[list[BindingType]] = [  # Keyboard shortcuts
        # enter is priority=True so the screen intercepts it before the focused
        # SelectionList (which would otherwise toggle the highlighted item, same as space).
        Binding("enter", "confirm", "Confirm", priority=True),
        Binding("escape", "cancel", "Cancel"),
    ]

    def __init__(
        self,
        *,
        projects: list[str],
        preselected: list[str],
        project_counts: dict[str, int] | None = None,
    ) -> None:
        """Initialize with available projects and initial selection."""
        super().__init__()
        self._projects = projects  # Available project names
        self._preselected = set(preselected)  # Initially checked project names
        self._project_counts = project_counts or {}  # Open todo counts per project

    def compose(self) -> ComposeResult:
        """Build the picker widget tree."""
        selections: list[Selection[str]] = []
        for name in self._projects:
            count = self._project_counts.get(name)
            label = f"{name} ({count})" if count is not None else name
            selections.append(Selection(label, name, name in self._preselected))
        with Vertical(classes="modal-dialog"):
            yield Label("[bold]Select Projects[/]", id="picker-title")
            yield SelectionList[str](*selections, id="project-selection")
            yield Label("[dim]\\[space] toggle  \\[enter] confirm  \\[esc] cancel[/]", id="picker-hint")

    def on_mount(self) -> None:
        """Focus the selection list."""
        self.query_one(SelectionList).focus()

    def action_confirm(self) -> None:
        """Dismiss with the current selection."""
        selected = self.query_one(SelectionList[str]).selected
        self.dismiss(list(selected))

    def action_cancel(self) -> None:
        """Dismiss with None to signal cancel."""
        self.dismiss(None)
