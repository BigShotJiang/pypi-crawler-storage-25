"""View todo screen."""

from typing import ClassVar, cast

from mm_clikit import CliError
from mm_clikit.tui import ModalConfirmScreen, ModalInputScreen, ModalListPickerScreen, ModalTextAreaScreen
from textual import work
from textual.app import ComposeResult
from textual.binding import Binding, BindingType
from textual.containers import VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Footer, Label, Static

from mb_todo.core.core import Core
from mb_todo.core.db import Priority, TodoRow
from mb_todo.tui.utils import fmt_timestamp, priority_color, status_color


class ViewTodoScreen(ModalScreen[None]):
    """Full-screen read-only view of a single todo."""

    DEFAULT_CSS = """
    ViewTodoScreen {
        background: $surface;
    }
    ViewTodoScreen #view-todo-title {
        text-style: bold;
        padding: 1 1 0 1;
    }
    ViewTodoScreen #view-todo-meta {
        color: $text-muted;
        padding: 0 1;
    }
    ViewTodoScreen #view-todo-dates {
        color: $text-muted;
        padding: 0 1 1 1;
    }
    ViewTodoScreen #view-todo-body {
        height: 1fr;
        padding: 0 1;
    }
    ViewTodoScreen #view-todo-body-text {
        height: auto;
    }
    """

    BINDINGS: ClassVar[list[BindingType]] = [  # Keyboard shortcuts
        Binding("escape", "dismiss", "Back", show=False),
        Binding("q", "dismiss", "Back"),
        Binding("t", "edit_title", "Title"),
        Binding("b", "edit_body", "Body"),
        Binding("p", "edit_project", "Project"),
        Binding("P", "edit_priority", "Priority"),
        Binding("T", "edit_tags", "Tags"),
        Binding("c", "close_todo", "Close"),
        Binding("r", "reopen_todo", "Reopen"),
        Binding("d", "delete", "Delete"),
    ]

    def __init__(self, todo: TodoRow, core: Core) -> None:
        """Initialize with the todo to display and core services."""
        super().__init__()
        self.todo = todo  # The todo being viewed
        self.core = core  # Application core for service access

    def _render_title(self) -> str:
        """Render the title line markup."""
        return f"[bold]#{self.todo.id}[/]  {self.todo.title}"

    def _render_meta(self) -> str:
        """Render the meta line markup (status, priority, project, tags)."""
        todo = self.todo
        status = status_color(todo.closed)
        priority = priority_color(todo.priority)
        parts = [f"Status: {status}", f"Priority: {priority}"]
        if todo.project:
            parts.append(f"Project: [bold]{todo.project}[/]")
        if todo.tags:
            parts.append(f"Tags: {', '.join(todo.tags)}")
        return "  ".join(parts)

    def _render_dates(self) -> str:
        """Render the dates line markup."""
        dates = f"Created: {fmt_timestamp(self.todo.created_at)}  Updated: {fmt_timestamp(self.todo.updated_at)}"
        if self.todo.closed_at:
            dates += f"  Closed: {fmt_timestamp(self.todo.closed_at)}"
        return dates

    def _render_body(self) -> str:
        """Render the body text markup."""
        return self.todo.body or ""

    def compose(self) -> ComposeResult:
        """Build the view layout."""
        yield Label(self._render_title(), id="view-todo-title")
        yield Label(self._render_meta(), id="view-todo-meta")
        yield Label(self._render_dates(), id="view-todo-dates")

        with VerticalScroll(id="view-todo-body"):
            yield Static(self._render_body(), id="view-todo-body-text")

        yield Footer()

    def _refresh_view(self) -> None:
        """Reload todo from DB and update all view widgets."""
        self.todo = self.core.service.get_todo(self.todo.id)
        self.query_one("#view-todo-title", Label).update(self._render_title())
        self.query_one("#view-todo-meta", Label).update(self._render_meta())
        self.query_one("#view-todo-dates", Label).update(self._render_dates())
        self.query_one("#view-todo-body-text", Static).update(self._render_body())

    async def _apply_edit(self, **kwargs: object) -> None:
        """Apply an edit to the current todo and refresh the view. Silently ignores NO_CHANGES."""
        try:
            self.core.service.edit_todo(self.todo.id, **kwargs)  # type: ignore[arg-type]
            self._refresh_view()
        except CliError as e:
            if e.code != "NO_CHANGES":
                self.notify(str(e), severity="error")

    @work
    async def action_edit_title(self) -> None:
        """Open title edit popup."""
        result = await self.app.push_screen_wait(ModalInputScreen("Edit Title", self.todo.title))
        if result is not None:
            await self._apply_edit(title=result)

    @work
    async def action_edit_body(self) -> None:
        """Open body edit screen."""
        title = f"[bold]#{self.todo.id}[/]  {self.todo.title}"
        result = await self.app.push_screen_wait(ModalTextAreaScreen(title, self.todo.body or ""))
        if result is not None:
            await self._apply_edit(body=result)

    @work
    async def action_edit_tags(self) -> None:
        """Open tags edit popup."""
        result = await self.app.push_screen_wait(
            ModalInputScreen("Edit Tags", ", ".join(self.todo.tags), placeholder="tag1, tag2...", allow_empty=True)
        )
        if result is not None:
            tag_list = [t.strip() for t in result.split(",") if t.strip()]
            await self._apply_edit(tag=tag_list)

    @work
    async def action_edit_project(self) -> None:
        """Open project picker for editing."""
        projects = self.core.db.fetch_projects()
        result = await self.app.push_screen_wait(
            ModalListPickerScreen(items=projects, title="Select Project", current=self.todo.project, empty_label="(none)")
        )
        if result is not None:
            await self._apply_edit(project_query=result)

    @work
    async def action_edit_priority(self) -> None:
        """Open priority picker for editing."""
        result = await self.app.push_screen_wait(
            ModalListPickerScreen(
                items=["high", "medium", "low"], title="Select Priority", current=self.todo.priority, empty_label=None
            )
        )
        if result is not None:
            await self._apply_edit(priority=cast("Priority", result))

    def action_close_todo(self) -> None:
        """Close the todo."""
        try:
            self.core.service.close_todo(self.todo.id)
            self._refresh_view()
        except CliError as e:
            self.notify(str(e), severity="error")

    def action_reopen_todo(self) -> None:
        """Reopen the todo."""
        try:
            self.core.service.reopen_todo(self.todo.id)
            self._refresh_view()
        except CliError as e:
            self.notify(str(e), severity="error")

    @work
    async def action_delete(self) -> None:
        """Delete the todo after confirmation."""
        confirmed = await self.app.push_screen_wait(
            ModalConfirmScreen(f'Delete #{self.todo.id} "{self.todo.title}"? This cannot be undone.')
        )
        if confirmed:
            try:
                self.core.service.delete_todo(self.todo.id)
                self.dismiss(None)
            except CliError as e:
                self.notify(str(e), severity="error")
