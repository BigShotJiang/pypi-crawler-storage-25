"""Unified filter screen for the TUI."""

from typing import ClassVar, cast

from mm_clikit.tui import ModalInputScreen, ModalListPickerScreen
from pydantic import BaseModel
from textual import work
from textual.app import ComposeResult
from textual.binding import Binding, BindingType
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Label, Static

from mb_todo.config import StatusFilter
from mb_todo.core.core import Core
from mb_todo.core.db import Priority
from mb_todo.tui.screens.view_todo import ViewTodoScreen
from mb_todo.tui.utils import priority_color, status_filter_color


class FilterResult(BaseModel):
    """Result from the filter screen with all filter values."""

    status: StatusFilter | None  # Status filter, None = all
    project: str | None  # Project filter, None = all
    priority: Priority | None  # Priority filter, None = all
    tag: str | None  # Tag filter, None = all


class FilterScreen(ModalScreen[FilterResult | None]):
    """Unified filter screen. Returns FilterResult or None on cancel."""

    DEFAULT_CSS = """
    FilterScreen {
        align: center middle;
    }
    FilterScreen .modal-dialog {
        width: 1fr;
        height: auto;
        margin: 0 4;
        padding: 0 1;
        background: $surface;
    }
    FilterScreen #filter-hint {
        margin-top: 1;
        color: $text-muted;
    }
    """

    BINDINGS: ClassVar[list[BindingType]] = [  # Keyboard shortcuts
        Binding("p", "pick_project", "Project", show=False),
        Binding("s", "pick_status", "Status", show=False),
        Binding("P", "pick_priority", "Priority", show=False),
        Binding("t", "pick_tag", "Tag", show=False),
        Binding("i", "pick_id", "ID", show=False),
        Binding("c", "clear_all", "Clear", show=False),
        Binding("escape", "close", "Close"),
    ]

    def __init__(
        self,
        *,
        core: Core,
        status: StatusFilter | None,
        project: str | None,
        priority: Priority | None,
        tag: str | None,
        projects: list[str],
        tags: list[str],
        project_counts: dict[str, int] | None = None,
    ) -> None:
        """Initialize with current filter state and available options."""
        super().__init__()
        self._core = core  # Application core for ID lookup
        self._status: StatusFilter | None = status  # Current status filter
        self._project = project  # Current project filter
        self._priority: Priority | None = priority  # Current priority filter
        self._tag = tag  # Current tag filter
        self._projects = projects  # Available project names
        self._tags = tags  # Available tag names
        self._project_counts = project_counts  # Open todo counts per project

    def compose(self) -> ComposeResult:
        """Build the filter display."""
        with Vertical(id="filter-screen", classes="modal-dialog"):
            yield Label("[bold]Filters[/]", id="picker-title")
            yield Static("", id="filter-rows")
            yield Label("[dim]\\[c] clear all  \\[esc] close[/]", id="filter-hint")

    def on_mount(self) -> None:
        """Render initial filter state."""
        self._update_display()

    def _update_display(self) -> None:
        """Refresh the filter rows display."""
        status_text = status_filter_color(self._status)
        project_text = f"[bold]{self._project}[/]" if self._project else "[dim]all[/]"
        priority_text = priority_color(self._priority) if self._priority else "[dim]all[/]"
        tag_text = f"[bold]{self._tag}[/]" if self._tag else "[dim]all[/]"

        lines = [
            f"  [bold]\\[p][/] Project:   {project_text}",
            f"  [bold]\\[s][/] Status:    {status_text}",
            f"  [bold]\\[P][/] Priority:  {priority_text}",
            f"  [bold]\\[t][/] Tag:       {tag_text}",
            "  [bold]\\[i][/] Go to ID",
        ]
        self.query_one("#filter-rows", Static).update("\n".join(lines))

    def _dismiss_with_result(self) -> None:
        """Dismiss the filter screen and apply current filter state immediately."""
        self.dismiss(FilterResult(status=self._status, project=self._project, priority=self._priority, tag=self._tag))

    @work
    async def action_pick_id(self) -> None:
        """Open ID input, then navigate directly to ViewTodoScreen."""
        result = await self.app.push_screen_wait(ModalInputScreen("Todo ID", placeholder="Enter todo ID..."))
        if result is None:
            return
        try:
            todo_id = int(result)
        except ValueError:
            self.app.notify("Invalid ID — must be a number.", severity="error")
            return
        todo = self._core.db.fetch_todo(todo_id)
        if todo is None:
            self.app.notify(f"Todo #{todo_id} not found.", severity="error")
            return
        await self.app.push_screen_wait(ViewTodoScreen(todo, self._core))

    @work
    async def action_pick_status(self) -> None:
        """Open status sub-picker."""
        result = await self.app.push_screen_wait(
            ModalListPickerScreen(items=["open", "closed"], title="Select Status", current=self._status)
        )
        if result is not None:
            self._status = cast(StatusFilter, result) if result else None
            self._dismiss_with_result()

    @work
    async def action_pick_project(self) -> None:
        """Open project sub-picker."""
        item_labels = {name: f"{name} ({count})" for name, count in (self._project_counts or {}).items() if count > 0}
        result = await self.app.push_screen_wait(
            ModalListPickerScreen(items=self._projects, title="Select Project", current=self._project, item_labels=item_labels)
        )
        if result is not None:
            self._project = result or None
            self._dismiss_with_result()

    @work
    async def action_pick_priority(self) -> None:
        """Open priority sub-picker."""
        result = await self.app.push_screen_wait(
            ModalListPickerScreen(items=["high", "medium", "low"], title="Select Priority", current=self._priority)
        )
        if result is not None:
            self._priority = cast(Priority, result) if result else None
            self._dismiss_with_result()

    @work
    async def action_pick_tag(self) -> None:
        """Open tag sub-picker."""
        result = await self.app.push_screen_wait(ModalListPickerScreen(items=self._tags, title="Select Tag", current=self._tag))
        if result is not None:
            self._tag = result or None
            self._dismiss_with_result()

    def action_clear_all(self) -> None:
        """Reset all filters to defaults."""
        self._status = "open"
        self._project = None
        self._priority = None
        self._tag = None
        self._dismiss_with_result()

    def action_close(self) -> None:
        """Dismiss with current filter state."""
        self.dismiss(FilterResult(status=self._status, project=self._project, priority=self._priority, tag=self._tag))
