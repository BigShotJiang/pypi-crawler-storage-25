"""Main Textual application for mb-todo TUI."""

from typing import ClassVar

from mm_clikit import CliError
from mm_clikit.tui import ModalInputScreen
from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding, BindingType
from textual.containers import Horizontal
from textual.widgets import DataTable, Footer, Label

from mb_todo.config import StatusFilter
from mb_todo.core.core import Core
from mb_todo.core.db import Priority, TodoRow
from mb_todo.tui.screens.filter_screen import FilterScreen
from mb_todo.tui.screens.multi_project_picker import MultiProjectPickerScreen
from mb_todo.tui.screens.view_todo import ViewTodoScreen
from mb_todo.tui.utils import priority_color, priority_color_short, relative_age, status_color_short, status_filter_color


class TodoApp(App[None]):
    """Interactive TUI for managing todos."""

    DEFAULT_CSS = """
    #header-bar {
        height: 1;
        dock: top;
        background: $primary-background;
    }
    #header-title {
        width: auto;
        color: $text;
    }
    #header-filters {
        width: 1fr;
        text-align: right;
        color: $text-muted;
    }
    #todo-table {
        height: 1fr;
    }
    """

    BINDINGS: ClassVar[list[BindingType]] = [  # Keyboard shortcuts
        Binding("q", "quit", "Quit"),
        Binding("a", "add_todo", "Add"),
        Binding("A", "add_todo_multi", "Add multi"),
        Binding("f", "open_filters", "Filter"),
        Binding("ctrl+r", "refresh", "Refresh"),
    ]

    def __init__(self, core: Core) -> None:
        """Initialize with the application core."""
        super().__init__()
        self.core = core  # Shared application services
        self._todos: list[TodoRow] = []  # Cached todo list for the current view
        self._projects: list[str] = []  # All project names from DB
        self._tags: list[str] = []  # All unique tags from DB
        self._project_counts: dict[str, int] = {}  # Open todo counts per project
        # Restored filters from config
        self._current_status: StatusFilter | None = core.config.tui.filters.status
        self._current_project: str | None = core.config.tui.filters.project
        self._current_priority: Priority | None = core.config.tui.filters.priority
        self._current_tag: str | None = core.config.tui.filters.tag

    def compose(self) -> ComposeResult:
        """Build the widget tree."""
        with Horizontal(id="header-bar"):
            yield Label(" [bold reverse] mb-todo [/]", id="header-title")
            yield Label("", id="header-filters")

        yield DataTable(id="todo-table", cursor_type="row")
        yield Footer()

    def on_mount(self) -> None:
        """Load data on startup."""
        self._reload_data()
        self._update_header()
        self._refresh_todos()
        self.query_one("#todo-table", DataTable).focus()

    def _update_header(self) -> None:
        """Update the header filter labels."""
        parts = [f"Status: {status_filter_color(self._current_status)}"]
        if self._current_project:
            parts.append(f"Project: [bold]{self._current_project}[/]")
        if self._current_priority:
            parts.append(f"Priority: {priority_color(self._current_priority)}")
        if self._current_tag:
            parts.append(f"Tag: [bold]{self._current_tag}[/]")
        self.query_one("#header-filters", Label).update(" " + "  ".join(parts) + " ")

    def _save_tui_filters(self) -> None:
        """Persist current filter state to config.toml."""
        self.core.config.save_tui_filters(
            project=self._current_project, status=self._current_status, priority=self._current_priority, tag=self._current_tag
        )

    def _reload_data(self) -> None:
        """Reload projects and tags from DB, resetting stale filters."""
        self._projects = self.core.db.fetch_projects()
        self._tags = self.core.db.fetch_tags()
        self._project_counts = self.core.db.fetch_open_todo_counts_by_project()
        if self._current_project and self._current_project not in self._projects:
            self._current_project = None
        if self._current_tag and self._current_tag not in self._tags:
            self._current_tag = None

    def _visible_columns(self, todos: list[TodoRow]) -> set[str]:
        """Compute which optional columns to show, applying three visibility layers."""
        visible = {"status", "priority", "project", "tags", "age", "body"}

        # Layer 3: config force-hide (unconditional)
        visible -= set(self.core.config.tui.hide_columns)

        # Layer 1: filter-based auto-hide (filtered value makes column redundant)
        if self._current_status is not None:
            visible.discard("status")
        if self._current_priority is not None:
            visible.discard("priority")
        if self._current_project is not None:
            visible.discard("project")

        # Layer 2: data-based smart auto-hide (uniform/empty data is noise)
        if not any(todo.tags for todo in todos):
            visible.discard("tags")
        if not any(todo.body for todo in todos):
            visible.discard("body")
        if not any(todo.project for todo in todos):
            visible.discard("project")
        if len({todo.priority for todo in todos}) <= 1:
            visible.discard("priority")

        return visible

    def _refresh_todos(self) -> None:
        """Fetch todos from DB and repopulate the table."""
        closed = True if self._current_status == "closed" else False if self._current_status == "open" else None
        self._todos = self.core.service.list_todos(
            closed=closed,
            project_query=self._current_project,
            priority=self._current_priority,
            tag=self._current_tag,
            sort="updated",
            limit=None,
        )

        visible = self._visible_columns(self._todos)
        table = self.query_one("#todo-table", DataTable)
        table.clear(columns=True)

        # Column specs in fixed display order: (key, label, width)
        all_optional: list[tuple[str, str, int]] = [
            ("status", "S", 1),
            ("priority", "P", 1),
            ("project", "Project", 12),
            ("age", "Age", 3),
            ("tags", "Tags", 10),
            ("body", "B", 1),
        ]
        shown_cols = [(k, label, w) for k, label, w in all_optional if k in visible]

        # Compute Title width from remaining space after all other columns
        pad = table.cell_padding * 2
        col_widths = [4] + [w for _, _, w in shown_cols]  # ID + visible optional
        gutter = 2  # row cursor gutter
        fixed_width = sum(w + pad for w in col_widths) + gutter
        title_width = max(20, self.size.width - fixed_width - pad)

        # Add columns: ID, optional columns, Title (always last)
        table.add_column("ID", width=4)
        for _, label, width in shown_cols:
            table.add_column(label, width=width)
        table.add_column("Title", width=title_width)

        for todo in self._todos:
            row: list[object] = [str(todo.id)]
            for key, _, _ in shown_cols:
                if key == "status":
                    row.append(status_color_short(todo.closed))
                elif key == "priority":
                    row.append(priority_color_short(todo.priority))
                elif key == "project":
                    row.append(todo.project or "")
                elif key == "age":
                    row.append(relative_age(todo.created_at))
                elif key == "tags":
                    row.append(", ".join(todo.tags))
                elif key == "body":
                    row.append("+" if todo.body else "")
            row.append(todo.title)
            table.add_row(*row, key=str(todo.id))

    def _get_selected_todo(self) -> TodoRow | None:
        """Get the currently highlighted todo."""
        table = self.query_one("#todo-table", DataTable)
        if table.row_count == 0:
            return None
        row_key, _ = table.coordinate_to_cell_key(table.cursor_coordinate)
        for todo in self._todos:
            if str(todo.id) == row_key.value:
                return todo
        return None

    # --- Actions: filters ---

    @work
    async def action_open_filters(self) -> None:
        """Open the unified filter screen."""
        result = await self.push_screen_wait(
            FilterScreen(
                core=self.core,
                status=self._current_status,
                project=self._current_project,
                priority=self._current_priority,
                tag=self._current_tag,
                projects=self._projects,
                tags=self._tags,
                project_counts=self._project_counts,
            )
        )
        if result is not None:
            self._current_status = result.status
            self._current_project = result.project
            self._current_priority = result.priority
            self._current_tag = result.tag
            self._update_header()
            self._refresh_todos()
            self._save_tui_filters()

    def action_refresh(self) -> None:
        """Refresh the todo list."""
        self._reload_data()
        self._update_header()
        self._refresh_todos()

    def on_resize(self) -> None:
        """Rebuild table columns on terminal resize."""
        if self._todos is not None:
            self._refresh_todos()

    # --- Actions: todo operations ---

    @work
    async def action_add_todo(self) -> None:
        """Open the quick-add todo popup."""
        project_text = f" ({self._current_project})" if self._current_project else ""
        title = await self.push_screen_wait(ModalInputScreen(f"New Todo{project_text}", placeholder="What needs to be done?"))
        if title is not None:
            try:
                self.core.service.add_todo(
                    title=title, body=None, priority="medium", project_query=self._current_project, tags=None
                )
                self._reload_data()
                self._update_header()
                self._refresh_todos()
            except CliError as e:
                self.notify(str(e), severity="error")

    @work
    async def action_add_todo_multi(self) -> None:
        """Open the multi-project add flow: pick projects, then enter title."""
        if not self._projects:
            self.notify("No projects available.", severity="warning")
            return
        preselected = [self._current_project] if self._current_project else []
        selected = await self.push_screen_wait(
            MultiProjectPickerScreen(projects=self._projects, preselected=preselected, project_counts=self._project_counts)
        )
        if selected is None:
            return
        if not selected:
            self.notify("No projects selected.", severity="warning")
            return
        title = await self.push_screen_wait(
            ModalInputScreen(f"New Todo ({len(selected)} project(s))", placeholder="What needs to be done?")
        )
        if title is None:
            return
        try:
            results = self.core.service.add_todo_for_projects(
                title=title, body=None, priority="medium", project_queries=selected, tags=None
            )
            self._reload_data()
            self._update_header()
            self._refresh_todos()
            self.notify(f"Added to {len(results)} project(s).")
        except CliError as e:
            self.notify(str(e), severity="error")

    @on(DataTable.RowSelected)
    @work
    async def on_row_selected(self, _event: DataTable.RowSelected) -> None:
        """Open view screen on Enter."""
        todo = self._get_selected_todo()
        if todo is None:
            return
        await self.push_screen_wait(ViewTodoScreen(todo, self.core))
        self._reload_data()
        self._update_header()
        self._refresh_todos()
