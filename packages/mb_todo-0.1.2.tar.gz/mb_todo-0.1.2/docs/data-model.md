# Data Model Design Decisions

Schema and columns are defined in `core/db.py` (migrations + `TodoRow`). This document covers the **why** behind key choices.

## Entities

Two tables: `projects` (name-only) and `todos` (all fields).

## Decisions

- **Integer IDs** — CLI ergonomics: `mb-todo close 42` is faster than UUIDs
- **Projects as name-only table** — a project is just a label; no metadata needed
- **Text FK for project** — project name stored directly in todos, eliminates JOINs
- **RESTRICT on project delete** — prevents orphaning; user must reassign todos first
- **CASCADE on project rename** — transparent propagation to all todos
- **Tags as JSON array** — simpler than a junction table, queryable via `json_each()`
- **`updated_at` NOT NULL** — set to `created_at` on insert; "never modified" = equal timestamps
- **`closed_at` nullable** — set when closing, enables "done today/this week" queries
- **Priority defaults to `medium`**
- **Timestamps as unix seconds**
- **SQLite STRICT mode**
- **No `due_date`** — deferred; can add via migration later if needed
