# Configuration

Optional TOML file at `{data_dir}/config.toml`. If absent, all defaults apply.
Config fields are defined in `config.py` (`Config`, `TuiConfig`, `TuiFilters`).

## Example

```toml
[tui]
hide_columns = ["age"]

[tui.filters]
project = "work"
status = "open"
priority = "high"
tag = "urgent"
```

## TUI Column Auto-Hiding

Column display order is fixed: `id`, `status`, `priority`, `project`, `age`, `tags`, `body`, `title`.

`id` and `title` are always shown. Optional columns are shown by default with smart auto-hiding:

- **Filter-based**: column hidden when its filter is active (e.g., project column hidden when filtering by a specific project)
- **Data-based**: column hidden when data is uniform or empty (e.g., tags hidden if no todos have tags, priority hidden if all same)

Force-hide columns via `hide_columns` in config (see example above).

## TUI Filter Persistence

Filter state is saved to `config.toml` automatically when changed in the TUI.
On next launch, filters restore from `[tui.filters]` section.

- **status** — `open` (default), `closed`, or omitted (= all)
- **project** — project name, or omitted (= all)
- **priority** — `low`, `medium`, `high`, or omitted (= all)
- **tag** — exact tag string, or omitted (= all)
