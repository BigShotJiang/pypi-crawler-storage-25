from setuptools import setup, find_packages

setup(
    name="alpha_omega_gravity",
    packages=find_packages(),
    version="0.1.1",
    description="""Successfully unified gravity and electromagnetism.""",
    long_description_content_type="text/markdown",
    long_description="""
# $\\alpha \\omega$ Gravity

Yes, that's $\\alpha$, as in the fine-structure constant. $\\omega$ is defined within the package, because I can't resist the urge to be grandiose. 

5 years ago I gave up *everything* to focus on a modified model of relativity after realizing that Einstein 
made an assumption that made far more sense before our observations that give us the Big Bang model.

I quit my job, gave up my condo, became homeless, but now 5 years later I think I have it... successfully unified
electromagnetism and gravity.

The only problem? It concludes that gravity is a repulsive force, and that the Earth is expanding _with_ the rest of the Universe.

If you're willing to entertain thoughts that are bigger than what some others can wrap their minds around, than this is the package for you.

It reaches some controversial conclusions, but you tell me... are _this many_ alignments to _this degree_ of accuracy a coincidence? I think it's time to accept the impossible, and realize not only is the Universe potentially infinitely large, it may also be infinitely small with no limit on complexity for smaller systems. This follows logically if parameters like the speed of light (the speed of causality) dilates with the medium, as all experiments seem to indicate.

Take a look at the `included_functions.md` file for a brief summary of the included functions, or take a look at [Fluster](https://flusterapp.com), an app I built to promote the model. There is a short summary of the model with a complete derivation available on the website. 
    """,
)
