"""Test that the dispatcher gates dependents on merge success.

These tests exercise the merged_to_target_branch lifecycle directly via the
helper that wraps PATCH calls — exhaustive end-to-end runs are out of scope
because they require provider keys.  We verify the call sequence.
"""
from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from claw_forge.cli import _set_merged_after_merge


@pytest.mark.asyncio
async def test_set_merged_after_merge_calls_patch_true_on_success() -> None:
    http = AsyncMock()
    merge_result = {"merged": True, "commit_hash": "abc1234"}
    base = "http://localhost:8420"
    await _set_merged_after_merge(http, base, "task-1", merge_result)
    # Two PATCH calls now: merged_to_target_branch=True (gating) and
    # merge_commit_sha (training-trace ground truth).  Both target the
    # same task URL.
    assert http.patch.call_count == 2
    calls = http.patch.call_args_list
    assert calls[0].args[0] == f"{base}/tasks/task-1"
    assert calls[0].kwargs["json"] == {"merged_to_target_branch": True}
    assert calls[1].args[0] == f"{base}/tasks/task-1"
    assert calls[1].kwargs["json"] == {"merge_commit_sha": "abc1234"}


@pytest.mark.asyncio
async def test_set_merged_after_merge_no_patch_on_failure() -> None:
    http = AsyncMock()
    merge_result = {"merged": False, "error": "conflict"}
    await _set_merged_after_merge(http, "http://x", "task-1", merge_result)
    http.patch.assert_not_called()


@pytest.mark.asyncio
async def test_set_merged_after_merge_no_patch_when_none() -> None:
    """When merge isn't attempted (manual strategy / git disabled), no PATCH."""
    http = AsyncMock()
    await _set_merged_after_merge(http, "http://x", "task-1", None)
    http.patch.assert_not_called()


def test_task_dict_to_node_reads_merged_to_target_branch() -> None:
    """The DB→TaskNode mapper preserves merged_to_target_branch."""
    from claw_forge.cli import _task_dict_to_node

    payload = {
        "id": "t1", "plugin_name": "coding", "priority": 0,
        "depends_on": [], "status": "completed",
        "merged_to_target_branch": False, "description": "X", "category": "c",
        "steps": [],
    }
    node = _task_dict_to_node(payload)
    assert node.merged_to_target_branch is False
    # Backward-compat: missing key defaults to True.
    payload2 = dict(payload)
    payload2.pop("merged_to_target_branch")
    node2 = _task_dict_to_node(payload2)
    assert node2.merged_to_target_branch is True


def test_task_dict_to_node_backward_compat_reads_legacy_merged_to_main() -> None:
    """A v0.5.30 state-service payload still emits merged_to_main; mapper honours it."""
    from claw_forge.cli import _task_dict_to_node

    legacy_payload = {
        "id": "t1", "plugin_name": "coding", "priority": 0,
        "depends_on": [], "status": "completed",
        "merged_to_main": False,  # old key from v0.5.30
        "description": "X", "category": "c", "steps": [],
    }
    node = _task_dict_to_node(legacy_payload)
    assert node.merged_to_target_branch is False
