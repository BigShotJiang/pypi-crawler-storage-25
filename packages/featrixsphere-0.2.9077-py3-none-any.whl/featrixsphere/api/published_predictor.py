#  -*- coding: utf-8 -*-
#
#  Copyright (c) 2023-2026 Featrix, Inc, All Rights Reserved
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#

"""
PublishedPredictor class for FeatrixSphere API.

Represents a predictor deployed to production, accessed via the Sphere API.
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Dict, Any, Iterator, Optional, List, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from .http_client import ClientContext
    import pandas as pd

from .prediction_result import PredictionResult

logger = logging.getLogger(__name__)


@dataclass
class PublishedPredictor:
    """
    Represents a predictor deployed to production for serving predictions.

    Attributes:
        org: Organization ID
        name: Model name
        api_key: API key for authentication
        base_url: Sphere API URL (default: https://sphere-api.featrix.com)

    Usage:
        # Load a published predictor
        predictor = client.published_predictor(
            org="alph",
            name="my-model",
            api_key="sk_alph_xxx"
        )

        # Make prediction
        result = predictor.predict({"age": 35, "income": 50000})
        print(result.predicted_class)
        print(result.confidence)

        # Batch predictions
        results = predictor.batch_predict([
            {"age": 35, "income": 50000},
            {"age": 42, "income": 75000}
        ])
    """

    org: str
    name: str
    api_key: str
    base_url: str = "https://sphere-api.featrix.com"

    # Internal
    _ctx: Optional['ClientContext'] = field(default=None, repr=False)

    @property
    def endpoint_url(self) -> str:
        """Get the full prediction endpoint URL."""
        return f"{self.base_url}/predict/{self.org}/{self.name}"

    def predict(
        self,
        record: Dict[str, Any],
    ) -> PredictionResult:
        """
        Make a single prediction.

        Args:
            record: Input record dictionary

        Returns:
            PredictionResult with prediction, confidence, and probabilities.

        Example:
            result = predictor.predict({"age": 35, "income": 50000})
            print(result.predicted_class)  # "churned"
            print(result.confidence)       # 0.87
        """
        # Clean the record
        cleaned_record = self._clean_record(record)

        # Make batch request with single record
        results = self.batch_predict([cleaned_record])

        return results[0] if results else None

    def batch_predict(
        self,
        records: Union[List[Dict[str, Any]], 'pd.DataFrame'],
        batch_size: int = 256,
    ) -> List[PredictionResult]:
        """
        Make batch predictions.

        Args:
            records: List of record dictionaries or DataFrame
            batch_size: Number of records to process per batch

        Returns:
            List of PredictionResult objects

        Example:
            results = predictor.batch_predict([
                {"age": 35, "income": 50000},
                {"age": 42, "income": 75000}
            ])
            for result in results:
                print(result.predicted_class, result.confidence)
        """
        # Convert DataFrame to list of dicts if needed
        if hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        # Clean records
        cleaned_records = [self._clean_record(r) for r in records]

        # Build request
        request_payload = {
            "records": cleaned_records,
            "batch_size": batch_size,
        }

        # Make request to production API with authentication
        import requests

        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

        response = requests.post(
            self.endpoint_url,
            json=request_payload,
            headers=headers,
            timeout=300,  # 5 minute timeout for large batches
        )

        # Check for errors
        if response.status_code != 200:
            error_msg = f"Prediction failed with status {response.status_code}"
            try:
                error_data = response.json()
                error_msg = error_data.get('error', error_msg)
            except:
                error_msg = response.text or error_msg
            raise RuntimeError(error_msg)

        # Parse response
        response_data = response.json()

        if not response_data.get('success'):
            error = response_data.get('error', 'Unknown error')
            raise RuntimeError(f"Prediction failed: {error}")

        # Parse results
        results = []
        predictions = response_data.get('predictions', [])

        # Extract prediction_uuid and deep links injected by sphere-api
        top_level_uuid = response_data.get('prediction_uuid')
        links = response_data.get('_links')

        for i, pred in enumerate(predictions):
            record = cleaned_records[i] if i < len(cleaned_records) else {}

            # Production API nests prediction data under 'results' key
            pred_results = pred.get('results', pred)

            # Create PredictionResult from production API response
            result = PredictionResult(
                predicted_class=pred_results.get('prediction', pred_results.get('predicted_class')),
                confidence=pred_results.get('confidence'),
                probabilities=pred_results.get('probabilities', {}),
                threshold=pred_results.get('threshold'),
                query_record=record,
                guardrails=pred.get('guardrails'),
                ignored_query_columns=pred.get('ignored_query_columns'),
                available_query_columns=pred.get('available_query_columns'),
                prediction_uuid=top_level_uuid,
                links=links,
                _ctx=self._ctx,
                _published_predictor=self,
            )
            results.append(result)

        return results

    def predict_csv_file(
        self,
        csv_path: str,
        batch_size: int = 256,
    ) -> List[PredictionResult]:
        """
        Load a CSV file and run batch predictions on all rows.

        Args:
            csv_path: Path to the CSV file
            batch_size: Number of records to process per batch

        Returns:
            List of PredictionResult objects

        Example:
            results = predictor.predict_csv_file("test_data.csv")
            for r in results:
                print(r.predicted_class, r.confidence)
        """
        import pandas as pd
        df = pd.read_csv(csv_path)
        return self.batch_predict(df, batch_size=batch_size)

    def batch_predict_streaming(
        self,
        records: Union[List[Dict[str, Any]], 'pd.DataFrame'],
        batch_size: int = 256,
    ) -> Iterator[PredictionResult]:
        """
        Stream predictions one at a time as they come off the GPU.

        Yields individual PredictionResult objects as they arrive from the
        production server, rather than waiting for all predictions to complete.

        Args:
            records: List of record dictionaries or DataFrame
            batch_size: Number of records per GPU batch on the server

        Yields:
            PredictionResult objects, one per input record

        Example:
            for result in predictor.batch_predict_streaming(records):
                print(result.predicted_class, result.confidence)
        """
        import requests as req_lib

        # Convert DataFrame to list of dicts if needed
        if hasattr(records, 'to_dict'):
            records = records.to_dict('records')

        # Clean records
        cleaned_records = [self._clean_record(r) for r in records]

        # Build request with NDJSON format
        request_payload = {
            "records": cleaned_records,
            "batch_size": batch_size,
            "result_format": "ndjson",
        }

        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

        response = req_lib.post(
            self.endpoint_url,
            json=request_payload,
            headers=headers,
            timeout=600,  # 10 minute timeout for large streaming batches
            stream=True,
        )

        if response.status_code != 200:
            error_msg = f"Prediction failed with status {response.status_code}"
            try:
                error_data = response.json()
                error_msg = error_data.get('error', error_msg)
            except Exception:
                error_msg = response.text or error_msg
            raise RuntimeError(error_msg)

        header_info = {}

        for line in response.iter_lines():
            if not line:
                continue
            msg = json.loads(line)

            if msg['type'] == 'header':
                header_info = msg
            elif msg['type'] == 'prediction':
                idx = msg['index']
                pred = msg['result']
                record = cleaned_records[idx] if idx < len(cleaned_records) else {}

                # Production API nests prediction data under 'results' key
                pred_results = pred.get('results', pred)

                yield PredictionResult(
                    predicted_class=pred_results.get('prediction', pred_results.get('predicted_class')),
                    confidence=pred_results.get('confidence'),
                    probabilities=pred_results.get('probabilities', {}),
                    threshold=pred_results.get('threshold'),
                    query_record=record,
                    guardrails=pred.get('guardrails'),
                    ignored_query_columns=pred.get('ignored_query_columns'),
                    available_query_columns=pred.get('available_query_columns'),
                    prediction_uuid=header_info.get('prediction_uuid'),
                    links=header_info.get('_links'),
                    _ctx=self._ctx,
                    _published_predictor=self,
                )
            elif msg['type'] == 'done':
                pass  # streaming complete

    def send_feedback(
        self,
        prediction_uuid: str,
        ground_truth: Union[str, float],
        meta: Dict[str, Any] = None,
    ) -> Dict[str, Any]:
        """
        Send ground truth feedback for a prediction.

        Args:
            prediction_uuid: UUID from PredictionResult.prediction_uuid
            ground_truth: The correct label/value
            meta: Optional metadata dict (source, annotator, notes, batch_id, etc.)

        Returns:
            Server response dict

        Example:
            result = predictor.predict({"age": 35})
            predictor.send_feedback(
                prediction_uuid=result.prediction_uuid,
                ground_truth="correct_label",
                meta={"source": "manual_review", "annotator": "jdoe"},
            )
        """
        import requests as req_lib

        headers = {
            "X-API-Key": self.api_key,
            "Content-Type": "application/json",
        }

        feedback_url = f"{self.base_url}/predict/{self.org}/{self.name}/feedback"

        body = {
            "prediction_uuid": prediction_uuid,
            "ground_truth": str(ground_truth),
        }
        if meta is not None:
            body["meta"] = meta

        response = req_lib.post(
            feedback_url,
            json=body,
            headers=headers,
            timeout=30,
        )

        if response.status_code != 200:
            error_msg = f"Feedback failed with status {response.status_code}"
            try:
                error_data = response.json()
                error_msg = error_data.get('error', error_msg)
            except Exception:
                error_msg = response.text or error_msg
            raise RuntimeError(error_msg)

        return response.json()

    def status(self) -> Dict[str, Any]:
        """
        Get deployment status of this published model on the production network.

        Returns:
            Dictionary with:
                - on_disk: Whether the model files exist on the production server
                - published_at: When the model was published (ISO 8601)
                - in_memory: Whether the model is loaded in a running container
                - loaded_at: When the container was started (ISO 8601)
                - last_used: Last prediction request time (ISO 8601)
                - request_count: Total predictions served since container start
                - uptime_seconds: How long the container has been running
                - verification: Self-test status (PASSED, FAILED, SKIPPED, PENDING)

        Example:
            status = predictor.status()
            if status['in_memory']:
                print(f"Model hot, {status['request_count']} predictions served")
            else:
                print(f"Model on disk, will cold-start on next prediction")
        """
        import requests as req_lib

        headers = {
            "X-API-Key": self.api_key,
        }

        status_url = f"{self.base_url}/predict/{self.org}/{self.name}/status"

        response = req_lib.get(
            status_url,
            headers=headers,
            timeout=15,
        )

        if response.status_code != 200:
            error_msg = f"Status request failed with status {response.status_code}"
            try:
                error_data = response.json()
                error_msg = error_data.get('error', error_msg)
            except Exception:
                error_msg = response.text or error_msg
            raise RuntimeError(error_msg)

        return response.json()

    def ground_truth_stats(self) -> Dict[str, Any]:
        """
        Get ground truth feedback statistics for this published model.

        Returns:
            Dictionary with:
                - org: Organization slug
                - model_name: Model name
                - total_predictions: Total successful predictions
                - total_corrections: Predictions with ground truth feedback
                - correction_rate: Fraction with ground truth

        Example:
            stats = predictor.ground_truth_stats()
            print(f"{stats['total_corrections']}/{stats['total_predictions']} have ground truth")
        """
        import requests as req_lib

        headers = {
            "X-API-Key": self.api_key,
        }

        stats_url = f"{self.base_url}/predict/{self.org}/{self.name}/ground_truth_stats"

        response = req_lib.get(
            stats_url,
            headers=headers,
            timeout=30,
        )

        if response.status_code != 200:
            error_msg = f"Stats request failed with status {response.status_code}"
            try:
                error_data = response.json()
                error_msg = error_data.get('error', error_msg)
            except Exception:
                error_msg = response.text or error_msg
            raise RuntimeError(error_msg)

        return response.json()

    def get_columns(self) -> List[str]:
        """
        Get column names for this published model.

        Returns column metadata from Supabase — no compute node or production-ai
        worker is involved. Available as soon as the model is published.

        Returns:
            List of column names (excludes internal __featrix columns).

        Example:
            columns = predictor.get_columns()
            print(f"Model expects {len(columns)} columns: {columns[:5]}...")
        """
        import requests as req_lib

        response = req_lib.get(
            f"{self.base_url}/predict/{self.org}/{self.name}/columns",
            headers={"X-API-Key": self.api_key},
            timeout=15,
        )

        if response.status_code != 200:
            error_msg = f"get_columns failed with status {response.status_code}"
            try:
                error_data = response.json()
                error_msg = error_data.get('error', error_msg)
            except Exception:
                error_msg = response.text or error_msg
            raise RuntimeError(error_msg)

        data = response.json()
        columns = data.get('columns', [])
        # Extract just the name strings if columns are dicts (full metadata format)
        if columns and isinstance(columns[0], dict):
            return [c['name'] for c in columns]
        return columns

    def get_session(self) -> Dict[str, Any]:
        """
        Get session metadata for this published model.

        Returns session data from production-ai — no compute node is involved.

        Returns:
            Dictionary with session metadata (session_id, status, job_plan, etc.).

        Example:
            session = predictor.get_session()
            print(f"Session: {session.get('session', {}).get('session_id')}")
        """
        import requests as req_lib

        response = req_lib.get(
            f"{self.base_url}/predict/{self.org}/{self.name}/session",
            headers={"X-API-Key": self.api_key},
            timeout=15,
        )

        if response.status_code != 200:
            error_msg = f"get_session failed with status {response.status_code}"
            try:
                error_data = response.json()
                error_msg = error_data.get('error', error_msg)
            except Exception:
                error_msg = response.text or error_msg
            raise RuntimeError(error_msg)

        return response.json()

    def _clean_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """Clean a record for API submission."""
        import math

        cleaned = {}
        for key, value in record.items():
            # Handle NaN/Inf
            if isinstance(value, float):
                if math.isnan(value) or math.isinf(value):
                    value = None
            # Handle numpy types
            if hasattr(value, 'item'):
                value = value.item()
            cleaned[key] = value
        return cleaned

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            'org': self.org,
            'name': self.name,
            'base_url': self.base_url,
            'endpoint_url': self.endpoint_url,
        }

    def __repr__(self) -> str:
        return f"PublishedPredictor(org='{self.org}', name='{self.name}')"
