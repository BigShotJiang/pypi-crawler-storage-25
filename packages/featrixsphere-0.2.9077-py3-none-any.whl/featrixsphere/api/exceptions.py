#  -*- coding: utf-8 -*-
#
#  Copyright (c) 2023-2026 Featrix, Inc, All Rights Reserved
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#

"""
Exceptions for FeatrixSphere API client.
"""


class FeatrixAuthenticationError(Exception):
    """Raised when the server returns 401 Unauthorized.

    This means the API key is missing, invalid, or expired.
    Set your API key in ~/.featrix or the FEATRIX_API_KEY environment variable.
    """

    def __init__(self, message: str = None, status_code: int = 401):
        if message is None:
            message = (
                "Authentication required. "
                "Set your API key in ~/.featrix (as api_key=sk_live_...) "
                "or the FEATRIX_API_KEY environment variable."
            )
        self.status_code = status_code
        super().__init__(message)


class FeatrixPredictionError(Exception):
    """Raised when a prediction request fails on the server.

    Contains the server's error detail (e.g., model integrity check failure,
    missing model, version mismatch) so the customer sees an actionable message
    instead of a raw HTTP 500.
    """

    def __init__(self, message: str, status_code: int = 500):
        self.status_code = status_code
        super().__init__(message)
