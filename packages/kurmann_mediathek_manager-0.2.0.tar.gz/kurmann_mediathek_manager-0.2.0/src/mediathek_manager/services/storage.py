"""Abstraktion für Dateizugriff — lokal (pathlib) oder remote (rclone).

Der Mediathek Manager extrahiert selbst keine Vorschaubilder. Die Backends
liefern deshalb ausschließlich Listing-, Lese- und (bei rclone) Sync-Fähigkeiten
sowie ``run_ffprobe`` für Metadaten-Extraktion.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path, PurePosixPath
from typing import Protocol, runtime_checkable

from ..api.models import RuntimeOptions


VIDEO_EXTENSIONS = {".m4v", ".mp4", ".mkv", ".mov", ".avi", ".webm"}


@runtime_checkable
class StorageBackend(Protocol):
    """Einheitliches Interface für lokalen und rclone-basierten Dateizugriff."""

    @property
    def root_name(self) -> str:
        """Name des Wurzelverzeichnisses (für Bibliothekstitel)."""
        ...

    def list_videos(self, recursive: bool = False) -> list[str]:
        """Gibt relative Pfade aller Videodateien zurück."""
        ...

    def list_subdirectories(self) -> list[str]:
        """Gibt Namen der direkten, nicht-versteckten Unterverzeichnisse zurück."""
        ...

    def file_exists(self, relative_path: str) -> bool:
        ...

    def read_text(self, relative_path: str, encoding: str = "utf-8") -> str:
        ...

    def run_ffprobe(self, relative_path: str, runtime: RuntimeOptions) -> str:
        """Führt ffprobe auf einer Datei aus und gibt stdout (JSON) zurück.

        Bei Timeout oder Fehler: leerer String — Aufrufer soll daraus einen
        Fallback ableiten statt abzubrechen.
        """
        ...


class LocalBackend:
    """Dateizugriff über das lokale Dateisystem (pathlib)."""

    def __init__(self, root: Path) -> None:
        self._root = Path(root)

    @property
    def root_name(self) -> str:
        return self._root.name

    @property
    def root_path(self) -> Path:
        return self._root

    def list_videos(self, recursive: bool = False) -> list[str]:
        videos: list[str] = []
        if recursive:
            # Hinweis: Kein zusätzlicher ``path.exists()``-Check nach rglob. Auf
            # SMB-Mounts mit NFD-kodierten Dateinamen (z. B. ``Bäbibett``)
            # schlägt der Check fälschlich fehl, obwohl rglob die Datei findet.
            for ext in VIDEO_EXTENSIONS:
                for path in self._root.rglob(f"*{ext}"):
                    try:
                        videos.append(str(path.relative_to(self._root)))
                    except (OSError, ValueError):
                        pass
        else:
            try:
                for item in self._root.iterdir():
                    try:
                        if item.is_file() and item.suffix.lower() in VIDEO_EXTENSIONS:
                            videos.append(item.name)
                    except OSError:
                        pass
            except OSError:
                pass
        return sorted(videos, key=str.lower)

    def list_subdirectories(self) -> list[str]:
        try:
            return sorted(
                [d.name for d in self._root.iterdir()
                 if d.is_dir() and not d.name.startswith(".")],
                key=str.lower,
            )
        except OSError:
            return []

    def file_exists(self, relative_path: str) -> bool:
        try:
            return (self._root / relative_path).exists()
        except OSError:
            return False

    def read_text(self, relative_path: str, encoding: str = "utf-8") -> str:
        return (self._root / relative_path).read_text(encoding=encoding)

    def run_ffprobe(self, relative_path: str, runtime: RuntimeOptions) -> str:
        file_path = self._root / relative_path
        try:
            result = subprocess.run(
                [
                    runtime.ffprobe_path,
                    "-v", "quiet",
                    "-print_format", "json",
                    "-show_format",
                    "-show_streams",
                    "-show_chapters",
                    str(file_path),
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return ""


class RcloneBackend:
    """Dateizugriff über rclone (SFTP, S3, etc.)."""

    def __init__(self, remote_path: str, runtime: RuntimeOptions) -> None:
        self._remote = remote_path.rstrip("/")
        self._rclone = runtime.rclone_path
        self._runtime = runtime

        # rclone-Verfügbarkeit prüfen
        try:
            subprocess.run([self._rclone, "version"], capture_output=True, timeout=5)
        except FileNotFoundError:
            raise RuntimeError(
                f"rclone nicht gefunden unter '{self._rclone}'. "
                "Bitte installieren: https://rclone.org/install/"
            )

        # Verzeichnislisting einmalig cachen
        self._listing: list[dict] = self._fetch_listing()

    @property
    def root_name(self) -> str:
        # "lyssach-nas:/Familienfilme/Final" → "Final"
        path_part = self._remote.split(":", 1)[1] if ":" in self._remote else self._remote
        return PurePosixPath(path_part).name or path_part

    def _fetch_listing(self) -> list[dict]:
        """Holt die vollständige Verzeichnisstruktur via rclone lsjson."""
        try:
            result = subprocess.run(
                [self._rclone, "lsjson", "--recursive", self._remote],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode != 0:
                raise RuntimeError(f"rclone lsjson fehlgeschlagen: {result.stderr.strip()}")
            return json.loads(result.stdout)
        except (subprocess.TimeoutExpired, json.JSONDecodeError) as e:
            raise RuntimeError(f"rclone Listing fehlgeschlagen: {e}")

    def list_videos(self, recursive: bool = False) -> list[str]:
        videos: list[str] = []
        for entry in self._listing:
            if entry.get("IsDir", False):
                continue
            path = entry["Path"]
            suffix = PurePosixPath(path).suffix.lower()
            if suffix not in VIDEO_EXTENSIONS:
                continue
            if not recursive and "/" in path:
                continue
            videos.append(path)
        return sorted(videos, key=str.lower)

    def list_subdirectories(self) -> list[str]:
        dirs: set[str] = set()
        for entry in self._listing:
            path = entry["Path"]
            # Direkte Unterverzeichnisse: erster Pfadteil ohne /
            if entry.get("IsDir", False) and "/" not in path.rstrip("/"):
                name = path.rstrip("/")
                if not name.startswith("."):
                    dirs.add(name)
            # Oder implizite Verzeichnisse aus Dateipfaden
            elif "/" in path:
                first_part = path.split("/")[0]
                if not first_part.startswith("."):
                    dirs.add(first_part)
        return sorted(dirs, key=str.lower)

    def file_exists(self, relative_path: str) -> bool:
        for entry in self._listing:
            if entry["Path"] == relative_path and not entry.get("IsDir", False):
                return True
        return False

    def read_text(self, relative_path: str, encoding: str = "utf-8") -> str:
        result = subprocess.run(
            [self._rclone, "cat", f"{self._remote}/{relative_path}"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            raise FileNotFoundError(f"rclone cat fehlgeschlagen: {relative_path}")
        return result.stdout

    def run_ffprobe(self, relative_path: str, runtime: RuntimeOptions) -> str:
        """Piped rclone cat → ffprobe für Metadaten-Extraktion.

        Achtung: Da ffprobe in der Pipe nicht seeken kann, muss bei MP4-Dateien
        mit moov-Atom am Ende die gesamte Datei gelesen werden. Bei großen
        Videos auf langsamen Verbindungen läuft das leicht in den Timeout.
        Für verlässliche rclone-Workflows empfiehlt sich stattdessen ein lokal
        gemountetes Volume (SMB/FUSE) mit ``LocalBackend``. Bei Timeout liefern
        wir leeren stdout zurück — der Aufrufer fällt dann auf Dateinamen als
        Titel zurück, ein einzelnes Video killt nicht den Gesamtlauf.
        """
        rclone_proc = subprocess.Popen(
            [self._rclone, "cat", f"{self._remote}/{relative_path}"],
            stdout=subprocess.PIPE,
        )
        ffprobe_proc = subprocess.Popen(
            [
                runtime.ffprobe_path,
                "-v", "quiet",
                "-print_format", "json",
                "-show_format",
                "-show_streams",
                "-show_chapters",
                "-i", "pipe:0",
            ],
            stdin=rclone_proc.stdout,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        rclone_proc.stdout.close()
        try:
            stdout, _ = ffprobe_proc.communicate(timeout=180)
        except subprocess.TimeoutExpired:
            ffprobe_proc.kill()
            rclone_proc.kill()
            ffprobe_proc.communicate()
            rclone_proc.communicate()
            return ""
        rclone_proc.wait()
        return stdout

    def sync_to_remote(self, local_dir: Path, remote_subdir: str) -> None:
        """Synchronisiert ein lokales Verzeichnis zum Remote."""
        result = subprocess.run(
            [self._rclone, "sync", str(local_dir), f"{self._remote}/{remote_subdir}"],
            capture_output=True,
            text=True,
            timeout=600,
        )
        if result.returncode != 0:
            raise RuntimeError(f"rclone sync fehlgeschlagen: {result.stderr.strip()}")

    def copy_local_to_remote(self, local_file: Path, remote_relative_path: str) -> None:
        """Kopiert eine einzelne lokale Datei zum Remote unter einem relativen Pfad."""
        result = subprocess.run(
            [self._rclone, "copyto", str(local_file), f"{self._remote}/{remote_relative_path}"],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if result.returncode != 0:
            raise RuntimeError(f"rclone copyto fehlgeschlagen: {result.stderr.strip()}")


def create_backend(path_str: str, runtime: RuntimeOptions) -> StorageBackend:
    """Erstellt das passende Backend basierend auf dem Pfad.

    Erkennung: Enthält der Pfad ':' und ist kein existierender lokaler Pfad → rclone.
    """
    if ":" in path_str and not Path(path_str).exists():
        return RcloneBackend(path_str, runtime)
    return LocalBackend(Path(path_str))
