"""CLI-Adapter für den Mediathek Manager."""

from pathlib import Path

import typer
from rich.console import Console

from ..api import (
    GenerateLibraryRequest,
    MediathekEvent,
    RuntimeOptions,
    ScanLibraryRequest,
    generate_library,
    scan_library,
)
from ..services.config_manager import load_config

app = typer.Typer(invoke_without_command=True)
stderr_console = Console(stderr=True)

config_app = typer.Typer()
app.add_typer(config_app, name="config", help="Konfiguration verwalten.")


@app.callback()
def main():
    """Mediathek Manager – Generiert statische HTML-Bibliotheken aus Videodateien."""


@app.command(name="generate")
def generate_cmd(
    source_path: str = typer.Argument(..., help="Verzeichnis oder rclone-Remote (z.B. lyssach-nas:/Filme)"),
    title: str | None = typer.Option(None, "--title", help="Bibliothekstitel (Fallback: Ordnername)"),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive", help="Unterverzeichnisse einbeziehen"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detaillierte Ausgabe auf stderr"),
):
    """Generiert eine statische HTML-Bibliothek."""
    cfg = load_config()
    runtime = RuntimeOptions(
        ffprobe_path=cfg.get("tools.ffprobe_path", "ffprobe"),
        rclone_path=cfg.get("tools.rclone_path", "rclone"),
    )

    def on_event(event: MediathekEvent) -> None:
        label = f" [{event.current}/{event.total}]" if event.current is not None else ""
        stderr_console.print(f"  {event.message}{label}")

    request = GenerateLibraryRequest(
        source_path=source_path,
        recursive=recursive,
        title=title,
    )
    result = generate_library(
        request,
        runtime,
        on_event=on_event if verbose else _minimal_event_handler,
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    # stdout: maschinenlesbarer Pfad zum Root-Index
    if result.output_dir:
        print(result.output_dir / "index.html")
    else:
        print(f"{source_path}/index.html")


@app.command(name="scan")
def scan_cmd(
    source_path: str = typer.Argument(..., help="Verzeichnis oder rclone-Remote (z.B. lyssach-nas:/Filme)"),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive", help="Unterverzeichnisse einbeziehen"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detaillierte Ausgabe auf stderr"),
):
    """Scannt ein Verzeichnis und zeigt gefundene Videos mit Metadaten."""
    cfg = load_config()
    runtime = RuntimeOptions(
        ffprobe_path=cfg.get("tools.ffprobe_path", "ffprobe"),
        rclone_path=cfg.get("tools.rclone_path", "rclone"),
    )

    def on_event(event: MediathekEvent) -> None:
        label = f" [{event.current}/{event.total}]" if event.current is not None else ""
        stderr_console.print(f"  {event.message}{label}")

    request = ScanLibraryRequest(
        source_path=source_path,
        recursive=recursive,
    )
    result = scan_library(
        request,
        runtime,
        on_event=on_event if verbose else None,
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    stderr_console.print(f"\n[bold]{len(result.videos)} Videos gefunden[/bold]\n")

    for video in result.videos:
        stderr_console.print(f"  [bold]{video.title}[/bold]")
        if video.album:
            stderr_console.print(f"    Album: {video.album}")
        if video.genre:
            stderr_console.print(f"    Genre: {video.genre}")
        if video.tags:
            stderr_console.print(f"    Tags: {', '.join(video.tags)}")
        if video.duration_seconds:
            minutes = int(video.duration_seconds // 60)
            stderr_console.print(f"    Dauer: {minutes} Min.")
        if video.chapters:
            stderr_console.print(f"    Kapitel: {len(video.chapters)}")
        stderr_console.print()


@config_app.command(name="list")
def config_list():
    """Zeigt alle Konfigurationseinstellungen."""
    cfg = load_config()
    for key, value in cfg.items():
        stderr_console.print(f"  {key} = {value}")


@config_app.command(name="set")
def config_set(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel (z.B. tools.ffprobe_path)"),
    value: str = typer.Argument(..., help="Wert"),
):
    """Setzt einen Konfigurationswert."""
    from ..services.config_manager import set_config
    set_config(key, value)
    stderr_console.print(f"  {key} = {value}")


@config_app.command(name="get")
def config_get(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel"),
):
    """Zeigt einen Konfigurationswert."""
    cfg = load_config()
    value = cfg.get(key)
    if value is None:
        stderr_console.print(f"[yellow]Nicht gesetzt:[/yellow] {key}")
        raise typer.Exit(code=1)
    print(value)


def _minimal_event_handler(event: MediathekEvent) -> None:
    """Zeigt nur Meilenstein-Events auf stderr."""
    from ..api.models import MediathekStage
    if event.stage_id in (
        MediathekStage.SCAN_COMPLETED,
        MediathekStage.RCLONE_SYNCING,
        MediathekStage.LIBRARY_COMPLETED,
    ):
        stderr_console.print(f"  {event.message}")
