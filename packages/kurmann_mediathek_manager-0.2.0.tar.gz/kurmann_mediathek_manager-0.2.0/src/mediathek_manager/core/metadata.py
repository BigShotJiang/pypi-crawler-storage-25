"""Extrahiert Metadaten aus Videodateien via StorageBackend."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import PurePosixPath
from typing import TYPE_CHECKING

import yaml

from ..api.models import Chapter, RuntimeOptions, VideoMetadata

if TYPE_CHECKING:
    from ..services.storage import StorageBackend


def extract_metadata(
    backend: StorageBackend,
    relative_path: str,
    runtime: RuntimeOptions | None = None,
) -> VideoMetadata:
    """Extrahiert Metadaten aus einer Videodatei.

    Liest eingebettete Metadaten via ffprobe (über das Backend) und
    ergänzt/überschreibt sie mit Werten aus einer optionalen YAML-Sidecar-Datei.
    """
    runtime = runtime or RuntimeOptions()
    metadata = _read_ffprobe(backend, relative_path, runtime)

    # YAML-Sidecar einlesen und mergen
    stem = PurePosixPath(relative_path).stem
    parent = str(PurePosixPath(relative_path).parent)
    prefix = f"{parent}/" if parent != "." else ""

    yaml_path = f"{prefix}{stem}.yaml"
    if backend.file_exists(yaml_path):
        try:
            yaml_text = backend.read_text(yaml_path)
            _merge_sidecar(metadata, yaml_text)
        except (OSError, FileNotFoundError):
            pass

    # Poster Sidecar erkennen (Mediathek Manager extrahiert selbst keine Vorschaubilder)
    poster_candidate = f"{prefix}{stem}-poster.jpg"
    if backend.file_exists(poster_candidate):
        metadata.poster_sidecar = poster_candidate

    return metadata


def _read_ffprobe(backend: StorageBackend, relative_path: str, runtime: RuntimeOptions) -> VideoMetadata:
    """Liest Metadaten via ffprobe über das Backend."""
    try:
        stdout = backend.run_ffprobe(relative_path, runtime)
        data = json.loads(stdout)
    except (json.JSONDecodeError, RuntimeError, FileNotFoundError):
        return VideoMetadata(
            relative_path=relative_path,
            title=PurePosixPath(relative_path).stem,
        )

    fmt = data.get("format", {})
    tags = fmt.get("tags", {})

    # Video-Stream für Auflösung finden
    resolution = None
    for stream in data.get("streams", []):
        if stream.get("codec_type") == "video":
            w = stream.get("width")
            h = stream.get("height")
            if w and h:
                resolution = f"{w}x{h}"
            break

    # Kapitel parsen
    chapters = _parse_chapters(data.get("chapters", []))

    # Tags extrahieren (Grouping-Feld, getrennt durch " / ")
    grouping = tags.get("grouping", "") or tags.get("Grouping", "")
    tag_list = [t.strip() for t in grouping.split(" / ") if t.strip()] if grouping else []

    # Dauer
    duration = None
    duration_str = fmt.get("duration")
    if duration_str:
        try:
            duration = float(duration_str)
        except ValueError:
            pass

    # Bitrate
    bitrate = None
    bitrate_str = fmt.get("bit_rate")
    if bitrate_str:
        try:
            bitrate_mbps = int(bitrate_str) / 1_000_000
            bitrate = f"{bitrate_mbps:.1f} Mbps"
        except (ValueError, TypeError):
            pass

    # Erstelldatum
    content_date = _parse_date(
        tags.get("date")
        or tags.get("creation_time")
        or tags.get("content_create_date")
    )

    return VideoMetadata(
        relative_path=relative_path,
        title=tags.get("title") or PurePosixPath(relative_path).stem,
        artist=tags.get("artist") or tags.get("album_artist"),
        album=tags.get("album"),
        genre=tags.get("genre"),
        tags=tag_list,
        description=tags.get("description"),
        long_description=tags.get("synopsis") or tags.get("long_description"),
        chapters=chapters,
        content_create_date=content_date,
        duration_seconds=duration,
        resolution=resolution,
        bitrate=bitrate,
        comment=tags.get("comment"),
    )


def _parse_chapters(chapters_data: list[dict]) -> list[Chapter]:
    """Parst ffprobe Chapter-Daten in Chapter-Objekte."""
    chapters = []
    for ch in chapters_data:
        title = ch.get("tags", {}).get("title", "")
        start = float(ch.get("start_time", 0))
        if title:
            chapters.append(Chapter(title=title, start_seconds=start))
    return chapters


def _parse_date(date_str: str | None) -> datetime | None:
    """Versucht verschiedene Datumsformate zu parsen."""
    if not date_str:
        return None

    formats = [
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
        "%Y:%m:%d %H:%M:%S",
        "%Y",
    ]
    for fmt in formats:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None


def _merge_sidecar(metadata: VideoMetadata, yaml_text: str) -> None:
    """Ergänzt/überschreibt Metadaten mit Werten aus YAML-Text."""
    try:
        data = yaml.safe_load(yaml_text)
    except yaml.YAMLError:
        return

    if not isinstance(data, dict):
        return

    field_mapping = {
        "title": "title",
        "artist": "artist",
        "album": "album",
        "genre": "genre",
        "description": "description",
        "long_description": "long_description",
        "comment": "comment",
    }
    for yaml_key, attr_name in field_mapping.items():
        if yaml_key in data and data[yaml_key] is not None:
            setattr(metadata, attr_name, data[yaml_key])

    if "tags" in data and isinstance(data["tags"], list):
        existing = set(metadata.tags)
        for tag in data["tags"]:
            if isinstance(tag, str) and tag not in existing:
                metadata.tags.append(tag)

    if "content_create_date" in data:
        parsed = _parse_date(str(data["content_create_date"]))
        if parsed:
            metadata.content_create_date = parsed
