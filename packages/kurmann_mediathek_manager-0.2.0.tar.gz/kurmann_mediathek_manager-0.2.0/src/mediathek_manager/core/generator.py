"""Generiert statische HTML-Seiten aus Videometadaten via Jinja2.

Struktur (v0.2.0):
    output_root/
    ├── index.html                   ← Root-Library
    └── mediathek/
        ├── style.css
        ├── browse/{subdir}/index.html
        ├── detail/{relative_stem}.html
        ├── tag/{slug}.html
        └── genre/{slug}.html

Poster-Vorschaubilder werden nicht vom Mediathek Manager erzeugt. Existiert
neben einem Video eine Sidecar-Datei ``{stem}-poster.jpg``, wird sie relativ
referenziert; andernfalls rendert der Generator eine Platzhalter-Card mit
zentriertem Titel (weiterhin klickbar).
"""

from __future__ import annotations

import os
import re
import unicodedata
from datetime import datetime
from pathlib import Path, PurePosixPath

from jinja2 import Environment, PackageLoader

from ..api.models import VideoMetadata


MIME_MAP = {
    ".mp4": "video/mp4",
    ".m4v": "video/mp4",
    ".mov": "video/quicktime",
    ".mkv": "video/x-matroska",
    ".webm": "video/webm",
    ".avi": "video/x-msvideo",
}


def generate_html(
    library_title: str,
    videos: list[VideoMetadata],
    subdirectories: list[str],
    output_root: Path,
) -> int:
    """Generiert alle HTML-Seiten für eine Bibliothek.

    Args:
        library_title: Der Titel der Bibliothek (aus ``--title`` oder Ordnername).
        videos: Alle Videos der Bibliothek (inklusive Unterverzeichnisse).
        subdirectories: Alle Unterverzeichnisse rekursiv (relative Pfade).
        output_root: Das Root-Verzeichnis (= Source-Dir oder Temp bei rclone).
            Hier wird ``index.html`` abgelegt und darunter ``mediathek/``.

    Returns:
        Anzahl generierter HTML-Seiten.
    """
    env = _create_jinja_env()
    output_root.mkdir(parents=True, exist_ok=True)

    mediathek_dir = output_root / "mediathek"
    (mediathek_dir / "browse").mkdir(parents=True, exist_ok=True)
    (mediathek_dir / "detail").mkdir(parents=True, exist_ok=True)
    (mediathek_dir / "tag").mkdir(parents=True, exist_ok=True)
    (mediathek_dir / "genre").mkdir(parents=True, exist_ok=True)
    # Kein poster/-Verzeichnis — der Mediathek Manager extrahiert keine Vorschaubilder.

    # Stylesheet
    (mediathek_dir / "style.css").write_text(_generate_css(), encoding="utf-8")

    pages = 0

    # 1. Root-Index
    _render_root_index(env, output_root, library_title, videos, subdirectories)
    pages += 1

    # 2. Unterverzeichnis-Indexe
    for subdir in subdirectories:
        _render_subdir_index(env, output_root, library_title, subdir, videos, subdirectories)
        pages += 1

    # 3. Detail-Seiten
    for video in videos:
        _render_detail(env, output_root, library_title, video)
        pages += 1

    # 4. Tag-Seiten (über gesamte Bibliothek)
    tag_map = _build_facet_map(videos, lambda v: v.tags)
    for tag, tag_videos in tag_map.items():
        _render_facet_page(env, output_root, library_title, "tag", "Tag", tag, tag_videos)
        pages += 1

    # 5. Genre-Seiten (über gesamte Bibliothek)
    genre_map = _build_facet_map(videos, lambda v: [v.genre] if v.genre else [])
    for genre, genre_videos in genre_map.items():
        _render_facet_page(env, output_root, library_title, "genre", "Genre", genre, genre_videos)
        pages += 1

    return pages


# ---------------------------------------------------------------------------
# Render-Funktionen
# ---------------------------------------------------------------------------


def _render_root_index(
    env: Environment,
    output_root: Path,
    library_title: str,
    videos: list[VideoMetadata],
    all_subdirs: list[str],
) -> None:
    page_path = _root_index_path(output_root)

    root_videos = sorted(
        [v for v in videos if "/" not in v.relative_path],
        key=lambda v: v.content_create_date or _epoch(),
        reverse=True,
    )
    direct_subdirs = [s for s in all_subdirs if "/" not in s]

    video_cards = _build_video_cards(page_path, root_videos, output_root)
    folder_cards = _build_folder_cards(page_path, direct_subdirs, output_root)

    # Tag-/Genre-Listen über gesamte Bibliothek
    tag_map = _build_facet_map(videos, lambda v: v.tags)
    genre_map = _build_facet_map(videos, lambda v: [v.genre] if v.genre else [])

    tag_list = [
        {
            "name": name,
            "count": len(vids),
            "url": _relpath(page_path, _tag_page_path(output_root, name)),
        }
        for name, vids in tag_map.items()
    ]
    genre_list = [
        {
            "name": name,
            "count": len(vids),
            "url": _relpath(page_path, _genre_page_path(output_root, name)),
        }
        for name, vids in genre_map.items()
    ]

    template = env.get_template("root_index.html.j2")
    html = template.render(
        library_title=library_title,
        breadcrumb=[{"label": "Start", "href": None}],
        css_href=_relpath(page_path, _stylesheet_path(output_root)),
        folder_cards=folder_cards,
        video_cards=video_cards,
        tag_list=tag_list,
        genre_list=genre_list,
    )
    page_path.parent.mkdir(parents=True, exist_ok=True)
    page_path.write_text(html, encoding="utf-8")


def _render_subdir_index(
    env: Environment,
    output_root: Path,
    library_title: str,
    subdir: str,
    all_videos: list[VideoMetadata],
    all_subdirs: list[str],
) -> None:
    page_path = _subdir_index_path(output_root, subdir)

    prefix = f"{subdir}/"
    subdir_videos = sorted(
        [
            v for v in all_videos
            if v.relative_path.startswith(prefix)
            and "/" not in v.relative_path[len(prefix):]
        ],
        key=lambda v: v.content_create_date or _epoch(),
        reverse=True,
    )
    direct_sub_subdirs = [
        s for s in all_subdirs
        if s.startswith(prefix) and "/" not in s[len(prefix):]
    ]

    video_cards = _build_video_cards(page_path, subdir_videos, output_root)
    folder_cards = _build_folder_cards(page_path, direct_sub_subdirs, output_root)

    template = env.get_template("subdir_index.html.j2")
    html = template.render(
        library_title=library_title,
        breadcrumb=_subdir_breadcrumb(page_path, subdir, output_root),
        css_href=_relpath(page_path, _stylesheet_path(output_root)),
        folder_cards=folder_cards,
        video_cards=video_cards,
        current_subdir=subdir,
    )
    page_path.parent.mkdir(parents=True, exist_ok=True)
    page_path.write_text(html, encoding="utf-8")


def _render_detail(
    env: Environment,
    output_root: Path,
    library_title: str,
    video: VideoMetadata,
) -> None:
    page_path = _detail_path(output_root, video)

    video_src = _relpath(page_path, _video_source_path(output_root, video))
    poster_src = _poster_url(page_path, video, output_root)
    video_mime = MIME_MAP.get(video.file_suffix.lower(), "video/mp4")

    # Tag-/Genre-Links vom Detail zur Facet-Seite
    tag_links = [
        {"name": tag, "url": _relpath(page_path, _tag_page_path(output_root, tag))}
        for tag in video.tags
    ]
    genre_link = None
    if video.genre:
        genre_link = {
            "name": video.genre,
            "url": _relpath(page_path, _genre_page_path(output_root, video.genre)),
        }

    template = env.get_template("detail.html.j2")
    html = template.render(
        library_title=library_title,
        breadcrumb=_detail_breadcrumb(page_path, video, output_root),
        css_href=_relpath(page_path, _stylesheet_path(output_root)),
        video=video,
        video_src=video_src,
        video_mime=video_mime,
        poster_src=poster_src,
        tag_links=tag_links,
        genre_link=genre_link,
    )
    page_path.parent.mkdir(parents=True, exist_ok=True)
    page_path.write_text(html, encoding="utf-8")


def _render_facet_page(
    env: Environment,
    output_root: Path,
    library_title: str,
    facet_type: str,
    facet_label: str,
    facet_name: str,
    facet_videos: list[VideoMetadata],
) -> None:
    if facet_type == "tag":
        page_path = _tag_page_path(output_root, facet_name)
    else:
        page_path = _genre_page_path(output_root, facet_name)

    sorted_videos = sorted(
        facet_videos,
        key=lambda v: v.content_create_date or _epoch(),
        reverse=True,
    )
    video_cards = _build_video_cards(page_path, sorted_videos, output_root)

    breadcrumb = [
        {"label": "Start", "href": _relpath(page_path, _root_index_path(output_root))},
        {"label": f"{facet_label}: {facet_name}", "href": None},
    ]

    template = env.get_template("facet_page.html.j2")
    html = template.render(
        library_title=library_title,
        breadcrumb=breadcrumb,
        css_href=_relpath(page_path, _stylesheet_path(output_root)),
        video_cards=video_cards,
        facet_label=facet_label,
        facet_name=facet_name,
    )
    page_path.parent.mkdir(parents=True, exist_ok=True)
    page_path.write_text(html, encoding="utf-8")


# ---------------------------------------------------------------------------
# View-Model Builder
# ---------------------------------------------------------------------------


def _build_video_cards(
    from_page: Path,
    videos: list[VideoMetadata],
    output_root: Path,
) -> list[dict]:
    return [
        {
            "title": v.title or v.file_stem,
            "detail_url": _relpath(from_page, _detail_path(output_root, v)),
            "poster_url": _poster_url(from_page, v, output_root),
            "duration": _format_duration(v.duration_seconds),
            "date": _format_date(v.content_create_date),
        }
        for v in videos
    ]


def _build_folder_cards(
    from_page: Path,
    subdirs: list[str],
    output_root: Path,
) -> list[dict]:
    return [
        {
            "name": PurePosixPath(sub).name,
            "url": _relpath(from_page, _subdir_index_path(output_root, sub)),
        }
        for sub in subdirs
    ]


def _build_facet_map(
    videos: list[VideoMetadata],
    extractor,
) -> dict[str, list[VideoMetadata]]:
    facet_map: dict[str, list[VideoMetadata]] = {}
    for video in videos:
        for value in extractor(video):
            if not value:
                continue
            facet_map.setdefault(value, []).append(video)
    return dict(sorted(facet_map.items(), key=lambda kv: kv[0].lower()))


# ---------------------------------------------------------------------------
# Breadcrumb-Helper
# ---------------------------------------------------------------------------


def _subdir_breadcrumb(
    page_path: Path,
    subdir: str,
    output_root: Path,
) -> list[dict]:
    crumbs = [{"label": "Start", "href": _relpath(page_path, _root_index_path(output_root))}]
    parts = subdir.split("/")
    for i, part in enumerate(parts):
        intermediate = "/".join(parts[: i + 1])
        if i == len(parts) - 1:
            crumbs.append({"label": part, "href": None})
        else:
            crumbs.append({
                "label": part,
                "href": _relpath(page_path, _subdir_index_path(output_root, intermediate)),
            })
    return crumbs


def _detail_breadcrumb(
    page_path: Path,
    video: VideoMetadata,
    output_root: Path,
) -> list[dict]:
    crumbs = [{"label": "Start", "href": _relpath(page_path, _root_index_path(output_root))}]
    parent = PurePosixPath(video.relative_path).parent
    if str(parent) != ".":
        parts = str(parent).split("/")
        for i, part in enumerate(parts):
            intermediate = "/".join(parts[: i + 1])
            crumbs.append({
                "label": part,
                "href": _relpath(page_path, _subdir_index_path(output_root, intermediate)),
            })
    crumbs.append({"label": video.title or video.file_stem, "href": None})
    return crumbs


# ---------------------------------------------------------------------------
# Pfad-Helper
# ---------------------------------------------------------------------------


def _stem_path(video: VideoMetadata) -> PurePosixPath:
    return PurePosixPath(video.relative_path).with_suffix("")


def _root_index_path(output_root: Path) -> Path:
    return output_root / "index.html"


def _subdir_index_path(output_root: Path, subdir: str) -> Path:
    return output_root / "mediathek" / "browse" / subdir / "index.html"


def _detail_path(output_root: Path, video: VideoMetadata) -> Path:
    return output_root / "mediathek" / "detail" / f"{_stem_path(video)}.html"


def _video_source_path(output_root: Path, video: VideoMetadata) -> Path:
    return output_root / video.relative_path


def _poster_url(from_page: Path, video: VideoMetadata, output_root: Path) -> str | None:
    """Liefert den relativen Poster-Pfad von ``from_page`` zum Sidecar oder ``None``.

    Der Mediathek Manager erzeugt keine Poster — referenziert wird ausschließlich
    eine existierende Sidecar-Datei ``{stem}-poster.jpg`` neben der Videodatei.
    """
    if not video.poster_sidecar:
        return None
    return _relpath(from_page, output_root / video.poster_sidecar)


def _stylesheet_path(output_root: Path) -> Path:
    return output_root / "mediathek" / "style.css"


def _tag_page_path(output_root: Path, tag: str) -> Path:
    return output_root / "mediathek" / "tag" / f"{slugify(tag)}.html"


def _genre_page_path(output_root: Path, genre: str) -> Path:
    return output_root / "mediathek" / "genre" / f"{slugify(genre)}.html"


def _relpath(from_file: Path, to_target: Path) -> str:
    """Relativer Pfad vom Verzeichnis der Ausgangsdatei zum Ziel."""
    return os.path.relpath(to_target, from_file.parent).replace(os.sep, "/")


# ---------------------------------------------------------------------------
# Jinja2-Setup & Filter
# ---------------------------------------------------------------------------


def _create_jinja_env() -> Environment:
    env = Environment(
        loader=PackageLoader("mediathek_manager", "templates"),
        autoescape=True,
    )
    env.filters["duration"] = _format_duration
    env.filters["timecode"] = _format_timecode
    env.filters["slugify"] = slugify
    env.filters["date"] = _format_date
    return env


def slugify(text: str) -> str:
    """Konvertiert einen Text in einen URL-sicheren Slug.

    Beispiel: 'Gesundheit & Psychologie' → 'gesundheit-psychologie'
    """
    replacements = {"ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss"}
    for old, new in replacements.items():
        text = text.replace(old, new).replace(old.upper(), new.capitalize())
    text = unicodedata.normalize("NFKD", text)
    text = text.encode("ascii", "ignore").decode("ascii")
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", "-", text)
    text = text.strip("-")
    text = re.sub(r"-+", "-", text)
    return text


def _format_duration(seconds: float | None) -> str:
    if seconds is None:
        return ""
    total = int(seconds)
    h, remainder = divmod(total, 3600)
    m, s = divmod(remainder, 60)
    if h > 0:
        return f"{h} Std. {m} Min."
    if m > 0:
        return f"{m} Min. {s} Sek."
    return f"{s} Sek."


def _format_timecode(seconds: float | None) -> str:
    """Formatiert Sekunden als MM:SS oder HH:MM:SS (für Kapitel-Timecodes)."""
    if seconds is None:
        return "00:00"
    total = int(seconds)
    h, remainder = divmod(total, 3600)
    m, s = divmod(remainder, 60)
    if h > 0:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def _format_date(dt) -> str:
    if dt is None:
        return ""
    try:
        return dt.strftime("%d.%m.%Y")
    except (AttributeError, ValueError):
        return str(dt)


def _epoch() -> datetime:
    return datetime(1970, 1, 1)


# ---------------------------------------------------------------------------
# CSS
# ---------------------------------------------------------------------------


def _generate_css() -> str:
    return """\
/* Mediathek Manager – v0.2.0 */
:root {
    --bg: #0d0d0d;
    --bg-card: #1a1a1a;
    --bg-hover: #252525;
    --text: #e0e0e0;
    --text-muted: #888;
    --accent: #e67e22;
    --accent-hover: #f39c12;
    --border: #333;
    --radius: 8px;
}

* { margin: 0; padding: 0; box-sizing: border-box; }

html, body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.6;
}

a { color: var(--accent); text-decoration: none; }
a:hover { color: var(--accent-hover); }

/* Header */
.header {
    padding: 1.5rem 2rem 1rem;
    border-bottom: 1px solid var(--border);
}
.header h1 {
    font-size: 1.5rem;
    font-weight: 600;
    margin-bottom: 0.4rem;
}

/* Breadcrumb */
.breadcrumb {
    font-size: 0.85rem;
    color: var(--text-muted);
}
.breadcrumb a {
    color: var(--text-muted);
}
.breadcrumb a:hover {
    color: var(--accent);
}
.breadcrumb .sep {
    margin: 0 0.4rem;
    color: var(--border);
}
.breadcrumb .current {
    color: var(--text);
}

/* Main */
main {
    padding: 1.5rem 2rem 3rem;
    max-width: 1400px;
    margin: 0 auto;
}

main > section {
    margin-bottom: 2.5rem;
}

main > section > h2 {
    font-size: 0.9rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-muted);
    margin-bottom: 1rem;
}

/* Ordner-Kacheln */
.folder-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 1rem;
}
.folder-card {
    background: var(--bg-card);
    border-radius: var(--radius);
    padding: 1.25rem 1rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    transition: background 0.15s;
}
.folder-card:hover { background: var(--bg-hover); }
.folder-card .icon {
    font-size: 1.5rem;
    flex-shrink: 0;
}
.folder-card .name {
    color: var(--text);
    font-size: 0.95rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

/* Video-Grid */
.video-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 1.25rem;
}
.video-card {
    background: var(--bg-card);
    border-radius: var(--radius);
    overflow: hidden;
    transition: background 0.15s;
}
.video-card:hover { background: var(--bg-hover); }
.video-card a { color: inherit; display: block; }
.video-card .poster {
    width: 100%;
    aspect-ratio: 2/3;
    object-fit: cover;
    display: block;
    background: #222;
}
.video-card .poster-placeholder {
    width: 100%;
    aspect-ratio: 2/3;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 1rem;
    background: linear-gradient(135deg, #1e1e1e 0%, #2a2a2a 100%);
    color: var(--text);
    font-size: 0.95rem;
    font-weight: 500;
    line-height: 1.3;
    word-break: break-word;
    hyphens: auto;
    border-bottom: 1px solid var(--border);
}
.video-card:hover .poster-placeholder {
    color: var(--accent);
}
.video-card .info { padding: 0.75rem 0.85rem; }
.video-card .info h3 {
    font-size: 0.9rem;
    font-weight: 500;
    margin-bottom: 0.25rem;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
.video-card .info .meta {
    font-size: 0.75rem;
    color: var(--text-muted);
}

/* Facet-Listen (Tag/Genre auf Root) */
.facet-columns {
    columns: 2;
    column-gap: 2rem;
}
.facet-columns a {
    display: flex;
    justify-content: space-between;
    padding: 0.4rem 0;
    border-bottom: 1px solid var(--border);
    color: var(--text);
    break-inside: avoid;
}
.facet-columns a:hover { color: var(--accent); }
.facet-columns .count {
    color: var(--text-muted);
    font-size: 0.85rem;
}

/* Detail-Seite */
.detail {
    max-width: 960px;
    margin: 0 auto;
}
.detail h1 {
    font-size: 1.8rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
}
.detail .detail-meta {
    color: var(--text-muted);
    font-size: 0.9rem;
    margin-bottom: 1.25rem;
}
.detail video {
    width: 100%;
    aspect-ratio: 16/9;
    background: #000;
    border-radius: var(--radius);
    margin-bottom: 1.5rem;
}

.tag-row {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin: 1rem 0;
}
.tag-chip {
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: 999px;
    padding: 0.3rem 0.85rem;
    font-size: 0.8rem;
    color: var(--text-muted);
    transition: all 0.15s;
}
.tag-chip:hover {
    border-color: var(--accent);
    color: var(--accent);
}

.description {
    margin: 1.5rem 0;
    line-height: 1.75;
}
.description.short { color: var(--text); font-size: 1rem; }
.description.long { color: var(--text-muted); font-size: 0.95rem; }
.description.long h2 {
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-muted);
    margin-bottom: 0.75rem;
}
.description p { margin-bottom: 0.75rem; }

.chapters h2 {
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: var(--text-muted);
    margin-bottom: 0.75rem;
}
.chapters ul { list-style: none; }
.chapters li {
    border-bottom: 1px solid var(--border);
}
.chapters a {
    display: flex;
    gap: 0.85rem;
    padding: 0.6rem 0;
    color: var(--text);
    transition: color 0.15s;
}
.chapters a:hover { color: var(--accent); }
.chapters .tc {
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    font-size: 0.85rem;
    color: var(--accent);
    min-width: 4.5rem;
}

.tech-info {
    margin: 1.5rem 0;
    padding: 1rem 1.25rem;
    background: var(--bg-card);
    border-radius: var(--radius);
    font-size: 0.85rem;
}
.tech-info dt {
    color: var(--text-muted);
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    margin-top: 0.6rem;
}
.tech-info dt:first-child { margin-top: 0; }
.tech-info dd { margin-bottom: 0.1rem; }

@media (max-width: 768px) {
    main { padding: 1rem; }
    .header { padding: 1rem; }
    .video-grid { grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 0.75rem; }
    .folder-grid { grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); }
    .facet-columns { columns: 1; }
    .detail h1 { font-size: 1.4rem; }
}
"""
