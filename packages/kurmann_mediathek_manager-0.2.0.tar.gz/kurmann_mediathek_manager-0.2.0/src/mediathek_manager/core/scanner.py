"""Scannt Verzeichnisse nach Videodateien über das StorageBackend."""

from __future__ import annotations

from pathlib import PurePosixPath
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..services.storage import StorageBackend


def scan_videos(backend: StorageBackend, recursive: bool = False) -> list[str]:
    """Findet alle Videodateien über das Backend.

    Returns:
        Sortierte Liste relativer Pfade.
    """
    return backend.list_videos(recursive=recursive)


def find_subdirectories(backend: StorageBackend) -> list[str]:
    """Findet direkte Unterverzeichnisse (ohne versteckte)."""
    return backend.list_subdirectories()


def find_all_subdirectories(backend: StorageBackend) -> list[str]:
    """Findet alle Unterverzeichnisse rekursiv, die Videos enthalten (direkt oder transitiv).

    Leitet die Verzeichnisstruktur aus der rekursiven Videoliste ab. Enthält auch
    Zwischenverzeichnisse (z. B. ``"Familie"``, wenn nur ``"Familie/2024/video.m4v"``
    existiert).

    Returns:
        Sortierte Liste relativer Verzeichnispfade, z. B. ``["Familie", "Familie/2024", "Ferien"]``.
    """
    video_paths = backend.list_videos(recursive=True)
    subdirs: set[str] = set()
    for path in video_paths:
        parent = PurePosixPath(path).parent
        while str(parent) not in (".", ""):
            subdirs.add(str(parent))
            parent = parent.parent
    return sorted(subdirs, key=str.lower)
