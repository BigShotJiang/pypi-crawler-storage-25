"""Request/Result-Modelle und Datenstrukturen für die Public API."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from pathlib import Path, PurePosixPath


@dataclass
class Chapter:
    """Ein Kapitel innerhalb eines Videos."""

    title: str
    start_seconds: float


@dataclass
class VideoMetadata:
    """Gesammelte Metadaten eines Videos aus eingebetteten Daten und optionalem YAML-Sidecar."""

    relative_path: str
    title: str
    artist: str | None = None
    album: str | None = None
    genre: str | None = None
    tags: list[str] = field(default_factory=list)
    description: str | None = None
    long_description: str | None = None
    chapters: list[Chapter] = field(default_factory=list)
    content_create_date: datetime | None = None
    duration_seconds: float | None = None
    resolution: str | None = None
    bitrate: str | None = None
    comment: str | None = None
    poster_sidecar: str | None = None
    """Relativer Pfad einer Poster-Sidecar-Datei (z. B. ``ferien/urlaub-poster.jpg``),
    falls vorhanden — sonst ``None``. Der Mediathek Manager extrahiert selbst keine
    Vorschaubilder; er konsumiert nur existierende Sidecars."""

    @property
    def file_name(self) -> str:
        return PurePosixPath(self.relative_path).name

    @property
    def file_stem(self) -> str:
        return PurePosixPath(self.relative_path).stem

    @property
    def file_suffix(self) -> str:
        return PurePosixPath(self.relative_path).suffix


@dataclass
class GenerateLibraryRequest:
    """Fachlicher Request: Bibliothek generieren."""

    source_path: str
    recursive: bool = True
    title: str | None = None


@dataclass
class GenerateLibraryResult:
    """Ergebnis der Bibliotheks-Generierung."""

    success: bool
    videos_processed: int = 0
    pages_generated: int = 0
    output_dir: Path | None = None
    error_message: str | None = None


@dataclass
class ScanLibraryRequest:
    """Fachlicher Request: Verzeichnis scannen."""

    source_path: str
    recursive: bool = True


@dataclass
class ScanLibraryResult:
    """Ergebnis des Scans."""

    success: bool
    videos: list[VideoMetadata] = field(default_factory=list)
    error_message: str | None = None


@dataclass
class RuntimeOptions:
    """Technische Laufzeitoptionen, getrennt vom fachlichen Request."""

    ffprobe_path: str = "ffprobe"
    rclone_path: str = "rclone"


class MediathekStage(StrEnum):
    """Stabile Bezeichner für Event-Stufen."""

    SCAN_STARTED = "scan_started"
    SCAN_COMPLETED = "scan_completed"
    METADATA_READING = "metadata_reading"
    HTML_GENERATING = "html_generating"
    RCLONE_SYNCING = "rclone_syncing"
    LIBRARY_COMPLETED = "library_completed"


@dataclass
class MediathekEvent:
    """Strukturiertes Event für Fortschrittsanzeige."""

    stage_id: MediathekStage
    message: str
    current: int | None = None
    total: int | None = None
