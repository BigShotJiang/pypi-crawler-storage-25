"""Öffentliche API des Mediathek Managers."""

from .facade import generate_library, scan_library
from .models import (
    Chapter,
    GenerateLibraryRequest,
    GenerateLibraryResult,
    MediathekEvent,
    MediathekStage,
    RuntimeOptions,
    ScanLibraryRequest,
    ScanLibraryResult,
    VideoMetadata,
)

__all__ = [
    "generate_library",
    "scan_library",
    "Chapter",
    "GenerateLibraryRequest",
    "GenerateLibraryResult",
    "MediathekEvent",
    "MediathekStage",
    "RuntimeOptions",
    "ScanLibraryRequest",
    "ScanLibraryResult",
    "VideoMetadata",
]
