"""API-Fassade – öffentliche Einstiegspunkte für den Mediathek Manager."""

from __future__ import annotations

import shutil
import tempfile
from collections.abc import Callable
from pathlib import Path, PurePosixPath

from .models import (
    GenerateLibraryRequest,
    GenerateLibraryResult,
    MediathekEvent,
    MediathekStage,
    RuntimeOptions,
    ScanLibraryRequest,
    ScanLibraryResult,
    VideoMetadata,
)


def scan_library(
    request: ScanLibraryRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediathekEvent], None] | None = None,
) -> ScanLibraryResult:
    """Scannt ein Verzeichnis und gibt Metadaten aller gefundenen Videos zurück."""
    runtime = runtime or RuntimeOptions()
    try:
        from ..services.storage import create_backend
        from ..core.scanner import scan_videos
        from ..core.metadata import extract_metadata

        backend = create_backend(request.source_path, runtime)
        video_paths = scan_videos(backend, recursive=request.recursive)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_COMPLETED,
                message=f"{len(video_paths)} Videodateien gefunden",
            ))

        videos: list[VideoMetadata] = []
        for i, rp in enumerate(video_paths):
            if on_event:
                on_event(MediathekEvent(
                    stage_id=MediathekStage.METADATA_READING,
                    message=f"Lese Metadaten: {PurePosixPath(rp).name}",
                    current=i + 1,
                    total=len(video_paths),
                ))
            metadata = extract_metadata(backend, rp, runtime)
            videos.append(metadata)

        return ScanLibraryResult(success=True, videos=videos)

    except Exception as e:
        return ScanLibraryResult(success=False, error_message=str(e))


def generate_library(
    request: GenerateLibraryRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediathekEvent], None] | None = None,
) -> GenerateLibraryResult:
    """Generiert eine statische HTML-Bibliothek aus einem Videoverzeichnis.

    Erzeugt eine einzelne Bibliothek mit Root = ``source_path``. Im Root-Verzeichnis
    liegt nur ``index.html`` (neben den Videos); alle weiteren HTML-Dateien, Poster
    und CSS liegen unter ``mediathek/``. Die Hierarchie wird gespiegelt.
    """
    runtime = runtime or RuntimeOptions()
    try:
        from ..services.storage import create_backend, RcloneBackend
        from ..core.scanner import scan_videos, find_all_subdirectories
        from ..core.metadata import extract_metadata
        from ..core.generator import generate_html

        backend = create_backend(request.source_path, runtime)
        is_remote = isinstance(backend, RcloneBackend)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_STARTED,
                message=f"Scanne {request.source_path}",
            ))

        # Alle Videos rekursiv sammeln (oder nur Root bei --no-recursive)
        video_paths = scan_videos(backend, recursive=request.recursive)
        subdirectories = find_all_subdirectories(backend) if request.recursive else []

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_COMPLETED,
                message=f"{len(video_paths)} Videos, {len(subdirectories)} Unterverzeichnisse",
            ))

        # Metadaten extrahieren
        videos: list[VideoMetadata] = []
        for i, rp in enumerate(video_paths):
            if on_event:
                on_event(MediathekEvent(
                    stage_id=MediathekStage.METADATA_READING,
                    message=f"Lese Metadaten: {PurePosixPath(rp).name}",
                    current=i + 1,
                    total=len(video_paths),
                ))
            metadata = extract_metadata(backend, rp, runtime)
            videos.append(metadata)

        # Output-Root bestimmen
        if is_remote:
            output_root = Path(tempfile.mkdtemp(prefix="mediathek-"))
        else:
            output_root = Path(request.source_path)

        # HTML generieren
        # Hinweis: Der Mediathek Manager extrahiert keine Vorschaubilder.
        # Poster werden als Sidecar (``{stem}-poster.jpg``) erwartet; falls keiner
        # existiert, rendert der Generator eine Platzhalter-Card mit zentriertem Titel.
        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.HTML_GENERATING,
                message="Generiere HTML-Seiten",
            ))
        library_title = request.title or backend.root_name
        pages_generated = generate_html(
            library_title=library_title,
            videos=videos,
            subdirectories=subdirectories,
            output_root=output_root,
        )

        # Für rclone: Output (index.html + mediathek/) zurück zum Remote synchronisieren
        if is_remote:
            if on_event:
                on_event(MediathekEvent(
                    stage_id=MediathekStage.RCLONE_SYNCING,
                    message=f"Synchronisiere Mediathek zu {request.source_path}",
                ))
            _sync_generated_files_to_remote(backend, output_root)
            shutil.rmtree(output_root, ignore_errors=True)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.LIBRARY_COMPLETED,
                message=f"Bibliothek generiert: {request.source_path}",
            ))

        return GenerateLibraryResult(
            success=True,
            videos_processed=len(videos),
            pages_generated=pages_generated,
            output_dir=output_root if not is_remote else None,
        )

    except Exception as e:
        return GenerateLibraryResult(success=False, error_message=str(e))


def _sync_generated_files_to_remote(backend, output_root: Path) -> None:
    """Synchronisiert generierte Dateien (index.html + mediathek/) auf das Remote.

    Kopiert ``index.html`` direkt und synct ``mediathek/`` rekursiv. Videos im Temp
    sind nicht vorhanden — es werden nur die neu erzeugten Artefakte übertragen.
    """
    index_file = output_root / "index.html"
    mediathek_dir = output_root / "mediathek"

    if index_file.exists():
        backend.copy_local_to_remote(index_file, "index.html")
    if mediathek_dir.exists():
        backend.sync_to_remote(mediathek_dir, "mediathek")
