import unittest
from unittest.mock import patch

from dta_utils_python import log_audit_event
from dta_utils_python.config.audit import AuditConfig


class DummyAuditCfgEnabled:
    enabled = True
    ignored_paths = []


class DummyAuditCfgDisabled:
    enabled = False
    ignored_paths = []


class DummyAuditCfgIgnored:
    enabled = True
    ignored_paths = ["/api"]


class DummyAuditCfgIgnoreSpecific:
    enabled = True
    ignored_paths = ["/ignore"]


class DummySettingsEnabled:
    audit = DummyAuditCfgEnabled()


class DummySettingsDisabled:
    audit = DummyAuditCfgDisabled()


class DummySettingsIgnored:
    audit = DummyAuditCfgIgnored()


class DummySettingsIgnoreSpecific:
    audit = DummyAuditCfgIgnoreSpecific()


class TestAuditConfig(unittest.TestCase):
    @patch.dict("os.environ", {}, clear=True)
    def test_enabled_default_true(self):
        cfg = AuditConfig()
        self.assertTrue(cfg.enabled)

    @patch.dict("os.environ", {}, clear=True)
    def test_enabled_false(self):
        cfg = AuditConfig(enabled=False)
        self.assertFalse(cfg.enabled)

    @patch.dict("os.environ", {}, clear=True)
    def test_ignored_paths_default(self):
        cfg = AuditConfig()
        self.assertIn("/healthcheck", cfg.ignored_paths)

    @patch.dict("os.environ", {}, clear=True)
    def test_ignored_paths_custom(self):
        cfg = AuditConfig(ignored_paths=["/foo", "/bar"])
        self.assertIn("/foo", cfg.ignored_paths)
        self.assertIn("/bar", cfg.ignored_paths)


class TestLogAuditEvent(unittest.TestCase):
    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_should_audit_path(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsIgnoreSpecific()

        log_audit_event("/not-ignored", "GET")

        mock_logger.info.assert_called_once()

    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_should_not_audit_ignored_path(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsIgnoreSpecific()

        log_audit_event("/ignore/something", "GET")

        mock_logger.info.assert_not_called()

    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_with_list_context(self, mock_logger):
        context = {"ids": [1, 2, 3]}

        log_audit_event("/api/test", "POST", context)

        mock_logger.info.assert_called_once()
        _, kwargs = mock_logger.info.call_args

        self.assertEqual(kwargs["extra"]["ctx_ids"], [1, 2, 3])

    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_with_float_context(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsEnabled()
        context = {"score": 9.8}

        log_audit_event("/api/test", "POST", context)

        mock_logger.info.assert_called_once()
        _, kwargs = mock_logger.info.call_args

        self.assertEqual(kwargs["extra"]["ctx_score"], 9.8)

    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_with_nested_dict_context(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsEnabled()
        context = {"user": {"id": 1, "name": "alice"}}

        log_audit_event("/api/test", "POST", context)

        mock_logger.info.assert_called_once()
        _, kwargs = mock_logger.info.call_args

        self.assertEqual(
            kwargs["extra"]["ctx_user"],
            {"id": 1, "name": "alice"},
        )

    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_similar_prefix_not_ignored(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsIgnored()

        log_audit_event("/apiary", "GET")

        mock_logger.info.assert_called_once()

    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_basic_log(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsEnabled()

        log_audit_event("/api/test", "GET")

        mock_logger.info.assert_called_once()
        args, kwargs = mock_logger.info.call_args

        self.assertEqual(args[0], "http_request_audited")
        self.assertEqual(kwargs["extra"]["path"], "/api/test")
        self.assertEqual(kwargs["extra"]["method"], "GET")
        self.assertEqual(kwargs["extra"]["logger"], "audit")

    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_with_context(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsEnabled()

        context = {
            "user": "alice",
            "success": True,
        }

        log_audit_event("/api/test", "POST", context)

        mock_logger.info.assert_called_once()
        _, kwargs = mock_logger.info.call_args

        self.assertEqual(kwargs["extra"]["ctx_user"], "alice")
        self.assertTrue(kwargs["extra"]["ctx_success"])

    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_disabled_audit(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsDisabled()

        log_audit_event("/api/test", "GET")

        mock_logger.info.assert_not_called()

    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_ignored_path(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsIgnored()

        log_audit_event("/api/test", "GET")

        mock_logger.info.assert_not_called()


class TestAuditFallback(unittest.TestCase):
    @patch("dta_utils_python.audit.audit.get_settings", return_value=None)
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_get_settings_none(self, mock_logger, _mock_get_settings):
        log_audit_event("/api/test", "GET")

        mock_logger.info.assert_not_called()

    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_missing_audit_cfg(self, mock_logger, mock_get_settings):
        class DummySettings:
            pass

        mock_get_settings.return_value = DummySettings()

        log_audit_event("/api/test", "GET")

        mock_logger.info.assert_not_called()


class TestAuditOverwrite(unittest.TestCase):
    @patch("dta_utils_python.audit.audit.get_settings")
    @patch("dta_utils_python.audit.audit.audit_logger")
    def test_overwrite_path_method(self, mock_logger, mock_get_settings):
        mock_get_settings.return_value = DummySettingsEnabled()

        context = {
            "path": "/malicious",
            "method": "DELETE",
        }

        log_audit_event("/api/real", "POST", context)

        mock_logger.info.assert_called_once()
        _, kwargs = mock_logger.info.call_args

        self.assertEqual(kwargs["extra"]["path"], "/api/real")
        self.assertEqual(kwargs["extra"]["method"], "POST")

        self.assertEqual(kwargs["extra"]["ctx_path"], "/malicious")
        self.assertEqual(kwargs["extra"]["ctx_method"], "DELETE")


if __name__ == "__main__":
    unittest.main()

