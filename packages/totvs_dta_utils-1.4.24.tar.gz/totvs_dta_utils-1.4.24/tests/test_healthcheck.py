"""Tests for dta_utils_python.healthcheck module."""

import asyncio
import time
import unittest

from fastapi import FastAPI
from fastapi.testclient import TestClient

from dta_utils_python.healthcheck import DtaHealthCheck, create_health_router


def _make_client(checks=None, **router_kwargs) -> TestClient:
    app = FastAPI()
    app.include_router(create_health_router(readiness_checks=checks, **router_kwargs))
    return TestClient(app)


class TestLiveness(unittest.TestCase):
    def test_live_returns_200(self):
        response = _make_client().get("/health/live")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"status": "ok"})


class TestReadinessNoChecks(unittest.TestCase):
    def test_no_checks_returns_200(self):
        response = _make_client().get("/health/ready")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "ok")
        self.assertEqual(data["checks"], {})


class TestReadinessSyncChecks(unittest.TestCase):
    def test_all_ok_returns_200(self):
        checks = [
            DtaHealthCheck(name="alpha", check=lambda: True),
            DtaHealthCheck(name="beta", check=lambda: True),
        ]
        response = _make_client(checks=checks).get("/health/ready")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["status"], "ok")
        self.assertEqual(data["checks"], {"alpha": "ok", "beta": "ok"})

    def test_check_returns_false_gives_503(self):
        checks = [
            DtaHealthCheck(name="db", check=lambda: True),
            DtaHealthCheck(name="cache", check=lambda: False),
        ]
        response = _make_client(checks=checks).get("/health/ready")
        self.assertEqual(response.status_code, 503)
        data = response.json()
        self.assertEqual(data["status"], "error")
        self.assertEqual(data["checks"]["db"], "ok")
        self.assertEqual(data["checks"]["cache"], "error")

    def test_exception_gives_503_without_leaking_details(self):
        def failing_check() -> bool:
            raise RuntimeError("sensitive internal error")

        checks = [DtaHealthCheck(name="broken", check=failing_check)]
        response = _make_client(checks=checks).get("/health/ready")
        self.assertEqual(response.status_code, 503)
        data = response.json()
        self.assertEqual(data["status"], "error")
        self.assertEqual(data["checks"]["broken"], "error")
        body = str(data)
        self.assertNotIn("sensitive internal error", body)
        self.assertNotIn("RuntimeError", body)


class TestReadinessAsyncChecks(unittest.TestCase):
    def test_all_ok_returns_200(self):
        async def async_ok() -> bool:
            return True

        checks = [DtaHealthCheck(name="svc", check=async_ok)]
        response = _make_client(checks=checks).get("/health/ready")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["checks"]["svc"], "ok")

    def test_check_returns_false_gives_503(self):
        async def async_fail() -> bool:
            return False

        checks = [DtaHealthCheck(name="svc", check=async_fail)]
        response = _make_client(checks=checks).get("/health/ready")
        self.assertEqual(response.status_code, 503)

    def test_exception_gives_503_without_leaking_details(self):
        async def async_broken() -> bool:
            raise ValueError("sensitive async error")

        checks = [DtaHealthCheck(name="svc", check=async_broken)]
        response = _make_client(checks=checks).get("/health/ready")
        self.assertEqual(response.status_code, 503)
        body = str(response.json())
        self.assertNotIn("sensitive async error", body)
        self.assertNotIn("ValueError", body)


class TestReadinessTimeout(unittest.TestCase):
    def test_sync_check_timeout_gives_503(self):
        def slow_sync() -> bool:
            time.sleep(5)
            return True

        checks = [DtaHealthCheck(name="slow", check=slow_sync, timeout=0.05)]
        response = _make_client(checks=checks).get("/health/ready")
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.json()["checks"]["slow"], "error")

    def test_async_check_timeout_gives_503(self):
        async def slow_async() -> bool:
            await asyncio.sleep(5)
            return True

        checks = [DtaHealthCheck(name="slow_async", check=slow_async, timeout=0.05)]
        response = _make_client(checks=checks).get("/health/ready")
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.json()["checks"]["slow_async"], "error")


class TestDuplicateCheckNames(unittest.TestCase):
    def test_duplicate_names_raise_value_error(self):
        checks = [
            DtaHealthCheck(name="db", check=lambda: True),
            DtaHealthCheck(name="db", check=lambda: True),
        ]
        with self.assertRaises(ValueError) as ctx:
            create_health_router(readiness_checks=checks)
        self.assertIn("db", str(ctx.exception))


class TestCustomPaths(unittest.TestCase):
    def test_custom_prefix(self):
        client = _make_client(prefix="/api/health")
        self.assertEqual(client.get("/api/health/live").status_code, 200)
        self.assertEqual(client.get("/api/health/ready").status_code, 200)
        self.assertEqual(client.get("/health/live").status_code, 404)

    def test_custom_live_and_ready_paths(self):
        client = _make_client(live_path="/ping", ready_path="/status")
        self.assertEqual(client.get("/health/ping").status_code, 200)
        self.assertEqual(client.get("/health/status").status_code, 200)
        self.assertEqual(client.get("/health/live").status_code, 404)
        self.assertEqual(client.get("/health/ready").status_code, 404)
