from dta_observability import get_logger

audit_logger = get_logger("audit")


from dta_utils_python.config import get_settings

def log_audit_event(
    path: str,
    method: str,
    context: dict[str, object] | None = None,
) -> None:
    try:
        settings = get_settings()
        audit_cfg = getattr(settings, "audit", None)
        if not audit_cfg or not getattr(audit_cfg, "enabled", False):
            return
        ignored_paths = getattr(audit_cfg, "ignored_paths", ["/healthcheck"])
        if any(path == p or path.startswith(p + "/") for p in ignored_paths):
            return
        payload = {"logger": "audit", "path": path, "method": method}
        if context:
            context_prefixed = {f"ctx_{k}": v for k, v in context.items()}
            payload.update(context_prefixed)
        audit_logger.info("http_request_audited", extra=payload)
    except Exception:
        return
