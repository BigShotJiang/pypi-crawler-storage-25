"""Auth/JWT exceptions; map to HTTPException in the web layer."""


class AuthError(Exception):
    """Auth/JWT validation failure (detail + status_code for HTTP mapping)."""

    def __init__(self, message: str, status_code: int = 401):
        self.detail = message
        self.status_code = status_code
        super().__init__(message)
