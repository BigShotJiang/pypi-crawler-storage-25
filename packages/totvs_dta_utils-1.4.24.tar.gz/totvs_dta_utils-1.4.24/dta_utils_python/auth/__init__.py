"""
Centralized authentication and JWT handling for DTA services.

Supports:
- DTA JWT (current): HS256, issuer dta.totvs.ai.
- Identity JWT (new): RS256 with kid, validated via JWKS.
- Shared Redis JWT cache: get/set/delete and get_identity_user_from_cache
  (all services share the same Redis instance for Identity token cache).
- Local development override (Identity): when DTA_ENVIRONMENT is "development"/"local"
  and DTA_ROLE_USER is set, get_identity_user_from_cache validates the JWT via JWKS
  and resolves tenant/role via env vars (DTA_TOTVS_TENANT_ID/DTA_TENANT_NAME, DTA_ROLE_USER).

Usage:
    from dta_utils_python.auth import (
        detect_jwt_type,
        validate_dta_jwt,
        validate_identity_jwt,
        normalize_user_data,
        validate_and_normalize,
        is_identity_token_expired,
        get_jwt_cached,
        set_jwt_cached,
        delete_jwt_cached,
        get_identity_user_from_cache,
        authorize,
        authorize_with_token,
        is_identity_super_user,
        DTARoles,
        DTAAuthMethods,
        RAC_STUDIO_NAME_TO_DTA_ROLE,
        DTA_ISSUER,
        AuthError,
    )
"""
from .cache import (
    delete_jwt_cached,
    get_identity_user_from_cache,
    get_jwt_cached,
    set_jwt_cached,
)
from .constants import (
    DTA_ISSUER,
    DTA_STUDIO_ROLE_NAMES,
    DTAAuthMethods,
    DTARoles,
    RAC_PERMISSIONS_MAPPING,
    RAC_STUDIO_NAME_TO_DTA_ROLE,
)
from .authorization import authorize, authorize_with_token, is_identity_super_user
from .exceptions import AuthError
from .expiry import is_identity_token_expired
from .jwt import (
    DEFAULT_JWKS_BASE_URL,
    IDENTITY_JWT_AUDIENCE,
    detect_jwt_type,
    get_jwks_public_key,
    normalize_user_data,
    validate_and_normalize,
    validate_dta_jwt,
    validate_identity_jwt,
)

__all__ = [
    # Authorization (shared across services)
    "authorize",
    "authorize_with_token",
    "is_identity_super_user",
    # Cache (shared Redis)
    "delete_jwt_cached",
    "get_identity_user_from_cache",
    "get_jwt_cached",
    "set_jwt_cached",
    # Constants
    "DTA_ISSUER",
    "DTA_STUDIO_ROLE_NAMES",
    "DTAAuthMethods",
    "DTARoles",
    "RAC_PERMISSIONS_MAPPING",
    "RAC_STUDIO_NAME_TO_DTA_ROLE",
    # JWT
    "DEFAULT_JWKS_BASE_URL",
    "IDENTITY_JWT_AUDIENCE",
    "detect_jwt_type",
    "get_jwks_public_key",
    "normalize_user_data",
    "validate_and_normalize",
    "validate_dta_jwt",
    "validate_identity_jwt",
    # Expiry
    "is_identity_token_expired",
    # Exceptions
    "AuthError",
]
