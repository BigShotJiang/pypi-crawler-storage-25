"""Reusable liveness and readiness health check router for FastAPI."""

import asyncio
import inspect
from dataclasses import dataclass
from typing import Awaitable, Callable, Union

from fastapi import APIRouter
from fastapi.responses import JSONResponse

CheckCallable = Callable[[], Union[bool, Awaitable[bool]]]
DEFAULT_CHECK_TIMEOUT = 2.0


@dataclass
class DtaHealthCheck:
    """A named readiness check.

    Args:
        name: Identifier shown in the readiness response.
        check: Callable that returns True on success. May be sync or async.
        timeout: Maximum seconds to wait before treating the check as failed.
    """

    name: str
    check: CheckCallable
    timeout: float = DEFAULT_CHECK_TIMEOUT


async def _run_check(hc: DtaHealthCheck) -> tuple[str, str]:
    """Run a single DtaHealthCheck and return its ``(name, status)`` pair.

    Returns ``"ok"`` if the callable returns a truthy value within the timeout,
    ``"error"`` for any failure, exception, or timeout.
    """
    try:
        if inspect.iscoroutinefunction(hc.check):
            awaitable: Awaitable[bool] = hc.check()
        else:
            awaitable = asyncio.to_thread(hc.check)
        result = await asyncio.wait_for(awaitable, timeout=hc.timeout)
        return hc.name, "ok" if result else "error"
    except Exception:
        return hc.name, "error"


def create_health_router(
    readiness_checks: list[DtaHealthCheck] | None = None,
    prefix: str = "/health",
    live_path: str = "/live",
    ready_path: str = "/ready",
) -> APIRouter:
    """Build a FastAPI router exposing liveness and readiness endpoints.

    Args:
        readiness_checks: Checks to run on ``GET {prefix}{ready_path}``.
        prefix: URL prefix shared by both endpoints (default ``"/health"``).
        live_path: Path for the liveness probe (default ``"/live"``).
        ready_path: Path for the readiness probe (default ``"/ready"``).

    Returns:
        A :class:`fastapi.APIRouter` ready to be included in any FastAPI app.

    Raises:
        ValueError: If two checks share the same name.

    Example::

        app.include_router(
            create_health_router(
                readiness_checks=[
                    DtaHealthCheck(name="db", check=ping_db),
                ]
            )
        )
    """
    checks: list[DtaHealthCheck] = readiness_checks or []
    names = [hc.name for hc in checks]
    duplicates = {n for n in names if names.count(n) > 1}
    if duplicates:
        raise ValueError(f"Duplicate check names: {sorted(duplicates)}")

    router = APIRouter(prefix=prefix)

    @router.get(live_path)
    async def liveness() -> JSONResponse:
        """Liveness probe — lightweight, no external dependency checks."""
        return JSONResponse(status_code=200, content={"status": "ok"})

    @router.get(ready_path)
    async def readiness() -> JSONResponse:
        """Readiness probe — runs all registered checks concurrently."""
        results = await asyncio.gather(*(_run_check(hc) for hc in checks))
        check_statuses = {name: status for name, status in results}
        all_ok = all(s == "ok" for s in check_statuses.values())
        return JSONResponse(
            status_code=200 if all_ok else 503,
            content={
                "status": "ok" if all_ok else "error",
                "checks": check_statuses,
            },
        )

    return router
