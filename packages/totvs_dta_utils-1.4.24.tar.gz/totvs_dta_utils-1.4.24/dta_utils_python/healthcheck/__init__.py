"""
Health check components for FastAPI applications.

Exposes standardized liveness and readiness endpoints that can be registered
in any FastAPI application with a single ``include_router`` call.

Usage::

    from dta_utils_python.healthcheck import DtaHealthCheck, create_health_router

    app.include_router(
        create_health_router(
            readiness_checks=[
                DtaHealthCheck(name="database", check=ping_db),
                DtaHealthCheck(name="redis", check=ping_redis),
            ]
        )
    )
"""

from .healthcheck import DEFAULT_CHECK_TIMEOUT, DtaHealthCheck, create_health_router

__all__ = [
    "DEFAULT_CHECK_TIMEOUT",
    "DtaHealthCheck",
    "create_health_router",
]
