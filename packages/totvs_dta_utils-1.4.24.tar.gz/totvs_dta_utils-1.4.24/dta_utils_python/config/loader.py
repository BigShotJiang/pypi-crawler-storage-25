from functools import lru_cache
from .app import AppConfig


@lru_cache
def get_settings() -> AppConfig:
    return AppConfig()