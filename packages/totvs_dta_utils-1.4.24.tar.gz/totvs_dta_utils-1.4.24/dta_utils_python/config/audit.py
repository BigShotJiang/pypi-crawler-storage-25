from pydantic_settings import BaseSettings
from pydantic import ConfigDict
from typing import List

class AuditConfig(BaseSettings):
    model_config = ConfigDict(env_prefix="AUDIT_LOGGING_")

    enabled: bool = True
    # When set via AUDIT_LOGGING_IGNORED_PATHS env var, the value replaces this
    # default entirely (pydantic-settings does not merge lists). Include all
    # desired paths explicitly, e.g. AUDIT_LOGGING_IGNORED_PATHS='["/healthcheck","/health","/custom"]'.
    ignored_paths: List[str] = ["/healthcheck", "/health"]
