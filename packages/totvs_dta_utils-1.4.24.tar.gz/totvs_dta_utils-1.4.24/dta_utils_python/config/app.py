
from pydantic_settings import BaseSettings
from pydantic import Field
from .audit import AuditConfig

class AppConfig(BaseSettings):
    audit: AuditConfig = Field(default_factory=AuditConfig)