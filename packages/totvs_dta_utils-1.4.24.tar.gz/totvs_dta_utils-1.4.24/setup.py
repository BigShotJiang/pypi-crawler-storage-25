from setuptools import setup, find_packages

readme = ""
with open("README.md") as rf:
    readme = rf.read()

setup(
    name="totvs_dta_utils",
    author="TOTVS - IDEIA",
    version="1.4.24",
    author_email="info@totvs.ai",
    python_requires=">=3.10",
    description="Lib for integration with DTA services",
    long_description=readme,
    long_description_content_type="text/markdown",
    install_requires=[],
    packages=find_packages(include=["dta_utils_python", "dta_utils_python.*"]),
    url="https://github.com/totvs-ai/dta-utils-python",
    extras_require={
        "secrets": [
            "python-dotenv>=1.0.0",
            "requests>=2.0.0"
        ],
        "apikeys": [
            "python-dotenv>=1.0.0",
            "requests>=2.0.0"
        ],
        "auth": [
            "PyJWT>=2.0.0",
            "cryptography>=3.4.0",
            "requests>=2.0.0",
            "redis>=4.0.0",
        ],
        "audit": [
            "dta-observability==0.0.16",
            "pydantic>=2.0.0",
            "pydantic-settings>=2.0.0"
        ],
        "healthcheck": [
            "fastapi>=0.100.0",
            "httpx>=0.23.0",
        ],
    },
)

