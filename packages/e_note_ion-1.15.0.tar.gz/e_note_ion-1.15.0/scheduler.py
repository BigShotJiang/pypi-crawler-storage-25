# e-note-ion.py
#
# Scheduler for sending timed messages to a Vestaboard split-flap display.
# Supports both the Note (3×15) and Flagship (6×22); defaults to Note.
#
# Content is defined in JSON files under content/contrib/ (bundled, opt-in
# via [scheduler].content_enabled in config.toml) and content/user/ (personal,
# always loaded). Each file describes one or more named templates, each with
# its own cron schedule, priority, and timing constraints. At runtime,
# scheduled messages are pushed into a priority queue and consumed by a single
# worker thread that sends them to the display one at a time, ensuring the
# physical flaps are never driven concurrently.
#
# Display model, public mode, and content selection are configured in
# config.toml under [scheduler].

import argparse
import email.message
import email.parser
import heapq
import importlib
import importlib.metadata
import json
import logging
import secrets
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from queue import Empty, PriorityQueue
from typing import Any
from urllib.parse import parse_qs, urlparse

from apscheduler.schedulers.background import BackgroundScheduler

import config as _config_mod
import health as _health_mod
import integrations.vestaboard as vestaboard
import public as _public_mod
import quiet as _quiet_mod
from exceptions import IntegrationDataUnavailableError

# When run via `python scheduler.py` or the `e-note-ion` entry point, Python
# loads this module as __main__. Integrations that do `import scheduler` (e.g.
# plex.py) would otherwise trigger a *second* import, producing a separate
# module object with its own copies of module-level globals such as
# _current_hold_supersede_tag. This line aliases __main__ → scheduler so that
# all imports share a single module object. No-op when scheduler is already
# imported normally (e.g. in tests or when imported by another module).
if __name__ == '__main__':
  sys.modules.setdefault('scheduler', sys.modules['__main__'])

logger = logging.getLogger('scheduler')


class _IndentedFormatter(logging.Formatter):
  # Prefix width for 'HH:MM:SS LEVELNAM ' (asctime=8, space=1, levelname-8=8, space=1)
  _PREFIX_WIDTH = 18

  def format(self, record: logging.LogRecord) -> str:
    msg = super().format(record)
    indent = ' ' * self._PREFIX_WIDTH
    return msg.replace('\n', '\n' + indent)


# Allowlist of valid integration names. Must be extended when a new integration
# is added to integrations/.
_KNOWN_INTEGRATIONS: frozenset[str] = frozenset(
  {
    'bart',
    'calendar',
    'discogs',
    'diving',
    'health',
    'message',
    'moon',
    'morning',
    'notion',
    'parcel',
    'plex',
    'qbittorrent',
    'scheduler',
    'trakt',
    'unraid',
    'uptimerobot',
    'weather',
    'ynab',
    'youtube',
  }
)

# Cache of loaded integration modules, keyed by name.
_integrations: dict[str, Any] = {}

# Resolved private flags for webhook-capable integrations, populated by
# _load_file.  The webhook handler checks this to set data['private'] so
# individual integrations don't need to propagate the flag themselves.
_webhook_private: dict[str, bool] = {}


def _get_integration(name: str) -> Any:
  if name not in _KNOWN_INTEGRATIONS:
    raise ValueError(f'Unknown integration: {name!r}')
  if name not in _integrations:
    logger.debug('loading integration %r', name)
    try:
      _integrations[name] = importlib.import_module(f'integrations.{name}')
    except ImportError as e:
      raise RuntimeError(
        f'Integration {name!r} is missing dependencies. '
        f'Install them with: pip install -r integrations/{name}.requirements.txt'
      ) from e
  else:
    logger.debug('integration %r already cached', name)
  return _integrations[name]


# --- Message ---

_counter = 0
_counter_lock = threading.Lock()


@dataclass
class QueuedMessage:
  # Represents a pending display message waiting in the priority queue.
  # `seq` is a monotonically increasing counter used to break priority ties
  # in favour of whichever message was scheduled earlier.
  priority: int
  seq: int
  name: str
  scheduled_at: float
  data: dict[str, Any]
  hold: int  # seconds message must stay on display
  timeout: int  # seconds message can wait in queue before being discarded
  indefinite: bool = False  # if True, hold runs until explicitly interrupted
  supersede_tag: str = ''  # if non-empty, enqueue() removes earlier same-tagged messages first

  def __lt__(self, other: 'QueuedMessage') -> bool:
    # PriorityQueue is a min-heap, so we invert priority comparison so that
    # higher numeric priority values are popped first.
    if self.priority != other.priority:
      return self.priority > other.priority  # higher priority = first
    return self.seq < other.seq  # earlier scheduled = first


@dataclass
class WebhookMessage:
  # Returned by an integration's handle_webhook() to enqueue a display message
  # triggered by an external HTTP POST. Set interrupt=True to cut the current
  # hold short so this message is shown immediately. Set indefinite=True to
  # hold until an explicit interrupt (e.g. a stop event) rather than timing
  # out at hold seconds. Set interrupt_only=True (e.g. for stop events) to
  # fire _hold_interrupt without enqueueing a new message.
  data: dict[str, Any]
  priority: int
  hold: int
  timeout: int
  name: str = ''
  interrupt: bool = False
  indefinite: bool = False
  interrupt_only: bool = False
  supersede_tag: str = ''  # if non-empty, enqueue() removes earlier same-tagged messages first


# --- Priority Queue ---

# Single shared queue consumed by the worker thread. Messages are pushed here
# by APScheduler's background threads when their cron triggers fire.
_queue: PriorityQueue[QueuedMessage] = PriorityQueue()


def enqueue(
  priority: int,
  data: dict[str, Any],
  hold: int,
  timeout: int,
  name: str = '',
  indefinite: bool = False,
  supersede_tag: str = '',
) -> None:
  global _counter
  with _counter_lock:
    seq = _counter
    _counter += 1

  msg = QueuedMessage(
    priority=priority,
    seq=seq,
    name=name,
    scheduled_at=time.monotonic(),
    data=data,
    hold=hold,
    timeout=timeout,
    indefinite=indefinite,
    supersede_tag=supersede_tag,
  )

  if supersede_tag:
    with _queue.mutex:
      before = len(_queue.queue)
      _queue.queue[:] = [m for m in _queue.queue if m.supersede_tag != supersede_tag]
      removed = before - len(_queue.queue)
      if removed:
        heapq.heapify(_queue.queue)
        logger.debug('supersede removed %d queued message(s) with tag %r', removed, supersede_tag)

  logger.debug('enqueued %s (priority=%d, seq=%d, hold=%ds, timeout=%ds)', name, priority, seq, hold, timeout)
  _queue.put(msg)


def pop_valid_message() -> QueuedMessage | None:
  """Return the highest-priority non-expired message, or None if the queue is empty.

  After the first message arrives, waits _COALESCE_WINDOW seconds so that any
  co-scheduled jobs (fired by APScheduler within milliseconds of each other) have
  time to enqueue before we commit to a winner. All candidates are collected, expired
  ones discarded, and the highest-priority valid message is returned; the rest are
  re-enqueued for the next cycle.
  """
  try:
    first = _queue.get(timeout=1)
  except Empty:
    return None

  time.sleep(_COALESCE_WINDOW)

  candidates = [first]
  while True:
    try:
      candidates.append(_queue.get_nowait())
    except Empty:
      break

  now = time.monotonic()
  valid: list[QueuedMessage] = []
  for m in candidates:
    waited = now - m.scheduled_at
    if waited <= m.timeout:
      valid.append(m)
    else:
      logger.warning('Discarding %s (waited %.1fs, timeout=%ds)', m.name, waited, m.timeout)

  if not valid:
    return None

  best = min(valid)
  for m in valid:
    if m is not best:
      _queue.put(m)
  return best


# --- Display Worker ---

_LOCK_RETRY_DELAY = 60  # seconds to wait before retrying a 423-locked send
_COALESCE_WINDOW = 0.1  # seconds to wait after first message arrives so co-scheduled jobs can enqueue
_HOLD_POLL_INTERVAL = 1.0  # seconds between priority-peek checks during hold
_INTERRUPT_PRIORITY_THRESHOLD = 8  # queued items at or above this can interrupt a hold early
_REFRESH_MIN_INTERVAL = 30  # minimum allowed refresh_interval (seconds); prevents API hammering

# Set by the webhook server when a high-priority incoming message should cut
# the current hold short. Cleared by the worker after each hold completes.
_hold_interrupt = threading.Event()

# Tracks state of the message currently being held by the worker.
# supersede_tag is '' and priority is None when the worker is idle.
_current_hold_lock = threading.Lock()
_current_hold_supersede_tag: str = ''
_current_hold_priority: int | None = None

# Tracks whether the board is currently showing private content. Defaults to
# True (safe assumption after restart — we don't know what was last displayed).
# Set True when a private message is sent, False on non-private send or clear.
_board_showing_private: bool = True


def current_hold_tag() -> str:
  """Return the supersede_tag of the message currently being held, or ''."""
  with _current_hold_lock:
    tag = _current_hold_supersede_tag
  return tag


def _current_hold_is_interruptible() -> bool:
  """Return True if the current hold's priority is below the interrupt threshold.

  Mirrors the cron-based interrupt gate: only holds with priority below
  _INTERRUPT_PRIORITY_THRESHOLD can be cut short. High-priority holds always
  run to completion. Returns True when no hold is active.
  """
  with _current_hold_lock:
    cur = _current_hold_priority
  return cur is None or cur < _INTERRUPT_PRIORITY_THRESHOLD


def fire_hold_interrupt(supersede_tag: str = '') -> None:
  """Fire the hold interrupt if the current hold matches supersede_tag or is interruptible.

  Intended for use by integration timer callbacks that enqueue directly (bypassing
  the webhook handler) and need to cut the current hold short, e.g. plex stop debounce.
  """
  same_tag = bool(supersede_tag) and supersede_tag == current_hold_tag()
  if same_tag or _current_hold_is_interruptible():
    _hold_interrupt.set()


def _get_min_hold() -> int:
  """Return the global minimum hold in seconds from config (default 60)."""
  raw = _config_mod.get_optional('scheduler', 'min_hold', '60')
  try:
    return max(0, int(raw))
  except ValueError:
    return 60


def _do_hold(
  message: 'QueuedMessage',
  min_hold: int,
  refresh_fn: Callable[[], None] | None = None,
  refresh_interval: int | None = None,
) -> None:
  """Sleep for message.hold seconds, subject to two early-exit conditions:

  1. Webhook interrupt (_hold_interrupt event set) — exits immediately at
     any point, regardless of min_hold. The webhook server only sets this
     event when the current hold's priority is below
     _INTERRUPT_PRIORITY_THRESHOLD (mirrors condition 2 below).
  2. Priority-based interruption — after min_hold seconds, if the current
     message's priority is below _INTERRUPT_PRIORITY_THRESHOLD and the
     highest-priority queued item is at or above it, exits early.

  High-priority messages (priority >= _INTERRUPT_PRIORITY_THRESHOLD) always
  run their full hold and are never interrupted by either path.

  If refresh_fn and refresh_interval are provided, refresh_fn() is called
  every refresh_interval seconds during the hold. Errors from refresh_fn are
  logged and the hold continues; the display keeps showing the last good content.

  Quiet→wake transitions are detected within ≤1s (the poll interval). When
  detected, the virtual state is sent to the board immediately and the hold
  continues normally.
  """
  hold_start = time.monotonic()
  last_refresh = hold_start
  was_quiet = _quiet_mod.is_quiet()
  while True:
    elapsed = time.monotonic() - hold_start
    remaining = message.hold - elapsed
    if remaining <= 0 and not message.indefinite:
      break

    next_wake = _HOLD_POLL_INTERVAL if message.indefinite else min(_HOLD_POLL_INTERVAL, remaining)
    if refresh_fn and refresh_interval:
      time_until_refresh = refresh_interval - (time.monotonic() - last_refresh)
      next_wake = min(next_wake, max(0.0, time_until_refresh))

    interrupted = _hold_interrupt.wait(timeout=next_wake)
    _hold_interrupt.clear()
    if interrupted:
      logger.debug('[hold] %s interrupted at %.1fs', message.name, time.monotonic() - hold_start)
      break

    if message.priority < _INTERRUPT_PRIORITY_THRESHOLD and elapsed >= min_hold:
      with _queue.mutex:
        if _queue.queue and _queue.queue[0].priority >= _INTERRUPT_PRIORITY_THRESHOLD:
          logger.debug(
            '[hold] %s preempted by higher-priority message at %.1fs',
            message.name,
            time.monotonic() - hold_start,
          )
          break

    # Detect quiet→wake transition and push the virtual state to the board
    # immediately, without breaking the hold. Subsequent refreshes (if any)
    # will write to the board directly via _do_refresh's is_quiet() check.
    now_quiet = _quiet_mod.is_quiet()
    if was_quiet and not now_quiet:
      virtual = _quiet_mod.pop_virtual_state()
      if virtual is not None:
        logger.info('[hold] quiet→wake during %s — sending virtual state to board', message.name)
        try:
          vestaboard.set_state_raw(virtual)
        except vestaboard.DuplicateContentError:
          pass
        except vestaboard.BoardLockedError:
          logger.warning('[hold] board locked on wake — virtual state discarded')
        except Exception as e:  # noqa: BLE001
          logger.error('[hold] error sending virtual state on wake: %s', e)
    was_quiet = now_quiet

    # Detect public mode activation while the board shows private content.
    # Break immediately so the worker can drain the queue or clear the board.
    if _public_mod.changed_event().is_set():
      _public_mod.changed_event().clear()
      if _board_showing_private:
        logger.info('[hold] public mode activated while private content displayed (%s) — breaking', message.name)
        break

    if refresh_fn and refresh_interval:
      now = time.monotonic()
      if now - last_refresh >= refresh_interval:
        last_refresh = now
        try:
          refresh_fn()
        except Exception as e:  # noqa: BLE001
          logger.warning('Refresh error for %s: %s', message.name, e)


def _clear_private_content() -> None:
  """Drain the queue for the next public message, or clear the board.

  Called when public mode is activated while the board shows private content.
  Skips private messages in the queue until a public one is found (put back for
  the main loop). If no public message is available, sends a blank grid to the
  board. Privacy trumps quiet mode: the blank grid is sent to the real board
  even when quiet is active.
  """
  global _board_showing_private
  found_public = False
  while True:
    try:
      m = _queue.get_nowait()
    except Empty:
      break
    m_private = m.data.get('private')
    if not m_private and m.name.startswith('webhook.'):
      m_private = _webhook_private.get(m.name.removeprefix('webhook.'), False)
    if m_private:
      logger.debug('Draining %s — private content hidden in public mode', m.name)
      continue
    _queue.put(m)
    found_public = True
    break
  if not found_public:
    logger.info('Public mode active with private content displayed — clearing board')
    try:
      blank = [[0] * vestaboard.model.cols for _ in range(vestaboard.model.rows)]
      vestaboard.set_state_raw(blank)
      _board_showing_private = False
    except Exception as e:  # noqa: BLE001
      logger.error('Error clearing board for public mode: %s', e)


def worker() -> None:
  # Single worker thread — ensures messages are sent to the Vestaboard
  # sequentially and never overlap. After sending a message, sleeps for
  # `hold` seconds before pulling the next one, giving the physical flaps
  # time to settle and the content time to be read.
  global _current_hold_supersede_tag, _current_hold_priority, _board_showing_private
  _idle_refresh_fn: Callable[[], None] | None = None
  _idle_refresh_interval: int | None = None
  _idle_last_refresh: float = 0.0
  while True:
    # Handle quiet→wake transition: send the last virtual state to the board
    # so it wakes to contextually relevant content. Detected within ≤1s of
    # the wake webhook firing (the pop_valid_message timeout).
    if not _quiet_mod.is_quiet():
      virtual = _quiet_mod.pop_virtual_state()
      if virtual is not None:
        logger.info('Quiet mode ended — sending virtual state to board')
        try:
          vestaboard.set_state_raw(virtual)
        except vestaboard.DuplicateContentError:
          pass  # content already showing
        except vestaboard.BoardLockedError:
          logger.warning('Board locked on wake — virtual state discarded')
        except Exception as e:  # noqa: BLE001
          logger.error('Error sending virtual state on wake: %s', e)

    # Public mode activated while idle — if the board shows private content,
    # drain the queue for the next public message or clear the board.
    if _public_mod.changed_event().is_set():
      _public_mod.changed_event().clear()
      if _board_showing_private:
        _idle_refresh_fn = None
        _idle_refresh_interval = None
        _clear_private_content()

    # Idle refresh: if the queue is empty and the previous integration message
    # is still on the board, keep refreshing at the same interval until a new
    # message is successfully sent. Errors are logged; the loop continues.
    if _idle_refresh_fn and _idle_refresh_interval:
      now = time.monotonic()
      if now - _idle_last_refresh >= _idle_refresh_interval:
        _idle_last_refresh = now
        with _queue.mutex:
          queue_pending = bool(_queue.queue)
        if not queue_pending:
          try:
            _idle_refresh_fn()
          except Exception as e:  # noqa: BLE001
            logger.warning('Idle refresh error: %s', e)

    message = pop_valid_message()
    if message is None:
      continue

    is_private = message.data.get('private')
    if not is_private and message.name.startswith('webhook.'):
      is_private = _webhook_private.get(message.name.removeprefix('webhook.'), False)
    if _public_mod.is_public() and is_private:
      logger.debug('Skipping %s — private content hidden in public mode', message.name)
      continue

    scheduled = datetime.fromtimestamp(time.time() - (time.monotonic() - message.scheduled_at))
    hold_desc = f'{message.hold}s (indefinite)' if message.indefinite else f'{message.hold}s'
    quiet_tag = ' [quiet]' if _quiet_mod.is_quiet() else ''
    logger.info(
      'Sending %s%s | scheduled: %s | priority: %d | hold: %s',
      message.name,
      quiet_tag,
      scheduled.strftime('%H:%M:%S'),
      message.priority,
      hold_desc,
    )
    # Set hold tracking before the set_state API call so that concurrent webhook
    # events (e.g. Plex pause arriving while now_playing is being sent to the
    # board) see the correct tag immediately rather than waiting ~1–2s for the
    # API round-trip to complete. Restored to '' in each exception path that
    # skips _do_hold so we never leave a stale tag when nothing is on the board.
    with _current_hold_lock:
      _current_hold_supersede_tag = message.supersede_tag
      _current_hold_priority = message.priority

    _health_name = message.data.get('integration', '')
    try:
      variables = message.data['variables']
      if 'integration' in message.data:
        fn_name = message.data.get('integration_fn', 'get_variables')
        variables = getattr(_get_integration(message.data['integration']), fn_name)()
      templates = message.data['templates']
      truncation = message.data.get('truncation', 'hard')
      if _quiet_mod.is_quiet():
        grid = vestaboard.render(templates, variables, truncation)
        _quiet_mod.set_virtual_state(grid)
      else:
        vestaboard.set_state(templates, variables, truncation)
      if _health_name:
        _health_mod.record_success(_health_name)
    except IntegrationDataUnavailableError as e:
      if _health_name:
        if e.expected:
          _health_mod.record_expected_empty(_health_name)
        else:
          _health_mod.record_error(_health_name, str(e))
      with _current_hold_lock:
        _current_hold_supersede_tag = ''
        _current_hold_priority = None
      logger.warning('Skipping %s: %s', message.name, e)
      continue
    except vestaboard.DuplicateContentError:
      logger.warning('Duplicate content for %s — already on board, still holding.', message.name)
      # Fall through to _do_hold(): content is already showing; we must still
      # hold it so lower-priority queued messages cannot preempt it.
    except vestaboard.BoardLockedError as e:
      with _current_hold_lock:
        _current_hold_supersede_tag = ''
        _current_hold_priority = None
      logger.warning('Board locked: %s. Retrying in %ds.', e, _LOCK_RETRY_DELAY)
      time.sleep(_LOCK_RETRY_DELAY)
      # Re-enqueue if the message hasn't exceeded its timeout.
      if time.monotonic() - message.scheduled_at <= message.timeout:
        _queue.put(message)
      continue
    except Exception as e:
      if _health_name:
        _health_mod.record_error(_health_name, str(e))
      with _current_hold_lock:
        _current_hold_supersede_tag = ''
        _current_hold_priority = None
      logger.error('Error sending to board: %s', e)
      continue

    # New message successfully sent (or DuplicateContentError fell through) —
    # track whether the board is now showing private content.
    _board_showing_private = bool(is_private)

    # Clear idle refresh state before setting up the new hold.
    _idle_refresh_fn = None
    _idle_refresh_interval = None

    _refresh_fn: Callable[[], None] | None = None
    refresh_interval = message.data.get('refresh_interval')
    if refresh_interval and 'integration' in message.data:
      _integration = _get_integration(message.data['integration'])
      _fn_name = message.data.get('integration_fn', 'get_variables')
      _templates = message.data['templates']
      _truncation = message.data.get('truncation', 'hard')

      def _do_refresh(
        _i: Any = _integration,
        _f: Any = _fn_name,
        _t: Any = _templates,
        _tr: Any = _truncation,
        _hn: str = _health_name,
      ) -> None:
        try:
          new_vars = getattr(_i, _f)()
        except IntegrationDataUnavailableError as _e:
          if _hn:
            if _e.expected:
              _health_mod.record_expected_empty(_hn)
            else:
              _health_mod.record_error(_hn, str(_e))
          raise
        except Exception as _e:
          if _hn:
            _health_mod.record_error(_hn, str(_e))
          raise
        if _hn:
          _health_mod.record_success(_hn)
        if _quiet_mod.is_quiet():
          _grid = vestaboard.render(_t, new_vars, _tr)
          _quiet_mod.set_virtual_state(_grid)
        else:
          try:
            vestaboard.set_state(_t, new_vars, _tr)
          except vestaboard.DuplicateContentError, IntegrationDataUnavailableError:
            pass

      _refresh_fn = _do_refresh

    # Clear any interrupt that fired before this hold began (e.g. the webhook
    # interrupt that preempted the previous hold and triggered enqueueing of
    # this message) so it cannot exit the new hold instantly. But if a same-tag
    # message arrived during the set_state API call above, re-fire the interrupt
    # so _do_hold exits immediately and the worker processes the newer event.
    _hold_interrupt.clear()
    if message.supersede_tag:
      with _queue.mutex:
        if any(m.supersede_tag == message.supersede_tag for m in _queue.queue):
          logger.debug('[hold] %s re-firing interrupt: same-tag message queued during set_state', message.name)
          _hold_interrupt.set()
    _do_hold(message, _get_min_hold(), refresh_fn=_refresh_fn, refresh_interval=refresh_interval)
    with _current_hold_lock:
      _current_hold_supersede_tag = ''
      _current_hold_priority = None
    logger.debug('[hold] %s hold ended, tag cleared', message.name)

    # Public mode activated while private content is on the board — drain the
    # queue for the next public message or clear the board.
    if _board_showing_private and _public_mod.is_public():
      _idle_refresh_fn = None
      _idle_refresh_interval = None
      _clear_private_content()
      continue

    # Hold expired — if this was a refresh-capable integration message, transfer
    # the refresh fn to idle state so the display keeps updating while the queue
    # is empty. Set last_refresh to 0 so the first idle refresh fires immediately.
    if _refresh_fn and refresh_interval:
      _idle_refresh_fn = _refresh_fn
      _idle_refresh_interval = refresh_interval
      _idle_last_refresh = 0.0


# --- Webhook Server ---

_MAX_WEBHOOK_BODY = 64 * 1024  # 64 KB — generous limit for any webhook payload


def _authenticate_webhook(provided: str, integration: str) -> str | None:
  """Authenticate a webhook request against named credentials.

  Returns:
    '<name>' — authenticated as the named credential
    None     — authentication failed

  Credentials are scoped to the integration: a credential's 'webhooks' list must
  include the integration name for it to be considered. Credential secrets are
  verified using argon2id hashing.
  """
  credentials = _config_mod.get_credentials(integration)
  if not credentials:
    return None

  try:
    from argon2 import PasswordHasher  # noqa: PLC0415
    from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError  # noqa: PLC0415

    ph = PasswordHasher()
    for name, cred in credentials.items():
      secret_hash = cred.get('secret_hash', '')
      if not secret_hash:
        continue
      try:
        ph.verify(secret_hash, provided)
        return name
      except VerifyMismatchError, VerificationError, InvalidHashError:
        continue
  except ImportError:
    logger.error(
      'argon2-cffi is required for named webhook credentials but is not installed; '
      'install it with: pip install argon2-cffi'
    )

  return None


def _make_webhook_handler() -> type:
  """Return a BaseHTTPRequestHandler subclass for the webhook listener."""

  class _WebhookHandler(BaseHTTPRequestHandler):
    def do_POST(self) -> None:  # noqa: N802
      # Validate path: must be /webhook/<integration>
      # Parse separately from query string so ?secret= is handled cleanly.
      parsed = urlparse(self.path)
      parts = parsed.path.strip('/').split('/')
      if len(parts) != 2 or parts[0] != 'webhook':
        self._respond(404, 'Not found')
        return

      integration_name = parts[1]

      # Accept secret from X-Webhook-Secret header (preferred) or ?secret=
      # query parameter (fallback for senders that cannot set custom headers,
      # e.g. Plex Media Server).
      header_secret = self.headers.get('X-Webhook-Secret', '')
      query_secret = parse_qs(parsed.query).get('secret', [''])[0]
      provided = header_secret or query_secret
      credential_name = _authenticate_webhook(provided, integration_name)
      if credential_name is None:
        logger.warning('Webhook: rejected request for %r — invalid or missing secret', integration_name)
        self._respond(401, 'Unauthorized')
        return

      # Validate against allowlist before any importlib call.
      if integration_name not in _KNOWN_INTEGRATIONS:
        self._respond(404, f'Unknown integration: {integration_name!r}')
        return

      # Parse body.
      try:
        content_length = min(int(self.headers.get('Content-Length') or 0), _MAX_WEBHOOK_BODY)
      except ValueError:
        content_length = 0
      body = self.rfile.read(content_length)
      content_type = self.headers.get('Content-Type', '')
      if 'multipart/form-data' in content_type:
        # Plex sends webhooks as multipart/form-data with JSON in a 'payload'
        # field. Prepend the Content-Type header to form a parseable MIME
        # message, then extract the named part.
        raw = b'Content-Type: ' + content_type.encode() + b'\r\n\r\n' + body
        msg = email.parser.BytesParser().parsebytes(raw)
        json_bytes: bytes | None = None
        if msg.is_multipart():
          for part in msg.get_payload():  # type: ignore[union-attr]
            if not isinstance(part, email.message.Message):
              continue
            if part.get_param('name', header='content-disposition') == 'payload':
              json_bytes = part.get_payload(decode=True)  # type: ignore[assignment]
              break
        if not json_bytes:
          self._respond(400, 'Missing payload field in multipart body')
          return
        try:
          payload: dict[str, Any] = json.loads(json_bytes)
        except json.JSONDecodeError:
          self._respond(400, 'Invalid JSON in payload field')
          return
      else:
        try:
          payload = json.loads(body) if body else {}
        except json.JSONDecodeError:
          self._respond(400, 'Invalid JSON')
          return

      # Load integration and check for webhook support.
      try:
        mod = _get_integration(integration_name)
      except (ValueError, RuntimeError) as e:
        self._respond(404, str(e))
        return
      if not hasattr(mod, 'handle_webhook'):
        self._respond(404, f'Integration {integration_name!r} does not support webhooks')
        return

      # Dispatch to the integration handler.
      # All integrations must accept credential_name as a keyword argument.
      try:
        result: WebhookMessage | None = mod.handle_webhook(payload, credential_name=credential_name)
      except Exception as e:  # noqa: BLE001
        _health_mod.record_error(integration_name, str(e))
        logger.error('Webhook error in %r: %s', integration_name, e)
        self._respond(500, 'Internal error')
        return

      if result is None:
        _health_mod.record_success(integration_name)
        self._respond(200, 'Discarded')
        return

      _health_mod.record_success(integration_name)

      if result.interrupt_only:
        if _current_hold_is_interruptible():
          logger.debug('[webhook] %s interrupt_only — firing hold interrupt', integration_name)
          _hold_interrupt.set()
        self._respond(200, 'Interrupted')
        return

      enqueue(
        priority=result.priority,
        data=result.data,
        hold=result.hold,
        timeout=result.timeout,
        name=result.name or f'webhook.{integration_name}',
        indefinite=result.indefinite,
        supersede_tag=result.supersede_tag,
      )
      if result.interrupt:
        # Same-tag supersede always interrupts regardless of priority threshold —
        # a source's own state transitions (e.g. Plex play→pause→stop) must always
        # cut through the prior hold from that same source.
        same_tag = bool(result.supersede_tag) and result.supersede_tag == current_hold_tag()
        if same_tag or _current_hold_is_interruptible():
          reason = 'same-tag' if same_tag else 'interruptible hold'
          logger.debug('[webhook] %s interrupt (%s) — firing hold interrupt', integration_name, reason)
          _hold_interrupt.set()

      self._respond(200, 'Enqueued')

    def do_GET(self) -> None:  # noqa: N802
      parsed = urlparse(self.path)
      if parsed.path.strip('/') != 'health':
        self._respond(404, 'Not found')
        return

      header_secret = self.headers.get('X-Webhook-Secret', '')
      query_secret = parse_qs(parsed.query).get('secret', [''])[0]
      provided = header_secret or query_secret
      credential_name = _authenticate_webhook(provided, 'health')
      if credential_name is None:
        logger.warning('Health: rejected request — invalid or missing secret')
        self._respond(401, 'Unauthorized')
        return

      summary = _health_mod.get_summary()
      status_code = 200 if summary['status'] == 'healthy' else 503
      self._respond_json(status_code, summary)

    def _respond(self, code: int, message: str) -> None:
      body = message.encode()
      self.send_response(code)
      self.send_header('Content-Type', 'text/plain')
      self.send_header('Content-Length', str(len(body)))
      self.end_headers()
      self.wfile.write(body)

    def _respond_json(self, code: int, data: dict[str, Any]) -> None:
      body = json.dumps(data, indent=2).encode()
      self.send_response(code)
      self.send_header('Content-Type', 'application/json')
      self.send_header('Content-Length', str(len(body)))
      self.end_headers()
      self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
      pass  # suppress default per-request access log lines

  return _WebhookHandler


# Integrations that get a named credential auto-generated on first startup
# if none exists yet. For message, the credential lives at
# [webhook.credentials.message.admin] and is keyed as 'admin' in get_credentials.
_WEBHOOK_AUTOGEN: dict[str, str] = {
  'diving': 'diving',
  'health': 'health',
  'message': 'admin',
  'notion': 'notion',
  'plex': 'plex',
  'scheduler': 'scheduler',
}


def _autogen_webhook_credential(integration: str, cred_name: str) -> None:
  """Auto-generate and persist a named credential for the given integration.

  Hashes a random 32-byte URL-safe secret with argon2id and writes it to
  config.toml. Message credentials are written under the nested namespace
  [webhook.credentials.message.<cred_name>]; all others go to the flat
  [webhook.credentials.<cred_name>]. The plaintext secret is logged once
  so the user can copy it into their webhook sender.
  """
  try:
    from argon2 import PasswordHasher  # noqa: PLC0415
  except ImportError:
    logger.warning(
      'argon2-cffi is required to auto-generate webhook credentials; install it with: pip install argon2-cffi'
    )
    return

  plaintext = secrets.token_urlsafe(32)
  ph = PasswordHasher()
  secret_hash = ph.hash(plaintext)
  section = (
    f'webhook.credentials.message.{cred_name}' if integration == 'message' else f'webhook.credentials.{cred_name}'
  )
  _config_mod.write_config_section(
    section,
    {'secret_hash': secret_hash, 'webhooks': [integration]},
  )
  logger.info(
    'Webhook credential auto-generated for %r and saved to config.toml '
    'as [%s]. '
    'Copy this into your webhook sender (as X-Webhook-Secret header or ?secret= query param): %s',
    integration,
    section,
    plaintext,
  )


def _start_webhook_server() -> None:
  """Start the HTTP webhook listener in a background daemon thread.

  Reads [webhook] config for port (default 8080) and bind address (default
  127.0.0.1). Authentication is handled entirely via named credentials defined
  in [webhook.credentials.*] sections of config.toml. Auto-generates a
  credential for each integration in _WEBHOOK_AUTOGEN on first startup if none
  exists yet. Raises OSError if the port is already in use.
  """
  try:
    port = int(_config_mod.get_optional('webhook', 'port', '8080'))
  except ValueError:
    port_raw = _config_mod.get_optional('webhook', 'port', '8080')
    logger.warning('invalid webhook port %r, defaulting to 8080', port_raw)
    port = 8080

  bind = _config_mod.get_optional('webhook', 'bind', '127.0.0.1')

  # Migrate old-style flat message credentials to the nested namespace (removed in 2.0).
  migrated = _config_mod.migrate_message_credentials()
  if migrated:
    logger.info(
      'Auto-migrated %d message credential(s) to webhook.credentials.message.*. '
      'No action required — your passphrases continue to work unchanged.',
      migrated,
    )

  # Auto-generate credentials for integrations that have none yet.
  for integration, cred_name in sorted(_WEBHOOK_AUTOGEN.items()):
    existing = _config_mod.get_credentials(integration)
    if integration == 'message':
      # For message, ensure the admin credential exists even when friends are present.
      needs_autogen = cred_name not in existing
    else:
      needs_autogen = not existing
    if needs_autogen:
      _autogen_webhook_credential(integration, cred_name)

  handler = _make_webhook_handler()
  server = HTTPServer((bind, port), handler)
  threading.Thread(target=server.serve_forever, daemon=True).start()
  logger.info('Webhook listener started on %s:%d', bind, port)


# --- Scheduler ---


def parse_cron(cron: str) -> dict[str, str]:
  minute, hour, day, month, day_of_week = cron.split()
  return {'minute': minute, 'hour': hour, 'day': day, 'month': month, 'day_of_week': day_of_week}


_VALID_TRUNCATION: frozenset[str] = frozenset({'hard', 'word', 'ellipsis', 'wrap_ellipsis'})


def _coerce_bool(val: object, label: str) -> bool | None:
  """Coerce a config override value to bool, warning on string input.

  Returns True/False for recognised values, None for unrecognised (caller
  ignores). Native TOML booleans pass through directly. String 'true'/'false'
  (case-insensitive) are accepted with a warning nudging toward correct TOML.
  Any other type is rejected with a warning.
  """
  if isinstance(val, bool):
    return val
  if isinstance(val, str):
    lower = val.strip().lower()
    if lower in ('true', 'false'):
      logger.warning(
        '%s should be a TOML boolean (true/false without quotes), not a string; treating as %s',
        label,
        lower,
      )
      return lower == 'true'
  logger.warning('ignoring invalid %s: %r', label, val)
  return None


def _validate_template(name: str, template: dict[str, Any]) -> None:
  """Validate a single template dict, raising ValueError with a clear message.

  Checks: schedule fields (cron str, hold/timeout non-negative int),
  priority range, truncation value, and that at least one of templates or
  integration is present. When "webhook": true is set, cron is optional —
  hold and timeout in the schedule dict still serve as webhook defaults.
  """
  is_webhook = bool(template.get('webhook', False))
  schedule = template.get('schedule')
  if not isinstance(schedule, dict):
    raise ValueError(f'{name}: missing or invalid "schedule" field')
  cron = schedule.get('cron')
  if not is_webhook:
    if not isinstance(cron, str) or not cron.strip():
      raise ValueError(f'{name}: schedule.cron must be a non-empty string')
  for field in ('hold', 'timeout'):
    val = schedule.get(field)
    if not isinstance(val, int) or val < 0:
      raise ValueError(f'{name}: schedule.{field} must be a non-negative integer, got {val!r}')

  priority = template.get('priority')
  if not isinstance(priority, int) or not (0 <= priority <= 10):
    raise ValueError(f'{name}: priority must be an integer between 0 and 10, got {priority!r}')

  truncation = template.get('truncation', 'hard')
  if truncation not in _VALID_TRUNCATION:
    valid = ', '.join(sorted(_VALID_TRUNCATION))
    raise ValueError(f'{name}: truncation must be one of {valid}, got {truncation!r}')

  refresh_interval = schedule.get('refresh_interval')
  if refresh_interval is not None:
    if not isinstance(refresh_interval, int) or refresh_interval < _REFRESH_MIN_INTERVAL:
      raise ValueError(
        f'{name}: schedule.refresh_interval must be an integer >= {_REFRESH_MIN_INTERVAL}, got {refresh_interval!r}'
      )

  has_templates = 'templates' in template
  has_integration = 'integration' in template
  if not has_templates and not has_integration:
    raise ValueError(f'{name}: must have "templates" and/or "integration"')

  integration_fn = template.get('integration_fn')
  if integration_fn is not None and not isinstance(integration_fn, str):
    raise ValueError(f'{name}: integration_fn must be a string, got {integration_fn!r}')


def _load_file(
  scheduler: BackgroundScheduler,
  content_file: Path,
) -> None:
  # Parse and validate the file before touching the scheduler so that a bad
  # file leaves existing jobs untouched.
  with open(content_file) as f:
    content = json.load(f)

  # Prefix the stem with the parent directory name (user or contrib) so that
  # files with the same name in different directories don't collide.
  stem = f'{content_file.parent.name}.{content_file.stem}'
  new_jobs = []
  webhook_only_jobs: list[tuple[str, int, dict[str, Any], dict[str, Any]]] = []
  disabled_jobs: list[str] = []
  for template_name, template in content['templates'].items():
    _validate_template(f'{stem}.{template_name}', template)
    # Check disabled overrides before building the job.
    override = _config_mod.get_schedule_override(f'{content_file.stem}.{template_name}')
    if 'disabled' in override:
      coerced = _coerce_bool(override['disabled'], f'disabled override for {stem}.{template_name}')
      if coerced is True:
        disabled_jobs.append(template_name)
        continue
    # Resolve effective private flag: config override takes precedence over JSON.
    private = template.get('private', False)
    if 'private' in override:
      coerced = _coerce_bool(override['private'], f'private override for {stem}.{template_name}')
      if coerced is not None:
        private = coerced
    priority = template['priority']
    truncation = template.get('truncation', 'hard')
    data: dict[str, Any] = {
      'templates': template.get('templates', []),
      'variables': content.get('variables', {}),
      'truncation': truncation,
    }
    if private:
      data['private'] = True
    if 'integration' in template:
      integration_name = template['integration']
      try:
        _get_integration(integration_name)
      except (ValueError, RuntimeError) as e:
        logger.warning('skipping template %s.%r — %s', stem, template_name, e)
        continue
      data['integration'] = integration_name
      _health_mod.register(integration_name)
    if 'integration_fn' in template:
      data['integration_fn'] = template['integration_fn']
    schedule = template['schedule']
    is_webhook = bool(template.get('webhook', False))
    if is_webhook and 'integration' in template:
      _webhook_private[template['integration']] = _webhook_private.get(template['integration'], False) or private
    has_cron = isinstance(schedule.get('cron'), str) and bool(schedule['cron'].strip())
    if is_webhook and not has_cron:
      webhook_only_jobs.append((f'{stem}.{template_name}', priority, data, schedule))
    else:
      new_jobs.append((f'{stem}.{template_name}', priority, data, schedule))

  # Atomically swap out the old jobs for this file.
  for job in scheduler.get_jobs():
    if job.id.startswith(f'{stem}.'):
      job.remove()

  # First pass: apply overrides and collect effective values so column widths
  # are computed from the values actually shown (not the pre-override JSON).
  effective_jobs: list[tuple[str, int, dict[str, Any], dict[str, Any]]] = []
  for job_id, priority, data, schedule in new_jobs:
    template_name = job_id[len(stem) + 1 :]
    # Merge any schedule overrides from config.toml (e.g. [bart.schedules.departures]).
    override = _config_mod.get_schedule_override(f'{content_file.stem}.{template_name}')
    effective = dict(schedule)
    for field in ('cron', 'hold', 'timeout', 'refresh_interval'):
      if field not in override:
        continue
      val = override[field]
      if field == 'cron' and isinstance(val, str) and val.strip():
        effective[field] = val
      elif field in ('hold', 'timeout') and isinstance(val, int) and val >= 0:
        effective[field] = val
      elif field == 'refresh_interval':
        if isinstance(val, int) and val >= _REFRESH_MIN_INTERVAL:
          effective[field] = val
        else:
          logger.warning('ignoring invalid refresh_interval override for %s: %r', job_id, val)
    if 'priority' in override:
      val = override['priority']
      if isinstance(val, int) and 0 <= val <= 10:
        priority = val
      else:
        logger.warning('ignoring invalid priority override for %s: %r', job_id, val)
    effective_jobs.append((job_id, priority, data, effective))

  max_name = max((len(job_id[len(stem) + 1 :]) for job_id, *_ in effective_jobs), default=0)
  max_cron = max((len(effective['cron']) for _, _, _, effective in effective_jobs), default=0)
  max_priority = max((len(str(priority)) for _, priority, _, _ in effective_jobs), default=0)
  # +1 for the 's' suffix so the whole "180s" token is padded together
  max_hold = max((len(str(effective['hold'])) + 1 for _, _, _, effective in effective_jobs), default=0)
  max_timeout = max((len(str(effective['timeout'])) + 1 for _, _, _, effective in effective_jobs), default=0)

  if effective_jobs or webhook_only_jobs or disabled_jobs:
    logger.info('Loaded %s/%s:', content_file.parent.name, content_file.name)
  for job_id, priority, data, effective in effective_jobs:
    template_name = job_id[len(stem) + 1 :]
    # Propagate effective refresh_interval (may have been set or overridden) into data.
    ri = effective.get('refresh_interval')
    if ri is not None:
      data['refresh_interval'] = ri
    elif 'refresh_interval' in data:
      del data['refresh_interval']
    scheduler.add_job(
      enqueue,
      trigger='cron',
      args=[priority, data, effective['hold'], effective['timeout'], job_id],
      id=job_id,
      **parse_cron(effective['cron']),  # type: ignore[arg-type]
    )
    logger.info(
      '  · %s  %s  %s  %s  %s',
      template_name.ljust(max_name),
      f'cron="{effective["cron"]}"'.ljust(max_cron + 7),
      f'priority={priority}'.ljust(max_priority + 9),
      f'hold={effective["hold"]}s'.ljust(max_hold + 5),
      f'timeout={effective["timeout"]}s'.ljust(max_timeout + 8),
    )

  if webhook_only_jobs:
    max_wh_name = max((len(job_id[len(stem) + 1 :]) for job_id, *_ in webhook_only_jobs), default=0)
    max_wh_hold = max((len(str(schedule['hold'])) + 1 for _, _, _, schedule in webhook_only_jobs), default=0)
    max_wh_timeout = max((len(str(schedule['timeout'])) + 1 for _, _, _, schedule in webhook_only_jobs), default=0)
    max_wh_priority = max((len(str(priority)) for _, priority, _, _ in webhook_only_jobs), default=0)
    for job_id, priority, _, schedule in webhook_only_jobs:
      template_name = job_id[len(stem) + 1 :]
      logger.info(
        '  · %s  %s  %s  %s  %s',
        template_name.ljust(max_wh_name),
        'webhook=true'.ljust(12),
        f'priority={priority}'.ljust(max_wh_priority + 9),
        f'hold={schedule["hold"]}s'.ljust(max_wh_hold + 5),
        f'timeout={schedule["timeout"]}s'.ljust(max_wh_timeout + 8),
      )

  for template_name in disabled_jobs:
    logger.info('  · %s  disabled', template_name)


def load_content(
  scheduler: BackgroundScheduler,
  content_enabled: set[str] | None = None,
) -> None:
  # Reads JSON files from content/user/ and content/contrib/.
  #
  # When content_enabled is None (key absent from config), user files always
  # load and no contrib files load — preserving the pre-filter default.
  #
  # When content_enabled is a set (key explicitly configured), the filter
  # applies to both directories: '*' enables all files; specific stems select
  # individual files from either directory.

  def _enabled(stem: str) -> bool:
    if content_enabled is None:
      return True
    return '*' in content_enabled or stem in content_enabled

  user_stems: set[str] = set()
  contrib_stems: set[str] = set()

  user_path = Path('content') / 'user'
  if user_path.is_dir():
    for f in sorted(user_path.glob('*.json')):
      if _enabled(f.stem):
        user_stems.add(f.stem)
        try:
          _load_file(scheduler, f)
        except Exception as e:  # noqa: BLE001
          logger.warning('failed to load %s: %s', f, e)

  contrib_path = Path('content') / 'contrib'
  if contrib_path.is_dir() and content_enabled:
    for f in sorted(contrib_path.glob('*.json')):
      if _enabled(f.stem):
        contrib_stems.add(f.stem)
        try:
          _load_file(scheduler, f)
        except Exception as e:  # noqa: BLE001
          logger.warning('failed to load %s: %s', f, e)

  for stem in sorted(user_stems & contrib_stems):
    logger.warning(
      '%s.json exists in both content/user/ and content/contrib/ — '
      'both loaded; rename the user file if this is unintentional',
      stem,
    )

  if content_enabled and '*' not in content_enabled:
    found = user_stems | contrib_stems
    for stem in sorted(content_enabled - found):
      logger.warning('content file not found for enabled stem %r — check [scheduler] enabled in config.toml', stem)


def _validate_startup(config_path: Path) -> None:
  """Sanity-check the config file before loading.

  Exits with a clear, actionable message on fatal errors (config path is a
  directory, missing, or empty). Warns non-fatally if the user content
  directory is empty.
  """
  if config_path.is_dir():
    print(
      f'Error: {config_path.resolve()} is a directory, not a file. '
      'Create a config.toml file (copy config.example.toml) and try again.',
      file=sys.stderr,
    )
    raise SystemExit(1)
  if not config_path.exists():
    print(
      f'Error: config.toml not found at {config_path.resolve()}. '
      'Copy config.example.toml, fill in your API keys, and try again.',
      file=sys.stderr,
    )
    raise SystemExit(1)
  if config_path.stat().st_size == 0:
    print(
      f'Error: {config_path.resolve()} is empty. Copy config.example.toml and fill in your API keys.',
      file=sys.stderr,
    )
    raise SystemExit(1)

  user_path = Path('content') / 'user'
  if user_path.is_dir() and not any(user_path.iterdir()):
    logger.warning('user content directory is empty — add JSON content files or remove the directory')


def main() -> None:
  parser = argparse.ArgumentParser(
    prog='e-note-ion',
    description='Content scheduler for Vestaboard split-flap displays.',
  )
  parser.add_argument(
    '-V',
    '--version',
    action='version',
    version=f'%(prog)s {importlib.metadata.version("e-note-ion")}',
  )
  parser.add_argument(
    '-c',
    '--config',
    type=Path,
    default=Path('config.toml'),
    metavar='PATH',
    help='path to config.toml (default: ./config.toml)',
  )
  args = parser.parse_args()

  _handler = logging.StreamHandler()
  _handler.setFormatter(
    _IndentedFormatter(
      fmt='%(asctime)s %(levelname)-8s %(message)s',
      datefmt='%H:%M:%S',
    )
  )
  logging.basicConfig(level=logging.INFO, handlers=[_handler])
  _validate_startup(args.config)
  _config_mod.load_config(args.config)
  _config_mod.migrate_quiet_config()
  _quiet_mod.init()
  _public_mod.init()
  _health_mod.init()

  log_level_str = _config_mod.get_optional('scheduler', 'log_level', 'INFO').upper()
  level = getattr(logging, log_level_str, None)
  if not isinstance(level, int):
    logger.warning('invalid log_level %r in config.toml — defaulting to INFO', log_level_str)
    level = logging.INFO
  logging.root.setLevel(level)

  model = _config_mod.get_model()
  if model == 'flagship':
    vestaboard.model = vestaboard.VestaboardModel.FLAGSHIP

  content_enabled = _config_mod.get_content_enabled()

  board_desc = 'Flagship (6×22)' if model == 'flagship' else 'Note (3×15)'
  extras: list[str] = []
  if content_enabled is None:
    extras.append('user content only')
  elif '*' in content_enabled:
    extras.append('all content')
  elif content_enabled:
    extras.append(f'content: {", ".join(sorted(content_enabled))}')
  else:
    extras.append('no content loaded')
  if _public_mod.is_public():
    extras.append('public mode')
  if _quiet_mod.is_quiet():
    extras.append('quiet mode')
  version = importlib.metadata.version('e-note-ion')
  logger.info('Starting e-note-ion v%s — %s, %s', version, board_desc, ', '.join(extras))

  logger.info('Current message:')
  try:
    logger.info('%s', vestaboard.get_state())
  except vestaboard.EmptyBoardError:
    logger.info('(no current message)')
  scheduler = BackgroundScheduler(
    misfire_grace_time=300,
    timezone=_config_mod.get_timezone(),
  )
  load_content(scheduler, content_enabled=content_enabled)
  scheduler.start()
  logger.info('Scheduler started — %d job(s) registered', len(scheduler.get_jobs()))

  loaded_integrations: set[str] = set()
  for job in scheduler.get_jobs():
    data = job.args[1]
    if 'integration' in data:
      loaded_integrations.add(data['integration'])
  for name in loaded_integrations:
    try:
      mod = _get_integration(name)
      if hasattr(mod, 'preflight'):
        mod.preflight()
    except Exception as e:  # noqa: BLE001
      logger.warning('preflight for %r failed: %s', name, e)

  threading.Thread(target=worker, daemon=True).start()
  _health_mod.start_periodic_log()

  if _config_mod.has_section('webhook'):
    _start_webhook_server()

  try:
    while True:
      time.sleep(1)
  except KeyboardInterrupt:
    _health_mod.stop_periodic_log()
    scheduler.shutdown()


if __name__ == '__main__':
  main()
