from loguru import logger

from .fetchers import fetch_nasdaq_nordic_price, fetch_yfinance_price


class Asset:
    """
    Asset class.

    Holds the name, number of units, and the :class:`.Price` of the asset.

    """

    def __init__(
        self,
        ticker,
        quantity=0,
        session=None,
        nasdaq_nordic_id=None,
        nasdaq_nordic_asset_class=None,
        name=None,
    ):
        """
        Initialization.

        Args
        ----
        - ticker (str): Ticker of the asset.
        - quantity (int, optional): Number of units of the asset. Default is zero.
        - session (optional): Requests session passed to the Nasdaq Nordic
            fetcher. Not used for yfinance (which manages its own session).
        - nasdaq_nordic_id (str, optional): Nasdaq Nordic instrument ID (e.g. "TX4856348"). If provided, price is fetched from the Nasdaq Nordic API.
        - nasdaq_nordic_asset_class (str, optional): Asset class for Nasdaq Nordic API (e.g. "ETN/ETC", "ETF", "Share"). Required when nasdaq_nordic_id is set.
        - name (str, optional): Human-readable name of the asset. Default is None.
        """

        assert ticker is not None, "ticker symbol is a mandatory argument."
        assert isinstance(quantity, int), "quantity must be integer."

        self._ticker = ticker
        self._quantity = quantity
        self._name = name

        if nasdaq_nordic_id is not None:
            assert nasdaq_nordic_asset_class is not None, (
                "nasdaq_nordic_asset_class is required when nasdaq_nordic_id is set."
            )
            logger.debug(
                "Fetching Nasdaq Nordic price for {} ({})",
                self._ticker,
                nasdaq_nordic_id,
            )
            self._price = fetch_nasdaq_nordic_price(
                nasdaq_nordic_id, nasdaq_nordic_asset_class, session=session
            )
        else:
            logger.debug("Fetching price for {}", self._ticker)
            self._price = fetch_yfinance_price(self._ticker)

    @property
    def name(self):
        """(str | None): Human-readable name of the asset."""
        return self._name

    @property
    def quantity(self):
        """(int): Number of units of the asset."""
        return self._quantity

    @quantity.setter
    def quantity(self, quantity):
        assert isinstance(quantity, int), "quantity must be integer."
        self._quantity = quantity

    @property
    def price(self):
        """
        (float): Price of the asset (in asset's own currency).
        """
        return self._price.price

    def price_in(self, currency):
        """
        Price of the asset in specified currency.

        Args:
            currency (str): Currency in which to obtain price of asset.
        """
        return self._price.price_in(currency)

    @property
    def currency(self):
        """
        (str): Currency of the asset.
        """
        return self._price.currency

    @property
    def ticker(self):
        """
        (str): Ticker of the asset.
        """
        return self._ticker

    def market_value(self):
        """
        Computes the market value of the asset.

        Returns:
            float: Market value of the asset (in asset's own currency).
        """
        return self.price * self._quantity

    def market_value_in(self, currency):
        """
        Computes the market value of the asset in specified currency.

        Args:
            currency (str): Currency in which to obtain market value.

        Returns:
            float: Market value of the asset.
        """
        return self._price.price_in(currency) * self._quantity

    def buy(self, quantity, currency=None):
        """
        Buys (or sells) a specified amount of the asset.

        Args:
            quantity (int): If positive, it is the quantity to buy. If negative, it is the quantity to sell.
            currency (str, optional): Currency in which to obtain cost. Defaults to asset's own currency.

        Returns:
            (float): Cost of the units bought in specified ``currency``.
        """
        self._quantity += quantity
        if currency is None:
            return self._price.price * quantity

        return self._price.price_in(currency) * quantity

    def cost_of(self, units, currency=None):
        """
        Computes the cost to purchase the specified number of units.

        Args:
            units (int): Units interested in purchasing.
            currency (str, optional): Currency in which to convert the cost. Default is asset's own currency.

        Returns:
            (float): Cost of the purchase.
        """
        if currency is None:
            return self.price * units

        return self.price_in(currency) * units

    @property
    def mer(self):
        return 0.0

    def __str__(self):
        # return yf.Ticker(
        #     self._ticker).info['shortName'] + " (" + self._ticker + ")"
        return f"{self._ticker:4s}  {self._quantity:4d} {self.market_value():8.2f}"
