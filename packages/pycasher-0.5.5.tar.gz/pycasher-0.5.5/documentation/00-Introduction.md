# casher — Function Result Cache with Side-Effect Capture

`casher` caches Python function results **and** their side effects
(stdout, stderr, filesystem writes). It automatically discovers file I/O
via `strace` (subprocess mode) or `sys.addaudithook` (in-process mode),
so cache invalidation happens without explicit file declarations.

Install from PyPI: `pip install pycasher`

## What it provides

- A `@cached` decorator that transparently caches any Python function.
- Automatic file I/O tracking — reads become cache keys, writes are
  restored on cache hit.
- Two-phase cache lookup: partial key (function + args) → full key
  (partial + input file hashes).
- Dependency tracking — changes to imported modules invalidate the cache.
- LRU eviction with configurable `max_cache_bytes` (default 32 GB).
  Size is measured in compressed on-disk bytes.
- Disk-space protection — stops caching when the disk is nearly full,
  auto-evicts entries when critically full.
- lz4 compression of cached data (enabled by default). Reduces disk
  usage significantly for text-heavy or repetitive results.
- `casher` CLI tool for caching arbitrary shell commands.
- `auto_cli` helper to generate argparse CLIs from decorated functions.
- Polars and pandas DataFrame serialization via Arrow IPC.
- Structured logging via loguru at INFO level.

## Cache key semantics

casher decides cache reuse in two stages:

- The **partial key** includes function identity, Python dependency hashes,
  hashed arguments, and any environment variables listed in `env_vars`.
- A cached candidate is reused only if its recorded `input_files` still exist
  and still have the same content hashes.

### `Path` arguments

- A `Path` argument that points to a **file** contributes its file content to
  the argument hash. The file's absolute location does not matter for this
  argument-level hashing.
- A `Path` argument that points to a **directory** keeps the default behavior:
  the path value itself is hashed, not a recursive directory snapshot.
- Auto-discovered files read during execution remain **path-sensitive and
  content-sensitive**.

This split keeps file arguments cache-friendly while preserving reliable
tracking for additional inputs discovered at runtime.

## Recommended patterns

- If an argument semantically means “this file's content”, pass a `Path`.
- If a function depends on extra files not passed directly as arguments, add
  them explicitly with `input_files=`.
- If a function depends on a directory tree, expand it explicitly instead of
  relying on implicit recursive directory hashing:

```python
from pathlib import Path

from casher import cached, expand_input_dir


@cached(input_files=lambda data_dir: expand_input_dir(data_dir, "*.csv"))
def load_dataset(data_dir: Path) -> int:
    return len(list(data_dir.glob("*.csv")))
```

## Configuration via environment variables

| Variable                 | Default               | Description                                        |
| ------------------------ | --------------------- | -------------------------------------------------- |
| `CASHER_CACHE_DIR`       | `~/.cache/casher`     | Cache storage directory                            |
| `CASHER_MAX_CACHE_BYTES` | `34359738368` (32 GB) | Max total cache size before LRU eviction           |
| `CASHER_STOP_CACHING`    | `95`                  | Disk usage % at which new cache writes are skipped |
| `CASHER_START_REMOVING`  | `97`                  | Disk usage % at which oldest entries are evicted   |
| `CASHER_COMPRESSION`     | `true`                | Enable lz4 compression of cached data              |

These are used when no explicit value is passed to the `@cached` decorator
or the `casher` CLI. You can also set them programmatically:

```python
from casher import configure, get_config

# Set before any @cached call — takes priority over env vars
configure(cache_dir="/data/my_cache", max_cache_bytes=10 * 1024**3)

# Adjust disk-space thresholds (percentage full)
configure(stop_caching_pct=90, start_removing_pct=95)

# Disable compression
configure(compression=False)

# Inspect effective config (override > env var > default)
print(get_config())
```

Resolution order: explicit decorator arg > `configure()` > env var > default.

## Cross-platform behavior

casher's full feature set (strace-based file tracking, `fcntl` locking)
requires Linux. On **macOS** and **Windows**, caching is automatically
disabled with a `logger.warning`. The decorated function still runs
normally — it just never caches.

## In-process vs. subprocess mode

| Aspect          | `subprocess=True` (default)                                                            | `subprocess=False`                                                              |
| --------------- | -------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| File tracking   | strace — kernel-level, catches all I/O including from C extensions and child processes | `sys.addaudithook` — Python-level, catches only `open()` calls from Python code |
| Dynamic imports | Fully captured (subprocess loads fresh)                                                | May be missed if imported after function entry                                  |
| Isolation       | Function runs in a separate process — no side effects on caller's globals              | Function runs in the same process — shared state, faster startup                |
| Overhead        | ~5–15% from strace tracing                                                             | Near-zero                                                                       |
| Requirements    | strace installed, Linux                                                                | Python 3.12+, any OS (but caching only active on Linux)                         |
| Best for        | Data pipelines, scripts with C extensions, shell commands                              | Pure-Python functions, fast inner loops, environments without strace            |

**Why not always use in-process?** The audit hook only intercepts Python's
built-in `open()`. File I/O from C extensions (numpy, pandas, polars
native readers), subprocess calls, or `os.read()`/`os.write()` is
invisible to it. strace intercepts at the kernel level, so nothing escapes.

## Limitations

- **Linux only** for caching. On macOS/Windows the decorator is a
  transparent pass-through with a one-time warning.
- **strace in Docker**: requires `--cap-add=SYS_PTRACE` or an equivalent
  seccomp profile that allows the `ptrace` syscall.
- **Security**: cache entries use pickle. Never point `cache_dir` at a
  shared or untrusted directory. Keep cache directories user-writable only.
- **strace overhead**: ~5–15% for typical data-processing functions.
  Negligible for functions taking seconds or longer. For sub-millisecond
  functions, use `subprocess=False`.
- **No exception caching.** Failed function calls are never cached.
- **No concurrent write safety** beyond `fcntl.flock`. Do not share
  cache directories across networked filesystems.

## Runtime dependencies

Only `loguru`. Polars and pandas support is optional — detected at
runtime via `type(val).__module__`.
