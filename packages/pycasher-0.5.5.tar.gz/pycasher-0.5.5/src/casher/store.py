import dataclasses
import fcntl
import json
import os
import shutil
import tempfile
from pathlib import Path
from typing import Any

from loguru import logger

from casher import eviction
from casher.compression import (
    find_file,
    read_compressed_text,
    write_compressed,
    write_compressed_text,
)
from casher.config import (
    META_FILENAME,
    OUTPUT_FILES_DIR,
    STDOUT_FILENAME,
    STDERR_FILENAME,
)
from casher.hasher import compute_file_hash
from casher.serializer import serialize_value, deserialize_value


@dataclasses.dataclass
class CacheEntry:
    return_value: Any
    stdout: str
    stderr: str
    output_files: dict[str, Path]  # relative_path → cached copy path
    input_files: dict[str, str]  # path → content hash
    created_at: float
    func_module: str
    func_name: str


def find_cached(cache_dir: Path, partial_key: str) -> tuple[CacheEntry, Path] | None:
    """Two-phase lookup: find a candidate whose input file hashes still match.
    Returns (entry, entry_dir) on hit, None on miss."""
    partial_dir = cache_dir / partial_key
    if not partial_dir.is_dir():
        return None

    for candidate_dir in partial_dir.iterdir():
        if not candidate_dir.is_dir():
            continue

        meta_path = candidate_dir / META_FILENAME
        if not meta_path.exists():
            continue

        try:
            with open(meta_path) as f:
                meta = json.load(f)
        except (json.JSONDecodeError, OSError):
            # Corruption — delete entry
            shutil.rmtree(candidate_dir, ignore_errors=True)
            continue

        # Verify input file hashes still match
        stored_input_files = meta.get("input_files", {})
        files_match = True
        for file_path_str, stored_hash in stored_input_files.items():
            file_path = Path(file_path_str)
            if not file_path.exists():
                files_match = False
                break
            current_hash = compute_file_hash([file_path])
            if current_hash != stored_hash:
                files_match = False
                break

        if not files_match:
            continue

        # Cache hit — update mtime for LRU
        os.utime(meta_path)

        # Deserialize return value
        result_meta = meta.get("result_meta", {})
        return_value = deserialize_value(result_meta, candidate_dir)

        # Read stdout/stderr (supports both compressed and plain)
        stdout_file = find_file(candidate_dir, STDOUT_FILENAME)
        stderr_file = find_file(candidate_dir, STDERR_FILENAME)
        stdout = read_compressed_text(stdout_file) if stdout_file else ""
        stderr = read_compressed_text(stderr_file) if stderr_file else ""

        # Collect output files
        output_files: dict[str, Path] = {}
        output_dir = candidate_dir / OUTPUT_FILES_DIR
        if output_dir.is_dir():
            for of in meta.get("output_files", []):
                safe_of = of.lstrip("/")
                # Check both plain and compressed variants
                cached_path = find_file(output_dir, safe_of)
                if cached_path is not None:
                    output_files[of] = cached_path

        entry = CacheEntry(
            return_value=return_value,
            stdout=stdout,
            stderr=stderr,
            output_files=output_files,
            input_files=stored_input_files,
            created_at=meta.get("created_at", 0.0),
            func_module=meta.get("func_module", ""),
            func_name=meta.get("func_name", ""),
        )
        return entry, candidate_dir

    return None


def store_result(
    cache_dir: Path,
    partial_key: str,
    file_hash: str,
    result: CacheEntry,
    max_bytes: int = 0,
) -> Path:
    """Write a cache entry. Uses atomic rename from temp dir."""
    final_dir = cache_dir / partial_key / file_hash
    cache_dir.mkdir(parents=True, exist_ok=True)

    # Disk-pressure eviction — may free space before we write
    eviction.evict_for_disk_pressure(cache_dir)

    # Skip storing if disk is still too full after eviction
    if eviction.is_disk_full(cache_dir):
        return final_dir

    # Write to temp dir first, then atomic rename
    tmp_dir = Path(tempfile.mkdtemp(dir=cache_dir, prefix=".tmp-"))
    lock_path = cache_dir / ".casher.lock"

    try:
        # Serialize return value
        result_meta = serialize_value(result.return_value, tmp_dir)

        # Write stdout/stderr (compressed if enabled)
        write_compressed_text(tmp_dir / STDOUT_FILENAME, result.stdout)
        write_compressed_text(tmp_dir / STDERR_FILENAME, result.stderr)

        # Copy output files (compressed if enabled)
        output_file_names = []
        if result.output_files:
            output_dir = tmp_dir / OUTPUT_FILES_DIR
            output_dir.mkdir(parents=True, exist_ok=True)
            for rel_path, src_path in result.output_files.items():
                safe_path = rel_path.lstrip("/")
                dest = output_dir / safe_path
                dest.parent.mkdir(parents=True, exist_ok=True)
                write_compressed(dest, Path(src_path).read_bytes())
                output_file_names.append(rel_path)

        # Write meta.json
        meta = {
            "func_module": result.func_module,
            "func_name": result.func_name,
            "created_at": result.created_at,
            "input_files": result.input_files,
            "output_files": output_file_names,
            "result_meta": result_meta,
        }
        with open(tmp_dir / META_FILENAME, "w") as f:
            json.dump(meta, f, indent=2)

        # Atomic move with file locking
        with open(lock_path, "w") as lock_file:
            fcntl.flock(lock_file, fcntl.LOCK_EX)
            try:
                final_dir.parent.mkdir(parents=True, exist_ok=True)
                if final_dir.exists():
                    shutil.rmtree(final_dir)
                os.rename(tmp_dir, final_dir)
            finally:
                fcntl.flock(lock_file, fcntl.LOCK_UN)
    except Exception:
        shutil.rmtree(tmp_dir, ignore_errors=True)
        raise

    # Trigger eviction if needed (size-based)
    eviction.evict_if_needed(cache_dir, max_bytes)
    # Trigger eviction if needed (disk-pressure)
    eviction.evict_for_disk_pressure(cache_dir)

    entry_size = eviction.get_entry_size(final_dir)
    logger.info(
        "cache stored: {}.{}() | key={}… | size={}",
        result.func_module,
        result.func_name,
        partial_key[:12],
        _human_size(entry_size),
    )

    return final_dir


def invalidate(cache_dir: Path, partial_key: str) -> bool:
    """Remove all cache entries for a partial key."""
    partial_dir = cache_dir / partial_key
    if partial_dir.is_dir():
        shutil.rmtree(partial_dir)
        return True
    return False


def clear_cache(cache_dir: Path) -> int:
    """Remove all cache entries. Returns number of entries removed."""
    count = 0
    if not cache_dir.is_dir():
        return 0
    for partial_dir in cache_dir.iterdir():
        if not partial_dir.is_dir() or partial_dir.name.startswith("."):
            continue
        for entry_dir in partial_dir.iterdir():
            if entry_dir.is_dir():
                shutil.rmtree(entry_dir)
                count += 1
        # Remove empty partial_key dir
        if partial_dir.is_dir() and not any(partial_dir.iterdir()):
            partial_dir.rmdir()
    return count


def _human_size(nbytes: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if abs(nbytes) < 1024:
            return f"{nbytes:.1f} {unit}"
        nbytes /= 1024
    return f"{nbytes:.1f} TB"
