import lz4.frame
from pathlib import Path

from casher.config import resolve_compression


def decompress_bytes(data: bytes) -> bytes:
    """Decompress lz4 frame bytes. Auto-detects whether data is compressed."""
    # lz4 frame magic number: 0x04224D18
    if len(data) >= 4 and data[:4] == b"\x04\x22\x4d\x18":
        return lz4.frame.decompress(data)
    return data


def write_compressed(path: Path, data: bytes) -> Path:
    """Write data, compressing if enabled. Appends .lz4 suffix when compressed."""
    if resolve_compression():
        path = path.with_suffix(path.suffix + ".lz4")
        path.write_bytes(lz4.frame.compress(data))
    else:
        path.write_bytes(data)
    return path


def read_compressed(path: Path) -> bytes:
    """Read data, decompressing if path has .lz4 suffix or data has lz4 magic."""
    data = path.read_bytes()
    if path.suffix == ".lz4":
        return lz4.frame.decompress(data)
    return decompress_bytes(data)


def write_compressed_text(path: Path, text: str) -> Path:
    """Write text, compressing if enabled."""
    return write_compressed(path, text.encode("utf-8"))


def read_compressed_text(path: Path) -> str:
    """Read text, decompressing if needed."""
    return read_compressed(path).decode("utf-8")


def find_file(directory: Path, name: str) -> Path | None:
    """Find a file by name, checking both plain and .lz4 variants."""
    plain = directory / name
    if plain.exists():
        return plain
    compressed = directory / (name + ".lz4")
    if compressed.exists():
        return compressed
    return None
