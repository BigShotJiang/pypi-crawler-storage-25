import hashlib
import io
import pickle
from pathlib import Path
from typing import Any

from casher.compression import find_file, read_compressed, write_compressed
from casher.config import HASH_ALGORITHM


def _is_polars_dataframe(val: Any) -> bool:
    return (
        type(val).__module__.startswith("polars") and type(val).__name__ == "DataFrame"
    )


def _is_polars_lazyframe(val: Any) -> bool:
    return (
        type(val).__module__.startswith("polars") and type(val).__name__ == "LazyFrame"
    )


def _is_pandas_dataframe(val: Any) -> bool:
    return (
        type(val).__module__.startswith("pandas") and type(val).__name__ == "DataFrame"
    )


def hash_value(val: Any) -> bytes:
    """Compute a deterministic hash of a value for cache key purposes."""
    h = hashlib.new(HASH_ALGORITHM)
    _hash_into(h, val)
    return h.digest()


def _hash_into(h: "hashlib._Hash", val: Any) -> None:
    if val is None or isinstance(val, (int, float, str, bool)):
        h.update(repr(val).encode())
    elif isinstance(val, bytes):
        h.update(val)
    elif isinstance(val, (list, tuple)):
        h.update(type(val).__name__.encode())
        for item in val:
            _hash_into(h, item)
    elif isinstance(val, dict):
        h.update(b"dict")
        for key in sorted(val.keys(), key=repr):
            _hash_into(h, key)
            _hash_into(h, val[key])
    elif isinstance(val, (set, frozenset)):
        h.update(type(val).__name__.encode())
        for item in sorted(val, key=repr):
            _hash_into(h, item)
    elif isinstance(val, Path):
        if val.is_file():
            h.update(b"path:file")
            h.update(val.read_bytes())
        else:
            h.update(repr(val).encode())
    elif _is_polars_lazyframe(val):
        buf = io.BytesIO()
        val.collect().write_ipc(buf)
        h.update(buf.getvalue())
    elif _is_polars_dataframe(val):
        buf = io.BytesIO()
        val.write_ipc(buf)
        h.update(buf.getvalue())
    elif _is_pandas_dataframe(val):
        import pyarrow as pa

        table = pa.Table.from_pandas(val)
        sink = pa.BufferOutputStream()
        writer = pa.ipc.new_stream(sink, table.schema)
        writer.write_table(table)
        writer.close()
        h.update(sink.getvalue().to_pybytes())
    else:
        h.update(repr(val).encode())


def serialize_value(val: Any, dest: Path) -> dict:
    """Serialize a value to disk with optional lz4 compression. Returns metadata dict."""
    if _is_polars_dataframe(val) or _is_polars_lazyframe(val):
        if _is_polars_lazyframe(val):
            val = val.collect()
        buf = io.BytesIO()
        val.write_ipc(buf)
        written = write_compressed(dest / "result.ipc", buf.getvalue())
        return {"type": "polars.DataFrame", "file": written.name}
    elif _is_pandas_dataframe(val):
        import pyarrow as pa

        table = pa.Table.from_pandas(val)
        sink = pa.BufferOutputStream()
        writer = pa.ipc.new_file(sink, table.schema)
        writer.write_table(table)
        writer.close()
        written = write_compressed(dest / "result.ipc", sink.getvalue().to_pybytes())
        return {"type": "pandas.DataFrame", "file": written.name}
    else:
        data = pickle.dumps(val)
        written = write_compressed(dest / "result.pkl", data)
        return {"type": "pickle", "file": written.name}


def deserialize_value(meta: dict, src: Path) -> Any:
    """Deserialize a value from disk, decompressing if needed."""
    val_type = meta["type"]
    file_name = meta["file"]

    # Support both stored filename and fallback to find_file for older entries
    file_path = src / file_name
    if not file_path.exists():
        # Try finding plain or compressed variant
        base_name = file_name.removesuffix(".lz4")
        found = find_file(src, base_name)
        assert found is not None, f"Cache file not found: {file_name} in {src}"
        file_path = found

    data = read_compressed(file_path)

    if val_type == "polars.DataFrame":
        import polars as pl

        return pl.read_ipc(io.BytesIO(data))
    elif val_type == "pandas.DataFrame":
        import pyarrow as pa

        reader = pa.ipc.open_file(pa.BufferReader(data))
        table = reader.read_all()
        return table.to_pandas()
    elif val_type == "pickle":
        return pickle.loads(data)  # noqa: S301
    else:
        assert False, f"Unknown serialized type: {val_type}"
