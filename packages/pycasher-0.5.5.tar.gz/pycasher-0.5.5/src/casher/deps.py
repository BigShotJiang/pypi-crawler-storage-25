import ast
import hashlib
import inspect
from pathlib import Path
from collections.abc import Callable

from casher.config import HASH_ALGORITHM


def compute_dep_hash(func: Callable, dep_roots: list[Path] | None = None) -> str:
    """Compute a hash over all Python source files reachable from func's module.

    Uses static AST import analysis instead of sys.modules so the result is
    deterministic regardless of runtime import history (lazy imports, cache
    hit/miss ordering, etc.).
    """
    mod = inspect.getmodule(func)
    assert mod is not None, f"Cannot determine module for {func}"
    assert (
        hasattr(mod, "__file__") and mod.__file__ is not None
    ), f"Module {mod.__name__} has no __file__"

    if dep_roots is None:
        dep_roots = _auto_detect_roots(mod)

    dep_roots_resolved = [Path(r).resolve() for r in dep_roots]
    start_file = Path(mod.__file__).resolve()

    # Walk the static import graph from the function's module
    visited: set[Path] = set()
    _walk_imports(start_file, dep_roots_resolved, visited, is_entry=True)

    # Hash all discovered files
    file_hashes: list[tuple[str, str]] = []
    for src_path in visited:
        content_hash = hashlib.new(HASH_ALGORITHM, src_path.read_bytes()).hexdigest()
        file_hashes.append((str(src_path), content_hash))

    file_hashes.sort(key=lambda x: x[0])
    combined = "\n".join(f"{path}:{h}" for path, h in file_hashes)
    return hashlib.new(HASH_ALGORITHM, combined.encode()).hexdigest()


def _walk_imports(
    source_file: Path,
    dep_roots: list[Path],
    visited: set[Path],
    *,
    is_entry: bool = False,
) -> None:
    """Recursively walk imports from a source file using AST analysis."""
    source_file = source_file.resolve()
    if source_file in visited:
        return
    if not source_file.is_file() or source_file.suffix != ".py":
        return
    # The entry file is always included; subsequent files must be under dep_roots
    if not is_entry and not any(_is_under(source_file, root) for root in dep_roots):
        return

    visited.add(source_file)

    try:
        tree = ast.parse(source_file.read_bytes(), filename=str(source_file))
    except SyntaxError:
        return

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                resolved = _resolve_module(alias.name, source_file, dep_roots)
                if resolved:
                    _walk_imports(resolved, dep_roots, visited)
        elif isinstance(node, ast.ImportFrom):
            if node.module is None:
                continue
            # For relative imports, compute the absolute module name
            module_name = node.module
            if node.level > 0:
                module_name = _resolve_relative(
                    module_name, node.level, source_file, dep_roots
                )
                if module_name is None:
                    continue
            resolved = _resolve_module(module_name, source_file, dep_roots)
            if resolved:
                _walk_imports(resolved, dep_roots, visited)


def _resolve_module(
    module_name: str,
    from_file: Path,
    dep_roots: list[Path],
) -> Path | None:
    """Resolve a dotted module name to a .py file under dep_roots."""
    parts = module_name.split(".")

    # Try each dep_root
    for root in dep_roots:
        # Try as package: root/a/b/c/__init__.py
        pkg_path = root / "/".join(parts) / "__init__.py"
        if pkg_path.is_file():
            return pkg_path.resolve()

        # Try as module: root/a/b/c.py
        mod_path = (
            root / "/".join(parts[:-1]) / (parts[-1] + ".py")
            if len(parts) > 1
            else root / (parts[0] + ".py")
        )
        if mod_path.is_file():
            return mod_path.resolve()

        # Try partial — the import might be "from pkg.mod import name"
        # where pkg.mod is the module and name is an attribute
        for i in range(len(parts), 0, -1):
            sub = parts[:i]
            pkg_init = root / "/".join(sub) / "__init__.py"
            if pkg_init.is_file():
                return pkg_init.resolve()
            mod_file = (
                root / "/".join(sub[:-1]) / (sub[-1] + ".py")
                if len(sub) > 1
                else root / (sub[0] + ".py")
            )
            if mod_file.is_file():
                return mod_file.resolve()

    return None


def _resolve_relative(
    module_name: str,
    level: int,
    from_file: Path,
    dep_roots: list[Path],
) -> str | None:
    """Resolve a relative import to an absolute module name."""
    # Go up 'level' directories from the file's directory
    pkg_dir = from_file.parent
    for _ in range(level - 1):
        pkg_dir = pkg_dir.parent

    # Find which dep_root this is under
    for root in dep_roots:
        if _is_under(pkg_dir, root):
            try:
                rel = pkg_dir.relative_to(root)
                prefix = ".".join(rel.parts)
                if prefix and module_name:
                    return f"{prefix}.{module_name}"
                return prefix or module_name
            except ValueError:
                continue
    return None


def _is_under(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _auto_detect_roots(mod) -> list[Path]:
    mod_file = Path(mod.__file__).resolve()
    # Walk up to find the top-level package directory
    parts = mod.__name__.split(".")
    pkg_dir = mod_file.parent
    for _ in range(len(parts) - 1):
        pkg_dir = pkg_dir.parent
    if len(parts) == 1:
        # Single-file module (no package) — use its directory as root
        return [pkg_dir]
    # Package module — root is the parent of the package directory
    return [pkg_dir.parent]
