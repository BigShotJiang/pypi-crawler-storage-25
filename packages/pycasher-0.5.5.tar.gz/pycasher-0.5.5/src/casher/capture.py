import sys
from pathlib import Path

from casher.compression import read_compressed
from casher.store import CacheEntry


def replay_side_effects(entry: CacheEntry, entry_dir: Path) -> None:
    """Replay cached side effects:
    - print stdout to sys.stdout
    - print stderr to sys.stderr
    - restore output files from cache to their original paths
    """
    if entry.stdout:
        sys.stdout.write(entry.stdout)

    if entry.stderr:
        sys.stderr.write(entry.stderr)

    for rel_path, cached_path in entry.output_files.items():
        if not cached_path.exists():
            continue
        target = Path(rel_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        # Decompress if stored compressed
        target.write_bytes(read_compressed(cached_path))
