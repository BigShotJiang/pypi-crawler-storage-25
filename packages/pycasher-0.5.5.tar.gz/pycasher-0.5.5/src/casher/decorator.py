import contextlib
import fnmatch
import functools
import hashlib
import inspect
import io
import json
import os
import pickle
import shutil
import sys
import tempfile
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from loguru import logger

from casher import capture, strace
from casher.audit_hook import track_file_io
from casher.config import (
    HASH_ALGORITHM,
    PLATFORM_SUPPORTED,
    TMP_SUBDIR,
    resolve_cache_dir,
    resolve_max_cache_bytes,
)
from casher.deps import compute_dep_hash
from casher.hasher import compute_file_hash, compute_partial_key
from casher.serializer import hash_value
from casher.store import CacheEntry, find_cached, store_result

_PLATFORM_WARNING_LOGGED = False


def cached(
    _fn: Callable | None = None,
    *,
    cache_dir: Path | str | None = None,
    env_vars: list[str] | None = None,
    dep_roots: list[str | Path] | None = None,
    max_cache_bytes: int | None = None,
    enabled: bool = True,
    subprocess: bool = True,
    input_files: list[str | Path] | Callable[..., list[Path]] | None = None,
    output_files: list[str | Path] | Callable[..., list[Path]] | None = None,
    ignore_files: list[str] | None = None,
) -> Callable:
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            if not enabled:
                return fn(*args, **kwargs)

            if not PLATFORM_SUPPORTED:
                global _PLATFORM_WARNING_LOGGED
                if not _PLATFORM_WARNING_LOGGED:
                    logger.warning(
                        "casher: caching disabled on {} (only Linux is supported)",
                        sys.platform,
                    )
                    _PLATFORM_WARNING_LOGGED = True
                return fn(*args, **kwargs)

            resolved_cache_dir = resolve_cache_dir(cache_dir)
            resolved_max_bytes = resolve_max_cache_bytes(max_cache_bytes)
            resolved_dep_roots = [Path(r) for r in dep_roots] if dep_roots else None
            mode = "subprocess" if subprocess else "in-process"

            logger.info(
                "casher call: {}.{}() | mode={} | cache_dir={}",
                fn.__module__,
                fn.__qualname__,
                mode,
                resolved_cache_dir,
            )

            dep_hash = compute_dep_hash(fn, resolved_dep_roots)
            args_hash = _compute_args_hash(args, kwargs)

            partial_key = compute_partial_key(
                func_module=fn.__module__,
                func_name=fn.__qualname__,
                dep_hash=dep_hash,
                args_hash=args_hash,
                env_vars=env_vars or [],
            )

            cached_result = find_cached(resolved_cache_dir, partial_key)
            if cached_result is not None:
                entry, entry_dir = cached_result
                _log_cache_key_debug(
                    fn=fn,
                    args=args,
                    kwargs=kwargs,
                    dep_hash=dep_hash,
                    args_hash=args_hash,
                    env_vars=env_vars or [],
                    partial_key=partial_key,
                    file_hash=entry_dir.name,
                    input_files=entry.input_files,
                )
                logger.info(
                    "cache HIT: {}.{}() | key={}…",
                    fn.__module__,
                    fn.__qualname__,
                    partial_key[:12],
                )
                capture.replay_side_effects(entry, entry_dir)
                return entry.return_value

            logger.info(
                "cache MISS: {}.{}() | key={}… | executing {}",
                fn.__module__,
                fn.__qualname__,
                partial_key[:12],
                mode,
            )

            if subprocess:
                return _execute_subprocess(
                    fn,
                    args,
                    kwargs,
                    resolved_cache_dir,
                    partial_key,
                    dep_hash,
                    args_hash,
                    resolved_max_bytes,
                    input_files,
                    output_files,
                    ignore_files,
                    env_vars,
                )
            return _execute_inprocess(
                fn,
                args,
                kwargs,
                resolved_cache_dir,
                partial_key,
                dep_hash,
                args_hash,
                resolved_max_bytes,
                input_files,
                output_files,
                ignore_files,
                env_vars,
            )

        return wrapper

    if _fn is not None:
        return decorator(_fn)
    return decorator


def _compute_args_hash(args: tuple, kwargs: dict) -> str:
    h = hashlib.new(HASH_ALGORITHM)
    for arg in args:
        h.update(hash_value(arg))
    for key in sorted(kwargs.keys()):
        h.update(key.encode())
        h.update(hash_value(kwargs[key]))
    return h.hexdigest()


def _truncate_debug_text(text: str, max_len: int = 120) -> str:
    if len(text) <= max_len:
        return text
    return f"{text[: max_len - 1]}…"


def _format_debug_value(value: Any) -> str:
    return _truncate_debug_text(repr(value))


def _format_parameter_hash_mode(value: Any) -> str:
    if isinstance(value, Path):
        if value.is_file():
            return " | hash_mode=file_content"
        return " | hash_mode=path_repr"
    return ""


def _build_cache_key_debug_message(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    dep_hash: str,
    args_hash: str,
    env_vars: list[str],
    partial_key: str,
    file_hash: str,
    input_files: dict[str, str],
) -> str:
    bound_args = inspect.signature(fn).bind_partial(*args, **kwargs)
    parameter_lines = ["  - parameters:"]
    if bound_args.arguments:
        for name, value in bound_args.arguments.items():
            parameter_lines.append(
                f"    - {name} = {_format_debug_value(value)}{_format_parameter_hash_mode(value)} | value_hash={hash_value(value).hex()}"
            )
    else:
        parameter_lines.append("    - <none>")

    env_var_lines = ["  - env_vars:"]
    if env_vars:
        for var_name in sorted(env_vars):
            env_var_lines.append(
                f"    - {var_name} = {_format_debug_value(os.environ.get(var_name, ''))}"
            )
    else:
        env_var_lines.append("    - <none>")

    input_file_lines = ["  - input_files:"]
    if input_files:
        for path, content_hash in sorted(input_files.items()):
            input_file_lines.append(f"    - {path} | content_hash={content_hash}")
    else:
        input_file_lines.append("    - <none>")

    lines = [
        "casher cache key details:",
        f"  - function: {fn.__module__}.{fn.__qualname__}",
        f"  - partial_key: {partial_key}",
        f"  - dependency_hash: {dep_hash}",
        f"  - arguments_hash: {args_hash}",
        *parameter_lines,
        *env_var_lines,
        *input_file_lines,
        f"  - combined_input_files_hash: {file_hash}",
    ]
    return "\n".join(lines)


def _log_cache_key_debug(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    dep_hash: str,
    args_hash: str,
    env_vars: list[str],
    partial_key: str,
    file_hash: str,
    input_files: dict[str, str],
) -> None:
    logger.debug(
        _build_cache_key_debug_message(
            fn=fn,
            args=args,
            kwargs=kwargs,
            dep_hash=dep_hash,
            args_hash=args_hash,
            env_vars=env_vars,
            partial_key=partial_key,
            file_hash=file_hash,
            input_files=input_files,
        )
    )


def _resolve_file_list(
    spec: list[str | Path] | Callable[..., list[Path]] | None,
    args: tuple,
    kwargs: dict,
) -> list[Path]:
    if spec is None:
        return []
    if callable(spec):
        return [Path(p) for p in spec(*args, **kwargs)]
    return [Path(p) for p in spec]


_NOISE_PREFIXES = (
    "/dev/",
    "/proc/",
    "/sys/",
    "/usr/lib/",
    "/lib/",
    "/usr/local/lib/",
    "/usr/share/",
    "/etc/",
)
_NOISE_SUFFIXES = (".pyc", ".pyo", ".so", ".dll", ".pth")
_NOISE_CONTAINS = ("__pycache__", "site-packages", "/python3.")


def _is_noise(path: Path, cache_dir_resolved: Path) -> bool:
    s = str(path)
    if any(s.startswith(p) for p in _NOISE_PREFIXES):
        return True
    if any(s.endswith(p) for p in _NOISE_SUFFIXES):
        return True
    if any(c in s for c in _NOISE_CONTAINS):
        return True
    try:
        path.resolve().relative_to(cache_dir_resolved)
        return True
    except ValueError:
        pass
    return False


def _filter_ignored(paths: list[Path], ignore_patterns: list[str] | None) -> list[Path]:
    if not ignore_patterns:
        return paths
    result = []
    for p in paths:
        p_str = str(p)
        if not any(
            fnmatch.fnmatch(p_str, pat) or fnmatch.fnmatch(p.name, pat)
            for pat in ignore_patterns
        ):
            result.append(p)
    return result


def _execute_inprocess(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    cache_dir: Path,
    partial_key: str,
    dep_hash: str,
    args_hash: str,
    max_bytes: int,
    input_files_spec: list[str | Path] | Callable[..., list[Path]] | None,
    output_files_spec: list[str | Path] | Callable[..., list[Path]] | None,
    ignore_files: list[str] | None,
    env_vars: list[str] | None,
) -> Any:
    explicit_input = _resolve_file_list(input_files_spec, args, kwargs)
    explicit_output = _resolve_file_list(output_files_spec, args, kwargs)

    stdout_buf = io.StringIO()
    stderr_buf = io.StringIO()

    with (
        contextlib.redirect_stdout(stdout_buf),
        contextlib.redirect_stderr(stderr_buf),
        track_file_io() as tracker,
    ):
        result = fn(*args, **kwargs)

    discovered_read = tracker.read_files
    discovered_write = tracker.write_files

    resolved_cache = cache_dir.resolve()
    discovered_read = [p for p in discovered_read if not _is_noise(p, resolved_cache)]
    discovered_write = [p for p in discovered_write if not _is_noise(p, resolved_cache)]

    all_read = list(dict.fromkeys(explicit_input + discovered_read))
    all_write = list(dict.fromkeys(explicit_output + discovered_write))

    all_read = _filter_ignored(all_read, ignore_files)
    all_write = _filter_ignored(all_write, ignore_files)

    existing_read = [p for p in all_read if p.exists()]

    if existing_read:
        file_hash = compute_file_hash(existing_read)
    else:
        file_hash = "none"

    input_files_dict: dict[str, str] = {}
    for p in existing_read:
        input_files_dict[str(p)] = compute_file_hash([p])

    output_files_dict: dict[str, Path] = {}
    existing_write = [p for p in all_write if p.exists()]
    for p in existing_write:
        output_files_dict[str(p)] = p

    entry = CacheEntry(
        return_value=result,
        stdout=stdout_buf.getvalue(),
        stderr=stderr_buf.getvalue(),
        output_files=output_files_dict,
        input_files=input_files_dict,
        created_at=time.time(),
        func_module=fn.__module__,
        func_name=fn.__qualname__,
    )

    _log_cache_key_debug(
        fn=fn,
        args=args,
        kwargs=kwargs,
        dep_hash=dep_hash,
        args_hash=args_hash,
        env_vars=env_vars or [],
        partial_key=partial_key,
        file_hash=file_hash,
        input_files=input_files_dict,
    )

    store_result(cache_dir, partial_key, file_hash, entry, max_bytes=max_bytes)

    if entry.stdout:
        sys.stdout.write(entry.stdout)
    if entry.stderr:
        sys.stderr.write(entry.stderr)

    return result


def _execute_subprocess(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    cache_dir: Path,
    partial_key: str,
    dep_hash: str,
    args_hash: str,
    max_bytes: int,
    input_files_spec: list[str | Path] | Callable[..., list[Path]] | None,
    output_files_spec: list[str | Path] | Callable[..., list[Path]] | None,
    ignore_files: list[str] | None,
    env_vars: list[str] | None,
) -> Any:
    explicit_input = _resolve_file_list(input_files_spec, args, kwargs)
    explicit_output = _resolve_file_list(output_files_spec, args, kwargs)

    tmp_root = cache_dir / TMP_SUBDIR
    tmp_root.mkdir(parents=True, exist_ok=True)
    work_dir = Path(tempfile.mkdtemp(prefix="casher-", dir=tmp_root))
    try:
        with open(work_dir / "args.pkl", "wb") as f:
            pickle.dump(
                {
                    "module": fn.__module__,
                    "function": fn.__qualname__,
                    "args": args,
                    "kwargs": kwargs,
                },
                f,
            )

        cmd = [sys.executable, "-m", "casher._runner", str(work_dir)]
        env = os.environ.copy()
        env["PYTHONPATH"] = os.pathsep.join(sys.path)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        strace_result = strace.run_with_strace(cmd, tmp_dir=tmp_root, env=env)

        status_path = work_dir / "status.json"
        assert status_path.exists(), (
            f"Runner did not write status.json. returncode={strace_result.returncode}, "
            f"stderr={strace_result.stderr[:500]}"
        )
        status = json.loads(status_path.read_text())

        if not status["success"]:
            exc_path = work_dir / "exception.pkl"
            assert exc_path.exists(), "Runner failed but did not write exception.pkl"
            with open(exc_path, "rb") as f:
                exc = pickle.load(f)  # noqa: S301
            raise exc

        result_path = work_dir / "result.pkl"
        assert result_path.exists(), "Runner succeeded but did not write result.pkl"
        with open(result_path, "rb") as f:
            result = pickle.load(f)  # noqa: S301

        resolved_cache = cache_dir.resolve()
        work_dir_resolved = work_dir.resolve()

        def _is_work_dir(p: Path) -> bool:
            try:
                p.resolve().relative_to(work_dir_resolved)
                return True
            except ValueError:
                return False

        discovered_read = [
            p
            for p in strace_result.read_files
            if not _is_noise(p, resolved_cache) and not _is_work_dir(p) and p.is_file()
        ]
        discovered_write = [
            p
            for p in strace_result.write_files
            if not _is_noise(p, resolved_cache) and not _is_work_dir(p) and p.is_file()
        ]

        all_read = list(dict.fromkeys(explicit_input + discovered_read))
        all_write = list(dict.fromkeys(explicit_output + discovered_write))

        all_read = _filter_ignored(all_read, ignore_files)
        all_write = _filter_ignored(all_write, ignore_files)

        existing_read = [p for p in all_read if p.exists()]

        if existing_read:
            file_hash = compute_file_hash(existing_read)
        else:
            file_hash = "none"

        input_files_dict: dict[str, str] = {}
        for p in existing_read:
            input_files_dict[str(p)] = compute_file_hash([p])

        output_files_dict: dict[str, Path] = {}
        existing_write = [p for p in all_write if p.exists()]
        for p in existing_write:
            output_files_dict[str(p)] = p

        entry = CacheEntry(
            return_value=result,
            stdout=strace_result.stdout,
            stderr=strace_result.stderr,
            output_files=output_files_dict,
            input_files=input_files_dict,
            created_at=time.time(),
            func_module=fn.__module__,
            func_name=fn.__qualname__,
        )

        _log_cache_key_debug(
            fn=fn,
            args=args,
            kwargs=kwargs,
            dep_hash=dep_hash,
            args_hash=args_hash,
            env_vars=env_vars or [],
            partial_key=partial_key,
            file_hash=file_hash,
            input_files=input_files_dict,
        )

        store_result(cache_dir, partial_key, file_hash, entry, max_bytes=max_bytes)

        if entry.stdout:
            sys.stdout.write(entry.stdout)
        if entry.stderr:
            sys.stderr.write(entry.stderr)

        return result
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)
