import time

import pytest

from casher.compression import find_file, read_compressed
from casher.hasher import compute_file_hash
from casher.store import CacheEntry, find_cached, store_result, invalidate, clear_cache
from casher.tests.config import TEST_FILE_HASH


def _make_entry(**overrides) -> CacheEntry:
    defaults = dict(
        return_value=42,
        stdout="hello stdout",
        stderr="",
        output_files={},
        input_files={},
        created_at=time.time(),
        func_module="test_mod",
        func_name="test_fn",
    )
    defaults.update(overrides)
    return CacheEntry(**defaults)


@pytest.mark.timeout(10)
def test_store_and_find(tmp_path):
    cache_dir = tmp_path / "cache"
    input_file = tmp_path / "input.txt"
    input_file.write_text("input data")
    file_hash_val = compute_file_hash([input_file])

    entry = _make_entry(
        input_files={str(input_file): file_hash_val},
        return_value={"result": 99},
        stdout="some output",
        stderr="some error",
    )
    partial_key = "pk_test_store"
    store_result(cache_dir, partial_key, file_hash_val, entry)

    result = find_cached(cache_dir, partial_key)
    assert result is not None
    found, found_dir = result
    assert found.return_value == {"result": 99}
    assert found.stdout == "some output"
    assert found.stderr == "some error"


@pytest.mark.timeout(10)
def test_find_returns_none_missing(tmp_path):
    cache_dir = tmp_path / "cache"
    cache_dir.mkdir()
    assert find_cached(cache_dir, "nonexistent") is None


@pytest.mark.timeout(10)
def test_find_returns_none_file_changed(tmp_path):
    cache_dir = tmp_path / "cache"
    input_file = tmp_path / "input.txt"
    input_file.write_text("original")
    file_hash_val = compute_file_hash([input_file])

    entry = _make_entry(input_files={str(input_file): file_hash_val})
    store_result(cache_dir, "pk_change", file_hash_val, entry)

    # Modify the input file
    input_file.write_text("modified")
    assert find_cached(cache_dir, "pk_change") is None


@pytest.mark.timeout(10)
def test_multiple_entries_same_partial_key(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_multi"

    # Entry 1 with file content "v1"
    input_file = tmp_path / "input.txt"
    input_file.write_text("v1")
    fh1 = compute_file_hash([input_file])
    entry1 = _make_entry(return_value="result_v1", input_files={str(input_file): fh1})
    store_result(cache_dir, partial_key, fh1, entry1)

    # Entry 2 with file content "v2"
    input_file.write_text("v2")
    fh2 = compute_file_hash([input_file])
    entry2 = _make_entry(return_value="result_v2", input_files={str(input_file): fh2})
    store_result(cache_dir, partial_key, fh2, entry2)

    # Current file is "v2" — should find entry2
    result = find_cached(cache_dir, partial_key)
    assert result is not None
    found, _ = result
    assert found.return_value == "result_v2"

    # Switch back to "v1" — should find entry1
    input_file.write_text("v1")
    result = find_cached(cache_dir, partial_key)
    assert result is not None
    found, _ = result
    assert found.return_value == "result_v1"


@pytest.mark.timeout(10)
def test_corrupted_meta_json(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_corrupt"

    entry = _make_entry()
    store_result(cache_dir, partial_key, TEST_FILE_HASH, entry)

    # Corrupt meta.json
    meta_path = cache_dir / partial_key / TEST_FILE_HASH / "meta.json"
    meta_path.write_text("not valid json{{{")

    result = find_cached(cache_dir, partial_key)
    assert result is None
    # Corrupted dir should be cleaned up
    assert not (cache_dir / partial_key / TEST_FILE_HASH).exists()


@pytest.mark.timeout(10)
def test_invalidate(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_invalidate"

    entry = _make_entry()
    store_result(cache_dir, partial_key, TEST_FILE_HASH, entry)
    assert find_cached(cache_dir, partial_key) is not None

    assert invalidate(cache_dir, partial_key) is True
    assert find_cached(cache_dir, partial_key) is None


@pytest.mark.timeout(10)
def test_clear_cache(tmp_path):
    cache_dir = tmp_path / "cache"

    for i in range(3):
        entry = _make_entry(return_value=i)
        store_result(cache_dir, f"pk_{i}", f"fh_{i}", entry)

    count = clear_cache(cache_dir)
    assert count == 3
    # Only lock file and similar should remain
    remaining_dirs = [
        d for d in cache_dir.iterdir() if d.is_dir() and not d.name.startswith(".")
    ]
    assert len(remaining_dirs) == 0


@pytest.mark.timeout(10)
def test_mtime_updated_on_hit(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_mtime"

    entry = _make_entry()
    store_result(cache_dir, partial_key, TEST_FILE_HASH, entry)

    meta_path = cache_dir / partial_key / TEST_FILE_HASH / "meta.json"
    mtime_before = meta_path.stat().st_mtime

    # Ensure measurable time difference
    time.sleep(0.05)

    result = find_cached(cache_dir, partial_key)
    assert result is not None

    mtime_after = meta_path.stat().st_mtime
    assert mtime_after > mtime_before


@pytest.mark.timeout(10)
def test_output_files_stored(tmp_path):
    cache_dir = tmp_path / "cache"
    partial_key = "pk_output"

    # Create a real output file
    output_file = tmp_path / "output.txt"
    output_file.write_text("output content")

    entry = _make_entry(output_files={"output.txt": output_file})
    result_dir = store_result(cache_dir, partial_key, TEST_FILE_HASH, entry)

    cached_output = find_file(result_dir / "output_files", "output.txt")
    assert cached_output is not None
    assert read_compressed(cached_output) == b"output content"


@pytest.mark.timeout(10)
def test_compressed_files_have_lz4_suffix(tmp_path):
    """With compression enabled (default), stored files use .lz4 suffix."""
    from casher.config import _overrides

    _overrides.pop("compression", None)  # ensure default (True)
    cache_dir = tmp_path / "cache"
    entry = _make_entry(return_value="big data " * 100)
    result_dir = store_result(cache_dir, "pk_comp", "fh_comp", entry)

    # result.pkl.lz4 should exist
    assert (result_dir / "result.pkl.lz4").exists()
    assert not (result_dir / "result.pkl").exists()
    # stdout should be compressed too
    assert (result_dir / "stdout.txt.lz4").exists()


@pytest.mark.timeout(10)
def test_compression_disabled(tmp_path):
    """With compression=False, files stored uncompressed."""
    from casher.config import _overrides

    _overrides["compression"] = False
    try:
        cache_dir = tmp_path / "cache"
        entry = _make_entry(return_value="small")
        result_dir = store_result(cache_dir, "pk_nocomp", "fh_nocomp", entry)

        assert (result_dir / "result.pkl").exists()
        assert not (result_dir / "result.pkl.lz4").exists()
        assert (result_dir / "stdout.txt").exists()
    finally:
        _overrides.pop("compression", None)


@pytest.mark.timeout(10)
def test_compressed_smaller_than_uncompressed(tmp_path):
    """Compressed storage should be smaller for repetitive data."""
    from casher.config import _overrides

    big_data = "repetitive " * 10000

    # Store compressed
    _overrides["compression"] = True
    cache_comp = tmp_path / "comp"
    entry = _make_entry(return_value=big_data)
    dir_comp = store_result(cache_comp, "pk", "fh", entry)
    size_comp = sum(f.stat().st_size for f in dir_comp.rglob("*") if f.is_file())

    # Store uncompressed
    _overrides["compression"] = False
    cache_raw = tmp_path / "raw"
    entry2 = _make_entry(return_value=big_data)
    dir_raw = store_result(cache_raw, "pk", "fh", entry2)
    size_raw = sum(f.stat().st_size for f in dir_raw.rglob("*") if f.is_file())

    _overrides.pop("compression", None)
    assert size_comp < size_raw


@pytest.mark.timeout(10)
def test_find_cached_reads_compressed(tmp_path):
    """find_cached correctly reads lz4-compressed entries."""
    cache_dir = tmp_path / "cache"
    entry = _make_entry(return_value={"key": "value"}, stdout="hello compressed")
    store_result(cache_dir, "pk_read", "fh_read", entry)

    result = find_cached(cache_dir, "pk_read")
    assert result is not None
    found_entry, _ = result
    assert found_entry.return_value == {"key": "value"}
    assert found_entry.stdout == "hello compressed"


@pytest.mark.timeout(10)
def test_lru_measures_compressed_bytes(tmp_path):
    """Eviction size is based on on-disk (compressed) bytes, not uncompressed."""
    from casher.eviction import get_entry_size

    cache_dir = tmp_path / "cache"
    big_data = "x" * 100000  # very compressible
    entry = _make_entry(return_value=big_data)
    result_dir = store_result(cache_dir, "pk_lru", "fh_lru", entry)

    on_disk_size = get_entry_size(result_dir)
    uncompressed_size = len(big_data.encode())
    # On-disk should be much smaller than the raw string
    assert on_disk_size < uncompressed_size
