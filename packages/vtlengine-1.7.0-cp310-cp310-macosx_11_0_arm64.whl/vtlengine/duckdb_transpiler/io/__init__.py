"""
DuckDB-based CSV IO optimized for out-of-core processing.

Public functions:
- load_datapoints_duckdb: Load CSV data into DuckDB table with validation
- save_datapoints_duckdb: Save DuckDB table to CSV file
- execute_queries: Execute transpiled SQL queries with DAG scheduling
- extract_datapoint_paths: Extract paths without pandas validation (DuckDB-optimized)
- register_dataframes: Register DataFrames directly with DuckDB
"""

from ._execution import execute_queries
from ._io import (
    extract_datapoint_paths,
    load_datapoints_duckdb,
    register_dataframes,
    save_datapoints_duckdb,
)
from ._time_handling import apply_time_period_representation, format_time_period_scalar

__all__ = [
    "load_datapoints_duckdb",
    "save_datapoints_duckdb",
    "execute_queries",
    "extract_datapoint_paths",
    "register_dataframes",
    "apply_time_period_representation",
    "format_time_period_scalar",
]
