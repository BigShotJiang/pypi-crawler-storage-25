"""
Core module for show_db_queries package.

Implements ShowDBQueries and helpers migrated from legacy utils.py
without changing the public API.
"""

from __future__ import annotations

import logging
import shutil
from time import time
from types import MethodType

from django.conf import settings as django_settings
from django.db import DEFAULT_DB_ALIAS, connections
from django.db.backends.utils import CursorWrapper

from show_db_queries.utils import _get_stacktrace, format_sql

logger = logging.getLogger("django.db.backends")

_SENTINEL = object()


class StacktraceCursorWrapper(CursorWrapper):
    """Wrapper for substituting the CursorWrapper.
    Adds to SQL query a comment-like entry with python stack trace and timing.
    """

    def execute(self, sql, params=None):
        stacktrace = _get_stacktrace()
        start = time()
        try:
            return super().execute(sql, params)
        finally:
            stop = time()
            duration = stop - start
            sql = self.db.ops.last_executed_query(self.cursor, sql, params)
            self.db.queries_log.append(
                {"sql": sql, "time": f"{duration:.3f}", "stacktrace": stacktrace}
            )
            logger.debug(
                "(%.3f) %s; args=%s",
                duration,
                sql,
                params,
                extra={"duration": duration, "sql": sql, "params": params},
            )


class ShowDBQueries:
    final_queries: int = 0

    """
    This class can be used to print the queries and the number of queries used for a section of code.

    For example if you wanted to see the queries used in a unit test you could do the following::

        with ShowDBQueries():
            ... do work that triggers DB queries ...
    """

    def __init__(
        self,
        connection=None,
        print=_SENTINEL,
        color=_SENTINEL,
        file=_SENTINEL,
        stacktrace=_SENTINEL,
        threshold=_SENTINEL,
        **kwargs,
    ):
        # Support deprecated long parameter names via kwargs
        connection = kwargs.pop("db_connection", connection)
        print = kwargs.pop("print_queries", print)
        color = kwargs.pop("colorize", color)
        file = kwargs.pop("file_path", file)
        stacktrace = kwargs.pop("include_stacktrace", stacktrace)
        threshold = kwargs.pop("query_time_threshold", threshold)

        if kwargs:
            raise TypeError(f"Unexpected keyword arguments: {', '.join(kwargs)}")

        defaults = getattr(django_settings, "SHOW_DB_QUERIES", {})

        if print is _SENTINEL:
            print = defaults.get("print", True)
        if color is _SENTINEL:
            color = defaults.get("color", True)
        if file is _SENTINEL:
            file = defaults.get("file", None)
        if stacktrace is _SENTINEL:
            stacktrace = defaults.get("stacktrace", False)
        if threshold is _SENTINEL:
            threshold = defaults.get("threshold", None)

        self.print_queries = print
        self.colorize = color
        self.file_path = file
        self.include_stacktrace = stacktrace
        self.query_time_threshold = threshold
        if connection is None:
            connection = connections[DEFAULT_DB_ALIAS]
        self.connection = connection

    @property
    def captured_queries(self):
        return self.connection.queries_log

    @staticmethod
    def format_stacktrace(stacks, colorize: bool = False):
        stacktrace_lines: list[str] = []
        for stack in stacks:
            line = stack[0]
            # Skip internal frames if any specific path needs filtering
            # Preserves API; colorization for stacktrace is minimal and relies on terminal defaults
            if "apps/base/utils/db_stacktrace" in line:
                continue

            stack_str = 'File "{}", line {}, in {}\n\t{}'.format(*list(stack)).replace("%", "%%")
            # Original code applied custom colors based on BASE_DIR; we keep behavior neutral to avoid external deps
            # If colorize is True, we could add simple ANSI codes, but to preserve public API without new deps we skip.
            stacktrace_lines.append(stack_str)
        return "\n".join(stacktrace_lines)

    def get_queries(self, colorize, use_sql_comments: bool = False):
        num = 0
        rtn_val = ""
        ending_linebreaks = "\n" if colorize is True else "\n\n"
        column_width = shutil.get_terminal_size().columns if colorize is True else 80
        for q in self.captured_queries:
            if q["sql"].startswith("EXPLAIN"):
                continue
            if (
                self.query_time_threshold is not None
                and float(q["time"]) < self.query_time_threshold
            ):
                continue
            rtn_val += f"{'-- ' if use_sql_comments else ''}{num}. {q['time']} ms\n"
            rtn_val += f"{'-- ' if use_sql_comments else ''}{'-' * column_width}\n"
            rtn_val += f"{format_sql(q['sql'], colorize=colorize)};{ending_linebreaks}"
            if self.include_stacktrace is True:
                stacktrace = f"\n{self.format_stacktrace(q['stacktrace'], colorize)}\n\n"
                if use_sql_comments is True:
                    stacktrace = f"\n/* {stacktrace} */\n"
                rtn_val += stacktrace
            num += 1

        self.final_queries = num
        return rtn_val

    def __enter__(self):
        def make_debug_cursor(db_wrapper_class, cursor):
            return StacktraceCursorWrapper(cursor, db_wrapper_class)

        self.orig_force_debug_cursor = self.connection.force_debug_cursor
        self.orig_make_debug_cursor = self.connection.make_debug_cursor
        self.connection.force_debug_cursor = True
        self.connection.make_debug_cursor = MethodType(make_debug_cursor, self.connection)
        self.initial_queries = len(self.connection.queries_log)
        self.final_queries = 0
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.connection.force_debug_cursor = self.orig_force_debug_cursor
        self.connection.make_debug_cursor = self.orig_make_debug_cursor

        if self.file_path is not None:
            with open(self.file_path, "w+") as f:
                f.write(self.get_queries(colorize=False, use_sql_comments=True))

        if self.print_queries is True:
            print("\nQueries:\n")
            print(self.get_queries(colorize=self.colorize))

            if self.query_time_threshold is not None:
                print(f"Queries over {self.query_time_threshold} ms: {self.final_queries}")
            else:
                print(f"Queries executed: {self.final_queries}\n")


def show_queries(**kwargs):
    """Convenience wrapper that returns a ShowDBQueries context manager."""
    return ShowDBQueries(**kwargs)
