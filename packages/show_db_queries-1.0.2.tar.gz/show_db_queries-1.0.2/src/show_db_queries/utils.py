from __future__ import annotations

import sqlparse
from django.conf import settings
from pygments import highlight
from pygments.formatters import Terminal256Formatter
from pygments.lexers.sql import SqlLexer


def _get_stacktrace() -> list[tuple[str, int, str, str]]:
    """
    Build a simplified Python stacktrace suitable for attaching to query logs.

    Returns a list of tuples: (filename, lineno, function, line)
    """
    import traceback

    stacks = traceback.extract_stack()
    # Remove the last frames that point to this helper and internal machinery
    filtered = []
    for frame in stacks[:-2]:
        # Frame is a FrameSummary(filename, lineno, name, line)
        filtered.append((frame.filename, frame.lineno, frame.name, frame.line or ""))
    return filtered


def format_sql(sql: str, colorize: bool = True) -> str:
    """
    Adds indenting and optional color coding to SQL queries.

    :param sql: The SQL query to format
    :param colorize: Should the SQL be formatted with color?
    :return: Formatted SQL string.
    """
    # See the docs for format options: https://sqlparse.readthedocs.io/en/latest/api/#formatting-of-sql-statements
    rtn_val = sqlparse.format(
        sql, keyword_case="upper", reindent=True, reindent_aligned=False, wrap_after=120
    )

    if colorize is True:
        lexer = SqlLexer()
        formatter = Terminal256Formatter(
            style=getattr(settings, "CODE_FORMAT_STYLE", "monokai") or "monokai"
        )
        rtn_val = highlight(rtn_val, lexer, formatter)

    return rtn_val
