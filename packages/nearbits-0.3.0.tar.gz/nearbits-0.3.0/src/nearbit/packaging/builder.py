from __future__ import annotations

from ..compression.activations import activation_policy
from ..types import ArtifactManifest, CompressionArtifact, CompressionPlan, PackedLayer


class ArtifactBuilder:
    def build(
        self,
        compression_plan: CompressionPlan,
        packed_layers: list[PackedLayer],
        kv_policy: dict[str, object],
    ) -> CompressionArtifact:
        manifest = ArtifactManifest(
            model_name=compression_plan.model_name,
            model_type=compression_plan.model_type,
            supported_operators=sorted({layer.precision.value for layer in packed_layers}),
            activation_precision=activation_policy(compression_plan.model_type)["default_precision"],
            kv_cache_policy=kv_policy,
            expected_peak_ram_bytes=min(compression_plan.ram_budget, 64 * 1024 * 1024),
            layer_precisions={layer.name: layer.precision.value for layer in packed_layers},
            extra={
                "recent_window_tokens": compression_plan.recent_window_tokens,
                "summary": compression_plan.summary,
            },
        )
        memory_schedule = [
            {
                "layer": layer.name,
                "load": "stream" if compression_plan.ram_budget < compression_plan.flash_budget else "resident",
                "precision": layer.precision.value,
            }
            for layer in packed_layers
        ]
        return CompressionArtifact(
            manifest=manifest,
            layers=packed_layers,
            memory_schedule=memory_schedule,
        )
