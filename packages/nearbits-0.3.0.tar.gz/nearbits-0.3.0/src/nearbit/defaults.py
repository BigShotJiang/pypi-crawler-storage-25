from __future__ import annotations

from .types import HardwareProfile, RuntimeProfile

DEFAULT_GROUP_SIZE = 128
DEFAULT_OUTLIER_FRACTION = 0.005
DEFAULT_RESIDUAL_RANK = 8
DEFAULT_ACTIVATION_PRECISION = "int8"
DEFAULT_KV_CACHE_PRECISION = "int4"
DEFAULT_RECENT_WINDOW_TOKENS = 128

DEFAULT_HARDWARE_PROFILE = HardwareProfile(
    device_name="generic-mobile",
    ram_budget_bytes=512 * 1024 * 1024,
    flash_budget_bytes=2 * 1024 * 1024 * 1024,
    latency_budget_ms=120.0,
    accelerator="cpu",
)

DEFAULT_RUNTIME_PROFILE = RuntimeProfile(
    stream_from_flash=True,
    static_arena_bytes=64 * 1024 * 1024,
    prefer_fused_kernels=True,
    max_sequence_length=2048,
)
