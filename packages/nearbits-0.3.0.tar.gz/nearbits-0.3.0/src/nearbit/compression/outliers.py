from __future__ import annotations

from math import ceil
from typing import Iterable


def extract_outliers(weights: Iterable[float], fraction: float) -> dict[str, object]:
    values = list(weights)
    keep = max(1, ceil(len(values) * fraction))
    ranked = sorted(enumerate(values), key=lambda item: abs(item[1]), reverse=True)
    selected = ranked[:keep]
    return {
        "fraction": fraction,
        "indices": [index for index, _ in selected],
        "values": [value for _, value in selected],
    }
