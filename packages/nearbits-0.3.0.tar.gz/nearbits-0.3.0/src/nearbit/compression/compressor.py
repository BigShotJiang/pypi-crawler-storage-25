from __future__ import annotations

from typing import Any

from ..packaging.builder import ArtifactBuilder
from ..types import CompressionArtifact, CompressionPlan, PackedLayer, PrecisionKind
from .binary import pack_signs
from .kv_cache import kv_cache_policy
from .outliers import extract_outliers
from .residual import build_low_rank_residual


class Compressor:
    def compress(self, model: Any, compression_plan: CompressionPlan) -> CompressionArtifact:
        weights_by_layer = self._read_weights(model)
        packed_layers: list[PackedLayer] = []

        for layer_plan in compression_plan.layers:
            weights = weights_by_layer.get(layer_plan.name, [0.0])
            payload = self._compress_layer(weights, layer_plan.precision, layer_plan.group_size, layer_plan.outlier_fraction, layer_plan.residual_rank)
            packed_layers.append(
                PackedLayer(
                    name=layer_plan.name,
                    precision=layer_plan.precision,
                    payload=payload,
                )
            )

        return ArtifactBuilder().build(
            compression_plan=compression_plan,
            packed_layers=packed_layers,
            kv_policy=kv_cache_policy(compression_plan.model_type),
        )

    def _compress_layer(
        self,
        weights: list[float],
        precision: PrecisionKind,
        group_size: int,
        outlier_fraction: float,
        residual_rank: int,
    ) -> dict[str, object]:
        if precision == PrecisionKind.BINARY:
            return pack_signs(weights, group_size)
        if precision == PrecisionKind.BINARY_OUTLIERS:
            return {
                "binary": pack_signs(weights, group_size),
                "outliers": extract_outliers(weights, outlier_fraction),
            }
        if precision == PrecisionKind.BINARY_LOW_RANK:
            return {
                "binary": pack_signs(weights, group_size),
                "outliers": extract_outliers(weights, outlier_fraction),
                "residual": build_low_rank_residual(weights, residual_rank),
            }
        return {
            "values": weights,
            "stored_precision": precision.value,
        }

    def _read_weights(self, model: Any) -> dict[str, list[float]]:
        if hasattr(model, "nearbit_weights"):
            return dict(model.nearbit_weights())
        if isinstance(model, dict) and "weights" in model:
            return {str(key): list(value) for key, value in model["weights"].items()}
        return {}
