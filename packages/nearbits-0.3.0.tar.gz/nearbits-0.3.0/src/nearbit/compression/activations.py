from __future__ import annotations

from ..types import PrecisionKind


def activation_policy(model_type: str) -> dict[str, str]:
    if model_type == "transformer":
        return {"default_precision": PrecisionKind.INT8.value, "fallback_precision": PrecisionKind.INT4.value}
    return {"default_precision": PrecisionKind.INT8.value, "fallback_precision": PrecisionKind.INT8.value}
