from __future__ import annotations

from typing import Iterable


def pack_signs(weights: Iterable[float], group_size: int) -> dict[str, object]:
    values = list(weights)
    packed = [1 if value >= 0 else 0 for value in values]
    scales = []
    for index in range(0, len(values), group_size):
        group = values[index : index + group_size]
        mean_abs = sum(abs(value) for value in group) / max(len(group), 1)
        scales.append(mean_abs)
    return {
        "bitpack": packed,
        "group_size": group_size,
        "scales": scales,
    }
