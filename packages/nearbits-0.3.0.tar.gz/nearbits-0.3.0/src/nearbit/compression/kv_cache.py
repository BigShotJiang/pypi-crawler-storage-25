from __future__ import annotations

from ..defaults import DEFAULT_RECENT_WINDOW_TOKENS
from ..types import PrecisionKind


def kv_cache_policy(model_type: str) -> dict[str, object]:
    if model_type != "transformer":
        return {"enabled": False, "precision": PrecisionKind.INT8.value, "recent_window_tokens": 0}
    return {
        "enabled": True,
        "precision": PrecisionKind.INT4.value,
        "recent_window_tokens": DEFAULT_RECENT_WINDOW_TOKENS,
        "newest_window_precision": PrecisionKind.INT8.value,
    }
