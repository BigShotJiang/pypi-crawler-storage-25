from __future__ import annotations

from typing import Iterable


def build_low_rank_residual(weights: Iterable[float], rank: int) -> dict[str, object]:
    values = list(weights)
    if rank <= 0:
        return {"rank": 0, "u": [], "v": []}
    chunk = max(1, len(values) // rank)
    u = [sum(values[index : index + chunk]) / max(len(values[index : index + chunk]), 1) for index in range(0, len(values), chunk)]
    u = u[:rank]
    v = [1.0 / max(index + 1, 1) for index in range(rank)]
    return {"rank": rank, "u": u, "v": v}
