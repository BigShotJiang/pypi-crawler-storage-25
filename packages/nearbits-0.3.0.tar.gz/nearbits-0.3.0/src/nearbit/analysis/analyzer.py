from __future__ import annotations

from collections.abc import Iterable
from statistics import mean
from typing import Any

from ..types import CalibrationSample, HardwareProfile, LayerSensitivity, PrecisionKind, SensitivityReport
from .introspection import ModelInspector


class Analyzer:
    def __init__(self, hardware_profile: HardwareProfile) -> None:
        self.hardware_profile = hardware_profile
        self.inspector = ModelInspector()

    def analyze(self, model: Any, calibration_set: Iterable[CalibrationSample]) -> SensitivityReport:
        samples = list(calibration_set)
        model_name, model_type = self.inspector.identify_model(model)
        layers = self.inspector.inspect_layers(model)
        sample_factor = max(len(samples), 1)

        sensitivities: list[LayerSensitivity] = []
        for index, layer in enumerate(layers):
            size_factor = min(layer.parameter_count / 1_000_000, 4.0)
            position_penalty = 0.8 if index in (0, len(layers) - 1) else 0.0
            fragile_penalty = 1.5 if layer.is_fragile else 0.0
            binary_bonus = -0.3 if layer.supports_binary else 0.8
            score = round(0.4 + size_factor + position_penalty + fragile_penalty + binary_bonus, 4)

            min_act = round(-1.0 - 0.02 * index, 4)
            max_act = round(1.0 + 0.03 * index, 4)
            outlier_fraction = round(min(0.01, 0.001 + size_factor / 100 + index / (10_000 * sample_factor)), 6)
            estimated_binary_error = round(score * 0.018 + outlier_fraction * 10, 6)

            recommended = self._recommended_precision(layer.is_fragile, layer.supports_binary, estimated_binary_error)
            sensitivities.append(
                LayerSensitivity(
                    name=layer.name,
                    op_type=layer.op_type,
                    sensitivity_score=score,
                    activation_range=(min_act, max_act),
                    outlier_fraction=outlier_fraction,
                    estimated_binary_error=estimated_binary_error,
                    is_fragile=layer.is_fragile,
                    supports_binary=layer.supports_binary,
                    recommended_precision=recommended,
                )
            )

        baseline_metric = round(max(0.0, 1.0 - mean(layer.estimated_binary_error for layer in sensitivities) / 2), 6)
        return SensitivityReport(
            model_name=model_name,
            model_type=model_type,
            layers=sensitivities,
            baseline_metric=baseline_metric,
            metadata={
                "calibration_samples": len(samples),
                "hardware_target": self.hardware_profile.device_name,
                "accelerator": self.hardware_profile.accelerator,
            },
        )

    def _recommended_precision(
        self,
        is_fragile: bool,
        supports_binary: bool,
        estimated_binary_error: float,
    ) -> PrecisionKind:
        if is_fragile:
            return PrecisionKind.INT8
        if not supports_binary:
            return PrecisionKind.INT4 if estimated_binary_error < 0.08 else PrecisionKind.INT8
        if estimated_binary_error < 0.03:
            return PrecisionKind.BINARY
        if estimated_binary_error < 0.06:
            return PrecisionKind.BINARY_OUTLIERS
        if estimated_binary_error < 0.09:
            return PrecisionKind.BINARY_LOW_RANK
        return PrecisionKind.INT4
