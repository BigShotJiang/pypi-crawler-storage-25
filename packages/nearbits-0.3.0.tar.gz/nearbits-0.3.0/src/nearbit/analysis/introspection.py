from __future__ import annotations

from typing import Any, Iterable

from ..types import LayerProfile


class ModelInspector:
    """Adapter-style model inspection with safe fallbacks for existing models."""

    FRAGILE_OPS = {"embedding", "norm", "layernorm", "rmsnorm", "head", "lm_head"}
    SAFE_BINARY_OPS = {"linear", "conv1d", "conv2d", "matmul"}

    def inspect_layers(self, model: Any) -> list[LayerProfile]:
        if hasattr(model, "nearbit_layers"):
            return list(model.nearbit_layers())
        if hasattr(model, "named_modules"):
            return self._from_named_modules(model.named_modules())
        if isinstance(model, dict) and "layers" in model:
            return self._from_mapping(model["layers"])
        raise TypeError("Unsupported model format. Provide nearbit_layers(), named_modules(), or a layer mapping.")

    def identify_model(self, model: Any) -> tuple[str, str]:
        model_name = getattr(model, "name", model.__class__.__name__)
        model_type = getattr(model, "model_type", "transformer")
        return model_name, model_type

    def _from_named_modules(self, modules: Iterable[tuple[str, Any]]) -> list[LayerProfile]:
        layers: list[LayerProfile] = []
        for name, module in modules:
            if not name:
                continue
            op_type = module.__class__.__name__.lower()
            parameter_count = int(getattr(module, "parameter_count", 0) or self._safe_numel(module))
            fragile = self._is_fragile(name, op_type)
            supports_binary = self._supports_binary(op_type) and not fragile
            layers.append(
                LayerProfile(
                    name=name,
                    op_type=op_type,
                    parameter_count=parameter_count,
                    is_fragile=fragile,
                    supports_binary=supports_binary,
                )
            )
        return layers

    def _from_mapping(self, layers_map: Iterable[dict[str, Any]]) -> list[LayerProfile]:
        layers: list[LayerProfile] = []
        for item in layers_map:
            name = item["name"]
            op_type = str(item.get("op_type", "linear")).lower()
            fragile = bool(item.get("is_fragile", self._is_fragile(name, op_type)))
            supports_binary = bool(item.get("supports_binary", self._supports_binary(op_type) and not fragile))
            layers.append(
                LayerProfile(
                    name=name,
                    op_type=op_type,
                    parameter_count=int(item.get("parameter_count", 0)),
                    output_shape=tuple(item.get("output_shape", ())),
                    is_fragile=fragile,
                    supports_binary=supports_binary,
                )
            )
        return layers

    def _is_fragile(self, name: str, op_type: str) -> bool:
        name_lower = name.lower()
        return any(token in name_lower or token in op_type for token in self.FRAGILE_OPS)

    def _supports_binary(self, op_type: str) -> bool:
        return any(token in op_type for token in self.SAFE_BINARY_OPS)

    def _safe_numel(self, module: Any) -> int:
        parameters = getattr(module, "parameters", None)
        if parameters is None:
            return 0
        total = 0
        for param in parameters():
            total += int(getattr(param, "numel", lambda: 0)())
        return total
