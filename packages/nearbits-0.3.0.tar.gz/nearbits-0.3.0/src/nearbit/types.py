from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from typing import Any


class PrecisionKind(str, Enum):
    FP16 = "fp16"
    INT8 = "int8"
    INT4 = "int4"
    BINARY = "binary"
    BINARY_OUTLIERS = "binary+outliers"
    BINARY_LOW_RANK = "binary+low-rank"


@dataclass(slots=True)
class CalibrationSample:
    inputs: dict[str, Any]
    target: Any | None = None


@dataclass(slots=True)
class HardwareProfile:
    device_name: str
    ram_budget_bytes: int
    flash_budget_bytes: int
    latency_budget_ms: float
    accelerator: str = "cpu"


@dataclass(slots=True)
class RuntimeProfile:
    stream_from_flash: bool
    static_arena_bytes: int
    prefer_fused_kernels: bool
    max_sequence_length: int


@dataclass(slots=True)
class LayerProfile:
    name: str
    op_type: str
    parameter_count: int
    output_shape: tuple[int, ...] = ()
    is_fragile: bool = False
    supports_binary: bool = True


@dataclass(slots=True)
class LayerSensitivity:
    name: str
    op_type: str
    sensitivity_score: float
    activation_range: tuple[float, float]
    outlier_fraction: float
    estimated_binary_error: float
    is_fragile: bool
    supports_binary: bool
    recommended_precision: PrecisionKind | None = None


@dataclass(slots=True)
class SensitivityReport:
    model_name: str
    model_type: str
    layers: list[LayerSensitivity]
    baseline_metric: float
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class LayerPlan:
    name: str
    precision: PrecisionKind
    group_size: int
    outlier_fraction: float
    residual_rank: int
    keep_high_precision_copy: bool = False
    notes: str = ""


@dataclass(slots=True)
class CompressionPlan:
    model_name: str
    model_type: str
    quality_budget: float
    ram_budget: int
    flash_budget: int
    latency_budget: float
    activation_precision: PrecisionKind
    kv_cache_precision: PrecisionKind
    recent_window_tokens: int
    layers: list[LayerPlan]
    summary: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class PackedLayer:
    name: str
    precision: PrecisionKind
    payload: dict[str, Any]


@dataclass(slots=True)
class ArtifactManifest:
    model_name: str
    model_type: str
    supported_operators: list[str]
    activation_precision: str
    kv_cache_policy: dict[str, Any]
    expected_peak_ram_bytes: int
    layer_precisions: dict[str, str]
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class CompressionArtifact:
    manifest: ArtifactManifest
    layers: list[PackedLayer]
    memory_schedule: list[dict[str, Any]]


@dataclass(slots=True)
class RuntimeResult:
    outputs: dict[str, Any]
    peak_ram_bytes: int
    executed_layers: list[str]
