from __future__ import annotations


class ToyLinear:
    def __init__(self, parameter_count: int) -> None:
        self.parameter_count = parameter_count

    def parameters(self):
        return []


class ToyTransformer:
    name = "toy-transformer"
    model_type = "transformer"

    def __init__(self) -> None:
        self.layers = {
            "embed_tokens": ToyLinear(4096),
            "blocks.0.attn.q_proj": ToyLinear(16384),
            "blocks.0.attn.k_proj": ToyLinear(16384),
            "blocks.0.attn.v_proj": ToyLinear(16384),
            "blocks.0.mlp.up_proj": ToyLinear(32768),
            "norm": ToyLinear(1024),
            "lm_head": ToyLinear(4096),
        }

    def named_modules(self):
        return list(self.layers.items())

    def nearbit_weights(self):
        return {name: [0.125, -0.25, 0.5, -0.75] * 16 for name in self.layers}
