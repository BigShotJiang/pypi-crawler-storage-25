"""Example model adapters for manual integration."""
