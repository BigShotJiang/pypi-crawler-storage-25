from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F

PROTECTED_NAME_TOKENS = (
    "embed",
    "norm",
    "layernorm",
    "rmsnorm",
    "lm_head",
    "output",
)


@dataclass(slots=True)
class HybridLowBitConfig:
    group_size: int = 128
    bitnet_scale_blend: float = 0.7
    bitnet_threshold_factor: float = 0.9
    vip_fraction: float = 0.001
    max_vip_fraction: float = 0.01
    vip_growth_factor: float = 2.0
    vip_bits: int = 4
    activation_bits: int = 8


class PackedInt8Linear(nn.Module):
    def __init__(
        self,
        qweight: torch.Tensor,
        scales: torch.Tensor,
        bias: torch.Tensor | None,
        in_features: int,
        out_features: int,
    ) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.register_buffer("qweight", qweight.contiguous())
        self.register_buffer("scales", scales.contiguous())
        if bias is None:
            self.register_buffer("bias", None)
        else:
            self.register_buffer("bias", bias.contiguous())

    @classmethod
    def from_weight_bias(
        cls,
        weight: torch.Tensor,
        bias: torch.Tensor | None,
        in_features: int,
        out_features: int,
    ) -> "PackedInt8Linear":
        weight = weight.detach().to(torch.float32).cpu()
        scales = weight.abs().amax(dim=1).clamp_min(1e-8) / 127.0
        qweight = torch.round(weight / scales.unsqueeze(1)).clamp(-127, 127).to(torch.int8)
        bias = bias.detach().to(torch.float32).cpu() if bias is not None else None
        return cls(qweight=qweight, scales=scales.to(torch.float16), bias=bias, in_features=in_features, out_features=out_features)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        weight = self.qweight.to(torch.float32) * self.scales.to(torch.float32).unsqueeze(1)
        return F.linear(x.to(torch.float32), weight, self.bias)


class PackedInt8Embedding(nn.Module):
    def __init__(self, qweight: torch.Tensor, scales: torch.Tensor, embedding_dim: int) -> None:
        super().__init__()
        self.num_embeddings = int(qweight.shape[0])
        self.embedding_dim = embedding_dim
        self.register_buffer("qweight", qweight.contiguous())
        self.register_buffer("scales", scales.contiguous())

    @classmethod
    def from_embedding(cls, embedding: nn.Embedding) -> "PackedInt8Embedding":
        weight = embedding.weight.detach().to(torch.float32).cpu()
        scales = weight.abs().amax(dim=1).clamp_min(1e-8) / 127.0
        qweight = torch.round(weight / scales.unsqueeze(1)).clamp(-127, 127).to(torch.int8)
        return cls(qweight=qweight, scales=scales.to(torch.float16), embedding_dim=embedding.embedding_dim)

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        flat_ids = input_ids.reshape(-1)
        rows = self.qweight.index_select(0, flat_ids).to(torch.float32)
        scales = self.scales.index_select(0, flat_ids).to(torch.float32).unsqueeze(1)
        output = rows * scales
        return output.view(*input_ids.shape, self.embedding_dim)


class PackedBitNetLinear(nn.Module):
    def __init__(
        self,
        packed_codes: torch.Tensor,
        scales: torch.Tensor,
        bias: torch.Tensor | None,
        in_features: int,
        out_features: int,
        group_size: int,
        outlier_rows: torch.Tensor,
        outlier_cols: torch.Tensor,
        outlier_values: torch.Tensor,
        outlier_scales: torch.Tensor,
        outlier_bits: int,
        outlier_count: int,
        activation_bits: int,
    ) -> None:
        super().__init__()
        self.mode = "bitnet158"
        self.in_features = in_features
        self.out_features = out_features
        self.group_size = group_size
        self.outlier_bits = outlier_bits
        self.outlier_count = outlier_count
        self.activation_bits = activation_bits
        self.register_buffer("packed_codes", packed_codes.contiguous())
        self.register_buffer("scales", scales.contiguous())
        if bias is None:
            self.register_buffer("bias", None)
        else:
            self.register_buffer("bias", bias.contiguous())
        self.register_buffer("outlier_rows", outlier_rows.contiguous())
        self.register_buffer("outlier_cols", outlier_cols.contiguous())
        self.register_buffer("outlier_values", outlier_values.contiguous())
        self.register_buffer("outlier_scales", outlier_scales.contiguous())

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x32 = x.to(torch.float32)
        if self.activation_bits <= 8:
            x32 = _quantize_activations_per_token(x32, self.activation_bits)
        weight = self._dequantize_weight(x.device)
        return F.linear(x32, weight, self.bias)

    def _dequantize_weight(self, device: torch.device) -> torch.Tensor:
        codes = _unpack_ternary(self.packed_codes.to(device), self.in_features).to(torch.float32)
        scale_map = _expand_group_scales(self.scales.to(device).to(torch.float32), self.in_features, self.group_size)
        weight = codes * scale_map
        if self.outlier_count > 0:
            rows = self.outlier_rows.to(device=device, dtype=torch.long)
            cols = self.outlier_cols.to(device=device, dtype=torch.long)
            values = _dequantize_vip_values(
                self.outlier_values.to(device),
                self.outlier_bits,
                self.outlier_count,
            ).to(torch.float32)
            values = values * self.outlier_scales.to(device=device, dtype=torch.float32).index_select(0, rows)
            weight[rows, cols] += values
        return weight


def convert_model_to_hybrid_lowbit(model: nn.Module, config: HybridLowBitConfig | None = None) -> nn.Module:
    from .huggingface import normalize_model_to_float32_cpu

    active_config = config or HybridLowBitConfig()
    if active_config.vip_bits not in {4, 8}:
        raise ValueError("HybridLowBitConfig.vip_bits must be 4 or 8.")
    if active_config.activation_bits not in {8, 16, 32}:
        raise ValueError("HybridLowBitConfig.activation_bits must be 8, 16, or 32.")
    reference_parameter_count = sum(param.numel() for param in model.parameters())
    normalize_model_to_float32_cpu(model)
    metadata: list[dict[str, object]] = []
    _replace_modules(model, active_config, metadata)
    summary = dict(Counter(item["mode"] for item in metadata))
    model.nearbit_lowbit_metadata = metadata
    model.nearbit_lowbit_summary = summary
    model.nearbit_reference_parameter_count = reference_parameter_count
    model.nearbits_lowbit_metadata = metadata
    model.nearbits_lowbit_summary = summary
    model.nearbits_reference_parameter_count = reference_parameter_count
    return model.eval()


def estimate_effective_bits(model: nn.Module) -> float:
    total_bits = 0
    for tensor in list(model.parameters()) + list(model.buffers()):
        total_bits += tensor.element_size() * tensor.numel() * 8
    reference_parameter_count = int(
        getattr(model, "nearbits_reference_parameter_count", 0)
        or getattr(model, "nearbit_reference_parameter_count", 0)
    )
    if reference_parameter_count > 0:
        return round(total_bits / reference_parameter_count, 4)
    total_values = sum(tensor.numel() for tensor in list(model.parameters()) + list(model.buffers()))
    if total_values == 0:
        return 0.0
    return round(total_bits / total_values, 4)


def _replace_modules(module: nn.Module, config: HybridLowBitConfig, metadata: list[dict[str, object]], prefix: str = "") -> None:
    for name, child in list(module.named_children()):
        full_name = f"{prefix}.{name}" if prefix else name
        lower = full_name.lower()
        if isinstance(child, nn.Embedding):
            packed = PackedInt8Embedding.from_embedding(child)
            setattr(module, name, packed)
            metadata.append({"name": full_name, "mode": "int8_embedding"})
            continue

        linear_spec = _extract_linear_spec(child)
        if linear_spec is not None:
            replacement, info = _convert_linear_like(lower, full_name, linear_spec, config)
            setattr(module, name, replacement)
            metadata.append(info)
            continue

        _replace_modules(child, config, metadata, full_name)


def _convert_linear_like(
    lower_name: str,
    full_name: str,
    linear_spec: dict[str, Any],
    config: HybridLowBitConfig,
) -> tuple[nn.Module, dict[str, object]]:
    if _should_protect(lower_name):
        return PackedInt8Linear.from_weight_bias(
            linear_spec["weight"],
            linear_spec["bias"],
            linear_spec["in_features"],
            linear_spec["out_features"],
        ), {"name": full_name, "mode": "int8", "nmse": 0.0}

    weight = linear_spec["weight"].detach().to(torch.float32).cpu()
    payload, nmse, vip_fraction = _search_payload(weight, config)
    return _build_bitnet158_linear(linear_spec, payload, config), {
        "name": full_name,
        "mode": "bitnet158",
        "nmse": round(nmse, 6),
        "vip_fraction": round(vip_fraction, 6),
        "vip_bits": config.vip_bits,
        "activation_bits": config.activation_bits,
    }


def _build_bitnet158_linear(
    linear_spec: dict[str, Any],
    payload: dict[str, torch.Tensor | int],
    config: HybridLowBitConfig,
) -> PackedBitNetLinear:
    bias = linear_spec["bias"].detach().to(torch.float32).cpu() if linear_spec["bias"] is not None else None
    return PackedBitNetLinear(
        packed_codes=payload["packed_codes"],
        scales=payload["scales"].to(torch.float16),
        bias=bias,
        in_features=linear_spec["in_features"],
        out_features=linear_spec["out_features"],
        group_size=config.group_size,
        outlier_rows=payload["outlier_rows"],
        outlier_cols=payload["outlier_cols"],
        outlier_values=payload["outlier_values"],
        outlier_scales=payload["outlier_scales"].to(torch.float16),
        outlier_bits=int(payload["outlier_bits"]),
        outlier_count=int(payload["outlier_count"]),
        activation_bits=config.activation_bits,
    )


def _extract_linear_spec(module: nn.Module) -> dict[str, Any] | None:
    if isinstance(module, nn.Linear):
        return {
            "weight": module.weight,
            "bias": module.bias,
            "in_features": module.in_features,
            "out_features": module.out_features,
        }
    if module.__class__.__name__ == "Conv1D" and hasattr(module, "weight") and hasattr(module, "bias"):
        weight = module.weight.detach().transpose(0, 1)
        bias = module.bias if isinstance(module.bias, torch.Tensor) else None
        return {
            "weight": weight,
            "bias": bias,
            "in_features": int(weight.shape[1]),
            "out_features": int(weight.shape[0]),
        }
    return None


def _search_payload(weight: torch.Tensor, config: HybridLowBitConfig) -> tuple[dict[str, torch.Tensor | int], float, float]:
    fraction = max(config.vip_fraction, 0.0)
    max_fraction = max(fraction, config.max_vip_fraction)
    best_payload: dict[str, torch.Tensor | int] | None = None
    best_nmse = float("inf")
    best_fraction = fraction
    while True:
        payload, nmse = _quantize_bitnet158_payload(weight, config.group_size, fraction, config.vip_bits, config.bitnet_scale_blend, config.bitnet_threshold_factor)
        if nmse < best_nmse:
            best_payload = payload
            best_nmse = nmse
            best_fraction = fraction
        if fraction >= max_fraction or nmse <= 0.05:
            return best_payload, best_nmse, best_fraction
        next_fraction = min(max_fraction, max(fraction * config.vip_growth_factor, fraction + (1.0 / max(weight.shape[1], 1))))
        if next_fraction <= fraction:
            return best_payload, best_nmse, best_fraction
        fraction = next_fraction


def _quantize_bitnet158_payload(
    weight: torch.Tensor,
    group_size: int,
    vip_fraction: float,
    vip_bits: int,
    scale_blend: float,
    threshold_factor: float,
) -> tuple[dict[str, torch.Tensor | int], float]:
    scales, absmeans = _compute_bitnet_group_params(weight, group_size, scale_blend)
    codes = _quantize_bitnet_groups(weight, absmeans, group_size, threshold_factor)
    packed_codes = _pack_ternary(codes)
    recon_base = _reconstruct_ternary(packed_codes, scales, weight.shape[1], group_size)
    residual = weight - recon_base
    outlier_payload = _extract_vip_residuals(residual, vip_fraction, vip_bits)
    recon = recon_base + _reconstruct_outliers(weight.shape, outlier_payload)
    nmse = _normalized_mse(weight, recon)
    payload = {
        "packed_codes": packed_codes,
        "scales": scales,
        **outlier_payload,
    }
    return payload, nmse


def _compute_bitnet_group_params(weight: torch.Tensor, group_size: int, scale_blend: float) -> tuple[torch.Tensor, torch.Tensor]:
    rows, cols = weight.shape
    groups = math.ceil(cols / group_size)
    scales = torch.zeros(rows, groups, dtype=torch.float32)
    absmeans = torch.zeros(rows, groups, dtype=torch.float32)
    for group_index in range(groups):
        start = group_index * group_size
        end = min(cols, start + group_size)
        chunk = weight[:, start:end]
        absmean = chunk.abs().mean(dim=1)
        rms = torch.sqrt(chunk.pow(2).mean(dim=1).clamp_min(1e-8))
        scales[:, group_index] = (scale_blend * absmean) + ((1.0 - scale_blend) * rms)
        absmeans[:, group_index] = absmean
    return scales.clamp_min(1e-8), absmeans.clamp_min(1e-8)


def _quantize_bitnet_groups(weight: torch.Tensor, absmeans: torch.Tensor, group_size: int, threshold_factor: float) -> torch.Tensor:
    rows, cols = weight.shape
    groups = math.ceil(cols / group_size)
    codes = torch.zeros(rows, cols, dtype=torch.uint8)
    for group_index in range(groups):
        start = group_index * group_size
        end = min(cols, start + group_size)
        chunk = weight[:, start:end]
        threshold = absmeans[:, group_index].unsqueeze(1) * threshold_factor
        positive = chunk >= threshold
        negative = chunk <= -threshold
        chunk_codes = torch.zeros_like(chunk, dtype=torch.uint8)
        chunk_codes[positive] = 1
        chunk_codes[negative] = 2
        codes[:, start:end] = chunk_codes
    return codes


def _extract_vip_residuals(residual: torch.Tensor, fraction: float, bits: int) -> dict[str, torch.Tensor | int]:
    rows, cols = residual.shape
    per_row = math.ceil(cols * fraction)
    if per_row <= 0:
        return {
            "outlier_rows": torch.empty(0, dtype=torch.int32),
            "outlier_cols": torch.empty(0, dtype=torch.int32),
            "outlier_values": torch.empty(0, dtype=torch.uint8 if bits == 4 else torch.int8),
            "outlier_scales": torch.zeros(rows, dtype=torch.float32),
            "outlier_bits": bits,
            "outlier_count": 0,
        }

    magnitudes, indices = residual.abs().topk(per_row, dim=1)
    selected_values = residual.gather(1, indices)
    row_ids = torch.arange(rows, dtype=torch.int32).unsqueeze(1).expand(-1, per_row).reshape(-1)
    col_ids = indices.reshape(-1).to(torch.int32)
    outlier_values = selected_values.reshape(-1)
    max_qvalue = 7.0 if bits == 4 else 127.0
    scales = magnitudes.amax(dim=1).clamp_min(1e-8) / max_qvalue
    qvalues = torch.round(outlier_values / scales.index_select(0, row_ids.to(torch.long))).clamp(-max_qvalue, max_qvalue).to(torch.int8)
    return {
        "outlier_rows": row_ids,
        "outlier_cols": col_ids,
        "outlier_values": _pack_vip_values(qvalues, bits),
        "outlier_scales": scales,
        "outlier_bits": bits,
        "outlier_count": int(qvalues.numel()),
    }


def _quantize_activations_per_token(x: torch.Tensor, bits: int) -> torch.Tensor:
    max_q = float((2 ** (bits - 1)) - 1)
    original_shape = x.shape
    flat = x.reshape(-1, original_shape[-1])
    scales = flat.abs().amax(dim=1, keepdim=True).clamp_min(1e-8) / max_q
    q = torch.round(flat / scales).clamp(-max_q, max_q)
    return (q * scales).reshape(original_shape)


def _pack_ternary(codes: torch.Tensor) -> torch.Tensor:
    rows, cols = codes.shape
    padded = ((cols + 3) // 4) * 4
    if padded != cols:
        padding = torch.zeros(rows, padded - cols, dtype=torch.uint8)
        codes = torch.cat([codes, padding], dim=1)
    reshaped = codes.view(rows, -1, 4).to(torch.int16)
    shifts = torch.tensor([0, 2, 4, 6], dtype=torch.int16).view(1, 1, 4)
    packed = torch.bitwise_left_shift(reshaped, shifts).sum(dim=2)
    return packed.to(torch.uint8)


def _unpack_ternary(packed: torch.Tensor, original_cols: int) -> torch.Tensor:
    shifts = torch.tensor([0, 2, 4, 6], device=packed.device, dtype=torch.uint8)
    expanded = torch.bitwise_and(torch.bitwise_right_shift(packed.unsqueeze(-1), shifts), 0b11)
    codes = expanded.view(packed.shape[0], -1)[:, :original_cols].to(torch.int8)
    output = torch.zeros_like(codes, dtype=torch.int8)
    output[codes == 1] = 1
    output[codes == 2] = -1
    return output


def _expand_group_scales(scales: torch.Tensor, original_cols: int, group_size: int) -> torch.Tensor:
    expanded = torch.repeat_interleave(scales, repeats=group_size, dim=1)
    return expanded[:, :original_cols]


def _reconstruct_ternary(packed_codes: torch.Tensor, scales: torch.Tensor, original_cols: int, group_size: int) -> torch.Tensor:
    codes = _unpack_ternary(packed_codes, original_cols).to(torch.float32)
    return codes * _expand_group_scales(scales.to(torch.float32), original_cols, group_size)


def _reconstruct_outliers(shape: tuple[int, int], payload: dict[str, torch.Tensor | int]) -> torch.Tensor:
    rows, cols = shape
    output = torch.zeros(rows, cols, dtype=torch.float32)
    if int(payload["outlier_count"]) == 0:
        return output
    row_ids = payload["outlier_rows"].to(torch.long)
    col_ids = payload["outlier_cols"].to(torch.long)
    values = _dequantize_vip_values(payload["outlier_values"], int(payload["outlier_bits"]), int(payload["outlier_count"])).to(torch.float32)
    values = values * payload["outlier_scales"].index_select(0, row_ids).to(torch.float32)
    output[row_ids, col_ids] = values
    return output


def _pack_vip_values(values: torch.Tensor, bits: int) -> torch.Tensor:
    if bits == 8:
        return values.to(torch.int8)
    if bits == 4:
        return _pack_int4(values.to(torch.int8))
    raise ValueError(f"Unsupported vip bit width: {bits}")


def _dequantize_vip_values(values: torch.Tensor, bits: int, count: int) -> torch.Tensor:
    if bits == 8:
        return values.reshape(-1)[:count].to(torch.int8)
    if bits == 4:
        return _unpack_int4(values)[:count]
    raise ValueError(f"Unsupported vip bit width: {bits}")


def _pack_int4(values: torch.Tensor) -> torch.Tensor:
    clamped = values.clamp(-7, 7).to(torch.int16)
    unsigned = torch.where(clamped < 0, clamped + 16, clamped).to(torch.uint8)
    if unsigned.numel() % 2 == 1:
        unsigned = torch.cat([unsigned, torch.zeros(1, dtype=torch.uint8)], dim=0)
    paired = unsigned.view(-1, 2)
    return (paired[:, 0] | torch.bitwise_left_shift(paired[:, 1], 4)).to(torch.uint8)


def _unpack_int4(values: torch.Tensor) -> torch.Tensor:
    flat = values.reshape(-1)
    low = torch.bitwise_and(flat, 0x0F)
    high = torch.bitwise_and(torch.bitwise_right_shift(flat, 4), 0x0F)
    merged = torch.stack([low, high], dim=1).reshape(-1).to(torch.int8)
    merged[merged >= 8] -= 16
    return merged


def _normalized_mse(weight: torch.Tensor, recon: torch.Tensor) -> float:
    denom = weight.pow(2).mean().clamp_min(1e-8)
    return float(((weight - recon).pow(2).mean() / denom).item())


def _should_protect(module_name: str) -> bool:
    return any(token in module_name for token in PROTECTED_NAME_TOKENS)
