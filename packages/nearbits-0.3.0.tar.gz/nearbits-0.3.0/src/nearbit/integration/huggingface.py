from __future__ import annotations

from collections import Counter

import torch
import torch.nn as nn
import torch.nn.functional as F

PROTECTED_NAME_TOKENS = (
    "embed",
    "norm",
    "layernorm",
    "rmsnorm",
    "lm_head",
    "output",
)


def detect_model_dtypes(model: nn.Module) -> dict[str, int]:
    counts: Counter[str] = Counter()
    for tensor in _iter_tensors(model):
        if tensor.is_floating_point() or tensor.dtype in {torch.int8, torch.int16, torch.int32, torch.int64, torch.uint8}:
            counts[str(tensor.dtype).replace("torch.", "")] += int(tensor.numel())
    return dict(sorted(counts.items()))


def normalize_model_to_float32_cpu(model: nn.Module) -> nn.Module:
    model.cpu()
    model.eval()
    with torch.no_grad():
        for param in model.parameters():
            if param.is_floating_point() and param.dtype != torch.float32:
                param.data = param.data.to(torch.float32)
        for _, buffer in model.named_buffers(recurse=True):
            if buffer.is_floating_point() and buffer.dtype != torch.float32:
                buffer.data = buffer.data.to(torch.float32)
    return model


def quantize_dynamic_int8(model: nn.Module) -> nn.Module:
    prepared = normalize_model_to_float32_cpu(model)
    quantized = torch.ao.quantization.quantize_dynamic(
        prepared,
        {nn.Linear},
        dtype=torch.qint8,
    )
    return quantized.eval()


class WeightOnlyLinear(nn.Module):
    """Inference-only int8 weight-only linear layer with per-output-channel scales."""

    def __init__(
        self,
        qweight: torch.Tensor,
        scales: torch.Tensor,
        bias: torch.Tensor | None,
        in_features: int,
        out_features: int,
    ) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.register_buffer("qweight", qweight.contiguous())
        self.register_buffer("scales", scales.contiguous())
        if bias is None:
            self.register_buffer("bias", None)
        else:
            self.register_buffer("bias", bias.contiguous())

    @classmethod
    def from_linear(cls, linear: nn.Linear) -> "WeightOnlyLinear":
        weight = linear.weight.detach().to(torch.float32).cpu()
        max_abs = weight.abs().amax(dim=1).clamp_min(1e-8)
        scales = max_abs / 127.0
        qweight = torch.round(weight / scales.unsqueeze(1)).clamp(-127, 127).to(torch.int8)
        bias = linear.bias.detach().to(torch.float32).cpu() if linear.bias is not None else None
        return cls(
            qweight=qweight,
            scales=scales,
            bias=bias,
            in_features=linear.in_features,
            out_features=linear.out_features,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x32 = x.to(torch.float32)
        weight = self.qweight.to(torch.float32) * self.scales.unsqueeze(1)
        return F.linear(x32, weight, self.bias)


def convert_linear_layers_to_weight_only_int8(model: nn.Module) -> nn.Module:
    prepared = normalize_model_to_float32_cpu(model)
    _replace_linear_layers(prepared)
    return prepared.eval()


def _replace_linear_layers(module: nn.Module, prefix: str = "") -> None:
    for name, child in list(module.named_children()):
        full_name = f"{prefix}.{name}" if prefix else name
        if isinstance(child, nn.Linear) and not _should_protect(full_name):
            setattr(module, name, WeightOnlyLinear.from_linear(child))
            continue
        _replace_linear_layers(child, full_name)


def _should_protect(module_name: str) -> bool:
    lowered = module_name.lower()
    return any(token in lowered for token in PROTECTED_NAME_TOKENS)


def _iter_tensors(model: nn.Module):
    for _, tensor in model.named_parameters(recurse=True):
        yield tensor
    for _, tensor in model.named_buffers(recurse=True):
        yield tensor
