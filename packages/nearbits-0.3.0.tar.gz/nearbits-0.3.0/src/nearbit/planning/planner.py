from __future__ import annotations

from ..defaults import (
    DEFAULT_ACTIVATION_PRECISION,
    DEFAULT_GROUP_SIZE,
    DEFAULT_OUTLIER_FRACTION,
    DEFAULT_RECENT_WINDOW_TOKENS,
    DEFAULT_RESIDUAL_RANK,
)
from ..types import CompressionPlan, LayerPlan, PrecisionKind, SensitivityReport


class Planner:
    def plan(
        self,
        sensitivity_report: SensitivityReport,
        quality_budget: float,
        ram_budget: int,
        flash_budget: int,
        latency_budget: float,
    ) -> CompressionPlan:
        layers: list[LayerPlan] = []
        protected_count = 0

        for index, layer in enumerate(sensitivity_report.layers):
            precision = layer.recommended_precision or PrecisionKind.INT8
            notes: list[str] = []

            if index in (0, len(sensitivity_report.layers) - 1) and precision in {
                PrecisionKind.BINARY,
                PrecisionKind.BINARY_OUTLIERS,
                PrecisionKind.BINARY_LOW_RANK,
            }:
                precision = PrecisionKind.INT8
                notes.append("protected boundary layer")

            if layer.is_fragile:
                precision = PrecisionKind.INT8
                protected_count += 1
                notes.append("fragile layer kept high precision")

            if layer.estimated_binary_error > quality_budget:
                precision = PrecisionKind.INT8
                notes.append("promoted due to quality budget")

            residual_rank = DEFAULT_RESIDUAL_RANK if precision == PrecisionKind.BINARY_LOW_RANK else 0
            outlier_fraction = max(layer.outlier_fraction, DEFAULT_OUTLIER_FRACTION)
            keep_high_precision_copy = precision == PrecisionKind.FP16

            layers.append(
                LayerPlan(
                    name=layer.name,
                    precision=precision,
                    group_size=DEFAULT_GROUP_SIZE,
                    outlier_fraction=outlier_fraction,
                    residual_rank=residual_rank,
                    keep_high_precision_copy=keep_high_precision_copy,
                    notes=", ".join(notes),
                )
            )

        summary = {
            "binary_layers": sum(1 for item in layers if item.precision == PrecisionKind.BINARY),
            "binary_outlier_layers": sum(1 for item in layers if item.precision == PrecisionKind.BINARY_OUTLIERS),
            "binary_low_rank_layers": sum(1 for item in layers if item.precision == PrecisionKind.BINARY_LOW_RANK),
            "protected_layers": protected_count,
        }

        kv_precision = PrecisionKind.INT4 if sensitivity_report.model_type == "transformer" else PrecisionKind.INT8
        return CompressionPlan(
            model_name=sensitivity_report.model_name,
            model_type=sensitivity_report.model_type,
            quality_budget=quality_budget,
            ram_budget=ram_budget,
            flash_budget=flash_budget,
            latency_budget=latency_budget,
            activation_precision=PrecisionKind(DEFAULT_ACTIVATION_PRECISION),
            kv_cache_precision=kv_precision,
            recent_window_tokens=DEFAULT_RECENT_WINDOW_TOKENS,
            layers=layers,
            summary=summary,
        )
