from __future__ import annotations

import time
from typing import Any

import torch

from .integration import (
    HybridLowBitConfig,
    convert_model_to_hybrid_lowbit,
    detect_model_dtypes,
    estimate_effective_bits,
)


def load_hf_model(model_id: str, trust_remote_code: bool = False):
    from transformers import AutoModelForCausalLM, AutoModelForSeq2SeqLM, AutoTokenizer

    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=trust_remote_code)
    if tokenizer.pad_token is None and tokenizer.eos_token is not None:
        tokenizer.pad_token = tokenizer.eos_token

    errors: list[str] = []
    for model_kind, loader in (("causal", AutoModelForCausalLM), ("seq2seq", AutoModelForSeq2SeqLM)):
        try:
            model = loader.from_pretrained(
                model_id,
                trust_remote_code=trust_remote_code,
                low_cpu_mem_usage=True,
            )
            model.eval()
            return model, tokenizer, model_kind
        except Exception as exc:
            errors.append(f"{model_kind}: {exc}")
    raise RuntimeError(f"Could not load model '{model_id}'. Details: {' | '.join(errors)}")


def compress_hf_model(model: Any, config: HybridLowBitConfig | None = None):
    return convert_model_to_hybrid_lowbit(model, config or HybridLowBitConfig())


def model_size_mb(model: Any) -> float:
    total_bytes = 0
    for tensor in model.state_dict().values():
        if hasattr(tensor, "element_size") and hasattr(tensor, "nelement"):
            total_bytes += tensor.element_size() * tensor.nelement()
    return round(total_bytes / (1024 ** 2), 4)


def model_report(model: Any) -> dict[str, Any]:
    summary = getattr(model, "nearbits_lowbit_summary", None)
    if summary is None:
        summary = getattr(model, "nearbit_lowbit_summary", {})
    return {
        "model_size_mb": model_size_mb(model),
        "effective_bits": estimate_effective_bits(model),
        "dtypes": detect_model_dtypes(model),
        "lowbit_summary": dict(summary),
    }


def chat(
    model: Any,
    tokenizer: Any,
    prompt: str,
    *,
    system_prompt: str | None = "You are a concise, helpful assistant.",
    max_new_tokens: int = 128,
    do_sample: bool = False,
    temperature: float = 0.7,
    top_p: float = 0.95,
) -> str:
    from transformers import GenerationConfig

    inputs = _build_inputs(tokenizer, prompt, system_prompt)
    generation_kwargs = {
        "max_new_tokens": max_new_tokens,
        "do_sample": do_sample,
        "pad_token_id": tokenizer.pad_token_id,
        "eos_token_id": tokenizer.eos_token_id,
    }
    if do_sample:
        generation_kwargs["temperature"] = temperature
        generation_kwargs["top_p"] = top_p
    generation_config = GenerationConfig(**generation_kwargs)

    with torch.inference_mode():
        output = model.generate(**inputs, generation_config=generation_config)

    is_encoder_decoder = bool(getattr(getattr(model, "config", None), "is_encoder_decoder", False))
    if is_encoder_decoder:
        generated_ids = output[0]
    else:
        input_len = inputs["input_ids"].shape[-1]
        generated_ids = output[0][input_len:]
    return tokenizer.decode(generated_ids, skip_special_tokens=True).strip()


def benchmark_prompts(
    model: Any,
    tokenizer: Any,
    prompts: list[str],
    *,
    system_prompt: str | None = "You are a concise, helpful assistant.",
    max_new_tokens: int = 64,
    do_sample: bool = False,
    temperature: float = 0.7,
    top_p: float = 0.95,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for prompt in prompts:
        started = time.perf_counter()
        response = chat(
            model,
            tokenizer,
            prompt,
            system_prompt=system_prompt,
            max_new_tokens=max_new_tokens,
            do_sample=do_sample,
            temperature=temperature,
            top_p=top_p,
        )
        elapsed = time.perf_counter() - started
        token_count = len(tokenizer.encode(response, add_special_tokens=False))
        rows.append(
            {
                "prompt": prompt,
                "response": response,
                "latency_sec": round(elapsed, 4),
                "generated_tokens": token_count,
                "tokens_per_sec": round(token_count / elapsed, 4) if elapsed > 0 else None,
            }
        )
    return rows


def _build_inputs(tokenizer: Any, prompt: str, system_prompt: str | None = None):
    if getattr(tokenizer, "chat_template", None):
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        rendered = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        return tokenizer(rendered, return_tensors="pt")
    return tokenizer(prompt, return_tensors="pt")
