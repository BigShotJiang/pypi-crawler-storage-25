from __future__ import annotations


class StaticArena:
    def __init__(self, capacity_bytes: int) -> None:
        self.capacity_bytes = capacity_bytes
        self.used_bytes = 0
        self.peak_bytes = 0

    def reserve(self, amount_bytes: int) -> None:
        self.used_bytes += amount_bytes
        self.peak_bytes = max(self.peak_bytes, self.used_bytes)
        if self.used_bytes > self.capacity_bytes:
            raise MemoryError(f"Static arena exceeded: {self.used_bytes} > {self.capacity_bytes}")

    def release(self, amount_bytes: int) -> None:
        self.used_bytes = max(0, self.used_bytes - amount_bytes)
