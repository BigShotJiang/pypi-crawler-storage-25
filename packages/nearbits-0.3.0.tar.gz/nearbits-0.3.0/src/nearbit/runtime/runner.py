from __future__ import annotations

from typing import Any

from ..types import CompressionArtifact, RuntimeProfile
from .arena import StaticArena
from .kernels import execute_layer


class Runner:
    def __init__(self, runtime_profile: RuntimeProfile) -> None:
        self.runtime_profile = runtime_profile

    def run(self, compressed_artifact: CompressionArtifact, inputs: dict[str, Any]) -> dict[str, Any]:
        arena = StaticArena(self.runtime_profile.static_arena_bytes)
        state: dict[str, Any] = {"inputs": inputs, "executed_layers": []}

        for layer in compressed_artifact.layers:
            arena.reserve(1024)
            execute_layer(layer, state)
            state["executed_layers"].append(layer.name)
            arena.release(1024)

        return {
            "outputs": {"status": "completed", "layer_count": len(compressed_artifact.layers)},
            "peak_ram_bytes": arena.peak_bytes,
            "executed_layers": state["executed_layers"],
            "manifest": compressed_artifact.manifest.to_dict(),
        }
