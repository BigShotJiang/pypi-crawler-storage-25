from __future__ import annotations

from ..types import PackedLayer, PrecisionKind


def execute_layer(layer: PackedLayer, state: dict[str, object]) -> dict[str, object]:
    if layer.precision in {PrecisionKind.BINARY, PrecisionKind.BINARY_OUTLIERS, PrecisionKind.BINARY_LOW_RANK}:
        state[layer.name] = {"kernel": "xnor-popcount", "payload": layer.payload}
    else:
        state[layer.name] = {"kernel": "dense", "payload": layer.payload}
    return state
