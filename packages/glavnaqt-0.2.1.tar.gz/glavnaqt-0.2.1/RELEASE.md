# Releasing GlavnaQt

GlavnaQt releases are driven from the workstation, not from forge-hosted CI.

Versions come from git tags via `setuptools-scm`.

## Validation

Run the normal package check:

```bash
scripts/ci/check
```

Run the fuller local pass, including the optional Qt smoke import:

```bash
scripts/ci/full
```

For a specific tagged release candidate:

```bash
scripts/ci/release-check v0.1.0
```

## Build artifacts locally

Build the normal PyPI artifacts:

```bash
scripts/release/build pypi v0.1.0
```

Build the TestPyPI variant:

```bash
scripts/release/build testpypi v0.1.0
```

The TestPyPI build rewrites the package name to `TestGlavnaQt`.

## Publish from the workstation

Upload to PyPI:

```bash
scripts/release/publish pypi v0.1.0
```

Upload to TestPyPI:

```bash
scripts/release/publish testpypi v0.1.0
```

`TWINE_REPOSITORY_URL` may be set to override the upload endpoint for manual or staging flows.

## Suggested release sequence

1. Run `scripts/ci/check`.
2. Run `scripts/ci/full`.
3. Run `scripts/ci/release-check vX.Y.Z`.
4. Tag locally with `git tag -a vX.Y.Z -m "vX.Y.Z"`.
5. Build and inspect artifacts with `scripts/release/build ...`.
6. Publish from the workstation with `scripts/release/publish ...`.
7. Push the tag after the local release artifacts are confirmed.

There is no GitHub Trusted Publishing dependency in the canonical flow anymore.
