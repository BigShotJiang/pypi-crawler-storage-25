# GlavnaQt

GlavnaQt is a PyQt6-based GUI framework for building desktop applications with customizable layouts and basic UI features.

## Features

- Layouts with splitters and sidebars (`CollapsibleSplitter`, `LayoutManager`)
- Event handling (`EventBus`, `transitions.py`)
- Configuration via `UIConfig` (Confumo)
- Status bar updates (`StatusBarManager`)
- Background tasks (`ThreadManager`, `TaskRunnable`)
- Light/dark theme support (`ThemeManager`, `ThemeWatcher`)
- Optional profiling (`profiler.py`) and logging (`logger.py`)

## Installation

For normal use, install the published package:

```bash
pip install GlavnaQt
```

For development from source, use a checkout from the canonical VPS host or public mirror, then create a virtual environment:

```bash
cd GlavnaQt
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python glavnaqt/examples/example.py
```

## Usage

Start the example app:

```bash
python glavnaqt/examples/example.py
```

Cycle layouts:

```bash
python glavnaqt/examples/example.py --cycle-layouts
```

Adjust application defaults in `glavnaqt/core/config.py`.

## Development

Run the local packaging check:

```bash
scripts/ci/check
```

Run the fuller local pass, including the optional Qt smoke import:

```bash
scripts/ci/full
```

For a tagged release candidate:

```bash
scripts/ci/release-check v0.1.0
```

## License

This repository ships under 0BSD; see `LICENSE` and `NOTICE`.

## Contact

Open an issue on the public Codeberg mirror.
