import importlib


def test_public_modules_import_with_runtime_dependencies_present():
    modules = [
        "glavnaqt",
        "glavnaqt.core.config",
        "glavnaqt.core.thread_manager",
        "glavnaqt.events.bus",
        "glavnaqt.ui.layout",
        "glavnaqt.ui.main_window",
        "glavnaqt.ui.theme_watcher",
    ]

    for module_name in modules:
        assert importlib.import_module(module_name)
