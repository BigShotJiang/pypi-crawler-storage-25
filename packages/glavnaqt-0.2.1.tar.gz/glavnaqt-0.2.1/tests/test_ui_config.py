import enum
import importlib
import sys
import types
import unittest
from contextlib import contextmanager
from unittest import mock


class _AlignmentFlag(enum.IntFlag):
    AlignLeft = 1
    AlignRight = 2
    AlignHCenter = 4
    AlignJustify = 8
    AlignAbsolute = 16
    AlignTop = 32
    AlignBottom = 64
    AlignVCenter = 128
    AlignCenter = AlignHCenter | AlignVCenter
    AlignLeading = AlignLeft
    AlignTrailing = AlignRight
    AlignHorizontal_Mask = AlignLeft | AlignRight | AlignHCenter | AlignJustify | AlignAbsolute
    AlignVertical_Mask = AlignTop | AlignBottom | AlignVCenter


class _Confumo:
    @staticmethod
    def expose(_app_name, config_cls, _globals, root=False):
        return config_cls.__new__(config_cls)


@contextmanager
def _load_config_with_stubs():
    qt_core = types.ModuleType("PyQt6.QtCore")
    qt_core.Qt = types.SimpleNamespace(AlignmentFlag=_AlignmentFlag)

    confumo = types.ModuleType("confumo")
    confumo.Confumo = _Confumo

    confuse = types.ModuleType("confuse")
    confuse.NotFoundError = KeyError

    platformdirs = types.ModuleType("platformdirs")
    platformdirs.user_config_dir = lambda *_args, **_kwargs: "/tmp"

    stubs = {
        "PyQt6": types.ModuleType("PyQt6"),
        "PyQt6.QtCore": qt_core,
        "confumo": confumo,
        "confuse": confuse,
        "platformdirs": platformdirs,
    }

    previous = sys.modules.pop("glavnaqt.core.config", None)
    with mock.patch.dict(sys.modules, stubs):
        module = importlib.import_module("glavnaqt.core.config")
        try:
            yield module
        finally:
            sys.modules.pop("glavnaqt.core.config", None)
            if previous is not None:
                sys.modules["glavnaqt.core.config"] = previous


class UIConfigTests(unittest.TestCase):
    def test_update_collapsible_section_merges_without_wiping_existing_fields(self):
        with _load_config_with_stubs() as module:
            cfg = module.UIConfig.__new__(module.UIConfig)
            cfg.collapsible_sections = {
                "bottom": {
                    "text": "Ready",
                    "alignment": module.Qt.AlignmentFlag.AlignLeft,
                }
            }
            existing_section = cfg.collapsible_sections["bottom"]
            bar = object()
            label = object()

            cfg.update_collapsible_section("bottom", widget=bar, status_label=label)

            self.assertIs(cfg.collapsible_sections["bottom"], existing_section)
            self.assertEqual(cfg.collapsible_sections["bottom"]["text"], "Ready")
            self.assertEqual(
                cfg.collapsible_sections["bottom"]["alignment"],
                module.Qt.AlignmentFlag.AlignLeft,
            )
            self.assertIs(cfg.collapsible_sections["bottom"]["widget"], bar)
            self.assertIs(cfg.collapsible_sections["bottom"]["status_label"], label)

    def test_update_collapsible_section_allows_explicit_none_clears(self):
        with _load_config_with_stubs() as module:
            cfg = module.UIConfig.__new__(module.UIConfig)
            cfg.collapsible_sections = {
                "bottom": {
                    "text": "Ready",
                    "alignment": module.Qt.AlignmentFlag.AlignLeft,
                    "status_label": object(),
                }
            }

            cfg.update_collapsible_section("bottom", text=None, status_label=None)

            self.assertIsNone(cfg.collapsible_sections["bottom"]["text"])
            self.assertIsNone(cfg.collapsible_sections["bottom"]["status_label"])
            self.assertEqual(
                cfg.collapsible_sections["bottom"]["alignment"],
                module.Qt.AlignmentFlag.AlignLeft,
            )

    def test_update_collapsible_section_keeps_legacy_defaults_for_new_sections(self):
        with _load_config_with_stubs() as module:
            cfg = module.UIConfig.__new__(module.UIConfig)
            cfg.collapsible_sections = {}
            bar = object()

            cfg.update_collapsible_section("bottom", widget=bar)

            self.assertIsNone(cfg.collapsible_sections["bottom"]["text"])
            self.assertEqual(
                cfg.collapsible_sections["bottom"]["alignment"],
                module.Qt.AlignmentFlag.AlignCenter,
            )
            self.assertIs(cfg.collapsible_sections["bottom"]["widget"], bar)

    def test_to_dict_preserves_theme_settings_for_yaml_round_trip(self):
        with _load_config_with_stubs() as module:
            cfg = module.UIConfig.__new__(module.UIConfig)
            cfg.cycle_layouts = False
            cfg.font_face = "Helvetica"
            cfg.font_size = 12
            cfg.splitter_handle_width = 5
            cfg.window_size = (640, 480)
            cfg.window_position = (100, 100)
            cfg.theme = "dark"
            cfg.light_start = "06:30"
            cfg.dark_start = "18:45"
            cfg.enable_status_bar_manager = True
            cfg.collapsible_sections = {
                "main_content": {
                    "text": "Main Content",
                    "alignment": module.Qt.AlignmentFlag.AlignCenter,
                }
            }

            dumped = cfg.to_dict()

            self.assertEqual(dumped["theme"], "dark")
            self.assertEqual(dumped["light_start"], "06:30")
            self.assertEqual(dumped["dark_start"], "18:45")


    def test_to_dict_omits_runtime_widget_entries_from_yaml_shape(self):
        with _load_config_with_stubs() as module:
            cfg = module.UIConfig.__new__(module.UIConfig)
            cfg.cycle_layouts = False
            cfg.font_face = "Helvetica"
            cfg.font_size = 12
            cfg.splitter_handle_width = 5
            cfg.window_size = (640, 480)
            cfg.window_position = (100, 100)
            cfg.theme = "auto"
            cfg.light_start = "07:00"
            cfg.dark_start = "19:00"
            cfg.enable_status_bar_manager = True
            cfg.collapsible_sections = {
                "bottom": {
                    "text": "Ready",
                    "alignment": module.Qt.AlignmentFlag.AlignLeft,
                    "widget": object(),
                    "status_label": object(),
                }
            }

            dumped = cfg.to_dict()

            self.assertEqual(
                dumped["collapsible_sections"]["bottom"],
                {
                    "text": "Ready",
                    "alignment": module.Qt.AlignmentFlag.AlignLeft,
                },
            )
            self.assertIn("widget", cfg.collapsible_sections["bottom"])
            self.assertIn("status_label", cfg.collapsible_sections["bottom"])


if __name__ == "__main__":
    unittest.main()
