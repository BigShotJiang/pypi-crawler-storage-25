import importlib
import sys
import types
import unittest
from contextlib import contextmanager
from unittest import mock


class _Signal:
    def __init__(self, *_args, **_kwargs):
        self.callbacks = []

    def connect(self, callback):
        self.callbacks.append(callback)

    def emit(self, *args, **kwargs):
        for callback in tuple(self.callbacks):
            callback(*args, **kwargs)


class _Timer:
    def __init__(self, *_args, **_kwargs):
        self.timeout = _Signal()
        self.active = False
        self.interval = None
        self.single_shot = False

    def setSingleShot(self, value):
        self.single_shot = value

    def isActive(self):
        return self.active

    def stop(self):
        self.active = False

    def start(self, interval):
        self.interval = interval
        self.active = True

    @staticmethod
    def singleShot(*_args, **_kwargs):
        pass


def _pyqt_signal(*_args, **_kwargs):
    return _Signal()


class _QMainWindow:
    def setCentralWidget(self, widget):
        self.central_widget = widget

    def setWindowTitle(self, title):
        self.window_title = title

    def setGeometry(self, x, y, width, height):
        self.geometry = (x, y, width, height)

    def setMinimumSize(self, width, height):
        self.minimum_size = (width, height)


class _Logger:
    def debug(self, *_args, **_kwargs):
        pass


class _Config:
    def __init__(self, sections):
        self.collapsible_sections = sections

    def copy(self):
        clone = self.__class__.__new__(self.__class__)
        clone.__dict__ = self.__dict__.copy()
        return clone


class _UIConfig(_Config):
    def get_section_alignment(self, section_name):
        return self.collapsible_sections.get(section_name, {}).get("alignment", "center")


@contextmanager
def _load_main_window_with_stubs(ui_config):
    qt_core = types.ModuleType("PyQt6.QtCore")
    qt_core.QTimer = _Timer
    qt_core.Qt = types.SimpleNamespace(
        AlignmentFlag=types.SimpleNamespace(AlignCenter="center")
    )
    qt_core.pyqtSignal = _pyqt_signal

    qt_widgets = types.ModuleType("PyQt6.QtWidgets")
    qt_widgets.QApplication = object
    qt_widgets.QMainWindow = _QMainWindow
    qt_widgets.QStatusBar = object

    qt_gui = types.ModuleType("PyQt6.QtGui")
    qt_gui.QPalette = object
    qt_gui.QColor = object

    core_config = types.ModuleType("glavnaqt.core.config")
    core_config.config = ui_config

    core = types.ModuleType("glavnaqt.core")
    core.logger = _Logger()

    events_bus = types.ModuleType("glavnaqt.events.bus")
    events_bus.create_or_get_shared_event_bus = lambda *args, **kwargs: None

    layout = types.ModuleType("glavnaqt.ui.layout")
    layout.LayoutManagerFactory = object

    theme_manager = types.ModuleType("glavnaqt.ui.theme_manager")
    theme_manager.ThemeManager = object

    theme_watcher = types.ModuleType("glavnaqt.ui.theme_watcher")
    theme_watcher.ThemeWatcher = object

    status_bar_initializer = types.ModuleType("glavnaqt.ui.status_bar_initializer")
    status_bar_initializer.StatusBarInitializer = object

    stubs = {
        "PyQt6": types.ModuleType("PyQt6"),
        "PyQt6.QtCore": qt_core,
        "PyQt6.QtWidgets": qt_widgets,
        "PyQt6.QtGui": qt_gui,
        "glavnaqt.core": core,
        "glavnaqt.core.config": core_config,
        "glavnaqt.events.bus": events_bus,
        "glavnaqt.ui.layout": layout,
        "glavnaqt.ui.theme_manager": theme_manager,
        "glavnaqt.ui.theme_watcher": theme_watcher,
        "glavnaqt.ui.status_bar_initializer": status_bar_initializer,
    }

    previous = sys.modules.pop("glavnaqt.ui.main_window", None)
    with mock.patch.dict(sys.modules, stubs):
        module = importlib.import_module("glavnaqt.ui.main_window")
        try:
            yield module
        finally:
            sys.modules.pop("glavnaqt.ui.main_window", None)
            if previous is not None:
                sys.modules["glavnaqt.ui.main_window"] = previous


class MainWindowFullscreenLayoutTests(unittest.TestCase):

    def test_resize_debouncer_emits_resize_finished_signal(self):
        ui_config = _UIConfig({"main_content": {"alignment": "center"}})

        with _load_main_window_with_stubs(ui_config) as module:
            resize_signal = _Signal()
            emissions = []

            window = types.SimpleNamespace(
                width=lambda: 321,
                height=lambda: 654,
                resizeFinished=resize_signal,
            )
            resize_signal.connect(lambda width, height: emissions.append((width, height)))

            debouncer = module.ResizeDebouncer(window)
            debouncer._emit_finished()

        self.assertEqual(emissions, [(321, 654)])

    def test_resize_finished_signal_rebroadcasts_to_event_bus_listener(self):
        ui_config = _UIConfig({"main_content": {"alignment": "center"}})

        class _LayoutManager:
            def __init__(self):
                self.adjust_calls = 0

            def adjust_layout(self):
                self.adjust_calls += 1

        class _Bus:
            def __init__(self):
                self.emissions = []
                self.listeners = {}

            def subscribe(self, event, callback):
                self.listeners.setdefault(event, []).append(callback)

            def emit(self, event, *args):
                self.emissions.append((event, args))
                for callback in tuple(self.listeners.get(event, ())):
                    callback(*args)

        with _load_main_window_with_stubs(ui_config) as module:
            window = module.MainWindow.__new__(module.MainWindow)
            window.layout_manager = _LayoutManager()
            window.event_bus = _Bus()
            window.resizeFinished = _Signal()
            window.resizeFinished.connect(window._publish_resize_finished)
            window.event_bus.subscribe("resize_finished", window.on_resize_done)

            window.resizeFinished.emit(400, 300)

        self.assertEqual(window.layout_manager.adjust_calls, 1)
        self.assertEqual(
            window.event_bus.emissions,
            [("resize_finished", (400, 300))],
        )

    def test_constructor_uses_injected_ui_config(self):
        default_config = types.SimpleNamespace(app_name="default")
        injected_config = types.SimpleNamespace(
            app_name="InjectedApp",
            window_position=(10, 20),
            window_size=(300, 200),
            theme="dark",
            collapsible_sections={"main_content": {"alignment": "center"}},
        )
        observed = {}

        class _Bus:
            def __init__(self):
                self.subscriptions = []
                self.emissions = []

            def subscribe(self, event, callback):
                self.subscriptions.append((event, callback))

            def emit(self, event, *args):
                self.emissions.append((event, args))

        class _ThemeManager:
            def __init__(self, parent, ui_config):
                observed["theme_config"] = ui_config

            def apply(self, theme):
                observed["applied_theme"] = theme

        class _StatusBarInitializer:
            def __init__(self, parent, ui_config, event_bus):
                observed["status_config"] = ui_config
                self.status_bar = object()
                self.status_label = object()

        class _WidgetAdjuster:
            def register_autofit_widget(self, widget):
                observed["autofit_widget"] = widget

        class _LayoutManager:
            def __init__(self):
                self.widget_adjuster = _WidgetAdjuster()

            def get_central_widget(self):
                return "central-widget"

            def adjust_layout(self):
                observed["adjusted"] = True

        class _LayoutManagerFactory:
            def create_layout_manager(self, layout_name, ui_config):
                observed["layout"] = (layout_name, ui_config)
                return _LayoutManager()

        with _load_main_window_with_stubs(default_config) as module:
            module.ThemeManager = _ThemeManager
            module.StatusBarInitializer = _StatusBarInitializer
            module.LayoutManagerFactory = _LayoutManagerFactory

            bus = _Bus()
            window = module.MainWindow(event_bus=bus, ui_config=injected_config)

        self.assertIs(window.ui_config, injected_config)
        self.assertEqual(observed["layout"], ("main", injected_config))
        self.assertIs(observed["theme_config"], injected_config)
        self.assertIs(observed["status_config"], injected_config)
        self.assertEqual(observed["applied_theme"], "dark")
        self.assertEqual(window.window_title, "InjectedApp")
        self.assertIn(("refresh_image_list", ()), bus.emissions)

    def test_fullscreen_layout_uses_detached_current_main_content_section(self):
        widget = object()
        current_sections = {
            "top": {"text": "Top", "alignment": "top"},
            "main_content": {
                "text": "Current Main",
                "alignment": "current-center",
                "widget": widget,
            },
        }
        current_config = _Config(current_sections)
        ui_config = _UIConfig(
            {
                "main_content": {
                    "text": "Original Main",
                    "alignment": "original-center",
                }
            }
        )

        with _load_main_window_with_stubs(ui_config) as module:
            window = module.MainWindow.__new__(module.MainWindow)
            window.ui_config = ui_config
            window.layout_manager = types.SimpleNamespace(
                current_config=current_config,
                last_config="last-layout",
            )
            window.is_fullscreen = False
            updated_configs = []
            window.update_ui = updated_configs.append

            window.toggle_fullscreen_layout()

        self.assertTrue(window.is_fullscreen)
        self.assertEqual(len(updated_configs), 1)
        fullscreen_config = updated_configs[0]
        self.assertIsNot(fullscreen_config, current_config)
        self.assertIsNot(fullscreen_config.collapsible_sections, current_sections)
        self.assertEqual(list(fullscreen_config.collapsible_sections), ["main_content"])
        self.assertIsNot(
            fullscreen_config.collapsible_sections["main_content"],
            current_sections["main_content"],
        )
        self.assertEqual(
            fullscreen_config.collapsible_sections["main_content"],
            {
                "text": "Current Main",
                "alignment": "current-center",
                "widget": widget,
            },
        )
        self.assertIn("top", current_sections)
        self.assertEqual(current_sections["main_content"]["alignment"], "current-center")

    def test_fullscreen_layout_falls_back_to_default_alignment(self):
        current_config = _Config({"main_content": {"text": "Current Main"}})
        ui_config = _UIConfig({"main_content": {"alignment": "fallback-center"}})

        with _load_main_window_with_stubs(ui_config) as module:
            window = module.MainWindow.__new__(module.MainWindow)
            window.ui_config = ui_config
            window.layout_manager = types.SimpleNamespace(current_config=current_config)

            fullscreen_config = window._fullscreen_layout_config()

        self.assertEqual(
            fullscreen_config.collapsible_sections,
            {"main_content": {"text": "Current Main", "alignment": "fallback-center"}},
        )


if __name__ == "__main__":
    unittest.main()
