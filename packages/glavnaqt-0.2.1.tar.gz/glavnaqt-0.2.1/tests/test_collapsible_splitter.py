import importlib
import sys
import types
import unittest
from contextlib import contextmanager
from unittest import mock


class _Signal:
    def __init__(self):
        self.callbacks = []

    def connect(self, callback):
        self.callbacks.append(callback)


class _QSplitter:
    def __init__(self, orientation, parent=None):
        self._parent = parent
        self._handle_width = None
        self._style_sheet = ""
        self.splitterMoved = _Signal()

    def parent(self):
        return self._parent

    def setHandleWidth(self, width):
        self._handle_width = width

    def setContentsMargins(self, *_args):
        pass

    def setStyleSheet(self, style_sheet):
        self._style_sheet = style_sheet

    def styleSheet(self):
        return self._style_sheet


class _Logger:
    def debug(self, *_args, **_kwargs):
        pass

    def error(self, *_args, **_kwargs):
        pass


@contextmanager
def _load_collapsible_splitter_with_qt_stubs():
    qt_core = types.ModuleType("PyQt6.QtCore")
    qt_core.Qt = types.SimpleNamespace(
        MouseButton=types.SimpleNamespace(LeftButton=1),
    )

    qt_gui = types.ModuleType("PyQt6.QtGui")
    qt_gui.QMouseEvent = object

    qt_widgets = types.ModuleType("PyQt6.QtWidgets")
    qt_widgets.QSplitter = _QSplitter

    splitter_handle = types.ModuleType("glavnaqt.ui.splitter_handle")
    splitter_handle.CollapsibleSplitterHandle = object

    core = types.ModuleType("glavnaqt.core")
    core.logger = _Logger()

    stubs = {
        "PyQt6": types.ModuleType("PyQt6"),
        "PyQt6.QtCore": qt_core,
        "PyQt6.QtGui": qt_gui,
        "PyQt6.QtWidgets": qt_widgets,
        "glavnaqt.core": core,
        "glavnaqt.ui.splitter_handle": splitter_handle,
    }

    previous = sys.modules.pop("glavnaqt.ui.collapsible_splitter", None)
    with mock.patch.dict(sys.modules, stubs):
        module = importlib.import_module("glavnaqt.ui.collapsible_splitter")
        try:
            yield module
        finally:
            sys.modules.pop("glavnaqt.ui.collapsible_splitter", None)
            if previous is not None:
                sys.modules["glavnaqt.ui.collapsible_splitter"] = previous


class CollapsibleSplitterTests(unittest.TestCase):
    def test_splitter_movement_does_not_call_qt_parent_adjust_layout(self):
        class ParentWithoutLayoutManagerApi:
            pass

        with _load_collapsible_splitter_with_qt_stubs() as module:
            splitter = module.CollapsibleSplitter(
                orientation="horizontal",
                parent=ParentWithoutLayoutManagerApi(),
                identifier="left",
            )
            splitter.on_splitter_moved(42, 1)


if __name__ == "__main__":
    unittest.main()
