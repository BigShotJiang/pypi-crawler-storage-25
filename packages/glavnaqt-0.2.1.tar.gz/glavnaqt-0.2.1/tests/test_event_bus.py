import logging
import threading
import unittest

from glavnaqt.events.bus import EventBus, create_or_get_shared_event_bus


class EventBusTests(unittest.TestCase):
    def test_listener_can_unsubscribe_during_emit_without_skipping_snapshot(self):
        bus = EventBus()
        calls = []

        def first():
            calls.append("first")
            bus.unsubscribe("ready", first)

        def second():
            calls.append("second")

        bus.subscribe("ready", first)
        bus.subscribe("ready", second)

        bus.emit("ready")

        self.assertEqual(calls, ["first", "second"])

    def test_listener_added_during_emit_is_not_called_until_next_emit(self):
        bus = EventBus()
        calls = []

        def first():
            calls.append("first")
            bus.subscribe("ready", second)

        def second():
            calls.append("second")

        bus.subscribe("ready", first)

        bus.emit("ready")
        self.assertEqual(calls, ["first"])

        bus.emit("ready")
        self.assertEqual(calls, ["first", "first", "second"])

    def test_listener_exception_is_logged_and_does_not_abort_later_listeners(self):
        bus = EventBus()
        calls = []

        def broken():
            calls.append("broken")
            raise RuntimeError("boom")

        def later():
            calls.append("later")

        bus.subscribe("ready", broken)
        bus.subscribe("ready", later)

        with self.assertLogs("glavnaqt.events.bus", level=logging.ERROR) as logs:
            bus.emit("ready")

        self.assertEqual(calls, ["broken", "later"])
        self.assertTrue(
            any("Unhandled exception in 'ready' event listener" in line for line in logs.output)
        )

    def test_shared_bus_factory_is_safe_under_concurrent_first_use(self):
        results = []
        barrier = threading.Barrier(8)

        def worker():
            barrier.wait()
            results.append(create_or_get_shared_event_bus("threaded-test-bus"))

        threads = [threading.Thread(target=worker) for _ in range(8)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        self.assertEqual(len({id(bus) for bus in results}), 1)


if __name__ == "__main__":
    unittest.main()
