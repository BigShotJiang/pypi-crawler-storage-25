import importlib
import sys
import types
import unittest
from contextlib import contextmanager
from unittest import mock


class _QObject:
    def __init__(self, *_args, **_kwargs):
        pass


def _pyqt_signal(*_args, **_kwargs):
    return object()


def _pyqt_slot(*_args, **_kwargs):
    def decorator(function):
        return function
    return decorator


class _QDBusVariant:
    def __init__(self, value):
        self._value = value

    def variant(self):
        return self._value


class _Reply:
    def __init__(self, arguments):
        self._arguments = arguments

    def arguments(self):
        return self._arguments


class _Connection:
    def __init__(self):
        self.connected = []

    def connect(self, *args):
        self.connected.append(args)
        return True


class _QDBusConnection:
    session = _Connection()

    @staticmethod
    def sessionBus():
        return _QDBusConnection.session


class _QDBusInterface:
    reply_value = None
    calls = []

    def __init__(self, *_args, **_kwargs):
        pass

    def call(self, *args):
        self.__class__.calls.append(args)
        return _Reply([self.__class__.reply_value])


class _Logger:
    def __init__(self):
        self.debug_messages = []

    def debug(self, message, *_args, **_kwargs):
        self.debug_messages.append(message)


class _Config:
    def __init__(self, theme="auto"):
        self.theme = theme


class _Window:
    def __init__(self, ui_config=None):
        self.ui_config = ui_config or _Config()
        self.applied = []

    def apply_theme(self, dark):
        self.applied.append(dark)


@contextmanager
def _load_theme_watcher(reply_value=1, platform="linux", include_dbus=True, global_config=None):
    qt_core = types.ModuleType("PyQt6.QtCore")
    qt_core.QObject = _QObject
    qt_core.pyqtSignal = _pyqt_signal
    qt_core.pyqtSlot = _pyqt_slot

    qt_dbus = types.ModuleType("PyQt6.QtDBus")
    qt_dbus.QDBusConnection = _QDBusConnection
    qt_dbus.QDBusInterface = _QDBusInterface
    qt_dbus.QDBusVariant = _QDBusVariant

    logger = _Logger()
    core = types.ModuleType("glavnaqt.core")
    core.logger = logger
    core.config = global_config or _Config()

    _QDBusInterface.reply_value = reply_value
    _QDBusInterface.calls = []
    _QDBusConnection.session = _Connection()

    stubs = {
        "PyQt6": types.ModuleType("PyQt6"),
        "PyQt6.QtCore": qt_core,
        "glavnaqt.core": core,
    }
    if include_dbus:
        stubs["PyQt6.QtDBus"] = qt_dbus
    else:
        # Force ``from PyQt6.QtDBus import ...`` to exercise the module's
        # ImportError fallback even when the real optional QtDBus extension is
        # installed or was imported by another pytest-qt test.
        stubs["PyQt6.QtDBus"] = None

    previous = sys.modules.pop("glavnaqt.ui.theme_watcher", None)
    with mock.patch.dict(sys.modules, stubs), mock.patch.object(sys, "platform", platform):
        module = importlib.import_module("glavnaqt.ui.theme_watcher")
        try:
            yield module, logger
        finally:
            sys.modules.pop("glavnaqt.ui.theme_watcher", None)
            if previous is not None:
                sys.modules["glavnaqt.ui.theme_watcher"] = previous


class ThemeWatcherTests(unittest.TestCase):
    def test_initial_read_unwraps_qdbusvariant(self):
        with _load_theme_watcher(reply_value=_QDBusVariant(1)) as (module, _logger):
            window = _Window()

            module.ThemeWatcher(window)

            self.assertEqual(window.applied, [True])

    def test_signal_path_uses_same_color_scheme_mapping_as_initial_read(self):
        with _load_theme_watcher(platform="darwin") as (module, _logger):
            window = _Window()
            watcher = module.ThemeWatcher(window)

            watcher.on_setting_changed(
                module.APPEARANCE_NAMESPACE,
                module.COLOR_SCHEME_KEY,
                _QDBusVariant(2),
            )

            self.assertEqual(window.applied, [False])

    def test_no_preference_is_explicitly_non_dark(self):
        with _load_theme_watcher(reply_value=_QDBusVariant(0)) as (module, _logger):
            window = _Window()

            module.ThemeWatcher(window)

            self.assertEqual(window.applied, [False])

    def test_uses_window_ui_config_instead_of_global_config(self):
        global_config = _Config(theme="light")
        window_config = _Config(theme="auto")
        with _load_theme_watcher(
            reply_value=_QDBusVariant(1),
            global_config=global_config,
        ) as (module, _logger):
            window = _Window(ui_config=window_config)

            watcher = module.ThemeWatcher(window)

            self.assertIs(watcher.ui_config, window_config)
            self.assertEqual(window.applied, [True])

    def test_missing_qtdbus_disables_watcher_without_import_failure(self):
        with _load_theme_watcher(include_dbus=False) as (module, logger):
            window = _Window()

            module.ThemeWatcher(window)

            self.assertEqual(window.applied, [])
            self.assertIsNone(module.QDBusConnection)
            self.assertTrue(
                any("PyQt6.QtDBus is unavailable" in message for message in logger.debug_messages)
            )


if __name__ == "__main__":
    unittest.main()
