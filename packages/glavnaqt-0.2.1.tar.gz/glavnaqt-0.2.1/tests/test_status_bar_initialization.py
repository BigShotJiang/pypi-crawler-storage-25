import enum
import importlib
import sys
import types
import unittest
from contextlib import contextmanager
from unittest import mock


class _AlignmentFlag(enum.IntFlag):
    AlignLeft = 1
    AlignVCenter = 2


class _QObject:
    def __init__(self, *_args, **_kwargs):
        pass


class _Signal:
    def __init__(self, *_args, **_kwargs):
        self._callbacks = []

    def connect(self, callback):
        self._callbacks.append(callback)

    def emit(self, *args, **kwargs):
        for callback in tuple(self._callbacks):
            callback(*args, **kwargs)


class _QFont:
    def __init__(self, *args):
        self.args = args


class _Layout:
    def setContentsMargins(self, *args):
        self.margins = args


class _Widget:
    def __init__(self, parent=None):
        self._parent = parent
        self._text = ""
        self._tooltip = ""
        self.children = []

    def parent(self):
        return self._parent

    def setFont(self, font):
        self.font = font

    def setText(self, text):
        self._text = text

    def text(self):
        return self._text

    def setToolTip(self, tooltip):
        self._tooltip = tooltip

    def toolTip(self):
        return self._tooltip

    def setAlignment(self, alignment):
        self.alignment = alignment

    def setSizePolicy(self, *args):
        self.size_policy = args

    def setObjectName(self, name):
        self.object_name = name

    def setFrameShape(self, shape):
        self.frame_shape = shape

    def setContentsMargins(self, *args):
        self.margins = args

    def deleteLater(self):
        self.deleted = True


class _QLabel(_Widget):
    pass


class _QStatusBar(_Widget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._layout = _Layout()

    def addPermanentWidget(self, widget, *args):
        widget._parent = self
        self.children.append((widget, args))

    def layout(self):
        return self._layout

    def setSizeGripEnabled(self, enabled):
        self.size_grip_enabled = enabled


class _QProgressBar(_Widget):
    def setMaximum(self, maximum):
        self.maximum = maximum

    def setVisible(self, visible):
        self.visible = visible

    def setMinimumWidth(self, width):
        self.minimum_width = width

    def setMaximumWidth(self, width):
        self.maximum_width = width


class _QFrame:
    Shape = types.SimpleNamespace(NoFrame=0)


class _QSizePolicy:
    Policy = types.SimpleNamespace(Expanding=1, Fixed=2, Minimum=3)


class _Config:
    font_face = "Helvetica"
    font_size = 12

    def __init__(self, text="Configured Ready"):
        self.collapsible_sections = {
            "bottom": {"text": text, "alignment": _AlignmentFlag.AlignLeft}
        }

    def update_collapsible_section(self, section_name, **kwargs):
        section = self.collapsible_sections.setdefault(section_name, {})
        section.update(kwargs)


class _RecordingBus:
    def __init__(self):
        self.emissions = []
        self.subscriptions = []

    def emit(self, event, *args, **kwargs):
        self.emissions.append((event, args, kwargs))

    def subscribe(self, event, callback):
        self.subscriptions.append((event, callback))


class _ThreadManager:
    def __init__(self):
        self.submissions = []

    def submit_task(self, function, *args, **kwargs):
        self.submissions.append((function, args, kwargs))


def _qt_stubs():
    qt_core = types.ModuleType("PyQt6.QtCore")
    qt_core.QObject = _QObject
    qt_core.pyqtSignal = _Signal
    qt_core.Qt = types.SimpleNamespace(AlignmentFlag=_AlignmentFlag)

    qt_gui = types.ModuleType("PyQt6.QtGui")
    qt_gui.QFont = _QFont

    qt_widgets = types.ModuleType("PyQt6.QtWidgets")
    qt_widgets.QStatusBar = _QStatusBar
    qt_widgets.QLabel = _QLabel
    qt_widgets.QFrame = _QFrame
    qt_widgets.QProgressBar = _QProgressBar
    qt_widgets.QSizePolicy = _QSizePolicy
    qt_widgets.QApplication = object

    return {
        "PyQt6": types.ModuleType("PyQt6"),
        "PyQt6.QtCore": qt_core,
        "PyQt6.QtGui": qt_gui,
        "PyQt6.QtWidgets": qt_widgets,
    }


@contextmanager
def _load_status_modules(config):
    config_module = types.ModuleType("glavnaqt.core.config")
    config_module.config = config

    events_module = types.ModuleType("glavnaqt.events.bus")
    events_module.create_or_get_shared_event_bus = lambda *args, **kwargs: _RecordingBus()

    stubs = _qt_stubs()
    stubs.update({
        "glavnaqt.core.config": config_module,
        "glavnaqt.events.bus": events_module,
    })

    module_names = [
        "glavnaqt.ui.status_bar_initializer",
        "glavnaqt.ui.status_bar_manager",
    ]
    previous_modules = {name: sys.modules.pop(name, None) for name in module_names}
    with mock.patch.dict(sys.modules, stubs):
        try:
            initializer = importlib.import_module("glavnaqt.ui.status_bar_initializer")
            manager = importlib.import_module("glavnaqt.ui.status_bar_manager")
            yield initializer, manager
        finally:
            for name in module_names:
                sys.modules.pop(name, None)
            for name, module in previous_modules.items():
                if module is not None:
                    sys.modules[name] = module


class StatusBarInitializationTests(unittest.TestCase):
    def test_initializer_exposes_widgets_without_side_effect_main_attributes(self):
        config = _Config()
        config.collapsible_sections["bottom"]["text"] = "Ready"
        bus = _RecordingBus()
        main_window = object()

        with _load_status_modules(config) as (initializer_module, _manager_module):
            initializer = initializer_module.StatusBarInitializer(main_window, config, bus)

        self.assertFalse(hasattr(main_window, "status_bar"))
        self.assertFalse(hasattr(main_window, "status_label"))
        self.assertIs(config.collapsible_sections["bottom"]["widget"], initializer.status_bar)
        self.assertIs(config.collapsible_sections["bottom"]["status_label"], initializer.status_label)
        self.assertEqual(config.collapsible_sections["bottom"]["text"], "Ready")
        self.assertEqual(initializer.status_label.text(), "Ready")
        self.assertEqual(initializer.status_label.toolTip(), "Ready")
        self.assertEqual(bus.emissions[0][0], "initialize_status_bar")
        self.assertEqual(bus.emissions[0][2]["initial_text"], "Ready")

    def test_manager_preserves_seeded_label_text_when_initial_text_is_omitted(self):
        config = _Config()
        bus = _RecordingBus()
        thread_manager = _ThreadManager()

        with _load_status_modules(config) as (_initializer_module, manager_module):
            manager = manager_module.StatusBarManager(thread_manager, event_bus=bus)
            bar = _QStatusBar()
            label = _QLabel(parent=bar)
            label.setText("Seeded Ready")
            manager.initialize_status_bar(bar, label)

        self.assertEqual(label.text(), "Seeded Ready")
        self.assertEqual(label.toolTip(), "Seeded Ready")
        self.assertEqual(thread_manager.submissions[0][2]["text"], "Seeded Ready")

    def test_manager_uses_injected_config_for_auto_registration(self):
        default_config = _Config("Default Ready")
        injected_config = _Config("Injected Ready")
        bus = _RecordingBus()
        thread_manager = _ThreadManager()
        bar = _QStatusBar()
        label = _QLabel(parent=bar)
        injected_config.update_collapsible_section(
            "bottom", widget=bar, status_label=label
        )

        with _load_status_modules(default_config) as (_initializer_module, manager_module):
            manager = manager_module.StatusBarManager(
                thread_manager,
                event_bus=bus,
                ui_config=injected_config,
            )

        self.assertIs(manager.ui_config, injected_config)
        self.assertIs(manager.status_bar, bar)
        self.assertIs(manager.status_label, label)
        self.assertEqual(label.text(), "Injected Ready")
        self.assertEqual(thread_manager.submissions[0][2]["text"], "Injected Ready")


if __name__ == "__main__":
    unittest.main()
