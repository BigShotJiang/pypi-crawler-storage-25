from types import SimpleNamespace

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QLabel

from glavnaqt.events.bus import EventBus
from glavnaqt.ui.layout import LayoutManager


class LayoutConfig(SimpleNamespace):
    def copy(self):
        clone = self.__class__.__new__(self.__class__)
        clone.__dict__ = self.__dict__.copy()
        clone.collapsible_sections = {
            key: dict(value) for key, value in self.collapsible_sections.items()
        }
        return clone

    def get_section_alignment(self, section_name):
        return self.collapsible_sections.get(section_name, {}).get(
            "alignment", Qt.AlignmentFlag.AlignCenter
        )


def _layout_config():
    return LayoutConfig(
        app_name="GlavnaQt test",
        window_position=(0, 0),
        window_size=(640, 480),
        font_face="Helvetica",
        font_size=12,
        splitter_handle_width=5,
        theme="light",
        enable_status_bar_manager=False,
        collapsible_sections={
            "main_content": {
                "text": "Main Content",
                "alignment": Qt.AlignmentFlag.AlignCenter,
            },
            "bottom": {
                "text": "Ready",
                "alignment": Qt.AlignmentFlag.AlignCenter,
            },
        },
    )


def test_event_bus_can_drive_qt_widget_headlessly(qtbot):
    label = QLabel("idle")
    qtbot.addWidget(label)
    bus = EventBus()

    bus.subscribe("status_text_changed", label.setText)
    bus.emit("status_text_changed", "ready")

    assert label.text() == "ready"


def test_layout_manager_builds_central_widget_headlessly(qtbot):
    manager = LayoutManager()

    manager.build_layout(_layout_config())
    central_widget = manager.get_central_widget()
    qtbot.addWidget(central_widget)

    assert central_widget is not None
    assert manager.current_widgets["central_widget"] == "bottom_splitter"
    assert manager.current_widgets["main_content_widget"].text() == "Main Content"
    assert manager.current_widgets["bottom_widget"].text() == "Ready"
