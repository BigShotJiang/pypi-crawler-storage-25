import importlib
import sys
import types
import unittest
from contextlib import contextmanager
from unittest import mock


class _Logger:
    def __init__(self):
        self.errors = []

    def debug(self, *_args, **_kwargs):
        pass

    def error(self, *args, **_kwargs):
        self.errors.append(args[0] if args else "")


class _Signal:
    def __init__(self):
        self.callbacks = []

    def connect(self, callback):
        self.callbacks.append(callback)


class _Widget:
    def __init__(self, *_args, objectName=None, **_kwargs):
        self.object_name = objectName
        self._parent = None
        self.resize_calls = []
        self._width = 800

    def setLayout(self, layout):
        self.layout = layout

    def setObjectName(self, name):
        self.object_name = name

    def setContentsMargins(self, *_args):
        pass

    def addWidget(self, widget):
        widget._parent = self

    def setParent(self, parent):
        self._parent = parent

    def resize(self, *size):
        self.resize_calls.append(size)

    def width(self):
        return self._width

    def height(self):
        return 600

    def parent(self):
        return self._parent

    def findChild(self, *_args, **_kwargs):
        return None

    def addPermanentWidget(self, widget, *_args):
        widget._parent = self


class _QSplitter(_Widget):
    def __init__(self, *_args, **_kwargs):
        super().__init__(*_args, **_kwargs)
        self.splitterMoved = _Signal()


class _QVBoxLayout:
    pass


class _Bus:
    def subscribe(self, *_args, **_kwargs):
        pass


class _Adjuster:
    def __init__(self):
        self.calls = []

    def adjust_font_and_widget_sizes(self, *args):
        self.calls.append(args)


@contextmanager
def _load_layout_with_qt_stubs():
    qt_core = types.ModuleType("PyQt6.QtCore")
    qt_core.Qt = types.SimpleNamespace(
        Orientation=types.SimpleNamespace(Vertical="vertical", Horizontal="horizontal")
    )
    qt_core.QTimer = types.SimpleNamespace(singleShot=lambda *_args, **_kwargs: None)

    qt_widgets = types.ModuleType("PyQt6.QtWidgets")
    qt_widgets.QSplitter = _QSplitter
    qt_widgets.QWidget = _Widget
    qt_widgets.QVBoxLayout = _QVBoxLayout
    qt_widgets.QProgressBar = _Widget

    logger = _Logger()
    core = types.ModuleType("glavnaqt.core")
    core.logger = logger

    collapsible_splitter = types.ModuleType("glavnaqt.ui.collapsible_splitter")
    collapsible_splitter.CollapsibleSplitter = _QSplitter

    panel = types.ModuleType("glavnaqt.ui.panel")
    panel.PanelLabel = _Widget
    panel.EXPANDING_EXPANDING = object()
    panel.EXPANDING_FIXED = object()
    panel.FIXED_EXPANDING = object()

    widget_adjustment = types.ModuleType("glavnaqt.ui.widget_adjustment")
    widget_adjustment.WidgetAdjuster = lambda layout_manager: _Adjuster()

    events_bus = types.ModuleType("glavnaqt.events.bus")
    events_bus.create_or_get_shared_event_bus = lambda *args, **kwargs: _Bus()

    helpers = types.ModuleType("glavnaqt.ui.helpers")
    helpers.apply_font = lambda *_args, **_kwargs: None

    stubs = {
        "PyQt6": types.ModuleType("PyQt6"),
        "PyQt6.QtCore": qt_core,
        "PyQt6.QtWidgets": qt_widgets,
        "glavnaqt.core": core,
        "glavnaqt.ui.collapsible_splitter": collapsible_splitter,
        "glavnaqt.ui.panel": panel,
        "glavnaqt.ui.widget_adjustment": widget_adjustment,
        "glavnaqt.events.bus": events_bus,
        "glavnaqt.ui.helpers": helpers,
    }

    previous = sys.modules.pop("glavnaqt.ui.layout", None)
    with mock.patch.dict(sys.modules, stubs):
        module = importlib.import_module("glavnaqt.ui.layout")
        try:
            yield module, logger
        finally:
            sys.modules.pop("glavnaqt.ui.layout", None)
            if previous is not None:
                sys.modules["glavnaqt.ui.layout"] = previous


class LayoutManagerTests(unittest.TestCase):
    def test_adjust_layout_returns_when_central_widget_has_been_cleared(self):
        with _load_layout_with_qt_stubs() as (module, logger):
            manager = module.LayoutManager.__new__(module.LayoutManager)
            manager.current_config = types.SimpleNamespace(
                window_size=(800, 600),
                font_face="Helvetica",
                font_size=12,
            )
            manager.current_widgets = {"main_content_widget": object()}
            manager._widget_adjuster = _Adjuster()

            manager.adjust_layout(current_window_size=(640, 480))

            self.assertEqual(manager._widget_adjuster.calls, [])
            self.assertIn(
                "central_widget is not initialized. Layout adjustment cannot proceed.",
                logger.errors,
            )

    def test_adjust_layout_resizes_existing_central_widget_before_adjusting(self):
        with _load_layout_with_qt_stubs() as (module, _logger):
            manager = module.LayoutManager.__new__(module.LayoutManager)
            manager.current_config = types.SimpleNamespace(
                window_size=(800, 600),
                font_face="Helvetica",
                font_size=12,
            )
            central = _Widget()
            manager.current_widgets = {
                "central_widget": "vertical_splitter",
                "vertical_splitter": central,
                "main_content_widget": object(),
            }
            manager._widget_adjuster = _Adjuster()

            manager.adjust_layout(current_window_size=(640, 480))

            self.assertEqual(central.resize_calls, [(640, 480)])
            self.assertEqual(
                manager._widget_adjuster.calls,
                [(800, "Helvetica", 12)],
            )


    def test_build_layout_preserves_runtime_widgets_in_config(self):
        with _load_layout_with_qt_stubs() as (module, _logger):
            manager = module.LayoutManager()
            widgets = {
                "top": _Widget(),
                "main_content": _Widget(),
                "left": _Widget(),
                "right": _Widget(),
                "bottom": _Widget(),
                "status_label": _Widget(),
            }
            sections = {
                "top": {"text": "Top", "alignment": "center", "widget": widgets["top"]},
                "main_content": {
                    "text": "Main",
                    "alignment": "center",
                    "widget": widgets["main_content"],
                },
                "left": {"text": "Left", "alignment": "center", "widget": widgets["left"]},
                "right": {"text": "Right", "alignment": "center", "widget": widgets["right"]},
                "bottom": {
                    "text": "Bottom",
                    "alignment": "center",
                    "widget": widgets["bottom"],
                    "status_label": widgets["status_label"],
                },
            }
            config = types.SimpleNamespace(
                collapsible_sections=sections,
                splitter_handle_width=5,
                window_size=(800, 600),
                font_face="Helvetica",
                font_size=12,
            )

            manager.build_layout(config)

            self.assertIs(sections["top"].get("widget"), widgets["top"])
            self.assertIs(sections["main_content"].get("widget"), widgets["main_content"])
            self.assertIs(sections["left"].get("widget"), widgets["left"])
            self.assertIs(sections["right"].get("widget"), widgets["right"])
            self.assertIs(sections["bottom"].get("widget"), widgets["bottom"])
            self.assertIs(sections["bottom"].get("status_label"), widgets["status_label"])


if __name__ == "__main__":
    unittest.main()
