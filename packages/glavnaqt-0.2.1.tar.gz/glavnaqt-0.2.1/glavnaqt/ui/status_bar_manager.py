
from PyQt6.QtCore import Qt, QObject, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QFrame, QProgressBar, QSizePolicy, QApplication

from glavnaqt.core.config import config as default_ui_config
from glavnaqt.events.bus import create_or_get_shared_event_bus


class StatusBarManager(QObject):
    status_updated = pyqtSignal(str, str)  # Signal to emit updated status text and tooltip

    def __init__(self, thread_manager, event_bus=None, ui_config=None):
        super().__init__()
        self.ui_config = ui_config or default_ui_config
        self.thread_manager = thread_manager
        self.event_bus = event_bus or create_or_get_shared_event_bus()
        self.status_bar = None
        self.status_label = None
        self.busy_indicator = None  # Busy indicator using QProgressBar
        self.event_bus.subscribe('initialize_status_bar', self.initialize_status_bar)
        self.event_bus.subscribe('status_update', self.update_status_bar_event)
        self.event_bus.subscribe('clear_status_bar', self.clear_status_bar)
        self.event_bus.subscribe('show_busy', self.start_busy_indicator)
        self.event_bus.subscribe('hide_busy', self.stop_busy_indicator)

        # --- NEW: auto‑register if the bar is already there ---
        bottom = self.ui_config.collapsible_sections.get('bottom', {})
        bar    = bottom.get('widget')
        label  = bottom.get('status_label')
        if bar is not None and label is not None:
            self.initialize_status_bar(bar, label)

        # Connect the signal to the slot
        self.status_updated.connect(self.update_status_bar)

    def initialize_status_bar(self, status_bar, status_label, initial_text=None):
        self.status_bar = status_bar
        self.status_bar.setContentsMargins(0, 0, 0, 0)
        self.status_bar.setObjectName("status_bar")
        self.status_bar.layout().setContentsMargins(0, 0, 0, 0)

        # Status label takes most of the space
        self.status_label = status_label
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        self.status_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.status_label.setObjectName("status_label")
        self.status_label.setFont(QFont(self.ui_config.font_face))
        self.status_label.setFrameShape(QFrame.Shape.NoFrame)
        self.status_label.setContentsMargins(0, 0, 0, 0)

        configured_text = self.ui_config.collapsible_sections.get('bottom', {}).get('text') or ''
        effective_initial_text = (
            initial_text
            if initial_text is not None
            else (self.status_label.text() or configured_text or "Status Bar Initialized")
        )

        self.status_bar.setSizeGripEnabled(False)
        self.status_label.setText(effective_initial_text)
        self.status_label.setToolTip(effective_initial_text)
        self.status_bar.addPermanentWidget(self.status_label, 1)  # Set stretch factor to 1

        # Busy indicator
        self.busy_indicator = QProgressBar(self.status_bar)
        self.busy_indicator.setObjectName('busy_indicator')
        self.busy_indicator.setMaximum(0)  # Indeterminate mode (busy state)
        self.busy_indicator.setVisible(False)  # Initially hidden

        # Set the minimum width for the busy indicator and allow it to resize appropriately
        self.busy_indicator.setMinimumWidth(5)
        self.busy_indicator.setMaximumWidth(50)
        self.busy_indicator.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.status_bar.addPermanentWidget(self.busy_indicator, 0)  # Set stretch factor to 0 (fixed size)
        self.start_worker(text=effective_initial_text)

    def start_busy_indicator(self):
        if self.busy_indicator:
            self.busy_indicator.setVisible(True)

    def stop_busy_indicator(self):
        if self.busy_indicator:
            self.busy_indicator.setVisible(False)
            self.event_bus.emit("request_global_adjust")

    def start_worker(self, *args, **kwargs):
        """
        Start a background task using the ThreadManager.

        :param args: Arguments to pass to the background task.
        :param kwargs: Keyword arguments to pass to the background task.
        """
        self.thread_manager.submit_task(self._process_status_update, *args, **kwargs)

    def _process_status_update(self, *args, **kwargs):
        """
        Background task that processes the status update.

        :param args: Arguments passed from start_worker.
        :param kwargs: Keyword arguments passed from start_worker.
        """
        status_text = kwargs.get('text', 'Default Status Text')
        tooltip_text = status_text

        # Emit the signal to update the GUI in the main thread
        self.status_updated.emit(status_text, tooltip_text)

    def update_status_bar(self, text=None, tooltip=None):
        """
        Slot to update the status bar GUI elements in the main thread.

        :param text: The text to display in the status bar.
        :param tooltip: The tooltip text for the status bar.
        """
        if not self.status_label:
            return

        current_text = self.status_label.text()

        # Update the label only if the visible text really changed
        if (text or '') != current_text:
            self.status_label.setText(text or '')
            self.status_label.setToolTip(tooltip or text or '')
            if hasattr(self.status_label, "_fit_font"):
                self.status_label._fit_font()

    def update_status_bar_event(self, text=None):
        """
        Event handler for 'status_update' events from the event bus.

        :param text: The text to display in the status bar.
        """
        if text is not None:
            self.start_worker(text=text)

    def clear_status_bar(self):
        """
        Clear and delete the status bar and its components.
        """
        if self.status_bar:
            self.status_bar.deleteLater()  # Schedule deletion of the status bar
            self.status_bar = None  # Clear the reference
        if self.status_label:
            self.status_label.deleteLater()  # Schedule deletion of the status label
            self.status_label = None  # Clear the reference
