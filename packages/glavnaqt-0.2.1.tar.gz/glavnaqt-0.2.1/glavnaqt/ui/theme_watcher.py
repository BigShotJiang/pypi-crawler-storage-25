
# theme_watcher.py
import sys
from PyQt6.QtCore import QObject, pyqtSignal, pyqtSlot

try:
    from PyQt6.QtDBus import QDBusConnection, QDBusInterface, QDBusVariant
except ImportError:  # pragma: no cover - exercised with import stubs in tests
    QDBusConnection = None
    QDBusInterface = None
    QDBusVariant = None

from glavnaqt.core import logger, config as default_config

APPEARANCE_NAMESPACE = 'org.freedesktop.appearance'
COLOR_SCHEME_KEY = 'color-scheme'
COLOR_SCHEME_NO_PREFERENCE = 0
COLOR_SCHEME_DARK = 1
COLOR_SCHEME_LIGHT = 2


def _unwrap_dbus_variant(value):
    """Return the Python value stored in a QDBusVariant-like wrapper."""
    if QDBusVariant is None:
        return value
    while isinstance(value, QDBusVariant):
        value = value.variant()
    return value


def _portal_color_scheme_is_dark(value):
    """
    Convert the XDG portal appearance color-scheme value to GlavnaQt's
    binary dark flag.

    The portal returns 0 for no preference, 1 for prefer-dark, and 2 for
    prefer-light. GlavnaQt exposes a binary theme callback, so no-preference
    is intentionally treated as non-dark.
    """
    value = _unwrap_dbus_variant(value)
    try:
        scheme = int(value)
    except (TypeError, ValueError):
        logger.debug(f"Ignoring unrecognized portal color-scheme value: {value!r}")
        return False

    if scheme == COLOR_SCHEME_DARK:
        return True
    if scheme in (COLOR_SCHEME_NO_PREFERENCE, COLOR_SCHEME_LIGHT):
        return False

    logger.debug(f"Ignoring unrecognized portal color-scheme value: {scheme!r}")
    return False


class ThemeWatcher(QObject):
    """
    Watches the XDG Portal's SettingChanged signal and invokes
    MainWindow.apply_theme(dark: bool) immediately and on each toggle.
    """
    def __init__(self, window, ui_config=None):
        super().__init__(window)
        self.win = window
        self.ui_config = ui_config or getattr(window, 'ui_config', default_config)

        if self.ui_config.theme == 'auto' and sys.platform.startswith('linux'):
            if QDBusConnection is None or QDBusInterface is None:
                logger.debug(
                    "PyQt6.QtDBus is unavailable; automatic system theme watching disabled"
                )
                return

            conn = QDBusConnection.sessionBus()

            # 1) Subscribe to the portal's SettingChanged(namespace, key, value) signal
            conn.connect(
                'org.freedesktop.portal.Desktop',
                '/org/freedesktop/portal/desktop',
                'org.freedesktop.portal.Settings',
                'SettingChanged',
                'ssv',
                self.on_setting_changed
            )

            # 2) Do one initial ReadOne to apply the current setting at startup
            iface = QDBusInterface(
                'org.freedesktop.portal.Desktop',
                '/org/freedesktop/portal/desktop',
                'org.freedesktop.portal.Settings',
                conn
            )
            reply = iface.call('ReadOne', APPEARANCE_NAMESPACE, COLOR_SCHEME_KEY)
            args = reply.arguments()
            if not args:
                logger.debug("Initial system theme read returned no color-scheme value")
                return
            dark = _portal_color_scheme_is_dark(args[0])
            logger.debug(f"Initial system theme read: {'dark' if dark else 'light'}")
            self.win.apply_theme(dark)

    @pyqtSlot(str, str, QDBusVariant if QDBusVariant is not None else object)
    def on_setting_changed(self, namespace, key, value):
        """
        Called whenever XDG Portal emits SettingChanged.
        Only act on 'org.freedesktop.appearance' + 'color-scheme'.
        """
        if namespace == APPEARANCE_NAMESPACE and key == COLOR_SCHEME_KEY:
            dark = _portal_color_scheme_is_dark(value)
            logger.debug(f"Got a change from the bus for {key}: {'dark' if dark else 'light'}")
            self.win.apply_theme(dark)
