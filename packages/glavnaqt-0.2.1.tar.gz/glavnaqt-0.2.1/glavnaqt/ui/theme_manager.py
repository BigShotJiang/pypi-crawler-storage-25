
# theme_manager.py
from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtGui import QPalette, QColor
from PyQt6.QtWidgets import QApplication

class ThemeManager(QObject):
    """
    Encapsulates application theme logic. Emits themeChanged when palette changes.
    """
    themeChanged = pyqtSignal(bool)

    def __init__(self, parent, ui_config):
        super().__init__(parent)
        self._ui_config = ui_config

    def apply(self, theme: str):
        """
        Apply the specified theme ('dark' or 'light'), update QApplication palette,
        and emit themeChanged if a switch occurred.
        """
        dark = theme.lower() == 'dark'
        current = QApplication.palette()
        is_dark = current.color(QPalette.ColorRole.Window).lightness() < 128

        # No change needed
        if dark == is_dark:
            return

        # Build new palette
        if dark:
            p = QPalette()
            p.setColor(QPalette.ColorRole.Window, QColor(53, 53, 53))
            p.setColor(QPalette.ColorRole.WindowText, QColor(255, 255, 255))
            p.setColor(QPalette.ColorRole.Base, QColor(35, 35, 35))
            p.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
            p.setColor(QPalette.ColorRole.ToolTipBase, QColor(255, 255, 255))
            p.setColor(QPalette.ColorRole.ToolTipText, QColor(255, 255, 255))
            p.setColor(QPalette.ColorRole.Text, QColor(255, 255, 255))
            p.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
            p.setColor(QPalette.ColorRole.ButtonText, QColor(255, 255, 255))
            p.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
            p.setColor(QPalette.ColorRole.HighlightedText, QColor(0, 0, 0))
        else:
            p = QApplication.style().standardPalette()

        # Apply and notify
        QApplication.setPalette(p)

        # Update status label text color if present
        main = self.parent()
        lbl = getattr(main, 'status_label', None)
        if lbl:
            text_col = QApplication.palette().color(QPalette.ColorRole.WindowText)
            pal = lbl.palette()
            pal.setColor(QPalette.ColorRole.WindowText, text_col)
            lbl.setPalette(pal)

        self.themeChanged.emit(dark)

