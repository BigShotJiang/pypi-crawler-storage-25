
import time
from PyQt6.QtCore import QTimer, Qt, pyqtSignal
from PyQt6.QtWidgets import QApplication, QMainWindow, QStatusBar
from PyQt6.QtGui import QPalette, QColor
from glavnaqt.core.config import config as default_ui_config
from glavnaqt.core import logger
from glavnaqt.events.bus import create_or_get_shared_event_bus
from glavnaqt.ui.layout import LayoutManagerFactory
from glavnaqt.ui.theme_manager import ThemeManager
from glavnaqt.ui.theme_watcher import ThemeWatcher
from glavnaqt.ui.status_bar_initializer import StatusBarInitializer


class MainWindow(QMainWindow):
    """
    Simplified MainWindow using single-responsibility collaborators.
    """
    resizeFinished = pyqtSignal(int, int)
    themeChanged   = pyqtSignal(bool)

    def __init__(self, event_bus=None, thread_manager=None, *args, ui_config=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.event_bus      = event_bus or create_or_get_shared_event_bus()
        self.thread_manager = thread_manager
        self.ui_config      = ui_config or default_ui_config

        self.resizeFinished.connect(self._publish_resize_finished)
        self.event_bus.subscribe('resize_finished', self.on_resize_done)

        self.resize_debouncer = ResizeDebouncer(self)
        self.theme_manager          = ThemeManager(self, self.ui_config)
        self.theme_watcher          = None
        self.status_bar_initializer = StatusBarInitializer(self, self.ui_config, self.event_bus)
        self.status_bar             = self.status_bar_initializer.status_bar
        self.status_label           = self.status_bar_initializer.status_label

        self.layout_manager = LayoutManagerFactory().create_layout_manager(
            "main", self.ui_config
        )
        self.layout_manager.widget_adjuster.register_autofit_widget(self.status_label)
        self.setCentralWidget(self.layout_manager.get_central_widget())
        self.event_bus.subscribe("request_global_adjust",
                         lambda *_: self.layout_manager.adjust_layout())
        
        self.is_fullscreen = False
        self.apply_initial_settings()
        self.event_bus.emit('refresh_image_list')
        QTimer.singleShot(0, lambda: self.layout_manager.adjust_layout())

    def update_ui(self, config):
        """
        Updates the UI layout based on new collapsible sections without tearing
        down the entire layout. Applies the change in memory before re-attaching
        to avoid flicker.
        """
        logger.debug(f'Updating UI to {config}')

        # Ensure the bottom/status section is wired up
        # (uses your new StatusBarInitializer under the hood)

        # Reflow all sections according to the new config and current size
        self.layout_manager.update_layout(
            config,
            current_window_size=(self.width(), self.height())
        )

        # Swap in the rebuilt central widget and refresh its geometry
        self.setCentralWidget(self.layout_manager.get_central_widget())
        self.centralWidget().updateGeometry()

    def apply_initial_settings(self):
        # Title, geometry, theme
        self.setWindowTitle(self.ui_config.app_name)
        x, y = self.ui_config.window_position
        w, h = self.ui_config.window_size
        self.initial_window_size = (w, h)
        self.setGeometry(x, y, w, h)
        if self.ui_config.theme.lower() in ('dark', 'light'):
            # explicit user choice
            self.theme_manager.apply(self.ui_config.theme)
        else:
            # “auto” → watch system and call apply_theme()
            self.theme_watcher = ThemeWatcher(self, self.ui_config)
        self.setMinimumSize(100, 100)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.resize_debouncer.handle_event(event)

    def on_resize_done(self, width: int, height: int):
        # single post-resize cleanup
        self.layout_manager.adjust_layout()

    def _publish_resize_finished(self, width: int, height: int):
        self.event_bus.emit("resize_finished", width, height)

    def apply_theme(self, dark: bool):
        """
        Called by ThemeWatcher when system theme toggles.
        """
        # delegate into ThemeManager
        self.theme_manager.apply('dark' if dark else 'light')
        # notify any other parts of your app
        self.themeChanged.emit(dark)

    def _fullscreen_layout_config(self):
        """Create a detached config containing only the current main content section."""
        source_config = self.layout_manager.current_config or self.ui_config
        fullscreen_config = source_config.copy()
        fullscreen_config.collapsible_sections = {
            "main_content": self._fullscreen_main_content_section(source_config)
        }
        return fullscreen_config

    def _fullscreen_main_content_section(self, source_config):
        sections = getattr(source_config, "collapsible_sections", {}) or {}
        source_section = sections.get("main_content", {})
        if not isinstance(source_section, dict):
            source_section = {}

        fullscreen_section = dict(source_section)
        fullscreen_section.setdefault(
            "alignment",
            self.ui_config.get_section_alignment("main_content")
            if hasattr(self.ui_config, "get_section_alignment")
            else Qt.AlignmentFlag.AlignCenter,
        )
        return fullscreen_section

    def toggle_fullscreen_layout(self):
        """Toggle between full-screen and original layout."""
        if self.is_fullscreen:
            self.update_ui(self.layout_manager.last_config)
        else:
            self.update_ui(self._fullscreen_layout_config())
        self.is_fullscreen = not self.is_fullscreen
        logger.debug(f"UI toggled to {'fullscreen' if self.is_fullscreen else 'original'} layout.")


class ResizeDebouncer:
    """
    Debounces raw resize events and emits a single `resize_finished`.
    """
    def __init__(self, main_window: QMainWindow):
        self.win       = main_window
        self._timer    = QTimer(main_window)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._emit_finished)

    def handle_event(self, event):
        # Restart debounce
        if self._timer.isActive():
            self._timer.stop()
        self._timer.start(50)

    def _emit_finished(self):
        w, h = self.win.width(), self.win.height()
        self.win.resizeFinished.emit(w, h)

