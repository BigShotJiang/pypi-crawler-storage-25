
# status_bar_initializer.py
from PyQt6.QtCore import QObject
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QStatusBar, QLabel
#from glavnaqt.ui.scaling_status_label import AutoFitLabel

class StatusBarInitializer(QObject):
    """
    Constructs the status bar and status label for a MainWindow.

    The created widgets are exposed on this initializer instance. MainWindow is
    responsible for assigning them to its own attributes explicitly, which keeps
    the ownership contract visible at the call site.
    """
    def __init__(self, main_window, ui_config, event_bus):
        super().__init__(main_window)
        self._main   = main_window
        self._config = ui_config
        self._bus    = event_bus

        """
        Programmatically create and register the status bar and label.
        Emits initialize_status_bar for immediate handler invocation.
        """
        bar = QStatusBar(self._main)
        label = QLabel(parent=bar)
        label.setFont(QFont(self._config.font_face, self._config.font_size))

        bottom_config = self._config.collapsible_sections.get('bottom', {})
        initial_text = bottom_config.get('text') or ''
        label.setText(initial_text)
        label.setToolTip(initial_text)

        bar.addPermanentWidget(label)
        self.status_bar = bar
        self.status_label = label

        # Persist in config for catch-up logic without discarding preconfigured
        # bottom-section text/alignment.
        self._config.update_collapsible_section(
            'bottom', widget=bar, status_label=label
        )
        # Notify subscribers that bar is ready. Pass the seeded text explicitly
        # so listeners do not replace it with their own default.
        self._bus.emit('initialize_status_bar', bar, label, initial_text=initial_text)
        
