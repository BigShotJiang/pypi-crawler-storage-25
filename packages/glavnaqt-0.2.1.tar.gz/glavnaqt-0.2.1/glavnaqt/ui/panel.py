
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QLabel, QSizePolicy, QFrame

# Constants for common size policies
EXPANDING_FIXED    = (QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
FIXED_EXPANDING    = (QSizePolicy.Policy.Fixed,     QSizePolicy.Policy.Expanding)
EXPANDING_EXPANDING= (QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
FIXED_FIXED        = (QSizePolicy.Policy.Fixed,     QSizePolicy.Policy.Fixed)


class PanelLabel(QLabel):
    """
    A QLabel subclass for creating labeled panels with custom styling and size policies.
    """

    def __init__(self, text: str, name: str, size_policy: tuple,
                 font_name="Helvetica", font_size=12,
                 alignment=Qt.AlignmentFlag.AlignCenter,
                 frame_shape=QFrame.Shape.NoFrame):
        super().__init__(text)
        self.setObjectName(name)
        self.setFont(QFont(font_name, font_size))
        self.setAlignment(alignment)
        self.setFrameShape(frame_shape)
        self.setContentsMargins(0, 0, 0, 0)
        self.setStyleSheet("padding: 0px; margin: 0px;")
        # **Enable palette-based background fill**
        self.setAutoFillBackground(True)
        self.setSizePolicy(size_policy[0], size_policy[1])

