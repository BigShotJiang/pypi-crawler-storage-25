"""
Qt-free application-wide events.

`EventBus` is the single observer hub.
Other helper modules (e.g. window-resize hooks) live here too.
"""

from .bus import (
    EventBus,
    create_or_get_shared_event_bus,
    get_shared_event_bus,
)

__all__ = [
    "EventBus",
    "create_or_get_shared_event_bus",
    "get_shared_event_bus",
    "setup_event_handling",
    "handle_resize_event",
]


def __getattr__(name):
    if name in {"setup_event_handling", "handle_resize_event"}:
        from . import window

        value = getattr(window, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
