import logging
from collections.abc import Callable
from threading import RLock
from typing import Any


logger = logging.getLogger(__name__)


class EventBus:
    """Simple pub-sub hub that is totally agnostic to Qt."""

    def __init__(self):
        self._listeners: dict[str, list[Callable[..., Any]]] = {}
        self._lock = RLock()

    def subscribe(self, event: str, cb: Callable[..., Any]):
        with self._lock:
            self._listeners.setdefault(event, []).append(cb)

    def unsubscribe(self, event: str, cb: Callable[..., Any]):
        with self._lock:
            try:
                self._listeners[event].remove(cb)
                if not self._listeners[event]:
                    del self._listeners[event]
            except (KeyError, ValueError):
                pass

    def emit(self, event: str, *args, **kw):
        with self._lock:
            listeners = tuple(self._listeners.get(event, ()))

        for cb in listeners:
            try:
                cb(*args, **kw)
            except Exception:
                logger.exception("Unhandled exception in %r event listener %r", event, cb)


# — shared instances — -------------------------------------------------------
_shared: dict[str, EventBus] = {}
_shared_lock = RLock()


def create_or_get_shared_event_bus(name: str = "glavna") -> EventBus:
    """Factory for a named, process-wide bus."""
    with _shared_lock:
        return _shared.setdefault(name, EventBus())


def get_shared_event_bus(name: str = "glavna") -> EventBus | None:
    with _shared_lock:
        return _shared.get(name)
