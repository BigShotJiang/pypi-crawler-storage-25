import logging
import os
import sys
import threading
from glavnaqt.core import config


_configured_loggers = {}
_configuration_lock = threading.RLock()


def _caller_module_name(stacklevel=2):
    """Return the module name for a caller without walking the full stack."""
    try:
        frame = sys._getframe(stacklevel)
    except ValueError:
        return "__main__"

    module_name = frame.f_globals.get("__name__")
    return module_name or "__main__"


def _log_level():
    return getattr(logging, str(config.LOG_LEVEL).upper(), logging.INFO)


# Function to dynamically get or create a logger based on module hierarchy
def get_dynamic_logger(*, stacklevel=2):
    module_name = _caller_module_name(stacklevel)

    cached_logger = _configured_loggers.get(module_name)
    if cached_logger is not None:
        return cached_logger

    logger = logging.getLogger(module_name)

    with _configuration_lock:
        cached_logger = _configured_loggers.get(module_name)
        if cached_logger is not None:
            return cached_logger

        if not getattr(logger, "_glavnaqt_configured", False):
            configure_logger(logger, module_name)
            logger._glavnaqt_configured = True

        _configured_loggers[module_name] = logger
        return logger


# Configure logger function
def configure_logger(logger, module_name):
    log_dir = os.path.join(config.config_dir, "logs")
    log_file_path = os.path.join(log_dir, config.LOG_FILE_NAME)
    log_level = _log_level()

    logger.setLevel(log_level)
    logger.propagate = False

    os.makedirs(log_dir, exist_ok=True)

    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    existing_file_handler = None
    existing_console_handler = None
    for handler in logger.handlers:
        if getattr(handler, "_glavnaqt_file_handler", False):
            existing_file_handler = handler
        elif getattr(handler, "_glavnaqt_console_handler", False):
            existing_console_handler = handler

    # File handler
    if existing_file_handler is None:
        file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
        file_handler._glavnaqt_file_handler = True
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    else:
        file_handler = existing_file_handler
        file_handler.setFormatter(formatter)
    file_handler.setLevel(log_level)

    # Console handler
    if existing_console_handler is None:
        console_handler = logging.StreamHandler()
        console_handler._glavnaqt_console_handler = True
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    else:
        console_handler = existing_console_handler
        console_handler.setFormatter(formatter)
    console_handler.setLevel(log_level)

    logger.debug(f"Logger configured for module: {module_name}", stacklevel=2)


def _logging_kwargs(kwargs):
    adjusted = dict(kwargs)
    try:
        stacklevel = int(adjusted.get("stacklevel", 1))
    except (TypeError, ValueError):
        stacklevel = 1
    adjusted["stacklevel"] = stacklevel + 2
    return adjusted


def _call_logger_method(method_name, *args, **kwargs):
    dynamic_logger = get_dynamic_logger(stacklevel=4)
    return getattr(dynamic_logger, method_name)(*args, **_logging_kwargs(kwargs))


def debug(msg, *args, **kwargs):
    return _call_logger_method("debug", msg, *args, **kwargs)


def info(msg, *args, **kwargs):
    return _call_logger_method("info", msg, *args, **kwargs)


def warning(msg, *args, **kwargs):
    return _call_logger_method("warning", msg, *args, **kwargs)


def warn(msg, *args, **kwargs):
    return _call_logger_method("warning", msg, *args, **kwargs)


def error(msg, *args, **kwargs):
    return _call_logger_method("error", msg, *args, **kwargs)


def exception(msg, *args, exc_info=True, **kwargs):
    return _call_logger_method("exception", msg, *args, exc_info=exc_info, **kwargs)


def critical(msg, *args, **kwargs):
    return _call_logger_method("critical", msg, *args, **kwargs)


def fatal(msg, *args, **kwargs):
    return _call_logger_method("fatal", msg, *args, **kwargs)


def log(level, msg, *args, **kwargs):
    return _call_logger_method("log", level, msg, *args, **kwargs)


def isEnabledFor(level):
    return get_dynamic_logger(stacklevel=3).isEnabledFor(level)


def getEffectiveLevel():
    return get_dynamic_logger(stacklevel=3).getEffectiveLevel()


# Expose logger attributes dynamically based on the caller module.
# Common logging methods above are real module functions so logger.debug/info/etc.
# avoid module __getattr__ entirely on the hot path.
def __getattr__(name):
    dynamic_logger = get_dynamic_logger(stacklevel=3)
    return getattr(dynamic_logger, name)


# Ensure the logger module itself is set up during import.
logger = get_dynamic_logger()
logger.debug(
    f"Logging initialized with log file: {config.LOG_FILE_NAME} and level: {logging.getLevelName(logger.level)}",
    stacklevel=1,
)
