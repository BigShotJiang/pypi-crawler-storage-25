# rigorxrigor

CLI for [RigorXRigor](https://app.rigorxrigor.com), a machine-verified
knowledge graph of mathematics. Designed for agents and humans alike.

## Install

```bash
pipx install rigorxrigor
```

Or run one-shot without installing:

```bash
uvx rigorxrigor verify 'sin^2(x) + cos^2(x) = 1'
```

## Sign up

First-time users and agents can create a free account from the CLI:

```bash
rigorxrigor signup
```

This opens the WorkOS signup page in your browser, returns to the local CLI
callback, and store tokens in `~/.rigorxrigor/auth.json`.

For browserless environments:

```bash
rigorxrigor signup --no-browser
```

Open the printed URL manually to complete signup.

Existing users can sign in with:

```bash
rigorxrigor login
```

This opens your browser, sends you through RigorXRigor sign-in, drops you back
to a "you can close this window" page, and saves your access token to
`~/.rigorxrigor/auth.json`.

## Headless agents

Agents should not need a human browser session at runtime. Put a WorkOS/RxR
bearer access token in a secret-backed environment variable:

```bash
export RIGORXRIGOR_TOKEN=...
rigorxrigor whoami
```

The CLI also accepts `RXR_ACCESS_TOKEN`. To persist a token into the normal CLI
auth file for a job image or local agent profile:

```bash
rigorxrigor auth import-token --token-env RIGORXRIGOR_TOKEN
rigorxrigor auth status
```

`rigorxrigor logout` clears saved credentials. If `RIGORXRIGOR_TOKEN` or
`RXR_ACCESS_TOKEN` is still set, that process is still authenticated.

## Usage

```bash
rigorxrigor signup
rigorxrigor status
rigorxrigor agent-guide
rigorxrigor rag "post-transformer memory invalidation" -k 8 --hops 2
rigorxrigor show inv_llm_memory_stale_invalidation
rigorxrigor bridges inv_llm_memory_stale_invalidation --limit 20
rigorxrigor verify 'sin^2(x) + cos^2(x) = 1'
rigorxrigor whoami
rigorxrigor logout
```

For agents, start with `rigorxrigor agent-guide`. The intended workflow is
cross-domain graph evidence: use `rag` as the starting-node and evidence
command, inspect promising context nodes with `show`, use `bridges` to find
cross-area and structure connections, verify formulas before treating them as
constraints, then re-query with useful area/operator/variable terms from the
context rows.

Structure-aware traversal is enabled by default for `rag` and `bridges`. Use
`--no-structure` only when a smaller JSON payload matters more than bridge
coverage.

Curated starting prompts and anchors:

```bash
rigorxrigor rag "post-transformer memory invalidation"
rigorxrigor show inv_llm_memory_stale_invalidation
rigorxrigor bridges inv_llm_memory_stale_invalidation

rigorxrigor rag "agent verifier constraints for numerical identities"
rigorxrigor rag "free energy optimization and partition functions"
rigorxrigor rag "control safety stopping envelope"
rigorxrigor rag "calibration error and probabilistic forecasts"
rigorxrigor rag "tensor contractions as graph structure"
rigorxrigor rag "PDE residual checks for boundary conditions"
rigorxrigor rag "quantum density matrix partial trace"
```

For JSON-consuming agents:

```bash
rigorxrigor rag "post-transformer memory invalidation" --json
rigorxrigor bridges inv_llm_memory_stale_invalidation --json
```

Exit codes mirror the local `rxr` tool:

- `0` verified / success
- `1` not verified
- `2` usage error
- `3` backend error / auth error

## Configuration

`~/.rigorxrigor/auth.json` holds your tokens. Override the API server with:

```bash
RXR_API_URL=https://api.rigorxrigor.com      # default
RIGORXRIGOR_API=https://api.rigorxrigor.com  # also supported
RIGORXRIGOR_AUTH=~/.rigorxrigor/auth.json    # default
RIGORXRIGOR_TIMEOUT=180                      # request/read timeout in seconds
RIGORXRIGOR_CONNECT_TIMEOUT=15               # connect timeout in seconds
```

The browser login callback listens on `http://127.0.0.1:8765/callback` by
default. Override the port with `RIGORXRIGOR_LOGIN_PORT` if needed.

You can also set timeout per command:

```bash
rigorxrigor --timeout 240 rag "cross-domain design question" -k 10 --hops 2
```

The intended agent workflow is cross-domain graph traversal. Longer request
timeouts are deliberate: RAG may need remote embedding plus graph context
expansion during concurrent benchmark runs.

## Local mode

This package talks to the cloud API. For fully offline / in-process work, use
the `rxr` tool from a RigorXRigor checkout.
