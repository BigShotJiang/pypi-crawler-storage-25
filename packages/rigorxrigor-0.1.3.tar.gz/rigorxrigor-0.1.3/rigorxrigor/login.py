"""Browser-based PKCE login using an ephemeral 127.0.0.1 listener.

Pattern (recommended in DEPLOYMENT.md / plan):
  1. CLI binds an ephemeral port on 127.0.0.1.
  2. CLI generates a PKCE pair, opens the user's browser to WorkOS
     authorize URL with redirect_uri=http://127.0.0.1:<port>/callback.
  3. WorkOS redirects to the loopback after sign-in.
  4. CLI's tiny HTTP handler receives ?code=..., exchanges it directly
     against WorkOS for tokens, returns a "you can close this window"
     HTML page, and exits the listener.

No server-side coordination needed: the whole flow runs CLI, browser, WorkOS.
The WorkOS application must include `http://127.0.0.1:8765/callback` as an
allowed redirect URI.
"""
from __future__ import annotations

import http.server
import os
import socketserver
import threading
import time
import webbrowser
from typing import Any
from urllib.parse import parse_qs, urlparse

from . import workos
from .config import StoredAuth, save


_SUCCESS_HTML = """<!doctype html>
<html><head><meta charset="utf-8"><title>RigorXRigor - signed in</title>
<style>body{font-family:-apple-system,system-ui,sans-serif;background:#0e1116;color:#e6e6e6;
display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;
margin:0}h1{color:#7df7b1;margin-bottom:.5em}p{color:#9ba3af}</style>
</head><body>
<h1>You're signed in.</h1>
<p>You can close this window and return to your terminal.</p>
</body></html>"""


_ERROR_HTML = """<!doctype html>
<html><head><meta charset="utf-8"><title>RigorXRigor - sign-in failed</title>
<style>body{font-family:-apple-system,system-ui,sans-serif;background:#0e1116;color:#e6e6e6;
display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;
margin:0}h1{color:#ff6b6b;margin-bottom:.5em}p{color:#9ba3af}</style>
</head><body>
<h1>Sign-in failed.</h1>
<p>{error}</p>
</body></html>"""


class _CallbackResult:
    """Mutable shared state between the HTTP handler and the main flow."""
    code: str | None = None
    error: str | None = None


def _make_handler(state: _CallbackResult, expected_state: str):
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *_: Any, **__: Any) -> None:
            pass  # silence default logging

        def do_GET(self) -> None:  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path != "/callback":
                self.send_response(404)
                self.end_headers()
                return
            qs = parse_qs(parsed.query)
            err = qs.get("error_description", qs.get("error", [None]))[0]
            code = qs.get("code", [None])[0]
            got_state = qs.get("state", [None])[0]

            if err:
                state.error = err
                body = _ERROR_HTML.format(error=err).encode("utf-8")
                self.send_response(400)
            elif not code or got_state != expected_state:
                state.error = "missing or mismatched authorization code"
                body = _ERROR_HTML.format(error=state.error).encode("utf-8")
                self.send_response(400)
            else:
                state.code = code
                body = _SUCCESS_HTML.encode("utf-8")
                self.send_response(200)

            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    return Handler


def _login_port() -> int:
    return int(os.environ.get("RIGORXRIGOR_LOGIN_PORT", "8765"))


def login(
    open_browser: bool = True,
    timeout_seconds: int = 300,
    screen_hint: str = "sign-in",
) -> StoredAuth:
    """Run the PKCE login dance. Returns the saved auth on success.

    Raises RuntimeError on timeout, callback error, or token-exchange failure.
    """
    verifier = workos.generate_code_verifier()
    challenge = workos.code_challenge_for(verifier)
    expected_state = workos.generate_code_verifier()  # reuse the helper for randomness
    result = _CallbackResult()

    handler = _make_handler(result, expected_state)
    try:
        httpd = socketserver.TCPServer(("127.0.0.1", _login_port()), handler)
    except OSError as exc:
        raise RuntimeError(
            f"could not bind local login callback on 127.0.0.1:{_login_port()}: {exc}"
        ) from exc
    port = httpd.server_address[1]
    redirect_uri = f"http://127.0.0.1:{port}/callback"

    server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    server_thread.start()

    try:
        url = workos.authorize_url(
            redirect_uri,
            challenge,
            state=expected_state,
            screen_hint=screen_hint,
        )
        if open_browser:
            webbrowser.open(url)
        else:
            action = "sign up" if screen_hint == "sign-up" else "sign in"
            print(f"Open this URL to {action}: {url}")

        deadline = time.time() + timeout_seconds
        while result.code is None and result.error is None:
            if time.time() > deadline:
                raise RuntimeError(f"login timed out after {timeout_seconds}s")
            time.sleep(0.2)

        if result.error:
            raise RuntimeError(f"WorkOS returned error: {result.error}")

        assert result.code  # narrow for mypy
        token_data = workos.exchange_code_for_tokens(result.code, verifier, redirect_uri)
    finally:
        httpd.shutdown()
        httpd.server_close()

    expires_in = float(token_data.get("expires_in", 3600))
    auth = StoredAuth(
        access_token=token_data["access_token"],
        expires_at=time.time() + expires_in,
        refresh_token=token_data.get("refresh_token", ""),
        user=token_data.get("user", {}),
    )
    save(auth)
    return auth
