"""rigorxrigor: pip-installable CLI talking to the cloud API.

Exit codes (mirrors the local rxr tool):
    0   verified / success
    1   not verified
    2   usage error
    3   backend / auth error
"""
from __future__ import annotations

import argparse
import base64
import json
import os
import sys
import time
from typing import Any

from . import __version__, config
from . import client as api
from . import login as login_mod
from .client import AuthMissing, BackendError


def _configure_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")


# ----------------------------------------------------------------------------
# Output helpers
# ----------------------------------------------------------------------------


def _err(msg: str) -> None:
    print(msg, file=sys.stderr)


def _print_json(obj: Any) -> None:
    json.dump(obj, sys.stdout, separators=(",", ":"), ensure_ascii=False)
    sys.stdout.write("\n")


def _truncate(s: str, n: int) -> str:
    return s if len(s) <= n else s[: n - 3] + "..."


def _jwt_payload(token: str) -> dict[str, Any]:
    parts = token.split(".")
    if len(parts) < 2:
        return {}
    payload = parts[1] + "=" * (-len(parts[1]) % 4)
    try:
        return json.loads(base64.urlsafe_b64decode(payload.encode("ascii")).decode("utf-8"))
    except Exception:
        return {}


def _auth_from_access_token(token: str) -> config.StoredAuth:
    claims = _jwt_payload(token)
    exp = float(claims.get("exp") or (time.time() + 365 * 24 * 3600))
    user = {
        "id": claims.get("sub") or claims.get("user_id") or "headless-agent",
        "email": claims.get("email") or "headless-agent",
    }
    return config.StoredAuth(
        access_token=token,
        expires_at=exp,
        refresh_token="",
        user=user,
    )


def _token_from_args(args: argparse.Namespace) -> str | None:
    if getattr(args, "token", None):
        return str(args.token).strip()
    token_env = getattr(args, "token_env", None)
    if token_env:
        token = os.environ.get(token_env)
        if not token:
            raise RuntimeError(f"{token_env} is not set")
        return token.strip()
    return None


AGENT_GUIDE = """RigorXRigor agent workflow

Use the graph as a cross-domain evidence tool. Structure-aware traversal is
included by default for rag and bridges.

1. Start broad:
   rigorxrigor rag "<task or research question>" -k 8 --hops 2

2. Read both hit and ctx rows. Hits are direct retrieval results; ctx rows are
   graph-neighbor evidence reached by traversal. Cross-domain value often lives
   in ctx rows, especially with --hops 2 or --hops 3.

3. Inspect useful node ids:
   rigorxrigor show <node_id>

4. Find explicit cross-area and structure bridge nodes from a good anchor:
   rigorxrigor bridges <node_id> --limit 20

5. Verify formulas before using them as hard constraints:
   rigorxrigor verify "<equation>"

6. Iterate with domain terms from good ctx or bridge rows:
   rigorxrigor rag "<original task> <useful area/operator/variable terms>" -k 10 --hops 2

Rules for agents:
- Prefer rag when designing, debugging, or reasoning across fields.
- Structure links are included by default; use --no-structure only when you
  need a smaller payload.
- Use bridges after show when you need cross-domain analogies, structure links,
  or adjacent constraints.
- Increase --hops to 2 or 3 when the task spans domains.
- Treat traversal and bridges as evidence for analogy or relevance, not proof of physical equivalence.
- Use show for provenance/details and verify for mathematical checks.
- Use --json when another tool or agent will consume the output.
"""


# ----------------------------------------------------------------------------
# Auth subcommands
# ----------------------------------------------------------------------------


def cmd_agent_guide(_: argparse.Namespace) -> int:
    print(AGENT_GUIDE)
    return 0


def cmd_deprecated_public(args: argparse.Namespace) -> int:
    _err(
        f"`rigorxrigor {args.cmd}` is no longer part of the public production CLI. "
        "Use `rigorxrigor rag`, `rigorxrigor show`, `rigorxrigor bridges`, and "
        "`rigorxrigor verify` for the supported evidence workflow."
    )
    return 2


def cmd_login(args: argparse.Namespace) -> int:
    try:
        token = _token_from_args(args)
    except RuntimeError as exc:
        _err(f"login failed: {exc}")
        return 2
    if token:
        auth = _auth_from_access_token(token)
        config.save(auth)
        print(f"signed in with bearer token as {auth.user.get('email', 'headless-agent')}")
        print(f"auth file: {config.auth_path()}")
        return 0

    try:
        auth = login_mod.login(
            open_browser=not args.no_browser,
            timeout_seconds=args.timeout,
            screen_hint="sign-in",
        )
    except RuntimeError as exc:
        _err(f"login failed: {exc}")
        return 3
    email = auth.user.get("email", "(unknown)")
    print(f"signed in as {email}")
    return 0


def cmd_signup(args: argparse.Namespace) -> int:
    try:
        auth = login_mod.login(
            open_browser=not args.no_browser,
            timeout_seconds=args.timeout,
            screen_hint="sign-up",
        )
    except RuntimeError as exc:
        _err(f"signup failed: {exc}")
        return 3
    email = auth.user.get("email", "(unknown)")
    print(f"signed in as {email}")
    return 0


def cmd_logout(_: argparse.Namespace) -> int:
    config.clear()
    if config.env_token():
        print("cleared saved credentials; env token is still active")
        print("unset RIGORXRIGOR_TOKEN/RXR_ACCESS_TOKEN to fully sign out this process")
    else:
        print("signed out")
    return 0


def cmd_auth_status(_: argparse.Namespace) -> int:
    env_active = bool(config.env_token())
    saved = config.load()
    print(f"env token: {'yes' if env_active else 'no'}")
    print(f"auth file: {config.auth_path()}")
    if saved and saved.access_token:
        stale = "expired/stale" if saved.expires_at and saved.expires_at < time.time() else "usable"
        print(f"saved token: yes ({stale})")
        print(f"saved user: {saved.user.get('email', '?')}")
    else:
        print("saved token: no")
    print(f"server: {config.server_url()}")
    return 0


def cmd_auth_import_token(args: argparse.Namespace) -> int:
    try:
        token = _token_from_args(args)
    except RuntimeError as exc:
        _err(f"auth import-token failed: {exc}")
        return 2
    if not token:
        _err("error: pass --token or --token-env")
        return 2
    auth = _auth_from_access_token(token)
    config.save(auth)
    print(f"saved bearer token for {auth.user.get('email', 'headless-agent')}")
    print(f"auth file: {config.auth_path()}")
    return 0


def cmd_whoami(args: argparse.Namespace) -> int:
    try:
        profile = api.me()
    except AuthMissing as exc:
        _err(str(exc))
        return 3
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(profile)
        return 0
    print(f"{profile.get('email', '?')}  (workos:{profile.get('workos_user_id', '?')})")
    sub = "active" if profile.get("subscription_active") else "inactive"
    print(f"subscription: {sub}")
    try:
        billing = api.billing_status()
    except Exception:
        billing = None
    if isinstance(billing, dict):
        if "credits_remaining" in billing:
            print(f"credits: {billing.get('credits_remaining')}")
        if billing.get("status"):
            print(f"billing: {billing.get('status')}")
        if billing.get("current_period_end"):
            print(f"period end: {billing.get('current_period_end')}")
        if "auto_topup_enabled" in billing:
            print(f"auto top-up: {'enabled' if billing.get('auto_topup_enabled') else 'disabled'}")
    print(f"server: {config.server_url()}")
    return 0


def cmd_config(args: argparse.Namespace) -> int:
    if args.set_server:
        a = config.load()
        if a is None:
            _err("not signed in; run `rigorxrigor login` first")
            return 3
        a.server = args.set_server
        config.save(a)
        print(f"server set to {a.server}")
        return 0
    a = config.load()
    print(f"server   : {config.server_url()}")
    if config.env_token():
        print("signed in: yes (env token)")
        print("auth env : RIGORXRIGOR_TOKEN/RXR_ACCESS_TOKEN")
        return 0
    if a:
        print(f"signed in: yes ({a.user.get('email', '?')})")
        print(f"auth file: {config.auth_path()}")
    else:
        print("signed in: no")
    return 0


def cmd_status(_: argparse.Namespace) -> int:
    try:
        health = api.health()
    except Exception as exc:
        _err(f"server: error ({exc})")
        return 3
    print(f"server: {config.server_url()}")
    print(f"health: {health.get('status', 'ok')}")
    auth = config.load()
    if config.env_token():
        print("signed in: yes (env token)")
        try:
            billing = api.billing_status()
        except Exception:
            billing = None
        if isinstance(billing, dict):
            if "credits_remaining" in billing:
                print(f"credits: {billing.get('credits_remaining')}")
            if billing.get("status"):
                print(f"billing: {billing.get('status')}")
    elif auth and auth.access_token:
        print(f"signed in: yes ({auth.user.get('email', '?')})")
        try:
            billing = api.billing_status()
        except Exception:
            billing = None
        if isinstance(billing, dict):
            if "credits_remaining" in billing:
                print(f"credits: {billing.get('credits_remaining')}")
            if billing.get("status"):
                print(f"billing: {billing.get('status')}")
    else:
        print("signed in: no")
    return 0


# ----------------------------------------------------------------------------
# Catalogue / search subcommands
# ----------------------------------------------------------------------------


def cmd_search(args: argparse.Namespace) -> int:
    try:
        result = api.search(args.query, limit=args.limit)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    hits = result.get("results", [])
    if not hits:
        print("no results")
        return 0
    for h in hits:
        mark = "OK" if h.get("is_true") else "NO"
        print(f"{h['id']:<18} {mark} {_truncate(h.get('name', ''), 42):<42} {h.get('area', '')}")
    return 0


def cmd_rag(args: argparse.Namespace) -> int:
    try:
        result = api.rag(
            args.query,
            limit=args.limit,
            hops=args.hops,
            include_structure=args.include_structure,
        )
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    hits = result.get("hits", [])
    ctx = result.get("context", [])
    print(f"# {len(hits)} hits, {len(ctx)} context items")
    for h in hits:
        print(f"hit  {h['id']:<18} {_truncate(h.get('name', ''), 42)}")
    for c in ctx[: args.limit * (args.hops + 1)]:
        via = c.get("via")
        via_s = f" via={via}" if via else ""
        print(f"ctx  {c['id']:<18} d={c.get('depth', 0)}  {_truncate(c.get('name', ''), 38)}{via_s}")
    if args.save:
        api.save_query("rag", {"q": args.query, "limit": args.limit, "hops": args.hops}, label=args.save)
        print(f"saved as: {args.save}")
    return 0


def cmd_bridges(args: argparse.Namespace) -> int:
    try:
        result = api.graph_bridges(
            args.id,
            limit=args.limit,
            provenance=args.provenance,
            include_structure=args.include_structure,
        )
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    print(
        f"{result.get('node_id', args.id)} bridges={len(result.get('bridges', []))} "
        f"curated={result.get('curated_count', 0)} auto={result.get('auto_count', 0)} "
        f"generated={result.get('generated_count', 0)}"
    )
    for bridge in result.get("bridges", []):
        node = bridge.get("node", {})
        print(
            f"  {node.get('id',''):<18} {bridge.get('provenance',''):<19} "
            f"shared={bridge.get('shared_count',0)} {node.get('area',''):<18} "
            f"{_truncate(node.get('name', ''), 42)}"
        )
    return 0


def cmd_show(args: argparse.Namespace) -> int:
    try:
        result = api.show_node(args.id)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    node = result.get("node", {})
    print(f"id:    {node.get('id', args.id)}")
    print(f"name:  {node.get('name', '')}")
    print(f"label: {node.get('label', '')}")
    print(f"area:  {node.get('area', '')}")
    print(f"true:  {node.get('is_true')}")
    if node.get("minimal_explanation"):
        print()
        print(node["minimal_explanation"])
    return 0


def cmd_ops(args: argparse.Namespace) -> int:
    try:
        result = api.list_operators(tier=args.tier)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    for op in result.get("operators", []):
        print(f"{op['id']:<18} tier={op.get('tier', 0)} arity={op.get('arity', '?')}  {op.get('name', '')}")
    return 0


def cmd_stats(args: argparse.Namespace) -> int:
    try:
        result = api.graph_stats()
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    for k, v in result.items():
        print(f"{k}: {v if not isinstance(v, dict) else json.dumps(v)}")
    return 0


# ----------------------------------------------------------------------------
# Verify
# ----------------------------------------------------------------------------


def cmd_verify(args: argparse.Namespace) -> int:
    try:
        result = api.verify(args.equation, samples=args.samples, tolerance=args.tolerance)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0 if result.get("verified") else 1
    verified = result.get("verified")
    status = "OK" if verified else "NO"
    raw_residual = result.get("max_residual")
    max_residual = float(raw_residual) if raw_residual is not None else float("nan")
    print(
        f'{status} max_res={max_residual:.2e} '
        f'method="{result.get("method", "")}" form="{result.get("equation", args.equation)}"'
    )
    return 0 if verified else 1


# ----------------------------------------------------------------------------
# Prove (passes raw .mg source through to the cloud)
# ----------------------------------------------------------------------------


def cmd_prove(args: argparse.Namespace) -> int:
    try:
        with open(args.path, "r", encoding="utf-8") as f:
            source = f.read()
    except OSError as exc:
        _err(f"error: cannot read {args.path}: {exc}")
        return 2
    try:
        result = api.prove(source, no_diagnosis=args.no_diagnosis, stop_at_fail=args.stop_at_fail)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0 if result.get("ok") else 1
    for s in result.get("steps", []):
        st = s.get("status", "?")
        print(f"step {s.get('ordinal'):>2}  {st:<8}  {s.get('label', '')}  res={s.get('residual', '')}")
    return 0 if result.get("ok") else 1


# ----------------------------------------------------------------------------
# Workspace: ingests + saved queries
# ----------------------------------------------------------------------------


def cmd_ingest(args: argparse.Namespace) -> int:
    """Add an equation to the user's per-user ingest workspace.

    Two modes:
      --latex '<expr>'     : direct latex string
      <path>               : read latex from a .tex/.md/.txt file (one equation
                             per line; lines starting with `%` are skipped).
    """
    items: list[str] = []
    if args.latex:
        items.append(args.latex)
    elif args.path:
        try:
            with open(args.path, "r", encoding="utf-8") as f:
                for raw in f:
                    line = raw.strip()
                    if not line or line.startswith("%") or line.startswith("#"):
                        continue
                    items.append(line)
        except OSError as exc:
            _err(f"error: cannot read {args.path}: {exc}")
            return 2
    else:
        _err("error: pass either --latex '<expr>' or a file path")
        return 2

    if not items:
        _err("error: nothing to ingest")
        return 2

    created: list[dict] = []
    for latex in items:
        # Best-effort: verify first so the stored row reflects truth.
        verified = False
        residual: float | None = None
        try:
            v = api.verify(latex)
            verified = bool(v.get("verified"))
            residual = float(v.get("max_residual", 0.0))
        except BackendError:
            pass

        try:
            row = api.create_ingest({
                "latex": latex,
                "source_path": args.path,
                "verified": verified,
                "residual": residual,
                "label": args.label,
            })
        except BackendError as exc:
            _err(f"error: {exc}")
            return 3
        created.append(row)

    if args.json:
        _print_json(created if len(created) > 1 else created[0])
        return 0
    for row in created:
        mark = "OK" if row.get("verified") else "NO"
        print(f"#{row['id']:<5} {mark} {_truncate(row.get('latex', ''), 60)}")
    return 0


def cmd_saved_queries(args: argparse.Namespace) -> int:
    """List, save (programmatically), or delete saved queries."""
    if args.delete is not None:
        try:
            api.delete("/api/me/saved-queries/" + str(args.delete))
        except BackendError as exc:
            _err(f"error: {exc}")
            return 3
        print(f"deleted #{args.delete}")
        return 0

    try:
        rows = api.list_saved_queries(kind=args.kind)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3

    if args.json:
        _print_json(rows)
        return 0
    if not rows:
        print("no saved queries")
        return 0
    for r in rows:
        label = r.get("label") or "(unlabeled)"
        q = json.dumps(r.get("query", {}))
        print(f"#{r['id']:<5} {r.get('kind', '?'):<8} {_truncate(label, 30):<30} {_truncate(q, 60)}")
    return 0


# ----------------------------------------------------------------------------
# Argparse setup
# ----------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="rigorxrigor",
        description="Cloud CLI for the RigorXRigor knowledge graph.",
        epilog="Agents: run `rigorxrigor agent-guide` first for the cross-domain graph traversal workflow.",
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    p.add_argument(
        "--timeout",
        dest="cloud_timeout",
        type=float,
        default=None,
        help="Cloud request timeout in seconds (default 180; env RIGORXRIGOR_TIMEOUT/RXR_TIMEOUT).",
    )
    p.add_argument(
        "--connect-timeout",
        type=float,
        default=None,
        help="Cloud connect timeout in seconds (default 15; env RIGORXRIGOR_CONNECT_TIMEOUT/RXR_CONNECT_TIMEOUT).",
    )

    sub = p.add_subparsers(
        dest="cmd",
        required=True,
        metavar="{signup,login,logout,status,whoami,agent-guide,guide,rag,show,bridges,verify}",
    )

    sp = sub.add_parser("agent-guide", aliases=["guide"], help="Show the recommended agent graph-traversal workflow.")
    sp.set_defaults(func=cmd_agent_guide)

    # auth
    sp = sub.add_parser("login", help="Sign in via browser PKCE, or import a bearer token for headless agents.")
    sp.add_argument("--no-browser", action="store_true", help="Print the auth URL instead of opening it.")
    sp.add_argument("--timeout", type=int, default=300, help="Login timeout in seconds (default 300).")
    sp.add_argument("--token", help="Import this bearer access token instead of opening a browser.")
    sp.add_argument("--token-env", metavar="NAME", help="Read a bearer access token from environment variable NAME.")
    sp.set_defaults(func=cmd_login)

    sp = sub.add_parser("signup", help="Create a free account via your browser (PKCE to WorkOS).")
    sp.add_argument("--no-browser", action="store_true", help="Print the signup URL instead of opening it.")
    sp.add_argument("--timeout", type=int, default=300, help="Signup timeout in seconds (default 300).")
    sp.set_defaults(func=cmd_signup)

    sp = sub.add_parser("logout", help="Forget local credentials.")
    sp.set_defaults(func=cmd_logout)

    sp = sub.add_parser("whoami", help="Show signed-in identity + subscription.")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_whoami)

    sp = sub.add_parser("status", help="Show API health and local sign-in state.")
    sp.set_defaults(func=cmd_status)

    # catalogue
    sp = sub.add_parser("rag", help="Retrieval-augmented context pack with BFS expansion.")
    sp.add_argument("query")
    sp.add_argument("-k", "--limit", type=int, default=8)
    sp.add_argument("-H", "--hops", type=int, default=1)
    sp.add_argument("--save", metavar="LABEL", help=argparse.SUPPRESS)
    sp.add_argument(
        "--no-structure",
        dest="include_structure",
        action="store_false",
        default=True,
        help="Reduce payload size by excluding generated structure links.",
    )
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_rag)

    sp = sub.add_parser("bridges", help="Show cross-area graph bridges for a node.")
    sp.add_argument("id")
    sp.add_argument("--limit", type=int, default=20)
    sp.add_argument("--provenance", choices=["curated", "auto", "generated", "all"], default="all")
    sp.add_argument(
        "--no-structure",
        dest="include_structure",
        action="store_false",
        default=True,
        help="Reduce payload size by excluding generated structure links.",
    )
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_bridges)

    sp = sub.add_parser("show", help="Show a single node by id.")
    sp.add_argument("id")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_show)

    # verify / prove
    sp = sub.add_parser("verify", help="Verify a mathematical equation numerically.")
    sp.add_argument("equation")
    sp.add_argument("--samples", type=int, default=10)
    sp.add_argument("--tolerance", type=float, default=1e-6)
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_verify)

    return p


def _build_auth_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="rigorxrigor auth",
        description="Advanced headless authentication helpers.",
    )
    sub = p.add_subparsers(dest="auth_cmd", required=True)

    sp = sub.add_parser(
        "status",
        help="Show env-token and saved-token state without calling the API.",
    )
    sp.set_defaults(func=cmd_auth_status)

    sp = sub.add_parser(
        "import-token",
        help="Save a bearer access token for non-interactive agent use.",
    )
    sp.add_argument("--token", help="Bearer access token to save.")
    sp.add_argument(
        "--token-env",
        default="RIGORXRIGOR_TOKEN",
        metavar="NAME",
        help="Environment variable containing the token (default RIGORXRIGOR_TOKEN).",
    )
    sp.set_defaults(func=cmd_auth_import_token)
    return p


def _build_config_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="rigorxrigor config", description="Advanced CLI configuration.")
    p.add_argument("--set-server", metavar="URL", help=argparse.SUPPRESS)
    p.set_defaults(func=cmd_config)
    return p


def _apply_leading_global_options(tokens: list[str]) -> None:
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--timeout", dest="cloud_timeout", type=float, default=None)
    p.add_argument("--connect-timeout", type=float, default=None)
    args, _ = p.parse_known_args(tokens)
    if getattr(args, "cloud_timeout", None) is not None:
        os.environ["RIGORXRIGOR_TIMEOUT"] = str(args.cloud_timeout)
    if getattr(args, "connect_timeout", None) is not None:
        os.environ["RIGORXRIGOR_CONNECT_TIMEOUT"] = str(args.connect_timeout)


def _split_leading_command(argv: list[str]) -> tuple[list[str], str, list[str]] | None:
    value_options = {"--timeout", "--connect-timeout"}
    i = 0
    while i < len(argv):
        token = argv[i]
        if token in value_options:
            i += 2
            continue
        if any(token.startswith(opt + "=") for opt in value_options):
            i += 1
            continue
        if token.startswith("-"):
            return None
        return argv[:i], token, argv[i + 1 :]
    return None


def _dispatch_advanced_or_deprecated(argv: list[str]) -> int | None:
    split = _split_leading_command(argv)
    if split is None:
        return None
    globals_, command, tail = split
    _apply_leading_global_options(globals_)

    if command == "auth":
        args = _build_auth_parser().parse_args(tail)
        return int(args.func(args))
    if command == "config":
        args = _build_config_parser().parse_args(tail)
        return int(args.func(args))
    if command in {"search", "ops", "stats", "prove", "ingest", "saved-queries"}:
        return cmd_deprecated_public(argparse.Namespace(cmd=command))
    return None


def main(argv: list[str] | None = None) -> int:
    _configure_stdio()
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    early = _dispatch_advanced_or_deprecated(raw_argv)
    if early is not None:
        return early
    parser = _build_parser()
    args = parser.parse_args(raw_argv)
    if getattr(args, "cloud_timeout", None) is not None:
        os.environ["RIGORXRIGOR_TIMEOUT"] = str(args.cloud_timeout)
    if getattr(args, "connect_timeout", None) is not None:
        os.environ["RIGORXRIGOR_CONNECT_TIMEOUT"] = str(args.connect_timeout)
    try:
        return int(args.func(args))
    except AuthMissing as exc:
        _err(str(exc))
        return 3
    except KeyboardInterrupt:
        _err("aborted")
        return 130


if __name__ == "__main__":
    sys.exit(main())
