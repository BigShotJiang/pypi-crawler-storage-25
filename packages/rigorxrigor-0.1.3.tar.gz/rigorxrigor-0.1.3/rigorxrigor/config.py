"""Read/write ~/.rigorxrigor/auth.json, the local token store."""
from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass
from pathlib import Path
from typing import Any


DEFAULT_API = (
    os.environ.get("RXR_API_URL")
    or os.environ.get("RIGORXRIGOR_API")
    or "https://api.rigorxrigor.com"
)

TOKEN_ENV_VARS = ("RIGORXRIGOR_TOKEN", "RXR_ACCESS_TOKEN")


def env_token() -> str | None:
    for name in TOKEN_ENV_VARS:
        token = os.environ.get(name)
        if token:
            return token.strip()
    return None


def auth_path() -> Path:
    override = os.environ.get("RIGORXRIGOR_AUTH")
    if override:
        return Path(override).expanduser()
    return Path.home() / ".rigorxrigor" / "auth.json"


@dataclass
class StoredAuth:
    access_token: str
    expires_at: float  # epoch seconds
    refresh_token: str = ""
    user: dict[str, Any] = None  # type: ignore[assignment]
    server: str = DEFAULT_API

    def __post_init__(self) -> None:
        if self.user is None:
            self.user = {}

    def to_dict(self) -> dict[str, Any]:
        return {
            "accessToken": self.access_token,
            "refreshToken": self.refresh_token,
            "tokenExpiresAt": int(self.expires_at * 1000),
            "user": self.user,
            "server": self.server,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "StoredAuth":
        exp_ms = d.get("tokenExpiresAt", 0)
        return cls(
            access_token=d.get("accessToken", ""),
            refresh_token=d.get("refreshToken", ""),
            expires_at=float(exp_ms) / 1000.0 if exp_ms else 0.0,
            user=d.get("user", {}),
            server=d.get("server", DEFAULT_API),
        )


def load() -> StoredAuth | None:
    p = auth_path()
    if not p.exists():
        return None
    try:
        return StoredAuth.from_dict(json.loads(p.read_text()))
    except Exception:
        return None


def save(auth: StoredAuth) -> None:
    p = auth_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(auth.to_dict(), indent=2))
    if os.name != "nt":
        try:
            os.chmod(p, stat.S_IRUSR | stat.S_IWUSR)
        except OSError:
            pass


def clear() -> None:
    p = auth_path()
    if p.exists():
        try:
            p.unlink()
        except OSError:
            pass


def server_url() -> str:
    a = load()
    return (a.server if a else None) or DEFAULT_API
