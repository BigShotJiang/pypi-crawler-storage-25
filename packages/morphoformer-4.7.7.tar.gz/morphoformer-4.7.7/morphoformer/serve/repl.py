"""Interactive REPL for morphological reinflection inference.

Uses Window + TabBar. On Windows TTY, the prompt reads keys so Tab cycles tabs and
F1–F3 jump to Chat / History / Info; elsewhere falls back to plain ``input()`` and
``:1`` / ``:2`` / ``:3`` commands.
"""

from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import torch

from chartoken import CharVocab, FeatureVocab
from morphoformer.config.schema import MorphoformerConfig
from morphoformer.inference.predict import predict_form
from morphoformer.ui.train_window import ensure_utf8_stdout
from morphoformer.model.model import Morphoformer
from vpterm.core.component import Component
from vpterm.rendering.style import Style, visible_length
from vpterm.terminal import Spinner, Terminal, get_terminal
from vpterm.ui.tabs import TabBar
from vpterm.window import Window

HISTORY_FILE = Path("session_history.json")


class _LinesPanel(Component):
    """Scrollable text block for a tab (chat / history / info)."""

    def __init__(self, title: str) -> None:
        super().__init__()
        self._title = title
        self._lines: list[str] = []

    def set_lines(self, lines: list[str]) -> None:
        self._lines = lines

    def render_lines(self) -> list[str]:
        head = [f" {Style.bold(self._title)}", ""]
        if not self._lines:
            return head + [f"  {Style.dim('(empty)')}"]
        return head + [f"  {line}" for line in self._lines]


def _load_history() -> list[dict[str, Any]]:
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return []
    return []


def _save_history(history: list[dict[str, Any]]) -> None:
    try:
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


def _add_to_history(history: list[dict[str, Any]], entry: dict[str, Any]) -> None:
    history.append(entry)
    _save_history(history)


def _parse_input(raw: str) -> tuple[str, list[str], str] | None:
    parts = raw.strip().rsplit(maxsplit=1)
    if len(parts) != 2:
        return None
    lemma_tags, language = parts
    segments = [segment.strip() for segment in lemma_tags.split(";") if segment.strip()]
    if len(segments) < 2:
        return None
    lemma = segments[0]
    tags = segments[1:]
    return lemma, tags, language


def _refresh_history_panel(panel: _LinesPanel, history: list[dict[str, Any]]) -> None:
    if not history:
        panel.set_lines(["No predictions yet."])
        return
    lines: list[str] = []
    for entry in history[-20:]:
        if entry.get("success"):
            lines.append(f"{entry['timestamp'][:19]}  {entry['input']}  ->  {entry['result']}")
        else:
            lines.append(f"{entry['timestamp'][:19]}  {entry['input']}  ERROR  {entry.get('error', '')}")
    panel.set_lines(lines)


def _read_line_serve(
    terminal: Terminal,
    window: Window,
    tab_bar: TabBar,
    history_panel: _LinesPanel,
    history: list[dict[str, Any]],
    prompt: str,
) -> str:
    """Read one line. On Windows console: Tab cycles tabs; F1/F2/F3 = Chat/History/Info."""
    if sys.platform != "win32" or not terminal.is_tty():
        return input(prompt)

    import msvcrt

    buf: list[str] = []

    def refresh_after_tab_change() -> None:
        if tab_bar.active_tab == 1:
            _refresh_history_panel(history_panel, history)
        window.display()
        terminal.write("\n")
        terminal.write(prompt + "".join(buf))

    def redraw_prompt() -> None:
        line = prompt + "".join(buf)
        wipe = max(visible_length(line), terminal.width() - 1)
        terminal.write("\r" + " " * wipe + "\r" + line)

    try:
        terminal.show_cursor()
    except Exception:
        pass
    terminal.write(prompt)

    while True:
        ch = msvcrt.getwch()
        if ch in ("\r", "\n"):
            terminal.write("\n")
            return "".join(buf)
        if ch == "\x03":
            raise KeyboardInterrupt
        if ch == "\t":
            tab_bar.next_tab()
            refresh_after_tab_change()
            continue
        if ch == "\x08":
            if buf:
                buf.pop()
                redraw_prompt()
            continue
        if ch in ("\x00", "\xe0"):
            scan = msvcrt.getwch()
            if scan == ";":  # F1
                tab_bar.select_tab(0)
            elif scan == "<":  # F2
                tab_bar.select_tab(1)
            elif scan == "=":  # F3
                tab_bar.select_tab(2)
            else:
                continue
            refresh_after_tab_change()
            continue
        buf.append(ch)
        terminal.write(ch)


def run_serve(
    config: MorphoformerConfig,
    model: Morphoformer,
    char_vocab: CharVocab,
    feature_vocab: FeatureVocab,
    torch_device: torch.device,
    checkpoint_path: str,
) -> None:
    ensure_utf8_stdout()
    terminal = get_terminal()
    history: list[dict[str, Any]] = _load_history()

    chat_panel = _LinesPanel("Inference")
    history_panel = _LinesPanel("Recent history")
    info_lines = [
        f"checkpoint {checkpoint_path}",
        f"device {config.train.device}",
        f"languages {' '.join(sorted(config.languages.keys()))}",
        f"max_len {config.data.max_len}  max_features {config.data.max_features}",
    ]
    info_panel = _LinesPanel("Session")
    info_panel.set_lines(info_lines)

    welcome = [
        "Enter:  lemma;TAG1;TAG2;...  <language>",
        "Example:  бежать;V;PST;SG;FEM  rus",
        "Commands:  quit | exit | help",
        "Tabs (Windows):  Tab = next tab  ·  F1 Chat  ·  F2 History  ·  F3 Info",
        "Tabs (anywhere):  :1 :2 :3  or  :chat :history :info",
    ]
    chat_panel.set_lines(welcome)
    last_result: list[str] = []

    tab_bar = TabBar()
    tab_bar.add_tab("Chat", chat_panel)
    tab_bar.add_tab("History", history_panel)
    tab_bar.add_tab("Info", info_panel)
    tab_bar.select_tab(0)

    window = Window("MorphFormer — interactive")
    window.set_content(tab_bar)
    window.display()
    terminal.blank_line()

    prompt = f" {Style.cyan('morph')} {Style.dim('>')} "

    while True:
        try:
            raw = _read_line_serve(terminal, window, tab_bar, history_panel, history, prompt)
        except (EOFError, KeyboardInterrupt):
            terminal.blank_line()
            terminal.status("Session ended.", kind="stop")
            break

        stripped = raw.strip()
        if not stripped:
            continue

        if stripped in (":1", ":chat"):
            tab_bar.select_tab(0)
            window.display()
            continue
        if stripped in (":2", ":history"):
            tab_bar.select_tab(1)
            _refresh_history_panel(history_panel, history)
            window.display()
            continue
        if stripped in (":3", ":info"):
            tab_bar.select_tab(2)
            window.display()
            continue

        if stripped in ("quit", "exit"):
            terminal.status("Session ended.", kind="stop")
            break

        if stripped == "help":
            chat_panel.set_lines(welcome + (last_result or []))
            tab_bar.select_tab(0)
            window.display()
            continue

        parsed = _parse_input(stripped)
        if parsed is None:
            terminal.writeln(
                f"  {Style.error('!')} Invalid input. Expected: "
                f"{Style.bold('lemma;TAG1;TAG2;... language')}"
            )
            terminal.writeln(f"  {Style.dim('Example:')} бежать;V;PST;SG;FEM rus")
            continue

        lemma, tags, language = parsed

        if language not in model.language_to_id:
            available = ", ".join(sorted(model.language_to_id.keys()))
            terminal.writeln(
                f"  {Style.error('!')} Unknown language {Style.bold(language)}. "
                f"Available: {Style.dim(available)}"
            )
            continue

        try:
            with Spinner(terminal, "Predicting"):
                result = predict_form(
                    model,
                    char_vocab,
                    feature_vocab,
                    lemma=lemma,
                    tags=tags,
                    language=language,
                    max_len=config.data.max_len,
                    max_features=config.data.max_features,
                    device=torch_device,
                )
            last_result = [
                "",
                Style.bold("Last prediction"),
                f"lemma    {lemma}",
                f"tags     {Style.cyan(';'.join(tags))}",
                f"language {language}",
                f"result   {Style.success(Style.bold(result))}",
            ]
            chat_panel.set_lines(welcome + last_result)
            tab_bar.select_tab(0)
            window.display()

            entry = {
                "timestamp": datetime.now().isoformat(),
                "input": stripped,
                "lemma": lemma,
                "tags": tags,
                "language": language,
                "result": result,
                "success": True,
            }
            _add_to_history(history, entry)
        except Exception as error:
            terminal.writeln(f"  {Style.error('!')} Prediction failed: {error}")
            entry = {
                "timestamp": datetime.now().isoformat(),
                "input": stripped,
                "error": str(error),
                "success": False,
            }
            _add_to_history(history, entry)

        terminal.blank_line()
