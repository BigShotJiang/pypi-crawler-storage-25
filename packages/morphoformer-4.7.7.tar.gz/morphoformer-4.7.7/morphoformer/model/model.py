from __future__ import annotations

from collections.abc import Mapping
from typing import Protocol, TypedDict, cast

import torch
import torch.nn as nn

from celmoe import (
    CELMoEConfig,
    ExpertBatch,
    ExpertConfig,
    ExpertModule,
    ExpertResult,
    HierarchicalCELMoE,
    HierarchyLevelConfig,
)
from morphoformer.config.schema import ModelConfig, MorphoformerConfig
from torchblocks import get


class MorphExpertMetadata(TypedDict):
    num_layers: int


class MorphExpertContext(TypedDict):
    language_embedding: torch.Tensor


class NormFactory(Protocol):
    def __call__(self, dim: int, eps: float = 1e-6) -> nn.Module: ...


class AttentionFactory(Protocol):
    def __call__(
        self,
        d_model: int,
        num_heads: int,
        num_kv_heads: int,
        dropout: float = 0.1,
    ) -> nn.Module: ...


class FeedForwardFactory(Protocol):
    def __call__(self, d_model: int, dim_ff: int, dropout: float = 0.1) -> nn.Module: ...


class AdapterFactory(Protocol):
    def __call__(self, d_model: int, bottleneck: int = 128) -> nn.Module: ...


class ConvFactory(Protocol):
    def __call__(self, d_model: int, kernel_size: int = 7, dropout: float = 0.1) -> nn.Module: ...


class PositionFactory(Protocol):
    def __call__(self, head_dim: int, max_positions: int = 512) -> nn.Module: ...


class MorphExpertBlock(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        norm_cls = cast(NormFactory, get("norm", config.norm))
        attn_cls = cast(AttentionFactory, get("attention", config.attention))
        ff_cls = cast(FeedForwardFactory, get("feedforward", config.feedforward))
        adapter_cls = cast(AdapterFactory, get("adapter", config.adapter))
        conv_cls = cast(ConvFactory, get("conv", config.conv))

        self.attn_norm = norm_cls(config.d_model)
        self.attn = attn_cls(
            d_model=config.d_model,
            num_heads=config.num_heads,
            num_kv_heads=config.num_kv_heads,
            dropout=config.dropout,
        )
        self.conv = conv_cls(
            d_model=config.d_model,
            kernel_size=config.conv_kernel_size,
            dropout=config.dropout,
        )
        self.ff_norm = norm_cls(config.d_model)
        self.ff = ff_cls(
            d_model=config.d_model,
            dim_ff=config.dim_ff,
            dropout=config.dropout,
        )
        self.adapter = adapter_cls(config.d_model, bottleneck=config.adapter_bottleneck)
        self.dropout = nn.Dropout(config.dropout)

    def forward(
        self,
        x: torch.Tensor,
        rope_cos: torch.Tensor,
        rope_sin: torch.Tensor,
        context_embed: torch.Tensor | None,
    ) -> torch.Tensor:
        hidden, _ = self.attn(self.attn_norm(x), rope_cos, rope_sin)
        x = x + self.dropout(hidden)
        x = x + self.conv(x)
        x = x + self.ff(self.ff_norm(x))
        return self.adapter(x, context_embed)


class MorphExpertStack(ExpertModule):
    def __init__(self, config: ModelConfig, num_layers: int) -> None:
        super().__init__()
        position_cls = cast(PositionFactory, get("position", "rope"))
        self.rope = position_cls(config.d_model // config.num_heads, config.max_positions)
        self.layers = nn.ModuleList([MorphExpertBlock(config) for _ in range(num_layers)])
        self.dropout = nn.Dropout(config.dropout)

    def _context_embed(self, context: object) -> torch.Tensor | None:
        if isinstance(context, torch.Tensor):
            return context
        if isinstance(context, Mapping):
            typed_context = cast(MorphExpertContext, context)
            return typed_context.get("language_embedding")
        return None

    def forward(self, batch: ExpertBatch) -> ExpertResult:
        rope_cos, rope_sin = self.rope(batch.hidden.size(1), batch.hidden.device)
        context_embed = self._context_embed(batch.context)
        hidden = batch.hidden
        for layer in self.layers:
            hidden = layer(hidden, rope_cos, rope_sin, context_embed)
        return ExpertResult(hidden=self.dropout(hidden))


class Morphoformer(nn.Module):
    model_family = "morphoformer"
    model_series = "v4"

    def __init__(
        self,
        config: MorphoformerConfig,
        vocab_size: int,
        feature_vocab_size: int,
        language_to_id: dict[str, int],
    ) -> None:
        super().__init__()
        self.config = config
        self.language_to_id = language_to_id
        self.id_to_language = {idx: name for name, idx in language_to_id.items()}
        self.family_by_language = {language: payload.family for language, payload in config.languages.items()}

        d_model = config.model.d_model
        self.token_embedding = nn.Embedding(vocab_size, d_model)
        self.feature_embedding = nn.Embedding(feature_vocab_size, config.model.feature_dim)
        self.language_embedding = nn.Embedding(len(language_to_id), d_model)
        self.input_projection = nn.Linear(d_model + config.model.feature_dim, d_model)
        self.dropout = nn.Dropout(config.model.dropout)

        families = sorted({item.family for item in config.languages.values()})
        levels: list[HierarchyLevelConfig] = [
            HierarchyLevelConfig(
                name="universal",
                experts={
                    "core": ExpertConfig(
                        name="core",
                        metadata=cast(MorphExpertMetadata, {"num_layers": config.model.universal_layers}),
                    )
                },
                fallback_expert="core",
            ),
            HierarchyLevelConfig(
                name="family",
                experts={
                    family: ExpertConfig(
                        name=family,
                        stop_gradient_from_parent=True,
                        metadata=cast(MorphExpertMetadata, {"num_layers": config.model.family_layers}),
                    )
                    for family in families
                },
            ),
            HierarchyLevelConfig(
                name="language",
                experts={
                    language: ExpertConfig(
                        name=language,
                        stop_gradient_from_parent=True,
                        metadata=cast(MorphExpertMetadata, {"num_layers": config.model.language_layers}),
                    )
                    for language in config.languages
                },
            ),
        ]
        celmoe_config = CELMoEConfig(
            hidden_size=d_model,
            levels=levels,
            fusion_dropout=config.model.dropout,
        )

        self.celmoe = HierarchicalCELMoE(celmoe_config, expert_factory=self._build_expert)
        self.universal_head = nn.Linear(d_model, vocab_size, bias=False)
        self.family_head = nn.Linear(d_model, vocab_size, bias=False)
        self.language_head = nn.Linear(d_model, vocab_size, bias=False)
        self.output_head = nn.Linear(d_model, vocab_size, bias=False)
        if config.model.tie_embeddings:
            self.output_head.weight = self.token_embedding.weight

    def _build_expert(self, level_name: str, expert_name: str, metadata: Mapping[str, object]) -> ExpertModule:
        del level_name, expert_name
        typed_metadata = cast(MorphExpertMetadata, metadata)
        num_layers = typed_metadata.get("num_layers", 1)
        return MorphExpertStack(self.config.model, num_layers=num_layers)

    def _merge_features(
        self,
        token_ids: torch.Tensor,
        feature_ids: torch.Tensor,
        feature_mask: torch.Tensor,
    ) -> torch.Tensor:
        token_hidden = self.token_embedding(token_ids)
        feature_hidden = self.feature_embedding(feature_ids)
        feature_hidden = (feature_hidden * feature_mask.unsqueeze(-1)).sum(dim=1)
        denom = feature_mask.sum(dim=1, keepdim=True).clamp_min(1.0)
        feature_hidden = feature_hidden / denom
        feature_hidden = feature_hidden.unsqueeze(1).expand(-1, token_hidden.size(1), -1)
        return self.input_projection(torch.cat([token_hidden, feature_hidden], dim=-1))

    def _build_routing(self, language_ids: torch.Tensor) -> dict[str, list[str]]:
        languages = [self.id_to_language[int(idx)] for idx in language_ids.tolist()]
        return {
            "universal": ["core"] * len(languages),
            "family": [self.family_by_language[language] for language in languages],
            "language": languages,
        }

    def forward(
        self,
        source_ids: torch.Tensor,
        language_ids: torch.Tensor,
        feature_ids: torch.Tensor,
        feature_mask: torch.Tensor,
    ) -> dict[str, torch.Tensor | list[str]]:
        """Forward pass through the full CELMoE hierarchy.

        Returns a dict with logits at each level plus routing info
        for per-expert loss computation:
            - logits: fused output (batch, seq, vocab)
            - universal_logits: universal expert output
            - family_logits: family expert output
            - language_logits: language expert output
            - family_routing: list[str] of family names per sample
            - language_routing: list[str] of language codes per sample
        """
        hidden = self._merge_features(source_ids, feature_ids, feature_mask)
        language_embed = self.language_embedding(language_ids)
        hidden = self.dropout(hidden + language_embed.unsqueeze(1))

        routing = self._build_routing(language_ids)
        celmoe_output = self.celmoe(
            hidden,
            routing=routing,
            context={"language_embedding": language_embed},
        )
        universal_hidden = celmoe_output.levels["universal"].hidden
        family_hidden = celmoe_output.levels["family"].hidden
        language_hidden = celmoe_output.levels["language"].hidden
        return {
            "logits": self.output_head(celmoe_output.fused_hidden),
            "universal_logits": self.universal_head(universal_hidden),
            "family_logits": self.family_head(family_hidden),
            "language_logits": self.language_head(language_hidden),
            "family_routing": routing["family"],
            "language_routing": routing["language"],
        }

    @torch.no_grad()
    def greedy_decode(
        self,
        source_ids: torch.Tensor,
        language_ids: torch.Tensor,
        feature_ids: torch.Tensor,
        feature_mask: torch.Tensor,
    ) -> torch.Tensor:
        logits = self.forward(source_ids, language_ids, feature_ids, feature_mask)["logits"]
        return logits.argmax(dim=-1)
