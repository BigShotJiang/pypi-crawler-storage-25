from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Mapping, TypedDict, cast

from morphoformer.config.schema import (
    DataConfig,
    DecodeConfig,
    LanguageConfig,
    ModelConfig,
    MorphoformerConfig,
    OptimizerConfig,
    TrainConfig,
)


class RawLanguageConfig(TypedDict, total=False):
    family: str
    weight: float


class RawDataConfig(TypedDict):
    train_path: str
    dev_path: str
    max_len: int
    max_features: int


class RawModelConfig(TypedDict, total=False):
    d_model: int
    dim_ff: int
    num_heads: int
    num_kv_heads: int
    dropout: float
    max_positions: int
    feature_dim: int
    tie_embeddings: bool
    attention: str
    feedforward: str
    norm: str
    adapter: str
    adapter_bottleneck: int
    conv: str
    conv_kernel_size: int
    universal_layers: int
    family_layers: int
    language_layers: int


class RawOptimizerConfig(TypedDict, total=False):
    lr: float
    weight_decay: float
    betas: tuple[float, float]


class RawTrainConfig(TypedDict, total=False):
    stage: str
    epochs: int
    batch_size: int
    warmup_steps: int
    total_steps: int
    clip_grad_norm: float
    device: str
    mixed_precision: bool
    log_interval: int
    output_dir: str
    final_loss_weight: float
    universal_loss_weight: float
    family_loss_weight: float
    language_loss_weight: float


class RawDecodeConfig(TypedDict, total=False):
    max_new_tokens: int


class RawMorphoformerConfig(TypedDict):
    data: RawDataConfig
    model: RawModelConfig
    languages: dict[str, RawLanguageConfig]
    optimizer: RawOptimizerConfig
    train: RawTrainConfig
    decode: RawDecodeConfig


def _langs_from_dict(data: Mapping[str, Mapping[str, object]]) -> dict[str, LanguageConfig]:
    languages: dict[str, LanguageConfig] = {}
    for name, payload in data.items():
        family_value = payload["family"]
        if not isinstance(family_value, str):
            raise TypeError("language family must be a string")
        weight_value = payload.get("weight", 1.0)
        if not isinstance(weight_value, (int, float)):
            raise TypeError("language weight must be numeric")
        languages[name] = LanguageConfig(
            family=family_value,
            weight=float(weight_value),
        )
    return languages


def load_config(path: str | Path) -> MorphoformerConfig:
    with open(path, "rb") as file:
        raw = cast(RawMorphoformerConfig, tomllib.load(file))
    raw_languages = raw["languages"]

    return MorphoformerConfig(
        data=DataConfig(**raw["data"]),
        model=ModelConfig(**raw["model"]),
        optimizer=OptimizerConfig(**raw.get("optimizer", {})),
        train=TrainConfig(**raw.get("train", {})),
        languages=_langs_from_dict(raw_languages),
        decode=DecodeConfig(**raw.get("decode", {})),
    )
