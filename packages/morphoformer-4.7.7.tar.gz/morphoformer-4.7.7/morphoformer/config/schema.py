from __future__ import annotations

from dataclasses import dataclass, field


def _empty_languages() -> dict[str, LanguageConfig]:
    return {}


@dataclass
class DataConfig:
    train_path: str
    dev_path: str
    max_len: int = 96
    max_features: int = 12


@dataclass
class LanguageConfig:
    family: str
    weight: float = 1.0


@dataclass
class ModelConfig:
    d_model: int
    dim_ff: int
    num_heads: int
    num_kv_heads: int
    dropout: float
    max_positions: int
    feature_dim: int
    tie_embeddings: bool = True
    attention: str = "gqa"
    feedforward: str = "swiglu"
    norm: str = "rmsnorm"
    adapter: str = "language_conditioned"
    adapter_bottleneck: int = 128
    conv: str = "none"
    conv_kernel_size: int = 7
    universal_layers: int = 8
    family_layers: int = 2
    language_layers: int = 2


@dataclass
class OptimizerConfig:
    lr: float = 3e-4
    weight_decay: float = 0.01
    betas: tuple[float, float] = (0.9, 0.95)


@dataclass
class TrainConfig:
    stage: str = "joint"
    epochs: int = 10
    batch_size: int = 64
    warmup_steps: int = 500
    total_steps: int = 20000
    clip_grad_norm: float = 1.0
    device: str = "cuda"
    mixed_precision: bool = True
    log_interval: int = 50
    output_dir: str = "dev/artifacts/v4_omni"
    final_loss_weight: float = 1.0
    universal_loss_weight: float = 0.25
    family_loss_weight: float = 0.35
    language_loss_weight: float = 0.5


@dataclass
class DecodeConfig:
    max_new_tokens: int = 64


@dataclass
class MorphoformerConfig:
    data: DataConfig
    model: ModelConfig
    optimizer: OptimizerConfig
    train: TrainConfig
    languages: dict[str, LanguageConfig] = field(default_factory=_empty_languages)
    decode: DecodeConfig = field(default_factory=DecodeConfig)
