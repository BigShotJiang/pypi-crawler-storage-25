from morphoformer.inference.predict import predict_form
