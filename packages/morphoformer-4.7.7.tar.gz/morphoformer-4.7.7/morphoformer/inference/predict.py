from __future__ import annotations

import torch

from chartoken import CharVocab, FeatureVocab
from morphoformer.model.model import Morphoformer


def predict_form(
    model: Morphoformer,
    char_vocab: CharVocab,
    feature_vocab: FeatureVocab,
    lemma: str,
    tags: list[str],
    language: str,
    max_len: int,
    max_features: int,
    device: torch.device,
) -> str:
    source_ids = char_vocab.encode(lemma, max_len=max_len, device=device).unsqueeze(0)
    feature_ids, feature_mask = feature_vocab.encode_tensor(tags, max_features=max_features, device=device)
    feature_ids = feature_ids.unsqueeze(0)
    feature_mask = feature_mask.unsqueeze(0)
    language_id = torch.tensor([model.language_to_id[language]], dtype=torch.long, device=device)
    prediction = model.greedy_decode(source_ids, language_id, feature_ids, feature_mask)[0].tolist()
    return char_vocab.decode(prediction)
