"""Full-screen training UI: same interaction model as `morphlog.sample` (Window + TabBar + refresh loop)."""

from __future__ import annotations

import sys
import threading
import time

from vpterm.core.component import Component
from vpterm.rendering.style import Style
from vpterm.terminal import Terminal
from vpterm.ui.tabs import TabBar
from vpterm.window import Window

from morphlog.train_logger import TrainLogger

ALT_SCREEN_ENTER = "\033[?1049h\033[H"
ALT_SCREEN_EXIT = "\033[?1049l"


def ensure_utf8_stdout() -> None:
    """Avoid Windows cp1251 crashes with box-drawing glyphs."""
    stream = getattr(sys, "stdout", None)
    reconfigure = getattr(stream, "reconfigure", None)
    if callable(reconfigure):
        try:
            reconfigure(encoding="utf-8")
        except OSError:
            pass


class SessionInfoPanel(Component):
    """Static run summary (device, paths, languages) for the Session tab."""

    def __init__(
        self,
        *,
        version: str,
        device: str,
        output_dir: str,
        languages: str,
        stage: str,
        resume_checkpoint: str | None = None,
    ) -> None:
        super().__init__()
        self._version = version
        self._device = device
        self._output_dir = output_dir
        self._languages = languages
        self._stage = stage
        self._resume_checkpoint = resume_checkpoint

    def render_lines(self) -> list[str]:
        lines = [
            f" {Style.bold('Session')}",
            f"  {Style.label('version'.ljust(14))} {self._version}",
            f"  {Style.label('stage'.ljust(14))} {self._stage}",
            f"  {Style.label('device'.ljust(14))} {self._device}",
            f"  {Style.label('output'.ljust(14))} {self._output_dir}",
            f"  {Style.label('languages'.ljust(14))} {Style.dim(self._languages)}",
        ]
        if self._resume_checkpoint:
            lines.append(f"  {Style.label('resume'.ljust(14))} {self._resume_checkpoint}")
        lines.append("")
        lines.append(f" {Style.dim('Switch tabs: Tab / arrows 1–2  ·  Training: V/L/I  ·  Scroll: PgUp/PgDn')}")
        return lines


def run_training_window_loop(
    terminal: Terminal,
    window: Window,
    logger: TrainLogger,
    tab_bar: TabBar,
    done_event: threading.Event,
    interrupt_event: threading.Event,
) -> bool:
    """Block until *done_event* or Ctrl+C. Returns True if user interrupted (Ctrl+C)."""
    active_tab = 0
    tab_bar.select_tab(active_tab)
    use_alt_screen = False
    try:
        if terminal.is_tty():
            terminal.write(ALT_SCREEN_ENTER)
            use_alt_screen = True
        terminal.hide_cursor()
    except Exception:
        terminal.clear_screen()

    interrupted = False
    try:
        while not done_event.is_set():
            key = terminal.poll_key()
            if key in ("tab", "right"):
                active_tab = (active_tab + 1) % len(tab_bar.tabs)
                tab_bar.select_tab(active_tab)
            elif key == "left":
                active_tab = (active_tab - 1) % len(tab_bar.tabs)
                tab_bar.select_tab(active_tab)
            elif key == "1":
                active_tab = 0
                tab_bar.select_tab(active_tab)
            elif key == "2" and len(tab_bar.tabs) > 1:
                active_tab = 1
                tab_bar.select_tab(active_tab)
            elif key in ("v", "V", "м", "М") and active_tab == 0:
                logger.set_view_mode("live")
            elif key in ("l", "L", "д", "Д") and active_tab == 0:
                logger.set_view_mode("logs")
            elif key in ("i", "I", "ш", "Ш") and active_tab == 0:
                logger.set_view_mode("info")
            elif key == "up":
                window.scroll_up()
            elif key == "down":
                window.scroll_down()
            elif key == "page_up":
                window.page_up()
            elif key == "page_down":
                window.page_down()
            elif key == "ctrl_o":
                logger.open_history_file()
            elif key == "ctrl_c":
                interrupt_event.set()
                interrupted = True

            window.refresh()
            # Ctrl+O is only visible as poll_key "ctrl_o" (handled above). handle_shortcuts
            # uses poll_ctrl_o and is for loops without poll_key (see finally block).
            time.sleep(0.08)
    except KeyboardInterrupt:
        interrupt_event.set()
        interrupted = True
    finally:
        while not done_event.is_set():
            window.refresh()
            logger.handle_shortcuts()
            time.sleep(0.08)
        try:
            terminal.show_cursor()
        except Exception:
            pass
        if use_alt_screen:
            terminal.write(ALT_SCREEN_EXIT)
        else:
            window.refresh()

    return interrupted
