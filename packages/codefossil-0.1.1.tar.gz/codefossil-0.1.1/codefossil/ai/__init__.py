"""AI integration package."""
