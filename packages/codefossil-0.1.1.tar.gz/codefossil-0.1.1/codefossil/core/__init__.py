"""Core analysis package."""
