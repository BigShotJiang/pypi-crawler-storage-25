from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from plaine.mcp import (
    Config,
    LabelClaim,
    MessagePayload,
    PlaineClient,
    build_mcp_server,
    default_label,
    extract_text,
    load_or_create_runtime_device_key,
)
from plaine.mcp import message_capabilities
from plaine.mcp import parse_messages, pidfile_path


class FakeClient(PlaineClient):
    def __init__(self) -> None:
        super().__init__(
            Config(
                api_base="https://plaine.chat",
                api_key="plane_test",
                conversation_id=None,
                label="test-project",
                on_timeout="stop",
                agent_device_key_file=None,
            )
        )

    def post_message(self, label: str, text: str) -> str:
        self.last_label = label
        self.last_text = text
        return "msg_123"

    def wait_for_message(
        self, label: str, timeout_seconds: int, since: str | None
    ) -> MessagePayload | None:
        self.last_wait_label = label
        self.last_timeout_seconds = timeout_seconds
        self.last_since = since
        return MessagePayload(id="msg_reply", parts=[{"type": "text", "text": "reply"}])


class FakeRegistrationClient(PlaineClient):
    def __init__(self, key_path: str) -> None:
        super().__init__(
            Config(
                api_base="https://plaine.chat",
                api_key="plane_test",
                conversation_id=None,
                label="test-project",
                on_timeout="stop",
                agent_device_key_file=key_path,
            )
        )
        self.requests: list[tuple[str, str, object]] = []

    def _request(self, method: str, path: str, body: object) -> dict[str, object]:
        self.requests.append((method, path, body))
        if path == "/api/agent/devices":
            return {"deviceId": "dev_123", "publicKeyFingerprint": "fp", "created": True}
        if path == "/api/agent/conversations":
            return {
                "conversationId": "conv_123",
                "label": "test-project",
                "encryptionMode": "at-rest-only",
                "created": True,
            }
        if path == "/api/agent/conversations/conv_123/messages":
            return {"id": "msg_agent"}
        raise AssertionError(f"unexpected request {method} {path}")


class McpTests(unittest.TestCase):
    def test_default_label_uses_host_and_cwd(self) -> None:
        with patch("plaine.mcp.socket.gethostname", return_value="host"):
            with patch("plaine.mcp.Path.cwd", return_value=Path("/tmp/project")):
                self.assertEqual(default_label(), "host:project")

    def test_message_user_returns_message_id(self) -> None:
        async def call_tool() -> tuple[FakeClient, object]:
            client = FakeClient()
            server = build_mcp_server(client, "host:project")
            response = await server.call_tool("message_user", {"text": "hello"})
            return client, response

        client, response = asyncio.run(call_tool())
        self.assertIsInstance(response, tuple)
        _, structured = response
        self.assertIsInstance(structured, dict)
        self.assertEqual(structured, {"messageId": "msg_123"})
        self.assertEqual(client.last_label, "host:project")
        self.assertEqual(client.last_text, "hello")

    def test_send_and_wait_uses_sent_message_as_cursor(self) -> None:
        async def call_tool() -> tuple[FakeClient, object]:
            client = FakeClient()
            server = build_mcp_server(client, "host:project")
            response = await server.call_tool(
                "send_and_wait", {"text": "question", "timeout_s": 12}
            )
            return client, response

        client, response = asyncio.run(call_tool())
        self.assertIsInstance(response, tuple)
        _, structured = response
        self.assertIsInstance(structured, dict)
        self.assertEqual(
            structured,
            {
                "sentMessageId": "msg_123",
                "message": "reply",
                "messageId": "msg_reply",
                "status": None,
                "timeout_s": None,
                "suggestion": None,
            },
        )
        self.assertEqual(client.last_label, "host:project")
        self.assertEqual(client.last_text, "question")
        self.assertEqual(client.last_wait_label, "host:project")
        self.assertEqual(client.last_timeout_seconds, 12)
        self.assertEqual(client.last_since, "msg_123")

    def test_parse_messages_extracts_text(self) -> None:
        messages = parse_messages(
            {
                "messages": [
                    {"id": "msg_1", "parts": [{"type": "text", "text": "hi"}]},
                ],
                "nextCursor": "msg_1",
            }
        )
        self.assertEqual(extract_text(messages[0]), "hi")

    def test_parse_messages_refuses_e2ee_without_decrypt_support(self) -> None:
        with self.assertRaisesRegex(Exception, "private E2EE messages require local decrypt support"):
            parse_messages(
                {
                    "messages": [
                        {"id": "msg_1", "parts": [], "contentEncrypted": "ciphertext-envelope"},
                    ],
                    "nextCursor": "msg_1",
                }
            )

    def test_capabilities_are_plaintext_only_until_local_e2ee_lands(self) -> None:
        self.assertEqual(
            message_capabilities(),
            {
                "transport": "local-stdio",
                "encryption": {
                    "status": "plaintext-only",
                    "encryptedEnvelopes": False,
                    "requiresLocalDeviceKey": True,
                    "localDeviceKeyConfigured": False,
                },
                "outboundShapes": ["text-only"],
                "inboundShapes": ["text-only"],
                "approvalResponses": "inbound-only",
                "docsUrl": "https://plaine.chat/docs/integrations/coding-agents-mcp",
            },
        )

    def test_label_claim_cleans_up_pidfile(self) -> None:
        api_key = "plane_test"
        label = "host:project"
        path = pidfile_path(api_key, label)
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        with LabelClaim(api_key, label, enabled=True):
            self.assertTrue(path.exists())
        self.assertFalse(path.exists())

    def test_runtime_device_file_store_generates_stable_public_key(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            key_path = str(Path(tmpdir) / "runtime-device.pem")
            config = Config(
                api_base="https://plaine.chat",
                api_key="plane_test",
                conversation_id=None,
                label="test-project",
                on_timeout="stop",
                agent_device_key_file=key_path,
            )

            first = load_or_create_runtime_device_key(config)
            second = load_or_create_runtime_device_key(config)

            self.assertTrue(first.public_key.startswith("plaine-agent-runtime-key-v1:"))
            self.assertEqual(first.public_key, second.public_key)
            self.assertIn("PRIVATE KEY", Path(key_path).read_text(encoding="utf-8"))

    def test_capabilities_report_existing_runtime_key(self) -> None:
        async def call_tool(key_path: str) -> object:
            config = Config(
                api_base="https://plaine.chat",
                api_key="plane_test",
                conversation_id=None,
                label="test-project",
                on_timeout="stop",
                agent_device_key_file=key_path,
            )
            load_or_create_runtime_device_key(config)
            client = PlaineClient(config)
            server = build_mcp_server(client, "host:project")
            return await server.call_tool("describe_message_capabilities", {})

        with tempfile.TemporaryDirectory() as tmpdir:
            response = asyncio.run(call_tool(str(Path(tmpdir) / "runtime-device.pem")))

        self.assertIsInstance(response, tuple)
        _, structured = response
        self.assertIsInstance(structured, dict)
        encryption = structured["encryption"]
        self.assertIsInstance(encryption, dict)
        self.assertEqual(encryption["localDeviceKeyConfigured"], True)

    def test_post_message_registers_runtime_device_public_key_only(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            client = FakeRegistrationClient(str(Path(tmpdir) / "runtime-device.pem"))

            message_id = client.post_message("test-project", "hello")

            self.assertEqual(message_id, "msg_agent")
            method, path, body = client.requests[0]
            self.assertEqual((method, path), ("POST", "/api/agent/devices"))
            self.assertIsInstance(body, dict)
            public_key = body["publicKey"]
            self.assertIsInstance(public_key, str)
            self.assertTrue(public_key.startswith("plaine-agent-runtime-key-v1:"))
            self.assertNotIn("PRIVATE KEY", public_key)


if __name__ == "__main__":
    unittest.main()
