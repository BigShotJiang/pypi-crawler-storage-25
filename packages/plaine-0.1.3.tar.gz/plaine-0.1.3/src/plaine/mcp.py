from __future__ import annotations

import hashlib
import json
import os
import socket
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from base64 import urlsafe_b64encode
from dataclasses import dataclass
from pathlib import Path
from types import TracebackType
from typing import Literal

import keyring
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError
from typing_extensions import TypedDict

JSONValue = None | bool | int | float | str | list["JSONValue"] | dict[str, "JSONValue"]
JSONObject = dict[str, JSONValue]

WAIT_CHUNK_SECONDS = 25
RUNTIME_PUBLIC_KEY_PREFIX = "plaine-agent-runtime-key-v1:"
KEYRING_SERVICE = "plaine-agent-runtime-device-v1"


@dataclass(frozen=True)
class Config:
    api_base: str
    api_key: str
    conversation_id: str | None
    label: str
    on_timeout: Literal["stop", "continue"]
    agent_device_key_file: str | None


@dataclass(frozen=True)
class MessagePayload:
    id: str
    parts: list[JSONObject]
    content_encrypted: str | None = None


@dataclass(frozen=True)
class RuntimeDeviceKey:
    public_key: str
    private_pem: str


class SendMessageResult(TypedDict):
    messageId: str


class InboxMessageResult(TypedDict):
    message: str
    messageId: str


class PollMessagesResult(TypedDict):
    messages: list[InboxMessageResult]
    nextCursor: str | None


class WaitTimeoutResult(TypedDict):
    status: Literal["timeout"]
    timeout_s: int
    suggestion: str


WaitForMessageResult = InboxMessageResult | WaitTimeoutResult


class SendAndWaitResult(TypedDict):
    sentMessageId: str
    message: str | None
    messageId: str | None
    status: Literal["timeout"] | None
    timeout_s: int | None
    suggestion: str | None


class EncryptionCapabilityResult(TypedDict):
    status: Literal["plaintext-only"]
    encryptedEnvelopes: bool
    requiresLocalDeviceKey: bool
    localDeviceKeyConfigured: bool


class MessageCapabilitiesResult(TypedDict):
    transport: Literal["local-stdio"]
    encryption: EncryptionCapabilityResult
    outboundShapes: list[str]
    inboundShapes: list[str]
    approvalResponses: Literal["inbound-only"]
    docsUrl: str


class PlaineError(RuntimeError):
    pass


def run_mcp_server() -> None:
    config = load_config()
    client = PlaineClient(config)
    with LabelClaim(config.api_key, config.label, config.conversation_id is None) as claim:
        build_mcp_server(client, claim.label).run(transport="stdio")


def load_config() -> Config:
    api_key = os.environ.get("PLAINE_API_KEY")
    if not api_key:
        print("plaine mcp: PLAINE_API_KEY is required", file=sys.stderr)
        raise SystemExit(1)

    on_timeout_raw = os.environ.get("PLAINE_ON_TIMEOUT", "stop")
    on_timeout: Literal["stop", "continue"] = "continue" if on_timeout_raw == "continue" else "stop"

    return Config(
        api_base=os.environ.get("PLAINE_API_BASE", "https://plaine.chat").rstrip("/"),
        api_key=api_key,
        conversation_id=os.environ.get("PLAINE_CONVERSATION_ID"),
        label=os.environ.get("PLAINE_CONVERSATION_LABEL", default_label()),
        on_timeout=on_timeout,
        agent_device_key_file=os.environ.get("PLAINE_AGENT_DEVICE_KEY_FILE"),
    )


def default_label() -> str:
    return f"{socket.gethostname()}:{Path.cwd().name}"


class LabelClaim:
    def __init__(self, api_key: str, label: str, enabled: bool) -> None:
        self._path: Path | None = None
        self.label = label
        if not enabled:
            return

        primary = pidfile_path(api_key, label)
        existing_pid = read_pidfile(primary)
        if existing_pid and existing_pid != os.getpid() and process_alive(existing_pid):
            self.label = f"{label}-{os.getpid()}"
            print(
                "plaine mcp: another MCP "
                f"(pid {existing_pid}) is already driving conversation label {label!r}. "
                f"Using {self.label!r} for this session.",
                file=sys.stderr,
            )
            self._path = pidfile_path(api_key, self.label)
        else:
            self._path = primary
        self._path.write_text(json.dumps({"pid": os.getpid()}), encoding="utf-8")

    def __enter__(self) -> "LabelClaim":
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        if self._path:
            try:
                self._path.unlink()
            except FileNotFoundError:
                pass


def pidfile_path(api_key: str, label: str) -> Path:
    digest = hashlib.sha256(f"{api_key}:{label}".encode()).hexdigest()[:16]
    return Path(tempfile.gettempdir()) / f"plaine-mcp-{digest}.pid"


def read_pidfile(path: Path) -> int | None:
    try:
        raw: object = json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None
    if not isinstance(raw, dict):
        return None
    pid = raw.get("pid")
    if isinstance(pid, int):
        return pid
    return None


def process_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


class PlaineClient:
    def __init__(self, config: Config) -> None:
        self.config = config
        self._conversation_id = config.conversation_id
        self._conversation_encryption_mode: str | None = None
        self._last_seen_cursor: str | None = None
        self._runtime_device_registered = False

    def provision_conversation(self, label: str) -> str:
        if self._conversation_id:
            return self._conversation_id
        body = self._request("POST", "/api/agent/conversations", {"label": label})
        conversation_id = read_required_string(body, "conversationId")
        self._conversation_encryption_mode = read_optional_string(body, "encryptionMode")
        self._conversation_id = conversation_id
        return conversation_id

    def post_message(self, label: str, text: str) -> str:
        self.ensure_runtime_device_registered(label)
        conversation_id = self.provision_conversation(label)
        self._require_plaintext_available()
        body = self._request(
            "POST",
            f"/api/agent/conversations/{conversation_id}/messages",
            {"parts": [{"type": "text", "text": text}]},
        )
        return read_required_string(body, "id")

    def poll_messages(self, label: str, since: str | None) -> tuple[list[MessagePayload], str | None]:
        if since:
            self._last_seen_cursor = since
        body = self._fetch_inbox(label, self._last_seen_cursor, 0)
        next_cursor = read_optional_string(body, "nextCursor")
        if next_cursor:
            self._last_seen_cursor = next_cursor
        return parse_messages(body), next_cursor

    def wait_for_message(self, label: str, timeout_seconds: int, since: str | None) -> MessagePayload | None:
        if since:
            self._last_seen_cursor = since
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            chunk = min(WAIT_CHUNK_SECONDS, max(1, int(deadline - time.time() + 0.999)))
            body = self._fetch_inbox(label, self._last_seen_cursor, chunk)
            next_cursor = read_optional_string(body, "nextCursor")
            if next_cursor:
                self._last_seen_cursor = next_cursor
            messages = parse_messages(body)
            if messages:
                return messages[0]
        return None

    def _fetch_inbox(self, label: str, since: str | None, wait: int) -> JSONObject:
        self.ensure_runtime_device_registered(label)
        conversation_id = self.provision_conversation(label)
        self._require_plaintext_available()
        query = f"?wait={wait}"
        if since:
            query = f"?since={url_quote(since)}&wait={wait}"
        return self._request("GET", f"/api/agent/conversations/{conversation_id}/inbox{query}", None)

    def ensure_runtime_device_registered(self, label: str) -> None:
        if self._runtime_device_registered:
            return
        runtime_key = load_or_create_runtime_device_key(self.config)
        self._request(
            "POST",
            "/api/agent/devices",
            {"publicKey": runtime_key.public_key, "label": label},
        )
        self._runtime_device_registered = True

    def runtime_device_key_configured(self) -> bool:
        if self.config.agent_device_key_file:
            return Path(self.config.agent_device_key_file).expanduser().exists()
        try:
            return keyring.get_password(KEYRING_SERVICE, runtime_key_account(self.config)) is not None
        except Exception:
            return False

    def _require_plaintext_available(self) -> None:
        if self._conversation_encryption_mode != "client-side-e2ee-v1":
            return
        raise PlaineError(
            "private E2EE conversations require local device-key decrypt/encrypt support; "
            "this Plaine MCP build is plaintext-only"
        )

    def _request(self, method: str, path: str, body: JSONObject | None) -> JSONObject:
        data = None if body is None else json.dumps(body).encode("utf-8")
        request = urllib.request.Request(
            f"{self.config.api_base}{path}",
            data=data,
            method=method,
            headers={
                "x-api-key": self.config.api_key,
                "content-type": "application/json",
                "user-agent": "plaine-mcp/0.1.3",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=WAIT_CHUNK_SECONDS + 10) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = http_error_detail(exc)
            if detail:
                raise PlaineError(f"plaine request failed: {exc.code} {exc.reason}: {detail}") from exc
            raise PlaineError(f"plaine request failed: {exc.code} {exc.reason}") from exc
        except urllib.error.URLError as exc:
            raise PlaineError(f"plaine request failed: {exc.reason}") from exc
        parsed: object = json.loads(raw)
        if not isinstance(parsed, dict):
            raise PlaineError("plaine response was not a JSON object")
        return normalize_object(parsed)


def build_mcp_server(client: PlaineClient, label: str) -> FastMCP:
    server = FastMCP("plaine-mcp")

    @server.tool(
        description=(
            "Send a message to the user through Plaine. Fire-and-forget; use "
            "wait_for_message afterwards if you want to block for a reply."
        )
    )
    def message_user(text: str) -> SendMessageResult:
        try:
            message_id = client.post_message(label, text)
            return {"messageId": message_id}
        except PlaineError as exc:
            raise ToolError(str(exc)) from exc

    @server.tool(description="Return any new user messages since the last seen cursor, without waiting.")
    def poll_messages(since: str | None = None) -> PollMessagesResult:
        try:
            messages, next_cursor = client.poll_messages(label, since)
            return {
                "messages": [
                    {"message": extract_text(message), "messageId": message.id}
                    for message in messages
                ],
                "nextCursor": next_cursor,
            }
        except PlaineError as exc:
            raise ToolError(str(exc)) from exc

    @server.tool(description="Block until the next user message arrives, or until timeout_s elapses.")
    def wait_for_message(timeout_s: float = 300, since: str | None = None) -> WaitForMessageResult:
        try:
            timeout_seconds = max(1, int(timeout_s))
            message = client.wait_for_message(label, timeout_seconds, since)
            if message:
                return {"message": extract_text(message), "messageId": message.id}
            suggestion = (
                "No reply within the timeout. You may continue with your best judgment."
                if client.config.on_timeout == "continue"
                else "No reply within the timeout. Stop and wait for the user."
            )
            return {
                "status": "timeout",
                "timeout_s": timeout_seconds,
                "suggestion": suggestion,
            }
        except PlaineError as exc:
            raise ToolError(str(exc)) from exc

    @server.tool(description="Send a message to the user, then wait for their next reply.")
    def send_and_wait(text: str, timeout_s: float = 300) -> SendAndWaitResult:
        try:
            timeout_seconds = max(1, int(timeout_s))
            sent_message_id = client.post_message(label, text)
            message = client.wait_for_message(label, timeout_seconds, sent_message_id)
            if message:
                return {
                    "sentMessageId": sent_message_id,
                    "message": extract_text(message),
                    "messageId": message.id,
                    "status": None,
                    "timeout_s": None,
                    "suggestion": None,
                }
            suggestion = (
                "No reply within the timeout. You may continue with your best judgment."
                if client.config.on_timeout == "continue"
                else "No reply within the timeout. Stop and wait for the user."
            )
            return {
                "sentMessageId": sent_message_id,
                "message": None,
                "messageId": None,
                "status": "timeout",
                "timeout_s": timeout_seconds,
                "suggestion": suggestion,
            }
        except PlaineError as exc:
            raise ToolError(str(exc)) from exc

    @server.tool(description="Return Plaine MCP transport, message shape, and encryption capabilities.")
    def describe_message_capabilities() -> MessageCapabilitiesResult:
        return message_capabilities(client.runtime_device_key_configured())

    return server


def message_capabilities(local_device_key_configured: bool = False) -> MessageCapabilitiesResult:
    return {
        "transport": "local-stdio",
        "encryption": {
            "status": "plaintext-only",
            "encryptedEnvelopes": False,
            "requiresLocalDeviceKey": True,
            "localDeviceKeyConfigured": local_device_key_configured,
        },
        "outboundShapes": ["text-only"],
        "inboundShapes": ["text-only"],
        "approvalResponses": "inbound-only",
        "docsUrl": "https://plaine.chat/docs/integrations/coding-agents-mcp",
    }


def load_or_create_runtime_device_key(config: Config) -> RuntimeDeviceKey:
    private_pem = read_runtime_private_key(config)
    if private_pem is None:
        private_pem = serialize_private_key(X25519PrivateKey.generate())
        write_runtime_private_key(config, private_pem)
    return runtime_device_key_from_private_pem(private_pem)


def read_runtime_private_key(config: Config) -> str | None:
    if config.agent_device_key_file:
        path = Path(config.agent_device_key_file).expanduser()
        try:
            return path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return None
    try:
        return keyring.get_password(KEYRING_SERVICE, runtime_key_account(config))
    except Exception as exc:
        raise PlaineError(
            "local secure storage is unavailable; set PLAINE_AGENT_DEVICE_KEY_FILE "
            "to a user-readable private key file path"
        ) from exc


def write_runtime_private_key(config: Config, private_pem: str) -> None:
    if config.agent_device_key_file:
        path = Path(config.agent_device_key_file).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(private_pem, encoding="utf-8")
        path.chmod(0o600)
        return
    try:
        keyring.set_password(KEYRING_SERVICE, runtime_key_account(config), private_pem)
    except Exception as exc:
        raise PlaineError(
            "local secure storage is unavailable; set PLAINE_AGENT_DEVICE_KEY_FILE "
            "to a user-readable private key file path"
        ) from exc


def runtime_key_account(config: Config) -> str:
    digest = hashlib.sha256(f"{config.api_base}:{config.api_key}".encode()).hexdigest()
    return f"agent-api-key:{digest[:32]}"


def runtime_device_key_from_private_pem(private_pem: str) -> RuntimeDeviceKey:
    loaded = serialization.load_pem_private_key(private_pem.encode("utf-8"), password=None)
    if not isinstance(loaded, X25519PrivateKey):
        raise PlaineError("local runtime device key must be an X25519 private key")
    return RuntimeDeviceKey(
        public_key=f"{RUNTIME_PUBLIC_KEY_PREFIX}{public_key_base64url(loaded)}",
        private_pem=private_pem,
    )


def serialize_private_key(private_key: X25519PrivateKey) -> str:
    raw = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    return raw.decode("utf-8")


def public_key_base64url(private_key: X25519PrivateKey) -> str:
    raw = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def parse_messages(body: JSONObject) -> list[MessagePayload]:
    raw_messages = body.get("messages")
    if not isinstance(raw_messages, list):
        raise PlaineError("plaine inbox response missing messages")
    messages: list[MessagePayload] = []
    for raw_message in raw_messages:
        message = read_object(raw_message)
        content_encrypted = read_optional_string(message, "contentEncrypted")
        if content_encrypted:
            raise PlaineError(
                "private E2EE messages require local decrypt support; this Plaine MCP build "
                "does not have conversation-key unwrap/decrypt yet"
            )
        raw_parts = message.get("parts")
        if not isinstance(raw_parts, list):
            raise PlaineError("plaine message missing parts")
        parts = [read_object(part) for part in raw_parts]
        messages.append(
            MessagePayload(
                id=read_required_string(message, "id"),
                parts=parts,
                content_encrypted=content_encrypted,
            )
        )
    return messages


def extract_text(message: MessagePayload) -> str:
    for part in message.parts:
        if part.get("type") == "text":
            text = part.get("text")
            if isinstance(text, str):
                return text
    return ""


def read_object(value: JSONValue | object) -> JSONObject:
    if not isinstance(value, dict):
        raise PlaineError("expected JSON object")
    return normalize_object(value)


def normalize_object(value: dict[object, object]) -> JSONObject:
    result: JSONObject = {}
    for key, item in value.items():
        if not isinstance(key, str):
            continue
        result[key] = normalize_json_value(item)
    return result


def normalize_json_value(value: object) -> JSONValue:
    if value is None or isinstance(value, bool | int | float | str):
        return value
    if isinstance(value, list):
        return [normalize_json_value(item) for item in value]
    if isinstance(value, dict):
        return normalize_object(value)
    raise PlaineError("unsupported JSON value")


def read_required_string(obj: JSONObject, key: str) -> str:
    value = obj.get(key)
    if not isinstance(value, str) or not value:
        raise PlaineError(f"{key} is required")
    return value


def read_optional_string(obj: JSONObject, key: str) -> str | None:
    value = obj.get(key)
    return value if isinstance(value, str) and value else None


def url_quote(value: str) -> str:
    return urllib.parse.quote(value, safe="")


def http_error_detail(exc: urllib.error.HTTPError) -> str | None:
    raw = exc.read().decode("utf-8")
    if not raw:
        return None
    try:
        parsed: object = json.loads(raw)
    except json.JSONDecodeError:
        return raw[:200]
    if not isinstance(parsed, dict):
        return raw[:200]
    error = parsed.get("error")
    if isinstance(error, str):
        return error
    return raw[:200]
