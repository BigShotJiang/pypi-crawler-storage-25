from __future__ import annotations

import argparse
import sys

from plaine import __version__
from plaine.mcp import run_mcp_server


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="plaine", description="Plaine command-line tools.")
    parser.add_argument("--version", action="version", version=f"plaine {__version__}")
    subparsers = parser.add_subparsers(dest="command")

    mcp = subparsers.add_parser("mcp", help="Run the Plaine stdio MCP server.")
    mcp.set_defaults(handler=run_mcp_server)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    handler = getattr(args, "handler", None)
    if handler is None:
        parser.print_help(sys.stderr)
        return 2
    handler()
    return 0

