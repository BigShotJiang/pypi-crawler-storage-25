# plaine

Lightweight Python CLI for [Plaine](https://plaine.chat).

## MCP

Run the local FastMCP stdio server with `uvx`:

```bash
uvx plaine mcp
```

The server uses the same environment variables as `@plaine/mcp`:

| Env var | Required | Default |
| --- | --- | --- |
| `PLAINE_API_KEY` | yes | - |
| `PLAINE_API_BASE` | no | `https://plaine.chat` |
| `PLAINE_CONVERSATION_ID` | no | auto-provisioned by label |
| `PLAINE_CONVERSATION_LABEL` | no | `${hostname}:${basename(cwd)}` |
| `PLAINE_ON_TIMEOUT` | no | `stop` |
| `PLAINE_AGENT_DEVICE_KEY_FILE` | no | OS secure storage |

Tools: `message_user`, `poll_messages`, `wait_for_message`, `send_and_wait`, and `describe_message_capabilities`.

This local stdio package is plaintext-only until local device-key support lands. It refuses `client-side-e2ee-v1` conversations rather than returning empty plaintext.

On first use, the server generates or loads a local X25519 agent-runtime device key, stores the private half locally, and registers only `plaine-agent-runtime-key-v1:<public>` with Plaine.

Example Claude Code setup:

```bash
claude mcp add plaine uvx plaine mcp \
  --env PLAINE_API_KEY=plane_xxx \
  --env PLAINE_API_BASE=https://plaine.chat
```
