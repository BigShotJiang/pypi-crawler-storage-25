from __future__ import annotations

import json
import secrets
from dataclasses import dataclass


def encode_message(message: dict) -> bytes:
    return (json.dumps(message) + "\n").encode("utf-8")


class JsonLineReader:
    def __init__(self) -> None:
        self._buffer = ""

    def feed(self, chunk: bytes) -> list[dict]:
        self._buffer += chunk.decode("utf-8")
        messages: list[dict] = []

        while True:
            newline = self._buffer.find("\n")
            if newline == -1:
                return messages

            line = self._buffer[:newline].strip()
            self._buffer = self._buffer[newline + 1 :]

            if not line:
                continue

            messages.append(json.loads(line))


def random_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(4)}"


def parse_labels(items: list[str]) -> dict[str, str]:
    labels: dict[str, str] = {}

    for item in items:
        if "=" not in item:
            raise ValueError(f"Invalid label {item!r}. Expected key=value.")

        key, value = item.split("=", 1)
        key = key.strip()
        value = value.strip()

        if not key or not value:
            raise ValueError(f"Invalid label {item!r}. Expected key=value.")

        labels[key] = value

    return labels


def labels_match(worker_labels: dict[str, str], required_labels: dict[str, str]) -> bool:
    for key, value in required_labels.items():
        if worker_labels.get(key) != value:
            return False
    return True


@dataclass(slots=True)
class Address:
    host: str
    port: int


def parse_address(value: str) -> Address:
    if ":" not in value:
        raise ValueError(f"Invalid address {value!r}. Expected host:port.")

    host, port_text = value.rsplit(":", 1)
    host = host.strip()

    if not host:
        raise ValueError(f"Invalid address {value!r}. Expected host:port.")

    return Address(host=host, port=int(port_text))
