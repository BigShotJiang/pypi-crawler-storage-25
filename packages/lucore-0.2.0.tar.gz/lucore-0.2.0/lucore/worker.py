from __future__ import annotations

import asyncio
import platform
import socket
import sys
import time

from .protocol import JsonLineReader, encode_message, random_id


async def run_worker(host: str, port: int, name: str | None, labels: dict[str, str]) -> None:
    reader, writer = await asyncio.open_connection(host, port)
    worker_id = random_id("worker")

    await _send(
        writer,
        {
            "type": "register_worker",
            "workerId": worker_id,
            "name": name or socket.gethostname(),
            "labels": labels,
            "platform": platform.system(),
        },
    )

    heartbeat_task = asyncio.create_task(_heartbeat(writer, worker_id))
    parser = JsonLineReader()

    try:
        while not reader.at_eof():
            chunk = await reader.read(8192)
            if not chunk:
                break

            for message in parser.feed(chunk):
                if message.get("type") == "worker_registered":
                    print(
                        f"lucore worker {worker_id} connected to {host}:{port} "
                        f"labels={labels} platform={platform.system()}",
                        flush=True,
                    )
                    continue

                if message.get("type") == "run_job":
                    command = str(message["command"])
                    job_id = str(message["jobId"])
                    print(f"running {job_id}: {command}", flush=True)
                    started_at = time.time()
                    exit_code, stdout, stderr = await _run_shell(command)
                    finished_at = time.time()
                    await _send(
                        writer,
                        {
                            "type": "job_result",
                            "jobId": job_id,
                            "exitCode": exit_code,
                            "stdout": stdout,
                            "stderr": stderr,
                            "startedAt": started_at,
                            "finishedAt": finished_at,
                        },
                    )
                    continue

                if message.get("type") == "error":
                    print(message["error"], file=sys.stderr, flush=True)
    finally:
        heartbeat_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await heartbeat_task
        writer.close()
        await writer.wait_closed()


async def _heartbeat(writer: asyncio.StreamWriter, worker_id: str) -> None:
    while True:
        await asyncio.sleep(5)
        await _send(writer, {"type": "heartbeat", "workerId": worker_id})


async def _run_shell(command: str) -> tuple[int, str, str]:
    process = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout_bytes, stderr_bytes = await process.communicate()
    return process.returncode or 0, stdout_bytes.decode(), stderr_bytes.decode()


async def _send(writer: asyncio.StreamWriter, message: dict) -> None:
    writer.write(encode_message(message))
    await writer.drain()


import contextlib
