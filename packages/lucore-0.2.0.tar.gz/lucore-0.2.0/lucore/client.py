from __future__ import annotations

import asyncio
import shlex

from .config import load_commands, load_tasks, resolve_entry
from .protocol import JsonLineReader, encode_message


async def run_remote_job(
    host: str,
    port: int,
    command: str,
    labels: dict[str, str],
    name: str | None = None,
) -> dict:
    reader, writer = await asyncio.open_connection(host, port)
    await _send(
        writer,
        {
            "type": "submit_job",
            "command": command,
            "labels": labels,
            "name": name,
            "detach": False,
        },
    )

    parser = JsonLineReader()

    try:
        while not reader.at_eof():
            chunk = await reader.read(8192)
            if not chunk:
                break

            for message in parser.feed(chunk):
                if message.get("type") == "job_queued":
                    print(f"queued {message['jobId']}")
                    continue

                if message.get("type") == "job_completed":
                    return message

                if message.get("type") == "error":
                    raise RuntimeError(str(message["error"]))
    finally:
        writer.close()
        await writer.wait_closed()

    raise RuntimeError("Connection closed before the job completed.")


async def submit_remote_job(
    host: str,
    port: int,
    command: str,
    labels: dict[str, str],
    name: str | None = None,
) -> dict:
    return await request_broker(
        host,
        port,
        {
            "type": "submit_job",
            "command": command,
            "labels": labels,
            "name": name,
            "detach": True,
        },
    )


async def query_jobs(host: str, port: int, limit: int = 20) -> dict:
    return await request_broker(host, port, {"type": "query_jobs", "limit": limit})


async def query_workers(host: str, port: int) -> dict:
    return await request_broker(host, port, {"type": "query_workers"})


async def inspect_job(host: str, port: int, job_id: str) -> dict:
    return await request_broker(host, port, {"type": "query_job", "jobId": job_id})


async def fetch_logs(host: str, port: int, job_id: str) -> dict:
    return await request_broker(host, port, {"type": "query_logs", "jobId": job_id})


async def request_broker(host: str, port: int, payload: dict) -> dict:
    reader, writer = await asyncio.open_connection(host, port)
    await _send(writer, payload)
    parser = JsonLineReader()

    try:
        while not reader.at_eof():
            chunk = await reader.read(8192)
            if not chunk:
                break

            for message in parser.feed(chunk):
                if message.get("type") == "error":
                    raise RuntimeError(str(message["error"]))
                return message
    finally:
        writer.close()
        await writer.wait_closed()

    raise RuntimeError("Broker closed the connection without a response.")


def resolve_named_command(
    name: str,
    extra_args: list[str],
    config_path: str | None = None,
) -> tuple[str, dict[str, str]]:
    commands = load_commands(config_path)
    if name not in commands:
        known = ", ".join(sorted(commands)) or "none"
        raise ValueError(f"Unknown lucore command {name!r}. Known commands: {known}")

    return render_entry(commands[name], extra_args)


def resolve_task(
    name: str,
    extra_args: list[str],
    config_path: str | None = None,
) -> tuple[dict, str, dict[str, str]]:
    entry = resolve_entry("tasks", name, config_path)
    command, labels = render_entry(entry, extra_args)
    return entry, command, labels


def render_entry(entry: dict, extra_args: list[str]) -> tuple[str, dict[str, str]]:
    template = entry["shell"]
    labels = dict(entry.get("labels", {}))
    args = " ".join(shlex.quote(arg) for arg in extra_args)
    command = template.replace("{args}", args).strip()
    return command, labels


async def _send(writer: asyncio.StreamWriter, message: dict) -> None:
    writer.write(encode_message(message))
    await writer.drain()
