from __future__ import annotations

import subprocess


def run_local_command(command: str) -> dict:
    completed = subprocess.run(
        command,
        shell=True,
        text=True,
        capture_output=True,
    )
    return {
        "jobId": "local",
        "workerId": "local",
        "exitCode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "command": command,
    }
