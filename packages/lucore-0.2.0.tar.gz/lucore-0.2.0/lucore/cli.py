from __future__ import annotations

import argparse
import asyncio
import csv
import json
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
import platform

from . import __version__
from .broker import Broker
from .client import (
    fetch_logs,
    inspect_job,
    query_jobs,
    query_workers,
    resolve_named_command,
    resolve_task,
    run_remote_job,
    submit_remote_job,
)
from .config import load_commands, load_project_config, load_tasks
from .config import load_shortcuts
from .local import run_local_command
from .node_tools import (
    command_exists,
    ensure_binary,
    list_package_scripts,
    npx_command,
    run_passthrough,
    scaffold_node_api,
    scaffold_node_app,
    scaffold_node_lib,
)
from .protocol import parse_address, parse_labels
from .worker import run_worker


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="lucore",
        description="A real distributed CLI/runtime for local and distributed commands, tasks, and workers.",
    )
    subparsers = parser.add_subparsers(dest="subcommand")

    broker = subparsers.add_parser("broker", help="Run the central broker.")
    broker.add_argument("--listen", default="127.0.0.1:7000", help="Broker bind address.")

    worker = subparsers.add_parser("worker", help="Run a worker that executes jobs.", aliases=["join"])
    worker.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    worker.add_argument("--name", help="Optional worker name.")
    worker.add_argument("--label", action="append", default=[], help="Worker label key=value.")

    run = subparsers.add_parser("run", help="Run a shell command locally or on the cluster.")
    run.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    run.add_argument("--label", action="append", default=[], help="Required job label key=value.")
    run.add_argument("--command", required=True, help="Shell command to run.")
    run.add_argument("--local", action="store_true", help="Run locally instead of distributed.")
    run.add_argument("--detach", action="store_true", help="Submit and return the job id immediately.")
    run.add_argument("--name", help="Optional human-friendly job name.")

    exec_cmd = subparsers.add_parser("exec", help="Alias for run with a more shell-like name.")
    exec_cmd.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    exec_cmd.add_argument("--label", action="append", default=[], help="Required job label key=value.")
    exec_cmd.add_argument("--command", required=True, help="Shell command to run.")
    exec_cmd.add_argument("--local", action="store_true", help="Run locally instead of distributed.")
    exec_cmd.add_argument("--detach", action="store_true", help="Submit and return the job id immediately.")
    exec_cmd.add_argument("--name", help="Optional human-friendly job name.")

    invoke = subparsers.add_parser("invoke", help="Run a named command from lucore.toml.")
    invoke.add_argument("name", help="Command name from lucore.toml [commands].")
    invoke.add_argument("args", nargs="*", help="Extra args passed into {args}.")
    invoke.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    invoke.add_argument("--config", help="Optional lucore.toml path.")
    invoke.add_argument("--local", action="store_true", help="Run locally instead of distributed.")
    invoke.add_argument("--detach", action="store_true", help="Submit and return the job id immediately.")

    task = subparsers.add_parser("task", help="Manage and run project tasks.")
    task_subparsers = task.add_subparsers(dest="task_command")

    task_run = task_subparsers.add_parser("run", help="Run a named task.")
    task_run.add_argument("name", help="Task name from lucore.toml [tasks].")
    task_run.add_argument("args", nargs="*", help="Extra args passed into {args}.")
    task_run.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    task_run.add_argument("--config", help="Optional lucore.toml path.")
    task_run.add_argument("--local", action="store_true", help="Force local execution.")
    task_run.add_argument("--detach", action="store_true", help="Submit and return the job id immediately.")

    task_list = task_subparsers.add_parser("list", help="List configured tasks.")
    task_list.add_argument("--config", help="Optional lucore.toml path.")

    task_show = task_subparsers.add_parser("show", help="Show one configured task.")
    task_show.add_argument("name", help="Task name from lucore.toml [tasks].")
    task_show.add_argument("--config", help="Optional lucore.toml path.")

    commands = subparsers.add_parser("commands", help="List configured named commands.")
    commands.add_argument("--config", help="Optional lucore.toml path.")

    hello = subparsers.add_parser("hello", help="Show a friendly getting-started summary.")
    hello.add_argument("--config", help="Optional lucore.toml path.")

    tasks_alias = subparsers.add_parser("tasks", help="Alias for `lucore task list`.")
    tasks_alias.add_argument("--config", help="Optional lucore.toml path.")

    make = subparsers.add_parser("make", help="Easy alias for `lucore task run`.")
    make.add_argument("name", help="Task name.")
    make.add_argument("args", nargs="*", help="Extra args passed into {args}.")
    make.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    make.add_argument("--config", help="Optional lucore.toml path.")
    make.add_argument("--local", action="store_true", help="Force local execution.")
    make.add_argument("--detach", action="store_true", help="Submit and return the job id immediately.")

    do = subparsers.add_parser("do", help="Run the most likely task, script, or command by name.")
    do.add_argument("name", help="Thing to run.")
    do.add_argument("args", nargs="*", help="Extra args passed through.")
    do.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    do.add_argument("--config", help="Optional lucore.toml path.")
    do.add_argument("--local", action="store_true", help="Force local execution.")
    do.add_argument("--detach", action="store_true", help="Submit and return the job id immediately.")

    find_cmd = subparsers.add_parser("find", help="Find files, text, jobs, workers, scripts, or tasks.")
    find_cmd.add_argument("topic", help="What to find.")
    find_cmd.add_argument("args", nargs="*", help="Extra search words.")
    find_cmd.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    find_cmd.add_argument("--config", help="Optional lucore.toml path.")

    deploy = subparsers.add_parser("deploy", help="Deploy or publish the current project in the simplest likely way.")
    deploy.add_argument("target", nargs="?", default="project", help="What to deploy.")
    deploy.add_argument("args", nargs="*", help="Extra arguments.")
    deploy.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    deploy.add_argument("--config", help="Optional lucore.toml path.")

    plugin = subparsers.add_parser("plugin", help="Manage lucore shortcuts/plugins.")
    plugin_subparsers = plugin.add_subparsers(dest="plugin_command")

    plugin_list = plugin_subparsers.add_parser("list", help="List configured shortcuts/plugins.")
    plugin_list.add_argument("--config", help="Optional lucore.toml path.")

    plugin_add = plugin_subparsers.add_parser("add", help="Add a shortcut/plugin entry to lucore.toml.")
    plugin_add.add_argument("name", help="Shortcut name.")
    plugin_add.add_argument("command", help="Command to run.")
    plugin_add.add_argument("--description", default="", help="Optional description.")
    plugin_add.add_argument("--config", help="Optional lucore.toml path.")

    cloud = subparsers.add_parser("cloud", help="Pass arguments to a cloud CLI if installed.")
    cloud.add_argument("provider", nargs="?", default="aws", help="Cloud provider, for example aws.")
    cloud.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to the provider CLI.")

    docker_cmd = subparsers.add_parser("docker", help="Pass arguments directly to docker if installed.")
    docker_cmd.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to docker.")

    ai = subparsers.add_parser("ai", help="Simple AI helper commands for prompts and local task suggestions.")
    ai_subparsers = ai.add_subparsers(dest="ai_command")

    ai_prompt = ai_subparsers.add_parser("prompt", help="Print a reusable prompt scaffold.")
    ai_prompt.add_argument("topic", nargs="?", default="general", help="Prompt topic.")

    ai_explain = ai_subparsers.add_parser("explain", help="Explain a command in plain language.")
    ai_explain.add_argument("text", nargs="+", help="Command or text to explain.")

    scan = subparsers.add_parser("scan", help="Scan ports, files, text, or system state.")
    scan.add_argument("topic", help="What to scan.")
    scan.add_argument("args", nargs="*", help="Extra scan arguments.")
    scan.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    scan.add_argument("--config", help="Optional lucore.toml path.")

    health = subparsers.add_parser("health", help="Run a simple health check.")
    health.add_argument("topic", nargs="?", default="all", help="What to health-check.")
    health.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    health.add_argument("--config", help="Optional lucore.toml path.")

    watch = subparsers.add_parser("watch", help="Repeat a command every few seconds.")
    watch.add_argument("command", nargs=argparse.REMAINDER, help="Command to run repeatedly.")
    watch.add_argument("--seconds", type=float, default=2.0, help="Refresh interval in seconds.")

    http = subparsers.add_parser("http", help="Simple HTTP requests through curl.")
    http_subparsers = http.add_subparsers(dest="http_command")

    http_get = http_subparsers.add_parser("get", help="HTTP GET")
    http_get.add_argument("url", help="URL to fetch.")

    http_head = http_subparsers.add_parser("head", help="HTTP HEAD")
    http_head.add_argument("url", help="URL to fetch.")

    http_post = http_subparsers.add_parser("post", help="HTTP POST")
    http_post.add_argument("url", help="URL to post to.")
    http_post.add_argument("data", nargs="?", default="", help="Body data.")

    json_cmd = subparsers.add_parser("json", help="Pretty-print or query JSON.")
    json_subparsers = json_cmd.add_subparsers(dest="json_command")

    json_pretty = json_subparsers.add_parser("pretty", help="Pretty-print a JSON file.")
    json_pretty.add_argument("path", help="Path to JSON file.")

    json_query = json_subparsers.add_parser("query", help="Query a JSON file with jq.")
    json_query.add_argument("path", help="Path to JSON file.")
    json_query.add_argument("expression", help="jq expression.")

    csv_cmd = subparsers.add_parser("csv", help="Inspect CSV files.")
    csv_subparsers = csv_cmd.add_subparsers(dest="csv_command")

    csv_head = csv_subparsers.add_parser("head", help="Show the first rows of a CSV file.")
    csv_head.add_argument("path", help="Path to CSV file.")
    csv_head.add_argument("--rows", type=int, default=5, help="How many rows to show.")

    csv_columns = csv_subparsers.add_parser("columns", help="Show CSV column names.")
    csv_columns.add_argument("path", help="Path to CSV file.")

    image = subparsers.add_parser("image", help="Inspect image files.")
    image_subparsers = image.add_subparsers(dest="image_command")

    image_info = image_subparsers.add_parser("info", help="Show image metadata.")
    image_info.add_argument("path", help="Path to image file.")

    service = subparsers.add_parser("service", help="Simple service helpers.")
    service_subparsers = service.add_subparsers(dest="service_command")

    service_start = service_subparsers.add_parser("start", help="Start a named task or script.")
    service_start.add_argument("name", help="Task or script name.")
    service_start.add_argument("args", nargs="*", help="Extra args passed through.")
    service_start.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    service_start.add_argument("--config", help="Optional lucore.toml path.")
    service_start.add_argument("--local", action="store_true", help="Force local execution.")
    service_start.add_argument("--detach", action="store_true", help="Submit and return the job id immediately.")

    service_stop = service_subparsers.add_parser("stop", help="Stop a service by port.")
    service_stop.add_argument("port", help="Port to stop.")

    service_status = service_subparsers.add_parser("status", help="Show service status.")
    service_status.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    service_status.add_argument("--config", help="Optional lucore.toml path.")

    cron = subparsers.add_parser("cron", help="Simple cron helpers.")
    cron_subparsers = cron.add_subparsers(dest="cron_command")

    cron_list = cron_subparsers.add_parser("list", help="List current cron entries.")
    cron_example = cron_subparsers.add_parser("example", help="Print a cron entry example.")
    cron_example.add_argument("schedule", help="Schedule expression, for example '*/5 * * * *'.")
    cron_example.add_argument("command", help="Command to run.")

    process = subparsers.add_parser("process", help="Inspect running processes.")
    process_subparsers = process.add_subparsers(dest="process_command")

    process_list = process_subparsers.add_parser("list", help="List running processes.")
    process_list.add_argument("query", nargs="?", help="Optional process search text.")

    process_port = process_subparsers.add_parser("port", help="Show which process owns a port.")
    process_port.add_argument("port", help="Port number.")

    download = subparsers.add_parser("download", help="Download a URL to a file.")
    download.add_argument("url", help="URL to download.")
    download.add_argument("output", nargs="?", help="Optional output path.")

    archive = subparsers.add_parser("archive", help="Create or extract zip/tar archives.")
    archive_subparsers = archive.add_subparsers(dest="archive_command")

    archive_extract = archive_subparsers.add_parser("extract", help="Extract an archive.")
    archive_extract.add_argument("path", help="Archive path.")
    archive_extract.add_argument("--to", default=".", help="Extraction directory.")

    archive_create = archive_subparsers.add_parser("create", help="Create a zip archive from files.")
    archive_create.add_argument("path", help="Archive path to create.")
    archive_create.add_argument("sources", nargs="+", help="Files or directories to include.")

    hash_cmd = subparsers.add_parser("hash", help="Hash a file or string.")
    hash_cmd.add_argument("target", help="File path or string to hash.")
    hash_cmd.add_argument("--string", action="store_true", help="Treat target as a raw string.")
    hash_cmd.add_argument("--algorithm", default="256", choices=["1", "256", "512"], help="SHA algorithm.")

    uuid_cmd = subparsers.add_parser("uuid", help="Generate a UUID.")
    uuid_cmd.add_argument("--count", type=int, default=1, help="How many UUIDs to generate.")

    time_cmd = subparsers.add_parser("time", help="Show local or UTC time.")
    time_cmd.add_argument("topic", nargs="?", default="now", help="now, utc, or timestamp.")

    sysinfo = subparsers.add_parser("sysinfo", help="Show a compact system summary.")

    local_ip = subparsers.add_parser("local-ip", help="Show the local Wi-Fi or LAN IP address.")
    local_ip.add_argument("--interface", default="en0", help="Network interface, default en0.")

    wifi = subparsers.add_parser("wifi", help="Show quick Wi-Fi/LAN details.")
    wifi.add_argument("--interface", default="en0", help="Network interface, default en0.")

    serve = subparsers.add_parser("serve", help="Serve the current directory or a path over HTTP.")
    serve.add_argument("path", nargs="?", default=".", help="Directory to serve.")
    serve.add_argument("--port", type=int, default=3000, help="Port to serve on.")
    serve.add_argument("--host", default="0.0.0.0", help="Host to bind to.")

    share = subparsers.add_parser("share", help="Show the LAN URL for a port or start a quick file server.")
    share.add_argument("target", nargs="?", default="3000", help="Port number or path to share.")
    share.add_argument("--port", type=int, help="Port to use when sharing a path.")
    share.add_argument("--interface", default="en0", help="Network interface, default en0.")

    where = subparsers.add_parser("where", help="Locate a binary, task, command, shortcut, or script.")
    where.add_argument("name", help="Thing to locate.")
    where.add_argument("--config", help="Optional lucore.toml path.")

    stop = subparsers.add_parser("stop", help="Stop a port, process, or common dev server.")
    stop.add_argument("topic", nargs="?", default="port", help="What to stop.")
    stop.add_argument("args", nargs="*", help="Port or process name.")

    open_cmd = subparsers.add_parser("open", help="Open a URL, file, or local shared port.")
    open_cmd.add_argument("target", help="URL, file path, or port number.")
    open_cmd.add_argument("--interface", default="en0", help="Network interface for numeric ports.")

    shortcuts_cmd = subparsers.add_parser("shortcuts", help="List configured shortcuts from lucore.toml.")
    shortcuts_cmd.add_argument("--config", help="Optional lucore.toml path.")

    clean = subparsers.add_parser("clean", help="Clean build files, caches, modules, or temp files.")
    clean.add_argument("topic", nargs="?", default="build", help="What to clean.")
    clean.add_argument("args", nargs="*", help="Extra values like a path or port.")

    fix = subparsers.add_parser("fix", help="Fix common project problems quickly.")
    fix.add_argument("topic", nargs="?", default="deps", help="What to fix.")
    fix.add_argument("args", nargs="*", help="Extra values like a port number.")

    monitor = subparsers.add_parser("monitor", help="Monitor system or runtime information.")
    monitor.add_argument("topic", nargs="?", default="status", help="What to monitor.")
    monitor.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    monitor.add_argument("--config", help="Optional lucore.toml path.")

    tail = subparsers.add_parser("tail", help="Tail a file or recent job logs.")
    tail.add_argument("target", help="File path or job id.")
    tail.add_argument("--lines", type=int, default=40, help="How many lines to show.")
    tail.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")

    backup = subparsers.add_parser("backup", help="Copy a file or directory with rsync.")
    backup.add_argument("source", help="Source path.")
    backup.add_argument("destination", help="Destination path.")

    sync_cmd = subparsers.add_parser("sync", help="Sync files or directories with rsync.")
    sync_cmd.add_argument("source", help="Source path.")
    sync_cmd.add_argument("destination", help="Destination path.")

    ssh_cmd = subparsers.add_parser("ssh", help="Pass arguments directly to ssh.")
    ssh_cmd.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to ssh.")

    git_cmd = subparsers.add_parser("git", help="Pass arguments directly to git.")
    git_cmd.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to git.")

    db = subparsers.add_parser("db", help="Simple SQLite database helpers.")
    db_subparsers = db.add_subparsers(dest="db_command")

    db_tables = db_subparsers.add_parser("tables", help="List tables in a sqlite database.")
    db_tables.add_argument("path", help="Path to the sqlite database.")

    db_query = db_subparsers.add_parser("query", help="Run a SQL query against a sqlite database.")
    db_query.add_argument("path", help="Path to the sqlite database.")
    db_query.add_argument("sql", help="SQL query to run.")

    node_cmd = subparsers.add_parser("node", help="Pass arguments directly to the Node runtime.")
    node_cmd.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to node.")

    repl = subparsers.add_parser("repl", help="Open a Node REPL.")
    repl.add_argument("args", nargs=argparse.REMAINDER, help="Extra arguments passed to node.")

    eval_cmd = subparsers.add_parser("eval", help="Evaluate JavaScript with node -e.")
    eval_cmd.add_argument("code", help="JavaScript source code.")

    js = subparsers.add_parser("js", help="Run a JavaScript file with Node.")
    js.add_argument("entry", help="Path to the JavaScript file.")
    js.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to the script.")

    python_cmd = subparsers.add_parser("python", help="Pass arguments directly to Python.")
    python_cmd.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to python3.")

    py_cmd = subparsers.add_parser("py", help="Run a Python file with python3.")
    py_cmd.add_argument("entry", help="Path to the Python file.")
    py_cmd.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to the script.")

    pip_cmd = subparsers.add_parser("pip", help="Pass arguments directly to pip3.")
    pip_cmd.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to pip3.")

    venv_cmd = subparsers.add_parser("venv", help="Create a Python virtual environment.")
    venv_cmd.add_argument("path", nargs="?", default=".venv", help="Target virtual environment path.")

    add_py = subparsers.add_parser("add-py", help="Install one or more Python packages with pip.")
    add_py.add_argument("packages", nargs="+", help="Packages to install.")

    remove_py = subparsers.add_parser("remove-py", help="Uninstall one or more Python packages with pip.")
    remove_py.add_argument("packages", nargs="+", help="Packages to uninstall.")

    npm_cmd = subparsers.add_parser("npm", help="Pass arguments directly to npm.")
    npm_cmd.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to npm.")

    npx = subparsers.add_parser("npx", help="Run a package binary without installing it globally.")
    npx.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to npx or npm exec.")

    dlx = subparsers.add_parser("dlx", help="Alias for npx.")
    dlx.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to npx or npm exec.")

    install = subparsers.add_parser("install", help="Run npm install or install specific packages.")
    install.add_argument("packages", nargs="*", help="Packages to install.")
    install.add_argument("--dev", action="store_true", help="Install as devDependencies.")

    add = subparsers.add_parser("add", help="Alias for npm install <packages>.")
    add.add_argument("packages", nargs="+", help="Packages to install.")
    add.add_argument("--dev", action="store_true", help="Install as devDependencies.")

    remove = subparsers.add_parser("remove", help="Remove one or more installed packages.")
    remove.add_argument("packages", nargs="+", help="Packages to remove.")

    update = subparsers.add_parser("update", help="Update installed packages.")
    update.add_argument("packages", nargs="*", help="Optional packages to update.")

    pack = subparsers.add_parser("pack", help="Create an npm package tarball.")
    pack.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to npm pack.")

    publish = subparsers.add_parser("publish", help="Publish the package through npm.")
    publish.add_argument("args", nargs=argparse.REMAINDER, help="Arguments passed to npm publish.")

    list_cmd = subparsers.add_parser("list", help="List installed dependencies with npm ls.", add_help=False)

    outdated = subparsers.add_parser("outdated", help="Show outdated dependencies.", add_help=False)

    why = subparsers.add_parser("why", help="Explain why a package is installed.")
    why.add_argument("package", help="Package name.")

    info = subparsers.add_parser("info", help="Show npm package metadata.")
    info.add_argument("package", help="Package name.")
    info.add_argument("args", nargs=argparse.REMAINDER, help="Extra arguments passed to npm info.")

    env_cmd = subparsers.add_parser("env", help="Show runtime environment information.")
    env_cmd.add_argument("--json", action="store_true", help="Print env info as JSON-like lines.")

    bin_cmd = subparsers.add_parser("bin", help="Show resolved binary paths.")
    bin_cmd.add_argument("name", nargs="?", help="Optional binary name.")

    pkg = subparsers.add_parser("pkg", help="Inspect package.json fields.")
    pkg_subparsers = pkg.add_subparsers(dest="pkg_command")

    pkg_name = pkg_subparsers.add_parser("name", help="Print package name.")
    pkg_version = pkg_subparsers.add_parser("version", help="Print package version.")
    pkg_scripts = pkg_subparsers.add_parser("scripts", help="Print package scripts.")

    start = subparsers.add_parser("start", help="Run npm start.")
    start.add_argument("args", nargs=argparse.REMAINDER, help="Extra args passed after --.")
    start.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    start.add_argument("--config", help="Optional lucore.toml path.")
    start.add_argument("--local", action="store_true", help="Force local execution.")

    build_cmd = subparsers.add_parser("build", help="Smart build command for beginners.")
    build_cmd.add_argument("args", nargs="*", help="Extra args passed into the build task or script.")
    build_cmd.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    build_cmd.add_argument("--config", help="Optional lucore.toml path.")
    build_cmd.add_argument("--local", action="store_true", help="Force local execution.")
    build_cmd.add_argument("--detach", action="store_true", help="Submit and return the job id immediately.")

    test_cmd = subparsers.add_parser("test", help="Run npm test.")
    test_cmd.add_argument("args", nargs=argparse.REMAINDER, help="Extra args passed after --.")
    test_cmd.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    test_cmd.add_argument("--config", help="Optional lucore.toml path.")
    test_cmd.add_argument("--local", action="store_true", help="Force local execution.")

    check = subparsers.add_parser("check", help="Smart validation and system inspection command.")
    check.add_argument("topic", nargs="?", help="What to check, for example ports, disk, memory, node, scripts, workers.")
    check.add_argument("args", nargs="*", help="Extra args for the selected check.")
    check.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    check.add_argument("--config", help="Optional lucore.toml path.")
    check.add_argument("--local", action="store_true", help="Force local execution.")

    script = subparsers.add_parser("script", help="Inspect and run package.json scripts.")
    script_subparsers = script.add_subparsers(dest="script_command")

    script_list = script_subparsers.add_parser("list", help="List package.json scripts.")
    script_run = script_subparsers.add_parser("run", help="Run one package.json script.")
    script_run.add_argument("name", help="Script name.")
    script_run.add_argument("args", nargs=argparse.REMAINDER, help="Extra args passed after --.")

    create = subparsers.add_parser("create", help="Scaffold new projects.")
    create_subparsers = create.add_subparsers(dest="create_command")

    create_app = create_subparsers.add_parser("app", help="Create a Node-oriented lucore app.")
    create_app.add_argument("name", help="Target directory name.")
    create_app.add_argument("--force", action="store_true", help="Allow writing into a non-empty directory.")

    create_api = create_subparsers.add_parser("api", help="Create a minimal Node API service.")
    create_api.add_argument("name", help="Target directory name.")
    create_api.add_argument("--force", action="store_true", help="Allow writing into a non-empty directory.")

    create_lib = create_subparsers.add_parser("lib", help="Create a minimal Node library.")
    create_lib.add_argument("name", help="Target directory name.")
    create_lib.add_argument("--force", action="store_true", help="Allow writing into a non-empty directory.")

    new = subparsers.add_parser("new", help="Beginner-friendly project creation command.")
    new.add_argument("name", help="Project directory name.")
    new.add_argument("--kind", choices=["app", "api", "lib"], default="app", help="Project kind.")
    new.add_argument("--force", action="store_true", help="Allow writing into a non-empty directory.")

    dev = subparsers.add_parser("dev", help="Run the project dev task.")
    dev.add_argument("args", nargs="*", help="Extra args passed into {args}.")
    dev.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    dev.add_argument("--config", help="Optional lucore.toml path.")
    dev.add_argument("--local", action="store_true", help="Force local execution.")

    submit = subparsers.add_parser("submit", help="Submit a distributed command without waiting.")
    submit.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    submit.add_argument("--label", action="append", default=[], help="Required job label key=value.")
    submit.add_argument("--command", required=True, help="Shell command to run remotely.")
    submit.add_argument("--name", help="Optional human-friendly job name.")

    ps = subparsers.add_parser("ps", help="List recent jobs.")
    ps.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    ps.add_argument("--limit", type=int, default=20, help="Maximum jobs to show.")

    logs = subparsers.add_parser("logs", help="Show stored logs for a job.")
    logs.add_argument("job_id", help="Job id.")
    logs.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")

    inspect = subparsers.add_parser("inspect", help="Inspect one job.")
    inspect.add_argument("job_id", help="Job id.")
    inspect.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")

    cluster = subparsers.add_parser("cluster", help="Inspect cluster state.")
    cluster_subparsers = cluster.add_subparsers(dest="cluster_command")

    cluster_workers = cluster_subparsers.add_parser("workers", help="List connected workers.")
    cluster_workers.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")

    cluster_jobs = cluster_subparsers.add_parser("jobs", help="List recent jobs from the broker.")
    cluster_jobs.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    cluster_jobs.add_argument("--limit", type=int, default=20, help="Maximum jobs to show.")

    config = subparsers.add_parser("config", help="Inspect lucore config.")
    config_subparsers = config.add_subparsers(dest="config_command")

    config_path = config_subparsers.add_parser("path", help="Print the config path.")
    config_path.add_argument("--config", help="Optional lucore.toml path.")

    config_show = config_subparsers.add_parser("show", help="Show parsed config.")
    config_show.add_argument("--config", help="Optional lucore.toml path.")

    doctor = subparsers.add_parser("doctor", help="Show environment and config diagnostics.")
    doctor.add_argument("--config", help="Optional lucore.toml path.")

    status = subparsers.add_parser("status", help="Show a simple project and cluster status summary.")
    status.add_argument("--broker", default="127.0.0.1:7000", help="Broker address.")
    status.add_argument("--config", help="Optional lucore.toml path.")

    ports_alias = subparsers.add_parser("ports", help="Shortcut for `lucore check ports`.")
    memory_alias = subparsers.add_parser("memory", help="Shortcut for `lucore check memory`.")
    disk_alias = subparsers.add_parser("disk", help="Shortcut for `lucore check disk`.")
    workers_alias = subparsers.add_parser("workers", help="Shortcut for `lucore check workers`.")
    jobs_alias = subparsers.add_parser("jobs", help="Shortcut for `lucore check jobs`.")
    scripts_alias = subparsers.add_parser("scripts", help="Shortcut for `lucore check scripts`.")

    init = subparsers.add_parser("init", help="Write a starter lucore.toml file.")
    init.add_argument("--force", action="store_true", help="Overwrite an existing lucore.toml.")

    version = subparsers.add_parser("version", help="Print the lucore version.")
    version.set_defaults(_lucore_version=True)

    return parser


def main() -> None:
    raw_args = _normalize_raw_args(sys.argv[1:])
    if raw_args:
        if raw_args[0] == "node":
            ensure_binary("node")
            raise SystemExit(run_passthrough(["node", *raw_args[1:]]))
        if raw_args[0] == "npm":
            ensure_binary("npm")
            raise SystemExit(run_passthrough(["npm", *raw_args[1:]]))
        if raw_args[0] == "git":
            raise SystemExit(run_passthrough(["git", *raw_args[1:]]))
        if raw_args[0] == "ssh":
            raise SystemExit(run_passthrough(["ssh", *raw_args[1:]]))
        if raw_args[0] == "docker":
            binary = _which_or_missing("docker")
            if binary == "missing":
                raise SystemExit("docker is not installed on this machine.")
            raise SystemExit(run_passthrough(["docker", *raw_args[1:]]))
        if raw_args[0] == "python":
            raise SystemExit(run_passthrough(["python3", *raw_args[1:]]))
        if raw_args[0] == "pip":
            raise SystemExit(run_passthrough(["pip3", *raw_args[1:]]))
        if raw_args[0] == "repl":
            ensure_binary("node")
            raise SystemExit(run_passthrough(["node", *raw_args[1:]]))
        if raw_args[0] in {"npx", "dlx"}:
            raise SystemExit(run_passthrough([*npx_command(), *raw_args[1:]]))
        if raw_args[0] == "list":
            ensure_binary("npm")
            raise SystemExit(run_passthrough(["npm", "ls", *raw_args[1:]]))
        if raw_args[0] == "outdated":
            ensure_binary("npm")
            raise SystemExit(run_passthrough(["npm", "outdated", *raw_args[1:]]))

    parser = build_parser()
    args = parser.parse_args(raw_args)

    if args.subcommand is None:
        parser.print_help()
        return

    try:
        if getattr(args, "_lucore_version", False):
            print(__version__)
            return

        match args.subcommand:
            case "broker":
                address = parse_address(args.listen)
                asyncio.run(Broker().serve(address.host, address.port))
            case "worker" | "join":
                address = parse_address(args.broker)
                labels = parse_labels(args.label)
                asyncio.run(run_worker(address.host, address.port, args.name, labels))
            case "run" | "exec":
                _handle_command_run(
                    command=args.command,
                    broker=args.broker,
                    labels=parse_labels(args.label),
                    local=args.local,
                    detach=args.detach,
                    name=args.name,
                )
            case "submit":
                _handle_command_run(
                    command=args.command,
                    broker=args.broker,
                    labels=parse_labels(args.label),
                    local=False,
                    detach=True,
                    name=args.name,
                )
            case "invoke":
                command, labels = resolve_named_command(args.name, args.args, args.config)
                _handle_command_run(
                    command=command,
                    broker=args.broker,
                    labels=labels,
                    local=args.local,
                    detach=args.detach,
                    name=args.name,
                )
            case "task":
                _handle_task(args, parser)
            case "commands":
                entries = load_commands(args.config)
                if not entries:
                    print("No commands configured. Create lucore.toml or run `lucore init`.")
                    return
                for name, entry in sorted(entries.items()):
                    print(
                        f"{name}\tmode={entry['mode']}\tlabels={entry['labels']}\t"
                        f"shell={entry['shell']}"
                    )
            case "hello":
                _handle_hello(args.config)
            case "tasks":
                _handle_task(argparse.Namespace(task_command="list", config=args.config), parser)
            case "make":
                _handle_make(args, parser)
            case "do":
                _handle_do(args)
            case "find":
                _handle_find(args.topic, list(args.args), args.broker, args.config)
            case "deploy":
                _handle_deploy(args.target, list(args.args), args.broker, args.config)
            case "plugin":
                _handle_plugin(args, parser)
            case "cloud":
                _handle_cloud(args.provider, list(args.args))
            case "docker":
                _handle_docker(list(args.args))
            case "ai":
                _handle_ai(args, parser)
            case "scan":
                _handle_scan(args.topic, list(args.args), args.broker, args.config)
            case "health":
                _handle_health(args.topic, args.broker, args.config)
            case "watch":
                _handle_watch(list(args.command), args.seconds)
            case "http":
                _handle_http(args, parser)
            case "json":
                _handle_json(args, parser)
            case "csv":
                _handle_csv(args, parser)
            case "image":
                _handle_image(args, parser)
            case "service":
                _handle_service(args, parser)
            case "cron":
                _handle_cron(args, parser)
            case "process":
                _handle_process(args, parser)
            case "download":
                _handle_download(args.url, args.output)
            case "archive":
                _handle_archive(args, parser)
            case "hash":
                _handle_hash(args.target, args.string, args.algorithm)
            case "uuid":
                _handle_uuid(args.count)
            case "time":
                _handle_time(args.topic)
            case "sysinfo":
                _handle_sysinfo()
            case "local-ip":
                _handle_local_ip(args.interface)
            case "wifi":
                _handle_wifi(args.interface)
            case "serve":
                _handle_serve(args.path, args.port, args.host)
            case "share":
                _handle_share(args.target, args.port, args.interface)
            case "where":
                _handle_where(args.name, args.config)
            case "stop":
                _handle_stop(args.topic, list(args.args))
            case "open":
                _handle_open(args.target, args.interface)
            case "shortcuts":
                _handle_shortcuts(args.config)
            case "clean":
                _handle_clean(args.topic, list(args.args))
            case "fix":
                _handle_fix(args.topic, list(args.args), args.broker, args.config)
            case "monitor":
                _handle_monitor(args.topic, args.broker, args.config)
            case "tail":
                _handle_tail(args.target, args.lines, args.broker)
            case "backup":
                _handle_backup(args.source, args.destination)
            case "sync":
                _handle_sync(args.source, args.destination)
            case "node":
                ensure_binary("node")
                raise SystemExit(run_passthrough(["node", *args.args]))
            case "repl":
                ensure_binary("node")
                raise SystemExit(run_passthrough(["node", *args.args]))
            case "eval":
                ensure_binary("node")
                raise SystemExit(run_passthrough(["node", "-e", args.code]))
            case "js":
                ensure_binary("node")
                raise SystemExit(run_passthrough(["node", args.entry, *args.args]))
            case "python":
                raise SystemExit(run_passthrough(["python3", *args.args]))
            case "py":
                raise SystemExit(run_passthrough(["python3", args.entry, *args.args]))
            case "pip":
                raise SystemExit(run_passthrough(["pip3", *args.args]))
            case "venv":
                raise SystemExit(run_passthrough(["python3", "-m", "venv", args.path]))
            case "add-py":
                raise SystemExit(run_passthrough(["pip3", "install", *args.packages]))
            case "remove-py":
                raise SystemExit(run_passthrough(["pip3", "uninstall", "-y", *args.packages]))
            case "ssh":
                raise SystemExit(run_passthrough(["ssh", *args.args]))
            case "git":
                raise SystemExit(run_passthrough(["git", *args.args]))
            case "npm":
                ensure_binary("npm")
                raise SystemExit(run_passthrough(["npm", *args.args]))
            case "npx" | "dlx":
                raise SystemExit(run_passthrough([*npx_command(), *args.args]))
            case "install":
                ensure_binary("npm")
                command = ["npm", "install"]
                if args.dev:
                    command.append("--save-dev")
                command.extend(args.packages)
                raise SystemExit(run_passthrough(command))
            case "add":
                ensure_binary("npm")
                command = ["npm", "install"]
                if args.dev:
                    command.append("--save-dev")
                command.extend(args.packages)
                raise SystemExit(run_passthrough(command))
            case "remove":
                ensure_binary("npm")
                raise SystemExit(run_passthrough(["npm", "uninstall", *args.packages]))
            case "update":
                ensure_binary("npm")
                raise SystemExit(run_passthrough(["npm", "update", *args.packages]))
            case "pack":
                ensure_binary("npm")
                raise SystemExit(run_passthrough(["npm", "pack", *args.args]))
            case "publish":
                ensure_binary("npm")
                raise SystemExit(run_passthrough(["npm", "publish", *args.args]))
            case "list":
                ensure_binary("npm")
                raise SystemExit(run_passthrough(["npm", "ls", *args.args]))
            case "outdated":
                ensure_binary("npm")
                raise SystemExit(run_passthrough(["npm", "outdated", *args.args]))
            case "why":
                ensure_binary("npm")
                raise SystemExit(run_passthrough(["npm", "explain", args.package]))
            case "info":
                ensure_binary("npm")
                raise SystemExit(run_passthrough(["npm", "info", args.package, *args.args]))
            case "env":
                _handle_env(args)
            case "bin":
                _handle_bin(args)
            case "pkg":
                _handle_pkg(args, parser)
            case "start":
                _run_smart_project_command(
                    task_name="start",
                    script_name="start",
                    fallback_command=None,
                    args=list(args.args),
                    broker=args.broker,
                    config_path=args.config,
                    local=args.local,
                    detach=False,
                )
            case "build":
                _run_smart_project_command(
                    task_name="build",
                    script_name="build",
                    fallback_command="node src/index.js build",
                    args=list(args.args),
                    broker=args.broker,
                    config_path=args.config,
                    local=args.local,
                    detach=args.detach,
                )
            case "test":
                _run_smart_project_command(
                    task_name="test",
                    script_name="test",
                    fallback_command="node --test",
                    args=list(args.args),
                    broker=args.broker,
                    config_path=args.config,
                    local=args.local,
                    detach=False,
                )
            case "check":
                if args.topic:
                    _handle_check_topic(args.topic, list(args.args), args.broker, args.config)
                else:
                    _run_smart_project_command(
                        task_name="test",
                        script_name="test",
                        fallback_command="node --test",
                        args=list(args.args),
                        broker=args.broker,
                        config_path=args.config,
                        local=args.local,
                        detach=False,
                    )
            case "script":
                _handle_script(args, parser)
            case "db":
                _handle_db(args, parser)
            case "create":
                _handle_create(args, parser)
            case "new":
                _handle_create(
                    argparse.Namespace(create_command=args.kind, name=args.name, force=args.force),
                    parser,
                )
            case "dev":
                _run_smart_project_command(
                    task_name="dev",
                    script_name="dev",
                    fallback_command="node --watch src/index.js",
                    args=list(args.args),
                    broker=args.broker,
                    config_path=args.config,
                    local=args.local,
                    detach=False,
                )
            case "ps":
                address = parse_address(args.broker)
                response = asyncio.run(query_jobs(address.host, address.port, args.limit))
                _print_jobs(response["jobs"])
            case "logs":
                address = parse_address(args.broker)
                response = asyncio.run(fetch_logs(address.host, address.port, args.job_id))
                if response.get("stdout"):
                    sys.stdout.write(response["stdout"])
                if response.get("stderr"):
                    sys.stderr.write(response["stderr"])
            case "inspect":
                address = parse_address(args.broker)
                response = asyncio.run(inspect_job(address.host, address.port, args.job_id))
                job = response["job"]
                for key, value in job.items():
                    print(f"{key}: {value}")
            case "cluster":
                _handle_cluster(args, parser)
            case "config":
                _handle_config(args, parser)
            case "doctor":
                config = load_project_config(args.config)
                print(f"version: {__version__}")
                print(f"config_path: {config['path']}")
                print(f"config_exists: {config['path'].exists()}")
                print(f"tasks: {', '.join(sorted(config['tasks'])) or 'none'}")
                print(f"commands: {', '.join(sorted(config['commands'])) or 'none'}")
                print(f"node: {_which_or_missing('node')}")
                print(f"npm: {_which_or_missing('npm')}")
                print(f"npx: {_which_or_missing('npx') if command_exists('npx') else 'npm exec fallback'}")
            case "status":
                _handle_status(args.broker, args.config)
            case "ports":
                _handle_check_topic("ports", [], "127.0.0.1:7000", None)
            case "memory":
                _handle_check_topic("memory", [], "127.0.0.1:7000", None)
            case "disk":
                _handle_check_topic("disk", [], "127.0.0.1:7000", None)
            case "workers":
                _handle_check_topic("workers", [], "127.0.0.1:7000", None)
            case "jobs":
                _handle_check_topic("jobs", [], "127.0.0.1:7000", None)
            case "scripts":
                _handle_check_topic("scripts", [], "127.0.0.1:7000", None)
            case "init":
                _write_starter_config(force=args.force)
            case _:
                parser.error(f"Unknown subcommand: {args.subcommand}")
    except KeyboardInterrupt:
        print("stopped", file=sys.stderr)
        raise SystemExit(130)
    except (ValueError, RuntimeError, OSError) as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1) from error


def _handle_task(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.task_command is None:
        parser.error("task requires a subcommand")

    if args.task_command == "list":
        entries = load_tasks(args.config)
        if not entries:
            print("No tasks configured. Create lucore.toml or run `lucore init`.")
            return
        for name, entry in sorted(entries.items()):
            description = entry["description"] or "-"
            print(
                f"{name}\tmode={entry['mode']}\tlabels={entry['labels']}\t"
                f"description={description}\tshell={entry['shell']}"
            )
        return

    if args.task_command == "show":
        entry = load_tasks(args.config).get(args.name)
        if entry is None:
            raise ValueError(f"Unknown task {args.name!r}")
        for key, value in entry.items():
            print(f"{key}: {value}")
        return

    if args.task_command == "run":
        entry, command, labels = resolve_task(args.name, args.args, args.config)
        local = bool(args.local) or entry["mode"] == "local" or (
            entry["mode"] == "auto" and not labels
        )
        _handle_command_run(
            command=command,
            broker=args.broker,
            labels=labels,
            local=local,
            detach=args.detach,
            name=args.name,
        )
        return

    parser.error(f"Unknown task subcommand: {args.task_command}")


def _handle_make(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.name in {"app", "api", "lib"} and args.args:
        _handle_create(
            argparse.Namespace(create_command=args.name, name=args.args[0], force=False),
            parser,
        )
        return

    if args.name in {"ip", "local-ip", "wifi"}:
        interface = args.args[0] if args.args else "en0"
        if args.name == "wifi":
            _handle_wifi(interface)
        else:
            _handle_local_ip(interface)
        return

    if args.name in {"ports", "disk", "memory", "node", "npm", "python", "pip", "venv", "scripts", "tasks", "workers", "jobs"}:
        _handle_check_topic(args.name, list(args.args), args.broker, args.config)
        return

    _handle_task(
        argparse.Namespace(
            task_command="run",
            name=args.name,
            args=args.args,
            broker=args.broker,
            config=args.config,
            local=args.local,
            detach=args.detach,
        ),
        parser,
    )


def _handle_do(args: argparse.Namespace) -> None:
    shortcuts = load_shortcuts(args.config)
    if args.name in shortcuts:
        command = shortcuts[args.name]["command"]
        if command.startswith("lucore "):
            raise SystemExit(run_passthrough(command.split()))
        _handle_command_run(
            command=command if not args.args else f"{command} {' '.join(args.args)}",
            broker=args.broker,
            labels={},
            local=True if args.local else True,
            detach=args.detach,
            name=args.name,
        )
        return

    tasks = load_tasks(args.config)
    if args.name in tasks:
        _handle_task(
            argparse.Namespace(
                task_command="run",
                name=args.name,
                args=args.args,
                broker=args.broker,
                config=args.config,
                local=args.local,
                detach=args.detach,
            ),
            build_parser(),
        )
        return

    scripts = _safe_package_scripts()
    if args.name in scripts:
        ensure_binary("npm")
        command = ["npm", "run", args.name]
        if args.args:
            command.extend(["--", *args.args])
        raise SystemExit(run_passthrough(command))

    commands = load_commands(args.config)
    if args.name in commands:
        command, labels = resolve_named_command(args.name, args.args, args.config)
        _handle_command_run(
            command=command,
            broker=args.broker,
            labels=labels,
            local=args.local,
            detach=args.detach,
            name=args.name,
        )
        return

    raise ValueError(
        f"Nothing named {args.name!r} was found. Try `lucore tasks`, `lucore scripts`, or `lucore hello`."
    )


def _handle_plugin(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.plugin_command is None:
        parser.error("plugin requires a subcommand")

    if args.plugin_command == "list":
        _handle_shortcuts(args.config)
        return

    if args.plugin_command == "add":
        _add_shortcut(args.name, args.command, args.description, args.config)
        return

    parser.error(f"Unknown plugin subcommand: {args.plugin_command}")


def _handle_cluster(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.cluster_command is None:
        parser.error("cluster requires a subcommand")

    address = parse_address(args.broker)

    if args.cluster_command == "workers":
        response = asyncio.run(query_workers(address.host, address.port))
        workers = response["workers"]
        if not workers:
            print("No workers connected.")
            return
        for worker in workers:
            print(
                f"{worker['workerId']}\tname={worker['name']}\tbusy={worker['busy']}\t"
                f"platform={worker['platform']}\tlabels={worker['labels']}\t"
                f"currentJob={worker['currentJobId']}"
            )
        return

    if args.cluster_command == "jobs":
        response = asyncio.run(query_jobs(address.host, address.port, args.limit))
        _print_jobs(response["jobs"])
        return

    parser.error(f"Unknown cluster subcommand: {args.cluster_command}")


def _handle_db(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.db_command is None:
        parser.error("db requires a subcommand")

    if args.db_command == "tables":
        raise SystemExit(run_passthrough(["sqlite3", args.path, ".tables"]))

    if args.db_command == "query":
        raise SystemExit(run_passthrough(["sqlite3", "-header", "-column", args.path, args.sql]))

    parser.error(f"Unknown db subcommand: {args.db_command}")


def _handle_script(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.script_command is None:
        parser.error("script requires a subcommand")

    if args.script_command == "list":
        scripts = list_package_scripts()
        if not scripts:
            print("No package.json scripts found.")
            return
        for name, command in scripts.items():
            print(f"{name}\t{command}")
        return

    if args.script_command == "run":
        ensure_binary("npm")
        command = ["npm", "run", args.name]
        if args.args:
            command.extend(["--", *args.args])
        raise SystemExit(run_passthrough(command))

    parser.error(f"Unknown script subcommand: {args.script_command}")


def _handle_create(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.create_command is None:
        parser.error("create requires a subcommand")

    if args.create_command == "app":
        root = scaffold_node_app(args.name, force=args.force)
        print(f"created {root}")
        return

    if args.create_command == "api":
        root = scaffold_node_api(args.name, force=args.force)
        print(f"created {root}")
        return

    if args.create_command == "lib":
        root = scaffold_node_lib(args.name, force=args.force)
        print(f"created {root}")
        return

    parser.error(f"Unknown create subcommand: {args.create_command}")


def _handle_hello(config_path: str | None) -> None:
    config = load_project_config(config_path)
    print("Welcome to lucore.")
    print(f"version: {__version__}")
    print(f"config: {config['path']}")
    print(f"tasks: {', '.join(sorted(config['tasks'])) or 'none'}")
    print(f"commands: {', '.join(sorted(config['commands'])) or 'none'}")
    print("try these:")
    print("  lucore new my-app")
    print("  lucore dev")
    print("  lucore build")
    print("  lucore check ports")
    print("  lucore find hello")
    print("  lucore clean build")
    print("  lucore fix deps")
    print("  lucore status")


def _handle_status(broker: str, config_path: str | None) -> None:
    config = load_project_config(config_path)
    print(f"project: {config['project'].get('name', Path.cwd().name)}")
    print(f"config: {config['path']}")
    print(f"tasks: {', '.join(sorted(config['tasks'])) or 'none'}")
    print(f"commands: {', '.join(sorted(config['commands'])) or 'none'}")
    scripts = _safe_package_scripts()
    print(f"scripts: {', '.join(sorted(scripts)) or 'none'}")

    address = parse_address(broker)
    try:
        workers = asyncio.run(
            asyncio.wait_for(query_workers(address.host, address.port), timeout=1.5)
        )["workers"]
        jobs = asyncio.run(
            asyncio.wait_for(query_jobs(address.host, address.port, 5), timeout=1.5)
        )["jobs"]
        print(f"workers: {len(workers)}")
        print(f"recent_jobs: {len(jobs)}")
    except Exception:
        print("workers: broker unreachable")
        print("recent_jobs: broker unreachable")


def _handle_deploy(target: str, extra_args: list[str], broker: str, config_path: str | None) -> None:
    tasks = load_tasks(config_path)
    if "ship" in tasks:
        _handle_task(
            argparse.Namespace(
                task_command="run",
                name="ship",
                args=extra_args,
                broker=broker,
                config=config_path,
                local=False,
                detach=False,
            ),
            build_parser(),
        )
        return

    scripts = _safe_package_scripts()
    for name in ["deploy", "ship", "release"]:
        if name in scripts:
            ensure_binary("npm")
            command = ["npm", "run", name]
            if extra_args:
                command.extend(["--", *extra_args])
            raise SystemExit(run_passthrough(command))

    print(f"No deploy task was found for {target}. Try adding a `ship` task or a `deploy` script.")


def _handle_cloud(provider: str, args: list[str]) -> None:
    binary = _which_or_missing(provider)
    if binary == "missing":
        raise ValueError(f"{provider} CLI is not installed on this machine.")
    raise SystemExit(run_passthrough([provider, *args]))


def _handle_docker(args: list[str]) -> None:
    binary = _which_or_missing("docker")
    if binary == "missing":
        raise ValueError("docker is not installed on this machine.")
    raise SystemExit(run_passthrough(["docker", *args]))


def _handle_ai(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.ai_command is None:
        parser.error("ai requires a subcommand")

    if args.ai_command == "prompt":
        topic = args.topic
        print(f"Topic: {topic}")
        print("Goal:")
        print("Context:")
        print("Constraints:")
        print("Desired output:")
        return

    if args.ai_command == "explain":
        text = " ".join(args.text)
        print("Plain-language explanation:")
        print(f"This command or text means: {text}")
        return

    parser.error(f"Unknown ai subcommand: {args.ai_command}")


def _handle_scan(topic: str, extra_args: list[str], broker: str, config_path: str | None) -> None:
    key = topic.lower().replace("-", "").replace("_", "")
    if key in {"ports", "port", "memory", "disk", "workers", "jobs", "scripts", "tasks", "env"}:
        _handle_check_topic(key, extra_args, broker, config_path)
        return
    _handle_find(topic, extra_args, broker, config_path)


def _handle_health(topic: str, broker: str, config_path: str | None) -> None:
    key = topic.lower().replace("-", "").replace("_", "")
    if key in {"all", "project", "system", "status"}:
        _handle_status(broker, config_path)
        print("")
        _handle_check_topic("all", [], broker, config_path)
        return
    _handle_check_topic(topic, [], broker, config_path)


def _handle_watch(command: list[str], seconds: float) -> None:
    if not command:
        raise ValueError("Use `lucore watch lucore check ports` or `lucore watch --seconds 5 npm test`.")
    if seconds <= 0:
        raise ValueError("Watch interval must be greater than 0 seconds.")

    while True:
        print(f"$ {' '.join(command)}")
        exit_code = run_passthrough(command)
        if exit_code != 0:
            print(f"watch run exited with code {exit_code}", file=sys.stderr)
        print(f"refreshing in {seconds:g}s... press Ctrl+C to stop")
        time.sleep(seconds)


def _handle_http(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.http_command is None:
        parser.error("http requires a subcommand")

    if args.http_command == "get":
        raise SystemExit(run_passthrough(["curl", "-fsSL", args.url]))

    if args.http_command == "head":
        raise SystemExit(run_passthrough(["curl", "-I", args.url]))

    if args.http_command == "post":
        raise SystemExit(
            run_passthrough(
                ["curl", "-fsSL", "-X", "POST", args.url, "-H", "Content-Type: application/json", "-d", args.data]
            )
        )

    parser.error(f"Unknown http subcommand: {args.http_command}")


def _handle_json(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.json_command is None:
        parser.error("json requires a subcommand")

    if args.json_command == "pretty":
        path = Path(args.path)
        data = json.loads(path.read_text(encoding="utf-8"))
        print(json.dumps(data, indent=2, sort_keys=True))
        return

    if args.json_command == "query":
        if _which_or_missing("jq") == "missing":
            raise ValueError("jq is not installed on this machine.")
        raise SystemExit(run_passthrough(["jq", args.expression, args.path]))

    parser.error(f"Unknown json subcommand: {args.json_command}")


def _handle_csv(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.csv_command is None:
        parser.error("csv requires a subcommand")

    path = Path(args.path)
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        rows = list(reader)

    if not rows:
        print("CSV file is empty.")
        return

    if args.csv_command == "columns":
        for column in rows[0]:
            print(column)
        return

    if args.csv_command == "head":
        for row in rows[: max(1, args.rows + 1)]:
            print(",".join(row))
        return

    parser.error(f"Unknown csv subcommand: {args.csv_command}")


def _handle_image(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.image_command is None:
        parser.error("image requires a subcommand")

    if args.image_command == "info":
        path = Path(args.path)
        if not path.exists():
            raise ValueError(f"Image file {args.path!r} does not exist.")
        print(f"path: {path.resolve()}")
        raise SystemExit(run_passthrough(["file", str(path)]))

    parser.error(f"Unknown image subcommand: {args.image_command}")


def _handle_service(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.service_command is None:
        parser.error("service requires a subcommand")

    if args.service_command == "start":
        _handle_do(
            argparse.Namespace(
                name=args.name,
                args=list(args.args),
                broker=args.broker,
                config=args.config,
                local=args.local,
                detach=args.detach,
            )
        )
        return

    if args.service_command == "stop":
        _handle_stop("port", [args.port])
        return

    if args.service_command == "status":
        _handle_status(args.broker, args.config)
        return

    parser.error(f"Unknown service subcommand: {args.service_command}")


def _handle_cron(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.cron_command is None:
        parser.error("cron requires a subcommand")

    if args.cron_command == "list":
        raise SystemExit(run_passthrough(["crontab", "-l"]))

    if args.cron_command == "example":
        print(f"{args.schedule} {args.command}")
        return

    parser.error(f"Unknown cron subcommand: {args.cron_command}")


def _handle_process(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.process_command is None:
        parser.error("process requires a subcommand")

    if args.process_command == "list":
        if args.query:
            _print_local_check("process", f"ps aux | rg -i {args.query!r}")
            return
        _print_local_check("process", "ps aux")
        return

    if args.process_command == "port":
        _print_local_check("process", f"lsof -nP -iTCP:{args.port} -sTCP:LISTEN")
        return

    parser.error(f"Unknown process subcommand: {args.process_command}")


def _handle_download(url: str, output: str | None) -> None:
    command = ["curl", "-fL", url]
    if output:
        command.extend(["-o", output])
    raise SystemExit(run_passthrough(command))


def _handle_archive(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.archive_command is None:
        parser.error("archive requires a subcommand")

    if args.archive_command == "extract":
        path = args.path
        if path.endswith(".zip"):
            raise SystemExit(run_passthrough(["unzip", "-o", path, "-d", args.to]))
        raise SystemExit(run_passthrough(["tar", "-xf", path, "-C", args.to]))

    if args.archive_command == "create":
        path = args.path
        if path.endswith(".zip"):
            raise SystemExit(run_passthrough(["zip", "-r", path, *args.sources]))
        raise SystemExit(run_passthrough(["tar", "-czf", path, *args.sources]))

    parser.error(f"Unknown archive subcommand: {args.archive_command}")


def _handle_hash(target: str, as_string: bool, algorithm: str) -> None:
    algorithm_flag = {"1": "-a 1", "256": "-a 256", "512": "-a 512"}[algorithm]
    if as_string:
        result = run_local_command(f"printf %s {target!r} | shasum {algorithm_flag}")
        output = (result.get("stdout") or "").strip()
        if output:
            print(output.split()[0])
            return
        raise ValueError("Failed to hash the provided string.")

    path = Path(target)
    if not path.exists():
        raise ValueError(f"File {target!r} does not exist.")
    raise SystemExit(run_passthrough(["shasum", "-a", algorithm, str(path)]))


def _handle_uuid(count: int) -> None:
    if count < 1:
        raise ValueError("UUID count must be at least 1.")
    for _ in range(count):
        print(uuid.uuid4())


def _handle_time(topic: str) -> None:
    key = topic.lower().replace("-", "").replace("_", "")
    now = datetime.now()
    if key in {"now", "local"}:
        print(now.astimezone().isoformat())
        return
    if key == "utc":
        print(datetime.now(timezone.utc).isoformat())
        return
    if key in {"timestamp", "unix"}:
        print(int(now.timestamp()))
        return
    raise ValueError("Try `lucore time now`, `lucore time utc`, or `lucore time timestamp`.")


def _handle_sysinfo() -> None:
    print(f"platform: {platform.platform()}")
    print(f"python: {sys.version.split()[0]}")
    print(f"node: {_which_or_missing('node')}")
    print(f"npm: {_which_or_missing('npm')}")
    print(f"cwd: {Path.cwd()}")
    try:
        print(f"local_ip: {_get_local_ip('en0')}")
    except Exception:
        print("local_ip: unavailable")


def _handle_find(topic: str, extra_args: list[str], broker: str, config_path: str | None) -> None:
    key = topic.lower().replace("-", "").replace("_", "")

    if key in {"ports", "port", "workers", "jobs", "scripts", "tasks"}:
        _handle_check_topic(key, extra_args, broker, config_path)
        return

    if key in {"localip", "ip", "wifi", "lanip"}:
        interface = extra_args[0] if extra_args else "en0"
        _handle_local_ip(interface)
        return

    if key in {"file", "files"}:
        pattern = extra_args[0] if extra_args else ""
        command = "rg --files" if not pattern else f"rg --files | rg {pattern!r}"
        _print_local_check("files", command)
        return

    if key in {"text", "grep", "search"} and extra_args:
        pattern = " ".join(extra_args)
        _print_local_check("text", f"rg -n {pattern!r} .")
        return

    if key in {"package", "pkg"} and extra_args:
        ensure_binary("npm")
        raise SystemExit(run_passthrough(["npm", "info", extra_args[0]]))

    search_term = " ".join([topic, *extra_args]).strip()
    if search_term:
        _print_local_check("search", f"rg -n {search_term!r} .")
        return

    raise ValueError("Try `lucore find file name`, `lucore find text hello`, or `lucore find ports`.")


def _handle_local_ip(interface: str) -> None:
    ip = _get_local_ip(interface)
    print(ip)


def _get_local_ip(interface: str) -> str:
    result = run_local_command(f"ipconfig getifaddr {interface}")
    ip = (result.get("stdout") or "").strip()
    if ip:
        return ip
    raise ValueError(f"Could not find a local IP on interface {interface!r}.")


def _handle_wifi(interface: str) -> None:
    print(f"interface: {interface}")
    try:
        _handle_local_ip(interface)
    except ValueError as error:
        print(str(error))
    print("open ports:")
    _handle_check_topic("ports", [], "127.0.0.1:7000", None)


def _handle_monitor(topic: str, broker: str, config_path: str | None) -> None:
    key = topic.lower().replace("-", "").replace("_", "")
    if key in {"status", "project"}:
        _handle_status(broker, config_path)
        return
    if key in {"ports", "memory", "disk", "workers", "jobs"}:
        _handle_check_topic(key, [], broker, config_path)
        return
    if key == "cpu":
        command = "top -l 1 | head -20" if platform.system() == "Darwin" else "top -bn1 | head -20"
        _print_local_check("cpu", command)
        return
    raise ValueError("Try `lucore monitor cpu`, `lucore monitor memory`, `lucore monitor ports`, or `lucore monitor status`.")


def _handle_tail(target: str, lines: int, broker: str) -> None:
    path = Path(target)
    if path.exists():
        raise SystemExit(run_passthrough(["tail", "-n", str(lines), str(path)]))

    address = parse_address(broker)
    response = asyncio.run(asyncio.wait_for(fetch_logs(address.host, address.port, target), timeout=1.5))
    stdout = response.get("stdout") or ""
    stderr = response.get("stderr") or ""
    output = (stdout + ("\n" if stdout and stderr else "") + stderr).strip().splitlines()
    for line in output[-lines:]:
        print(line)


def _handle_backup(source: str, destination: str) -> None:
    raise SystemExit(run_passthrough(["rsync", "-a", source, destination]))


def _handle_sync(source: str, destination: str) -> None:
    raise SystemExit(run_passthrough(["rsync", "-av", "--delete", source, destination]))


def _handle_serve(path: str, port: int, host: str) -> None:
    raise SystemExit(
        run_passthrough(
            ["python3", "-m", "http.server", str(port), "--bind", host, "--directory", path]
        )
    )


def _handle_share(target: str, port: int | None, interface: str) -> None:
    if target.isdigit():
        ip = _get_local_ip(interface)
        print(f"http://{ip}:{target}")
        return

    chosen_port = port or 3000
    ip = _get_local_ip(interface)
    print(f"sharing {target} on http://{ip}:{chosen_port}")
    print("press Ctrl+C to stop")
    _handle_serve(target, chosen_port, "0.0.0.0")


def _handle_where(name: str, config_path: str | None) -> None:
    if Path(name).exists():
        print(Path(name).resolve())
        return

    binary = _which_or_missing(name)
    if binary != "missing":
        print(binary)
        return

    tasks = load_tasks(config_path)
    if name in tasks:
        print(f"task\t{name}\t{tasks[name]['shell']}")
        return

    commands = load_commands(config_path)
    if name in commands:
        print(f"command\t{name}\t{commands[name]['shell']}")
        return

    shortcuts = load_shortcuts(config_path)
    if name in shortcuts:
        print(f"shortcut\t{name}\t{shortcuts[name]['command']}")
        return

    scripts = _safe_package_scripts()
    if name in scripts:
        print(f"script\t{name}\t{scripts[name]}")
        return

    raise ValueError(f"Could not find {name!r}.")


def _handle_stop(topic: str, extra_args: list[str]) -> None:
    key = topic.lower().replace("-", "").replace("_", "")
    if key == "port":
        if not extra_args:
            raise ValueError("Use `lucore stop port 3000`.")
        _handle_clean("port", extra_args)
        return
    if key in {"server", "dev"}:
        port = extra_args[0] if extra_args else "3000"
        _handle_clean("port", [port])
        return
    if key in {"process", "proc"}:
        if not extra_args:
            raise ValueError("Use `lucore stop process node`.")
        name = extra_args[0]
        _print_local_check("process", f"pkill -f {name!r}")
        print(f"Tried to stop process matches for {name}.")
        return
    raise ValueError("Try `lucore stop port 3000`, `lucore stop server`, or `lucore stop process node`.")


def _handle_open(target: str, interface: str) -> None:
    if target.isdigit():
        target = f"http://{_get_local_ip(interface)}:{target}"
    opener = "open" if platform.system() == "Darwin" else "xdg-open"
    raise SystemExit(run_passthrough([opener, target]))


def _handle_shortcuts(config_path: str | None) -> None:
    shortcuts = load_shortcuts(config_path)
    if not shortcuts:
        print("No shortcuts configured.")
        return
    for name, entry in sorted(shortcuts.items()):
        description = entry["description"] or "-"
        print(f"{name}\tdescription={description}\tcommand={entry['command']}")


def _add_shortcut(name: str, command: str, description: str, config_path: str | None) -> None:
    path = Path(config_path or "lucore.toml")
    if not path.exists():
        _write_starter_config(force=False)

    existing = path.read_text(encoding="utf-8")
    block = (
        f"\n[shortcuts.{name}]\n"
        f'command = "{command.replace(chr(34), chr(92) + chr(34))}"\n'
        f'description = "{description.replace(chr(34), chr(92) + chr(34))}"\n'
    )
    path.write_text(existing.rstrip() + "\n" + block, encoding="utf-8")
    print(f"Added shortcut {name} to {path}")


def _handle_clean(topic: str, extra_args: list[str]) -> None:
    key = topic.lower().replace("-", "").replace("_", "")
    commands = {
        "build": "rm -rf dist build .coverage htmlcov",
        "cache": "rm -rf .pytest_cache .ruff_cache .mypy_cache node_modules/.cache",
        "modules": "rm -rf node_modules",
        "temp": "rm -rf /private/tmp/lucore-* /tmp/lucore-*",
        "all": "rm -rf dist build .coverage htmlcov .pytest_cache .ruff_cache .mypy_cache node_modules/.cache",
    }

    if key in commands:
        _print_local_check("clean", commands[key])
        print(f"Cleaned {key}.")
        return

    if key == "port" and extra_args:
        port = extra_args[0]
        _print_local_check("port", f"lsof -ti tcp:{port} | xargs -r kill")
        print(f"Tried to free port {port}.")
        return

    raise ValueError("Try `lucore clean build`, `lucore clean cache`, `lucore clean modules`, or `lucore clean port 3000`.")


def _handle_fix(topic: str, extra_args: list[str], broker: str, config_path: str | None) -> None:
    key = topic.lower().replace("-", "").replace("_", "")

    if key in {"deps", "dependencies", "package"}:
        ensure_binary("npm")
        raise SystemExit(run_passthrough(["npm", "install"]))

    if key == "config":
        path = Path(config_path or "lucore.toml")
        if path.exists():
            print(f"{path} already exists.")
            return
        _write_starter_config(force=False)
        return

    if key == "port" and extra_args:
        _handle_clean("port", extra_args)
        return

    if key == "broker":
        _handle_status(broker, config_path)
        return

    if key == "all":
        if not Path(config_path or "lucore.toml").exists():
            _write_starter_config(force=False)
        if Path("package.json").exists():
            ensure_binary("npm")
            raise SystemExit(run_passthrough(["npm", "install"]))
        print("Fixed what I could: config checked, package setup checked.")
        return

    raise ValueError("Try `lucore fix deps`, `lucore fix config`, `lucore fix port 3000`, or `lucore fix all`.")


def _run_smart_project_command(
    task_name: str,
    script_name: str,
    fallback_command: str | None,
    args: list[str],
    broker: str,
    config_path: str | None,
    local: bool,
    detach: bool,
) -> None:
    tasks = load_tasks(config_path)
    if task_name in tasks:
        effective_local = local or not _broker_reachable(broker)
        _handle_task(
            argparse.Namespace(
                task_command="run",
                name=task_name,
                args=args,
                broker=broker,
                config=config_path,
                local=effective_local,
                detach=detach,
            ),
            build_parser(),
        )
        return

    scripts = _safe_package_scripts()
    if script_name in scripts:
        ensure_binary("npm")
        command = ["npm", "run", script_name]
        if args:
            command.extend(["--", *args])
        raise SystemExit(run_passthrough(command))

    if fallback_command:
        command = fallback_command if not args else f"{fallback_command} {' '.join(args)}"
        _handle_command_run(
            command=command,
            broker=broker,
            labels={},
            local=True,
            detach=False,
            name=task_name,
        )
        return

    raise ValueError(
        f"No task or package script named {task_name!r} was found. "
        "Try `lucore hello` or `lucore task list`."
    )


def _handle_env(args: argparse.Namespace) -> None:
    import os
    import platform

    values = {
        "lucore": __version__,
        "python": sys.version.split()[0],
        "node": _which_or_missing("node"),
        "npm": _which_or_missing("npm"),
        "npx": _which_or_missing("npx"),
        "cwd": str(Path.cwd()),
        "platform": platform.platform(),
    }
    if args.json:
        for key, value in values.items():
            print(f"{key}={value}")
        return
    for key, value in values.items():
        print(f"{key}: {value}")
    path_preview = os.environ.get("PATH", "")
    print(f"PATH: {path_preview}")


def _handle_check_topic(topic: str, extra_args: list[str], broker: str, config_path: str | None) -> None:
    key = topic.lower().replace("-", "").replace("_", "")

    if key in {"ports", "port"}:
        _print_local_check("ports", "lsof -nP -iTCP -sTCP:LISTEN")
        return
    if key in {"disk", "storage"}:
        _print_local_check("disk", "df -h")
        return
    if key in {"memory", "ram"}:
        command = "vm_stat" if platform.system() == "Darwin" else "free -h"
        _print_local_check("memory", command)
        return
    if key in {"processes", "process", "ps"}:
        _print_local_check("processes", "ps aux | head -20")
        return
    if key in {"node", "nodejs"}:
        _print_local_check("node", "node --version")
        return
    if key == "npm":
        _print_local_check("npm", "npm --version")
        return
    if key == "pip":
        _print_local_check("pip", "pip3 --version")
        return
    if key in {"python", "python3"}:
        _print_local_check("python", "python3 --version")
        return
    if key in {"venv", "virtualenv"}:
        if Path(".venv").exists():
            print(".venv exists")
        else:
            print("No .venv found in this directory.")
        return
    if key in {"scripts", "script"}:
        scripts = _safe_package_scripts()
        if not scripts:
            print("No package.json scripts found.")
            return
        for name, command in scripts.items():
            print(f"{name}\t{command}")
        return
    if key in {"tasks", "task"}:
        _handle_task(argparse.Namespace(task_command="list", config=config_path), build_parser())
        return
    if key == "config":
        _handle_config(argparse.Namespace(config_command="show", config=config_path), build_parser())
        return
    if key == "env":
        _handle_env(argparse.Namespace(json=False))
        return
    if key == "workers":
        address = parse_address(broker)
        response = asyncio.run(asyncio.wait_for(query_workers(address.host, address.port), timeout=1.5))
        workers = response["workers"]
        if not workers:
            print("No workers connected.")
            return
        for worker in workers:
            print(
                f"{worker['workerId']}\tname={worker['name']}\tbusy={worker['busy']}\t"
                f"platform={worker['platform']}\tlabels={worker['labels']}"
            )
        return
    if key == "jobs":
        address = parse_address(broker)
        response = asyncio.run(asyncio.wait_for(query_jobs(address.host, address.port, 10), timeout=1.5))
        _print_jobs(response["jobs"])
        return
    if key == "all":
        _handle_status(broker, config_path)
        print("")
        _handle_env(argparse.Namespace(json=False))
        return

    known = "ports, disk, memory, processes, node, npm, python, pip, venv, scripts, tasks, config, env, workers, jobs, all"
    raise ValueError(f"Unknown check topic {topic!r}. Try one of: {known}")


def _print_local_check(label: str, command: str) -> None:
    result = run_local_command(command)
    if result.get("stderr"):
        sys.stderr.write(result["stderr"])
    if result.get("stdout"):
        sys.stdout.write(result["stdout"])
    if not result.get("stdout") and not result.get("stderr"):
        print(f"No output for {label}.")


def _handle_bin(args: argparse.Namespace) -> None:
    if args.name:
        print(_which_or_missing(args.name))
        return
    for name in ["lucore", "node", "npm", "npx", "python3"]:
        print(f"{name}: {_which_or_missing(name)}")


def _handle_pkg(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    from .node_tools import load_package_json

    if args.pkg_command is None:
        parser.error("pkg requires a subcommand")

    data = load_package_json()
    if args.pkg_command == "name":
        print(data.get("name", ""))
        return
    if args.pkg_command == "version":
        print(data.get("version", ""))
        return
    if args.pkg_command == "scripts":
        scripts = data.get("scripts", {})
        if not scripts:
            print("No scripts found.")
            return
        for name, command in scripts.items():
            print(f"{name}\t{command}")
        return
    parser.error(f"Unknown pkg subcommand: {args.pkg_command}")


def _handle_config(args: argparse.Namespace, parser: argparse.ArgumentParser) -> None:
    if args.config_command is None:
        parser.error("config requires a subcommand")

    config = load_project_config(args.config)

    if args.config_command == "path":
        print(config["path"])
        return

    if args.config_command == "show":
        print(f"path: {config['path']}")
        print(f"project: {config['project']}")
        print(f"tasks: {sorted(config['tasks'])}")
        print(f"commands: {sorted(config['commands'])}")
        return

    parser.error(f"Unknown config subcommand: {args.config_command}")


def _handle_command_run(
    command: str,
    broker: str,
    labels: dict[str, str],
    local: bool,
    detach: bool,
    name: str | None,
) -> None:
    if local:
        result = run_local_command(command)
        _print_result(result)
        raise SystemExit(int(result.get("exitCode", 0)))

    address = parse_address(broker)
    if detach:
        response = asyncio.run(submit_remote_job(address.host, address.port, command, labels, name))
        print(response["jobId"])
        return

    result = asyncio.run(run_remote_job(address.host, address.port, command, labels, name))
    _print_result(result)
    raise SystemExit(int(result.get("exitCode", 0)))


def _print_result(result: dict) -> None:
    stdout = result.get("stdout") or ""
    stderr = result.get("stderr") or ""

    if stdout:
        sys.stdout.write(stdout)
    if stderr:
        sys.stderr.write(stderr)

    print(
        f"job {result['jobId']} finished on {result.get('workerId')} "
        f"with exit code {result.get('exitCode', 0)}",
        file=sys.stderr,
    )


def _print_jobs(jobs: list[dict]) -> None:
    if not jobs:
        print("No jobs found.")
        return

    for job in jobs:
        print(
            f"{job['jobId']}\tstatus={job['status']}\tname={job.get('name') or '-'}\t"
            f"worker={job.get('workerId')}\tlabels={job['labels']}\tcommand={job['command']}"
        )


def _write_starter_config(force: bool) -> None:
    path = Path("lucore.toml")
    if path.exists() and not force:
        raise ValueError("lucore.toml already exists. Use --force to overwrite it.")

    path.write_text(
        """[project]
name = "amazing-lucore-app"
default_queue = "build"

[tasks.dev]
description = "Run the local development loop."
run = "node --watch src/index.js"
mode = "local"

[tasks.build]
description = "Build the project on distributed build workers."
run = "node src/index.js build {args}"
mode = "distributed"
labels = { queue = "build" }

[tasks.test]
description = "Run the test suite on test workers."
run = "node --test {args}"
mode = "distributed"
labels = { queue = "test" }

[tasks.start]
description = "Start the application."
run = "node src/index.js {args}"
mode = "local"

[tasks.ship]
description = "Example deployment command."
run = "echo shipping release {args}"
mode = "distributed"
labels = { queue = "deploy" }

[commands.hello]
shell = "echo hello from lucore {args}"
labels = { queue = "build" }

[commands.list]
shell = "ls -la {args}"
mode = "local"

[commands.python-version]
shell = "python3 --version"
mode = "local"

[shortcuts.ip]
command = "lucore local-ip"
description = "Show the local LAN IP."

[shortcuts.wifi]
command = "lucore wifi"
description = "Show the local LAN summary."
""",
        encoding="utf-8",
    )
    print(f"Wrote {path}")


def _which_or_missing(name: str) -> str:
    try:
        return ensure_binary(name)
    except RuntimeError:
        return "missing"


def _safe_package_scripts() -> dict[str, str]:
    try:
        return list_package_scripts()
    except Exception:
        return {}


def _broker_reachable(broker: str) -> bool:
    address = parse_address(broker)
    try:
        asyncio.run(asyncio.wait_for(query_workers(address.host, address.port), timeout=0.75))
        return True
    except Exception:
        return False


def _normalize_raw_args(raw_args: list[str]) -> list[str]:
    if not raw_args:
        return raw_args

    command = raw_args[0]
    if command.endswith(":"):
        normalized = command[:-1]
        if normalized in {
            "check",
            "make",
            "new",
            "hello",
            "status",
            "find",
            "clean",
            "fix",
            "do",
            "scan",
            "health",
            "service",
            "http",
            "json",
            "csv",
            "image",
            "cron",
            "process",
            "archive",
            "hash",
            "time",
        }:
            return [normalized, *raw_args[1:]]

    return raw_args


if __name__ == "__main__":
    main()
