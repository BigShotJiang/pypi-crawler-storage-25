from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path


def ensure_binary(name: str) -> str:
    path = shutil.which(name)
    if path is None:
        raise RuntimeError(f"Required binary not found on PATH: {name}")
    return path


def run_passthrough(argv: list[str], cwd: str | None = None) -> int:
    if not argv:
        raise ValueError("Missing command arguments.")
    completed = subprocess.run(argv, cwd=cwd)
    return int(completed.returncode)


def command_exists(name: str) -> bool:
    return shutil.which(name) is not None


def npx_command() -> list[str]:
    if command_exists("npx"):
        return ["npx"]
    ensure_binary("npm")
    return ["npm", "exec", "--"]


def load_package_json(cwd: str | None = None) -> dict:
    path = Path(cwd or ".") / "package.json"
    if not path.exists():
        raise ValueError(f"No package.json found at {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def list_package_scripts(cwd: str | None = None) -> dict[str, str]:
    data = load_package_json(cwd)
    scripts = data.get("scripts", {})
    if not isinstance(scripts, dict):
        raise ValueError("package.json scripts must be an object.")
    return {str(key): str(value) for key, value in scripts.items()}


def scaffold_node_app(target: str, force: bool = False) -> Path:
    root = Path(target).resolve()
    if root.exists() and any(root.iterdir()) and not force:
        raise ValueError(f"Target directory {root} is not empty. Use --force to continue.")

    root.mkdir(parents=True, exist_ok=True)
    src = root / "src"
    src.mkdir(exist_ok=True)

    package_json = {
        "name": root.name,
        "version": "0.1.0",
        "private": True,
        "type": "module",
        "scripts": {
            "dev": "node --watch src/index.js",
            "start": "node src/index.js",
            "test": "node --test",
            "build": "node src/index.js build",
        },
    }
    (root / "package.json").write_text(json.dumps(package_json, indent=2) + "\n", encoding="utf-8")
    (root / "src" / "index.js").write_text(
        """const command = process.argv[2] ?? "start";

if (command === "build") {
  console.log("build pipeline placeholder");
  process.exit(0);
}

console.log("hello from lucore + node");
""",
        encoding="utf-8",
    )
    (root / "lucore.toml").write_text(
        f"""[project]
name = "{root.name}"

[tasks.dev]
description = "Run the local node dev loop."
run = "npm run dev -- {{args}}"
mode = "local"

[tasks.start]
description = "Start the app locally."
run = "npm run start -- {{args}}"
mode = "local"

[tasks.build]
description = "Run the build on distributed build workers."
run = "npm run build -- {{args}}"
mode = "distributed"
labels = {{ queue = "build" }}

[tasks.test]
description = "Run node tests on distributed test workers."
run = "npm test -- {{args}}"
mode = "distributed"
labels = {{ queue = "test" }}

[commands.node-version]
shell = "node --version"
mode = "local"
""",
        encoding="utf-8",
    )
    (root / "README.md").write_text(
        f"# {root.name}\n\nCreated by `lucore create app`.\n",
        encoding="utf-8",
    )
    return root


def scaffold_node_lib(target: str, force: bool = False) -> Path:
    root = Path(target).resolve()
    if root.exists() and any(root.iterdir()) and not force:
        raise ValueError(f"Target directory {root} is not empty. Use --force to continue.")

    root.mkdir(parents=True, exist_ok=True)
    src = root / "src"
    src.mkdir(exist_ok=True)
    (root / "package.json").write_text(
        json.dumps(
            {
                "name": root.name,
                "version": "0.1.0",
                "type": "module",
                "main": "./src/index.js",
                "exports": "./src/index.js",
                "scripts": {
                    "test": "node --test",
                    "build": "node -e \"console.log('build placeholder')\"",
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (src / "index.js").write_text(
        """export function hello(name = "world") {
  return `hello ${name}`;
}
""",
        encoding="utf-8",
    )
    return root


def scaffold_node_api(target: str, force: bool = False) -> Path:
    root = Path(target).resolve()
    if root.exists() and any(root.iterdir()) and not force:
        raise ValueError(f"Target directory {root} is not empty. Use --force to continue.")

    root.mkdir(parents=True, exist_ok=True)
    src = root / "src"
    src.mkdir(exist_ok=True)
    (root / "package.json").write_text(
        json.dumps(
            {
                "name": root.name,
                "version": "0.1.0",
                "private": True,
                "type": "module",
                "scripts": {
                    "dev": "node --watch src/server.js",
                    "start": "node src/server.js",
                    "test": "node --test",
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (src / "server.js").write_text(
        """import http from "node:http";

const port = Number(process.env.PORT || 3000);

const server = http.createServer((req, res) => {
  res.writeHead(200, { "content-type": "application/json" });
  res.end(JSON.stringify({ ok: true, url: req.url }));
});

server.listen(port, () => {
  console.log(`api listening on http://localhost:${port}`);
});
""",
        encoding="utf-8",
    )
    return root
