from __future__ import annotations

import asyncio
import contextlib
import time
from collections import deque
from dataclasses import dataclass, field

from .protocol import JsonLineReader, encode_message, labels_match, random_id

HEARTBEAT_TIMEOUT_SECONDS = 15
MAX_JOB_HISTORY = 500


@dataclass(slots=True)
class WorkerState:
    worker_id: str
    name: str
    labels: dict[str, str]
    writer: asyncio.StreamWriter
    platform: str = "unknown"
    busy: bool = False
    current_job_id: str | None = None
    last_heartbeat_at: float = field(default_factory=time.time)


@dataclass(slots=True)
class JobState:
    job_id: str
    command: str
    labels: dict[str, str]
    name: str | None = None
    client_writer: asyncio.StreamWriter | None = None
    detached: bool = False
    status: str = "queued"
    worker_id: str | None = None
    created_at: float = field(default_factory=time.time)
    started_at: float | None = None
    finished_at: float | None = None
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""

    def summary(self) -> dict:
        return {
            "jobId": self.job_id,
            "name": self.name,
            "command": self.command,
            "labels": self.labels,
            "status": self.status,
            "workerId": self.worker_id,
            "createdAt": self.created_at,
            "startedAt": self.started_at,
            "finishedAt": self.finished_at,
            "exitCode": self.exit_code,
            "detached": self.detached,
        }


class Broker:
    def __init__(self) -> None:
        self.workers: dict[str, WorkerState] = {}
        self.jobs: dict[str, JobState] = {}
        self.job_history: dict[str, JobState] = {}
        self.job_order: deque[str] = deque()
        self.queued_jobs: list[str] = []

    async def serve(self, host: str, port: int) -> None:
        server = await asyncio.start_server(self._handle_connection, host, port)
        print(f"lucore broker listening on {host}:{port}")

        async with server:
            monitor = asyncio.create_task(self._monitor_heartbeats())
            try:
                await server.serve_forever()
            finally:
                monitor.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await monitor

    async def _handle_connection(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        parser = JsonLineReader()
        connection_kind = "unknown"
        worker_id: str | None = None

        try:
            while not reader.at_eof():
                chunk = await reader.read(8192)
                if not chunk:
                    break

                for message in parser.feed(chunk):
                    message_type = message.get("type")

                    if message_type == "register_worker":
                        connection_kind = "worker"
                        worker_id = str(message["workerId"])
                        self.workers[worker_id] = WorkerState(
                            worker_id=worker_id,
                            name=str(message.get("name") or worker_id),
                            labels=dict(message.get("labels") or {}),
                            writer=writer,
                            platform=str(message.get("platform") or "unknown"),
                        )
                        await self._send(
                            writer, {"type": "worker_registered", "workerId": worker_id}
                        )
                        await self._schedule()
                        continue

                    if message_type == "heartbeat":
                        if worker_id and worker_id in self.workers:
                            self.workers[worker_id].last_heartbeat_at = time.time()
                        continue

                    if message_type == "submit_job":
                        connection_kind = "client"
                        job_id = random_id("job")
                        detached = bool(message.get("detach"))
                        job = JobState(
                            job_id=job_id,
                            command=str(message["command"]),
                            labels=dict(message.get("labels") or {}),
                            name=str(message.get("name") or "") or None,
                            client_writer=None if detached else writer,
                            detached=detached,
                        )
                        self.jobs[job_id] = job
                        self.queued_jobs.append(job_id)
                        await self._send(
                            writer,
                            {
                                "type": "job_queued",
                                "jobId": job_id,
                                "status": job.status,
                                "detached": detached,
                            },
                        )
                        await self._schedule()
                        if detached:
                            return
                        continue

                    if message_type == "job_result":
                        await self._finish_job(
                            worker_id=worker_id,
                            message=message,
                        )
                        await self._schedule()
                        continue

                    if message_type == "query_jobs":
                        limit = int(message.get("limit", 20))
                        await self._send(
                            writer,
                            {
                                "type": "jobs",
                                "jobs": self._recent_jobs(limit),
                            },
                        )
                        return

                    if message_type == "query_workers":
                        await self._send(
                            writer,
                            {
                                "type": "workers",
                                "workers": [self._worker_summary(worker) for worker in self.workers.values()],
                            },
                        )
                        return

                    if message_type == "query_job":
                        job = self._get_job(str(message["jobId"]))
                        if job is None:
                            await self._send(writer, {"type": "error", "error": "Unknown job id"})
                            return
                        await self._send(writer, {"type": "job", "job": job.summary()})
                        return

                    if message_type == "query_logs":
                        job = self._get_job(str(message["jobId"]))
                        if job is None:
                            await self._send(writer, {"type": "error", "error": "Unknown job id"})
                            return
                        await self._send(
                            writer,
                            {
                                "type": "logs",
                                "jobId": job.job_id,
                                "stdout": job.stdout,
                                "stderr": job.stderr,
                                "status": job.status,
                            },
                        )
                        return

                    await self._send(
                        writer,
                        {"type": "error", "error": f"Unknown message type: {message_type}"},
                    )
                    return
        finally:
            if connection_kind == "worker" and worker_id:
                await self._drop_worker(worker_id)
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()

    async def _finish_job(self, worker_id: str | None, message: dict) -> None:
        job_id = str(message["jobId"])
        job = self.jobs.get(job_id)
        if job is None:
            return

        job.exit_code = int(message.get("exitCode", 0))
        job.stdout = str(message.get("stdout", ""))
        job.stderr = str(message.get("stderr", ""))
        job.status = "succeeded" if job.exit_code == 0 else "failed"
        job.finished_at = time.time()

        if worker_id and worker_id in self.workers:
            worker = self.workers[worker_id]
            worker.busy = False
            worker.current_job_id = None

        if job.client_writer and not job.client_writer.is_closing():
            await self._send(
                job.client_writer,
                {
                    "type": "job_completed",
                    "jobId": job.job_id,
                    "workerId": worker_id,
                    "exitCode": job.exit_code,
                    "stdout": job.stdout,
                    "stderr": job.stderr,
                    "startedAt": message.get("startedAt"),
                    "finishedAt": message.get("finishedAt"),
                    "status": job.status,
                },
            )
            job.client_writer.close()
            with contextlib.suppress(Exception):
                await job.client_writer.wait_closed()

        self.jobs.pop(job.job_id, None)
        self.job_history[job.job_id] = job
        self.job_order.appendleft(job.job_id)
        while len(self.job_order) > MAX_JOB_HISTORY:
            removed = self.job_order.pop()
            self.job_history.pop(removed, None)

    async def _schedule(self) -> None:
        if not self.queued_jobs:
            return

        for worker in list(self.workers.values()):
            if worker.busy:
                continue

            matched_job_id = None
            for job_id in self.queued_jobs:
                job = self.jobs.get(job_id)
                if job and labels_match(worker.labels, job.labels):
                    matched_job_id = job_id
                    break

            if matched_job_id is None:
                continue

            self.queued_jobs.remove(matched_job_id)
            job = self.jobs.get(matched_job_id)
            if job is None:
                continue

            job.status = "running"
            job.worker_id = worker.worker_id
            job.started_at = time.time()
            worker.busy = True
            worker.current_job_id = job.job_id

            await self._send(
                worker.writer,
                {
                    "type": "run_job",
                    "jobId": job.job_id,
                    "command": job.command,
                },
            )

    async def _drop_worker(self, worker_id: str) -> None:
        worker = self.workers.pop(worker_id, None)
        if worker is None:
            return

        if worker.current_job_id and worker.current_job_id in self.jobs:
            job = self.jobs[worker.current_job_id]
            job.status = "queued"
            job.worker_id = None
            job.started_at = None
            self.queued_jobs.insert(0, job.job_id)

        await self._schedule()

    async def _monitor_heartbeats(self) -> None:
        while True:
            await asyncio.sleep(5)
            now = time.time()
            stale_workers = [
                worker_id
                for worker_id, worker in self.workers.items()
                if now - worker.last_heartbeat_at > HEARTBEAT_TIMEOUT_SECONDS
            ]
            for worker_id in stale_workers:
                await self._drop_worker(worker_id)

    def _recent_jobs(self, limit: int) -> list[dict]:
        live_jobs = sorted(self.jobs.values(), key=lambda job: job.created_at, reverse=True)
        history_jobs = [self.job_history[job_id] for job_id in self.job_order]
        all_jobs = [job.summary() for job in live_jobs] + [job.summary() for job in history_jobs]
        return all_jobs[:limit]

    def _get_job(self, job_id: str) -> JobState | None:
        return self.jobs.get(job_id) or self.job_history.get(job_id)

    def _worker_summary(self, worker: WorkerState) -> dict:
        return {
            "workerId": worker.worker_id,
            "name": worker.name,
            "labels": worker.labels,
            "platform": worker.platform,
            "busy": worker.busy,
            "currentJobId": worker.current_job_id,
            "lastHeartbeatAt": worker.last_heartbeat_at,
        }

    async def _send(self, writer: asyncio.StreamWriter, message: dict) -> None:
        writer.write(encode_message(message))
        await writer.drain()
