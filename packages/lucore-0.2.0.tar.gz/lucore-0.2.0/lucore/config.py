from __future__ import annotations

from pathlib import Path
import tomllib


def load_project_config(config_path: str | None = None) -> dict:
    path = Path(config_path or "lucore.toml")
    if not path.exists():
        return {"path": path, "project": {}, "tasks": {}, "commands": {}, "shortcuts": {}}

    data = tomllib.loads(path.read_text(encoding="utf-8"))
    project = data.get("project", {})
    tasks = _normalize_entries(data.get("tasks", {}), "tasks")
    commands = _normalize_entries(data.get("commands", {}), "commands")
    shortcuts = _normalize_shortcuts(data.get("shortcuts", {}))

    if not isinstance(project, dict):
        raise ValueError("lucore.toml [project] must be a table.")

    return {
        "path": path,
        "project": {str(key): value for key, value in project.items()},
        "tasks": tasks,
        "commands": commands,
        "shortcuts": shortcuts,
    }


def load_commands(config_path: str | None = None) -> dict[str, dict]:
    return load_project_config(config_path)["commands"]


def load_tasks(config_path: str | None = None) -> dict[str, dict]:
    return load_project_config(config_path)["tasks"]


def load_shortcuts(config_path: str | None = None) -> dict[str, dict]:
    return load_project_config(config_path)["shortcuts"]


def resolve_entry(
    collection: str,
    name: str,
    config_path: str | None = None,
) -> dict:
    config = load_project_config(config_path)
    entries = config[collection]
    if name not in entries:
        known = ", ".join(sorted(entries)) or "none"
        raise ValueError(f"Unknown {collection[:-1]} {name!r}. Known: {known}")
    return entries[name]


def _normalize_entries(raw_entries: object, section_name: str) -> dict[str, dict]:
    if not isinstance(raw_entries, dict):
        raise ValueError(f"lucore.toml [{section_name}] must be a table.")

    normalized: dict[str, dict] = {}
    for name, raw_value in raw_entries.items():
        if isinstance(raw_value, str):
            normalized[name] = _normalize_entry(name, {"shell": raw_value})
            continue

        if not isinstance(raw_value, dict):
            raise ValueError(f"Entry {name!r} in [{section_name}] must be a string or table.")

        normalized[name] = _normalize_entry(name, raw_value)

    return normalized


def _normalize_entry(name: str, raw_value: dict) -> dict:
    shell = raw_value.get("shell") or raw_value.get("run")
    if not isinstance(shell, str) or not shell.strip():
        raise ValueError(f"Entry {name!r} must define a non-empty shell command.")

    labels = raw_value.get("labels", {})
    if not isinstance(labels, dict):
        raise ValueError(f"Entry {name!r} labels must be a table.")

    description = raw_value.get("description", "")
    if description and not isinstance(description, str):
        raise ValueError(f"Entry {name!r} description must be a string.")

    mode = raw_value.get("mode", "auto")
    if mode not in {"auto", "local", "distributed"}:
        raise ValueError(f"Entry {name!r} mode must be auto, local, or distributed.")

    return {
        "shell": shell,
        "labels": {str(key): str(value) for key, value in labels.items()},
        "description": description,
        "mode": mode,
    }


def _normalize_shortcuts(raw_shortcuts: object) -> dict[str, dict]:
    if not isinstance(raw_shortcuts, dict):
        raise ValueError("lucore.toml [shortcuts] must be a table.")

    normalized: dict[str, dict] = {}
    for name, raw_value in raw_shortcuts.items():
        if isinstance(raw_value, str):
            normalized[name] = {"command": raw_value, "description": ""}
            continue
        if not isinstance(raw_value, dict):
            raise ValueError(f"Shortcut {name!r} must be a string or table.")
        command = raw_value.get("command")
        if not isinstance(command, str) or not command.strip():
            raise ValueError(f"Shortcut {name!r} must define a non-empty command.")
        description = raw_value.get("description", "")
        if description and not isinstance(description, str):
            raise ValueError(f"Shortcut {name!r} description must be a string.")
        normalized[name] = {"command": command, "description": description}

    return normalized
