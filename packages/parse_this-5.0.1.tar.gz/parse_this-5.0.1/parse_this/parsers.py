import logging
import typing
from argparse import ArgumentParser
from functools import wraps
from inspect import getfullargspec, unwrap
from typing import Callable, Dict, Optional, Type

from parse_this.args import _get_args_and_defaults, _get_args_to_parse
from parse_this.call import _call, _call_method_from_namespace, _get_parser_call_method
from parse_this.exception import ParseThisException
from parse_this.help.action import FullHelpAction
from parse_this.helpers import _add_log_level_argument
from parse_this.parsing import _get_arg_parser, _get_parseable_methods
from parse_this.type_check import _check_types

_LOG = logging.getLogger(__name__)


class SubcommandAwareArgumentParser(ArgumentParser):
    """An ArgumentParser subclass that, when unrecognized arguments are present
    after a subcommand has been selected, reports the error using the
    *subcommand's* parser rather than the top-level parser.

    This fixes the case where argparse accumulates unrecognized tokens through
    parse_known_args at the subparser level and then has the top-level parser
    call error(), showing the top-level usage instead of the subcommand's.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._subparsers_action = None

    def parse_args(self, args=None, namespace=None):
        namespace, remainder = self.parse_known_args(args, namespace)
        if remainder:
            # If a subcommand was selected and its parser is known, delegate
            # the error to that subparser so the subcommand's usage is shown.
            method = getattr(namespace, "method", None)
            if (
                self._subparsers_action is not None
                and method is not None
                and method in self._subparsers_action.choices
            ):
                subparser = self._subparsers_action.choices[method]
                subparser.error("unrecognized arguments: %s" % " ".join(remainder))
            self.error("unrecognized arguments: %s" % " ".join(remainder))
        return namespace


class FunctionParser(object):
    """Parse command line arguments, transform them to the appropriate type and
    delegate the call to a given callable.
    """

    def __call__(
        self,
        func: Callable,
        args: typing.List[str] = None,
        docstring_style: str = "auto",
        log_level: bool = False,
        version: Optional[str] = None,
    ):
        """Create an ArgParser for the given function converting the command line
           arguments and passing them to the function, return the result of the
           function call.

        Args:
            func: the function for which the command line arguments to be parsed
            args: a list of arguments to be parsed if None sys.argv is used
            docstring_style: which docstring style to parse for the parser
            description and per-argument help. One of ``"auto"`` (default,
            autodetect), ``"google"``, ``"numpy"``, ``"rest"``, ``"epytext"``.
            log_level: indicate whether or not a '--log-level' argument should be
            handled to set the log level during the execution
            version: optional version string to enable a '--version' flag.
            When provided, '--version' prints this string and exits.
        """
        _LOG.debug("Creating parser for %s", func.__name__)
        # Follow __wrapped__ so @create_parser can be stacked below decorators
        # that use functools.wraps around a *args/**kwargs wrapper.
        wrapped = unwrap(func)
        func_args, _, _, defaults, _, _, annotations = getfullargspec(wrapped)
        func_args = _check_types(func.__name__, annotations, func_args, defaults)
        args_and_defaults = _get_args_and_defaults(func_args, defaults)
        parser = _get_arg_parser(
            func, annotations, args_and_defaults, docstring_style, log_level
        )
        if version is not None:
            parser.add_argument("--version", action="version", version=version)
        self._set_function_parser(func, parser)
        arguments = parser.parse_args(_get_args_to_parse(args))
        return _call(func, func_args, arguments)

    @typing.no_type_check  # dynamically attaches .parser to callables
    def _set_function_parser(self, func: Callable, parser: ArgumentParser):
        func.parser = parser


class MethodParser(object):
    """Creates an argument parser for the decorated function.

    Note:
        The method '__init__' can not be decorated if the class is not
        decorated with 'parse_class'
    """

    _name: Optional[str]
    _docstring_style: str
    _log_level: bool

    def __init__(
        self,
        docstring_style: str = "auto",
        name: str = None,
        log_level: bool = False,
    ):
        """
        Args:
            docstring_style: which docstring style to parse for the parser
            description and per-argument help. One of ``"auto"`` (default,
            autodetect), ``"google"``, ``"numpy"``, ``"rest"``, ``"epytext"``.
            name: name that will be used for the parser when used in a class
            decorated with `parse_class`. If not provided the name of the method will
            be used
            log_level: indicate whether or not a '--log-level' argument should be
            handled to set the log level during the execution
        """
        self._docstring_style = docstring_style
        self._name = name
        self._log_level = log_level

    def __call__(self, func: Callable):
        """Add an argument parser attribute `parser` to the decorated function.

        Args:
            func: the function for which we want to create an argument parser
        """
        if not hasattr(func, "parser"):
            _LOG.debug(
                "Creating parser for '%s'%s",
                func.__name__,
                "/%s" % self._name if self._name else "",
            )
            # Follow __wrapped__ so @create_parser can be stacked below
            # decorators that use functools.wraps around a *args/**kwargs
            # wrapper.
            wrapped = unwrap(func)
            func_args, _, _, defaults, _, _, annotations = getfullargspec(wrapped)
            func_args = _check_types(func.__name__, annotations, func_args, defaults)
            args_and_defaults = _get_args_and_defaults(func_args, defaults)
            parser = _get_arg_parser(
                func,
                annotations,
                args_and_defaults,
                self._docstring_style,
                self._log_level,
            )
            parser.get_name = lambda: self._name or func.__name__  # type: ignore[attr-defined]
            self._set_method_parser(func, parser)

        @wraps(func)
        def decorated(*args, **kwargs):
            return func(*args, **kwargs)

        return decorated

    @typing.no_type_check  # dynamically attaches .parser to callables
    def _set_method_parser(self, func: Callable, parser: ArgumentParser):
        func.parser = parser
        func.parser.call = _get_parser_call_method(func)


class ClassParser(object):
    """Allows to create a global argument parser for a class along with
    subparsers with each if its properly decorated methods."""

    _parse_private: bool
    _description: Optional[str]
    _cls: Type = None
    _log_level: bool
    _version: Optional[str]

    def __init__(
        self,
        description: str = None,
        parse_private: bool = False,
        log_level: bool = False,
        version: Optional[str] = None,
    ):
        """

        Args:
            description: give a specific description for the top level parser,
            if not specified it will be the class docstring.
            parse_private: specifies whether or not 'private' methods should be
            parsed, defaults to False
            log_level: indicate whether or not a '--log-level' argument should be
            handled to set the log level during the execution
            version: optional version string to enable a '--version' flag on
            the top-level parser. When provided, '--version' prints this
            string and exits.
        """
        self._description = description
        self._parse_private = parse_private
        self._log_level = log_level
        self._version = version

    def __call__(self, cls: Type):
        """
        Args:
            cls: class to be decorated
        """
        _LOG.debug("Creating parser for class '%s'", cls.__name__)
        self._cls = cls
        init_parser, methods_to_parse = _get_parseable_methods(cls)
        self._set_class_parser(init_parser, methods_to_parse, cls)
        return cls

    def _add_sub_parsers(
        self,
        top_level_parser,
        methods_to_parse: Dict[str, ArgumentParser],
        class_name: str,
    ):
        """Add all the sub-parsers to the top_level_parser.

        Args:
            top_level_parser: the top level parser
            methods_to_parse: dict of method name pointing to their associated
            argument parser
            class_name: name of the decorated class

        Returns:
            a 2-tuple of (parser_to_method, sub_parsers) where parser_to_method
            is a dict of registered name of the parser i.e. sub command name
            pointing to the method real name, and sub_parsers is the subparsers
            action added to top_level_parser
        """
        description = f"Accessible methods of {class_name}"
        sub_parsers = top_level_parser.add_subparsers(
            description=description, dest="method"
        )
        # Holds the mapping between the name registered for the parser
        # and the method real name. It is useful in the 'inner_call'
        # method retrieve the real method
        parser_to_method = {}
        for method_name, parser in methods_to_parse.items():
            # We use the name provided in 'create_parser` or the name of the
            # decorated method
            parser_name = parser.get_name()  # type: ignore[attr-defined]
            # Make the method name compatible for the argument parsing
            if parser_name.startswith("_"):
                if not self._parse_private:
                    # We skip private methods if the caller asked not to
                    # parse them
                    continue
                # 'Private' methods are exposed without their leading or
                # trailing '_'s. Also works for 'special' methods.
                parser_name = parser_name.strip("_")
            parser_name = parser_name.replace("_", "-")
            parser_to_method[parser_name] = method_name
            sub_parsers.add_parser(
                parser_name,
                parents=[parser],
                add_help=False,
                description=parser.description,
            )
        return parser_to_method, sub_parsers

    def _set_class_parser(
        self,
        init_parser: ArgumentParser,
        methods_to_parse: Dict[str, ArgumentParser],
        cls: Type,
    ):
        """Creates the complete argument parser for the decorated class.

        Args:
            init_parser: argument parser for the __init__ method or None
            methods_to_parse: dict of method name pointing to their associated
            argument parser
            cls: the class we are decorating

        Returns:
            The decorated class with an added attribute 'parser'
        """
        top_level_parents = [init_parser] if init_parser else []
        description = self._description or cls.__doc__
        top_level_parser = SubcommandAwareArgumentParser(
            description=description,
            parents=top_level_parents,
            add_help=False,
            conflict_handler="resolve",
        )
        top_level_parser.add_argument(
            "-h", "--help", action=FullHelpAction, help="Display this help message"
        )
        if self._version is not None:
            top_level_parser.add_argument(
                "--version", action="version", version=self._version
            )
        if self._log_level:
            _add_log_level_argument(top_level_parser)
        parser_to_method, sub_parsers_action = self._add_sub_parsers(
            top_level_parser, methods_to_parse, cls.__name__
        )
        # Store the subparsers action so SubcommandAwareArgumentParser can
        # route unrecognized-argument errors to the correct subparser.
        top_level_parser._subparsers_action = sub_parsers_action
        # Update the dict with the __init__ method so we can instantiate
        # the decorated class
        if init_parser:
            parser_to_method["__init__"] = "__init__"
        self._set_parser_call_method(parser_to_method, top_level_parser)
        cls.parser = top_level_parser

    @typing.no_type_check  # dynamically attaches .parser and .call to objects
    def _set_parser_call_method(
        self, parser_to_method: Dict[str, str], top_level_parser: ArgumentParser
    ):
        top_level_parser.call = self._get_parser_call_method(parser_to_method)

    def _get_parser_call_method(self, parser_to_method: Dict[str, Callable]):
        """Return the parser special method 'call' that handles sub-command
            calling.

        Args:
            parser_to_method: mapping of the parser registered name
            to the method it is linked to
        """

        def inner_call(args=None, instance=None):
            """Allows to call the method invoked from the command line or
            provided argument.

            Args:
                args: list of arguments to parse, defaults to command line arguments
                instance: an instance of the decorated class. If instance is None,
                    the default, and __init__ is decorated the object will be
                    instantiated on the fly from the command line arguments
            """
            parser = self._cls.parser
            namespace = parser.parse_args(_get_args_to_parse(args))
            method_name = parser_to_method[namespace.method]
            if instance is None:
                if "__init__" in parser_to_method:
                    # Instantiate the class from the command line arguments
                    instance = _call_method_from_namespace(
                        self._cls, "__init__", namespace
                    )
                elif isinstance(
                    vars(self._cls).get(method_name), (classmethod, staticmethod)
                ):
                    # No decorated __init__. classmethods and staticmethods
                    # don't need an instance — dispatch on the class itself.
                    instance = self._cls
                else:
                    raise ParseThisException(
                        f"'__init__' method is not decorated. "
                        f"Please provide an instance to "
                        f"'{self._cls.__name__}.parser.call', decorate the "
                        f"'__init__' method with 'create_parser', or expose "
                        f"only 'classmethod'/'staticmethod' subcommands so "
                        f"no instance is required."
                    )
            return _call_method_from_namespace(instance, method_name, namespace)

        return inner_call
