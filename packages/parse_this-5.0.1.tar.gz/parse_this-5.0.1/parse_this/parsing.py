import enum
import logging
from argparse import ArgumentParser
from typing import Any, Callable, Dict, List, Optional, Tuple, Type, cast

from parse_this.args import _NO_DEFAULT
from parse_this.exception import ParseThisException
from parse_this.help.description import prepare_doc
from parse_this.helpers import (
    _add_log_level_argument,
    _get_element_type,
    _get_literal_values,
    _is_enum_type,
    _is_literal_type,
    _is_sequence_type,
    _make_enum_converter,
    _unwrap_optional,
)

_LOG = logging.getLogger(__name__)


def _get_parseable_methods(
    cls: type,
) -> Tuple[Optional[ArgumentParser], Dict[str, ArgumentParser]]:
    """Return all methods of cls that are parseable i.e. have been decorated
    by '@create_parser'.

    Args:
        cls: the class currently being decorated

    Returns:
        a 2-tuple with the parser of the __init__ method if any and a dict
        of the form {'method_name': associated_parser}

    Note:
        classmethods and staticmethods stacked on top of '@create_parser' are
        included. vars(cls) returns the classmethod/staticmethod descriptor
        (which is neither callable nor exposes .parser directly), so we
        unwrap via the descriptor's .__func__ attribute before the
        callable/has-parser check.
    """
    _LOG.debug("Retrieving parseable methods for '%s'", cls.__name__)
    init_parser = None
    methods_to_parse = {}
    for name, obj in vars(cls).items():
        # Unwrap classmethod/staticmethod descriptors to reach the underlying
        # function that carries the .parser attribute set by @create_parser.
        if isinstance(obj, (classmethod, staticmethod)):
            obj = obj.__func__
        # Every callable object that has a 'parser' attribute will be
        # added as a subparser.
        if callable(obj) and hasattr(obj, "parser"):
            _LOG.debug("Found method '%s'", name)
            if name == "__init__":
                # If we find the decorated __init__ method it will be
                # used as the top level parser
                init_parser = obj.parser
            else:
                methods_to_parse[obj.__name__] = obj.parser
    return init_parser, methods_to_parse


def _get_arg_parser(
    func: Callable,
    annotations: Dict[str, Callable],
    args_and_defaults: List[Tuple[str, Any]],
    docstring_style: str,
    log_level: bool = False,
) -> ArgumentParser:
    """Return an ArgumentParser for the given function. Arguments are defined
        from the function arguments and their associated defaults.

    Args:
        func: function for which we want an ArgumentParser
        annotations: is a dictionary mapping parameter names to annotations
        args_and_defaults: list of 2-tuples (arg_name, arg_default)
        docstring_style: docstring style hint passed to ``prepare_doc``
        ("auto", "google", "numpy", "rest", "epytext")
        log_level: indicate whether or not a '--log-level' argument should be
        handled to set the log level during the execution
    """
    _LOG.debug("Creating ArgumentParser for '%s'", func.__name__)
    description, arg_help = prepare_doc(
        func, [x for (x, _) in args_and_defaults], docstring_style
    )
    parser = ArgumentParser(description=description)
    if log_level:
        _add_log_level_argument(parser)
    for arg, default in args_and_defaults:
        help_msg = arg_help[arg]
        arg_type = annotations.get(arg)
        if default is _NO_DEFAULT:
            arg_type = arg_type or (lambda x: x)
            _add_required_argument(parser, func, arg, arg_type, help_msg)
        else:
            _add_optional_argument(parser, func, arg, arg_type, default, help_msg)
    return parser


def _validate_literal_values(func_name: str, arg: str, values: tuple) -> None:
    """Validate that all Literal values share the same type.

    The expected type is inferred from the first value in the tuple.

    Args:
        func_name: name of the function (for error messages)
        arg: the parameter name
        values: the tuple of Literal values

    Raises:
        ParseThisException: if Literal values have mixed types
    """
    expected_type = type(values[0])
    if not all(type(v) is expected_type for v in values):
        raise ParseThisException(
            f"Literal values for '{arg}' in '{func_name}' must all be the "
            f"same type, got mixed types: {values}"
        )


def _add_required_argument(
    parser: ArgumentParser,
    func: Callable,
    arg: str,
    arg_type: Any,
    help_msg: str,
) -> None:
    """Add a required (positional) argument to parser for a parameter with no default.

    Args:
        parser: the ArgumentParser to add the argument to
        func: the function being parsed (used for logging)
        arg: the parameter name
        arg_type: the resolved type for the argument
        help_msg: the help string for this argument
    """
    arg_type = _unwrap_optional(arg_type)
    if arg_type is bool:
        _LOG.debug("Adding optional flag %s.%s (default: True)", func.__name__, arg)
        parser.add_argument(
            "--%s" % arg,
            default=True,
            required=False,
            action="store_false",
            help="%s. Defaults to True if not specified" % help_msg,
        )
    elif _is_literal_type(arg_type):
        values = _get_literal_values(arg_type)
        _validate_literal_values(func.__name__, arg, values)
        literal_type = type(values[0])
        _LOG.debug(
            "Adding positional literal argument %s.%s: %s",
            func.__name__,
            arg,
            values,
        )
        parser.add_argument(arg, help=help_msg, type=literal_type, choices=values)
    elif _is_enum_type(arg_type):
        _LOG.debug(
            "Adding positional enum argument %s.%s: %s",
            func.__name__,
            arg,
            arg_type,
        )
        _enum_class = cast(Type[enum.Enum], arg_type)
        _names: List[str] = [e.name for e in _enum_class]
        parser.add_argument(
            arg,
            help=help_msg,
            type=_make_enum_converter(_enum_class),
            choices=list(_enum_class),
            metavar="{%s}" % ",".join(_names),
        )
    elif _is_sequence_type(arg_type):
        _LOG.debug(
            "Adding positional sequence argument %s.%s: %s",
            func.__name__,
            arg,
            arg_type,
        )
        element_type = _get_element_type(arg_type)
        parser.add_argument(arg, help=help_msg, type=element_type, nargs="+")
    else:
        _LOG.debug("Adding positional argument %s.%s: %s", func.__name__, arg, arg_type)
        parser.add_argument(arg, help=help_msg, type=arg_type)


def _add_optional_argument(
    parser: ArgumentParser,
    func: Callable,
    arg: str,
    arg_type: Any,
    default: Any,
    help_msg: str,
) -> None:
    """Add an optional argument to parser for a parameter that has a default value.

    Args:
        parser: the ArgumentParser to add the argument to
        func: the function being parsed (used for logging)
        arg: the parameter name
        arg_type: the resolved type for the argument
        default: the default value for this argument
        help_msg: the help string for this argument
    """
    arg_type = _unwrap_optional(arg_type)
    if default is None and arg_type is None:
        raise ParseThisException(
            f"parameter '{arg}' of '{func.__name__}' has default None but no "
            f"type annotation. Add an annotation, for example: "
            f"{arg}: int | None = None"
        )
    if _is_literal_type(arg_type):
        values = _get_literal_values(arg_type)
        _validate_literal_values(func.__name__, arg, values)
        literal_type = type(values[0])
        if default is not None and default not in values:
            raise ParseThisException(
                f"Default value {default!r} for '{arg}' in '{func.__name__}' "
                f"is not one of the allowed Literal values: {values}"
            )
        _LOG.debug(
            "Adding optional literal argument %s.%s: %s (default: %s)",
            func.__name__,
            arg,
            values,
            default,
        )
        parser.add_argument(
            "--%s" % arg,
            help=help_msg,
            default=default,
            type=literal_type,
            choices=values,
        )
        return
    arg_type = arg_type or type(default)
    if arg_type is bool:
        action = "store_false" if default else "store_true"
        _LOG.debug(
            "Adding optional flag %s.%s (default: %s)",
            func.__name__,
            arg,
            default,
        )
        parser.add_argument("--%s" % arg, help=help_msg, default=default, action=action)
    elif _is_enum_type(arg_type):
        _LOG.debug(
            "Adding optional enum argument %s.%s: %s (default: %s)",
            func.__name__,
            arg,
            arg_type,
            default,
        )
        _enum_class = cast(Type[enum.Enum], arg_type)
        _names = [e.name for e in _enum_class]
        parser.add_argument(
            "--%s" % arg,
            help=help_msg,
            default=default,
            type=_make_enum_converter(_enum_class),
            choices=list(_enum_class),
            metavar="{%s}" % ",".join(_names),
        )
    elif _is_sequence_type(arg_type):
        _LOG.debug(
            "Adding optional sequence argument %s.%s: %s (default: %s)",
            func.__name__,
            arg,
            arg_type,
            default,
        )
        element_type = _get_element_type(arg_type)
        parser.add_argument(
            "--%s" % arg, help=help_msg, default=default, type=element_type, nargs="+"
        )
    else:
        _LOG.debug(
            "Adding optional argument %s.%s: %s (default: %s)",
            func.__name__,
            arg,
            arg_type,
            default,
        )
        parser.add_argument("--%s" % arg, help=help_msg, default=default, type=arg_type)
