"""
NTLabs Email Branding - Unified email template for all products.

Provides `build_email()` which wraps any HTML body content in the
standard Neural Thinkers LAB email template with:
- Optional hero banner
- Dark header with product title and accent color
- Content area
- Legal footer (CNPJ, LGPD, Privacy, Terms)

Usage:
    from ntlabs.email.templates.branding import build_email

    html = build_email(
        title="Sistema Hipocrates",
        body="<p>Your appointment is confirmed.</p>",
        accent="#6366f1",
    )

All products (Hipocrates, Mercurius, Polis, Argos, Agora) should use
this function to maintain consistent visual identity.
"""

import random

COMPANY_NAME = "Neural Thinker - AI Engineering LTDA"
COMPANY_CNPJ = "62.155.930/0001-71"
DPO_EMAIL = "dpo@ntlabs.dev"
SITE_URL = "https://www.ntlabs.dev"

# Product registry: name → (accent, from_email, display_name)
PRODUCTS = {
    "neural-lab": ("#16a34a", "noreply@ntlabs.dev", "Neural LAB"),
    "hipocrates": ("#6366f1", "hipocrates@ntlabs.dev", "Sistema Hipocrates"),
    "mercurius": ("#8b5cf6", "mercurius@ntlabs.dev", "Sistema Mercurius"),
    "polis": ("#f59e0b", "polis@ntlabs.dev", "Sistema Polis"),
    "argos": ("#ef4444", "argos@ntlabs.dev", "Sistema Argos"),
    "agora": ("#10b981", "agora@ntlabs.dev", "Sistema Agora"),
    "cidadao": ("#0284c7", "cidadao@ntlabs.dev", "Cidadao.AI"),
}


def get_product_config(product: str) -> dict:
    """Get product branding config.

    Returns:
        Dict with keys: accent, from_email, display_name.
    """
    accent, from_email, display_name = PRODUCTS.get(
        product, ("#10b981", "noreply@ntlabs.dev", "Neural Thinkers LAB")
    )
    return {
        "accent": accent,
        "from_email": from_email,
        "display_name": display_name,
    }


def _footer_html(accent: str) -> str:
    """Standard email footer with legal links, copyright, and confidentiality."""
    return f"""
      <tr>
        <td style="background-color:#111827;padding:24px 32px;border-top:2px solid {accent};">
          <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
            <tr>
              <td>
                <p style="margin:0 0 4px;font-size:14px;font-weight:700;font-family:'Courier New',monospace;color:#ffffff;letter-spacing:1px;">NEURAL THINKERS LAB</p>
                <p style="margin:0;font-size:11px;color:#9ca3af;">AI Solutions Platform &mdash; ntlabs.dev</p>
              </td>
              <td align="right" valign="top">
                <a href="{SITE_URL}" style="display:inline-block;padding:6px 14px;border:1px solid #374151;font-size:11px;color:#9ca3af;text-decoration:none;font-family:'Courier New',monospace;">SITE</a>
              </td>
            </tr>
          </table>
          <p style="margin:16px 0 0;font-size:10px;color:#9ca3af;">
            {COMPANY_NAME} | CNPJ: {COMPANY_CNPJ}
          </p>
          <p style="margin:10px 0 0;font-size:11px;color:#9ca3af;">
            <a href="{SITE_URL}/docs/neural-lab/privacy" style="color:#9ca3af;text-decoration:underline;">Privacy Policy</a>
            &nbsp;&middot;&nbsp;
            <a href="{SITE_URL}/docs/neural-lab/terms" style="color:#9ca3af;text-decoration:underline;">Terms of Service</a>
            &nbsp;&middot;&nbsp;
            <a href="{SITE_URL}/lab/privacidade" style="color:#9ca3af;text-decoration:underline;">LGPD</a>
          </p>
          <p style="margin:10px 0 0;font-size:10px;color:#9ca3af;">
            &copy; 2026 {COMPANY_NAME}. All rights reserved.
          </p>
          <p style="margin:6px 0 0;font-size:10px;color:#6b7280;">
            This message contains confidential information intended solely for the recipient(s). If you received this in error, please delete it immediately.
          </p>
        </td>
      </tr>"""


# ─── Banner registry ──────────────────────────────────────────────────────────
_CDN = "https://fisqbazfulmkxvrwjeuh.supabase.co/storage/v1/object/public/email-assets/welcome"

# Public banner URLs (Supabase Storage public bucket)
BANNERS = [
    f"{_CDN}/banner-agora-slide-01.jpg",
    f"{_CDN}/banner-agora-slide-02.jpg",
    f"{_CDN}/banner-agora-slide-03.jpg",
    f"{_CDN}/banner-agora-slide-04.jpg",
    f"{_CDN}/banner-agora-slide-05.jpg",
    f"{_CDN}/banner-agora-slide-06.jpg",
    f"{_CDN}/banner-cidadao-slide-06.jpg",
]


def get_random_banner(accent: str = "#10b981") -> str:
    """Pick a random banner from the registry.

    Returns HTML img tag, or empty string if no banners available.
    """
    if not BANNERS:
        return ""
    return _banner_img(random.choice(BANNERS), accent)


def _banner_img(url: str, accent: str) -> str:
    """Generate banner img HTML."""
    return (
        f'<img src="{url}" alt="" width="600" height="150" '
        f'style="display:block;width:100%;max-width:600px;height:150px;'
        f'object-fit:cover;background-color:{accent};" />'
    )


def build_email(
    *,
    title: str,
    body: str,
    accent: str = "#10b981",
    banner_url: str = "",
    auto_banner: bool = True,
    lang: str = "pt-BR",
) -> str:
    """Build a complete NTLabs-branded email HTML.

    Args:
        title: Header subtitle shown below "NEURAL THINKERS LAB"
               (e.g. "Sistema Hipocrates", "Receita Digital").
        body: Inner HTML content.
        accent: Hex color for accents (border, links).
        banner_url: Explicit banner image URL (overrides auto_banner).
        auto_banner: If True, fetch a random banner from Supabase Storage.
        lang: HTML lang attribute.

    Returns:
        Complete HTML email string with NTLabs branding.
    """
    banner_row = ""
    if banner_url:
        banner_row = f"<tr><td>{_banner_img(banner_url, accent)}</td></tr>"
    elif auto_banner:
        banner_html = get_random_banner(accent)
        if banner_html:
            banner_row = f"<tr><td>{banner_html}</td></tr>"

    return f"""<!DOCTYPE html>
<html lang="{lang}">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background-color:#f3f4f6;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;-webkit-font-smoothing:antialiased;">
<table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color:#f3f4f6;">
  <tr><td style="padding:32px 16px;">
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="600" style="margin:0 auto;background-color:#ffffff;border:2px solid #e5e7eb;">
      {banner_row}
      <!-- Header -->
      <tr>
        <td style="background-color:#111827;padding:24px 32px;border-left:4px solid {accent};">
          <h1 style="margin:0;color:#ffffff;font-size:20px;font-weight:700;font-family:'Courier New',monospace;letter-spacing:1px;">NEURAL THINKERS LAB</h1>
          <p style="margin:6px 0 0;color:{accent};font-size:12px;font-weight:600;font-family:'Courier New',monospace;text-transform:uppercase;letter-spacing:2px;">{title}</p>
        </td>
      </tr>
      <!-- Body -->
      <tr>
        <td style="padding:32px;">
          {body}
        </td>
      </tr>
      <!-- Footer -->
      {_footer_html(accent)}
    </table>
  </td></tr>
</table>
</body>
</html>"""
