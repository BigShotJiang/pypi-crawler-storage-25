"""
Email template rendering and branding.
"""

from .branding import PRODUCTS, build_email, get_product_config, get_random_banner
from .renderer import TemplateRenderer, get_builtin_templates

__all__ = [
    "TemplateRenderer",
    "get_builtin_templates",
    "build_email",
    "get_product_config",
    "PRODUCTS",
    "get_random_banner",
]
