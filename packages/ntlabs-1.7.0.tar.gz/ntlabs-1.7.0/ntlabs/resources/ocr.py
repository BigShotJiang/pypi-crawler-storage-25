"""
Neural LAB - AI Solutions Platform
OCR Resource - Optical Character Recognition via Tesseract.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
Created: 2026-02-02
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO

from ..base import DataclassMixin


@dataclass
class OCRResult(DataclassMixin):
    """OCR extraction result."""

    text: str
    raw_text: str
    confidence: float
    word_count: int
    line_count: int
    language: str
    latency_ms: int
    cost_brl: float


@dataclass
class OCRLanguage(DataclassMixin):
    """Available OCR language."""

    code: str
    name: str
    available: bool


class OCRResource:
    """
    OCR resource for text extraction from images via Tesseract.

    Usage:
        # From file path
        result = client.ocr.extract("/path/to/image.png")
        print(result.text)

        # From bytes
        with open("document.jpg", "rb") as f:
            result = client.ocr.extract(f)

        # List available languages
        languages = client.ocr.get_languages()
    """

    def __init__(self, client):
        self._client = client

    def extract(
        self,
        file: str | Path | BinaryIO | bytes,
        language: str = "por+eng",
        preprocess: bool = True,
    ) -> OCRResult:
        """
        Extract text from an image using OCR.

        Args:
            file: Image file (path, file object, or bytes)
            language: OCR language code (por, eng, por+eng, etc.)
            preprocess: Preprocess image for better results

        Returns:
            OCRResult with extracted text and confidence
        """
        # Prepare file
        if isinstance(file, (str, Path)):
            file_path = Path(file)
            file_obj = open(file_path, "rb")
            filename = file_path.name
            close_file = True
        elif isinstance(file, bytes):
            import io

            file_obj = io.BytesIO(file)
            filename = "image.png"
            close_file = True
        else:
            file_obj = file
            filename = getattr(file, "name", "image.png")
            close_file = False

        try:
            # Prepare form data
            files = {"file": (filename, file_obj)}
            data = {
                "language": language,
                "preprocess": str(preprocess).lower(),
            }

            response = self._client.post(
                "/v1/ocr/extract",
                files=files,
                data=data,
            )

            return OCRResult(
                text=response.get("text", ""),
                raw_text=response.get("raw_text", ""),
                confidence=response.get("confidence", 0),
                word_count=response.get("word_count", 0),
                line_count=response.get("line_count", 0),
                language=response.get("language", language),
                latency_ms=response.get("latency_ms", 0),
                cost_brl=response.get("cost_brl", 0),
            )

        finally:
            if close_file:
                file_obj.close()

    def get_languages(self) -> list[OCRLanguage]:
        """
        Get available OCR languages.

        Returns:
            List of available languages
        """
        response = self._client.get("/v1/ocr/languages")

        return [
            OCRLanguage(
                code=lang.get("code", ""),
                name=lang.get("name", ""),
                available=lang.get("available", False),
            )
            for lang in response.get("languages", [])
        ]

    def health(self) -> dict[str, Any]:
        """
        Check OCR service health.

        Returns:
            Health status
        """
        return self._client.get("/v1/ocr/health")
