"""
Neural LAB SDK - Async Storage Resource
File storage operations via Supabase Storage.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
"""

import base64
from typing import Any

from .storage import (
    StorageDeleteResult,
    StorageDownloadResult,
    StorageFile,
    StorageListResult,
    StorageUploadResult,
    StorageURLResult,
)


class AsyncStorageResource:
    """
    Async storage resource for file operations.

    Provides unified access to Supabase Storage with signed URLs,
    upload/download, and billing integration.

    Example:
        >>> from ntlabs import AsyncNTLClient
        >>> async with AsyncNTLClient(api_key="ntl_xxx") as client:
        ...     # Upload a file
        ...     with open("document.pdf", "rb") as f:
        ...         result = await client.storage.upload(
        ...             path="docs/document.pdf",
        ...             data=f.read(),
        ...             content_type="application/pdf"
        ...         )
        ...     print(result.public_url)
        ...
        ...     # Get signed URL for private file
        ...     url_result = await client.storage.get_signed_url("private/secret.pdf")
        ...     print(url_result.url)
    """

    DEFAULT_BUCKET = "gateway-storage"

    def __init__(self, client: Any):
        """Initialize storage resource.

        Args:
            client: The AsyncNTLClient instance
        """
        self._client = client

    async def upload(
        self,
        path: str,
        data: bytes,
        content_type: str = "application/octet-stream",
        bucket: str = None,
        upsert: bool = False,
    ) -> StorageUploadResult:
        """
        Upload a file to storage.

        Args:
            path: Full path including filename (e.g., 'uploads/user123/doc.pdf')
            data: File content as bytes
            content_type: MIME type of the file
            bucket: Storage bucket name (default: gateway-storage)
            upsert: Overwrite if file exists

        Returns:
            StorageUploadResult with file details and optional public URL
        """
        bucket = bucket or self.DEFAULT_BUCKET

        # Encode data as base64
        content_base64 = base64.b64encode(data).decode("utf-8")

        response = await self._client.post(
            "/v1/storage/upload",
            json={
                "bucket": bucket,
                "path": path,
                "content_base64": content_base64,
                "content_type": content_type,
                "upsert": upsert,
            },
        )

        if not response.get("success"):
            return StorageUploadResult(
                success=False,
                error=response.get("detail", "Upload failed"),
            )

        return StorageUploadResult(
            success=True,
            id=response.get("id", ""),
            path=response.get("path", path),
            bucket=response.get("bucket", bucket),
            size_bytes=response.get("size_bytes", len(data)),
            content_type=response.get("content_type", content_type),
            public_url=response.get("public_url"),
            created_at=response.get("created_at"),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    async def get_signed_url(
        self,
        path: str,
        bucket: str = None,
        expires_in: int = 3600,
    ) -> StorageURLResult:
        """
        Generate a signed URL for a file.

        Signed URLs provide temporary access to private files.

        Args:
            path: File path in storage
            bucket: Storage bucket name
            expires_in: URL expiration in seconds (1 min to 7 days, default: 1 hour)

        Returns:
            StorageURLResult with the signed URL
        """
        bucket = bucket or self.DEFAULT_BUCKET

        response = await self._client.get(
            f"/v1/storage/url/{path}",
            params={
                "bucket": bucket,
                "expires_in": expires_in,
            },
        )

        if not response.get("success"):
            return StorageURLResult(
                success=False,
                error=response.get("detail", "Failed to generate URL"),
            )

        return StorageURLResult(
            success=True,
            url=response.get("url", ""),
            path=response.get("path", path),
            bucket=response.get("bucket", bucket),
            expires_in=response.get("expires_in", expires_in),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    async def download(
        self,
        path: str,
        bucket: str = None,
    ) -> StorageDownloadResult:
        """
        Download a file from storage.

        Args:
            path: File path in storage
            bucket: Storage bucket name

        Returns:
            StorageDownloadResult with file content as bytes
        """
        bucket = bucket or self.DEFAULT_BUCKET

        response = await self._client.get(
            f"/v1/storage/download/{path}",
            params={"bucket": bucket},
        )

        if not response.get("success"):
            return StorageDownloadResult(
                success=False,
                error=response.get("detail", "Download failed"),
            )

        # Decode base64 content
        content_base64 = response.get("content_base64", "")
        try:
            data = base64.b64decode(content_base64)
        except Exception:
            data = b""

        return StorageDownloadResult(
            success=True,
            path=response.get("path", path),
            bucket=response.get("bucket", bucket),
            data=data,
            data_base64=content_base64,
            content_type=response.get("content_type", "application/octet-stream"),
            size_bytes=response.get("size_bytes", len(data)),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    async def list(
        self,
        path: str = "",
        bucket: str = None,
        limit: int = 100,
        offset: int = 0,
    ) -> StorageListResult:
        """
        List files in a directory.

        Args:
            path: Directory path to list (empty for root)
            bucket: Storage bucket name
            limit: Maximum files to return (1-1000)
            offset: Offset for pagination

        Returns:
            StorageListResult with list of files
        """
        bucket = bucket or self.DEFAULT_BUCKET

        response = await self._client.get(
            "/v1/storage/list",
            params={
                "path": path,
                "bucket": bucket,
                "limit": limit,
                "offset": offset,
            },
        )

        if not response.get("success"):
            return StorageListResult(
                success=False,
                error=response.get("detail", "List failed"),
            )

        files = []
        for f in response.get("files", []):
            files.append(
                StorageFile(
                    id=f.get("id", ""),
                    name=f.get("name", ""),
                    path=f.get("path", ""),
                    bucket=bucket,
                    size_bytes=f.get("size_bytes"),
                    content_type=f.get("content_type"),
                    created_at=f.get("created_at"),
                    updated_at=f.get("updated_at"),
                )
            )

        return StorageListResult(
            success=True,
            files=files,
            total_count=response.get("total_count", len(files)),
            path=response.get("path", path),
            bucket=response.get("bucket", bucket),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    async def delete(
        self,
        path: str,
        bucket: str = None,
    ) -> StorageDeleteResult:
        """
        Delete a file from storage.

        Args:
            path: File path to delete
            bucket: Storage bucket name

        Returns:
            StorageDeleteResult with deletion status
        """
        bucket = bucket or self.DEFAULT_BUCKET

        response = await self._client.request(
            "DELETE",
            f"/v1/storage/{path}",
            params={"bucket": bucket},
        )

        if not response.get("success"):
            return StorageDeleteResult(
                success=False,
                error=response.get("detail", "Delete failed"),
            )

        return StorageDeleteResult(
            success=True,
            path=response.get("path", path),
            bucket=response.get("bucket", bucket),
            deleted_count=response.get("deleted_count", 1),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    async def health(self) -> dict:
        """
        Check storage service health.

        Returns:
            Health status dictionary
        """
        return await self._client.get("/v1/storage/health")
