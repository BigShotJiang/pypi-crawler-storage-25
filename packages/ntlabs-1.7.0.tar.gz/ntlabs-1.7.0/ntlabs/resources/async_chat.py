"""
Neural LAB - AI Solutions Platform
Async Chat Resource - LLM completions.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
Created: 2026-01-25
"""

import logging
from collections.abc import AsyncIterator

from ..exceptions import APIError
from .chat import ChatCompletion, StreamEvent, _parse_sse_line

logger = logging.getLogger(__name__)


class AsyncChatResource:
    """
    Async chat completions resource.

    Usage:
        async with AsyncNTLClient(api_key="ntl_xxx") as client:
            response = await client.chat.complete(
                messages=[{"role": "user", "content": "Ola!"}],
                model="maritaca-sabia-4"
            )
            print(response.content)
    """

    def __init__(self, client):
        self._client = client

    async def complete(
        self,
        messages: list[dict[str, str]],
        model: str = "maritaca-sabia-4",
        max_tokens: int = 1024,
        temperature: float = 0.7,
        system: str | None = None,
        **kwargs,
    ) -> ChatCompletion:
        """
        Create a chat completion.

        Args:
            messages: List of messages [{"role": "user", "content": "..."}]
            model: Model to use (maritaca-sabia-4, claude-sonnet, claude-opus)
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0-1)
            system: System prompt (optional)
            **kwargs: Additional parameters

        Returns:
            ChatCompletion with response
        """
        if system:
            messages = [{"role": "system", "content": system}] + messages

        response = await self._client.post(
            "/v1/llm/completions",
            json={
                "messages": messages,
                "model": model,
                "max_tokens": max_tokens,
                "temperature": temperature,
                **kwargs,
            },
        )

        return ChatCompletion(
            id=response.get("id", ""),
            content=response.get("choices", [{}])[0]
            .get("message", {})
            .get("content", ""),
            model=response.get("model", model),
            usage=response.get("usage", {}),
            finish_reason=response.get("choices", [{}])[0].get("finish_reason", "stop"),
        )

    async def complete_stream(
        self,
        messages: list[dict[str, str]],
        model: str = "maritaca-sabia-4",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        agent: str = "dedalo",
        locale: str = "pt",
        session_id: str | None = None,
        user_id: str | None = None,
        **kwargs,
    ) -> AsyncIterator[str]:
        """
        Create a streaming chat completion via SSE.

        Connects to the /api/chat/stream endpoint and yields content
        chunks as they arrive from the server.

        Args:
            messages: List of messages [{"role": "user", "content": "..."}]
            model: Model to use
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0-1)
            agent: Agent ID (dedalo, chiron, themis, hermes, athena)
            locale: Language code (pt, en, es)
            session_id: Optional session ID for context persistence
            user_id: Optional user ID for personalization
            **kwargs: Additional parameters

        Yields:
            Content text chunks as they arrive from the stream
        """
        import httpx

        client = self._client._get_client()

        payload = {
            "messages": [
                {"role": m["role"], "content": m["content"]} for m in messages
            ],
            "agent": agent,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "locale": locale,
            "stream": True,
        }
        if session_id:
            payload["session_id"] = session_id
        if user_id:
            payload["user_id"] = user_id

        try:
            async with client.stream(
                "POST",
                "/api/chat/stream",
                json=payload,
            ) as response:
                if response.status_code >= 400:
                    await response.aread()
                    raise APIError(
                        f"Stream request failed: {response.status_code}",
                        status_code=response.status_code,
                    )

                async for line in response.aiter_lines():
                    event = _parse_sse_line(line)
                    if event is None:
                        continue

                    if event.type == "error":
                        raise APIError(event.error or "Unknown streaming error")

                    if event.type == "token" and event.content:
                        yield event.content

                    if event.type == "end":
                        break

        except httpx.TimeoutException as e:
            raise APIError(f"Stream request timeout: {e}") from e
        except httpx.RequestError as e:
            raise APIError(f"Stream request failed: {e}") from e

    async def complete_stream_events(
        self,
        messages: list[dict[str, str]],
        model: str = "maritaca-sabia-4",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        agent: str = "dedalo",
        locale: str = "pt",
        session_id: str | None = None,
        user_id: str | None = None,
        **kwargs,
    ) -> AsyncIterator[StreamEvent]:
        """
        Create a streaming chat completion via SSE, yielding full events.

        Unlike complete_stream() which yields only content strings, this
        method yields StreamEvent objects including start, token, end, and
        error events with all metadata.

        Args:
            messages: List of messages [{"role": "user", "content": "..."}]
            model: Model to use
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0-1)
            agent: Agent ID (dedalo, chiron, themis, hermes, athena)
            locale: Language code (pt, en, es)
            session_id: Optional session ID for context persistence
            user_id: Optional user ID for personalization
            **kwargs: Additional parameters

        Yields:
            StreamEvent objects for each SSE event
        """
        import httpx

        client = self._client._get_client()

        payload = {
            "messages": [
                {"role": m["role"], "content": m["content"]} for m in messages
            ],
            "agent": agent,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "locale": locale,
            "stream": True,
        }
        if session_id:
            payload["session_id"] = session_id
        if user_id:
            payload["user_id"] = user_id

        try:
            async with client.stream(
                "POST",
                "/api/chat/stream",
                json=payload,
            ) as response:
                if response.status_code >= 400:
                    await response.aread()
                    raise APIError(
                        f"Stream request failed: {response.status_code}",
                        status_code=response.status_code,
                    )

                async for line in response.aiter_lines():
                    event = _parse_sse_line(line)
                    if event is None:
                        continue

                    yield event

                    if event.type in ("end", "error"):
                        break

        except httpx.TimeoutException as e:
            raise APIError(f"Stream request timeout: {e}") from e
        except httpx.RequestError as e:
            raise APIError(f"Stream request failed: {e}") from e
