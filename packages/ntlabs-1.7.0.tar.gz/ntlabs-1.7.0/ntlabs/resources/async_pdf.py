"""
Neural LAB - AI Solutions Platform
Async PDF Resource - PDF generation via ReportLab.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
Created: 2026-02-02
"""

import base64
from typing import Any, Literal

from .pdf import PDFDocument, PDFSection, PDFTemplate, PDFTheme


class AsyncPDFResource:
    """
    Async PDF resource for PDF generation via ReportLab.

    Usage:
        async with AsyncNTLClient(api_key="ntl_xxx") as client:
            # Generate a report
            pdf = await client.pdf.generate_report(
                title="Monthly Report",
                author="Anderson",
                summary=[("Total", 100), ("Active", 80)],
            )
            with open("report.pdf", "wb") as f:
                f.write(pdf.data)

            # Generate an invoice
            pdf = await client.pdf.generate_invoice(
                invoice_number="INV-001",
                customer_name="John Doe",
                items=[{"description": "Service A", "quantity": 1, "unit_price": 100, "total": 100}],
                total=100.0,
            )
    """

    def __init__(self, client):
        self._client = client

    async def generate(
        self,
        title: str,
        template: Literal[
            "report", "invoice", "certificate", "receipt", "custom"
        ] = "report",
        subtitle: str | None = None,
        author: str | None = None,
        sections: list[PDFSection] | None = None,
        page_size: Literal["a4", "letter"] = "a4",
        theme: PDFTheme | None = None,
        footer_text: str | None = None,
        output_format: Literal["base64", "binary"] = "base64",
    ) -> PDFDocument:
        """
        Generate a PDF document.

        Args:
            title: Document title
            template: Template type (report, invoice, certificate, receipt, custom)
            subtitle: Document subtitle
            author: Author name
            sections: List of PDFSection objects
            page_size: Page size (a4 or letter)
            theme: Custom theme configuration
            footer_text: Custom footer text
            output_format: Output format (base64 or binary)

        Returns:
            PDFDocument with PDF data
        """
        # Convert sections to dict format
        sections_data = []
        if sections:
            for section in sections:
                sections_data.append(
                    {
                        "title": section.title,
                        "content": section.content,
                        "table_headers": section.table_headers,
                        "table_rows": section.table_rows,
                        "summary_items": section.summary_items,
                    }
                )

        # Convert theme to dict
        theme_data = None
        if theme:
            theme_data = {
                "primary_color": theme.primary_color,
                "secondary_color": theme.secondary_color,
                "company_name": theme.company_name,
                "company_subtitle": theme.company_subtitle,
            }

        response = await self._client.post(
            "/v1/pdf/generate",
            json={
                "template": template,
                "title": title,
                "subtitle": subtitle,
                "author": author,
                "sections": sections_data,
                "page_size": page_size,
                "theme": theme_data,
                "footer_text": footer_text,
                "output_format": output_format,
            },
        )

        # Decode base64 to bytes
        pdf_bytes = None
        if response.get("data"):
            pdf_bytes = base64.b64decode(response["data"])

        return PDFDocument(
            success=response.get("success", False),
            data=pdf_bytes,
            data_base64=response.get("data"),
            pages=response.get("pages", 0),
            size_bytes=response.get("size_bytes", 0),
            cost_brl=response.get("cost_brl", 0.0),
            latency_ms=response.get("latency_ms", 0),
        )

    async def generate_report(
        self,
        title: str,
        author: str | None = None,
        summary: list[tuple[str, Any]] | None = None,
        sections: list[dict] | None = None,
        footer_text: str | None = None,
        output_format: Literal["base64", "binary"] = "base64",
    ) -> PDFDocument:
        """
        Generate a report PDF.

        Args:
            title: Report title
            author: Author name
            summary: Summary statistics [(label, value), ...]
            sections: List of section dicts with title, content, table_headers, table_rows
            footer_text: Custom footer text
            output_format: Output format

        Returns:
            PDFDocument with PDF data
        """
        response = await self._client.post(
            "/v1/pdf/report",
            json={
                "title": title,
                "author": author,
                "summary": summary,
                "sections": sections,
                "footer_text": footer_text,
                "output_format": output_format,
            },
        )

        pdf_bytes = None
        if response.get("data"):
            pdf_bytes = base64.b64decode(response["data"])

        return PDFDocument(
            success=response.get("success", False),
            data=pdf_bytes,
            data_base64=response.get("data"),
            pages=response.get("pages", 0),
            size_bytes=response.get("size_bytes", 0),
            cost_brl=response.get("cost_brl", 0.0),
            latency_ms=response.get("latency_ms", 0),
        )

    async def generate_invoice(
        self,
        invoice_number: str,
        customer_name: str,
        items: list[dict],
        total: float,
        currency: str = "BRL",
        due_date: str | None = None,
        notes: str | None = None,
        output_format: Literal["base64", "binary"] = "base64",
    ) -> PDFDocument:
        """
        Generate an invoice PDF.

        Args:
            invoice_number: Invoice number/ID
            customer_name: Customer name
            items: List of items [{description, quantity, unit_price, total}, ...]
            total: Total amount
            currency: Currency code
            due_date: Payment due date (ISO format)
            notes: Additional notes
            output_format: Output format

        Returns:
            PDFDocument with PDF data
        """
        response = await self._client.post(
            "/v1/pdf/invoice",
            json={
                "invoice_number": invoice_number,
                "customer_name": customer_name,
                "items": items,
                "total": total,
                "currency": currency,
                "due_date": due_date,
                "notes": notes,
                "output_format": output_format,
            },
        )

        pdf_bytes = None
        if response.get("data"):
            pdf_bytes = base64.b64decode(response["data"])

        return PDFDocument(
            success=response.get("success", False),
            data=pdf_bytes,
            data_base64=response.get("data"),
            pages=response.get("pages", 0),
            size_bytes=response.get("size_bytes", 0),
            cost_brl=response.get("cost_brl", 0.0),
            latency_ms=response.get("latency_ms", 0),
        )

    async def list_templates(self) -> list[PDFTemplate]:
        """
        List available PDF templates.

        Returns:
            List of PDFTemplate objects
        """
        response = await self._client.get("/v1/pdf/templates")

        templates = []
        for t in response.get("templates", []):
            templates.append(
                PDFTemplate(
                    name=t.get("name", ""),
                    description=t.get("description", ""),
                    fields=t.get("fields", []),
                )
            )

        return templates

    async def health(self) -> dict[str, Any]:
        """
        Check PDF service health.

        Returns:
            Health status including ReportLab availability
        """
        return await self._client.get("/v1/pdf/health")
