"""
Neural LAB SDK - Document AI Resource
Intelligent document analysis via LLM.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
Created: 2026-02-02
"""

from dataclasses import dataclass
from typing import Any, Literal

from ..base import DataclassMixin


@dataclass
class DocumentAIResult(DataclassMixin):
    """Document AI operation result."""

    success: bool
    result: dict
    model: str = "maritaca-sabia-4"
    input_tokens: int = 0
    output_tokens: int = 0
    cost_brl: float = 0.0
    latency_ms: int = 0


class DocumentAIResource:
    """
    Document AI resource for intelligent document analysis.

    Provides summarization, extraction, analysis, and comparison
    of documents using LLM.

    Usage:
        # Summarize a document
        result = client.document_ai.summarize(
            content="Long document text...",
            max_length="medium",
            format="bullets"
        )
        print(result.result["summary"])

        # Extract key points
        result = client.document_ai.extract(
            content="Document with data...",
            extract_type="key_points"
        )

        # Full analysis
        result = client.document_ai.analyze(
            content="Document...",
            analysis_type="legal",
            include_recommendations=True
        )

        # Compare documents
        result = client.document_ai.compare(
            document_a="First version...",
            document_b="Second version...",
            comparison_type="changes"
        )
    """

    def __init__(self, client: Any):
        """Initialize Document AI resource.

        Args:
            client: The NTLClient instance
        """
        self._client = client

    def summarize(
        self,
        content: str,
        language: str = "pt",
        max_length: Literal["short", "medium", "long"] = "medium",
        format: Literal["paragraph", "bullets", "structured"] = "paragraph",
        focus: str | None = None,
    ) -> DocumentAIResult:
        """
        Generate a summary of a document.

        Args:
            content: Document content to summarize
            language: Output language (pt, en, es)
            max_length: Summary length (short, medium, long)
            format: Output format (paragraph, bullets, structured)
            focus: Specific focus for the summary

        Returns:
            DocumentAIResult with summary
        """
        response = self._client.post(
            "/v1/document-ai/summarize",
            json={
                "content": content,
                "language": language,
                "max_length": max_length,
                "format": format,
                "focus": focus,
            },
        )

        return DocumentAIResult(
            success=response.get("success", False),
            result=response.get("result", {}),
            model=response.get("model", "maritaca-sabia-4"),
            input_tokens=response.get("input_tokens", 0),
            output_tokens=response.get("output_tokens", 0),
            cost_brl=response.get("cost_brl", 0.0),
            latency_ms=response.get("latency_ms", 0),
        )

    def extract(
        self,
        content: str,
        extract_type: Literal[
            "key_points", "entities", "dates", "numbers", "actions", "custom"
        ] = "key_points",
        custom_extraction: str | None = None,
        language: str = "pt",
    ) -> DocumentAIResult:
        """
        Extract specific information from a document.

        Args:
            content: Document content to extract from
            extract_type: What to extract (key_points, entities, dates, numbers, actions, custom)
            custom_extraction: Custom extraction prompt (if extract_type=custom)
            language: Output language (pt, en, es)

        Returns:
            DocumentAIResult with extracted information
        """
        response = self._client.post(
            "/v1/document-ai/extract",
            json={
                "content": content,
                "extract_type": extract_type,
                "custom_extraction": custom_extraction,
                "language": language,
            },
        )

        return DocumentAIResult(
            success=response.get("success", False),
            result=response.get("result", {}),
            model=response.get("model", "maritaca-sabia-4"),
            input_tokens=response.get("input_tokens", 0),
            output_tokens=response.get("output_tokens", 0),
            cost_brl=response.get("cost_brl", 0.0),
            latency_ms=response.get("latency_ms", 0),
        )

    def analyze(
        self,
        content: str,
        analysis_type: Literal[
            "general", "legal", "medical", "technical", "financial"
        ] = "general",
        include_summary: bool = True,
        include_key_points: bool = True,
        include_entities: bool = True,
        include_sentiment: bool = False,
        include_recommendations: bool = False,
        language: str = "pt",
    ) -> DocumentAIResult:
        """
        Perform comprehensive document analysis.

        Args:
            content: Document content to analyze
            analysis_type: Type of analysis (general, legal, medical, technical, financial)
            include_summary: Include summary in analysis
            include_key_points: Include key points
            include_entities: Include entity extraction
            include_sentiment: Include sentiment analysis
            include_recommendations: Include recommendations
            language: Output language (pt, en, es)

        Returns:
            DocumentAIResult with full analysis
        """
        response = self._client.post(
            "/v1/document-ai/analyze",
            json={
                "content": content,
                "analysis_type": analysis_type,
                "include_summary": include_summary,
                "include_key_points": include_key_points,
                "include_entities": include_entities,
                "include_sentiment": include_sentiment,
                "include_recommendations": include_recommendations,
                "language": language,
            },
        )

        return DocumentAIResult(
            success=response.get("success", False),
            result=response.get("result", {}),
            model=response.get("model", "maritaca-sabia-4"),
            input_tokens=response.get("input_tokens", 0),
            output_tokens=response.get("output_tokens", 0),
            cost_brl=response.get("cost_brl", 0.0),
            latency_ms=response.get("latency_ms", 0),
        )

    def compare(
        self,
        document_a: str,
        document_b: str,
        comparison_type: Literal[
            "differences", "similarities", "full", "changes"
        ] = "full",
        language: str = "pt",
    ) -> DocumentAIResult:
        """
        Compare two documents.

        Args:
            document_a: First document content
            document_b: Second document content
            comparison_type: Type of comparison (differences, similarities, full, changes)
            language: Output language (pt, en, es)

        Returns:
            DocumentAIResult with comparison
        """
        response = self._client.post(
            "/v1/document-ai/compare",
            json={
                "document_a": document_a,
                "document_b": document_b,
                "comparison_type": comparison_type,
                "language": language,
            },
        )

        return DocumentAIResult(
            success=response.get("success", False),
            result=response.get("result", {}),
            model=response.get("model", "maritaca-sabia-4"),
            input_tokens=response.get("input_tokens", 0),
            output_tokens=response.get("output_tokens", 0),
            cost_brl=response.get("cost_brl", 0.0),
            latency_ms=response.get("latency_ms", 0),
        )

    def health(self) -> dict:
        """
        Check Document AI service health.

        Returns:
            Health status dictionary
        """
        return self._client.get("/v1/document-ai/health")
