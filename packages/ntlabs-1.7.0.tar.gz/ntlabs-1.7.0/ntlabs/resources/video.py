"""
Neural LAB - AI Solutions Platform
Video Resource - Video conferencing via Daily.co/Pipecat.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
Created: 2026-02-02
"""

from dataclasses import dataclass
from typing import Any

from ..base import DataclassMixin


@dataclass
class VideoRoom(DataclassMixin):
    """Video room information."""

    session_id: str
    room_url: str
    room_name: str
    token: str | None = None
    expires_at: str | None = None
    is_mock: bool = False
    latency_ms: int = 0


@dataclass
class VideoSessionStatus(DataclassMixin):
    """Video session status."""

    session_id: str
    status: str  # pending, active, ended
    participants: int = 0
    is_recording: bool = False
    started_at: str | None = None
    ended_at: str | None = None
    latency_ms: int = 0


@dataclass
class VideoSessionEnd(DataclassMixin):
    """Result of ending a video session."""

    session_id: str
    recording_url: str | None = None
    transcript: str | None = None
    duration_seconds: int = 0
    cost_brl: float = 0.0
    latency_ms: int = 0


@dataclass
class VideoRecording(DataclassMixin):
    """Video recording information."""

    session_id: str
    recording_url: str | None = None
    duration_seconds: int = 0
    latency_ms: int = 0


class VideoResource:
    """
    Video resource for video conferencing via Daily.co/Pipecat.

    Usage:
        # Create a room
        room = client.video.create_room(
            session_id="sess_123",
            room_prefix="hipocrates",
            enable_recording=True,
        )
        print(room.room_url)

        # Get session status
        status = client.video.get_status("sess_123")
        print(f"Participants: {status.participants}")

        # End session
        result = client.video.end_session("sess_123")
        print(f"Recording: {result.recording_url}")

        # Get recording
        recording = client.video.get_recording("sess_123")
    """

    def __init__(self, client):
        self._client = client

    def create_room(
        self,
        session_id: str,
        room_prefix: str = "room",
        room_name: str | None = None,
        enable_recording: bool = True,
        enable_transcription: bool = True,
        enable_chat: bool = True,
        max_participants: int = 10,
        expiry_minutes: int = 60,
    ) -> VideoRoom:
        """
        Create a new video room.

        Args:
            session_id: Unique session identifier
            room_prefix: Prefix for room name (e.g., 'hipocrates', 'mercurius')
            room_name: Custom room name (optional)
            enable_recording: Enable cloud recording
            enable_transcription: Enable real-time transcription
            enable_chat: Enable in-room chat
            max_participants: Maximum participants (2-100)
            expiry_minutes: Room expiry in minutes (5-480)

        Returns:
            VideoRoom with room URL and session info
        """
        response = self._client.post(
            "/v1/video/rooms",
            json={
                "session_id": session_id,
                "room_prefix": room_prefix,
                "room_name": room_name,
                "enable_recording": enable_recording,
                "enable_transcription": enable_transcription,
                "enable_chat": enable_chat,
                "max_participants": max_participants,
                "expiry_minutes": expiry_minutes,
            },
        )

        return VideoRoom(
            session_id=response.get("session_id", session_id),
            room_url=response.get("room_url", ""),
            room_name=response.get("room_name", ""),
            token=response.get("token"),
            expires_at=response.get("expires_at"),
            is_mock=response.get("is_mock", False),
            latency_ms=response.get("latency_ms", 0),
        )

    def end_session(self, session_id: str) -> VideoSessionEnd:
        """
        End a video session.

        Args:
            session_id: The session ID to end

        Returns:
            VideoSessionEnd with recording URL and duration
        """
        response = self._client.request(
            "DELETE",
            f"/v1/video/rooms/{session_id}",
        )

        return VideoSessionEnd(
            session_id=response.get("session_id", session_id),
            recording_url=response.get("recording_url"),
            transcript=response.get("transcript"),
            duration_seconds=response.get("duration_seconds", 0),
            cost_brl=response.get("cost_brl", 0.0),
            latency_ms=response.get("latency_ms", 0),
        )

    def get_status(self, session_id: str) -> VideoSessionStatus:
        """
        Get status of a video session.

        Args:
            session_id: The session ID

        Returns:
            VideoSessionStatus with participants and recording status
        """
        response = self._client.get(f"/v1/video/rooms/{session_id}/status")

        return VideoSessionStatus(
            session_id=response.get("session_id", session_id),
            status=response.get("status", "pending"),
            participants=response.get("participants", 0),
            is_recording=response.get("is_recording", False),
            started_at=response.get("started_at"),
            ended_at=response.get("ended_at"),
            latency_ms=response.get("latency_ms", 0),
        )

    def get_recording(self, session_id: str) -> VideoRecording:
        """
        Get recording URL for a completed session.

        Args:
            session_id: The session ID

        Returns:
            VideoRecording with URL and duration
        """
        response = self._client.get(f"/v1/video/rooms/{session_id}/recording")

        return VideoRecording(
            session_id=response.get("session_id", session_id),
            recording_url=response.get("recording_url"),
            duration_seconds=response.get("duration_seconds", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    def health(self) -> dict[str, Any]:
        """
        Check video service health.

        Returns:
            Health status including Daily.co configuration
        """
        return self._client.get("/v1/video/health")
