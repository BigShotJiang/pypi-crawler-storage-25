"""
Neural LAB - AI Solutions Platform
Chat Resource - LLM completions.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
Created: 2026-01-24
"""

import json
import logging
from collections.abc import Iterator
from dataclasses import dataclass, field

from ..base import DataclassMixin
from ..exceptions import APIError

logger = logging.getLogger(__name__)


@dataclass
class ChatMessage(DataclassMixin):
    """Chat message."""

    role: str  # system, user, assistant
    content: str


@dataclass
class ChatCompletion(DataclassMixin):
    """Chat completion response."""

    id: str
    content: str
    model: str
    usage: dict[str, int]
    finish_reason: str


@dataclass
class StreamEvent(DataclassMixin):
    """Parsed SSE stream event from the chat API.

    Events follow the format:
        type=start  -> agent, session_id
        type=token  -> content (text chunk)
        type=end    -> intent, lead_score, should_handoff, latency_ms
        type=error  -> error message
    """

    type: str
    content: str | None = None
    agent: str | None = None
    session_id: str | None = None
    intent: str | None = None
    lead_score: int | None = None
    should_handoff: bool | None = None
    latency_ms: int | None = None
    error: str | None = None
    raw: dict = field(default_factory=dict)


def _parse_sse_line(line: str) -> StreamEvent | None:
    """Parse a single SSE data line into a StreamEvent.

    Args:
        line: Raw SSE line (e.g. 'data: {"type": "token", "content": "Hello"}')

    Returns:
        StreamEvent if the line contains valid data, None otherwise.
    """
    line = line.strip()
    if not line or not line.startswith("data: "):
        return None

    payload = line[6:]  # strip "data: " prefix

    if payload == "[DONE]":
        return None

    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        logger.warning("Failed to parse SSE payload: %s", payload)
        return None

    return StreamEvent(
        type=data.get("type", "unknown"),
        content=data.get("content"),
        agent=data.get("agent"),
        session_id=data.get("session_id"),
        intent=data.get("intent"),
        lead_score=data.get("lead_score"),
        should_handoff=data.get("should_handoff"),
        latency_ms=data.get("latency_ms"),
        error=data.get("error"),
        raw=data,
    )


class ChatResource:
    """
    Chat completions resource.

    Usage:
        response = client.chat.complete(
            messages=[{"role": "user", "content": "Ola!"}],
            model="maritaca-sabia-4"
        )
        print(response.content)
    """

    def __init__(self, client):
        self._client = client

    def complete(
        self,
        messages: list[dict[str, str]],
        model: str = "maritaca-sabia-4",
        max_tokens: int = 1024,
        temperature: float = 0.7,
        system: str | None = None,
        **kwargs,
    ) -> ChatCompletion:
        """
        Create a chat completion.

        Args:
            messages: List of messages [{"role": "user", "content": "..."}]
            model: Model to use (maritaca-sabia-4, claude-sonnet, claude-opus)
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0-1)
            system: System prompt (optional)
            **kwargs: Additional parameters

        Returns:
            ChatCompletion with response
        """
        # Prepend system message if provided
        if system:
            messages = [{"role": "system", "content": system}] + messages

        response = self._client.post(
            "/v1/llm/completions",
            json={
                "messages": messages,
                "model": model,
                "max_tokens": max_tokens,
                "temperature": temperature,
                **kwargs,
            },
        )

        return ChatCompletion(
            id=response.get("id", ""),
            content=response.get("choices", [{}])[0]
            .get("message", {})
            .get("content", ""),
            model=response.get("model", model),
            usage=response.get("usage", {}),
            finish_reason=response.get("choices", [{}])[0].get("finish_reason", "stop"),
        )

    def complete_stream(
        self,
        messages: list[dict[str, str]],
        model: str = "maritaca-sabia-4",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        agent: str = "dedalo",
        locale: str = "pt",
        session_id: str | None = None,
        user_id: str | None = None,
        **kwargs,
    ) -> Iterator[str]:
        """
        Create a streaming chat completion via SSE.

        Connects to the /api/chat/stream endpoint and yields content
        chunks as they arrive from the server.

        Args:
            messages: List of messages [{"role": "user", "content": "..."}]
            model: Model to use
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0-1)
            agent: Agent ID (dedalo, chiron, themis, hermes, athena)
            locale: Language code (pt, en, es)
            session_id: Optional session ID for context persistence
            user_id: Optional user ID for personalization
            **kwargs: Additional parameters

        Yields:
            Content text chunks as they arrive from the stream
        """
        import httpx

        payload = {
            "messages": [
                {"role": m["role"], "content": m["content"]} for m in messages
            ],
            "agent": agent,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "locale": locale,
            "stream": True,
        }
        if session_id:
            payload["session_id"] = session_id
        if user_id:
            payload["user_id"] = user_id

        try:
            with self._client._client.stream(
                "POST",
                "/api/chat/stream",
                json=payload,
            ) as response:
                if response.status_code >= 400:
                    response.read()
                    raise APIError(
                        f"Stream request failed: {response.status_code}",
                        status_code=response.status_code,
                    )

                for line in response.iter_lines():
                    event = _parse_sse_line(line)
                    if event is None:
                        continue

                    if event.type == "error":
                        raise APIError(event.error or "Unknown streaming error")

                    if event.type == "token" and event.content:
                        yield event.content

                    if event.type == "end":
                        break

        except httpx.TimeoutException as e:
            raise APIError(f"Stream request timeout: {e}") from e
        except httpx.RequestError as e:
            raise APIError(f"Stream request failed: {e}") from e

    def complete_stream_events(
        self,
        messages: list[dict[str, str]],
        model: str = "maritaca-sabia-4",
        max_tokens: int = 2000,
        temperature: float = 0.7,
        agent: str = "dedalo",
        locale: str = "pt",
        session_id: str | None = None,
        user_id: str | None = None,
        **kwargs,
    ) -> Iterator[StreamEvent]:
        """
        Create a streaming chat completion via SSE, yielding full events.

        Unlike complete_stream() which yields only content strings, this
        method yields StreamEvent objects including start, token, end, and
        error events with all metadata.

        Args:
            messages: List of messages [{"role": "user", "content": "..."}]
            model: Model to use
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0-1)
            agent: Agent ID (dedalo, chiron, themis, hermes, athena)
            locale: Language code (pt, en, es)
            session_id: Optional session ID for context persistence
            user_id: Optional user ID for personalization
            **kwargs: Additional parameters

        Yields:
            StreamEvent objects for each SSE event
        """
        import httpx

        payload = {
            "messages": [
                {"role": m["role"], "content": m["content"]} for m in messages
            ],
            "agent": agent,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "locale": locale,
            "stream": True,
        }
        if session_id:
            payload["session_id"] = session_id
        if user_id:
            payload["user_id"] = user_id

        try:
            with self._client._client.stream(
                "POST",
                "/api/chat/stream",
                json=payload,
            ) as response:
                if response.status_code >= 400:
                    response.read()
                    raise APIError(
                        f"Stream request failed: {response.status_code}",
                        status_code=response.status_code,
                    )

                for line in response.iter_lines():
                    event = _parse_sse_line(line)
                    if event is None:
                        continue

                    yield event

                    if event.type in ("end", "error"):
                        break

        except httpx.TimeoutException as e:
            raise APIError(f"Stream request timeout: {e}") from e
        except httpx.RequestError as e:
            raise APIError(f"Stream request failed: {e}") from e
