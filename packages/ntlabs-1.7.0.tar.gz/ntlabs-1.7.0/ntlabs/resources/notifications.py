"""
Neural LAB SDK - Notifications Resource
Push notification operations via Web Push (VAPID).

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Literal

from ..base import DataclassMixin

NotificationCategory = Literal[
    "marketing", "updates", "security", "reminders", "billing", "system"
]


@dataclass
class SubscriptionInfo(DataclassMixin):
    """Push subscription information."""

    id: str
    product: str
    device_name: str | None = None
    user_agent: str | None = None
    created_at: datetime | None = None
    last_used_at: datetime | None = None


@dataclass
class SubscribeResult(DataclassMixin):
    """Result of subscription registration."""

    success: bool
    subscription_id: str | None = None
    message: str = ""
    cost_brl: float = 0.0
    latency_ms: int = 0
    error: str | None = None


@dataclass
class UnsubscribeResult(DataclassMixin):
    """Result of subscription removal."""

    success: bool
    message: str = ""
    cost_brl: float = 0.0
    latency_ms: int = 0
    error: str | None = None


@dataclass
class SendResult(DataclassMixin):
    """Result of sending notifications."""

    success: bool
    sent_count: int = 0
    failed_count: int = 0
    notification_ids: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    cost_brl: float = 0.0
    latency_ms: int = 0
    error: str | None = None


@dataclass
class NotificationPreferences(DataclassMixin):
    """User notification preferences."""

    marketing: bool = True
    updates: bool = True
    security: bool = True
    reminders: bool = True
    billing: bool = True
    email_enabled: bool = True
    push_enabled: bool = True
    quiet_hours_start: str | None = None
    quiet_hours_end: str | None = None
    product: str = "lab"


@dataclass
class PreferencesResult(DataclassMixin):
    """Result of preferences operations."""

    success: bool
    preferences: NotificationPreferences | None = None
    message: str | None = None
    cost_brl: float = 0.0
    latency_ms: int = 0
    error: str | None = None


@dataclass
class SubscriptionsListResult(DataclassMixin):
    """Result of listing subscriptions."""

    success: bool
    subscriptions: list[SubscriptionInfo] = field(default_factory=list)
    total_count: int = 0
    cost_brl: float = 0.0
    latency_ms: int = 0
    error: str | None = None


class NotificationsResource:
    """
    Notifications resource for push notification operations.

    Provides Web Push notifications for all Neural LAB products
    with user preference management and billing integration.

    Example:
        >>> from ntlabs import NTLClient
        >>> client = NTLClient(api_key="ntl_xxx")
        >>>
        >>> # Send a notification to a user
        >>> result = client.notifications.send(
        ...     user_id="user-uuid",
        ...     title="New Message",
        ...     body="You have a new message",
        ...     category="updates"
        ... )
        >>> print(f"Sent: {result.sent_count}, Failed: {result.failed_count}")
        >>>
        >>> # Get user preferences
        >>> prefs = client.notifications.get_preferences()
        >>> print(f"Push enabled: {prefs.preferences.push_enabled}")
        >>>
        >>> # Update preferences
        >>> client.notifications.update_preferences(
        ...     marketing=False,
        ...     quiet_hours_start="22:00",
        ...     quiet_hours_end="08:00"
        ... )
    """

    def __init__(self, client: Any):
        """Initialize notifications resource.

        Args:
            client: The NTLClient instance
        """
        self._client = client

    def subscribe(
        self,
        endpoint: str,
        keys: dict,
        product: str = "lab",
        device_name: str | None = None,
        user_agent: str | None = None,
    ) -> SubscribeResult:
        """
        Register a push notification subscription.

        The subscription details come from the browser's Push API.

        Args:
            endpoint: Push service endpoint URL
            keys: Subscription keys (p256dh, auth)
            product: Product identifier (lab, hipocrates, mercurius, polis, argos)
            device_name: Optional friendly device name
            user_agent: Optional user agent string

        Returns:
            SubscribeResult with subscription ID
        """
        response = self._client.post(
            "/v1/notifications/subscribe",
            json={
                "subscription": {
                    "endpoint": endpoint,
                    "keys": keys,
                },
                "product": product,
                "device_name": device_name,
                "user_agent": user_agent,
            },
        )

        if not response.get("success"):
            return SubscribeResult(
                success=False,
                error=response.get("detail", "Subscription failed"),
            )

        return SubscribeResult(
            success=True,
            subscription_id=response.get("subscription_id"),
            message=response.get("message", ""),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    def unsubscribe(self, endpoint: str) -> UnsubscribeResult:
        """
        Remove a push notification subscription.

        Args:
            endpoint: Push service endpoint URL to remove

        Returns:
            UnsubscribeResult with status
        """
        response = self._client.delete(
            "/v1/notifications/subscribe",
            json={"endpoint": endpoint},
        )

        if not response.get("success"):
            return UnsubscribeResult(
                success=False,
                error=response.get("detail", "Unsubscribe failed"),
            )

        return UnsubscribeResult(
            success=True,
            message=response.get("message", ""),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    def list_subscriptions(
        self,
        product: str | None = None,
    ) -> SubscriptionsListResult:
        """
        List all push subscriptions for the current user.

        Args:
            product: Optional filter by product

        Returns:
            SubscriptionsListResult with list of subscriptions
        """
        params = {}
        if product:
            params["product"] = product

        response = self._client.get("/v1/notifications/subscriptions", params=params)

        if not response.get("success"):
            return SubscriptionsListResult(
                success=False,
                error=response.get("detail", "Failed to list subscriptions"),
            )

        subscriptions = []
        for sub in response.get("subscriptions", []):
            subscriptions.append(
                SubscriptionInfo(
                    id=sub["id"],
                    product=sub["product"],
                    device_name=sub.get("device_name"),
                    user_agent=sub.get("user_agent"),
                    created_at=sub.get("created_at"),
                    last_used_at=sub.get("last_used_at"),
                )
            )

        return SubscriptionsListResult(
            success=True,
            subscriptions=subscriptions,
            total_count=response.get("total_count", len(subscriptions)),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    def send(
        self,
        title: str,
        body: str | None = None,
        user_id: str | None = None,
        subscription_id: str | None = None,
        product: str = "lab",
        category: NotificationCategory = "system",
        icon: str | None = None,
        badge: str | None = None,
        image: str | None = None,
        tag: str | None = None,
        url: str | None = None,
        data: dict | None = None,
        ttl: int = 86400,
    ) -> SendResult:
        """
        Send a push notification.

        Can target a specific user, subscription, or broadcast to all
        subscriptions of a product.

        Args:
            title: Notification title (required)
            body: Notification body text
            user_id: Target user ID
            subscription_id: Specific subscription ID
            product: Product to target (default: lab)
            category: Notification category for filtering
            icon: Icon URL
            badge: Badge URL
            image: Image URL
            tag: Notification tag for grouping
            url: URL to open on click
            data: Additional data payload
            ttl: Time to live in seconds (default: 24 hours)

        Returns:
            SendResult with counts of sent/failed notifications
        """
        payload = {
            "title": title,
            "product": product,
            "category": category,
            "ttl": ttl,
        }

        if body is not None:
            payload["body"] = body
        if user_id is not None:
            payload["user_id"] = user_id
        if subscription_id is not None:
            payload["subscription_id"] = subscription_id
        if icon is not None:
            payload["icon"] = icon
        if badge is not None:
            payload["badge"] = badge
        if image is not None:
            payload["image"] = image
        if tag is not None:
            payload["tag"] = tag
        if url is not None:
            payload["url"] = url
        if data is not None:
            payload["data"] = data

        response = self._client.post("/v1/notifications/send", json=payload)

        if not response.get("success") and response.get("sent_count", 0) == 0:
            return SendResult(
                success=False,
                error=response.get("detail", "Send failed"),
                errors=response.get("errors", []),
            )

        return SendResult(
            success=response.get("success", False),
            sent_count=response.get("sent_count", 0),
            failed_count=response.get("failed_count", 0),
            notification_ids=response.get("notification_ids", []),
            errors=response.get("errors", []),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    def get_preferences(self, product: str = "lab") -> PreferencesResult:
        """
        Get notification preferences for the current user.

        Args:
            product: Product to get preferences for

        Returns:
            PreferencesResult with user preferences
        """
        response = self._client.get(
            "/v1/notifications/preferences",
            params={"product": product},
        )

        if not response.get("success"):
            return PreferencesResult(
                success=False,
                error=response.get("detail", "Failed to get preferences"),
            )

        prefs_data = response.get("preferences", {})

        return PreferencesResult(
            success=True,
            preferences=NotificationPreferences(
                marketing=prefs_data.get("marketing", True),
                updates=prefs_data.get("updates", True),
                security=prefs_data.get("security", True),
                reminders=prefs_data.get("reminders", True),
                billing=prefs_data.get("billing", True),
                email_enabled=prefs_data.get("email_enabled", True),
                push_enabled=prefs_data.get("push_enabled", True),
                quiet_hours_start=prefs_data.get("quiet_hours_start"),
                quiet_hours_end=prefs_data.get("quiet_hours_end"),
                product=prefs_data.get("product", product),
            ),
            message=response.get("message"),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    def update_preferences(
        self,
        product: str = "lab",
        marketing: bool | None = None,
        updates: bool | None = None,
        security: bool | None = None,
        reminders: bool | None = None,
        billing: bool | None = None,
        email_enabled: bool | None = None,
        push_enabled: bool | None = None,
        quiet_hours_start: str | None = None,
        quiet_hours_end: str | None = None,
    ) -> PreferencesResult:
        """
        Update notification preferences for the current user.

        Args:
            product: Product to update preferences for
            marketing: Enable marketing notifications
            updates: Enable update notifications
            security: Enable security notifications
            reminders: Enable reminder notifications
            billing: Enable billing notifications
            email_enabled: Enable email notifications
            push_enabled: Enable push notifications
            quiet_hours_start: Start of quiet hours (HH:MM format)
            quiet_hours_end: End of quiet hours (HH:MM format)

        Returns:
            PreferencesResult with updated preferences
        """
        payload = {}

        if marketing is not None:
            payload["marketing"] = marketing
        if updates is not None:
            payload["updates"] = updates
        if security is not None:
            payload["security"] = security
        if reminders is not None:
            payload["reminders"] = reminders
        if billing is not None:
            payload["billing"] = billing
        if email_enabled is not None:
            payload["email_enabled"] = email_enabled
        if push_enabled is not None:
            payload["push_enabled"] = push_enabled
        if quiet_hours_start is not None:
            payload["quiet_hours_start"] = quiet_hours_start
        if quiet_hours_end is not None:
            payload["quiet_hours_end"] = quiet_hours_end

        response = self._client.put(
            "/v1/notifications/preferences",
            params={"product": product},
            json=payload,
        )

        if not response.get("success"):
            return PreferencesResult(
                success=False,
                error=response.get("detail", "Failed to update preferences"),
            )

        prefs_data = response.get("preferences", {})

        return PreferencesResult(
            success=True,
            preferences=NotificationPreferences(
                marketing=prefs_data.get("marketing", True),
                updates=prefs_data.get("updates", True),
                security=prefs_data.get("security", True),
                reminders=prefs_data.get("reminders", True),
                billing=prefs_data.get("billing", True),
                email_enabled=prefs_data.get("email_enabled", True),
                push_enabled=prefs_data.get("push_enabled", True),
                quiet_hours_start=prefs_data.get("quiet_hours_start"),
                quiet_hours_end=prefs_data.get("quiet_hours_end"),
                product=prefs_data.get("product", product),
            ),
            cost_brl=response.get("cost_brl", 0),
            latency_ms=response.get("latency_ms", 0),
        )

    def get_vapid_key(self) -> str | None:
        """
        Get the VAPID public key for client-side subscription.

        Returns:
            VAPID public key string or None if not configured
        """
        try:
            response = self._client.get("/v1/notifications/vapid-key")
            return response.get("publicKey")
        except Exception:
            return None

    def health(self) -> dict:
        """
        Check notifications service health.

        Returns:
            Health status dictionary
        """
        return self._client.get("/v1/notifications/health")
