"""
Tenant-aware FastAPI dependencies.

Reproduces the `get_tenant_id_header` / `require_tenant_id` pair that
every multi-tenant NTLabs product API writes in its own `deps.py`.
"""

from collections.abc import Callable


def create_tenant_deps(
    header_name: str = "X-Tenant-ID",
    error_detail: str = "Tenant não identificado. Envie o header X-Tenant-ID.",
    http_status_on_missing: int = 400,
) -> tuple[Callable, Callable]:
    """
    Build a `(get_tenant_id_header, require_tenant_id)` pair.

    - `get_tenant_id_header()` reads the tenant header and returns it, or
      `None` if absent.
    - `require_tenant_id()` returns the tenant value or raises
      `HTTPException(400)` when missing.

    Args:
        header_name: HTTP header carrying the tenant identifier
            (default: `X-Tenant-ID`; Agora uses `X-Tenant-Slug`).
        error_detail: Message raised by `require_tenant_id` when the
            header is absent.
        http_status_on_missing: Status code for the missing-tenant error
            (default: 400).

    Returns:
        Tuple of `(get_tenant_id_header, require_tenant_id)`.

    Example:
        # In app/core/deps.py:
        from ntlabs.fastapi import create_tenant_deps

        get_tenant_id_header, require_tenant_id = create_tenant_deps()

        # In a router:
        @router.get("/items")
        async def list_items(tenant_id: str = Depends(require_tenant_id)):
            ...
    """
    try:
        from fastapi import Header, HTTPException
    except ImportError as err:
        raise ImportError(
            "fastapi is required for create_tenant_deps(). "
            "Install it with: pip install fastapi"
        ) from err

    header_alias = header_name.lower()

    async def get_tenant_id_header(
        value: str | None = Header(None, alias=header_alias),
    ) -> str | None:
        return value

    async def require_tenant_id(
        value: str | None = Header(None, alias=header_alias),
    ) -> str:
        if not value:
            raise HTTPException(status_code=http_status_on_missing, detail=error_detail)
        return value

    return get_tenant_id_header, require_tenant_id
