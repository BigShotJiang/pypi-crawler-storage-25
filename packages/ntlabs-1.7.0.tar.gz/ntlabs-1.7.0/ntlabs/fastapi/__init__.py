"""
NTLabs FastAPI helpers - product-ready dependencies and factories.

This module consolidates the boilerplate that every NTLabs product API
(Mercurius, Polis, Argos, Hipocrates, Agora) rewrites in its own
`app/core/deps.py`:

- NTLClient singleton factory (tagged with source_system)
- Tenant-aware FastAPI dependencies (X-Tenant-ID / X-Tenant-Slug)
- Supabase JWT current-user dependency

Example:
    from fastapi import FastAPI, Depends
    from ntlabs.fastapi import create_ntl_client_factory, create_tenant_deps

    app = FastAPI()
    get_ntl_client, require_ntl_client = create_ntl_client_factory(
        api_key=settings.ntl_api_key,
        source_system="mercurius",
    )
    get_tenant_id_header, require_tenant_id = create_tenant_deps()

    @app.post("/generate")
    async def generate(
        client=Depends(require_ntl_client),
        tenant_id=Depends(require_tenant_id),
    ):
        return client.chat.complete(messages=[...])
"""

from .client_factory import create_ntl_client_factory
from .tenant import create_tenant_deps

__all__ = [
    "create_ntl_client_factory",
    "create_tenant_deps",
]
