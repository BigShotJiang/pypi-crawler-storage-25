"""
NTLClient FastAPI factory - build singleton dependencies tagged with a
product's source_system.

Replaces near-identical `get_ntl_client` / `require_ntl_client` pairs
that each product reimplements in `app/core/deps.py`.
"""

import logging
from collections.abc import Callable
from functools import lru_cache

logger = logging.getLogger(__name__)


def create_ntl_client_factory(
    api_key: str | None,
    source_system: str,
    http_status_on_missing: int = 503,
) -> tuple[Callable[[], object], Callable[[], object]]:
    """
    Build a `(get_ntl_client, require_ntl_client)` pair for use as FastAPI
    dependencies.

    - `get_ntl_client()` returns the NTLClient singleton or `None` if
      `api_key` is missing / the SDK fails to initialise.
    - `require_ntl_client()` calls `get_ntl_client()` and raises an
      `HTTPException(503)` (configurable) when it returns `None`.

    Args:
        api_key: The `NTL_API_KEY` value. Pass `settings.ntl_api_key` etc.
        source_system: Product tag used by Neural LAB gateway for billing
            and observability (e.g., `"mercurius"`, `"polis"`, `"hipocrates"`).
        http_status_on_missing: Status code raised by `require_ntl_client`
            when the client is not configured. Defaults to 503.

    Returns:
        Tuple of `(get_ntl_client, require_ntl_client)`.

    Example:
        # In app/core/deps.py:
        from ntlabs.fastapi import create_ntl_client_factory
        from app.config import get_settings

        _settings = get_settings()
        get_ntl_client, require_ntl_client = create_ntl_client_factory(
            api_key=_settings.ntl_api_key,
            source_system="mercurius",
        )
    """

    @lru_cache(maxsize=1)
    def _build_client() -> object | None:
        if not api_key:
            logger.warning("NTL_API_KEY not configured for %s", source_system)
            return None
        try:
            from ntlabs import NTLClient

            client = NTLClient(api_key=api_key, source_system=source_system)
            logger.info("NTLClient initialized for %s", source_system)
            return client
        except ImportError:
            logger.error("ntlabs SDK not installed. Run: pip install ntlabs")
            return None
        except Exception as exc:  # pragma: no cover - network/config failures
            logger.error(
                "Failed to initialize NTLClient for %s: %s", source_system, exc
            )
            return None

    def get_ntl_client() -> object | None:
        return _build_client()

    def require_ntl_client() -> object:
        client = _build_client()
        if client is None:
            try:
                from fastapi import HTTPException
            except ImportError as err:
                raise ImportError(
                    "fastapi is required for require_ntl_client(). "
                    "Install it with: pip install fastapi"
                ) from err
            raise HTTPException(
                status_code=http_status_on_missing,
                detail="NTLabs SDK not configured. Check NTL_API_KEY environment variable.",
            )
        return client

    return get_ntl_client, require_ntl_client
