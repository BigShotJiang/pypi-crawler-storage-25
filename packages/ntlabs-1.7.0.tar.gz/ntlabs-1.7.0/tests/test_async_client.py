"""
Tests for the asynchronous AsyncNTLClient.

Author: Anderson Henrique da Silva
Date: 2026-02-04
"""

from unittest.mock import MagicMock, patch

import httpx
import pytest

from ntlabs import AsyncNTLClient
from ntlabs.exceptions import (
    APIError,
    AuthenticationError,
    InsufficientCreditsError,
    RateLimitError,
    ServiceUnavailableError,
)


class TestAsyncNTLClientInitialization:
    """Test AsyncNTLClient initialization."""

    @pytest.mark.asyncio
    async def test_client_initialization_with_api_key(self):
        """Test client initialization with explicit API key."""
        client = AsyncNTLClient(api_key="ntl_hipo_test123")
        assert client.api_key == "ntl_hipo_test123"
        assert client.source_system == "hipocrates"
        assert client.base_url == "https://api.ntlabs.dev"

    @pytest.mark.asyncio
    async def test_client_initialization_with_env_var(self, monkeypatch):
        """Test client initialization with environment variable."""
        monkeypatch.setenv("NTL_API_KEY", "ntl_merc_test456")
        client = AsyncNTLClient()
        assert client.api_key == "ntl_merc_test456"
        assert client.source_system == "mercurius"

    @pytest.mark.asyncio
    async def test_client_initialization_without_api_key(self, monkeypatch):
        """Test client initialization fails without API key."""
        monkeypatch.delenv("NTL_API_KEY", raising=False)
        with pytest.raises(AuthenticationError) as exc_info:
            AsyncNTLClient()
        assert "API key required" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_client_initialization_with_custom_base_url(self):
        """Test client initialization with custom base URL."""
        client = AsyncNTLClient(
            api_key="ntl_test_123",
            base_url="https://custom.api.com/",
        )
        assert client.base_url == "https://custom.api.com"

    @pytest.mark.asyncio
    async def test_client_initialization_with_custom_timeout(self):
        """Test client initialization with custom timeout."""
        client = AsyncNTLClient(api_key="ntl_test_123", timeout=120.0)
        assert client.timeout == 120.0

    @pytest.mark.asyncio
    async def test_source_system_detection(self):
        """Test source system detection."""
        client_hipo = AsyncNTLClient(api_key="ntl_hipo_abc")
        assert client_hipo.source_system == "hipocrates"

        client_merc = AsyncNTLClient(api_key="ntl_merc_abc")
        assert client_merc.source_system == "mercurius"

        client_poli = AsyncNTLClient(api_key="ntl_poli_abc")
        assert client_poli.source_system == "polis"

        client_ext = AsyncNTLClient(api_key="ntl_other_abc")
        assert client_ext.source_system == "external"


class TestAsyncNTLClientLazyInitialization:
    """Test AsyncNTLClient lazy resource initialization."""

    @pytest.mark.asyncio
    async def test_lazy_client_initialization(self):
        """Test HTTP client is lazily initialized."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._client is None

    @pytest.mark.asyncio
    async def test_client_created_on_first_use(self):
        """Test HTTP client is created on first request."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                mock_response = MagicMock()
                mock_response.status_code = 200
                mock_response.content = b'{"data": "test"}'
                mock_response.json.return_value = {"data": "test"}
                mock_response.headers = {}
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            await client.get("/test")

            assert client._client is not None


class TestAsyncNTLClientResources:
    """Test AsyncNTLClient resource properties."""

    @pytest.mark.asyncio
    async def test_agents_resource_lazy_load(self):
        """Test agents resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._agents is None
        _ = client.agents
        assert client._agents is not None

    @pytest.mark.asyncio
    async def test_auth_resource_lazy_load(self):
        """Test auth resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._auth is None
        _ = client.auth
        assert client._auth is not None

    @pytest.mark.asyncio
    async def test_chat_resource_lazy_load(self):
        """Test chat resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._chat is None
        _ = client.chat
        assert client._chat is not None

    @pytest.mark.asyncio
    async def test_email_resource_lazy_load(self):
        """Test email resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._email is None
        _ = client.email
        assert client._email is not None

    @pytest.mark.asyncio
    async def test_transcribe_resource_lazy_load(self):
        """Test transcribe resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._transcribe is None
        _ = client.transcribe
        assert client._transcribe is not None

    @pytest.mark.asyncio
    async def test_ocr_resource_lazy_load(self):
        """Test ocr resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._ocr is None
        _ = client.ocr
        assert client._ocr is not None

    @pytest.mark.asyncio
    async def test_video_resource_lazy_load(self):
        """Test video resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._video is None
        _ = client.video
        assert client._video is not None

    @pytest.mark.asyncio
    async def test_pdf_resource_lazy_load(self):
        """Test pdf resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._pdf is None
        _ = client.pdf
        assert client._pdf is not None

    @pytest.mark.asyncio
    async def test_storage_resource_lazy_load(self):
        """Test storage resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._storage is None
        _ = client.storage
        assert client._storage is not None

    @pytest.mark.asyncio
    async def test_notifications_resource_lazy_load(self):
        """Test notifications resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._notifications is None
        _ = client.notifications
        assert client._notifications is not None

    @pytest.mark.asyncio
    async def test_document_ai_resource_lazy_load(self):
        """Test document_ai resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._document_ai is None
        _ = client.document_ai
        assert client._document_ai is not None

    @pytest.mark.asyncio
    async def test_gov_resource_lazy_load(self):
        """Test gov resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._gov is None
        _ = client.gov
        assert client._gov is not None

    @pytest.mark.asyncio
    async def test_bb_resource_lazy_load(self):
        """Test bb resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._bb is None
        _ = client.bb
        assert client._bb is not None

    @pytest.mark.asyncio
    async def test_ibge_resource_lazy_load(self):
        """Test ibge resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._ibge is None
        _ = client.ibge
        assert client._ibge is not None

    @pytest.mark.asyncio
    async def test_saude_resource_lazy_load(self):
        """Test saude resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._saude is None
        _ = client.saude
        assert client._saude is not None

    @pytest.mark.asyncio
    async def test_cartorio_resource_lazy_load(self):
        """Test cartorio resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._cartorio is None
        _ = client.cartorio
        assert client._cartorio is not None

    @pytest.mark.asyncio
    async def test_rnds_resource_lazy_load(self):
        """Test rnds resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._rnds is None
        _ = client.rnds
        assert client._rnds is not None

    @pytest.mark.asyncio
    async def test_crc_resource_lazy_load(self):
        """Test crc resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._crc is None
        _ = client.crc
        assert client._crc is not None

    @pytest.mark.asyncio
    async def test_censec_resource_lazy_load(self):
        """Test censec resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._censec is None
        _ = client.censec
        assert client._censec is not None

    @pytest.mark.asyncio
    async def test_enotariado_resource_lazy_load(self):
        """Test enotariado resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._enotariado is None
        _ = client.enotariado
        assert client._enotariado is not None

    @pytest.mark.asyncio
    async def test_onr_resource_lazy_load(self):
        """Test onr resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._onr is None
        _ = client.onr
        assert client._onr is not None

    @pytest.mark.asyncio
    async def test_billing_resource_lazy_load(self):
        """Test billing resource lazy loading."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        assert client._billing is None
        _ = client.billing
        assert client._billing is not None

    @pytest.mark.asyncio
    async def test_resource_caching(self):
        """Test resources are cached after first access."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        agents1 = client.agents
        agents2 = client.agents
        assert agents1 is agents2


class TestAsyncNTLClientHTTPMethods:
    """Test AsyncNTLClient HTTP methods."""

    @pytest.mark.asyncio
    async def test_get_request(self):
        """Test async GET request."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'{"data": "test"}'
            mock_response.json.return_value = {"data": "test"}
            mock_response.headers = {}

            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            result = await client.get("/test")

            assert result == {"data": "test"}

    @pytest.mark.asyncio
    async def test_post_request(self):
        """Test async POST request."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'{"id": "123"}'
            mock_response.json.return_value = {"id": "123"}
            mock_response.headers = {}

            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            result = await client.post("/test", json={"name": "test"})

            assert result == {"id": "123"}

    @pytest.mark.asyncio
    async def test_put_request(self):
        """Test async PUT request."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'{"updated": true}'
            mock_response.json.return_value = {"updated": True}
            mock_response.headers = {}

            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            result = await client.put("/test/123", json={"name": "updated"})

            assert result == {"updated": True}

    @pytest.mark.asyncio
    async def test_delete_request(self):
        """Test async DELETE request."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'{"deleted": true}'
            mock_response.json.return_value = {"deleted": True}
            mock_response.headers = {}

            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            result = await client.delete("/test/123")

            assert result == {"deleted": True}


class TestAsyncNTLClientErrorHandling:
    """Test AsyncNTLClient error handling."""

    @pytest.mark.asyncio
    async def test_authentication_error(self):
        """Test 401 raises AuthenticationError."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 401
            mock_response.content = b'{"detail": "Invalid API key"}'
            mock_response.json.return_value = {"detail": "Invalid API key"}
            mock_response.headers = {}

            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            with pytest.raises(AuthenticationError) as exc_info:
                await client.get("/test")
            assert exc_info.value.status_code == 401

    @pytest.mark.asyncio
    async def test_insufficient_credits_error(self):
        """Test 402 raises InsufficientCreditsError."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 402
            mock_response.content = b'{"detail": "No credits"}'
            mock_response.json.return_value = {"detail": "No credits"}
            mock_response.headers = {}

            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            with pytest.raises(InsufficientCreditsError) as exc_info:
                await client.get("/test")
            assert exc_info.value.status_code == 402

    @pytest.mark.asyncio
    async def test_rate_limit_error(self):
        """Test 429 raises RateLimitError."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 429
            mock_response.content = b'{"detail": "Rate limited"}'
            mock_response.json.return_value = {"detail": "Rate limited"}
            mock_response.headers = {"Retry-After": "60"}

            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            with pytest.raises(RateLimitError) as exc_info:
                await client.get("/test")
            assert exc_info.value.status_code == 429
            assert exc_info.value.retry_after == 60

    @pytest.mark.asyncio
    async def test_service_unavailable_error(self):
        """Test 503 raises ServiceUnavailableError."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 503
            mock_response.content = b""
            mock_response.headers = {}

            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            with pytest.raises(ServiceUnavailableError) as exc_info:
                await client.get("/test")
            assert exc_info.value.status_code == 503

    @pytest.mark.asyncio
    async def test_timeout_exception(self):
        """Test timeout raises APIError."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                raise httpx.TimeoutException("Timeout")

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123", timeout=30.0)
            with pytest.raises(APIError) as exc_info:
                await client.get("/test")
            assert "timeout" in str(exc_info.value).lower()

    @pytest.mark.asyncio
    async def test_request_error(self):
        """Test request error raises APIError."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                raise httpx.RequestError("Connection failed")

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            with pytest.raises(APIError) as exc_info:
                await client.get("/test")
            assert "request failed" in str(exc_info.value).lower()


class TestAsyncNTLClientContextManager:
    """Test AsyncNTLClient async context manager."""

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """Test client works as async context manager."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_instance = MagicMock()

            async def mock_aclose():
                pass

            mock_instance.aclose = mock_aclose
            mock_client_class.return_value = mock_instance

            async with AsyncNTLClient(api_key="ntl_test_123") as client:
                assert client.api_key == "ntl_test_123"

    @pytest.mark.asyncio
    async def test_close_method(self):
        """Test async close method."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_instance = MagicMock()

            async def mock_aclose():
                pass

            mock_instance.aclose = mock_aclose
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            await client.close()

            assert client._client is None

    @pytest.mark.asyncio
    async def test_close_when_not_initialized(self):
        """Test close when client was never used."""
        client = AsyncNTLClient(api_key="ntl_test_123")
        await client.close()  # Should not raise

    @pytest.mark.asyncio
    async def test_empty_response_handling(self):
        """Test handling of empty response."""
        with patch("httpx.AsyncClient") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b""
            mock_response.headers = {}

            mock_instance = MagicMock()

            async def mock_request(*args, **kwargs):
                return mock_response

            mock_instance.request = mock_request
            mock_client_class.return_value = mock_instance

            client = AsyncNTLClient(api_key="ntl_test_123")
            result = await client.get("/test")
            assert result == {}
