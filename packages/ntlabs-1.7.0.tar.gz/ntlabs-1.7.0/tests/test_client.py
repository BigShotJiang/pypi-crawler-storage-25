"""
Tests for the synchronous NTLClient.

Author: Anderson Henrique da Silva
Date: 2026-02-04
"""

from unittest.mock import MagicMock, patch

import httpx
import pytest

from ntlabs import NTLClient
from ntlabs.exceptions import (
    APIError,
    AuthenticationError,
    InsufficientCreditsError,
    RateLimitError,
    ServiceUnavailableError,
)


class TestNTLClientInitialization:
    """Test NTLClient initialization."""

    def test_client_initialization_with_api_key(self):
        """Test client initialization with explicit API key."""
        client = NTLClient(api_key="ntl_hipo_test123")
        assert client.api_key == "ntl_hipo_test123"
        assert client.source_system == "hipocrates"
        assert client.base_url == "https://api.ntlabs.dev"

    def test_client_initialization_with_env_var(self, monkeypatch):
        """Test client initialization with environment variable."""
        monkeypatch.setenv("NTL_API_KEY", "ntl_merc_test456")
        client = NTLClient()
        assert client.api_key == "ntl_merc_test456"
        assert client.source_system == "mercurius"

    def test_client_initialization_without_api_key(self, monkeypatch):
        """Test client initialization fails without API key."""
        monkeypatch.delenv("NTL_API_KEY", raising=False)
        with pytest.raises(AuthenticationError) as exc_info:
            NTLClient()
        assert "API key required" in str(exc_info.value)

    def test_client_initialization_with_custom_base_url(self):
        """Test client initialization with custom base URL."""
        client = NTLClient(
            api_key="ntl_test_123",
            base_url="https://custom.api.com/",
        )
        assert client.base_url == "https://custom.api.com"

    def test_client_initialization_with_env_base_url(self, monkeypatch):
        """Test client initialization with base URL from env."""
        monkeypatch.setenv("NTL_API_URL", "https://env.api.com")
        client = NTLClient(api_key="ntl_test_123")
        assert client.base_url == "https://env.api.com"

    def test_client_initialization_with_internal_url(self, monkeypatch):
        """Test client initialization with internal URL priority."""
        monkeypatch.setenv("NTL_INTERNAL_URL", "https://internal.api.com")
        monkeypatch.setenv("NTL_API_URL", "https://public.api.com")
        client = NTLClient(api_key="ntl_test_123")
        assert client.base_url == "https://internal.api.com"

    def test_client_initialization_with_custom_timeout(self):
        """Test client initialization with custom timeout."""
        client = NTLClient(api_key="ntl_test_123", timeout=120.0)
        assert client.timeout == 120.0

    def test_source_system_detection_hipocrates(self):
        """Test source system detection for hipocrates."""
        client = NTLClient(api_key="ntl_hipo_abc123")
        assert client.source_system == "hipocrates"

    def test_source_system_detection_mercurius(self):
        """Test source system detection for mercurius."""
        client = NTLClient(api_key="ntl_merc_abc123")
        assert client.source_system == "mercurius"

    def test_source_system_detection_polis(self):
        """Test source system detection for polis."""
        client = NTLClient(api_key="ntl_poli_abc123")
        assert client.source_system == "polis"

    def test_source_system_detection_external(self):
        """Test source system detection for external keys."""
        client = NTLClient(api_key="ntl_other_abc123")
        assert client.source_system == "external"

    def test_custom_source_system_override(self):
        """Test custom source system override."""
        client = NTLClient(
            api_key="ntl_hipo_abc123",
            source_system="custom_system",
        )
        assert client.source_system == "custom_system"


class TestNTLClientResources:
    """Test NTLClient resource initialization."""

    def test_chat_resource_initialized(self):
        """Test chat resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.chat is not None
        assert hasattr(client.chat, "complete")

    def test_auth_resource_initialized(self):
        """Test auth resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.auth is not None
        assert hasattr(client.auth, "login")

    def test_gov_resource_initialized(self):
        """Test gov resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.gov is not None
        assert hasattr(client.gov, "cnpj")

    def test_agents_resource_initialized(self):
        """Test agents resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.agents is not None

    def test_email_resource_initialized(self):
        """Test email resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.email is not None

    def test_transcribe_resource_initialized(self):
        """Test transcribe resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.transcribe is not None

    def test_ocr_resource_initialized(self):
        """Test ocr resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.ocr is not None

    def test_video_resource_initialized(self):
        """Test video resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.video is not None

    def test_pdf_resource_initialized(self):
        """Test pdf resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.pdf is not None

    def test_storage_resource_initialized(self):
        """Test storage resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.storage is not None

    def test_notifications_resource_initialized(self):
        """Test notifications resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.notifications is not None

    def test_document_ai_resource_initialized(self):
        """Test document_ai resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.document_ai is not None

    def test_bb_resource_initialized(self):
        """Test bb resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.bb is not None

    def test_ibge_resource_initialized(self):
        """Test ibge resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.ibge is not None

    def test_saude_resource_initialized(self):
        """Test saude resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.saude is not None

    def test_cartorio_resource_initialized(self):
        """Test cartorio resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.cartorio is not None

    def test_rnds_resource_initialized(self):
        """Test rnds resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.rnds is not None

    def test_crc_resource_initialized(self):
        """Test crc resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.crc is not None

    def test_censec_resource_initialized(self):
        """Test censec resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.censec is not None

    def test_enotariado_resource_initialized(self):
        """Test enotariado resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.enotariado is not None

    def test_onr_resource_initialized(self):
        """Test onr resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.onr is not None

    def test_billing_resource_initialized(self):
        """Test billing resource is initialized."""
        client = NTLClient(api_key="ntl_test_123")
        assert client.billing is not None


class TestNTLClientHTTPMethods:
    """Test NTLClient HTTP methods."""

    def test_get_request(self):
        """Test GET request."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'{"data": "test"}'
            mock_response.json.return_value = {"data": "test"}
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            result = client.get("/test")

            assert result == {"data": "test"}
            mock_instance.request.assert_called_once()
            call_args = mock_instance.request.call_args
            assert call_args.kwargs["method"] == "GET"
            assert call_args.kwargs["url"] == "/test"

    def test_post_request(self):
        """Test POST request."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'{"id": "123"}'
            mock_response.json.return_value = {"id": "123"}
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            result = client.post("/test", json={"name": "test"})

            assert result == {"id": "123"}
            mock_instance.request.assert_called_once()

    def test_put_request(self):
        """Test PUT request."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'{"updated": true}'
            mock_response.json.return_value = {"updated": True}
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            result = client.put("/test/123", json={"name": "updated"})

            assert result == {"updated": True}

    def test_delete_request(self):
        """Test DELETE request."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'{"deleted": true}'
            mock_response.json.return_value = {"deleted": True}
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            result = client.delete("/test/123")

            assert result == {"deleted": True}

    def test_request_with_params(self):
        """Test request with query parameters."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b'{"items": []}'
            mock_response.json.return_value = {"items": []}
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            client.get("/test", params={"page": 1, "limit": 10})

            call_args = mock_instance.request.call_args
            assert call_args.kwargs["params"] == {"page": 1, "limit": 10}

    def test_request_with_custom_headers(self):
        """Test request with custom headers."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b"{}"
            mock_response.json.return_value = {}
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            client.get("/test", headers={"X-Custom": "value"})

            call_args = mock_instance.request.call_args
            assert call_args.kwargs["headers"] == {"X-Custom": "value"}


class TestNTLClientErrorHandling:
    """Test NTLClient error handling."""

    def test_authentication_error(self):
        """Test 401 raises AuthenticationError."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 401
            mock_response.content = b'{"detail": "Invalid API key"}'
            mock_response.json.return_value = {"detail": "Invalid API key"}
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            with pytest.raises(AuthenticationError) as exc_info:
                client.get("/test")
            assert exc_info.value.status_code == 401

    def test_insufficient_credits_error(self):
        """Test 402 raises InsufficientCreditsError."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 402
            mock_response.content = b'{"detail": "No credits"}'
            mock_response.json.return_value = {"detail": "No credits"}
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            with pytest.raises(InsufficientCreditsError) as exc_info:
                client.get("/test")
            assert exc_info.value.status_code == 402

    def test_rate_limit_error(self):
        """Test 429 raises RateLimitError with retry_after."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 429
            mock_response.content = b'{"detail": "Rate limited"}'
            mock_response.json.return_value = {"detail": "Rate limited"}
            mock_response.headers = {"Retry-After": "60"}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            with pytest.raises(RateLimitError) as exc_info:
                client.get("/test")
            assert exc_info.value.status_code == 429
            assert exc_info.value.retry_after == 60

    def test_service_unavailable_error(self):
        """Test 503 raises ServiceUnavailableError."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 503
            mock_response.content = b""
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            with pytest.raises(ServiceUnavailableError) as exc_info:
                client.get("/test")
            assert exc_info.value.status_code == 503

    def test_generic_api_error(self):
        """Test 400+ raises APIError."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 400
            mock_response.content = b'{"detail": "Bad request"}'
            mock_response.json.return_value = {"detail": "Bad request"}
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            with pytest.raises(APIError) as exc_info:
                client.get("/test")
            assert exc_info.value.status_code == 400

    def test_timeout_exception(self):
        """Test timeout raises APIError."""
        with patch("httpx.Client") as mock_client_class:
            mock_instance = MagicMock()
            mock_instance.request.side_effect = httpx.TimeoutException("Timeout")
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123", timeout=30.0)
            with pytest.raises(APIError) as exc_info:
                client.get("/test")
            assert "timeout" in str(exc_info.value).lower()

    def test_request_error(self):
        """Test request error raises APIError."""
        with patch("httpx.Client") as mock_client_class:
            mock_instance = MagicMock()
            mock_instance.request.side_effect = httpx.RequestError("Connection failed")
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            with pytest.raises(APIError) as exc_info:
                client.get("/test")
            assert "request failed" in str(exc_info.value).lower()


class TestNTLClientContextManager:
    """Test NTLClient context manager."""

    def test_context_manager(self):
        """Test client works as context manager."""
        with patch("httpx.Client") as mock_client_class:
            mock_instance = MagicMock()
            mock_client_class.return_value = mock_instance

            with NTLClient(api_key="ntl_test_123") as client:
                assert client.api_key == "ntl_test_123"

            mock_instance.close.assert_called_once()

    def test_close_method(self):
        """Test close method."""
        with patch("httpx.Client") as mock_client_class:
            mock_instance = MagicMock()
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            client.close()

            mock_instance.close.assert_called_once()

    def test_empty_response_handling(self):
        """Test handling of empty response."""
        with patch("httpx.Client") as mock_client_class:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.content = b""
            mock_response.headers = {}

            mock_instance = MagicMock()
            mock_instance.request.return_value = mock_response
            mock_client_class.return_value = mock_instance

            client = NTLClient(api_key="ntl_test_123")
            result = client.get("/test")
            assert result == {}
