"""
NTLabs SDK - Chat Resource Tests
Tests for the ChatResource class, including real SSE streaming.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
"""

import json
from contextlib import contextmanager

import pytest

from ntlabs.exceptions import APIError
from ntlabs.resources.chat import (
    ChatCompletion,
    ChatMessage,
    ChatResource,
    StreamEvent,
    _parse_sse_line,
)

# =============================================================================
# Helpers for mocking SSE streams
# =============================================================================


def _make_sse_lines(events: list[dict]) -> list[str]:
    """Convert a list of event dicts into SSE-formatted lines."""
    lines = []
    for event in events:
        lines.append(f"data: {json.dumps(event)}")
        lines.append("")  # empty line between SSE events
    return lines


class MockStreamResponse:
    """Mock httpx streaming response for sync tests."""

    def __init__(self, lines: list[str], status_code: int = 200):
        self.status_code = status_code
        self._lines = lines

    def iter_lines(self):
        yield from self._lines

    def read(self):
        pass

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


# =============================================================================
# Unit tests: _parse_sse_line
# =============================================================================


class TestParseSSELine:
    """Tests for the SSE line parser."""

    def test_parse_token_event(self):
        """Parse a token event with content."""
        event = _parse_sse_line('data: {"type": "token", "content": "Hello"}')
        assert event is not None
        assert event.type == "token"
        assert event.content == "Hello"

    def test_parse_start_event(self):
        """Parse a start event with agent and session_id."""
        line = 'data: {"type": "start", "agent": "dedalo", "session_id": "sess_123"}'
        event = _parse_sse_line(line)
        assert event is not None
        assert event.type == "start"
        assert event.agent == "dedalo"
        assert event.session_id == "sess_123"

    def test_parse_end_event(self):
        """Parse an end event with metadata."""
        data = {
            "type": "end",
            "intent": "greeting",
            "lead_score": 25,
            "should_handoff": False,
            "latency_ms": 450,
        }
        event = _parse_sse_line(f"data: {json.dumps(data)}")
        assert event is not None
        assert event.type == "end"
        assert event.intent == "greeting"
        assert event.lead_score == 25
        assert event.should_handoff is False
        assert event.latency_ms == 450

    def test_parse_error_event(self):
        """Parse an error event."""
        event = _parse_sse_line('data: {"type": "error", "error": "Something failed"}')
        assert event is not None
        assert event.type == "error"
        assert event.error == "Something failed"

    def test_parse_done_signal(self):
        """[DONE] signal returns None."""
        event = _parse_sse_line("data: [DONE]")
        assert event is None

    def test_parse_empty_line(self):
        """Empty line returns None."""
        assert _parse_sse_line("") is None
        assert _parse_sse_line("   ") is None

    def test_parse_non_data_line(self):
        """Lines without 'data: ' prefix return None."""
        assert _parse_sse_line("event: message") is None
        assert _parse_sse_line(": comment") is None

    def test_parse_invalid_json(self):
        """Invalid JSON returns None (logged as warning)."""
        event = _parse_sse_line("data: {invalid json}")
        assert event is None

    def test_raw_dict_preserved(self):
        """The raw dict is preserved in StreamEvent.raw."""
        data = {"type": "token", "content": "X", "extra_field": True}
        event = _parse_sse_line(f"data: {json.dumps(data)}")
        assert event is not None
        assert event.raw == data
        assert event.raw["extra_field"] is True


# =============================================================================
# Unit tests: StreamEvent dataclass
# =============================================================================


class TestStreamEvent:
    """Tests for StreamEvent dataclass."""

    def test_create_token_event(self):
        """Create a token StreamEvent."""
        event = StreamEvent(type="token", content="Hello")
        assert event.type == "token"
        assert event.content == "Hello"
        assert event.agent is None

    def test_to_dict(self):
        """StreamEvent converts to dict via DataclassMixin."""
        event = StreamEvent(type="start", agent="dedalo", session_id="s1")
        d = event.to_dict()
        assert d["type"] == "start"
        assert d["agent"] == "dedalo"
        assert d["session_id"] == "s1"

    def test_defaults(self):
        """All optional fields default to None or empty dict."""
        event = StreamEvent(type="token")
        assert event.content is None
        assert event.agent is None
        assert event.lead_score is None
        assert event.raw == {}


# =============================================================================
# Unit tests: ChatMessage / ChatCompletion
# =============================================================================


class TestChatMessage:
    """Tests for ChatMessage dataclass."""

    def test_create_user_message(self):
        """Create user message."""
        msg = ChatMessage(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"

    def test_create_assistant_message(self):
        """Create assistant message."""
        msg = ChatMessage(role="assistant", content="Hi there!")
        assert msg.role == "assistant"
        assert msg.content == "Hi there!"

    def test_create_system_message(self):
        """Create system message."""
        msg = ChatMessage(role="system", content="You are a helpful assistant.")
        assert msg.role == "system"


class TestChatCompletion:
    """Tests for ChatCompletion dataclass."""

    def test_create_completion(self):
        """Create chat completion."""
        completion = ChatCompletion(
            id="chat-123",
            content="Hello! How can I help?",
            model="maritaca-sabia-4",
            usage={
                "prompt_tokens": 10,
                "completion_tokens": 20,
                "total_tokens": 30,
            },
            finish_reason="stop",
        )
        assert completion.id == "chat-123"
        assert completion.content == "Hello! How can I help?"
        assert completion.model == "maritaca-sabia-4"
        assert completion.usage["total_tokens"] == 30
        assert completion.finish_reason == "stop"


# =============================================================================
# Integration tests: ChatResource.complete()
# =============================================================================


class TestChatResource:
    """Tests for ChatResource.complete()."""

    def test_initialization(self, mock_client):
        """ChatResource initializes with client."""
        chat = ChatResource(mock_client)
        assert chat._client == mock_client

    def test_complete_basic(self, mock_client, mock_response, chat_response):
        """Basic chat completion."""
        mock_client._mock_http.request.return_value = mock_response(chat_response)

        result = mock_client.chat.complete(
            messages=[{"role": "user", "content": "Hello"}]
        )

        assert isinstance(result, ChatCompletion)
        assert "Como posso ajudar?" in result.content
        assert result.model == "maritaca-sabia-4"

    def test_complete_with_model(self, mock_client, mock_response, chat_response):
        """Chat completion with specific model."""
        mock_client._mock_http.request.return_value = mock_response(chat_response)

        result = mock_client.chat.complete(
            messages=[{"role": "user", "content": "Hello"}],
            model="claude-sonnet",
        )

        assert isinstance(result, ChatCompletion)
        call_kwargs = mock_client._mock_http.request.call_args
        assert "claude-sonnet" in str(call_kwargs)

    def test_complete_with_system_prompt(
        self, mock_client, mock_response, chat_response
    ):
        """Chat completion with system prompt."""
        mock_client._mock_http.request.return_value = mock_response(chat_response)

        result = mock_client.chat.complete(
            messages=[{"role": "user", "content": "What is Python?"}],
            system="You are a programming tutor.",
        )

        assert isinstance(result, ChatCompletion)

    def test_complete_with_parameters(self, mock_client, mock_response, chat_response):
        """Chat completion with all parameters."""
        mock_client._mock_http.request.return_value = mock_response(chat_response)

        result = mock_client.chat.complete(
            messages=[{"role": "user", "content": "Tell me a story"}],
            model="maritaca-sabia-4",
            max_tokens=2048,
            temperature=0.9,
        )

        assert isinstance(result, ChatCompletion)

    def test_complete_multiple_messages(
        self, mock_client, mock_response, chat_response
    ):
        """Chat completion with conversation history."""
        mock_client._mock_http.request.return_value = mock_response(chat_response)

        messages = [
            {"role": "user", "content": "My name is Joao"},
            {"role": "assistant", "content": "Nice to meet you, Joao!"},
            {"role": "user", "content": "What is my name?"},
        ]

        result = mock_client.chat.complete(messages=messages)
        assert isinstance(result, ChatCompletion)

    def test_complete_empty_response(self, mock_client, mock_response):
        """Handle empty response gracefully."""
        mock_client._mock_http.request.return_value = mock_response({})

        result = mock_client.chat.complete(
            messages=[{"role": "user", "content": "Hello"}]
        )

        assert result.id == ""
        assert result.content == ""
        assert result.finish_reason == "stop"

    def test_complete_with_kwargs(self, mock_client, mock_response, chat_response):
        """Chat completion with extra kwargs."""
        mock_client._mock_http.request.return_value = mock_response(chat_response)

        result = mock_client.chat.complete(
            messages=[{"role": "user", "content": "Hello"}],
            top_p=0.95,
            presence_penalty=0.5,
        )

        assert isinstance(result, ChatCompletion)


# =============================================================================
# Integration tests: ChatResource.complete_stream() - real SSE
# =============================================================================


class TestChatResourceStreaming:
    """Tests for ChatResource.complete_stream() with real SSE parsing."""

    def test_stream_yields_token_content(self, mock_client):
        """Streaming yields content from token events."""
        sse_events = [
            {"type": "start", "agent": "dedalo", "session_id": "s1"},
            {"type": "token", "content": "Ola"},
            {"type": "token", "content": "! Como "},
            {"type": "token", "content": "posso ajudar?"},
            {"type": "end", "intent": "greeting", "lead_score": 10},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockStreamResponse(lines)

        @contextmanager
        def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_client._client.stream = fake_stream

        chunks = list(
            mock_client.chat.complete_stream(
                messages=[{"role": "user", "content": "Ola"}],
            )
        )

        assert chunks == ["Ola", "! Como ", "posso ajudar?"]

    def test_stream_handles_empty_content(self, mock_client):
        """Tokens with None/empty content are skipped."""
        sse_events = [
            {"type": "start", "agent": "dedalo"},
            {"type": "token", "content": ""},
            {"type": "token", "content": None},
            {"type": "token", "content": "Hello"},
            {"type": "end"},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockStreamResponse(lines)

        @contextmanager
        def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_client._client.stream = fake_stream

        chunks = list(
            mock_client.chat.complete_stream(
                messages=[{"role": "user", "content": "Hi"}],
            )
        )

        assert chunks == ["Hello"]

    def test_stream_raises_on_error_event(self, mock_client):
        """Error events raise APIError."""
        sse_events = [
            {"type": "start", "agent": "dedalo"},
            {"type": "error", "error": "Agent unavailable"},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockStreamResponse(lines)

        @contextmanager
        def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_client._client.stream = fake_stream

        with pytest.raises(APIError, match="Agent unavailable"):
            list(
                mock_client.chat.complete_stream(
                    messages=[{"role": "user", "content": "Hi"}],
                )
            )

    def test_stream_raises_on_http_error(self, mock_client):
        """HTTP errors raise APIError with status code."""
        mock_stream = MockStreamResponse([], status_code=503)

        @contextmanager
        def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_client._client.stream = fake_stream

        with pytest.raises(APIError, match="503"):
            list(
                mock_client.chat.complete_stream(
                    messages=[{"role": "user", "content": "Hi"}],
                )
            )

    def test_stream_stops_at_end_event(self, mock_client):
        """Stream stops processing after end event."""
        sse_events = [
            {"type": "start", "agent": "dedalo"},
            {"type": "token", "content": "A"},
            {"type": "end", "intent": "casual"},
            {"type": "token", "content": "B"},  # should not be yielded
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockStreamResponse(lines)

        @contextmanager
        def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_client._client.stream = fake_stream

        chunks = list(
            mock_client.chat.complete_stream(
                messages=[{"role": "user", "content": "Hi"}],
            )
        )

        assert chunks == ["A"]

    def test_stream_with_session_and_user(self, mock_client):
        """Session ID and user ID are included in the request payload."""
        sse_events = [
            {"type": "start", "agent": "chiron", "session_id": "s42"},
            {"type": "token", "content": "Hi"},
            {"type": "end"},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockStreamResponse(lines)

        captured_kwargs = {}

        @contextmanager
        def fake_stream(method, url, **kwargs):
            captured_kwargs.update(kwargs)
            yield mock_stream

        mock_client._client.stream = fake_stream

        chunks = list(
            mock_client.chat.complete_stream(
                messages=[{"role": "user", "content": "Hi"}],
                agent="chiron",
                session_id="s42",
                user_id="u99",
            )
        )

        assert chunks == ["Hi"]
        payload = captured_kwargs["json"]
        assert payload["agent"] == "chiron"
        assert payload["session_id"] == "s42"
        assert payload["user_id"] == "u99"


# =============================================================================
# Integration tests: ChatResource.complete_stream_events()
# =============================================================================


class TestChatResourceStreamEvents:
    """Tests for ChatResource.complete_stream_events() (full event objects)."""

    def test_yields_all_event_types(self, mock_client):
        """All event types are yielded as StreamEvent objects."""
        sse_events = [
            {"type": "start", "agent": "dedalo", "session_id": "s1"},
            {"type": "token", "content": "Hi"},
            {"type": "end", "intent": "greeting", "lead_score": 30},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockStreamResponse(lines)

        @contextmanager
        def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_client._client.stream = fake_stream

        events = list(
            mock_client.chat.complete_stream_events(
                messages=[{"role": "user", "content": "Hi"}],
            )
        )

        assert len(events) == 3
        assert events[0].type == "start"
        assert events[0].agent == "dedalo"
        assert events[1].type == "token"
        assert events[1].content == "Hi"
        assert events[2].type == "end"
        assert events[2].lead_score == 30

    def test_stops_after_error_event(self, mock_client):
        """Stops yielding after an error event."""
        sse_events = [
            {"type": "start", "agent": "dedalo"},
            {"type": "error", "error": "timeout"},
            {"type": "token", "content": "should not appear"},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockStreamResponse(lines)

        @contextmanager
        def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_client._client.stream = fake_stream

        events = list(
            mock_client.chat.complete_stream_events(
                messages=[{"role": "user", "content": "Hi"}],
            )
        )

        assert len(events) == 2
        assert events[1].type == "error"
        assert events[1].error == "timeout"


# =============================================================================
# Usage tracking tests
# =============================================================================


class TestChatResourceUsage:
    """Tests for usage tracking in chat responses."""

    def test_usage_tokens(self, mock_client, mock_response, chat_response):
        """Usage tokens are tracked."""
        mock_client._mock_http.request.return_value = mock_response(chat_response)

        result = mock_client.chat.complete(
            messages=[{"role": "user", "content": "Hello"}]
        )

        assert result.usage["prompt_tokens"] == 10
        assert result.usage["completion_tokens"] == 20

    def test_missing_usage(self, mock_client, mock_response):
        """Handle missing usage gracefully."""
        mock_client._mock_http.request.return_value = mock_response(
            {"choices": [{"message": {"content": "Hi"}, "finish_reason": "stop"}]}
        )

        result = mock_client.chat.complete(
            messages=[{"role": "user", "content": "Hello"}]
        )

        assert result.usage == {}
