"""
Neural LAB SDK - PDF Resource Tests
Tests for the PDF resource.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
"""

import base64
from unittest.mock import MagicMock

import pytest

from ntlabs.resources.pdf import PDFDocument, PDFResource, PDFSection, PDFTemplate


class TestPDFDocument:
    """Tests for PDFDocument dataclass."""

    def test_pdf_document_creation(self):
        """Test PDFDocument creation."""
        pdf_data = b"%PDF-1.4 content"
        doc = PDFDocument(
            success=True,
            data=pdf_data,
            data_base64=base64.b64encode(pdf_data).decode("utf-8"),
            pages=2,
            size_bytes=len(pdf_data),
            cost_brl=0.04,
            latency_ms=150,
        )

        assert doc.success is True
        assert doc.data == pdf_data
        assert doc.pages == 2
        assert doc.cost_brl == 0.04

    def test_pdf_document_to_dict(self):
        """Test PDFDocument to_dict method."""
        doc = PDFDocument(
            success=True,
            data=b"test",
            pages=1,
        )

        data = doc.to_dict()
        assert data["success"] is True
        assert data["pages"] == 1


class TestPDFSection:
    """Tests for PDFSection dataclass."""

    def test_section_with_content(self):
        """Test section with text content."""
        section = PDFSection(
            title="Introduction",
            content="This is the introduction.",
        )

        assert section.title == "Introduction"
        assert section.content == "This is the introduction."

    def test_section_with_table(self):
        """Test section with table data."""
        section = PDFSection(
            title="Data",
            table_headers=["Name", "Value"],
            table_rows=[["A", "100"], ["B", "200"]],
        )

        assert section.table_headers == ["Name", "Value"]
        assert len(section.table_rows) == 2


class TestPDFTemplate:
    """Tests for PDFTemplate dataclass."""

    def test_template_creation(self):
        """Test template creation."""
        template = PDFTemplate(
            name="report",
            description="General report template",
            fields=["title", "author", "sections"],
        )

        assert template.name == "report"
        assert len(template.fields) == 3


class TestPDFResource:
    """Tests for PDFResource."""

    @pytest.fixture
    def mock_client(self):
        """Create mock client."""
        client = MagicMock()
        return client

    @pytest.fixture
    def pdf_resource(self, mock_client):
        """Create PDFResource with mock client."""
        return PDFResource(mock_client)

    def test_generate_pdf(self, pdf_resource, mock_client):
        """Test generating a PDF."""
        pdf_content = b"%PDF-1.4 test"
        mock_client.post.return_value = {
            "success": True,
            "data": base64.b64encode(pdf_content).decode("utf-8"),
            "pages": 1,
            "size_bytes": len(pdf_content),
            "cost_brl": 0.02,
            "latency_ms": 100,
        }

        result = pdf_resource.generate(
            title="Test Document",
            template="report",
            sections=[PDFSection(title="Section 1", content="Content")],
        )

        assert result.success is True
        assert result.data == pdf_content
        assert result.pages == 1
        mock_client.post.assert_called_once()

    def test_generate_report(self, pdf_resource, mock_client):
        """Test generating a report."""
        pdf_content = b"%PDF-1.4 report"
        mock_client.post.return_value = {
            "success": True,
            "data": base64.b64encode(pdf_content).decode("utf-8"),
            "pages": 3,
            "size_bytes": len(pdf_content),
            "cost_brl": 0.06,
            "latency_ms": 200,
        }

        result = pdf_resource.generate_report(
            title="Monthly Report",
            author="Test Author",
            summary=[("Total", 100), ("Active", 80)],
            sections=[{"title": "Details", "content": "Details here"}],
        )

        assert result.success is True
        assert result.pages == 3
        mock_client.post.assert_called_with(
            "/v1/pdf/report",
            json={
                "title": "Monthly Report",
                "author": "Test Author",
                "summary": [("Total", 100), ("Active", 80)],
                "sections": [{"title": "Details", "content": "Details here"}],
                "footer_text": None,
                "output_format": "base64",
            },
        )

    def test_generate_invoice(self, pdf_resource, mock_client):
        """Test generating an invoice."""
        pdf_content = b"%PDF-1.4 invoice"
        mock_client.post.return_value = {
            "success": True,
            "data": base64.b64encode(pdf_content).decode("utf-8"),
            "pages": 1,
            "size_bytes": len(pdf_content),
            "cost_brl": 0.02,
            "latency_ms": 150,
        }

        result = pdf_resource.generate_invoice(
            invoice_number="INV-001",
            customer_name="ACME Corp",
            items=[
                {
                    "description": "Service",
                    "quantity": 1,
                    "unit_price": 100,
                    "total": 100,
                }
            ],
            total=100.0,
            currency="BRL",
        )

        assert result.success is True
        assert result.pages == 1
        mock_client.post.assert_called_once()

    def test_list_templates(self, pdf_resource, mock_client):
        """Test listing templates."""
        mock_client.get.return_value = {
            "templates": [
                {"name": "report", "description": "Report", "fields": ["title"]},
                {"name": "invoice", "description": "Invoice", "fields": ["number"]},
            ]
        }

        templates = pdf_resource.list_templates()

        assert len(templates) == 2
        assert templates[0].name == "report"
        assert templates[1].name == "invoice"
        mock_client.get.assert_called_with("/v1/pdf/templates")

    def test_health(self, pdf_resource, mock_client):
        """Test health check."""
        mock_client.get.return_value = {
            "status": "ok",
            "reportlab_available": True,
            "supported_templates": ["report", "invoice"],
        }

        health = pdf_resource.health()

        assert health["status"] == "ok"
        assert health["reportlab_available"] is True
        mock_client.get.assert_called_with("/v1/pdf/health")
