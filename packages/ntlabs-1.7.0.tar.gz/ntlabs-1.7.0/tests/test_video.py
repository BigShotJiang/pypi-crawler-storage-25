"""
NTLabs SDK - Video Resource Tests
Tests for the VideoResource class (video conferencing).

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
"""

from ntlabs.resources.video import (
    VideoRecording,
    VideoResource,
    VideoRoom,
    VideoSessionEnd,
    VideoSessionStatus,
)


class TestVideoRoom:
    """Tests for VideoRoom dataclass."""

    def test_create_room(self):
        """Create video room."""
        room = VideoRoom(
            session_id="sess_123",
            room_url="https://test.daily.co/room-123",
            room_name="hipocrates-sess_123",
            token="token_abc",
            expires_at="2026-02-02T14:00:00Z",
            is_mock=False,
            latency_ms=150,
        )
        assert room.session_id == "sess_123"
        assert "daily.co" in room.room_url
        assert room.is_mock is False

    def test_room_to_dict(self):
        """Room can be converted to dict."""
        room = VideoRoom(
            session_id="sess_123",
            room_url="https://test.daily.co/room-123",
            room_name="room-123",
        )
        data = room.to_dict()
        assert data["session_id"] == "sess_123"
        assert "room_url" in data


class TestVideoSessionStatus:
    """Tests for VideoSessionStatus dataclass."""

    def test_create_status(self):
        """Create session status."""
        status = VideoSessionStatus(
            session_id="sess_123",
            status="active",
            participants=2,
            is_recording=True,
        )
        assert status.status == "active"
        assert status.participants == 2


class TestVideoSessionEnd:
    """Tests for VideoSessionEnd dataclass."""

    def test_create_session_end(self):
        """Create session end result."""
        result = VideoSessionEnd(
            session_id="sess_123",
            recording_url="https://daily.co/recordings/abc.mp4",
            transcript="Hello, how are you?",
            duration_seconds=300,
            cost_brl=0.5,
        )
        assert result.duration_seconds == 300
        assert result.cost_brl == 0.5


class TestVideoResource:
    """Tests for VideoResource."""

    def test_initialization(self, mock_client):
        """VideoResource initializes with client."""
        video = VideoResource(mock_client)
        assert video._client == mock_client

    def test_create_room(self, mock_client, mock_response):
        """Create video room."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "session_id": "sess_123",
                "room_url": "https://test.daily.co/room-123",
                "room_name": "hipocrates-sess_123",
                "token": "token_abc",
                "expires_at": "2026-02-02T14:00:00Z",
                "is_mock": False,
                "latency_ms": 150,
            }
        )

        room = mock_client.video.create_room(
            session_id="sess_123",
            room_prefix="hipocrates",
            enable_recording=True,
        )

        assert isinstance(room, VideoRoom)
        assert room.session_id == "sess_123"
        assert room.room_name == "hipocrates-sess_123"

    def test_create_room_with_custom_name(self, mock_client, mock_response):
        """Create room with custom name."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "session_id": "sess_123",
                "room_url": "https://test.daily.co/custom-room",
                "room_name": "custom-room",
                "token": None,
                "expires_at": None,
                "is_mock": False,
                "latency_ms": 100,
            }
        )

        room = mock_client.video.create_room(
            session_id="sess_123",
            room_name="custom-room",
        )

        assert room.room_name == "custom-room"

    def test_create_room_all_options(self, mock_client, mock_response):
        """Create room with all options."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "session_id": "sess_456",
                "room_url": "https://test.daily.co/mercurius-sess_456",
                "room_name": "mercurius-sess_456",
                "token": "token_xyz",
                "expires_at": "2026-02-02T16:00:00Z",
                "is_mock": False,
                "latency_ms": 200,
            }
        )

        room = mock_client.video.create_room(
            session_id="sess_456",
            room_prefix="mercurius",
            enable_recording=True,
            enable_transcription=True,
            enable_chat=True,
            max_participants=50,
            expiry_minutes=120,
        )

        assert isinstance(room, VideoRoom)
        assert "mercurius" in room.room_name

    def test_end_session(self, mock_client, mock_response):
        """End video session."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "session_id": "sess_123",
                "recording_url": "https://daily.co/recordings/abc.mp4",
                "transcript": "Hello, how are you?",
                "duration_seconds": 300,
                "cost_brl": 0.5,
                "latency_ms": 100,
            }
        )

        result = mock_client.video.end_session("sess_123")

        assert isinstance(result, VideoSessionEnd)
        assert result.duration_seconds == 300
        assert result.cost_brl == 0.5
        assert result.recording_url is not None

    def test_end_session_no_recording(self, mock_client, mock_response):
        """End session without recording."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "session_id": "sess_123",
                "recording_url": None,
                "transcript": None,
                "duration_seconds": 0,
                "cost_brl": 0.0,
                "latency_ms": 50,
            }
        )

        result = mock_client.video.end_session("sess_123")

        assert result.recording_url is None
        assert result.duration_seconds == 0

    def test_get_status(self, mock_client, mock_response):
        """Get session status."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "session_id": "sess_123",
                "status": "active",
                "participants": 2,
                "is_recording": True,
                "started_at": "2026-02-02T13:00:00Z",
                "ended_at": None,
                "latency_ms": 50,
            }
        )

        status = mock_client.video.get_status("sess_123")

        assert isinstance(status, VideoSessionStatus)
        assert status.status == "active"
        assert status.participants == 2
        assert status.is_recording is True

    def test_get_status_pending(self, mock_client, mock_response):
        """Get pending session status."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "session_id": "sess_123",
                "status": "pending",
                "participants": 0,
                "is_recording": False,
                "latency_ms": 30,
            }
        )

        status = mock_client.video.get_status("sess_123")

        assert status.status == "pending"
        assert status.participants == 0

    def test_get_recording(self, mock_client, mock_response):
        """Get recording URL."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "session_id": "sess_123",
                "recording_url": "https://daily.co/recordings/abc.mp4",
                "duration_seconds": 600,
                "latency_ms": 100,
            }
        )

        recording = mock_client.video.get_recording("sess_123")

        assert isinstance(recording, VideoRecording)
        assert recording.recording_url is not None
        assert recording.duration_seconds == 600

    def test_get_recording_not_found(self, mock_client, mock_response):
        """Handle recording not found."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "session_id": "sess_123",
                "recording_url": None,
                "duration_seconds": 0,
                "latency_ms": 50,
            }
        )

        recording = mock_client.video.get_recording("sess_123")

        assert recording.recording_url is None

    def test_health(self, mock_client, mock_response):
        """Check video service health."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "status": "ok",
                "daily_configured": True,
                "pipecat_configured": True,
                "domain": "test-domain",
            }
        )

        health = mock_client.video.health()

        assert health["status"] == "ok"
        assert health["daily_configured"] is True

    def test_health_not_configured(self, mock_client, mock_response):
        """Health when not configured."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "status": "unavailable",
                "daily_configured": False,
                "pipecat_configured": False,
                "domain": None,
            }
        )

        health = mock_client.video.health()

        assert health["status"] == "unavailable"
        assert health["daily_configured"] is False

    def test_empty_response_handling(self, mock_client, mock_response):
        """Handle empty response gracefully."""
        mock_client._mock_http.request.return_value = mock_response({})

        room = mock_client.video.create_room(session_id="sess_123")

        assert room.room_url == ""
        assert room.room_name == ""
        assert room.is_mock is False
