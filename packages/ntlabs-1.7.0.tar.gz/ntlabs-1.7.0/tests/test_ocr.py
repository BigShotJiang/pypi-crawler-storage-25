"""
NTLabs SDK - OCR Resource Tests
Tests for the OCRResource class (text extraction from images).

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
"""

import io
from pathlib import Path
from unittest.mock import mock_open, patch

from ntlabs.resources.ocr import (
    OCRLanguage,
    OCRResource,
    OCRResult,
)


class TestOCRResult:
    """Tests for OCRResult dataclass."""

    def test_create_result(self, ocr_response):
        """Create OCR result."""
        result = OCRResult(
            text=ocr_response["text"],
            raw_text=ocr_response["raw_text"],
            confidence=ocr_response["confidence"],
            word_count=ocr_response["word_count"],
            line_count=ocr_response["line_count"],
            language=ocr_response["language"],
            latency_ms=ocr_response["latency_ms"],
            cost_brl=ocr_response["cost_brl"],
        )
        assert result.text == "Texto extraído do documento."
        assert result.confidence == 92.5
        assert result.word_count == 4

    def test_result_to_dict(self, ocr_response):
        """Result can be converted to dict."""
        result = OCRResult(
            text=ocr_response["text"],
            raw_text=ocr_response["raw_text"],
            confidence=ocr_response["confidence"],
            word_count=ocr_response["word_count"],
            line_count=ocr_response["line_count"],
            language=ocr_response["language"],
            latency_ms=ocr_response["latency_ms"],
            cost_brl=ocr_response["cost_brl"],
        )
        data = result.to_dict()
        assert data["text"] == "Texto extraído do documento."


class TestOCRLanguage:
    """Tests for OCRLanguage dataclass."""

    def test_create_language(self):
        """Create OCR language."""
        lang = OCRLanguage(
            code="por+eng",
            name="Portuguese + English",
            available=True,
        )
        assert lang.code == "por+eng"
        assert lang.available is True


class TestOCRResource:
    """Tests for OCRResource."""

    def test_initialization(self, mock_client):
        """OCRResource initializes with client."""
        ocr = OCRResource(mock_client)
        assert ocr._client == mock_client

    def test_extract_from_bytes(self, mock_client, mock_response, ocr_response):
        """Extract text from bytes."""
        mock_client._mock_http.request.return_value = mock_response(ocr_response)

        image_bytes = b"fake image content"
        result = mock_client.ocr.extract(image_bytes)

        assert isinstance(result, OCRResult)
        assert result.text == "Texto extraído do documento."

    def test_extract_from_file_object(self, mock_client, mock_response, ocr_response):
        """Extract text from file object."""
        mock_client._mock_http.request.return_value = mock_response(ocr_response)

        file_obj = io.BytesIO(b"fake image content")
        result = mock_client.ocr.extract(file_obj)

        assert isinstance(result, OCRResult)
        assert result.language == "por+eng"

    def test_extract_from_path_string(self, mock_client, mock_response, ocr_response):
        """Extract text from path string."""
        mock_client._mock_http.request.return_value = mock_response(ocr_response)

        with patch("builtins.open", mock_open(read_data=b"fake image")):
            with patch.object(Path, "exists", return_value=True):
                result = mock_client.ocr.extract("/path/to/image.png")

        assert isinstance(result, OCRResult)

    def test_extract_from_path_object(self, mock_client, mock_response, ocr_response):
        """Extract text from Path object."""
        mock_client._mock_http.request.return_value = mock_response(ocr_response)

        with patch("builtins.open", mock_open(read_data=b"fake image")):
            with patch.object(Path, "exists", return_value=True):
                result = mock_client.ocr.extract(Path("/path/to/document.jpg"))

        assert isinstance(result, OCRResult)

    def test_extract_with_language(self, mock_client, mock_response, ocr_response):
        """Extract text with specific language."""
        mock_client._mock_http.request.return_value = mock_response(ocr_response)

        result = mock_client.ocr.extract(
            b"fake image",
            language="por",
        )

        assert isinstance(result, OCRResult)

    def test_extract_with_preprocess(self, mock_client, mock_response, ocr_response):
        """Extract text with preprocessing disabled."""
        mock_client._mock_http.request.return_value = mock_response(ocr_response)

        result = mock_client.ocr.extract(
            b"fake image",
            preprocess=False,
        )

        assert isinstance(result, OCRResult)

    def test_extract_with_all_options(self, mock_client, mock_response, ocr_response):
        """Extract text with all options."""
        mock_client._mock_http.request.return_value = mock_response(ocr_response)

        result = mock_client.ocr.extract(
            b"fake image",
            language="por+eng",
            preprocess=True,
        )

        assert isinstance(result, OCRResult)
        assert result.confidence == 92.5

    def test_get_languages(self, mock_client, mock_response):
        """Get available OCR languages."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "languages": [
                    {
                        "code": "por",
                        "name": "Portuguese",
                        "available": True,
                    },
                    {
                        "code": "eng",
                        "name": "English",
                        "available": True,
                    },
                    {
                        "code": "por+eng",
                        "name": "Portuguese + English",
                        "available": True,
                    },
                ]
            }
        )

        languages = mock_client.ocr.get_languages()

        assert len(languages) == 3
        assert all(isinstance(lang, OCRLanguage) for lang in languages)
        assert languages[0].code == "por"

    def test_get_languages_empty(self, mock_client, mock_response):
        """Handle empty languages list."""
        mock_client._mock_http.request.return_value = mock_response({})

        languages = mock_client.ocr.get_languages()
        assert languages == []

    def test_health(self, mock_client, mock_response):
        """Check OCR service health."""
        mock_client._mock_http.request.return_value = mock_response(
            {
                "status": "ok",
                "tesseract_available": True,
                "tesseract_version": "5.3.0",
                "available_languages": ["por", "eng", "spa"],
            }
        )

        health = mock_client.ocr.health()

        assert health["status"] == "ok"
        assert health["tesseract_available"] is True

    def test_extract_empty_response(self, mock_client, mock_response):
        """Handle empty response gracefully."""
        mock_client._mock_http.request.return_value = mock_response({})

        result = mock_client.ocr.extract(b"fake image")

        assert result.text == ""
        assert result.confidence == 0
        assert result.word_count == 0

    def test_extract_file_object_name(self, mock_client, mock_response, ocr_response):
        """Uses file object name if available."""
        mock_client._mock_http.request.return_value = mock_response(ocr_response)

        file_obj = io.BytesIO(b"fake image")
        file_obj.name = "document.tiff"
        result = mock_client.ocr.extract(file_obj)

        assert isinstance(result, OCRResult)

    def test_extract_includes_metrics(self, mock_client, mock_response, ocr_response):
        """Extraction includes performance metrics."""
        mock_client._mock_http.request.return_value = mock_response(ocr_response)

        result = mock_client.ocr.extract(b"fake image")

        assert result.latency_ms == 350
        assert result.cost_brl == 0.015
