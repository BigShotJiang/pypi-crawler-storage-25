"""
Tests for common validators.

Author: Anderson Henrique da Silva
Date: 2026-02-04
"""

from datetime import date

from ntlabs.validators.common import (
    DISPOSABLE_DOMAINS,
    calculate_password_strength,
    extract_domain_from_url,
    generate_uuid,
    get_email_domain,
    get_ip_version,
    is_valid_date,
    is_valid_email,
    is_valid_ip,
    is_valid_url,
    is_valid_uuid,
    normalize_email,
    parse_date,
    validate_date,
    validate_email,
    validate_ip,
    validate_length,
    validate_numeric_range,
    validate_password,
    validate_url,
    validate_uuid,
)


class TestEmailValidation:
    """Test email validation functions."""

    def test_valid_email(self):
        """Test valid email addresses."""
        assert validate_email("user@example.com") is True
        assert validate_email("test.user@domain.co.uk") is True
        assert validate_email("user+tag@example.org") is True
        assert validate_email("user_name@example.com") is True

    def test_valid_email_with_subdomain(self):
        """Test valid email with multiple subdomains."""
        assert validate_email("user@sub.domain.example.com") is True

    def test_invalid_email_no_at(self):
        """Test invalid email without @."""
        assert validate_email("userexample.com") is False

    def test_invalid_email_no_domain(self):
        """Test invalid email without domain."""
        assert validate_email("user@") is False

    def test_invalid_email_no_user(self):
        """Test invalid email without user part."""
        assert validate_email("@example.com") is False

    def test_invalid_email_empty(self):
        """Test invalid empty email."""
        assert validate_email("") is False
        assert validate_email(None) is False

    def test_invalid_email_wrong_type(self):
        """Test invalid email with wrong type."""
        assert validate_email(123) is False

    def test_disposable_email_allowed(self):
        """Test disposable email allowed by default."""
        assert validate_email("test@tempmail.com") is True

    def test_disposable_email_blocked(self):
        """Test disposable email blocked when not allowed."""
        assert validate_email("test@tempmail.com", allow_disposable=False) is False
        assert validate_email("test@yopmail.com", allow_disposable=False) is False

    def test_disposable_domains_list(self):
        """Test disposable domains list is populated."""
        assert len(DISPOSABLE_DOMAINS) > 0
        assert "tempmail.com" in DISPOSABLE_DOMAINS
        assert "mailinator.com" in DISPOSABLE_DOMAINS

    def test_normalize_email(self):
        """Test email normalization."""
        assert normalize_email("  User@Example.COM  ") == "user@example.com"
        assert normalize_email("USER@DOMAIN.COM") == "user@domain.com"

    def test_normalize_email_empty(self):
        """Test normalize_email with empty input."""
        assert normalize_email("") == ""
        assert normalize_email(None) == ""

    def test_get_email_domain(self):
        """Test extracting domain from email."""
        assert get_email_domain("user@example.com") == "example.com"
        assert get_email_domain("user@sub.domain.com") == "sub.domain.com"

    def test_get_email_domain_invalid(self):
        """Test get_email_domain with invalid email."""
        assert get_email_domain("invalid-email") is None

    def test_is_valid_email_alias(self):
        """Test is_valid_email is alias for validate_email."""
        assert is_valid_email is validate_email


class TestURLValidation:
    """Test URL validation functions."""

    def test_valid_http_url(self):
        """Test valid HTTP URL."""
        assert validate_url("http://example.com") is True
        assert validate_url("http://www.example.com/path") is True

    def test_valid_https_url(self):
        """Test valid HTTPS URL."""
        assert validate_url("https://example.com") is True
        assert validate_url("https://api.example.com/v1/users") is True

    def test_valid_url_with_query(self):
        """Test valid URL with query string."""
        assert validate_url("https://example.com?key=value") is True
        assert validate_url("https://example.com?key=value&other=test") is True

    def test_valid_url_with_port(self):
        """Test valid URL with port."""
        assert validate_url("http://localhost:8080") is True
        assert validate_url("https://example.com:443/path") is True

    def test_invalid_url_no_scheme(self):
        """Test invalid URL without scheme."""
        assert validate_url("example.com") is False

    def test_invalid_url_wrong_scheme(self):
        """Test invalid URL with wrong scheme."""
        assert validate_url("ftp://example.com") is False
        assert validate_url("file:///etc/passwd") is False

    def test_invalid_url_empty(self):
        """Test invalid empty URL."""
        assert validate_url("") is False
        assert validate_url(None) is False

    def test_url_allowed_schemes(self):
        """Test URL with allowed schemes."""
        assert (
            validate_url("ftp://example.com", allowed_schemes=["http", "https", "ftp"])
            is True
        )

    def test_url_require_https(self):
        """Test URL with HTTPS required."""
        assert validate_url("https://example.com", require_https=True) is True
        assert validate_url("http://example.com", require_https=True) is False

    def test_extract_domain_from_url(self):
        """Test extracting domain from URL."""
        assert (
            extract_domain_from_url("https://www.example.com/path") == "www.example.com"
        )
        assert (
            extract_domain_from_url("http://api.example.com:8080/v1")
            == "api.example.com"
        )

    def test_extract_domain_from_url_empty(self):
        """Test extract_domain_from_url with empty input."""
        assert extract_domain_from_url("") is None
        assert extract_domain_from_url(None) is None

    def test_is_valid_url_alias(self):
        """Test is_valid_url is alias for validate_url."""
        assert is_valid_url is validate_url


class TestUUIDValidation:
    """Test UUID validation functions."""

    def test_valid_uuid_v4(self):
        """Test valid UUID v4."""
        assert validate_uuid("550e8400-e29b-41d4-a716-446655440000") is True

    def test_valid_uuid_any_version(self):
        """Test valid UUID any version."""
        assert validate_uuid("550e8400-e29b-11d4-a716-446655440000") is True  # v1
        assert validate_uuid("550e8400-e29b-21d4-a716-446655440000") is True  # v2
        assert validate_uuid("550e8400-e29b-31d4-a716-446655440000") is True  # v3

    def test_invalid_uuid_wrong_format(self):
        """Test invalid UUID with wrong format."""
        assert validate_uuid("not-a-uuid") is False
        assert validate_uuid("550e8400e29b41d4a716446655440000") is False  # No dashes

    def test_invalid_uuid_empty(self):
        """Test invalid empty UUID."""
        assert validate_uuid("") is False
        assert validate_uuid(None) is False

    def test_validate_uuid_version(self):
        """Test UUID validation with specific version."""
        assert validate_uuid("550e8400-e29b-41d4-a716-446655440000", version=4) is True
        assert (
            validate_uuid("550e8400-e29b-11d4-a716-446655440000", version=4) is False
        )  # v1

    def test_generate_uuid_v4(self):
        """Test UUID v4 generation."""
        uuid = generate_uuid(version=4)
        assert validate_uuid(uuid, version=4) is True

    def test_generate_uuid_v1(self):
        """Test UUID v1 generation."""
        uuid = generate_uuid(version=1)
        assert validate_uuid(uuid, version=1) is True

    def test_generate_uuid_default(self):
        """Test UUID generation default (v4)."""
        uuid = generate_uuid()
        assert validate_uuid(uuid, version=4) is True

    def test_is_valid_uuid_alias(self):
        """Test is_valid_uuid is alias for validate_uuid."""
        assert is_valid_uuid is validate_uuid


class TestIPValidation:
    """Test IP address validation functions."""

    def test_valid_ipv4(self):
        """Test valid IPv4 addresses."""
        assert validate_ip("192.168.1.1") is True
        assert validate_ip("10.0.0.1") is True
        assert validate_ip("127.0.0.1") is True

    def test_valid_ipv6(self):
        """Test valid IPv6 addresses."""
        assert validate_ip("::1") is True
        assert validate_ip("2001:db8::1") is True
        assert validate_ip("fe80::1") is True

    def test_invalid_ip(self):
        """Test invalid IP addresses."""
        assert validate_ip("256.1.1.1") is False
        assert validate_ip("192.168.1") is False
        assert validate_ip("not-an-ip") is False

    def test_invalid_ip_empty(self):
        """Test invalid empty IP."""
        assert validate_ip("") is False
        assert validate_ip(None) is False

    def test_validate_ip_version_4(self):
        """Test IP validation with version 4 only."""
        assert validate_ip("192.168.1.1", version=4) is True
        assert validate_ip("::1", version=4) is False

    def test_validate_ip_version_6(self):
        """Test IP validation with version 6 only."""
        assert validate_ip("::1", version=6) is True
        assert validate_ip("192.168.1.1", version=6) is False

    def test_validate_ip_no_private(self):
        """Test IP validation rejecting private IPs."""
        assert validate_ip("192.168.1.1", allow_private=False) is False
        assert validate_ip("8.8.8.8", allow_private=False) is True  # Public

    def test_validate_ip_no_loopback(self):
        """Test IP validation rejecting loopback."""
        assert validate_ip("127.0.0.1", allow_loopback=False) is False
        assert validate_ip("192.168.1.1", allow_loopback=False) is True

    def test_get_ip_version(self):
        """Test getting IP version."""
        assert get_ip_version("192.168.1.1") == 4
        assert get_ip_version("::1") == 6

    def test_get_ip_version_invalid(self):
        """Test get_ip_version with invalid IP."""
        assert get_ip_version("invalid") is None

    def test_is_valid_ip_alias(self):
        """Test is_valid_ip is alias for validate_ip."""
        assert is_valid_ip is validate_ip


class TestPasswordValidation:
    """Test password validation functions."""

    def test_valid_password(self):
        """Test valid password."""
        is_valid, errors = validate_password("SecurePass123")
        assert is_valid is True
        assert len(errors) == 0

    def test_invalid_password_too_short(self):
        """Test password too short."""
        is_valid, errors = validate_password("Short1")
        assert is_valid is False
        assert any("8" in e for e in errors)

    def test_invalid_password_no_uppercase(self):
        """Test password without uppercase."""
        is_valid, errors = validate_password("lowercase123")
        assert is_valid is False
        assert any("uppercase" in e.lower() for e in errors)

    def test_invalid_password_no_lowercase(self):
        """Test password without lowercase."""
        is_valid, errors = validate_password("UPPERCASE123")
        assert is_valid is False
        assert any("lowercase" in e.lower() for e in errors)

    def test_invalid_password_no_digit(self):
        """Test password without digit."""
        is_valid, errors = validate_password("NoDigitsHere")
        assert is_valid is False
        assert any("digit" in e.lower() for e in errors)

    def test_password_with_special_char(self):
        """Test password requiring special character."""
        is_valid, errors = validate_password("SecurePass123!", require_special=True)
        assert is_valid is True

    def test_password_without_required_special_char(self):
        """Test password missing required special character."""
        is_valid, errors = validate_password("SecurePass123", require_special=True)
        assert is_valid is False
        assert any("special" in e.lower() for e in errors)

    def test_password_empty(self):
        """Test empty password."""
        is_valid, errors = validate_password("")
        assert is_valid is False
        assert any("empty" in e.lower() for e in errors)

    def test_calculate_password_strength(self):
        """Test password strength calculation."""
        # Very weak
        assert calculate_password_strength("123") < 20

        # Medium strength
        strength = calculate_password_strength("Password123")
        assert 40 <= strength <= 80

        # Strong
        strength = calculate_password_strength("VeryStrongP@ssw0rd!123")
        assert strength > 80

    def test_password_strength_with_patterns(self):
        """Test password strength with common patterns."""
        # Common patterns reduce score
        strength1 = calculate_password_strength("Password123")
        strength2 = calculate_password_strength("Qwerty123")
        assert strength2 < strength1

    def test_password_strength_empty(self):
        """Test password strength for empty password."""
        assert calculate_password_strength("") == 0


class TestDateValidation:
    """Test date validation functions."""

    def test_valid_date_iso(self):
        """Test valid ISO format date."""
        assert validate_date("2026-01-27") is True

    def test_valid_date_custom_format(self):
        """Test valid date with custom format."""
        assert validate_date("27/01/2026", format="%d/%m/%Y") is True
        assert validate_date("01/27/2026", format="%m/%d/%Y") is True

    def test_invalid_date(self):
        """Test invalid date."""
        assert validate_date("2026-13-27") is False  # Invalid month
        assert validate_date("2026-01-32") is False  # Invalid day
        assert validate_date("not-a-date") is False

    def test_invalid_date_empty(self):
        """Test invalid empty date."""
        assert validate_date("") is False
        assert validate_date(None) is False

    def test_validate_date_with_min(self):
        """Test date validation with minimum date."""
        min_date = date(2026, 1, 1)
        assert validate_date("2026-01-15", min_date=min_date) is True
        assert validate_date("2025-12-31", min_date=min_date) is False

    def test_validate_date_with_max(self):
        """Test date validation with maximum date."""
        max_date = date(2026, 12, 31)
        assert validate_date("2026-06-15", max_date=max_date) is True
        assert validate_date("2027-01-01", max_date=max_date) is False

    def test_parse_date(self):
        """Test date parsing."""
        parsed = parse_date("2026-01-27")
        assert parsed == date(2026, 1, 27)

    def test_parse_date_custom_format(self):
        """Test date parsing with custom format."""
        parsed = parse_date("27/01/2026", format="%d/%m/%Y")
        assert parsed == date(2026, 1, 27)

    def test_parse_date_invalid(self):
        """Test parsing invalid date."""
        assert parse_date("invalid") is None
        assert parse_date("2026-13-27") is None

    def test_is_valid_date_alias(self):
        """Test is_valid_date is alias for validate_date."""
        assert is_valid_date is validate_date


class TestGenericValidators:
    """Test generic validation functions."""

    def test_validate_length(self):
        """Test string length validation."""
        assert validate_length("hello", min_length=3, max_length=10) is True
        assert validate_length("hi", min_length=3) is False
        assert validate_length("hello world", max_length=10) is False

    def test_validate_length_no_bounds(self):
        """Test length validation with no bounds."""
        assert validate_length("anything") is True

    def test_validate_length_none(self):
        """Test length validation with None."""
        assert validate_length(None, min_length=1) is False

    def test_validate_numeric_range(self):
        """Test numeric range validation."""
        assert validate_numeric_range(50, min_value=0, max_value=100) is True
        assert validate_numeric_range(-5, min_value=0, max_value=100) is False
        assert validate_numeric_range(150, min_value=0, max_value=100) is False

    def test_validate_numeric_range_min_only(self):
        """Test numeric range with min only."""
        assert validate_numeric_range(50, min_value=0) is True
        assert validate_numeric_range(-5, min_value=0) is False

    def test_validate_numeric_range_max_only(self):
        """Test numeric range with max only."""
        assert validate_numeric_range(50, max_value=100) is True
        assert validate_numeric_range(150, max_value=100) is False

    def test_validate_numeric_range_none(self):
        """Test numeric range with None."""
        assert validate_numeric_range(None) is False
        assert validate_numeric_range(None, allow_none=True) is True

    def test_validate_numeric_range_non_numeric(self):
        """Test numeric range with non-numeric value."""
        assert validate_numeric_range("string") is False
