"""
Neural LAB SDK - Storage Resource Tests
Tests for the Storage resource.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
"""

import base64
from unittest.mock import MagicMock

import pytest

from ntlabs.resources.storage import (
    StorageDownloadResult,
    StorageFile,
    StorageListResult,
    StorageResource,
    StorageUploadResult,
    StorageURLResult,
)


class TestStorageFile:
    """Tests for StorageFile dataclass."""

    def test_file_creation(self):
        """Test StorageFile creation."""
        file = StorageFile(
            id="file123",
            name="document.pdf",
            path="uploads/document.pdf",
            bucket="gateway-storage",
            size_bytes=1024,
            content_type="application/pdf",
        )

        assert file.id == "file123"
        assert file.name == "document.pdf"
        assert file.size_bytes == 1024

    def test_file_to_dict(self):
        """Test StorageFile to_dict method."""
        file = StorageFile(
            id="file123",
            name="document.pdf",
            path="uploads/document.pdf",
            bucket="gateway-storage",
        )

        data = file.to_dict()
        assert data["id"] == "file123"
        assert data["name"] == "document.pdf"


class TestStorageUploadResult:
    """Tests for StorageUploadResult dataclass."""

    def test_upload_result_success(self):
        """Test successful upload result."""
        result = StorageUploadResult(
            success=True,
            id="abc123",
            path="uploads/test.pdf",
            bucket="my-bucket",
            size_bytes=2048,
            content_type="application/pdf",
            public_url="https://storage.example.com/test.pdf",
            cost_brl=0.0001,
            latency_ms=150,
        )

        assert result.success is True
        assert result.id == "abc123"
        assert result.size_bytes == 2048
        assert result.public_url is not None

    def test_upload_result_failure(self):
        """Test failed upload result."""
        result = StorageUploadResult(
            success=False,
            error="Bucket not found",
        )

        assert result.success is False
        assert result.error == "Bucket not found"


class TestStorageURLResult:
    """Tests for StorageURLResult dataclass."""

    def test_url_result_success(self):
        """Test successful URL result."""
        result = StorageURLResult(
            success=True,
            url="https://storage.example.com/signed/test.pdf?token=xxx",
            path="uploads/test.pdf",
            bucket="my-bucket",
            expires_in=3600,
            cost_brl=0.0001,
        )

        assert result.success is True
        assert "signed" in result.url
        assert result.expires_in == 3600


class TestStorageDownloadResult:
    """Tests for StorageDownloadResult dataclass."""

    def test_download_result_success(self):
        """Test successful download result."""
        content = b"file content here"
        result = StorageDownloadResult(
            success=True,
            path="uploads/test.txt",
            bucket="my-bucket",
            data=content,
            data_base64=base64.b64encode(content).decode("utf-8"),
            content_type="text/plain",
            size_bytes=len(content),
        )

        assert result.success is True
        assert result.data == content
        assert result.size_bytes == len(content)


class TestStorageListResult:
    """Tests for StorageListResult dataclass."""

    def test_list_result_with_files(self):
        """Test list result with files."""
        files = [
            StorageFile(id="1", name="a.pdf", path="a.pdf", bucket="test"),
            StorageFile(id="2", name="b.pdf", path="b.pdf", bucket="test"),
        ]

        result = StorageListResult(
            success=True,
            files=files,
            total_count=2,
            path="",
            bucket="test",
        )

        assert result.success is True
        assert len(result.files) == 2
        assert result.total_count == 2


class TestStorageResource:
    """Tests for StorageResource."""

    @pytest.fixture
    def mock_client(self):
        """Create mock client."""
        client = MagicMock()
        return client

    @pytest.fixture
    def storage_resource(self, mock_client):
        """Create StorageResource with mock client."""
        return StorageResource(mock_client)

    def test_upload_success(self, storage_resource, mock_client):
        """Test uploading a file."""
        file_content = b"test content"

        mock_client.post.return_value = {
            "success": True,
            "id": "abc123",
            "path": "uploads/test.txt",
            "bucket": "gateway-storage",
            "size_bytes": len(file_content),
            "content_type": "text/plain",
            "public_url": "https://storage.example.com/test.txt",
            "cost_brl": 0.0001,
            "latency_ms": 100,
        }

        result = storage_resource.upload(
            path="uploads/test.txt",
            data=file_content,
            content_type="text/plain",
        )

        assert result.success is True
        assert result.id == "abc123"
        assert result.size_bytes == len(file_content)
        mock_client.post.assert_called_once()

    def test_upload_custom_bucket(self, storage_resource, mock_client):
        """Test uploading to custom bucket."""
        mock_client.post.return_value = {
            "success": True,
            "id": "xyz",
            "path": "docs/file.pdf",
            "bucket": "custom-bucket",
            "size_bytes": 100,
            "content_type": "application/pdf",
            "cost_brl": 0.0001,
            "latency_ms": 50,
        }

        result = storage_resource.upload(
            path="docs/file.pdf",
            data=b"content",
            bucket="custom-bucket",
        )

        assert result.success is True
        assert result.bucket == "custom-bucket"

    def test_get_signed_url_success(self, storage_resource, mock_client):
        """Test getting signed URL."""
        mock_client.get.return_value = {
            "success": True,
            "url": "https://storage.example.com/signed?token=xxx",
            "path": "private/doc.pdf",
            "bucket": "gateway-storage",
            "expires_in": 3600,
            "cost_brl": 0.0001,
            "latency_ms": 50,
        }

        result = storage_resource.get_signed_url("private/doc.pdf")

        assert result.success is True
        assert "signed" in result.url
        mock_client.get.assert_called_once()

    def test_get_signed_url_custom_expiry(self, storage_resource, mock_client):
        """Test getting signed URL with custom expiry."""
        mock_client.get.return_value = {
            "success": True,
            "url": "https://storage.example.com/signed?token=xxx",
            "path": "private/doc.pdf",
            "bucket": "gateway-storage",
            "expires_in": 86400,
            "cost_brl": 0.0001,
            "latency_ms": 50,
        }

        result = storage_resource.get_signed_url(
            "private/doc.pdf",
            expires_in=86400,  # 24 hours
        )

        assert result.success is True
        assert result.expires_in == 86400

    def test_download_success(self, storage_resource, mock_client):
        """Test downloading a file."""
        file_content = b"downloaded content"
        content_base64 = base64.b64encode(file_content).decode("utf-8")

        mock_client.get.return_value = {
            "success": True,
            "path": "uploads/doc.pdf",
            "bucket": "gateway-storage",
            "content_base64": content_base64,
            "content_type": "application/pdf",
            "size_bytes": len(file_content),
            "cost_brl": 0.0001,
            "latency_ms": 100,
        }

        result = storage_resource.download("uploads/doc.pdf")

        assert result.success is True
        assert result.data == file_content
        assert result.size_bytes == len(file_content)

    def test_list_success(self, storage_resource, mock_client):
        """Test listing files."""
        mock_client.get.return_value = {
            "success": True,
            "files": [
                {
                    "id": "1",
                    "name": "file1.pdf",
                    "path": "uploads/file1.pdf",
                    "size_bytes": 1024,
                },
                {
                    "id": "2",
                    "name": "file2.pdf",
                    "path": "uploads/file2.pdf",
                    "size_bytes": 2048,
                },
            ],
            "total_count": 2,
            "path": "uploads",
            "bucket": "gateway-storage",
            "cost_brl": 0.0001,
            "latency_ms": 50,
        }

        result = storage_resource.list(path="uploads")

        assert result.success is True
        assert len(result.files) == 2
        assert result.total_count == 2

    def test_list_with_pagination(self, storage_resource, mock_client):
        """Test listing with pagination."""
        mock_client.get.return_value = {
            "success": True,
            "files": [{"id": "1", "name": "file.pdf", "path": "file.pdf"}],
            "total_count": 1,
            "path": "",
            "bucket": "gateway-storage",
            "cost_brl": 0.0001,
            "latency_ms": 50,
        }

        result = storage_resource.list(limit=10, offset=20)

        assert result.success is True
        mock_client.get.assert_called_once()

    def test_delete_success(self, storage_resource, mock_client):
        """Test deleting a file."""
        mock_client.delete.return_value = {
            "success": True,
            "path": "uploads/old.pdf",
            "bucket": "gateway-storage",
            "deleted_count": 1,
            "cost_brl": 0.0001,
            "latency_ms": 50,
        }

        result = storage_resource.delete("uploads/old.pdf")

        assert result.success is True
        assert result.deleted_count == 1
        mock_client.delete.assert_called_once()

    def test_health(self, storage_resource, mock_client):
        """Test health check."""
        mock_client.get.return_value = {
            "status": "ok",
            "supabase_configured": True,
            "default_bucket": "gateway-storage",
        }

        health = storage_resource.health()

        assert health["status"] == "ok"
        assert health["supabase_configured"] is True
        mock_client.get.assert_called_with("/v1/storage/health")
