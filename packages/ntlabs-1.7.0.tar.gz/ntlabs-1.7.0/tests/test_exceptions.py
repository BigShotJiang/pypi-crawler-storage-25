"""
Tests for NTLabs SDK exceptions.

Author: Anderson Henrique da Silva
Date: 2026-02-04
"""

import pytest

from ntlabs.exceptions import (
    APIError,
    AuthenticationError,
    InsufficientCreditsError,
    NTLError,
    RateLimitError,
    ServiceUnavailableError,
    ValidationError,
)


class TestNTLError:
    """Test base NTLError class."""

    def test_basic_error(self):
        """Test basic error creation."""
        error = NTLError("Something went wrong")
        assert str(error) == "Something went wrong"
        assert error.message == "Something went wrong"
        assert error.status_code is None
        assert error.response == {}

    def test_error_with_status_code(self):
        """Test error with status code."""
        error = NTLError("Not found", status_code=404)
        assert error.status_code == 404
        assert str(error) == "Not found"

    def test_error_with_response(self):
        """Test error with response data."""
        response = {"detail": "Invalid field", "field": "email"}
        error = NTLError("Validation failed", status_code=422, response=response)
        assert error.response == response
        assert error.status_code == 422

    def test_error_inheritance(self):
        """Test NTLError inherits from Exception."""
        error = NTLError("Test")
        assert isinstance(error, Exception)


class TestAuthenticationError:
    """Test AuthenticationError."""

    def test_authentication_error(self):
        """Test authentication error creation."""
        error = AuthenticationError("Invalid API key")
        assert str(error) == "Invalid API key"
        assert isinstance(error, NTLError)

    def test_authentication_error_with_status_code(self):
        """Test authentication error with status code."""
        error = AuthenticationError(
            "Invalid API key",
            status_code=401,
            response={"detail": "Token expired"},
        )
        assert error.status_code == 401
        assert error.response["detail"] == "Token expired"


class TestRateLimitError:
    """Test RateLimitError."""

    def test_rate_limit_error(self):
        """Test rate limit error creation."""
        error = RateLimitError("Rate limit exceeded")
        assert str(error) == "Rate limit exceeded"
        assert isinstance(error, NTLError)
        assert error.retry_after is None

    def test_rate_limit_error_with_retry_after(self):
        """Test rate limit error with retry_after."""
        error = RateLimitError(
            "Rate limit exceeded. Retry after 60s",
            retry_after=60,
            status_code=429,
        )
        assert error.retry_after == 60
        assert error.status_code == 429

    def test_rate_limit_error_inheritance(self):
        """Test RateLimitError inherits from NTLError."""
        error = RateLimitError("Test")
        assert isinstance(error, NTLError)


class TestInsufficientCreditsError:
    """Test InsufficientCreditsError."""

    def test_insufficient_credits_error(self):
        """Test insufficient credits error creation."""
        error = InsufficientCreditsError("Not enough credits")
        assert str(error) == "Not enough credits"
        assert isinstance(error, NTLError)

    def test_insufficient_credits_error_with_status_code(self):
        """Test insufficient credits error with status code."""
        error = InsufficientCreditsError(
            "Not enough credits",
            status_code=402,
            response={"balance": 0, "required": 10},
        )
        assert error.status_code == 402
        assert error.response["balance"] == 0


class TestAPIError:
    """Test APIError."""

    def test_api_error(self):
        """Test API error creation."""
        error = APIError("API request failed")
        assert str(error) == "API request failed"
        assert isinstance(error, NTLError)

    def test_api_error_with_details(self):
        """Test API error with details."""
        error = APIError(
            "Bad request",
            status_code=400,
            response={"errors": [{"field": "name", "message": "Required"}]},
        )
        assert error.status_code == 400
        assert len(error.response["errors"]) == 1


class TestValidationError:
    """Test ValidationError."""

    def test_validation_error(self):
        """Test validation error creation."""
        error = ValidationError("Invalid input")
        assert str(error) == "Invalid input"
        assert isinstance(error, NTLError)


class TestServiceUnavailableError:
    """Test ServiceUnavailableError."""

    def test_service_unavailable_error(self):
        """Test service unavailable error creation."""
        error = ServiceUnavailableError("Service temporarily unavailable")
        assert str(error) == "Service temporarily unavailable"
        assert isinstance(error, NTLError)

    def test_service_unavailable_with_status_code(self):
        """Test service unavailable error with status code."""
        error = ServiceUnavailableError(
            "Service down for maintenance",
            status_code=503,
        )
        assert error.status_code == 503


class TestExceptionCatching:
    """Test catching exceptions."""

    def test_catch_base_exception(self):
        """Test catching base NTLError."""
        errors = [
            AuthenticationError("Auth failed"),
            RateLimitError("Rate limited"),
            InsufficientCreditsError("No credits"),
            APIError("API failed"),
            ValidationError("Invalid"),
            ServiceUnavailableError("Down"),
        ]

        for error in errors:
            try:
                raise error
            except NTLError as e:
                assert e is error

    def test_catch_specific_exception(self):
        """Test catching specific exceptions."""
        with pytest.raises(AuthenticationError):
            raise AuthenticationError("Auth failed")

        with pytest.raises(RateLimitError):
            raise RateLimitError("Rate limited")

    def test_exception_hierarchy(self):
        """Test exception hierarchy."""
        # All should be catchable as NTLError
        assert issubclass(AuthenticationError, NTLError)
        assert issubclass(RateLimitError, NTLError)
        assert issubclass(InsufficientCreditsError, NTLError)
        assert issubclass(APIError, NTLError)
        assert issubclass(ValidationError, NTLError)
        assert issubclass(ServiceUnavailableError, NTLError)

    def test_rate_limit_error_attributes(self):
        """Test RateLimitError specific attributes."""
        error = RateLimitError(
            "Too many requests",
            retry_after=120,
            status_code=429,
            response={"limit": 100, "remaining": 0},
        )

        # Inherited from NTLError
        assert error.message == "Too many requests"
        assert error.status_code == 429
        assert error.response["limit"] == 100

        # Specific to RateLimitError
        assert error.retry_after == 120


class TestErrorMessages:
    """Test error message formatting."""

    def test_error_str_representation(self):
        """Test error string representation."""
        error = NTLError("Test message")
        assert str(error) == "Test message"

    def test_error_with_long_message(self):
        """Test error with long message."""
        long_message = "A" * 1000
        error = NTLError(long_message)
        assert str(error) == long_message

    def test_error_with_unicode(self):
        """Test error with unicode characters."""
        error = NTLError("Erro: chave de API inválida 🔑")
        assert "inválida" in str(error)

    def test_error_with_special_chars(self):
        """Test error with special characters."""
        message = "Error: <script>alert('xss')</script>"
        error = NTLError(message)
        assert str(error) == message
