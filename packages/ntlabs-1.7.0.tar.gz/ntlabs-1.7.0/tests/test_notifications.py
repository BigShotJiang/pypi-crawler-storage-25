"""
Tests for the Notifications SDK resource.

Tests cover push subscription management, notification sending,
and preference handling.
"""

from unittest.mock import MagicMock

import pytest

from ntlabs import NTLClient
from ntlabs.resources.notifications import (
    NotificationsResource,
)


@pytest.fixture
def mock_client():
    """Create a mock NTLClient."""
    client = MagicMock(spec=NTLClient)
    return client


@pytest.fixture
def notifications(mock_client):
    """Create a NotificationsResource with a mock client."""
    return NotificationsResource(mock_client)


class TestSubscribe:
    """Tests for subscription operations."""

    def test_subscribe_success(self, notifications, mock_client):
        """Test successful subscription."""
        mock_client.post.return_value = {
            "success": True,
            "subscription_id": "sub-uuid-123",
            "message": "Subscription registered",
            "cost_brl": 0,
            "latency_ms": 50,
        }

        result = notifications.subscribe(
            endpoint="https://push.example.com/send/abc123",
            keys={"p256dh": "test-key", "auth": "test-auth"},
            product="lab",
            device_name="Chrome Desktop",
        )

        assert result.success is True
        assert result.subscription_id == "sub-uuid-123"
        assert result.message == "Subscription registered"

        mock_client.post.assert_called_once_with(
            "/v1/notifications/subscribe",
            json={
                "subscription": {
                    "endpoint": "https://push.example.com/send/abc123",
                    "keys": {"p256dh": "test-key", "auth": "test-auth"},
                },
                "product": "lab",
                "device_name": "Chrome Desktop",
                "user_agent": None,
            },
        )

    def test_subscribe_failure(self, notifications, mock_client):
        """Test subscription failure."""
        mock_client.post.return_value = {
            "success": False,
            "detail": "User ID required",
        }

        result = notifications.subscribe(
            endpoint="https://push.example.com/send/abc123",
            keys={"p256dh": "test-key", "auth": "test-auth"},
        )

        assert result.success is False
        assert result.error == "User ID required"


class TestUnsubscribe:
    """Tests for unsubscription."""

    def test_unsubscribe_success(self, notifications, mock_client):
        """Test successful unsubscription."""
        mock_client.delete.return_value = {
            "success": True,
            "message": "Subscription removed",
            "cost_brl": 0,
            "latency_ms": 30,
        }

        result = notifications.unsubscribe(
            endpoint="https://push.example.com/send/abc123"
        )

        assert result.success is True
        assert result.message == "Subscription removed"

    def test_unsubscribe_not_found(self, notifications, mock_client):
        """Test unsubscription when subscription not found."""
        mock_client.delete.return_value = {
            "success": False,
            "message": "Subscription not found",
        }

        result = notifications.unsubscribe(
            endpoint="https://push.example.com/send/unknown"
        )

        assert result.success is False


class TestListSubscriptions:
    """Tests for listing subscriptions."""

    def test_list_subscriptions(self, notifications, mock_client):
        """Test listing user subscriptions."""
        mock_client.get.return_value = {
            "success": True,
            "subscriptions": [
                {
                    "id": "sub-1",
                    "product": "lab",
                    "device_name": "Chrome",
                    "user_agent": "Mozilla/5.0",
                    "created_at": "2026-02-02T10:00:00Z",
                    "last_used_at": None,
                },
                {
                    "id": "sub-2",
                    "product": "hipocrates",
                    "device_name": "Safari",
                    "user_agent": None,
                    "created_at": "2026-02-01T10:00:00Z",
                    "last_used_at": "2026-02-02T09:00:00Z",
                },
            ],
            "total_count": 2,
            "cost_brl": 0,
            "latency_ms": 25,
        }

        result = notifications.list_subscriptions()

        assert result.success is True
        assert result.total_count == 2
        assert len(result.subscriptions) == 2
        assert result.subscriptions[0].id == "sub-1"
        assert result.subscriptions[0].product == "lab"

    def test_list_subscriptions_with_filter(self, notifications, mock_client):
        """Test listing subscriptions with product filter."""
        mock_client.get.return_value = {
            "success": True,
            "subscriptions": [
                {
                    "id": "sub-1",
                    "product": "hipocrates",
                    "device_name": "Safari",
                },
            ],
            "total_count": 1,
            "cost_brl": 0,
            "latency_ms": 20,
        }

        result = notifications.list_subscriptions(product="hipocrates")

        mock_client.get.assert_called_with(
            "/v1/notifications/subscriptions",
            params={"product": "hipocrates"},
        )
        assert result.total_count == 1


class TestSendNotification:
    """Tests for sending notifications."""

    def test_send_to_user(self, notifications, mock_client):
        """Test sending notification to a user."""
        mock_client.post.return_value = {
            "success": True,
            "sent_count": 2,
            "failed_count": 0,
            "notification_ids": ["notif-1", "notif-2"],
            "errors": [],
            "cost_brl": 0.002,
            "latency_ms": 150,
        }

        result = notifications.send(
            title="New Message",
            body="You have a new message",
            user_id="user-uuid-123",
            product="hipocrates",
            category="updates",
            url="https://hipocrates.ntlabs.dev/messages",
        )

        assert result.success is True
        assert result.sent_count == 2
        assert result.failed_count == 0
        assert len(result.notification_ids) == 2
        assert result.cost_brl == 0.002

    def test_send_broadcast(self, notifications, mock_client):
        """Test broadcast notification to all product users."""
        mock_client.post.return_value = {
            "success": True,
            "sent_count": 50,
            "failed_count": 5,
            "notification_ids": [],
            "errors": ["Some subscriptions expired"],
            "cost_brl": 0.050,
            "latency_ms": 2000,
        }

        result = notifications.send(
            title="System Maintenance",
            body="Scheduled maintenance tonight at 2am",
            product="lab",
            category="system",
        )

        assert result.success is True
        assert result.sent_count == 50
        assert result.failed_count == 5

    def test_send_with_custom_data(self, notifications, mock_client):
        """Test sending notification with custom data."""
        mock_client.post.return_value = {
            "success": True,
            "sent_count": 1,
            "failed_count": 0,
            "notification_ids": ["notif-1"],
            "errors": [],
            "cost_brl": 0.001,
            "latency_ms": 100,
        }

        result = notifications.send(
            title="New Appointment",
            body="Dr. Silva scheduled for 3pm",
            user_id="patient-uuid",
            product="hipocrates",
            category="reminders",
            icon="https://hipocrates.ntlabs.dev/icon.png",
            badge="https://hipocrates.ntlabs.dev/badge.png",
            tag="appointment-123",
            data={
                "appointment_id": "apt-123",
                "doctor": "Dr. Silva",
                "time": "15:00",
            },
        )

        assert result.success is True
        mock_client.post.assert_called_once()
        call_args = mock_client.post.call_args
        assert call_args[1]["json"]["data"]["appointment_id"] == "apt-123"

    def test_send_failure(self, notifications, mock_client):
        """Test notification send failure."""
        mock_client.post.return_value = {
            "success": False,
            "sent_count": 0,
            "detail": "No subscriptions found",
            "errors": ["No subscriptions found"],
        }

        result = notifications.send(
            title="Test",
            body="Test body",
            user_id="nonexistent-user",
        )

        assert result.success is False
        assert result.sent_count == 0
        assert "No subscriptions found" in result.errors


class TestPreferences:
    """Tests for notification preferences."""

    def test_get_preferences(self, notifications, mock_client):
        """Test getting user preferences."""
        mock_client.get.return_value = {
            "success": True,
            "preferences": {
                "marketing": False,
                "updates": True,
                "security": True,
                "reminders": True,
                "billing": True,
                "email_enabled": True,
                "push_enabled": True,
                "quiet_hours_start": "22:00",
                "quiet_hours_end": "08:00",
                "product": "lab",
            },
            "cost_brl": 0,
            "latency_ms": 15,
        }

        result = notifications.get_preferences()

        assert result.success is True
        assert result.preferences is not None
        assert result.preferences.marketing is False
        assert result.preferences.quiet_hours_start == "22:00"

    def test_get_preferences_default(self, notifications, mock_client):
        """Test getting default preferences."""
        mock_client.get.return_value = {
            "success": True,
            "preferences": {
                "marketing": True,
                "updates": True,
                "security": True,
                "reminders": True,
                "billing": True,
                "email_enabled": True,
                "push_enabled": True,
                "quiet_hours_start": None,
                "quiet_hours_end": None,
                "product": "lab",
            },
            "message": "Using default preferences",
            "cost_brl": 0,
            "latency_ms": 10,
        }

        result = notifications.get_preferences()

        assert result.success is True
        assert result.message == "Using default preferences"
        assert result.preferences.marketing is True

    def test_update_preferences(self, notifications, mock_client):
        """Test updating preferences."""
        mock_client.put.return_value = {
            "success": True,
            "preferences": {
                "marketing": False,
                "updates": True,
                "security": True,
                "reminders": True,
                "billing": True,
                "email_enabled": True,
                "push_enabled": False,
                "quiet_hours_start": "23:00",
                "quiet_hours_end": "07:00",
                "product": "lab",
            },
            "cost_brl": 0,
            "latency_ms": 20,
        }

        result = notifications.update_preferences(
            marketing=False,
            push_enabled=False,
            quiet_hours_start="23:00",
            quiet_hours_end="07:00",
        )

        assert result.success is True
        assert result.preferences.marketing is False
        assert result.preferences.push_enabled is False
        assert result.preferences.quiet_hours_start == "23:00"


class TestVapidKey:
    """Tests for VAPID key retrieval."""

    def test_get_vapid_key(self, notifications, mock_client):
        """Test getting VAPID public key."""
        mock_client.get.return_value = {"publicKey": "BNxRLg-test-public-key"}

        key = notifications.get_vapid_key()

        assert key == "BNxRLg-test-public-key"

    def test_get_vapid_key_not_configured(self, notifications, mock_client):
        """Test VAPID key when not configured."""
        mock_client.get.side_effect = Exception("Not configured")

        key = notifications.get_vapid_key()

        assert key is None


class TestHealth:
    """Tests for health check."""

    def test_health(self, notifications, mock_client):
        """Test health check."""
        mock_client.get.return_value = {
            "status": "ok",
            "vapid_configured": True,
            "supabase_configured": True,
            "public_key": "BNxRLg-test-public-key",
        }

        health = notifications.health()

        assert health["status"] == "ok"
        assert health["vapid_configured"] is True
