"""
NTLabs SDK - Async Chat Resource Tests
Tests for the AsyncChatResource class, including real SSE streaming.

Author: Anderson Henrique da Silva
Location: Minas Gerais, Brasil
"""

import json
from contextlib import asynccontextmanager
from unittest.mock import AsyncMock, MagicMock

import pytest

from ntlabs.exceptions import APIError
from ntlabs.resources.async_chat import AsyncChatResource
from ntlabs.resources.chat import ChatCompletion

# =============================================================================
# Helpers for mocking async SSE streams
# =============================================================================


def _make_sse_lines(events: list[dict]) -> list[str]:
    """Convert a list of event dicts into SSE-formatted lines."""
    lines = []
    for event in events:
        lines.append(f"data: {json.dumps(event)}")
        lines.append("")  # empty line between SSE events
    return lines


class MockAsyncStreamResponse:
    """Mock httpx async streaming response."""

    def __init__(self, lines: list[str], status_code: int = 200):
        self.status_code = status_code
        self._lines = lines

    async def aiter_lines(self):
        for line in self._lines:
            yield line

    async def aread(self):
        pass

    async def aclose(self):
        pass

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        pass


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def chat_response():
    """Standard chat completion API response."""
    return {
        "id": "chat_123",
        "choices": [
            {
                "message": {"content": "Ola! Como posso ajudar?"},
                "finish_reason": "stop",
            }
        ],
        "model": "maritaca-sabia-4",
        "usage": {
            "prompt_tokens": 10,
            "completion_tokens": 20,
            "total_tokens": 30,
        },
    }


# =============================================================================
# Tests: AsyncChatResource.complete()
# =============================================================================


@pytest.mark.asyncio
class TestAsyncChatResource:
    """Tests for AsyncChatResource."""

    async def test_initialization(self):
        """AsyncChatResource initializes with client."""
        mock_client = AsyncMock()
        chat = AsyncChatResource(mock_client)
        assert chat._client == mock_client

    async def test_complete_basic(self, chat_response):
        """Basic async chat completion."""
        mock_client = AsyncMock()
        mock_client.post.return_value = chat_response

        chat = AsyncChatResource(mock_client)
        result = await chat.complete(messages=[{"role": "user", "content": "Ola!"}])

        assert isinstance(result, ChatCompletion)
        assert result.content == "Ola! Como posso ajudar?"
        assert result.model == "maritaca-sabia-4"
        mock_client.post.assert_called_once()
        call_args = mock_client.post.call_args
        assert call_args[0][0] == "/v1/llm/completions"

    async def test_complete_with_model(self, chat_response):
        """Async chat completion with specific model."""
        mock_client = AsyncMock()
        mock_client.post.return_value = chat_response

        chat = AsyncChatResource(mock_client)
        result = await chat.complete(
            messages=[{"role": "user", "content": "Hello"}],
            model="claude-sonnet",
        )

        assert isinstance(result, ChatCompletion)
        call_kwargs = mock_client.post.call_args[1]
        assert call_kwargs["json"]["model"] == "claude-sonnet"

    async def test_complete_with_system_prompt(self, chat_response):
        """Async chat completion with system prompt."""
        mock_client = AsyncMock()
        mock_client.post.return_value = chat_response

        chat = AsyncChatResource(mock_client)
        result = await chat.complete(
            messages=[{"role": "user", "content": "What is Python?"}],
            system="You are a programming tutor.",
        )

        assert isinstance(result, ChatCompletion)
        call_kwargs = mock_client.post.call_args[1]
        messages = call_kwargs["json"]["messages"]
        assert messages[0]["role"] == "system"
        assert messages[0]["content"] == "You are a programming tutor."

    async def test_complete_with_parameters(self, chat_response):
        """Async chat completion with all parameters."""
        mock_client = AsyncMock()
        mock_client.post.return_value = chat_response

        chat = AsyncChatResource(mock_client)
        result = await chat.complete(
            messages=[{"role": "user", "content": "Tell me a story"}],
            model="maritaca-sabia-4",
            max_tokens=2048,
            temperature=0.9,
        )

        assert isinstance(result, ChatCompletion)
        call_kwargs = mock_client.post.call_args[1]
        assert call_kwargs["json"]["max_tokens"] == 2048
        assert call_kwargs["json"]["temperature"] == 0.9

    async def test_complete_multiple_messages(self, chat_response):
        """Async chat completion with conversation history."""
        mock_client = AsyncMock()
        mock_client.post.return_value = chat_response

        chat = AsyncChatResource(mock_client)
        messages = [
            {"role": "user", "content": "My name is Joao"},
            {"role": "assistant", "content": "Nice to meet you, Joao!"},
            {"role": "user", "content": "What is my name?"},
        ]

        result = await chat.complete(messages=messages)
        assert isinstance(result, ChatCompletion)
        call_kwargs = mock_client.post.call_args[1]
        assert len(call_kwargs["json"]["messages"]) == 3

    async def test_complete_empty_response(self):
        """Handle empty response gracefully."""
        mock_client = AsyncMock()
        mock_client.post.return_value = {}

        chat = AsyncChatResource(mock_client)
        result = await chat.complete(messages=[{"role": "user", "content": "Hello"}])

        assert result.id == ""
        assert result.content == ""
        assert result.finish_reason == "stop"

    async def test_complete_with_kwargs(self, chat_response):
        """Async chat completion with extra kwargs."""
        mock_client = AsyncMock()
        mock_client.post.return_value = chat_response

        chat = AsyncChatResource(mock_client)
        result = await chat.complete(
            messages=[{"role": "user", "content": "Hello"}],
            top_p=0.95,
            presence_penalty=0.5,
        )

        assert isinstance(result, ChatCompletion)
        call_kwargs = mock_client.post.call_args[1]
        assert call_kwargs["json"]["top_p"] == 0.95
        assert call_kwargs["json"]["presence_penalty"] == 0.5


# =============================================================================
# Tests: AsyncChatResource usage tracking
# =============================================================================


@pytest.mark.asyncio
class TestAsyncChatResourceUsage:
    """Tests for usage tracking in async chat responses."""

    async def test_usage_tokens(self, chat_response):
        """Usage tokens are tracked."""
        mock_client = AsyncMock()
        mock_client.post.return_value = chat_response

        chat = AsyncChatResource(mock_client)
        result = await chat.complete(messages=[{"role": "user", "content": "Hello"}])

        assert result.usage["prompt_tokens"] == 10
        assert result.usage["completion_tokens"] == 20
        assert result.usage["total_tokens"] == 30

    async def test_missing_usage(self):
        """Handle missing usage gracefully."""
        mock_client = AsyncMock()
        mock_client.post.return_value = {
            "choices": [{"message": {"content": "Hi"}, "finish_reason": "stop"}]
        }

        chat = AsyncChatResource(mock_client)
        result = await chat.complete(messages=[{"role": "user", "content": "Hello"}])

        assert result.usage == {}


# =============================================================================
# Tests: AsyncChatResource.complete_stream() - real SSE
# =============================================================================


@pytest.mark.asyncio
class TestAsyncChatResourceStreaming:
    """Tests for async streaming chat completions with real SSE parsing."""

    async def test_stream_yields_token_content(self):
        """Streaming yields content from token events."""
        sse_events = [
            {"type": "start", "agent": "dedalo", "session_id": "s1"},
            {"type": "token", "content": "Ola"},
            {"type": "token", "content": "! Como "},
            {"type": "token", "content": "posso ajudar?"},
            {"type": "end", "intent": "greeting", "lead_score": 10},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockAsyncStreamResponse(lines)

        mock_http_client = MagicMock()

        @asynccontextmanager
        async def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_http_client.stream = fake_stream

        mock_client = MagicMock()
        mock_client._get_client.return_value = mock_http_client

        chat = AsyncChatResource(mock_client)
        chunks = []
        async for chunk in chat.complete_stream(
            messages=[{"role": "user", "content": "Ola"}],
        ):
            chunks.append(chunk)

        assert chunks == ["Ola", "! Como ", "posso ajudar?"]

    async def test_stream_handles_empty_content(self):
        """Tokens with None/empty content are skipped."""
        sse_events = [
            {"type": "start", "agent": "dedalo"},
            {"type": "token", "content": ""},
            {"type": "token", "content": None},
            {"type": "token", "content": "Hello"},
            {"type": "end"},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockAsyncStreamResponse(lines)

        mock_http_client = MagicMock()

        @asynccontextmanager
        async def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_http_client.stream = fake_stream

        mock_client = MagicMock()
        mock_client._get_client.return_value = mock_http_client

        chat = AsyncChatResource(mock_client)
        chunks = []
        async for chunk in chat.complete_stream(
            messages=[{"role": "user", "content": "Hi"}],
        ):
            chunks.append(chunk)

        assert chunks == ["Hello"]

    async def test_stream_raises_on_error_event(self):
        """Error events raise APIError."""
        sse_events = [
            {"type": "start", "agent": "dedalo"},
            {"type": "error", "error": "Agent unavailable"},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockAsyncStreamResponse(lines)

        mock_http_client = MagicMock()

        @asynccontextmanager
        async def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_http_client.stream = fake_stream

        mock_client = MagicMock()
        mock_client._get_client.return_value = mock_http_client

        chat = AsyncChatResource(mock_client)
        with pytest.raises(APIError, match="Agent unavailable"):
            async for _ in chat.complete_stream(
                messages=[{"role": "user", "content": "Hi"}],
            ):
                pass

    async def test_stream_raises_on_http_error(self):
        """HTTP errors raise APIError with status code."""
        mock_stream = MockAsyncStreamResponse([], status_code=503)

        mock_http_client = MagicMock()

        @asynccontextmanager
        async def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_http_client.stream = fake_stream

        mock_client = MagicMock()
        mock_client._get_client.return_value = mock_http_client

        chat = AsyncChatResource(mock_client)
        with pytest.raises(APIError, match="503"):
            async for _ in chat.complete_stream(
                messages=[{"role": "user", "content": "Hi"}],
            ):
                pass

    async def test_stream_stops_at_end_event(self):
        """Stream stops processing after end event."""
        sse_events = [
            {"type": "start", "agent": "dedalo"},
            {"type": "token", "content": "A"},
            {"type": "end", "intent": "casual"},
            {"type": "token", "content": "B"},  # should not be yielded
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockAsyncStreamResponse(lines)

        mock_http_client = MagicMock()

        @asynccontextmanager
        async def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_http_client.stream = fake_stream

        mock_client = MagicMock()
        mock_client._get_client.return_value = mock_http_client

        chat = AsyncChatResource(mock_client)
        chunks = []
        async for chunk in chat.complete_stream(
            messages=[{"role": "user", "content": "Hi"}],
        ):
            chunks.append(chunk)

        assert chunks == ["A"]

    async def test_stream_with_session_and_user(self):
        """Session ID and user ID are included in the request payload."""
        sse_events = [
            {"type": "start", "agent": "chiron", "session_id": "s42"},
            {"type": "token", "content": "Hi"},
            {"type": "end"},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockAsyncStreamResponse(lines)

        captured_kwargs = {}
        mock_http_client = MagicMock()

        @asynccontextmanager
        async def fake_stream(method, url, **kwargs):
            captured_kwargs.update(kwargs)
            yield mock_stream

        mock_http_client.stream = fake_stream

        mock_client = MagicMock()
        mock_client._get_client.return_value = mock_http_client

        chat = AsyncChatResource(mock_client)
        chunks = []
        async for chunk in chat.complete_stream(
            messages=[{"role": "user", "content": "Hi"}],
            agent="chiron",
            session_id="s42",
            user_id="u99",
        ):
            chunks.append(chunk)

        assert chunks == ["Hi"]
        payload = captured_kwargs["json"]
        assert payload["agent"] == "chiron"
        assert payload["session_id"] == "s42"
        assert payload["user_id"] == "u99"


# =============================================================================
# Tests: AsyncChatResource.complete_stream_events()
# =============================================================================


@pytest.mark.asyncio
class TestAsyncChatResourceStreamEvents:
    """Tests for async streaming with full StreamEvent objects."""

    async def test_yields_all_event_types(self):
        """All event types are yielded as StreamEvent objects."""
        sse_events = [
            {"type": "start", "agent": "dedalo", "session_id": "s1"},
            {"type": "token", "content": "Hi"},
            {"type": "end", "intent": "greeting", "lead_score": 30},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockAsyncStreamResponse(lines)

        mock_http_client = MagicMock()

        @asynccontextmanager
        async def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_http_client.stream = fake_stream

        mock_client = MagicMock()
        mock_client._get_client.return_value = mock_http_client

        chat = AsyncChatResource(mock_client)
        events = []
        async for event in chat.complete_stream_events(
            messages=[{"role": "user", "content": "Hi"}],
        ):
            events.append(event)

        assert len(events) == 3
        assert events[0].type == "start"
        assert events[0].agent == "dedalo"
        assert events[1].type == "token"
        assert events[1].content == "Hi"
        assert events[2].type == "end"
        assert events[2].lead_score == 30

    async def test_stops_after_error_event(self):
        """Stops yielding after an error event."""
        sse_events = [
            {"type": "start", "agent": "dedalo"},
            {"type": "error", "error": "timeout"},
            {"type": "token", "content": "should not appear"},
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockAsyncStreamResponse(lines)

        mock_http_client = MagicMock()

        @asynccontextmanager
        async def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_http_client.stream = fake_stream

        mock_client = MagicMock()
        mock_client._get_client.return_value = mock_http_client

        chat = AsyncChatResource(mock_client)
        events = []
        async for event in chat.complete_stream_events(
            messages=[{"role": "user", "content": "Hi"}],
        ):
            events.append(event)

        assert len(events) == 2
        assert events[1].type == "error"
        assert events[1].error == "timeout"

    async def test_end_event_contains_metadata(self):
        """End event contains all metadata fields."""
        sse_events = [
            {"type": "start", "agent": "dedalo"},
            {"type": "token", "content": "Response"},
            {
                "type": "end",
                "intent": "pricing",
                "lead_score": 75,
                "should_handoff": True,
                "latency_ms": 1200,
                "session_id": "s99",
            },
        ]
        lines = _make_sse_lines(sse_events)
        mock_stream = MockAsyncStreamResponse(lines)

        mock_http_client = MagicMock()

        @asynccontextmanager
        async def fake_stream(method, url, **kwargs):
            yield mock_stream

        mock_http_client.stream = fake_stream

        mock_client = MagicMock()
        mock_client._get_client.return_value = mock_http_client

        chat = AsyncChatResource(mock_client)
        events = []
        async for event in chat.complete_stream_events(
            messages=[{"role": "user", "content": "Price?"}],
        ):
            events.append(event)

        end_event = events[-1]
        assert end_event.type == "end"
        assert end_event.intent == "pricing"
        assert end_event.lead_score == 75
        assert end_event.should_handoff is True
        assert end_event.latency_ms == 1200
        assert end_event.session_id == "s99"
