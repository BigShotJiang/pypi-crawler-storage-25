"""
NTLabs SDK - Test Configuration and Fixtures

Author: Anderson Henrique da Silva
Date: 2026-02-04
Location: Minas Gerais, Brasil
Copyright: Neural Thinker | AI Engineering LTDA

Description: Pytest fixtures for NTLabs SDK tests
Version: 1.0.0
"""

import os
from collections.abc import Generator
from typing import Any
from unittest.mock import MagicMock, patch

import httpx
import pytest
from pydantic import BaseModel

# Set test environment
os.environ.setdefault("NTL_API_KEY", "ntl_test_123456789")


# =============================================================================
# Mock HTTP Client Fixtures
# =============================================================================


class MockResponse:
    """Mock HTTP response for testing."""

    def __init__(
        self,
        json_data: dict | None = None,
        status_code: int = 200,
        headers: dict | None = None,
        content: bytes | None = None,
    ):
        self.json_data = json_data or {}
        self.status_code = status_code
        self.headers = headers or {}
        self.content = content or b""

    def json(self) -> dict:
        return self.json_data


@pytest.fixture
def mock_http_client() -> Generator[MagicMock, None, None]:
    """Create a mock HTTP client for testing."""
    mock_client = MagicMock(spec=httpx.Client)
    mock_client.request = MagicMock(return_value=MockResponse({"success": True}, 200))
    yield mock_client


@pytest.fixture
def mock_async_http_client() -> Generator[MagicMock, None, None]:
    """Create a mock async HTTP client for testing."""
    mock_client = MagicMock(spec=httpx.AsyncClient)

    async def mock_request(*args, **kwargs) -> MockResponse:
        return MockResponse({"success": True}, 200)

    async def mock_aclose():
        pass

    mock_client.request = mock_request
    mock_client.aclose = mock_aclose
    yield mock_client


# =============================================================================
# Client Fixtures
# =============================================================================


@pytest.fixture
def api_key() -> str:
    """Test API key."""
    return "ntl_hipo_test123456789"


@pytest.fixture
def base_url() -> str:
    """Test base URL."""
    return "https://api.test.neuralthinkers.com"


@pytest.fixture
def mock_ntl_client(api_key: str, base_url: str) -> Generator[MagicMock, None, None]:
    """Create a mock NTL client for resource testing."""
    mock_client = MagicMock()
    mock_client.api_key = api_key
    mock_client.base_url = base_url
    mock_client.source_system = "hipocrates"
    mock_client.get = MagicMock(return_value={"success": True})
    mock_client.post = MagicMock(return_value={"success": True})
    mock_client.put = MagicMock(return_value={"success": True})
    mock_client.delete = MagicMock(return_value={"success": True})
    mock_client.request = MagicMock(return_value={"success": True})
    yield mock_client


# =============================================================================
# Response Data Fixtures
# =============================================================================


@pytest.fixture
def chat_completion_response() -> dict[str, Any]:
    """Sample chat completion response."""
    return {
        "id": "chat_123",
        "choices": [
            {
                "message": {"content": "Olá! Como posso ajudar?"},
                "finish_reason": "stop",
            }
        ],
        "model": "maritaca-sabia-4",
        "usage": {"prompt_tokens": 10, "completion_tokens": 20},
    }


# Aliases used by test_chat.py and test_async_chat.py
@pytest.fixture
def chat_response(chat_completion_response) -> dict[str, Any]:
    """Alias for chat_completion_response (used by chat tests)."""
    return chat_completion_response


@pytest.fixture
def mock_response():
    """Factory for MockResponse objects.

    Sets content to non-empty bytes so that the client's
    `response.json() if response.content else {}` check works correctly.
    """

    def _make(json_data: dict, status_code: int = 200):
        import json as _json

        return MockResponse(
            json_data=json_data,
            status_code=status_code,
            content=_json.dumps(json_data).encode() if json_data else b"",
        )

    return _make


@pytest.fixture
def mock_client(api_key, base_url):
    """Mock NTL sync client with underlying httpx client for chat tests."""
    from ntlabs.client import NTLClient

    with patch("httpx.Client") as mock_cls:
        mock_http = MagicMock()
        mock_http.request = MagicMock(return_value=MockResponse({"success": True}, 200))
        mock_http.close = MagicMock()
        mock_cls.return_value = mock_http

        client = NTLClient(api_key=api_key, base_url=base_url)
        # Expose underlying mock for direct assertion
        client._mock_http = mock_http
        yield client


@pytest.fixture
def cnpj_response() -> dict[str, Any]:
    """Sample CNPJ lookup response."""
    return {
        "cnpj": "11222333000181",
        "razao_social": "Empresa Teste LTDA",
        "nome_fantasia": "Teste",
        "situacao": "ATIVA",
        "data_situacao": "2020-01-01",
        "tipo": "MATRIZ",
        "porte": "MICRO EMPRESA",
        "natureza_juridica": "206-2 - Sociedade Empresária Limitada",
        "atividade_principal": [{"code": "6201-5/00", "text": "Atividade teste"}],
        "atividades_secundarias": [],
        "endereco": {
            "logradouro": "Rua Teste",
            "numero": "123",
            "complemento": "Sala 1",
            "bairro": "Centro",
            "municipio": "São Paulo",
            "uf": "SP",
            "cep": "01000-000",
        },
        "telefone": "(11) 99999-9999",
        "email": "teste@empresa.com",
        "capital_social": "100000.00",
        "data_abertura": "2020-01-01",
        "latency_ms": 100,
        "cost_brl": 0.01,
    }


@pytest.fixture
def cep_response() -> dict[str, Any]:
    """Sample CEP lookup response."""
    return {
        "cep": "01310-100",
        "logradouro": "Avenida Paulista",
        "complemento": "de 1047 a 1865 - lado ímpar",
        "bairro": "Bela Vista",
        "municipio": "São Paulo",
        "uf": "SP",
        "ibge": "3550308",
        "ddd": "11",
        "latency_ms": 50,
        "cost_brl": 0.005,
    }


@pytest.fixture
def auth_token_response() -> dict[str, Any]:
    """Sample auth token response."""
    return {
        "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
        "refresh_token": "dGhpcyBpcyBhIHJlZnJlc2ggdG9rZW4",
        "token_type": "Bearer",
        "expires_in": 3600,
        "user": {
            "id": "user_123",
            "email": "test@example.com",
            "name": "Test User",
        },
    }


@pytest.fixture
def user_response() -> dict[str, Any]:
    """Sample user response."""
    return {
        "id": "user_123",
        "email": "test@example.com",
        "name": "Test User",
        "avatar_url": "https://example.com/avatar.jpg",
        "role": "user",
        "is_active": True,
        "is_verified": True,
    }


# =============================================================================
# Pydantic Model Fixtures
# =============================================================================


@pytest.fixture
def sample_pydantic_model() -> type[BaseModel]:
    """Create a sample Pydantic model for testing validators."""

    class SampleModel(BaseModel):
        name: str
        email: str
        age: int = 0

    return SampleModel


# =============================================================================
# Context Manager Helpers
# =============================================================================


@pytest.fixture
def patch_httpx_client():
    """Context manager to patch httpx.Client."""

    class ClientPatcher:
        def __init__(self, response: MockResponse | None = None):
            self.response = response or MockResponse({"success": True}, 200)
            self.patcher = None

        def __enter__(self):
            self.patcher = patch("httpx.Client")
            mock_class = self.patcher.__enter__()
            mock_instance = MagicMock()
            mock_instance.request = MagicMock(return_value=self.response)
            mock_instance.close = MagicMock()
            mock_class.return_value = mock_instance
            return mock_instance

        def __exit__(self, *args):
            return self.patcher.__exit__(*args)

    return ClientPatcher


@pytest.fixture
def patch_httpx_async_client():
    """Context manager to patch httpx.AsyncClient."""

    class AsyncClientPatcher:
        def __init__(self, response: MockResponse | None = None):
            self.response = response or MockResponse({"success": True}, 200)
            self.patcher = None

        async def _async_request(self, *args, **kwargs):
            return self.response

        def __enter__(self):
            self.patcher = patch("httpx.AsyncClient")
            mock_class = self.patcher.__enter__()
            mock_instance = MagicMock()

            async def async_request(*args, **kwargs):
                return self.response

            async def async_aclose():
                pass

            mock_instance.request = async_request
            mock_instance.aclose = async_aclose
            mock_class.return_value = mock_instance
            return mock_instance

        def __exit__(self, *args):
            return self.patcher.__exit__(*args)

    return AsyncClientPatcher
