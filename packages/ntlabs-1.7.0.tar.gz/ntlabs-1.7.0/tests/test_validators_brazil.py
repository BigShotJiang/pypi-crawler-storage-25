"""
Tests for Brazilian document validators.

Author: Anderson Henrique da Silva
Date: 2026-02-04
"""


from ntlabs.validators.brazil import (
    UF_CODES,
    UF_NAMES,
    VALID_UFS,
    clean_cep,
    clean_cnpj,
    clean_cns,
    clean_cpf,
    clean_phone,
    clean_pis,
    format_cep,
    format_cnpj,
    format_cns,
    format_cpf,
    format_phone,
    format_pis,
    generate_cnpj,
    generate_cpf,
    get_uf_code,
    get_uf_name,
    identify_document,
    is_valid_cep,
    is_valid_cnpj,
    is_valid_cns,
    is_valid_cpf,
    is_valid_phone,
    is_valid_pis,
    is_valid_uf,
    validate_cep,
    validate_cnpj,
    validate_cns,
    validate_cpf,
    validate_phone,
    validate_pis,
    validate_uf,
)


class TestCPFValidation:
    """Test CPF validation functions."""

    def test_valid_cpf_formatted(self):
        """Test valid CPF with formatting."""
        assert validate_cpf("123.456.789-09") is True

    def test_valid_cpf_unformatted(self):
        """Test valid CPF without formatting."""
        assert validate_cpf("12345678909") is True

    def test_invalid_cpf_all_same_digits(self):
        """Test invalid CPF with all same digits."""
        assert validate_cpf("111.111.111-11") is False
        assert validate_cpf("000.000.000-00") is False

    def test_invalid_cpf_wrong_length(self):
        """Test invalid CPF with wrong length."""
        assert validate_cpf("123.456.789") is False
        assert validate_cpf("123.456.789-090") is False

    def test_invalid_cpf_wrong_check_digit(self):
        """Test invalid CPF with wrong check digit."""
        assert validate_cpf("123.456.789-00") is False

    def test_clean_cpf(self):
        """Test CPF cleaning function."""
        assert clean_cpf("123.456.789-09") == "12345678909"
        assert clean_cpf("12345678909") == "12345678909"
        assert clean_cpf(None) == ""

    def test_format_cpf(self):
        """Test CPF formatting function."""
        assert format_cpf("12345678909") == "123.456.789-09"
        assert format_cpf("123.456.789-09") == "123.456.789-09"

    def test_format_cpf_wrong_length(self):
        """Test format_cpf with wrong length."""
        assert format_cpf("123456") == "123456"

    def test_generate_cpf(self):
        """Test CPF generation."""
        cpf = generate_cpf()
        assert validate_cpf(cpf) is True
        assert len(clean_cpf(cpf)) == 11

    def test_generate_cpf_unique(self):
        """Test generated CPFs are different."""
        cpf1 = generate_cpf()
        cpf2 = generate_cpf()
        assert cpf1 != cpf2

    def test_is_valid_cpf_alias(self):
        """Test is_valid_cpf is alias for validate_cpf."""
        assert is_valid_cpf is validate_cpf


class TestCNPJValidation:
    """Test CNPJ validation functions."""

    def test_valid_cnpj_formatted(self):
        """Test valid CNPJ with formatting."""
        # Valid CNPJ: 11.222.333/0001-81
        assert validate_cnpj("11.222.333/0001-81") is True

    def test_valid_cnpj_unformatted(self):
        """Test valid CNPJ without formatting."""
        assert validate_cnpj("11222333000181") is True

    def test_invalid_cnpj_all_same_digits(self):
        """Test invalid CNPJ with all same digits."""
        assert validate_cnpj("11.111.111/1111-11") is False
        assert validate_cnpj("00.000.000/0000-00") is False

    def test_invalid_cnpj_wrong_length(self):
        """Test invalid CNPJ with wrong length."""
        assert validate_cnpj("11.222.333/0001") is False
        assert validate_cnpj("11.222.333/0001-811") is False

    def test_clean_cnpj(self):
        """Test CNPJ cleaning function."""
        assert clean_cnpj("11.222.333/0001-81") == "11222333000181"
        assert clean_cnpj("11222333000181") == "11222333000181"
        assert clean_cnpj(None) == ""

    def test_format_cnpj(self):
        """Test CNPJ formatting function."""
        assert format_cnpj("11222333000181") == "11.222.333/0001-81"

    def test_format_cnpj_wrong_length(self):
        """Test format_cnpj with wrong length."""
        assert format_cnpj("11222333") == "11222333"

    def test_generate_cnpj(self):
        """Test CNPJ generation."""
        cnpj = generate_cnpj()
        assert validate_cnpj(cnpj) is True
        assert len(clean_cnpj(cnpj)) == 14

    def test_is_valid_cnpj_alias(self):
        """Test is_valid_cnpj is alias for validate_cnpj."""
        assert is_valid_cnpj is validate_cnpj


class TestCEPValidation:
    """Test CEP validation functions."""

    def test_valid_cep_formatted(self):
        """Test valid CEP with formatting."""
        assert validate_cep("01310-100") is True

    def test_valid_cep_unformatted(self):
        """Test valid CEP without formatting."""
        assert validate_cep("01310100") is True

    def test_invalid_cep_wrong_length(self):
        """Test invalid CEP with wrong length."""
        assert validate_cep("01310") is False
        assert validate_cep("013101001") is False

    def test_invalid_cep_non_digits(self):
        """Test invalid CEP with non-digits."""
        assert validate_cep("01310-10a") is False

    def test_clean_cep(self):
        """Test CEP cleaning function."""
        assert clean_cep("01310-100") == "01310100"
        assert clean_cep("01310100") == "01310100"
        assert clean_cep(None) == ""

    def test_format_cep(self):
        """Test CEP formatting function."""
        assert format_cep("01310100") == "01310-100"
        assert format_cep("01310-100") == "01310-100"

    def test_format_cep_wrong_length(self):
        """Test format_cep with wrong length."""
        assert format_cep("01310") == "01310"

    def test_is_valid_cep_alias(self):
        """Test is_valid_cep is alias for validate_cep."""
        assert is_valid_cep is validate_cep


class TestUFValidation:
    """Test UF (state) validation functions."""

    def test_valid_uf(self):
        """Test valid UF codes."""
        assert validate_uf("SP") is True
        assert validate_uf("RJ") is True
        assert validate_uf("MG") is True
        assert validate_uf("BA") is True

    def test_valid_uf_lowercase(self):
        """Test valid UF codes in lowercase."""
        assert validate_uf("sp") is True
        assert validate_uf("rj") is True

    def test_invalid_uf(self):
        """Test invalid UF codes."""
        assert validate_uf("XX") is False
        assert validate_uf("AAA") is False
        assert validate_uf("") is False

    def test_invalid_uf_none(self):
        """Test invalid UF with None."""
        assert validate_uf(None) is False

    def test_get_uf_name(self):
        """Test get_uf_name function."""
        assert get_uf_name("SP") == "São Paulo"
        assert get_uf_name("RJ") == "Rio de Janeiro"
        assert get_uf_name("MG") == "Minas Gerais"

    def test_get_uf_name_invalid(self):
        """Test get_uf_name with invalid UF."""
        assert get_uf_name("XX") is None

    def test_get_uf_code(self):
        """Test get_uf_code function."""
        assert get_uf_code("SP") == 35
        assert get_uf_code("RJ") == 33
        assert get_uf_code("MG") == 31

    def test_get_uf_code_invalid(self):
        """Test get_uf_code with invalid UF."""
        assert get_uf_code("XX") is None

    def test_valid_ufs_set(self):
        """Test VALID_UFS contains all states."""
        assert len(VALID_UFS) == 27  # 26 states + DF
        assert "SP" in VALID_UFS
        assert "RJ" in VALID_UFS
        assert "DF" in VALID_UFS

    def test_uf_names_mapping(self):
        """Test UF_NAMES mapping."""
        assert len(UF_NAMES) == 27
        assert UF_NAMES["SP"] == "São Paulo"

    def test_uf_codes_mapping(self):
        """Test UF_CODES mapping."""
        assert len(UF_CODES) == 27
        assert UF_CODES["SP"] == 35

    def test_is_valid_uf_alias(self):
        """Test is_valid_uf is alias for validate_uf."""
        assert is_valid_uf is validate_uf


class TestPhoneValidation:
    """Test phone validation functions."""

    def test_valid_mobile_phone(self):
        """Test valid mobile phone."""
        assert validate_phone("(11) 99999-9999") is True
        assert validate_phone("11999999999") is True

    def test_valid_landline_phone(self):
        """Test valid landline phone."""
        assert validate_phone("(11) 3333-4444") is True
        assert validate_phone("1133334444") is True

    def test_valid_phone_with_country_code(self):
        """Test valid phone with country code."""
        assert validate_phone("+55 (11) 99999-9999") is True
        assert validate_phone("5511999999999") is True

    def test_invalid_phone_no_ddd(self):
        """Test invalid phone without DDD."""
        assert validate_phone("99999-9999") is False

    def test_invalid_phone_wrong_length(self):
        """Test invalid phone with wrong length."""
        assert validate_phone("(11) 9999") is False
        assert validate_phone("(11) 99999-99999") is False

    def test_invalid_phone_wrong_ddd(self):
        """Test invalid phone with wrong DDD."""
        assert validate_phone("(01) 99999-9999") is False
        assert validate_phone("(00) 99999-9999") is False

    def test_mobile_only_validation(self):
        """Test mobile-only phone validation."""
        assert validate_phone("(11) 99999-9999", allow_landline=False) is True
        assert validate_phone("(11) 3333-4444", allow_landline=False) is False

    def test_clean_phone(self):
        """Test phone cleaning function."""
        assert clean_phone("(11) 99999-9999") == "11999999999"
        assert clean_phone("+55 (11) 99999-9999") == "5511999999999"
        assert clean_phone(None) == ""

    def test_format_phone(self):
        """Test phone formatting function."""
        assert format_phone("11999999999") == "(11) 99999-9999"
        assert format_phone("1133334444") == "(11) 3333-4444"

    def test_format_phone_international(self):
        """Test phone formatting with international prefix."""
        assert format_phone("11999999999", international=True) == "+55 (11) 99999-9999"

    def test_is_valid_phone_alias(self):
        """Test is_valid_phone is alias for validate_phone."""
        assert is_valid_phone is validate_phone


class TestPISValidation:
    """Test PIS/PASEP validation functions."""

    def test_valid_pis_formatted(self):
        """Test valid PIS with formatting."""
        # Valid PIS: 123.45678.90-1 (needs to be calculated)
        # Using a known valid PIS
        assert validate_pis("120.8205.52-8") is True

    def test_valid_pis_unformatted(self):
        """Test valid PIS without formatting."""
        assert validate_pis("1208205528") is True

    def test_invalid_pis_all_same_digits(self):
        """Test invalid PIS with all same digits."""
        assert validate_pis("111.11111.11-1") is False

    def test_invalid_pis_wrong_length(self):
        """Test invalid PIS with wrong length."""
        assert validate_pis("123.45678.90") is False

    def test_clean_pis(self):
        """Test PIS cleaning function."""
        assert clean_pis("123.45678.90-1") == "12345678901"
        assert clean_pis(None) == ""

    def test_format_pis(self):
        """Test PIS formatting function."""
        assert format_pis("12345678901") == "123.45678.90-1"

    def test_is_valid_pis_alias(self):
        """Test is_valid_pis is alias for validate_pis."""
        assert is_valid_pis is validate_pis


class TestCNSValidation:
    """Test CNS (Cartão Nacional de Saúde) validation."""

    def test_valid_cns_provisional(self):
        """Test valid provisional CNS (starts with 7, 8, or 9)."""
        # Provisional CNS starting with 9 and divisible by 11
        assert validate_cns("942613957950004") is True

    def test_invalid_cns_wrong_length(self):
        """Test invalid CNS with wrong length."""
        assert validate_cns("12345678901234") is False  # 14 digits
        assert validate_cns("1234567890123456") is False  # 16 digits

    def test_invalid_cns_wrong_start(self):
        """Test invalid CNS with wrong starting digit."""
        # CNS must start with 1, 2, 7, 8, or 9
        assert validate_cns("342613957950004") is False

    def test_clean_cns(self):
        """Test CNS cleaning function."""
        assert clean_cns("123 4567 8901 2345") == "123456789012345"
        assert clean_cns(None) == ""

    def test_format_cns(self):
        """Test CNS formatting function."""
        assert format_cns("123456789012345") == "123 4567 8901 2345"

    def test_is_valid_cns_alias(self):
        """Test is_valid_cns is alias for validate_cns."""
        assert is_valid_cns is validate_cns


class TestDocumentIdentification:
    """Test document identification function."""

    def test_identify_cpf(self):
        """Test identification of CPF."""
        assert identify_document("123.456.789-09") == "cpf"
        assert identify_document("12345678909") == "cpf"

    def test_identify_cnpj(self):
        """Test identification of CNPJ."""
        assert identify_document("11.222.333/0001-81") == "cnpj"
        assert identify_document("11222333000181") == "cnpj"

    def test_identify_unknown(self):
        """Test identification of unknown document."""
        assert identify_document("123456") is None
        assert identify_document("12345678901234567890") is None

    def test_identify_invalid_document(self):
        """Test identification of invalid document format."""
        assert identify_document("111.111.111-11") is None  # Invalid CPF
        assert identify_document("") is None
