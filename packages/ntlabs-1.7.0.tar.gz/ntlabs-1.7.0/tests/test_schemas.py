"""
Tests for NTLabs SDK schemas.

Author: Anderson Henrique da Silva
Date: 2026-02-04
"""

from datetime import datetime

import pytest
from pydantic import ValidationError

from ntlabs.schemas.auth import (
    OAuthCallbackRequest,
    OAuthUrlResponse,
    PasswordChangeRequest,
    PasswordResetConfirm,
    PasswordResetRequest,
    RefreshTokenRequest,
    SessionInfo,
    TokenResponse,
    UserCreate,
    UserResponse,
    UserUpdate,
)
from ntlabs.schemas.common import (
    Address,
    BulkOperationResponse,
    ContactInfo,
    CountResponse,
    DataResponse,
    FileUploadResponse,
    HealthResponse,
    IdResponse,
    MetadataMixin,
    SoftDeleteMixin,
    SuccessResponse,
    TimestampMixin,
    WebhookPayload,
)
from ntlabs.schemas.errors import (
    ErrorCodes,
    ErrorDetail,
    ErrorResponse,
    ForbiddenErrorResponse,
    InternalErrorResponse,
    NotFoundErrorResponse,
    RateLimitErrorResponse,
    ServiceUnavailableErrorResponse,
    UnauthorizedErrorResponse,
    ValidationErrorResponse,
)
from ntlabs.schemas.pagination import (
    CursorPaginatedResponse,
    CursorPaginationParams,
    PaginatedResponse,
    PaginatedResponseWithMeta,
    PaginationParams,
    paginate_list,
)


class TestAuthSchemas:
    """Test authentication schemas."""

    def test_token_response(self):
        """Test TokenResponse schema."""
        token = TokenResponse(
            access_token="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9",
            refresh_token="refresh_token_here",
            expires_in=3600,
            scope="read write",
        )
        assert token.access_token == "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
        assert token.token_type == "Bearer"
        assert token.expires_in == 3600

    def test_token_response_defaults(self):
        """Test TokenResponse default values."""
        token = TokenResponse(
            access_token="test_token",
            expires_in=1800,
        )
        assert token.token_type == "Bearer"
        assert token.refresh_token is None
        assert token.scope is None

    def test_refresh_token_request(self):
        """Test RefreshTokenRequest schema."""
        req = RefreshTokenRequest(refresh_token="refresh_123")
        assert req.refresh_token == "refresh_123"

    def test_user_response(self):
        """Test UserResponse schema."""
        user = UserResponse(
            id="user_123",
            email="test@example.com",
            name="Test User",
            role="admin",
            is_active=True,
        )
        assert user.id == "user_123"
        assert user.email == "test@example.com"
        assert user.role == "admin"
        assert user.is_verified is False  # default

    def test_user_response_email_validation(self):
        """Test UserResponse email validation."""
        with pytest.raises(ValidationError):
            UserResponse(
                id="user_123",
                email="invalid-email",
            )

    def test_user_create(self):
        """Test UserCreate schema."""
        user = UserCreate(
            email="new@example.com",
            password="SecurePass123!",
            name="New User",
        )
        assert user.email == "new@example.com"
        assert user.password == "SecurePass123!"

    def test_user_create_password_min_length(self):
        """Test UserCreate password minimum length."""
        with pytest.raises(ValidationError):
            UserCreate(
                email="new@example.com",
                password="short",
            )

    def test_user_update(self):
        """Test UserUpdate schema."""
        update = UserUpdate(name="Updated Name")
        assert update.name == "Updated Name"
        assert update.avatar_url is None

    def test_password_change_request(self):
        """Test PasswordChangeRequest schema."""
        req = PasswordChangeRequest(
            current_password="OldPass123!",
            new_password="NewPass456!",
        )
        assert req.current_password == "OldPass123!"
        assert req.new_password == "NewPass456!"

    def test_password_reset_request(self):
        """Test PasswordResetRequest schema."""
        req = PasswordResetRequest(email="user@example.com")
        assert req.email == "user@example.com"

    def test_password_reset_confirm(self):
        """Test PasswordResetConfirm schema."""
        req = PasswordResetConfirm(
            token="reset_token_123",
            new_password="NewSecurePass456!",
        )
        assert req.token == "reset_token_123"

    def test_oauth_url_response(self):
        """Test OAuthUrlResponse schema."""
        resp = OAuthUrlResponse(
            url="https://github.com/login/oauth/authorize?client_id=xxx",
            provider="github",
            state="random_state_123",
        )
        assert resp.provider == "github"
        assert "github.com" in resp.url

    def test_oauth_callback_request(self):
        """Test OAuthCallbackRequest schema."""
        req = OAuthCallbackRequest(
            code="auth_code_123",
            state="state_123",
        )
        assert req.code == "auth_code_123"

    def test_session_info(self):
        """Test SessionInfo schema."""
        user = UserResponse(
            id="user_123",
            email="test@example.com",
            name="Test User",
        )
        session = SessionInfo(
            user=user,
            expires_at=datetime(2026, 12, 31, 23, 59, 59),
            permissions=["read:users", "write:own"],
        )
        assert session.user.id == "user_123"
        assert "read:users" in session.permissions


class TestCommonSchemas:
    """Test common schemas."""

    def test_timestamp_mixin(self):
        """Test TimestampMixin schema."""
        ts = TimestampMixin(
            created_at=datetime(2026, 1, 1, 0, 0, 0),
            updated_at=datetime(2026, 1, 2, 0, 0, 0),
        )
        assert ts.created_at.year == 2026

    def test_soft_delete_mixin(self):
        """Test SoftDeleteMixin schema."""
        sd = SoftDeleteMixin(is_deleted=True)
        assert sd.is_deleted is True
        assert sd.deleted_at is None

    def test_metadata_mixin(self):
        """Test MetadataMixin schema."""
        meta = MetadataMixin(metadata={"key": "value", "number": 42})
        assert meta.metadata["key"] == "value"

    def test_health_response(self):
        """Test HealthResponse schema."""
        health = HealthResponse(
            status="healthy",
            version="1.0.0",
            checks={
                "database": {"status": "healthy", "latency_ms": 5},
            },
        )
        assert health.status == "healthy"
        assert health.checks["database"]["status"] == "healthy"

    def test_health_response_timestamp_default(self):
        """Test HealthResponse timestamp default."""
        health = HealthResponse(status="healthy")
        assert health.timestamp is not None
        assert isinstance(health.timestamp, datetime)

    def test_success_response(self):
        """Test SuccessResponse schema."""
        success = SuccessResponse(success=True, message="Operation completed")
        assert success.success is True
        assert success.message == "Operation completed"

    def test_success_response_defaults(self):
        """Test SuccessResponse default values."""
        success = SuccessResponse()
        assert success.success is True
        assert "completed successfully" in success.message

    def test_data_response(self):
        """Test DataResponse schema."""
        data = DataResponse(data={"id": "123", "name": "Test"})
        assert data.data["id"] == "123"
        assert data.message is None

    def test_data_response_with_message(self):
        """Test DataResponse with message."""
        data = DataResponse(
            data={"id": "123"},
            message="Data retrieved successfully",
        )
        assert data.message == "Data retrieved successfully"

    def test_count_response(self):
        """Test CountResponse schema."""
        count = CountResponse(count=42)
        assert count.count == 42

    def test_count_response_validation(self):
        """Test CountResponse validation."""
        with pytest.raises(ValidationError):
            CountResponse(count=-1)

    def test_id_response(self):
        """Test IdResponse schema."""
        resp = IdResponse(id="res_abc123")
        assert resp.id == "res_abc123"

    def test_bulk_operation_response(self):
        """Test BulkOperationResponse schema."""
        bulk = BulkOperationResponse(
            total=100,
            succeeded=98,
            failed=2,
            errors=[{"index": 5, "error": "Invalid email"}],
        )
        assert bulk.total == 100
        assert bulk.succeeded == 98
        assert len(bulk.errors) == 1

    def test_file_upload_response(self):
        """Test FileUploadResponse schema."""
        upload = FileUploadResponse(
            file_id="file_abc123",
            filename="document.pdf",
            size=102400,
            content_type="application/pdf",
            url="https://storage.example.com/files/document.pdf",
        )
        assert upload.file_id == "file_abc123"
        assert upload.size == 102400

    def test_webhook_payload(self):
        """Test WebhookPayload schema."""
        webhook = WebhookPayload(
            event="user.created",
            data={"user_id": "user_123"},
            webhook_id="wh_abc123",
        )
        assert webhook.event == "user.created"
        assert webhook.webhook_id == "wh_abc123"

    def test_webhook_payload_timestamp_default(self):
        """Test WebhookPayload timestamp default."""
        webhook = WebhookPayload(
            event="test",
            data={},
        )
        assert webhook.timestamp is not None

    def test_address(self):
        """Test Address schema."""
        addr = Address(
            street="Av. Paulista",
            number="1000",
            city="São Paulo",
            state="SP",
            postal_code="01310-100",
        )
        assert addr.street == "Av. Paulista"
        assert addr.state == "SP"
        assert addr.country == "BR"  # default

    def test_address_state_validation(self):
        """Test Address state validation."""
        with pytest.raises(ValidationError):
            Address(
                street="Test",
                city="Test",
                state="INVALID",  # Too long
                postal_code="12345-678",
            )

    def test_contact_info(self):
        """Test ContactInfo schema."""
        contact = ContactInfo(
            email="test@example.com",
            phone="(11) 3333-4444",
            mobile="(11) 99999-8888",
        )
        assert contact.email == "test@example.com"
        assert contact.whatsapp is None


class TestErrorSchemas:
    """Test error response schemas."""

    def test_error_detail(self):
        """Test ErrorDetail schema."""
        detail = ErrorDetail(
            field="email",
            message="Invalid email format",
            code="invalid_format",
        )
        assert detail.field == "email"
        assert detail.code == "invalid_format"

    def test_error_response(self):
        """Test ErrorResponse schema."""
        error = ErrorResponse(
            error="Validation failed",
            code="validation_error",
            status_code=400,
        )
        assert error.error == "Validation failed"
        assert error.status_code == 400

    def test_error_response_with_details(self):
        """Test ErrorResponse with details."""
        error = ErrorResponse(
            error="Validation failed",
            details=[
                ErrorDetail(field="email", message="Invalid format"),
                ErrorDetail(field="name", message="Required"),
            ],
        )
        assert len(error.details) == 2

    def test_validation_error_response(self):
        """Test ValidationErrorResponse schema."""
        error = ValidationErrorResponse(
            details=[ErrorDetail(field="cpf", message="Invalid CPF")],
        )
        assert error.status_code == 422
        assert error.code == "validation_error"

    def test_not_found_error_response(self):
        """Test NotFoundErrorResponse schema."""
        error = NotFoundErrorResponse(
            resource_type="user",
            resource_id="user_123",
        )
        assert error.status_code == 404
        assert error.resource_type == "user"

    def test_unauthorized_error_response(self):
        """Test UnauthorizedErrorResponse schema."""
        error = UnauthorizedErrorResponse()
        assert error.status_code == 401
        assert error.error == "Unauthorized"

    def test_forbidden_error_response(self):
        """Test ForbiddenErrorResponse schema."""
        error = ForbiddenErrorResponse(
            required_permission="admin:read",
        )
        assert error.status_code == 403
        assert error.required_permission == "admin:read"

    def test_rate_limit_error_response(self):
        """Test RateLimitErrorResponse schema."""
        error = RateLimitErrorResponse(
            retry_after=60,
            limit=100,
            remaining=0,
        )
        assert error.status_code == 429
        assert error.retry_after == 60

    def test_internal_error_response(self):
        """Test InternalErrorResponse schema."""
        error = InternalErrorResponse(
            request_id="req_abc123",
        )
        assert error.status_code == 500
        assert error.request_id == "req_abc123"

    def test_service_unavailable_error_response(self):
        """Test ServiceUnavailableErrorResponse schema."""
        error = ServiceUnavailableErrorResponse(
            retry_after=300,
        )
        assert error.status_code == 503
        assert error.retry_after == 300

    def test_error_codes(self):
        """Test ErrorCodes constants."""
        assert ErrorCodes.VALIDATION_ERROR == "validation_error"
        assert ErrorCodes.UNAUTHORIZED == "unauthorized"
        assert ErrorCodes.NOT_FOUND == "not_found"
        assert ErrorCodes.RATE_LIMIT_EXCEEDED == "rate_limit_exceeded"
        assert ErrorCodes.INTERNAL_ERROR == "internal_error"


class TestPaginationSchemas:
    """Test pagination schemas."""

    def test_pagination_params(self):
        """Test PaginationParams schema."""
        params = PaginationParams(page=2, page_size=50, sort_by="name")
        assert params.page == 2
        assert params.page_size == 50
        assert params.sort_order == "asc"

    def test_pagination_params_defaults(self):
        """Test PaginationParams default values."""
        params = PaginationParams()
        assert params.page == 1
        assert params.page_size == 20
        assert params.sort_by is None

    def test_pagination_params_offset(self):
        """Test PaginationParams offset calculation."""
        params = PaginationParams(page=3, page_size=20)
        assert params.offset == 40

    def test_pagination_params_validation(self):
        """Test PaginationParams validation."""
        with pytest.raises(ValidationError):
            PaginationParams(page=0)  # Must be >= 1

        with pytest.raises(ValidationError):
            PaginationParams(page_size=200)  # Must be <= 100

    def test_paginated_response(self):
        """Test PaginatedResponse schema."""
        resp = PaginatedResponse(
            items=[{"id": "1"}, {"id": "2"}],
            total=50,
            page=1,
            page_size=20,
        )
        assert len(resp.items) == 2
        assert resp.total == 50

    def test_paginated_response_properties(self):
        """Test PaginatedResponse computed properties."""
        resp = PaginatedResponse(
            items=[{"id": "1"}],
            total=50,
            page=1,
            page_size=20,
        )
        assert resp.total_pages == 3
        assert resp.has_next is True
        assert resp.has_prev is False

    def test_paginated_response_with_meta(self):
        """Test PaginatedResponseWithMeta schema."""
        resp = PaginatedResponseWithMeta(
            items=[{"id": "1"}],
            total=50,
            page=2,
            page_size=20,
        )
        assert resp.total_pages == 3
        assert resp.has_next is True
        assert resp.has_prev is True
        assert resp.next_page == 3
        assert resp.prev_page == 1

    def test_cursor_pagination_params(self):
        """Test CursorPaginationParams schema."""
        params = CursorPaginationParams(cursor="eyJpZCI6IjEwMCJ9", limit=50)
        assert params.cursor == "eyJpZCI6IjEwMCJ9"
        assert params.limit == 50

    def test_cursor_pagination_params_defaults(self):
        """Test CursorPaginationParams default values."""
        params = CursorPaginationParams()
        assert params.cursor is None
        assert params.limit == 20

    def test_cursor_paginated_response(self):
        """Test CursorPaginatedResponse schema."""
        resp = CursorPaginatedResponse(
            items=[{"id": "1"}],
            next_cursor="eyJpZCI6IjIwMCJ9",
            has_more=True,
        )
        assert resp.has_more is True
        assert resp.next_cursor is not None
        assert resp.prev_cursor is None

    def test_paginate_list_helper(self):
        """Test paginate_list helper function."""
        items = [{"id": str(i)} for i in range(100)]
        resp = paginate_list(items[:20], total=100, page=1, page_size=20)

        assert len(resp.items) == 20
        assert resp.total == 100
        assert resp.page == 1
        assert resp.total_pages == 5


class TestSchemaExamples:
    """Test schema examples from json_schema_extra."""

    def test_token_response_example(self):
        """Test TokenResponse example can be loaded."""
        example = TokenResponse.model_config["json_schema_extra"]["example"]
        token = TokenResponse(**example)
        assert token.token_type == "Bearer"

    def test_user_response_example(self):
        """Test UserResponse example can be loaded."""
        example = UserResponse.model_config["json_schema_extra"]["example"]
        user = UserResponse(**example)
        assert user.role == "user"

    def test_health_response_example(self):
        """Test HealthResponse example can be loaded."""
        example = HealthResponse.model_config["json_schema_extra"]["example"]
        health = HealthResponse(**example)
        assert health.status == "healthy"

    def test_error_response_example(self):
        """Test ErrorResponse example can be loaded."""
        example = ErrorResponse.model_config["json_schema_extra"]["example"]
        error = ErrorResponse(**example)
        assert error.status_code == 400

    def test_paginated_response_example(self):
        """Test PaginatedResponse example can be loaded."""
        example = PaginatedResponse.model_config["json_schema_extra"]["example"]
        resp = PaginatedResponse(**example)
        assert resp.total == 50
