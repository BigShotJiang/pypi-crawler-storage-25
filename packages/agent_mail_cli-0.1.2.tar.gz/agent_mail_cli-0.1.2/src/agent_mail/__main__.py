import sys
from pathlib import Path

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from agent_mail.cli import main
else:
    from .cli import main

if __name__ == "__main__":
    main()
