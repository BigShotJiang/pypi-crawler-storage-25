from setuptools import setup, find_packages
import os

# 1. Read the README.md file securely
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="lumen-py",
    version="1.0.5",
    description="An AI-powered, local, coding mentor.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    
    # These are the libraries pip will automatically install for the user
    install_requires=[
        "torch",
        "transformers",
        "datasets",
        "typer",
        "rich",
        "pyperclip",
        "requests"
    ],
    
    # This creates the global terminal command "lumen"
    entry_points={
        "console_scripts": [
            "lumen=main:app", 
        ],
    },
)