import re
import uuid
from http import HTTPStatus


class TPException(Exception):
    def __init__(
        self,
        message: str,
        status_code: int | HTTPStatus = HTTPStatus.INTERNAL_SERVER_ERROR,
        trace_id: uuid.UUID | None = None,
    ) -> None:
        super().__init__(message)
        self.trace_id = trace_id
        self.message = message
        self.status_code = int(status_code)

    @property
    def error(self) -> str:
        """Идентификатор ошибки из имени класса в snake_case: UserScopeCompanyAccessDenied → user_scope_company_access_denied."""
        return re.sub(r"(?<!^)(?=[A-Z])", "_", self.__class__.__name__).lower()
