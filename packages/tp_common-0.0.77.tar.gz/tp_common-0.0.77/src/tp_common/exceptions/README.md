# API Exceptions

Исключения API-слоя наследуются от `TPException` (из `tp_common.exceptions`).

Исключения, специфичные для сущности, создавать в модуле этой сущности — `exceptions.py` рядом с route/service (например `cp_vehicles/vehicle_types/exceptions.py`). В общий `src/apis/exceptions/` выносить только общие ошибки.

## 1 класс — 1 ошибка

Каждое исключение — отдельный класс. Один класс описывает одну конкретную ошибку.

**Использовать** отдельный класс на каждую ошибку:

```python
# ✅ GOOD
from http import HTTPStatus
import uuid

from tp_common.exceptions import TPException


class VehicleTypeNotFound(TPException):
    def __init__(self, type_id: uuid.UUID, *, trace_id: uuid.UUID | None = None) -> None:
        super().__init__(
            message=f"Тип транспортного средства не найден: {type_id}",
            status_code=HTTPStatus.NOT_FOUND,
            trace_id=trace_id,
        )
```
