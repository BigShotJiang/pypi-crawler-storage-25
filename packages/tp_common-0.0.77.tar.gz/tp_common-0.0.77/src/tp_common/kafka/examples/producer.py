"""
Пример продюсера: пишет тестовые события в топик.

Запуск (из корня репозитория, с настроенным Kafka):
  python -m tp_common.kafka.examples.producer

Переменная окружения KAFKA_URL задаёт URL Kafka (по умолчанию localhost:9092).
Опционально: SOURCE_SYSTEM — запись в топик example.events.<SOURCE_SYSTEM>.
"""

import asyncio
import logging
import os
from datetime import UTC, datetime

from tp_common.kafka.connector import KafkaConnector
from tp_common.kafka.examples.service import ExampleEventService, ExampleResultMessage
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory

logging.basicConfig(level=logging.INFO)
logger_factory = TpLoggerFactory(env=EnvironmentType.LOCAL)
logger = logger_factory.get_logger("example_producer")


def get_connector(kafka_url: str | None = None) -> KafkaConnector:
    url = kafka_url or os.environ.get("KAFKA_URL", "plaintext://localhost:9092")
    return KafkaConnector(url, logger=logger)


async def send_example_events(
    connector: KafkaConnector,
    logger: TpLogger,
    *,
    source_system: str | None = None,
) -> None:
    """Отправляет тестовые события. Коннектор и логгер передаются снаружи."""
    service = ExampleEventService(
        connector=connector,
        logger=logger,
        source_system=source_system,
    )
    now = datetime.now(UTC)
    messages = [
        ExampleResultMessage(id=1, name="first", created_at=now),
        ExampleResultMessage(id=1, name="first_updated", created_at=now),
        ExampleResultMessage(id=2, name="second", created_at=now),
    ]
    for i, msg in enumerate(messages):
        await service.publish(msg, target_source_system=source_system)
        logger.info("Опубликовано сообщение %s", i + 1)
        await asyncio.sleep(0.5)
    await service.close()


async def main(kafka_url: str | None = None) -> None:
    connector = get_connector(kafka_url=kafka_url)
    service = ExampleEventService(
        connector=connector,
        logger=logger,
        source_system=os.environ.get("SOURCE_SYSTEM") or None,
    )

    now = datetime.now(UTC)
    messages = [
        ExampleResultMessage(id=1, name="first", created_at=now),
        ExampleResultMessage(id=1, name="first_updated", created_at=now),
        ExampleResultMessage(id=2, name="second", created_at=now),
    ]

    for i, msg in enumerate(messages):
        target = os.environ.get("SOURCE_SYSTEM")
        await service.publish(msg, target_source_system=target)
        logger.info("Опубликовано сообщение %s", i + 1)
        await asyncio.sleep(0.5)

    await service.close()
    logger.info("Готово. Запустите API и запросите long-polling эндпоинт.")


if __name__ == "__main__":
    asyncio.run(main())
