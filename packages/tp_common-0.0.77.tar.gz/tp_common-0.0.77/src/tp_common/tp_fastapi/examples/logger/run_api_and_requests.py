"""
Скрипт поднимает пример FastAPI с TpLogger и выполняет запросы
(в терминале видны JSON-логи с trace_id, level, msg, env).

Запуск из корня репозитория:
  python -m tp_common.tp_fastapi.examples.logger.run_api_and_requests

Скрипт:
  1. Запускает uvicorn с tp_common.tp_fastapi.examples.logger.app:app на порту 8766
  2. Ждёт готовности API (GET /)
  3. Делает запросы: /, /items/1, X-Trace-ID, /slow, /explicit, /error
  4. Останавливает сервер
"""

import sys
import time
import urllib.error
import urllib.request

PORT = 8766
BASE_URL = f"http://127.0.0.1:{PORT}"
REQUEST_TIMEOUT = 5


def wait_ready(max_attempts: int = 30, interval: float = 0.2) -> bool:
    for _ in range(max_attempts):
        try:
            req = urllib.request.Request(f"{BASE_URL}/", method="GET")
            with urllib.request.urlopen(req, timeout=2) as r:
                if r.status == 200:
                    return True
        except (urllib.error.URLError, OSError):
            pass
        time.sleep(interval)
    return False


def request(
    method: str,
    path: str,
    headers: dict[str, str] | None = None,
    *,
    data: bytes | None = None,
) -> tuple[int, str, dict]:
    url = BASE_URL + path
    req = urllib.request.Request(url, method=method, headers=headers or {}, data=data)
    try:
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as r:
            body = r.read().decode("utf-8")
            out_headers = {k.lower(): v for k, v in r.headers.items()}
            return r.status, body, out_headers
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace") if e.fp else ""
        out_headers = {k.lower(): v for k, v in e.headers.items()} if e.headers else {}
        return e.code, body, out_headers


def main() -> int:
    import os
    import subprocess

    print("Запуск API на порту", PORT, "...")
    print("(Логи API — JSON с trace_id, level, msg, env — пойдут ниже.)\n")

    proc = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "uvicorn",
            "tp_common.tp_fastapi.examples.logger.app:app",
            "--port",
            str(PORT),
            "--host",
            "127.0.0.1",
        ],
        stdout=None,
        stderr=subprocess.STDOUT,
        env=os.environ,
    )

    try:
        if not wait_ready():
            print("API не поднялся за отведённое время.", file=sys.stderr)
            return 1

        requests_spec: list[
            tuple[str, str, dict[str, str] | None, str, bytes | None]
        ] = [
            ("GET", "/", None, "Корень, trace_id сгенерируется автоматически", None),
            ("GET", "/items/42", None, "Эндпоинт с path-параметром", None),
            (
                "GET",
                "/items/-1",
                None,
                "Отрицательный item_id — в логах будет warning",
                None,
            ),
            (
                "GET",
                "/",
                {"X-Trace-ID": "00000000-0000-0000-0000-000000000123"},
                "Свой X-Trace-ID — в логах и в ответе будет этот trace_id",
                None,
            ),
            ("GET", "/slow", None, "Асинхронный эндпоинт, два сообщения в логе", None),
            (
                "GET",
                "/explicit",
                None,
                "Явный Depends(get_request_logger), debug-лог",
                None,
            ),
            (
                "GET",
                "/error",
                None,
                "Эндпоинт с исключением — в логе error, stack_trace",
                None,
            ),
            (
                "GET",
                "/validate/query?limit=0",
                None,
                "Ошибка валидации query (limit < 1) — ожидается 422",
                None,
            ),
            (
                "POST",
                "/validate/body",
                {"Content-Type": "application/json"},
                "Ошибка валидации body (name: int, age: str) — ожидается 422",
                b'{"name":123,"age":"x"}',
            ),
            (
                "POST",
                "/validate/items",
                {"Content-Type": "application/json"},
                "Ошибка валидации списка (index в loc) — ожидается 422",
                b'[{"name":""},{"name":123}]',
            ),
        ]

        for method, path, headers, desc, data in requests_spec:
            print("=" * 60)
            print(f"Запрос: {method} {path}")
            if headers:
                print("Заголовки:", headers)
            print("(", desc, ")")
            print()

            status, body, out_headers = request(method, path, headers, data=data)
            x_trace_id = out_headers.get("x-trace-id", "")

            print(f"Ответ: HTTP {status}")
            if x_trace_id:
                print(f"X-Trace-ID: {x_trace_id}")
            if body:
                print("Тело:", body[:500] + ("..." if len(body) > 500 else ""))
            print()

        print("=" * 60)
        print("Готово. Остановка сервера...")
        return 0

    except urllib.error.URLError as e:
        print("Ошибка запроса:", e, file=sys.stderr)
        return 1
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        print("Сервер остановлен.")


if __name__ == "__main__":
    sys.exit(main())
