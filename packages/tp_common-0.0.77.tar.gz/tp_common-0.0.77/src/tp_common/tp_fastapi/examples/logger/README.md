# Пример: TpLogger в FastAPI

Пример приложения с интеграцией TpLogger: trace_id на запрос, логгер в эндпоинтах, наследование от TPException.

## Что показывает

- **Старт приложения (lifespan):** фабрика `TpLoggerFactory` в `app.state.log_factory`, `setup_standard_loggers`.
- **Middleware:** `TpMiddleware` — выставляет `trace_id` из заголовка `X-Trace-ID` или генерирует новый, на каждый запрос пишет access-строку в TpLogger (метод, путь, статус, длительность), добавляет `X-Trace-ID` в ответ, перехватывает необработанные исключения с логом.
- **Логгер в эндпоинтах:** `logger: TpLogger = Depends(get_request_logger)` — во всех логах автоматически попадает `trace_id`.
- **Эндпоинты:** `/`, `/items/{item_id}`, `/slow`, `/explicit`, `/error`, `/flaky` — демонстрация info/warning/error и исключений.
- **TPException:** классы `ExampleErrorException` и `FlakyOperationException` (наследники `TPException`) с передачей `trace_id` из логгера.
- **retry_forever:** эндпоинт `/flaky` вызывает метод с декоратором `@retry_forever`; после исчерпания повторов — свой exception с trace_id.

## Запуск

```bash
uvicorn tp_common.tp_fastapi.examples.logger.app:app --reload --port 8000
```

## Скрипт с запросами

Поднять приложение и выполнить набор запросов (логи в stdout с trace_id):

```bash
python -m tp_common.tp_fastapi.examples.logger.run_api_and_requests
```

## Проверка

```bash
curl -i http://127.0.0.1:8000/
curl -i -H "X-Trace-ID: 00000000-0000-0000-0000-000000000123" http://127.0.0.1:8000/items/1
```
