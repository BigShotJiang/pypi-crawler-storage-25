# Пример: Events (Kafka) в FastAPI

Пример API для чтения событий из Kafka по timestamp: long-polling эндпоинт, который возвращает список сообщений начиная с указанной даты.

## Что показывает

- Подключение к Kafka через `KafkaConnector` и `ExampleEventService` (`tp_common.kafka.examples.service`).
- Эндпоинт `GET /events` с параметрами: `timestamp` (мс), `source_system`, `limit`, `timeout`.
- Чтение пачки сообщений через `read_from_timestamp_ready`; у каждого сообщения есть поле `timestamp` из схемы (пагинация по последнему).
- TpLogger и trace_id в запросе (middleware, `get_request_logger`).
- Наследование от `TPException`: `EventReadException` с фиксированным message/status_code и передачей `trace_id` при ошибке чтения.

## Запуск

Нужен доступный Kafka.

```bash
uvicorn tp_common.tp_fastapi.examples.events.app:app --reload --port 8000
```

## Пример запроса

```bash
curl "http://127.0.0.1:8000/events?timestamp=1710000000000&source_system=my_client&limit=100"
```

Ответ: массив сообщений (JSON). Для следующей страницы используй `timestamp` последнего сообщения из списка.
