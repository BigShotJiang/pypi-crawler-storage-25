"""
Пример: как делать исключения — наследование от TPException.

Показывает:
  - свой класс-исключение, наследник TPException (message и status_code в __init__);
  - передачу trace_id из логгера запроса;
  - FastAPI обрабатывает наследника HTTPException и отдаёт JSON в ответ.

Запуск:
  uvicorn tp_common.tp_fastapi.examples.exceptions.app:app --reload --port 8000

Проверка:
  curl -i http://127.0.0.1:8000/ok
  curl -i http://127.0.0.1:8000/fail
  curl -i -H "X-Trace-ID: 00000000-0000-0000-0000-000000000999" http://127.0.0.1:8000/fail

  # Примеры ошибок валидации (RequestValidationError), которые перехватывает TpMiddleware:
  curl -i "http://127.0.0.1:8000/validate/query?limit=0"
  curl -i -X POST "http://127.0.0.1:8000/validate/body" -H "Content-Type: application/json" -d "{\"name\":123,\"age\":\"x\"}"
  curl -i -X POST "http://127.0.0.1:8000/validate/items" -H "Content-Type: application/json" -d "[{\"name\":\"\"},{\"name\":123}]"
"""

from __future__ import annotations

import uuid
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from http import HTTPStatus

from fastapi import Body, Depends, FastAPI, Query
from pydantic import BaseModel, Field

from tp_common.exceptions.exceptions import TPException
from tp_common.tp_fastapi.middleware import TpMiddleware
from tp_common.tp_logger.fastapi_integration import get_request_logger
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory


class NotFoundException(TPException):
    """Ресурс не найден (404)."""

    def __init__(
        self,
        *,
        message: str = "Not Found",
        trace_id: uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message=message,
            status_code=HTTPStatus.NOT_FOUND,
            trace_id=trace_id,
        )


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    env = EnvironmentType.DEV
    app.state.log_factory = TpLoggerFactory(env)
    yield


app = FastAPI(title="TPException example", lifespan=lifespan)
app.add_middleware(TpMiddleware)


class UserPayload(BaseModel):
    name: str = Field(min_length=1)
    age: int = Field(ge=0, le=130)


class ItemPayload(BaseModel):
    name: str = Field(min_length=1)


@app.get("/ok")
def ok(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    logger.info("Запрос /ok")
    return {"status": "ok", "trace_id": str(logger.trace_id) if logger.trace_id else ""}


@app.get("/fail")
def fail(logger: TpLogger = Depends(get_request_logger)) -> None:
    """Возвращает 404 с trace_id в ответе (как наследник HTTPException)."""
    logger.warning("Запрос /fail — выбрасываем NotFoundException")
    raise NotFoundException(
        message="Ресурс не найден",
        trace_id=logger.trace_id,
    )


@app.get("/validate/query")
def validate_query(
    limit: int = Query(10, ge=1, le=100),
    offset: int = Query(0, ge=0),
) -> dict[str, int]:
    return {"limit": limit, "offset": offset}


@app.post("/validate/body")
def validate_body(payload: UserPayload) -> dict[str, object]:
    return {"payload": payload.model_dump()}


@app.post("/validate/items")
def validate_items(payload: list[ItemPayload] = Body(...)) -> dict[str, int]:
    # Нужен пример с index в loc (список объектов).
    return {"items_count": len(payload)}
