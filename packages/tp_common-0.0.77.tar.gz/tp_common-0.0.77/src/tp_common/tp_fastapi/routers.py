from __future__ import annotations

import importlib
import sys
from collections.abc import Iterable
from pathlib import Path

from fastapi import APIRouter, FastAPI


def _iter_route_files(base_dir: Path) -> Iterable[Path]:
    # `route.py` в любой папке внутри base_dir
    yield from base_dir.rglob("route.py")

    # Также поддерживаем паттерн `*_route.py` (часто встречается в `routes/`).
    yield from base_dir.rglob("*_route.py")


def _best_sys_path_root_for(base_dir: Path) -> Path | None:
    """
    Возвращает самый "глубокий" sys.path root, который является родителем base_dir.

    Это позволяет корректно построить import-путь вида `api.accounts.route`
    в проектах со `src` layout, где в sys.path лежит `.../src`.
    """

    candidates: list[Path] = []
    for entry in sys.path:
        if not entry:
            continue
        try:
            root = Path(entry).resolve()
        except OSError:
            continue
        try:
            base_dir.relative_to(root)
        except ValueError:
            continue
        candidates.append(root)

    if not candidates:
        return None
    return max(candidates, key=lambda p: len(str(p)))


def auto_include_routers(app: FastAPI, base_dir: Path) -> int:
    """Автоматическое подключение роутеров из `route.py` / `*_route.py` внутри `base_dir`."""

    routers_count = 0
    base_dir = base_dir.resolve()

    import_root = _best_sys_path_root_for(base_dir)
    if import_root is None:
        raise ValueError(
            "base_dir должен находиться внутри одной из директорий sys.path "
            "(например, внутри `src/`). Не удалось построить import-путь."
        )

    seen_modules: set[str] = set()
    for route_file in _iter_route_files(base_dir):
        module_path = (
            route_file.with_suffix("")
            .resolve()
            .relative_to(import_root)
            .as_posix()
            .replace("/", ".")
        )

        if module_path in seen_modules:
            continue
        seen_modules.add(module_path)

        module = importlib.import_module(module_path)

        router = getattr(module, "route", None)
        if router is None or not isinstance(router, APIRouter):
            # Роутер может называться иначе (users, clients и т.д.)
            router = next(
                (
                    v
                    for k, v in vars(module).items()
                    if not k.startswith("_") and isinstance(v, APIRouter)
                ),
                None,
            )

        if router is None or not isinstance(router, APIRouter):
            continue
        if not router.prefix:
            raise ValueError(f"prefix cannot be empty ({module_path})")

        app.include_router(router)
        routers_count += 1

    return routers_count
