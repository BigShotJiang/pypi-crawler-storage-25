"""
HTTP middleware для FastAPI: trace_id, access-лог, перехват исключений.

См. также ``tp_common.tp_logger.fastapi_integration`` (``get_request_logger`` и т.д.).
"""

# pylint: disable=broad-exception-caught

from __future__ import annotations

import json
import time
import uuid
from collections.abc import Awaitable, Callable

from fastapi import Request
from fastapi.exceptions import RequestValidationError
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, Response

from tp_common.exceptions import TPException
from tp_common.tp_logger.fastapi_integration import get_request_logger
from tp_common.tp_logger.tp_logging import generate_trace_id

# Имена заголовков для передачи trace_id (клиент может передать свой id)
TRACE_ID_HEADERS = ("x-trace-id", "x-correlation-id")
RESPONSE_TRACE_HEADER = "x-trace-id"


class TpMiddleware(BaseHTTPMiddleware):
    """
    Базовый middleware приложения.

    Отвечает за единый trace_id и последнюю линию обработки ошибок, которые
    не были обработаны на уровне роутеров/сервисов.

    Поведение:
    - Устанавливает trace_id из заголовка (X-Trace-ID и др.) или генерирует новый.
    - После ответа пишет в TpLogger строку: метод, путь, статус, длительность (с тем же trace_id).
    - Добавляет X-Trace-ID в ответ.
    - Перехватывает TPException и возвращает JSON в формате:
      {"message": "...", "error": "...", "traceId": "..."}.
    - Перехватывает прочие необработанные Exception и возвращает 500 в том же формате.
    """

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        trace_id: uuid.UUID | None = None
        for header_name in TRACE_ID_HEADERS:
            value = request.headers.get(header_name)
            if value:
                try:
                    trace_id = uuid.UUID(value.strip())
                except ValueError:
                    trace_id = None
                break
        if trace_id is None:
            trace_id = generate_trace_id()
        request.state.trace_id = trace_id

        started = time.perf_counter()
        status_code = 500
        try:
            response = await call_next(request)
            status_code = response.status_code
            if response.status_code == 422:
                response = await _maybe_transform_validation_response(
                    request=request,
                    response=response,
                    trace_id=trace_id,
                )
                status_code = response.status_code
            response.headers[RESPONSE_TRACE_HEADER] = str(trace_id)
            return response
        except RequestValidationError as exc:
            status_code = 422
            try:
                logger = get_request_logger(request)
                logger.info(
                    "Ошибка валидации запроса",
                    extra={"errors_count": len(exc.errors())},
                )
            except Exception:  # noqa: BLE001
                pass
            response = JSONResponse(
                status_code=status_code,
                content={
                    "message": "Ошибка валидации",
                    "error": "validation_error",
                    "errors": _format_validation_errors(exc),
                    "traceId": str(trace_id),
                },
            )
            response.headers[RESPONSE_TRACE_HEADER] = str(trace_id)
            return response
        except TPException as exc:
            status_code = exc.status_code
            response = JSONResponse(
                status_code=status_code,
                content={
                    "message": exc.message,
                    "error": exc.error,
                    "traceId": str(trace_id),
                },
            )
            response.headers[RESPONSE_TRACE_HEADER] = str(trace_id)
            return response
        except Exception as exc:
            status_code = 500
            try:
                logger = get_request_logger(request)
                logger.critical("Необработанное исключение: %s", exc)
            except Exception:  # noqa: BLE001
                pass
            response = JSONResponse(
                status_code=500,
                content={
                    "message": "Internal Server Error",
                    "error": "internal_server_error",
                    "traceId": str(trace_id),
                },
            )
            response.headers[RESPONSE_TRACE_HEADER] = str(trace_id)
            return response
        finally:
            _tp_log_http_request(request, status_code, time.perf_counter() - started)


async def _maybe_transform_validation_response(
    *, request: Request, response: Response, trace_id: uuid.UUID
) -> Response:
    """
    FastAPI по умолчанию обрабатывает ``RequestValidationError`` сам и возвращает 422
    в виде ``{"detail": [...]}`` (исключение в middleware не попадает).

    Здесь мы перехватываем такой ответ и приводим его к единому формату tp-common.
    """
    content_type = response.headers.get("content-type", "")
    if "application/json" not in content_type.lower():
        return response

    body: bytes = b""
    direct_body = getattr(response, "body", None)
    if isinstance(direct_body, (bytes, bytearray)) and direct_body:
        body = bytes(direct_body)
    else:
        # У FastAPI/Starlette тело часто лежит в body_iterator (StreamingResponse).
        iterator = getattr(response, "body_iterator", None)
        if iterator is None:
            return response
        try:
            chunks: list[bytes] = []
            async for chunk in iterator:
                if isinstance(chunk, (bytes, bytearray)):
                    chunks.append(bytes(chunk))
                else:
                    chunks.append(str(chunk).encode("utf-8"))
            body = b"".join(chunks)
        except Exception:  # noqa: BLE001
            return response
        if not body:
            return response

    try:
        payload = json.loads(body.decode("utf-8"))
    except Exception:  # noqa: BLE001
        return response

    detail = payload.get("detail")
    if not isinstance(detail, list):
        return response

    try:
        logger = get_request_logger(request)
        logger.info("Ошибка валидации запроса", extra={"errors_count": len(detail)})
    except Exception:  # noqa: BLE001
        pass

    transformed = JSONResponse(
        status_code=422,
        content={
            "message": "Ошибка валидации",
            "error": "validation_error",
            "errors": _format_validation_error_dicts(detail),
            "traceId": str(trace_id),
        },
    )

    # Сохраним заголовки (кроме content-length, он изменился).
    for k, v in response.headers.items():
        if k.lower() in {"content-length", RESPONSE_TRACE_HEADER.lower()}:
            continue
        transformed.headers[k] = v
    return transformed


def _format_validation_error_dicts(detail: list[object]) -> list[dict[str, object]]:
    formatted: list[dict[str, object]] = []
    for item in detail:
        if not isinstance(item, dict):
            continue
        loc = item.get("loc") or ()
        loc_tuple = tuple(loc) if isinstance(loc, (list, tuple)) else ()

        loc_tail = loc_tuple[1:] if len(loc_tuple) > 1 else loc_tuple
        index: int | None = None
        field_parts: list[str] = []
        for part in loc_tail:
            if isinstance(part, int) and index is None:
                index = part
                continue
            field_parts.append(str(part))

        field = ".".join(field_parts) if field_parts else ""
        formatted.append(
            {
                "field": field,
                "message": item.get("msg") or "Invalid value",
                "index": index,
            }
        )
    return formatted


def _format_validation_errors(exc: RequestValidationError) -> list[dict[str, object]]:
    """
    Приведение ``RequestValidationError`` к компактному формату ошибок:
    [{field: str, message: str, index: int | None}]
    """
    formatted: list[dict[str, object]] = []
    for err in exc.errors():
        loc = err.get("loc") or ()
        # pydantic/fastapi обычно добавляет префикс: ("body"|"query"|"path"|"header", ...)
        loc_tail = loc[1:] if len(loc) > 1 else loc

        index: int | None = None
        field_parts: list[str] = []
        for part in loc_tail:
            if isinstance(part, int) and index is None:
                index = part
                continue
            field_parts.append(str(part))

        field = ".".join(field_parts) if field_parts else ""
        formatted.append(
            {
                "field": field,
                "message": err.get("msg") or "Invalid value",
                "index": index,
            }
        )
    return formatted


def _tp_log_http_request(request: Request, status_code: int, duration_s: float) -> None:
    """Одна строка access-лога на запрос (вызывается из ``TpMiddleware``)."""
    try:
        logger = get_request_logger(request)
        client = request.client
        client_host = client.host if client else None
        duration_ms = duration_s * 1000
        logger.info(
            "%s %s -> %s",
            request.method,
            request.url.path,
            status_code,
            extra={
                "http_method": request.method,
                "http_path": request.url.path,
                "http_status": status_code,
                "duration_ms": round(duration_ms, 3),
                "client_host": client_host,
            },
        )
    except Exception:  # noqa: BLE001
        pass
