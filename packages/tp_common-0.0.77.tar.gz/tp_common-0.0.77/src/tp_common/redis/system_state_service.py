from enum import StrEnum

from redis.asyncio import Redis

from tp_common.decorators.decorator_retry_forever import retry_forever
from tp_common.tp_logger.tp_logging import TpLogger


class SystemState(StrEnum):
    NORMAL = "normal"
    MAINTENANCE = "maintenance"


class SystemStateService:
    """Сервис хранения системных параметров в Redis."""

    SYSTEM_STATE_KEY = ""

    def __init__(self, service_name: str, redis: Redis, logger: TpLogger) -> None:
        """Инициализирует сервис Redis-клиентом и логгером."""
        self.SYSTEM_STATE_KEY = service_name + ":system-state"
        self.redis = redis
        self.logger = logger

    @retry_forever(
        start_message=f"Чтение состояния системы по ключу: {SYSTEM_STATE_KEY}",
        error_message="Ошибка при чтении состояния системы из Redis!",
    )
    async def get(self) -> SystemState:
        """Возвращает состояние системы, создавая ключ со значением по умолчанию."""
        value = await self.redis.get(self.SYSTEM_STATE_KEY)
        if value is None:
            self.logger.info(
                "Состояние системы не найдено в Redis, создаем ключ со значением по умолчанию"
            )
            system_state = SystemState.NORMAL
            await self.redis.set(self.SYSTEM_STATE_KEY, system_state)
            return system_state
        system_state = SystemState(value)
        self.logger.debug(f"Состояние системы получено из Redis: {system_state}")
        return system_state

    @retry_forever(
        start_message="Сохранение состояния системы {system_state}",
        error_message="Ошибка при сохранении состояния системы в Redis!",
    )
    async def set(self, system_state: SystemState) -> None:
        """Сохраняет состояние системы в Redis."""
        await self.redis.set(self.SYSTEM_STATE_KEY, str(system_state.value))
