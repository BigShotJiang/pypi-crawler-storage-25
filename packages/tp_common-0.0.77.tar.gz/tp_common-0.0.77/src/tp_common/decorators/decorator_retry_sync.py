import functools
import inspect
import logging
import time
from collections.abc import Callable
from typing import ParamSpec, Protocol, TypeVar, cast

P = ParamSpec("P")  # параметры оригинальной функции
R = TypeVar("R")  # возвращаемый тип оригинальной функции


class _HasLogger(Protocol):
    logger: logging.Logger


def retry_sync(
    error_message: str,
    start_message: str | None = None,
    delay: int = 10,
    backoff: float = 1.2,
    max_delay: int = 60,
    ignore_exceptions: list[type[Exception | BaseException]] | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """
    Оборачивает только метод класса. Синхронная версия без Discord.
    """
    ignored_list: list[type[Exception] | type[BaseException]] = (
        ignore_exceptions if ignore_exceptions is not None else []
    )

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        sig = inspect.signature(func)

        @functools.wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            # --- Собираем контекст для подстановки в сообщения
            self = args[0] if args else None  # self итак уже есть в *args
            if self is None:
                raise ValueError(
                    "@retry_forever_sync применяется только к методу класса, "
                    f"но {func.__qualname__} не принимает аргументов"
                )
            try:
                bound = sig.bind(*args, **kwargs)
                bound.apply_defaults()
                context = dict(bound.arguments)
            except Exception:
                context = {"self": self}

            str_context = {k: str(v) for k, v in context.items()}

            # --- Распаковываем self.*
            if "self" in context:
                self_obj = context["self"]
                try:
                    for attr in dir(self_obj):
                        if not attr.startswith("_"):
                            val = getattr(self_obj, attr)
                            if not callable(val):
                                str_context[attr] = str(val)
                except Exception:
                    pass

            # --- Лог старта (если задан start_message)
            self_typed = cast(_HasLogger, self)
            if start_message:
                try:
                    self_typed.logger.debug(start_message.format_map(str_context))
                except Exception:
                    self_typed.logger.debug(start_message)

            # --- Цикл повторов
            current_delay: float = float(delay)
            retry_count = 0

            while True:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if type(e) in ignored_list:
                        raise e from e

                    if not getattr(self, "retry_enabled", True):
                        try:
                            no_retry_msg = error_message.format_map(
                                {**str_context, "e": str(e)}
                            )
                        except Exception:
                            no_retry_msg = error_message
                        self_typed.logger.exception(f"❌ {no_retry_msg}")
                        raise e from e

                    retry_count += 1

                    str_context_with_exception = {
                        **str_context,
                        "e": str(e),
                        "retry_count": retry_count,
                    }

                    try:
                        err_msg = error_message.format_map(str_context_with_exception)
                    except Exception:
                        err_msg = error_message

                    if retry_count % 10 == 0:
                        self_typed.logger.critical(f"❌ {err_msg}", exc_info=True)
                    else:
                        self_typed.logger.exception(f"❌ {err_msg}")

                    self_typed.logger.info(
                        f"🔁 Повтор #{retry_count} через {current_delay:.1f} сек..."
                    )

                    time.sleep(current_delay)
                    current_delay = min(current_delay * backoff, float(max_delay))

        return wrapper

    return decorator
