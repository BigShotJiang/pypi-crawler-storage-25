"""Переиспользуемые миксины для декларативных моделей SQLAlchemy."""

from tp_common.model.mixins.created_updated import CreatedUpdatedMixin

__all__ = ["CreatedUpdatedMixin"]
