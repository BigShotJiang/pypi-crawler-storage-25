"""
Пример использования BaseClient с async with и типизированными схемами.

Запуск (из корня проекта):
    python -m tp_common.base_client.example

Используется публичный API https://jsonplaceholder.typicode.com (без ключей).
"""

from __future__ import annotations

import asyncio

from pydantic import BaseModel, RootModel

from tp_common.base_client.client import BaseClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory

LOG_FACTORY = TpLoggerFactory(EnvironmentType.DEV)
logger = LOG_FACTORY.get_logger("base_client_example")


class Post(BaseModel):
    """Один пост (ответ GET /posts/:id или тело ответа POST /posts)."""

    userId: int
    id: int
    title: str
    body: str


class PostsParams(BaseModel):
    userId: int


class CreatePostRequest(BaseModel):
    """Тело запроса POST /posts."""

    title: str
    body: str
    userId: int


class PostsListResponse(RootModel[list[Post]]):
    """Ответ GET /posts — список постов."""


async def main() -> None:
    base_url = "https://jsonplaceholder.typicode.com"

    client = BaseClient(
        base_url=base_url,
        headers={"X-Custom-Header": "example"},
        retry_on_proxy_error=False,
        max_retries=3,
        logger=logger,
    )

    async with client:
        # GET с типизированным ответом — сразу модель
        post: Post = await client.get("/posts/1", Post)
        logger.info("GET /posts/1: %s", post.title[:50])

        # POST с телом-схемой и типизированным ответом
        created: Post = await client.post(
            "/posts",
            Post,
            body=CreatePostRequest(title="Example", body="Body text", userId=1),
        )
        logger.info("POST /posts: %s %s", created.id, created.title)

        # GET со списком — схема RootModel[list[Post]]
        posts_list: PostsListResponse = await client.get(
            "/posts",
            PostsListResponse,
            params=PostsParams(userId=1),
        )
        logger.info("GET /posts?userId=1: count = %s", len(posts_list.root))

        # Настройки можно менять после создания
        client.retry_on_proxy_error = True
        client.max_retries = 5

    # После выхода из async with сессия закрыта; клиент можно использовать снова


if __name__ == "__main__":
    asyncio.run(main())
