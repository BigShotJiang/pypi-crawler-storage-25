from urllib.parse import urlparse


def parse_url_with_auth(url: str) -> tuple[str, str, str]:
    """Парсит URL вида протокол://логин:пароль@хост/путь -> (base_url, login, password)."""
    if not url or not url.strip():
        return ("", "", "")

    parsed = urlparse(url)
    netloc = parsed.hostname or ""
    if parsed.port:
        netloc = f"{netloc}:{parsed.port}"

    path = parsed.path if parsed.path else "/"
    base_url = f"{parsed.scheme}://{netloc}{path}"
    return (base_url, parsed.username or "", parsed.password or "")


def parse_url_with_token(url: str) -> tuple[str, str]:
    """
    Парсит URL вида протокол://token@хост/путь или протокол://:token@хост/путь
    и возвращает (base_url, token).
    """
    if not url or not url.strip():
        return ("", "")

    parsed = urlparse(url)
    netloc = parsed.hostname or ""
    if parsed.port:
        netloc = f"{netloc}:{parsed.port}"

    path = parsed.path if parsed.path else "/"
    base_url = f"{parsed.scheme}://{netloc}{path}"
    token = parsed.password or parsed.username or ""
    return (base_url, token)
