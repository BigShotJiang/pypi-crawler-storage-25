from __future__ import annotations

import asyncio
import configparser
import io
import logging
import sys
from contextlib import redirect_stderr
from pathlib import Path
from typing import TextIO

from alembic import command
from alembic.config import Config
from alembic.script import ScriptDirectory
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Connection, Engine, make_url
from sqlalchemy.exc import ProgrammingError

from tp_common.redis.system_state_service import SystemState, SystemStateService
from tp_common.tp_logger.tp_logging import TpLogger


class _AlembicLogBufferHandler(logging.Handler):
    """Буферизует строки ``logging`` на время ``command.upgrade`` (см. ``check_and_apply_migrations``)."""

    def __init__(self, lines: list[str]) -> None:
        super().__init__(level=logging.INFO)
        self._lines = lines
        self.setFormatter(logging.Formatter("%(levelname)s %(name)s %(message)s"))

    def emit(self, record: logging.LogRecord) -> None:
        self._lines.append(self.format(record))


class DbInitMigration:
    """Проверка схемы и накат Alembic; при накате — сигнал в Redis (обслуживание / норма).

    1. Сравнить версию в БД с последней ревизией в коде.
    2. Если всё совпадает — выйти, Redis не трогать.
    3. Если нужен накат — записать в Redis режим обслуживания.
    4. Выполнить upgrade до head.
    5. В любом случае после блока наката вернуть в Redis обычный режим.

    При создании подключения к БД при необходимости создаётся сама база в кластере.
    """

    REPO_MARKER = "pyproject.toml"
    ALEMBIC_INI_MARKER = "alembic.ini"
    ALEMBIC_DIR_MARKER = "alembic"

    def __init__(
        self,
        logger: TpLogger,
        state_svc: SystemStateService,
        is_local: bool | None,
        db_url: str,
        project_root: Path | str | None = None,
    ) -> None:
        """
        Инициализирует сервис миграции БД.

        :param logger: Логгер приложения.
        :param state_svc: Сервис управления системным состоянием в Redis.
        """
        self.is_local = is_local
        self.db_url = db_url
        self.logger = logger
        self.state_svc = state_svc
        self._project_root = (
            Path(project_root).resolve() if project_root is not None else None
        )

    @classmethod
    def _is_project_root(cls, path: Path) -> bool:
        return (path / cls.ALEMBIC_INI_MARKER).is_file() and (
            path / cls.ALEMBIC_DIR_MARKER
        ).is_dir()

    def _discover_project_root(self) -> Path:
        # 1) Рабочая директория процесса (типичный запуск сервиса/воркера).
        cwd = Path.cwd().resolve()
        for candidate in (cwd, *cwd.parents):
            if self._is_project_root(candidate):
                return candidate

        # 2) Фолбэк для запуска из исходников библиотеки.
        current = Path(__file__).resolve().parent
        for candidate in (current, *current.parents):
            if self._is_project_root(candidate):
                return candidate

        raise RuntimeError(
            "Не удалось определить корень проекта: ожидаются alembic.ini и каталог alembic. "
            "Передайте project_root явно в DbInitMigration(..., project_root=...)"
        )

    @property
    def project_root(self) -> Path:
        """
        Возвращает корневую директорию проекта с Alembic.
        """
        if self._project_root is not None:
            return self._project_root
        self._project_root = self._discover_project_root()
        return self._project_root

    @property
    def alembic_ini_path(self) -> Path:
        return self.project_root / "alembic.ini"

    @property
    def alembic_script_dir(self) -> Path:
        """Каталог скриптов Alembic (рядом с ``alembic.ini``)."""
        return self.project_root / "alembic"

    def _alembic_config_from_ini_utf8(self, *, stdout: TextIO | None = None) -> Config:
        """
        Собирает Alembic ``Config`` без чтения ini через locale (Windows cp1251).

        Секция ``[alembic]`` читается ``configparser`` с ``encoding=utf-8``,
        опции переносятся в ``set_main_option``; ``%(here)s`` — корень репозитория.
        """
        # ``RawConfigParser`` — чтобы не выполнялась интерполяция: в ``alembic.ini``
        # значения типа ``file_template = %%(year)d-...%%(rev)s_%%(slug)s`` содержат
        # экранированные ``%%``, которые должен обработать сам Alembic, а не этот парсер.
        # Обычный ``ConfigParser`` превратил бы ``%%`` в ``%`` и свалил бы ``set_main_option``
        # ошибкой ``invalid interpolation syntax`` (форматы вида ``%(year)d`` не распознаются
        # как ссылки интерполяции и оставляют «голые» ``%`` в строке).
        parser = configparser.RawConfigParser()
        read = parser.read(self.alembic_ini_path, encoding="utf-8")
        if not read:
            msg = f"Не удалось прочитать {self.alembic_ini_path}"
            raise RuntimeError(msg)
        if not parser.has_section("alembic"):
            msg = "В alembic.ini отсутствует секция [alembic]"
            raise RuntimeError(msg)

        here = self.project_root.resolve().as_posix()
        cfg = Config(
            config_args={"here": here},
            stdout=stdout if stdout is not None else sys.stdout,
        )
        for key, raw in parser.items("alembic"):
            if raw is None:
                continue
            value = str(raw).strip()
            if value:
                cfg.set_main_option(key, value)

        # В ini ``script_location = alembic`` относительно ``%(here)s``; при запуске из IDE cwd
        # может быть не корень репозитория — задаём абсолютный путь к каталогу скриптов.
        cfg.set_main_option(
            "script_location",
            str(self.alembic_script_dir.resolve()),
        )
        cfg.set_main_option("prepend_sys_path", here)
        return cfg

    def _log_alembic_command_output(
        self,
        stdout: str,
        stderr: str,
        logging_lines: list[str],
    ) -> None:
        for line in stdout.splitlines():
            if line.strip():
                self.logger.info("Alembic stdout: %s", line)
        for line in stderr.splitlines():
            if line.strip():
                self.logger.info("Alembic stderr: %s", line)
        for line in logging_lines:
            if line.strip():
                self.logger.info("Alembic log: %s", line)

    async def start(self) -> None:
        """Сверить версию схемы с кодом; при необходимости накатить и сигнализировать в Redis.

        1. Если БД уже на head — выйти, Redis не трогать.
        2. Иначе MAINTENANCE в Redis, синхронный upgrade Alembic, затем NORMAL.
        Redis здесь async, вызовы Alembic — sync.
        """
        engine = self.create_migration_engine()
        try:
            head_revision = self.get_head_revision()

            with engine.connect() as conn:
                if not self.needs_migration(conn, head_revision):
                    if head_revision is None:
                        self.logger.info(
                            "Миграции Alembic отсутствуют (нет revision-файлов в каталоге "
                            "скриптов); таблица alembic_version не задана — шаг пропущен",
                        )
                    else:
                        self.logger.info(
                            "БД актуальна (head=%s), миграции не нужны",
                            head_revision,
                        )
                    return
        finally:
            engine.dispose()

        await self.state_svc.set(SystemState.MAINTENANCE)

        if self.is_local is None:
            await self._wait_before_migrations(total_seconds=30, step_seconds=5)
        # ``alembic/env.py`` на уровне модуля вызывает ``asyncio.run(run_migrations_online())``.
        # Мы уже в работающем event loop (``asyncio.run(worker.start())``), поэтому прямой
        # вызов упадёт с ``RuntimeError: asyncio.run() cannot be called from a running event loop``.
        # Выносим синхронный upgrade в отдельный поток — там свой «чистый» контекст для asyncio.run.
        await asyncio.to_thread(self.apply_migrations_full_cycle)

    async def _wait_before_migrations(
        self,
        *,
        total_seconds: int,
        step_seconds: int,
    ) -> None:
        """Ожидание перед накатом миграций с периодическим логом обратного отсчёта.

        Нужен зазор после перевода системы в ``MAINTENANCE``, чтобы воркеры
        успели корректно остановиться. Чтобы простой был виден в логах, ждём
        не одним ``asyncio.sleep``, а шагами по ``step_seconds`` секунд и на
        каждом шаге выводим, сколько осталось до старта миграций.
        """
        if total_seconds <= 0:
            return

        step = max(1, step_seconds)
        remaining = total_seconds
        self.logger.info(
            "MAINTENANCE включён, ожидание %d сек перед накатом миграций",
            total_seconds,
        )
        while remaining > 0:
            chunk = min(step, remaining)
            await asyncio.sleep(chunk)
            remaining -= chunk
            if remaining > 0:
                self.logger.info(
                    "Ожидание перед миграциями: осталось %d сек",
                    remaining,
                )
        self.logger.info("Ожидание завершено, запускаю накат миграций")

    def _build_sync_sqlalchemy_url(self) -> str:
        """
        Преобразует async SQLAlchemy URL в sync URL для Alembic и sync Engine.

        Поддерживает:
        - postgresql+asyncpg:// -> postgresql+psycopg2://
        - postgresql:// -> postgresql+psycopg2://
        """
        url = self.db_url

        if url.startswith("postgresql+asyncpg://"):
            return url.replace("postgresql+asyncpg://", "postgresql+psycopg2://", 1)

        if url.startswith("postgresql://"):
            return url.replace("postgresql://", "postgresql+psycopg2://", 1)

        return url

    def ensure_target_database_exists(self) -> None:
        """
        Если целевой кластер PostgreSQL доступен, а БД из ``POSTGRES_URL`` ещё нет —
        создаёт её (подключение к служебной БД ``postgres``, ``CREATE DATABASE`` в autocommit).
        """
        sync_url = self._build_sync_sqlalchemy_url()
        if not sync_url.startswith("postgresql"):
            return

        url = make_url(sync_url)
        target_db = url.database
        if not target_db or target_db == "postgres":
            return

        admin_url = url.set(database="postgres").render_as_string(hide_password=False)
        admin_engine = create_engine(
            admin_url,
            isolation_level="AUTOCOMMIT",
            pool_pre_ping=True,
        )
        try:
            with admin_engine.connect() as conn:
                exists = conn.execute(
                    text("SELECT 1 FROM pg_database WHERE datname = :name"),
                    {"name": target_db},
                ).scalar()
                if exists:
                    return

                self.logger.info("БД «%s» не найдена, создаём", target_db)
                quoted = conn.dialect.identifier_preparer.quote(target_db)
                conn.execute(text(f"CREATE DATABASE {quoted}"))
                self.logger.info("БД «%s» создана", target_db)
        finally:
            admin_engine.dispose()

    def create_migration_engine(self) -> Engine:
        """Создаёт sync Engine для проверки ревизий и вспомогательных sync-операций."""
        self.ensure_target_database_exists()
        return create_engine(self._build_sync_sqlalchemy_url(), pool_pre_ping=True)

    def check_and_apply_migrations(self) -> None:
        """
        Сверяет ``alembic_version`` с head из скриптов; при расхождении — ``upgrade head`` через API Alembic.

        Чтение ``alembic.ini`` — только UTF-8 (см. ``_alembic_config_from_ini_utf8``), без subprocess и locale ini.
        """
        head_revision = self.get_head_revision()
        engine = self.create_migration_engine()
        try:
            with engine.connect() as conn:
                if not self.needs_migration(conn, head_revision):
                    if head_revision is None:
                        self.logger.info(
                            "Файлов миграций нет; upgrade не выполняется",
                        )
                    else:
                        self.logger.info("Неприменённых миграций нет")
                    return
        finally:
            engine.dispose()

        self.logger.info("Обнаружены неприменённые миграции")
        stdout_buf = io.StringIO()
        stderr_buf = io.StringIO()

        alembic_cfg = self._alembic_config_from_ini_utf8(stdout=stdout_buf)

        self.logger.info("Alembic: command.upgrade(head)")

        log_lines: list[str] = []
        log_handler = _AlembicLogBufferHandler(log_lines)

        capture_loggers: list[logging.Logger] = [logging.getLogger("alembic")]
        capture_loggers.append(logging.getLogger("sqlalchemy.engine"))

        saved: list[tuple[logging.Logger, int, bool]] = []
        for lg in capture_loggers:
            saved.append((lg, lg.level, lg.propagate))
            lg.addHandler(log_handler)
            lg.propagate = True
            if lg.getEffectiveLevel() > logging.INFO:
                lg.setLevel(logging.INFO)

        try:
            with redirect_stderr(stderr_buf):
                command.upgrade(alembic_cfg, "head")
        finally:
            for lg, prev_level, prev_propagate in saved:
                lg.removeHandler(log_handler)
                lg.setLevel(prev_level)
                lg.propagate = prev_propagate
            log_handler.close()

        self.logger.debug("Alembic upgrade: после command.upgrade")

        self._log_alembic_command_output(
            stdout_buf.getvalue(),
            stderr_buf.getvalue(),
            log_lines,
        )
        self.logger.info("Миграции успешно применены")

    def apply_migrations_full_cycle(self) -> None:
        """Применяет миграции до head (без сидов и прочих post-шагов)."""
        self.check_and_apply_migrations()

    def get_head_revision(self) -> str | None:
        """
        Возвращает Alembic head revision из локального кода.

        ``None`` — в каталоге скриптов нет ни одной ревизии (например, пустой
        ``alembic/versions``). Иначе ожидается ровно одна head-ветка; при нескольких
        heads — исключение (нужен merge).
        """
        script_dir = self.alembic_script_dir.resolve()
        script = ScriptDirectory(
            str(script_dir),
            recursive_version_locations=True,
        )
        heads = script.get_heads()

        if len(heads) == 0:
            return None
        if len(heads) > 1:
            msg = (
                "Ожидается одна Alembic head, получено несколько: "
                f"{heads!r}. Объедините ветки (alembic merge)."
            )
            raise RuntimeError(msg)

        return heads[0]

    def get_current_revision(self, conn: Connection) -> str | None:
        """
        Возвращает текущую revision из таблицы alembic_version.

        :param conn: Активное SQLAlchemy соединение.
        :return: Текущая revision или None, если таблица ещё не существует.
        """
        try:
            revision = conn.execute(
                text("SELECT version_num FROM alembic_version"),
            ).scalar_one_or_none()
        except ProgrammingError:
            return None

        return str(revision) if revision is not None else None

    def needs_migration(self, conn: Connection, head_revision: str | None) -> bool:
        """
        Проверяет, нужна ли миграция БД.

        Миграция нужна, если:
        - в коде есть head-ревизия и таблицы ``alembic_version`` ещё нет;
        - в коде есть head и текущая revision отличается от неё.

        Если в коде нет ни одной ревизии (``head_revision is None``) и в БД тоже
        нет записи в ``alembic_version`` — миграция не нужна. Если в БД есть
        ревизия, а в репозитории файлов миграций нет — исключение (несогласованное
        состояние).

        :param conn: Активное SQLAlchemy соединение.
        :param head_revision: Локальная Alembic head revision или None.
        :return: True, если БД требует миграции.
        """
        current_revision = self.get_current_revision(conn)
        if head_revision is None:
            if current_revision is None:
                return False
            msg = (
                f"В БД зафиксирована ревизия Alembic {current_revision!r}, но в каталоге "
                f"миграций нет ни одной head (пустой {self.alembic_script_dir / 'versions'}?)."
            )
            raise RuntimeError(msg)

        if current_revision is None:
            return True

        return current_revision != head_revision

    def should_skip_prepare(self, engine: Engine, head_revision: str | None) -> bool:
        with engine.connect() as conn:
            if not self.needs_migration(conn, head_revision):
                if head_revision is None:
                    self.logger.info(
                        "Миграции Alembic отсутствуют; подготовка не требуется",
                    )
                else:
                    self.logger.info(
                        "БД актуальна (head=%s), миграции не нужны",
                        head_revision,
                    )
                return True
        return False

    def should_skip_prepare_after_lock(
        self,
        engine: Engine,
        head_revision: str | None,
    ) -> bool:
        with engine.connect() as conn:
            if not self.needs_migration(conn, head_revision):
                self.logger.info(
                    "После получения lock миграции уже не нужны "
                    "(другой инстанс успел применить изменения)"
                )
                return True
        return False
