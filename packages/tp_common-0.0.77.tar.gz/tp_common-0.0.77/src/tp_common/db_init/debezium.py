"""Включает для таблиц режим полной строки в WAL (нужно репликаторам вроде Debezium)."""

from __future__ import annotations

import re
from pathlib import Path

from sqlalchemy import text
from sqlalchemy.engine import Engine

from tp_common.tp_logger.tp_logging import TpLogger


class DebeziumInit:
    """Один прогон: для списка таблиц выставить REPLICA IDENTITY FULL, если ещё не стоит.

    start():

    1. Собрать имена таблиц из доменных model.py рядом с event.py.
    2. Для каждой таблицы в PostgreSQL проверить режим репликации.
    3. При необходимости выполнить ALTER TABLE … REPLICA IDENTITY FULL.

    dispose() закрывает переданный sync-движок SQLAlchemy.
    """

    TABLE_NAME_RE = re.compile(r'__tablename__\s*=\s*["\']([^"\']+)["\']')
    REPO_MARKER = "pyproject.toml"
    DOMAIN_EVENT_FILE_GLOB = "src/domain/**/event.py"

    RELREPLIDENT_STATUS = text(
        """
                                SELECT c.relreplident
                                FROM pg_class c
                                         JOIN pg_namespace n
                                              ON n.oid = c.relnamespace
                                WHERE n.nspname = :schema
                                  AND c.relname = :name
                                  AND c.relkind IN ('r', 'p')
                                """
    )

    def __init__(self, logger: TpLogger, engine: Engine) -> None:
        self.logger = logger
        self.engine = engine

    def project_root(self) -> Path:
        current = Path(__file__).resolve().parent
        for path in (current, *current.parents):
            if (path / self.REPO_MARKER).is_file():
                return path
        raise RuntimeError(f"Не найден {self.REPO_MARKER} выше {current}")

    def discover_debezium_tables(
        self,
        source_dir: Path | str,
        file_pattern: str = "src/domain/**/event.py",
    ) -> list[str]:
        root = Path(source_dir)
        if not root.exists():
            raise FileNotFoundError(f"Не найден каталог: {root}")

        tables: set[str] = set()

        for event_file in root.glob(file_pattern):
            if not event_file.is_file():
                continue

            model_file = event_file.parent / "model.py"
            if not model_file.is_file():
                continue

            content = model_file.read_text(encoding="utf-8")
            tables.update(
                name.strip()
                for name in self.TABLE_NAME_RE.findall(content)
                if name.strip()
            )

        if not tables:
            raise ValueError(f"Не найдены таблицы по шаблону '{file_pattern}' в {root}")

        return sorted(tables)

    def start(
        self,
        schema: str = "public",
        source_dir: Path | str | None = None,
        file_pattern: str = "src/domain/**/event.py",
    ) -> None:
        root = Path(source_dir) if source_dir is not None else self.project_root()
        tables = self.discover_debezium_tables(root, file_pattern)

        with self.engine.begin() as conn:
            preparer = conn.dialect.identifier_preparer
            schema_ident = preparer.quote_schema(schema)

            for table in tables:
                table_ident = preparer.quote(table)
                qualified_name = f"{schema_ident}.{table_ident}"

                relreplident = conn.execute(
                    self.RELREPLIDENT_STATUS,
                    {"schema": schema, "name": table},
                ).scalar_one_or_none()

                if relreplident is None:
                    self.logger.warning(
                        "Пропуск REPLICA IDENTITY: в каталоге нет таблицы %s",
                        qualified_name,
                    )
                    continue

                if relreplident == "f":
                    self.logger.debug(
                        "REPLICA IDENTITY FULL уже установлен: %s",
                        qualified_name,
                    )
                    continue

                conn.execute(
                    text(f"ALTER TABLE {qualified_name} REPLICA IDENTITY FULL")
                )
                self.logger.info(
                    "REPLICA IDENTITY FULL применён: %s",
                    qualified_name,
                )

    def dispose(self) -> None:
        self.engine.dispose()
