from __future__ import annotations

from tp_common.tp_logger.schemas import EnvironmentType


def resolve_realm(env_type: EnvironmentType) -> str:
    realm_by_env: dict[EnvironmentType, str] = {
        EnvironmentType.LOCAL: "dev",
        EnvironmentType.DEV: "dev",
        EnvironmentType.STAGING: "staging",
        EnvironmentType.PROD: "prod",
    }
    return realm_by_env[env_type]
