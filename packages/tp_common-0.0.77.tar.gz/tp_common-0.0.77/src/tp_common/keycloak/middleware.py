"""Проверка access token Keycloak через JWKS (Starlette / FastAPI middleware)."""

from __future__ import annotations

import asyncio
import base64
import json
import threading
from collections.abc import Awaitable, Callable, Sequence
from typing import Any
from urllib.parse import urlparse

import jwt
from jwt import PyJWKClient
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp

from tp_common.keycloak.exceptions import (
    KeycloakInvalidAudience,
    KeycloakInvalidAuthorizationHeader,
    KeycloakInvalidConfiguration,
    KeycloakInvalidIssuer,
    KeycloakInvalidToken,
    KeycloakMissingAuthorizationHeader,
    KeycloakMissingRequiredRole,
    KeycloakTokenExpired,
)
from tp_common.keycloak.utils import resolve_realm
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.utils import parse_url_with_auth


def _decode_keycloak_access_token(
    jwk_client: PyJWKClient,
    keycloak_issuer: str,
    service_name: str,
    required_role: str,
    token: str,
) -> dict[str, Any]:
    try:
        signing_key = jwk_client.get_signing_key_from_jwt(token)
        payload = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            issuer=keycloak_issuer,
            options={"verify_aud": False},
        )
    except jwt.PyJWKClientError:
        # Ошибка получения/разбора JWKS или выбора signing key.
        raise KeycloakInvalidToken() from None

    except jwt.ExpiredSignatureError:
        raise KeycloakTokenExpired() from None

    except jwt.InvalidIssuerError:
        raise KeycloakInvalidIssuer() from None

    except jwt.InvalidTokenError:
        raise KeycloakInvalidToken() from None

    aud = payload.get("aud", [])
    if isinstance(aud, str):
        aud = [aud]

    if service_name not in aud:
        raise KeycloakInvalidAudience()

    roles = payload.get("resource_access", {}).get(service_name, {}).get("roles", [])

    if required_role not in roles:
        raise KeycloakMissingRequiredRole()

    return payload


def _resolve_issuer_for_any_realm(*, allowed_iss_prefix: str, token: str) -> str:
    token_issuer = _extract_iss_from_token(token)
    if not token_issuer:
        raise KeycloakInvalidIssuer("Token is missing 'iss' claim") from None

    token_issuer_norm = token_issuer.rstrip("/")

    # Дешёвая проверка домена + формата "/realms/<realm>" без urlparse.
    if not token_issuer_norm.startswith(allowed_iss_prefix):
        raise KeycloakInvalidIssuer(
            "Invalid issuer domain (token 'iss' does not match configured keycloak_url)"
        ) from None

    realm_part = token_issuer_norm[len(allowed_iss_prefix) :]
    if not realm_part or "/" in realm_part:
        raise KeycloakInvalidIssuer(
            "Invalid issuer domain (token 'iss' does not match configured keycloak_url)"
        ) from None

    return token_issuer_norm


def _get_jwk_client_for_issuer(
    *,
    jwk_clients_by_issuer: dict[str, PyJWKClient],
    jwk_clients_lock: threading.Lock,
    issuer: str,
) -> PyJWKClient:
    jwk_client = jwk_clients_by_issuer.get(issuer)
    if jwk_client is not None:
        return jwk_client

    jwks_url = _build_jwks_url(issuer)
    with jwk_clients_lock:
        jwk_client = jwk_clients_by_issuer.get(issuer)
        if jwk_client is None:
            jwk_client = PyJWKClient(jwks_url)
            jwk_clients_by_issuer[issuer] = jwk_client
    return jwk_client


def _extract_iss_from_token(token: str) -> str | None:
    """
    Достаёт ``iss`` из payload JWT без полноценного ``jwt.decode``.

    Не валидирует подпись/exp/aud — только base64url + JSON парсинг payload.
    Используется как дешёвая предварительная проверка домена в режиме
    ``accept_any_realm_on_domain``.
    """
    try:
        _, payload_b64, _ = token.split(".", 2)
    except ValueError:
        return None
    padded = payload_b64 + "=" * (-len(payload_b64) % 4)
    try:
        decoded = base64.urlsafe_b64decode(padded)
        data = json.loads(decoded)
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict):
        return None
    iss = data.get("iss")
    if isinstance(iss, str) and iss.strip():
        return iss
    return None


def _build_jwks_url(keycloak_base_url: str) -> str:
    """Нормализует keycloak URL до JWKS endpoint."""
    base = keycloak_base_url.rstrip("/")
    if not base:
        raise KeycloakInvalidConfiguration("keycloak_url must not be empty")
    if base.endswith("/protocol/openid-connect/certs"):
        return base
    if "/realms/" in base:
        return f"{base}/protocol/openid-connect/certs"
    return f"{base}/protocol/openid-connect/certs"


def _strip_realm_from_url(keycloak_url: str) -> str:
    """
    Убирает суффикс ``/realms/<realm>`` из URL, если он присутствует.

    Пример:
    - https://keycloak.host/realms/prod -> https://keycloak.host
    - https://keycloak.host/auth/realms/prod -> https://keycloak.host/auth
    """
    parsed = urlparse(keycloak_url.rstrip("/"))
    path = (parsed.path or "").rstrip("/")
    parts = [p for p in path.split("/") if p]
    try:
        idx = parts.index("realms")
    except ValueError:
        return keycloak_url.rstrip("/")

    # Обрезаем "/realms/<realm>" и всё после.
    new_parts = parts[:idx]
    new_path = "/" + "/".join(new_parts) if new_parts else ""
    return parsed._replace(path=new_path).geturl().rstrip("/")


def _build_keycloak_issuer(
    keycloak_base_url: str,
    env_type: EnvironmentType,
) -> str:
    base = keycloak_base_url.rstrip("/")
    base_without_realm = _strip_realm_from_url(base)
    resolved_realm = resolve_realm(env_type)
    return f"{base_without_realm}/realms/{resolved_realm}".rstrip("/")


class KeycloakMiddleware(BaseHTTPMiddleware):
    """
    Middleware авторизации для доступа к API по Bearer token из Keycloak.

    Что делает middleware:
    - пропускает запросы на пути из ``exempt_paths`` без проверки токена;
    - читает ``Authorization: Bearer <token>``;
    - валидирует JWT через JWKS (подпись, issuer, audience и role);
    - при успехе сохраняет payload в ``request.state.keycloak_jwt``;
    - при ошибке выбрасывает ``TPException``-наследника (``Keycloak*``);
      чтобы получать единый формат ответа ``{"message","error","trace_id"}``,
      подключайте ``TpMiddleware`` внешним middleware.

    Формат ``exempt_paths``:
    - ``"/path"``: исключает ``/path`` и все вложенные (``/path/...``);
    - ``"/status/*"``: исключает префикс (``/status`` и ``/status/...``);
    - ``"/prefix*"``: raw-prefix сопоставление;
    - ``"/"``: исключает только корневой путь.

    Параметры:
    - ``keycloak_url``: URL Keycloak. Поддерживает формат
      ``https://client_id:client_secret@keycloak.host[/realms/<realm>]``;
    - ``env_type``: окружение для автоопределения realm и ``iss``:
      LOCAL/DEV -> dev, STAGING -> staging, PROD -> prod;
    - ``service_name`` берётся из ``client_id`` внутри ``keycloak_url`` и используется
      для проверки ``aud`` и ``resource_access``;
    - ``required_role``: обязательная роль в ``resource_access[service_name].roles``;
    - ``exempt_paths``: пути без авторизации.
    - ``accept_any_realm_on_domain``: если True — принимает токены из любого realm
      на домене, заданном в ``keycloak_url``. Realm берётся из ``payload["iss"]``.

    Пример::

        app.add_middleware(
            KeycloakMiddleware,
            keycloak_url=settings.keycloak_url,
            env_type=settings.ENV_TYPE,
            required_role="access",
            exempt_paths=("/health", "/docs", "/openapi.json", "/redoc", "/status/*"),
        )
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        keycloak_url: str,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        required_role: str = "access",
        exempt_paths: Sequence[str] = (),
        accept_any_realm_on_domain: bool = False,
    ) -> None:
        super().__init__(app)
        try:
            keycloak_base_url, keycloak_client_id, keycloak_client_secret = (
                parse_url_with_auth(keycloak_url)
            )
        except Exception as exc:  # noqa: BLE001
            raise KeycloakInvalidConfiguration("Invalid keycloak_url") from exc
        self._keycloak_url = keycloak_base_url
        self._keycloak_client_id = keycloak_client_id or None
        self._keycloak_client_secret = keycloak_client_secret or None
        self._accept_any_realm_on_domain = accept_any_realm_on_domain
        self._keycloak_issuer = _build_keycloak_issuer(keycloak_base_url, env_type)
        self._allowed_iss_prefix = (
            f"{_strip_realm_from_url(keycloak_base_url).rstrip('/')}/realms/"
        )
        self._jwk_clients_by_issuer: dict[str, PyJWKClient] = {}
        self._jwk_clients_lock = threading.Lock()
        self._keycloak_client = _get_jwk_client_for_issuer(
            jwk_clients_by_issuer=self._jwk_clients_by_issuer,
            jwk_clients_lock=self._jwk_clients_lock,
            issuer=self._keycloak_issuer,
        )

        resolved_service_name = (keycloak_client_id or "").strip()
        if not resolved_service_name:
            raise KeycloakInvalidConfiguration(
                "keycloak_url must include client_id (service name), "
                "e.g. https://client_id:client_secret@keycloak.host"
            )
        self._service_name = resolved_service_name
        self._required_role = required_role
        self._exempt_patterns = tuple(exempt_paths)

    def _is_exempt(self, path: str) -> bool:
        for pattern in self._exempt_patterns:
            if pattern.endswith("/*"):
                prefix = pattern[:-2].rstrip("/") or "/"
                if path == prefix or path.startswith(f"{prefix}/"):
                    return True
                continue
            if pattern.endswith("*"):
                if path.startswith(pattern[:-1]):
                    return True
                continue
            if pattern == "/":
                if path == "/":
                    return True
                continue
            base = pattern.rstrip("/") or "/"
            if path == base or path.startswith(f"{base}/"):
                return True
        return False

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        if self._is_exempt(request.url.path):
            return await call_next(request)

        authorization = request.headers.get("authorization")
        if not authorization:
            raise KeycloakMissingAuthorizationHeader()

        parts = authorization.split(" ", 1)
        if len(parts) != 2 or parts[0].lower() != "bearer":
            raise KeycloakInvalidAuthorizationHeader()

        token = parts[1]

        if self._accept_any_realm_on_domain:
            issuer = _resolve_issuer_for_any_realm(
                allowed_iss_prefix=self._allowed_iss_prefix,
                token=token,
            )
            jwk_client = _get_jwk_client_for_issuer(
                jwk_clients_by_issuer=self._jwk_clients_by_issuer,
                jwk_clients_lock=self._jwk_clients_lock,
                issuer=issuer,
            )
            payload = await asyncio.to_thread(
                _decode_keycloak_access_token,
                jwk_client,
                issuer,
                self._service_name,
                self._required_role,
                token,
            )
        else:
            payload = await asyncio.to_thread(
                _decode_keycloak_access_token,
                self._keycloak_client,
                self._keycloak_issuer,
                self._service_name,
                self._required_role,
                token,
            )

        request.state.keycloak_jwt = payload
        return await call_next(request)
