from __future__ import annotations

import base64
import json
import time
from dataclasses import dataclass
from typing import Any

import aiohttp

from tp_common.base_client.client import BaseClient
from tp_common.base_client.exceptions import ClientResponseErrorException
from tp_common.keycloak.exceptions import (
    KeycloakInvalidConfiguration,
    KeycloakTokenMissingAccessToken,
    KeycloakTokenResponseInvalid,
)
from tp_common.keycloak.utils import resolve_realm
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger
from tp_common.utils import parse_url_with_auth


@dataclass(frozen=True)
class KeycloakTokenResult:
    access_token: str
    expires_at: int | None = None  # unix seconds


def _basic_auth_header(client_id: str, client_secret: str) -> str:
    raw = f"{client_id}:{client_secret}".encode()
    return "Basic " + base64.b64encode(raw).decode("ascii")


def _clean_json_prefix(text: str) -> str:
    """
    Keycloak/openssl иногда печатает мусор вроде "GOST engine..." перед JSON.
    Берём всё, начиная с первого '{'.
    """
    idx = text.find("{")
    return text[idx:] if idx >= 0 else text


def _parse_json_loose(text: str) -> dict[str, Any]:
    cleaned = _clean_json_prefix(text).strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise KeycloakTokenResponseInvalid(
            "Keycloak response is not valid JSON"
        ) from exc
    if not isinstance(data, dict):
        raise KeycloakTokenResponseInvalid("Keycloak response is not a JSON object")
    return data


def _decode_jwt_exp_unverified(token: str) -> int | None:
    """
    Достаёт exp из JWT без проверки подписи.
    Нужен только для локального кеша/обновления.
    """
    try:
        _, payload_b64, _ = token.split(".", 2)
    except ValueError:
        return None
    padded = payload_b64 + "=" * (-len(payload_b64) % 4)
    try:
        payload = json.loads(base64.urlsafe_b64decode(padded))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(payload, dict):
        return None
    exp = payload.get("exp")
    return int(exp) if isinstance(exp, (int, float)) else None


def _looks_like_token_expired(data: dict[str, Any]) -> bool:
    # Keycloak обычно возвращает: {"error":"invalid_token","error_description":"Token is not active"}
    # либо "Token expired", "Expired token", etc.
    err = str(data.get("error") or "").lower()
    desc = str(data.get("error_description") or data.get("errorMessage") or "").lower()
    return ("expired" in desc) or ("not active" in desc) or (err == "invalid_token")


class KeycloakClient(BaseClient):
    """
    HTTP клиент для получения access token из Keycloak:
    - client_credentials token
    - token exchange (audience)

    Поддерживает "мусор" перед JSON в ответе (например, "GOST engine...").
    """

    TOKEN_URI_TEMPLATE = "/realms/{realm}/protocol/openid-connect/token"

    def __init__(
        self,
        *,
        keycloak_url: str,
        logger: TpLogger,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        proxy: str | None = None,
        max_retries: int = 2,
    ) -> None:
        base_url, client_id, client_secret = parse_url_with_auth(keycloak_url)
        if not client_id or not client_secret:
            raise KeycloakInvalidConfiguration(
                "keycloak_url must include client_id and client_secret, "
                "e.g. https://client_id:client_secret@keycloak.host"
            )
        super().__init__(
            base_url=base_url,
            logger=logger,
            proxy=proxy,
            retry_on_proxy_error=True,
            max_retries=max_retries,
        )
        self._client_id = client_id
        self._client_secret = client_secret
        self._env_type = env_type
        self._cache: dict[tuple[str, str], KeycloakTokenResult] = {}

    async def get_client_credentials_token(
        self,
        *,
        min_ttl_s: int = 30,
    ) -> str:
        client_id = self._client_id
        client_secret = self._client_secret
        realm = resolve_realm(self._env_type)
        cache_key = (realm, client_id)
        cached = self._cache.get(cache_key)
        now = int(time.time())
        if cached and cached.expires_at and cached.expires_at > now + min_ttl_s:
            return cached.access_token

        uri = self.TOKEN_URI_TEMPLATE.format(realm=realm)
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": _basic_auth_header(client_id, client_secret),
        }
        form = aiohttp.FormData()
        form.add_field("grant_type", "client_credentials")

        resp = await self.post_response(uri, headers=headers, data=form)
        raw_text = resp.text()
        data = _parse_json_loose(raw_text)
        token = str(data.get("access_token") or "")
        if not token:
            raise KeycloakTokenMissingAccessToken(
                "Keycloak token response has no access_token"
            )

        exp = _decode_jwt_exp_unverified(token)
        self._cache[cache_key] = KeycloakTokenResult(access_token=token, expires_at=exp)
        return token

    async def exchange_token(
        self,
        *,
        subject_token: str,
        audience: str,
    ) -> str:
        client_id = self._client_id
        client_secret = self._client_secret
        realm = resolve_realm(self._env_type)
        uri = self.TOKEN_URI_TEMPLATE.format(realm=realm)
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": _basic_auth_header(client_id, client_secret),
        }
        form = aiohttp.FormData()
        form.add_field("grant_type", "urn:ietf:params:oauth:grant-type:token-exchange")
        form.add_field("subject_token", subject_token)
        form.add_field(
            "subject_token_type", "urn:ietf:params:oauth:token-type:access_token"
        )
        form.add_field("audience", audience)

        resp = await self.post_response(uri, headers=headers, data=form)
        raw_text = resp.text()
        data = _parse_json_loose(raw_text)
        token = str(data.get("access_token") or "")
        if not token:
            raise KeycloakTokenMissingAccessToken(
                "Keycloak exchange response has no access_token"
            )
        return token

    async def get_service_token_via_exchange(
        self,
        *,
        audience: str,
    ) -> str:
        """
        Аналог твоего bash:
        1) client_credentials -> BASE_TOKEN
        2) token-exchange -> FINAL_TOKEN
        Если exchange возвращает, что subject_token просрочен — повторяем BASE_TOKEN и exchange ещё раз.
        """
        base_token = await self.get_client_credentials_token()

        try:
            return await self.exchange_token(
                subject_token=base_token,
                audience=audience,
            )
        except ClientResponseErrorException as exc:
            body = exc.response_body or ""
            try:
                err_json = _parse_json_loose(body) if body else {}
            except Exception:  # noqa: BLE001
                err_json = {}
            if not err_json or not _looks_like_token_expired(err_json):
                raise

        # Второй шанс: новый base_token и повтор exchange
        base_token = await self.get_client_credentials_token(
            min_ttl_s=0,
        )
        return await self.exchange_token(
            subject_token=base_token,
            audience=audience,
        )
