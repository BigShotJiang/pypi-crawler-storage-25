# Пример: KeycloakMiddleware в FastAPI

Минимальный пример приложения FastAPI с `KeycloakMiddleware` (проверка Bearer JWT через JWKS) и `TpMiddleware` (trace_id + единый формат ошибок).

## Что показывает

- Подключение `KeycloakMiddleware` через `app.add_middleware(...)`.
- Формат `KEYCLOAK_URL`: `https://client_id:client_secret@keycloak.host[/realms/<realm>]`.
  - `client_id` используется как `service_name` для проверки `aud` и `resource_access`.
- Режим `accept_any_realm_on_domain=True`: принимать токены из **любого realm** на **одном домене** (домен берётся из `KEYCLOAK_URL`).
- `exempt_paths`: пути без авторизации (`/health`, `/docs`, `/openapi.json`, `/redoc`).
- Доступ к payload в `request.state.keycloak_jwt`.

## Запуск

```bash
set KEYCLOAK_URL=https://client_id:client_secret@keycloak.8525.ru
set ENV_TYPE=DEV
set ACCEPT_ANY_REALM_ON_DOMAIN=1

uvicorn tp_common.keycloak.examples.middleware.app:app --reload --port 8000
```

## Проверка

```bash
curl -i http://127.0.0.1:8000/health
curl -i -H "Authorization: Bearer <token>" http://127.0.0.1:8000/me
```

