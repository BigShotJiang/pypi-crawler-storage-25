"""Интеграция с Keycloak (JWKS, middleware для FastAPI)."""

from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.exceptions import (
    KeycloakException,
    KeycloakInvalidAudience,
    KeycloakInvalidAuthorizationHeader,
    KeycloakInvalidConfiguration,
    KeycloakInvalidIssuer,
    KeycloakInvalidToken,
    KeycloakMissingAuthorizationHeader,
    KeycloakMissingRequiredRole,
    KeycloakTokenExpired,
)
from tp_common.keycloak.middleware import KeycloakMiddleware

__all__ = [
    "KeycloakMiddleware",
    "KeycloakClient",
    "KeycloakException",
    "KeycloakInvalidConfiguration",
    "KeycloakMissingAuthorizationHeader",
    "KeycloakInvalidAuthorizationHeader",
    "KeycloakTokenExpired",
    "KeycloakInvalidIssuer",
    "KeycloakInvalidToken",
    "KeycloakInvalidAudience",
    "KeycloakMissingRequiredRole",
]
