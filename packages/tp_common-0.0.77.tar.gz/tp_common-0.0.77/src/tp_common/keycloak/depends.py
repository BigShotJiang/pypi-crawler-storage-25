from __future__ import annotations

from fastapi import Depends, Request


def get_keycloak_payload(request: Request) -> dict[str, object]:
    """
    Возвращает payload JWT, сохранённый `KeycloakMiddleware` в `request.state.keycloak_jwt`.
    """
    payload = getattr(request.state, "keycloak_jwt", None)
    return payload if isinstance(payload, dict) else {}


def get_keycloak_service_id(
    payload: dict[str, object] = Depends(get_keycloak_payload),
) -> str:
    """
    Keycloak client_id вызывающей стороны обычно лежит в claim `azp`.
    """
    azp = payload.get("azp")
    return str(azp) if azp is not None else ""
