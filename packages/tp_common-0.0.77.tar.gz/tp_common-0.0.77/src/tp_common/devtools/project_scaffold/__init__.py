"""
Обновление конфигурации проекта из шаблона (tp-bootstrap).

Дерево файлов и исходный ``pyproject.toml`` загружаются из репозитория шаблона
(см. ``constants.BASE_URL``); встроенного заготовочного pyproject нет.

Код разбит по модулям в этой же папке:

- ``constants`` — URL/репозиторий шаблона и UPDATE_PRESERVE
- ``remote_template`` — GitLab API и HTTP-загрузка файлов
- ``template_sync`` — копирование шаблона в проект
- ``poetry_ops`` — poetry lock/install, pre-commit
- ``git_ops`` — git init
- ``pyproject_sync`` — правки pyproject.toml
- ``commands`` — update
- ``cli`` — argparse и ``main``

Сценарии:

1) Обновление из шаблона: ``tp-bootstrap update [-f]``.

2) После установки пакета: ``poetry run tp-bootstrap`` (без аргументов — update в текущей папке).

3) Через модуль: ``python -m tp_common.devtools.project_scaffold``.

4) Инициализация нового проекта выполняется curl-скриптом:
   ``curl .../curl_bootstrap.py | python - init ИМЯ`` (см. README пакета).

При update без ``--force`` файлы из шаблона перезаписываются, кроме путей из
``UPDATE_PRESERVE`` (см. ``constants``). С ``--force`` перезаписывается всё.

Источник истины по зависимостям — ``pyproject.toml`` шаблона.
"""

from .cli import main

__all__ = ["main"]
