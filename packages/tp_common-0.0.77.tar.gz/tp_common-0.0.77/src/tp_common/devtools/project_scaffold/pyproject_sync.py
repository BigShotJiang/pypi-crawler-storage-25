"""Правки pyproject.toml: package-mode, основные и dev-зависимости."""

from __future__ import annotations

import re
from pathlib import Path

from .remote_template import http_get_root

# Источник истины по зависимостям — шаблонный pyproject.toml.
# Старые функции sync_* оставлены для совместимости (no-op по умолчанию).
REQUIRED_DEV_DEPS: dict[str, str] = {}
REQUIRED_MAIN_DEPS: dict[str, str] = {}


def find_section(lines: list[str], header: str) -> int | None:
    for i, line in enumerate(lines):
        if line.strip() == header:
            return i
    return None


def section_range(lines: list[str], start: int) -> tuple[int, int]:
    end = start + 1
    for i in range(end, len(lines)):
        if lines[i].strip().startswith("[") and not lines[i].strip().startswith("#["):
            return end, i
    return end, len(lines)


def set_pyproject_distribution_name(target_root: Path, distribution_name: str) -> None:
    """Поля ``name`` в ``[tool.poetry]`` и ``[project]`` (если есть) приводят к имени проекта."""
    path = target_root / "pyproject.toml"
    if not path.is_file():
        return
    lines = path.read_text(encoding="utf-8").splitlines()
    for header in ("[tool.poetry]", "[project]"):
        idx = find_section(lines, header)
        if idx is None:
            continue
        start, end = section_range(lines, idx)
        for i in range(start, end):
            line = lines[i]
            if not re.match(r"^\s*name\s*=", line):
                continue
            indent_m = re.match(r"^(\s*)", line)
            indent = indent_m.group(1) if indent_m else ""
            lines[i] = f'{indent}name = "{distribution_name}"'
            break
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def ensure_package_mode_false(target_root: Path) -> None:
    """package-mode = false в [tool.poetry]."""
    pyproject = target_root / "pyproject.toml"
    if not pyproject.is_file():
        return
    lines = pyproject.read_text(encoding="utf-8").splitlines()
    header = "[tool.poetry]"
    new_line = "package-mode = false"
    idx = None
    for i, line in enumerate(lines):
        if line.strip() == header:
            idx = i
            break
    if idx is None:
        return
    start = idx + 1
    has_package_mode = False
    package_mode_line_idx = None
    for i in range(start, len(lines)):
        stripped = lines[i].strip()
        if stripped.startswith("[") and not stripped.startswith("#["):
            break
        if stripped.startswith("package-mode"):
            has_package_mode = True
            package_mode_line_idx = i
    if has_package_mode and package_mode_line_idx is not None:
        if "false" in lines[package_mode_line_idx].lower():
            return
        lines[package_mode_line_idx] = new_line
    else:
        lines.insert(idx + 1, new_line)
    pyproject.write_text("\n".join(lines) + "\n", encoding="utf-8")


def sync_dev_deps(target_root: Path) -> None:
    """Выравнивает dev-зависимости: ключи из REQUIRED_DEV_DEPS — из constants.

    Пакеты из шаблона, не входящие в REQUIRED_DEV_DEPS, не меняются. Дополнительно,
    если в pyproject шаблона есть ``pylint``, его строка может быть перенесена
    в целевой проект (не входит в REQUIRED_DEV_DEPS).
    """
    target_pyproject = target_root / "pyproject.toml"
    if not target_pyproject.is_file():
        return

    section = "[tool.poetry.group.dev.dependencies]"
    optional_keys = ("pylint",)
    required_keys = tuple(REQUIRED_DEV_DEPS.keys())

    source_deps: dict[str, str] = {}
    try:
        src_text = http_get_root("pyproject.toml")
        src_lines = src_text.splitlines()
        src_idx = find_section(src_lines, section)
        if src_idx is not None:
            src_start, src_end = section_range(src_lines, src_idx)
            for line in src_lines[src_start:src_end]:
                s = line.strip()
                if not s or s.startswith("#"):
                    continue
                for key in required_keys + optional_keys:
                    if s.startswith(f"{key} ") or s.startswith(f"{key}="):
                        source_deps[key] = line
                        break
    except RuntimeError:
        pass

    merged: dict[str, str] = {}
    for k in required_keys:
        merged[k] = REQUIRED_DEV_DEPS[k]
    for k in optional_keys:
        if k in source_deps:
            merged[k] = source_deps[k]

    tgt_lines = target_pyproject.read_text(encoding="utf-8").splitlines()
    tgt_idx = find_section(tgt_lines, section)
    if tgt_idx is None:
        if tgt_lines and tgt_lines[-1].strip():
            tgt_lines.append("")
        tgt_lines.append(section)
        for k in required_keys + optional_keys:
            if k in merged:
                tgt_lines.append(merged[k])
        target_pyproject.write_text("\n".join(tgt_lines) + "\n", encoding="utf-8")
        return

    tgt_start, tgt_end = section_range(tgt_lines, tgt_idx)
    for key in required_keys + optional_keys:
        _l = merged.get(key)
        if _l is None:
            continue
        line = _l

        found = False
        for i in range(tgt_start, tgt_end):
            if tgt_lines[i].strip().startswith(f"{key} ") or tgt_lines[
                i
            ].strip().startswith(f"{key}="):
                tgt_lines[i] = line
                found = True
                break
        if not found:
            tgt_lines.insert(tgt_end, line)
            tgt_end += 1

    target_pyproject.write_text("\n".join(tgt_lines) + "\n", encoding="utf-8")


def sync_main_deps(target_root: Path) -> None:
    """Выравнивает строки для ключей из REQUIRED_MAIN_DEPS в [tool.poetry.dependencies].

    ``python``, ``tp-common`` и прочие пакеты из шаблона не трогаются.
    """
    target_pyproject = target_root / "pyproject.toml"
    if not target_pyproject.is_file():
        return

    section = "[tool.poetry.dependencies]"
    required_keys = tuple(REQUIRED_MAIN_DEPS.keys())

    tgt_lines = target_pyproject.read_text(encoding="utf-8").splitlines()
    tgt_idx = find_section(tgt_lines, section)
    if tgt_idx is None:
        if tgt_lines and tgt_lines[-1].strip():
            tgt_lines.append("")
        tgt_lines.append(section)
        for key in required_keys:
            tgt_lines.append(REQUIRED_MAIN_DEPS[key])
        target_pyproject.write_text("\n".join(tgt_lines) + "\n", encoding="utf-8")
        return

    tgt_start, tgt_end = section_range(tgt_lines, tgt_idx)
    for key in required_keys:
        line = REQUIRED_MAIN_DEPS[key]
        found = False
        for i in range(tgt_start, tgt_end):
            if tgt_lines[i].strip().startswith(f"{key} ") or tgt_lines[
                i
            ].strip().startswith(f"{key}="):
                tgt_lines[i] = line
                found = True
                break
        if not found:
            tgt_lines.insert(tgt_end, line)
            tgt_end += 1

    target_pyproject.write_text("\n".join(tgt_lines) + "\n", encoding="utf-8")
