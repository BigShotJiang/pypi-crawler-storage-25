"""Константы репозитория-шаблона.

Два слоя:

1. **Шаблон** (``BASE_URL``) — всегда подтягиваются файлы и базовый ``pyproject.toml``:
   структура проекта, конфиги, ``python`` / ``tp-common`` и любые другие пакеты,
   которых нет в списках ниже.

2. Источник истины по зависимостям — ``pyproject.toml`` шаблона.
"""

# Корень raw-URL репозитория полного шаблона сервиса (см. devtools/bsp-template)
BASE_URL = "https://gitlab.8525.ru/devtools/bsp-template/-/raw/main/"
# Репозиторий шаблона для операций через git clone (использует git-авторизацию).
TEMPLATE_REPO_URL = "https://gitlab.8525.ru/devtools/bsp-template.git"
TEMPLATE_REF = "main"
# Подкаталог внутри репозитория; пусто — весь репозиторий с корня
TEMPLATE_REL = ""

# При обнаружении по API: источник -> назначение
TEMPLATE_RENAME: dict[str, str] = {}
# Не копировать из шаблона
TEMPLATE_SKIP: frozenset[str] = frozenset()
# Префиксы путей, которые не копировать (кэш, git-метаданные и т.п.)
TEMPLATE_SKIP_PREFIXES: tuple[str, ...] = (
    ".ruff_cache/",
    ".ruff_cache\\",
    ".git/",
    ".git\\",
)

# При update без --force файлы из этого списка не перезаписываются.
# `pyproject.toml` сохраняем и мерджим зависимости отдельно (см. pyproject_merge).
UPDATE_PRESERVE: frozenset[str] = frozenset({"src/config.py", "pyproject.toml"})

POETRY_NOT_FOUND_MSG = (
    "Poetry не найден. Установите: https://python-poetry.org/docs/#installation "
    "и добавьте poetry в PATH, либо запускайте скрипт тем интерпретатором Python, "
    "в окружении которого установлен poetry (не из виртуального окружения проекта)."
)
