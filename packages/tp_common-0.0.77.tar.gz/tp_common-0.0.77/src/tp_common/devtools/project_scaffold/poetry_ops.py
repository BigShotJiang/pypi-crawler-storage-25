"""Запуск Poetry и pre-commit."""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

from .constants import POETRY_NOT_FOUND_MSG


def poetry_cmd_base() -> list[str]:
    """Команда для poetry: из PATH или python -m poetry."""
    if shutil.which("poetry") is not None:
        return ["poetry"]
    return [sys.executable, "-m", "poetry"]


def run_poetry(cwd: Path, *args: str) -> None:
    """Запускает poetry в cwd."""
    base = poetry_cmd_base()
    cmd = [*base, *args]
    use_capture = base[0] != "poetry"
    result = subprocess.run(
        cmd,
        cwd=cwd,
        shell=False,
        capture_output=use_capture,
        text=use_capture,
        check=False,
    )
    if result.returncode == 0:
        return
    if use_capture and result.stderr and "No module named poetry" in result.stderr:
        raise RuntimeError(POETRY_NOT_FOUND_MSG)
    raise RuntimeError(f"poetry завершился с кодом {result.returncode}")


def ensure_poetry_venv_in_project(target_root: Path) -> None:
    """Poetry: venv в проекте (.venv), если его ещё нет."""
    venv_dir = target_root / ".venv"
    if venv_dir.is_dir():
        return
    run_poetry(target_root, "config", "virtualenvs.in-project", "true", "--local")


def run_precommit_install(cwd: Path) -> None:
    """Устанавливает pre-commit и pre-push hooks."""
    base = poetry_cmd_base()
    cmd = [
        *base,
        "run",
        "pre-commit",
        "install",
        "--hook-type",
        "pre-commit",
        "--hook-type",
        "pre-push",
    ]
    use_capture = base[0] != "poetry"
    result = subprocess.run(
        cmd,
        cwd=cwd,
        shell=False,
        capture_output=use_capture,
        text=use_capture,
        check=False,
    )
    if result.returncode == 0:
        return
    if use_capture and result.stderr and "No module named poetry" in result.stderr:
        raise RuntimeError(POETRY_NOT_FOUND_MSG)
    print(
        "[tp-bootstrap] Предупреждение: установка pre-commit/pre-push hooks не выполнена (например, нет git-репозитория)."
    )
    print(
        "[tp-bootstrap] Выполните вручную: poetry run pre-commit install "
        "--hook-type pre-commit --hook-type pre-push"
    )
