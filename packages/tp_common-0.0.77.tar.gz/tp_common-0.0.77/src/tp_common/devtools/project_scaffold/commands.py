"""Команда update."""

from __future__ import annotations

from pathlib import Path

from .poetry_ops import ensure_poetry_venv_in_project, run_poetry, run_precommit_install
from .pyproject_merge import merge_dependencies_from_template
from .pyproject_sync import set_pyproject_distribution_name
from .template_sync import apply_template_update


def cmd_update(target_root: Path, force: bool) -> None:
    """Обновляет конфигурацию из шаблона."""
    target_root = target_root.resolve()
    if not target_root.is_dir():
        raise NotADirectoryError(f"Не директория: {target_root}")

    apply_template_update(target_root, force)

    target_pyproject = target_root / "pyproject.toml"
    if target_pyproject.is_file():
        set_pyproject_distribution_name(target_root, target_root.name)
        if not force:
            merge_dependencies_from_template(target_root)

    # Источник истины по зависимостям — шаблон. После обновления шаблона
    # подтягиваем зависимости через poetry.
    ensure_poetry_venv_in_project(target_root)
    print("[tp-bootstrap] Выполнение poetry lock.")
    run_poetry(target_root, "lock", "--no-interaction")
    print("[tp-bootstrap] Выполнение poetry install.")
    run_poetry(target_root, "install", "--no-interaction")
    print("[tp-bootstrap] Установка pre-commit/pre-push hooks.")
    run_precommit_install(target_root)

    print("[tp-bootstrap] Готово. Конфигурация обновлена.")
