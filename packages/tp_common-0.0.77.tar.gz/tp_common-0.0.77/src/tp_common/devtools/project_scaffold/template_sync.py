"""Копирование файлов шаблона в целевой проект (через git clone)."""

from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

from .constants import (
    TEMPLATE_REF,
    TEMPLATE_REL,
    TEMPLATE_RENAME,
    TEMPLATE_REPO_URL,
    TEMPLATE_SKIP,
    TEMPLATE_SKIP_PREFIXES,
    UPDATE_PRESERVE,
)


def _template_subdir() -> str:
    return TEMPLATE_REL.strip().strip("/")


def _clone_template_repo() -> Path:
    tmp_dir = Path(tempfile.mkdtemp(prefix="tp-bootstrap-template-")).resolve()
    cmd = [
        "git",
        "clone",
        "--depth",
        "1",
        "--branch",
        TEMPLATE_REF,
        TEMPLATE_REPO_URL,
        str(tmp_dir),
    ]
    subprocess.check_call(cmd)
    return tmp_dir


def _iter_template_files(template_root: Path) -> list[tuple[str, str]]:
    sub = _template_subdir()
    root = (template_root / sub) if sub else template_root
    result: list[tuple[str, str]] = []
    for src in root.rglob("*"):
        if src.is_dir():
            continue
        rel = src.relative_to(root).as_posix()
        if not rel or rel in TEMPLATE_SKIP:
            continue
        if any(rel.startswith(p.replace("\\", "/")) for p in TEMPLATE_SKIP_PREFIXES):
            continue
        dest_rel = TEMPLATE_RENAME.get(rel, rel)
        result.append((rel, dest_rel if dest_rel is not None else rel))
    return sorted(result, key=lambda x: x[1])


def _write_template_files(target_root: Path, *, force: bool, intro: str) -> None:
    print(f"[tp-bootstrap] {intro}")
    template_root = _clone_template_repo()
    try:
        template_files = _iter_template_files(template_root)
        sub = _template_subdir()
        root = (template_root / sub) if sub else template_root
        for src_rel, dest_rel in template_files:
            dest = target_root / dest_rel
            if not force and dest_rel in UPDATE_PRESERVE and dest.is_file():
                print(
                    f"[tp-bootstrap] Пропуск {dest_rel} "
                    "(файл в списке сохраняемых, оставлен без изменений; "
                    "используйте --force для перезаписи)"
                )
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(root / src_rel, dest)
            print(f"[tp-bootstrap] Запись {dest_rel}")
        (target_root / "alembic" / "versions").mkdir(parents=True, exist_ok=True)
    finally:
        shutil.rmtree(template_root, ignore_errors=True)


def copy_template_to_target(target_root: Path, *, force: bool = False) -> None:
    """Копирует файлы шаблона; пути из UPDATE_PRESERVE не трогает при force=False."""
    _write_template_files(target_root, force=force, intro="Загрузка файлов шаблона.")


def apply_template_update(target_root: Path, force: bool) -> None:
    """Применяет шаблон при update (то же правило UPDATE_PRESERVE)."""
    _write_template_files(target_root, force=force, intro="Обновление из шаблона.")


def read_template_file_text(relative_path: str) -> str:
    """Читает файл из шаблона (через git clone)."""
    template_root = _clone_template_repo()
    try:
        sub = _template_subdir()
        root = (template_root / sub) if sub else template_root
        path = (root / relative_path).resolve()
        if not path.is_file():
            return ""
        return path.read_text(encoding="utf-8")
    finally:
        shutil.rmtree(template_root, ignore_errors=True)
