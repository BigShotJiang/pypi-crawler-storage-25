"""
Интеграция TpLogger с FastAPI: dependency для логгера на запрос.

Middleware ``TpMiddleware`` (trace_id, access-лог, перехват исключений) подключайте из
``tp_common.tp_fastapi.middleware``.

Использование:
    1. При старте приложения сохраните фабрику в app.state и настройте стандартные логгеры:
        app.state.log_factory = TpLoggerFactory(EnvironmentType.DEV)
        TpLoggerFactory.setup_standard_loggers(EnvironmentType.DEV)

    2. Подключите middleware (trace_id, лог каждого HTTP-запроса, перехват исключений):
        from tp_common.tp_fastapi.middleware import TpMiddleware
        app.add_middleware(TpMiddleware)

    3. В эндпоинтах инжектируйте логгер (тип — TpLogger, переменную называйте logger):
        from fastapi import Depends
        from tp_common.tp_logger.fastapi_integration import get_request_logger
        from tp_common.tp_logger.tp_logging import TpLogger
        @app.get("/")
        def root(logger: TpLogger = Depends(get_request_logger)):
            logger.info("Обработка запроса")
"""

from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import Depends, Request
from starlette.responses import JSONResponse

from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory, generate_trace_id


def _get_trace_id_from_request(request: Request) -> uuid.UUID:
    """Достаёт trace_id из request.state (уже установлен middleware) или генерирует."""
    trace_id = getattr(request.state, "trace_id", None)
    if isinstance(trace_id, uuid.UUID):
        return trace_id
    return generate_trace_id()


def get_request_logger(request: Request) -> TpLogger:
    """
    Dependency: возвращает TpLogger с trace_id текущего запроса.
    Фабрика должна быть в request.app.state.log_factory (TpLoggerFactory).
    """
    factory: TpLoggerFactory | None = getattr(request.app.state, "log_factory", None)
    if factory is None:
        raise RuntimeError(
            "TpLoggerFactory not set on app.state.log_factory. "
            "Set it on startup, e.g. app.state.log_factory = TpLoggerFactory(env)."
        )
    trace_id = _get_trace_id_from_request(request)
    # Кэшируем логгер на запрос, чтобы не создавать новый при каждом вызове dependency
    logger = getattr(request.state, "_tp_logger", None)
    if logger is None:
        logger = factory.get_logger("api", trace_id=trace_id)
        request.state._tp_logger = logger
    return logger


# Для аннотации используйте: logger: TpLogger = Depends(get_request_logger)
# (Annotated-алиас может вызывать предупреждения типа "invalid type" в части IDE/checker.)
RequestLogger = Annotated[
    TpLogger, Depends(get_request_logger)
]  # опциональный короткий вариант


async def tp_logger_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """
    Обработчик исключений для add_exception_handler.
    Для необработанных 500 не вызывается — их перехватывает ServerErrorMiddleware.
    Используйте TpMiddleware — он перехватывает исключения и логирует с trace_id.
    """
    try:
        logger = get_request_logger(request)
        logger.exception("Необработанное исключение: %s", exc)
    except Exception:  # noqa: BLE001
        pass
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal Server Error"},
    )
