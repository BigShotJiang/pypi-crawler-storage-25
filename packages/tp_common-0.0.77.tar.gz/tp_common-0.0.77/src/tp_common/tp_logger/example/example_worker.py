"""
Пример: воркер с 10 потоками и логированием через TpLoggerFactory / TpLogger.

Показывает:
- как создать фабрику логгеров и получить логгер с thread_name для каждого потока;
- как генерируются JSON-сообщения (поля timestamp, level, msg, env, thread_name);
- при случайной ошибке — поля error, error_message, last_tb_line, stack_trace в JSON (формат удобен для Loki: одна строка на запись).

Воркер работает в вечном цикле; с вероятностью ERROR_CHANCE поток имитирует ошибку
и пишет её в лог (logger.exception), затем продолжает работу. Остановка: Ctrl+C.

Запуск из корня репозитория (установите зависимости: pip install -e . или uv sync):
    python -m tp_common.tp_logger.example.example_worker
"""

from __future__ import annotations

import random
import threading
import time

from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory

# Один раз на процесс — фабрика логгеров с окружением
LOG_FACTORY = TpLoggerFactory(EnvironmentType.DEV)

NUM_WORKER_THREADS = 10
WORK_DURATION_SEC = 2
ERROR_CHANCE = 0.15  # вероятность "ошибки" за итерацию (15%)


def worker_task(worker_id: int) -> None:
    """Вечный цикл: в начале каждой итерации задаётся новый trace_id через new_trace_id() (логгер один)."""
    logger = LOG_FACTORY.get_logger("worker", thread_name=f"w{worker_id+1}")
    logger.info("Поток запущен")

    while True:
        logger.new_trace_id()  # новый trace_id на каждую итерацию (задачу)
        try:
            logger.debug("Начало итерации")
            time.sleep(WORK_DURATION_SEC)
            logger.debug("Шаг выполнен")
            if random.random() < ERROR_CHANCE:
                raise ValueError(f"Случайная ошибка в worker_{worker_id}")
        except ValueError as e:
            logger.exception("Поймана ошибка в цикле: %s", e)


def main() -> None:
    main_logger = LOG_FACTORY.get_logger("main")
    main_logger.info(
        "Запуск воркера с %s потоками (вечный цикл, Ctrl+C — выход)", NUM_WORKER_THREADS
    )

    threads = [
        threading.Thread(target=worker_task, args=(i,), name=f"Worker-{i}", daemon=True)
        for i in range(NUM_WORKER_THREADS)
    ]
    for t in threads:
        t.start()
    try:
        for t in threads:
            t.join()
    except KeyboardInterrupt:
        main_logger.info("Остановка по Ctrl+C")


if __name__ == "__main__":
    main()
