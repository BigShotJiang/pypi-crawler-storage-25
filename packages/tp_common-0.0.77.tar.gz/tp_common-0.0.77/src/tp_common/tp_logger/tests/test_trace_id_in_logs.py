"""
Тесты для проверки, что в логах FastAPI в любой ситуации присутствует trace_id.

Проверяем:
- логгер из get_request_logger (как в эндпоинтах) всегда пишет trace_id в запись;
- info / error / exception — во всех случаях trace_id попадает в лог;
- логгер из фабрики с trace_id (как при инициализации по request) передаёт trace_id во все записи.
"""

import logging
import uuid
from types import SimpleNamespace

import pytest
from starlette.requests import Request

from tp_common.tp_logger.fastapi_integration import get_request_logger
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory


class _CaptureHandler(logging.Handler):
    """Хранит последнюю запись для проверки полей."""

    def __init__(self) -> None:
        super().__init__()
        self.record: logging.LogRecord | None = None

    def emit(self, record: logging.LogRecord) -> None:
        self.record = record


def _assert_trace_id_in_record(handler: _CaptureHandler, expected: uuid.UUID) -> None:
    assert handler.record is not None
    assert getattr(handler.record, "trace_id", None) == str(expected)


# --- FastAPI: логгер запроса (get_request_logger) всегда с trace_id ---


@pytest.fixture
def fastapi_request_with_trace_id() -> Request:
    """Минимальный Request с app.state.log_factory и request.state.trace_id (как после TraceIdMiddleware)."""
    factory = TpLoggerFactory(EnvironmentType.LOCAL)
    app = SimpleNamespace(state=SimpleNamespace(log_factory=factory))
    scope = {"type": "http", "method": "GET", "path": "/", "app": app}
    request = Request(scope)
    request.state.trace_id = uuid.UUID("00000000-0000-0000-0000-000000000042")
    return request


def test_fastapi_request_logger_info_has_trace_id(
    fastapi_request_with_trace_id: Request,
) -> None:
    """В FastAPI при logger.info() из Depends(get_request_logger) в логе есть trace_id."""
    logger = get_request_logger(fastapi_request_with_trace_id)
    handler = _CaptureHandler()
    logger.logger.handlers = [handler]
    logger.logger.propagate = False

    logger.info("Запрос обработан")
    _assert_trace_id_in_record(
        handler, uuid.UUID("00000000-0000-0000-0000-000000000042")
    )


def test_fastapi_request_logger_error_has_trace_id(
    fastapi_request_with_trace_id: Request,
) -> None:
    """В FastAPI при logger.error() (в т.ч. в except) в логе есть trace_id."""
    logger = get_request_logger(fastapi_request_with_trace_id)
    handler = _CaptureHandler()
    logger.logger.handlers = [handler]
    logger.logger.propagate = False

    logger.error("Ошибка обработки запроса")
    _assert_trace_id_in_record(
        handler, uuid.UUID("00000000-0000-0000-0000-000000000042")
    )


def test_fastapi_request_logger_exception_has_trace_id(
    fastapi_request_with_trace_id: Request,
) -> None:
    """В FastAPI при logger.exception() (перехват ошибки в эндпоинте или middleware) в логе есть trace_id."""
    logger = get_request_logger(fastapi_request_with_trace_id)
    handler = _CaptureHandler()
    logger.logger.handlers = [handler]
    logger.logger.propagate = False

    try:
        raise ValueError("Сбой при обработке")
    except ValueError:
        logger.exception("Необработанное исключение")
    _assert_trace_id_in_record(
        handler, uuid.UUID("00000000-0000-0000-0000-000000000042")
    )


def test_fastapi_request_logger_cached_has_trace_id(
    fastapi_request_with_trace_id: Request,
) -> None:
    """Повторный вызов get_request_logger для того же request возвращает логгер с тем же trace_id."""
    logger1 = get_request_logger(fastapi_request_with_trace_id)
    logger2 = get_request_logger(fastapi_request_with_trace_id)
    assert logger1 is logger2
    handler = _CaptureHandler()
    logger1.logger.handlers = [handler]
    logger1.logger.propagate = False

    logger1.exception("Ошибка после кэширования логгера")
    _assert_trace_id_in_record(
        handler, uuid.UUID("00000000-0000-0000-0000-000000000042")
    )


# --- Базовая гарантия: TpLogger с trace_id пишет его во все уровни ---


@pytest.fixture
def factory() -> TpLoggerFactory:
    return TpLoggerFactory(EnvironmentType.LOCAL)


@pytest.fixture
def capture_handler(factory: TpLoggerFactory) -> tuple[TpLogger, _CaptureHandler]:
    """Логгер с фиксированным trace_id и handler для перехвата записи."""
    handler = _CaptureHandler()
    logger_impl = logging.getLogger("test_trace_id_capture")
    logger_impl.handlers = [handler]
    logger_impl.setLevel(logging.DEBUG)
    logger_impl.propagate = False
    tp_logger = TpLogger(
        logger_impl,
        EnvironmentType.LOCAL,
        thread_name=None,
        initial_trace_id=uuid.UUID("00000000-0000-0000-0000-000000000123"),
    )
    return tp_logger, handler


def test_trace_id_in_info(capture_handler: tuple[TpLogger, _CaptureHandler]) -> None:
    """info() добавляет trace_id в запись."""
    logger, handler = capture_handler
    logger.info("test message")
    _assert_trace_id_in_record(
        handler, uuid.UUID("00000000-0000-0000-0000-000000000123")
    )


def test_trace_id_in_error(capture_handler: tuple[TpLogger, _CaptureHandler]) -> None:
    """error() добавляет trace_id в запись."""
    logger, handler = capture_handler
    logger.error("error message")
    _assert_trace_id_in_record(
        handler, uuid.UUID("00000000-0000-0000-0000-000000000123")
    )


def test_trace_id_in_exception(
    capture_handler: tuple[TpLogger, _CaptureHandler],
) -> None:
    """exception() добавляет trace_id в запись (критично для отслеживания ошибок по запросу)."""
    logger, handler = capture_handler
    try:
        raise ValueError("test")
    except ValueError:
        logger.exception("exception message")
    _assert_trace_id_in_record(
        handler, uuid.UUID("00000000-0000-0000-0000-000000000123")
    )


def test_trace_id_from_factory(factory: TpLoggerFactory) -> None:
    """Логгер из фабрики с trace_id (как при создании по request) передаёт trace_id во все записи."""
    handler = _CaptureHandler()
    trace_id = uuid.UUID("00000000-0000-0000-0000-000000000456")
    logger = factory.get_logger("test", trace_id=trace_id, use_queue=False)
    logger.logger.handlers = [handler]
    logger.logger.propagate = False

    logger.info("from factory")
    _assert_trace_id_in_record(handler, trace_id)

    logger.exception("error from factory")
    _assert_trace_id_in_record(handler, trace_id)
