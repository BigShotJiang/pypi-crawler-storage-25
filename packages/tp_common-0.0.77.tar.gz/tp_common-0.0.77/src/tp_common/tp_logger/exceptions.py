class TpLoggerConfigurationError(Exception):
    """
    Ошибка конфигурации TpLogger/TpLoggerFactory.

    Пример: попытка создать логгер без обязательного контекста идентификации
    (`name` и/или `thread_name` в зависимости от кейса).
    """


class TpLoggerMisconfiguredNameError(TpLoggerConfigurationError):
    """Выбрасывается, когда вызов TpLoggerFactory.get_logger без `name` и без `thread_name` невозможен."""

    def __init__(self) -> None:
        super().__init__(
            "TpLoggerFactory.get_logger: нельзя создать TpLogger без `name` и без `thread_name`."
        )
