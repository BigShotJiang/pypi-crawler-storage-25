"""
Централизованный модуль для получения логгеров в проекте.

Единая точка входа — TpLoggerFactory(env).get_logger(...) возвращает TpLogger.
Все настройки форматирования и обработки логов находятся здесь.
Очередь и поток для асинхронного логирования общие для всех экземпляров (синглтоны).

thread_name — метка контекста (воркер, поток-обработчик). Передаётся в get_logger(..., thread_name=...).
trace_id — идентификатор одной операции; задаётся в get_logger(..., trace_id=...) или
через set_trace_id()/new_trace_id() на экземпляре логгера. Попадает в поле "trace_id"
каждой записи для связки логов в агрегаторах (Loki, ELK).
"""

from __future__ import annotations

import atexit
import logging
import queue
import sys
import threading
import traceback
import uuid
from typing import Any

from pythonjsonlogger.json import JsonFormatter

from tp_common.tp_logger.exceptions import (
    TpLoggerMisconfiguredNameError,
)
from tp_common.tp_logger.schemas import EnvironmentType


def generate_trace_id() -> uuid.UUID:
    """Генерирует новый случайный trace_id (uuid4) для связки логов одной операции."""
    return uuid.uuid4()


# ============================================================================
# ЕДИНАЯ КОНФИГУРАЦИЯ ФОРМАТТЕРА
# ============================================================================
# Все изменения формата логов должны производиться здесь


class TpJsonFormatter(JsonFormatter):
    """
    JSON-форматтер: thread_name, trace_id, env и поля ошибки берутся из record (extra).
    Исключения форматируются здесь в error, error_message, stack_trace, last_tb_line.
    """

    def add_fields(
        self,
        log_data: dict[str, Any],
        record: logging.LogRecord,
        message_dict: dict[str, Any],
    ) -> None:
        # Сначала вычислить поля ошибки и очистить exc_info (чтобы parent не выводил сырой tuple)
        error_fields: dict[str, str] = {}
        if record.exc_info and record.exc_info[0] is not None:
            e_type, e, exc_tb = record.exc_info
            error_fields["error"] = e_type.__name__ if e_type else ""
            error_fields["error_message"] = str(e) if e else ""
            error_fields["stack_trace"] = "".join(
                traceback.format_exception(e_type, e, exc_tb)
            ).strip()
            if exc_tb:
                tb_list = traceback.extract_tb(exc_tb)
                if tb_list:
                    last = tb_list[-1]
                    error_fields["last_tb_line"] = (
                        f"{last.filename}:{last.lineno} — {last.name} → {last.line}"
                    )
            record.exc_info = None

        super().add_fields(log_data, record, message_dict)

        # Основные параметры после timestamp, level, msg
        tn = getattr(record, "thread_name", None)
        if tn is not None:
            log_data["thread_name"] = str(tn)
        tid = getattr(record, "trace_id", None)
        if tid is not None:
            log_data["trace_id"] = str(tid)
        env_val = getattr(record, "env", None)
        if env_val is not None:
            log_data["env"] = str(env_val)

        # Поля ошибки в конце
        for key in ("error", "error_message", "last_tb_line", "stack_trace"):
            if key in error_fields:
                log_data[key] = error_fields[key]
            elif key not in log_data:
                v = getattr(record, key, None)
                if v:
                    log_data[key] = str(v)


def _create_formatter(env: EnvironmentType) -> JsonFormatter:
    """
    Создаёт JSON-форматтер для логов.

    Поля thread_name и trace_id добавляются только когда переданы в get_logger(...).

    Args:
        env: Окружение (для статического поля в логах).

    Returns:
        Настроенный JSON форматтер.
    """
    static_fields: dict[Any, Any] = {"env": env.value}

    return TpJsonFormatter(
        "{asctime}{levelname}{message}{env}",
        style="{",
        json_ensure_ascii=False,
        rename_fields={
            "asctime": "timestamp",
            "levelname": "level",
            "message": "msg",
        },
        static_fields=static_fields,
    )


# ============================================================================
# АСИНХРОННАЯ ОБРАБОТКА ЛОГОВ
# ============================================================================


class QueueHandler(logging.Handler):
    """Handler that sends log records to a queue for async processing."""

    def __init__(self, log_queue: queue.Queue[logging.LogRecord | None]) -> None:
        super().__init__()
        self.queue = log_queue

    def emit(self, record: logging.LogRecord) -> None:
        """Put the record into the queue."""
        try:
            self.queue.put_nowait(record)
        except queue.Full:
            self.handleError(record)
        except Exception:
            self.handleError(record)


def _log_listener_thread(
    log_queue: queue.Queue[logging.LogRecord | None],
    env: EnvironmentType,
) -> None:
    """Поток для обработки логов из очереди."""

    formatter = _create_formatter(env)
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setFormatter(formatter)

    while True:
        try:
            record = log_queue.get()
            if record is None:  # Сигнал для завершения
                break
            stdout_handler.emit(record)
        except (KeyboardInterrupt, SystemExit):
            break
        except Exception:
            import traceback

            traceback.print_exc(file=sys.stderr)


# -----------------------------------------------------------------------------
# Кэш логгеров (избежание дублирования хендлеров)
# -----------------------------------------------------------------------------
# Ключ: (env.value, name, thread_name_key, use_queue). trace_id хранится в TpLogger.

_logger_cache: dict[tuple[str, str, str | None, bool], logging.Logger] = {}
_logger_cache_lock = threading.Lock()


# -----------------------------------------------------------------------------
# Общая очередь и поток (синглтоны)
# -----------------------------------------------------------------------------
# Все экземпляры TpLoggerFactory с use_queue=True используют одну очередь и один поток.
# Это стандартная практика для асинхронного логирования: один listener на всё
# приложение — меньше памяти и контекстных переключений, единый формат вывода.

_log_queue: queue.Queue[logging.LogRecord | None] | None = None
_log_thread: threading.Thread | None = None
_log_lock = threading.Lock()
_atexit_registered = False


def _shutdown_log_listener() -> None:
    """По завершении процесса отправляет сигнал остановки и ждёт поток — иначе логи из очереди не успевают вывестись."""
    global _log_queue, _log_thread
    if _log_queue is None or _log_thread is None or not _log_thread.is_alive():
        return
    try:
        _log_queue.put(None)
        _log_thread.join(timeout=5.0)
    except Exception:
        pass


def _get_log_queue(env: EnvironmentType) -> queue.Queue[logging.LogRecord | None]:
    """Получает или создаёт глобальную очередь для логов (один раз на приложение)."""
    global _log_queue, _log_thread, _atexit_registered

    if _log_queue is None:
        with _log_lock:
            if _log_queue is None:
                _log_queue = queue.Queue(-1)  # -1 = без ограничения размера
                _log_thread = threading.Thread(
                    target=_log_listener_thread,
                    args=(_log_queue, env),
                    daemon=True,
                    name="LogListenerThread",
                )
                _log_thread.start()
                if not _atexit_registered:
                    atexit.register(_shutdown_log_listener)
                    _atexit_registered = True

    return _log_queue


# ============================================================================
# ЛОГГЕР (возвращается get_logger, имеет set_trace_id)
# ============================================================================


class TpLogger:
    """
    Логгер, возвращаемый TpLoggerFactory.get_logger().

    env, thread_name, trace_id передаются в каждую запись через extra.
    set_trace_id() / new_trace_id() меняют текущий trace_id для следующих записей.
    """

    def __init__(
        self,
        logger: logging.Logger,
        env: EnvironmentType,
        thread_name: str | int | uuid.UUID | None,
        initial_trace_id: uuid.UUID | None,
    ) -> None:
        self._logger = logger
        self._env = env.value
        self._thread_name = str(thread_name) if thread_name is not None else None
        self._current_trace_id: uuid.UUID | None = (
            initial_trace_id if initial_trace_id is not None else generate_trace_id()
        )

    def _extra(self) -> dict[str, Any]:
        out: dict[str, Any] = {"env": self._env}
        if self._thread_name is not None:
            out["thread_name"] = self._thread_name
        if self._current_trace_id is not None:
            out["trace_id"] = str(self._current_trace_id)
        return out

    def set_trace_id(self, trace_id: uuid.UUID | None) -> None:
        """Установить trace_id для всех последующих записей этого логгера."""
        self._current_trace_id = trace_id

    def new_trace_id(self) -> uuid.UUID:
        """Генерирует новый trace_id, устанавливает и возвращает. Удобно в начале каждой логической операции."""
        new_id = generate_trace_id()
        self._current_trace_id = new_id
        return new_id

    @property
    def trace_id(self) -> uuid.UUID | None:
        """Текущий trace_id или None."""
        return self._current_trace_id

    def _merge_extra(self, kwargs: dict[str, Any]) -> None:
        kwargs["extra"] = {**self._extra(), **kwargs.get("extra", {})}

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._merge_extra(kwargs)
        self._logger.info(msg, *args, **kwargs)

    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._merge_extra(kwargs)
        self._logger.debug(msg, *args, **kwargs)

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._merge_extra(kwargs)
        self._logger.warning(msg, *args, **kwargs)

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._merge_extra(kwargs)
        self._logger.error(msg, *args, **kwargs)

    def exception(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._merge_extra(kwargs)
        self._logger.exception(msg, *args, **kwargs)

    def critical(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._merge_extra(kwargs)
        self._logger.critical(msg, *args, **kwargs)

    def log(self, level: int, msg: str, *args: Any, **kwargs: Any) -> None:
        self._merge_extra(kwargs)
        self._logger.log(level, msg, *args, **kwargs)

    @property
    def logger(self) -> logging.Logger:
        """Доступ к исходному logging.Logger при необходимости."""
        return self._logger


# ============================================================================
# ФАБРИКА ЛОГГЕРОВ
# ============================================================================


class TpLoggerFactory:
    """
    Фабрика логгеров: создаётся с env, возвращает TpLogger через get_logger().

    Создаётся один раз на уровне приложения. get_logger(name, thread_name=..., trace_id=...)
    возвращает TpLogger (один тип, с set_trace_id при необходимости).

    Все экземпляры TpLoggerFactory с use_queue=True пишут в одну общую очередь и один
    фоновый поток. env передаётся с каждой записью.

    Использование:
        from tp_common.tp_logger.tp_logging import TpLoggerFactory, TpLogger
        from tp_common.tp_logger.schemas import EnvironmentType

        factory = TpLoggerFactory(EnvironmentType.DEV)
        logger: TpLogger = factory.get_logger("api_service")
        worker_logger = factory.get_logger("worker", thread_name="worker_1")
        worker_logger.new_trace_id()  # в начале итерации/операции

        TpLoggerFactory.setup_standard_loggers(EnvironmentType.DEV)
    """

    def __init__(self, env: EnvironmentType) -> None:
        """
        Args:
            env: Окружение (local/dev/staging/prod) для поля в логах.
        """
        self._env = env

    def get_logger(
        self,
        name: str | int | None = None,
        thread_name: str | uuid.UUID | int | None = None,
        trace_id: uuid.UUID | None = None,
        use_queue: bool = True,
    ) -> TpLogger:
        """
        Возвращает TpLogger с именем name и опциональными thread_name и trace_id.

        Правило идентификации:
        - если указан `thread_name`, то `name` берётся равным `thread_name`;
        - если не указан ни `name`, ни `thread_name` — бросается исключение.

        Args:
            name: Имя логгера (идентификация в логах). Может быть не задано, если задан `thread_name`.
            thread_name: Метка контекста (воркер, поток-обработчик); опционально.
            trace_id: Начальный trace_id или None — тогда хранится на логгере (set_trace_id/new_trace_id);
            при первой записи без заданного — генерируется случайный.
            use_queue: True — асинхронная запись через общую очередь (по умолчанию).

        Returns:
            TpLogger — логгер с методами info/debug/... и set_trace_id().
        """
        # Если задан `thread_name`, идентификатор логгера должен соответствовать ему.

        self.setup_standard_loggers()

        if thread_name is not None:
            name = str(thread_name)
        if name is None:
            raise TpLoggerMisconfiguredNameError()

        thread_name_key: str | None = (
            str(thread_name) if thread_name is not None else None
        )
        cache_key = (
            self._env.value,
            str(name),
            thread_name_key,
            use_queue,
        )

        with _logger_cache_lock:
            if cache_key in _logger_cache:
                return TpLogger(
                    _logger_cache[cache_key],
                    self._env,
                    thread_name,
                    trace_id,
                )

            logger_name = f"app_logger_{self._env.value}_{name}_{thread_name_key or ''}_{use_queue}"
            logger = logging.getLogger(logger_name)
            logger.setLevel(logging.DEBUG)
            logger.propagate = False

            if use_queue:
                log_queue = _get_log_queue(self._env)
                logger.addHandler(QueueHandler(log_queue))
            else:
                formatter = _create_formatter(self._env)
                stdout_handler = logging.StreamHandler(sys.stdout)
                stdout_handler.setFormatter(formatter)
                logger.addHandler(stdout_handler)

            _logger_cache[cache_key] = logger
            return TpLogger(logger, self._env, thread_name, trace_id)

    def setup_standard_loggers(self) -> None:
        """
        Настраивает логирование для системных библиотек (единый JSON-формат).

        Вызывать при инициализации API-приложения.
        """
        json_formatter = _create_formatter(self._env)
        standard_handler = logging.StreamHandler(sys.stdout)
        standard_handler.setFormatter(json_formatter)

        uvicorn_logger = logging.getLogger("uvicorn")
        uvicorn_logger.setLevel(logging.INFO)
        uvicorn_logger.handlers = [standard_handler]
        uvicorn_logger.propagate = False

        uvicorn_access_logger = logging.getLogger("uvicorn.access")
        uvicorn_access_logger.setLevel(logging.WARNING)
        uvicorn_access_logger.propagate = False

        fastapi_logger = logging.getLogger("fastapi")
        fastapi_logger.setLevel(logging.INFO)
        fastapi_logger.handlers = [standard_handler]
        fastapi_logger.propagate = False

        # aiokafka пишет служебные логи (например про heartbeat/rebalancing)
        # в логгеры aiokafka.*; направляем их в общий JSON-формат.
        aiokafka_logger = logging.getLogger("aiokafka")
        aiokafka_logger.setLevel(logging.WARNING)
        aiokafka_logger.handlers = [standard_handler]
        aiokafka_logger.propagate = False

        logging.getLogger("src.infrastructure.clients").setLevel(logging.INFO)
