"""CLI entry point: `ign8vault up` provisions Vault + Consul on Hetzner."""

import io
import json
import secrets
import shlex
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

import urllib.request

from ign8vault.config import Config
from ign8vault.dns.cloudflare import CloudflareDNS
from ign8vault.infra import hetzner
from ign8vault.keys import ensure_ed25519_keypair, save_keypair
from ign8vault.setup.server import VaultSetup

app = typer.Typer(name="ign8vault", help="Ignite a production Vault + Consul stack in minutes.", invoke_without_command=True)
console = Console()


@app.callback(invoke_without_command=True)
def _main(
    ctx: typer.Context,
    env_file: Path = typer.Option(Path(".env"), "--env-file", hidden=True),
) -> None:
    # Load .env into os.environ so all envvar= options pick it up
    if env_file.exists():
        import os
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip())
        # Bridge IGN8_ prefixed Vault vars to the native Vault env var names
        for bare, prefixed in (("VAULT_ADDR", "IGN8_VAULT_ADDR"), ("VAULT_TOKEN", "IGN8_VAULT_TOKEN")):
            if bare not in os.environ and prefixed in os.environ:
                os.environ[bare] = os.environ[prefixed]
    if ctx.invoked_subcommand is None:
        _print_intro()


@app.command()
def up(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN", help="Base domain (e.g. example.com)"),
    admin_email: str = typer.Option("", envvar="IGN8_ADMIN_EMAIL", help="Admin / certbot email"),
    hetzner_token: str = typer.Option(..., envvar="IGN8_HETZNER_TOKEN", help="Hetzner Cloud API token"),
    cloudflare_token: str = typer.Option(..., envvar="IGN8_CLOUDFLARE_TOKEN", help="Cloudflare API token"),
    cloudflare_zone_id: str = typer.Option(..., envvar="IGN8_CLOUDFLARE_ZONE_ID", help="Cloudflare Zone ID"),
    cloudflare_email: str = typer.Option("", envvar="IGN8_CLOUDFLARE_EMAIL", help="Cloudflare account email (Global API Key only)"),
    storagebox_host: str = typer.Option("", envvar="IGN8_STORAGEBOX_HOST", help="Hetzner StorageBox hostname"),
    storagebox_user: str = typer.Option("", envvar="IGN8_STORAGEBOX_USER", help="StorageBox username (defaults to first part of host)"),
    storagebox_password: str = typer.Option("", envvar="IGN8_STORAGEBOX_PASSWORD", help="StorageBox password"),
    backup_password: str = typer.Option("", envvar="IGN8_BACKUP_PASSWORD", help="Restic encryption password (auto-generated if empty)"),
    work_dir: Path = typer.Option(Path(".ign8vault"), help="Directory for keys and state"),
) -> None:
    """Provision Vault + Consul: Hetzner VM + Cloudflare DNS + TLS + backups."""

    cfg = Config(
        domain=domain,
        admin_email=admin_email,  # type: ignore[arg-type]
        hetzner_token=hetzner_token,
        cloudflare_token=cloudflare_token,
        cloudflare_zone_id=cloudflare_zone_id,
        cloudflare_email=cloudflare_email,
        storagebox_host=storagebox_host,
        storagebox_user=storagebox_user,
        storagebox_password=storagebox_password,
        backup_password=backup_password,
    )

    # Auto-generate backup password if not supplied
    effective_backup_password = cfg.backup_password or secrets.token_hex(24)

    console.print(Panel(f"[bold]ign8vault[/bold] — igniting [cyan]{cfg.domain}[/cyan]"))

    # 1. SSH keypair
    console.print("[1/5] Generating SSH keypair...")
    keys_dir = work_dir / "keys"
    priv_path, pub_path = save_keypair(keys_dir)
    public_key_openssh = pub_path.read_text().strip()

    # 2. Hetzner server
    console.print("[2/5] Provisioning Hetzner server...")
    outputs = hetzner.provision(cfg, public_key_openssh, work_dir / "state.json")
    ipv4: str = outputs["ipv4"]
    ipv6: str = outputs["ipv6"]
    console.print(f"    Server IPv4: [green]{ipv4}[/green]")
    if ipv6:
        console.print(f"    Server IPv6: [green]{ipv6}[/green]")

    # 3. Cloudflare DNS
    console.print("[3/5] Creating Cloudflare DNS records...")
    dns = CloudflareDNS(cfg.cloudflare_token, cfg.cloudflare_zone_id, cfg.domain, cfg.cloudflare_email)
    dns.provision(ipv4, ipv6)
    console.print(f"    vault.{cfg.domain}  → {ipv4}")
    console.print(f"    consul.{cfg.domain} → {ipv4}")

    # 4. Server setup
    console.print("[4/5] Setting up server (Consul + Vault + nginx + TLS)...")
    console.print("    Connecting via SSH (may take up to 5 minutes for boot)...")
    setup = VaultSetup(cfg, ipv4, str(priv_path))
    setup.connect(retries=30, delay=10)
    try:
        init_data = setup.run(effective_backup_password)
    finally:
        setup.disconnect()

    # 5. Save credentials locally
    console.print("[5/5] Saving credentials...")
    init_path = work_dir / "vault-init.json"
    saved: dict[str, object] = {
        "vault_url": f"https://vault.{cfg.domain}",
        "consul_url": f"https://consul.{cfg.domain}",
        "backup_password": effective_backup_password,
    }
    if init_data:
        saved.update(init_data)

    init_path.write_text(json.dumps(saved, indent=2))
    init_path.chmod(0o600)

    _print_summary(cfg, saved, init_data)


@app.command()
def destroy(
    domain: str = typer.Option(..., envvar="IGN8_DOMAIN", help="Base domain"),
    hetzner_token: str = typer.Option(..., envvar="IGN8_HETZNER_TOKEN", help="Hetzner Cloud API token"),
    cloudflare_token: str = typer.Option("", envvar="IGN8_CLOUDFLARE_TOKEN", help="Cloudflare API token"),
    cloudflare_zone_id: str = typer.Option("", envvar="IGN8_CLOUDFLARE_ZONE_ID", help="Cloudflare Zone ID"),
    cloudflare_email: str = typer.Option("", envvar="IGN8_CLOUDFLARE_EMAIL"),
    work_dir: Path = typer.Option(Path(".ign8vault"), help="Directory for keys and state"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Tear down the Vault + Consul server and DNS records."""
    if not yes:
        typer.confirm(f"Destroy all ign8vault resources for {domain}?", abort=True)

    console.print(Panel(f"[bold red]ign8vault destroy[/bold red] — tearing down [cyan]{domain}[/cyan]"))

    console.print("[1/2] Deleting Hetzner server...")
    hetzner.destroy(work_dir / "state.json", hetzner_token)

    if cloudflare_token and cloudflare_zone_id:
        console.print("[2/2] Removing DNS records...")
        dns = CloudflareDNS(cloudflare_token, cloudflare_zone_id, domain, cloudflare_email)
        dns.destroy()
    else:
        console.print("[2/2] Skipping DNS cleanup (no Cloudflare credentials)")

    console.print("[green]Done.[/green] DNS may take a few minutes to propagate removal.")


def _print_summary(cfg: Config, saved: dict[str, object], init_data: dict[str, object]) -> None:
    console.print()
    console.print(Panel("[bold green]Vault stack is live![/bold green]"))

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[dim]Vault UI[/dim]",  f"[cyan]https://vault.{cfg.domain}[/cyan]")
    table.add_row("[dim]Consul UI[/dim]", f"[cyan]https://consul.{cfg.domain}[/cyan]")

    if init_data:
        root_token = str(init_data.get("root_token", ""))
        table.add_row("[dim]Root token[/dim]", f"[yellow]{root_token}[/yellow]")
        keys = init_data.get("unseal_keys_b64", [])
        for i, k in enumerate(keys, 1):  # type: ignore[union-attr]
            table.add_row(f"[dim]Unseal key {i}[/dim]", str(k))

    backup_pw = str(saved.get("backup_password", ""))
    if backup_pw:
        table.add_row("[dim]Backup password[/dim]", f"[yellow]{backup_pw}[/yellow]")

    console.print(table)
    console.print()
    console.print(
        f"[dim]Credentials saved to[/dim] [bold].ign8vault/vault-init.json[/bold]\n"
        f"[dim]Keep unseal keys safe — you need 3 of 5 to unseal after a reboot.[/dim]"
    )


@app.command()
def sign(
    vault_addr: str = typer.Option(..., envvar=["VAULT_ADDR", "IGN8_VAULT_ADDR"], help="Vault address"),
    vault_token: str = typer.Option(..., envvar=["VAULT_TOKEN", "IGN8_VAULT_TOKEN"], help="Vault token"),
    principals: str = typer.Option("", help="Comma-separated list of valid principals (default: current user + root)"),
    role: str = typer.Option("signer", help="Vault SSH signing role"),
    keys_dir: Path = typer.Option(Path("~/.ssh/signedssh").expanduser(), help="Directory for signing keys"),
) -> None:
    """Create (if absent) the signssh keypair and sign it, saving the cert as signedssh."""
    import getpass
    if not principals:
        principals = f"{getpass.getuser()},root"

    keys_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

    # 1. Create keypair if it doesn't exist yet
    priv_path, pub_path = ensure_ed25519_keypair(keys_dir, "signssh")
    public_key = pub_path.read_text().strip()
    console.print(f"[dim]Key:[/dim] {pub_path}")

    # 2. Sign via Vault SSH API
    payload = json.dumps({
        "public_key": public_key,
        "valid_principals": principals,
        "cert_type": "user",
    }).encode()

    req = urllib.request.Request(
        f"{vault_addr.rstrip('/')}/v1/ssh/sign/{role}",
        data=payload,
        headers={"X-Vault-Token": vault_token, "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read())

    signed_key: str = data["data"]["signed_key"]

    # 3. Save as signssh-cert.pub (OpenSSH auto-discovery: looks for <key>-cert.pub)
    cert_path = keys_dir / "signssh-cert.pub"
    cert_path.write_text(signed_key + "\n")
    cert_path.chmod(0o644)

    console.print(f"[green]Signed certificate saved to[/green] {cert_path}")
    console.print(f"[dim]Serial:[/dim] {data['data']['serial_number']}")
    console.print(f"  ssh -i {priv_path} <host>  [cert auto-loaded]")


@app.command()
def setenv(
    env_file: Path = typer.Option(Path(".env"), help="Path to write credentials"),
) -> None:
    """Interactive setup: collect all credentials and write to .env."""
    import os

    # Read existing .env values so we can show them as defaults
    existing: dict[str, str] = {}
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            existing[k.strip()] = v.strip()

    def _current(key: str, fallback: str = "") -> str:
        return existing.get(key) or os.environ.get(key, fallback)

    def _ask(label: str, key: str, hint: str, required: bool = True, secret: bool = False) -> str:
        console.print(f"\n[bold]{label}[/bold]")
        console.print(f"  [dim]{hint}[/dim]")
        default = _current(key)
        display_default = ("(set)" if default else "") if secret else default
        prompt_text = f"  {key}" + (f" [{display_default}]" if display_default else "")
        while True:
            value = typer.prompt(prompt_text, default=default, show_default=False).strip()
            if value or not required:
                return value
            console.print("  [red]Required — cannot be empty.[/red]")

    console.print(Panel("[bold]ign8vault — interactive setup[/bold]", style="bold cyan"))
    console.print("\nPress Enter to keep an existing value. Leave optional fields blank to skip.\n")

    results: list[tuple[str, str]] = []

    # --- Provisioning vars ---
    console.rule("[dim]Provisioning[/dim]")

    results.append(("IGN8_DOMAIN", _ask(
        "Domain",
        "IGN8_DOMAIN",
        "Base domain — vault.DOMAIN and consul.DOMAIN will be created (e.g. example.com)",
    )))
    results.append(("IGN8_ADMIN_EMAIL", _ask(
        "Admin email",
        "IGN8_ADMIN_EMAIL",
        "Contact email for Let's Encrypt TLS certificates",
    )))
    results.append(("IGN8_HETZNER_TOKEN", _ask(
        "Hetzner Cloud API token",
        "IGN8_HETZNER_TOKEN",
        "console.hetzner.cloud → Project → Security → API Tokens → Generate API Token",
        secret=True,
    )))
    results.append(("IGN8_CLOUDFLARE_TOKEN", _ask(
        "Cloudflare API token",
        "IGN8_CLOUDFLARE_TOKEN",
        "dash.cloudflare.com → Profile → API Tokens → Create Token\n"
        "  Permission needed: Zone → DNS → Edit",
        secret=True,
    )))
    results.append(("IGN8_CLOUDFLARE_ZONE_ID", _ask(
        "Cloudflare Zone ID",
        "IGN8_CLOUDFLARE_ZONE_ID",
        "dash.cloudflare.com → select your domain → Overview → right sidebar → Zone ID",
    )))

    # --- Backup (optional) ---
    console.rule("[dim]Backup (optional — press Enter to skip)[/dim]")

    results.append(("IGN8_STORAGEBOX_HOST", _ask(
        "StorageBox hostname",
        "IGN8_STORAGEBOX_HOST",
        "Hetzner StorageBox hostname, e.g. u310424.your-storagebox.de\n"
        "  hetzner.com/storage/storage-box — leave blank to skip backups",
        required=False,
    )))
    if dict(results).get("IGN8_STORAGEBOX_HOST"):
        results.append(("IGN8_STORAGEBOX_PASSWORD", _ask(
            "StorageBox password",
            "IGN8_STORAGEBOX_PASSWORD",
            "Found in your Hetzner account under the StorageBox details",
            required=False,
            secret=True,
        )))

    # --- Vault connection (optional, set after provisioning) ---
    console.rule("[dim]Vault connection (optional — set after ign8vault up)[/dim]")

    results.append(("IGN8_VAULT_ADDR", _ask(
        "Vault address",
        "IGN8_VAULT_ADDR",
        "Your Vault URL, e.g. https://vault.example.com\n"
        "  Leave blank now — fill in after running ign8vault up",
        required=False,
    )))
    results.append(("IGN8_VAULT_TOKEN", _ask(
        "Vault token",
        "IGN8_VAULT_TOKEN",
        "Root or user token from .ign8vault/vault-init.json\n"
        "  Leave blank now — fill in after running ign8vault up",
        required=False,
        secret=True,
    )))

    # Write .env (upsert)
    lines = env_file.read_text().splitlines() if env_file.exists() else []
    written: set[str] = set()
    new_lines: list[str] = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            new_lines.append(line)
            continue
        key = stripped.partition("=")[0].strip()
        match = next(((k, v) for k, v in results if k == key), None)
        if match:
            k, v = match
            new_lines.append(f"{k}={v}" if v else f"# {k}=")
            written.add(k)
        else:
            new_lines.append(line)
    for k, v in results:
        if k not in written:
            new_lines.append(f"{k}={v}" if v else f"# {k}=")

    env_file.write_text("\n".join(new_lines) + "\n")
    env_file.chmod(0o600)

    console.print(f"\n[green]Written to {env_file}[/green]")

    # Test Vault connection if address provided
    vault_addr = dict(results).get("IGN8_VAULT_ADDR", "")
    vault_token = dict(results).get("IGN8_VAULT_TOKEN", "")
    if vault_addr:
        console.print(f"\n[dim]Testing connection to {vault_addr} …[/dim]")
        try:
            req = urllib.request.Request(
                f"{vault_addr.rstrip('/')}/v1/sys/health",
                headers={"X-Vault-Token": vault_token},
            )
            with urllib.request.urlopen(req) as resp:
                health = json.loads(resp.read())
            sealed = health.get("sealed", True)
            version = health.get("version", "?")
            status = "[green]unsealed[/green]" if not sealed else "[yellow]sealed[/yellow]"
            console.print(f"  Vault {version} — {status}")
        except Exception as exc:
            console.print(f"  [yellow]Could not connect:[/yellow] {exc}")


@app.command()
def test(
    host: str = typer.Option(..., "--host", help="Hostname, IP, or ~/.ssh/config alias"),
    user: str = typer.Option("", "--user", "-u", help="SSH username (default: current user)"),
    port: int = typer.Option(22, "--port", "-p", help="SSH port"),
    keys_dir: Path = typer.Option(Path("~/.ssh/signedssh").expanduser(), help="Directory for signing keys"),
) -> None:
    """Test SSH login to a host using the signed certificate."""
    import subprocess

    priv_path = keys_dir / "signssh"
    cert_path = keys_dir / "signssh-cert.pub"

    for p in (priv_path, cert_path):
        if not p.exists():
            console.print(f"[red]Missing {p} — run [cyan]ign8vault sign[/cyan] first.[/red]")
            raise typer.Exit(1)

    # Show cert info before attempting
    info = subprocess.run(["ssh-keygen", "-L", "-f", str(cert_path)], capture_output=True, text=True)
    lines = info.stdout.splitlines()
    valid_line = next((l.strip() for l in lines if l.strip().startswith("Valid:")), "")
    principals: list[str] = []
    in_principals = False
    for l in lines:
        stripped = l.strip()
        if stripped.startswith("Principals:"):
            in_principals = True
            continue
        if in_principals:
            if stripped and ":" not in stripped:
                principals.append(stripped)
            elif stripped:
                break
    if valid_line:
        console.print(f"[dim]Cert  {valid_line}[/dim]")
    if principals:
        console.print(f"[dim]      Principals: {', '.join(principals)}[/dim]")

    # If --user not given, let ~/.ssh/config resolve the user for this host
    target = f"{user}@{host}" if user else host
    console.print(f"[dim]Connecting to [cyan]{target}[/cyan]:{port} …[/dim]")

    cmd = [
        "ssh",
        "-i", str(priv_path),
        "-o", f"CertificateFile={cert_path}",
        "-o", "BatchMode=yes",
        "-o", "StrictHostKeyChecking=accept-new",
        "-p", str(port),
        target,
        "whoami",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)

    if result.returncode == 0:
        remote_user = result.stdout.strip()
        console.print(f"[green]OK[/green] — logged in as [cyan]{remote_user}[/cyan]")
    else:
        stderr = result.stderr.strip().splitlines()
        reason = next((l for l in stderr if "Permission denied" in l or "error" in l.lower()), stderr[-1] if stderr else "unknown")
        console.print(f"[red]Failed[/red] — {reason}")
        raise typer.Exit(1)


@app.command()
def ssh(
    host: str = typer.Option(..., "--host", help="Hostname, IP, or ~/.ssh/config alias"),
    user: str = typer.Option("", "--user", "-u", help="SSH username (default: current user)"),
    port: int = typer.Option(22, "--port", "-p", help="SSH port"),
    keys_dir: Path = typer.Option(Path("~/.ssh/signedssh").expanduser(), help="Directory for signing keys"),
) -> None:
    """Open an interactive SSH session using the signed certificate."""
    import os as _os

    priv_path = keys_dir / "signssh"
    cert_path = keys_dir / "signssh-cert.pub"

    for p in (priv_path, cert_path):
        if not p.exists():
            console.print(f"[red]Missing {p} — run [cyan]ign8vault sign[/cyan] first.[/red]")
            raise typer.Exit(1)

    # If --user not given, let ~/.ssh/config resolve the user for this host
    target = f"{user}@{host}" if user else host
    ssh_bin = shlex.split(_os.environ.get("SSH", "ssh"))[0]
    args = [
        ssh_bin,
        "-i", str(priv_path),
        "-o", f"CertificateFile={cert_path}",
        "-o", "StrictHostKeyChecking=accept-new",
        "-p", str(port),
        target,
    ]
    _os.execvp(ssh_bin, args)


@app.command()
def adduser(
    vault_addr: str = typer.Option(..., envvar="VAULT_ADDR", help="Vault address"),
    vault_token: str = typer.Option(..., envvar="VAULT_TOKEN", help="Vault admin token"),
    username: str = typer.Argument(..., help="Username to create"),
    role: str = typer.Option("signer", help="SSH signing role"),
) -> None:
    """Create a Vault user with a password and a dedicated SSH-signing token."""
    import os

    password = secrets.token_urlsafe(16)

    def api(method: str, path: str, body: Optional[dict] = None) -> dict:
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(
            f"{vault_addr.rstrip('/')}/v1/{path}",
            data=data,
            headers={"X-Vault-Token": vault_token, "Content-Type": "application/json"},
            method=method,
        )
        try:
            with urllib.request.urlopen(req) as resp:
                return json.loads(resp.read()) if resp.length != 0 else {}  # type: ignore[attr-defined]
        except urllib.error.HTTPError as exc:
            body_bytes = exc.read()
            err = json.loads(body_bytes).get("errors", [str(exc)]) if body_bytes else [str(exc)]
            # Ignore "already enabled/exists" errors
            if any("already" in e for e in err):
                return {}
            raise RuntimeError("; ".join(err)) from exc

    # 1. Enable userpass auth (idempotent)
    console.print("[1/4] Enabling userpass auth method...")
    api("POST", "sys/auth/userpass", {"type": "userpass"})

    # 2. Create SSH-signer policy (idempotent)
    console.print("[2/4] Writing ssh-signer policy...")
    policy_hcl = f'path "ssh/sign/{role}" {{\n  capabilities = ["create", "update"]\n}}\n'
    api("PUT", "sys/policies/acl/ssh-signer", {"policy": policy_hcl})

    # 3. Create the userpass user
    console.print(f"[3/4] Creating user [cyan]{username}[/cyan]...")
    api("POST", f"auth/userpass/users/{username}", {
        "password": password,
        "policies": "ssh-signer",
    })

    # 4. Create an orphan token tied to the ssh-signer policy
    console.print("[4/4] Creating SSH-signing token...")
    resp = api("POST", "auth/token/create", {
        "policies": ["ssh-signer"],
        "display_name": f"{username}-ssh-sign",
        "no_parent": True,
        "renewable": True,
        "ttl": "8760h",  # 1 year
    })
    sign_token: str = resp["auth"]["client_token"]

    # Display
    console.print()
    console.print(Panel(f"[bold green]User [cyan]{username}[/cyan] created[/bold green]"))
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("[dim]Username[/dim]",    f"[cyan]{username}[/cyan]")
    table.add_row("[dim]Password[/dim]",    f"[yellow]{password}[/yellow]")
    table.add_row("[dim]Sign token[/dim]",  f"[yellow]{sign_token}[/yellow]", no_wrap=True)
    table.add_row("[dim]Vault login[/dim]", f"vault login -method=userpass username={username}")
    console.print(table)
    console.print()
    console.print("[dim]The sign token can be used as VAULT_TOKEN for[/dim] [cyan]ign8vault sign[/cyan]")


@app.command()
def setupsshd(
    host: str = typer.Option(..., "--host", help="Target hostname or IP"),
    user: str = typer.Option(..., "--user", help="SSH username on the target"),
    password: str = typer.Option(..., "--password", help="SSH password for initial connection"),
    ssh_port: int = typer.Option(22, "--port", help="SSH port"),
    vault_addr: str = typer.Option(..., envvar=["VAULT_ADDR", "IGN8_VAULT_ADDR"], help="Vault address"),
    keys_dir: Path = typer.Option(Path("~/.ssh/signedssh").expanduser(), help="Directory for signing keys"),
) -> None:
    """Configure a host to trust the Vault SSH CA and add an ~/.ssh/config entry."""
    import paramiko

    signssh_priv = keys_dir / "signssh"
    signssh_cert = keys_dir / "signssh-cert.pub"

    for p in (signssh_priv, signssh_cert):
        if not p.exists():
            console.print(f"[red]Missing {p} — run [cyan]ign8vault sign[/cyan] first.[/red]")
            raise typer.Exit(1)

    # 1. Fetch Vault SSH CA public key (unauthenticated endpoint)
    console.print("[1/3] Fetching Vault SSH CA public key...")
    req = urllib.request.Request(f"{vault_addr.rstrip('/')}/v1/ssh/public_key")
    with urllib.request.urlopen(req) as resp:
        ca_pub_key = resp.read().decode().strip()
    console.print(f"    [dim]{len(ca_pub_key)} bytes[/dim]")

    # 2. Connect to target host and configure sshd
    console.print(f"[2/3] Connecting to [cyan]{host}[/cyan] as [cyan]{user}[/cyan]...")
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(host, port=ssh_port, username=user, password=password)

    is_root = user == "root"

    def _run(cmd: str) -> str:
        full = cmd if is_root else f"sudo -S -p '' sh -c {shlex.quote(cmd)}"
        stdin, stdout, stderr = client.exec_command(full)
        if not is_root:
            stdin.write(password + "\n")
            stdin.flush()
        stdin.channel.shutdown_write()
        rc = stdout.channel.recv_exit_status()
        out = stdout.read().decode()
        err = stderr.read().decode()
        if rc != 0:
            raise RuntimeError(err.strip() or out.strip())
        return out

    try:
        is_macos = _run("uname").strip() == "Darwin"
        console.print(f"    [dim]{'macOS' if is_macos else 'Linux'} detected[/dim]")

        # Write CA key via SFTP, then move with sudo to final location
        tmp = f"/tmp/vault-ca-{secrets.token_hex(6)}.pub"
        sftp = client.open_sftp()
        sftp.putfo(io.BytesIO((ca_pub_key + "\n").encode()), tmp)
        sftp.close()

        _run(f"mv {shlex.quote(tmp)} /etc/ssh/trusted-user-ca-keys.pem && chmod 644 /etc/ssh/trusted-user-ca-keys.pem")
        console.print("    [dim]CA key → /etc/ssh/trusted-user-ca-keys.pem[/dim]")

        # Add TrustedUserCAKeys directive if absent
        _run(
            "grep -q TrustedUserCAKeys /etc/ssh/sshd_config || "
            "echo 'TrustedUserCAKeys /etc/ssh/trusted-user-ca-keys.pem' >> /etc/ssh/sshd_config"
        )
        console.print("    [dim]sshd_config updated[/dim]")

        # Ensure user exists (no-op if they already do)
        if is_macos:
            _run(f"id {shlex.quote(user)} > /dev/null 2>&1 || dscl . -create /Users/{shlex.quote(user)}")
        else:
            _run(f"id {shlex.quote(user)} > /dev/null 2>&1 || useradd -m -s /bin/bash {shlex.quote(user)}")
        console.print(f"    [dim]User {user!r} verified[/dim]")

        # Reload sshd
        if is_macos:
            _run("launchctl kickstart -k system/com.openssh.sshd 2>/dev/null || true")
        else:
            _run("systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || true")
        console.print("    [dim]sshd reloaded[/dim]")
    finally:
        client.close()

    # 3. Update local ~/.ssh/config
    console.print("[3/3] Updating [cyan]~/.ssh/config[/cyan]...")
    short = host.split(".")[0]
    _upsert_ssh_config(short, host, user, signssh_priv.resolve(), signssh_cert.resolve(), ssh_port)

    console.print()
    console.print(Panel(f"[bold green]Host [cyan]{short}[/cyan] ready for signed SSH[/bold green]"))
    console.print(f"  ssh {short}  [dim](cert: {signssh_cert.name})[/dim]")


def _upsert_ssh_config(alias: str, hostname: str, user: str, identity: Path, cert: Path, port: int) -> None:
    config_path = Path("~/.ssh/config").expanduser()
    config_path.parent.mkdir(mode=0o700, exist_ok=True)

    entry = (
        f"\nHost {alias}\n"
        f"    HostName {hostname}\n"
        f"    User {user}\n"
        f"    IdentityFile {identity}\n"
        f"    CertificateFile {cert}\n"
    )
    if port != 22:
        entry += f"    Port {port}\n"

    text = config_path.read_text() if config_path.exists() else ""
    marker = f"Host {alias}\n"
    if marker in text:
        console.print(f"    [yellow]Host {alias!r} already in ~/.ssh/config — skipping[/yellow]")
        return

    with config_path.open("a") as f:
        f.write(entry)
    config_path.chmod(0o600)
    console.print(f"    Added [cyan]Host {alias}[/cyan] → {hostname}")


@app.command()
def quickstart() -> None:
    """Print a step-by-step quickstart guide."""
    console.print()
    console.print(Panel("[bold]ign8vault — Quickstart[/bold]", style="bold cyan"))

    steps = [
        (
            "1. Install",
            "[dim]$ [/dim]pipx install ign8vault",
        ),
        (
            "2. Configure",
            "[dim]$ [/dim][cyan]ign8vault setenv[/cyan]\n\n"
            "  Walks you through every credential with hints on where to find\n"
            "  each value. Writes a [bold].env[/bold] file in the current directory.\n"
            "  Re-run after provisioning to fill in VAULT_ADDR and VAULT_TOKEN.",
        ),
        (
            "3. Provision the stack",
            "[dim]$ [/dim][cyan]ign8vault up[/cyan]\n\n"
            "  Creates a Hetzner VPS, Cloudflare DNS records, installs Consul +\n"
            "  Vault + nginx + TLS + daily restic backups. Saves credentials to\n"
            "  [bold].ign8vault/vault-init.json[/bold] (keep the unseal keys safe!).",
        ),
        (
            "4. Finish configuration",
            "[dim]$ [/dim][cyan]ign8vault setenv[/cyan]\n\n"
            "  Re-run setenv to fill in VAULT_ADDR and VAULT_TOKEN from\n"
            "  [bold].ign8vault/vault-init.json[/bold]. Existing values are preserved.",
        ),
        (
            "5. Create a user (optional)",
            "[dim]$ [/dim][cyan]ign8vault adduser[/cyan] [yellow]<username>[/yellow]\n\n"
            "  Creates a Vault userpass account and a scoped SSH-signing token.\n"
            "  Use the printed token as VAULT_TOKEN for [cyan]ign8vault sign[/cyan].",
        ),
        (
            "6. Sign your SSH key",
            "[dim]$ [/dim][cyan]ign8vault sign[/cyan]\n\n"
            "  Generates an ed25519 keypair in [bold]~/.ssh/signedssh/[/bold] and signs it\n"
            "  via the Vault SSH CA. The signed cert is valid for 8 hours.\n"
            "  Re-run any time to renew.",
        ),
        (
            "7. Configure a target host",
            "[dim]$ [/dim][cyan]ign8vault setupsshd[/cyan] [yellow]--host <ip> --user <user> --password <pw>[/yellow]\n\n"
            "  Installs the Vault CA public key on the host, adds a\n"
            "  [bold]~/.ssh/config[/bold] entry, and reloads sshd.\n"
            "  After this, [bold]ssh <alias>[/bold] works with your signed cert.",
        ),
        (
            "8. Connect",
            "[dim]$ [/dim]ssh [yellow]<alias>[/yellow]\n\n"
            "  Certificate-based login — no passwords, no individual authorized_keys.",
        ),
        (
            "Tear down",
            "[dim]$ [/dim][cyan]ign8vault destroy[/cyan]\n\n"
            "  Deletes the Hetzner server and Cloudflare DNS records.",
        ),
    ]

    for title, body in steps:
        console.print(f"\n[bold]{title}[/bold]")
        console.print(f"  {body}")

    console.print()
    console.print("[dim]Docs & source:[/dim] https://github.com/lyngknuden/ign8vault")
    console.print()


def _print_intro() -> None:
    console.print(Panel(
        "[bold]ign8vault[/bold] — HashiCorp Vault + Consul on Hetzner\n\n"
        "  [cyan]ign8vault up[/cyan]          provision a complete stack\n"
        "  [cyan]ign8vault adduser[/cyan]     create a Vault user + SSH-sign token\n"
        "  [cyan]ign8vault sign[/cyan]        create/sign the signssh keypair\n"
        "  [cyan]ign8vault setupsshd[/cyan]   configure a host to trust Vault CA + update ~/.ssh/config\n"
        "  [cyan]ign8vault test[/cyan]        test signed SSH login to a host\n"
        "  [cyan]ign8vault ssh[/cyan]         open a signed SSH session\n"
        "  [cyan]ign8vault setenv[/cyan]      interactive credential setup\n"
        "  [cyan]ign8vault quickstart[/cyan]  step-by-step guide\n"
        "  [cyan]ign8vault destroy[/cyan]     tear it all down",
        title="ign8vault",
    ))
