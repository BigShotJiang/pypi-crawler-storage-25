"""AlgoTradeKit – Algorithmic Trading Toolkit"""
__version__ = "0.0.0"