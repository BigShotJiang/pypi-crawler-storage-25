# poly-lens

**Route any file to the right analysis lens.**

Instead of remembering which tool handles which file type, you run `polylens analyse <file>` and poly-lens figures out the rest — routing PDFs to [document-lens](https://github.com/michael-borck/document-lens), audio to [audio-lens](https://github.com/michael-borck/audio-lens), spreadsheets to [data-lens](https://github.com/michael-borck/data-lens), and code to code-lens.

## Install

```bash
pip install poly-lens
```

## Usage

```bash
polylens detect report.pdf          # report.pdf -> document-lens
polylens detect data.json           # Note: may be config data...  data.json -> data-lens
polylens detect notebook.ipynb      # Note: contains code and prose...  notebook.ipynb -> code-lens

polylens analyse report.pdf
polylens analyse recording.mp3 --json
polylens analyse data.json --lens document-lens
polylens status
```

## Python API

```python
from poly_lens import Router

router = Router()
result = router.route("report.pdf")
```

## Configuration

poly-lens ships with built-in defaults (document-lens on `localhost:8000`, audiolens via CLI, etc.). Override with a config file:

```
./poly-lens.yaml
~/.config/poly-lens/config.yaml
```

See `poly-lens.example.yaml` for all options.

## Part of the poly-lens family

- [document-lens](https://github.com/michael-borck/document-lens) — PDF, DOCX, Markdown, plain text
- [audio-lens](https://github.com/michael-borck/audio-lens) — MP3, WAV, M4A and other audio formats
- [data-lens](https://github.com/michael-borck/data-lens) — CSV, Excel, Parquet, SQLite, JSON
- [video-lens](https://github.com/michael-borck/video-lens) — MP4, MOV, AVI and other video formats
- [poly-lens](https://github.com/michael-borck/poly-lens) — meta-router: detects format and calls the right lens

## License

MIT
