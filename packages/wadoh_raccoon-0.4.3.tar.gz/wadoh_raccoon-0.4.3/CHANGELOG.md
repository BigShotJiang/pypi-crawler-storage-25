## [0.4.3](https://github.com/NW-PaGe/wadoh_raccoon/compare/v0.4.2...v0.4.3) (2026-03-31)


### Bug Fixes

* test fix cus gh actions are hilarious ([655af19](https://github.com/NW-PaGe/wadoh_raccoon/commit/655af19a9984ad4a55daa143a5a812731593d9c9))



## [0.4.2](https://github.com/NW-PaGe/wadoh_raccoon/compare/v0.4.1...v0.4.2) (2026-03-31)


### Bug Fixes

* check for data leaks on input schema when no key specified ([90f748e](https://github.com/NW-PaGe/wadoh_raccoon/commit/90f748ec95660e0eab934bded58f7cb3ee7e2f2e))



## [0.4.1](https://github.com/NW-PaGe/wadoh_raccoon/compare/v0.4.0...v0.4.1) (2026-03-24)


### Bug Fixes

* update dataframe_matcher.py ([c952aa3](https://github.com/NW-PaGe/wadoh_raccoon/commit/c952aa3b004088a1ac77e1bc06c8aa84276574c4))



# [0.4.0](https://github.com/NW-PaGe/wadoh_raccoon/compare/v0.3.0...v0.4.0) (2026-02-04)


### Bug Fixes

* push corrected ver and restore del ([b75a720](https://github.com/NW-PaGe/wadoh_raccoon/commit/b75a720874249a6f19b6b7d685efcbd3e2b49f1b))


### Features

* accept lf input in dataframe_matcher.py ([924caf5](https://github.com/NW-PaGe/wadoh_raccoon/commit/924caf5bbc84b7a93431aef2bb977bd14d0a98c4))
* add mft_upload function ([dbaedc4](https://github.com/NW-PaGe/wadoh_raccoon/commit/dbaedc4f306c5c59c88a7d524f956dfb588c1ecb))
* update helpers ([f4ec01d](https://github.com/NW-PaGe/wadoh_raccoon/commit/f4ec01dda3b87d0c4347d6b7305321896b19d2e3))



# [0.3.0](https://github.com/NW-PaGe/wadoh_raccoon/compare/v0.2.0...v0.3.0) (2025-10-23)


### Bug Fixes

* fix fuzzy matching outputs - submission df needs create date + sub_number ([016ad1e](https://github.com/NW-PaGe/wadoh_raccoon/commit/016ad1edf560f3f0047e40ba34a80f240a557409))
* raise error if df_subm doesn't have submission_number or internal_create_date ([cd946a7](https://github.com/NW-PaGe/wadoh_raccoon/commit/cd946a77a004f12dbd4a64e81d406032e20bb2a0))
* update key col, add respnet tests ([00a53bb](https://github.com/NW-PaGe/wadoh_raccoon/commit/00a53bbae4c2f23b81329041f1615171706edb06))
* use self.key instead of submission_number ([e3ac609](https://github.com/NW-PaGe/wadoh_raccoon/commit/e3ac6099707088b5e6c87c4d7816b32a529ab42a))


### Features

* add exact match and cleaner functions to match class ([d15f56f](https://github.com/NW-PaGe/wadoh_raccoon/commit/d15f56fbf0c12f0dba012fc096c3d2bb33307a00))
* add output message and errors for data leaks ([45b4305](https://github.com/NW-PaGe/wadoh_raccoon/commit/45b430542724d5f4cd886c637f24b4d36e61b7de))
* init shig match tests ([f8d68d0](https://github.com/NW-PaGe/wadoh_raccoon/commit/f8d68d0da93c1ee9b2b9739f79cfbfd2f621ca16))
* update enteric test_dataframe_matcher.py ([9dfd804](https://github.com/NW-PaGe/wadoh_raccoon/commit/9dfd804f00b942998cbf60ef9fcf2161bc8f7b9f))
* update names, add clean_names and prep_df functions ([149223a](https://github.com/NW-PaGe/wadoh_raccoon/commit/149223a9ba2fd0e6c803a6e0a722c1de8d84f0c1))



