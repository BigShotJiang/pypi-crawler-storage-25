"""numberlabs — coming soon.

Reference implementation of the OpenRecon reconciliation spec.
This is a name reservation release. Full package launching shortly.
"""

__version__ = "0.0.1.dev0"


def _coming_soon() -> None:
    print("numberlabs is coming soon. Follow https://github.com/slainai for updates.")


_coming_soon()