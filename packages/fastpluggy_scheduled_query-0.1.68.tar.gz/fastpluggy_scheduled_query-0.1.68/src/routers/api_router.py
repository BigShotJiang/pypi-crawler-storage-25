import csv
import io
import json
import time

from fastapi import APIRouter, Depends, Request, HTTPException
from fastapi import Query
from fastapi.responses import JSONResponse
from fastapi.responses import RedirectResponse
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, field_validator
from sqlalchemy import desc, text
from sqlalchemy.orm import Session


def _safe_parse(raw: str | None) -> dict | None:
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return {"type": "raw", "value": raw}

def _extract_scalar(result_str: str):
    """Extract a single scalar value from a counter/metric result JSON string."""
    try:
        data = json.loads(result_str)
        if data.get("type") == "rows" and data.get("rows") and data.get("columns"):
            first_row = data["rows"][0]
            first_col = data["columns"][0]["name"]
            val = first_row.get(first_col)
            if isinstance(val, (int, float)):
                return val
    except Exception:
        pass
    return None

from fastpluggy.core.auth import require_authentication
from fastpluggy.core.database import get_db
from ..models import ScheduledQuery
from ..models import ScheduledQueryResultHistory
from ..tasks import execute_scheduled_query, is_query_safe, _build_column_meta, _row_to_dict




api_router = APIRouter(
    prefix="/api",
    dependencies=[Depends(require_authentication)]
)

@api_router.post("/query/{query_id}/toggle", name="toggle_query_enabled")
def toggle_query_enabled(
        query_id: int,
        db: Session = Depends(get_db)
):
    """Toggle the enabled field of a scheduled query."""
    q = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not q:
        return JSONResponse(status_code=404, content={"error": "Query not found"})
    q.enabled = not q.enabled
    db.commit()
    return JSONResponse(content={"enabled": q.enabled})


ALLOWED_CHART_TYPES = {"area", "bar", "line", "donut", "pie"}
ALLOWED_CHART_KEYS = {"timeline", "donut", "trend", "detail"}


class ChartPreferenceRequest(BaseModel):
    chart_key: str
    chart_type: str

    @field_validator("chart_key")
    @classmethod
    def validate_chart_key(cls, v: str) -> str:
        if v not in ALLOWED_CHART_KEYS:
            raise ValueError(f"chart_key must be one of {sorted(ALLOWED_CHART_KEYS)}")
        return v

    @field_validator("chart_type")
    @classmethod
    def validate_chart_type(cls, v: str) -> str:
        if v not in ALLOWED_CHART_TYPES:
            raise ValueError(f"chart_type must be one of {sorted(ALLOWED_CHART_TYPES)}")
        return v


@api_router.patch("/query/{query_id}/chart-preferences", name="update_chart_preferences")
def update_chart_preferences(
        query_id: int,
        body: ChartPreferenceRequest,
        db: Session = Depends(get_db),
):
    """Save a chart type preference for a specific chart on a query."""
    q = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not q:
        raise HTTPException(status_code=404, detail=f"Scheduled query with ID {query_id} not found")

    config = dict(q.grafana_metric_config or {})
    prefs = dict(config.get("chart_preferences", {}))
    prefs[body.chart_key] = body.chart_type
    config["chart_preferences"] = prefs
    q.grafana_metric_config = config
    db.commit()
    return JSONResponse(content={"chart_preferences": prefs})


@api_router.get("/query/{query_id}/chart-preferences", name="get_chart_preferences")
def get_chart_preferences(
        query_id: int,
        db: Session = Depends(get_db),
):
    """Return saved chart type preferences for a query."""
    q = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not q:
        raise HTTPException(status_code=404, detail=f"Scheduled query with ID {query_id} not found")

    config = q.grafana_metric_config or {}
    return JSONResponse(content=config.get("chart_preferences", {}))


@api_router.get("/queries/sparklines", name="get_queries_sparklines")
def get_queries_sparklines(
        range: str = Query("24h", description="Time range: 24h, 7d, 30d"),
        db: Session = Depends(get_db)
):
    """
    Return sparkline data for all queries in one call.
    For counter/metric render_type: extracts scalar values from results.
    For table/raw: returns durations only.
    """
    from datetime import datetime, timedelta, timezone

    # Parse time range
    now = datetime.now(tz=timezone.utc)
    range_map = {"24h": timedelta(hours=24), "7d": timedelta(days=7), "30d": timedelta(days=30)}
    delta = range_map.get(range, timedelta(hours=24))
    since = now - delta

    # Get all queries
    queries = db.query(ScheduledQuery).all()

    # Get all history records in range, ordered by time
    history = (
        db.query(ScheduledQueryResultHistory)
        .filter(ScheduledQueryResultHistory.executed_at >= since)
        .order_by(ScheduledQueryResultHistory.executed_at.asc())
        .all()
    )

    # Group by query_id
    by_query: dict[int, list] = {}
    for h in history:
        by_query.setdefault(h.scheduled_query_id, []).append(h)

    # Build query info map for render_type lookup
    query_map = {q.id: q for q in queries}

    result = {}
    for query_id, records in by_query.items():
        q = query_map.get(query_id)
        render_type = q.render_type if q else "auto"

        timestamps = []
        durations = []
        statuses = []
        values = []

        for r in records:
            timestamps.append(r.executed_at.strftime('%Y-%m-%d %H:%M:%S') if r.executed_at else None)
            durations.append(r.duration_ms)
            statuses.append(r.status)

            # Extract scalar value for counter/metric queries
            if render_type in ("counter", "metric") and r.result:
                val = _extract_scalar(r.result)
                values.append(val)

        entry = {
            "timestamps": timestamps,
            "durations": durations,
            "statuses": statuses,
        }
        if render_type in ("counter", "metric") and values:
            entry["values"] = values

        result[str(query_id)] = entry

    return JSONResponse(content=result)

@api_router.get("/run-now/{query_id}")
async def run_scheduled_query_now(
        query_id: int,
        request: Request,
        db: Session = Depends(get_db)
):
    """
    Run a scheduled query immediately and redirect back to the queries list.
    """
    # Check if the query exists
    query = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not query:
        raise HTTPException(status_code=404, detail=f"Scheduled query with ID {query_id} not found")

    # Execute the query asynchronously
    await execute_scheduled_query(query_id)

    # Redirect back to the scheduled queries list
    return RedirectResponse(url=str(request.url_for("read_scheduled_queries")), status_code=303)


@api_router.get("/execution-history/{query_id}", name="get_execution_history")
def get_execution_history(
        query_id: int,
        page: int = Query(1, ge=1, description="Page number (1-based)"),
        limit: int = Query(50, ge=1, le=200, description="Number of records per page"),
        status_filter: str = Query("all", description="Filter by status: all, success, failed, timeout"),
        db: Session = Depends(get_db)
):
    """
    Get execution history for a specific scheduled query with pagination and filtering.
    """
    # Verify the query exists
    scheduled_query = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not scheduled_query:
        return JSONResponse(
            status_code=404,
            content={"error": f"Scheduled query with ID {query_id} not found"}
        )

    # Build the base query
    history_query = db.query(ScheduledQueryResultHistory).filter(
        ScheduledQueryResultHistory.scheduled_query_id == query_id
    )

    # Apply status filter if specified
    if status_filter != "all":
        history_query = history_query.filter(ScheduledQueryResultHistory.status == status_filter)

    # Order by executed_at descending (most recent first) and apply pagination
    history_query = history_query.order_by(desc(ScheduledQueryResultHistory.executed_at))

    # Get total count for pagination info
    total_count = history_query.count()

    # Apply pagination
    offset = (page - 1) * limit
    history_records = history_query.offset(offset).limit(limit).all()

    # Convert to JSON-serializable format
    history_data = []
    for record in history_records:
        history_data.append({
            "id": record.id,
            "executed_at": record.executed_at.strftime('%Y-%m-%d %H:%M:%S') if record.executed_at else None,
            "duration_ms": record.duration_ms,
            "result": record.result,
            "parsed": _safe_parse(record.result),
            "status": record.status,
            "error_message": record.error_message,
            "grafana_metrics_snapshot": record.grafana_metrics_snapshot
        })

    # Calculate pagination info
    total_pages = (total_count + limit - 1) // limit  # Ceiling division
    has_next = page < total_pages
    has_prev = page > 1

    return JSONResponse(content={
        "data": history_data,
        "pagination": {
            "page": page,
            "limit": limit,
            "total_count": total_count,
            "total_pages": total_pages,
            "has_next": has_next,
            "has_prev": has_prev
        },
        "query_info": {
            "id": scheduled_query.id,
            "name": scheduled_query.name
        }
    })

# New endpoint: fetch scheduled query info (to replace embedded const queryData in dashboard)
@api_router.get("/scheduled-queries/{query_id}", name="get_scheduled_query_info")
def get_scheduled_query_info(
        query_id: int,
        db: Session = Depends(get_db)
):
    """
    Return details about a single scheduled query used by the dashboard UI.
    """
    q = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not q:
        return JSONResponse(status_code=404, content={"error": f"Scheduled query with ID {query_id} not found"})

    data = {
        "id": q.id,
        "name": q.name,
        "query": q.query,
        "cron_schedule": q.cron_schedule,
        "last_executed": q.last_executed.strftime('%Y-%m-%d %H:%M:%S') if q.last_executed else "Never",
        "enabled": q.enabled,
        "grafana_metric_config": q.grafana_metric_config
    }
    return JSONResponse(content=data)


@api_router.get("/query/{query_id}/chart-data", name="get_chart_data")
def get_chart_data(
        query_id: int,
        range: str = Query("24h", description="Time range: 24h, 7d, 30d, or all"),
        db: Session = Depends(get_db)
):
    """Return execution data optimized for ApexCharts."""
    from datetime import datetime, timedelta, timezone

    q = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not q:
        raise HTTPException(status_code=404, detail=f"Scheduled query with ID {query_id} not found")

    # Parse time range
    range_map = {"24h": timedelta(hours=24), "7d": timedelta(days=7), "30d": timedelta(days=30)}

    history_query = (
        db.query(ScheduledQueryResultHistory)
        .filter(ScheduledQueryResultHistory.scheduled_query_id == query_id)
    )

    if range != "all":
        now = datetime.now(tz=timezone.utc)
        delta = range_map.get(range, timedelta(hours=24))
        since = now - delta
        history_query = history_query.filter(ScheduledQueryResultHistory.executed_at >= since)

    records = history_query.order_by(ScheduledQueryResultHistory.executed_at.asc()).all()

    timestamps = []
    durations = []
    statuses = []
    values = []

    for r in records:
        timestamps.append(r.executed_at.isoformat() if r.executed_at else None)
        durations.append(r.duration_ms)
        statuses.append(r.status)

        if q.render_type in ("counter", "metric") and r.result:
            values.append(_extract_scalar(r.result))

    result = {
        "timestamps": timestamps,
        "durations": durations,
        "statuses": statuses,
        "values": values if q.render_type in ("counter", "metric") else [],
    }

    return JSONResponse(content=result)


class PreviewRequest(BaseModel):
    sql: str
    render_type: str


@api_router.post("/preview", name="preview_query")
def preview_query(
        body: PreviewRequest,
        db: Session = Depends(get_db),
):
    """Execute a SQL query in a read-only transaction and return the rendered result."""
    if not is_query_safe(body.sql):
        return JSONResponse(status_code=400, content={"error": "Query contains forbidden keywords"})

    start = time.perf_counter()
    try:
        db.execute(text("SET TRANSACTION READ ONLY"))
        db.execute(text("SET statement_timeout = '5s'"))
        result = db.execute(text(body.sql))

        if result.returns_rows:
            keys = list(result.keys())
            rows = result.fetchmany(100)
            payload = {
                "type": "rows",
                "columns": _build_column_meta(keys, rows[0] if rows else None),
                "rows": [_row_to_dict(row, keys) for row in rows],
            }
        else:
            payload = {"type": "rows_affected", "count": result.rowcount}

        duration_ms = int((time.perf_counter() - start) * 1000)
        db.rollback()
        return JSONResponse(content={
            "result": payload,
            "render_type": body.render_type,
            "duration_ms": duration_ms,
        })
    except Exception as e:
        duration_ms = int((time.perf_counter() - start) * 1000)
        db.rollback()
        error_str = str(e)
        if "canceling statement due to statement timeout" in error_str:
            return JSONResponse(status_code=408, content={"error": "Preview timed out (5s limit)"})
        return JSONResponse(status_code=400, content={"error": error_str})


def _result_summary(raw: str | None) -> str:
    """Extract a representative value from a query result string for CSV export."""
    if not raw:
        return ""
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return raw
    if isinstance(payload, dict):
        if payload.get("type") == "rows_affected":
            return str(payload.get("count", 0))
        rows = payload.get("rows", [])
        columns = payload.get("columns", [])
        if not rows:
            return ""
        if len(columns) == 1 and len(rows) == 1:
            row = rows[0]
            v = list(row.values())[0] if isinstance(row, dict) else row[0]
            return str(v)
        return f"{len(rows)} rows"
    return str(payload)


@api_router.get("/query/{query_id}/export-csv", name="export_query_csv")
def export_query_csv(
        query_id: int,
        db: Session = Depends(get_db)
):
    """Export full execution history for a scheduled query as CSV."""
    scheduled_query = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not scheduled_query:
        raise HTTPException(status_code=404, detail=f"Scheduled query with ID {query_id} not found")

    history_records = (
        db.query(ScheduledQueryResultHistory)
        .filter(ScheduledQueryResultHistory.scheduled_query_id == query_id)
        .order_by(desc(ScheduledQueryResultHistory.executed_at))
        .all()
    )

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Timestamp", "Duration (ms)", "Status", "Error", "Result Value"])

    for record in history_records:
        timestamp = record.executed_at.strftime('%Y-%m-%d %H:%M:%S') if record.executed_at else ""
        duration = str(record.duration_ms) if record.duration_ms is not None else ""
        status = record.status or ""
        error = record.error_message or ""
        result_value = _result_summary(record.result)
        writer.writerow([timestamp, duration, status, error, result_value])

    output.seek(0)
    return StreamingResponse(
        output,
        media_type="text/csv",
        headers={
            "Content-Disposition": f'attachment; filename="query_{query_id}_history.csv"'
        }
    )

