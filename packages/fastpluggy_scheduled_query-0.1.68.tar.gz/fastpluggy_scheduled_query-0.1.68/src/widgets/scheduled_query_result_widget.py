import copy
import json
from typing import Any, Dict, Optional

from fastpluggy.core.widgets import AbstractWidget
from ..models import ScheduledQuery, ScheduledQueryResultHistory


class ScheduledQueryResultWidget(AbstractWidget):
    """Display the latest scheduled query result. Render type is driven by
    ScheduledQuery.render_type (auto/table/counter/metric/raw)."""

    widget_type = "scheduled_query_result"
    template_name = "scheduled_query/widgets/scheduled_query_result.html.j2"
    category = "scheduled_query"
    description = "Display scheduled query results as a table"
    icon = "database"

    def __init__(
        self,
            db,
            id_scheduled_query: int,
        show_query_info: bool = True,
        show_execution_details: bool = True,
        max_table_rows: int = 10,
        **kwargs,
    ):
        super().__init__(**kwargs)
        if not id_scheduled_query:
            raise ValueError("id_scheduled_query is required")

        self.scheduled_query: Optional[ScheduledQuery] = (
            db.query(ScheduledQuery).filter(ScheduledQuery.id == id_scheduled_query).first()
        )
        if not self.scheduled_query:
            raise ValueError(f"ScheduledQuery with id {id_scheduled_query} not found")

        latest = (
            db.query(ScheduledQueryResultHistory)
            .filter(ScheduledQueryResultHistory.scheduled_query_id == self.scheduled_query.id)
            .order_by(ScheduledQueryResultHistory.executed_at.desc())
            .first()
        )
        self.execution_result = copy.deepcopy(latest) if latest else None

        self.show_query_info = show_query_info
        self.show_execution_details = show_execution_details
        self.max_table_rows = max_table_rows

        self.processed_result: Dict[str, Any] = {}
        self.result_type: str = "no_result"
        self.error_message: Optional[str] = None

    # --- processing ----------------------------------------------------------

    def process(self, **kwargs) -> None:
        if not self.execution_result:
            self.result_type = "no_result"
            return

        status = getattr(self.execution_result, "status", "unknown")
        self.error_message = getattr(self.execution_result, "error_message", None)
        raw = getattr(self.execution_result, "result", None)

        if status != "success" or raw is None:
            self.result_type = "error" if self.error_message else "no_result"
            return

        render_type = getattr(self.scheduled_query, 'render_type', 'auto') or 'auto'

        raw_str = str(raw).strip()
        payload = self._parse_result(raw_str)
        if payload is None:
            self.result_type = "raw"
            self.processed_result = {"raw": raw_str}
            return

        if payload.get("type") == "rows_affected":
            self.result_type = "rows_affected"
            self.processed_result = {"count": payload.get("count", 0)}
            return

        rows = payload.get("rows", [])
        columns = payload.get("columns", [])

        if render_type == "auto":
            render_type = self._auto_detect_render_type(rows, columns)

        self.result_type = render_type
        self.processed_result = {
            "columns": columns,
            "rows": rows,
            "rows_limited": rows[:self.max_table_rows],
            "total_rows": len(rows),
        }

    def _auto_detect_render_type(self, rows: list, columns: list) -> str:
        if not rows:
            return "no_result"
        if len(columns) == 1 and len(rows) == 1:
            v = list(rows[0].values())[0] if isinstance(rows[0], dict) else rows[0][0]
            return "counter" if isinstance(v, (int, float)) else "metric"
        return "table"

    def _parse_result(self, s: str) -> Optional[dict]:
        try:
            return json.loads(s)
        except (json.JSONDecodeError, TypeError):
            return None