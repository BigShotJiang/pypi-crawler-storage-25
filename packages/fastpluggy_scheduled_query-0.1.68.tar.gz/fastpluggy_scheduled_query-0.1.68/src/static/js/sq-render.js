/**
 * Shared renderer for scheduled_query result payloads.
 *
 * Single source of truth for the "Rendered" view in the history detail row
 * (query_detail.html.j2) and the Preview panel (edit_form.html.j2).
 *
 * Render type semantics (matches the form's render_type field):
 *   - "auto"    → infer from shape
 *   - "table"   → tabular view (always)
 *   - "counter" → single scalar — first row, first column rendered as big number
 *   - "metric"  → multi-value chart (multiple rows or multiple numeric columns)
 *   - "raw"     → not handled here (raw view is a separate code path)
 *
 * Payload types:
 *   - { type:"rows", columns:[{name,type}], rows:[{...}] }
 *   - { type:"command", command:"REFRESH MATERIALIZED VIEW", rowcount, notices }
 *   - { type:"rows_affected", count } (legacy)
 */
(function() {
  'use strict';

  function _empty(container, text) {
    var div = document.createElement('div');
    div.className = 'text-muted';
    div.textContent = text;
    container.appendChild(div);
  }

  function _renderCommand(container, parsed) {
    var info = document.createElement('div');
    info.className = 'alert alert-info mb-0';
    var head = document.createElement('div');
    var icon = document.createElement('i');
    icon.className = 'ti ti-terminal-2 me-2';
    head.appendChild(icon);
    var strong = document.createElement('strong');
    strong.textContent = parsed.command || 'OK';
    head.appendChild(strong);
    if (parsed.rowcount !== null && parsed.rowcount !== undefined) {
      head.appendChild(document.createTextNode(' — ' + parsed.rowcount + ' row' + (parsed.rowcount === 1 ? '' : 's') + ' affected'));
    }
    info.appendChild(head);
    if (parsed.notices && parsed.notices.length) {
      var noticesWrap = document.createElement('div');
      noticesWrap.className = 'mt-2 small';
      for (var i = 0; i < parsed.notices.length; i++) {
        var n = document.createElement('div');
        n.className = 'text-warning-emphasis';
        n.textContent = '⚠ ' + parsed.notices[i];
        noticesWrap.appendChild(n);
      }
      info.appendChild(noticesWrap);
    }
    container.appendChild(info);
  }

  function _renderCounter(container, rows, cols) {
    if (rows.length === 0 || cols.length === 0) {
      _empty(container, 'No value');
      return;
    }
    var col = cols[0];
    var val = rows[0][col.name];
    var counter = document.createElement('div');
    counter.className = 'sq-counter';
    counter.style.cssText = 'font-size:3rem;font-weight:bold;text-align:center;padding:1rem';
    counter.textContent = (val !== null && val !== undefined) ? val : '';
    container.appendChild(counter);
    var label = document.createElement('div');
    label.className = 'text-muted text-center';
    label.textContent = String(col.name).replace(/_/g, ' ');
    container.appendChild(label);
  }

  function _renderTable(container, rows, cols) {
    if (rows.length === 0) {
      _empty(container, 'No rows returned');
      return;
    }
    var colNames = cols.map(function(c) { return c.name; });
    var table = document.createElement('table');
    table.className = 'table table-striped table-sm mb-0';
    var thead = document.createElement('thead');
    var hRow = document.createElement('tr');
    for (var i = 0; i < colNames.length; i++) {
      var th = document.createElement('th');
      th.textContent = colNames[i];
      hRow.appendChild(th);
    }
    thead.appendChild(hRow);
    table.appendChild(thead);
    var tbody = document.createElement('tbody');
    var maxRows = Math.min(rows.length, 50);
    for (var r = 0; r < maxRows; r++) {
      var tr = document.createElement('tr');
      for (var c = 0; c < colNames.length; c++) {
        var td = document.createElement('td');
        var v = rows[r][colNames[c]];
        td.textContent = (v !== null && v !== undefined) ? v : '';
        tr.appendChild(td);
      }
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    var wrap = document.createElement('div');
    wrap.className = 'table-responsive';
    wrap.style.maxHeight = '300px';
    wrap.style.overflow = 'auto';
    wrap.appendChild(table);
    container.appendChild(wrap);
    if (rows.length > 50) {
      var more = document.createElement('div');
      more.className = 'text-muted small mt-1';
      more.textContent = 'Showing first 50 of ' + rows.length + ' rows';
      container.appendChild(more);
    }
  }

  function _renderMetric(container, rows, cols) {
    if (rows.length === 0 || cols.length === 0) {
      _empty(container, 'No data');
      return;
    }
    var numCols = cols.filter(function(c) {
      return c.type === 'integer' || c.type === 'float';
    });
    var catCol = null;
    for (var i = 0; i < cols.length; i++) {
      if (cols[i].type !== 'integer' && cols[i].type !== 'float') {
        catCol = cols[i];
        break;
      }
    }
    if (numCols.length === 0) {
      // Nothing chartable — fall back to a table.
      _renderTable(container, rows, cols);
      return;
    }
    if (typeof ApexCharts === 'undefined') {
      // ApexCharts not loaded — degrade to table.
      _renderTable(container, rows, cols);
      return;
    }
    var chartEl = document.createElement('div');
    chartEl.style.minHeight = '250px';
    container.appendChild(chartEl);

    var categories;
    if (catCol) {
      categories = rows.map(function(r) { return String(r[catCol.name] === null || r[catCol.name] === undefined ? '' : r[catCol.name]); });
    } else {
      categories = rows.map(function(_, idx) { return String(idx + 1); });
    }
    var series = numCols.map(function(c) {
      return { name: c.name, data: rows.map(function(r) { return r[c.name] || 0; }) };
    });

    var chart = new ApexCharts(chartEl, {
      chart: { type: 'bar', height: 240, toolbar: { show: false } },
      series: series,
      xaxis: { categories: categories, labels: { style: { fontSize: '11px' } } },
      colors: ['#206bc4', '#2fb344', '#f59f00', '#d63939', '#ae3ec9'],
      grid: { borderColor: '#e0e5ec', strokeDashArray: 3 },
      dataLabels: { enabled: false }
    });
    chart.render();
  }

  /**
   * Render a parsed query result into `container`, honoring renderType.
   * Returns the ApexCharts instance for "metric" mode (so callers can dispose), else null.
   */
  window.sqRenderResult = function(container, parsed, renderType, errorMessage) {
    container.textContent = '';

    if (!parsed) {
      _empty(container, errorMessage || 'No result');
      return null;
    }

    if (parsed.type === 'rows_affected') {
      // Legacy DML payload from older history records.
      var legacy = document.createElement('div');
      legacy.className = 'alert alert-info mb-0';
      legacy.textContent = (parsed.count || 0) + ' rows affected';
      container.appendChild(legacy);
      return null;
    }

    if (parsed.type === 'command') {
      _renderCommand(container, parsed);
      return null;
    }

    if (parsed.type !== 'rows') {
      _empty(container, 'Unknown result type');
      return null;
    }

    var rows = parsed.rows || [];
    var cols = parsed.columns || [];
    var rt = renderType || 'auto';

    if (rt === 'counter') {
      _renderCounter(container, rows, cols);
      return null;
    }

    if (rt === 'metric') {
      _renderMetric(container, rows, cols);
      return null;
    }

    // table / auto
    _renderTable(container, rows, cols);
    return null;
  };
})();
