"""Tests for crud_router and api_router endpoints."""

import json
from datetime import datetime, timedelta, timezone
from unittest.mock import patch

import pytest
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, Session

from fastpluggy.core.database import Base, get_db
from fastpluggy.core.auth import require_authentication
from fastpluggy.core.dependency import get_view_builder
from fastpluggy_plugin.scheduled_query.models import (
    ScheduledQuery,
    ScheduledQueryResultHistory,
)
from fastpluggy_plugin.scheduled_query.routers.api_router import api_router
from fastpluggy_plugin.scheduled_query.routers.crud_router import crud_router


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

_engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
Base.metadata.create_all(bind=_engine)
_SessionLocal = sessionmaker(bind=_engine)


class MockViewBuilder:
    def generate(self, request, title, widgets, context=None):
        return HTMLResponse(content=f"<html><body><h1>{title}</h1></body></html>")


@pytest.fixture
def db():
    """Provide a transactional DB session that rolls back after each test."""
    connection = _engine.connect()
    transaction = connection.begin()
    session = _SessionLocal(bind=connection)

    # Begin a nested (savepoint) so the test can call commit() without
    # actually persisting to the outer transaction.
    nested = connection.begin_nested()

    @event.listens_for(session, "after_transaction_end")
    def restart_savepoint(sess, trans):
        nonlocal nested
        if trans.nested and not trans._parent.nested:
            nested = connection.begin_nested()

    yield session

    session.close()
    transaction.rollback()
    connection.close()


@pytest.fixture
def app(db):
    _app = FastAPI()
    _app.include_router(crud_router)
    _app.include_router(api_router)

    _app.dependency_overrides[get_db] = lambda: db
    _app.dependency_overrides[require_authentication] = lambda: True
    _app.dependency_overrides[get_view_builder] = lambda: MockViewBuilder()

    return _app


@pytest.fixture
def client(app):
    return TestClient(app, follow_redirects=False)


@pytest.fixture
def sample_query(db):
    q = ScheduledQuery(
        name="Test Query",
        query="SELECT 1",
        cron_schedule="*/5 * * * *",
        enabled=True,
        render_type="counter",
    )
    db.add(q)
    db.flush()
    db.refresh(q)
    return q


@pytest.fixture
def sample_history(db, sample_query):
    now = datetime.now(timezone.utc)
    records = []
    for i in range(3):
        h = ScheduledQueryResultHistory(
            scheduled_query_id=sample_query.id,
            executed_at=now - timedelta(hours=1, minutes=i),
            duration_ms=100 + i * 50,
            status="success",
            result=json.dumps({
                "type": "rows",
                "columns": [{"name": "cnt", "type": "integer"}],
                "rows": [{"cnt": 42 + i}],
            }),
        )
        records.append(h)
        db.add(h)
    db.flush()
    for r in records:
        db.refresh(r)
    return records


# ---------------------------------------------------------------------------
# CRUD router tests
# ---------------------------------------------------------------------------


class TestCreateRoute:
    @patch("fastpluggy_plugin.scheduled_query.tasks.is_query_safe", return_value=True)
    def test_create_route(self, _mock_safe, client, db):
        response = client.post(
            "/create",
            data={
                "name": "New Query",
                "query": "SELECT count(*) FROM users",
                "cron_schedule": "*/10 * * * *",
                "enabled": "true",
                "render_type": "counter",
            },
        )
        assert response.status_code == 303
        q = db.query(ScheduledQuery).filter(ScheduledQuery.name == "New Query").first()
        assert q is not None
        assert q.cron_schedule == "*/10 * * * *"

    def test_create_route_invalid_cron(self, client):
        response = client.post(
            "/create",
            data={
                "name": "Bad Cron",
                "query": "SELECT 1",
                "cron_schedule": "not-a-cron",
                "enabled": "false",
                "render_type": "auto",
            },
        )
        assert response.status_code == 400

    @patch(
        "fastpluggy_plugin.scheduled_query.tasks.is_query_safe",
        return_value=False,
    )
    def test_create_route_unsafe_query(self, _mock_safe, client):
        response = client.post(
            "/create",
            data={
                "name": "Dangerous",
                "query": "DROP TABLE users",
                "cron_schedule": "* * * * *",
                "enabled": "false",
                "render_type": "auto",
            },
        )
        assert response.status_code == 400


# ---------------------------------------------------------------------------
# API router tests
# ---------------------------------------------------------------------------


class TestToggleEndpoint:
    def test_toggle_endpoint(self, client, sample_query, db):
        assert sample_query.enabled is True
        response = client.post(f"/api/query/{sample_query.id}/toggle")
        assert response.status_code == 200
        data = response.json()
        assert data["enabled"] is False

        # Toggle back
        response = client.post(f"/api/query/{sample_query.id}/toggle")
        assert response.status_code == 200
        assert response.json()["enabled"] is True

    def test_toggle_not_found(self, client):
        response = client.post("/api/query/9999/toggle")
        assert response.status_code == 404


class TestSparklinesEndpoint:
    def test_sparklines_endpoint(self, client, sample_query, sample_history):
        response = client.get("/api/queries/sparklines")
        assert response.status_code == 200
        data = response.json()
        key = str(sample_query.id)
        assert key in data
        entry = data[key]
        assert "timestamps" in entry
        assert "durations" in entry
        assert "statuses" in entry
        assert len(entry["timestamps"]) == 3
        # counter render_type should produce values
        assert "values" in entry

    def test_sparklines_empty(self, client):
        response = client.get("/api/queries/sparklines")
        assert response.status_code == 200
        assert response.json() == {}


class TestChartDataEndpoint:
    def test_chart_data_endpoint(self, client, sample_query, sample_history):
        response = client.get(f"/api/query/{sample_query.id}/chart-data?range=all")
        assert response.status_code == 200
        data = response.json()
        assert "timestamps" in data
        assert "durations" in data
        assert "statuses" in data
        assert "values" in data
        assert len(data["timestamps"]) == 3

    def test_chart_data_not_found(self, client):
        response = client.get("/api/query/9999/chart-data")
        assert response.status_code == 404


class TestPreviewEndpoint:
    def test_preview_endpoint(self):
        """Preview executes SET TRANSACTION READ ONLY (PostgreSQL-specific).

        We override get_db with a mock session so the test doesn't depend on
        a real PostgreSQL database.
        """
        from unittest.mock import MagicMock

        mock_db = MagicMock()
        result = MagicMock()
        result.returns_rows = True
        result.keys.return_value = ["val"]
        result.fetchmany.return_value = [(1,)]
        # Only the third execute call (the actual SQL) returns a result;
        # the first two are SET TRANSACTION and SET statement_timeout.
        mock_db.execute.side_effect = [None, None, result]

        _app = FastAPI()
        _app.include_router(api_router)
        _app.dependency_overrides[get_db] = lambda: mock_db
        _app.dependency_overrides[require_authentication] = lambda: True

        with patch("fastpluggy_plugin.scheduled_query.routers.api_router.is_query_safe", return_value=True):
            _client = TestClient(_app, follow_redirects=False)
            response = _client.post(
                "/api/preview",
                json={"sql": "SELECT 1 AS val", "render_type": "counter"},
            )

        assert response.status_code == 200
        data = response.json()
        assert "result" in data
        assert "duration_ms" in data
        assert data["result"]["type"] == "rows"

    @patch(
        "fastpluggy_plugin.scheduled_query.routers.api_router.is_query_safe",
        return_value=False,
    )
    def test_preview_unsafe(self, _mock_safe, client):
        response = client.post(
            "/api/preview",
            json={"sql": "DROP TABLE users", "render_type": "auto"},
        )
        assert response.status_code == 400
        assert "forbidden" in response.json()["error"].lower()


class TestDetailPage:
    def test_detail_page(self, client, sample_query):
        response = client.get(f"/query/{sample_query.id}")
        assert response.status_code == 200

    def test_detail_page_not_found(self, client):
        response = client.get("/query/9999")
        assert response.status_code == 404


class TestExportCsv:
    def test_export_csv(self, client, sample_query, sample_history):
        response = client.get(f"/api/query/{sample_query.id}/export-csv")
        assert response.status_code == 200
        assert "text/csv" in response.headers["content-type"]
        content = response.text
        lines = content.strip().split("\n")
        # Header + 3 data rows
        assert len(lines) == 4
        assert "Timestamp" in lines[0]
        assert "Duration (ms)" in lines[0]

    def test_export_csv_not_found(self, client):
        response = client.get("/api/query/9999/export-csv")
        assert response.status_code == 404


class TestChartPreferences:
    def test_save_preference(self, client, sample_query, db):
        """Save a chart type preference and verify it persists."""
        response = client.patch(
            f"/api/query/{sample_query.id}/chart-preferences",
            json={"chart_key": "timeline", "chart_type": "bar"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["chart_preferences"]["timeline"] == "bar"

        # Verify it persisted in the DB
        db.refresh(sample_query)
        config = sample_query.grafana_metric_config
        assert config["chart_preferences"]["timeline"] == "bar"

    def test_read_preferences(self, client, sample_query, db):
        """GET returns saved preferences."""
        # Save first
        client.patch(
            f"/api/query/{sample_query.id}/chart-preferences",
            json={"chart_key": "donut", "chart_type": "pie"},
        )
        # Read back
        response = client.get(f"/api/query/{sample_query.id}/chart-preferences")
        assert response.status_code == 200
        assert response.json() == {"donut": "pie"}

    def test_read_preferences_empty(self, client, sample_query):
        """GET returns empty dict when no preferences saved."""
        response = client.get(f"/api/query/{sample_query.id}/chart-preferences")
        assert response.status_code == 200
        assert response.json() == {}

    def test_invalid_chart_type(self, client, sample_query):
        """Invalid chart_type is rejected with 422."""
        response = client.patch(
            f"/api/query/{sample_query.id}/chart-preferences",
            json={"chart_key": "timeline", "chart_type": "scatter"},
        )
        assert response.status_code == 422

    def test_invalid_chart_key(self, client, sample_query):
        """Invalid chart_key is rejected with 422."""
        response = client.patch(
            f"/api/query/{sample_query.id}/chart-preferences",
            json={"chart_key": "unknown", "chart_type": "bar"},
        )
        assert response.status_code == 422

    def test_null_grafana_metric_config(self, client, sample_query, db):
        """First write creates the JSON when grafana_metric_config is null."""
        assert sample_query.grafana_metric_config is None
        response = client.patch(
            f"/api/query/{sample_query.id}/chart-preferences",
            json={"chart_key": "trend", "chart_type": "line"},
        )
        assert response.status_code == 200
        db.refresh(sample_query)
        assert sample_query.grafana_metric_config == {
            "chart_preferences": {"trend": "line"}
        }

    def test_preserves_existing_metric_config(self, client, db):
        """Chart preferences don't overwrite existing metric_name config."""
        q = ScheduledQuery(
            name="Metric Query",
            query="SELECT count(*) FROM events",
            cron_schedule="*/5 * * * *",
            enabled=True,
            render_type="counter",
            grafana_metric_config={"metric_name": "event_count"},
        )
        db.add(q)
        db.flush()
        db.refresh(q)

        response = client.patch(
            f"/api/query/{q.id}/chart-preferences",
            json={"chart_key": "timeline", "chart_type": "area"},
        )
        assert response.status_code == 200

        db.refresh(q)
        config = q.grafana_metric_config
        assert config["metric_name"] == "event_count"
        assert config["chart_preferences"]["timeline"] == "area"

    def test_update_existing_preference(self, client, sample_query, db):
        """Updating a preference for the same chart_key overwrites the old value."""
        client.patch(
            f"/api/query/{sample_query.id}/chart-preferences",
            json={"chart_key": "timeline", "chart_type": "bar"},
        )
        client.patch(
            f"/api/query/{sample_query.id}/chart-preferences",
            json={"chart_key": "timeline", "chart_type": "line"},
        )
        db.refresh(sample_query)
        assert sample_query.grafana_metric_config["chart_preferences"]["timeline"] == "line"

    def test_not_found(self, client):
        """PATCH and GET return 404 for non-existent query."""
        response = client.patch(
            "/api/query/9999/chart-preferences",
            json={"chart_key": "timeline", "chart_type": "bar"},
        )
        assert response.status_code == 404

        response = client.get("/api/query/9999/chart-preferences")
        assert response.status_code == 404
