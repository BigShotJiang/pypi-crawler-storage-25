"""Tests for metrics.py — _extract_metric_value, update_prometheus_metric, _slugify, record_execution."""

import json
from unittest.mock import MagicMock, patch

from fastpluggy_plugin.scheduled_query.metrics import (
    _extract_metric_value,
    _slugify,
    record_execution,
    update_prometheus_metric,
    execution_counters,
    per_query_last_duration,
    per_query_avg_duration,
    prometheus_gauges,
)


# ---------------------------------------------------------------------------
# _extract_metric_value
# ---------------------------------------------------------------------------

class TestExtractMetricValue:
    def test_single_row_single_col(self):
        payload = json.dumps({"rows": [{"count": 42}]})
        assert _extract_metric_value(payload) == 42.0

    def test_single_row_float(self):
        payload = json.dumps({"rows": [{"avg": 3.14}]})
        assert _extract_metric_value(payload) == 3.14

    def test_empty_rows(self):
        payload = json.dumps({"rows": []})
        assert _extract_metric_value(payload) is None

    def test_no_rows_key(self):
        payload = json.dumps({"type": "rows_affected", "count": 5})
        assert _extract_metric_value(payload) is None

    def test_invalid_json(self):
        assert _extract_metric_value("not json") is None

    def test_none_input(self):
        assert _extract_metric_value(None) is None

    def test_empty_string(self):
        assert _extract_metric_value("") is None

    def test_non_numeric_value(self):
        payload = json.dumps({"rows": [{"name": "alice"}]})
        assert _extract_metric_value(payload) is None


# ---------------------------------------------------------------------------
# update_prometheus_metric
# ---------------------------------------------------------------------------

class TestUpdatePrometheusMetric:
    def setup_method(self):
        # Clean up any gauges from previous tests
        prometheus_gauges.clear()

    def test_no_config_does_nothing(self):
        sq = MagicMock()
        sq.grafana_metric_config = None
        update_prometheus_metric(sq)
        # No error, no gauge created
        assert len(prometheus_gauges) == 0

    @patch("fastpluggy_plugin.scheduled_query.metrics.Gauge")
    def test_creates_gauge_and_sets_value(self, mock_gauge_cls):
        gauge_instance = MagicMock()
        mock_gauge_cls.return_value = gauge_instance

        sq = MagicMock()
        sq.id = 1
        sq.grafana_metric_config = {"metric_name": "test_metric"}
        sq.last_result = json.dumps({"rows": [{"count": 99}]})

        update_prometheus_metric(sq)

        mock_gauge_cls.assert_called_once()
        gauge_instance.set.assert_called_once_with(99.0)
        assert "test_metric" in prometheus_gauges

    @patch("fastpluggy_plugin.scheduled_query.metrics.Gauge")
    def test_reuses_existing_gauge(self, mock_gauge_cls):
        existing_gauge = MagicMock()
        prometheus_gauges["reuse_metric"] = existing_gauge

        sq = MagicMock()
        sq.id = 1
        sq.grafana_metric_config = {"metric_name": "reuse_metric"}
        sq.last_result = json.dumps({"rows": [{"val": 7}]})

        update_prometheus_metric(sq)

        # Should NOT create a new gauge
        mock_gauge_cls.assert_not_called()
        existing_gauge.set.assert_called_once_with(7.0)

    def test_no_extractable_value_logs_warning(self):
        sq = MagicMock()
        sq.id = 1
        sq.grafana_metric_config = {"metric_name": "empty_metric"}
        sq.last_result = json.dumps({"rows": []})

        # Should not raise
        update_prometheus_metric(sq)
        assert "empty_metric" not in prometheus_gauges


# ---------------------------------------------------------------------------
# _slugify
# ---------------------------------------------------------------------------

class TestSlugify:
    def test_simple_name(self):
        assert _slugify("My Query") == "my_query"

    def test_special_chars(self):
        assert _slugify("CPU % Usage (prod)") == "cpu_usage_prod"

    def test_already_clean(self):
        assert _slugify("daily_report") == "daily_report"

    def test_leading_trailing_underscores(self):
        assert _slugify("__test__") == "test"

    def test_consecutive_non_alnum(self):
        assert _slugify("a---b___c") == "a_b_c"

    def test_empty_string(self):
        assert _slugify("") == ""

    def test_unicode(self):
        assert _slugify("café latté") == "caf_latt"


# ---------------------------------------------------------------------------
# record_execution
# ---------------------------------------------------------------------------

class TestRecordExecution:
    def setup_method(self):
        execution_counters["executions_total"] = 0
        execution_counters["successes_total"] = 0
        execution_counters["failures_total"] = 0
        execution_counters["timeouts_total"] = 0
        per_query_last_duration.clear()
        per_query_avg_duration.clear()

    def test_success_increments_counters(self):
        record_execution("My Query", "success", 150)
        assert execution_counters["executions_total"] == 1
        assert execution_counters["successes_total"] == 1
        assert execution_counters["failures_total"] == 0

    def test_failure_increments_counters(self):
        record_execution("My Query", "failed")
        assert execution_counters["executions_total"] == 1
        assert execution_counters["failures_total"] == 1

    def test_timeout_increments_counters(self):
        record_execution("My Query", "timeout", 5000)
        assert execution_counters["timeouts_total"] == 1

    def test_duration_tracked_per_query(self):
        record_execution("Daily Report", "success", 200)
        assert per_query_last_duration["daily_report"] == 200.0

    def test_avg_duration_accumulates(self):
        record_execution("Q1", "success", 100)
        record_execution("Q1", "success", 300)
        total, count = per_query_avg_duration["q1"]
        assert total == 400.0
        assert count == 2

    def test_no_duration_skips_per_query(self):
        record_execution("Q1", "failed")
        assert "q1" not in per_query_last_duration

    def test_multiple_queries(self):
        record_execution("Alpha", "success", 100)
        record_execution("Beta", "success", 200)
        assert execution_counters["executions_total"] == 2
        assert "alpha" in per_query_last_duration
        assert "beta" in per_query_last_duration
