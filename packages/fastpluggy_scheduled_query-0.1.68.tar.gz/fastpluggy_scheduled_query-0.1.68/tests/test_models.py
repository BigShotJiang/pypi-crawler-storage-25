"""Basic model and config tests."""

from unittest.mock import patch

from fastpluggy_plugin.scheduled_query.models import (
    ScheduledQuery,
    ScheduledQueryResultHistory,
)
from fastpluggy_plugin.scheduled_query.config import ScheduledQuerySettings


# ---------------------------------------------------------------------------
# ScheduledQuery model
# ---------------------------------------------------------------------------

class TestScheduledQueryModel:
    def test_tablename(self):
        assert ScheduledQuery.__tablename__ == "fp_scheduled_queries"

    def test_repr(self):
        q = ScheduledQuery(
            name="test",
            query="SELECT 1",
            cron_schedule="* * * * *",
            enabled=True,
        )
        r = repr(q)
        assert "ScheduledQuery" in r
        assert "name='test'" in r
        assert "enabled=True" in r
        assert "render_type=" in r
        assert "cron='* * * * *'" in r


# ---------------------------------------------------------------------------
# ScheduledQueryResultHistory model
# ---------------------------------------------------------------------------

class TestHistoryModel:
    def test_tablename(self):
        assert ScheduledQueryResultHistory.__tablename__ == "fp_scheduled_query_results"

    def test_repr(self):
        h = ScheduledQueryResultHistory(
            scheduled_query_id=1,
            duration_ms=100,
            status="success",
        )
        r = repr(h)
        assert "ScheduledQueryResultHistory" in r
        assert "status=success" in r


# ---------------------------------------------------------------------------
# ScheduledQuerySettings defaults
# ---------------------------------------------------------------------------

class TestSettings:
    @patch("fastpluggy_plugin.scheduled_query.config.BaseDatabaseSettings.__init__", return_value=None)
    def test_defaults(self, _mock_init):
        s = ScheduledQuerySettings.__new__(ScheduledQuerySettings)
        # Check class-level defaults
        assert ScheduledQuerySettings.model_fields["interval"].default == 30
        assert ScheduledQuerySettings.model_fields["enable_history"].default is True
        assert ScheduledQuerySettings.model_fields["prometheus_enabled"].default is True
        assert "drop" in ScheduledQuerySettings.model_fields["forbidden_keywords"].default
