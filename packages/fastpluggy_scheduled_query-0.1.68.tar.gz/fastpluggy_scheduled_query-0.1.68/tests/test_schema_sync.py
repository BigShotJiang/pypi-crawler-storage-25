"""Test in-plugin schema sync helper (_ensure_model_columns)."""

from sqlalchemy import Column, Integer, MetaData, Table, Text, create_engine, inspect, text
from sqlalchemy.orm import sessionmaker
from unittest.mock import patch

from fastpluggy_plugin.scheduled_query.plugin import _ensure_model_columns
from fastpluggy_plugin.scheduled_query.models import ScheduledQuery


class TestEnsureModelColumns:
    def test_adds_missing_column_to_existing_table(self):
        """Pre-existing table without query_timeout gets the column added."""
        engine = create_engine("sqlite:///:memory:")

        # Build the legacy table (without query_timeout) directly
        meta = MetaData()
        Table(
            "fp_scheduled_queries",
            meta,
            Column("id", Integer, primary_key=True),
            Column("name", Text, nullable=False),
            Column("query", Text, nullable=False),
            Column("cron_schedule", Text, nullable=False),
        )
        meta.create_all(engine)

        # Sanity check: query_timeout absent before sync
        cols_before = {c["name"] for c in inspect(engine).get_columns("fp_scheduled_queries")}
        assert "query_timeout" not in cols_before

        # Patch session_scope to use this engine
        SessionLocal = sessionmaker(bind=engine)

        from contextlib import contextmanager

        @contextmanager
        def fake_scope():
            db = SessionLocal()
            try:
                yield db
                db.commit()
            finally:
                db.close()

        with patch("fastpluggy_plugin.scheduled_query.plugin.session_scope", fake_scope):
            _ensure_model_columns(ScheduledQuery)

        cols_after = {c["name"] for c in inspect(engine).get_columns("fp_scheduled_queries")}
        assert "query_timeout" in cols_after

    def test_noop_on_missing_table(self):
        """If the table doesn't exist yet, helper is a no-op (no error)."""
        engine = create_engine("sqlite:///:memory:")
        SessionLocal = sessionmaker(bind=engine)

        from contextlib import contextmanager

        @contextmanager
        def fake_scope():
            db = SessionLocal()
            try:
                yield db
                db.commit()
            finally:
                db.close()

        with patch("fastpluggy_plugin.scheduled_query.plugin.session_scope", fake_scope):
            _ensure_model_columns(ScheduledQuery)  # should not raise

    def test_idempotent_when_all_columns_present(self):
        """Running helper twice on a fully-synced table is a no-op."""
        engine = create_engine("sqlite:///:memory:")
        ScheduledQuery.__table__.create(bind=engine, checkfirst=True)
        SessionLocal = sessionmaker(bind=engine)

        from contextlib import contextmanager

        @contextmanager
        def fake_scope():
            db = SessionLocal()
            try:
                yield db
                db.commit()
            finally:
                db.close()

        with patch("fastpluggy_plugin.scheduled_query.plugin.session_scope", fake_scope):
            _ensure_model_columns(ScheduledQuery)
            _ensure_model_columns(ScheduledQuery)  # second call must not error
