#!/usr/bin/env python3
"""
BytePlus SeeDANCE 2.0 视频生成测试脚本
支持模型: doubao-seedance-2-0-260128 / doubao-seedance-2-0-fast-260128

直接运行: python tests/byteplus/test_seedance_v2.py
"""

import asyncio
import logging
import os

os.environ['MODEL_MANAGER_SERVER_GRPC_USE_TLS'] = "true"
os.environ['MODEL_MANAGER_SERVER_ADDRESS'] = os.getenv('MODEL_MANAGER_SERVER_ADDRESS', 'model-manager-server-grpc-469996334172.asia-northeast1.run.app')
os.environ['MODEL_MANAGER_SERVER_JWT_SECRET_KEY'] = os.getenv('MODEL_MANAGER_SERVER_JWT_SECRET_KEY',
                                                              'model-manager-server-jwt-key')

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

from tamar_model_client import TamarModelClient, AsyncTamarModelClient
from tamar_model_client.schemas import ModelRequest, UserContext
from tamar_model_client.schemas.inputs.byteplus import BytePlusSeeDANCEInput, ContentItem
from tamar_model_client.enums import ProviderType, InvokeType, Channel

# 测试用的图片/视频/音频 URL（替换为实际可用的地址）
TEST_IMAGE_URL = "https://storage.googleapis.com/files.tamaredge.top/omnihuman/image%201.png"
TEST_VIDEO_URL = "https://storage.googleapis.com/files.tamaredge.top/test/sample_video.mp4"
TEST_AUDIO_URL = "https://storage.googleapis.com/files.tamaredge.top/test/sample_audio.mp3"

USER_CONTEXT = UserContext(
    user_id="test_user",
    org_id="test_org",
    client_type="test_client"
)


def test_seedance_v2_text_to_video():
    """测试 Seedance 2.0 文生视频"""
    print("\n" + "=" * 60)
    print("测试 Seedance 2.0 Text-to-Video（文本生成视频）")
    print("=" * 60)

    try:
        client = TamarModelClient()

        request = ModelRequest(
            provider=ProviderType.DOUBAO,
            channel=Channel.SEEDANCE,
            invoke_type=InvokeType.VIDEO_GENERATION,
            model="doubao-seedance-2-0-260128",
            content=[
                {
                    "type": "text",
                    "text": "A serene landscape with mountains and a lake at sunset, cinematic lighting"
                }
            ],
            duration=5,
            ratio="16:9",
            resolution="720p",
            generate_audio=True,
            enable_async_task=True,
            user_context=USER_CONTEXT
        )

        print("发送 Seedance 2.0 Text-to-Video 请求...")
        response = client.invoke(request, timeout=18000.0)
        print(f"响应: {response}")
        return True

    except Exception as e:
        print(f"异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_seedance_v2_fast_text_to_video():
    """测试 Seedance 2.0 Fast 文生视频"""
    print("\n" + "=" * 60)
    print("测试 Seedance 2.0 Fast Text-to-Video（快速文本生成视频）")
    print("=" * 60)

    try:
        client = TamarModelClient()

        request = ModelRequest(
            provider=ProviderType.BYTEPLUS,
            channel=Channel.SEEDANCE,
            invoke_type=InvokeType.VIDEO_GENERATION,
            model="doubao-seedance-2-0-fast-260128",
            content=[
                {
                    "type": "text",
                    "text": "A futuristic city at night with neon lights and flying cars"
                }
            ],
            duration=6,
            ratio="16:9",
            resolution="720p",
            generate_audio=True,
            enable_async_task=True,
            user_context=USER_CONTEXT
        )

        print("发送 Seedance 2.0 Fast Text-to-Video 请求...")
        response = client.invoke(request, timeout=18000.0)
        print(f"响应: {response}")
        return True

    except Exception as e:
        print(f"异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_seedance_v2_image_to_video_first_frame():
    """测试 Seedance 2.0 图生视频-首帧"""
    print("\n" + "=" * 60)
    print("测试 Seedance 2.0 Image-to-Video（首帧生视频）")
    print("=" * 60)

    try:
        client = TamarModelClient()

        request = ModelRequest(
            provider=ProviderType.BYTEPLUS,
            channel=Channel.SEEDANCE,
            invoke_type=InvokeType.VIDEO_GENERATION,
            model="doubao-seedance-2-0-260128",
            content=[
                {
                    "type": "text",
                    "text": "Make the character walk forward slowly"
                },
                {
                    "type": "image_url",
                    "image_url": {"url": TEST_IMAGE_URL},
                    "role": "first_frame"
                }
            ],
            duration=8,
            ratio="adaptive",
            resolution="720p",
            enable_async_task=True,
            user_context=USER_CONTEXT
        )

        print("发送首帧生视频请求...")
        response = client.invoke(request, timeout=18000.0)
        print(f"响应: {response}")
        return True

    except Exception as e:
        print(f"异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_seedance_v2_reference_video():
    """测试 Seedance 2.0 参考视频生视频"""
    print("\n" + "=" * 60)
    print("测试 Seedance 2.0 参考视频生视频（多模态参考）")
    print("=" * 60)

    try:
        client = TamarModelClient()

        request = ModelRequest(
            provider=ProviderType.BYTEPLUS,
            channel=Channel.SEEDANCE,
            invoke_type=InvokeType.VIDEO_GENERATION,
            model="doubao-seedance-2-0-260128",
            content=[
                {
                    "type": "text",
                    "text": "Generate a similar video with different color palette"
                },
                {
                    "type": "image_url",
                    "image_url": {"url": TEST_IMAGE_URL},
                    "role": "reference_image"
                },
                {
                    "type": "video_url",
                    "video_url": {"url": TEST_VIDEO_URL},
                    "role": "reference_video"
                }
            ],
            duration=5,
            resolution="720p",
            enable_async_task=True,
            user_context=USER_CONTEXT
        )

        print("发送参考视频生视频请求...")
        response = client.invoke(request, timeout=18000.0)
        print(f"响应: {response}")
        return True

    except Exception as e:
        print(f"异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_seedance_v2_reference_audio():
    """测试 Seedance 2.0 带参考音频的视频生成"""
    print("\n" + "=" * 60)
    print("测试 Seedance 2.0 参考音频+图片生视频")
    print("=" * 60)

    try:
        client = TamarModelClient()

        request = ModelRequest(
            provider=ProviderType.BYTEPLUS,
            channel=Channel.SEEDANCE,
            invoke_type=InvokeType.VIDEO_GENERATION,
            model="doubao-seedance-2-0-260128",
            content=[
                {
                    "type": "text",
                    "text": "A person speaking in a conference room"
                },
                {
                    "type": "image_url",
                    "image_url": {"url": TEST_IMAGE_URL},
                    "role": "reference_image"
                },
                {
                    "type": "audio_url",
                    "audio_url": {"url": TEST_AUDIO_URL},
                    "role": "reference_audio"
                }
            ],
            duration=5,
            resolution="720p",
            enable_async_task=True,
            user_context=USER_CONTEXT
        )

        print("发送参考音频+图片生视频请求...")
        response = client.invoke(request, timeout=18000.0)
        print(f"响应: {response}")
        return True

    except Exception as e:
        print(f"异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_seedance_v2_web_search():
    """测试 Seedance 2.0 联网搜索文生视频"""
    print("\n" + "=" * 60)
    print("测试 Seedance 2.0 联网搜索文生视频")
    print("=" * 60)

    try:
        client = TamarModelClient()

        request = ModelRequest(
            provider=ProviderType.BYTEPLUS,
            channel=Channel.SEEDANCE,
            invoke_type=InvokeType.VIDEO_GENERATION,
            model="doubao-seedance-2-0-260128",
            content=[
                {
                    "type": "text",
                    "text": "Latest SpaceX rocket launch highlights"
                }
            ],
            tools=[{"type": "web_search"}],
            duration=8,
            ratio="16:9",
            resolution="720p",
            enable_async_task=True,
            user_context=USER_CONTEXT
        )

        print("发送联网搜索文生视频请求...")
        response = client.invoke(request, timeout=18000.0)
        print(f"响应: {response}")
        return True

    except Exception as e:
        print(f"异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_seedance_v2_return_last_frame():
    """测试 Seedance 2.0 返回最后一帧"""
    print("\n" + "=" * 60)
    print("测试 Seedance 2.0 返回最后一帧（用于视频续接）")
    print("=" * 60)

    try:
        client = TamarModelClient()

        request = ModelRequest(
            provider=ProviderType.BYTEPLUS,
            channel=Channel.SEEDANCE,
            invoke_type=InvokeType.VIDEO_GENERATION,
            model="doubao-seedance-2-0-260128",
            content=[
                {
                    "type": "text",
                    "text": "A cat playing with a ball of yarn"
                }
            ],
            duration=5,
            ratio="16:9",
            resolution="720p",
            return_last_frame=True,
            enable_async_task=True,
            user_context=USER_CONTEXT
        )

        print("发送请求（return_last_frame=True）...")
        response = client.invoke(request, timeout=18000.0)
        print(f"响应: {response}")
        return True

    except Exception as e:
        print(f"异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


async def test_seedance_v2_async():
    """测试异步客户端 Seedance 2.0 视频生成"""
    print("\n" + "=" * 60)
    print("测试异步客户端 Seedance 2.0 视频生成")
    print("=" * 60)

    try:
        async with AsyncTamarModelClient() as client:
            res = await client.batch_get_task_status(["d7cc0ba9-0cff-41b0-b1ec-08273a9d8222"])
            print(res.model_dump_json())
            return True

            request = ModelRequest(
                provider=ProviderType.DOUBAO,
                channel=Channel.SEEDANCE,
                invoke_type=InvokeType.VIDEO_GENERATION,
                model="doubao-seedance-2-0-260128",
                content=[
                    {
                        "type": "image_url",
                        "image_url": {"url": "asset://asset-20260324112444-zpmsn"},
                        "role": "reference_image"
                    },
                    {
                        "type": "text",
                        "text": """
场景】工业摄影棚，真实电影拍摄现场，冷色工业灯光，略有烟尘颗粒，真实电影质感

【镜头】手持摄影 + 缓慢推进（handheld cinematic push-in）

─────────────────────
🎞️【0–3秒｜进入状态】

摄影机轻微晃动向前推进
导演正在盯着镜头构图，眉头紧锁
他手已经抬起，准备指挥
女孩站在旁边，快速调整手里的场记板位置
后方有人走动，搬设备

─────────────────────
🎞️【3–6秒｜动作爆发点①】

导演突然伸手向前指，动作果断
同时身体微微前倾
嘴巴开合（像在说：“那里不对”）

女孩被带动，立刻顺着方向看过去
手上的场记板轻微晃动

摄影机轻微跟随这个动作向前推进

─────────────────────
🎞️【6–10秒｜持续互动】

导演保持指向，同时连续做两个小幅度调整动作（手指微移动）
头部轻微偏移，重新确认构图

女孩往前小半步（非常轻）
眼神来回：导演 → 画面前方

后景有工作人员快速穿过画面边缘（制造真实节奏）
灯光轻微闪动

─────────────────────
🎞️【10–13秒｜动作变化点②】

导演慢慢收回手
用另一只手在空中比划一个构图框（像摄影指导）

女孩稍微点头，手握紧场记板

摄影机继续推进，画面更压迫

─────────────────────
🎞️【13–15秒｜收住但留张力】

导演停住动作，直视前方（压迫感）

女孩短暂停顿，轻微吸气

背景运动减弱
镜头稳定下来

─────────────────────

【风格】cinematic, film production set, ultra realistic, natural human motion
【运动要求】smooth motion, continuous action flow, no jitter, no frozen frames
【细节】natural body mechanics, realistic inertia, micro delays between actions
【时长】15秒
【帧率】24fps
"""
                    }
                ],
                duration=15,
                ratio="16:9",
                resolution="720p",
                enable_async_task=True,
                user_context=USER_CONTEXT
            )

            print("发送异步 Seedance 2.0 视频生成请求...")
            response = await client.invoke(request, timeout=18000.0)
            print(response.model_dump_json())
            print(f"响应: {response}")
            return True

    except Exception as e:
        print(f"异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


async def main():
    """主函数"""
    print("\n" + "=" * 60)
    print("BytePlus SeeDANCE 2.0 视频生成测试套件")
    print("支持模型: doubao-seedance-2-0-260128 / doubao-seedance-2-0-fast-260128")
    print("=" * 60)

    results = []

    # 同步测试
    # results.append(("2.0 Text-to-Video", test_seedance_v2_text_to_video()))
    # results.append(("2.0 Fast Text-to-Video", test_seedance_v2_fast_text_to_video()))
    # results.append(("2.0 首帧生视频", test_seedance_v2_image_to_video_first_frame()))
    # results.append(("2.0 参考视频生视频", test_seedance_v2_reference_video()))
    # results.append(("2.0 参考音频+图片生视频", test_seedance_v2_reference_audio()))
    # results.append(("2.0 联网搜索文生视频", test_seedance_v2_web_search()))
    # results.append(("2.0 返回最后一帧", test_seedance_v2_return_last_frame()))

    # 异步测试
    results.append(("2.0 异步客户端视频生成", await test_seedance_v2_async()))

    # 统计结果
    print("\n" + "=" * 60)
    print("测试结果汇总")
    print("=" * 60)

    success_count = sum(1 for _, result in results if result)
    total_count = len(results)

    for name, result in results:
        status = "PASS" if result else "FAIL"
        print(f"  [{status}] {name}")

    print(f"\n总计: {success_count}/{total_count} 通过")
    print("=" * 60)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n测试被用户中断")
    except Exception as e:
        print(f"\n测试执行出错: {e}")
        import traceback
        traceback.print_exc()
