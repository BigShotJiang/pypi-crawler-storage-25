# goldprice

Official Python SDK for [goldprice.dev](https://goldprice.dev) — the commodity data API for prediction-market bot builders.

## Coming soon

This is a placeholder release reserving the package name. The real SDK ships shortly after the goldprice.dev launch (April 2026).

## Why goldprice.dev

- **Multi-source provenance**: Pyth + WGC + CME + Stooq, with cross-source divergence detection
- **Prediction-market view**: Polymarket + Kalshi yes-prices aggregated into a monotone CDF
- **MCP server**: Official MCP stdio bridge for Claude Desktop, Cursor, Continue
- **Commercial use clarity**: single ToS, $10/mo Basic for commercial use

See [goldprice.dev/docs](https://goldprice.dev/docs) for the REST API reference.

## Install

```bash
pip install goldprice
```

## License

MIT
