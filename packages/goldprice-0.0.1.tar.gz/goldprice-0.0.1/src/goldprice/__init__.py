"""Official Python SDK for goldprice.dev — coming soon.

This is a placeholder release reserving the package name on PyPI.
The real SDK ships shortly after the goldprice.dev launch (April 2026).

Track progress: https://github.com/michaelmustopo/goldprice-dev
"""

__version__ = "0.0.1"
