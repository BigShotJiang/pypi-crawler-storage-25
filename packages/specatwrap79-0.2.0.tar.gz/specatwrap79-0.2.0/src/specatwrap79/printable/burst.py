import polars as pl

lf: pl.LazyFrame = None
allowed_events = ["MUSCULOSKELETAL", "CARDIOVASCULAR", "CANCER", "Death"]
# {{paste:begin}}
"""
Merging close activities
"""
allowed_events = ["MUSCULOSKELETAL", "CARDIOVASCULAR", "CANCER"]
pattern = r"^(?!.*SENSORY)(?:" + "|".join(allowed_events) + ")"
clinical_events = lf.filter(pl.col("TDiag").str.contains(pattern))
remaining_events = lf.filter(~pl.col("TDiag").str.contains(pattern))

# 3. Cluster the clinical events
is_new_chain = (
    (pl.col("startTime") - pl.col("startTime").shift(1).over("case:PNR")).abs()
    >= pl.duration(days=10)
).fill_null(True)


clustered_clinical = (
    clinical_events.with_columns(
        chain_id=is_new_chain.cast(pl.Int32).cum_sum().over("case:PNR")
    )
    .group_by(["case:PNR", "chain_id"])
    .agg(
        pl.col("case:mortality").first(),
        pl.col("case:diagnosis_count").first(),
        pl.col("case:duration").first(),
        startTime=pl.col("startTime").first(),
        # Clean and concatenate
        TDiag=pl.when(pl.len() == 1)
        .then(pl.col("TDiag").first())
        .otherwise(
            pl.when(pl.len() >= 3)
            .then(pl.lit("BURST2+"))
            .otherwise(pl.lit("BURST") + pl.len().cast(pl.String))
        ),
    )
    .drop("chain_id")
)

lf = pl.concat(
    [
        clustered_clinical,
        remaining_events.select(clustered_clinical.collect_schema().names()),
    ]
).sort(["case:PNR", "startTime"])
