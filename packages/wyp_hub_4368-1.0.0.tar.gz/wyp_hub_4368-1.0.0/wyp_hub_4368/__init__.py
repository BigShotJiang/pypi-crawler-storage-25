"""Edge Spotlight: Jasper Mint"""
__version__ = "1.0.0"
