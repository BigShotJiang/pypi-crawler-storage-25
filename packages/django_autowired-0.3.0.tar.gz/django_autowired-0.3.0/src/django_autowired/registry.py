"""Injectable/provides decorators and thread-safe registration store."""

from __future__ import annotations

import threading
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from django_autowired.exceptions import DuplicateBindingError
from django_autowired.scopes import Scope


@dataclass(frozen=True)
class Registration:
    """A single ``@injectable`` registration.

    Attributes:
        cls: The concrete implementation class.
        scope: The lifecycle scope for this registration.
        bind_to: Optional interface/ABC this class implements.
    """

    cls: type
    scope: Scope
    bind_to: type | None = None

    @property
    def target(self) -> type:
        """The type key used for container binding — ``bind_to`` if set, else ``cls``."""
        return self.bind_to if self.bind_to is not None else self.cls


@dataclass(frozen=True)
class ProviderRegistration:
    """A single ``@provides`` factory registration.

    The factory is invoked by the backend according to ``scope``. Its return
    value is bound to ``bind_to``. Factory parameters (if any) are resolved
    from the container.

    Attributes:
        factory: The zero-or-more-arg function that produces the instance.
        scope: The lifecycle scope the backend applies to the factory.
        bind_to: The interface/type the factory's result binds to (required).
    """

    factory: Callable[..., Any]
    scope: Scope
    bind_to: type

    @property
    def target(self) -> type:
        """The type key used for container binding."""
        return self.bind_to


class _Registry:
    """Thread-safe store of all ``@injectable`` and ``@provides`` registrations."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._registrations: list[Registration] = []
        self._providers: list[ProviderRegistration] = []
        self._target_map: dict[type, Registration | ProviderRegistration] = {}

    def register(self, registration: Registration) -> None:
        """Add an ``@injectable`` registration, raising on duplicate targets."""
        with self._lock:
            existing = self._target_map.get(registration.target)
            if existing is not None:
                if isinstance(existing, Registration) and existing.cls is registration.cls:
                    return  # idempotent re-registration
                raise DuplicateBindingError(
                    registration.target,
                    _existing_source(existing),
                    registration.cls,
                )
            self._registrations.append(registration)
            self._target_map[registration.target] = registration

    def register_provider(self, registration: ProviderRegistration) -> None:
        """Add a ``@provides`` registration, raising on duplicate targets."""
        with self._lock:
            existing = self._target_map.get(registration.target)
            if existing is not None:
                if (
                    isinstance(existing, ProviderRegistration)
                    and existing.factory is registration.factory
                ):
                    return  # idempotent re-registration
                raise DuplicateBindingError(
                    registration.target,
                    _existing_source(existing),
                    registration.factory,
                )
            self._providers.append(registration)
            self._target_map[registration.target] = registration

    def all(self) -> list[Registration]:
        """Return a snapshot of all ``@injectable`` registrations."""
        with self._lock:
            return list(self._registrations)

    def all_providers(self) -> list[ProviderRegistration]:
        """Return a snapshot of all ``@provides`` registrations."""
        with self._lock:
            return list(self._providers)

    def clear(self) -> None:
        """Remove all registrations and providers."""
        with self._lock:
            self._registrations.clear()
            self._providers.clear()
            self._target_map.clear()

    def __len__(self) -> int:
        with self._lock:
            return len(self._registrations) + len(self._providers)


def _existing_source(entry: Registration | ProviderRegistration) -> Any:
    """Return the class or factory for a registry entry (for error messages)."""
    if isinstance(entry, Registration):
        return entry.cls
    return entry.factory


_registry = _Registry()


def get_registry() -> _Registry:
    """Return the module-level registry singleton."""
    return _registry


def clear_registry() -> None:
    """Clear all registrations. For tests only."""
    _registry.clear()


def injectable(
    scope: Scope = Scope.SINGLETON,
    bind_to: type | None = None,
) -> Any:
    """Decorator that registers a class for autowiring.

    Args:
        scope: Lifecycle scope (default: SINGLETON).
        bind_to: Optional interface type to bind this implementation to.

    Returns:
        The original class, unmodified.

    Example::

        @injectable()
        class MyService:
            ...

        @injectable(bind_to=IRepository, scope=Scope.TRANSIENT)
        class SqlRepository:
            ...
    """

    def decorator(cls: type) -> type:
        _registry.register(Registration(cls=cls, scope=scope, bind_to=bind_to))
        return cls

    return decorator


def provides(
    bind_to: type,
    scope: Scope = Scope.SINGLETON,
) -> Any:
    """Decorator that registers a factory function for a conditional binding.

    Use ``@provides`` when the concrete implementation of an interface must be
    chosen at runtime — for example, based on a feature flag or environment
    configuration. The decorated function is invoked by the container
    according to ``scope``; its return value is bound to ``bind_to``.

    Factory parameters (if any) are resolved from the container, so factories
    can depend on other ``@injectable`` or ``@provides`` bindings.

    Args:
        bind_to: The interface/type the factory's return value binds to. Required.
        scope: Lifecycle scope (default: SINGLETON). Controls how often the
            factory is invoked — once per container (SINGLETON), per resolution
            (TRANSIENT), or per thread (THREAD).

    Returns:
        The original function, unmodified.

    Raises:
        TypeError: If ``bind_to`` is not provided.

    Example::

        @provides(bind_to=IPaymentGateway)
        def payment_gateway(flags: FeatureFlags, cfg: StripeConfig) -> IPaymentGateway:
            if flags.is_enabled("use_stripe_v2"):
                return StripeV2Gateway(cfg)
            return StripeV1Gateway(cfg)
    """
    if bind_to is None or not isinstance(bind_to, type):
        raise TypeError(
            "@provides requires bind_to to be a type. Example: @provides(bind_to=IPaymentGateway)"
        )

    def decorator(factory: Callable[..., Any]) -> Callable[..., Any]:
        if not callable(factory):
            raise TypeError("@provides must decorate a callable (function).")
        if isinstance(factory, type):
            raise TypeError(
                "@provides must decorate a function, not a class. "
                "Use @injectable for class registration."
            )
        _registry.register_provider(
            ProviderRegistration(factory=factory, scope=scope, bind_to=bind_to)
        )
        return factory

    return decorator
