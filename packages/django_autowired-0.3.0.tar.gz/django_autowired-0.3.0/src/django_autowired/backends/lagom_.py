"""Lagom backend adapter."""

from __future__ import annotations

from typing import Any, TypeVar

from django_autowired.backends.base import AbstractBackend
from django_autowired.exceptions import (
    BackendNotInstalledError,
    UnresolvableTypeError,
)
from django_autowired.registry import ProviderRegistration, Registration
from django_autowired.scopes import Scope

try:
    import lagom

    _AVAILABLE = True
except ImportError:
    _AVAILABLE = False

T = TypeVar("T")


class LagomBackend(AbstractBackend):
    """Backend adapter for the ``lagom`` library.

    Lagom resolves concrete classes automatically from type hints, so only
    interface bindings and singleton scopes need explicit registration.

    Note:
        The ``@inject`` decorator from the ``injector`` library is not used
        or needed with this backend.
    """

    def __init__(self) -> None:
        if not _AVAILABLE:
            raise BackendNotInstalledError("lagom", "lagom")
        self._container: lagom.Container | None = None
        self._overrides: dict[type, Any] = {}

    @classmethod
    def name(cls) -> str:
        return "lagom"

    def build(
        self,
        registrations: list[Registration],
        extra_modules: list[Any] | None = None,
        providers: list[ProviderRegistration] | None = None,
    ) -> None:
        container = lagom.Container()

        for reg in registrations:
            if reg.bind_to is not None:
                if reg.scope == Scope.SINGLETON:
                    container.define(reg.bind_to, lagom.Singleton(reg.cls))
                else:
                    container.define(reg.bind_to, lambda _c, cls=reg.cls: cls())
            elif reg.scope == Scope.SINGLETON:
                container.define(reg.cls, lagom.Singleton(reg.cls))

        for preg in providers or []:
            invoker = _make_factory_invoker(preg.factory)
            if preg.scope == Scope.SINGLETON:
                container.define(preg.bind_to, _make_cached(invoker))
            else:
                container.define(preg.bind_to, _make_fresh(invoker))

        self._container = container
        self._overrides.clear()

    def get(self, cls: type[T]) -> T:
        if cls in self._overrides:
            return self._overrides[cls]
        assert self._container is not None
        try:
            return self._container.resolve(cls)
        except Exception as exc:
            raise UnresolvableTypeError(cls, str(exc)) from exc

    def override(self, bindings: dict[type, Any]) -> None:
        """Apply overrides via a per-instance dict.

        Lagom's ``define`` raises on duplicate bindings, so overrides are
        stored in a dict and consulted before delegating to the container.
        """
        for iface, impl in bindings.items():
            if isinstance(impl, type):
                try:
                    self._overrides[iface] = impl()
                except Exception:
                    assert self._container is not None
                    self._overrides[iface] = self._container.resolve(impl)
            else:
                self._overrides[iface] = impl

    def raw(self) -> lagom.Container:
        """Return the underlying ``lagom.Container``."""
        assert self._container is not None
        return self._container


def _make_cached(invoker: Any) -> Any:
    """Return a 1-arg lagom resolver that caches the first factory result."""
    store: dict[str, Any] = {}

    def resolve(c: Any) -> Any:
        if "v" not in store:
            store["v"] = invoker(c)
        return store["v"]

    return resolve


def _make_fresh(invoker: Any) -> Any:
    """Return a 1-arg lagom resolver that invokes the factory on every call."""

    def resolve(c: Any) -> Any:
        return invoker(c)

    return resolve


def _make_factory_invoker(factory: Any) -> Any:
    """Return a callable that invokes *factory* with deps resolved from lagom."""
    import inspect
    import typing

    sig = inspect.signature(factory)
    params = [p for p in sig.parameters.values() if p.name != "self"]

    if not params:

        def invoke_no_args(_c: Any) -> Any:
            return factory()

        return invoke_no_args

    if not all(p.annotation is not inspect.Parameter.empty for p in params):
        raise TypeError(
            f"@provides factory {factory.__qualname__} must annotate "
            f"every parameter for dependency resolution."
        )

    try:
        hints = typing.get_type_hints(factory)
    except Exception:
        hints = {}
    annotations = [hints.get(p.name, p.annotation) for p in params]

    def invoke_with_args(c: Any) -> Any:
        args = [c.resolve(t) for t in annotations]
        return factory(*args)

    return invoke_with_args
