"""Dishka backend adapter."""

from __future__ import annotations

from typing import Any, TypeVar

from django_autowired.backends.base import AbstractBackend
from django_autowired.exceptions import (
    BackendNotInstalledError,
    UnresolvableTypeError,
)
from django_autowired.registry import ProviderRegistration, Registration
from django_autowired.scopes import Scope

try:
    from dishka import Provider, make_container
    from dishka import Scope as DishkaScope

    _AVAILABLE = True
except ImportError:
    _AVAILABLE = False

T = TypeVar("T")

_SCOPE_MAP: dict[Scope, Any] = {}

if _AVAILABLE:
    _SCOPE_MAP = {
        Scope.SINGLETON: DishkaScope.APP,
        Scope.TRANSIENT: DishkaScope.APP,
        Scope.THREAD: DishkaScope.APP,
    }


class DishkaBackend(AbstractBackend):
    """Backend adapter for the ``dishka`` library.

    Note:
        Dishka's scope model differs from other backends — ``SINGLETON``,
        ``TRANSIENT``, and ``THREAD`` all map to ``DishkaScope.APP`` because
        the top-level container is APP-scoped. Use ``cache=False`` semantics
        via a ``REQUEST`` scope for true transient behavior if needed.
    """

    def __init__(self) -> None:
        if not _AVAILABLE:
            raise BackendNotInstalledError("dishka", "dishka")
        self._container: Any = None
        self._registrations: list[Registration] = []
        self._providers: list[ProviderRegistration] = []

    @classmethod
    def name(cls) -> str:
        return "dishka"

    def build(
        self,
        registrations: list[Registration],
        extra_modules: list[Any] | None = None,
        providers: list[ProviderRegistration] | None = None,
    ) -> None:
        self._registrations = list(registrations)
        self._providers = list(providers or [])
        base = _build_provider(registrations)
        provider_modules: list[Any] = [base]
        if self._providers:
            provider_modules.append(_build_provides_provider(self._providers))
        provider_modules.extend(extra_modules or [])
        self._container = make_container(*provider_modules)

    def get(self, cls: type[T]) -> T:
        assert self._container is not None
        try:
            return self._container.get(cls)
        except Exception as exc:
            raise UnresolvableTypeError(cls, str(exc)) from exc

    def override(self, bindings: dict[type, Any]) -> None:
        assert self._container is not None
        self._container.close()
        base = _build_provider(self._registrations)
        parts: list[Any] = [base]
        if self._providers:
            parts.append(_build_provides_provider(self._providers))
        parts.append(_build_override_provider(bindings))
        self._container = make_container(*parts)

    def raw(self) -> Any:
        """Return the underlying dishka ``Container``."""
        assert self._container is not None
        return self._container


def _build_provider(registrations: list[Registration]) -> Provider:
    """Build a dishka Provider from registrations."""
    provider = Provider(scope=DishkaScope.APP)

    for reg in registrations:
        target = reg.bind_to if reg.bind_to is not None else reg.cls
        provider.provide(
            _make_factory(reg.cls),
            provides=target,
            scope=DishkaScope.APP,
            cache=(reg.scope == Scope.SINGLETON),
        )

    return provider


def _build_override_provider(bindings: dict[type, Any]) -> Provider:
    """Build a dishka Provider that overrides existing bindings."""
    provider = Provider(scope=DishkaScope.APP)

    for iface, impl in bindings.items():
        if isinstance(impl, type):
            provider.provide(
                _make_factory(impl),
                provides=iface,
                scope=DishkaScope.APP,
                override=True,
            )
        else:
            provider.provide(
                _make_instance_factory(impl),
                provides=iface,
                scope=DishkaScope.APP,
                override=True,
            )

    return provider


def _build_provides_provider(providers: list[ProviderRegistration]) -> Provider:
    """Build a dishka Provider from @provides registrations.

    Dishka's ``provide`` introspects the factory's annotations to resolve
    parameters from the container, giving factory injection natively.
    """
    import inspect

    provider = Provider(scope=DishkaScope.APP)

    for preg in providers:
        factory = preg.factory
        sig = inspect.signature(factory)
        params = [p for p in sig.parameters.values() if p.name != "self"]
        if params and not all(p.annotation is not inspect.Parameter.empty for p in params):
            raise TypeError(
                f"@provides factory {factory.__qualname__} must annotate "
                f"every parameter for dependency resolution."
            )
        provider.provide(
            factory,
            provides=preg.bind_to,
            scope=DishkaScope.APP,
            cache=(preg.scope == Scope.SINGLETON),
        )

    return provider


def _make_factory(cls: type) -> Any:
    """Return a zero-arg factory callable whose return annotation is *cls*."""

    def factory() -> Any:
        return cls()

    factory.__annotations__ = {"return": cls}
    return factory


def _make_instance_factory(instance: Any) -> Any:
    """Return a zero-arg factory callable that yields *instance*."""

    def factory() -> Any:
        return instance

    factory.__annotations__ = {"return": type(instance)}
    return factory
