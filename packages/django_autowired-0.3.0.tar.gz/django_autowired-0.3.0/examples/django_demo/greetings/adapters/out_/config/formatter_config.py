"""Runtime configuration for the name-formatter selection.

Reads ``GREETER_FORMATTER_STYLE`` from the environment so the demo can
switch implementations without code changes:

    GREETER_FORMATTER_STYLE=upper python main.py
"""

import os

from django_autowired import injectable


@injectable()
class FormatterConfig:
    """Holds the runtime-selected formatter style.

    The value of ``style`` is consulted by the ``@provides`` factory in
    ``services.name_formatter_provider`` to pick the concrete formatter.
    """

    def __init__(self) -> None:
        self.style: str = os.getenv("GREETER_FORMATTER_STYLE", "title").lower()
