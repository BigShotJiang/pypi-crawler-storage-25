"""Title-case name formatter — default implementation of ``INameFormatter``.

This class is intentionally **not** decorated with ``@injectable``. It is
selected by the ``@provides`` factory in ``name_formatter_provider`` based
on the runtime value of ``FormatterConfig.style``.
"""

from greetings.domain.ports.services.name_formatter import INameFormatter


class TitleCaseNameFormatter(INameFormatter):
    """Capitalizes the first letter of each word."""

    def format(self, name: str) -> str:
        return name.strip().title()
