"""``@provides`` factory that picks the name formatter at runtime.

Demonstrates two things:

1. **Conditional binding** — the concrete ``INameFormatter`` implementation
   is chosen from a runtime config value rather than hard-wired at boot.
2. **Factory injection** — the factory itself receives ``FormatterConfig``
   from the container, just like an ``@injectable`` constructor would.

Try it::

    GREETER_FORMATTER_STYLE=upper python main.py
    GREETER_FORMATTER_STYLE=title python main.py    # default
"""

from django_autowired import provides
from greetings.adapters.out_.config.formatter_config import FormatterConfig
from greetings.adapters.out_.services.title_case_name_formatter import (
    TitleCaseNameFormatter,
)
from greetings.adapters.out_.services.upper_case_name_formatter import (
    UpperCaseNameFormatter,
)
from greetings.domain.ports.services.name_formatter import INameFormatter


@provides(bind_to=INameFormatter)
def name_formatter(config: FormatterConfig) -> INameFormatter:
    """Pick the formatter based on ``FormatterConfig.style``."""
    if config.style == "upper":
        return UpperCaseNameFormatter()
    return TitleCaseNameFormatter()
