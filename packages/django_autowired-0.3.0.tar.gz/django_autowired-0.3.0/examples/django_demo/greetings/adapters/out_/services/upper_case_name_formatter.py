"""Upper-case name formatter — alternative implementation of ``INameFormatter``.

This class is intentionally **not** decorated with ``@injectable``. It is
selected by the ``@provides`` factory in ``name_formatter_provider`` based
on the runtime value of ``FormatterConfig.style``.
"""

from greetings.domain.ports.services.name_formatter import INameFormatter


class UpperCaseNameFormatter(INameFormatter):
    """Upper-cases the entire name."""

    def format(self, name: str) -> str:
        return name.strip().upper()
