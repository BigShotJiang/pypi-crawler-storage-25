#!/usr/bin/env python
"""Django's command-line utility for the django-autowired demo project."""

import os
import sys


def main() -> None:
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "project.settings")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Install the demo dependencies with:\n"
            "    pip install -e '../..[django,injector]' django"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
