"""Tests for the @provides decorator and ProviderRegistration."""

from __future__ import annotations

from abc import ABC, abstractmethod

import pytest

from django_autowired.exceptions import DuplicateBindingError
from django_autowired.registry import (
    ProviderRegistration,
    get_registry,
    injectable,
    provides,
)
from django_autowired.scopes import Scope


class IGateway(ABC):
    @abstractmethod
    def pay(self) -> str: ...


class StripeGateway(IGateway):
    def pay(self) -> str:
        return "stripe"


class PayPalGateway(IGateway):
    def pay(self) -> str:
        return "paypal"


class TestProviderRegistration:
    def test_target_returns_bind_to(self):
        preg = ProviderRegistration(
            factory=lambda: StripeGateway(),
            scope=Scope.SINGLETON,
            bind_to=IGateway,
        )
        assert preg.target is IGateway


class TestProvidesDecorator:
    def test_registers_factory_function(self):
        @provides(bind_to=IGateway)
        def factory() -> IGateway:
            return StripeGateway()

        providers_list = get_registry().all_providers()
        assert len(providers_list) == 1
        assert providers_list[0].factory is factory
        assert providers_list[0].bind_to is IGateway
        assert providers_list[0].scope == Scope.SINGLETON

    def test_custom_scope(self):
        @provides(bind_to=IGateway, scope=Scope.TRANSIENT)
        def factory() -> IGateway:
            return StripeGateway()

        assert get_registry().all_providers()[0].scope == Scope.TRANSIENT

    def test_returns_original_function_unchanged(self):
        def original() -> IGateway:
            return StripeGateway()

        decorated = provides(bind_to=IGateway)(original)
        assert decorated is original

    def test_missing_bind_to_raises(self):
        with pytest.raises(TypeError, match="bind_to"):
            provides(bind_to=None)  # type: ignore[arg-type]

    def test_bind_to_must_be_type(self):
        with pytest.raises(TypeError, match="bind_to"):
            provides(bind_to="not-a-type")  # type: ignore[arg-type]

    def test_cannot_decorate_class(self):
        with pytest.raises(TypeError, match="function"):

            @provides(bind_to=IGateway)
            class NotAFunction:
                pass

    def test_duplicate_provides_raises(self):
        @provides(bind_to=IGateway)
        def factory_a() -> IGateway:
            return StripeGateway()

        with pytest.raises(DuplicateBindingError):

            @provides(bind_to=IGateway)
            def factory_b() -> IGateway:
                return PayPalGateway()

    def test_duplicate_with_injectable_raises(self):
        @injectable(bind_to=IGateway)
        class Impl(IGateway):
            def pay(self) -> str:
                return "impl"

        with pytest.raises(DuplicateBindingError):

            @provides(bind_to=IGateway)
            def factory() -> IGateway:
                return StripeGateway()

    def test_injectable_after_provides_raises(self):
        @provides(bind_to=IGateway)
        def factory() -> IGateway:
            return StripeGateway()

        with pytest.raises(DuplicateBindingError):

            @injectable(bind_to=IGateway)
            class Impl(IGateway):
                def pay(self) -> str:
                    return "impl"

    def test_idempotent_re_registration(self):
        @provides(bind_to=IGateway)
        def factory() -> IGateway:
            return StripeGateway()

        get_registry().register_provider(
            ProviderRegistration(factory=factory, scope=Scope.SINGLETON, bind_to=IGateway)
        )
        assert len(get_registry().all_providers()) == 1

    def test_clear_registry_clears_providers(self):
        @provides(bind_to=IGateway)
        def factory() -> IGateway:
            return StripeGateway()

        assert len(get_registry().all_providers()) == 1
        get_registry().clear()
        assert len(get_registry().all_providers()) == 0

    def test_registry_len_counts_both(self):
        @injectable()
        class Plain:
            pass

        @provides(bind_to=IGateway)
        def factory() -> IGateway:
            return StripeGateway()

        assert len(get_registry()) == 2
