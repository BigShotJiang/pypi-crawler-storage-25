"""Smoke tests for @provides with the wireup backend."""

from __future__ import annotations

from abc import ABC, abstractmethod

import pytest

pytest.importorskip("wireup")

from django_autowired import container
from django_autowired.backends.wireup_ import WireupBackend
from django_autowired.exceptions import ProviderResolutionError
from django_autowired.registry import (
    ProviderRegistration,
    Registration,
    get_registry,
)
from django_autowired.scopes import Scope


class IGateway(ABC):
    @abstractmethod
    def name(self) -> str: ...


class StripeGateway(IGateway):
    def name(self) -> str:
        return "stripe"


class StripeConfig:
    def __init__(self) -> None:
        self.api_key = "sk_test"


class ConfiguredStripe(IGateway):
    def __init__(self, cfg: StripeConfig) -> None:
        self.cfg = cfg

    def name(self) -> str:
        return f"stripe:{self.cfg.api_key}"


def _register_provider(factory, bind_to, scope: Scope = Scope.SINGLETON) -> None:
    get_registry().register_provider(
        ProviderRegistration(factory=factory, scope=scope, bind_to=bind_to)
    )


class TestProvidesWireup:
    def test_basic_factory_binding(self):
        _register_provider(lambda: StripeGateway(), bind_to=IGateway)
        container.initialize([], backend=WireupBackend())
        assert isinstance(container.get(IGateway), StripeGateway)

    def test_singleton_caches_result(self):
        _register_provider(lambda: StripeGateway(), bind_to=IGateway)
        container.initialize([], backend=WireupBackend())
        assert container.get(IGateway) is container.get(IGateway)

    def test_factory_with_injected_deps(self):
        get_registry().register(Registration(cls=StripeConfig, scope=Scope.SINGLETON))

        def factory(cfg: StripeConfig) -> IGateway:
            return ConfiguredStripe(cfg)

        _register_provider(factory, bind_to=IGateway)
        container.initialize([], backend=WireupBackend())

        gw = container.get(IGateway)
        assert gw.name() == "stripe:sk_test"

    def test_factory_raises_wrapped(self):
        def factory() -> IGateway:
            raise RuntimeError("boom")

        _register_provider(factory, bind_to=IGateway)

        with pytest.raises(ProviderResolutionError):
            container.initialize([], backend=WireupBackend())
