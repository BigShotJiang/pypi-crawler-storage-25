"""Smoke tests for @provides with the lagom backend."""

from __future__ import annotations

from abc import ABC, abstractmethod

import pytest

pytest.importorskip("lagom")

from django_autowired import container
from django_autowired.backends.lagom_ import LagomBackend
from django_autowired.exceptions import ProviderResolutionError
from django_autowired.registry import (
    ProviderRegistration,
    Registration,
    get_registry,
)
from django_autowired.scopes import Scope


class IGateway(ABC):
    @abstractmethod
    def name(self) -> str: ...


class StripeGateway(IGateway):
    def name(self) -> str:
        return "stripe"


class StripeConfig:
    def __init__(self) -> None:
        self.api_key = "sk_test"


class ConfiguredStripe(IGateway):
    def __init__(self, cfg: StripeConfig) -> None:
        self.cfg = cfg

    def name(self) -> str:
        return f"stripe:{self.cfg.api_key}"


def _register_provider(factory, bind_to, scope: Scope = Scope.SINGLETON) -> None:
    get_registry().register_provider(
        ProviderRegistration(factory=factory, scope=scope, bind_to=bind_to)
    )


class TestProvidesLagom:
    def test_basic_factory_binding(self):
        _register_provider(lambda: StripeGateway(), bind_to=IGateway)
        container.initialize([], backend=LagomBackend())

        assert isinstance(container.get(IGateway), StripeGateway)

    def test_singleton_caches_result(self):
        calls = {"n": 0}

        def factory() -> IGateway:
            calls["n"] += 1
            return StripeGateway()

        _register_provider(factory, bind_to=IGateway)
        container.initialize([], backend=LagomBackend())

        first = container.get(IGateway)
        second = container.get(IGateway)
        assert first is second

    def test_transient_invokes_on_every_get(self):
        calls = {"n": 0}

        def factory() -> IGateway:
            calls["n"] += 1
            return StripeGateway()

        _register_provider(factory, bind_to=IGateway, scope=Scope.TRANSIENT)
        container.initialize([], backend=LagomBackend())

        container.get(IGateway)
        container.get(IGateway)
        assert calls["n"] >= 3  # 1 eager + 2 gets

    def test_factory_with_injected_deps(self):
        get_registry().register(Registration(cls=StripeConfig, scope=Scope.SINGLETON))

        def factory(cfg: StripeConfig) -> IGateway:
            return ConfiguredStripe(cfg)

        _register_provider(factory, bind_to=IGateway)
        container.initialize([], backend=LagomBackend())

        gw = container.get(IGateway)
        assert gw.name() == "stripe:sk_test"

    def test_factory_raises_wrapped(self):
        def factory() -> IGateway:
            raise RuntimeError("boom")

        _register_provider(factory, bind_to=IGateway)

        with pytest.raises(ProviderResolutionError):
            container.initialize([], backend=LagomBackend())
