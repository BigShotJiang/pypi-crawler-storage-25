"""Tests for @provides end-to-end with the injector backend."""

from __future__ import annotations

import threading
from abc import ABC, abstractmethod

import pytest

injector_mod = pytest.importorskip("injector")

from django_autowired import container
from django_autowired.backends.injector_ import InjectorBackend
from django_autowired.exceptions import ProviderResolutionError
from django_autowired.registry import (
    ProviderRegistration,
    Registration,
    get_registry,
)
from django_autowired.scopes import Scope


class IGateway(ABC):
    @abstractmethod
    def name(self) -> str: ...


class StripeGateway(IGateway):
    def name(self) -> str:
        return "stripe"


class PayPalGateway(IGateway):
    def name(self) -> str:
        return "paypal"


class FeatureFlags:
    def __init__(self) -> None:
        self.use_stripe = True


class StripeConfig:
    def __init__(self) -> None:
        self.api_key = "sk_test"


class ConfiguredStripe(IGateway):
    def __init__(self, cfg: StripeConfig) -> None:
        self.cfg = cfg

    def name(self) -> str:
        return f"stripe:{self.cfg.api_key}"


def _register_injectable(cls: type, scope: Scope = Scope.SINGLETON, bind_to=None) -> None:
    get_registry().register(Registration(cls=cls, scope=scope, bind_to=bind_to))


def _register_provider(factory, bind_to, scope: Scope = Scope.SINGLETON) -> None:
    get_registry().register_provider(
        ProviderRegistration(factory=factory, scope=scope, bind_to=bind_to)
    )


class TestProvidesInjector:
    def test_provides_binds_factory_result(self):
        def factory() -> IGateway:
            return StripeGateway()

        _register_provider(factory, bind_to=IGateway)
        container.initialize([], backend=InjectorBackend())

        result = container.get(IGateway)
        assert isinstance(result, StripeGateway)
        assert result.name() == "stripe"

    def test_singleton_scope_caches_factory_result(self):
        calls = {"count": 0}

        def factory() -> IGateway:
            calls["count"] += 1
            return StripeGateway()

        _register_provider(factory, bind_to=IGateway, scope=Scope.SINGLETON)
        container.initialize([], backend=InjectorBackend())

        first = container.get(IGateway)
        second = container.get(IGateway)
        assert first is second
        # Eager verification invokes once; subsequent gets hit the cache.
        assert calls["count"] == 1

    def test_transient_scope_invokes_on_every_get(self):
        calls = {"count": 0}

        def factory() -> IGateway:
            calls["count"] += 1
            return StripeGateway()

        _register_provider(factory, bind_to=IGateway, scope=Scope.TRANSIENT)
        container.initialize([], backend=InjectorBackend())

        # Eager verification = 1 call. Two more gets = 3 total.
        container.get(IGateway)
        container.get(IGateway)
        assert calls["count"] >= 3

    def test_factory_with_injected_deps(self):
        _register_injectable(StripeConfig)

        def factory(cfg: StripeConfig) -> IGateway:
            return ConfiguredStripe(cfg)

        _register_provider(factory, bind_to=IGateway)
        container.initialize([], backend=InjectorBackend())

        gateway = container.get(IGateway)
        assert isinstance(gateway, ConfiguredStripe)
        assert gateway.name() == "stripe:sk_test"

    def test_factory_chooses_based_on_flag(self):
        flags = FeatureFlags()

        def factory(f: FeatureFlags = flags) -> IGateway:
            return StripeGateway() if f.use_stripe else PayPalGateway()

        _register_provider(factory, bind_to=IGateway)
        container.initialize([], backend=InjectorBackend())

        assert container.get(IGateway).name() == "stripe"

    def test_factory_raises_wrapped_in_provider_resolution_error(self):
        def factory() -> IGateway:
            raise RuntimeError("boom")

        _register_provider(factory, bind_to=IGateway)

        with pytest.raises(ProviderResolutionError) as exc_info:
            container.initialize([], backend=InjectorBackend())

        assert "boom" in str(exc_info.value)

    def test_factory_runs_eagerly_at_initialize(self):
        calls = {"count": 0}

        def factory() -> IGateway:
            calls["count"] += 1
            return StripeGateway()

        _register_provider(factory, bind_to=IGateway)

        assert calls["count"] == 0  # not called at decoration
        container.initialize([], backend=InjectorBackend())
        assert calls["count"] == 1  # called at initialize()

    def test_thread_scope_isolates_per_thread(self):
        def factory() -> IGateway:
            return StripeGateway()

        _register_provider(factory, bind_to=IGateway, scope=Scope.THREAD)
        container.initialize([], backend=InjectorBackend())

        results: dict[str, object] = {}

        def grab(key: str) -> None:
            results[key] = container.get(IGateway)

        results["main"] = container.get(IGateway)
        t = threading.Thread(target=grab, args=("other",))
        t.start()
        t.join()

        # Same thread = same instance; different thread = different instance.
        assert results["main"] is container.get(IGateway)
        assert results["main"] is not results["other"]
