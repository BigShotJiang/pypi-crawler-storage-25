"""DevPanel CLI entry point."""

from __future__ import annotations

import asyncio
import json
import sys
import urllib.request


def main() -> None:
    args = sys.argv[1:]

    # Native messaging mode: Chrome invokes as `devpanel chrome-extension://ID/`
    if args and args[0].startswith("chrome-extension://"):
        from devpanel.nativemsg import serve

        serve()
        return

    cmd = args[0] if args else "start"

    if cmd == "start":
        port = 0
        for i, a in enumerate(args[1:], 1):
            if a == "--port" and i + 1 < len(args):
                port = int(args[i + 1])
        _run_server(port)

    elif cmd == "install":
        ext_id = None
        dev = False
        user_data_dir = None
        for i, a in enumerate(args[1:], 1):
            if a.startswith("--extension-id="):
                ext_id = a.split("=", 1)[1]
            elif a == "--extension-id" and i + 1 < len(args):
                ext_id = args[i + 1]
            elif a.startswith("--user-data-dir="):
                user_data_dir = a.split("=", 1)[1]
            elif a == "--user-data-dir" and i + 1 < len(args):
                user_data_dir = args[i + 1]
            elif a == "--dev":
                dev = True
        from devpanel.install import install

        install(ext_id, dev=dev, user_data_dir=user_data_dir)

    elif cmd == "restart":
        sys.exit(_cmd_restart())

    elif cmd == "status":
        sys.exit(_cmd_status())

    else:
        print(
            "Usage: devpanel [start|install|restart|status]\n"
            "\n"
            "  start                              Start daemon (random port)\n"
            "  start --port PORT                  Start daemon on fixed port\n"
            "  install --extension-id=ID          Register NMH manifest (production)\n"
            "  install --extension-id=ID --dev    Register NMH manifest (dev, repld)\n"
            "  install --user-data-dir=PATH       Also write manifest to custom profile\n"
            "  restart                            Kill running daemon\n"
            "  status                             Show daemon health",
            file=sys.stderr,
        )
        sys.exit(1)


def _cmd_restart() -> int:
    """Kill the running daemon and remove the lock. Next NMH spawn brings up fresh code."""
    from devpanel.nativemsg import LOCK_FILE, _kill_pid, _read_lock

    lock = _read_lock()
    if not lock:
        if LOCK_FILE.exists():
            LOCK_FILE.unlink(missing_ok=True)
            print("Removed stale lock (daemon was not running)")
            return 0
        print("No daemon running")
        return 0

    pid = lock.get("pid", 0)
    port = lock.get("port", "?")
    if _kill_pid(pid):
        LOCK_FILE.unlink(missing_ok=True)
        print(f"Killed daemon pid={pid} port={port}")
        return 0
    print(f"Failed to kill daemon pid={pid}", file=sys.stderr)
    return 1


def _cmd_status() -> int:
    """Print daemon health from /controls. Exit 1 if not running."""
    from devpanel.nativemsg import LOCK_FILE, _read_lock

    if not LOCK_FILE.exists():
        print("not running (no lock file)")
        return 1
    lock = _read_lock()
    if not lock:
        print("not running (stale lock — pid not alive)")
        return 1
    port = lock.get("port")
    pid = lock.get("pid")
    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/controls", timeout=2
        ) as resp:
            data = json.loads(resp.read())
    except Exception as e:
        print(f"unreachable: {e}", file=sys.stderr)
        return 1

    print(f"devpanel daemon  pid={pid}  port={port}")
    print(f"  version       {data.get('version') or '(unknown)'}")
    print(f"  uptime        {data.get('uptime', 0)}s")
    print(f"  spill_dir     {data.get('spill_dir', '?')}")
    print(f"  repld_socket  {data.get('repld_socket') or '(none)'}")
    sessions = data.get("sessions", {})
    print(f"  sessions      {len(sessions)}")
    for sid, s in sessions.items():
        print(
            f"    {sid[:8]}  pty_pid={s.get('pty_pid')}  clients={s.get('clients', 0)}  "
            f"stack={s.get('stack_size', 0)}  mcp={s.get('mcp_sessions', 0)}  "
            f"async={s.get('async_tasks', 0)}  watch={s.get('watchers', 0)}"
        )
    return 0


def _run_server(port: int) -> None:
    async def _main() -> None:
        from devpanel.server import run

        actual_port = await run(port)
        if sys.stdout.isatty():
            print(f"devpanel daemon listening on http://127.0.0.1:{actual_port}")
            print(f"  WebSocket PTY: ws://127.0.0.1:{actual_port}/ws")
            print(f"  MCP:           http://127.0.0.1:{actual_port}/mcp")
            print(f"  Controls:      http://127.0.0.1:{actual_port}/controls")
            print(f"  Stack:         http://127.0.0.1:{actual_port}/stack")
        # Block forever
        await asyncio.Event().wait()

    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        pass
