"""Session module tests."""
