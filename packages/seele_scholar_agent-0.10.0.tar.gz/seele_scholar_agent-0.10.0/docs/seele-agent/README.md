# Seele Scholar Agent 实现指南

> 基于 LangGraph 的学术论文写作 Agent 逐步实现文档

---

## 目录

1. [项目概述](#1-项目概述)
2. [整体架构设计](#2-整体架构设计)
3. [项目初始化](#3-项目初始化)
4. [项目结构](#4-项目结构)
5. [实现步骤](#5-实现步骤)

---

## 1. 项目概述

Seele Scholar Agent 是一个基于 LangGraph 的学术论文写作 Agent，核心功能：

- **多源文献检索**：ArXiv、Semantic Scholar、用户私有文档库 (RAG)
- **智能大纲规划**：基于文献生成结构化论文大纲
- **协作式撰写**：人与 AI 协作，AI 撰写、人类确认
- **严格审稿**：自动审稿 + 返修循环

---

## 2. 整体架构设计

### 2.1 为什么需要 Agent？

传统函数调用的问题：**一次性执行，无法中断，无法记忆中间状态**。

论文写作是**多阶段、长流程**的任务：
- 检索文献 → 生成大纲 → 撰写章节 → 审稿 → 修改 → 重复
- 用户可能在中途确认/修改大纲
- 需要在断点处暂停等待人类输入

Agent 解决的问题：**状态持久化 + 节点编排 + 人机协作**。

### 2.2 节点划分

将论文写作流程拆分为 4 个节点：

| 节点 | 职责 | 输入 | 输出 |
|------|------|------|------|
| **Researcher** | 检索学术文献 | topic | papers[] |
| **Planner** | 生成论文大纲 | topic + papers | outline + sections[] |
| **Writer** | 撰写章节内容 | outline + section | section.content |
| **Reviewer** | 审稿打分 | section.content | review_result |

**为什么这样划分？**

- **单一职责**：每个节点只做一件事，便于测试和复用
- **自然边界**：每个节点都是一次 LLM 调用，成本可预估
- **可中断点**：Planner 之后可以中断等待用户确认大纲

### 2.3 状态设计

节点之间通过**共享状态**通信：

```
AgentState
├── topic: str                    # 研究主题（入口）
├── papers: List[PaperMetadata]   # 检索结果
├── outline: OutlineStructure     # 大纲
├── sections: List[SectionDraft]  # 章节列表
├── review_history: List[Dict]    # 审稿记录
└── status: str                   # 当前状态
```

**关键设计：Annotated 类型**

使用 `Annotated[List[T], operator.add]` 实现列表**累加**而非覆盖：

```python
papers: Annotated[List[PaperMetadata], operator.add]
```

这确保多个节点向同一列表添加内容时不会互相覆盖。

### 2.4 工作流程

```
START
  │
  ▼
┌──────────────┐
│  Researcher  │─── 检索 ArXiv + Semantic Scholar
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Planner    │─── 生成论文大纲
└──────┬───────┘
       │
       ▼ [中断等待用户确认]
┌──────────────┐
│    Writer    │─── 撰写当前章节
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Reviewer   │─── 审稿评分
└──────┬───────┘
       │
       ├── 通过 ──▶ 下一章节 ──▶ Writer
       │
       └── 全部完成 ──▶ END
```

---

## 3. 项目初始化

### 3.1 创建项目目录

```bash
# 创建项目根目录
mkdir seele-agent
cd seele-agent

# 创建包目录结构
mkdir -p seele_agent/nodes
```

### 3.2 初始化 pyproject.toml

```bash
# 方法一：使用 uv 初始化
uv init

# 方法二：手动创建 pyproject.toml
cat > pyproject.toml << 'EOF'
[project]
name = "seele-agent"
version = "0.1.0"
description = "An academic paper writing agent based on LangGraph"
requires-python = ">=3.11"

dependencies = [
    "langgraph>=0.0.40",
    "langchain-core>=0.1.0",
    "langchain-openai>=0.0.5",
    "langchain-community>=0.0.10",
    "pydantic>=2.0.0",
    "pydantic-settings>=2.0.0",
    "python-dotenv>=1.0.0",
    "structlog>=24.0.0",
    "aiohttp>=3.9.0",
    "arxiv>=1.4.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0.0",
    "pytest-asyncio>=0.23.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["seele_agent"]
EOF
```

### 3.3 安装依赖

**方式一：使用 uv init（推荐）**

```bash
uv init                    # 创建项目 + .venv + pyproject.toml

# 编辑 pyproject.toml，添加 dependencies（见上方 3.2）

uv sync                    # 安装依赖
```

**方式二：手动创建**

```bash
# 如果不用 uv init，手动创建目录后：
uv venv                   # 创建虚拟环境

uv sync                   # 安装依赖（需要 pyproject.toml 已包含 dependencies）
```

**激活虚拟环境（可选）**

```bash
source .venv/bin/activate  # Linux/Mac
# 或 .venv\Scripts\activate  # Windows

# 之后就可以用 python 运行代码了
```

### 3.4 配置环境变量

```bash
cat > .env << 'EOF'
OPENAI_API_KEY=sk-your-api-key-here
OPENAI_MODEL=gpt-4o
SEMANTIC_SCHOLAR_API_KEY=
EOF
```

---

## 4. 项目结构

```
seele_agent/                    # Python 包
├── __init__.py                 # 包入口
├── state.py                    # 状态定义
├── config.py                   # 配置管理
├── logging.py                  # 日志工具
├── graph.py                    # 图编排
└── nodes/
    ├── __init__.py
    ├── researcher.py           # 文献检索
    ├── planner.py              # 大纲规划
    ├── writer.py               # 章节撰写
    └── reviewer.py             # 审稿
```

**实现顺序**：`state.py` → `config.py` → `logging.py` → `nodes/*` → `graph.py`

原因：
1. state 是基础，其他所有模块依赖它
2. nodes 之间相互独立，可以并行实现
3. graph 依赖所有其他模块，最后实现

---

## 5. 实现步骤

### 5.1 定义状态模型

状态是 Agent 的核心，定义在 `state.py` 中。

**文件：** `seele_agent/state.py`

```python
from typing import Annotated, List, Dict, Optional, Literal, Any
from typing_extensions import TypedDict
from pydantic import BaseModel, Field
from datetime import datetime
import operator
```

**PaperMetadata - 文献元数据**

```python
class PaperMetadata(BaseModel):
    """文献元数据"""
    paper_id: str                                    # 唯一标识
    title: str                                       # 标题
    authors: List[str]                               # 作者列表
    abstract: str                                    # 摘要
    url: Optional[str] = None                        # 论文链接
    pdf_url: Optional[str] = None                   # PDF 下载链接
    relevance_score: float = 0.0                      # 相关性评分 (0-1)
    source: Literal["arxiv", "semantic_scholar", "user_library"] = "arxiv"
```

**SectionOutline - 大纲章节**

```python
class SectionOutline(BaseModel):
    """大纲章节（规划用）"""
    title: str                              # 章节标题
    description: str = ""                    # 章节描述
    order: int                              # 顺序
    key_points: List[str] = Field(default_factory=list)  # 关键论点
```

**OutlineStructure - 论文大纲**

```python
class OutlineStructure(BaseModel):
    """论文大纲"""
    title: str                              # 论文标题
    abstract: str = ""                      # 摘要
    sections: List[SectionOutline] = []     # 章节列表
    keywords: List[str] = []                # 关键词
```

**SectionDraft - 章节草稿**

```python
class SectionDraft(BaseModel):
    """章节草稿（撰写用）"""
    section_id: str                                     # 章节 ID
    title: str                                          # 标题
    description: str = ""                               # 描述
    content: str = ""                                   # 正文内容
    order_index: int                                    # 顺序
    status: Literal["pending", "writing", "review", "approved"] = "pending"
    revision_count: int = 0                             # 返修次数
    review_comments: List[str] = Field(default_factory=list)  # 审稿意见
```

**ReviewIssue + ReviewResult - 审稿结果**

```python
class ReviewIssue(BaseModel):
    """审稿问题"""
    type: Literal["factual_error", "missing_citation", "weak_argument", "format_issue", "other"]
    description: str
    suggestion: str
    location: Optional[str] = None

class ReviewResult(BaseModel):
    """审稿结果"""
    approved: bool                      # 是否通过
    score: int = Field(ge=1, le=10)    # 评分 1-10
    issues: List[ReviewIssue] = []
    summary: str
```

**AgentState - 全局状态**

这是 LangGraph 使用的状态类型，必须是 `TypedDict`：

```python
class AgentState(TypedDict):
    """Agent 全局状态"""
    
    # === 基础信息 ===
    thread_id: str                      # 唯一会话 ID（断点续传用）
    topic: str                          # 研究主题
    created_at: datetime                # 创建时间
    tenant_id: Optional[str]            # 租户 ID（多租户用）
    
    # === 检索阶段 ===
    papers: Annotated[List[PaperMetadata], operator.add]  # 累加列表
    search_queries: Annotated[List[str], operator.add]
    
    # === 规划阶段 ===
    outline: Optional[OutlineStructure]
    outline_approved: bool               # 大纲是否已确认
    
    # === 撰写阶段 ===
    sections: List[SectionDraft]         # 章节列表
    current_section_index: int           # 当前处理到第几个章节
    sections_completed: Annotated[List[str], operator.add]
    
    # === 审稿阶段 ===
    review_history: Annotated[List[Dict], operator.add]
    current_review: Optional[ReviewResult]
    
    # === RAG 上下文 ===
    rag_context: Annotated[List[DocumentChunk], operator.add]
    
    # === 流程控制 ===
    status: Literal[
        "idle", "researching", "planning", "writing",
        "reviewing", "waiting_human", "completed", "failed"
    ]
    pending_node: Optional[str]
    error_message: Optional[str]
    max_revisions: int                  # 最大返修次数
    revision_count: int                 # 当前返修次数
```

**设计决策：**

| 决策 | 选择 | 原因 |
|------|------|------|
| papers 用 Annotated | `operator.add` | 多个检索源的结果累加 |
| sections 用 List | 非 Annotated | 整体替换，不是追加 |
| status 内置 | 字符串字面量 | LangGraph 条件边需要可比较 |
| revision_count 独立 | 非 section 内 | 全局计数，避免无限循环 |

---

### 5.2 配置管理

使用 Pydantic Settings 管理配置，遵循**12-Factor App** 原则。

**文件：** `seele_agent/config.py`

> **注意（当前实现）**：`config.py` 仅保留 agent 内部使用的字段（`SEMANTIC_SCHOLAR_API_KEY`、`MAX_REVISIONS`）。
> LLM、Qdrant、Embedding 等配置由**调用方**在构造时注入，不再由 agent 包管理。
> 以下为初始设计阶段的字段示意，仅供参考。

```python
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    """Agent 配置（初始设计示意，当前实现已精简）"""
    model_config = {"env_file": ".env", "extra": "ignore"}
    
    # === Agent 内部配置（当前实际使用） ===
    SEMANTIC_SCHOLAR_API_KEY: str = ""
    MAX_REVISIONS: int = 3

    # === 以下字段已移除，由调用方注入 ===
    # OPENAI_API_KEY: str = ""      → 由调用方传给 ChatOpenAI(api_key=...)
    # OPENAI_MODEL: str = "gpt-4o"  → 由调用方传给 ChatOpenAI(model=...)
    # QDRANT_URL / QDRANT_API_KEY   → 由调用方传给 QdrantClient(...)
    # EMBEDDING_MODEL               → 由调用方传给 OpenAIEmbeddings(model=...)
    # DEFAULT_TOP_K                 → 由调用方传给 create_writing_graph(...)


@lru_cache
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
```

**配置优先级**（从高到低）：
1. 环境变量：`SEMANTIC_SCHOLAR_API_KEY=xxx`
2. `src/seele_scholar_agent/.env` 文件
3. 代码默认值

---

### 5.3 日志工具

使用 structlog 实现结构化日志。

**文件：** `seele_agent/logging.py`

```python
import logging
import sys
import structlog


def setup_logging(debug: bool = False):
    """配置结构化日志"""
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=logging.DEBUG if debug else logging.INFO,
    )
    
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer()
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str):
    """获取 logger 实例"""
    return structlog.get_logger(name)
```

---

> **注意（当前实现）**：以下 5.4 ~ 5.8 的节点示例代码中，`PlannerNode`/`WriterNode`/`ReviewerNode` 的 `__init__` 含有 `model or ChatOpenAI(model=settings.OPENAI_MODEL, ...)` 回退逻辑。
> 当前实现已移除这些 settings 字段（`OPENAI_MODEL`/`OPENAI_API_KEY` 等），所有节点**必须**由调用方在初始化 graph 时传入 `llm` 参数，没有默认回退。以下代码仅作设计意图参考。

### 5.4 实现 Researcher 节点

Researcher 节点负责从多个来源检索学术文献。

**文件：** `seele_agent/nodes/researcher.py`

**ArXiv 检索器**

```python
from langchain_community.tools import ArxivQueryRun

class ArxivRetriever:
    """ArXiv 文献检索"""
    
    def __init__(self):
        self.arxiv = ArxivQueryRun(top_k_results=10)
    
    async def search(self, query: str) -> List[PaperMetadata]:
        try:
            raw_result = await self.arxiv.ainvoke({"query": query})
            result_data = json.loads(raw_result) if isinstance(raw_result, str) else raw_result
            results = result_data.get("results", []) if isinstance(result_data, dict) else []
            
            papers = []
            for r in results[:10]:
                papers.append(PaperMetadata(
                    paper_id=r.get("entry_id", ""),
                    title=r.get("title", ""),
                    authors=r.get("authors", []),
                    abstract=r.get("summary", ""),
                    url=r.get("entry_id", ""),
                    pdf_url=(r.get("entry_id", "") or "").replace("abs", "pdf") + ".pdf",
                    source="arxiv",
                    relevance_score=0.8
                ))
            return papers
        except Exception as e:
            logger.error(f"ArXiv search failed: {e}")
            return []
```

**Semantic Scholar 检索器**

```python
class SemanticScholarRetriever:
    """Semantic Scholar 文献检索"""
    
    BASE_URL = "https://api.semanticscholar.org/graph/v1"
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.headers = {"x-api-key": api_key} if api_key else {}
    
    async def search(
        self,
        query: str,
        top_k: int = 10,
        fields: List[str] = None
    ) -> List[PaperMetadata]:
        if fields is None:
            fields = ["paperId", "title", "authors", "abstract", 
                     "url", "pdfUrl", "year", "citationCount"]
        
        url = f"{self.BASE_URL}/paper/search"
        params = {"query": query, "limit": top_k, "fields": ",".join(fields)}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url, params=params, headers=self.headers,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status != 200:
                        return []
                    data = await response.json()
            
            papers = []
            for r in data.get("data", [])[:top_k]:
                relevance = self._calculate_relevance(r)
                papers.append(PaperMetadata(
                    paper_id=r["paperId"],
                    title=r.get("title", ""),
                    authors=[a.get("name", "") for a in r.get("authors", [])],
                    abstract=r.get("abstract") or "",
                    url=r.get("url"),
                    pdf_url=r.get("pdfUrl"),
                    source="semantic_scholar",
                    relevance_score=relevance
                ))
            return papers
        except Exception as e:
            logger.error(f"Semantic Scholar search failed: {e}")
            return []
    
    def _calculate_relevance(self, paper: dict) -> float:
        """计算相关性评分"""
        citation_count = paper.get("citationCount", 0)
        year = paper.get("year", 2020)
        citation_score = min(citation_count / 10000, 1.0)
        year_weight = 1.0 if year >= 2020 else 0.6
        return round(citation_score * 0.7 + year_weight * 0.3, 2)
```

**ResearcherNode 组合**

```python
class ResearcherNode:
    """文献检索节点"""
    
    def __init__(
        self,
        qdrant_client=None,
        embedding_model=None,
        semantic_scholar_key: Optional[str] = None
    ):
        self.arxiv = ArxivRetriever()
        self.ss = SemanticScholarRetriever(api_key=semantic_scholar_key)
        self.qdrant = qdrant_client
        self.embedding = embedding_model
    
    async def search(self, state: AgentState) -> Dict:
        topic = state["topic"]
        
        all_papers = []
        
        # 1. ArXiv 检索
        logger.info(f"Searching ArXiv for: {topic}")
        arxiv_papers = await self.arxiv.search(topic)
        all_papers.extend(arxiv_papers)
        
        # 2. Semantic Scholar 检索
        logger.info(f"Searching Semantic Scholar for: {topic}")
        ss_papers = await self.ss.search(topic, top_k=10)
        all_papers.extend(ss_papers)
        
        # 3. 去重（按 paper_id）
        seen_ids = set()
        unique_papers = [
            p for p in all_papers 
            if p.paper_id not in seen_ids and not seen_ids.add(p.paper_id)
        ]
        
        # 4. 按相关性排序
        unique_papers.sort(key=lambda x: x.relevance_score, reverse=True)
        
        return {
            "papers": unique_papers,
            "status": "planning"
        }
```

**设计决策：**

| 决策 | 选择 | 原因 |
|------|------|------|
| ArXiv API | langchain 封装 | 简化 PDF URL 构造 |
| SS 相关性 | 引用量 + 年份 | 学术论文通常引用量高=质量高 |
| 去重方式 | paper_id | 唯一标识，最可靠 |

---

### 5.5 实现 Planner 节点

Planner 节点使用 LLM 根据研究主题和检索到的文献生成论文大纲。

**文件：** `seele_agent/nodes/planner.py`

**Prompt 设计**

```python
PLANNER_SYSTEM_PROMPT = """你是一位资深的学术论文大纲规划师。根据给定的研究主题和检索到的相关文献，生成一份结构清晰、逻辑严谨的论文大纲。

要求：
1. 遵循标准学术论文结构 (Introduction -> Related Work -> Method -> Experiment -> Conclusion)
2. 章节数量适中 (6-10个主要章节)，每个章节有明确的描述
3. 适当引用检索到的文献
4. 输出有效的 JSON 格式"""

PLANNER_USER_PROMPT = """研究主题：{topic}

检索到的相关文献：
{papers_summary}

请生成以下 JSON 格式的论文大纲：
{{
    "title": "论文标题（英文）",
    "abstract": "摘要（200-300词）",
    "sections": [
        {{
            "title": "Introduction",
            "description": "章节描述",
            "order": 1,
            "key_points": ["关键论点1", "关键论点2"]
        }}
    ],
    "keywords": ["关键词1", "关键词2", "关键词3"]
}}

只输出 JSON，不要有其他文字"""
```

**PlannerNode 实现**

```python
class PlannerNode:
    """大纲规划节点"""
    
    def __init__(self, model: ChatOpenAI = None):
        self.model = model or ChatOpenAI(
            model=settings.OPENAI_MODEL,
            api_key=settings.OPENAI_API_KEY,
            temperature=settings.OPENAI_TEMPERATURE,
            max_tokens=settings.OPENAI_MAX_TOKENS
        )
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", PLANNER_SYSTEM_PROMPT),
            ("user", PLANNER_USER_PROMPT)
        ])
        self.parser = JsonOutputParser()
        self.chain = self.prompt | self.model | self.parser
    
    async def plan(self, state: AgentState) -> Dict:
        topic = state["topic"]
        papers = state.get("papers", [])
        
        # 构建文献摘要（只取前 15 篇，避免 context 过长）
        papers_summary = "\n\n".join([
            f"- **{p.title}** ({', '.join(p.authors[:3])})"
            for p in papers[:15]
        ]) or "无相关文献"
        
        logger.info("Generating outline with LLM...")
        
        try:
            result = await self.chain.ainvoke({
                "topic": topic,
                "papers_summary": papers_summary
            })
        except Exception as e:
            logger.error(f"LLM outline generation failed: {e}")
            result = self._default_outline(topic)
        
        # 解析并构建大纲对象
        outline = OutlineStructure(
            title=result.get("title", f"Research on {topic}"),
            abstract=result.get("abstract", ""),
            sections=[
                SectionOutline(
                    title=s.get("title", f"Section {i}"),
                    description=s.get("description", ""),
                    order=s.get("order", i),
                    key_points=s.get("key_points", [])
                )
                for i, s in enumerate(result.get("sections", []), 1)
            ],
            keywords=result.get("keywords", [])
        )
        
        # 转换为章节草稿列表
        sections = [
            SectionDraft(
                section_id=f"section_{i}",
                title=s.title,
                description=s.description,
                order_index=s.order
            )
            for s in sorted(outline.sections, key=lambda x: x.order)
        ]
        
        logger.info(f"Generated outline with {len(sections)} sections")
        
        return {
            "outline": outline,
            "sections": sections,
            "current_section_index": 0,
            "status": "waiting_human"
        }
    
    def _default_outline(self, topic: str) -> dict:
        """LLM 调用失败时的兜底大纲"""
        return {
            "title": f"Research on {topic}",
            "sections": [
                {"title": "Introduction", "description": "Research background", "order": 1, "key_points": []},
                {"title": "Related Work", "description": "Literature review", "order": 2, "key_points": []},
                {"title": "Methodology", "description": "Proposed method", "order": 3, "key_points": []},
                {"title": "Experiment", "description": "Experimental results", "order": 4, "key_points": []},
                {"title": "Conclusion", "description": "Summary", "order": 5, "key_points": []}
            ],
            "keywords": [topic]
        }
```

**设计决策：**

| 决策 | 选择 | 原因 |
|------|------|------|
| 输出格式 | JSON | 便于解析，结构化 |
| Parser | JsonOutputParser | LangChain 内置，健壮 |
| 文献数量 | 最多 15 篇 | 控制 context 长度和成本 |
| 兜底大纲 | 5 章经典结构 | LLM 失败时仍可继续 |
| 中断状态 | `waiting_human` | 等待用户确认大纲 |

---

### 5.6 实现 Writer 节点

Writer 节点根据大纲和审稿意见撰写章节内容。

**文件：** `seele_agent/nodes/writer.py`

**Prompt 设计**

```python
WRITER_SYSTEM_PROMPT = """你是一位专业的学术论文撰写者。你擅长撰写严谨、清晰、论证充分的学术论文内容。

要求：
1. 学术风格，严谨客观
2. 适当引用相关工作，使用 [1], [2] 格式
3. 使用 Markdown 格式输出
4. 直接输出内容，不要有解释性文字"""

WRITER_USER_PROMPT = """论文主题：{topic}

当前章节：{section_title}
章节描述：{section_description}

论文大纲：
{outline_json}

相关文献上下文：
{rag_context}

历史审稿意见：
{review_comments}

请撰写该章节的完整内容。"""
```

**WriterNode 实现**

```python
class WriterNode:
    """章节撰写节点"""
    
    def __init__(self, model: ChatOpenAI = None, rag_service=None):
        self.model = model or ChatOpenAI(
            model=settings.OPENAI_MODEL,
            api_key=settings.OPENAI_API_KEY,
            temperature=settings.OPENAI_TEMPERATURE,
            max_tokens=settings.OPENAI_MAX_TOKENS
        )
        self.rag_service = rag_service
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", WRITER_SYSTEM_PROMPT),
            ("user", WRITER_USER_PROMPT)
        ])
        self.chain = self.prompt | self.model
    
    async def write(self, state: AgentState) -> Dict:
        sections = state["sections"]
        current_idx = state["current_section_index"]
        
        # 所有章节已完成
        if current_idx >= len(sections):
            return {"status": "completed", "sections_completed": state.get("sections_completed", [])}
        
        section = sections[current_idx]
        
        # 已通过的章节直接跳过
        if section.status == "approved":
            return await self._move_to_next(state)
        
        logger.info(f"Writing section: {section.title}")
        
        # 构建上下文
        outline_json = self._build_outline_json(state.get("outline"))
        rag_context = self._build_rag_context(state.get("rag_context"))
        review_comments = self._build_review_comments(section)
        
        try:
            result = await self.chain.ainvoke({
                "topic": state["topic"],
                "section_title": section.title,
                "section_description": section.description,
                "outline_json": outline_json,
                "rag_context": rag_context,
                "review_comments": review_comments
            })
            content = result.content if hasattr(result, 'content') else str(result)
            content = self._clean_content(content)
        except Exception as e:
            logger.error(f"Writing failed: {e}")
            content = f"**[Error: {str(e)}]**"
        
        # 更新章节状态
        updated_sections = sections.copy()
        updated_sections[current_idx] = section.model_copy(update={
            "content": content,
            "status": "review",
            "revision_count": section.revision_count + 1
        })
        
        return {
            "sections": updated_sections,
            "status": "reviewing"
        }
    
    def _build_outline_json(self, outline) -> str:
        if not outline:
            return ""
        lines = [f"Title: {outline.title}", ""]
        for s in outline.sections:
            lines.append(f"- {s.title}: {s.description}")
        return "\n".join(lines)
    
    def _build_rag_context(self, rag_context) -> str:
        if not rag_context:
            return "无"
        return "\n\n".join([c.content for c in rag_context[:5]])
    
    def _build_review_comments(self, section) -> str:
        if not section.review_comments:
            return "无"
        return "\n".join([f"- {c}" for c in section.review_comments])
    
    def _clean_content(self, content: str) -> str:
        """移除 markdown 代码块标记"""
        lines = content.split("\n")
        skip = True
        clean = []
        for line in lines:
            if line.strip().startswith("```"):
                skip = not skip
                continue
            if skip and not line.strip():
                continue
            skip = False
            clean.append(line)
        return "\n".join(clean).strip()
    
    async def _move_to_next(self, state: AgentState) -> Dict:
        """移动到下一个章节"""
        sections = state["sections"]
        idx = state["current_section_index"]
        completed = state.get("sections_completed", [])
        completed.append(sections[idx].title)
        
        if idx + 1 >= len(sections):
            return {"sections_completed": completed, "status": "completed"}
        
        return {
            "sections_completed": completed,
            "current_section_index": idx + 1,
            "status": "writing"
        }
```

**设计决策：**

| 决策 | 选择 | 原因 |
|------|------|------|
| 章节跳过 | status == "approved" | 已通过的章节不重复写 |
| 上下文构建 | 分离为独立方法 | 便于测试和复用 |
| 内容清洗 | 移除 ``` 块 | LLM 可能输出 markdown 代码块 |
| 状态更新 | model_copy | Pydantic 模型不可变 |

---

### 5.7 实现 Reviewer 节点

Reviewer 节点对章节进行审稿，决定是通过还是需要修改。

**文件：** `seele_agent/nodes/reviewer.py`

**Prompt 设计**

```python
REVIEWER_SYSTEM_PROMPT = """你是一位资深的学术论文审稿人。你会严格审查论文内容，给出建设性的修改意见。
输出有效的 JSON 格式。"""

REVIEWER_USER_PROMPT = """请审阅以下论文章节：

论文主题：{topic}
章节标题：{section_title}
章节内容：
{content}

请给出 JSON 格式的审阅结果：
{{
    "approved": true或false,
    "score": 1-10,
    "issues": [
        {{
            "type": "factual_error|missing_citation|weak_argument|format_issue",
            "description": "问题描述",
            "suggestion": "修改建议"
        }}
    ],
    "summary": "总体审阅意见"
}}

如果 score >= 7 且 issues 为空，approved 应为 true。"""
```

**ReviewerNode 实现**

```python
class ReviewerNode:
    """审稿节点"""
    
    def __init__(self, model: ChatOpenAI = None):
        self.model = model or ChatOpenAI(
            model=settings.OPENAI_MODEL,
            api_key=settings.OPENAI_API_KEY,
            temperature=0.3,
            max_tokens=2048
        )
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", REVIEWER_SYSTEM_PROMPT),
            ("user", REVIEWER_USER_PROMPT)
        ])
        self.parser = JsonOutputParser()
        self.chain = self.prompt | self.model | self.parser
    
    async def review(self, state: AgentState) -> Dict:
        sections = state["sections"]
        idx = state["current_section_index"]
        section = sections[idx]
        
        logger.info(f"Reviewing section: {section.title}")
        
        try:
            result = await self.chain.ainvoke({
                "topic": state["topic"],
                "section_title": section.title,
                "content": section.content
            })
            review = ReviewResult(
                approved=result.get("approved", False),
                score=result.get("score", 5),
                issues=[ReviewIssue(**i) for i in result.get("issues", [])],
                summary=result.get("summary", "")
            )
        except Exception as e:
            logger.error(f"Review failed: {e}")
            review = ReviewResult(
                approved=False,
                score=5,
                issues=[ReviewIssue(type="other", description=str(e), suggestion="请重试")],
                summary="审稿过程发生错误"
            )
        
        record = {
            "section": section.title,
            "score": review.score,
            "approved": review.approved,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        if review.approved:
            return await self._handle_approved(state, section, review, record)
        return await self._handle_rejected(state, section, review, record)
    
    async def _handle_approved(self, state, section, review, record):
        """审稿通过"""
        sections = state["sections"]
        idx = state["current_section_index"]
        updated = sections.copy()
        updated[idx] = section.model_copy(update={"status": "approved"})
        
        completed = state.get("sections_completed", [])
        completed.append(section.title)
        
        if idx + 1 >= len(sections):
            return {
                "sections": updated,
                "sections_completed": completed,
                "review_history": [record],
                "current_review": review.model_dump(),
                "status": "completed"
            }
        
        return {
            "sections": updated,
            "sections_completed": completed,
            "current_section_index": idx + 1,
            "review_history": [record],
            "current_review": review.model_dump(),
            "status": "writing"
        }
    
    async def _handle_rejected(self, state, section, review, record):
        """审稿未通过，需要修改"""
        sections = state["sections"]
        idx = state["current_section_index"]
        revision_count = state.get("revision_count", 0)
        max_revisions = state.get("max_revisions", settings.MAX_REVISIONS)
        
        if revision_count >= max_revisions:
            logger.warning(f"Max revisions reached, forcing approval")
            updated = sections.copy()
            updated[idx] = section.model_copy(update={"status": "approved"})
            return {
                "sections": updated,
                "review_history": [record],
                "status": "completed"
            }
        
        comments = [
            f"【第 {section.revision_count} 轮审稿】评分: {review.score}/10",
            f"意见: {review.summary}"
        ]
        for i, issue in enumerate(review.issues, 1):
            comments.append(f"问题 {i}: [{issue.type}] {issue.description}")
            comments.append(f"建议: {issue.suggestion}")
        
        updated = sections.copy()
        updated[idx] = section.model_copy(update={
            "status": "writing",
            "review_comments": section.review_comments + comments
        })
        
        return {
            "sections": updated,
            "review_history": [record],
            "current_review": review.model_dump(),
            "revision_count": revision_count + 1,
            "status": "writing"
        }
```

**设计决策：**

| 决策 | 选择 | 原因 |
|------|------|------|
| temperature | 0.3 (低温) | 审稿需要确定性强 |
| 评分阈值 | 7 分 | 中等偏上标准 |
| 最大返修 | 全局计数 | 避免无限循环 |
| 强制通过 | 超过上限 | 用户可接受最低质量 |

---

### 5.8 图编排

使用 LangGraph 将所有节点串联成完整的 Agent 工作流。

**文件：** `seele_agent/graph.py`

**create_writing_graph（带人工确认）**

```python
def create_writing_graph(
    openai_api_key: str = None,
    qdrant_client=None,
    embedding_model=None,
    semantic_scholar_key: str = None
) -> StateGraph:
    """创建论文写作图（带人工确认中断）"""
    from langchain_openai import ChatOpenAI
    
    api_key = openai_api_key or settings.OPENAI_API_KEY
    
    model = ChatOpenAI(
        model=settings.OPENAI_MODEL,
        api_key=api_key,
        temperature=settings.OPENAI_TEMPERATURE,
        max_tokens=settings.OPENAI_MAX_TOKENS
    )
    
    researcher = ResearcherNode(
        qdrant_client=qdrant_client,
        embedding_model=embedding_model,
        semantic_scholar_key=semantic_scholar_key or settings.SEMANTIC_SCHOLAR_API_KEY
    )
    planner = PlannerNode(model=model)
    writer = WriterNode(model=model)
    reviewer = ReviewerNode(model=model)
    
    graph = StateGraph(AgentState)
    
    graph.add_node("researcher", researcher.search)
    graph.add_node("planner", planner.plan)
    graph.add_node("writer", writer.write)
    graph.add_node("reviewer", reviewer.review)
    
    graph.add_edge(START, "researcher")
    graph.add_edge("researcher", "planner")
    
    # 关键：Planner 后中断，等待用户确认大纲
    graph.add_edge("planner", END, interrupt_after=["planner"])
    
    graph.add_edge("writer", "reviewer")
    
    def route_reviewer(state: AgentState) -> Literal["writer", END]:
        sections = state["sections"]
        idx = state["current_section_index"]
        
        if sections[idx].status == "approved":
            if idx + 1 >= len(sections):
                return END
            return "writer"
        
        return "writer"
    
    graph.add_conditional_edges(
        "reviewer",
        route_reviewer,
        {"writer": "writer", END: END}
    )
    
    return graph.compile(
        checkpointer=MemorySaver(),
        interrupt_after=["planner"]
    )
```

**create_simple_writing_graph（无中断）**

```python
def create_simple_writing_graph(openai_api_key: str = None) -> StateGraph:
    """简化版（无人工中断，全自动执行）"""
    from langchain_openai import ChatOpenAI
    
    api_key = openai_api_key or settings.OPENAI_API_KEY
    
    model = ChatOpenAI(
        model=settings.OPENAI_MODEL,
        api_key=api_key,
        temperature=settings.OPENAI_TEMPERATURE
    )
    
    researcher = ResearcherNode()
    planner = PlannerNode(model=model)
    writer = WriterNode(model=model)
    reviewer = ReviewerNode(model=model)
    
    graph = StateGraph(AgentState)
    
    graph.add_node("researcher", researcher.search)
    graph.add_node("planner", planner.plan)
    graph.add_node("writer", writer.write)
    graph.add_node("reviewer", reviewer.review)
    
    graph.add_edge(START, "researcher")
    graph.add_edge("researcher", "planner")
    graph.add_edge("planner", "writer")
    graph.add_edge("writer", "reviewer")
    
    def should_continue(state: AgentState) -> Literal["writer", END]:
        sections = state["sections"]
        idx = state["current_section_index"]
        if sections[idx].status == "approved" and idx + 1 >= len(sections):
            return END
        return "writer"
    
    graph.add_conditional_edges(
        "reviewer",
        should_continue,
        {"writer": "writer", END: END}
    )
    
    return graph.compile(checkpointer=MemorySaver())
```

**设计决策：**

| 决策 | 选择 | 原因 |
|------|------|------|
| interrupt_after | `["planner"]` | 只在大纲生成后中断 |
| Checkpointer | MemorySaver | 内存存储，开发方便 |
| 条件边 | 放在 Reviewer 后 | Writer 不知道该去哪 |
| 简化版 | 无 interrupt | 自动化测试用 |

---

### 5.9 包导出

**文件：** `seele_agent/__init__.py`

```python
"""Seele Scholar Agent - 学术论文写作 Agent"""

from .graph import create_writing_graph, create_simple_writing_graph
from .logging import setup_logging
from .state import AgentState, PaperMetadata, OutlineStructure, SectionDraft

__version__ = "0.1.0"

__all__ = [
    "create_writing_graph",
    "create_simple_writing_graph", 
    "setup_logging",
    "AgentState",
    "PaperMetadata",
    "OutlineStructure",
    "SectionDraft",
]
```

---

### 5.10 使用示例

```python
import asyncio
from seele_agent import create_writing_graph, setup_logging
from datetime import datetime

# 初始化
setup_logging()
graph = create_writing_graph(openai_api_key="sk-...")

# 初始状态
initial_state = {
    "thread_id": "session-001",
    "topic": "Large Language Model Compression",
    "created_at": datetime.now(),
    "outline_approved": False,  # 需要确认大纲
    "papers": [],
    "search_queries": [],
    "outline": None,
    "sections": [],
    "current_section_index": 0,
    "sections_completed": [],
    "review_history": [],
    "current_review": None,
    "rag_context": [],
    "status": "idle",
    "pending_node": None,
    "error_message": None,
    "max_revisions": 3,
    "revision_count": 0,
    "tenant_id": None
}

# 运行
async def main():
    async for event in graph.astream(
        initial_state,
        config={"configurable": {"thread_id": "session-001"}}
    ):
        if event.get("status") == "waiting_human":
            # 用户确认大纲
            print("请确认大纲:", event["outline"].title)
            graph.update_state(
                {"configurable": {"thread_id": "session-001"}},
                {"outline_approved": True}
            )
        
        if event.get("status") == "completed":
            print("论文生成完成!")
            for section in event["sections"]:
                print(f"- {section.title}")

asyncio.run(main())
```

---

### 5.11 依赖说明

完整实现所需依赖：

| 依赖 | 版本 | 用途 |
|------|------|------|
| langgraph | ≥0.0.40 | Agent 图编排 |
| langchain-core | ≥0.1.0 | LLM 调用框架 |
| langchain-openai | ≥0.0.5 | OpenAI GPT 接口 |
| langchain-community | ≥0.0.10 | ArXiv 工具 |
| pydantic | ≥2.0.0 | 数据验证 |
| pydantic-settings | ≥2.0.0 | 环境配置 |
| python-dotenv | ≥1.0.0 | .env 文件读取 |
| structlog | ≥24.0.0 | 结构化日志 |
| aiohttp | ≥3.9.0 | 异步 HTTP 客户端 |
| arxiv | ≥1.4.0 | ArXiv API 封装 |

---

### 5.12 常见问题

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| LLM 输出非 JSON | 模型问题 | 增加 prompt，强调 JSON 格式 |
| 无限循环 | 审稿一直不通过 | 检查 max_revisions 逻辑 |
| 状态丢失 | 未使用 Checkpointer | 使用 MemorySaver |
| context 过长 | 文献/章节太多 | 限制数量或分批处理 |
