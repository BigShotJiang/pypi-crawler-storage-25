from mail2task import extract_tasks


def test_extract_tasks():
    email = """
    Please submit the report by Friday.
    Schedule the meeting tomorrow.
    """

    tasks = extract_tasks(email)

    assert len(tasks) >= 1