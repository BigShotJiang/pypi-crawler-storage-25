import argparse
import json
import csv
from .extractor import extract_tasks


def save_csv(tasks, output_file):
    with open(output_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["title", "due_date", "priority", "confidence"]
        )

        writer.writeheader()
        writer.writerows(tasks)


def save_markdown(tasks, output_file):
    with open(output_file, "w", encoding="utf-8") as f:
        f.write("# Extracted Tasks\n\n")

        for task in tasks:
            f.write(f"## {task['title']}\n")
            f.write(f"- Due Date: {task['due_date']}\n")
            f.write(f"- Priority: {task['priority']}\n")
            f.write(f"- Confidence: {task['confidence']}\n\n")


def main():
    parser = argparse.ArgumentParser(
        description="Extract actionable tasks from emails"
    )

    parser.add_argument(
        "file",
        help="Path to the email text file"
    )

    parser.add_argument(
        "--pretty",
        action="store_true",
        help="Pretty print JSON output"
    )

    parser.add_argument(
        "--format",
        choices=["json", "csv", "markdown"],
        default="json",
        help="Output format"
    )

    parser.add_argument(
        "--output",
        help="Output file path"
    )

    args = parser.parse_args()

    try:
        with open(args.file, "r", encoding="utf-8") as f:
            content = f.read()

        tasks = extract_tasks(content)

        # JSON handling
        if args.format == "json":
            result = (
                json.dumps(tasks, indent=2)
                if args.pretty
                else json.dumps(tasks)
            )

            print(result)

            if args.output:
                with open(args.output, "w", encoding="utf-8") as out:
                    out.write(result)

        # CSV handling
        elif args.format == "csv":
            output_file = args.output or "tasks.csv"

            save_csv(tasks, output_file)

            print(f"CSV saved to {output_file}")

        # Markdown handling
        elif args.format == "markdown":
            output_file = args.output or "tasks.md"

            save_markdown(tasks, output_file)

            print(f"Markdown saved to {output_file}")

    except FileNotFoundError:
        print(f"File not found: {args.file}")

    except Exception as e:
        print(f"Error: {e}")