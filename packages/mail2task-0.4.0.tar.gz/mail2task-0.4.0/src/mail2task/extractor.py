import re
import dateparser


ACTION_WORDS = [
    "submit",
    "schedule",
    "send",
    "complete",
    "review",
    "update",
    "prepare",
    "finish",
    "call",
    "email",
    "organize",
    "create",
    "fix"
]


PRIORITY_KEYWORDS = {
    "high": ["urgent", "asap", "important", "immediately"],
    "medium": ["soon", "priority"],
    "low": ["later", "whenever"]
}


def clean_text(text: str):
    return re.sub(r"\s+", " ", text).strip()


def detect_priority(text: str):
    text_lower = text.lower()

    for level, keywords in PRIORITY_KEYWORDS.items():
        for keyword in keywords:
            if keyword in text_lower:
                return level

    return "normal"


def extract_due_date(text: str):
    date = dateparser.parse(
        text,
        settings={"PREFER_DATES_FROM": "future"}
    )

    if date:
        return date.isoformat()

    return None


def is_task_sentence(text: str):
    text_lower = text.lower()

    return any(word in text_lower for word in ACTION_WORDS)


def calculate_confidence(text: str, due_date, priority):
    score = 0.4

    text_lower = text.lower()

    # Action word boost
    if any(word in text_lower for word in ACTION_WORDS):
        score += 0.25

    # Due date boost
    if due_date:
        score += 0.2

    # Priority boost
    if priority != "normal":
        score += 0.1

    # Sentence length quality
    word_count = len(text.split())

    if 4 <= word_count <= 20:
        score += 0.05

    return round(min(score, 0.99), 2)


def extract_tasks(email_text: str):
    lines = email_text.splitlines()

    tasks = []
    seen_titles = set()

    for line in lines:
        line = clean_text(line)

        if not line:
            continue

        if len(line.split()) < 3:
            continue

        if not is_task_sentence(line):
            continue

        title = re.sub(
            r"\b(please|kindly)\b",
            "",
            line,
            flags=re.IGNORECASE
        ).strip()

        if title.lower() in seen_titles:
            continue

        seen_titles.add(title.lower())

        due_date = extract_due_date(line)
        priority = detect_priority(line)

        confidence = calculate_confidence(
            line,
            due_date,
            priority
        )

        task = {
            "title": title,
            "due_date": due_date,
            "priority": priority,
            "confidence": confidence
        }

        tasks.append(task)

    return tasks