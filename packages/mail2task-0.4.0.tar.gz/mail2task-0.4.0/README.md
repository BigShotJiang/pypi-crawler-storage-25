# mail2task

Extract actionable tasks from messy emails using Python.

## Features

- Extract task-like sentences
- Detect due dates
- Detect priority levels
- Clean JSON output
- CLI support

---

## Installation

```bash
pip install mail2task
```

---

## Usage

### Python

```python
from mail2task import extract_tasks

email = """
Please submit the compliance report by Friday.

Schedule the onboarding meeting tomorrow.
"""

tasks = extract_tasks(email)

print(tasks)
```

---

### CLI

Create a text file:

```text
Please submit the report by Friday.
Schedule the client call tomorrow.
```

Run:

```bash
mail2task sample_email.txt
```

Output:

```json
[
  {
    "title": "submit the report by Friday.",
    "due_date": "2026-05-29T00:00:00",
    "priority": "normal",
        "confidence": 0.9

  }
]
```

### Pretty Output

```bash
mail2task sample_email.txt --pretty
```

### Save Output

```bash
mail2task sample_email.txt --output tasks.json
```


## Export Formats

### JSON
```bash
mail2task sample_email.txt --format json
```

### CSV
```bash
mail2task sample_email.txt --format csv
```

### Markdown
```bash
mail2task sample_email.txt --format markdown
```


---

## Example Use Cases

- Email automation
- Productivity apps
- AI assistants
- CRM workflows
- Task management systems

---

## Project Structure

```text
mail2task/
├── src/
├── tests/
├── README.md
├── pyproject.toml
```

---

## License

MIT License