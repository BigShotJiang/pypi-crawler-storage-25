========
seriable
========

Overview
--------

seriable

Installation
------------

To install ``seriable``, you can use ``pip``. Open your terminal and run:

.. code-block:: bash

    pip install seriable

License
-------

This project is licensed under the MIT License.

Links
-----

* `Download <https://pypi.org/project/seriable/#files>`_
* `Index <https://pypi.org/project/seriable/>`_
* `Source <https://github.com/johannes-programming/seriable/>`_

Credits
-------

* Author: Johannes
* Email: `johannes.programming@gmail.com <mailto:johannes.programming@gmail.com>`_

Thank you for using ``seriable``!