from seriable.core import *
from seriable.tests import *

if __name__ == "__main__":
    main()
