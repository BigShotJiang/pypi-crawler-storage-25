from pathlib import Path
from typing import Dict, List

from funasr import AutoModel
from funasr_onnx.paraformer_online_bin import Paraformer as ParaformerONNX
from loguru import logger
import numpy as np
from pydantic import Field
import torch
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioChunk, AudioSpan, AudioToken, AudioTokenList
from fasr.model import StreamASRModel


@registry.stream_asr_models.register("stream_paraformer")
@registry.stream_asr_models.register("stream_paraformer.torch")
class ParaformerForStreamASR(StreamASRModel):
    """Paraformer streaming speech recognition model."""

    checkpoint: str = (
        "iic/speech_paraformer-large_asr_nat-zh-cn-16k-common-vocab8404-online"
    )
    endpoint: str = "modelscope"

    chunk_size_ms: int = 600  # chunk size in ms
    encoder_chunk_look_back: int = (
        4  # number of chunks to lookback for encoder self-attention
    )
    decoder_chunk_look_back: int = 1
    sample_rate: int = 16000

    paraformer: AutoModel | None = Field(
        default=None,
        exclude=True,
        description="Underlying funasr AutoModel handle populated by `load_checkpoint`.",
    )
    disable_update: bool = Field(default=True, description="Forwarded to AutoModel.")
    disable_log: bool = Field(default=True, description="Forwarded to AutoModel.")
    disable_pbar: bool = Field(default=True, description="Forwarded to AutoModel.")
    compile_model: bool = Field(
        default=False,
        description="If `True`, wrap the backend module with `torch.compile` (fullgraph + dynamic) to speed up steady-state inference at the cost of JIT warm-up.",
    )

    def push_chunk(self, chunk: AudioChunk) -> AudioSpan | None:
        if chunk.is_start and chunk.stream_id in self.states:
            logger.warning(
                "found start chunk with existing state, this is not expected"
            )
            del self.states[chunk.stream_id]
        state: Dict = self.states.get(chunk.stream_id, {})
        waveform = chunk.waveform
        if waveform.sample_rate != self.sample_rate:
            waveform = waveform.resample(self.sample_rate)
        sample_rate = waveform.sample_rate
        data = waveform.data
        chunk_size = int(self.chunk_size_ms * sample_rate / 1000)
        buffer = state.get("buffer", np.array([], dtype=np.float32))
        buffer = np.concatenate([buffer, data], axis=0)
        cache = state.get("cache", {})
        emitted: List[AudioToken] = state.get("emitted", [])
        new_tokens: List[AudioToken] = []
        if chunk.is_last:
            stream = self.paraformer.generate(
                input=buffer,
                cache=cache,
                is_final=True,
                chunk_size=[0, 10, 5],
                encoder_chunk_look_back=self.encoder_chunk_look_back,
                decoder_chunk_look_back=self.decoder_chunk_look_back,
            )
            for result in stream:
                if result["text"]:
                    new_tokens.append(AudioToken(text=result["text"]))
        else:
            while len(buffer) > chunk_size:
                input_data = buffer[:chunk_size]
                buffer = buffer[chunk_size:]
                stream = self.paraformer.generate(
                    input=input_data,
                    cache=cache,
                    is_final=False,
                    chunk_size=[0, 10, 5],  # chunk size 10 * 60ms
                    encoder_chunk_look_back=self.encoder_chunk_look_back,
                    decoder_chunk_look_back=self.decoder_chunk_look_back,
                )
                for result in stream:
                    if result["text"]:
                        new_tokens.append(AudioToken(text=result["text"]))
        emitted.extend(new_tokens)
        state["buffer"] = buffer
        state["cache"] = cache
        state["emitted"] = emitted
        self.states[chunk.stream_id] = state
        if chunk.is_last:
            self.states.pop(chunk.stream_id)
        if not new_tokens and not chunk.is_last:
            return None
        return AudioSpan(
            tokens=AudioTokenList(list(emitted)),
            is_last=bool(chunk.is_last),
        )

    def reset(self):
        self.states.clear()

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the streaming paraformer model from a local checkpoint directory."""
        if checkpoint_dir is None:
            if self.checkpoint is None:
                raise ValueError(
                    "Either `checkpoint_dir` or `self.checkpoint` must be set."
                )
            self.download_checkpoint()
            checkpoint_dir = self.checkpoint_dir
        checkpoint_dir = Path(checkpoint_dir)
        if not checkpoint_dir.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_dir}")
        self.paraformer = AutoModel(
            model=str(checkpoint_dir),
            disable_update=self.disable_update,
            disable_log=self.disable_log,
            disable_pbar=self.disable_pbar,
        )
        if self.compile_model:
            logger.info("using torch.compile for stream paraformer")
            self.paraformer.model = torch.compile(
                self.paraformer.model, fullgraph=True, dynamic=True
            )
        return self

    def get_config(self) -> Config:
        return Config(
            data={
                "stream_asr_model": {
                    "@stream_asr_models": "stream_paraformer",
                    "checkpoint": self.checkpoint,
                    "endpoint": self.endpoint,
                    "chunk_size_ms": self.chunk_size_ms,
                    "encoder_chunk_look_back": self.encoder_chunk_look_back,
                    "decoder_chunk_look_back": self.decoder_chunk_look_back,
                    "sample_rate": self.sample_rate,
                    "compile_model": self.compile_model,
                }
            }
        )


@registry.stream_asr_models.register("stream_paraformer.onnx")
class ParaformerForStreamASROnnx(StreamASRModel):
    """Paraformer streaming speech recognition model (ONNX runtime)."""

    checkpoint: str = (
        "iic/speech_paraformer-large_asr_nat-zh-cn-16k-common-vocab8404-online"
    )
    endpoint: str = "modelscope"
    chunk_size_ms: int = 600  # chunk size in ms
    encoder_chunk_look_back: int = (
        4  # number of chunks to lookback for encoder self-attention
    )
    decoder_chunk_look_back: int = 1
    sample_rate: int = 16000
    paraformer: ParaformerONNX | None = Field(
        default=None,
        exclude=True,
        description="Underlying funasr-onnx Paraformer handle populated by `load_checkpoint`.",
    )
    quantize: bool = Field(
        default=False,
        description="Use the quantized ONNX weights when available; trades accuracy for throughput.",
    )
    device: str | None = Field(
        default=None,
        description="Execution device (`'cpu'` / `'cuda'`); `None` auto-detects via `torch.cuda.is_available()`.",
    )
    intra_op_num_threads: int = Field(
        default=4, ge=0, description="ONNX Runtime intra-op thread count."
    )

    def push_chunk(self, chunk: AudioChunk) -> AudioSpan | None:
        if chunk.is_start and chunk.stream_id in self.states:
            logger.warning(
                "found start chunk with existing state, this is not expected"
            )
            del self.states[chunk.stream_id]
        state = self.states.get(chunk.stream_id, {})
        waveform = chunk.waveform
        if waveform.sample_rate != self.sample_rate:
            waveform = waveform.resample(self.sample_rate)
        sample_rate = waveform.sample_rate
        data = waveform.data
        chunk_size = int(self.chunk_size_ms * sample_rate / 1000)
        buffer = state.get("buffer", np.array([], dtype=np.float32))
        buffer = np.concatenate([buffer, data], axis=0)
        cache = state.get("cache", {})
        emitted: List[AudioToken] = state.get("emitted", [])
        new_tokens: List[AudioToken] = []
        param_dict = {"cache": cache}
        if chunk.is_last:
            param_dict["is_final"] = True
            stream = self.paraformer(
                audio_in=buffer,
                param_dict=param_dict,
            )
            for result in stream:
                if result["preds"]:
                    for t in result["preds"][1]:
                        new_tokens.append(AudioToken(text=t))
        else:
            while len(buffer) > chunk_size:
                audio_in = buffer[:chunk_size]
                buffer = buffer[chunk_size:]
                stream = self.paraformer(
                    audio_in=audio_in,
                    param_dict=param_dict,
                )
                for result in stream:
                    if result["preds"]:
                        for t in result["preds"][1]:
                            new_tokens.append(AudioToken(text=t))
        emitted.extend(new_tokens)
        state["buffer"] = buffer
        state["cache"] = cache
        state["emitted"] = emitted
        self.states[chunk.stream_id] = state
        if chunk.is_last:
            self.states.pop(chunk.stream_id)
        if not new_tokens and not chunk.is_last:
            return None
        return AudioSpan(
            tokens=AudioTokenList(list(emitted)),
            is_last=bool(chunk.is_last),
        )

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the ONNX streaming paraformer model from a local checkpoint directory."""
        if checkpoint_dir is None:
            if self.checkpoint is None:
                raise ValueError(
                    "Either `checkpoint_dir` or `self.checkpoint` must be set."
                )
            self.download_checkpoint()
            checkpoint_dir = self.checkpoint_dir
        checkpoint_dir = Path(checkpoint_dir)
        if not checkpoint_dir.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_dir}")

        device = self.device
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        device_id = 0 if device == "cuda" else -1

        self.paraformer = ParaformerONNX(
            model_dir=str(checkpoint_dir),
            chunk_size=[0, 10, 5],
            quantize=self.quantize,
            device_id=device_id,
            intra_op_num_threads=self.intra_op_num_threads,
        )
        return self

    def get_config(self) -> Config:
        return Config(
            data={
                "stream_asr_model": {
                    "@stream_asr_models": "stream_paraformer.onnx",
                    "checkpoint": self.checkpoint,
                    "endpoint": self.endpoint,
                    "chunk_size_ms": self.chunk_size_ms,
                    "encoder_chunk_look_back": self.encoder_chunk_look_back,
                    "decoder_chunk_look_back": self.decoder_chunk_look_back,
                    "sample_rate": self.sample_rate,
                    "quantize": self.quantize,
                    "device": self.device,
                    "intra_op_num_threads": self.intra_op_num_threads,
                }
            }
        )
