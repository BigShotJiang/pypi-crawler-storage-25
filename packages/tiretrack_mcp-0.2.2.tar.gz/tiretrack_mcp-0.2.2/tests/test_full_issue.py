"""Tests for the get_full_issue MCP tool (TT-52)."""

import json
from unittest.mock import AsyncMock, patch

from tiretrack_mcp.server import get_full_issue


MOCK_FULL_ISSUE = {
    "id": "abc-123",
    "key": "TT-1",
    "title": "Test Issue",
    "comments": [],
    "attachments": [],
    "outgoing_links": [],
    "incoming_links": [],
    "history_entries": [],
    "work_logs": [],
    "custom_field_values": [],
}


class TestGetFullIssue:
    async def test_issue_key_routes_to_key_endpoint(self) -> None:
        """Issue key like TT-1 should use the key-based endpoint."""
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = MOCK_FULL_ISSUE
            result = await get_full_issue("TT-1")

        mock_api.assert_called_once_with("GET", "/api/v1/issues/key/TT-1/full")
        parsed = json.loads(result)
        assert parsed["key"] == "TT-1"

    async def test_uuid_routes_to_uuid_endpoint(self) -> None:
        """UUID should use the UUID-based endpoint."""
        uuid = "550e8400-e29b-41d4-a716-446655440000"
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = MOCK_FULL_ISSUE
            await get_full_issue(uuid)

        mock_api.assert_called_once_with("GET", f"/api/v1/issues/{uuid}/full")

    async def test_lowercase_key_routes_to_key_endpoint(self) -> None:
        """Lowercase key like tt-1 should still use the key endpoint."""
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = MOCK_FULL_ISSUE
            await get_full_issue("tt-1")

        mock_api.assert_called_once_with("GET", "/api/v1/issues/key/tt-1/full")

    async def test_alphanumeric_project_key_routes_to_key_endpoint(self) -> None:
        """Project keys with digits like PROJ2-42 should use the key endpoint."""
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = MOCK_FULL_ISSUE
            await get_full_issue("PROJ2-42")

        mock_api.assert_called_once_with(
            "GET", "/api/v1/issues/key/PROJ2-42/full"
        )

    async def test_long_project_key(self) -> None:
        """Longer project keys like FRONTEND-123 should use the key endpoint."""
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = MOCK_FULL_ISSUE
            await get_full_issue("FRONTEND-123")

        mock_api.assert_called_once_with(
            "GET", "/api/v1/issues/key/FRONTEND-123/full"
        )

    async def test_returns_formatted_json(self) -> None:
        """Result should be formatted JSON with all inline fields."""
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = MOCK_FULL_ISSUE
            result = await get_full_issue("TT-1")

        parsed = json.loads(result)
        assert parsed["title"] == "Test Issue"
        assert "comments" in parsed
        assert "attachments" in parsed
        assert "outgoing_links" in parsed
        assert "incoming_links" in parsed
        assert "history_entries" in parsed
        assert "work_logs" in parsed
        assert "custom_field_values" in parsed
