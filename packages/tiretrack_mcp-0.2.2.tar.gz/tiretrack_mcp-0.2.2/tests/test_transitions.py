"""Tests for transition MCP tools."""

import json
from unittest.mock import AsyncMock, patch

import pytest

from tiretrack_mcp.server import get_transitions, transition_issue


# ---------------------------------------------------------------------------
# get_transitions
# ---------------------------------------------------------------------------


class TestGetTransitions:
    async def test_returns_formatted_json(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = [
                {"status": "in_progress", "name": "In Progress"},
                {"status": "done", "name": "Done"},
            ]
            result = await get_transitions("issue-uuid")

        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0]["status"] == "in_progress"
        assert parsed[1]["name"] == "Done"

        mock_api.assert_called_once_with(
            "GET", "/api/v1/issues/issue-uuid/transitions"
        )

    async def test_empty_list(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = []
            result = await get_transitions("issue-uuid")

        assert json.loads(result) == []


# ---------------------------------------------------------------------------
# transition_issue
# ---------------------------------------------------------------------------


class TestTransitionIssue:
    async def test_successful_transition(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {
                "id": "issue-uuid",
                "key": "TT-1",
                "status": "in_progress",
                "title": "Test Issue",
            }
            result = await transition_issue("issue-uuid", "in_progress")

        parsed = json.loads(result)
        assert parsed["status"] == "in_progress"

        mock_api.assert_called_once_with(
            "POST",
            "/api/v1/issues/issue-uuid/transitions",
            json_body={"to_status": "in_progress"},
        )

    async def test_passes_correct_status_values(self) -> None:
        """Verify various status values are passed through correctly."""
        for status_val in ["backlog", "dev_testing", "done", "cancelled"]:
            with patch(
                "tiretrack_mcp.server.api_request", new_callable=AsyncMock
            ) as mock_api:
                mock_api.return_value = {"id": "issue-uuid", "status": status_val}
                await transition_issue("issue-uuid", status_val)

            call_body = mock_api.call_args.kwargs["json_body"]
            assert call_body["to_status"] == status_val
