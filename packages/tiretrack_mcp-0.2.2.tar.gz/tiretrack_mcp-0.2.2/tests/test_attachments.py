"""Tests for attachment MCP tools."""

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from tiretrack_mcp.server import (
    DENIED_ATTACHMENT_EXTENSIONS,
    MAX_ATTACHMENT_SIZE_BYTES,
    add_attachment,
    delete_attachment,
    download_attachment,
    list_attachments,
)


@pytest.fixture
def png_file(tmp_path: Path) -> Path:
    """Create a small PNG file for testing."""
    png_bytes = (
        b"\x89PNG\r\n\x1a\n"
        b"\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01"
        b"\x08\x06\x00\x00\x00\x1f\x15\xc4\x89"
        b"\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01"
        b"\r\n\xb4\x00\x00\x00\x00IEND\xaeB`\x82"
    )
    f = tmp_path / "screenshot.png"
    f.write_bytes(png_bytes)
    return f


@pytest.fixture
def pdf_file(tmp_path: Path) -> Path:
    f = tmp_path / "notes.pdf"
    f.write_bytes(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n" + b"\x00" * 20)
    return f


def _presigned_stub(object_url: str = "https://cdn.example.com/obj") -> dict:
    return {
        "url": "https://s3.example.com/bucket",
        "fields": {
            "key": "uploads/abc123",
            "policy": "b64policy",
            "x-amz-signature": "sig",
            "Content-Type": "application/pdf",
        },
        "object_url": object_url,
        "max_size_bytes": MAX_ATTACHMENT_SIZE_BYTES,
    }


def _mock_client(mock_client_cls: AsyncMock) -> AsyncMock:
    mock_client = AsyncMock()
    mock_resp = AsyncMock()
    mock_resp.raise_for_status = lambda: None
    mock_client.post = AsyncMock(return_value=mock_resp)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client_cls.return_value = mock_client
    return mock_client


class TestAddAttachment:
    async def test_file_not_found(self) -> None:
        result = await add_attachment("issue-uuid", "/nonexistent/image.png")
        assert "Error: file not found" in result

    async def test_oversized_rejected(self, tmp_path: Path) -> None:
        big = tmp_path / "big.bin"
        big.write_bytes(b"\x00" * (MAX_ATTACHMENT_SIZE_BYTES + 1))
        result = await add_attachment("issue-uuid", str(big))
        assert "exceeds" in result.lower()

    async def test_denied_extension_rejected(self, tmp_path: Path) -> None:
        bad = tmp_path / "evil.exe"
        bad.write_bytes(b"\x00" * 10)
        result = await add_attachment("issue-uuid", str(bad))
        assert "blocked for security" in result.lower()

    async def test_successful_upload_flow(self, pdf_file: Path) -> None:
        """Full happy path: presigned POST → S3 POST → create attachment."""
        raw_bytes = pdf_file.read_bytes()

        with (
            patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api,
            patch("tiretrack_mcp.server.httpx.AsyncClient") as mock_client_cls,
        ):
            mock_api.side_effect = [
                _presigned_stub("https://cdn.example.com/doc.pdf"),
                {
                    "id": "att-123",
                    "filename": "notes.pdf",
                    "file_url": "https://cdn.example.com/doc.pdf",
                    "file_size": len(raw_bytes),
                    "mime_type": "application/pdf",
                },
            ]
            mock_client = _mock_client(mock_client_cls)

            result = await add_attachment("issue-uuid", str(pdf_file))

        parsed = json.loads(result)
        assert parsed["id"] == "att-123"
        assert parsed["filename"] == "notes.pdf"

        presigned_call = mock_api.call_args_list[0]
        assert presigned_call.args == ("POST", "/api/v1/uploads/presigned-url")
        assert presigned_call.kwargs["json_body"]["content_type"] == "application/pdf"
        assert presigned_call.kwargs["json_body"]["filename"] == "notes.pdf"

        post_kwargs = mock_client.post.call_args.kwargs
        assert post_kwargs["data"]["key"] == "uploads/abc123"
        assert post_kwargs["files"]["file"][0] == "notes.pdf"

        attach_call = mock_api.call_args_list[1]
        assert attach_call.args == ("POST", "/api/v1/issues/issue-uuid/attachments")
        body = attach_call.kwargs["json_body"]
        assert body["file_url"] == "https://cdn.example.com/doc.pdf"
        assert body["file_size"] == len(raw_bytes)
        assert body["mime_type"] == "application/pdf"

    async def test_unknown_extension_falls_back_to_octet_stream(self, tmp_path: Path) -> None:
        # No extension at all → mimetypes.guess_type returns None → octet-stream
        f = tmp_path / "opaque_blob"
        f.write_bytes(b"\x00" * 10)

        with (
            patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api,
            patch("tiretrack_mcp.server.httpx.AsyncClient") as mock_client_cls,
        ):
            mock_api.side_effect = [_presigned_stub(), {"id": "att-1"}]
            _mock_client(mock_client_cls)
            await add_attachment("issue-uuid", str(f))

        assert mock_api.call_args_list[0].kwargs["json_body"]["content_type"] == (
            "application/octet-stream"
        )


class TestListAttachments:
    async def test_returns_formatted_json(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = [
                {"id": "att-1", "filename": "a.png"},
                {"id": "att-2", "filename": "b.pdf"},
            ]
            result = await list_attachments("issue-uuid")

        parsed = json.loads(result)
        assert len(parsed) == 2
        mock_api.assert_called_once_with("GET", "/api/v1/issues/issue-uuid/attachments")


class TestDeleteAttachment:
    async def test_returns_success(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = {"status": "success"}
            result = await delete_attachment("issue-uuid", "att-123")

        parsed = json.loads(result)
        assert parsed["status"] == "success"
        mock_api.assert_called_once_with(
            "DELETE", "/api/v1/issues/issue-uuid/attachments/att-123"
        )


class TestDownloadAttachment:
    async def test_returns_download_url(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = {"download_url": "https://s3.example.com/get?sig=abc"}
            result = await download_attachment("issue-uuid", "att-123")

        parsed = json.loads(result)
        assert parsed["download_url"] == "https://s3.example.com/get?sig=abc"
        mock_api.assert_called_once_with(
            "GET", "/api/v1/issues/issue-uuid/attachments/att-123/download"
        )


class TestDenyList:
    def test_common_executables_are_denied(self) -> None:
        for ext in (".exe", ".msi", ".sh", ".bat", ".dmg", ".jar", ".apk"):
            assert ext in DENIED_ATTACHMENT_EXTENSIONS
