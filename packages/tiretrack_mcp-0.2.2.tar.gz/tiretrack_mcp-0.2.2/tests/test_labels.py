"""Tests for label MCP tools."""

import json
from unittest.mock import AsyncMock, patch

import pytest

from tiretrack_mcp.server import create_label, list_labels


# ---------------------------------------------------------------------------
# list_labels
# ---------------------------------------------------------------------------


class TestListLabels:
    async def test_returns_formatted_json(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = [
                {"id": "lbl-1", "name": "bug", "color": "#ff0000"},
                {"id": "lbl-2", "name": "feature", "color": "#00ff00"},
            ]
            result = await list_labels("proj-uuid")

        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0]["name"] == "bug"
        assert parsed[1]["name"] == "feature"

        mock_api.assert_called_once_with(
            "GET", "/api/v1/issues/project/proj-uuid/labels"
        )

    async def test_empty_list(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = []
            result = await list_labels("proj-uuid")

        assert json.loads(result) == []


# ---------------------------------------------------------------------------
# create_label
# ---------------------------------------------------------------------------


class TestCreateLabel:
    async def test_create_with_name_only(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {
                "id": "lbl-new",
                "name": "urgent",
            }
            result = await create_label("proj-uuid", "urgent")

        parsed = json.loads(result)
        assert parsed["id"] == "lbl-new"
        assert parsed["name"] == "urgent"

        mock_api.assert_called_once_with(
            "POST",
            "/api/v1/issues/project/proj-uuid/labels",
            json_body={"name": "urgent", "project_id": "proj-uuid"},
        )

    async def test_create_with_all_fields(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {
                "id": "lbl-full",
                "name": "enhancement",
                "color": "#00ff00",
                "description": "Feature improvements",
            }
            result = await create_label(
                "proj-uuid",
                "enhancement",
                color="#00ff00",
                description="Feature improvements",
            )

        parsed = json.loads(result)
        assert parsed["name"] == "enhancement"
        assert parsed["color"] == "#00ff00"
        assert parsed["description"] == "Feature improvements"

        mock_api.assert_called_once_with(
            "POST",
            "/api/v1/issues/project/proj-uuid/labels",
            json_body={
                "name": "enhancement",
                "project_id": "proj-uuid",
                "color": "#00ff00",
                "description": "Feature improvements",
            },
        )

    async def test_description_normalize_text(self) -> None:
        """Literal \\n sequences in description are converted to real newlines."""
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {"id": "lbl-1", "name": "test"}
            await create_label(
                "proj-uuid", "test", description="line1\\nline2"
            )

        call_body = mock_api.call_args.kwargs["json_body"]
        assert call_body["description"] == "line1\nline2"

    async def test_color_without_description(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {"id": "lbl-1", "name": "p0", "color": "#ff0000"}
            await create_label("proj-uuid", "p0", color="#ff0000")

        call_body = mock_api.call_args.kwargs["json_body"]
        assert call_body == {"name": "p0", "project_id": "proj-uuid", "color": "#ff0000"}
        assert "description" not in call_body

    async def test_description_without_color(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {"id": "lbl-1", "name": "docs"}
            await create_label("proj-uuid", "docs", description="Documentation tasks")

        call_body = mock_api.call_args.kwargs["json_body"]
        assert call_body == {"name": "docs", "project_id": "proj-uuid", "description": "Documentation tasks"}
        assert "color" not in call_body
