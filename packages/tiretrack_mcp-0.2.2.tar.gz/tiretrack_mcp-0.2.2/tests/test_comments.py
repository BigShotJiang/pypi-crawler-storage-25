"""Tests for comment MCP tools."""

import json
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from tiretrack_mcp.server import add_comment, delete_comment, list_comments, update_comment


# ---------------------------------------------------------------------------
# list_comments
# ---------------------------------------------------------------------------


class TestListComments:
    async def test_returns_formatted_json(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = [
                {"id": "c1", "content": "First", "is_edited": False},
                {"id": "c2", "content": "Second", "is_edited": True},
            ]
            result = await list_comments("issue-uuid")

        parsed = json.loads(result)
        assert len(parsed) == 2
        assert parsed[0]["content"] == "First"
        assert parsed[1]["is_edited"] is True

        mock_api.assert_called_once_with("GET", "/api/v1/issues/issue-uuid/comments")

    async def test_empty_list(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = []
            result = await list_comments("issue-uuid")

        assert json.loads(result) == []


# ---------------------------------------------------------------------------
# add_comment
# ---------------------------------------------------------------------------


class TestAddComment:
    async def test_sends_post_request(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {
                "id": "comment-new",
                "content": "Hello world",
                "is_edited": False,
            }
            result = await add_comment("issue-uuid", "Hello world")

        parsed = json.loads(result)
        assert parsed["id"] == "comment-new"
        assert parsed["content"] == "Hello world"

        mock_api.assert_called_once_with(
            "POST",
            "/api/v1/issues/issue-uuid/comments",
            json_body={"content": "Hello world"},
        )

    async def test_normalizes_newlines(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {"id": "c1", "content": "a\nb"}
            await add_comment("issue-uuid", "a\\nb")

        call_body = mock_api.call_args.kwargs["json_body"]
        assert call_body["content"] == "a\nb"


# ---------------------------------------------------------------------------
# update_comment
# ---------------------------------------------------------------------------


class TestUpdateComment:
    async def test_sends_patch_request(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {
                "id": "comment-1",
                "content": "Updated text",
                "is_edited": True,
            }
            result = await update_comment("issue-uuid", "comment-1", "Updated text")

        parsed = json.loads(result)
        assert parsed["id"] == "comment-1"
        assert parsed["content"] == "Updated text"
        assert parsed["is_edited"] is True

        mock_api.assert_called_once_with(
            "PATCH",
            "/api/v1/issues/issue-uuid/comments/comment-1",
            json_body={"content": "Updated text"},
        )

    async def test_normalizes_newlines(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {"id": "comment-1", "content": "line1\nline2"}
            await update_comment("issue-uuid", "comment-1", "line1\\nline2")

        call_body = mock_api.call_args.kwargs["json_body"]
        assert call_body["content"] == "line1\nline2"

    async def test_api_error_propagates(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.side_effect = httpx.HTTPStatusError(
                "404: Comment not found",
                request=httpx.Request("PATCH", "http://test"),
                response=httpx.Response(404),
            )
            with pytest.raises(httpx.HTTPStatusError):
                await update_comment("issue-uuid", "bad-id", "text")


# ---------------------------------------------------------------------------
# delete_comment
# ---------------------------------------------------------------------------


class TestDeleteComment:
    async def test_sends_delete_request(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {"status": "success"}
            result = await delete_comment("issue-uuid", "comment-1")

        parsed = json.loads(result)
        assert parsed["status"] == "success"

        mock_api.assert_called_once_with(
            "DELETE", "/api/v1/issues/issue-uuid/comments/comment-1"
        )

    async def test_api_error_propagates(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.side_effect = httpx.HTTPStatusError(
                "403: Forbidden",
                request=httpx.Request("DELETE", "http://test"),
                response=httpx.Response(403),
            )
            with pytest.raises(httpx.HTTPStatusError):
                await delete_comment("issue-uuid", "comment-1")
