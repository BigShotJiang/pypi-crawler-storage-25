"""Tests for issue link MCP tools."""

import json
from unittest.mock import AsyncMock, patch

from tiretrack_mcp.server import delete_issue_link, link_issues, list_issue_links


# ---------------------------------------------------------------------------
# link_issues
# ---------------------------------------------------------------------------


class TestLinkIssues:
    async def test_creates_link_with_correct_params(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {
                "id": "link-1",
                "link_type": "blocks",
                "source_issue_id": "issue-a",
                "target_issue_id": "issue-b",
            }
            result = await link_issues("issue-a", "issue-b", "blocks")

        parsed = json.loads(result)
        assert parsed["id"] == "link-1"
        assert parsed["link_type"] == "blocks"

        mock_api.assert_called_once_with(
            "POST",
            "/api/v1/issues/issue-a/links",
            json_body={"target_issue_id": "issue-b", "link_type": "blocks"},
        )

    async def test_defaults_to_relates_to(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = {"id": "link-1", "link_type": "relates_to"}
            await link_issues("issue-a", "issue-b")

        call_kwargs = mock_api.call_args.kwargs
        assert call_kwargs["json_body"]["link_type"] == "relates_to"


# ---------------------------------------------------------------------------
# list_issue_links
# ---------------------------------------------------------------------------


class TestListIssueLinks:
    async def test_returns_formatted_json(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = [
                {"id": "link-1", "link_type": "blocks", "target_issue_id": "issue-b"},
            ]
            result = await list_issue_links("issue-a")

        parsed = json.loads(result)
        assert len(parsed) == 1
        assert parsed[0]["link_type"] == "blocks"

        mock_api.assert_called_once_with("GET", "/api/v1/issues/issue-a/links")

    async def test_empty_list(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = []
            result = await list_issue_links("issue-a")

        assert json.loads(result) == []


# ---------------------------------------------------------------------------
# delete_issue_link
# ---------------------------------------------------------------------------


class TestDeleteIssueLink:
    async def test_returns_success_message(self) -> None:
        with patch(
            "tiretrack_mcp.server.api_request", new_callable=AsyncMock
        ) as mock_api:
            mock_api.return_value = None
            result = await delete_issue_link("issue-a", "link-1")

        assert result == "Link deleted successfully."

        mock_api.assert_called_once_with(
            "DELETE", "/api/v1/issues/issue-a/links/link-1"
        )
