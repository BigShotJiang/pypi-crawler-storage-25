"""Tests for lint_issue, suggest_improvements, and lint_project MCP tools."""

import json
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock, patch

import pytest

from tiretrack_mcp.server import lint_issue, lint_project, suggest_improvements


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_GOOD_ISSUE = {
    "id": "issue-uuid",
    "key": "TT-1",
    "title": "Fix login redirect after password reset",
    "description": "## Problem\nUsers are redirected to the wrong page after resetting their password.\n\n## Acceptance Criteria\n- [ ] Redirect lands on dashboard\n- [ ] Works in all supported browsers",
    "issue_type": "task",
    "priority": "high",
    "assignee_id": "user-uuid",
    "story_points": None,
    "updated_at": datetime.now(UTC).isoformat(),
    "status": "in_progress",
    "sprint_id": None,
}

_BAD_ISSUE = {
    "id": "issue-uuid-2",
    "key": "TT-2",
    "title": "Fix",  # too short
    "description": None,  # missing
    "issue_type": "story",
    "priority": "medium",
    "assignee_id": None,  # unassigned
    "story_points": None,  # story with no points
    "updated_at": "2026-01-01T00:00:00Z",  # stale
    "status": "in_progress",
    "sprint_id": "sprint-uuid",
}


# ---------------------------------------------------------------------------
# lint_issue
# ---------------------------------------------------------------------------


class TestLintIssue:
    async def test_good_issue_passes(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = _GOOD_ISSUE
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        assert parsed["issue_key"] == "TT-1"
        assert parsed["overall"] == "pass"
        assert all(c["status"] == "pass" for c in parsed["checks"])

    async def test_bad_issue_fails(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = _BAD_ISSUE
            result = await lint_issue("TT-2")

        parsed = json.loads(result)
        assert parsed["issue_key"] == "TT-2"
        assert parsed["overall"] == "fail"

    async def test_uses_key_endpoint_for_issue_key(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = _GOOD_ISSUE
            await lint_issue("TT-1")

        mock_api.assert_called_once_with("GET", "/api/v1/issues/key/TT-1")

    async def test_uses_uuid_endpoint_for_uuid(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = _GOOD_ISSUE
            await lint_issue("issue-uuid")

        mock_api.assert_called_once_with("GET", "/api/v1/issues/issue-uuid")

    async def test_title_too_short_fails(self) -> None:
        issue = {**_GOOD_ISSUE, "title": "Fix"}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        title_check = next(c for c in parsed["checks"] if c["name"] == "title_length")
        assert title_check["status"] == "fail"

    async def test_all_caps_title_fails(self) -> None:
        issue = {**_GOOD_ISSUE, "title": "FIX LOGIN BUG NOW PLEASE"}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        caps_check = next(c for c in parsed["checks"] if c["name"] == "title_no_all_caps")
        assert caps_check["status"] == "fail"

    async def test_lowercase_title_warns(self) -> None:
        issue = {**_GOOD_ISSUE, "title": "fix login redirect after password reset"}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        cap_check = next(c for c in parsed["checks"] if c["name"] == "title_starts_capital")
        assert cap_check["status"] == "warn"

    async def test_missing_description_fails(self) -> None:
        issue = {**_GOOD_ISSUE, "description": None}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        desc_check = next(c for c in parsed["checks"] if c["name"] == "description_present")
        assert desc_check["status"] == "fail"

    async def test_short_description_warns(self) -> None:
        issue = {**_GOOD_ISSUE, "description": "Short desc"}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        desc_check = next(c for c in parsed["checks"] if c["name"] == "description_present")
        assert desc_check["status"] == "warn"

    async def test_missing_acceptance_criteria_warns(self) -> None:
        issue = {**_GOOD_ISSUE, "description": "A long enough description without the magic section included here."}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        ac_check = next(c for c in parsed["checks"] if c["name"] == "has_acceptance_criteria")
        assert ac_check["status"] == "warn"

    async def test_unassigned_warns(self) -> None:
        issue = {**_GOOD_ISSUE, "assignee_id": None}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        assignee_check = next(c for c in parsed["checks"] if c["name"] == "assignee_set")
        assert assignee_check["status"] == "warn"

    async def test_story_without_points_warns(self) -> None:
        issue = {**_GOOD_ISSUE, "issue_type": "story", "story_points": None}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        sp_check = next(c for c in parsed["checks"] if c["name"] == "story_points_set")
        assert sp_check["status"] == "warn"

    async def test_story_with_points_passes(self) -> None:
        issue = {**_GOOD_ISSUE, "issue_type": "story", "story_points": 3}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        sp_check = next(c for c in parsed["checks"] if c["name"] == "story_points_set")
        assert sp_check["status"] == "pass"

    async def test_non_story_skips_story_points_check(self) -> None:
        issue = {**_GOOD_ISSUE, "issue_type": "task", "story_points": None}
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        sp_checks = [c for c in parsed["checks"] if c["name"] == "story_points_set"]
        assert sp_checks == []

    async def test_overall_warn_when_only_warnings(self) -> None:
        issue = {
            **_GOOD_ISSUE,
            "assignee_id": None,  # warn
        }
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await lint_issue("TT-1")

        parsed = json.loads(result)
        assert parsed["overall"] == "warn"


# ---------------------------------------------------------------------------
# suggest_improvements
# ---------------------------------------------------------------------------


class TestSuggestImprovements:
    async def test_no_suggestions_for_good_issue(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = _GOOD_ISSUE
            result = await suggest_improvements("TT-1")

        parsed = json.loads(result)
        assert parsed["suggestion_count"] == 0
        assert parsed["suggestions"] == []

    async def test_suggestions_for_bad_issue(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = _BAD_ISSUE
            result = await suggest_improvements("TT-2")

        parsed = json.loads(result)
        assert parsed["suggestion_count"] > 0
        checks_covered = {s["check"] for s in parsed["suggestions"]}
        assert "title_length" in checks_covered
        assert "description_present" in checks_covered

    async def test_high_priority_for_fails(self) -> None:
        issue = {**_GOOD_ISSUE, "title": "Fx"}  # too short → fail
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await suggest_improvements("TT-1")

        parsed = json.loads(result)
        title_suggestion = next(s for s in parsed["suggestions"] if s["check"] == "title_length")
        assert title_suggestion["priority"] == "high"

    async def test_medium_priority_for_warnings(self) -> None:
        issue = {**_GOOD_ISSUE, "assignee_id": None}  # warn
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = issue
            result = await suggest_improvements("TT-1")

        parsed = json.loads(result)
        assignee_suggestion = next(s for s in parsed["suggestions"] if s["check"] == "assignee_set")
        assert assignee_suggestion["priority"] == "medium"

    async def test_uses_key_endpoint(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = _GOOD_ISSUE
            await suggest_improvements("TT-1")

        mock_api.assert_called_once_with("GET", "/api/v1/issues/key/TT-1")

    async def test_uses_uuid_endpoint(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = _GOOD_ISSUE
            await suggest_improvements("issue-uuid")

        mock_api.assert_called_once_with("GET", "/api/v1/issues/issue-uuid")


# ---------------------------------------------------------------------------
# lint_project
# ---------------------------------------------------------------------------


class TestLintProject:
    def _make_issues(self, overrides: list[dict] | None = None) -> dict:
        base_issues = [
            {
                "id": "issue-1",
                "key": "TT-1",
                "issue_type": "task",
                "status": "in_progress",
                "priority": "medium",
                "assignee_id": "user-1",
                "sprint_id": None,
                "epic_id": None,
                "parent_id": None,
                "updated_at": datetime.now(UTC).isoformat(),
            },
        ]
        if overrides:
            base_issues.extend(overrides)
        return {"items": base_issues, "total": len(base_issues), "page": 1, "page_size": 100}

    async def test_clean_project_has_no_problems(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = self._make_issues()
            result = await lint_project("proj-uuid")

        parsed = json.loads(result)
        assert parsed["summary"]["issues_with_problems"] == 0
        assert parsed["issues_with_problems"] == []

    async def test_stale_in_progress_detected(self) -> None:
        old = (datetime.now(UTC) - timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%SZ")
        stale_issue = {
            "id": "issue-stale",
            "key": "TT-stale",
            "issue_type": "task",
            "status": "in_progress",
            "priority": "medium",
            "assignee_id": "user-1",
            "sprint_id": None,
            "epic_id": None,
            "parent_id": None,
            "updated_at": old,
        }
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = self._make_issues([stale_issue])
            result = await lint_project("proj-uuid")

        parsed = json.loads(result)
        assert parsed["summary"]["stale_in_progress"] == 1
        stale_entry = next(i for i in parsed["issues_with_problems"] if i["key"] == "TT-stale")
        assert any("stale_in_progress" in p for p in stale_entry["problems"])

    async def test_unassigned_in_sprint_detected(self) -> None:
        unassigned = {
            "id": "issue-unassigned",
            "key": "TT-unassigned",
            "issue_type": "task",
            "status": "todo",
            "priority": "medium",
            "assignee_id": None,
            "sprint_id": "sprint-active",
            "epic_id": None,
            "parent_id": None,
            "updated_at": "2026-03-17T12:00:00Z",
        }
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = self._make_issues([unassigned])
            result = await lint_project("proj-uuid")

        parsed = json.loads(result)
        assert parsed["summary"]["unassigned_in_sprint"] == 1
        entry = next(i for i in parsed["issues_with_problems"] if i["key"] == "TT-unassigned")
        assert "unassigned_in_sprint" in entry["problems"]

    async def test_high_priority_in_backlog_detected(self) -> None:
        high_prio = {
            "id": "issue-hi",
            "key": "TT-hi",
            "issue_type": "task",
            "status": "backlog",
            "priority": "high",
            "assignee_id": "user-1",
            "sprint_id": None,
            "epic_id": None,
            "parent_id": None,
            "updated_at": "2026-03-17T12:00:00Z",
        }
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = self._make_issues([high_prio])
            result = await lint_project("proj-uuid")

        parsed = json.loads(result)
        assert parsed["summary"]["high_priority_in_backlog"] == 1
        entry = next(i for i in parsed["issues_with_problems"] if i["key"] == "TT-hi")
        assert any("high_priority_in_backlog" in p for p in entry["problems"])

    async def test_epic_without_children_detected(self) -> None:
        epic = {
            "id": "epic-1",
            "key": "TT-epic",
            "issue_type": "epic",
            "status": "in_progress",
            "priority": "medium",
            "assignee_id": "user-1",
            "sprint_id": None,
            "epic_id": None,
            "parent_id": None,
            "updated_at": "2026-03-17T12:00:00Z",
        }
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = self._make_issues([epic])
            result = await lint_project("proj-uuid")

        parsed = json.loads(result)
        assert parsed["summary"]["epics_without_children"] == 1
        entry = next(i for i in parsed["issues_with_problems"] if i["key"] == "TT-epic")
        assert "epic_without_children" in entry["problems"]

    async def test_epic_with_children_ok(self) -> None:
        epic = {
            "id": "epic-1",
            "key": "TT-epic",
            "issue_type": "epic",
            "status": "in_progress",
            "priority": "medium",
            "assignee_id": "user-1",
            "sprint_id": None,
            "epic_id": None,
            "parent_id": None,
            "updated_at": "2026-03-17T12:00:00Z",
        }
        child = {
            "id": "child-1",
            "key": "TT-child",
            "issue_type": "story",
            "status": "todo",
            "priority": "medium",
            "assignee_id": "user-1",
            "sprint_id": None,
            "epic_id": "epic-1",
            "parent_id": None,
            "updated_at": "2026-03-17T12:00:00Z",
        }
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            issues = [epic, child]
            mock_api.return_value = {"items": issues, "total": 2, "page": 1, "page_size": 100}
            result = await lint_project("proj-uuid")

        parsed = json.loads(result)
        assert parsed["summary"]["epics_without_children"] == 0

    async def test_empty_project(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = {"items": [], "total": 0, "page": 1, "page_size": 100}
            result = await lint_project("proj-uuid")

        parsed = json.loads(result)
        assert parsed["summary"]["total_issues"] == 0
        assert parsed["issues_with_problems"] == []

    async def test_api_called_with_project_id(self) -> None:
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = {"items": [], "total": 0, "page": 1, "page_size": 100}
            await lint_project("proj-uuid")

        mock_api.assert_called_once_with(
            "GET",
            "/api/v1/issues/",
            params={"project_id": "proj-uuid", "page": 1, "page_size": 100},
        )

    async def test_highest_priority_in_backlog_detected(self) -> None:
        highest = {
            "id": "issue-highest",
            "key": "TT-highest",
            "issue_type": "task",
            "status": "backlog",
            "priority": "highest",
            "assignee_id": "user-1",
            "sprint_id": None,
            "epic_id": None,
            "parent_id": None,
            "updated_at": "2026-03-17T12:00:00Z",
        }
        with patch("tiretrack_mcp.server.api_request", new_callable=AsyncMock) as mock_api:
            mock_api.return_value = self._make_issues([highest])
            result = await lint_project("proj-uuid")

        parsed = json.loads(result)
        assert parsed["summary"]["high_priority_in_backlog"] == 1
