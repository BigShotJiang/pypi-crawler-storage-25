"""TireTrack MCP Server — project management tools for AI assistants."""
