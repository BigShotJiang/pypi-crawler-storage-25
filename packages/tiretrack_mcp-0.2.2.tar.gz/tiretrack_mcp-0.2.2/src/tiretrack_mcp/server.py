"""TireTrack MCP Server — tools for AI-powered project management."""

import mimetypes
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

import httpx
from mcp.server.fastmcp import FastMCP

from .api_client import api_request, format_response

ALLOWED_IMAGE_MIME_TYPES = {"image/png", "image/jpeg", "image/gif", "image/webp"}

MAX_ATTACHMENT_SIZE_BYTES = 10 * 1024 * 1024  # 10 MB — mirrors backend cap

DENIED_ATTACHMENT_EXTENSIONS = {
    ".exe",
    ".msi",
    ".bat",
    ".cmd",
    ".com",
    ".scr",
    ".ps1",
    ".sh",
    ".app",
    ".dmg",
    ".jar",
    ".vbs",
    ".js",
    ".dll",
    ".apk",
}


def _normalize_text(value: str) -> str:
    """Convert literal escape sequences (\\n, \\t) to real characters.

    LLMs often emit the two-character sequence ``\\n`` instead of an actual
    newline when calling MCP tools.  This helper ensures markdown descriptions
    and comments are stored with proper whitespace so they render correctly in
    the UI.
    """
    return value.replace("\\n", "\n").replace("\\t", "\t")


mcp = FastMCP(
    "TireTrack",
    instructions=(
        "TireTrack is a project management tool (like Jira). "
        "Use these tools to manage projects, issues, sprints, and team members. "
        "Issue keys look like PROJ-123. Statuses flow: backlog → todo → in_progress → dev_testing → done."
    ),
)

# ---------------------------------------------------------------------------
# Projects
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_projects(include_archived: bool = False) -> str:
    """List all projects the current user has access to.

    Returns project name, key, type (kanban/scrum), issue count, and archive status.

    Args:
        include_archived: Include archived projects in the results.
    """
    params = {}
    if include_archived:
        params["include_archived"] = "true"
    data = await api_request("GET", "/api/v1/projects/", params=params)
    return format_response(data)


@mcp.tool()
async def get_project(project_id: str) -> str:
    """Get detailed information about a specific project.

    Args:
        project_id: The project UUID.
    """
    data = await api_request("GET", f"/api/v1/projects/{project_id}")
    return format_response(data)


@mcp.tool()
async def create_project(
    name: str,
    key: str,
    description: str | None = None,
    project_type: Literal["kanban", "scrum"] = "kanban",
) -> str:
    """Create a new project. A default board with columns is created automatically.

    Args:
        name: Project display name (1-255 characters).
        key: Unique project key, 2-10 uppercase letters/numbers starting with a letter (e.g., 'TT', 'PROJ').
        description: Optional project description.
        project_type: Project methodology — 'kanban' or 'scrum'.
    """
    body: dict = {
        "name": name,
        "key": key.upper(),
        "project_type": project_type,
    }
    if description is not None:
        body["description"] = _normalize_text(description)
    data = await api_request("POST", "/api/v1/projects/", json_body=body)
    return format_response(data)


# ---------------------------------------------------------------------------
# Project Members
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_project_members(project_id: str) -> str:
    """List all members of a project with their roles.

    Args:
        project_id: The project UUID.
    """
    data = await api_request("GET", f"/api/v1/projects/{project_id}/members")
    return format_response(data)


@mcp.tool()
async def add_project_member(
    project_id: str,
    user_id: str,
    role: Literal["admin", "member", "viewer"] = "member",
) -> str:
    """Add a user to a project. Requires admin role on the project.

    Args:
        project_id: The project UUID.
        user_id: The user UUID to add.
        role: Role to assign — 'admin', 'member', or 'viewer'.
    """
    data = await api_request(
        "POST",
        f"/api/v1/projects/{project_id}/members",
        json_body={"user_id": user_id, "role": role},
    )
    return format_response(data)


# ---------------------------------------------------------------------------
# Issues
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_issues(
    project_id: str,
    status: Literal[
        "backlog",
        "new",
        "todo",
        "in_progress",
        "dev_testing",
        "qa_testing",
        "done",
        "cancelled",
    ]
    | None = None,
    assignee_id: str | None = None,
    issue_type: Literal["epic", "story", "task", "bug", "subtask"] | None = None,
    priority: Literal["highest", "high", "medium", "low", "lowest"] | None = None,
    sprint_id: str | None = None,
    search: str | None = None,
    page: int = 1,
    page_size: int = 25,
) -> str:
    """List issues in a project with optional filtering.

    Returns paginated results with issue key, title, status, assignee, priority, and type.

    Args:
        project_id: The project UUID (required).
        status: Filter by status.
        assignee_id: Filter by assignee user UUID.
        issue_type: Filter by issue type.
        priority: Filter by priority level.
        sprint_id: Filter by sprint UUID.
        search: Text search across issue titles and descriptions.
        page: Page number (default 1).
        page_size: Results per page (default 25, max 100).
    """
    params: dict = {"project_id": project_id, "page": page, "page_size": page_size}
    if status:
        params["status"] = status
    if assignee_id:
        params["assignee_id"] = assignee_id
    if issue_type:
        params["issue_type"] = issue_type
    if priority:
        params["priority"] = priority
    if sprint_id:
        params["sprint_id"] = sprint_id
    if search:
        params["search"] = search
    data = await api_request("GET", "/api/v1/issues/", params=params)
    return format_response(data)


@mcp.tool()
async def get_issue(issue_id: str) -> str:
    """Get full details of an issue by its UUID.

    Args:
        issue_id: The issue UUID.
    """
    data = await api_request("GET", f"/api/v1/issues/{issue_id}")
    return format_response(data)


@mcp.tool()
async def get_issue_by_key(issue_key: str) -> str:
    """Get full details of an issue by its key (e.g., 'PROJ-123').

    Args:
        issue_key: The issue key like 'TT-1' or 'PROJ-42'.
    """
    data = await api_request("GET", f"/api/v1/issues/key/{issue_key}")
    return format_response(data)


@mcp.tool()
async def get_full_issue(issue_id_or_key: str) -> str:
    """Get full details of an issue with all related data inline (comments, attachments, links, history, work logs, custom fields).

    Accepts either a UUID or an issue key (e.g., 'TT-1' or 'PROJ-42').

    Args:
        issue_id_or_key: The issue UUID or issue key.
    """
    if re.match(r"^[A-Za-z][A-Za-z0-9]*-\d+$", issue_id_or_key):
        data = await api_request("GET", f"/api/v1/issues/key/{issue_id_or_key}/full")
    else:
        data = await api_request("GET", f"/api/v1/issues/{issue_id_or_key}/full")
    return format_response(data)


@mcp.tool()
async def create_issue(
    project_id: str,
    title: str,
    issue_type: Literal["epic", "story", "task", "bug", "subtask"] = "task",
    priority: Literal["highest", "high", "medium", "low", "lowest"] = "medium",
    status: Literal[
        "backlog",
        "new",
        "todo",
        "in_progress",
        "dev_testing",
        "qa_testing",
        "done",
        "cancelled",
    ] = "todo",
    description: str | None = None,
    assignee_id: str | None = None,
    sprint_id: str | None = None,
    story_points: int | None = None,
    parent_id: str | None = None,
    epic_id: str | None = None,
) -> str:
    """Create a new issue in a project.

    The issue key (e.g., 'PROJ-1') is auto-generated from the project key.

    Args:
        project_id: The project UUID.
        title: Issue title (1-500 characters).
        issue_type: Type of issue.
        priority: Priority level.
        status: Initial status (default 'todo').
        description: Detailed description (supports markdown).
        assignee_id: UUID of the user to assign.
        sprint_id: UUID of the sprint to add this issue to.
        story_points: Estimated effort (0-100).
        parent_id: UUID of parent issue (for subtasks).
        epic_id: UUID of the epic this issue belongs to.
    """
    body: dict = {
        "project_id": project_id,
        "title": title,
        "issue_type": issue_type,
        "priority": priority,
        "status": status,
    }
    if description is not None:
        body["description"] = _normalize_text(description)
    if assignee_id is not None:
        body["assignee_id"] = assignee_id
    if sprint_id is not None:
        body["sprint_id"] = sprint_id
    if story_points is not None:
        body["story_points"] = story_points
    if parent_id is not None:
        body["parent_id"] = parent_id
    if epic_id is not None:
        body["epic_id"] = epic_id
    data = await api_request("POST", "/api/v1/issues/", json_body=body)
    return format_response(data)


@mcp.tool()
async def update_issue(
    issue_id: str,
    title: str | None = None,
    status: Literal[
        "backlog",
        "new",
        "todo",
        "in_progress",
        "dev_testing",
        "qa_testing",
        "done",
        "cancelled",
    ]
    | None = None,
    priority: Literal["highest", "high", "medium", "low", "lowest"] | None = None,
    issue_type: Literal["epic", "story", "task", "bug", "subtask"] | None = None,
    description: str | None = None,
    assignee_id: str | None = None,
    sprint_id: str | None = None,
    story_points: int | None = None,
    is_flagged: bool | None = None,
    flag_reason: str | None = None,
) -> str:
    """Update an existing issue. Only provide fields you want to change.

    Args:
        issue_id: The issue UUID.
        title: New title.
        status: New status.
        priority: New priority.
        issue_type: New issue type.
        description: New description.
        assignee_id: New assignee UUID (or empty string to unassign).
        sprint_id: New sprint UUID (or empty string to remove from sprint).
        story_points: New story point estimate.
        is_flagged: Flag or unflag the issue.
        flag_reason: Reason for flagging.
    """
    body: dict = {}
    if title is not None:
        body["title"] = title
    if status is not None:
        body["status"] = status
    if priority is not None:
        body["priority"] = priority
    if issue_type is not None:
        body["issue_type"] = issue_type
    if description is not None:
        body["description"] = _normalize_text(description)
    if assignee_id is not None:
        body["assignee_id"] = assignee_id or None
    if sprint_id is not None:
        body["sprint_id"] = sprint_id or None
    if story_points is not None:
        body["story_points"] = story_points
    if is_flagged is not None:
        body["is_flagged"] = is_flagged
    if flag_reason is not None:
        body["flag_reason"] = flag_reason
    data = await api_request("PATCH", f"/api/v1/issues/{issue_id}", json_body=body)
    return format_response(data)


# ---------------------------------------------------------------------------
# Transitions
# ---------------------------------------------------------------------------


@mcp.tool()
async def get_transitions(issue_id: str) -> str:
    """List available status transitions for an issue.

    Returns the statuses the issue can be moved to, based on the project's
    board column configuration.

    Args:
        issue_id: The issue UUID.
    """
    data = await api_request("GET", f"/api/v1/issues/{issue_id}/transitions")
    return format_response(data)


@mcp.tool()
async def transition_issue(
    issue_id: str,
    to_status: Literal[
        "backlog",
        "new",
        "todo",
        "in_progress",
        "dev_testing",
        "qa_testing",
        "done",
        "cancelled",
    ],
) -> str:
    """Transition an issue to a new status.

    Records the status change in the issue's history. The target status must
    be valid for the project's board configuration.

    Args:
        issue_id: The issue UUID.
        to_status: The status to transition to.
    """
    data = await api_request(
        "POST",
        f"/api/v1/issues/{issue_id}/transitions",
        json_body={"to_status": to_status},
    )
    return format_response(data)


# ---------------------------------------------------------------------------
# Bulk operations
# ---------------------------------------------------------------------------


@mcp.tool()
async def bulk_transition(
    issue_ids: list[str],
    to_status: Literal[
        "backlog",
        "new",
        "todo",
        "in_progress",
        "dev_testing",
        "qa_testing",
        "done",
        "cancelled",
    ],
) -> str:
    """Transition multiple issues to the same status in a single call.

    Records the status change in each issue's history. Returns per-issue
    success/failure so partial failures are visible.

    Args:
        issue_ids: List of issue UUIDs to transition.
        to_status: The status to transition all issues to.
    """
    data = await api_request(
        "POST",
        "/api/v1/issues/bulk/transition",
        json_body={"issue_ids": issue_ids, "to_status": to_status},
    )
    return format_response(data)


@mcp.tool()
async def bulk_add_comment(issue_ids: list[str], content: str) -> str:
    """Add the same comment to multiple issues in a single call.

    Returns per-issue success/failure so partial failures are visible.

    Args:
        issue_ids: List of issue UUIDs to comment on.
        content: Comment text to add to all issues (supports markdown).
    """
    data = await api_request(
        "POST",
        "/api/v1/issues/bulk/comment",
        json_body={"issue_ids": issue_ids, "content": _normalize_text(content)},
    )
    return format_response(data)


@mcp.tool()
async def get_issues_bulk(issue_ids: list[str]) -> str:
    """Fetch multiple issues by ID in a single call.

    Returns the found issues and a list of IDs that were not found or
    not accessible.

    Args:
        issue_ids: List of issue UUIDs to fetch.
    """
    data = await api_request(
        "POST",
        "/api/v1/issues/bulk",
        json_body={"issue_ids": issue_ids},
    )
    return format_response(data)


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_comments(issue_id: str) -> str:
    """List all comments on an issue.

    Args:
        issue_id: The issue UUID.
    """
    data = await api_request("GET", f"/api/v1/issues/{issue_id}/comments")
    return format_response(data)


@mcp.tool()
async def add_comment(issue_id: str, content: str) -> str:
    """Add a comment to an issue.

    Args:
        issue_id: The issue UUID.
        content: Comment text (supports markdown).
    """
    data = await api_request(
        "POST",
        f"/api/v1/issues/{issue_id}/comments",
        json_body={"content": _normalize_text(content)},
    )
    return format_response(data)


@mcp.tool()
async def update_comment(issue_id: str, comment_id: str, content: str) -> str:
    """Update an existing comment on an issue.

    Args:
        issue_id: The issue UUID.
        comment_id: The comment UUID.
        content: New comment text (supports markdown).
    """
    data = await api_request(
        "PATCH",
        f"/api/v1/issues/{issue_id}/comments/{comment_id}",
        json_body={"content": _normalize_text(content)},
    )
    return format_response(data)


@mcp.tool()
async def delete_comment(issue_id: str, comment_id: str) -> str:
    """Delete a comment from an issue.

    Args:
        issue_id: The issue UUID.
        comment_id: The comment UUID.
    """
    data = await api_request(
        "DELETE",
        f"/api/v1/issues/{issue_id}/comments/{comment_id}",
    )
    return format_response(data)


# ---------------------------------------------------------------------------
# Attachments
# ---------------------------------------------------------------------------


@mcp.tool()
async def add_attachment(
    issue_id: str,
    file_path: str,
    filename: str | None = None,
    mime_type: str | None = None,
) -> str:
    """Upload a local file and attach it to an issue.

    Accepts any file type up to 10 MB, except executables and scripts.

    Args:
        issue_id: The issue UUID.
        file_path: Absolute path to the file on disk (e.g., '/tmp/notes.pdf').
        filename: Optional display name for the attachment. Defaults to the file's basename.
        mime_type: Optional MIME type. Inferred from the file extension if not provided.
    """
    path = Path(file_path).expanduser().resolve()
    if not path.is_file():
        return f"Error: file not found: {path}"

    raw_bytes = path.read_bytes()
    if len(raw_bytes) > MAX_ATTACHMENT_SIZE_BYTES:
        return (
            f"Error: file is {len(raw_bytes)} bytes, exceeds the "
            f"{MAX_ATTACHMENT_SIZE_BYTES // (1024 * 1024)} MB limit."
        )

    if filename is None:
        filename = path.name

    if path.suffix.lower() in DENIED_ATTACHMENT_EXTENSIONS:
        return "Error: this file type is blocked for security reasons."

    if mime_type is None:
        mime_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"

    # 1. Get a presigned POST from the backend
    presigned = await api_request(
        "POST",
        "/api/v1/uploads/presigned-url",
        json_body={"content_type": mime_type, "filename": filename},
    )
    post_url: str = presigned["url"]  # type: ignore[index]
    post_fields: dict[str, str] = presigned["fields"]  # type: ignore[index]
    object_url: str = presigned["object_url"]  # type: ignore[index]

    # 2. POST the raw bytes directly to S3 (presigned policy enforces the size cap)
    async with httpx.AsyncClient(timeout=60.0) as client:
        post_resp = await client.post(
            post_url,
            data=post_fields,
            files={"file": (filename, raw_bytes, mime_type)},
        )
        post_resp.raise_for_status()

    # 3. Create the attachment record on the issue
    data = await api_request(
        "POST",
        f"/api/v1/issues/{issue_id}/attachments",
        json_body={
            "filename": filename,
            "file_url": object_url,
            "file_size": len(raw_bytes),
            "mime_type": mime_type,
        },
    )
    return format_response(data)


@mcp.tool()
async def list_attachments(issue_id: str) -> str:
    """List all attachments on an issue.

    Args:
        issue_id: The issue UUID.
    """
    data = await api_request("GET", f"/api/v1/issues/{issue_id}/attachments")
    return format_response(data)


@mcp.tool()
async def delete_attachment(issue_id: str, attachment_id: str) -> str:
    """Delete an attachment from an issue.

    Args:
        issue_id: The issue UUID.
        attachment_id: The attachment UUID.
    """
    data = await api_request(
        "DELETE", f"/api/v1/issues/{issue_id}/attachments/{attachment_id}"
    )
    return format_response(data)


@mcp.tool()
async def download_attachment(issue_id: str, attachment_id: str) -> str:
    """Get a presigned download URL for an attachment.

    Args:
        issue_id: The issue UUID.
        attachment_id: The attachment UUID.
    """
    data = await api_request(
        "GET", f"/api/v1/issues/{issue_id}/attachments/{attachment_id}/download"
    )
    return format_response(data)


# ---------------------------------------------------------------------------
# Labels
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_labels(project_id: str) -> str:
    """List all labels in a project.

    To assign labels to an issue, use ``update_issue`` with the ``label_ids`` parameter.

    Args:
        project_id: The project UUID.
    """
    data = await api_request("GET", f"/api/v1/issues/project/{project_id}/labels")
    return format_response(data)


@mcp.tool()
async def create_label(
    project_id: str,
    name: str,
    color: str | None = None,
    description: str | None = None,
) -> str:
    """Create a new label in a project.

    To assign the created label to an issue, use ``update_issue`` with the ``label_ids`` parameter.

    Args:
        project_id: The project UUID.
        name: Label name.
        color: Optional hex color code (e.g., '#ff0000').
        description: Optional label description.
    """
    body: dict = {"name": name, "project_id": project_id}
    if color is not None:
        body["color"] = color
    if description is not None:
        body["description"] = _normalize_text(description)
    data = await api_request(
        "POST", f"/api/v1/issues/project/{project_id}/labels", json_body=body
    )
    return format_response(data)


# ---------------------------------------------------------------------------
# Issue Links
# ---------------------------------------------------------------------------


@mcp.tool()
async def link_issues(
    source_issue_id: str,
    target_issue_id: str,
    link_type: Literal[
        "blocks",
        "is_blocked_by",
        "clones",
        "is_cloned_by",
        "duplicates",
        "is_duplicated_by",
        "implements",
        "is_implemented_by",
        "relates_to",
        "parent_of",
        "child_of",
    ] = "relates_to",
) -> str:
    """Create a link between two issues. The inverse link is created automatically.

    For example, linking A → B with 'blocks' also creates B → A with 'is_blocked_by'.

    Args:
        source_issue_id: UUID of the source issue.
        target_issue_id: UUID of the target issue.
        link_type: Type of relationship between the issues.
    """
    data = await api_request(
        "POST",
        f"/api/v1/issues/{source_issue_id}/links",
        json_body={"target_issue_id": target_issue_id, "link_type": link_type},
    )
    return format_response(data)


@mcp.tool()
async def list_issue_links(issue_id: str) -> str:
    """List all links for an issue (outgoing relationships).

    Each issue stores links from its own perspective, so 'blocks' on issue A
    appears as 'is_blocked_by' when querying issue B.

    Args:
        issue_id: The issue UUID.
    """
    data = await api_request("GET", f"/api/v1/issues/{issue_id}/links")
    return format_response(data)


@mcp.tool()
async def delete_issue_link(issue_id: str, link_id: str) -> str:
    """Delete a link and its inverse between two issues.

    Args:
        issue_id: The issue UUID that owns the link.
        link_id: The link UUID to delete.
    """
    await api_request("DELETE", f"/api/v1/issues/{issue_id}/links/{link_id}")
    return "Link deleted successfully."


# ---------------------------------------------------------------------------
# Sprints
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_sprints(
    project_id: str,
    status_filter: Literal["future", "active", "completed"] | None = None,
) -> str:
    """List sprints in a project, optionally filtered by status.

    Args:
        project_id: The project UUID.
        status_filter: Filter by sprint status.
    """
    params: dict = {}
    if status_filter:
        params["status_filter"] = status_filter
    data = await api_request(
        "GET", f"/api/v1/sprints/project/{project_id}", params=params
    )
    return format_response(data)


@mcp.tool()
async def get_sprint_metrics(sprint_id: str) -> str:
    """Get sprint metrics including burndown chart data and velocity history.

    Args:
        sprint_id: The sprint UUID.
    """
    data = await api_request("GET", f"/api/v1/sprints/{sprint_id}/metrics")
    return format_response(data)


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


@mcp.tool()
async def search_issues(query: str) -> str:
    """Search issues using JQL-like syntax.

    Supports fields: status, assignee, reporter, priority, type, labels, sprint,
    created, updated, due, story_points, flagged, text, key.

    Example queries:
    - 'status = in_progress AND assignee = me'
    - 'type = bug AND priority >= high'
    - 'text ~ "login error"'
    - 'sprint = "Sprint 5" AND status != done'

    Args:
        query: JQL-like search query string.
    """
    data = await api_request("POST", "/api/v1/search/", json_body={"jql": query})
    return format_response(data)


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------


@mcp.tool()
async def list_users() -> str:
    """List all active users in the system.

    Returns user UUID, email, full name, and avatar URL.
    """
    data = await api_request("GET", "/api/v1/users/")
    return format_response(data)


@mcp.tool()
async def get_current_user() -> str:
    """Get the currently authenticated user's profile."""
    data = await api_request("GET", "/api/v1/auth/me")
    return format_response(data)


# ---------------------------------------------------------------------------
# Quality Tools (lint / suggest)
# ---------------------------------------------------------------------------

_LINT_SUGGESTIONS: dict[str, dict[str, str]] = {
    "title_length": {
        "fail": "Expand the title to at least 10 characters so it clearly conveys the issue's purpose.",
    },
    "title_no_all_caps": {
        "fail": "Rewrite the title in sentence case — ALL CAPS titles are hard to read.",
    },
    "title_starts_capital": {
        "warn": "Capitalise the first word of the title for consistency.",
    },
    "description_present": {
        "fail": "Add a description explaining the problem, desired outcome, and relevant context.",
        "warn": "The description is very brief. Expand it to at least 50 characters covering the problem, context, and expected behaviour.",
    },
    "has_acceptance_criteria": {
        "warn": "Add an '## Acceptance Criteria' section listing the conditions that must be true for this issue to be considered done.",
        "fail": "Add a description with an '## Acceptance Criteria' section.",
    },
    "assignee_set": {
        "warn": "Assign this issue to a team member so responsibility is clear.",
    },
    "story_points_set": {
        "warn": "Estimate effort by setting story points to help with sprint planning and velocity tracking.",
    },
}


def _lint_issue_data(issue: dict) -> list[dict]:
    """Run heuristic quality checks on issue data. Returns list of check results."""
    checks: list[dict] = []

    # --- Title checks ---
    title: str = issue.get("title") or ""

    if len(title) < 10:
        checks.append(
            {
                "name": "title_length",
                "status": "fail",
                "message": f"Title is too short ({len(title)} chars, min 10)",
            }
        )
    else:
        checks.append(
            {
                "name": "title_length",
                "status": "pass",
                "message": "Title length is adequate",
            }
        )

    if title.strip() and title == title.upper() and any(c.isalpha() for c in title):
        checks.append(
            {
                "name": "title_no_all_caps",
                "status": "fail",
                "message": "Title should not be ALL CAPS",
            }
        )
    else:
        checks.append(
            {
                "name": "title_no_all_caps",
                "status": "pass",
                "message": "Title casing is appropriate",
            }
        )

    if title and not title[0].isupper():
        checks.append(
            {
                "name": "title_starts_capital",
                "status": "warn",
                "message": "Title should start with a capital letter",
            }
        )
    else:
        checks.append(
            {
                "name": "title_starts_capital",
                "status": "pass",
                "message": "Title starts with a capital letter",
            }
        )

    # --- Description checks ---
    description: str = issue.get("description") or ""

    if not description:
        checks.append(
            {
                "name": "description_present",
                "status": "fail",
                "message": "Description is missing",
            }
        )
    elif len(description) < 50:
        checks.append(
            {
                "name": "description_present",
                "status": "warn",
                "message": f"Description is very short ({len(description)} chars, min 50 recommended)",
            }
        )
    else:
        checks.append(
            {
                "name": "description_present",
                "status": "pass",
                "message": "Description is present",
            }
        )

    has_ac = bool(description) and (
        "## acceptance criteria" in description.lower()
        or "acceptance criteria:" in description.lower()
    )
    if not description:
        checks.append(
            {
                "name": "has_acceptance_criteria",
                "status": "fail",
                "message": "Cannot check acceptance criteria without a description",
            }
        )
    elif has_ac:
        checks.append(
            {
                "name": "has_acceptance_criteria",
                "status": "pass",
                "message": "Acceptance criteria section present",
            }
        )
    else:
        checks.append(
            {
                "name": "has_acceptance_criteria",
                "status": "warn",
                "message": "No acceptance criteria section found in description",
            }
        )

    # --- Assignee ---
    if not issue.get("assignee_id"):
        checks.append(
            {
                "name": "assignee_set",
                "status": "warn",
                "message": "Issue has no assignee",
            }
        )
    else:
        checks.append(
            {"name": "assignee_set", "status": "pass", "message": "Issue is assigned"}
        )

    # --- Story points (stories only) ---
    if issue.get("issue_type") == "story":
        if issue.get("story_points") is None:
            checks.append(
                {
                    "name": "story_points_set",
                    "status": "warn",
                    "message": "Story has no story points estimate",
                }
            )
        else:
            checks.append(
                {
                    "name": "story_points_set",
                    "status": "pass",
                    "message": f"Story points set ({issue['story_points']})",
                }
            )

    return checks


@mcp.tool()
async def lint_issue(issue_id_or_key: str) -> str:
    """Check issue quality using heuristic rules.

    Evaluates title length and casing, description presence, acceptance
    criteria, assignee, and (for stories) story points.  Returns a
    structured report with a pass / warn / fail result for each check.

    Accepts either a UUID or an issue key (e.g., 'TT-1' or 'PROJ-42').

    Args:
        issue_id_or_key: The issue UUID or issue key.
    """
    if re.match(r"^[A-Za-z][A-Za-z0-9]*-\d+$", issue_id_or_key):
        issue = await api_request("GET", f"/api/v1/issues/key/{issue_id_or_key}")
    else:
        issue = await api_request("GET", f"/api/v1/issues/{issue_id_or_key}")

    checks = _lint_issue_data(issue)  # type: ignore[arg-type]

    statuses = [c["status"] for c in checks]
    if "fail" in statuses:
        overall = "fail"
    elif "warn" in statuses:
        overall = "warn"
    else:
        overall = "pass"

    result = {
        "issue_key": issue.get("key", issue_id_or_key),  # type: ignore[union-attr]
        "title": issue.get("title", ""),  # type: ignore[union-attr]
        "overall": overall,
        "checks": checks,
    }
    return format_response(result)


@mcp.tool()
async def suggest_improvements(issue_id_or_key: str) -> str:
    """Return actionable suggestions to improve an issue's quality.

    Complements ``lint_issue`` with human-friendly guidance rather than raw
    pass / fail checks.  Accepts either a UUID or an issue key.

    Args:
        issue_id_or_key: The issue UUID or issue key.
    """
    if re.match(r"^[A-Za-z][A-Za-z0-9]*-\d+$", issue_id_or_key):
        issue = await api_request("GET", f"/api/v1/issues/key/{issue_id_or_key}")
    else:
        issue = await api_request("GET", f"/api/v1/issues/{issue_id_or_key}")

    checks = _lint_issue_data(issue)  # type: ignore[arg-type]

    suggestions = []
    for check in checks:
        if check["status"] in ("fail", "warn"):
            hint = _LINT_SUGGESTIONS.get(check["name"], {}).get(check["status"])
            if hint:
                suggestions.append(
                    {
                        "priority": "high" if check["status"] == "fail" else "medium",
                        "check": check["name"],
                        "suggestion": hint,
                    }
                )

    result = {
        "issue_key": issue.get("key", issue_id_or_key),  # type: ignore[union-attr]
        "title": issue.get("title", ""),  # type: ignore[union-attr]
        "suggestion_count": len(suggestions),
        "suggestions": suggestions,
    }
    return format_response(result)


@mcp.tool()
async def lint_project(project_id: str) -> str:
    """Audit all issues in a project for common quality problems.

    Checks for:
    - Issues ``in_progress`` for more than 14 days without an update
    - Unassigned issues in an active sprint
    - Epics with no child issues
    - High-priority issues sitting in ``backlog``

    Args:
        project_id: The project UUID.
    """
    # Fetch up to 200 issues (sufficient for most project audits)
    first_page = await api_request(
        "GET",
        "/api/v1/issues/",
        params={"project_id": project_id, "page": 1, "page_size": 100},
    )
    if isinstance(first_page, dict):
        issues: list[dict] = list(first_page.get("items", []))
        total: int = first_page.get("total", len(issues))
        page = 2
        while len(issues) < total and len(issues) < 200:
            more = await api_request(
                "GET",
                "/api/v1/issues/",
                params={"project_id": project_id, "page": page, "page_size": 100},
            )
            batch: list[dict] = (
                list(more.get("items", [])) if isinstance(more, dict) else list(more)
            )  # type: ignore[union-attr]
            if not batch:
                break
            issues.extend(batch)
            page += 1
    else:
        issues = list(first_page)  # type: ignore[arg-type]

    now = datetime.now(timezone.utc)

    # Build epic lookup: id → issue dict
    epic_by_id: dict[str, dict] = {
        issue["id"]: issue
        for issue in issues
        if issue.get("issue_type") == "epic" and issue.get("id")
    }
    epic_child_counts: dict[str, int] = {
        issue.get("key", issue["id"]): 0 for issue in epic_by_id.values()
    }

    # Count children (via epic_id or parent_id pointing at an epic)
    for issue in issues:
        if issue.get("issue_type") == "epic":
            continue
        for ref in (issue.get("epic_id"), issue.get("parent_id")):
            if ref and ref in epic_by_id:
                epic_key = epic_by_id[ref].get("key", ref)
                epic_child_counts[epic_key] = epic_child_counts.get(epic_key, 0) + 1
                break

    problems_by_key: dict[str, list[str]] = {}
    summary = {
        "stale_in_progress": 0,
        "unassigned_in_sprint": 0,
        "epics_without_children": 0,
        "high_priority_in_backlog": 0,
    }

    for issue in issues:
        key: str = issue.get("key") or issue.get("id", "?")
        issue_problems: list[str] = []

        status = issue.get("status", "")
        priority = issue.get("priority", "")
        sprint_id = issue.get("sprint_id")
        assignee_id = issue.get("assignee_id")
        updated_at_str: str | None = issue.get("updated_at")

        if status == "in_progress" and updated_at_str:
            try:
                updated_at = datetime.fromisoformat(
                    updated_at_str.replace("Z", "+00:00")
                )
                age_days = (now - updated_at).days
                if age_days > 14:
                    issue_problems.append(
                        f"stale_in_progress ({age_days} days without update)"
                    )
                    summary["stale_in_progress"] += 1
            except (ValueError, TypeError):
                pass

        if sprint_id and not assignee_id:
            issue_problems.append("unassigned_in_sprint")
            summary["unassigned_in_sprint"] += 1

        if status == "backlog" and priority in ("high", "highest"):
            issue_problems.append(f"high_priority_in_backlog (priority={priority})")
            summary["high_priority_in_backlog"] += 1

        if issue_problems:
            problems_by_key[key] = issue_problems

    for epic_key, child_count in epic_child_counts.items():
        if child_count == 0:
            problems_by_key.setdefault(epic_key, []).append("epic_without_children")
            summary["epics_without_children"] += 1

    issues_with_problems = [
        {"key": k, "problems": v} for k, v in sorted(problems_by_key.items())
    ]

    result = {
        "project_id": project_id,
        "summary": {
            "total_issues": len(issues),
            "issues_with_problems": len(issues_with_problems),
            **summary,
        },
        "issues_with_problems": issues_with_problems,
    }
    return format_response(result)
