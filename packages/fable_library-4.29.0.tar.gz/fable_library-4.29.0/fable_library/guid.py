import uuid

from .array_ import Array
from .core import FSharpRef, byte


def parse(string: str) -> uuid.UUID:
    return uuid.UUID(string.strip("()"))


def try_parse(string: str, def_value: FSharpRef[uuid.UUID]) -> bool:
    try:
        def_value.contents = parse(string)
        return True
    except Exception:
        return False


def to_string(guid: uuid.UUID) -> str:
    return str(guid)


def new_guid() -> uuid.UUID:
    return uuid.uuid4()


def guid_to_array(guid: uuid.UUID) -> Array[byte]:
    return Array[byte](byte(x) for x in guid.bytes_le)


def array_to_guid(guid: Array[byte]) -> uuid.UUID:
    return uuid.UUID(bytes_le=bytes(guid))


__all__ = [
    "array_to_guid",
    "guid_to_array",
    "new_guid",
    "parse",
    "to_string",
    "try_parse",
]
