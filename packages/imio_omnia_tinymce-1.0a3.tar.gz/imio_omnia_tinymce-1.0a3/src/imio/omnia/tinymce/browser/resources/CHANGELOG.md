# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Initial release.

### Added
- TinyMCE plugin with Omnia AI API integration
- Content manipulation: expand, improve, reduce, correct, accessibility, translate
- FloatingPanel for inline text transformations
- SidePanel for content generation
- SSE streaming with animated text output
- Keyboard shortcuts (Alt+prefix chord system)
- Storybook stories and integration test page
