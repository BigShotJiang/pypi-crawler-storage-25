/**
 * Factory for a mock TinyMCE editor instance.
 * Provides only the API surface the Omnia plugin actually uses.
 *
 * @param {{ selectedText?: string, rect?: DOMRect, container?: HTMLElement }} [opts]
 */
export function createMockEditor(opts = {}) {
  const {
    selectedText = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
    rect = { top: 200, left: 300, bottom: 220, right: 500, width: 200, height: 20 },
    container = null,
  } = opts;

  const listeners = new Map();
  let lastInserted = null;
  let lastSetContent = null;

  return {
    id: 'mock-editor-1',

    selection: {
      getContent() {
        return selectedText;
      },
      getRng() {
        return {
          getBoundingClientRect() {
            return rect;
          },
        };
      },
      setContent(html) {
        lastSetContent = html;
      },
    },

    insertContent(html) {
      lastInserted = html;
    },

    getContainer() {
      return container || document.body;
    },

    getBody() {
      return container || document.body;
    },

    on(event, callback) {
      if (!listeners.has(event)) listeners.set(event, new Set());
      listeners.get(event).add(callback);
    },

    off(event, callback) {
      listeners.get(event)?.delete(callback);
    },

    fire(event, data) {
      listeners.get(event)?.forEach((cb) => cb(data));
    },

    // Test helpers
    get _lastInserted() { return lastInserted; },
    get _lastSetContent() { return lastSetContent; },
  };
}
