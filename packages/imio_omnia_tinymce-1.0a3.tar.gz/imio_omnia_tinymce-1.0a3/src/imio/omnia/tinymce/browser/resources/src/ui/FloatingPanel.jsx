import { useState, useEffect, useRef } from 'preact/hooks';
import { motion, AnimatePresence, useDragControls, useMotionValue } from 'motion/react';
import { LANGUAGES as DEFAULT_LANGUAGES } from '../config.js';
import { PanelHeader } from './PanelHeader';
import { TypingDots, Button, INPUT_CLASS, AIDisclaimer } from './components';

const ACTION_LABELS = {
  'expand-text': 'Développer',
  'improve-text': 'Améliorer',
  'reduce-text': 'Réduire',
  'correct-text': 'Corriger',
  'make-accessible': 'Rendre accessible',
  'translate-text': 'Traduire',
};

// Actions that auto-start without user input
const AUTO_START_ACTIONS = new Set([
  'improve-text',
  'correct-text',
  'make-accessible',
  'expand-text',
  'reduce-text',
]);

const DEFAULT_INLINE_WIDTH = 380;
const BLUR_WIDTH = 560;

/**
 * Floating panel anchored near the text selection.
 *
 * Two display modes (controlled via the `mode` prop):
 *  - "inline": compact panel positioned near the selection, transparent overlay
 *  - "blur":   wider centred panel, blurred overlay
 *
 * @param {{
 *   editor: object,
 *   client: object,
 *   mode: 'inline'|'blur',
 *   action: string|null,
 *   onClose: () => void,
 *   onAccept: (text: string) => void,
 * }} props
 */
export function FloatingPanel({ editor, client, config = {}, mode = 'inline', action, onClose, onAccept }) {
  const [status, setStatus] = useState('idle');
  const [result, setResult] = useState('');
  const [error, setError] = useState(null);

  // Action-specific inputs
  const [targetLang, setTargetLang] = useState(config.defaultLanguage ?? 'fr');
  const languages = config.languages?.length ? config.languages : DEFAULT_LANGUAGES;

  const panelRef = useRef(null);
  const abortRef = useRef(null);
  const acceptRef = useRef(null);

  // Drag
  const dragControls = useDragControls();
  const dragX = useMotionValue(0);
  const dragY = useMotionValue(0);

  // Resize (user-driven)
  const inlineWidth = config.floatingPanelWidth ?? DEFAULT_INLINE_WIDTH;
  const isFullWidth = inlineWidth === 'full';
  const defaultWidth = mode === 'blur' ? BLUR_WIDTH : (isFullWidth ? window.innerWidth - 32 : inlineWidth);
  const [panelSize, setPanelSize] = useState({ width: defaultWidth, height: null });

  function onResizePointerDown(e) {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startY = e.clientY;
    const startWidth = panelRef.current.offsetWidth;
    const startHeight = panelRef.current.offsetHeight;

    const onMove = (ev) => {
      const newWidth = Math.max(280, Math.min(startWidth + ev.clientX - startX, window.innerWidth - 32));
      const newHeight = Math.max(120, Math.min(startHeight + ev.clientY - startY, window.innerHeight - 32));
      setPanelSize({ width: newWidth, height: newHeight });
    };
    const onUp = () => {
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
    };
    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
  }

  // Inline mode: position near the text selection
  useEffect(() => {
    if (mode !== 'inline' || !action || !panelRef.current || !editor) return;
    const panel = panelRef.current;
    const panelRect = panel.getBoundingClientRect();

    const rng = editor.selection.getRng();
    const selRect = rng.getBoundingClientRect();

    const iframe = editor.iframeElement;
    const iframeRect = iframe?.getBoundingClientRect() || { top: 0, left: 0 };

    const selBottom = iframeRect.top + selRect.bottom;
    const selTop = iframeRect.top + selRect.top;

    let top = selBottom + 8;
    if (top + panelRect.height > window.innerHeight - 16) {
      top = selTop - panelRect.height - 8;
    }
    top = Math.max(8, top);

    let left;
    if (isFullWidth) {
      left = 16;
    } else {
      const selLeft = iframeRect.left + selRect.left;
      const selWidth = selRect.width;
      left = selLeft + (selWidth - panelRect.width) / 2;
      left = Math.max(8, Math.min(left, window.innerWidth - panelRect.width - 8));
    }

    panel.style.top = `${top}px`;
    panel.style.left = `${left}px`;
  }, [action, editor, status]);

  // Blur mode: keep centred (re-runs on resize via panelSize dependency)
  useEffect(() => {
    if (mode !== 'blur' || !action || !panelRef.current) return;
    const panel = panelRef.current;
    const rect = panel.getBoundingClientRect();
    panel.style.top = `${Math.max(16, (window.innerHeight - rect.height) / 2)}px`;
    panel.style.left = `${Math.max(16, (window.innerWidth - rect.width) / 2)}px`;
  }, [action, status, panelSize]);

  // Keyboard: Escape to close, Enter to accept when done
  const keyRef = useRef(null);
  keyRef.current = (e) => {
    if (e.key === 'Escape') {
      handleClose();
    }
    if (e.key === 'Enter' && status === 'done') {
      const tag = e.target?.tagName;
      if (tag !== 'INPUT' && tag !== 'TEXTAREA' && tag !== 'SELECT') {
        e.preventDefault();
        handleAccept();
      }
    }
  };

  useEffect(() => {
    if (!action) return;
    const onKey = (e) => keyRef.current?.(e);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [action]);

  // Reset state when a new action starts (skip on close to preserve exit animation position)
  useEffect(() => {
    if (!action) return;

    setStatus('idle');
    setResult('');
    setError(null);
    setTargetLang(config.defaultLanguage ?? 'fr');
    setPanelSize({ width: defaultWidth, height: null });
    dragX.set(0);
    dragY.set(0);

    if (AUTO_START_ACTIONS.has(action)) {
      startAction();
    } else if (action) {
      // Auto-focus the first input/select in the panel
      requestAnimationFrame(() => {
        const el = panelRef.current?.querySelector('.omnia-input, .omnia-select');
        el?.focus();
      });
    }
  }, [action]);

  // Focus the accept button when result is ready
  useEffect(() => {
    if (status === 'done') {
      acceptRef.current?.focus();
    }
  }, [status]);

  function handleClose() {
    abortRef.current?.abort();
    onClose();
  }

  async function startAction() {
    const selectedText = editor.selection.getContent({ format: 'html' });
    if (!selectedText) return;

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setStatus('streaming');
    setError(null);
    setResult('');

    try {
      let text;
      if (action === 'expand-text') {
        text = await client.expandText(selectedText, { signal: controller.signal });
      } else if (action === 'improve-text') {
        text = await client.improveText(selectedText, { signal: controller.signal });
      } else if (action === 'reduce-text') {
        text = await client.reduceText(selectedText, { signal: controller.signal });
      } else if (action === 'correct-text') {
        text = await client.correctText(selectedText, { signal: controller.signal });
      } else if (action === 'make-accessible') {
        text = await client.makeAccessible(selectedText, { signal: controller.signal });
      } else if (action === 'translate-text') {
        text = await client.translateText(selectedText, targetLang, { signal: controller.signal });
      }
      if (!controller.signal.aborted) {
        setResult(text);
        setStatus('done');
      }
    } catch (err) {
      if (err.name !== 'AbortError') {
        setError(err.message);
        setStatus('error');
      }
    }
  }

  function handleAccept() {
    if (result) {
      onAccept(result);
    }
    onClose();
  }

  if (action && config.enabledFeatures && !config.enabledFeatures.includes(action)) {
    return null;
  }

  const backdropClass = mode === 'blur'
    ? 'omnia-backdrop om:fixed om:inset-0 om:z-[10000] om:bg-black/15 om:backdrop-blur-[2px]'
    : 'omnia-backdrop om:fixed om:inset-0 om:z-[10000] om:bg-black/5';

  const maxPreviewHeight = mode === 'blur' ? ' om:max-h-[50vh] om:overflow-y-auto' : ' om:max-h-[300px] om:overflow-y-auto';

  return (
    <AnimatePresence>
      {action && (
        <>
        {/* Backdrop overlay */}
        <motion.div
          key="backdrop"
          className={backdropClass}
          data-omnia
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          onMouseDown={handleClose}
        />
        <motion.div
          key={action}
          ref={panelRef}
          className="omnia-floating-panel omnia-panel om:fixed om:z-[10001] om:max-w-[calc(100vw-16px)] om:font-sans om:text-sm om:leading-relaxed om:text-gray-800 om:bg-white om:border om:border-gray-200 om:rounded-lg om:shadow-lg om:box-border om:flex om:flex-col om:overflow-hidden"
          data-omnia
          style={{ x: dragX, y: dragY, width: panelSize.width, ...(panelSize.height ? { height: panelSize.height } : {}) }}
          drag={mode !== 'blur'}
          dragListener={false}
          dragControls={dragControls}
          dragTransition={{ power: 0.1, timeConstant: 80 }}
          dragConstraints={{ left: -window.innerWidth / 2, right: window.innerWidth / 2, top: -window.innerHeight / 2, bottom: window.innerHeight / 2 }}
          dragElastic={0.1}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.15, ease: 'easeOut' }}
        >
          <div
            class={`omnia-panel__header om:flex om:shrink-0 om:items-center om:justify-between om:px-3 om:py-2.5 om:border-b om:border-gray-100 om:select-none${mode !== 'blur' ? ' om:cursor-grab om:active:cursor-grabbing' : ''}`}
            onPointerDown={mode !== 'blur' ? (e) => dragControls.start(e) : undefined}
          >
            <PanelHeader title={ACTION_LABELS[action] || action} />
            <Button variant="icon" onClick={handleClose} aria-label="Close">✕</Button>
          </div>

          <div class={`omnia-panel__body om:p-3${panelSize.height ? ' om:flex-1 om:min-h-0 om:overflow-y-auto' : ''}`}>
            {/* translate-text: language picker */}
            {action === 'translate-text' && status === 'idle' && (
              <div class="omnia-floating-panel__input-row om:flex om:gap-1.5 om:mb-2">
                <select
                  class={`omnia-select om:flex-1 ${INPUT_CLASS}`}
                  value={targetLang}
                  onChange={(e) => setTargetLang(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') startAction();
                  }}
                >
                  {languages.map((l) => (
                    <option key={l.code} value={l.code}>
                      {l.label}
                    </option>
                  ))}
                </select>
                <Button variant="primary" onClick={startAction}>Traduire</Button>
              </div>
            )}

            <div class={`omnia-stream-preview om:font-sans om:text-sm om:leading-relaxed om:text-gray-800 om:p-2 om:break-words${panelSize.height ? '' : maxPreviewHeight}`}>
              {status === 'streaming' && (
                <div class="om:flex om:justify-center om:py-4">
                  <TypingDots />
                </div>
              )}
              {status === 'done' && result && (
                <motion.div
                  className="omnia-stream-preview__text"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.2 }}
                  dangerouslySetInnerHTML={{ __html: result }}
                />
              )}
              {status === 'error' && (
                <motion.div
                  className="omnia-stream-preview__error om:flex om:items-center om:gap-2 om:text-red-600 om:text-[13px] om:mt-2"
                  initial={{ opacity: 0, x: -4 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <span>{error || 'An error occurred'}</span>
                  <Button variant="secondary" size="sm" onClick={startAction}>
                    Réessayer
                  </Button>
                </motion.div>
              )}
            </div>
          </div>

          <AnimatePresence>
            {status === 'done' && (
              <motion.div
                className="omnia-panel__footer om:flex om:shrink-0 om:flex-col om:border-t om:border-gray-100"
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 8 }}
                transition={{ duration: 0.15 }}
              >

                <div class="om:flex om:items-center om:justify-end om:gap-1.5 om:px-3 om:pt-3">
                  <Button onClick={handleClose}>Annuler</Button>
                  <Button ref={acceptRef} variant="primary" onClick={handleAccept} disabled={status !== 'done'}>
                    Accepter
                  </Button>
                </div>
                  <AIDisclaimer />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Resize handle */}
          <div
            class="omnia-resize-handle om:absolute om:bottom-0 om:right-0 om:w-6 om:h-6 om:cursor-nwse-resize om:flex om:items-end om:justify-end om:p-1 om:text-gray-400 om:opacity-60 om:transition-opacity hover:om:opacity-100"
            onPointerDown={onResizePointerDown}
          >
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
              <path d="M9 1L1 9" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>
              <path d="M9 5L5 9" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>
            </svg>
          </div>
        </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
