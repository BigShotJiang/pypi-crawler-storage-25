/**
 * Keyboard shortcut bindings for Omnia actions.
 *
 * Shortcuts follow the pattern: Alt+<prefix>, then a single letter.
 * Press Alt+<prefix>, release, then press the action letter within the configured delay.
 * Selection-based actions only fire when text is selected in the editor.
 *
 * Uses raw addEventListener on the capture phase so events are caught
 * before TinyMCE or other handlers can swallow them. Binds to both the
 * TinyMCE iframe document and the main document.
 */

/**
 * Bind keyboard shortcuts to Omnia actions.
 *
 * @param {object} editor - TinyMCE editor instance
 * @param {{ appRef: { current: object } }} ui - Mounted UI handle
 * @param {{ enabled: boolean, prefix: string, timeoutMs: number, bindings: Record<string, string> }} config
 * @returns {{ destroy: () => void }}
 */
export function bindShortcuts(editor, ui, config) {
  if (!config.enabled) {
    return { destroy() {} };
  }

  const keyToAction = Object.fromEntries(
    Object.entries(config.bindings).map(([action, key]) => [key, action]),
  );

  let awaitingAction = false;
  let resetTimer = null;

  function dispatch(action) {
    if (action === 'generate') {
      ui.appRef.current?.toggleSidePanel();
    } else {
      const content = editor.selection.getContent({ format: 'text' });
      if (content && content.trim().length > 0) {
        ui.appRef.current?.showFloatingPanel(action);
      }
    }
  }

  function onKeyDown(e) {
    // Step 2: we're waiting for the action letter after Alt+O
    if (awaitingAction) {
      awaitingAction = false;
      clearTimeout(resetTimer);

      // Ignore if any modifier is held (user might be doing something else)
      if (e.altKey || e.ctrlKey || e.metaKey) return;

      const action = keyToAction[e.key.toLowerCase()];
      if (action) {
        e.preventDefault();
        e.stopPropagation();
        dispatch(action);
      }
      return;
    }

    // Step 1: detect Alt+<prefix> (use e.code for cross-platform consistency)
    if (
      e.altKey &&
      !e.ctrlKey &&
      !e.metaKey &&
      e.code === `Key${config.prefix.toUpperCase()}`
    ) {
      e.preventDefault();
      e.stopPropagation();
      awaitingAction = true;
      resetTimer = setTimeout(() => {
        awaitingAction = false;
      }, config.timeoutMs);
    }
  }

  // Bind to the TinyMCE iframe document (capture phase to beat TinyMCE handlers)
  const editorDoc = editor.getDoc();
  editorDoc.addEventListener('keydown', onKeyDown, true);

  // Bind to the main document (for when focus is on toolbar / Omnia panels)
  document.addEventListener('keydown', onKeyDown, true);

  return {
    destroy() {
      editorDoc.removeEventListener('keydown', onKeyDown, true);
      document.removeEventListener('keydown', onKeyDown, true);
      clearTimeout(resetTimer);
    },
  };
}
