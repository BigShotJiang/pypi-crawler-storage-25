import defaultResponseHtml from '../presets/corriger-bulletin.html?raw';

/**
 * Split HTML into small stream-friendly chunks: tags are emitted whole,
 * text is split into short runs of 2-5 words.
 */
function chunkHtml(html) {
  const parts = [];
  const re = /(<[^>]+>)|([^<]+)/g;
  let m;
  while ((m = re.exec(html)) !== null) {
    if (m[1]) {
      // Tag — emit whole
      parts.push(m[1]);
    } else {
      // Text — split into small word groups
      const words = m[2].split(/(?<= )/); // split keeping trailing spaces
      let buf = '';
      let count = 0;
      const groupSize = 2 + Math.floor(Math.random() * 4); // 2-5
      for (const w of words) {
        buf += w;
        count++;
        if (count >= groupSize) {
          parts.push(buf);
          buf = '';
          count = 0;
        }
      }
      if (buf) parts.push(buf);
    }
  }
  return parts;
}

/**
 * Factory for a mock OmniaClient.
 *
 * @param {{ delay?: number, response?: string, error?: boolean }} [opts]
 *   - delay: ms before resolving (default 800)
 *   - response: HTML string returned by all agent methods
 *   - error: throw an error instead of returning a result
 *   - errorAfter: number of chunks to stream before the error (default: half)
 */
export function createMockOmniaClient(opts = {}) {
  const {
    delay = 800,
    response = defaultResponseHtml,
    error = false,
    errorAfter,
  } = opts;

  const chunks = chunkHtml(response);
  const fullText = response;

  async function resolve(signal) {
    await new Promise((res) => setTimeout(res, delay));
    if (signal?.aborted) return;
    if (error) throw new Error('Simulated API error');
    return fullText;
  }

  return {
    generate(prompt, options = {}) {
      async function* stream(signal) {
        const errorAt = error ? (errorAfter ?? Math.ceil(chunks.length / 2)) : Infinity;
        for (let i = 0; i < chunks.length; i++) {
          if (signal?.aborted) return;
          // Vary timing: tags are fast, text chunks get 80-200ms
          const isTag = chunks[i].startsWith('<');
          const ms = isTag ? 15 : 80 + Math.random() * 120;
          await new Promise((res) => setTimeout(res, ms));
          if (signal?.aborted) return;
          if (i === errorAt) throw new Error('Simulated API error');
          yield chunks[i];
        }
      }
      return stream(options.signal);
    },
    expandText(text, options = {}) {
      return resolve(options.signal);
    },
    improveText(text, options = {}) {
      return resolve(options.signal);
    },
    reduceText(text, options = {}) {
      return resolve(options.signal);
    },
    correctText(text, options = {}) {
      return resolve(options.signal);
    },
    makeAccessible(text, options = {}) {
      return resolve(options.signal);
    },
    translateText(text, targetLang, options = {}) {
      return resolve(options.signal);
    },
  };
}
