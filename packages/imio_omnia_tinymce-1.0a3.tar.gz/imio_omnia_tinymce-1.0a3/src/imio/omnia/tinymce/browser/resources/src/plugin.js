import tinymce from 'tinymce';
import omniaIcon from './assets/omnia-icon.svg?raw';
import { OmniaClient } from './client.js';
import { FEATURE_DEFS, registerOmniaOptions, resolveOmniaConfig } from './config.js';
import { mountOmniaUI } from './ui/mount.jsx';
import { bindShortcuts } from './shortcuts.js';

tinymce.PluginManager.add('omnia', (editor) => {
  registerOmniaOptions(editor);

  const baseUrl = editor.options.get('omnia_base_url');
  if (!baseUrl) {
    console.warn('[omnia] omnia_base_url is required');
    return;
  }

  const config = resolveOmniaConfig(editor);
  const enabledFeatureSet = new Set(config.enabledFeatures);

  const client = new OmniaClient({
    baseUrl,
    application: config.application,
    municipality: config.municipality,
    authToken: config.authToken,
    endpoints: config.endpoints,
    onError: (err) => console.error('[omnia]', err),
  });

  let ui = null;
  let shortcuts = null;

  editor.on('init', () => {
    ui = mountOmniaUI(editor, client, config);
    shortcuts = bindShortcuts(editor, ui, config.shortcuts);
  });

  editor.on('remove', () => {
    shortcuts?.destroy();
    shortcuts = null;
    ui?.destroy();
    ui = null;
  });

  function hasSelection() {
    const content = editor.selection.getContent({ format: 'text' });
    return content && content.trim().length > 0;
  }

  function showFloating(action) {
    if (enabledFeatureSet.has(action)) {
      ui?.appRef.current?.showFloatingPanel(action);
    }
  }

  function buildMainMenuItems() {
    const sel = hasSelection();
    const items = [];

    if (enabledFeatureSet.has('generate')) {
      items.push({
        type: 'menuitem',
        text: 'Générer du contenu',
        onAction: () => ui?.appRef.current?.toggleSidePanel(),
      });
    }

    const groups = [
      ['improve-text', 'correct-text'],
      ['expand-text', 'reduce-text'],
      ['make-accessible', 'translate-text'],
    ];

    for (const group of groups) {
      const groupFeatures = group
        .filter((id) => enabledFeatureSet.has(id))
        .map((id) => FEATURE_DEFS.find((f) => f.id === id))
        .filter(Boolean);

      if (groupFeatures.length === 0) continue;

      if (items.length > 0) {
        items.push({ type: 'separator' });
      }

      for (const feature of groupFeatures) {
        items.push({
          type: 'menuitem',
          text: feature.label,
          enabled: sel,
          onAction: () => showFloating(feature.id),
        });
      }
    }

    return items;
  }

  if (config.toolbar && config.enabledFeatures.length > 0) {
    editor.ui.registry.addIcon('omnia', omniaIcon);
    editor.ui.registry.addMenuButton('omnia', {
      icon: 'omnia',
      tooltip: "Assistant Omnia d'iMio",
      fetch: (callback) => callback(buildMainMenuItems()),
    });
  }

  for (const feature of FEATURE_DEFS) {
    if (!feature.menuItem || !enabledFeatureSet.has(feature.id)) {
      continue;
    }

    editor.ui.registry.addMenuItem(feature.menuItem.id, {
      icon: 'omnia',
      text: feature.menuItem.text,
      onAction: () => {
        if (feature.menu === 'panel') {
          ui?.appRef.current?.toggleSidePanel();
        } else {
          showFloating(feature.id);
        }
      },
    });
  }

  if (config.contextMenu) {
    editor.ui.registry.addContextMenu('omnia', {
      update: () => {
        if (hasSelection()) {
          return FEATURE_DEFS.filter(
            (feature) =>
              feature.menu === 'floating' &&
              feature.menuItem &&
              enabledFeatureSet.has(feature.id),
          )
            .map((feature) => feature.menuItem.id)
            .join(' ');
        }

        return enabledFeatureSet.has('generate') ? 'omnia-generate' : '';
      },
    });
  }
});
