import { defineConfig } from 'vite';
import preact from '@preact/preset-vite';
import tailwindcss from '@tailwindcss/vite';
import svgr from 'vite-plugin-svgr';

export default defineConfig({
  plugins: [preact(), tailwindcss(), svgr()],
  define: {
    'process.env.NODE_ENV': JSON.stringify('production'),
  },
  build: {
    lib: {
      entry: 'src/plugin.js',
      name: 'OmniaTinyMCE',
      formats: ['es', 'umd'],
      fileName: 'omnia-tinymce',
    },
    rollupOptions: {
      external: ['tinymce'],
      output: {
        globals: {
          tinymce: 'tinymce',
        },
      },
    },
  },
});
