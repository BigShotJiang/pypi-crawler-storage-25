/** @type { import('storybook').StorybookConfig } */
const config = {
  stories: ['../stories/**/*.stories.@(js|jsx)'],
  framework: {
    name: '@storybook/html-vite',
    options: {},
  },
  staticDirs: [{ from: '../node_modules/tinymce', to: '/tinymce' }],
  async viteFinal(config) {
    config.plugins = [...(config.plugins ?? []), mockApiPlugin()];

    // If VITE_OMNIA_BASE_URL is a full URL, proxy it to avoid CORS in the Live API story.
    const apiTarget = process.env.VITE_OMNIA_BASE_URL;
    if (apiTarget?.startsWith('http')) {
      const { origin, pathname } = new URL(apiTarget);
      config.server ??= {};
      config.server.proxy ??= {};
      config.server.proxy['/omnia-proxy'] = {
        target: origin,
        changeOrigin: true,
        rewrite: (path) => {
          const rewritten = path.replace(/^\/omnia-proxy/, pathname);
          console.log(`[omnia-proxy] ${path} → ${origin}${rewritten}`);
          return rewritten;
        },
      };
      // Point the client to the local proxy path instead of the remote URL.
      config.define ??= {};
      config.define['import.meta.env.VITE_OMNIA_BASE_URL'] = JSON.stringify('/omnia-proxy');
    }

    return config;
  },
};

export default config;

function mockApiPlugin() {
  return {
    name: 'omnia-mock-api',
    configureServer(server) {
      function sendSSE(res, text, delay = 40) {
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          Connection: 'keep-alive',
        });
        const words = text.split(' ');
        let i = 0;
        const interval = setInterval(() => {
          if (i >= words.length) {
            res.write('data: [DONE]\n\n');
            res.end();
            clearInterval(interval);
            return;
          }
          const chunk = (i > 0 ? ' ' : '') + words[i];
          res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
          i++;
        }, delay);
        res.on('close', () => clearInterval(interval));
      }

      function readBody(req) {
        return new Promise((resolve) => {
          let body = '';
          req.on('data', (c) => (body += c));
          req.on('end', () => {
            try { resolve(JSON.parse(body)); } catch { resolve({}); }
          });
        });
      }

      server.middlewares.use('/api/generate', async (req, res) => {
        const body = await readBody(req);
        sendSSE(res, `Voici le contenu généré pour : "${body.prompt || ''}". Ce texte a été produit par le serveur mock Omnia.`);
      });
      // Non-streaming agents endpoints
      const MOCK_DELAY = 1800;

      function sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms));
      }

      function sendJSON(res, result) {
        const payload = JSON.stringify({ result });
        res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) });
        res.end(payload);
      }

      server.middlewares.use('/api/v1/agents/expand-text', async (req, res) => {
        const body = await readBody(req);
        await sleep(MOCK_DELAY);
        sendJSON(res, `${body.input || ''} [Texte développé — version plus détaillée et enrichie du contenu original.]`);
      });
      server.middlewares.use('/api/v1/agents/improve-text', async (req, res) => {
        const body = await readBody(req);
        await sleep(MOCK_DELAY);
        sendJSON(res, `[Texte amélioré] ${body.input || ''}`);
      });
      server.middlewares.use('/api/v1/agents/reduce-text', async (req, res) => {
        const body = await readBody(req);
        await sleep(MOCK_DELAY);
        const words = (body.input || '').split(' ').slice(0, 20).join(' ');
        sendJSON(res, `${words}… [Texte réduit]`);
      });
      server.middlewares.use('/api/v1/agents/correct-text', async (req, res) => {
        const body = await readBody(req);
        await sleep(MOCK_DELAY);
        sendJSON(res, `[Texte corrigé] ${body.input || ''}`);
      });
      server.middlewares.use('/api/v1/agents/make-accessible', async (req, res) => {
        const body = await readBody(req);
        await sleep(MOCK_DELAY);
        sendJSON(res, `[Texte accessible WCAG] ${body.input || ''}`);
      });
      server.middlewares.use('/api/v1/agents/translate-text', async (req, res) => {
        const body = await readBody(req);
        await sleep(MOCK_DELAY);
        sendJSON(res, `[Traduit en ${body.target_language || 'fr'}] ${body.input || ''}`);
      });
    },
  };
}
