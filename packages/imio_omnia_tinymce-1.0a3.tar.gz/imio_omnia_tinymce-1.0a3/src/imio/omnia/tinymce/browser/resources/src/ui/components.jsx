import { forwardRef } from 'preact/compat';

/** HTML string for the blinking cursor — used to inject inline within innerHTML content. */
export const CURSOR_HTML =
  '<span class="omnia-stream-preview__cursor om:inline-block om:w-[3px] om:h-[1.3em] om:bg-[#E6007E] om:ml-[5px] om:mb-[1px] om:align-text-bottom om:animate-[omnia-blink_0.8s_step-end_infinite]" aria-label="Chargement…"></span>';

/** Blinking cursor shown during streaming / loading. */
export function Cursor() {
  return (
    <span
      class="omnia-stream-preview__cursor om:inline-block om:w-[3px] om:h-[1.3em] om:bg-[#E6007E] om:ml-[5px] om:mb-[1px] om:align-text-bottom om:animate-[omnia-blink_0.8s_step-end_infinite]"
      aria-label="Chargement…"
    />
  );
}

/** Three-dot typing animation shown while waiting for a non-streaming API response. */
export function TypingDots() {
  const dot = 'om:w-1.5 om:h-1.5 om:rounded-full om:bg-[#E6007E] om:opacity-30 om:animate-[omnia-typing_1.1s_ease-in-out_infinite]';
  return (
    <span class="omnia-typing om:inline-flex om:gap-1.5" aria-label="Chargement…">
      <span class={dot} />
      <span class={`${dot} om:[animation-delay:0.15s]`} />
      <span class={`${dot} om:[animation-delay:0.3s]`} />
    </span>
  );
}

/** Disclaimer shown below AI-generated content. */
export function AIDisclaimer() {
  return (
    <p class="omnia-ai-disclaimer om:border-t-1 om:border-gray-100 om:bg-gray-100 om:text-[10px] om:leading-snug om:text-gray-600 om:text-center om:px-3 om:py-1 om:mb-0 om:mt-3">
      L'intelligence artificielle peut commettre des erreurs, vérifiez les informations importantes.
    </p>
  );
}

/** Shared class string for text inputs, textareas and selects. */
export const INPUT_CLASS =
  'om:block om:w-full om:px-2.5 om:py-1.5 om:border om:border-gray-300 om:rounded om:text-[13px] om:leading-normal om:text-gray-800 om:bg-white om:font-[inherit] om:focus:outline-none om:focus:border-[#E6007E] om:focus:ring-2 om:focus:ring-[#E6007E]/15';

const BTN_BASE =
  'omnia-btn om:inline-flex om:items-center om:justify-center om:cursor-pointer om:transition-colors om:focus:outline-none om:disabled:opacity-50 om:disabled:cursor-not-allowed';

const BTN_VARIANTS = {
  primary: {
    md: 'omnia-btn--primary om:gap-1 om:px-3.5 om:py-1.5 om:border om:border-[#E6007E] om:rounded om:bg-[#E6007E] om:text-white om:text-[13px] om:leading-snug om:whitespace-nowrap om:hover:bg-[#CF0071] om:hover:border-[#CF0071] om:focus-visible:ring-2 om:focus-visible:ring-[#E6007E] om:focus-visible:ring-offset-2',
    sm: 'omnia-btn--primary omnia-btn--small om:gap-1 om:px-2 om:py-0.5 om:border om:border-[#E6007E] om:rounded om:bg-[#E6007E] om:text-white om:text-xs om:leading-snug om:whitespace-nowrap om:hover:bg-[#CF0071] om:hover:border-[#CF0071] om:focus-visible:ring-2 om:focus-visible:ring-[#E6007E] om:focus-visible:ring-offset-2',
  },
  secondary: {
    md: 'om:gap-1 om:px-3.5 om:py-1.5 om:border om:border-gray-300 om:rounded om:bg-white om:text-gray-700 om:text-[13px] om:leading-snug om:whitespace-nowrap om:hover:bg-gray-50 om:hover:border-gray-400 om:focus-visible:ring-2 om:focus-visible:ring-gray-400 om:focus-visible:ring-offset-2',
    sm: 'omnia-btn--small om:gap-1 om:px-2 om:py-0.5 om:border om:border-gray-300 om:rounded om:bg-white om:text-gray-700 om:text-xs om:leading-snug om:whitespace-nowrap om:hover:bg-gray-50 om:hover:border-gray-400 om:focus-visible:ring-2 om:focus-visible:ring-gray-400 om:focus-visible:ring-offset-2',
  },
  icon: 'omnia-btn--icon om:p-1 om:border-none om:bg-transparent om:text-gray-500 om:hover:text-gray-800 om:hover:bg-black/5',
};

/**
 * @param {{ variant?: 'primary'|'secondary'|'icon', size?: 'md'|'sm' }} props
 */
export const Button = forwardRef(function Button(
  { variant = 'secondary', size = 'md', class: className, children, ...props },
  ref,
) {
  const v = variant === 'icon' ? BTN_VARIANTS.icon : BTN_VARIANTS[variant]?.[size] ?? BTN_VARIANTS.secondary.md;
  return (
    <button ref={ref} class={`${BTN_BASE} ${v}${className ? ` ${className}` : ''}`} {...props}>
      {children}
    </button>
  );
});
