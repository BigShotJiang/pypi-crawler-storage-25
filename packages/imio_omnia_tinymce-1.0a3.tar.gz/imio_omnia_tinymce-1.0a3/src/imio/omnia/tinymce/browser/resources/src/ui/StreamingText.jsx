import { useState, useEffect, useRef } from 'preact/hooks';
import { motion } from 'motion/react';
import { Button } from './components';

/** Invisible inline marker injected at the end of the HTML to track cursor position.
 *  It inherits the surrounding font-size/line-height so its rect matches the text line. */
const MARKER_HTML = '<span data-omnia-cursor-marker style="display:inline;width:0;overflow:hidden;"></span>';

/**
 * Displays streaming AI output chunk by chunk with a fade-in effect.
 *
 * @param {{ stream: AsyncIterable|null, status: string, error: string|null, onComplete: (text: string) => void, onError: (err: Error) => void, onRetry: () => void }} props
 *   status: 'idle' | 'streaming' | 'done' | 'error'
 */
export function StreamingText({ stream, status, error, onComplete, onError, onRetry }) {
  const [settled, setSettled] = useState('');
  const [fresh, setFresh] = useState('');
  const containerRef = useRef(null);
  const textRef = useRef(null);
  const timerRef = useRef(null);
  const [cursorPos, setCursorPos] = useState(null);

  // Consume the stream when it changes
  useEffect(() => {
    if (!stream) return;

    let cancelled = false;
    setSettled('');
    setFresh('');
    setCursorPos(null);

    (async () => {
      let full = '';
      try {
        for await (const chunk of stream) {
          if (cancelled) break;

          // Promote previous fresh chunk to settled, set new fresh
          setSettled(full);
          setFresh(chunk);
          full += chunk;

          // After animation ends, fold fresh into settled
          clearTimeout(timerRef.current);
          timerRef.current = setTimeout(() => {
            if (!cancelled) {
              setSettled(full);
              setFresh('');
            }
          }, 320);
        }
        if (!cancelled) {
          setSettled(full);
          setFresh('');
          onComplete?.(full);
        }
      } catch (err) {
        if (!cancelled) {
          setSettled(full);
          setFresh('');
          onError?.(err);
        }
      }
    })();

    return () => {
      cancelled = true;
      clearTimeout(timerRef.current);
    };
  }, [stream]);

  const text = settled + fresh;

  // Auto-scroll to bottom while streaming + measure cursor position
  useEffect(() => {
    const container = containerRef.current;
    const textEl = textRef.current;
    if (!container || !textEl) return;

    if (status === 'streaming') {
      container.scrollTop = container.scrollHeight;
    }

    // Measure marker position in content coordinates (accounting for scroll)
    if (status === 'streaming') {
      const marker = textEl.querySelector('[data-omnia-cursor-marker]');
      if (marker) {
        const containerRect = container.getBoundingClientRect();
        const markerRect = marker.getBoundingClientRect();
        setCursorPos({
          x: markerRect.left - containerRect.left + container.scrollLeft,
          y: markerRect.top - containerRect.top + container.scrollTop,
          h: markerRect.height,
        });
      }
    }
  }, [text, status]);

  if (status === 'idle') {
    return <div class="omnia-stream-preview omnia-stream-preview--idle" />;
  }

  const markerSuffix = status === 'streaming' ? MARKER_HTML : '';
  const html = fresh
    ? settled + '<span class="omnia-stream-preview__new">' + fresh + '</span>' + markerSuffix
    : settled + markerSuffix;

  return (
    <div
      class="omnia-stream-preview om:relative om:font-sans om:text-sm om:leading-relaxed om:text-gray-800 om:max-h-[300px] om:overflow-y-auto om:p-2 om:break-words"
      ref={containerRef}
    >
      {(text || status === 'streaming') && (
        <div
          ref={textRef}
          class="omnia-stream-preview__text"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      )}

      {status === 'streaming' && cursorPos && (
        <motion.span
          class="omnia-stream-preview__cursor om:inline-block om:w-[3px] om:bg-[#E6007E] om:animate-[omnia-blink_0.8s_step-end_infinite]"
          aria-label="Chargement…"
          style={{ position: 'absolute', top: 0, left: 0, height: cursorPos.h }}
          animate={{ x: cursorPos.x, y: cursorPos.y }}
          transition={{ type: 'tween', duration: 0.08, ease: 'easeOut' }}
        />
      )}

      {status === 'error' && (
        <div class="omnia-stream-preview__error om:flex om:items-center om:gap-2 om:text-red-600 om:text-[13px] om:mt-2">
          <span>{error || 'An error occurred'}</span>
          {onRetry && (
            <Button variant="secondary" size="sm" onClick={onRetry}>
              Réessayer
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
