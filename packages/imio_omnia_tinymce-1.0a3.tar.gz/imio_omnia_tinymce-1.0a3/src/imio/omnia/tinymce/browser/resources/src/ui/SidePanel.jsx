import { useState, useEffect, useRef } from 'preact/hooks';
import { motion, AnimatePresence } from 'motion/react';
import { StreamingText } from './StreamingText';
import { PanelHeader } from './PanelHeader';
import { Button, INPUT_CLASS, AIDisclaimer } from './components';

const TONE_OPTIONS = [
  { value: '', label: 'Aucun (par défaut)' },
  { value: 'formal', label: 'Formel' },
  { value: 'casual', label: 'Informel' },
  { value: 'bullet_points', label: 'Points clés' },
  { value: 'concise', label: 'Concis' },
];

/**
 * Docked side panel for content generation.
 *
 * @param {{
 *   editor: object,
 *   client: object,
 *   visible: boolean,
 *   onClose: () => void,
 * }} props
 */
export function SidePanel({ editor, client, config = {}, visible, onClose }) {
  const [prompt, setPrompt] = useState('');
  const [tone, setTone] = useState('');
  const [status, setStatus] = useState('idle');
  const [stream, setStream] = useState(null);
  const [result, setResult] = useState('');
  const [error, setError] = useState(null);
  const [history, setHistory] = useState([]);
  const [viewingIndex, setViewingIndex] = useState(null);

  const abortRef = useRef(null);
  const textareaRef = useRef(null);
  const insertRef = useRef(null);

  function handleGenerate() {
    if (!prompt.trim()) return;

    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setStatus('streaming');
    setError(null);
    setResult('');
    setViewingIndex(null);

    const options = { signal: controller.signal };
    if (tone) options.tone = tone;

    const iter = client.generate(prompt, options);
    setStream(iter);
  }

  function handleStreamComplete(text) {
    setResult(text);
    setStatus('done');
    setHistory((prev) => [{ prompt, result: text, tone }, ...prev].slice(0, config.historyLimit ?? 10));
  }

  function handleStreamError(err) {
    if (err.name !== 'AbortError') {
      setError(err.message);
      setStatus('error');
    }
  }

  function handleInsert() {
    const text = viewingIndex != null ? history[viewingIndex].result : result;
    if (text && editor) {
      editor.insertContent(text);
      editor.selection.collapse(false);
      editor.focus();
    }
  }

  function handleCopy() {
    const text = viewingIndex != null ? history[viewingIndex].result : result;
    if (text) {
      navigator.clipboard.writeText(text).catch(() => {});
    }
  }

  function handleStop() {
    abortRef.current?.abort();
    setStatus('idle');
  }

  function viewHistoryItem(index) {
    setViewingIndex(index);
    setResult(history[index].result);
    setStream(null);
    setStatus('done');
  }

  const isViewing = viewingIndex != null;
  const displayResult = isViewing ? history[viewingIndex]?.result : result;

  // Keyboard: Escape to close, Enter to insert when done
  const keyRef = useRef(null);
  keyRef.current = (e) => {
    if (e.key === 'Escape') {
      onClose();
    }
    if (e.key === 'Enter' && status === 'done') {
      const tag = e.target?.tagName;
      if (tag !== 'TEXTAREA' && tag !== 'INPUT' && tag !== 'SELECT') {
        e.preventDefault();
        handleInsert();
      }
    }
  };

  useEffect(() => {
    if (!visible) return;
    const onKey = (e) => keyRef.current?.(e);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [visible]);

  // Auto-focus textarea on open, focus insert button when done
  useEffect(() => {
    if (visible) {
      requestAnimationFrame(() => textareaRef.current?.focus());
    }
  }, [visible]);

  useEffect(() => {
    if (status === 'done' && !isViewing) {
      insertRef.current?.focus();
    }
  }, [status]);

  if (config.enabledFeatures && !config.enabledFeatures.includes('generate')) {
    return null;
  }

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="omnia-side-panel omnia-panel om:fixed om:top-0 om:right-0 om:w-[340px] om:max-w-full om:h-screen om:z-[10000] om:rounded-none om:border-l om:border-gray-200 om:flex om:flex-col om:font-sans om:text-sm om:leading-relaxed om:text-gray-800 om:bg-white om:shadow-lg om:box-border"
          data-omnia
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        >
          <div class="omnia-panel__header om:flex om:items-center om:justify-between om:px-3 om:py-2.5 om:border-b om:border-gray-100">
            <PanelHeader title="Générer du texte" />
            <Button variant="icon" onClick={onClose} aria-label="Close">✕</Button>
          </div>

          <div class="omnia-panel__body omnia-side-panel__body om:p-3 om:flex-1 om:overflow-y-auto om:flex om:flex-col om:gap-3">
            {/* Prompt area */}
            <div class="omnia-side-panel__prompt-area om:flex om:flex-col om:gap-2">
              <textarea
                ref={textareaRef}
                class={`omnia-textarea ${INPUT_CLASS} om:resize-y om:min-h-[60px]`}
                placeholder="Décrivez le contenu à générer…"
                value={prompt}
                onInput={(e) => setPrompt(e.target.value)}
                disabled={status === 'streaming'}
                rows={3}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) handleGenerate();
                }}
              />

              <div class="omnia-side-panel__options om:flex om:gap-1.5">
                <select
                  class={`omnia-select om:flex-1 ${INPUT_CLASS}`}
                  value={tone}
                  onChange={(e) => setTone(e.target.value)}
                  disabled={status === 'streaming'}
                >
                  {TONE_OPTIONS.map((t) => (
                    <option key={t.value} value={t.value}>
                      {t.label}
                    </option>
                  ))}
                </select>

                {status === 'streaming' ? (
                  <Button onClick={handleStop}>Stop</Button>
                ) : (
                  <Button variant="primary" onClick={handleGenerate} disabled={!prompt.trim()}>
                    Générer
                  </Button>
                )}
              </div>
            </div>

            {/* Stream / result area */}
            {status !== 'idle' && !isViewing && (
              <div class="omnia-side-panel__result om:border om:border-gray-100 om:rounded-md om:overflow-hidden">
                <StreamingText
                  stream={stream}
                  status={status}
                  error={error}
                  onComplete={handleStreamComplete}
                  onError={handleStreamError}
                  onRetry={handleGenerate}
                />
                <AnimatePresence>
                  {status === 'done' && (
                    <motion.div
                      className="omnia-side-panel__result-actions om:flex om:gap-1.5 om:p-2 om:border-t om:border-gray-100"
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 8 }}
                      transition={{ duration: 0.15 }}
                    >
                      <Button ref={insertRef} variant="primary" size="sm" onClick={handleInsert}>
                        Insérer
                      </Button>
                      <Button variant="secondary" size="sm" onClick={handleCopy}>
                        Copier
                      </Button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* Viewing a history item */}
            {isViewing && (
              <div class="omnia-side-panel__result om:border om:border-gray-100 om:rounded-md om:overflow-hidden">
                <div class="omnia-stream-preview om:font-sans om:text-sm om:leading-relaxed om:text-gray-800 om:max-h-[300px] om:overflow-y-auto om:p-2 om:break-words">
                  <div class="omnia-stream-preview__text" dangerouslySetInnerHTML={{ __html: displayResult }} />
                </div>
                <div class="omnia-side-panel__result-actions om:flex om:gap-1.5 om:p-2 om:border-t om:border-gray-100">
                  <Button variant="primary" size="sm" onClick={handleInsert}>
                    Insérer
                  </Button>
                  <Button variant="secondary" size="sm" onClick={handleCopy}>
                    Copier
                  </Button>
                  <Button variant="secondary" size="sm" onClick={() => setViewingIndex(null)}>
                    Retour
                  </Button>
                </div>
              </div>
            )}

            {/* History */}
            {history.length > 0 && (
              <div class="omnia-side-panel__history om:mt-auto om:border-t om:border-gray-100 om:pt-2">
                <div class="omnia-side-panel__history-title om:text-[11px] om:font-semibold om:uppercase om:tracking-wide om:text-gray-400 om:mb-1.5">
                  Historique
                </div>
                {history.map((item, i) => (
                  <button
                    key={i}
                    class={`omnia-side-panel__history-item om:block om:w-full om:text-left om:px-2 om:py-1.5 om:border om:rounded om:bg-transparent om:cursor-pointer om:font-[inherit] om:text-xs om:leading-snug om:text-gray-600 om:mb-0.5 om:hover:bg-[#E6007E]/5 om:hover:border-[#E6007E]/20 ${
                      viewingIndex === i
                        ? 'omnia-side-panel__history-item--active om:bg-[#E6007E]/5 om:border-[#E6007E]/30'
                        : 'om:border-transparent'
                    }`}
                    onClick={() => viewHistoryItem(i)}
                  >
                    <div class="omnia-side-panel__history-prompt om:font-medium om:text-gray-800 om:whitespace-nowrap om:overflow-hidden om:text-ellipsis">
                      {item.prompt}
                    </div>
                    <div class="omnia-side-panel__history-preview om:text-gray-400 om:whitespace-nowrap om:overflow-hidden om:text-ellipsis">
                      {(() => { const t = item.result.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim(); return t.length > 80 ? t.slice(0, 80) + '…' : t; })()}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div class="omnia-panel__footer om:shrink-0">
            <AIDisclaimer />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
