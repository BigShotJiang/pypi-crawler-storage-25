import OmniaIcon from '../assets/omnia-icon.svg?react';

export function PanelHeader({ title }) {
  return (
    <div class="om:flex om:items-center om:gap-2">
        <span class="om:w-8 om:h-8 om:flex-shrink-0">
            <OmniaIcon className="om:h-8 om:w-8 om:pt-0.5" />
        </span>
      <div class="om:flex om:flex-col om:ml-2">
        <span class="om:text-[14px] om:text-gray-700">Omnia – L'assistant IA d'iMio</span>
        <span class="om:text-[14px] om:font-bold om:leading-none">{title}</span>
      </div>
    </div>
  );
}
