/** @type { import('storybook').Preview } */
const preview = {
  parameters: {
    layout: 'centered',
  },
};

export default preview;
