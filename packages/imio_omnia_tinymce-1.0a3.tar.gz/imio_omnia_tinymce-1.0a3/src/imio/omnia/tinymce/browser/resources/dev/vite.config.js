import { defineConfig } from 'vite';
import preact from '@preact/preset-vite';

/**
 * Vite config for the integration test page.
 * Includes a mock SSE API server via middleware.
 */
export default defineConfig({
  plugins: [
    preact(),
    mockApiPlugin(),
  ],
  root: '.',
});

function mockApiPlugin() {
  return {
    name: 'omnia-mock-api',
    configureServer(server) {
      // Shared SSE response helper
      function sendSSE(res, text, delay = 40) {
        res.writeHead(200, {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          Connection: 'keep-alive',
        });

        const words = text.split(' ');
        let i = 0;

        const interval = setInterval(() => {
          if (i >= words.length) {
            res.write('data: [DONE]\n\n');
            res.end();
            clearInterval(interval);
            return;
          }
          const chunk = (i > 0 ? ' ' : '') + words[i];
          res.write(`data: ${JSON.stringify({ chunk })}\n\n`);
          i++;
        }, delay);

        // Handle client disconnect
        res.on('close', () => clearInterval(interval));
      }

      function readBody(req) {
        return new Promise((resolve) => {
          let body = '';
          req.on('data', (chunk) => (body += chunk));
          req.on('end', () => {
            try { resolve(JSON.parse(body)); }
            catch { resolve({}); }
          });
        });
      }

      server.middlewares.use('/api/generate', async (req, res) => {
        const body = await readBody(req);
        sendSSE(res, `Voici le contenu généré pour : "${body.prompt || ''}". Ce texte a été produit par le serveur mock Omnia.`);
      });

      server.middlewares.use('/api/rewrite', async (req, res) => {
        const body = await readBody(req);
        sendSSE(res, `Texte réécrit selon l'instruction "${body.instruction || ''}": ${body.text || ''}`);
      });

      server.middlewares.use('/api/translate', async (req, res) => {
        const body = await readBody(req);
        sendSSE(res, `[Translated to ${body.target_lang || 'fr'}] ${body.text || ''}`);
      });

      server.middlewares.use('/api/summarize', async (req, res) => {
        sendSSE(res, 'Résumé : ce texte traite de sujets variés et importants pour le contexte.');
      });
    },
  };
}
