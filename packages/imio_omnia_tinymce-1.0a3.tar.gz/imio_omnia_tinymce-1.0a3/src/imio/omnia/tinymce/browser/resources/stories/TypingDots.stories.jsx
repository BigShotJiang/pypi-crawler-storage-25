import { render } from 'preact';
import { TypingDots } from '../src/ui/components';
import '../src/ui/omnia.css';

export default {
  title: 'TypingDots',
};

export const Default = () => {
  const el = document.createElement('div');
  el.setAttribute('data-omnia', '');
  el.style.padding = '32px';
  render(<TypingDots />, el);
  return el;
};

export const OnPanel = () => {
  const el = document.createElement('div');
  el.setAttribute('data-omnia', '');
  el.style.width = '380px';
  el.style.border = '1px solid #e5e7eb';
  el.style.borderRadius = '8px';
  el.style.boxShadow = '0 4px 12px rgba(0,0,0,.08)';
  render(
    <div class="om:flex om:justify-center om:py-6">
      <TypingDots />
    </div>,
    el,
  );
  return el;
};
