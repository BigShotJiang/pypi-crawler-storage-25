import { useState, useCallback, useImperativeHandle } from 'preact/hooks';
import { forwardRef } from 'preact/compat';
import { FloatingPanel } from './FloatingPanel';
import { SidePanel } from './SidePanel';
import './omnia.css';

/**
 * Root Omnia UI component. Manages which panels are visible.
 * Exposes control methods via ref.
 */
export const App = forwardRef(function App({ editor, client, config }, ref) {
  const [floatingAction, setFloatingAction] = useState(null);
  const [sidePanelVisible, setSidePanelVisible] = useState(false);

  // Expose imperative API to the plugin entry point
  useImperativeHandle(ref, () => ({
    showFloatingPanel(action) {
      setFloatingAction(action);
    },
    hideFloatingPanel() {
      setFloatingAction(null);
    },
    toggleSidePanel() {
      setSidePanelVisible((v) => !v);
    },
    showSidePanel() {
      setSidePanelVisible(true);
    },
    hideSidePanel() {
      setSidePanelVisible(false);
    },
  }));

  const handleFloatingClose = useCallback(() => {
    setFloatingAction(null);
  }, []);

  const handleFloatingAccept = useCallback(
    (text) => {
      if (editor) {
        editor.undoManager.transact(() => {
          editor.selection.setContent(text);
        });
        editor.selection.collapse(false);
        editor.focus();
      }
    },
    [editor],
  );

  const handleSidePanelClose = useCallback(() => {
    setSidePanelVisible(false);
  }, []);

  return (
    <>
      <FloatingPanel
        editor={editor}
        client={client}
        config={config}
        mode={config.floatingPanelMode}
        action={floatingAction}
        onClose={handleFloatingClose}
        onAccept={handleFloatingAccept}
      />
      <SidePanel
        editor={editor}
        client={client}
        config={config}
        visible={sidePanelVisible}
        onClose={handleSidePanelClose}
      />
    </>
  );
});
