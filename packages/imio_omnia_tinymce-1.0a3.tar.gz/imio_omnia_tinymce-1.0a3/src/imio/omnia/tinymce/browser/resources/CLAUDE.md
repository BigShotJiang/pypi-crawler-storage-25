# omnia-tinymce

TinyMCE plugin that integrates iMio's Omnia AI API for intelligent content manipulation (expansion, improvement, reduction, correction, accessibility, translation). Content generation (SidePanel) is implemented in the UI but not yet available server-side — it is disabled by default.

Published as `@imiobe/omnia-tinymce` on npm.

## Commands

- `make dev` / `npm run dev` — Start Storybook dev server on port 6006
- `make build` / `npm run build` — Build library to `dist/` (ES + UMD + CSS)
- `make build-storybook` / `npm run build-storybook` — Build static Storybook site
- `make dev-integration` / `npm run dev:integration` — Run integration test page with mock API on port 5173
- `make clean` — Remove `dist/` and `storybook-static/`
- `make publish` — Build and publish to npm

No linting or test runner is configured.

## Architecture

- **Entry point:** `src/plugin.js` — TinyMCE plugin registration, menu/toolbar setup
- **Client:** `src/client.js` — HTTP client with SSE streaming for the Omnia API
- **Config:** `src/config.js` — Feature definitions, option registration and validation
- **Shortcuts:** `src/shortcuts.js` — Keyboard shortcut binding (Alt+prefix chord system)
- **UI:** `src/ui/` — Preact components (FloatingPanel, SidePanel, StreamingText, TypingDots, etc.)
- **Stories:** `stories/` — Storybook stories with mock editor and client
- **Dev page:** `dev/` — Integration test page with mock API middleware
- **Docs:** `docs/images/` — Screenshots used in the README

The plugin builds as a library (UMD + ESM) via Vite. TinyMCE is a peer dependency (not bundled).

## Stack

- **Preact** for UI (functional components + hooks, aliased from React)
- **Vite** for builds (library mode) and dev server
- **Tailwind CSS v4** with `om:` prefix to scope styles and avoid host page conflicts
- **Motion** (Framer Motion) for animations
- **Storybook 10** (HTML framework) for component development

## Workflow

- When modifying a UI component, always update its corresponding Storybook stories in `stories/` to cover new props/modes.
- When adding or changing a TinyMCE option (`omnia_*`), also update the TinyMCE integration story (`stories/TinyMCEEditor.stories.js`): add the argType, pass it in `createEditor`, and set a default in `MockAPI.args`.
- Prefer Storybook **controls** (argTypes) over creating separate stories for each variant. Only create new stories when explicitly asked or for brand new components.
- The `generate` feature is disabled by default (`DEFAULT_ENABLED_FEATURES` in `src/config.js`) but should stay enabled in all Storybook stories for development.

## Code conventions

- Vanilla JS for business logic; JSX (Preact) for UI components only
- All Tailwind classes use the `om:` prefix (e.g. `om:flex`, `om:text-sm`)
- CSS scoped to `[data-omnia]` elements — no Tailwind preflight to avoid polluting the host
- Streaming responses use `async function*` generators
- Non-streaming agent responses show a `TypingDots` loader
- Root UI component (`App`) exposes imperative methods via `useImperativeHandle`
- Feature labels and UI text are in French
- Supported languages: fr, nl, de, en, es, it

## Environment

Copy `.env.example` to `.env` for Storybook "Omnia API" story. Variables:
- `VITE_OMNIA_BASE_URL` — Omnia API base URL
- `VITE_OMNIA_APPLICATION` — x-imio-application header
- `VITE_OMNIA_MUNICIPALITY` — x-imio-municipality header
