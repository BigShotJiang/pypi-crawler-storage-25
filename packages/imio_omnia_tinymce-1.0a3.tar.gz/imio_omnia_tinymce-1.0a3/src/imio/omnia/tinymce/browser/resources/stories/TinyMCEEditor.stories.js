import tinymce from 'tinymce';
import 'tinymce/models/dom';
import 'tinymce/themes/silver';
import 'tinymce/icons/default';
import 'tinymce/plugins/lists';
import 'tinymce/plugins/link';
import 'tinymce/plugins/image';
import 'tinymce/plugins/table';
import 'tinymce/plugins/charmap';
import 'tinymce/plugins/searchreplace';
import 'tinymce/plugins/fullscreen';
import 'tinymce/plugins/code';
import 'tinymce/plugins/wordcount';
import '../src/plugin.js';
import { FEATURE_IDS, LANGUAGES } from '../src/config.js';

import presetReduire from './presets/reduire-deliberation.html?raw';
import presetAmeliorer from './presets/ameliorer-communication.html?raw';
import presetAccessibilite from './presets/accessibilite-reglement.html?raw';
import presetTraduire from './presets/traduire-guide.html?raw';
import presetCorriger from './presets/corriger-bulletin.html?raw';
import presetLong from './presets/long-cdld.html?raw';

const PRESETS = {
  empty: '',
  'reduire': presetReduire,
  'ameliorer': presetAmeliorer,
  'accessibilite': presetAccessibilite,
  'traduire': presetTraduire,
  'corriger': presetCorriger,
  'long': presetLong,
};

const PRESET_LABELS = {
  empty: 'Vide',
  'reduire': 'Réduire — Délibération du Conseil communal',
  'ameliorer': 'Améliorer — Communication citoyenne',
  'accessibilite': 'Rendre accessible — Règlement des cimetières',
  'traduire': 'Traduire — Guide des démarches administratives',
  'corriger': 'Corriger — Bulletin communal',
  'long': 'Long — Code de la démocratie locale et de la décentralisation (CDLD)'
};

export default {
  title: 'TinyMCE Editor',
  parameters: {
    layout: 'fullscreen',
  },
  argTypes: {
    preset: {
      control: 'select',
      options: Object.keys(PRESETS),
      labels: PRESET_LABELS,
      description: 'Text preset to load in the editor',
      table: { category: 'Contenu' },
    },
    omnia_base_url: { control: 'text', description: 'Base URL for Omnia API', table: { category: 'Configuration Omnia' } },
    omnia_application: { control: 'text', description: 'Application identifier', table: { category: 'Configuration Omnia' } },
    omnia_municipality: { control: 'text', description: 'Municipality identifier', table: { category: 'Configuration Omnia' } },
    omnia_default_translate_language: {
      control: 'select',
      options: LANGUAGES.map((l) => l.code),
      description: 'Default language',
      table: { category: 'Configuration Omnia' },
    },
    omnia_enabled_features: {
      control: 'check',
      options: FEATURE_IDS,
      description: 'Enabled features',
      table: { category: 'Configuration Omnia' },
    },
    omnia_shortcuts: { control: 'boolean', description: 'Enable keyboard shortcuts', table: { category: 'Configuration Omnia' } },
    omnia_toolbar: { control: 'boolean', description: 'Show toolbar button', table: { category: 'Configuration Omnia' } },
    omnia_context_menu: { control: 'boolean', description: 'Show context menu items', table: { category: 'Configuration Omnia' } },
    omnia_translate_languages: {
      control: 'check',
      options: LANGUAGES.map((l) => l.code),
      description: 'Available languages',
      table: { category: 'Configuration Omnia' },
    },
    omnia_history_limit: { control: { type: 'number', min: 1, max: 50 }, description: 'History limit', table: { category: 'Configuration Omnia' } },
    omnia_floating_panel_mode: {
      control: 'select',
      options: ['inline', 'blur'],
      description: 'Floating panel display mode',
      table: { category: 'Configuration Omnia' },
    },
    omnia_floating_panel_width: {
      control: 'text',
      description: 'Inline panel width: a number (px) or "full"',
      table: { category: 'Configuration Omnia' },
    },
  },
};

function createEditor(el, args) {
  return new Promise((resolve) => {
    tinymce.init({
      target: el,
      skin_url: '/tinymce/skins/ui/oxide',
      content_css: '/tinymce/skins/content/default/content.min.css',
      license_key: 'gpl',
      height: '100%',
      plugins: 'omnia lists link image table charmap searchreplace fullscreen code wordcount',
      toolbar:
        'undo redo | omnia | styles | bold italic underline strikethrough | ' +
        'bullist numlist outdent indent | link image table charmap | ' +
        'searchreplace fullscreen code',
      contextmenu: 'link image table' + (args.omnia_context_menu ? ' omnia' : ''),
      omnia_base_url: args.omnia_base_url,
      omnia_application: args.omnia_application,
      omnia_municipality: args.omnia_municipality,
      omnia_default_translate_language: args.omnia_default_translate_language,
      omnia_enabled_features: args.omnia_enabled_features,
      omnia_shortcuts: args.omnia_shortcuts,
      omnia_toolbar: args.omnia_toolbar,
      omnia_context_menu: args.omnia_context_menu,
      omnia_translate_languages: args.omnia_translate_languages,
      omnia_history_limit: args.omnia_history_limit,
      omnia_floating_panel_mode: args.omnia_floating_panel_mode,
      omnia_floating_panel_width: args.omnia_floating_panel_width === 'full' ? 'full' : Number(args.omnia_floating_panel_width) || undefined,
      promotion: false,
      branding: false,
      setup(editor) {
        editor.on('init', () => {
          editor.setContent(PRESETS[args.preset] || '');
          resolve(editor);
        });
      },
    });
  });
}

function render(args) {
  const wrapper = document.createElement('div');
  wrapper.style.height = 'calc(100vh - 4rem)';
  wrapper.style.display = 'flex';
  wrapper.style.margin = '2rem';
  wrapper.style.flexDirection = 'column';

  const textarea = document.createElement('textarea');
  wrapper.appendChild(textarea);

  createEditor(textarea, args);

  return wrapper;
}

// ── Mock API story ──────────────────────────────────────────────────

export const MockAPI = {
  render,
  args: {
    omnia_base_url: '/api',
    omnia_application: import.meta.env.VITE_OMNIA_APPLICATION || '',
    omnia_municipality: import.meta.env.VITE_OMNIA_MUNICIPALITY || '',
    omnia_default_translate_language: 'nl',
    omnia_enabled_features: [...FEATURE_IDS],
    omnia_shortcuts: true,
    omnia_toolbar: true,
    omnia_context_menu: true,
    omnia_translate_languages: LANGUAGES.map((l) => l.code),
    omnia_history_limit: 5,
    omnia_floating_panel_mode: 'inline',
    omnia_floating_panel_width: "450",
    preset: 'ameliorer',
  },
};

// ── Omnia API story (uses proxy from VITE_OMNIA_BASE_URL env var) ────

export const OmniaAPI = {
  render,
  args: {
    ...MockAPI.args,
    omnia_base_url: import.meta.env.VITE_OMNIA_BASE_URL || '/api',
  },
};

// ── Vanilla TinyMCE (no Omnia plugin) ───────────────────────────────

function renderVanilla(args) {
  const wrapper = document.createElement('div');
  wrapper.style.height = 'calc(100vh - 4rem)';
  wrapper.style.display = 'flex';
  wrapper.style.margin = '2rem';
  wrapper.style.flexDirection = 'column';

  const textarea = document.createElement('textarea');
  wrapper.appendChild(textarea);

  tinymce.init({
    target: textarea,
    skin_url: '/tinymce/skins/ui/oxide',
    content_css: '/tinymce/skins/content/default/content.min.css',
    license_key: 'gpl',
    height: '100%',
    plugins: 'lists link image table charmap searchreplace fullscreen code wordcount',
    toolbar:
      'undo redo | styles | bold italic underline strikethrough | ' +
      'bullist numlist outdent indent | link image table charmap | ' +
      'searchreplace fullscreen code',
    promotion: false,
    branding: false,
    setup(editor) {
      editor.on('init', () => {
        editor.setContent(PRESETS[args.preset] || '');
      });
    },
  });

  return wrapper;
}

export const Vanilla = {
  render: renderVanilla,
  argTypes: {
    preset: {
      control: 'select',
      options: Object.keys(PRESETS),
      labels: PRESET_LABELS,
      description: 'Text preset to load in the editor',
    },
  },
  args: {
    preset: 'corriger',
  },
};
