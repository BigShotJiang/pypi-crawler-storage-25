import { render, createRef } from 'preact';
import { App } from './App';

/**
 * Mount the Omnia UI next to a TinyMCE editor.
 *
 * @param {object} editor - TinyMCE editor instance
 * @param {import('../client').OmniaClient} client - OmniaClient instance
 * @param {object} config - Normalized Omnia config
 * @returns {{ appRef: { current: object }, destroy: () => void }}
 */
export function mountOmniaUI(editor, client, config) {
  const editorId = editor.id || 'default';
  const rootId = `omnia-root-${editorId}`;

  // Prevent double-mount
  let root = document.getElementById(rootId);
  if (!root) {
    root = document.createElement('div');
    root.id = rootId;
    document.body.appendChild(root);
  }

  const appRef = createRef();

  render(<App ref={appRef} editor={editor} client={client} config={config} />, root);

  return {
    appRef,
    destroy() {
      render(null, root);
      root.remove();
    },
  };
}
