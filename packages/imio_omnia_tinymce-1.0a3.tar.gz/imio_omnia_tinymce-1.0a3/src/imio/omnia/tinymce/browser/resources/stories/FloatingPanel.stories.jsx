import { render } from 'preact';
import { FloatingPanel } from '../src/ui/FloatingPanel';
import { createMockEditor } from './mocks/editor';
import { createMockOmniaClient } from './mocks/omnia-client';
import presetReduire from './presets/reduire-deliberation.html?raw';
import '../src/ui/omnia.css';

export default {
  title: 'FloatingPanel',
  argTypes: {
    action: {
      control: 'select',
      options: [null, 'improve-text', 'expand-text', 'reduce-text', 'correct-text', 'make-accessible', 'translate-text'],
    },
    mode: {
      control: 'select',
      options: ['inline', 'blur'],
    },
    floatingPanelWidth: {
      control: 'text',
      description: 'Panel width: a number (px) or "full"',
    },
    mockError: {
      control: 'boolean',
      description: 'Simulate an API error',
    },
  },
};

function renderStory(args) {
  const el = document.createElement('div');
  el.style.width = '600px';
  el.style.height = '400px';
  el.style.position = 'relative';

  const editor = createMockEditor();
  const client = createMockOmniaClient({ error: args.mockError, response: presetReduire });

  const width = args.floatingPanelWidth === 'full'
    ? 'full'
    : Number(args.floatingPanelWidth) || undefined;

  render(
    <FloatingPanel
      editor={editor}
      client={client}
      config={{ floatingPanelWidth: width }}
      mode={args.mode}
      action={args.action}
      onClose={() => console.log('close')}
      onAccept={(text) => console.log('accept:', text)}
    />,
    el,
  );
  return el;
}

export const Default = {
  render: renderStory,
  args: {
    action: 'improve-text',
    mode: 'inline',
    floatingPanelWidth: '600',
    mockError: false,
  },
};
