import { render } from 'preact';
import { useState } from 'preact/hooks';
import { StreamingText } from '../src/ui/StreamingText';
import { createMockOmniaClient } from './mocks/omnia-client';
import presetReduire from './presets/reduire-deliberation.html?raw';
import '../src/ui/omnia.css';

export default {
  title: 'StreamingText',
};

function mount(vnode) {
  const el = document.createElement('div');
  el.style.width = '700px';
  render(vnode, el);
  return el;
}

function StreamingTextWithState({ mockError, delay = 60, response = presetReduire, errorAfter }) {
  const [status, setStatus] = useState('streaming');
  const [error, setError] = useState(null);
  const [key, setKey] = useState(0);

  const [client] = useState(() => createMockOmniaClient({ delay, error: mockError, response, errorAfter }));
  const [stream, setStream] = useState(() => client.generate('test'));

  function replay() {
    setStatus('streaming');
    setError(null);
    setStream(client.generate('test'));
    setKey((k) => k + 1);
  }

  return (
    <div>
      <StreamingText
        key={key}
        stream={stream}
        status={status}
        error={error}
        onComplete={() => setStatus('done')}
        onError={(err) => {
          setError(err.message);
          setStatus('error');
        }}
        onRetry={replay}
      />
      {status !== 'streaming' && (
        <button
          onClick={replay}
          style={{
            marginTop: '12px',
            padding: '6px 16px',
            fontSize: '13px',
            cursor: 'pointer',
            border: '1px solid #ccc',
            borderRadius: '4px',
            background: '#f5f5f5',
          }}
        >
          ▶ Replay
        </button>
      )}
    </div>
  );
}

export const Streaming = () => mount(<StreamingTextWithState mockError={false} />);

export const ErrorDuringStream = () => mount(<StreamingTextWithState mockError={true} errorAfter={37} />);

export const Error = () => {
  return mount(
    <StreamingText
      stream={null}
      status="error"
      error="Network error: could not reach Omnia API"
      onRetry={() => alert('Retry clicked')}
    />,
  );
};

export const Idle = () => {
  return mount(<StreamingText stream={null} status="idle" error={null} />);
};
