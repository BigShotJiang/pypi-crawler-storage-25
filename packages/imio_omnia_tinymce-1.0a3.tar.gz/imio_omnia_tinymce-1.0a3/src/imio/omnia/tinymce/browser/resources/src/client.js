import { parseSSE } from './utils.js';

/**
 * HTTP client for the Omnia AI API.
 * All public methods return async iterables of text chunks (SSE streaming).
 */
export class OmniaClient {
  #baseUrl;
  #application;
  #municipality;
  #authToken;
  #onError;
  #endpoints;

  /**
   * @param {{ baseUrl: string, application?: string, municipality?: string, authToken?: string, onError?: (err: Error) => void, endpoints?: Record<string, string> }} config
   */
  constructor({ baseUrl, application, municipality, authToken, onError, endpoints }) {
    this.#baseUrl = baseUrl.replace(/\/+$/, '');
    this.#application = application || null;
    this.#municipality = municipality || null;
    this.#authToken = authToken || null;
    this.#onError = onError || null;
    this.#endpoints = endpoints || {};
  }

  /**
   * Internal: make a non-streaming JSON request and return the parsed body.
   *
   * @param {string} endpoint - Path relative to baseUrl
   * @param {object} body - JSON request body
   * @param {AbortSignal} [signal] - Optional abort signal
   * @returns {Promise<object>}
   */
  #resolveUrl(endpoint) {
    let url;
    if (/^https?:\/\//.test(endpoint)) {
      url = endpoint;
    } else if (endpoint.startsWith('/')) {
      url = `${this.#baseUrl}${endpoint}`;
    } else {
      url = `${this.#baseUrl}/${endpoint}`;
    }

    if (this.#authToken) {
      // This is for Plone, where we need to add the CSRF token to the URL
      // It also allows to authenticate the user.
      // TODO: We might want to make this configurable and less Plone related
      const sep = url.includes('?') ? '&' : '?';
      url += `${sep}_authenticator=${encodeURIComponent(this.#authToken)}`;
    }

    return url;
  }

  #getEndpoint(key, fallback) {
    return this.#endpoints[key] || fallback;
  }

  #buildHeaders(extra = {}) {
    const headers = { 'Content-Type': 'application/json', ...extra };
    if (this.#application) headers['x-imio-application'] = this.#application;
    if (this.#municipality) headers['x-imio-municipality'] = this.#municipality;
    return headers;
  }

  async #requestJSON(endpoint, body, signal) {
    const url = this.#resolveUrl(endpoint);
    const headers = this.#buildHeaders();

    let response;
    try {
      response = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal,
      });
    } catch (err) {
      if (err.name !== 'AbortError') this.#onError?.(err);
      throw err;
    }

    if (!response.ok) {
      const err = new Error(`Omnia API error: ${response.status} ${response.statusText}`);
      err.status = response.status;
      this.#onError?.(err);
      throw err;
    }

    return response.json();
  }

  /**
   * Internal: make a streaming request and return an async iterable of chunks.
   *
   * @param {string} endpoint - Path relative to baseUrl (e.g. '/generate')
   * @param {object} body - JSON request body
   * @param {AbortSignal} [signal] - Optional abort signal
   * @returns {AsyncGenerator<string>}
   */
  async *#request(endpoint, body, signal) {
    const url = this.#resolveUrl(endpoint);
    const headers = this.#buildHeaders({ Accept: 'text/event-stream' });

    let response;
    try {
      response = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal,
      });
    } catch (err) {
      if (err.name !== 'AbortError') this.#onError?.(err);
      throw err;
    }

    if (!response.ok) {
      const err = new Error(`Omnia API error: ${response.status} ${response.statusText}`);
      err.status = response.status;
      this.#onError?.(err);
      throw err;
    }

    yield* parseSSE(response, signal);
  }

  /**
   * Generate content from a prompt.
   * @param {string} prompt
   * @param {{ tone?: string, signal?: AbortSignal }} [options]
   */
  async *generate(prompt, options = {}) {
    const { signal, ...rest } = options;
    yield* this.#request(this.#getEndpoint('generate', '/generate'), { prompt, ...rest }, signal);
  }

  /**
   * Expand text (make it longer).
   * @param {string} text
   * @param {{ expansionTarget?: number, signal?: AbortSignal }} [options]
   * @returns {Promise<string>}
   */
  async expandText(text, options = {}) {
    const { signal, expansionTarget, ...rest } = options;
    const body = { input: text, ...rest };
    if (expansionTarget !== undefined) body.expansion_target = expansionTarget;
    const data = await this.#requestJSON(
      this.#getEndpoint('expand-text', '/v1/agents/expand-text'),
      body,
      signal,
    );
    return data.result;
  }

  /**
   * Improve text quality and style.
   * @param {string} text
   * @param {{ signal?: AbortSignal }} [options]
   * @returns {Promise<string>}
   */
  async improveText(text, options = {}) {
    const { signal } = options;
    const data = await this.#requestJSON(
      this.#getEndpoint('improve-text', '/v1/agents/improve-text'),
      { input: text },
      signal,
    );
    return data.result;
  }

  /**
   * Reduce text length.
   * @param {string} text
   * @param {{ reductionTarget?: number, signal?: AbortSignal }} [options]
   * @returns {Promise<string>}
   */
  async reduceText(text, options = {}) {
    const { signal, reductionTarget } = options;
    const body = { input: text };
    if (reductionTarget !== undefined) body.reduction_target = reductionTarget;
    const data = await this.#requestJSON(
      this.#getEndpoint('reduce-text', '/v1/agents/reduce-text'),
      body,
      signal,
    );
    return data.result;
  }

  /**
   * Correct spelling and grammar.
   * @param {string} text
   * @param {{ signal?: AbortSignal }} [options]
   * @returns {Promise<string>}
   */
  async correctText(text, options = {}) {
    const { signal } = options;
    const data = await this.#requestJSON(
      this.#getEndpoint('correct-text', '/v1/agents/correct-text'),
      { input: text },
      signal,
    );
    return data.result;
  }

  /**
   * Rewrite text for WCAG accessibility.
   * @param {string} text
   * @param {{ signal?: AbortSignal }} [options]
   * @returns {Promise<string>}
   */
  async makeAccessible(text, options = {}) {
    const { signal } = options;
    const data = await this.#requestJSON(
      this.#getEndpoint('make-accessible', '/v1/agents/make-accessible'),
      { input: text },
      signal,
    );
    return data.result;
  }

  /**
   * Translate text using the structured agents endpoint.
   * @param {string} text
   * @param {string} targetLang - fr | nl | de | en | es | it
   * @param {{ signal?: AbortSignal }} [options]
   * @returns {Promise<string>}
   */
  async translateText(text, targetLang, options = {}) {
    const { signal } = options;
    const data = await this.#requestJSON(
      this.#getEndpoint('translate-text', '/v1/agents/translate-text'),
      { input: text, target_language: targetLang },
      signal,
    );
    return data.result;
  }
}
