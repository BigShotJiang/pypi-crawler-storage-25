/**
 * Parse an SSE stream from a fetch Response into an async iterable of text chunks.
 *
 * @param {Response} response - Fetch response with an SSE body
 * @param {AbortSignal} [signal] - Optional abort signal
 * @returns {AsyncGenerator<string>}
 */
export async function* parseSSE(response, signal) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  try {
    while (true) {
      if (signal?.aborted) break;

      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      // SSE frames are separated by double newlines
      const frames = buffer.split('\n\n');
      // Keep the last (possibly incomplete) frame in the buffer
      buffer = frames.pop() || '';

      for (const frame of frames) {
        for (const line of frame.split('\n')) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') return;

            try {
              const parsed = JSON.parse(data);
              if (parsed.chunk != null) {
                yield parsed.chunk;
              }
            } catch {
              // If not JSON, yield the raw data as a text chunk
              if (data.trim()) yield data;
            }
          }
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
}

/**
 * Generate a unique ID string.
 */
export function uid() {
  return Math.random().toString(36).slice(2, 10);
}
