export const FEATURE_DEFS = [
  {
    id: 'generate',
    label: 'Générer du contenu',
    menu: 'panel',
    shortcut: 'g',
    menuItem: { id: 'omnia-generate', text: 'Générer' },
  },
  {
    id: 'expand-text',
    label: 'Développer la sélection',
    menu: 'floating',
    shortcut: 'd',
    menuItem: { id: 'omnia-expand-text', text: 'Développer' },
  },
  {
    id: 'improve-text',
    label: 'Améliorer',
    menu: 'floating',
    shortcut: 'a',
    menuItem: { id: 'omnia-improve-text', text: 'Améliorer' },
  },
  {
    id: 'reduce-text',
    label: 'Réduire',
    menu: 'floating',
    shortcut: 'r',
    menuItem: { id: 'omnia-reduce-text', text: 'Réduire' },
  },
  {
    id: 'correct-text',
    label: 'Corriger',
    menu: 'floating',
    shortcut: 'c',
    menuItem: { id: 'omnia-correct-text', text: 'Corriger' },
  },
  {
    id: 'make-accessible',
    label: 'Rendre accessible',
    menu: 'floating',
    shortcut: 'x',
    menuItem: { id: 'omnia-make-accessible', text: 'Rendre accessible' },
  },
  {
    id: 'translate-text',
    label: 'Traduire',
    menu: 'floating',
    shortcut: 't',
    menuItem: { id: 'omnia-translate-text', text: 'Traduire' },
  },
];

export const FEATURE_IDS = FEATURE_DEFS.map((feature) => feature.id);

/** Features enabled by default (generate excluded — not yet implemented server-side). */
export const DEFAULT_ENABLED_FEATURES = FEATURE_IDS.filter((id) => id !== 'generate');

export const LANGUAGES = [
  { code: 'fr', label: 'Français' },
  { code: 'nl', label: 'Nederlands' },
  { code: 'de', label: 'Deutsch' },
  { code: 'en', label: 'English' },
  { code: 'es', label: 'Español' },
  { code: 'it', label: 'Italiano' },
];

const DEFAULT_ENDPOINTS = {
  generate: '/generate',
  'expand-text': '/v1/agents/expand-text',
  'improve-text': '/v1/agents/improve-text',
  'reduce-text': '/v1/agents/reduce-text',
  'correct-text': '/v1/agents/correct-text',
  'make-accessible': '/v1/agents/make-accessible',
  'translate-text': '/v1/agents/translate-text',
};

function stringArrayProcessor(value) {
  if (Array.isArray(value) && value.every((item) => typeof item === 'string')) {
    return { value, valid: true };
  }

  if (typeof value === 'string') {
    return {
      value: value
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean),
      valid: true,
    };
  }

  return { valid: false, message: 'Expected a string or an array of strings.' };
}

function objectProcessor(value) {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return { value, valid: true };
  }

  return { valid: false, message: 'Expected an object.' };
}

function shortcutsProcessor(value) {
  if (typeof value === 'boolean') {
    return { value, valid: true };
  }

  return objectProcessor(value);
}

export function registerOmniaOptions(editor) {
  editor.options.register('omnia_base_url', { processor: 'string', default: '' });
  editor.options.register('omnia_auth_token', { processor: 'string', default: '' });
  editor.options.register('omnia_application', { processor: 'string', default: '' });
  editor.options.register('omnia_municipality', { processor: 'string', default: '' });
  editor.options.register('omnia_default_translate_language', { processor: 'string', default: 'fr' });
  editor.options.register('omnia_enabled_features', {
    processor: stringArrayProcessor,
    default: DEFAULT_ENABLED_FEATURES,
  });
  editor.options.register('omnia_endpoints', { processor: objectProcessor, default: {} });
  editor.options.register('omnia_shortcuts', { processor: shortcutsProcessor, default: true });
  editor.options.register('omnia_toolbar', { processor: 'boolean', default: true });
  editor.options.register('omnia_context_menu', { processor: 'boolean', default: true });
  editor.options.register('omnia_translate_languages', {
    processor: stringArrayProcessor,
    default: LANGUAGES.map((language) => language.code),
  });
  editor.options.register('omnia_history_limit', { processor: 'number', default: 5 });
  editor.options.register('omnia_floating_panel_mode', {
    processor: (value) =>
      value === 'inline' || value === 'blur'
        ? { value, valid: true }
        : { valid: false, message: 'Expected "inline" or "blur".' },
    default: 'inline',
  });
  editor.options.register('omnia_floating_panel_width', {
    processor: (value) => {
      if (value === 'full') return { value, valid: true };
      if (typeof value === 'number' && value > 0) return { value, valid: true };
      return { valid: false, message: 'Expected a positive number or "full".' };
    },
    default: 500,
  });
}

function normalizeFeatureIds(featureIds) {
  const allowed = new Set(FEATURE_IDS);
  return featureIds.filter((featureId) => allowed.has(featureId));
}

function normalizeLanguages(languageCodes, defaultLanguage) {
  const available = new Map(LANGUAGES.map((language) => [language.code, language]));
  const normalized = languageCodes
    .filter((code) => available.has(code))
    .map((code) => available.get(code));

  const languages = normalized.length > 0 ? normalized : LANGUAGES;
  const enabledCodes = new Set(languages.map((language) => language.code));

  return {
    languages,
    defaultLanguage: enabledCodes.has(defaultLanguage) ? defaultLanguage : languages[0].code,
  };
}

function normalizeShortcuts(shortcutsOption, enabledFeatureIds) {
  if (shortcutsOption === false) {
    return { enabled: false, prefix: 'o', timeoutMs: 1500, bindings: {} };
  }

  if (shortcutsOption === true) {
    shortcutsOption = {};
  }

  const enabledSet = new Set(enabledFeatureIds);
  const bindings = {};

  for (const feature of FEATURE_DEFS) {
    const configured = shortcutsOption.bindings?.[feature.id];
    const binding = typeof configured === 'string' ? configured.toLowerCase() : feature.shortcut;
    if (enabledSet.has(feature.id) && binding) {
      bindings[feature.id] = binding;
    }
  }

  return {
    enabled: shortcutsOption.enabled !== false,
    prefix:
      typeof shortcutsOption.prefix === 'string' && shortcutsOption.prefix.length === 1
        ? shortcutsOption.prefix.toLowerCase()
        : 'o',
    timeoutMs: Number.isFinite(shortcutsOption.timeoutMs) ? shortcutsOption.timeoutMs : 1500,
    bindings,
  };
}

export function resolveOmniaConfig(editor) {
  const enabledFeatures = normalizeFeatureIds(editor.options.get('omnia_enabled_features'));
  const { languages, defaultLanguage } = normalizeLanguages(
    editor.options.get('omnia_translate_languages'),
    editor.options.get('omnia_default_translate_language'),
  );

  return {
    enabledFeatures,
    endpoints: { ...DEFAULT_ENDPOINTS, ...editor.options.get('omnia_endpoints') },
    shortcuts: normalizeShortcuts(editor.options.get('omnia_shortcuts'), enabledFeatures),
    toolbar: editor.options.get('omnia_toolbar'),
    contextMenu: editor.options.get('omnia_context_menu'),
    defaultLanguage,
    languages,
    historyLimit: Math.max(1, editor.options.get('omnia_history_limit')),
    floatingPanelMode: editor.options.get('omnia_floating_panel_mode'),
    floatingPanelWidth: editor.options.get('omnia_floating_panel_width'),
    authToken: editor.options.get('omnia_auth_token'),
    application: editor.options.get('omnia_application'),
    municipality: editor.options.get('omnia_municipality'),
  };
}
