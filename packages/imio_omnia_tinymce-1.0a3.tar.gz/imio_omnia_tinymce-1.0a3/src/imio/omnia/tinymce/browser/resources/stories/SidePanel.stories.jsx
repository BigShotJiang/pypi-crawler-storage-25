import { render } from 'preact';
import { SidePanel } from '../src/ui/SidePanel';
import { createMockEditor } from './mocks/editor';
import { createMockOmniaClient } from './mocks/omnia-client';
import '../src/ui/omnia.css';

export default {
  title: 'SidePanel',
  parameters: {
    layout: 'fullscreen',
  },
};

function mount(vnode) {
  const el = document.createElement('div');
  el.style.height = '100vh';
  render(vnode, el);
  return el;
}

export const Generate = () => {
  const editor = createMockEditor();
  const client = createMockOmniaClient({
    delay: 50,
    response:
      "Voici un long texte généré qui simule une réponse complète de l'API Omnia. Ce texte contient suffisamment de mots pour montrer le comportement du streaming en temps réel.",
  });
  return mount(
    <SidePanel editor={editor} client={client} visible={true} onClose={() => console.log('close')} />,
  );
};
