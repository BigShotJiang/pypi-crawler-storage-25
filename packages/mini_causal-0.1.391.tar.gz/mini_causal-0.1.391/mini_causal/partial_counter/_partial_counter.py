import numpy as np
import pandas as pd
from mini_causal.utils import clone_model


class PartialCounterfactual:
    """
    PartialCounterfactual is class that uses partial modeling or methods to 
    measure the impact of features on the built-in models.

    It moves away from the traditional feature importance used in machine learning algorithms
    towards measuring the impact of an individual feature on the model by using Causal Inference.
    The method sits at the intersection of both parametric and non-parametric methods. 
    Hence it can be used for both methods.

    Args:
    
    model:
        the trained model

    X (pd.DataFrame):
        The features stored in a dataframe format dataframe are used to simplify accessing the features for partial modeling 
        and calculating causal metrics

        
    y {pd.DataFrame ,np.array}:
        The target values  must have the same length as the X arg

   

    Attributes:

        partial_fit :
            fits the partial estimator i.e the model without the feature

        individual_causal_effects (np.ndarray):
            returns an array of the individual causal effects

        average_causal_effects (np.ndarray):
            returns the average causal effect float value

    References
    ----------
        .. [1] GUIDO W. IMBENS and DONALD B. RUBIN, Causal Inference For Statistics,Social and Biomedical Sciences An Introduction
        .. [2] Victor Chernozhukov et al. ,Applied Causal Inference Powered by
        ML and AI https://causalml-book.org/
        .. [3] Wikipedia ,Partial Linear Regression , https://en.wikipedia.org/wiki/Partial_least_squares_regression
        .. [4] ELIFE OZTURK KIYAK el al. Partial Decision Tree Forest,A Machine Learning Model For GeoScience,
     https://www.mdpi.com/2075-163X/13/6/800

    
    """
    def __init__(self,model,X,y):
        self.model=model
        self.X=X
        self.y=y


        

    def partial_model(self,feature):
        """
        Clone the parameters from the fitted model
        Then build a partial model from the scratch 

        Args:
            feature (str):
                the name of the feature that will be used for partial modeling
            
        Returns:
            fitted partial estimator

        """
        X_partial=self.X.drop(feature,axis=1)
        cloned_model=clone_model(self.model)

        return cloned_model.fit(X_partial,self.y)


  
    def individual_causal_effects(self,X:pd.DataFrame,feature:str):
        """
        The individual causal effects of the predicted

        Args:
            X (pd.DataFrame):
                The input values that will be used for predictions.

            feature:
                the name of the feature that used for partial modeling
        
        Returns:
            np.array:
                the individual causal effects
                the difference in predictions between the model and partial estimator

        """
        X_partial=X.drop(feature,axis=1)

        full_model_preds=self.model.predict(X)
        partial_model_preds=self.partial_model(feature).predict(X_partial)

        return full_model_preds-partial_model_preds
    
    def average_causal_effect(self,X,feature:str):
        """
        The average causal effect

        Args:
            X (pd.DataFrame)
                The input values that will be used for getting the predictions

            feature (str)
                the name of the feature that will be used for partial modeling
    
                
        Returns:
            float:
                the average causal effect float value
            
        """
        return np.mean(self.individual_causal_effects(X,feature))
    

  
