import numpy as np
from mini_causal.partial_counter._partial_counter import PartialCounterfactual

class PartialCounterfactualClassifier(PartialCounterfactual):
    """
    PartialCounterfactualClassifier is class that uses partial modeling or methods to 
    measure the impact of features on the built-in classification models.

    It inherits all the methods and properties from the PartialCounterfactual.

    Args:
        model:
            the trained model
        
        X (pd.DataFrame):
            The features stored in a dataframe format dataframe are used to simplify accessing the features for partial modeling 
            and calculating causal metrics
            
        y {pd.DataFrame ,np.array}:
            The target values  must have the same length as the X arg


    
    Attributes:

        partial_fit :
            fits the partial estimator i.e the model without the feature

        individual_causal_effects (np.ndarray):
            returns an array of the individual causal effects

        average_causal_effects (np.ndarray):
            returns the average causal effect float value
        
            
    References
    ------------
        .. [1] GUIDO W. IMBENS and DONALD B. RUBIN, Causal Inference For Statistics,Social and Biomedical Sciences An Introduction
        .. [2] Victor Chernozhukov et al. ,Applied Causal Inference Powered by
            ML and AI https://causalml-book.org/

    """
    def __init__(self,model,X,y):
        super().__init__(model,X,y)
    
    def individual_causal_effects_probs(self,X,feature):
        """

        The individual causal effects of the predicted probabilities

        Args:
            feature (str):
                the name of the feature that will be used for partial modeling
        
        Returns:
             np.array:
                 the individual causal effects
                 the difference in predicted probabilities between the model and partial estimator

        """
        X_partial=X.drop(feature,axis=1)

        full_model_probs=self.model.predict_proba(X)[:,1]
        partial_model_probs=self.partial_model(feature).predict_proba(X_partial)[:,1]

        return full_model_probs-partial_model_probs
    
    def average_causal_effect_probs(self,X,feature):
        """

        The average causal effect on the predicted probabilities

        Args:
            X (pd.DataFrame):
                the input values that will be used for estimation or prediction process

            feature (str):
                the name of the feature that will be used for partial modeling
            
        
        Returns:
            float:
                average causal effect probs: float

        """
        return float(np.mean(self.individual_causal_effects_probs(X,feature)))
 
