"""MongoDB database service with CRUD operations and index management.

This module provides TinyDBService, a high-level MongoDB client for the TinyAI
microservices platform. It handles common database operations with automatic
index management and ObjectId conversion.

Example:
  Basic usage with environment variables::

    from tinysdk import TinyDBService

    db = TinyDBService()
    doc_id = db.create("users", {"name": "John", "email": "john@example.com"})
"""

import os
from typing import Any, Dict, List, Optional, Tuple

from bson.objectid import ObjectId
from pymongo import MongoClient
from pymongo.errors import AutoReconnect, NetworkTimeout, NotPrimaryError, ServerSelectionTimeoutError

from tinysdk.collections import Collection
from tinysdk.index_config import INDEX_CONFIG
from tinysdk.models.bundle_document import BundleDocument, compute_aggregated_status
from tinysdk.tinylogger import TinyLogger
from tinysdk.utils.decorators import exception_logger, retry
from tinysdk.utils.helpers import get_date

_db_retry_logger = TinyLogger()
_mongo_retry = retry(
  exceptions=(AutoReconnect, NetworkTimeout, NotPrimaryError, ServerSelectionTimeoutError),
  tries=3,
  delay=1,
  backoff=2,
  jitter=(0, 1),
  logger=_db_retry_logger,
)


class TinyDBService:
  """MongoDB service for CRUD operations with automatic index management.

  TinyDBService provides a high-level interface for MongoDB operations including
  create, read, update, delete, and bulk operations. It automatically manages
  indexes based on configuration and handles ObjectId conversions.

  Attributes:
    db_link (str): MongoDB connection string
    db_name (str): Database name
    client (MongoClient): Active MongoDB client connection
    db: MongoDB database instance
    index_config (Dict[str, List]): Index configuration for collections

  Example:
    >>> # Using environment variables
    >>> db = TinyDBService()
    >>>
    >>> # Or explicit parameters
    >>> db = TinyDBService(
    ...     db_link="mongodb://localhost:27017",
    ...     db_name="mydb"
    ... )
    >>>
    >>> # Create a document
    >>> doc_id = db.create("users", {"name": "John", "email": "john@example.com"})
  """

  @exception_logger
  def __init__(
    self,
    db_link: Optional[str] = None,
    db_name: Optional[str] = None,
    index_config: Optional[Dict[str, List[Any]]] = None,
    logger: Optional[TinyLogger] = None,
    connection_timeout_ms: int = 5000,
  ) -> None:
    """Initialize TinyDBService with MongoDB connection.

    Args:
      db_link (str, optional): MongoDB connection string. Defaults to DB_LINK env var.
      db_name (str, optional): Database name. Defaults to DB_NAME env var.
      index_config (Dict[str, List], optional): Custom index configuration to merge with defaults.

    Raises:
      AssertionError: If db_link or db_name not provided via parameters or environment variables.

    Environment Variables:
      DB_LINK: MongoDB connection string (e.g., mongodb://mongo-server:27017)
      DB_NAME: Database name (e.g., tinyDatabase)
    """
    db_link = db_link or os.getenv("DB_LINK")
    db_name = db_name or os.getenv("DB_NAME")
    assert db_link, "DB_LINK must be provided via parameter or environment variable"
    assert db_name, "DB_NAME must be provided via parameter or environment variable"
    self.db_link: str = db_link
    self.db_name: str = db_name

    self.logger: TinyLogger = logger or TinyLogger()
    self.client: MongoClient = MongoClient(self.db_link, serverSelectionTimeoutMS=connection_timeout_ms)
    self.db = self.client.get_database(self.db_name)

    # Initialize index configuration
    self.index_config: Dict[str, List[Any]] = INDEX_CONFIG.copy()
    self._initialized_collections: set = set()
    if index_config:
      self.index_config.update(index_config)

  @_mongo_retry
  @exception_logger
  def create(self, collection: str, documents: List[Dict[str, Any]], bundle: bool = False) -> List[str]:
    """
    Inserts multiple documents into the specified collection.
    When bundle=True, also creates a BundleDocument entry in DOCUMENT_BUNDLES
    grouping all inserted document IDs.

    Args:
        collection (str): The name of the collection to insert documents into.
        documents (List[Dict[str, Any]]): The list of documents to insert.
        bundle (bool): If True, creates a corresponding bundle in DOCUMENT_BUNDLES.

    Returns:
        List[str]: The inserted document IDs as strings.
    """
    self._init_index(collection, bundle=bundle)
    col = self.db.get_collection(collection)
    result = col.insert_many(documents)
    doc_ids = [str(oid) for oid in result.inserted_ids]
    if bundle:
      bundle_col = self.db.get_collection(Collection.DOCUMENT_BUNDLES.value)
      bundle_col.insert_one(BundleDocument(bundleIds=doc_ids, totalFiles=len(doc_ids)).to_dict())
    return doc_ids

  @_mongo_retry
  @exception_logger
  def read(
    self,
    collection: str,
    filter: Optional[Dict[str, Any]] = None,
    sort: Optional[Tuple[str, int]] = None,
    page: int = 0,
    limit: int = 0,
    bundle: bool = False,
  ) -> List[Dict[str, Any]]:
    """
    Retrieves documents from the specified collection based on filters and options.
    When bundle=True, expands the filter's _id to all document IDs in the same bundle.

    Args:
        collection (str): The name of the collection to query.
        filter (Dict[str, Any], optional): Filter criteria. Defaults to no filter.
        sort (Tuple[str, int], optional): A (field, direction) tuple for sorting.
        page (int): Page number for pagination (used with limit).
        limit (int): Maximum number of documents to return (0 means no limit).
        bundle (bool): If True, expands _id to all documents in the same bundle.
        Requires '_id' in filter, raises ValueError otherwise.

    Returns:
        List[Dict[str, Any]]: List of documents with _id converted to string.

    Raises:
      ValueError: If bundle=True and filter does not contain '_id'.
    """
    self._init_index(collection, bundle=bundle)
    col = self.db.get_collection(collection)
    resolved_filter = self._expand_bundle_filter(filter or {}) if bundle else dict(filter or {})
    search_filter = self._convert_filter_id(resolved_filter)
    cursor = col.find(search_filter)
    if sort is not None:
      cursor = cursor.sort(sort[0], sort[1])
    if limit > 0:
      cursor = cursor.skip(page * limit).limit(limit)
    return [{**doc, "_id": str(doc.get("_id"))} for doc in cursor]

  @_mongo_retry
  @exception_logger
  def update(self, collection: str, filter: Dict[str, Any], data: Dict[str, Any], bundle: bool = False) -> int:
    """
    Updates documents in the specified collection based on the filter.
    When bundle=True, expands the filter's _id to all document IDs in the same bundle,
    applying update_data to every document in the bundle.

    Args:
        collection (str): The name of the collection to update.
        filter (Dict[str, Any]): Filter criteria to identify documents to update.
        data (Dict[str, Any]): Update operations to apply (e.g. {"$set": {...}}).
        bundle (bool): If True, applies the update to all documents in the same bundle.
        Requires '_id' in filter, raises ValueError otherwise.

    Returns:
        int: The number of modified documents.

    Raises:
      ValueError: If bundle=True and filter does not contain '_id'.
    """
    self._init_index(collection, bundle=bundle)
    col = self.db.get_collection(collection)
    resolved_filter = self._expand_bundle_filter(filter) if bundle else dict(filter)
    search_filter = self._convert_filter_id(resolved_filter)
    response = col.update_many(search_filter, data)
    if not bundle:
      return response.modified_count
    doc_id = filter.get("_id")
    if not doc_id:
      return response.modified_count
    found_bundle = self._get_bundle_from_id(str(doc_id))
    if not found_bundle:
      return response.modified_count
    updated_docs = list(col.find({"_id": {"$in": [ObjectId(fid) if ObjectId.is_valid(fid) else fid for fid in found_bundle["bundleIds"]]}}))
    new_status = compute_aggregated_status(updated_docs)
    if new_status == found_bundle.get("aggregatedStatus"):
      return response.modified_count
    self.db.get_collection(Collection.DOCUMENT_BUNDLES.value).update_one(
      {"_id": found_bundle["_id"]},
      {"$set": {"aggregatedStatus": new_status, "updatedDate": get_date()}},
    )
    return response.modified_count

  @_mongo_retry
  @exception_logger
  def upsert(self, collection: str, filter: Dict[str, Any], data: Dict[str, Any]) -> bool:
    """
    Atomically creates or updates a single document matching the filter.

    Args:
        collection (str): The name of the collection.
        filter (Dict[str, Any]): Filter criteria to match a single document.
        data (Dict[str, Any]): Update operations to apply.

    Returns:
        bool: True if a new document was inserted, False if an existing one was updated.
    """
    self._init_index(collection)
    col = self.db.get_collection(collection)
    search_filter = self._convert_filter_id(filter)
    result = col.update_one(search_filter, data, upsert=True)
    return result.upserted_id is not None

  @_mongo_retry
  @exception_logger
  def delete(self, collection: str, filter: Optional[Dict[str, Any]] = None, bundle: bool = False) -> int:
    """
    Deletes documents from the specified collection based on the filter.
    When bundle=True, expands the filter's _id to all document IDs in the same bundle,
    deletes all of them, and also removes the bundle document from DOCUMENT_BUNDLES.

    Args:
        collection (str): The name of the collection to delete from.
        filter (Dict[str, Any], optional): Filter criteria. Defaults to {} (delete all).
        bundle (bool): If True, deletes all documents in the bundle and the bundle itself.
        Requires '_id' in filter, raises ValueError otherwise.

    Returns:
        int: The number of deleted documents.

    Raises:
      ValueError: If bundle=True and filter does not contain '_id'.
    """
    self._init_index(collection, bundle=bundle)
    col = self.db.get_collection(collection)
    resolved_filter = dict(filter or {})
    if bundle:
      doc_id = resolved_filter.get("_id")
      if not doc_id:
        raise ValueError("bundle=True requires '_id' in the filter to identify the bundle.")
      found_bundle = self._get_bundle_from_id(str(doc_id))
      if found_bundle:
        self.db.get_collection(Collection.DOCUMENT_BUNDLES.value).delete_one({"_id": found_bundle["_id"]})
        resolved_filter = {"_id": {"$in": found_bundle["bundleIds"]}}
    search_filter = self._convert_filter_id(resolved_filter)
    response = col.delete_many(search_filter)
    return response.deleted_count

  @exception_logger
  def _get_bundle_from_id(self, document_id: str) -> Optional[Dict[str, Any]]:
    """
    Looks up DOCUMENT_BUNDLES to find the bundle containing document_id.

    Returns the full bundle document or None if not found.
    """
    bundle_col = self.db.get_collection(Collection.DOCUMENT_BUNDLES.value)
    return bundle_col.find_one({"bundleIds": document_id})

  @exception_logger
  def _expand_bundle_filter(self, filter: Dict[str, Any]) -> Dict[str, Any]:
    """
    Expands a filter's _id to all document IDs in the same bundle.
    Falls back to the original filter if no bundle is found for the given _id.

    Raises:
        ValueError: If filter does not contain an _id field. Bundle expansion
        requires a document _id to identify which bundle to expand.
    """
    doc_id = filter.get("_id")
    if not doc_id:
      raise ValueError("bundle=True requires '_id' in the filter to identify the bundle.")
    self._init_index(Collection.DOCUMENT_BUNDLES.value)
    found_bundle = self._get_bundle_from_id(str(doc_id))
    return {"_id": {"$in": found_bundle["bundleIds"]}} if found_bundle else dict(filter)

  @exception_logger
  def _init_index(self, collection_name: str, bundle: bool = False) -> None:
    """
    Initializes indexes for the specified collection based on the index configuration.
    When bundle=True, also initializes DOCUMENT_BUNDLES indexes.

    Args:
        collection_name (str): The name of the collection for which to create indexes.
        bundle (bool): If True, also initializes DOCUMENT_BUNDLES indexes.
    """
    assert collection_name is not None, "Collection name cannot be None"
    for name in [collection_name] + ([Collection.DOCUMENT_BUNDLES.value] if bundle else []):
      if name in self._initialized_collections:
        continue
      col = self.db.get_collection(name)
      for index in self.index_config.get(name, []):
        fields = index[:-1] if isinstance(index[-1], dict) else index
        options = index[-1] if isinstance(index[-1], dict) else {}
        col.create_index(fields, **options)
      self._initialized_collections.add(name)

  @exception_logger
  def _convert_filter_id(self, filter: Dict[str, Any]) -> Dict[str, Any]:
    """
    Converts string IDs in the filter to ObjectId.

    Args:
    filter (Dict[str, Any]): Dictionary containing filter criteria.

    Returns:
    Dict[str, Any]: Filter with ObjectId values.
    """
    filter = filter.copy()  # do not mutate caller's dict
    id = filter.get("_id", None)
    if isinstance(id, str):
      filter["_id"] = ObjectId(id)
    elif isinstance(id, dict) and "$in" in id:
      filter["_id"]["$in"] = [ObjectId(id_str) for id_str in id["$in"]]
    return filter

  @_mongo_retry
  @exception_logger
  def exists(self, collection: str, filter: Optional[Dict[str, Any]] = None) -> bool:
    """
    Checks if a document exists in the specified collection based on the filter.

    Args:
        collection (str): The name of the collection to check.
        filter (Dict[str, Any], optional): Filter criteria. Defaults to {} (any document).

    Returns:
        bool: True if a matching document exists, False otherwise.
    """
    self._init_index(collection)
    col = self.db.get_collection(collection)
    search_filter = self._convert_filter_id(filter or {})
    return col.count_documents(search_filter) > 0

  @_mongo_retry
  @exception_logger
  def count(self, collection: str, filter: Optional[Dict[str, Any]] = None) -> int:
    """
    Counts documents in the specified collection matching the filter.

    Args:
        collection (str): The name of the collection to query.
        filter (Dict[str, Any], optional): Filter criteria. Defaults to no filter.

    Returns:
        int: The number of matching documents.
    """
    self._init_index(collection)
    col = self.db.get_collection(collection)
    search_filter = self._convert_filter_id(filter or {})
    return col.count_documents(search_filter)

  @exception_logger
  def close(self) -> None:
    """Closes the MongoDB client connection and releases the connection pool."""
    self.client.close()
    self.logger.log("MongoDB client connection closed.")
