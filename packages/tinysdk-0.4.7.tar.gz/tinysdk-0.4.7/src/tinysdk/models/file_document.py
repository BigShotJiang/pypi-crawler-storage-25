from dataclasses import asdict, dataclass, field
from typing import Any, Dict

from tinysdk.utils.helpers import get_date


@dataclass
class FileDocument:
  documentName: str
  fileName: str
  mimeType: str
  size: int
  uploadedBy: str
  bucketName: str
  bucketNameProcessed: str
  uploadDate: str = field(default_factory=get_date)
  ocrCompleted: bool = field(default=False)
  classificationCompleted: bool = field(default=False)
  extractionCompleted: bool = field(default=False)
  hitlCompleted: bool = field(default=False)
  processingCompleted: bool = field(default=False)
  status: str = field(default="created")
  custom: bool = field(default=False)
  customMetadata: Dict[str, Any] = field(default_factory=dict)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
