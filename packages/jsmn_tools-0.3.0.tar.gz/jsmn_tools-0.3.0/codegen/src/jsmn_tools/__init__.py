"""jsmn-tools code generator."""
