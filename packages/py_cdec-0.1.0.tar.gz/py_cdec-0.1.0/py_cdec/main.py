#!/usr/bin/env python3
"""Strong best-effort .pyc / marshal / source analyzer and decompiler.

This file favors readable, syntactically valid output over exact bytecode
reconstruction. It is intentionally heuristic, but it is more careful than a
plain stack printer:
- version-aware .pyc header handling,
- marshal extraction from .py source,
- stack-based reconstruction of calls, attributes, literals, subscripts,
  imports, and assignments,
- basic support for comprehensions, f-strings, and unpacking,
- post-processing that repairs common decompiler artifacts,
- AST-based cleanup when the emitted source is parseable.
"""

from __future__ import annotations

import argparse
import ast
import dis
import io
import marshal
import re
import sys
import tokenize
import types
from dataclasses import dataclass
from pathlib import Path
from types import CodeType
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

try:
    import autopep8  # type: ignore
except Exception:  # pragma: no cover
    autopep8 = None


MAGIC_TO_VERSION: Dict[bytes, Tuple[int, int]] = {
    b"\x33\x0d\x0d\x0a": (3, 6),
    b"\x42\x0d\x0d\x0a": (3, 7),
    b"\x55\x0d\x0d\x0a": (3, 8),
    b"\x61\x0d\x0d\x0a": (3, 9),
    b"\x6f\x0d\x0d\x0a": (3, 10),
    b"\xa7\x0d\x0d\x0a": (3, 11),
    b"\xcb\x0d\x0d\x0a": (3, 12),
    b"\xee\x0d\x0d\x0a": (3, 13),
}

HEADER_SIZE_CANDIDATES: Dict[Tuple[int, int], Tuple[int, ...]] = {
    (3, 6): (12, 16),
    (3, 7): (16, 12),
    (3, 8): (16, 12),
    (3, 9): (16, 12),
    (3, 10): (16, 12),
    (3, 11): (16, 20, 12),
    (3, 12): (16, 20, 12),
    (3, 13): (16, 20, 12),
}
DEFAULT_HEADER_SIZES = (16, 12, 20, 8)

SKIP_OPS = {
    "CACHE",
    "EXTENDED_ARG",
    "NOP",
    "RESUME",
    "RESUME_QUICK",
    "PUSH_NULL",
    "PRECALL",
    "COPY_FREE_VARS",
    "RETURN_GENERATOR",
    "SETUP_ANNOTATIONS",
    "SETUP_WITH",
    "BEFORE_ASYNC_WITH",
    "WITH_EXCEPT_START",
    "GET_AWAITABLE",
    "GET_ITER",
    "GET_YIELD_FROM_ITER",
    "KW_NAMES",
    "COPY",
    "SWAP",
}

LOAD_OPS = {
    "LOAD_CONST",
    "LOAD_FAST",
    "LOAD_NAME",
    "LOAD_GLOBAL",
    "LOAD_DEREF",
    "LOAD_CLOSURE",
    "LOAD_CLASSDEREF",
    "LOAD_ATTR",
    "LOAD_METHOD",
    "LOAD_BUILD_CLASS",
    "LOAD_ASSERTION_ERROR",
    "LOAD_FAST_LOAD_FAST",
    "LOAD_FAST_AND_CLEAR",
    "LOAD_FAST_CHECK",
}

STORE_OPS = {
    "STORE_FAST",
    "STORE_NAME",
    "STORE_GLOBAL",
    "STORE_DEREF",
    "STORE_ATTR",
    "STORE_SUBSCR",
    "STORE_FAST_LOAD_FAST",
    "STORE_FAST_STORE_FAST",
    "STORE_FAST_MAYBE_NULL",
}

UNARY_SYMBOLS = {
    "UNARY_POSITIVE": "+",
    "UNARY_NEGATIVE": "-",
    "UNARY_NOT": "not",
    "UNARY_INVERT": "~",
}

BINARY_SYMBOLS = {
    "BINARY_ADD": "+",
    "BINARY_AND": "&",
    "BINARY_FLOOR_DIVIDE": "//",
    "BINARY_LSHIFT": "<<",
    "BINARY_MATRIX_MULTIPLY": "@",
    "BINARY_MODULO": "%",
    "BINARY_MULTIPLY": "*",
    "BINARY_OR": "|",
    "BINARY_POWER": "**",
    "BINARY_RSHIFT": ">>",
    "BINARY_SUBTRACT": "-",
    "BINARY_TRUE_DIVIDE": "/",
    "BINARY_XOR": "^",
    "INPLACE_ADD": "+=",
    "INPLACE_AND": "&=",
    "INPLACE_FLOOR_DIVIDE": "//=",
    "INPLACE_LSHIFT": "<<=",
    "INPLACE_MATRIX_MULTIPLY": "@=",
    "INPLACE_MODULO": "%=",
    "INPLACE_MULTIPLY": "*=",
    "INPLACE_OR": "|=",
    "INPLACE_POWER": "**=",
    "INPLACE_RSHIFT": ">>=",
    "INPLACE_SUBTRACT": "-=",
    "INPLACE_TRUE_DIVIDE": "/=",
    "INPLACE_XOR": "^=",
}

COMPARE_OP_NAMES = {
    0: "<",
    1: "<=",
    2: "==",
    3: "!=",
    4: ">",
    5: ">=",
    6: "in",
    7: "not in",
    8: "is",
    9: "is not",
    10: "exception match",
}

JUMP_PREFIXES = ("JUMP_", "POP_JUMP_", "FOR_ITER", "SEND")


@dataclass(frozen=True)
class PycHeader:
    version: Optional[Tuple[int, int]]
    header_size: int
    raw_magic: bytes
    bitfield: Optional[int] = None


@dataclass
class StackEntry:
    expr: str
    origin: str = "unknown"
    is_temp: bool = True
    kind: str = "expr"  # expr | name | literal | call | attr | import | statement | unknown
    import_module: Optional[str] = None
    import_name: Optional[str] = None


class SafeStack:
    def __init__(self) -> None:
        self._items: List[StackEntry] = []

    def push(
        self,
        expr: str,
        origin: str = "unknown",
        is_temp: bool = True,
        kind: str = "expr",
        import_module: Optional[str] = None,
        import_name: Optional[str] = None,
    ) -> None:
        self._items.append(
            StackEntry(
                expr=expr,
                origin=origin,
                is_temp=is_temp,
                kind=kind,
                import_module=import_module,
                import_name=import_name,
            )
        )

    def pop(self, fallback: str = "<?>") -> StackEntry:
        if self._items:
            return self._items.pop()
        return StackEntry(fallback, origin="fallback", is_temp=False, kind="unknown")

    def peek(self, fallback: str = "<?>") -> StackEntry:
        if self._items:
            return self._items[-1]
        return StackEntry(fallback, origin="fallback", is_temp=False, kind="unknown")

    def clear(self) -> None:
        self._items.clear()

    def __len__(self) -> int:
        return len(self._items)

    def __bool__(self) -> bool:
        return bool(self._items)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def safe_str(value: Any) -> str:
    try:
        return str(value)
    except Exception:
        return f"<{type(value).__name__}>"


def safe_repr(value: Any, max_length: int = 120) -> str:
    try:
        if isinstance(value, CodeType):
            return f"<code object {value.co_name}>"
        if isinstance(value, types.FunctionType):
            return f"<function {value.__name__}>"
        if isinstance(value, types.ModuleType):
            return f"<module {value.__name__}>"
        text = repr(value)
        if len(text) > max_length:
            return text[: max_length - 3] + "..."
        return text
    except Exception:
        return f"<{type(value).__name__}>"


def sanitize_identifier(name: str, fallback: str = "_obj") -> str:
    text = safe_str(name).strip()
    if not text:
        return fallback

    aliases = {
        "<module>": "module",
        "<lambda>": "lambda_func",
        "<genexpr>": "genexpr",
        "<listcomp>": "listcomp",
        "<setcomp>": "setcomp",
        "<dictcomp>": "dictcomp",
    }
    if text in aliases:
        return aliases[text]

    cleaned: List[str] = []
    for ch in text:
        cleaned.append(ch if (ch.isalnum() or ch == "_") else "_")
    result = "".join(cleaned).strip("_")
    if not result:
        return fallback
    if result[0].isdigit():
        result = "_" + result
    return result


def sanitize_param_name(name: str, index: int) -> str:
    return sanitize_identifier(name, fallback=f"_arg{index}")


def normalize_module_name(name: Any) -> str:
    text = safe_str(name).strip()
    text = text.replace("NULL + ", "").replace("NULL+", "")
    return text or "unknown_module"


def format_exception(exc: BaseException) -> str:
    return f"{exc.__class__.__name__}: {exc}"


def get_dis_kwargs() -> Dict[str, Any]:
    kwargs: Dict[str, Any] = {}
    try:
        params = dis.get_instructions.__code__.co_varnames  # type: ignore[attr-defined]
    except Exception:
        params = ()
    if "show_caches" in params:
        kwargs["show_caches"] = False
    if "adaptive" in params:
        kwargs["adaptive"] = False
    if "show_offsets" in params:
        kwargs["show_offsets"] = False
    return kwargs


def _is_jump_instruction(instr: dis.Instruction) -> bool:
    return instr.opname.startswith(JUMP_PREFIXES)


def _literal_bytes(node: ast.AST) -> Optional[bytes]:
    try:
        value = ast.literal_eval(node)
    except Exception:
        return None
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)
    return None


def _safe_unparse(node: ast.AST) -> str:
    try:
        if hasattr(ast, "unparse"):
            return ast.unparse(node)
    except Exception:
        pass
    try:
        return ast.dump(node)
    except Exception:
        return "<?>"


def _split_top_level(expr: str) -> List[str]:
    expr = expr.strip()
    if not expr:
        return []
    if expr[0] in "([{" and expr[-1] in ")]}":
        expr = expr[1:-1].strip()
    if not expr:
        return []
    parts: List[str] = []
    depth = 0
    start = 0
    quote: Optional[str] = None
    esc = False
    for i, ch in enumerate(expr):
        if quote:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
            continue
        if ch in "'\"":
            quote = ch
            continue
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        elif ch == "," and depth == 0:
            parts.append(expr[start:i].strip())
            start = i + 1
    tail = expr[start:].strip()
    if tail:
        parts.append(tail)
    return parts


# ---------------------------------------------------------------------------
# .pyc / marshal loading
# ---------------------------------------------------------------------------


def detect_version_from_magic(raw: bytes) -> Optional[Tuple[int, int]]:
    for magic, version in MAGIC_TO_VERSION.items():
        if raw.startswith(magic):
            return version
    return None


def read_pyc_file(path: Path) -> Tuple[PycHeader, CodeType]:
    try:
        raw = path.read_bytes()
    except Exception as exc:
        raise RuntimeError(f"Cannot read file {path}: {format_exception(exc)}") from exc

    if len(raw) < 12:
        raise RuntimeError(f"File too small: {len(raw)} bytes")

    version = detect_version_from_magic(raw)
    candidate_sizes = HEADER_SIZE_CANDIDATES.get(version, DEFAULT_HEADER_SIZES)
    last_error: Optional[BaseException] = None

    for size in candidate_sizes:
        if size > len(raw):
            continue
        try:
            obj = marshal.loads(raw[size:])
        except Exception as exc:
            last_error = exc
            continue
        if isinstance(obj, CodeType):
            bitfield = int.from_bytes(raw[4:8], "little") if len(raw) >= 8 else None
            return PycHeader(version=version, header_size=size, raw_magic=raw[:4], bitfield=bitfield), obj

    if last_error is not None:
        raise RuntimeError(f"Could not decode {path}: {format_exception(last_error)}")
    raise RuntimeError(f"Could not decode {path}")


def _is_marshal_import_call(node: ast.AST, importlib_aliases: Set[str]) -> bool:
    if not isinstance(node, ast.Call) or not node.args:
        return False
    first = node.args[0]
    try:
        mod_name = ast.literal_eval(first)
    except Exception:
        return False
    if mod_name != "marshal":
        return False
    func = node.func
    if isinstance(func, ast.Name) and func.id == "__import__":
        return True
    if isinstance(func, ast.Attribute) and func.attr == "import_module":
        if isinstance(func.value, ast.Name) and func.value.id in importlib_aliases:
            return True
    return False


def _compile_variants(text: str) -> List[str]:
    variants = [text]
    lines = text.splitlines()
    for i in range(len(lines)):
        candidate = "\n".join(lines[i:]).strip()
        if candidate:
            variants.append(candidate)
    return variants


def extract_marshaled_code_object(source: str) -> Optional[CodeType]:
    try:
        tree = ast.parse(source)
    except Exception:
        try:
            return compile(source, "<string>", "exec")
        except Exception:
            return None

    marshal_aliases: Set[str] = {"marshal"}
    importlib_aliases: Set[str] = {"importlib"}
    loads_aliases: Set[str] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "marshal":
                    marshal_aliases.add(alias.asname or alias.name)
                elif alias.name == "importlib":
                    importlib_aliases.add(alias.asname or alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module == "marshal":
                for alias in node.names:
                    if alias.name == "loads":
                        loads_aliases.add(alias.asname or alias.name)
            elif node.module == "importlib":
                for alias in node.names:
                    if alias.name == "import_module":
                        importlib_aliases.add(alias.asname or alias.name)
        elif isinstance(node, ast.Assign):
            value = node.value
            if _is_marshal_import_call(value, importlib_aliases):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        marshal_aliases.add(target.id)
            if isinstance(value, ast.Attribute) and value.attr == "loads":
                base = value.value
                if isinstance(base, ast.Name) and base.id in marshal_aliases:
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            loads_aliases.add(target.id)

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not node.args:
            continue
        func = node.func
        is_candidate = False
        if isinstance(func, ast.Name) and func.id in loads_aliases:
            is_candidate = True
        elif isinstance(func, ast.Attribute) and func.attr == "loads":
            base = func.value
            if isinstance(base, ast.Name) and base.id in marshal_aliases:
                is_candidate = True
            elif _is_marshal_import_call(base, importlib_aliases):
                is_candidate = True
        if not is_candidate:
            continue

        data = _literal_bytes(node.args[0])
        if data is None:
            continue

        try:
            obj = marshal.loads(data)
            if isinstance(obj, CodeType):
                return obj
        except Exception:
            pass

        try:
            text_content = data.decode("utf-8", errors="ignore")
        except Exception:
            continue

        for candidate in _compile_variants(text_content):
            try:
                return compile(candidate, "<string>", "exec")
            except Exception:
                continue

    try:
        return compile(source, "<string>", "exec")
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Expression builder
# ---------------------------------------------------------------------------


class ExpressionBuilder:
    """Opcode-to-expression reconstruction.

    The goal is to rebuild valid Python with sensible precedence and fewer
    artifacts than a literal opcode printer.
    """

    def __init__(self, code: CodeType):
        self.code = code
        self.stack = SafeStack()
        self.pending_kw_names: Tuple[str, ...] = ()
        self.pending_import_module: Optional[str] = None
        self._last_emitted: Optional[str] = None

    def reset(self) -> None:
        self.stack.clear()
        self.pending_kw_names = ()
        self.pending_import_module = None
        self._last_emitted = None

    def _dedupe_stmt(self, stmt: Optional[str]) -> Optional[str]:
        if stmt is None:
            return None
        cleaned = stmt.strip()
        if not cleaned:
            return None
        if cleaned == self._last_emitted:
            return None
        self._last_emitted = cleaned
        return cleaned

    def _push(self, expr: str, *, origin: str, kind: str = "expr", is_temp: bool = True, module: Optional[str] = None, name: Optional[str] = None) -> None:
        self.stack.push(expr, origin=origin, is_temp=is_temp, kind=kind, import_module=module, import_name=name)

    def _pop(self) -> StackEntry:
        return self.stack.pop()

    def _pop_many(self, count: int) -> List[StackEntry]:
        items = [self._pop() for _ in range(max(0, count))]
        items.reverse()
        return items

    def _looks_like_augassign(self, name: str, value: str) -> Optional[str]:
        # Repair common forms like "hit = (hit += 1)" and keep them as augmented assignment.
        if value.startswith(f"({name} ") and value.endswith(")"):
            inner = value[1:-1].strip()
            if inner.startswith(f"{name} "):
                return inner
        return None

    def process_instruction(self, instr: dis.Instruction) -> Optional[str]:
        try:
            opname = instr.opname

            if opname in SKIP_OPS:
                return None

            if opname in {"LOAD_FAST_LOAD_FAST", "STORE_FAST_LOAD_FAST", "STORE_FAST_STORE_FAST"}:
                handler = getattr(self, f"_handle_{opname.lower()}", None)
                if handler:
                    handler(instr)
                return None

            if opname in LOAD_OPS:
                self._handle_load(instr)
                return None

            if opname in UNARY_SYMBOLS:
                self._handle_unary(instr)
                return None

            if opname in BINARY_SYMBOLS:
                self._handle_binary(instr)
                return None

            if opname == "BINARY_OP":
                self._handle_binary_op(instr)
                return None

            if opname in {"COMPARE_OP", "IS_OP", "CONTAINS_OP"}:
                self._handle_compare(instr)
                return None

            if opname == "KW_NAMES":
                self._handle_kw_names(instr)
                return None

            if opname in {
                "BUILD_TUPLE",
                "BUILD_LIST",
                "BUILD_SET",
                "BUILD_MAP",
                "BUILD_CONST_KEY_MAP",
                "BUILD_STRING",
                "BUILD_SLICE",
                "BUILD_TUPLE_UNPACK",
                "BUILD_LIST_UNPACK",
                "BUILD_MAP_UNPACK",
                "BUILD_MAP_UNPACK_WITH_CALL",
            }:
                self._handle_build(instr)
                return None

            if opname in {"CALL_FUNCTION", "CALL_METHOD", "CALL", "CALL_FUNCTION_KW", "CALL_FUNCTION_EX"}:
                self._handle_call(instr)
                return None

            if opname in STORE_OPS:
                return self._dedupe_stmt(self._handle_store(instr))

            if opname in {"DELETE_FAST", "DELETE_NAME", "DELETE_GLOBAL", "DELETE_ATTR", "DELETE_SUBSCR"}:
                return self._dedupe_stmt(self._handle_delete(instr))

            if opname == "BINARY_SUBSCR":
                self._handle_subscr()
                return None

            if opname in {"UNPACK_SEQUENCE", "UNPACK_EX"}:
                self._handle_unpack(instr)
                return None

            if opname == "RETURN_VALUE":
                return self._dedupe_stmt(self._handle_return())

            if opname == "RETURN_CONST":
                return self._dedupe_stmt(f"return {safe_repr(instr.argval)}")

            if opname == "POP_TOP":
                return self._dedupe_stmt(self._handle_pop_top())

            if opname == "FORMAT_VALUE":
                self._handle_format_value(instr)
                return None

            if opname in {"LIST_APPEND", "SET_ADD", "MAP_ADD"}:
                self._handle_comprehension_append()
                return None

            if opname in {"YIELD_VALUE", "YIELD_FROM"}:
                self._handle_yield(instr)
                return None

            if opname == "RAISE_VARARGS":
                return self._dedupe_stmt(self._handle_raise(instr))

            if opname == "IMPORT_NAME":
                self._handle_import(instr)
                return None

            if opname == "IMPORT_FROM":
                self._handle_import_from(instr)
                return None

            if _is_jump_instruction(instr):
                return None

            return None
        except Exception:
            return None

    def _handle_load(self, instr: dis.Instruction) -> None:
        opname = instr.opname

        if opname == "LOAD_CONST":
            value = instr.argval
            if value is None:
                self._push("None", origin=opname, kind="literal", is_temp=False)
            elif isinstance(value, bool):
                self._push("True" if value else "False", origin=opname, kind="literal", is_temp=False)
            elif isinstance(value, str):
                self._push(repr(value), origin=opname, kind="literal", is_temp=False)
            elif isinstance(value, (int, float, complex, bytes)):
                self._push(repr(value), origin=opname, kind="literal", is_temp=False)
            elif isinstance(value, tuple):
                self._push("(" + ", ".join(repr(v) for v in value) + ("," if len(value) == 1 else "") + ")", origin=opname, kind="literal", is_temp=False)
            elif isinstance(value, frozenset):
                items = ", ".join(repr(v) for v in value)
                self._push(f"frozenset({{{items}}})", origin=opname, kind="literal", is_temp=False)
            elif isinstance(value, CodeType):
                self._push(f"<code object {sanitize_identifier(value.co_name, 'code')}>", origin=opname, kind="literal", is_temp=False)
            else:
                self._push(safe_repr(value), origin=opname, kind="literal", is_temp=False)

        elif opname in {
            "LOAD_FAST",
            "LOAD_NAME",
            "LOAD_GLOBAL",
            "LOAD_DEREF",
            "LOAD_CLASSDEREF",
            "LOAD_FAST_AND_CLEAR",
            "LOAD_FAST_CHECK",
        }:
            text = self._normalize_loaded_name(instr)
            self._push(text, origin=opname, kind="name", is_temp=False)

        elif opname in {"LOAD_ATTR", "LOAD_METHOD"}:
            obj = self._pop()
            attr = safe_str(instr.argrepr)
            expr = f"{obj.expr}.{attr}"
            self._push(expr, origin=opname, kind="attr", is_temp=False)

        elif opname == "LOAD_BUILD_CLASS":
            self._push("__build_class__", origin=opname, kind="name", is_temp=False)
        elif opname == "LOAD_ASSERTION_ERROR":
            self._push("AssertionError", origin=opname, kind="name", is_temp=False)
        else:
            self._push(f"<{opname}>", origin=opname)

    def _normalize_loaded_name(self, instr: dis.Instruction) -> str:
        text = safe_str(instr.argval if instr.argval is not None else instr.argrepr)
        return text.replace("NULL + ", "").replace("NULL+", "").strip()

    def _handle_load_fast_load_fast(self, instr: dis.Instruction) -> None:
        value = instr.argval
        if isinstance(value, tuple) and len(value) == 2:
            a, b = value
            self._push(safe_str(a), origin=instr.opname, kind="name", is_temp=False)
            self._push(safe_str(b), origin=instr.opname, kind="name", is_temp=False)
            return
        text = safe_str(instr.argrepr)
        parts = [p.strip() for p in text.split(",") if p.strip()]
        if len(parts) >= 2:
            self._push(parts[0], origin=instr.opname, kind="name", is_temp=False)
            self._push(parts[1], origin=instr.opname, kind="name", is_temp=False)
        else:
            self._push(text, origin=instr.opname, kind="name", is_temp=False)

    def _handle_store_fast_load_fast(self, instr: dis.Instruction) -> None:
        value = self._pop().expr
        name = safe_str(instr.argrepr).split(",")[-1].strip()
        self._push(f"{name} = {value}", origin=instr.opname, kind="statement", is_temp=False)

    def _handle_store_fast_store_fast(self, instr: dis.Instruction) -> None:
        value2 = self._pop().expr
        value1 = self._pop().expr
        name_text = safe_str(instr.argrepr)
        names = [n.strip() for n in name_text.split(",") if n.strip()]
        if len(names) >= 2:
            stmt = f"{names[0]} = {value1}; {names[1]} = {value2}"
        else:
            stmt = f"{name_text} = ({value1}, {value2})"
        self._push(stmt, origin=instr.opname, kind="statement", is_temp=False)

    def _handle_unary(self, instr: dis.Instruction) -> None:
        symbol = UNARY_SYMBOLS.get(instr.opname)
        if symbol is None:
            self._push(f"<{instr.opname}>", origin=instr.opname)
            return
        value = self._pop()
        expr = f"not {value.expr}" if symbol == "not" else f"({symbol}{value.expr})"
        self._push(expr, origin=instr.opname, kind="expr", is_temp=True)

    def _handle_binary(self, instr: dis.Instruction) -> None:
        symbol = BINARY_SYMBOLS.get(instr.opname)
        if symbol is None:
            self._push(f"<{instr.opname}>", origin=instr.opname)
            return
        right = self._pop()
        left = self._pop()
        self._push(f"({left.expr} {symbol} {right.expr})", origin=instr.opname, kind="expr", is_temp=True)

    def _handle_binary_op(self, instr: dis.Instruction) -> None:
        symbol = safe_str(instr.argrepr).strip()
        if not symbol:
            try:
                symbol = dis._nb_ops[int(instr.arg or 0)][1]  # type: ignore[attr-defined]
            except Exception:
                symbol = "?"
        right = self._pop()
        left = self._pop()
        self._push(f"({left.expr} {symbol} {right.expr})", origin=instr.opname, kind="expr", is_temp=True)

    def _handle_compare(self, instr: dis.Instruction) -> None:
        right = self._pop()
        left = self._pop()
        if instr.opname == "COMPARE_OP":
            op = safe_str(instr.argrepr or COMPARE_OP_NAMES.get(int(instr.arg or -1), "?"))
        elif instr.opname == "IS_OP":
            op = "is not" if int(instr.arg or 0) else "is"
        elif instr.opname == "CONTAINS_OP":
            op = "not in" if int(instr.arg or 0) else "in"
        else:
            op = "?"
        self._push(f"({left.expr} {op} {right.expr})", origin=instr.opname, kind="expr", is_temp=True)

    def _handle_unpack(self, instr: dis.Instruction) -> None:
        count = int(instr.arg or 0)
        value = self._pop().expr
        if instr.opname == "UNPACK_SEQUENCE":
            targets = [f"_u{i}" for i in range(count)]
        else:
            before = int(instr.arg & 0xFF) if instr.arg is not None else 0
            after = int(instr.arg >> 8) if instr.arg is not None else 0
            targets = [f"_u{i}" for i in range(before)] + ["*_u_rest"] + [f"_u{i}" for i in range(after)]
        self._push(f"{', '.join(targets)} = {value}", origin=instr.opname, kind="statement", is_temp=False)

    def _handle_build(self, instr: dis.Instruction) -> None:
        opname = instr.opname
        argc = int(instr.arg or 0)

        if opname == "BUILD_TUPLE":
            items = [self._pop().expr for _ in range(argc)][::-1]
            expr = f"({', '.join(items)}{',' if argc == 1 else ''})"
        elif opname == "BUILD_LIST":
            items = [self._pop().expr for _ in range(argc)][::-1]
            expr = f"[{', '.join(items)}]"
        elif opname == "BUILD_SET":
            items = [self._pop().expr for _ in range(argc)][::-1]
            expr = f"{{{', '.join(items)}}}"
        elif opname == "BUILD_MAP":
            items = [self._pop().expr for _ in range(argc * 2)][::-1]
            pairs = []
            for i in range(0, len(items), 2):
                key = items[i]
                val = items[i + 1] if i + 1 < len(items) else "None"
                pairs.append(f"{key}: {val}")
            expr = "{" + ", ".join(pairs) + "}"
        elif opname == "BUILD_CONST_KEY_MAP":
            keys_entry = self._pop().expr
            keys = _split_top_level(keys_entry)
            values = [self._pop().expr for _ in range(argc)][::-1]
            pairs = [f"{keys[i]}: {values[i]}" for i in range(min(len(keys), len(values)))]
            expr = "{" + ", ".join(pairs) + "}"
        elif opname == "BUILD_STRING":
            parts = [self._pop().expr for _ in range(argc)][::-1]
            expr = f'"" .join([{", ".join(parts)}])'
        elif opname == "BUILD_SLICE":
            if argc == 3:
                step = self._pop().expr
                stop = self._pop().expr
                start = self._pop().expr
                expr = f"slice({start}, {stop}, {step})"
            else:
                stop = self._pop().expr
                start = self._pop().expr
                expr = f"slice({start}, {stop})"
        elif opname == "BUILD_TUPLE_UNPACK":
            items = [self._pop().expr for _ in range(argc)][::-1]
            expr = "(" + ", ".join(items) + ")"
        elif opname == "BUILD_LIST_UNPACK":
            items = [self._pop().expr for _ in range(argc)][::-1]
            expr = "[" + ", ".join(items) + "]"
        elif opname in {"BUILD_MAP_UNPACK", "BUILD_MAP_UNPACK_WITH_CALL"}:
            items = [self._pop().expr for _ in range(argc)][::-1]
            expr = "{" + ", ".join(items) + "}"
        else:
            expr = f"<{opname}>"
        self._push(expr, origin=opname, kind="expr", is_temp=False)

    def _handle_kw_names(self, instr: dis.Instruction) -> None:
        value = instr.argval
        if isinstance(value, tuple):
            self.pending_kw_names = tuple(str(x) for x in value)
        else:
            self.pending_kw_names = ()

    def _handle_call(self, instr: dis.Instruction) -> None:
        opname = instr.opname
        argc = int(instr.arg or 0)

        if opname in {"CALL_FUNCTION", "CALL_METHOD", "CALL"}:
            args = [self._pop().expr for _ in range(argc)][::-1]
            func_entry = self._pop()
            func = func_entry.expr

            if self.pending_kw_names:
                kwcount = min(len(self.pending_kw_names), len(args))
                pos_args = args[:-kwcount] if kwcount else args
                kw_values = args[-kwcount:] if kwcount else []
                kw_parts = [f"{k}={v}" for k, v in zip(self.pending_kw_names, kw_values)]
                args = pos_args + kw_parts
            self.pending_kw_names = ()

            self._push(f"{func}({', '.join(args)})", origin=opname, kind="call", is_temp=False)
            return

        if opname == "CALL_FUNCTION_KW":
            names_entry = self._pop().expr
            args = [self._pop().expr for _ in range(argc)][::-1]
            func = self._pop().expr
            names = _split_top_level(names_entry)
            kwcount = min(len(names), len(args))
            pos_args = args[:-kwcount] if kwcount else args
            kw_values = args[-kwcount:] if kwcount else []
            kw_parts = [f"{k}={v}" for k, v in zip(names, kw_values)]
            self.pending_kw_names = ()
            self._push(f"{func}({', '.join(pos_args + kw_parts)})", origin=opname, kind="call", is_temp=False)
            return

        if opname == "CALL_FUNCTION_EX":
            flags = int(instr.arg or 0)
            stararg = self._pop().expr
            func = self._pop().expr
            if flags & 1:
                kwarg = self._pop().expr
                expr = f"{func}(*{stararg}, **{kwarg})"
            else:
                expr = f"{func}(*{stararg})"
            self.pending_kw_names = ()
            self._push(expr, origin=opname, kind="call", is_temp=False)
            return

        self._push(f"<{opname}>", origin=opname, kind="call", is_temp=False)

    def _maybe_store_import(self, opname: str, name: str, value: str, kind: str, module: Optional[str], imported: Optional[str]) -> Optional[str]:
        if kind == "import":
            if imported and module:
                if opname in {"STORE_FAST", "STORE_NAME", "STORE_GLOBAL", "STORE_DEREF"}:
                    if name != imported:
                        return f"from {module} import {imported} as {name}"
                    return f"from {module} import {imported}"
            if module:
                if opname in {"STORE_FAST", "STORE_NAME", "STORE_GLOBAL", "STORE_DEREF"}:
                    if name != module:
                        return f"import {module} as {name}"
                    return f"import {module}"
        return None

    def _handle_store(self, instr: dis.Instruction) -> Optional[str]:
        entry = self._pop()
        value = entry.expr
        opname = instr.opname
        name = safe_str(instr.argrepr)

        if value == "__build_class__":
            return None

        import_stmt = self._maybe_store_import(opname, name, value, entry.kind, entry.import_module, entry.import_name)
        if import_stmt:
            return import_stmt

        if opname in {"STORE_FAST", "STORE_NAME", "STORE_GLOBAL", "STORE_DEREF"}:
            maybe_aug = self._looks_like_augassign(name, value)
            if maybe_aug:
                return maybe_aug
            return f"{name} = {value}"

        if opname == "STORE_ATTR":
            obj = self._pop().expr
            return f"{obj}.{name} = {value}"

        if opname == "STORE_SUBSCR":
            idx = self._pop().expr
            target = self._pop().expr
            return f"{target}[{idx}] = {value}"

        return None

    def _handle_delete(self, instr: dis.Instruction) -> Optional[str]:
        opname = instr.opname
        if opname in {"DELETE_FAST", "DELETE_NAME", "DELETE_GLOBAL"}:
            return f"del {safe_str(instr.argrepr)}"
        if opname == "DELETE_ATTR":
            obj = self._pop().expr
            return f"del {obj}.{safe_str(instr.argrepr)}"
        if opname == "DELETE_SUBSCR":
            idx = self._pop().expr
            target = self._pop().expr
            return f"del {target}[{idx}]"
        return None

    def _handle_subscr(self) -> None:
        idx = self._pop().expr
        obj = self._pop().expr
        self._push(f"{obj}[{idx}]", origin="BINARY_SUBSCR", kind="expr", is_temp=False)

    def _handle_return(self) -> Optional[str]:
        if not self.stack:
            return None
        value = self._pop().expr
        if value == "None":
            return None
        return f"return {value}"

    def _handle_pop_top(self) -> Optional[str]:
        if not self.stack:
            return None
        value = self._pop().expr
        if value in {"None", "__build_class__"} or "<code object" in value:
            return None
        return value

    def _handle_format_value(self, instr: dis.Instruction) -> None:
        value = self._pop().expr
        flags = int(instr.arg or 0)
        conversion = ""
        if flags & 0x01:
            conversion = "!r"
        elif flags & 0x02:
            conversion = "!s"
        elif flags & 0x04:
            conversion = "!a"
        self._push(f"{{{value}{conversion}}}", origin="FORMAT_VALUE", kind="expr", is_temp=True)

    def _handle_comprehension_append(self) -> None:
        if self.stack:
            self.stack.pop()

    def _handle_yield(self, instr: dis.Instruction) -> None:
        if not self.stack:
            return
        value = self._pop().expr
        if instr.opname == "YIELD_FROM":
            self._push(f"yield from {value}", origin=instr.opname, kind="expr", is_temp=False)
        else:
            self._push(f"yield {value}", origin=instr.opname, kind="expr", is_temp=False)

    def _handle_raise(self, instr: dis.Instruction) -> Optional[str]:
        argc = int(instr.arg or 0)
        if argc == 0:
            return "raise"
        if argc == 1:
            exc = self._pop().expr
            return f"raise {exc}"
        if argc == 2:
            exc = self._pop().expr
            cause = self._pop().expr
            return f"raise {exc} from {cause}"
        return "raise"

    def _handle_import(self, instr: dis.Instruction) -> None:
        try:
            self._pop()
            self._pop()
        except Exception:
            pass
        module = normalize_module_name(instr.argval)
        self.pending_import_module = module
        self._push(module, origin="IMPORT_NAME", kind="import", is_temp=False, module=module, name=module)

    def _handle_import_from(self, instr: dis.Instruction) -> None:
        name = sanitize_identifier(safe_str(instr.argrepr), "item")
        module = self.pending_import_module or self.stack.peek().expr
        self._push(name, origin="IMPORT_FROM", kind="import", is_temp=False, module=module, name=name)


# ---------------------------------------------------------------------------
# Structured decompiler
# ---------------------------------------------------------------------------


class StructuredDecompiler:
    def __init__(self, code: CodeType):
        self.code = code
        self.output_lines: List[str] = []
        self.indent = 0
        self._comp_counter = 0

    def decompile(self) -> str:
        self.output_lines = []
        self.indent = 0
        self._emit_code_object(self.code, is_root=True)
        return "\n".join(self.output_lines).rstrip() + "\n"

    def _emit_code_object(self, code: CodeType, is_root: bool = False) -> None:
        if is_root:
            for child in self._direct_code_children(code):
                self._emit_code_object(child, is_root=False)
            self._emit_body(code, kind="module")
            return

        if self._is_class_like(code):
            self._emit_line(f"class {sanitize_identifier(code.co_name, 'Class')}:")
            self.indent += 1
            emitted_any = False
            for child in self._direct_code_children(code):
                self._emit_code_object(child, is_root=False)
                emitted_any = True
            for line in self._body_lines(code, kind="class"):
                self._emit_line(line)
                emitted_any = True
            if not emitted_any:
                self._emit_line("pass")
            self.indent -= 1
            return

        self._emit_line(self._function_header(code))
        self.indent += 1
        emitted_any = False
        for child in self._direct_code_children(code):
            self._emit_code_object(child, is_root=False)
            emitted_any = True
        for line in self._body_lines(code, kind="function"):
            self._emit_line(line)
            emitted_any = True
        if not emitted_any:
            self._emit_line("pass")
        self.indent -= 1

    def _is_class_like(self, code: CodeType) -> bool:
        names = set(code.co_names)
        return "__module__" in names and "__qualname__" in names and code.co_name != "<module>"

    def _is_comp_like(self, code: CodeType) -> bool:
        return code.co_name in {"<genexpr>", "<listcomp>", "<setcomp>", "<dictcomp>"}

    def _comp_name(self, code: CodeType) -> str:
        self._comp_counter += 1
        return f"{sanitize_identifier(code.co_name, 'comp')}_{self._comp_counter}"

    def _direct_code_children(self, code: CodeType) -> List[CodeType]:
        seen: Set[int] = set()
        items: List[CodeType] = []
        try:
            instructions = dis.get_instructions(code, **get_dis_kwargs())
        except TypeError:
            instructions = dis.get_instructions(code)
        for instr in instructions:
            if instr.opname == "LOAD_CONST" and isinstance(instr.argval, CodeType):
                child = instr.argval
                key = id(child)
                if key not in seen:
                    seen.add(key)
                    items.append(child)
        if not items:
            for const in code.co_consts:
                if isinstance(const, CodeType):
                    key = id(const)
                    if key not in seen:
                        seen.add(key)
                        items.append(const)
        return items

    def _function_header(self, code: CodeType) -> str:
        if self._is_comp_like(code):
            return f"def {self._comp_name(code)}(_iterable):"

        posonly = getattr(code, "co_posonlyargcount", 0)
        argcount = getattr(code, "co_argcount", 0)
        kwonly = getattr(code, "co_kwonlyargcount", 0)
        flags = getattr(code, "co_flags", 0)
        varnames = list(getattr(code, "co_varnames", ()))

        parts: List[str] = []
        args = [sanitize_param_name(name, i) for i, name in enumerate(varnames[:argcount])]

        if posonly:
            parts.extend(args[:posonly])
            parts.append("/")
            args = args[posonly:]

        parts.extend(args)

        if kwonly:
            kw_args = [sanitize_param_name(name, argcount + i) for i, name in enumerate(varnames[argcount : argcount + kwonly])]
            if kw_args:
                parts.append("*")
                parts.extend(kw_args)

        if flags & 0x04:
            parts.append("*args")
        if flags & 0x08:
            parts.append("**kwargs")

        return f"def {sanitize_identifier(code.co_name, 'func')}({', '.join(p for p in parts if p)}):"

    def _body_lines(self, code: CodeType, kind: str) -> List[str]:
        builder = ExpressionBuilder(code)
        builder.reset()
        lines: List[str] = []

        try:
            instructions = dis.get_instructions(code, **get_dis_kwargs())
        except TypeError:
            instructions = dis.get_instructions(code)

        for instr in instructions:
            stmt = builder.process_instruction(instr)
            if not stmt:
                continue
            stmt = stmt.strip()
            if not stmt:
                continue

            # --- التعديل والإصلاح هنا لتصفية السطور الزائدة ومخلفات البناء التلقائي ---
            if "<code object" in stmt or "__build_class__" in stmt:
                continue

            if stmt == "return None" and kind in {"module", "class"}:
                continue
            # -----------------------------------------------------------------

            if kind == "module" and stmt == "return None":
                continue

            if kind == "class":
                synthetic_prefixes = (
                    "__module__ =",
                    "__qualname__ =",
                    "__doc__ =",
                    "__firstlineno__ =",
                    "__static_attributes__ =",
                )
                if stmt.startswith(synthetic_prefixes):
                    continue

            if stmt.startswith("__import__("):
                continue

            if kind in {"module", "class"} and stmt in {"__build_class__", "None"}:
                continue

            if stmt == "pass" and lines and lines[-1] == "pass":
                continue

            lines.append(stmt)

        if kind == "module":
            lines = [line for line in lines if line != "return None"]
        return lines

    def _emit_body(self, code: CodeType, kind: str) -> None:
        lines = self._body_lines(code, kind=kind)
        if not lines:
            self._emit_line("pass")
            return
        for line in lines:
            self._emit_line(line)

    def _emit_line(self, line: str) -> None:
        self.output_lines.append(("    " * self.indent + line) if line else "")


# ---------------------------------------------------------------------------
# Post-processing and repair
# ---------------------------------------------------------------------------


BROKEN_CALL_CLEAR_PATTERN = re.compile(
    r"""
    (?P<callee>['\"](?:cls|clear)['\"])\s*
    \(\s*
    (?P<arg>['\"](?:cls|clear)['\"])\s*
    \)
    """,
    re.VERBOSE,
)

BROKEN_AUGASSIGN_PATTERN = re.compile(
    r"""
    (?P<lhs>[A-Za-z_][\w\.]*)
    \s*=\s*
    \(\s*
    (?P=lhs)
    \s*(?P<op>\+=|-=|\*=|/=|//=|%=|&=|\|=|\^=|<<=|>>=)
    \s*(?P<rhs>[^()\n]+?)
    \s*\)
    """,
    re.VERBOSE,
)

BROKEN_NONE_CALL_PATTERN = re.compile(r"\bNone\s*\(\s*None\s*,\s*None\s*\)")
BROKEN_STR_CALL_PATTERN = re.compile(r"(?<![\w.])(['\"])(?P<name>[A-Za-z_][A-Za-z0-9_]*)\1\((['\"])(?P=name)\3\)")
BROKEN_RETURN_NONE_PATTERN = re.compile(r"^\s*return\s+None\s*$", re.M)


def _strip_redundant_parens(text: str) -> str:
    text = re.sub(r"\breturn\s+\(([^()\n]+)\)", r"return \1", text)
    text = re.sub(r"\bdel\s+\(([^()\n]+)\)", r"del \1", text)
    return text


def _simplify_join_calls(text: str) -> str:
    text = re.sub(r'""\.join\(\[([^\[\]]+)\]\)', r'"".join([\1])', text)
    return text


def _drop_noise_lines(lines: List[str]) -> List[str]:
    cleaned: List[str] = []
    for line in lines:
        s = line.strip()
        if not s:
            cleaned.append(line)
            continue
        if s in {"None(None, None)", "__build_class__"}:
            continue
        if s.startswith("ImportError") or s.startswith("ModuleNotFoundError"):
            continue
        if re.fullmatch(r"[A-Za-z_][\w.]*\(None, None\)", s):
            continue
        cleaned.append(line)
    return cleaned


def restore_common_decompiler_artifacts(source: str) -> str:
    """Heuristically repair common bytecode-to-source artifacts."""
    if not source:
        return source

    source = source.replace(" + NULL|self", "")
    source = source.replace("NULL|self", "")
    source = source.replace("NULL + ", "")
    source = source.replace("NULL+", "")

    def _clear_call_repl(match: re.Match) -> str:
        arg = match.group("arg")
        return f"os.system({arg})"

    source = BROKEN_CALL_CLEAR_PATTERN.sub(_clear_call_repl, source)
    source = BROKEN_AUGASSIGN_PATTERN.sub(lambda m: f"{m.group('lhs')} {m.group('op')} {m.group('rhs').strip()}", source)
    source = BROKEN_STR_CALL_PATTERN.sub(lambda m: f"{m.group('name')}('{m.group('name')}')", source)
    source = re.sub(r"\s*\+\s*NULL\|self\b", "", source)
    source = _strip_redundant_parens(source)
    source = _simplify_join_calls(source)

    lines: List[str] = []
    prev_blank = False
    for line in source.splitlines():
        s = line.strip()
        if s in {"None(None, None)"}:
            continue
        if not s:
            if prev_blank:
                continue
            prev_blank = True
        else:
            prev_blank = False
        lines.append(line)

    lines = _drop_noise_lines(lines)
    return "\n".join(lines) + ("\n" if lines else "")


def strip_comments_and_docstrings(source: str) -> str:
    try:
        sio = io.StringIO(source)
        out: List[str] = []
        prev_toktype = tokenize.INDENT
        last_lineno = -1
        last_col = 0

        for tok in tokenize.generate_tokens(sio.readline):
            tok_type = tok.type
            tok_string = tok.string
            start_line, start_col = tok.start
            end_line, end_col = tok.end

            if start_line > last_lineno:
                last_col = 0

            if start_col > last_col:
                out.append(" " * (start_col - last_col))

            if tok_type == tokenize.COMMENT:
                pass
            elif tok_type == tokenize.STRING:
                if prev_toktype in (tokenize.INDENT, tokenize.NEWLINE, tokenize.NL):
                    pass
                else:
                    out.append(tok_string)
            else:
                out.append(tok_string)

            prev_toktype = tok_type
            last_lineno = end_line
            last_col = end_col

        text = "".join(out)
    except Exception:
        return source

    try:
        tree = ast.parse(text)

        class DocstringRemover(ast.NodeTransformer):
            def _strip_first(self, node: ast.AST) -> ast.AST:
                body = getattr(node, "body", None)
                if isinstance(body, list) and body:
                    first = body[0]
                    if isinstance(first, ast.Expr) and isinstance(getattr(first, "value", None), ast.Constant):
                        if isinstance(first.value.value, str):
                            body.pop(0)
                return node

            def visit_Module(self, node: ast.Module) -> ast.AST:
                self.generic_visit(node)
                return self._strip_first(node)

            def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
                self.generic_visit(node)
                return self._strip_first(node)

            def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> ast.AST:
                self.generic_visit(node)
                return self._strip_first(node)

            def visit_ClassDef(self, node: ast.ClassDef) -> ast.AST:
                self.generic_visit(node)
                return self._strip_first(node)

        tree = DocstringRemover().visit(tree)
        ast.fix_missing_locations(tree)
        if hasattr(ast, "unparse"):
            cleaned = ast.unparse(tree)
            return cleaned + ("\n" if not cleaned.endswith("\n") else "")
        return text
    except Exception:
        return text


def _post_ast_cleanup(text: str) -> str:
    try:
        tree = ast.parse(text)
    except Exception:
        return text

    class Cleanup(ast.NodeTransformer):
        def visit_Expr(self, node: ast.Expr) -> Any:
            self.generic_visit(node)
            if isinstance(node.value, ast.Constant) and node.value.value is None:
                return None
            return node

        def visit_Pass(self, node: ast.Pass) -> Any:
            return node

    tree = Cleanup().visit(tree)
    ast.fix_missing_locations(tree)
    try:
        if hasattr(ast, "unparse"):
            cleaned = ast.unparse(tree)
            return cleaned + ("\n" if not cleaned.endswith("\n") else "")
    except Exception:
        pass
    return text


def format_with_autopep8(source: str, passes: int = 1) -> str:
    source = restore_common_decompiler_artifacts(source)
    source = strip_comments_and_docstrings(source)
    source = _post_ast_cleanup(source)
    if autopep8 is None:
        return source

    options = {
        "aggressive": 2,
        "experimental": True,
        "max_line_length": 88,
    }

    for _ in range(max(1, passes)):
        try:
            source = autopep8.fix_code(source, options=options)
        except Exception:
            break
    return source


# ---------------------------------------------------------------------------
# CLI helpers
# ---------------------------------------------------------------------------


def collect_paths(inputs: Sequence[str], recurse: bool = False, ext: str = ".pyc") -> List[Path]:
    result: List[Path] = []
    for item in inputs:
        p = Path(item)
        if p.is_dir():
            if recurse:
                result.extend(sorted(p.rglob(f"*{ext}")))
            else:
                result.extend(sorted(p.glob(f"*{ext}")))
        else:
            if ext == "" or p.suffix == ext or p.name.endswith(ext):
                result.append(p)
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pyc-rebuilder", description="Best-effort .pyc / marshal / source extractor.")
    parser.add_argument("files", nargs="*", default=["."], help=".pyc files, .py files, or directories")
    parser.add_argument("-o", "--output", help="Write output to file")
    parser.add_argument("-r", "--recurse", action="store_true", help="Recurse into directories")
    parser.add_argument("--show-dis", action="store_true", help="Append disassembly to output")
    parser.add_argument("--strict", action="store_true", help="Abort on the first error")
    parser.add_argument("--no-format", action="store_true", help="Skip auto-formatting")
    parser.add_argument("--selftest", action="store_true", help="Run a tiny local syntax self-test and exit")
    return parser


class PycDecompiler:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.header: Optional[PycHeader] = None
        self.code: Optional[CodeType] = None
        self._load()

    def _load(self) -> None:
        suffix = self.path.suffix.lower()
        
        if suffix == ".pyc":
            self.header, self.code = read_pyc_file(self.path)
        elif suffix == ".py":
            text = self.path.read_text(encoding="utf-8", errors="ignore")
            self.code = extract_marshaled_code_object(text)
            if self.code is None:
                raise RuntimeError(f"Could not extract a code object from {self.path}")
        else:
            raise RuntimeError(f"Unsupported file type: {self.path}")

    def decompile(self, show_disassembly: bool = False, format_source: bool = True) -> str:
        if self.code is None:
            raise RuntimeError("No code object loaded")

        decompiler = StructuredDecompiler(self.code)
        source = decompiler.decompile()
        if format_source:
            source = format_with_autopep8(source)

        parts = [
            f"# Source: {self.path}",
            f"# Python version: {sys.version}",
            "# BY: AHMEDALHRRANI ~ T.me : @maho_s9",
            "",
            source.rstrip(),
        ]

        if show_disassembly:
            parts.extend(["", "# --- Disassembly ---", self._disassemble()])

        return "\n".join(parts).rstrip() + "\n"

    def _disassemble(self) -> str:
        buf = io.StringIO()
        try:
            dis.dis(self.code, file=buf, **get_dis_kwargs())
        except TypeError:
            dis.dis(self.code, file=buf)
        except Exception as exc:
            buf.write(f"# Disassembly failed: {format_exception(exc)}")
        return buf.getvalue().rstrip()

    def __str__(self) -> str:
        return self.decompile(show_disassembly=False, format_source=True)



def decompile_python_source(path: Path, show_disassembly: bool = False, format_source: bool = True) -> str:
    text = path.read_text(encoding="utf-8", errors="ignore")
    code = extract_marshaled_code_object(text)
    if code is None:
        raise RuntimeError(f"Could not extract a code object from {path}")

    decompiler = StructuredDecompiler(code)
    source = decompiler.decompile()
    if format_source:
        source = format_with_autopep8(source)

    parts = [
        f"# Source: {path}",
        f"# Python version: {sys.version}",
        "# BY: AHMEDALHRRANI ~ T.me : @maho_s9",
        "",
        source.rstrip(),
    ]

    if show_disassembly:
        buf = io.StringIO()
        try:
            dis.dis(code, file=buf, **get_dis_kwargs())
        except TypeError:
            dis.dis(code, file=buf)
        parts.extend(["", "# --- Disassembly ---", buf.getvalue().rstrip()])

    return "\n".join(parts).rstrip() + "\n"


def process_path(path: Path, show_disassembly: bool, format_source: bool) -> str:
    return PycDecompiler(path).decompile(show_disassembly=show_disassembly, format_source=format_source)


# ---------------------------------------------------------------------------
# Tiny self-test
# ---------------------------------------------------------------------------


REGRESSION_SNIPPETS: Tuple[str, ...] = (
    "email.split('@')[0]",
    "response.json()['date']",
    "hit += 1",
    "os.system('clear')",
    "requests.post(url, headers=headers, data=data)",
    "''.join([a, b, c])",
)


def selftest_compile_roundtrip(snippets: Iterable[str]) -> List[Tuple[str, bool]]:
    results: List[Tuple[str, bool]] = []
    for s in snippets:
        try:
            compile(s, "<selftest>", "exec")
            results.append((s, True))
        except Exception:
            results.append((s, False))
    return results


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.selftest:
        results = selftest_compile_roundtrip(REGRESSION_SNIPPETS)
        for snippet, ok in results:
            print(f"{snippet!r}: {'OK' if ok else 'FAIL'}")
        return 0

    paths: List[Path] = []
    for item in args.files:
        p = Path(item)
        if p.is_dir():
            paths.extend(collect_paths([item], recurse=args.recurse, ext=".pyc"))
            paths.extend(collect_paths([item], recurse=args.recurse, ext=".py"))
        else:
            if p.exists():
                paths.append(p)

    if not paths:
        print("No input files found.", file=sys.stderr)
        return 1

    outputs: List[str] = []
    for path in paths:
        try:
            outputs.append(process_path(path, show_disassembly=args.show_dis, format_source=not args.no_format))
        except Exception as exc:
            outputs.append(f"# Error processing {path}: {format_exception(exc)}\n")
            if args.strict:
                raise

    final = "\n".join(outputs).rstrip() + "\n"

    if args.output:
        try:
            Path(args.output).write_text(final, encoding="utf-8")
        except Exception as exc:
            print(f"Failed to write output: {exc}", file=sys.stderr)
            return 1
    else:
        sys.stdout.write(final)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
