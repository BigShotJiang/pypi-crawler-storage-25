"""
Local flight search — runs 195 airline connectors on the user's machine.

Can be used programmatically:

    from letsfg.local import search_local
    result = await search_local("SHA", "CTU", "2026-03-20")

Or as a subprocess (used by the npm MCP server + JS SDK):

    echo '{"origin":"SHA","destination":"CTU","date_from":"2026-03-20"}' | python -m letsfg.local

**GitHub Star Required!**
Before using the SDK, you must:
1. Star https://github.com/LetsFG/LetsFG
2. Run: letsfg star --github <your-username>

This is completely FREE — just a star to help us grow!

**For Hosted/API Usage (Messenger, etc.):**
- Search is FREE, results are MASKED
- Unlock fee: 1% of ticket (min $1) to reveal airline & booking link
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from datetime import date

from letsfg.models.flights import FlightSearchRequest, cache_offers

logger = logging.getLogger(__name__)


def _is_hosted_mode() -> bool:
    """Check if running in hosted/API mode (Messenger, etc.) vs local developer mode."""
    # Hosted mode if: LETSFG_HOSTED=1, or running via API server
    return os.environ.get("LETSFG_HOSTED", "").lower() in ("1", "true", "yes")


def _check_star_verification() -> None:
    """
    Check GitHub star verification for local (non-hosted) usage.
    
    Raises StarRequiredError if not verified.
    Skipped in hosted mode (Messenger/API) since those users pay unlock fees.
    """
    if _is_hosted_mode():
        # Hosted mode doesn't require star — they pay unlock fees
        return
    
    from letsfg.config import require_star_verification
    require_star_verification()


async def search_local(
    origin: str,
    destination: str,
    date_from: str,
    *,
    return_date: str | None = None,
    adults: int = 1,
    children: int = 0,
    infants: int = 0,
    cabin_class: str | None = None,
    currency: str = "EUR",
    limit: int = 50,
    max_browsers: int | None = None,
    max_stopovers: int | None = None,
    masked: bool | None = None,  # None = auto-detect, True = force mask, False = no mask
) -> dict:
    """
    Run all 195 local airline connectors and return results as a dict.

    This is the core local search — no API key needed, no backend.
    Connectors run on the user's machine via Playwright + httpx.

    **GitHub Star Required!**
    Before using, you must star https://github.com/LetsFG/LetsFG
    and run: letsfg star --github <your-username>

    Args:
        max_browsers: Max concurrent browser processes (1–32).
            None = auto-detect based on system RAM.
        masked: Control result masking:
            None = auto (local=unmasked, hosted=masked)
            True = force masking (for hosted/API)
            False = no masking (for developers)
    
    Raises:
        StarRequiredError: If GitHub star not verified (local mode only).
    """
    # Check GitHub star verification (only for local/CLI, not hosted)
    _check_star_verification()
    
    from letsfg.connectors.engine import multi_provider

    # Apply concurrency setting before search starts
    if max_browsers is not None:
        from letsfg.connectors.browser import configure_max_browsers
        configure_max_browsers(max_browsers)

    req = FlightSearchRequest(
        origin=origin.upper(),
        destination=destination.upper(),
        date_from=date.fromisoformat(date_from),
        return_from=date.fromisoformat(return_date) if return_date else None,
        adults=adults,
        children=children,
        infants=infants,
        cabin_class=cabin_class.upper() if cabin_class else None,
        currency=currency,
        limit=limit,
        max_stopovers=max_stopovers if max_stopovers is not None else 2,
    )

    resp = await multi_provider.search_flights(req)
    
    # Determine if we should mask results
    should_mask = masked if masked is not None else _is_hosted_mode()
    
    if should_mask and resp.offers:
        # Hosted mode: mask results, cache originals for unlock
        masked_resp, offer_cache = resp.to_masked()
        cache_offers(offer_cache)
        return masked_resp.model_dump(mode="json")
    
    return resp.model_dump(mode="json")


def _main() -> None:
    """Entry point for subprocess invocation: reads JSON from stdin, writes JSON to stdout."""
    import os
    import warnings

    # Suppress asyncio transport cleanup noise (Python 3.13+)
    warnings.filterwarnings("ignore", category=ResourceWarning, message=".*unclosed transport.*")
    _orig_unraisable = sys.unraisablehook
    def _quiet_unraisable(hook_args):
        try:
            if hook_args.exc_type is ValueError and "pipe" in str(hook_args.exc_value).lower():
                return
            if "transport" in str(getattr(hook_args, "object", "")):
                return
        except Exception:
            return
        _orig_unraisable(hook_args)
    sys.unraisablehook = _quiet_unraisable

    # Suppress Node.js DEP0169 warnings from Playwright subprocesses
    os.environ.setdefault("NODE_OPTIONS", "--no-deprecation")

    raw = sys.stdin.read().strip()
    if not raw:
        json.dump({"error": "No input provided. Send JSON on stdin."}, sys.stdout)
        sys.exit(1)

    try:
        params = json.loads(raw)
    except json.JSONDecodeError as e:
        json.dump({"error": f"Invalid JSON: {e}"}, sys.stdout)
        sys.exit(1)

    # System info query (used by MCP server's system_info tool)
    if params.get("__system_info"):
        from letsfg.system_info import get_system_profile
        from letsfg.connectors.browser import get_max_browsers
        profile = get_system_profile()
        profile["current_max_browsers"] = get_max_browsers()
        json.dump(profile, sys.stdout)
        return

    # Suppress noisy logs — only errors to stderr
    logging.basicConfig(
        level=logging.WARNING,
        format="%(name)s %(levelname)s %(message)s",
        stream=sys.stderr,
    )

    async def _run():
        asyncio.get_event_loop().set_exception_handler(lambda loop, ctx: None)
        return await search_local(
            origin=params["origin"],
            destination=params["destination"],
            date_from=params["date_from"],
            return_date=params.get("return_date") or params.get("return_from"),
            adults=params.get("adults", 1),
            children=params.get("children", 0),
            infants=params.get("infants", 0),
            cabin_class=params.get("cabin_class"),
            currency=params.get("currency", "EUR"),
            limit=params.get("limit", 50),
            max_browsers=params.get("max_browsers"),
            masked=params.get("masked"),  # None = auto, True = hosted, False = developer
        )

    try:
        result = asyncio.run(_run())
        json.dump(result, sys.stdout)
    except Exception as e:
        json.dump({"error": str(e)}, sys.stdout)
        sys.exit(1)


if __name__ == "__main__":
    _main()
