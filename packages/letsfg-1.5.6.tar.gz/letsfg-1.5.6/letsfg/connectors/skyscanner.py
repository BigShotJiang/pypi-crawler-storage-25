"""
Skyscanner connector — CDP Chrome + API response interception.

Skyscanner is the world's #1 flight meta-search engine, aggregating from
1200+ partners. Direct API access is blocked by PerimeterX, so we use
a real Chrome instance via CDP (not Playwright's bundled Chromium) to
bypass bot detection.

Strategy:
1.  Launch real system Chrome via CDP (Chromium Debug Protocol).
2.  Navigate to Skyscanner search results URL.
3.  Intercept the fps3/search (or similar) API response with flight data.
4.  Parse itineraries from the JSON response.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import os
import random
import subprocess
import time
from datetime import datetime, date as date_type
from typing import Any, Optional

from ..models.flights import (
    FlightOffer,
    FlightRoute,
    FlightSearchRequest,
    FlightSearchResponse,
    FlightSegment,
)
from .browser import (
    auto_block_if_proxied,
    block_heavy_resources,
    find_chrome,
    get_default_proxy,
    stealth_popen_kwargs,
    _launched_procs,
    proxy_chrome_args,
    proxy_is_configured,
    inject_stealth_js,
)

logger = logging.getLogger(__name__)

_DEBUG_PORT = 9470
_USER_DATA_DIR = os.path.join(
    os.environ.get("TEMP", "/tmp"), "chrome-cdp-skyscanner"
)


def _parse_dt(s: Any) -> datetime:
    if not s:
        return datetime(2000, 1, 1)
    s = str(s)
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00").split("+")[0])
    except (ValueError, AttributeError):
        return datetime(2000, 1, 1)


def _bezier_curve(t: float, p0: float, p1: float, p2: float, p3: float) -> float:
    """Calculate point on cubic bezier curve at parameter t."""
    return (
        (1-t)**3 * p0 +
        3 * (1-t)**2 * t * p1 +
        3 * (1-t) * t**2 * p2 +
        t**3 * p3
    )


async def _human_mouse_move(page, start_x: float, start_y: float, end_x: float, end_y: float):
    """Move mouse in a human-like bezier curve with variable speed."""
    distance = math.sqrt((end_x - start_x)**2 + (end_y - start_y)**2)
    steps = max(20, int(distance / 5))

    # Random control points for bezier curve (creates natural arc)
    mid_x = (start_x + end_x) / 2
    mid_y = (start_y + end_y) / 2

    ctrl1_x = start_x + (mid_x - start_x) * random.uniform(0.3, 0.7) + random.uniform(-50, 50)
    ctrl1_y = start_y + (mid_y - start_y) * random.uniform(0.3, 0.7) + random.uniform(-30, 30)
    ctrl2_x = mid_x + (end_x - mid_x) * random.uniform(0.3, 0.7) + random.uniform(-50, 50)
    ctrl2_y = mid_y + (end_y - mid_y) * random.uniform(0.3, 0.7) + random.uniform(-30, 30)

    for i in range(steps + 1):
        t = i / steps
        # Ease in-out for natural acceleration/deceleration
        t = t * t * (3 - 2 * t)

        x = _bezier_curve(t, start_x, ctrl1_x, ctrl2_x, end_x)
        y = _bezier_curve(t, start_y, ctrl1_y, ctrl2_y, end_y)

        # Add tiny jitter (human hands shake slightly)
        x += random.uniform(-1, 1)
        y += random.uniform(-1, 1)

        await page.mouse.move(x, y)

        # Variable delay (faster in middle, slower at start/end)
        delay = 0.008 + random.uniform(0, 0.012)
        if i < steps * 0.1 or i > steps * 0.9:
            delay += random.uniform(0.005, 0.015)
        await asyncio.sleep(delay)


async def _solve_px_captcha(page, max_attempts: int = 3) -> bool:
    """Solve PX press-and-hold captcha with human-like behavior."""
    for attempt in range(max_attempts):
        await asyncio.sleep(random.uniform(1.0, 2.0))

        # Find the captcha button
        button = page.locator('#px-captcha').first

        if await button.count() == 0:
            # Check if we're past the captcha
            url = page.url
            if "captcha" not in url.lower():
                return True
            logger.debug("SKYSCANNER: PX button not found, attempt %d", attempt)
            continue

        # Wait for button to be ready (show "PRESS & HOLD" text)
        for wait in range(10):
            try:
                text = await button.inner_text()
                if "press" in text.lower() or "hold" in text.lower():
                    logger.debug("SKYSCANNER: PX button ready: %s", text)
                    break
            except Exception:
                pass
            await asyncio.sleep(0.5)

        box = await button.bounding_box()
        if not box:
            logger.debug("SKYSCANNER: PX button no bounding box")
            continue

        # Button center with small random offset
        target_x = box['x'] + box['width'] / 2 + random.uniform(-10, 10)
        target_y = box['y'] + box['height'] / 2 + random.uniform(-5, 5)

        # Start from random position
        start_x = random.uniform(200, 800)
        start_y = random.uniform(100, 400)

        # Move to starting position
        await page.mouse.move(start_x, start_y)
        await asyncio.sleep(random.uniform(0.3, 0.6))

        # Human-like movement to button
        await _human_mouse_move(page, start_x, start_y, target_x, target_y)

        # Small pause before clicking
        await asyncio.sleep(random.uniform(0.15, 0.35))

        # Press and hold
        await page.mouse.down()

        # Hold with micro-movements (natural hand tremor) - longer hold time
        hold_time = random.uniform(4.0, 5.5)
        micro_steps = int(hold_time / 0.1)
        for _ in range(micro_steps):
            jitter_x = target_x + random.uniform(-2, 2)
            jitter_y = target_y + random.uniform(-2, 2)
            await page.mouse.move(jitter_x, jitter_y)
            await asyncio.sleep(0.1)

        # Release
        await page.mouse.up()
        await asyncio.sleep(3.0)

        # Check result
        current_url = page.url
        if "captcha" not in current_url.lower():
            logger.info("SKYSCANNER: PX captcha solved")
            return True

        await asyncio.sleep(random.uniform(1, 2))

    return False


class SkyscannerConnectorClient:
    """Skyscanner — meta-search, Playwright + API interception."""

    def __init__(self, timeout: float = 55.0):
        self.timeout = timeout

    async def close(self):
        pass

    async def search_flights(
        self, req: FlightSearchRequest
    ) -> FlightSearchResponse:
        t0 = time.monotonic()

        for attempt in range(2):
            try:
                offers = await self._do_search(req)
                if offers is not None:
                    offers.sort(
                        key=lambda o: o.price if o.price > 0 else float("inf")
                    )
                    elapsed = time.monotonic() - t0
                    logger.info(
                        "SKYSCANNER %s→%s: %d offers in %.1fs",
                        req.origin, req.destination, len(offers), elapsed,
                    )
                    h = hashlib.md5(
                        f"skyscanner{req.origin}{req.destination}{req.date_from}".encode()
                    ).hexdigest()[:12]
                    return FlightSearchResponse(
                        search_id=f"fs_ss_{h}",
                        origin=req.origin,
                        destination=req.destination,
                        currency=req.currency,
                        offers=offers,
                        total_results=len(offers),
                    )
            except Exception as e:
                logger.warning("SKYSCANNER attempt %d failed: %s", attempt, e)

        return self._empty(req)

    async def _do_search(
        self, req: FlightSearchRequest
    ) -> list[FlightOffer] | None:
        """Search Skyscanner using patchright with captcha solving."""
        # Try patchright first (anti-detection), fall back to playwright
        try:
            from patchright.async_api import async_playwright
            logger.debug("SKYSCANNER: using patchright")
        except ImportError:
            from playwright.async_api import async_playwright
            logger.debug("SKYSCANNER: patchright not installed, using playwright")

        api_responses: list[dict] = []

        async def on_response(response):
            """Intercept API responses with flight data."""
            url = response.url
            # Match both old and new API patterns
            hit = (
                "/g/radar/api/v2/web-unified-search" in url  # New unified search
                or "fps3/search" in url  # Old FPS3
                or "flights/live/search" in url
                or "/api/v3/" in url
            )
            if not hit:
                return
            try:
                if response.status != 200:
                    return
                body = await response.text()
                if len(body) > 5000:
                    data = json.loads(body)
                    # Check for itineraries in new or old format
                    itineraries = data.get("itineraries", {})
                    if isinstance(itineraries, dict) and itineraries.get("results"):
                        api_responses.append(data)
                        logger.info("SKYSCANNER: captured unified search response (%d results)",
                                    len(itineraries.get("results", [])))
                    elif data.get("content", {}).get("results", {}).get("itineraries"):
                        api_responses.append(data)
                        logger.info("SKYSCANNER: captured fps3 response")
            except Exception:
                pass

        # Build proxy config if available
        proxy_config = get_default_proxy()

        pw = await async_playwright().start()
        browser = None
        context = None
        page = None

        try:
            browser = await pw.chromium.launch(headless=False)

            context = await browser.new_context(
                proxy=proxy_config,
                viewport={"width": 1920, "height": 1080},
                locale="en-US",
                timezone_id="Europe/London",
            )
            page = await context.new_page()

            # Set up response interception
            page.on("response", on_response)

            # Random initial mouse position
            await page.mouse.move(random.randint(400, 800), random.randint(300, 500))

            # Visit homepage first
            logger.info("SKYSCANNER: visiting homepage")
            await page.goto("https://www.skyscanner.com/", timeout=60000)
            await asyncio.sleep(2)

            # Check for captcha on homepage
            url = page.url
            if "captcha" in url.lower():
                logger.info("SKYSCANNER: solving homepage captcha")
                solved = await _solve_px_captcha(page)
                if not solved:
                    logger.warning("SKYSCANNER: failed to solve homepage captcha")
                    return None
                await asyncio.sleep(1)

            # Dismiss cookie consent
            try:
                await page.evaluate("""() => {
                    const btn = document.querySelector('#acceptCookieButton, button[id*="accept"], [data-testid="accept-button"]');
                    if (btn && btn.offsetHeight > 0) btn.click();
                }""")
                await asyncio.sleep(1)
            except Exception:
                pass

            # Navigate to search results
            d = req.date_from
            origin = req.origin.upper()
            dest = req.destination.upper()
            date_str = f"{d.year % 100:02d}{d.month:02d}{d.day:02d}"
            search_url = (
                f"https://www.skyscanner.com/transport/flights/"
                f"{origin.lower()}/{dest.lower()}/{date_str}/"
                f"?adultsv2={req.adults or 1}&cabinclass=economy&ref=home"
            )

            logger.info("SKYSCANNER: navigating to search %s→%s", origin, dest)
            await page.goto(search_url, timeout=60000)
            await asyncio.sleep(2)

            # Check for captcha on search page
            url = page.url
            if "captcha" in url.lower():
                logger.info("SKYSCANNER: solving search page captcha")
                solved = await _solve_px_captcha(page)
                if not solved:
                    logger.warning("SKYSCANNER: failed to solve search captcha")
                    return None
                await asyncio.sleep(2)

            # Wait for API responses
            logger.info("SKYSCANNER: waiting for flight data")
            for tick in range(20):
                await asyncio.sleep(2)
                if api_responses:
                    # Wait a bit more for additional data
                    await asyncio.sleep(5)
                    break

        except Exception as e:
            logger.error("SKYSCANNER browser error: %s", e)
            return None
        finally:
            try:
                if page:
                    await page.close()
                if context:
                    await context.close()
                if browser:
                    await browser.close()
            except Exception:
                pass
            try:
                await pw.stop()
            except Exception:
                pass

        if not api_responses:
            logger.warning("SKYSCANNER: no flight API response captured")
            return None

        # Use the response with most data
        best = max(api_responses, key=lambda d: len(json.dumps(d)))
        return _parse_skyscanner(best, req)

    def _empty(self, req: FlightSearchRequest) -> FlightSearchResponse:
        return FlightSearchResponse(
            search_id="",
            origin=req.origin,
            destination=req.destination,
            currency=req.currency,
            offers=[],
            total_results=0,
        )


def _parse_skyscanner(data: dict, req: FlightSearchRequest) -> list[FlightOffer]:
    """Parse Skyscanner API response into FlightOffer list.

    Supports two formats:
    1. Old fps3 format: data.content.results.{itineraries (dict), legs, segments, carriers, places}
    2. New unified search: data.itineraries.results (list with inline leg/segment data)
    """
    target_cur = req.currency or "EUR"
    offers: list[FlightOffer] = []

    # Try new unified search format first (itineraries.results is a list)
    itineraries_data = data.get("itineraries", {})
    results_list = itineraries_data.get("results", [])

    if isinstance(results_list, list) and results_list:
        # NEW FORMAT: itineraries.results is a list with inline data
        logger.info("SKYSCANNER: parsing new unified search format (%d results)", len(results_list))
        for itin in results_list:
            try:
                if not isinstance(itin, dict):
                    continue

                # Price
                price_data = itin.get("price", {})
                if isinstance(price_data, dict):
                    raw_price = price_data.get("raw")
                else:
                    raw_price = None
                if not raw_price or float(raw_price) <= 0:
                    continue

                price = float(raw_price)

                # Legs (inline with full data)
                legs = itin.get("legs", [])
                if not legs:
                    continue

                # Build outbound from first leg
                out_leg = legs[0]
                if not isinstance(out_leg, dict):
                    continue

                flight_segments: list[FlightSegment] = []
                segments = out_leg.get("segments", [])

                for seg in segments:
                    if not isinstance(seg, dict):
                        continue
                    mc = seg.get("marketingCarrier", {})
                    airline_code = mc.get("displayCode") or mc.get("alternateId") or ""
                    airline_name = mc.get("name", airline_code)

                    origin_data = seg.get("origin", {})
                    dest_data = seg.get("destination", {})

                    flight_segments.append(FlightSegment(
                        airline=airline_code,
                        airline_name=airline_name,
                        flight_no=f"{airline_code}{seg.get('flightNumber', '')}",
                        origin=origin_data.get("displayCode", req.origin),
                        destination=dest_data.get("displayCode", req.destination),
                        departure=_parse_dt(seg.get("departure")),
                        arrival=_parse_dt(seg.get("arrival")),
                    ))

                if not flight_segments:
                    continue

                total_dur = (out_leg.get("durationInMinutes") or 0) * 60
                stopovers = out_leg.get("stopCount", max(0, len(flight_segments) - 1))
                outbound = FlightRoute(
                    segments=flight_segments,
                    total_duration_seconds=total_dur,
                    stopovers=stopovers,
                )

                # Build inbound (if round-trip)
                inbound = None
                if len(legs) > 1:
                    ret_leg = legs[1]
                    if isinstance(ret_leg, dict):
                        ret_segments: list[FlightSegment] = []
                        for seg in ret_leg.get("segments", []):
                            if not isinstance(seg, dict):
                                continue
                            mc = seg.get("marketingCarrier", {})
                            airline_code = mc.get("displayCode") or mc.get("alternateId") or ""
                            origin_data = seg.get("origin", {})
                            dest_data = seg.get("destination", {})
                            ret_segments.append(FlightSegment(
                                airline=airline_code,
                                airline_name=mc.get("name", airline_code),
                                flight_no=f"{airline_code}{seg.get('flightNumber', '')}",
                                origin=origin_data.get("displayCode", req.destination),
                                destination=dest_data.get("displayCode", req.origin),
                                departure=_parse_dt(seg.get("departure")),
                                arrival=_parse_dt(seg.get("arrival")),
                            ))
                        if ret_segments:
                            inbound = FlightRoute(
                                segments=ret_segments,
                                total_duration_seconds=(ret_leg.get("durationInMinutes") or 0) * 60,
                                stopovers=ret_leg.get("stopCount", max(0, len(ret_segments) - 1)),
                            )

                # Get airlines from segments (has correct displayCode)
                all_airlines = list(dict.fromkeys(s.airline for s in flight_segments if s.airline))

                itin_id = itin.get("id", "")
                h = hashlib.md5(f"ss_{itin_id}_{price}".encode()).hexdigest()[:10]

                offers.append(FlightOffer(
                    id=f"ss_{h}",
                    price=price,
                    currency=target_cur,
                    price_formatted=f"{target_cur} {price:.2f}",
                    outbound=outbound,
                    inbound=inbound,
                    airlines=all_airlines,
                    owner_airline=all_airlines[0] if all_airlines else "",
                    source="skyscanner_meta",
                    source_tier="free",
                    is_locked=False,
                    booking_url=f"https://www.skyscanner.net/transport/flights/{req.origin.lower()}/{req.destination.lower()}/",
                ))
            except Exception as e:
                logger.warning("SKYSCANNER: parse unified itinerary failed: %s", e)

        return offers

    # FALLBACK: Old fps3 format (data.content.results.itineraries is a dict)
    content = data.get("content") or data.get("data") or data
    results = content.get("results") or content

    # Build lookup maps for old format
    legs_map: dict[str, dict] = {}
    for lid, leg in (results.get("legs") or {}).items():
        if isinstance(leg, dict):
            legs_map[lid] = leg

    segments_map: dict[str, dict] = {}
    for sid, seg in (results.get("segments") or {}).items():
        if isinstance(seg, dict):
            segments_map[sid] = seg

    carriers_map: dict[str, dict] = {}
    for cid, carrier in (results.get("carriers") or {}).items():
        if isinstance(carrier, dict):
            carriers_map[cid] = carrier

    places_map: dict[str, dict] = {}
    for pid, place in (results.get("places") or {}).items():
        if isinstance(place, dict):
            places_map[pid] = place

    itineraries = results.get("itineraries") or {}
    if not isinstance(itineraries, dict):
        logger.warning("SKYSCANNER: unexpected itineraries type: %s", type(itineraries))
        return offers

    for itin_id, itin in itineraries.items():
        try:
            if not isinstance(itin, dict):
                continue
            # Price — look in pricingOptions
            pricing_opts = itin.get("pricingOptions") or []
            if not pricing_opts:
                continue
            best_price = None
            for po in pricing_opts:
                p = po.get("price") or {}
                amount = p.get("amount")
                if amount is not None:
                    amt = float(str(amount).replace(",", ""))
                    if best_price is None or amt < best_price:
                        best_price = amt
            if not best_price or best_price <= 0:
                continue

            # Leg IDs
            leg_ids = itin.get("legIds") or []
            if not leg_ids:
                continue

            # Build outbound from first leg
            out_leg = legs_map.get(leg_ids[0], {})
            seg_ids = out_leg.get("segmentIds") or []
            flight_segments: list[FlightSegment] = []

            for sid in seg_ids:
                seg = segments_map.get(sid, {})
                carrier_id = str(seg.get("marketingCarrierId") or seg.get("operatingCarrierId", ""))
                carrier_info = carriers_map.get(carrier_id, {})
                carrier_name = carrier_info.get("name", carrier_id)

                origin_id = str(seg.get("originPlaceId", ""))
                dest_id = str(seg.get("destinationPlaceId", ""))
                origin_place = places_map.get(origin_id, {})
                dest_place = places_map.get(dest_id, {})

                flight_segments.append(FlightSegment(
                    airline=carrier_info.get("iata", carrier_id),
                    airline_name=carrier_name,
                    flight_no=f"{carrier_info.get('iata', carrier_id)}{seg.get('marketingFlightNumber', '')}",
                    origin=origin_place.get("iata", req.origin),
                    destination=dest_place.get("iata", req.destination),
                    departure=_parse_dt(seg.get("departureDateTime") or seg.get("departure")),
                    arrival=_parse_dt(seg.get("arrivalDateTime") or seg.get("arrival")),
                ))

            if not flight_segments:
                continue

            total_dur = (out_leg.get("durationInMinutes") or 0) * 60
            stopovers = out_leg.get("stopCount", max(0, len(flight_segments) - 1))
            outbound = FlightRoute(
                segments=flight_segments,
                total_duration_seconds=total_dur,
                stopovers=stopovers,
            )

            # Build inbound (if round-trip)
            inbound = None
            if len(leg_ids) > 1:
                ret_leg = legs_map.get(leg_ids[1], {})
                ret_seg_ids = ret_leg.get("segmentIds") or []
                ret_segments: list[FlightSegment] = []
                for sid in ret_seg_ids:
                    seg = segments_map.get(sid, {})
                    cid = str(seg.get("marketingCarrierId", ""))
                    ci = carriers_map.get(cid, {})
                    oid = str(seg.get("originPlaceId", ""))
                    did = str(seg.get("destinationPlaceId", ""))
                    ret_segments.append(FlightSegment(
                        airline=ci.get("iata", cid),
                        airline_name=ci.get("name", cid),
                        flight_no=f"{ci.get('iata', cid)}{seg.get('marketingFlightNumber', '')}",
                        origin=places_map.get(oid, {}).get("iata", req.destination),
                        destination=places_map.get(did, {}).get("iata", req.origin),
                        departure=_parse_dt(seg.get("departureDateTime") or seg.get("departure")),
                        arrival=_parse_dt(seg.get("arrivalDateTime") or seg.get("arrival")),
                    ))
                if ret_segments:
                    inbound = FlightRoute(
                        segments=ret_segments,
                        total_duration_seconds=(ret_leg.get("durationInMinutes") or 0) * 60,
                        stopovers=ret_leg.get("stopCount", max(0, len(ret_segments) - 1)),
                    )

            all_airlines = list(dict.fromkeys(
                s.airline for s in flight_segments if s.airline
            ))
            h = hashlib.md5(
                f"ss_{itin_id}_{best_price}".encode()
            ).hexdigest()[:10]

            offers.append(FlightOffer(
                id=f"ss_{h}",
                price=best_price,
                currency=target_cur,
                price_formatted=f"{target_cur} {best_price:.2f}",
                outbound=outbound,
                inbound=inbound,
                airlines=all_airlines,
                owner_airline=all_airlines[0] if all_airlines else "",
                source="skyscanner_meta",
                source_tier="free",
                is_locked=False,
                booking_url=f"https://www.skyscanner.net/transport/flights/{req.origin.lower()}/{req.destination.lower()}/",
            ))
        except Exception as e:
            logger.warning("SKYSCANNER: parse itinerary failed: %s", e)

    return offers
