"""
Trip.com / Ctrip connector — Playwright browser + FlightMiddleSearch API interception.

Trip.com is the world's largest OTA by transaction volume.
The international search page at www.trip.com fires FlightMiddleSearch API calls
progressively, each returning a journey (flight) with multiple fare policies.

Strategy:
1.  Launch Playwright browser (headless=new for anti-bot).
2.  Navigate to www.trip.com flight results URL.
3.  Intercept FlightMiddleSearch JSON responses (progressive loading).
4.  Parse journeyList + policyList → FlightOffer.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from datetime import datetime, date as date_type
from typing import Any, Optional

from ..models.flights import (
    FlightOffer,
    FlightRoute,
    FlightSearchRequest,
    FlightSearchResponse,
    FlightSegment,
)
from .browser import auto_block_if_proxied, block_heavy_resources, get_proxy

logger = logging.getLogger(__name__)

# City name slugs for Trip.com URL format
_CITY_SLUGS: dict[str, str] = {
    "LON": "london", "BCN": "barcelona", "PAR": "paris", "ROM": "rome",
    "MIL": "milan", "BER": "berlin", "AMS": "amsterdam", "MAD": "madrid",
    "LIS": "lisbon", "NYC": "new-york", "LAX": "los-angeles", "SFO": "san-francisco",
    "CHI": "chicago", "MIA": "miami", "BKK": "bangkok", "SIN": "singapore",
    "TYO": "tokyo", "SEL": "seoul", "HKG": "hong-kong", "SYD": "sydney",
    "DXB": "dubai", "IST": "istanbul", "DEL": "delhi", "BOM": "mumbai",
    "SHA": "shanghai", "PEK": "beijing", "KUL": "kuala-lumpur", "JKT": "jakarta",
    "TPE": "taipei", "MNL": "manila", "ATH": "athens", "VIE": "vienna",
    "PRG": "prague", "WAW": "warsaw", "BUD": "budapest", "CPH": "copenhagen",
    "OSL": "oslo", "STO": "stockholm", "HEL": "helsinki", "DUB": "dublin",
    "EDI": "edinburgh", "ZRH": "zurich", "GVA": "geneva", "BRU": "brussels",
}


def _city_slug(iata: str) -> str:
    """Get URL-safe city slug from IATA code."""
    return _CITY_SLUGS.get(iata.upper(), iata.lower())


def _parse_dt(s: Any) -> datetime:
    if not s:
        return datetime(2000, 1, 1)
    s = str(s)
    try:
        return datetime.fromisoformat(s.replace(" ", "T"))
    except (ValueError, AttributeError):
        return datetime(2000, 1, 1)


class TripcomConnectorClient:
    """Trip.com / Ctrip — Playwright + batchSearch API interception."""

    def __init__(self, timeout: float = 55.0):
        self.timeout = timeout

    async def close(self):
        pass

    async def search_flights(
        self, req: FlightSearchRequest
    ) -> FlightSearchResponse:
        t0 = time.monotonic()

        for attempt in range(2):
            try:
                offers = await self._do_search(req)
                if offers is not None:
                    offers.sort(
                        key=lambda o: o.price if o.price > 0 else float("inf")
                    )
                    elapsed = time.monotonic() - t0
                    logger.info(
                        "TRIPCOM %s→%s: %d offers in %.1fs",
                        req.origin, req.destination, len(offers), elapsed,
                    )
                    h = hashlib.md5(
                        f"tripcom{req.origin}{req.destination}{req.date_from}".encode()
                    ).hexdigest()[:12]
                    return FlightSearchResponse(
                        search_id=f"fs_tc_{h}",
                        origin=req.origin,
                        destination=req.destination,
                        currency=req.currency,
                        offers=offers,
                        total_results=len(offers),
                    )
            except Exception as e:
                logger.warning("TRIPCOM attempt %d failed: %s", attempt, e)

        return self._empty(req)

    async def _do_search(
        self, req: FlightSearchRequest
    ) -> list[FlightOffer] | None:
        from playwright.async_api import async_playwright

        # Collect FlightMiddleSearch responses (progressive loading — one flight per response)
        search_responses: list[dict] = []

        async def on_response(response):
            url = response.url
            if "FlightMiddleSearch" not in url:
                return
            try:
                if response.status == 200:
                    body = await response.text()
                    if len(body) > 5000:
                        data = json.loads(body)
                        if data.get("journeyList"):
                            search_responses.append(data)
            except Exception:
                pass

        pw = await async_playwright().start()
        try:
            proxy = get_proxy("TRIPCOM_PROXY")
            launch_kw: dict = {
                "headless": False,
                "args": [
                    "--headless=new",
                    "--window-size=1366,768",
                    "--disable-blink-features=AutomationControlled",
                ],
            }
            if proxy:
                launch_kw["proxy"] = proxy
            browser = await pw.chromium.launch(**launch_kw)
            ctx = await browser.new_context(
                viewport={"width": 1366, "height": 768},
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/131.0.0.0 Safari/537.36"
                ),
            )
            page = await ctx.new_page()
            await auto_block_if_proxied(page)
            if proxy:
                await block_heavy_resources(page)
            page.on("response", on_response)

            dep_date = req.date_from.isoformat()
            origin_slug = _city_slug(req.origin)
            dest_slug = _city_slug(req.destination)

            # trip.com URL format: /flights/{origin}-to-{dest}/tickets-{orig}-{dest}
            url = (
                f"https://www.trip.com/flights/"
                f"{origin_slug}-to-{dest_slug}/"
                f"tickets-{req.origin.lower()}-{req.destination.lower()}"
                f"?dcity={req.origin.lower()}&acity={req.destination.lower()}"
                f"&depdate={dep_date}"
                f"&cabin=y_s&adult={req.adults or 1}&child=0&infant=0"
            )
            if req.return_from:
                url += f"&rdate={req.return_from.isoformat()}"

            try:
                resp = await page.goto(url, wait_until="domcontentloaded", timeout=30000)
                if resp and resp.status >= 400:
                    logger.warning("TRIPCOM: trip.com returned HTTP %d", resp.status)
            except Exception as e:
                logger.warning("TRIPCOM: goto failed: %s", e)
                raise

            # Wait for FlightMiddleSearch responses (progressive — they arrive over ~15-25s)
            for _ in range(12):
                if page.is_closed():
                    logger.warning("TRIPCOM: page closed during wait")
                    break
                await asyncio.sleep(3)
                # After we've gotten some responses, give a bit more time for stragglers
                if len(search_responses) >= 3:
                    await asyncio.sleep(6)
                    break

            if not page.is_closed():
                await page.close()
            await ctx.close()
            await browser.close()
        except Exception as e:
            logger.error("TRIPCOM browser error: %s", e)
            return None
        finally:
            try:
                await pw.stop()
            except Exception:
                pass

        if not search_responses:
            logger.warning("TRIPCOM: no FlightMiddleSearch responses captured")
            return None

        logger.info("TRIPCOM: captured %d FlightMiddleSearch responses", len(search_responses))
        return _parse_trip_responses(search_responses, req)

    def _empty(self, req: FlightSearchRequest) -> FlightSearchResponse:
        return FlightSearchResponse(
            search_id="",
            origin=req.origin,
            destination=req.destination,
            currency=req.currency,
            offers=[],
            total_results=0,
        )


def _parse_trip_responses(
    responses: list[dict], req: FlightSearchRequest
) -> list[FlightOffer]:
    """Parse Trip.com FlightMiddleSearch responses into FlightOffer list.

    Each response contains one journeyList (single flight/itinerary) with
    multiple policyList entries (fare classes). We take the cheapest policy
    per journey.
    """
    target_cur = req.currency or "EUR"
    offers: list[FlightOffer] = []
    seen_flights: set[str] = set()  # Dedupe by flight key

    for resp in responses:
        try:
            journeys = resp.get("journeyList") or []
            policies = resp.get("policyList") or []
            if not journeys or not policies:
                continue

            # Find cheapest policy
            cheapest_policy = None
            cheapest_price = float("inf")
            for pol in policies:
                price_info = pol.get("price") or {}
                total = float(price_info.get("totalPrice", 0))
                if 0 < total < cheapest_price:
                    cheapest_price = total
                    cheapest_policy = pol

            if not cheapest_policy or cheapest_price <= 0:
                continue

            # Build flight segments from journey's transportList
            flight_segments: list[FlightSegment] = []
            journey = journeys[0]
            transports = journey.get("transportList") or []
            total_duration = journey.get("duration", 0) * 60  # min → sec

            flight_key_parts = []
            for tpt in transports:
                fl = tpt.get("flight") or {}
                dp = tpt.get("departPoint") or {}
                ap = tpt.get("arrivePoint") or {}
                di = tpt.get("dateInfo") or {}
                ci = tpt.get("craftInfo") or {}

                airline_info = fl.get("airlineInfo") or {}
                airline_code = airline_info.get("code", "")
                airline_name = airline_info.get("name", "")
                flight_no = fl.get("flightNo", "")

                dep_airport = (dp.get("airPort") or {}).get("airportCode", "")
                arr_airport = (ap.get("airPort") or {}).get("airportCode", "")
                dep_dt = di.get("departDate", "")
                arr_dt = di.get("arriveDate", "")

                flight_key_parts.append(f"{flight_no}-{dep_dt}")

                flight_segments.append(FlightSegment(
                    airline=airline_code,
                    airline_name=airline_name,
                    flight_no=flight_no,
                    origin=dep_airport or req.origin,
                    destination=arr_airport or req.destination,
                    departure=_parse_dt(dep_dt),
                    arrival=_parse_dt(arr_dt),
                ))

            if not flight_segments:
                continue

            flight_key = "|".join(flight_key_parts)
            if flight_key in seen_flights:
                continue
            seen_flights.add(flight_key)

            stopovers = len(transports) - 1 if len(transports) > 1 else 0
            outbound = FlightRoute(
                segments=flight_segments,
                total_duration_seconds=total_duration,
                stopovers=stopovers,
            )

            # Note: Trip.com prices are already in user's local currency
            # based on geo-IP (not CNY for international users)
            price = cheapest_price

            all_airlines = list(dict.fromkeys(
                s.airline for s in flight_segments if s.airline
            ))
            owner = flight_segments[0].airline if flight_segments else ""

            h = hashlib.md5(flight_key.encode()).hexdigest()[:10]

            offers.append(FlightOffer(
                id=f"tc_{h}",
                price=price,
                currency=target_cur,
                price_formatted=f"{target_cur} {price:.2f}",
                outbound=outbound,
                inbound=None,  # TODO: handle round-trip
                airlines=all_airlines,
                owner_airline=owner,
                source="tripcom_ota",
                source_tier="free",
                is_locked=False,
                booking_url=(
                    f"https://www.trip.com/flights/"
                    f"{_city_slug(req.origin)}-to-{_city_slug(req.destination)}/"
                    f"tickets-{req.origin.lower()}-{req.destination.lower()}"
                ),
            ))
        except Exception as e:
            logger.warning("TRIPCOM: parse response failed: %s", e)

    return offers
