"""
Air Europa (UX) — per-search browser connector — form fill + API intercept.

Strategy (rewritten Mar 2026 — per-search browser model):
1. Each search launches a fresh Playwright browser (bundled Chromium, headed mode).
2. Navigate to aireuropa.com → establish session → navigate to booking URL.
3. Intercept Amadeus DES air-bounds API response.
4. If API not captured, fall back to DOM scraping on results page.
5. Close browser + cleanup temp directory.

Per-search browser model: no shared state, Cloud Run compatible,
bypasses Imperva via real browser with stealth patches.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import shutil
import sys
import tempfile
import time
from datetime import datetime, date, timedelta
from typing import Optional

from ..models.flights import (
    FlightOffer,
    FlightRoute,
    FlightSearchRequest,
    FlightSearchResponse,
    FlightSegment,
)
from .browser import (
    inject_stealth_js,
    get_default_proxy,
    proxy_is_configured,
    acquire_browser_slot,
    release_browser_slot,
    block_all_heavy_resources,
)
from .airline_routes import get_city_airports

logger = logging.getLogger(__name__)

async def _dismiss_overlays(page) -> None:
    """Remove CDK overlay backdrop (NOT container), dismiss language dialog, accept cookies."""
    try:
        # 1. Remove CDK overlay backdrop — blocks clicks but autocomplete lives in the container
        await page.evaluate("""() => {
            document.querySelectorAll('.cdk-overlay-backdrop').forEach(el => el.remove());
        }""")
        await asyncio.sleep(0.5)

        # 2. Dismiss language selector dialog ("Apply" button in overlay container)
        await page.evaluate("""() => {
            document.querySelectorAll('.cdk-overlay-container button').forEach(b => {
                const t = (b.textContent || '').trim().toLowerCase();
                if (t.includes('apply') || t.includes('confirm')) b.click();
            });
        }""")
        await asyncio.sleep(1.0)

        # 3. Accept cookies
        await page.evaluate("""() => {
            const accept = document.querySelector('#onetrust-accept-btn-handler');
            if (accept && accept.offsetHeight > 0) { accept.click(); return; }
            document.querySelectorAll('button').forEach(b => {
                const t = (b.textContent || '').trim().toLowerCase();
                if ((t.includes('accept all') || t === 'accept') && b.offsetHeight > 0) b.click();
            });
        }""")
        await asyncio.sleep(1.0)
        await page.evaluate("""() => {
            document.querySelectorAll('#onetrust-consent-sdk, .onetrust-pc-dark-filter').forEach(el => el.remove());
        }""")

        # 4. Remove any new backdrops that appeared
        await page.evaluate("""() => {
            document.querySelectorAll('.cdk-overlay-backdrop').forEach(el => el.remove());
        }""")
    except Exception:
        pass


class AirEuropaConnectorClient:
    """Air Europa (UX) per-search browser connector."""

    IATA = "UX"
    AIRLINE_NAME = "Air Europa"
    SOURCE = "aireuropa_direct"
    HOMEPAGE = "https://www.aireuropa.com/en/flights"
    DEFAULT_CURRENCY = "EUR"

    def __init__(self, timeout: float = 55.0):
        self.timeout = timeout

    async def close(self):
        pass

    async def search_flights(self, req: FlightSearchRequest) -> FlightSearchResponse:
        t0 = time.monotonic()
        temp_dir = None
        pw_instance = None
        browser = None
        context = None

        # City code expansion (LON → LHR, BCN stays BCN)
        origins = get_city_airports(req.origin)
        destinations = get_city_airports(req.destination)
        api_origin = origins[0] if origins else req.origin
        api_dest = destinations[0] if destinations else req.destination

        try:
            await acquire_browser_slot()

            temp_dir = tempfile.mkdtemp(prefix="aireuropa_")
            logger.debug("AirEuropa: using temp dir %s", temp_dir)

            from playwright.async_api import async_playwright
            pw_instance = await async_playwright().start()

            args = [
                "--disable-blink-features=AutomationControlled",
                "--no-first-run",
            ]
            if sys.platform.startswith("linux"):
                args.extend(["--no-sandbox", "--disable-dev-shm-usage"])

            browser = await pw_instance.chromium.launch(
                headless=False,
                args=args,
            )
            ctx_kwargs: dict = {
                "viewport": {"width": 1400, "height": 900},
                "locale": "en-GB",
                "timezone_id": "Europe/London",
            }
            proxy = get_default_proxy()
            if proxy:
                ctx_kwargs["proxy"] = proxy

            context = await browser.new_context(**ctx_kwargs)

            page = await context.new_page()
            await inject_stealth_js(page)
            await block_all_heavy_resources(page)

            search_data: dict = {}
            api_event = asyncio.Event()

            async def _on_response(response):
                nonlocal search_data
                url = response.url.lower()
                if response.status not in (200, 201):
                    if response.status in (403, 429) and any(k in url for k in ("air-bounds", "availability", "flight", "search", "offer")):
                        logger.warning("AirEuropa: blocked %d on %s", response.status, url[:120])
                    return
                try:
                    # Capture Amadeus DES flight API responses (api-des.aireuropa.com)
                    is_flight_api = any(k in url for k in (
                        "air-bounds", "air-shopping", "availability",
                        "/offers", "flight-search", "low-fare",
                        "air-calendars",
                    ))
                    # Exclude known non-flight API paths
                    is_excluded = any(k in url for k in (
                        "channel-cms", "masterdata", "config", "tracking",
                        "analytics", "tag-manager", "i18n", "assets",
                        "login", "session", "payment",
                    ))
                    if not is_flight_api or is_excluded:
                        return
                    ct = response.headers.get("content-type", "")
                    if "json" not in ct:
                        return
                    body = await response.text()
                    if len(body) < 200:
                        return
                    data = json.loads(body)
                    if isinstance(data, dict):
                        keys = list(data.keys())[:8]
                        logger.info("AirEuropa: API response keys=%s from %s (%dB)", keys, url[:100], len(body))
                        # Primary: Amadeus DES format with data.airBoundGroups
                        inner = data.get("data", {})
                        if isinstance(inner, dict) and ("airBoundGroups" in inner or "airBounds" in inner):
                            search_data.update(data)
                            api_event.set()
                            logger.info("AirEuropa: captured air-bounds API (%d keys, %dB)", len(data), len(body))
                        # Alternate: direct flight results with flight-specific keys
                        elif any(k in data for k in ("flights", "offers", "itineraries", "airBounds", "airBoundGroups")):
                            search_data.update(data)
                            api_event.set()
                            logger.info("AirEuropa: captured alternate flight API (%d keys)", len(data))
                except Exception:
                    pass

            page.on("response", _on_response)

            logger.info("AirEuropa: loading search for %s→%s", req.origin, req.destination)

            # Form fill approach: homepage → fill form → submit → capture API
            # (direct URL to digital.aireuropa.com blocked by Imperva)
            await page.goto(self.HOMEPAGE, wait_until="domcontentloaded", timeout=25000)
            await asyncio.sleep(4.0)
            await _dismiss_overlays(page)

            # Fill origin
            ok = await self._fill_airport(page, "input#departure", api_origin)
            if not ok:
                return self._empty(req)
            await asyncio.sleep(0.5)
            await page.evaluate("() => document.querySelectorAll('.cdk-overlay-backdrop').forEach(el => el.remove())")

            # Fill destination
            ok = await self._fill_airport(page, "input#arrival", api_dest)
            if not ok:
                return self._empty(req)
            await asyncio.sleep(0.5)
            await page.evaluate("() => document.querySelectorAll('.cdk-overlay-backdrop').forEach(el => el.remove())")

            # Fill departure date
            ok = await self._fill_date(page, "input#mat-input-1", req.date_from)
            if not ok:
                return self._empty(req)
            await asyncio.sleep(0.5)

            # Fill return date (site defaults to roundtrip; use dep+7 to satisfy validation)
            try:
                dt = req.date_from if isinstance(req.date_from, (datetime, date)) else datetime.strptime(str(req.date_from), "%Y-%m-%d")
                ret_date = dt + timedelta(days=7)
            except Exception:
                ret_date = date.today() + timedelta(days=14)
            ok = await self._fill_date(page, "input#mat-input-2", ret_date)
            if not ok:
                logger.warning("AirEuropa: return date fill failed, continuing anyway")
            await asyncio.sleep(0.5)

            await page.evaluate("() => document.querySelectorAll('.cdk-overlay-backdrop').forEach(el => el.remove())")

            # Click Search button (text="Search", class has ae-btn-block)
            await page.evaluate("""() => {
                const btns = document.querySelectorAll('button');
                for (const b of btns) {
                    const t = (b.textContent || '').trim();
                    const cls = (b.getAttribute('class') || '');
                    if (t === 'Search' && cls.includes('ae-btn-block') && b.offsetHeight > 0) {
                        b.click(); return;
                    }
                }
            }""")
            logger.info("AirEuropa: search clicked, waiting for navigation...")

            # Wait for redirect to digital.aireuropa.com and API response
            try:
                await page.wait_for_url("**/digital*", timeout=20000)
                logger.info("AirEuropa: redirected to %s", page.url[:120])
            except Exception:
                logger.info("AirEuropa: no redirect, current URL: %s", page.url[:120])
            await asyncio.sleep(5.0)

            remaining = max(self.timeout - (time.monotonic() - t0), 15)
            deadline = time.monotonic() + remaining
            while time.monotonic() < deadline:
                if api_event.is_set():
                    break
                url = page.url
                if any(k in url.lower() for k in ["result", "booking", "digital.aireuropa", "availability", "select"]):
                    await asyncio.sleep(6.0)
                    break
                await asyncio.sleep(1.0)

            if not api_event.is_set():
                try:
                    await asyncio.wait_for(api_event.wait(), timeout=8.0)
                except asyncio.TimeoutError:
                    pass

            offers = []
            if search_data:
                offers = self._parse_api_response(search_data, req)
            if not offers:
                offers = await self._scrape_dom(page, req)

            offers.sort(key=lambda o: o.price)
            elapsed = time.monotonic() - t0
            logger.info("AirEuropa %s→%s: %d offers in %.1fs", req.origin, req.destination, len(offers), elapsed)

            search_hash = hashlib.md5(
                f"aireuropa{req.origin}{req.destination}{req.date_from}".encode()
            ).hexdigest()[:12]
            currency = offers[0].currency if offers else self.DEFAULT_CURRENCY
            return FlightSearchResponse(
                search_id=f"fs_{search_hash}", origin=req.origin, destination=req.destination,
                currency=currency, offers=offers, total_results=len(offers),
            )
        except Exception as e:
            logger.error("AirEuropa error: %s", e)
            return self._empty(req)
        finally:
            if context:
                try:
                    await context.close()
                except Exception:
                    pass
            if browser:
                try:
                    await browser.close()
                except Exception:
                    pass
            if pw_instance:
                try:
                    await pw_instance.stop()
                except Exception:
                    pass
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                except Exception:
                    pass
            release_browser_slot()

    async def _fill_airport(self, page, selector: str, iata: str) -> bool:
        """Fill an airport autocomplete field. Uses force=True to bypass overlays."""
        try:
            field = page.locator(selector).first
            await field.click(force=True, timeout=5000)
            await asyncio.sleep(0.3)
            await field.fill("")
            await asyncio.sleep(0.2)

            # Type the IATA code for autocomplete matching
            await field.type(iata, delay=100)
            await asyncio.sleep(3.0)

            # Click matching autocomplete option in CDK overlay
            selected = await page.evaluate("""(iata) => {
                const opts = document.querySelectorAll('mat-option, [role="option"]');
                for (const o of opts) {
                    if (o.offsetHeight > 0 && o.textContent.includes(iata)) {
                        o.click(); return true;
                    }
                }
                // Fallback: click first visible option
                for (const o of opts) {
                    if (o.offsetHeight > 0) { o.click(); return true; }
                }
                return false;
            }""", iata)
            if not selected:
                # Keyboard fallback
                await page.keyboard.press("ArrowDown")
                await asyncio.sleep(0.3)
                await page.keyboard.press("Enter")

            await asyncio.sleep(0.5)
            val = await page.evaluate(f"() => document.querySelector('{selector}')?.value || ''")
            logger.info("AirEuropa: %s → %s (value=%s)", selector, iata, val[:30])
            return bool(val)
        except Exception as e:
            logger.warning("AirEuropa: airport fill error for %s: %s", iata, e)
            return False

    async def _fill_date(self, page, selector: str, target_date) -> bool:
        """Fill a date via the calendar picker. Date input is readonly — must use calendar UI."""
        try:
            dt = target_date if isinstance(target_date, (datetime, date)) else datetime.strptime(str(target_date), "%Y-%m-%d")
        except (ValueError, TypeError):
            return False
        target_day = str(dt.day)
        target_month = dt.strftime("%B").lower()  # e.g. "june"
        target_year = str(dt.year)
        try:
            # Click date input to open calendar (readonly, so must use force=True)
            date_field = page.locator(selector).first
            await date_field.click(force=True, timeout=5000)
            await asyncio.sleep(1.5)

            # Navigate calendar forward until target month is visible
            for _ in range(15):
                found = await page.evaluate("""(args) => {
                    const [targetMonth, targetYear] = args;
                    const months = document.querySelectorAll('.month');
                    for (const m of months) {
                        const text = m.textContent.toLowerCase();
                        if (text.includes(targetMonth) && text.includes(targetYear) && m.offsetHeight > 0) {
                            return true;
                        }
                    }
                    return false;
                }""", [target_month, target_year])
                if found:
                    break
                # Click "Next month" button (aria-label based, proven to work)
                await page.evaluate("""() => {
                    const btns = document.querySelectorAll('button');
                    for (const b of btns) {
                        const label = (b.getAttribute('aria-label') || '').toLowerCase();
                        if (label.includes('next month') && b.offsetHeight > 0) {
                            b.click(); return;
                        }
                    }
                }""")
                await asyncio.sleep(0.5)

            # Click the target day WITHIN the correct month section (scoped)
            clicked = await page.evaluate("""(args) => {
                const [targetMonth, targetYear, day] = args;
                const months = document.querySelectorAll('.month');
                for (const m of months) {
                    const text = m.textContent.toLowerCase();
                    if (text.includes(targetMonth) && text.includes(targetYear) && m.offsetHeight > 0) {
                        // Walk up to find container holding day cells
                        let container = m.parentElement;
                        for (let i = 0; i < 5; i++) {
                            const cells = container.querySelectorAll('.day-content');
                            if (cells.length > 0) {
                                for (const c of cells) {
                                    if ((c.textContent || '').trim() === day && c.offsetHeight > 0) {
                                        c.click();
                                        return true;
                                    }
                                }
                                break;
                            }
                            container = container.parentElement;
                            if (!container) break;
                        }
                    }
                }
                return false;
            }""", [target_month, target_year, target_day])
            if clicked:
                logger.info("AirEuropa: date selected %s via %s", dt.strftime("%Y-%m-%d"), selector)
            else:
                logger.warning("AirEuropa: could not click day %s in %s %s", target_day, target_month, target_year)
            await asyncio.sleep(0.8)
            return clicked
        except Exception as e:
            logger.warning("AirEuropa: date error: %s", e)
            return False

    def _parse_api_response(self, data: dict, req: FlightSearchRequest) -> list[FlightOffer]:
        """Parse Amadeus DES air-bounds format."""
        offers = []
        air_data = data.get("data", {})
        if isinstance(air_data, dict):
            groups = air_data.get("airBoundGroups", [])
        else:
            groups = []
        dicts = data.get("dictionaries", {})
        flight_dict = dicts.get("flight", {}) if isinstance(dicts, dict) else {}

        for group in (groups if isinstance(groups, list) else []):
            bound_details = group.get("boundDetails", {})
            seg_refs = bound_details.get("segments", [])
            duration_secs = bound_details.get("duration", 0)

            # Build segments from dictionaries
            segments = []
            for seg_ref in seg_refs:
                fid = seg_ref.get("flightId", "") if isinstance(seg_ref, dict) else str(seg_ref)
                seg_data = flight_dict.get(fid, {})
                dep_info = seg_data.get("departure", {})
                arr_info = seg_data.get("arrival", {})
                airline_code = seg_data.get("marketingAirlineCode") or self.IATA
                flight_num = seg_data.get("marketingFlightNumber", "")
                flight_no = f"{airline_code}{flight_num}" if flight_num else airline_code

                dep_dt = self._parse_dt(dep_info.get("dateTime", ""), req.date_from)
                arr_dt = self._parse_dt(arr_info.get("dateTime", ""), req.date_from)

                segments.append(FlightSegment(
                    airline=airline_code[:2],
                    airline_name=self.AIRLINE_NAME if airline_code == self.IATA else airline_code,
                    flight_no=flight_no,
                    origin=dep_info.get("locationCode", req.origin),
                    destination=arr_info.get("locationCode", req.destination),
                    departure=dep_dt, arrival=arr_dt, cabin_class="economy",
                ))

            if not segments:
                continue

            route = FlightRoute(segments=segments, total_duration_seconds=duration_secs,
                                stopovers=max(0, len(segments) - 1))

            # Each airBound is a fare option for this flight group
            for ab in group.get("airBounds", []):
                prices_block = ab.get("prices", {})
                total_prices = prices_block.get("totalPrices", [{}])
                tp = total_prices[0] if total_prices else {}
                # Prices are in cents
                total_cents = tp.get("total", 0)
                currency = tp.get("currencyCode", self.DEFAULT_CURRENCY)
                price = total_cents / 100.0
                if price <= 0:
                    continue

                fare_family = ab.get("fareFamilyCode", "")
                offer_id = hashlib.md5(
                    f"{self.IATA.lower()}_{req.origin}_{req.destination}_{req.date_from}_{price}_{fare_family}_{segments[0].flight_no}".encode()
                ).hexdigest()[:12]

                offers.append(FlightOffer(
                    id=f"{self.IATA.lower()}_{offer_id}", price=round(price, 2), currency=currency,
                    price_formatted=f"{currency} {price:,.2f}", outbound=route, inbound=None,
                    airlines=list({s.airline for s in segments}), owner_airline=self.IATA,
                    booking_url=self._booking_url(req), is_locked=False,
                    source=self.SOURCE, source_tier="free",
                ))
        return offers

    def _extract_currency(self, d: dict) -> str:
        for key in ("currency", "currencyCode"):
            val = d.get(key)
            if isinstance(val, str) and len(val) == 3:
                return val.upper()
        if isinstance(d.get("price"), dict):
            return d["price"].get("currency", self.DEFAULT_CURRENCY)
        return self.DEFAULT_CURRENCY

    @staticmethod
    def _parse_dt(s, fallback_date) -> datetime:
        if not s:
            try:
                dt = fallback_date if isinstance(fallback_date, (datetime, date)) else datetime.strptime(str(fallback_date), "%Y-%m-%d")
                return datetime(dt.year, dt.month, dt.day) if isinstance(dt, date) and not isinstance(dt, datetime) else dt
            except Exception:
                return datetime.now()
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
            try:
                return datetime.strptime(s[:19], fmt)
            except (ValueError, TypeError):
                continue
        m = re.search(r"(\d{1,2}):(\d{2})", str(s))
        if m:
            try:
                dt = fallback_date if isinstance(fallback_date, (datetime, date)) else datetime.strptime(str(fallback_date), "%Y-%m-%d")
                d = dt if isinstance(dt, date) and not isinstance(dt, datetime) else dt.date() if isinstance(dt, datetime) else dt
                return datetime(d.year, d.month, d.day, int(m.group(1)), int(m.group(2)))
            except Exception:
                pass
        return datetime.now()

    async def _scrape_dom(self, page, req: FlightSearchRequest) -> list[FlightOffer]:
        await asyncio.sleep(3)
        flights = await page.evaluate(r"""(params) => {
            const [origin, destination] = params;
            const results = [];
            const cards = document.querySelectorAll(
                '[class*="flight-card"], [class*="flight-row"], [class*="itinerary"], ' +
                '[class*="result-card"], [class*="bound"], [class*="flight-item"], ' +
                '[class*="flightInfo"], [class*="flight_item"]'
            );
            for (const card of cards) {
                const text = card.innerText || '';
                if (text.length < 20) continue;
                const times = text.match(/\b(\d{1,2}:\d{2})\b/g) || [];
                if (times.length < 2) continue;
                const priceMatch = text.match(/(EUR|USD|GBP|€|\$|£)\s*[\d,]+\.?\d*/i) ||
                                   text.match(/[\d,]+\.?\d*\s*(EUR|USD|GBP|€|\$|£)/i);
                if (!priceMatch) continue;
                // Handle European price format: "496,62" or "1.496,62"
                let priceStr = priceMatch[0].replace(/[^0-9.,]/g, '');
                // If comma is present and followed by 1-2 digits at end → European decimal
                if (/,\d{1,2}$/.test(priceStr)) {
                    priceStr = priceStr.replace(/\./g, '').replace(',', '.');
                } else {
                    priceStr = priceStr.replace(/,/g, '');
                }
                const price = parseFloat(priceStr);
                if (!price || price <= 0) continue;
                let currency = 'EUR';
                if (/USD|\$/.test(priceMatch[0])) currency = 'USD';
                else if (/GBP|£/.test(priceMatch[0])) currency = 'GBP';
                const fnMatch = text.match(/\b(UX\s*\d{2,4})\b/i);
                results.push({
                    depTime: times[0], arrTime: times[1], price, currency,
                    flightNo: fnMatch ? fnMatch[1].replace(/\s/g, '') : 'UX',
                });
            }
            return results;
        }""", [req.origin, req.destination])

        offers = []
        for f in (flights or []):
            offer = self._build_dom_offer(f, req)
            if offer:
                offers.append(offer)
        return offers

    def _build_dom_offer(self, f: dict, req: FlightSearchRequest) -> Optional[FlightOffer]:
        price = f.get("price", 0)
        if price <= 0:
            return None
        try:
            dt = req.date_from if isinstance(req.date_from, (datetime, date)) else datetime.strptime(str(req.date_from), "%Y-%m-%d")
            dep_date = dt.date() if isinstance(dt, datetime) else dt if isinstance(dt, date) else date.today()
        except (ValueError, TypeError):
            dep_date = date.today()

        dep_time = f.get("depTime", "00:00")
        arr_time = f.get("arrTime", "00:00")
        try:
            h, m = dep_time.split(":")
            dep_dt = datetime(dep_date.year, dep_date.month, dep_date.day, int(h), int(m))
        except (ValueError, IndexError):
            dep_dt = datetime(dep_date.year, dep_date.month, dep_date.day)
        try:
            h, m = arr_time.split(":")
            arr_dt = datetime(dep_date.year, dep_date.month, dep_date.day, int(h), int(m))
            if arr_dt <= dep_dt:
                arr_dt += timedelta(days=1)
        except (ValueError, IndexError):
            arr_dt = dep_dt

        flight_no = f.get("flightNo", self.IATA)
        currency = f.get("currency", self.DEFAULT_CURRENCY)
        offer_id = hashlib.md5(f"{self.IATA.lower()}_{req.origin}_{req.destination}_{dep_date}_{flight_no}_{price}".encode()).hexdigest()[:12]

        segment = FlightSegment(
            airline=self.IATA, airline_name=self.AIRLINE_NAME, flight_no=flight_no,
            origin=req.origin, destination=req.destination, departure=dep_dt, arrival=arr_dt, cabin_class="economy",
        )
        route = FlightRoute(segments=[segment], total_duration_seconds=0, stopovers=0)
        return FlightOffer(
            id=f"{self.IATA.lower()}_{offer_id}", price=round(price, 2), currency=currency,
            price_formatted=f"{currency} {price:,.0f}", outbound=route, inbound=None,
            airlines=[self.AIRLINE_NAME], owner_airline=self.IATA,
            booking_url=self._booking_url(req), is_locked=False, source=self.SOURCE, source_tier="free",
        )

    def _booking_url(self, req: FlightSearchRequest) -> str:
        try:
            date_str = req.date_from.strftime("%Y-%m-%d") if hasattr(req.date_from, "strftime") else str(req.date_from)
        except Exception:
            date_str = ""
        return f"https://www.aireuropa.com/en/flights?from={req.origin}&to={req.destination}&date={date_str}"

    def _empty(self, req: FlightSearchRequest) -> FlightSearchResponse:
        search_hash = hashlib.md5(f"aireuropa{req.origin}{req.destination}{req.date_from}".encode()).hexdigest()[:12]
        return FlightSearchResponse(
            search_id=f"fs_{search_hash}", origin=req.origin, destination=req.destination,
            currency=self.DEFAULT_CURRENCY, offers=[], total_results=0,
        )
