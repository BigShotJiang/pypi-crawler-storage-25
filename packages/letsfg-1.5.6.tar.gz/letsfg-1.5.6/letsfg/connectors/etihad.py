"""
Etihad (EY) per-search browser connector — form-fill + DOM scraping.

Strategy (rewritten Mar 2026 — per-search browser model):
1. Each search launches a fresh Playwright browser (bundled Chromium, headed mode).
2. Navigate to etihad.com → dismiss cookie banner → remove navbar overlay.
3. Fill flight search form: one-way, origin, destination, date via Mobiscroll calendar.
4. Click search → wait for navigation to digital.etihad.com upsell page.
5. Scrape rendered DOM for flight cards (flight number, times, prices, duration, stops).
6. Close browser + cleanup temp directory.

Direct API calls are blocked by Akamai; form-fill lets the React app make
authenticated requests with valid WAF tokens.

Per-search browser model: no shared state, Cloud Run compatible.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import re
import shutil
import sys
import tempfile
import time
from datetime import datetime
from typing import Optional

from ..models.flights import (
    FlightOffer,
    FlightRoute,
    FlightSearchRequest,
    FlightSearchResponse,
    FlightSegment,
)
from .browser import (
    auto_block_if_proxied,
    inject_stealth_js,
    get_default_proxy,
    proxy_is_configured,
    acquire_browser_slot,
    release_browser_slot,
)

logger = logging.getLogger(__name__)

_BLOCKED_TYPES = frozenset(["image", "media", "font", "websocket", "manifest"])


async def _block_handler(route):
    if route.request.resource_type in _BLOCKED_TYPES:
        await route.abort()
    else:
        await route.continue_()


async def _dismiss_overlays(page) -> None:
    """Remove OneTrust cookie banner and any blocking overlays."""
    for selector in [
        "#onetrust-accept-btn-handler",
        "button#accept-recommended-btn-handler",
    ]:
        try:
            btn = page.locator(selector)
            if await btn.count() > 0 and await btn.first.is_visible(timeout=1500):
                await btn.first.click(timeout=3000)
                await asyncio.sleep(0.5)
                return
        except Exception:
            continue
    try:
        await page.evaluate("""() => {
            document.querySelectorAll(
                '#onetrust-consent-sdk, .onetrust-pc-dark-filter, #onetrust-banner-sdk'
            ).forEach(el => el.remove());
        }""")
    except Exception:
        pass


async def _remove_blocking_overlays(page) -> None:
    """Disable pointer-events on navbar/header so calendar clicks work."""
    await page.evaluate("""() => {
        const navbar = document.getElementById('navbar');
        if (navbar) {
            navbar.style.pointerEvents = 'none';
            navbar.style.position = 'relative';
            navbar.style.zIndex = '0';
        }
        document.querySelectorAll('header, .ey-header, .menu-item, nav').forEach(el => {
            el.style.pointerEvents = 'none';
            el.style.position = 'relative';
            el.style.zIndex = '0';
        });
    }""")


class EtihadConnectorClient:
    """Etihad per-search browser connector — form fill + DOM scraping."""

    def __init__(self, timeout: float = 60.0):
        self.timeout = timeout

    async def close(self):
        pass

    async def search_flights(self, req: FlightSearchRequest) -> FlightSearchResponse:
        t0 = time.monotonic()
        temp_dir = None
        pw_instance = None
        browser = None
        context = None

        try:
            await acquire_browser_slot()

            temp_dir = tempfile.mkdtemp(prefix="etihad_")

            from playwright.async_api import async_playwright
            pw_instance = await async_playwright().start()

            args = [
                "--disable-blink-features=AutomationControlled",
                "--no-first-run",
            ]
            if sys.platform.startswith("linux"):
                args.extend(["--no-sandbox", "--disable-dev-shm-usage"])

            browser = await pw_instance.chromium.launch(
                headless=False,
                args=args,
            )

            ctx_kwargs = {
                "viewport": {"width": 1400, "height": 900},
                "locale": "en-GB",
                "timezone_id": "Europe/London",
            }
            proxy = get_default_proxy()
            if proxy:
                ctx_kwargs["proxy"] = proxy

            context = await browser.new_context(**ctx_kwargs)
            page = await context.new_page()
            await inject_stealth_js(page)
            await page.route("**/*", _block_handler)

            from .airline_routes import get_city_airports
            origins = get_city_airports(req.origin)
            destinations = get_city_airports(req.destination)
            api_origin = origins[0] if origins else req.origin
            api_dest = destinations[0] if destinations else req.destination

            dep = datetime.strptime(str(req.date_from)[:10], "%Y-%m-%d")
            dep_str = dep.strftime("%Y-%m-%d")

            # ── Step 1: Load homepage ──
            logger.info("Etihad: loading homepage for %s→%s on %s", api_origin, api_dest, dep_str)
            await page.goto(
                "https://www.etihad.com/en/",
                wait_until="domcontentloaded",
                timeout=45000,
            )
            await asyncio.sleep(5)
            await _dismiss_overlays(page)
            await asyncio.sleep(0.5)
            await _remove_blocking_overlays(page)

            # ── Step 2: Select One-way ──
            try:
                await page.locator("li").filter(has_text="One-way").first.click(timeout=5000)
            except Exception:
                logger.debug("Etihad: one-way click failed, continuing")
            await asyncio.sleep(0.5)

            # ── Step 3: Fill origin ──
            await self._fill_typeahead(page, "#fsporigin", self._city_name(api_origin))
            await asyncio.sleep(1)

            # ── Step 4: Fill destination ──
            await self._fill_typeahead(page, "#fspdestination", self._city_name(api_dest))
            await asyncio.sleep(1)

            # ── Step 5: Select date in Mobiscroll calendar ──
            await self._select_date(page, dep)

            # ── Step 6: Click Search and wait for navigation ──
            logger.info("Etihad: clicking Search Flights")
            try:
                await page.locator("button.ey-button--large").first.click(timeout=5000)
            except Exception:
                await page.evaluate("() => document.querySelector('button.ey-button--large')?.click()")

            try:
                await page.wait_for_url("**/digital.etihad.com/**", timeout=30000)
                logger.info("Etihad: navigated to %s", page.url[:100])
            except Exception:
                logger.warning("Etihad: no navigation to digital.etihad.com, URL: %s", page.url[:80])
                return self._empty(req)

            # ── Step 7: Wait for upsell page to render ──
            await asyncio.sleep(15)

            # ── Step 8: Scrape flight data from DOM ──
            offers = await self._scrape_upsell_page(page, req, api_origin, api_dest, dep)
            offers.sort(key=lambda o: o.price)

            elapsed = time.monotonic() - t0
            logger.info(
                "Etihad %s→%s returned %d offers in %.1fs",
                req.origin, req.destination, len(offers), elapsed,
            )

            search_hash = hashlib.md5(
                f"etihad{req.origin}{req.destination}{req.date_from}".encode()
            ).hexdigest()[:12]

            currency = offers[0].currency if offers else (req.currency or "AED")

            return FlightSearchResponse(
                search_id=f"fs_{search_hash}",
                origin=req.origin,
                destination=req.destination,
                currency=currency,
                offers=offers,
                total_results=len(offers),
            )

        except Exception as e:
            logger.error("Etihad error: %s", e)
            return self._empty(req)
        finally:
            if context:
                try:
                    await context.close()
                except Exception:
                    pass
            if browser:
                try:
                    await browser.close()
                except Exception:
                    pass
            if pw_instance:
                try:
                    await pw_instance.stop()
                except Exception:
                    pass
            if temp_dir and os.path.exists(temp_dir):
                try:
                    shutil.rmtree(temp_dir, ignore_errors=True)
                except Exception:
                    pass
            release_browser_slot()

    # ------------------------------------------------------------------
    # Form fill helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _city_name(iata: str) -> str:
        """Map common IATA codes to city names for typeahead input."""
        names = {
            "AUH": "Abu Dhabi", "DXB": "Dubai", "DOH": "Doha",
            "RUH": "Riyadh", "JED": "Jeddah", "BAH": "Bahrain",
            "KWI": "Kuwait", "MCT": "Muscat", "AMM": "Amman",
            "CAI": "Cairo", "CMB": "Colombo", "BOM": "Mumbai",
            "DEL": "Delhi", "HYD": "Hyderabad", "BLR": "Bangalore",
            "MAA": "Chennai", "CCU": "Kolkata", "DAC": "Dhaka",
            "KTM": "Kathmandu", "MLE": "Male", "BKK": "Bangkok",
            "SIN": "Singapore", "KUL": "Kuala Lumpur", "CGK": "Jakarta",
            "MNL": "Manila", "ICN": "Seoul", "NRT": "Tokyo",
            "PEK": "Beijing", "PVG": "Shanghai", "HKG": "Hong Kong",
            "SYD": "Sydney", "MEL": "Melbourne", "BNE": "Brisbane",
            "LHR": "London", "CDG": "Paris", "FRA": "Frankfurt",
            "MUC": "Munich", "ZRH": "Zurich", "AMS": "Amsterdam",
            "FCO": "Rome", "MXP": "Milan", "MAD": "Madrid",
            "BCN": "Barcelona", "ATH": "Athens", "IST": "Istanbul",
            "MAN": "Manchester", "DUB": "Dublin", "BRU": "Brussels",
            "CPH": "Copenhagen", "ARN": "Stockholm", "OSL": "Oslo",
            "HEL": "Helsinki", "WAW": "Warsaw", "PRG": "Prague",
            "VIE": "Vienna", "BUD": "Budapest", "GVA": "Geneva",
            "DUS": "Dusseldorf", "TXL": "Berlin",
            "JFK": "New York", "LAX": "Los Angeles", "ORD": "Chicago",
            "IAD": "Washington", "YYZ": "Toronto", "YUL": "Montreal",
            "GRU": "Sao Paulo", "EZE": "Buenos Aires",
            "JNB": "Johannesburg", "NBO": "Nairobi", "LOS": "Lagos",
            "ADD": "Addis Ababa", "CAS": "Casablanca", "TUN": "Tunis",
        }
        return names.get(iata, iata)

    @staticmethod
    async def _fill_typeahead(page, selector: str, text: str) -> None:
        """Fill a React Bootstrap Typeahead input and pick the first suggestion."""
        inp = page.locator(selector).first
        try:
            await inp.wait_for(state="visible", timeout=10000)
        except Exception:
            logger.debug("Etihad: %s not visible, scrolling", selector)
            await page.evaluate("window.scrollBy(0, 300)")
            await asyncio.sleep(1)
            await inp.wait_for(state="visible", timeout=5000)
        await inp.click()
        await asyncio.sleep(0.5)
        await inp.fill("")
        await inp.type(text, delay=80)
        await asyncio.sleep(2)
        try:
            await page.locator('[role="option"]').first.click(timeout=5000)
        except Exception:
            logger.debug("Etihad: no autocomplete option for '%s'", text)
        await asyncio.sleep(2)

    @staticmethod
    async def _select_date(page, dep: datetime) -> None:
        """Open the Mobiscroll calendar, navigate to target month, click target day."""
        target_month_abbrev = dep.strftime("%b")  # "Jun"
        target_year = str(dep.year)  # "2026"
        target_day = str(dep.day)  # "15"

        # Open calendar
        for sel in ['text="Travelling when?"', '.ey-fsp__when', 'text="Add dates"']:
            try:
                loc = page.locator(sel).first
                if await loc.is_visible(timeout=2000):
                    await loc.click(timeout=3000)
                    break
            except Exception:
                continue
        await asyncio.sleep(2)

        # Navigate to target month
        for _ in range(18):
            data = await page.evaluate("""() => {
                const m = document.querySelectorAll('.mbsc-calendar-month');
                const y = document.querySelectorAll('.mbsc-calendar-year');
                return {
                    months: Array.from(m).map(h => h.textContent.trim()),
                    years: Array.from(y).map(h => h.textContent.trim()),
                };
            }""")
            months = data.get("months", [])
            years = data.get("years", [])
            found = any(
                target_month_abbrev in m and target_year in y
                for m, y in zip(months, years)
            )
            if found:
                break
            try:
                await page.locator('.mbsc-calendar-button-next').first.click(timeout=2000)
            except Exception:
                break
            await asyncio.sleep(0.5)

        # Click target day in the correct month slide
        await page.evaluate("""(args) => {
            const [targetDay] = args;
            const activeTables = document.querySelectorAll('.mbsc-calendar-table-active');
            const table = activeTables[activeTables.length - 1];
            if (!table) return;
            const slide = table.closest('.mbsc-calendar-slide') || table.parentElement;
            const cells = slide.querySelectorAll(
                '.mbsc-calendar-cell.mbsc-calendar-day:not(.mbsc-calendar-day-outer):not(.mbsc-disabled)'
            );
            for (const cell of cells) {
                if (cell.textContent.trim() === String(targetDay)) {
                    const inner = cell.querySelector('.mbsc-calendar-cell-inner') || cell;
                    inner.dispatchEvent(new PointerEvent('pointerdown', {bubbles: true}));
                    inner.dispatchEvent(new PointerEvent('pointerup', {bubbles: true}));
                    inner.dispatchEvent(new MouseEvent('click', {bubbles: true}));
                    inner.click();
                    break;
                }
            }
        }""", [target_day])
        await asyncio.sleep(2)

    # ------------------------------------------------------------------
    # DOM scraping
    # ------------------------------------------------------------------

    async def _scrape_upsell_page(
        self, page, req: FlightSearchRequest,
        origin: str, destination: str, dep: datetime,
    ) -> list[FlightOffer]:
        """Extract flight offers from the digital.etihad.com upsell page."""
        cards = await page.evaluate("""() => {
            const cards = document.querySelectorAll('.bound-element');
            return Array.from(cards).map(c => c.textContent.trim()).filter(t => t.length > 10);
        }""")

        if not cards:
            logger.warning("Etihad: no .bound-element cards found on upsell page")
            return []

        offers: list[FlightOffer] = []
        for card_text in cards:
            offer = self._parse_card_text(card_text, req, origin, destination, dep)
            if offer:
                offers.append(offer)
        return offers

    def _parse_card_text(
        self, text: str, req: FlightSearchRequest,
        origin: str, destination: str, dep: datetime,
    ) -> Optional[FlightOffer]:
        """Parse a single flight card text like:
        'Departure02:20AUHNon-stop 7h 40m ArrivalLHR07:00 Details EY 61 FromAED2,375View...'
        """
        # Departure time + origin IATA
        dep_m = re.search(r'Departure(\d{2}:\d{2})([A-Z]{3})', text)
        if not dep_m:
            return None
        dep_time = dep_m.group(1)
        dep_iata = dep_m.group(2)

        # Stops + duration
        stop_m = re.search(r'(Non-stop|(\d+)\s+stops?)\s+(\d+)h\s+(\d+)m', text)
        stopovers = 0
        duration_seconds = 0
        if stop_m:
            if stop_m.group(2):
                stopovers = int(stop_m.group(2))
            duration_seconds = int(stop_m.group(3)) * 3600 + int(stop_m.group(4)) * 60

        # Arrival IATA + time
        arr_m = re.search(r'Arrival([A-Z]{3})(\d{2}:\d{2})', text)
        arr_iata = arr_m.group(1) if arr_m else destination
        arr_time = arr_m.group(2) if arr_m else ""

        # Flight number(s) — "EY 61" or "EY 77 EY 2598"
        flight_m = re.search(r'Details\s+(EY[\s\xa0]*\d+)', text)
        flight_no = ""
        if flight_m:
            raw = flight_m.group(1).strip()
            flight_no = re.sub(r'[\s\xa0]+', '', raw)  # "EY61"

        # First price (economy) — "FromAED2,375View" or "FromAED10,815View"
        price_m = re.search(r'From(AED|USD|EUR|GBP)([\d,]+(?:\.\d+)?)', text)
        if not price_m:
            return None
        currency = price_m.group(1)
        try:
            price = float(price_m.group(2).replace(",", ""))
        except ValueError:
            return None

        if price <= 0 or not flight_no:
            return None

        return self._build_offer_from_scrape(
            req, origin, destination, dep, dep_time, arr_time,
            dep_iata, arr_iata, flight_no, price, currency,
            duration_seconds, stopovers,
        )

    def _build_offer_from_scrape(
        self,
        req: FlightSearchRequest,
        origin: str, destination: str,
        dep_date: datetime,
        dep_time: str, arr_time: str,
        dep_iata: str, arr_iata: str,
        flight_no: str,
        price: float, currency: str,
        duration_seconds: int,
        stopovers: int,
    ) -> Optional[FlightOffer]:
        """Build a FlightOffer from scraped page data."""
        offer_id = hashlib.md5(
            f"ey_{flight_no}_{dep_date.strftime('%Y%m%d')}_{price}".encode()
        ).hexdigest()[:12]

        try:
            dep_h, dep_m = map(int, dep_time.split(":"))
            dep_dt = dep_date.replace(hour=dep_h, minute=dep_m, second=0, microsecond=0)
        except Exception:
            dep_dt = dep_date

        try:
            arr_h, arr_m = map(int, arr_time.split(":"))
            arr_dt = dep_date.replace(hour=arr_h, minute=arr_m, second=0, microsecond=0)
            # If arrival is before departure, it's next day
            if arr_dt < dep_dt:
                from datetime import timedelta
                arr_dt += timedelta(days=1)
        except Exception:
            arr_dt = dep_dt

        segment = FlightSegment(
            airline="EY",
            airline_name="Etihad Airways",
            flight_no=flight_no,
            origin=dep_iata or origin,
            destination=arr_iata or destination,
            departure=dep_dt,
            arrival=arr_dt,
            duration_seconds=duration_seconds,
            cabin_class="economy",
        )

        route = FlightRoute(
            segments=[segment],
            total_duration_seconds=duration_seconds,
            stopovers=stopovers,
        )

        return FlightOffer(
            id=f"ey_{offer_id}",
            price=price,
            currency=currency,
            price_formatted=f"{price:,.0f} {currency}",
            outbound=route,
            inbound=None,
            airlines=["Etihad Airways"],
            owner_airline="EY",
            booking_url=self._booking_url(req),
            is_locked=False,
            source="etihad_direct",
            source_tier="free",
        )

    @staticmethod
    def _booking_url(req: FlightSearchRequest) -> str:
        """Build Etihad booking deep-link."""
        try:
            dt = req.date_from if hasattr(req.date_from, 'strftime') else datetime.strptime(str(req.date_from), "%Y-%m-%d")
            date_str = dt.strftime("%d-%m-%Y")
        except (ValueError, TypeError):
            date_str = ""
        adults = req.adults or 1
        children = req.children or 0
        infants = req.infants or 0
        return (
            f"https://www.etihad.com/en/book/flights"
            f"?from={req.origin}&to={req.destination}"
            f"&departdate={date_str}"
            f"&adult={adults}&child={children}&infant={infants}"
            f"&class=Economy&trip=oneway"
        )

    def _empty(self, req: FlightSearchRequest) -> FlightSearchResponse:
        search_hash = hashlib.md5(
            f"etihad{req.origin}{req.destination}{req.date_from}".encode()
        ).hexdigest()[:12]
        return FlightSearchResponse(
            search_id=f"fs_{search_hash}",
            origin=req.origin,
            destination=req.destination,
            currency=req.currency,
            offers=[],
            total_results=0,
        )
