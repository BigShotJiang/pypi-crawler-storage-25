"""
Despegar connector — Latin America's largest OTA.

Despegar (NASDAQ: DESP) covers all Latin American airlines + international.
Often has OTA-exclusive fares for LATAM, GOL, Azul, Avianca, Copa, JetSmart, etc.
Also operates as Decolar (Brazil), BestDay (Mexico).

Strategy (CDP Chrome + deep-link + API interception):
  Despegar's React SPA requires session cookies, CSRF tokens, and tracking
  headers that cannot be obtained with direct httpx calls.
  Instead: deep-link to the search results page and intercept the JSON API
  responses that the SPA fires internally.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import subprocess
import time
from datetime import datetime
from typing import Any, Optional

from ..models.flights import (
    FlightOffer,
    FlightRoute,
    FlightSearchRequest,
    FlightSearchResponse,
    FlightSegment,
)
from .browser import find_chrome, stealth_popen_kwargs, _launched_procs, proxy_chrome_args, auto_block_if_proxied

logger = logging.getLogger(__name__)

_BASE = "https://www.despegar.com"
_CDP_PORT = 9492
_USER_DATA_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), ".despegar_chrome_data"
)

_pw_instance = None
_browser = None
_chrome_proc = None
_browser_lock: Optional[asyncio.Lock] = None
_context = None


def _get_lock() -> asyncio.Lock:
    global _browser_lock
    if _browser_lock is None:
        _browser_lock = asyncio.Lock()
    return _browser_lock


def _parse_dt(s: Any) -> datetime:
    if not s:
        return datetime(2000, 1, 1)
    s = str(s)
    try:
        clean = s.replace("Z", "+00:00").split("+")[0] if "T" in s else s
        clean = clean.split(".")[0] if "." in clean else clean
        return datetime.fromisoformat(clean)
    except (ValueError, AttributeError):
        return datetime(2000, 1, 1)


async def _get_context():
    global _context
    browser = await _get_browser()
    if _context:
        try:
            if _context.pages:
                return _context
        except Exception:
            pass
    contexts = browser.contexts
    if contexts:
        _context = contexts[0]
    else:
        _context = await browser.new_context(viewport={"width": 1366, "height": 768})
    return _context


async def _get_browser():
    global _pw_instance, _browser, _chrome_proc
    lock = _get_lock()
    async with lock:
        if _browser:
            try:
                if _browser.is_connected():
                    return _browser
            except Exception:
                pass

        from playwright.async_api import async_playwright

        pw = None
        try:
            pw = await async_playwright().start()
            _browser = await pw.chromium.connect_over_cdp(f"http://127.0.0.1:{_CDP_PORT}")
            _pw_instance = pw
            return _browser
        except Exception:
            if pw:
                try:
                    await pw.stop()
                except Exception:
                    pass

        chrome = find_chrome()
        os.makedirs(_USER_DATA_DIR, exist_ok=True)
        args = [
            chrome,
            f"--remote-debugging-port={_CDP_PORT}",
            f"--user-data-dir={_USER_DATA_DIR}",
            "--no-first-run",
            *proxy_chrome_args(),
            "--no-default-browser-check",
            "--disable-blink-features=AutomationControlled",
            "--disable-http2",
            "--window-position=-2400,-2400",
            "--window-size=1366,768",
            "about:blank",
        ]
        _chrome_proc = subprocess.Popen(args, **stealth_popen_kwargs())
        _launched_procs.append(_chrome_proc)
        await asyncio.sleep(2.0)

        pw = await async_playwright().start()
        _pw_instance = pw
        _browser = await pw.chromium.connect_over_cdp(f"http://127.0.0.1:{_CDP_PORT}")
        logger.info("Despegar: Chrome launched on CDP port %d (pid %d)", _CDP_PORT, _chrome_proc.pid)
        return _browser


class DespegarConnectorClient:
    """Despegar — Latin America's largest OTA, CDP Chrome + deep-link."""

    def __init__(self, timeout: float = 55.0):
        self.timeout = timeout

    async def close(self):
        pass

    async def search_flights(self, req: FlightSearchRequest) -> FlightSearchResponse:
        t0 = time.monotonic()
        date_str = req.date_from.strftime("%Y-%m-%d")
        adults = req.adults or 1

        context = await _get_context()
        page = await context.new_page()
        await auto_block_if_proxied(page)

        captured: list[dict] = []

        async def _on_response(response):
            url = response.url.lower()
            if response.status != 200:
                return
            # Despegar internal BFF uses various search/cluster/itinerary endpoints
            if any(kw in url for kw in ("busquedas", "cluster", "itinerar", "search", "flights")):
                ct = response.headers.get("content-type", "")
                if "json" in ct:
                    try:
                        data = await response.json()
                        if isinstance(data, dict) and len(str(data)) > 200:
                            captured.append(data)
                            logger.debug("Despegar: captured API response from %s (%d bytes)", response.url[:120], len(str(data)))
                    except Exception:
                        pass

        page.on("response", _on_response)

        try:
            # Deep-link: Despegar uses path-encoded search URLs
            # Format: /shop/flights/results/oneway/ORIGIN/DESTINATION/DATE/ADULTS/CHILDREN/INFANTS
            deep_url = (
                f"{_BASE}/shop/flights/results/oneway/"
                f"{req.origin}/{req.destination}/{date_str}/{adults}/0/0"
            )

            logger.info("Despegar: navigating to %s→%s on %s", req.origin, req.destination, date_str)
            await page.goto(deep_url, wait_until="domcontentloaded", timeout=int(self.timeout * 1000))
            await asyncio.sleep(4.0)

            # Dismiss cookies
            for label in ["Aceptar", "Accept", "Entendido", "OK", "Acepto"]:
                try:
                    btn = page.get_by_role("button", name=label)
                    if await btn.count() > 0:
                        await btn.first.click(timeout=2000)
                        await asyncio.sleep(0.5)
                        break
                except Exception:
                    continue

            # Log diagnostics
            try:
                diag = await page.evaluate("() => ({url: location.href, title: document.title, text: document.body?.innerText?.substring(0,200)||''})")
                logger.info("Despegar page state: url=%s title=%s", diag.get('url','?'), diag.get('title','?'))
            except Exception:
                pass

            # Polling loop: wait for API responses
            remaining = max(self.timeout - (time.monotonic() - t0), 15)
            deadline = time.monotonic() + remaining
            offers: list[FlightOffer] = []

            while time.monotonic() < deadline and not offers:
                # Parse all captured responses (largest first — main payload is biggest)
                for data in sorted(captured, key=lambda d: len(str(d)), reverse=True):
                    offers = self._parse(data, req, date_str)
                    if offers:
                        break

                if not offers:
                    # Try __NEXT_DATA__ / window globals
                    try:
                        raw = await page.evaluate("""() => {
                            if (window.__NEXT_DATA__) return JSON.stringify(window.__NEXT_DATA__);
                            if (window.__INITIAL_STATE__) return JSON.stringify(window.__INITIAL_STATE__);
                            return null;
                        }""")
                        if raw:
                            jd = json.loads(raw)
                            props = jd.get("props", {}).get("pageProps", jd) if isinstance(jd, dict) and "props" in jd else jd
                            if isinstance(props, dict):
                                offers = self._parse(props, req, date_str)
                    except Exception:
                        pass

                if not offers:
                    # Check for "no results" / blocked page
                    try:
                        text = await page.evaluate("() => document.body?.innerText?.substring(0, 400) || ''")
                        if any(kw in text.lower() for kw in ("no encontramos", "sin resultados", "no results", "no flights")):
                            logger.info("Despegar: no results text detected")
                            break
                        if any(kw in text.lower() for kw in ("blocked", "access denied", "captcha")):
                            logger.warning("Despegar: blocked / captcha detected")
                            break
                    except Exception:
                        pass
                    await asyncio.sleep(1.5)

            offers.sort(key=lambda o: o.price)
            elapsed = time.monotonic() - t0
            logger.info("Despegar %s→%s: %d offers in %.1fs (CDP Chrome)", req.origin, req.destination, len(offers), elapsed)

            sh = hashlib.md5(f"despegar{req.origin}{req.destination}{date_str}".encode()).hexdigest()[:12]
            return FlightSearchResponse(
                search_id=f"fs_{sh}", origin=req.origin, destination=req.destination,
                currency=offers[0].currency if offers else "USD",
                offers=offers, total_results=len(offers),
            )
        except Exception as e:
            logger.error("Despegar CDP error: %s", e)
            return self._empty(req)
        finally:
            try:
                await page.close()
            except Exception:
                pass

    def _parse(self, data: dict, req: FlightSearchRequest, target_date: str) -> list[FlightOffer]:
        offers: list[FlightOffer] = []

        # Despegar nests results under various keys depending on endpoint version
        results = (
            data.get("flights") or data.get("items") or data.get("clusters")
            or data.get("itineraries") or data.get("results")
            or (data.get("data", {}).get("items") if isinstance(data.get("data"), dict) else None)
            or (data.get("data", {}).get("flights") if isinstance(data.get("data"), dict) else None)
            or []
        )
        if isinstance(results, dict):
            results = results.get("items") or results.get("list") or list(results.values())

        for flight in (results if isinstance(results, list) else [])[:40]:
            try:
                price_obj = flight.get("priceDetail") or flight.get("price") or flight
                price = (
                    price_obj.get("totalPrice") or price_obj.get("total")
                    or price_obj.get("price") or price_obj.get("amount") or 0
                )
                currency = price_obj.get("currency") or flight.get("currency") or "USD"
                if float(price) <= 0:
                    continue

                segments_data = flight.get("segments") or flight.get("legs") or flight.get("routes") or [flight]
                seg_info = segments_data[0] if segments_data else flight
                airline_name = (
                    seg_info.get("airline") or seg_info.get("carrierName")
                    or seg_info.get("marketingCarrier", {}).get("name", "")
                    or seg_info.get("operatingCarrier", {}).get("name", "Unknown")
                )
                airline_code = (
                    seg_info.get("airlineCode") or seg_info.get("carrierCode")
                    or seg_info.get("marketingCarrier", {}).get("code", "")
                )
                flight_no = seg_info.get("flightNumber") or seg_info.get("number") or airline_code or ""

                dep_str = seg_info.get("departure") or seg_info.get("departureTime") or seg_info.get("departureDateTime") or ""
                arr_str = seg_info.get("arrival") or seg_info.get("arrivalTime") or seg_info.get("arrivalDateTime") or ""
                dep_dt = _parse_dt(dep_str) if dep_str else datetime.combine(req.date_from, datetime.min.time().replace(hour=8))
                arr_dt = _parse_dt(arr_str) if arr_str else dep_dt

                duration = flight.get("duration") or flight.get("durationMinutes") or seg_info.get("duration") or 0
                duration_secs = int(duration) * 60 if duration else 0
                stops = flight.get("stops") or flight.get("stopovers") or max(0, len(segments_data) - 1)

                # Build segments from individual leg data
                segments: list[FlightSegment] = []
                for si, sd in enumerate(segments_data if isinstance(segments_data, list) else [seg_info]):
                    s_airline = sd.get("airline") or sd.get("carrierName") or sd.get("marketingCarrier", {}).get("name", airline_name)
                    s_fno = sd.get("flightNumber") or sd.get("number") or flight_no
                    s_origin = sd.get("origin") or sd.get("departureAirport") or sd.get("departure", {}).get("code", req.origin) if isinstance(sd.get("departure"), dict) else req.origin
                    s_dest = sd.get("destination") or sd.get("arrivalAirport") or sd.get("arrival", {}).get("code", req.destination) if isinstance(sd.get("arrival"), dict) else req.destination
                    s_dep = _parse_dt(sd.get("departureTime") or sd.get("departureDateTime") or sd.get("departure") if isinstance(sd.get("departure"), str) else "")
                    s_arr = _parse_dt(sd.get("arrivalTime") or sd.get("arrivalDateTime") or sd.get("arrival") if isinstance(sd.get("arrival"), str) else "")
                    s_dur = sd.get("duration") or sd.get("durationMinutes") or 0

                    segments.append(FlightSegment(
                        airline=s_airline or airline_name, flight_no=str(s_fno),
                        origin=s_origin if isinstance(s_origin, str) else req.origin,
                        destination=s_dest if isinstance(s_dest, str) else req.destination,
                        departure=s_dep if s_dep.year > 2001 else dep_dt,
                        arrival=s_arr if s_arr.year > 2001 else arr_dt,
                        duration_seconds=int(s_dur) * 60 if s_dur else duration_secs,
                    ))

                if not segments:
                    continue

                total_dur = duration_secs or sum(s.duration_seconds for s in segments)
                route = FlightRoute(segments=segments, total_duration_seconds=total_dur, stopovers=int(stops))
                oid = hashlib.md5(f"desp_{req.origin}{req.destination}{target_date}{price}{flight_no}".encode()).hexdigest()[:12]
                offers.append(FlightOffer(
                    id=f"desp_{oid}", price=round(float(price), 2), currency=currency,
                    price_formatted=f"{float(price):.2f} {currency}",
                    outbound=route, inbound=None,
                    airlines=list({s.airline for s in segments if s.airline}),
                    owner_airline=airline_code or (segments[0].airline if segments else "Despegar"),
                    booking_url=f"{_BASE}/shop/flights/results/oneway/{req.origin}/{req.destination}/{target_date}/{req.adults or 1}/0/0",
                    is_locked=False, source="despegar_ota", source_tier="free",
                ))
            except Exception as e:
                logger.debug("Despegar parse error: %s", e)

        return offers

    def _empty(self, req: FlightSearchRequest) -> FlightSearchResponse:
        h = hashlib.md5(f"despegar{req.origin}{req.destination}{req.date_from}".encode()).hexdigest()[:12]
        return FlightSearchResponse(
            search_id=f"fs_{h}", origin=req.origin, destination=req.destination,
            currency="USD", offers=[], total_results=0,
        )
