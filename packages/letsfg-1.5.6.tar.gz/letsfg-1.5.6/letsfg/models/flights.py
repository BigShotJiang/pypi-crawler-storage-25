"""Flight search request/response models — multi-provider."""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator


# ── Request ──────────────────────────────────────────────────────────────────

class FlightSearchRequest(BaseModel):
    """Parameters for a flight search — FREE for agents."""

    origin: str = Field(
        ...,
        description="IATA code of departure airport/city (e.g. 'PRG', 'LON')",
        min_length=2,
        max_length=4,
    )
    destination: str = Field(
        ...,
        description="IATA code of arrival airport/city (e.g. 'BCN', 'NYC')",
        min_length=2,
        max_length=4,
    )
    date_from: date = Field(..., description="Departure date")
    date_to: Optional[date] = Field(None, description="Latest departure date")
    return_from: Optional[date] = Field(None, description="Return date (omit for one-way)")
    return_to: Optional[date] = Field(None, description="Latest return date")
    adults: int = Field(1, ge=1, le=9)
    children: int = Field(0, ge=0, le=9)
    infants: int = Field(0, ge=0, le=9)
    cabin_class: Optional[str] = Field(
        None,
        description="M (economy), W (premium economy), C (business), F (first)",
        pattern=r"^[MWCF]$",
    )
    max_stopovers: int = Field(2, ge=0, le=4, description="Max connections per direction")
    currency: str = Field("EUR", min_length=3, max_length=3)
    locale: str = Field("en", description="Language for city/airport names")
    limit: int = Field(50, ge=1, le=200, description="Max results to return")
    sort: str = Field("price", description="Sort by: price, duration, best_per_airline")

    @field_validator("origin", "destination")
    @classmethod
    def validate_iata_code(cls, v: str) -> str:
        v = v.strip().upper()
        if not re.fullmatch(r"[A-Z]{2,4}", v):
            raise ValueError(f"Invalid IATA code '{v}': must be 2-4 letters (e.g. 'LON', 'PRG')")
        return v

    @field_validator("date_from")
    @classmethod
    def validate_date_not_past(cls, v: date) -> date:
        if v < date.today():
            raise ValueError(f"date_from ({v}) cannot be in the past")
        return v


# ── Response ─────────────────────────────────────────────────────────────────

class FlightSegment(BaseModel):
    """A single flight leg (e.g., PRG→FRA)."""

    airline: str = Field(..., description="Operating carrier IATA code")
    airline_name: str = ""
    flight_no: str = ""
    origin: str = Field(..., description="Departure IATA")
    destination: str = Field(..., description="Arrival IATA")
    origin_city: str = ""
    destination_city: str = ""
    departure: datetime
    arrival: datetime
    duration_seconds: int = 0
    cabin_class: str = "economy"
    aircraft: str = ""


class FlightRoute(BaseModel):
    """One direction (outbound or return) composed of segments."""

    segments: list[FlightSegment] = []
    total_duration_seconds: int = 0
    stopovers: int = 0


class FlightOffer(BaseModel):
    """
    A single flight offer with full itinerary, pricing, and booking details.
    
    **Two-tier pricing model:**
    
    For Developers (Local/CLI):
    - `is_masked=False` (default) — full airline names, booking URLs visible
    - Completely FREE — just star our GitHub!
    
    For Hosted/API (Messenger, etc.):
    - `is_masked=True` — airlines hidden, booking_url empty
    - Unlock fee: 1% of ticket (min $1) to reveal full details
    """

    id: str = Field(..., description="Unique offer ID")
    price: float
    currency: str = "EUR"
    price_formatted: str = ""
    outbound: FlightRoute
    inbound: Optional[FlightRoute] = None
    airlines: list[str] = Field(default_factory=list, description="Airlines in itinerary")
    owner_airline: str = Field("", description="Validating carrier")
    bags_price: dict[str, Any] = Field(default_factory=dict, description="Baggage pricing")
    availability_seats: Optional[int] = None
    conditions: dict[str, str] = Field(default_factory=dict, description="Refund/change policies")
    source: str = Field("", description="Provider source tag (e.g. 'duffel', 'amadeus', 'kiwi', 'travelpayouts')")
    source_tier: str = Field(
        "paid",
        description=(
            "Data source cost tier: "
            "'free' = cached/aggregated data (Travelpayouts), "
            "'low' = affordable API (Kiwi Tequila), "
            "'paid' = GDS/NDC providers (Duffel, Amadeus), "
            "'protocol' = LCC direct via Agent Interaction Protocol (Ryanair, Wizzair)"
        ),
    )
    is_locked: bool = Field(False, description="Whether booking details require unlock")
    fetched_at: datetime = Field(default_factory=datetime.utcnow)
    booking_url: str = Field("", description="Booking URL (only available after unlock)")
    price_normalized: Optional[float] = Field(None, description="Price converted to the search currency for sorting")
    
    # ── Masking / Monetization fields ────────────────────────────────────────
    # For developers (local/CLI): is_masked=False, full results FREE
    # For hosted/API (Messenger): is_masked=True, unlock required (1% min $1)
    is_masked: bool = Field(
        False,  # Default: unmasked (developers get full results FREE)
        description="False = full details visible (default for developers). True = airlines hidden (hosted mode).",
    )
    unlock_fee: float = Field(
        0,
        description="Fee to unlock this offer. Zero for unmasked offers. 1% of price (min $1) for masked offers.",
    )
    unlock_fee_formatted: str = Field(
        "",
        description="Human-readable unlock fee (e.g., '$1.50'). Empty for unmasked offers.",
    )

    def compute_unlock_fee(self) -> "FlightOffer":
        """Compute and set the unlock fee (1% of price, min $1.00)."""
        fee = max(self.price * 0.01, 1.0)
        self.unlock_fee = round(fee, 2)
        self.unlock_fee_formatted = f"${self.unlock_fee:.2f}"
        return self

    def to_masked(self) -> "FlightOffer":
        """Return a masked copy of this offer (hides airline info)."""
        import hashlib
        import base64
        
        # Create a masked ID (hash of original to prevent guessing)
        masked_id = "msk_" + base64.urlsafe_b64encode(
            hashlib.sha256(self.id.encode()).digest()[:12]
        ).decode().rstrip("=")
        
        return FlightOffer(
            id=masked_id,
            price=self.price,
            currency=self.currency,
            price_formatted=self.price_formatted,
            outbound=self.outbound,
            inbound=self.inbound,
            airlines=["🔒 Unlock to reveal"],  # Hidden
            owner_airline="🔒",  # Hidden
            bags_price=self.bags_price,
            availability_seats=self.availability_seats,
            conditions=self.conditions,
            source="",  # Hidden
            source_tier=self.source_tier,
            is_locked=True,
            fetched_at=self.fetched_at,
            booking_url="",  # Hidden
            price_normalized=self.price_normalized,
            is_masked=True,
            unlock_fee=max(self.price * 0.01, 1.0),
            unlock_fee_formatted=f"${max(self.price * 0.01, 1.0):.2f}",
        )


class AirlineSummary(BaseModel):
    """Cheapest offer summary for one airline (masked in search results)."""
    airline_code: str = Field("🔒", description="Airline IATA code (hidden until unlock)")
    airline_name: str = Field("🔒 Unlock to reveal", description="Airline name (hidden until unlock)")
    cheapest_price: float
    currency: str = "EUR"
    offer_count: int
    cheapest_offer_id: str = ""
    sample_route: str = Field("", description="e.g. KRK→WAW→BER")
    unlock_fee: float = Field(0, description="Fee to unlock this airline's offers")
    
    def to_masked(self) -> "AirlineSummary":
        """Return a masked copy hiding airline identity."""
        import hashlib
        import base64
        masked_id = "msk_" + base64.urlsafe_b64encode(
            hashlib.sha256(self.cheapest_offer_id.encode()).digest()[:12]
        ).decode().rstrip("=") if self.cheapest_offer_id else ""
        
        return AirlineSummary(
            airline_code="🔒",
            airline_name="🔒 Unlock to reveal",
            cheapest_price=self.cheapest_price,
            currency=self.currency,
            offer_count=self.offer_count,
            cheapest_offer_id=masked_id,
            sample_route=self.sample_route,
            unlock_fee=max(self.cheapest_price * 0.01, 1.0),
        )


class FlightSearchResponse(BaseModel):
    """Full response from a flight search — always FREE."""

    search_id: str = ""
    offer_request_id: str = Field("", description="Offer request ID (for booking flow)")
    passenger_ids: list[str] = Field(
        default_factory=list,
        description="Passenger IDs from the offer request — REQUIRED for booking. "
        "Map these 1:1 to your passengers when calling POST /bookings/book.",
    )

    origin: str
    destination: str
    currency: str = "EUR"
    offers: list[FlightOffer] = []
    total_results: int = 0
    airlines_summary: list[AirlineSummary] = Field(
        default_factory=list,
        description="Cheapest offer per airline — quick overview of all options.",
    )
    search_params: dict = Field(default_factory=dict)
    source_tiers: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Breakdown of which source tiers were used in this search. "
            "Keys are tier names, values describe the data source. "
            "Example: {'paid': 'Duffel (NDC), Amadeus (GDS)', 'low': 'Kiwi Tequila', 'free': 'Travelpayouts'}"
        ),
    )
    # Pricing notes — two-tier model:
    # - Developers (local/CLI): FREE, full unmasked results
    # - Hosted/API (Messenger): Search FREE, unlock 1% min $1
    pricing_note: str = Field(
        default="Completely FREE for developers. Just star our GitHub: https://github.com/LetsFG/LetsFG",
        description="Pricing transparency for agents",
    )
    github_star_bonus: str = Field(
        default="⭐ Star for premium sources (Duffel, Amadeus)! https://github.com/LetsFG/LetsFG",
        description="Incentive to star the GitHub repo",
    )
    
    def to_masked(self) -> tuple["FlightSearchResponse", dict[str, "FlightOffer"]]:
        """
        Return a masked copy of this response + a cache mapping masked_id → original offer.
        
        Used for hosted/API mode (Messenger, etc.) where unlock is required.
        
        Returns:
            (masked_response, offer_cache) where offer_cache maps masked IDs to original offers.
        """
        offer_cache: dict[str, FlightOffer] = {}
        masked_offers: list[FlightOffer] = []
        
        for offer in self.offers:
            masked = offer.to_masked()
            offer_cache[masked.id] = offer  # Store original by masked ID
            masked_offers.append(masked)
        
        masked_summaries = [s.to_masked() for s in self.airlines_summary]
        
        # Hosted mode pricing note
        hosted_pricing_note = (
            "Search is FREE and unlimited. "
            "Unlock fee: 1% of ticket price (min $1) to reveal airline & booking link. "
            "No booking fees — you pay the exact airline price."
        )
        
        masked_response = FlightSearchResponse(
            search_id=self.search_id,
            offer_request_id=self.offer_request_id,
            passenger_ids=self.passenger_ids,
            origin=self.origin,
            destination=self.destination,
            currency=self.currency,
            offers=masked_offers,
            total_results=self.total_results,
            airlines_summary=masked_summaries,
            search_params=self.search_params,
            source_tiers={},  # Hide source tier details
            pricing_note=hosted_pricing_note,
            github_star_bonus="⭐ Star for premium sources (Duffel, Amadeus)! https://github.com/LetsFG/LetsFG",
        )
        
        return masked_response, offer_cache


# ── Global offer cache for unlock flow ───────────────────────────────────────
# Maps masked_id → original FlightOffer
# This is updated by local search and used by unlock()

_OFFER_CACHE: dict[str, FlightOffer] = {}


def cache_offers(offer_cache: dict[str, FlightOffer]) -> None:
    """Add offers to the global cache (called after masking search results)."""
    _OFFER_CACHE.update(offer_cache)


def get_cached_offer(masked_id: str) -> Optional[FlightOffer]:
    """Retrieve original offer by masked ID (for unlock flow)."""
    return _OFFER_CACHE.get(masked_id)


def clear_offer_cache() -> None:
    """Clear the offer cache (for testing)."""
    _OFFER_CACHE.clear()
