"""Declarative configuration for Soothe agents.

All public names are re-exported here so that ``from soothe.config import X``
continues to work after the module was split into a package.
"""

from soothe.config.env import (
    _ENV_VAR_RE,
    SOOTHE_HOME,
    _resolve_env,
    _resolve_provider_env,
)
from soothe.config.models import (
    AutonomousConfig,
    BrowserSubagentConfig,
    ComplexityThresholds,
    ConsoleLoggingConfig,
    DurabilityProtocolConfig,
    ExecutionConfig,
    FileLoggingConfig,
    LoggingConfig,
    MCPServerConfig,
    MemUConfig,
    ModelProviderConfig,
    ModelRouter,
    PerformanceConfig,
    PersistenceConfig,
    PlannerProtocolConfig,
    PolicyProtocolConfig,
    ProtocolsConfig,
    RecoveryConfig,
    SecurityConfig,
    SubagentConfig,
    ThreadLoggingConfig,
    ToolConfig,
    ToolsConfig,
    ToolResultCacheConfig,
    VectorStoreProviderConfig,
    VectorStoreRouter,
    WebSearchConfig,
)
from soothe.config.prompts import (
    _DEFAULT_SYSTEM_PROMPT,
    _MEDIUM_SYSTEM_PROMPT,
    _SIMPLE_SYSTEM_PROMPT,
    _TOOL_ORCHESTRATION_GUIDE,
)
from soothe.config.settings import SootheConfig
from soothe.config.templates import get_config_template_path

__all__ = [
    "SOOTHE_HOME",
    "_DEFAULT_SYSTEM_PROMPT",
    "_ENV_VAR_RE",
    "_MEDIUM_SYSTEM_PROMPT",
    "_SIMPLE_SYSTEM_PROMPT",
    "_TOOL_ORCHESTRATION_GUIDE",
    "AutonomousConfig",
    "BrowserSubagentConfig",
    "ComplexityThresholds",
    "ConsoleLoggingConfig",
    "DurabilityProtocolConfig",
    "ExecutionConfig",
    "FileLoggingConfig",
    "LoggingConfig",
    "MCPServerConfig",
    "MemUConfig",
    "ModelProviderConfig",
    "ModelRouter",
    "PerformanceConfig",
    "PersistenceConfig",
    "PlannerProtocolConfig",
    "PolicyProtocolConfig",
    "ProtocolsConfig",
    "RecoveryConfig",
    "SecurityConfig",
    "SootheConfig",
    "SubagentConfig",
    "ThreadLoggingConfig",
    "ToolConfig",
    "ToolsConfig",
    "ToolResultCacheConfig",
    "VectorStoreProviderConfig",
    "VectorStoreRouter",
    "WebSearchConfig",
    "_resolve_env",
    "_resolve_provider_env",
    "get_config_template_path",
]
