# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Chart panel — container for layers visualising a single dependent variable."""

from __future__ import annotations

from typing import Any

from vcti.deck import CompatibilityPolicy, PolicyBoundDeck

from .axis import AxisStyle
from .coordsys import CoordSysType
from .data import ArrayData, DataArray
from .layer import Layer, LayerType
from .variable import Variable


class CoordSysLayersPolicy(CompatibilityPolicy[CoordSysType, Layer]):
    """Policy enforcing layer-type compatibility with the panel coordinate system.

    Cartesian panels accept XY and BAR layers; circular panels accept
    SECTOR layers.
    """

    ALLOWED_LAYER_TYPES: dict[CoordSysType, set[LayerType]] = {
        CoordSysType.CARTESIAN: {LayerType.XY, LayerType.BAR},
        CoordSysType.CIRCULAR: {LayerType.SECTOR},
    }

    def is_compatible(self, item: Layer, deck_type: CoordSysType) -> bool:
        """Return ``True`` if *item.type* is allowed for *deck_type*."""
        return item.type in self.ALLOWED_LAYER_TYPES.get(deck_type, set())


class Panel:
    """Container for layers that visualise one dependent variable.

    A panel holds multiple :class:`Layer` objects that all share the same
    coordinate system and dependent variable.

    Args:
        coordsys: Coordinate system type.
        range_var: The dependent variable (carries metadata for axis labels).
        axis_style: Visual styling for the range (value) axis.
        index: Optional per-panel index override (usually inherited from facet).

    Examples:
        >>> panel = Panel(CoordSysType.CARTESIAN, Variable("temp"))
        >>> panel.layers.add("line", XyLayer(...))
    """

    def __init__(
        self,
        coordsys: CoordSysType,
        range_var: Variable,
        axis_style: AxisStyle | None = None,
        index: ArrayData | None = None,
    ) -> None:
        self._coordsys = coordsys
        self.range_var = range_var
        self.axis_style = axis_style or AxisStyle.create_default(
            range_var.metadata.name or range_var.id
        )
        self.index = index
        self.layers: PolicyBoundDeck[CoordSysType, Layer] = PolicyBoundDeck(
            deck_type=coordsys,
            policy=CoordSysLayersPolicy(),
        )

    @property
    def coordsys(self) -> CoordSysType:
        """Coordinate system type of this panel."""
        return self._coordsys

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable dictionary."""
        return {
            "coordsys": self._coordsys.value,
            "range_var": self.range_var.to_dict(),
            "axis_style": self.axis_style.model_dump(),
            "index": self.index.to_list() if self.index else None,
            "layers": {
                lid: layer.to_dict()
                for lid, layer in zip(self.layers.ids(), self.layers.items())
            },
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Panel:
        """Reconstruct a :class:`Panel` from a dictionary."""
        coordsys = CoordSysType(data["coordsys"])
        range_var = Variable.from_dict(data["range_var"])
        axis_style = AxisStyle(**data["axis_style"]) if data.get("axis_style") else None
        index = DataArray(data["index"]) if data.get("index") is not None else None
        panel = cls(coordsys=coordsys, range_var=range_var, axis_style=axis_style, index=index)
        for layer_id, layer_data in data.get("layers", {}).items():
            panel.layers.add(layer_id, Layer.from_dict(layer_data))
        return panel

    def __repr__(self) -> str:
        return (
            f"Panel(coordsys={self._coordsys!r}, "
            f"range_var={self.range_var.id!r}, "
            f"layers={len(self.layers)})"
        )
