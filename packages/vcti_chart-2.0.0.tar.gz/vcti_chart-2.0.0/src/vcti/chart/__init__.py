# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Chart data model with template-based HTML export.

Provides a framework-agnostic chart data model that exports to self-
contained HTML files via Jinja2 templates.  Each template targets a
specific JavaScript charting library (Plotly.js, ECharts, Chart.js,
etc.).  Adding a new JS library requires only a new template — no
Python code changes.

Python renderers (Plotly, Bokeh) are also available for interactive
exploration in Jupyter.

Architecture:
    - Scale: ScaleType (linear, logarithmic)
    - CoordSys: CoordSysType (cartesian, circular), policies
    - Data: ArrayData protocol, DataArray implementation
    - Axis: AxisType, AxesAlignment, AxisStyle, AxesLayout
    - Variable: VariableInfo metadata, Variable container
    - Layers: XyLayer, BarLayer, SectorLayer with typed configs
    - Panel: Groups layers for one dependent variable
    - Facet: Groups panels sharing one domain variable
    - Chart: Top-level container with layout and legend
    - Serialisation: ``to_dict()`` / ``from_dict()`` on all classes
    - Converters: Optional Plotly/Bokeh renderers for Jupyter
"""

from importlib.metadata import version

from .scale import ScaleType
from .coordsys import CoordSysType, MatchingCoordSysPolicy, WithCoordSys
from .data import ArrayData, DataArray
from .axis import AxisType, AxesAlignment, AxisStyle, AxesLayout
from .variable import VariableInfo, Variable
from .layout import LayoutConfig
from .legend import LegendConfig
from .layer import (
    LayerType,
    Layer,
    LayerConfig,
    LineType,
    MarkerType,
    AreaFillType,
    XyPlotConfig,
    XyLayer,
    BarEdge,
    BarPlotConfig,
    BarLayer,
    SectorPlotConfig,
    SectorLayer,
)
from .panel import CoordSysLayersPolicy, Panel
from .facet import Facet
from .chart import Chart

__version__ = version("vcti-chart")

__all__ = [
    "__version__",
    # Scale
    "ScaleType",
    # Coordinate system
    "CoordSysType",
    "MatchingCoordSysPolicy",
    "WithCoordSys",
    # Data
    "ArrayData",
    "DataArray",
    # Axis
    "AxisType",
    "AxesAlignment",
    "AxisStyle",
    "AxesLayout",
    # Variable
    "VariableInfo",
    "Variable",
    # Layout and legend
    "LayoutConfig",
    "LegendConfig",
    # Layer types and configs
    "LayerType",
    "Layer",
    "LayerConfig",
    "LineType",
    "MarkerType",
    "AreaFillType",
    "XyPlotConfig",
    "XyLayer",
    "BarEdge",
    "BarPlotConfig",
    "BarLayer",
    "SectorPlotConfig",
    "SectorLayer",
    # Panel
    "CoordSysLayersPolicy",
    "Panel",
    # Facet
    "Facet",
    # Chart
    "Chart",
]
