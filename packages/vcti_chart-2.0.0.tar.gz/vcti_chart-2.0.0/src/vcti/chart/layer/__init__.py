# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Chart layer classes and configuration."""

from .types import LayerType
from .base import Layer, LayerConfig, _LAYER_CLS_REGISTRY
from .xy import LineType, MarkerType, AreaFillType, XyPlotConfig, XyLayer
from .bar import BarEdge, BarPlotConfig, BarLayer
from .sector import SectorPlotConfig, SectorLayer

# Populate the from_dict registry after all subclasses are imported.
_LAYER_CLS_REGISTRY.update({
    "XyLayer": XyLayer,
    "BarLayer": BarLayer,
    "SectorLayer": SectorLayer,
})

__all__ = [
    "LayerType",
    "Layer",
    "LayerConfig",
    "LineType",
    "MarkerType",
    "AreaFillType",
    "XyPlotConfig",
    "XyLayer",
    "BarEdge",
    "BarPlotConfig",
    "BarLayer",
    "SectorPlotConfig",
    "SectorLayer",
]
