# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""XY (cartesian) plot layer — line, scatter, and area charts."""

from __future__ import annotations

from typing import Any

from pydantic import Field, model_validator

from vcti.enum import EnumValueLowerCase, auto_enum_value

from ..data import ArrayData, DataArray
from .base import Layer, LayerConfig
from .types import LayerType


class LineType(EnumValueLowerCase):
    """Line style enumeration.

    Examples:
        >>> LineType.SOLID.value
        'solid'
    """
    NONE = auto_enum_value()
    SOLID = auto_enum_value()
    DASHED = auto_enum_value()
    DOTTED = auto_enum_value()
    DASH_DOT = auto_enum_value()


class MarkerType(EnumValueLowerCase):
    """Marker symbol enumeration.

    Examples:
        >>> MarkerType.CIRCLE.value
        'circle'
    """
    NONE = auto_enum_value()
    CIRCLE = auto_enum_value()
    SQUARE = auto_enum_value()
    TRIANGLE = auto_enum_value()
    DIAMOND = auto_enum_value()
    CROSS = auto_enum_value()
    STAR = auto_enum_value()


class AreaFillType(EnumValueLowerCase):
    """Area fill type enumeration.

    Examples:
        >>> AreaFillType.FILLED.value
        'filled'
    """
    NONE = auto_enum_value()
    FILLED = auto_enum_value()
    HATCHED = auto_enum_value()
    GRADIENT = auto_enum_value()


class XyPlotConfig(LayerConfig):
    """Configuration for an XY plot layer.

    At least one of *line_type* or *marker_type* must be set to a
    non-``NONE`` value.  Area fill requires a visible line.

    Attributes:
        line_type: Line style.
        marker_type: Marker symbol.
        area_fill_type: Area fill mode.
        line_color: Optional line colour override.
        marker_color: Optional marker colour override.
    """
    line_type: LineType = Field(default=LineType.SOLID, description="Line style.")
    marker_type: MarkerType = Field(default=MarkerType.NONE, description="Marker symbol.")
    area_fill_type: AreaFillType = Field(default=AreaFillType.NONE, description="Area fill.")
    line_color: str | None = Field(default=None, description="Line colour.")
    marker_color: str | None = Field(default=None, description="Marker colour.")

    @model_validator(mode="after")
    def _validate_visibility(self) -> "XyPlotConfig":
        if self.line_type == LineType.NONE and self.marker_type == MarkerType.NONE:
            raise ValueError("At least one of line_type or marker_type must be non-NONE.")
        if self.area_fill_type != AreaFillType.NONE and self.line_type == LineType.NONE:
            raise ValueError("Area fill requires a visible line (line_type != NONE).")
        return self


class XyLayer(Layer):
    """XY (cartesian) plot layer for line, scatter, and area charts.

    Args:
        index: Independent-variable data (x-values).
        values: Dependent-variable data (y-values).
        config: XY-specific plot configuration.

    Examples:
        >>> layer = XyLayer(DataArray([1,2,3]), DataArray([10,20,30]))
    """

    def __init__(
        self,
        index: ArrayData | None = None,
        values: ArrayData | None = None,
        config: XyPlotConfig | None = None,
    ) -> None:
        super().__init__(LayerType.XY, index, values, config or XyPlotConfig())

    @property
    def config(self) -> XyPlotConfig:
        """Return the typed XY plot configuration."""
        assert isinstance(self._config, XyPlotConfig)
        return self._config

    @property
    def line_enabled(self) -> bool:
        """Whether the line is visible."""
        return self.config.line_type != LineType.NONE

    @property
    def marker_enabled(self) -> bool:
        """Whether markers are visible."""
        return self.config.marker_type != MarkerType.NONE

    @property
    def area_fill_enabled(self) -> bool:
        """Whether area fill is active."""
        return self.config.area_fill_type != AreaFillType.NONE

    @classmethod
    def _from_dict_impl(cls, data: dict[str, Any]) -> "XyLayer":
        index = DataArray(data["index"]) if data.get("index") is not None else None
        values = DataArray(data["values"]) if data.get("values") is not None else None
        config = XyPlotConfig(**data.get("config", {}))
        return cls(index=index, values=values, config=config)
