# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Layer type enumeration."""

from vcti.enum import EnumValueLowerCase, auto_enum_value


class LayerType(EnumValueLowerCase):
    """Enumeration for chart layer types.

    Examples:
        >>> LayerType.XY.value
        'xy'
    """
    #: XY (cartesian) plot layer for line, scatter, and area charts.
    XY = auto_enum_value()
    #: Bar chart layer.
    BAR = auto_enum_value()
    #: Sector layer for pie, donut, and radial charts.
    SECTOR = auto_enum_value()
