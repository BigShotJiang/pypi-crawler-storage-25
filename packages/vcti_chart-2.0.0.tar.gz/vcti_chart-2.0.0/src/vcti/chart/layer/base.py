# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Base layer class and configuration for chart layers."""

from __future__ import annotations

from abc import ABC
from typing import Any

from pydantic import BaseModel

from ..data import ArrayData, DataArray
from .types import LayerType


class LayerConfig(BaseModel):
    """Base configuration for all layer types.

    Subclasses add layer-specific fields (line style, bar width, etc.).
    Pydantic's ``model_dump()`` provides JSON serialisation.
    """


# Registry populated by layer/__init__.py after all subclasses are defined.
_LAYER_CLS_REGISTRY: dict[str, type[Layer]] = {}


class Layer(ABC):
    """Abstract base for a single data series in a chart panel.

    Args:
        layer_type: The type discriminator for this layer.
        index: Optional independent-variable data (overrides panel index).
        values: Dependent-variable data.
        config: Layer-specific configuration.

    Examples:
        >>> # Use concrete subclasses (XyLayer, BarLayer, SectorLayer)
    """

    def __init__(
        self,
        layer_type: LayerType,
        index: ArrayData | None = None,
        values: ArrayData | None = None,
        config: LayerConfig | None = None,
    ) -> None:
        self.type = layer_type
        self.index = index
        self.values = values
        self._config = config or LayerConfig()

    # -- serialisation --------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable dictionary."""
        return {
            "class": self.__class__.__name__,
            "type": self.type.value,
            "index": self.index.to_list() if self.index else None,
            "values": self.values.to_list() if self.values else None,
            "config": self._config.model_dump(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Layer:
        """Reconstruct a :class:`Layer` subclass from a dictionary.

        Dispatches to the correct subclass using the ``"class"`` key.
        """
        class_name = data.get("class", "Layer")
        layer_cls = _LAYER_CLS_REGISTRY.get(class_name)
        if layer_cls is None:
            raise ValueError(f"Unknown layer class: {class_name!r}")
        return layer_cls._from_dict_impl(data)

    @classmethod
    def _from_dict_impl(cls, data: dict[str, Any]) -> Layer:
        """Override in subclasses for type-specific deserialisation."""
        raise NotImplementedError

    # -- dunder ---------------------------------------------------------------

    def __repr__(self) -> str:
        n = len(self.values) if self.values else 0
        return f"{self.__class__.__name__}(type={self.type!r}, n={n})"
