# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Bar chart layer."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field

from vcti.enum import EnumValueLowerCase, auto_enum_value

from ..data import ArrayData, DataArray
from .base import Layer, LayerConfig
from .types import LayerType


class BarEdge(LayerConfig):
    """Edge (outline) styling for bar segments.

    Attributes:
        color: Edge colour.
        width: Edge width in pixels.
    """
    color: str = Field(default="black", description="Edge colour.")
    width: float = Field(default=1.0, ge=0.0, description="Edge width.")


class BarPlotConfig(LayerConfig):
    """Configuration for a bar chart layer.

    Attributes:
        mode: Bar grouping mode.
        color: Fill colour.
        width: Bar width as a fraction of available space (0–1].
        edge: Edge/outline styling.
    """
    mode: Literal["group", "stack", "overlay"] = Field(
        default="group", description="Bar grouping mode."
    )
    color: str = Field(default="#4CAF50", description="Fill colour.")
    width: float = Field(default=0.8, gt=0.0, le=1.0, description="Bar width fraction.")
    edge: BarEdge = Field(default_factory=BarEdge, description="Edge styling.")


class BarLayer(Layer):
    """Bar chart layer.

    Args:
        index: Category labels or x-positions.
        values: Bar heights.
        config: Bar-specific plot configuration.

    Examples:
        >>> layer = BarLayer(DataArray(["A","B","C"]), DataArray([10,20,30]))
    """

    def __init__(
        self,
        index: ArrayData | None = None,
        values: ArrayData | None = None,
        config: BarPlotConfig | None = None,
    ) -> None:
        super().__init__(LayerType.BAR, index, values, config or BarPlotConfig())

    @property
    def config(self) -> BarPlotConfig:
        """Return the typed bar plot configuration."""
        assert isinstance(self._config, BarPlotConfig)
        return self._config

    @classmethod
    def _from_dict_impl(cls, data: dict[str, Any]) -> "BarLayer":
        index = DataArray(data["index"]) if data.get("index") is not None else None
        values = DataArray(data["values"]) if data.get("values") is not None else None
        config = BarPlotConfig(**data.get("config", {}))
        return cls(index=index, values=values, config=config)
