# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Sector (pie / donut) chart layer."""

from __future__ import annotations

from typing import Any

from pydantic import Field, model_validator

from ..data import ArrayData, DataArray
from .base import Layer, LayerConfig
from .types import LayerType


class SectorPlotConfig(LayerConfig):
    """Configuration for a sector (pie/donut) chart layer.

    Attributes:
        start_angle: Start angle in degrees (0–360).
        end_angle: End angle in degrees (must be > *start_angle*).
        inner_radius: Inner radius ratio for donut charts (0 = pie, 0–1).
        colors: Optional list of segment colours.
    """
    start_angle: float = Field(default=0.0, ge=0.0, le=360.0, description="Start angle.")
    end_angle: float = Field(default=360.0, gt=0.0, le=360.0, description="End angle.")
    inner_radius: float | None = Field(
        default=None, ge=0.0, lt=1.0, description="Inner radius for donut (0=pie)."
    )
    colors: list[str] = Field(default_factory=list, description="Segment colours.")

    @model_validator(mode="after")
    def _validate_angles(self) -> "SectorPlotConfig":
        if self.end_angle <= self.start_angle:
            raise ValueError(
                f"end_angle ({self.end_angle}) must be greater than "
                f"start_angle ({self.start_angle})."
            )
        return self


class SectorLayer(Layer):
    """Sector layer for pie, donut, and radial charts.

    Args:
        index: Segment labels.
        values: Segment values.
        config: Sector-specific plot configuration.

    Examples:
        >>> layer = SectorLayer(
        ...     DataArray(["A","B","C"]),
        ...     DataArray([40, 35, 25]),
        ...     SectorPlotConfig(inner_radius=0.4),
        ... )
    """

    def __init__(
        self,
        index: ArrayData | None = None,
        values: ArrayData | None = None,
        config: SectorPlotConfig | None = None,
    ) -> None:
        super().__init__(LayerType.SECTOR, index, values, config or SectorPlotConfig())

    @property
    def config(self) -> SectorPlotConfig:
        """Return the typed sector plot configuration."""
        assert isinstance(self._config, SectorPlotConfig)
        return self._config

    @classmethod
    def _from_dict_impl(cls, data: dict[str, Any]) -> "SectorLayer":
        index = DataArray(data["index"]) if data.get("index") is not None else None
        values = DataArray(data["values"]) if data.get("values") is not None else None
        config = SectorPlotConfig(**data.get("config", {}))
        return cls(index=index, values=values, config=config)
