# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Scale type enumeration for axis and variable configuration."""

from vcti.enum import EnumValueLowerCase, auto_enum_value


class ScaleType(EnumValueLowerCase):
    """Mathematical scale type for axis display and data interpretation.

    Examples:
        >>> ScaleType.LINEAR.value
        'linear'
        >>> ScaleType.LOGARITHMIC.value
        'logarithmic'
    """
    #: Linear scale (default).
    LINEAR = auto_enum_value()
    #: Logarithmic scale.
    LOGARITHMIC = auto_enum_value()
