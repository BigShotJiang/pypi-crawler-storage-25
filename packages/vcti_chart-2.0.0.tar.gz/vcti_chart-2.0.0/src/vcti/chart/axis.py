# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Axis types, styles, and layout configuration for chart facets."""

from pydantic import BaseModel, Field

from vcti.enum import EnumValueLowerCase, auto_enum_value

from .coordsys import CoordSysType
from .scale import ScaleType


class AxisType(EnumValueLowerCase):
    """Axis direction enumeration.

    Examples:
        >>> AxisType.X.value
        'x'
    """
    #: Horizontal axis.
    X = auto_enum_value()
    #: Vertical axis.
    Y = auto_enum_value()
    #: Angular axis for circular charts.
    ANGULAR = auto_enum_value()
    #: Radial axis for circular charts.
    RADIAL = auto_enum_value()


class AxesAlignment(EnumValueLowerCase):
    """How multiple panels arrange their value axes within a facet.

    Examples:
        >>> AxesAlignment.PARALLEL.value
        'parallel'
    """
    #: Shared index axis with multiple overlaid value axes (e.g. dual Y).
    PARALLEL = auto_enum_value()
    #: Stacked panels, each with its own subplot area.
    SERIAL = auto_enum_value()


class AxisStyle(BaseModel):
    """Visual styling for a single axis.

    Attributes:
        label: Display label for the axis.
        scale: Visual scaling type.
        color: Colour for the axis line and labels.
        font_size: Font size in points (8–72).
        show_grid: Whether to show grid lines.
        tick_interval: Spacing between major ticks (auto if ``None``).
        tick_count: Number of ticks (alternative to *tick_interval*).
        show_axis_line: Whether to draw the axis line itself.
        label_padding: Padding around the axis label in pixels.

    Examples:
        >>> style = AxisStyle(label="Temperature (°C)", show_grid=True)
    """
    label: str | None = Field(default=None, description="Display label for the axis.")
    scale: ScaleType = Field(default=ScaleType.LINEAR, description="Visual scale type.")
    color: str = Field(default="black", description="Axis colour.")
    font_size: int = Field(default=12, ge=8, le=72, description="Font size in points.")
    show_grid: bool = Field(default=True, description="Show grid lines.")
    tick_interval: float | None = Field(default=None, description="Major tick spacing.")
    tick_count: int | None = Field(default=None, ge=2, description="Number of ticks.")
    show_axis_line: bool = Field(default=True, description="Show the axis line.")
    label_padding: int = Field(default=5, ge=0, description="Label padding in pixels.")

    @classmethod
    def create_default(cls, label: str | None = None) -> "AxisStyle":
        """Create a default axis style with an optional label."""
        return cls(label=label)


class AxesLayout(BaseModel):
    """Spatial arrangement of axes within a facet.

    Attributes:
        index_axis: Which axis carries the independent variable.
        value_axes_alignment: How value axes are arranged.

    Examples:
        >>> layout = AxesLayout.create_default(CoordSysType.CARTESIAN)
        >>> layout.index_axis
        <AxisType.X: 'x'>
    """
    index_axis: AxisType = Field(default=AxisType.X, description="Index axis direction.")
    value_axes_alignment: AxesAlignment = Field(
        default=AxesAlignment.PARALLEL,
        description="Value axes arrangement.",
    )

    @classmethod
    def create_default(cls, coordsys: CoordSysType) -> "AxesLayout":
        """Create a default layout appropriate for *coordsys*."""
        defaults: dict[CoordSysType, tuple[AxisType, AxesAlignment]] = {
            CoordSysType.CARTESIAN: (AxisType.X, AxesAlignment.PARALLEL),
            CoordSysType.CIRCULAR: (AxisType.ANGULAR, AxesAlignment.SERIAL),
        }
        index_axis, alignment = defaults.get(
            coordsys, (AxisType.X, AxesAlignment.PARALLEL)
        )
        return cls(index_axis=index_axis, value_axes_alignment=alignment)
