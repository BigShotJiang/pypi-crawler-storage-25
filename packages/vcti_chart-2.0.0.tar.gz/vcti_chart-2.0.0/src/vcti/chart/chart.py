# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Chart — top-level container for multiple facets."""

from __future__ import annotations

from typing import Any

from vcti.deck import Deck

from .facet import Facet
from .layout import LayoutConfig
from .legend import LegendConfig


class Chart:
    """Top-level container organising facets into a chart layout.

    The hierarchy is: **Chart → Facet → Panel → Layer**.

    Args:
        layout: Grid layout configuration for facet arrangement.
        legend: Legend visibility configuration.

    Examples:
        >>> chart = Chart(layout=LayoutConfig(items_per_row=2))
        >>> chart.facets.add("f1", facet)
        >>> data = chart.to_dict()  # JSON-safe for template consumption
    """

    def __init__(
        self,
        layout: LayoutConfig | None = None,
        legend: LegendConfig | None = None,
    ) -> None:
        self.facets: Deck[Facet] = Deck()
        self.layout = layout or LayoutConfig()
        self.legend = legend or LegendConfig()

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable dictionary of the entire chart.

        The returned dict is the contract consumed by Jinja2 templates
        via the external ``vcti-template`` package.
        """
        return {
            "facets": {
                fid: facet.to_dict()
                for fid, facet in zip(self.facets.ids(), self.facets.items())
            },
            "facet_order": self.facets.ids(),
            "layout": self.layout.model_dump(),
            "legend": self.legend.model_dump(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Chart:
        """Reconstruct a :class:`Chart` from a dictionary."""
        layout = LayoutConfig(**data.get("layout", {}))
        legend = LegendConfig(**data.get("legend", {}))
        chart = cls(layout=layout, legend=legend)
        facet_order = data.get("facet_order", list(data.get("facets", {}).keys()))
        for fid in facet_order:
            facet_data = data["facets"][fid]
            chart.facets.add(fid, Facet.from_dict(facet_data))
        return chart

    def __repr__(self) -> str:
        return f"Chart(facets={len(self.facets)}, layout={self.layout.items_per_row} per row)"

    def __len__(self) -> int:
        """Return the number of facets."""
        return len(self.facets)
