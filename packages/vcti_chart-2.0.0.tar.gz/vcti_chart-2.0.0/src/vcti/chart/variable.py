# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Variable data container with semantic metadata."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from .data import ArrayData, DataArray
from .scale import ScaleType


class VariableInfo(BaseModel):
    """Semantic metadata describing a variable's inherent properties.

    Attributes:
        name: Human-readable name.
        unit: Unit of measurement (e.g. ``"°C"``, ``"m/s"``).
        range: Valid value range as ``(min, max)``.
        scale: Mathematical distribution of the data.
        description: Additional notes.

    Examples:
        >>> info = VariableInfo(name="Temperature", unit="°C")
    """
    name: str = Field(..., description="Human-readable name.")
    unit: str | None = Field(default=None, description="Unit of measurement.")
    range: tuple[float, float] | None = Field(default=None, description="Valid value range.")
    scale: ScaleType = Field(default=ScaleType.LINEAR, description="Data scale type.")
    description: str | None = Field(default=None, description="Additional notes.")

    @classmethod
    def create_default(cls, name: str) -> VariableInfo:
        """Create a minimal :class:`VariableInfo` with just a name."""
        return cls(name=name)


class Variable:
    """Named data container with semantic metadata.

    Args:
        id: Unique identifier (e.g. ``"temperature"``).
        values: Numerical data values.
        metadata: Semantic metadata describing the variable.

    Examples:
        >>> var = Variable("temp", DataArray([20, 25, 30]),
        ...                VariableInfo(name="Temperature", unit="°C"))
        >>> var.id
        'temp'
    """

    def __init__(
        self,
        id: str,
        values: ArrayData | None = None,
        metadata: VariableInfo | None = None,
    ) -> None:
        self.id = id
        self.values = values
        self.metadata = metadata if metadata is not None else VariableInfo.create_default(name=id)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable dictionary."""
        return {
            "id": self.id,
            "values": self.values.to_list() if self.values else None,
            "metadata": self.metadata.model_dump(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Variable:
        """Reconstruct a :class:`Variable` from a dictionary."""
        values = DataArray(data["values"]) if data.get("values") is not None else None
        metadata = VariableInfo(**data["metadata"]) if data.get("metadata") else None
        return cls(id=data["id"], values=values, metadata=metadata)

    def __repr__(self) -> str:
        name = self.metadata.name if self.metadata else ""
        n = len(self.values) if self.values else 0
        return f"Variable(id={self.id!r}, name={name!r}, n={n})"
