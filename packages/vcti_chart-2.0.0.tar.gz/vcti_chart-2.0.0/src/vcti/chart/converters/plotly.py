# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Convert Chart objects to Plotly figures."""

from typing import Any

import plotly.graph_objs as go
from plotly.subplots import make_subplots

from ..chart import Chart
from ..axis import AxesAlignment
from ..coordsys import CoordSysType
from ..layer import XyLayer, BarLayer, SectorLayer, LineType, MarkerType, AreaFillType


def get_figure(chart: Chart) -> go.Figure:
    """Convert a :class:`Chart` to a Plotly ``Figure``.

    Args:
        chart: The chart to convert.

    Returns:
        A ``plotly.graph_objs.Figure`` instance.
    """
    facet_ids = chart.facets.ids()
    n_facets = len(facet_ids)

    if n_facets == 0:
        return go.Figure()

    # Determine grid dimensions
    cols = min(n_facets, chart.layout.items_per_row)
    rows = (n_facets + cols - 1) // cols

    # Detect subplot types (pie needs "domain" type)
    subplot_types = []
    for fid in facet_ids:
        facet = chart.facets.get(fid)
        if facet and facet.coordsys == CoordSysType.CIRCULAR:
            subplot_types.append({"type": "domain"})
        else:
            subplot_types.append({"type": "xy"})

    fig = make_subplots(rows=rows, cols=cols, specs=_build_specs(rows, cols, subplot_types))

    for idx, fid in enumerate(facet_ids):
        facet = chart.facets.get(fid)
        if facet is None:
            continue
        row = idx // cols + 1
        col = idx % cols + 1

        domain_values = facet.domain_var.values.to_list() if facet.domain_var.values else []

        for pid in facet.panels.ids():
            panel = facet.panels.get(pid)
            if panel is None:
                continue

            index_data = panel.index.to_list() if panel.index else domain_values

            for lid in panel.layers.ids():
                layer = panel.layers.get(lid)
                if layer is None:
                    continue

                if isinstance(layer, XyLayer):
                    trace = _xy_trace(index_data, layer, panel)
                    fig.add_trace(trace, row=row, col=col)
                elif isinstance(layer, BarLayer):
                    trace = _bar_trace(index_data, layer)
                    fig.add_trace(trace, row=row, col=col)
                elif isinstance(layer, SectorLayer):
                    trace = _sector_trace(index_data, layer)
                    fig.add_trace(trace, row=row, col=col)

        # Set axis labels from facet/panel metadata
        axis_suffix = "" if idx == 0 else str(idx + 1)
        fig.update_layout(**{
            f"xaxis{axis_suffix}": {"title": {"text": facet.axis_style.label or ""}},
        })
        # Use first panel's range_var for Y axis label
        first_panel_ids = facet.panels.ids()
        if first_panel_ids:
            first_panel = facet.panels.get(first_panel_ids[0])
            if first_panel:
                fig.update_layout(**{
                    f"yaxis{axis_suffix}": {
                        "title": {"text": first_panel.axis_style.label or ""}
                    },
                })

    if chart.legend.show:
        fig.update_layout(showlegend=True)
    else:
        fig.update_layout(showlegend=False)

    return fig


def _build_specs(
    rows: int, cols: int, subplot_types: list[dict[str, str]]
) -> list[list[dict[str, str] | None]]:
    """Build subplot specs grid, padding with None for empty cells."""
    specs: list[list[dict[str, str] | None]] = []
    idx = 0
    for _r in range(rows):
        row_specs: list[dict[str, str] | None] = []
        for _c in range(cols):
            if idx < len(subplot_types):
                row_specs.append(subplot_types[idx])
                idx += 1
            else:
                row_specs.append(None)
        specs.append(row_specs)
    return specs


def _xy_trace(index_data: list, layer: XyLayer, panel: Any) -> go.Scatter:
    """Convert an XyLayer to a Plotly Scatter trace."""
    values = layer.values.to_list() if layer.values else []
    cfg = layer.config

    mode_parts: list[str] = []
    if cfg.line_type != LineType.NONE:
        mode_parts.append("lines")
    if cfg.marker_type != MarkerType.NONE:
        mode_parts.append("markers")
    mode = "+".join(mode_parts) or "lines"

    kwargs: dict[str, Any] = {
        "x": index_data,
        "y": values,
        "name": panel.range_var.metadata.name,
        "mode": mode,
    }

    if cfg.line_color:
        kwargs["line"] = {"color": cfg.line_color}
    if cfg.marker_color:
        kwargs["marker"] = {"color": cfg.marker_color}
    if cfg.area_fill_type == AreaFillType.FILLED:
        kwargs["fill"] = "tozeroy"

    return go.Scatter(**kwargs)


def _bar_trace(index_data: list, layer: BarLayer) -> go.Bar:
    """Convert a BarLayer to a Plotly Bar trace."""
    values = layer.values.to_list() if layer.values else []
    cfg = layer.config
    kwargs: dict[str, Any] = {
        "x": index_data,
        "y": values,
        "marker": {"color": cfg.color},
        "width": cfg.width,
    }
    return go.Bar(**kwargs)


def _sector_trace(index_data: list, layer: SectorLayer) -> go.Pie:
    """Convert a SectorLayer to a Plotly Pie trace."""
    values = layer.values.to_list() if layer.values else []
    cfg = layer.config
    kwargs: dict[str, Any] = {
        "labels": index_data,
        "values": values,
        "hole": cfg.inner_radius or 0,
    }
    if cfg.colors:
        kwargs["marker"] = {"colors": cfg.colors}
    return go.Pie(**kwargs)
