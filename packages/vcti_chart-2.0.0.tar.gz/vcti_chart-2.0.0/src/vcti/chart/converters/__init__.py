# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Optional rendering converters for Chart objects.

Provides converters for Plotly and Bokeh visualisation libraries.
Each converter transforms a :class:`~vcti.chart.chart.Chart` into
the corresponding library's figure object.
"""
