# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Convert Chart objects to Bokeh layouts."""

from math import pi
from typing import Any

import numpy as np
from bokeh.layouts import gridplot
from bokeh.models import ColumnDataSource
from bokeh.plotting import figure

from ..chart import Chart
from ..coordsys import CoordSysType
from ..layer import (
    XyLayer, BarLayer, SectorLayer,
    LineType, MarkerType, AreaFillType,
)


_LINE_DASH_MAP = {
    LineType.SOLID: "solid",
    LineType.DASHED: "dashed",
    LineType.DOTTED: "dotted",
    LineType.DASH_DOT: "dashdot",
}


def chart_to_bokeh(chart: Chart) -> Any:
    """Convert a :class:`Chart` to a Bokeh layout.

    Args:
        chart: The chart to convert.

    Returns:
        A Bokeh figure or gridplot layout.
    """
    figs: list[Any] = []

    for fid in chart.facets.ids():
        facet = chart.facets.get(fid)
        if facet is None:
            continue

        domain_values = facet.domain_var.values.to_list() if facet.domain_var.values else []

        if facet.coordsys == CoordSysType.CARTESIAN:
            p = figure(
                title="",
                x_axis_label=facet.axis_style.label or "",
                width=600, height=400,
            )
            for pid in facet.panels.ids():
                panel = facet.panels.get(pid)
                if panel is None:
                    continue

                p.yaxis.axis_label = panel.axis_style.label or ""
                index_data = panel.index.to_list() if panel.index else domain_values

                for lid in panel.layers.ids():
                    layer = panel.layers.get(lid)
                    if layer is None:
                        continue

                    values = layer.values.to_list() if layer.values else []
                    source = ColumnDataSource(data={"x": index_data, "y": values})
                    label = panel.range_var.metadata.name

                    if isinstance(layer, XyLayer):
                        cfg = layer.config
                        color = cfg.line_color or "blue"
                        dash = _LINE_DASH_MAP.get(cfg.line_type, "solid")

                        if layer.line_enabled:
                            p.line("x", "y", source=source, color=color,
                                   legend_label=label, line_dash=dash)
                        if layer.marker_enabled:
                            mc = cfg.marker_color or color
                            p.scatter("x", "y", source=source, color=mc,
                                      legend_label=label)
                        if layer.area_fill_enabled:
                            p.varea(x="x", y1=0, y2="y", source=source,
                                    fill_color=color, fill_alpha=0.3)

                    elif isinstance(layer, BarLayer):
                        cfg = layer.config
                        p.vbar(x="x", top="y", width=cfg.width, source=source,
                               color=cfg.color, legend_label=label)

            if p.legend:
                p.legend.click_policy = "hide"
            figs.append(p)

        elif facet.coordsys == CoordSysType.CIRCULAR:
            for pid in facet.panels.ids():
                panel = facet.panels.get(pid)
                if panel is None:
                    continue
                for lid in panel.layers.ids():
                    layer = panel.layers.get(lid)
                    if not isinstance(layer, SectorLayer):
                        continue
                    values = layer.values.to_list() if layer.values else []
                    if not values:
                        continue
                    cfg = layer.config
                    total = sum(values)
                    angles = [v / total * 2 * pi for v in values]
                    starts = np.cumsum([0] + angles[:-1]).tolist()
                    ends = np.cumsum(angles).tolist()
                    colors = cfg.colors or ["blue"] * len(values)

                    p = figure(
                        title="", width=400, height=400,
                        toolbar_location=None,
                        x_range=(-1.2, 1.2), y_range=(-1.2, 1.2),
                    )
                    inner = cfg.inner_radius or 0
                    p.annular_wedge(
                        x=0, y=0,
                        inner_radius=inner, outer_radius=1,
                        start_angle=starts, end_angle=ends,
                        color=colors, direction="anticlock",
                    )
                    p.axis.visible = False
                    p.grid.visible = False
                    figs.append(p)

    if len(figs) == 1:
        return figs[0]
    if not figs:
        return gridplot([[]])
    cols = min(len(figs), chart.layout.items_per_row)
    rows_list = [figs[i:i + cols] for i in range(0, len(figs), cols)]
    return gridplot(rows_list)
