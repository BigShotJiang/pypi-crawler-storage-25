# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Layout configuration for chart facet arrangement."""

from pydantic import BaseModel, Field


class LayoutConfig(BaseModel):
    """Configuration for spatial arrangement of facets in a chart.

    Attributes:
        items_per_row: Maximum number of facets per row in the grid layout.

    Examples:
        >>> layout = LayoutConfig(items_per_row=2)
        >>> layout.items_per_row
        2
    """
    items_per_row: int = Field(default=4, gt=0, description="Maximum facets per row.")
