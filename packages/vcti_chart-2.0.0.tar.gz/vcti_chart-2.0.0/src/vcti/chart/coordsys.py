# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Coordinate system types and compatibility policies."""

from typing import Protocol, runtime_checkable

from vcti.deck import CompatibilityPolicy
from vcti.enum import EnumValueLowerCase, auto_enum_value


class CoordSysType(EnumValueLowerCase):
    """Coordinate system type for facets and panels.

    Examples:
        >>> CoordSysType.CARTESIAN.value
        'cartesian'
    """
    #: Standard x-y cartesian coordinate system.
    CARTESIAN = auto_enum_value()
    #: Circular (polar) coordinate system for pie, donut, radar charts.
    CIRCULAR = auto_enum_value()


@runtime_checkable
class WithCoordSys(Protocol):
    """Protocol for objects that have a coordinate system type."""

    @property
    def coordsys(self) -> CoordSysType: ...


class MatchingCoordSysPolicy[T: WithCoordSys](CompatibilityPolicy[CoordSysType, T]):
    """Policy that requires an item's coordsys to match the deck's type.

    Used by :class:`~vcti.chart.facet.Facet` to ensure all panels share
    the same coordinate system.

    Examples:
        >>> policy = MatchingCoordSysPolicy()
        >>> policy.is_compatible(cartesian_panel, CoordSysType.CARTESIAN)
        True
    """

    def is_compatible(self, item: T, deck_type: CoordSysType) -> bool:
        """Return ``True`` if *item.coordsys* equals *deck_type*."""
        return item.coordsys == deck_type
