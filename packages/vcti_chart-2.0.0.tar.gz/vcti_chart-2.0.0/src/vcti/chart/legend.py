# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Legend configuration for chart display."""

from pydantic import BaseModel, Field


class LegendConfig(BaseModel):
    """Configuration for chart legend visibility.

    Attributes:
        show: Whether to display the legend.

    Examples:
        >>> legend = LegendConfig(show=False)
        >>> legend.show
        False
    """
    show: bool = Field(default=True, description="Whether to display the legend.")
