# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Chart facet — panels sharing a common domain variable."""

from __future__ import annotations

from typing import Any

from vcti.deck import PolicyBoundDeck

from .axis import AxisStyle, AxesLayout
from .coordsys import CoordSysType, MatchingCoordSysPolicy
from .panel import Panel
from .variable import Variable


class Facet:
    """A group of panels that share a common independent variable (domain).

    All panels in a facet visualise different dependent variables against
    the same domain variable (e.g. multiple quantities vs. time).

    Args:
        coordsys: Coordinate system type for all panels.
        domain_var: Shared independent variable.
        axis_style: Styling for the domain axis.
        axes_layout: Spatial arrangement of axes within this facet.

    Examples:
        >>> time = Variable("time", DataArray([1,2,3]),
        ...                 VariableInfo(name="Time", unit="s"))
        >>> facet = Facet(CoordSysType.CARTESIAN, domain_var=time)
        >>> facet.panels.add("temp", Panel(CoordSysType.CARTESIAN, temp_var))
    """

    def __init__(
        self,
        coordsys: CoordSysType,
        domain_var: Variable,
        axis_style: AxisStyle | None = None,
        axes_layout: AxesLayout | None = None,
    ) -> None:
        self._coordsys = coordsys
        self.domain_var = domain_var
        self.axis_style = axis_style or AxisStyle.create_default(
            domain_var.metadata.name or domain_var.id
        )
        self.panels: PolicyBoundDeck[CoordSysType, Panel] = PolicyBoundDeck(
            deck_type=coordsys,
            policy=MatchingCoordSysPolicy(),
        )
        self.axes_layout = axes_layout or AxesLayout.create_default(coordsys)

    @property
    def coordsys(self) -> CoordSysType:
        """Coordinate system type of this facet."""
        return self._coordsys

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serialisable dictionary."""
        return {
            "coordsys": self._coordsys.value,
            "domain_var": self.domain_var.to_dict(),
            "axis_style": self.axis_style.model_dump(),
            "axes_layout": self.axes_layout.model_dump(),
            "panels": {
                pid: panel.to_dict()
                for pid, panel in zip(self.panels.ids(), self.panels.items())
            },
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Facet:
        """Reconstruct a :class:`Facet` from a dictionary."""
        coordsys = CoordSysType(data["coordsys"])
        domain_var = Variable.from_dict(data["domain_var"])
        axis_style = AxisStyle(**data["axis_style"]) if data.get("axis_style") else None
        axes_layout = AxesLayout(**data["axes_layout"]) if data.get("axes_layout") else None
        facet = cls(
            coordsys=coordsys,
            domain_var=domain_var,
            axis_style=axis_style,
            axes_layout=axes_layout,
        )
        for panel_id, panel_data in data.get("panels", {}).items():
            facet.panels.add(panel_id, Panel.from_dict(panel_data))
        return facet

    def __repr__(self) -> str:
        return (
            f"Facet(coordsys={self._coordsys!r}, "
            f"domain_var={self.domain_var.id!r}, "
            f"panels={len(self.panels)})"
        )
