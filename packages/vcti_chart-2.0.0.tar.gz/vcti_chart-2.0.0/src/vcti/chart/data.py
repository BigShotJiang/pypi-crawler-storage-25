# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Data types and protocols for chart data."""

from typing import Protocol, runtime_checkable

import numpy as np
import pandas as pd


@runtime_checkable
class ArrayData(Protocol):
    """Protocol for array-like data containers.

    Implementations must provide conversion to both numpy arrays
    (for computation) and Python lists (for JSON serialisation).

    Examples:
        >>> class MyData:
        ...     def array(self) -> np.ndarray: ...
        ...     def to_list(self) -> list: ...
        ...     def __len__(self) -> int: ...
        ...     @property
        ...     def dtype(self) -> np.dtype: ...
    """

    def array(self) -> np.ndarray:
        """Return the data as a numpy ndarray."""
        ...

    @property
    def dtype(self) -> np.dtype:
        """Return the numpy dtype of the underlying data."""
        ...

    def to_list(self) -> list:
        """Return the data as a plain Python list."""
        ...

    def __len__(self) -> int:
        """Return the number of elements."""
        ...


class DataArray:
    """Concrete :class:`ArrayData` implementation for numpy, pandas, and lists.

    Args:
        data: Input data as numpy ndarray, pandas Series, or Python list.

    Raises:
        TypeError: If *data* is not a supported type.

    Examples:
        >>> da = DataArray([1, 2, 3])
        >>> da.to_list()
        [1, 2, 3]
        >>> len(da)
        3
    """

    def __init__(self, data: np.ndarray | pd.Series | list) -> None:
        if not isinstance(data, (np.ndarray, pd.Series, list)):
            raise TypeError(
                f"Unsupported data type {type(data).__name__}. "
                "DataArray supports numpy.ndarray, pandas.Series, or list."
            )
        self._data = data

    def array(self) -> np.ndarray:
        """Return the data as a numpy ndarray."""
        if isinstance(self._data, pd.Series):
            return self._data.to_numpy()
        if isinstance(self._data, np.ndarray):
            return self._data
        return np.array(self._data)

    @property
    def dtype(self) -> np.dtype:
        """Return the numpy dtype of the underlying data."""
        return self.array().dtype

    def to_list(self) -> list:
        """Return the data as a plain Python list."""
        if isinstance(self._data, (pd.Series, np.ndarray)):
            return self._data.tolist()
        return list(self._data)

    def __len__(self) -> int:
        """Return the number of elements."""
        return len(self._data)

    def __repr__(self) -> str:
        return f"DataArray(type={type(self._data).__name__}, length={len(self)})"
