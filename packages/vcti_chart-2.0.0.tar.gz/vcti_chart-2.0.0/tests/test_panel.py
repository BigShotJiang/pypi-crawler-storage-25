# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for chart Panel and CoordSysLayersPolicy."""

import pytest

from vcti.chart import (
    CoordSysType,
    CoordSysLayersPolicy,
    DataArray,
    VariableInfo,
    Variable,
    AxisStyle,
    LayerType,
    XyLayer,
    XyPlotConfig,
    BarLayer,
    SectorLayer,
    Panel,
)


def _make_variable(var_id: str = "temperature", name: str = "Temperature",
                   unit: str = "C", values: list | None = None) -> Variable:
    """Create a Variable for testing."""
    data = DataArray(values) if values is not None else None
    return Variable(var_id, values=data, metadata=VariableInfo(name=name, unit=unit))


def _make_cartesian_panel(**kwargs) -> Panel:
    """Create a cartesian Panel with a default range variable."""
    range_var = kwargs.pop("range_var", _make_variable())
    return Panel(CoordSysType.CARTESIAN, range_var=range_var, **kwargs)


def _make_circular_panel(**kwargs) -> Panel:
    """Create a circular Panel with a default range variable."""
    range_var = kwargs.pop("range_var", _make_variable("category", "Category"))
    return Panel(CoordSysType.CIRCULAR, range_var=range_var, **kwargs)


# -- CoordSysLayersPolicy -----------------------------------------------------


class TestCoordSysLayersPolicy:
    """Tests for the layer-type/coordsys compatibility policy."""

    def test_cartesian_accepts_xy(self):
        policy = CoordSysLayersPolicy()
        layer = XyLayer()
        assert policy.is_compatible(layer, CoordSysType.CARTESIAN) is True

    def test_cartesian_accepts_bar(self):
        policy = CoordSysLayersPolicy()
        layer = BarLayer()
        assert policy.is_compatible(layer, CoordSysType.CARTESIAN) is True

    def test_cartesian_rejects_sector(self):
        policy = CoordSysLayersPolicy()
        layer = SectorLayer()
        assert policy.is_compatible(layer, CoordSysType.CARTESIAN) is False

    def test_circular_accepts_sector(self):
        policy = CoordSysLayersPolicy()
        layer = SectorLayer()
        assert policy.is_compatible(layer, CoordSysType.CIRCULAR) is True

    def test_circular_rejects_xy(self):
        policy = CoordSysLayersPolicy()
        layer = XyLayer()
        assert policy.is_compatible(layer, CoordSysType.CIRCULAR) is False

    def test_circular_rejects_bar(self):
        policy = CoordSysLayersPolicy()
        layer = BarLayer()
        assert policy.is_compatible(layer, CoordSysType.CIRCULAR) is False


# -- Panel creation ------------------------------------------------------------


class TestPanelCreation:
    """Tests for Panel construction."""

    def test_coordsys_property(self):
        panel = _make_cartesian_panel()
        assert panel.coordsys == CoordSysType.CARTESIAN

    def test_range_var_stored(self):
        var = _make_variable("pressure", "Pressure", "Pa")
        panel = Panel(CoordSysType.CARTESIAN, range_var=var)
        assert panel.range_var.id == "pressure"

    def test_default_axis_style(self):
        panel = _make_cartesian_panel()
        assert panel.axis_style is not None
        assert isinstance(panel.axis_style, AxisStyle)

    def test_custom_axis_style(self):
        style = AxisStyle(label="Custom", show_grid=False)
        panel = _make_cartesian_panel(axis_style=style)
        assert panel.axis_style.label == "Custom"
        assert panel.axis_style.show_grid is False

    def test_default_index_is_none(self):
        panel = _make_cartesian_panel()
        assert panel.index is None

    def test_custom_index(self):
        idx = DataArray([1, 2, 3])
        panel = _make_cartesian_panel(index=idx)
        assert panel.index.to_list() == [1, 2, 3]

    def test_layers_initially_empty(self):
        panel = _make_cartesian_panel()
        assert len(panel.layers) == 0


# -- Adding layers -------------------------------------------------------------


class TestPanelAddLayers:
    """Tests for adding compatible and incompatible layers."""

    def test_add_xy_to_cartesian(self):
        panel = _make_cartesian_panel()
        layer = XyLayer(DataArray([1, 2]), DataArray([10, 20]))
        panel.layers.add("line1", layer)
        assert len(panel.layers) == 1

    def test_add_bar_to_cartesian(self):
        panel = _make_cartesian_panel()
        layer = BarLayer(DataArray(["A", "B"]), DataArray([5, 10]))
        panel.layers.add("bar1", layer)
        assert len(panel.layers) == 1

    def test_add_multiple_layers(self):
        panel = _make_cartesian_panel()
        panel.layers.add("line1", XyLayer())
        panel.layers.add("bar1", BarLayer())
        assert len(panel.layers) == 2

    def test_add_sector_to_cartesian_raises(self):
        panel = _make_cartesian_panel()
        layer = SectorLayer()
        with pytest.raises(ValueError):
            panel.layers.add("sector1", layer)

    def test_add_sector_to_circular(self):
        panel = _make_circular_panel()
        layer = SectorLayer(DataArray(["A", "B"]), DataArray([60, 40]))
        panel.layers.add("pie1", layer)
        assert len(panel.layers) == 1

    def test_add_xy_to_circular_raises(self):
        panel = _make_circular_panel()
        layer = XyLayer()
        with pytest.raises(ValueError):
            panel.layers.add("line1", layer)

    def test_add_bar_to_circular_raises(self):
        panel = _make_circular_panel()
        layer = BarLayer()
        with pytest.raises(ValueError):
            panel.layers.add("bar1", layer)


# -- Panel serialisation -------------------------------------------------------


class TestPanelRoundTrip:
    """Tests for Panel to_dict()/from_dict() serialisation."""

    def test_round_trip_empty_panel(self):
        panel = _make_cartesian_panel()
        d = panel.to_dict()
        restored = Panel.from_dict(d)
        assert restored.coordsys == CoordSysType.CARTESIAN
        assert restored.range_var.id == "temperature"
        assert len(restored.layers) == 0

    def test_round_trip_with_layers(self):
        panel = _make_cartesian_panel()
        panel.layers.add("line1", XyLayer(DataArray([1, 2]), DataArray([10, 20])))
        panel.layers.add("bar1", BarLayer(DataArray(["A", "B"]), DataArray([5, 15])))

        d = panel.to_dict()
        restored = Panel.from_dict(d)

        assert restored.coordsys == CoordSysType.CARTESIAN
        assert len(restored.layers) == 2

    def test_round_trip_preserves_axis_style(self):
        style = AxisStyle(label="Temp (C)", font_size=14, show_grid=False)
        panel = _make_cartesian_panel(axis_style=style)

        d = panel.to_dict()
        restored = Panel.from_dict(d)

        assert restored.axis_style.label == "Temp (C)"
        assert restored.axis_style.font_size == 14
        assert restored.axis_style.show_grid is False

    def test_round_trip_preserves_index(self):
        idx = DataArray([100, 200, 300])
        panel = _make_cartesian_panel(index=idx)

        d = panel.to_dict()
        restored = Panel.from_dict(d)

        assert restored.index is not None
        assert restored.index.to_list() == [100, 200, 300]

    def test_dict_has_coordsys_key(self):
        d = _make_cartesian_panel().to_dict()
        assert d["coordsys"] == "cartesian"
