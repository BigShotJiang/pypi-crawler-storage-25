# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for DataArray and ArrayData protocol."""

import numpy as np
import pandas as pd
import pytest

from vcti.chart import DataArray, ArrayData


class TestDataArrayFromNumpy:
    """Tests for DataArray constructed from numpy ndarray."""

    def test_array_returns_ndarray(self):
        arr = np.array([1.0, 2.0, 3.0])
        da = DataArray(arr)
        result = da.array()
        assert isinstance(result, np.ndarray)
        np.testing.assert_array_equal(result, arr)

    def test_to_list(self):
        arr = np.array([10, 20, 30])
        da = DataArray(arr)
        assert da.to_list() == [10, 20, 30]

    def test_len(self):
        arr = np.array([1, 2, 3, 4])
        da = DataArray(arr)
        assert len(da) == 4

    def test_dtype(self):
        arr = np.array([1.5, 2.5], dtype=np.float64)
        da = DataArray(arr)
        assert da.dtype == np.float64


class TestDataArrayFromPandas:
    """Tests for DataArray constructed from pandas Series."""

    def test_array_returns_ndarray(self):
        series = pd.Series([4.0, 5.0, 6.0])
        da = DataArray(series)
        result = da.array()
        assert isinstance(result, np.ndarray)
        np.testing.assert_array_equal(result, np.array([4.0, 5.0, 6.0]))

    def test_to_list(self):
        series = pd.Series([7, 8, 9])
        da = DataArray(series)
        assert da.to_list() == [7, 8, 9]

    def test_len(self):
        series = pd.Series([1, 2])
        da = DataArray(series)
        assert len(da) == 2

    def test_dtype(self):
        series = pd.Series([1, 2, 3], dtype=np.int64)
        da = DataArray(series)
        assert da.dtype == np.int64


class TestDataArrayFromList:
    """Tests for DataArray constructed from a Python list."""

    def test_array_returns_ndarray(self):
        da = DataArray([10, 20, 30])
        result = da.array()
        assert isinstance(result, np.ndarray)
        np.testing.assert_array_equal(result, np.array([10, 20, 30]))

    def test_to_list(self):
        da = DataArray([1, 2, 3])
        assert da.to_list() == [1, 2, 3]

    def test_len(self):
        da = DataArray([5, 6, 7, 8, 9])
        assert len(da) == 5

    def test_dtype(self):
        da = DataArray([1.0, 2.0])
        assert da.dtype == np.float64

    def test_empty_list(self):
        da = DataArray([])
        assert len(da) == 0
        assert da.to_list() == []


class TestDataArrayErrors:
    """Tests for DataArray type validation."""

    def test_unsupported_type_string_raises(self):
        with pytest.raises(TypeError, match="Unsupported data type"):
            DataArray("not a valid input")

    def test_unsupported_type_dict_raises(self):
        with pytest.raises(TypeError, match="Unsupported data type"):
            DataArray({"a": 1})

    def test_unsupported_type_int_raises(self):
        with pytest.raises(TypeError, match="Unsupported data type"):
            DataArray(42)

    def test_unsupported_type_tuple_raises(self):
        with pytest.raises(TypeError, match="Unsupported data type"):
            DataArray((1, 2, 3))


class TestArrayDataProtocol:
    """Tests for the ArrayData runtime-checkable protocol."""

    def test_data_array_is_instance(self):
        da = DataArray([1, 2, 3])
        assert isinstance(da, ArrayData)

    def test_plain_list_is_not_instance(self):
        assert not isinstance([1, 2, 3], ArrayData)

    def test_ndarray_is_not_instance(self):
        assert not isinstance(np.array([1, 2]), ArrayData)


class TestDataArrayRepr:
    """Tests for DataArray __repr__."""

    def test_repr_contains_type_and_length(self):
        da = DataArray([1, 2, 3])
        r = repr(da)
        assert "list" in r
        assert "3" in r
