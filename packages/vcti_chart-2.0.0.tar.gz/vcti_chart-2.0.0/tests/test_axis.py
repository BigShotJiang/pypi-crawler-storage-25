# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for AxisType, AxesAlignment enums, AxisStyle, and AxesLayout."""

import pytest
from pydantic import ValidationError

from vcti.chart import (
    AxisType,
    AxesAlignment,
    AxisStyle,
    AxesLayout,
    CoordSysType,
    ScaleType,
)


class TestAxisType:
    """Tests for AxisType enum values."""

    def test_x_value(self):
        assert AxisType.X.value == "x"

    def test_y_value(self):
        assert AxisType.Y.value == "y"

    def test_angular_value(self):
        assert AxisType.ANGULAR.value == "angular"

    def test_radial_value(self):
        assert AxisType.RADIAL.value == "radial"

    def test_member_count(self):
        assert len(AxisType) == 4

    def test_invalid_value_raises(self):
        with pytest.raises(ValueError):
            AxisType("z")


class TestAxesAlignment:
    """Tests for AxesAlignment enum values."""

    def test_parallel_value(self):
        assert AxesAlignment.PARALLEL.value == "parallel"

    def test_serial_value(self):
        assert AxesAlignment.SERIAL.value == "serial"

    def test_member_count(self):
        assert len(AxesAlignment) == 2

    def test_invalid_value_raises(self):
        with pytest.raises(ValueError):
            AxesAlignment("diagonal")


class TestAxisStyle:
    """Tests for AxisStyle creation and defaults."""

    def test_defaults(self):
        style = AxisStyle()
        assert style.label is None
        assert style.scale is ScaleType.LINEAR
        assert style.color == "black"
        assert style.font_size == 12
        assert style.show_grid is True
        assert style.tick_interval is None
        assert style.tick_count is None
        assert style.show_axis_line is True
        assert style.label_padding == 5

    def test_custom_values(self):
        style = AxisStyle(
            label="Temperature",
            scale=ScaleType.LOGARITHMIC,
            color="red",
            font_size=16,
            show_grid=False,
            tick_interval=5.0,
            tick_count=10,
            show_axis_line=False,
            label_padding=10,
        )
        assert style.label == "Temperature"
        assert style.scale is ScaleType.LOGARITHMIC
        assert style.color == "red"
        assert style.font_size == 16
        assert style.show_grid is False
        assert style.tick_interval == 5.0
        assert style.tick_count == 10
        assert style.show_axis_line is False
        assert style.label_padding == 10

    def test_create_default_without_label(self):
        style = AxisStyle.create_default()
        assert style.label is None
        assert style.scale is ScaleType.LINEAR

    def test_create_default_with_label(self):
        style = AxisStyle.create_default(label="X Axis")
        assert style.label == "X Axis"

    def test_model_dump_keys(self):
        style = AxisStyle()
        d = style.model_dump()
        expected_keys = {
            "label", "scale", "color", "font_size", "show_grid",
            "tick_interval", "tick_count", "show_axis_line", "label_padding",
        }
        assert set(d.keys()) == expected_keys

    def test_font_size_below_minimum_raises(self):
        with pytest.raises(ValidationError):
            AxisStyle(font_size=7)

    def test_font_size_above_maximum_raises(self):
        with pytest.raises(ValidationError):
            AxisStyle(font_size=73)

    def test_tick_count_below_minimum_raises(self):
        with pytest.raises(ValidationError):
            AxisStyle(tick_count=1)

    def test_label_padding_negative_raises(self):
        with pytest.raises(ValidationError):
            AxisStyle(label_padding=-1)


class TestAxesLayout:
    """Tests for AxesLayout defaults and create_default()."""

    def test_defaults(self):
        layout = AxesLayout()
        assert layout.index_axis is AxisType.X
        assert layout.value_axes_alignment is AxesAlignment.PARALLEL

    def test_create_default_cartesian(self):
        layout = AxesLayout.create_default(CoordSysType.CARTESIAN)
        assert layout.index_axis is AxisType.X
        assert layout.value_axes_alignment is AxesAlignment.PARALLEL

    def test_create_default_circular(self):
        layout = AxesLayout.create_default(CoordSysType.CIRCULAR)
        assert layout.index_axis is AxisType.ANGULAR
        assert layout.value_axes_alignment is AxesAlignment.SERIAL

    def test_custom_axes_layout(self):
        layout = AxesLayout(
            index_axis=AxisType.Y,
            value_axes_alignment=AxesAlignment.SERIAL,
        )
        assert layout.index_axis is AxisType.Y
        assert layout.value_axes_alignment is AxesAlignment.SERIAL
