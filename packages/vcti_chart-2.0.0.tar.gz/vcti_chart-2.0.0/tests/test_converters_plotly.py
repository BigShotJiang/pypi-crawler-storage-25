# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for the Plotly converter module."""

import pytest

plotly = pytest.importorskip("plotly", reason="plotly not installed")

import plotly.graph_objs as go

from vcti.chart import (
    Chart, Facet, Panel, Variable, VariableInfo, DataArray,
    CoordSysType, XyLayer, BarLayer, SectorLayer,
    XyPlotConfig, BarPlotConfig, SectorPlotConfig,
    LineType, MarkerType,
)
from vcti.chart.converters.plotly import get_figure


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def _make_cartesian_xy_chart() -> Chart:
    """Chart with one CARTESIAN facet, one panel, one XyLayer."""
    chart = Chart()
    domain = Variable("x", DataArray([1, 2, 3]), VariableInfo(name="X"))
    facet = Facet(CoordSysType.CARTESIAN, domain_var=domain)
    range_var = Variable("y", metadata=VariableInfo(name="Y"))
    panel = Panel(CoordSysType.CARTESIAN, range_var=range_var)
    layer = XyLayer(values=DataArray([10, 20, 30]), config=XyPlotConfig())
    panel.layers.add("line1", layer)
    facet.panels.add("p1", panel)
    chart.facets.add("f1", facet)
    return chart


def _make_cartesian_bar_chart() -> Chart:
    """Chart with one CARTESIAN facet, one panel, one BarLayer."""
    chart = Chart()
    domain = Variable("cat", DataArray(["A", "B", "C"]), VariableInfo(name="Category"))
    facet = Facet(CoordSysType.CARTESIAN, domain_var=domain)
    range_var = Variable("val", metadata=VariableInfo(name="Value"))
    panel = Panel(CoordSysType.CARTESIAN, range_var=range_var)
    layer = BarLayer(values=DataArray([10, 20, 30]), config=BarPlotConfig())
    panel.layers.add("bar1", layer)
    facet.panels.add("p1", panel)
    chart.facets.add("f1", facet)
    return chart


def _make_circular_sector_chart() -> Chart:
    """Chart with one CIRCULAR facet, one panel, one SectorLayer."""
    chart = Chart()
    domain = Variable("label", DataArray(["A", "B", "C"]), VariableInfo(name="Label"))
    facet = Facet(CoordSysType.CIRCULAR, domain_var=domain)
    range_var = Variable("share", metadata=VariableInfo(name="Share"))
    panel = Panel(CoordSysType.CIRCULAR, range_var=range_var)
    layer = SectorLayer(
        values=DataArray([40, 35, 25]),
        config=SectorPlotConfig(colors=["red", "green", "blue"]),
    )
    panel.layers.add("sec1", layer)
    facet.panels.add("p1", panel)
    chart.facets.add("f1", facet)
    return chart


def _make_multi_facet_chart() -> Chart:
    """Chart with 2 CARTESIAN facets, each with one panel and one XyLayer."""
    chart = Chart()
    for i in range(2):
        domain = Variable(f"x{i}", DataArray([1, 2, 3]), VariableInfo(name=f"X{i}"))
        facet = Facet(CoordSysType.CARTESIAN, domain_var=domain)
        range_var = Variable(f"y{i}", metadata=VariableInfo(name=f"Y{i}"))
        panel = Panel(CoordSysType.CARTESIAN, range_var=range_var)
        layer = XyLayer(values=DataArray([10 + i, 20 + i, 30 + i]))
        panel.layers.add("line", layer)
        facet.panels.add("p", panel)
        chart.facets.add(f"f{i}", facet)
    return chart


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestGetFigureReturnsPlotlyFigure:
    """get_figure should return a plotly.graph_objs.Figure."""

    def test_xy_chart_returns_figure(self):
        fig = get_figure(_make_cartesian_xy_chart())
        assert isinstance(fig, go.Figure)

    def test_bar_chart_returns_figure(self):
        fig = get_figure(_make_cartesian_bar_chart())
        assert isinstance(fig, go.Figure)

    def test_sector_chart_returns_figure(self):
        fig = get_figure(_make_circular_sector_chart())
        assert isinstance(fig, go.Figure)


class TestXyTrace:
    """XY layer should produce a Scatter trace with correct data."""

    def test_trace_is_scatter(self):
        fig = get_figure(_make_cartesian_xy_chart())
        assert len(fig.data) == 1
        trace = fig.data[0]
        assert isinstance(trace, go.Scatter)

    def test_trace_x_data(self):
        fig = get_figure(_make_cartesian_xy_chart())
        trace = fig.data[0]
        assert list(trace.x) == [1, 2, 3]

    def test_trace_y_data(self):
        fig = get_figure(_make_cartesian_xy_chart())
        trace = fig.data[0]
        assert list(trace.y) == [10, 20, 30]


class TestBarTrace:
    """Bar layer should produce a Bar trace."""

    def test_trace_is_bar(self):
        fig = get_figure(_make_cartesian_bar_chart())
        assert len(fig.data) == 1
        trace = fig.data[0]
        assert isinstance(trace, go.Bar)


class TestSectorTrace:
    """Sector layer should produce a Pie trace."""

    def test_trace_is_pie(self):
        fig = get_figure(_make_circular_sector_chart())
        assert len(fig.data) == 1
        trace = fig.data[0]
        assert isinstance(trace, go.Pie)


class TestEmptyChart:
    """An empty chart (no facets) should return an empty figure."""

    def test_empty_chart_returns_empty_figure(self):
        chart = Chart()
        fig = get_figure(chart)
        assert isinstance(fig, go.Figure)
        assert len(fig.data) == 0


class TestMultiFacetChart:
    """Multi-facet chart should produce the correct number of traces."""

    def test_trace_count(self):
        fig = get_figure(_make_multi_facet_chart())
        assert len(fig.data) == 2


class TestLegendVisibility:
    """Legend show/hide should be reflected in the figure layout."""

    def test_legend_shown_by_default(self):
        chart = _make_cartesian_xy_chart()
        fig = get_figure(chart)
        assert fig.layout.showlegend is True

    def test_legend_hidden(self):
        from vcti.chart import LegendConfig

        chart = _make_cartesian_xy_chart()
        chart.legend = LegendConfig(show=False)
        fig = get_figure(chart)
        assert fig.layout.showlegend is False
