# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for CoordSysType enum, WithCoordSys protocol, and MatchingCoordSysPolicy."""

import pytest

from vcti.chart import CoordSysType, WithCoordSys, MatchingCoordSysPolicy


class TestCoordSysType:
    """Tests for CoordSysType enum values."""

    def test_cartesian_value(self):
        assert CoordSysType.CARTESIAN.value == "cartesian"

    def test_circular_value(self):
        assert CoordSysType.CIRCULAR.value == "circular"

    def test_member_count(self):
        assert len(CoordSysType) == 2

    def test_lookup_by_value(self):
        assert CoordSysType("cartesian") is CoordSysType.CARTESIAN
        assert CoordSysType("circular") is CoordSysType.CIRCULAR

    def test_invalid_value_raises(self):
        with pytest.raises(ValueError):
            CoordSysType("polar")


class _FakeWithCoordSys:
    """Helper class that satisfies WithCoordSys protocol."""

    def __init__(self, coordsys: CoordSysType):
        self._coordsys = coordsys

    @property
    def coordsys(self) -> CoordSysType:
        return self._coordsys


class _NoCoordSys:
    """Helper class that does NOT satisfy WithCoordSys protocol."""
    pass


class TestWithCoordSys:
    """Tests for the WithCoordSys runtime-checkable protocol."""

    def test_conforming_object_is_instance(self):
        obj = _FakeWithCoordSys(CoordSysType.CARTESIAN)
        assert isinstance(obj, WithCoordSys)

    def test_non_conforming_object_is_not_instance(self):
        obj = _NoCoordSys()
        assert not isinstance(obj, WithCoordSys)


class TestMatchingCoordSysPolicy:
    """Tests for MatchingCoordSysPolicy.is_compatible()."""

    def test_compatible_cartesian(self):
        policy = MatchingCoordSysPolicy()
        item = _FakeWithCoordSys(CoordSysType.CARTESIAN)
        assert policy.is_compatible(item, CoordSysType.CARTESIAN) is True

    def test_compatible_circular(self):
        policy = MatchingCoordSysPolicy()
        item = _FakeWithCoordSys(CoordSysType.CIRCULAR)
        assert policy.is_compatible(item, CoordSysType.CIRCULAR) is True

    def test_incompatible_cartesian_vs_circular(self):
        policy = MatchingCoordSysPolicy()
        item = _FakeWithCoordSys(CoordSysType.CARTESIAN)
        assert policy.is_compatible(item, CoordSysType.CIRCULAR) is False

    def test_incompatible_circular_vs_cartesian(self):
        policy = MatchingCoordSysPolicy()
        item = _FakeWithCoordSys(CoordSysType.CIRCULAR)
        assert policy.is_compatible(item, CoordSysType.CARTESIAN) is False
