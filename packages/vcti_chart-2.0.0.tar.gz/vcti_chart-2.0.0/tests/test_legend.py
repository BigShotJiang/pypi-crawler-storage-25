# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for LegendConfig."""

from vcti.chart import LegendConfig


class TestLegendConfigDefaults:
    """Tests for LegendConfig default values."""

    def test_default_show_is_true(self):
        legend = LegendConfig()
        assert legend.show is True


class TestLegendConfigCustom:
    """Tests for LegendConfig with custom values."""

    def test_show_false(self):
        legend = LegendConfig(show=False)
        assert legend.show is False

    def test_show_true_explicit(self):
        legend = LegendConfig(show=True)
        assert legend.show is True
