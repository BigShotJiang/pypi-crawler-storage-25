# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for ScaleType enum."""

import pytest

from vcti.chart import ScaleType


class TestScaleType:
    """Tests for ScaleType enum values and membership."""

    def test_linear_value(self):
        assert ScaleType.LINEAR.value == "linear"

    def test_logarithmic_value(self):
        assert ScaleType.LOGARITHMIC.value == "logarithmic"

    def test_member_count(self):
        assert len(ScaleType) == 2

    def test_members_are_unique(self):
        values = [member.value for member in ScaleType]
        assert len(values) == len(set(values))

    def test_lookup_by_value(self):
        assert ScaleType("linear") is ScaleType.LINEAR
        assert ScaleType("logarithmic") is ScaleType.LOGARITHMIC

    def test_invalid_value_raises(self):
        with pytest.raises(ValueError):
            ScaleType("exponential")

    def test_identity(self):
        assert ScaleType.LINEAR is not ScaleType.LOGARITHMIC
