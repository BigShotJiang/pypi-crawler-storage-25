# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for VariableInfo and Variable."""

import pytest

from vcti.chart import VariableInfo, Variable, DataArray, ScaleType


class TestVariableInfo:
    """Tests for VariableInfo creation, defaults, and create_default()."""

    def test_creation_with_name_only(self):
        info = VariableInfo(name="Temperature")
        assert info.name == "Temperature"
        assert info.unit is None
        assert info.range is None
        assert info.scale is ScaleType.LINEAR
        assert info.description is None

    def test_creation_with_all_fields(self):
        info = VariableInfo(
            name="Pressure",
            unit="Pa",
            range=(0.0, 1000.0),
            scale=ScaleType.LOGARITHMIC,
            description="Atmospheric pressure",
        )
        assert info.name == "Pressure"
        assert info.unit == "Pa"
        assert info.range == (0.0, 1000.0)
        assert info.scale is ScaleType.LOGARITHMIC
        assert info.description == "Atmospheric pressure"

    def test_create_default(self):
        info = VariableInfo.create_default("velocity")
        assert info.name == "velocity"
        assert info.unit is None
        assert info.scale is ScaleType.LINEAR

    def test_name_is_required(self):
        with pytest.raises(Exception):
            VariableInfo()


class TestVariable:
    """Tests for Variable creation with and without values."""

    def test_creation_with_values_and_metadata(self):
        values = DataArray([1.0, 2.0, 3.0])
        meta = VariableInfo(name="Temperature", unit="C")
        var = Variable("temp", values=values, metadata=meta)
        assert var.id == "temp"
        assert var.values is values
        assert var.metadata.name == "Temperature"
        assert var.metadata.unit == "C"

    def test_creation_without_values(self):
        var = Variable("empty_var")
        assert var.id == "empty_var"
        assert var.values is None

    def test_default_metadata_from_id(self):
        var = Variable("speed")
        assert var.metadata.name == "speed"

    def test_creation_with_explicit_metadata(self):
        meta = VariableInfo(name="Custom Name", unit="m/s")
        var = Variable("v", metadata=meta)
        assert var.metadata.name == "Custom Name"
        assert var.metadata.unit == "m/s"

    def test_repr(self):
        var = Variable("x", values=DataArray([1, 2, 3]))
        r = repr(var)
        assert "x" in r
        assert "3" in r


class TestVariableRoundTrip:
    """Tests for Variable to_dict() / from_dict() serialisation round-trip."""

    def test_round_trip_with_values(self):
        values = DataArray([10, 20, 30])
        meta = VariableInfo(name="Temperature", unit="K", scale=ScaleType.LINEAR)
        var = Variable("temp", values=values, metadata=meta)

        d = var.to_dict()
        restored = Variable.from_dict(d)

        assert restored.id == "temp"
        assert restored.values.to_list() == [10, 20, 30]
        assert restored.metadata.name == "Temperature"
        assert restored.metadata.unit == "K"

    def test_round_trip_without_values(self):
        var = Variable("empty")
        d = var.to_dict()
        restored = Variable.from_dict(d)

        assert restored.id == "empty"
        assert restored.values is None

    def test_to_dict_structure(self):
        var = Variable("x", values=DataArray([1, 2]))
        d = var.to_dict()
        assert "id" in d
        assert "values" in d
        assert "metadata" in d
        assert d["id"] == "x"
        assert d["values"] == [1, 2]
        assert isinstance(d["metadata"], dict)

    def test_to_dict_none_values(self):
        var = Variable("y")
        d = var.to_dict()
        assert d["values"] is None

    def test_from_dict_preserves_metadata_fields(self):
        d = {
            "id": "pressure",
            "values": [100.0, 200.0],
            "metadata": {
                "name": "Pressure",
                "unit": "Pa",
                "range": (0.0, 500.0),
                "scale": "logarithmic",
                "description": "Test pressure",
            },
        }
        var = Variable.from_dict(d)
        assert var.metadata.name == "Pressure"
        assert var.metadata.unit == "Pa"
        assert var.metadata.scale is ScaleType.LOGARITHMIC
        assert var.metadata.description == "Test pressure"
