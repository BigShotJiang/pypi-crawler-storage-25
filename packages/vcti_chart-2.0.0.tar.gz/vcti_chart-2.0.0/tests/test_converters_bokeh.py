# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for the Bokeh converter module."""

import pytest

bokeh = pytest.importorskip("bokeh", reason="bokeh not installed")

from bokeh.layouts import GridPlot
from bokeh.models import GlyphRenderer
from bokeh.models.glyphs import Line, VBar, AnnularWedge
from bokeh.plotting import figure as BokehFigure

from vcti.chart import (
    Chart, Facet, Panel, Variable, VariableInfo, DataArray,
    CoordSysType, XyLayer, BarLayer, SectorLayer,
    XyPlotConfig, BarPlotConfig, SectorPlotConfig,
    LineType, MarkerType,
)
from vcti.chart.converters.bokeh import chart_to_bokeh


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def _make_cartesian_xy_chart() -> Chart:
    """Chart with one CARTESIAN facet, one panel, one XyLayer."""
    chart = Chart()
    domain = Variable("x", DataArray([1, 2, 3]), VariableInfo(name="X"))
    facet = Facet(CoordSysType.CARTESIAN, domain_var=domain)
    range_var = Variable("y", metadata=VariableInfo(name="Y"))
    panel = Panel(CoordSysType.CARTESIAN, range_var=range_var)
    layer = XyLayer(values=DataArray([10, 20, 30]), config=XyPlotConfig())
    panel.layers.add("line1", layer)
    facet.panels.add("p1", panel)
    chart.facets.add("f1", facet)
    return chart


def _make_cartesian_bar_chart() -> Chart:
    """Chart with one CARTESIAN facet, one panel, one BarLayer."""
    chart = Chart()
    domain = Variable("cat", DataArray([1, 2, 3]), VariableInfo(name="Category"))
    facet = Facet(CoordSysType.CARTESIAN, domain_var=domain)
    range_var = Variable("val", metadata=VariableInfo(name="Value"))
    panel = Panel(CoordSysType.CARTESIAN, range_var=range_var)
    layer = BarLayer(values=DataArray([10, 20, 30]), config=BarPlotConfig())
    panel.layers.add("bar1", layer)
    facet.panels.add("p1", panel)
    chart.facets.add("f1", facet)
    return chart


def _make_circular_sector_chart() -> Chart:
    """Chart with one CIRCULAR facet, one panel, one SectorLayer."""
    chart = Chart()
    domain = Variable("label", DataArray(["A", "B", "C"]), VariableInfo(name="Label"))
    facet = Facet(CoordSysType.CIRCULAR, domain_var=domain)
    range_var = Variable("share", metadata=VariableInfo(name="Share"))
    panel = Panel(CoordSysType.CIRCULAR, range_var=range_var)
    layer = SectorLayer(
        values=DataArray([40, 35, 25]),
        config=SectorPlotConfig(colors=["red", "green", "blue"]),
    )
    panel.layers.add("sec1", layer)
    facet.panels.add("p1", panel)
    chart.facets.add("f1", facet)
    return chart


def _make_multi_facet_chart() -> Chart:
    """Chart with 2 CARTESIAN facets, each with one panel and one XyLayer."""
    chart = Chart()
    for i in range(2):
        domain = Variable(f"x{i}", DataArray([1, 2, 3]), VariableInfo(name=f"X{i}"))
        facet = Facet(CoordSysType.CARTESIAN, domain_var=domain)
        range_var = Variable(f"y{i}", metadata=VariableInfo(name=f"Y{i}"))
        panel = Panel(CoordSysType.CARTESIAN, range_var=range_var)
        layer = XyLayer(values=DataArray([10 + i, 20 + i, 30 + i]))
        panel.layers.add("line", layer)
        facet.panels.add("p", panel)
        chart.facets.add(f"f{i}", facet)
    return chart


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestChartToBokehReturnType:
    """chart_to_bokeh should return a Bokeh figure or layout."""

    def test_single_facet_returns_figure(self):
        result = chart_to_bokeh(_make_cartesian_xy_chart())
        # Single facet returns a Bokeh Figure (plotting figure)
        from bokeh.plotting import figure as _fig_func
        assert hasattr(result, "renderers")

    def test_bar_chart_returns_figure(self):
        result = chart_to_bokeh(_make_cartesian_bar_chart())
        assert hasattr(result, "renderers")


class TestXyLineRenderer:
    """XY layer should produce a line renderer."""

    def test_has_line_renderer(self):
        result = chart_to_bokeh(_make_cartesian_xy_chart())
        glyph_renderers = [
            r for r in result.renderers if isinstance(r, GlyphRenderer)
        ]
        line_renderers = [
            r for r in glyph_renderers if isinstance(r.glyph, Line)
        ]
        assert len(line_renderers) >= 1


class TestBarRenderer:
    """Bar layer should produce a vbar renderer."""

    def test_has_vbar_renderer(self):
        result = chart_to_bokeh(_make_cartesian_bar_chart())
        glyph_renderers = [
            r for r in result.renderers if isinstance(r, GlyphRenderer)
        ]
        bar_renderers = [
            r for r in glyph_renderers if isinstance(r.glyph, VBar)
        ]
        assert len(bar_renderers) >= 1


class TestSectorRenderer:
    """Circular/sector chart should produce wedge renderers and hide axes."""

    def test_has_annular_wedge_renderer(self):
        result = chart_to_bokeh(_make_circular_sector_chart())
        glyph_renderers = [
            r for r in result.renderers if isinstance(r, GlyphRenderer)
        ]
        wedge_renderers = [
            r for r in glyph_renderers if isinstance(r.glyph, AnnularWedge)
        ]
        assert len(wedge_renderers) >= 1

    def test_axes_hidden(self):
        result = chart_to_bokeh(_make_circular_sector_chart())
        for axis in result.axis:
            assert axis.visible is False


class TestEmptyChart:
    """An empty chart should return a gridplot."""

    def test_empty_chart_returns_gridplot(self):
        chart = Chart()
        result = chart_to_bokeh(chart)
        assert isinstance(result, GridPlot)


class TestMultiFacetChart:
    """Multi-facet chart should return a gridplot."""

    def test_returns_gridplot(self):
        result = chart_to_bokeh(_make_multi_facet_chart())
        assert isinstance(result, GridPlot)
