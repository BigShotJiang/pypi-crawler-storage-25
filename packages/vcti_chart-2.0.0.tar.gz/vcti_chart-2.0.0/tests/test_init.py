# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for vcti.chart package initialisation and public API."""

import re

import pytest


class TestVersion:
    """Tests for __version__ attribute."""

    def test_version_exists(self):
        from vcti.chart import __version__
        assert __version__ is not None

    def test_version_is_string(self):
        from vcti.chart import __version__
        assert isinstance(__version__, str)

    def test_version_format(self):
        from vcti.chart import __version__
        # Matches semver-like patterns: X.Y.Z, X.Y.Z.devN, X.Y.ZaN, etc.
        assert re.match(r"^\d+\.\d+", __version__), (
            f"Version {__version__!r} does not match expected format"
        )


class TestAllSymbols:
    """Tests for __all__ completeness."""

    def test_all_exists(self):
        import vcti.chart
        assert hasattr(vcti.chart, "__all__")

    def test_expected_symbols_in_all(self):
        from vcti.chart import __all__
        expected = [
            "__version__",
            # Scale
            "ScaleType",
            # Coordinate system
            "CoordSysType",
            "MatchingCoordSysPolicy",
            "WithCoordSys",
            # Data
            "ArrayData",
            "DataArray",
            # Axis
            "AxisType",
            "AxesAlignment",
            "AxisStyle",
            "AxesLayout",
            # Variable
            "VariableInfo",
            "Variable",
            # Layout and legend
            "LayoutConfig",
            "LegendConfig",
            # Layer types and configs
            "LayerType",
            "Layer",
            "LayerConfig",
            "LineType",
            "MarkerType",
            "AreaFillType",
            "XyPlotConfig",
            "XyLayer",
            "BarEdge",
            "BarPlotConfig",
            "BarLayer",
            "SectorPlotConfig",
            "SectorLayer",
            # Panel
            "CoordSysLayersPolicy",
            "Panel",
            # Facet
            "Facet",
            # Chart
            "Chart",
        ]
        for sym in expected:
            assert sym in __all__, f"{sym!r} missing from __all__"

    def test_all_symbols_are_importable(self):
        import vcti.chart
        for name in vcti.chart.__all__:
            assert hasattr(vcti.chart, name), f"{name!r} in __all__ but not importable"


class TestKeyImports:
    """Tests that key classes can be imported from vcti.chart."""

    def test_import_chart(self):
        from vcti.chart import Chart
        assert Chart is not None

    def test_import_facet(self):
        from vcti.chart import Facet
        assert Facet is not None

    def test_import_panel(self):
        from vcti.chart import Panel
        assert Panel is not None

    def test_import_xy_layer(self):
        from vcti.chart import XyLayer
        assert XyLayer is not None

    def test_import_bar_layer(self):
        from vcti.chart import BarLayer
        assert BarLayer is not None

    def test_import_sector_layer(self):
        from vcti.chart import SectorLayer
        assert SectorLayer is not None

    def test_import_data_array(self):
        from vcti.chart import DataArray
        assert DataArray is not None

    def test_import_variable(self):
        from vcti.chart import Variable, VariableInfo
        assert Variable is not None
        assert VariableInfo is not None

    def test_import_coordsys(self):
        from vcti.chart import CoordSysType
        assert CoordSysType is not None

    def test_import_layout_legend(self):
        from vcti.chart import LayoutConfig, LegendConfig
        assert LayoutConfig is not None
        assert LegendConfig is not None
