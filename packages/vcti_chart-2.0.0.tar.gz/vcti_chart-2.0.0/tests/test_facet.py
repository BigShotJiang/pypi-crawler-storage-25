# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for chart Facet."""

import pytest

from vcti.chart import (
    AxesAlignment,
    AxesLayout,
    AxisStyle,
    AxisType,
    CoordSysType,
    DataArray,
    Variable,
    VariableInfo,
    Panel,
    Facet,
    XyLayer,
    BarLayer,
    SectorLayer,
)


def _make_variable(var_id: str = "time", name: str = "Time",
                   unit: str = "s", values: list | None = None) -> Variable:
    """Create a Variable for testing."""
    data = DataArray(values) if values is not None else None
    return Variable(var_id, values=data, metadata=VariableInfo(name=name, unit=unit))


def _make_panel(coordsys: CoordSysType = CoordSysType.CARTESIAN,
                var_id: str = "temperature") -> Panel:
    """Create a Panel for testing."""
    range_var = _make_variable(var_id, var_id.capitalize())
    return Panel(coordsys, range_var=range_var)


def _make_facet(coordsys: CoordSysType = CoordSysType.CARTESIAN,
                **kwargs) -> Facet:
    """Create a Facet with a default domain variable."""
    domain_var = kwargs.pop("domain_var", _make_variable("time", "Time", "s",
                                                          [1, 2, 3]))
    return Facet(coordsys, domain_var=domain_var, **kwargs)


# -- Facet creation ------------------------------------------------------------


class TestFacetCreation:
    """Tests for Facet construction."""

    def test_coordsys_property(self):
        facet = _make_facet(CoordSysType.CARTESIAN)
        assert facet.coordsys == CoordSysType.CARTESIAN

    def test_domain_var_stored(self):
        domain = _make_variable("freq", "Frequency", "Hz", [100, 200])
        facet = Facet(CoordSysType.CARTESIAN, domain_var=domain)
        assert facet.domain_var.id == "freq"

    def test_panels_initially_empty(self):
        facet = _make_facet()
        assert len(facet.panels) == 0

    def test_default_axis_style(self):
        facet = _make_facet()
        assert facet.axis_style is not None
        assert isinstance(facet.axis_style, AxisStyle)

    def test_custom_axis_style(self):
        style = AxisStyle(label="Custom Domain", show_grid=False)
        facet = _make_facet(axis_style=style)
        assert facet.axis_style.label == "Custom Domain"
        assert facet.axis_style.show_grid is False


# -- Default axes layout -------------------------------------------------------


class TestFacetDefaultAxesLayout:
    """Tests for default axis_style and axes_layout based on coordsys."""

    def test_cartesian_default_index_axis(self):
        facet = _make_facet(CoordSysType.CARTESIAN)
        assert facet.axes_layout.index_axis == AxisType.X

    def test_cartesian_default_alignment(self):
        facet = _make_facet(CoordSysType.CARTESIAN)
        assert facet.axes_layout.value_axes_alignment == AxesAlignment.PARALLEL

    def test_circular_default_index_axis(self):
        facet = _make_facet(CoordSysType.CIRCULAR)
        assert facet.axes_layout.index_axis == AxisType.ANGULAR

    def test_circular_default_alignment(self):
        facet = _make_facet(CoordSysType.CIRCULAR)
        assert facet.axes_layout.value_axes_alignment == AxesAlignment.SERIAL

    def test_custom_axes_layout(self):
        layout = AxesLayout(index_axis=AxisType.Y, value_axes_alignment=AxesAlignment.SERIAL)
        facet = _make_facet(axes_layout=layout)
        assert facet.axes_layout.index_axis == AxisType.Y
        assert facet.axes_layout.value_axes_alignment == AxesAlignment.SERIAL


# -- Adding panels -------------------------------------------------------------


class TestFacetAddPanels:
    """Tests for adding panels with matching and mismatching coordsys."""

    def test_add_matching_cartesian_panel(self):
        facet = _make_facet(CoordSysType.CARTESIAN)
        panel = _make_panel(CoordSysType.CARTESIAN)
        facet.panels.add("temp", panel)
        assert len(facet.panels) == 1

    def test_add_multiple_matching_panels(self):
        facet = _make_facet(CoordSysType.CARTESIAN)
        facet.panels.add("temp", _make_panel(CoordSysType.CARTESIAN, "temperature"))
        facet.panels.add("pres", _make_panel(CoordSysType.CARTESIAN, "pressure"))
        assert len(facet.panels) == 2

    def test_add_matching_circular_panel(self):
        facet = _make_facet(CoordSysType.CIRCULAR)
        panel = _make_panel(CoordSysType.CIRCULAR)
        facet.panels.add("pie", panel)
        assert len(facet.panels) == 1

    def test_add_mismatching_panel_raises(self):
        facet = _make_facet(CoordSysType.CARTESIAN)
        panel = _make_panel(CoordSysType.CIRCULAR)
        with pytest.raises(ValueError):
            facet.panels.add("pie", panel)

    def test_add_circular_to_cartesian_facet_raises(self):
        facet = _make_facet(CoordSysType.CARTESIAN)
        panel = _make_panel(CoordSysType.CIRCULAR, "sector_var")
        with pytest.raises(ValueError):
            facet.panels.add("bad", panel)

    def test_add_cartesian_to_circular_facet_raises(self):
        facet = _make_facet(CoordSysType.CIRCULAR)
        panel = _make_panel(CoordSysType.CARTESIAN, "xy_var")
        with pytest.raises(ValueError):
            facet.panels.add("bad", panel)


# -- Facet serialisation -------------------------------------------------------


class TestFacetRoundTrip:
    """Tests for Facet to_dict()/from_dict() serialisation."""

    def test_round_trip_empty_facet(self):
        facet = _make_facet()
        d = facet.to_dict()
        restored = Facet.from_dict(d)
        assert restored.coordsys == CoordSysType.CARTESIAN
        assert restored.domain_var.id == "time"
        assert len(restored.panels) == 0

    def test_round_trip_with_panels(self):
        facet = _make_facet()
        panel = _make_panel(CoordSysType.CARTESIAN, "temperature")
        panel.layers.add("line1", XyLayer(DataArray([1, 2]), DataArray([10, 20])))
        facet.panels.add("temp", panel)

        d = facet.to_dict()
        restored = Facet.from_dict(d)

        assert restored.coordsys == CoordSysType.CARTESIAN
        assert len(restored.panels) == 1

    def test_round_trip_preserves_domain_var_values(self):
        domain = _make_variable("time", "Time", "s", [10, 20, 30])
        facet = Facet(CoordSysType.CARTESIAN, domain_var=domain)

        d = facet.to_dict()
        restored = Facet.from_dict(d)

        assert restored.domain_var.values is not None
        assert restored.domain_var.values.to_list() == [10, 20, 30]

    def test_round_trip_preserves_axes_layout(self):
        layout = AxesLayout(index_axis=AxisType.Y, value_axes_alignment=AxesAlignment.SERIAL)
        facet = _make_facet(axes_layout=layout)

        d = facet.to_dict()
        restored = Facet.from_dict(d)

        assert restored.axes_layout.index_axis == AxisType.Y
        assert restored.axes_layout.value_axes_alignment == AxesAlignment.SERIAL

    def test_round_trip_preserves_axis_style(self):
        style = AxisStyle(label="Frequency (Hz)", font_size=16)
        facet = _make_facet(axis_style=style)

        d = facet.to_dict()
        restored = Facet.from_dict(d)

        assert restored.axis_style.label == "Frequency (Hz)"
        assert restored.axis_style.font_size == 16

    def test_dict_has_coordsys_key(self):
        d = _make_facet().to_dict()
        assert d["coordsys"] == "cartesian"
