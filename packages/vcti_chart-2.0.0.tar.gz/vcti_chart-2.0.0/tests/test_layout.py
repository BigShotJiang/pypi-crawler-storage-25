# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for LayoutConfig."""

import pytest
from pydantic import ValidationError

from vcti.chart import LayoutConfig


class TestLayoutConfigDefaults:
    """Tests for LayoutConfig default values."""

    def test_default_items_per_row(self):
        layout = LayoutConfig()
        assert layout.items_per_row == 4


class TestLayoutConfigCustom:
    """Tests for LayoutConfig with custom values."""

    def test_custom_items_per_row(self):
        layout = LayoutConfig(items_per_row=2)
        assert layout.items_per_row == 2

    def test_items_per_row_one(self):
        layout = LayoutConfig(items_per_row=1)
        assert layout.items_per_row == 1

    def test_large_items_per_row(self):
        layout = LayoutConfig(items_per_row=100)
        assert layout.items_per_row == 100


class TestLayoutConfigValidation:
    """Tests for LayoutConfig pydantic validation."""

    def test_zero_items_per_row_raises(self):
        with pytest.raises(ValidationError):
            LayoutConfig(items_per_row=0)

    def test_negative_items_per_row_raises(self):
        with pytest.raises(ValidationError):
            LayoutConfig(items_per_row=-1)
