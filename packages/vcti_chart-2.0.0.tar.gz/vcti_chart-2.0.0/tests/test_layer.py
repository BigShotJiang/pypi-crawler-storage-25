# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for chart layer types, configs, and serialisation."""

import pytest

from vcti.chart import (
    DataArray,
    LayerType,
    Layer,
    LayerConfig,
    LineType,
    MarkerType,
    AreaFillType,
    XyPlotConfig,
    XyLayer,
    BarEdge,
    BarPlotConfig,
    BarLayer,
    SectorPlotConfig,
    SectorLayer,
)


class TestLayerType:
    """Tests for LayerType enum values."""

    def test_xy_value(self):
        assert LayerType.XY.value == "xy"

    def test_bar_value(self):
        assert LayerType.BAR.value == "bar"

    def test_sector_value(self):
        assert LayerType.SECTOR.value == "sector"

    def test_all_members(self):
        assert set(LayerType) == {LayerType.XY, LayerType.BAR, LayerType.SECTOR}


# -- XyLayer -----------------------------------------------------------------


class TestXyLayerDefaults:
    """Tests for XyLayer creation with default config."""

    def test_type_is_xy(self):
        layer = XyLayer()
        assert layer.type == LayerType.XY

    def test_default_config_line_solid(self):
        layer = XyLayer()
        assert layer.config.line_type == LineType.SOLID

    def test_default_config_marker_none(self):
        layer = XyLayer()
        assert layer.config.marker_type == MarkerType.NONE

    def test_default_config_area_fill_none(self):
        layer = XyLayer()
        assert layer.config.area_fill_type == AreaFillType.NONE

    def test_default_index_is_none(self):
        layer = XyLayer()
        assert layer.index is None

    def test_default_values_is_none(self):
        layer = XyLayer()
        assert layer.values is None


class TestXyLayerCustomConfig:
    """Tests for XyLayer creation with custom config."""

    def test_with_data(self):
        idx = DataArray([1, 2, 3])
        vals = DataArray([10, 20, 30])
        layer = XyLayer(index=idx, values=vals)
        assert layer.index.to_list() == [1, 2, 3]
        assert layer.values.to_list() == [10, 20, 30]

    def test_with_scatter_config(self):
        cfg = XyPlotConfig(line_type=LineType.NONE, marker_type=MarkerType.CIRCLE)
        layer = XyLayer(config=cfg)
        assert layer.config.line_type == LineType.NONE
        assert layer.config.marker_type == MarkerType.CIRCLE

    def test_with_area_fill_config(self):
        cfg = XyPlotConfig(line_type=LineType.SOLID, area_fill_type=AreaFillType.FILLED)
        layer = XyLayer(config=cfg)
        assert layer.config.area_fill_type == AreaFillType.FILLED

    def test_with_colors(self):
        cfg = XyPlotConfig(line_color="#FF0000", marker_type=MarkerType.SQUARE,
                           marker_color="#00FF00")
        layer = XyLayer(config=cfg)
        assert layer.config.line_color == "#FF0000"
        assert layer.config.marker_color == "#00FF00"


class TestXyLayerProperties:
    """Tests for XyLayer convenience properties."""

    def test_line_enabled_default(self):
        layer = XyLayer()
        assert layer.line_enabled is True

    def test_line_enabled_false(self):
        cfg = XyPlotConfig(line_type=LineType.NONE, marker_type=MarkerType.CIRCLE)
        layer = XyLayer(config=cfg)
        assert layer.line_enabled is False

    def test_marker_enabled_default(self):
        layer = XyLayer()
        assert layer.marker_enabled is False

    def test_marker_enabled_true(self):
        cfg = XyPlotConfig(marker_type=MarkerType.DIAMOND)
        layer = XyLayer(config=cfg)
        assert layer.marker_enabled is True

    def test_area_fill_enabled_default(self):
        layer = XyLayer()
        assert layer.area_fill_enabled is False

    def test_area_fill_enabled_true(self):
        cfg = XyPlotConfig(area_fill_type=AreaFillType.GRADIENT)
        layer = XyLayer(config=cfg)
        assert layer.area_fill_enabled is True


class TestXyLayerRoundTrip:
    """Tests for XyLayer to_dict()/from_dict() serialisation."""

    def test_round_trip_with_data(self):
        idx = DataArray([1.0, 2.0, 3.0])
        vals = DataArray([10.0, 20.0, 30.0])
        cfg = XyPlotConfig(line_type=LineType.DASHED, marker_type=MarkerType.TRIANGLE)
        layer = XyLayer(index=idx, values=vals, config=cfg)

        d = layer.to_dict()
        restored = Layer.from_dict(d)

        assert isinstance(restored, XyLayer)
        assert restored.index.to_list() == [1.0, 2.0, 3.0]
        assert restored.values.to_list() == [10.0, 20.0, 30.0]
        assert restored.config.line_type == LineType.DASHED
        assert restored.config.marker_type == MarkerType.TRIANGLE

    def test_round_trip_no_data(self):
        layer = XyLayer()
        d = layer.to_dict()
        restored = Layer.from_dict(d)
        assert isinstance(restored, XyLayer)
        assert restored.index is None
        assert restored.values is None

    def test_dict_has_class_key(self):
        d = XyLayer().to_dict()
        assert d["class"] == "XyLayer"
        assert d["type"] == "xy"


class TestXyPlotConfigValidation:
    """Tests for XyPlotConfig validation rules."""

    def test_both_none_raises(self):
        with pytest.raises(ValueError, match="line_type or marker_type"):
            XyPlotConfig(line_type=LineType.NONE, marker_type=MarkerType.NONE)

    def test_area_fill_without_line_raises(self):
        with pytest.raises(ValueError, match="Area fill requires a visible line"):
            XyPlotConfig(
                line_type=LineType.NONE,
                marker_type=MarkerType.CIRCLE,
                area_fill_type=AreaFillType.FILLED,
            )

    def test_valid_scatter_only(self):
        cfg = XyPlotConfig(line_type=LineType.NONE, marker_type=MarkerType.CIRCLE)
        assert cfg.line_type == LineType.NONE

    def test_valid_line_only(self):
        cfg = XyPlotConfig(line_type=LineType.SOLID, marker_type=MarkerType.NONE)
        assert cfg.marker_type == MarkerType.NONE


# -- BarLayer -----------------------------------------------------------------


class TestBarLayerDefaults:
    """Tests for BarLayer creation with default config."""

    def test_type_is_bar(self):
        layer = BarLayer()
        assert layer.type == LayerType.BAR

    def test_default_mode(self):
        layer = BarLayer()
        assert layer.config.mode == "group"

    def test_default_color(self):
        layer = BarLayer()
        assert layer.config.color == "#4CAF50"

    def test_default_width(self):
        layer = BarLayer()
        assert layer.config.width == 0.8

    def test_default_edge(self):
        layer = BarLayer()
        assert layer.config.edge.color == "black"
        assert layer.config.edge.width == 1.0


class TestBarLayerCustomConfig:
    """Tests for BarLayer creation with custom config."""

    def test_with_data(self):
        idx = DataArray(["A", "B", "C"])
        vals = DataArray([10, 20, 30])
        layer = BarLayer(index=idx, values=vals)
        assert layer.index.to_list() == ["A", "B", "C"]
        assert layer.values.to_list() == [10, 20, 30]

    def test_custom_mode(self):
        cfg = BarPlotConfig(mode="stack")
        layer = BarLayer(config=cfg)
        assert layer.config.mode == "stack"

    def test_custom_color_and_width(self):
        cfg = BarPlotConfig(color="#FF5733", width=0.5)
        layer = BarLayer(config=cfg)
        assert layer.config.color == "#FF5733"
        assert layer.config.width == 0.5

    def test_custom_edge(self):
        edge = BarEdge(color="red", width=2.0)
        cfg = BarPlotConfig(edge=edge)
        layer = BarLayer(config=cfg)
        assert layer.config.edge.color == "red"
        assert layer.config.edge.width == 2.0


class TestBarLayerRoundTrip:
    """Tests for BarLayer to_dict()/from_dict() serialisation."""

    def test_round_trip_with_data(self):
        idx = DataArray(["X", "Y", "Z"])
        vals = DataArray([5, 15, 25])
        cfg = BarPlotConfig(mode="stack", color="#123456", width=0.6)
        layer = BarLayer(index=idx, values=vals, config=cfg)

        d = layer.to_dict()
        restored = Layer.from_dict(d)

        assert isinstance(restored, BarLayer)
        assert restored.index.to_list() == ["X", "Y", "Z"]
        assert restored.values.to_list() == [5, 15, 25]
        assert restored.config.mode == "stack"
        assert restored.config.color == "#123456"
        assert restored.config.width == 0.6

    def test_dict_has_class_key(self):
        d = BarLayer().to_dict()
        assert d["class"] == "BarLayer"
        assert d["type"] == "bar"


class TestBarPlotConfigValidation:
    """Tests for BarPlotConfig validation rules."""

    def test_width_zero_raises(self):
        with pytest.raises(ValueError):
            BarPlotConfig(width=0.0)

    def test_width_negative_raises(self):
        with pytest.raises(ValueError):
            BarPlotConfig(width=-0.1)

    def test_width_exceeds_one_raises(self):
        with pytest.raises(ValueError):
            BarPlotConfig(width=1.1)

    def test_width_exactly_one_accepted(self):
        cfg = BarPlotConfig(width=1.0)
        assert cfg.width == 1.0

    def test_overlay_mode_accepted(self):
        cfg = BarPlotConfig(mode="overlay")
        assert cfg.mode == "overlay"


# -- SectorLayer --------------------------------------------------------------


class TestSectorLayerDefaults:
    """Tests for SectorLayer creation with default config."""

    def test_type_is_sector(self):
        layer = SectorLayer()
        assert layer.type == LayerType.SECTOR

    def test_default_start_angle(self):
        layer = SectorLayer()
        assert layer.config.start_angle == 0.0

    def test_default_end_angle(self):
        layer = SectorLayer()
        assert layer.config.end_angle == 360.0

    def test_default_inner_radius(self):
        layer = SectorLayer()
        assert layer.config.inner_radius is None

    def test_default_colors_empty(self):
        layer = SectorLayer()
        assert layer.config.colors == []


class TestSectorLayerCustomConfig:
    """Tests for SectorLayer creation with custom config."""

    def test_donut_config(self):
        cfg = SectorPlotConfig(inner_radius=0.4)
        layer = SectorLayer(config=cfg)
        assert layer.config.inner_radius == 0.4

    def test_custom_colors(self):
        cfg = SectorPlotConfig(colors=["#FF0000", "#00FF00", "#0000FF"])
        layer = SectorLayer(config=cfg)
        assert layer.config.colors == ["#FF0000", "#00FF00", "#0000FF"]

    def test_custom_angles(self):
        cfg = SectorPlotConfig(start_angle=90.0, end_angle=270.0)
        layer = SectorLayer(config=cfg)
        assert layer.config.start_angle == 90.0
        assert layer.config.end_angle == 270.0

    def test_with_data(self):
        idx = DataArray(["A", "B", "C"])
        vals = DataArray([40, 35, 25])
        layer = SectorLayer(index=idx, values=vals)
        assert layer.index.to_list() == ["A", "B", "C"]
        assert layer.values.to_list() == [40, 35, 25]


class TestSectorLayerRoundTrip:
    """Tests for SectorLayer to_dict()/from_dict() serialisation."""

    def test_round_trip_with_data(self):
        idx = DataArray(["P", "Q", "R"])
        vals = DataArray([50, 30, 20])
        cfg = SectorPlotConfig(inner_radius=0.3, colors=["red", "green", "blue"])
        layer = SectorLayer(index=idx, values=vals, config=cfg)

        d = layer.to_dict()
        restored = Layer.from_dict(d)

        assert isinstance(restored, SectorLayer)
        assert restored.index.to_list() == ["P", "Q", "R"]
        assert restored.values.to_list() == [50, 30, 20]
        assert restored.config.inner_radius == 0.3
        assert restored.config.colors == ["red", "green", "blue"]

    def test_dict_has_class_key(self):
        d = SectorLayer().to_dict()
        assert d["class"] == "SectorLayer"
        assert d["type"] == "sector"


class TestSectorPlotConfigValidation:
    """Tests for SectorPlotConfig validation rules."""

    def test_end_angle_less_than_start_raises(self):
        with pytest.raises(ValueError, match="end_angle.*must be greater"):
            SectorPlotConfig(start_angle=180.0, end_angle=90.0)

    def test_end_angle_equal_to_start_raises(self):
        with pytest.raises(ValueError, match="end_angle.*must be greater"):
            SectorPlotConfig(start_angle=180.0, end_angle=180.0)

    def test_valid_partial_arc(self):
        cfg = SectorPlotConfig(start_angle=0.0, end_angle=180.0)
        assert cfg.start_angle == 0.0
        assert cfg.end_angle == 180.0


# -- Layer.from_dict dispatch -------------------------------------------------


class TestLayerFromDictDispatch:
    """Tests for Layer.from_dict() dispatching to correct subclass."""

    def test_dispatch_xy_layer(self):
        data = XyLayer(DataArray([1]), DataArray([2])).to_dict()
        restored = Layer.from_dict(data)
        assert isinstance(restored, XyLayer)

    def test_dispatch_bar_layer(self):
        data = BarLayer(DataArray(["A"]), DataArray([10])).to_dict()
        restored = Layer.from_dict(data)
        assert isinstance(restored, BarLayer)

    def test_dispatch_sector_layer(self):
        data = SectorLayer(DataArray(["X"]), DataArray([50])).to_dict()
        restored = Layer.from_dict(data)
        assert isinstance(restored, SectorLayer)

    def test_unknown_class_raises(self):
        data = {"class": "UnknownLayer", "type": "xy", "index": None,
                "values": None, "config": {}}
        with pytest.raises(ValueError, match="Unknown layer class"):
            Layer.from_dict(data)
