# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
"""Tests for the Chart top-level container."""

import pytest

from vcti.chart import (
    Chart,
    CoordSysType,
    DataArray,
    Facet,
    LayoutConfig,
    LegendConfig,
    Panel,
    Variable,
    VariableInfo,
    XyLayer,
    XyPlotConfig,
    BarLayer,
    SectorLayer,
    SectorPlotConfig,
    LineType,
    MarkerType,
)


def _make_variable(var_id: str = "time", name: str = "Time",
                   unit: str = "s", values: list | None = None) -> Variable:
    """Create a Variable for testing."""
    data = DataArray(values) if values is not None else None
    return Variable(var_id, values=data, metadata=VariableInfo(name=name, unit=unit))


def _make_panel(coordsys: CoordSysType = CoordSysType.CARTESIAN,
                var_id: str = "temperature") -> Panel:
    """Create a Panel for testing."""
    range_var = _make_variable(var_id, var_id.capitalize())
    return Panel(coordsys, range_var=range_var)


def _make_facet(coordsys: CoordSysType = CoordSysType.CARTESIAN) -> Facet:
    """Create a Facet with a default domain variable."""
    domain = _make_variable("time", "Time", "s", [1, 2, 3])
    return Facet(coordsys, domain_var=domain)


def _make_full_chart() -> Chart:
    """Build a complete chart with facet, panel, and layers."""
    chart = Chart(
        layout=LayoutConfig(items_per_row=2),
        legend=LegendConfig(show=True),
    )

    # Cartesian facet with XY and bar layers
    facet1 = _make_facet(CoordSysType.CARTESIAN)
    panel1 = _make_panel(CoordSysType.CARTESIAN, "temperature")
    panel1.layers.add("line1", XyLayer(
        DataArray([1.0, 2.0, 3.0]),
        DataArray([20.0, 25.0, 22.0]),
        XyPlotConfig(line_type=LineType.DASHED, marker_type=MarkerType.CIRCLE),
    ))
    panel1.layers.add("bar1", BarLayer(
        DataArray(["A", "B", "C"]),
        DataArray([10, 20, 15]),
    ))
    facet1.panels.add("temp", panel1)

    panel2 = _make_panel(CoordSysType.CARTESIAN, "pressure")
    panel2.layers.add("line2", XyLayer(
        DataArray([1.0, 2.0, 3.0]),
        DataArray([101.3, 100.8, 102.1]),
    ))
    facet1.panels.add("pres", panel2)
    chart.facets.add("f1", facet1)

    return chart


# -- Chart creation ------------------------------------------------------------


class TestChartCreation:
    """Tests for Chart construction."""

    def test_default_layout(self):
        chart = Chart()
        assert chart.layout.items_per_row == 4

    def test_default_legend(self):
        chart = Chart()
        assert chart.legend.show is True

    def test_custom_layout(self):
        chart = Chart(layout=LayoutConfig(items_per_row=2))
        assert chart.layout.items_per_row == 2

    def test_custom_legend(self):
        chart = Chart(legend=LegendConfig(show=False))
        assert chart.legend.show is False

    def test_facets_initially_empty(self):
        chart = Chart()
        assert len(chart.facets) == 0


# -- Adding facets -------------------------------------------------------------


class TestChartAddFacets:
    """Tests for adding facets to a chart."""

    def test_add_single_facet(self):
        chart = Chart()
        facet = _make_facet()
        chart.facets.add("f1", facet)
        assert len(chart.facets) == 1

    def test_add_multiple_facets(self):
        chart = Chart()
        chart.facets.add("f1", _make_facet(CoordSysType.CARTESIAN))
        chart.facets.add("f2", _make_facet(CoordSysType.CIRCULAR))
        assert len(chart.facets) == 2

    def test_duplicate_facet_id_raises(self):
        chart = Chart()
        chart.facets.add("f1", _make_facet())
        with pytest.raises(KeyError):
            chart.facets.add("f1", _make_facet())


# -- Chart.__len__ -------------------------------------------------------------


class TestChartLen:
    """Tests for Chart.__len__()."""

    def test_empty_chart_len(self):
        chart = Chart()
        assert len(chart) == 0

    def test_chart_len_with_facets(self):
        chart = Chart()
        chart.facets.add("f1", _make_facet())
        chart.facets.add("f2", _make_facet())
        assert len(chart) == 2


# -- Chart serialisation -------------------------------------------------------


class TestChartRoundTrip:
    """Tests for Chart to_dict()/from_dict() serialisation."""

    def test_round_trip_empty_chart(self):
        chart = Chart()
        d = chart.to_dict()
        restored = Chart.from_dict(d)
        assert len(restored) == 0
        assert restored.layout.items_per_row == 4
        assert restored.legend.show is True

    def test_round_trip_custom_layout_legend(self):
        chart = Chart(
            layout=LayoutConfig(items_per_row=3),
            legend=LegendConfig(show=False),
        )
        d = chart.to_dict()
        restored = Chart.from_dict(d)
        assert restored.layout.items_per_row == 3
        assert restored.legend.show is False

    def test_round_trip_full_chart(self):
        chart = _make_full_chart()
        d = chart.to_dict()
        restored = Chart.from_dict(d)

        # Top-level
        assert len(restored) == 1
        assert restored.layout.items_per_row == 2
        assert restored.legend.show is True

    def test_round_trip_preserves_facet_order(self):
        chart = Chart()
        chart.facets.add("alpha", _make_facet())
        chart.facets.add("beta", _make_facet())
        chart.facets.add("gamma", _make_facet())

        d = chart.to_dict()
        assert d["facet_order"] == ["alpha", "beta", "gamma"]

        restored = Chart.from_dict(d)
        assert restored.facets.ids() == ["alpha", "beta", "gamma"]

    def test_round_trip_preserves_panels_and_layers(self):
        chart = _make_full_chart()
        d = chart.to_dict()
        restored = Chart.from_dict(d)

        # Verify facet "f1" has panels
        facet_data = d["facets"]["f1"]
        assert "temp" in facet_data["panels"]
        assert "pres" in facet_data["panels"]

        # Verify layers in "temp" panel
        temp_layers = facet_data["panels"]["temp"]["layers"]
        assert "line1" in temp_layers
        assert "bar1" in temp_layers

    def test_round_trip_preserves_layer_data(self):
        chart = _make_full_chart()
        d = chart.to_dict()
        restored = Chart.from_dict(d)

        # Dig into the restored structure
        f1_dict = d["facets"]["f1"]
        line1_dict = f1_dict["panels"]["temp"]["layers"]["line1"]
        assert line1_dict["values"] == [20.0, 25.0, 22.0]
        assert line1_dict["class"] == "XyLayer"

    def test_dict_has_required_keys(self):
        chart = _make_full_chart()
        d = chart.to_dict()
        assert "facets" in d
        assert "facet_order" in d
        assert "layout" in d
        assert "legend" in d
