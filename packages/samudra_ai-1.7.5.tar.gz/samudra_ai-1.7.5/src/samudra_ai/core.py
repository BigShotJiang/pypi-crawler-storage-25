# File: src/samudra_ai/core.py
import os
import json
import joblib
import logging
import xarray as xr
import numpy as np
from tensorflow.keras.models import load_model as keras_load_model
from tensorflow.keras.layers import LeakyReLU
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

from .models import build_cnn_bilstm, ModelConfig
from .model2 import build_convlstm2d, ModelConfig2
from .utils import NumpyEncoder, save_to_netcdf
from .data_loader import load_and_mask_dataset
from .trainer import prepare_training_data, plot_training_history
from .evaluator import evaluate_model, plot_spatial_comparison
from .utils import add_seasonal_features, apply_log_transform, inverse_log_transform
from .utils import align_time_if_needed

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class SamudraAI:
    def __init__(
        self,
        time_seq: int = 9,
        lstm_units: int = 64,
        learning_rate: float = 3e-4,
        config: ModelConfig = None,
        use_log: bool = False,
        use_seasonal: bool = False,
        mode: str = None
    ):
        self.time_seq = time_seq
        self.lstm_units = lstm_units
        self.learning_rate = learning_rate
        self.config = config

        # =========================
        # MODE PRIORITY
        # =========================
        if mode == "harian":
            self.use_log = True
            self.use_seasonal = True
        else:
            # backward compatibility
            self.use_log = use_log
            self.use_seasonal = use_seasonal

        self.mode = mode
        self.model = None
        self.scaler_X = None
        self.scaler_y = None
        self.history = None
        self.obs_for_metadata = None

    @staticmethod
    def _apply_scaler_safely(X, scaler):
        """
        Clean version for StandardScaler ONLY (recommended)
        """
        X_flat = X.reshape(X.shape[0], -1)
        return scaler.transform(X_flat).reshape(X.shape)
    
    def _squeeze_channel(self, da):
        if isinstance(da, xr.DataArray) and "channel" in da.dims:
            da = da.squeeze("channel", drop=True)
        return da

    def fit(self, x_data_hist: xr.DataArray, y_data_obs: xr.DataArray, epochs: int = 100, batch_size: int = 8, test_size: float = 0.2, seed: int = 42):
        logger.info("🧠 Memulai training model CNN-BiLSTM...")
        self.obs_for_metadata = y_data_obs.copy(deep=True)

        # ✅ bersihkan dari awal
        if "channel" in self.obs_for_metadata.dims:
            self.obs_for_metadata = self.obs_for_metadata.squeeze("channel", drop=True)

        # =========================
        # TIME ALIGNMENT (NEW)
        # =========================

        x_data_hist, y_data_obs = align_time_if_needed(
            x_data_hist,
            y_data_obs,
            mode=self.mode or "bulanan")

        # =========================
        # STEP 1 - AFTER SEASONAL
        # =========================
        if self.use_seasonal:
            x_data_hist = add_seasonal_features(x_data_hist)

        self.n_input_channels = x_data_hist.sizes.get("channel", 1)

        self.feature_mode = {
            "use_log": self.use_log,
            "use_seasonal": self.use_seasonal
        }

        if self.use_log:
            x_data_hist = xr.apply_ufunc(apply_log_transform, x_data_hist)
            y_data_obs = xr.apply_ufunc(apply_log_transform, y_data_obs)
        
        # =========================
        # TRAINER
        # =========================
        X_train, X_test, y_train, y_test, scaler_X, scaler_y = prepare_training_data(
            x_data_hist, y_data_obs, self.time_seq, seed, config=self.config
        )
        self.scaler_X = scaler_X
        self.scaler_y = scaler_y

        input_shape = X_train.shape[1:]
        output_shape = y_train.shape[1:3]

        # ✅ pakai config custom kalau ada, kalau tidak build default
        if self.config is None:
            self.config = ModelConfig(rnn_units=self.lstm_units, learning_rate=self.learning_rate)

        self.model = build_cnn_bilstm(input_shape, output_shape, self.config)
        self.model.summary()

        callbacks = [EarlyStopping(patience=10, restore_best_weights=True), ReduceLROnPlateau(patience=5, verbose=1)]
        self.history = self.model.fit(
            X_train, y_train, epochs=epochs, batch_size=batch_size,
            validation_data=(X_test, y_test), callbacks=callbacks, verbose=1
        )

        loss, mae = self.model.evaluate(X_test, y_test, verbose=0)
        logger.info(f"✅ Training selesai -> Final Val Loss (MSE): {loss:.4f}, Final Val MAE: {mae:.4f}")

    def correction(self, data_to_correct: xr.DataArray, save_path: str = None) -> xr.DataArray:
        if not all([self.model, self.scaler_X, self.scaler_y, self.obs_for_metadata is not None]):
            raise RuntimeError("Model belum dilatih. Jalankan .fit() terlebih dahulu.")

        logger.info(f"🔬 Mengoreksi data dengan shape: {data_to_correct.shape}...")

        # =========================
        # FIX DIM ANEH (CRITICAL)
        # =========================
        for d in data_to_correct.dims:
            if data_to_correct.sizes[d] == 1 and d != "time":
                data_to_correct = data_to_correct.squeeze(d)

        # =========================
        # 1. FEATURE ENGINEERING (CONSISTENT WITH TRAINING)
        # =========================
        if self.use_seasonal:
            data_to_correct = add_seasonal_features(data_to_correct)

        # =========================
        # 2. CONVERT TO NUMPY
        # =========================
        X_future = data_to_correct.fillna(0).values

        # SAFE DIMENSION NORMALIZATION
        if X_future.ndim == 3:
            # asumsi: (time, lat, lon)
            X_future = X_future[..., np.newaxis]

        elif X_future.ndim != 4:
            raise ValueError(f"Unexpected shape: {X_future.shape}")

        expected_channels = self.n_input_channels

        if X_future.shape[-1] != expected_channels:
            logger.warning(f"Channel mismatch: expected={expected_channels}, got={X_future.shape[-1]}")

        # =========================
        # 4. OPTIONAL LOG
        # =========================
        if self.use_log:
            X_future = apply_log_transform(X_future)

        # =========================
        # 5. SCALING
        # =========================
        X_future_scaled = self._apply_scaler_safely(X_future, self.scaler_X)

        # =========================
        # 6. BUILD SEQUENCES
        # =========================
        n_time = X_future_scaled.shape[0]

        if n_time < self.time_seq:
            raise ValueError(
                f"❌ Not enough time steps: {n_time} < {self.time_seq}"
            )
        
        if "time" not in data_to_correct.dims:
            raise ValueError("Input must contain time dimension")

        time_values = data_to_correct.time.values

        seq_indices = [
            (i, i + self.time_seq)
            for i in range(len(X_future_scaled) - self.time_seq + 1)
        ]

        X_future_seq = np.array([
            X_future_scaled[start:end]
            for start, end in seq_indices
        ])

        valid_time = np.array([
            time_values[end - 1] for _, end in seq_indices
        ])

        # =========================
        # 7. MODEL INPUT CHECK
        # =========================
        if len(valid_time) != len(X_future_seq):
            raise ValueError("Mismatch time vs sequence")

        # =========================
        # STRICT SHAPE VALIDATION (IMPORTANT)
        # =========================
        expected_channels = self.n_input_channels

        if X_future_seq.ndim not in [4, 5]:
            raise ValueError(f"Invalid ndim: {X_future_seq.shape}")

        # kalau belum ada channel dim
        if X_future_seq.ndim == 4:
            # (batch, time, lat, lon)
            X_future_seq = X_future_seq[..., np.newaxis]

        # kalau sudah 5D tapi channel mismatch
        if X_future_seq.shape[-1] != expected_channels:
            raise ValueError(
                f"Channel mismatch: expected {expected_channels}, got {X_future_seq.shape[-1]}"
            )
            
        # =========================
        # 8. PREDICT
        # =========================
        pred_scaled = self.model.predict(X_future_seq, batch_size=1)

        # =========================
        # FIX OUTPUT CHANNEL
        # =========================
        if pred_scaled.ndim == 4:
            pred_scaled = np.squeeze(pred_scaled, axis=-1)

        flat_pred = pred_scaled.reshape(pred_scaled.shape[0], -1)

        # =========================
        # 9. INVERSE SCALE
        # =========================
        pred_original = self.scaler_y.inverse_transform(flat_pred)

        # =========================
        # 10. INVERSE LOG
        # =========================
        if self.use_log:
            pred_original = inverse_log_transform(pred_original)

        # =========================
        # 11. RESHAPE OUTPUT
        # =========================
        obs_shape = self.obs_for_metadata.isel(time=0).shape

        pred_original = pred_original.reshape((pred_scaled.shape[0], *obs_shape))

        # ✅ FIX OUTPUT DIM
        if pred_original.ndim == 4 and pred_original.shape[-1] == 1:
            pred_original = np.squeeze(pred_original, axis=-1)

        # =========================
        # 12. BUILD DATAARRAY
        # =========================
        obs_mask = self.obs_for_metadata.isel(time=0).notnull()

        # ✅ FIX MASK DIM (WAJIB)
        if "channel" in obs_mask.dims:
            obs_mask = obs_mask.squeeze("channel")

        lat_dim_name = next((d for d in obs_mask.dims if 'lat' in d.lower()), 'lat')
        lon_dim_name = next((d for d in obs_mask.dims if 'lon' in d.lower()), 'lon')

        if set(obs_mask.dims) != {lat_dim_name, lon_dim_name}:
            raise ValueError(f"Unexpected mask dims: {obs_mask.dims}")

        obs_mask = obs_mask.transpose(lat_dim_name, lon_dim_name)

        predicted_da = xr.DataArray(
            pred_original,
            coords={
                "time": valid_time,
                lat_dim_name: obs_mask.coords[lat_dim_name],
                lon_dim_name: obs_mask.coords[lon_dim_name]
            },
            dims=["time", lat_dim_name, lon_dim_name],
            name="corrected"
        )

        # =========================
        # 13. MASKING
        # =========================
        predicted_masked = predicted_da.where(obs_mask, drop=False)

        # =========================
        # 14. SAVE
        # =========================
        if save_path:
            save_to_netcdf(predicted_masked, save_path)

        logger.info("✅ Koreksi selesai.")
        return predicted_masked

    def evaluate_and_plot(
        self,
        raw_gcm_data: xr.DataArray,
        ref_data: xr.DataArray,
        var_name_ref: str,
        output_dir: str = "hasil_evaluasi",
        save_corrected_path: str = None,
        mask_type: str = None):
        
        corrected_data = self.correction(raw_gcm_data)

        corrected_data = self._squeeze_channel(corrected_data)
        raw_gcm_data = self._squeeze_channel(raw_gcm_data)
        ref_data = self._squeeze_channel(ref_data)

        # Debug log hasil prediksi
        try:
            min_val = np.nanmin(corrected_data.values)
            max_val = np.nanmax(corrected_data.values)
            print(f"✅ Hasil koreksi -> min: {min_val:.4f}, max: {max_val:.4f}, shape: {corrected_data.shape}")
        except Exception as e:
            print("⚠️ Gagal menghitung min/max hasil koreksi:", e)

        # Auto-trim obs agar cocok dengan hasil koreksi
        if "time" in ref_data.dims:
            ref_data = ref_data.sel(time=corrected_data.time)

        # Simpan hasil koreksi jika diminta
        if save_corrected_path:
            save_to_netcdf(corrected_data, save_corrected_path)

        # === Plot spasial perbandingan ===
        spatial_path = plot_spatial_comparison(
            corrected_da=corrected_data,
            raw_gcm_da=raw_gcm_data,
            ref_da=ref_data,
            var_name=var_name_ref,
            output_dir=output_dir,
            units=ref_data.attrs.get("units", ""),
            mask_type=mask_type 
        )
        logger.info(f"🌍 Peta spasial disimpan ke: {spatial_path}")

        return evaluate_model(ref_data, raw_gcm_data, corrected_data, var_name_ref, output_dir)

    def plot_history(self, output_dir: str = None):
        if not self.history:
            raise ValueError("Model belum dilatih.")
        plot_training_history(self.history, output_dir)

    def save(self, path: str):
        logger.info(f"💾 Menyimpan model ke direktori: {path}...")
        os.makedirs(path, exist_ok=True)

        # Simpan model dan scaler
        self.model.save(os.path.join(path, "model.keras"))
        joblib.dump(self.scaler_X, os.path.join(path, "scaler_X.gz"))
        joblib.dump(self.scaler_y, os.path.join(path, "scaler_y.gz"))

        # Simpan metadata observasi dengan backend yang lebih stabil
        try:
            self.obs_for_metadata.to_netcdf(
                os.path.join(path, "obs_metadata.nc"),
                engine="h5netcdf"
            )
        except Exception as e:
            logger.warning(f"❗ Gagal menyimpan obs_metadata.nc: {e}")

        # Simpan konfigurasi model
        config = {
            'time_seq': self.time_seq,
            'lstm_units': self.lstm_units,
            'learning_rate': self.learning_rate,
            'use_log': self.use_log,
            'use_seasonal': self.use_seasonal,
            'mode': self.mode
        }

        with open(os.path.join(path, "config.json"), 'w') as f:
            json.dump(config, f, cls=NumpyEncoder)

        logger.info(f"✅ Model dan komponen berhasil disimpan.")

    @classmethod
    def load(cls, path: str):
        logger.info(f"🔄 Memuat model dari direktori: {path}...")
        required_files = ["config.json", "model.keras", "scaler_X.gz", "scaler_y.gz", "obs_metadata.nc"]
        for fname in required_files:
            full_path = os.path.join(path, fname)
            if not os.path.exists(full_path):
                raise FileNotFoundError(f"File tidak ditemukan: {full_path}")

        with open(os.path.join(path, "config.json"), 'r') as f:
            config = json.load(f)
        instance = cls(
            time_seq=config.get("time_seq", 9),
            lstm_units=config.get("lstm_units", 64),
            learning_rate=config.get("learning_rate", 3e-4),
            use_log=config.get("use_log", False),
            use_seasonal=config.get("use_seasonal", False),
            mode=config.get("mode", None)
        )
        instance.model = keras_load_model(
            os.path.join(path, "model.keras"),
            custom_objects={"LeakyReLU": LeakyReLU},
            compile=False)
        instance.scaler_X = joblib.load(os.path.join(path, "scaler_X.gz"))
        instance.scaler_y = joblib.load(os.path.join(path, "scaler_y.gz"))
        instance.obs_for_metadata = xr.open_dataarray(os.path.join(path, "obs_metadata.nc"))
        instance.model.compile(
            optimizer=Adam(learning_rate=instance.learning_rate),
            loss='mse',
            metrics=['mae'])
        logger.info(f"✅ Model dan komponen berhasil dimuat.")
        return instance
    
class SamudraAI2:
    def __init__(self, time_seq: int = 9, config: ModelConfig2 = None,
                 use_log: bool = False, use_seasonal: bool = False, mode: str = None):
        self.time_seq = time_seq
        self.config = config
        self.use_log = use_log
        # =========================
        # MODE PRIORITY
        # =========================
        if mode == "harian":
            self.use_log = True
            self.use_seasonal = True
        else:
            # backward compatibility
            self.use_log = use_log
            self.use_seasonal = use_seasonal
        self.mode = mode
        self.model = None
        self.scaler_X = None
        self.scaler_y = None
        self.history = None
        self.obs_for_metadata = None

    @staticmethod
    def _apply_scaler_safely(X, scaler):
        """
        Clean version for StandardScaler ONLY (recommended)
        """
        X_flat = X.reshape(X.shape[0], -1)
        return scaler.transform(X_flat).reshape(X.shape)
    
    def _squeeze_channel(self, da):
        if isinstance(da, xr.DataArray) and "channel" in da.dims:
            da = da.squeeze("channel", drop=True)
        return da

    def fit(self, x_data_hist, y_data_obs, epochs: int = None, batch_size: int = None, test_size: float = 0.2, seed: int = 42):
        logger.info("🧠 Memulai training model ConvLSTM2D...")
        self.obs_for_metadata = y_data_obs.copy(deep=True)

        # ✅ bersihkan dari awal
        if "channel" in self.obs_for_metadata.dims:
            self.obs_for_metadata = self.obs_for_metadata.squeeze("channel", drop=True)

        # =========================
        # TIME ALIGNMENT (NEW)
        # =========================
        x_data_hist, y_data_obs = align_time_if_needed(
            x_data_hist,
            y_data_obs,
            mode=self.mode or "bulanan")

        # =========================
        # STEP 1 - AFTER SEASONAL
        # =========================
        if self.use_seasonal:
            x_data_hist = add_seasonal_features(x_data_hist)

        self.n_input_channels = x_data_hist.sizes.get("channel", 1)

        self.feature_mode = {
            "use_log": self.use_log,
            "use_seasonal": self.use_seasonal
        }

        if self.use_log:
            x_data_hist = xr.apply_ufunc(apply_log_transform, x_data_hist)
            y_data_obs = xr.apply_ufunc(apply_log_transform, y_data_obs)

        # =========================
        # TRAINER
        # =========================
        X_train, X_test, y_train, y_test, scaler_X, scaler_y = prepare_training_data(
            x_data_hist, y_data_obs, self.time_seq, seed, config=self.config
        )
        self.scaler_X, self.scaler_y = scaler_X, scaler_y

        input_shape = X_train.shape[1:]    # (time_seq, lat, lon, 1)
        output_shape = y_train.shape[1:3]  # (lat, lon)

        if self.config is None:
            self.config = ModelConfig2()

        self.model = build_convlstm2d(input_shape, output_shape, self.config)
        self.model.summary()

        callbacks = [EarlyStopping(patience=10, restore_best_weights=True), ReduceLROnPlateau(patience=5, verbose=1)]
        self.history = self.model.fit(
            X_train, y_train,
            epochs=epochs or self.config.epochs,
            batch_size=batch_size or self.config.batch_size,
            validation_data=(X_test, y_test),
            callbacks=callbacks, verbose=1
        )

    def correction(self, data_to_correct: xr.DataArray, save_path: str = None) -> xr.DataArray:
        if not all([self.model, self.scaler_X, self.scaler_y, self.obs_for_metadata is not None]):
            raise RuntimeError("Model belum dilatih. Jalankan .fit() terlebih dahulu.")

        logger.info(f"🔬 Mengoreksi data dengan shape: {data_to_correct.shape}...")

        # =========================
        # FIX DIM ANEH (CRITICAL)
        # =========================
        for d in data_to_correct.dims:
            if data_to_correct.sizes[d] == 1 and d != "time":
                data_to_correct = data_to_correct.squeeze(d)

        # =========================
        # 1. FEATURE ENGINEERING (CONSISTENT WITH TRAINING)
        # =========================
        if self.use_seasonal:
            data_to_correct = add_seasonal_features(data_to_correct)

        # =========================
        # 2. CONVERT TO NUMPY
        # =========================
        X_future = data_to_correct.fillna(0).values

        if X_future.ndim == 3:
            X_future = X_future[..., np.newaxis]
        elif X_future.ndim != 4:
            raise ValueError(f"Unexpected shape: {X_future.shape}")

        expected_channels = self.n_input_channels

        if X_future.shape[-1] != expected_channels:
            raise ValueError(
                f"Channel mismatch! expected={expected_channels}, got={X_future.shape[-1]}"
            )

        # =========================
        # 4. OPTIONAL LOG
        # =========================
        if self.use_log:
            X_future = apply_log_transform(X_future)

        # =========================
        # 5. SCALING
        # =========================
        X_future_scaled = self._apply_scaler_safely(X_future, self.scaler_X)

        # ✅ FIX INI DI SINI
        if X_future_scaled.ndim == 3:
            X_future_scaled = X_future_scaled[..., np.newaxis]

        # =========================
        # 6. VALIDASI DASAR
        # =========================
        if "time" not in data_to_correct.dims:
            raise ValueError("Input must contain time dimension")

        n_time = X_future_scaled.shape[0]

        if n_time < self.time_seq:
            raise ValueError(
                f"❌ Not enough time steps: {n_time} < {self.time_seq}"
            )

        time_values = data_to_correct.time.values

        # =========================
        # 7. BUILD SEQUENCE WINDOW
        # =========================

        X_future_seq = np.stack([
            X_future_scaled[i:i + self.time_seq]
            for i in range(n_time - self.time_seq + 1)
        ])

        valid_time = time_values[self.time_seq - 1:]

        # =========================
        # FORCE 5D SAFETY (CRITICAL FOR CONVLSTM2D)
        # =========================
        if X_future_seq.ndim == 4:
            X_future_seq = X_future_seq[..., np.newaxis]

        # =========================
        # 9. CHANNEL SAFETY CHECK (IMPORTANT)
        # =========================
        expected_channels = self.n_input_channels

        if X_future_seq.shape[-1] != expected_channels:
            raise ValueError(
                f"Channel mismatch: expected={expected_channels}, "
                f"got={X_future_seq.shape[-1]}"
            )
            
        # =========================
        # 10. FINAL DEBUG
        # =========================
        print("🧪 ConvLSTM2D input shape:", X_future_seq.shape)

        # =========================
        # 8. PREDICT
        # =========================
        pred_scaled = self.model.predict(X_future_seq, batch_size=1)

        # =========================
        # FIX OUTPUT CHANNEL
        # =========================
        if pred_scaled.ndim == 4:
            pred_scaled = np.squeeze(pred_scaled, axis=-1)

        flat_pred = pred_scaled.reshape(pred_scaled.shape[0], -1)

        # =========================
        # 9. INVERSE SCALE
        # =========================
        pred_original = self.scaler_y.inverse_transform(flat_pred)

        # =========================
        # 10. INVERSE LOG
        # =========================
        if self.use_log:
            pred_original = inverse_log_transform(pred_original)

        # =========================
        # 11. RESHAPE OUTPUT
        # =========================
        obs_shape = self.obs_for_metadata.isel(time=0).shape

        pred_original = pred_original.reshape((pred_scaled.shape[0], *obs_shape))

        # ✅ FIX OUTPUT DIM
        if pred_original.ndim == 4 and pred_original.shape[-1] == 1:
            pred_original = np.squeeze(pred_original, axis=-1)

        # =========================
        # 12. BUILD DATAARRAY
        # =========================
        obs_mask = self.obs_for_metadata.isel(time=0).notnull()

        # ✅ FIX MASK DIM (WAJIB)
        if "channel" in obs_mask.dims:
            obs_mask = obs_mask.squeeze("channel")

        lat_dim_name = next((d for d in obs_mask.dims if 'lat' in d.lower()), 'lat')
        lon_dim_name = next((d for d in obs_mask.dims if 'lon' in d.lower()), 'lon')

        if set(obs_mask.dims) != {lat_dim_name, lon_dim_name}:
            raise ValueError(f"Unexpected mask dims: {obs_mask.dims}")

        obs_mask = obs_mask.transpose(lat_dim_name, lon_dim_name)

        predicted_da = xr.DataArray(
            pred_original,
            coords={
                "time": valid_time,
                lat_dim_name: obs_mask.coords[lat_dim_name],
                lon_dim_name: obs_mask.coords[lon_dim_name]
            },
            dims=["time", lat_dim_name, lon_dim_name],
            name="corrected"
        )

        # =========================
        # 13. MASKING
        # =========================
        predicted_masked = predicted_da.where(obs_mask, drop=False)

        # =========================
        # 14. SAVE
        # =========================
        if save_path:
            save_to_netcdf(predicted_masked, save_path)

        logger.info("✅ Koreksi selesai.")
        return predicted_masked

    def evaluate_and_plot(
        self,
        raw_gcm_data: xr.DataArray,
        ref_data: xr.DataArray,
        var_name_ref: str,
        output_dir: str = "hasil_evaluasi",
        save_corrected_path: str = None,
        mask_type: str = None):

        logger.info("📊 Evaluasi model dengan data referensi...")
        
        corrected_data = self.correction(raw_gcm_data)

        corrected_data = self._squeeze_channel(corrected_data)
        raw_gcm_data = self._squeeze_channel(raw_gcm_data)
        ref_data = self._squeeze_channel(ref_data)

        # Debug log hasil prediksi
        try:
            min_val = np.nanmin(corrected_data.values)
            max_val = np.nanmax(corrected_data.values)
            print(f"✅ Hasil koreksi -> min: {min_val:.4f}, max: {max_val:.4f}, shape: {corrected_data.shape}")
        except Exception as e:
            print("⚠️ Gagal menghitung min/max hasil koreksi:", e)

        # Auto-trim obs agar cocok dengan hasil koreksi
        if "time" in ref_data.dims:
            ref_data = ref_data.sel(time=corrected_data.time)

        # Simpan hasil koreksi jika diminta
        if save_corrected_path:
            save_to_netcdf(corrected_data, save_corrected_path)

        # === Plot spasial perbandingan ===
        spatial_path = plot_spatial_comparison(
            corrected_da=corrected_data,
            raw_gcm_da=raw_gcm_data,
            ref_da=ref_data,
            var_name=var_name_ref,
            output_dir=output_dir,
            units=ref_data.attrs.get("units", ""),
            mask_type=mask_type 
        )
        logger.info(f"🌍 Peta spasial disimpan ke: {spatial_path}")

        return evaluate_model(ref_data, raw_gcm_data, corrected_data, var_name_ref, output_dir)

    def plot_history(self, output_dir: str = None):
        if not self.history:
            raise ValueError("Model belum dilatih.")
        plot_training_history(self.history, output_dir)

    def save(self, path: str):
        logger.info(f"💾 Menyimpan model ke direktori: {path}...")
        os.makedirs(path, exist_ok=True)

        # Simpan model dan scaler
        self.model.save(os.path.join(path, "model2.keras"))
        joblib.dump(self.scaler_X, os.path.join(path, "scaler_X2.gz"))
        joblib.dump(self.scaler_y, os.path.join(path, "scaler_y2.gz"))

        # Simpan metadata observasi dengan backend yang lebih stabil
        try:
            self.obs_for_metadata.to_netcdf(
                os.path.join(path, "obs_metadata2.nc"),
                engine="h5netcdf"
            )
        except Exception as e:
            logger.warning(f"❗ Gagal menyimpan obs_metadata.nc: {e}")

        # Simpan konfigurasi model
        config = {
            "time_seq": self.time_seq,
            "use_log": self.use_log,
            'use_seasonal': self.use_seasonal,
            'mode': self.mode,
            "model_config": self.config.__dict__
        }
        with open(os.path.join(path, "config2.json"), 'w') as f:
            json.dump(config, f, cls=NumpyEncoder)

        logger.info(f"✅ Model dan komponen berhasil disimpan.")

    @classmethod
    def load(cls, path: str):
        logger.info(f"🔄 Memuat model dari direktori: {path}...")

        # =====================================
        # Validate required files
        # =====================================
        required_files = [
            "config2.json",
            "model2.keras",
            "scaler_X2.gz",
            "scaler_y2.gz",
            "obs_metadata2.nc"
        ]

        for fname in required_files:
            full_path = os.path.join(path, fname)
            if not os.path.exists(full_path):
                raise FileNotFoundError(f"❌ File tidak ditemukan: {full_path}")

        # =====================================
        # Load config
        # =====================================
        with open(os.path.join(path, "config2.json"), "r") as f:
            config = json.load(f)

        # SamudraAI2 hanya butuh time_seq & config ModelConfig2
        cfg = ModelConfig2(**config["model_config"])
        instance = cls(
            time_seq=config["time_seq"],
            config=cfg,
            use_log=config.get("use_log", False),
            use_seasonal=config.get("use_seasonal", False),
            mode=config.get("mode", None)
        )

        # =====================================
        # Load model
        # =====================================
        model_path = os.path.join(path, "model2.keras")

        instance.model = keras_load_model(
            model_path,
            custom_objects={"LeakyReLU": LeakyReLU},
            compile=False
        )

        # =====================================
        # Load scalers
        # =====================================
        instance.scaler_X = joblib.load(os.path.join(path, "scaler_X2.gz"))
        instance.scaler_y = joblib.load(os.path.join(path, "scaler_y2.gz"))

        # =====================================
        # Load metadata
        # =====================================
        instance.obs_for_metadata = xr.open_dataarray(
            os.path.join(path, "obs_metadata2.nc")
        )

        # =====================================
        # Compile safely
        # =====================================
        instance.model.compile(
            optimizer=Adam(),   # SamudraAI2 tidak punya learning_rate sendiri
            loss="mse",
            metrics=["mae"]
        )

        logger.info("✅ Model CONVLSTM2D dan komponen berhasil dimuat.")
        return instance