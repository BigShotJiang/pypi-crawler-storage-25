# src/samudra_ai/utils.py

import json
import numpy as np
import xarray as xr
import pandas as pd
import datetime
import cftime
from sklearn.metrics import mean_absolute_error

def add_seasonal_features(da: xr.DataArray, scale_factor: float = 1.0) -> xr.DataArray:
    """
    Add seasonal encoding (sin/cos month) as extra channel.

    OUTPUT FORMAT (STRICT):
        (time, lat, lon, channel)

    channel:
        0 = original data
        1 = sin(month)
        2 = cos(month)
    """

    # =========================
    # ENSURE BASE FORMAT
    # =========================
    if "channel" in da.dims:
        da = da.isel(channel=0)

    # jika masih 3D → expand channel
    da = da.expand_dims("channel")
    da = da.assign_coords(channel=[0])

    # =========================
    # TIME FEATURES
    # =========================
    month = da["time"].dt.month

    sin_month = np.sin(2 * np.pi * month / 12)
    cos_month = np.cos(2 * np.pi * month / 12)

    # =========================
    # BROADCAST KE GRID
    # =========================
    base = da.isel(channel=0)

    sin_da = xr.DataArray(sin_month, coords={"time": da.time}, dims=["time"])
    cos_da = xr.DataArray(cos_month, coords={"time": da.time}, dims=["time"])

    sin_da = xr.broadcast(sin_da, base)[0]
    cos_da = xr.broadcast(cos_da, base)[0]

    # =========================
    # ADD CHANNEL DIM
    # =========================
    sin_da = sin_da.expand_dims("channel").assign_coords(channel=[1]) * scale_factor
    cos_da = cos_da.expand_dims("channel").assign_coords(channel=[2]) * scale_factor

    # =========================
    # CONCAT
    # =========================
    out = xr.concat([da, sin_da, cos_da], dim="channel")

    # =========================
    # FORCE STANDARD ORDER
    # =========================
    out = out.transpose("time", "lat", "lon", "channel")

    return out

def apply_log_transform(x):
    return np.log1p(np.maximum(x, 0))

def inverse_log_transform(x, clip_max=15):
    if clip_max is not None:
        x = np.clip(x, None, clip_max)
    return np.maximum(np.expm1(x), 0)

def standardize_dims(da: xr.DataArray) -> xr.DataArray:
    da = da.copy()

    # =========================
    # DETECT CURVILINEAR
    # =========================
    is_curvilinear = (
        "lat" in da.coords and
        "lon" in da.coords and
        len(da["lat"].dims) == 2
    )

    # =========================
    # HANDLE REGULAR GRID
    # =========================
    if not is_curvilinear:
        rename_map = {}

        # standard names
        if "latitude" in da.dims:
            rename_map["latitude"] = "lat"
        if "longitude" in da.dims:
            rename_map["longitude"] = "lon"

        # fallback y/x → lat/lon (ONLY if safe)
        if "y" in da.dims and "lat" not in da.dims:
            rename_map["y"] = "lat"
        if "x" in da.dims and "lon" not in da.dims:
            rename_map["x"] = "lon"

        if rename_map:
            da = da.rename(rename_map)

        if "lat" not in da.dims or "lon" not in da.dims:
            print("⚠️ Skip standardize_dims: bukan regular grid")
            return da

        spatial_dims = ("lat", "lon")

    # =========================
    # HANDLE CURVILINEAR GRID
    # =========================
    else:
        print("⚠️ Curvilinear grid detected → using raw spatial dims")

        # ambil dim dari lat
        spatial_dims = da["lat"].dims  # biasanya (y,x)

        if len(spatial_dims) != 2:
            raise ValueError("❌ Curvilinear lat harus 2D")

    # =========================
    # VALIDASI DIM
    # =========================
    if "time" not in da.dims:
        raise ValueError("❌ Tidak ada dim 'time'")

    # =========================
    # DROP DIM LAIN (kalau ada)
    # =========================
    allowed_dims = ["time", *spatial_dims]

    extra_dims = [d for d in da.dims if d not in allowed_dims]

    if extra_dims:
        print(f"⚠️ Drop dim tambahan: {extra_dims}")
        da = da.isel({d: 0 for d in extra_dims})

    # =========================
    # ENSURE CHANNEL
    # =========================
    if "channel" not in da.dims:
        da = da.expand_dims("channel")
        da = da.assign_coords(channel=[0])

    # =========================
    # FINAL ORDER (FIXED)
    # =========================
    da = da.transpose("time", *spatial_dims, "channel")

    return da

def safe_time_convert(time_values):
    if isinstance(time_values[0], cftime.datetime):
        print("⚠️ CFTime detected in align_time → skip conversion")
        return time_values
    try:
        return pd.to_datetime(time_values).normalize()
    except Exception:
        print("⚠️ Fallback: keep original time")
        return time_values
    
def to_time_str(time_values, mode=None):

    def convert_one(t):

        # =========================
        # CASE 1: CFTime (AMAN)
        # =========================
        if isinstance(t, cftime.datetime):
            if mode == "harian":
                return f"{t.year:04d}-{t.month:02d}-{t.day:02d}"
            else:
                return f"{t.year:04d}-{t.month:02d}"

        # =========================
        # CASE 2: numpy.datetime64
        # =========================
        if isinstance(t, np.datetime64):
            ts = pd.Timestamp(t)
            if mode == "harian":
                return ts.strftime("%Y-%m-%d")
            else:
                return ts.strftime("%Y-%m")

        # =========================
        # CASE 3: python datetime
        # =========================
        if hasattr(t, "year") and hasattr(t, "month"):
            if mode == "harian":
                return f"{t.year:04d}-{t.month:02d}-{t.day:02d}"
            else:
                return f"{t.year:04d}-{t.month:02d}"

        # =========================
        # FALLBACK (STRING)
        # =========================
        t_str = str(t)
        return t_str[:10] if mode == "harian" else t_str[:7]

    return np.array([convert_one(t) for t in time_values])

def align_time_if_needed(gcm, obs, mode="bulanan"):
    gcm = gcm.copy()
    obs = obs.copy()

    # =========================
    # SORT (WAJIB)
    # =========================
    gcm = gcm.sortby("time")
    obs = obs.sortby("time")

    # =========================
    # STRING CONVERSION (CORE FIX)
    # =========================
    gcm_time_str = to_time_str(gcm.time.values, mode)
    obs_time_str = to_time_str(obs.time.values, mode)

    common = np.intersect1d(gcm_time_str, obs_time_str)

    print(f"🔍 COMMON TIME: {len(common)}")

    if len(common) == 0:
        raise ValueError("❌ No overlapping time found")

    gcm = gcm.isel(time=np.isin(gcm_time_str, common))
    obs = obs.isel(time=np.isin(obs_time_str, common))

    return gcm, obs

def compute_metrics(obs, model):
    """Menghitung metrik statistik antara data observasi dan model."""
    if isinstance(obs, xr.DataArray): obs = obs.values
    if isinstance(model, xr.DataArray): model = model.values
    obs_vals, model_vals = obs.flatten(), model.flatten()
    mask = ~np.isnan(obs_vals) & ~np.isnan(model_vals)
    obs_clean, model_clean = obs_vals[mask], model_vals[mask]
    if len(obs_clean) == 0: return np.nan, np.nan, np.nan, np.nan
    correlation = np.corrcoef(obs_clean, model_clean)[0, 1]
    rmse = np.sqrt(np.mean((model_clean - obs_clean) ** 2))
    bias = np.mean(model_clean - obs_clean)
    mae = mean_absolute_error(obs_clean, model_clean)
    return correlation, rmse, bias, mae

def save_to_netcdf(da: xr.DataArray, path: str, attrs: dict = None):
    """
    Simpan xarray.DataArray ke file NetCDF dengan atribut dan encoding standar.
    """
    da.name = da.name or "variable"
    da.attrs.update(attrs or {})
    da.attrs.setdefault("title", "Hasil Koreksi SAMUDRA-AI")
    da.attrs.setdefault("description", "Data hasil koreksi bias menggunakan CNN-BiLSTM")
    da.attrs.setdefault("history", f"Generated by SAMUDRA-AI on {datetime.datetime.now().isoformat()}")
    
    # Tambahkan encoding agar tidak terlalu besar (opsional)
    encoding = {
        da.name: {
            "zlib": True,
            "complevel": 4,
            "_FillValue": -9999.0,
        }
    }
    da.to_netcdf(path, encoding=encoding, engine="h5netcdf")
    print(f"💾 Data berhasil disimpan ke: {path}")

class NumpyEncoder(json.JSONEncoder):
    """ Kelas helper untuk encoding NumPy array ke JSON. """
    def default(self, obj):
        if isinstance(obj, np.generic):
            return obj.item()
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)