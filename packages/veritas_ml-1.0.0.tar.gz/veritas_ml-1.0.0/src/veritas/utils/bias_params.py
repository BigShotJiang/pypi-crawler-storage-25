"""Load protected attribute configuration for Veritas components."""

import json
import os
import sys
from pathlib import Path
from typing import Iterable, List, Optional, Tuple, Union

BIAS_PARAMS_FILE = "bias_params.json"

ProtectedAttributesInput = Optional[Union[str, Iterable[str]]]


def _candidate_bias_params_paths() -> List[Path]:
    """Return config locations in the order non-technical users expect."""
    candidates = [Path(os.getcwd()) / BIAS_PARAMS_FILE]

    main_module = sys.modules.get("__main__")
    main_file = getattr(main_module, "__file__", None)
    if main_file:
        candidates.append(Path(main_file).resolve().parent / BIAS_PARAMS_FILE)

    seen = set()
    unique_candidates = []
    for path in candidates:
        resolved = path.resolve()
        if resolved not in seen:
            unique_candidates.append(resolved)
            seen.add(resolved)
    return unique_candidates


def _normalise_protected_attributes(
    value: ProtectedAttributesInput,
    *,
    source: str,
) -> Optional[List[str]]:
    if value is None:
        return None

    if isinstance(value, str):
        attrs = [value]
    else:
        try:
            attrs = list(value)
        except TypeError as exc:
            raise ValueError(
                f"{source} must be a string or a list of protected attribute names."
            ) from exc

    cleaned = []
    for attr in attrs:
        if not isinstance(attr, str) or not attr.strip():
            raise ValueError(
                f"{source} must contain only non-empty string protected attribute names."
            )
        cleaned.append(attr.strip())

    return cleaned or None


def load_protected_attributes_from_bias_params() -> Tuple[Optional[List[str]], Optional[Path]]:
    """Load protected attributes from the nearest expected bias_params.json file."""
    for path in _candidate_bias_params_paths():
        if not path.exists():
            continue

        try:
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {path}: {exc}") from exc
        except OSError as exc:
            raise ValueError(f"Could not read {path}: {exc}") from exc

        if isinstance(data, list):
            protected = data
        elif isinstance(data, dict):
            protected = data.get("protected_attributes")
            if protected is None and "protected_attribute" in data:
                protected = data.get("protected_attribute")
        else:
            raise ValueError(
                f"{path} must contain an object with a 'protected_attributes' list."
            )

        attrs = _normalise_protected_attributes(
            protected,
            source=f"{path} protected_attributes",
        )
        if attrs is None:
            raise ValueError(
                f"{path} must define at least one protected attribute, for example "
                '{"protected_attributes": ["sex", "race"]}.'
            )
        return attrs, path

    return None, None


def resolve_protected_attributes(
    protected_attributes: ProtectedAttributesInput = None,
) -> Optional[List[str]]:
    """
    Resolve protected attributes from bias_params.json first, then constructor input.

    The package intentionally prefers the JSON file so application code can stay free
    of sensitive/protected attribute names.
    """
    attrs, _ = load_protected_attributes_from_bias_params()
    if attrs is not None:
        return attrs
    return _normalise_protected_attributes(
        protected_attributes,
        source="protected_attributes",
    )


def require_protected_attributes(
    protected_attributes: ProtectedAttributesInput = None,
) -> List[str]:
    """Resolve protected attributes or raise a user-friendly configuration error."""
    resolved = resolve_protected_attributes(protected_attributes)
    if resolved:
        return resolved

    searched = ", ".join(str(path) for path in _candidate_bias_params_paths())
    raise ValueError(
        "No protected attributes were configured. Create bias_params.json in the "
        "current working directory or beside your main Python script with content "
        'like {"protected_attributes": ["sex", "race"]}, or pass '
        "protected_attributes=[...] when constructing the Veritas class. "
        f"Searched: {searched}"
    )
