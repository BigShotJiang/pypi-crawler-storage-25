"""Tests for sklearn-compatible wrappers."""

import json
import os
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

from veritas import VeritasClassifier


@contextmanager
def bias_params_cwd(protected_attributes):
    previous = os.getcwd()
    with tempfile.TemporaryDirectory() as tmp:
        params_path = Path(tmp) / "bias_params.json"
        params_path.write_text(
            json.dumps({"protected_attributes": protected_attributes}),
            encoding="utf-8",
        )
        os.chdir(tmp)
        try:
            yield params_path
        finally:
            os.chdir(previous)


class TestVeritasClassifier(unittest.TestCase):
    """Test cases for VeritasClassifier."""

    def setUp(self):
        """Set up test data."""
        np.random.seed(42)
        self.X = np.random.randn(200, 5)
        self.y = np.random.randint(0, 2, 200)
        self.sensitive = np.random.choice(["A", "B"], 200)

    def test_initialization(self):
        """Test classifier can be initialized."""
        clf = VeritasClassifier(
            base_estimator=LogisticRegression(),
            protected_attribute="attr",
            run_audit=False
        )
        self.assertIsNotNone(clf.base_estimator)
        self.assertEqual(clf.protected_attribute, "attr")

    def test_fit_without_audit(self):
        """Test fitting without audit works."""
        with bias_params_cwd(["sex"]):
            clf = VeritasClassifier(
                base_estimator=LogisticRegression(max_iter=500),
                run_audit=False
            )
            clf.fit(self.X, self.y)
            self.assertIsNotNone(clf.estimator_)
            self.assertEqual(clf.protected_attributes, ["sex"])

    def test_predict_after_fit(self):
        """Test prediction works after fitting."""
        with bias_params_cwd(["sex"]):
            clf = VeritasClassifier(
                base_estimator=LogisticRegression(max_iter=500),
                run_audit=False
            )
            clf.fit(self.X, self.y)
            predictions = clf.predict(self.X[:10])
            self.assertEqual(len(predictions), 10)

    def test_has_bias_before_fit(self):
        """Test has_bias returns False before fitting."""
        with bias_params_cwd(["sex"]):
            clf = VeritasClassifier()
            self.assertFalse(clf.has_bias())

    def test_get_bias_report_before_fit(self):
        """Test get_bias_report returns None before fitting."""
        with bias_params_cwd(["sex"]):
            clf = VeritasClassifier()
            self.assertIsNone(clf.get_bias_report())

    def test_with_different_estimators(self):
        """Test works with different base estimators."""
        for estimator in [LogisticRegression(max_iter=500), RandomForestClassifier(n_estimators=10)]:
            with bias_params_cwd(["sex"]):
                clf = VeritasClassifier(
                    base_estimator=estimator,
                    run_audit=False
                )
                clf.fit(self.X, self.y)
                score = clf.score(self.X, self.y)
                self.assertGreaterEqual(score, 0)
                self.assertLessEqual(score, 1)

    def test_missing_protected_attributes_error(self):
        """Test a clear error is raised when neither JSON nor params exist."""
        with tempfile.TemporaryDirectory() as tmp:
            previous = os.getcwd()
            os.chdir(tmp)
            try:
                with self.assertRaisesRegex(ValueError, "bias_params.json"):
                    VeritasClassifier()
            finally:
                os.chdir(previous)


if __name__ == "__main__":
    unittest.main()
