# SPDX-License-Identifier: Apache-2.0
"""
MLX Model Runner for vLLM.

This module implements the model runner that bridges vLLM's request
handling with mlx-lm's inference capabilities.

Note: This is a vLLM v1 platform plugin shim. The real inference path
uses Scheduler.step() with mlx-lm's BatchGenerator, not this runner.
"""

import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

import mlx.core as mx

if TYPE_CHECKING:
    from vllm.config import VllmConfig
    from vllm.v1.core.sched.output import SchedulerOutput

logger = logging.getLogger(__name__)


@dataclass
class SamplerOutput:
    """Output from sampling."""

    token_ids: list[int]
    logprobs: list[dict] | None = None


@dataclass
class MLXModelRunnerOutput:
    """Output from MLX model runner, compatible with vLLM's ModelRunnerOutput."""

    # Request ID to sampled token IDs
    req_id_to_token_ids: dict[str, list[int]]

    # Request ID to logprobs (if requested)
    req_id_to_logprobs: dict[str, list[dict]] | None = None

    # Number of tokens generated
    num_tokens_generated: int = 0

    # Time taken for generation
    generation_time_s: float = 0.0


class MLXModelRunner:
    """
    Model runner that uses mlx-lm for inference (vLLM v1 compat shim).

    This class handles:
    - Model loading via mlx-lm
    - Converting vLLM requests to mlx-lm format
    - Hardware detection and cache spec calculation

    Note: The real inference path uses Scheduler.step() with BatchGenerator.
    This runner exists for vLLM platform plugin compatibility.
    """

    def __init__(self, vllm_config: "VllmConfig", enable_optimizations: bool = True):
        """
        Initialize MLX model runner.

        Args:
            vllm_config: vLLM configuration
            enable_optimizations: Whether to enable low-level optimizations
        """
        self.vllm_config = vllm_config
        self.model_config = vllm_config.model_config
        self.cache_config = vllm_config.cache_config
        self.scheduler_config = vllm_config.scheduler_config

        # mlx-lm model and tokenizer
        self.model = None
        self.tokenizer = None
        self._loaded = False

        # Cache for prompt processing
        self._prompt_cache = None

        # KV cache blocks
        self._num_cache_blocks = 0

        # Optimization settings
        self._enable_optimizations = enable_optimizations
        self._compiled_forward = None  # Compiled model forward pass
        self._hardware_info = None  # Detected hardware profile

        logger.info(f"MLXModelRunner initialized for model: {self.model_config.model}")
        logger.info(
            f"Low-level optimizations: {'ENABLED' if enable_optimizations else 'disabled'}"
        )

    def load_model(self) -> None:
        """Load model using mlx-lm with optimizations."""
        if self._loaded:
            return

        try:
            from mlx_lm import load

            model_name = self.model_config.model

            logger.info(f"Loading model with mlx-lm: {model_name}")
            start_time = time.time()

            self.model, self.tokenizer = load(
                model_name,
                tokenizer_config={
                    "trust_remote_code": self.model_config.trust_remote_code,
                },
            )

            load_time = time.time() - start_time
            logger.info(f"Model loaded in {load_time:.2f}s")

            self._loaded = True

            # Apply low-level optimizations
            if self._enable_optimizations:
                self._apply_optimizations()

        except ImportError:
            raise ImportError(
                "mlx-lm is required for MLX model runner. "
                "Install with: pip install mlx-lm"
            )
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            raise

    def _apply_optimizations(self) -> None:
        """Apply low-level optimizations for maximum performance."""
        try:
            from vmlx_engine.optimizations import detect_hardware

            # Detect hardware
            self._hardware_info = detect_hardware()
            logger.info(f"Hardware detected: {self._hardware_info.chip_name}")
            logger.info(f"Memory: {self._hardware_info.total_memory_gb:.1f} GB")
            logger.info(f"Bandwidth: {self._hardware_info.memory_bandwidth_gbs} GB/s")

            # Compile the model forward pass for kernel fusion
            self._setup_compiled_forward()

        except Exception as e:
            logger.warning(f"Failed to apply optimizations: {e}")

    def _setup_compiled_forward(self) -> None:
        """
        Setup compiled forward pass using mx.compile() for kernel fusion.

        This fuses multiple operations into single Metal kernels,
        reducing kernel launch overhead and improving throughput.
        """
        if self.model is None:
            return

        try:
            # Compile the model's __call__ method
            # This creates fused Metal kernels for the forward pass
            if hasattr(self.model, "__call__"):
                self._compiled_forward = mx.compile(self.model.__call__)
                logger.info("Compiled forward pass enabled (mx.compile kernel fusion)")
            else:
                logger.warning(
                    "Model does not have __call__ method, skipping compilation"
                )

        except Exception as e:
            logger.warning(f"Failed to compile forward pass: {e}")
            self._compiled_forward = None

    def initialize_cache(self, num_blocks: int) -> None:
        """Initialize KV cache."""
        self._num_cache_blocks = num_blocks
        logger.info(f"KV cache initialized with {num_blocks} blocks")

        # mlx-lm manages its own KV cache internally
        # We just track the configuration here

    def get_kv_cache_spec(self) -> dict:
        """Get KV cache specification."""
        return {
            "num_blocks": self._num_cache_blocks,
            "block_size": self.cache_config.block_size,
        }

    def get_cache_block_size_bytes(self) -> int:
        """Calculate cache block size in bytes."""
        if not self._loaded or self.model is None:
            return 0

        # Get model config
        config = getattr(self.model, "config", None)
        if config is None:
            return 0

        head_size = getattr(config, "head_dim", 64)
        num_kv_heads = getattr(
            config, "num_key_value_heads", getattr(config, "num_attention_heads", 32)
        )
        num_layers = getattr(config, "num_hidden_layers", 32)
        block_size = self.cache_config.block_size

        # K+V (×2) × float16 (×2 bytes) per element
        return 2 * block_size * num_layers * num_kv_heads * head_size * 2

    def warm_up(self) -> None:
        """Warm up model with a test generation."""
        if not self._loaded:
            self.load_model()

        logger.info("Warming up model...")

        try:
            from mlx_lm import generate

            # Simple warm-up generation
            _ = generate(
                self.model,
                self.tokenizer,
                prompt="Hello",
                max_tokens=5,
                verbose=False,
            )
            logger.info("Model warm-up complete")

        except Exception as e:
            logger.warning(f"Warm-up failed (non-critical): {e}")

    def execute_model(
        self,
        scheduler_output: "SchedulerOutput",
    ) -> MLXModelRunnerOutput:
        """
        Execute model inference for scheduled requests.

        Args:
            scheduler_output: Contains requests to process

        Returns:
            MLXModelRunnerOutput with generated tokens
        """
        if not self._loaded:
            raise RuntimeError("Model not loaded. Call load_model() first.")

        start_time = time.time()
        req_id_to_token_ids: dict[str, list[int]] = {}
        total_tokens = 0

        # Process new requests
        for req_data in scheduler_output.scheduled_new_reqs:
            req_id = req_data.req_id
            prompt_token_ids = req_data.prompt_token_ids

            # Generate tokens for this request
            generated_ids = self._generate_for_request(
                prompt_token_ids=prompt_token_ids,
                sampling_params=req_data.sampling_params,
                max_tokens=1,  # Generate one token at a time for streaming
            )

            req_id_to_token_ids[req_id] = generated_ids
            total_tokens += len(generated_ids)

        # Process running requests (continue generation)
        # NOTE: MLXModelRunner is a vLLM v1 compat shim. Running requests
        # should not reach here during normal vmlx-engine serving.
        for req_id in scheduler_output.scheduled_running_reqs:
            try:
                generated_ids = self._continue_generation(req_id)
            except NotImplementedError:
                logger.error(
                    "MLXModelRunner._continue_generation called — this runner "
                    "is a vLLM compat shim. Use Scheduler.step() for inference."
                )
                break
            if generated_ids:
                req_id_to_token_ids[req_id] = generated_ids
                total_tokens += len(generated_ids)

        generation_time = time.time() - start_time

        return MLXModelRunnerOutput(
            req_id_to_token_ids=req_id_to_token_ids,
            num_tokens_generated=total_tokens,
            generation_time_s=generation_time,
        )

    def _prefill_with_chunking(
        self,
        input_ids: mx.array,
        cache: Optional[Any] = None,
    ) -> tuple[mx.array, Any]:
        """
        Process prompt with optimal chunking for L2 cache efficiency.

        Long prompts are broken into chunks that fit in L2 cache,
        maximizing memory bandwidth utilization during prefill.

        Args:
            input_ids: Input token IDs [1, seq_len]
            cache: Optional existing KV cache

        Returns:
            Tuple of (logits, updated_cache)
        """
        def get_optimal_prefill_size(seq_len):
            # 512 tokens fits comfortably in Apple Silicon L2 cache
            return min(512, seq_len)

        seq_len = input_ids.shape[-1] if len(input_ids.shape) > 1 else len(input_ids)
        chunk_size = get_optimal_prefill_size(seq_len)

        # Reshape if needed
        if len(input_ids.shape) == 1:
            input_ids = input_ids.reshape(1, -1)

        # Use compiled forward if available, otherwise use model directly
        forward_fn = self._compiled_forward if self._compiled_forward else self.model

        if seq_len <= chunk_size:
            # Process entire sequence at once
            return forward_fn(input_ids, cache=cache)

        # Process in chunks for large prompts
        for i in range(0, seq_len, chunk_size):
            chunk = input_ids[:, i : i + chunk_size]
            logits, cache = forward_fn(chunk, cache=cache)
            mx.eval(cache)  # Force evaluation to free intermediate memory

        return logits, cache

    def _generate_for_request(
        self,
        prompt_token_ids: list[int],
        sampling_params: Any,
        max_tokens: int = 1,
    ) -> list[int]:
        """
        Generate tokens for a single request.

        Uses optimizations when enabled:
        - Compiled forward pass (kernel fusion)
        - Prefill chunking for long prompts

        Args:
            prompt_token_ids: Input token IDs
            sampling_params: Sampling parameters
            max_tokens: Maximum tokens to generate

        Returns:
            List of generated token IDs
        """
        try:
            from mlx_lm.generate import generate_step
            from .sampling import make_sampler

            # Create sampler from sampling params
            temp = getattr(sampling_params, "temperature", 0.7)
            top_p = getattr(sampling_params, "top_p", 0.9)
            top_k = getattr(sampling_params, "top_k", 0)
            min_p = getattr(sampling_params, "min_p", 0.0)
            sampler = make_sampler(temp=temp, top_p=top_p, top_k=top_k, min_p=min_p)

            # Convert token IDs to MLX array
            prompt = mx.array(prompt_token_ids)

            generated_ids = []

            # Generate tokens — generate_step yields (token_id, logprobs) tuples
            for token_id, _logprobs in generate_step(
                prompt=prompt,
                model=self.model,
                max_tokens=max_tokens,
                sampler=sampler,
            ):
                generated_ids.append(token_id.item() if hasattr(token_id, "item") else int(token_id))

                if len(generated_ids) >= max_tokens:
                    break

            return generated_ids

        except Exception as e:
            logger.error(f"Generation failed: {e}")
            return []

    def _continue_generation(self, req_id: str) -> list[int]:
        """
        Continue generation for an existing request.

        Not implemented — MLXModelRunner is a vLLM v1 platform plugin shim
        and is not used during normal vmlx-engine serving. The real inference
        path uses Scheduler.step() with mlx-lm's BatchGenerator.

        Raises:
            NotImplementedError: Always. This code path should not be reached
                during normal operation. If you see this error, the vLLM v1
                executor is routing running requests to MLXModelRunner, which
                requires a full implementation with per-request KV state tracking.
        """
        raise NotImplementedError(
            f"_continue_generation({req_id}) not implemented. "
            "MLXModelRunner is a vLLM compat shim; use Scheduler for inference."
        )

    def decode_tokens(self, token_ids: list[int]) -> str:
        """Decode token IDs to text."""
        if self.tokenizer is None:
            return ""
        return self.tokenizer.decode(token_ids)

    def get_model_info(self) -> dict:
        """Get information about the loaded model and optimizations."""
        info = {
            "loaded": self._loaded,
            "model_name": self.model_config.model,
            "optimizations_enabled": self._enable_optimizations,
        }

        if self._loaded and self.model is not None:
            config = getattr(self.model, "config", None)
            if config:
                info.update(
                    {
                        "vocab_size": getattr(config, "vocab_size", None),
                        "hidden_size": getattr(config, "hidden_size", None),
                        "num_layers": getattr(config, "num_hidden_layers", None),
                        "num_heads": getattr(config, "num_attention_heads", None),
                    }
                )

            # Add optimization status
            info["optimizations"] = {
                "kernel_fusion": self._compiled_forward is not None,
                "memory_optimized": self._hardware_info is not None,
            }

            if self._hardware_info:
                info["hardware"] = {
                    "chip": self._hardware_info.chip_name,
                    "memory_gb": self._hardware_info.total_memory_gb,
                    "bandwidth_gbs": self._hardware_info.memory_bandwidth_gbs,
                    "gpu_cores": self._hardware_info.gpu_cores,
                }

        return info

    def __repr__(self) -> str:
        status = "loaded" if self._loaded else "not loaded"
        opt_status = "optimized" if self._compiled_forward else "standard"
        return f"<MLXModelRunner model={self.model_config.model} status={status} mode={opt_status}>"
