# SPDX-License-Identifier: Apache-2.0
"""Tests for the OpenAI-compatible API server."""

import platform
import sys
from pathlib import Path

import pytest

# Skip all tests if not on Apple Silicon
pytestmark = pytest.mark.skipif(
    sys.platform != "darwin" or platform.machine() != "arm64",
    reason="Requires Apple Silicon",
)


# =============================================================================
# Unit Tests - Request/Response Models
# =============================================================================


class TestRequestModels:
    """Test Pydantic request models."""

    def test_chat_message_text_only(self):
        """Test chat message with text content."""
        from vmlx_engine.server import Message

        msg = Message(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"

    def test_chat_message_multimodal(self):
        """Test chat message with multimodal content."""
        from vmlx_engine.server import Message

        content = [
            {"type": "text", "text": "What's this?"},
            {"type": "image_url", "image_url": {"url": "https://example.com/img.jpg"}},
        ]
        msg = Message(role="user", content=content)

        assert msg.role == "user"
        assert isinstance(msg.content, list)
        assert len(msg.content) == 2

    def test_image_url_model(self):
        """Test ImageUrl model."""
        from vmlx_engine.server import ImageUrl

        img_url = ImageUrl(url="https://example.com/image.jpg")
        assert img_url.url == "https://example.com/image.jpg"
        assert img_url.detail is None

    def test_video_url_model(self):
        """Test VideoUrl model."""
        from vmlx_engine.server import VideoUrl

        video_url = VideoUrl(url="https://example.com/video.mp4")
        assert video_url.url == "https://example.com/video.mp4"

    def test_content_part_text(self):
        """Test ContentPart with text."""
        from vmlx_engine.server import ContentPart

        part = ContentPart(type="text", text="Hello world")
        assert part.type == "text"
        assert part.text == "Hello world"

    def test_content_part_image(self):
        """Test ContentPart with image_url."""
        from vmlx_engine.server import ContentPart

        part = ContentPart(
            type="image_url", image_url={"url": "https://example.com/img.jpg"}
        )
        assert part.type == "image_url"
        # image_url can be dict or ImageUrl object
        if isinstance(part.image_url, dict):
            assert part.image_url["url"] == "https://example.com/img.jpg"
        else:
            assert part.image_url.url == "https://example.com/img.jpg"

    def test_content_part_video(self):
        """Test ContentPart with video."""
        from vmlx_engine.server import ContentPart

        part = ContentPart(type="video", video="/path/to/video.mp4")
        assert part.type == "video"
        assert part.video == "/path/to/video.mp4"

    def test_content_part_video_url(self):
        """Test ContentPart with video_url."""
        from vmlx_engine.server import ContentPart

        part = ContentPart(
            type="video_url", video_url={"url": "https://example.com/video.mp4"}
        )
        assert part.type == "video_url"
        # video_url can be dict or VideoUrl object
        if isinstance(part.video_url, dict):
            assert part.video_url["url"] == "https://example.com/video.mp4"
        else:
            assert part.video_url.url == "https://example.com/video.mp4"


class TestChatCompletionRequest:
    """Test ChatCompletionRequest model."""

    def test_basic_request(self):
        """Test basic chat completion request."""
        from vmlx_engine.server import ChatCompletionRequest, Message

        request = ChatCompletionRequest(
            model="test-model", messages=[Message(role="user", content="Hello")]
        )

        assert request.model == "test-model"
        assert len(request.messages) == 1
        assert request.max_tokens is None  # uses _default_max_tokens when None
        assert (
            request.temperature is None
        )  # resolved at runtime by _resolve_temperature
        assert request.stream is False  # default

    def test_request_with_options(self):
        """Test request with custom options."""
        from vmlx_engine.server import ChatCompletionRequest, Message

        request = ChatCompletionRequest(
            model="test-model",
            messages=[Message(role="user", content="Hello")],
            max_tokens=100,
            temperature=0.5,
            stream=True,
        )

        assert request.max_tokens == 100
        assert request.temperature == 0.5
        assert request.stream is True

    def test_request_with_video_params(self):
        """Test request with video parameters."""
        from vmlx_engine.server import ChatCompletionRequest, Message

        request = ChatCompletionRequest(
            model="test-model",
            messages=[Message(role="user", content="Describe the video")],
            video_fps=2.0,
            video_max_frames=16,
        )

        assert request.video_fps == 2.0
        assert request.video_max_frames == 16


class TestCompletionRequest:
    """Test CompletionRequest model."""

    def test_basic_completion_request(self):
        """Test basic completion request."""
        from vmlx_engine.server import CompletionRequest

        request = CompletionRequest(model="test-model", prompt="Once upon a time")

        assert request.model == "test-model"
        assert request.prompt == "Once upon a time"
        assert request.max_tokens is None  # uses _default_max_tokens when None


# =============================================================================
# Helper Function Tests
# =============================================================================


class TestHelperFunctions:
    """Test server helper functions."""

    def test_resolve_max_prompt_tokens_uses_user_context_cap(self):
        from vmlx_engine import server

        assert server._resolve_max_prompt_tokens(64000, 8192) == 8192

    def test_resolve_max_prompt_tokens_uses_auto_estimate_when_unset(self):
        from vmlx_engine import server

        assert server._resolve_max_prompt_tokens(4096, None) == 4096

    def test_resolve_max_prompt_tokens_uses_auto_estimate_when_zero(self):
        from vmlx_engine import server

        assert server._resolve_max_prompt_tokens(4096, 0) == 4096

    def test_effective_max_prompt_tokens_request_can_only_lower_session_cap(self, monkeypatch):
        from types import SimpleNamespace
        from vmlx_engine import server

        monkeypatch.setattr(server, "_max_prompt_tokens", 8192)

        assert server._effective_max_prompt_tokens(SimpleNamespace(max_prompt_tokens=None)) == 8192
        assert server._effective_max_prompt_tokens(SimpleNamespace(max_prompt_tokens=4096)) == 4096
        assert server._effective_max_prompt_tokens(SimpleNamespace(max_prompt_tokens=16384)) == 8192

    def test_effective_max_prompt_tokens_request_can_cap_when_session_unbounded(self, monkeypatch):
        from types import SimpleNamespace
        from vmlx_engine import server

        monkeypatch.setattr(server, "_max_prompt_tokens", 0)

        assert server._effective_max_prompt_tokens(SimpleNamespace(max_prompt_tokens=2048)) == 2048

    def test_api_request_max_context_aliases_normalize_to_max_prompt_tokens(self):
        from vmlx_engine.api.models import (
            ChatCompletionRequest,
            CompletionRequest,
            Message,
            ResponsesRequest,
        )

        chat = ChatCompletionRequest(
            model="m",
            messages=[Message(role="user", content="hi")],
            max_context_tokens=1234,
        )
        comp = CompletionRequest(model="m", prompt="hi", max_context=2345)
        resp = ResponsesRequest(model="m", input="hi", max_prompt_tokens=3456)

        assert chat.max_prompt_tokens == 1234
        assert comp.max_prompt_tokens == 2345
        assert resp.max_prompt_tokens == 3456

    def test_ollama_num_ctx_maps_to_internal_max_prompt_tokens(self):
        from vmlx_engine.api.ollama_adapter import (
            ollama_chat_to_openai,
            ollama_generate_to_openai,
            ollama_generate_to_openai_chat,
        )

        chat = ollama_chat_to_openai({
            "model": "m",
            "messages": [{"role": "user", "content": "hi"}],
            "options": {"num_ctx": 2048},
        })
        raw = ollama_generate_to_openai({
            "model": "m",
            "prompt": "hi",
            "options": {"num_ctx": 3072},
        })
        templated = ollama_generate_to_openai_chat({
            "model": "m",
            "prompt": "hi",
            "options": {"num_ctx": 4096},
        })

        assert chat["max_prompt_tokens"] == 2048
        assert raw["max_prompt_tokens"] == 3072
        assert templated["max_prompt_tokens"] == 4096

    def test_anthropic_max_context_extension_maps_to_chat_request(self):
        from vmlx_engine.api.anthropic_adapter import AnthropicRequest, to_chat_completion

        req = AnthropicRequest(
            model="m",
            messages=[{"role": "user", "content": "hi"}],
            max_tokens=10,
            max_context_tokens=2048,
        )
        chat = to_chat_completion(req)

        assert chat.max_prompt_tokens == 2048

    def test_dead_max_context_length_global_removed(self):
        from pathlib import Path
        import vmlx_engine.server as server

        src = Path(server.__file__).read_text()
        assert "_max_context_length" not in src

    def test_prompt_limit_guard_rejects_chat_messages(self, monkeypatch):
        from vmlx_engine import server
        from vmlx_engine.api.models import Message

        monkeypatch.setattr(server, "_max_prompt_tokens", 2)

        response = server._reject_if_prompt_too_long_for_messages([
            Message(role="user", content="x" * 30)
        ])

        assert response is not None
        assert response.status_code == 413
        assert b"prompt_too_long" in response.body

    def test_prompt_limit_guard_allows_chat_messages_under_limit(self, monkeypatch):
        from vmlx_engine import server
        from vmlx_engine.api.models import Message

        monkeypatch.setattr(server, "_max_prompt_tokens", 100)

        assert server._reject_if_prompt_too_long_for_messages([
            Message(role="user", content="hello")
        ]) is None

    def test_prompt_limit_guard_rejects_completion_prompt_list(self, monkeypatch):
        from vmlx_engine import server

        monkeypatch.setattr(server, "_max_prompt_tokens", 2)

        response = server._reject_if_prompt_too_long_for_prompts([
            "short",
            "x" * 30,
        ])

        assert response is not None
        assert response.status_code == 413
        assert b"prompt_too_long" in response.body

    def test_prompt_limit_guard_counts_vlm_media_parts(self, monkeypatch):
        from vmlx_engine import server
        from vmlx_engine.api.models import Message

        monkeypatch.setattr(server, "_max_prompt_tokens", 100)

        response = server._reject_if_prompt_too_long_for_messages([
            Message(
                role="user",
                content=[
                    {"type": "text", "text": "describe"},
                    {"type": "image_url", "image_url": {"url": "file:///tmp/x.png"}},
                ],
            )
        ])

        assert response is not None
        assert response.status_code == 413
        assert b"prompt_too_long" in response.body

    def test_prompt_limit_guard_is_used_by_all_generation_entrypoints(self):
        import inspect
        from vmlx_engine import server

        completion_src = inspect.getsource(server.create_completion)
        chat_src = inspect.getsource(server.create_chat_completion)
        responses_src = inspect.getsource(server.create_response)
        anthropic_src = inspect.getsource(server.create_anthropic_message)
        ollama_chat_src = inspect.getsource(server.ollama_chat)
        ollama_generate_src = inspect.getsource(server.ollama_generate)

        assert "_completion_max_prompt_tokens = _effective_max_prompt_tokens(request)" in completion_src
        assert "_chat_max_prompt_tokens = _effective_max_prompt_tokens(request)" in chat_src
        assert "_responses_max_prompt_tokens = _effective_max_prompt_tokens(request)" in responses_src
        assert "_msg_max_prompt_tokens = _effective_max_prompt_tokens(chat_req)" in anthropic_src
        assert "_ollama_max_prompt_tokens = _effective_max_prompt_tokens(chat_req)" in ollama_chat_src
        assert "_ollama_gen_max_prompt_tokens = _effective_max_prompt_tokens(chat_req)" in ollama_generate_src
        assert "_ollama_raw_max_prompt_tokens = _effective_max_prompt_tokens(comp_req)" in ollama_generate_src

    def test_prompt_limit_is_forwarded_to_engine_generation_kwargs(self):
        source = Path("vmlx_engine/server.py").read_text()

        assert "_effective_max_prompt_tokens(request)" in source
        assert "max_prompt_tokens=_chat_max_prompt_tokens" in source
        assert '"max_prompt_tokens": _chat_max_prompt_tokens' in source
        assert '"max_prompt_tokens": _responses_max_prompt_tokens' in source
        assert "except PromptTooLongError" in source

    def test_streaming_routes_map_prompt_limit_to_prompt_too_long(self):
        import inspect
        from vmlx_engine import server

        chat_stream_src = inspect.getsource(server.stream_chat_completion)
        responses_stream_src = inspect.getsource(server.stream_responses_api)

        assert chat_stream_src.count("except PromptTooLongError") == 1
        assert "code\": \"prompt_too_long\"" in chat_stream_src
        assert "except PromptTooLongError" in responses_stream_src
        assert "code\": \"prompt_too_long\"" in responses_stream_src

    def test_is_mllm_model_detection(self, tmp_path):
        """Test MLLM model detection via config.json and force flag.
        No regex fallback — remote names without local config return False."""
        import json
        from vmlx_engine.server import is_mllm_model

        # force_mllm always returns True
        assert is_mllm_model("anything", force_mllm=True)

        # Remote names without local config.json return False
        assert not is_mllm_model("mlx-community/Qwen3-VL-4B-Instruct-3bit")
        assert not is_mllm_model("mlx-community/Llama-3.2-1B-Instruct-4bit")

        # Local model with vision_config returns True
        vlm_dir = tmp_path / "vlm-model"
        vlm_dir.mkdir()
        (vlm_dir / "config.json").write_text(json.dumps({
            "model_type": "qwen3_5", "vision_config": {"hidden_size": 1024}
        }))
        assert is_mllm_model(str(vlm_dir))

        # Local model without vision_config returns False
        llm_dir = tmp_path / "llm-model"
        llm_dir.mkdir()
        (llm_dir / "config.json").write_text(json.dumps({
            "model_type": "llama", "hidden_size": 4096
        }))
        assert not is_mllm_model(str(llm_dir))


class TestOllamaCompatibilityProbe:
    """Ollama-compatible clients probe these before sending real requests."""

    def test_root_and_version_do_not_require_api_key(self, monkeypatch):
        from fastapi.testclient import TestClient
        from vmlx_engine import server

        monkeypatch.setattr(server, "_api_key", "secret-token", raising=False)
        client = TestClient(server.app)

        root = client.get("/")
        assert root.status_code == 200
        assert "Ollama" in root.text
        assert client.head("/").status_code == 200

        version = client.get("/api/version")
        assert version.status_code == 200
        assert version.json()["version"] == "0.12.6"
        assert client.head("/api/version").status_code == 200

    def test_extract_multimodal_content_text_only(self):
        """Test extracting content from text-only messages."""
        from vmlx_engine.server import extract_multimodal_content, Message

        messages = [
            Message(role="user", content="Hello"),
            Message(role="assistant", content="Hi there!"),
        ]

        processed, images, videos = extract_multimodal_content(messages)

        assert len(processed) == 2
        assert processed[0]["content"] == "Hello"
        assert len(images) == 0
        assert len(videos) == 0

    def test_extract_multimodal_content_with_image(self):
        """Test extracting content with images."""
        from vmlx_engine.server import extract_multimodal_content, Message

        messages = [
            Message(
                role="user",
                content=[
                    {"type": "text", "text": "What's this?"},
                    {
                        "type": "image_url",
                        "image_url": {"url": "https://example.com/img.jpg"},
                    },
                ],
            )
        ]

        processed, images, videos = extract_multimodal_content(messages)

        assert len(processed) == 1
        assert processed[0]["content"] == "What's this?"
        assert len(images) == 1
        assert "https://example.com/img.jpg" in images[0]

    def test_extract_multimodal_content_with_video(self):
        """Test extracting content with videos."""
        from vmlx_engine.server import extract_multimodal_content, Message

        messages = [
            Message(
                role="user",
                content=[
                    {"type": "text", "text": "Describe this video"},
                    {"type": "video", "video": "/path/to/video.mp4"},
                ],
            )
        ]

        processed, images, videos = extract_multimodal_content(messages)

        assert len(processed) == 1
        assert processed[0]["content"] == "Describe this video"
        assert len(videos) == 1
        assert videos[0] == "/path/to/video.mp4"

    def test_extract_multimodal_content_with_video_url(self):
        """Test extracting content with video_url format."""
        from vmlx_engine.server import extract_multimodal_content, Message

        messages = [
            Message(
                role="user",
                content=[
                    {"type": "text", "text": "What happens?"},
                    {
                        "type": "video_url",
                        "video_url": {"url": "https://example.com/video.mp4"},
                    },
                ],
            )
        ]

        processed, images, videos = extract_multimodal_content(messages)

        assert len(videos) == 1


# =============================================================================
# Security and Reliability Tests (PR #4)
# =============================================================================


class TestRateLimiter:
    """Test the RateLimiter class for rate limiting functionality."""

    def test_rate_limiter_disabled_by_default(self):
        """Test that rate limiter allows all requests when disabled."""
        from vmlx_engine.server import RateLimiter

        limiter = RateLimiter(requests_per_minute=5, enabled=False)

        # Should allow unlimited requests when disabled
        for _ in range(100):
            allowed, retry_after = limiter.is_allowed("client1")
            assert allowed is True
            assert retry_after == 0

    def test_rate_limiter_enforces_limit(self):
        """Test that rate limiter enforces the request limit."""
        from vmlx_engine.server import RateLimiter

        limiter = RateLimiter(requests_per_minute=3, enabled=True)

        # First 3 requests should be allowed
        for i in range(3):
            allowed, retry_after = limiter.is_allowed("client1")
            assert allowed is True, f"Request {i+1} should be allowed"
            assert retry_after == 0

        # 4th request should be blocked
        allowed, retry_after = limiter.is_allowed("client1")
        assert allowed is False
        assert retry_after > 0

    def test_rate_limiter_per_client(self):
        """Test that rate limits are tracked per client."""
        from vmlx_engine.server import RateLimiter

        limiter = RateLimiter(requests_per_minute=2, enabled=True)

        # Client 1 uses its quota
        limiter.is_allowed("client1")
        limiter.is_allowed("client1")
        allowed, _ = limiter.is_allowed("client1")
        assert allowed is False

        # Client 2 should still have quota
        allowed, _ = limiter.is_allowed("client2")
        assert allowed is True

    def test_rate_limiter_thread_safety(self):
        """Test that rate limiter is thread-safe."""
        import threading
        from vmlx_engine.server import RateLimiter

        limiter = RateLimiter(requests_per_minute=100, enabled=True)
        results = []
        errors = []

        def make_requests():
            try:
                for _ in range(10):
                    allowed, _ = limiter.is_allowed("shared_client")
                    results.append(allowed)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=make_requests) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"Thread safety errors: {errors}"
        assert len(results) == 100
        # Exactly 100 requests allowed (our limit)
        assert results.count(True) == 100


class TestTempFileManager:
    """Test the TempFileManager class for temp file cleanup."""

    def test_register_and_cleanup_single_file(self):
        """Test registering and cleaning up a single temp file."""
        import tempfile
        import os
        from vmlx_engine.models.mllm import TempFileManager

        manager = TempFileManager()

        # Create a real temp file
        temp = tempfile.NamedTemporaryFile(delete=False, suffix=".txt")
        temp.write(b"test content")
        temp.close()

        # Register it
        path = manager.register(temp.name)
        assert path == temp.name
        assert os.path.exists(temp.name)

        # Cleanup
        result = manager.cleanup(temp.name)
        assert result is True
        assert not os.path.exists(temp.name)

    def test_cleanup_all_files(self):
        """Test cleaning up all registered temp files."""
        import tempfile
        import os
        from vmlx_engine.models.mllm import TempFileManager

        manager = TempFileManager()
        paths = []

        # Create multiple temp files
        for i in range(3):
            temp = tempfile.NamedTemporaryFile(delete=False, suffix=f"_{i}.txt")
            temp.write(f"content {i}".encode())
            temp.close()
            manager.register(temp.name)
            paths.append(temp.name)

        # Verify all exist
        for p in paths:
            assert os.path.exists(p)

        # Cleanup all
        cleaned = manager.cleanup_all()
        assert cleaned == 3

        # Verify all deleted
        for p in paths:
            assert not os.path.exists(p)

    def test_cleanup_nonexistent_file(self):
        """Test cleanup of a non-existent file."""
        from vmlx_engine.models.mllm import TempFileManager

        manager = TempFileManager()

        # Cleanup a file that doesn't exist
        result = manager.cleanup("/nonexistent/path/file.txt")
        assert result is False

    def test_thread_safe_registration(self):
        """Test that TempFileManager is thread-safe."""
        import threading
        import tempfile
        from vmlx_engine.models.mllm import TempFileManager

        manager = TempFileManager()
        paths = []
        lock = threading.Lock()
        errors = []

        def register_files():
            try:
                for _ in range(5):
                    temp = tempfile.NamedTemporaryFile(delete=False, suffix=".txt")
                    temp.write(b"test")
                    temp.close()
                    path = manager.register(temp.name)
                    with lock:
                        paths.append(path)
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=register_files) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"Thread safety errors: {errors}"
        assert len(paths) == 25

        # Cleanup all
        cleaned = manager.cleanup_all()
        assert cleaned == 25


class TestRequestOutputCollectorThreadSafety:
    """Test thread-safety of RequestOutputCollector._waiting_consumers."""

    def test_waiting_consumers_thread_safe(self):
        """Test that _waiting_consumers counter is thread-safe."""
        import threading
        from vmlx_engine.output_collector import RequestOutputCollector

        # Reset the counter
        with RequestOutputCollector._waiting_lock:
            RequestOutputCollector._waiting_consumers = 0

        errors = []

        def manipulate_counter():
            try:
                for _ in range(100):
                    with RequestOutputCollector._waiting_lock:
                        RequestOutputCollector._waiting_consumers += 1
                    with RequestOutputCollector._waiting_lock:
                        RequestOutputCollector._waiting_consumers -= 1
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=manipulate_counter) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"Thread safety errors: {errors}"
        # Should return to zero
        with RequestOutputCollector._waiting_lock:
            assert RequestOutputCollector._waiting_consumers == 0

    def test_has_waiting_consumers_method(self):
        """Test has_waiting_consumers class method."""
        from vmlx_engine.output_collector import RequestOutputCollector

        # Reset counter
        with RequestOutputCollector._waiting_lock:
            RequestOutputCollector._waiting_consumers = 0

        assert RequestOutputCollector.has_waiting_consumers() is False

        with RequestOutputCollector._waiting_lock:
            RequestOutputCollector._waiting_consumers = 1

        assert RequestOutputCollector.has_waiting_consumers() is True

        # Reset
        with RequestOutputCollector._waiting_lock:
            RequestOutputCollector._waiting_consumers = 0


class TestRequestTimeoutField:
    """Test the new timeout field in request models."""

    def test_chat_completion_request_timeout_field(self):
        """Test that ChatCompletionRequest has timeout field."""
        from vmlx_engine.server import ChatCompletionRequest, Message

        # Default should be None
        request = ChatCompletionRequest(
            model="test-model", messages=[Message(role="user", content="Hello")]
        )
        assert request.timeout is None

        # Can set custom timeout
        request_with_timeout = ChatCompletionRequest(
            model="test-model",
            messages=[Message(role="user", content="Hello")],
            timeout=60.0,
        )
        assert request_with_timeout.timeout == 60.0

    def test_completion_request_timeout_field(self):
        """Test that CompletionRequest has timeout field."""
        from vmlx_engine.server import CompletionRequest

        # Default should be None
        request = CompletionRequest(model="test-model", prompt="Once upon a time")
        assert request.timeout is None

        # Can set custom timeout
        request_with_timeout = CompletionRequest(
            model="test-model", prompt="Once upon a time", timeout=120.0
        )
        assert request_with_timeout.timeout == 120.0


class TestOpenAILogprobsFormatting:
    """Server-side token decoding must produce OpenAI-compatible logprob shapes."""

    class _Tokenizer:
        def decode(self, token_ids):
            mapping = {
                10: " hello",
                11: "world",
                12: "é",
            }
            return "".join(mapping[i] for i in token_ids)

    def test_completion_logprobs_preserve_tokens_offsets_and_top_entries(self):
        from vmlx_engine.server import _format_completion_logprobs

        raw = [
            {
                "token_id": 10,
                "logprob": -0.1,
                "top_logprobs": [(10, -0.1), (11, -2.0)],
            },
            {
                "token_id": 12,
                "logprob": -0.2,
                "top_logprobs": [(12, -0.2)],
            },
        ]

        formatted = _format_completion_logprobs(raw, self._Tokenizer())

        assert formatted == {
            "tokens": [" hello", "é"],
            "token_logprobs": [-0.1, -0.2],
            "top_logprobs": [
                {" hello": -0.1, "world": -2.0},
                {"é": -0.2},
            ],
            "text_offset": [0, 6],
        }

    def test_chat_logprobs_include_utf8_bytes(self):
        from vmlx_engine.server import _format_chat_logprobs

        formatted = _format_chat_logprobs(
            [
                {
                    "token_id": 12,
                    "logprob": -0.2,
                    "top_logprobs": [(12, -0.2), (11, -1.5)],
                }
            ],
            self._Tokenizer(),
        )

        assert formatted == {
            "content": [
                {
                    "token": "é",
                    "logprob": -0.2,
                    "bytes": [195, 169],
                    "top_logprobs": [
                        {"token": "é", "logprob": -0.2, "bytes": [195, 169]},
                        {
                            "token": "world",
                            "logprob": -1.5,
                            "bytes": [119, 111, 114, 108, 100],
                        },
                    ],
                }
            ]
        }

    @pytest.mark.asyncio
    async def test_completion_endpoint_passes_logprobs_to_text_engine(self, monkeypatch):
        import vmlx_engine.server as server
        from vmlx_engine.api.models import CompletionRequest
        from vmlx_engine.engine.base import GenerationOutput

        class _Engine:
            is_mllm = False
            preserve_native_tool_format = False
            tokenizer = self._Tokenizer()

            def __init__(self):
                self.kwargs = None

            async def generate(self, **kwargs):
                self.kwargs = kwargs
                return GenerationOutput(
                    text=" hello",
                    tokens=[10],
                    prompt_tokens=2,
                    completion_tokens=1,
                    logprobs=[
                        {
                            "token_id": 10,
                            "logprob": -0.1,
                            "top_logprobs": [(10, -0.1), (11, -2.0)],
                        }
                    ],
                    finish_reason="stop",
                )

        engine = _Engine()
        monkeypatch.setattr(server, "_engine", engine)
        monkeypatch.setattr(server, "_served_model_name", "loaded-model")
        monkeypatch.setattr(server, "_model_name", "loaded-model")

        response = await server.create_completion(
            CompletionRequest(
                model="loaded-model",
                prompt="hi",
                max_tokens=1,
                logprobs=2,
            )
        )

        assert engine.kwargs["logprobs"] is True
        assert engine.kwargs["top_logprobs"] == 2
        assert response.choices[0].logprobs == {
            "tokens": [" hello"],
            "token_logprobs": [-0.1],
            "top_logprobs": [{" hello": -0.1, "world": -2.0}],
            "text_offset": [0],
        }

    @pytest.mark.asyncio
    async def test_chat_endpoint_passes_logprobs_to_text_engine(self, monkeypatch):
        import vmlx_engine.server as server
        from vmlx_engine.api.models import ChatCompletionRequest, Message
        from vmlx_engine.engine.base import GenerationOutput

        class _Engine:
            is_mllm = False
            tokenizer = self._Tokenizer()
            preserve_native_tool_format = False

            def __init__(self):
                self.kwargs = None

            async def chat(self, *, messages, **kwargs):
                self.kwargs = kwargs
                return GenerationOutput(
                    text="é",
                    tokens=[12],
                    prompt_tokens=3,
                    completion_tokens=1,
                    logprobs=[
                        {
                            "token_id": 12,
                            "logprob": -0.2,
                            "top_logprobs": [(12, -0.2), (11, -1.5)],
                        }
                    ],
                    finish_reason="stop",
                )

        engine = _Engine()
        monkeypatch.setattr(server, "_engine", engine)
        monkeypatch.setattr(server, "_served_model_name", "loaded-model")
        monkeypatch.setattr(server, "_model_name", "loaded-model")
        monkeypatch.setattr(server, "_model_path", None)
        monkeypatch.setattr(server, "_model_type", "llm")
        monkeypatch.setattr(server, "_reasoning_parser", None)
        monkeypatch.setattr(server, "_mcp_manager", None)

        response = await server.create_chat_completion(
            ChatCompletionRequest(
                model="loaded-model",
                messages=[Message(role="user", content="hi")],
                max_tokens=1,
                logprobs=True,
                top_logprobs=2,
            ),
            fastapi_request=None,
        )

        assert engine.kwargs["logprobs"] is True
        assert engine.kwargs["top_logprobs"] == 2
        assert response.choices[0].logprobs == {
            "content": [
                {
                    "token": "é",
                    "logprob": -0.2,
                    "bytes": [195, 169],
                    "top_logprobs": [
                        {"token": "é", "logprob": -0.2, "bytes": [195, 169]},
                        {
                            "token": "world",
                            "logprob": -1.5,
                            "bytes": [119, 111, 114, 108, 100],
                        },
                    ],
                }
            ]
        }

    @pytest.mark.asyncio
    async def test_chat_endpoint_passes_max_prompt_tokens_to_engine(self, monkeypatch):
        import vmlx_engine.server as server
        from vmlx_engine.api.models import ChatCompletionRequest, Message
        from vmlx_engine.engine.base import GenerationOutput

        class _Engine:
            is_mllm = False
            preserve_native_tool_format = False

            def __init__(self):
                self.kwargs = None

            async def chat(self, *, messages, **kwargs):
                self.kwargs = kwargs
                return GenerationOutput(
                    text="ok",
                    prompt_tokens=3,
                    completion_tokens=1,
                    finish_reason="stop",
                )

        engine = _Engine()
        monkeypatch.setattr(server, "_engine", engine)
        monkeypatch.setattr(server, "_served_model_name", "loaded-model")
        monkeypatch.setattr(server, "_model_name", "loaded-model")
        monkeypatch.setattr(server, "_model_path", None)
        monkeypatch.setattr(server, "_model_type", "llm")
        monkeypatch.setattr(server, "_reasoning_parser", None)
        monkeypatch.setattr(server, "_mcp_manager", None)
        monkeypatch.setattr(server, "_max_prompt_tokens", 64)

        await server.create_chat_completion(
            ChatCompletionRequest(
                model="loaded-model",
                messages=[Message(role="user", content="hi")],
                max_tokens=1,
            ),
            fastapi_request=None,
        )

        assert engine.kwargs["max_prompt_tokens"] == 64

    @pytest.mark.asyncio
    async def test_chat_endpoint_request_max_prompt_tokens_lowers_session_cap(self, monkeypatch):
        import vmlx_engine.server as server
        from vmlx_engine.api.models import ChatCompletionRequest, Message
        from vmlx_engine.engine.base import GenerationOutput

        class _Engine:
            is_mllm = False
            preserve_native_tool_format = False

            def __init__(self):
                self.kwargs = None

            async def chat(self, *, messages, **kwargs):
                self.kwargs = kwargs
                return GenerationOutput(
                    text="ok",
                    prompt_tokens=3,
                    completion_tokens=1,
                    finish_reason="stop",
                )

        engine = _Engine()
        monkeypatch.setattr(server, "_engine", engine)
        monkeypatch.setattr(server, "_served_model_name", "loaded-model")
        monkeypatch.setattr(server, "_model_name", "loaded-model")
        monkeypatch.setattr(server, "_model_path", None)
        monkeypatch.setattr(server, "_model_type", "llm")
        monkeypatch.setattr(server, "_reasoning_parser", None)
        monkeypatch.setattr(server, "_mcp_manager", None)
        monkeypatch.setattr(server, "_max_prompt_tokens", 64)

        await server.create_chat_completion(
            ChatCompletionRequest(
                model="loaded-model",
                messages=[Message(role="user", content="hi")],
                max_tokens=1,
                max_prompt_tokens=32,
            ),
            fastapi_request=None,
        )

        assert engine.kwargs["max_prompt_tokens"] == 32

    @pytest.mark.parametrize(
        "endpoint, stream, is_mllm, expected",
        [
            ("Completions", False, True, "text-only LLM"),
            ("Chat Completions", False, True, "text-only LLM"),
            ("Completions", True, True, "multimodal/VLM logprobs"),
            ("Chat Completions", True, True, "multimodal/VLM logprobs"),
        ],
    )
    def test_logprobs_rejects_unimplemented_surfaces(
        self, endpoint, stream, is_mllm, expected
    ):
        from fastapi import HTTPException
        from vmlx_engine.server import _reject_unsupported_logprobs_request

        with pytest.raises(HTTPException) as exc:
            _reject_unsupported_logprobs_request(
                endpoint=endpoint,
                requested=True,
                stream=stream,
                is_mllm=is_mllm,
            )

        assert exc.value.status_code == 400
        assert expected in exc.value.detail

    def test_logprobs_allows_text_streaming(self):
        from vmlx_engine.server import _reject_unsupported_logprobs_request

        _reject_unsupported_logprobs_request(
            endpoint="Chat Completions",
            requested=True,
            stream=True,
            is_mllm=False,
        )

    @pytest.mark.asyncio
    async def test_completion_endpoint_rejects_mllm_logprobs(self, monkeypatch):
        import vmlx_engine.server as server
        from fastapi import HTTPException
        from vmlx_engine.api.models import CompletionRequest

        class _Engine:
            is_mllm = True

        monkeypatch.setattr(server, "_engine", _Engine())
        monkeypatch.setattr(server, "_served_model_name", "vl-model")
        monkeypatch.setattr(server, "_model_name", "vl-model")

        with pytest.raises(HTTPException) as exc:
            await server.create_completion(
                CompletionRequest(model="vl-model", prompt="hi", logprobs=1)
            )

        assert exc.value.status_code == 400
        assert "multimodal/VLM logprobs" in exc.value.detail

    @pytest.mark.asyncio
    async def test_chat_endpoint_rejects_mllm_logprobs_before_generation(self, monkeypatch):
        import vmlx_engine.server as server
        from fastapi import HTTPException
        from vmlx_engine.api.models import ChatCompletionRequest, Message

        class _Engine:
            is_mllm = True

            async def chat(self, **kwargs):  # pragma: no cover - must not run
                raise AssertionError("chat should not be called")

        monkeypatch.setattr(server, "_engine", _Engine())
        monkeypatch.setattr(server, "_served_model_name", "vl-model")
        monkeypatch.setattr(server, "_model_name", "vl-model")
        monkeypatch.setattr(server, "_model_path", None)

        with pytest.raises(HTTPException) as exc:
            await server.create_chat_completion(
                ChatCompletionRequest(
                    model="vl-model",
                    messages=[Message(role="user", content="hi")],
                    logprobs=True,
                ),
                fastapi_request=None,
            )

        assert exc.value.status_code == 400
        assert "multimodal/VLM logprobs" in exc.value.detail

    def test_streaming_chunk_choice_can_carry_logprobs(self):
        from vmlx_engine.api.models import ChatCompletionChunkChoice

        assert "logprobs" in ChatCompletionChunkChoice.model_fields

    @pytest.mark.asyncio
    async def test_streaming_completion_emits_delta_logprobs(self, monkeypatch):
        import json

        import vmlx_engine.server as server
        from vmlx_engine.api.models import CompletionRequest
        from vmlx_engine.engine.base import GenerationOutput

        class _Engine:
            tokenizer = self._Tokenizer()

            def __init__(self):
                self.kwargs = None

            async def stream_generate(self, **kwargs):
                self.kwargs = kwargs
                yield GenerationOutput(
                    text=" hello",
                    new_text=" hello",
                    tokens=[10],
                    prompt_tokens=2,
                    completion_tokens=1,
                    finished=False,
                    logprobs=[
                        {
                            "token_id": 10,
                            "logprob": -0.1,
                            "top_logprobs": [(10, -0.1)],
                        }
                    ],
                )

        engine = _Engine()
        monkeypatch.setattr(server, "_default_timeout", 5.0)

        chunks = []
        request = CompletionRequest(
            model="loaded-model",
            prompt="hi",
            stream=True,
            logprobs=1,
        )
        async for line in server.stream_completions_multi(engine, ["hi"], request):
            if line.startswith("data: ") and line.strip() != "data: [DONE]":
                chunks.append(json.loads(line.removeprefix("data: ")))

        assert engine.kwargs["logprobs"] is True
        assert engine.kwargs["top_logprobs"] == 1
        assert chunks[0]["choices"][0]["logprobs"] == {
            "tokens": [" hello"],
            "token_logprobs": [-0.1],
            "top_logprobs": [{" hello": -0.1}],
            "text_offset": [0],
        }

    @pytest.mark.asyncio
    async def test_streaming_chat_emits_delta_logprobs(self, monkeypatch):
        import json

        import vmlx_engine.server as server
        from vmlx_engine.api.models import ChatCompletionRequest, Message
        from vmlx_engine.engine.base import GenerationOutput

        class _Engine:
            tokenizer = self._Tokenizer()

            async def stream_chat(self, *, messages, **kwargs):
                yield GenerationOutput(
                    text="é",
                    new_text="é",
                    tokens=[12],
                    prompt_tokens=3,
                    completion_tokens=1,
                    finished=False,
                    logprobs=[
                        {
                            "token_id": 12,
                            "logprob": -0.2,
                            "top_logprobs": [(12, -0.2)],
                        }
                    ],
                )

        monkeypatch.setattr(server, "_default_timeout", 5.0)
        monkeypatch.setattr(server, "_model_name", "loaded-model")
        monkeypatch.setattr(server, "_model_path", None)
        monkeypatch.setattr(server, "_reasoning_parser", None)

        request = ChatCompletionRequest(
            model="loaded-model",
            messages=[Message(role="user", content="hi")],
            stream=True,
            logprobs=True,
            top_logprobs=1,
        )
        chunks = []
        async for line in server.stream_chat_completion(
            _Engine(),
            [m.model_dump(exclude_none=True) for m in request.messages],
            request,
            fastapi_request=None,
            logprobs=True,
            top_logprobs=1,
        ):
            if line.startswith("data: ") and line.strip() != "data: [DONE]":
                chunks.append(json.loads(line.removeprefix("data: ")))

        content_chunks = [
            c for c in chunks
            if c["choices"] and c["choices"][0]["delta"].get("content")
        ]
        assert content_chunks[0]["choices"][0]["logprobs"] == {
            "content": [
                {
                    "token": "é",
                    "logprob": -0.2,
                    "bytes": [195, 169],
                    "top_logprobs": [
                        {"token": "é", "logprob": -0.2, "bytes": [195, 169]}
                    ],
                }
            ]
        }

    @pytest.mark.asyncio
    async def test_streaming_chat_suppresses_mid_text_dsml_partial_marker(
        self, monkeypatch
    ):
        """DSV4 can flush `<｜DSML｜tool` before the full wrapper name.

        That partial can land in the middle of the accumulated stream when the
        model resumes prose after a tool attempt. It must never be emitted as
        visible assistant text.
        """
        import json
        from types import SimpleNamespace

        import vmlx_engine.server as server
        from vmlx_engine.api.models import ChatCompletionRequest, Message
        from vmlx_engine.engine.base import GenerationOutput

        class _Engine:
            tokenizer = SimpleNamespace(has_thinking=False)

            async def stream_chat(self, *, messages, **kwargs):
                yield GenerationOutput(
                    text="<",
                    new_text="<",
                    tokens=[10],
                    prompt_tokens=3,
                    completion_tokens=1,
                    finished=False,
                    finish_reason=None,
                )
                yield GenerationOutput(
                    text="<｜DSML｜",
                    new_text="｜DSML｜",
                    tokens=[10, 11],
                    prompt_tokens=3,
                    completion_tokens=2,
                    finished=False,
                    finish_reason=None,
                )
                yield GenerationOutput(
                    text='<｜DSML｜tool_call_type type="list_directory" "attributes":"."',
                    new_text='tool_call_type type="list_directory" "attributes":"."',
                    tokens=[10, 11],
                    prompt_tokens=3,
                    completion_tokens=3,
                    finished=True,
                    finish_reason="stop",
                )

        monkeypatch.setattr(server, "_default_timeout", 5.0)
        monkeypatch.setattr(server, "_model_name", "dsv4-test")
        monkeypatch.setattr(server, "_model_path", None)
        monkeypatch.setattr(server, "_reasoning_parser", None)
        monkeypatch.setattr(server, "_tool_call_parser", "deepseek_v4")

        request = ChatCompletionRequest(
            model="dsv4-test",
            messages=[Message(role="user", content="read files and help me fix")],
            stream=True,
            tools=[
                {
                    "type": "function",
                    "function": {
                        "name": "read_file",
                        "parameters": {
                            "type": "object",
                            "properties": {"path": {"type": "string"}},
                        },
                    },
                }
            ],
        )

        chunks = []
        async for line in server.stream_chat_completion(
            _Engine(),
            [m.model_dump(exclude_none=True) for m in request.messages],
            request,
            fastapi_request=None,
        ):
            if line.startswith("data: ") and line.strip() != "data: [DONE]":
                chunks.append(json.loads(line.removeprefix("data: ")))

        visible = "".join(
            choice.get("delta", {}).get("content") or ""
            for chunk in chunks
            for choice in chunk.get("choices", [])
        )
        assert "<｜DSML｜" not in visible
        assert "<tool" not in visible

    @pytest.mark.asyncio
    async def test_streaming_chat_flushes_literal_less_than_after_tool_buffer_probe(
        self, monkeypatch
    ):
        """A literal `<` prefix probe must not swallow normal visible text."""
        import json
        from types import SimpleNamespace

        import vmlx_engine.server as server
        from vmlx_engine.api.models import ChatCompletionRequest, Message
        from vmlx_engine.engine.base import GenerationOutput

        class _Engine:
            tokenizer = SimpleNamespace(has_thinking=False)

            async def stream_chat(self, *, messages, **kwargs):
                yield GenerationOutput(
                    text="2 <",
                    new_text="2 <",
                    tokens=[10],
                    prompt_tokens=3,
                    completion_tokens=1,
                    finished=False,
                    finish_reason=None,
                )
                yield GenerationOutput(
                    text="2 < 3",
                    new_text=" 3",
                    tokens=[10, 11],
                    prompt_tokens=3,
                    completion_tokens=2,
                    finished=True,
                    finish_reason="stop",
                )

        monkeypatch.setattr(server, "_default_timeout", 5.0)
        monkeypatch.setattr(server, "_model_name", "dsv4-test")
        monkeypatch.setattr(server, "_model_path", None)
        monkeypatch.setattr(server, "_reasoning_parser", None)
        monkeypatch.setattr(server, "_tool_call_parser", "deepseek_v4")

        request = ChatCompletionRequest(
            model="dsv4-test",
            messages=[Message(role="user", content="is 2 < 3?")],
            stream=True,
            tools=[
                {
                    "type": "function",
                    "function": {
                        "name": "read_file",
                        "parameters": {
                            "type": "object",
                            "properties": {"path": {"type": "string"}},
                        },
                    },
                }
            ],
        )

        chunks = []
        async for line in server.stream_chat_completion(
            _Engine(),
            [m.model_dump(exclude_none=True) for m in request.messages],
            request,
            fastapi_request=None,
        ):
            if line.startswith("data: ") and line.strip() != "data: [DONE]":
                chunks.append(json.loads(line.removeprefix("data: ")))

        visible = "".join(
            choice.get("delta", {}).get("content") or ""
            for chunk in chunks
            for choice in chunk.get("choices", [])
        )
        assert visible == "2 < 3"


class TestAPIKeyVerification:
    """Test API key verification with timing attack prevention."""

    def test_secrets_compare_digest_usage(self):
        """Test that secrets.compare_digest is used (timing attack prevention)."""
        import secrets

        # Verify secrets.compare_digest works as expected
        key1 = "test-api-key-12345"
        key2 = "test-api-key-12345"
        key3 = "different-key-67890"

        # Same keys should match
        assert secrets.compare_digest(key1, key2) is True

        # Different keys should not match
        assert secrets.compare_digest(key1, key3) is False

        # Verify it's constant-time (by checking function exists)
        assert hasattr(secrets, "compare_digest")

    def test_verify_api_key_rejects_invalid(self):
        """Test that invalid API key is rejected with 401."""
        import asyncio
        from fastapi import HTTPException
        from fastapi.security import HTTPAuthorizationCredentials

        # Import and set up the module
        import vmlx_engine.server as server

        original_key = server._api_key

        try:
            # Set a known API key
            server._api_key = "valid-secret-key"

            # Create mock credentials with invalid key
            credentials = HTTPAuthorizationCredentials(
                scheme="Bearer", credentials="invalid-key"
            )

            # Should raise HTTPException with 401
            with pytest.raises(HTTPException) as exc_info:
                asyncio.run(server.verify_api_key(credentials))

            assert exc_info.value.status_code == 401
            assert "Invalid API key" in str(exc_info.value.detail)
        finally:
            server._api_key = original_key

    def test_verify_api_key_accepts_valid(self):
        """Test that valid API key is accepted."""
        import asyncio
        from fastapi.security import HTTPAuthorizationCredentials

        import vmlx_engine.server as server

        original_key = server._api_key

        try:
            # Set a known API key
            server._api_key = "valid-secret-key"

            # Create mock credentials with valid key
            credentials = HTTPAuthorizationCredentials(
                scheme="Bearer", credentials="valid-secret-key"
            )

            # Should not raise any exception
            result = asyncio.run(server.verify_api_key(credentials))
            # verify_api_key returns True on success (no exception raised)
            assert result is True or result is None
        finally:
            server._api_key = original_key


class TestRateLimiterHTTPResponse:
    """Test rate limiter HTTP response behavior."""

    def test_rate_limiter_returns_retry_after(self):
        """Test that rate limiter returns retry_after when limit exceeded."""
        from vmlx_engine.server import RateLimiter

        limiter = RateLimiter(requests_per_minute=2, enabled=True)

        # Exhaust the limit
        limiter.is_allowed("test_client")
        limiter.is_allowed("test_client")

        # Next request should be denied with retry_after
        allowed, retry_after = limiter.is_allowed("test_client")

        assert allowed is False
        assert retry_after is not None
        assert retry_after > 0
        assert retry_after <= 60  # Should be within a minute

    def test_rate_limiter_window_cleanup(self):
        """Test that rate limiter cleans up old requests from sliding window."""
        from vmlx_engine.server import RateLimiter
        import time

        limiter = RateLimiter(requests_per_minute=2, enabled=True)

        # Make some requests
        limiter.is_allowed("test_client")
        limiter.is_allowed("test_client")

        # Should be denied (limit reached)
        allowed, _ = limiter.is_allowed("test_client")
        assert allowed is False

        # Manually inject old timestamps to simulate time passing
        # The sliding window should clean these up
        old_time = time.time() - 120  # 2 minutes ago
        with limiter._lock:
            limiter._requests["test_client"] = [old_time, old_time]

        # Now should be allowed again (old requests cleaned up)
        allowed, _ = limiter.is_allowed("test_client")
        assert allowed is True


# =============================================================================
# Integration Tests (require running server)
# =============================================================================


@pytest.mark.slow
@pytest.mark.integration
class TestServerIntegration:
    """Integration tests that require a running server.

    These tests are skipped by default. Run with:
        pytest -m integration --server-url http://localhost:8000
    """

    @pytest.fixture
    def server_url(self, request):
        """Get server URL from command line or use default."""
        return request.config.getoption("--server-url", default="http://localhost:8000")

    def test_health_endpoint(self, server_url):
        """Test /health endpoint."""
        import requests

        response = requests.get(f"{server_url}/health", timeout=5)
        assert response.status_code == 200

        data = response.json()
        assert data["status"] == "healthy"
        assert "model_name" in data

    def test_models_endpoint(self, server_url):
        """Test /v1/models endpoint."""
        import requests

        response = requests.get(f"{server_url}/v1/models", timeout=5)
        assert response.status_code == 200

        data = response.json()
        assert "data" in data
        assert len(data["data"]) > 0

    def test_chat_completion(self, server_url):
        """Test /v1/chat/completions endpoint."""
        import requests

        payload = {
            "model": "default",
            "messages": [{"role": "user", "content": "Say hello"}],
            "max_tokens": 10,
        }

        response = requests.post(
            f"{server_url}/v1/chat/completions",
            json=payload,
            timeout=30,
        )
        assert response.status_code == 200

        data = response.json()
        assert "choices" in data
        assert len(data["choices"]) > 0
        assert data["choices"][0]["message"]["content"]


def pytest_addoption(parser):
    """Add custom command line options."""
    parser.addoption(
        "--server-url",
        action="store",
        default="http://localhost:8000",
        help="URL of the vmlx-engine server for integration tests",
    )


class TestDSV4RepetitionPenaltyDefaults:
    """DSV4 uses bundle-declared mode-specific repetition penalties.

    The DSV4 converter documents that thinking mode must remain neutral
    (`repetition_penalty_thinking=1.0`) because higher penalties make the model
    fail to close `</think>`. The old generic 1.15 floor is a regression for
    the forced-thinking default path.
    """

    def _set_dsv4_path(self, monkeypatch, tmp_path, sampling_defaults):
        """Build a fake DSV4 bundle dir + point _model_path at it."""
        import json
        cfg = {"model_type": "deepseek_v4"}
        (tmp_path / "config.json").write_text(json.dumps(cfg))
        jang_cfg = {
            "model_family": "deepseek_v4",
            "chat": {"sampling_defaults": sampling_defaults,
                     "reasoning": {"default_mode": "chat"}},
        }
        (tmp_path / "jang_config.json").write_text(json.dumps(jang_cfg))
        import vmlx_engine.server as srv
        monkeypatch.setattr(srv, "_model_path", str(tmp_path))
        monkeypatch.setattr(srv, "_default_repetition_penalty", None)
        return srv

    def test_thinking_mode_keeps_bundle_neutral_penalty(self, monkeypatch, tmp_path):
        srv = self._set_dsv4_path(monkeypatch, tmp_path, {
            "repetition_penalty_thinking": 1.0,
            "repetition_penalty_chat": 1.05,
            "repetition_penalty": 1.0,
        })
        result = srv._resolve_repetition_penalty(
            None,
            str(tmp_path),
            enable_thinking=True,
        )
        assert result == 1.0

    def test_chat_mode_uses_bundle_chat_penalty(self, monkeypatch, tmp_path):
        srv = self._set_dsv4_path(monkeypatch, tmp_path, {
            "repetition_penalty_chat": 1.05,
            "repetition_penalty_thinking": 1.0,
        })
        result = srv._resolve_repetition_penalty(
            None,
            str(tmp_path),
            enable_thinking=False,
        )
        assert result == 1.05

    def test_generation_kwargs_recomputed_after_mode_resolution(self, monkeypatch, tmp_path):
        srv = self._set_dsv4_path(monkeypatch, tmp_path, {
            "repetition_penalty_chat": 1.05,
            "repetition_penalty_thinking": 1.0,
        })
        kwargs = {"repetition_penalty": 1.0}

        srv._set_resolved_repetition_penalty(
            kwargs,
            None,
            str(tmp_path),
            enable_thinking=False,
        )

        assert kwargs["repetition_penalty"] == 1.05

    def test_explicit_per_request_repetition_penalty_is_honored(self, monkeypatch, tmp_path):
        srv = self._set_dsv4_path(monkeypatch, tmp_path, {
            "repetition_penalty_thinking": 1.0,
            "repetition_penalty_chat": 1.05,
        })
        result = srv._resolve_repetition_penalty(
            1.05,
            str(tmp_path),
            enable_thinking=True,
        )
        assert result == 1.05

    def test_floor_does_not_affect_non_dsv4_families(self, monkeypatch, tmp_path):
        import json
        # Build a non-DSV4 bundle
        cfg = {"model_type": "qwen3_moe"}
        (tmp_path / "config.json").write_text(json.dumps(cfg))
        jang_cfg = {"chat": {"sampling_defaults": {"repetition_penalty_chat": 1.0}}}
        (tmp_path / "jang_config.json").write_text(json.dumps(jang_cfg))
        import vmlx_engine.server as srv
        monkeypatch.setattr(srv, "_model_path", str(tmp_path))
        monkeypatch.setattr(srv, "_default_repetition_penalty", None)
        result = srv._resolve_repetition_penalty(None, str(tmp_path))
        # Non-DSV4 families don't get the DSV4 floor — None or actual is fine.
        assert result is None or result < 1.15, (
            f"Floor leaked to non-DSV4 family: got {result}")
