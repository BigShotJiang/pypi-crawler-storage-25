script_name = "pykara Bridge"
script_description = "Run pykara and insert generated FX lines"
script_author = "pykara"
script_version = "1.0"

local function is_windows()
    return package.config:sub(1, 1) == "\\"
end

local function shell_quote(value)
    if is_windows() then
        return '"' .. tostring(value):gsub('"', '""') .. '"'
    end
    return "'" .. tostring(value):gsub("'", "'\\''") .. "'"
end

local function join_path(...)
    local separator = is_windows() and "\\" or "/"
    local parts = {...}
    return table.concat(parts, separator)
end

local function parse_ass_time(value)
    local hours, minutes, seconds, centiseconds =
        value:match("^(%d+):(%d%d):(%d%d)%.(%d%d)$")
    if not hours then
        error("Invalid ASS time: " .. tostring(value))
    end
    return (
        (((tonumber(hours) * 60) + tonumber(minutes)) * 60 + tonumber(seconds))
        * 1000
    ) + tonumber(centiseconds) * 10
end

local function split_event_fields(value)
    local fields = {}
    local rest = value
    for _ = 1, 9 do
        local current, next_rest = rest:match("^([^,]*),(.*)$")
        if not current then
            break
        end
        table.insert(fields, current)
        rest = next_rest
    end
    table.insert(fields, rest)
    return fields
end

local function parse_generated_line(raw_line)
    local kind, body = raw_line:match("^(%a+):%s*(.*)$")
    if kind ~= "Dialogue" and kind ~= "Comment" then
        error("Unexpected generated event line: " .. tostring(raw_line))
    end

    local fields = split_event_fields(body)
    return {
        class = "dialogue",
        section = "[Events]",
        comment = kind == "Comment",
        layer = tonumber(fields[1]) or 0,
        start_time = parse_ass_time(fields[2] or "0:00:00.00"),
        end_time = parse_ass_time(fields[3] or "0:00:00.00"),
        style = fields[4] or "",
        actor = fields[5] or "",
        margin_l = tonumber(fields[6]) or 0,
        margin_r = tonumber(fields[7]) or 0,
        margin_t = tonumber(fields[8]) or 0,
        margin_b = tonumber(fields[8]) or 0,
        effect = fields[9] or "",
        text = fields[10] or "",
        raw = raw_line,
    }
end

local function current_ass_path()
    local dir = aegisub.decode_path("?script")
    local name = aegisub.file_name()

    if not dir or dir == "" or not name or name == "" then
        return nil
    end

    return join_path(dir, name)
end

local function pykara_command()
    return "pykara --emit-events "
end

local function show_text_dialog(text)
    aegisub.dialog.display({
        {
            class = "textbox",
            x = 0,
            y = 0,
            width = 60,
            height = 10,
            text = text,
        }
    }, {"OK"})
end

local function show_missing_pykara_message(output)
    local message = table.concat({
        "The `pykara` command is not available in PATH.",
        "",
        "Install it in your environment and ensure the command is available.",
        "",
        "Command output:",
        output,
    }, "\n")
    show_text_dialog(message)
end

local function strip_ansi(text)
    return (text or ""):gsub("\27%[[%d;]*m", "")
end

local function normalize_output_lines(output)
    local cleaned = strip_ansi(output)
    local lines = {}
    for raw_line in cleaned:gmatch("[^\r\n]+") do
        local line = raw_line:gsub("%s+$", "")
        if line ~= "" then
            table.insert(lines, line)
        end
    end
    return lines
end

local function try_bridge_command(command)
    local pipe = io.popen(command .. " 2>&1")

    if not pipe then
        return false, "io.popen failed in this Aegisub build.", false
    end

    local output = pipe:read("*a") or ""
    local ok = pipe:close()

    return ok ~= nil, output, true
end

local function remove_existing_fx_lines(subs)
    for i = #subs, 1, -1 do
        local line = subs[i]
        if line.class == "dialogue" and not line.comment and line.effect == "fx" then
            subs.delete(i)
        end
    end
end

local function comment_input_lines(subs)
    for i = 1, #subs do
        local line = subs[i]
        if line.class == "dialogue" and not line.comment then
            local effect = (line.effect or ""):lower()
            if effect == "kara" or effect == "karaoke" then
                line.comment = true
                subs[i] = line
            end
        end
    end
end

local function run_bridge(subs)
    local input_path = current_ass_path()

    if not input_path then
        aegisub.dialog.display({
            {
                class = "label",
                x = 0,
                y = 0,
                width = 60,
                height = 2,
                label = "Could not resolve the current subtitle path.",
            }
        }, {"OK"})
        return
    end

    local command = pykara_command() .. shell_quote(input_path)
    local succeeded, output, command_started = try_bridge_command(command)

    if not command_started then
        aegisub.dialog.display({
            {
                class = "label",
                x = 0,
                y = 0,
                width = 60,
                height = 2,
                label = "io.popen failed in this Aegisub build.",
            }
        }, {"OK"})
        return
    end

    if not succeeded then
        if output:match("command not found")
            or output:match("not found")
            or output:match("is not recognized as an internal or external command")
        then
            show_missing_pykara_message(output)
            return
        end

        if output:match("No module named ['\"]pykara['\"]")
            or output:match("ModuleNotFoundError:.-pykara")
        then
            show_missing_pykara_message(output)
            return
        end

        local lines = normalize_output_lines(output)
        if #lines > 0 then
            show_text_dialog(table.concat(lines, "\n"))
        else
            show_text_dialog(output)
        end
        return
    end

    remove_existing_fx_lines(subs)

    for raw_line in output:gmatch("[^\r\n]+") do
        if raw_line:match("^Dialogue: ") or raw_line:match("^Comment: ") then
            subs.append(parse_generated_line(raw_line))
        end
    end

    comment_input_lines(subs)

    aegisub.set_undo_point("pykara Apply Templates")
end

aegisub.register_macro(
    "pykara Apply Templates",
    "Generate FX lines through the Python bridge",
    run_bridge
)
