# pykara

Standalone Python CLI karaoke templater for ASS subtitles.

## Requirements

- Python 3.11+
- Cairo and Pango bindings available to Python

On Ubuntu/Debian, the CI setup installs:

```bash
sudo apt-get install -y \
  libcairo2-dev \
  libgirepository-2.0-dev \
  gir1.2-pango-1.0 \
  pkg-config
```

## Install

Install from PyPI:

```bash
pip install pykara
```

For a source checkout with development tools:

```bash
pip install -e .[dev]
```

## Documentation

Start with the
[documentation index](https://github.com/pandafansub/pykara/blob/main/docs/index.md)
for directives, scopes, and helpers.

## CLI

Write a new `.ass` output file:

```bash
pykara input.ass output.ass
```

Print only the generated ASS event rows:

```bash
pykara --emit-events input.ass
```

Use timecodes for frame-baked motion:

```bash
pykara --timecodes path/to/timecodes.txt input.ass output.ass
```

Useful flags:

- `--seed`: deterministic RNG seed for reproducible output
- `--debug`: show the full traceback instead of the short CLI error

## Aegisub Bridge

The repository includes an Aegisub automation script at
`bridge/pykara.lua`.

The bridge expects the `pykara` command to be available in `PATH`, runs
`pykara --emit-events` for the currently open subtitle file, removes existing
`fx` lines, inserts the regenerated ones, and comments the source karaoke
lines.
