"""Shared test paths for the pykara test suite."""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
from typing import Final

import pytest

PROJECT_ROOT: Final[Path] = Path(__file__).resolve().parents[1]
SRC_DIR: Final[Path] = PROJECT_ROOT / "src"
TESTS_DIR: Final[Path] = PROJECT_ROOT / "tests"
TEST_FIXTURES_DIR: Final[Path] = TESTS_DIR / "fixtures"
ASS_FIXTURES_DIR: Final[Path] = TEST_FIXTURES_DIR / "ass"
REFERENCE_FIXTURES_DIR: Final[Path] = TEST_FIXTURES_DIR / "reference"
KARAOKE_REFERENCE_FIXTURES_DIR: Final[Path] = REFERENCE_FIXTURES_DIR / "karaoke"
LAYOUT_REFERENCE_FIXTURES_DIR: Final[Path] = REFERENCE_FIXTURES_DIR / "layout"
FONTS_DIR: Final[Path] = TESTS_DIR / "fonts"
_FONTCONFIG_DIR: Final[Path] = Path(tempfile.mkdtemp(prefix="pykara-fontconfig-"))
_FONTCONFIG_CACHE_DIR: Final[Path] = _FONTCONFIG_DIR / "cache"
_FONTCONFIG_CACHE_DIR.mkdir(parents=True, exist_ok=True)
_FONTCONFIG_FILE: Final[Path] = _FONTCONFIG_DIR / "fonts.conf"

_FONTCONFIG_FILE.write_text(
    "\n".join(
        [
            '<?xml version="1.0"?>',
            '<!DOCTYPE fontconfig SYSTEM "fonts.dtd">',
            "<fontconfig>",
            "  <reset-dirs />",
            f"  <dir>{FONTS_DIR}</dir>",
            f"  <cachedir>{_FONTCONFIG_CACHE_DIR}</cachedir>",
            "</fontconfig>",
            "",
        ]
    ),
    encoding="utf-8",
)
os.environ["FONTCONFIG_FILE"] = str(_FONTCONFIG_FILE)
os.environ["XDG_CACHE_HOME"] = str(_FONTCONFIG_DIR)

if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))


@pytest.fixture(name="fixtures_dir")
def fixtures_dir_fixture() -> Path:
    """Return the shared fixture directory."""
    return TEST_FIXTURES_DIR


@pytest.fixture(name="ass_fixtures_dir")
def ass_fixtures_dir_fixture() -> Path:
    """Return the ASS-specific fixture directory."""
    return ASS_FIXTURES_DIR


@pytest.fixture(name="reference_fixtures_dir")
def reference_fixtures_dir_fixture() -> Path:
    """Return the shared reference fixture directory."""
    return REFERENCE_FIXTURES_DIR


@pytest.fixture(name="karaoke_reference_dir")
def karaoke_reference_dir_fixture() -> Path:
    """Return the karaoke reference fixture directory."""
    return KARAOKE_REFERENCE_FIXTURES_DIR


@pytest.fixture(name="layout_reference_dir")
def layout_reference_dir_fixture() -> Path:
    """Return the layout reference fixture directory."""
    return LAYOUT_REFERENCE_FIXTURES_DIR
