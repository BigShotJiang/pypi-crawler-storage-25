"""Shared test builders for common ASS and karaoke objects."""

from __future__ import annotations

from collections.abc import Sequence

from pykara.ass.types import (
    AssStyle as RawStyle,
)
from pykara.ass.types import (
    DialogueLine,
    EventType,
    ScriptInfo,
)
from pykara.karaoke.line import Line
from pykara.karaoke.parser import parse_karaoke


def _make_event(
    event_type: EventType,
    text: str,
    effect: str,
    *,
    style: str,
    name: str,
    layer: int,
    start_time: int,
    end_time: int,
) -> DialogueLine:
    return DialogueLine(
        event_type=event_type,
        layer=layer,
        start_time=start_time,
        end_time=end_time,
        style=style,
        name=name,
        margin_l=0,
        margin_r=0,
        margin_v=0,
        effect=effect,
        text=text,
    )


def make_comment_event(
    effect: str,
    text: str,
    *,
    style: str = "Default",
    name: str = "",
    layer: int = 0,
    start_time: int = 0,
    end_time: int = 0,
) -> DialogueLine:
    """Return one comment event configured as a directive source."""
    return _make_event(
        EventType.COMMENT,
        text,
        effect,
        style=style,
        name=name,
        layer=layer,
        start_time=start_time,
        end_time=end_time,
    )


def make_dialogue_event(
    text: str,
    *,
    style: str = "Default",
    actor: str = "actor",
    layer: int = 0,
    start_time: int = 1000,
    end_time: int = 1600,
    effect: str = "",
) -> DialogueLine:
    """Return one dialogue event with the suite's default timing metadata."""
    return _make_event(
        EventType.DIALOGUE,
        text,
        effect,
        style=style,
        name=actor,
        layer=layer,
        start_time=start_time,
        end_time=end_time,
    )


def parse_karaoke_line(
    text: str = r"{\k10}ab{\k20}cd",
    *,
    style: str = "Default",
    actor: str = "actor",
    start_time: int = 1000,
    end_time: int = 1600,
    effect: str = "",
) -> Line:
    """Parse one dialogue event into the internal karaoke line model."""
    return parse_karaoke(
        make_dialogue_event(
            text,
            style=style,
            actor=actor,
            start_time=start_time,
            end_time=end_time,
            effect=effect,
        )
    )


def make_raw_style(
    *,
    name: str = "Default",
    fontname: str = "Droid Sans",
    fontsize: float = 100.0,
    primary_colour: str = "&H00FFFFFF",
    secondary_colour: str = "&H000000FF",
    outline_colour: str = "&H00000000",
    back_colour: str = "&H00000000",
    bold: bool = False,
    italic: bool = False,
    underline: bool = False,
    strike_out: bool = False,
    scale_x: float = 99.0,
    scale_y: float = 98.0,
    spacing: float = 5.0,
    angle: float = 1.0,
    border_style: int = 1,
    outline: float = 2.0,
    shadow: float = 2.0,
    alignment: int = 5,
    margin_l: int = 30,
    margin_r: int = 32,
    margin_v: int = 33,
    encoding: int = 1,
) -> RawStyle:
    """Return one ASS style row with defaults tuned for layout tests."""
    return RawStyle(
        name=name,
        fontname=fontname,
        fontsize=fontsize,
        primary_colour=primary_colour,
        secondary_colour=secondary_colour,
        outline_colour=outline_colour,
        back_colour=back_colour,
        bold=bold,
        italic=italic,
        underline=underline,
        strike_out=strike_out,
        scale_x=scale_x,
        scale_y=scale_y,
        spacing=spacing,
        angle=angle,
        border_style=border_style,
        outline=outline,
        shadow=shadow,
        alignment=alignment,
        margin_l=margin_l,
        margin_r=margin_r,
        margin_v=margin_v,
        encoding=encoding,
    )


def make_motion_event(
    text: str,
    start_time: int = 1000,
    end_time: int = 2000,
) -> DialogueLine:
    """Return one minimal dialogue event for motion tests."""
    return make_dialogue_event(
        text,
        style="Default",
        actor="",
        start_time=start_time,
        end_time=end_time,
    )


def make_script_info(
    *,
    play_res_x: int = 1920,
    play_res_y: int = 1080,
    extra_fields: Sequence[tuple[str, str]] = (),
) -> ScriptInfo:
    """Return script info with the default play-resolution fields first."""
    return ScriptInfo(
        fields=[
            ("PlayResX", str(play_res_x)),
            ("PlayResY", str(play_res_y)),
            *extra_fields,
        ]
    )
