"""Tests for spring motion in the shad and fbf helper families."""

from __future__ import annotations

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.exceptions import PykaraValidationError
from pykara.helpers.motion import MotionHelper
from pykara.motion.spring.request import SpringFbfRequest


def test_shad_spring_returns_nonempty_string() -> None:
    """motion.shad.spring() should return a non-empty string in line runtime."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.spring(100, 400, 800, 400)
    assert isinstance(result, str)
    assert len(result) > 0
    assert r"\t(" in result


def test_shad_spring_requires_line_runtime() -> None:
    """motion.shad.spring() should raise a library validation error without line."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.shad\.spring\(\) requires line runtime",
    ):
        MotionHelper(runtime).shad.spring(100, 400, 800, 400)


def test_shad_spring_segments_param_is_forwarded() -> None:
    """The segments argument should control the number of \\t tags."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    motion = MotionHelper(runtime)

    result_8 = motion.shad.spring(100, 400, 800, 400, segments=8)
    result_24 = motion.shad.spring(100, 400, 800, 400, segments=24)
    assert result_8.count(r"\t(") == 16
    assert result_24.count(r"\t(") == 48


def test_shad_spring_default_segments_is_48() -> None:
    """motion.shad.spring() default should produce 48 segments (96 \\t tags)."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.spring(100, 400, 800, 400)
    assert result.count(r"\t(") == 96


def test_fbf_spring_queues_request_and_returns_empty_string() -> None:
    """motion.fbf.spring() should queue a SpringFbfRequest and return ''."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line, framerate=24.0)

    result = MotionHelper(runtime).fbf.spring(100, 400, 800, 400)
    assert result == ""
    assert runtime.consume_fbf_request() == SpringFbfRequest(
        x0=100,
        y0=400,
        x1=800,
        y1=400,
    )


def test_fbf_spring_queues_request_with_custom_params() -> None:
    """motion.fbf.spring() should forward all optional parameters."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line, framerate=24.0)

    MotionHelper(runtime).fbf.spring(
        100,
        400,
        800,
        400,
        amplitude=2.0,
        damping=5.0,
        freq=8.0,
    )
    assert runtime.consume_fbf_request() == SpringFbfRequest(
        x0=100,
        y0=400,
        x1=800,
        y1=400,
        amplitude=2.0,
        damping=5.0,
        freq=8.0,
    )


def test_fbf_spring_requires_line_runtime() -> None:
    """motion.fbf.spring() should raise a library validation error without line."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.spring\(\) requires line runtime",
    ):
        MotionHelper(runtime).fbf.spring(100, 400, 800, 400)


def test_fbf_spring_requires_framerate() -> None:
    """motion.fbf.spring() should raise a library validation error without FPS."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.spring\(\) requires explicit timecodes or PlaybackFPS",
    ):
        MotionHelper(runtime).fbf.spring(100, 400, 800, 400)
