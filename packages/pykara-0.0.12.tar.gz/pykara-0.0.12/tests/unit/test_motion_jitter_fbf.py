"""Tests for the frame-baked jitter effect helpers."""

from __future__ import annotations

import pytest
from tests.support import make_motion_event

from pykara.exceptions import PykaraValidationError
from pykara.motion.jitter.fbf import jitter_fbf_line, validate_jitter_line
from pykara.motion.jitter.request import JitterFbfRequest


def test_jitter_fbf_line_expands_one_line_to_pos_jittered_frames() -> None:
    r"""FBF jitter should emit one `\pos(...)` line per frame bucket."""
    line = make_motion_event(r"{\an5}X")

    result = jitter_fbf_line(
        line,
        24.0,
        640,
        360,
        left=1,
        right=1,
        up=0,
        down=1,
        period_ms=100,
        seed=7,
    )

    assert len(result) == 24
    assert result[0].start_time == 1000
    assert result[-1].end_time == 2000
    assert all(r"\pos(" in generated.text for generated in result)
    assert result[0].text == r"{\an5\pos(639,360)}X"
    assert result[1].text == r"{\an5\pos(639,360)}X"
    assert result[2].text == r"{\an5\pos(640,360)}X"


def test_jitter_fbf_line_prepends_pos_block_when_text_has_no_tags() -> None:
    """FBF jitter should prepend a fresh override block when none exists."""
    line = make_motion_event("X", 1000, 1100)

    result = jitter_fbf_line(
        line,
        24.0,
        320,
        240,
        left=0,
        right=0,
        up=0,
        down=0,
        period_ms=100,
        seed=0,
    )

    assert result[0].text == r"{\pos(320,240)}X"


def test_jitter_fbf_line_uses_existing_pos_as_the_jitter_base() -> None:
    r"""Existing ``\pos`` tags should override the fallback x/y base position."""
    line = make_motion_event(r"{\an5\pos(100,200)}X", 1000, 1100)

    result = jitter_fbf_line(
        line,
        24.0,
        320,
        240,
        left=0,
        right=0,
        up=0,
        down=0,
        period_ms=100,
        seed=0,
    )

    assert result[0].text == r"{\an5\pos(100,200)}X"


def test_jitter_fbf_line_rejects_invalid_step() -> None:
    """Jitter expansion should reject non-positive frame grouping."""
    with pytest.raises(
        PykaraValidationError,
        match=r"frame-baked jitter step must be >= 1",
    ):
        jitter_fbf_line(make_motion_event("X"), 24.0, 0, 0, step=0)


def test_validate_jitter_line_rejects_move_tags() -> None:
    r"""Frame-baked jitter should reject lines that still use `\move`."""
    with pytest.raises(
        PykaraValidationError,
        match=r"frame-baked jitter cannot be combined with \\move",
    ):
        validate_jitter_line(make_motion_event(r"{\move(1,2,3,4)}X"))


def test_jitter_fbf_request_expands_lines() -> None:
    """The queued request should delegate expansion to the jitter helper."""
    request = JitterFbfRequest(640, 360, 1, 1, 0, 1, 100, 7)

    result = request.expand(make_motion_event(r"{\an5}X"), 24.0)

    assert len(result) == 24
    assert result[0].text == r"{\an5\pos(639,360)}X"
