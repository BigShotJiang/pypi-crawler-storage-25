"""Tests for the shadow-trick arc motion builder."""

from __future__ import annotations

from pykara.motion.arc.shad import build_shad_arc


def test_build_shad_arc_returns_nonempty_string() -> None:
    """Arc shad builder should return a non-empty tag string."""
    result = build_shad_arc(1000, 500, 400, 500, 400, 500, 400, 0, 180, 100, 100)
    assert isinstance(result, str)
    assert len(result) > 0


def test_build_shad_arc_contains_t_segments() -> None:
    r"""Arc shad should emit ``\t(`` sequences."""
    result = build_shad_arc(1000, 500, 400, 500, 400, 500, 400, 0, 180, 100, 100)
    assert r"\t(" in result


def test_build_shad_arc_segments_param_controls_t_count() -> None:
    """More segments should produce more ``\\t`` tags."""
    result_8 = build_shad_arc(
        1000, 500, 400, 500, 400, 500, 400, 0, 180, 100, 100, segments=8
    )
    result_16 = build_shad_arc(
        1000, 500, 400, 500, 400, 500, 400, 0, 180, 100, 100, segments=16
    )
    assert result_8.count(r"\t(") == 16
    assert result_16.count(r"\t(") == 32


def test_build_shad_arc_first_position_matches_angle_at_zero() -> None:
    r"""First fix-start ``\t`` should encode start-angle position."""
    result = build_shad_arc(1000, 500, 400, 500, 400, 500, 400, 0, 180, 100, 100)
    assert r"\t(0,0,\xshad100\yshad0)" in result


def test_build_shad_arc_t1_t2_none_defaults_to_full_duration() -> None:
    """Omitting t1/t2 should span the full duration."""
    result_none = build_shad_arc(1000, 500, 400, 500, 400, 500, 400, 0, 180, 100, 100)
    result_explicit = build_shad_arc(
        1000, 500, 400, 500, 400, 500, 400, 0, 180, 100, 100, t1=0, t2=1000
    )
    assert result_none.count(r"\t(") == result_explicit.count(r"\t(")


def test_build_shad_arc_xshad_zero_replaced_with_minimum() -> None:
    r"""``\xshad0`` must be ``\xshad0.001`` to keep shadow active."""

    result = build_shad_arc(
        1000, 500, 400, 500, 400, 500, 400, 90, 90, 100, 100, segments=1
    )
    assert r"\xshad0\y" not in result


def test_build_shad_arc_degree_to_radian_conversion() -> None:
    """Degrees should be converted to radians before computing arc_xy."""
    result_0 = build_shad_arc(
        1000, 500, 400, 500, 400, 500, 400, 0, 0, 100, 100, segments=1
    )
    assert r"\xshad100" in result_0

    result_180 = build_shad_arc(
        1000, 500, 400, 500, 400, 500, 400, 180, 180, 100, 100, segments=1
    )
    assert r"\xshad-100" in result_180
