"""Tests for character decomposition."""

from pykara.karaoke.char import split_chars
from pykara.karaoke.syllable import Syllable
from pykara.karaoke.word import split_words


def test_split_chars_links_word_and_syllable_references() -> None:
    """Each char should point to both its word and syllable."""
    syllables = [
        Syllable(0, 200, 200, 20, "ab ", r"\k", "", si=1, ci=1),
        Syllable(200, 400, 200, 20, "cd", r"\k", "", si=2, ci=4),
    ]
    words = split_words(syllables)

    chars = split_chars(syllables, words)

    assert [char.text for char in chars] == ["a", "b", " ", "c", "d"]
    assert [(char.ci, char.si, char.wi) for char in chars] == [
        (1, 1, 1),
        (2, 1, 1),
        (3, 1, 1),
        (4, 2, 2),
        (5, 2, 2),
    ]
    assert chars[0].syl is syllables[0]
    assert chars[0].word is words[0]
    assert chars[-1].syl is syllables[1]
    assert chars[-1].word is words[1]
