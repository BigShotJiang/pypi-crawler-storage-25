"""Tests for ASS time helpers."""

from pykara.ass.time import format_ass_time, parse_ass_time


def test_parse_ass_time_golden_values() -> None:
    """parse_ass_time should decode centisecond timestamps."""
    assert parse_ass_time("0:00:00.00") == 0
    assert parse_ass_time("0:00:17.19") == 17_190
    assert parse_ass_time("1:02:03.45") == 3_723_450


def test_format_ass_time_round_trip() -> None:
    """Formatting a parsed ASS timestamp should reproduce the original text."""
    cases = ["0:00:00.00", "0:00:21.34", "1:02:03.45", "12:34:56.78"]
    assert [format_ass_time(parse_ass_time(case)) for case in cases] == cases
