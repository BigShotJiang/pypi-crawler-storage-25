"""Tests for the frame-baked wave motion builder."""

from __future__ import annotations

import re

import pytest
from tests.support import make_motion_event

from pykara.motion.wave.fbf import wave_fbf_line
from pykara.motion.wave.request import WaveFbfRequest


def test_wave_fbf_line_returns_correct_frame_count() -> None:
    """Wave FBF should produce one frame per frame bucket."""
    line = make_motion_event(r"{\an5}X")
    result = wave_fbf_line(line, 24.0, 100, 900, 400)
    assert len(result) == 24


def test_wave_fbf_line_each_frame_has_pos() -> None:
    r"""Every FBF wave frame should contain a ``\pos(`` tag."""
    line = make_motion_event(r"{\an5}X")
    result = wave_fbf_line(line, 24.0, 100, 900, 400)
    assert all(r"\pos(" in frame.text for frame in result)


def test_wave_fbf_line_start_x_near_x0() -> None:
    r"""First frame x should be close to x0."""
    line = make_motion_event(r"{\an5}X")
    result = wave_fbf_line(line, 24.0, 100, 900, 400, amplitude=0)
    m = re.search(r"\\pos\(([\d.-]+)", result[0].text)
    assert m is not None
    x = float(m.group(1))
    assert x == pytest.approx(100.0, abs=30.0)


def test_wave_fbf_line_end_x_near_x1() -> None:
    r"""Last frame x should be close to x1."""
    line = make_motion_event(r"{\an5}X")
    result = wave_fbf_line(line, 24.0, 100, 900, 400, amplitude=0)
    m = re.search(r"\\pos\(([\d.-]+)", result[-1].text)
    assert m is not None
    x = float(m.group(1))
    assert x == pytest.approx(900.0, abs=30.0)


def test_wave_fbf_line_timing_is_correct() -> None:
    """FBF frames should cover the full line interval."""
    line = make_motion_event(r"{\an5}X")
    result = wave_fbf_line(line, 24.0, 100, 900, 400)
    assert result[0].start_time == 1000
    assert result[-1].end_time == 2000


def test_wave_fbf_line_zero_amplitude_stays_at_y_base() -> None:
    """With zero amplitude, all frames should have y == y_base."""
    line = make_motion_event(r"{\an5}X")
    result = wave_fbf_line(line, 24.0, 100, 900, 400, amplitude=0)
    for frame in result:
        m = re.search(r"\\pos\([\d.-]+,([\d.-]+)\)", frame.text)
        assert m is not None
        y = float(m.group(1))
        assert y == pytest.approx(400.0, abs=0.1)


def test_wave_fbf_line_t1_t2_none_defaults_to_full_duration() -> None:
    """Omitting t1/t2 should use the full line duration."""
    line = make_motion_event(r"{\an5}X")
    result = wave_fbf_line(line, 24.0, 100, 900, 400)
    assert len(result) == 24


def test_wave_fbf_request_expands_correctly() -> None:
    """WaveFbfRequest.expand() should delegate to wave_fbf_line."""
    request = WaveFbfRequest(x0=100, x1=900, y_base=400)
    result = request.expand(make_motion_event(r"{\an5}X"), 24.0)
    assert len(result) == 24
    assert all(r"\pos(" in frame.text for frame in result)
