"""Error-path tests for directive parsing."""

import pytest

from pykara.directive.parser import parse_directive
from pykara.exceptions import PykaraValidationError


@pytest.mark.parametrize(
    ("effect", "pattern"),
    [
        ("template nope", "Invalid scope"),
        ("template syl no_blankx", "Unexpected trailing directive text"),
        ("template syl prepend", "Unexpected trailing directive text"),
        ("template syl layer 1", "Unexpected trailing directive text"),
        ("template syl for actor", "Unexpected trailing directive text"),
        ("template syl repeat nope", "Invalid repeat count"),
        ("template syl repeat Outer 2", "Invalid repeat name"),
        ("template syl repeat 0", "Invalid repeat count"),
        ("template syl inline_fx 123", "Invalid inline_fx"),
        ("template syl when", "missing condition"),
        ("template syl when Enabled", "Invalid condition token"),
        ("template syl unless has-value", "Invalid condition token"),
        ("template syl when enabled trailing", "Invalid condition token"),
        ("template syl when (a) trailing", "when/unless condition must be last"),
        ("template syl when (", "Invalid condition expression"),
        ('template syl when ("a\\"b")', None),
        ("template syl stray", "Unexpected trailing directive text"),
        ("patch nope", "Invalid scope"),
        ("patch syl no_text", "Unexpected trailing directive text"),
        ("patch syl multi", "Unexpected trailing directive text"),
        ("patch syl repeat 2", "Unexpected trailing directive text"),
        ("patch syl layer nope", "Invalid layer"),
        ("patch syl for", "expected token"),
        ("patch syl inline_fx 123", "Invalid inline_fx"),
        ("patch syl when Enabled", "Invalid condition token"),
        ("patch syl when enabled unless blocked", "Invalid condition token"),
        ("patch syl unless enabled when blocked", "Invalid condition token"),
        ("patch syl prepend stray", "Unexpected trailing directive text"),
        ('patch syl when ("a\\"b")', None),
        ("code setup extra", "code directives do not accept modifiers"),
        ("code line prepend", "code directives do not accept modifiers"),
        ("code line layer 1", "code directives do not accept modifiers"),
        ("code line for actor", "code directives do not accept modifiers"),
        ("code", "expected token"),
        ("code once extra", r"Invalid scope: 'once'"),
    ],
)
def test_parse_directive_error_paths(effect: str, pattern: str | None) -> None:
    """Directive parser should exercise remaining edge branches."""
    if pattern is None:
        assert parse_directive(effect) is not None
        return

    with pytest.raises(PykaraValidationError, match=pattern):
        parse_directive(effect)
