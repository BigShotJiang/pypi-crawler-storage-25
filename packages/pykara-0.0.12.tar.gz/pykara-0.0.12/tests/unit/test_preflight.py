"""Tests for pre-flight document validation."""

from __future__ import annotations

import pytest

from pykara.ass.types import AssDocument, DialogueLine, EventType, ScriptInfo
from pykara.engine.preflight import PreflightViolationError, preflight


def _doc(*comment_events: tuple[str, str]) -> AssDocument:
    """Build a minimal AssDocument from (effect, text) comment pairs."""
    events = [
        DialogueLine(
            event_type=EventType.COMMENT,
            layer=0,
            start_time=0,
            end_time=1000,
            style="Default",
            name="",
            margin_l=0,
            margin_r=0,
            margin_v=0,
            effect=effect,
            text=text,
        )
        for effect, text in comment_events
    ]
    return AssDocument(
        script_info=ScriptInfo(fields=[]),
        styles=[],
        events=events,
        other_sections=[],
        section_order=[],
        style_format=[],
        event_format=[],
    )


def test_preflight_passes_empty_document() -> None:
    """An empty document should pass pre-flight without error."""
    preflight(_doc())


def test_preflight_passes_fbf_without_pos_or_move() -> None:
    r"""motion.fbf.* without \pos or \move should pass."""
    preflight(_doc(("template line", r"{\an5}!motion.fbf.arc(0,0,100,100)!")))


def test_preflight_passes_shad_without_shad_tag() -> None:
    r"""motion.shad.* without \shad should pass."""
    preflight(_doc(("template line", r"{\an5}!motion.shad.arc(0,0,100,100)!")))


def test_preflight_passes_pos_without_fbf() -> None:
    r"""A template with \pos but no motion.fbf should pass."""
    preflight(_doc(("template line", r"{\pos(640,360)}text")))


def test_preflight_passes_shad_tag_without_shad_motion() -> None:
    r"""A template with \shad but no motion.shad should pass."""
    preflight(_doc(("template line", r"{\shad3}text")))


def test_preflight_rejects_fbf_with_pos() -> None:
    r"""motion.fbf.* combined with \pos must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(("template line", r"{\pos(640,360)}!motion.fbf.arc(0,0,100,100)!"))
        )
    assert r"\pos" in str(exc_info.value)


def test_preflight_rejects_fbf_with_move() -> None:
    r"""motion.fbf.* combined with \move must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template line", r"{\move(0,0,100,100)}!motion.fbf.arc(0,0,100,100)!")
            )
        )
    assert r"\move" in str(exc_info.value)


def test_preflight_rejects_fbf_pos_and_move_reports_both() -> None:
    r"""Both \pos and \move conflicts should be reported in one pass."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                (
                    "template line",
                    r"{\pos(1,2)\move(0,0,100,100)}!motion.fbf.arc(0,0,100,100)!",
                )
            )
        )
    assert len(exc_info.value.errors) == 2


def test_preflight_rejects_fbf_jitter_with_pos() -> None:
    r"""motion.fbf.jitter combined with \pos must also be rejected."""
    with pytest.raises(PreflightViolationError):
        preflight(
            _doc(
                (
                    "template line",
                    r"{\pos(640,360)}!motion.fbf.jitter(10,10,10,10,100)!",
                )
            )
        )


def test_preflight_rejects_shad_motion_with_shad_tag() -> None:
    r"""motion.shad.* combined with \shad must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(_doc(("template line", r"{\shad5}!motion.shad.arc(0,0,100,100)!")))
    assert r"\shad" in str(exc_info.value)


def test_preflight_rejects_shad_motion_with_xshad() -> None:
    r"""motion.shad.* combined with \xshad must be rejected."""
    with pytest.raises(PreflightViolationError):
        preflight(_doc(("template line", r"{\xshad3}!motion.shad.arc(0,0,100,100)!")))


def test_preflight_rejects_shad_motion_with_yshad() -> None:
    r"""motion.shad.* combined with \yshad must be rejected."""
    with pytest.raises(PreflightViolationError):
        preflight(
            _doc(("template line", r"{\yshad3}!motion.shad.jitter(10,10,10,10,100)!"))
        )


def test_preflight_collects_errors_across_templates() -> None:
    """Errors from multiple templates should all be reported together."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template line", r"{\pos(640,360)}!motion.fbf.arc(0,0,100,100)!"),
                ("template line", r"{\shad5}!motion.shad.jitter(10,10,10,10,100)!"),
            )
        )
    assert len(exc_info.value.errors) == 2


def test_preflight_violation_message_includes_effect() -> None:
    """The exception message should include the source effect string."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(("template line", r"{\pos(640,360)}!motion.fbf.arc(0,0,100,100)!"))
        )
    assert "template line" in str(exc_info.value)


def test_preflight_rejects_two_fbf_calls_in_template_body() -> None:
    """Two motion.fbf.* calls in the same template body must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                (
                    "template line",
                    r"!motion.fbf.arc(0,0,100,100)!!motion.fbf.spring(0,0,100,100)!",
                )
            )
        )
    assert any("once" in e.message for e in exc_info.value.errors)


def test_preflight_rejects_two_shad_calls_in_template_body() -> None:
    """Two motion.shad.* calls in the same template body must be rejected."""
    with pytest.raises(PreflightViolationError):
        preflight(
            _doc(
                (
                    "template line",
                    r"!motion.shad.arc(0,0,100,100)!!motion.shad.spring(0,0,100,100)!",
                )
            )
        )


def test_preflight_rejects_fbf_split_across_patches() -> None:
    """motion.fbf.* in template + patch counts as two calls — must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template line", r"!motion.fbf.arc(0,0,100,100)!"),
                ("patch line", r"!motion.fbf.spring(0,0,100,100)!"),
            )
        )
    assert any("once" in e.message for e in exc_info.value.errors)


def test_preflight_rejects_fbf_across_two_patches() -> None:
    """Two patches targeting the same template each with motion.fbf.* must be
    rejected."""
    with pytest.raises(PreflightViolationError):
        preflight(
            _doc(
                ("template line", r"text"),
                ("patch line", r"!motion.fbf.arc(0,0,100,100)!"),
                ("patch line", r"!motion.fbf.spring(0,0,100,100)!"),
            )
        )


def test_preflight_rejects_shad_split_across_patches() -> None:
    """motion.shad.* in template + patch counts as two calls — must be rejected."""
    with pytest.raises(PreflightViolationError):
        preflight(
            _doc(
                ("template line", r"!motion.shad.arc(0,0,100,100)!"),
                ("patch line", r"!motion.shad.spring(0,0,100,100)!"),
            )
        )


def test_preflight_passes_one_fbf_in_patch_only() -> None:
    """A single motion.fbf.* in a patch (none in template) should pass."""
    preflight(
        _doc(
            ("template line", r"text"),
            ("patch line", r"!motion.fbf.arc(0,0,100,100)!"),
        )
    )


def test_preflight_passes_one_shad_in_patch_only() -> None:
    """A single motion.shad.* in a patch (none in template) should pass."""
    preflight(
        _doc(
            ("template line", r"text"),
            ("patch line", r"!motion.shad.arc(0,0,100,100)!"),
        )
    )


def test_preflight_rejects_fbf_in_patch_with_pos_in_template() -> None:
    r"""motion.fbf.* in patch + \pos in template must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template line", r"{\pos(640,360)}text"),
                ("patch line", r"!motion.fbf.arc(0,0,100,100)!"),
            )
        )
    assert r"\pos" in str(exc_info.value)


def test_preflight_rejects_fbf_in_template_with_pos_in_patch() -> None:
    r"""motion.fbf.* in template + \pos in patch must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template line", r"!motion.fbf.arc(0,0,100,100)!"),
                ("patch line", r"{\pos(640,360)}"),
            )
        )
    assert r"\pos" in str(exc_info.value)


def test_preflight_rejects_fbf_in_patch_with_move_in_template() -> None:
    r"""motion.fbf.* in patch + \move in template must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template line", r"{\move(0,0,100,100)}text"),
                ("patch line", r"!motion.fbf.arc(0,0,100,100)!"),
            )
        )
    assert r"\move" in str(exc_info.value)


def test_preflight_rejects_shad_motion_in_patch_with_shad_tag_in_template() -> None:
    r"""motion.shad.* in patch + \shad in template must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template line", r"{\shad3}text"),
                ("patch line", r"!motion.shad.arc(0,0,100,100)!"),
            )
        )
    assert r"\shad" in str(exc_info.value)


def test_preflight_rejects_shad_motion_in_template_with_shad_tag_in_patch() -> None:
    r"""motion.shad.* in template + \shad in patch must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template line", r"!motion.shad.arc(0,0,100,100)!"),
                ("patch line", r"{\xshad3}"),
            )
        )
    assert r"\shad" in str(exc_info.value)


def test_preflight_rejects_two_fbf_calls_in_syl_template_and_patch() -> None:
    """motion.fbf.* once in template syl + once in patch syl must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template syl", r"!motion.fbf.arc(0,0,100,100)!"),
                ("patch syl", r"!motion.fbf.spring(0,0,100,100)!"),
            )
        )
    assert any("once" in e.message for e in exc_info.value.errors)


def test_preflight_rejects_two_shad_calls_in_syl_template_and_patch() -> None:
    """motion.shad.* once in template syl + once in patch syl must be rejected."""
    with pytest.raises(PreflightViolationError):
        preflight(
            _doc(
                ("template syl", r"!motion.shad.arc(0,0,100,100)!"),
                ("patch syl", r"!motion.shad.spring(0,0,100,100)!"),
            )
        )


def test_preflight_rejects_fbf_in_syl_patch_with_pos_in_syl_template() -> None:
    r"""motion.fbf.* in patch syl + \pos in template syl must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template syl", r"{\pos(640,360)}text"),
                ("patch syl", r"!motion.fbf.arc(0,0,100,100)!"),
            )
        )
    assert r"\pos" in str(exc_info.value)


def test_preflight_rejects_shad_in_char_patch_with_shad_in_char_template() -> None:
    r"""motion.shad.* in patch char + \shad in template char must be rejected."""
    with pytest.raises(PreflightViolationError) as exc_info:
        preflight(
            _doc(
                ("template char", r"{\shad3}text"),
                ("patch char", r"!motion.shad.arc(0,0,100,100)!"),
            )
        )
    assert r"\shad" in str(exc_info.value)


def test_preflight_syl_patch_does_not_match_line_template() -> None:
    """patch syl must not be matched against template line — different scopes."""

    preflight(
        _doc(
            ("template line", r"!motion.fbf.arc(0,0,100,100)!"),
            ("template syl", r"text"),
            ("patch syl", r"!motion.fbf.spring(0,0,100,100)!"),
        )
    )
