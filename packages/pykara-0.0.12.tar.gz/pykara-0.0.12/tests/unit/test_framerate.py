"""Tests for frame/time conversions."""

from __future__ import annotations

from pathlib import Path

import pytest
from tests.support import make_script_info

from pykara.ass.types import AssDocument, RawSection
from pykara.exceptions import PykaraValidationError
from pykara.timing import Framerate, load_timecodes, resolve_framerate


def test_load_timecodes_reads_reference_fixture(fixtures_dir: Path) -> None:
    """The loader should parse the bundled reference fixture."""
    path = fixtures_dir / "timecodes" / "crf_timecodes.txt"

    framerate = load_timecodes(path)

    assert framerate.frame_count == 480
    assert framerate.time_at_frame(0) == 0
    assert framerate.time_at_frame(1) == 42
    assert framerate.time_at_frame(479) == 19978


def test_frame_at_time_uses_current_frame_window(fixtures_dir: Path) -> None:
    """Times between two frame starts should map to the previous frame."""
    path = fixtures_dir / "timecodes" / "crf_timecodes.txt"
    framerate = load_timecodes(path)

    assert framerate.frame_at_time(0) == 0
    assert framerate.frame_at_time(41) == 0
    assert framerate.frame_at_time(42) == 1
    assert framerate.frame_at_time(19978) == 479


def test_load_timecodes_reads_vfr_fixture(fixtures_dir: Path) -> None:
    """The loader should parse the bundled variable-framerate fixture."""
    path = fixtures_dir / "timecodes" / "vrf_timecodes.txt"

    framerate = load_timecodes(path)

    assert framerate.frame_count == 116_044
    assert framerate.time_at_frame(0) == 0
    assert framerate.time_at_frame(1) == 42
    assert framerate.time_at_frame(10) == 417
    assert framerate.time_at_frame(1_000) == 35_102
    assert framerate.time_at_frame(116_043) == 2_432_580


def test_frame_at_time_uses_vfr_windows(fixtures_dir: Path) -> None:
    """Variable frame durations should still map to the current frame window."""
    path = fixtures_dir / "timecodes" / "vrf_timecodes.txt"
    framerate = load_timecodes(path)

    assert framerate.frame_at_time(417) == 10
    assert framerate.frame_at_time(418) == 10
    assert framerate.frame_at_time(419) == 10
    assert framerate.frame_at_time(42_310) == 1_432
    assert framerate.frame_at_time(2_137_926) == 99_558


def test_time_at_frame_extrapolates_after_known_range() -> None:
    """Frames beyond the known table should use the last frame duration."""
    framerate = Framerate((0, 40, 80))

    assert framerate.time_at_frame(3) == 120
    assert framerate.time_at_frame(5) == 200


def test_frame_at_time_extrapolates_after_known_range() -> None:
    """Times beyond the known table should use the last frame duration."""
    framerate = Framerate((0, 40, 80))

    assert framerate.frame_at_time(80) == 2
    assert framerate.frame_at_time(119) == 2
    assert framerate.frame_at_time(120) == 3
    assert framerate.frame_at_time(200) == 5


def test_vfr_extrapolates_after_known_range(fixtures_dir: Path) -> None:
    """VFR lookup should extrapolate using the final known frame duration."""
    path = fixtures_dir / "timecodes" / "vrf_timecodes.txt"
    framerate = load_timecodes(path)

    assert framerate.time_at_frame(116_044) == 2_432_597
    assert framerate.time_at_frame(116_050) == 2_432_699
    assert framerate.frame_at_time(2_432_596) == 116_043
    assert framerate.frame_at_time(2_432_597) == 116_044
    assert framerate.frame_at_time(2_432_699) == 116_050


def test_framerate_rejects_invalid_inputs(tmp_path: Path) -> None:
    """Invalid file formats and negative frame indexes should fail."""
    invalid_file = tmp_path / "bad.txt"
    invalid_file.write_text("invalid-header\n0\n", encoding="utf-8")

    with pytest.raises(PykaraValidationError):
        load_timecodes(invalid_file)

    with pytest.raises(PykaraValidationError):
        Framerate(())

    with pytest.raises(PykaraValidationError):
        Framerate((10, 5))

    with pytest.raises(PykaraValidationError):
        Framerate((0,)).time_at_frame(-1)


def test_load_timecodes_rejects_empty_and_comment_only_payloads(
    tmp_path: Path,
) -> None:
    """The loader should reject empty and comment-only bodies."""
    empty_file = tmp_path / "empty.txt"
    empty_file.write_text("", encoding="utf-8")

    with pytest.raises(PykaraValidationError, match="empty"):
        load_timecodes(empty_file)

    comment_only_file = tmp_path / "comments.txt"
    comment_only_file.write_text(
        "# timecode format\n\n# comment\n",
        encoding="utf-8",
    )

    with pytest.raises(
        PykaraValidationError,
        match="does not contain any frame timestamps",
    ):
        load_timecodes(comment_only_file)


def test_single_frame_framerate_uses_zero_duration_extrapolation() -> None:
    """A single known frame should clamp all extrapolation to that frame time."""
    framerate = Framerate((123,))

    assert framerate.last_frame_duration == 0
    assert framerate.frame_at_time(999) == 0
    assert framerate.time_at_frame(5) == 123


def test_resolve_framerate_prefers_explicit_timecodes() -> None:
    """An explicit mapping should override script and project metadata."""
    explicit = Framerate((0, 40, 80))
    document = AssDocument(
        script_info=make_script_info(extra_fields=[("PlaybackFPS", "23.976")]),
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=["Video File: ?dummy:29.970000:40000:1280:720:0:0:0:"],
            )
        ],
    )

    resolved = resolve_framerate(document, explicit)

    assert resolved is explicit


def test_resolve_framerate_uses_playback_fps_before_dummy_video() -> None:
    """PlaybackFPS should win over dummy-video metadata when both exist."""
    document = AssDocument(
        script_info=make_script_info(extra_fields=[("PlaybackFPS", "23.976")]),
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=["Video File: ?dummy:29.970000:40000:1280:720:0:0:0:"],
            )
        ],
    )

    resolved = resolve_framerate(document)

    assert resolved == pytest.approx(23.976)


def test_resolve_framerate_uses_last_playback_fps_value() -> None:
    """Script-info resolution should use the last effective PlaybackFPS field."""
    document = AssDocument(
        script_info=make_script_info(
            extra_fields=[
                ("PlaybackFPS", "23.976"),
                ("PlaybackFPS", "24000/1001"),
            ]
        )
    )

    resolved = resolve_framerate(document)

    assert resolved == pytest.approx(24000 / 1001)


def test_resolve_framerate_falls_back_to_dummy_video_decimal_fps() -> None:
    """Dummy-video metadata should provide a constant FPS when needed."""
    document = AssDocument(
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=["Video File: ?dummy:23.976000:40000:1280:720:47:163:254:"],
            )
        ]
    )

    resolved = resolve_framerate(document)

    assert resolved == pytest.approx(23.976)


def test_resolve_framerate_accepts_dummy_video_fractional_fps() -> None:
    """Dummy-video metadata should also accept rational FPS values."""
    document = AssDocument(
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=["Video File: ?dummy:24000/1001:40000:1920:1080:47:163:254:"],
            )
        ]
    )

    resolved = resolve_framerate(document)

    assert resolved == pytest.approx(24000 / 1001)


def test_resolve_framerate_uses_last_dummy_video_value() -> None:
    """Aegisub raw sections should resolve the last effective Video File value."""
    document = AssDocument(
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=[
                    "Video File: ?dummy:23.976000:40000:1280:720:47:163:254:",
                    "Video File: ?dummy:24:40000:1280:720:47:163:254:",
                ],
            )
        ]
    )

    resolved = resolve_framerate(document)

    assert resolved == pytest.approx(24.0)


def test_resolve_framerate_ignores_comments_and_invalid_raw_lines() -> None:
    """Raw project metadata should ignore comments and malformed lines."""
    document = AssDocument(
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=[
                    "; comment",
                    "not a field",
                    "Video File: ?dummy:24:40000:1280:720:47:163:254:",
                ],
            )
        ]
    )

    resolved = resolve_framerate(document)

    assert resolved == pytest.approx(24.0)


def test_resolve_framerate_ignores_non_video_project_fields() -> None:
    """Raw project metadata without a Video File entry should not resolve."""
    document = AssDocument(
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=["Audio File: /tmp/audio.flac"],
            )
        ]
    )

    assert resolve_framerate(document) is None


def test_resolve_framerate_ignores_non_dummy_video_metadata() -> None:
    """A regular video path should not be treated as a frame source."""
    document = AssDocument(
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=["Video File: /tmp/video.mkv"],
            )
        ]
    )

    assert resolve_framerate(document) is None


def test_resolve_framerate_rejects_invalid_playback_fps() -> None:
    """Malformed PlaybackFPS values should fail instead of being ignored."""
    document = AssDocument(
        script_info=make_script_info(extra_fields=[("PlaybackFPS", "abc")])
    )

    with pytest.raises(PykaraValidationError, match="Invalid PlaybackFPS FPS"):
        resolve_framerate(document)


def test_resolve_framerate_rejects_non_finite_playback_fps() -> None:
    """Non-finite PlaybackFPS values should fail."""
    document = AssDocument(
        script_info=make_script_info(extra_fields=[("PlaybackFPS", "nan")])
    )

    with pytest.raises(PykaraValidationError, match="Invalid PlaybackFPS FPS"):
        resolve_framerate(document)


def test_resolve_framerate_rejects_invalid_dummy_video_fps() -> None:
    """Malformed dummy-video FPS values should fail instead of being ignored."""
    document = AssDocument(
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=["Video File: ?dummy:not-a-number:40000:1280:720:0:0:0:"],
            )
        ]
    )

    with pytest.raises(PykaraValidationError, match="Invalid dummy video FPS"):
        resolve_framerate(document)


def test_resolve_framerate_requires_metadata_when_no_source_exists() -> None:
    """Frame-based processing should fail when no source can be resolved."""
    assert resolve_framerate(AssDocument()) is None
