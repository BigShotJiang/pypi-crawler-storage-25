"""Tests for arc motion in the shad and fbf helper families."""

from __future__ import annotations

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.exceptions import PykaraValidationError
from pykara.helpers.motion import MotionHelper
from pykara.motion.arc.request import ArcFbfRequest


def test_shad_arc_returns_nonempty_string() -> None:
    """motion.shad.arc() should return a non-empty string in line runtime."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.arc(500, 400, 500, 400, 0, 180, 100, 100)
    assert isinstance(result, str)
    assert len(result) > 0
    assert r"\t(" in result


def test_shad_arc_requires_line_runtime() -> None:
    """motion.shad.arc() should raise a library validation error without line."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.shad\.arc\(\) requires line runtime",
    ):
        MotionHelper(runtime).shad.arc(500, 400, 500, 400, 0, 180, 100, 100)


def test_shad_arc_uses_motion_anchor() -> None:
    """motion.shad.arc() should use motion_anchor for offset calculation."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 640
    line.y = 360
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.arc(640, 360, 640, 360, 0, 0, 100, 100)

    assert r"\xshad100" in result


def test_shad_arc_segments_param_is_forwarded() -> None:
    """The segments argument should control the number of \\t tags."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    motion = MotionHelper(runtime)

    result_8 = motion.shad.arc(500, 400, 500, 400, 0, 180, 100, 100, segments=8)
    result_16 = motion.shad.arc(500, 400, 500, 400, 0, 180, 100, 100, segments=16)
    assert result_8.count(r"\t(") == 16
    assert result_16.count(r"\t(") == 32


def test_fbf_arc_queues_request_and_returns_empty_string() -> None:
    """motion.fbf.arc() should queue an ArcFbfRequest and return ''."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line, framerate=24.0)

    result = MotionHelper(runtime).fbf.arc(100, 400, 800, 400, 0, 180, 50, 100)
    assert result == ""
    assert runtime.consume_fbf_request() == ArcFbfRequest(
        x1=100, y1=400, x2=800, y2=400, a1=0, a2=180, r1=50, r2=100
    )


def test_fbf_arc_requires_line_runtime() -> None:
    """motion.fbf.arc() should raise a library validation error without line."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.arc\(\) requires line runtime",
    ):
        MotionHelper(runtime).fbf.arc(100, 400, 800, 400)


def test_fbf_arc_requires_framerate() -> None:
    """motion.fbf.arc() should raise a library validation error without FPS."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.arc\(\) requires explicit timecodes or PlaybackFPS",
    ):
        MotionHelper(runtime).fbf.arc(100, 400, 800, 400)
