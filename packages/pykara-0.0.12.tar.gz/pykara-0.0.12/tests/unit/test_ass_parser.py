"""Tests for the ASS parser."""

from pathlib import Path

from pykara.ass.parser import read_ass
from pykara.ass.types import EventType


def test_read_ass_parses_core_sections_and_preserves_raw_sections(
    karaoke_reference_dir: Path,
) -> None:
    """The parser should read core sections and keep unknown sections in order."""
    document = read_ass(karaoke_reference_dir / "karaoke.ass")

    assert document.section_order == ["script_info", "raw:0", "styles", "events"]
    assert document.script_info.fields[0] == ("Title", "Default Aegisub file")
    assert document.other_sections[0].name == "Aegisub Project Garbage"
    assert document.other_sections[0].lines[0] == "Last Style Storage: Default"

    assert len(document.styles) == 1
    style = document.styles[0]
    assert style.name == "Default"
    assert style.fontname == "Droid Sans"
    assert style.scale_x == 99.0
    assert style.scale_y == 98.0

    assert len(document.events) == 3
    first_event = document.events[0]
    assert first_event.event_type is EventType.DIALOGUE
    assert first_event.start_time == 17_190
    assert first_event.end_time == 21_090
    assert first_event.text.startswith(r"{\k36}gol")


def test_read_ass_parses_comment_events(ass_fixtures_dir: Path) -> None:
    """Comment events should map to EventType.COMMENT."""
    document = read_ass(ass_fixtures_dir / "comment_event.ass")

    assert len(document.events) == 1
    assert document.events[0].event_type is EventType.COMMENT
    assert document.events[0].text == "comment body"


def test_read_ass_maps_reordered_format_fields(ass_fixtures_dir: Path) -> None:
    """Reordered ``Format:`` columns should still map to canonical fields."""
    document = read_ass(ass_fixtures_dir / "reordered_format.ass")

    assert document.section_order == ["script_info", "raw:0", "styles", "events"]
    assert document.other_sections[0].name == "Aegisub Project Garbage"
    assert document.style_format == [
        "Fontsize",
        "Name",
        "Fontname",
        "SecondaryColour",
        "PrimaryColour",
        "OutlineColour",
        "BackColour",
        "Bold",
        "Italic",
        "Underline",
        "StrikeOut",
        "ScaleY",
        "ScaleX",
        "Spacing",
        "Angle",
        "BorderStyle",
        "Outline",
        "Shadow",
        "Alignment",
        "MarginR",
        "MarginL",
        "MarginV",
        "Encoding",
    ]
    assert document.event_format == [
        "Text",
        "Effect",
        "MarginV",
        "MarginR",
        "MarginL",
        "Name",
        "Style",
        "End",
        "Start",
        "Layer",
    ]

    style = document.styles[0]
    assert style.name == "Alt"
    assert style.fontname == "Arial"
    assert style.fontsize == 24.0
    assert style.primary_colour == "&H00FFFFFF"
    assert style.secondary_colour == "&H000000FF"
    assert style.bold is True
    assert style.scale_x == 97.0
    assert style.scale_y == 98.0
    assert style.margin_l == 11
    assert style.margin_r == 22

    first_event = document.events[0]
    assert first_event.event_type is EventType.DIALOGUE
    assert first_event.layer == 3
    assert first_event.start_time == 1_000
    assert first_event.end_time == 2_000
    assert first_event.style == "Alt"
    assert first_event.name == "singer"
    assert first_event.margin_l == 4
    assert first_event.margin_r == 5
    assert first_event.margin_v == 6
    assert first_event.effect == "fx"
    assert first_event.text == "hello"
