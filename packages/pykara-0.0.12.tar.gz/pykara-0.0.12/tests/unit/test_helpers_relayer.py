"""Tests for the relayer helper."""

import pytest
from tests.support import make_comment_event, make_dialogue_event

from pykara.ass.types import AssDocument
from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.engine.runner import run
from pykara.exceptions import PykaraTypeError
from pykara.helpers.relayer import RelayerHelper


def test_relayer_sets_output_layer() -> None:
    """Calling relayer() should update the runtime output layer."""
    runtime = ExecutionRuntime(scope=Scope.SYL)

    assert RelayerHelper(runtime.set_output_layer)(5) is None
    assert runtime.output_layer(0) == 5


def test_relayer_zero_is_valid() -> None:
    """Layer 0 is a valid value and must not fall back to the default."""
    runtime = ExecutionRuntime(scope=Scope.SYL)
    RelayerHelper(runtime.set_output_layer)(0)

    assert runtime.output_layer(99) == 0


def test_relayer_rejects_non_integer() -> None:
    """Passing a non-integer to relayer() should raise ``PykaraTypeError``."""
    runtime = ExecutionRuntime(scope=Scope.SYL)
    relayer = RelayerHelper(runtime.set_output_layer)

    with pytest.raises(
        PykaraTypeError,
        match=r"layer must be an integer, got 1\.5 \(float\)",
    ):
        relayer(1.5)  # type: ignore[arg-type]


def test_relayer_with_repeat_and_two_patches() -> None:
    """relayer + repeat + layer-selective patches compose correctly.

    patch syl layer 1 must only inject on the iteration whose output layer is 1,
    and patch syl layer 2 only on layer 2.
    """
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl no_text repeat 3",
                "!relayer(repeat.i)!T!repeat.i!",
                style="Default",
            ),
            make_comment_event("patch syl layer 1", ":A", style="Default"),
            make_comment_event("patch syl layer 2", ":B", style="Default"),
            make_dialogue_event(r"{\k10}a", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [(line.layer, line.text) for line in output] == [
        (1, "T1:A"),
        (2, "T2:B"),
        (3, "T3"),
    ]


def test_relayer_without_call_keeps_template_event_layer() -> None:
    """When relayer is not called the template directive's own layer is preserved."""
    document = AssDocument(
        events=[
            make_comment_event("template syl no_text", "", style="Default", layer=7),
            make_dialogue_event(r"{\k10}a", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert output[0].layer == 7
