"""Tests for Phase 4 text measurement."""

# pyright: reportUnknownMemberType=false, reportUntypedFunctionDecorator=false

from __future__ import annotations

import importlib
import json
import sys
from dataclasses import replace
from pathlib import Path
from typing import Any, ClassVar, cast
from unittest.mock import MagicMock, patch

import pytest

from pykara.ass import read_ass
from pykara.exceptions import PykaraRuntimeError
from pykara.layout import LayoutStyle, measure_text
from pykara.layout import _pango_measure as pango_measure_module
from pykara.layout import text_measure as text_measure_module


class AttrBag:
    """Minimal attribute container used by backend stubs in tests."""

    def __init__(self, **attrs: object) -> None:
        self.__dict__.update(attrs)


def _load_reference_cases() -> list[tuple[str, str, float, float, float, float]]:
    """Load structured reference cases for parametrized measurement tests."""
    fixture_path = (
        Path(__file__).resolve().parents[1]
        / "fixtures"
        / "reference"
        / "layout"
        / "text_measure.json"
    )
    raw_cases = json.loads(fixture_path.read_text(encoding="utf-8"))
    return [
        (
            str(case["style"]),
            str(case["text"]),
            float(case["width"]),
            float(case["height"]),
            float(case["descent"]),
            float(case["extlead"]),
        )
        for case in raw_cases
    ]


@pytest.mark.parametrize(
    ("style_key", "text", "width", "height", "descent", "extlead"),
    _load_reference_cases(),
)
def test_measure_text_matches_reference_outputs(
    layout_reference_dir: Path,
    style_key: str,
    text: str,
    width: float,
    height: float,
    descent: float,
    extlead: float,
) -> None:
    """The adapted measurement backend must match the validated reference outputs."""
    document = read_ass(layout_reference_dir / "layout.ass")
    styles = {style.name: LayoutStyle.from_parsed(style) for style in document.styles}
    metrics = measure_text(styles[style_key], text)

    assert abs(metrics.width - width) < 1e-9
    assert abs(metrics.height - height) < 1e-9
    assert abs(metrics.descent - descent) < 1e-9
    assert abs(metrics.extlead - extlead) < 1e-9


def _fake_make_layout(_: LayoutStyle, __: float) -> object:
    return object()


def _fake_measure_spacing(_: object, text: str) -> tuple[float, float, float, float]:
    return {
        "a": (64.0, 64.0, 16.0, 0.0),
        "b": (128.0, 64.0, 8.0, 0.0),
    }[text]


def _fake_measure_full(_: object, __: str) -> tuple[float, float, float, float]:
    return (320.0, 128.0, 64.0, 32.0)


def test_make_layout_configures_pango_font_description(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The Pango branch should map ASS style fields into the layout font config."""

    class FakeFontDescription:
        def __init__(self) -> None:
            self.family = ""
            self.size = 0
            self.weight = ""
            self.style = ""

        def set_family(self, value: str) -> None:
            self.family = value

        def set_size(self, value: int) -> None:
            self.size = value

        def set_weight(self, value: str) -> None:
            self.weight = value

        def set_style(self, value: str) -> None:
            self.style = value

    class FakeLayout:
        def __init__(self) -> None:
            self.font_description: FakeFontDescription | None = None

        def set_font_description(self, value: FakeFontDescription) -> None:
            self.font_description = value

    class FakeContext:
        def __init__(self, surface: object) -> None:
            self.surface = surface

    fake_layout = FakeLayout()
    fake_surface = object()
    style = replace(LayoutStyle.default(), font="Test Font", bold=True, italic=True)

    def make_surface(
        fmt: object,
        width: int,
        height: int,
    ) -> tuple[object, object, int, int]:
        return (fake_surface, fmt, width, height)

    def create_layout(_: FakeContext) -> FakeLayout:
        return fake_layout

    monkeypatch.setattr(
        pango_measure_module,
        "cairo",
        AttrBag(
            Format=AttrBag(A8="A8"),
            ImageSurface=make_surface,
            Context=FakeContext,
        ),
    )
    monkeypatch.setattr(
        pango_measure_module,
        "Pango",
        AttrBag(
            SCALE=1024,
            Weight=AttrBag(BOLD="bold", NORMAL="normal"),
            Style=AttrBag(ITALIC="italic", NORMAL="normal"),
            FontDescription=FakeFontDescription,
        ),
    )
    monkeypatch.setattr(
        pango_measure_module,
        "PangoCairo",
        AttrBag(create_layout=create_layout),
    )

    layout = cast(FakeLayout, pango_measure_module.make_layout(style, 12.5))

    assert layout is fake_layout
    assert fake_layout.font_description is not None
    assert fake_layout.font_description.family == "Test Font"
    assert fake_layout.font_description.size == 12_800
    assert fake_layout.font_description.weight == "bold"
    assert fake_layout.font_description.style == "italic"


def test_measure_layout_clamps_zero_height_and_negative_descent(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The measurement helper should clamp empty height and negative descent."""

    class FakeIter:
        def get_baseline(self) -> int:
            return 5

    class FakeLayout:
        def __init__(self) -> None:
            self.seen: tuple[str, int] | None = None

        def set_text(self, text: str, length: int) -> None:
            self.seen = (text, length)

        def get_pixel_size(self) -> tuple[int, int]:
            return (7, 0)

        def get_iter(self) -> FakeIter:
            return FakeIter()

    monkeypatch.setattr(pango_measure_module, "Pango", AttrBag(SCALE=1))

    layout = FakeLayout()

    assert pango_measure_module.measure_layout(layout, "x") == (7.0, 1.0, 0.0, 0.0)
    assert layout.seen == ("x", -1)


def test_measure_text_spacing_branch_aggregates_each_character(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Non-zero spacing should measure and scale each character independently."""
    style = replace(
        LayoutStyle.default(),
        fontsize=1.0,
        spacing=0.5,
        scalex=100.0,
        scaley=100.0,
    )

    monkeypatch.setattr(pango_measure_module, "make_layout", _fake_make_layout)
    monkeypatch.setattr(pango_measure_module, "measure_layout", _fake_measure_spacing)

    metrics = measure_text(style, "ab")

    assert metrics.width == 4.0
    assert metrics.height == 1.0
    assert metrics.descent == 0.25
    assert metrics.extlead == 0.0


def test_measure_text_non_spacing_branch_scales_full_layout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Zero spacing should scale the full-string measurement once."""
    style = replace(
        LayoutStyle.default(),
        fontsize=2.0,
        spacing=0.0,
        scalex=150.0,
        scaley=50.0,
    )

    monkeypatch.setattr(pango_measure_module, "make_layout", _fake_make_layout)
    monkeypatch.setattr(pango_measure_module, "measure_layout", _fake_measure_full)

    metrics = measure_text(style, "full")

    assert metrics.width == 7.5
    assert metrics.height == 1.0
    assert metrics.descent == 0.5
    assert metrics.extlead == 0.25


def _build_fake_win32_structures() -> tuple[type[Any], type[Any], type[Any], type[Any]]:
    """Build fake ctypes structure classes for the Win32 import path."""

    class FakeStructure:
        """Minimal ctypes.Structure stand-in."""

        _fields_: ClassVar[tuple[tuple[str, Any], ...]] = ()

        def __init_subclass__(cls, **kwargs: Any) -> None:
            super().__init_subclass__(**kwargs)
            for name, _ in cls._fields_:
                setattr(cls, name, 0)

    class FakeSIZE(FakeStructure):
        """Fake SIZE struct: cx and cy are plain int attributes."""

        _fields_: ClassVar[tuple[tuple[str, Any], ...]] = (("cx", int), ("cy", int))

        def __init__(self) -> None:
            self.cx = 0
            self.cy = 0

    class FakeLOGFONTW(FakeStructure):
        """Fake LOGFONTW struct."""

        _fields_: ClassVar[tuple[tuple[str, Any], ...]] = (
            ("lfHeight", int),
            ("lfWidth", int),
            ("lfEscapement", int),
            ("lfOrientation", int),
            ("lfWeight", int),
            ("lfItalic", int),
            ("lfUnderline", int),
            ("lfStrikeOut", int),
            ("lfCharSet", int),
            ("lfOutPrecision", int),
            ("lfClipPrecision", int),
            ("lfQuality", int),
            ("lfPitchAndFamily", int),
            ("lfFaceName", str),
        )

        def __init__(self) -> None:
            for name, _ in self._fields_:
                object.__setattr__(self, name, 0)
            self.lfFaceName = ""

    class FakeTEXTMETRICW(FakeStructure):
        """Fake TEXTMETRICW struct."""

        _fields_: ClassVar[tuple[tuple[str, Any], ...]] = (
            ("tmHeight", int),
            ("tmAscent", int),
            ("tmDescent", int),
            ("tmInternalLeading", int),
            ("tmExternalLeading", int),
        )

        def __init__(self) -> None:
            self.tmHeight = 0
            self.tmAscent = 0
            self.tmDescent = 0
            self.tmInternalLeading = 0
            self.tmExternalLeading = 0

    return FakeStructure, FakeSIZE, FakeLOGFONTW, FakeTEXTMETRICW


def _build_fake_ctypes_modules(
    fake_structure: type[Any],
) -> tuple[AttrBag, AttrBag]:
    """Build fake ctypes and wintypes module stubs for the Win32 import path."""

    class FakeCType:
        def __mul__(self, _n: int) -> FakeCType:
            return self

        def __rmul__(self, _n: int) -> FakeCType:
            return self

    _wchar = FakeCType()

    fake_wintypes = AttrBag(
        LONG=int,
        BYTE=int,
        WCHAR=_wchar,
        HDC=int,
        HFONT=int,
        HGDIOBJ=int,
        BOOL=int,
        LPCWSTR=str,
    )

    fake_ptr_sentinel = object()

    def fake_byref(obj: Any) -> Any:
        return obj

    def fake_sizeof(_obj: Any) -> int:
        return 1

    def fake_memset(_ref: Any, _value: int, _size: int) -> None:
        pass

    def fake_pointer(_typ: Any) -> Any:
        return fake_ptr_sentinel

    def fake_windll(_name: str) -> MagicMock:
        return MagicMock()

    fake_ctypes = AttrBag(
        Structure=fake_structure,
        WinDLL=fake_windll,
        POINTER=fake_pointer,
        byref=fake_byref,
        sizeof=fake_sizeof,
        memset=fake_memset,
        c_int=int,
        wintypes=fake_wintypes,
    )

    return fake_ctypes, fake_wintypes


def _build_win32_module() -> Any:
    """Import the Win32 backend with ctypes and GDI mocked."""
    fake_structure, fake_size, fake_logfontw, fake_textmetricw = (
        _build_fake_win32_structures()
    )
    fake_ctypes, fake_wintypes = _build_fake_ctypes_modules(fake_structure)

    with (
        patch.dict(
            sys.modules,
            {"ctypes": fake_ctypes, "ctypes.wintypes": fake_wintypes},
        ),  # type: ignore[arg-type]
    ):
        sys.modules.pop("pykara.layout._win32_measure", None)
        mod = importlib.import_module("pykara.layout._win32_measure")
        mod._FakeSIZE = fake_size  # type: ignore[attr-defined]
        mod._FakeLOGFONTW = fake_logfontw  # type: ignore[attr-defined]
        mod._FakeTEXTMETRICW = fake_textmetricw  # type: ignore[attr-defined]
        return mod


@pytest.fixture()
def win32_mod() -> Any:
    """Return the Win32 backend reimported under the mock environment."""

    sys.modules.pop("pykara.layout._win32_measure", None)
    mod = _build_win32_module()
    yield mod
    sys.modules.pop("pykara.layout._win32_measure", None)


def test_win32_make_logfont_bold_italic(win32_mod: Any) -> None:
    """_make_logfont must set weight/italic flags from the ASS style."""
    style = replace(
        LayoutStyle.default(),
        font="Arial",
        bold=True,
        italic=True,
        underline=True,
        strikeout=True,
        encoding=128,
    )
    lf = win32_mod._make_logfont(style, 1280.0)

    assert lf.lfHeight == 1280
    assert lf.lfWeight == 700
    assert lf.lfItalic == 1
    assert lf.lfUnderline == 1
    assert lf.lfStrikeOut == 1
    assert lf.lfCharSet == 128
    assert lf.lfOutPrecision == 4
    assert lf.lfClipPrecision == 0
    assert lf.lfQuality == 4
    assert lf.lfPitchAndFamily == 0
    assert lf.lfFaceName == "Arial"


def test_win32_make_logfont_normal(win32_mod: Any) -> None:
    """_make_logfont must use FW_NORMAL when bold/italic/etc. are False."""
    style = LayoutStyle.default()
    lf = win32_mod._make_logfont(style, 640.0)

    assert lf.lfWeight == 400
    assert lf.lfItalic == 0
    assert lf.lfUnderline == 0
    assert lf.lfStrikeOut == 0


def test_win32_make_logfont_truncates_font_name(win32_mod: Any) -> None:
    """Font names longer than 31 chars must be truncated to 31 characters."""
    long_name = "A" * 40
    style = replace(LayoutStyle.default(), font=long_name)
    lf = win32_mod._make_logfont(style, 640.0)
    assert lf.lfFaceName == "A" * 31


def _setup_gdi_mock(
    win32_mod: Any,
    *,
    dc_handle: int = 1,
    font_handle: int = 2,
    size_cx: int = 1024,
    size_cy: int = 512,
    tm_descent: int = 64,
    tm_extlead: int = 32,
    spacing_results: dict[str, tuple[int, int]] | None = None,
) -> MagicMock:
    """Wire up a gdi32 mock with controllable return values.

    The SIZE and TEXTMETRICW structs are patched via side_effect so callers
    receive populated instances rather than plain Mock objects.
    """
    gdi32 = MagicMock()
    gdi32.CreateCompatibleDC.return_value = dc_handle
    gdi32.CreateFontIndirectW.return_value = font_handle
    gdi32.SelectObject.return_value = 99
    gdi32.GetTextMetricsW.return_value = 1

    if spacing_results is not None:
        call_counts: dict[str, int] = {}

        def get_extent_spacing(_dc: int, char: str, _n: int, size_ptr: Any) -> int:
            cx, cy = spacing_results.get(char, (size_cx, size_cy))
            size_ptr.cx = cx
            size_ptr.cy = cy
            call_counts[char] = call_counts.get(char, 0) + 1
            return 1

        gdi32.GetTextExtentPoint32W.side_effect = get_extent_spacing
    else:

        def get_extent_full(_dc: int, _text: str, _n: int, size_ptr: Any) -> int:
            size_ptr.cx = size_cx
            size_ptr.cy = size_cy
            return 1

        gdi32.GetTextExtentPoint32W.side_effect = get_extent_full

    def get_metrics(_dc: int, tm_ptr: Any) -> int:
        tm_ptr.tmDescent = tm_descent
        tm_ptr.tmExternalLeading = tm_extlead
        return 1

    gdi32.GetTextMetricsW.side_effect = get_metrics
    win32_mod.gdi32 = gdi32
    return gdi32


def test_measure_text_scales_backend_metrics() -> None:
    """measure_text must scale backend metrics into ASS coordinates.

    Raw values (cx=1024, cy=512, descent=64, extlead=32) with fontsize=1.0,
    scalex=100, scaley=100:
      width  = 100/100 * 1024/64 = 16.0
      height = 100/100 * 512/64  = 8.0
      descent= 100/100 * 64/64   = 1.0
      extlead= 100/100 * 32/64   = 0.5
    """
    style = replace(
        LayoutStyle.default(),
        fontsize=1.0,
        spacing=0.0,
        scalex=100.0,
        scaley=100.0,
    )
    with patch.object(
        text_measure_module,
        "_measure_raw_text",
        return_value=(1024.0, 512.0, 64.0, 32.0),
    ):
        metrics = measure_text(style, "hello")

    assert metrics.width == 16.0
    assert metrics.height == 8.0
    assert metrics.descent == 1.0
    assert metrics.extlead == 0.5


def test_measure_text_applies_scalex_and_scaley_independently() -> None:
    """measure_text must apply scalex and scaley independently.

    Raw values (cx=128, cy=64, descent=16, extlead=8) with fontsize=1.0,
    scalex=200, scaley=50:
      width  = 200/100 * 128/64 = 4.0
      height = 50/100  * 64/64  = 0.5
      descent= 50/100  * 16/64  = 0.125
      extlead= 50/100  * 8/64   = 0.0625
    """
    style = replace(
        LayoutStyle.default(),
        fontsize=1.0,
        spacing=0.0,
        scalex=200.0,
        scaley=50.0,
    )
    with patch.object(
        text_measure_module,
        "_measure_raw_text",
        return_value=(128.0, 64.0, 16.0, 8.0),
    ):
        metrics = measure_text(style, "x")

    assert metrics.width == pytest.approx(4.0)
    assert metrics.height == pytest.approx(0.5)
    assert metrics.descent == pytest.approx(0.125)
    assert metrics.extlead == pytest.approx(0.0625)


def test_win32_measure_text_spacing_branch_accumulates(win32_mod: Any) -> None:
    """Spacing branch: width must sum cx+spacing per character.

    Two characters 'a' and 'b' with cx=64 each, cy=32, spacing=0.5 px,
    fontsize=1.0, scalex=100, scaley=100:
      spacing_raw = 0.5 * 64 = 32.0
      width  = 100/100 * (64+32 + 64+32)/64 = 100/100 * 192/64 = 3.0
      height = 100/100 * 32/64 = 0.5
    """
    style = replace(
        LayoutStyle.default(),
        fontsize=1.0,
        spacing=0.5,
        scalex=100.0,
        scaley=100.0,
    )
    _setup_gdi_mock(
        win32_mod,
        size_cx=64,
        size_cy=32,
        tm_descent=0,
        tm_extlead=0,
        spacing_results={"a": (64, 32), "b": (64, 32)},
    )

    with patch.object(
        text_measure_module,
        "_measure_raw_text",
        wraps=win32_mod.measure_backend,
    ):
        metrics = measure_text(style, "ab")

    assert metrics.width == pytest.approx(3.0)
    assert metrics.height == pytest.approx(0.5)


def test_win32_measure_text_raises_on_dc_failure(win32_mod: Any) -> None:
    """measure_text must raise the library runtime error when DC creation fails."""
    gdi32 = MagicMock()
    gdi32.CreateCompatibleDC.return_value = 0
    win32_mod.gdi32 = gdi32

    style = LayoutStyle.default()
    with pytest.raises(PykaraRuntimeError, match="CreateCompatibleDC"):
        win32_mod.measure_backend(style, "x")


def test_win32_measure_text_raises_on_font_failure(win32_mod: Any) -> None:
    """measure_text must raise the library runtime error when font creation fails."""
    gdi32 = MagicMock()
    gdi32.CreateCompatibleDC.return_value = 1
    gdi32.CreateFontIndirectW.return_value = 0
    win32_mod.gdi32 = gdi32

    style = LayoutStyle.default()
    with pytest.raises(PykaraRuntimeError, match="CreateFontIndirectW"):
        win32_mod.measure_backend(style, "x")


def test_win32_measure_text_raises_on_extent_failure_no_spacing(
    win32_mod: Any,
) -> None:
    """Non-spacing branch must raise the library runtime error on extent failure."""
    gdi32 = MagicMock()
    gdi32.CreateCompatibleDC.return_value = 1
    gdi32.CreateFontIndirectW.return_value = 2
    gdi32.SelectObject.return_value = 99
    gdi32.GetTextExtentPoint32W.return_value = 0
    win32_mod.gdi32 = gdi32

    style = replace(LayoutStyle.default(), spacing=0.0)
    with pytest.raises(PykaraRuntimeError, match="non-spacing"):
        win32_mod.measure_backend(style, "x")


def test_win32_measure_text_raises_on_extent_failure_spacing(win32_mod: Any) -> None:
    """Spacing branch must raise the library runtime error on extent failure."""
    gdi32 = MagicMock()
    gdi32.CreateCompatibleDC.return_value = 1
    gdi32.CreateFontIndirectW.return_value = 2
    gdi32.SelectObject.return_value = 99
    gdi32.GetTextExtentPoint32W.return_value = 0
    win32_mod.gdi32 = gdi32

    style = replace(LayoutStyle.default(), spacing=1.0)
    with pytest.raises(PykaraRuntimeError, match="spacing branch"):
        win32_mod.measure_backend(style, "a")


def test_win32_measure_text_raises_on_metrics_failure(win32_mod: Any) -> None:
    """measure_text must raise the library runtime error when metrics fail."""

    def get_extent(_dc: int, _text: str, _n: int, size_ptr: Any) -> int:
        size_ptr.cx = 64
        size_ptr.cy = 64
        return 1

    gdi32 = MagicMock()
    gdi32.CreateCompatibleDC.return_value = 1
    gdi32.CreateFontIndirectW.return_value = 2
    gdi32.SelectObject.return_value = 99
    gdi32.GetTextExtentPoint32W.side_effect = get_extent
    gdi32.GetTextMetricsW.return_value = 0
    win32_mod.gdi32 = gdi32

    style = replace(LayoutStyle.default(), spacing=0.0)
    with pytest.raises(PykaraRuntimeError, match="GetTextMetricsW"):
        win32_mod.measure_backend(style, "x")
