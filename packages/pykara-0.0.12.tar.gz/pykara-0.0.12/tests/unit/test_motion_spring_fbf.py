"""Tests for the frame-baked spring motion builder."""

from __future__ import annotations

import pytest
from tests.support import make_motion_event

from pykara.motion.spring.fbf import spring_fbf_line
from pykara.motion.spring.request import SpringFbfRequest


def test_spring_fbf_line_returns_correct_frame_count() -> None:
    """Spring FBF should produce one frame per frame bucket."""
    line = make_motion_event(r"{\an5}X")
    result = spring_fbf_line(line, 24.0, 100, 400, 800, 400)
    assert len(result) == 24


def test_spring_fbf_line_each_frame_has_pos() -> None:
    r"""Every FBF spring frame should contain a ``\pos(`` tag."""
    line = make_motion_event(r"{\an5}X")
    result = spring_fbf_line(line, 24.0, 100, 400, 800, 400)
    assert all(r"\pos(" in frame.text for frame in result)


def test_spring_fbf_line_first_frame_oscillates_from_start() -> None:
    r"""First frame should reflect the spring displacement near t=0."""
    import re

    line = make_motion_event(r"{\an5}X")
    result = spring_fbf_line(line, 24.0, 100, 400, 800, 400)
    m = re.search(r"\\pos\(([\d.-]+),([\d.-]+)\)", result[0].text)
    assert m is not None
    x = float(m.group(1))
    assert 0.0 <= x <= 1000.0


def test_spring_fbf_line_timing_is_correct() -> None:
    """FBF frames should cover the full line interval."""
    line = make_motion_event(r"{\an5}X")
    result = spring_fbf_line(line, 24.0, 100, 400, 800, 400)
    assert result[0].start_time == 1000
    assert result[-1].end_time == 2000


def test_spring_fbf_line_settles_near_target() -> None:
    """With sufficient damping, the last frame should be near the target."""
    line = make_motion_event(r"{\an5}X")
    result = spring_fbf_line(line, 24.0, 100, 400, 800, 400, amplitude=1.0, damping=5.0)
    last_text = result[-1].text
    import re

    m = re.search(r"\\pos\(([\d.-]+),([\d.-]+)\)", last_text)
    assert m is not None
    x = float(m.group(1))
    assert x == pytest.approx(800.0, abs=5.0)


def test_spring_fbf_line_t1_t2_none_defaults_to_full_duration() -> None:
    """Omitting t1/t2 should use the full line duration."""
    line = make_motion_event(r"{\an5}X")
    result = spring_fbf_line(line, 24.0, 100, 400, 800, 400)
    assert len(result) == 24


def test_spring_fbf_request_expands_correctly() -> None:
    """SpringFbfRequest.expand() should delegate to spring_fbf_line."""
    request = SpringFbfRequest(x0=100, y0=400, x1=800, y1=400)
    result = request.expand(make_motion_event(r"{\an5}X"), 24.0)
    assert len(result) == 24
    assert all(r"\pos(" in frame.text for frame in result)
