"""Tests for the centralized evaluation public API catalog."""

from __future__ import annotations

from dataclasses import fields

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.engine.expression_catalog import (
    DOCUMENTED_HELPER_SURFACE,
    DOCUMENTED_REPEAT_VARIABLE_PATTERNS,
    DOCUMENTED_STATIC_VARIABLES_BY_SCOPE,
    EXPRESSION_BINDINGS_BY_SCOPE,
    EXPRESSION_OBJECT_BINDING_NAMES,
    EXPRESSION_OBJECT_BINDINGS_BY_SCOPE,
    EXPRESSION_SPECIAL_BINDINGS_BY_SCOPE,
    EXPRESSION_VISIBLE_ATTRS,
    GENERIC_REPEAT_VARIABLE_NAMES,
    HELPER_NAMES,
    LINE_INDEX_VARIABLE_NAME,
    REPEAT_VALUE_SUFFIXES,
    REPEAT_VARIABLE_PREFIX,
    RESERVED_EXPRESSION_NAMES,
    STATIC_VARIABLE_NAMES_BY_SCOPE,
    VARIABLE_ATTRS_BY_GROUP,
    VARIABLE_GROUPS_BY_SCOPE,
    VARIABLE_PATTERN_NAMES,
)
from pykara.helpers import build_runtime_helpers
from pykara.karaoke.char import Char
from pykara.karaoke.line import Line
from pykara.karaoke.syllable import Syllable
from pykara.karaoke.word import Word


def test_expression_visible_attrs_follow_public_dataclass_fields() -> None:
    """Expression object attrs should omit internal dataclass-only fields."""
    for model_type in (Line, Word, Syllable, Char):
        assert EXPRESSION_VISIBLE_ATTRS[model_type] == frozenset(
            field_info.name
            for field_info in fields(model_type)
            if field_info.name != "highlights"
        )


def test_scope_catalogs_define_the_public_visibility_rules() -> None:
    """One central catalog should define object and variable visibility."""
    expected_object_groups: dict[Scope, frozenset[str]] = {
        Scope.SETUP: frozenset[str](),
        Scope.LINE: frozenset({"line"}),
        Scope.WORD: frozenset({"line", "word"}),
        Scope.SYL: frozenset({"line", "syl"}),
        Scope.CHAR: frozenset({"line", "word", "syl", "char"}),
    }
    expected_special_bindings: dict[Scope, frozenset[str]] = {
        Scope.SETUP: frozenset[str]()
    } | {
        scope: frozenset({"script"})
        for scope in Scope
        if scope is not Scope.SETUP
    }

    assert EXPRESSION_OBJECT_BINDING_NAMES == ("line", "word", "syl", "char")
    assert expected_object_groups == EXPRESSION_OBJECT_BINDINGS_BY_SCOPE
    assert expected_special_bindings == EXPRESSION_SPECIAL_BINDINGS_BY_SCOPE
    assert {
        Scope.SETUP: frozenset[str](),
        Scope.LINE: frozenset({"line", "script"}),
        Scope.WORD: frozenset({"line", "word", "script"}),
        Scope.SYL: frozenset({"line", "syl", "script"}),
        Scope.CHAR: frozenset({"line", "word", "syl", "char", "script"}),
    } == EXPRESSION_BINDINGS_BY_SCOPE
    assert expected_object_groups == VARIABLE_GROUPS_BY_SCOPE


def test_variable_catalog_covers_each_public_group() -> None:
    """The variable catalog should be keyed by the documented group names."""
    assert frozenset({"line", "word", "syl", "char"}) == VARIABLE_PATTERN_NAMES
    assert LINE_INDEX_VARIABLE_NAME == "line_li"
    assert REPEAT_VARIABLE_PREFIX == "repeat_"
    assert frozenset({"repeat_i", "repeat_n"}) == GENERIC_REPEAT_VARIABLE_NAMES
    assert frozenset({"i", "n"}) == REPEAT_VALUE_SUFFIXES
    assert VARIABLE_ATTRS_BY_GROUP["line"]["line_dur"] == "duration"
    assert VARIABLE_ATTRS_BY_GROUP["word"]["word_left"] == "abs_left"
    assert VARIABLE_ATTRS_BY_GROUP["syl"]["syl_start"] == "start_time"
    assert VARIABLE_ATTRS_BY_GROUP["char"]["char_ci"] == "ci"
    assert STATIC_VARIABLE_NAMES_BY_SCOPE[Scope.SETUP] == frozenset()
    assert STATIC_VARIABLE_NAMES_BY_SCOPE[Scope.LINE] == frozenset(
        {"line_li", *VARIABLE_ATTRS_BY_GROUP["line"]}
    )
    assert STATIC_VARIABLE_NAMES_BY_SCOPE[Scope.WORD] == (
        STATIC_VARIABLE_NAMES_BY_SCOPE[Scope.LINE]
        | frozenset(VARIABLE_ATTRS_BY_GROUP["word"])
    )
    assert STATIC_VARIABLE_NAMES_BY_SCOPE[Scope.SYL] == (
        STATIC_VARIABLE_NAMES_BY_SCOPE[Scope.LINE]
        | frozenset(VARIABLE_ATTRS_BY_GROUP["syl"])
    )
    assert STATIC_VARIABLE_NAMES_BY_SCOPE[Scope.CHAR] == (
        STATIC_VARIABLE_NAMES_BY_SCOPE[Scope.WORD]
        | frozenset(VARIABLE_ATTRS_BY_GROUP["syl"])
        | frozenset(VARIABLE_ATTRS_BY_GROUP["char"])
    )
    assert {
        scope: frozenset(f"${name}" for name in names)
        for scope, names in STATIC_VARIABLE_NAMES_BY_SCOPE.items()
    } == DOCUMENTED_STATIC_VARIABLES_BY_SCOPE
    assert (
        frozenset(
            {
                "$repeat_i",
                "$repeat_n",
                "$repeat_<name>_i",
                "$repeat_<name>_n",
            }
        )
        == DOCUMENTED_REPEAT_VARIABLE_PATTERNS
    )


def test_reserved_expression_names_cover_public_bindings() -> None:
    """Code state should not overwrite the built-in public expression names."""
    assert (
        frozenset(
            {
                "__builtins__",
                "line",
                "word",
                "syl",
                "char",
                "script",
                "color",
                "memory",
                "motion",
                "relayer",
                "timeline",
                "repeat",
                "retime",
                "scale",
                "palette",
            }
        )
        == RESERVED_EXPRESSION_NAMES
    )


def test_helper_builder_matches_the_documented_helper_names() -> None:
    """Helper construction should be driven by the public API catalog."""
    helpers = build_runtime_helpers(ExecutionRuntime(scope=Scope.SETUP))

    assert frozenset(helpers) == HELPER_NAMES


def test_documented_helper_surfaces_match_the_public_contract() -> None:
    """The docs-facing helper patterns should be centralized in one catalog."""
    assert frozenset(DOCUMENTED_HELPER_SURFACE) == HELPER_NAMES
    assert DOCUMENTED_HELPER_SURFACE["color"] == frozenset(
        {
            "color.rgb.to_ass(r, g, b)",
            "color.hex.to_ass(value)",
            "color.ass.parse(value)",
            "color.hsv.to_rgb(h, s, v)",
        }
    )
    assert DOCUMENTED_HELPER_SURFACE["memory"] == frozenset(
        {"memory.remember(key, value)", "memory.recall.<key>"}
    )
    assert DOCUMENTED_HELPER_SURFACE["motion"] == frozenset(
        {
            "motion.shad",
            "motion.fbf",
            "motion.shad.setup()",
            "motion.shad.jitter(left, right, up, down, period, seed=0)",
            "motion.fbf.jitter(left, right, up, down, period, seed=0)",
        }
    )
    assert DOCUMENTED_HELPER_SURFACE["timeline"] == frozenset(
        {
            "timeline.transitions(steps, tags)",
            "timeline.sequence(steps, accel=1.0)",
            "timeline.pulse(span, cadence, values, accel=1.0, start_index=0)",
        }
    )
    assert DOCUMENTED_HELPER_SURFACE["repeat"] == frozenset(
        {"repeat.i", "repeat.n", "repeat.<name>.i", "repeat.<name>.n"}
    )
    assert DOCUMENTED_HELPER_SURFACE["retime"] >= frozenset(
        {
            "retime.line(start_offset=0, end_offset=0)",
            "retime.syl2end(start_offset=0, end_offset=0)",
            "retime.<target>.ltr(start_offset=0, end_offset=0)",
            "retime.<target>.random(start_offset=0, end_offset=0)",
        }
    )
    assert DOCUMENTED_HELPER_SURFACE["scale"] == frozenset(
        {
            "scale.of(value)",
            "scale.of(value).value",
            "scale.of(value).base(base_value)",
            "scale.of(value).base(base_value).to(target_value)",
        }
    )
    assert DOCUMENTED_HELPER_SURFACE["palette"] == frozenset(
        {
            "palette.<color>[shade]",
        }
    )
