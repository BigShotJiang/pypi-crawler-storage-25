"""Tests for Bezier motion in the shad and fbf helper families."""

from __future__ import annotations

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.exceptions import PykaraValidationError
from pykara.helpers.motion import MotionHelper
from pykara.motion.bezier.request import BezierFbfRequest


def test_shad_bezier_quadratic_returns_nonempty_string() -> None:
    """motion.shad.bezier() with 3 points should return a non-empty string."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.bezier((100, 600), (500, 100), (900, 600))
    assert isinstance(result, str)
    assert len(result) > 0
    assert r"\t(" in result


def test_shad_bezier_cubic_returns_nonempty_string() -> None:
    """motion.shad.bezier() with 4 points should return a non-empty string."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.bezier(
        (100, 600),
        (300, 100),
        (700, 700),
        (900, 200),
    )
    assert len(result) > 0
    assert r"\t(" in result


def test_shad_bezier_requires_line_runtime() -> None:
    """motion.shad.bezier() should raise a library validation error without line."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.shad\.bezier\(\) requires line runtime",
    ):
        MotionHelper(runtime).shad.bezier((100, 600), (500, 100), (900, 600))


def test_shad_bezier_quadratic_default_segments_is_16() -> None:
    """3-point bezier should default to 16 segments == 32 \\t tags."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.bezier((100, 600), (500, 100), (900, 600))
    assert result.count(r"\t(") == 32


def test_shad_bezier_cubic_default_segments_is_32() -> None:
    """4-point bezier should default to 32 segments == 64 \\t tags."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.bezier(
        (100, 600),
        (300, 100),
        (700, 700),
        (900, 200),
    )
    assert result.count(r"\t(") == 64


def test_shad_bezier_explicit_segments_override() -> None:
    """Explicit segments kwarg should override the default."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.bezier(
        (100, 600),
        (500, 100),
        (900, 600),
        segments=8,
    )
    assert result.count(r"\t(") == 16


def test_fbf_bezier_queues_request_and_returns_empty_string() -> None:
    """motion.fbf.bezier() should queue a BezierFbfRequest and return ''."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line, framerate=24.0)

    result = MotionHelper(runtime).fbf.bezier((100, 600), (500, 100), (900, 600))
    assert result == ""
    assert runtime.consume_fbf_request() == BezierFbfRequest(
        points=((100, 600), (500, 100), (900, 600))
    )


def test_fbf_bezier_requires_line_runtime() -> None:
    """motion.fbf.bezier() should raise a library validation error without line."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.bezier\(\) requires line runtime",
    ):
        MotionHelper(runtime).fbf.bezier((100, 600), (500, 100), (900, 600))


def test_fbf_bezier_requires_framerate() -> None:
    """motion.fbf.bezier() should raise a library validation error without FPS."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.bezier\(\) requires explicit timecodes or PlaybackFPS",
    ):
        MotionHelper(runtime).fbf.bezier((100, 600), (500, 100), (900, 600))
