"""Tests for Phase 4 absolute positioning."""

from __future__ import annotations

from tests.support import (
    make_raw_style,
    make_script_info,
    parse_karaoke_line,
)

from pykara.ass.types import AssDocument
from pykara.karaoke.line import Line
from pykara.karaoke.word import Word
from pykara.layout import (
    LayoutStyle,
    compute_char_positions,
    compute_line_layout,
    compute_syl_positions,
    compute_word_positions,
    script_from_document,
)


def _line() -> Line:
    """Build a positioned karaoke line with spaces around the first word."""
    document = AssDocument(
        script_info=make_script_info(),
        styles=[make_raw_style()],
    )
    line = parse_karaoke_line(r"{\k10} hi {\k20}there", start_time=0, end_time=500)
    style = LayoutStyle.from_parsed(document.styles[0])
    script = script_from_document(document)
    compute_line_layout(line, style, script)
    compute_syl_positions(line, style, script)
    compute_char_positions(line, style)
    compute_word_positions(line)
    return line


def test_positioning_populates_relative_and_absolute_boxes() -> None:
    """Child objects should keep relative boxes while variables use absolute ones."""
    line = _line()

    assert (
        line.left,
        line.center,
        line.right,
        line.width,
        line.top,
        line.middle,
        line.bottom,
        line.height,
    ) == (785, 959, 1133, 349, 491, 540, 589, 98)

    assert [
        (
            syllable.text,
            syllable.left,
            syllable.center,
            syllable.right,
            syllable.abs_left,
            syllable.abs_center,
            syllable.abs_right,
            syllable.width,
            syllable.top,
            syllable.middle,
            syllable.bottom,
            syllable.height,
        )
        for syllable in line.syls
    ] == [
        (" hi ", 25, 65, 104, 810, 849, 888, 78, 491, 540, 589, 98),
        ("there", 129, 239, 349, 914, 1024, 1133, 220, 491, 540, 589, 98),
    ]

    assert [
        (
            word.text,
            word.wi,
            word.ci,
            word.left,
            word.center,
            word.right,
            word.abs_left,
            word.abs_center,
            word.abs_right,
            word.width,
            word.height,
        )
        for word in line.words
    ] == [
        (" hi ", 1, 1, 50, 90, 129, 835, 874, 914, 79, 98),
        ("there", 2, 5, 129, 239, 349, 914, 1024, 1134, 220, 98),
    ]

    assert [
        (
            char.text,
            char.ci,
            char.si,
            char.wi,
            char.left,
            char.center,
            char.right,
            char.abs_left,
            char.abs_center,
            char.abs_right,
            char.width,
            char.top,
            char.middle,
            char.bottom,
            char.abs_top,
            char.abs_middle,
            char.abs_bottom,
            char.height,
        )
        for char in line.chars
    ] == [
        (
            " ",
            1,
            1,
            1,
            25,
            38,
            50,
            810,
            822,
            835,
            25,
            491,
            540,
            589,
            491,
            540,
            589,
            98,
        ),
        (
            "h",
            2,
            1,
            1,
            50,
            77,
            104,
            835,
            862,
            888,
            53,
            491,
            540,
            589,
            491,
            540,
            589,
            98,
        ),
        (
            "i",
            3,
            1,
            1,
            104,
            116,
            129,
            888,
            901,
            913,
            25,
            491,
            540,
            589,
            491,
            540,
            589,
            98,
        ),
        (
            " ",
            4,
            1,
            1,
            129,
            141,
            154,
            913,
            926,
            939,
            25,
            491,
            540,
            589,
            491,
            540,
            589,
            98,
        ),
        (
            "t",
            5,
            2,
            2,
            129,
            145,
            161,
            914,
            930,
            946,
            32,
            491,
            540,
            589,
            491,
            540,
            589,
            98,
        ),
        (
            "h",
            6,
            2,
            2,
            161,
            188,
            214,
            946,
            972,
            999,
            53,
            491,
            540,
            589,
            491,
            540,
            589,
            98,
        ),
        (
            "e",
            7,
            2,
            2,
            214,
            239,
            263,
            999,
            1023,
            1048,
            49,
            491,
            540,
            589,
            491,
            540,
            589,
            98,
        ),
        (
            "r",
            8,
            2,
            2,
            263,
            282,
            300,
            1048,
            1066,
            1085,
            37,
            491,
            540,
            589,
            491,
            540,
            589,
            98,
        ),
        (
            "e",
            9,
            2,
            2,
            300,
            324,
            349,
            1085,
            1109,
            1133,
            49,
            491,
            540,
            589,
            491,
            540,
            589,
            98,
        ),
    ]


def test_word_box_excludes_spaces() -> None:
    """``word_left`` and ``word_width`` must ignore leading and trailing spaces."""
    line = _line()

    first_word = line.words[0]

    assert first_word.left == line.chars[1].left
    assert first_word.left > line.chars[0].left
    assert first_word.right == line.chars[2].right
    assert first_word.width == first_word.right - first_word.left


def test_positioning_uses_left_and_top_alignment_branches() -> None:
    """Left/top aligned styles should anchor directly to effective margins."""
    document = AssDocument(
        script_info=make_script_info(),
        styles=[make_raw_style()],
    )
    raw_style = make_raw_style()
    raw_style.alignment = 7
    raw_style.margin_l = 44
    raw_style.margin_v = 55
    style = LayoutStyle.from_parsed(raw_style)
    script = script_from_document(document)
    line = parse_karaoke_line(r"{\k10}ab", start_time=0, end_time=500)

    compute_line_layout(line, style, script)

    assert line.left == 44
    assert line.top == 55
    assert line.halign == "left"
    assert line.valign == "top"


def test_compute_word_positions_handles_space_only_and_empty_words() -> None:
    """Word layout should cover the all-space and no-char fallback branches."""
    line = _line()

    space_only = Word(text=" ", start_time=0, duration=0, wi=3, ci=10)
    space_only.chars = [line.chars[0]]
    empty = Word(text="", start_time=0, duration=0, wi=4, ci=11)
    line.words = [space_only, empty]

    compute_word_positions(line)

    assert space_only.width == 0
    assert space_only.left == line.chars[0].left
    assert space_only.height == line.chars[0].height
    assert empty.width == 0
    assert empty.height == 0
