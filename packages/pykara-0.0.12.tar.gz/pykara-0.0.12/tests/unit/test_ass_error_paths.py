"""Error-path tests for ASS parsing and writing helpers."""

from __future__ import annotations

from pathlib import Path

import pytest

from pykara.ass.parser import read_ass
from pykara.ass.time import format_ass_time, parse_ass_time
from pykara.ass.types import AssDocument
from pykara.ass.writer import write_ass
from pykara.exceptions import PykaraValidationError


def test_parse_ass_time_rejects_invalid_inputs() -> None:
    """Malformed or out-of-range ASS timestamps should fail."""
    with pytest.raises(PykaraValidationError, match="Invalid ASS time"):
        parse_ass_time("bad")
    with pytest.raises(PykaraValidationError, match="Invalid ASS time"):
        parse_ass_time("0:61:00.00")
    with pytest.raises(PykaraValidationError, match="cannot be negative"):
        format_ass_time(-1)


def test_format_ass_time_rounds_to_nearest_centisecond() -> None:
    """Formatting should round millisecond values to centiseconds."""
    assert format_ass_time(15) == "0:00:00.02"


@pytest.mark.parametrize(
    ("fixture_name", "pattern"),
    [
        ("invalid_script_info_line.ass", "Invalid \\[Script Info\\] line"),
        ("style_before_format.ass", "Found Style line before Format line"),
        ("invalid_style_line.ass", "Invalid Style line"),
        ("style_missing_fields.ass", "Style line missing fields"),
        ("unsupported_styles_line.ass", "Unsupported \\[V4\\+ Styles\\] line"),
        ("styles_with_extra_column.ass", None),
        ("invalid_events_line.ass", "Invalid \\[Events\\] line"),
        ("unsupported_event_type.ass", "Unsupported event type"),
        ("event_before_format.ass", "Found event line before Format line"),
        ("invalid_event_line.ass", "Invalid event line"),
        ("event_missing_fields.ass", "Event line missing fields"),
        ("events_with_comment.ass", None),
    ],
)
def test_read_ass_error_paths(
    ass_fixtures_dir: Path,
    fixture_name: str,
    pattern: str | None,
) -> None:
    """Parser error branches should raise stable messages."""
    path = ass_fixtures_dir / fixture_name

    if pattern is None:
        assert read_ass(path) is not None
        return

    with pytest.raises(PykaraValidationError, match=pattern):
        read_ass(path)


def test_read_ass_empty_file_uses_default_section_order(tmp_path: Path) -> None:
    """An empty file should produce the default section order."""
    path = tmp_path / "empty.ass"
    path.write_text("", encoding="utf-8")

    document = read_ass(path)

    assert document.section_order == ["script_info", "styles", "events"]


def test_write_ass_rejects_unknown_section_token(tmp_path: Path) -> None:
    """Writer should reject unknown section-order markers."""
    document = AssDocument(section_order=["mystery"])

    with pytest.raises(PykaraValidationError, match="Unknown section token"):
        write_ass(document, tmp_path / "out.ass")
