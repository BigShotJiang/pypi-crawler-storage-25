"""Tests for the ASS writer."""

from pathlib import Path

from pykara.ass.parser import read_ass
from pykara.ass.writer import write_ass


def test_write_ass_round_trips_through_parser(
    karaoke_reference_dir: Path, tmp_path: Path
) -> None:
    """A parsed document should survive write and re-read unchanged."""
    original = read_ass(karaoke_reference_dir / "karaoke.ass")
    output_path = tmp_path / "roundtrip.ass"

    write_ass(original, output_path)
    reparsed = read_ass(output_path)

    assert reparsed == original


def test_write_ass_round_trips_layout_reference(
    layout_reference_dir: Path, tmp_path: Path
) -> None:
    """Layout reference fixtures should survive a write/read cycle unchanged."""
    original = read_ass(layout_reference_dir / "layout.ass")
    output_path = tmp_path / "layout_roundtrip.ass"

    write_ass(original, output_path)
    reparsed = read_ass(output_path)

    assert reparsed == original


def test_write_ass_round_trips_reordered_format_fixture(
    ass_fixtures_dir: Path, tmp_path: Path
) -> None:
    """Writer should preserve valid non-canonical ``Format:`` orders."""
    original = read_ass(ass_fixtures_dir / "reordered_format.ass")
    output_path = tmp_path / "reordered_roundtrip.ass"

    write_ass(original, output_path)
    reparsed = read_ass(output_path)

    assert reparsed == original
