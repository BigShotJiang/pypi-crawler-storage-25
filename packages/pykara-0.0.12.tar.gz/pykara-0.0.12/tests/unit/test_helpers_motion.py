"""Tests for the motion helper."""

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.exceptions import PykaraTypeError, PykaraValidationError
from pykara.helpers.motion import MotionHelper
from pykara.motion.jitter.request import JitterFbfRequest


class _IntSubclass(int):
    """Int subclass used to mirror repeat helper values."""


def test_motion_helper_exposes_shad_and_fbf_modules() -> None:
    """The root motion helper should only aggregate its effect helpers."""
    motion = MotionHelper()

    assert hasattr(motion, "shad")
    assert hasattr(motion, "fbf")


def test_shad_setup_returns_the_fixed_shadow_trick_fragment() -> None:
    """The setup helper should emit the fixed tags required by the trick."""
    motion = MotionHelper()

    assert motion.shad.setup() == r"\alpha&HFF&\4a&H00&\ko0\xshad0.001\yshad0"


def test_shad_jitter_builds_zero_duration_transforms() -> None:
    """Shad jitter should emit one zero-duration hop per active period."""
    line = parse_karaoke_line(start_time=1000, end_time=1350)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    assert MotionHelper(runtime).shad.jitter(1, 2, 0, 1, 100, 7) == (
        r"\t(0,0,\xshad1.5\yshad0.5)"
        r"\t(100,100,\xshad0.375\yshad0.5)"
        r"\t(200,200,\xshad-0.875\yshad0.625)"
        r"\t(300,300,\xshad1\yshad0.625)"
    )


def test_shad_jitter_keeps_xshad_alive_when_zero() -> None:
    r"""A zero x offset still needs ``\xshad0.001`` inside each hop."""
    line = parse_karaoke_line(start_time=1000, end_time=1200)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    assert MotionHelper(runtime).shad.jitter(0, 0, 0, 0, 100) == (
        r"\t(0,0,\xshad0.001\yshad0)"
        r"\t(100,100,\xshad0.001\yshad0)"
    )


def test_shad_jitter_rejects_invalid_inputs() -> None:
    """Shad jitter only accepts line runtime and integer arguments."""
    motion = MotionHelper(ExecutionRuntime(scope=Scope.SETUP))

    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.shad\.jitter\(\) requires line runtime",
    ):
        motion.shad.jitter(1, 1, 1, 1, 100)

    line = parse_karaoke_line(start_time=1000, end_time=1200)
    motion = MotionHelper(ExecutionRuntime(scope=Scope.LINE, line=line))

    with pytest.raises(
        PykaraTypeError,
        match=(
            r"motion\.shad\.jitter\(\) expects integer "
            r"left/right/up/down/period/seed values"
        ),
    ):
        motion.shad.jitter(1, 1, 1, 1, 100, 0.5)  # type: ignore[arg-type]

    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.shad\.jitter\(\) period must be >= 0",
    ):
        motion.shad.jitter(1, 1, 1, 1, -1)


def test_fbf_jitter_queues_one_request_and_returns_no_inline_text() -> None:
    """FBF jitter should enqueue motion work for the runner layer."""
    line = parse_karaoke_line(start_time=1000, end_time=1200)
    line.x = 640
    line.y = 360
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line, framerate=24.0)

    assert MotionHelper(runtime).fbf.jitter(3, 4, 5, 6, 100, 7) == ""
    assert runtime.consume_fbf_request() == JitterFbfRequest(
        x=640,
        y=360,
        left=3,
        right=4,
        up=5,
        down=6,
        period=100,
        seed=7,
    )


def test_fbf_jitter_requires_line_runtime_and_framerate() -> None:
    """FBF jitter needs both a line and a frame source."""
    motion = MotionHelper(ExecutionRuntime(scope=Scope.SETUP))
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.jitter\(\) requires line runtime",
    ):
        motion.fbf.jitter(1, 1, 1, 1, 100)

    line = parse_karaoke_line(start_time=1000, end_time=1200)
    motion = MotionHelper(ExecutionRuntime(scope=Scope.LINE, line=line))
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.jitter\(\) requires explicit timecodes or PlaybackFPS",
    ):
        motion.fbf.jitter(1, 1, 1, 1, 100)


def test_fbf_jitter_rejects_invalid_inputs() -> None:
    """FBF jitter should validate numeric arguments just like shad jitter."""
    line = parse_karaoke_line(start_time=1000, end_time=1200)
    motion = MotionHelper(ExecutionRuntime(scope=Scope.LINE, line=line, framerate=24.0))

    with pytest.raises(
        PykaraTypeError,
        match=(
            r"motion\.fbf\.jitter\(\) expects integer "
            r"left/right/up/down/period/seed values"
        ),
    ):
        motion.fbf.jitter(1, 1, 1, 1, 100, 0.5)  # type: ignore[arg-type]

    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.jitter\(\) period must be >= 0",
    ):
        motion.fbf.jitter(1, 1, 1, 1, -1)


def test_jitter_accepts_int_subclasses_but_rejects_bool() -> None:
    """Repeat-like int subclasses should work, but bool should not."""
    line = parse_karaoke_line(start_time=1000, end_time=1200)
    motion = MotionHelper(ExecutionRuntime(scope=Scope.LINE, line=line, framerate=24.0))

    assert motion.shad.jitter(_IntSubclass(1), 1, 1, 1, 100, _IntSubclass(7))
    assert motion.fbf.jitter(_IntSubclass(1), 1, 1, 1, 100, _IntSubclass(7)) == ""

    with pytest.raises(
        PykaraTypeError,
        match=(
            r"motion\.shad\.jitter\(\) expects integer "
            r"left/right/up/down/period/seed values"
        ),
    ):
        motion.shad.jitter(True, 1, 1, 1, 100)  # type: ignore[arg-type]
