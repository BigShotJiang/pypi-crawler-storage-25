"""Tests for the memory helper."""

import pytest

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.exceptions import PykaraAttributeError
from pykara.helpers.memory import MemoryHelper


def test_memory_remember_and_recall_round_trip() -> None:
    """Remembered values should be readable through ``memory.recall``."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)
    memory = MemoryHelper(runtime.memory_state)

    assert memory.remember("color", "&HFF0000&") == "&HFF0000&"
    assert memory.recall.color == "&HFF0000&"


def test_memory_recall_missing_key_raises_attribute_error() -> None:
    """Unknown memory keys should surface as attribute lookups failures."""
    memory = MemoryHelper(ExecutionRuntime(scope=Scope.SETUP).memory_state)

    with pytest.raises(
        PykaraAttributeError,
        match=r"memory\.recall\.missing is not defined",
    ):
        _ = memory.recall.missing
