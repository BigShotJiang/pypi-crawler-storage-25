"""Tests for RetimeState — retime interval tracking for one evaluation pass."""

from __future__ import annotations

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.retime_state import RetimeState
from pykara.exceptions import PykaraValidationError


def _line_and_syl():
    """Return a (line, syl) pair for tests that need both."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}cd")
    return line, line.syls[0]


def test_output_interval_no_line_returns_zero_zero():
    """No line runtime always yields (0, 0)."""
    state = RetimeState()
    assert state.output_interval(None) == (0, 0)


def test_output_interval_no_retime_applied_returns_full_line_duration():
    """Without any retime call the full line interval is returned."""
    line, _ = _line_and_syl()
    state = RetimeState()
    assert state.output_interval(line) == (0, line.duration)


def test_output_interval_after_apply_returns_offset_range():
    """After apply() the stored range is returned."""
    line, _ = _line_and_syl()
    state = RetimeState()
    state.apply("line", 100, -50, scope=Scope.LINE, line=line, syl=None)
    start, end = state.output_interval(line)
    assert start == 100
    assert end == line.duration - 50


def test_apply_line_target_base_range():
    """retime.line maps to (0, line.duration) before offsets."""
    line, _ = _line_and_syl()
    state = RetimeState()
    state.apply("line", 0, 0, scope=Scope.LINE, line=line, syl=None)
    assert state.output_interval(line) == (0, line.duration)


def test_apply_preline_target_base_range():
    """retime.preline maps to (0, 0) before offsets."""
    line, _ = _line_and_syl()
    state = RetimeState()
    state.apply("preline", 10, 20, scope=Scope.LINE, line=line, syl=None)
    assert state.output_interval(line) == (10, 20)


def test_apply_postline_target_base_range():
    """retime.postline maps to (duration, duration) before offsets."""
    line, _ = _line_and_syl()
    state = RetimeState()
    state.apply("postline", -10, 10, scope=Scope.LINE, line=line, syl=None)
    assert state.output_interval(line) == (line.duration - 10, line.duration + 10)


def test_apply_syl_target_base_range():
    """retime.syl maps to (syl.start_time, syl.end_time) before offsets."""
    line, syl = _line_and_syl()
    state = RetimeState()
    state.apply("syl", 0, 0, scope=Scope.SYL, line=line, syl=syl)
    assert state.output_interval(line) == (syl.start_time, syl.end_time)


def test_apply_presyl_target_base_range():
    """retime.presyl maps to (syl.start_time, syl.start_time) before offsets."""
    line, syl = _line_and_syl()
    state = RetimeState()
    state.apply("presyl", 5, 10, scope=Scope.SYL, line=line, syl=syl)
    assert state.output_interval(line) == (syl.start_time + 5, syl.start_time + 10)


def test_apply_postsyl_target_base_range():
    """retime.postsyl maps to (syl.end_time, syl.end_time) before offsets."""
    line, syl = _line_and_syl()
    state = RetimeState()
    state.apply("postsyl", -5, 5, scope=Scope.SYL, line=line, syl=syl)
    assert state.output_interval(line) == (syl.end_time - 5, syl.end_time + 5)


def test_apply_start2syl_target_base_range():
    """retime.start2syl maps to (0, syl.start_time) before offsets."""
    line, syl = _line_and_syl()
    state = RetimeState()
    state.apply("start2syl", 0, 0, scope=Scope.SYL, line=line, syl=syl)
    assert state.output_interval(line) == (0, syl.start_time)


def test_apply_syl2end_target_base_range():
    """retime.syl2end maps to (syl.end_time, line.duration) before offsets."""
    line, syl = _line_and_syl()
    state = RetimeState()
    state.apply("syl2end", 0, 0, scope=Scope.SYL, line=line, syl=syl)
    assert state.output_interval(line) == (syl.end_time, line.duration)


def test_apply_unknown_target_raises():
    """An unrecognised target name raises ``PykaraValidationError``."""
    line, _ = _line_and_syl()
    state = RetimeState()
    with pytest.raises(PykaraValidationError, match="Unknown retime target"):
        state.apply("bogus", 0, 0, scope=Scope.LINE, line=line, syl=None)  # type: ignore[arg-type]


def test_apply_line_target_without_line_raises():
    """A line-group target without a line object raises ``PykaraValidationError``."""
    state = RetimeState()
    with pytest.raises(PykaraValidationError, match="requires line runtime"):
        state.apply("line", 0, 0, scope=Scope.LINE, line=None, syl=None)


def test_apply_syl_target_in_line_scope_raises():
    """A syl-group target outside syl/char scope should raise a validation error."""
    line, syl = _line_and_syl()
    state = RetimeState()
    with pytest.raises(
        PykaraValidationError,
        match="only valid in template syl and char",
    ):
        state.apply("syl", 0, 0, scope=Scope.LINE, line=line, syl=syl)


def test_apply_syl_target_without_syl_raises():
    """A syl-group target without a syl object raises ``PykaraValidationError``."""
    line, _ = _line_and_syl()
    state = RetimeState()
    with pytest.raises(PykaraValidationError, match="requires line and syl runtime"):
        state.apply("syl", 0, 0, scope=Scope.SYL, line=line, syl=None)


def test_apply_same_target_twice_raises():
    """Calling the same target a second time raises ``PykaraValidationError``."""
    line, _ = _line_and_syl()
    state = RetimeState()
    state.apply("line", 0, 0, scope=Scope.LINE, line=line, syl=None)
    with pytest.raises(PykaraValidationError, match=r"can only be called once"):
        state.apply("line", 0, 0, scope=Scope.LINE, line=line, syl=None)


def test_apply_two_different_targets_raises():
    """Two different retime targets should raise ``PykaraValidationError``."""
    line, _ = _line_and_syl()
    state = RetimeState()
    state.apply("line", 0, 0, scope=Scope.LINE, line=line, syl=None)
    with pytest.raises(PykaraValidationError, match="mutually exclusive"):
        state.apply("preline", 0, 0, scope=Scope.LINE, line=line, syl=None)
