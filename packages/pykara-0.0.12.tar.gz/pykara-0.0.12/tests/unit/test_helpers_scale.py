"""Tests for the scale helper."""

from __future__ import annotations

import pytest

from pykara.exceptions import PykaraTypeError, PykaraValidationError
from pykara.helpers.scale import ScaleHelper


def test_scale_helper_scales_one_value_between_bases() -> None:
    """The fluent scale helper should apply the expected proportional result."""
    scale = ScaleHelper()

    assert scale.of(2).base(100).to(150) == 3
    assert scale.of(2.5).base(100).to(150) == 3.75


def test_scale_helper_exposes_the_original_value() -> None:
    """The wrapped value should remain available via ``.value``."""
    scale = ScaleHelper()

    assert scale.of(2).value == 2
    assert scale.of(2.5).value == 2.5


def test_scale_helper_rejects_zero_base() -> None:
    """The source base must be non-zero."""
    scale = ScaleHelper()

    with pytest.raises(PykaraValidationError, match="cannot use zero"):
        scale.of(2).base(0)


def test_scale_helper_requires_base_before_target() -> None:
    """Calling ``to(...)`` without a bound base should fail clearly."""
    scale = ScaleHelper()

    with pytest.raises(PykaraValidationError, match=r"must be set before \.to"):
        scale.of(2).to(150)


@pytest.mark.parametrize("value", ["2", object(), True])
def test_scale_helper_rejects_non_numeric_input(value: object) -> None:
    """Only plain numeric values should be accepted."""
    scale = ScaleHelper()

    with pytest.raises(PykaraTypeError, match="int or float"):
        scale.of(value)

    with pytest.raises(PykaraTypeError, match="int or float"):
        scale.of(2).base(value)

    with pytest.raises(PykaraTypeError, match="int or float"):
        scale.of(2).base(100).to(value)
