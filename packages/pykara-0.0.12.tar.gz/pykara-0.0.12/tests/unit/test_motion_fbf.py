"""Tests for the internal FBF motion helpers."""

from __future__ import annotations

import re
import tempfile
from pathlib import Path
from typing import cast

import pytest
from tests.support import (
    make_comment_event,
    make_motion_event,
    make_script_info,
)

from pykara.ass.parser import read_ass
from pykara.ass.time import parse_ass_time
from pykara.ass.types import AssDocument, DialogueLine, EventType, RawSection
from pykara.ass.writer import write_ass
from pykara.exceptions import PykaraTypeError, PykaraValidationError
from pykara.motion.runtime.fbf import ass_tags as fbf_module
from pykara.motion.runtime.fbf.ass_tags import (
    MotionState,
    MoveTag,
    alpha_from_tag,
    calc_accel,
    coerce_value,
    collect_initial_data,
    extract_all_tags_from_block,
    extract_t_tags,
    get_alpha_interpolation,
    get_tag_fade,
    get_tag_move,
    get_tag_value_from_block,
    get_time_in_interval,
    interpolate_alpha,
    interpolate_color,
    interpolate_shape,
    interpolate_value,
    lerp_tag_move,
    math_clamp,
    math_lerp,
    math_round,
    parse_t_tag,
    remove_move,
    remove_tag_from_block,
    replace_tag_in_block,
)
from pykara.motion.runtime.fbf.expansion import expand_document_to_fbf, line_to_fbf
from pykara.motion.runtime.fbf.timeline import frame_from_ms, ms_from_frame
from pykara.timing import Framerate

FPS = 24.0
RAW_DIALOGUE = r"Dialogue: 0,0:00:01.00,0:00:02.00,Default,,0,0,0,,{\pos(100,200)}Texto"


def tag_values(lines: list[DialogueLine], tag_pattern: str) -> list[str]:
    """Extract every tag value from a generated event list."""
    results: list[str] = []
    for line in lines:
        match = re.search(tag_pattern, line.text)
        if match:
            results.append(match.group(1))
    return results


def numeric_tag_values(lines: list[DialogueLine], tag_pattern: str) -> list[float]:
    """Extract every numeric tag value from a generated event list."""
    return [float(value) for value in tag_values(lines, tag_pattern)]


def parse_event_line(raw: str):
    """Parse one raw ASS event line with the project's canonical parser."""
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "event.ass"
        path.write_text(
            "[Events]\n"
            "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, "
            "Effect, Text\n" + raw + "\n",
            encoding="utf-8",
        )
        return read_ass(path).events[0]


def position_values(line_text: str) -> tuple[float, float]:
    """Extract a position tuple from generated text."""
    match = re.search(r"\\pos\(([\d.-]+),([\d.-]+)\)", line_text)
    assert match is not None
    return float(match.group(1)), float(match.group(2))


def alpha_value(line_text: str) -> int:
    """Extract one alpha byte from generated text."""
    match = re.search(r"\\alpha&H([0-9A-F]{2})&", line_text)
    assert match is not None
    return int(match.group(1), 16)


def test_math_clamp_below_range() -> None:
    """Clamp should return the lower bound for out-of-range values."""
    assert math_clamp(-5, 0, 1) == 0


def test_math_clamp_above_range() -> None:
    """Clamp should return the upper bound for out-of-range values."""
    assert math_clamp(5, 0, 1) == 1


def test_math_clamp_inside_range() -> None:
    """Clamp should preserve values that are already in range."""
    assert math_clamp(0.5, 0, 1) == 0.5


def test_math_lerp_at_zero_progress() -> None:
    """Linear interpolation should return the start value at zero progress."""
    assert math_lerp(0, 100, 200) == pytest.approx(100)


def test_math_lerp_at_full_progress() -> None:
    """Linear interpolation should return the end value at full progress."""
    assert math_lerp(1, 100, 200) == pytest.approx(200)


def test_math_lerp_at_half_progress() -> None:
    """Linear interpolation should return the midpoint at half progress."""
    assert math_lerp(0.5, 100, 200) == pytest.approx(150)


def test_math_round_with_two_decimals() -> None:
    """Rounded values should keep the requested precision."""
    assert math_round(1.2349, 2) == pytest.approx(1.23)


def test_math_round_with_zero_decimals() -> None:
    """Rounded values should return integral results when precision is zero."""
    assert math_round(2.6, 0) == 3


def test_ms_from_frame_at_24_fps() -> None:
    """One second at 24 fps should map to 24 frames."""
    assert ms_from_frame(24, 24.0) == 1000


def test_frame_from_ms_at_24_fps() -> None:
    """One second in milliseconds should map back to 24 frames."""
    assert frame_from_ms(1000, 24.0) == 24


def test_ms_from_frame_zero() -> None:
    """Frame zero should map to time zero."""
    assert ms_from_frame(0, 24.0) == 0


@pytest.mark.parametrize("frame", [0, 12, 24])
def test_frame_and_millisecond_conversion_roundtrip(frame: int) -> None:
    """Frame conversion should be stable for exact frame boundaries."""
    milliseconds = ms_from_frame(frame, 24.0)
    assert frame_from_ms(milliseconds, 24.0) == frame


def test_ms_from_frame_at_23976_fps() -> None:
    """NTSC-like rates should round to the nearest millisecond."""
    assert ms_from_frame(24, 23.976) == pytest.approx(1001, abs=1)


def test_ms_from_frame_rejects_non_positive_fps() -> None:
    """Constant FPS conversion should reject non-positive rates."""
    with pytest.raises(
        PykaraValidationError,
        match=r"frame-baked timeline fps must be > 0",
    ):
        ms_from_frame(1, 0.0)


def test_ms_from_frame_rejects_negative_frame_indexes() -> None:
    """Frame conversion should reject negative frame indexes."""
    with pytest.raises(
        PykaraValidationError,
        match=r"frame-baked timeline frame index cannot be negative",
    ):
        ms_from_frame(-1, 24.0)


def test_frame_conversion_accepts_framerate_objects() -> None:
    """Frame conversion should also work with the project's timecode mapping."""
    framerate = Framerate((0, 42, 84))

    assert ms_from_frame(2, framerate) == 84
    assert frame_from_ms(42, framerate) == 1


def test_interpolate_numeric_at_half_progress() -> None:
    """Numeric tag interpolation should reach the arithmetic midpoint."""
    result = interpolate_value("frz", 0.5, 0.0, 360.0)
    assert result == pytest.approx(180.0, abs=0.1)


def test_interpolate_numeric_at_start() -> None:
    """Numeric interpolation should preserve the start value at zero."""
    result = interpolate_value("fscx", 0.0, 100.0, 200.0)
    assert result == pytest.approx(100.0)


def test_interpolate_numeric_at_end() -> None:
    """Numeric interpolation should reach the end value at full progress."""
    result = interpolate_value("fscx", 1.0, 100.0, 200.0)
    assert result == pytest.approx(200.0)


def test_interpolate_alpha_at_half_progress() -> None:
    """Alpha interpolation should encode the midpoint byte."""
    assert interpolate_alpha(0.5, "&H00&", "&HFF&") == "&H80&"


def test_interpolate_alpha_at_start() -> None:
    """Alpha interpolation should preserve the start value at zero."""
    assert interpolate_alpha(0.0, "&H00&", "&HFF&") == "&H00&"


def test_interpolate_alpha_at_end() -> None:
    """Alpha interpolation should preserve the end value at one."""
    assert interpolate_alpha(1.0, "&H00&", "&HFF&") == "&HFF&"


def test_interpolate_alpha_returns_start_on_invalid_payload() -> None:
    """Invalid alpha payloads should fall back to the start value."""
    assert interpolate_alpha(0.5, "invalid", "&HFF&") == "invalid"


def test_alpha_from_tag_returns_zero_on_invalid_payload() -> None:
    """Invalid inline alpha payloads should fall back to zero."""
    assert alpha_from_tag("invalid") == 0.0


def test_interpolate_color_at_half_progress() -> None:
    """Color interpolation should keep a valid ASS color literal."""
    result = interpolate_color(0.5, "&H0000FF&", "&HFF0000&")
    assert re.fullmatch(r"&H[0-9A-F]{6}&", result) is not None


def test_interpolate_color_returns_start_on_invalid_payload() -> None:
    """Invalid color payloads should fall back to the start value."""
    assert interpolate_color(0.5, "invalid", "&HFF0000&") == "invalid"


def test_interpolate_shape_at_half_progress() -> None:
    """Shape interpolation should blend all numeric coordinates."""
    start = "m 0 0 l 100 0 100 100 0 100"
    end = "m 0 0 l 200 0 200 200 0 200"
    result = interpolate_shape(0.5, start, end)
    numbers = [float(value) for value in re.findall(r"-?[\d.]+", result)]
    assert numbers == [0, 0, 150, 0, 150, 150, 0, 150]


def test_interpolate_shape_requires_matching_point_counts() -> None:
    """Shape interpolation should reject mismatched vector sizes."""
    with pytest.raises(
        PykaraValidationError,
        match=r"clip shape interpolation requires matching point counts",
    ):
        interpolate_shape(0.5, "m 0 0 l 10 10", "m 0 0 l 10 10 20 20")


def test_interpolate_value_uses_alpha_branch() -> None:
    """Value interpolation should dispatch alpha tags to alpha interpolation."""
    assert interpolate_value("alpha", 0.5, "&H00&", "&HFF&") == "&H80&"


def test_interpolate_value_interpolates_rectangular_clip() -> None:
    """Rectangular clips should interpolate numerically component by component."""
    result = interpolate_value(
        "clip",
        0.5,
        [0.0, 0.0, 10.0, 10.0],
        [10.0, 20.0, 30.0, 40.0],
    )
    assert result == [5.0, 10.0, 20.0, 25.0]


def test_interpolate_value_returns_start_for_unknown_tags() -> None:
    """Unknown tags should preserve the current start value."""
    assert interpolate_value("unknown", 0.5, "keep", "drop") == "keep"


def test_interpolate_value_rejects_list_values_for_numeric_tags() -> None:
    """Numeric tag interpolation should reject list payloads."""
    with pytest.raises(
        PykaraTypeError,
        match=r"numeric tag interpolation does not accept list values",
    ):
        interpolate_value("frz", 0.5, [1.0], 2.0)  # type: ignore[arg-type]


def test_interval_progress_before_start() -> None:
    """Progress before the interval should clamp to zero."""
    assert get_time_in_interval(0, 100, 500) == 0.0


def test_interval_progress_after_end() -> None:
    """Progress after the interval should clamp to one."""
    assert get_time_in_interval(600, 100, 500) == 1.0


def test_interval_progress_at_midpoint() -> None:
    """Linear interval progress should reach 0.5 at the midpoint."""
    progress = get_time_in_interval(300, 100, 500)
    assert progress == pytest.approx(0.5, abs=1e-5)


def test_interval_progress_with_acceleration_is_slower_at_start() -> None:
    """Higher acceleration should lag behind the linear curve early on."""
    linear = get_time_in_interval(200, 0, 1000, 1.0)
    accel_2 = get_time_in_interval(200, 0, 1000, 2.0)
    assert accel_2 < linear


def test_interval_progress_at_exact_start() -> None:
    """Progress at the interval start should be zero."""
    assert get_time_in_interval(100, 100, 500) == 0.0


def test_interval_progress_at_exact_end() -> None:
    """Progress at the interval end should be one."""
    assert get_time_in_interval(500, 100, 500) == 1.0


def test_parse_t_tag_without_arguments() -> None:
    """A transform without timing arguments should use defaults."""
    start, end, accel, transform = parse_t_tag(r"\frz360")
    assert start is None
    assert end is None
    assert accel == 1.0
    assert "frz" in transform


def test_parse_t_tag_with_explicit_times() -> None:
    """A transform with two numeric prefixes should parse as start and end."""
    start, end, accel, _ = parse_t_tag(r"0,500,\frz360")
    assert start == 0.0
    assert end == 500.0
    assert accel == 1.0


def test_parse_t_tag_with_explicit_acceleration() -> None:
    """A transform with three numeric prefixes should parse acceleration."""
    start, end, accel, _ = parse_t_tag(r"0,500,2,\frz360")
    assert start == 0.0
    assert end == 500.0
    assert accel == 2.0


def test_parse_t_tag_with_acceleration_only() -> None:
    """A single numeric prefix should be interpreted as acceleration."""
    start, end, accel, _ = parse_t_tag(r"2,\frz360")
    assert start is None
    assert end is None
    assert accel == 2.0


def test_parse_t_tag_preserves_transform_payload() -> None:
    """Transform parsing should preserve the raw inner tag block."""
    _, _, _, transform = parse_t_tag(r"0,1000,\fscx200\fscy200")
    assert "fscx" in transform
    assert "fscy" in transform


def test_parse_t_tag_falls_back_for_unmatched_payload() -> None:
    """Malformed transform payloads should return the raw input unchanged."""
    start, end, accel, transform = parse_t_tag("")
    assert start is None
    assert end is None
    assert accel == 1.0
    assert transform == ""


def test_parse_event_line_reads_start_time() -> None:
    """The canonical parser should read the dialogue start time."""
    line = parse_event_line(RAW_DIALOGUE)
    assert line.start_time == parse_ass_time("0:00:01.00")


def test_parse_event_line_reads_end_time() -> None:
    """The canonical parser should read the dialogue end time."""
    line = parse_event_line(RAW_DIALOGUE)
    assert line.end_time == parse_ass_time("0:00:02.00")


def test_parse_event_line_reads_style() -> None:
    """The canonical parser should read the dialogue style."""
    line = parse_event_line(RAW_DIALOGUE)
    assert line.style == "Default"


def test_parse_event_line_preserves_text() -> None:
    """The canonical parser should preserve the event text payload."""
    line = parse_event_line(RAW_DIALOGUE)
    assert "pos" in line.text


def test_parse_event_line_roundtrips_through_writer() -> None:
    """A parsed event should roundtrip through the project writer."""
    line = parse_event_line(RAW_DIALOGUE)
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "roundtrip.ass"
        write_ass(
            AssDocument(events=[line], section_order=["events"]),
            path,
        )
        reparsed = read_ass(path).events[0]
    assert reparsed.start_time == line.start_time
    assert reparsed.end_time == line.end_time
    assert reparsed.text == line.text


def test_extract_t_tags_from_single_transform() -> None:
    """One transform block should be extracted and removed from the cleaned text."""
    t_list, cleaned = extract_t_tags(r"{\pos(100,100)\frz0\t(\frz360)}")
    assert len(t_list) == 1
    assert r"\t(" not in cleaned


def test_extract_t_tags_from_multiple_transforms() -> None:
    """Multiple transform blocks should all be extracted."""
    t_list, _ = extract_t_tags(r"{\t(0,500,\frz360)\t(500,1000,\blur5)}")
    assert len(t_list) == 2


def test_extract_t_tags_keeps_non_transform_tags() -> None:
    """Removing transform blocks should not discard unrelated tags."""
    _, cleaned = extract_t_tags(r"{\pos(100,100)\frz0\t(\frz360)}")
    assert r"\pos" in cleaned
    assert r"\frz0" in cleaned


def test_extract_t_tags_without_any_transform() -> None:
    """Extraction should be a no-op when the block has no transform tags."""
    t_list, cleaned = extract_t_tags(r"{\pos(100,100)\frz45}")
    assert t_list == []
    assert r"\frz45" in cleaned


def test_get_tag_value_from_block_returns_none_for_unknown_tags() -> None:
    """Unknown tag patterns should return no effective value."""
    assert get_tag_value_from_block(r"\frz45", "unknown") is None


def test_coerce_value_parses_rectangular_clip_payloads() -> None:
    """Rectangular clip payloads should become numeric coordinate lists."""
    assert coerce_value("clip", "1,2,3,4") == [1.0, 2.0, 3.0, 4.0]


def test_remove_tag_from_block_is_a_noop_for_unknown_tags() -> None:
    """Removing an unknown tag should return the original block."""
    block = r"{\frz45}"
    assert remove_tag_from_block(block, "unknown") == block


def test_replace_tag_in_block_formats_rectangular_clips() -> None:
    """Replacing a clip should format list values back into ASS syntax."""
    block = replace_tag_in_block(r"{\clip(0,0,10,10)}", "clip", [1.0, 2.0, 3.0, 4.0])
    assert block == r"{\clip(1,2,3,4)}"


def test_replace_tag_in_block_accepts_string_values() -> None:
    """Replacing numeric tags should also accept string payloads."""
    block = replace_tag_in_block(r"{\fs20}", "fs", "30")
    assert block == r"{\fs30}"


def test_remove_move_removes_move_tags() -> None:
    """Move removal should strip the tag from the override block."""
    assert remove_move(r"{\move(0,0,100,100)\frz45}") == r"{\frz45}"


def test_get_tag_move_at_start() -> None:
    """Move interpolation should start from the declared origin."""
    x, y, _ = get_tag_move(0, 1000, 0, 0, 500, 300, None, None)
    assert x == pytest.approx(0.0, abs=0.01)
    assert y == pytest.approx(0.0, abs=0.01)


def test_get_tag_move_at_end() -> None:
    """Move interpolation should end at the declared destination."""
    x, y, _ = get_tag_move(1000, 1000, 0, 0, 500, 300, None, None)
    assert x == pytest.approx(500.0, abs=0.01)
    assert y == pytest.approx(300.0, abs=0.01)


def test_get_tag_move_at_midpoint() -> None:
    """Move interpolation should reach the midpoint halfway through."""
    x, y, _ = get_tag_move(500, 1000, 0, 0, 500, 300, None, None)
    assert x == pytest.approx(250.0, abs=0.01)
    assert y == pytest.approx(150.0, abs=0.01)


def test_get_tag_move_with_explicit_window() -> None:
    """Move interpolation should respect explicit ``t1`` and ``t2`` values."""
    x, _, __ = get_tag_move(200, 1000, 0, 0, 100, 100, 200, 800)
    assert x == pytest.approx(0.0, abs=0.01)
    x2, y2, _ = get_tag_move(800, 1000, 0, 0, 100, 100, 200, 800)
    assert x2 == pytest.approx(100.0, abs=0.01)
    assert y2 == pytest.approx(100.0, abs=0.01)


def test_get_tag_move_before_window_start() -> None:
    """Move interpolation should stay at the origin before the window opens."""
    x, y, _ = get_tag_move(100, 1000, 50, 50, 200, 200, 300, 700)
    assert x == pytest.approx(50.0, abs=0.01)
    assert y == pytest.approx(50.0, abs=0.01)


def test_get_tag_move_swaps_reversed_time_windows() -> None:
    """Move interpolation should normalize reversed time windows."""
    x, y, _ = get_tag_move(250, 1000, 0, 0, 100, 100, 800, 200)
    assert x == pytest.approx(8.33, abs=0.05)
    assert y == pytest.approx(8.33, abs=0.05)


def test_get_alpha_interpolation_returns_first_alpha_before_window() -> None:
    """Three-state alpha interpolation should use the first alpha before ``t1``."""
    assert get_alpha_interpolation(50, 100, 200, 300, 400, 255, 0, 255) == 255


def test_get_tag_fade_for_visible_segment() -> None:
    """The visible segment of a fade should yield opaque alpha."""
    fade = ("fad", 200.0, 200.0)
    alpha = get_tag_fade(500, 1000, 0, fade)
    assert alpha == pytest.approx(0.0, abs=0.1)


def test_get_tag_fade_at_fade_in_start() -> None:
    """The first instant of a fade should be fully transparent."""
    fade = ("fad", 200.0, 200.0)
    alpha = get_tag_fade(0, 1000, 0, fade)
    assert alpha == pytest.approx(255.0, abs=0.1)


def test_get_tag_fade_at_fade_out_end() -> None:
    """The last instant of a fade should be fully transparent."""
    fade = ("fad", 200.0, 200.0)
    alpha = get_tag_fade(1000, 1000, 0, fade)
    assert alpha == pytest.approx(255.0, abs=0.1)


def test_get_tag_fade_at_fade_in_midpoint() -> None:
    """Midway through the fade-in should yield half transparency."""
    fade = ("fad", 200.0, 200.0)
    alpha = get_tag_fade(100, 1000, 0, fade)
    assert alpha == pytest.approx(127.5, abs=1.0)


def test_get_tag_fade_with_full_fade_tag() -> None:
    """The full fade form should use the middle alpha in the steady region."""
    fade = ("fade", 255.0, 0.0, 255.0, 0.0, 200.0, 800.0, 1000.0)
    alpha = get_tag_fade(500, 1000, 0, fade)
    assert alpha == pytest.approx(0.0, abs=0.1)


def test_calc_accel_linear_curve_returns_one() -> None:
    """A linear curve should map to equivalent acceleration of one."""
    assert calc_accel(0.25, 0.5, 0.75) == pytest.approx(1.0, abs=0.01)


def test_calc_accel_with_zero_denominator_returns_one() -> None:
    """Degenerate inputs should fall back to linear acceleration."""
    assert calc_accel(0.5, 0.5, 0.5) == 1.0


def test_calc_accel_for_slow_start_is_greater_than_one() -> None:
    """A slow-start curve should map to acceleration above one."""
    assert calc_accel(0.0, 0.1, 1.0) > 1.0


def test_calc_accel_for_fast_start_is_less_than_one() -> None:
    """A fast-start curve should map to acceleration below one."""
    assert calc_accel(0.0, 0.9, 1.0) < 1.0


def test_calc_accel_result_is_clamped() -> None:
    """Equivalent acceleration should stay within the supported bounds."""
    accel = calc_accel(0.0, 0.001, 1.0)
    assert accel >= 0.01
    assert accel <= 100.0


def test_calc_accel_returns_one_for_out_of_range_ratios() -> None:
    """Equivalent acceleration should fall back to one for invalid ratios."""
    assert calc_accel(0.0, 0.0, 1.0) == 1.0


def test_calc_accel_handles_log_errors(monkeypatch: pytest.MonkeyPatch) -> None:
    """Unexpected log errors should fall back to linear acceleration."""
    original_log = fbf_module.math.log
    calls = {"count": 0}

    def flaky_log(value: float) -> float:
        calls["count"] += 1
        if calls["count"] == 2:
            raise ValueError("boom")
        return original_log(value)

    monkeypatch.setattr(fbf_module.math, "log", flaky_log)

    assert calc_accel(0.0, 0.25, 1.0) == 1.0


def test_calc_accel_rejects_nan_results(monkeypatch: pytest.MonkeyPatch) -> None:
    """Non-finite acceleration results should also fall back to one."""
    original_log = fbf_module.math.log

    def nan_log(value: float) -> float:
        if value == 0.25:
            return float("nan")
        return original_log(value)

    monkeypatch.setattr(fbf_module.math, "log", nan_log)

    assert calc_accel(0.0, 0.25, 1.0) == 1.0


def test_collect_initial_data_reads_numeric_tag_outside_transform() -> None:
    """Initial data should use the pre-transform numeric value."""
    data = collect_initial_data(r"{\frz45\t(\frz360)}")
    assert data["frz"] == pytest.approx(45.0)


def test_collect_initial_data_excludes_transform_payload() -> None:
    """Transform payload values should not leak into the initial state."""
    data = collect_initial_data(r"{\frz0\t(\frz360)}")
    assert data["frz"] == pytest.approx(0.0)


def test_collect_initial_data_omits_missing_numeric_tags() -> None:
    """Missing outer tags should not appear in the collected state."""
    data = collect_initial_data(r"{\pos(100,100)\t(\frz360)}")
    assert "frz" not in data


def test_collect_initial_data_reads_pos_tag() -> None:
    """The collector should parse positional tags from the base block."""
    data = collect_initial_data(r"{\pos(320,240)\t(\frz360)}")
    assert data["pos"] == [320.0, 240.0]


def test_collect_initial_data_reads_fad_tag() -> None:
    """The collector should keep fade metadata from the base block."""
    data = collect_initial_data(r"{\pos(100,100)\fad(200,200)}")
    assert "fad" in data


def test_collect_initial_data_ignores_invalid_fad_tag() -> None:
    """Invalid fade-in/out tags should be ignored."""
    data = collect_initial_data(r"{\fad(100,200,300)}")
    assert "fad" not in data


def test_collect_initial_data_reads_fade_tag() -> None:
    """The collector should parse the full fade tag form."""
    data = collect_initial_data(r"{\fade(255,0,255,0,100,900,1000)}")
    assert data["fade"] == ("fade", 255.0, 0.0, 255.0, 0.0, 100.0, 900.0, 1000.0)


def test_collect_initial_data_ignores_invalid_fade_tag() -> None:
    """Invalid full fade tags should be ignored."""
    data = collect_initial_data(r"{\fade(255,0,255,0,100,900)}")
    assert "fade" not in data


def test_collect_initial_data_reads_move_tag() -> None:
    """The collector should parse move metadata from the base block."""
    data = collect_initial_data(r"{\move(0,0,500,300)}")
    assert "move" in data
    move = data["move"]
    assert isinstance(move, tuple)
    assert cast(MoveTag, move)[:4] == (0.0, 0.0, 500.0, 300.0)


def test_collect_initial_data_reads_color_tag_outside_transform() -> None:
    """Color tags outside a transform should be used as the initial state."""
    data = collect_initial_data(r"{\c&H0000FF&\t(\c&HFF0000&)}")
    assert data["c"] == "&H0000FF&"


def test_line_to_fbf_generates_one_line_per_frame() -> None:
    """One second at 24 fps should generate 24 output lines."""
    line = make_motion_event(r"{\pos(100,100)}Texto", 0, 1000)
    output = line_to_fbf(line, FPS, step=1)
    assert len(output) == 24


def test_line_to_fbf_with_step_two_halves_the_line_count() -> None:
    """Grouped output should emit half as many lines at ``step=2``."""
    line = make_motion_event(r"{\pos(100,100)}Texto", 0, 1000)
    output = line_to_fbf(line, FPS, step=2)
    assert len(output) == 12


def test_line_to_fbf_produces_contiguous_timing() -> None:
    """Generated frame intervals should be contiguous."""
    line = make_motion_event(r"{\pos(100,100)}Texto", 0, 1000)
    output = line_to_fbf(line, FPS, step=1)
    for index in range(len(output) - 1):
        assert output[index].end_time == output[index + 1].start_time


def test_line_to_fbf_preserves_line_start_time() -> None:
    """The first generated frame should start with the source line."""
    line = make_motion_event(r"{\pos(100,100)}Texto", 1000, 2000)
    output = line_to_fbf(line, FPS, step=1)
    assert output[0].start_time == 1000


def test_line_to_fbf_preserves_line_end_time() -> None:
    """The last generated frame should end with the source line."""
    line = make_motion_event(r"{\pos(100,100)}Texto", 1000, 2000)
    output = line_to_fbf(line, FPS, step=1)
    assert output[-1].end_time == 2000


def test_line_to_fbf_passthroughs_lines_without_transform() -> None:
    """Static tags should be copied to every generated frame."""
    line = make_motion_event(r"{\pos(100,100)\frz45}Texto", 0, 1000)
    output = line_to_fbf(line, FPS, step=1)
    assert all(r"\frz45" in generated.text for generated in output)


def test_line_to_fbf_rejects_step_values_below_one() -> None:
    """Frame expansion should reject invalid grouping factors."""
    with pytest.raises(
        PykaraValidationError,
        match=r"frame-baked expansion step must be >= 1",
    ):
        line_to_fbf(make_motion_event(r"{\pos(0,0)}x", 0, 1000), FPS, step=0)


def test_line_to_fbf_returns_the_original_line_for_empty_frame_ranges() -> None:
    """Lines that do not span a full frame should be returned unchanged."""
    line = make_motion_event(r"{\pos(0,0)}x", 1000, 1010)
    assert line_to_fbf(line, FPS) == [line]


def test_line_to_fbf_handles_plain_text_without_override_blocks() -> None:
    """Plain text lines should still expand into timed chunks."""
    output = line_to_fbf(make_motion_event("hello", 0, 1000), FPS)
    assert len(output) == 24
    assert all(generated.text == "hello" for generated in output)


def test_numeric_transform_monotonically_increases_fscx() -> None:
    """A growing scale transform should increase monotonically."""
    line = make_motion_event(r"{\pos(100,100)\fscx100\t(\fscx200)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    values = numeric_tag_values(output, r"\\fscx([\d.-]+)")
    assert all(values[index] <= values[index + 1] for index in range(len(values) - 1))


def test_numeric_transform_fscx_stays_within_expected_range() -> None:
    """The interpolated scale should stay between the start and end values."""
    line = make_motion_event(r"{\pos(100,100)\fscx100\t(\fscx200)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    values = numeric_tag_values(output, r"\\fscx([\d.-]+)")
    assert values[0] > 100.0
    assert values[-1] < 200.0
    assert values[-1] > values[0]


def test_numeric_transform_rotates_toward_full_turn() -> None:
    """Rotation should move from the start angle toward the target angle."""
    line = make_motion_event(r"{\pos(100,100)\frz0\t(\frz360)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    values = numeric_tag_values(output, r"\\frz([\d.-]+)")
    assert values[0] > 0.0
    assert values[-1] < 360.0
    assert values[-1] > values[0]


def test_numeric_transform_interpolates_blur() -> None:
    """Blur transforms should emit interpolated blur values."""
    line = make_motion_event(r"{\pos(100,100)\blur0\t(\blur10)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    values = numeric_tag_values(output, r"\\blur([\d.-]+)")
    assert max(values) > 0
    assert max(values) < 10.1


def test_numeric_transform_output_does_not_keep_t_tags() -> None:
    """Fully expanded output should not preserve raw transform tags."""
    line = make_motion_event(r"{\pos(100,100)\frz0\t(\frz360)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    assert all(r"\t(" not in generated.text for generated in output)


def test_timed_transform_uses_start_value_before_window() -> None:
    """Frames before the transform window should keep the base value."""
    line = make_motion_event(r"{\pos(0,0)\fscx100\t(800,1000,\fscx200)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    early = [generated for generated in output if generated.end_time <= 800]
    values = numeric_tag_values(early, r"\\fscx([\d.-]+)")
    assert all(abs(value - 100.0) < 0.5 for value in values), values


def test_timed_transform_uses_end_value_after_window() -> None:
    """Frames after the transform window should keep the target value."""
    line = make_motion_event(r"{\pos(0,0)\fscx100\t(0,200,\fscx200)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    late = [generated for generated in output if generated.start_time >= 200]
    values = numeric_tag_values(late, r"\\fscx([\d.-]+)")
    assert all(abs(value - 200.0) < 0.5 for value in values), values


def test_timed_transform_with_accel_two_has_slower_start() -> None:
    """An accelerated transform should lag behind the linear midpoint early on."""
    line = make_motion_event(r"{\pos(0,0)\frz0\t(0,1000,2,\frz100)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    values = numeric_tag_values(output, r"\\frz([\d.-]+)")
    quarter_index = len(values) // 4
    assert values[quarter_index] < 25.0


def test_move_is_resolved_to_pos_tags() -> None:
    """Expanded move output should replace move tags with position tags."""
    line = make_motion_event(r"{\move(0,0,500,300)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    assert all(r"\pos(" in generated.text for generated in output)
    assert all(r"\move(" not in generated.text for generated in output)


def test_move_x_positions_increase_monotonically() -> None:
    """Move expansion should progress forward across the X axis."""
    line = make_motion_event(r"{\move(0,0,500,0)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    xs = [position_values(generated.text)[0] for generated in output]
    assert all(xs[index] <= xs[index + 1] for index in range(len(xs) - 1))


def test_move_starts_near_the_declared_origin() -> None:
    """The first expanded frame should still be near the move origin."""
    line = make_motion_event(r"{\move(100,200,500,300)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    x, y = position_values(output[0].text)
    assert x < 120
    assert y < 210


def test_move_ends_near_the_declared_destination() -> None:
    """The last expanded frame should be near the move destination."""
    line = make_motion_event(r"{\move(100,200,500,300)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    x, y = position_values(output[-1].text)
    assert x > 480
    assert y > 290


def test_move_with_window_stays_at_origin_before_start() -> None:
    """A delayed move should remain at the start position before ``t1``."""
    line = make_motion_event(r"{\move(0,0,500,300,200,800)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    early = [generated for generated in output if generated.end_time <= 200]
    if early:
        x, _ = position_values(early[0].text)
        assert x == pytest.approx(0.0, abs=1)


def test_grouped_move_before_its_window_collapses_to_pos() -> None:
    """Grouped chunks before a move window should collapse to a static position."""
    line = make_motion_event(r"{\move(0,0,500,300,800,900)}", 0, 1000)
    output = line_to_fbf(line, FPS, step=4)
    assert r"\move(" not in output[0].text
    assert r"\pos(0,0)" in output[0].text


def test_grouped_move_after_its_window_collapses_to_pos() -> None:
    """Grouped chunks after a move window should also collapse to a static position."""
    line = make_motion_event(r"{\move(0,0,500,300,100,200)}", 0, 1000)
    output = line_to_fbf(line, FPS, step=4)
    assert r"\move(" not in output[-1].text
    assert r"\pos(500,300)" in output[-1].text


def test_lerp_tag_move_ignores_malformed_move_state() -> None:
    """Malformed cached move state should leave the block untouched."""
    data: MotionState = cast(MotionState, {"move": (0.0, 0.0, 100.0)})
    result = lerp_tag_move(0, 1, 0, 40, 0, data, r"{\move(0,0,100,100)}")
    assert result == r"{\move(0,0,100,100)}"


def test_fad_is_removed_from_expanded_output() -> None:
    """Expanded fade output should remove the original fade tag."""
    line = make_motion_event(r"{\pos(0,0)\fad(200,200)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    assert all(r"\fad(" not in generated.text for generated in output)


def test_fad_expansion_injects_alpha_tags() -> None:
    """Expanded fade output should use per-frame alpha tags."""
    line = make_motion_event(r"{\pos(0,0)\fad(200,200)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    assert all(r"\alpha" in generated.text for generated in output)


def test_fad_starts_transparent() -> None:
    """The first frame of a fade should be mostly transparent."""
    line = make_motion_event(r"{\pos(0,0)\fad(200,200)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    assert alpha_value(output[0].text) > 200


def test_fad_is_opaque_in_the_middle() -> None:
    """The middle frame of a fade should be nearly opaque."""
    line = make_motion_event(r"{\pos(0,0)\fad(200,200)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    mid = output[len(output) // 2]
    assert alpha_value(mid.text) < 10


def test_fad_ends_transparent() -> None:
    """The last frame of a fade should be mostly transparent."""
    line = make_motion_event(r"{\pos(0,0)\fad(200,200)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    assert alpha_value(output[-1].text) > 200


def test_fade_uses_existing_base_alpha_when_present() -> None:
    """Fade expansion should honor an existing alpha tag as the steady-state alpha."""
    line = make_motion_event(
        r"{\pos(0,0)\alpha&H80&\fade(255,0,255,0,200,800,1000)}", 0, 1000
    )
    output = line_to_fbf(line, FPS)
    mid = output[len(output) // 2]
    assert r"\alpha&H80&" in mid.text


def test_color_transform_changes_over_time() -> None:
    """Color interpolation should produce multiple distinct values."""
    line = make_motion_event(r"{\pos(0,0)\c&H0000FF&\t(\c&HFF0000&)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    colors = tag_values(output, r"\\c(&H[0-9A-F]+&)")
    assert len(set(colors)) > 5


def test_color_transform_starts_near_the_source_color() -> None:
    """The first expanded color should stay near the initial color."""
    line = make_motion_event(r"{\pos(0,0)\c&H0000FF&\t(\c&HFF0000&)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    first_color = tag_values(output, r"\\c(&H[0-9A-F]+&)")[0]
    blue = int(first_color[2:4], 16)
    red = int(first_color[6:8], 16)
    assert blue < 30
    assert red > 220


def test_color_transform_ends_near_the_target_color() -> None:
    """The last expanded color should stay near the target color."""
    line = make_motion_event(r"{\pos(0,0)\c&H0000FF&\t(\c&HFF0000&)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    last_color = tag_values(output, r"\\c(&H[0-9A-F]+&)")[-1]
    blue = int(last_color[2:4], 16)
    red = int(last_color[6:8], 16)
    assert blue > 220
    assert red < 30


def test_color_transform_output_does_not_keep_t_tags() -> None:
    """Color-expanded output should not preserve raw transform tags."""
    line = make_motion_event(r"{\pos(0,0)\c&H0000FF&\t(\c&HFF0000&)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    assert all(r"\t(" not in generated.text for generated in output)


def test_multiple_transforms_are_both_resolved() -> None:
    """Multiple transforms in one block should all be expanded."""
    line = make_motion_event(
        r"{\pos(0,0)\fscx100\blur0\t(0,500,\fscx200)\t(500,1000,\blur10)}",
        0,
        1000,
    )
    output = line_to_fbf(line, FPS)
    assert all(r"\t(" not in generated.text for generated in output)


def test_multiple_transforms_resolve_fscx_in_the_first_half() -> None:
    """The first transform should affect the early half of the line."""
    line = make_motion_event(
        r"{\pos(0,0)\fscx100\blur0\t(0,500,\fscx200)\t(500,1000,\blur10)}",
        0,
        1000,
    )
    output = line_to_fbf(line, FPS)
    values = numeric_tag_values(output, r"\\fscx([\d.-]+)")
    assert values[0] < values[-1]
    assert values[0] < 115


def test_multiple_transforms_resolve_blur_in_the_second_half() -> None:
    """The second transform should affect the late frames."""
    line = make_motion_event(
        r"{\pos(0,0)\fscx100\blur0\t(0,500,\fscx200)\t(500,1000,\blur10)}",
        0,
        1000,
    )
    output = line_to_fbf(line, FPS)
    last_values = numeric_tag_values(output[-3:], r"\\blur([\d.-]+)")
    assert all(value > 7 for value in last_values), last_values


def test_move_fad_and_transform_are_all_resolved() -> None:
    """Combined motion effects should all resolve into concrete frame tags."""
    line = make_motion_event(
        r"{\move(0,0,960,540)\fad(150,150)\frz0\t(\frz360)}", 0, 1000
    )
    output = line_to_fbf(line, FPS)
    for generated in output:
        assert r"\move(" not in generated.text
        assert r"\fad(" not in generated.text
        assert r"\t(" not in generated.text
        assert r"\pos(" in generated.text
        assert r"\alpha" in generated.text
        assert r"\frz" in generated.text


def test_move_and_fad_combination_still_moves_forward() -> None:
    """Combining fade with move should not break positional progression."""
    line = make_motion_event(r"{\move(0,0,960,540)\fad(150,150)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    xs = [position_values(generated.text)[0] for generated in output]
    assert all(xs[index] <= xs[index + 1] for index in range(len(xs) - 1))


def test_move_and_fad_combination_fades_in() -> None:
    """Combined output should still fade in across the early frames."""
    line = make_motion_event(r"{\move(0,0,960,540)\fad(300,300)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    alphas = [
        alpha_value(generated.text)
        for generated in output
        if r"\alpha" in generated.text
    ]
    first_third = alphas[: len(alphas) // 3]
    assert first_third[0] > first_third[-1]


def test_move_and_rotation_remain_independent() -> None:
    """Resolving move should not suppress the interpolated rotation tag."""
    line = make_motion_event(r"{\move(0,0,500,0)\frz0\t(\frz180)}", 0, 1000)
    output = line_to_fbf(line, FPS)
    assert all(r"\pos(" in generated.text for generated in output)
    assert all(r"\frz" in generated.text for generated in output)


def test_step_two_emits_half_as_many_lines_as_step_one() -> None:
    """Grouped-frame output should reduce the emitted line count."""
    line = make_motion_event(r"{\pos(0,0)\frz0\t(\frz360)}", 0, 1000)
    output_step_1 = line_to_fbf(line, FPS, step=1)
    output_step_2 = line_to_fbf(line, FPS, step=2)
    assert len(output_step_2) == len(output_step_1) // 2


def test_step_two_preserves_t_tags() -> None:
    """Grouped-frame output should retain a compact transform representation."""
    line = make_motion_event(r"{\pos(0,0)\frz0\t(\frz360)}", 0, 1000)
    output = line_to_fbf(line, FPS, step=2)
    assert all(r"\t(" in generated.text for generated in output)


def test_step_two_produces_contiguous_timing() -> None:
    """Grouped-frame output should still be contiguous in time."""
    line = make_motion_event(r"{\pos(0,0)\frz0\t(\frz360)}", 0, 1000)
    output = line_to_fbf(line, FPS, step=2)
    for index in range(len(output) - 1):
        assert output[index].end_time == output[index + 1].start_time


def test_step_two_resolves_move_state() -> None:
    """Grouped output should materialize a move state for each emitted chunk."""
    line = make_motion_event(r"{\move(0,0,500,300)\frz0\t(\frz360)}", 0, 1000)
    output = line_to_fbf(line, FPS, step=2)
    for generated in output:
        if r"\move(" in generated.text:
            match = re.search(
                r"\\move\(([\d.-]+),([\d.-]+),([\d.-]+),([\d.-]+)",
                generated.text,
            )
            assert match is not None
            x1, y1, x2, y2 = [float(match.group(index)) for index in range(1, 5)]
            assert not (x1 == 0 and y1 == 0 and x2 == 500 and y2 == 300)


def test_step_four_resolves_fad_into_alpha() -> None:
    """Grouped output should still resolve fades into alpha tags."""
    line = make_motion_event(r"{\pos(0,0)\fad(200,200)}", 0, 1000)
    output = line_to_fbf(line, FPS, step=4)
    assert all(r"\fad(" not in generated.text for generated in output)
    assert all(r"\alpha" in generated.text for generated in output)


def test_duplicate_tags_use_the_last_effective_value() -> None:
    """Duplicate ASS tags should resolve using the last value in the block."""
    extracted = extract_all_tags_from_block(r"\fs20\fs30\c&H0000FF&\c&HFF0000&")
    assert extracted["fs"] == "30"
    assert extracted["c"] == "&HFF0000&"


def test_step_greater_than_one_keeps_clip_only_transforms_valid() -> None:
    """Clip-only grouped transforms should not emit an empty transform payload."""
    line = make_motion_event(
        r"{\clip(m 0 0 l 10 0 10 10 0 10)\t(\clip(m 0 0 l 20 0 20 20 0 20))}x",
        1000,
        2000,
    )
    output = line_to_fbf(line, FPS, step=2)
    assert r"\t(" in output[0].text
    assert r"\clip(" in output[0].text
    assert ",)" not in output[0].text


def test_step_greater_than_one_uses_the_current_step_start_state() -> None:
    """Grouped transforms should seed each chunk from its actual start state."""
    line = make_motion_event(r"{\fscx100\t(\fscx200)}x", 1000, 2000)
    output = line_to_fbf(line, FPS, step=2)
    assert output[1].text.startswith(r"{\fscx108")


def test_collect_initial_data_ignores_malformed_move_tags() -> None:
    """Malformed move payloads should not become active motion state."""
    data = collect_initial_data(r"{\move(10,20,30)}x")
    assert "move" not in data


def test_expand_document_to_fbf_expands_only_selected_event_types() -> None:
    """Document expansion should expand selected events and preserve others."""
    dialogue = make_motion_event(r"{\frz0\t(\frz360)}x", 0, 1000)
    comment = make_comment_event("note", "keep", start_time=0, end_time=1000)
    document = AssDocument(events=[dialogue, comment], section_order=["events"])

    expanded = expand_document_to_fbf(document, FPS)

    assert len(expanded.events) == 25
    assert expanded.events[-1].event_type is EventType.COMMENT
    assert expanded.events[-1].text == "keep"


def test_expand_document_to_fbf_can_expand_comment_events_too() -> None:
    """Document expansion should respect the explicit event-type filter."""
    comment = make_comment_event(
        "note",
        r"{\frz0\t(\frz360)}x",
        start_time=0,
        end_time=1000,
    )
    document = AssDocument(events=[comment], section_order=["events"])

    expanded = expand_document_to_fbf(
        document,
        FPS,
        event_types=(EventType.COMMENT,),
    )

    assert len(expanded.events) == 24
    assert all(event.event_type is EventType.COMMENT for event in expanded.events)


def test_expand_document_to_fbf_uses_document_playback_fps_when_not_explicit() -> None:
    """Document expansion should resolve PlaybackFPS from script metadata."""
    dialogue = make_motion_event(r"{\frz0\t(\frz360)}x", 0, 1000)
    document = AssDocument(
        script_info=make_script_info(extra_fields=[("PlaybackFPS", "24")]),
        events=[dialogue],
        section_order=["script_info", "events"],
    )

    expanded = expand_document_to_fbf(document)

    assert len(expanded.events) == 24


def test_expand_document_to_fbf_falls_back_to_dummy_video_fps() -> None:
    """Document expansion should resolve dummy-video FPS when needed."""
    dialogue = make_motion_event(r"{\frz0\t(\frz360)}x", 0, 1000)
    document = AssDocument(
        events=[dialogue],
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=["Video File: ?dummy:24:40000:1280:720:0:0:0:"],
            )
        ],
        section_order=["events", "raw:0"],
    )

    expanded = expand_document_to_fbf(document)

    assert len(expanded.events) == 24


def test_expand_document_to_fbf_prefers_explicit_framerate() -> None:
    """An explicit framerate argument should override document fallbacks."""
    dialogue = make_motion_event(r"{\frz0\t(\frz360)}x", 0, 1000)
    document = AssDocument(
        script_info=make_script_info(extra_fields=[("PlaybackFPS", "12")]),
        other_sections=[
            RawSection(
                name="Aegisub Project Garbage",
                lines=["Video File: ?dummy:6:40000:1280:720:0:0:0:"],
            )
        ],
        events=[dialogue],
        section_order=["script_info", "raw:0", "events"],
    )

    expanded = expand_document_to_fbf(document, 24.0)

    assert len(expanded.events) == 24


def test_expand_document_to_fbf_requires_a_resolvable_frame_source() -> None:
    """Document expansion should fail when the document has no frame source."""
    dialogue = make_motion_event(r"{\frz0\t(\frz360)}x", 0, 1000)
    document = AssDocument(events=[dialogue], section_order=["events"])

    with pytest.raises(
        PykaraValidationError,
        match=r"frame-baked expansion requires explicit timecodes or PlaybackFPS",
    ):
        expand_document_to_fbf(document)
