"""Tests for eval/exec helpers."""

from pykara.engine.evaluator import eval_expression, exec_code


def test_eval_expression_returns_the_expression_result() -> None:
    """The eval wrapper should return the computed value."""
    context: dict[str, object] = {"value": 5}

    assert eval_expression("value + 7", context) == 12


def test_exec_code_mutates_the_shared_context() -> None:
    """The exec wrapper should preserve updates in-place."""
    context: dict[str, object] = {}

    exec_code("counter = 41\ncounter += 1", context)

    assert context["counter"] == 42
