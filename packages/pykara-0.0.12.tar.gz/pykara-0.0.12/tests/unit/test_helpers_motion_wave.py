"""Tests for wave motion in the shad and fbf helper families."""

from __future__ import annotations

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.exceptions import PykaraValidationError
from pykara.helpers.motion import MotionHelper
from pykara.motion.wave.request import WaveFbfRequest


def test_shad_wave_returns_nonempty_string() -> None:
    """motion.shad.wave() should return a non-empty string in line runtime."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.wave(100, 900, 400)
    assert isinstance(result, str)
    assert len(result) > 0
    assert r"\t(" in result


def test_shad_wave_requires_line_runtime() -> None:
    """motion.shad.wave() should raise a library validation error without line."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.shad\.wave\(\) requires line runtime",
    ):
        MotionHelper(runtime).shad.wave(100, 900, 400)


def test_shad_wave_segments_param_is_forwarded() -> None:
    """The segments argument should control the number of \\t tags."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    motion = MotionHelper(runtime)

    result_8 = motion.shad.wave(100, 900, 400, segments=8)
    result_16 = motion.shad.wave(100, 900, 400, segments=16)
    assert result_8.count(r"\t(") == 16
    assert result_16.count(r"\t(") == 32


def test_shad_wave_default_segments_is_32() -> None:
    """motion.shad.wave() default should produce 32 segments (64 \\t tags)."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = MotionHelper(runtime).shad.wave(100, 900, 400)
    assert result.count(r"\t(") == 64


def test_fbf_wave_queues_request_and_returns_empty_string() -> None:
    """motion.fbf.wave() should queue a WaveFbfRequest and return ''."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line, framerate=24.0)

    result = MotionHelper(runtime).fbf.wave(100, 900, 400)
    assert result == ""
    assert runtime.consume_fbf_request() == WaveFbfRequest(x0=100, x1=900, y_base=400)


def test_fbf_wave_queues_request_with_custom_params() -> None:
    """motion.fbf.wave() should forward all optional parameters."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 500
    line.y = 400
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line, framerate=24.0)

    MotionHelper(runtime).fbf.wave(
        100,
        900,
        400,
        amplitude=200.0,
        frequency=3.0,
        phase=90.0,
    )
    assert runtime.consume_fbf_request() == WaveFbfRequest(
        x0=100,
        x1=900,
        y_base=400,
        amplitude=200.0,
        frequency=3.0,
        phase=90.0,
    )


def test_fbf_wave_requires_line_runtime() -> None:
    """motion.fbf.wave() should raise a library validation error without line."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.wave\(\) requires line runtime",
    ):
        MotionHelper(runtime).fbf.wave(100, 900, 400)


def test_fbf_wave_requires_framerate() -> None:
    """motion.fbf.wave() should raise a library validation error without FPS."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.fbf\.wave\(\) requires explicit timecodes or PlaybackFPS",
    ):
        MotionHelper(runtime).fbf.wave(100, 900, 400)
