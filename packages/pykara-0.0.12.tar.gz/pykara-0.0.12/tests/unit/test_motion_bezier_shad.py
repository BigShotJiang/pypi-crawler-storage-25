"""Tests for the shadow-trick Bezier motion builder."""

from __future__ import annotations

from pykara.motion.bezier.shad import build_shad_bezier


def test_build_shad_bezier_quadratic_returns_nonempty_string() -> None:
    """Quadratic Bezier shad builder should return a non-empty tag string."""
    pts = [(100.0, 600.0), (500.0, 100.0), (900.0, 600.0)]
    result = build_shad_bezier(1000, 500, 400, pts)
    assert isinstance(result, str)
    assert len(result) > 0


def test_build_shad_bezier_cubic_returns_nonempty_string() -> None:
    """Cubic Bezier shad builder should return a non-empty tag string."""
    pts = [(100.0, 600.0), (300.0, 100.0), (700.0, 700.0), (900.0, 200.0)]
    result = build_shad_bezier(1000, 500, 400, pts, segments=32)
    assert isinstance(result, str)
    assert len(result) > 0


def test_build_shad_bezier_contains_t_segments() -> None:
    r"""Bezier shad should emit ``\t(`` sequences."""
    pts = [(100.0, 600.0), (500.0, 100.0), (900.0, 600.0)]
    result = build_shad_bezier(1000, 500, 400, pts)
    assert r"\t(" in result


def test_build_shad_bezier_segments_param_controls_t_count() -> None:
    """More segments should produce more ``\\t`` tags."""
    pts = [(100.0, 600.0), (500.0, 100.0), (900.0, 600.0)]
    result_8 = build_shad_bezier(1000, 500, 400, pts, segments=8)
    result_16 = build_shad_bezier(1000, 500, 400, pts, segments=16)
    assert result_8.count(r"\t(") == 16
    assert result_16.count(r"\t(") == 32


def test_build_shad_bezier_quadratic_first_position() -> None:
    r"""First fix-start position should match bezier_xy(0, points)."""
    pts = [(100.0, 600.0), (500.0, 100.0), (900.0, 600.0)]
    result = build_shad_bezier(1000, 500, 400, pts)
    assert r"\t(0,0,\xshad-400\yshad200)" in result


def test_build_shad_bezier_t1_t2_none_defaults_to_full_duration() -> None:
    """Omitting t1/t2 should span the full duration."""
    pts = [(100.0, 600.0), (500.0, 100.0), (900.0, 600.0)]
    result_none = build_shad_bezier(1000, 500, 400, pts)
    result_explicit = build_shad_bezier(1000, 500, 400, pts, t1=0, t2=1000)
    assert result_none.count(r"\t(") == result_explicit.count(r"\t(")


def test_build_shad_bezier_xshad_zero_replaced_with_minimum() -> None:
    r"""``\xshad0`` must be ``\xshad0.001`` to keep shadow active."""
    pts = [(500.0, 200.0), (500.0, 400.0), (500.0, 600.0)]
    result = build_shad_bezier(1000, 500, 400, pts, segments=1)
    assert r"\xshad0\y" not in result
