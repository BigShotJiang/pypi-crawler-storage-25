"""Tests for motion positioning inference."""

from __future__ import annotations

from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.motion.runtime.runtime_geometry import motion_anchor


def test_motion_anchor_line_scope_uses_line_xy() -> None:
    """Without char/word/syl, motion_anchor should return line.x, line.y."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    line.x = 320
    line.y = 180
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    assert motion_anchor(runtime) == (320, 180)


def test_motion_anchor_syl_scope_uses_syl_abs_center_and_abs_middle() -> None:
    """In syl scope, motion_anchor should use syl.abs_center and syl.abs_middle."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}cd", start_time=1000, end_time=1600)
    line.x = 100
    line.y = 200
    syl = line.syls[0]
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=syl)
    x, y = motion_anchor(runtime)
    assert x == syl.abs_center
    assert y == syl.abs_middle


def test_motion_anchor_char_scope_uses_char_abs_center_and_line_y() -> None:
    """In char scope, motion_anchor should use char.abs_center and line.y."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}cd", start_time=1000, end_time=1600)
    line.y = 360
    char = line.chars[0]
    runtime = ExecutionRuntime(scope=Scope.CHAR, line=line, char=char)
    x, y = motion_anchor(runtime)
    assert x == char.abs_center
    assert y == line.y


def test_motion_anchor_word_scope_uses_word_abs_center_and_line_y() -> None:
    """In word scope, motion_anchor should use word.abs_center and line.y."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}cd", start_time=1000, end_time=1600)
    line.y = 540
    word = line.words[0]
    runtime = ExecutionRuntime(scope=Scope.WORD, line=line, word=word)
    x, y = motion_anchor(runtime)
    assert x == word.abs_center
    assert y == line.y


def test_motion_anchor_line_scope_an5_uses_line_xy() -> None:
    r"""\\an5 line: motion_anchor should still use line.x and line.y."""
    line = parse_karaoke_line(r"{\an5\k10}ab", start_time=1000, end_time=2000)
    line.x = 640
    line.y = 360
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    assert motion_anchor(runtime) == (640, 360)


def test_motion_anchor_syl_scope_an5_uses_syl_coords() -> None:
    r"""\\an5 syl: motion_anchor should use syl absolute centre/middle."""
    line = parse_karaoke_line(r"{\an5\k10}ab{\k20}cd", start_time=1000, end_time=1600)
    syl = line.syls[0]
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=syl)
    x, y = motion_anchor(runtime)
    assert x == syl.abs_center
    assert y == syl.abs_middle
