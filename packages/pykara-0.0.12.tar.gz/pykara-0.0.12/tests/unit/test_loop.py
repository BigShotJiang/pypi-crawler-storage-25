"""Tests for loop and skip helpers."""

from __future__ import annotations

from tests.support import parse_karaoke_line

from pykara.directive.parser import parse_directive
from pykara.directive.types import Scope, TemplateDirective
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.engine.loop import (
    append_scope_text,
    expand_highlight_runtimes,
    expand_repeat_bindings,
    repeat_modifiers,
    should_skip,
)


def _directive(effect: str) -> TemplateDirective:
    parsed = parse_directive(effect)
    assert isinstance(parsed, TemplateDirective)
    return parsed


def test_should_skip_respects_no_blank() -> None:
    """Blank syllables should be skipped when ``no_blank`` is present."""
    line = parse_karaoke_line(r"{\k10}a{\k10} {\k10}b", start_time=0, end_time=600)
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[1])

    assert should_skip(_directive("template syl no_blank"), runtime)


def test_should_skip_filters_by_inline_fx() -> None:
    """The inline-fx filter should match the current syllable."""
    line = parse_karaoke_line(r"{\-foo\k10}a{\-bar\k10}b", start_time=0, end_time=600)
    foo_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])
    bar_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[1])

    directive = _directive("template syl inline_fx foo")

    assert not should_skip(directive, foo_runtime)
    assert should_skip(directive, bar_runtime)


def test_should_skip_evaluates_when_and_unless_conditions() -> None:
    """Conditional modifiers should use either expressions or tokens."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", start_time=0, end_time=600)
    expression_runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=line.syls[1],
    )
    token_runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=line.syls[1],
        syl_state={"enabled": True, "disabled": True},
    )

    assert not should_skip(
        _directive("template syl when (syl.duration > 150)"),
        expression_runtime,
    )
    assert not should_skip(_directive("template syl when enabled"), token_runtime)
    assert should_skip(_directive("template syl unless disabled"), token_runtime)


def test_should_skip_uses_char_inline_fx_and_unless_expression() -> None:
    """Char runtimes should read inline-fx from their parent syllable."""
    line = parse_karaoke_line(r"{\-flash\k10}ab", start_time=0, end_time=600)
    char_runtime = ExecutionRuntime(
        scope=Scope.CHAR,
        line=line,
        word=line.words[0],
        syl=line.syls[0],
        char=line.chars[0],
    )

    assert not should_skip(_directive("template char inline_fx flash"), char_runtime)
    assert should_skip(
        _directive("template char unless (char.text == 'a')"),
        char_runtime,
    )


def test_repeat_and_no_text_helpers_follow_modifiers() -> None:
    """Loop helpers should reflect ``repeat`` and ``no_text`` modifiers."""
    repeat_directive = _directive("template syl repeat outer 2 repeat inner 3")
    no_text_directive = _directive("template syl no_text")
    first_repeat = _directive("template syl repeat outer 2").modifiers[0]
    second_repeat = _directive("template syl repeat inner 3").modifiers[0]

    assert repeat_modifiers(repeat_directive) == [
        first_repeat,
        second_repeat,
    ]
    assert not append_scope_text(no_text_directive)


def test_expand_repeat_bindings_uses_cartesian_order() -> None:
    """Repeat loops should expand in declaration order with the last varying fastest."""
    directive = _directive("template syl repeat outer 2 repeat inner 3")

    bindings = expand_repeat_bindings(directive)

    assert [
        tuple((binding.key, binding.index, binding.count) for binding in group)
        for group in bindings
    ] == [
        (("outer", 1, 2), ("inner", 1, 3)),
        (("outer", 1, 2), ("inner", 2, 3)),
        (("outer", 1, 2), ("inner", 3, 3)),
        (("outer", 2, 2), ("inner", 1, 3)),
        (("outer", 2, 2), ("inner", 2, 3)),
        (("outer", 2, 2), ("inner", 3, 3)),
    ]


def test_expand_highlight_runtimes_uses_syllable_highlights() -> None:
    """The ``multi`` modifier should produce one template pass per highlight."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}#cd", start_time=0, end_time=600)
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])

    runtimes = expand_highlight_runtimes(_directive("template syl multi"), runtime)

    intervals: list[tuple[int, int]] = []
    for item in runtimes:
        assert item.syl is not None
        intervals.append((item.syl.start_time, item.syl.end_time))

    assert intervals == [
        (0, 100),
        (100, 300),
    ]
