"""Tests for shared curve math utilities."""

from __future__ import annotations

import pytest

from pykara.math.curves import sample_curve
from pykara.motion.runtime.window import progress, resolve_window


def test_resolve_window_returns_full_duration_when_t1_is_none() -> None:
    """None t1 should map to full duration."""
    assert resolve_window(None, 500.0, 1000) == (0.0, 1000.0)


def test_resolve_window_returns_full_duration_when_t2_is_none() -> None:
    """None t2 should map to full duration."""
    assert resolve_window(200.0, None, 1000) == (0.0, 1000.0)


def test_resolve_window_returns_full_duration_when_both_zero_or_negative() -> None:
    """Both non-positive values should map to full duration."""
    assert resolve_window(0.0, 0.0, 1000) == (0.0, 1000.0)
    assert resolve_window(-100.0, 0.0, 1000) == (0.0, 1000.0)


def test_resolve_window_swaps_when_t2_less_than_t1() -> None:
    """Out-of-order bounds should be swapped."""
    assert resolve_window(800.0, 200.0, 1000) == (200.0, 800.0)


def test_resolve_window_returns_explicit_bounds_when_valid() -> None:
    """Positive valid bounds should be returned as-is."""
    assert resolve_window(100.0, 900.0, 1000) == (100.0, 900.0)


def test_resolve_window_returns_floats() -> None:
    """Return values should always be floats."""
    tw1, tw2 = resolve_window(100, 900, 1000)
    assert isinstance(tw1, float)
    assert isinstance(tw2, float)


def test_progress_returns_zero_at_or_before_window_start() -> None:
    """Progress should clamp to 0.0 at and before tw1."""
    assert progress(0.0, 100.0, 900.0) == 0.0
    assert progress(50.0, 100.0, 900.0) == 0.0
    assert progress(100.0, 100.0, 900.0) == 0.0


def test_progress_returns_one_at_or_after_window_end() -> None:
    """Progress should clamp to 1.0 at and after tw2."""
    assert progress(900.0, 100.0, 900.0) == 1.0
    assert progress(1000.0, 100.0, 900.0) == 1.0


def test_progress_returns_midpoint_correctly() -> None:
    """Progress at the midpoint of the window should be 0.5."""
    assert progress(500.0, 0.0, 1000.0) == pytest.approx(0.5)


def test_progress_interpolates_linearly() -> None:
    """Progress should increase linearly within the window."""
    tw1, tw2 = 200.0, 800.0
    assert progress(200.0, tw1, tw2) == pytest.approx(0.0)
    assert progress(500.0, tw1, tw2) == pytest.approx(0.5)
    assert progress(800.0, tw1, tw2) == pytest.approx(1.0)


def test_sample_curve_returns_correct_segment_count() -> None:
    """sample_curve should return exactly n_segments tuples."""
    result = sample_curve(lambda t: (t, t), 8, 0.0, 1000.0)
    assert len(result) == 8


def test_sample_curve_first_segment_starts_at_tw1() -> None:
    """The first segment should start at tw1."""
    result = sample_curve(lambda t: (t * 100, 0.0), 4, 200.0, 600.0)
    ms0, *_ = result[0]
    assert ms0 == pytest.approx(200.0)


def test_sample_curve_last_segment_ends_at_tw2() -> None:
    """The last segment should end at tw2."""
    result = sample_curve(lambda t: (t * 100, 0.0), 4, 200.0, 600.0)
    _, ms1, *_ = result[-1]
    assert ms1 == pytest.approx(600.0)


def test_sample_curve_segments_are_contiguous() -> None:
    """Adjacent segments should share boundary times."""
    result = sample_curve(lambda t: (t, t), 5, 0.0, 500.0)
    for i in range(len(result) - 1):
        assert result[i][1] == pytest.approx(result[i + 1][0])


def test_sample_curve_boundary_values_match_curve() -> None:
    """Start and end positions should equal curve(0) and curve(1)."""

    def curve(t: float) -> tuple[float, float]:
        return t * 100, t * 200

    result = sample_curve(curve, 4, 0.0, 1000.0)
    _, _, x0_first, y0_first, _, _ = result[0]
    assert x0_first == pytest.approx(0.0)
    assert y0_first == pytest.approx(0.0)
    _, _, _, _, x1_last, y1_last = result[-1]
    assert x1_last == pytest.approx(100.0)
    assert y1_last == pytest.approx(200.0)
