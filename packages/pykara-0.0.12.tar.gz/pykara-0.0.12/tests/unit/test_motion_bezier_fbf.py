"""Tests for the frame-baked Bezier motion builder."""

from __future__ import annotations

import pytest
from tests.support import make_motion_event

from pykara.exceptions import PykaraValidationError
from pykara.motion.bezier.fbf import bezier_fbf_line
from pykara.motion.bezier.request import BezierFbfRequest


def test_bezier_fbf_line_quadratic_returns_correct_frame_count() -> None:
    """Quadratic Bezier FBF should produce one frame per frame bucket."""
    line = make_motion_event(r"{\an5}X")
    pts = [(100.0, 600.0), (500.0, 100.0), (900.0, 600.0)]
    result = bezier_fbf_line(line, 24.0, pts)
    assert len(result) == 24


def test_bezier_fbf_line_cubic_returns_correct_frame_count() -> None:
    """Cubic Bezier FBF should produce one frame per frame bucket."""
    line = make_motion_event(r"{\an5}X")
    pts = [(100.0, 600.0), (300.0, 100.0), (700.0, 700.0), (900.0, 200.0)]
    result = bezier_fbf_line(line, 24.0, pts)
    assert len(result) == 24


def test_bezier_fbf_line_each_frame_has_pos() -> None:
    r"""Every FBF Bezier frame should contain a ``\pos(`` tag."""
    line = make_motion_event(r"{\an5}X")
    pts = [(100.0, 600.0), (500.0, 100.0), (900.0, 600.0)]
    result = bezier_fbf_line(line, 24.0, pts)
    assert all(r"\pos(" in frame.text for frame in result)


def test_bezier_fbf_line_start_position_is_near_p0() -> None:
    r"""First frame position should be closer to p0 than to p2."""
    import re

    line = make_motion_event(r"{\an5}X")
    pts = [(100.0, 600.0), (500.0, 100.0), (900.0, 600.0)]
    result = bezier_fbf_line(line, 24.0, pts)
    m = re.search(r"\\pos\(([\d.-]+),([\d.-]+)\)", result[0].text)
    assert m is not None
    x = float(m.group(1))
    assert x < 200.0


def test_bezier_fbf_line_timing_is_correct() -> None:
    """FBF frames should cover the full line interval."""
    line = make_motion_event(r"{\an5}X")
    pts = [(100.0, 600.0), (500.0, 100.0), (900.0, 600.0)]
    result = bezier_fbf_line(line, 24.0, pts)
    assert result[0].start_time == 1000
    assert result[-1].end_time == 2000


def test_bezier_fbf_request_expands_correctly() -> None:
    """BezierFbfRequest.expand() should delegate to bezier_fbf_line."""
    pts = ((100.0, 600.0), (500.0, 100.0), (900.0, 600.0))
    request = BezierFbfRequest(points=pts)
    result = request.expand(make_motion_event(r"{\an5}X"), 24.0)
    assert len(result) == 24
    assert all(r"\pos(" in frame.text for frame in result)


def test_bezier_fbf_line_invalid_point_count_raises() -> None:
    """Two control points should raise a library validation error."""
    line = make_motion_event(r"{\an5}X")
    with pytest.raises(
        PykaraValidationError,
        match=r"motion\.bezier\.bezier_xy\(\) requires 3 or 4 control points",
    ):
        bezier_fbf_line(line, 24.0, [(0.0, 0.0), (100.0, 100.0)])
