"""Tests for the color helper."""

import pytest

from pykara.exceptions import PykaraValidationError
from pykara.helpers.color import ColorHelper


def test_ass_color_round_trip() -> None:
    """The color helper should format and parse ASS colors."""
    color = ColorHelper()

    assert color.rgb.to_ass(255, 0, 16) == "&H1000FF&"
    assert color.ass.parse("&H1000FF&") == (255, 0, 16)


def test_color_helper_exposes_only_format_contexts() -> None:
    """The root helper should expose the format-specific contexts only."""
    color = ColorHelper()

    assert vars(color) == {
        "rgb": color.rgb,
        "hex": color.hex,
        "ass": color.ass,
        "hsv": color.hsv,
    }


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("#fff", "&HFFFFFF&"),
        ("#ffffff", "&HFFFFFF&"),
        ("#AbC", "&HCCBBAA&"),
        ("#123abc", "&HBC3A12&"),
    ],
)
def test_hex_to_ass_converts_hex_to_ass_color(value: str, expected: str) -> None:
    """Hex colors should convert to ASS ``&HBBGGRR&`` strings."""
    color = ColorHelper()

    assert color.hex.to_ass(value) == expected


def test_hsv_context_to_rgb_matches_primary_hues() -> None:
    """The color helper should expose the reference HSV-to-RGB helper."""
    color = ColorHelper()

    assert color.hsv.to_rgb(0, 1, 1) == (255, 0, 0)
    assert color.hsv.to_rgb(120, 1, 1) == (0, 255, 0)
    assert color.hsv.to_rgb(240, 1, 1) == (0, 0, 255)


def test_parse_accepts_ass_alpha_prefix() -> None:
    """Eight-digit ASS colors should ignore the alpha prefix."""
    color = ColorHelper()

    assert color.ass.parse("&HAA1000FF&") == (255, 0, 16)


@pytest.mark.parametrize("value", ["1000FF", "&H1000FF", "&H1000F&"])
def test_parse_rejects_invalid_ass_colors(value: str) -> None:
    """Malformed ASS colors should raise ``PykaraValidationError``."""
    color = ColorHelper()

    with pytest.raises(PykaraValidationError, match="Invalid ASS color"):
        color.ass.parse(value)


@pytest.mark.parametrize(
    "value", ["", "123", "fff", "  #AbC  ", "#ff", "#ffff", "#fffffg"]
)
def test_hex_to_ass_rejects_invalid_hex_colors(value: str) -> None:
    """Malformed hex colors should raise ``PykaraValidationError``."""
    color = ColorHelper()

    with pytest.raises(PykaraValidationError, match="Invalid hex color"):
        color.hex.to_ass(value)


def test_hsv_context_to_rgb_wraps_degree_hues() -> None:
    """Hue values should wrap on the degree-based scale."""
    color = ColorHelper()

    assert color.hsv.to_rgb(360, 1, 1) == (255, 0, 0)
    assert color.hsv.to_rgb(-120, 1, 1) == (0, 0, 255)
