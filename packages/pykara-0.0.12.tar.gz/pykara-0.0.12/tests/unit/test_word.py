"""Tests for word decomposition."""

from pykara.karaoke.syllable import Syllable
from pykara.karaoke.word import split_words


def test_split_words_groups_space_runs_with_previous_word() -> None:
    """Whitespace should attach to the preceding word."""
    syllables = [
        Syllable(0, 200, 200, 20, "go ", r"\k", "", si=1, ci=1),
        Syllable(200, 400, 200, 20, "home", r"\k", "", si=2, ci=4),
        Syllable(400, 600, 200, 20, " now", r"\k", "", si=3, ci=8),
    ]

    words = split_words(syllables)

    assert [word.text for word in words] == ["go ", "home ", "now"]
    assert [(word.wi, word.ci) for word in words] == [(1, 1), (2, 4), (3, 9)]
    assert [(word.start_time, word.duration) for word in words] == [
        (0, 200),
        (200, 400),
        (400, 200),
    ]
