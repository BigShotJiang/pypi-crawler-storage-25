"""Tests for template interpolation."""

from __future__ import annotations

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime, RepeatBinding
from pykara.engine.interpolator import interpolate
from pykara.exceptions import PykaraAttributeError, PykaraValidationError


def test_interpolate_substitutes_scope_variables() -> None:
    """``$variables`` should resolve against the current scope."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=line.syls[1],
        line_index=3,
    )

    assert interpolate("[$line_li][$syl_start][$syl_dur]", runtime) == "[3][100][200]"


def test_interpolate_treats_variable_names_as_case_insensitive() -> None:
    """``$variables`` should resolve regardless of case."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=line.syls[1],
        line_index=3,
    )

    assert interpolate("[$LINE_LI][$Syl_Start][$SYL_DUR]", runtime) == "[3][100][200]"


def test_interpolate_evaluates_python_expressions() -> None:
    """``!expression!`` should see the same scope objects."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[1])

    assert interpolate("!syl.start_time! / !line.duration!", runtime) == "100 / 400"


@pytest.mark.parametrize(
    ("plain_expression", "parenthesized_expression", "expected"),
    [
        ("!syl.duration * 0.5!", "!(syl.duration * 0.5)!", "100.0"),
        (
            "!syl.start_time + line.duration!",
            "!(syl.start_time + line.duration)!",
            "500",
        ),
        ("!syl.duration > 100!", "!(syl.duration > 100)!", "True"),
    ],
)
def test_interpolate_treats_parenthesized_and_plain_expression_forms_as_equivalent(
    plain_expression: str,
    parenthesized_expression: str,
    expected: str,
) -> None:
    """Wrapping the whole ``!expression!`` payload in parentheses should not
    change it."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[1])

    assert interpolate(plain_expression, runtime) == expected
    assert interpolate(parenthesized_expression, runtime) == expected


def test_interpolate_allows_dollar_variables_inside_expression() -> None:
    """``$var`` usage inside ``!expression!`` should resolve before evaluation."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[1])

    assert interpolate("!$syl_start + $syl_dur!", runtime) == "300"


def test_interpolate_rejects_unterminated_expression_segments() -> None:
    """An unmatched ``!`` should fail instead of silently truncating the body."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])

    with pytest.raises(
        PykaraValidationError,
        match="Unterminated !expression! segment",
    ):
        interpolate("prefix !syl.start_time", runtime)


def test_interpolate_rejects_out_of_scope_and_unknown_variables() -> None:
    """Scope boundaries and unknown names should raise errors."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    line_runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    syl_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])

    with pytest.raises(PykaraValidationError, match=r"\$syl_start"):
        interpolate("$syl_start", line_runtime)
    with pytest.raises(PykaraValidationError, match=r"\$word_wi"):
        interpolate("$word_wi", syl_runtime)
    with pytest.raises(PykaraValidationError, match=r"\$foo_bar"):
        interpolate("$foo_bar", syl_runtime)


def test_interpolate_converts_none_to_empty_string() -> None:
    """A ``None`` expression result should emit an empty string."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])

    assert interpolate("a!None!b", runtime) == "ab"


def test_interpolate_preserves_the_specified_substitution_order() -> None:
    """Variables resolve before independent expression evaluation."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[1])

    assert interpolate("$syl_start|!syl.start_time!", runtime) == "100|100"


def test_interpolate_exposes_repeat_state_in_variables_and_expression() -> None:
    """Repeat state should be available via both $variables and repeat.*."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=line.syls[0],
        repeat_loops=(RepeatBinding(name="outer", index=2, count=4),),
    )

    assert (
        interpolate(
            "$repeat_i|$repeat_n|$repeat_outer_i|$repeat_outer_n|!repeat.i!|!repeat.n!|!repeat.outer.i!|!repeat.outer.n!",
            runtime,
        )
        == "2|4|2|4|2|4|2|4"
    )


def test_interpolate_rejects_generic_repeat_access_with_multiple_loops() -> None:
    """Generic repeat aliases are invalid when more than one loop exists."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c", end_time=1400)
    runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=line.syls[0],
        repeat_loops=(
            RepeatBinding(name="outer", index=1, count=2),
            RepeatBinding(name="inner", index=2, count=3),
        ),
    )

    with pytest.raises(PykaraValidationError, match="requires exactly one repeat loop"):
        interpolate("$repeat_i", runtime)

    with pytest.raises(
        PykaraAttributeError,
        match=r"repeat\.i requires exactly one active repeat loop",
    ):
        interpolate("!repeat.i!", runtime)
