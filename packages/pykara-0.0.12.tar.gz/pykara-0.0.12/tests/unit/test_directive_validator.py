"""Tests for directive validation."""

from typing import cast

import pytest

from pykara.directive.parser import parse_directive
from pykara.directive.types import (
    Expression,
    ForMod,
    InlineFxMod,
    LayerMod,
    MultiMod,
    NoblankMod,
    NotextMod,
    PatchDirective,
    PatchModifier,
    PrependMod,
    RepeatMod,
    Scope,
    TemplateDirective,
    TemplateModifier,
    Token,
    UnlessMod,
    WhenMod,
)
from pykara.directive.validator import validate_directive
from pykara.exceptions import PykaraValidationError


def test_validate_accepts_legal_directives() -> None:
    """Validator should accept representative legal directives."""
    directives = [
        parse_directive("code setup"),
        parse_directive("template line"),
        parse_directive("template word repeat 2"),
        parse_directive(
            "template syl no_blank multi repeat outer 2 repeat inner 3 inline_fx glow"
        ),
        parse_directive("template char inline_fx glow unless enabled"),
        parse_directive("patch line prepend layer 2"),
        parse_directive("patch char no_blank inline_fx flash for high-light"),
    ]

    for directive in directives:
        assert directive is not None
        validate_directive(directive)


def test_validate_rejects_code_with_modifier_text() -> None:
    """Code directives cannot have modifiers."""
    with pytest.raises(PykaraValidationError, match="do not accept modifiers"):
        parse_directive("code syl no_blank")


def test_validate_rejects_duplicate_modifier() -> None:
    """Each modifier can appear at most once."""
    directive = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[NoblankMod(), NoblankMod()],
    )

    with pytest.raises(PykaraValidationError, match="Duplicate modifier"):
        validate_directive(directive)


def test_validate_rejects_when_and_unless_together() -> None:
    """When and unless are mutually exclusive."""
    directive = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            WhenMod(condition=Token(name="foo")),
            UnlessMod(condition=Token(name="bar")),
        ],
    )

    with pytest.raises(
        PykaraValidationError,
        match=r"out of order|cannot coexist|last modifier",
    ):
        validate_directive(directive)


def test_validate_rejects_when_not_last() -> None:
    """When must be the last modifier."""
    when_directive = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            WhenMod(condition=Expression(code="syl.duration > 200")),
            RepeatMod(name=None, count=2),
        ],
    )
    unless_directive = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            UnlessMod(condition=Token(name="disabled")),
            RepeatMod(name=None, count=2),
        ],
    )

    with pytest.raises(PykaraValidationError, match=r"out of order|last modifier"):
        validate_directive(when_directive)
    with pytest.raises(PykaraValidationError, match=r"out of order|last modifier"):
        validate_directive(unless_directive)


def test_validate_rejects_modifiers_out_of_order() -> None:
    """Modifiers must follow the spec order."""
    directive = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[RepeatMod(name=None, count=2), NotextMod()],
    )

    with pytest.raises(PykaraValidationError, match="out of order"):
        validate_directive(directive)


def test_validate_rejects_multi_outside_template_syl() -> None:
    """Multi is only valid in template syl."""
    directive = TemplateDirective(scope=Scope.LINE, modifiers=[MultiMod()])

    with pytest.raises(PykaraValidationError, match="multi is only valid"):
        validate_directive(directive)


def test_validate_rejects_inline_fx_outside_syl_or_char() -> None:
    """inline_fx is only valid in template syl and char."""
    directive = TemplateDirective(
        scope=Scope.WORD,
        modifiers=[InlineFxMod(name="glow")],
    )

    with pytest.raises(PykaraValidationError, match="inline_fx is only valid"):
        validate_directive(directive)


def test_validate_rejects_patch_inline_fx_outside_syl_or_char() -> None:
    """Patch inline_fx is only valid in patch syl and char."""
    directive = PatchDirective(
        scope=Scope.WORD,
        modifiers=[InlineFxMod(name="glow")],
    )

    with pytest.raises(PykaraValidationError, match="inline_fx is only valid"):
        validate_directive(directive)


def test_validate_rejects_repeat_less_than_one() -> None:
    """Repeat must be >= 1."""
    directive = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[RepeatMod(name=None, count=0)],
    )

    with pytest.raises(PykaraValidationError, match="repeat count must be >= 1"):
        validate_directive(directive)


def test_validate_rejects_invalid_repeat_combinations() -> None:
    """Repeat loops must follow the naming rules from the repeat spec."""
    duplicate_named = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            RepeatMod(name="a", count=2),
            RepeatMod(name="a", count=3),
        ],
    )
    mixed_named_and_unnamed = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            RepeatMod(name=None, count=2),
            RepeatMod(name="b", count=3),
        ],
    )
    duplicate_unnamed = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            RepeatMod(name=None, count=2),
            RepeatMod(name=None, count=3),
        ],
    )
    named_then_unnamed = TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            RepeatMod(name="b", count=3),
            RepeatMod(name=None, count=2),
        ],
    )

    with pytest.raises(PykaraValidationError, match="Duplicate repeat loop name"):
        validate_directive(duplicate_named)
    with pytest.raises(PykaraValidationError, match="cannot be mixed"):
        validate_directive(mixed_named_and_unnamed)
    with pytest.raises(PykaraValidationError, match="can only appear once"):
        validate_directive(duplicate_unnamed)
    with pytest.raises(PykaraValidationError, match="cannot be mixed"):
        validate_directive(named_then_unnamed)


def test_validate_rejects_template_setup_scope() -> None:
    """Template directives must not use setup scope."""
    directive = TemplateDirective(scope=Scope.SETUP)

    with pytest.raises(PykaraValidationError, match="do not support setup scope"):
        validate_directive(directive)


def test_validate_rejects_patch_setup_scope() -> None:
    """Patch directives must not use setup scope."""
    directive = PatchDirective(scope=Scope.SETUP)

    with pytest.raises(PykaraValidationError, match="do not support setup scope"):
        validate_directive(directive)


def test_validate_rejects_patch_modifiers_out_of_order() -> None:
    """Patch modifiers must follow the declared order."""
    directive = PatchDirective(
        scope=Scope.SYL,
        modifiers=[LayerMod(layer=2), PrependMod()],
    )

    with pytest.raises(PykaraValidationError, match="out of order"):
        validate_directive(directive)


def test_validate_rejects_template_only_modifiers_inside_patch() -> None:
    """Template-only modifiers must not be accepted on patch directives."""
    directive = PatchDirective(
        scope=Scope.SYL,
        modifiers=cast(list[PatchModifier], [NotextMod()]),
    )

    with pytest.raises(PykaraValidationError, match="not valid in patch directives"):
        validate_directive(directive)


def test_validate_rejects_patch_only_modifiers_inside_template() -> None:
    """Patch-only modifiers must not be accepted on template directives."""
    directive = TemplateDirective(
        scope=Scope.SYL,
        modifiers=cast(list[TemplateModifier], [ForMod(name="actor")]),
    )

    with pytest.raises(PykaraValidationError, match="not valid in template directives"):
        validate_directive(directive)


def test_validate_rejects_duplicate_patch_modifier() -> None:
    """Patch-only modifiers must also remain unique."""
    directive = PatchDirective(
        scope=Scope.SYL,
        modifiers=[ForMod(name="a"), ForMod(name="b")],
    )

    with pytest.raises(PykaraValidationError, match="Duplicate modifier"):
        validate_directive(directive)


@pytest.mark.parametrize(
    ("directive", "pattern"),
    [
        (
            PatchDirective(
                scope=Scope.LINE,
                modifiers=[InlineFxMod(name="glow")],
            ),
            "inline_fx is only valid",
        ),
        (
            PatchDirective(
                scope=Scope.SYL,
                modifiers=[WhenMod(condition=Token(name="foo")), PrependMod()],
            ),
            "out of order|last modifier",
        ),
        (
            PatchDirective(
                scope=Scope.SYL,
                modifiers=[UnlessMod(condition=Token(name="foo")), LayerMod(layer=1)],
            ),
            "out of order|last modifier",
        ),
        (
            PatchDirective(
                scope=Scope.SYL,
                modifiers=[
                    NoblankMod(),
                    InlineFxMod(name="glow"),
                    ForMod(name="actor"),
                    LayerMod(layer=1),
                ],
            ),
            "out of order",
        ),
        (
            PatchDirective(
                scope=Scope.SYL,
                modifiers=[
                    PrependMod(),
                    WhenMod(condition=Token(name="foo")),
                    UnlessMod(condition=Token(name="bar")),
                ],
            ),
            "out of order|last modifier",
        ),
    ],
)
def test_validate_rejects_invalid_patch_modifier_combinations(
    directive: PatchDirective,
    pattern: str,
) -> None:
    """Patch invalid modifier combinations should fail validation."""
    with pytest.raises(PykaraValidationError, match=pattern):
        validate_directive(directive)
