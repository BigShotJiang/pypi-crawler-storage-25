"""Tests for override-tag helpers."""

from pykara.karaoke.override_tags import parse_karaoke_tag, split_override_tags


def test_split_override_tags_respects_parentheses() -> None:
    """Backslashes inside parenthesized arguments should not split tags."""
    block = r"\pos(10,20)\t(0,100,\alpha&HFF&)\bord2"
    assert split_override_tags(block) == [
        r"\pos(10,20)",
        r"\t(0,100,\alpha&HFF&)",
        r"\bord2",
    ]


def test_parse_karaoke_tag_supports_supported_variants() -> None:
    """Supported karaoke tag variants should normalize correctly."""
    assert parse_karaoke_tag(r"\k36") == (r"\k", 360)
    assert parse_karaoke_tag(r"\K36") == (r"\kf", 360)
    assert parse_karaoke_tag(r"\kf12") == (r"\kf", 120)
    assert parse_karaoke_tag(r"\ko5") == (r"\ko", 50)
    assert parse_karaoke_tag(r"\kt7") == (r"\kt", 70)
    assert parse_karaoke_tag(r"\bord2") is None
