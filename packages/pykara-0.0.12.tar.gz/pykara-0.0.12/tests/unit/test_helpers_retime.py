"""Tests for the retime helper."""

from __future__ import annotations

from math import sin

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.exceptions import (
    PykaraAttributeError,
    PykaraNotImplementedError,
    PykaraTypeError,
    PykaraValidationError,
)
from pykara.helpers.retime import RetimeHelper


def _word_runtime(word_index: int) -> ExecutionRuntime:
    """Build one word-scope runtime for preset tests."""
    line = parse_karaoke_line(r"{\k10}ab {\k10}cd {\k10}ef")
    word = line.words[word_index]
    return ExecutionRuntime(
        scope=Scope.WORD,
        line_index=word_index,
        line=line,
        word=word,
    )


def _syl_runtime(syl_index: int) -> ExecutionRuntime:
    """Build one syllable-scope runtime for preset tests."""
    line = parse_karaoke_line(r"{\k10}ab {\k10}cd {\k10}ef")
    syllable = line.syls[syl_index]
    return ExecutionRuntime(
        scope=Scope.SYL,
        line_index=syl_index,
        line=line,
        syl=syllable,
    )


def _char_runtime(line_index: int, char_index: int) -> ExecutionRuntime:
    """Build one char-scope runtime for preset tests."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}cd")
    char = line.chars[char_index]
    return ExecutionRuntime(
        scope=Scope.CHAR,
        line_index=line_index,
        line=line,
        word=char.word,
        syl=char.syl,
        char=char,
    )


def _matrix_runtime(scope: Scope) -> ExecutionRuntime:
    """Return one fresh runtime with non-degenerate preset collections."""
    line = parse_karaoke_line(r"{\k10}ab {\k10}cd {\k10}ef")
    if scope is Scope.LINE:
        return ExecutionRuntime(scope=Scope.LINE, line=line)
    if scope is Scope.WORD:
        return ExecutionRuntime(scope=Scope.WORD, line=line, word=line.words[1])
    if scope is Scope.SYL:
        return ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[1])

    char = line.syls[1].chars[1]
    return ExecutionRuntime(
        scope=Scope.CHAR,
        line=line,
        word=char.word,
        syl=char.syl,
        char=char,
    )


def test_retime_line_targets_apply_expected_ranges() -> None:
    """Line-family targets should cover line, preline and postline."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c")
    full_runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    pre_runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    post_runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    assert RetimeHelper(full_runtime).line(-50, 20) == ""
    assert full_runtime.output_interval() == (-50, 620)

    RetimeHelper(pre_runtime).preline(-10, 30)
    assert pre_runtime.output_interval() == (-10, 30)

    RetimeHelper(post_runtime).postline(-20, 40)
    assert post_runtime.output_interval() == (580, 640)


def test_retime_syllable_targets_apply_expected_ranges() -> None:
    """Syllable-family targets should cover the explicit target matrix."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c")
    syllable = line.syls[1]
    full_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=syllable)
    start_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=syllable)
    end_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=syllable)

    RetimeHelper(full_runtime).syl(-5, 10)
    assert full_runtime.output_interval() == (95, 310)

    RetimeHelper(start_runtime).start2syl(-30, 0)
    assert start_runtime.output_interval() == (-30, 100)

    RetimeHelper(end_runtime).syl2end(0, 25)
    assert end_runtime.output_interval() == (300, 625)


def test_retime_syl_is_available_in_char_scope() -> None:
    """Char templates should resolve the parent syllable for retiming."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c")
    char = line.chars[-1]
    runtime = ExecutionRuntime(
        scope=Scope.CHAR,
        line=line,
        word=char.word,
        syl=char.syl,
        char=char,
    )

    RetimeHelper(runtime).presyl()

    assert runtime.output_interval() == (char.syl.start_time, char.syl.start_time)


def test_retime_rejects_invalid_scope_and_duplicate_calls() -> None:
    """Scope and exclusivity restrictions should raise errors."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}c")
    line_runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    syl_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])

    with pytest.raises(PykaraValidationError, match=r"template syl and char"):
        RetimeHelper(line_runtime).syl()

    RetimeHelper(syl_runtime).syl()
    with pytest.raises(PykaraValidationError, match=r"only be called once"):
        RetimeHelper(syl_runtime).syl()

    mixed_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])
    RetimeHelper(mixed_runtime).line()
    with pytest.raises(PykaraValidationError, match=r"mutually exclusive"):
        RetimeHelper(mixed_runtime).syl()


def test_retime_line_ltr_distributes_offsets_across_line_chars() -> None:
    """Line-family presets should distribute one target by line-wide char order."""
    first_runtime = _char_runtime(0, 0)
    middle_runtime = _char_runtime(0, 1)
    last_runtime = _char_runtime(0, 3)
    assert first_runtime.line is not None
    line_duration = first_runtime.line.duration

    RetimeHelper(first_runtime).line.ltr(-300, 0)
    RetimeHelper(middle_runtime).line.ltr(-300, 0)
    RetimeHelper(last_runtime).line.ltr(-300, 0)

    assert first_runtime.output_interval() == (-300, line_duration - 300)
    assert middle_runtime.output_interval() == (-200, line_duration - 200)
    assert last_runtime.output_interval() == (0, line_duration)


@pytest.mark.parametrize(
    ("preset_name", "expected_offset"),
    [
        ("ltr", -200),
        ("rtl", -100),
        ("from_center", -200),
        ("from_edges", -100),
        ("odd_first", 0),
        ("even_first", -300),
    ],
)
def test_retime_textual_presets_follow_the_spec_formula(
    preset_name: str,
    expected_offset: int,
) -> None:
    """Textual presets should project their factors into the offset window."""
    runtime = _char_runtime(0, 1)
    assert runtime.line is not None

    getattr(RetimeHelper(runtime).line, preset_name)(-300, 0)

    assert runtime.output_interval() == (
        expected_offset,
        runtime.line.duration + expected_offset,
    )


def test_retime_syl_ltr_uses_syllable_chars_not_line_chars() -> None:
    """Syllable-family presets in char scope should iterate over ``syl.chars``."""
    first_char_runtime = _char_runtime(0, 0)
    second_char_runtime = _char_runtime(0, 1)
    assert first_char_runtime.syl is not None
    assert second_char_runtime.syl is not None

    RetimeHelper(first_char_runtime).syl.ltr(-100, 0)
    RetimeHelper(second_char_runtime).syl.ltr(-100, 0)

    assert first_char_runtime.output_interval() == (
        first_char_runtime.syl.start_time - 100,
        first_char_runtime.syl.end_time,
    )
    assert second_char_runtime.output_interval() == (
        second_char_runtime.syl.end_time - second_char_runtime.syl.duration,
        second_char_runtime.syl.end_time,
    )


def test_retime_line_ltr_uses_line_words_in_word_scope() -> None:
    """Word-scope line presets should iterate over ``line.words``."""
    runtime = _word_runtime(1)
    assert runtime.line is not None

    RetimeHelper(runtime).line.ltr(-90, 0)

    assert runtime.output_interval() == (-45, runtime.line.duration - 45)


def test_retime_line_ltr_uses_line_syllables_in_syl_scope() -> None:
    """Syllable-scope line presets should iterate over ``line.syls``."""
    runtime = _syl_runtime(1)
    assert runtime.line is not None

    RetimeHelper(runtime).line.ltr(-90, 0)

    assert runtime.output_interval() == (-45, runtime.line.duration)


def test_retime_start2syl_and_syl2end_use_line_syllables_in_syl_scope() -> None:
    """Syllable-anchored line presets should still iterate over ``line.syls``."""
    start_runtime = _syl_runtime(1)
    end_runtime = _syl_runtime(1)

    RetimeHelper(start_runtime).start2syl.ltr(-90, 0)
    RetimeHelper(end_runtime).syl2end.ltr(-90, 0)

    assert start_runtime.output_interval() == (-45, 100)
    assert end_runtime.output_interval() == (110, 555)


def test_retime_start2syl_and_syl2end_use_line_syllables_in_char_scope() -> None:
    """Char-scope syllable-anchored presets should distribute by ``line.syls``."""
    start_runtime = _char_runtime(0, 2)
    end_runtime = _char_runtime(0, 2)

    RetimeHelper(start_runtime).start2syl.ltr(-90, 0)
    RetimeHelper(end_runtime).syl2end.ltr(-90, 0)

    assert start_runtime.output_interval() == (0, 100)
    assert end_runtime.output_interval() == (210, 600)


def test_retime_spatial_preset_uses_visual_positions() -> None:
    """Spatial presets should follow horizontal positions, not textual order."""
    runtime = _char_runtime(0, 1)
    assert runtime.line is not None
    for char, x in zip(runtime.line.chars, [100, 300, 200, 150], strict=True):
        char.abs_center = x

    RetimeHelper(runtime).line.spatial_ltr(-90, 0)

    assert runtime.output_interval() == (0, runtime.line.duration)


def test_retime_spatial_rtl_inverts_the_visual_order() -> None:
    """The RTL spatial preset should invert the normalized horizontal position."""
    runtime = _char_runtime(0, 1)
    assert runtime.line is not None
    for char, x in zip(runtime.line.chars, [100, 300, 200, 150], strict=True):
        char.abs_center = x

    RetimeHelper(runtime).line.spatial_rtl(-90, 0)

    assert runtime.output_interval() == (-90, runtime.line.duration - 90)


def test_retime_spatial_presets_require_distinct_horizontal_positions() -> None:
    """Spatial presets should fail when every item shares the same X position."""
    runtime = _char_runtime(0, 1)
    assert runtime.line is not None
    for char in runtime.line.chars:
        char.abs_center = 123

    with pytest.raises(PykaraValidationError, match=r"distinct horizontal positions"):
        RetimeHelper(runtime).line.spatial_ltr(-90, 0)


def test_retime_random_preset_is_deterministic_for_the_same_item() -> None:
    """Random preset should be deterministic for one collection index."""
    first = _char_runtime(0, 2)
    second = _char_runtime(0, 2)

    RetimeHelper(first).line.random(-120, 0)
    RetimeHelper(second).line.random(-120, 0)

    assert first.output_interval() == second.output_interval()


@pytest.mark.parametrize(
    ("scope", "target_name", "is_valid"),
    [
        (Scope.LINE, "line", False),
        (Scope.LINE, "preline", False),
        (Scope.LINE, "postline", False),
        (Scope.LINE, "syl", False),
        (Scope.LINE, "presyl", False),
        (Scope.LINE, "postsyl", False),
        (Scope.LINE, "start2syl", False),
        (Scope.LINE, "syl2end", False),
        (Scope.WORD, "line", True),
        (Scope.WORD, "preline", True),
        (Scope.WORD, "postline", True),
        (Scope.WORD, "syl", False),
        (Scope.WORD, "presyl", False),
        (Scope.WORD, "postsyl", False),
        (Scope.WORD, "start2syl", False),
        (Scope.WORD, "syl2end", False),
        (Scope.SYL, "line", True),
        (Scope.SYL, "preline", True),
        (Scope.SYL, "postline", True),
        (Scope.SYL, "syl", False),
        (Scope.SYL, "presyl", False),
        (Scope.SYL, "postsyl", False),
        (Scope.SYL, "start2syl", True),
        (Scope.SYL, "syl2end", True),
        (Scope.CHAR, "line", True),
        (Scope.CHAR, "preline", True),
        (Scope.CHAR, "postline", True),
        (Scope.CHAR, "syl", True),
        (Scope.CHAR, "presyl", True),
        (Scope.CHAR, "postsyl", True),
        (Scope.CHAR, "start2syl", True),
        (Scope.CHAR, "syl2end", True),
    ],
)
def test_retime_preset_matrix_matches_the_spec(
    scope: Scope,
    target_name: str,
    is_valid: bool,
) -> None:
    """Every scope-target pair should match the current preset validity matrix."""
    runtime = _matrix_runtime(scope)
    target = getattr(RetimeHelper(runtime), target_name)

    if is_valid:
        assert target.ltr(-90, 0) == ""
        return

    with pytest.raises(
        PykaraValidationError,
        match=(
            r"(invalid in template line|only valid in template char|"
            r"only valid in template syl and char|requires line and syl runtime)"
        ),
    ):
        target.ltr(-90, 0)


def test_retime_preset_rejects_degenerate_collections() -> None:
    """Preset calls require collections with at least two elements."""
    line = parse_karaoke_line(r"{\k10}a{\k20}bc")
    char = line.chars[0]
    runtime = ExecutionRuntime(
        scope=Scope.CHAR,
        line=line,
        word=char.word,
        syl=char.syl,
        char=char,
    )

    with pytest.raises(PykaraValidationError, match=r"requires at least 2 elements"):
        RetimeHelper(runtime).syl.ltr(-100, 0)


def test_retime_random_preset_matches_the_spec_formula() -> None:
    """Random preset should use the deterministic sine-based factor from the spec."""
    runtime = _char_runtime(0, 2)
    assert runtime.line is not None
    expected_offset = round(-120 * (1.0 - abs(sin(3 * 127.1 + 311.7))))

    RetimeHelper(runtime).line.random(-120, 0)

    assert runtime.output_interval() == (
        expected_offset,
        runtime.line.duration + expected_offset,
    )


def test_retime_preset_and_base_calls_share_global_exclusivity() -> None:
    """Preset and non-preset retime calls should share the same exclusivity slot."""
    same_target_runtime = _char_runtime(0, 1)
    different_target_runtime = _char_runtime(0, 1)

    RetimeHelper(same_target_runtime).line.ltr(-90, 0)
    with pytest.raises(PykaraValidationError, match=r"only be called once"):
        RetimeHelper(same_target_runtime).line()

    RetimeHelper(different_target_runtime).line()
    with pytest.raises(PykaraValidationError, match=r"mutually exclusive"):
        RetimeHelper(different_target_runtime).syl.ltr(-90, 0)


def test_retime_unknown_preset_names_stay_reserved_until_implemented() -> None:
    """Unsupported preset names should keep the chain reserved explicitly."""
    runtime = _char_runtime(0, 0)
    with pytest.raises(PykaraNotImplementedError, match=r"not implemented yet"):
        RetimeHelper(runtime).line.future_preset(-300, 0)


def test_retime_rejects_invalid_offset_signatures() -> None:
    """Retime calls should reject unsupported argument shapes."""
    runtime = _char_runtime(0, 0)

    with pytest.raises(
        PykaraTypeError,
        match=r"accepts \(\) or \(start_offset, end_offset\)",
    ):
        RetimeHelper(runtime).line(1)

    with pytest.raises(
        PykaraTypeError,
        match=r"accepts \(\) or \(start_offset, end_offset\)",
    ):
        RetimeHelper(runtime).line.ltr("bad", 0)


def test_retime_line_preset_requires_line_runtime() -> None:
    """Line-family presets should reject runtimes that lack an active line."""
    runtime = ExecutionRuntime(scope=Scope.SETUP)

    with pytest.raises(PykaraValidationError, match=r"requires line runtime"):
        RetimeHelper(runtime).line.ltr(-90, 0)


def test_retime_rejects_current_items_outside_the_resolved_collection() -> None:
    """Preset execution should fail if the current item is outside its collection."""
    line = parse_karaoke_line(r"{\k10}ab{\k10}cd")
    foreign_line = parse_karaoke_line(r"{\k10}xy{\k10}zz")
    foreign_char = foreign_line.chars[0]
    runtime = ExecutionRuntime(
        scope=Scope.CHAR,
        line=line,
        word=foreign_char.word,
        syl=foreign_char.syl,
        char=foreign_char,
    )

    with pytest.raises(
        PykaraValidationError,
        match=r"could not locate the current item in its collection",
    ):
        RetimeHelper(runtime).line.ltr(-90, 0)


def test_retime_rejects_keyword_arguments_until_parameter_syntax_exists() -> None:
    """Preset keyword arguments should stay blocked until the spec defines them."""
    runtime = _char_runtime(0, 0)

    with pytest.raises(
        PykaraNotImplementedError,
        match=r"keyword parameters are not implemented yet",
    ):
        RetimeHelper(runtime).line.ltr(start_offset=-90, end_offset=0)


def test_retime_target_dunder_attrs_raise_attribute_error() -> None:
    """Special attribute lookups should not be interpreted as preset names."""
    runtime = _char_runtime(0, 0)

    with pytest.raises(PykaraAttributeError, match=r"__wrapped__"):
        _ = RetimeHelper(runtime).line.__wrapped__
