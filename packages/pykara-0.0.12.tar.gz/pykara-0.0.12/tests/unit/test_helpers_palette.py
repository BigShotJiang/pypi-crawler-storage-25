"""Tests for the palette color helper."""

from __future__ import annotations

import pytest

from pykara.exceptions import (
    PykaraAttributeError,
    PykaraTypeError,
    PykaraValidationError,
)
from pykara.helpers.palette import PaletteHelper


def test_palette_returns_ass_colors() -> None:
    """Palette shades should resolve to ASS colors."""
    palette = PaletteHelper()

    assert palette.red[100] == "&HE2E2FE&"
    assert palette.blue[500] == "&HF6823B&"
    assert palette.pink[300] == "&HD4A8F9&"


def test_palette_requires_an_explicit_shade() -> None:
    """One color family alone should not stringify without a shade."""
    palette = PaletteHelper()

    with pytest.raises(
        PykaraValidationError,
        match=r"palette\.pink requires a shade index",
    ):
        str(palette.pink)


def test_palette_rejects_invalid_shades() -> None:
    """Unknown shade indexes should raise a helpful error."""
    palette = PaletteHelper()

    with pytest.raises(PykaraValidationError, match=r"available shades: 50, 100, 200"):
        palette.red[42]


def test_palette_rejects_non_integer_shades() -> None:
    """Shade lookups must use integer indexes."""
    palette = PaletteHelper()

    with pytest.raises(PykaraTypeError, match=r"requires an integer shade index"):
        palette.red["500"]  # type: ignore[index]


def test_palette_rejects_unknown_colors() -> None:
    """Unknown color families should behave like missing attributes."""
    palette = PaletteHelper()

    with pytest.raises(PykaraAttributeError):
        palette.__getattr__("magenta")


def test_palette_exposes_debug_and_discovery_helpers() -> None:
    """Palette helpers should support discovery and debug-friendly reprs."""
    palette = PaletteHelper()

    assert repr(palette.pink) == "<palette color family pink>"
    assert "pink" in dir(palette)

    with pytest.raises(
        PykaraValidationError,
        match=r"palette\.pink requires a shade index",
    ):
        format(palette.pink)

    with pytest.raises(PykaraAttributeError):
        _ = palette.__pykara_missing__
