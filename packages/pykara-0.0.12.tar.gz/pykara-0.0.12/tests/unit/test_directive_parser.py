"""Tests for directive parsing."""

from __future__ import annotations

import itertools
from collections.abc import Iterable

import pytest

from pykara.directive.parser import parse_directive
from pykara.directive.types import (
    CodeDirective,
    Expression,
    ForMod,
    InlineFxMod,
    LayerMod,
    MultiMod,
    NoblankMod,
    NotextMod,
    PatchDirective,
    PrependMod,
    RepeatMod,
    Scope,
    TemplateDirective,
    Token,
    UnlessMod,
    WhenMod,
)
from pykara.directive.validator import validate_directive
from pykara.exceptions import PykaraValidationError

_CONDITION_VARIANTS: list[list[str]] = [
    [],
    ["when", "enabled"],
    ["when", "(syl.duration > 200)"],
    ["unless", "enabled"],
    ["unless", "(func(\"(a)\") and nested((1 + 2), 'x)'))"],
]


def _cartesian_variants(*groups: list[list[str]]) -> list[list[str]]:
    """Return the cartesian product of modifier variant groups."""
    return [
        [token for fragment in combo for token in fragment]
        for combo in itertools.product(*groups)
    ]


def _inline_fx_variants(scope: Scope) -> list[list[str]]:
    """Return inline_fx variants for scopes that support it."""
    return [[], ["inline_fx", "glow"]] if scope in {Scope.SYL, Scope.CHAR} else [[]]


def _template_effects() -> Iterable[str]:
    """Generate all legal template directives from the spec matrix."""
    repeat_variants: list[list[str]] = [
        [],
        ["repeat", "2"],
        ["repeat", "outer", "2"],
        ["repeat", "outer", "2", "repeat", "inner", "3"],
    ]
    for scope in (Scope.LINE, Scope.WORD, Scope.SYL, Scope.CHAR):
        multi_variants: list[list[str]] = (
            [[], ["multi"]] if scope is Scope.SYL else [[]]
        )
        for modifiers in _cartesian_variants(
            [[], ["no_blank"]],
            [[], ["no_text"]],
            multi_variants,
            repeat_variants,
            _inline_fx_variants(scope),
            _CONDITION_VARIANTS,
        ):
            yield " ".join(["template", scope.value, *modifiers])


def _patch_effects() -> Iterable[str]:
    """Generate all legal patch directives from the spec matrix."""
    for scope in (Scope.LINE, Scope.WORD, Scope.SYL, Scope.CHAR):
        for modifiers in _cartesian_variants(
            [[], ["no_blank"]],
            _inline_fx_variants(scope),
            [[], ["prepend"]],
            [[], ["layer", "2"]],
            [[], ["for", "high-light"]],
            _CONDITION_VARIANTS,
        ):
            yield " ".join(["patch", scope.value, *modifiers])


@pytest.mark.parametrize("effect", list(_template_effects()))
def test_parse_all_legal_template_combinations(effect: str) -> None:
    """All legal template combinations from the spec should parse and validate."""
    directive = parse_directive(effect)

    assert isinstance(directive, TemplateDirective)
    validate_directive(directive)


@pytest.mark.parametrize("effect", list(_patch_effects()))
def test_parse_all_legal_patch_combinations(effect: str) -> None:
    """All legal patch combinations from the spec should parse and validate."""
    directive = parse_directive(effect)

    assert isinstance(directive, PatchDirective)
    validate_directive(directive)


def test_parse_template_with_all_legal_modifiers() -> None:
    """The parser should decode modifiers in spec order."""
    directive = parse_directive(
        "template syl no_blank no_text multi repeat 3 inline_fx glow when is_active"
    )

    assert directive == TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            NoblankMod(),
            NotextMod(),
            MultiMod(),
            RepeatMod(name=None, count=3),
            InlineFxMod(name="glow"),
            WhenMod(condition=Token(name="is_active")),
        ],
    )


def test_parse_repeat_named_and_multiple_forms() -> None:
    """Repeat should support optional names and multiple declarations."""
    directive = parse_directive("template syl repeat outer 2 repeat inner 3")

    assert directive == TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            RepeatMod(name="outer", count=2),
            RepeatMod(name="inner", count=3),
        ],
    )


def test_parse_repeat_named_form_rejects_non_numeric_count() -> None:
    """Named repeats still require a numeric count token."""
    with pytest.raises(PykaraValidationError, match="Invalid repeat count: 'nope'"):
        parse_directive("template syl repeat outer nope")


def test_parse_when_and_unless_condition_forms() -> None:
    """Both token and expression conditions should parse."""
    when_directive = parse_directive("template syl when is_active")
    unless_directive = parse_directive("template syl unless (syl.duration > 200)")

    assert when_directive == TemplateDirective(
        scope=Scope.SYL,
        modifiers=[WhenMod(condition=Token(name="is_active"))],
    )
    assert unless_directive == TemplateDirective(
        scope=Scope.SYL,
        modifiers=[UnlessMod(condition=Expression(code="syl.duration > 200"))],
    )


def test_parse_patch_with_all_legal_modifiers() -> None:
    """Patch parser should decode all supported modifiers in order."""
    directive = parse_directive(
        "patch char no_blank inline_fx glow prepend layer 3 for high-light "
        "unless active"
    )

    assert directive == PatchDirective(
        scope=Scope.CHAR,
        modifiers=[
            NoblankMod(),
            InlineFxMod(name="glow"),
            PrependMod(),
            LayerMod(layer=3),
            ForMod(name="high-light"),
            UnlessMod(condition=Token(name="active")),
        ],
    )


def test_parse_condition_expression_handles_nested_parentheses_and_quotes() -> None:
    """Nested parentheses and quoted strings should remain intact."""
    directive = parse_directive(
        "template syl when (func(\"(a)\") and nested((1 + 2), 'x)'))"
    )

    assert directive == TemplateDirective(
        scope=Scope.SYL,
        modifiers=[
            WhenMod(
                condition=Expression(
                    code="func(\"(a)\") and nested((1 + 2), 'x)')"
                )
            )
        ],
    )


def test_parse_code_directives() -> None:
    """Code setup and scoped code directives should parse normally."""
    assert parse_directive("code setup") == CodeDirective(scope=Scope.SETUP)
    assert parse_directive("code line") == CodeDirective(scope=Scope.LINE)
    assert parse_directive("patch line") == PatchDirective(scope=Scope.LINE)


def test_parse_rejects_legacy_code_once_scope() -> None:
    """Legacy ``code once`` should now fail as an invalid scope."""
    with pytest.raises(PykaraValidationError, match=r"Invalid scope: 'once'"):
        parse_directive("code once")


def test_parse_unknown_or_blank_effect_returns_none() -> None:
    """Blank or unrelated effects should not parse as directives."""
    assert parse_directive("") is None
    assert parse_directive("karaoke") is None


def test_parse_rejects_when_and_unless_together() -> None:
    """A single directive cannot contain both when and unless."""
    with pytest.raises(PykaraValidationError, match="Invalid condition token"):
        parse_directive("template syl when foo unless bar")
