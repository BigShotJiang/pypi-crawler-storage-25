"""Tests for the karaoke line wrapper."""

from tests.support import parse_karaoke_line


def test_parse_karaoke_builds_line_metadata() -> None:
    """The top-level karaoke line should mirror dialogue timing metadata."""
    line = parse_karaoke_line(
        r"{\k10}he{\k15}llo",
        style="Default",
        actor="Singer",
        start_time=1_000,
        end_time=2_500,
    )

    assert line.start_time == 1_000
    assert line.end_time == 2_500
    assert line.duration == 1_500
    assert line.style is None
    assert line.actor == "Singer"
