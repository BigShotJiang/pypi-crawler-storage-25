"""Tests for syllable parsing details."""

from tests.support import parse_karaoke_line


def test_parse_karaoke_assigns_syllable_indices() -> None:
    """Syllables should receive stable ``si`` and ``ci`` indices."""
    line = parse_karaoke_line(
        r"{\k10}ab{\k20}c",
        style="Default",
        actor="",
        start_time=0,
        end_time=1_000,
    )

    assert [(syllable.si, syllable.ci) for syllable in line.syls] == [(1, 1), (2, 3)]
    assert [(syllable.kdur, syllable.end_time) for syllable in line.syls] == [
        (10, 100),
        (20, 300),
    ]
