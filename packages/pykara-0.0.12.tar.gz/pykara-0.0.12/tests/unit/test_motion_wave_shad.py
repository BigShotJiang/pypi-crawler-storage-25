"""Tests for the shadow-trick wave motion builder."""

from __future__ import annotations

from pykara.motion.wave.shad import build_shad_wave


def test_build_shad_wave_returns_nonempty_string() -> None:
    """Wave shad builder should return a non-empty tag string."""
    result = build_shad_wave(1000, 500, 400, 100, 900, 400)
    assert isinstance(result, str)
    assert len(result) > 0


def test_build_shad_wave_contains_t_segments() -> None:
    r"""Wave shad should emit ``\t(`` sequences."""
    result = build_shad_wave(1000, 500, 400, 100, 900, 400)
    assert r"\t(" in result


def test_build_shad_wave_segments_param_controls_t_count() -> None:
    """More segments should produce more ``\\t`` tags."""
    result_16 = build_shad_wave(1000, 500, 400, 100, 900, 400, segments=16)
    result_32 = build_shad_wave(1000, 500, 400, 100, 900, 400, segments=32)
    assert result_16.count(r"\t(") == 32
    assert result_32.count(r"\t(") == 64


def test_build_shad_wave_first_position_at_t0() -> None:
    r"""First fix-start should encode wave_xy(0) relative to anchor."""
    result = build_shad_wave(
        1000, 500, 400, 100, 900, 400, amplitude=150, frequency=2, phase=0
    )
    assert r"\t(0,0,\xshad-400\yshad0)" in result


def test_build_shad_wave_t1_t2_none_defaults_to_full_duration() -> None:
    """Omitting t1/t2 should span the full duration."""
    result_none = build_shad_wave(1000, 500, 400, 100, 900, 400)
    result_explicit = build_shad_wave(1000, 500, 400, 100, 900, 400, t1=0, t2=1000)
    assert result_none.count(r"\t(") == result_explicit.count(r"\t(")


def test_build_shad_wave_phase_shifts_y_at_start() -> None:
    """A 90-degree phase should produce max amplitude at t=0."""
    result = build_shad_wave(
        1000,
        500,
        400,
        100,
        900,
        400,
        amplitude=100,
        frequency=1,
        phase=90.0,
        segments=1,
    )
    assert r"\yshad100)" in result


def test_build_shad_wave_xshad_zero_replaced_with_minimum() -> None:
    r"""``\xshad0`` must be ``\xshad0.001`` to keep shadow active."""
    result = build_shad_wave(1000, 100, 400, 100, 900, 400, segments=32)
    assert r"\xshad0\y" not in result
