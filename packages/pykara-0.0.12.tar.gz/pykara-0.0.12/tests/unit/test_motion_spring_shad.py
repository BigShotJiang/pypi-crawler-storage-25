"""Tests for the shadow-trick spring motion builder."""

from __future__ import annotations

from pykara.motion.spring.shad import build_shad_spring


def test_build_shad_spring_returns_nonempty_string() -> None:
    """Spring shad builder should return a non-empty tag string."""
    result = build_shad_spring(1000, 500, 400, 100, 400, 800, 400)
    assert isinstance(result, str)
    assert len(result) > 0


def test_build_shad_spring_contains_t_segments() -> None:
    r"""Spring shad should emit ``\t(`` sequences."""
    result = build_shad_spring(1000, 500, 400, 100, 400, 800, 400)
    assert r"\t(" in result


def test_build_shad_spring_segments_param_controls_t_count() -> None:
    """More segments should produce more ``\\t`` tags."""
    result_24 = build_shad_spring(1000, 500, 400, 100, 400, 800, 400, segments=24)
    result_48 = build_shad_spring(1000, 500, 400, 100, 400, 800, 400, segments=48)
    assert result_24.count(r"\t(") == 48
    assert result_48.count(r"\t(") == 96


def test_build_shad_spring_first_position_at_t0() -> None:
    r"""First fix-start should encode spring_xy(0) relative to anchor."""
    result = build_shad_spring(1000, 500, 400, 100, 400, 800, 400)
    assert r"\t(0,0,\xshad-400\yshad0)" in result


def test_build_shad_spring_t1_t2_none_defaults_to_full_duration() -> None:
    """Omitting t1/t2 should span the full duration."""
    result_none = build_shad_spring(1000, 500, 400, 100, 400, 800, 400)
    result_explicit = build_shad_spring(
        1000, 500, 400, 100, 400, 800, 400, t1=0, t2=1000
    )
    assert result_none.count(r"\t(") == result_explicit.count(r"\t(")


def test_build_shad_spring_default_params() -> None:
    """Default amplitude/damping/freq should produce a valid output."""
    result = build_shad_spring(2000, 400, 300, 100, 300, 700, 300)
    assert r"\t(" in result


def test_build_shad_spring_xshad_zero_replaced_with_minimum() -> None:
    r"""``\xshad0`` must be ``\xshad0.001`` to keep shadow active."""
    result = build_shad_spring(1000, 500, 400, 500, 400, 500, 400, segments=48)
    assert r"\xshad0\y" not in result
