"""Tests for the CLI entry point."""

from __future__ import annotations

from pathlib import Path

import pytest

from pykara.ass.parser import read_ass
from pykara.ass.writer import write_ass
from pykara.cli import main


def test_cli_writes_generated_fx_lines(ass_fixtures_dir: Path, tmp_path: Path) -> None:
    """The CLI should append generated fx lines to the output ASS file."""
    input_path = ass_fixtures_dir / "cli_generated_fx_input.ass"
    output_path = tmp_path / "output.ass"

    exit_code = main([str(input_path), str(output_path)])

    assert exit_code == 0
    output_document = read_ass(output_path)
    fx_lines = [event for event in output_document.events if event.effect == "fx"]
    assert [line.text for line in fx_lines] == ["S:a", "S:b"]


def test_cli_accepts_timecodes_option(
    ass_fixtures_dir: Path, fixtures_dir: Path, tmp_path: Path
) -> None:
    """The CLI should accept a valid timecodes file."""
    input_path = ass_fixtures_dir / "cli_timecodes_input.ass"
    output_path = tmp_path / "output.ass"

    exit_code = main(
        [
            "--timecodes",
            str(fixtures_dir / "timecodes" / "crf_timecodes.txt"),
            str(input_path),
            str(output_path),
        ]
    )

    assert exit_code == 0
    assert output_path.exists()


def test_cli_ignores_dialogue_without_karaoke_effect(
    ass_fixtures_dir: Path, tmp_path: Path
) -> None:
    """Only rows marked with ``Effect: karaoke`` should generate fx."""
    input_path = ass_fixtures_dir / "cli_generated_fx_input.ass"
    output_path = tmp_path / "output.ass"

    source = read_ass(input_path)
    source.events[1].effect = ""

    muted_input = tmp_path / "input_without_karaoke_effect.ass"
    write_ass(source, muted_input)

    exit_code = main([str(muted_input), str(output_path)])

    assert exit_code == 0
    output_document = read_ass(output_path)
    fx_lines = [event for event in output_document.events if event.effect == "fx"]
    assert fx_lines == []


def test_cli_can_emit_generated_events_to_stdout(
    ass_fixtures_dir: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """The bridge mode should print only the generated ASS event rows."""
    input_path = ass_fixtures_dir / "cli_generated_fx_input.ass"

    exit_code = main(["--emit-events", str(input_path)])

    assert exit_code == 0
    captured = capsys.readouterr()
    assert captured.out.splitlines() == [
        "Dialogue: 0,0:00:01.00,0:00:01.20,Default,actor,0,0,0,fx,S:a",
        "Dialogue: 0,0:00:01.00,0:00:01.20,Default,actor,0,0,0,fx,S:b",
    ]
    assert captured.err == ""


def test_cli_requires_output_when_not_emitting_events(
    ass_fixtures_dir: Path,
) -> None:
    """The normal file-writing mode should still require an output path."""
    input_path = ass_fixtures_dir / "cli_generated_fx_input.ass"

    with pytest.raises(SystemExit, match="2"):
        main([str(input_path)])


def test_cli_error_without_debug_prints_clean_message(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    """A runtime error should produce a short stderr message and exit code 1."""
    # Pass a non-existent file so read_ass raises an exception immediately.
    bad_input = tmp_path / "does_not_exist.ass"
    output_path = tmp_path / "output.ass"

    exit_code = main([str(bad_input), str(output_path)])

    assert exit_code == 1
    captured = capsys.readouterr()
    assert "pykara: error:" in captured.err
    assert "--debug" in captured.err
    # No Python traceback noise on stderr by default.
    assert "Traceback" not in captured.err


def test_cli_error_with_debug_raises_exception(tmp_path: Path) -> None:
    """With --debug the original exception should propagate to the caller."""
    bad_input = tmp_path / "does_not_exist.ass"
    output_path = tmp_path / "output.ass"

    with pytest.raises(FileNotFoundError):
        main(["--debug", str(bad_input), str(output_path)])
