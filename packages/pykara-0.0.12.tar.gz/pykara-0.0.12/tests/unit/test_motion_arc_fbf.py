"""Tests for the frame-baked arc motion builder."""

from __future__ import annotations

from tests.support import make_motion_event

from pykara.motion.arc.fbf import arc_fbf_line
from pykara.motion.arc.request import ArcFbfRequest


def test_arc_fbf_line_returns_correct_frame_count() -> None:
    """Arc FBF should produce one frame per frame bucket."""
    line = make_motion_event(r"{\an5}X")
    result = arc_fbf_line(line, 24.0, 500, 400, 500, 400, 0, 180, 100, 100)
    assert len(result) == 24


def test_arc_fbf_line_each_frame_has_pos() -> None:
    r"""Every FBF arc frame should contain a ``\pos(`` tag."""
    line = make_motion_event(r"{\an5}X")
    result = arc_fbf_line(line, 24.0, 500, 400, 500, 400, 0, 180, 100, 100)
    assert all(r"\pos(" in frame.text for frame in result)


def test_arc_fbf_line_start_position_at_angle_zero() -> None:
    r"""First frame position should match arc_xy at t≈0."""
    line = make_motion_event(r"{\an5}X")
    result = arc_fbf_line(line, 24.0, 500, 400, 500, 400, 0, 0, 100, 100)
    assert r"\pos(600" in result[0].text
    assert ",400)" in result[0].text


def test_arc_fbf_line_timing_is_correct() -> None:
    """FBF frames should cover the full line interval."""
    line = make_motion_event(r"{\an5}X")
    result = arc_fbf_line(line, 24.0, 500, 400, 500, 400, 0, 180, 100, 100)
    assert result[0].start_time == 1000
    assert result[-1].end_time == 2000


def test_arc_fbf_line_t1_t2_none_defaults_to_full_duration() -> None:
    """Omitting t1/t2 should use the full line duration for progress."""
    line = make_motion_event(r"{\an5}X")
    result = arc_fbf_line(line, 24.0, 500, 400, 500, 400, 0, 180, 100, 100)
    assert len(result) == 24


def test_arc_fbf_request_expands_correctly() -> None:
    """ArcFbfRequest.expand() should delegate to arc_fbf_line."""
    request = ArcFbfRequest(
        x1=500, y1=400, x2=500, y2=400, a1=0, a2=180, r1=100, r2=100
    )
    result = request.expand(make_motion_event(r"{\an5}X"), 24.0)
    assert len(result) == 24
    assert all(r"\pos(" in frame.text for frame in result)
