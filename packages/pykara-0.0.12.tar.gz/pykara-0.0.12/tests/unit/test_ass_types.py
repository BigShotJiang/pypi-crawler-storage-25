"""Coverage-oriented tests for ASS dataclasses."""

from pykara.ass.types import AssDocument, RawSection, ScriptInfo


def test_ass_document_defaults_build_empty_collections() -> None:
    """Default dataclass factories should provide empty collections."""
    document = AssDocument()
    script_info = ScriptInfo()
    raw_section = RawSection(name="Extra")

    assert document.styles == []
    assert document.events == []
    assert document.other_sections == []
    assert script_info.fields == []
    assert raw_section.lines == []
