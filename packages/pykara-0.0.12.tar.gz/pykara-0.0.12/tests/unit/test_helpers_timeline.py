"""Tests for the timeline helper."""

from __future__ import annotations

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.exceptions import PykaraTypeError, PykaraValidationError
from pykara.helpers.retime import RetimeHelper
from pykara.helpers.timeline import TimelineHelper


def _timeline(runtime: ExecutionRuntime) -> TimelineHelper:
    """Bind TimelineHelper to the explicit dependencies it now consumes."""
    return TimelineHelper(line=runtime.line, output_interval=runtime.output_interval)


def test_transitions_builds_ass_transforms_from_absolute_time_windows() -> None:
    """Absolute timeline windows should become relative ASS transforms."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = _timeline(runtime).transitions(
        [
            (("0:00:01.30", 1), "&HFF0000&"),
            (("0:00:01.70", 120), "&H00FF00&"),
        ],
        [r"\1c"],
    )

    assert result == (
        r"\t(300,301,\1c&HFF0000&)"
        r"\t(700,820,\1c&H00FF00&)"
    )


def test_transitions_accepts_kara_effector_style_time_signature() -> None:
    """Numeric strings and millisecond HMS strings should be valid times."""
    line = parse_karaoke_line(start_time=0, end_time=98_000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = _timeline(runtime).transitions(
        [
            (("0", 0), "&H111111&"),
            (("0:01:35.804", 150), "&H222222&"),
            (("0:01:36.722", 150), "&H333333&"),
            (("0:01:37.389", 150), "&H444444&"),
        ],
        [r"\1c"],
    )

    assert result == (
        r"\t(0,0,\1c&H111111&)"
        r"\t(95804,95954,\1c&H222222&)"
        r"\t(96722,96872,\1c&H333333&)"
        r"\t(97389,97539,\1c&H444444&)"
    )


def test_transitions_accepts_absolute_end_time_windows() -> None:
    """One step may use absolute start/end times instead of a duration."""
    line = parse_karaoke_line(start_time=0, end_time=98_000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = _timeline(runtime).transitions(
        [
            (("0:01:35.804", "0:01:36.722"), "&H222222&"),
        ],
        [r"\1c"],
    )

    assert result == r"\t(95804,96722,\1c&H222222&)"


def test_transitions_supports_multiple_tags_with_aligned_values() -> None:
    """Multiple tags should consume one value per tag in the same step."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    result = _timeline(runtime).transitions(
        [
            (("0:00:01.30", 1), ("&HFF0000&", "&H000000&")),
        ],
        [r"\1c", r"\3c"],
    )

    assert result == r"\t(300,301,\1c&HFF0000&\3c&H000000&)"


def test_transitions_clip_to_the_current_retimed_output_interval() -> None:
    """Transitions should be clipped to the active output interval."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}cd", start_time=1000, end_time=1600)
    syllable = line.syls[1]
    runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=syllable)
    RetimeHelper(runtime).syl()

    result = _timeline(runtime).transitions(
        [
            (("0:00:01.05", "0:00:01.15"), "&HFF0000&"),
            (("0:00:01.25", "0:00:01.35"), "&H00FF00&"),
        ],
        [r"\1c"],
    )

    assert result == (
        r"\t(0,50,\1c&HFF0000&)"
        r"\t(150,200,\1c&H00FF00&)"
    )


def test_transitions_return_empty_for_empty_steps() -> None:
    """An empty transition sequence should return an empty fragment."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)

    assert _timeline(runtime).transitions([], [r"\1c"]) == ""


def test_transitions_accept_single_value_sequences_and_skip_non_overlaps() -> None:
    """Single-tag values may be wrapped, and out-of-range steps should be ignored."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    timeline = _timeline(runtime)

    assert timeline.transitions(
        [
            (("0:00:01.30", 1), ["&HFF0000&"]),
        ],
        [r"\1c"],
    ) == r"\t(300,301,\1c&HFF0000&)"

    assert timeline.transitions(
        [
            (("0:00:03.00", 100), "&H00FF00&"),
        ],
        [r"\1c"],
    ) == ""


def test_transitions_reject_invalid_inputs() -> None:
    """Validation should reject malformed tags, ranges, and values."""
    line = parse_karaoke_line(start_time=1000, end_time=2000)
    runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    timeline = _timeline(runtime)

    with pytest.raises(PykaraValidationError, match="at least one tag"):
        timeline.transitions([], [])

    with pytest.raises(PykaraTypeError, match="sequence of strings"):
        timeline.transitions([], r"\1c")  # type: ignore[arg-type]

    with pytest.raises(PykaraTypeError, match="sequence of strings"):
        timeline.transitions([], [1])  # type: ignore[list-item]

    with pytest.raises(PykaraValidationError, match="sorted ascending"):
        timeline.transitions(
            [
                (("0:00:01.70", 1), "&H00FF00&"),
                (("0:00:01.30", 1), "&HFF0000&"),
            ],
            [r"\1c"],
        )

    with pytest.raises(PykaraTypeError, match="steps must be two-item pairs"):
        timeline.transitions(["bad"], [r"\1c"])  # type: ignore[list-item]

    with pytest.raises(PykaraTypeError, match="ranges must be two-item"):
        timeline.transitions(
            [
                (("0:00:01.30", 10, 20), "&HFF0000&"),  # type: ignore[list-item]
            ],
            [r"\1c"],
        )

    with pytest.raises(
        PykaraTypeError,
        match=r"ASS timestamps, H:MM:SS\.mmm strings, or integers",
    ):
        timeline.transitions(
            [
                ((1.3, 10), "&HFF0000&"),  # type: ignore[list-item]
            ],
            [r"\1c"],
        )

    with pytest.raises(PykaraValidationError, match="end >= start"):
        timeline.transitions(
            [
                (("0:00:01.70", "0:00:01.30"), "&HFF0000&"),
            ],
            [r"\1c"],
        )

    with pytest.raises(PykaraTypeError, match="one string when one tag"):
        timeline.transitions(
            [
                (("0:00:01.30", 1), ("&HFF0000&", "&H00FF00&")),
            ],
            [r"\1c"],
        )

    with pytest.raises(PykaraTypeError, match="match the tag count"):
        timeline.transitions(
            [
                (("0:00:01.30", 1), "&HFF0000&"),
            ],
            [r"\1c", r"\3c"],
        )

    with pytest.raises(
        PykaraTypeError,
        match=r"ASS timestamps, H:MM:SS\.mmm strings, or integers",
    ):
        timeline.transitions(
            [
                (("soon", 10), "&HFF0000&"),
            ],
            [r"\1c"],
        )

    with pytest.raises(PykaraTypeError, match="match the tag count"):
        timeline.transitions(
            [
                (("0:00:01.30", 1), ("&HFF0000&",)),
            ],
            [r"\1c", r"\3c"],
        )


def test_transitions_requires_line_runtime() -> None:
    """Timeline transitions are undefined without one active line interval."""
    timeline = _timeline(ExecutionRuntime(scope=Scope.SETUP))

    with pytest.raises(PykaraValidationError, match="requires line runtime"):
        timeline.transitions([], [r"\1c"])


def test_sequence_builds_ass_transforms_from_relative_windows() -> None:
    """Relative window sequences should become ASS transforms verbatim."""
    timeline = _timeline(ExecutionRuntime(scope=Scope.SETUP))

    result = timeline.sequence(
        [
            ((12, 33), r"\3c&HFFFFFF&"),
            ((145, "245"), r"\3c&H00000000&"),
        ]
    )

    assert result == (
        r"\t(12,45,\3c&HFFFFFF&)"
        r"\t(145,245,\3c&H00000000&)"
    )


def test_sequence_supports_acceleration_and_validates_values() -> None:
    """Sequence should expose accel and reject malformed steps."""
    timeline = _timeline(ExecutionRuntime(scope=Scope.SETUP))

    assert timeline.sequence([((10, 30), r"\fr0.02")], accel=0.5) == (
        r"\t(10,40,0.5,\fr0.02)"
    )

    with pytest.raises(PykaraTypeError, match="two-item pairs"):
        timeline.sequence(["bad"])  # type: ignore[list-item]

    with pytest.raises(PykaraTypeError, match="must be strings"):
        timeline.sequence([((10, 30), 123)])  # type: ignore[list-item]


def test_pulse_cycles_values_across_one_relative_span() -> None:
    """Pulse should cycle values and clip the final transform to the span."""
    timeline = _timeline(ExecutionRuntime(scope=Scope.SETUP))

    result = timeline.pulse(
        1000,
        400,
        [r"\fr-0.02", r"\fr0.02"],
    )

    assert result == (
        r"\t(0,400,\fr-0.02)"
        r"\t(400,800,\fr0.02)"
        r"\t(800,1000,\fr-0.02)"
    )


def test_pulse_supports_explicit_ranges_and_start_index() -> None:
    """Pulse should support multiple ranges and zero-based starting indices."""
    timeline = _timeline(ExecutionRuntime(scope=Scope.SETUP))

    result = timeline.pulse(
        [(100, "500"), (700, "900")],
        (200, 50),
        [r"\1a&H00&", r"\1a&HFF&"],
        start_index=1,
    )

    assert result == (
        r"\t(100,150,\1a&HFF&)"
        r"\t(300,350,\1a&H00&)"
        r"\t(700,750,\1a&HFF&)"
    )


def test_pulse_supports_one_range_pair_and_skips_zero_length_spans() -> None:
    """Pulse should accept one explicit range and ignore empty windows."""
    timeline = _timeline(ExecutionRuntime(scope=Scope.SETUP))

    assert timeline.pulse(
        (100, "180"),
        50,
        [r"\fr0.02"],
    ) == r"\t(100,150,\fr0.02)\t(150,180,\fr0.02)"

    assert timeline.pulse(
        [(100, "100"), (200, "260")],
        40,
        [r"\fr0.02"],
    ) == r"\t(200,240,\fr0.02)\t(240,260,\fr0.02)"


def test_pulse_validates_inputs() -> None:
    """Pulse should reject malformed spans, cadence, values, and indices."""
    timeline = _timeline(ExecutionRuntime(scope=Scope.SETUP))

    with pytest.raises(PykaraTypeError, match="non-empty sequence of strings"):
        timeline.pulse(100, 20, r"\fr0.02")  # type: ignore[arg-type]

    with pytest.raises(PykaraValidationError, match="positive integer"):
        timeline.pulse(100, 0, [r"\fr0.02"])

    with pytest.raises(PykaraTypeError, match=r"\(step, duration\)"):
        timeline.pulse(100, ("20", 10), [r"\fr0.02"])  # type: ignore[arg-type]

    with pytest.raises(PykaraValidationError, match="start_index must be >= 0"):
        timeline.pulse(100, 20, [r"\fr0.02"], start_index=-1)

    with pytest.raises(PykaraTypeError, match="non-empty sequence of strings"):
        timeline.pulse(100, 20, [])  # type: ignore[arg-type]

    with pytest.raises(PykaraValidationError, match="span must be non-negative"):
        timeline.pulse(-1, 20, [r"\fr0.02"])

    with pytest.raises(PykaraValidationError, match="include at least one window"):
        timeline.pulse([], 20, [r"\fr0.02"])  # type: ignore[arg-type]

    with pytest.raises(PykaraTypeError, match="integer duration, one range pair"):
        timeline.pulse(object(), 20, [r"\fr0.02"])  # type: ignore[arg-type]

    with pytest.raises(PykaraValidationError, match="positive integer"):
        timeline.pulse(100, (20, -1), [r"\fr0.02"])
