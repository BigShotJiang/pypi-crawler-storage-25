"""Tests for full karaoke parsing."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

from pykara.ass.parser import read_ass
from pykara.karaoke.parser import parse_karaoke


def test_parse_karaoke_matches_reference_fixture(
    karaoke_reference_dir: Path,
) -> None:
    """Parsed syllable timing should match the structured reference data."""
    document = read_ass(karaoke_reference_dir / "karaoke.ass")
    expected = cast(
        list[dict[str, Any]],
        json.loads(
            (karaoke_reference_dir / "karaoke_expected.json").read_text(
                encoding="utf-8"
            )
        ),
    )

    parsed_lines = [parse_karaoke(event) for event in document.events]

    for parsed_line, expected_line in zip(parsed_lines, expected, strict=True):
        actual_syllables = [
            {
                "duration": syllable.duration,
                "start_time": syllable.start_time,
                "end_time": syllable.end_time,
                "tag": syllable.tag_type,
                "text": syllable.text,
            }
            for syllable in parsed_line.syls
        ]
        assert actual_syllables == expected_line["syllables"]


def test_parse_karaoke_tracks_override_tags_and_inline_fx(
    ass_fixtures_dir: Path,
) -> None:
    """Non-karaoke tags should be preserved and inline-fx should propagate."""
    document = read_ass(ass_fixtures_dir / "karaoke_inline_fx.ass")

    line = parse_karaoke(document.events[0])

    assert line.actor == "actor"
    assert [syllable.inline_fx for syllable in line.syls] == ["flash", "flash"]
    assert line.syls[0].override_tags == {0: r"{\bord2\-flash}"}
