"""Coverage-oriented tests for karaoke error paths and defaults."""

import pytest
from tests.support import parse_karaoke_line

from pykara.exceptions import PykaraValidationError
from pykara.karaoke.char import split_chars
from pykara.karaoke.line import Line
from pykara.karaoke.override_tags import parse_karaoke_tag, split_override_tags
from pykara.karaoke.syllable import Syllable
from pykara.karaoke.word import Word, split_words


def test_split_override_tags_ignores_text_without_tags() -> None:
    """Blocks without backslash tags should produce no entries."""
    assert split_override_tags("plain text") == []


def test_parse_karaoke_tag_handles_invalid_and_negative_values() -> None:
    """Invalid prefixes and negative values should exercise both branches."""
    assert parse_karaoke_tag("x") is None
    assert parse_karaoke_tag("k10") is None
    assert parse_karaoke_tag(r"\ko-3") == (r"\ko", -30)


def test_line_defaults_build_empty_collections() -> None:
    """Line default factories should return empty collections."""
    line = Line(start_time=0, end_time=0, duration=0, actor="")

    assert line.syls == []
    assert line.words == []
    assert line.chars == []


def test_split_words_empty_input_returns_empty_list() -> None:
    """Word splitting should handle empty syllable input."""
    assert split_words([]) == []


def test_word_defaults_build_empty_collections() -> None:
    """Word default factories should return empty collections."""
    word = Word(text="a", start_time=0, duration=0, wi=1, ci=1)

    assert word.syls == []
    assert word.chars == []


def test_split_chars_raises_when_words_missing_for_non_empty_text() -> None:
    """Character splitting should reject non-empty syllables without words."""
    syllables = [Syllable(0, 100, 100, 10, "ab", r"\k", "", si=1, ci=1)]

    with pytest.raises(
        PykaraValidationError,
        match=r"karaoke\.split_chars\(\) requires words for syllables",
    ):
        split_chars(syllables, [])


def test_parse_karaoke_handles_unclosed_override_blocks() -> None:
    """Unclosed blocks should be preserved as plain text."""
    line = parse_karaoke_line(
        r"{\k10}ab{\bord2",
        style="Default",
        actor="",
        start_time=0,
        end_time=100,
    )

    assert line.syls[0].text == r"ab{\bord2"


def test_parse_karaoke_closes_open_override_tag_group() -> None:
    """Override blocks that stay open through the end of the group should close."""
    line = parse_karaoke_line(
        r"{\bord2}ab",
        style="Default",
        actor="",
        start_time=0,
        end_time=100,
    )

    assert line.syls[0].override_tags == {0: r"{\bord2}"}
