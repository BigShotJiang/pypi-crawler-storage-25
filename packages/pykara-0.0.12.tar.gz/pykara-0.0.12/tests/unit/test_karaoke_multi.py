"""Tests for multi-highlight karaoke grouping."""

from tests.support import parse_karaoke_line


def test_parse_karaoke_collapses_hash_prefixed_multi_highlights() -> None:
    """``#``-prefixed syllables should become highlight passes of one syllable."""
    line = parse_karaoke_line(r"{\k10}ab{\k20}#cd{\k30}ef", start_time=0, end_time=600)

    assert [syllable.text for syllable in line.syls] == ["ab", "ef"]
    assert line.syls[0].duration == 300
    assert [
        (highlight.start_time, highlight.end_time, highlight.duration)
        for highlight in line.syls[0].highlights
    ] == [(0, 100, 100), (100, 300, 200)]
    assert [
        (highlight.start_time, highlight.end_time, highlight.duration)
        for highlight in line.syls[1].highlights
    ] == [(300, 600, 300)]
