"""Acceptance tests over rewritten reference fixtures."""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from pykara.ass.parser import read_ass
from pykara.ass.types import AssDocument, DialogueLine
from pykara.ass.writer import format_event_line
from pykara.engine.runner import RunOptions, run

ACCEPTANCE_FIXTURES_DIR = (
    Path(__file__).resolve().parents[1] / "fixtures" / "acceptance"
)
INVALID_ACCEPTANCE_FIXTURES_DIR = ACCEPTANCE_FIXTURES_DIR / "99_invalid"
_RETIME_PRESET_CALL = re.compile(
    r"retime\.[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*\("
)


def discover_rewritten_fixtures() -> list[Path]:
    """Return the sorted list of rewritten acceptance fixtures."""
    return sorted(
        fixture_path
        for fixture_path in ACCEPTANCE_FIXTURES_DIR.rglob("*.ass")
        if INVALID_ACCEPTANCE_FIXTURES_DIR not in fixture_path.parents
    )


def discover_invalid_fixtures() -> list[Path]:
    """Return the sorted list of intentionally invalid acceptance fixtures."""
    return sorted(INVALID_ACCEPTANCE_FIXTURES_DIR.rglob("*.ass"))


def fixture_retime_preset_details(fixture_path: Path) -> list[str]:
    """Return one detail line per forbidden retime preset call in ``fixture_path``."""
    fixture_text = fixture_path.read_text(encoding="utf-8")
    details: list[str] = []
    for match in _RETIME_PRESET_CALL.finditer(fixture_text):
        line_number = fixture_text.count("\n", 0, match.start()) + 1
        details.append(f"line {line_number}: {match.group(0)!r}")
    return details


def assert_fixture_avoids_retime_presets(fixture_path: Path) -> None:
    """Reject acceptance fixtures that use ``retime.<target>.<preset>(...)``."""
    details = fixture_retime_preset_details(fixture_path)
    if not details:
        return

    pytest.fail(
        f"{fixture_path.name} uses forbidden retime preset syntax:\n"
        + "\n".join(details)
    )


def split_fixture(
    document: AssDocument,
) -> tuple[AssDocument, list[DialogueLine]]:
    """Split one fixture into executable inputs and embedded expected fx lines."""
    input_events: list[DialogueLine] = []
    expected_events: list[DialogueLine] = []

    for event in document.events:
        if event.effect == "fx":
            expected_events.append(event)
        else:
            input_events.append(event)

    input_document = AssDocument(
        script_info=document.script_info,
        styles=list(document.styles),
        events=input_events,
        other_sections=list(document.other_sections),
        section_order=list(document.section_order),
        style_format=list(document.style_format),
        event_format=list(document.event_format),
    )
    return input_document, expected_events


def _event_signature(event: DialogueLine) -> tuple[object, ...]:
    """Return the stable comparison tuple for one event."""
    return (
        event.event_type.value,
        event.layer,
        event.start_time,
        event.end_time,
        event.style,
        event.name,
        event.margin_l,
        event.margin_r,
        event.margin_v,
        event.effect,
        event.text,
    )


def assert_fx_lines_match(
    actual: list[DialogueLine],
    expected: list[DialogueLine],
) -> None:
    """Assert that the generated fx lines match the fixture output exactly."""
    actual_signatures = [_event_signature(event) for event in actual]
    expected_signatures = [_event_signature(event) for event in expected]
    assert actual_signatures == expected_signatures


def assert_fx_lines_match_at_ass_precision(
    actual: list[DialogueLine],
    expected: list[DialogueLine],
    event_format: list[str],
) -> None:
    """Assert that generated lines match once ASS centisecond rounding is applied."""
    actual_lines = [format_event_line(event, event_format) for event in actual]
    expected_lines = [format_event_line(event, event_format) for event in expected]
    assert actual_lines == expected_lines


@pytest.mark.parametrize(
    "fixture_path",
    discover_rewritten_fixtures(),
    ids=lambda path: str(path.relative_to(ACCEPTANCE_FIXTURES_DIR).with_suffix("")),
)
def test_fixture(fixture_path: Path) -> None:
    """Each fixture must reproduce the current embedded fx output in the same .ass."""
    assert_fixture_avoids_retime_presets(fixture_path)
    document = read_ass(fixture_path)
    inputs, expected = split_fixture(document)
    actual = run(inputs, RunOptions(seed=42))
    assert expected, f"{fixture_path.name} does not define embedded fx lines"
    assert_fx_lines_match(actual, expected)


@pytest.mark.parametrize(
    "fixture_path",
    discover_invalid_fixtures(),
    ids=lambda path: str(path.relative_to(ACCEPTANCE_FIXTURES_DIR).with_suffix("")),
)
def test_invalid_fixture_retime_presets_are_rejected(fixture_path: Path) -> None:
    """Invalid fixtures should fail the syntax guard and preserve embedded fx."""
    details = fixture_retime_preset_details(fixture_path)

    assert details, f"{fixture_path.name} does not contain any forbidden preset call"
    with pytest.raises(
        pytest.fail.Exception,
        match="uses forbidden retime preset syntax",
    ):
        assert_fixture_avoids_retime_presets(fixture_path)

    document = read_ass(fixture_path)
    inputs, expected = split_fixture(document)
    actual = run(inputs, RunOptions(seed=42))
    assert expected, f"{fixture_path.name} does not define embedded fx lines"
    assert_fx_lines_match_at_ass_precision(actual, expected, document.event_format)
