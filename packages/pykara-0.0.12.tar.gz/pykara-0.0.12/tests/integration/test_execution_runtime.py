"""Integration tests for execution runtime behavior."""

from __future__ import annotations

import random
from typing import Any, cast

import pytest
from tests.support import parse_karaoke_line

from pykara.directive.types import Scope
from pykara.engine.context_builder import build_expression_context
from pykara.engine.execution_runtime import ExecutionRuntime, RepeatBinding
from pykara.engine.expression_catalog import DOCUMENTED_EXPRESSION_OBJECT_SURFACE
from pykara.engine.interpolator import interpolate
from pykara.engine.rng import RngManager
from pykara.exceptions import PykaraNameError, PykaraValidationError
from pykara.karaoke.line import Line
from pykara.layout.style import LayoutStyle
from pykara.motion.jitter.request import JitterFbfRequest


def _line(
    text: str = r"{\k10}ab{\k20}cd",
    *,
    actor: str = "actor",
) -> Line:
    """Build the default karaoke line used across the runtime tests."""
    return parse_karaoke_line(text, actor=actor)


def _char_runtime(
    line: Line,
    *,
    setup_state: dict[str, object] | None = None,
    line_state: dict[str, object] | None = None,
    word_state: dict[str, object] | None = None,
    syl_state: dict[str, object] | None = None,
    char_state: dict[str, object] | None = None,
) -> ExecutionRuntime:
    char = line.chars[0]
    return ExecutionRuntime(
        scope=Scope.CHAR,
        line=line,
        word=char.word,
        syl=char.syl,
        char=char,
        setup_state={} if setup_state is None else setup_state,
        line_state={} if line_state is None else line_state,
        word_state={} if word_state is None else word_state,
        syl_state={} if syl_state is None else syl_state,
        char_state={} if char_state is None else char_state,
    )


def _public_attrs(obj: object) -> set[str]:
    """Return the documented public attribute surface of one runtime object."""
    return {name for name in dir(obj) if not name.startswith("_")}


def test_runtime_injects_only_the_objects_allowed_by_scope() -> None:
    """Context object visibility should match the scope boundaries."""
    line = parse_karaoke_line()
    word = line.words[0]
    syllable = line.syls[0]
    char = line.chars[0]

    line_context = build_expression_context(
        ExecutionRuntime(scope=Scope.LINE, line=line)
    )
    syl_context = build_expression_context(
        ExecutionRuntime(
            scope=Scope.SYL,
            line=line,
            syl=syllable,
        )
    )
    char_context = build_expression_context(
        ExecutionRuntime(
            scope=Scope.CHAR,
            line=line,
            word=word,
            syl=syllable,
            char=char,
        )
    )

    assert "line" in line_context
    assert "syl" not in line_context
    assert "word" not in syl_context
    assert "syl" in syl_context
    assert "word" in char_context
    assert "syl" in char_context
    assert "char" in char_context


def test_setup_scope_hides_documented_non_setup_bindings() -> None:
    """Setup scope should not leak undocumented bindings even if values exist."""
    line = parse_karaoke_line()
    context = build_expression_context(
        ExecutionRuntime(
            scope=Scope.SETUP,
            line=line,
            script=object(),
        )
    )

    assert "line" not in context
    assert "state" not in context
    assert "script" not in context


def test_expression_objects_expose_the_documented_public_attribute_surface() -> None:
    """The visible runtime objects must keep a stable public attribute contract."""
    line = parse_karaoke_line()
    line.style = LayoutStyle.default()
    word = line.words[0]
    syl = line.syls[0]
    char = line.chars[0]
    char_context = build_expression_context(
        ExecutionRuntime(
            scope=Scope.CHAR,
            line=line,
            word=word,
            syl=syl,
            char=char,
        )
    )

    assert (
        _public_attrs(char_context["line"])
        == (DOCUMENTED_EXPRESSION_OBJECT_SURFACE["line"])
    )
    assert (
        _public_attrs(char_context["word"])
        == (DOCUMENTED_EXPRESSION_OBJECT_SURFACE["word"])
    )
    assert (
        _public_attrs(char_context["syl"])
        == (DOCUMENTED_EXPRESSION_OBJECT_SURFACE["syl"])
    )
    assert (
        _public_attrs(char_context["char"])
        == (DOCUMENTED_EXPRESSION_OBJECT_SURFACE["char"])
    )
    line_view = cast(Any, char_context["line"])
    assert _public_attrs(line_view.style) == (
        DOCUMENTED_EXPRESSION_OBJECT_SURFACE["style"]
    )


def test_expression_scope_rules_apply_to_bare_bindings_but_not_materialized_links(
) -> None:
    """Missing bare names should not hide linked objects already on visible objects."""
    line = _line()
    syl_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])
    context = build_expression_context(syl_runtime)

    assert "word" not in context
    assert syl_runtime.evaluate("syl.word.text") == line.words[0].text
    assert syl_runtime.evaluate("syl.word.line is line") is True
    assert syl_runtime.evaluate("line.syls[0].word.text") == line.words[0].text

    word_runtime = ExecutionRuntime(scope=Scope.WORD, line=line, word=line.words[0])
    assert "syl" not in build_expression_context(word_runtime)
    assert word_runtime.evaluate("word.syls[0].text") == line.syls[0].text


def test_expression_context_hides_internal_object_state_apis() -> None:
    """Expressions should not expose internal state helpers or object state."""
    line = _line()
    char_runtime = _char_runtime(line)

    with pytest.raises(NameError):
        char_runtime.evaluate("state")
    with pytest.raises(NameError):
        char_runtime.evaluate('state.get("flag")')
    with pytest.raises(AttributeError):
        char_runtime.evaluate("line.state")
    with pytest.raises(AttributeError):
        char_runtime.evaluate('line.set("flag", 1)')
    with pytest.raises(AttributeError):
        char_runtime.evaluate("syl.highlights")
    with pytest.raises(AttributeError):
        char_runtime.evaluate("char.highlights")
    with pytest.raises(NameError):
        char_runtime.evaluate("state._context_access")


def test_expression_proxies_expose_safe_repr_and_public_dir_behavior() -> None:
    """Expression proxies should expose stable repr/dir behavior only."""
    context = build_expression_context(_char_runtime(_line()))

    assert "state" not in context
    assert repr(context["line"]) == "<expression-proxy Line>"


def test_expression_context_exposes_scale_helper() -> None:
    """Expressions should be able to use the fluent scale helper."""
    line = _line()
    char_runtime = _char_runtime(line)

    assert char_runtime.evaluate("scale.of(2).base(100).to(150)") == 3
    assert char_runtime.evaluate("scale.of(2).value") == 2


def test_expression_context_exposes_palette() -> None:
    """Expressions should be able to resolve palette colors by shade."""
    line = _line()
    char_runtime = _char_runtime(line)

    assert char_runtime.evaluate("palette.red[100]") == "&HE2E2FE&"
    assert char_runtime.evaluate("palette.blue[500]") == "&HF6823B&"


def test_expression_context_formats_style_colors_for_tag_usage() -> None:
    """Style colors should be formatted for expression/tag usage."""
    line = _line()
    line.style = LayoutStyle.default()
    char_runtime = _char_runtime(line)

    assert line.style is not None
    assert line.style.primary_color == "&H00FFFFFF"
    assert line.style.outline_color == "&H00000000"
    assert char_runtime.evaluate("line.style.primary_color") == "&HFFFFFF&"
    assert char_runtime.evaluate("line.style.outline_color") == "&H000000&"


def test_interpolation_rejects_palette_color_without_shade() -> None:
    """Interpolating one palette family without a shade should fail clearly."""
    line = _line()
    char_runtime = _char_runtime(line)

    with pytest.raises(
        PykaraValidationError,
        match=r"palette\.pink requires a shade index",
    ):
        interpolate("!palette.pink!", char_runtime)


def test_runtime_combines_visible_scope_states() -> None:
    """Visible scope vars should follow the documented hierarchy."""
    line = _line()
    char = line.chars[0]

    runtime = ExecutionRuntime(
        scope=Scope.CHAR,
        line=line,
        word=char.word,
        syl=char.syl,
        char=char,
        setup_state={"setup_flag": True},
        line_state={"line_flag": 1},
        word_state={"word_flag": 2},
        syl_state={"syl_flag": 3},
        char_state={"char_flag": 4},
    )
    context = build_expression_context(runtime)

    assert context["setup_flag"] is True
    assert context["line_flag"] == 1
    assert context["word_flag"] == 2
    assert context["syl_flag"] == 3
    assert context["char_flag"] == 4


def test_current_text_uses_scope_specific_text_and_line_fallbacks() -> None:
    """current_text should follow char, word, syl, line, and empty-runtime order."""
    line = _line()
    word_runtime = ExecutionRuntime(scope=Scope.WORD, line=line, word=line.words[0])
    syl_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[1])

    assert word_runtime.current_text() == line.words[0].text
    assert syl_runtime.current_text() == "cd"
    assert _char_runtime(line).current_text() == "a"

    line_only_runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    assert line_only_runtime.current_text() == "abcd"

    chars_only_line = _line()
    chars_only_line.syls.clear()
    chars_only_runtime = ExecutionRuntime(scope=Scope.LINE, line=chars_only_line)
    assert chars_only_runtime.current_text() == "abcd"

    empty_line = _line()
    empty_line.syls.clear()
    empty_line.chars.clear()
    assert ExecutionRuntime(scope=Scope.LINE, line=empty_line).current_text() == ""
    assert ExecutionRuntime(scope=Scope.SETUP).current_text() == ""


def test_condition_helpers_cover_edge_cases() -> None:
    """Condition evaluation should cover empty and error paths."""
    line = _line()
    word_runtime = ExecutionRuntime(scope=Scope.WORD, line=line, word=line.words[0])

    assert word_runtime.evaluate(f"word.text == {line.words[0].text!r}") is True

    from pykara.engine.loop import evaluate_token
    with pytest.raises(PykaraNameError, match="Unknown condition token"):
        evaluate_token(word_runtime, "missing_flag")


def test_imported_random_is_seeded_without_leaking_global_module_state() -> None:
    """Imported ``random`` should use the runtime seed and restore module state."""
    line = _line()
    first = ExecutionRuntime(
        scope=Scope.LINE, line=line, rng_manager=RngManager(seed=42)
    )
    second = ExecutionRuntime(
        scope=Scope.LINE, line=line, rng_manager=RngManager(seed=42)
    )

    random.seed(999)
    previous_state = random.getstate()
    try:
        first.run_code("import random\nsample = random.randint(0, 255)")
        second.run_code("import random\nsample = random.randint(0, 255)")

        assert first.line_state["sample"] == second.line_state["sample"]
        assert random.getstate() == previous_state
    finally:
        random.setstate(previous_state)


def test_resolve_variable_covers_unknown_and_unavailable_cases() -> None:
    """Variable resolution should fail clearly for bad names and bad objects."""
    line = _line()
    syl_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])

    with pytest.raises(
        PykaraValidationError,
        match=r"Unknown variable: \$line_unknown",
    ):
        syl_runtime.resolve_variable("line_unknown")

    unavailable_runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=cast(Any, object()),
    )
    with pytest.raises(PykaraValidationError, match=r"unavailable in this phase"):
        unavailable_runtime.resolve_variable("syl_start")


def test_copy_for_highlight_requires_syllable_runtime() -> None:
    """Highlight copies should reject runtimes without an active syllable."""
    highlight = _line().syls[0].highlights[0]

    with pytest.raises(PykaraValidationError, match="require syllable runtime"):
        ExecutionRuntime(scope=Scope.LINE).copy_for_highlight(highlight)


def test_runtime_queue_and_repeat_variable_edge_cases() -> None:
    """Queue handling and repeat variables should fail clearly on bad access."""
    line = _line()
    queue_runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    request = JitterFbfRequest(640, 360, 1, 1, 0, 1, 100, 7)
    queue_runtime.queue_fbf_request(request)

    with pytest.raises(
        PykaraValidationError,
        match="Only one frame-baked motion request",
    ):
        queue_runtime.queue_fbf_request(request)

    assert queue_runtime.consume_fbf_request() == request
    assert queue_runtime.consume_fbf_request() is None

    repeat_runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=line.syls[0],
        repeat_loops=(RepeatBinding(name="outer", index=2, count=4),),
    )

    assert repeat_runtime.repeat_binding("inner") is None

    with pytest.raises(PykaraValidationError, match=r"Unknown variable: \$repeat_"):
        repeat_runtime.resolve_variable("repeat_")

    with pytest.raises(PykaraValidationError, match=r"Unknown variable: \$repeat__i"):
        repeat_runtime.resolve_variable("repeat__i")

    with pytest.raises(
        PykaraValidationError,
        match=r"Unknown variable: \$repeat_inner_i",
    ):
        repeat_runtime.resolve_variable("repeat_inner_i")


def test_retime_helpers_cover_default_and_error_paths() -> None:
    """Retime helpers should reject invalid usage and expose default intervals."""
    line = _line()

    assert ExecutionRuntime(scope=Scope.SETUP).output_interval() == (0, 0)

    with pytest.raises(PykaraValidationError, match="requires line runtime"):
        ExecutionRuntime(scope=Scope.SETUP).apply_retime_target("line", 0, 0)

    line_runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    with pytest.raises(PykaraValidationError, match=r"Unknown retime target: 'bogus'"):
        line_runtime.apply_retime_target(cast(Any, "bogus"), 0, 0)

    line_runtime.apply_retime_target("preline", -5, 10)
    assert line_runtime.output_interval() == (-5, 10)
    with pytest.raises(PykaraValidationError, match="mutually exclusive"):
        line_runtime.apply_retime_target("postline", 0, 0)

    with pytest.raises(PykaraValidationError, match="requires line and syl runtime"):
        ExecutionRuntime(scope=Scope.SYL, line=line).apply_retime_target("syl", 0, 0)

    syl_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])
    syl_runtime.apply_retime_target("syl", -1, 2)
    assert syl_runtime.output_interval() == (-1, 102)
    with pytest.raises(PykaraValidationError, match="mutually exclusive"):
        syl_runtime.apply_retime_target("line", 0, 0)
    with pytest.raises(PykaraValidationError, match="only be called once"):
        syl_runtime.apply_retime_target("syl", 0, 0)

    post_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=line.syls[0])
    post_runtime.apply_retime_target("postsyl", 3, 4)
    assert post_runtime.output_interval() == (103, 104)

    with pytest.raises(
        PykaraValidationError,
        match=r"Variable \$line_li is out of scope",
    ):
        ExecutionRuntime(scope=Scope.SETUP).resolve_variable("line_li")

    with pytest.raises(
        PykaraValidationError,
        match=r"Variable \$word_wi is out of scope",
    ):
        ExecutionRuntime(
            scope=Scope.CHAR,
            line=line,
            syl=line.syls[0],
            char=line.chars[0],
        ).resolve_variable("word_wi")


def test_runtime_state_visibility_matches_the_documented_scope_hierarchy() -> None:
    """Scope state visibility should match the documented scope hierarchy."""
    line = _line()
    setup_state: dict[str, object] = {"setup_only": "setup", "shared": "setup"}
    line_state: dict[str, object] = {"line_only": "line", "shared": "line"}
    word_state: dict[str, object] = {"word_only": "word", "shared": "word"}
    syl_state: dict[str, object] = {"syl_only": "syl", "shared": "syl"}
    char_state: dict[str, object] = {"char_only": "char", "shared": "char"}

    line_context = build_expression_context(
        ExecutionRuntime(
            scope=Scope.LINE,
            line=line,
            setup_state=setup_state,
            line_state=line_state,
            word_state=word_state,
            syl_state=syl_state,
            char_state=char_state,
        )
    )
    word_context = build_expression_context(
        ExecutionRuntime(
            scope=Scope.WORD,
            line=line,
            word=line.words[0],
            setup_state=setup_state,
            line_state=line_state,
            word_state=word_state,
            syl_state=syl_state,
            char_state=char_state,
        )
    )
    syl_context = build_expression_context(
        ExecutionRuntime(
            scope=Scope.SYL,
            line=line,
            syl=line.syls[0],
            setup_state=setup_state,
            line_state=line_state,
            word_state=word_state,
            syl_state=syl_state,
            char_state=char_state,
        )
    )
    char_context = build_expression_context(
        _char_runtime(
            line,
            setup_state=setup_state,
            line_state=line_state,
            word_state=word_state,
            syl_state=syl_state,
            char_state=char_state,
        )
    )

    assert line_context["setup_only"] == "setup"
    assert line_context["shared"] == "line"
    assert "word_only" not in line_context
    assert "syl_only" not in line_context
    assert "char_only" not in line_context

    assert word_context["setup_only"] == "setup"
    assert word_context["line_only"] == "line"
    assert word_context["shared"] == "word"
    assert "syl_only" not in word_context
    assert "char_only" not in word_context

    assert syl_context["setup_only"] == "setup"
    assert syl_context["line_only"] == "line"
    assert syl_context["shared"] == "syl"
    assert "word_only" not in syl_context
    assert "char_only" not in syl_context

    assert char_context["setup_only"] == "setup"
    assert char_context["line_only"] == "line"
    assert char_context["shared"] == "char"
    assert char_context["word_only"] == "word"
    assert char_context["syl_only"] == "syl"


def _setup_ctx_with_helper() -> ExecutionRuntime:
    """Return a setup runtime with a helper function defined by code."""
    setup_runtime = ExecutionRuntime(scope=Scope.SETUP)
    setup_runtime.run_code("def active_shared(): return shared")
    return setup_runtime


@pytest.mark.parametrize(
    ("scope", "shared_value"),
    [
        (Scope.LINE, "line"),
        (Scope.WORD, "word"),
        (Scope.SYL, "syl"),
        (Scope.CHAR, "char"),
    ],
)
def test_code_functions_follow_the_active_scope_hierarchy(
    scope: Scope,
    shared_value: str,
) -> None:
    """Code-defined functions should resolve names from the active scope chain."""
    line = _line()
    setup_runtime = _setup_ctx_with_helper()
    line_state: dict[str, object] = {"shared": "line"}

    if scope is Scope.LINE:
        runtime = ExecutionRuntime(
            scope=scope,
            line=line,
            setup_state=setup_runtime.setup_state,
            line_state=line_state,
        )
    elif scope is Scope.WORD:
        runtime = ExecutionRuntime(
            scope=scope,
            line=line,
            word=line.words[0],
            setup_state=setup_runtime.setup_state,
            line_state=line_state,
            word_state={"shared": "word"},
        )
    elif scope is Scope.SYL:
        runtime = ExecutionRuntime(
            scope=scope,
            line=line,
            syl=line.syls[0],
            setup_state=setup_runtime.setup_state,
            line_state=line_state,
            syl_state={"shared": "syl"},
        )
    else:
        runtime = _char_runtime(
            line,
            setup_state=setup_runtime.setup_state,
            line_state=line_state,
            word_state={"shared": "word"},
            syl_state={"shared": "syl"},
            char_state={"shared": "char"},
        )

    assert runtime.evaluate("active_shared()") == shared_value


def test_code_functions_can_call_other_code_functions() -> None:
    """Deferred code functions should resolve sibling helpers in the same context."""
    line = _line()
    setup_runtime = ExecutionRuntime(scope=Scope.SETUP)
    setup_runtime.run_code(
        "\n".join(
            [
                "def build_tag(target):",
                '    return f"<{target.start_time}:{target.end_time}:{syl.text}>"',
                "def autotag():",
                '    tags = ""',
                "    for target in line.syls:",
                "        tags += build_tag(target)",
                "    return tags",
            ]
        )
    )

    syl_runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=line.syls[1],
        setup_state=setup_runtime.setup_state,
    )

    assert syl_runtime.evaluate("autotag()") == "<0:100:cd><100:300:cd>"


def test_code_functions_rebind_to_the_active_runtime_context() -> None:
    """Persisted code functions must resolve names from the active runtime."""
    setup_runtime = ExecutionRuntime(scope=Scope.SETUP)
    setup_runtime.run_code("def active_actor(): return line.actor")

    first_runtime = ExecutionRuntime(
        scope=Scope.LINE,
        line=_line(actor="first"),
        setup_state=setup_runtime.setup_state,
    )
    second_runtime = ExecutionRuntime(
        scope=Scope.LINE,
        line=_line(actor="second"),
        setup_state=setup_runtime.setup_state,
    )

    assert first_runtime.evaluate("active_actor()") == "first"
    assert second_runtime.evaluate("active_actor()") == "second"


def test_scope_local_code_functions_follow_the_documented_hierarchy() -> None:
    """Functions stored in each scope should obey the documented visibility rules."""
    line = _line()
    word = line.words[0]
    syllable = line.syls[0]
    char = line.chars[0]

    line_code_runtime = ExecutionRuntime(scope=Scope.LINE, line=line)
    line_code_runtime.run_code("def line_helper(): return line.duration")

    word_code_runtime = ExecutionRuntime(scope=Scope.WORD, line=line, word=word)
    word_code_runtime.run_code("def word_helper(): return word.text")

    syl_code_runtime = ExecutionRuntime(scope=Scope.SYL, line=line, syl=syllable)
    syl_code_runtime.run_code("def syl_helper(): return syl.text")

    char_code_runtime = ExecutionRuntime(
        scope=Scope.CHAR,
        line=line,
        word=word,
        syl=syllable,
        char=char,
    )
    char_code_runtime.run_code("def char_helper(): return char.text")

    word_eval_runtime = ExecutionRuntime(
        scope=Scope.WORD,
        line=line,
        word=word,
        line_state=line_code_runtime.line_state,
        word_state=word_code_runtime.word_state,
        syl_state=syl_code_runtime.syl_state,
        char_state=char_code_runtime.char_state,
    )
    syl_eval_runtime = ExecutionRuntime(
        scope=Scope.SYL,
        line=line,
        syl=syllable,
        line_state=line_code_runtime.line_state,
        word_state=word_code_runtime.word_state,
        syl_state=syl_code_runtime.syl_state,
        char_state=char_code_runtime.char_state,
    )
    char_eval_runtime = _char_runtime(
        line,
        line_state=line_code_runtime.line_state,
        word_state=word_code_runtime.word_state,
        syl_state=syl_code_runtime.syl_state,
        char_state=char_code_runtime.char_state,
    )

    assert word_eval_runtime.evaluate("line_helper()") == line.duration
    assert word_eval_runtime.evaluate("word_helper()") == word.text
    with pytest.raises(NameError):
        word_eval_runtime.evaluate("syl_helper()")
    with pytest.raises(NameError):
        word_eval_runtime.evaluate("char_helper()")

    assert syl_eval_runtime.evaluate("line_helper()") == line.duration
    assert syl_eval_runtime.evaluate("syl_helper()") == syllable.text
    with pytest.raises(NameError):
        syl_eval_runtime.evaluate("word_helper()")
    with pytest.raises(NameError):
        syl_eval_runtime.evaluate("char_helper()")

    assert char_eval_runtime.evaluate("line_helper()") == line.duration
    assert char_eval_runtime.evaluate("word_helper()") == word.text
    assert char_eval_runtime.evaluate("syl_helper()") == syllable.text
    assert char_eval_runtime.evaluate("char_helper()") == char.text
