"""Integration tests for directive collection."""

import pytest
from tests.support import make_comment_event, make_dialogue_event

from pykara.ass.types import AssDocument
from pykara.engine.collector import collect_directives
from pykara.exceptions import PykaraValidationError


def test_collect_directives_reads_comment_lines_only() -> None:
    """Only comment lines with valid directives should be collected."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl", r"{\bord2}", style="Default", name="glow"
            ),
            make_comment_event("code line", "enabled = True", style="Default"),
            make_comment_event("patch syl for glow", r"{\bord3}", style="Default"),
            make_comment_event("karaoke", "ignored", style="Default"),
            make_dialogue_event(
                r"{\k10}a", style="Default", start_time=0, end_time=1000
            ),
        ]
    )

    templates, codes, patches = collect_directives(document)

    assert len(templates) == 1
    assert templates[0].style == "Default"
    assert templates[0].body == r"{\bord2}"
    assert len(codes) == 1
    assert codes[0].body == "enabled = True"
    assert len(patches) == 1
    assert patches[0].body == r"{\bord3}"


def test_collect_directives_rejects_patch_without_matching_template() -> None:
    """Patches must match at least one same-scope template declaration."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl", r"{\bord2}", style="Default", name="beta"
            ),
            make_comment_event(
                "patch syl layer 2 for alpha",
                r"{\bord3}",
                style="Default",
                layer=1,
            ),
        ]
    )

    with pytest.raises(PykaraValidationError, match="does not match any template"):
        collect_directives(document)


@pytest.mark.parametrize(
    (
        "template_style",
        "template_scope",
        "template_name",
        "template_layer",
        "patch_effect",
    ),
    [
        ("Other", "syl", "alpha", 1, "patch syl layer 1 for alpha"),
        ("Default", "word", "alpha", 1, "patch syl layer 1 for alpha"),
        ("Default", "syl", "beta", 1, "patch syl layer 1 for alpha"),
    ],
)
def test_collect_directives_rejects_patch_target_mismatch_matrix(
    template_style: str,
    template_scope: str,
    template_name: str,
    template_layer: int,
    patch_effect: str,
) -> None:
    """Patch matching should fail on style, scope, actor, and layer mismatches."""
    document = AssDocument(
        events=[
            make_comment_event(
                f"template {template_scope}",
                r"{\bord2}",
                style=template_style,
                name=template_name,
                layer=template_layer,
            ),
            make_comment_event(patch_effect, r"{\bord3}", style="Default"),
        ]
    )

    with pytest.raises(PykaraValidationError, match="does not match any template"):
        collect_directives(document)
