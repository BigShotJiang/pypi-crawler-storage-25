"""Runner integration tests for Phase 4 layout variables."""

from __future__ import annotations

from tests.support import (
    make_comment_event,
    make_dialogue_event,
    make_raw_style,
    make_script_info,
)

from pykara.ass.types import AssDocument
from pykara.engine.runner import run


def test_runner_interpolates_layout_variables() -> None:
    """Template output should expose all Phase 4 positioning variables."""
    document = AssDocument(
        script_info=make_script_info(),
        styles=[make_raw_style()],
        events=[
            make_comment_event(
                "template line no_text",
                "L:$line_left,$line_center,$line_right,$line_width,"
                "$line_top,$line_middle,$line_bottom,$line_height",
            ),
            make_comment_event(
                "template word no_text",
                "W:$word_wi,$word_ci,$word_left,$word_center,"
                "$word_right,$word_width,$word_height",
            ),
            make_comment_event(
                "template syl no_text",
                "S:$syl_si,$syl_ci,$syl_left,$syl_center,$syl_right,"
                "$syl_width,$syl_top,$syl_middle,$syl_bottom,$syl_height",
            ),
            make_comment_event(
                "template char no_text",
                "C:$char_ci,$char_si,$char_wi,$char_left,$char_center,"
                "$char_right,$char_width,$char_top,$char_middle,$char_bottom,$char_height",
            ),
            make_dialogue_event(
                r"{\k10} hi {\k20}there",
                style="Default",
                start_time=0,
                end_time=500,
                effect="karaoke",
            ),
        ],
    )

    output = run(document)

    assert [line.text for line in output] == [
        "L:785,959,1133,349,491,540,589,98",
        "W:1,1,835,874,914,79,98",
        "W:2,5,914,1024,1134,220,98",
        "S:1,1,810,849,888,78,491,540,589,98",
        "S:2,5,914,1024,1133,220,491,540,589,98",
        "C:1,1,1,810,822,835,25,491,540,589,98",
        "C:2,1,1,835,862,888,53,491,540,589,98",
        "C:3,1,1,888,901,913,25,491,540,589,98",
        "C:4,1,1,913,926,939,25,491,540,589,98",
        "C:5,2,2,914,930,946,32,491,540,589,98",
        "C:6,2,2,946,972,999,53,491,540,589,98",
        "C:7,2,2,999,1023,1048,49,491,540,589,98",
        "C:8,2,2,1048,1066,1085,37,491,540,589,98",
        "C:9,2,2,1085,1109,1133,49,491,540,589,98",
    ]
