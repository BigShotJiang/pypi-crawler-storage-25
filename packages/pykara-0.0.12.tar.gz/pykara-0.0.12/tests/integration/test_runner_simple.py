"""Small end-to-end engine tests."""

from __future__ import annotations

import itertools
import re

import pytest
from tests.support import make_comment_event, make_dialogue_event, make_script_info

from pykara.ass.types import AssDocument
from pykara.engine.runner import RunOptions, run
from pykara.exceptions import PykaraValidationError


def test_runner_template_line_runs_once_per_karaoke_line() -> None:
    """Line templates must not expand once per syllable."""
    document = AssDocument(
        events=[
            make_comment_event("template line", "L:", style="Default"),
            make_dialogue_event(r"{\k10}a{\k10}b", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert len(output) == 1
    assert output[0].text == "L:ab"


def test_runner_template_syl_runs_once_per_syllable() -> None:
    """Syllable templates should emit one output per syllable."""
    document = AssDocument(
        events=[
            make_comment_event("template syl", "S:", style="Default"),
            make_dialogue_event(r"{\k10}a{\k10}b", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["S:a", "S:b"]


def test_runner_supports_code_setup_and_code_line_state() -> None:
    """Setup and line code should be visible in later templates."""
    document = AssDocument(
        events=[
            make_comment_event("code setup", 'prefix = "P"', style="Any"),
            make_comment_event(
                "code line", "line_value = line.duration", style="Default"
            ),
            make_comment_event(
                "template syl", "!prefix!-!line_value!:", style="Default"
            ),
            make_dialogue_event(
                r"{\k10}a{\k20}b",
                style="Default",
                end_time=1500,
                effect="karaoke",
            ),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["P-500:a", "P-500:b"]


def test_runner_repeat_no_blank_inline_fx_and_no_text() -> None:
    """Loop modifiers should affect emission count and text append behavior."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl no_text repeat 3",
                "R!repeat.i!",
                style="Default",
            ),
            make_comment_event(
                "template syl no_blank inline_fx foo",
                "",
                style="Default",
            ),
            make_dialogue_event(
                r"{\-foo\k10}a{\k10} {\-bar\k10}b",
                style="Default",
                effect="karaoke",
            ),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == [
        "R1",
        "R2",
        "R3",
        "a",
        "R1",
        "R2",
        "R3",
        "R1",
        "R2",
        "R3",
    ]


def test_runner_repeat_supports_named_and_cartesian_loops() -> None:
    """Named repeat loops should expose repeat.* and expand cartesian products."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl no_text repeat outer 2 repeat inner 3",
                "O!repeat.outer.i!/!repeat.outer.n!-I!repeat.inner.i!/!repeat.inner.n!",
                style="Default",
            ),
            make_dialogue_event(r"{\k10}a", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == [
        "O1/2-I1/3",
        "O1/2-I2/3",
        "O1/2-I3/3",
        "O2/2-I1/3",
        "O2/2-I2/3",
        "O2/2-I3/3",
    ]


def test_runner_when_conditions_support_expression_and_token_forms() -> None:
    """Expression and token conditions should both filter syllables."""
    document = AssDocument(
        events=[
            make_comment_event(
                "code syl",
                "has_long_dur = syl.duration > 150",
                style="Default",
            ),
            make_comment_event(
                "template syl when (syl.duration > 150)",
                "E:",
                style="Default",
            ),
            make_comment_event("template syl when has_long_dur", "T:", style="Default"),
            make_dialogue_event(r"{\k10}a{\k20}b", style="Default", effect="karaoke"),
        ]
    )

    output = run(document, RunOptions(seed=42))

    assert [line.text for line in output] == ["E:b", "T:b"]


def test_runner_multi_emits_one_output_per_highlight_pass() -> None:
    """``multi`` should re-evaluate a syllable template for each highlight."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl no_text multi",
                "M:!syl.start_time!-!syl.end_time!",
                style="Default",
            ),
            make_dialogue_event(
                r"{\k10}ab{\k20}#cd{\k30}ef",
                style="Default",
                effect="karaoke",
            ),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == [
        "M:0-100",
        "M:100-300",
        "M:300-600",
    ]


def test_runner_processes_comment_karaoke_lines() -> None:
    """Comment karaoke sources should be treated as source lines."""
    document = AssDocument(
        events=[
            make_comment_event("template syl", "S:", style="Default"),
            make_comment_event("karaoke", r"{\k10}a{\k10}b", style="Default"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["S:a", "S:b"]


def test_runner_shares_memory_between_line_and_syllable_templates() -> None:
    """Line templates should be able to seed memory read by syllable templates."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template line no_text",
                '!memory.remember("prefix", "L")!',
                style="Default",
            ),
            make_comment_event(
                "template syl no_text",
                '!memory.recall.prefix!:"!syl.text!"',
                style="Default",
            ),
            make_dialogue_event(r"{\k10}a{\k10}b", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["L", 'L:"a"', 'L:"b"']


def test_runner_memory_uses_latest_overwritten_value() -> None:
    """Later writes to the same memory key should be visible to later templates."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template line no_text",
                '!memory.remember("prefix", "first")!',
                style="Default",
            ),
            make_comment_event(
                "template line no_text",
                '!memory.remember("prefix", "second")!',
                style="Default",
            ),
            make_comment_event(
                "template syl no_text",
                '!memory.recall.prefix!:"!syl.text!"',
                style="Default",
            ),
            make_dialogue_event(r"{\k10}a{\k10}b", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == [
        "first",
        "second",
        'second:"a"',
        'second:"b"',
    ]


def test_runner_templates_can_use_modules_imported_in_code_setup() -> None:
    """Names imported in setup code should remain available to later templates."""
    document = AssDocument(
        events=[
            make_comment_event("code setup", "import math", style="Default"),
            make_comment_event(
                "template syl no_text",
                "!math.floor(syl.duration / 100)!",
                style="Default",
            ),
            make_dialogue_event(
                r"{\k10}a{\k20}b",
                style="Default",
                effect="karaoke",
            ),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["1", "2"]


def test_runner_shares_seeded_imported_random_module_across_syllable_runtimes() -> None:
    """Imported random-module values should advance across syllables."""
    document = AssDocument(
        events=[
            make_comment_event("code setup", "import random", style="Default"),
            make_comment_event(
                "template syl no_text",
                "!random.randint(0, 255)!",
                style="Default",
            ),
            make_dialogue_event(
                r"{\k10}a{\k10}b{\k10}c",
                style="Default",
                effect="karaoke",
            ),
        ]
    )

    first = [line.text for line in run(document, RunOptions(seed=42))]
    second = [line.text for line in run(document, RunOptions(seed=42))]

    assert first == second
    assert len(set(first)) == 3


def test_runner_code_syl_can_consume_progressive_seeded_random_values() -> None:
    """``code syl`` should observe the shared seeded imported-random sequence."""
    document = AssDocument(
        events=[
            make_comment_event("code setup", "import random", style="Default"),
            make_comment_event(
                "code syl",
                "shade = random.randint(0, 255)",
                style="Default",
            ),
            make_comment_event("template syl no_text", "!shade!", style="Default"),
            make_dialogue_event(
                r"{\k10}a{\k10}b{\k10}c",
                style="Default",
                effect="karaoke",
            ),
        ]
    )

    output = [line.text for line in run(document, RunOptions(seed=42))]

    assert len(set(output)) == 3


def test_runner_executes_code_in_word_and_char_scopes() -> None:
    """Word and char code blocks should run before their matching templates."""
    document = AssDocument(
        events=[
            make_comment_event(
                "code word",
                "word_value = word.text.upper()",
                style="Default",
            ),
            make_comment_event(
                "template word no_text", "W:!word_value!", style="Default"
            ),
            make_comment_event(
                "code char",
                "char_value = char.text.upper()",
                style="Default",
            ),
            make_comment_event(
                "template char no_text", "C:!char_value!", style="Default"
            ),
            make_dialogue_event(r"{\k10}ab", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["W:AB", "C:A", "C:B"]


def test_runner_patch_syl_injects_before_scope_text() -> None:
    """Patch syl should inject text before the active syllable text."""
    document = AssDocument(
        events=[
            make_comment_event("template syl", "T:", style="Default"),
            make_comment_event("patch syl", "P:", style="Default"),
            make_dialogue_event(r"{\k10}a{\k10}b", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["T:P:a", "T:P:b"]


def test_runner_patch_matches_template_by_actor_and_layer() -> None:
    """Patch matching should honor the template comment actor and layer filters."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl", "A:", style="Default", name="alpha", layer=1
            ),
            make_comment_event(
                "template syl", "B:", style="Default", name="beta", layer=2
            ),
            make_comment_event("patch syl layer 1 for alpha", "P:", style="Default"),
            make_dialogue_event(r"{\k10}x", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["A:P:x", "B:x"]


def test_runner_patch_skips_style_scope_and_actor_mismatches() -> None:
    """Runner should ignore valid patches that target other templates."""
    document = AssDocument(
        events=[
            make_comment_event("template syl", "S:", style="Default", name="alpha"),
            make_comment_event("template word", "W:", style="Default", name="alpha"),
            make_comment_event("template syl", "B:", style="Default", name="beta"),
            make_comment_event("template syl", "O:", style="Other", name="alpha"),
            make_comment_event("patch syl for alpha", "P:", style="Default"),
            make_comment_event("patch word for alpha", "Q:", style="Default"),
            make_comment_event("patch syl for beta", "R:", style="Default"),
            make_comment_event("patch syl for alpha", "Z:", style="Other"),
            make_dialogue_event(r"{\k10}ab", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == [
        "W:Q:ab",
        "S:P:ab",
        "B:R:ab",
    ]


def test_runner_patch_inherits_repeat_and_template_side_effects() -> None:
    """Patch evaluation should reuse the same repeat pass side effects."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl no_text repeat 2",
                '!memory.remember("seen", repeat.i) and ""!T',
                style="Default",
            ),
            make_comment_event(
                "patch syl", ':!memory.recall.seen!', style="Default"
            ),
            make_dialogue_event(r"{\k10}a", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["T:1", "T:2"]


def test_runner_patch_re_evaluates_for_each_repeat_loop_iteration() -> None:
    """Patch should run once per template repeat iteration with the same loop state."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl no_text repeat outer 2 repeat inner 2",
                "T!repeat.outer.i!-!repeat.inner.i!",
                style="Default",
            ),
            make_comment_event(
                "patch syl",
                ":P!repeat.outer.i!-!repeat.inner.i!",
                style="Default",
            ),
            make_dialogue_event(r"{\k10}a", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == [
        "T1-1:P1-1",
        "T1-2:P1-2",
        "T2-1:P2-1",
        "T2-2:P2-2",
    ]


def test_runner_patch_re_evaluates_for_each_multi_highlight_pass() -> None:
    """Patch should observe the per-pass syllable state produced by ``multi``."""
    document = AssDocument(
        events=[
            make_comment_event("template syl no_text multi", "T", style="Default"),
            make_comment_event(
                "patch syl", ":!syl.start_time!-!syl.end_time!", style="Default"
            ),
            make_dialogue_event(
                r"{\k10}ab{\k20}#cd", style="Default", effect="karaoke"
            ),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == [
        "T:0-100",
        "T:100-300",
    ]


def test_runner_patch_respects_no_blank_and_inline_fx() -> None:
    """Patch skip modifiers should filter the injection passes."""
    document = AssDocument(
        events=[
            make_comment_event("template syl", "T:", style="Default"),
            make_comment_event(
                "patch syl no_blank inline_fx foo", "P:", style="Default"
            ),
            make_dialogue_event(
                r"{\-foo\k10}a{\-foo\k10} {\-bar\k10}b",
                style="Default",
                effect="karaoke",
            ),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["T:P:a", "T: ", "T:b"]


def test_runner_patch_char_runs_in_character_scope() -> None:
    """Patch char should inject once per rendered character output."""
    document = AssDocument(
        events=[
            make_comment_event("template char", "C:", style="Default"),
            make_comment_event("patch char inline_fx flash", "P:", style="Default"),
            make_dialogue_event(r"{\-flash\k10}ab", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["C:P:a", "C:P:b"]


def test_runner_applies_textual_retime_presets_in_char_scope() -> None:
    """Textual presets should stagger char templates by line-wide char order."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template char no_text", "!retime.line.ltr(-300, 0)!T", style="Default"
            ),
            make_dialogue_event(r"{\k10}ab", style="Default", effect="karaoke"),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["T", "T"]
    assert [(line.start_time, line.end_time) for line in output] == [
        (700, 1300),
        (1000, 1600),
    ]


def test_runner_applies_start2syl_presets_in_syl_scope() -> None:
    """Syllable-scope presets should distribute ``start2syl`` across line syllables."""
    document = AssDocument(
        events=[
            make_comment_event(
                "template syl no_text",
                "!retime.start2syl.from_edges(-200, 0)!T",
                style="Default",
            ),
            make_dialogue_event(
                r"{\k10}a{\k10}b{\k10}c{\k10}d", style="Default", effect="karaoke"
            ),
        ]
    )

    output = run(document)

    assert [line.text for line in output] == ["T", "T", "T", "T"]
    assert [(line.start_time, line.end_time) for line in output] == [
        (800, 1000),
        (933, 1100),
        (933, 1200),
        (800, 1300),
    ]


def test_runner_ignores_dialogue_without_karaoke_effect() -> None:
    """Ordinary dialogue rows must not be treated as karaoke sources."""
    document = AssDocument(
        events=[
            make_comment_event("template syl", "S:", style="Default"),
            make_dialogue_event(r"{\k10}a{\k10}b", style="Default", effect=""),
        ]
    )

    output = run(document)

    assert output == []


def test_runner_ignores_random_comment_lines() -> None:
    """Random comments must not be treated as karaoke sources."""
    document = AssDocument(
        events=[
            make_comment_event("template syl", "S:", style="Default"),
            make_comment_event("hello world", r"{\k10}a{\k10}b", style="Default"),
        ]
    )

    output = run(document)

    assert output == []


def test_runner_expands_motion_fbf_jitter_into_frame_baked_output() -> None:
    """`motion.fbf.jitter(...)` should expand one rendered line per frame."""
    document = AssDocument(
        script_info=make_script_info(extra_fields=[("PlaybackFPS", "24")]),
        events=[
            make_comment_event(
                "template line no_text",
                r"{\an5}!motion.fbf.jitter(1, 1, 0, 1, 100, 7)!X",
                style="Default",
            ),
            make_dialogue_event(
                r"{\k100}a",
                style="Default",
                start_time=1000,
                end_time=2000,
                effect="karaoke",
            ),
        ],
    )

    output = run(document)

    assert len(output) == 24
    assert output[0].start_time == 1000
    assert output[-1].end_time == 2000
    assert all(line.text.endswith("X") for line in output)
    assert all(r"\pos(" in line.text for line in output)
    assert all(
        left.end_time == right.start_time for left, right in itertools.pairwise(output)
    )


def test_runner_bakes_transforms_and_clip_before_applying_motion_fbf_jitter() -> None:
    r"""FBF jitter must compose with baked ``\t(...)`` and ``\clip`` output."""
    document = AssDocument(
        script_info=make_script_info(extra_fields=[("PlaybackFPS", "24")]),
        events=[
            make_comment_event(
                "template line",
                (
                    r"{\an5\clip(10,20,110,120)\fscx90\t(0,500,\clip(20,30,120,130)\fscx130)}"
                    r"!motion.fbf.jitter(1, 1, 1, 1, 100, 5)!"
                ),
                style="Default",
            ),
            make_dialogue_event(
                r"{\k100}a",
                style="Default",
                start_time=1000,
                end_time=2000,
                effect="karaoke",
            ),
        ],
    )

    output = run(document)

    assert len(output) == 24
    assert all(r"\pos(" in line.text for line in output)
    assert all(r"\clip(" in line.text for line in output)
    assert all(r"\t(" not in line.text for line in output)
    first_clip = re.search(r"\\clip\(([^)]*)\)", output[0].text)
    last_clip = re.search(r"\\clip\(([^)]*)\)", output[-1].text)
    first_scale = re.search(r"\\fscx([0-9.]+)", output[0].text)
    last_scale = re.search(r"\\fscx([0-9.]+)", output[-1].text)
    assert first_clip is not None and last_clip is not None
    assert first_scale is not None and last_scale is not None
    assert first_clip.group(1) != last_clip.group(1)
    assert first_scale.group(1) != last_scale.group(1)


def test_runner_rejects_move_with_motion_fbf_jitter() -> None:
    r"""FBF jitter should reject rendered lines that still contain ``\move``."""
    document = AssDocument(
        script_info=make_script_info(extra_fields=[("PlaybackFPS", "24")]),
        events=[
            make_comment_event(
                "template line",
                (
                    r"{\an5\move(10,20,30,40)}"
                    r"!motion.fbf.jitter(1, 1, 1, 1, 100, 5)!"
                ),
                style="Default",
            ),
            make_dialogue_event(
                r"{\k100}a",
                style="Default",
                start_time=1000,
                end_time=2000,
                effect="karaoke",
            ),
        ],
    )

    with pytest.raises(
        PykaraValidationError,
        match=r"frame-baked jitter cannot be combined with \\move",
    ):
        run(document)
