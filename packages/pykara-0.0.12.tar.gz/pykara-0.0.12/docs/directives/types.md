# Directive Types

Pykara uses ASS comment Effect fields to define template, code, and patch
directives.

## Template Directive

Defines a template that generates FX lines. Templates interpolate variables and
expressions once for each matching karaoke object.

**Syntax:** `template <scope> [modifiers...]`

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl no_text,{\pos($syl_center,$syl_middle)}
```

The text field is interpolated for each matching object and produces the final
FX lines.

---

## Code Directive

Executes Python code in a specific scope. Use it for setup, calculations, or
custom logic.

**Syntax:** `code <scope>`

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,code setup,my_var = 42
```

Code directives run their body as Python and cannot use modifiers.

---

## Patch Directive

Injects additional text into template output. Patches can prepend output,
target layers, or filter by actor and inline-fx.

**Syntax:** `patch <scope> [modifiers...]`

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,patch syl prepend,{\fad(300,0)}
```

Patch text is inserted before the template output with `prepend`, or after it
by default.
