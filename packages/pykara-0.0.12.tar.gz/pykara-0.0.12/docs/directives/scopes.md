# Scopes

Scopes determine what data is available during directive execution and which
karaoke object each directive runs against.

## Available Scopes

| Scope | Description |
|-------|-------------|
| `setup` | Runs once before any karaoke lines (`code` only) |
| `line` | Executes once per karaoke line |
| `word` | Executes once per word |
| `syl` | Executes once per syllable |
| `char` | Executes once per character |

See the individual scope pages for available bindings and variables.
