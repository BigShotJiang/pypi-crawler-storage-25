# Modifiers

Modifiers change how directives behave. For templates, modifier order matters.

## Template Modifiers

These modifiers can be used with `template` directives:

### `no_blank`

Skip execution when the current scope text is blank (only whitespace).

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl no_blank,{\pos($syl_center,$syl_middle)}
```

---

### `no_text`

Do not append the scope text to the template output. Without this modifier, the
template output is automatically followed by the syllable, word, or char text.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl no_text,{\pos($syl_center,$syl_middle)}
```

---

### `multi`

Expand the template once per highlight interval in the syllable. Use this with
multi-highlight karaoke timing.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl multi,{\pos($syl_center,$syl_middle)}
```

---

### `repeat [<name>] <count>`

Repeat the template multiple times with incrementing loop variables. You can
specify it multiple times for nested loops.

- `count` — Number of repetitions (must be ≥ 1)
- `name` — Optional name for this repeat loop

**Variables exposed:**

- `$repeat_i` — Current iteration index (1-based)
- `$repeat_n` — Total iterations
- `$repeat_<name>_i` — Named iteration index
- `$repeat_<name>_n` — Named total iterations

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl repeat 3,{\fad(!100*$repeat_i!,0)}

Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl repeat outer 2 repeat inner 3,{\pos($syl_center + $repeat_outer_i*10, $syl_middle + $repeat_inner_i*10)}
```

---

### `inline_fx <name>`

Only execute when the current inline-fx name matches the given value. Inline-fx
is set with `\-name` tags in karaoke timing.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl inline_fx special,{\pos($syl_center,$syl_middle)}
```

For example, with this karaoke line:

```ass
Dialogue: 0,0:00:00.00,0:00:05.00,Default,,0,0,0,karaoke,{\k50}No{\-special\k50}Yes{\k50}No
```

---

### `when <condition>`

Only execute when the condition evaluates to true. Must be the last modifier.

- Bare identifier: `when my_var` — true when the variable is truthy
- Python expression: `when (line.duration > 5000)` — evaluated as Python

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,code line,is_long = line.duration > 5000

Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl when is_long,{\pos($syl_center,$syl_middle)}
```

---

### `unless <condition>`

Only execute when the condition evaluates to false. Must be the last modifier.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl unless (syl.duration < 300),{\pos($syl_center,$syl_middle)}
```

---

## Patch Modifiers

These modifiers can be used with `patch` directives. Patch directives support a
subset of template modifiers plus patch-specific ones:

### Shared with Templates

- `no_blank` — Skip when text is blank
- `inline_fx <name>` — Only apply to matching inline-fx
- `when <condition>` — Conditional application
- `unless <condition>` — Conditional application

### Patch-Specific

#### `prepend`

Insert the patch text before the template output instead of after it.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,patch syl prepend,{\fad(300,0)}
```

---

#### `layer <n>`

Only apply this patch to templates generating output on layer `n`.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,patch syl layer 5,{\blur2}
```

> The `layer` modifier is most powerful when combined with `repeat` in the target
> template.

---

#### `for <actor>`

Only apply this patch to templates generated from lines with the matching actor
field.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,patch syl for Singer1,{\1c&HFFFFFF&}
```

---

## Modifier Order

For `template` directives, modifier order matters:

1. `no_blank`
2. `no_text`
3. `multi`
4. `repeat` (can appear multiple times)
5. `inline_fx`
6. `when` / `unless` (must be last)

For `patch` directives:

1. `no_blank`
2. `inline_fx`
3. `prepend`
4. `layer`
5. `for`
6. `when` / `unless` (must be last)
