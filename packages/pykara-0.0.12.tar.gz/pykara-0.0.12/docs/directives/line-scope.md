# Line Scope

Executes once per karaoke line. The entire line is the context.

## Available Bindings

- `line` — The current `Line` object
- `script` — Script metadata (resolution, styles, etc.)

## Variables

| Variable | Type | Description |
|----------|------|-------------|
| `$line_dur` | int | Line duration in milliseconds |
| `$line_left` | int | Left position |
| `$line_center` | int | Center position |
| `$line_right` | int | Right position |
| `$line_width` | int | Line width |
| `$line_top` | int | Top position |
| `$line_middle` | int | Middle position |
| `$line_bottom` | int | Bottom position |
| `$line_height` | int | Line height |
| `$line_li` | int | Line index (1-based) |

## Line Object Attributes

- `line.start_time`, `line.end_time`, `line.duration`
- `line.actor`, `line.style`
- `line.plain_text`, `line.trimmed_text`
- `line.syls`, `line.words`, `line.chars`
- `line.x`, `line.y`, `line.width`, `line.height`

## Example

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template line,{\pos($line_center,$line_middle)}
```
