# Template Interpolation

Templates use two forms of interpolation:

## Variables

`$variable_name` — Variable names are case-insensitive. Each scope exposes its
own set of `$variables`, which are replaced with their values.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\pos($syl_center,$syl_middle)\fscx!($syl_width * 2)!}
```

---

## Expressions

`!expression!` or `!(expression)!` — Evaluated as Python code with access to
the current scope's bindings.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\fad(!(syl.duration * 10)!,0)}

Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\alpha(&H!(255 - syl.si * 20)!&)}
```

**Variables in expressions:**

Inside expressions, `$variables` are resolved first and inserted as Python
literals:

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\pos(!($syl_left + 5)!,$syl_middle)}
```
