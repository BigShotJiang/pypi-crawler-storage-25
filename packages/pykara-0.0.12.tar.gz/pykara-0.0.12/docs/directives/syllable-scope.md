# Syllable Scope

Executes once per syllable in each karaoke line. This is the most commonly used
scope.

## Available Bindings

- `line` — The parent `Line` object
- `syl` — The current `Syllable` object
- `script` — Script metadata

## Variables

| Variable | Type | Description |
|----------|------|-------------|
| `$line_*` | various | All line-scope variables |
| `$syl_start` | int | Syllable start time (milliseconds) |
| `$syl_end` | int | Syllable end time (milliseconds) |
| `$syl_dur` | int | Syllable duration (milliseconds) |
| `$syl_kdur` | int | Karaoke duration in milliseconds (`\k`/`\K` value × 10) |
| `$syl_si` | int | Syllable index (1-based) |
| `$syl_ci` | int | Character index of syllable start |
| `$syl_left` | int | Absolute left position |
| `$syl_center` | int | Absolute center position |
| `$syl_right` | int | Absolute right position |
| `$syl_width` | int | Syllable width |
| `$syl_top` | int | Absolute top position |
| `$syl_middle` | int | Absolute middle position |
| `$syl_bottom` | int | Absolute bottom position |
| `$syl_height` | int | Syllable height |

## Syllable Object Attributes

- `syl.text`, `syl.start_time`, `syl.end_time`, `syl.duration`
- `syl.kdur` — Karaoke duration in milliseconds (`\k`/`\K` value × 10)
- `syl.tag_type` — The override tag used (`\k`, `\kf`, `\ko`, etc.)
- `syl.inline_fx` — Inline-fx name set by `\-name` tags
- `syl.override_tags` — Override tags found in syllable
- `syl.chars` — Child character objects
- `syl.left`, `syl.center`, `syl.right`, `syl.width`, `syl.height`
- `syl.abs_left`, `syl.abs_center`, `syl.abs_right`

## Example

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\pos($syl_center,$syl_middle)}
```
