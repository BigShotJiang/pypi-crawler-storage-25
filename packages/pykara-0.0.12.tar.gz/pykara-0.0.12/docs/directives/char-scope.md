# Char Scope

Executes once per character in each karaoke line, including spaces.

## Available Bindings

- `line` — The parent `Line` object
- `word` — The parent `Word` object
- `syl` — The parent `Syllable` object
- `char` — The current `Char` object
- `script` — Script metadata

## Variables

| Variable | Type | Description |
|----------|------|-------------|
| `$line_*` | various | All line-scope variables |
| `$word_*` | various | All word-scope variables |
| `$syl_*` | various | All syllable-scope variables |
| `$char_ci` | int | Character index (1-based) |
| `$char_si` | int | Syllable index of this character |
| `$char_wi` | int | Word index of this character |
| `$char_left` | int | Absolute left position |
| `$char_center` | int | Absolute center position |
| `$char_right` | int | Absolute right position |
| `$char_width` | int | Character width |
| `$char_top` | int | Absolute top position |
| `$char_middle` | int | Absolute middle position |
| `$char_bottom` | int | Absolute bottom position |
| `$char_height` | int | Character height |

## Char Object Attributes

- `char.text` — The single character
- `char.start_time`, `char.end_time`, `char.duration`

## Example

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template char,{\pos($char_center,$char_middle)}
```
