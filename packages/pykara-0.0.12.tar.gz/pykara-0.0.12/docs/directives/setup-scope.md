# Setup Scope

Runs once at the beginning, before any karaoke lines are processed. Use it for
initialization and shared state.

Only `code setup` directives are valid in this scope.

## Available Bindings

None

## Variables

None

Use `setup` to define shared names for later `line`, `word`, `syl`, and `char`
scopes.

## Example

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,code setup,max_alpha = 255
```
