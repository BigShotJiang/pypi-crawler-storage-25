# Word Scope

Executes once per word in each karaoke line.

## Available Bindings

- `line` — The parent `Line` object
- `word` — The current `Word` object
- `script` — Script metadata

## Variables

| Variable | Type | Description |
|----------|------|-------------|
| `$line_*` | various | All line-scope variables |
| `$word_wi` | int | Word index (1-based) |
| `$word_ci` | int | Character index of word start |
| `$word_left` | int | Absolute left position |
| `$word_center` | int | Absolute center position |
| `$word_right` | int | Absolute right position |
| `$word_width` | int | Word width |
| `$word_height` | int | Word height |

## Word Object Attributes

- `word.text`, `word.start_time`, `word.end_time`, `word.duration`
- `word.plain_text`, `word.trimmed_text`
- `word.leading_spaces`, `word.trailing_spaces`
- `word.syls`, `word.chars`
- `word.left`, `word.center`, `word.right`, `word.width`, `word.height`

## Example

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template word,{\pos($word_center,$line_middle)!word.text!}
```
