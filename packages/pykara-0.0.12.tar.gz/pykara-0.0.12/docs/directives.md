# Pykara Directive System

Pykara's directive system controls karaoke execution through comment lines in
your ASS file. Each directive is selected by keywords in the Effect field.

## Quick Reference

| Directive | Description |
|----------|-------------|
| `template <scope>` | Defines a template for generating FX lines into a scope |
| `code <scope>` | Executes Python code in a scope |
| `patch <scope>` | Injects additional text into template output |

## Documentation

### Core Concepts

- **[Directive Types](./directives/types.md)** — Template, code, and patch directives
- **[Scopes](./directives/scopes.md)** — Available scopes and their bindings
- **[Modifiers](./directives/modifiers.md)** — Template and patch modifiers
- **[Interpolation](./directives/interpolation.md)** — Variables and expressions

### Scopes

- **[Setup Scope](./directives/setup-scope.md)** — Runs once at initialization
- **[Line Scope](./directives/line-scope.md)** — Per-line execution
- **[Word Scope](./directives/word-scope.md)** — Per-word execution
- **[Syllable Scope](./directives/syllable-scope.md)** — Per-syllable execution (most
  common)
- **[Char Scope](./directives/char-scope.md)** — Per-character execution

### ASS Line Format

All directives use the ASS comment format:

```ass
Comment: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
```

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\pos($syl_center,$syl_middle)}
```

- `0:00:00.00,0:00:00.00` — Start and end times (use `0:00:00.00` for directives)
- `Default,,` — Style name and an empty Name field (note the double comma)
- `0,0,0,` — Three margin values
- `template syl` — Effect field (directive keyword + scope + modifiers)
- `{\pos($syl_center,$syl_middle)}` — Text field containing the template or
  code body

## See Also

- [Helpers](./helpers.md) — Available functions in expressions
