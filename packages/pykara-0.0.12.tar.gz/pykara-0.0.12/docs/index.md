# Pykara Documentation

## Quick Links

- **[Directives](./directives.md)** — Template directive system
- **[Helpers](./helpers.md)** — Expression helpers

## Documentation

### Directives

- [Types](./directives/types.md) — Template, code, and patch directives
- [Scopes](./directives/scopes.md) — Setup, line, word, syllable, and char scopes
- [Modifiers](./directives/modifiers.md) — Template and patch modifiers
- [Interpolation](./directives/interpolation.md) — Variables and expressions

### Helpers

- [color](./helpers/color.md) — Format-aware color helpers
- [memory](./helpers/memory.md) — Cross-template state
- [motion](./helpers/motion.md) — Animation effects
- [relayer](./helpers/relayer.md) — Layer control
- [repeat](./helpers/repeat.md) — Repeat-loop helpers
- [retime](./helpers/retime.md) — Timing control
- [scale](./helpers/scale.md) — Numeric scaling
- [palette](./helpers/palette.md) — Color palette
- [timeline](./helpers/timeline.md) — ASS transforms
