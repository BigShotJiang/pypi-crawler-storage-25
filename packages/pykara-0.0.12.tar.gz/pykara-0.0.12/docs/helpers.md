# Helpers

Helpers are available inside `!expression!` blocks in every scope.

## Available Helpers

| Helper | Description |
|--------|-------------|
| [`color`](./helpers/color.md) | RGB, hex, ASS, and HSV color helpers |
| [`memory`](./helpers/memory.md) | Persist values across template runs |
| [`motion`](./helpers/motion.md) | Motion helpers with shadow-trick or frame-baked output |
| [`relayer`](./helpers/relayer.md) | Change output layer dynamically |
| [`repeat`](./helpers/repeat.md) | Access repeat-loop state |
| [`retime`](./helpers/retime.md) | Explicit timing control |
| [`scale`](./helpers/scale.md) | Numeric scaling between ranges |
| [`palette`](./helpers/palette.md) | Named palette shades |
| [`timeline`](./helpers/timeline.md) | ASS `\t(...)` transform builders |

---

## Quick Reference

### color

- `color.rgb.to_ass(r, g, b)` — Format RGB as `&HBBGGRR&`
- `color.hex.to_ass("#RGB")` — Convert hex to ASS color
- `color.ass.parse("&HBBGGRR&")` — Parse ASS color to RGB tuple
- `color.hsv.to_rgb(h, s, v)` — HSV to RGB conversion

### memory

- `memory.remember(key, value)` — Store value in memory
- `memory.recall.<key>` — Retrieve stored value

### motion

- `motion.shad.*` — Shadow-trick motion effects
- `motion.fbf.*` — Frame-baked motion effects

### relayer

- `relayer(layer)` — Set output layer for this template

### repeat

- `repeat.i` — Current iteration (1-based)
- `repeat.n` — Total iterations
- `repeat.<name>.i` / `repeat.<name>.n` — Named repeat loop access

### retime

- `retime.line(start, end)` — Time relative to line
- `retime.syl(start, end)` — Time relative to syllable
- `retime.preline/postline` — Before/after line
- `retime.presyl/postsyl` — Before/after syllable
- `retime.start2syl/syl2end` — Line start to syl / Syl to line end
- Plus preset distributions: `.ltr()`, `.rtl()`, `.from_center()`, `.from_edges()`, etc.

### scale

- `scale.of(value).base(from).to(target)` — Scale value between ranges

### palette

- `palette.red[500]` — Get a palette shade as an ASS color

### timeline

- `timeline.transitions(steps, tags)` — Absolute-time transforms
- `timeline.sequence(steps, accel=1.0)` — Relative-time transforms
- `timeline.pulse(span, cadence, values, accel=1.0, start_index=0)` — Repeating
  transforms

---

## See Also

- [Directives](./directives.md) — Template directive syntax
- [Scopes & Variables](./directives/scopes.md) — Available scopes and variables
- [Modifiers](./directives/modifiers.md) — Template and patch modifiers
