# repeat Helper

Access repeat-loop state in expressions.

## repeat.i

Current iteration index (1-based) when exactly one repeat loop is active.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl repeat 3,{\fscx!(100 * repeat.i)!}
```

**Alternative:** `$repeat_i` in plain text

---

## repeat.n

Total iteration count when exactly one repeat loop is active.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl repeat 3,{progress: !(repeat.i / repeat.n)!}
```

**Alternative:** `$repeat_n` in plain text

---

## repeat.<name>

Access a named repeat loop's value with `.i` and `.n` properties.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl repeat outer 2 repeat inner 3,{!repeat.outer.i!,!repeat.inner.i!}
```

**Returns:** An int-like object with `.i` (current) and `.n` (total) properties
