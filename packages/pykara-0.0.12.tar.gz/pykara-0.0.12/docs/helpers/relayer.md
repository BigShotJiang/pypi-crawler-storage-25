# relayer Helper

Change the output layer for the current template pass.

## relayer(layer)

Set the output layer for the current template execution.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,!relayer(syl.si)!
```

**Parameters:**

- `layer` — Integer layer number
