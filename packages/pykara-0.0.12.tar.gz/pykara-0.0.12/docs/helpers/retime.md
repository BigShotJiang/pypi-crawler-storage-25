# retime Helper

Control output intervals explicitly. Retime targets shift when generated FX
appears.

## retime.line(start_offset, end_offset)

Set output timing relative to the line's duration.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.line(0, line.duration)!}
```

**Default:** `(0, 0)` = start at line start, end at line end

---

## retime.preline(start_offset, end_offset)

Set output timing before the line starts.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.preline(-500, 0)!}
```

Use negative offsets to place output before the line.

---

## retime.postline(start_offset, end_offset)

Set output timing after the line ends.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.postline(0, 500)!}
```

---

## retime.syl(start_offset, end_offset)

Set output timing relative to the syllable.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl(0, syl.duration)!}
```

**Default:** `(0, 0)` = start at syllable start, end at syllable end

---

## retime.presyl(start_offset, end_offset)

Set output timing before the syllable starts.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.presyl(-200, 0)!}
```

---

## retime.postsyl(start_offset, end_offset)

Set output timing after the syllable ends.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.postsyl(0, 200)!}
```

---

## retime.start2syl(start_offset, end_offset)

Set output timing from line start to syllable start.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.start2syl(0, 0)!}
```

---

## retime.syl2end(start_offset, end_offset)

Set output timing from syllable end to line end.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl2end(0, 0)!}
```

---

## Preset Distributions

All retime targets support preset distributions for animated timing:

### retime.<target>.ltr()

Left-to-right distribution across the collection.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl.ltr(-100, 100)!}
```

---

### retime.<target>.rtl()

Right-to-left distribution.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl.rtl(-100, 100)!}
```

---

### retime.<target>.from_center()

Distribute from center outward.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl.from_center(-100, 100)!}
```

---

### retime.<target>.from_edges()

Distribute from edges inward.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl.from_edges(-100, 100)!}
```

---

### retime.<target>.odd_first()

Odd indices first, then even.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl.odd_first(-100, 100)!}
```

---

### retime.<target>.even_first()

Even indices first, then odd.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl.even_first(-100, 100)!}
```

---

### retime.<target>.spatial_ltr()

Spatial left-to-right based on screen position.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl.spatial_ltr(-100, 100)!}
```

---

### retime.<target>.spatial_rtl()

Spatial right-to-left based on screen position.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl.spatial_rtl(-100, 100)!}
```

---

### retime.<target>.random()

Pseudo-random distribution.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!retime.syl.random(-100, 100)!}
```
