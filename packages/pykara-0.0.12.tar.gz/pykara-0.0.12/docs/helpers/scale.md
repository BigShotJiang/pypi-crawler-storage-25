# scale Helper

Scale values proportionally: `scale.of(x).base(B).to(T)` computes `x * T / B`.

Given a value `x` measured on a scale of `0..B`, this returns the equivalent
value on a scale of `0..T`.

---

## scale.of(value)

Wrap a numeric value to begin the scaling chain.

```python
scale.of(syl.si)
```

---

## scale.of(value).base(B)

Declare the source scale that `x` was measured on.

```python
scale.of(syl.si).base(len(line.syls))
```

---

## scale.of(value).base(B).to(T)

Compute the scaled result. Returns `int` when the result is a whole number, `float`
otherwise.

```python
scale.of(syl.si).base(len(line.syls)).to(T)
# → x * T / B
```

**Examples:**

Scale syllable index (1..N) to font size range 80..120:

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\fscx!(80 + scale.of(syl.si).base(len(line.syls)).to(40))!}
```

Scale syllable duration to alpha 0..200 (longer syllable = more opaque):

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\1a&H!(255 - scale.of(syl.duration).base(line.duration).to(200))!&}
```

Scale syllable horizontal position to hue angle 0..360:

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,code line,hue = lambda s: scale.of(s.center).base(line.right).to(360)
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\1c!(color.rgb.to_ass(*color.hsv.to_rgb(hue(syl), 0.8, 1.0)))!}
```

---

## scale.of(value).value

Access the original wrapped value when you need to reuse it after building the
chain.

```python
v = scale.of(syl.duration)
# v.value == syl.duration
# v.base(line.duration).to(255) == scaled result
```
