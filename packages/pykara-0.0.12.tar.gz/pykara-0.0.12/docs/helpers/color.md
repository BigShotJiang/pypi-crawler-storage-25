# color Helper

Color conversion utilities grouped by input and output format.

## color.rgb.to_ass(r, g, b)

Convert RGB values to an ASS color string.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\1c!color.rgb.to_ass(255, 0, 0)!}
```

**Returns:** `&HBBGGRR&` format string

---

## color.hex.to_ass(value)

Convert a hex color string to ASS format.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\1c!color.hex.to_ass("#FF0000")!}
```

**Accepts:** `#RGB` or `#RRGGBB` formats
**Returns:** `&HBBGGRR&` format string

---

## color.ass.parse(value)

Parse an ASS color string into an RGB tuple.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,code line,r, g, b = color.ass.parse("&H0000FF&")
```

**Accepts:** `&HBBGGRR&` or `&HAABBGGRR&` formats
**Returns:** `(r, g, b)` tuple with values 0-255

---

## color.hsv.to_rgb(h, s, v)

Convert HSV color to RGB tuple.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\1c!color.rgb.to_ass(*color.hsv.to_rgb(syl.si * 30, 1, 1))!}
```

**Parameters:**

- `h` — Hue in degrees (wraps modulo 360)
- `s` — Saturation 0.0-1.0
- `v` — Value/brightness 0.0-1.0

**Returns:** `(r, g, b)` tuple with values 0-255
