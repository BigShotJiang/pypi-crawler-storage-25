# timeline Helper

Build ASS `\t(...)` transform tags.

## timeline.transitions(steps, tags)

Create transforms anchored to absolute time windows.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template line,{!timeline.transitions([(("0:00:01.30", 120), "&H222222&")], [r"\1c"])!}
```

**Parameters:**

- `steps` — List of `((start, end_or_offset), values)` tuples where `start`
  can be:
  - Integer milliseconds
  - "H:MM:SS.mmm" timestamp string
  - end_or_offset can be integer (offset from start) or end time
- `tags` — List of ASS tag prefixes including backslashes (e.g., `[r"\1c", r"\3c"]`)

**Example with multiple tags:**

```ass
!timeline.transitions([(("0:00:01.30", 120), ("&H222222&", "&H000000&"))], [r"\1c", r"\3c"])
```

---

## timeline.sequence(steps, accel=1.0)

Build relative-time transforms.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!timeline.sequence([((12, 33), r"\3c&HFFFFFF&"), ((145, 245), r"\3c&H000000&")])!}
```

**Parameters:**

- `steps` — List of `((start_ms, end_ms), value)` tuples where value is a single string
  of ASS tags
- `accel` — Acceleration factor (default 1.0)

**Returns:** Combined `\t(...)` tags

**Example with acceleration:**

```ass
!timeline.sequence([((0, 200), r"\fscx150")], accel=0.5)
```

---

## timeline.pulse(span, cadence, values, accel=1.0, start_index=0)

Repeat transforms across time windows.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template line,{!timeline.pulse(line.duration, 400, [r"\fr-0.02", r"\fr0.02"])!}
```

**Parameters:**

- `span` — Integer duration, `(start_ms, end_ms)`, or list of ranges
- `cadence` — Integer (step=duration) or `(step_ms, duration_ms)` tuple
- `values` — List of transform payloads to cycle through
- `accel` — Acceleration factor (default 1.0)
- `start_index` — Which value to start with (default 0)

**Example with explicit range:**

```ass
!timeline.pulse((0, 1000), (200, 50), [r"\fscx120", r"\fscx100"])
```
