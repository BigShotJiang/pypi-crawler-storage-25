# memory Helper

Persist values across template evaluations.

## memory.remember(key, value)

Store a value in memory and return it.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!memory.remember("last_syl", syl.si)!}
```

Useful for tracking state between syllables.

---

## memory.recall.*

Access recalled values via attribute syntax.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!memory.recall.last_syl!}
```

Returns the value stored with `memory.remember()`.
