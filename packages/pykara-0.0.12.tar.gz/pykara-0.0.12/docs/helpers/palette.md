# palette Helper

Access named palette shades as ASS colors.

## palette.<color>[shade]

Get one shade from a palette color family.

**Example:**

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{\1c!palette.red[500]!}
```

**Available shades:** 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950

**Available color families:**

- `slate`, `gray`, `zinc`, `neutral`, `stone`
- `red`, `orange`, `amber`, `yellow`, `lime`
- `green`, `emerald`, `teal`, `cyan`
- `sky`, `blue`, `indigo`, `violet`, `purple`, `fuchsia`, `pink`, `rose`

**Example:**

```ass
{\1c!palette.rose[500]!}  ! Soft rose
{\3c!palette.sky[300]!}  ! Light sky blue for outline
{\4c!palette.amber[400]!}  ! Amber shadow
```
