# motion Helper

Create motion effects with two backends:

- `motion.shad` — Shadow-trick motion (single line, no framerate needed)
- `motion.fbf` — Frame-baked motion (generates multiple lines, requires framerate)

## Available Effects

| Effect | Description |
|--------|-------------|
| `jitter` | Random position hopping |
| `arc` | Arc/circle path motion |
| `bezier` | Bezier curve path motion |
| `spring` | Spring physics motion |
| `wave` | Sine wave motion |

## motion.shad

Shadow-trick motion uses ASS shadow offsets to simulate motion without
generating multiple lines. It returns `\t(...)` transform fragments.

### motion.shad.setup()

Initialize the shadow-trick backend. Returns the setup fragment.

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template line,{\an5\pos(640,360)!motion.shad.setup()!\4c!color.hex.to_ass("#123abc")!}
```

---

### motion.shad.jitter(left, right, up, down, period, seed=0)

Create jittery position hops.

**Parameters:**

- `left, right, up, down` — Jitter bounds in pixels
- `period` — Duration between hops in milliseconds
- `seed` — Random seed (default 0)

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template line,{\an5\pos(640,360)!motion.shad.setup()!\4c!color.hex.to_ass("#123abc")!!motion.shad.jitter(5, 5, 5, 5, 70)!}
```

---

### motion.shad.arc(x1, y1, x2, y2, a1=0, a2=360, r1=100, r2=100, t1=None, t2=None, segments=16)

Move along a circular or elliptical arc.

**Parameters:**

- `x1, y1` — Start position
- `x2, y2` — End position
- `a1, a2` — Start and end angles in degrees (default 0, 360)
- `r1, r2` — Radii (default 100)
- `t1, t2` — Timing offsets (optional)
- `segments` — Number of transform segments (default 16)

---

### motion.shad.bezier(*points, t1=None, t2=None, segments=None)

Move along a Bezier curve.

**Parameters:**

- `points` — Variable number of (x, y) tuples defining the curve
- `t1, t2` — Timing offsets (optional)
- `segments` — Number of transform segments (default 32 for 4 points, 16 for others)

---

### motion.shad.spring(...)

```python
motion.shad.spring(
    x0,
    y0,
    x1,
    y1,
    amplitude=1.0,
    damping=3.0,
    freq=6.0,
    t1=None,
    t2=None,
    segments=48,
)
```

Move with spring-like overshoot and damping.

**Parameters:**

- `x0, y0` — Start position
- `x1, y1` — Target position
- `amplitude` — Oscillation amplitude (default 1.0)
- `damping` — Damping factor (default 3.0)
- `freq` — Oscillation frequency (default 6.0)
- `t1, t2` — Timing offsets (optional)
- `segments` — Number of transform segments (default 48)

---

### motion.shad.wave(...)

```python
motion.shad.wave(
    x0,
    x1,
    y_base,
    amplitude=150,
    frequency=2.0,
    phase=0.0,
    t1=None,
    t2=None,
    segments=32,
)
```

Move along a sine wave.

**Parameters:**

- `x0, x1` — Start and end x positions
- `y_base` — Base y position
- `amplitude` — Wave height in pixels (default 150)
- `frequency` — Number of waves (default 2.0)
- `phase` — Phase offset in degrees (default 0.0)
- `t1, t2` — Timing offsets (optional)
- `segments` — Number of transform segments (default 32)

## motion.fbf

Frame-baked motion emits one event per frame for smoother animation. The
current template expands into multiple `DialogueLine` events.

### motion.fbf.jitter(left, right, up, down, period, seed=0)

Frame-baked version of `motion.shad.jitter`.

**Parameters:** Same as `motion.shad.jitter`

---

### motion.fbf.arc(x1, y1, x2, y2, a1=0, a2=360, r1=100, r2=100, t1=None, t2=None)

Frame-baked version of `motion.shad.arc`.

**Parameters:** Same as `motion.shad.arc` (segments not applicable)

---

### motion.fbf.bezier(*points, t1=None, t2=None)

Frame-baked version of `motion.shad.bezier`.

**Parameters:** Same as `motion.shad.bezier` (segments not applicable)

---

### motion.fbf.spring(x0, y0, x1, y1, amplitude=1.0, damping=3.0, freq=6.0, t1=None, t2=None)

Frame-baked version of `motion.shad.spring`.

**Parameters:** Same as `motion.shad.spring` (segments not applicable)

---

### motion.fbf.wave(x0, x1, y_base, amplitude=150, frequency=2.0, phase=0.0, t1=None, t2=None)

Frame-baked version of `motion.shad.wave`.

**Parameters:** Same as `motion.shad.wave` (segments not applicable)

## Requirements

- **shad**: Call `motion.shad.setup()` first, usually in a `template line`
- **fbf**: Requires framerate information in the ASS file (via `ScriptInfo` or
  the `--timecodes` flag)
- Use only one motion call across a template and its patches

## Example

```ass
Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template line,{\an5\pos(640,360)!motion.shad.setup()!\4c!color.hex.to_ass("#123abc")!}

Comment: 0,0:00:00.00,0:00:00.00,Default,,0,0,0,template syl,{!motion.shad.arc(0, 0, 100, 50, 0, 180)!}
```
