"""Validate parsed directives against the directive specs."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TypeAlias

from pykara.directive.types import (
    CodeDirective,
    ForMod,
    InlineFxMod,
    LayerMod,
    Modifier,
    MultiMod,
    NoblankMod,
    NotextMod,
    PatchDirective,
    PrependMod,
    RepeatMod,
    Scope,
    TemplateDirective,
    UnlessMod,
    WhenMod,
)
from pykara.exceptions import PykaraValidationError

ModifierOrderMap: TypeAlias = Mapping[type[Modifier], int]

_TEMPLATE_MODIFIER_ORDER: ModifierOrderMap = {
    NoblankMod: 0,
    NotextMod: 1,
    MultiMod: 2,
    RepeatMod: 3,
    InlineFxMod: 4,
    WhenMod: 5,
    UnlessMod: 5,
}

_PATCH_MODIFIER_ORDER: ModifierOrderMap = {
    NoblankMod: 0,
    InlineFxMod: 1,
    PrependMod: 2,
    LayerMod: 3,
    ForMod: 4,
    WhenMod: 5,
    UnlessMod: 5,
}


def _modifier_name(modifier: Modifier) -> str:
    """Return the stable spec name for one modifier instance."""
    modifier_names = {
        NoblankMod: "no_blank",
        NotextMod: "no_text",
        MultiMod: "multi",
        RepeatMod: "repeat",
        InlineFxMod: "inline_fx",
        PrependMod: "prepend",
        LayerMod: "layer",
        ForMod: "for",
        WhenMod: "when",
        UnlessMod: "unless",
    }
    return modifier_names[type(modifier)]


def _ensure_supported_modifier(
    modifier: Modifier,
    *,
    valid_modifiers: ModifierOrderMap,
    directive_label: str,
) -> type[Modifier]:
    """Return the modifier type after verifying it is valid here."""
    modifier_type = type(modifier)
    if modifier_type not in valid_modifiers:
        raise PykaraValidationError(
            "directive.validate(): "
            f"{_modifier_name(modifier)} is not valid in {directive_label} directives"
        )
    return modifier_type


def _ensure_modifier_order(
    modifier_type: type[Modifier],
    *,
    previous_order: int,
    order_map: ModifierOrderMap,
) -> int:
    """Validate modifier order and return the new order position."""
    order_position = order_map[modifier_type]
    if order_position < previous_order:
        raise PykaraValidationError("directive.validate(): modifiers are out of order")
    return order_position


def _ensure_condition_is_last(
    directive: TemplateDirective | PatchDirective,
    modifier: Modifier,
    index: int,
) -> None:
    """Reject conditional modifiers that are followed by later modifiers."""
    if not isinstance(modifier, WhenMod | UnlessMod):
        return
    if index == len(directive.modifiers) - 1:
        return
    if isinstance(modifier, WhenMod):
        raise PykaraValidationError(
            "directive.validate(): when must be the last modifier"
        )
    raise PykaraValidationError(
        "directive.validate(): unless must be the last modifier"
    )


def _validate_modifiers(  # noqa: C901
    directive: TemplateDirective | PatchDirective,
    *,
    order_map: ModifierOrderMap,
    directive_label: str,
) -> None:
    """Validate the modifier sequence of one template or patch directive.

    Args:
        directive: The directive whose modifier list is to be validated.
        order_map: Mapping from modifier type to its canonical order position.
        directive_label: Human-readable label (``"template"`` or ``"patch"``)
            used in error messages.

    Raises:
        PykaraValidationError: A modifier is unsupported, out of order, duplicated,
            or violates scope or mutual-exclusion constraints.
    """
    seen_modifier_types: set[type[Modifier]] = set()
    previous_order = -1
    named_repeat_loops: set[str] = set()
    seen_unnamed_repeat = False

    for index, modifier in enumerate(directive.modifiers):
        modifier_type = _ensure_supported_modifier(
            modifier,
            valid_modifiers=order_map,
            directive_label=directive_label,
        )
        is_repeat = modifier_type is RepeatMod
        if modifier_type in seen_modifier_types and not is_repeat:
            raise PykaraValidationError(
                "directive.validate(): "
                f"Duplicate modifier: {_modifier_name(modifier)}"
            )
        if not is_repeat:
            seen_modifier_types.add(modifier_type)

        previous_order = _ensure_modifier_order(
            modifier_type,
            previous_order=previous_order,
            order_map=order_map,
        )

        if isinstance(modifier, MultiMod) and directive.scope is not Scope.SYL:
            raise PykaraValidationError(
                "directive.validate(): multi is only valid in template syl"
            )

        if isinstance(modifier, InlineFxMod) and directive.scope not in {
            Scope.SYL,
            Scope.CHAR,
        }:
            raise PykaraValidationError(
                "directive.validate(): "
                f"inline_fx is only valid in {directive_label} syl and char"
            )

        if isinstance(modifier, RepeatMod):
            if modifier.count < 1:
                raise PykaraValidationError(
                    "directive.validate(): repeat count must be >= 1"
                )
            if modifier.name is None:
                if seen_unnamed_repeat:
                    raise PykaraValidationError(
                        "directive.validate(): "
                        "repeat without name can only appear once"
                    )
                if named_repeat_loops:
                    raise PykaraValidationError(
                        "directive.validate(): "
                        "Unnamed and named repeat loops cannot be mixed"
                    )
                seen_unnamed_repeat = True
            else:
                if seen_unnamed_repeat:
                    raise PykaraValidationError(
                        "directive.validate(): "
                        "Unnamed and named repeat loops cannot be mixed"
                    )
                if modifier.name in named_repeat_loops:
                    raise PykaraValidationError(
                        "directive.validate(): "
                        f"Duplicate repeat loop name: {modifier.name}"
                    )
                named_repeat_loops.add(modifier.name)

        _ensure_condition_is_last(directive, modifier, index)


def validate_directive(
    directive: TemplateDirective | CodeDirective | PatchDirective,
) -> None:
    """Validate one parsed directive instance.

    Args:
        directive: The directive to validate.

    Raises:
        PykaraValidationError: The directive has an illegal scope or its modifier
            sequence violates the spec.
    """
    if isinstance(directive, CodeDirective):
        return
    directive_label = "patch" if isinstance(directive, PatchDirective) else "template"
    if directive.scope == Scope.SETUP:
        raise PykaraValidationError(
            "directive.validate(): "
            f"{directive_label} directives do not support setup scope"
        )
    order_map = (
        _PATCH_MODIFIER_ORDER
        if isinstance(directive, PatchDirective)
        else _TEMPLATE_MODIFIER_ORDER
    )
    _validate_modifiers(directive, order_map=order_map, directive_label=directive_label)
