"""Typed directive models."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import TypeAlias, TypeVar

_M = TypeVar("_M")


class Scope(StrEnum):
    """Supported directive scopes."""

    SETUP = "setup"
    LINE = "line"
    WORD = "word"
    SYL = "syl"
    CHAR = "char"


@dataclass(frozen=True, slots=True)
class Token:
    """A bare identifier condition."""

    name: str


@dataclass(frozen=True, slots=True)
class Expression:
    """A parenthesized Python expression condition."""

    code: str


Condition: TypeAlias = Token | Expression
TemplateModifierList: TypeAlias = list["TemplateModifier"]
PatchModifierList: TypeAlias = list["PatchModifier"]


@dataclass(frozen=True, slots=True)
class NoblankMod:
    """The ``no_blank`` modifier."""


@dataclass(frozen=True, slots=True)
class NotextMod:
    """The ``no_text`` template modifier."""


@dataclass(frozen=True, slots=True)
class MultiMod:
    """The ``multi`` template modifier."""


@dataclass(frozen=True, slots=True)
class RepeatMod:
    """The ``repeat`` template modifier."""

    name: str | None
    count: int


@dataclass(frozen=True, slots=True)
class InlineFxMod:
    """The ``inline_fx`` modifier."""

    name: str


@dataclass(frozen=True, slots=True)
class WhenMod:
    """The ``when`` modifier."""

    condition: Condition


@dataclass(frozen=True, slots=True)
class UnlessMod:
    """The ``unless`` modifier."""

    condition: Condition


@dataclass(frozen=True, slots=True)
class PrependMod:
    """The ``prepend`` patch modifier."""


@dataclass(frozen=True, slots=True)
class LayerMod:
    """The ``layer`` patch modifier."""

    layer: int


@dataclass(frozen=True, slots=True)
class ForMod:
    """The ``for`` patch modifier."""

    name: str


TemplateModifier: TypeAlias = (
    NoblankMod | NotextMod | MultiMod | RepeatMod | InlineFxMod | WhenMod | UnlessMod
)


PatchModifier: TypeAlias = (
    NoblankMod | InlineFxMod | PrependMod | LayerMod | ForMod | WhenMod | UnlessMod
)


Modifier: TypeAlias = TemplateModifier | PatchModifier

AnyDirective: TypeAlias = "TemplateDirective | PatchDirective"


def find_modifier(directive: AnyDirective, modifier_type: type[_M]) -> _M | None:
    """Return the first modifier of ``modifier_type`` on ``directive``, or None.

    Args:
        directive: The template or patch directive to search.
        modifier_type: The modifier class to look for.

    Returns:
        The first matching modifier instance, or ``None`` if not present.
    """
    for modifier in directive.modifiers:
        if isinstance(modifier, modifier_type):
            return modifier
    return None


def has_modifier(directive: AnyDirective, modifier_type: type) -> bool:
    """Return whether ``directive`` carries any modifier of ``modifier_type``.

    Args:
        directive: The template or patch directive to inspect.
        modifier_type: The modifier class to check for.

    Returns:
        ``True`` if at least one modifier of the given type is present.
    """
    return find_modifier(directive, modifier_type) is not None


@dataclass(frozen=True, slots=True)
class TemplateDirective:
    """A parsed template directive."""

    scope: Scope
    modifiers: TemplateModifierList = field(default_factory=list[TemplateModifier])


@dataclass(frozen=True, slots=True)
class CodeDirective:
    """A parsed code directive."""

    scope: Scope


@dataclass(frozen=True, slots=True)
class PatchDirective:
    """A parsed patch directive."""

    scope: Scope
    modifiers: PatchModifierList = field(default_factory=list[PatchModifier])
