"""Parse ASS effect fields into typed directive models."""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import TypeVar, cast

from pykara.directive.types import (
    CodeDirective,
    Expression,
    ForMod,
    InlineFxMod,
    LayerMod,
    Modifier,
    MultiMod,
    NoblankMod,
    NotextMod,
    PatchDirective,
    PatchModifier,
    PrependMod,
    RepeatMod,
    Scope,
    TemplateDirective,
    TemplateModifier,
    Token,
    UnlessMod,
    WhenMod,
)
from pykara.exceptions import PykaraValidationError

_M = TypeVar("_M", "TemplateModifier", "PatchModifier")

_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_SNAKE_CASE_RE = re.compile(r"^[a-z][a-z0-9_]*$")
_ModifierParser = Callable[["DirectiveScanner"], Modifier]
_DirectiveParser = Callable[
    ["DirectiveScanner"],
    TemplateDirective | CodeDirective | PatchDirective,
]


class DirectiveScanner:
    """Consume directive tokens from one effect field."""

    def __init__(self, text: str) -> None:
        """Initialize the scanner."""
        self.text = text
        self.index = 0

    def at_end(self) -> bool:
        """Return whether the cursor already reached the end of the text."""
        return self.index >= len(self.text)

    def skip_spaces(self) -> None:
        """Advance the cursor past contiguous ASCII whitespace."""
        while not self.at_end() and self.text[self.index].isspace():
            self.index += 1

    def consume_word(self) -> str:
        """Consume the next whitespace-delimited token."""
        self.skip_spaces()
        start_index = self.index
        while not self.at_end() and not self.text[self.index].isspace():
            self.index += 1
        if start_index == self.index:
            raise PykaraValidationError("directive.parse(): expected token")
        return self.text[start_index : self.index]

    def consume_literal(self, literal: str) -> bool:
        """Consume ``literal`` when it appears at the current token boundary."""
        saved_index = self.index
        self.skip_spaces()
        literal_end = self.index + len(literal)
        if self.text[self.index : literal_end] != literal:
            self.index = saved_index
            return False
        if literal_end < len(self.text) and not self.text[literal_end].isspace():
            self.index = saved_index
            return False
        self.index = literal_end
        return True

    def remainder(self) -> str:
        """Return the remaining unconsumed text with outer whitespace stripped."""
        return self.text[self.index :].strip()


def _parse_scope(scope_name: str) -> Scope:
    """Parse one directive scope token."""
    try:
        return Scope(scope_name)
    except ValueError as exc:
        raise PykaraValidationError(
            f"directive.parse(): Invalid scope: {scope_name!r}"
        ) from exc


def _parse_identifier(token: str, *, label: str) -> str:
    """Parse one bare identifier token."""
    if not _IDENTIFIER_RE.fullmatch(token):
        raise PykaraValidationError(f"directive.parse(): Invalid {label}: {token!r}")
    return token


def _parse_snake_case_token(token: str, *, label: str) -> str:
    """Parse one snake_case token used by directive modifiers."""
    if not _SNAKE_CASE_RE.fullmatch(token):
        raise PykaraValidationError(f"directive.parse(): Invalid {label}: {token!r}")
    return token


def _parse_repeat_modifier(scanner: DirectiveScanner) -> RepeatMod:
    """Parse one ``repeat`` modifier payload."""
    first_token = scanner.consume_word()
    repeat_name: str | None = None
    count_token = first_token
    if not first_token.isdigit():
        repeat_name = _parse_snake_case_token(first_token, label="repeat name")
        try:
            count_token = scanner.consume_word()
        except PykaraValidationError as exc:
            raise PykaraValidationError(
                "directive.parse(): Invalid repeat count: ''"
            ) from exc
    if not count_token.isdigit():
        raise PykaraValidationError(
            f"directive.parse(): Invalid repeat count: {count_token!r}"
        )
    repeat_count = int(count_token)
    if repeat_count < 1:
        raise PykaraValidationError(
            f"directive.parse(): Invalid repeat count: {count_token!r}"
        )
    return RepeatMod(name=repeat_name, count=repeat_count)


def _parse_inline_fx_modifier(scanner: DirectiveScanner) -> InlineFxMod:
    """Parse one ``inline_fx`` modifier payload."""
    inline_fx_name = _parse_identifier(scanner.consume_word(), label="inline_fx")
    return InlineFxMod(name=inline_fx_name)


def _parse_noblank_modifier(_scanner: DirectiveScanner) -> NoblankMod:
    """Parse ``no_blank``."""
    return NoblankMod()


def _parse_notext_modifier(_scanner: DirectiveScanner) -> NotextMod:
    """Parse ``no_text``."""
    return NotextMod()


def _parse_multi_modifier(_scanner: DirectiveScanner) -> MultiMod:
    """Parse ``multi``."""
    return MultiMod()


def _parse_prepend_modifier(_scanner: DirectiveScanner) -> PrependMod:
    """Parse ``prepend``."""
    return PrependMod()


def _parse_layer_modifier(scanner: DirectiveScanner) -> LayerMod:
    """Parse one ``layer`` modifier payload."""
    layer_token = scanner.consume_word()
    try:
        layer_value = int(layer_token)
    except ValueError as exc:
        raise PykaraValidationError(
            f"directive.parse(): Invalid layer: {layer_token!r}"
        ) from exc
    return LayerMod(layer=layer_value)


def _parse_for_modifier(scanner: DirectiveScanner) -> ForMod:
    """Parse one ``for`` modifier payload."""
    return ForMod(name=scanner.consume_word())


def _parse_condition_payload(text: str) -> Token | Expression:  # noqa: C901
    """Parse the payload of a ``when`` or ``unless`` modifier.

    Args:
        text: Remaining scanner text after the ``when``/``unless`` keyword,
            already stripped of leading whitespace.

    Returns:
        A ``Token`` for bare snake_case identifiers, or an ``Expression`` for
        parenthesized Python expressions.

    Raises:
        PykaraValidationError: The condition is empty, the expression parentheses are
            unterminated, or trailing text follows the closing parenthesis.
    """
    if not text:
        raise PykaraValidationError("directive.parse(): missing condition")

    if text[0] != "(":
        return Token(name=_parse_snake_case_token(text, label="condition token"))

    depth = 0
    current_quote: str | None = None
    escaped = False
    for index, char in enumerate(text):
        if current_quote is not None:
            if escaped:
                escaped = False
                continue
            if char == "\\":
                escaped = True
                continue
            if char == current_quote:
                current_quote = None
            continue

        if char in {"'", '"'}:
            current_quote = char
            continue
        if char == "(":
            depth += 1
            continue
        if char == ")":
            depth -= 1
            if depth == 0:
                if text[index + 1 :].strip():
                    raise PykaraValidationError(
                        "directive.parse(): when/unless condition must be last"
                    )
                return Expression(code=text[1:index])

    raise PykaraValidationError(
        f"directive.parse(): Invalid condition expression: {text!r}"
    )


def _parse_conditional_modifier(
    scanner: DirectiveScanner,
) -> WhenMod | UnlessMod | None:
    """Parse one trailing conditional modifier when present."""
    if scanner.consume_literal("when"):
        return WhenMod(condition=_parse_condition_payload(scanner.remainder()))
    if scanner.consume_literal("unless"):
        return UnlessMod(condition=_parse_condition_payload(scanner.remainder()))
    return None


def _parse_optional_modifier(
    scanner: DirectiveScanner,
    literal: str,
    parse_modifier: _ModifierParser,
) -> Modifier | None:
    """Parse one optional modifier at the current cursor position."""
    if not scanner.consume_literal(literal):
        return None
    return parse_modifier(scanner)


def _append_template_modifier(
    modifiers: list[TemplateModifier],
    modifier: Modifier | None,
) -> None:
    """Append one optional template modifier with a narrowed type."""
    if modifier is not None:
        modifiers.append(cast(TemplateModifier, modifier))


def _append_patch_modifier(
    modifiers: list[PatchModifier],
    modifier: Modifier | None,
) -> None:
    """Append one optional patch modifier with a narrowed type."""
    if modifier is not None:
        modifiers.append(cast(PatchModifier, modifier))


def _finish_modifiers(
    scanner: DirectiveScanner,
    modifiers: list[_M],
    append: Callable[[list[_M], Modifier | None], None],
) -> None:
    """Append trailing conditional modifier and assert no leftover tokens."""
    conditional = _parse_conditional_modifier(scanner)
    if conditional is not None:
        append(modifiers, conditional)
        scanner.index = len(scanner.text)
    if scanner.remainder():
        raise PykaraValidationError(
            "directive.parse(): "
            f"Unexpected trailing directive text: {scanner.remainder()!r}"
        )


def _parse_template_directive(scanner: DirectiveScanner) -> TemplateDirective:
    """Parse the body of a ``template`` directive."""
    scope = _parse_scope(scanner.consume_word())
    modifiers: list[TemplateModifier] = []

    for literal, parse_modifier in [
        ("no_blank", _parse_noblank_modifier),
        ("no_text", _parse_notext_modifier),
        ("multi", _parse_multi_modifier),
    ]:
        _append_template_modifier(
            modifiers,
            _parse_optional_modifier(scanner, literal, parse_modifier),
        )

    while True:
        repeat_modifier = _parse_optional_modifier(
            scanner, "repeat", _parse_repeat_modifier
        )
        if repeat_modifier is None:
            break
        _append_template_modifier(modifiers, repeat_modifier)

    _append_template_modifier(
        modifiers,
        _parse_optional_modifier(scanner, "inline_fx", _parse_inline_fx_modifier),
    )

    _finish_modifiers(scanner, modifiers, _append_template_modifier)
    return TemplateDirective(scope=scope, modifiers=modifiers)


def _parse_patch_directive(scanner: DirectiveScanner) -> PatchDirective:
    """Parse the body of a ``patch`` directive."""
    scope = _parse_scope(scanner.consume_word())
    modifiers: list[PatchModifier] = []

    for literal, parse_modifier in [
        ("no_blank", _parse_noblank_modifier),
        ("inline_fx", _parse_inline_fx_modifier),
        ("prepend", _parse_prepend_modifier),
        ("layer", _parse_layer_modifier),
        ("for", _parse_for_modifier),
    ]:
        _append_patch_modifier(
            modifiers,
            _parse_optional_modifier(scanner, literal, parse_modifier),
        )

    _finish_modifiers(scanner, modifiers, _append_patch_modifier)
    return PatchDirective(scope=scope, modifiers=modifiers)


def _parse_code_directive(scanner: DirectiveScanner) -> CodeDirective:
    """Parse the body of a ``code`` directive."""
    scope_name = scanner.consume_word()
    if scope_name == Scope.SETUP.value:
        if scanner.remainder():
            raise PykaraValidationError(
                "directive.parse(): code directives do not accept modifiers"
            )
        return CodeDirective(scope=Scope.SETUP)
    scope = _parse_scope(scope_name)
    if scanner.remainder():
        raise PykaraValidationError(
            "directive.parse(): code directives do not accept modifiers"
        )
    return CodeDirective(scope=scope)


_DIRECTIVE_HANDLERS: dict[str, _DirectiveParser] = {
    "code": _parse_code_directive,
    "template": _parse_template_directive,
    "patch": _parse_patch_directive,
}


def parse_directive(
    effect: str,
) -> TemplateDirective | CodeDirective | PatchDirective | None:
    """Parse one ASS effect field into a directive model when applicable.

    Args:
        effect: Raw value of an ASS event ``Effect`` field.

    Returns:
        A ``TemplateDirective``, ``CodeDirective``, or ``PatchDirective``
        when the effect field begins with a recognized directive keyword;
        ``None`` when the field is blank or uses an unrecognized keyword.

    Raises:
        PykaraValidationError: The directive is recognized but its syntax is invalid.
    """
    scanner = DirectiveScanner(effect.strip())
    if scanner.at_end():
        return None

    directive_kind = scanner.consume_word()
    parse_directive_body = _DIRECTIVE_HANDLERS.get(directive_kind)
    return None if parse_directive_body is None else parse_directive_body(scanner)
