"""Shared curve sampling utilities used by all motion effects."""

from __future__ import annotations

from collections.abc import Callable


def lerp(t: float, a: float, b: float) -> float:
    """Return the linear interpolation between ``a`` and ``b`` at ``t``.

    Args:
        t: Interpolation factor in ``[0, 1]``.
        a: Start value.
        b: End value.

    Returns:
        ``a + t * (b - a)``.
    """
    return a + t * (b - a)


def _window_progress(ms: float, tw1: float, tw2: float) -> float:
    """Return normalised progress for one sampling window."""
    if ms <= tw1:
        return 0.0
    if ms >= tw2:
        return 1.0
    return (ms - tw1) / (tw2 - tw1)


def sample_curve(
    curve_fn: Callable[[float], tuple[float, float]],
    n_segments: int,
    tw1: float,
    tw2: float,
) -> list[tuple[float, float, float, float, float, float]]:
    """Sample *curve_fn* at ``n_segments + 1`` uniformly-spaced points.

    Args:
        curve_fn: A callable mapping ``t ∈ [0, 1]`` to ``(x, y)``.
        n_segments: Number of linear segments to produce.
        tw1: Window start in milliseconds.
        tw2: Window end in milliseconds.

    Returns:
        A list of ``(ms0, ms1, x0, y0, x1, y1)`` tuples, one per segment.
    """
    result: list[tuple[float, float, float, float, float, float]] = []
    for i in range(n_segments):
        t0 = i / n_segments
        t1 = (i + 1) / n_segments
        ms0 = tw1 + t0 * (tw2 - tw1)
        ms1 = tw1 + t1 * (tw2 - tw1)
        x0, y0 = curve_fn(_window_progress(ms0, tw1, tw2))
        x1, y1 = curve_fn(_window_progress(ms1, tw1, tw2))
        result.append((ms0, ms1, x0, y0, x1, y1))
    return result
