"""Shared curve math utilities for motion effects."""
