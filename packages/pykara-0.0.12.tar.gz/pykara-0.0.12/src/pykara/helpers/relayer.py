"""Relayer helper."""

from __future__ import annotations

from collections.abc import Callable

from pykara.exceptions import PykaraTypeError


class RelayerHelper:
    """Callable that mutates the output layer for the current template pass."""

    def __init__(self, set_output_layer: Callable[[int], None]) -> None:
        self._set_output_layer = set_output_layer

    def __call__(self, layer: object) -> None:
        """Set the output layer for this template pass."""
        if not isinstance(layer, int):
            raise PykaraTypeError(
                "relayer() layer must be an integer, "
                f"got {layer!r} ({type(layer).__name__})"
            )
        self._set_output_layer(layer)
