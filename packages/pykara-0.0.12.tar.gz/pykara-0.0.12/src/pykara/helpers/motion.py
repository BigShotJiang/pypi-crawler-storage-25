"""Motion helper."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pykara.helpers.motion_fbf import FbfMotionHelper
from pykara.helpers.motion_shad import ShadMotionHelper

if TYPE_CHECKING:
    from pykara.engine.protocols import MotionRuntime


class MotionHelper:
    """Root motion helper that exposes effect-specific helper families."""

    def __init__(self, runtime: MotionRuntime | None = None) -> None:
        """Bind helper families to the current execution runtime."""
        self.shad = ShadMotionHelper(runtime)
        self.fbf = FbfMotionHelper(runtime)


__all__ = ["FbfMotionHelper", "MotionHelper", "ShadMotionHelper"]
