"""Preset resolution helpers for retime."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from math import sin
from typing import TYPE_CHECKING, Literal, Protocol, TypeAlias

from pykara.directive.types import Scope
from pykara.exceptions import PykaraValidationError

if TYPE_CHECKING:
    from pykara.engine.protocols import RetimeRuntime
    from pykara.engine.retime_state import RetimeTargetName

RetimePresetName: TypeAlias = Literal[
    "ltr",
    "rtl",
    "from_center",
    "from_edges",
    "odd_first",
    "even_first",
    "spatial_ltr",
    "spatial_rtl",
    "random",
]
PresetOffsetMode: TypeAlias = Literal["point", "entry", "exit", "both"]


class CenteredItem(Protocol):
    """Minimal spatial surface required by retime preset collections."""

    abs_center: int


RetimeCollectionItem: TypeAlias = CenteredItem

LINE_FAMILY_TARGETS: frozenset[RetimeTargetName] = frozenset(
    {"line", "preline", "postline"}
)
SYL_FAMILY_TARGETS: frozenset[RetimeTargetName] = frozenset(
    {"syl", "presyl", "postsyl"}
)
IMPLEMENTED_PRESETS: frozenset[RetimePresetName] = frozenset(
    {
        "ltr",
        "rtl",
        "from_center",
        "from_edges",
        "odd_first",
        "even_first",
        "spatial_ltr",
        "spatial_rtl",
        "random",
    }
)
SPATIAL_PRESETS: frozenset[RetimePresetName] = frozenset(
    {"spatial_ltr", "spatial_rtl"}
)
POINT_TARGETS: frozenset[RetimeTargetName] = frozenset(
    {"preline", "postline", "presyl", "postsyl"}
)
ENTRY_TARGETS: frozenset[RetimeTargetName] = frozenset({"syl", "start2syl"})
EXIT_TARGETS: frozenset[RetimeTargetName] = frozenset({"syl2end"})
TEXTUAL_PRESET_FACTORIES: dict[
    RetimePresetName,
    Callable[[int, int], float],
] = {
    "ltr": lambda index, count: index / (count - 1),
    "rtl": lambda index, count: (count - 1 - index) / (count - 1),
    "from_center": lambda index, count: (
        abs(index - (count - 1) / 2) / ((count - 1) / 2)
    ),
    "from_edges": lambda index, count: (
        1 - abs(index - (count - 1) / 2) / ((count - 1) / 2)
    ),
    "odd_first": lambda index, count: float(index % 2),
    "even_first": lambda index, count: float((index + 1) % 2),
    "random": lambda index, count: abs(sin((index + 1) * 127.1 + 311.7)),
}


def resolve_preset_collection(
    runtime: RetimeRuntime,
    target_name: RetimeTargetName,
    preset_name: str,
) -> tuple[Sequence[RetimeCollectionItem], RetimeCollectionItem]:
    """Return the collection and current item used by one preset call."""
    if target_name in LINE_FAMILY_TARGETS:
        return _resolve_line_family_collection(runtime, target_name, preset_name)
    if target_name in SYL_FAMILY_TARGETS:
        return _resolve_syl_family_collection(runtime, target_name, preset_name)
    if runtime.line is None or runtime.syl is None:
        raise PykaraValidationError(
            f"retime.{target_name}.{preset_name}() requires line and syl runtime"
        )
    if runtime.scope not in {Scope.SYL, Scope.CHAR}:
        raise PykaraValidationError(
            "retime."
            f"{target_name}.{preset_name}() is only valid in template syl and char"
        )
    return (runtime.line.syls, runtime.syl)


def preset_offset_mode(
    target_name: RetimeTargetName,
    scope: Scope,
) -> PresetOffsetMode:
    """Return how one preset should distribute offsets for one target."""
    if target_name in POINT_TARGETS:
        return "point"
    if target_name == "line":
        return "both" if scope in {Scope.WORD, Scope.CHAR} else "entry"
    if target_name in ENTRY_TARGETS:
        return "entry"
    if target_name in EXIT_TARGETS:
        return "exit"
    raise PykaraValidationError(f"retime: Unknown retime target: {target_name!r}")


def applied_offsets(
    *,
    start_offset: int,
    end_offset: int,
    distributed_offset: int,
    offset_mode: PresetOffsetMode,
) -> tuple[int, int]:
    """Return the concrete offsets applied to one preset-distributed target."""
    if offset_mode in {"point", "both"}:
        return (distributed_offset, distributed_offset)
    if offset_mode == "entry":
        return (distributed_offset, end_offset)
    return (start_offset, distributed_offset)


def distributed_offset(start_offset: int, end_offset: int, factor: float) -> int:
    """Project one normalized factor onto the requested offset window."""
    return round(start_offset * (1.0 - factor) + end_offset * factor)


def preset_factor(
    target_name: RetimeTargetName,
    preset_name: RetimePresetName,
    collection: Sequence[RetimeCollectionItem],
    current_item: RetimeCollectionItem,
) -> float:
    """Return the normalized factor for one preset and current item."""
    if len(collection) < 2:
        raise PykaraValidationError(
            f"retime.{target_name}.{preset_name}() requires at least 2 elements"
        )

    index = _current_index(collection, current_item)
    if preset_name in SPATIAL_PRESETS:
        return _spatial_factor(preset_name, collection, index, target_name)
    return TEXTUAL_PRESET_FACTORIES[preset_name](index, len(collection))


def _resolve_line_family_collection(
    runtime: RetimeRuntime,
    target_name: RetimeTargetName,
    preset_name: str,
) -> tuple[Sequence[RetimeCollectionItem], RetimeCollectionItem]:
    if runtime.line is None:
        raise PykaraValidationError(
            f"retime.{target_name}.{preset_name}() requires line runtime"
        )
    if runtime.scope is Scope.WORD and runtime.word is not None:
        return (runtime.line.words, runtime.word)
    if runtime.scope is Scope.SYL and runtime.syl is not None:
        return (runtime.line.syls, runtime.syl)
    if runtime.scope is Scope.CHAR and runtime.char is not None:
        return (runtime.line.chars, runtime.char)
    raise PykaraValidationError(
        f"retime.{target_name}.{preset_name}() is invalid in template line"
    )


def _resolve_syl_family_collection(
    runtime: RetimeRuntime,
    target_name: RetimeTargetName,
    preset_name: str,
) -> tuple[Sequence[RetimeCollectionItem], RetimeCollectionItem]:
    if runtime.scope is not Scope.CHAR or runtime.syl is None or runtime.char is None:
        raise PykaraValidationError(
            f"retime.{target_name}.{preset_name}() is only valid in template char"
        )
    return (runtime.syl.chars, runtime.char)


def _current_index(
    collection: Sequence[RetimeCollectionItem],
    current_item: RetimeCollectionItem,
) -> int:
    current_id = id(current_item)
    for index, item in enumerate(collection):
        if id(item) == current_id:
            return index
    raise PykaraValidationError(
        "retime preset could not locate the current item in its collection"
    )


def _spatial_factor(
    preset_name: RetimePresetName,
    collection: Sequence[RetimeCollectionItem],
    index: int,
    target_name: RetimeTargetName,
) -> float:
    xs = [float(item.abs_center) for item in collection]
    min_x = min(xs)
    max_x = max(xs)
    if max_x == min_x:
        raise PykaraValidationError(
            "retime."
            f"{target_name}.{preset_name}() requires distinct horizontal positions"
        )
    normalized = (xs[index] - min_x) / (max_x - min_x)
    if preset_name == "spatial_ltr":
        return normalized
    return 1 - normalized
