"""Target call helpers for retime."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, cast

from pykara.exceptions import (
    PykaraAttributeError,
    PykaraNotImplementedError,
    PykaraTypeError,
)
from pykara.helpers.retime_presets import (
    IMPLEMENTED_PRESETS,
    RetimePresetName,
    applied_offsets,
    distributed_offset,
    preset_factor,
    preset_offset_mode,
    resolve_preset_collection,
)

if TYPE_CHECKING:
    from pykara.engine.protocols import RetimeRuntime
    from pykara.engine.retime_state import RetimeTargetName

ALL_TARGET_NAMES: tuple[RetimeTargetName, ...] = (
    "line",
    "preline",
    "postline",
    "syl",
    "presyl",
    "postsyl",
    "start2syl",
    "syl2end",
)


def validate_offsets(target_name: str, args: tuple[object, ...]) -> tuple[int, int]:
    """Return validated explicit retime offsets."""
    if not args:
        return (0, 0)
    if len(args) == 2 and all(type(value) is int for value in args):
        return cast(tuple[int, int], args)
    raise PykaraTypeError(
        f"retime.{target_name}() accepts () or (start_offset, end_offset)"
    )


@dataclass(slots=True)
class PendingRetimePreset:
    """Placeholder object reserved for future preset support."""

    target_name: RetimeTargetName
    preset_name: str

    def __call__(self, *_args: object, **_kwargs: object) -> str:
        """Reject preset calls until the preset is implemented."""
        raise PykaraNotImplementedError(
            f"retime.{self.target_name}.{self.preset_name}(...) is not implemented yet"
        )


@dataclass(slots=True)
class RetimePresetCall:
    """Callable retime preset bound to one explicit target."""

    runtime: RetimeRuntime
    target_name: RetimeTargetName
    preset_name: RetimePresetName

    def __call__(self, *args: object, **kwargs: object) -> str:
        """Apply one preset-distributed retime target."""
        if kwargs:
            raise PykaraNotImplementedError(
                f"retime.{self.target_name}.{self.preset_name}(...) keyword parameters "
                "are not implemented yet"
            )
        start_offset, end_offset = validate_offsets(
            f"{self.target_name}.{self.preset_name}",
            args,
        )
        collection, current_item = resolve_preset_collection(
            self.runtime,
            self.target_name,
            self.preset_name,
        )
        factor = preset_factor(
            self.target_name,
            self.preset_name,
            collection,
            current_item,
        )
        offset = distributed_offset(start_offset, end_offset, factor)
        applied_start_offset, applied_end_offset = applied_offsets(
            start_offset=start_offset,
            end_offset=end_offset,
            distributed_offset=offset,
            offset_mode=preset_offset_mode(self.target_name, self.runtime.scope),
        )
        self.runtime.apply_retime_target(
            self.target_name,
            applied_start_offset,
            applied_end_offset,
        )
        return ""


@dataclass(slots=True)
class RetimeTargetCall:
    """Callable retime target prepared for preset chaining."""

    runtime: RetimeRuntime
    target_name: RetimeTargetName

    def __call__(self, *args: object) -> str:
        """Apply one explicit retime target and return an empty fragment."""
        start_offset, end_offset = validate_offsets(self.target_name, args)
        self.runtime.apply_retime_target(
            self.target_name,
            start_offset,
            end_offset,
        )
        return ""

    def __getattr__(self, preset_name: str) -> RetimePresetCall | PendingRetimePreset:
        """Resolve one concrete preset target or keep the future chain reserved."""
        if preset_name.startswith("__"):
            raise PykaraAttributeError(
                f"retime.{self.target_name}.{preset_name} is not defined"
            )
        if preset_name in IMPLEMENTED_PRESETS:
            return RetimePresetCall(
                self.runtime,
                self.target_name,
                preset_name,
            )
        return PendingRetimePreset(self.target_name, preset_name)
