"""Retime helper for explicit timing control."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pykara.helpers.retime_targets import ALL_TARGET_NAMES, RetimeTargetCall

if TYPE_CHECKING:
    from pykara.engine.protocols import RetimeRuntime


class RetimeHelper:
    """Explicit retime targets that mutate the current output interval."""

    line: RetimeTargetCall
    preline: RetimeTargetCall
    postline: RetimeTargetCall
    syl: RetimeTargetCall
    presyl: RetimeTargetCall
    postsyl: RetimeTargetCall
    start2syl: RetimeTargetCall
    syl2end: RetimeTargetCall

    def __init__(self, runtime: RetimeRuntime) -> None:
        """Bind one retime target attribute per supported target name."""
        for target_name in ALL_TARGET_NAMES:
            setattr(self, target_name, RetimeTargetCall(runtime, target_name))


__all__ = ["RetimeHelper"]
