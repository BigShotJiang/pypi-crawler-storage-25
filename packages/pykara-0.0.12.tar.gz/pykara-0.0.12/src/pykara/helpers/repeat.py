"""Repeat-loop helper."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

from pykara.exceptions import PykaraAttributeError

if TYPE_CHECKING:
    from pykara.engine.protocols import RepeatBindingLike


class _RepeatValue(int):
    """Int-like repeat iteration value that also exposes ``.i`` and ``.n``."""

    _total_count: int

    def __new__(cls, binding: RepeatBindingLike) -> _RepeatValue:
        instance = int.__new__(cls, binding.index)
        instance._total_count = binding.count
        return instance

    @property
    def i(self) -> int:
        """Return the current iteration (1-based)."""
        return int(self)

    @property
    def n(self) -> int:
        """Return the total iteration count."""
        return self._total_count


class RepeatHelper:
    """Repeat helpers exposed to ``!expression!``."""

    def __init__(
        self,
        *,
        repeat_binding: Callable[[str], RepeatBindingLike | None],
        single_repeat_binding: Callable[[], RepeatBindingLike | None],
    ) -> None:
        """Initialize the helper."""
        self._repeat_binding = repeat_binding
        self._single_repeat_binding = single_repeat_binding

    def __getattr__(self, name: str) -> object:
        """Resolve generic or named repeat state.

        Args:
            name: Attribute name to resolve.  ``"i"`` returns the current
                iteration (1-based int), ``"n"`` returns the total iteration
                count, and any other name resolves a named repeat binding.

        Returns:
            A ``_RepeatValue`` (int subclass) for the resolved binding, or
            a plain ``int`` for the ``"n"`` shorthand.

        Raises:
            PykaraAttributeError: The name is ``"i"`` or ``"n"`` and the runtime
                does not have exactly one repeat loop, or the named binding
                does not exist.
        """
        if name in {"i", "n"}:
            default_binding = self._single_repeat_binding()
            if default_binding is None:
                raise PykaraAttributeError(
                    f"repeat.{name} requires exactly one active repeat loop"
                )
            value = _RepeatValue(default_binding)
            return value if name == "i" else value.n

        named_binding = self._repeat_binding(name)
        if named_binding is None:
            raise PykaraAttributeError(f"repeat.{name} is not defined")
        return _RepeatValue(named_binding)
