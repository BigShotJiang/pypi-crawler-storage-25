"""Timeline helper."""

from __future__ import annotations

from collections.abc import Callable, Sequence

from pykara.exceptions import PykaraValidationError
from pykara.helpers.timeline_parsing import (
    TimelinePulseCadenceInput,
    TimelinePulseSpanInput,
    TimelineSequenceStepInput,
    TimelineStepInput,
    TimelineTransition,
    normalize_pulse_cadence,
    normalize_pulse_spans,
    normalize_pulse_values,
    parse_sequence_step,
    parse_tags,
    parse_transition,
)
from pykara.karaoke.line import Line


def _format_transition(tags: tuple[str, ...], values: tuple[str, ...]) -> str:
    """Return one ASS tag payload aligned with ``tags``."""
    return "".join(f"{tag}{value}" for tag, value in zip(tags, values, strict=True))


def _format_ass_transform(start_ms: int, end_ms: int, value: str, accel: float) -> str:
    r"""Return one ASS ``\t(...)`` fragment."""
    if accel == 1:
        return rf"\t({start_ms},{end_ms},{value})"
    return rf"\t({start_ms},{end_ms},{accel},{value})"


def _clip_to_output_interval(
    transition: TimelineTransition,
    absolute_start: int,
    absolute_end: int,
) -> tuple[int, int] | None:
    """Clip one absolute transition to the current output interval."""
    if transition.end_ms < absolute_start or transition.start_ms >= absolute_end:
        return None

    clipped_start = max(transition.start_ms, absolute_start)
    clipped_end = min(transition.end_ms, absolute_end)
    return (clipped_start - absolute_start, clipped_end - absolute_start)


class TimelineHelper:
    """Time-based ASS transition helpers."""

    def __init__(
        self,
        *,
        line: Line | None,
        output_interval: Callable[[], tuple[int, int]],
    ) -> None:
        """Bind the helper to the current line and output interval."""
        self._line = line
        self._output_interval = output_interval

    def transitions(
        self,
        steps: Sequence[TimelineStepInput],
        tags: Sequence[str],
    ) -> str:
        r"""Map absolute transition windows into ASS ``\t(...)`` fragments."""
        if self._line is None:
            raise PykaraValidationError("timeline.transitions() requires line runtime")
        tag_items = parse_tags(tags)
        if not steps:
            return ""

        transitions = [parse_transition(step, tag_items) for step in steps]
        if any(
            transitions[index].start_ms > transitions[index + 1].start_ms
            for index in range(len(transitions) - 1)
        ):
            raise PykaraValidationError(
                "timeline.transitions() steps must be sorted ascending"
            )

        output_start, output_end = self._output_interval()
        absolute_start = self._line.start_time + output_start
        absolute_end = self._line.start_time + output_end

        fragments: list[str] = []
        for transition in transitions:
            clipped = _clip_to_output_interval(
                transition,
                absolute_start,
                absolute_end,
            )
            if clipped is None:
                continue

            t1, t2 = clipped
            event = _format_transition(tag_items, transition.values)
            fragments.append(rf"\t({t1},{t2},{event})")
        return "".join(fragments)

    def sequence(
        self,
        steps: Sequence[TimelineSequenceStepInput],
        *,
        accel: float = 1.0,
    ) -> str:
        r"""Build ASS ``\t(...)`` fragments from relative windows."""
        fragments = [
            _format_ass_transform(
                window.start_ms,
                window.end_ms,
                window.value,
                accel,
            )
            for window in (parse_sequence_step(step) for step in steps)
        ]
        return "".join(fragments)

    def pulse(
        self,
        span: TimelinePulseSpanInput,
        cadence: TimelinePulseCadenceInput,
        values: Sequence[str],
        *,
        accel: float = 1.0,
        start_index: int = 0,
    ) -> str:
        r"""Repeat a transform payload across one or more relative windows."""
        if start_index < 0:
            raise PykaraValidationError("timeline.pulse() start_index must be >= 0")

        pulse_values = normalize_pulse_values(values)
        windows = normalize_pulse_spans(span)
        step_ms, duration_ms = normalize_pulse_cadence(cadence)

        if not pulse_values:
            return ""

        fragments: list[str] = []
        pulse_count = len(pulse_values)
        value_index = start_index % pulse_count

        for window_start, window_end in windows:
            current_start = window_start
            while current_start < window_end:
                current_end = min(current_start + duration_ms, window_end)
                fragments.append(
                    _format_ass_transform(
                        current_start,
                        current_end,
                        pulse_values[value_index],
                        accel,
                    )
                )
                current_start += step_ms
                value_index = (value_index + 1) % pulse_count

        return "".join(fragments)
