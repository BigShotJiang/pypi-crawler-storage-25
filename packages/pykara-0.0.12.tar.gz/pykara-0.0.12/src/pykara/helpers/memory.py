"""Cross-template memory helper."""

from __future__ import annotations

from pykara.exceptions import PykaraAttributeError


class MemoryRecallView:
    """Attribute-style memory reader."""

    def __init__(self, memory: dict[str, object]) -> None:
        """Initialize the proxy."""
        self._memory = memory

    def __getattr__(self, name: str) -> object:
        """Resolve a stored key."""
        if name not in self._memory:
            raise PykaraAttributeError(f"memory.recall.{name} is not defined")
        return self._memory[name]


class MemoryHelper:
    """Memory helpers for ``remember`` and ``recall``."""

    def __init__(self, memory_state: dict[str, object]) -> None:
        """Initialize the helper."""
        self._memory_state = memory_state
        self.recall = MemoryRecallView(memory_state)

    def remember(self, key: str, value: object) -> object:
        """Store ``value`` under ``key`` and return it.

        Args:
            key: The string key to store the value under.
            value: The value to persist in the cross-template memory state.

        Returns:
            ``value`` unchanged, so the call can be used inline.
        """
        self._memory_state[key] = value
        return value
