"""Shadow-trick motion helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pykara.helpers.motion_base import MotionBackend
from pykara.motion.arc.shad import build_shad_arc
from pykara.motion.bezier.shad import build_shad_bezier
from pykara.motion.jitter.shad import SHAD_SETUP_FRAGMENT, build_shad_jitter
from pykara.motion.runtime.runtime_geometry import (
    motion_anchor,
    output_interval_duration,
)
from pykara.motion.spring.shad import build_shad_spring
from pykara.motion.wave.shad import build_shad_wave

if TYPE_CHECKING:
    from pykara.engine.protocols import MotionRuntime


class ShadMotionHelper(MotionBackend):
    """Shadow-trick motion helpers exposed as ``motion.shad``."""

    backend_name = "shad"

    def setup(self) -> str:
        r"""Return the fixed ASS fragment that enables the shadow trick."""
        return SHAD_SETUP_FRAGMENT

    def _curve_runtime(
        self,
        effect_name: str,
    ) -> tuple[MotionRuntime, int, float, float]:
        """Return line runtime, duration and anchor for one shad effect."""
        runtime = self._require_line_runtime(effect_name)
        ax, ay = motion_anchor(runtime)
        return runtime, output_interval_duration(runtime), ax, ay

    def jitter(
        self,
        left: int,
        right: int,
        up: int,
        down: int,
        period: int,
        seed: int = 0,
    ) -> str:
        r"""Return deterministic zero-duration ``\t(...)`` jitter hops."""
        runtime = self._require_line_runtime("jitter")
        spec = self._validate_jitter_spec(
            "jitter",
            left,
            right,
            up,
            down,
            period,
            seed,
        )
        return build_shad_jitter(
            output_interval_duration(runtime),
            spec.left,
            spec.right,
            spec.up,
            spec.down,
            spec.period,
            spec.seed,
        )

    def arc(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        a1: float = 0.0,
        a2: float = 360.0,
        r1: float = 100.0,
        r2: float = 100.0,
        t1: float | None = None,
        t2: float | None = None,
        segments: int = 16,
    ) -> str:
        r"""Return ``\t(...)`` segments for arc motion via the shadow trick."""
        _, duration, ax, ay = self._curve_runtime("arc")
        return build_shad_arc(
            duration,
            ax,
            ay,
            x1,
            y1,
            x2,
            y2,
            a1,
            a2,
            r1,
            r2,
            t1,
            t2,
            segments,
        )

    def bezier(
        self,
        *points: tuple[float, float],
        t1: float | None = None,
        t2: float | None = None,
        segments: int | None = None,
    ) -> str:
        r"""Return ``\t(...)`` segments for Bezier motion via the shadow trick."""
        _, duration, ax, ay = self._curve_runtime("bezier")
        pts = list(points)
        default_segments = 32 if len(pts) == 4 else 16
        return build_shad_bezier(
            duration,
            ax,
            ay,
            pts,
            t1,
            t2,
            segments if segments is not None else default_segments,
        )

    def spring(
        self,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        amplitude: float = 1.0,
        damping: float = 3.0,
        freq: float = 6.0,
        t1: float | None = None,
        t2: float | None = None,
        segments: int = 48,
    ) -> str:
        r"""Return ``\t(...)`` segments for spring motion via the shadow trick."""
        _, duration, ax, ay = self._curve_runtime("spring")
        return build_shad_spring(
            duration,
            ax,
            ay,
            x0,
            y0,
            x1,
            y1,
            amplitude,
            damping,
            freq,
            t1,
            t2,
            segments,
        )

    def wave(
        self,
        x0: float,
        x1: float,
        y_base: float,
        amplitude: float = 150.0,
        frequency: float = 2.0,
        phase: float = 0.0,
        t1: float | None = None,
        t2: float | None = None,
        segments: int = 32,
    ) -> str:
        r"""Return ``\t(...)`` segments for wave motion via the shadow trick."""
        _, duration, ax, ay = self._curve_runtime("wave")
        return build_shad_wave(
            duration,
            ax,
            ay,
            x0,
            x1,
            y_base,
            amplitude,
            frequency,
            phase,
            t1,
            t2,
            segments,
        )
