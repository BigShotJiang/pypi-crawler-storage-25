"""Shared runtime helpers for motion helper families."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pykara.exceptions import PykaraValidationError
from pykara.motion.jitter.spec import JitterSpec, validate_jitter_spec

if TYPE_CHECKING:
    from pykara.engine.protocols import MotionRuntime


class MotionBackend:
    """Shared runtime and validation helpers for motion backends."""

    backend_name: str

    def __init__(self, runtime: MotionRuntime | None = None) -> None:
        """Bind the backend to the current execution runtime."""
        self._runtime = runtime

    def _label(self, effect_name: str) -> str:
        """Return the public helper label used in error messages."""
        return f"motion.{self.backend_name}.{effect_name}()"

    def _require_line_runtime(self, effect_name: str) -> MotionRuntime:
        """Return a runtime guaranteed to carry line data."""
        label = self._label(effect_name)
        if self._runtime is None or self._runtime.line is None:
            raise PykaraValidationError(f"{label} requires line runtime")
        return self._runtime

    def _require_fbf_runtime(self, effect_name: str) -> MotionRuntime:
        """Return a line runtime guaranteed to have a framerate."""
        label = self._label(effect_name)
        runtime = self._require_line_runtime(effect_name)
        if runtime.framerate is None:
            raise PykaraValidationError(
                f"{label} requires explicit timecodes or PlaybackFPS"
            )
        return runtime

    def _validate_jitter_spec(
        self,
        effect_name: str,
        left: int,
        right: int,
        up: int,
        down: int,
        period: int,
        seed: int,
    ) -> JitterSpec:
        """Return one validated jitter spec for the public motion API."""
        return validate_jitter_spec(
            left,
            right,
            up,
            down,
            period,
            seed,
            label=self._label(effect_name),
        )
