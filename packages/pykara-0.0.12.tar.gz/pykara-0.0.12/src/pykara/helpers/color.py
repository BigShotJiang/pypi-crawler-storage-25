"""Color helper."""

from __future__ import annotations

import colorsys

from pykara.exceptions import PykaraValidationError


def _format_ass_color(r: int, g: int, b: int) -> str:
    """Return one ASS color string from integer RGB channels."""
    return f"&H{b:02X}{g:02X}{r:02X}&"


def _normalize_ass_color_payload(value: str) -> str:
    """Return the ``BBGGRR`` payload from one ASS color string."""
    normalized = value.strip()
    if not (normalized.startswith("&H") and normalized.endswith("&")):
        raise PykaraValidationError(f"color.ass.parse(): Invalid ASS color: {value!r}")

    payload = normalized[2:-1]
    if len(payload) == 8:
        payload = payload[2:]
    if len(payload) != 6:
        raise PykaraValidationError(f"color.ass.parse(): Invalid ASS color: {value!r}")
    return payload


def _normalize_hex_color_payload(value: str) -> str:
    """Return the ``RRGGBB`` payload from one hex color string."""
    if not value.startswith("#"):
        raise PykaraValidationError(
            f"color.hex.to_ass(): Invalid hex color: {value!r}"
        )

    payload = value[1:]
    if len(payload) == 3:
        payload = "".join(channel * 2 for channel in payload)
    if len(payload) != 6 or any(
        char not in "0123456789abcdefABCDEF" for char in payload
    ):
        raise PykaraValidationError(
            f"color.hex.to_ass(): Invalid hex color: {value!r}"
        )
    return payload.upper()


class RgbColorHelper:
    """RGB color conversions."""

    def to_ass(self, r: int, g: int, b: int) -> str:
        """Format an RGB color as ``&HBBGGRR&``."""
        return _format_ass_color(r, g, b)


class HexColorHelper:
    """Hex color conversions."""

    def to_ass(self, value: str) -> str:
        """Convert ``#RGB`` or ``#RRGGBB`` into ``&HBBGGRR&``."""
        payload = _normalize_hex_color_payload(value)
        return _format_ass_color(
            int(payload[0:2], 16),
            int(payload[2:4], 16),
            int(payload[4:6], 16),
        )


class AssColorHelper:
    """ASS color conversions."""

    def parse(self, value: str) -> tuple[int, int, int]:
        """Parse an ASS color string into ``(r, g, b)``."""
        payload = _normalize_ass_color_payload(value)
        return (int(payload[4:6], 16), int(payload[2:4], 16), int(payload[0:2], 16))


class HsvColorHelper:
    """HSV color conversions."""

    def to_rgb(self, h: float, s: float, v: float) -> tuple[int, int, int]:
        """Convert HSV to integer RGB using a degree-based hue scale."""
        hue = (h % 360) / 360.0
        red, green, blue = colorsys.hsv_to_rgb(hue, s, v)
        return (
            round(red * 255),
            round(green * 255),
            round(blue * 255),
        )


class ColorHelper:
    """Root color helper that exposes format-specific helper families."""

    def __init__(self) -> None:
        """Bind format-specific color helpers."""
        self.rgb = RgbColorHelper()
        self.hex = HexColorHelper()
        self.ass = AssColorHelper()
        self.hsv = HsvColorHelper()


__all__ = [
    "AssColorHelper",
    "ColorHelper",
    "HexColorHelper",
    "HsvColorHelper",
    "RgbColorHelper",
]
