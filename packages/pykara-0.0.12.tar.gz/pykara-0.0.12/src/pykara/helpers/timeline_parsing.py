"""Parsing helpers and normalized types for timeline helpers."""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TypeAlias, cast

from pykara.ass.time import parse_ass_time
from pykara.exceptions import PykaraTypeError, PykaraValidationError

TimelineScalarTime: TypeAlias = int | str
TimelineRangeInput: TypeAlias = tuple[TimelineScalarTime, int | TimelineScalarTime]
TimelineValueInput: TypeAlias = str | tuple[str, ...] | list[str]
TimelineStepInput: TypeAlias = tuple[TimelineRangeInput, TimelineValueInput]
TimelineSequenceStepInput: TypeAlias = tuple[TimelineRangeInput, str]
TimelinePulseSpanInput: TypeAlias = (
    int
    | tuple[TimelineScalarTime, int | TimelineScalarTime]
    | Sequence[tuple[TimelineScalarTime, int | TimelineScalarTime]]
)
TimelinePulseCadenceInput: TypeAlias = int | tuple[int, int]

_TAGS_ERROR = "timeline.transitions() tags must be a sequence of strings"
_STEP_PAIR_ERROR = "timeline.transitions() steps must be two-item pairs"
_RANGE_PAIR_ERROR = "timeline.transitions() ranges must be two-item tuples/lists"
_TIME_VALUE_ERROR = (
    "timeline.transitions() time values must be ASS timestamps, "
    "H:MM:SS.mmm strings, or integers"
)
_TIMELINE_HMS_RE = re.compile(
    r"^(?P<hours>\d+):(?P<minutes>\d+):(?P<seconds>\d+)\.(?P<fraction>\d{1,3})$"
)
_SEQUENCE_STEP_ERROR = "timeline.sequence() steps must be two-item pairs"
_SEQUENCE_VALUE_ERROR = "timeline.sequence() step values must be strings"
_PULSE_VALUES_ERROR = "timeline.pulse() values must be a non-empty sequence of strings"
_PULSE_CADENCE_ERROR = (
    "timeline.pulse() cadence must be a positive integer or a two-item pair "
    "(step, duration)"
)


@dataclass(frozen=True, slots=True)
class TimelineWindow:
    """One normalized relative transform window."""

    start_ms: int
    end_ms: int
    value: str


@dataclass(frozen=True, slots=True)
class TimelineTransition:
    """One parsed transition window plus its ordered tag values."""

    start_ms: int
    end_ms: int
    values: tuple[str, ...]


def parse_transition(
    step: object,
    tags: tuple[str, ...],
) -> TimelineTransition:
    """Parse one user-provided transition step."""
    range_value, values_value = _expect_two_item_pair(step, _STEP_PAIR_ERROR)
    start_ms, end_ms = parse_range(range_value)
    return TimelineTransition(
        start_ms=start_ms,
        end_ms=end_ms,
        values=_parse_values(values_value, tags),
    )


def parse_tags(tags: object) -> tuple[str, ...]:
    """Validate and normalize the user-provided tag sequence."""
    if type(tags) in {str, bytes}:
        raise PykaraTypeError(_TAGS_ERROR)

    tag_items = tuple(cast(Sequence[object], tags))
    if not tag_items:
        raise PykaraValidationError("timeline.transitions() requires at least one tag")
    if any(type(tag) is not str for tag in tag_items):
        raise PykaraTypeError(_TAGS_ERROR)
    return cast(tuple[str, ...], tag_items)


def parse_sequence_step(step: object) -> TimelineWindow:
    """Parse one user-provided relative transform step."""
    range_value, value = _expect_two_item_pair(step, _SEQUENCE_STEP_ERROR)
    if type(value) is not str:
        raise PykaraTypeError(_SEQUENCE_VALUE_ERROR)
    start_ms, end_ms = parse_range(range_value)
    return TimelineWindow(start_ms=start_ms, end_ms=end_ms, value=value)


def normalize_pulse_values(values: object) -> tuple[str, ...]:
    """Validate the pulse payload sequence."""
    if type(values) in {str, bytes}:
        raise PykaraTypeError(_PULSE_VALUES_ERROR)
    items = tuple(cast(Sequence[object], values))
    if not items or any(type(item) is not str for item in items):
        raise PykaraTypeError(_PULSE_VALUES_ERROR)
    return cast(tuple[str, ...], items)


def normalize_pulse_spans(span: TimelinePulseSpanInput) -> tuple[tuple[int, int], ...]:
    """Normalize one or more relative pulse spans."""
    if type(span) is int:
        if span < 0:
            raise PykaraValidationError("timeline.pulse() span must be non-negative")
        return ((0, span),)

    if type(span) in {tuple, list}:
        items = tuple(cast(Sequence[object], span))
        if len(items) == 2 and type(items[0]) not in {tuple, list}:
            start_ms, end_ms = parse_range(cast(object, span))
            return ((start_ms, end_ms),)

        windows: list[tuple[int, int]] = []
        for item in items:
            start_ms, end_ms = parse_range(item)
            windows.append((start_ms, end_ms))
        if not windows:
            raise PykaraValidationError(
                "timeline.pulse() span must include at least one window"
            )
        return tuple(windows)

    raise PykaraTypeError(
        "timeline.pulse() span must be an integer duration, one range pair, "
        "or a sequence of range pairs"
    )


def normalize_pulse_cadence(cadence: TimelinePulseCadenceInput) -> tuple[int, int]:
    """Normalize pulse cadence into ``(step_ms, duration_ms)``."""
    if type(cadence) is int:
        if cadence <= 0:
            raise PykaraValidationError(_PULSE_CADENCE_ERROR)
        return (cadence, cadence)

    step_ms, duration_ms = _expect_two_item_pair(cadence, _PULSE_CADENCE_ERROR)
    if type(step_ms) is not int or type(duration_ms) is not int:
        raise PykaraTypeError(_PULSE_CADENCE_ERROR)
    if step_ms <= 0 or duration_ms < 0:
        raise PykaraValidationError(_PULSE_CADENCE_ERROR)
    return (step_ms, duration_ms)


def parse_range(value: object) -> tuple[int, int]:
    """Parse one transition range into absolute millisecond bounds."""
    start_value, end_or_offset = _expect_two_item_pair(value, _RANGE_PAIR_ERROR)
    start_ms = _parse_time_value(start_value)
    if type(end_or_offset) is int:
        end_ms = start_ms + end_or_offset
    else:
        end_ms = _parse_time_value(end_or_offset)

    if end_ms < start_ms:
        raise PykaraValidationError(
            "timeline.transitions() ranges must satisfy end >= start"
        )
    return (start_ms, end_ms)


def _expect_two_item_pair(value: object, error_message: str) -> tuple[object, object]:
    if type(value) not in {tuple, list}:
        raise PykaraTypeError(error_message)

    item = tuple(cast(Sequence[object], value))
    if len(item) != 2:
        raise PykaraTypeError(error_message)
    return (item[0], item[1])


def _parse_time_value(value: object) -> int:
    if type(value) is int:
        return value
    if type(value) is str:
        if value.isdigit():
            return int(value)
        try:
            return parse_ass_time(value)
        except PykaraValidationError:
            match = _TIMELINE_HMS_RE.fullmatch(value)
            if match is None:
                raise PykaraTypeError(_TIME_VALUE_ERROR) from None

            fraction = match.group("fraction").ljust(3, "0")
            return (
                int(match.group("hours")) * 3_600_000
                + int(match.group("minutes")) * 60_000
                + int(match.group("seconds")) * 1_000
                + int(fraction)
            )
    raise PykaraTypeError(_TIME_VALUE_ERROR)


def _parse_values(value: object, tags: tuple[str, ...]) -> tuple[str, ...]:
    if len(tags) == 1:
        if type(value) is str:
            return (value,)
        if type(value) in {tuple, list}:
            values = tuple(cast(Sequence[object], value))
            if len(values) == 1 and type(values[0]) is str:
                return (values[0],)
        raise PykaraTypeError(
            "timeline.transitions() step values must be one string when one tag "
            "is provided"
        )

    if type(value) not in {tuple, list}:
        raise PykaraTypeError(
            "timeline.transitions() step values must match the tag count"
        )
    values = tuple(cast(Sequence[object], value))
    if len(values) != len(tags) or any(type(item) is not str for item in values):
        raise PykaraTypeError(
            "timeline.transitions() step values must match the tag count"
        )
    return cast(tuple[str, ...], values)
