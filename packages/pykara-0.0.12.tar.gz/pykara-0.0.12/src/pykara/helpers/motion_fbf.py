"""Frame-baked motion helpers."""

from __future__ import annotations

from pykara.helpers.motion_base import MotionBackend
from pykara.motion.arc.request import ArcFbfRequest
from pykara.motion.bezier.request import BezierFbfRequest
from pykara.motion.jitter.request import JitterFbfRequest
from pykara.motion.runtime.fbf.protocol import FbfRequest
from pykara.motion.runtime.runtime_geometry import motion_anchor
from pykara.motion.spring.request import SpringFbfRequest
from pykara.motion.wave.request import WaveFbfRequest


class FbfMotionHelper(MotionBackend):
    """Frame-baked motion helpers exposed as ``motion.fbf``."""

    backend_name = "fbf"

    def _queue_request(self, effect_name: str, request: FbfRequest) -> str:
        """Queue one frame-baked motion request."""
        runtime = self._require_fbf_runtime(effect_name)
        runtime.queue_fbf_request(request)
        return ""

    def jitter(
        self,
        left: int,
        right: int,
        up: int,
        down: int,
        period: int,
        seed: int = 0,
    ) -> str:
        """Queue one frame-baked jitter request for the current output line."""
        runtime = self._require_fbf_runtime("jitter")
        spec = self._validate_jitter_spec(
            "jitter",
            left,
            right,
            up,
            down,
            period,
            seed,
        )
        x, y = motion_anchor(runtime)
        runtime.queue_fbf_request(
            JitterFbfRequest(
                x=x,
                y=y,
                left=spec.left,
                right=spec.right,
                up=spec.up,
                down=spec.down,
                period=spec.period,
                seed=spec.seed,
            )
        )
        return ""

    def arc(
        self,
        x1: float,
        y1: float,
        x2: float,
        y2: float,
        a1: float = 0.0,
        a2: float = 360.0,
        r1: float = 100.0,
        r2: float = 100.0,
        t1: float | None = None,
        t2: float | None = None,
    ) -> str:
        """Queue one frame-baked arc request for the current output line."""
        return self._queue_request(
            "arc",
            ArcFbfRequest(
                x1=x1,
                y1=y1,
                x2=x2,
                y2=y2,
                a1=a1,
                a2=a2,
                r1=r1,
                r2=r2,
                t1=t1,
                t2=t2,
            ),
        )

    def bezier(
        self,
        *points: tuple[float, float],
        t1: float | None = None,
        t2: float | None = None,
    ) -> str:
        """Queue one frame-baked Bezier request for the current output line."""
        return self._queue_request(
            "bezier",
            BezierFbfRequest(points=tuple(points), t1=t1, t2=t2),
        )

    def spring(
        self,
        x0: float,
        y0: float,
        x1: float,
        y1: float,
        amplitude: float = 1.0,
        damping: float = 3.0,
        freq: float = 6.0,
        t1: float | None = None,
        t2: float | None = None,
    ) -> str:
        """Queue one frame-baked spring request for the current output line."""
        return self._queue_request(
            "spring",
            SpringFbfRequest(
                x0=x0,
                y0=y0,
                x1=x1,
                y1=y1,
                amplitude=amplitude,
                damping=damping,
                freq=freq,
                t1=t1,
                t2=t2,
            ),
        )

    def wave(
        self,
        x0: float,
        x1: float,
        y_base: float,
        amplitude: float = 150.0,
        frequency: float = 2.0,
        phase: float = 0.0,
        t1: float | None = None,
        t2: float | None = None,
    ) -> str:
        """Queue one frame-baked wave request for the current output line."""
        return self._queue_request(
            "wave",
            WaveFbfRequest(
                x0=x0,
                x1=x1,
                y_base=y_base,
                amplitude=amplitude,
                frequency=frequency,
                phase=phase,
                t1=t1,
                t2=t2,
            ),
        )
