"""Scale helper."""

from __future__ import annotations

from dataclasses import dataclass

from pykara.exceptions import PykaraTypeError, PykaraValidationError


def _validated_number(value: object, *, label: str) -> int | float:
    """Return ``value`` as one supported numeric type."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise PykaraTypeError(f"scale.{label} must be an int or float")
    return value


def _scaled_result(
    value: int | float,
    base: int | float,
    target: int | float,
) -> int | float:
    """Return one scaled numeric result, collapsing integral floats to ``int``."""
    result = value * target / base
    if isinstance(result, float) and result.is_integer():
        return int(result)
    return result


@dataclass(frozen=True, slots=True)
class _ScaledValue:
    """One numeric value prepared for fluent scale transforms.

    The wrapped numeric payload remains available via ``.value`` so callers
    can keep one named scaled helper without losing access to the original
    value.
    """

    value: int | float
    base_value: int | float | None = None

    def base(self, value: object) -> _ScaledValue:
        """Bind the source scale used by ``to(...)``."""
        base_value = _validated_number(value, label="of(...).base(...)")
        if base_value == 0:
            raise PykaraValidationError("scale.of(...).base(...) cannot use zero")
        return _ScaledValue(self.value, base_value)

    def to(self, value: object) -> int | float:
        """Scale the wrapped value from the configured base to ``value``."""
        target_value = _validated_number(value, label="of(...).base(...).to(...)")
        if self.base_value is None:
            raise PykaraValidationError(
                "scale.of(...).base(...) must be set before .to(...)"
            )
        return _scaled_result(self.value, self.base_value, target_value)


class ScaleHelper:
    """Numeric scaling helpers exposed as ``scale``."""

    def of(self, value: object) -> _ScaledValue:
        """Wrap one numeric value for fluent scale transforms."""
        return _ScaledValue(_validated_number(value, label="of(...)"))
