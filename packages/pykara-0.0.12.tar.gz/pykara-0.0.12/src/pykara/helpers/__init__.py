"""Runtime helper assembly for expression evaluation."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pykara.engine.expression_catalog import ExpressionHelpers
    from pykara.engine.protocols import HelpersRuntime


def build_runtime_helpers(
    runtime: HelpersRuntime,
) -> ExpressionHelpers:
    """Build the helper bindings visible to ``eval`` and ``exec``."""
    from pykara.engine.expression_catalog import HELPER_NAMES
    from pykara.helpers.color import ColorHelper
    from pykara.helpers.memory import MemoryHelper
    from pykara.helpers.motion import MotionHelper
    from pykara.helpers.palette import PaletteHelper
    from pykara.helpers.relayer import RelayerHelper
    from pykara.helpers.repeat import RepeatHelper
    from pykara.helpers.retime import RetimeHelper
    from pykara.helpers.scale import ScaleHelper
    from pykara.helpers.timeline import TimelineHelper

    helper_factories = {
        "color": lambda: ColorHelper(),
        "memory": lambda: MemoryHelper(runtime.memory_state),
        "motion": lambda: MotionHelper(runtime),
        "palette": lambda: PaletteHelper(),
        "relayer": lambda: RelayerHelper(runtime.set_output_layer),
        "repeat": lambda: RepeatHelper(
            repeat_binding=runtime.repeat_binding,
            single_repeat_binding=runtime.single_repeat_binding,
        ),
        "retime": lambda: RetimeHelper(runtime),
        "scale": lambda: ScaleHelper(),
        "timeline": lambda: TimelineHelper(
            line=runtime.line,
            output_interval=runtime.output_interval,
        ),
    }
    return {name: helper_factories[name]() for name in HELPER_NAMES}
