"""Typed structures for ASS documents."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

STYLE_FORMAT_FIELDS = [
    "Name",
    "Fontname",
    "Fontsize",
    "PrimaryColour",
    "SecondaryColour",
    "OutlineColour",
    "BackColour",
    "Bold",
    "Italic",
    "Underline",
    "StrikeOut",
    "ScaleX",
    "ScaleY",
    "Spacing",
    "Angle",
    "BorderStyle",
    "Outline",
    "Shadow",
    "Alignment",
    "MarginL",
    "MarginR",
    "MarginV",
    "Encoding",
]

EVENT_FORMAT_FIELDS = [
    "Layer",
    "Start",
    "End",
    "Style",
    "Name",
    "MarginL",
    "MarginR",
    "MarginV",
    "Effect",
    "Text",
]


def _default_section_order() -> list[str]:
    """Return the canonical default ASS section order."""
    return ["script_info", "styles", "events"]


def _default_style_format() -> list[str]:
    """Return the canonical ASS style-field order."""
    return list(STYLE_FORMAT_FIELDS)


def _default_event_format() -> list[str]:
    """Return the canonical ASS event-field order."""
    return list(EVENT_FORMAT_FIELDS)


class EventType(StrEnum):
    """Supported ASS event types."""

    COMMENT = "Comment"
    DIALOGUE = "Dialogue"


@dataclass(slots=True)
class ScriptInfo:
    """Ordered key/value pairs from ``[Script Info]``."""

    fields: list[tuple[str, str]] = field(default_factory=list[tuple[str, str]])


@dataclass(slots=True)
class RawSection:
    """A non-core ASS section preserved verbatim."""

    name: str
    lines: list[str] = field(default_factory=list[str])


@dataclass(slots=True)
class AssStyle:
    """A parsed ``Style:`` row from ``[V4+ Styles]``."""

    name: str
    fontname: str
    fontsize: float
    primary_colour: str
    secondary_colour: str
    outline_colour: str
    back_colour: str
    bold: bool
    italic: bool
    underline: bool
    strike_out: bool
    scale_x: float
    scale_y: float
    spacing: float
    angle: float
    border_style: int
    outline: float
    shadow: float
    alignment: int
    margin_l: int
    margin_r: int
    margin_v: int
    encoding: int


@dataclass(slots=True)
class DialogueLine:
    """A parsed event row from ``[Events]``."""

    event_type: EventType
    layer: int
    start_time: int
    end_time: int
    style: str
    name: str
    margin_l: int
    margin_r: int
    margin_v: int
    effect: str
    text: str


@dataclass(slots=True)
class AssDocument:
    """A parsed ASS document."""

    script_info: ScriptInfo = field(default_factory=ScriptInfo)
    styles: list[AssStyle] = field(default_factory=list[AssStyle])
    events: list[DialogueLine] = field(default_factory=list[DialogueLine])
    other_sections: list[RawSection] = field(default_factory=list[RawSection])
    section_order: list[str] = field(default_factory=_default_section_order)
    style_format: list[str] = field(default_factory=_default_style_format)
    event_format: list[str] = field(default_factory=_default_event_format)
