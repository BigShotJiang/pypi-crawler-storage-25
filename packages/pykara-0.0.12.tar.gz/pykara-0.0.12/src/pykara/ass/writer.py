"""ASS document writer."""

from __future__ import annotations

from pathlib import Path

from pykara.ass.time import format_ass_time
from pykara.ass.types import AssDocument, AssStyle, DialogueLine
from pykara.exceptions import PykaraValidationError


def _format_number(value: float) -> str:
    """Format a float without unnecessary trailing zeroes."""
    formatted = f"{value:.10f}".rstrip("0").rstrip(".")
    return formatted if formatted != "-0" else "0"


def _format_bool(value: bool) -> str:
    """Format a boolean using ASS-style numeric values."""
    return "-1" if value else "0"


def _style_field_values(style: AssStyle) -> dict[str, str]:
    """Return the formatted ASS style fields keyed by ASS column name."""
    return {
        "Name": style.name,
        "Fontname": style.fontname,
        "Fontsize": _format_number(style.fontsize),
        "PrimaryColour": style.primary_colour,
        "SecondaryColour": style.secondary_colour,
        "OutlineColour": style.outline_colour,
        "BackColour": style.back_colour,
        "Bold": _format_bool(style.bold),
        "Italic": _format_bool(style.italic),
        "Underline": _format_bool(style.underline),
        "StrikeOut": _format_bool(style.strike_out),
        "ScaleX": _format_number(style.scale_x),
        "ScaleY": _format_number(style.scale_y),
        "Spacing": _format_number(style.spacing),
        "Angle": _format_number(style.angle),
        "BorderStyle": str(style.border_style),
        "Outline": _format_number(style.outline),
        "Shadow": _format_number(style.shadow),
        "Alignment": str(style.alignment),
        "MarginL": str(style.margin_l),
        "MarginR": str(style.margin_r),
        "MarginV": str(style.margin_v),
        "Encoding": str(style.encoding),
    }


def _event_field_values(event: DialogueLine) -> dict[str, str]:
    """Return the formatted ASS event fields keyed by ASS column name."""
    return {
        "Layer": str(event.layer),
        "Start": format_ass_time(event.start_time),
        "End": format_ass_time(event.end_time),
        "Style": event.style,
        "Name": event.name,
        "MarginL": str(event.margin_l),
        "MarginR": str(event.margin_r),
        "MarginV": str(event.margin_v),
        "Effect": event.effect,
        "Text": event.text,
    }


def format_event_line(
    event: DialogueLine,
    event_format: list[str] | tuple[str, ...],
) -> str:
    """Return one serialized ASS event row."""
    field_values = _event_field_values(event)
    payload = ",".join(field_values[field_name] for field_name in event_format)
    return f"{event.event_type.value}: {payload}"


def _append_spacing(lines: list[str]) -> None:
    """Append a section separator when needed."""
    if lines and lines[-1] != "":
        lines.append("")


def write_ass(document: AssDocument, path: str | Path) -> None:
    """Write an ASS document to disk.

    Args:
        document: The ``AssDocument`` to serialise.
        path: Destination path for the ``.ass`` file.

    Raises:
        PykaraValidationError: ``document.section_order`` contains an unknown token.
        OSError: The output file cannot be written.
    """
    lines: list[str] = []

    for section_token in document.section_order:
        _append_spacing(lines)

        if section_token == "script_info":
            lines.append("[Script Info]")
            for key, value in document.script_info.fields:
                lines.append(f"{key}: {value}")
            continue

        if section_token == "styles":
            lines.append("[V4+ Styles]")
            lines.append(f"Format: {', '.join(document.style_format)}")
            for style in document.styles:
                field_values = _style_field_values(style)
                payload = ",".join(
                    field_values[field_name] for field_name in document.style_format
                )
                lines.append(f"Style: {payload}")
            continue

        if section_token == "events":
            lines.append("[Events]")
            lines.append(f"Format: {', '.join(document.event_format)}")
            lines.extend(
                format_event_line(event, document.event_format)
                for event in document.events
            )
            continue

        if not section_token.startswith("raw:"):
            raise PykaraValidationError(
                f"ass.write_ass(): Unknown section token: {section_token!r}"
            )

        raw_index = int(section_token.split(":", maxsplit=1)[1])
        raw_section = document.other_sections[raw_index]
        lines.append(f"[{raw_section.name}]")
        lines.extend(raw_section.lines)

    output = "\n".join(lines)
    if output:
        output += "\n"
    Path(path).write_text(output, encoding="utf-8-sig")
