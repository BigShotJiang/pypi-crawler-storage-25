"""Parse ASS documents from disk into typed Python models."""

from __future__ import annotations

from pathlib import Path

from pykara.ass.time import parse_ass_time
from pykara.ass.types import (
    EVENT_FORMAT_FIELDS,
    STYLE_FORMAT_FIELDS,
    AssDocument,
    AssStyle,
    DialogueLine,
    EventType,
    RawSection,
    ScriptInfo,
)
from pykara.exceptions import PykaraValidationError

_STYLE_FIELD_MAP = {
    "name": "Name",
    "fontname": "Fontname",
    "fontsize": "Fontsize",
    "primarycolour": "PrimaryColour",
    "secondarycolour": "SecondaryColour",
    "outlinecolour": "OutlineColour",
    "backcolour": "BackColour",
    "bold": "Bold",
    "italic": "Italic",
    "underline": "Underline",
    "strikeout": "StrikeOut",
    "scalex": "ScaleX",
    "scaley": "ScaleY",
    "spacing": "Spacing",
    "angle": "Angle",
    "borderstyle": "BorderStyle",
    "outline": "Outline",
    "shadow": "Shadow",
    "alignment": "Alignment",
    "marginl": "MarginL",
    "marginr": "MarginR",
    "marginv": "MarginV",
    "encoding": "Encoding",
}

_EVENT_FIELD_MAP = {
    "layer": "Layer",
    "start": "Start",
    "end": "End",
    "style": "Style",
    "name": "Name",
    "marginl": "MarginL",
    "marginr": "MarginR",
    "marginv": "MarginV",
    "effect": "Effect",
    "text": "Text",
}


def _split_csv_row(text: str, field_count: int) -> list[str]:
    """Split a CSV row while keeping the last field unsplit."""
    values: list[str] = []
    current_value: list[str] = []
    for char in text:
        if char == "," and len(values) + 1 < field_count:
            values.append("".join(current_value))
            current_value = []
        else:
            current_value.append(char)
    values.append("".join(current_value))
    return values


def _normalize_format_field(field_name: str) -> str:
    """Normalize one ASS format field name for canonical lookup."""
    return field_name.strip().lower().replace(" ", "")


def _parse_format_line(line: str) -> list[str]:
    """Parse one ``Format:`` line into ordered field names."""
    return [field.strip() for field in line[len("Format:") :].strip().split(",")]


def _map_row_fields(
    format_fields: list[str],
    raw_values: list[str],
    field_map: dict[str, str],
    *,
    preserve_text_field: bool = False,
) -> dict[str, str]:
    """Map one parsed row to canonical ASS field names."""
    mapped_fields: dict[str, str] = {}
    for field_name, raw_value in zip(format_fields, raw_values, strict=True):
        normalized_name = _normalize_format_field(field_name)
        if normalized_name not in field_map:
            continue
        mapped_fields[field_map[normalized_name]] = (
            raw_value
            if preserve_text_field and normalized_name == "text"
            else raw_value.strip()
        )
    return mapped_fields


def _parse_script_info(lines: list[str]) -> ScriptInfo:
    """Parse the contents of a ``[Script Info]`` section."""
    fields: list[tuple[str, str]] = []
    for raw_line in lines:
        stripped_line = raw_line.strip()
        if not stripped_line or stripped_line.startswith(";"):
            continue
        key, separator, value = raw_line.partition(":")
        if not separator:
            raise PykaraValidationError(
                f"ass.read_ass(): Invalid [Script Info] line: {raw_line!r}"
            )
        fields.append((key.strip(), value.strip()))
    return ScriptInfo(fields=fields)


def _parse_styles(lines: list[str]) -> tuple[list[AssStyle], list[str]]:
    """Parse the contents of a ``[V4+ Styles]`` section.

    Args:
        lines: Raw text lines from the ``[V4+ Styles]`` section body,
            excluding the section header.

    Returns:
        A tuple ``(styles, format_fields)`` where ``styles`` is the ordered
        list of parsed ``AssStyle`` objects and ``format_fields`` is the
        ordered list of ASS column names declared by the ``Format:`` line.
    """
    styles: list[AssStyle] = []
    format_fields: list[str] | None = None

    for raw_line in lines:
        stripped_line = raw_line.strip()
        if not stripped_line or stripped_line.startswith(";"):
            continue
        if stripped_line.startswith("Format:"):
            format_fields = _parse_format_line(stripped_line)
            continue
        if not stripped_line.startswith("Style:"):
            raise PykaraValidationError(
                f"ass.read_ass(): Unsupported [V4+ Styles] line: {raw_line!r}"
            )
        if format_fields is None:
            raise PykaraValidationError(
                "ass.read_ass(): Found Style line before Format line"
            )

        payload = stripped_line[len("Style:") :].strip()
        raw_values = _split_csv_row(payload, len(format_fields))
        if len(raw_values) != len(format_fields):
            raise PykaraValidationError(
                f"ass.read_ass(): Invalid Style line: {raw_line!r}"
            )

        mapped_fields = _map_row_fields(format_fields, raw_values, _STYLE_FIELD_MAP)
        missing_fields = [
            field_name
            for field_name in STYLE_FORMAT_FIELDS
            if field_name not in mapped_fields
        ]
        if missing_fields:
            raise PykaraValidationError(
                "ass.read_ass(): "
                f"Style line missing fields: {missing_fields!r}"
            )

        styles.append(
            AssStyle(
                name=mapped_fields["Name"],
                fontname=mapped_fields["Fontname"],
                fontsize=float(mapped_fields["Fontsize"]),
                primary_colour=mapped_fields["PrimaryColour"],
                secondary_colour=mapped_fields["SecondaryColour"],
                outline_colour=mapped_fields["OutlineColour"],
                back_colour=mapped_fields["BackColour"],
                bold=int(mapped_fields["Bold"]) != 0,
                italic=int(mapped_fields["Italic"]) != 0,
                underline=int(mapped_fields["Underline"]) != 0,
                strike_out=int(mapped_fields["StrikeOut"]) != 0,
                scale_x=float(mapped_fields["ScaleX"]),
                scale_y=float(mapped_fields["ScaleY"]),
                spacing=float(mapped_fields["Spacing"]),
                angle=float(mapped_fields["Angle"]),
                border_style=int(mapped_fields["BorderStyle"]),
                outline=float(mapped_fields["Outline"]),
                shadow=float(mapped_fields["Shadow"]),
                alignment=int(mapped_fields["Alignment"]),
                margin_l=int(mapped_fields["MarginL"]),
                margin_r=int(mapped_fields["MarginR"]),
                margin_v=int(mapped_fields["MarginV"]),
                encoding=int(mapped_fields["Encoding"]),
            )
        )

    return styles, format_fields or list(STYLE_FORMAT_FIELDS)


def _parse_events(lines: list[str]) -> tuple[list[DialogueLine], list[str]]:
    """Parse the contents of an ``[Events]`` section.

    Args:
        lines: Raw text lines from the ``[Events]`` section body,
            excluding the section header.

    Returns:
        A tuple ``(events, format_fields)`` where ``events`` is the ordered
        list of parsed ``DialogueLine`` objects and ``format_fields`` is the
        ordered list of ASS column names declared by the ``Format:`` line.
    """
    events: list[DialogueLine] = []
    format_fields: list[str] | None = None

    for raw_line in lines:
        stripped_line = raw_line.strip()
        if not stripped_line or stripped_line.startswith(";"):
            continue
        if stripped_line.startswith("Format:"):
            format_fields = _parse_format_line(stripped_line)
            continue

        event_type_name, separator, payload = raw_line.partition(":")
        if not separator:
            raise PykaraValidationError(
                f"ass.read_ass(): Invalid [Events] line: {raw_line!r}"
            )
        if event_type_name not in {EventType.COMMENT.value, EventType.DIALOGUE.value}:
            raise PykaraValidationError(
                f"ass.read_ass(): Unsupported event type: {event_type_name!r}"
            )
        if format_fields is None:
            raise PykaraValidationError(
                "ass.read_ass(): Found event line before Format line"
            )

        raw_values = _split_csv_row(payload.lstrip(), len(format_fields))
        if len(raw_values) != len(format_fields):
            raise PykaraValidationError(
                f"ass.read_ass(): Invalid event line: {raw_line!r}"
            )

        mapped_fields = _map_row_fields(
            format_fields,
            raw_values,
            _EVENT_FIELD_MAP,
            preserve_text_field=True,
        )
        missing_fields = [
            field_name
            for field_name in EVENT_FORMAT_FIELDS
            if field_name not in mapped_fields
        ]
        if missing_fields:
            raise PykaraValidationError(
                "ass.read_ass(): "
                f"Event line missing fields: {missing_fields!r}"
            )

        events.append(
            DialogueLine(
                event_type=EventType(event_type_name),
                layer=int(mapped_fields["Layer"]),
                start_time=parse_ass_time(mapped_fields["Start"]),
                end_time=parse_ass_time(mapped_fields["End"]),
                style=mapped_fields["Style"],
                name=mapped_fields["Name"],
                margin_l=int(mapped_fields["MarginL"]),
                margin_r=int(mapped_fields["MarginR"]),
                margin_v=int(mapped_fields["MarginV"]),
                effect=mapped_fields["Effect"],
                text=mapped_fields["Text"],
            )
        )

    return events, format_fields or list(EVENT_FORMAT_FIELDS)


def read_ass(path: str | Path) -> AssDocument:
    """Read one ASS document from disk.

    Args:
        path: Path to the ``.ass`` file to read.

    Returns:
        The fully parsed ``AssDocument``.

    Raises:
        PykaraValidationError: A section line is malformed or a required field is
            missing.
        OSError: The file cannot be opened or read.
    """
    raw_lines = Path(path).read_text(encoding="utf-8-sig").splitlines()

    script_info = ScriptInfo()
    styles: list[AssStyle] = []
    events: list[DialogueLine] = []
    other_sections: list[RawSection] = []
    section_order: list[str] = []
    style_format = list(STYLE_FORMAT_FIELDS)
    event_format = list(EVENT_FORMAT_FIELDS)

    current_section_name: str | None = None
    current_section_lines: list[str] = []

    def flush_current_section() -> None:
        nonlocal event_format, events, script_info, style_format, styles

        if current_section_name is None:
            return
        if current_section_name == "Script Info":
            script_info = _parse_script_info(current_section_lines)
            section_order.append("script_info")
            return
        if current_section_name == "V4+ Styles":
            styles, style_format = _parse_styles(current_section_lines)
            section_order.append("styles")
            return
        if current_section_name == "Events":
            events, event_format = _parse_events(current_section_lines)
            section_order.append("events")
            return

        other_sections.append(
            RawSection(name=current_section_name, lines=list(current_section_lines))
        )
        section_order.append(f"raw:{len(other_sections) - 1}")

    for raw_line in raw_lines:
        stripped_line = raw_line.strip()
        if stripped_line.startswith("[") and stripped_line.endswith("]"):
            flush_current_section()
            current_section_name = stripped_line[1:-1]
            current_section_lines = []
            continue
        current_section_lines.append(raw_line)

    flush_current_section()

    if not section_order:
        section_order = ["script_info", "styles", "events"]

    return AssDocument(
        script_info=script_info,
        styles=styles,
        events=events,
        other_sections=other_sections,
        section_order=section_order,
        style_format=style_format,
        event_format=event_format,
    )
