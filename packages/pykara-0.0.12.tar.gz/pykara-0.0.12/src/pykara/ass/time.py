"""ASS time parsing and formatting utilities."""

from __future__ import annotations

import re

from pykara.exceptions import PykaraValidationError

_ASS_TIME_RE = re.compile(
    r"^(?P<hours>\d+):(?P<minutes>\d{1,2}):"
    r"(?P<seconds>\d{1,2})\.(?P<cs>\d{2})$"
)


def _invalid_ass_time(text: str) -> PykaraValidationError:
    """Return the canonical ASS-time validation error.

    Args:
        text: The raw timestamp string that failed validation.

    Returns:
        A ``PykaraValidationError`` describing the invalid timestamp.
    """
    return PykaraValidationError(f"ass.parse_ass_time(): Invalid ASS time: {text!r}")


def parse_ass_time(text: str) -> int:
    """Parse an ASS timestamp into milliseconds.

    Args:
        text: Timestamp in ``H:MM:SS.cc`` format.

    Returns:
        The timestamp in milliseconds.

    Raises:
        PykaraValidationError: The timestamp is malformed or out of range.
    """
    match = _ASS_TIME_RE.fullmatch(text)
    if match is None:
        raise _invalid_ass_time(text)

    hours = int(match.group("hours"))
    minutes = int(match.group("minutes"))
    seconds = int(match.group("seconds"))
    centiseconds = int(match.group("cs"))

    if minutes >= 60 or seconds >= 60:
        raise _invalid_ass_time(text)

    return (((hours * 60) + minutes) * 60 + seconds) * 1000 + centiseconds * 10


def format_ass_time(milliseconds: int) -> str:
    """Format milliseconds as an ASS timestamp.

    Values are rounded to the nearest centisecond because ASS timestamps only
    store centiseconds.

    Args:
        milliseconds: Time in milliseconds.

    Returns:
        The timestamp in ``H:MM:SS.cc`` format.

    Raises:
        PykaraValidationError: ``milliseconds`` is negative.
    """
    if milliseconds < 0:
        raise PykaraValidationError(
            "ass.format_ass_time(): ASS timestamps cannot be negative"
        )

    total_centiseconds = (milliseconds + 5) // 10
    total_seconds, centiseconds = divmod(total_centiseconds, 100)
    total_minutes, seconds = divmod(total_seconds, 60)
    hours, minutes = divmod(total_minutes, 60)
    return f"{hours}:{minutes:02d}:{seconds:02d}.{centiseconds:02d}"
