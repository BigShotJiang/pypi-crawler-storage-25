"""Expression context assembly and persistence."""

from __future__ import annotations

from pykara.engine.expression_catalog import (
    EXPRESSION_BINDINGS_BY_SCOPE,
    EXPRESSION_OBJECT_BINDINGS_BY_SCOPE,
    RESERVED_EXPRESSION_NAMES,
    SCRIPT_BINDING_NAME,
)
from pykara.engine.expression_proxies import (
    persist_expression_value,
    resolve_deferred_code_functions,
    wrap_expression_value,
)
from pykara.engine.protocols import ContextAccess, HelpersRuntime
from pykara.engine.scope_registry import SCOPE_REGISTRY
from pykara.helpers import build_runtime_helpers


def visible_scope_states(context_access: ContextAccess) -> list[dict[str, object]]:
    """Return the visible scope-state chain for the current scope."""
    return [
        getattr(context_access, attr)
        for attr in SCOPE_REGISTRY[context_access.scope].visible_state_attrs
    ]


def local_scope_state(context_access: ContextAccess) -> dict[str, object]:
    """Return the state dict owned by the current scope."""
    return getattr(
        context_access,
        SCOPE_REGISTRY[context_access.scope].local_state_attr,
    )


def build_expression_context(runtime: HelpersRuntime) -> dict[str, object]:
    """Build the context dict visible to ``eval`` and ``exec``."""
    context: dict[str, object] = {}
    expression_proxy_cache: dict[int, object] = {}
    visible_bindings = EXPRESSION_BINDINGS_BY_SCOPE[runtime.scope]
    for state in visible_scope_states(runtime):
        context.update(state)
    context.update(build_runtime_helpers(runtime))
    if SCRIPT_BINDING_NAME in visible_bindings and runtime.script is not None:
        context[SCRIPT_BINDING_NAME] = runtime.script
    object_values = runtime.object_binding_values()
    for binding_name in EXPRESSION_OBJECT_BINDINGS_BY_SCOPE[runtime.scope]:
        binding_value = object_values[binding_name]
        if binding_value is None:
            continue
        context[binding_name] = wrap_expression_value(
            binding_value, expression_proxy_cache
        )
    resolve_deferred_code_functions(context)
    return context


def persist_expression_state(
    context_access: ContextAccess, context: dict[str, object]
) -> None:
    """Persist code-defined names back onto the current scope state."""
    current_state = local_scope_state(context_access)
    current_state.clear()
    for name, value in context.items():
        if name in RESERVED_EXPRESSION_NAMES or name.startswith("__"):
            continue
        current_state[name] = persist_expression_value(value)
