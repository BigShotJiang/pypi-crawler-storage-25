"""Collect and cross-validate directives declared on ASS comment lines."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, TypeVar

from pykara.ass.types import AssDocument, DialogueLine, EventType
from pykara.directive.parser import parse_directive
from pykara.directive.types import (
    CodeDirective,
    ForMod,
    LayerMod,
    PatchDirective,
    TemplateDirective,
    find_modifier,
)
from pykara.directive.validator import validate_directive
from pykara.exceptions import PykaraValidationError

_D = TypeVar("_D", TemplateDirective, CodeDirective, PatchDirective)


@dataclass(frozen=True, slots=True)
class Collected(Generic[_D]):
    """One directive plus the comment event it came from."""

    style: str
    directive: _D
    body: str
    source_event: DialogueLine


CollectedTemplate = Collected[TemplateDirective]
CollectedCode = Collected[CodeDirective]
CollectedPatch = Collected[PatchDirective]


def patch_layer_matches(directive: PatchDirective, effective_layer: int) -> bool:
    """Return whether ``directive`` passes the layer filter for ``effective_layer``.

    Args:
        directive: The patch directive to test.
        effective_layer: The output layer for the current template iteration.

    Returns:
        ``True`` when the directive carries no ``layer`` modifier, or when
        its layer value matches ``effective_layer``.
    """
    mod = find_modifier(directive, LayerMod)
    return mod is None or mod.layer == effective_layer


def _patch_target_actor(directive: PatchDirective) -> str | None:
    """Return the optional template-actor selector declared on ``directive``."""
    mod = find_modifier(directive, ForMod)
    return mod.name if mod is not None else None


def patch_targets_template(
    patch: CollectedPatch,
    template: CollectedTemplate,
) -> bool:
    """Return whether one collected patch applies to one template declaration.

    Args:
        patch: The collected patch directive to test.
        template: The collected template directive to test against.

    Returns:
        ``True`` when the patch matches the template by style, scope, and any
        optional ``for`` selector declared on the patch. The ``layer``
        modifier is not evaluated here — it is resolved per-iteration in the
        runner against the effective output layer.
    """
    if patch.style != template.style:
        return False
    if patch.directive.scope is not template.directive.scope:
        return False

    target_actor = _patch_target_actor(patch.directive)
    return not (target_actor is not None and template.source_event.name != target_actor)


def _validate_patch_targets(
    templates: list[CollectedTemplate],
    patches: list[CollectedPatch],
) -> None:
    """Ensure every collected patch matches at least one template declaration.

    Args:
        templates: All template directives collected from the document.
        patches: All patch directives collected from the document.

    Raises:
        PykaraValidationError: A patch directive does not match any template directive.
    """
    for patch in patches:
        if any(patch_targets_template(patch, template) for template in templates):
            continue
        raise PykaraValidationError(
            "collect_directives(): "
            f"Patch directive does not match any template: {patch.source_event.effect}"
        )


def collect_directives(
    document: AssDocument,
) -> tuple[list[CollectedTemplate], list[CollectedCode], list[CollectedPatch]]:
    """Collect validated directives declared on comment events.

    Args:
        document: The parsed ASS document to scan for directives.

    Returns:
        A triple ``(templates, code_blocks, patches)`` where each element is
        a list of collected directives in document order.

    Raises:
        PykaraValidationError: A directive is syntactically invalid, fails
            validation, or a patch directive does not match any template.
    """
    templates: list[CollectedTemplate] = []
    code_blocks: list[CollectedCode] = []
    patches: list[CollectedPatch] = []

    for event in document.events:
        if event.event_type is not EventType.COMMENT:
            continue

        parsed_directive = parse_directive(event.effect)
        if parsed_directive is None:
            continue
        validate_directive(parsed_directive)

        if isinstance(parsed_directive, TemplateDirective):
            templates.append(
                CollectedTemplate(
                    style=event.style,
                    directive=parsed_directive,
                    body=event.text,
                    source_event=event,
                )
            )
        elif isinstance(parsed_directive, PatchDirective):
            patches.append(
                CollectedPatch(
                    style=event.style,
                    directive=parsed_directive,
                    body=event.text,
                    source_event=event,
                )
            )
        else:
            code_blocks.append(
                CollectedCode(
                    style=event.style,
                    directive=parsed_directive,
                    body=event.text,
                    source_event=event,
                )
            )

    _validate_patch_targets(templates, patches)

    return templates, code_blocks, patches
