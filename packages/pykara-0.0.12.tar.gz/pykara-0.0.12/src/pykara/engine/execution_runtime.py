"""Execution runtime for code and template evaluation."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING

from pykara.directive.types import Scope
from pykara.engine.expression_catalog import EXPRESSION_OBJECT_BINDING_NAMES
from pykara.engine.fbf_slot import FbfRequestSlot
from pykara.engine.retime_state import RetimeState, RetimeTargetName
from pykara.engine.rng import RngManager
from pykara.engine.runtime_execution import evaluate as _evaluate
from pykara.engine.runtime_execution import run_code as _run_code
from pykara.engine.variable_resolver import resolve_variable as _resolve_variable
from pykara.exceptions import PykaraValidationError
from pykara.karaoke.char import Char
from pykara.karaoke.line import Line
from pykara.karaoke.syllable import Highlight, Syllable
from pykara.karaoke.word import Word
from pykara.timing import Framerate

if TYPE_CHECKING:
    from pykara.motion.runtime.fbf.protocol import FbfRequest


def _clone_highlight_syllable(source: Syllable, highlight: Highlight) -> Syllable:
    """Return a syllable view rewritten to one highlight interval."""
    return replace(
        source,
        start_time=highlight.start_time,
        end_time=highlight.end_time,
        duration=highlight.duration,
        kdur=highlight.duration // 10,
    )


@dataclass(frozen=True, slots=True)
class RepeatBinding:
    """One resolved repeat-loop state for the current template iteration."""

    name: str | None
    index: int
    count: int

    @property
    def key(self) -> str:
        """Return the canonical loop key used by variables and helpers."""
        return "i" if self.name is None else self.name


@dataclass(slots=True)
class ExecutionRuntime:
    """Current runtime state for one code/template evaluation."""

    scope: Scope
    line_index: int = 0
    line: Line | None = None
    word: Word | None = None
    syl: Syllable | None = None
    char: Char | None = None
    script: object | None = None
    framerate: Framerate | float | None = None
    rng_manager: RngManager = field(default_factory=RngManager)
    setup_state: dict[str, object] = field(default_factory=dict[str, object])
    line_state: dict[str, object] = field(default_factory=dict[str, object])
    word_state: dict[str, object] = field(default_factory=dict[str, object])
    syl_state: dict[str, object] = field(default_factory=dict[str, object])
    char_state: dict[str, object] = field(default_factory=dict[str, object])
    memory_state: dict[str, object] = field(default_factory=dict[str, object])
    repeat_loops: tuple[RepeatBinding, ...] = ()
    _retime: RetimeState = field(default_factory=RetimeState, init=False, repr=False)
    _output_layer: int | None = field(default=None, init=False, repr=False)
    _fbf_slot: FbfRequestSlot = field(
        default_factory=FbfRequestSlot,
        init=False,
        repr=False,
    )

    def _copy(
        self,
        *,
        syl: Syllable | None = None,
        repeat_loops: tuple[RepeatBinding, ...] | None = None,
    ) -> ExecutionRuntime:
        """Clone the runtime, optionally overriding syl and/or repeat_loops."""
        return ExecutionRuntime(
            scope=self.scope,
            line_index=self.line_index,
            line=self.line,
            word=self.word,
            syl=syl if syl is not None else self.syl,
            char=self.char,
            script=self.script,
            framerate=self.framerate,
            rng_manager=self.rng_manager,
            setup_state=self.setup_state,
            line_state=self.line_state,
            word_state=self.word_state,
            syl_state=self.syl_state,
            char_state=self.char_state,
            memory_state=self.memory_state,
            repeat_loops=(
                repeat_loops if repeat_loops is not None else self.repeat_loops
            ),
        )

    def copy_for_repeat(
        self,
        repeat_loops: tuple[RepeatBinding, ...],
    ) -> ExecutionRuntime:
        """Clone the runtime while overriding the repeat-loop state."""
        return self._copy(repeat_loops=repeat_loops)

    def copy_for_highlight(self, highlight: Highlight) -> ExecutionRuntime:
        """Clone the runtime with a highlight-specific syllable timing window."""
        if self.syl is None:
            raise PykaraValidationError(
                "runtime.copy_for_highlight(): "
                "Highlight copies require syllable runtime"
            )
        return self._copy(syl=_clone_highlight_syllable(self.syl, highlight))

    def queue_fbf_request(self, request: FbfRequest) -> None:
        """Store one pending frame-baked request for this evaluation."""
        self._fbf_slot.queue(request)

    def consume_fbf_request(self) -> FbfRequest | None:
        """Return and clear the pending frame-baked request."""
        return self._fbf_slot.consume()

    def current_text(self) -> str:
        """Return the scope-local text that template output appends by default."""
        if self.char is not None:
            return self.char.text
        if self.word is not None:
            return self.word.text
        if self.syl is not None:
            return self.syl.text
        if self.line is None:
            return ""
        if self.line.syls:
            return "".join(syllable.text for syllable in self.line.syls)
        if self.line.chars:
            return "".join(char.text for char in self.line.chars)
        return ""

    def repeat_binding(self, name: str) -> RepeatBinding | None:
        """Return the repeat binding identified by ``name``."""
        for binding in self.repeat_loops:
            if binding.key == name:
                return binding
        return None

    def single_repeat_binding(self) -> RepeatBinding | None:
        """Return the unique repeat binding when exactly one loop exists."""
        if len(self.repeat_loops) != 1:
            return None
        return self.repeat_loops[0]

    def object_binding_values(self) -> dict[str, object | None]:
        """Return the current runtime objects keyed by their public binding names."""
        return {
            binding_name: getattr(self, binding_name)
            for binding_name in EXPRESSION_OBJECT_BINDING_NAMES
        }

    def run_code(self, code: str) -> None:
        """Execute code and persist its resulting names for this scope."""
        _run_code(self, code)

    def evaluate(self, expression: str) -> object:
        """Evaluate an expression in the current context."""
        return _evaluate(self, expression)

    def resolve_variable(self, raw_name: str) -> object:
        """Resolve one ``$variable`` according to the current scope boundaries.

        Delegates to :func:`pykara.engine.variable_resolver.resolve_variable`.
        """
        return _resolve_variable(self, raw_name)

    def set_output_layer(self, layer: int) -> None:
        """Override the output layer for the current template pass."""
        self._output_layer = layer

    def output_layer(self, default: int) -> int:
        """Return the output layer, falling back to ``default`` when unset."""
        return self._output_layer if self._output_layer is not None else default

    def apply_retime_target(
        self,
        target: RetimeTargetName,
        start_offset: int,
        end_offset: int,
    ) -> None:
        """Apply one explicit retime target to the output interval."""
        self._retime.apply(
            target,
            start_offset,
            end_offset,
            scope=self.scope,
            line=self.line,
            syl=self.syl,
        )

    def output_interval(self) -> tuple[int, int]:
        """Return the relative output interval for the current template."""
        return self._retime.output_interval(self.line)
