"""Frame-by-frame motion request slot."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from pykara.exceptions import PykaraValidationError

if TYPE_CHECKING:
    from pykara.motion.runtime.fbf.protocol import FbfRequest


@dataclass(slots=True)
class FbfRequestSlot:
    """A slot for holding a single pending frame-baked motion request."""

    _pending_request: FbfRequest | None = None

    def queue(self, request: FbfRequest) -> None:
        """Store one pending frame-baked request."""
        if self._pending_request is not None:
            raise PykaraValidationError(
                "runtime.queue_fbf_request(): "
                "Only one frame-baked motion request is currently supported "
                "per template pass"
            )
        self._pending_request = request

    def consume(self) -> FbfRequest | None:
        """Return and clear the pending frame-baked request."""
        request = self._pending_request
        self._pending_request = None
        return request
