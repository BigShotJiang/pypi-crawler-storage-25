"""Main orchestration for directive execution and FX line emission."""

from __future__ import annotations

from dataclasses import dataclass

from pykara.ass.types import AssDocument, DialogueLine, EventType
from pykara.directive.types import Scope
from pykara.engine.collector import (
    CollectedCode,
    CollectedPatch,
    CollectedTemplate,
    collect_directives,
    patch_layer_matches,
    patch_targets_template,
)
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.engine.interpolator import interpolate
from pykara.engine.line_runtime_factory import LineRuntimeFactory
from pykara.engine.loop import (
    append_scope_text,
    expand_highlight_runtimes,
    expand_repeat_bindings,
    should_skip,
)
from pykara.engine.protocols import TemplateRuntime
from pykara.engine.rng import RngManager
from pykara.karaoke.parser import parse_karaoke
from pykara.layout import LayoutStyle, populate_positions, script_from_document
from pykara.timing import resolve_framerate

_KARAOKE_EFFECT = "karaoke"


@dataclass(frozen=True, slots=True)
class RunOptions:
    """Configurable runtime options."""

    seed: int = 42


def _normalized_effect(event: DialogueLine) -> str:
    """Return the normalized effect token stored on one event."""
    return event.effect.strip().lower()


def _is_karaoke_source_event(event: DialogueLine) -> bool:
    """Return whether one event should be treated as karaoke source input."""
    return (
        event.event_type in {EventType.DIALOGUE, EventType.COMMENT}
        and _normalized_effect(event) == _KARAOKE_EFFECT
    )


def _matching_templates(
    templates: list[CollectedTemplate],
    style: str,
    scope: Scope,
) -> list[CollectedTemplate]:
    """Return templates that target one style and scope pair."""
    return [
        template
        for template in templates
        if template.style == style and template.directive.scope is scope
    ]


def _matching_codes(
    code_blocks: list[CollectedCode],
    style: str,
    scope: Scope,
) -> list[CollectedCode]:
    """Return code blocks that target one style and scope pair."""
    if scope is Scope.SETUP:
        return [code for code in code_blocks if code.directive.scope is scope]
    return [
        code
        for code in code_blocks
        if code.directive.scope is scope and code.style == style
    ]


def _matching_patches_for_template(
    patch_directives: list[CollectedPatch],
    template: CollectedTemplate,
) -> list[CollectedPatch]:
    """Return the patches that apply to one active template declaration."""
    return [
        patch for patch in patch_directives if patch_targets_template(patch, template)
    ]


def _render_patch_output(
    patch_directives: list[CollectedPatch],
    runtime: TemplateRuntime,
    effective_layer: int,
) -> str:
    """Render the patch text injected into one rendered template pass."""
    rendered_fragments: list[str] = []
    for patch in patch_directives:
        if not patch_layer_matches(patch.directive, effective_layer):
            continue
        if should_skip(patch.directive, runtime):
            continue
        rendered_fragments.append(interpolate(patch.body, runtime))
    return "".join(rendered_fragments)


def _expand_fbf_motion(
    line: DialogueLine,
    runtime: TemplateRuntime,
) -> list[DialogueLine]:
    """Expand one rendered line when a frame-baked motion request is pending."""
    pending_request = runtime.consume_fbf_request()
    if pending_request is None:
        return [line]
    assert runtime.framerate is not None
    return pending_request.expand(line, runtime.framerate)


def _render_template(
    source_event: DialogueLine,
    template: CollectedTemplate,
    runtime: ExecutionRuntime,
    patch_directives: list[CollectedPatch],
) -> list[DialogueLine]:
    """Render one template against the current execution runtime."""
    generated_lines: list[DialogueLine] = []
    for highlight_runtime in expand_highlight_runtimes(template.directive, runtime):
        if should_skip(template.directive, highlight_runtime):
            continue

        for repeat_bindings in expand_repeat_bindings(template.directive):
            repeated_runtime = highlight_runtime.copy_for_repeat(repeat_bindings)
            rendered_text = interpolate(template.body, repeated_runtime)
            effective_layer = repeated_runtime.output_layer(template.source_event.layer)
            injected_patch_text = _render_patch_output(
                patch_directives, repeated_runtime, effective_layer
            )
            if append_scope_text(template.directive):
                rendered_text += injected_patch_text + repeated_runtime.current_text()
            else:
                rendered_text += injected_patch_text

            start_offset, end_offset = repeated_runtime.output_interval()
            generated_line = DialogueLine(
                event_type=EventType.DIALOGUE,
                layer=effective_layer,
                start_time=source_event.start_time + start_offset,
                end_time=source_event.start_time + end_offset,
                style=source_event.style,
                name=source_event.name,
                margin_l=source_event.margin_l,
                margin_r=source_event.margin_r,
                margin_v=source_event.margin_v,
                effect="fx",
                text=rendered_text,
            )
            generated_lines.extend(_expand_fbf_motion(generated_line, repeated_runtime))
    return generated_lines


def _render_scope_outputs(
    source_event: DialogueLine,
    style: str,
    scope: Scope,
    runtimes: list[ExecutionRuntime],
    templates: list[CollectedTemplate],
    code_blocks: list[CollectedCode],
    patch_directives: list[CollectedPatch],
) -> list[DialogueLine]:
    """Run all code and templates for one scope over the provided runtimes."""
    scope_outputs: list[DialogueLine] = []
    scope_codes = _matching_codes(code_blocks, style, scope)
    scope_templates = _matching_templates(templates, style, scope)

    for runtime in runtimes:
        for code in scope_codes:
            runtime.run_code(code.body)
        for template in scope_templates:
            scope_outputs.extend(
                _render_template(
                    source_event,
                    template,
                    runtime,
                    _matching_patches_for_template(patch_directives, template),
                )
            )

    return scope_outputs


def run(document: AssDocument, opts: RunOptions | None = None) -> list[DialogueLine]:
    """Run the templater and return the generated FX dialogue lines.

    Args:
        document: The parsed ASS document containing karaoke source events
            and comment-line directive declarations.
        opts: Optional runtime options; defaults to ``RunOptions()`` when
            ``None``.

    Returns:
        Ordered list of generated ``DialogueLine`` objects (effect ``"fx"``)
        ready to be appended to the output document.

    Raises:
        PykaraValidationError: A directive is invalid or a patch has no matching
            template.
        PykaraError: Template evaluation may propagate any library-specific error
            raised by helpers or runtime validation.
    """
    options = opts or RunOptions()
    templates, code_blocks, patch_directives = collect_directives(document)
    generated_lines: list[DialogueLine] = []
    style_lookup = {
        style.name: LayoutStyle.from_parsed(style) for style in document.styles
    }
    script = script_from_document(document)
    resolved_framerate = resolve_framerate(document)
    rng_manager = RngManager(seed=options.seed)

    setup_state: dict[str, object] = {}
    memory_state: dict[str, object] = {}

    setup_runtime = ExecutionRuntime(
        scope=Scope.SETUP,
        framerate=resolved_framerate,
        rng_manager=rng_manager,
        setup_state=setup_state,
        memory_state=memory_state,
    )
    for code in _matching_codes(code_blocks, "", Scope.SETUP):
        setup_runtime.run_code(code.body)

    line_index = 0
    for event in document.events:
        if not _is_karaoke_source_event(event):
            continue

        line_index += 1
        line = parse_karaoke(event)
        line_style = style_lookup.get(event.style, LayoutStyle.default(event.style))
        line.style = line_style
        populate_positions(line, line_style, script)
        line_runtime_factory = LineRuntimeFactory(
            line=line,
            line_index=line_index,
            script=script,
            framerate=resolved_framerate,
            rng_manager=rng_manager,
            setup_state=setup_state,
            memory_state=memory_state,
        )

        scope_runtimes: list[tuple[Scope, list[ExecutionRuntime]]] = [
            (Scope.LINE, [line_runtime_factory.make_runtime(Scope.LINE)]),
            (
                Scope.WORD,
                [
                    line_runtime_factory.make_runtime(Scope.WORD, word=word)
                    for word in line.words
                ],
            ),
            (
                Scope.SYL,
                [
                    line_runtime_factory.make_runtime(Scope.SYL, syl=syl)
                    for syl in line.syls
                ],
            ),
            (
                Scope.CHAR,
                [
                    line_runtime_factory.make_runtime(
                        Scope.CHAR,
                        word=char.word,
                        char=char,
                    )
                    for char in line.chars
                ],
            ),
        ]
        for scope, runtimes in scope_runtimes:
            generated_lines.extend(
                _render_scope_outputs(
                    event,
                    event.style,
                    scope,
                    runtimes,
                    templates,
                    code_blocks,
                    patch_directives,
                )
            )

    return generated_lines
