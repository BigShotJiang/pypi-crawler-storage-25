"""Template body interpolation."""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import TypeAlias

from pykara.engine.protocols import InterpolationRuntime
from pykara.exceptions import PykaraValidationError

_VARIABLE_RE = re.compile(r"\$([A-Za-z_][A-Za-z0-9_]*)", re.IGNORECASE)
Segment: TypeAlias = tuple[bool, str]


def _replace_variables(
    segment: str,
    runtime: InterpolationRuntime,
    *,
    render: Callable[[object], str],
) -> str:
    """Replace ``$variables`` in one segment using ``render`` for values."""

    def replacer(match: re.Match[str]) -> str:
        return render(runtime.resolve_variable(match.group(1)))

    return _VARIABLE_RE.sub(replacer, segment)


def _replace_variables_in_segment(
    segment: str, runtime: InterpolationRuntime
) -> str:
    """Replace ``$variables`` in one plain-text segment."""
    return _replace_variables(segment, runtime, render=str)


def _replace_variables_in_expression(
    expression: str, runtime: InterpolationRuntime
) -> str:
    """Replace ``$variables`` in one expression segment with Python literals."""
    return _replace_variables(expression, runtime, render=repr)


def _split_expression_segments(text: str) -> list[Segment]:
    """Split ``text`` into ``(is_expression, payload)`` segments."""
    segments: list[Segment] = []
    current: list[str] = []
    in_expression = False

    for char in text:
        if char != "!":
            current.append(char)
            continue
        segments.append((in_expression, "".join(current)))
        current = []
        in_expression = not in_expression

    if in_expression:
        raise PykaraValidationError("interpolate(): Unterminated !expression! segment")

    segments.append((False, "".join(current)))
    return segments


def interpolate(body: str, runtime: InterpolationRuntime) -> str:
    """Interpolate a template body using ``$variables`` then ``!expression!``.

    Args:
        body: Raw template text that may contain ``$var`` references and
            ``!expression!`` expression blocks.
        runtime: The execution runtime used to resolve variables and evaluate
            expressions.

    Returns:
        The fully interpolated string with all variables and expressions
        replaced by their computed string values.

    Raises:
        PykaraValidationError: An ``!expression!`` block is unterminated, or a
            ``$variable`` reference is invalid for the current scope.
    """
    rendered: list[str] = []
    for is_expression, payload in _split_expression_segments(body):
        if not is_expression:
            rendered.append(_replace_variables_in_segment(payload, runtime))
            continue

        value = runtime.evaluate(_replace_variables_in_expression(payload, runtime))
        rendered.append("" if value is None else str(value))

    return "".join(rendered)
