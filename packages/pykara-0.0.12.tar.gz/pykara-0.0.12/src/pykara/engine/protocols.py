"""Segregated interfaces for execution runtimes and helper capabilities."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from pykara.directive.types import Scope
    from pykara.engine.retime_state import RetimeTargetName
    from pykara.engine.rng import RngManager
    from pykara.karaoke.char import Char
    from pykara.karaoke.line import Line
    from pykara.karaoke.syllable import Highlight, Syllable
    from pykara.karaoke.word import Word
    from pykara.motion.runtime.fbf.protocol import FbfRequest
    from pykara.timing import Framerate


class RepeatBindingLike(Protocol):
    """One resolved repeat-loop binding visible to helper APIs."""

    @property
    def name(self) -> str | None:
        """Return the binding name, or ``None`` for the unnamed loop."""
        ...

    @property
    def index(self) -> int:
        """Return the current iteration index."""
        ...

    @property
    def count(self) -> int:
        """Return the total iteration count."""
        ...

    @property
    def key(self) -> str:
        """Return the canonical public key used by expressions."""
        ...


class VariableSource(Protocol):
    """Runtime surface required for variable resolution."""

    @property
    def scope(self) -> Scope:
        """Return the active template scope."""
        ...

    @property
    def line_index(self) -> int:
        """Return the 1-based index of the current dialogue line."""
        ...

    def repeat_binding(self, name: str) -> RepeatBindingLike | None:
        """Return the named repeat-loop binding, or ``None``."""
        ...

    def single_repeat_binding(self) -> RepeatBindingLike | None:
        """Return the sole active repeat binding when exactly one exists."""
        ...

    def object_binding_values(self) -> dict[str, object | None]:
        """Return the current karaoke objects keyed by binding name."""
        ...


class InterpolationRuntime(Protocol):
    """Runtime surface required for string interpolation."""

    def resolve_variable(self, raw_name: str) -> object:
        """Resolve one ``$variable`` according to the current scope boundaries."""
        ...

    def evaluate(self, expression: str) -> object:
        """Evaluate an expression in the current context."""
        ...


class ContextAccess(Protocol):
    """Capability surface required for expression-context construction."""

    @property
    def scope(self) -> Scope:
        """Return the active template scope."""
        ...

    @property
    def script(self) -> object | None:
        """Return the script resolution object, or ``None``."""
        ...

    def object_binding_values(self) -> dict[str, object | None]:
        """Return the current karaoke objects keyed by binding name."""
        ...


class RepeatSource(Protocol):
    """Capability surface required for repeat helper APIs."""

    def repeat_binding(self, name: str) -> RepeatBindingLike | None:
        """Return the named repeat-loop binding, or ``None``."""
        ...

    def single_repeat_binding(self) -> RepeatBindingLike | None:
        """Return the sole active repeat binding when exactly one exists."""
        ...


class RetimeRuntime(Protocol):
    """Runtime surface required for retime helper APIs."""

    @property
    def scope(self) -> Scope:
        """Return the active template scope."""
        ...

    @property
    def line(self) -> Line | None:
        """Return the current Line, or ``None``."""
        ...

    @property
    def word(self) -> Word | None:
        """Return the current Word, or ``None``."""
        ...

    @property
    def syl(self) -> Syllable | None:
        """Return the current Syllable, or ``None``."""
        ...

    @property
    def char(self) -> Char | None:
        """Return the current Char, or ``None``."""
        ...

    def apply_retime_target(
        self, target: RetimeTargetName, start_offset: int, end_offset: int
    ) -> None:
        """Apply one explicit retime target to the output interval."""
        ...


class MotionRuntime(Protocol):
    """Runtime surface required for motion helper APIs."""

    @property
    def line(self) -> Line | None:
        """Return the current Line, or ``None``."""
        ...

    @property
    def word(self) -> Word | None:
        """Return the current Word, or ``None``."""
        ...

    @property
    def syl(self) -> Syllable | None:
        """Return the current Syllable, or ``None``."""
        ...

    @property
    def char(self) -> Char | None:
        """Return the current Char, or ``None``."""
        ...

    @property
    def framerate(self) -> Framerate | float | None:
        """Return the active framerate, or ``None``."""
        ...

    def queue_fbf_request(self, request: FbfRequest) -> None:
        """Queue one pending frame-baked motion request."""
        ...

    def output_interval(self) -> tuple[int, int]:
        """Return the relative output interval for the current template."""
        ...


class OutputLayerController(Protocol):
    """Capability surface required for output-layer helpers."""

    def set_output_layer(self, layer: int) -> None:
        """Override the output layer for the current template pass."""
        ...


class HelpersRuntime(
    ContextAccess,
    RepeatSource,
    RetimeRuntime,
    MotionRuntime,
    OutputLayerController,
    Protocol,
):
    """Composite runtime surface used while assembling the helpers package."""

    @property
    def memory_state(self) -> dict[str, object]:
        """Return the cross-template memory state."""
        ...


class TemplateRuntime(HelpersRuntime, Protocol):
    """Runtime surface required for loop execution and skip conditions."""

    @property
    def framerate(self) -> Framerate | float | None:
        """Return the runtime framerate, or ``None``."""
        ...

    @property
    def rng_manager(self) -> RngManager:
        """Return the runtime RNG manager."""
        ...

    def resolve_variable(self, raw_name: str) -> object:
        """Resolve one ``$variable`` according to the current scope boundaries."""
        ...

    def evaluate(self, expression: str) -> object:
        """Evaluate an expression in the current context."""
        ...

    def current_text(self) -> str:
        """Return the scope-local text that template output appends by default."""
        ...

    def copy_for_highlight(self, highlight: Highlight) -> TemplateRuntime:
        """Clone the runtime with a highlight-specific syllable timing window."""
        ...

    def copy_for_repeat(
        self, repeat_loops: tuple[RepeatBindingLike, ...]
    ) -> TemplateRuntime:
        """Clone the runtime while overriding the repeat-loop state."""
        ...

    def consume_fbf_request(self) -> FbfRequest | None:
        """Return and clear the pending frame-baked request."""
        ...

    def set_output_layer(self, layer: int) -> None:
        """Override the output layer for the current template pass."""
        ...

    def output_layer(self, default: int) -> int:
        """Return the output layer, falling back to ``default`` when unset."""
        ...

    def output_interval(self) -> tuple[int, int]:
        """Return the relative output interval for the current template."""
        ...
