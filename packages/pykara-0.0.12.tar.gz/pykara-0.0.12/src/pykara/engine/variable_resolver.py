"""Variable resolution for ``$variable`` interpolation.

Extracts the variable-resolution responsibility from ``ExecutionRuntime``
into a standalone function that operates against a minimal ``VariableSource``
protocol instead of the full execution runtime.
"""

from __future__ import annotations

from pykara.engine.expression_catalog import (
    GENERIC_REPEAT_VARIABLE_NAMES,
    LINE_INDEX_VARIABLE_NAME,
    REPEAT_VALUE_SUFFIXES,
    REPEAT_VARIABLE_PREFIX,
    VARIABLE_ATTRS_BY_GROUP,
    VARIABLE_GROUPS_BY_SCOPE,
    VARIABLE_PATTERN_NAMES,
)
from pykara.engine.protocols import VariableSource
from pykara.exceptions import PykaraValidationError


def _resolve_repeat_variable(
    source: VariableSource,
    raw_name: str,
    name: str,
) -> int:
    """Resolve one ``$repeat_*`` variable.

    Args:
        source: The variable source providing repeat-loop state.
        raw_name: Original variable name for error messages.
        name: Lower-cased variable name.

    Returns:
        The current iteration index or total count for the resolved
        repeat binding.

    Raises:
        PykaraValidationError: The repeat variable name is malformed or
            references a non-existent repeat loop.
    """
    if name in GENERIC_REPEAT_VARIABLE_NAMES:
        binding = source.single_repeat_binding()
        if binding is None:
            raise PykaraValidationError(
                "runtime.resolve_variable(): "
                f"Variable ${raw_name} requires exactly one repeat loop"
            )
        return binding.index if name.endswith("_i") else binding.count

    prefix, _, suffix = name.rpartition("_")
    if suffix not in REPEAT_VALUE_SUFFIXES or not prefix.startswith(
        REPEAT_VARIABLE_PREFIX
    ):
        raise PykaraValidationError(
            f"runtime.resolve_variable(): Unknown variable: ${raw_name}"
        )

    loop_name = prefix[len(REPEAT_VARIABLE_PREFIX) :]
    if not loop_name:
        raise PykaraValidationError(
            f"runtime.resolve_variable(): Unknown variable: ${raw_name}"
        )
    binding = source.repeat_binding(loop_name)
    if binding is None:
        raise PykaraValidationError(
            f"runtime.resolve_variable(): Unknown variable: ${raw_name}"
        )
    return binding.index if suffix == "i" else binding.count


def resolve_variable(source: VariableSource, raw_name: str) -> object:
    """Resolve one ``$variable`` according to the current scope boundaries.

    Args:
        source: The variable source providing scope, karaoke objects, and
            repeat-loop state.
        raw_name: Variable name as it appears after the ``$`` sigil,
            before any case normalisation.

    Returns:
        The resolved value of the variable for the current scope and
        karaoke object.

    Raises:
        PykaraValidationError: The variable name is unknown, out of scope, or the
            underlying attribute is unavailable in the current phase.
    """
    name = raw_name.lower()
    if name.startswith(REPEAT_VARIABLE_PREFIX):
        return _resolve_repeat_variable(source, raw_name, name)

    allowed_groups = VARIABLE_GROUPS_BY_SCOPE.get(source.scope, frozenset())
    if name == LINE_INDEX_VARIABLE_NAME:
        if "line" not in allowed_groups:
            raise PykaraValidationError(
                f"runtime.resolve_variable(): Variable ${raw_name} is out of scope"
            )
        return source.line_index

    group, _, _ = name.partition("_")
    if group not in VARIABLE_PATTERN_NAMES:
        raise PykaraValidationError(
            f"runtime.resolve_variable(): Unknown variable: ${raw_name}"
        )
    if group not in allowed_groups:
        raise PykaraValidationError(
            f"runtime.resolve_variable(): Variable ${raw_name} is out of scope"
        )

    variable_map = VARIABLE_ATTRS_BY_GROUP[group]
    obj = source.object_binding_values()[group]
    if name not in variable_map:
        raise PykaraValidationError(
            f"runtime.resolve_variable(): Unknown variable: ${raw_name}"
        )
    if obj is None:
        raise PykaraValidationError(
            f"runtime.resolve_variable(): Variable ${raw_name} is out of scope"
        )

    attribute_name = variable_map[name]
    if not hasattr(obj, attribute_name):
        raise PykaraValidationError(
            "runtime.resolve_variable(): "
            f"Variable ${raw_name} is unavailable in this phase"
        )
    return getattr(obj, attribute_name)
