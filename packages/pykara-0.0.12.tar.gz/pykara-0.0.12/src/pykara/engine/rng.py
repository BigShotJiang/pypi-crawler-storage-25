"""Deterministic random number generator state management."""

from __future__ import annotations

import random
from collections.abc import Generator
from contextlib import contextmanager


class RngManager:
    """Manages predictable seeded RNG state across template evaluations."""

    __slots__ = ("_rng", "seed")

    def __init__(self, seed: int = 42, shared_rng: random.Random | None = None) -> None:
        self.seed = seed
        self._rng = shared_rng if shared_rng is not None else random.Random(seed)

    @property
    def rng(self) -> random.Random:
        """Return the managed deterministic RNG instance."""
        return self._rng

    def _sync_random_module_state(self) -> None:
        """Persist stdlib ``random`` module mutations back into the shared RNG."""
        self._rng.setstate(random.getstate())

    @contextmanager
    def activated(self) -> Generator[None, None, None]:
        """Run one evaluation with stdlib ``random`` bound to this RNG.

        Yields:
            Nothing; the context manager temporarily replaces the stdlib
            ``random`` module's global state with this manager's RNG and
            restores the previous state on exit.
        """
        previous_state = random.getstate()
        random.setstate(self._rng.getstate())
        try:
            yield
        finally:
            self._sync_random_module_state()
            random.setstate(previous_state)
