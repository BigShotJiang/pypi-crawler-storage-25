"""Thin wrappers over Python expression execution."""

from __future__ import annotations

from typing import TypeAlias

ExpressionHelpers: TypeAlias = dict[str, object]


def eval_expression(expression: str, context: ExpressionHelpers) -> object:
    """Evaluate a Python expression in ``context``.

    Args:
        expression: A Python expression string to evaluate.
        context: The ``globals``/``locals`` dict exposed to the expression.

    Returns:
        The value produced by evaluating ``expression``.
    """
    return eval(expression, context, context)  # noqa: S307


def exec_code(code: str, context: ExpressionHelpers) -> None:
    """Execute Python statements in ``context``.

    Args:
        code: A Python source string containing one or more statements.
        context: The ``globals``/``locals`` dict exposed to the code; any
            names defined by the code are written back into this dict.
    """
    exec(code, context, context)  # noqa: S102
