"""Expression-facing wrappers used by runtime context assembly."""

from __future__ import annotations

from dataclasses import dataclass
from types import FunctionType
from typing import cast

from pykara.engine.expression_catalog import (
    EXPRESSION_OBJECT_TYPES,
    EXPRESSION_VISIBLE_ATTRS,
    STYLE_PROPERTY_ATTRS,
    STYLE_VISIBLE_ATTRS,
)
from pykara.exceptions import PykaraAttributeError
from pykara.layout.style import LayoutStyle, format_style_color_for_expression

STYLE_COLOR_ATTRS = frozenset(
    {
        "primary_color",
        "secondary_color",
        "outline_color",
        "back_color",
    }
)


@dataclass(frozen=True, slots=True)
class DeferredCodeFunction:
    """A code-defined function rebound against a later runtime context."""

    function: FunctionType

    def resolve(self, context: dict[str, object]) -> FunctionType:
        """Return a function bound to ``context`` as its globals dict."""
        original = cast(FunctionType, self.function)
        rebound = FunctionType(
            original.__code__,
            context,
            original.__name__,
            original.__defaults__,
            original.__closure__,
        )
        rebound.__kwdefaults__ = original.__kwdefaults__
        rebound.__annotations__ = dict(original.__annotations__)
        return rebound


class ExpressionView:
    """Read-only public view of one runtime value for expressions."""

    __slots__ = ("_cache", "_target", "_visible_attrs")

    def __init__(
        self,
        *,
        target: object,
        visible_attrs: frozenset[str],
        cache: dict[int, object],
    ) -> None:
        self._target = target
        self._visible_attrs = visible_attrs
        self._cache = cache

    def __getattribute__(self, name: str) -> object:
        """Resolve one allowed public attribute from the wrapped object."""
        if name in {"__class__", "__dir__", "__repr__"}:
            return object.__getattribute__(self, name)

        visible_attrs = object.__getattribute__(self, "_visible_attrs")
        if name not in visible_attrs:
            target = object.__getattribute__(self, "_target")
            raise PykaraAttributeError(
                f"{type(target).__name__.lower()}.{name} "
                "is not available in expressions"
            )
        target = object.__getattribute__(self, "_target")
        cache = object.__getattribute__(self, "_cache")
        value = getattr(target, name)
        if (
            isinstance(target, LayoutStyle)
            and name in STYLE_COLOR_ATTRS
            and isinstance(value, str)
        ):
            value = format_style_color_for_expression(value)
        return wrap_expression_value(value, cache)

    def __dir__(self) -> list[str]:
        """Expose only the documented public attribute surface."""
        return sorted(object.__getattribute__(self, "_visible_attrs"))

    def __repr__(self) -> str:
        """Show the wrapped type without leaking internals."""
        target = object.__getattribute__(self, "_target")
        return f"<expression-proxy {type(target).__name__}>"


def resolve_deferred_code_functions(context: dict[str, object]) -> None:
    """Replace deferred code functions with call-ready runtime functions."""
    for name, value in list(context.items()):
        if isinstance(value, DeferredCodeFunction):
            context[name] = value.resolve(context)


def persist_expression_value(value: object) -> object:
    """Prepare one scope-defined value for storage across future evaluations."""
    if isinstance(value, FunctionType):
        return DeferredCodeFunction(value)
    return value


def wrap_expression_value(value: object, cache: dict[int, object]) -> object:
    """Wrap runtime objects before exposing them to ``!expression!`` code."""
    if isinstance(value, EXPRESSION_OBJECT_TYPES):
        object_id = id(value)
        cached = cache.get(object_id)
        if cached is not None:
            return cached
        view = ExpressionView(
            target=value,
            visible_attrs=EXPRESSION_VISIBLE_ATTRS[type(value)],
            cache=cache,
        )
        cache[object_id] = view
        return view

    if isinstance(value, LayoutStyle):
        object_id = id(value)
        cached = cache.get(object_id)
        if cached is not None:
            return cached
        view = ExpressionView(
            target=value,
            visible_attrs=STYLE_VISIBLE_ATTRS | STYLE_PROPERTY_ATTRS,
            cache=cache,
        )
        cache[object_id] = view
        return view

    if isinstance(value, list):
        return [
            wrap_expression_value(item, cache)
            for item in cast(list[object], value)
        ]

    if isinstance(value, tuple):
        return tuple(
            wrap_expression_value(item, cache)
            for item in cast(tuple[object, ...], value)
        )

    return value
