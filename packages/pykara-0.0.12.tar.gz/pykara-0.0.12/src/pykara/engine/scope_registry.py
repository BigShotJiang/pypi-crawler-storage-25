"""Central registry for scope-dependent execution visibility rules."""

from __future__ import annotations

from dataclasses import dataclass

from pykara.directive.types import Scope


@dataclass(frozen=True, slots=True)
class ScopeConfig:
    """Visibility and state configuration for one execution scope."""

    expression_object_bindings: frozenset[str]
    variable_groups: frozenset[str]
    expression_special_bindings: frozenset[str]
    visible_state_attrs: tuple[str, ...]
    local_state_attr: str


SCOPE_REGISTRY: dict[Scope, ScopeConfig] = {
    Scope.SETUP: ScopeConfig(
        expression_object_bindings=frozenset(),
        variable_groups=frozenset(),
        expression_special_bindings=frozenset(),
        visible_state_attrs=("setup_state",),
        local_state_attr="setup_state",
    ),
    Scope.LINE: ScopeConfig(
        expression_object_bindings=frozenset({"line"}),
        variable_groups=frozenset({"line"}),
        expression_special_bindings=frozenset({"script"}),
        visible_state_attrs=("setup_state", "line_state"),
        local_state_attr="line_state",
    ),
    Scope.WORD: ScopeConfig(
        expression_object_bindings=frozenset({"line", "word"}),
        variable_groups=frozenset({"line", "word"}),
        expression_special_bindings=frozenset({"script"}),
        visible_state_attrs=("setup_state", "line_state", "word_state"),
        local_state_attr="word_state",
    ),
    Scope.SYL: ScopeConfig(
        expression_object_bindings=frozenset({"line", "syl"}),
        variable_groups=frozenset({"line", "syl"}),
        expression_special_bindings=frozenset({"script"}),
        visible_state_attrs=("setup_state", "line_state", "syl_state"),
        local_state_attr="syl_state",
    ),
    Scope.CHAR: ScopeConfig(
        expression_object_bindings=frozenset({"line", "word", "syl", "char"}),
        variable_groups=frozenset({"line", "word", "syl", "char"}),
        expression_special_bindings=frozenset({"script"}),
        visible_state_attrs=(
            "setup_state",
            "line_state",
            "syl_state",
            "word_state",
            "char_state",
        ),
        local_state_attr="char_state",
    ),
}
