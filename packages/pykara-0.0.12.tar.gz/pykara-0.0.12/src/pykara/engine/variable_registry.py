"""Central registry of public ``$variables`` and repeat-variable patterns."""

from __future__ import annotations

from pykara.directive.types import Scope
from pykara.engine.scope_registry import SCOPE_REGISTRY

LINE_INDEX_VARIABLE_NAME = "line_li"
REPEAT_VARIABLE_PREFIX = "repeat_"
GENERIC_REPEAT_VARIABLE_NAMES = frozenset({"repeat_i", "repeat_n"})
REPEAT_VALUE_SUFFIXES = frozenset({"i", "n"})

LINE_VARIABLES = {
    "line_dur": "duration",
    "line_left": "left",
    "line_center": "center",
    "line_right": "right",
    "line_width": "width",
    "line_top": "top",
    "line_middle": "middle",
    "line_bottom": "bottom",
    "line_height": "height",
}

WORD_VARIABLES = {
    "word_wi": "wi",
    "word_ci": "ci",
    "word_left": "abs_left",
    "word_center": "abs_center",
    "word_right": "abs_right",
    "word_width": "width",
    "word_height": "height",
}

SYL_VARIABLES = {
    "syl_start": "start_time",
    "syl_end": "end_time",
    "syl_dur": "duration",
    "syl_kdur": "kdur",
    "syl_si": "si",
    "syl_ci": "ci",
    "syl_left": "abs_left",
    "syl_center": "abs_center",
    "syl_right": "abs_right",
    "syl_width": "width",
    "syl_top": "abs_top",
    "syl_middle": "abs_middle",
    "syl_bottom": "abs_bottom",
    "syl_height": "height",
}

CHAR_VARIABLES = {
    "char_ci": "ci",
    "char_si": "si",
    "char_wi": "wi",
    "char_left": "abs_left",
    "char_center": "abs_center",
    "char_right": "abs_right",
    "char_width": "width",
    "char_top": "abs_top",
    "char_middle": "abs_middle",
    "char_bottom": "abs_bottom",
    "char_height": "height",
}

VARIABLE_ATTRS_BY_GROUP = {
    "line": LINE_VARIABLES,
    "word": WORD_VARIABLES,
    "syl": SYL_VARIABLES,
    "char": CHAR_VARIABLES,
}
VARIABLE_PATTERN_NAMES = frozenset(VARIABLE_ATTRS_BY_GROUP)

VARIABLE_GROUPS_BY_SCOPE: dict[Scope, frozenset[str]] = {
    scope: config.variable_groups for scope, config in SCOPE_REGISTRY.items()
}

STATIC_VARIABLE_NAMES_BY_SCOPE: dict[Scope, frozenset[str]] = {
    scope: frozenset({LINE_INDEX_VARIABLE_NAME} if "line" in groups else set())
    | frozenset(
        variable_name
        for group_name in groups
        for variable_name in VARIABLE_ATTRS_BY_GROUP[group_name]
    )
    for scope, groups in VARIABLE_GROUPS_BY_SCOPE.items()
}
