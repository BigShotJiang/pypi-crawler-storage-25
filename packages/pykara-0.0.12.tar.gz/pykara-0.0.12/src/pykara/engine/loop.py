"""Loop and skip logic for template directives."""

from __future__ import annotations

from itertools import product

from pykara.directive.types import (
    InlineFxMod,
    MultiMod,
    NoblankMod,
    NotextMod,
    PatchDirective,
    RepeatMod,
    TemplateDirective,
    Token,
    UnlessMod,
    WhenMod,
    find_modifier,
    has_modifier,
)
from pykara.engine.context_builder import build_expression_context
from pykara.engine.execution_runtime import RepeatBinding
from pykara.engine.protocols import TemplateRuntime
from pykara.exceptions import PykaraNameError


def _is_blank(text: str) -> bool:
    """Return whether ``text`` is blank by template-spec rules."""
    return text.strip(" \t\n\r\u3000") == ""


def _required_inline_fx_name(
    directive: TemplateDirective | PatchDirective,
) -> str | None:
    """Return the inline-fx name required by one directive, when present."""
    mod = find_modifier(directive, InlineFxMod)
    return mod.name if mod is not None else None


def _current_inline_fx(runtime: TemplateRuntime) -> str:
    """Return the inline-fx name visible at the current execution object."""
    if runtime.char is not None:
        return runtime.char.syl.inline_fx
    if runtime.syl is not None:
        return runtime.syl.inline_fx
    return ""


def evaluate_token(runtime: TemplateRuntime, name: str) -> bool:
    """Evaluate a token condition from the visible code context."""
    with runtime.rng_manager.activated():
        context = build_expression_context(runtime)
        if name not in context:
            raise PykaraNameError(
                f"loop.evaluate_token(): Unknown condition token: {name}"
            )
        return bool(context[name])


def _eval_condition(
    condition: object, runtime: TemplateRuntime, *, negate: bool
) -> bool:
    """Evaluate one When/Unless condition payload."""
    result = (
        evaluate_token(runtime, condition.name)  # type: ignore[union-attr]
        if isinstance(condition, Token)
        else bool(runtime.evaluate(condition.code))  # type: ignore[union-attr]
    )
    return not result if negate else result


def _condition_result(
    directive: TemplateDirective | PatchDirective,
    runtime: TemplateRuntime,
) -> bool | None:
    """Return the boolean result of the directive condition, when any exists."""
    when = find_modifier(directive, WhenMod)
    if when is not None:
        return _eval_condition(when.condition, runtime, negate=False)
    unless = find_modifier(directive, UnlessMod)
    if unless is not None:
        return _eval_condition(unless.condition, runtime, negate=True)
    return None


def should_skip(
    directive: TemplateDirective | PatchDirective,
    runtime: TemplateRuntime,
) -> bool:
    """Return whether the current object should skip this directive.

    Args:
        directive: The template or patch directive being evaluated.
        runtime: The execution runtime for the current karaoke object.

    Returns:
        ``True`` under any of three conditions: the ``no_blank`` modifier is
        present and the current scope text is blank; the ``inline_fx``
        modifier is present and the current inline-fx name does not match;
        or a ``when``/``unless`` condition evaluates to the skipping result.
    """
    if has_modifier(directive, NoblankMod) and _is_blank(runtime.current_text()):
        return True

    required_inline_fx = _required_inline_fx_name(directive)
    if (
        required_inline_fx is not None
        and _current_inline_fx(runtime) != required_inline_fx
    ):
        return True

    condition_result = _condition_result(directive, runtime)
    return bool(condition_result is not None and not condition_result)


def repeat_modifiers(directive: TemplateDirective) -> list[RepeatMod]:
    """Return the repeat modifiers declared on ``directive``.

    Args:
        directive: The template directive to inspect.

    Returns:
        Ordered list of ``RepeatMod`` instances found in the modifier list.
    """
    return [mod for mod in directive.modifiers if isinstance(mod, RepeatMod)]


def expand_repeat_bindings(
    directive: TemplateDirective,
) -> list[tuple[RepeatBinding, ...]]:
    """Expand the directive repeat modifiers into cartesian loop bindings.

    Args:
        directive: The template directive whose repeat modifiers are expanded.

    Returns:
        A list of binding tuples, one per cartesian product combination.
        When no repeat modifiers are present the base case ``[()]`` is
        returned so that the caller always iterates exactly once.
    """
    repeat_mods = repeat_modifiers(directive)
    if not repeat_mods:
        return [()]

    ranges = [range(1, modifier.count + 1) for modifier in repeat_mods]
    return [
        tuple(
            RepeatBinding(
                name=modifier.name,
                index=index,
                count=modifier.count,
            )
            for modifier, index in zip(repeat_mods, indices, strict=True)
        )
        for indices in product(*ranges)
    ]


def append_scope_text(directive: TemplateDirective) -> bool:
    """Return whether template output should append the current scope text.

    Args:
        directive: The template directive being evaluated.

    Returns:
        ``True`` unless the directive carries the ``no_text`` modifier.
    """
    return not has_modifier(directive, NotextMod)


def expand_highlight_runtimes(
    directive: TemplateDirective,
    runtime: TemplateRuntime,
) -> list[TemplateRuntime]:
    """Expand one template runtime into one or more multi-highlight passes.

    Args:
        directive: The template directive being evaluated.
        runtime: The execution runtime for the current syllable.

    Returns:
        A list with one runtime per highlight when the ``multi`` modifier is
        present and the runtime has a syllable; otherwise a single-element
        list containing the original runtime unchanged.
    """
    if not has_modifier(directive, MultiMod) or runtime.syl is None:
        return [runtime]
    return [
        runtime.copy_for_highlight(highlight) for highlight in runtime.syl.highlights
    ]
