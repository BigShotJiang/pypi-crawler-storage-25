"""Central definition of the public expression surface."""

from __future__ import annotations

from dataclasses import fields
from typing import TypeAlias

from pykara.directive.types import Scope
from pykara.engine import variable_registry as _variable_registry
from pykara.engine.scope_registry import SCOPE_REGISTRY
from pykara.karaoke.char import Char
from pykara.karaoke.line import Line
from pykara.karaoke.syllable import Highlight, Syllable
from pykara.karaoke.word import Word
from pykara.layout.positioning import Script
from pykara.layout.style import LayoutStyle

ExpressionObjectType: TypeAlias = Line | Word | Syllable | Char
ExpressionObjectClass: TypeAlias = (
    type[Line] | type[Word] | type[Syllable] | type[Char]
)
ExpressionHelpers: TypeAlias = dict[str, object]

EXPRESSION_OBJECT_MODEL_BY_BINDING = {
    "line": Line,
    "word": Word,
    "syl": Syllable,
    "char": Char,
}
EXPRESSION_OBJECT_BINDING_NAMES = tuple(EXPRESSION_OBJECT_MODEL_BY_BINDING)
EXPRESSION_OBJECT_TYPES = tuple(EXPRESSION_OBJECT_MODEL_BY_BINDING.values())
SCRIPT_BINDING_NAME = "script"
STYLE_PROPERTY_ATTRS = frozenset({"margin_t", "margin_b"})

EXPRESSION_OBJECT_BINDINGS_BY_SCOPE: dict[Scope, frozenset[str]] = {
    scope: config.expression_object_bindings for scope, config in SCOPE_REGISTRY.items()
}

EXPRESSION_SPECIAL_BINDINGS_BY_SCOPE: dict[Scope, frozenset[str]] = {
    scope: config.expression_special_bindings
    for scope, config in SCOPE_REGISTRY.items()
}

EXPRESSION_BINDINGS_BY_SCOPE: dict[Scope, frozenset[str]] = {
    scope: EXPRESSION_OBJECT_BINDINGS_BY_SCOPE[scope]
    | EXPRESSION_SPECIAL_BINDINGS_BY_SCOPE[scope]
    for scope in Scope
}


def expression_visible_fields(model_type: type) -> frozenset[str]:
    """Return the public dataclass fields exposed to expressions."""
    return frozenset(
        field_info.name
        for field_info in fields(model_type)
        if field_info.name != "highlights"
    )


EXPRESSION_VISIBLE_ATTRS: dict[ExpressionObjectClass, frozenset[str]] = {
    model_type: expression_visible_fields(model_type)
    for model_type in EXPRESSION_OBJECT_MODEL_BY_BINDING.values()
}
STYLE_VISIBLE_ATTRS = frozenset(field_info.name for field_info in fields(LayoutStyle))
SCRIPT_VISIBLE_ATTRS = expression_visible_fields(Script)
HIGHLIGHT_VISIBLE_ATTRS = expression_visible_fields(Highlight)

CHAR_VARIABLES = _variable_registry.CHAR_VARIABLES
GENERIC_REPEAT_VARIABLE_NAMES = _variable_registry.GENERIC_REPEAT_VARIABLE_NAMES
LINE_INDEX_VARIABLE_NAME = _variable_registry.LINE_INDEX_VARIABLE_NAME
LINE_VARIABLES = _variable_registry.LINE_VARIABLES
REPEAT_VALUE_SUFFIXES = _variable_registry.REPEAT_VALUE_SUFFIXES
REPEAT_VARIABLE_PREFIX = _variable_registry.REPEAT_VARIABLE_PREFIX
STATIC_VARIABLE_NAMES_BY_SCOPE = _variable_registry.STATIC_VARIABLE_NAMES_BY_SCOPE
SYL_VARIABLES = _variable_registry.SYL_VARIABLES
VARIABLE_ATTRS_BY_GROUP = _variable_registry.VARIABLE_ATTRS_BY_GROUP
VARIABLE_GROUPS_BY_SCOPE = _variable_registry.VARIABLE_GROUPS_BY_SCOPE
VARIABLE_PATTERN_NAMES = _variable_registry.VARIABLE_PATTERN_NAMES
WORD_VARIABLES = _variable_registry.WORD_VARIABLES

DOCUMENTED_REPEAT_VARIABLE_PATTERNS = frozenset(
    {
        "$repeat_i",
        "$repeat_n",
        "$repeat_<name>_i",
        "$repeat_<name>_n",
    }
)
DOCUMENTED_HELPER_SURFACE = {
    "color": frozenset(
        {
            "color.rgb.to_ass(r, g, b)",
            "color.hex.to_ass(value)",
            "color.ass.parse(value)",
            "color.hsv.to_rgb(h, s, v)",
        }
    ),
    "memory": frozenset(
        {
            "memory.remember(key, value)",
            "memory.recall.<key>",
        }
    ),
    "relayer": frozenset(
        {
            "relayer(layer)",
        }
    ),
    "motion": frozenset(
        {
            "motion.shad",
            "motion.fbf",
            "motion.shad.setup()",
            "motion.shad.jitter(left, right, up, down, period, seed=0)",
            "motion.fbf.jitter(left, right, up, down, period, seed=0)",
        }
    ),
    "timeline": frozenset(
        {
            "timeline.transitions(steps, tags)",
            "timeline.sequence(steps, accel=1.0)",
            "timeline.pulse(span, cadence, values, accel=1.0, start_index=0)",
        }
    ),
    "repeat": frozenset(
        {
            "repeat.i",
            "repeat.n",
            "repeat.<name>.i",
            "repeat.<name>.n",
        }
    ),
    "retime": frozenset(
        {
            "retime.line(start_offset=0, end_offset=0)",
            "retime.preline(start_offset=0, end_offset=0)",
            "retime.postline(start_offset=0, end_offset=0)",
            "retime.syl(start_offset=0, end_offset=0)",
            "retime.presyl(start_offset=0, end_offset=0)",
            "retime.postsyl(start_offset=0, end_offset=0)",
            "retime.start2syl(start_offset=0, end_offset=0)",
            "retime.syl2end(start_offset=0, end_offset=0)",
            "retime.<target>.ltr(start_offset=0, end_offset=0)",
            "retime.<target>.rtl(start_offset=0, end_offset=0)",
            "retime.<target>.from_center(start_offset=0, end_offset=0)",
            "retime.<target>.from_edges(start_offset=0, end_offset=0)",
            "retime.<target>.odd_first(start_offset=0, end_offset=0)",
            "retime.<target>.even_first(start_offset=0, end_offset=0)",
            "retime.<target>.spatial_ltr(start_offset=0, end_offset=0)",
            "retime.<target>.spatial_rtl(start_offset=0, end_offset=0)",
            "retime.<target>.random(start_offset=0, end_offset=0)",
        }
    ),
    "scale": frozenset(
        {
            "scale.of(value)",
            "scale.of(value).value",
            "scale.of(value).base(base_value)",
            "scale.of(value).base(base_value).to(target_value)",
        }
    ),
    "palette": frozenset(
        {
            "palette.<color>[shade]",
        }
    ),
}
HELPER_NAMES = frozenset(DOCUMENTED_HELPER_SURFACE)


def _dollar_prefixed(names: frozenset[str]) -> frozenset[str]:
    """Return the public ``$``-prefixed representation of variable names."""
    return frozenset(f"${name}" for name in names)


def _binding_scope_names(
    bindings_by_scope: dict[Scope, frozenset[str]],
) -> dict[str, frozenset[str]]:
    """Return scope-name sets keyed by one public binding/group name."""
    all_binding_names: frozenset[str] = frozenset[str]().union(
        *bindings_by_scope.values()
    )
    return {
        binding_name: frozenset(
            scope.value
            for scope, binding_names in bindings_by_scope.items()
            if binding_name in binding_names
        )
        for binding_name in all_binding_names
    }


DOCUMENTED_STATIC_VARIABLES_BY_SCOPE: dict[Scope, frozenset[str]] = {
    scope: _dollar_prefixed(names)
    for scope, names in STATIC_VARIABLE_NAMES_BY_SCOPE.items()
}
DOCUMENTED_VARIABLE_SECTION_SURFACE = {
    "line": _dollar_prefixed(
        frozenset({LINE_INDEX_VARIABLE_NAME}) | frozenset(LINE_VARIABLES)
    ),
    "word": _dollar_prefixed(frozenset(WORD_VARIABLES)),
    "syl": _dollar_prefixed(frozenset(SYL_VARIABLES)),
    "char": _dollar_prefixed(frozenset(CHAR_VARIABLES)),
    "repeat": DOCUMENTED_REPEAT_VARIABLE_PATTERNS,
}
DOCUMENTED_EXPRESSION_BINDING_SCOPES = _binding_scope_names(
    EXPRESSION_BINDINGS_BY_SCOPE
)
DOCUMENTED_VARIABLE_GROUP_SCOPES = _binding_scope_names(VARIABLE_GROUPS_BY_SCOPE)

RESERVED_EXPRESSION_NAMES = (
    frozenset({"__builtins__"})
    | HELPER_NAMES
    | frozenset(
        name
        for bindings in EXPRESSION_BINDINGS_BY_SCOPE.values()
        for name in bindings
    )
)

DOCUMENTED_EXPRESSION_OBJECT_SURFACE = {
    binding_name: EXPRESSION_VISIBLE_ATTRS[model_type]
    for binding_name, model_type in EXPRESSION_OBJECT_MODEL_BY_BINDING.items()
} | {
    "style": STYLE_VISIBLE_ATTRS | STYLE_PROPERTY_ATTRS,
    "script": SCRIPT_VISIBLE_ATTRS,
    "highlight": HIGHLIGHT_VISIBLE_ATTRS,
}
