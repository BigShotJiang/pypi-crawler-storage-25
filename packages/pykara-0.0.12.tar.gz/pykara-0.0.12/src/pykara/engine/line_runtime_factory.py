"""Per-line runtime state used to build execution runtimes."""

from __future__ import annotations

from dataclasses import dataclass, field

from pykara.directive.types import Scope
from pykara.engine.execution_runtime import ExecutionRuntime
from pykara.engine.rng import RngManager
from pykara.karaoke.char import Char
from pykara.karaoke.line import Line
from pykara.karaoke.syllable import Syllable
from pykara.karaoke.word import Word
from pykara.timing import Framerate


@dataclass(slots=True)
class LineRuntimeFactory:
    """Per-line state bundle that manufactures scope-specific runtimes."""

    line: Line
    line_index: int
    script: object
    framerate: Framerate | float | None
    rng_manager: RngManager
    setup_state: dict[str, object]
    memory_state: dict[str, object]
    line_state: dict[str, object] = field(default_factory=dict[str, object])
    word_states: dict[int, dict[str, object]] = field(init=False)
    syl_states: dict[int, dict[str, object]] = field(init=False)
    char_states: dict[int, dict[str, object]] = field(init=False)

    def __post_init__(self) -> None:
        self.word_states = {id(word): {} for word in self.line.words}
        self.syl_states = {id(syl): {} for syl in self.line.syls}
        self.char_states = {id(char): {} for char in self.line.chars}

    def make_runtime(
        self,
        scope: Scope,
        *,
        word: Word | None = None,
        syl: Syllable | None = None,
        char: Char | None = None,
    ) -> ExecutionRuntime:
        """Build one execution runtime for the given scope and karaoke objects."""
        resolved_syl = syl if syl is not None or char is None else char.syl
        resolved_word_state = {} if word is None else self.word_states[id(word)]
        resolved_syl_state = (
            {} if resolved_syl is None else self.syl_states[id(resolved_syl)]
        )
        resolved_char_state = {} if char is None else self.char_states[id(char)]

        return ExecutionRuntime(
            scope=scope,
            line_index=self.line_index,
            line=self.line,
            word=word,
            syl=resolved_syl,
            char=char,
            script=self.script,
            framerate=self.framerate,
            rng_manager=self.rng_manager,
            setup_state=self.setup_state,
            line_state=self.line_state,
            word_state=resolved_word_state,
            syl_state=resolved_syl_state,
            char_state=resolved_char_state,
            memory_state=self.memory_state,
        )
