"""Output-document assembly helpers."""

from __future__ import annotations

from pykara.ass.types import AssDocument, DialogueLine


def build_output_document(
    source_document: AssDocument,
    generated_events: list[DialogueLine],
) -> AssDocument:
    """Return one output ASS document with generated events appended."""
    return AssDocument(
        script_info=source_document.script_info,
        styles=list(source_document.styles),
        events=[*source_document.events, *generated_events],
        other_sections=list(source_document.other_sections),
        section_order=list(source_document.section_order),
        style_format=list(source_document.style_format),
        event_format=list(source_document.event_format),
    )
