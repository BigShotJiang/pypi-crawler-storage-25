"""Retime interval state for one template evaluation pass."""

from __future__ import annotations

from typing import Literal, TypeAlias

from pykara.directive.types import Scope
from pykara.exceptions import PykaraValidationError
from pykara.karaoke.line import Line
from pykara.karaoke.syllable import Syllable

RetimeTargetName: TypeAlias = Literal[
    "line",
    "preline",
    "postline",
    "syl",
    "presyl",
    "postsyl",
    "start2syl",
    "syl2end",
]

_LINE_RETIME_TARGETS: frozenset[RetimeTargetName] = frozenset(
    {"line", "preline", "postline"}
)
_SYL_RETIME_TARGETS: frozenset[RetimeTargetName] = frozenset(
    {"syl", "presyl", "postsyl", "start2syl", "syl2end"}
)
_RETIME_TARGET_NAMES: frozenset[RetimeTargetName] = frozenset(
    _LINE_RETIME_TARGETS | _SYL_RETIME_TARGETS
)


def _retime_base_range(
    target: RetimeTargetName,
    line: Line,
    syl: Syllable | None,
) -> tuple[int, int]:
    """Return the un-offset base interval for one explicit retime target."""
    if target == "line":
        return (0, line.duration)
    if target == "preline":
        return (0, 0)
    if target == "postline":
        return (line.duration, line.duration)

    assert syl is not None
    if target == "syl":
        return (syl.start_time, syl.end_time)
    if target == "presyl":
        return (syl.start_time, syl.start_time)
    if target == "postsyl":
        return (syl.end_time, syl.end_time)
    if target == "start2syl":
        return (0, syl.start_time)
    if target == "syl2end":
        return (syl.end_time, line.duration)
    raise PykaraValidationError(f"retime: Unknown retime target: {target!r}")


class RetimeState:
    """Mutable retime interval for one template evaluation pass."""

    __slots__ = ("_range", "_target")

    def __init__(self) -> None:
        """Initialize with no active retime target."""
        self._target: RetimeTargetName | None = None
        self._range: tuple[int, int] | None = None

    def apply(
        self,
        target: RetimeTargetName,
        start_offset: int,
        end_offset: int,
        *,
        scope: Scope,
        line: Line | None,
        syl: Syllable | None,
    ) -> None:
        """Apply one explicit retime target to the output interval."""
        if target not in _RETIME_TARGET_NAMES:
            raise PykaraValidationError(f"retime: Unknown retime target: {target!r}")
        if target in _LINE_RETIME_TARGETS:
            if line is None:
                raise PykaraValidationError(f"retime.{target}() requires line runtime")
        else:
            if scope not in {Scope.SYL, Scope.CHAR}:
                raise PykaraValidationError(
                    f"retime.{target}() is only valid in template syl and char"
                )
            if line is None or syl is None:
                raise PykaraValidationError(
                    f"retime.{target}() requires line and syl runtime"
                )

        if self._target == target:
            raise PykaraValidationError(f"retime.{target}() can only be called once")
        if self._target is not None:
            raise PykaraValidationError(
                f"retime.{self._target}() and retime.{target}() are mutually exclusive"
            )

        base_start, base_end = _retime_base_range(target, line, syl)  # type: ignore[arg-type]
        self._target = target
        self._range = (base_start + start_offset, base_end + end_offset)

    def output_interval(self, line: Line | None) -> tuple[int, int]:
        """Return the relative output interval for the current template."""
        if line is None:
            return (0, 0)
        if self._range is not None:
            return self._range
        return (0, line.duration)
