"""Pre-flight validation of an ASS document before processing."""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass

from pykara.ass.types import AssDocument
from pykara.engine.collector import (
    CollectedPatch,
    CollectedTemplate,
    collect_directives,
    patch_targets_template,
)


@dataclass(frozen=True, slots=True)
class PreflightError:
    """One validation failure found during pre-flight."""

    message: str
    source_effect: str
    source_text: str


@dataclass(frozen=True, slots=True)
class PreflightSubject:
    """One template plus the combined body surface checked by preflight."""

    template: CollectedTemplate
    bodies: tuple[str, ...]
    combined_body: str


class PreflightViolationError(Exception):
    """Raised when pre-flight finds one or more errors in the document."""

    def __init__(self, errors: list[PreflightError]) -> None:
        self.errors = errors
        lines = "\n".join(f"  [{e.source_effect}] {e.message}" for e in errors)
        super().__init__(f"Pre-flight validation failed:\n{lines}")


_FBF_CALL = re.compile(r"motion\.fbf\.")
_SHAD_CALL = re.compile(r"motion\.shad\.")
_POS_TAG = re.compile(r"\\pos\s*\(")
_MOVE_TAG = re.compile(r"\\move\s*\(")
_SHAD_TAG = re.compile(r"\\(?:xshad|yshad|shad)")
PreflightRule = Callable[[PreflightSubject], list[PreflightError]]


def _build_subject(
    template: CollectedTemplate,
    patches: list[CollectedPatch],
) -> PreflightSubject:
    """Return one preflight subject with all matching bodies precomputed."""
    matching = [p for p in patches if patch_targets_template(p, template)]
    bodies = (template.body, *(p.body for p in matching))
    return PreflightSubject(
        template=template,
        bodies=bodies,
        combined_body="\n".join(bodies),
    )


def _rule_fbf_pos_move(subject: PreflightSubject) -> list[PreflightError]:
    r"""motion.fbf.* is mutually exclusive with \pos and \move."""
    if not any(_FBF_CALL.search(body) for body in subject.bodies):
        return []
    errors: list[PreflightError] = []
    if _POS_TAG.search(subject.combined_body):
        errors.append(
            PreflightError(
                message=r"motion.fbf.* cannot be combined with \pos",
                source_effect=subject.template.source_event.effect,
                source_text=subject.template.body,
            )
        )
    if _MOVE_TAG.search(subject.combined_body):
        errors.append(
            PreflightError(
                message=r"motion.fbf.* cannot be combined with \move",
                source_effect=subject.template.source_event.effect,
                source_text=subject.template.body,
            )
        )
    return errors


def _rule_shad_motion_shad_tag(subject: PreflightSubject) -> list[PreflightError]:
    r"""motion.shad.* is mutually exclusive with \shad, \xshad and \yshad."""
    if not _SHAD_CALL.search(subject.combined_body) or not _SHAD_TAG.search(
        subject.combined_body
    ):
        return []
    return [
        PreflightError(
            message=r"motion.shad.* cannot be combined with \shad, \xshad or \yshad",
            source_effect=subject.template.source_event.effect,
            source_text=subject.template.body,
        )
    ]


def _rule_single_fbf_call(subject: PreflightSubject) -> list[PreflightError]:
    """``motion.fbf.*`` may appear at most once across a template and patches."""
    return _rule_single_motion_call(subject, pattern=_FBF_CALL, label="motion.fbf.*")


def _rule_single_shad_call(subject: PreflightSubject) -> list[PreflightError]:
    """``motion.shad.*`` may appear at most once across a template and patches."""
    return _rule_single_motion_call(subject, pattern=_SHAD_CALL, label="motion.shad.*")


def _rule_single_motion_call(
    subject: PreflightSubject,
    *,
    pattern: re.Pattern[str],
    label: str,
) -> list[PreflightError]:
    """``label`` may appear at most once across a template and its patches."""
    total = sum(len(pattern.findall(body)) for body in subject.bodies)
    if total <= 1:
        return []
    return [
        PreflightError(
            message=f"{label} may only appear once per template and its patches",
            source_effect=subject.template.source_event.effect,
            source_text=subject.template.body,
        )
    ]


_PREFLIGHT_RULES: tuple[PreflightRule, ...] = (
    _rule_fbf_pos_move,
    _rule_shad_motion_shad_tag,
    _rule_single_fbf_call,
    _rule_single_shad_call,
)


def preflight(document: AssDocument) -> None:
    """Validate ``document`` before processing begins.

    Collects directives from the document and runs all pre-flight rules over
    every template body.  All errors are gathered before raising so the caller
    sees the full picture in one pass.

    Args:
        document: The parsed ASS document to validate.

    Raises:
        PreflightViolationError: One or more pre-flight rules were violated.
    """
    templates, _code_blocks, patches = collect_directives(document)
    errors: list[PreflightError] = []
    for template in templates:
        subject = _build_subject(template, patches)
        for rule in _PREFLIGHT_RULES:
            errors.extend(rule(subject))
    if errors:
        raise PreflightViolationError(errors)
