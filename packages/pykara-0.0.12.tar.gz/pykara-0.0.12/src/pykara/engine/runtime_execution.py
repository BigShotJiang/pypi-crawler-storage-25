"""Execution utilities that evaluate code against one runtime."""

from __future__ import annotations

from typing import Protocol

from pykara.engine.context_builder import (
    build_expression_context,
    persist_expression_state,
)
from pykara.engine.evaluator import eval_expression, exec_code
from pykara.engine.protocols import HelpersRuntime
from pykara.engine.rng import RngManager


class CodeExecutionRuntime(HelpersRuntime, Protocol):
    """Runtime surface required to execute expressions and code."""

    @property
    def rng_manager(self) -> RngManager:
        """Return the runtime RNG manager."""
        ...


def run_code(runtime: CodeExecutionRuntime, code: str) -> None:
    """Execute code and persist the resulting names on the current scope."""
    with runtime.rng_manager.activated():
        context = build_expression_context(runtime)
        exec_code(code, context)
    persist_expression_state(runtime, context)


def evaluate(runtime: CodeExecutionRuntime, expression: str) -> object:
    """Evaluate an expression inside the current runtime context."""
    with runtime.rng_manager.activated():
        context = build_expression_context(runtime)
        return eval_expression(expression, context)
