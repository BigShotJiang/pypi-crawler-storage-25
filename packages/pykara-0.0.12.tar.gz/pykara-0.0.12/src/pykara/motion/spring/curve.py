"""Pure spring (damped oscillation) curve math."""

from __future__ import annotations

import math


def spring_xy(
    t: float,
    x0: float,
    y0: float,
    x1: float,
    y1: float,
    amplitude: float = 1.0,
    damping: float = 3.0,
    freq: float = 6.0,
) -> tuple[float, float]:
    """Return the spring-motion position at normalised progress *t*."""
    dx = x0 - x1
    dy = y0 - y1
    env = math.exp(-damping * t * 4) * amplitude
    osc = math.cos(freq * math.pi * 2 * t)
    return x1 + dx * env * osc, y1 + dy * env * osc

