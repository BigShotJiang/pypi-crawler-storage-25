"""Queued frame-baked spring requests."""

from __future__ import annotations

from dataclasses import dataclass

from pykara.ass.types import DialogueLine
from pykara.timing import Framerate


@dataclass(frozen=True, slots=True)
class SpringFbfRequest:
    """Queued parameters for one frame-baked spring expansion."""

    x0: float
    y0: float
    x1: float
    y1: float
    amplitude: float = 1.0
    damping: float = 3.0
    freq: float = 6.0
    t1: float | None = None
    t2: float | None = None
    step: int = 1

    def expand(
        self,
        line: DialogueLine,
        framerate: Framerate | float,
    ) -> list[DialogueLine]:
        """Expand ``line`` using the queued spring configuration."""
        from pykara.motion.spring.fbf import spring_fbf_line

        return spring_fbf_line(
            line,
            framerate,
            self.x0,
            self.y0,
            self.x1,
            self.y1,
            self.amplitude,
            self.damping,
            self.freq,
            self.t1,
            self.t2,
            self.step,
        )

