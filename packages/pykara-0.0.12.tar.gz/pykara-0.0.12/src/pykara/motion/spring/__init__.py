"""Spring motion effect."""
