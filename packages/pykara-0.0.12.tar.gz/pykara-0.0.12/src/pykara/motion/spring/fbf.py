"""Frame-baked spring motion builder."""

from __future__ import annotations

from pykara.ass.types import DialogueLine
from pykara.motion.runtime.fbf.expansion import apply_curve_fbf
from pykara.motion.runtime.window import resolve_window
from pykara.motion.spring.curve import spring_xy
from pykara.timing import Framerate


def spring_fbf_line(
    line: DialogueLine,
    framerate: Framerate | float,
    x0: float,
    y0: float,
    x1: float,
    y1: float,
    amplitude: float = 1.0,
    damping: float = 3.0,
    freq: float = 6.0,
    t1: float | None = None,
    t2: float | None = None,
    step: int = 1,
) -> list[DialogueLine]:
    r"""Expand one line to frame-baked spring motion output.

    Args:
        line: The source dialogue line to expand.
        framerate: Frame timing data used to compute per-frame intervals.
        x0: Start X coordinate.
        y0: Start Y coordinate.
        x1: Target X coordinate.
        y1: Target Y coordinate.
        amplitude: Oscillation amplitude multiplier.
        damping: Exponential damping coefficient.
        freq: Oscillation frequency in cycles per duration.
        t1: Optional window start in milliseconds.
        t2: Optional window end in milliseconds.
        step: Frame grouping step.

    Returns:
        An ordered list of ``DialogueLine`` objects, one per frame.
    """
    tw1, tw2 = resolve_window(t1, t2, line.end_time - line.start_time)

    def curve(t: float) -> tuple[float, float]:
        return spring_xy(t, x0, y0, x1, y1, amplitude, damping, freq)

    return apply_curve_fbf(line, framerate, curve, tw1, tw2, step)
