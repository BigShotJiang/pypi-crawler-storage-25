"""Shadow-trick wave motion builder."""

from __future__ import annotations

import math

from pykara.math.curves import sample_curve
from pykara.motion.runtime.shad.formatting import fmt_shad_tags
from pykara.motion.runtime.shad.transforms import zero_duration_transform
from pykara.motion.runtime.window import resolve_window
from pykara.motion.wave.curve import wave_xy


def build_shad_wave(
    duration_ms: int,
    ax: float,
    ay: float,
    x0: float,
    x1: float,
    y_base: float,
    amplitude: float = 150.0,
    frequency: float = 2.0,
    phase: float = 0.0,
    t1: float | None = None,
    t2: float | None = None,
    segments: int = 32,
) -> str:
    r"""Return ``\t(...)`` segments for wave motion using the shadow trick.

    Args:
        duration_ms: Line interval duration in milliseconds.
        ax: Anchor X coordinate (from ``\pos``).
        ay: Anchor Y coordinate (from ``\pos``).
        x0: Start X coordinate.
        x1: End X coordinate.
        y_base: Vertical baseline in pixels.
        amplitude: Peak vertical displacement in pixels.
        frequency: Number of full cycles over the duration.
        phase: Initial phase offset in degrees.
        t1: Optional window start in milliseconds.
        t2: Optional window end in milliseconds.
        segments: Number of linear approximation segments.

    Returns:
        A string of concatenated ``\t(ms0,ms1,\xshad...\yshad...)`` tags.
    """
    tw1, tw2 = resolve_window(t1, t2, duration_ms)
    phase_rad = math.radians(phase)

    def curve(t: float) -> tuple[float, float]:
        return wave_xy(t, x0, x1, y_base, amplitude, frequency, phase_rad)

    raw_segments = sample_curve(curve, segments, tw1, tw2)
    fragments: list[str] = []
    for ms0, ms1, px0, py0, px1, py1 in raw_segments:
        t0, t1 = int(ms0), int(ms1)
        shad0 = fmt_shad_tags(px0 - ax, py0 - ay)
        shad1 = fmt_shad_tags(px1 - ax, py1 - ay)
        fragments.append(zero_duration_transform(t0, shad0))
        fragments.append(rf"\t({t0},{t1},{shad1})")
    return "".join(fragments)
