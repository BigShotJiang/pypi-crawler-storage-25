"""Wave motion effect."""
