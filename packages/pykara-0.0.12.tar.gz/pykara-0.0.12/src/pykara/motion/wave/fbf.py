"""Frame-baked wave motion builder."""

from __future__ import annotations

import math

from pykara.ass.types import DialogueLine
from pykara.motion.runtime.fbf.expansion import apply_curve_fbf
from pykara.motion.runtime.window import resolve_window
from pykara.motion.wave.curve import wave_xy
from pykara.timing import Framerate


def wave_fbf_line(
    line: DialogueLine,
    framerate: Framerate | float,
    x0: float,
    x1: float,
    y_base: float,
    amplitude: float = 150.0,
    frequency: float = 2.0,
    phase: float = 0.0,
    t1: float | None = None,
    t2: float | None = None,
    step: int = 1,
) -> list[DialogueLine]:
    r"""Expand one line to frame-baked wave motion output.

    Args:
        line: The source dialogue line to expand.
        framerate: Frame timing data used to compute per-frame intervals.
        x0: Start X coordinate.
        x1: End X coordinate.
        y_base: Vertical baseline in pixels.
        amplitude: Peak vertical displacement in pixels.
        frequency: Number of full cycles over the duration.
        phase: Initial phase offset in degrees.
        t1: Optional window start in milliseconds.
        t2: Optional window end in milliseconds.
        step: Frame grouping step.

    Returns:
        An ordered list of ``DialogueLine`` objects, one per frame.
    """
    tw1, tw2 = resolve_window(t1, t2, line.end_time - line.start_time)
    phase_rad = math.radians(phase)

    def curve(t: float) -> tuple[float, float]:
        return wave_xy(t, x0, x1, y_base, amplitude, frequency, phase_rad)

    return apply_curve_fbf(line, framerate, curve, tw1, tw2, step)
