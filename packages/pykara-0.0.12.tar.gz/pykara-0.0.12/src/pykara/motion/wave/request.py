"""Queued frame-baked wave requests."""

from __future__ import annotations

from dataclasses import dataclass

from pykara.ass.types import DialogueLine
from pykara.timing import Framerate


@dataclass(frozen=True, slots=True)
class WaveFbfRequest:
    """Queued parameters for one frame-baked wave expansion."""

    x0: float
    x1: float
    y_base: float
    amplitude: float = 150.0
    frequency: float = 2.0
    phase: float = 0.0
    t1: float | None = None
    t2: float | None = None
    step: int = 1

    def expand(
        self,
        line: DialogueLine,
        framerate: Framerate | float,
    ) -> list[DialogueLine]:
        """Expand ``line`` using the queued wave configuration."""
        from pykara.motion.wave.fbf import wave_fbf_line

        return wave_fbf_line(
            line,
            framerate,
            self.x0,
            self.x1,
            self.y_base,
            self.amplitude,
            self.frequency,
            self.phase,
            self.t1,
            self.t2,
            self.step,
        )

