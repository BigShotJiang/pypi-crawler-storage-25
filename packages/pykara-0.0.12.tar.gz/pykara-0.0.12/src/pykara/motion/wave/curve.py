"""Pure wave (sinusoidal) curve math."""

from __future__ import annotations

import math

from pykara.math.curves import lerp


def wave_xy(
    t: float,
    x0: float,
    x1: float,
    y_base: float,
    amplitude: float = 150.0,
    frequency: float = 2.0,
    phase_rad: float = 0.0,
) -> tuple[float, float]:
    """Return the wave position at normalised progress *t*."""
    x = lerp(t, x0, x1)
    y = y_base + amplitude * math.sin(frequency * 2 * math.pi * t + phase_rad)
    return x, y

