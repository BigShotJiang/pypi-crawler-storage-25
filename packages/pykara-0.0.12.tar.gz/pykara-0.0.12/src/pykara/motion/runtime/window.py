"""Timing-window utilities shared by motion builders."""

from __future__ import annotations


def resolve_window(
    t1: float | None,
    t2: float | None,
    duration_ms: int,
) -> tuple[float, float]:
    """Resolve the active animation window from optional t1/t2 bounds."""
    if t1 is None or t2 is None:
        return 0.0, float(duration_ms)
    if t1 <= 0 and t2 <= 0:
        return 0.0, float(duration_ms)
    if t2 < t1:
        t1, t2 = t2, t1
    return float(t1), float(t2)


def progress(ms: float, tw1: float, tw2: float) -> float:
    """Return normalised progress in ``[0, 1]`` for a given time."""
    if ms <= tw1:
        return 0.0
    if ms >= tw2:
        return 1.0
    return (ms - tw1) / (tw2 - tw1)

