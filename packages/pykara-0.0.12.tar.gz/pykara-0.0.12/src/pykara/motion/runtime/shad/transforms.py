"""ASS transform utilities shared by shadow-trick motion effects."""

from __future__ import annotations


def zero_duration_transform(start_ms: int, tags: str) -> str:
    r"""Return one zero-duration ``\t(...)`` jump."""
    return rf"\t({start_ms},{start_ms},{tags})"

