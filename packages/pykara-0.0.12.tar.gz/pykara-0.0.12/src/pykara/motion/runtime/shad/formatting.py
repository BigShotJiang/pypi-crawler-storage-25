"""Formatting utilities for shadow-trick motion output."""

from __future__ import annotations

from pykara.motion.runtime.fbf.ass_tags import math_round


def fmt_shad_tags(xs: float, ys: float) -> str:
    r"""Return ``\xshad...\yshad...`` tags for float pixel offsets."""
    xs_r = math_round(xs, 2)
    ys_r = math_round(ys, 2)
    if xs_r == 0:
        xs_str = "0.001"
    elif xs_r == int(xs_r):
        xs_str = str(int(xs_r))
    else:
        xs_str = str(xs_r)
    ys_str = str(int(ys_r)) if ys_r == int(ys_r) else str(ys_r)
    return rf"\xshad{xs_str}\yshad{ys_str}"
