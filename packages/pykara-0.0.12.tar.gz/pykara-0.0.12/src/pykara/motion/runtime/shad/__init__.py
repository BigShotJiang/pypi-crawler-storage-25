"""Shared shadow-trick runtime modules."""
