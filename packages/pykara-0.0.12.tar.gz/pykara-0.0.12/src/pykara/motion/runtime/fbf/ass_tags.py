# ruff: noqa: D301 - File uses ASS tag backslash literals in all docstrings
"""ASS tag parsing, formatting, interpolation and state for FBF motion."""

from __future__ import annotations

import math
import re
from dataclasses import replace
from typing import cast

from pykara.ass.types import DialogueLine
from pykara.exceptions import PykaraTypeError, PykaraValidationError

MoveTag = tuple[float, float, float, float, float | None, float | None]
FadTag = tuple[str, float, float]
FadeTag = tuple[str, float, float, float, float, float, float, float]
AnyFadeTag = FadTag | FadeTag
TagValue = float | str | list[float]
MotionStateValue = TagValue | MoveTag | AnyFadeTag | int
MotionState = dict[str, MotionStateValue]
LINE_DURATION_KEY = "_line_duration"


def math_clamp(value: float, lower: float, upper: float) -> float:
    """Clamp one numeric value."""
    return min(max(value, lower), upper)


def math_round(value: float, decimals: int = 3) -> float:
    """Match the rounding semantics used by the original MoonScript code."""
    factor = 10 ** math.floor(decimals)
    rounded = math.floor(value * factor + 0.5)
    integer = math.floor(rounded + 0.5)
    return rounded / factor if decimals >= 1 else integer


def math_lerp(t: float, start: float, end: float) -> float:
    """Linearly interpolate between two values."""
    t = math_clamp(t, 0.0, 1.0)
    return (1.0 - t) * start + t * end


COLOR_TAGS = {"c", "2c", "3c", "4c"}
ALPHA_TAGS = {"alpha", "1a", "2a", "3a", "4a"}
CLIP_TAGS = {"clip", "iclip"}
NUMERIC_TAGS = {
    "fs",
    "fscx",
    "fscy",
    "fsp",
    "bord",
    "shad",
    "frz",
    "be",
    "blur",
    "xbord",
    "ybord",
    "xshad",
    "yshad",
    "frx",
    "fry",
    "fax",
    "fay",
}


def interpolate_alpha(t: float, start: str, end: str) -> str:
    """Interpolate two ASS alpha values."""
    start_match = re.search(r"[Hh]([0-9A-Fa-f]{2})", start)
    end_match = re.search(r"[Hh]([0-9A-Fa-f]{2})", end)
    if start_match is None or end_match is None:
        return start
    start_value = int(start_match.group(1), 16)
    end_value = int(end_match.group(1), 16)
    return f"&H{round(math_lerp(t, start_value, end_value)):02X}&"


def interpolate_color(t: float, start: str, end: str) -> str:
    """Interpolate two ASS BGR colors."""
    start_match = re.search(
        r"[Hh]([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})",
        start,
    )
    end_match = re.search(
        r"[Hh]([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})([0-9A-Fa-f]{2})",
        end,
    )
    if start_match is None or end_match is None:
        return start
    values = [
        round(
            math_lerp(
                t,
                int(start_match.group(index), 16),
                int(end_match.group(index), 16),
            )
        )
        for index in range(1, 4)
    ]
    return f"&H{values[0]:02X}{values[1]:02X}{values[2]:02X}&"


def interpolate_shape(t: float, start: str, end: str) -> str:
    """Interpolate matching vector clip shapes."""
    numbers_start = [float(value) for value in re.findall(r"-?\d[\d.]*", start)]
    numbers_end = [float(value) for value in re.findall(r"-?\d[\d.]*", end)]
    if len(numbers_start) != len(numbers_end):
        raise PykaraValidationError(
            "clip shape interpolation requires matching point counts"
        )

    index = 0

    def replace_number(_match: re.Match[str]) -> str:
        nonlocal index
        value = math_round(math_lerp(t, numbers_start[index], numbers_end[index]), 2)
        index += 1
        return _format_ass_number(value)

    return re.sub(r"-?\d[\d.]*", replace_number, start)


def interpolate_value(
    tag_name: str,
    t: float,
    start_value: TagValue,
    end_value: TagValue,
) -> TagValue:
    """Interpolate two values according to one ASS tag type."""
    if tag_name in COLOR_TAGS:
        return interpolate_color(t, str(start_value), str(end_value))
    if tag_name in ALPHA_TAGS:
        return interpolate_alpha(t, str(start_value), str(end_value))
    if tag_name in NUMERIC_TAGS:
        start_number = _numeric_tag_value(start_value)
        end_number = _numeric_tag_value(end_value)
        return math_round(
            math_lerp(t, start_number, end_number),
            2,
        )
    if tag_name in CLIP_TAGS:
        if (
            isinstance(start_value, list)
            and isinstance(end_value, list)
            and len(start_value) == 4
            and len(end_value) == 4
        ):
            return [
                math_round(math_lerp(t, start_value[index], end_value[index]), 2)
                for index in range(4)
            ]
        return interpolate_shape(t, str(start_value), str(end_value))
    return start_value


def get_time_in_interval(
    current_time: float,
    start_time: float,
    end_time: float,
    accel: float = 1.0,
) -> float:
    """Return normalized progress in one time window."""
    if current_time < start_time:
        return 0.0
    if current_time >= end_time:
        return 1.0
    return (current_time - start_time) ** accel / (end_time - start_time) ** accel


def _format_ass_number(value: float | int, decimals: int = 3) -> str:
    """Format a numeric literal without unnecessary trailing zeroes."""
    if isinstance(value, int):
        return str(value)
    rounded = math_round(float(value), decimals)
    if rounded == int(rounded):
        return str(int(rounded))
    text = f"{rounded:.{decimals}f}".rstrip("0").rstrip(".")
    return "0" if text == "-0" else text


def parse_t_tag(inner: str) -> tuple[float | None, float | None, float, str]:
    """Parse the contents of one ``\\t(...)`` payload."""
    match = re.match(
        r"^([-\d.]*),?([-\d.]*),?([-\d.]*),?(.+)$",
        inner.strip(),
        re.DOTALL,
    )
    if match is None:
        return None, None, 1.0, inner
    first, second, third, transform = match.groups()
    if first == "" and second == "" and third == "":
        return None, None, 1.0, transform
    if first != "" and second == "" and third == "":
        return None, None, float(first), transform
    if first != "" and second != "" and third == "":
        return float(first), float(second), 1.0, transform
    return float(first), float(second), float(third), transform


_ORDERED_TAGS = (
    "iclip",
    "clip",
    "alpha",
    "1a",
    "2a",
    "3a",
    "4a",
    "2c",
    "3c",
    "4c",
    "c",
    "xbord",
    "ybord",
    "xshad",
    "yshad",
    "fscx",
    "fscy",
    "fsp",
    "frz",
    "frx",
    "fry",
    "fax",
    "fay",
    "bord",
    "shad",
    "blur",
    "be",
    "fs",
)

_TAG_PATTERNS = {
    "fs": r"\\fs\s*([\d.]+)",
    "fscx": r"\\fscx\s*(-?[\d.eE+\-]+)",
    "fscy": r"\\fscy\s*(-?[\d.eE+\-]+)",
    "fsp": r"\\fsp\s*(-?[\d.eE+\-]+)",
    "frz": r"\\frz\s*(-?[\d.eE+\-]+)",
    "frx": r"\\frx\s*(-?[\d.eE+\-]+)",
    "fry": r"\\fry\s*(-?[\d.eE+\-]+)",
    "fax": r"\\fax\s*(-?[\d.eE+\-]+)",
    "fay": r"\\fay\s*(-?[\d.eE+\-]+)",
    "bord": r"\\bord\s*([\d.]+)",
    "shad": r"\\shad\s*([\d.]+)",
    "xbord": r"\\xbord\s*(-?[\d.eE+\-]+)",
    "ybord": r"\\ybord\s*(-?[\d.eE+\-]+)",
    "xshad": r"\\xshad\s*(-?[\d.eE+\-]+)",
    "yshad": r"\\yshad\s*(-?[\d.eE+\-]+)",
    "blur": r"\\blur\s*([\d.]+)",
    "be": r"\\be\s*([\d.]+)",
    "c": r"\\c\s*(&[Hh][0-9A-Fa-f]+&?)",
    "2c": r"\\2c\s*(&[Hh][0-9A-Fa-f]+&?)",
    "3c": r"\\3c\s*(&[Hh][0-9A-Fa-f]+&?)",
    "4c": r"\\4c\s*(&[Hh][0-9A-Fa-f]+&?)",
    "alpha": r"\\alpha\s*(&[Hh][0-9A-Fa-f]+&?)",
    "1a": r"\\1a\s*(&[Hh][0-9A-Fa-f]+&?)",
    "2a": r"\\2a\s*(&[Hh][0-9A-Fa-f]+&?)",
    "3a": r"\\3a\s*(&[Hh][0-9A-Fa-f]+&?)",
    "4a": r"\\4a\s*(&[Hh][0-9A-Fa-f]+&?)",
    "clip": r"\\clip\(([^)]+)\)",
    "iclip": r"\\iclip\(([^)]+)\)",
}
_PAREN_TAG_VALUE_TEMPLATE = r"\\{tag_name}\(([^)]*)\)"
_NUMBER_PATTERN = r"-?[\d.]+"
_ALPHA_VALUE_PATTERN = r"[Hh]([0-9A-Fa-f]{2})"
_INLINE_ALPHA_TAG_PATTERN = r"\\alpha&[Hh][0-9A-Fa-f]+&?"


def get_tag_value_from_block(block: str, tag_name: str) -> str | None:
    """Return the effective tag value from one raw override block."""
    pattern = _TAG_PATTERNS.get(tag_name)
    if pattern is None:
        return None
    matches = list(re.finditer(pattern, block))
    if not matches:
        return None
    return matches[-1].group(1)


def extract_all_tags_from_block(block: str) -> dict[str, str]:
    """Return the effective value of every known transformable tag."""
    extracted: dict[str, str] = {}
    for tag_name in _ORDERED_TAGS:
        value = get_tag_value_from_block(block, tag_name)
        if value is not None:
            extracted[tag_name] = value
    return extracted


def coerce_value(tag_name: str, raw: str) -> TagValue:
    """Convert one raw tag payload to the representation used internally."""
    if tag_name in NUMERIC_TAGS:
        return float(raw)
    if tag_name in CLIP_TAGS and re.search(r"[A-Za-z]", raw) is None:
        numbers = _parse_number_list(raw)
        if len(numbers) == 4:
            return numbers
    return raw


def split_text_blocks(text: str) -> list[tuple[str, str]]:
    """Split an ASS text body into alternating tag and text segments."""
    blocks: list[tuple[str, str]] = []
    pattern = re.compile(r"(\{[^}]*\})|([^{]+)")
    tags_acc = ""
    for match in pattern.finditer(text):
        if match.group(1) is not None:
            tags_acc += match.group(1)
            continue
        blocks.append((tags_acc, match.group(2)))
        tags_acc = ""
    if tags_acc:
        blocks.append((tags_acc, ""))
    return blocks


def extract_t_tags(tags_block: str) -> tuple[list[str], str]:
    """Extract all ``\\t(...)`` payloads from one override block."""
    inner_content = tags_block[1:-1] if tags_block.startswith("{") else tags_block
    payloads: list[str] = []

    def find_transforms(text: str) -> list[tuple[int, int, str]]:
        results: list[tuple[int, int, str]] = []
        index = 0
        while index < len(text):
            match = re.search(r"\\t\(", text[index:])
            if match is None:
                break
            start = index + match.start()
            position = index + match.end()
            depth = 1
            while position < len(text) and depth > 0:
                if text[position] == "(":
                    depth += 1
                elif text[position] == ")":
                    depth -= 1
                position += 1
            results.append((start, position, text[start:position]))
            index = position
        return results

    found = find_transforms(inner_content)
    cleaned = inner_content
    for start, end, full_transform in reversed(found):
        payloads.append(full_transform[3:-1])
        cleaned = cleaned[:start] + cleaned[end:]

    return list(reversed(payloads)), "{" + cleaned + "}"


def remove_tag_from_block(tags_block: str, tag_name: str) -> str:
    """Remove every instance of one tag from an override block."""
    inner = tags_block[1:-1] if tags_block.startswith("{") else tags_block
    pattern = _TAG_PATTERNS.get(tag_name)
    if pattern is None:
        return tags_block
    return "{" + re.sub(pattern, "", inner) + "}"


def _format_tag_assignment(tag_name: str, value: TagValue) -> str:
    """Format one ASS tag assignment without outer braces."""
    prefix = "\\" + tag_name
    if tag_name in CLIP_TAGS:
        if isinstance(value, list):
            joined = ",".join(_format_ass_number(component, 2) for component in value)
            return f"{prefix}({joined})"
        return f"{prefix}({value})"
    if tag_name in COLOR_TAGS or tag_name in ALPHA_TAGS:
        return f"{prefix}{value}"
    if isinstance(value, float):
        return f"{prefix}{_format_ass_number(value, 2)}"
    return f"{prefix}{value}"


def replace_tag_in_block(tags_block: str, tag_name: str, new_value: object) -> str:
    """Replace one effective tag with a new value."""
    block = remove_tag_from_block(tags_block, tag_name)
    formatted_value = cast(TagValue, new_value)
    return "{" + block[1:-1] + _format_tag_assignment(tag_name, formatted_value) + "}"


def remove_fad_or_fade(tags_block: str) -> str:
    """Remove ``\\fad`` and ``\\fade`` from one block."""
    inner = tags_block[1:-1] if tags_block.startswith("{") else tags_block
    inner = re.sub(r"\\fad\([^)]*\)", "", inner)
    inner = re.sub(r"\\fade\([^)]*\)", "", inner)
    return "{" + inner + "}"


def remove_move(tags_block: str) -> str:
    """Remove ``\\move`` from one block."""
    inner = tags_block[1:-1] if tags_block.startswith("{") else tags_block
    return "{" + re.sub(r"\\move\([^)]*\)", "", inner) + "}"


def _parse_number_list(raw: str) -> list[float]:
    """Parse every numeric literal from one raw ASS payload."""
    return [float(value) for value in re.findall(_NUMBER_PATTERN, raw)]


def _extract_parenthesized_numbers(block: str, tag_name: str) -> list[float] | None:
    """Extract the numeric contents of one ``\\tag(...)`` payload."""
    pattern = _PAREN_TAG_VALUE_TEMPLATE.format(tag_name=tag_name)
    match = re.search(pattern, block)
    if match is None:
        return None
    return _parse_number_list(match.group(1))


def _relative_step_window(
    step_start_ms: float,
    step_end_ms: float,
    line_start_ms: int,
) -> tuple[float, float, float]:
    """Return rounded line-relative bounds for one grouped frame window."""
    step_start = round_line_time(step_start_ms - line_start_ms)
    step_end = round_line_time(step_end_ms - line_start_ms)
    return step_start, step_end, step_end - step_start


def alpha_from_tag(raw_alpha: str | None) -> float:
    """Parse one ASS alpha payload to a numeric byte value."""
    if raw_alpha is None:
        return 0.0
    match = re.search(_ALPHA_VALUE_PATTERN, raw_alpha)
    if match is None:
        return 0.0
    return float(int(match.group(1), 16))


def _format_alpha(value: float) -> str:
    """Format one numeric alpha byte as an ASS alpha literal."""
    return f"&H{round(value):02X}&"


def _set_alpha(tags_block: str, alpha_value: str, transform_suffix: str = "") -> str:
    """Replace fade state with one explicit alpha tag and optional transform."""
    block_without_fade = remove_fad_or_fade(tags_block)
    inner = re.sub(_INLINE_ALPHA_TAG_PATTERN, "", block_without_fade[1:-1])
    return "{" + inner + rf"\alpha{alpha_value}{transform_suffix}" + "}"


def _normalize_move_times(
    line_duration: float,
    t1: float | None,
    t2: float | None,
) -> tuple[float, float]:
    """Normalize ASS move timing to an explicit active window."""
    if t1 is not None and t2 is not None and t1 > t2:
        t1, t2 = t2, t1
    elif t1 is None or t2 is None:
        t1, t2 = 0.0, 0.0
    if t1 <= 0 and t2 <= 0:
        return 0.0, line_duration
    return t1, t2


def _fad_from_numbers(numbers: list[float]) -> FadTag | None:
    """Build one short fade tuple from parsed numeric values."""
    if len(numbers) != 2:
        return None
    return ("fad", numbers[0], numbers[1])


def _fade_from_numbers(numbers: list[float]) -> FadeTag | None:
    """Build one full fade tuple from parsed numeric values."""
    if len(numbers) != 7:
        return None
    return (
        "fade",
        numbers[0],
        numbers[1],
        numbers[2],
        numbers[3],
        numbers[4],
        numbers[5],
        numbers[6],
    )


def _move_from_numbers(numbers: list[float]) -> MoveTag | None:
    """Build one move tuple from parsed numeric values."""
    if len(numbers) < 4:
        return None
    if len(numbers) >= 6:
        return (
            numbers[0],
            numbers[1],
            numbers[2],
            numbers[3],
            numbers[4],
            numbers[5],
        )
    return (
        numbers[0],
        numbers[1],
        numbers[2],
        numbers[3],
        None,
        None,
    )


def _resolved_tag_value(
    data: MotionState,
    tag_name: str,
    raw_end_value: str,
    progress: float,
) -> TagValue:
    """Resolve one transformable tag to its value at ``progress``."""
    start_value = cast(
        TagValue,
        data.get(tag_name, coerce_value(tag_name, raw_end_value)),
    )
    end_value = coerce_value(tag_name, raw_end_value)
    result = interpolate_value(tag_name, progress, start_value, end_value)
    if isinstance(result, float):
        return math_round(result, 2)
    return result


def set_pos(tags_block: str, x: float, y: float) -> str:
    """Set ``\\pos`` and drop any existing ``\\pos`` or ``\\move``."""
    inner = tags_block[1:-1] if tags_block.startswith("{") else tags_block
    inner = re.sub(r"\\pos\([^)]*\)", "", inner)
    inner = re.sub(r"\\move\([^)]*\)", "", inner)
    inner += rf"\pos({_format_ass_number(x)},{_format_ass_number(y)})"
    return "{" + inner + "}"


def inject_pos(line: DialogueLine, x: float, y: float) -> DialogueLine:
    r"""Return a copy of ``line`` with ``\pos`` injected into the first tag block."""
    match = re.search(r"\{[^}]*\}", line.text)
    if match is not None:
        updated_text = (
            line.text[: match.start()]
            + set_pos(match.group(0), x, y)
            + line.text[match.end() :]
        )
        return replace(line, text=updated_text)
    return replace(line, text=set_pos("{}", x, y) + line.text)


def set_move(
    tags_block: str,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    t1: float,
    t2: float,
) -> str:
    """Set ``\\move`` and drop any existing ``\\pos`` or ``\\move``."""
    inner = tags_block[1:-1] if tags_block.startswith("{") else tags_block
    inner = re.sub(r"\\pos\([^)]*\)", "", inner)
    inner = re.sub(r"\\move\([^)]*\)", "", inner)
    inner += (
        rf"\move({_format_ass_number(x1)},{_format_ass_number(y1)},"
        rf"{_format_ass_number(x2)},{_format_ass_number(y2)},"
        rf"{_format_ass_number(t1)},{_format_ass_number(t2)})"
    )
    return "{" + inner + "}"


def get_tag_move(
    current_time: float,
    line_duration: float,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    t1: float | None,
    t2: float | None,
) -> tuple[float, float, float]:
    """Return position and normalized progress for one ``\\move``."""
    t1, t2 = _normalize_move_times(line_duration, t1, t2)

    t = get_time_in_interval(current_time, t1, t2)
    x = math_round((1.0 - t) * x1 + t * x2, 3)
    y = math_round((1.0 - t) * y1 + t * y2, 3)
    return x, y, t


def get_alpha_interpolation(
    current_time: float,
    t1: float,
    t2: float,
    t3: float,
    t4: float,
    a1: float,
    a2: float,
    a3: float,
) -> float:
    """Interpolate a three-state alpha curve."""
    if current_time < t1:
        return a1
    if current_time < t2:
        fraction = (current_time - t1) / (t2 - t1)
        return a1 * (1 - fraction) + a2 * fraction
    if current_time < t3:
        return a2
    if current_time < t4:
        fraction = (current_time - t3) / (t4 - t3)
        return a2 * (1 - fraction) + a3 * fraction
    return a3


def get_tag_fade(
    current_time: float,
    line_duration: float,
    default_alpha: float,
    fade_data: AnyFadeTag,
) -> float:
    """Return the active alpha value for ``\\fad`` or ``\\fade``."""
    kind = fade_data[0]
    if kind == "fad":
        _, fade_in, fade_out = cast(FadTag, fade_data)
        alpha_1, alpha_2, alpha_3 = 255.0, 0.0, 255.0
        t1 = 0.0
        t2 = float(fade_in)
        t3 = line_duration - float(fade_out)
        t4 = line_duration
    else:
        full_fade = cast(FadeTag, fade_data)
        (
            _,
            alpha_1,
            alpha_2,
            alpha_3,
            t1,
            t2,
            t3,
            t4,
        ) = full_fade

    return get_alpha_interpolation(
        current_time,
        float(t1),
        float(t2),
        float(t3),
        float(t4),
        float(alpha_1),
        default_alpha if default_alpha else float(alpha_2),
        float(alpha_3),
    )


def calc_accel(t1: float, t2: float, t3: float) -> float:
    """Approximate one transform's acceleration for a shortened time window."""
    denominator = t3 - t1
    if denominator == 0:
        return 1.0
    ratio = (t2 - t1) / denominator
    if ratio <= 0 or ratio >= 1:
        return 1.0
    try:
        accel = math.log(ratio) / math.log(0.5)
    except (ValueError, ZeroDivisionError):
        return 1.0
    if math.isnan(accel) or math.isinf(accel):
        return 1.0
    return math_round(math_clamp(accel, 0.01, 100.0))


def round_line_time(value: float) -> float:
    """Round line-relative times to the nearest 10ms."""
    return math.floor((value + 5) / 10) * 10


def _numeric_tag_value(value: TagValue) -> float:
    """Return a float value for numeric tags."""
    if isinstance(value, list):
        raise PykaraTypeError("numeric tag interpolation does not accept list values")
    return float(value)


def _line_duration_from_state(data: MotionState, fallback: float) -> int:
    """Return the cached line duration from one motion-state mapping."""
    value = data.get(LINE_DURATION_KEY, int(fallback))
    return int(cast(int, value))


def collect_initial_data(text: str) -> MotionState:
    """Collect the effective pre-transform tag state of one line."""
    data: MotionState = {}
    raw_blocks = re.findall(r"\{[^}]*\}", text)
    for raw_block in raw_blocks:
        _, clean_block = extract_t_tags(raw_block)
        block = clean_block[1:-1]

        for tag_name in _ORDERED_TAGS:
            value = get_tag_value_from_block(block, tag_name)
            if value is not None:
                data[tag_name] = coerce_value(tag_name, value)

        move_numbers = _extract_parenthesized_numbers(block, "move")
        if move_numbers is not None:
            move = _move_from_numbers(move_numbers)
            if move is not None:
                data["move"] = move

        pos_numbers = _extract_parenthesized_numbers(block, "pos")
        if pos_numbers is not None:
            numbers = pos_numbers
            if len(numbers) >= 2:
                data["pos"] = numbers[:2]

        fad_numbers = _extract_parenthesized_numbers(block, "fad")
        if fad_numbers is not None:
            parsed_fad = _fad_from_numbers(fad_numbers)
            if parsed_fad is not None:
                data["fad"] = parsed_fad

        fade_numbers = _extract_parenthesized_numbers(block, "fade")
        if fade_numbers is not None:
            parsed_fade = _fade_from_numbers(fade_numbers)
            if parsed_fade is not None:
                data["fade"] = parsed_fade

    return data


def lerp_tag_transform(
    current_time: float,
    step: int,
    step_start_ms: float,
    step_end_ms: float,
    line_start_ms: int,
    line_duration: int,
    data: MotionState,
    tags_block: str,
) -> str:
    """Resolve or shorten every transform inside one override block."""
    while True:
        transform_payloads, tags_block = extract_t_tags(tags_block)
        if not transform_payloads:
            break

        payload = transform_payloads[0]
        remaining_payloads = transform_payloads[1:]
        start_time, end_time, accel, transform = parse_t_tag(payload)

        effective_start = start_time if start_time is not None else 0.0
        effective_end = end_time if end_time is not None else float(line_duration)
        inner_tags = extract_all_tags_from_block(transform)

        if step > 1:
            step_start, step_end, step_duration = _relative_step_window(
                step_start_ms,
                step_end_ms,
                line_start_ms,
            )
            step_mid = (step_start + step_end) * 0.5

            t_start = get_time_in_interval(
                step_start, effective_start, effective_end, accel
            )
            t_mid = get_time_in_interval(
                step_mid, effective_start, effective_end, accel
            )
            t_end = get_time_in_interval(
                step_end, effective_start, effective_end, accel
            )
            accel_step = calc_accel(t_start, t_mid, t_end)

            end_fragments: list[str] = []
            for tag_name, raw_end_value in inner_tags.items():
                current_value = _resolved_tag_value(
                    data,
                    tag_name,
                    raw_end_value,
                    t_start,
                )
                step_end_value = _resolved_tag_value(
                    data,
                    tag_name,
                    raw_end_value,
                    t_end,
                )

                data[tag_name] = step_end_value
                tags_block = replace_tag_in_block(tags_block, tag_name, current_value)
                end_fragments.append(_format_tag_assignment(tag_name, step_end_value))

            if end_fragments:
                transform_start = max(effective_start - step_start, 0)
                transform_end = min(effective_end - step_start, step_duration)
                shortened = (
                    rf"\gt({_format_ass_number(transform_start)},"
                    rf"{_format_ass_number(transform_end)},"
                    rf"{_format_ass_number(accel_step)}," + "".join(end_fragments) + ")"
                )
                tags_block = "{" + tags_block[1:-1] + shortened + "}"
        else:
            t = get_time_in_interval(
                current_time, effective_start, effective_end, accel
            )
            for tag_name, raw_end_value in inner_tags.items():
                result = _resolved_tag_value(data, tag_name, raw_end_value, t)
                data[tag_name] = result
                tags_block = replace_tag_in_block(tags_block, tag_name, result)

        for remaining in remaining_payloads:
            tags_block = "{" + tags_block[1:-1] + rf"\t({remaining})" + "}"

    if step > 1:
        tags_block = tags_block.replace(r"\gt(", r"\t(")
    return tags_block


def lerp_tag_move(
    current_time: float,
    step: int,
    step_start_ms: float,
    step_end_ms: float,
    line_start_ms: int,
    data: MotionState,
    tags_block: str,
) -> str:
    """Resolve or shorten the first-block ``\\move`` of one line."""
    if "move" not in data:
        return tags_block

    move = data["move"]
    if not isinstance(move, tuple) or len(move) != 6:
        return tags_block
    x1, y1, x2, y2, t1_move, t2_move = move
    line_duration = _line_duration_from_state(data, step_end_ms - line_start_ms)
    normalized_t1, normalized_t2 = _normalize_move_times(
        line_duration,
        t1_move,
        t2_move,
    )

    if step > 1:
        step_start, step_end, step_duration = _relative_step_window(
            step_start_ms,
            step_end_ms,
            line_start_ms,
        )

        rx1, ry1, progress_start = get_tag_move(
            step_start,
            line_duration,
            x1,
            y1,
            x2,
            y2,
            normalized_t1,
            normalized_t2,
        )
        rx2, ry2, progress_end = get_tag_move(
            step_end,
            line_duration,
            x1,
            y1,
            x2,
            y2,
            normalized_t1,
            normalized_t2,
        )

        if progress_start == 0 and progress_end == 0:
            data["pos"] = [rx1, ry1]
            del data["move"]
            return set_pos(tags_block, rx1, ry1)
        if progress_start == 1 and progress_end == 1:
            data["pos"] = [rx2, ry2]
            del data["move"]
            return set_pos(tags_block, rx2, ry2)

        move_start = max(normalized_t1 - step_start, 0)
        move_end = min(normalized_t2 - step_start, step_duration)
        data["move"] = (rx1, ry1, rx2, ry2, move_start, move_end)
        data["pos"] = [rx1, ry1]
        return set_move(tags_block, rx1, ry1, rx2, ry2, move_start, move_end)

    x, y, _ = get_tag_move(
        current_time,
        line_duration,
        x1,
        y1,
        x2,
        y2,
        normalized_t1,
        normalized_t2,
    )
    data["pos"] = [x, y]
    del data["move"]
    return set_pos(tags_block, x, y)


def lerp_tag_fade(
    current_time: float,
    step: int,
    step_start_ms: float,
    step_end_ms: float,
    line_start_ms: int,
    line_duration: int,
    data: MotionState,
    tags_block: str,
) -> str:
    """Resolve ``\\fad``/``\\fade`` into alpha output."""
    fade_data = data.get("fad") or data.get("fade")
    if fade_data is None or not isinstance(fade_data, tuple):
        return tags_block
    typed_fade_data = cast(AnyFadeTag, fade_data)

    base_alpha = alpha_from_tag(get_tag_value_from_block(tags_block[1:-1], "alpha"))

    if step > 1:
        step_start, step_end, _ = _relative_step_window(
            step_start_ms,
            step_end_ms,
            line_start_ms,
        )
        alpha_start = get_tag_fade(
            step_start,
            line_duration,
            base_alpha,
            typed_fade_data,
        )
        alpha_end = get_tag_fade(
            step_end,
            line_duration,
            base_alpha,
            typed_fade_data,
        )
        tags_block = _set_alpha(
            tags_block,
            _format_alpha(alpha_start),
            rf"\t(\alpha{_format_alpha(alpha_end)})",
        )
    else:
        alpha_value = get_tag_fade(
            current_time,
            line_duration,
            base_alpha,
            typed_fade_data,
        )
        tags_block = _set_alpha(tags_block, _format_alpha(alpha_value))

    data.pop("fad", None)
    data.pop("fade", None)
    return tags_block
