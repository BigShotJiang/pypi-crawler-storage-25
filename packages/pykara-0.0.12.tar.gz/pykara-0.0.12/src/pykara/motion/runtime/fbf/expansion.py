"""Frame-baked expansion utilities built on top of ASS tag utilities."""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import replace

from pykara.ass.types import AssDocument, DialogueLine, EventType
from pykara.exceptions import PykaraValidationError
from pykara.motion.runtime.fbf.ass_tags import (
    LINE_DURATION_KEY,
    collect_initial_data,
    inject_pos,
    lerp_tag_fade,
    lerp_tag_move,
    lerp_tag_transform,
    math_round,
    split_text_blocks,
)
from pykara.motion.runtime.fbf.timeline import coerce_framerate
from pykara.motion.runtime.window import progress
from pykara.timing import Framerate, resolve_framerate

_FBF_FRAMERATE_ERROR = (
    "frame-baked expansion requires explicit timecodes or PlaybackFPS"
)


def _line_duration(line: DialogueLine) -> int:
    """Return one line duration in milliseconds."""
    return line.end_time - line.start_time


def apply_curve_fbf(
    line: DialogueLine,
    framerate: Framerate | float,
    curve_fn: Callable[[float], tuple[float, float]],
    tw1: float,
    tw2: float,
    step: int = 1,
) -> list[DialogueLine]:
    r"""Expand one dialogue line to frame-baked output driven by *curve_fn*."""
    start_time = line.start_time
    baked_lines = line_to_fbf(line, framerate, step)
    result: list[DialogueLine] = []
    for baked in baked_lines:
        current_time = math.floor((baked.start_time + baked.end_time) / 2) - start_time
        t = progress(current_time, tw1, tw2)
        x, y = curve_fn(t)
        result.append(inject_pos(baked, math_round(x, 3), math_round(y, 3)))
    return result


def line_to_fbf(
    line: DialogueLine,
    framerate: Framerate | float,
    step: int = 1,
) -> list[DialogueLine]:
    """Convert one ASS event into frame-by-frame static events."""
    if step < 1:
        raise PykaraValidationError("frame-baked expansion step must be >= 1")

    mapping = coerce_framerate(framerate)
    start_time = line.start_time
    end_time = line.end_time
    line_duration = _line_duration(line)
    text_blocks = split_text_blocks(line.text)

    start_frame = mapping.frame_at_time(start_time)
    end_frame = mapping.frame_at_time(end_time)
    if start_frame >= end_frame:
        return [line]

    base_data = collect_initial_data(line.text)
    base_data[LINE_DURATION_KEY] = line_duration
    result_lines: list[DialogueLine] = []

    for frame_index in range(start_frame, end_frame, step):
        step_start = mapping.time_at_frame(frame_index)
        step_end = mapping.time_at_frame(min(frame_index + step, end_frame))
        current_time = math.floor((step_start + step_end) / 2) - start_time

        current_data = base_data.copy()
        rebuilt: list[str] = []
        first_block = True

        for tag_block, text_content in text_blocks:
            current_block = tag_block
            if current_block:
                if first_block:
                    current_block = lerp_tag_move(
                        current_time,
                        step,
                        step_start,
                        step_end,
                        start_time,
                        current_data,
                        current_block,
                    )
                    first_block = False

                current_block = lerp_tag_transform(
                    current_time,
                    step,
                    step_start,
                    step_end,
                    start_time,
                    line_duration,
                    current_data,
                    current_block,
                )
                current_block = lerp_tag_fade(
                    current_time,
                    step,
                    step_start,
                    step_end,
                    start_time,
                    line_duration,
                    current_data,
                    current_block,
                )
            else:
                first_block = False

            rebuilt.append(current_block + text_content)

        result_lines.append(
            replace(
                line,
                start_time=step_start,
                end_time=step_end,
                text="".join(rebuilt),
            )
        )

    return result_lines


def expand_document_to_fbf(
    document: AssDocument,
    framerate: Framerate | float | None = None,
    step: int = 1,
    *,
    event_types: tuple[EventType, ...] = (EventType.DIALOGUE,),
) -> AssDocument:
    """Return a new document with selected events expanded to FBF output."""
    resolved_framerate = resolve_framerate(document, framerate)
    if resolved_framerate is None:
        raise PykaraValidationError(_FBF_FRAMERATE_ERROR)
    expanded_events: list[DialogueLine] = []
    for event in document.events:
        if event.event_type in event_types:
            expanded_events.extend(line_to_fbf(event, resolved_framerate, step))
        else:
            expanded_events.append(event)
    return replace(document, events=expanded_events)
