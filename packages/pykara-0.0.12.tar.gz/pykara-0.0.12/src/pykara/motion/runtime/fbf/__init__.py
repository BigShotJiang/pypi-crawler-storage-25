"""Shared frame-baked motion runtime modules."""
