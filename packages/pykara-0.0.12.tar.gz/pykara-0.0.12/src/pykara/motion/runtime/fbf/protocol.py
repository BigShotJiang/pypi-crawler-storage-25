"""Contracts for frame-baked motion requests."""

from __future__ import annotations

from typing import Protocol

from pykara.ass.types import DialogueLine
from pykara.timing import Framerate


class FbfRequest(Protocol):
    """One queued frame-baked effect that can expand a rendered line."""

    def expand(
        self,
        line: DialogueLine,
        framerate: Framerate | float,
    ) -> list[DialogueLine]:
        """Expand ``line`` into one or more baked output events."""
        ...

