"""Shared runtime utilities for motion effects."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pykara.engine.protocols import MotionRuntime


def output_interval_duration(runtime: MotionRuntime) -> int:
    """Return the current output interval duration in milliseconds."""
    output_start, output_end = runtime.output_interval()
    return output_end - output_start


def motion_anchor(runtime: MotionRuntime) -> tuple[int, int]:
    """Return the base anchor for motion effects in the current scope."""
    assert runtime.line is not None
    if runtime.char is not None:
        return runtime.char.abs_center, runtime.line.y
    if runtime.word is not None:
        return runtime.word.abs_center, runtime.line.y
    if runtime.syl is not None:
        return runtime.syl.abs_center, runtime.syl.abs_middle
    return runtime.line.x, runtime.line.y
