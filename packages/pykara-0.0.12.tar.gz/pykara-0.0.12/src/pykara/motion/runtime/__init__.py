"""Shared runtime support for motion effects."""

