"""Shadow-trick Bezier motion builder."""

from __future__ import annotations

from pykara.math.curves import sample_curve
from pykara.motion.bezier.curve import bezier_xy
from pykara.motion.runtime.shad.formatting import fmt_shad_tags
from pykara.motion.runtime.shad.transforms import zero_duration_transform
from pykara.motion.runtime.window import resolve_window


def build_shad_bezier(
    duration_ms: int,
    ax: float,
    ay: float,
    points: list[tuple[float, float]],
    t1: float | None = None,
    t2: float | None = None,
    segments: int = 16,
) -> str:
    r"""Return ``\t(...)`` segments for a Bezier motion using the shadow trick.

    Args:
        duration_ms: Line interval duration in milliseconds.
        ax: Anchor X coordinate (from ``\pos``).
        ay: Anchor Y coordinate (from ``\pos``).
        points: List of 3 or 4 ``(x, y)`` control points.
        t1: Optional window start in milliseconds.
        t2: Optional window end in milliseconds.
        segments: Number of linear approximation segments.  Defaults to 16
            for quadratic and 32 for cubic curves.

    Returns:
        A string of concatenated ``\t(ms0,ms1,\xshad...\yshad...)`` tags.
    """
    tw1, tw2 = resolve_window(t1, t2, duration_ms)

    def curve(t: float) -> tuple[float, float]:
        return bezier_xy(t, points)

    raw_segments = sample_curve(curve, segments, tw1, tw2)
    fragments: list[str] = []
    for ms0, ms1, x0, y0, x1_pt, y1_pt in raw_segments:
        t0, t1 = int(ms0), int(ms1)
        shad0 = fmt_shad_tags(x0 - ax, y0 - ay)
        shad1 = fmt_shad_tags(x1_pt - ax, y1_pt - ay)
        fragments.append(zero_duration_transform(t0, shad0))
        fragments.append(rf"\t({t0},{t1},{shad1})")
    return "".join(fragments)
