"""Frame-baked Bezier motion builder."""

from __future__ import annotations

from pykara.ass.types import DialogueLine
from pykara.motion.bezier.curve import bezier_xy
from pykara.motion.runtime.fbf.expansion import apply_curve_fbf
from pykara.motion.runtime.window import resolve_window
from pykara.timing import Framerate


def bezier_fbf_line(
    line: DialogueLine,
    framerate: Framerate | float,
    points: list[tuple[float, float]],
    t1: float | None = None,
    t2: float | None = None,
    step: int = 1,
) -> list[DialogueLine]:
    r"""Expand one line to frame-baked Bezier motion output.

    Args:
        line: The source dialogue line to expand.
        framerate: Frame timing data used to compute per-frame intervals.
        points: List of 3 or 4 ``(x, y)`` control points.
        t1: Optional window start in milliseconds.
        t2: Optional window end in milliseconds.
        step: Frame grouping step.

    Returns:
        An ordered list of ``DialogueLine`` objects, one per frame.
    """
    tw1, tw2 = resolve_window(t1, t2, line.end_time - line.start_time)

    def curve(t: float) -> tuple[float, float]:
        return bezier_xy(t, points)

    return apply_curve_fbf(line, framerate, curve, tw1, tw2, step)
