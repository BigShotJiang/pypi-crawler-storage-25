"""Bezier motion effect."""
