"""Queued frame-baked Bezier requests."""

from __future__ import annotations

from dataclasses import dataclass

from pykara.ass.types import DialogueLine
from pykara.timing import Framerate


@dataclass(frozen=True, slots=True)
class BezierFbfRequest:
    """Queued parameters for one frame-baked Bezier expansion."""

    points: tuple[tuple[float, float], ...]
    t1: float | None = None
    t2: float | None = None
    step: int = 1

    def expand(
        self,
        line: DialogueLine,
        framerate: Framerate | float,
    ) -> list[DialogueLine]:
        """Expand ``line`` using the queued Bezier configuration."""
        from pykara.motion.bezier.fbf import bezier_fbf_line

        return bezier_fbf_line(
            line,
            framerate,
            list(self.points),
            self.t1,
            self.t2,
            self.step,
        )

