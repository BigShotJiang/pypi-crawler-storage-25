"""Pure Bezier curve math."""

from __future__ import annotations

from pykara.exceptions import PykaraValidationError


def bezier_xy(
    t: float,
    points: list[tuple[float, float]],
) -> tuple[float, float]:
    """Return the Bezier curve position at normalised progress *t*."""
    if len(points) == 3:
        x1, y1 = points[0]
        x2, y2 = points[1]
        x3, y3 = points[2]
        mt = 1 - t
        return (
            mt * mt * x1 + 2 * t * mt * x2 + t * t * x3,
            mt * mt * y1 + 2 * t * mt * y2 + t * t * y3,
        )
    if len(points) == 4:
        x1, y1 = points[0]
        x2, y2 = points[1]
        x3, y3 = points[2]
        x4, y4 = points[3]
        mt = 1 - t
        return (
            mt**3 * x1 + 3 * t * mt**2 * x2 + 3 * t**2 * mt * x3 + t**3 * x4,
            mt**3 * y1 + 3 * t * mt**2 * y2 + 3 * t**2 * mt * y3 + t**3 * y4,
        )
    raise PykaraValidationError(
        f"motion.bezier.bezier_xy() requires 3 or 4 control points, got {len(points)}"
    )

