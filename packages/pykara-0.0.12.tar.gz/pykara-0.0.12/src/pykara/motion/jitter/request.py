"""Queued frame-baked jitter requests."""

from __future__ import annotations

from dataclasses import dataclass

from pykara.ass.types import DialogueLine
from pykara.timing import Framerate


@dataclass(frozen=True, slots=True)
class JitterFbfRequest:
    """Queued parameters for one frame-baked jitter expansion."""

    x: float
    y: float
    left: int
    right: int
    up: int
    down: int
    period: int
    seed: int = 0

    def expand(
        self,
        line: DialogueLine,
        framerate: Framerate | float,
    ) -> list[DialogueLine]:
        """Expand ``line`` using the queued jitter configuration."""
        from pykara.motion.jitter.fbf import jitter_fbf_line

        return jitter_fbf_line(
            line,
            framerate,
            self.x,
            self.y,
            self.left,
            self.right,
            self.up,
            self.down,
            self.period,
            self.seed,
        )

