"""Jitter motion utilities."""
