"""Shadow-trick jitter utilities."""

from __future__ import annotations

from pykara.motion.jitter.engine import iter_jitter_offsets
from pykara.motion.runtime.shad.transforms import zero_duration_transform

_JITTER_SCALE = 8
SHAD_SETUP_FRAGMENT = r"\alpha&HFF&\4a&H00&\ko0\xshad0.001\yshad0"


def normalize_jitter_amplitude(value: int) -> int:
    """Normalize one jitter amplitude to 1/8 px units."""
    return abs(value) * _JITTER_SCALE


def format_shadow_component(value: int) -> str:
    """Format one 1/8 px shadow offset as an ASS numeric literal."""
    if value == 0:
        return "0"
    sign = "-" if value < 0 else ""
    whole, fraction = divmod(abs(value), 8)
    if fraction == 0:
        return f"{sign}{whole}"
    return f"{sign}{whole}.{fraction * 125:03d}".rstrip("0")


def format_shadow_tags(x_offset: int, y_offset: int) -> str:
    """Return one ASS tag payload for the current jitter offset."""
    x_component = "0.001" if x_offset == 0 else format_shadow_component(x_offset)
    y_component = format_shadow_component(y_offset)
    return rf"\xshad{x_component}\yshad{y_component}"


def build_shad_jitter(
    duration_ms: int,
    left: int,
    right: int,
    up: int,
    down: int,
    period_ms: int,
    seed: int,
) -> str:
    """Return deterministic zero-duration jitter hops for one interval."""
    if duration_ms <= 0:
        return ""

    normalized_left = normalize_jitter_amplitude(left)
    normalized_right = normalize_jitter_amplitude(right)
    normalized_up = normalize_jitter_amplitude(up)
    normalized_down = normalize_jitter_amplitude(down)
    fragments: list[str] = []
    for current_ms, x_offset, y_offset in iter_jitter_offsets(
        duration_ms,
        period_ms,
        normalized_left,
        normalized_right,
        normalized_up,
        normalized_down,
        seed,
    ):
        fragments.append(
            zero_duration_transform(
                current_ms,
                format_shadow_tags(x_offset, y_offset),
            )
        )

    return "".join(fragments)
