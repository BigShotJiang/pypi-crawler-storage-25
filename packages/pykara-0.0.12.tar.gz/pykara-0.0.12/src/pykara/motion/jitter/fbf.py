"""Frame-baked jitter expansion utilities."""

from __future__ import annotations

import math

from pykara.ass.types import DialogueLine
from pykara.exceptions import PykaraValidationError
from pykara.motion.jitter.engine import jitter_offsets_at
from pykara.motion.runtime.fbf.ass_tags import (
    collect_initial_data,
    get_tag_move,
    inject_pos,
)
from pykara.motion.runtime.fbf.expansion import line_to_fbf
from pykara.timing import Framerate

_MOVE_WITH_JITTER_ERROR = (
    "frame-baked jitter cannot be combined with \\move"
)


def _resolved_line_pos(
    line: DialogueLine,
    default_x: float,
    default_y: float,
) -> tuple[float, float]:
    """Return the effective line position already baked into ``line``."""
    data = collect_initial_data(line.text)
    pos = data.get("pos")
    if isinstance(pos, list) and len(pos) >= 2:
        return float(pos[0]), float(pos[1])

    move = data.get("move")
    if isinstance(move, tuple) and len(move) == 6:
        x1, y1, x2, y2, t1, t2 = move
        midpoint = (line.end_time - line.start_time) * 0.5
        x, y, _ = get_tag_move(
            midpoint,
            line.end_time - line.start_time,
            x1,
            y1,
            x2,
            y2,
            t1,
            t2,
        )
        return x, y

    return default_x, default_y


def validate_jitter_line(line: DialogueLine) -> None:
    """Reject line content that is incompatible with baked jitter."""
    if "move" in collect_initial_data(line.text):
        raise PykaraValidationError(_MOVE_WITH_JITTER_ERROR)


def jitter_fbf_line(
    line: DialogueLine,
    framerate: Framerate | float,
    x: float,
    y: float,
    left: int = 10,
    right: int = 10,
    up: int = 10,
    down: int = 10,
    period_ms: int = 100,
    seed: int = 0,
    step: int = 1,
) -> list[DialogueLine]:
    r"""Expand one line to deterministic ``\pos`` jittered FBF output."""
    if step < 1:
        raise PykaraValidationError("frame-baked jitter step must be >= 1")

    validate_jitter_line(line)
    period_ms = period_ms or 1
    start_time = line.start_time
    baked_lines = line_to_fbf(line, framerate, step)
    result_lines: list[DialogueLine] = []

    for baked_line in baked_lines:
        current_time = math.floor((baked_line.start_time + baked_line.end_time) / 2) - (
            start_time
        )
        x_offset, y_offset = jitter_offsets_at(
            current_time,
            period_ms,
            left,
            right,
            up,
            down,
            seed,
        )
        base_x, base_y = _resolved_line_pos(baked_line, x, y)
        result_lines.append(
            inject_pos(baked_line, base_x + x_offset, base_y + y_offset)
        )

    return result_lines
