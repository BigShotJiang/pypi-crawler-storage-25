"""Deterministic jitter sampling utilities."""

from __future__ import annotations


def msvc_rand_pair(seed: int) -> tuple[int, int]:
    """Return the first two `rand()` values from one MSVC `srand(seed)` call."""
    state = seed & 0xFFFFFFFF
    state = (state * 214013 + 2531011) & 0xFFFFFFFF
    first = (state >> 16) & 0x7FFF
    state = (state * 214013 + 2531011) & 0xFFFFFFFF
    second = (state >> 16) & 0x7FFF
    return (first, second)


def truncating_division(dividend: int, divisor: int) -> int:
    """Match C++ integer division semantics for negative values."""
    quotient = abs(dividend) // abs(divisor)
    return -quotient if (dividend < 0) ^ (divisor < 0) else quotient


def jitter_bucket(milliseconds: int, period_ms: int) -> int:
    """Return the deterministic jitter bucket for one timestamp."""
    return truncating_division(milliseconds, period_ms)


def jitter_offsets(
    bucket: int,
    left: int,
    right: int,
    up: int,
    down: int,
    seed: int,
) -> tuple[int, int]:
    """Return one deterministic jitter offset using the VSFilterMod formula."""
    random_x, random_y = msvc_rand_pair((seed + bucket) * 100)
    x_amplitude = left + right
    y_amplitude = up + down
    x_offset = (random_x % x_amplitude) - left if x_amplitude else 0
    y_offset = (random_y % y_amplitude) - up if y_amplitude else 0
    return (x_offset, y_offset)


def jitter_offsets_at(
    milliseconds: int,
    period_ms: int,
    left: int,
    right: int,
    up: int,
    down: int,
    seed: int,
) -> tuple[int, int]:
    """Return the deterministic jitter offsets active at ``milliseconds``."""
    return jitter_offsets(
        jitter_bucket(milliseconds, period_ms),
        left,
        right,
        up,
        down,
        seed,
    )


def iter_jitter_offsets(
    duration_ms: int,
    period_ms: int,
    left: int,
    right: int,
    up: int,
    down: int,
    seed: int,
) -> list[tuple[int, int, int]]:
    """Return ``(time, x, y)`` tuples for each active jitter period."""
    resolved_period = period_ms or 1
    offsets: list[tuple[int, int, int]] = []
    current_ms = 0
    while current_ms < duration_ms:
        x_offset, y_offset = jitter_offsets_at(
            current_ms,
            resolved_period,
            left,
            right,
            up,
            down,
            seed,
        )
        offsets.append((current_ms, x_offset, y_offset))
        current_ms += resolved_period
    return offsets

