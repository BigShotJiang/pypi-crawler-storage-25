"""Validated jitter configuration shared by motion backends."""

from __future__ import annotations

from dataclasses import dataclass
from typing import cast

from pykara.exceptions import PykaraTypeError, PykaraValidationError


@dataclass(frozen=True, slots=True)
class JitterSpec:
    """Validated jitter parameters shared by multiple backends."""

    left: int
    right: int
    up: int
    down: int
    period: int
    seed: int


def validate_jitter_spec(
    left: object,
    right: object,
    up: object,
    down: object,
    period: object,
    seed: object,
    *,
    label: str,
) -> JitterSpec:
    """Return one validated jitter-parameter bundle."""
    values = (left, right, up, down, period, seed)
    if any(not isinstance(value, int) or isinstance(value, bool) for value in values):
        raise PykaraTypeError(
            f"{label} expects integer left/right/up/down/period/seed values"
        )
    left_i, right_i, up_i, down_i, period_i, seed_i = cast(
        tuple[int, int, int, int, int, int],
        values,
    )
    if period_i < 0:
        raise PykaraValidationError(f"{label} period must be >= 0")
    return JitterSpec(left_i, right_i, up_i, down_i, period_i, seed_i)

