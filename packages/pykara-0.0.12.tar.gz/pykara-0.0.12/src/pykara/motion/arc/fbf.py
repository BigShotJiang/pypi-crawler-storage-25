"""Frame-baked arc motion builder."""

from __future__ import annotations

import math

from pykara.ass.types import DialogueLine
from pykara.motion.arc.curve import arc_xy
from pykara.motion.runtime.fbf.expansion import apply_curve_fbf
from pykara.motion.runtime.window import resolve_window
from pykara.timing import Framerate


def arc_fbf_line(
    line: DialogueLine,
    framerate: Framerate | float,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    a1_deg: float,
    a2_deg: float,
    r1: float,
    r2: float,
    t1: float | None = None,
    t2: float | None = None,
    step: int = 1,
) -> list[DialogueLine]:
    r"""Expand one line to frame-baked arc motion output.

    Args:
        line: The source dialogue line to expand.
        framerate: Frame timing data used to compute per-frame intervals.
        x1: Start origin X coordinate.
        y1: Start origin Y coordinate.
        x2: End origin X coordinate.
        y2: End origin Y coordinate.
        a1_deg: Start angle in degrees.
        a2_deg: End angle in degrees.
        r1: Start radius in pixels.
        r2: End radius in pixels.
        t1: Optional window start in milliseconds.
        t2: Optional window end in milliseconds.
        step: Frame grouping step.

    Returns:
        An ordered list of ``DialogueLine`` objects, one per frame.
    """
    tw1, tw2 = resolve_window(t1, t2, line.end_time - line.start_time)
    a1_rad = math.radians(a1_deg)
    a2_rad = math.radians(a2_deg)

    def curve(t: float) -> tuple[float, float]:
        return arc_xy(t, x1, y1, x2, y2, a1_rad, a2_rad, r1, r2)

    return apply_curve_fbf(line, framerate, curve, tw1, tw2, step)
