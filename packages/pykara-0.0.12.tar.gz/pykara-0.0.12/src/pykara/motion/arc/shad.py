"""Shadow-trick arc motion builder."""

from __future__ import annotations

import math

from pykara.math.curves import sample_curve
from pykara.motion.arc.curve import arc_xy
from pykara.motion.runtime.shad.formatting import fmt_shad_tags
from pykara.motion.runtime.shad.transforms import zero_duration_transform
from pykara.motion.runtime.window import resolve_window


def build_shad_arc(
    duration_ms: int,
    ax: float,
    ay: float,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    a1_deg: float,
    a2_deg: float,
    r1: float,
    r2: float,
    t1: float | None = None,
    t2: float | None = None,
    segments: int = 16,
) -> str:
    r"""Return ``\t(...)`` segments for an arc motion using the shadow trick.

    Args:
        duration_ms: Line interval duration in milliseconds.
        ax: Anchor X coordinate (from ``\pos``).
        ay: Anchor Y coordinate (from ``\pos``).
        x1: Start origin X coordinate.
        y1: Start origin Y coordinate.
        x2: End origin X coordinate.
        y2: End origin Y coordinate.
        a1_deg: Start angle in degrees.
        a2_deg: End angle in degrees.
        r1: Start radius in pixels.
        r2: End radius in pixels.
        t1: Optional window start in milliseconds.
        t2: Optional window end in milliseconds.
        segments: Number of linear approximation segments.

    Returns:
        A string of concatenated ``\t(ms0,ms1,\xshad...\yshad...)`` tags.
    """
    tw1, tw2 = resolve_window(t1, t2, duration_ms)
    a1_rad = math.radians(a1_deg)
    a2_rad = math.radians(a2_deg)

    def curve(t: float) -> tuple[float, float]:
        return arc_xy(t, x1, y1, x2, y2, a1_rad, a2_rad, r1, r2)

    raw_segments = sample_curve(curve, segments, tw1, tw2)
    fragments: list[str] = []
    for ms0, ms1, x0, y0, x1_pt, y1_pt in raw_segments:
        t0, t1 = int(ms0), int(ms1)
        shad0 = fmt_shad_tags(x0 - ax, y0 - ay)
        shad1 = fmt_shad_tags(x1_pt - ax, y1_pt - ay)
        fragments.append(zero_duration_transform(t0, shad0))
        fragments.append(rf"\t({t0},{t1},{shad1})")
    return "".join(fragments)
