"""Arc motion effect."""
