"""Pure arc curve math."""

from __future__ import annotations

import math

from pykara.math.curves import lerp


def arc_xy(
    t: float,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    a1_rad: float,
    a2_rad: float,
    r1: float,
    r2: float,
) -> tuple[float, float]:
    """Return the arc position at normalised progress *t*."""
    ox = lerp(t, x1, x2)
    oy = lerp(t, y1, y2)
    alp = lerp(t, a1_rad, a2_rad)
    rt = lerp(t, r1, r2)
    return ox + math.cos(alp) * rt, oy - math.sin(alp) * rt

