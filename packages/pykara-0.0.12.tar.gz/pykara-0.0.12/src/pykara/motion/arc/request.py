"""Queued frame-baked arc requests."""

from __future__ import annotations

from dataclasses import dataclass

from pykara.ass.types import DialogueLine
from pykara.timing import Framerate


@dataclass(frozen=True, slots=True)
class ArcFbfRequest:
    """Queued parameters for one frame-baked arc expansion."""

    x1: float
    y1: float
    x2: float
    y2: float
    a1: float
    a2: float
    r1: float
    r2: float
    t1: float | None = None
    t2: float | None = None
    step: int = 1

    def expand(
        self,
        line: DialogueLine,
        framerate: Framerate | float,
    ) -> list[DialogueLine]:
        """Expand ``line`` using the queued arc configuration."""
        from pykara.motion.arc.fbf import arc_fbf_line

        return arc_fbf_line(
            line,
            framerate,
            self.x1,
            self.y1,
            self.x2,
            self.y2,
            self.a1,
            self.a2,
            self.r1,
            self.r2,
            self.t1,
            self.t2,
            self.step,
        )

