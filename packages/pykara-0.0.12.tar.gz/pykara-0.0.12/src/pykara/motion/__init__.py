"""Internal motion utilities."""
