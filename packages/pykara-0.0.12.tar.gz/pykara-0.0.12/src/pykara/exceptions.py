"""Library-specific exception hierarchy for pykara."""

from __future__ import annotations


class PykaraError(Exception):
    """Base class for all public pykara exceptions."""


class PykaraValidationError(PykaraError):
    """Raised when user-provided data is invalid for a pykara API."""


class PykaraTypeError(PykaraError):
    """Raised when argument types do not satisfy a pykara API contract."""


class PykaraRuntimeError(PykaraError):
    """Raised when a pykara runtime backend cannot complete its work."""


class PykaraLookupError(PykaraError):
    """Raised when a pykara lookup cannot resolve the requested name or item."""


class PykaraNameError(PykaraLookupError):
    """Raised when a pykara expression token or binding name is unknown."""


class PykaraNotImplementedError(PykaraError):
    """Raised when a pykara feature exists conceptually but is not implemented."""


class PykaraAttributeError(PykaraLookupError, AttributeError):
    """Raised for pykara attribute lookups that must also satisfy Python protocols."""
