"""Pango text-measurement backend."""

# pyright: reportAttributeAccessIssue=false, reportMissingTypeStubs=false, reportUnknownArgumentType=false, reportUnknownMemberType=false, reportUnknownParameterType=false, reportUnknownVariableType=false

from __future__ import annotations

import cairo
import gi

from pykara.layout.style import LayoutStyle

gi.require_version("Pango", "1.0")
gi.require_version("PangoCairo", "1.0")

from gi.repository import Pango, PangoCairo  # noqa: E402


def make_layout(style: LayoutStyle, fontsize: float) -> Pango.Layout:
    """Create the Pango layout used by the validated reference branch."""
    surface = cairo.ImageSurface(cairo.Format.A8, 1, 1)
    context = cairo.Context(surface)
    layout = PangoCairo.create_layout(context)

    font_description = Pango.FontDescription()
    font_description.set_family(style.font)
    font_description.set_size(int(fontsize * Pango.SCALE))
    font_description.set_weight(
        Pango.Weight.BOLD if style.bold else Pango.Weight.NORMAL
    )
    font_description.set_style(
        Pango.Style.ITALIC if style.italic else Pango.Style.NORMAL
    )

    layout.set_font_description(font_description)
    return layout


def measure_layout(
    layout: Pango.Layout,
    text: str,
) -> tuple[float, float, float, float]:
    """Measure a layout exactly as in the reference implementation."""
    layout.set_text(text, -1)
    width, height = layout.get_pixel_size()
    height = height if height > 0 else 1

    layout_iter = layout.get_iter()
    baseline = layout_iter.get_baseline() / Pango.SCALE

    descent = height - baseline
    if descent < 0:
        descent = 0.0

    return float(width), float(height), float(descent), 0.0


def measure_backend(style: LayoutStyle, text: str) -> tuple[float, float, float, float]:
    """Measure text and return raw backend metrics before final ASS scaling."""
    width = 0.0
    height = 0.0
    descent = 0.0
    extlead = 0.0

    fontsize = style.fontsize * 64.0
    spacing = style.spacing * 64.0
    layout = make_layout(style, fontsize)

    if spacing != 0:
        for char in text:
            char_width, char_height, char_descent, char_extlead = measure_layout(
                layout,
                char,
            )
            scaling = fontsize / char_height
            width += (char_width + spacing) * scaling
            height = max(height, char_height * scaling)
            descent = max(descent, char_descent * scaling)
            extlead = max(extlead, char_extlead * scaling)
    else:
        full_width, full_height, full_descent, full_extlead = measure_layout(
            layout,
            text,
        )
        scaling = fontsize / full_height
        width = full_width * scaling
        height = full_height * scaling
        descent = full_descent * scaling
        extlead = full_extlead * scaling

    return (width, height, descent, extlead)
