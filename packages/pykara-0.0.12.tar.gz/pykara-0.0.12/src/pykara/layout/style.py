"""ASS style adapter used by the layout engine."""

from __future__ import annotations

from dataclasses import dataclass

from pykara.ass.types import AssStyle as ParsedAssStyle


def format_style_color_for_expression(value: str) -> str:
    """Return one style color formatted for expression/tag usage.

    Style rows store colors as ``&HAABBGGRR``. Expressions should see the
    tag-oriented ``&HBBGGRR&`` form instead.
    """
    normalized = value.strip()
    if not normalized.startswith("&H"):
        return value

    payload = normalized[2:-1] if normalized.endswith("&") else normalized[2:]
    if len(payload) == 8:
        payload = payload[2:]
    if len(payload) != 6:
        return value
    return f"&H{payload.upper()}&"


@dataclass(slots=True, frozen=True)
class LayoutStyle:
    """Normalized ASS style data used by text measurement."""

    name: str
    font: str
    fontsize: float
    primary_color: str
    secondary_color: str
    outline_color: str
    back_color: str
    bold: bool
    italic: bool
    underline: bool
    strikeout: bool
    scalex: float
    scaley: float
    spacing: float
    angle: float
    border_style: int
    outline: float
    shadow: float
    alignment: int
    margin_l: int
    margin_r: int
    margin_v: int
    encoding: int

    @property
    def margin_t(self) -> int:
        """Return the top margin used by karaskel-style positioning."""
        return self.margin_v

    @property
    def margin_b(self) -> int:
        """Return the bottom margin used by karaskel-style positioning."""
        return self.margin_v

    @classmethod
    def from_parsed(cls, style: ParsedAssStyle) -> LayoutStyle:
        """Convert a parsed ASS style row into the layout representation.

        Args:
            style: A ``ParsedAssStyle`` instance from the ASS parser.

        Returns:
            A ``LayoutStyle`` with all fields mapped from the parsed row.
        """
        return cls(
            name=style.name,
            font=style.fontname,
            fontsize=style.fontsize,
            primary_color=style.primary_colour,
            secondary_color=style.secondary_colour,
            outline_color=style.outline_colour,
            back_color=style.back_colour,
            bold=style.bold,
            italic=style.italic,
            underline=style.underline,
            strikeout=style.strike_out,
            scalex=style.scale_x,
            scaley=style.scale_y,
            spacing=style.spacing,
            angle=style.angle,
            border_style=style.border_style,
            outline=style.outline,
            shadow=style.shadow,
            alignment=style.alignment,
            margin_l=style.margin_l,
            margin_r=style.margin_r,
            margin_v=style.margin_v,
            encoding=style.encoding,
        )

    @classmethod
    def default(cls, name: str = "Default") -> LayoutStyle:
        """Return a fallback style for tests and style-less documents.

        Args:
            name: Style name to assign; defaults to ``"Default"``.

        Returns:
            A ``LayoutStyle`` populated with safe, neutral default values.
        """
        return cls(
            name=name,
            font="Arial",
            fontsize=20.0,
            primary_color="&H00FFFFFF",
            secondary_color="&H000000FF",
            outline_color="&H00000000",
            back_color="&H00000000",
            bold=False,
            italic=False,
            underline=False,
            strikeout=False,
            scalex=100.0,
            scaley=100.0,
            spacing=0.0,
            angle=0.0,
            border_style=1,
            outline=0.0,
            shadow=0.0,
            alignment=2,
            margin_l=0,
            margin_r=0,
            margin_v=0,
            encoding=1,
        )
