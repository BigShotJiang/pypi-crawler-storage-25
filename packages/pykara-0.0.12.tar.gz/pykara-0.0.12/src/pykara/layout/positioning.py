"""Populate absolute layout coordinates for lines, words, syllables, and chars."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

from pykara.ass.types import AssDocument
from pykara.karaoke.line import Line
from pykara.layout.style import LayoutStyle
from pykara.layout.text_measure import TextMetrics, measure_text


@dataclass(slots=True, frozen=True)
class Script:
    """Script resolution data required by the layout engine."""

    res_x: int
    res_y: int
    x_scale_correction: float = 1.0


_MeasureCache = dict[str, TextMetrics]


class _HorizontalBox(Protocol):
    """Object that carries horizontal box coordinates."""

    left: int
    center: int
    right: int
    width: int


class _AbsHorizontalBox(Protocol):
    """Object that carries absolute horizontal box coordinates."""

    abs_left: int
    abs_center: int
    abs_right: int


class _VerticalBox(Protocol):
    """Object that carries vertical box coordinates."""

    top: int
    middle: int
    bottom: int
    height: int


class _AbsVerticalBox(Protocol):
    """Object that carries absolute vertical box coordinates."""

    abs_top: int
    abs_middle: int
    abs_bottom: int


def _round_coordinate(value: float) -> int:
    """Round ASS coordinates to the nearest integer."""
    return math.floor(value + 0.5)


def _measure_text_cached(
    style: LayoutStyle,
    text: str,
    cache: _MeasureCache,
) -> TextMetrics:
    """Measure ``text`` once per layout pass."""
    cached_metrics = cache.get(text)
    if cached_metrics is None:
        cached_metrics = measure_text(style, text)
        cache[text] = cached_metrics
    return cached_metrics


def _assign_horizontal_box(
    obj: _HorizontalBox,
    *,
    left: float,
    width: float,
) -> None:
    """Populate horizontal box coordinates on one layout object."""
    if isinstance(obj, Line):
        obj.raw_left = left
        obj.raw_center = left + width / 2
        obj.raw_right = left + width
        obj.raw_width = width

    obj.left = _round_coordinate(left)
    obj.center = _round_coordinate(left + width / 2)
    obj.right = _round_coordinate(left + width)
    obj.width = _round_coordinate(width)


def _assign_absolute_horizontal(
    obj: _AbsHorizontalBox,
    *,
    absolute_left: float,
    width: float,
) -> None:
    """Populate absolute horizontal coordinates on one layout object."""
    obj.abs_left = _round_coordinate(absolute_left)
    obj.abs_center = _round_coordinate(absolute_left + width / 2)
    obj.abs_right = _round_coordinate(absolute_left + width)


def _assign_vertical_box(
    obj: _VerticalBox,
    *,
    top: float,
    middle: float,
    bottom: float,
    height: float,
) -> None:
    """Populate vertical box coordinates on one layout object."""
    obj.top = _round_coordinate(top)
    obj.middle = _round_coordinate(middle)
    obj.bottom = _round_coordinate(bottom)
    obj.height = _round_coordinate(height)


def _assign_absolute_vertical(obj: _VerticalBox, abs_obj: _AbsVerticalBox) -> None:
    """Populate absolute vertical coordinates from one relative vertical box."""
    abs_obj.abs_top = obj.top
    abs_obj.abs_middle = obj.middle
    abs_obj.abs_bottom = obj.bottom


def _is_left_aligned(alignment: int) -> bool:
    """Return whether one ASS alignment is left-aligned."""
    return alignment in {1, 4, 7}


def _is_center_aligned(alignment: int) -> bool:
    """Return whether one ASS alignment is horizontally centered."""
    return alignment in {2, 5, 8}


def _is_bottom_aligned(alignment: int) -> bool:
    """Return whether one ASS alignment is bottom-aligned."""
    return alignment in {1, 2, 3}


def _is_middle_aligned(alignment: int) -> bool:
    """Return whether one ASS alignment is vertically centered."""
    return alignment in {4, 5, 6}


def script_from_document(document: AssDocument) -> Script:
    """Build script positioning metadata from ``[Script Info]``.

    Args:
        document: The parsed ASS document whose ``[Script Info]`` fields
            supply ``PlayResX`` and ``PlayResY``.

    Returns:
        A ``Script`` populated with the document's play resolution values.
    """
    script_info_fields = {
        key.lower(): value for key, value in document.script_info.fields
    }
    return Script(
        res_x=int(script_info_fields.get("playresx", "0")),
        res_y=int(script_info_fields.get("playresy", "0")),
    )


def compute_line_layout(
    line: Line,
    style: LayoutStyle,
    script: Script,
    cache: _MeasureCache | None = None,
) -> None:
    """Populate the absolute line box.

    Args:
        line: The karaoke line to update in-place.
        style: The resolved ``LayoutStyle`` for the line.
        script: Script resolution data for margin/alignment calculations.
        cache: Optional text-metrics cache shared across layout calls.
    """
    metrics_cache = cache or {}
    line_text = "".join(syllable.text for syllable in line.syls)
    line_metrics = _measure_text_cached(style, line_text, metrics_cache)
    line_width = line_metrics.width * script.x_scale_correction
    line_height = line_metrics.height

    line.style = style
    effective_margin_left = line.margin_l if line.margin_l > 0 else style.margin_l
    effective_margin_right = line.margin_r if line.margin_r > 0 else style.margin_r
    effective_margin_top = line.margin_v if line.margin_v > 0 else style.margin_t
    effective_margin_bottom = line.margin_v if line.margin_v > 0 else style.margin_b
    effective_margin_vertical = line.margin_v if line.margin_v > 0 else style.margin_v

    line.effective_margin_left = effective_margin_left
    line.effective_margin_right = effective_margin_right
    line.effective_margin_top = effective_margin_top
    line.effective_margin_bottom = effective_margin_bottom
    line.effective_margin_vertical = effective_margin_vertical

    if _is_left_aligned(style.alignment):
        line_left = float(effective_margin_left)
        line.halign = "left"
    elif _is_center_aligned(style.alignment):
        line_left = (
            script.res_x - effective_margin_left - effective_margin_right - line_width
        ) / 2 + effective_margin_left
        line.halign = "center"
    else:
        line_left = script.res_x - effective_margin_right - line_width
        line.halign = "right"

    if _is_bottom_aligned(style.alignment):
        line_bottom = script.res_y - effective_margin_bottom
        line_middle = line_bottom - line_height / 2
        line_top = line_bottom - line_height
        line.valign = "bottom"
    elif _is_middle_aligned(style.alignment):
        line_top = (
            script.res_y - effective_margin_top - effective_margin_bottom - line_height
        ) / 2 + effective_margin_top
        line_middle = line_top + line_height / 2
        line_bottom = line_top + line_height
        line.valign = "middle"
    else:
        line_top = float(effective_margin_top)
        line_middle = line_top + line_height / 2
        line_bottom = line_top + line_height
        line.valign = "top"

    _assign_horizontal_box(line, left=line_left, width=line_width)
    _assign_vertical_box(
        line,
        top=line_top,
        middle=line_middle,
        bottom=line_bottom,
        height=line_height,
    )
    line.x = line.center
    line.y = line.middle


def compute_syl_positions(
    line: Line,
    style: LayoutStyle,
    script: Script,
    cache: _MeasureCache | None = None,
) -> None:
    """Populate the absolute syllable boxes.

    Args:
        line: The karaoke line whose syllables are updated in-place.
        style: The resolved ``LayoutStyle`` for the line.
        script: Script resolution data used for x-scale correction.
        cache: Optional text-metrics cache shared across layout calls.
    """
    metrics_cache = cache or {}
    cursor_left = 0.0
    line_left = line.raw_left
    line_top = float(line.top)
    line_middle = float(line.middle)
    line_bottom = float(line.bottom)

    for syllable in line.syls:
        syllable.style = style
        syllable_metrics = _measure_text_cached(
            style,
            syllable.trimmed_text,
            metrics_cache,
        )
        leading_space_metrics = _measure_text_cached(
            style,
            syllable.leading_spaces,
            metrics_cache,
        )
        trailing_space_metrics = _measure_text_cached(
            style,
            syllable.trailing_spaces,
            metrics_cache,
        )

        syllable_width = syllable_metrics.width * script.x_scale_correction
        leading_space_width = leading_space_metrics.width * script.x_scale_correction
        trailing_space_width = trailing_space_metrics.width * script.x_scale_correction

        syllable.leading_space_width = _round_coordinate(leading_space_width)
        syllable.trailing_space_width = _round_coordinate(trailing_space_width)

        relative_left = cursor_left + leading_space_width
        absolute_left = line_left + relative_left
        cursor_left += leading_space_width + syllable_width + trailing_space_width

        _assign_horizontal_box(syllable, left=relative_left, width=syllable_width)
        _assign_absolute_horizontal(
            syllable, absolute_left=absolute_left, width=syllable_width
        )
        _assign_vertical_box(
            syllable,
            top=line_top,
            middle=line_middle,
            bottom=line_bottom,
            height=syllable_metrics.height,
        )
        _assign_absolute_vertical(syllable, syllable)


def compute_char_positions(
    line: Line,
    style: LayoutStyle,
    cache: _MeasureCache | None = None,
) -> None:
    """Populate the absolute character boxes.

    Args:
        line: The karaoke line whose characters are updated in-place.
        style: The resolved ``LayoutStyle`` for the line.
        cache: Optional text-metrics cache shared across layout calls.
    """
    metrics_cache = cache or {}
    cursor_left = 0.0
    line_top = float(line.top)
    line_middle = float(line.middle)
    line_bottom = float(line.bottom)

    for char in line.chars:
        char.style = style
        char_metrics = _measure_text_cached(style, char.text, metrics_cache)
        char_width = char_metrics.width
        relative_left = cursor_left
        if char is char.syl.chars[0] and relative_left != float(char.syl.left):
            relative_left = float(char.syl.left)

        absolute_left = line.raw_left + relative_left
        _assign_horizontal_box(char, left=relative_left, width=char_width)
        _assign_absolute_horizontal(char, absolute_left=absolute_left, width=char_width)
        _assign_vertical_box(
            char,
            top=line_top,
            middle=line_middle,
            bottom=line_bottom,
            height=char_metrics.height,
        )
        _assign_absolute_vertical(char, char)

        cursor_left = relative_left + char_width


def compute_word_positions(line: Line) -> None:
    """Populate word boxes while excluding spaces from the visible width.

    Args:
        line: The karaoke line whose words are updated in-place.
    """
    for word in line.words:
        word.style = line.style
        visible_chars = [char for char in word.chars if char.text not in {" ", "\t"}]

        if visible_chars:
            left = visible_chars[0].left
            right = visible_chars[-1].right
            width = right - left
            height = max(char.height for char in visible_chars)
        elif word.chars:
            left = word.chars[0].left
            right = left
            width = 0
            height = max(char.height for char in word.chars)
        else:
            left = 0
            right = 0
            width = 0
            height = 0

        word.left = left
        word.center = _round_coordinate(left + width / 2)
        word.right = right
        word.width = width
        word.height = height
        word.abs_left = _round_coordinate(line.raw_left + word.left)
        word.abs_center = _round_coordinate(line.raw_left + left + width / 2)
        word.abs_right = _round_coordinate(line.raw_left + word.right)


def populate_positions(line: Line, style: LayoutStyle, script: Script) -> None:
    """Run the full layout pass for one parsed karaoke line.

    Args:
        line: The karaoke line to populate in-place.
        style: The resolved ``LayoutStyle`` for the line.
        script: Script resolution data for margin and alignment calculations.
    """
    measure_cache: _MeasureCache = {}
    compute_line_layout(line, style, script, measure_cache)
    compute_syl_positions(line, style, script, measure_cache)
    compute_char_positions(line, style, measure_cache)
    compute_word_positions(line)
