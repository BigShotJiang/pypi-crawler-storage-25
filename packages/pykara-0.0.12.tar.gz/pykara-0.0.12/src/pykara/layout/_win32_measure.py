"""Win32 GDI text-measurement backend."""

# pyright: reportAttributeAccessIssue=false, reportMissingTypeStubs=false, reportUnknownArgumentType=false, reportUnknownMemberType=false, reportUnknownParameterType=false, reportUnknownVariableType=false

from __future__ import annotations

import ctypes
from ctypes import wintypes

from pykara.exceptions import PykaraRuntimeError
from pykara.layout.style import LayoutStyle

MM_TEXT = 1
FW_NORMAL = 400
FW_BOLD = 700
OUT_TT_PRECIS = 4
CLIP_DEFAULT_PRECIS = 0
ANTIALIASED_QUALITY = 4
DEFAULT_PITCH = 0
FF_DONTCARE = 0


class SIZE(ctypes.Structure):
    """Win32 text size structure."""

    _fields_ = [
        ("cx", wintypes.LONG),
        ("cy", wintypes.LONG),
    ]


class LOGFONTW(ctypes.Structure):
    """Win32 logical font definition."""

    _fields_ = [
        ("lfHeight", wintypes.LONG),
        ("lfWidth", wintypes.LONG),
        ("lfEscapement", wintypes.LONG),
        ("lfOrientation", wintypes.LONG),
        ("lfWeight", wintypes.LONG),
        ("lfItalic", wintypes.BYTE),
        ("lfUnderline", wintypes.BYTE),
        ("lfStrikeOut", wintypes.BYTE),
        ("lfCharSet", wintypes.BYTE),
        ("lfOutPrecision", wintypes.BYTE),
        ("lfClipPrecision", wintypes.BYTE),
        ("lfQuality", wintypes.BYTE),
        ("lfPitchAndFamily", wintypes.BYTE),
        ("lfFaceName", wintypes.WCHAR * 32),
    ]


class TEXTMETRICW(ctypes.Structure):
    """Win32 text metric structure."""

    _fields_ = [
        ("tmHeight", wintypes.LONG),
        ("tmAscent", wintypes.LONG),
        ("tmDescent", wintypes.LONG),
        ("tmInternalLeading", wintypes.LONG),
        ("tmExternalLeading", wintypes.LONG),
        ("tmAveCharWidth", wintypes.LONG),
        ("tmMaxCharWidth", wintypes.LONG),
        ("tmWeight", wintypes.LONG),
        ("tmOverhang", wintypes.LONG),
        ("tmDigitizedAspectX", wintypes.LONG),
        ("tmDigitizedAspectY", wintypes.LONG),
        ("tmFirstChar", wintypes.WCHAR),
        ("tmLastChar", wintypes.WCHAR),
        ("tmDefaultChar", wintypes.WCHAR),
        ("tmBreakChar", wintypes.WCHAR),
        ("tmItalic", wintypes.BYTE),
        ("tmUnderlined", wintypes.BYTE),
        ("tmStruckOut", wintypes.BYTE),
        ("tmPitchAndFamily", wintypes.BYTE),
        ("tmCharSet", wintypes.BYTE),
    ]


gdi32 = ctypes.WinDLL("gdi32")

gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
gdi32.CreateCompatibleDC.restype = wintypes.HDC

gdi32.SetMapMode.argtypes = [wintypes.HDC, ctypes.c_int]
gdi32.SetMapMode.restype = ctypes.c_int

gdi32.CreateFontIndirectW.argtypes = [ctypes.POINTER(LOGFONTW)]
gdi32.CreateFontIndirectW.restype = wintypes.HFONT

gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
gdi32.SelectObject.restype = wintypes.HGDIOBJ

gdi32.GetTextExtentPoint32W.argtypes = [
    wintypes.HDC,
    wintypes.LPCWSTR,
    ctypes.c_int,
    ctypes.POINTER(SIZE),
]
gdi32.GetTextExtentPoint32W.restype = wintypes.BOOL

gdi32.GetTextMetricsW.argtypes = [wintypes.HDC, ctypes.POINTER(TEXTMETRICW)]
gdi32.GetTextMetricsW.restype = wintypes.BOOL

gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
gdi32.DeleteObject.restype = wintypes.BOOL

gdi32.DeleteDC.argtypes = [wintypes.HDC]
gdi32.DeleteDC.restype = wintypes.BOOL


def _make_logfont(style: LayoutStyle, fontsize: float) -> LOGFONTW:
    """Build a Win32 logical font from an ASS style."""
    logfont = LOGFONTW()
    ctypes.memset(ctypes.byref(logfont), 0, ctypes.sizeof(logfont))
    logfont.lfHeight = int(fontsize)
    logfont.lfWeight = FW_BOLD if style.bold else FW_NORMAL
    logfont.lfItalic = 1 if style.italic else 0
    logfont.lfUnderline = 1 if style.underline else 0
    logfont.lfStrikeOut = 1 if style.strikeout else 0
    logfont.lfCharSet = int(style.encoding)
    logfont.lfOutPrecision = OUT_TT_PRECIS
    logfont.lfClipPrecision = CLIP_DEFAULT_PRECIS
    logfont.lfQuality = ANTIALIASED_QUALITY
    logfont.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE
    logfont.lfFaceName = style.font[:31]
    return logfont


def measure_backend(style: LayoutStyle, text: str) -> tuple[float, float, float, float]:
    """Measure text and return raw backend metrics before final ASS scaling."""
    width = 0.0
    height = 0.0
    descent = 0.0
    extlead = 0.0

    fontsize = style.fontsize * 64.0
    spacing = style.spacing * 64.0

    dc = gdi32.CreateCompatibleDC(None)
    if not dc:
        raise PykaraRuntimeError(
            "layout.measure_text() backend error: CreateCompatibleDC failed"
        )

    try:
        gdi32.SetMapMode(dc, MM_TEXT)
        logfont = _make_logfont(style, fontsize)
        hfont = gdi32.CreateFontIndirectW(ctypes.byref(logfont))
        if not hfont:
            raise PykaraRuntimeError(
                "layout.measure_text() backend error: CreateFontIndirectW failed"
            )

        try:
            old_font = gdi32.SelectObject(dc, hfont)
            size = SIZE()

            if spacing != 0:
                for char in text:
                    ok = gdi32.GetTextExtentPoint32W(
                        dc,
                        char,
                        1,
                        ctypes.byref(size),
                    )
                    if not ok:
                        raise PykaraRuntimeError(
                            "layout.measure_text() backend error: "
                            "GetTextExtentPoint32W failed in spacing branch"
                        )
                    width += size.cx + spacing
                    height = float(size.cy)
            else:
                ok = gdi32.GetTextExtentPoint32W(
                    dc,
                    text,
                    len(text),
                    ctypes.byref(size),
                )
                if not ok:
                    raise PykaraRuntimeError(
                        "layout.measure_text() backend error: "
                        "GetTextExtentPoint32W failed in non-spacing branch"
                    )
                width = float(size.cx)
                height = float(size.cy)

            metrics = TEXTMETRICW()
            ok = gdi32.GetTextMetricsW(dc, ctypes.byref(metrics))
            if not ok:
                raise PykaraRuntimeError(
                    "layout.measure_text() backend error: GetTextMetricsW failed"
                )

            descent = float(metrics.tmDescent)
            extlead = float(metrics.tmExternalLeading)
            gdi32.SelectObject(dc, old_font)
        finally:
            gdi32.DeleteObject(hfont)
    finally:
        gdi32.DeleteDC(dc)

    return (width, height, descent, extlead)
