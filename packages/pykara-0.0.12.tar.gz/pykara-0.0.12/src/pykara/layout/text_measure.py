"""Public text-measurement API."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from importlib import import_module
from sys import platform
from typing import Protocol, cast

from pykara.exceptions import PykaraRuntimeError
from pykara.layout.style import LayoutStyle


@dataclass(slots=True, frozen=True)
class TextMetrics:
    """Measured text extents for one string."""

    width: float
    height: float
    descent: float
    extlead: float


RawTextMetrics = tuple[float, float, float, float]


class TextMeasureBackend(Protocol):
    """Minimal contract for private text-measurement backends."""

    def measure_backend(self, style: LayoutStyle, text: str) -> RawTextMetrics:
        """Measure raw backend text metrics for one string."""
        ...


def _scale_metrics(
    *,
    width: float,
    height: float,
    descent: float,
    extlead: float,
    style: LayoutStyle,
) -> TextMetrics:
    """Scale raw backend metrics into ASS script coordinates."""
    return TextMetrics(
        width=style.scalex / 100.0 * width / 64.0,
        height=style.scaley / 100.0 * height / 64.0,
        descent=style.scaley / 100.0 * descent / 64.0,
        extlead=style.scaley / 100.0 * extlead / 64.0,
    )


@lru_cache(maxsize=1)
def _load_backend() -> TextMeasureBackend:
    """Load the active platform backend once per process."""
    if platform == "win32":
        return cast(TextMeasureBackend, import_module("pykara.layout._win32_measure"))

    try:
        return cast(TextMeasureBackend, import_module("pykara.layout._pango_measure"))
    except ImportError as exc:
        raise PykaraRuntimeError(
            "layout.measure_text() missing dependencies. Install pycairo and "
            "PyGObject with Pango support."
        ) from exc


def _measure_raw_text(style: LayoutStyle, text: str) -> RawTextMetrics:
    """Dispatch to the active platform backend and return raw backend metrics."""
    backend = _load_backend()
    return backend.measure_backend(style, text)


def measure_text(style: LayoutStyle, text: str) -> TextMetrics:
    """Measure text using the active platform backend."""
    width, height, descent, extlead = _measure_raw_text(style, text)
    return _scale_metrics(
        width=width,
        height=height,
        descent=descent,
        extlead=extlead,
        style=style,
    )
