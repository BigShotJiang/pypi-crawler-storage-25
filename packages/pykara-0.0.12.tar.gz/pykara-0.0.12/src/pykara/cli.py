"""CLI entry point for the pykara package."""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from pathlib import Path
from typing import Protocol, cast

from pykara import __version__
from pykara.ass.parser import read_ass
from pykara.ass.writer import format_event_line, write_ass
from pykara.engine.output import build_output_document
from pykara.engine.preflight import preflight
from pykara.engine.runner import RunOptions, run
from pykara.timing import load_timecodes


class CliArgs(Protocol):
    """Typed view of the parsed CLI arguments."""

    timecodes: Path | None
    seed: int
    debug: bool
    emit_events: bool
    input: Path
    output: Path | None


def build_parser() -> argparse.ArgumentParser:
    """Build the top-level command-line parser.

    Returns:
        A configured ``ArgumentParser`` for the ``pykara`` command.
    """
    parser = argparse.ArgumentParser(prog="pykara")
    parser.add_argument(
        "--timecodes",
        type=Path,
        help="Path to timecodes file for frame-baked motion",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="RNG seed for deterministic output (default: 42)",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--emit-events",
        action="store_true",
        help=(
            "Print generated Dialogue/Comment rows to stdout instead of writing a file"
        ),
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Show full traceback on error instead of a short message",
    )
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path, nargs="?")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the pykara CLI.

    Args:
        argv: Command-line arguments to parse; defaults to ``sys.argv[1:]``
            when ``None``.

    Returns:
        Exit code ``0`` on success, ``1`` on error.
    """
    args = cast(CliArgs, build_parser().parse_args(argv))
    try:
        return _run(args)
    except Exception as exc:
        if args.debug:
            raise
        print(
            f"pykara: error: {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        print(
            "Re-run with --debug for the full traceback.",
            file=sys.stderr,
        )
        return 1


def _run(args: CliArgs) -> int:
    """Execute the templater after arguments have been parsed.

    Args:
        args: Parsed command-line arguments.

    Returns:
        Exit code ``0`` on success.
    """
    if args.timecodes is not None:
        load_timecodes(args.timecodes)

    source_document = read_ass(args.input)
    preflight(source_document)
    generated_events = run(source_document, RunOptions(seed=args.seed))
    if args.emit_events:
        for event in generated_events:
            print(
                format_event_line(event, source_document.event_format),
                file=sys.stdout,
            )
        return 0

    if args.output is None:
        build_parser().error("the following arguments are required: output")
    output_document = build_output_document(source_document, generated_events)
    write_ass(output_document, args.output)
    return 0
