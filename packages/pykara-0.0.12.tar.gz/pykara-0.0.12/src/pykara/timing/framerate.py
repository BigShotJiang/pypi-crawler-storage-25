"""Helpers for frame/time conversion and framerate-source resolution."""

from __future__ import annotations

import re
from bisect import bisect_right
from dataclasses import dataclass
from fractions import Fraction
from math import isfinite
from pathlib import Path

from pykara.ass.types import AssDocument, RawSection, ScriptInfo
from pykara.exceptions import PykaraValidationError

_AEGISUB_PROJECT_GARBAGE = "aegisub project garbage"
_VIDEO_FILE_FIELD = "video file"
_PLAYBACK_FPS_FIELD = "PlaybackFPS"
_DUMMY_VIDEO_FPS_PATTERN = re.compile(r"^\?dummy:([^:]+):")
_TIMECODES_HEADER_PREFIX = "# timecode format"


def _parse_timecode_lines(lines: list[str]) -> list[int]:
    """Parse a timecodes payload into frame-start timestamps.

    Args:
        lines: Lines of the timecodes file, including the header line.

    Returns:
        Ordered list of frame-start timestamps in milliseconds.

    Raises:
        PykaraValidationError: The file is empty, the header does not match the
            supported format, or no frame timestamps are present.
    """
    if not lines:
        raise PykaraValidationError(
            "timing.load_timecodes(): Timecodes file is empty"
        )

    header = lines[0].strip().lower()
    if not header.startswith(_TIMECODES_HEADER_PREFIX):
        raise PykaraValidationError(
            "timing.load_timecodes(): Unsupported timecodes format"
        )

    frame_start_times: list[int] = []
    for raw_line in lines[1:]:
        stripped_line = raw_line.strip()
        if not stripped_line or stripped_line.startswith("#"):
            continue
        frame_start_times.append(int(stripped_line))

    if not frame_start_times:
        raise PykaraValidationError(
            "timing.load_timecodes(): "
            "Timecodes file does not contain any frame timestamps"
        )
    return frame_start_times


@dataclass(frozen=True, slots=True)
class Framerate:
    """Frame/time mapping based on frame-start timestamps."""

    frame_start_times: tuple[int, ...]

    def __post_init__(self) -> None:
        """Validate the frame-start sequence.

        Raises:
            PykaraValidationError: ``frame_start_times`` is empty or contains a
                timestamp that is less than the preceding one.
        """
        if not self.frame_start_times:
            raise PykaraValidationError(
                "timing.Framerate(): Framerate requires at least one frame timestamp"
            )
        if any(
            current_time < previous_time
            for previous_time, current_time in zip(
                self.frame_start_times,
                self.frame_start_times[1:],
                strict=False,
            )
        ):
            raise PykaraValidationError(
                "timing.Framerate(): Frame timestamps must be non-decreasing"
            )

    @property
    def frame_count(self) -> int:
        """Return the number of known frame-start timestamps."""
        return len(self.frame_start_times)

    @property
    def last_frame_duration(self) -> int:
        """Return the duration used for extrapolation past known frames."""
        if len(self.frame_start_times) == 1:
            return 0
        return self.frame_start_times[-1] - self.frame_start_times[-2]

    def frame_at_time(self, milliseconds: int) -> int:
        """Return the frame index active at ``milliseconds``.

        Args:
            milliseconds: Absolute timestamp in milliseconds.

        Returns:
            Zero-based frame index.  For timestamps before the first known
            frame the result is ``0``.  For timestamps beyond the last known
            frame the result is extrapolated using the duration of the final
            inter-frame interval (``last_frame_duration``); if that duration
            is zero or unavailable the last known frame index is returned.
        """
        if milliseconds <= self.frame_start_times[0]:
            return 0

        insertion_index = bisect_right(self.frame_start_times, milliseconds)
        if insertion_index < len(self.frame_start_times):
            return insertion_index - 1

        last_duration = self.last_frame_duration
        if last_duration <= 0:
            return len(self.frame_start_times) - 1
        return (
            len(self.frame_start_times)
            - 1
            + ((milliseconds - self.frame_start_times[-1]) // last_duration)
        )

    def time_at_frame(self, frame_index: int) -> int:
        """Return the start time of ``frame_index``.

        Args:
            frame_index: Zero-based frame index.

        Returns:
            Start time in milliseconds.  For frame indices within the known
            range the exact stored timestamp is returned.  For indices beyond
            the last known frame the start time is extrapolated by adding
            multiples of ``last_frame_duration``; if that duration is zero
            the last known timestamp is returned.

        Raises:
            PykaraValidationError: ``frame_index`` is negative.
        """
        if frame_index < 0:
            raise PykaraValidationError(
                "timing.Framerate.time_at_frame(): Frame index cannot be negative"
            )
        if frame_index < len(self.frame_start_times):
            return self.frame_start_times[frame_index]

        last_duration = self.last_frame_duration
        if last_duration <= 0:
            return self.frame_start_times[-1]
        extra_frame_count = frame_index - (len(self.frame_start_times) - 1)
        return self.frame_start_times[-1] + extra_frame_count * last_duration


def load_timecodes(path: str | Path) -> Framerate:
    """Load a timecodes file from disk.

    Args:
        path: Path to the timecodes file. The standard timecodes header is
            expected on the first line.

    Returns:
        A ``Framerate`` built from the parsed frame-start timestamps.

    Raises:
        PykaraValidationError: The file format is invalid or contains no timestamps.
        OSError: The file cannot be opened or read.
    """
    lines = Path(path).read_text(encoding="utf-8-sig").splitlines()
    return Framerate(tuple(_parse_timecode_lines(lines)))


def _last_field_value(
    fields: list[tuple[str, str]],
    field_name: str,
) -> str | None:
    """Return the last effective value for one case-insensitive field name."""
    normalized_name = field_name.casefold()
    for key, value in reversed(fields):
        if key.casefold() == normalized_name:
            return value.strip()
    return None


def _last_script_info_value(
    script_info: ScriptInfo,
    field_name: str,
) -> str | None:
    """Return the last value for one script-info field."""
    return _last_field_value(script_info.fields, field_name)


def _parse_constant_fps(raw_value: str, *, source_name: str) -> float:
    """Parse one constant-FPS value from a script or dummy-video field."""
    value = raw_value.strip()
    try:
        fps = float(Fraction(value)) if "/" in value else float(value)
    except (ValueError, ZeroDivisionError) as exc:
        raise PykaraValidationError(
            f"timing.resolve_framerate(): Invalid {source_name} FPS: {raw_value!r}"
        ) from exc

    if not isfinite(fps) or fps <= 0:
        raise PykaraValidationError(
            f"timing.resolve_framerate(): Invalid {source_name} FPS: {raw_value!r}"
        )
    return fps


def _playback_fps(script_info: ScriptInfo) -> float | None:
    """Return PlaybackFPS from ``[Script Info]`` when present."""
    raw_value = _last_script_info_value(script_info, _PLAYBACK_FPS_FIELD)
    if raw_value is None:
        return None
    return _parse_constant_fps(raw_value, source_name=_PLAYBACK_FPS_FIELD)


def _dummy_video_fps(video_file: str) -> float | None:
    """Return the FPS encoded in one ``Video File: ?dummy:...`` value."""
    match = _DUMMY_VIDEO_FPS_PATTERN.match(video_file.strip())
    if match is None:
        return None
    return _parse_constant_fps(match.group(1), source_name="dummy video")


def _raw_section_fields(section: RawSection) -> list[tuple[str, str]]:
    """Return parsed key/value fields from one raw ASS section."""
    fields: list[tuple[str, str]] = []
    for raw_line in reversed(section.lines):
        stripped_line = raw_line.strip()
        if not stripped_line or stripped_line.startswith(";"):
            continue
        key, separator, value = stripped_line.partition(":")
        if separator:
            fields.append((key.strip(), value.strip()))
    fields.reverse()
    return fields


def _project_garbage_video_fps(section: RawSection) -> float | None:
    """Return the dummy-video FPS encoded in one raw Aegisub section."""
    raw_value = _last_field_value(_raw_section_fields(section), _VIDEO_FILE_FIELD)
    if raw_value is None:
        return None
    return _dummy_video_fps(raw_value)


def _document_dummy_fps(document: AssDocument) -> float | None:
    """Return the fallback dummy-video FPS from one parsed ASS document."""
    for section in reversed(document.other_sections):
        if section.name.casefold() == _AEGISUB_PROJECT_GARBAGE:
            fps = _project_garbage_video_fps(section)
            if fps is not None:
                return fps
    return None


def resolve_framerate(
    document: AssDocument,
    explicit: Framerate | float | None = None,
) -> Framerate | float | None:
    """Resolve a framerate source from explicit input or ASS metadata.

    Resolution priority (first match wins):

    1. ``explicit`` — a ``Framerate`` or constant FPS value supplied by the
       caller.
    2. ``PlaybackFPS`` field in ``[Script Info]``.
    3. FPS encoded in a ``?dummy:…`` video path in the Aegisub project
       garbage section.

    Args:
        document: The parsed ASS document to inspect for framerate metadata.
        explicit: An optional caller-supplied framerate; takes priority over
            all document metadata when not ``None``.

    Returns:
        A ``Framerate`` or ``float`` FPS value when a source is found,
        otherwise ``None``.
    """
    if explicit is not None:
        return float(explicit) if isinstance(explicit, (int, float)) else explicit

    playback_fps = _playback_fps(document.script_info)
    if playback_fps is not None:
        return playback_fps

    dummy_fps = _document_dummy_fps(document)
    if dummy_fps is not None:
        return dummy_fps

    return None
