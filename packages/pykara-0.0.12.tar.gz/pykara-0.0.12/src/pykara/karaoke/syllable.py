"""Syllable data model."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pykara.karaoke.char import Char
    from pykara.karaoke.line import Line
    from pykara.karaoke.word import Word
    from pykara.layout.style import LayoutStyle


def _new_chars() -> list[Char]:
    """Return an empty character list used as the ``chars`` default factory."""
    return []


@dataclass(slots=True, frozen=True)
class Highlight:
    """One highlight interval within a syllable."""

    start_time: int
    end_time: int
    duration: int


@dataclass(slots=True)
class Syllable:
    """A parsed karaoke syllable with full metadata.

    Contains timing data, override tag dictionary, highlight intervals,
    text analysis (spaces/trimming), inline FX, and layout positioning
    fields populated during karaoke parsing and layout passes.
    """

    start_time: int
    end_time: int
    duration: int
    kdur: int
    text: str
    tag_type: str
    inline_fx: str
    plain_text: str = ""
    trimmed_text: str = ""
    leading_spaces: str = ""
    trailing_spaces: str = ""
    line: Line | None = None
    word: Word | None = None
    style: LayoutStyle | None = None
    highlights: list[Highlight] = field(default_factory=list[Highlight])
    override_tags: dict[int, str] = field(default_factory=dict[int, str])
    si: int = 0
    ci: int = 0
    wi: int = 0
    length: int = 0
    is_blank: bool = False
    is_space: bool = False
    syl_fx: str = ""
    chars: list[Char] = field(default_factory=_new_chars)
    left: int = 0
    center: int = 0
    right: int = 0
    width: int = 0
    abs_left: int = 0
    abs_center: int = 0
    abs_right: int = 0
    top: int = 0
    middle: int = 0
    bottom: int = 0
    height: int = 0
    abs_top: int = 0
    abs_middle: int = 0
    abs_bottom: int = 0
    leading_space_width: int = 0
    trailing_space_width: int = 0
