"""Character data model and decomposition helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from pykara.exceptions import PykaraValidationError
from pykara.karaoke.syllable import Highlight, Syllable
from pykara.karaoke.word import Word

if TYPE_CHECKING:
    from pykara.karaoke.line import Line
    from pykara.layout.style import LayoutStyle


@dataclass(slots=True)
class Char:
    """A parsed character with timing, positioning, and style metadata.

    Each character is linked to its parent syllable and word, and carries
    timing, text analysis, and layout positioning fields populated during
    karaoke parsing and layout passes.
    """

    text: str
    ci: int
    si: int
    wi: int
    syl: Syllable
    word: Word
    plain_text: str = ""
    trimmed_text: str = ""
    line: Line | None = None
    start_time: int = 0
    end_time: int = 0
    duration: int = 0
    style: LayoutStyle | None = None
    inline_fx: str = ""
    highlights: list[Highlight] = field(default_factory=list[Highlight])
    length: int = 0
    is_blank: bool = False
    is_space: bool = False
    left: int = 0
    center: int = 0
    right: int = 0
    width: int = 0
    height: int = 0
    abs_left: int = 0
    abs_center: int = 0
    abs_right: int = 0
    top: int = 0
    middle: int = 0
    bottom: int = 0
    abs_top: int = 0
    abs_middle: int = 0
    abs_bottom: int = 0


def split_chars(syllables: list[Syllable], words: list[Word]) -> list[Char]:
    """Split syllables into characters and attach each one to its word.

    Args:
        syllables: Ordered syllable list produced by the karaoke parser.
        words: Ordered word list produced by ``split_words``.

    Returns:
        Ordered list of ``Char`` objects, one per Unicode code point across
        all syllable text, each linked to its parent syllable and word.

    Raises:
        PykaraValidationError: ``syllables`` contains text characters but
            ``words`` is empty, which would leave characters unattached.
    """
    if syllables and not words:
        raise PykaraValidationError(
            "karaoke.split_chars() requires words for syllables"
        )

    chars: list[Char] = []
    for word in words:
        word.chars.clear()
    for syllable in syllables:
        syllable.chars.clear()

    word_index = 0
    ci = 1

    for syllable in syllables:
        for char_text in syllable.text:
            while word_index + 1 < len(words):
                current_word = words[word_index]
                current_word_end = current_word.ci + len(current_word.text)
                if ci < current_word_end:
                    break
                word_index += 1

            word = words[word_index]
            char = Char(
                text=char_text,
                ci=ci,
                si=syllable.si,
                wi=word.wi,
                syl=syllable,
                word=word,
            )
            chars.append(char)
            word.chars.append(char)
            syllable.chars.append(char)
            ci += 1

    return chars
