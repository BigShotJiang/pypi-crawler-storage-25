"""Parse karaoke timing and inline-fx data from ASS dialogue text."""

from __future__ import annotations

from typing import Protocol

from pykara.ass.types import DialogueLine
from pykara.karaoke.char import Char, split_chars
from pykara.karaoke.line import Line
from pykara.karaoke.override_tags import parse_karaoke_tag, split_override_tags
from pykara.karaoke.syllable import Highlight, Syllable
from pykara.karaoke.word import Word, split_words


class _HasSpaceFields(Protocol):
    plain_text: str
    leading_spaces: str
    trailing_spaces: str
    trimmed_text: str
    length: int
    is_blank: bool
    is_space: bool


def _extract_inline_fx_name(tag: str) -> str | None:
    """Extract the inline-fx name carried by one override tag."""
    if not tag.startswith("\\-"):
        return None
    inline_fx_name = tag[2:]
    return inline_fx_name if inline_fx_name else None


def _new_syllable(
    *,
    start_time: int,
    duration: int = 0,
    tag_type: str = "\\k",
    inline_fx: str = "",
) -> Syllable:
    """Create a syllable with consistent derived timing fields."""
    return Syllable(
        start_time=start_time,
        end_time=start_time + duration,
        duration=duration,
        kdur=duration // 10,
        text="",
        tag_type=tag_type,
        inline_fx=inline_fx,
    )


def _close_override_block(syllable: Syllable) -> None:
    """Close the current override block at the current text position."""
    tag_index = len(syllable.text)
    existing_tags = syllable.override_tags.get(tag_index, "")
    syllable.override_tags[tag_index] = f"{existing_tags}}}"


def _append_override_tag(
    syllable: Syllable,
    tag: str,
    *,
    open_block: bool,
) -> None:
    """Append one non-karaoke override tag to the current syllable."""
    tag_index = len(syllable.text)
    existing_tags = syllable.override_tags.get(tag_index, "")
    prefix = "{" if open_block else ""
    syllable.override_tags[tag_index] = f"{existing_tags}{prefix}{tag}"


def _apply_karaoke_timing_tag(
    current_syllable: Syllable,
    normalized_tag_name: str,
    duration_ms: int,
    current_inline_fx: str,
    parsed_syllables: list[Syllable],
) -> Syllable:
    """Apply one karaoke timing tag to the current parsing state."""
    if current_syllable.duration > 0 or current_syllable.text:
        parsed_syllables.append(current_syllable)
        return _new_syllable(
            start_time=current_syllable.end_time,
            duration=duration_ms,
            tag_type=normalized_tag_name,
            inline_fx=current_inline_fx,
        )

    current_syllable.tag_type = normalized_tag_name
    current_syllable.start_time += current_syllable.duration
    current_syllable.duration = duration_ms
    current_syllable.end_time = current_syllable.start_time + duration_ms
    current_syllable.kdur = duration_ms // 10
    current_syllable.inline_fx = current_inline_fx
    return current_syllable


def _default_highlight(syllable: Syllable) -> Highlight:
    """Build the default highlight interval for one syllable."""
    return Highlight(
        start_time=syllable.start_time,
        end_time=syllable.end_time,
        duration=syllable.duration,
    )


def _leading_non_space_char(text: str) -> str:
    """Return the first non-space character from ``text`` when present."""
    stripped = text.lstrip(" \t")
    return stripped[0] if stripped else ""


def _split_surrounding_spaces(text: str) -> tuple[str, str, str]:
    """Split text into leading spaces, core text, and trailing spaces."""
    stripped = text.lstrip(" \t")
    leading_spaces = text[: len(text) - len(stripped)]
    trimmed_text = stripped.rstrip(" \t")
    trailing_spaces = stripped[len(trimmed_text) :]
    return leading_spaces, trimmed_text, trailing_spaces


def _collapse_multi_highlights(parsed_syllables: list[Syllable]) -> list[Syllable]:
    """Collapse ``#``-prefixed extra highlights into the previous syllable."""
    collapsed_syllables: list[Syllable] = []
    current_output_syllable: Syllable | None = None

    for syllable in parsed_syllables:
        leading_char = _leading_non_space_char(syllable.text)
        highlight = _default_highlight(syllable)
        is_extra_highlight = (
            leading_char in {"#", "＃"}  # noqa: RUF001
            and current_output_syllable is not None
            and current_output_syllable.text != ""
        )

        if not is_extra_highlight:
            syllable.highlights.append(highlight)
            collapsed_syllables.append(syllable)
            current_output_syllable = syllable
            continue

        assert current_output_syllable is not None
        current_output_syllable.highlights.append(highlight)
        current_output_syllable.duration += syllable.duration
        current_output_syllable.kdur += syllable.kdur
        current_output_syllable.end_time = syllable.end_time

    return collapsed_syllables


def _apply_space_fields(obj: _HasSpaceFields, text: str) -> str:
    """Populate space-derived text fields and return the trimmed core text."""
    leading_spaces, trimmed_text, trailing_spaces = _split_surrounding_spaces(text)
    obj.plain_text = text
    obj.leading_spaces = leading_spaces
    obj.trailing_spaces = trailing_spaces
    obj.trimmed_text = trimmed_text
    obj.length = len(text)
    obj.is_blank = text == ""
    obj.is_space = trimmed_text == "" and not obj.is_blank
    return trimmed_text


def _finalize_syllables(syllables: list[Syllable]) -> None:
    """Populate derived syllable fields after parsing."""
    next_char_index = 1
    for syllable_index, syllable in enumerate(syllables, start=1):
        syllable.si = syllable_index
        syllable.ci = next_char_index
        _apply_space_fields(syllable, syllable.text)
        next_char_index += len(syllable.text)


def _populate_word_fields(words: list[Word], line: Line) -> None:
    """Populate derived word fields after parsing words."""
    for word in words:
        word.line = line
        _apply_space_fields(word, word.text)
        word.end_time = word.start_time + word.duration
        if not word.syls:
            continue
        word.si = word.syls[0].si
        word.inline_fx = word.syls[0].inline_fx
        word.highlights = [
            highlight for syllable in word.syls for highlight in syllable.highlights
        ]
        for syllable in word.syls:
            syllable.word = word
            syllable.wi = word.wi


def _populate_char_fields(chars: list[Char], line: Line) -> None:
    """Populate derived character fields after parsing characters."""
    for char in chars:
        char.line = line
        char.plain_text = char.text
        char.trimmed_text = char.text.strip(" \t")
        char.start_time = char.syl.start_time
        char.end_time = char.syl.end_time
        char.duration = char.syl.duration
        char.inline_fx = char.syl.inline_fx
        char.highlights = list(char.syl.highlights)
        char.length = len(char.text)
        char.is_blank = char.text == ""
        char.is_space = char.text in {" ", "\t"}


def _parse_override_block(
    override_block: str,
    current_syllable: Syllable,
    current_inline_fx: str,
    parsed_syllables: list[Syllable],
) -> tuple[Syllable, str]:
    """Process one ``{...}`` override block.

    Args:
        override_block: Raw tag text between ``{`` and ``}`` (braces excluded).
        current_syllable: The syllable that is currently being accumulated.
        current_inline_fx: The inline-fx name active before this block.
        parsed_syllables: Accumulator list for completed syllables.

    Returns:
        A tuple ``(updated_syllable, updated_inline_fx)`` reflecting any
        karaoke timing tags encountered in the block.
    """
    inside_override_block = False
    for tag in split_override_tags(override_block):
        parsed_tag = parse_karaoke_tag(tag)
        if parsed_tag is not None:
            normalized_tag_name, duration_ms = parsed_tag
            if inside_override_block:
                _close_override_block(current_syllable)
                inside_override_block = False
            current_syllable = _apply_karaoke_timing_tag(
                current_syllable,
                normalized_tag_name,
                duration_ms,
                current_inline_fx,
                parsed_syllables,
            )
            continue

        inline_fx_name = _extract_inline_fx_name(tag)
        if inline_fx_name is not None:
            current_inline_fx = inline_fx_name
            if current_syllable.duration == 0 and not current_syllable.text:
                current_syllable.inline_fx = inline_fx_name

        _append_override_tag(
            current_syllable, tag, open_block=not inside_override_block
        )
        inside_override_block = True

    if inside_override_block:
        _close_override_block(current_syllable)

    return current_syllable, current_inline_fx


def _scan_syllables(text: str) -> list[Syllable]:
    """Scan raw dialogue text into a flat syllable list."""
    parsed_syllables: list[Syllable] = []
    current_inline_fx = ""
    current_syllable = _new_syllable(start_time=0)

    index = 0
    while index < len(text):
        if text[index] == "{":
            block_end = text.find("}", index)
            if block_end == -1:
                current_syllable.text += text[index:]
                break
            current_syllable, current_inline_fx = _parse_override_block(
                text[index + 1 : block_end],
                current_syllable,
                current_inline_fx,
                parsed_syllables,
            )
            index = block_end + 1
            continue
        current_syllable.text += text[index]
        index += 1

    parsed_syllables.append(current_syllable)
    return parsed_syllables


def parse_karaoke(dialogue_line: DialogueLine) -> Line:
    r"""Parse one dialogue line into the internal karaoke structure.

    Args:
        dialogue_line: A raw ``DialogueLine`` whose ``text`` field contains
            karaoke override tags (``\k``, ``\kf``, ``\ko``, etc.).

    Returns:
        A fully populated ``Line`` with syllables, words, and characters
        linked together and their derived fields set.
    """
    parsed_syllables = _scan_syllables(dialogue_line.text)
    parsed_syllables = _collapse_multi_highlights(parsed_syllables)
    _finalize_syllables(parsed_syllables)

    words = split_words(parsed_syllables)
    chars = split_chars(parsed_syllables, words)
    plain_text = "".join(syllable.plain_text for syllable in parsed_syllables)

    for syllable in parsed_syllables:
        inline_fx_in_text = _extract_inline_fx_name(syllable.text)
        syllable.syl_fx = (
            syllable.inline_fx
            if syllable.inline_fx and syllable.inline_fx == inline_fx_in_text
            else ""
        )

    line = Line(
        start_time=dialogue_line.start_time,
        end_time=dialogue_line.end_time,
        duration=dialogue_line.end_time - dialogue_line.start_time,
        actor=dialogue_line.name,
        style=None,
        margin_l=dialogue_line.margin_l,
        margin_r=dialogue_line.margin_r,
        margin_v=dialogue_line.margin_v,
        plain_text=plain_text,
        trimmed_text=plain_text.strip(" \t"),
        length=len(plain_text),
        is_blank=plain_text == "",
        is_space=plain_text.strip(" \t") == "" and plain_text != "",
        syls=parsed_syllables,
        words=words,
        chars=chars,
    )

    for syllable in line.syls:
        syllable.line = line

    _populate_word_fields(line.words, line)
    _populate_char_fields(line.chars, line)

    return line
