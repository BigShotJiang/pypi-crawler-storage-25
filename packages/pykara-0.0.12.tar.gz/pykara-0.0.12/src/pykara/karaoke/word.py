"""Word data model and decomposition helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from pykara.karaoke.syllable import Highlight, Syllable

if TYPE_CHECKING:
    from pykara.karaoke.char import Char
    from pykara.karaoke.line import Line
    from pykara.layout.style import LayoutStyle


def _new_chars() -> list[Char]:
    """Return an empty character list used as the ``chars`` default factory."""
    return []


def _is_space(char: str) -> bool:
    """Return whether ``char`` should count as a word separator."""
    return char in {" ", "\t"}


def _iter_syllable_chars(
    syllables: list[Syllable],
) -> list[tuple[int, str, Syllable]]:
    """Flatten syllable text into a line-wide character stream."""
    flattened: list[tuple[int, str, Syllable]] = []
    ci = 1
    for syllable in syllables:
        for char in syllable.text:
            flattened.append((ci, char, syllable))
            ci += 1
    return flattened


@dataclass(slots=True)
class Word:
    """A parsed word assembled from one or more syllables.

    Carries timing, text analysis (including space handling), inline FX,
    highlight intervals, and layout positioning fields populated during
    karaoke parsing and layout passes.
    """

    text: str
    start_time: int
    duration: int
    wi: int
    ci: int
    plain_text: str = ""
    trimmed_text: str = ""
    leading_spaces: str = ""
    trailing_spaces: str = ""
    end_time: int = 0
    si: int = 0
    line: Line | None = None
    style: LayoutStyle | None = None
    inline_fx: str = ""
    highlights: list[Highlight] = field(default_factory=list[Highlight])
    length: int = 0
    is_blank: bool = False
    is_space: bool = False
    syls: list[Syllable] = field(default_factory=list[Syllable])
    chars: list[Char] = field(default_factory=_new_chars)
    left: int = 0
    center: int = 0
    right: int = 0
    width: int = 0
    height: int = 0
    abs_left: int = 0
    abs_center: int = 0
    abs_right: int = 0
    leading_space_width: int = 0
    trailing_space_width: int = 0


def split_words(syllables: list[Syllable]) -> list[Word]:
    """Split syllables into word objects.

    Word boundaries follow the current char-based grouping rule: whitespace is
    attached to the preceding word, and a new word starts when a non-space
    character appears after a completed non-space run plus whitespace.

    Args:
        syllables: Ordered syllable list produced by the karaoke parser.

    Returns:
        Ordered list of ``Word`` objects covering all syllable characters.
        Returns an empty list when ``syllables`` is empty or every syllable
        has empty text.
    """
    flattened = _iter_syllable_chars(syllables)
    if not flattened:
        return []

    word_groups: list[list[tuple[int, str, Syllable]]] = []
    current_group: list[tuple[int, str, Syllable]] = []
    seen_space = False
    only_space = True

    for char_info in flattened:
        _, char, _ = char_info
        is_space = _is_space(char)

        if seen_space and not is_space and not only_space:
            word_groups.append(current_group)
            current_group = []
            seen_space = False
            only_space = True

        current_group.append(char_info)

        if is_space:
            seen_space = True
        else:
            seen_space = False
            only_space = False

    if current_group:
        word_groups.append(current_group)

    words: list[Word] = []
    for wi, group in enumerate(word_groups, start=1):
        group_syllables: list[Syllable] = []
        seen_ids: set[int] = set()
        for _, _, syllable in group:
            syllable_id = id(syllable)
            if syllable_id not in seen_ids:
                group_syllables.append(syllable)
                seen_ids.add(syllable_id)

        start_time = group_syllables[0].start_time
        end_time = group_syllables[-1].end_time
        words.append(
            Word(
                text="".join(char for _, char, _ in group),
                start_time=start_time,
                duration=end_time - start_time,
                wi=wi,
                ci=group[0][0],
                syls=group_syllables,
            )
        )

    return words
