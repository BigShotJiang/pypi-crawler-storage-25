"""Helpers for parsing override-tag blocks."""

from __future__ import annotations


def _karaoke_tag_name(tag: str, position: int) -> tuple[str, int] | None:
    """Return the normalized karaoke tag name and the next parse position."""
    if position < len(tag) and tag[position] == "K":
        return ("\\kf", position + 1)
    if tag[position : position + 2] == "kf":
        return ("\\kf", position + 2)
    if tag[position : position + 2] == "ko":
        return ("\\ko", position + 2)
    if tag[position : position + 2] == "kt":
        return ("\\kt", position + 2)
    if tag[position] == "k":
        return ("\\k", position + 1)
    return None


def split_override_tags(block: str) -> list[str]:
    """Split an override block into individual tags."""
    tags: list[str] = []
    index = 0
    while index < len(block):
        while index < len(block) and block[index] != "\\":
            index += 1
        if index >= len(block):
            break

        start = index
        index += 1
        paren_depth = 0
        while index < len(block):
            char = block[index]
            if char == "(":
                paren_depth += 1
            elif char == ")" and paren_depth > 0:
                paren_depth -= 1
            elif char == "\\" and paren_depth == 0:
                break
            index += 1

        tags.append(block[start:index])

    return tags


def parse_karaoke_tag(tag: str) -> tuple[str, int] | None:
    """Parse a karaoke duration tag into its normalized form."""
    if len(tag) < 2 or tag[0] != "\\":
        return None

    position = 1
    parsed_name = _karaoke_tag_name(tag, position)
    if parsed_name is None:
        return None
    normalized_name, position = parsed_name

    negative = False
    if position < len(tag) and tag[position] == "-":
        negative = True
        position += 1

    digits_start = position
    while position < len(tag) and tag[position].isdigit():
        position += 1

    value = int(tag[digits_start:position]) if position > digits_start else 0
    if negative:
        value = -value

    return normalized_name, value * 10
