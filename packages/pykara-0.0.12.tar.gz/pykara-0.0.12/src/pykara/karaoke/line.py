"""Karaoke line data model."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from pykara.karaoke.char import Char
from pykara.karaoke.syllable import Syllable
from pykara.karaoke.word import Word

if TYPE_CHECKING:
    from pykara.layout.style import LayoutStyle


@dataclass(slots=True)
class Line:
    """A parsed karaoke dialogue line with complete metadata.

    Stores timing, actor, margins, effective margin calculations, text
    analysis (plain/trimmed/space handling), syllable/word/character
    decompositions, and layout positioning fields populated during
    karaoke parsing and layout passes.
    """

    start_time: int
    end_time: int
    duration: int
    actor: str
    style: LayoutStyle | None = None
    margin_l: int = 0
    margin_r: int = 0
    margin_v: int = 0
    effective_margin_left: int = 0
    effective_margin_right: int = 0
    effective_margin_top: int = 0
    effective_margin_bottom: int = 0
    effective_margin_vertical: int = 0
    plain_text: str = ""
    trimmed_text: str = ""
    length: int = 0
    is_blank: bool = False
    is_space: bool = False
    syls: list[Syllable] = field(default_factory=list[Syllable])
    words: list[Word] = field(default_factory=list[Word])
    chars: list[Char] = field(default_factory=list[Char])
    raw_left: float = 0.0
    raw_center: float = 0.0
    raw_right: float = 0.0
    raw_width: float = 0.0
    left: int = 0
    center: int = 0
    right: int = 0
    width: int = 0
    top: int = 0
    middle: int = 0
    bottom: int = 0
    height: int = 0
    x: int = 0
    y: int = 0
    halign: str = ""
    valign: str = ""
