"""PLY raw vertex sampler and occupancy proxy builder for 3DGS splat files.

Two families of functions:

parse_splat()           — sample up to N raw vertices, return columnar JSON.
                          Server decodes sigmoid/exp and runs quality metrics.

build_occupancy_proxy() — load ALL Gaussians, filter, voxelise, return compact
                          occupied-voxel-index list. No sampling limit because
                          voxel coverage requires the full point cloud. The
                          resulting JSON is tiny (~30 KB for a typical room)
                          regardless of scene size.

Raw opacity/scale values are never decoded in parse_splat; the server owns that
logic. build_occupancy_proxy must decode them locally to filter correctly, but
the voxelisation itself (binning + inflation) is standard robotics math — it is
NOT proprietary and belongs here.

Requires: pip install 'spatio-local[splat]'  (plyfile + numpy)
"""
from __future__ import annotations

import os
import sys
import time

from spatio_local import __version__

# Properties extracted when present (all others are ignored)
_EXTRACT_PROPS = (
    "x", "y", "z",
    "opacity",
    "scale_0", "scale_1", "scale_2",
    "f_dc_0", "f_dc_1", "f_dc_2",
)

# Occupancy proxy constants
_MAX_INFLATE_R = 3         # max voxel inflation radius (3 × voxel_size_m)
_MAX_GRID_CELLS = 50_000_000  # ~50 MB bool grid; fallback to no-inflate if exceeded


def parse_splat(
    path: str,
    max_gaussians: int = 10_000,
    sample_strategy: str = "uniform",
    extra_meta: dict | None = None,
) -> dict:
    """Sample raw vertices from a PLY file and return columnar JSON.

    Parameters
    ----------
    path:
        Path to the .ply file.
    max_gaussians:
        Maximum number of vertices to include in the JSON output.
    sample_strategy:
        "uniform" (evenly spaced across the file) or "first" (first N rows).
    extra_meta:
        Arbitrary key-value pairs echoed back under "_params" so the server
        knows the full algorithm parameters (opacity_threshold, voxel_size_m, …).
    """
    start = time.monotonic()

    if not os.path.isfile(path):
        print(f"File does not exist: {path}", file=sys.stderr)
        sys.exit(1)

    try:
        import numpy as np
        from plyfile import PlyData
    except ImportError as exc:
        missing = str(exc).split("'")[1] if "'" in str(exc) else str(exc)
        print(
            f"Missing dependency: {missing}\n"
            "Install with:  pip install 'spatio-local[splat]'\n"
            "               pip install plyfile numpy",
            file=sys.stderr,
        )
        sys.exit(2)

    ply_format = _read_ply_format(path)

    try:
        plydata = PlyData.read(path)
    except Exception as exc:
        print(f"Failed to read PLY: {exc}", file=sys.stderr)
        sys.exit(1)

    vertex = plydata["vertex"]
    n_total = len(vertex)
    fields: list[str] = list(vertex.dtype.names or [])

    # Build sample indices
    n_sample = min(n_total, max_gaussians)
    if n_total == 0:
        indices = np.array([], dtype=int)
    elif sample_strategy == "first" or n_total <= max_gaussians:
        indices = np.arange(n_sample)
    else:
        indices = np.linspace(0, n_total - 1, n_sample, dtype=int)

    out: dict = {
        "ply_format": ply_format,
        "gaussian_count": n_total,
        "file_size_bytes": os.path.getsize(path),
        "fields": fields,
        "sample_count": int(n_sample),
        "sample_strategy": sample_strategy,
    }

    # Extract only the properties that exist in this file
    for prop in _EXTRACT_PROPS:
        if prop in fields and n_sample > 0:
            out[prop] = vertex[prop][indices].tolist()

    out["parse_duration_ms"] = int((time.monotonic() - start) * 1000)
    out["spatio_local_version"] = __version__
    out["python_version"] = (
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )

    if extra_meta:
        out["_params"] = extra_meta

    return out


def parse_npz_proxy(path: str, extra_meta: dict | None = None) -> dict:
    """Load a pre-computed occupancy proxy (.npz) and return its arrays as JSON.

    The .npz is produced by a prior splat-to-occupancy conversion. All arrays
    are returned verbatim; the cloud server performs collision detection.
    """
    start = time.monotonic()

    if not os.path.isfile(path):
        print(f"File does not exist: {path}", file=sys.stderr)
        sys.exit(1)

    try:
        import numpy as np
    except ImportError:
        print(
            "Missing dependency: numpy\n"
            "Install with:  pip install 'spatio-local[splat]'",
            file=sys.stderr,
        )
        sys.exit(2)

    try:
        data = np.load(path, allow_pickle=False)
    except Exception as exc:
        print(f"Failed to load NPZ proxy: {exc}", file=sys.stderr)
        sys.exit(1)

    out: dict = {
        "proxy_type": "occupancy_npz",
        "proxy_path": path,
        "file_size_bytes": os.path.getsize(path),
    }

    for key in data.files:
        arr = data[key]
        if arr.ndim == 0:
            out[key] = arr.item()
        else:
            out[key] = arr.tolist()

    out["parse_duration_ms"] = int((time.monotonic() - start) * 1000)
    out["spatio_local_version"] = __version__
    out["python_version"] = (
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )

    if extra_meta:
        out["_params"] = extra_meta

    return out


def _read_ply_format(path: str) -> str:
    """Return PLY format string from the header without loading vertices."""
    try:
        with open(path, "rb") as fh:
            for _ in range(20):
                line = fh.readline().decode("ascii", errors="ignore").strip()
                if line.startswith("format "):
                    return line.split()[1]
    except Exception:
        pass
    return "unknown"


def build_pointcloud_proxy(
    path: str,
    max_output_points: int = 100_000,
    opacity_threshold: float = 0.01,
    extra_meta: dict | None = None,
) -> dict:
    """Load ALL Gaussians, filter by opacity, sample survivors, decode RGB.

    Unlike parse_splat (which samples N raw vertices before filtering), this
    function loads the full point cloud, applies the opacity filter, then
    uniformly samples up to max_output_points from the surviving set. This
    gives much better spatial coverage for dense scenes.

    Requires: pip install 'spatio-local[splat]'
    """
    start = time.monotonic()

    if not os.path.isfile(path):
        print(f"File does not exist: {path}", file=sys.stderr)
        sys.exit(1)

    try:
        import numpy as np
        from plyfile import PlyData
    except ImportError as exc:
        missing = str(exc).split("'")[1] if "'" in str(exc) else str(exc)
        print(
            f"Missing dependency: {missing}\n"
            "Install with:  pip install 'spatio-local[splat]'\n"
            "               pip install plyfile numpy",
            file=sys.stderr,
        )
        sys.exit(2)

    ply_format = _read_ply_format(path)

    try:
        plydata = PlyData.read(path)
    except Exception as exc:
        print(f"Failed to read PLY: {exc}", file=sys.stderr)
        sys.exit(1)

    vertex = plydata["vertex"]
    n_total = len(vertex)
    fields: list[str] = list(vertex.dtype.names or [])

    _C0 = 0.28209479177387814  # SH order-0 coefficient

    def _empty_proxy() -> dict:
        r: dict = {
            "proxy_type": "pointcloud",
            "ply_format": ply_format,
            "gaussian_count": n_total,
            "n_filtered": 0,
            "n_output": 0,
            "opacity_threshold": opacity_threshold,
            "x": [], "y": [], "z": [],
            "quality_flags": ["all_filtered"],
            "parse_duration_ms": int((time.monotonic() - start) * 1000),
            "spatio_local_version": __version__,
            "python_version": (
                f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
            ),
        }
        if extra_meta:
            r["_params"] = extra_meta
        return r

    if n_total == 0:
        return _empty_proxy()

    x = np.array(vertex["x"], dtype=np.float32)
    y = np.array(vertex["y"], dtype=np.float32)
    z = np.array(vertex["z"], dtype=np.float32)

    # Opacity filter: sigmoid(raw) >= threshold
    if "opacity" in fields:
        opacity_dec = 1.0 / (1.0 + np.exp(-np.array(vertex["opacity"], dtype=np.float32)))
        keep = opacity_dec >= opacity_threshold
    else:
        keep = np.ones(n_total, dtype=bool)

    x_f, y_f, z_f = x[keep], y[keep], z[keep]
    n_filtered = int(keep.sum())

    if n_filtered == 0:
        return _empty_proxy()

    # Uniform sample from survivors
    if n_filtered <= max_output_points:
        idx = np.arange(n_filtered)
    else:
        idx = np.linspace(0, n_filtered - 1, max_output_points, dtype=int)
    n_output = len(idx)

    out: dict = {
        "proxy_type": "pointcloud",
        "ply_format": ply_format,
        "gaussian_count": n_total,
        "n_filtered": n_filtered,
        "n_output": n_output,
        "opacity_threshold": opacity_threshold,
        "x": x_f[idx].tolist(),
        "y": y_f[idx].tolist(),
        "z": z_f[idx].tolist(),
    }

    # Decode SH DC → linear RGB if f_dc channels are present
    has_color = all(f"f_dc_{i}" in fields for i in range(3))
    if has_color:
        dc0 = np.array(vertex["f_dc_0"], dtype=np.float32)[keep][idx]
        dc1 = np.array(vertex["f_dc_1"], dtype=np.float32)[keep][idx]
        dc2 = np.array(vertex["f_dc_2"], dtype=np.float32)[keep][idx]
        out["r"] = np.clip(0.5 + _C0 * dc0, 0.0, 1.0).tolist()
        out["g"] = np.clip(0.5 + _C0 * dc1, 0.0, 1.0).tolist()
        out["b"] = np.clip(0.5 + _C0 * dc2, 0.0, 1.0).tolist()

    flags: list[str] = []
    if n_output < 100:
        flags.append("very_sparse_proxy")
    if not has_color:
        flags.append("no_color_xyz_only")
    out["quality_flags"] = flags

    out["parse_duration_ms"] = int((time.monotonic() - start) * 1000)
    out["spatio_local_version"] = __version__
    out["python_version"] = (
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    if extra_meta:
        out["_params"] = extra_meta

    return out


def build_occupancy_proxy(
    path: str,
    voxel_size_m: float = 0.10,
    opacity_threshold: float = 0.05,
    max_scale_m: float = 0.5,
    inflate_by_scale: bool = True,
    output_dir: str | None = None,
    extra_meta: dict | None = None,
) -> dict:
    """Build a conservative voxel occupancy proxy from a 3DGS PLY.

    Loads the FULL point cloud (no sampling limit) — coverage requires all
    Gaussians. Filters by opacity and scale, bins centres into a voxel grid,
    then inflates each occupied voxel via repeated binary dilation (no scipy).

    Inflation radius per voxel = ceil(dominant_scale / voxel_size_m), capped
    at _MAX_INFLATE_R. A global margin = max(inflate_r) is applied across the
    whole grid, which is conservative but correct for a safety-first product.

    If output_dir is given, also saves a compressed .npz (occupied, voxel_size_m,
    origin) so the agent can reuse the proxy across multiple validation calls.

    Returns a compact dict: occupied voxel indices + metadata. Typical room at
    0.1 m resolution produces < 50 k voxels — the JSON payload is ~30 KB.
    """
    start = time.monotonic()

    if not os.path.isfile(path):
        print(f"File does not exist: {path}", file=sys.stderr)
        sys.exit(1)

    try:
        import numpy as np
        from plyfile import PlyData
    except ImportError as exc:
        missing = str(exc).split("'")[1] if "'" in str(exc) else str(exc)
        print(
            f"Missing dependency: {missing}\n"
            "Install with:  pip install 'spatio-local[splat]'",
            file=sys.stderr,
        )
        sys.exit(2)

    try:
        plydata = PlyData.read(path)
    except Exception as exc:
        print(f"Failed to read PLY: {exc}", file=sys.stderr)
        sys.exit(1)

    vertex = plydata["vertex"]
    n_total = len(vertex)
    fields: list[str] = list(vertex.dtype.names or [])

    def _empty() -> dict:
        r: dict = {
            "proxy_type": "occupancy",
            "gaussian_count": n_total,
            "n_filtered": 0,
            "n_voxels": 0,
            "voxel_size_m": float(voxel_size_m),
            "origin": [0.0, 0.0, 0.0],
            "occupied": [],
            "quality_flags": ["all_filtered"],
            "parse_duration_ms": int((time.monotonic() - start) * 1000),
            "spatio_local_version": __version__,
            "python_version": (
                f"{sys.version_info.major}.{sys.version_info.minor}"
                f".{sys.version_info.micro}"
            ),
        }
        if extra_meta:
            r["_params"] = extra_meta
        return r

    if n_total == 0:
        return _empty()

    x = np.array(vertex["x"], dtype=np.float32)
    y = np.array(vertex["y"], dtype=np.float32)
    z = np.array(vertex["z"], dtype=np.float32)

    # Opacity filter: sigmoid(raw) >= threshold
    if "opacity" in fields:
        opacity_dec = 1.0 / (1.0 + np.exp(-np.array(vertex["opacity"], dtype=np.float32)))
        keep = opacity_dec >= opacity_threshold
    else:
        keep = np.ones(n_total, dtype=bool)

    # Scale filter + dominant scale for inflation radius
    has_scales = all(f"scale_{i}" in fields for i in range(3))
    dominant_scale: "np.ndarray | None" = None
    if has_scales:
        scales_m = np.exp(np.stack([
            np.array(vertex["scale_0"], dtype=np.float32),
            np.array(vertex["scale_1"], dtype=np.float32),
            np.array(vertex["scale_2"], dtype=np.float32),
        ], axis=1))
        dominant_scale = scales_m.max(axis=1)
        keep &= dominant_scale <= max_scale_m

    x_f, y_f, z_f = x[keep], y[keep], z[keep]
    n_kept = int(keep.sum())

    if n_kept == 0:
        return _empty()

    # Grid-aligned origin (world coordinates of voxel [0,0,0])
    origin = np.array([
        float(np.floor(x_f.min() / voxel_size_m) * voxel_size_m),
        float(np.floor(y_f.min() / voxel_size_m) * voxel_size_m),
        float(np.floor(z_f.min() / voxel_size_m) * voxel_size_m),
    ])

    i_idx = np.floor((x_f - origin[0]) / voxel_size_m).astype(np.int32)
    j_idx = np.floor((y_f - origin[1]) / voxel_size_m).astype(np.int32)
    k_idx = np.floor((z_f - origin[2]) / voxel_size_m).astype(np.int32)

    # Inflation margin: max over all Gaussians, capped
    if inflate_by_scale and dominant_scale is not None:
        dom_kept = dominant_scale[keep]
        inflate_r = np.clip(
            np.ceil(dom_kept / voxel_size_m).astype(np.int32), 0, _MAX_INFLATE_R
        )
        margin = int(inflate_r.max())
    else:
        margin = 0

    # Boolean grid: tight bbox + margin padding on all sides
    i_lo = int(i_idx.min()) - margin
    j_lo = int(j_idx.min()) - margin
    k_lo = int(k_idx.min()) - margin
    grid_shape = (
        int(i_idx.max()) - int(i_idx.min()) + 2 * margin + 1,
        int(j_idx.max()) - int(j_idx.min()) + 2 * margin + 1,
        int(k_idx.max()) - int(k_idx.min()) + 2 * margin + 1,
    )

    if grid_shape[0] * grid_shape[1] * grid_shape[2] > _MAX_GRID_CELLS:
        # Scene too large for inflated grid — fall back to centre voxels only
        print(
            f"Warning: occupancy grid would exceed {_MAX_GRID_CELLS} cells; "
            "inflation disabled, using centre voxels only.",
            file=sys.stderr,
        )
        margin = 0
        i_lo = int(i_idx.min())
        j_lo = int(j_idx.min())
        k_lo = int(k_idx.min())
        grid_shape = (
            int(i_idx.max()) - i_lo + 1,
            int(j_idx.max()) - j_lo + 1,
            int(k_idx.max()) - k_lo + 1,
        )

    grid = np.zeros(grid_shape, dtype=np.bool_)
    grid[i_idx - i_lo, j_idx - j_lo, k_idx - k_lo] = True

    # Repeated face-adjacent binary dilation (no scipy)
    for _ in range(margin):
        dilated = grid.copy()
        dilated[1:] |= grid[:-1];    dilated[:-1] |= grid[1:]
        dilated[:, 1:] |= grid[:, :-1]; dilated[:, :-1] |= grid[:, 1:]
        dilated[:, :, 1:] |= grid[:, :, :-1]; dilated[:, :, :-1] |= grid[:, :, 1:]
        grid = dilated

    local_ijk = np.argwhere(grid).astype(np.int32)
    occupied_arr = local_ijk + np.array([[i_lo, j_lo, k_lo]], dtype=np.int32)
    n_voxels = len(occupied_arr)

    result: dict = {
        "proxy_type": "occupancy",
        "gaussian_count": n_total,
        "n_filtered": n_kept,
        "n_voxels": n_voxels,
        "voxel_size_m": float(voxel_size_m),
        "origin": origin.tolist(),
        "occupied": occupied_arr.tolist(),
        "inflate_margin_voxels": margin,
        "parse_duration_ms": int((time.monotonic() - start) * 1000),
        "spatio_local_version": __version__,
        "python_version": (
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        ),
    }

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        npz_path = os.path.join(output_dir, "occupancy_proxy.npz")
        np.savez_compressed(
            npz_path,
            occupied=occupied_arr,
            voxel_size_m=np.float32(voxel_size_m),
            origin=origin.astype(np.float32),
        )
        result["proxy_path"] = npz_path

    if extra_meta:
        result["_params"] = extra_meta

    return result
