"""COLMAP sparse reconstruction parser.

Loads a COLMAP project and emits a structured JSON summary the cloud server
uses to complete validation without receiving the raw point cloud.

Requires: pip install 'spatio-local[colmap]'  (pycolmap + numpy)
"""
from __future__ import annotations

import os
import sys
import time

from spatio_local import __version__


def parse_colmap(path: str) -> dict:
    start = time.monotonic()

    if not os.path.isdir(path):
        print(f"Path does not exist or is not a directory: {path}", file=sys.stderr)
        sys.exit(1)

    try:
        import numpy as np
        import pycolmap
    except ImportError as exc:
        missing = str(exc).split("'")[1] if "'" in str(exc) else str(exc)
        print(
            f"Missing dependency: {missing}\n"
            "Install with:  pip install 'spatio-local[colmap]'\n"
            "               pip install pycolmap numpy",
            file=sys.stderr,
        )
        sys.exit(2)

    rec = pycolmap.Reconstruction(path)
    points = rec.points3D

    if not points:
        return _build_result(
            path,
            point_count=0,
            bounds={"min": [0.0, 0.0, 0.0], "max": [0.0, 0.0, 0.0]},
            camera_count=len(rec.cameras),
            image_count=len(rec.images),
            mean_reprojection_error=None,
            duration_ms=int((time.monotonic() - start) * 1000),
        )

    xyz = np.array([p.xyz for p in points.values()])
    mean_error = float(np.mean([p.error for p in points.values()]))

    return _build_result(
        path,
        point_count=len(points),
        bounds={
            "min": xyz.min(axis=0).tolist(),
            "max": xyz.max(axis=0).tolist(),
        },
        camera_count=len(rec.cameras),
        image_count=len(rec.images),
        mean_reprojection_error=mean_error,
        duration_ms=int((time.monotonic() - start) * 1000),
    )


def _build_result(
    path: str,
    *,
    point_count: int,
    bounds: dict,
    camera_count: int,
    image_count: int,
    mean_reprojection_error: float | None,
    duration_ms: int,
) -> dict:
    return {
        "format": "colmap",
        "path": path,
        "point_count": point_count,
        "bounds": bounds,
        "camera_count": camera_count,
        "image_count": image_count,
        "mean_reprojection_error": mean_reprojection_error,
        "parse_duration_ms": duration_ms,
        "spatio_local_version": __version__,
        "python_version": (
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        ),
    }
