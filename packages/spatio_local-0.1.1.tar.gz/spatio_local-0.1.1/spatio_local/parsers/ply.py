"""PLY file parser — supports standard point clouds and 3DGS splat .ply files.

Requires: pip install 'spatio-local[ply]'  (plyfile + numpy)
"""
from __future__ import annotations

import os
import sys
import time

from spatio_local import __version__


def parse_ply(path: str) -> dict:
    start = time.monotonic()

    if not os.path.isfile(path):
        print(f"File does not exist: {path}", file=sys.stderr)
        sys.exit(1)

    try:
        import numpy as np
        from plyfile import PlyData
    except ImportError as exc:
        missing = str(exc).split("'")[1] if "'" in str(exc) else str(exc)
        print(
            f"Missing dependency: {missing}\n"
            "Install with:  pip install 'spatio-local[ply]'\n"
            "               pip install plyfile numpy",
            file=sys.stderr,
        )
        sys.exit(2)

    plydata = PlyData.read(path)
    vertex = plydata["vertex"]
    point_count = len(vertex)
    field_names: tuple = vertex.dtype.names or ()

    # 3DGS splats have f_dc_* or scale_* fields
    is_splat = any(n.startswith("f_dc_") or n.startswith("scale_") for n in field_names)

    if point_count > 0:
        xyz = np.column_stack([vertex["x"], vertex["y"], vertex["z"]])
        bounds = {
            "min": xyz.min(axis=0).tolist(),
            "max": xyz.max(axis=0).tolist(),
        }
    else:
        bounds = {"min": [0.0, 0.0, 0.0], "max": [0.0, 0.0, 0.0]}

    return {
        "format": "splat" if is_splat else "ply",
        "path": path,
        "file_size_bytes": os.path.getsize(path),
        "point_count": point_count,
        "bounds": bounds,
        "is_3dgs_splat": is_splat,
        "fields": list(field_names),
        "parse_duration_ms": int((time.monotonic() - start) * 1000),
        "spatio_local_version": __version__,
        "python_version": (
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        ),
    }
