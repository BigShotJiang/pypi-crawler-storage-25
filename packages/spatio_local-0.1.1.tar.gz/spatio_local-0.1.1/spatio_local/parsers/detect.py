"""Spatial input type detector.

Reads only the PLY header (never loads vertices) or lists directory contents
to determine the input type. No heavy dependencies required.

Detected types:
  splat           — PLY with 3DGS-specific properties (f_dc_*, scale_*, rot_*)
  pointcloud      — PLY without splat properties
  colmap          — Directory containing cameras.txt / images.txt / points3D.txt
  tum_rgbd        — Directory containing rgb.txt / depth.txt
  unknown         — Anything else
"""
from __future__ import annotations

import sys
from pathlib import Path

from spatio_local import __version__

# 3DGS-specific PLY property names (any one is enough to classify as splat)
_SPLAT_PROP_MARKERS = {"f_dc_0", "scale_0", "rot_0", "opacity"}

_COLMAP_MARKERS = {"cameras.txt", "images.txt", "points3D.txt"}
_TUM_MARKERS = {"rgb.txt", "depth.txt"}


def detect_input(path: str) -> dict:
    p = Path(path)

    if p.is_dir():
        return _detect_directory(p)
    if p.is_file():
        return _detect_file(p)

    return {
        "detected_type": "unknown",
        "path": str(path),
        "error": "Path does not exist",
        "spatio_local_version": __version__,
        "python_version": (
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        ),
    }


def _detect_directory(p: Path) -> dict:
    try:
        top_files = {f.name for f in p.iterdir() if f.is_file()}
    except PermissionError:
        top_files = set()

    if _COLMAP_MARKERS.issubset(top_files):
        detected_type = "colmap"
    elif _TUM_MARKERS.issubset(top_files):
        detected_type = "tum_rgbd"
    else:
        detected_type = "unknown_directory"

    return {
        "detected_type": detected_type,
        "path": str(p),
        "is_file": False,
        "contents": sorted(top_files)[:50],
        "spatio_local_version": __version__,
        "python_version": (
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        ),
    }


def _detect_file(p: Path) -> dict:
    result: dict = {
        "path": str(p),
        "is_file": True,
        "file_size_bytes": p.stat().st_size,
        "spatio_local_version": __version__,
        "python_version": (
            f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        ),
    }

    if p.suffix.lower() != ".ply":
        result["detected_type"] = "unknown_file"
        return result

    ply_format, vertex_count, property_names = _read_ply_header(str(p))
    result["ply_format"] = ply_format
    result["gaussian_count"] = vertex_count
    result["fields"] = property_names

    prop_set = set(property_names)
    result["detected_type"] = "splat" if (prop_set & _SPLAT_PROP_MARKERS) else "pointcloud"

    return result


def _read_ply_header(path: str) -> tuple[str, int, list[str]]:
    """Return (format, vertex_count, property_names) from PLY header only."""
    ply_format = "unknown"
    vertex_count = 0
    property_names: list[str] = []
    in_vertex_element = False

    try:
        with open(path, "rb") as fh:
            for _ in range(500):
                raw = fh.readline()
                if not raw:
                    break
                line = raw.decode("ascii", errors="ignore").strip()
                if line == "end_header":
                    break
                if line.startswith("format "):
                    parts = line.split()
                    if len(parts) >= 2:
                        ply_format = parts[1]
                elif line.startswith("element vertex "):
                    parts = line.split()
                    vertex_count = int(parts[-1])
                    in_vertex_element = True
                elif line.startswith("element ") and in_vertex_element:
                    in_vertex_element = False
                elif line.startswith("property ") and in_vertex_element:
                    parts = line.split()
                    if len(parts) >= 3:
                        property_names.append(parts[-1])
    except Exception:
        pass

    return ply_format, vertex_count, property_names
