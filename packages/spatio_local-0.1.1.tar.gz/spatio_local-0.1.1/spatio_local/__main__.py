from spatio_local.cli import main

if __name__ == "__main__":
    main()
