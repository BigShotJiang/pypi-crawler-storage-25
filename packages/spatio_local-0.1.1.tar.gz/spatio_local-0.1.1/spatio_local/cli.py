"""spatio-local CLI.

Invoked by Claude Code (or another agent) via its bash tool when the Spatio
cloud server requests local file parsing. Each subcommand parses one file type
and emits structured JSON to stdout. Nothing else goes to stdout — errors and
progress go to stderr.
"""
from __future__ import annotations

import argparse
import json
import sys


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="spatio-local",
        description="Local execution helpers for the Spatio cloud MCP server",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # ------------------------------------------------------------------
    # version
    # ------------------------------------------------------------------
    sub.add_parser("version", help="Print spatio-local version")

    # ------------------------------------------------------------------
    # parse-colmap  (existing)
    # ------------------------------------------------------------------
    p_colmap = sub.add_parser(
        "parse-colmap",
        help="Parse a COLMAP sparse reconstruction and emit a structured JSON summary",
    )
    p_colmap.add_argument("--path", required=True, help="Path to COLMAP project directory")

    # ------------------------------------------------------------------
    # parse-ply  (existing)
    # ------------------------------------------------------------------
    p_ply = sub.add_parser(
        "parse-ply",
        help="Parse a PLY file (including 3DGS splats) and emit a structured JSON summary",
    )
    p_ply.add_argument("--path", required=True, help="Path to .ply file")

    # ------------------------------------------------------------------
    # inspect-input  (new)
    # ------------------------------------------------------------------
    p_detect = sub.add_parser(
        "inspect-input",
        help="Auto-detect spatial input type (PLY, COLMAP folder, TUM RGB-D folder)",
    )
    p_detect.add_argument("--path", required=True, help="Path to file or directory")

    # ------------------------------------------------------------------
    # inspect-splat  (new)
    # ------------------------------------------------------------------
    p_splat = sub.add_parser(
        "inspect-splat",
        help="Sample raw vertices from a 3DGS PLY and emit columnar JSON for cloud quality analysis",
    )
    p_splat.add_argument("--path", required=True, help="Path to .ply file")
    p_splat.add_argument("--max-gaussians", type=int, default=10_000,
                         help="Maximum vertices to sample (default: 10000)")
    p_splat.add_argument("--sample-strategy", choices=["uniform", "first"], default="uniform")
    p_splat.add_argument("--generate-assertion", action="store_true",
                         help="Hint to cloud server to generate an assertion script")
    p_splat.add_argument("--export-pointcloud-proxy", action="store_true",
                         help="Hint to cloud server to export a point-cloud proxy")
    p_splat.add_argument("--opacity-threshold", type=float, default=0.01)
    p_splat.add_argument("--max-scale-m", type=float, default=1.0)

    # ------------------------------------------------------------------
    # generate-splat-assertion  (new)
    # ------------------------------------------------------------------
    p_assert = sub.add_parser(
        "generate-splat-assertion",
        help="Sample a 3DGS PLY and send to cloud to generate a data-integrity assertion script",
    )
    p_assert.add_argument("--path", required=True)
    p_assert.add_argument("--max-gaussians", type=int, default=10_000)
    p_assert.add_argument("--opacity-threshold", type=float, default=0.01)
    p_assert.add_argument("--max-scale-m", type=float, default=1.0)
    p_assert.add_argument("--output-dir", default="outputs/splat_inspect")

    # ------------------------------------------------------------------
    # splat-to-proxy  (new)
    # ------------------------------------------------------------------
    p_proxy = sub.add_parser(
        "splat-to-proxy",
        help="Load ALL Gaussians, filter by opacity, sample survivors, decode RGB — build a point-cloud proxy locally",
    )
    p_proxy.add_argument("--path", required=True)
    p_proxy.add_argument("--output-path", default="outputs/splat_proxy.ply",
                         help="Output path hint passed to cloud server")
    p_proxy.add_argument("--max-output-points", type=int, default=100_000,
                         help="Maximum points to include after opacity filtering (default: 100000)")
    p_proxy.add_argument("--opacity-threshold", type=float, default=0.01)

    # ------------------------------------------------------------------
    # splat-to-occupancy  (new)
    # ------------------------------------------------------------------
    p_occ = sub.add_parser(
        "splat-to-occupancy",
        help="Sample a 3DGS PLY for cloud-side voxel occupancy proxy construction",
    )
    p_occ.add_argument("--path", required=True)
    p_occ.add_argument("--max-gaussians", type=int, default=10_000)
    p_occ.add_argument("--voxel-size-m", type=float, default=0.10)
    p_occ.add_argument("--opacity-threshold", type=float, default=0.05)
    p_occ.add_argument("--max-scale-m", type=float, default=0.5)
    p_occ.add_argument("--inflate-by-scale", action="store_true", default=True)
    p_occ.add_argument("--no-inflate-by-scale", dest="inflate_by_scale", action="store_false")
    p_occ.add_argument("--sample-strategy", choices=["uniform", "first"], default="uniform")
    p_occ.add_argument("--output-dir", default="outputs/splat_occupancy")

    # ------------------------------------------------------------------
    # validate-splat-proxy  (new)
    # ------------------------------------------------------------------
    p_val = sub.add_parser(
        "validate-splat-proxy",
        help="Load occupancy proxy (.npz) or build one from a PLY, then send to cloud for collision validation",
    )
    p_val.add_argument("--proxy-path", help="Path to pre-computed .npz occupancy proxy")
    p_val.add_argument("--source-path", help="Path to 3DGS PLY — proxy is built locally then sent to cloud")
    p_val.add_argument("--robot-width-m", type=float, default=0.70)
    p_val.add_argument("--robot-height-m", type=float, default=1.50)
    p_val.add_argument("--safety-margin-m", type=float, default=0.10)
    p_val.add_argument("--step-m", type=float, default=0.10)
    p_val.add_argument("--route-waypoints",
                       help="JSON array of [x,y,z] waypoints, e.g. '[[0,0,0],[1,0,0]]'")
    p_val.add_argument("--output-dir", default="outputs/splat_validation")
    # Voxel params — used only when --source-path is given (building the proxy locally)
    p_val.add_argument("--voxel-size-m", type=float, default=0.10)
    p_val.add_argument("--opacity-threshold", type=float, default=0.05)
    p_val.add_argument("--max-scale-m", type=float, default=0.5)
    p_val.add_argument("--inflate-by-scale", action="store_true", default=True)
    p_val.add_argument("--no-inflate-by-scale", dest="inflate_by_scale", action="store_false")

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------
    args = parser.parse_args()

    if args.cmd == "version":
        from spatio_local import __version__
        print(json.dumps({"spatio_local_version": __version__}))
        return

    if args.cmd == "parse-colmap":
        from spatio_local.parsers.colmap import parse_colmap
        result = parse_colmap(args.path)

    elif args.cmd == "parse-ply":
        from spatio_local.parsers.ply import parse_ply
        result = parse_ply(args.path)

    elif args.cmd == "inspect-input":
        from spatio_local.parsers.detect import detect_input
        result = detect_input(args.path)

    elif args.cmd == "inspect-splat":
        from spatio_local.parsers.splat import parse_splat
        result = parse_splat(
            args.path,
            max_gaussians=args.max_gaussians,
            sample_strategy=args.sample_strategy,
            extra_meta={
                "opacity_threshold": args.opacity_threshold,
                "max_scale_m": args.max_scale_m,
                "generate_assertion": args.generate_assertion,
                "export_pointcloud_proxy": args.export_pointcloud_proxy,
            },
        )

    elif args.cmd == "generate-splat-assertion":
        from spatio_local.parsers.splat import parse_splat
        result = parse_splat(
            args.path,
            max_gaussians=args.max_gaussians,
            sample_strategy="uniform",
            extra_meta={
                "opacity_threshold": args.opacity_threshold,
                "max_scale_m": args.max_scale_m,
                "output_dir": args.output_dir,
            },
        )

    elif args.cmd == "splat-to-proxy":
        from spatio_local.parsers.splat import build_pointcloud_proxy
        result = build_pointcloud_proxy(
            args.path,
            max_output_points=args.max_output_points,
            opacity_threshold=args.opacity_threshold,
            extra_meta={"output_path": args.output_path},
        )

    elif args.cmd == "splat-to-occupancy":
        from spatio_local.parsers.splat import build_occupancy_proxy
        result = build_occupancy_proxy(
            args.path,
            voxel_size_m=args.voxel_size_m,
            opacity_threshold=args.opacity_threshold,
            max_scale_m=args.max_scale_m,
            inflate_by_scale=args.inflate_by_scale,
            output_dir=args.output_dir,
        )

    elif args.cmd == "validate-splat-proxy":
        if not args.proxy_path and not args.source_path:
            print("Error: --proxy-path or --source-path is required", file=sys.stderr)
            sys.exit(1)

        robot_meta = {
            "robot_width_m": args.robot_width_m,
            "robot_height_m": args.robot_height_m,
            "safety_margin_m": args.safety_margin_m,
            "step_m": args.step_m,
            "route_waypoints": args.route_waypoints,
            "output_dir": args.output_dir,
        }

        if args.proxy_path:
            from spatio_local.parsers.splat import parse_npz_proxy
            result = parse_npz_proxy(args.proxy_path, extra_meta=robot_meta)
        else:
            # Build the occupancy proxy locally from the full PLY, then send the
            # compact voxel grid to the cloud for collision detection.
            from spatio_local.parsers.splat import build_occupancy_proxy
            result = build_occupancy_proxy(
                args.source_path,
                voxel_size_m=args.voxel_size_m,
                opacity_threshold=args.opacity_threshold,
                max_scale_m=args.max_scale_m,
                inflate_by_scale=args.inflate_by_scale,
                output_dir=args.output_dir,
                extra_meta=robot_meta,
            )

    else:
        parser.error(f"Unknown command: {args.cmd}")
        return

    print(json.dumps(result))


if __name__ == "__main__":
    main()
