"""Asynchronous eksisozluk thread scraper."""
