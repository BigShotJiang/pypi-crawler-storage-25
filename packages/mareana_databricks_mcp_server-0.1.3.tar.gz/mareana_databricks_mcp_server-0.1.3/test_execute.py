import asyncio
import os
import sys
import json

# Add the src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from databricks_mcp_server.databricks_client import execute_query

async def main():
    os.environ["DATABRICKS_PROFILE"] = "mareana_vsm"
    sql = "SELECT * FROM mareana_vsm.kpi.inventory_kpi_agg LIMIT 3"
    print(f"Testing execute_query with: {sql}")
    result = await execute_query(sql, max_rows=3)
    print("Result:")
    print(result)

if __name__ == "__main__":
    asyncio.run(main())
