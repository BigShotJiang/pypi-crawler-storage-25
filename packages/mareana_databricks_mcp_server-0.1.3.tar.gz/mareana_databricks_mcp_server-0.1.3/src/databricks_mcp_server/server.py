"""
Databricks MCP Server Entry Point
"""

from .databricks_client import main


def main_entry():
    """Entry point for the MCP server."""
    main()


if __name__ == "__main__":
    main_entry()
