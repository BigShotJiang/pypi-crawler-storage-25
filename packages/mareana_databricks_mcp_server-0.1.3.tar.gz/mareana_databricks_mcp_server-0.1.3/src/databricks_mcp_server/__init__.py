"""
Databricks MCP Server - Explore Unity Catalog via Databricks SDK
"""

__version__ = "0.1.3"
