def main() -> None:
    print("Hello from letscode!")
