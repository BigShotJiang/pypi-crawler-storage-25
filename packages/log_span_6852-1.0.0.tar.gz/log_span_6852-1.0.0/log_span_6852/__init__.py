"""Byte Discovery Pad"""
__version__ = "1.0.0"
