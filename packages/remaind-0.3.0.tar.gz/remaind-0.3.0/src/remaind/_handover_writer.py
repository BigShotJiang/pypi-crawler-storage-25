"""Atomic handover.md writer with required-section guard."""

from __future__ import annotations

from pathlib import Path

from ._atomic import atomic_write_text
from ._handover import REQUIRED_SECTIONS, section_headings
from ._paths import ContextPaths


class HandoverValidationError(Exception):
    """Raised when handover content is missing one or more required sections."""

    def __init__(self, missing: list[str]) -> None:
        super().__init__(
            "handover content missing required sections: " + ", ".join(missing)
        )
        self.missing = missing


def write_handover(base: Path, content: str) -> dict[str, object]:
    """Atomically write ``handover.md``.

    Validates that ``content`` contains every section in
    :data:`REQUIRED_SECTIONS` before writing. On failure, raises
    :class:`HandoverValidationError` and leaves the on-disk file untouched.

    Returns ``{"path": Path, "history": Path | None}``.
    """
    paths = ContextPaths.at(Path(base))
    present = set(section_headings(content))
    missing = [s for s in REQUIRED_SECTIONS if s not in present]
    if missing:
        raise HandoverValidationError(missing)

    history_dir = paths.history_dir / "handover"
    history_path = atomic_write_text(
        paths.handover_md, content, history_dir=history_dir
    )
    return {"path": paths.handover_md, "history": history_path}
