"""Minimal Crockford base32 ULID generator.

Produces 26-character ULIDs of the form `TTTTTTTTTTRRRRRRRRRRRRRRRR` where
the first 10 chars encode 48 bits of millisecond timestamp and the last 16
encode 80 bits of randomness. No third-party dependency.

Monotonicity guarantee: within a single process, successive calls to
``new_ulid()`` always return a strictly greater ULID under lexicographic
comparison. Within a single millisecond the random component is incremented
by 1 instead of being re-randomized; if the wall clock moves backward we
keep using the last observed millisecond. This is load-bearing for the
compaction anchor (``state.last_compaction_event_id``), which relies on
``event_id > anchor`` to identify post-anchor events.
"""

from __future__ import annotations

import os
import threading
import time

_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"  # Crockford base32
ULID_REGEX = r"[0-9A-HJKMNP-TV-Z]{26}"
_RAND_MASK = (1 << 80) - 1
_MS_MASK = (1 << 48) - 1

_lock = threading.Lock()
_last_ms = -1
_last_rand = 0


def _encode(value: int, length: int) -> str:
    out: list[str] = []
    for _ in range(length):
        out.append(_ALPHABET[value & 0x1F])
        value >>= 5
    return "".join(reversed(out))


def new_ulid() -> str:
    global _last_ms, _last_rand
    with _lock:
        ms = int(time.time() * 1000) & _MS_MASK
        if ms <= _last_ms:
            # Same millisecond or clock skew: stay at last_ms, bump rand.
            _last_rand = (_last_rand + 1) & _RAND_MASK
            ms_used = _last_ms
        else:
            _last_ms = ms
            _last_rand = int.from_bytes(os.urandom(10), "big")
            ms_used = ms
        return _encode(ms_used, 10) + _encode(_last_rand, 16)


def new_event_id() -> str:
    return f"evt_{new_ulid()}"


def new_memory_id() -> str:
    return f"mem_{new_ulid()}"
