"""Content-addressed artifact store under ``.context/artifacts/``.

Used by the event writer when a single payload exceeds the inline byte
threshold (text) or is binary. Filenames are ``{sha256}.{ext}`` so identical
content deduplicates automatically and the on-disk name is verifiable from
the recorded ``content_hash``.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class StoredArtifact:
    path: Path
    sha256: str
    bytes: int


class ArtifactStore:
    def __init__(self, root: Path) -> None:
        self._root = root

    @property
    def root(self) -> Path:
        return self._root

    def _ensure_root(self) -> None:
        self._root.mkdir(parents=True, exist_ok=True)

    def write_text(self, text: str) -> StoredArtifact:
        data = text.encode("utf-8")
        return self._write(data, suffix="txt")

    def write_bytes(self, data: bytes) -> StoredArtifact:
        if not isinstance(data, (bytes, bytearray)):
            raise TypeError(
                f"write_bytes expected bytes-like, got {type(data).__name__}"
            )
        return self._write(bytes(data), suffix="bin")

    def _write(self, data: bytes, *, suffix: str) -> StoredArtifact:
        digest = hashlib.sha256(data).hexdigest()
        self._ensure_root()
        path = self._root / f"{digest}.{suffix}"
        if not path.exists():
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_bytes(data)
            tmp.replace(path)
        return StoredArtifact(path=path, sha256=digest, bytes=len(data))
