"""Handover.md section parser.

Per CONTRACT.md the handover document must contain six required H2 sections.
This module exposes the required-section list and a helper for detecting
which are missing from a given file.
"""

from __future__ import annotations

import re
from pathlib import Path

REQUIRED_SECTIONS: tuple[str, ...] = (
    "Goal",
    "Status",
    "Next Step",
    "Constraints",
    "Artifacts",
    "Decisions",
)

_H2 = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)


def section_headings(text: str) -> list[str]:
    return [m.group(1).strip() for m in _H2.finditer(text)]


def missing_required_sections(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8")
    present = {h for h in section_headings(text)}
    return [name for name in REQUIRED_SECTIONS if name not in present]
