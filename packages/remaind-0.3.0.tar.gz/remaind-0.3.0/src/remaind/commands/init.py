"""`remaind init` — bootstrap a `.context/` directory.

Copies bundled static files into place, generates fresh dynamic content
(state.json, seed init event in events.jsonl) and validates the generated
content against the bundled schemas before reporting success.
"""

from __future__ import annotations

import json
import shutil
from importlib.resources import files
from pathlib import Path

from .._paths import ContextPaths
from .._schemas import bundled_schema, make_validator
from .._timestamps import utc_now_filename_safe, utc_now_iso
from .._ulid import new_event_id, new_ulid

_STATE_VERSION = "1.0.0"
_EVENT_VERSION = "1.0.0"

# Static files shipped in the wheel under remaind/_templates/.
# Tuples are (relative path inside _templates/, relative path inside .context/).
_STATIC_FILES: tuple[tuple[str, str], ...] = (
    ("README.md", "README.md"),
    ("CONTRACT.md", "CONTRACT.md"),
    ("active/handover.md", "active/handover.md"),
    ("schemas/event.schema.json", "schemas/event.schema.json"),
    ("schemas/state.schema.json", "schemas/state.schema.json"),
    ("schemas/memory.schema.json", "schemas/memory.schema.json"),
    ("schemas/validation.schema.json", "schemas/validation.schema.json"),
    ("schemas/thresholds.yaml", "schemas/thresholds.yaml"),
    ("schemas/redaction.yaml", "schemas/redaction.yaml"),
    ("schemas/tools.yaml", "schemas/tools.yaml"),
)


class InitError(Exception):
    """Raised when init refuses or fails to bootstrap a `.context/`."""


def _copy_bundled_static(paths: ContextPaths) -> None:
    bundle = files("remaind") / "_templates"
    for src_rel, dst_rel in _STATIC_FILES:
        src = bundle
        for part in src_rel.split("/"):
            src = src / part
        dst = paths.root / dst_rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(src.read_bytes())


def _make_initial_state(session_id: str, task_id: str, now: str) -> dict:
    return {
        "schema_version": _STATE_VERSION,
        "session_id": session_id,
        "task_id": task_id,
        "updated_at": now,
        "current_goal": "Initialize Remaind context.",
        "active_task": "Initialize Remaind context.",
        "status": "planning",
        "next_step": (
            "Replace bootstrap placeholders with the real goal and begin work."
        ),
        "completed_work": [],
        "active_constraints": [],
        "open_questions": [],
        "open_blockers": [],
        "decisions": [],
        "files_touched": [],
        "artifacts": [],
        "latest_user_instruction_event_id": None,
        "last_compaction_event_id": None,
        "last_validation_event_id": None,
        "threshold_band": "normal",
        "estimated_context_tokens": 0,
    }


def _make_seed_event(
    event_id: str, session_id: str, task_id: str, now: str
) -> dict:
    return {
        "schema_version": _EVENT_VERSION,
        "id": event_id,
        "timestamp": now,
        "session_id": session_id,
        "task_id": task_id,
        "type": "init",
        "actor": "system",
        "summary": "Initialize Remaind context.",
        "content_type": "text/plain",
        "is_binary": False,
        "content_excerpt_head": None,
        "content_excerpt_tail": None,
        "content_ref": None,
        "content_hash": None,
        "content_bytes": 0,
        "importance": 1,
        "tags": ["init"],
        "redacted": False,
        "source": "remaind init",
        "source_event_ids": [],
        "metadata": {},
    }


def run(base: Path, *, force: bool = False) -> ContextPaths:
    """Bootstrap `.context/` under ``base``. Return paths on success.

    Refuses if ``.context/`` already exists unless ``force`` is true, in which
    case the existing directory is renamed to ``.context.bak.{timestamp}``.
    """
    base = Path(base).resolve()
    paths = ContextPaths.at(base)

    if paths.root.exists():
        if not force:
            raise InitError(
                f"refused: {paths.root} already exists; "
                f"pass --force to back it up and reinitialize"
            )
        backup = base / f".context.bak.{utc_now_filename_safe()}"
        if backup.exists():
            raise InitError(
                f"backup target {backup} already exists; aborting to avoid "
                f"overwriting prior state"
            )
        shutil.move(str(paths.root), str(backup))

    # Skeleton directories
    paths.root.mkdir(parents=True)
    paths.active_dir.mkdir()
    paths.logs_dir.mkdir()
    paths.schemas_dir.mkdir()
    paths.migrations_state_dir.mkdir(parents=True)
    paths.migrations_events_dir.mkdir(parents=True)

    # Static templates
    _copy_bundled_static(paths)

    # Dynamic content
    now = utc_now_iso()
    session_id = f"sess_{new_ulid()}"
    task_id = f"task_{new_ulid()}"
    event_id = new_event_id()

    state = _make_initial_state(session_id, task_id, now)
    event = _make_seed_event(event_id, session_id, task_id, now)

    # Self-check against the bundled (canonical) schemas before writing.
    state_validator = make_validator(bundled_schema("state.schema.json"))
    event_validator = make_validator(bundled_schema("event.schema.json"))
    state_errors = sorted(
        state_validator.iter_errors(state),
        key=lambda e: list(e.absolute_path),
    )
    if state_errors:
        raise InitError(
            "internal: generated state.json fails schema validation: "
            + "; ".join(e.message for e in state_errors)
        )
    event_errors = sorted(
        event_validator.iter_errors(event),
        key=lambda e: list(e.absolute_path),
    )
    if event_errors:
        raise InitError(
            "internal: generated seed event fails schema validation: "
            + "; ".join(e.message for e in event_errors)
        )

    paths.state_json.write_text(
        json.dumps(state, indent=2) + "\n", encoding="utf-8"
    )
    paths.events_jsonl.write_text(
        json.dumps(event) + "\n", encoding="utf-8"
    )

    return paths
