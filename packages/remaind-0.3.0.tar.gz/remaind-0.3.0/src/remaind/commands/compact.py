"""`remaind compact` — run manual compaction, gated by structured validation.

Flow:

1. Select sources from ``.context/``.
2. Run the compactor (default rule-based) to get a :class:`CompactionCandidate`.
3. Run the mechanical validator over (sources, candidate).
4. If verdict is ``reject``: append a validation event recording the
   failure, advance ``state.last_validation_event_id``, and raise
   :class:`CompactionRejected`. The handover and ``last_compaction_event_id``
   are left untouched.
5. If verdict is ``accept``: write the candidate handover, append the
   compaction event, append the validation event, and advance both
   ``last_compaction_event_id`` and ``last_validation_event_id`` in state.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .._compactor import (
    CompactionCandidate,
    Compactor,
    default_compact,
    select_sources,
)
from .._events import EventInput, EventWriter
from .._handover_writer import write_handover
from .._local_compactor import detect_local_compactor
from .._paths import ContextPaths
from .._state_writer import update_state
from .._validator import validate_candidate


@dataclass(frozen=True)
class CompactionResult:
    accepted: bool
    compaction_event_id: str | None
    validation_event_id: str
    preserved_count: int
    window_size: int
    candidate: CompactionCandidate
    validation: dict[str, Any]
    # Handover size before/after, in characters. The structured validator
    # guarantees faithfulness, not compression — these let a caller see
    # whether the handover actually got smaller. (default_compact GROWS it:
    # it appends a notes section. A local model should shrink it.)
    handover_chars_before: int = 0
    handover_chars_after: int = 0
    # Which compactor produced the candidate — so a caller can tell whether
    # the local model, the rule-based fallback, or a custom compactor ran.
    compactor_label: str = "rule-based fallback"


class CompactionError(Exception):
    """Raised when compaction cannot proceed."""


class CompactionRejected(CompactionError):
    """Raised when the structured validator rejects the candidate.

    Carries the validation dict and the id of the validation event that was
    appended to record the rejection.
    """

    def __init__(self, validation: dict[str, Any], validation_event_id: str) -> None:
        super().__init__(
            f"compaction rejected by validator: "
            f"missing={len(validation['missing_items'])}, "
            f"unsupported={len(validation['unsupported_claims'])}"
        )
        self.validation = validation
        self.validation_event_id = validation_event_id


def _validation_summary(validation: dict[str, Any]) -> str:
    if validation["verdict"] == "accept":
        return "compaction validation: accept"
    return (
        f"compaction validation: reject "
        f"({len(validation['missing_items'])} missing, "
        f"{len(validation['unsupported_claims'])} unsupported)"
    )


def run(base: Path, *, compactor: Compactor | None = None) -> CompactionResult:
    base = Path(base)
    if not ContextPaths.at(base).state_json.is_file():
        raise CompactionError(
            f"no .context/ found at {base} — run `remaind init` first"
        )
    sources = select_sources(base)
    # No compactor passed: use the local model if one is running, otherwise
    # fall back to the rule-based reference compactor. Detection is invisible
    # and never fails — a missing runtime just means default_compact.
    if compactor is None:
        detected = detect_local_compactor(base)
        if detected is not None:
            compactor = detected
            compactor_label = getattr(detected, "label", "local model")
        else:
            compactor = default_compact
            compactor_label = "rule-based fallback"
    else:
        compactor_label = "custom compactor"
    candidate = compactor(sources)

    validation = validate_candidate(sources, candidate)

    session_id = sources.current_state["session_id"]
    task_id = sources.current_state["task_id"]
    writer = EventWriter.open(base)
    validation_payload = json.dumps(validation, indent=2, sort_keys=True)

    if validation["verdict"] == "reject":
        v_event = writer.append(
            EventInput(
                type="validation",
                actor="remaind compact",
                summary=_validation_summary(validation),
                session_id=session_id,
                task_id=task_id,
                content=validation_payload,
                content_type="application/json",
                importance=2,
                tags=["validation", "compaction-rejected"],
                source="remaind compact",
                source_event_ids=list(candidate.preserved_event_ids),
                metadata={
                    "verdict": "reject",
                    "missing_items_count": len(validation["missing_items"]),
                    "unsupported_claims_count": len(
                        validation["unsupported_claims"]
                    ),
                    "previous_compaction_event_id": sources.last_compaction_event_id,
                },
            )
        )
        update_state(
            base, lambda s: {**s, "last_validation_event_id": v_event["id"]}
        )
        raise CompactionRejected(validation, v_event["id"])

    # Accept path -----------------------------------------------------------
    write_handover(base, candidate.new_handover)

    c_event = writer.append(
        EventInput(
            type="compaction",
            actor="remaind compact",
            summary=candidate.summary,
            session_id=session_id,
            task_id=task_id,
            content=candidate.rationale,
            content_type="text/plain",
            importance=2,
            tags=["compaction"],
            source="remaind compact",
            source_event_ids=list(candidate.preserved_event_ids),
            metadata={
                "preserved_count": len(candidate.preserved_event_ids),
                "window_size": len(sources.window_events),
                "previous_compaction_event_id": sources.last_compaction_event_id,
            },
        )
    )

    v_event = writer.append(
        EventInput(
            type="validation",
            actor="remaind compact",
            summary=_validation_summary(validation),
            session_id=session_id,
            task_id=task_id,
            content=validation_payload,
            content_type="application/json",
            importance=2,
            tags=["validation"],
            source="remaind compact",
            source_event_ids=[c_event["id"]],
            metadata={
                "verdict": "accept",
                "compaction_event_id": c_event["id"],
            },
        )
    )

    new_state = dict(candidate.new_state)
    new_state["last_compaction_event_id"] = c_event["id"]
    new_state["last_validation_event_id"] = v_event["id"]
    update_state(base, lambda _s: new_state)

    return CompactionResult(
        accepted=True,
        compaction_event_id=c_event["id"],
        validation_event_id=v_event["id"],
        preserved_count=len(candidate.preserved_event_ids),
        window_size=len(sources.window_events),
        candidate=candidate,
        validation=validation,
        handover_chars_before=len(sources.current_handover),
        handover_chars_after=len(candidate.new_handover),
        compactor_label=compactor_label,
    )
