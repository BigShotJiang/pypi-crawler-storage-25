"""`remaind validate` — verify that a `.context/` directory is well-formed.

Implements the v1 validate checklist from the engineering handoff §22:
structure exists, schemas parse, state.json validates, handover.md has
required sections, events.jsonl is readable AND each event validates,
YAML configs parse. SQLite/FTS, history, and migration-path checks land in
later phases.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from .._configs import load_yaml_mapping
from .._handover import missing_required_sections
from .._jsonl import iter_jsonl
from .._paths import ContextPaths
from .._schemas import load_schema, make_validator


@dataclass
class ValidationReport:
    passed: list[str] = field(default_factory=list)
    failed: list[tuple[str, str]] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.failed

    def add_pass(self, label: str) -> None:
        self.passed.append(label)

    def add_fail(self, label: str, reason: str) -> None:
        self.failed.append((label, reason))


def run(base: Path) -> ValidationReport:
    base = Path(base).resolve()
    paths = ContextPaths.at(base)
    report = ValidationReport()

    if not paths.root.is_dir():
        report.add_fail(".context/", f"missing: {paths.root}")
        return report
    report.add_pass(".context/")

    required = {
        "active/state.json": paths.state_json,
        "active/handover.md": paths.handover_md,
        "logs/events.jsonl": paths.events_jsonl,
        "schemas/event.schema.json": paths.event_schema,
        "schemas/state.schema.json": paths.state_schema,
        "schemas/memory.schema.json": paths.memory_schema,
        "schemas/validation.schema.json": paths.validation_schema,
        "schemas/thresholds.yaml": paths.thresholds_yaml,
        "schemas/redaction.yaml": paths.redaction_yaml,
        "schemas/tools.yaml": paths.tools_yaml,
    }
    missing = [rel for rel, p in required.items() if not p.exists()]
    if missing:
        report.add_fail("required files", "missing " + ", ".join(missing))
        return report
    report.add_pass("required files")

    # Parse + compile schemas
    try:
        event_schema = load_schema(paths.event_schema)
        state_schema = load_schema(paths.state_schema)
        load_schema(paths.memory_schema)
        load_schema(paths.validation_schema)
    except json.JSONDecodeError as e:
        report.add_fail("schemas parse", str(e))
        return report

    try:
        event_validator = make_validator(event_schema)
        state_validator = make_validator(state_schema)
    except Exception as e:
        report.add_fail("schemas valid", str(e))
        return report
    report.add_pass("schemas parse")

    # YAML configs
    yaml_errors: list[str] = []
    for label, p in (
        ("thresholds.yaml", paths.thresholds_yaml),
        ("redaction.yaml", paths.redaction_yaml),
        ("tools.yaml", paths.tools_yaml),
    ):
        try:
            load_yaml_mapping(p)
        except Exception as e:
            yaml_errors.append(f"{label}: {e}")
    if yaml_errors:
        report.add_fail("yaml configs", "; ".join(yaml_errors))
    else:
        report.add_pass("yaml configs")

    # state.json
    try:
        state = json.loads(paths.state_json.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        report.add_fail("state.json parse", str(e))
    else:
        errs = sorted(
            state_validator.iter_errors(state),
            key=lambda e: list(e.absolute_path),
        )
        if errs:
            report.add_fail(
                "state.json schema", "; ".join(e.message for e in errs)
            )
        else:
            report.add_pass("state.json schema")

    # handover.md required sections
    missing_sections = missing_required_sections(paths.handover_md)
    if missing_sections:
        report.add_fail(
            "handover.md sections", "missing " + ", ".join(missing_sections)
        )
    else:
        report.add_pass("handover.md sections")

    # events.jsonl line-by-line
    event_errors: list[str] = []
    for lineno, obj, err in iter_jsonl(paths.events_jsonl):
        if err is not None:
            event_errors.append(err)
            continue
        assert obj is not None
        errs = sorted(
            event_validator.iter_errors(obj),
            key=lambda e: list(e.absolute_path),
        )
        if errs:
            event_errors.append(
                f"line {lineno}: " + "; ".join(e.message for e in errs)
            )
    if event_errors:
        report.add_fail("events.jsonl", "; ".join(event_errors[:10]))
    else:
        report.add_pass("events.jsonl")

    # SQLite (only when the DB has been bootstrapped)
    if paths.db_sqlite.exists():
        _validate_sqlite(paths.db_sqlite, report)

    return report


def _validate_sqlite(db_path: Path, report: ValidationReport) -> None:
    import sqlite3

    try:
        conn = sqlite3.connect(str(db_path))
    except sqlite3.Error as exc:
        report.add_fail("sqlite open", str(exc))
        return
    try:
        existing = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type IN ('table','virtual') "
                "  AND name IN ('memories','memories_fts','events_index')"
            )
        }
        missing = {"memories", "memories_fts", "events_index"} - existing
        if missing:
            report.add_fail(
                "sqlite tables", "missing " + ", ".join(sorted(missing))
            )
            return
        report.add_pass("sqlite tables")

        memories_count = conn.execute(
            "SELECT COUNT(*) FROM memories"
        ).fetchone()[0]
        fts_count = conn.execute(
            "SELECT COUNT(*) FROM memories_fts"
        ).fetchone()[0]
        if memories_count != fts_count:
            report.add_fail(
                "sqlite FTS consistency",
                f"memories={memories_count} vs memories_fts={fts_count}",
            )
        else:
            report.add_pass("sqlite FTS consistency")
    finally:
        conn.close()
