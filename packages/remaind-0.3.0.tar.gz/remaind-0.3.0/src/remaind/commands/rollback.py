"""`remaind rollback --to <timestamp>` — restore derived files from history.

For each of (state, handover, resume_packet) we find the latest snapshot at
or before the target timestamp, validate it, and atomic-write it back over
the active file. Pre-rollback active files are themselves snapshotted, so
rollback is reversible.

``events.jsonl`` is never rewritten — but a ``rollback`` event is appended
recording what was restored and what was skipped.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .._atomic import atomic_write_text
from .._events import EventInput, EventWriter
from .._handover import REQUIRED_SECTIONS, section_headings
from .._paths import ContextPaths
from .._rollback import (
    RollbackError,
    find_snapshot_active_at,
    normalize_target,
)
from .._schemas import load_schema, make_validator


@dataclass(frozen=True)
class RollbackResult:
    rollback_event_id: str
    target: str
    normalized_target: str
    restored: dict[str, Path]
    skipped: dict[str, str]


def _validate_state_snapshot(paths: ContextPaths, content: str) -> None:
    try:
        candidate = json.loads(content)
    except json.JSONDecodeError as exc:
        raise RollbackError(f"snapshot is not valid JSON: {exc}") from exc
    validator = make_validator(load_schema(paths.state_schema))
    errors = list(validator.iter_errors(candidate))
    if errors:
        raise RollbackError(
            "snapshot fails state schema: "
            + "; ".join(e.message for e in errors)
        )


def _validate_handover_snapshot(_paths: ContextPaths, content: str) -> None:
    present = set(section_headings(content))
    missing = [s for s in REQUIRED_SECTIONS if s not in present]
    if missing:
        raise RollbackError(
            "snapshot missing required handover sections: " + ", ".join(missing)
        )


def _validate_resume_packet_snapshot(_paths: ContextPaths, content: str) -> None:
    if not content.strip():
        raise RollbackError("resume_packet snapshot is empty")


def _kinds(paths: ContextPaths) -> list[tuple[str, Path, Path, Any]]:
    return [
        ("state", paths.history_dir / "state", paths.state_json, _validate_state_snapshot),
        ("handover", paths.history_dir / "handover", paths.handover_md, _validate_handover_snapshot),
        (
            "resume_packet",
            paths.history_dir / "resume_packet",
            paths.resume_packet,
            _validate_resume_packet_snapshot,
        ),
    ]


def run(base: Path, *, target: str) -> RollbackResult:
    base = Path(base)
    paths = ContextPaths.at(base)
    normalized = normalize_target(target)

    restored: dict[str, Path] = {}
    skipped: dict[str, str] = {}

    for kind, history_dir, active_path, validator in _kinds(paths):
        snapshot = find_snapshot_active_at(history_dir, normalized)
        if snapshot is None:
            skipped[kind] = (
                f"no snapshot captures the state active at {normalized}"
            )
            continue
        try:
            content = snapshot.read_text(encoding="utf-8")
            validator(paths, content)
        except RollbackError as exc:
            skipped[kind] = f"snapshot {snapshot.name} invalid: {exc}"
            continue
        # Atomic write that also snapshots the CURRENT active file before
        # replacement — rollback is reversible.
        atomic_write_text(active_path, content, history_dir=history_dir)
        restored[kind] = snapshot

    # Append the rollback event last. events.jsonl is never rewritten — this
    # is an append.
    state = json.loads(paths.state_json.read_text(encoding="utf-8"))
    writer = EventWriter.open(base)
    payload = {
        "target": target,
        "normalized_target": normalized,
        "restored": {k: v.name for k, v in restored.items()},
        "skipped": skipped,
    }
    event = writer.append(
        EventInput(
            type="rollback",
            actor="remaind rollback",
            summary=(
                f"Rolled back to {normalized}: "
                f"{len(restored)} restored, {len(skipped)} skipped"
            ),
            session_id=state["session_id"],
            task_id=state["task_id"],
            content=json.dumps(payload, indent=2, sort_keys=True),
            content_type="application/json",
            importance=3,
            tags=["rollback"],
            source="remaind rollback",
            source_event_ids=[],
            metadata=payload,
        )
    )

    return RollbackResult(
        rollback_event_id=event["id"],
        target=target,
        normalized_target=normalized,
        restored=restored,
        skipped=skipped,
    )
