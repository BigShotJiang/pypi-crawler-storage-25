"""Redaction engine.

Patterns are loaded from ``schemas/redaction.yaml``. Each match is replaced
with ``[REDACTED:{type}:sha256_{hex_prefix}]``. The hash is deterministic:
the same secret always produces the same redacted token, which preserves
debuggability without leaking the secret.

Redaction MUST happen before raw logging — callers should redact strings
prior to writing them into ``events.jsonl`` content excerpts.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from pathlib import Path

from ._configs import load_yaml_mapping


@dataclass(frozen=True)
class RedactionPattern:
    type: str
    regex: re.Pattern[str]


class Redactor:
    def __init__(
        self,
        patterns: list[RedactionPattern],
        *,
        hash_prefix_length: int = 12,
    ) -> None:
        if hash_prefix_length < 1 or hash_prefix_length > 64:
            raise ValueError(
                f"hash_prefix_length must be 1..64, got {hash_prefix_length}"
            )
        self._patterns = tuple(patterns)
        self._hash_prefix_length = hash_prefix_length

    @classmethod
    def from_config_path(cls, path: Path) -> Redactor:
        cfg = load_yaml_mapping(path)
        raw = cfg.get("patterns", [])
        if not isinstance(raw, list):
            raise ValueError(f"{path}: 'patterns' must be a list")
        compiled: list[RedactionPattern] = []
        for i, entry in enumerate(raw):
            if not isinstance(entry, dict):
                raise ValueError(f"{path}: patterns[{i}] must be a mapping")
            try:
                t = entry["type"]
                p = entry["pattern"]
            except KeyError as missing:
                raise ValueError(
                    f"{path}: patterns[{i}] missing required key {missing}"
                ) from missing
            compiled.append(RedactionPattern(type=str(t), regex=re.compile(str(p))))
        hpl = int(cfg.get("hash_prefix_length", 12))
        return cls(compiled, hash_prefix_length=hpl)

    @property
    def hash_prefix_length(self) -> int:
        return self._hash_prefix_length

    def _token_for(self, kind: str, secret: str) -> str:
        digest = hashlib.sha256(secret.encode("utf-8")).hexdigest()
        return f"[REDACTED:{kind}:sha256_{digest[: self._hash_prefix_length]}]"

    def redact(self, text: str) -> tuple[str, bool]:
        """Return ``(redacted_text, was_modified)``."""
        modified = False
        for pat in self._patterns:
            kind = pat.type

            def _sub(match: re.Match[str], _kind: str = kind) -> str:
                nonlocal modified
                modified = True
                return self._token_for(_kind, match.group(0))

            text = pat.regex.sub(_sub, text)
        return text, modified
