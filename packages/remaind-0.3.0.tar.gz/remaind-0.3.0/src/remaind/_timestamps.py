"""ISO 8601 UTC timestamp helpers."""

from __future__ import annotations

import datetime as _dt


def utc_now_iso() -> str:
    """Return the current UTC time as RFC 3339 with a trailing Z."""
    return _dt.datetime.now(_dt.UTC).isoformat().replace("+00:00", "Z")


def utc_now_filename_safe() -> str:
    """Return a UTC timestamp safe for use in filenames: `20260513T224200Z`."""
    return _dt.datetime.now(_dt.UTC).strftime("%Y%m%dT%H%M%SZ")


def utc_now_filename_safe_us() -> str:
    """Microsecond-precision filename-safe UTC timestamp: `20260513T224200_123456Z`.

    Use for history snapshots where two writes may occur within the same
    second — second-resolution collisions would otherwise lose a snapshot.
    """
    return _dt.datetime.now(_dt.UTC).strftime("%Y%m%dT%H%M%S_%fZ")
