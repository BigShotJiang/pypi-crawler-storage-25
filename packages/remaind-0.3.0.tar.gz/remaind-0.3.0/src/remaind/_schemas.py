"""Schema loading and validator construction.

`.context/schemas/` is canonical. Validators are built from the on-disk
schemas so that downstream tools reading `.context/` see exactly the same
contract Remaind enforces. The bundled copies in
``remaind._templates/schemas`` are init defaults only.
"""

from __future__ import annotations

import json
from importlib.resources import files
from pathlib import Path

from jsonschema import Draft202012Validator

SCHEMA_FILES = (
    "event.schema.json",
    "state.schema.json",
    "memory.schema.json",
    "validation.schema.json",
)


def bundled_schema(name: str) -> dict:
    """Return the bundled (init-default) copy of a schema."""
    if name not in SCHEMA_FILES:
        raise KeyError(f"unknown schema: {name!r}")
    res = files("remaind") / "_templates" / "schemas" / name
    return json.loads(res.read_text(encoding="utf-8"))


def load_schema(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def make_validator(schema: dict) -> Draft202012Validator:
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema)
