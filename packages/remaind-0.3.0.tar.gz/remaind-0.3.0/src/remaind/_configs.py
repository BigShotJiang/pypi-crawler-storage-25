"""YAML config loaders for thresholds / redaction / tools."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def load_yaml_mapping(path: Path) -> dict[str, Any]:
    """Parse ``path`` as YAML, requiring the top level to be a mapping."""
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ValueError(
            f"{path}: top-level value must be a mapping, got {type(data).__name__}"
        )
    return data
