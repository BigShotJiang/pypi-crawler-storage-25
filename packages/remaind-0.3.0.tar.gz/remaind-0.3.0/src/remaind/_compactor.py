"""Compaction pipeline primitives.

This phase delivers the **pipeline** for compaction: source event selection,
a candidate-generation interface, and a deterministic reference compactor.
The structured-validation gate that decides whether to accept a candidate
lands in the next phase.

The reference compactor is rule-based and intentionally cheap. It does the
minimum compaction work: preserves the existing state, rewrites the
``## Compaction Notes`` section of the handover with the recent
high-importance events, and reports which event IDs it preserved. Real
LLM-driven compaction plugs in via the :class:`Compactor` Protocol later.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

from ._jsonl import iter_jsonl
from ._paths import ContextPaths


@dataclass(frozen=True)
class CompactionSources:
    """The raw material a compactor needs to produce candidate state/handover."""

    window_events: list[dict] = field(default_factory=list)
    importance_high: list[dict] = field(default_factory=list)
    importance_critical: list[dict] = field(default_factory=list)
    current_state: dict = field(default_factory=dict)
    current_handover: str = ""
    last_compaction_event_id: str | None = None


@dataclass(frozen=True)
class CompactionCandidate:
    """Result of running a compactor.

    The candidate is just a proposal. A separate validation step (Phase 10)
    decides whether to accept it.
    """

    new_state: dict
    new_handover: str
    summary: str
    preserved_event_ids: list[str]
    rationale: str


class Compactor(Protocol):
    """Pluggable compactor surface for future LLM-driven plug-ins."""

    def __call__(self, sources: CompactionSources) -> CompactionCandidate: ...


def select_sources(base: Path) -> CompactionSources:
    """Read state + handover + post-anchor events from ``base/.context``."""
    paths = ContextPaths.at(Path(base))
    state = json.loads(paths.state_json.read_text(encoding="utf-8"))
    handover = paths.handover_md.read_text(encoding="utf-8")
    last_compaction = state.get("last_compaction_event_id")
    last_validation = state.get("last_validation_event_id")
    # A completed compaction cycle writes a compaction event followed by a
    # validation event; both must be excluded from the next window. We use
    # whichever pointer is later as the effective anchor (validation, when
    # both are set, since it's written second).
    anchor: str | None = max(
        (x for x in (last_compaction, last_validation) if x is not None),
        default=None,
    )

    window: list[dict] = []
    for _lineno, obj, err in iter_jsonl(paths.events_jsonl):
        if err is not None or obj is None:
            continue
        # ULIDs sort lexicographically by time; same length and prefix means
        # a plain string compare is correct.
        if anchor is not None and obj.get("id", "") <= anchor:
            continue
        window.append(obj)

    high = [e for e in window if int(e.get("importance", 0)) >= 2]
    critical = [e for e in window if int(e.get("importance", 0)) >= 3]
    return CompactionSources(
        window_events=window,
        importance_high=high,
        importance_critical=critical,
        current_state=state,
        current_handover=handover,
        last_compaction_event_id=last_compaction,
    )


_COMPACTION_NOTES_HEADING = "Compaction Notes"


def _render_compaction_notes(high: Iterable[dict]) -> str:
    high = list(high)
    if not high:
        return "- No high-importance events to preserve.\n"
    lines = [f"- Preserved {len(high)} high-importance event(s):"]
    for e in high:
        critical = int(e.get("importance", 0)) >= 3
        marker = " [critical]" if critical else ""
        lines.append(
            f"  - `{e['id']}` ({e['type']}, importance={e['importance']})"
            f"{marker}: {e.get('summary', '').strip()}"
        )
    return "\n".join(lines) + "\n"


def _replace_or_append_h2_section(text: str, heading: str, body: str) -> str:
    """Replace an existing H2 ``heading`` block, or append one at the end."""
    pattern = re.compile(
        rf"^##\s+{re.escape(heading)}\s*$.*?(?=^##\s+|\Z)",
        re.MULTILINE | re.DOTALL,
    )
    new_section = f"## {heading}\n\n{body.rstrip()}\n\n"
    if pattern.search(text):
        return pattern.sub(new_section, text)
    return text.rstrip() + "\n\n" + new_section


def default_compact(sources: CompactionSources) -> CompactionCandidate:
    """Deterministic, rule-based reference compactor.

    Keeps the active state intact and rewrites the handover's
    ``## Compaction Notes`` section so the highest-importance events from
    the window are explicitly summarized in the handover document.
    """
    new_state = dict(sources.current_state)
    notes_body = _render_compaction_notes(sources.importance_high)
    new_handover = _replace_or_append_h2_section(
        sources.current_handover, _COMPACTION_NOTES_HEADING, notes_body
    )

    preserved_ids = [e["id"] for e in sources.importance_high if "id" in e]
    summary = (
        f"Preserved {len(preserved_ids)} high-importance event(s) "
        f"from {len(sources.window_events)} window event(s)."
    )
    rationale = (
        "default rule-based compactor: state preserved verbatim; handover "
        "'## Compaction Notes' section rewritten to reflect the current "
        "high-importance window."
    )
    return CompactionCandidate(
        new_state=new_state,
        new_handover=new_handover,
        summary=summary,
        preserved_event_ids=preserved_ids,
        rationale=rationale,
    )
