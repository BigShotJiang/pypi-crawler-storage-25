"""Atomic file writer with optional history snapshots.

Implements the contract from `CONTRACT.md` §18:

1. If the target exists and ``history_dir`` is supplied, copy the current
   contents to ``history_dir/<microsecond-timestamp><ext>`` and fsync.
2. Write the new contents to ``<target>.tmp`` + flush + fsync.
3. Rename ``<target>.tmp`` over ``<target>``.
4. fsync the parent directory where supported.

Failures clean up the temp file before re-raising. The original target is
never partially overwritten — either the new content is fully in place or
the prior version is still on disk.
"""

from __future__ import annotations

import os
from pathlib import Path

from ._timestamps import utc_now_filename_safe_us


def _fsync_dir(dirpath: Path) -> None:
    """fsync ``dirpath`` if the platform supports directory fsync."""
    try:
        fd = os.open(str(dirpath), os.O_RDONLY)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        # Best-effort on platforms without directory fsync (e.g. Windows).
        pass
    finally:
        os.close(fd)


def atomic_write_text(
    target: Path,
    content: str,
    *,
    history_dir: Path | None = None,
    encoding: str = "utf-8",
) -> Path | None:
    """Atomically write ``content`` to ``target``.

    When ``target`` already exists and ``history_dir`` is given, the current
    contents are copied to a timestamped file inside ``history_dir`` before
    the new write proceeds. Returns the history path if one was created,
    else ``None``.
    """
    if not isinstance(content, str):
        raise TypeError(
            f"atomic_write_text requires str content, got {type(content).__name__}"
        )

    target = Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)

    history_path: Path | None = None
    if history_dir is not None and target.exists():
        history_dir.mkdir(parents=True, exist_ok=True)
        history_path = history_dir / f"{utc_now_filename_safe_us()}{target.suffix}"
        # Read + write to copy the prior content so we capture the exact
        # bytes that were on disk just before this update.
        prior = target.read_bytes()
        with open(history_path, "wb") as f:
            f.write(prior)
            f.flush()
            os.fsync(f.fileno())
        _fsync_dir(history_dir)

    tmp = target.with_name(target.name + ".tmp")
    try:
        data = content.encode(encoding)
        with open(tmp, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, target)
        _fsync_dir(target.parent)
    except Exception:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass
        raise

    return history_path
