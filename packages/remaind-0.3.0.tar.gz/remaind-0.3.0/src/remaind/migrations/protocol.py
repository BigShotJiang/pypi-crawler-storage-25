"""Structural typing for migration and adapter steps.

Each step carries explicit ``from_version`` / ``to_version`` / ``name``
attributes so the runner can produce informative errors and (in later phases)
verify that a chain forms a contiguous path between schema versions.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class StateMigration(Protocol):
    """A single state schema migration step.

    Implementations are pure functions: given a state dict at
    ``from_version``, return a new dict at ``to_version``. The runner copies
    its input before invoking the chain, but implementations should still
    avoid mutating the dict they receive.
    """

    from_version: str
    to_version: str
    name: str

    def __call__(self, state: dict) -> dict: ...


@runtime_checkable
class EventAdapter(Protocol):
    """A read-time event adapter step.

    Implementations are pure functions transforming a single event dict from
    ``from_version`` to ``to_version``. Adapters run on read; they must not
    cause the raw event log to be rewritten.
    """

    from_version: str
    to_version: str
    name: str

    def __call__(self, event: dict) -> dict: ...
