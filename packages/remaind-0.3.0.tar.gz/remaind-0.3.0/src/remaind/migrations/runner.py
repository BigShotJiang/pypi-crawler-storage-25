"""Write-time state migration runner.

Applies an ordered chain of :class:`StateMigration` steps to a state dict.
On any failure the original input is preserved on the raised
:class:`MigrationError` so the caller can leave ``state.json`` untouched.
"""

from __future__ import annotations

from collections.abc import Iterable
from copy import deepcopy

from .protocol import StateMigration


class MigrationError(Exception):
    """Structured failure raised when a state migration step fails."""

    def __init__(
        self,
        message: str,
        *,
        step_name: str,
        from_version: str,
        to_version: str,
        original_state: dict,
    ) -> None:
        super().__init__(message)
        self.step_name = step_name
        self.from_version = from_version
        self.to_version = to_version
        self.original_state = original_state


def run_state_migrations(
    state: dict, chain: Iterable[StateMigration]
) -> dict:
    """Apply ``chain`` to ``state`` in order, returning a new dict.

    A no-op chain (empty iterable) returns a deep copy of the input.
    The input is never mutated. On step failure, raises
    :class:`MigrationError` with the unchanged original state attached.
    """
    steps = list(chain)
    if not steps:
        return deepcopy(state)

    current = deepcopy(state)
    for step in steps:
        try:
            current = step(current)
        except Exception as exc:
            raise MigrationError(
                f"state migration {getattr(step, 'name', repr(step))!r} failed: {exc}",
                step_name=getattr(step, "name", repr(step)),
                from_version=getattr(step, "from_version", "?"),
                to_version=getattr(step, "to_version", "?"),
                original_state=deepcopy(state),
            ) from exc
    return current
