"""Schema migration interfaces.

Two distinct chains live here:

* **State migrations** (`runner`) — write-time, applied eagerly on bootstrap
  to bring ``active/state.json`` to the current schema version. Pure functions
  in v1.
* **Event adapters** (`adapter`) — read-time only, applied lazily per event
  when ``events.jsonl`` is consumed. Adapters must never rewrite the raw log.
"""

from .adapter import EventAdapterError, run_event_adapters
from .protocol import EventAdapter, StateMigration
from .runner import MigrationError, run_state_migrations

__all__ = [
    "EventAdapter",
    "EventAdapterError",
    "MigrationError",
    "StateMigration",
    "run_event_adapters",
    "run_state_migrations",
]
