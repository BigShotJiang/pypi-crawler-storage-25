"""Token estimators.

V1 ships a single ``approx_chars_div_4`` estimator: ``ceil(len(text) / 4)``.
It systematically over-estimates relative to real tokenizers, which is the
right bias for "should I compact?" decisions — false positives are cheap,
false negatives are expensive (model OOM mid-task).

The contract leaves room for a future ``model_profile_or_approx`` compaction
estimator; that method is not implemented yet and raises ``ValueError``.
"""

from __future__ import annotations

import json
import math
from typing import Any

APPROX_CHARS_DIV_4 = "approx_chars_div_4"
KNOWN_METHODS: tuple[str, ...] = (APPROX_CHARS_DIV_4,)


def estimate_tokens_chars_div_4(text: str) -> int:
    """``ceil(len(text) / 4)``. Returns 0 for empty input."""
    if not text:
        return 0
    return math.ceil(len(text) / 4)


def serialize_for_estimate(obj: Any) -> str:
    """Canonical string form used when estimating non-string inputs."""
    if isinstance(obj, str):
        return obj
    return json.dumps(obj, ensure_ascii=False, sort_keys=True)


def estimate_tokens(content: Any, *, method: str = APPROX_CHARS_DIV_4) -> int:
    """Estimate the token count of ``content`` using ``method``."""
    if method not in KNOWN_METHODS:
        raise ValueError(
            f"unknown token estimator method: {method!r}. "
            f"Known methods: {', '.join(KNOWN_METHODS)}"
        )
    return estimate_tokens_chars_div_4(serialize_for_estimate(content))
