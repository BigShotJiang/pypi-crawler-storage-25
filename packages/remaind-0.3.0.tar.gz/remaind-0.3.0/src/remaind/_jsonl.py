"""Line-by-line JSONL streaming with parse-error reporting."""

from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path


def iter_jsonl(path: Path) -> Iterator[tuple[int, dict | None, str | None]]:
    """Yield ``(line_number, parsed_object, error_message)`` for each line.

    Blank lines are skipped silently. On parse failure or non-object payload,
    ``parsed_object`` is ``None`` and ``error_message`` describes the problem.
    """
    with path.open("r", encoding="utf-8") as f:
        for lineno, raw in enumerate(f, start=1):
            stripped = raw.strip()
            if not stripped:
                continue
            try:
                obj = json.loads(stripped)
            except json.JSONDecodeError as exc:
                yield lineno, None, f"line {lineno}: invalid JSON: {exc.msg}"
                continue
            if not isinstance(obj, dict):
                yield lineno, None, (
                    f"line {lineno}: expected JSON object, "
                    f"got {type(obj).__name__}"
                )
                continue
            yield lineno, obj, None
