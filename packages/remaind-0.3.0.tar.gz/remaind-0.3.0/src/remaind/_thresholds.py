"""Threshold band computation.

The contract derives token bands multiplicatively from a single
``compaction_required_tokens`` value:

* ``compaction_required`` = sum of ``compaction_budget.*``
* ``warning``   = required × ``warning_multiplier``    (default 1.5)
* ``hard``      = required × ``hard_multiplier``       (default 1.75)
* ``emergency`` = required × ``emergency_multiplier``  (default 2.0)

With bundled defaults this yields 40000 / 60000 / 70000 / 80000.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ._configs import load_yaml_mapping

_BUDGET_KEYS = (
    "instructions",
    "source_events_window",
    "existing_state",
    "previous_handover",
    "output_budget",
    "validation_budget",
    "safety_margin",
)

BAND_NAMES = ("normal", "warning", "hard", "emergency")


@dataclass(frozen=True)
class Bands:
    required: int
    warning: int
    hard: int
    emergency: int


def compute_bands(default_profile: dict) -> Bands:
    """Compute bands from a thresholds.yaml ``default:`` mapping."""
    budget = default_profile.get("compaction_budget", {}) or {}
    required = sum(int(budget.get(k, 0)) for k in _BUDGET_KEYS)
    multipliers = default_profile.get("thresholds", {}) or {}
    warning = int(required * float(multipliers.get("warning_multiplier", 1.5)))
    hard = int(required * float(multipliers.get("hard_multiplier", 1.75)))
    emergency = int(required * float(multipliers.get("emergency_multiplier", 2.0)))
    return Bands(required=required, warning=warning, hard=hard, emergency=emergency)


def band_for(tokens: int, bands: Bands) -> str:
    """Classify ``tokens`` into one of the four band names."""
    if tokens >= bands.emergency:
        return "emergency"
    if tokens >= bands.hard:
        return "hard"
    if tokens >= bands.warning:
        return "warning"
    return "normal"


def load_default_profile(path: Path) -> dict:
    """Read ``thresholds.yaml`` and return its ``default:`` sub-mapping."""
    data = load_yaml_mapping(path)
    profile = data.get("default", {})
    if profile is None:
        return {}
    if not isinstance(profile, dict):
        raise ValueError(
            f"{path}: 'default' must be a mapping, got {type(profile).__name__}"
        )
    return profile
