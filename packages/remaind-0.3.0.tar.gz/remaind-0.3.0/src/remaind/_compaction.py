"""Compaction-needed status surface.

Combines ``estimated_context_tokens`` with the active threshold bands to
answer two questions every caller cares about:

* should compaction happen at all? (``compaction_needed``)
* is it urgent — i.e. before the next substantial task step?
  (``compaction_urgent``)

The four band recommendations come straight from CONTRACT.md §14.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from ._paths import ContextPaths
from ._thresholds import Bands, band_for, compute_bands, load_default_profile

_RECOMMENDATIONS: dict[str, str] = {
    "normal": "continue — no compaction needed",
    "warning": "mark compaction pending",
    "hard": "compact before the next substantial task step",
    "emergency": "compact immediately before adding context-heavy work",
}


@dataclass(frozen=True)
class CompactionStatus:
    estimated_tokens: int
    band: str
    bands: Bands
    compaction_needed: bool
    compaction_urgent: bool
    recommendation: str = field(default="")


def compute_compaction_status(state: dict, bands: Bands) -> CompactionStatus:
    """Pure: classify ``state`` against precomputed ``bands``."""
    tokens = int(state.get("estimated_context_tokens", 0))
    band = band_for(tokens, bands)
    return CompactionStatus(
        estimated_tokens=tokens,
        band=band,
        bands=bands,
        compaction_needed=band != "normal",
        compaction_urgent=band in ("hard", "emergency"),
        recommendation=_RECOMMENDATIONS[band],
    )


def compaction_status(base: Path) -> CompactionStatus:
    """Read state + thresholds from ``base/.context`` and classify."""
    paths = ContextPaths.at(Path(base))
    state = json.loads(paths.state_json.read_text(encoding="utf-8"))
    bands = compute_bands(load_default_profile(paths.thresholds_yaml))
    return compute_compaction_status(state, bands)
