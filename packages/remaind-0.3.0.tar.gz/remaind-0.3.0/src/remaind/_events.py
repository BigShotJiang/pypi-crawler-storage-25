"""Append-only event writer.

Builds a fully-formed event from caller-supplied fields, applies redaction
and large-output routing, validates the result against the on-disk event
schema, and appends a single JSON line to ``logs/events.jsonl``. The writer
is single-process / single-writer — v1 does not coordinate concurrent
writers.
"""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from ._artifacts import ArtifactStore
from ._configs import load_yaml_mapping
from ._paths import ContextPaths
from ._redaction import Redactor
from ._schemas import load_schema, make_validator
from ._timestamps import utc_now_iso
from ._ulid import new_event_id

_EVENT_VERSION = "1.0.0"
_DEFAULT_LARGE_OUTPUT_BYTES = 4096
_DEFAULT_ARTIFACT_EXCERPT_CHARS = 500


@dataclass
class EventInput:
    """Caller-facing fields for constructing a single event.

    The writer fills in ``id``, ``timestamp``, the content excerpt / hash /
    bytes / ref triple, ``is_binary``, and ``redacted``.
    """

    type: str
    actor: str
    summary: str
    session_id: str
    task_id: str
    content: str | bytes | None = None
    content_type: str = "text/plain"
    importance: int = 1
    tags: Sequence[str] = field(default_factory=list)
    source: str = ""
    source_event_ids: Sequence[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


class EventValidationError(Exception):
    """Raised when a constructed event fails schema validation.

    The offending event is exposed on ``event`` for diagnostic logging.
    Nothing is appended to ``events.jsonl`` when this is raised.
    """

    def __init__(self, event: dict, errors: list) -> None:
        super().__init__(
            "event failed schema validation: "
            + "; ".join(e.message for e in errors)
        )
        self.event = event
        self.errors = errors


class EventWriter:
    def __init__(
        self,
        paths: ContextPaths,
        *,
        redactor: Redactor,
        event_validator: Draft202012Validator,
        large_output_bytes: int = _DEFAULT_LARGE_OUTPUT_BYTES,
        artifact_excerpt_chars: int = _DEFAULT_ARTIFACT_EXCERPT_CHARS,
    ) -> None:
        self._paths = paths
        self._redactor = redactor
        self._validator = event_validator
        self._large_output_bytes = int(large_output_bytes)
        self._artifact_excerpt_chars = int(artifact_excerpt_chars)
        self._artifacts = ArtifactStore(paths.artifacts_dir)

    @classmethod
    def open(cls, base: Path) -> EventWriter:
        """Build a writer from an initialized ``.context/`` rooted at ``base``."""
        paths = ContextPaths.at(Path(base))
        redactor = Redactor.from_config_path(paths.redaction_yaml)
        validator = make_validator(load_schema(paths.event_schema))
        thresholds = load_yaml_mapping(paths.thresholds_yaml).get("default", {})
        return cls(
            paths,
            redactor=redactor,
            event_validator=validator,
            large_output_bytes=int(
                thresholds.get("large_output_bytes", _DEFAULT_LARGE_OUTPUT_BYTES)
            ),
            artifact_excerpt_chars=int(
                thresholds.get(
                    "artifact_excerpt_chars", _DEFAULT_ARTIFACT_EXCERPT_CHARS
                )
            ),
        )

    @property
    def paths(self) -> ContextPaths:
        return self._paths

    def append(self, event: EventInput) -> dict:
        """Materialize, validate, and append an event. Return the written dict."""
        (
            head,
            tail,
            content_ref,
            content_hash,
            content_bytes,
            is_binary,
            redacted,
            content_type,
        ) = self._route_content(event)

        full = {
            "schema_version": _EVENT_VERSION,
            "id": new_event_id(),
            "timestamp": utc_now_iso(),
            "session_id": event.session_id,
            "task_id": event.task_id,
            "type": event.type,
            "actor": event.actor,
            "summary": event.summary,
            "content_type": content_type,
            "is_binary": is_binary,
            "content_excerpt_head": head,
            "content_excerpt_tail": tail,
            "content_ref": content_ref,
            "content_hash": content_hash,
            "content_bytes": content_bytes,
            "importance": int(event.importance),
            "tags": list(event.tags),
            "redacted": redacted,
            "source": event.source,
            "source_event_ids": list(event.source_event_ids),
            "metadata": dict(event.metadata),
        }

        errors = sorted(
            self._validator.iter_errors(full),
            key=lambda e: list(e.absolute_path),
        )
        if errors:
            raise EventValidationError(full, errors)

        self._paths.logs_dir.mkdir(parents=True, exist_ok=True)
        with self._paths.events_jsonl.open("a", encoding="utf-8") as f:
            f.write(json.dumps(full) + "\n")
            f.flush()
            os.fsync(f.fileno())

        return full

    def _route_content(
        self, event: EventInput
    ) -> tuple[str | None, str | None, str | None, str | None, int, bool, bool, str]:
        content = event.content
        if content is None:
            return None, None, None, None, 0, False, False, event.content_type

        if isinstance(content, (bytes, bytearray)):
            stored = self._artifacts.write_bytes(bytes(content))
            content_type = event.content_type
            if content_type == "text/plain":
                # default for str — override for raw bytes
                content_type = "application/octet-stream"
            ref = stored.path.relative_to(self._paths.root).as_posix()
            return None, None, ref, stored.sha256, stored.bytes, True, False, content_type

        if isinstance(content, str):
            text, was_redacted = self._redactor.redact(content)
            data = text.encode("utf-8")
            content_bytes = len(data)
            content_hash = hashlib.sha256(data).hexdigest()
            if content_bytes > self._large_output_bytes:
                stored = self._artifacts.write_text(text)
                head = text[: self._artifact_excerpt_chars]
                tail = text[-self._artifact_excerpt_chars :]
                ref = stored.path.relative_to(self._paths.root).as_posix()
                return (
                    head,
                    tail,
                    ref,
                    content_hash,
                    content_bytes,
                    False,
                    was_redacted,
                    event.content_type,
                )
            return (
                text,
                None,
                None,
                content_hash,
                content_bytes,
                False,
                was_redacted,
                event.content_type,
            )

        raise TypeError(
            f"event.content must be str | bytes | None, "
            f"got {type(content).__name__}"
        )
