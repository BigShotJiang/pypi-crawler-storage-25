"""Atomic state.json updater with history snapshots and band recompute.

Wraps the mutate-validate-write sequence in a single entry point so callers
cannot accidentally skip validation or history capture:

1. Read current ``active/state.json``.
2. Apply the caller's mutator.
3. Refresh ``updated_at``.
4. Recompute ``threshold_band`` from ``estimated_context_tokens`` against
   the active ``schemas/thresholds.yaml``.
5. Validate the new state against the on-disk state schema.
6. Atomic-write with a snapshot of the prior state under
   ``active/history/state/``.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from pathlib import Path

from ._atomic import atomic_write_text
from ._paths import ContextPaths
from ._schemas import load_schema, make_validator
from ._thresholds import band_for, compute_bands, load_default_profile
from ._timestamps import utc_now_iso


class StateValidationError(Exception):
    """Raised when a state mutator produces a value that fails the schema."""

    def __init__(self, candidate: dict, errors: list) -> None:
        super().__init__(
            "state failed schema validation: "
            + "; ".join(e.message for e in errors)
        )
        self.candidate = candidate
        self.errors = errors


def update_state(
    base: Path,
    mutator: Callable[[dict], dict],
) -> dict:
    """Apply ``mutator`` to the current state and persist atomically.

    Returns the written state on success. On validation failure, raises
    :class:`StateValidationError` and leaves ``active/state.json`` untouched.
    """
    paths = ContextPaths.at(Path(base))

    current = json.loads(paths.state_json.read_text(encoding="utf-8"))
    candidate = mutator(dict(current))
    if not isinstance(candidate, dict):
        raise TypeError(
            f"mutator must return dict, got {type(candidate).__name__}"
        )

    candidate["updated_at"] = utc_now_iso()

    profile = load_default_profile(paths.thresholds_yaml)
    bands = compute_bands(profile)
    tokens = int(candidate.get("estimated_context_tokens", 0))
    candidate["threshold_band"] = band_for(tokens, bands)

    validator = make_validator(load_schema(paths.state_schema))
    errors = sorted(
        validator.iter_errors(candidate),
        key=lambda e: list(e.absolute_path),
    )
    if errors:
        raise StateValidationError(candidate, errors)

    history_dir = paths.history_dir / "state"
    atomic_write_text(
        paths.state_json,
        json.dumps(candidate, indent=2) + "\n",
        history_dir=history_dir,
    )
    return candidate
