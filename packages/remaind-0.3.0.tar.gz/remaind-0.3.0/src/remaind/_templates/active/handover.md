# Handover

## Goal

Initialize Remaind context.

## Status

Context bootstrapped. No work in progress yet.

## Next Step

Replace this placeholder by recording a real goal, then begin work.

## Constraints

- Respect the authority order defined in `CONTRACT.md`.
- Do not edit `logs/events.jsonl` by hand.

## Artifacts

None yet.

## Decisions

None yet.
