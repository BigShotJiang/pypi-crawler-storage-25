"""Remaind — durable context for long-running agents.

This module is the **public API**. Everything exported here is stable: the
names, their import paths, and their behaviour will not change without a
version bump and a changelog entry.

The underscore-prefixed modules (``remaind._events``, ``remaind._compactor``,
``remaind._llm_compactor``, …) are **internal**. They may be renamed or
restructured at any time — do not import from them directly. If you need
something only available there, open an issue so it can be promoted here.

Operator integration guide: ``docs/integration.md`` in the repository.

Quick orientation — the operator loop::

    import remaind

    remaind.init(base)                        # once: create .context/
    writer = remaind.EventWriter.open(base)    # log events as work happens
    writer.append(remaind.EventInput(...))
    status = remaind.compaction_status(base)   # monitor the token band
    if status.compaction_needed:
        remaind.compact(base)                  # validated compaction
    result = remaind.resume(base)              # build a fresh-context packet
"""

from importlib.metadata import PackageNotFoundError, version

from ._compaction import CompactionStatus, compaction_status
from ._compactor import (
    CompactionCandidate,
    CompactionSources,
    Compactor,
    default_compact,
    select_sources,
)
from ._events import EventInput, EventValidationError, EventWriter
from ._handover_writer import HandoverValidationError, write_handover
from ._local_compactor import CompactorResponseError
from ._paths import ContextPaths
from ._resume_gate import GateAssessment
from ._resume_packet import ResumePacket, build_resume_packet
from ._state_writer import StateValidationError, update_state
from ._tokens import estimate_tokens
from .commands.compact import (
    CompactionError,
    CompactionRejected,
    CompactionResult,
)
from .commands.compact import run as compact
from .commands.init import InitError
from .commands.init import run as init
from .commands.resume import ResumeError, ResumeResult
from .commands.resume import run as resume
from .commands.rollback import RollbackError, RollbackResult
from .commands.rollback import run as rollback
from .commands.status import StatusError
from .commands.status import build_status_payload as status
from .commands.validate import ValidationReport
from .commands.validate import run as validate

try:
    # Single source of truth: the installed package metadata (pyproject.toml).
    __version__ = version("remaind")
except PackageNotFoundError:  # pragma: no cover - running from source tree
    __version__ = "0.0.0+source"


__all__ = [
    "__version__",
    # --- paths -----------------------------------------------------------
    "ContextPaths",
    # --- high-level operations (mirror the CLI verbs) --------------------
    "init",
    "validate",
    "status",
    "compact",
    "resume",
    "rollback",
    # --- event logging ---------------------------------------------------
    "EventWriter",
    "EventInput",
    "EventValidationError",
    # --- derived-state writes -------------------------------------------
    "update_state",
    "StateValidationError",
    "write_handover",
    "HandoverValidationError",
    # --- token budget + compaction monitoring ---------------------------
    "estimate_tokens",
    "compaction_status",
    "CompactionStatus",
    # --- compaction: result + error types -------------------------------
    "CompactionResult",
    "CompactionError",
    "CompactionRejected",
    # --- compaction internals (the rule-based fallback + the protocol) --
    "Compactor",
    "CompactionSources",
    "CompactionCandidate",
    "select_sources",
    "default_compact",
    "CompactorResponseError",
    # --- resume ----------------------------------------------------------
    "build_resume_packet",
    "ResumePacket",
    "ResumeResult",
    "ResumeError",
    "GateAssessment",
    # --- per-command result / error types -------------------------------
    "InitError",
    "ValidationReport",
    "StatusError",
    "RollbackResult",
    "RollbackError",
]
