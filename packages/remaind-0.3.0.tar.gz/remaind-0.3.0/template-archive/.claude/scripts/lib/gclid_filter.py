"""Shared gclid filter constants for /iterate --cross HogQL queries.

Single source of truth for "what counts as a real Google Ads click".
Any HogQL query that filters for paid traffic MUST use one of these constants.

Real Google Ads gclid prefixes (used for 10+ years, stable):
  Cj0KCQ / CjwKCAjw / CjsKCQ  — Search CPC
  EAIaIQob / EAIa             — Display / Performance Max / Discovery
  CIa-                        — Search retargeting (less common but valid)

Operator manual-test patterns excluded by prefix + length:
  test123                          (12 chars — also fails length>40)
  MANUAL_VERIFY_CHECK              (19 chars — fails length>40)
  analytics-verify-2026050720272   (32 chars — passes length>30 but fails length>40)
  framework_audit_*                (variable — fails prefix)
"""

from __future__ import annotations


# Inline HogQL fragment for the attribution expression (use as a SQL operand).
# Reads $session_entry_gclid first (PostHog auto-captured); falls back to
# properties.gclid (manually stamped by analytics.ts loaded callback when
# session_entry capture loses the race to Next.js router URL cleanup).
PAID_GCLID_EXPR = (
    "coalesce(toString(properties.$session_entry_gclid), toString(properties.gclid))"
)

# Inline HogQL fragment for the WHERE-clause filter. Use as a boolean operand.
# Length>40 excludes 32-char operator test sentinels; prefix match positively
# identifies the Google gclid format. False negatives (real gclid not matching
# prefix) are extremely rare and acceptable — they would only undercount slightly.
PAID_GCLID_FILTER = (
    f"{PAID_GCLID_EXPR} IS NOT NULL "
    f"AND length({PAID_GCLID_EXPR}) > 40 "
    f"AND (startsWith({PAID_GCLID_EXPR}, 'Cj') "
    f"OR startsWith({PAID_GCLID_EXPR}, 'EAI') "
    f"OR startsWith({PAID_GCLID_EXPR}, 'CIa'))"
)


def is_real_gclid(g: str | None) -> bool:
    """Python-side validator mirroring PAID_GCLID_FILTER semantics.

    Used to sanity-check operator-set test gclids during /iterate --cross debug
    flows. The HogQL filter and this function MUST stay in lockstep.
    """
    if not g or not isinstance(g, str):
        return False
    return len(g) > 40 and (
        g.startswith("Cj") or g.startswith("EAI") or g.startswith("CIa")
    )
