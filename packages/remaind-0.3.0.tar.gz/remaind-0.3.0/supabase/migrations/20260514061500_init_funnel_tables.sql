-- Remaind surface funnel tables.
--
-- Two anon-insert-only tables backing the marketing surface's capture
-- behaviors (experiment.yaml b-01, b-03). RLS allows INSERT from the anon
-- role and nothing else — no anonymous reads of the signup or feedback
-- lists. supabase-js .insert() without .select() returns no rows, so the
-- INSERT-only policy is sufficient.

create table if not exists public.signups (
    id           uuid primary key default gen_random_uuid(),
    email        text not null,
    source       text,
    utm_source   text,
    utm_medium   text,
    utm_campaign text,
    click_id     text,
    created_at   timestamptz not null default now()
);

create table if not exists public.feedback (
    id         uuid primary key default gen_random_uuid(),
    message    text not null,
    source     text,
    created_at timestamptz not null default now()
);

alter table public.signups  enable row level security;
alter table public.feedback enable row level security;

grant insert on public.signups  to anon;
grant insert on public.feedback to anon;

create policy "anon can insert signups"
    on public.signups for insert
    to anon
    with check (true);

create policy "anon can insert feedback"
    on public.feedback for insert
    to anon
    with check (true);
