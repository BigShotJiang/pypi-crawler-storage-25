from typing import TYPE_CHECKING
from weakref import ReferenceType, ref

from django.template import Origin, Template
from django.template.loader import get_template as django_get_template

from django_components_lite.util.django_monkeypatch import is_cls_patched
from django_components_lite.util.misc import get_module_info

if TYPE_CHECKING:
    from django_components_lite.component import Component


########################################################
# LOADING TEMPLATES FROM FILEPATH
########################################################


# Remember which Component class is currently being loaded
# This is important, because multiple Components may define the same `template_file`.
# So we need this global state to help us decide which Component class of the list of components
# that matched for the given `template_file` should be associated with the template.
#
# NOTE: Implemented as a list (stack) to handle the case when calling Django's `get_template()`
#       could lead to more components being loaded at once.
#       (For this to happen, user would have to define a Django template loader that renders other components
#       while resolving the template file.)
loading_components: list["ComponentRef"] = []


def load_component_template(
    component_cls: type["Component"],
    filepath: str | None = None,
    content: str | None = None,
) -> Template:
    if filepath is None and content is None:
        raise ValueError("Either `filepath` or `content` must be provided.")

    loading_components.append(ref(component_cls))

    if filepath is not None:
        # Use Django's `get_template()` to load the template file
        template = _load_django_template(filepath)
        template = ensure_unique_template(component_cls, template)

    elif content is not None:
        template = _create_template_from_string(component_cls, content)
    else:
        raise ValueError("Received both `filepath` and `content`. These are mutually exclusive.")

    loading_components.pop()

    return template


# When loading a Template instance, it may be cached by Django / template loaders.
# In that case we want to make a copy of the template which would
# be owned by the current Component class.
# Thus each Component has it's own Template instance with their own Origins
# pointing to the correct Component class.
def ensure_unique_template(component_cls: type["Component"], template: Template) -> Template:
    # Use `template.origin.component_cls` to check if the template was cached by Django / template loaders.
    if get_component_from_origin(template.origin) is None:
        set_component_to_origin(template.origin, component_cls)
    else:
        origin_copy = Origin(template.origin.name, template.origin.template_name, template.origin.loader)
        set_component_to_origin(origin_copy, component_cls)
        template = Template(template.source, origin=origin_copy, name=template.name, engine=template.engine)

    return template


def get_component_template(component: "Component") -> Template | None:
    """Resolve the Template instance for a Component, or None if the component has no template."""
    template = _get_component_template(component)
    if template is not None and not is_cls_patched(template):
        raise RuntimeError(
            "Django-components received a Template instance which was not patched."
            "If you are using Django's Template class, check if you added django-components"
            "to INSTALLED_APPS. If you are using a custom template class, then you need to"
            "manually patch the class.",
        )
    return template


def _get_component_template(component: "Component") -> Template | None:
    template: Template | None = None
    template_string: str | None = None

    if component.template_file is not None:
        # Check if there's a cached Template instance on the class
        cached = getattr(component.__class__, "_cached_template", None)
        if cached is not None:
            template = cached
        else:
            template = _load_django_template(component.template_file)
            component.__class__._cached_template = template
    elif component.template:
        template_string = component.template

    # We already have a template instance, so we can return it
    if template is not None:
        return template
    # Create the template from the string
    if template_string is not None:
        return _create_template_from_string(component.__class__, template_string)

    # Otherwise, Component has no template - render returns an empty string.
    return None


def _create_template_from_string(
    component: type["Component"],
    template_string: str,
) -> Template:
    # Generate a valid Origin instance.
    # When an Origin instance is created by Django when using Django's loaders, it looks like this:
    # ```
    # {
    #   'name': '/path/to/project/django-components/sampleproject/calendarapp/templates/calendarapp/calendar.html',
    #   'template_name': 'calendarapp/calendar.html',
    #   'loader': <django.template.loaders.app_directories.Loader object at 0x10b441d90>
    # }
    # ```
    #
    # Since our template is inlined, we will format as `filepath::ComponentName`
    #
    # ```
    # /path/to/project/django-components/src/calendarapp/calendar.html::Calendar
    # ```
    #
    # See https://docs.djangoproject.com/en/5.2/howto/custom-template-backend/#template-origin-api
    _, _, module_filepath = get_module_info(component)
    origin = Origin(
        name=f"{module_filepath}::{component.__name__}",
        template_name=None,
        loader=None,
    )

    set_component_to_origin(origin, component)

    return Template(template_string, name=origin.template_name, origin=origin)


# When loading a template, use Django's `get_template()` to ensure it triggers Django template loaders
# See https://github.com/django-components/django-components/issues/901
#
# This may raise `TemplateDoesNotExist` if the template doesn't exist.
# See https://docs.djangoproject.com/en/5.2/ref/templates/api/#template-loaders
# And https://docs.djangoproject.com/en/5.2/ref/templates/api/#custom-template-loaders
def _load_django_template(template_name: str) -> Template:
    return django_get_template(template_name).template


########################################################
# ASSOCIATING COMPONENT CLASSES WITH TEMPLATES
#
# See https://github.com/django-components/django-components/pull/1222
########################################################

# NOTE: `ReferenceType` is NOT a generic pre-3.9
ComponentRef = ReferenceType[type["Component"]]


# Remember which Component classes defined `template_file`. Since multiple Components may
# define the same `template_file`, we store a list of weak references to the Component classes.
component_template_file_cache: dict[str, list[ComponentRef]] = {}
component_template_file_cache_initialized = False


# Remember the mapping of `Component.template_file` -> `Component` class, so that we can associate
# the `Template` instances with the correct Component class in our monkepatched `Template.__init__()`.
def cache_component_template_file(component_cls: type["Component"]) -> None:
    # When a Component class is created before Django is set up,
    # then `component_template_file_cache_initialized` is False and we leave it for later.
    # This is necessary because:
    # 1. We might need to resolve the template_file as relative to the file where the Component class is defined.
    # 2. To be able to resolve the template_file, Django needs to be set up, because we need to access Django settings.
    # 3. Django settings may not be available at the time of Component class creation.
    if not component_template_file_cache_initialized:
        return

    template_file = getattr(component_cls, "template_file", None)
    if not template_file:
        return

    if template_file not in component_template_file_cache:
        component_template_file_cache[template_file] = []

    component_template_file_cache[template_file].append(ref(component_cls))


def get_component_by_template_file(template_file: str) -> type["Component"] | None:
    # This function is called from within `Template.__init__()`. At that point, Django MUST be already set up,
    # because Django's `Template.__init__()` accesses the templating engines.
    #
    # So at this point we want to call `cache_component_template_file()` for all Components for which
    # we skipped it earlier.
    global component_template_file_cache_initialized  # noqa: PLW0603
    if not component_template_file_cache_initialized:
        component_template_file_cache_initialized = True

        # NOTE: Avoids circular import
        from django_components_lite.component import all_components

        components = all_components()
        for component in components:
            cache_component_template_file(component)

    if template_file not in component_template_file_cache or not len(component_template_file_cache[template_file]):
        return None

    # There is at least one Component class that has this `template_file`.
    matched_component_refs = component_template_file_cache[template_file]

    # There may be multiple components that define the same `template_file`.
    # So to find the correct one, we need to check if the currently loading component
    # is one of the ones that define the `template_file`.
    #
    # If there are NO currently loading components, then `Template.__init__()` was NOT triggered by us,
    # in which case we don't associate any Component class with this Template.
    if not len(loading_components):
        return None

    loading_component = loading_components[-1]()
    if loading_component is None:
        return None

    for component_ref in matched_component_refs:
        comp_cls = component_ref()
        if comp_cls is loading_component:
            return comp_cls

    return None


# NOTE: Used by `@djc_test` to reset the component template file cache
def _reset_component_template_file_cache() -> None:
    global component_template_file_cache  # noqa: PLW0603
    component_template_file_cache = {}

    global component_template_file_cache_initialized  # noqa: PLW0603
    component_template_file_cache_initialized = False


# Helpers so we know where in the codebase we set / access the `Origin.component_cls` attribute
def set_component_to_origin(origin: Origin, component_cls: type["Component"]) -> None:
    origin.component_cls = component_cls


def get_component_from_origin(origin: Origin) -> type["Component"] | None:
    return getattr(origin, "component_cls", None)
