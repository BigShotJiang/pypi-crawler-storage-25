from setuptools import setup, find_packages

setup(
    name="django_template_helper",
    version="0.2",
    packages=find_packages(),
)