from django.urls import path

from . import views

app_name = "users"

urlpatterns = [
    path('registration/', views.registration, name="registration"),
    path('login/', views.mylogin, name="login"),
    path('logout/', views.mylogout, name="logout"),
    path('profile/<str:pk>', views.myprofile, name="profile"),
]