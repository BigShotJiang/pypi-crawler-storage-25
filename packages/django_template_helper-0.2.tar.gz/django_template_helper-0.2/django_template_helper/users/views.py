from django.shortcuts import render, redirect
from django.contrib.auth import get_user_model, authenticate, login, logout
from django.contrib.auth.decorators import login_required
# Create your views here.


def registration(request):
    User = get_user_model()
    user = request.user
    context = {"user": user}
    if request.method == "POST":
        user_name = request.POST.get("login")
        email = request.POST.get("email")
        password = request.POST.get("password")
        tel = request.POST.get("tel")
        User.objects.create_user(user_name, email, password, telephone=tel)
        return render(request, "users/success.html", context=context)
    return render(request, "users/registration.html", context=context)


def mylogin(request):
    user = request.user
    context = {"user": user}
    if request.method == "POST":
        user_name = request.POST.get("login")
        password = request.POST.get("password")
        user = authenticate(request, username=user_name, password=password)
        if user is not None:
            login(request, user)
        return render(request, "users/profile.html", context=context)
    return render(request, "users/login.html", context=context)


def mylogout(request):
    logout(request)
    return redirect("users:login")


def myprofile(request, pk):
    User = get_user_model()
    user = User.objects.get(username=pk)
    context = {"user": user}
    return render(request, "users/profile.html", context=context)
