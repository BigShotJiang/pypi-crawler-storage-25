"""

{% load static %}
<header>
    {% if user.is_authenticated %}
    <a href="{% url 'users:profile' user.username %}">{{ user.username }} </a>
    <a href="{% url 'users:logout' %}">Выйти</a>
    {% else %}
    <a href="{% url 'users:login' %}">Войти</a>
    <a href="{% url 'users:registration' %}">Регистрация</a>
    {% endif %}
</header>

"""
