"""

{% extends "base.html" %}
{% load static %}
{% block title %}Успешная регистрация{% endblock %}
{% block content %}
<p>Успешная регистрация!</p>
{% endblock content %}

"""
