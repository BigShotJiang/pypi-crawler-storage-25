"""

{% extends "base.html" %}
{% load static %}
{% block title %}Профиль{% endblock title %}
{% block content %}
<h1>Профиль {{ user.username }}</h1>
<p>Почта: {{ user.email }}</p>
<p>Телефон: {{ user.telephone }}</p>
{% endblock content %}

"""
