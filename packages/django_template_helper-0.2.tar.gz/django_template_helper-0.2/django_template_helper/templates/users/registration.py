"""

{% extends "base.html" %}
{% load static %}
{% block title %}Регистрация{% endblock %}
{% block content %}
<h1>Регистрация</h1>
<div class="container">
    <div class="row">
        <div class="col-6 border rounded">
            <form method="POST" action="{% url 'users:registration' %}">
                {% csrf_token %}
                <div class="form-group">
                    <input name="login" type="text" id="login" placeholder="Логин" minlength="6" class="form-control">
                </div>
                <div class="form-group">
                    <input name="password" type="password" id="password" placeholder="Пароль" minlength="8" class="form-control">
                </div>
                <div class="form-group">
                    <input name="email" type="email" id="email" placeholder="Email" class="form-control">
                </div>
                <input name="tel" type="tel" id="tel" 
                pattern="8\([0-9]{3}\)[0-9]{3}-[0-9]{2}-[0-9]{2}"
                placeholder="8(123)123-12-12" class="form-control">
                <button type="submit" class="btn btn-primary">Создать пользователя</button>  
            </form>
        </div>
    </div>
</div>
{% endblock %}

"""