"""

{% extends "base.html" %}
{% load static %}
{% block content %}
<h1>Вход в аккаунт</h1>
<div class="container">
    <div class="row">
        <div class="col-6  border rounded ">
            <form method="POST" action="{% url 'users:login' %}">
                {% csrf_token %}
                <div class="form-group">
                    <input type="text" placeholder="Логин" name="login" class="form-control">
                </div>
                <div class="form-group">
                    <input type="password" placeholder="Пароль" name="password" class="form-control">
                </div>
                <button type="submit" class="btn btn-primary">Отправить</button>
            </form>
        </div>
    </div>
</div>
{% endblock %}

"""
