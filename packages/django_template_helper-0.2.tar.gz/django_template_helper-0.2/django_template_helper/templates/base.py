"""

{% load static %}
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>
        {% block title %}{% endblock %}
        </title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="{% static 'css/bootstrap.min.css' %}">
    </head>
    <body>
        {% include "includes/header.html" %}
        {% block content %}
        {% endblock %}
        <script src="{% static 'js/bootstrap.min.js' %}"></script>
    </body>
</html>

"""
