"""
Создать django проект:
django-admin startproject main

Изменить settings.py и urls.py
"""
import main.urls
import main.settings
"""
Создать приложение users:
python manage.py startapp users
Изменить admin.py, models.py, urls.py, views.py
"""
import users.admin
import users.models
import users.urls
import users.views
"""
Создать папку static со следующей иерархией:
static
    ├───css
    │       bootstrap.min.css
    │
    ├───img
    └───js
            bootstrap.min.js
В static/css положить файл с названием bootstram.min.css:
"""
import static.css.bootstrapmincss
"""
В static/js положить файл с названием bootstrap.min.js:
"""
import static.js.bootstrapminjs
"""
Создать папку templates со следующей иерархией:
templates
    │   base.html
    │
    ├───includes
    │       header.html
    │
    └───users
            login.html
            profile.html
            registration.html
            success.html
"""
import templates.base

import templates.includes.header

import templates.users.login
import templates.users.profile
import templates.users.registration
import templates.users.success
"""
Создать и применить миграции:
python manage.py makemigrations
python manage.py migrate
"""
