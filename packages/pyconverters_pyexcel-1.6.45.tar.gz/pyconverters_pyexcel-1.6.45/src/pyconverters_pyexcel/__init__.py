"""Convert XLSX to 1-segment per row document"""

__version__ = "1.6.45"
