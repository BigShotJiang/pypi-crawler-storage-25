import pytest

from syrag.protocols import LLM, Embedder, VectorStore
from syrag.providers import InMemoryEmbedder, InMemoryLLM, InMemoryVectorStore
from syrag.schemas import DocumentChunk, GenerationRequest, QueryRequest


@pytest.mark.asyncio
async def test_in_memory_embedder_is_deterministic() -> None:
    embedder = InMemoryEmbedder(dimensions=8)

    first = await embedder.embed(["SyRAG builds RAG services quickly."])
    second = await embedder.embed(["SyRAG builds RAG services quickly."])

    assert isinstance(embedder, Embedder)
    assert first == second
    assert len(first[0]) == 8


@pytest.mark.asyncio
async def test_in_memory_vector_store_respects_collection_tenant_and_filters() -> None:
    embedder = InMemoryEmbedder()
    store = InMemoryVectorStore()

    documents = [
        "SyRAG is a production-first Python framework for RAG services.",
        "FastAPI powers the HTTP layer for SyRAG.",
    ]
    embeddings = await embedder.embed(documents)
    await store.upsert(
        chunks=[
            DocumentChunk(
                chunk_id="prd-chunk-0",
                source_id="prd",
                content=documents[0],
                metadata={"source_id": "prd", "topic": "product", "page_number": 1},
                page_number=1,
                chunk_index=0,
            ),
            DocumentChunk(
                chunk_id="http-chunk-0",
                source_id="http",
                content=documents[1],
                metadata={"source_id": "http", "topic": "transport", "page_number": 2},
                page_number=2,
                chunk_index=0,
            ),
        ],
        embeddings=embeddings,
        collection="product",
        tenant_id="tenant-a",
    )

    query_embedding = (await embedder.embed(["production-first python framework"]))[0]
    results = await store.query(
        query_embedding=query_embedding,
        top_k=2,
        collection="product",
        tenant_id="tenant-a",
        filters={"topic": "product"},
    )

    assert isinstance(store, VectorStore)
    assert len(results) == 1
    assert results[0].source_id == "prd"
    assert results[0].score > 0.0


@pytest.mark.asyncio
async def test_in_memory_llm_generates_grounded_response_with_citations() -> None:
    embedder = InMemoryEmbedder()
    store = InMemoryVectorStore()
    llm = InMemoryLLM()

    documents = [
        "SyRAG offers a FastAPI-like experience for production RAG services.",
        "It emphasizes observability, type safety, and multi-tenancy.",
    ]
    embeddings = await embedder.embed(documents)
    await store.upsert(
        chunks=[
            DocumentChunk(
                chunk_id="overview-1-chunk-0",
                source_id="overview-1",
                content=documents[0],
                metadata={"source_id": "overview-1", "page_number": 1},
                page_number=1,
                chunk_index=0,
            ),
            DocumentChunk(
                chunk_id="overview-2-chunk-0",
                source_id="overview-2",
                content=documents[1],
                metadata={"source_id": "overview-2", "page_number": 1},
                page_number=1,
                chunk_index=0,
            ),
        ],
        embeddings=embeddings,
        collection="overview",
    )

    query = QueryRequest(query="What does SyRAG emphasize?", collection="overview")
    query_embedding = (await embedder.embed([query.query]))[0]
    context = await store.query(
        query_embedding=query_embedding,
        top_k=2,
        collection=query.collection,
    )
    response = await llm.generate(
        generation=GenerationRequest(
            query=query,
            context=context,
            prompt=f"Question: {query.query}",
            system_prompt="Ground the answer in context.",
            require_citations=True,
        )
    )

    assert isinstance(llm, LLM)
    assert "SyRAG" in response.answer
    assert len(response.citations) == 2
    assert response.citations[0].source_id == "overview-1"
    assert response.usage["prompt_tokens"] > 0
