import tomllib
from pathlib import Path

import syrag
from syrag._optional import missing_optional_dependency
from syrag.providers import __all__ as provider_exports


def test_pyproject_declares_optional_extension_boundaries() -> None:
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    project = pyproject["project"]
    dependencies = project["dependencies"]
    optional_dependencies = project["optional-dependencies"]

    assert project["name"] == "syrag"
    assert "httpx>=0.28.1" not in dependencies
    assert "uvicorn[standard]>=0.44.0" not in dependencies
    assert optional_dependencies["chroma"] == ["chromadb>=1.0.0"]
    assert optional_dependencies["openai"] == ["httpx>=0.28.1"]
    assert optional_dependencies["testing"] == ["httpx>=0.28.1"]
    assert optional_dependencies["server"] == ["uvicorn[standard]>=0.44.0"]


def test_pyproject_declares_release_metadata() -> None:
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    project = pyproject["project"]

    assert project["license"] == "Apache-2.0"
    assert project["authors"] == [{"name": "A. Marzoug"}]
    assert project["requires-python"] == ">=3.12,<3.14"
    assert project["urls"] == {
        "Repository": "https://github.com/a-marzoug/syrag",
        "Issues": "https://github.com/a-marzoug/syrag/issues",
        "Documentation": "https://github.com/a-marzoug/syrag/tree/main/docs",
    }
    assert "Programming Language :: Python :: 3.12" in project["classifiers"]
    assert "Programming Language :: Python :: 3.13" in project["classifiers"]


def test_optional_dependency_error_mentions_install_extra() -> None:
    error = missing_optional_dependency(feature="syrag.testing", extra="testing")

    assert str(error) == (
        "syrag.testing requires the optional 'testing' extra. "
        "Install with `pip install syrag[testing]`."
    )


def test_optional_integrations_are_exported_when_installed() -> None:
    assert "ChromaVectorStore" in provider_exports
    assert "ChromaVectorStore" in syrag.__all__
    assert "OpenAIEmbedder" in provider_exports
    assert "OpenAIEmbedder" in syrag.__all__
    assert "create_test_client" in syrag.__all__
