# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
import argparse
import sys


def main():
    parser = argparse.ArgumentParser(prog="reactor")
    subparsers = parser.add_subparsers(dest="command")

    from .commands import (
        RunCommand,
        InitCommand,
        CapabilitiesCommand,
    )

    RunCommand.register_subcommand(subparsers)
    InitCommand.register_subcommand(subparsers)
    CapabilitiesCommand.register_subcommand(subparsers)

    args, remaining = parser.parse_known_args()
    if hasattr(args, "func"):
        if args.func == RunCommand:
            command = args.func(args, remaining_args=remaining)
        else:
            if remaining:
                parser.error(f"Unrecognized arguments: {' '.join(remaining)}")
            command = args.func(args)
        command.run()
    else:
        parser.print_help()
        sys.exit(1)
