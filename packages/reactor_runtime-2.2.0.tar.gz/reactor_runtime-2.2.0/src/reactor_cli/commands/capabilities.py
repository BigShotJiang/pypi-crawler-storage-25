# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""Capabilities command — prints model capabilities by introspecting the model class."""

import json
from pathlib import Path

from omegaconf import OmegaConf

from reactor_runtime.capabilities import Capabilities
from reactor_runtime.config import ReactorConfig
from reactor_runtime.utils.loader import resolve_class
from reactor_runtime.utils.launch import add_import_paths

_REACTOR_YAML = "reactor.yaml"


class CapabilitiesCommand:
    @staticmethod
    def register_subcommand(subparsers):
        """Register capabilities command."""
        run_parser = subparsers.add_parser(
            "capabilities", help="Print model capabilities from reactor.yaml."
        )
        run_parser.add_argument(
            "--path",
            "-p",
            type=str,
            default=None,
            help="Path to model directory (default: current directory)",
        )
        run_parser.set_defaults(func=CapabilitiesCommand)

    def __init__(self, args):
        """Initialize with parsed arguments."""
        self.args = args

    def run(self):
        """Print the capabilities of a Reactor model.

        Loads the model class (triggering auto-registration of tracks,
        events, and messages in the global registries), then builds
        capabilities from those registries.
        """
        model_path = Path(self.args.path).resolve() if self.args.path else Path.cwd()

        reactor_yaml_path = model_path / _REACTOR_YAML
        if not reactor_yaml_path.exists():
            print(f"Error: {_REACTOR_YAML} not found in {model_path}")
            return

        raw_yaml = OmegaConf.to_container(
            OmegaConf.load(str(reactor_yaml_path)), resolve=True
        )
        if not isinstance(raw_yaml, dict) or "model" not in raw_yaml:
            print(f"Error: {_REACTOR_YAML} must contain a 'model' field")
            return

        reactor_config = ReactorConfig.from_dict(raw_yaml)

        add_import_paths([str(model_path)])

        try:
            model_cls = resolve_class(reactor_config.model)
        except Exception as e:
            print(f"Error loading model class: {e}")
            return

        try:
            caps = Capabilities.from_config(reactor_config, model_cls=model_cls)
        except Exception as e:
            print(f"Error extracting capabilities: {e}")
            return

        model_name = reactor_config.name or reactor_config.model
        print(f"Model: {model_name}")
        print(json.dumps(caps.to_dict(), indent=4))
