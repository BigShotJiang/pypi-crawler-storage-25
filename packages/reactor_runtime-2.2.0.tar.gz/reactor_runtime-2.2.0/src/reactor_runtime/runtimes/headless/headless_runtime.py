# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Headless Runtime for Reactor

A command-line runtime that reads commands from stdin and writes frames to disk.
Useful for testing models, batch processing, and non-interactive scenarios.
"""

import asyncio
import json
import sys
from pathlib import Path
from typing import Optional
import time
import cv2
import os

from reactor_runtime.capabilities import Capabilities
from reactor_runtime.config import ReactorConfig
from reactor_runtime.model_state import ModelEvent
from reactor_runtime.runtime_api import Runtime
from reactor_runtime.utils.log import get_logger
from reactor_runtime.utils.messages import (
    ApplicationMessage,
    RuntimeMessage,
    RuntimeMessageType,
)
from reactor_runtime.runtimes.headless.config import HeadlessRuntimeConfig
from reactor_runtime.runtimes.headless.input_feeder import (
    InputFrameFeeder,
    parse_start_args,
)

logger = get_logger(__name__)


class HeadlessRuntime(Runtime):
    """
    A headless runtime that operates via stdin/stdout and saves output to files.

    Commands (via stdin):
        start [--input-folder PATH] [--input-fps FPS]
                        - Start the model session, optionally feeding input frames
        stop            - Stop the model session
        cmd <name> <json> - Send a command to the model
        help            - Show available commands
        quit            - Exit the runtime
    """

    config: HeadlessRuntimeConfig

    def __init__(self, config: HeadlessRuntimeConfig):
        """
        Initialize the headless runtime.

        Args:
            config: HeadlessRuntimeConfig containing model and runtime-specific settings.
        """
        self.file_path: Optional[Path] = None
        self._frame_count = 0
        self._duplicates_skipped = 0
        self._stdin_task: Optional[asyncio.Task] = None
        self._input_feeder: Optional[InputFrameFeeder] = None
        self._input_frames_fed: int = 0

        # Call parent constructor (loads model)
        super().__init__(config)

    # ===============================
    # Runtime API implementation - MODEL -> CLIENT (stdout)
    # ===============================

    def _send_out_app_bundle_sync(self, media_bundle, duplicate: bool) -> None:
        """Override base-class sync wrapper to forward duplicates.

        The base :class:`Runtime` drops duplicates because re-sending
        the same frame over WebRTC is wasteful.  The headless runtime
        needs to see them so that ``send_out_app_bundle`` can count
        skipped duplicates for the ``ignore_duplicates`` feature.
        """
        if self.loop.is_closed():
            return
        try:
            asyncio.run_coroutine_threadsafe(
                self.send_out_app_bundle(media_bundle, duplicate), self.loop
            )
        except RuntimeError:
            pass

    async def _download_uploaded_file(self, upload_id: str) -> bytes:
        """File upload is not supported in headless mode."""
        raise NotImplementedError("File upload is not supported in headless mode")

    async def send_out_app_message(self, data: ApplicationMessage) -> None:
        """
        Send an application message by printing to stdout.
        """
        output = json.dumps(data, indent=2)
        print(f"\n[MESSAGE] {output}", flush=True)

    async def send_out_runtime_message(self, data: RuntimeMessage) -> None:
        """
        Send a runtime message by printing to stdout.
        """
        output = json.dumps(data, indent=2)
        print(f"\n[RUNTIME] {output}", flush=True)

    async def send_out_app_bundle(self, media_bundle, duplicate: bool) -> None:
        """
        Handle an output media bundle from the model.
        Extracts the video frame and writes it as a PNG file.

        Args:
            media_bundle: A :class:`MediaBundle` (video track extracted).
            duplicate: True if this is a re-emission of the last frame.
        """
        if self.file_path is None:
            return

        # Skip duplicate frames (re-emissions from the frame buffer when it's empty)
        if self.config.ignore_duplicates and duplicate:
            self._duplicates_skipped += 1
            logger.debug(
                "Skipped duplicate frame", total_skipped=self._duplicates_skipped
            )
            return

        # Extract video frame from the bundle
        from reactor_runtime.transports.media import TrackKind

        video_tracks = media_bundle.get_tracks_by_kind(TrackKind.VIDEO)
        if not video_tracks:
            return
        frame = video_tracks[0].data

        # Write frame to disk
        frame_path = self.file_path / f"frame_{self._frame_count:06d}.png"
        # Convert RGB to BGR for OpenCV
        frame_bgr = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        cv2.imwrite(str(frame_path), frame_bgr)
        logger.debug("Saved frame", path=frame_path)

        self._frame_count += 1

    def _print_help(self) -> None:
        """Print available commands and model capabilities."""
        print("\n" + "=" * 60, flush=True)
        print("HEADLESS RUNTIME COMMANDS", flush=True)
        print("=" * 60, flush=True)
        print(
            "  start [--input-folder PATH] [--input-fps FPS]",
            flush=True,
        )
        print(
            "                     - Start session, optionally feeding input frames",
            flush=True,
        )
        print("  stop               - Stop the model session", flush=True)
        print("  cmd <name> <json>  - Send a command to the model", flush=True)
        print("  help               - Show this help message", flush=True)
        print("  quit               - Exit the runtime", flush=True)
        print("=" * 60, flush=True)

        caps = Capabilities.from_config(
            self.config.reactor_config,
            model_cls=type(self.model) if self.model else None,
        )
        if caps.commands:
            print("\nMODEL COMMANDS:", flush=True)
            print("-" * 60, flush=True)
            for name, cmd in caps.commands.items():
                print(f"\n  {name}", flush=True)
                print(
                    f"    Description: {cmd.description or 'No description'}",
                    flush=True,
                )
                if cmd.schema:
                    print(f"    Schema: {json.dumps(cmd.schema, indent=6)}", flush=True)
            print("-" * 60, flush=True)
        else:
            print("\nNo model commands available.", flush=True)

    # ===============================
    # Runtime API implementation - Model Lifecycle Handlers
    # ===============================

    def on_before_stop_session(self, **kwargs) -> None:
        """Stop the feeder before the model so there is no race with model state reset."""
        if self._input_feeder is not None:
            self._input_feeder.stop()
            self._input_frames_fed += self._input_feeder.frames_fed
            self._input_feeder = None

    def on_before_cleanup_complete(self, **kwargs) -> None:
        """
        Handler called before the cleanup complete event is sent.
        This is run right after the model thread finishes cleanup, before the cleanup complete event is sent.
        """
        error = kwargs.get("error", None)
        if error:
            logger.warning("Model exited with error", error=error)
            print(f"\n[ERROR] Model exited with error: {error}", flush=True)
        else:
            logger.info("Model session ended")
            print("\n[INFO] Model session ended", flush=True)

        # Print session summary
        summary = f"Total frames: {self._frame_count}"
        if self._duplicates_skipped > 0:
            summary += f", duplicates skipped: {self._duplicates_skipped}"
        print(f"\n[INFO] Session stopped. {summary}", flush=True)

    def on_before_client_connected(self, **kwargs) -> None:
        """
        Setup the headless session file paths, and then start the model in thread.
        """

        # Reset implementation-specific state
        self._frame_count = 0
        self._duplicates_skipped = 0
        self._input_feeder = None

        # Set output path to <output_root>/<current_epoch>
        self.file_path = Path(self.config.output_root) / str(int(time.time()))
        self.file_path.mkdir(parents=True, exist_ok=True)
        print(f"\n[INFO] Output directory: {self.file_path.absolute()}", flush=True)

        # Set up and start the input frame feeder if requested for this session
        input_folder = kwargs.get("input_folder")
        if input_folder:
            self._input_feeder = InputFrameFeeder(
                input_folder=input_folder,
                model=self.model,
                input_fps=kwargs.get("input_fps"),
            )
            if self._input_feeder.validate():
                self._input_feeder.start()
            else:
                self._input_feeder = None

        print("\n[INFO] Session started", flush=True)

    # ===============================
    # Runtime API implementation - Client Commands
    # ===============================

    async def _send_command(self, cmd_line: str) -> None:
        """
        Parse and send a command to the model.

        Expected format: cmd <command_name> <json_args>
        """
        if not self.session_running:
            print(
                f"\n[WARN] Cannot send command in state {self.current_state.value}.",
                flush=True,
            )
            return

        parts = cmd_line.split(maxsplit=2)
        if len(parts) < 2:
            print("\n[ERROR] Usage: cmd <command_name> [json_args]", flush=True)
            return

        cmd_name = parts[1]

        # Parse JSON args if provided
        args = {}
        if len(parts) >= 3:
            try:
                args = json.loads(parts[2])
            except json.JSONDecodeError as e:
                print(f"\n[ERROR] Invalid JSON: {e}", flush=True)
                return

        # Handle runtime-level commands locally (not dispatched to model)
        if cmd_name == RuntimeMessageType.REQUEST_CAPABILITIES:
            caps = Capabilities.from_config(
                self.config.reactor_config,
                model_cls=type(self.model) if self.model else None,
            )
            print(f"\n[RESULT] {json.dumps(caps.to_dict(), indent=2)}", flush=True)
            return

        msg = json.dumps(
            {"scope": "application", "data": {"type": cmd_name, "data": args}}
        )
        await self._handle_incoming_data_channel_message(msg)
        print(f"\n[OK] Command '{cmd_name}' dispatched", flush=True)

    async def _read_stdin_loop(self) -> None:
        """
        Main loop that reads commands from stdin.
        """
        print("\n" + "=" * 60, flush=True)
        model_name = self.config.reactor_config.name or self.config.reactor_config.model
        print(f"Headless Runtime Ready - Model: {model_name}", flush=True)
        print("Type 'help' for available commands", flush=True)
        print("=" * 60, flush=True)

        loop = asyncio.get_event_loop()

        while True:
            try:
                # Print prompt
                status = f"[{self.current_state.value}]"
                print(f"\n{status}> ", end="", flush=True)

                # Read line from stdin asynchronously
                line = await loop.run_in_executor(None, sys.stdin.readline)

                if not line:
                    # EOF reached
                    break

                original_line = line.strip()
                line_lower = original_line.lower()

                if not original_line:
                    continue

                if line_lower == "start" or line_lower.startswith("start "):
                    start_args = parse_start_args(original_line[len("start") :].strip())
                    if start_args is None:
                        continue

                    success = self.send(ModelEvent.START_SESSION)
                    if not success:
                        print("\n[ERROR] Failed to start session", flush=True)
                        continue
                    self.send(
                        ModelEvent.CLIENT_CONNECTED,
                        input_folder=start_args.input_folder,
                        input_fps=start_args.input_fps,
                    )
                elif line_lower == "stop":
                    self.send(ModelEvent.STOP_SESSION)
                elif line_lower.startswith("cmd "):
                    await self._send_command(original_line)
                elif line_lower == "help":
                    self._print_help()
                elif line_lower in ("quit", "exit"):
                    # Break out of loop to trigger shutdown in finally block
                    print("\n[INFO] Exiting...", flush=True)
                    return
                else:
                    print(
                        f"\n[ERROR] Unknown command: {original_line}. Type 'help' for available commands.",
                        flush=True,
                    )

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception("Error in stdin loop")
                print(f"\n[ERROR] {e}", flush=True)

    async def run(self) -> None:
        """
        Main entry point to run the headless runtime.
        Starts the stdin reading loop and handles shutdown.
        """

        try:
            await self._read_stdin_loop()
        except KeyboardInterrupt:
            print("\n[INFO] Interrupted", flush=True)
        finally:
            # Perform graceful shutdown with proper state transitions
            await self.shutdown()
            print("\n[INFO] Runtime shutdown complete", flush=True)
            # Force exit to terminate the stdin executor thread that may still be blocking
            os._exit(0)


async def serve(
    reactor_config: ReactorConfig,
    **kwargs,
) -> None:
    """Entry point for running the headless runtime from a CLI.

    Args:
        reactor_config: Parsed reactor.yaml configuration.
        **kwargs: Runtime-specific arguments from HeadlessRuntimeConfig.parser()
            - output_root: Root directory for output (default: "./output")
            - no_ignore_duplicates: If True, write all frames including duplicates (default: False)
            - orphan_timeout: Seconds to wait before stopping orphaned session (default: 30.0)
            - max_session_duration: Maximum session duration in seconds (default: None, disabled)
    """
    config = HeadlessRuntimeConfig(
        reactor_config=reactor_config,
        output_root=kwargs.get("output_root", "./output"),
        ignore_duplicates=not kwargs.get("no_ignore_duplicates", False),
        orphan_timeout=kwargs.get("orphan_timeout", 30.0),
        max_session_duration=kwargs.get("max_session_duration"),
        profiling_output_dir=kwargs.get("profiling_output_dir"),
    )

    runtime = HeadlessRuntime(config)
    asyncio.create_task(runtime.load())
    await runtime.run()
