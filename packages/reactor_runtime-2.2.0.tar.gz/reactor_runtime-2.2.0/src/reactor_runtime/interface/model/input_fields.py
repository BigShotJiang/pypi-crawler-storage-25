# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Input field constraints — :func:`InputField` and :class:`FieldInfo`.

Use :func:`InputField` as the default value for ``@event`` parameters
or ``InputState`` fields to declare validation constraints::

    @event(name="set_brightness", description="Adjust brightness")
    def set_brightness(self, brightness: float = InputField(default=1.0, ge=0.0, le=1.0)):
        self.brightness = brightness
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Optional, Tuple, Union

_NO_DEFAULT = object()


@dataclass(frozen=True)
class FieldInfo:
    """Validation constraints for a single input field.

    Create instances via :func:`InputField` rather than directly.
    When no default is provided, ``default`` is :data:`_NO_DEFAULT`.
    """

    default: Any = _NO_DEFAULT
    description: Optional[str] = None
    ge: Optional[Union[int, float]] = None
    le: Optional[Union[int, float]] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    choices: Optional[List[Any]] = None


def InputField(
    default: Any = _NO_DEFAULT,
    *,
    description: Optional[str] = None,
    ge: Optional[Union[int, float]] = None,
    le: Optional[Union[int, float]] = None,
    min_length: Optional[int] = None,
    max_length: Optional[int] = None,
    choices: Optional[List[Any]] = None,
) -> Any:
    """Declare a default value and validation constraints for a field.

    Use as the default value for ``@event`` handler parameters or
    :class:`InputState` fields.  Values that violate constraints are
    rejected before reaching the handler (logged at debug level,
    the event is dropped).

    Args:
        default: Default value for the field.
        description: Human-readable description (exposed in capabilities).
        ge: Minimum allowed value (inclusive).
        le: Maximum allowed value (inclusive).
        min_length: Minimum length for string/sequence values.
        max_length: Maximum length for string/sequence values.
        choices: Exhaustive list of allowed values.
    """
    return FieldInfo(
        default=default,
        description=description,
        ge=ge,
        le=le,
        min_length=min_length,
        max_length=max_length,
        choices=choices,
    )


def validate_field(name: str, value: Any, info: FieldInfo) -> Tuple[bool, str]:
    """Validate *value* against its :class:`FieldInfo` constraints.

    Returns ``(True, "")`` if valid, ``(False, reason)`` if not.
    """
    if info.choices is not None and value not in info.choices:
        return False, f"{name}: {value!r} not in choices {info.choices}"

    if info.ge is not None:
        try:
            if value < info.ge:
                return False, f"{name}: {value} < ge({info.ge})"
        except TypeError:
            return False, f"{name}: {value!r} is not comparable to ge({info.ge})"

    if info.le is not None:
        try:
            if value > info.le:
                return False, f"{name}: {value} > le({info.le})"
        except TypeError:
            return False, f"{name}: {value!r} is not comparable to le({info.le})"

    if info.min_length is not None:
        try:
            if len(value) < info.min_length:
                return (
                    False,
                    f"{name}: length {len(value)} < min_length({info.min_length})",
                )
        except TypeError:
            return (
                False,
                f"{name}: {value!r} has no length for min_length({info.min_length})",
            )

    if info.max_length is not None:
        try:
            if len(value) > info.max_length:
                return (
                    False,
                    f"{name}: length {len(value)} > max_length({info.max_length})",
                )
        except TypeError:
            return (
                False,
                f"{name}: {value!r} has no length for max_length({info.max_length})",
            )

    return True, ""
