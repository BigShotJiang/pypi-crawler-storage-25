# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Model decorators — ``@connected``, ``@disconnected``, ``@file_uploaded``, and ``@event``.
"""

from __future__ import annotations

import dataclasses
import inspect
from dataclasses import make_dataclass
from typing import Any, Callable, List, Tuple, Type, Union, get_type_hints

from reactor_runtime.interface.events.event import Event, _snake_to_pascal
from reactor_runtime.interface.model.input_fields import FieldInfo, _NO_DEFAULT
from reactor_runtime.interface.upload import UploadedFile

_CONNECTED_ATTR = "__reactor_connected__"
_DISCONNECTED_ATTR = "__reactor_disconnected__"
_FILE_UPLOADED_ATTR = "__reactor_file_uploaded__"
_EVENT_HANDLER_ATTR = "__reactor_event_meta__"
_IS_ASYNC_ATTR = "__reactor_is_async__"


def connected(func: Callable) -> Callable:
    """Mark a method as the handler called when a client connects.

    Called once per connection, before the generation loop begins.
    Only one ``@connected`` handler is allowed per model class.
    The handler may be ``async def`` or a plain ``def``.

    Example::

        @connected
        async def on_connect(self):
            self.frame_count = 0
    """
    if not callable(func):  # type annotations aren't enforced at runtime
        raise TypeError(f"@connected expected a callable, got {type(func)}")
    setattr(func, _CONNECTED_ATTR, True)
    setattr(func, _IS_ASYNC_ATTR, inspect.iscoroutinefunction(func))
    return func


def disconnected(func: Callable) -> Callable:
    """Mark a method as the handler called when a client disconnects.

    Called once when the client leaves the session.  Only one
    ``@disconnected`` handler is allowed per model class.  The
    handler may be ``async def`` or a plain ``def``.

    Example::

        @disconnected
        async def on_disconnect(self):
            self.cleanup()
    """
    if not callable(func):  # type annotations aren't enforced at runtime
        raise TypeError(f"@disconnected expected a callable, got {type(func)}")
    setattr(func, _DISCONNECTED_ATTR, True)
    setattr(func, _IS_ASYNC_ATTR, inspect.iscoroutinefunction(func))
    return func


def file_uploaded(func: Callable) -> Callable:
    """Mark a method as the handler called when a file is uploaded.

    Called each time the client uploads a file to the runtime.
    Only one ``@file_uploaded`` handler is allowed per model class.
    The handler receives a single ``uploaded_file`` keyword argument
    of type :class:`UploadedFile`.  The handler may be ``async def``
    or a plain ``def``.

    Example::

        @file_uploaded
        async def on_file(self, uploaded_file: UploadedFile):
            if uploaded_file.mime_type.startswith("image/"):
                pil_image = Image.open(io.BytesIO(uploaded_file.data))
    """
    if not callable(func):
        raise TypeError(f"@file_uploaded expected a callable, got {type(func)}")
    sig = inspect.signature(func)
    params = [p for p in sig.parameters if p != "self"]
    if params != ["uploaded_file"]:
        raise TypeError(
            f"@file_uploaded handler must accept exactly one parameter named "
            f"'uploaded_file', got: {params}"
        )
    setattr(func, _FILE_UPLOADED_ATTR, True)
    setattr(func, _IS_ASYNC_ATTR, inspect.iscoroutinefunction(func))
    return func


def event(*, name: str, description: str = "", dedupe: bool = False):
    """Mark a method as a named event handler.

    The client triggers this handler by sending a message with the
    matching event ``type``.  The method's type-annotated parameters
    define the expected payload fields.  Use :func:`InputField` as
    a default value to add validation constraints.

    The handler may be ``async def`` or a plain ``def``.

    Args:
        name: Event name the client sends as the ``type`` string.
        description: Human-readable description (exposed in model
            capabilities).
        dedupe: When ``True`` and running inside a
            :class:`ReactorPipeline`, duplicate events of this type
            that queue up between ``yield`` points are collapsed —
            the handler runs once with the latest payload.  Useful
            for expensive handlers (e.g. VAE-encoding an image).

    Example::

        @event(name="set_brightness", description="Adjust brightness")
        async def set_brightness(self, brightness: float = InputField(default=1.0, ge=0.0, le=1.0)):
            self.brightness = brightness
    """

    def decorator(func: Callable) -> Callable:
        if not callable(func):  # type annotations aren't enforced at runtime
            raise TypeError(f"@event expected a callable, got {type(func)}")
        is_async = inspect.iscoroutinefunction(func)
        event_cls = _make_event_from_method(func, name)
        if dedupe:
            event_cls._dedupe = True  # type: ignore[attr-defined]
        setattr(
            func,
            _EVENT_HANDLER_ATTR,
            {
                "name": name,
                "description": description,
                "event_cls": event_cls,
                "is_async": is_async,
            },
        )
        setattr(func, _IS_ASYNC_ATTR, is_async)
        return func

    return decorator


# ------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------


def make_event_class(
    event_name: str,
    fields: List[Union[Tuple[str, type], Tuple[str, type, Any]]],
) -> Type[Event]:
    """Create a ``@dataclass`` Event subclass for a named event.

    The class name is the PascalCase version of *event_name*, which
    round-trips through ``Event._event_name()`` back to *event_name*
    for registry lookup.
    """
    class_name = _snake_to_pascal(event_name)
    return make_dataclass(class_name, fields, bases=(Event,))


def _make_event_from_method(func: Callable, event_name: str) -> Type[Event]:
    """Generate an Event subclass from a method's signature.

    Handles ``InputField()`` / ``FieldInfo`` defaults: extracts the
    actual default value for the dataclass field and stores the
    ``FieldInfo`` on the generated Event class as ``_field_infos``.
    """
    sig = inspect.signature(func)
    try:
        hints = get_type_hints(func)
    except Exception:
        hints = {}

    fields: list = []
    field_infos: dict[str, FieldInfo] = {}
    upload_fields: set[str] = set()

    for param_name, param in sig.parameters.items():
        if param_name == "self":
            continue
        param_type = hints.get(param_name, Any)

        if param_type is UploadedFile:
            upload_fields.add(param_name)

        if param.default != inspect.Parameter.empty:
            raw_default = param.default
            if isinstance(raw_default, FieldInfo):
                field_infos[param_name] = raw_default
                actual_default = raw_default.default
            else:
                actual_default = raw_default

            if actual_default is _NO_DEFAULT:
                fields.append((param_name, param_type))
            else:
                fields.append(
                    (
                        param_name,
                        param_type,
                        dataclasses.field(default=actual_default),
                    )
                )
        else:
            fields.append((param_name, param_type))

    event_cls = make_event_class(event_name, fields)

    if field_infos:
        event_cls._field_infos = field_infos  # type: ignore[attr-defined]

    if upload_fields:
        event_cls._upload_fields = upload_fields  # type: ignore[attr-defined]

    return event_cls
