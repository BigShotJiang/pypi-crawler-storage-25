# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
:class:`InputState` — typed, client-mutable session state.

Declare your session parameters as fields on an :class:`InputState`
subclass.  Public fields (no ``_`` prefix) become ``set_<field>``
events the client can send.  Private fields (``_`` prefix) are not
exposed to the client::

    @dataclass
    class GameState(InputState):
        prompt: str = InputField(default="a sunny meadow")
        brightness: float = InputField(default=1.0, ge=0.0, le=1.0)

        _encoded_prompt: Any = None   # private — not exposed
"""

from __future__ import annotations

import dataclasses
from typing import Any, ClassVar, Dict, Set, get_type_hints

from reactor_runtime.interface.model.input_fields import FieldInfo, _NO_DEFAULT
from reactor_runtime.interface.upload import UploadedFile

_MISSING = object()


class InputState:
    """Base class for typed, client-mutable session state.

    Subclass with annotated fields to define the parameters a client
    can change during a session.  Use :func:`InputField` to set
    defaults and validation constraints.

    - **Public fields** (no ``_`` prefix) — each one generates a
      ``set_<field>`` event the client can send.
    - **Private fields** (``_`` prefix) — not exposed to clients.
      Useful for derived or cached values updated in custom ``@event``
      handlers.

    A fresh instance is created for each client connection and
    destroyed on disconnect.  Read the current values via
    ``self.state.<field>`` inside your ``inference()`` generator.

    Example::

        @dataclass
        class GameState(InputState):
            prompt: str = InputField(default="a sunny meadow")
            brightness: float = InputField(default=1.0, ge=0.0, le=1.0)
            _cached_embedding: Any = None
    """

    _public_fields: ClassVar[Dict[str, FieldInfo]]
    _private_fields: ClassVar[Set[str]]
    _upload_fields: ClassVar[Set[str]]

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)

        # Extract FieldInfo metadata and replace with actual defaults
        # BEFORE @dataclass processes the class — otherwise the dataclass
        # bakes the FieldInfo object itself as the field default.
        public: Dict[str, FieldInfo] = {}
        private: Set[str] = set()
        uploads: Set[str] = set()

        annotations = getattr(cls, "__annotations__", {})
        try:
            resolved_hints = get_type_hints(cls)
        except Exception:
            resolved_hints = {}
        for name in list(annotations):
            raw = cls.__dict__.get(name, _MISSING)
            ann = resolved_hints.get(name, annotations[name])
            is_upload = ann is UploadedFile
            if name.startswith("_"):
                private.add(name)
            elif is_upload:
                uploads.add(name)
                if isinstance(raw, FieldInfo):
                    public[name] = raw
                    setattr(cls, name, None)
                elif raw is _MISSING:
                    public[name] = FieldInfo(default=None)
                    setattr(cls, name, None)
                else:
                    public[name] = FieldInfo(default=raw)
            elif isinstance(raw, FieldInfo):
                public[name] = raw
                if raw.default is not _NO_DEFAULT:
                    setattr(cls, name, raw.default)
                else:
                    delattr(cls, name)
            elif raw is not _MISSING:
                public[name] = FieldInfo(default=raw)
            else:
                public[name] = FieldInfo()

        cls._public_fields = public
        cls._private_fields = private
        cls._upload_fields = uploads

        if not dataclasses.is_dataclass(cls):
            dataclasses.dataclass(cls)
