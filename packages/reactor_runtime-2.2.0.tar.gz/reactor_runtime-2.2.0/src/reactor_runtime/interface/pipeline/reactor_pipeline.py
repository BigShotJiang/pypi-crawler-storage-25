# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
:class:`ReactorPipeline` — generator-driven model with typed state.

A higher-level base class built on :class:`ReactorModel`.  Instead of
writing a manual ``run()`` loop, implement an ``inference()`` generator
and declare a typed :class:`InputState`.  The pipeline handles
connection lifecycle, state management, and adaptive FPS automatically.
"""

from __future__ import annotations

import asyncio
import dataclasses
import inspect
import time
from typing import Any, Callable, Dict, Optional, Type, get_type_hints

from reactor_runtime.interface.model.decorators import make_event_class
from reactor_runtime.interface.model.handlers import (
    EventEntry,
    Handlers,
    collect_handlers,
)
from reactor_runtime.interface.model.input_fields import (
    FieldInfo,
    _NO_DEFAULT,
    validate_field,
)
from reactor_runtime.interface.model.reactor_model import ReactorModel
from reactor_runtime.interface.internal.input_buffer import BufferClosed
from reactor_runtime.interface.internal.reactor_core import ReactorCore
from reactor_runtime.interface.pipeline.idle import Idle
from reactor_runtime.interface.pipeline.input_state import InputState
from reactor_runtime.interface.tracks.output import OUTPUT_REGISTRY, Output
from reactor_runtime.interface.upload import UploadedFile
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class GeneratorEnded(Exception):
    """Raised by ``_advance()`` when the inference generator finishes.

    ``StopIteration`` cannot propagate out of an ``async def`` (PEP 479
    converts it to ``RuntimeError``), so ``_advance()`` catches it and
    raises this instead.  Callers that need to handle generator
    exhaustion should catch ``GeneratorEnded``.
    """


class ReactorPipeline(ReactorModel):
    """Generator-driven model with typed, client-mutable state.

    Subclass and provide:

    - ``state: MyState`` — type annotation declaring the session state
      class (an :class:`InputState` subclass).  ``self.state`` holds
      the live state during a session.
    - ``inference()`` — a generator (``def`` or ``async def``) that
      reads ``self.state``, consumes input tracks, and yields
      :class:`Output` instances (or raw frames for single-track models).

    A fresh ``self.state`` is created for each client connection and
    set to ``None`` on disconnect.  Public state fields automatically
    become ``set_<field>`` events the client can send — no boilerplate
    required.

    All :class:`ReactorModel` features still work: ``@event``,
    ``@connected``, ``@disconnected``, ``emit()``, ``send()``.

    Event handlers are serialised with generator advancement: they
    fire only between ``yield`` points, never at internal ``await``
    boundaries inside ``inference()``.  This means ``self.state`` is
    guaranteed to be consistent within a single generator iteration.

    If ``fps`` is not set on the subclass, the emission rate adapts
    automatically to the model's inference speed.

    Example::

        class MyPipeline(ReactorPipeline):
            state: MyState
            fps = 24

            def load(self, config):
                self.pipe = load_model(config["checkpoint"])

            def inference(self):
                while True:
                    frame = self.pipe.forward(prompt=self.state.prompt)
                    yield MyOutput(video=frame)
    """

    def __init__(self) -> None:
        super().__init__()
        self._state_cls: Type[InputState] = self._resolve_state_class()
        self._dynamic_fps: bool = "fps" not in type(self).__dict__
        self.state = None  # type: ignore[assignment]
        self._single_track_output: Optional[Type[Output]] = None
        self._gen_lock: Optional[asyncio.Lock] = None

    # ------------------------------------------------------------------
    # Async init (must run on the event loop thread)
    # ------------------------------------------------------------------

    def _init_async(self) -> None:
        super()._init_async()
        self._gen_lock = asyncio.Lock()

    # ------------------------------------------------------------------
    # Event handler serialisation
    # ------------------------------------------------------------------

    async def _invoke(
        self,
        handler: Callable,
        is_async: bool,
        *,
        _event: Any = None,
        **kw: Any,
    ) -> None:
        """Run a handler under the generator lock.

        Ensures ``@event``, ``@connected``, and ``@disconnected``
        handlers are mutually exclusive with generator advancement.
        Because ``_dedupe`` runs inside ``super()._invoke`` (after
        the lock is acquired), events that arrive while the dispatcher
        waits for the lock are properly collapsed.
        """
        if self._gen_lock is not None:
            async with self._gen_lock:
                await super()._invoke(handler, is_async, _event=_event, **kw)
        else:
            await super()._invoke(handler, is_async, _event=_event, **kw)

    # ------------------------------------------------------------------
    # State class resolution
    # ------------------------------------------------------------------

    @classmethod
    def _resolve_state_class(cls) -> Type[InputState]:
        """Derive the state class from the ``state`` type annotation.

        Looks for a class-level ``state: MyState`` annotation where
        ``MyState`` is an :class:`InputState` subclass.  Falls back to
        an explicit ``state_class`` attribute for backwards compat.
        """
        hints = get_type_hints(cls, include_extras=False)
        hint = hints.get("state")
        if hint is not None and isinstance(hint, type) and issubclass(hint, InputState):
            return hint

        # Fallback: explicit state_class attribute
        state_cls = getattr(cls, "state_class", None)
        if state_cls is not None and issubclass(state_cls, InputState):
            return state_cls

        raise TypeError(
            f"{cls.__name__} must declare 'state: MyState' where MyState "
            f"is an InputState subclass."
        )

    # ------------------------------------------------------------------
    # Generator advancement
    # ------------------------------------------------------------------

    async def _advance(self, gen, is_async: bool):
        """Advance the inference generator by one ``yield``.

        Returns ``(output, compute_time)`` where *output* is a
        resolved :class:`Output` instance or :data:`Idle`.

        Note:
            In the production ``run()`` loop the caller must hold
            ``_gen_lock`` (via ``async with self._gen_lock:``)
            before calling this method.  Advancing the generator
            without the lock allows event handlers to fire at
            internal ``await`` points inside an async
            ``inference()``.              ``PipelineExecutor`` is exempt because
            it is single-threaded and sequential by design.

        Raises:
            GeneratorEnded: The generator finished (``StopIteration``
                / ``StopAsyncIteration``).  Re-raised as
                :class:`GeneratorEnded` because PEP 479 converts
                ``StopIteration`` to ``RuntimeError`` at async
                function boundaries.
            BufferClosed: An input buffer was closed mid-read.
        """
        t0 = time.perf_counter()
        try:
            if is_async:
                result = await gen.__anext__()
            else:
                result = next(gen)
        except (StopIteration, StopAsyncIteration):
            raise GeneratorEnded()
        compute_time = time.perf_counter() - t0
        if result is None or result is Idle:
            return Idle, 0.0
        return self._resolve_output(result), compute_time

    # ------------------------------------------------------------------
    # run() — the generator loop
    # ------------------------------------------------------------------

    async def run(self) -> None:
        """Drive ``inference()`` across client connection cycles.

        Each connection receives a fresh ``self.state`` and a new
        generator instance.  Override :meth:`inference` instead of
        this method when using the pipeline pattern.

        The inference callable is resolved from ``self.inference`` at
        the start of ``run()``.  If ``load()`` assigned an instance
        attribute (e.g. ``self.inference = self._my_generator``), that
        takes priority over the class-level method override.  The
        async-vs-sync distinction is inferred automatically.
        """
        lock = self._gen_lock
        if lock is None:
            raise RuntimeError("run() called before _init_async()")

        inference_fn = self.inference
        is_async = inspect.isasyncgenfunction(inference_fn)

        while True:
            self.state = self._state_cls()
            await self.connected.wait()

            gen = inference_fn()
            try:
                while self.connected.is_set():
                    try:
                        async with lock:
                            output, compute_time = await self._advance(gen, is_async)
                    except GeneratorEnded:
                        logger.debug("inference() ended, restarting generator")
                        gen = inference_fn()
                        await asyncio.sleep(0.005)
                        continue
                    except BufferClosed:
                        logger.debug("Input buffer closed, ending session")
                        break

                    if output is Idle:
                        await asyncio.sleep(0.005)
                        continue

                    if self._dynamic_fps:
                        await self.emit(output, compute_time=compute_time)
                    else:
                        await self.emit(output)
            finally:
                if is_async:
                    await gen.aclose()
                else:
                    gen.close()
                self.state = None
                for buf in self._input_buffers.values():
                    buf.reset()
                self.output_buffer.flush()

    # ------------------------------------------------------------------
    # inference() — override this
    # ------------------------------------------------------------------

    def inference(self):
        """Generation loop — override this as a generator.

        Implement as ``def`` (sync) or ``async def`` (async) generator.
        Each iteration should read ``self.state`` for current parameters,
        optionally read input tracks, run a forward pass, and yield an
        :class:`Output` instance (or a raw ``np.ndarray`` for single-track
        models).  Yield :data:`Idle` or ``None`` to skip a frame.

        The generator is started when a client connects and closed when
        the client disconnects.  If it finishes early (``StopIteration``),
        it is restarted automatically.

        Example (sync)::

            def inference(self):
                while True:
                    frame = self.pipe.forward(prompt=self.state.prompt)
                    yield MyOutput(video=frame)

        Example (async)::

            async def inference(self):
                while True:
                    [frame] = await self.input.camera.read(1)
                    result = self.pipe.forward(frame)
                    yield MyOutput(video=result)
        """
        raise NotImplementedError(f"{type(self).__name__} must implement inference()")

    # ------------------------------------------------------------------
    # Output resolution — typed Output or raw frame shorthand
    # ------------------------------------------------------------------

    def _resolve_output(self, result: Any) -> Output:
        """Wrap a raw frame in the single-track Output class, or pass through."""
        if isinstance(result, Output):
            return result

        out_cls = self._get_single_track_output()
        track_name = next(iter(out_cls._tracks))
        return out_cls(**{track_name: result})

    def _get_single_track_output(self) -> Type[Output]:
        """Find and cache the single-track Output class for raw shorthand."""
        if self._single_track_output is not None:
            return self._single_track_output

        candidates = [cls for cls in OUTPUT_REGISTRY.values() if len(cls._tracks) == 1]
        if len(candidates) == 1:
            self._single_track_output = candidates[0]
            return candidates[0]

        if not candidates:
            raise TypeError(
                "Raw frame shorthand requires an Output subclass with a single "
                "track.  Define one, or yield a typed Output instance instead."
            )
        raise TypeError(
            f"Ambiguous raw frame shorthand: {len(candidates)} single-track "
            f"Output classes registered ({[c.__name__ for c in candidates]}). "
            f"Yield a typed Output instance instead."
        )

    # ------------------------------------------------------------------
    # Auto-generated events for InputState fields
    # ------------------------------------------------------------------

    @classmethod
    def _get_handlers(cls) -> Handlers:
        """Extend handler resolution with auto-generated state setters."""
        cache_key = "_pipeline_handlers_cache"
        if cache_key not in cls.__dict__:
            handlers = collect_handlers(
                cls,
                skip_classes=(ReactorCore, ReactorModel, ReactorPipeline),
            )
            cls._inject_auto_events(handlers)
            setattr(cls, cache_key, handlers)
        return getattr(cls, cache_key)

    @classmethod
    def _inject_auto_events(cls, handlers: Handlers) -> None:
        """Generate ``set_<field>`` events for public InputState fields.

        Skips fields that already have a custom ``@event`` handler with
        the same name.  For ``UploadedFile``-typed fields, the generated
        event class carries an ``_upload_fields`` set so the runtime
        knows to resolve upload references before dispatching.
        """
        try:
            state_cls = cls._resolve_state_class()
        except TypeError:
            return
        type_hints = _resolve_state_hints(state_cls)
        upload_field_names: set[str] = getattr(state_cls, "_upload_fields", set())

        for field_name, field_info in state_cls._public_fields.items():
            event_name = f"set_{field_name}"
            if event_name in handlers.events:
                continue

            field_type = type_hints.get(field_name, Any)
            is_upload = field_name in upload_field_names

            if is_upload:
                event_cls = _build_upload_state_event(
                    event_name, field_name, field_info
                )
                handler = _make_upload_setter(field_name)
            else:
                event_cls = _build_state_event(
                    event_name, field_name, field_type, field_info
                )
                handler = _make_auto_setter(field_name, field_info)

            handlers.events[event_name] = EventEntry(
                handler=handler,
                event_cls=event_cls,
                name=event_name,
                description=f"Set {field_name}",
                is_async=False,
            )


# ------------------------------------------------------------------
# Module-level helpers (kept out of the class for clarity)
# ------------------------------------------------------------------


def _resolve_state_hints(state_cls: type) -> Dict[str, Any]:
    """Get resolved type annotations for an InputState subclass."""
    try:
        return get_type_hints(state_cls)
    except Exception:
        return getattr(state_cls, "__annotations__", {})


def _build_state_event(
    event_name: str,
    field_name: str,
    field_type: type,
    info: FieldInfo,
) -> type:
    """Create an Event subclass for an auto-generated state setter."""
    default = info.default
    fields: list = []
    if default is not _NO_DEFAULT:
        fields.append((field_name, field_type, dataclasses.field(default=default)))
    else:
        fields.append((field_name, field_type))

    event_cls = make_event_class(event_name, fields)
    event_cls._field_infos = {field_name: info}  # type: ignore[attr-defined]
    return event_cls


def _make_auto_setter(field_name: str, info: FieldInfo) -> Callable:
    """Build a handler closure that validates and sets a state field."""

    def handler(self: Any, **kwargs: Any) -> None:
        if self.state is None:
            return
        value = kwargs[field_name]
        ok, reason = validate_field(field_name, value, info)
        if not ok:
            logger.debug("Auto event rejected", reason=reason)
            return
        setattr(self.state, field_name, value)

    return handler


def _build_upload_state_event(
    event_name: str, field_name: str, info: FieldInfo
) -> type:
    """Create an Event subclass for an UploadedFile state field."""
    event_cls = make_event_class(event_name, [(field_name, UploadedFile)])
    event_cls._upload_fields = {field_name}  # type: ignore[attr-defined]
    event_cls._field_infos = {field_name: info}  # type: ignore[attr-defined]
    return event_cls


def _make_upload_setter(field_name: str) -> Callable:
    """Build a handler closure that sets an UploadedFile state field."""

    def handler(self: Any, **kwargs: Any) -> None:
        if self.state is None:
            return
        setattr(self.state, field_name, kwargs[field_name])

    return handler
