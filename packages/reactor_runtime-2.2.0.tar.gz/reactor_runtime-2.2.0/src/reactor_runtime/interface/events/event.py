# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Event base class — :class:`Event`.

Subclass :class:`Event` to define typed events that clients can send
to your model.  Each subclass is automatically registered under its
``snake_case`` name (e.g. ``SetBrightness`` → ``"set_brightness"``).
"""

from __future__ import annotations

import dataclasses
import re
from typing import ClassVar, Dict, Type

EVENT_REGISTRY: Dict[str, Type["Event"]] = {}

_PASCAL_RE = re.compile(r"(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])")


def _pascal_to_snake(name: str) -> str:
    return _PASCAL_RE.sub("_", name).lower()


def _snake_to_pascal(name: str) -> str:
    return "".join(word.capitalize() for word in name.split("_"))


class Event:
    """Base class for all inbound events from client to model.

    Subclass to define a typed event.  The event is registered under
    its ``snake_case`` name (e.g. ``SetBrightness`` →
    ``"set_brightness"``), which is the string the client sends as
    the event ``type``.

    In most cases you don't subclass ``Event`` directly — use the
    ``@event`` decorator on a handler method instead, which creates
    the event class from the method signature automatically.
    """

    name: ClassVar[str]

    def __init_subclass__(cls, *, internal: bool = False, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        if not dataclasses.is_dataclass(cls):
            dataclasses.dataclass(cls)
        if internal:
            return
        event_name = cls._event_name()
        EVENT_REGISTRY[event_name] = cls
        if "name" not in cls.__dict__:
            cls.name = event_name

    @classmethod
    def _event_name(cls) -> str:
        return _pascal_to_snake(cls.__name__)
