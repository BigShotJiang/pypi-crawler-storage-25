# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Typed outbound messages — :class:`ModelMessage`.

Subclass :class:`ModelMessage` to define typed messages your model
sends to the client via :meth:`send`::

    @dataclass
    class CurrentMode(ModelMessage):
        mode: str

    await self.send(CurrentMode(mode="turbo"))

The client receives::

    {"type": "current_mode", "data": {"mode": "turbo"}}
"""

from __future__ import annotations

import dataclasses
from typing import Any, ClassVar, Dict, Type

from reactor_runtime.interface.events.event import _pascal_to_snake

MESSAGE_REGISTRY: Dict[str, Type["ModelMessage"]] = {}


class ModelMessage:
    """Base class for typed outbound messages from model to client.

    Subclass with dataclass fields to define a message type.  Send
    instances via ``await self.send(MyMessage(...))``.  The message
    is delivered to the client as JSON with ``type`` and ``data``
    keys.

    Example::

        @dataclass
        class Progress(ModelMessage):
            step: int
            total: int

        await self.send(Progress(step=42, total=100))
    """

    name: ClassVar[str]

    def __init_subclass__(cls, **kwargs: object) -> None:
        super().__init_subclass__(**kwargs)
        if not dataclasses.is_dataclass(cls):
            dataclasses.dataclass(cls)
        msg_name = cls._message_name()
        MESSAGE_REGISTRY[msg_name] = cls
        if "name" not in cls.__dict__:
            cls.name = msg_name

    @classmethod
    def _message_name(cls) -> str:
        return _pascal_to_snake(cls.__name__)

    def to_wire_format(self) -> Dict[str, Any]:
        """Serialise into the ``{"type": "<name>", "data": {...}}`` wire envelope."""
        data: Dict[str, Any] = {}
        if dataclasses.is_dataclass(self):
            for f in dataclasses.fields(self):
                data[f.name] = getattr(self, f.name)
        return {"type": self.name, "data": data}
