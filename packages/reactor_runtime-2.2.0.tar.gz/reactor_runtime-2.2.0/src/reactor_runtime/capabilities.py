# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Versioned model capabilities descriptor.

:class:`Capabilities` is the structured representation of what a model
can do — its tracks, registered events/commands, and emission settings.
Track topology is introspected from the model's ``OUTPUT_REGISTRY`` and
``INPUT_REGISTRY``; commands come from ``EVENT_REGISTRY``; outbound
messages from ``MESSAGE_REGISTRY``.

The version field allows clients and tooling to detect schema changes.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any, Dict, Literal, Optional, get_args, get_origin

from reactor_runtime.config import ReactorConfig
from reactor_runtime.interface.events.event import EVENT_REGISTRY
from reactor_runtime.interface.events.messages import MESSAGE_REGISTRY
from reactor_runtime.interface.model.input_fields import FieldInfo
from reactor_runtime.interface.tracks.descriptors import Audio
from reactor_runtime.interface.tracks.input import INPUT_REGISTRY
from reactor_runtime.interface.tracks.output import OUTPUT_REGISTRY
from reactor_runtime.interface.upload import UploadedFile


CAPABILITIES_VERSION = "1.2"

_TYPE_MAP = {
    int: "integer",
    float: "number",
    str: "string",
    bool: "boolean",
    UploadedFile: "file",
}


def _resolve_type(raw_type: Any) -> Dict[str, Any]:
    """Resolve a type annotation into a JSON-friendly schema fragment."""
    origin = get_origin(raw_type)

    if origin is Literal:
        values = list(get_args(raw_type))
        value_types = {type(v) for v in values}
        base = "string"
        if value_types == {int}:
            base = "integer"
        elif value_types == {float}:
            base = "number"
        elif value_types == {bool}:
            base = "boolean"
        return {"type": base, "enum": values}

    if isinstance(raw_type, type):
        return {"type": _TYPE_MAP.get(raw_type, raw_type.__name__)}

    if isinstance(raw_type, str):
        return {"type": raw_type}

    return {"type": str(raw_type)}


def _apply_field_info(schema: Dict[str, Any], info: FieldInfo) -> None:
    """Merge FieldInfo constraints into a schema dict."""
    if info.description:
        schema["description"] = info.description
    if info.ge is not None:
        schema["minimum"] = info.ge
    if info.le is not None:
        schema["maximum"] = info.le
    if info.min_length is not None:
        schema["minLength"] = info.min_length
    if info.max_length is not None:
        schema["maxLength"] = info.max_length
    if info.choices is not None:
        schema["enum"] = info.choices


def _field_schema(
    f: dataclasses.Field,
    field_infos: Optional[Dict[str, FieldInfo]] = None,
) -> Dict[str, Any]:
    """Build a JSON-friendly schema dict from a dataclass field."""
    schema = _resolve_type(f.type)

    default_val = f.default
    info: Optional[FieldInfo] = None

    if isinstance(default_val, FieldInfo):
        info = default_val
        default_val = info.default
    elif field_infos is not None:
        info = field_infos.get(f.name)

    if default_val is not dataclasses.MISSING and default_val is not None:
        schema["default"] = default_val
    elif f.default_factory is not dataclasses.MISSING:
        schema["default"] = f.default_factory()

    if info is not None:
        _apply_field_info(schema, info)

    return schema


def _command_schema(cls: type) -> Dict[str, Any]:
    """Build a JSON-friendly schema from a command Event @dataclass."""
    if not dataclasses.is_dataclass(cls):
        return {}
    field_infos = getattr(cls, "_field_infos", None)
    return {f.name: _field_schema(f, field_infos) for f in dataclasses.fields(cls)}


def _message_schema(cls: type) -> Dict[str, Any]:
    """Build a type-only schema from a ModelMessage @dataclass."""
    if not dataclasses.is_dataclass(cls):
        return {}
    return {f.name: _resolve_type(f.type) for f in dataclasses.fields(cls)}


@dataclass
class CommandCapability:
    """Schema for a single command."""

    description: str = ""
    schema: Dict[str, Any] = field(default_factory=dict)


@dataclass
class MessageCapability:
    """Schema for a single outbound message type."""

    schema: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TrackCapability:
    """A single track's metadata in the capabilities payload."""

    kind: str
    direction: str
    rate: float = 0.0


@dataclass
class Capabilities:
    """Versioned capabilities descriptor for a Reactor model.

    Built from the global registries (populated when the model class is
    imported) and a :class:`ReactorConfig` for identity.  Serialisable
    to JSON via :meth:`to_dict`.
    """

    version: str = CAPABILITIES_VERSION
    model: str = ""
    name: str = ""
    fps: Optional[float] = None
    tracks: Dict[str, TrackCapability] = field(default_factory=dict)
    commands: Dict[str, CommandCapability] = field(default_factory=dict)
    messages: Dict[str, MessageCapability] = field(default_factory=dict)

    @classmethod
    def from_config(
        cls,
        config: ReactorConfig,
        model_cls: Optional[type] = None,
    ) -> "Capabilities":
        """Build capabilities from a ReactorConfig + the global registries.

        Track topology is introspected from ``OUTPUT_REGISTRY`` /
        ``INPUT_REGISTRY``; commands from ``EVENT_REGISTRY``; messages
        from ``MESSAGE_REGISTRY``.

        When *model_cls* is provided, handler descriptions are extracted
        from the class's ``@event`` decorators via ``_get_handlers()``,
        and ``fps`` is read from the class attribute.

        Args:
            config: The parsed reactor.yaml (for model name).
            model_cls: The concrete model class (subclass of
                ``ReactorModel``).  Used to extract ``@event`` handler
                descriptions and ``fps``.  Optional — when ``None``,
                descriptions default to empty strings.
        """
        tracks = cls._build_tracks()
        descriptions = cls._extract_handler_descriptions(model_cls)
        model_fps = getattr(model_cls, "fps", None) if model_cls else None

        commands: Dict[str, CommandCapability] = {}
        for event_name, event_cls in EVENT_REGISTRY.items():
            if event_name in ("connected", "disconnected"):
                continue
            commands[event_name] = CommandCapability(
                description=descriptions.get(event_name, ""),
                schema=_command_schema(event_cls),
            )

        messages: Dict[str, MessageCapability] = {}
        for msg_name, msg_cls in MESSAGE_REGISTRY.items():
            messages[msg_name] = MessageCapability(
                schema=_message_schema(msg_cls),
            )

        return cls(
            model=config.model,
            name=config.name,
            fps=model_fps,
            tracks=tracks,
            commands=commands,
            messages=messages,
        )

    @staticmethod
    def _marker_kind(marker: type) -> str:
        if issubclass(marker, Audio):
            return "audio"
        return "video"

    @classmethod
    def _build_tracks(cls) -> Dict[str, TrackCapability]:
        """Introspect INPUT_REGISTRY and OUTPUT_REGISTRY for track metadata.

        Input tracks are listed first so that their m-line indices in
        the SDP come before output tracks.  GStreamer's webrtcbin maps
        ``src_N`` pads to m-line indices; placing sendonly (input) tracks
        first ensures incoming media pads map to the correct track names.

        Raises:
            ValueError: If an input and output track share the same name.
        """
        tracks: Dict[str, TrackCapability] = {}

        for input_cls in INPUT_REGISTRY.values():
            for name, marker in input_cls._tracks.items():
                tracks[name] = TrackCapability(
                    kind=cls._marker_kind(marker),
                    direction="in",
                )

        for output_cls in OUTPUT_REGISTRY.values():
            for name, marker in output_cls._tracks.items():
                if name in tracks:
                    raise ValueError(
                        f"Track name '{name}' is declared as both input and output"
                    )
                tracks[name] = TrackCapability(
                    kind=cls._marker_kind(marker),
                    direction="out",
                )

        return tracks

    @staticmethod
    def _extract_handler_descriptions(
        model_cls: Optional[type],
    ) -> Dict[str, str]:
        """Extract event handler descriptions from a model class.

        Calls ``_get_handlers()`` (available on ``ReactorModel``
        subclasses) and collects the ``description`` from each
        ``EventEntry``.  Returns an empty dict if the class doesn't
        support handler introspection.
        """
        if model_cls is None:
            return {}
        get_handlers = getattr(model_cls, "_get_handlers", None)
        if get_handlers is None:
            return {}
        try:
            handlers = get_handlers()
            return {name: entry.description for name, entry in handlers.events.items()}
        except Exception:
            return {}

    _MODEL_TO_CLIENT_DIRECTION = {"out": "recvonly", "in": "sendonly"}

    def to_dict(self) -> Dict[str, Any]:
        """Serialise to the client-facing format (matches TransportCapabilities proto).

        Tracks are an array of ``{name, kind, direction}`` with directions
        expressed from the **client's** perspective using WebRTC convention:
        model ``out`` -> ``recvonly``, model ``in`` -> ``sendonly``.

        Commands are an array of ``{name, description, schema}`` matching
        the proto ``Command`` message.
        """
        tracks_list = [
            {
                "name": name,
                "kind": t.kind,
                "direction": self._MODEL_TO_CLIENT_DIRECTION.get(
                    t.direction, t.direction
                ),
            }
            for name, t in self.tracks.items()
        ]

        commands_list = [
            {
                "name": name,
                "description": cmd.description,
                "schema": cmd.schema,
            }
            for name, cmd in self.commands.items()
        ]

        messages_list = [
            {
                "name": name,
                "schema": msg.schema,
            }
            for name, msg in self.messages.items()
        ]

        return {
            "protocol_version": self.version,
            "tracks": tracks_list,
            "commands": commands_list,
            "messages": messages_list,
            "emission_fps": self.fps,
        }
