"""Trace format adapters."""
