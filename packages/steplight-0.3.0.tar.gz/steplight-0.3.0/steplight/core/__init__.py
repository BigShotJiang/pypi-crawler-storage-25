"""Core logic for Steplight."""
