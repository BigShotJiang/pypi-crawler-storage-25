"""Alsorn Python SDK client."""

import httpx

from . import __version__
from .exceptions import AlsornAuthError, AlsornError, AlsornRateLimitError
from .resources.agents import AgentsResource
from .resources.trust import TrustResource
from .resources.transactions import TransactionsResource
from .resources.webhooks import WebhooksResource


class AlsornClient:
    """Synchronous client for the Alsorn Protocol API.

    Usage::

        from alsorn import AlsornClient

        client = AlsornClient(api_key="als_YOUR_API_KEY")
        agent = client.agents.register(
            name="Trading Agent Alpha",
            authorized_actions=["execute_trades"],
            spending_limit=50000,
        )
        print(agent.id, agent.fingerprint)

    Or as a context manager::

        with AlsornClient(api_key="als_...") as client:
            agents = client.agents.list()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.alsorn.com",
        timeout: int = 30,
    ):
        if not api_key.startswith("als_"):
            raise AlsornAuthError("Invalid API key format. Keys must start with 'als_'")

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            follow_redirects=True,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"alsorn-python/{__version__}",
            },
            timeout=timeout,
        )

        self.agents = AgentsResource(self)
        self.trust = TrustResource(self)
        self.transactions = TransactionsResource(self)
        self.webhooks = WebhooksResource(self)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict | None = None,
        params: dict | None = None,
    ) -> dict:
        # Filter out None values from params
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        response = self._client.request(method, path, json=json, params=params)

        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "60"))
            raise AlsornRateLimitError(retry_after=retry_after)

        if response.status_code >= 400:
            try:
                body = response.json()
            except Exception:
                body = {}
            raise AlsornError.from_response(response.status_code, body)

        if response.status_code == 204:
            return {}

        return response.json()

    def _request_raw(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
    ) -> bytes:
        """Make a request and return raw bytes (for CSV export)."""
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        response = self._client.request(method, path, params=params)

        if response.status_code >= 400:
            try:
                body = response.json()
            except Exception:
                body = {}
            raise AlsornError.from_response(response.status_code, body)

        return response.content

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "AlsornClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"AlsornClient(base_url={self._base_url!r})"
