"""TrustGraph API resource."""

from __future__ import annotations
from typing import TYPE_CHECKING

from ..models import TrustProfile, TrustHistoryEntry, TrustQueryResponse, DisputeRecord

if TYPE_CHECKING:
    from ..client import AlsornClient


class TrustResource:
    """Operations on the TrustGraph network."""

    def __init__(self, client: AlsornClient) -> None:
        self._client = client

    def query(self, agent_id: str) -> TrustProfile:
        """Get the trust profile for an agent."""
        data = self._client._request("GET", f"/trust/{agent_id}")
        return TrustProfile.from_dict(data)

    def evaluate(self, agent_id: str) -> TrustProfile:
        """Trigger a trust re-evaluation for an agent."""
        data = self._client._request("POST", f"/trust/evaluate/{agent_id}")
        return TrustProfile.from_dict(data)

    def batch_query(self, agent_ids: list[str]) -> TrustQueryResponse:
        """Batch query trust profiles for multiple agents (max 50)."""
        data = self._client._request(
            "POST", "/trust/query", json={"agent_ids": agent_ids}
        )
        return TrustQueryResponse.from_dict(data)

    def get_history(
        self, agent_id: str, *, days: int = 30
    ) -> list[TrustHistoryEntry]:
        """Get trust score history for an agent."""
        data = self._client._request(
            "GET", f"/trust/{agent_id}/history", params={"days": days}
        )
        return [TrustHistoryEntry.from_dict(e) for e in data]

    def report(
        self,
        agent_id: str,
        reason: str,
        *,
        evidence: str | None = None,
        transaction_id: str | None = None,
    ) -> DisputeRecord:
        """File a trust dispute against an agent."""
        body: dict = {"agent_id": agent_id, "reason": reason}
        if evidence is not None:
            body["evidence"] = evidence
        if transaction_id is not None:
            body["transaction_id"] = transaction_id

        data = self._client._request("POST", "/trust/report", json=body)
        return DisputeRecord.from_dict(data)
