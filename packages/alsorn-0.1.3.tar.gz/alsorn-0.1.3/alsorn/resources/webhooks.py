"""Webhooks API resource."""

from __future__ import annotations
from typing import TYPE_CHECKING

from ..models import Webhook, DeliveryResult

if TYPE_CHECKING:
    from ..client import AlsornClient


class WebhooksResource:
    """Operations on webhook endpoints."""

    def __init__(self, client: AlsornClient) -> None:
        self._client = client

    def register(self, url: str, events: list[str]) -> Webhook:
        """Register a new webhook endpoint.

        Args:
            url: The URL to receive webhook events.
            events: List of event types to subscribe to.

        Returns:
            The created Webhook with secret (only returned on creation).
        """
        data = self._client._request(
            "POST", "/webhooks/", json={"url": url, "events": events}
        )
        return Webhook.from_dict(data)

    def list(self) -> list[Webhook]:
        """List all registered webhooks."""
        data = self._client._request("GET", "/webhooks/")
        return [Webhook.from_dict(w) for w in data]

    def get(self, webhook_id: str) -> Webhook:
        """Get a webhook by ID."""
        data = self._client._request("GET", f"/webhooks/{webhook_id}")
        return Webhook.from_dict(data)

    def update(self, webhook_id: str, **kwargs: object) -> Webhook:
        """Update a webhook endpoint.

        Keyword Args:
            url: New webhook URL.
            events: Updated event list.
        """
        data = self._client._request("PUT", f"/webhooks/{webhook_id}", json=kwargs)
        return Webhook.from_dict(data)

    def delete(self, webhook_id: str) -> None:
        """Delete a webhook endpoint."""
        self._client._request("DELETE", f"/webhooks/{webhook_id}")

    def test(self, webhook_id: str) -> DeliveryResult:
        """Send a test event to a webhook endpoint."""
        data = self._client._request("POST", f"/webhooks/{webhook_id}/test")
        return DeliveryResult.from_dict(data)
