"""TransactLayer API resource."""

from __future__ import annotations
from typing import TYPE_CHECKING

from ..models import Transaction, TransactionList

if TYPE_CHECKING:
    from ..client import AlsornClient


class TransactionsResource:
    """Operations on the TransactLayer ledger."""

    def __init__(self, client: AlsornClient) -> None:
        self._client = client

    def execute(
        self,
        agent_id: str,
        counterparty_id: str,
        amount: float,
        action_type: str,
        *,
        currency: str = "USD",
        notes: str | None = None,
    ) -> Transaction:
        """Execute a new transaction between agents.

        Args:
            agent_id: The initiating agent's ID.
            counterparty_id: The receiving agent's ID.
            amount: Transaction amount (must be > 0).
            action_type: The type of action being performed.
            currency: ISO 4217 currency code (default USD).
            notes: Optional transaction notes.
        """
        body: dict = {
            "agent_id": agent_id,
            "counterparty_id": counterparty_id,
            "amount": amount,
            "action_type": action_type,
            "currency": currency,
        }
        if notes is not None:
            body["notes"] = notes

        data = self._client._request("POST", "/transactions/", json=body)
        return Transaction.from_dict(data)

    def list(
        self,
        *,
        agent_id: str | None = None,
        status: str | None = None,
        action_type: str | None = None,
        min_amount: float | None = None,
        max_amount: float | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> TransactionList:
        """List transactions with optional filtering."""
        data = self._client._request(
            "GET",
            "/transactions/",
            params={
                "agent_id": agent_id,
                "status": status,
                "action_type": action_type,
                "min_amount": min_amount,
                "max_amount": max_amount,
                "start_date": start_date,
                "end_date": end_date,
                "page": page,
                "limit": limit,
            },
        )
        return TransactionList.from_dict(data)

    def get(self, transaction_id: str) -> Transaction:
        """Get a transaction by ID with audit data."""
        data = self._client._request("GET", f"/transactions/{transaction_id}")
        return Transaction.from_dict(data)

    def reverse(self, transaction_id: str) -> Transaction:
        """Reverse a completed transaction."""
        data = self._client._request("POST", f"/transactions/{transaction_id}/reverse")
        return Transaction.from_dict(data)

    def export(
        self,
        *,
        agent_id: str | None = None,
        status: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> bytes:
        """Export transactions as CSV bytes."""
        return self._client._request_raw(
            "GET",
            "/transactions/export",
            params={
                "agent_id": agent_id,
                "status": status,
                "start_date": start_date,
                "end_date": end_date,
            },
        )
