"""AgentID API resource."""

from __future__ import annotations
from typing import TYPE_CHECKING

from ..models import Agent, AgentList, AgentListItem, VerificationResult, AuditChain

if TYPE_CHECKING:
    from ..client import AlsornClient


class AgentsResource:
    """Operations on the AgentID registry."""

    def __init__(self, client: AlsornClient) -> None:
        self._client = client

    def register(
        self,
        name: str,
        authorized_actions: list[str],
        spending_limit: float = 1000.0,
        currency: str = "USD",
        environment: str = "production",
        description: str | None = None,
    ) -> Agent:
        """Register a new AI agent on the Alsorn Protocol.

        Issues a cryptographic AgentID and initializes a TrustGraph record.
        The organization is inferred from the authenticated API key.

        Args:
            name: Human-readable agent name.
            authorized_actions: Actions the agent may perform.
            spending_limit: Maximum per-transaction limit (default 1000).
            currency: ISO 4217 currency code (default USD).
            environment: 'production' or 'staging'.
            description: Optional description.

        Returns:
            The newly created Agent with id and fingerprint.
        """
        body: dict = {
            "name": name,
            "authorized_actions": authorized_actions,
            "spending_limit": spending_limit,
            "currency": currency,
            "environment": environment,
        }
        if description is not None:
            body["description"] = description

        data = self._client._request("POST", "/agents/", json=body)
        return Agent.from_dict(data)

    def list(
        self,
        *,
        status: str | None = None,
        environment: str | None = None,
        search: str | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> AgentList:
        """List registered agents with optional filtering."""
        data = self._client._request(
            "GET",
            "/agents/",
            params={
                "status": status,
                "environment": environment,
                "search": search,
                "page": page,
                "limit": limit,
            },
        )
        return AgentList.from_dict(data)

    def get(self, agent_id: str) -> Agent:
        """Get a registered agent by ID with full trust record."""
        data = self._client._request("GET", f"/agents/{agent_id}")
        return Agent.from_dict(data)

    def verify(self, agent_id: str) -> VerificationResult:
        """Public verification of an agent. Does not require authentication."""
        data = self._client._request("GET", f"/agents/{agent_id}/verify")
        return VerificationResult.from_dict(data)

    def update(self, agent_id: str, **kwargs: object) -> Agent:
        """Update mutable agent parameters.

        Keyword Args:
            name: New agent name.
            description: New description.
            authorized_actions: Updated action list.
            spending_limit: Updated spending limit.
            currency: Updated currency.
        """
        data = self._client._request("PATCH", f"/agents/{agent_id}", json=kwargs)
        return Agent.from_dict(data)

    def suspend(self, agent_id: str) -> Agent:
        """Suspend an active agent."""
        data = self._client._request("POST", f"/agents/{agent_id}/suspend")
        return Agent.from_dict(data)

    def get_audit_chain(
        self,
        agent_id: str,
        *,
        page: int = 1,
        limit: int = 20,
    ) -> AuditChain:
        """Get the cryptographic audit chain for an agent."""
        data = self._client._request(
            "GET",
            f"/agents/{agent_id}/audit",
            params={"page": page, "limit": limit},
        )
        return AuditChain.from_dict(data)
