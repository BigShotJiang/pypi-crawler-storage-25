"""Exception hierarchy for the Alsorn Python SDK."""


class AlsornError(Exception):
    """Base exception for all Alsorn SDK errors."""

    def __init__(self, message: str, code: str = "unknown_error", status_code: int = 0, request_id: str | None = None):
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.request_id = request_id

    @classmethod
    def from_response(cls, status_code: int, body: dict) -> "AlsornError":
        error = body.get("error", {})
        code = error.get("code", "unknown_error")
        message = error.get("message", "An unknown error occurred")
        request_id = error.get("request_id")

        if status_code == 401:
            return AlsornAuthError(message, request_id=request_id)
        if status_code == 403:
            return AlsornForbiddenError(message, request_id=request_id)
        if status_code == 404:
            return AlsornNotFoundError(message, request_id=request_id)
        if status_code == 422:
            details = error.get("details", [])
            return AlsornValidationError(message, details=details, request_id=request_id)
        if status_code == 429:
            return AlsornRateLimitError(retry_after=60, request_id=request_id)
        return AlsornAPIError(code=code, message=message, status_code=status_code, request_id=request_id)


class AlsornAuthError(AlsornError):
    """Raised when authentication fails."""

    def __init__(self, message: str = "Authentication failed", request_id: str | None = None):
        super().__init__(message, code="invalid_auth", status_code=401, request_id=request_id)


class AlsornForbiddenError(AlsornError):
    """Raised when access is denied."""

    def __init__(self, message: str = "Forbidden", request_id: str | None = None):
        super().__init__(message, code="forbidden", status_code=403, request_id=request_id)


class AlsornNotFoundError(AlsornError):
    """Raised when a resource is not found."""

    def __init__(self, message: str = "Resource not found", request_id: str | None = None):
        super().__init__(message, code="not_found", status_code=404, request_id=request_id)


class AlsornValidationError(AlsornError):
    """Raised when request validation fails."""

    def __init__(self, message: str = "Validation failed", details: list | None = None, request_id: str | None = None):
        super().__init__(message, code="validation_error", status_code=422, request_id=request_id)
        self.field_errors: dict[str, str] = {}
        for d in details or []:
            if isinstance(d, dict) and "field" in d:
                self.field_errors[d["field"]] = d.get("message", "Invalid value")


class AlsornRateLimitError(AlsornError):
    """Raised when rate limit is exceeded."""

    def __init__(self, retry_after: int = 60, request_id: str | None = None):
        super().__init__(
            f"Rate limit exceeded. Retry after {retry_after}s",
            code="rate_limit_exceeded",
            status_code=429,
            request_id=request_id,
        )
        self.retry_after = retry_after


class AlsornAPIError(AlsornError):
    """Raised for general API errors."""

    def __init__(self, code: str, message: str, status_code: int, request_id: str | None = None):
        super().__init__(message, code=code, status_code=status_code, request_id=request_id)
