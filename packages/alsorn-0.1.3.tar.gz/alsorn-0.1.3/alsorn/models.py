"""Data models for the Alsorn Python SDK."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TrustRecordSummary:
    id: str
    agent_id: str
    score: int

    @classmethod
    def from_dict(cls, data: dict) -> TrustRecordSummary:
        return cls(id=data["id"], agent_id=data["agent_id"], score=data["score"])


@dataclass
class TrustRecordFull:
    id: str
    agent_id: str
    score: int
    total_tasks: int
    disputes: int
    completion_rate: float
    tenure_days: int
    operator_verified: bool
    last_evaluated: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> TrustRecordFull:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})


@dataclass
class Agent:
    id: str
    name: str
    description: str | None
    fingerprint: str
    environment: str
    status: str
    authorized_actions: list[str]
    spending_limit: float
    currency: str
    org_id: str
    owner_id: str
    created_at: str
    trust_record: TrustRecordFull | TrustRecordSummary | None = None

    @classmethod
    def from_dict(cls, data: dict) -> Agent:
        tr = data.get("trust_record")
        if tr:
            if "total_tasks" in tr:
                trust_record = TrustRecordFull.from_dict(tr)
            else:
                trust_record = TrustRecordSummary.from_dict(tr)
        else:
            trust_record = None
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description"),
            fingerprint=data["fingerprint"],
            environment=data["environment"],
            status=data["status"],
            authorized_actions=data["authorized_actions"],
            spending_limit=data["spending_limit"],
            currency=data["currency"],
            org_id=data["org_id"],
            owner_id=data["owner_id"],
            created_at=data["created_at"],
            trust_record=trust_record,
        )


@dataclass
class AgentListItem:
    id: str
    name: str
    fingerprint: str
    environment: str
    status: str
    authorized_actions: list[str]
    spending_limit: float
    currency: str
    created_at: str
    trust_score: int | None = None

    @classmethod
    def from_dict(cls, data: dict) -> AgentListItem:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})


@dataclass
class AgentList:
    agents: list[AgentListItem]
    total: int
    page: int
    limit: int

    @classmethod
    def from_dict(cls, data: dict) -> AgentList:
        return cls(
            agents=[AgentListItem.from_dict(a) for a in data["agents"]],
            total=data["total"],
            page=data["page"],
            limit=data["limit"],
        )


@dataclass
class VerificationResult:
    id: str
    name: str
    org_name: str
    fingerprint: str
    authorized_actions: list[str]
    environment: str
    status: str
    created_at: str
    trust_score: int
    operator_verified: bool
    last_evaluated: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> VerificationResult:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})


@dataclass
class TrustProfile:
    agent_id: str
    score: int
    assessment: str
    components: dict[str, Any]
    total_tasks: int
    disputes: int
    tenure_days: int
    operator_verified: bool
    agent_name: str | None = None
    last_evaluated: str | None = None
    trend: str | None = None
    environment: str | None = None
    org_name: str | None = None
    created_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> TrustProfile:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})


@dataclass
class TrustHistoryEntry:
    score: int
    created_at: str
    reason: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> TrustHistoryEntry:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})


@dataclass
class TrustQueryResponse:
    results: list[TrustProfile | None]

    @classmethod
    def from_dict(cls, data: dict) -> TrustQueryResponse:
        results = [TrustProfile.from_dict(r) if r else None for r in data["results"]]
        return cls(results=results)


@dataclass
class DisputeRecord:
    id: str
    agent_id: str
    reason: str
    status: str
    created_at: str
    evidence: str | None = None
    transaction_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> DisputeRecord:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})


@dataclass
class Transaction:
    id: str
    agent_id: str
    agent_name: str
    counterparty_id: str
    amount: float
    currency: str
    action_type: str
    status: str
    permissions_checked: bool
    created_at: str
    audit_hash: str | None = None
    notes: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> Transaction:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})


@dataclass
class TransactionList:
    transactions: list[Transaction]
    total: int
    page: int
    limit: int

    @classmethod
    def from_dict(cls, data: dict) -> TransactionList:
        return cls(
            transactions=[Transaction.from_dict(t) for t in data["transactions"]],
            total=data["total"],
            page=data["page"],
            limit=data["limit"],
        )


@dataclass
class AuditEntry:
    id: str
    agent_id: str
    action_type: str
    payload_hash: str
    created_at: str
    previous_hash: str | None = None
    operator_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> AuditEntry:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})


@dataclass
class AuditChain:
    entries: list[AuditEntry]
    total: int
    page: int
    limit: int

    @classmethod
    def from_dict(cls, data: dict) -> AuditChain:
        return cls(
            entries=[AuditEntry.from_dict(e) for e in data["entries"]],
            total=data["total"],
            page=data["page"],
            limit=data["limit"],
        )


@dataclass
class Webhook:
    id: str
    org_id: str
    url: str
    events: list[str]
    active: bool
    consecutive_failures: int
    created_at: str
    secret: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> Webhook:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})


@dataclass
class DeliveryResult:
    id: str
    webhook_id: str
    event_type: str
    status: str
    attempts: int
    created_at: str
    payload: dict | None = None
    http_status: int | None = None
    response_body: str | None = None
    duration_ms: int | None = None

    @classmethod
    def from_dict(cls, data: dict) -> DeliveryResult:
        return cls(**{k: data.get(k) for k in cls.__dataclass_fields__})
