"""Tests for the TransactionsResource."""

import unittest
from unittest.mock import MagicMock
from alsorn import AlsornClient
from alsorn.models import Transaction, TransactionList


MOCK_TX = {
    "id": "tx_abc123",
    "agent_id": "agent_abc123",
    "agent_name": "Trading Agent Alpha",
    "counterparty_id": "agent_def456",
    "amount": 1500.0,
    "currency": "USD",
    "action_type": "execute_trades",
    "status": "completed",
    "permissions_checked": True,
    "audit_hash": "sha256:tx_hash",
    "notes": None,
    "created_at": "2025-01-15T10:00:00Z",
}

MOCK_TX_LIST = {
    "transactions": [MOCK_TX],
    "total": 1,
    "page": 1,
    "limit": 20,
}


class TestTransactionsResource(unittest.TestCase):
    def setUp(self):
        self.client = AlsornClient.__new__(AlsornClient)
        self.client._api_key = "als_test_key_123"
        self.client._base_url = "https://api.alsorn.com"
        self.client._client = MagicMock()
        from alsorn.resources.transactions import TransactionsResource

        self.client.transactions = TransactionsResource(self.client)

    def _mock_request(self, return_value):
        self.client._request = MagicMock(return_value=return_value)

    def test_execute(self):
        self._mock_request(MOCK_TX)
        tx = self.client.transactions.execute(
            agent_id="agent_abc123",
            counterparty_id="agent_def456",
            amount=1500,
            action_type="execute_trades",
        )
        self.assertIsInstance(tx, Transaction)
        self.assertEqual(tx.id, "tx_abc123")
        self.assertEqual(tx.amount, 1500.0)

    def test_list(self):
        self._mock_request(MOCK_TX_LIST)
        result = self.client.transactions.list(agent_id="agent_abc123")
        self.assertIsInstance(result, TransactionList)
        self.assertEqual(result.total, 1)

    def test_get(self):
        self._mock_request(MOCK_TX)
        tx = self.client.transactions.get("tx_abc123")
        self.assertIsInstance(tx, Transaction)
        self.assertEqual(tx.status, "completed")

    def test_reverse(self):
        self._mock_request({**MOCK_TX, "status": "reversed"})
        tx = self.client.transactions.reverse("tx_abc123")
        self.assertEqual(tx.status, "reversed")

    def test_export(self):
        self.client._request_raw = MagicMock(return_value=b"id,agent_id,amount\n")
        data = self.client.transactions.export(start_date="2025-01-01")
        self.assertEqual(data, b"id,agent_id,amount\n")


if __name__ == "__main__":
    unittest.main()
