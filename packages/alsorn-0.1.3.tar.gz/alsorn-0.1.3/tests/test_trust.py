"""Tests for the TrustResource."""

import unittest
from unittest.mock import MagicMock
from alsorn import AlsornClient
from alsorn.models import TrustProfile, TrustHistoryEntry, TrustQueryResponse, DisputeRecord


MOCK_TRUST_PROFILE = {
    "agent_id": "agent_abc123",
    "agent_name": "Trading Agent Alpha",
    "score": 850,
    "assessment": "Trusted",
    "components": {
        "completion_rate": {"weight": 0.4, "score": 392, "value": 0.98},
        "dispute_rate": {"weight": 0.3, "score": 270, "value": 0.02},
        "tenure": {"weight": 0.15, "score": 75, "value": 90},
        "operator_verified": {"weight": 0.15, "score": 150, "value": True},
    },
    "total_tasks": 100,
    "disputes": 2,
    "tenure_days": 90,
    "operator_verified": True,
    "last_evaluated": "2025-01-15T10:00:00Z",
    "trend": "stable",
    "environment": "production",
    "org_name": "Acme Corp",
    "created_at": "2024-10-15T10:00:00Z",
}

MOCK_HISTORY = [
    {"score": 840, "reason": "New transaction completed", "created_at": "2025-01-14T10:00:00Z"},
    {"score": 850, "reason": "Re-evaluation", "created_at": "2025-01-15T10:00:00Z"},
]

MOCK_QUERY = {
    "results": [MOCK_TRUST_PROFILE, None],
}

MOCK_DISPUTE = {
    "id": "dispute_001",
    "agent_id": "agent_abc123",
    "reason": "Unauthorized transaction",
    "status": "open",
    "created_at": "2025-01-15T10:00:00Z",
    "evidence": None,
    "transaction_id": "tx_abc123",
}


class TestTrustResource(unittest.TestCase):
    def setUp(self):
        self.client = AlsornClient.__new__(AlsornClient)
        self.client._api_key = "als_test_key_123"
        self.client._base_url = "https://api.alsorn.com"
        self.client._client = MagicMock()
        from alsorn.resources.trust import TrustResource

        self.client.trust = TrustResource(self.client)

    def _mock_request(self, return_value):
        self.client._request = MagicMock(return_value=return_value)

    def test_query(self):
        self._mock_request(MOCK_TRUST_PROFILE)
        profile = self.client.trust.query("agent_abc123")
        self.assertIsInstance(profile, TrustProfile)
        self.assertEqual(profile.score, 850)
        self.assertEqual(profile.assessment, "Trusted")

    def test_evaluate(self):
        self._mock_request(MOCK_TRUST_PROFILE)
        profile = self.client.trust.evaluate("agent_abc123")
        self.assertIsInstance(profile, TrustProfile)

    def test_batch_query(self):
        self._mock_request(MOCK_QUERY)
        result = self.client.trust.batch_query(["agent_abc123", "agent_unknown"])
        self.assertIsInstance(result, TrustQueryResponse)
        self.assertEqual(len(result.results), 2)
        self.assertIsNotNone(result.results[0])
        self.assertIsNone(result.results[1])

    def test_get_history(self):
        self._mock_request(MOCK_HISTORY)
        history = self.client.trust.get_history("agent_abc123", days=7)
        self.assertEqual(len(history), 2)
        self.assertIsInstance(history[0], TrustHistoryEntry)

    def test_report(self):
        self._mock_request(MOCK_DISPUTE)
        record = self.client.trust.report(
            "agent_abc123",
            "Unauthorized transaction",
            transaction_id="tx_abc123",
        )
        self.assertIsInstance(record, DisputeRecord)
        self.assertEqual(record.status, "open")


if __name__ == "__main__":
    unittest.main()
