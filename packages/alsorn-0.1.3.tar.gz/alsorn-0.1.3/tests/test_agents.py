"""Tests for the AgentsResource."""

import unittest
from unittest.mock import MagicMock, patch
from alsorn import AlsornClient, AlsornAuthError
from alsorn.models import Agent, AgentList, VerificationResult, AuditChain


MOCK_AGENT = {
    "id": "agent_abc123",
    "name": "Trading Agent Alpha",
    "description": None,
    "fingerprint": "sha256:abc123def456",
    "environment": "production",
    "status": "active",
    "authorized_actions": ["execute_trades"],
    "spending_limit": 50000.0,
    "currency": "USD",
    "org_id": "org_xyz",
    "owner_id": "user_123",
    "created_at": "2025-01-15T10:00:00Z",
    "trust_record": {
        "id": "tr_001",
        "agent_id": "agent_abc123",
        "score": 850,
    },
}

MOCK_AGENT_FULL = {
    **MOCK_AGENT,
    "trust_record": {
        "id": "tr_001",
        "agent_id": "agent_abc123",
        "score": 850,
        "total_tasks": 100,
        "disputes": 2,
        "completion_rate": 0.98,
        "tenure_days": 90,
        "operator_verified": True,
        "last_evaluated": "2025-01-15T10:00:00Z",
    },
}

MOCK_AGENT_LIST = {
    "agents": [
        {
            "id": "agent_abc123",
            "name": "Trading Agent Alpha",
            "fingerprint": "sha256:abc123def456",
            "environment": "production",
            "status": "active",
            "authorized_actions": ["execute_trades"],
            "spending_limit": 50000.0,
            "currency": "USD",
            "created_at": "2025-01-15T10:00:00Z",
            "trust_score": 850,
        }
    ],
    "total": 1,
    "page": 1,
    "limit": 20,
}

MOCK_VERIFY = {
    "id": "agent_abc123",
    "name": "Trading Agent Alpha",
    "org_name": "Acme Corp",
    "fingerprint": "sha256:abc123def456",
    "authorized_actions": ["execute_trades"],
    "environment": "production",
    "status": "active",
    "created_at": "2025-01-15T10:00:00Z",
    "trust_score": 850,
    "operator_verified": True,
    "last_evaluated": "2025-01-15T10:00:00Z",
}

MOCK_AUDIT = {
    "entries": [
        {
            "id": "audit_001",
            "agent_id": "agent_abc123",
            "action_type": "agent.registered",
            "payload_hash": "sha256:xyz",
            "previous_hash": None,
            "operator_id": "user_123",
            "created_at": "2025-01-15T10:00:00Z",
        }
    ],
    "total": 1,
    "page": 1,
    "limit": 20,
}


class TestAgentsResource(unittest.TestCase):
    def setUp(self):
        self.client = AlsornClient.__new__(AlsornClient)
        self.client._api_key = "als_test_key_123"
        self.client._base_url = "https://api.alsorn.com"
        self.client._client = MagicMock()
        from alsorn.resources.agents import AgentsResource
        from alsorn.resources.trust import TrustResource
        from alsorn.resources.transactions import TransactionsResource
        from alsorn.resources.webhooks import WebhooksResource

        self.client.agents = AgentsResource(self.client)
        self.client.trust = TrustResource(self.client)
        self.client.transactions = TransactionsResource(self.client)
        self.client.webhooks = WebhooksResource(self.client)

    def _mock_request(self, return_value):
        self.client._request = MagicMock(return_value=return_value)

    def test_register(self):
        self._mock_request(MOCK_AGENT)
        agent = self.client.agents.register(
            name="Trading Agent Alpha",
            authorized_actions=["execute_trades"],
            spending_limit=50000,
        )
        self.assertIsInstance(agent, Agent)
        self.assertEqual(agent.id, "agent_abc123")
        self.assertEqual(agent.name, "Trading Agent Alpha")
        self.client._request.assert_called_once()
        # org_id must not be in the request body — server derives it from the API key
        _, kwargs = self.client._request.call_args
        self.assertNotIn("org_id", kwargs.get("json", {}))

    def test_list(self):
        self._mock_request(MOCK_AGENT_LIST)
        result = self.client.agents.list(status="active")
        self.assertIsInstance(result, AgentList)
        self.assertEqual(result.total, 1)
        self.assertEqual(len(result.agents), 1)

    def test_get(self):
        self._mock_request(MOCK_AGENT_FULL)
        agent = self.client.agents.get("agent_abc123")
        self.assertIsInstance(agent, Agent)
        self.assertEqual(agent.trust_record.score, 850)

    def test_verify(self):
        self._mock_request(MOCK_VERIFY)
        result = self.client.agents.verify("agent_abc123")
        self.assertIsInstance(result, VerificationResult)
        self.assertEqual(result.trust_score, 850)
        self.assertTrue(result.operator_verified)

    def test_update(self):
        self._mock_request({**MOCK_AGENT_FULL, "name": "Updated Agent"})
        agent = self.client.agents.update("agent_abc123", name="Updated Agent")
        self.assertEqual(agent.name, "Updated Agent")

    def test_suspend(self):
        self._mock_request({**MOCK_AGENT_FULL, "status": "suspended"})
        agent = self.client.agents.suspend("agent_abc123")
        self.assertEqual(agent.status, "suspended")

    def test_get_audit_chain(self):
        self._mock_request(MOCK_AUDIT)
        result = self.client.agents.get_audit_chain("agent_abc123")
        self.assertIsInstance(result, AuditChain)
        self.assertEqual(len(result.entries), 1)
        self.assertEqual(result.entries[0].action_type, "agent.registered")

    def test_invalid_api_key(self):
        with self.assertRaises(AlsornAuthError):
            AlsornClient(api_key="invalid_key")


if __name__ == "__main__":
    unittest.main()
