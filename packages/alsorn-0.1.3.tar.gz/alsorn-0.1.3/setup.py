from setuptools import setup, find_packages

setup(
    name="alsorn",
    version="0.1.0",
    packages=find_packages(),
    python_requires=">=3.11",
    install_requires=[
        "httpx>=0.27.0",
    ],
    extras_require={
        "dev": ["pytest>=7.0", "pytest-asyncio>=0.21"],
    },
    author="Alsorn",
    description="Official Python SDK for the Alsorn Protocol — Identity, Trust & Transaction Infrastructure for AI Agents",
    url="https://github.com/your-org/alsorn",
)
