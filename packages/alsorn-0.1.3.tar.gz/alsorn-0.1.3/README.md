# Alsorn Python SDK

The official Python SDK for the Alsorn Protocol.

## Installation

```bash
pip install alsorn
```

## Quick Start

```python
from alsorn import AlsornClient

client = AlsornClient(api_key="als_your_api_key")

# Register an agent
agent = client.agents.register(
    name="my-agent",
    authorized_actions=["execute_trades"],
    org_id="your-org-id",
    spending_limit=10000,
    currency="USD",
    environment="production",
)

print(agent.id)
print(agent.fingerprint)
```

> Find your `org_id` in the Alsorn dashboard at
> [alsorn.com/control/settings](https://alsorn.com/control/settings) —
> it's also shown in the sidebar at [alsorn.com/control](https://alsorn.com/control).

## Documentation

Full documentation at https://alsorn.com/docs/sdks/python
