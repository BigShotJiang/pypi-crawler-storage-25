---
name: Feature request
about: Suggest an idea for querri
labels: enhancement
---

## Is your feature request related to a problem?

A clear and concise description of the problem. E.g. "I'm always frustrated when [...]"

## Describe the solution you'd like

A clear and concise description of what you want to happen.

## Alternatives considered

A clear and concise description of any alternative solutions or features you've considered.

## Additional context

Add any other context or screenshots about the feature request here.
