__version__ = "0.1.5"
API_URL = "https://www.zohoapis.eu/crm/v7"
