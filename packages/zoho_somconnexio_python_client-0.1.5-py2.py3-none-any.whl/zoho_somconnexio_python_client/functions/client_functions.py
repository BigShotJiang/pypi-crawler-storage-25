import os
from typing import Optional
import requests
from zoho_somconnexio_python_client import API_URL
from zoho_somconnexio_python_client.exceptions import FunctionNotExecuted


class ZohoFunctionsClient:

    @classmethod
    def execute_function(
        self, function_api_name: str, params: Optional[dict] = {}
    ) -> dict:
        """
        Execute a Zoho CRM function.

        :param function_api_name: Name of the Zoho function to execute.
        :param params: Parameters to pass to the function.
        :return: Response from the Zoho API as a dictionary.
        """
        try:
            zapikey = os.environ.get(f"ZOHO_APIKEY_{function_api_name.upper()}", "")
            url = f"{API_URL}/functions/{function_api_name}/actions/execute"
            headers = {
                "Authorization": f"Bearer {zapikey}",
            }
            query_parms = {"auth_type": "apikey"} | params
            response = requests.post(url, headers=headers, params=query_parms)
        except Exception as e:
            raise FunctionNotExecuted(500, e)

        if response.status_code >= 400:
            raise FunctionNotExecuted(response.status_code, response.text, query_parms)
        return response.json()
