from zoho_somconnexio_python_client.functions.client_functions import (
    ZohoFunctionsClient,
)


class ActivateZohoDealFromOdoo:
    """Class to activate a deal in Zoho from Odoo."""

    @classmethod
    def activate_deal(self, lead_id: str) -> bool:
        """
        Execute function Activat from Odoo in zoho.

        :param lead_id: field in zoho Deals.
        """
        response = ZohoFunctionsClient.execute_function(
            "activat_from_odoo", {"lead_id": lead_id}
        )
        return response["details"]["output"] == "OK"
