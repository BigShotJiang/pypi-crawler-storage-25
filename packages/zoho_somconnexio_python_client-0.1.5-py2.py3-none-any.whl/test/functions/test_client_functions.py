import os
import unittest
from mock import patch


from test.utilities import FakeResponse
from zoho_somconnexio_python_client import API_URL
from zoho_somconnexio_python_client.exceptions import FunctionNotExecuted
from zoho_somconnexio_python_client.functions.client_functions import (
    ZohoFunctionsClient,
)


@patch.dict(
    os.environ,
    {
        "ZOHO_APIKEY_API_NAME": "token_api_name",
    },
)
class ZohoFunctionsClientTestCase(unittest.TestCase):
    def setUp(self):
        self.params = {"param": "test"}
        self.function_api_name = "api_name"

    @patch(
        "zoho_somconnexio_python_client.functions.client_functions.requests.post",
        return_value=FakeResponse(),
    )
    def test_execution_function_ok(self, mock_post):
        response = ZohoFunctionsClient.execute_function(
            self.function_api_name, self.params
        )
        self.assertEqual(response, FakeResponse().json())
        mock_post.assert_called_once_with(
            f"{API_URL}/functions/{self.function_api_name}/actions/execute",
            headers={
                "Authorization": "Bearer token_api_name",
            },
            params={"auth_type": "apikey", **self.params},
        )

    @patch(
        "zoho_somconnexio_python_client.functions.client_functions.requests.post",
        return_value=FakeResponse(404),
    )
    def test_execution_function_ko(self, _):
        msg = "Error executing function with the next error message:"
        self.assertRaisesRegex(
            FunctionNotExecuted,
            msg,
            ZohoFunctionsClient.execute_function,
            self.function_api_name,
            self.params,
        )

    def test_execution_function_error(self):
        msg = "Error executing function with the next error message:"
        self.assertRaisesRegex(
            FunctionNotExecuted,
            msg,
            ZohoFunctionsClient.execute_function,
            None,
            self.params,
        )
