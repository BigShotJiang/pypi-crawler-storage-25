import unittest
from mock import patch

from zoho_somconnexio_python_client.functions.activate_deal_from_odoo import (
    ActivateZohoDealFromOdoo,
)


class ActivateZohoDealFromOdooTestCase(unittest.TestCase):

    @patch(
        "zoho_somconnexio_python_client.functions.activate_deal_from_odoo.ZohoFunctionsClient.execute_function",  # noqa
        return_value={"code": "success", "details": {"output": "OK"}},
    )
    def test_ok(self, mock_execute_function):
        response = ActivateZohoDealFromOdoo.activate_deal("1234")

        self.assertTrue(response)
        mock_execute_function.assert_called_once_with(
            "activat_from_odoo",
            {
                "lead_id": "1234",
            },
        )

    @patch(
        "zoho_somconnexio_python_client.functions.activate_deal_from_odoo.ZohoFunctionsClient.execute_function",  # noqa
        return_value={"code": "error", "details": {"output": "Error"}},
    )
    def test_ko(self, mock_execute_function):
        response = ActivateZohoDealFromOdoo.activate_deal("9988")

        self.assertFalse(response)
        mock_execute_function.assert_called_once_with(
            "activat_from_odoo",
            {
                "lead_id": "9988",
            },
        )
