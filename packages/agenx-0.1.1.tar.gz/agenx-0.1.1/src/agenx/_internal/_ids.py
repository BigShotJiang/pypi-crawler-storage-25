"""
Trace and span ID generation

- trace_id : 128-bit (32 hex chars) 
- span_id  : 64-bit  (16 hex chars) 
"""

from __future__ import annotations

import secrets

def make_trace_id() -> str:
    """Generate a 128-bit cryptographically random trace ID as a 32-char hex string."""
    return secrets.token_hex(16)


def make_span_id() -> str:
    """Generate a 64-bit cryptographically random span ID as a 16-char hex string."""
    return secrets.token_hex(8)