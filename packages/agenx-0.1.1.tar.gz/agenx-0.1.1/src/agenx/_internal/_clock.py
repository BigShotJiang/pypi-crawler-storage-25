"""
Monotonic + wall-clock timestamps

- wall_ns  : human-readable time 
- mono_ns  : for duration math 
"""

from __future__ import annotations

from dataclasses import dataclass
import time
import datetime

@dataclass(frozen=True)
class Timestamp:
    wall_ns: int      
    mono_ns: int     

def now() -> Timestamp:
    return Timestamp(wall_ns=time.time_ns(), mono_ns=time.monotonic_ns())

def duration_ms(start: Timestamp, end: Timestamp) -> float:
    return (end.mono_ns - start.mono_ns) / 1_000_000

def wall_ns_to_iso(wall_ns: int) -> str:
    dt = datetime.datetime.fromtimestamp(wall_ns / 1_000_000_000, tz=datetime.timezone.utc)
    return dt.isoformat()