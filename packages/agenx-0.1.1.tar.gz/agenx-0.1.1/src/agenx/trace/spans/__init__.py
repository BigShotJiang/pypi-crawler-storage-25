from agenx.trace.spans.models import (
    Span,
    SpanEvent,
    SpanType,
    SpanStatus
)