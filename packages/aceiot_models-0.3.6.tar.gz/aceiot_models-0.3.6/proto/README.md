# Shared Proto Contracts

Canonical source for cross-repo wire contracts used by Aerodrome,
ace-ng-edge, and future SDKs. Published to the Buf Schema Registry
at [`buf.build/ace-iot-solutions/aceiot`](https://buf.build/ace-iot-solutions/aceiot).

See `../docs/plans/edge-control-plane-alignment.md` in the Aerodrome
repo (Phase 1a) for the overall design.

## Layout

| Path | Contents |
|------|----------|
| `aerodrome/v1/*.proto` | Existing Aerodrome contracts: timeseries, graph events, alerts, NATS subject conventions. Package name stays `aerodrome.v1` for Phase 1a to minimize namespace churn. |

## Workflow

1. Edit a `.proto` under `proto/`.
2. `cd proto && buf lint` — catches naming/package-path issues before push.
3. `cd proto && buf breaking --against 'buf.build/ace-iot-solutions/aceiot'` — verify the change is backwards-compatible.
4. `cd proto && buf push` — publishes a new commit to BSR.
5. Bump consumer pins in Aerodrome / ace-ng-edge to the new commit.

## Lint exclusions

- `PACKAGE_DIRECTORY_MATCH` — `aerodrome.v1` package is under `./aerodrome/v1/`, not `./` (Phase 1a keeps existing names).
- `ENUM_VALUE_PREFIX` — legacy `NatsStream` enum values aren't prefixed; renaming would break Rust callers.

Both exclusions are scoped to Phase 1a and should be re-evaluated when consumers migrate off the legacy names.
