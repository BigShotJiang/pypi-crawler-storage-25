"""nab-resolver: stub release 0.0.1a0."""

__version__ = "0.0.1a0"
