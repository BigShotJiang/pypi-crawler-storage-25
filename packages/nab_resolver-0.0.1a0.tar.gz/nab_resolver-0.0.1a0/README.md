# nab-resolver

Generic PubGrub dependency resolver, parameterised over a
`ResolverProvider` protocol.  No Python-specific knowledge: this
package is a SAT-style solver core.  The Python provider lives in
[`nab-python`](https://pypi.org/project/nab-python/) and the
user-facing CLI in [`nab`](https://pypi.org/project/nab/).

## What is included

- Unit propagation with a cached decision-level lookup.
- Conflict-driven clause learning with non-chronological backjumping.
- Optimistic backjumping under culprit-count thresholds.
- Targeted backtracking that demotes the suspected culprit's priority.
- Dependency-clause merging across siblings of the same parent.
- A `Range` reference type and a `RangeProtocol` extension point so
  callers can plug in a domain-specific version-set algebra.

## When to use it

Pick `nab-resolver` if you are building a resolver for some
non-Python ecosystem and want a PubGrub core with a small surface
area.  For Python package resolution use the higher levels of the
stack instead.

## Status

Pre-1.0.  The public API is the `Resolver` class plus the
`ResolverProvider` protocol, the `Range` and `Term` types, and the
`ResolutionError` exception.  Everything else is internal.

## License

MIT.  See `LICENSE` in the workspace root.
