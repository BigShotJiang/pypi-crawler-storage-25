# -*- coding: utf-8 -*-
"""ADMM 算法库"""

import os
import sys
from pathlib import Path

package_dir = Path(__file__).parent

lib_dir = package_dir / "lib"
include_dir = package_dir / "include"

__all__ = ["lib_dir", "include_dir"]
