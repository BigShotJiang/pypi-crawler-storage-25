import jsonschema
import logging
from .ToolSchema import ToolSchema

class SchemaValidator:
  _logger = logging.getLogger('airflow.task')

  @classmethod
  def validate_tool_input(cls, instance: any, tool_name: str) -> None:
    schema: dict | None = ToolSchema.get_input_schema(tool_name)
    cls.validate(instance, schema)

  @classmethod
  def validate(cls, instance: any, schema: dict) -> None:
    stat, message = SchemaValidator.validate_schema(schema)
    if not stat:
      raise ValueError('Invalid JSON schema: ' + message)
    title: str = schema.get('title') or schema.get('description') or ''
    try:
      jsonschema.validate(instance, schema)
    except jsonschema.exceptions.ValidationError as e:
      message: str = cls._get_message(title, e)
      raise ValueError('Validation error: ' + message)
    except Exception as e:
      raise ValueError('Unknown error: ' + str(e))

  @classmethod
  def _get_message(cls, title: str, validation_error):
    path = '/'.join(map(str, validation_error.path))
    at = ' at ' + path if path else ''
    title = f'[{title}] ' if title else ''
    return f"{title}{validation_error.message}{at}"

  @classmethod
  def validate_schema(cls, schema) -> tuple[bool, str]:
    try:
      jsonschema.validators.validator_for(schema).check_schema(schema)
      return True, ''
    except Exception as e:
      return False, str(e)
