from blues_lib.utils.resource import ResourceReader


class ToolSchema:

  _URI_DICT = {
    'tool': 'definition://common/common_tool_opts',
    'click': 'definition://ability/atom/click',
    'dbclick': 'definition://ability/atom/dbclick',
    'get_text': 'definition://ability/atom/get_text',
    "standard_llm_request": "definition://ability/atom/standard_llm_request",
    'json_llm_request': 'definition://ability/atom/json_llm_request',
    'cast_single': 'definition://ability/seq/cast_single',
    'cast_loop': 'definition://ability/seq/cast_loop',
    'cast_page': 'definition://ability/seq/cast_page',
    'xcom_mapping': 'definition://task/xcom_mapping',
    'task': 'definition://task/task',
  }

  @classmethod
  def get_uris(cls) -> dict[str, str]:
    return cls._URI_DICT

  @classmethod
  def get_uri(cls, tool_name: str) -> str:
    return cls._URI_DICT[tool_name] if cls.exists(tool_name) else ''

  @classmethod
  def exists(cls, tool_name: str) -> bool:
    return tool_name in cls._URI_DICT

  @classmethod
  def get(cls, tool_name: str) -> dict | None:
    uri = cls.get_uri(tool_name)
    return ResourceReader.load(uri) if uri else None

  @classmethod
  def get_input_schema(cls, tool_name: str) -> dict | None:
    definition = cls.get(tool_name)
    if not definition:
      return cls.get('tool')
    if 'input_schema' in definition:
      return definition['input_schema']
    else:
      return definition

  @classmethod
  def list(cls) -> list[dict]:
    defs: list[dict] = []
    for tool_name in cls._URI_DICT:
      definition: dict | None = cls.get(tool_name)
      if definition:
        defs.append(definition)
    return defs
