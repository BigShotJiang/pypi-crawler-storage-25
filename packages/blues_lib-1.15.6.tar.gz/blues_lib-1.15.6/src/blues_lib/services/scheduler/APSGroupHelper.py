import os
import sys
import subprocess
import tempfile
import json
from blues_lib.types import APSJob


class APSGroupHelper:
  '''APSGroup 的工具类'''

  @classmethod
  def get_terminal_command(cls, script_path: str, scheduler_name: str, os_type: str) -> str:
    '''
    根据操作系统返回对应的终端启动命令
    '''
    python_path = sys.executable

    if os_type == 'Windows':
      # Windows: 使用 cmd /k 保持终端打开，并设置标题
      return f'start "scheduler_{scheduler_name}" cmd /k "cd /d {os.path.dirname(script_path)} && {python_path} {os.path.basename(script_path)}"'

    elif os_type == 'Linux':
      # Linux: 优先使用 x-terminal-emulator
      for terminal in ['x-terminal-emulator', 'gnome-terminal', 'xterm']:
        if cls.is_command_available(terminal):
          if terminal == 'gnome-terminal':
            return f'{terminal} --title="scheduler_{scheduler_name}" -- bash -c "{python_path} \'{script_path}\'; exec bash"'
          elif terminal == 'xterm':
            return f'{terminal} -T "scheduler_{scheduler_name}" -e "{python_path} \'{script_path}\'"'
          else:
            return f'{terminal} -e "{python_path} \'{script_path}\'"'
      raise RuntimeError("Linux 系统未找到可用的终端程序")

    elif os_type == 'Darwin':
      # macOS: 使用 osascript + AppleScript
      script = f'''tell application "Terminal"
do script "{python_path} '{script_path}'; read -p \'Press Enter to exit...\'"
set custom title of front window to "scheduler_{scheduler_name}"
end tell'''
      return f"osascript -e '{script}'"

    else:
      raise RuntimeError(f"不支持的操作系统: {os_type}")

  @classmethod
  def is_command_available(cls, command: str, os_type: str) -> bool:
    '''
    检查命令是否可用
    '''
    try:
      check_cmd = ['which', command] if os_type != 'Windows' else ['where', command]
      subprocess.run(check_cmd, check=True, capture_output=True)
      return True
    except subprocess.CalledProcessError:
      return False

  @classmethod
  def create_startup_script(cls, scheduler_name: str, jobs: list[APSJob]) -> str:
    '''
    创建临时启动脚本
    '''
    # 使用 json 序列化 jobs，避免字符串转义问题
    jobs_json = json.dumps(jobs)
    # 添加 UTF-8 编码声明
    script_content = f'''# -*- coding: utf-8 -*-
#!/usr/bin/env python
import sys
import os
import json
import logging

# 配置 logging 输出到终端
logger = logging.getLogger('airflow.task')
logger.setLevel(logging.INFO)

# 移除所有已有的 handlers，避免重复输出
for handler in logger.handlers[:]:
    logger.removeHandler(handler)

# 添加新的 StreamHandler
ch = logging.StreamHandler(sys.stdout)
ch.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
logger.addHandler(ch)

# 导入 APS 调度器（pip 安装后自动在 sys.path 中）
from blues_lib.services.scheduler.APS import APS

if __name__ == "__main__":
    print("=" * 60)
    print(f"Scheduler: {scheduler_name}")
    print(f"Jobs: {len({jobs_json})} task(s)")
    for job in {jobs_json}:
        print(f"  - {{job.get('name', 'unnamed')}}: {{job.get('cron', {{}})}}")
    print("=" * 60)
    print()

    try:
        scheduler = APS(name="{scheduler_name}", jobs={jobs_json})
        scheduler.start()
    except Exception as e:
        print(f"Error: {{e}}")
        import traceback
        traceback.print_exc()
        input("Press Enter to exit...")
'''
    # 创建临时文件，使用 utf-8 编码
    with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
      f.write(script_content)
      temp_file = f.name

    # 设置可执行权限（Linux/macOS）
    if os.name != 'nt':
      os.chmod(temp_file, 0o755)

    return temp_file