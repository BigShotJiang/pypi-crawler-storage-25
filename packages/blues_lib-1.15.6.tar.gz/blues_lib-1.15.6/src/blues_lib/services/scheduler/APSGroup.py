import os
import subprocess
import platform
from blues_lib.types import APSJob
from .APSGroupHelper import APSGroupHelper


class APSGroup:
  '''
  调度器组 - 跨平台多终端启动多个 APS 实例

  使用方式：
  schedulers = [
      ('scheduler_name1', [job1, job2]),
      ('scheduler_name2', [job3])
  ]
  group = APSGroup(schedulers=schedulers)
  group.start()
  '''

  def __init__(self, schedulers: list[tuple[str, list[APSJob]]]):
    self._schedulers = schedulers
    self._processes = []
    self._temp_files = []
    self._os_type = platform.system()

  def start(self):
    '''
    启动所有调度器（每个调度器在独立终端中运行）
    '''
    for scheduler_name, jobs in self._schedulers:
      # 创建启动脚本
      script_path = APSGroupHelper.create_startup_script(scheduler_name, jobs)
      self._temp_files.append(script_path)

      # 获取终端命令
      terminal_cmd = APSGroupHelper.get_terminal_command(script_path, scheduler_name, self._os_type)
      print(f"启动命令: {terminal_cmd}")

      # 启动子进程
      try:
        process = subprocess.Popen(terminal_cmd, shell=True)
        self._processes.append(process)
        print(f"已启动调度器: {scheduler_name}")
      except Exception as e:
        print(f"启动调度器 {scheduler_name} 失败: {e}")

  def shutdown(self):
    '''
    关闭所有调度器进程
    '''
    for process in self._processes:
      try:
        process.terminate()
        process.wait()
      except Exception as e:
        print(f"关闭进程失败: {e}")

    # 清理临时文件
    for temp_file in self._temp_files:
      try:
        os.unlink(temp_file)
      except Exception as e:
        print(f"删除临时文件失败: {e}")

    self._processes.clear()
    self._temp_files.clear()