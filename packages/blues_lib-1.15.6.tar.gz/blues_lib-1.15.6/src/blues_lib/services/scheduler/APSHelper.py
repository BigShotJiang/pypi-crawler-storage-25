from blues_lib.types import APSJob, APSCron


class APSHelper:
  '''APS 调度器的工具类'''

  @classmethod
  def format_cron(cls, aps_cron: APSCron) -> str:
    '''格式化 cron 配置为字符串'''
    if aps_cron.get('cron'):
      return aps_cron['cron']

    parts = []
    if 'hour' in aps_cron:
      parts.append(f"hour={aps_cron['hour']}")
    if 'minute' in aps_cron:
      parts.append(f"minute={aps_cron['minute']}")
    if 'second' in aps_cron:
      parts.append(f"second={aps_cron['second']}")
    if 'day_of_week' in aps_cron:
      parts.append(f"day_of_week={aps_cron['day_of_week']}")

    if not parts:
      return 'second=0'

    return ', '.join(parts)

  @classmethod
  def get_job_details(cls, jobs: list[APSJob]) -> list[tuple[str, str]]:
    '''获取所有任务的详细信息 (name, cron)'''
    details = []
    for idx, job in enumerate(jobs):
      job_name = job.get('name', f'job-{idx}')
      cron_str = cls.format_cron(job['cron'])
      details.append((job_name, cron_str))
    return details

  @classmethod
  def format_jobs_list(cls, jobs: list[APSJob]) -> str:
    '''格式化任务列表为多行字符串'''
    details = cls.get_job_details(jobs)
    if not details:
      return '  (no jobs)'

    lines = []
    for job_name, cron_str in details:
      lines.append(f"  {job_name} : {cron_str}")
    return '\n' + '\n'.join(lines)

  @classmethod
  def get_job_name(cls, job: APSJob, index: int) -> str:
    '''获取任务名称，如果没有则自动生成'''
    return job.get('name', f'job-{index}')