import os
import subprocess
import signal
import logging
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from blues_lib.types import APSJob, APSExec, APSCron
from .APSHelper import APSHelper


class APS:

  def __init__(self, name: str, jobs: list[APSJob] | APSJob, block: bool = True):
    '''
    初始化调度器
    :param name: 调度器名称（必须）
    :param jobs: 任务列表或单个任务字典（必须）
    :param block: 是否阻塞主进程（默认True，保持调度器运行）
    '''
    self._name = name
    # 兼容单个任务字典，自动转换为列表
    self._jobs = [jobs] if isinstance(jobs, dict) else list(jobs)
    self._block = block
    self._scheduler: BackgroundScheduler | None = None
    self._running: bool = False
    self._started: bool = False
    self._logger = logging.getLogger('airflow.task')

  def start(self) -> list[int]:
    '''
    启动调度器（只能执行一次）
    :return: 任务ID列表
    :raises RuntimeError: 如果调度器已经启动且未关闭
    '''
    if self._started and self._scheduler and self._scheduler.running:
      raise RuntimeError("调度器已启动，请先调用 shutdown() 再创建新实例")

    self._scheduler = BackgroundScheduler(timezone='Asia/Shanghai', daemon=True)
    job_ids = self._add_jobs(self._jobs)

    self._register_signal_handlers()

    self._scheduler.start()
    self._started = True
    self._running = True
    self._logger.info(f"Scheduler '{self._name}' started with jobs:{APSHelper.format_jobs_list(self._jobs)}\nPress Ctrl+C to stop.")

    if self._block:
      import time
      while self._running:
        time.sleep(1)

    return job_ids

  def _add_jobs(self, jobs: list[APSJob]) -> list[int]:
    '''
    添加任务到调度器
    '''
    job_ids = []

    for idx, job in enumerate(jobs):
      job_name = APSHelper.get_job_name(job, idx)
      aps_exec = job['exec']
      aps_cron = job['cron']

      trigger = self._build_trigger(aps_cron)
      next_run_time = trigger.get_next_fire_time(None, datetime.now())
      runner = self._create_runner(aps_exec, job_name)

      added_job = self._scheduler.add_job(
        runner,
        trigger=trigger,
        id=job_name,
        name=job_name
      )
      job_ids.append(added_job.id)

      self._logger.info(f"Added job: {job_name}")
      if aps_exec.get('cwd'):
        self._logger.info(f"  cwd: {aps_exec['cwd']}")
      self._logger.info(f"  command: {aps_exec['command']}")
      self._logger.info(f"  next run: {next_run_time}")

    return job_ids

  def _build_trigger(self, aps_cron: APSCron) -> CronTrigger:
    '''
    根据cron配置构建触发器
    '''
    if aps_cron.get('cron'):
      return CronTrigger.from_crontab(aps_cron['cron'])

    return CronTrigger(
      hour=aps_cron.get('hour', '*'),
      minute=aps_cron.get('minute', '*'),
      second=aps_cron.get('second', 0),
      day_of_week=aps_cron.get('day_of_week', '*')
    )

  def _create_runner(self, aps_exec: APSExec, job_name: str):
    '''
    创建任务执行器
    '''
    cwd = aps_exec.get('cwd', os.getcwd())
    command = aps_exec['command']

    def runner():
      self._logger.info(f"Executing task '{job_name}' for scheduler '{self._name}':")
      if aps_exec.get('cwd'):
        self._logger.info(f"  cwd: {cwd}")
      self._logger.info(f"  command: {command}")

      subprocess.run(
        command,
        cwd=cwd,
        shell=True
      )

      self._logger.info(f"Scheduler '{self._name}' task '{job_name}' completed with jobs:{APSHelper.format_jobs_list(self._jobs)}")

    return runner

  def _register_signal_handlers(self):
    '''
    注册信号处理器以支持Ctrl+C关闭
    '''
    def shutdown_handler(signum, frame):
      signal_name = "Ctrl+C" if signum == signal.SIGINT else "SIGTERM"
      self._logger.info(f"\n手动关闭调度器 '{self._name}' with jobs:{APSHelper.format_jobs_list(self._jobs)}\n({signal_name})...")
      if self._scheduler:
        self._logger.info("正在等待任务完成...")
        self._scheduler.shutdown(wait=True)
      self._running = False
      self._logger.info(f"调度器 '{self._name}' with jobs:{APSHelper.format_jobs_list(self._jobs)} 已优雅关闭")

    signal.signal(signal.SIGINT, shutdown_handler)
    signal.signal(signal.SIGTERM, shutdown_handler)

  def shutdown(self):
    '''
    关闭调度器
    '''
    if self._scheduler:
      self._scheduler.shutdown(wait=True)
      self._scheduler = None