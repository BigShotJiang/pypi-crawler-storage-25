import os

from blues_lib.types import SQLSTDOut
from blues_lib.services.sql.db.MySQLDB import MySQLDB
from blues_lib.services.sql.db.SQLiteDB import SQLiteDB
from blues_lib.services.sql.convertor.MySQLConvertor import MySQLConvertor
from blues_lib.services.sql.convertor.SQLiteConvertor import SQLiteConvertor


class SQLExecutor:

  def __init__(self, account: dict = None):
    self._account = account or {}

    db_type = self._account.get('db_type') or os.environ.get('DB_TYPE', 'sqlite')
    self._db_type = db_type.lower()

    if self._db_type == 'mysql':
      self._convertor = MySQLConvertor()
      self.sql_executor = MySQLDB.get_instance(account)
    else:
      self._convertor = SQLiteConvertor()
      self.sql_executor = SQLiteDB.get_instance(account)

  @property
  def db_type(self) -> str:
    return self._db_type

  @property
  def convertor(self):
    return self._convertor

  def get(self, table: str, fields=None, conditions=None, orders=None, pagination=None) -> SQLSTDOut:
    condition_sql = self._convertor.get_condition_sql(conditions)
    order_sql = self._convertor.get_order_sql(orders)
    limit_sql = self._convertor.get_limit_sql(pagination)
    if isinstance(fields, list) or isinstance(fields, tuple):
      field_sql = ','.join(fields)
    else:
      field_sql = '*'

    sql = 'select %s from %s %s %s %s' % (field_sql, table, condition_sql, order_sql, limit_sql)
    return self.sql_executor.get(sql)

  def insert(self, table: str, entities: list[dict]) -> SQLSTDOut:
    insert_sql = self._convertor.get_insert_sql(entities)
    sql = 'insert into %s %s' % (table, insert_sql)
    return self.sql_executor.post(sql)

  def post(self, table: str, fields: list, values: list[list]) -> SQLSTDOut:
    insert_sql = self._convertor.get_insert_template_sql(fields)
    sql = 'insert into %s %s' % (table, insert_sql)
    return self.sql_executor.post(sql, values)

  def put(self, table: str, fields: list, values: list, conditions: list[dict]) -> SQLSTDOut:
    update_sql = self._convertor.get_update_template_sql(fields, conditions)
    sql = 'update %s %s' % (table, update_sql)
    return self.sql_executor.put(sql, values)

  def update(self, table: str, entity: dict, conditions: list[dict]) -> SQLSTDOut:
    update_sql = self._convertor.get_update_sql(entity, conditions)
    sql = 'update %s %s' % (table, update_sql)
    return self.sql_executor.put(sql)

  def delete(self, table: str, conditions: list[dict]) -> SQLSTDOut:
    condition_sql = self._convertor.get_condition_sql(conditions)
    sql = 'delete from %s %s' % (table, condition_sql)
    return self.sql_executor.delete(sql)
