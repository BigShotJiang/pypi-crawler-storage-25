from blues_lib.services.dpp.processors.BaseProcessor import BaseProcessor
from blues_lib.services.dpp.db.FlushHelper import FlushHelper
from blues_lib.types import SQLSTDOut

class TableInserter(BaseProcessor):
  """
  最终写入数据库的处理器。
  只处理 request['entities'] 中的 valid 数据。
  配置项 persist: 数据库映射配置
  返回值: 写入成功返回 True，否则返回 False
  """

  _RULE_KEY = 'persist'

  def _process(self, entities: list[dict], config: dict) -> tuple[list, list]:
    return entities, []

  def _post_process(self, valid_entities: list, invalid_entities: list, config: dict) -> bool:
    result: SQLSTDOut = FlushHelper.flush(valid_entities, 'valid', config) 
    if result.code != 200:
      self._logger.warning(f'flush {len(valid_entities)} valid entity(ies) failed, error: {result.message}')
    
    return result.code == 200
