import re


class FieldSelectorHelper:
  """
  Helper class for filtering and mapping entity fields.
  Supports include/exclude by field names or regex patterns, and field mapping.
  """

  @classmethod
  def process(cls, entities: list[dict], config: dict) -> list[dict]:
    """
    处理实体：根据配置筛选和映射字段

    参数:
      entities: 实体列表
      config: 配置，包含:
        - inc_fields: 包含的字段列表
        - exc_fields: 排除的字段列表
        - inc_pattern: 包含字段的正则模式
        - exc_pattern: 排除字段的正则模式
        - mapping: 字段映射字典 {原始字段名: 数据库字段名}

    返回:
      处理后的实体列表（原地修改）
    """
    if not entities:
      return entities

    inc_fields = config.get('inc_fields', [])
    exc_fields = config.get('exc_fields', [])
    inc_pattern = config.get('inc_pattern', '')
    exc_pattern = config.get('exc_pattern', '')
    mapping = config.get('mapping', {})

    if mapping:
      cls._expand_fields_by_mapping(entities, mapping)
      if not inc_fields:
        inc_fields = list(mapping.values())
        config['inc_fields'] = inc_fields

    if inc_fields:
      return cls._include_fields(entities, inc_fields)
    elif inc_pattern:
      return cls._filter_by_pattern(entities, inc_pattern, include=True)
    elif exc_fields:
      return cls._exclude_fields(entities, exc_fields)
    elif exc_pattern:
      return cls._filter_by_pattern(entities, exc_pattern, include=False)

    return entities

  @classmethod
  def _expand_fields_by_mapping(cls, entities: list[dict], mapping: dict) -> None:
    """根据 mapping 扩展实体字段：原始字段名 → 数据库字段名（就地修改）"""
    for e in entities:
      for original_key, db_key in mapping.items():
        if original_key in e and db_key not in e:
          e[db_key] = e[original_key]

  @classmethod
  def _include_fields(cls, entities: list[dict], fields: list[str]) -> list[dict]:
    return [{k: v for k, v in e.items() if k in fields} for e in entities]

  @classmethod
  def _exclude_fields(cls, entities: list[dict], fields: list[str]) -> list[dict]:
    return [{k: v for k, v in e.items() if k not in fields} for e in entities]

  @classmethod
  def _filter_by_pattern(cls, entities: list[dict], pattern: str, include: bool) -> list[dict]:
    if include:
      return [{k: v for k, v in e.items() if re.match(pattern, k)} for e in entities]
    else:
      return [{k: v for k, v in e.items() if not re.match(pattern, k)} for e in entities]
