from blues_lib.services.dpp.db.FlushHelper import FlushHelper
from blues_lib.services.dpp.db.FieldSelectorHelper import FieldSelectorHelper


def __getattr__(name):
  if name == 'TableInserter':
    from blues_lib.services.dpp.db.TableInserter import TableInserter
    globals()['TableInserter'] = TableInserter
    return TableInserter
  raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ['FlushHelper', 'FieldSelectorHelper', 'TableInserter']
