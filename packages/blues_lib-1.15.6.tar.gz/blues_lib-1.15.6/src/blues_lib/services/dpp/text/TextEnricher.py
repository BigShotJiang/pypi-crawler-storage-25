import pandas as pd
from blues_lib.services.dpp.processors.TextProcessor import TextProcessor
from blues_lib.utils.convert import Algorithm
from blues_lib.utils.url import URLManager


class TextEnricher(TextProcessor):
  """
  补全text字段。
  """

  def _process_df(self, df: pd.DataFrame, config: dict) -> pd.DataFrame:
    if 'url' in df.columns:
      df['site'] = df['url'].apply(lambda x: URLManager.get_domain(x) if x else '')

    if 'paras' in df.columns:
      df['thumb'] = df['paras'].apply(self._get_thumb_from_paras)

    if 'paras' in df.columns and 'thumb' in df.columns:
      df['paras'] = df.apply(lambda row: self._insert_thumb_to_paras(row['paras'], row.get('thumb', '')), axis=1)

    return df

  def _get_thumb_from_paras(self, paras: list[dict]) -> str:
    if not paras:
      return ''
    for p in paras:
      if p.get('type') == 'image' and p.get('value'):
        return p['value']
    return ''

  def _insert_thumb_to_paras(self, paras: list[dict], thumb: str) -> list[dict]:
    if not paras or not thumb:
      return paras
    has_image = any(p.get('type') == 'image' and p.get('value') for p in paras)
    if not has_image:
      paras.insert(0, {'type': 'image', 'value': thumb})
    return paras
