# DPP (Data Preprocessing Pipeline) 职责链设计

基于技术栈分类的数据预处理职责链，重新设计以充分利用各技术优势。

## 设计理念

按技术栈将处理器分为三大类：
- **文本处理**: 使用 Pandas 进行向量化数据操作
- **图片处理**: 使用 Pillow 进行图像操作
- **数据库处理**: 保留现有 SQL 操作类

## 架构概览

```
DPPChain (Chain)
├── processors/
│   ├── Deduplicator       (去重检查)
│   ├── TextProcessor (文本处理 - Pandas)
│   │   ├── TextValidator      (文本校验)
│   │   ├── TextNormalizer     (文本归一化/截断)
│   │   └── TextEnricher      (字段生成/补充)
│   └── ImageProcessor (图片处理 - Pillow)
│       └── ImageValidator     (图片校验+下载+调整)
└── db/
    ├── TableInserter       (持久化写入)
    └── FlushHelper         (公共写入辅助)
```

---

## 技术分类详解

### 1. Deduplicator (去重处理器)

**功能**: 检查数据库中是否已存在记录，从 entities 中移除重复项。

**配置项 unique**:
- `key`: entity 属性名（必填）
- `field`: 数据库字段名（可选，默认取 key 的值）
- `comparator`: 比较符号（可选，默认 =）

---

### 2. TextProcessor (文本处理 - Pandas)

#### 2.1 TextValidator

**功能**: 使用 Pandas 向量化操作校验文本数据。

**可实现校验**:
- URL 格式校验
- 文本长度校验
- 文本模式匹配（正则表达式）

---

#### 2.2 TextNormalizer

**功能**: 使用 Pandas 对文本进行归一化处理。

**可实现功能**:
- 文本按长度截断
- 文本数量限制
- 空值处理

---

#### 2.3 TextEnricher

**功能**: 使用 Pandas 生成/补充字段。

**可实现功能**:
- 补全 thumb 字段（从 paras 取第一张图）

---

### 3. ImageProcessor (图片处理 - Pillow)

#### 3.1 ImageValidator

**功能**: 集成图片验证、下载、尺寸调整的全功能处理器。

**功能说明**:
- 自动检测在线图片 URL 并下载到本地
- 使用 Pillow 验证图片尺寸和格式
- 超出尺寸的图片自动调整大小
- 支持有效图片数量限制，多余的图片自动移除

---

### 4. db/ (数据库处理)

#### 4.1 TableInserter

**功能**: 最终写入数据库的处理器。

**说明**:
- 只处理 request['entities'] 中的数据
- 自动添加 stat='valid' 状态
- 根据 insert 配置进行字段映射

#### 4.2 FlushHelper

**功能**: 公共写入辅助方法。

**说明**:
- 统一处理 records 的 stat 状态添加和字段映射
- 被 BaseProcessor 和 TableInserter 共用

---

## 统一处理流程 (BaseProcessor)

所有处理器都继承自 BaseProcessor，拥有统一的处理流程：

### 处理步骤

```
1. 获取 request['entities']
   ↓
2. 判断 entities 是否为空
   ↓
3. 获取配置 (._get_config)
   ↓
4. 处理数据 (._process)
   - 根据配置执行具体处理逻辑
   - 返回 (valid_entities, invalid_entities)
   ↓
5. 调用 FlushHelper.flush 写入 invalid 数据
   ↓
6. 更新 request['entities'] = valid_entities
   ↓
7. 返回结果 (True)
```

### 数据流转

```
输入 Request
├── entities: [实体列表]
└── rule: {配置规则}

处理中
├── valid_entities: 继续流转
└── invalid_entities: 立即写入数据库 (stat='invalid')

输出 Request
├── entities: [有效实体列表]
└── _message: [处理结果消息]
```

---

## 完整职责链流程 (DPPChain)

### 示例配置

```python
rule = {
    "unique": {"key": "url", "field": "mat_url"},
    "text": {
        "url": {},
        "title": {
            "min_length": 5,
            "max_length": 100
        },
        "paras": {
            "min_length": 50,
            "max_length": 1000
        }
    },
    "image": {
        "min_length": 0,
        "max_length": 5,
        "min_width": 100,
        "max_width": 4000,
        "min_height": 100,
        "max_height": 4000
    },
    "insert": {
        "mapping": {
            "id": "mat_id",
            "url": "mat_url"
        }
    }
}
```

### 处理链顺序

```
1. Deduplicator (去重)
   - 检查数据库是否已存在
   ↓
2. TextValidator (文本校验)
   - 校验 url, title, paras
   - 标记无效实体
   ↓
3. TextNormalizer (文本归一化)
   - 截断超长文本
   ↓
4. TextEnricher (文本补全)
   - 补全 thumb 字段
   ↓
5. ImageValidator (图片处理)
   - 验证图片有效性
   - 下载在线图片
   - 调整图片尺寸
   ↓
6. TableInserter (写入数据库)
   - 持久化 valid 数据
```

---

## 类设计

```
dpp/
├── __init__.py
├── DPPChain.py              # 总链入口
├── processors/              # 处理器
│   ├── __init__.py
│   ├── BaseProcessor.py     # 统一基类
│   ├── TextProcessor.py     # 文本处理器基类
│   ├── ImageProcessor.py    # 图片处理器基类
│   ├── Deduplicator.py      # 去重检查
│   ├── TextValidator.py     # 文本校验
│   ├── TextNormalizer.py    # 文本归一化
│   ├── TextEnricher.py      # 字段生成
│   └── ImageValidator.py    # 图片校验+下载+调整
└── db/                      # 数据库处理
    ├── __init__.py
    ├── TableInserter.py     # 持久化写入
    ├── FlushHelper.py       # 公共写入辅助
    └── FieldSelectorHelper.py # 字段映射辅助
```

---

## 优势

1. **职责分离**: 每个处理器只关注单一职责
2. **统一基类**: BaseProcessor 提供统一的处理流程
3. **链式调用**: 处理器通过链式调用自动流转
4. **即时处理**: invalid 数据立即写入数据库，不继续流转
5. **灵活配置**: 通过 rule 配置控制启用哪些处理器
6. **可测试性**: 每个处理器可独立单元测试
