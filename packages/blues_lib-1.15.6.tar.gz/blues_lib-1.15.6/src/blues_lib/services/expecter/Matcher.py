from blues_lib.types import ToolExpect, SkipLoopWarning, SkipLoopError, SkipSeqError, BlockSeqError
from blues_lib.services.expecter import Expecter
from blues_lib.tools.context import TaskContext

class Matcher:

  _EXCEPTIONS = {
    SkipLoopWarning.__name__:SkipLoopWarning,
    SkipLoopError.__name__:SkipLoopError,
    SkipSeqError.__name__:SkipSeqError,
    BlockSeqError.__name__:BlockSeqError,
  }
  
  def __init__(self,context:TaskContext):
    self._context = context

  def match(self,opts:ToolExpect)->None:
    method:str = opts.setdefault('method','to_be')
    exception:str = opts.setdefault('exception','SkipLoopError')

    value:any = opts.get('value') 
    result:any = opts.get('result')
    message:str = opts.get('message') or f"expect {method} {value}, but got {result}"
    message = f"{exception} : {message}"

    matcher = getattr(Expecter, method, None)
    if not matcher:
      message = f"Invalid expect method: {method}"
      raise ValueError(message)

    if not matcher(opts):
      if not exception in self._EXCEPTIONS.keys():
        raise ValueError(f"Invalid expect exception: {exception}")

      exception_class = self._EXCEPTIONS.get(exception)
      raise exception_class(message)
    