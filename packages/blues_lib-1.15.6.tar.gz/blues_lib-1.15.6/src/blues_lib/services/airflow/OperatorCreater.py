import logging
from datetime import timedelta
from blues_lib.types import ToolDef, AbilityExecError, BlockSeqError
from blues_lib.tools.context import TaskContext
from blues_lib.tools.runner import AbilityFacade

class OperatorCreater:
  
  def __init__(self,ctx_meta:dict,meta:dict,operator_class) -> None:
    self._meta = meta
    self._context = TaskContext(ctx_meta)
    self._operator_class = operator_class
    self._logger = logging.getLogger('airflow.task')
    
  def get_operators(self)->list[any]:
    options = self._meta.get('options')
    tools:list[ToolDef] = options.get('tools',[])
    operators = []

    for idx,sub_meta in enumerate(tools):
      options:dict = sub_meta.get('options') or {}

      task_id = self._context.get_meta_id(sub_meta)
      retries = int(options.get('retries',0))
      delay_seconds = int(options.get('retry_delay',0)) # seconds
      retry_delay = timedelta(seconds=delay_seconds) if delay_seconds else None
      is_last:bool = idx == len(tools)-1

      operator = self._operator_class(
        task_id=task_id,
        retries=retries,
        retry_delay=retry_delay,
        op_args=[sub_meta,is_last],
        python_callable=self._callback,
      )
      operators.append(operator)
    return operators
  
  def _callback(self,meta:dict,is_last:bool):
    name:str = meta.get('name')
    description:str = meta.get('description')
    options = meta.get('options')
    try:
      facade = AbilityFacade(self._context)
      result:dict =  facade.execute(name,options)

      id:str = self._context.get_meta_id(meta)
      self._context.add_result(id,result)

      self._context.add_stat(True,name,description)

      if is_last:
        self._context.teardown()

      self._logger.info(result)
        
    except (AbilityExecError,BlockSeqError,Exception) as e:
      self._context.add_stat(False,name,description,str(e))
      self._context.teardown()
      # break the airflow dag
      raise e
