class PythonOperator:
  def __init__(self,**kwargs):
    self._kwargs = kwargs

  def execute(self):
    op_args:list[any] = self._kwargs.get('op_args',[])
    callback:callable = self._kwargs.get('python_callable')
    callback(*op_args)