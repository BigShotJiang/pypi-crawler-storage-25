from blues_lib.services.llm import StandardLLMClient
from blues_lib.types import LLMSTDReqOpts

class JSONLLMClient(StandardLLMClient):

  def __init__(self,std_opts:LLMSTDReqOpts) -> None:
    std_opts['to_json'] = True
    super().__init__(std_opts)
    self._set_response_format()
    
  def _set_response_format(self):
    if self._payload.get('response_format'):
      self._payload['response_format']['type'] = 'json_object'
    