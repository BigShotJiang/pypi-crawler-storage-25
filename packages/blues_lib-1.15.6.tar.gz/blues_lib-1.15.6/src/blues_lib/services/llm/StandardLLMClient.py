import json
from blues_lib.types import LLMMessage,LLMSTDReqOpts,LLMBaseReqOpts
from blues_lib.services.llm import BaseLLMClient

class StandardLLMClient(BaseLLMClient):
  
  def __init__(self,std_opts:LLMSTDReqOpts) -> None:
    base_opts:LLMBaseReqOpts = self._get_base_opts(std_opts)
    super().__init__(base_opts)
    
  def request(self,user_content:str|None=None,system_content:str|None=None)->any:
    messages:list[LLMMessage] = self._get_messages(user_content,system_content)
    return super().request(messages)
    
  def _get_base_opts(self,std_opts:LLMSTDReqOpts)->LLMBaseReqOpts:
    url:str = std_opts.get('url','')
    api_key:str = std_opts.get('api_key','')
    
    payload:dict = self._get_payload(std_opts)
    headers:dict = {
      'Authorization': f'Bearer {api_key}',
    } if api_key else {}

    base_opts:LLMBaseReqOpts = {}
    if url:
      base_opts['url'] = url
    if payload:
      base_opts['payload'] = payload
    if headers:
      base_opts['headers'] = headers
    return {**std_opts,**base_opts}

  def _get_payload(self,std_opts:LLMSTDReqOpts) -> dict:
    model:str = std_opts.get('model','')
    system_content:str = std_opts.get('system_content','')
    user_content:str = str(std_opts.get('user_content','')) # 避免传入json对象

    payload:dict = {}
    if model:
      payload['model'] = model
    
    messages:list[LLMMessage] = self._get_messages(user_content,system_content)
    if messages:
      payload['messages'] = messages
    
    return payload

  def _get_messages(self,user_content:str|None=None,system_content:str|None=None)->list[LLMMessage]:
    max_prompt_length:int = -1
    if getattr(self,'_std_opts',None):
      max_prompt_length = int(self._std_opts.get('max_prompt_length',-1))

    messages:list[LLMMessage] = []
    if system_content:
      messages.append({
        "role": "system",
        "content": system_content,
      })
    if user_content:
      if max_prompt_length > 0 and len(user_content) > max_prompt_length:
        user_content = user_content[:max_prompt_length]
      messages.append({
        "role": "user",
        "content": user_content,
      })
    return messages