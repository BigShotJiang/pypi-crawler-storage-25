from typing import TypeAlias, TypedDict, Literal

__all__ = [
  "EmailPara",
  "EmailTpl",
  "EmailOpts",
  "DingMsgType",
  "DingOpts",
]

EmailPara: TypeAlias = TypedDict("EmailPara", {
  "type": Literal["text", "image", "link", "remark"],
  "value": str,
})

EmailTpl: TypeAlias = Literal["default", "publish"]

EmailOpts: TypeAlias = TypedDict("EmailOpts", {
  "template": EmailTpl,
  "addressee": list[str] | str,
  "addressee_name": str,
  "subject": str,
  "paras": list[EmailPara],
})

DingMsgType: TypeAlias = Literal["text", "markdown", "link", "actioncard", "feedcard"]

DingOpts: TypeAlias = TypedDict("DingOpts", {
  "msgtype": DingMsgType,
  "title": str,
  "text": str,
  "message_url": str,
  "pic_url": str,
  "content": str,
  "is_at_all": bool,
})
