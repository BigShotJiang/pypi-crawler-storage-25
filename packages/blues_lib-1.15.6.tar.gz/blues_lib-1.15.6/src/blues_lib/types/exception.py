class AbilityExecError(Exception):
  def __init__(self, message="Ability execution exception"):
    super().__init__(message)


class SkipLoopWarning(Exception):
  def __init__(self, message="Skip the loop, but don't execute the skip loop tools"):
    super().__init__(message)


class SkipLoopError(Exception):
  def __init__(self, message="Skip the loop"):
    super().__init__(message)


class SkipSeqError(Exception):
  def __init__(self, message="Skip the sequence"):
    super().__init__(message)


class BlockSeqError(Exception):
  def __init__(self, message="Block seq error"):
    super().__init__(message)


__all__ = [
  'AbilityExecError',
  'SkipLoopWarning',
  'SkipLoopError',
  'SkipSeqError',
  'BlockSeqError',
]