from typing import TypeAlias, TypedDict

__all__ = [
  "APSCron",
  "APSExec",
  "APSJob",
]

APSCron: TypeAlias = TypedDict("APSCron", {
  "year": int | str,
  "month": int | str,
  "day": int | str,
  "week": int | str,
  "day_of_week": int | str,
  "hour": int | str,
  "minute": int | str,
  "second": int | str,
  "start_date": str,
  "end_date": str,
  "timezone": str,
  "jitter": int | float,
  "cron": str,
})

APSExec: TypeAlias = TypedDict("APSExec", {
  "cwd": str,
  "command": str,
})

APSJob: TypeAlias = TypedDict("APSJob", {
  "name": str,
  "exec": APSExec,
  "cron": APSCron,
})
