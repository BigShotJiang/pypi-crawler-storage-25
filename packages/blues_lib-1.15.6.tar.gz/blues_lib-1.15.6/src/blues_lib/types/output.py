from dataclasses import dataclass, asdict


@dataclass
class STDOut:
  code: int = 200
  message: str = 'success'
  data: any = None
  trash: any = None
  detail: any = None

  def to_dict(self) -> dict:
    return asdict(self)

  def to_status(self) -> tuple:
    return (self.code, self.message)


@dataclass
class SQLSTDOut(STDOut):
  count: int = 0
  sql: str = ''
  lastid: any = None


__all__ = [
  'STDOut',
  'SQLSTDOut',
]
