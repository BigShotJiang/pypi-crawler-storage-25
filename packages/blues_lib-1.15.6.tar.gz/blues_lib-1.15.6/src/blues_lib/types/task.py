from typing import TypedDict, Any

__all__ = [
  "TaskResponse",
]


class TaskResponse(TypedDict):
  code: int
  data: Any | None
  message: str
  detail: Any | None
