from typing import TypeAlias, TypedDict
from blues_lib.types import AttemptDelay, ToolDef

__all__ = [
  "AttemptBy",
  "ToolSummary",
  "SeqOpts",
]

AttemptBy: TypeAlias = int | str | list[dict] | list[str]

ToolSummary: TypeAlias = TypedDict("ToolSummary", {
  "attempt_by": AttemptBy,
  "attempts": int,
  "attempt_delay": AttemptDelay,
  "prev_tools": list[ToolDef],
  "post_tools": list[ToolDef],
})

SeqOpts: TypeAlias = TypedDict("SeqOpts", {
  "single": ToolSummary,
  "loop": ToolSummary,
  "page": ToolSummary,
  "combo": ToolSummary,
  "tools": list[ToolDef] | dict[str, ToolDef],
})
