from typing import TypeAlias, Literal

__all__ = [
  "VariableLevel",
]

VariableLevel: TypeAlias = Literal[
  "global",
  "task",
  "loop",
  "hook",
  "atom",
]
