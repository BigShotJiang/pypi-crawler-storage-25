from typing import TypeAlias, TypedDict, Any, Literal
from selenium.webdriver.remote.webdriver import WebDriver

__all__ = [
  "DriverStartupOpts",
  "DriverMode",
  "DriverLocOpts",
  "LoginMode",
  "DriverOpts",
  "NotifyOpts",
  "ContextDef",
]

DriverStartupOpts: TypeAlias = TypedDict("DriverStartupOpts", {
  "features": list[str],
  "caps": dict[str, Any],
  "arguments": list[str],
  "exp_options": dict[str, Any],
  "extensions": list[str],
  "cdp_cmds": dict[str, Any],
})

DriverMode: TypeAlias = Literal["remote", "chrome", "cft", "udc", "udcft", "context"]

DriverLocOpts: TypeAlias = TypedDict("DriverLocOpts", {
  "command_executor": str,
  "executable_path": str,
  "binary_location": str,
})

LoginMode: TypeAlias = Literal["account", "sms", "qrcode"]


class DriverOpts(TypedDict, total=False):
  mode: DriverMode
  startup: DriverStartupOpts
  location: DriverLocOpts


class NotifyOpts(TypedDict, total=False):
  mode: Literal["none", "ding","email"]


class ContextDef(TypedDict, total=False):
  driver: WebDriver | bool | DriverOpts
  notify: NotifyOpts
