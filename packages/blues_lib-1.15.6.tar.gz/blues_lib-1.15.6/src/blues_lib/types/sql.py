from typing import TypeAlias, TypedDict, Any

__all__ = [
  "SQLPagination",
  "SQLCondition",
  "SQLOrder",
  "SQLFilter",
  "SQLOpts",
]

SQLPagination: TypeAlias = TypedDict("SQLPagination", {
  "no": int,
  "size": int,
})

SQLCondition: TypeAlias = TypedDict("SQLCondition", {
  "operator": str,
  "field": str,
  "comparator": str,
  "value": str | int | float | bool | None,
  "value_type": str,
})

SQLOrder: TypeAlias = TypedDict("SQLOrder", {
  "field": str,
  "sort": str,
})

SQLFilter: TypeAlias = TypedDict("SQLFilter", {
  "inc_fields": list[str],
  "inc_pattern": str,
  "dec_fields": list[str],
  "dec_pattern": str,
})

SQLOpts: TypeAlias = TypedDict("SQLOpts", {
  "table": str,
  "conditions": list[SQLCondition],
  "entity": dict[str, Any],
  "entities": list[dict[str, Any]],
  "filter": SQLFilter,
  "constants": dict[str, Any],
  "orders": list[SQLOrder],
  "fields": list[str],
  "page": SQLPagination,
})
