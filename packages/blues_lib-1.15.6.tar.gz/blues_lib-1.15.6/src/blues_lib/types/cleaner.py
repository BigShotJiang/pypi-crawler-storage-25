from typing import TypeAlias, TypedDict

__all__ = [
  "CleanOpts",
]

CleanOpts: TypeAlias = TypedDict("CleanOpts", {
  "validity_days": int,
  "tables": list[str],
  "dirs": list[str],
})
