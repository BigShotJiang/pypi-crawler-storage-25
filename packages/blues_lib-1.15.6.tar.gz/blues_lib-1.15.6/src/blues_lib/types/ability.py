from typing import TypeAlias, TypedDict, Any, Literal, NotRequired

__all__ = [
  "AttemptDelay",
  "AbilityStep",
  "ToolExpectMethod",
  "ToolExpectException",
  "ToolExpect",
  "ToolDef",
]

AttemptDelay: TypeAlias = int | float | list[int | float]

AbilityStep: TypeAlias = TypedDict("AbilityStep", {
  "value": float | int,
  "max_attempts": int,
  "interval": float | int,
})

ToolExpectMethod: TypeAlias = Literal[
  "to_be",
  "to_equal",
  "to_be_null",
  "to_be_truthy", "to_be_falsy",
  "to_be_greater_than", "to_be_less_than", "to_be_greater_than_or_equal", "to_be_less_than_or_equal",
  "to_contain",
  "to_match",
  "to_have_length",
  "to_have_length_greater_than",
  "to_have_property",
  "not_to_be",
  "not_to_equal",
  "not_to_be_null",
  "not_to_be_truthy", "not_to_be_falsy",
  "not_to_be_greater_than", "not_to_be_less_than", "not_to_be_greater_than_or_equal", "not_to_be_less_than_or_equal",
  "not_to_contain",
  "not_to_match",
  "not_to_have_length",
  "not_to_have_length_greater_than",
  "not_to_have_property",
]

ToolExpectException: TypeAlias = Literal[
  "AbilityExecError",
  "SkipLoopWarning",
  "SkipLoopError",
  "SkipSeqError",
  "BlockSeqError",
]

ToolExpect: TypeAlias = TypedDict("ToolExpect", {
  "method": ToolExpectMethod,
  "value": Any,
  "result": Any,
  "exception": ToolExpectException,
})


class ToolDef(TypedDict):
  name: str
  description: NotRequired[str]
  options: dict[str, Any]
