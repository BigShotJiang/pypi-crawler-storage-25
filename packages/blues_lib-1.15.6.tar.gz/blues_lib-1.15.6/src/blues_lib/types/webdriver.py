from typing import TypeAlias, TypedDict, Any, Callable, Literal
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.shadowroot import ShadowRoot
from selenium.webdriver.remote.webelement import WebElement

__all__ = [
  "SearchContext",
  "ElementTarget",
  "ElementRoot",
]

SearchContext: TypeAlias = WebDriver | WebElement | ShadowRoot
ElementTarget: TypeAlias = str | list[str] | WebElement | list[WebElement]
ElementRoot: TypeAlias = str | SearchContext
