from datetime import datetime
from jinja2 import Environment
import json
import os
import uuid
import random

class Jinja2Globals:
  '''
  Jinja2 全局方法和工具类
  '''

  @classmethod
  def set_globals(cls, env:Environment)->None:
    '''
    设置 Jinja2 环境全局对象和方法
    Args:
      env {Environment} : Jinja2 环境实例
    '''
    env.globals.update({
      'uuid': cls._generate_uuid,
      'random_int': cls._random_int,
      'random_choice': cls._random_choice,
      'env': cls._get_env,
      'json_dumps': cls._json_dumps,
      
      # 时间相关
      'now': datetime.now,
      'date': cls._date,
      'time': cls._time,
      'datetime': cls._datetime,
      'year': cls._year,
      'month': cls._month,
      'day': cls._day,
      'weekday': cls._weekday,
      'weekday_name': cls._weekday_name,
      'year_month': cls._year_month,
      'month_day': cls._month_day,
    })

  @classmethod
  def _date(cls)->str:
    '''
    获取当前日期字符串 (yyyy-mm-dd)
    Returns:
      str: 日期字符串
    '''
    return datetime.now().strftime('%Y-%m-%d')

  @classmethod
  def _time(cls)->str:
    '''
    获取当前时间字符串 (hh:mm:ss)
    Returns:
      str: 时间字符串
    '''
    return datetime.now().strftime('%H:%M:%S')

  @classmethod
  def _datetime(cls)->str:
    '''
    获取当前日期时间字符串 (yyyy-mm-dd hh:mm:ss)
    Returns:
      str: 日期时间字符串
    '''
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

  @classmethod
  def _year(cls)->str:
    '''
    获取当前年份 (yyyy)
    Returns:
      str: 年份字符串
    '''
    return datetime.now().strftime('%Y')

  @classmethod
  def _month(cls)->str:
    '''
    获取当前月份 (mm)
    Returns:
      str: 月份字符串
    '''
    return datetime.now().strftime('%m')

  @classmethod
  def _day(cls)->str:
    '''
    获取当前日期 (dd)
    Returns:
      str: 日期字符串
    '''
    return datetime.now().strftime('%d')

  @classmethod
  def _year_month(cls)->str:
    '''
    获取当前年月 (yyyy-mm)
    Returns:
      str: 年月字符串
    '''
    return datetime.now().strftime('%Y-%m')

  @classmethod
  def _month_day(cls)->str:
    '''
    获取当前月日 (mm-dd)
    Returns:
      str: 月日字符串
    '''
    return datetime.now().strftime('%m-%d')

  @classmethod
  def _weekday(cls)->int:
    '''
    获取当前星期几的数字 (1-7, 星期一=1, 星期日=7)
    Returns:
      int: 星期几的数字
    '''
    return datetime.now().weekday() + 1

  @classmethod
  def _weekday_name(cls)->str:
    '''
    获取当前星期几的名称 (Mon ~ Sun)
    Returns:
      str: 星期几的名称
    '''
    weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    return weekdays[datetime.now().weekday()]

  @classmethod
  def _generate_uuid(cls)->str:
    '''
    生成 UUID 字符串
    Returns:
      str: UUID 字符串
    '''
    return str(uuid.uuid4())

  @classmethod
  def _random_int(cls, min_val:int=0, max_val:int=100)->int:
    '''
    生成随机整数
    Args:
      min_val {int} : 最小值
      max_val {int} : 最大值
    Returns:
      int: 随机整数
    '''
    return random.randint(min_val, max_val)

  @classmethod
  def _random_choice(cls, choices:list)->any:
    '''
    从列表中随机选择一个元素
    Args:
      choices {list} : 可选列表
    Returns:
      any: 随机选择的元素
    '''
    return random.choice(choices)

  @classmethod
  def _get_env(cls, key:str, default:str='')->str:
    '''
    获取环境变量值
    Args:
      key {str} : 环境变量名
      default {str} : 默认值
    Returns:
      str: 环境变量值或默认值
    '''
    return os.environ.get(key, default)

  @classmethod
  def _json_dumps(cls, obj:any, ensure_ascii:bool=False)->str:
    '''
    将对象转为 JSON 字符串（支持中文）
    Args:
      obj {any} : 要转换的对象
      ensure_ascii {bool} : 是否确保 ASCII 编码，默认 False（支持中文）
    Returns:
      str: JSON 字符串
    '''
    return json.dumps(obj, ensure_ascii=ensure_ascii)