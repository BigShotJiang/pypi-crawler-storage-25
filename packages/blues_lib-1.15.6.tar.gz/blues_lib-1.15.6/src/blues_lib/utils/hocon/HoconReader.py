from pyhocon import ConfigFactory
from pyhocon.config_tree import ConfigTree
from pyhocon.tool import HOCONConverter


class HoconReader:
  """
  HOCON配置文件读取工具类
  """

  @classmethod
  def read(cls, file_path: str) -> ConfigTree:
    """
    读取HOCON配置文件为ConfigTree对象

    Args:
      file_path: 配置文件路径

    Returns:
      ConfigTree对象，读取失败返回空ConfigTree
    """
    try:
      return ConfigFactory.parse_file(file_path)
    except Exception as e:
      print(f"read hocon error: {e}")
      return ConfigTree()

  @classmethod
  def read_as_dict(cls, file_path: str) -> dict:
    """
    读取HOCON配置文件并转换为字典

    Args:
      file_path: 配置文件路径

    Returns:
      配置字典
    """
    config: ConfigTree = cls.read(file_path)
    return config.as_plain_ordered_dict()

  @classmethod
  def read_as_hocon(cls, file_path: str) -> str:
    """
    读取HOCON配置文件并转换为HOCON格式字符串

    Args:
      file_path: 配置文件路径

    Returns:
      HOCON格式字符串
    """
    config: ConfigTree = cls.read(file_path)
    return HOCONConverter.convert(config, 'hocon')

  @classmethod
  def read_as_json(cls, file_path: str) -> str:
    """
    读取HOCON配置文件并转换为JSON格式字符串

    Args:
      file_path: 配置文件路径

    Returns:
      JSON格式字符串
    """
    config: ConfigTree = cls.read(file_path)
    return HOCONConverter.convert(config, 'json')

  @classmethod
  def read_as_yaml(cls, file_path: str) -> str:
    """
    读取HOCON配置文件并转换为YAML格式字符串

    Args:
      file_path: 配置文件路径

    Returns:
      YAML格式字符串
    """
    config: ConfigTree = cls.read(file_path)
    return HOCONConverter.convert(config, 'yaml')

  @classmethod
  def read_as_properties(cls, file_path: str) -> str:
    """
    读取HOCON配置文件并转换为Properties格式字符串

    Args:
      file_path: 配置文件路径

    Returns:
      Properties格式字符串
    """
    config: ConfigTree = cls.read(file_path)
    return HOCONConverter.convert(config, 'properties')
