from .HoconReader import HoconReader

__all__ = ['HoconReader']
