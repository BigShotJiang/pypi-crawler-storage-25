import base64


class Base64:
  """
  Base64编解码工具类
  """

  @classmethod
  def dump_base64(cls, text: str) -> str:
    """
    将文本编码为Base64字符串

    Args:
      text: 待编码的文本

    Returns:
      Base64编码后的字符串
    """
    return base64.b64encode(text.encode()).decode()

  @classmethod
  def load_base64(cls, b64: str) -> str:
    """
    将Base64字符串解码为原始文本

    Args:
      b64: Base64编码的字符串

    Returns:
      解码后的原始文本
    """
    return base64.b64decode(b64.encode()).decode()
