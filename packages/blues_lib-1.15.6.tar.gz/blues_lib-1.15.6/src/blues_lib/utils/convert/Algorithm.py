import hashlib
import math


class Algorithm:
  """
  算法工具类，提供常用的加密和计算功能
  """

  @classmethod
  def md5(cls, text: str) -> str:
    """
    MD5加密算法（单向不可逆），用于数据存储密码，如果忘了只能重置

    Args:
      text: 待加密的文本字符串

    Returns:
      MD5加密后的十六进制字符串
    """
    md_5 = hashlib.md5()
    md_5.update(text.encode())
    return md_5.hexdigest()

  @classmethod
  def sha1(cls, text: str) -> str:
    """
    SHA1加密算法

    Args:
      text: 待加密的文本字符串

    Returns:
      SHA1加密后的十六进制字符串
    """
    sha_1 = hashlib.sha1()
    sha_1.update(text.encode())
    return sha_1.hexdigest()

  @classmethod
  def get_cn_length(cls, text: str) -> int:
    """
    计算字符串长度，中文按长度1计算，英文和符号按0.5计算，结果向上取整

    Args:
      text: 待计算长度的字符串

    Returns:
      向上取整后的字符长度
    """
    length = 0
    for char in text:
      if '\u4e00' <= char <= '\u9fff':
        length += 1
      else:
        length += 0.5
    return math.ceil(length)
