import os
import requests
from blues_lib.utils.os import Printer
from blues_lib.utils.url import URLManager
from blues_lib.utils.file import File


class FileDownloader:
  """
  文件下载工具类
  """

  @classmethod
  def download(cls, urls: list[str] | str, directory: str, success=None, error=None) -> dict:
    """
    下载多个文件

    Args:
      urls: 文件的远程URL，可以是单个URL字符串或URL列表
      directory: 保存下载文件的本地目录
      success: 成功回调函数
      error: 失败回调函数

    Returns:
      下载结果字典，包含成功和失败的文件信息
    """
    result = cls._get_result()
    if not urls:
      return result

    url_list = urls if isinstance(urls, list) else [urls]
    for url in url_list:
      (code, file_or_msg) = cls.download_one(url, directory)
      if code == 200:
        item = {
          'url': url,
          'file': file_or_msg,
          'callback_value': None
        }
        if success:
          item['callback_value'] = success(file_or_msg)
        result['success']['count'] += 1
        result['success']['files'].append(item)
        result['files'].append(file_or_msg)
        result['code'] = 200
      else:
        item = {
          'url': url,
          'message': file_or_msg,
          'callback_value': None
        }
        if error:
          item['callback_value'] = error(str(e))
        result['error']['count'] += 1
        result['error']['files'].append(item)

    return result

  @classmethod
  def download_one(cls, url: str, directory: str, name: str = '') -> tuple[int, str]:
    """
    下载单个文件

    Args:
      url: 文件的远程URL
      directory: 保存文件的目录
      name: 文件名（不含扩展名）

    Returns:
      元组 (状态码, 文件路径或错误消息)
    """
    try:
      File.makedirs(directory)
      file_name = URLManager.get_file_name(url, name)
      local_file = os.path.join(directory, file_name)

      Printer.info('Downloading the file: %s' % url)
      res = requests.get(url, timeout=1)
      res.raise_for_status()
      with open(local_file, 'wb') as f:
        f.write(res.content)
        f.close()
        Printer.success(f'Downloaded the file: {url} to {local_file}')
        return (200, local_file)
    except Exception as e:
      Printer.error(f'Downloaded the image failure: {e}')
      return (500, str(e))

  @classmethod
  def _get_result(cls) -> dict:
    """
    获取默认的结果字典

    Returns:
      默认结果字典
    """
    return {
      'code': 500,
      'files': [],
      'success': {
        'count': 0,
        'files': [],
      },
      'error': {
        'count': 0,
        'files': [],
      },
    }
