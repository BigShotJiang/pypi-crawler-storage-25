import os
import time
import logging
from datetime import datetime, timedelta
from blues_lib.utils.file import File


class FileRemover:
  """
  文件删除工具类，支持按时间保留策略删除文件
  """

  _logger = logging.getLogger('airflow.task')

  @classmethod
  def remove_dirs(cls, directory: str, retention_days: int = 0) -> int:
    """
    删除目录下所有子目录和文件（按保留天数过滤）

    Args:
      directory: 目录路径
      retention_days: 保留天数，删除早于该天数的文件

    Returns:
      删除的文件/目录数量
    """
    threshold = datetime.now() - timedelta(days=retention_days)
    removed_count = 0
    if not File.exists(directory):
      return removed_count

    for root, dirs, files in os.walk(directory):
      for file in files:
        file_path = os.path.join(root, file)
        if cls.__remove_once(file_path, retention_days):
          removed_count += 1
      for dire in dirs:
        dir_path = os.path.join(root, dire)
        file_modified_time = datetime.fromtimestamp(os.path.getmtime(dir_path))
        if file_modified_time < threshold:
          removed_count += cls.remove_dirs(dir_path, retention_days)
    if File.is_dir_empty(directory):
      os.rmdir(directory)
      removed_count += 1
    return removed_count

  @classmethod
  def remove_files(cls, dir_path: str, retention_days: int = 0) -> int:
    """
    删除目录下符合条件的文件

    Args:
      dir_path: 目录路径
      retention_days: 保留天数，删除早于该天数的文件，默认为0

    Returns:
      删除的文件数量
    """
    removed_count = 0
    if not File.exists(dir_path):
      return removed_count
    for item in os.scandir(dir_path):
      if cls.__remove_once(item.path, retention_days):
        removed_count += 1
    return removed_count

  @classmethod
  def remove_file(cls, file_path: str, retention_days: int = 0) -> bool:
    """
    删除单个文件（按保留天数过滤）

    Args:
      file_path: 文件路径
      retention_days: 保留天数，删除早于该天数的文件，默认为0

    Returns:
      是否成功删除
    """
    if not File.exists(file_path):
      return True
    return cls.__remove_once(file_path, retention_days)

  @classmethod
  def __remove_once(cls, item_path: str, retention_days: int) -> bool:
    """
    检查并删除单个文件

    Args:
      item_path: 文件路径
      retention_days: 保留天数

    Returns:
      是否成功删除
    """
    if not os.path.isfile(item_path):
      return True

    threshold = datetime.now() - timedelta(days=retention_days)
    file_modified_time = datetime.fromtimestamp(os.path.getmtime(item_path))
    if file_modified_time < threshold:
      try:
        os.remove(item_path)
        return True
      except OSError as e:
        cls._logger.warning(f"remove file {item_path} failed, {e}")
        return False
    return True
