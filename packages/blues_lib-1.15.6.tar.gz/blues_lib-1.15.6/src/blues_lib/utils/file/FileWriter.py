from typing import Any
import os
import json
import csv
from blues_lib.utils.file import File
from blues_lib.utils.convert import TypeManager


class FileWriter:
  """
  文件写入工具类，支持多种文件格式
  """

  @classmethod
  def write(cls, file_path: str, text: str, mode: str = 'w') -> str:
    """
    写入文本到文件

    Args:
      file_path: 文件路径
      text: 要写入的内容
      mode: 写入模式，'w' 覆盖写入，'a' 追加写入

    Returns:
      写入的文件路径，失败返回空字符串
    """
    dir_path = os.path.dirname(file_path)
    if dir_path != '.':
      File.makedirs(dir_path)

    try:
      with open(file_path, mode, encoding='utf-8') as file:
        file.write(text)
      return file_path
    except Exception as e:
      print(f'==>write error: {e}')
      return ''

  @classmethod
  def write_text(cls, file_path: str, text: str, mode: str = 'w') -> str:
    """
    写入文本到文件（同 write 方法）

    Args:
      file_path: 文件路径
      text: 要写入的内容
      mode: 写入模式

    Returns:
      写入的文件路径
    """
    return cls.write(file_path, text, mode)

  @classmethod
  def write_after(cls, file_path: str, text: str) -> str:
    """
    追加写入文本到文件

    Args:
      file_path: 文件路径
      text: 要追加的内容

    Returns:
      写入的文件路径
    """
    return cls.write(file_path, text, 'a')

  @classmethod
  def write_json(cls, file_path: str, data: Any, indent: int = 2) -> str:
    """
    写入JSON数据到文件

    Args:
      file_path: 文件路径
      data: 要写入的JSON数据
      indent: 缩进空格数，默认为2

    Returns:
      写入的文件路径，失败返回空字符串
    """
    dir_path = os.path.dirname(file_path)
    if dir_path != '.':
      File.makedirs(dir_path)

    try:
      with open(file_path, 'w', encoding='utf-8') as file:
        json.dump(data, file, indent=indent, ensure_ascii=False)
        return file_path
    except Exception as e:
      print(f'==>write_json error: {e}')
      return ''

  @classmethod
  def write_csv(cls, file_path: str, rows: list, header: list | tuple | None = None, mode: str = 'w') -> str:
    """
    写入CSV文件

    Args:
      file_path: CSV文件路径
      rows: 数据行，可以是列表的列表或元组的元组
      header: 表头行
      mode: 写入模式，'a' 追加，'w' 覆盖

    Returns:
      写入的文件路径，失败返回空字符串
    """
    dir_path = os.path.dirname(file_path)
    if dir_path != '.':
      File.makedirs(dir_path)

    try:
      with open(file_path, mode, encoding='utf-8', newline="") as file:
        writer = csv.writer(file)
        if mode == 'w' and header:
          writer.writerow(header)
        if rows:
          for row in rows:
            writer.writerow(row)
        return file_path
    except Exception as e:
      print(f'==>write_csv error: {e}')
      return ''

  @classmethod
  def to_file(cls, content: Any, options: dict | str | bool) -> str:
    """
    将内容写入文件（自动选择格式）

    Args:
      content: 要写入的内容
      options: 文件配置选项

    Returns:
      写入的文件路径
    """
    file_path: str = File.get_abs_file(options)
    if isinstance(content, str):
      return cls.write_text(file_path, content)
    else:
      return cls.write_json(file_path, content)

  @classmethod
  def write_or_return(cls, opts: dict, content: Any) -> Any:
    """
    根据配置写入文件或返回内容

    Args:
      opts: 配置选项
      content: 要处理的内容

    Returns:
      文件路径（如果写入文件）或内容本身
    """
    to_json: bool = opts.get('to_json') or False
    if to_json:
      content = TypeManager.to_json(content)

    to_file: dict | str = opts.get('to_file', {})
    if to_file:
      return cls.to_file(content, to_file)
    else:
      return content
