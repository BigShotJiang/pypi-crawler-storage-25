import pandas


class CSVManager:
  """
  CSV文件管理工具类
  """

  @classmethod
  def read_columns(cls, csv_file: str) -> list[str]:
    """
    读取CSV文件的列名（首行）

    Args:
      csv_file: CSV文件路径

    Returns:
      列名列表
    """
    df = pandas.read_csv(csv_file)
    return df.columns.tolist()

  @classmethod
  def read_rows(cls, csv_file: str) -> list[dict]:
    """
    读取CSV文件的所有数据行

    Args:
      csv_file: CSV文件路径

    Returns:
      数据行列表，每行表示为字典
    """
    df = pandas.read_csv(csv_file)
    return df.to_dict(orient='records')

  @classmethod
  def write(cls, file_path: str, rows: list, columns: list[str] | None = None, index: bool = False) -> None:
    """
    创建或覆盖CSV文件

    Args:
      file_path: CSV文件绝对路径
      rows: 数据行，可以是列表的列表或列表的字典
      columns: 列名（如果rows是字典列表则不需要）
      index: 是否创建索引列
    """
    if isinstance(rows[0], dict):
      df = pandas.DataFrame(rows)
    else:
      df = pandas.DataFrame(rows, columns=columns)
    df.to_csv(file_path, index=index)

  @classmethod
  def append(cls, file_path: str, rows: list, index: bool = False) -> None:
    """
    向已存在的CSV文件追加行

    Args:
      file_path: CSV文件绝对路径
      rows: 数据行，可以是列表的列表或列表的字典
      index: 是否创建索引列
    """
    df = pandas.DataFrame(rows)
    df.to_csv(file_path, mode='a', header=False, index=index)
