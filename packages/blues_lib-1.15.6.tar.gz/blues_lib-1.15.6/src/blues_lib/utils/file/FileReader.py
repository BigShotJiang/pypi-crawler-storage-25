import os
import json
import csv
import yaml
import json5
from typing import Any
from blues_lib.utils.file import File
from blues_lib.utils.hocon import HoconReader


_READER_MAP = {}


def _register(ext: str):
  def wrapper(method):
    _READER_MAP[ext] = method
    return method
  return wrapper


class FileReader:

  @classmethod
  def read(cls, file_path: str, root_path: str = '', extension: str = '') -> Any:
    ext = extension or 'txt'
    file_path = File.get_standard_path(file_path, root_path, ext)
    _, detected = os.path.splitext(file_path)
    reader = _READER_MAP.get(detected.lower())
    return reader(cls, file_path) if reader else cls.read_text(file_path)

  @classmethod
  def read_text(cls, file_path: str, root_path: str = '', extension: str = '') -> str:
    try:
      file_path = File.get_standard_path(file_path, root_path, extension or 'txt')
      with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()
    except Exception as e:
      print(f"read file error: {e}")
      return ''

  @classmethod
  @_register('.yaml')
  @_register('.yml')
  def read_yaml(cls, file_path: str, root_path: str = '', extension: str = '') -> Any | None:
    try:
      file_path = File.get_standard_path(file_path, root_path, extension or 'yaml')
      with open(file_path, 'r', encoding='utf-8') as file:
        return yaml.safe_load(file)
    except Exception as e:
      print(f"read yaml error: {e}")
      return None

  @classmethod
  @_register('.json5')
  def read_json5(cls, file_path: str, root_path: str = '', extension: str = '') -> Any | None:
    try:
      file_path = File.get_standard_path(file_path, root_path, extension or 'json5')
      with open(file_path, 'r', encoding='utf-8') as file:
        return json5.load(file)
    except Exception as e:
      print(f"read json5 error: {e}")
      return None

  @classmethod
  @_register('.json')
  def read_json(cls, file_path: str, root_path: str = '', extension: str = '') -> Any | None:
    try:
      file_path = File.get_standard_path(file_path, root_path, extension or 'json')
      with open(file_path, 'r', encoding='utf-8') as file:
        return json.load(file)
    except Exception as e:
      print(f"read json error: {e}")
      return None

  @classmethod
  @_register('.csv')
  def read_csv(cls, file_path: str, headless: bool = False, root_path: str = '', extension: str = '') -> list[list[str]] | None:
    try:
      file_path = File.get_standard_path(file_path, root_path, extension or 'csv')
      with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
        lines = csv.reader(file)
        rows = []
        i = 0
        for line in lines:
          i += 1
          if i == 1 and headless:
            continue
          if not line:
            continue
          rows.append(line)
        return rows
    except Exception as e:
      print(f"read csv error: {e}")
      return None

  @classmethod
  @_register('.conf')
  def read_hocon(cls, file_path: str, root_path: str = '', extension: str = '') -> dict:
    file_path = File.get_standard_path(file_path, root_path, extension or 'conf')
    return HoconReader.read_as_dict(file_path)
