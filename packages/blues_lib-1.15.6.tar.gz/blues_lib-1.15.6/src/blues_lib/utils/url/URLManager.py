from os import path
from urllib.parse import urlparse
from tld import get_fld
from blues_lib.utils.convert import Algorithm

class URLManager():
  
  @classmethod
  def is_http_url(cls, url: str) -> bool:
    """
    判断是否为 HTTP/HTTPS URL
    
    Args:
      url: 待判断的URL字符串
      
    Returns:
      如果是HTTP/HTTPS URL返回True，否则返回False
    """
    try:
      result = urlparse(url)
      return result.scheme in ('http', 'https') and bool(result.netloc)
    except ValueError:
      return False

  @classmethod
  def get_domain(cls, url: str) -> str:
    """
    获取URL的域名部分
    
    Args:
      url: URL字符串
      
    Returns:
      域名部分（netloc）
    """
    parsed_url = urlparse(url)
    return parsed_url.netloc

  @classmethod
  def get_main_domain(cls, url: str) -> str:
    """
    获取URL的主域名（不带www等前缀）
    
    Args:
      url: URL字符串
      
    Returns:
      主域名
    """
    return get_fld(url)
  
  @classmethod
  def get_abs_path(cls, abs_file: str, child_dir: str = '', file_name: str = '') -> str:
    """
    获取当前文件所在目录（或子目录下）的文件或目录的绝对路径
    
    Args:
      abs_file: 当前文件绝对路径
      child_dir: 基于当前目录向后拼接的子目录
      file_name: 文件名
      
    Returns:
      拼接后的绝对路径
    """
    cur_path = path.dirname(abs_file)
    return path.join(cur_path, child_dir, file_name)
  
  @classmethod
  def get_file_name(cls, url: str, name: str = '', with_extension: bool = True) -> str:
    """
    从URL中提取文件名
    
    Args:
      url: URL字符串
      name: 自定义文件名（可选）
      with_extension: 是否包含扩展名，默认为True
      
    Returns:
      文件名
    """
    parsed_url = urlparse(url)
    file_path = path.basename(parsed_url.path)
    file_name = path.splitext(file_path)[0] if not name else name
    extend_name = path.splitext(file_path)[1]

    if len(file_name) > 50:
      file_name = Algorithm.md5(file_name)

    if with_extension:
      return file_name + extend_name
    else:
      return file_name

  @classmethod
  def get_extend_name(cls, file_name: str) -> str:
    """
    获取文件扩展名（包含点号）
    
    Args:
      file_name: 文件名
      
    Returns:
      文件扩展名（包含.）
    """
    return path.splitext(file_name)[1]

  @classmethod
  def get_blues_file_path(cls, dir_path: str, file_name: str) -> str:
    """
    拼接目录路径和文件名
    
    Args:
      dir_path: 目录路径
      file_name: 文件名
      
    Returns:
      完整的文件路径
    """
    return path.join(dir_path, file_name)

  @classmethod
  def get_file_dir(cls, file_path: str) -> str:
    """
    获取文件所在目录路径（不含文件名）
    
    Args:
      file_path: 文件路径
      
    Returns:
      目录路径
    """
    return path.dirname(file_path)

  @classmethod
  def rename_extend_name(cls, file_path: str, extend_name: str) -> str:
    """
    重命名文件扩展名
    
    Args:
      file_path: 文件路径
      extend_name: 新的扩展名（不含点号）
      
    Returns:
      新的文件路径
    """
    if not extend_name:
      return file_path

    file_dir = cls.get_file_dir(file_path)
    pure_file_name = cls.get_file_name(file_path, '', False)
    new_file_name = '%s.%s' % (pure_file_name, extend_name)
    return path.join(file_dir, new_file_name)
    