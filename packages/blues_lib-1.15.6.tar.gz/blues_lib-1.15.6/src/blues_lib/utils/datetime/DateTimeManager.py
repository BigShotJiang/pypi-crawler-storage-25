import time
import datetime
import random


class DateTimeManager:
  """
  日期时间管理工具类
  """

  spend = 0

  @classmethod
  def get_random_seconds(cls, min_seconds: float, max_seconds: float) -> float:
    """
    生成指定范围内的随机等待时间（秒）

    Args:
      min_seconds: 最小等待时间（秒）
      max_seconds: 最大等待时间（秒）

    Returns:
      float: 随机等待时间，单位为秒，介于min_seconds和max_seconds之间
    """
    if min_seconds > max_seconds:
      min_seconds, max_seconds = max_seconds, min_seconds

    return random.uniform(min_seconds, max_seconds)

  @classmethod
  def get_today(cls) -> str:
    """
    获取今天的日期字符串

    Returns:
      格式为 'YYYY-MM-DD' 的日期字符串
    """
    now = datetime.datetime.now()
    return now.strftime('%Y-%m-%d')

  @classmethod
  def get_time(cls) -> str:
    """
    获取当前时间字符串

    Returns:
      格式为 'HH:MM:SS' 的时间字符串
    """
    now = datetime.datetime.now()
    return now.strftime('%H:%M:%S')

  @classmethod
  def get_now(cls) -> str:
    """
    获取当前日期时间字符串

    Returns:
      格式为 'YYYY-MM-DD HH:MM:SS' 的日期时间字符串
    """
    now = datetime.datetime.now()
    return now.strftime('%Y-%m-%d %H:%M:%S')

  @classmethod
  def get_timestamp(cls) -> int:
    """
    获取当前时间戳（毫秒）

    Returns:
      当前时间戳，单位为毫秒
    """
    now = datetime.datetime.now()
    return int(now.timestamp() * 1000)

  @classmethod
  def count_down(cls, payload: dict = {}) -> None:
    """
    倒计时功能

    Args:
      payload: 配置参数
        - duration: 总时长（秒），默认10
        - interval: 更新间隔（秒），默认1
        - title: 标题，默认'coutdown'
    """
    duration = int(payload.get('duration', 10))
    interval = int(payload.get('interval', 1))
    title = payload.get('title', 'coutdown')

    if not duration:
      return

    if interval <= 0:
      interval = 1

    spend = 0
    time.sleep(interval)
    while spend < duration:
      spend += interval
      progress = (spend / duration) * 100
      remaining = duration - spend
      print_content = f"{title}: progress {progress:.0f}% | remain {remaining:.0f}s"
      max_length = len(f"{title}: progress 100% | remain 0s")
      print_content_padded = print_content.ljust(max_length)
      print(print_content_padded, end='\r', flush=True)
      if spend < duration:
        time.sleep(interval)
    print()
