from functools import wraps
from blues_lib.tools.context import TaskContext
from blues_lib.services.schema import SchemaValidator

class AbilityIOHook():
  
  _SUMMARY_KEYS:dict[str,str] = {
    'cast':'single',
    'cast_single':'single',
    'cast_loop':'loop',
    'cast_page':'page',
  }

  def __call__(self,func):
    @wraps(func) 
    def wrapper(instance,method:str,options:dict|None=None)->any:
      
      self._validate_input(method,options)

      from blues_lib.tools.runner import AbilityHook
      context:TaskContext = instance._context
      options = options or {}
  
      summary_key:str = self._SUMMARY_KEYS.get(method,'')
      tool_summary:dict[str,any] = (options.get(summary_key) or {}) if summary_key else options
      id:str = context.get_id(tool_summary.get('id'),method)

      ability_hook:AbilityHook = AbilityHook(context,tool_summary,id)
      ability_hook.prev() 

      result:any = func(instance,method,options) 
      # 将结果追加到同一个seq共享的context result字典中，如果未提供id，则不会暴露在result字典中
      context.add_result(id,result)
      # post中可通过设置相同id覆盖result结果，如果是引用类型可直接修改
      ability_hook.post()
      return context.result.get(id)

    return wrapper
  
  def _validate_input(self,name:str,opts:dict):
    if opts:
      SchemaValidator.validate_tool_input(opts,name)

  def _has_hook_tools(self,opts:dict)->bool:
    prev_tools:list = opts.get('prev_tools',[]) or []
    post_tools:list = opts.get('post_tools',[]) or []
    return len(prev_tools)>0 or len(post_tools)>0


