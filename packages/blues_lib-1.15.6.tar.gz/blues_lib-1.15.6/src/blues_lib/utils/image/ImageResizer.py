import os
from PIL import Image
import logging

class ImageResizer():

  _logger = logging.getLogger('airflow.task')

  @classmethod
  def handle(cls, local_image: str, config: dict) -> tuple[bool,str]:
    is_ad,message = cls.is_ad_image(local_image,config)
    if is_ad:
      cls._logger.warning(f"remove AD image {local_image}, {message}")
      return False,message
    return cls.resize(local_image,config)

  @classmethod
  def is_ad_image(cls, local_image: str, config:dict ) -> tuple[bool,str]:
    """
    通过图片的长宽比判断是否为典型的广告图
    
    参数:
        local_image: 本地图片路径
        max_w_h_ratio: 最大宽高比阈值，默认3
        max_h_w_ratio: 最大高宽比阈值，默认3
        
    返回:
        bool: 如果长宽比超过阈值则返回True（认为是广告图），否则返回False
    """
    try:
      # 打开图片并获取尺寸
      max_w_h_ratio: int = config.get('max_w_h_ratio') or 4
      max_h_w_ratio: int = config.get('max_h_w_ratio') or 4

      with Image.open(local_image) as img:
        width, height = img.size
        
        # 避免除以零错误
        if width == 0 or height == 0:
          return False
        
        # 计算宽高比和高宽比
        width_height_ratio = width / height  # 宽/高
        height_width_ratio = height / width  # 高/宽
        
        # 判断是否超过阈值
        if width_height_ratio > max_w_h_ratio or height_width_ratio > max_h_w_ratio:
          return (True,f"图片 {local_image} 长宽比异常，宽高比: {width_height_ratio:.2f}, 高宽比: {height_width_ratio:.2f}")

        return (False,'ok')
        
    except FileNotFoundError:
      return (False,f"错误: 找不到图片文件 {local_image}")
    except Exception as e:
      return (False,f"分析图片时发生错误: {str(e)}")
    
  @classmethod
  def resize(cls, local_image: str, config: dict) -> tuple[bool,str]:
    """
    检查并按比例调整本地图片尺寸使其符合给定范围，统一保存为PNG格式
    参数:
        local_image: 本地图片路径
        config: 包含尺寸范围配置的字典，支持两种参数命名:
          - max_width,max_height,min_height,min_width
    返回:
        tuple[bool, str]: (成功标志, 处理后的图片路径或错误信息)
    """
    if not local_image:
      return (False,'no local_image')

    max_w = config.get('max_width') or 1000
    min_w = config.get('min_width') or 300
    max_h = config.get('max_height') or 1000
    min_h = config.get('min_height') or 300

    if not max_w or not max_h or not min_w or not min_h:
      return (True, local_image)
    
    # 验证配置的有效性
    if min_w > max_w:
      min_w = max_w
    if min_h > max_h:
      min_h = max_h

    try:
      # 打开图片
      with Image.open(local_image) as img:
        # 获取当前图片尺寸
        current_width, current_height = img.size

        # 计算原始宽高比
        if current_height == 0:
          return (True, local_image)  # 避免除以零错误
        original_ratio = current_width / current_height

        new_width, new_height = current_width, current_height
        need_resize = False

        # 检查是否需要调整尺寸（按比例）
        # 情况1: 宽度超出最大值
        if current_width > max_w:
          new_width = max_w
          new_height = int(new_width / original_ratio)
          need_resize = True

        # 情况2: 高度超出最大值（在情况1调整后可能出现）
        if new_height > max_h:
          new_height = max_h
          new_width = int(new_height * original_ratio)
          need_resize = True

        # 情况3: 宽度小于最小值
        if current_width < min_w:
          new_width = min_w
          new_height = int(new_width / original_ratio)
          need_resize = True

        # 情况4: 高度小于最小值（在情况3调整后可能出现）
        if new_height < min_h:
          new_height = min_h
          new_width = int(new_height * original_ratio)
          need_resize = True

        # 处理特殊情况：如果一个边达到最小值后另一个边超过最大值，允许这种情况
        # 不需要额外处理，前面的逻辑已经允许这种情况发生

        # 无论是否需要调整尺寸，都处理格式
        original_format = img.format.upper() if img.format else ''
        is_png = original_format == 'PNG'

        # 处理图片尺寸（如果需要）
        if need_resize:
          processed_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        else:
          processed_img = img.copy()

        # 构建新的文件名（统一输出为PNG）
        base, _ = os.path.splitext(local_image)
        new_path = f"{base}.png"

        # 删除原文件
        os.remove(local_image)

        # 保存为PNG格式
        processed_img.save(new_path, format='PNG')

        cls._logger.info(f"resize {new_path} from {current_width},{current_height} to {new_width},{new_height}")

        return (True, new_path)
        
    except FileNotFoundError:
      return (False,f"错误: 找不到图片文件 {local_image}")
    except Exception as e:
      return (False,f"处理图片时发生错误: {str(e)}")
