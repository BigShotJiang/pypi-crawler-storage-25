import requests
import json
import logging
import os
import time
import hmac
import hashlib
import base64
import urllib.parse
from blues_lib.types import TaskResponse,DingOpts


class DingGroupSender:
  """
  钉钉群消息发送器（基于 Webhook）

  注意事项：
  - 本类使用钉钉自定义机器人的 Webhook 方式发送消息
  - 消息只能发送到创建机器人的群聊，不支持直接发送给个人联系人
  - 如果需要发送个人消息，请使用企业内部应用 API（需要企业认证）

  配置方式：
  1. 在钉钉群聊中添加自定义机器人
  2. 获取 Webhook URL 和 Secret（可选）
  3. 设置环境变量：
     - DING_WEBHOOK_URL: Webhook 地址
     - DING_SECRET: 签名密钥（可选，用于安全验证）

  支持的消息类型：
  - text: 文本消息，支持 @ 指定用户
  - link: 链接消息
  - markdown: Markdown 格式消息，支持图片和 @ 指定用户
  - actioncard: ActionCard 消息（整体跳转或多按钮）
  - feedcard: FeedCard 消息（多条链接卡片）

  使用示例：
  >>> sender = DingGroupSender.get_instance()
  >>> result = sender.send({
  ...     'msgtype': 'text',
  ...     'content': '这是一条测试消息'
  ... })
  """

  config = {
    'timeout': 10,
  }

  _instance = None

  @classmethod
  def get_instance(cls):
    if not cls._instance:
      cls._instance = DingGroupSender()
    return cls._instance

  def __init__(self):
    self.logger = logging.getLogger('airflow.task')

  def _generate_sign(self, timestamp: int) -> str:
    secret = os.environ.get("DING_SECRET", "")
    if not secret:
      return ''
    
    secret_enc = secret.encode('utf-8')
    string_to_sign = f'{timestamp}\n{secret}'
    string_to_sign_enc = string_to_sign.encode('utf-8')
    
    hmac_code = hmac.new(secret_enc, string_to_sign_enc, digestmod=hashlib.sha256).digest()
    sign = urllib.parse.quote_plus(base64.b64encode(hmac_code))
    return sign

  def _get_webhook_url(self) -> str:
    webhook_url = os.environ.get("DING_WEBHOOK_URL", "")
    if not webhook_url:
      raise ValueError('DING_WEBHOOK_URL is not configured')
    
    secret = os.environ.get("DING_SECRET", "")
    if secret:
      timestamp = int(round(time.time() * 1000))
      sign = self._generate_sign(timestamp)
      return f"{webhook_url}&timestamp={timestamp}&sign={sign}"
    
    return webhook_url

  def _build_text_message(self, content: str, at_mobiles: list = None, at_user_ids: list = None, is_at_all: bool = False) -> dict:
    message = {
      'msgtype': 'text',
      'text': {
        'content': content
      }
    }
    
    at = {}
    if at_mobiles:
      at['atMobiles'] = at_mobiles
    if at_user_ids:
      at['atUserIds'] = at_user_ids
    if is_at_all:
      at['isAtAll'] = is_at_all
    
    if at:
      message['at'] = at
    
    return message

  def _build_link_message(self, title: str, text: str, message_url: str, pic_url: str = None) -> dict:
    message = {
      'msgtype': 'link',
      'link': {
        'title': title,
        'text': text,
        'messageUrl': message_url
      }
    }
    
    if pic_url:
      message['link']['picUrl'] = pic_url
    
    return message

  def _build_markdown_message(self, title: str, text: str, at_mobiles: list = None, at_user_ids: list = None, is_at_all: bool = False) -> dict:
    message = {
      'msgtype': 'markdown',
      'markdown': {
        'title': title,
        'text': text
      }
    }
    
    at = {}
    if at_mobiles:
      at['atMobiles'] = at_mobiles
    if at_user_ids:
      at['atUserIds'] = at_user_ids
    if is_at_all:
      at['isAtAll'] = is_at_all
    
    if at:
      message['at'] = at
    
    return message

  def _build_actioncard_message(self, title: str, text: str, single_title: str = None, single_url: str = None, btn_orientation: str = '0', btns: list = None) -> dict:
    message = {
      'msgtype': 'actionCard',
      'actionCard': {
        'title': title,
        'text': text,
        'btnOrientation': btn_orientation
      }
    }
    
    if single_title and single_url:
      message['actionCard']['singleTitle'] = single_title
      message['actionCard']['singleURL'] = single_url
    elif btns:
      message['actionCard']['btns'] = btns
    
    return message

  def _build_feedcard_message(self, links: list) -> dict:
    processed_links = []
    for link in links:
      processed_link = {}
      if 'title' in link:
        processed_link['title'] = link['title']
      if 'message_url' in link:
        processed_link['messageURL'] = link['message_url']
      elif 'messageURL' in link:
        processed_link['messageURL'] = link['messageURL']
      if 'pic_url' in link:
        processed_link['picURL'] = link['pic_url']
      elif 'picURL' in link:
        processed_link['picURL'] = link['picURL']
      processed_links.append(processed_link)
    
    message = {
      'msgtype': 'feedCard',
      'feedCard': {
        'links': processed_links
      }
    }
    return message

  def _build_message(self, options: dict) -> dict:
    msg_type = options.get('msgtype', 'text')
    
    if msg_type == 'text':
      return self._build_text_message(
        content=options.get('content', ''),
        at_mobiles=options.get('at_mobiles'),
        at_user_ids=options.get('at_user_ids'),
        is_at_all=options.get('is_at_all', False)
      )
    elif msg_type == 'link':
      return self._build_link_message(
        title=options.get('title', ''),
        text=options.get('text', ''),
        message_url=options.get('message_url', ''),
        pic_url=options.get('pic_url')
      )
    elif msg_type == 'markdown':
      return self._build_markdown_message(
        title=options.get('title', ''),
        text=options.get('text', ''),
        at_mobiles=options.get('at_mobiles'),
        at_user_ids=options.get('at_user_ids'),
        is_at_all=options.get('is_at_all', False)
      )
    elif msg_type == 'actioncard':
      return self._build_actioncard_message(
        title=options.get('title', ''),
        text=options.get('text', ''),
        single_title=options.get('single_title'),
        single_url=options.get('single_url'),
        btn_orientation=options.get('btn_orientation', '0'),
        btns=options.get('btns')
      )
    elif msg_type == 'feedcard':
      return self._build_feedcard_message(
        links=options.get('links', [])
      )
    else:
      raise ValueError(f'Unsupported message type: {msg_type}')

  def send(self, options: DingOpts) -> TaskResponse:
    """
    发送钉钉群消息

    Args:
      options: 消息配置字典
        - msgtype: 消息类型（text/link/markdown/actioncard/feedcard）
        - 其他参数根据消息类型而定

    Returns:
      TaskResponse: 发送结果
        - code: 200 表示成功，504 表示失败
        - message: 结果描述
        - data: 成功时返回钉钉 API 响应
        - detail: 失败时返回详细错误信息

    Examples:
      # 发送文本消息
      sender.send({
          'msgtype': 'text',
          'content': '这是一条文本消息',
          'at_mobiles': ['13800138000'],
          'is_at_all': False
      })

      # 发送 Markdown 消息
      sender.send({
          'msgtype': 'markdown',
          'title': 'Markdown 标题',
          'text': '### 标题\n\n**粗体文字**\n\n![图片](https://example.com/img.png)'
      })
    """
    try:
      webhook_url = self._get_webhook_url()
      message = self._build_message(options)
      
      headers = {
        'Content-Type': 'application/json'
      }
      
      response = requests.post(
        webhook_url,
        data=json.dumps(message),
        headers=headers,
        timeout=self.config['timeout']
      )
      
      result = response.json()
      
      if result.get('errcode') == 0:
        self.logger.info('DingTalk message sent successfully')
        return TaskResponse({
          'code': 200,
          'message': 'Managed to send',
          'data': result,
          'detail': None
        })
      else:
        self.logger.error(f'Failed to send DingTalk message: {result.get("errmsg")}')
        return TaskResponse({
          'code': 504,
          'message': f'Failed to send - {result.get("errmsg")}',
          'data': None,
          'detail': result
        })
        
    except requests.exceptions.Timeout:
      self.logger.error('DingTalk message send timeout')
      return TaskResponse({
        'code': 504,
        'message': 'Failed to send - timeout',
        'data': None,
        'detail': None
      })
    except requests.exceptions.RequestException as e:
      self.logger.error(f'DingTalk message send request error: {e}')
      return TaskResponse({
        'code': 504,
        'message': f'Failed to send - {e}',
        'data': None,
        'detail': None
      })
    except Exception as e:
      self.logger.error(f'DingTalk message send error: {e}')
      return TaskResponse({
        'code': 504,
        'message': f'Failed to send - {e}',
        'data': None,
        'detail': None
      })
