import re
from bs4 import BeautifulSoup, Comment


class HtmlExtractor:
  """
  HTML内容提取和清理工具类
  """

  def extract(self, html: str, includes: list[str] = [], excludes: list[str] = []) -> dict[str, str | int]:
    """
    提取html的body有效内容并移除非必要属性
    这是唯一暴露的公共方法

    Args:
      html: 要提取的html字符串
      includes: 可选的CSS选择器列表，用于在body之后进一步过滤内容，支持多个选择器
      excludes: 可选的CSS选择器列表，用于排除指定的元素，在includes计算后立即执行，支持多个选择器

    Returns:
      dict: 包含以下键的字典
        - html: 解析后的html
        - char_size: 解析后的html长度
        - token_size: 解析后的html token长度
    """
    if not html or not isinstance(html, str):
      return {"html": "", "char_size": 0, "token_size": 0}

    html = self._body(html, includes, excludes)
    html = self._shake(html)
    html = self._minify(html)

    char_size = len(html)
    token_size = -1

    return {
      "html": html,
      "char_size": char_size,
      "token_size": token_size
    }

  def _filter_by_css_selectors(self, soup, css_selectors: list[str]) -> BeautifulSoup:
    """
    根据CSS选择器列表过滤HTML内容

    Args:
      soup: BeautifulSoup对象
      css_selectors: CSS选择器列表

    Returns:
      过滤后的BeautifulSoup对象
    """
    if not css_selectors:
      return soup

    try:
      new_soup = BeautifulSoup('<div></div>', 'html.parser')
      container = new_soup.div

      for selector in css_selectors:
        if selector:
          selected_elements = soup.select(selector)
          for element in selected_elements:
            container.append(element)

      if len(container.contents) > 0:
        return new_soup
    except Exception as e:
      pass

    return soup

  def _exclude_by_css_selectors(self, soup, css_selectors: list[str]) -> BeautifulSoup:
    """
    根据CSS选择器列表排除HTML内容

    Args:
      soup: BeautifulSoup对象
      css_selectors: CSS选择器列表

    Returns:
      排除指定元素后的BeautifulSoup对象
    """
    if not css_selectors:
      return soup

    try:
      for selector in css_selectors:
        if selector:
          for element in soup.select(selector):
            element.decompose()
    except Exception as e:
      pass

    return soup

  def _body(self, html: str, includes: list[str] = [], excludes: list[str] = []) -> str:
    """
    提取html的body内容
    - 提取body标签内容
    - 如果提供了includes选择器列表，先使用这些选择器过滤内容
    - 如果提供了excludes选择器列表，在includes过滤后立即执行排除操作
    - 移除指定的不需要的标签：style、script、iframe、frame、canvas、svg
    - 移除所有注释

    Args:
      html: HTML字符串
      includes: CSS选择器列表（包含）
      excludes: CSS选择器列表（排除）

    Returns:
      处理后的HTML字符串
    """
    if not html or not isinstance(html, str):
      return ""

    soup = BeautifulSoup(html, 'html.parser')

    body = soup.body
    if body:
      soup = BeautifulSoup(str(body), 'html.parser')

    if includes:
      soup = self._filter_by_css_selectors(soup, includes)

    if excludes:
      soup = self._exclude_by_css_selectors(soup, excludes)

    tags_to_remove = ['style', 'script', 'iframe', 'frame', 'canvas', 'svg', 'footer', 'aside']

    for tag_name in tags_to_remove:
      for tag in soup(tag_name):
        tag.decompose()

    for comment in soup.find_all(string=lambda text: isinstance(text, Comment)):
      comment.extract()

    return str(soup)

  def _shake(self, html: str) -> str:
    """
    移除非必要属性，减少总字符数量
    - 移除所有标签内的非必要属性，例如 style class id 等
    - 保留某些必须的属性，例如 href src alt 等
    - 移除样式类标签 strong、b、i，但保留标签内的文本内容
    - 移除base64类型的img标签（src属性以data:image/开头）

    Args:
      html: HTML字符串

    Returns:
      处理后的HTML字符串
    """
    if not html or not isinstance(html, str):
      return ""

    keep_attributes = {'href', 'src', 'alt', 'title'}

    soup = BeautifulSoup(html, 'html.parser')

    style_tags = ['strong', 'b', 'i']
    for tag_name in style_tags:
      for tag in soup.find_all(tag_name):
        tag.unwrap()

    for img in soup.find_all('img'):
      src = img.get('src', '')
      if src.lower().startswith('data:image/'):
        img.decompose()

    for tag in soup.find_all(True):
      new_attrs = {}
      for attr, value in tag.attrs.items():
        if attr.lower() in keep_attributes:
          new_attrs[attr] = value
      tag.attrs = new_attrs

    return str(soup)

  def _minify(self, html: str) -> str:
    """
    最小化HTML内容
    - 移除所有不必要的空白
    - 移除所有注释
    - 压缩标签间的空白

    Args:
      html: HTML字符串

    Returns:
      压缩后的HTML字符串
    """
    if not html or not isinstance(html, str):
      return ""

    html = re.sub(r'<!--.*?-->', '', html, flags=re.DOTALL)
    html = re.sub(r'\s+', ' ', html)
    html = re.sub(r'>\s+<', '><', html)
    html = html.strip()

    return html
