import importlib
import inspect
import logging
import pkgutil

class AbilityScanner:

  _logger = logging.getLogger('airflow.task')

  @classmethod
  def scan(cls, package_name: str, base_class: type, context) -> dict[str, any]:
    package = importlib.import_module(package_name)
    all_subclasses: list[type] = []

    for _importer, modname, _ispkg in pkgutil.walk_packages(
      package.__path__, package.__name__ + '.'
    ):
      try:
        module = importlib.import_module(modname)
      except Exception as e:
        cls._logger.debug('Skipping %s: %s', modname, e)
        continue

      for name, obj in inspect.getmembers(module, inspect.isclass):
        if obj is base_class:
          continue
        if issubclass(obj, base_class):
          all_subclasses.append(obj)

    leaf_classes = [
      cls for cls in all_subclasses
      if not any(other is not cls and issubclass(other, cls) for other in all_subclasses)
    ]

    return {cls.__name__: cls(context) for cls in leaf_classes}
