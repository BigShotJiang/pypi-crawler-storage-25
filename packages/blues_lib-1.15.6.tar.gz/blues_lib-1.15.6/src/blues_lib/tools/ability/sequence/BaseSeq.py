import logging
from abc import ABC
from blues_lib.tools.ability.sequence.IterationHelper import IterationHelper
from blues_lib.types import SeqOpts, ToolSummary, ToolDef, SkipSeqError
from blues_lib.tools.context import TaskContext

class BaseSeq(ABC):
  
  _TOOLS_KEY:str = 'tools'
  _SUMMARY_KEY:str = ''
  
  def __init__(self,context:TaskContext):
    self._context:TaskContext = context
    self._executor_instance = None
    self._iter_helper = IterationHelper(context.driver)
    self._logger = logging.getLogger('airflow.task')
    self._seq_opts:SeqOpts = {}
    self._tool_summary:ToolSummary = {}

  def _prepare(self,options:SeqOpts)->None:
    self._seq_opts = options 
    self._tool_summary = self._seq_opts.get(self._SUMMARY_KEY) or {}
    from blues_lib.tools.runner import AbilityExecutor
    self._executor_instance = AbilityExecutor
  
  def _cast(self,tool_defs:list[ToolDef])->dict[str,any]:
    # avoid to recursively import 
    # craete a new context for children tools (reuse the driver)
    sub_context = TaskContext({"driver":self._context.driver})
    executor = self._executor_instance(sub_context)
    try:
      return executor.execute(tool_defs)
    except SkipSeqError as e:
      self._logger.warning(e)
      result:dict = sub_context.result
      return {
        **result,
        '_skip':str(e)
      }