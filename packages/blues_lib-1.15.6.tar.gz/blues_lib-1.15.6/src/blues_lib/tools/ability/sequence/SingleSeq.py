from blues_lib.tools.ability.sequence.BaseSeq import BaseSeq
from blues_lib.types import SeqOpts,ToolDef
from blues_lib.utils.jinja2 import Jinja2Renderer

class SingleSeq(BaseSeq):
  
  _SUMMARY_KEY:str = 'single'

  # Public API Alias
  def cast(self,options:SeqOpts)->dict[str,any]:
    return self.cast_single(options)

  # Public API  
  def cast_single(self,options:SeqOpts)->dict[str,any]:
    self._prepare(options)
    return self._process()
    
  def _process(self)->None:
    tool_defs:list[ToolDef] = self._seq_opts.get(self._TOOLS_KEY,[])
    # like page item
    attempt_item:dict = self._tool_summary.get('attempt_item') or {}
    # render for page item
    if attempt_item:
      tool_defs = Jinja2Renderer.render_loop(tool_defs,attempt_item) 
    return self._cast(tool_defs)
