from blues_lib.tools.ability.atom.webdriver.QuerierAbility import QuerierAbility
from blues_lib.tools.ability.atom.webdriver.interaction.JavaScript import JavaScript
from blues_lib.tools.ability.atom.webdriver.action.Keyboard import Keyboard
from blues_lib.tools.context import TaskContext

class InterBase(QuerierAbility):
  """
  Interaction class to interact with element.
  Reference : https://www.selenium.dev/documentation/webdriver/elements/interactions/
  """
  
  def __init__(self,context:TaskContext):
    super().__init__(context)
    self._javascript = JavaScript(context)
    self._keyboard = Keyboard(context)
