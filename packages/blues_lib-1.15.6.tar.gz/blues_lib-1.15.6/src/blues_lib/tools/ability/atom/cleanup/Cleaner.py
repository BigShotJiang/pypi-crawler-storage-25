from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.services.cleaner import DirCleaner, DBCleaner
from blues_lib.types import STDOut, CleanOpts

class Cleaner(BaseAbility):

  def clean(self,options:dict)->STDOut:
    value:CleanOpts = options.get('value',{})
    db_count = DBCleaner(value).clean()
    dir_count = DirCleaner(value).clean()
    return STDOut(200,'ok',{'db':db_count,'dir':dir_count})

