import re
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.matcher.MatcherAbility import MatcherAbility


class ElemAttrMatcher(MatcherAbility):

  def elem_attr_to_equal(self, options: dict) -> bool:
    value, expected = self._get_expected_pair(options)
    return value == expected

  def elem_attr_to_search(self, options: dict) -> bool:
    value, expected = self._get_expected_pair(options)
    return bool(re.search(expected, value))

  def elem_attr_to_match(self, options: dict) -> bool:
    value, expected = self._get_expected_pair(options)
    return bool(re.match(expected, value))

  def _get_expected_pair(self, options: dict) -> tuple[str, str]:
    elem: WebElement | None = self._querier.query_element(options)
    value = elem.get_attribute(options.get('value')).strip() if elem else ''
    expected = str(options.get('expected')).strip()
    return value, expected
