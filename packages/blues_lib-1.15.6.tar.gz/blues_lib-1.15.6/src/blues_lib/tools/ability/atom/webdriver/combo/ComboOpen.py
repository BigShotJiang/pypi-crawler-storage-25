from blues_lib.tools.ability.atom.webdriver.combo.ComboBase import ComboBase
from blues_lib.types import ToolDef

class ComboOpen(ComboBase):

  def open_and_click(self,options:dict)->bool:
    tools:list[ToolDef] = []
    self.__add_open_tool(options,tools)
    self._add_click_seq_tool(options,tools,'post_click')
    result:dict = self._exec_tools(tools)
    return self._get_result(result)
  
  def __add_open_tool(self,options:dict,tools:list[ToolDef])->None:
    url:str = options.get('url') or ''
    open_tool:ToolDef = {
      "name":"open",
      "options":{
        "value":url,
        "style":options.get('style') or '',
      }
    }
    tools.append(open_tool)
