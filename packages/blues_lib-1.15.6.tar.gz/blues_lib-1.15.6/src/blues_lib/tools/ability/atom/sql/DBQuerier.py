from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.types import SQLOpts, SQLCondition, SQLPagination, SQLOrder, STDOut
from blues_lib.services.sql import SQLQuerier as ServiceSQLQuerier
from blues_lib.tools.ability.atom.sql.SQLHelper import SQLHelper

class DBQuerier(BaseAbility):

  _DEFAULT_PAGINATION:SQLPagination = {
    'no':1,
    'size':1
  }

  def sql_query(self,options:SQLOpts)->list[dict]:
    table:str = options.get('table')
    conditions:list[SQLCondition] = SQLHelper.get_conditions(options)
    fields:list[str] = options.get('fields',[])
    pagination:SQLPagination = options.get('page') or self._DEFAULT_PAGINATION
    orders:list[SQLOrder] = options.get('orders') or []
    querier = ServiceSQLQuerier(table)
    stdout:STDOut = querier.get(fields,conditions,orders,pagination)
    return stdout.data or []
