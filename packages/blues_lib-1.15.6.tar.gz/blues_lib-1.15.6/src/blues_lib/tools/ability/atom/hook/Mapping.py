from typing import Any
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.ability.atom.hook.XComMapper import XComMapper

class Mapping(BaseAbility): 

  def xcom_map(self,opts:dict)->bool: 
    mappings:list[list[str]] = opts.get('value') or []
    ti:Any = opts.get('ti')
    xcom_biz:dict|None = opts.get('xcom_biz')
    return self._map(mappings,ti,xcom_biz)
    
  def _map(self,mappings:list[list[str]],ti:Any,xcom_biz:dict|None)->bool:
    if not mappings or not ti:
      self._logger.warning(f'{self.__class__.__name__} :  mappings or ti is None')
      return False
    if xcom_biz is None:
      self._logger.warning(f'{self.__class__.__name__} :  xcom_biz is None')
      return False

    map_count:int = 0    
    for mapping_item in mappings:
      if len(mapping_item)<2:
        continue
      
      callback:str = mapping_item[2] if len(mapping_item)>2 else ''
      mapping:dict = {
        'source':mapping_item[0],
        'target':mapping_item[1],
      }
      if callback:
        mapping['callback'] = callback

      is_success:bool = XComMapper(mapping,xcom_biz,ti).handle()
      if is_success:
        map_count += 1

    return True if map_count>0 else False
