from blues_lib.tools.ability.atom.webdriver.combo.ComboBase import ComboBase
from blues_lib.types import ToolDef

class ComboForm(ComboBase):

  def fillin_form(self,options:dict)->bool:
    tools:list[ToolDef] = []
    self._add_click_seq_tool(options,tools,'prev_click')
    self.__add_input_tools(options,tools)
    self._add_click_seq_tool(options,tools,'post_click')

    # must add frame before check
    self.__add_frame_tool(options,tools)

    self._add_check_tool(options,tools)

    result:dict = self.__exec_tools(tools) if len(tools) > 0 else {}
    return self._get_result(result)

  def __exec_tools(self,tools:list[ToolDef])->dict:
    from blues_lib.tools.runner import AbilityExecutor
    return AbilityExecutor(self._context).execute(tools)
    
  def __add_input_tools(self,options:dict,tools:list[ToolDef])->None:
    input_tools:list[ToolDef] = self._get_input_tools(options)
    tools.extend(input_tools)

  def __add_frame_tool(self,options:dict,tools:list[ToolDef])->None:
    base_opts:dict = self._get_base_opts(options)
    target:str = options.get('frame') or ''
    if not target:
      return

    in_tool:ToolDef = {
      "name":"switch_to_frame",
      "options":{
        **base_opts,
        "target":target,
      }
    }
    tools.insert(0,in_tool)

    out_tool:ToolDef = {
      "name":"switch_to_default_content",
    }
    tools.append(out_tool)
