from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.types import SQLOpts, SQLCondition, STDOut
from blues_lib.services.sql import SQLMutator
from blues_lib.tools.ability.atom.sql.SQLHelper import SQLHelper

class DBUpdater(BaseAbility):

  def sql_update(self,options:SQLOpts)->STDOut:
    table:str = options.get('table')
    entity = SQLHelper.get_entity(options)
    conditions:list[SQLCondition] = SQLHelper.get_conditions(options,entity)

    mutator = SQLMutator(table)
    return mutator.update(entity,conditions)
