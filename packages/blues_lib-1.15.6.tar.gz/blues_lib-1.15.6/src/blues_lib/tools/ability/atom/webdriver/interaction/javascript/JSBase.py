from typing import Any
import requests,time
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.webdriver.QuerierAbility import QuerierAbility
from blues_lib.tools.ability.atom.webdriver.interaction.Alerts import Alerts

class JSBase(QuerierAbility):
  """
  Executes JavaScript code snippet in the current context of a selected frame or window.
  Reference : https://www.selenium.dev/documentation/webdriver/interactions/windows/#execute-script
  """

  def execute_script(self,options:dict)->Any:
    '''
    Execute the jvascript script
    Args:
      options (dict): the javascript options
    Returns:
      The return value of the javascript script.
    '''
    value:str = options.get('value')
    if not value:
      return None
    args:list = options.get('args') or []
    return self._driver.execute_script(value,*args)
    
  def execute_async_script(self,options:dict)->Any:
    '''
    Execute the javascript script asynchronously.
    Args:
      options (dict): the javascript options
    Returns:
      The return value of the javascript script.
    '''
    value:str = options.get('value')
    if not value:
      return None
    args:list = options.get('args') or []
    return self._driver.execute_async_script(value,*args)

  def load_and_execute_script(self,options:dict)->Any:
    '''
    Execute the javascript script online.
    Args:
      options (dict): the javascript options
    Returns:
      The return value of the javascript script.
    '''
    value:str = options.get('value')
    if not value:
      return None
    response = requests.get(url = value)
    return self.execute_script({'value':response.text})
  
  def alert(self,options:dict)->bool:
    '''
    Popup the alert dialog
    Args:
      options (dict): the alert options
    Returns:
      None : alert return undefined in js
    '''
    options = self._get_ability_options(options)
    value:str = options.get('value')
    if not value:
      return False

    script:str = f'return alert(`{value}`);'
    self.execute_script({'value':script})

    duration:int|float = options.get('duration')
    # don't close when the duration is -1
    if duration > 0:
      time.sleep(duration)
      alerts = Alerts(self._context)
      alerts.switch_to_alert()
      alerts.accept_alert()
    return True

  def get_document_size(self):
    script = 'return {width:document.documentElement.offsetWidth,height:document.documentElement.offsetHeight};'
    return self.execute_script({'value':script})

  def _set_document(self,options:dict)->bool: 
    '''
    Set the document content by javascript script
    Args:
      options (dict): the document options
    Returns:
      bool : 
    '''
    script:str = options.get('value')
    if not script:
      return False

    elem:WebElement|None = self._querier.query_element(options)
    if not elem:
      return False

    options = {
      'value':script,
      'args':[elem],
    }
    self.execute_script(options)
    return True

  def _set_document_for_elements(self,options:dict)->bool: 
    script:str = options.get('value')
    if not script:
      return False

    elems:list[WebElement]|None = self._querier.query_elements(options)
    if not elems:
      return False

    options = {
      'value':script,
      'args':[elems],
    }
    self.execute_script(options)
    return True