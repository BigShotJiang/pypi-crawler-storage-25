import re
from selenium.webdriver.remote.webelement import WebElement
from blues_lib.tools.ability.atom.webdriver.element.information.InfoBase import InfoBase
from blues_lib.utils.file import FileWriter

class InfoAttr(InfoBase):

  def get_text(self,options:dict)->str|list[str]:
    '''
    Fetching element's text node value
    Args:
      options (dict) : the element query options
    Returns:
      str|list[str]
    '''
    elem:WebElement|None = self._querier.query_element(options)
    if not elem:
      return ''

    inline:bool = options.get('inline',False)
    max_length:int = int(options.get('max_length') or -1)

    replacement:str = '' if inline else '\n'
    text = elem.text.strip()

    MULTI_NEWLINE_PATTERN = re.compile(r'\n+')
    text = MULTI_NEWLINE_PATTERN.sub(replacement, text)

    if max_length>0 and len(text)>max_length:
      text = text[:max_length]+'...'

    return FileWriter.write_or_return(options,text)

  def get_texts(self,options:dict)->list[str]:
    text:str = self.get_text(options)
    lines:list[str] = []
    if text:
      lines = text.split('\n')
    return FileWriter.write_or_return(options,lines)

  def get_tag_name(self,options:dict)->str:
    '''
    Fetching element's tag name
    Args:
      options (dict) : the element query options
    Returns:
      str         
    '''
    elem:WebElement|None = self._querier.query_element(options)
    return elem.tag_name if elem else ''
  
  def get_property(self,options:dict)->str|bool|None:
    '''
    Get element's property value
    Args:
      options (dict) : the element query options
    Returns:
      str|bool|None
    '''
    key:str = options.get('value','')
    elem:WebElement|None = self._querier.query_element(options)
    return elem.get_property(key) if elem else None

  def get_attribute(self,options:dict)->str:
    '''
    Fetching Attributes or Properties ： Get the value of the specified attribute or property of the element.
    Args:
      options (dict) : the element query options
    Returns:
      str
    '''
    key:str = options.get('value','')
    elem:WebElement|None = self._querier.query_element(options)
    return elem.get_attribute(key) if elem else ''

  def value_of_css_property(self,options:dict)->str:
    '''
    Fetching element's css attr's value
    Args:
      options (dict) : the element query options
    Returns:
      str
    '''
    key:str = options.get('value','')
    elem:WebElement|None = self._querier.query_element(options)
    return elem.value_of_css_property(key) if elem else ''

  def get_value(self,options:dict)->str:
    '''
    Fetching form element's value ： 
    Args:
      options (dict) : the element query options
    Returns:
      str         
    '''
    options['value']='value'
    return self.get_attribute(options) or ''

  def get_inner_html(self,options:dict)->str:
    '''
    Fetching element's text node value
    Args:
      options (dict) : the element query options
    Returns:
      str         
    '''
    options['value']='innerHTML'
    html:str|None = self.get_attribute(options)
    return html.strip() if html else ''

  def get_outer_html(self,options:dict)->str:
    '''
    Fetching element's outer html value
    Args:
      options (dict) : the element query options
    Returns:
      str          
    '''
    options['value']='outerHTML'
    html:str|None = self.get_attribute(options)
    return html.strip() if html else ''

  def get_srcs(self,options:dict)->list[str]:
    '''
    Get all img urls from multiple elements
    Args:
      options (dict) : the element query options
    Returns:
      list[str] : the url list
    '''
    elems:list[WebElement]|None = self._querier.query_elements(options)
    if not elems:
      return []
    
    urls = []
    for elem in elems:
      if url := elem.get_attribute('src'):
        urls.append(url)
    return urls

  def get_src(self,options:dict)->str:
    elem:WebElement|None = self._querier.query_element(options)
    if not elem:
      return ''
    return elem.get_attribute('src')

  def get_hrefs(self,options:dict)->list[str]:
    elems:list[WebElement]|None = self._querier.query_elements(options)
    if not elems:
      return []

    urls = []
    for elem in elems:
      if url := elem.get_attribute('href'):
        urls.append(url)
    return urls

  def get_href(self,options:dict)->str:
    elem:WebElement|None = self._querier.query_element(options)
    if not elem:
      return ''
    return elem.get_attribute('href')
