from blues_lib.tools.ability.atom.webdriver.DriverAbility import DriverAbility
from blues_lib.tools.ability.atom.webdriver.wait.Querier import Querier
from blues_lib.tools.context import TaskContext

class QuerierAbility(DriverAbility):

  def __init__(self,context:TaskContext):
    super().__init__(context)
    self._querier = Querier(context)