from blues_lib.tools.ability.atom.matcher.MatcherAbility import MatcherAbility


class UrlMatcher(MatcherAbility):

  def url_to_match(self,options:dict)->bool:
    return self._ec.url_matches(options)
