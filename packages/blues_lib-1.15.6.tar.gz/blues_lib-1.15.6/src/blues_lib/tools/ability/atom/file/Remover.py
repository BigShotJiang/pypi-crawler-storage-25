from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.utils.file import FileRemover

class Remover(BaseAbility):

  def remove_dirs(self,options:dict)->str:
    directory:str = options.get("absdir","")
    retention_days:int = options.get("retention_days",0)
    return FileRemover.remove_dirs(directory,retention_days)

  def remove_files(self,options:dict)->str:
    directory:str = options.get("absdir","")
    retention_days:int = options.get("retention_days",0)
    return FileRemover.remove_files(directory,retention_days)

  def remove_file(self,options:dict)->str:
    file:str = options.get("absfile","")
    retention_days:int = options.get("retention_days",0)
    return FileRemover.remove_file(file,retention_days)
