import re
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.common.exceptions import NoSuchElementException 
from selenium.common.exceptions import ElementNotInteractableException 
from blues_lib.types import SearchContext, ElementRoot
from blues_lib.tools.ability.atom.webdriver.wait.ec.ECInfo import  ECInfo
from blues_lib.tools.ability.atom.webdriver.wait.ec.ECSwitch import ECSwitch
from blues_lib.tools.ability.atom.webdriver.wait.ec.ECElementLocated import ECElementLocated
from blues_lib.tools.ability.atom.webdriver.wait.ec.ECElementToBe import ECElementToBe
from blues_lib.tools.ability.atom.webdriver.LocatorCreator import LocatorCreator


class EC(ECInfo,ECSwitch,ECElementLocated,ECElementToBe):
  """
  official expected_conditions
  Reference: https://www.selenium.dev/documentation/webdriver/support_features/expected_conditions/
  """

  def until(self,options:dict):
    options = self._get_ability_options(options)
    callback:callable = options.get('callback')
    timeout:int|float = options.get('timeout')
    message:str = options.get('message','until failed')
    poll_frequency:int|float = options.get('poll_frequency',0.5)
    ignored_exceptions:list = options.get('ignored_exceptions',[NoSuchElementException,ElementNotInteractableException])
    
    # can return any type result
    driver_wait = WebDriverWait(self._driver,timeout,poll_frequency,ignored_exceptions)
    return driver_wait.until(callback,message)

  def __wait_for_element_attr(self, options: dict, attr_check: callable) -> bool:
    options = self._get_ability_options(options)
    timeout: int|float = options.get('timeout') or 5
    poll_frequency: int|float = options.get('poll_frequency', 0.5)
    ignored_exceptions: list = options.get('ignored_exceptions', [NoSuchElementException, ElementNotInteractableException])

    target: str = options.get('target') or ''
    name: str = options.get('name')

    if not name or not target:
      return True

    root: ElementRoot = options.get('root')
    context: SearchContext = self._get_context(root)
    locator: tuple[str, str] = LocatorCreator.create(target)

    def callback(driver: WebDriver) -> bool:
      try:
        elem: WebElement = context.find_element(*locator)
        attr_value = elem.get_attribute(name)
        return attr_check(attr_value)
      except (NoSuchElementException, ElementNotInteractableException):
        return False

    driver_wait = WebDriverWait(context, timeout, poll_frequency, ignored_exceptions)
    return driver_wait.until(callback)

  def element_not_to_have_attr(self, options: dict) -> bool:
    '''
    等待元素不拥有指定属性（即属性值为 falsy）
    '''
    attr_check = lambda attr_value: not attr_value
    return self.__wait_for_element_attr(options, attr_check)

  def element_to_have_attr(self, options: dict) -> bool:
    '''
    等待元素拥有指定属性（即属性值为 truthy）
    '''
    attr_check = lambda attr_value: bool(attr_value)
    return self.__wait_for_element_attr(options, attr_check)

  def element_attr_not_to_contain(self, options: dict) -> bool:
    '''
    等待元素属性不包含指定值
    '''
    value: str = options.get('value')
    if not value:
      return True

    attr_check = lambda attr_value: value not in (str(attr_value) or '')

    result = self.__wait_for_element_attr(options, attr_check)
    return result

  def element_attr_to_contain(self, options: dict) -> bool:
    '''
    等待元素属性包含指定值
    '''
    value: str = options.get('value')
    if not value:
      return True

    attr_check = lambda attr_value: value in (str(attr_value) or '')

    result = self.__wait_for_element_attr(options, attr_check)
    return result

  def element_attr_not_to_search(self, options: dict) -> bool:
    '''
    等待元素属性不匹配正则表达式（search 在任意位置查找）
    '''
    pattern: str = options.get('value')
    if not pattern:
      return True

    regex = re.compile(pattern)
    attr_check = lambda attr_value: not regex.search(str(attr_value) or '')

    return self.__wait_for_element_attr(options, attr_check)

  def element_attr_to_search(self, options: dict) -> bool:
    '''
    等待元素属性匹配正则表达式（search 在任意位置查找）
    Examples:
      - 开头是 "item": "^item"  -> 匹配 "item123", "item-abc"
      - 结尾是 ".js": "\\.js$"   -> 匹配 "app.js", "lib.js"
      - 包含 "test": "test"      -> 匹配 "test123", "mytest"
      - 包含 a 或 b: "a|b"       -> 匹配 "cat", "bat"
    '''
    pattern: str = options.get('value')
    if not pattern:
      return True

    regex = re.compile(pattern)
    attr_check = lambda attr_value: bool(regex.search(str(attr_value) or ''))

    return self.__wait_for_element_attr(options, attr_check)
