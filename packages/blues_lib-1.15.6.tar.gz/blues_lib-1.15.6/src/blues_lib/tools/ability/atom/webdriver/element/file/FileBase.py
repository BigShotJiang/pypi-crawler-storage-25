from blues_lib.tools.ability.atom.webdriver.element.Information import Information  
from blues_lib.tools.ability.atom.webdriver.interaction.JavaScript import JavaScript
from blues_lib.tools.ability.atom.webdriver.QuerierAbility import QuerierAbility
from blues_lib.tools.context import TaskContext

class FileBase(QuerierAbility):
  """
  File class to get element information.
  Reference : https://www.selenium.dev/documentation/webdriver/elements/information/
  """
  
  def __init__(self,context:TaskContext):
    super().__init__(context)
    self._info = Information(context)
    self._javascript = JavaScript(context)

