from blues_lib.tools.ability.atom.matcher.MatcherAbility import MatcherAbility
from blues_lib.services.expecter import Matcher

class AssertMatcher(MatcherAbility):

  def match(self,options:dict)->None:
    Matcher(self._context).match(options)
