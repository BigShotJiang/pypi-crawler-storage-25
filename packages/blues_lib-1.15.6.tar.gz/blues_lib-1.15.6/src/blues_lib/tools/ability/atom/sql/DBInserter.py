from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.types import SQLOpts, STDOut
from blues_lib.services.sql import SQLMutator
from blues_lib.tools.ability.atom.sql.SQLHelper import SQLHelper

class DBInserter(BaseAbility):

  def sql_insert(self,options:SQLOpts)->STDOut:
    table:str = options.get('table')
    entities = SQLHelper.get_entities(options)
    mutator = SQLMutator(table)
    return mutator.insert(entities)
