from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.types import SQLOpts, SQLCondition, STDOut
from blues_lib.services.sql import SQLMutator
from blues_lib.tools.ability.atom.sql.SQLHelper import SQLHelper

class DBDeleter(BaseAbility):

  def sql_delete(self,options:SQLOpts)->STDOut:
    table:str = options.get('table')
    conditions:list[SQLCondition] = SQLHelper.get_conditions(options)
    mutator = SQLMutator(table)
    return mutator.delete(conditions)
