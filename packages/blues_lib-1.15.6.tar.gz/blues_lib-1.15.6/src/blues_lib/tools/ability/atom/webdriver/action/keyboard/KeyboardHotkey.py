import pyperclip
from selenium.webdriver.common.keys import Keys
from blues_lib.tools.ability.atom.webdriver.action.keyboard.KeyboardBase import KeyboardBase

class KeyboardHotkey(KeyboardBase):

  def home(self,options:dict)->bool:
    """
    Move cursor to home of text in input or contenteditable element
    Args:
      options (dict): The element query options
    """
    options['value'] = Keys.HOME
    return self.hold_ctrl_and_press(options)

  def end(self,options:dict)->bool:
    """
    Move cursor to end of text in input or contenteditable element
    Args:
      options (dict): The element query options
    """
    options['value'] = Keys.END
    return self.hold_ctrl_and_press(options)

  def select(self,options:dict)->bool:
    """
    Select all text in input or contenteditable element
    Args:
      options (dict): The element query options
    """
    options['value'] = 'a'
    return self.hold_ctrl_and_press(options)

  def copy(self,options:dict)->bool:
    """
    Select all text then copy text in input or contenteditable element
    Args:
      options (dict): The element query options
    """
    options['value'] = 'ac'
    return self.hold_ctrl_and_press(options)

  def cut(self,options:dict)->bool:
    """
    Select all text then cut text in input or contenteditable element
    Args:
      options (dict): The element query options
    """
    options['value'] = 'ax'
    return self.hold_ctrl_and_press(options)

  def paste(self,options:dict)->bool:
    """
    Move cursor to end of text then paste text in input or contenteditable element
    Args:
      value (list[str]|str|None): The value to paste, if is empty copy from clipboard
      options (dict): The element query options
    """
    value:list[str]|str|None = options.get('value')
    if value:
      lines:str = self._get_lines(value,options)
      pyperclip.copy(lines) # write to clipboard

    options['value'] = [Keys.END,"v"]
    return self.hold_ctrl_and_press(options)

  def newline_and_paste(self,options:dict)->bool:
    self.press({'value':'\n'})
    return self.paste(options)

  def paste_and_newline(self,options:dict)->bool:
    self.paste(options)
    return self.press({'value':'\n'})

  def clear(self,options:dict)->bool:
    """
    Select all text then delete text in input or contenteditable element
    Args:
      options (dict): The element query options
    """
    options['value'] = ["a",Keys.BACKSPACE]
    self.hold_ctrl_and_press(options)

  def clear_and_paste(self,options:dict)->bool:
    """
    Select all text then paste text in input or contenteditable element
    Args:
      value (list[str]|str|None): The value to paste, if is empty copy from clipboard
      options (dict): The element query options
    """
    value:list[str]|str|None = options.get('value')
    if value:
      lines:str = self._get_lines(value,options)
      pyperclip.copy(lines) # write to clipboard

    options['value'] = "av"
    return self.hold_ctrl_and_press(options)

  def _get_lines(self,value:list[str]|str,options:dict)->str:
    # three kind of line feed count
    prefix_lf:int = options.get('prefix_lf',0)
    segment_lf:int = options.get('segment_lf',0)
    suffix_lf:int = options.get('suffix_lf',0)

    texts:list[str] = value if isinstance(value,list) else [value]
    texts = [str(text) for text in texts]

    if prefix_lf>0:
      texts[0] = '\n'*prefix_lf + texts[0]
    if suffix_lf>0:
      texts[-1] += '\n'*suffix_lf

    lf_chars:str = '\n'*segment_lf if segment_lf>0 else ''
    return lf_chars.join(texts)
