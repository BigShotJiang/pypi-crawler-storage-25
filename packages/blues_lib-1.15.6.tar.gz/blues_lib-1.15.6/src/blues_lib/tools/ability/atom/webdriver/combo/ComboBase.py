from abc import ABC
from blues_lib.tools.ability.atom.webdriver.DriverAbility import DriverAbility
from blues_lib.types import ToolDef

class ComboBase(DriverAbility,ABC):
  """
  a sequence of actions to operate.
  """
  _CHECK_KEY:str = '__check_status'

  def _exec_tools(self,tools:list[ToolDef])->dict:
    from blues_lib.tools.runner import AbilityExecutor
    return AbilityExecutor(self._context).execute(tools)
    
  def _get_result(self,result:dict)->bool:
    if not result:
      return False
    if self._CHECK_KEY in result:
      return result[self._CHECK_KEY]
    return True

  def _get_input_tools(self,options:dict,name:str='send_keys',key:str='inputs')->list[ToolDef]:
    inputs:list[list[str]]|list[str] = options.get(key) or []
    if not inputs:
      return []

    # support simple input format
    if not isinstance(inputs[0],list):
      inputs = [inputs]

    base_opts:dict = self._get_base_opts(options)
    tools:list[ToolDef] = []
    for target_value in inputs:
      target,value = target_value
      if not target:
        continue

      tool:ToolDef = {
        "name":name,
        "options":{
          **base_opts,
          "target":target,
          "value":value,
        }
      }
      tools.append(tool)
    return tools

  def _add_click_seq_tool(self,options:dict,tools:list[ToolDef],key:str)->None:
    base_opts:dict = self._get_base_opts(options)
    prev_click:list[str]|str = options.get(key) or ''
    if not prev_click:
      return

    tool:ToolDef = {
      "name":"click_seq",
      "options":{
        **base_opts,
        "target":prev_click,
      }
    }
    tools.append(tool)

  def _add_check_tool(self,options:dict,tools:list[ToolDef])->None:
    base_opts:dict = self._get_base_opts(options)
    target:str = options.get('post_check') or ''
    if not target:
      return

    tool:ToolDef = {
      "name":"element_to_be_visible",
      "options":{
        **base_opts,
        "id":self._CHECK_KEY,
        "target":target,
      }
    }
    tools.append(tool)

  def _get_base_opts(self,options:dict)->dict:
    root:str = options.get('root') or ''
    interval:int|float = options.get('interval') or 0.5 
    timeout:int|float = options.get('timeout') or 5
    clear:bool = options.get('clear') or False
    return {
      "root":root,
      "interval":interval,
      "timeout":timeout,
      "clear":clear,
    }