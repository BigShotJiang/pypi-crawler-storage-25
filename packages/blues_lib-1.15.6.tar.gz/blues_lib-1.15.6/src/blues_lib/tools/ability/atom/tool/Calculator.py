from typing import Any
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility


class Calculator(BaseAbility):
  
  def assign(self,options:dict)->Any:
    return options.get('value')

  def evaluate(self,options:dict)->Any:
    value:str = options.get('value')
    if not value:
      return None
    try:
      global_ns = {}
      local_ns = {}
      return eval(value,global_ns,local_ns)
    except Exception as e:
      self._logger.error(f'expression {value} eval failed: {e}')
      return None