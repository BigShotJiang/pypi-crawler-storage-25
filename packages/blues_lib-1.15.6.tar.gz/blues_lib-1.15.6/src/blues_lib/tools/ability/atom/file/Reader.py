import re
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.utils.file import File, FileReader

class Reader(BaseAbility):
  
  def item_to_exist(self,options:dict)->bool:
    item_path:str = options.get("value")
    timeout:int|float = options.get("timeout") or 5
    interval:int|float = options.get("interval") or 1
    if not item_path:
      return False
    return File.wait(item_path,timeout,interval)

  def search_regexp(self,options:dict)->bool:
    value:any = options.get("value")
    if not value:
      return False

    pattern:str = str(value)
    content:str = self.read_text(options)
    try:
      return re.search(pattern,content) is not None
    except re.error:
      return False

  def contain_text(self,options:dict)->bool:
    value:any = options.get("value")
    if not value:
      return False
    value:str = str(value)
    content:str = self.read_text(options)
    return value in content

  def read_text(self,options:dict)->str:
    options.setdefault("extension","txt")
    file_path:str = File.get_abs_file(options)
    return FileReader.read_text(file_path)
  
  def read_json(self,options:dict)->str:
    options.setdefault("extension","json")
    file_path:str = File.get_abs_file(options)
    return FileReader.read_json(file_path)

  def read_csv(self,options:dict)->str:
    options.setdefault("extension","csv")
    file_path:str = File.get_abs_file(options)
    return FileReader.read_csv(file_path)
