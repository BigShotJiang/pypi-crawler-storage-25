import re
from blues_lib.types import SQLCondition,SQLOpts,SQLFilter

class SQLHelper():

  @classmethod
  def get_conditions(cls,sql_opts:SQLOpts,entity:dict|None=None)->list[SQLCondition]:
    conditions = sql_opts.get('conditions',[])
    if not conditions:
      return []

    if not entity:
      return conditions
      
    for condition in conditions:
      if condition.get('value') == '{{field}}':
        condition['value'] = entity.get(condition.get('field'))

    return conditions
  
  @classmethod
  def get_entity(cls,sql_opts:SQLOpts)->dict:
    entity:dict = sql_opts.get('entity',{})
    return cls.clean([entity],sql_opts)[0]

  @classmethod
  def get_entities(cls,sql_opts:SQLOpts)->list[dict]:
    entities:list[dict] = sql_opts.get('entities',[])
    return cls.clean(entities,sql_opts)

  @classmethod
  def clean(cls,entities:list[dict],sql_opts:SQLOpts)->list[dict]:
    merged:list[dict] = cls.merge(entities,sql_opts)
    return cls.filter(merged,sql_opts)
  
  @classmethod
  def merge(cls,entities:list[dict],sql_opts:SQLOpts)->list[dict]:
    constants:dict = sql_opts.get('constants',{}) 
    if not entities:
      return entities
    
    if not constants:
      return entities

    filtered:list[dict] = []
    for entity in entities:
      filtered.append({**entity,**constants})
    return filtered

  @classmethod
  def filter(cls,entities:list[dict],sql_opts:SQLOpts)->list[dict]:
    sql_filter:SQLFilter = sql_opts.get('filter',{})
    if not sql_filter:
      return entities
    
    inc_fields:list[str] = sql_filter.get('inc_fields',[])
    inc_pattern:str = sql_filter.get('inc_pattern','')
    exc_fields:list[str] = sql_filter.get('dec_fields',[])
    exc_pattern:str = sql_filter.get('dec_pattern','')

    filtered:list[dict] = []

    for entity in entities:
      filtered_entity:dict = entity.copy()
        
      # include and exclude the fields
      if inc_fields:
        filtered_entity = {k:v for k,v in filtered_entity.items() if k in inc_fields}

      if inc_pattern:
        filtered_entity = {k:v for k,v in filtered_entity.items() if re.match(inc_pattern,k)}  

      if exc_fields:
        filtered_entity = {k:v for k,v in filtered_entity.items() if k not in exc_fields}

      if exc_pattern:
        filtered_entity = {k:v for k,v in filtered_entity.items() if not re.match(exc_pattern,k)}

      filtered.append(filtered_entity)
    return filtered
    

