from deepmerge import always_merger
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.services.dpp import DPPChain

class DppEntity(BaseAbility):
  
  _DEFAULT_RULE = {
    "text": {
      "content": {
        "min_length": 200,
        "max_length": 15000,
      },
      "paras": {
        "min_length": 200,
        "max_length": 15000,
      },
    },
    "image": {
      "min_length": 1,
      "max_length": 8,
      "min_width": 300,
      "max_width": 1000,
      "min_height": 300,
      "max_height": 1000,
    },
    "unique":{
      "key":"url", 
    },
    "persist":False,
  }

  def dpp_entity(self,options:dict)->dict|None:
    entity:dict = options.get('entity',{})
    rule = always_merger.merge(self._DEFAULT_RULE, options.get('rule',{}))
    if not entity:
      return entity

    request:dict = {
      'entities': [entity],
      'rule': rule
    }
    chain = DPPChain(request)
    chain.handle()
    valid_entities = request.get('entities')
    return valid_entities[0] if valid_entities else None

  def dpp_entities(self,options:dict)->list[dict]|None:
    entities:list[dict] = options.get('entities',[])
    rule = always_merger.merge(self._DEFAULT_RULE, options.get('rule',{}))
    if not entities:
      return entities

    request:dict = {
      'entities': entities,
      'rule': rule
    }
    chain = DPPChain(request)
    chain.handle()
    valid_entities = request.get('entities')
    return valid_entities if valid_entities else None
