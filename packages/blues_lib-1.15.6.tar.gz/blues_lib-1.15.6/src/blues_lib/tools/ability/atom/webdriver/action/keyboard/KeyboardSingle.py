from selenium.webdriver.common.keys import Keys
from blues_lib.tools.ability.atom.webdriver.action.keyboard.KeyboardBase import KeyboardBase


class KeyboardSingle(KeyboardBase):

  def enter(self,options:dict)->bool:
    """
    Press enter key
    Args:
      options (dict): The element query options
    """
    key_options = {'value':Keys.ENTER}
    options = {**options,**key_options} if options else key_options
    return self.press(options)  
  def newline(self,options:dict)->bool:
    """
    Press newline key
    Args:
      options (dict): The element query options
    """
    key_options = {'value':'\n'}
    options = {**options,**key_options} if options else key_options
    return self.press(options)  

  def esc(self,options:dict|None=None)->bool:
    """
    Press escape key
    Args:
      options (dict): The element query options
    """
    key_options = {'value':Keys.ESCAPE}
    options = {**options,**key_options} if options else key_options
    return self.press(options)

  def f12(self,options:dict|None=None)->bool:
    """
    Press f12 key
    """
    key_options = {'value':Keys.F12}
    options = {**options,**key_options} if options else key_options
    return self.press(options)
  