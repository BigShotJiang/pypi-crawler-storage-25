from datetime import datetime
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.ability.atom.sql.DBWaiter import DBWaiter
from blues_lib.utils.message import EmailSender
from blues_lib.types import EmailOpts,TaskResponse

class Email(BaseAbility):
  
  def send_email(self,options:EmailOpts)->TaskResponse:
    sender:EmailSender = EmailSender.get_instance()
    return sender.send(options)

  def email_and_wait_sms_code(self,options:dict)->str:
    timestamp:str = self.email_login(options)
    options.setdefault('timeout',300)
    if not timestamp:
      self._logger.error('Failed to send login email')
      return ''
    options['timestamp'] = timestamp
    return DBWaiter(self._context).wait_sms_code(options)

  def email_login(self,options:dict)->str:
    '''
    Send a login email to the user.
    Returns:
      The timestamp(id) of the email.
    '''
    sender:EmailSender = EmailSender.get_instance()
    domain = options.get('domain')
    timeout = options.get('timeout') or 300
    timestamp:int = int(datetime.now().timestamp() * 1000)
    email_opts:EmailOpts = {
      "subject":f"Submit your {domain} login code please",
      "paras":[
        {
          "type":"text",
          "value":f"[AutoLive] An SMS code has been sent for your {domain} account re-login. Please submit it within {timeout} seconds.",
        },
        {
          "type":"link",
          "value":{
            "href":f"http://deepbluenet.com/naps-upload-code.html?site={domain}&ts={timestamp}",
            "text":"Click to open the code submit page.",
          },
        },
      ],
      'addressee':options.get('addressee'), 
      'addressee_name':options.get('addressee_name','AutoLive'),
    }
    response:TaskResponse = sender.send(email_opts)
    return str(timestamp) if response['code'] == 200 else ''
