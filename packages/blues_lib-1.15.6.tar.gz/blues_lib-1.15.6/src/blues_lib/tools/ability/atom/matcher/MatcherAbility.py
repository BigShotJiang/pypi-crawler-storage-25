from blues_lib.tools.context import TaskContext
from blues_lib.tools.ability.atom.webdriver.QuerierAbility import QuerierAbility
from blues_lib.tools.ability.atom.webdriver.wait.EC import EC


class MatcherAbility(QuerierAbility):

  def __init__(self, context: TaskContext):
    super().__init__(context)
    self._ec = EC(context)
