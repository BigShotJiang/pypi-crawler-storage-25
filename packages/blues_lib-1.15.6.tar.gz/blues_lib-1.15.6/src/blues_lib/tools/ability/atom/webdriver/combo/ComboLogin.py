from blues_lib.tools.ability.atom.webdriver.combo.ComboBase import ComboBase
from blues_lib.types import ToolDef

class ComboLogin(ComboBase):

  def login_check(self,options:dict)->bool:
    tools:list[ToolDef] = []
    self.__add_open_and_cookie_tool(options,tools)
    self._add_check_tool(options,tools)
    result:dict = self._exec_tools(tools)
    return self._get_result(result)
  
  def __add_open_and_cookie_tool(self,options:dict,tools:list[ToolDef])->None:
    login_url:str = options.get('login_url') or ''
    logged_url:str = options.get('logged_url') or ''

    open_tool:ToolDef = {
      "name":"open",
      "options":{
        "value":login_url,
      }
    }
    cookie_tool:ToolDef = {
      "name":"read_and_add_cookies",
    }
    reopen_tool:ToolDef = {
      "name":"open",
      "options":{
        "value":logged_url,
      }
    }
    tools.append(open_tool)
    tools.append(cookie_tool)
    tools.append(reopen_tool)
