from abc import ABC
import logging
from blues_lib.tools.context import TaskContext

class BaseAbility(ABC):

  def __init__(self,context:TaskContext):
    self._context = context
    self._logger = logging.getLogger('airflow.task')