from typing import Any
from blues_lib.types import ToolDef

class StandardDefConverter():
  '''
  Convert simplified tools options to std tools options. 
  
  Support two kind of simplified options:
  1. List of def, standard simplified format is:
    - ["name",[["target1","value1"],["target2","value2"]],extra]
  2. Dict of def, standard simplified format is:
    - ["name",{"target":".user-name","value":"liu"},extra]

  List Variants:
  - ["switch_back_default_content", "_non_opts"] # one ability and don't need options
  - ["sleep", null,{"value":3}] # one ability and don't need options, but need extra
  - ["click", [".user-name", "123"],{}] # one ability and has value opt
  - ["click", [[".user-name"], [".user-title"]],{}] # two abilities - standard format
  - ["send_keys", [[".name", "liu"],[".age", "18"]],{"timeout":10}]
  - ["send_keys", [[".name", "liu"],{"target":".name","value":"liu"}],{"timeout":10}] # dict options
  
  Dict Variants:
  - key's value support all list variants, but it's a one-dim list or dict
  '''

  @classmethod
  def convert(cls,def_list:list[Any])->list[ToolDef]:
    parts:list[Any] = (def_list + [None] * 2)[:3]
    name:str = parts[0]
    if not name:
      return []

    opts_conf:list[Any]|dict = parts[1] or []
    extra:dict = parts[2] or {}
    return cls._get_std_def_from_list(name,opts_conf,extra)

  @classmethod
  def _get_std_def_from_list(cls,name:str,opts_conf:list[str|list|dict]|str|None,extra:dict)->list[ToolDef]:
    opts_list:list[list[Any]|dict] = cls._get_opts_list(opts_conf)
    if not opts_list:
      return [{
        "name":name,
        "options":{
          **extra,
        },
      }]

    tool_defs:list[ToolDef] = []
    for opts in opts_list:
      std_def:ToolDef = cls._get_std_def(name,opts,extra)
      tool_defs.append(std_def)
    return tool_defs

  @classmethod
  def _get_std_def(cls,name:str,mixed_opts:list[Any]|dict,extra:dict)->ToolDef:
    tool_def:ToolDef = {
      'name':name,
      'options':{
        **extra,
      },
    }

    tool_opts:dict = tool_def['options']
    if isinstance(mixed_opts,dict):
      tool_def['options'] = {**tool_opts,**mixed_opts}
      return tool_def

    target:str = mixed_opts[0]
    if target:
      tool_opts['target'] = target
    if len(mixed_opts) > 1:
      tool_opts['value'] = mixed_opts[1]
    if len(mixed_opts) > 2:
      opt_extra:dict = mixed_opts[2] or {}
      tool_opts.update(opt_extra)
    return tool_def

  @classmethod
  def _get_opts_list(cls,opts_conf:dict|list[str|list|dict]|str|None)->list[list[Any]|dict]:
    '''
    Convert to a list or dict opts
    Returns: two-dim list or list of dict
    '''
    if not opts_conf:
      return []
        
    if not isinstance(opts_conf,list):
      opts_conf = [opts_conf]

    opts_list:list[list[Any]|dict] = []
    for item in opts_conf:
      if not isinstance(item,dict) and not isinstance(item,list):
        item = [item]
      opts_list.append(item)
    return opts_list
