import logging
from blues_lib.tools.runner import ScopeFacade
from blues_lib.tools.ability.atom.BaseAbility import BaseAbility
from blues_lib.tools.ability.sequence.BaseSeq import BaseSeq
from blues_lib.tools.ability.AbilityScanner import AbilityScanner
from blues_lib.tools.context import TaskContext

class AbilityFacade():

  _dynamic_ability_classes: list[type[BaseAbility]] = []

  def __init__(self, context: TaskContext | None = None) -> None:
    self._context = context
    self._logger = logging.getLogger('airflow.task')
    self._atom_facade: ScopeFacade | None = None
    self._seq_facade: ScopeFacade | None = None
    self._dynamic_facade: ScopeFacade | None = None

  def execute(self, method: str, options: dict | None = None) -> any:
    if not self._context:
      context_meta: dict | None = options.get('context')
      self._context = TaskContext(context_meta)
    return self._cast(method, options)

  def _cast(self, method: str, options: dict | None = None) -> any:
    if self._atom_facade is None:
      _atom_provider = lambda ctx: AbilityScanner.scan('blues_lib.tools.ability.atom', BaseAbility, ctx)
      _seq_provider = lambda ctx: AbilityScanner.scan('blues_lib.tools.ability.sequence', BaseSeq, ctx)
      self._atom_facade = ScopeFacade(self._context, _atom_provider)
      self._seq_facade = ScopeFacade(self._context, _seq_provider)
      self._dynamic_facade = ScopeFacade(self._context, self._get_dynamic_abilities)

    if self._dynamic_facade.has(method):
      return self._dynamic_facade.execute(method, options)
    elif self._atom_facade.has(method):
      return self._atom_facade.execute(method, options)
    elif self._seq_facade.has(method):
      return self._seq_facade.execute(method, options)
    else:
      self._logger.error(f'Unknown method: {method}')
      return None

  def clear(self):
    self._context.teardown()

  @classmethod
  def _get_dynamic_abilities(cls, context: TaskContext) -> dict[str, BaseAbility]:
    insts: dict[str, BaseAbility] = {}
    for ability_cls in cls._dynamic_ability_classes:
      name: str = ability_cls.__name__
      if name in insts:
        continue
      insts[name] = ability_cls(context)
    return insts

  @classmethod
  def register(cls, ability_classes: list[type[BaseAbility]] | type[BaseAbility]):
    classes = ability_classes if isinstance(ability_classes, list) else [ability_classes]
    cls._dynamic_ability_classes.extend(classes)
