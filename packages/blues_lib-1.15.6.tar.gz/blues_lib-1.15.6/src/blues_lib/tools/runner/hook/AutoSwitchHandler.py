from blues_lib.tools.runner.hook.HookHandler import HookHandler
from blues_lib.types import ToolDef

class AutoSwitchHandler(HookHandler):

  _SWITCH_NAME_HASH = {
    'switch_to_frame': 'switch_to_default_content',
    'switch_to_next_content': 'close_and_switch_to_first_content',
    'switch_to_new_tab': 'close_and_switch_to_first_content',
    'switch_to_new_window': 'close_and_switch_to_first_content',
  }

  def handle(self) -> None:
    self._add_switch_tools()

  def _add_switch_tools(self) -> None:
    for name in self._prev_tool_names:
      tool_name: str = self._SWITCH_NAME_HASH.get(name, '')
      if not tool_name:
        continue
      self._add_tool(tool_name, self._post_tools, self._post_tool_names)
      self._add_tool(tool_name, self._skip_loop_tools, self._skip_loop_tool_names)
      self._add_tool(tool_name, self._skip_seq_tools, self._skip_seq_tool_names)
      self._add_tool(tool_name, self._block_seq_tools, self._block_seq_tool_names)

  def _add_tool(self, tool_name: str, tools: list[ToolDef], names: list[str]):
    if tool_name not in names:
      tools.append({
        'name': tool_name,
      })
