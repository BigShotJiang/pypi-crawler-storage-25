from typing import Any
from copy import deepcopy
from blues_lib.utils.resource import ResourceReader
from blues_lib.utils.jinja2 import Jinja2Renderer
from blues_lib.types import ToolDef

class MetaLoader:

  _TOOL_KEYS = ['tools', 'prev_tools', 'post_tools', 'skip_loop_tools', 'skip_seq_tools', 'block_seq_tools']
  _TASK_TOOL_KEY = 'tools'

  @classmethod
  def repeat(cls,resource:dict|str,repeat_by:int|list=0)->list[tuple[dict|None,dict]]:
    orig_meta:dict = ResourceReader.load(resource)
    repeat_items:list[tuple[dict,dict]] = cls.__get_repeat_items(orig_meta,repeat_by)
    repeat_metas:list[tuple[dict,ToolDef]] = []
    for items in repeat_items:
      meta_copy:dict = deepcopy(orig_meta) # keep all replaceholders
      metas:tuple[dict,ToolDef] = cls.load(meta_copy,*items)
      repeat_metas.append(metas)
    return repeat_metas

  @classmethod
  def load(cls,resource:dict|str,context:dict|None=None,globals:dict|None=None)->tuple[ToolDef,dict]:
    '''
    Load and interpolate by iteself.
    Args:
      resource (dict|str): The resource, support three types:
        - dict: The resource is already loaded.
        - str of uri: The resource is a uri.
        - str of file path: The resource is a file path. support slash path or dot path.
      context (dict|None, optional): The context to interpolate the resource with.
      globals (dict|None, optional): The globals to interpolate the resource with.
    Returns:
      tuple[ToolDef,dict]: The meta and merged context.
    '''
    meta:ToolDef = cls.__load_and_convert(resource)
    merged_globals:dict = cls.__merge_globals(meta,globals)
    merged_ctx:dict = cls.__merge_context(meta,context)
    if merged_globals:
      meta = Jinja2Renderer.render(meta,merged_globals)
    return meta,merged_ctx

  @classmethod
  def __get_repeat_items(cls,meta:dict,repeat_by:int|list)->list[tuple[dict,dict]]:
    items:list[tuple[dict,dict]] = []
    inner_repeat_by:int|list = meta.pop('repeat_by', 1)
    if not repeat_by:
      repeat_by = inner_repeat_by
    if isinstance(repeat_by,int):
      for i in range(repeat_by):
        globals:dict = {}
        context:dict = {}
        items.append((context,globals))
    else:
      for item in repeat_by:
        if not item:
          continue
        if isinstance(item,dict):
          globals:dict = item
          context:dict = {}
          items.append((context,globals))
        elif isinstance(item,list) or isinstance(item,tuple):
          globals:dict = item[0]
          context:dict = item[1] if len(item) > 1 else {}
          items.append((context,globals))
    return items

  @classmethod
  def __merge_context(cls,meta:dict,context:dict|None=None)->dict:
    inner_ctx:dict = meta.pop('context', {})
    outer_ctx:dict = context or {}
    merged_ctx:dict = {**inner_ctx,**outer_ctx}
    return merged_ctx

  @classmethod
  def __merge_globals(cls,meta:dict,globals:dict|None=None)->dict:
    inner_globals:dict = meta.pop('globals', {})
    outer_globals:dict = globals or {}
    merged_globals:dict = {**inner_globals,**outer_globals}
    # render globals by itself
    if not merged_globals:
      return {}
    return Jinja2Renderer.render(merged_globals,merged_globals)

  @classmethod
  def __load_and_convert(cls,resource:dict|str)->dict:
    meta:dict = ResourceReader.load(resource)
    cls.convert_standard_tools(meta)
    return meta

  @classmethod
  def convert_standard_tools(cls,task_biz:dict,excludes:list[str]=[])->None:
    '''
    将简写的工具定义转换为标准的工具定义元数据，使用 ToolDefConverter.convert(value) 实现转换，并直接修改数据节点的值。
    该方法不返回任何值，仅在原数据节点上进行修改。
    
    转换规则：
    1. 递归task_biz的所有dict和list节点。
    2. 如果属性名是 _TOOL_KEYS 中的任意一个，递归调用 ToolDefConverter.convert(value) 替换此节点的值。
    3. 注意替换值后，要继续递归处理子节点。
    Args:
      task_biz (dict): 任务业务数据元数据字典
    Returns:
      None
    '''
    if not isinstance(task_biz, dict):
      return

    from blues_lib.tools.runner.convert import ToolDefConverter
    for key, value in task_biz.items():
      if key in cls._TOOL_KEYS and value is not None and key not in excludes:
        task_biz[key] = ToolDefConverter.convert(value)
        cls._process_value(task_biz[key])
      else:
        cls._process_value(value)

  @classmethod
  def _process_value(cls, value: Any) -> None:
    if isinstance(value, dict):
      cls.convert_standard_tools(value)
    elif isinstance(value, list):
      for item in value:
        cls._process_value(item)
      