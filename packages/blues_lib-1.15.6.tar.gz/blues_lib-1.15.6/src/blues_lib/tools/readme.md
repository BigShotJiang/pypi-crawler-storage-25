# Package Structure

```
tools/
├── __init__.py              (empty)
├── MockTI.py                Mock Airflow TaskInstance
├── readme.md
├── context/
│   ├── __init__.py           exports: TaskContext
│   └── TaskContext.py        Central execution context (driver, results, logging)
├── ability/
│   ├── AbilityScanner.py     Dynamic ability discovery via package scanning
│   ├── AtomAbilityDict.py    (deleted — replaced by AbilityScanner)
│   ├── SeqAbilityDict.py     (deleted — replaced by AbilityScanner)
│   ├── atom/                 Atom ability definitions (BaseAbility subclasses)
│   │   ├── BaseAbility.py
│   │   ├── tool/             Dummy, Util, Clipboard, Calculator
│   │   ├── llm/              LLMClient
│   │   ├── sql/              DBQuerier, DBInserter, DBUpdater, DBDeleter, DBWaiter
│   │   ├── cleanup/          Cleaner
│   │   ├── hook/             Sharing, Mapping
│   │   ├── script/           Python, Process
│   │   ├── file/             Reader, Writer, Remover
│   │   ├── message/          Email, DingDing
│   │   ├── dpp/              DppEntity
│   │   ├── webdriver/        Session, Finder, Information, Interaction, ...
│   │   ├── matcher/          AssertMatcher, ElementTextMatcher, ...
│   │   └── api/              (empty — dead code removed)
│   └── sequence/
│       └── cast/             Sequence ability definitions (BaseSeq subclasses)
│           ├── SingleSeq, LoopSeq, PageSeq
│           └── BaseSeq.py
└── runner/                   Execution orchestration
    ├── __init__.py            exports: ScopeFacade, AbilityFacade, AbilityExecutor, AbilityClient, AbilityHook
    ├── BaseFacade.py
    ├── ScopeFacade.py
    ├── AbilityFacade.py
    ├── AbilityExecutor.py
    ├── AbilityClient.py
    ├── AbilityHook.py
    ├── convert/               ToolDef format converters
    │   ├── __init__.py        exports: ToolDefConverter
    │   ├── ToolDefConverter.py
    │   └── StandardDefConverter.py
    └── hook/                  Hook lifecycle handlers
        ├── __init__.py
        ├── HookHandler.py
        └── AutoSwitchHandler.py
```

# Dynamic Ability Discovery

All abilities are discovered automatically at runtime by `AbilityScanner`
rather than manually registered.

**Mechanism:**

- `AbilityScanner.scan(package, base_class, context)` uses `pkgutil.walk_packages`
  to traverse all modules under a given package.
- Every class that is a subclass of `base_class` is collected.
- **Leaf detection** filters out intermediate base classes — only classes
  that are NOT further subclassed by any other discovered class are kept.
- Each leaf class is instantiated with the given context.

**Example:** `AbilityScanner.scan('blues_lib.tools.ability.atom', BaseAbility, ctx)`
walks all atom sub-packages (tool, llm, sql, ...), collects 45 leaf classes,
and returns `{"Session": Session(ctx), "Finder": Finder(ctx), ...}`.

**Benefits:**
- Adding a new ability only requires creating a `BaseAbility` subclass file.
- No manual registration in dict files.
- No import boilerplate.
- Intermediate bases (mixins, abstract classes) are automatically excluded.

# Ability Registry

48 abilities discovered dynamically (45 atom + 3 sequence).

## Atom Abilities (45)

### tool (4)
- Dummy, Util, Clipboard, Calculator

### llm (1)
- LLMClient

### sql (5)
- DBQuerier, DBInserter, DBUpdater, DBDeleter, DBWaiter

### cleanup (1)
- Cleaner

### hook (2)
- Sharing, Mapping

### script (2)
- Python, Process

### file (3)
- Reader, Writer, Remover

### message (2)
- Email, DingDing

### dpp (1)
- DppEntity

### webdriver (18)
- Session, Finder, Information, Interaction, File, Keyboard, Mouse, Wheel, JavaScript, Navigation, Window, Cookie, Alerts, Frame, Browser, EC, Querier, Combo

### matcher (6)
- AssertMatcher, ElementTextMatcher, ElementValueMatcher, ElementAttributeMatcher, ElementCountMatcher, UrlMatcher

## Sequence Abilities (3)

- SingleSeq, LoopSeq, PageSeq
