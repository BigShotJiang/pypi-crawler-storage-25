"""Chat screen — interactive conversation with a local model."""

from __future__ import annotations

import re

from rich.markup import escape

from textual.app import ComposeResult
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Input
from textual.containers import VerticalScroll
from textual.binding import Binding
from textual import work

from ..backends import InferenceBackend, get_backend


def _format_response(text: str, show_thinking: bool = False) -> str:
    """Format response, handling <think> blocks."""
    # Extract think blocks
    think_pattern = re.compile(r'<think>(.*?)</think>', re.DOTALL)
    parts = []
    last_end = 0

    for m in think_pattern.finditer(text):
        # Text before think block
        before = text[last_end:m.start()].strip()
        if before:
            for ln in before.split("\n"):
                parts.append(f"  {escape(ln)}")

        # Think block — collapsible
        think_text = m.group(1).strip()
        if show_thinking:
            parts.append("  [yellow]── thinking ──[/]")
            for ln in think_text.split("\n"):
                parts.append(f"  [dim]{escape(ln)}[/]")
            parts.append("  [yellow]── /thinking ──[/]")
        else:
            think_lines = [l for l in think_text.split("\n") if l.strip()]
            n_lines = len(think_lines)
            n_chars = len(think_text)
            parts.append(f"  [bold yellow]thought[/] [dim]({n_lines} lines, {n_chars} chars) · Ctrl+T to show[/]")

        last_end = m.end()

    # Remaining text after last think block
    remaining = text[last_end:].strip()
    if remaining:
        for ln in remaining.split("\n"):
            parts.append(f"  {escape(ln)}")

    # If no think blocks found, just format normally
    if not parts:
        for ln in text.split("\n"):
            parts.append(f"  {escape(ln)}")

    return "\n".join(parts)


def _format_streaming(text: str, show_thinking: bool = False) -> str:
    """Format streaming text, showing think blocks as they arrive."""
    open_count = text.count("<think>")
    close_count = text.count("</think>")

    if open_count > close_count:
        # Currently inside an unclosed think block
        last_open = text.rfind("<think>")
        before = text[:last_open].strip()
        thinking = text[last_open + 7:].strip()

        lines = ""
        if before:
            lines += _format_response(before, show_thinking=show_thinking) + "\n"

        think_lines = [l for l in thinking.split("\n") if l.strip()]
        n_lines = len(think_lines)
        lines += f"  [bold yellow]thinking[/] [dim]({n_lines} lines) · Ctrl+T to expand[/]\n"

        if show_thinking:
            for ln in thinking.split("\n"):
                lines += f"  [dim]{escape(ln)}[/]\n"
        else:
            # Show last 3 lines as preview so user sees activity
            for ln in think_lines[-3:]:
                display = ln[:100] + "..." if len(ln) > 100 else ln
                lines += f"  [dim]{escape(display)}[/]\n"
        return lines
    else:
        # No open think block — show response normally
        return _format_response(text, show_thinking=show_thinking)


class ChatScreen(Screen):
    DEFAULT_CSS = "ChatScreen { layout: vertical; }"

    BINDINGS = [
        Binding("ctrl+t", "toggle_thinking", "Thinking", show=True),
        Binding("escape", "app.pop_screen", "Back", show=True),
    ]

    def __init__(self, model_tag: str, backend: InferenceBackend | None = None):
        super().__init__()
        self.model_tag = model_tag
        self.backend = backend
        self._messages: list[dict] = []
        self._display: list[tuple[str, str]] = []
        self._show_thinking = False
        self._current_streaming: str | None = None  # track streaming state

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        backend_name = self.backend.name if self.backend else "detecting..."
        yield Static(
            f"  [bold]Chat — {escape(self.model_tag)}[/]  "
            f"[dim]via {backend_name} · Enter=send · Ctrl+T=toggle thinking · Esc=back[/]",
            id="chat-header",
        )
        yield VerticalScroll(Static("", id="chat-log"), id="chat-scroll")
        yield Input(placeholder="Type your message...", id="chat-input")
        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#chat-input", Input).focus()
        if self.backend is None:
            self._detect_backend()

    @work(thread=True)
    def _detect_backend(self) -> None:
        """Auto-detect an available backend."""
        backend = get_backend()
        if backend is None:
            self.app.call_from_thread(
                self.notify,
                "No inference backend found. Start Ollama or llama-server first.",
                severity="error",
                timeout=5,
            )
            return
        self.backend = backend
        self.app.call_from_thread(
            self.query_one("#chat-header", Static).update,
            f"  [bold]Chat — {escape(self.model_tag)}[/]  "
            f"[dim]via {backend.name} · Enter=send · Ctrl+T=toggle thinking · Esc=back[/]",
        )
        self.app.call_from_thread(
            self.notify,
            f"Connected to {backend.name} at {backend.base_url}",
            timeout=3,
        )

    def action_toggle_thinking(self) -> None:
        self._show_thinking = not self._show_thinking
        label = "shown" if self._show_thinking else "hidden"
        self.notify(f"Thinking blocks {label}", timeout=2)
        self._refresh_log(streaming=self._current_streaming)

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id != "chat-input":
            return
        text = event.value.strip()
        if not text:
            return
        event.input.value = ""

        self._messages.append({"role": "user", "content": text})
        self._display.append(("user", text))
        self._refresh_log(streaming="")
        self._send()

    @work(thread=True)
    def _send(self) -> None:
        """Stream response from the inference backend."""
        if self.backend is None:
            self._display.append(("assistant", "[No backend available — start Ollama or llama-server]"))
            self.app.call_from_thread(self._refresh_log)
            return

        try:
            response_text = ""

            for chunk in self.backend.stream_chat(
                self.model_tag, self._messages, timeout=120.0
            ):
                if chunk.content:
                    response_text += chunk.content
                    self.app.call_from_thread(self._refresh_log, streaming=response_text)

                if chunk.done:
                    break

            self._messages.append({"role": "assistant", "content": response_text})
            self._display.append(("assistant", response_text))
            self.app.call_from_thread(self._refresh_log)

        except ConnectionError:
            self._display.append((
                "assistant",
                f"[Cannot connect to {self.backend.name} at {self.backend.base_url} — is it running?]",
            ))
            self.app.call_from_thread(self._refresh_log)
        except TimeoutError:
            if response_text:
                self._messages.append({"role": "assistant", "content": response_text})
                self._display.append(("assistant", response_text + "\n[timeout — response may be incomplete]"))
            else:
                self._display.append(("assistant", "[Timeout — model took too long to respond]"))
            self.app.call_from_thread(self._refresh_log)
        except Exception as e:
            self._display.append(("assistant", f"[Error: {e}]"))
            self.app.call_from_thread(self._refresh_log)

    def _refresh_log(self, streaming: str | None = None) -> None:
        """Redraw the chat log."""
        self._current_streaming = streaming
        lines = ""
        for role, text in self._display:
            if role == "user":
                lines += f"\n  [bold cyan]You:[/]\n"
                for ln in text.split("\n"):
                    lines += f"  {escape(ln)}\n"
            else:
                lines += f"\n  [bold green]{escape(self.model_tag)}:[/]\n"
                lines += _format_response(text, self._show_thinking) + "\n"

        if streaming is not None:
            lines += f"\n  [bold green]{escape(self.model_tag)}:[/]\n"
            if streaming:
                lines += _format_streaming(streaming, self._show_thinking) + "\n"
            else:
                lines += "  [dim]waiting for response...[/]\n"

        self.query_one("#chat-log", Static).update(lines)

        try:
            self.query_one("#chat-scroll", VerticalScroll).scroll_end(animate=False)
        except Exception:
            pass
