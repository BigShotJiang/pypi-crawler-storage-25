from setuptools import setup, find_packages


setup(
    name='EMReport', 
    version='0.1.0',
    packages=find_packages(),
    description='A Python library for evaluating machine learning models with comprehensive reports for regression, classification, and clustering tasks.',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    author='alkiviadis',
    author_email='alkiviadisagrogiannhs@gmail.com',
    url='https://github.com/Alkiviadisss/EMReport', 
    install_requires=[
        'numpy',
        'scikit-learn',
        'pandas'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)