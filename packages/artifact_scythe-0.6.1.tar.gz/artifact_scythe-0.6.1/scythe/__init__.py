"""
Scythe - Command Line Tool for cleaning artifacts and builds
"""


__version__ = "0.6.1"
__author__ = "Eliel MENGUE"
__email__ = "mengueeliel712@gmail.com"

from scythe.cli import cli
