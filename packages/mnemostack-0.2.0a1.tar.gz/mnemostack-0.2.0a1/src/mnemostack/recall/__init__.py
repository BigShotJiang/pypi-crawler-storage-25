"""
Recall pipeline — hybrid retrieval + fusion + reranking + answer generation.

Components:
- BM25 (exact token matching)
- VectorStore (semantic search via Qdrant)
- RRF fusion (merges ranked lists)
- Reranker (optional)
- Answer generator (inference layer)

Usage:
    from mnemostack.recall import BM25, reciprocal_rank_fusion
    bm25 = BM25(documents)
    hits = bm25.search("query", limit=10)
"""

from .answer import Answer, AnswerGenerator
from .bm25 import BM25, BM25Doc, tokenize
from .expansion import QueryExpander
from .fusion import reciprocal_rank_fusion
from .retrievers import (
    BM25Retriever,
    HyDERetriever,
    MemgraphRetriever,
    Retriever,
    TemporalRetriever,
    VectorRetriever,
    extract_temporal,
)
from .pipeline import (
    ClassifyQuery,
    CuriosityBoost,
    ExactTokenRescue,
    FileStateStore,
    FreshnessBlend,
    GravityDampen,
    HubDampen,
    InhibitionOfReturn,
    InMemoryStateStore,
    Pipeline,
    PipelineContext,
    QLearningReranker,
    Stage,
    StateStore,
    build_full_pipeline,
    build_stateless_pipeline,
)
from .recaller import Recaller, RecallResult
from .render import compact_format, full_format
from .reranker import Reranker

__all__ = [
    "BM25",
    "BM25Doc",
    "tokenize",
    "reciprocal_rank_fusion",
    "Recaller",
    "RecallResult",
    "compact_format",
    "full_format",
    "QueryExpander",
    "Retriever",
    "VectorRetriever",
    "BM25Retriever",
    "HyDERetriever",
    "MemgraphRetriever",
    "TemporalRetriever",

    "extract_temporal",
    "Answer",
    "AnswerGenerator",
    "Reranker",
    "Pipeline",
    "PipelineContext",
    "Stage",
    "StateStore",
    "InMemoryStateStore",
    "FileStateStore",
    "ClassifyQuery",
    "ExactTokenRescue",
    "GravityDampen",
    "HubDampen",
    "FreshnessBlend",
    "InhibitionOfReturn",
    "CuriosityBoost",
    "QLearningReranker",
    "build_full_pipeline",
    "build_stateless_pipeline",
]
