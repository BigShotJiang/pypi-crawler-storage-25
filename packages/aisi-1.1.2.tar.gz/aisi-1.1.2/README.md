# AISI v1.1.2

**Project**: AISI
<br>**Version**: 1.1.2
<br>**OS**: OS Independent
<br>**Author**: Irakli Gzirishvili
<br>**Mail**: gziraklirex@gmail.com

**AISI** (AI Skill Infrastructure) is a python module, providing a modular framework environment for developing powerful AI-powered workflow systems in your projects.

## Installation

To use **AISI**, follow these steps:

- Open CMD and run the following command to install `pip install aisi` then restart your CMD
- To check if **AISI** is installed correctly, run the following command `aisi`

## Commands

These are the available commands you can use:

- `aisi` - To list available commands
- `aisi.init(folder, model, key)` - Initialize system
- `aisi.run(name, prompt)` - Run skill from code
- `aisi.prompt(message, skill)` - Builds a prompt for AI request
- `aisi.src(path, skill)` - Returns relative path of skill resources
- `aisi.format(type, content)` - Returns right content/code block
- `aisi.add(name)` - Add new skill to project with name e.g "Other.Skill"
- `aisi.generate(skill, prompt)` - Generate new skill for project
- `aisi.skills(must, skip) - Displays skill selection in terminal
- `aisi.models(must) - Displays model selection in terminal
- `aisi.REPLY(prompt)` - Generates reply, returns message or ""
- `aisi.FILES(prompt, path)` - Generates files with contents, returns files dict or {}
- `aisi.IMAGE(prompt, path)` - Generates image file, returns path or ""
- `aisi.VIDEO(prompt, path)` - Generates video file, returns path or ""
- `aisi.AUDIO(prompt, path)` - Generates audio file, returns path or ""
