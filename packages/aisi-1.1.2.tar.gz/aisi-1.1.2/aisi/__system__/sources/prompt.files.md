# Output Format

You must output file content blocks with this format;
Each content block should contain complete content;
Each content block MUST have filename specified above the code block;
File names MUST be specified above the relevant code blocks with numeration like this:
...

0. example.txt
```txt
... text content here ...
```

1. example.sql
```sql
... sql code here ...
```

2. example.html
```html
... html code here ...
```

... and so on.

> Note: This is the strict output response format you must comply!
