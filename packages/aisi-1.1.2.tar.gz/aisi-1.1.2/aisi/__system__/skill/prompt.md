# Definition

You are ___
You have to ___

# Consider

This is ___:

[[collectorTest]]

> Note: ___

# Required

I need you to ___.

# Rules

Follow these rules:

- ___

# Request

You must generate ___ for this user request:

[[MESSAGE]]
