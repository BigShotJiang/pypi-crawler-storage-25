from imports import *


class {{name}}:
    ####################################################################################// Load
    def run(self, message="", project="", skill=""):
        # prompt = AISI.prompt(message, "Other.Skill")
        prompt = AISI.prompt(message, skill)
        # result = AISI.run(message, "Other.Skill")

        # reply = AISI.REPLY(prompt)
        # files = AISI.FILES(prompt)
        # path = AISI.IMAGE(prompt, "folder/file.png")
        # path = AISI.VIDEO(prompt, "folder/file.mp4")
        # path = AISI.AUDIO(prompt, "folder/file.mp3")

        # info = self.__helperExample(skill)

        # ...

        return prompt

    ####################################################################################// Helpers
    def __helperExample(self, skill=""):
        # path = AISI.src("resource.txt", "Other.Skill")
        path = AISI.src("resource.txt", skill)

        return cli.read(path)
