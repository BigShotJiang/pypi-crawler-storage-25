from setuptools import setup, find_packages

setup(
    name="aisi",
    version="1.1.2",
    packages=find_packages(),
    install_requires=[
        "clight",
        "google-genai",
        "requests",
        "google",
        "anthropic",
        "openai"
    ],
    entry_points={
        "console_scripts": [
            "aisi=aisi.main:main",  # Entry point of the app
        ],
    },
    package_data={
        "aisi": [
            "main.py",
            "__init__.py",
            "__system__/imports.py",
            "__system__/index.py",
            "__system__/modules/claude.py",
            "__system__/modules/grok.py",
            "__system__/modules/openai.py",
            "__system__/modules/vertex.py",
            "__system__/skill/prompt.md",
            "__system__/skill/resource.txt",
            "__system__/skill/skill.py",
            "__system__/sources/clight.json",
            "__system__/sources/logo.ico",
            "__system__/sources/prompt.files.md",
            "__system__/sources/prompt.skill.md"
        ],
    },
    include_package_data=True,
    author="Irakli Gzirishvili",
    author_email="gziraklirex@gmail.com",
    description="AISI (AI Skill Infrastructure) is a python module, providing a modular framework environment for developing powerful AI-powered workflow systems in your projects.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/IG-onGit/AISI",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
