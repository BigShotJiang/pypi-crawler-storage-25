"""
Sync Manager v2
===============
Sincronización bidireccional entre cualquier par de almacenamientos.
"""
import os
import shutil
import tempfile
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class SyncManager:
    """Sincroniza archivos entre fuentes de almacenamiento."""

    def __init__(self, local=None, cloud=None, remote=None):
        self._local = local
        self._cloud = cloud
        self._remote = remote

    def sync(self, source: str, destination: str) -> Dict[str, Any]:
        """
        Sincroniza source → destination.
        Retorna resumen: files_synced, bytes_transferred, errors.
        """
        logger.info(f"Iniciando sync: {source} → {destination}")
        result = {"source": source, "destination": destination,
                  "files_synced": 0, "bytes_transferred": 0, "errors": []}

        try:
            src_files = self._list_source(source)
            for f in src_files:
                if f.get("is_folder"):
                    continue
                try:
                    transferred = self._transfer_file(f, source, destination)
                    if transferred > 0:
                        result["files_synced"] += 1
                        result["bytes_transferred"] += transferred
                except Exception as e:
                    result["errors"].append(str(e))
                    logger.error(f"Error transfiriendo {f.get('name')}: {e}")
        except Exception as e:
            result["errors"].append(str(e))
            logger.error(f"Error en sync: {e}")

        result["status"] = "completed" if not result["errors"] else "partial"
        logger.info(f"Sync completado: {result['files_synced']} archivos, "
                    f"{result['bytes_transferred']} bytes")
        return result

    def _list_source(self, uri: str) -> List[Dict]:
        """Lista archivos en la fuente."""
        from ..storage.unified_manager import UnifiedStorageManager
        um = UnifiedStorageManager(self._local, self._cloud, self._remote)
        return um.list_path(uri)

    def _transfer_file(self, file_info: Dict, source_uri: str, dest_uri: str) -> int:
        """Transfiere un archivo de source a dest. Retorna bytes transferidos."""
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp_path = tmp.name

        try:
            # Descargar a temp
            self._download_to_temp(file_info, source_uri, tmp_path)
            size = os.path.getsize(tmp_path)

            # Subir desde temp
            dest_path = self._build_dest_path(dest_uri, file_info["name"])
            self._upload_from_temp(tmp_path, dest_path, dest_uri)
            return size
        finally:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass

    def _download_to_temp(self, file_info: Dict, source_uri: str, tmp_path: str) -> None:
        if source_uri.startswith("local:"):
            shutil.copy2(file_info["path"], tmp_path)
        elif source_uri.startswith("gdrive:"):
            self._cloud.download_file("google_drive", file_info["file_id"], tmp_path)
        elif source_uri.startswith("dropbox:"):
            self._cloud.download_file("dropbox", file_info["path"], tmp_path)
        else:
            parts = source_uri.split(":", 2)
            if len(parts) == 3:
                self._remote.download_file(parts[1], file_info["path"], tmp_path)

    def _upload_from_temp(self, tmp_path: str, dest_path: str, dest_uri: str) -> None:
        if dest_uri.startswith("local:"):
            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            shutil.copy2(tmp_path, dest_path)
        else:
            parts = dest_uri.split(":", 2)
            if len(parts) == 3:
                self._remote.upload_file(parts[1], tmp_path, dest_path)

    def _build_dest_path(self, dest_uri: str, filename: str) -> str:
        if dest_uri.startswith("local:"):
            base = dest_uri[6:]
            return os.path.join(base, filename)
        parts = dest_uri.split(":", 2)
        if len(parts) == 3:
            return os.path.join(parts[2], filename)
        return filename
