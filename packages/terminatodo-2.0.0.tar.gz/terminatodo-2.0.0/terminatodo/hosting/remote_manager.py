"""
Remote Storage Manager v2
==========================
Gestiona servidores remotos: SFTP, FTP, HTTP/S, S3-compatible.
Persiste configuración en SQLite.
"""
import logging
import os
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class RemoteFile:
    name: str
    path: str
    is_folder: bool
    size_bytes: int
    modified: str
    server_id: str

    def to_dict(self) -> Dict:
        return asdict(self)


class RemoteStorageManager:
    """Gestiona conexiones a servidores remotos."""

    def __init__(self, db_path: str = "terminatodo.db"):
        self.db_path = db_path
        self._db = None
        self._connections: Dict[str, Any] = {}

    @property
    def db(self):
        if self._db is None:
            from ..db.database import Database
            self._db = Database(self.db_path)
        return self._db

    # ------------------------------------------------------------------
    # Gestión de servidores
    # ------------------------------------------------------------------

    def add_server(self, config: Dict) -> bool:
        """Registra un servidor remoto. Verifica conectividad antes de guardar."""
        required = ["server_id", "name", "host", "port", "protocol"]
        for field in required:
            if field not in config:
                raise ValueError(f"Campo requerido: {field}")

        # Verificar conectividad
        if not self._test_connection(config):
            logger.warning(f"No se pudo conectar a {config['host']} — guardando de todas formas")

        self.db.save_remote_server(config)
        logger.info(f"Servidor '{config['name']}' registrado")
        return True

    def list_servers(self) -> List[Dict]:
        """Lista servidores registrados."""
        return self.db.list_remote_servers()

    def remove_server(self, server_id: str) -> None:
        """Elimina un servidor registrado."""
        self._disconnect(server_id)
        self.db.delete_remote_server(server_id)

    def _get_server_config(self, server_id: str) -> Optional[Dict]:
        servers = self.db.list_remote_servers()
        for s in servers:
            if s["server_id"] == server_id:
                return s
        return None

    # ------------------------------------------------------------------
    # Operaciones de archivos
    # ------------------------------------------------------------------

    def list_files(self, server_id: str, remote_path: str = "/") -> List[RemoteFile]:
        """Lista archivos en un servidor remoto."""
        config = self._get_server_config(server_id)
        if not config:
            raise ValueError(f"Servidor '{server_id}' no encontrado")

        protocol = config["protocol"].lower()
        if protocol == "sftp":
            return self._list_sftp(config, remote_path)
        elif protocol == "ftp":
            return self._list_ftp(config, remote_path)
        elif protocol in ("http", "https"):
            return self._list_http(config, remote_path)
        elif protocol == "s3":
            return self._list_s3(config, remote_path)
        else:
            raise ValueError(f"Protocolo no soportado: {protocol}")

    def download_file(self, server_id: str, remote_path: str, local_path: str) -> bool:
        """Descarga un archivo de un servidor remoto."""
        config = self._get_server_config(server_id)
        if not config:
            return False
        protocol = config["protocol"].lower()
        try:
            if protocol == "sftp":
                return self._download_sftp(config, remote_path, local_path)
            elif protocol == "ftp":
                return self._download_ftp(config, remote_path, local_path)
            elif protocol in ("http", "https"):
                return self._download_http(config, remote_path, local_path)
            elif protocol == "s3":
                return self._download_s3(config, remote_path, local_path)
        except Exception as e:
            logger.error(f"Error descargando {remote_path}: {e}")
        return False

    def upload_file(self, server_id: str, local_path: str, remote_path: str) -> bool:
        """Sube un archivo a un servidor remoto."""
        config = self._get_server_config(server_id)
        if not config:
            return False
        protocol = config["protocol"].lower()
        try:
            if protocol == "sftp":
                return self._upload_sftp(config, local_path, remote_path)
            elif protocol == "ftp":
                return self._upload_ftp(config, local_path, remote_path)
        except Exception as e:
            logger.error(f"Error subiendo {local_path}: {e}")
        return False

    # ------------------------------------------------------------------
    # SFTP
    # ------------------------------------------------------------------

    def _get_sftp(self, config: Dict):
        sid = config["server_id"]
        if sid in self._connections:
            return self._connections[sid]
        import paramiko
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(
            config["host"], port=config["port"],
            username=config.get("username"),
            password=config.get("password"),
            timeout=10,
        )
        sftp = ssh.open_sftp()
        self._connections[sid] = sftp
        return sftp

    def _list_sftp(self, config: Dict, path: str) -> List[RemoteFile]:
        sftp = self._get_sftp(config)
        files = []
        for attr in sftp.listdir_attr(path):
            import stat
            is_dir = stat.S_ISDIR(attr.st_mode)
            files.append(RemoteFile(
                name=attr.filename,
                path=os.path.join(path, attr.filename),
                is_folder=is_dir,
                size_bytes=attr.st_size or 0,
                modified=str(attr.st_mtime or ""),
                server_id=config["server_id"],
            ))
        return files

    def _download_sftp(self, config: Dict, remote: str, local: str) -> bool:
        sftp = self._get_sftp(config)
        sftp.get(remote, local)
        return True

    def _upload_sftp(self, config: Dict, local: str, remote: str) -> bool:
        sftp = self._get_sftp(config)
        sftp.put(local, remote)
        return True

    # ------------------------------------------------------------------
    # FTP
    # ------------------------------------------------------------------

    def _get_ftp(self, config: Dict):
        sid = config["server_id"]
        if sid in self._connections:
            return self._connections[sid]
        from ftplib import FTP
        ftp = FTP()
        ftp.connect(config["host"], config["port"], timeout=10)
        ftp.login(config.get("username", "anonymous"), config.get("password", ""))
        self._connections[sid] = ftp
        return ftp

    def _list_ftp(self, config: Dict, path: str) -> List[RemoteFile]:
        ftp = self._get_ftp(config)
        files = []
        lines = []
        ftp.retrlines(f"LIST {path}", lines.append)
        for line in lines:
            parts = line.split()
            if len(parts) < 9:
                continue
            name = parts[-1]
            is_dir = line.startswith("d")
            size = int(parts[4]) if not is_dir else 0
            files.append(RemoteFile(
                name=name,
                path=os.path.join(path, name),
                is_folder=is_dir,
                size_bytes=size,
                modified=" ".join(parts[5:8]),
                server_id=config["server_id"],
            ))
        return files

    def _download_ftp(self, config: Dict, remote: str, local: str) -> bool:
        ftp = self._get_ftp(config)
        with open(local, "wb") as f:
            ftp.retrbinary(f"RETR {remote}", f.write)
        return True

    def _upload_ftp(self, config: Dict, local: str, remote: str) -> bool:
        ftp = self._get_ftp(config)
        with open(local, "rb") as f:
            ftp.storbinary(f"STOR {remote}", f)
        return True

    # ------------------------------------------------------------------
    # HTTP/S (listado de directorios Apache/Nginx)
    # ------------------------------------------------------------------

    def _list_http(self, config: Dict, path: str) -> List[RemoteFile]:
        import requests
        from bs4 import BeautifulSoup
        base = f"{config['protocol']}://{config['host']}:{config['port']}{path}"
        headers = {}
        if config.get("api_key"):
            headers["Authorization"] = f"Bearer {config['api_key']}"
        resp = requests.get(base, headers=headers, timeout=10)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "html.parser")
        files = []
        for link in soup.find_all("a", href=True):
            href = link["href"]
            if href in ("../", "./", "/"):
                continue
            is_dir = href.endswith("/")
            files.append(RemoteFile(
                name=href.rstrip("/"),
                path=os.path.join(path, href),
                is_folder=is_dir,
                size_bytes=0,
                modified="",
                server_id=config["server_id"],
            ))
        return files

    def _download_http(self, config: Dict, remote: str, local: str) -> bool:
        import requests
        url = f"{config['protocol']}://{config['host']}:{config['port']}{remote}"
        headers = {}
        if config.get("api_key"):
            headers["Authorization"] = f"Bearer {config['api_key']}"
        resp = requests.get(url, headers=headers, stream=True, timeout=30)
        resp.raise_for_status()
        with open(local, "wb") as f:
            for chunk in resp.iter_content(8192):
                f.write(chunk)
        return True

    # ------------------------------------------------------------------
    # S3-compatible (boto3)
    # ------------------------------------------------------------------

    def _list_s3(self, config: Dict, path: str) -> List[RemoteFile]:
        import boto3
        bucket, prefix = self._parse_s3_path(path)
        s3 = self._get_s3_client(config)
        result = s3.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")
        files = []
        for cp in result.get("CommonPrefixes", []):
            name = cp["Prefix"].rstrip("/").split("/")[-1]
            files.append(RemoteFile(name=name, path=cp["Prefix"], is_folder=True,
                                    size_bytes=0, modified="", server_id=config["server_id"]))
        for obj in result.get("Contents", []):
            name = obj["Key"].split("/")[-1]
            if not name:
                continue
            files.append(RemoteFile(name=name, path=obj["Key"], is_folder=False,
                                    size_bytes=obj["Size"],
                                    modified=str(obj["LastModified"]),
                                    server_id=config["server_id"]))
        return files

    def _download_s3(self, config: Dict, remote: str, local: str) -> bool:
        bucket, key = self._parse_s3_path(remote)
        s3 = self._get_s3_client(config)
        s3.download_file(bucket, key, local)
        return True

    def _get_s3_client(self, config: Dict):
        import boto3
        return boto3.client(
            "s3",
            endpoint_url=config.get("api_key"),  # api_key = endpoint URL for S3-compat
            aws_access_key_id=config.get("username"),
            aws_secret_access_key=config.get("password"),
        )

    @staticmethod
    def _parse_s3_path(path: str):
        path = path.lstrip("/")
        parts = path.split("/", 1)
        bucket = parts[0]
        key = parts[1] if len(parts) > 1 else ""
        return bucket, key

    # ------------------------------------------------------------------
    # Utilidades
    # ------------------------------------------------------------------

    def _test_connection(self, config: Dict) -> bool:
        import socket
        try:
            sock = socket.create_connection((config["host"], config["port"]), timeout=5)
            sock.close()
            return True
        except Exception:
            return False

    def _disconnect(self, server_id: str) -> None:
        conn = self._connections.pop(server_id, None)
        if conn:
            try:
                conn.close()
            except Exception:
                pass
