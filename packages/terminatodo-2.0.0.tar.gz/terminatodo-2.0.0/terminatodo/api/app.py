"""
TerminaTodo API v2
==================
API REST completa con autenticación JWT.
Todos los endpoints de gestión requieren token.
"""
from fastapi import FastAPI, HTTPException, Depends, Header, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import logging
import os

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# Modelos Pydantic
# ------------------------------------------------------------------

class LoginRequest(BaseModel):
    username: str
    password: str

class RemoteServerConfig(BaseModel):
    server_id: str
    name: str
    host: str
    port: int
    protocol: str   # sftp, ftp, http, https, s3
    username: Optional[str] = None
    password: Optional[str] = None
    api_key: Optional[str] = None

class CloudAuthRequest(BaseModel):
    service: str    # google_drive, dropbox, onedrive
    credentials: str

class DropboxAuthRequest(BaseModel):
    access_token: str

class OneDriveAuthRequest(BaseModel):
    client_id: str
    client_secret: str
    tenant_id: str = "common"

class TrainingRequest(BaseModel):
    data_source_uri: str
    model_config: Dict[str, Any] = {}
    output_uri: Optional[str] = None

class SyncRequest(BaseModel):
    source: str
    destination: str


# ------------------------------------------------------------------
# Dependencia de autenticación
# ------------------------------------------------------------------

ADMIN_USER = os.environ.get("TERMINATODO_USER", "admin")
ADMIN_PASS = os.environ.get("TERMINATODO_PASS", "terminatodo2024")

def get_current_user(authorization: Optional[str] = Header(None)) -> Dict:
    from ..auth.jwt_auth import verify_token
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Token requerido")
    token = authorization.split(" ", 1)[1]
    payload = verify_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Token inválido o expirado")
    return payload


# ------------------------------------------------------------------
# Factory de la app
# ------------------------------------------------------------------

def create_app(terminatodo_instance=None) -> FastAPI:
    app = FastAPI(
        title="TerminaTodo API",
        version="2.0.0",
        description="API unificada de gestión de almacenamiento para Deep Learning",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Instancia global
    tt = terminatodo_instance

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    @app.post("/auth/login", tags=["Auth"])
    def login(req: LoginRequest):
        """Obtiene un JWT para usar la API."""
        from ..auth.jwt_auth import create_token
        if req.username != ADMIN_USER or req.password != ADMIN_PASS:
            raise HTTPException(status_code=401, detail="Credenciales incorrectas")
        token = create_token({"sub": req.username, "role": "admin"})
        return {"access_token": token, "token_type": "bearer", "expires_in": 86400}

    @app.get("/auth/me", tags=["Auth"])
    def me(user: Dict = Depends(get_current_user)):
        return user

    # ------------------------------------------------------------------
    # Info
    # ------------------------------------------------------------------

    @app.get("/", tags=["Info"])
    def root():
        return {
            "name": "TerminaTodo API",
            "version": "2.0.0",
            "docs": "/docs",
            "status": "running",
        }

    @app.get("/health", tags=["Info"])
    def health():
        return {"status": "ok"}

    # ------------------------------------------------------------------
    # Almacenamiento local
    # ------------------------------------------------------------------

    @app.get("/storage/local/devices", tags=["Local Storage"])
    def list_local_devices(user=Depends(get_current_user)):
        """Lista todos los dispositivos de almacenamiento local."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        return {"devices": tt.local.list_devices()}

    @app.get("/storage/local/files", tags=["Local Storage"])
    def list_local_files(
        path: str = Query(..., description="Ruta absoluta"),
        recursive: bool = Query(False),
        user=Depends(get_current_user)
    ):
        """Lista archivos en una ruta local."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        try:
            return {"files": tt.local.list_files(path, recursive=recursive)}
        except FileNotFoundError as e:
            raise HTTPException(404, str(e))

    @app.get("/storage/local/usage", tags=["Local Storage"])
    def local_disk_usage(
        path: str = Query("/", description="Ruta a analizar"),
        user=Depends(get_current_user)
    ):
        return tt.local.get_disk_usage(path)

    # ------------------------------------------------------------------
    # Almacenamiento en nube
    # ------------------------------------------------------------------

    @app.get("/storage/cloud/services", tags=["Cloud Storage"])
    def list_cloud_services(user=Depends(get_current_user)):
        """Lista servicios en nube y su estado de autenticación."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        return {"services": tt.cloud.get_available_services()}

    @app.post("/storage/cloud/auth/google", tags=["Cloud Storage"])
    def auth_google_drive(req: CloudAuthRequest, user=Depends(get_current_user)):
        """Autentica con Google Drive (JSON de cuenta de servicio o token OAuth2)."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        ok = tt.cloud.authenticate_google_drive(req.credentials)
        if not ok:
            raise HTTPException(400, "Error autenticando con Google Drive")
        return {"status": "authenticated", "service": "google_drive"}

    @app.post("/storage/cloud/auth/dropbox", tags=["Cloud Storage"])
    def auth_dropbox(req: DropboxAuthRequest, user=Depends(get_current_user)):
        """Autentica con Dropbox usando access token."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        ok = tt.cloud.authenticate_dropbox(req.access_token)
        if not ok:
            raise HTTPException(400, "Error autenticando con Dropbox")
        return {"status": "authenticated", "service": "dropbox"}

    @app.post("/storage/cloud/auth/onedrive", tags=["Cloud Storage"])
    def auth_onedrive(req: OneDriveAuthRequest, user=Depends(get_current_user)):
        """Autentica con OneDrive (MSAL)."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        ok = tt.cloud.authenticate_onedrive(req.client_id, req.client_secret, req.tenant_id)
        if not ok:
            raise HTTPException(400, "Error autenticando con OneDrive")
        return {"status": "authenticated", "service": "onedrive"}

    @app.get("/storage/cloud/{service}/files", tags=["Cloud Storage"])
    def list_cloud_files(
        service: str,
        path: str = Query("", description="Ruta o ID de carpeta"),
        user=Depends(get_current_user)
    ):
        """Lista archivos en un servicio en nube."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        try:
            if service == "google_drive":
                files = tt.cloud.list_google_drive(path or "root")
            elif service == "dropbox":
                files = tt.cloud.list_dropbox(path)
            elif service == "onedrive":
                files = tt.cloud.list_onedrive(path or "root")
            else:
                raise HTTPException(400, f"Servicio no soportado: {service}")
            return {"files": [f.to_dict() for f in files]}
        except Exception as e:
            raise HTTPException(500, str(e))

    # ------------------------------------------------------------------
    # Servidores remotos
    # ------------------------------------------------------------------

    @app.get("/storage/remote/servers", tags=["Remote Storage"])
    def list_remote_servers(user=Depends(get_current_user)):
        """Lista servidores remotos registrados."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        return {"servers": tt.remote.list_servers()}

    @app.post("/storage/remote/servers", tags=["Remote Storage"])
    def add_remote_server(config: RemoteServerConfig, user=Depends(get_current_user)):
        """Registra un nuevo servidor remoto."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        try:
            tt.remote.add_server(config.model_dump())
            return {"status": "added", "server_id": config.server_id}
        except Exception as e:
            raise HTTPException(400, str(e))

    @app.delete("/storage/remote/servers/{server_id}", tags=["Remote Storage"])
    def remove_remote_server(server_id: str, user=Depends(get_current_user)):
        """Elimina un servidor remoto."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        tt.remote.remove_server(server_id)
        return {"status": "removed", "server_id": server_id}

    @app.get("/storage/remote/{server_id}/files", tags=["Remote Storage"])
    def list_remote_files(
        server_id: str,
        path: str = Query("/", description="Ruta remota"),
        user=Depends(get_current_user)
    ):
        """Lista archivos en un servidor remoto."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        try:
            files = tt.remote.list_files(server_id, path)
            return {"files": [f.to_dict() for f in files]}
        except Exception as e:
            raise HTTPException(500, str(e))

    # ------------------------------------------------------------------
    # Vista unificada
    # ------------------------------------------------------------------

    @app.get("/storage/all", tags=["Unified Storage"])
    def list_all_storages(user=Depends(get_current_user)):
        """Lista todos los almacenamientos disponibles."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        return tt.list_all()

    @app.get("/storage/list", tags=["Unified Storage"])
    def list_path(
        uri: str = Query(..., description="URI de almacenamiento (ej: local:/data, gdrive:/carpeta)"),
        user=Depends(get_current_user)
    ):
        """Lista archivos en cualquier almacenamiento por URI."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        try:
            return {"files": tt.unified.list_path(uri)}
        except ValueError as e:
            raise HTTPException(400, str(e))
        except Exception as e:
            raise HTTPException(500, str(e))

    # ------------------------------------------------------------------
    # Sincronización
    # ------------------------------------------------------------------

    @app.post("/sync", tags=["Sync"])
    def sync_storages(req: SyncRequest, user=Depends(get_current_user)):
        """Sincroniza source → destination."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        try:
            result = tt.sync(req.source, req.destination)
            return result
        except Exception as e:
            raise HTTPException(500, str(e))

    @app.get("/sync/history", tags=["Sync"])
    def sync_history(
        limit: int = Query(20, ge=1, le=100),
        user=Depends(get_current_user)
    ):
        """Historial de sincronizaciones."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        return {"history": tt.db.get_sync_history(limit)}

    # ------------------------------------------------------------------
    # Entrenamiento
    # ------------------------------------------------------------------

    @app.post("/training/start", tags=["Training"])
    def start_training(req: TrainingRequest, user=Depends(get_current_user)):
        """Inicia una sesión de entrenamiento con TenMiNaTor."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        from ..training.training_bridge import TrainingBridge
        bridge = TrainingBridge(
            db_path=tt.db_path,
            unified_manager=tt.unified,
        )
        session_id = bridge.start_training(
            data_source_uri=req.data_source_uri,
            model_config=req.model_config,
            output_uri=req.output_uri,
        )
        return {"session_id": session_id, "status": "started"}

    @app.get("/training/sessions", tags=["Training"])
    def list_training_sessions(
        limit: int = Query(20, ge=1, le=100),
        user=Depends(get_current_user)
    ):
        """Lista sesiones de entrenamiento."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        return {"sessions": tt.db.get_training_sessions(limit)}

    @app.get("/training/sessions/{session_id}", tags=["Training"])
    def get_training_session(session_id: str, user=Depends(get_current_user)):
        """Estado de una sesión de entrenamiento."""
        if not tt:
            raise HTTPException(503, "TerminaTodo no inicializado")
        sessions = tt.db.get_training_sessions(limit=100)
        for s in sessions:
            if s["session_id"] == session_id:
                return s
        raise HTTPException(404, f"Sesión '{session_id}' no encontrada")

    return app
