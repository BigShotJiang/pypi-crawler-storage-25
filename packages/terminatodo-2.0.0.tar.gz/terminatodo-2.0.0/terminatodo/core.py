"""
TerminaTodo Core
================
Clase principal que orquesta todos los subsistemas.
"""
import logging
import threading
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)


class TerminaTodo:
    """Punto de entrada principal del framework."""

    def __init__(self, db_path: str = "terminatodo.db", port: int = 8765):
        self.port = port
        self.db_path = db_path
        self._server_thread: Optional[threading.Thread] = None
        self._running = False

        # Subsistemas (lazy import para evitar dependencias opcionales al importar)
        self._local: Optional[Any] = None
        self._cloud: Optional[Any] = None
        self._remote: Optional[Any] = None
        self._unified: Optional[Any] = None
        self._db: Optional[Any] = None

    # ------------------------------------------------------------------
    # Ciclo de vida
    # ------------------------------------------------------------------

    def start(self, host: str = "0.0.0.0", blocking: bool = False) -> None:
        """Inicia la API REST en segundo plano (o bloqueante)."""
        import uvicorn
        from .api.app import create_app

        app = create_app(self)

        config = uvicorn.Config(app, host=host, port=self.port, log_level="info")
        server = uvicorn.Server(config)

        if blocking:
            server.run()
        else:
            self._server_thread = threading.Thread(target=server.run, daemon=True)
            self._server_thread.start()
            self._running = True
            logger.info(f"TerminaTodo API en http://{host}:{self.port}")

    def stop(self) -> None:
        """Detiene el servidor."""
        self._running = False
        logger.info("TerminaTodo detenido.")

    # ------------------------------------------------------------------
    # Acceso a subsistemas
    # ------------------------------------------------------------------

    @property
    def local(self):
        if self._local is None:
            from .storage.local_storage import LocalStorageManager
            self._local = LocalStorageManager()
        return self._local

    @property
    def cloud(self):
        if self._cloud is None:
            from .cloud.cloud_manager import CloudStorageManager
            self._cloud = CloudStorageManager(db_path=self.db_path)
        return self._cloud

    @property
    def remote(self):
        if self._remote is None:
            from .hosting.remote_manager import RemoteStorageManager
            self._remote = RemoteStorageManager(db_path=self.db_path)
        return self._remote

    @property
    def unified(self):
        if self._unified is None:
            from .storage.unified_manager import UnifiedStorageManager
            self._unified = UnifiedStorageManager(
                local=self.local, cloud=self.cloud, remote=self.remote
            )
        return self._unified

    @property
    def db(self):
        if self._db is None:
            from .db.database import Database
            self._db = Database(self.db_path)
        return self._db

    # ------------------------------------------------------------------
    # API de alto nivel
    # ------------------------------------------------------------------

    def list_all(self) -> Dict[str, List[Dict]]:
        """Lista todos los almacenamientos disponibles."""
        return {
            "local": self.local.list_devices(),
            "cloud": self.cloud.get_available_services(),
            "remote": self.remote.list_servers(),
        }

    def sync(self, source: str, destination: str) -> Dict[str, Any]:
        """
        Sincroniza source → destination.
        Formato: 'local:/ruta', 'gdrive:/carpeta', 'sftp:server_id:/ruta'
        """
        from .sync.sync_manager import SyncManager
        sm = SyncManager(self.local, self.cloud, self.remote)
        return sm.sync(source, destination)
