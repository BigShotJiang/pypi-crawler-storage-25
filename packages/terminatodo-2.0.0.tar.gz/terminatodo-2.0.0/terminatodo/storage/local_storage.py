"""
Local Storage Manager v2
========================
Detecta y gestiona almacenamiento local: SSD, HDD, pendrives, RAM.
"""
import os
import logging
import shutil
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)


@dataclass
class LocalDevice:
    device_id: str
    name: str
    mount_point: str
    total_gb: float
    used_gb: float
    free_gb: float
    device_type: str   # ssd, hdd, usb, ram, network
    filesystem: str

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["used_pct"] = round(self.used_gb / self.total_gb * 100, 1) if self.total_gb else 0
        return d


@dataclass
class LocalFile:
    name: str
    path: str
    is_folder: bool
    size_bytes: int
    modified: float

    def to_dict(self) -> Dict:
        return asdict(self)


class LocalStorageManager:
    """Detecta y gestiona almacenamiento local."""

    def list_devices(self) -> List[Dict]:
        """Lista todos los dispositivos de almacenamiento montados."""
        try:
            import psutil
            devices = []
            for part in psutil.disk_partitions(all=False):
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                    device_type = self._detect_device_type(part)
                    devices.append(LocalDevice(
                        device_id=part.device.replace("/", "_").strip("_") or "disk",
                        name=self._friendly_name(part),
                        mount_point=part.mountpoint,
                        total_gb=round(usage.total / (1024 ** 3), 2),
                        used_gb=round(usage.used / (1024 ** 3), 2),
                        free_gb=round(usage.free / (1024 ** 3), 2),
                        device_type=device_type,
                        filesystem=part.fstype,
                    ).to_dict())
                except (PermissionError, OSError):
                    continue
            # Añadir RAM como "dispositivo"
            devices.append(self._ram_device())
            return devices
        except ImportError:
            return [self._fallback_device()]

    def list_files(self, path: str, recursive: bool = False) -> List[Dict]:
        """Lista archivos en una ruta local."""
        if not os.path.exists(path):
            raise FileNotFoundError(f"Ruta no encontrada: {path}")
        files = []
        try:
            if recursive:
                for root, dirs, fnames in os.walk(path):
                    for name in fnames:
                        fp = os.path.join(root, name)
                        files.append(self._file_info(fp))
                    for d in dirs:
                        dp = os.path.join(root, d)
                        files.append(self._file_info(dp))
            else:
                for entry in os.scandir(path):
                    files.append(self._file_info(entry.path))
        except PermissionError as e:
            logger.warning(f"Permiso denegado en {path}: {e}")
        return files

    def get_disk_usage(self, path: str) -> Dict:
        total, used, free = shutil.disk_usage(path)
        return {
            "path": path,
            "total_gb": round(total / (1024 ** 3), 2),
            "used_gb": round(used / (1024 ** 3), 2),
            "free_gb": round(free / (1024 ** 3), 2),
            "used_pct": round(used / total * 100, 1) if total else 0,
        }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _file_info(self, path: str) -> Dict:
        stat = os.stat(path)
        return LocalFile(
            name=os.path.basename(path),
            path=path,
            is_folder=os.path.isdir(path),
            size_bytes=stat.st_size,
            modified=stat.st_mtime,
        ).to_dict()

    def _detect_device_type(self, partition) -> str:
        dev = partition.device.lower()
        opts = partition.opts.lower()
        if "usb" in opts or "removable" in opts or "sd" in dev:
            return "usb"
        if "tmpfs" in partition.fstype or "ramfs" in partition.fstype:
            return "ram"
        if "network" in opts or "nfs" in partition.fstype or "cifs" in partition.fstype:
            return "network"
        # Heurística simple: nvme/ssd vs hdd
        if "nvme" in dev:
            return "ssd"
        return "hdd"

    def _friendly_name(self, partition) -> str:
        mp = partition.mountpoint
        if mp == "/":
            return "Sistema (raíz)"
        if "/media/" in mp or "/mnt/" in mp:
            return f"Extraíble ({os.path.basename(mp)})"
        return os.path.basename(mp) or partition.device

    def _ram_device(self) -> Dict:
        try:
            import psutil
            vm = psutil.virtual_memory()
            return LocalDevice(
                device_id="ram",
                name="Memoria RAM",
                mount_point="ram://",
                total_gb=round(vm.total / (1024 ** 3), 2),
                used_gb=round(vm.used / (1024 ** 3), 2),
                free_gb=round(vm.available / (1024 ** 3), 2),
                device_type="ram",
                filesystem="tmpfs",
            ).to_dict()
        except Exception:
            return {"device_id": "ram", "name": "RAM", "device_type": "ram"}

    def _fallback_device(self) -> Dict:
        usage = shutil.disk_usage("/")
        return LocalDevice(
            device_id="disk0",
            name="Disco principal",
            mount_point="/",
            total_gb=round(usage.total / (1024 ** 3), 2),
            used_gb=round(usage.used / (1024 ** 3), 2),
            free_gb=round(usage.free / (1024 ** 3), 2),
            device_type="hdd",
            filesystem="unknown",
        ).to_dict()
