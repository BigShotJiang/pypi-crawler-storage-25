"""
Unified Storage Manager v2
===========================
Vista unificada de todos los almacenamientos: local, nube y remoto.
"""
import logging
from typing import List, Dict, Optional, Any

logger = logging.getLogger(__name__)


class UnifiedStorageManager:
    """Agrega local + cloud + remote en una interfaz única."""

    def __init__(self, local=None, cloud=None, remote=None):
        self._local = local
        self._cloud = cloud
        self._remote = remote

    def list_all_storages(self) -> Dict[str, List[Dict]]:
        """Retorna todos los almacenamientos disponibles."""
        result = {"local": [], "cloud": [], "remote": []}
        if self._local:
            try:
                result["local"] = self._local.list_devices()
            except Exception as e:
                logger.error(f"Error listando local: {e}")
        if self._cloud:
            try:
                result["cloud"] = self._cloud.get_available_services()
            except Exception as e:
                logger.error(f"Error listando cloud: {e}")
        if self._remote:
            try:
                result["remote"] = self._remote.list_servers()
            except Exception as e:
                logger.error(f"Error listando remoto: {e}")
        return result

    def resolve_path(self, uri: str) -> Dict[str, Any]:
        """
        Resuelve un URI de almacenamiento.
        Formatos:
          local:/ruta/absoluta
          gdrive:/carpeta
          dropbox:/carpeta
          onedrive:/carpeta
          sftp:server_id:/ruta
          ftp:server_id:/ruta
          s3:server_id:/bucket/key
        """
        if uri.startswith("local:"):
            return {"type": "local", "path": uri[6:]}
        elif uri.startswith("gdrive:"):
            return {"type": "cloud", "service": "google_drive", "path": uri[7:]}
        elif uri.startswith("dropbox:"):
            return {"type": "cloud", "service": "dropbox", "path": uri[8:]}
        elif uri.startswith("onedrive:"):
            return {"type": "cloud", "service": "onedrive", "path": uri[9:]}
        else:
            # Formato: protocol:server_id:/path
            parts = uri.split(":", 2)
            if len(parts) == 3:
                return {"type": "remote", "protocol": parts[0],
                        "server_id": parts[1], "path": parts[2]}
        raise ValueError(f"URI no reconocida: {uri}")

    def list_path(self, uri: str) -> List[Dict]:
        """Lista archivos en cualquier almacenamiento por URI."""
        info = self.resolve_path(uri)
        if info["type"] == "local":
            return self._local.list_files(info["path"])
        elif info["type"] == "cloud":
            svc = info["service"]
            if svc == "google_drive":
                return [f.to_dict() for f in self._cloud.list_google_drive(info["path"])]
            elif svc == "dropbox":
                return [f.to_dict() for f in self._cloud.list_dropbox(info["path"])]
            elif svc == "onedrive":
                return [f.to_dict() for f in self._cloud.list_onedrive(info["path"])]
        elif info["type"] == "remote":
            return [f.to_dict() for f in self._remote.list_files(info["server_id"], info["path"])]
        return []
