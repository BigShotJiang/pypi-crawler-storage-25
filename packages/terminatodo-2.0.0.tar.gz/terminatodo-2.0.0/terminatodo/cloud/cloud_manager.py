"""
Cloud Storage Manager v2
========================
Gestiona autenticación y operaciones reales en:
- Google Drive (OAuth2 + service account)
- Microsoft OneDrive (OAuth2 MSAL)
- Dropbox (OAuth2)

Las credenciales se persisten en SQLite.
"""
import logging
import json
import os
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, asdict
from datetime import datetime

logger = logging.getLogger(__name__)


@dataclass
class CloudFile:
    file_id: str
    name: str
    path: str
    is_folder: bool
    size_bytes: int
    modified: str
    cloud_service: str

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["size_mb"] = round(self.size_bytes / (1024 ** 2), 2)
        return d


class CloudStorageManager:
    """Gestor unificado de almacenamiento en nube con persistencia."""

    SERVICES = {
        "google_drive": {
            "name": "Google Drive",
            "icon": "🔵",
            "auth_url": "https://accounts.google.com/o/oauth2/auth",
            "scopes": ["https://www.googleapis.com/auth/drive"],
        },
        "onedrive": {
            "name": "Microsoft OneDrive",
            "icon": "🔷",
            "auth_url": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
            "scopes": ["Files.ReadWrite"],
        },
        "dropbox": {
            "name": "Dropbox",
            "icon": "🔹",
            "auth_url": "https://www.dropbox.com/oauth2/authorize",
            "scopes": ["files.metadata.read", "files.content.read"],
        },
    }

    def __init__(self, db_path: str = "terminatodo.db"):
        self.db_path = db_path
        self._db = None
        self._clients: Dict[str, Any] = {}

    @property
    def db(self):
        if self._db is None:
            from ..db.database import Database
            self._db = Database(self.db_path)
        return self._db

    # ------------------------------------------------------------------
    # Información de servicios
    # ------------------------------------------------------------------

    def get_available_services(self) -> List[Dict]:
        services = []
        for sid, info in self.SERVICES.items():
            creds = self.db.get_cloud_credentials(sid)
            services.append({
                "id": sid,
                "name": info["name"],
                "icon": info["icon"],
                "authenticated": creds is not None,
                "auth_url": info["auth_url"],
            })
        return services

    # ------------------------------------------------------------------
    # Google Drive
    # ------------------------------------------------------------------

    def authenticate_google_drive(self, credentials_json: str) -> bool:
        """
        Autentica con Google Drive.
        credentials_json: JSON de cuenta de servicio o token OAuth2.
        """
        try:
            creds_data = json.loads(credentials_json)
            # Intentar con google-auth si está disponible
            try:
                if "type" in creds_data and creds_data["type"] == "service_account":
                    from google.oauth2.service_account import Credentials
                    creds = Credentials.from_service_account_info(
                        creds_data,
                        scopes=self.SERVICES["google_drive"]["scopes"]
                    )
                else:
                    from google.oauth2.credentials import Credentials
                    creds = Credentials(
                        token=creds_data.get("access_token"),
                        refresh_token=creds_data.get("refresh_token"),
                        token_uri="https://oauth2.googleapis.com/token",
                        client_id=creds_data.get("client_id"),
                        client_secret=creds_data.get("client_secret"),
                    )
                from googleapiclient.discovery import build
                service = build("drive", "v3", credentials=creds)
                # Verificar acceso
                service.files().list(pageSize=1).execute()
                self._clients["google_drive"] = service
            except ImportError:
                logger.warning("google-auth no instalado; guardando credenciales sin verificar")

            self.db.save_cloud_credentials("google_drive", creds_data)
            logger.info("Google Drive autenticado correctamente")
            return True
        except Exception as e:
            logger.error(f"Error autenticando Google Drive: {e}")
            return False

    def list_google_drive(self, folder_id: str = "root") -> List[CloudFile]:
        """Lista archivos en Google Drive."""
        client = self._get_gdrive_client()
        if not client:
            return []
        try:
            query = f"'{folder_id}' in parents and trashed=false"
            results = client.files().list(
                q=query,
                fields="files(id,name,mimeType,size,modifiedTime)",
                pageSize=100
            ).execute()
            files = []
            for f in results.get("files", []):
                is_folder = f["mimeType"] == "application/vnd.google-apps.folder"
                files.append(CloudFile(
                    file_id=f["id"],
                    name=f["name"],
                    path=f"gdrive:/{f['name']}",
                    is_folder=is_folder,
                    size_bytes=int(f.get("size", 0)),
                    modified=f.get("modifiedTime", ""),
                    cloud_service="google_drive",
                ))
            return files
        except Exception as e:
            logger.error(f"Error listando Google Drive: {e}")
            return []

    def _get_gdrive_client(self):
        if "google_drive" in self._clients:
            return self._clients["google_drive"]
        creds_data = self.db.get_cloud_credentials("google_drive")
        if not creds_data:
            return None
        try:
            from google.oauth2.credentials import Credentials
            from googleapiclient.discovery import build
            creds = Credentials(
                token=creds_data.get("access_token"),
                refresh_token=creds_data.get("refresh_token"),
                token_uri="https://oauth2.googleapis.com/token",
                client_id=creds_data.get("client_id"),
                client_secret=creds_data.get("client_secret"),
            )
            client = build("drive", "v3", credentials=creds)
            self._clients["google_drive"] = client
            return client
        except Exception as e:
            logger.error(f"No se pudo restaurar cliente Google Drive: {e}")
            return None

    # ------------------------------------------------------------------
    # Dropbox
    # ------------------------------------------------------------------

    def authenticate_dropbox(self, access_token: str) -> bool:
        """Autentica con Dropbox usando access token."""
        try:
            try:
                import dropbox
                dbx = dropbox.Dropbox(access_token)
                dbx.users_get_current_account()
                self._clients["dropbox"] = dbx
            except ImportError:
                logger.warning("dropbox SDK no instalado; guardando token sin verificar")

            self.db.save_cloud_credentials("dropbox", {"access_token": access_token})
            logger.info("Dropbox autenticado correctamente")
            return True
        except Exception as e:
            logger.error(f"Error autenticando Dropbox: {e}")
            return False

    def list_dropbox(self, path: str = "") -> List[CloudFile]:
        """Lista archivos en Dropbox."""
        client = self._get_dropbox_client()
        if not client:
            return []
        try:
            result = client.files_list_folder(path)
            files = []
            for entry in result.entries:
                import dropbox
                is_folder = isinstance(entry, dropbox.files.FolderMetadata)
                size = getattr(entry, "size", 0)
                modified = str(getattr(entry, "client_modified", ""))
                files.append(CloudFile(
                    file_id=entry.id if hasattr(entry, "id") else entry.path_lower,
                    name=entry.name,
                    path=f"dropbox:{entry.path_display}",
                    is_folder=is_folder,
                    size_bytes=size,
                    modified=modified,
                    cloud_service="dropbox",
                ))
            return files
        except Exception as e:
            logger.error(f"Error listando Dropbox: {e}")
            return []

    def _get_dropbox_client(self):
        if "dropbox" in self._clients:
            return self._clients["dropbox"]
        creds = self.db.get_cloud_credentials("dropbox")
        if not creds:
            return None
        try:
            import dropbox
            dbx = dropbox.Dropbox(creds["access_token"])
            self._clients["dropbox"] = dbx
            return dbx
        except Exception:
            return None

    # ------------------------------------------------------------------
    # OneDrive (MSAL)
    # ------------------------------------------------------------------

    def authenticate_onedrive(self, client_id: str, client_secret: str,
                               tenant_id: str = "common") -> bool:
        """Autentica con OneDrive usando MSAL."""
        try:
            try:
                import msal
                authority = f"https://login.microsoftonline.com/{tenant_id}"
                app = msal.ConfidentialClientApplication(
                    client_id, authority=authority, client_credential=client_secret
                )
                token = app.acquire_token_for_client(
                    scopes=["https://graph.microsoft.com/.default"]
                )
                if "access_token" not in token:
                    raise ValueError(f"MSAL error: {token.get('error_description')}")
                self._clients["onedrive"] = token["access_token"]
            except ImportError:
                logger.warning("msal no instalado; guardando credenciales sin verificar")

            self.db.save_cloud_credentials("onedrive", {
                "client_id": client_id,
                "client_secret": client_secret,
                "tenant_id": tenant_id,
            })
            logger.info("OneDrive autenticado correctamente")
            return True
        except Exception as e:
            logger.error(f"Error autenticando OneDrive: {e}")
            return False

    def list_onedrive(self, folder_path: str = "root") -> List[CloudFile]:
        """Lista archivos en OneDrive vía Microsoft Graph."""
        token = self._clients.get("onedrive")
        if not token:
            return []
        try:
            import requests
            url = f"https://graph.microsoft.com/v1.0/me/drive/{folder_path}/children"
            headers = {"Authorization": f"Bearer {token}"}
            resp = requests.get(url, headers=headers, timeout=10)
            resp.raise_for_status()
            files = []
            for item in resp.json().get("value", []):
                is_folder = "folder" in item
                files.append(CloudFile(
                    file_id=item["id"],
                    name=item["name"],
                    path=f"onedrive:/{item['name']}",
                    is_folder=is_folder,
                    size_bytes=item.get("size", 0),
                    modified=item.get("lastModifiedDateTime", ""),
                    cloud_service="onedrive",
                ))
            return files
        except Exception as e:
            logger.error(f"Error listando OneDrive: {e}")
            return []

    # ------------------------------------------------------------------
    # Descarga genérica
    # ------------------------------------------------------------------

    def download_file(self, service: str, file_id: str, dest_path: str) -> bool:
        """Descarga un archivo de cualquier servicio a dest_path."""
        try:
            if service == "google_drive":
                client = self._get_gdrive_client()
                if not client:
                    return False
                request = client.files().get_media(fileId=file_id)
                with open(dest_path, "wb") as f:
                    f.write(request.execute())
                return True
            elif service == "dropbox":
                client = self._get_dropbox_client()
                if not client:
                    return False
                _, res = client.files_download(file_id)
                with open(dest_path, "wb") as f:
                    f.write(res.content)
                return True
            else:
                logger.warning(f"Descarga no implementada para {service}")
                return False
        except Exception as e:
            logger.error(f"Error descargando {file_id} de {service}: {e}")
            return False
