"""
Training Bridge v2
==================
Integración de TerminaTodo con TenMiNaTor para entrenamiento de modelos.
Permite usar cualquier almacenamiento como fuente de datos de entrenamiento.
"""
import os
import uuid
import logging
import json
from typing import Dict, Any, Optional, Callable, List

logger = logging.getLogger(__name__)


class TrainingBridge:
    """
    Puente entre TerminaTodo y TenMiNaTor.
    
    Flujo:
    1. Resuelve la fuente de datos (local, cloud, remoto)
    2. Descarga/prepara los datos en un directorio temporal
    3. Lanza el entrenamiento con TenMiNaTor
    4. Persiste el progreso en la base de datos
    5. Guarda el modelo entrenado en el destino especificado
    """

    def __init__(self, db_path: str = "terminatodo.db",
                 unified_manager=None, work_dir: str = "/tmp/terminatodo_training"):
        self.db_path = db_path
        self.unified = unified_manager
        self.work_dir = work_dir
        self._db = None
        self._active_sessions: Dict[str, Dict] = {}
        os.makedirs(work_dir, exist_ok=True)

    @property
    def db(self):
        if self._db is None:
            from ..db.database import Database
            self._db = Database(self.db_path)
        return self._db

    # ------------------------------------------------------------------
    # API principal
    # ------------------------------------------------------------------

    def start_training(
        self,
        data_source_uri: str,
        model_config: Dict[str, Any],
        output_uri: Optional[str] = None,
        on_progress: Optional[Callable[[str, float, float], None]] = None,
    ) -> str:
        """
        Inicia una sesión de entrenamiento.

        Args:
            data_source_uri: URI del almacenamiento de datos (ej: 'local:/data/train.csv')
            model_config: Configuración del modelo TenMiNaTor
            output_uri: Dónde guardar el modelo (ej: 'local:/models/')
            on_progress: Callback(session_id, progress_pct, loss)

        Returns:
            session_id (str)
        """
        session_id = str(uuid.uuid4())[:8]
        session_dir = os.path.join(self.work_dir, session_id)
        os.makedirs(session_dir, exist_ok=True)

        # Persistir sesión
        self.db.save_training_session(session_id, data_source_uri, model_config)

        # Preparar datos
        logger.info(f"[{session_id}] Preparando datos desde {data_source_uri}")
        data_path = self._prepare_data(data_source_uri, session_dir)

        # Guardar estado
        self._active_sessions[session_id] = {
            "status": "running",
            "data_path": data_path,
            "config": model_config,
            "output_uri": output_uri,
            "on_progress": on_progress,
        }

        # Lanzar entrenamiento en hilo separado
        import threading
        thread = threading.Thread(
            target=self._run_training,
            args=(session_id, data_path, model_config, output_uri, on_progress),
            daemon=True,
        )
        thread.start()
        self._active_sessions[session_id]["thread"] = thread

        logger.info(f"[{session_id}] Entrenamiento iniciado")
        return session_id

    def get_status(self, session_id: str) -> Dict[str, Any]:
        """Retorna el estado actual de una sesión."""
        sessions = self.db.get_training_sessions(limit=100)
        for s in sessions:
            if s["session_id"] == session_id:
                return s
        return {"session_id": session_id, "status": "not_found"}

    def list_sessions(self) -> List[Dict]:
        """Lista todas las sesiones de entrenamiento."""
        return self.db.get_training_sessions()

    def stop_training(self, session_id: str) -> bool:
        """Detiene una sesión de entrenamiento activa."""
        session = self._active_sessions.get(session_id)
        if not session:
            return False
        session["status"] = "stopping"
        self.db.update_training_session(session_id, "stopped")
        logger.info(f"[{session_id}] Entrenamiento detenido")
        return True

    # ------------------------------------------------------------------
    # Preparación de datos
    # ------------------------------------------------------------------

    def _prepare_data(self, uri: str, session_dir: str) -> str:
        """
        Descarga/copia los datos al directorio de sesión.
        Retorna la ruta local de los datos.
        """
        if uri.startswith("local:"):
            path = uri[6:]
            if os.path.isfile(path):
                dest = os.path.join(session_dir, os.path.basename(path))
                import shutil
                shutil.copy2(path, dest)
                return dest
            return path  # Directorio local, usar directamente

        # Para fuentes remotas/cloud, descargar al directorio de sesión
        if self.unified:
            files = self.unified.list_path(uri)
            data_dir = os.path.join(session_dir, "data")
            os.makedirs(data_dir, exist_ok=True)
            for f in files:
                if not f.get("is_folder"):
                    dest = os.path.join(data_dir, f["name"])
                    try:
                        self._download_file(uri, f, dest)
                    except Exception as e:
                        logger.warning(f"No se pudo descargar {f['name']}: {e}")
            return data_dir

        raise ValueError(f"No se pudo preparar datos desde: {uri}")

    def _download_file(self, base_uri: str, file_info: Dict, dest: str) -> None:
        if base_uri.startswith("gdrive:"):
            self.unified._cloud.download_file("google_drive", file_info["file_id"], dest)
        elif base_uri.startswith("dropbox:"):
            self.unified._cloud.download_file("dropbox", file_info["path"], dest)
        else:
            parts = base_uri.split(":", 2)
            if len(parts) == 3:
                self.unified._remote.download_file(parts[1], file_info["path"], dest)

    # ------------------------------------------------------------------
    # Entrenamiento
    # ------------------------------------------------------------------

    def _run_training(
        self,
        session_id: str,
        data_path: str,
        config: Dict,
        output_uri: Optional[str],
        on_progress: Optional[Callable],
    ) -> None:
        """Ejecuta el entrenamiento usando TenMiNaTor."""
        try:
            self.db.update_training_session(session_id, "running", 0.0)

            # Intentar usar TenMiNaTor si está disponible
            try:
                from tenminator_lib.training import Trainer
                from tenminator_lib.data import DataLoader

                loader = DataLoader(data_path)
                dataset = loader.load()

                trainer = Trainer(
                    epochs=config.get("epochs", 10),
                    learning_rate=config.get("learning_rate", 0.001),
                    batch_size=config.get("batch_size", 32),
                    early_stop_patience=config.get("early_stop_patience", 12),
                )

                def progress_callback(epoch: int, total: int, loss: float):
                    pct = (epoch / total) * 100
                    self.db.update_training_session(
                        session_id, "running", pct, loss,
                        {"epoch": epoch, "total_epochs": total, "loss": loss}
                    )
                    if on_progress:
                        on_progress(session_id, pct, loss)

                model = trainer.train(dataset, on_epoch=progress_callback)

                # Guardar modelo
                model_path = os.path.join(self.work_dir, session_id, "model.pkl")
                trainer.save(model, model_path)

                # Exportar al destino si se especificó
                if output_uri:
                    self._export_model(model_path, output_uri, session_id)

                self.db.update_training_session(session_id, "completed", 100.0,
                                                 trainer.best_loss)
                logger.info(f"[{session_id}] Entrenamiento completado. Loss: {trainer.best_loss:.4f}")

            except ImportError:
                # TenMiNaTor no disponible: simulación para demo
                logger.warning(f"[{session_id}] TenMiNaTor no disponible, ejecutando demo")
                self._run_demo_training(session_id, config, on_progress)

        except Exception as e:
            logger.error(f"[{session_id}] Error en entrenamiento: {e}")
            self.db.update_training_session(session_id, "failed", metrics={"error": str(e)})
        finally:
            self._active_sessions.pop(session_id, None)

    def _run_demo_training(
        self,
        session_id: str,
        config: Dict,
        on_progress: Optional[Callable],
    ) -> None:
        """Simulación de entrenamiento para demo sin TenMiNaTor instalado."""
        import time
        import math
        epochs = config.get("epochs", 10)
        for epoch in range(1, epochs + 1):
            session = self._active_sessions.get(session_id, {})
            if session.get("status") == "stopping":
                break
            time.sleep(0.5)
            loss = 2.0 * math.exp(-0.3 * epoch) + 0.05
            pct = (epoch / epochs) * 100
            self.db.update_training_session(
                session_id, "running", pct, loss,
                {"epoch": epoch, "total_epochs": epochs, "loss": round(loss, 4)}
            )
            if on_progress:
                on_progress(session_id, pct, loss)
        self.db.update_training_session(session_id, "completed", 100.0, 0.05)

    def _export_model(self, model_path: str, output_uri: str, session_id: str) -> None:
        """Exporta el modelo al destino especificado."""
        if output_uri.startswith("local:"):
            dest_dir = output_uri[6:]
            os.makedirs(dest_dir, exist_ok=True)
            import shutil
            shutil.copy2(model_path, os.path.join(dest_dir, f"model_{session_id}.pkl"))
        else:
            logger.warning(f"Exportación a {output_uri} no implementada aún")
