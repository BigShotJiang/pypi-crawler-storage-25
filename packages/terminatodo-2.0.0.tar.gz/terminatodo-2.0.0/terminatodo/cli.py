"""
TerminaTodo CLI v2
==================
Punto de entrada de línea de comandos.

Uso:
    terminatodo start              # Inicia la API en puerto 8765
    terminatodo start --port 9000  # Puerto personalizado
    terminatodo list               # Lista almacenamientos
    terminatodo sync src dst       # Sincroniza
    terminatodo training start ... # Gestión de entrenamiento
"""
import argparse
import sys
import json
import logging


def main():
    parser = argparse.ArgumentParser(
        prog="terminatodo",
        description="TerminaTodo v2 — Gestión unificada de almacenamiento para Deep Learning",
    )
    parser.add_argument("--verbose", "-v", action="store_true", help="Modo verbose")

    subparsers = parser.add_subparsers(dest="command")

    # start
    p_start = subparsers.add_parser("start", help="Inicia la API REST")
    p_start.add_argument("--host", default="0.0.0.0", help="Host (default: 0.0.0.0)")
    p_start.add_argument("--port", type=int, default=8765, help="Puerto (default: 8765)")
    p_start.add_argument("--db", default="terminatodo.db", help="Ruta de la base de datos")

    # list
    p_list = subparsers.add_parser("list", help="Lista todos los almacenamientos")
    p_list.add_argument("--db", default="terminatodo.db")

    # sync
    p_sync = subparsers.add_parser("sync", help="Sincroniza source → destination")
    p_sync.add_argument("source", help="URI fuente (ej: local:/data)")
    p_sync.add_argument("destination", help="URI destino (ej: gdrive:/backup)")
    p_sync.add_argument("--db", default="terminatodo.db")

    # training
    p_train = subparsers.add_parser("training", help="Gestión de entrenamiento")
    train_sub = p_train.add_subparsers(dest="train_cmd")
    p_train_start = train_sub.add_parser("start", help="Inicia entrenamiento")
    p_train_start.add_argument("data_uri", help="URI de datos de entrenamiento")
    p_train_start.add_argument("--epochs", type=int, default=10)
    p_train_start.add_argument("--lr", type=float, default=0.001)
    p_train_start.add_argument("--output", help="URI de salida del modelo")
    p_train_start.add_argument("--db", default="terminatodo.db")
    p_train_list = train_sub.add_parser("list", help="Lista sesiones")
    p_train_list.add_argument("--db", default="terminatodo.db")

    # version
    subparsers.add_parser("version", help="Muestra la versión")

    args = parser.parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    if args.command == "version":
        from terminatodo import __version__
        print(f"TerminaTodo v{__version__}")

    elif args.command == "start":
        from terminatodo.core import TerminaTodo
        print(f"🚀 TerminaTodo API iniciando en http://{args.host}:{args.port}")
        print(f"📚 Documentación: http://{args.host}:{args.port}/docs")
        print("   Ctrl+C para detener\n")
        tt = TerminaTodo(db_path=args.db, port=args.port)
        tt.start(host=args.host, blocking=True)

    elif args.command == "list":
        from terminatodo.core import TerminaTodo
        tt = TerminaTodo(db_path=args.db)
        data = tt.list_all()
        print(json.dumps(data, indent=2, ensure_ascii=False))

    elif args.command == "sync":
        from terminatodo.core import TerminaTodo
        tt = TerminaTodo(db_path=args.db)
        result = tt.sync(args.source, args.destination)
        print(json.dumps(result, indent=2, ensure_ascii=False))

    elif args.command == "training":
        from terminatodo.core import TerminaTodo
        from terminatodo.training.training_bridge import TrainingBridge

        if args.train_cmd == "start":
            tt = TerminaTodo(db_path=args.db)
            bridge = TrainingBridge(db_path=args.db, unified_manager=tt.unified)
            config = {"epochs": args.epochs, "learning_rate": args.lr}
            print(f"🏋️  Iniciando entrenamiento desde {args.data_uri}")

            def on_progress(sid, pct, loss):
                bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
                print(f"\r  [{bar}] {pct:.1f}% | Loss: {loss:.4f}", end="", flush=True)

            session_id = bridge.start_training(
                data_source_uri=args.data_uri,
                model_config=config,
                output_uri=args.output,
                on_progress=on_progress,
            )
            print(f"\n✅ Sesión iniciada: {session_id}")

        elif args.train_cmd == "list":
            tt = TerminaTodo(db_path=args.db)
            sessions = tt.db.get_training_sessions()
            if not sessions:
                print("No hay sesiones de entrenamiento.")
            else:
                print(f"{'ID':<10} {'Estado':<12} {'Progreso':<10} {'Loss':<10} {'Creada'}")
                print("-" * 60)
                for s in sessions:
                    loss = f"{s['loss']:.4f}" if s.get("loss") else "—"
                    print(f"{s['session_id']:<10} {s['status']:<12} "
                          f"{s['progress']:.1f}%{'':<5} {loss:<10} {s['created_at']}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
