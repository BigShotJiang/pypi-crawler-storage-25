"""
Database — SQLite persistence for TerminaTodo v2
"""
import sqlite3
import json
import logging
from typing import Optional, List, Dict, Any
from contextlib import contextmanager

logger = logging.getLogger(__name__)


class Database:
    """SQLite-backed persistence layer."""

    def __init__(self, db_path: str = "terminatodo.db"):
        self.db_path = db_path
        self._init_schema()

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS cloud_credentials (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    service TEXT NOT NULL UNIQUE,
                    credentials_json TEXT NOT NULL,
                    created_at TEXT DEFAULT (datetime('now')),
                    updated_at TEXT DEFAULT (datetime('now'))
                );

                CREATE TABLE IF NOT EXISTS remote_servers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    server_id TEXT NOT NULL UNIQUE,
                    name TEXT NOT NULL,
                    host TEXT NOT NULL,
                    port INTEGER NOT NULL,
                    protocol TEXT NOT NULL,
                    username TEXT,
                    password TEXT,
                    api_key TEXT,
                    created_at TEXT DEFAULT (datetime('now'))
                );

                CREATE TABLE IF NOT EXISTS sync_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source TEXT NOT NULL,
                    destination TEXT NOT NULL,
                    status TEXT NOT NULL,
                    files_synced INTEGER DEFAULT 0,
                    bytes_transferred INTEGER DEFAULT 0,
                    error TEXT,
                    started_at TEXT DEFAULT (datetime('now')),
                    finished_at TEXT
                );

                CREATE TABLE IF NOT EXISTS training_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL UNIQUE,
                    storage_source TEXT NOT NULL,
                    config_json TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',
                    progress REAL DEFAULT 0.0,
                    loss REAL,
                    metrics_json TEXT,
                    created_at TEXT DEFAULT (datetime('now')),
                    updated_at TEXT DEFAULT (datetime('now'))
                );
            """)
        logger.info(f"Database initialized at {self.db_path}")

    # ------------------------------------------------------------------
    # Cloud credentials
    # ------------------------------------------------------------------

    def save_cloud_credentials(self, service: str, credentials: Dict) -> None:
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO cloud_credentials (service, credentials_json, updated_at)
                VALUES (?, ?, datetime('now'))
                ON CONFLICT(service) DO UPDATE SET
                    credentials_json = excluded.credentials_json,
                    updated_at = datetime('now')
            """, (service, json.dumps(credentials)))

    def get_cloud_credentials(self, service: str) -> Optional[Dict]:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT credentials_json FROM cloud_credentials WHERE service = ?",
                (service,)
            ).fetchone()
        return json.loads(row["credentials_json"]) if row else None

    # ------------------------------------------------------------------
    # Remote servers
    # ------------------------------------------------------------------

    def save_remote_server(self, config: Dict) -> None:
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO remote_servers
                    (server_id, name, host, port, protocol, username, password, api_key)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(server_id) DO UPDATE SET
                    name = excluded.name, host = excluded.host,
                    port = excluded.port, protocol = excluded.protocol,
                    username = excluded.username, password = excluded.password,
                    api_key = excluded.api_key
            """, (
                config["server_id"], config["name"], config["host"],
                config["port"], config["protocol"],
                config.get("username"), config.get("password"), config.get("api_key")
            ))

    def list_remote_servers(self) -> List[Dict]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT server_id, name, host, port, protocol, username FROM remote_servers"
            ).fetchall()
        return [dict(r) for r in rows]

    def delete_remote_server(self, server_id: str) -> None:
        with self._conn() as conn:
            conn.execute("DELETE FROM remote_servers WHERE server_id = ?", (server_id,))

    # ------------------------------------------------------------------
    # Sync history
    # ------------------------------------------------------------------

    def log_sync(self, source: str, destination: str, status: str,
                 files_synced: int = 0, bytes_transferred: int = 0,
                 error: Optional[str] = None) -> int:
        with self._conn() as conn:
            cur = conn.execute("""
                INSERT INTO sync_history
                    (source, destination, status, files_synced, bytes_transferred, error, finished_at)
                VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
            """, (source, destination, status, files_synced, bytes_transferred, error))
            return cur.lastrowid

    def get_sync_history(self, limit: int = 50) -> List[Dict]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM sync_history ORDER BY started_at DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Training sessions
    # ------------------------------------------------------------------

    def save_training_session(self, session_id: str, storage_source: str,
                               config: Dict) -> None:
        with self._conn() as conn:
            conn.execute("""
                INSERT INTO training_sessions (session_id, storage_source, config_json)
                VALUES (?, ?, ?)
                ON CONFLICT(session_id) DO NOTHING
            """, (session_id, storage_source, json.dumps(config)))

    def update_training_session(self, session_id: str, status: str,
                                 progress: float = 0.0, loss: Optional[float] = None,
                                 metrics: Optional[Dict] = None) -> None:
        with self._conn() as conn:
            conn.execute("""
                UPDATE training_sessions SET
                    status = ?, progress = ?, loss = ?,
                    metrics_json = ?, updated_at = datetime('now')
                WHERE session_id = ?
            """, (status, progress, loss,
                  json.dumps(metrics) if metrics else None, session_id))

    def get_training_sessions(self, limit: int = 20) -> List[Dict]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM training_sessions ORDER BY created_at DESC LIMIT ?", (limit,)
            ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["config"] = json.loads(d.pop("config_json", "{}"))
            d["metrics"] = json.loads(d.pop("metrics_json") or "{}")
            result.append(d)
        return result
