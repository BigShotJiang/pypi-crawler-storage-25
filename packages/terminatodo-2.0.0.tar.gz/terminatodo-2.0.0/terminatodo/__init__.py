"""
TerminaTodo v2.0
================
Framework unificado para gestión de almacenamiento múltiple:
- Almacenamiento local (SSD, HDD, pendrives, memoria)
- Nube (Google Drive, OneDrive, Dropbox)
- Hosting privado (SFTP, FTP, HTTP/S, S3)
- Integración con TenMiNaTor para entrenamiento de modelos
- API REST completa con autenticación JWT
- Persistencia SQLite

Uso rápido:
    from terminatodo import TerminaTodo
    tt = TerminaTodo()
    tt.start()          # inicia API en http://localhost:8765
    storages = tt.list_all()
    tt.sync("local:./data", "gdrive:/datasets")
"""

__version__ = "2.0.0"
__author__ = "Cristian / yoqer"
__license__ = "MIT"
__description__ = "Framework unificado de almacenamiento para Deep Learning"

from .core import TerminaTodo
from .storage.local_storage import LocalStorageManager
from .cloud.cloud_manager import CloudStorageManager
from .hosting.remote_manager import RemoteStorageManager
from .storage.unified_manager import UnifiedStorageManager
from .training.training_bridge import TrainingBridge

__all__ = [
    "TerminaTodo",
    "LocalStorageManager",
    "CloudStorageManager",
    "RemoteStorageManager",
    "UnifiedStorageManager",
    "TrainingBridge",
]
