"""
Tests completos para TerminaTodo v2
====================================
Ejecutar con: pytest tests/ -v
"""
import os
import json
import tempfile
import pytest
from pathlib import Path


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------

@pytest.fixture
def tmp_db(tmp_path):
    return str(tmp_path / "test.db")


@pytest.fixture
def db(tmp_db):
    from terminatodo.db.database import Database
    return Database(tmp_db)


@pytest.fixture
def local_mgr():
    from terminatodo.storage.local_storage import LocalStorageManager
    return LocalStorageManager()


@pytest.fixture
def cloud_mgr(tmp_db):
    from terminatodo.cloud.cloud_manager import CloudStorageManager
    return CloudStorageManager(db_path=tmp_db)


@pytest.fixture
def remote_mgr(tmp_db):
    from terminatodo.hosting.remote_manager import RemoteStorageManager
    return RemoteStorageManager(db_path=tmp_db)


@pytest.fixture
def tt_instance(tmp_db):
    from terminatodo.core import TerminaTodo
    return TerminaTodo(db_path=tmp_db)


@pytest.fixture
def api_client(tt_instance):
    from fastapi.testclient import TestClient
    from terminatodo.api.app import create_app
    app = create_app(tt_instance)
    return TestClient(app)


@pytest.fixture
def auth_headers(api_client):
    resp = api_client.post("/auth/login", json={"username": "admin", "password": "terminatodo2024"})
    token = resp.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


# ------------------------------------------------------------------
# Tests: Database
# ------------------------------------------------------------------

class TestDatabase:
    def test_init_creates_tables(self, db):
        """La base de datos se inicializa con las tablas correctas."""
        import sqlite3
        conn = sqlite3.connect(db.db_path)
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()}
        conn.close()
        assert "cloud_credentials" in tables
        assert "remote_servers" in tables
        assert "sync_history" in tables
        assert "training_sessions" in tables

    def test_save_and_get_cloud_credentials(self, db):
        creds = {"access_token": "tok123", "refresh_token": "ref456"}
        db.save_cloud_credentials("google_drive", creds)
        retrieved = db.get_cloud_credentials("google_drive")
        assert retrieved == creds

    def test_update_cloud_credentials(self, db):
        db.save_cloud_credentials("dropbox", {"access_token": "old"})
        db.save_cloud_credentials("dropbox", {"access_token": "new"})
        assert db.get_cloud_credentials("dropbox")["access_token"] == "new"

    def test_save_and_list_remote_servers(self, db):
        config = {
            "server_id": "srv1", "name": "Test Server",
            "host": "192.168.1.1", "port": 22,
            "protocol": "sftp", "username": "user"
        }
        db.save_remote_server(config)
        servers = db.list_remote_servers()
        assert len(servers) == 1
        assert servers[0]["server_id"] == "srv1"

    def test_delete_remote_server(self, db):
        db.save_remote_server({
            "server_id": "del1", "name": "To Delete",
            "host": "10.0.0.1", "port": 22, "protocol": "sftp"
        })
        db.delete_remote_server("del1")
        assert db.list_remote_servers() == []

    def test_log_and_get_sync_history(self, db):
        db.log_sync("local:/src", "local:/dst", "completed", files_synced=5, bytes_transferred=1024)
        history = db.get_sync_history()
        assert len(history) == 1
        assert history[0]["files_synced"] == 5

    def test_training_session_lifecycle(self, db):
        db.save_training_session("sess1", "local:/data", {"epochs": 5})
        db.update_training_session("sess1", "running", 50.0, 0.5)
        sessions = db.get_training_sessions()
        assert len(sessions) == 1
        assert sessions[0]["status"] == "running"
        assert sessions[0]["progress"] == 50.0


# ------------------------------------------------------------------
# Tests: Auth
# ------------------------------------------------------------------

class TestAuth:
    def test_create_and_verify_token(self):
        from terminatodo.auth.jwt_auth import create_token, verify_token
        token = create_token({"sub": "testuser"})
        payload = verify_token(token)
        assert payload is not None
        assert payload["sub"] == "testuser"

    def test_expired_token_rejected(self):
        from terminatodo.auth.jwt_auth import create_token, verify_token
        token = create_token({"sub": "user"}, expires_in=-1)
        assert verify_token(token) is None

    def test_tampered_token_rejected(self):
        from terminatodo.auth.jwt_auth import create_token, verify_token
        token = create_token({"sub": "user"})
        tampered = token[:-5] + "XXXXX"
        assert verify_token(tampered) is None

    def test_hash_and_verify_password(self):
        from terminatodo.auth.jwt_auth import hash_password, verify_password
        hashed = hash_password("mysecret")
        assert verify_password("mysecret", hashed)
        assert not verify_password("wrong", hashed)


# ------------------------------------------------------------------
# Tests: Local Storage
# ------------------------------------------------------------------

class TestLocalStorage:
    def test_list_devices_returns_list(self, local_mgr):
        devices = local_mgr.list_devices()
        assert isinstance(devices, list)
        assert len(devices) > 0

    def test_list_devices_has_required_fields(self, local_mgr):
        devices = local_mgr.list_devices()
        for d in devices:
            assert "device_id" in d
            assert "name" in d
            assert "device_type" in d

    def test_list_files_in_tmp(self, local_mgr):
        with tempfile.TemporaryDirectory() as tmpdir:
            Path(tmpdir, "file1.txt").write_text("hello")
            Path(tmpdir, "file2.csv").write_text("a,b,c")
            files = local_mgr.list_files(tmpdir)
            names = {f["name"] for f in files}
            assert "file1.txt" in names
            assert "file2.csv" in names

    def test_list_files_not_found(self, local_mgr):
        with pytest.raises(FileNotFoundError):
            local_mgr.list_files("/nonexistent/path/xyz")

    def test_get_disk_usage(self, local_mgr):
        usage = local_mgr.get_disk_usage("/")
        assert usage["total_gb"] > 0
        assert 0 <= usage["used_pct"] <= 100


# ------------------------------------------------------------------
# Tests: Cloud Manager
# ------------------------------------------------------------------

class TestCloudManager:
    def test_get_available_services(self, cloud_mgr):
        services = cloud_mgr.get_available_services()
        ids = {s["id"] for s in services}
        assert "google_drive" in ids
        assert "dropbox" in ids
        assert "onedrive" in ids

    def test_services_unauthenticated_by_default(self, cloud_mgr):
        services = cloud_mgr.get_available_services()
        for s in services:
            assert s["authenticated"] is False

    def test_dropbox_auth_saved(self, cloud_mgr):
        # Sin SDK real, solo verifica que se guarda en DB
        cloud_mgr.db.save_cloud_credentials("dropbox", {"access_token": "test_tok"})
        creds = cloud_mgr.db.get_cloud_credentials("dropbox")
        assert creds["access_token"] == "test_tok"


# ------------------------------------------------------------------
# Tests: Remote Manager
# ------------------------------------------------------------------

class TestRemoteManager:
    def test_list_servers_empty(self, remote_mgr):
        assert remote_mgr.list_servers() == []

    def test_add_and_list_server(self, remote_mgr):
        config = {
            "server_id": "test1", "name": "Test", "host": "localhost",
            "port": 22, "protocol": "sftp", "username": "user"
        }
        remote_mgr.add_server(config)
        servers = remote_mgr.list_servers()
        assert len(servers) == 1
        assert servers[0]["server_id"] == "test1"

    def test_remove_server(self, remote_mgr):
        remote_mgr.add_server({
            "server_id": "del1", "name": "Del", "host": "localhost",
            "port": 21, "protocol": "ftp"
        })
        remote_mgr.remove_server("del1")
        assert remote_mgr.list_servers() == []


# ------------------------------------------------------------------
# Tests: API
# ------------------------------------------------------------------

class TestAPI:
    def test_root_endpoint(self, api_client):
        resp = api_client.get("/")
        assert resp.status_code == 200
        assert resp.json()["name"] == "TerminaTodo API"

    def test_health_endpoint(self, api_client):
        resp = api_client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"

    def test_login_success(self, api_client):
        resp = api_client.post("/auth/login",
                               json={"username": "admin", "password": "terminatodo2024"})
        assert resp.status_code == 200
        assert "access_token" in resp.json()

    def test_login_wrong_password(self, api_client):
        resp = api_client.post("/auth/login",
                               json={"username": "admin", "password": "wrong"})
        assert resp.status_code == 401

    def test_protected_endpoint_without_token(self, api_client):
        resp = api_client.get("/storage/local/devices")
        assert resp.status_code == 401

    def test_list_local_devices_authenticated(self, api_client, auth_headers):
        resp = api_client.get("/storage/local/devices", headers=auth_headers)
        assert resp.status_code == 200
        assert "devices" in resp.json()

    def test_list_cloud_services(self, api_client, auth_headers):
        resp = api_client.get("/storage/cloud/services", headers=auth_headers)
        assert resp.status_code == 200
        assert "services" in resp.json()

    def test_add_remote_server(self, api_client, auth_headers):
        resp = api_client.post("/storage/remote/servers", headers=auth_headers, json={
            "server_id": "api_test", "name": "API Test", "host": "localhost",
            "port": 22, "protocol": "sftp"
        })
        assert resp.status_code == 200
        assert resp.json()["server_id"] == "api_test"

    def test_list_all_storages(self, api_client, auth_headers):
        resp = api_client.get("/storage/all", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert "local" in data
        assert "cloud" in data
        assert "remote" in data

    def test_start_training_session(self, api_client, auth_headers, tmp_path):
        # Crear archivo de datos temporal
        data_file = tmp_path / "data.csv"
        data_file.write_text("x,y\n1,2\n3,4\n5,6\n")
        resp = api_client.post("/training/start", headers=auth_headers, json={
            "data_source_uri": f"local:{str(data_file)}",
            "model_config": {"epochs": 2, "learning_rate": 0.01},
        })
        assert resp.status_code == 200
        assert "session_id" in resp.json()

    def test_list_training_sessions(self, api_client, auth_headers):
        resp = api_client.get("/training/sessions", headers=auth_headers)
        assert resp.status_code == 200
        assert "sessions" in resp.json()
