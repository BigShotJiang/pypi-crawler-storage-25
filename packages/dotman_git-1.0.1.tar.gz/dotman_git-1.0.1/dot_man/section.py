"""Section configuration for dot-man."""

__all__ = ["Section"]

import os
from pathlib import Path
from typing import Any, Optional

from .config_detector import ConfigDetector
from .constants import (
    DEFAULT_IGNORED_DIRECTORIES,
    HOOK_ALIASES,
)


def _expand_path(path_str: str) -> Path:
    """Expand environment variables and ~ in a path string."""
    expanded = os.path.expandvars(os.path.expanduser(path_str))
    return Path(expanded)


class Section:
    """Represents a resolved configuration section with smart defaults."""

    def __init__(
        self,
        name: str,
        paths: list[Path],
        repo_base: Optional[str] = None,  # NOW OPTIONAL!
        repo_path: Optional[str] = None,
        secrets_filter: Optional[bool] = None,  # None = use default
        update_strategy: Optional[str] = None,  # None = use default
        include: Optional[list[str]] = None,
        exclude: Optional[list[str]] = None,
        pre_deploy: Optional[str] = None,
        post_deploy: Optional[str] = None,
        on_activate: Optional[str] = None,
        on_deactivate: Optional[str] = None,
        inherits: Optional[list[str]] = None,
        ignored_directories: Optional[list[str]] = None,
        follow_symlinks: Optional[bool] = None,
        encrypted: Optional[bool] = None,
        encryption_method: Optional[str] = None,
        encryption_recipient: Optional[str] = None,
    ):
        self.name = name
        # Expand environment variables in paths
        self.paths = [_expand_path(str(p)) if isinstance(p, str) else p for p in paths]
        self.repo_path = repo_path

        # Smart repo_base generation if not provided
        if repo_base is None and not repo_path:
            self.repo_base = self._generate_repo_base()
        else:
            self.repo_base = repo_base or name

        # Use provided values or defaults (None means "use global default")
        self.secrets_filter = secrets_filter if secrets_filter is not None else True
        self.update_strategy = update_strategy or "replace"

        self.include = include or []
        self.exclude = exclude or []

        # Resolve hook aliases
        self.pre_deploy = self._resolve_hook(pre_deploy)
        self.post_deploy = self._resolve_hook(post_deploy)
        self.on_activate = on_activate
        self.on_deactivate = on_deactivate

        self.inherits = inherits or []

        self.ignored_directories = (
            ignored_directories
            if ignored_directories is not None
            else DEFAULT_IGNORED_DIRECTORIES
        )
        self.follow_symlinks = follow_symlinks if follow_symlinks is not None else False

        # Encryption options
        self.encrypted = encrypted if encrypted is not None else False
        self.encryption_method = encryption_method or "gpg"
        self.encryption_recipient = encryption_recipient

    def _generate_repo_base(self) -> str:
        """Auto-generate repo_base from first path.

        Examples:
            ~/.bashrc → "bashrc"
            ~/.config/nvim → "nvim"
            ~/.ssh/config → "ssh/config"
        """
        if not self.paths:
            return self.name

        first_path = self.paths[0]

        # Handle dotfiles: ~/.bashrc → "bashrc"
        if first_path.name.startswith(".") and first_path.suffix:
            # .bashrc → bashrc, .vimrc → vimrc
            return first_path.name[1:]

        if first_path.name.startswith(".") and not first_path.suffix:
            # .vim → vim, .ssh → ssh
            return first_path.name[1:]

        # Handle .config directories: ~/.config/nvim → "nvim"
        if ".config" in first_path.parts:
            return first_path.name

        # Handle subdirectories: ~/.ssh/config → "ssh/config"
        if len(first_path.parts) > 1 and first_path.is_file():
            parent_name = first_path.parent.name
            if parent_name.startswith("."):
                parent_name = parent_name[1:]
            return f"{parent_name}/{first_path.name}"

        # Fallback: use stem or name
        return first_path.stem or first_path.name

    def _resolve_hook(self, hook: str | None) -> str | None:
        """Resolve hook aliases to actual commands.

        Examples:
            "shell_reload" → "source ~/.bashrc || ..."
            "nvim_sync" → "nvim --headless +PackerSync +qa"
            "quickshell_reload" → "killall qs; qs -c ii &" (with detected config)
            "echo hello" → "echo hello" (unchanged)
        """
        if not hook:
            return None

        # Check if it's an alias
        resolved = HOOK_ALIASES.get(hook, hook)

        # Replace {qs_config} placeholder with detected quickshell config dir
        if "{qs_config}" in resolved:
            qs_config = self._detect_quickshell_config()
            resolved = resolved.replace("{qs_config}", qs_config)

        return resolved

    def _detect_quickshell_config(self) -> str:
        """Detect the quickshell config directory name from section paths.

        Uses ConfigDetector for comprehensive detection.

        Returns:
            Config directory name (e.g., "ii", "caelestea") or empty string if not found.
        """
        for path in self.paths:
            config_name = ConfigDetector.get_quickshell_config_name(path)
            if config_name:
                return config_name
        return ""

    def get_repo_path(self, local_path: Path, repo_dir: Path) -> Path:
        """Get the repository path for a local path."""
        if self.repo_path:
            # Explicit repo_path for single files
            return repo_dir / self.repo_path
        # Use repo_base + filename
        return repo_dir / self.repo_base / local_path.name

    def to_dict(self) -> dict[str, Any]:
        """Convert section to dictionary (only non-default values)."""
        result: dict[str, Any] = {
            "paths": [str(p) for p in self.paths],
        }

        # Only include if non-default or explicitly set
        if self.repo_path:
            result["repo_path"] = self.repo_path
        elif self.repo_base != self._generate_repo_base():
            # Only save repo_base if it differs from auto-generated
            result["repo_base"] = self.repo_base

        if self.secrets_filter is not True:  # Only if NOT default
            result["secrets_filter"] = self.secrets_filter
        if self.update_strategy != "replace":  # Only if NOT default
            result["update_strategy"] = self.update_strategy
        if self.include:
            result["include"] = self.include
        if self.exclude:
            result["exclude"] = self.exclude
        if self.pre_deploy:
            result["pre_deploy"] = self.pre_deploy
        if self.post_deploy:
            result["post_deploy"] = self.post_deploy
        if self.on_activate:
            result["on_activate"] = self.on_activate
        if self.on_deactivate:
            result["on_deactivate"] = self.on_deactivate
        if self.inherits:
            result["inherits"] = self.inherits

        if self.ignored_directories != DEFAULT_IGNORED_DIRECTORIES:
            result["ignored_directories"] = self.ignored_directories
        if self.follow_symlinks is not False:
            result["follow_symlinks"] = self.follow_symlinks
        if self.encrypted:
            result["encrypted"] = self.encrypted
        if self.encryption_method != "gpg":
            result["encryption_method"] = self.encryption_method
        if self.encryption_recipient:
            result["encryption_recipient"] = self.encryption_recipient

        return result
