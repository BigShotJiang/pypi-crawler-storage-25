"""Secret detection patterns and filtering logic."""

__all__ = [
    "SecretScanner",
    "SecretMatch",
    "SecretPattern",
    "SecretGuard",
    "PermanentRedactGuard",
    "Severity",
    "filter_secrets",
]

import json
import logging
import re
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Callable, Iterable, Iterator, TypedDict

from .constants import DOT_MAN_DIR, SECRET_REDACTION_TEXT
from .utils import sha256_hex


def _canonicalize_path(file_path: Path | str) -> str:
    """Resolve path to canonical absolute form for consistent matching.

    This ensures that ~/file, /home/user/file, and ./file all resolve
    to the same canonical path for reliable secret ignore list matching.
    """
    path = Path(file_path).expanduser()
    try:
        # resolve() handles symlinks and .. components
        return str(path.resolve())
    except OSError:
        # File might not exist yet, just expand and convert to absolute
        return str(path.absolute())


class AllowedSecret(TypedDict):
    """Structure for an allowed secret entry."""

    file_path: str
    secret_hash: str
    pattern_name: str
    added_at: str


class BaseSecretGuard:
    """Base class for managing secret lists (allow list, redact list)."""

    def __init__(
        self,
        config_dir: Path | None = None,
        path: Path | None = None,
        default_filename: str = "secrets.json",
    ):
        self.config_dir = config_dir or DOT_MAN_DIR
        self.list_path = path or (self.config_dir / default_filename)
        self._secrets: list[AllowedSecret] = self._load()

    def _load(self) -> list[AllowedSecret]:
        """Load secrets from disk."""
        if not self.list_path.exists():
            return []
        try:
            content = self.list_path.read_text(encoding="utf-8")
            from typing import cast

            return cast(list[AllowedSecret], json.loads(content))
        except (FileNotFoundError, json.JSONDecodeError):
            return []
        except OSError:
            return []

    def save(self) -> None:
        """Save secrets to disk."""
        try:
            # Ensure directory exists
            self.list_path.parent.mkdir(parents=True, exist_ok=True)

            content = json.dumps(self._secrets, indent=2)
            self.list_path.write_text(content, encoding="utf-8")
        except OSError as e:
            logging.warning(f"Could not save secrets list: {e}")

    def _compute_hash(self, content: str) -> str:
        """Compute SHA256 hash of the content."""
        return sha256_hex(content)

    def _is_in_list(
        self, file_path: Path | str, line_content: str, pattern_name: str
    ) -> bool:
        """Check if a secret is in the list."""
        path_str = _canonicalize_path(file_path)
        content_hash = self._compute_hash(line_content)

        for secret in self._secrets:
            if (
                secret["file_path"] == path_str
                and secret["secret_hash"] == content_hash
                and secret["pattern_name"] == pattern_name
            ):
                return True
        return False

    def _add_to_list(
        self, file_path: Path | str, line_content: str, pattern_name: str
    ) -> None:
        """Add a secret to the list."""
        if self._is_in_list(file_path, line_content, pattern_name):
            return

        entry: AllowedSecret = {
            "file_path": _canonicalize_path(file_path),
            "secret_hash": self._compute_hash(line_content),
            "pattern_name": pattern_name,
            "added_at": datetime.now().isoformat(),
        }
        self._secrets.append(entry)
        self.save()


class SecretGuard(BaseSecretGuard):
    """Manages the list of allowed (skipped) secrets."""

    def __init__(self, config_dir: Path | None = None, path: Path | None = None):
        super().__init__(
            config_dir, path, default_filename=".dotman-allowed-secrets.json"
        )

    def is_allowed(
        self, file_path: Path | str, line_content: str, pattern_name: str
    ) -> bool:
        """Check if a secret is in the allow list."""
        return self._is_in_list(file_path, line_content, pattern_name)

    def add_allowed(
        self, file_path: Path | str, line_content: str, pattern_name: str
    ) -> None:
        """Add a secret to the allow list."""
        self._add_to_list(file_path, line_content, pattern_name)


class PermanentRedactGuard(BaseSecretGuard):
    """Manages the list of secrets that should always be redacted."""

    def __init__(self, config_dir: Path | None = None, path: Path | None = None):
        super().__init__(
            config_dir, path, default_filename=".dotman-permanent-redact.json"
        )

    def should_redact(
        self, file_path: Path | str, line_content: str, pattern_name: str
    ) -> bool:
        """Check if a secret should be permanently redacted."""
        return self._is_in_list(file_path, line_content, pattern_name)

    def add_permanent_redact(
        self, file_path: Path | str, line_content: str, pattern_name: str
    ) -> None:
        """Add a secret to the permanent redact list."""
        self._add_to_list(file_path, line_content, pattern_name)


class Severity(Enum):
    """Secret severity levels."""

    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


@dataclass
class SecretPattern:
    """A secret detection pattern."""

    name: str
    pattern: re.Pattern
    severity: Severity
    description: str


@dataclass
class SecretMatch:
    """A detected secret match."""

    file: Path
    line_number: int
    line_content: str
    pattern_name: str
    severity: Severity
    matched_text: str


# ============================================================================
# Default Patterns
# ============================================================================

DEFAULT_PATTERNS: list[SecretPattern] = [
    # CRITICAL - System/Cloud compromise
    SecretPattern(
        name="Private Key",
        pattern=re.compile(
            r"-----BEGIN\s+(?:RSA|DSA|EC|OPENSSH|PGP)?\s*PRIVATE KEY-----"
        ),
        severity=Severity.CRITICAL,
        description="SSH/GPG private key header detected",
    ),
    SecretPattern(
        name="AWS Access Key ID",
        pattern=re.compile(r"AKIA[0-9A-Z]{16}"),
        severity=Severity.CRITICAL,
        description="AWS Access Key ID format",
    ),
    SecretPattern(
        name="AWS Secret Key",
        pattern=re.compile(r"aws_secret_access_key\s*[=:]\s*\S+", re.IGNORECASE),
        severity=Severity.CRITICAL,
        description="AWS Secret Access Key assignment",
    ),
    # HIGH - Service compromise
    SecretPattern(
        name="GitHub Token",
        pattern=re.compile(r"gh[ps]_[a-zA-Z0-9]{36}"),
        severity=Severity.HIGH,
        description="GitHub Personal Access Token",
    ),
    SecretPattern(
        name="Generic API Key",
        pattern=re.compile(
            r"(?:api[_-]?key|apikey)\s*[=:]\s*['\"]?[\w-]{20,}['\"]?", re.IGNORECASE
        ),
        severity=Severity.HIGH,
        description="Generic API key assignment",
    ),
    SecretPattern(
        name="Password Assignment",
        pattern=re.compile(
            r"(?:password|passwd|pwd)\s*[=:]\s*['\"]?.+['\"]?", re.IGNORECASE
        ),
        severity=Severity.HIGH,
        description="Password assignment detected",
    ),
    SecretPattern(
        name="Bearer Token",
        pattern=re.compile(r"bearer\s+[a-zA-Z0-9._-]+", re.IGNORECASE),
        severity=Severity.HIGH,
        description="Bearer token detected",
    ),
    SecretPattern(
        name="Auth Token",
        pattern=re.compile(
            r"(?:auth[_-]?token|token)\s*[=:]\s*['\"]?[\w-]{20,}['\"]?", re.IGNORECASE
        ),
        severity=Severity.HIGH,
        description="Authentication token assignment",
    ),
    # MEDIUM - Potential exposure
    SecretPattern(
        name="JWT Token",
        pattern=re.compile(r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+"),
        severity=Severity.MEDIUM,
        description="JSON Web Token detected",
    ),
    SecretPattern(
        name="Generic Secret",
        pattern=re.compile(
            r"(?:secret|credential)\s*[=:]\s*['\"]?.+['\"]?", re.IGNORECASE
        ),
        severity=Severity.MEDIUM,
        description="Generic secret assignment",
    ),
]

# False positive indicators - lines containing these are skipped
FALSE_POSITIVE_INDICATORS = [
    "example",
    "dummy",
    "sample",
    "your_key_here",
    "your-key-here",
    "xxx",
    "placeholder",
    "<your",
    "${",  # Environment variable substitution
    "{{",  # Template variable
]


class SecretScanner:
    """Scans files for secrets."""

    def __init__(self, patterns: list[SecretPattern] | None = None):
        self.patterns = patterns or DEFAULT_PATTERNS

    def is_false_positive(self, line: str) -> bool:
        """Check if a line is likely a false positive."""
        line_lower = line.lower()
        return any(indicator in line_lower for indicator in FALSE_POSITIVE_INDICATORS)

    def is_binary_file(self, path: Path) -> bool:
        """Check if a file is binary."""
        try:
            with open(path, "rb") as f:
                chunk = f.read(8192)
                return b"\x00" in chunk
        except OSError:
            return True  # Assume binary if we can't read it

    def scan_lines(
        self, lines: Iterable[str], file_path: Path | None = None
    ) -> Iterator[SecretMatch]:
        """Scan lines for secrets."""
        file_path = file_path or Path("<string>")

        for line_number, line in enumerate(lines, start=1):
            # Skip likely false positives
            if self.is_false_positive(line):
                continue

            for pattern in self.patterns:
                match = pattern.pattern.search(line)
                if match:
                    yield SecretMatch(
                        file=file_path,
                        line_number=line_number,
                        line_content=line.strip(),
                        pattern_name=pattern.name,
                        severity=pattern.severity,
                        matched_text=match.group(0),
                    )

    def scan_content(
        self, content: str, file_path: Path | None = None
    ) -> Iterator[SecretMatch]:
        """Scan content for secrets."""
        return self.scan_lines(content.splitlines(), file_path)

    def scan_file(self, path: Path) -> Iterator[SecretMatch]:
        """Scan a file for secrets."""
        if self.is_binary_file(path):
            return

        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                yield from self.scan_lines(f, path)
        except (OSError, UnicodeDecodeError):
            # Skip files we can't read
            pass

    def scan_directory(
        self, directory: Path, exclude_patterns: list[str] | None = None
    ) -> Iterator[SecretMatch]:
        """Scan all files in a directory for secrets."""
        exclude_patterns = exclude_patterns or []

        for path in directory.rglob("*"):
            # Skip directories
            if path.is_dir():
                continue

            # Skip .git directory
            if ".git" in path.parts:
                continue

            # Skip excluded patterns
            if any(path.match(pattern) for pattern in exclude_patterns):
                continue

            yield from self.scan_file(path)

    def redact_content(
        self,
        content: str,
        callback: Callable[[SecretMatch], str] | None = None,
        file_path: Path | None = None,
    ) -> tuple[str, int]:
        """
        Redact secrets from content. Returns (redacted_content, count).

        Args:
            content: Text content to redact
            callback: Optional function that takes a SecretMatch and returns a string action ("REDACT")
                      OR the replacement string itself.
                      If it returns "REDACT", default redaction text is used.
                      If it returns anything else (and not "KEEP"), that string is used as replacement.
            file_path: Path to the file being scanned (for context in callback)
        """
        redacted_lines = []
        count = 0
        file_path = file_path or Path("<string>")

        for line_number, line in enumerate(content.splitlines(keepends=True), start=1):
            # precise matching logic needed to handle multiple secrets in one line appropriately
            # checking for false positives first
            if self.is_false_positive(line):
                redacted_lines.append(line)
                continue

            current_line = line

            for pattern in self.patterns:
                match = pattern.pattern.search(current_line)
                if match:
                    replacement_text = SECRET_REDACTION_TEXT
                    should_redact = True
                    matched_text = match.group(0)

                    if callback:
                        secret_match = SecretMatch(
                            file=file_path,
                            line_number=line_number,
                            line_content=line.strip(),
                            pattern_name=pattern.name,
                            severity=pattern.severity,
                            matched_text=matched_text,
                        )
                        result = callback(secret_match)

                        if result == "KEEP" or result == "IGNORE":
                            should_redact = False
                        elif result == "REDACT":
                            should_redact = True
                        else:
                            # Use custom replacement (e.g., hashed redaction)
                            should_redact = True
                            replacement_text = result

                    if should_redact:
                        # Replace the matched text with redaction
                        current_line = pattern.pattern.sub(
                            replacement_text, current_line
                        )
                        count += 1

            redacted_lines.append(current_line)

        return "".join(redacted_lines), count


def filter_secrets(
    content: str,
    callback: Callable[[SecretMatch], str] | None = None,
    file_path: Path | None = None,
) -> tuple[str, list[SecretMatch]]:
    """Filter secrets from content before saving.

    Returns:
        Tuple of (filtered_content, list_of_redacted_secrets)
        Note: Only secrets that were actually redacted are returned, not ignored ones.
    """
    scanner = SecretScanner()

    # Track which secrets were actually redacted
    redacted_secrets: list[SecretMatch] = []

    def tracking_callback(match: SecretMatch) -> str:
        if callback:
            result = callback(match)
            # Only add to redacted list if not ignored/kept
            if result not in ("KEEP", "IGNORE"):
                redacted_secrets.append(match)
            return result
        else:
            # No callback = always redact
            redacted_secrets.append(match)
            return "REDACT"

    filtered_content, _ = scanner.redact_content(content, tracking_callback, file_path)
    return filtered_content, redacted_secrets
