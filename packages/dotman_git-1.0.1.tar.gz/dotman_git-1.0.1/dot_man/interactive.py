"""Interactive CLI wizards for dot-man."""

__all__ = [
    "run_section_wizard",
    "run_global_wizard",
    "run_templates_wizard",
    "edit_template",
]

from pathlib import Path

import questionary
from questionary import Style, ValidationError, Validator
from rich.panel import Panel
from rich.table import Table

from .config import DotManConfig, GlobalConfig, Section
from .ui import console, error, print_banner, success, warn

# Questionary Custom Style
custom_style = Style(
    [
        ("qmark", "fg:#673ab7 bold"),  # Token.Question.Mark
        ("question", "bold"),  # Token.Question
        ("answer", "fg:#f44336 bold"),  # Token.Answer
        ("pointer", "fg:#673ab7 bold"),  # Token.Pointer
        ("highlighted", "fg:#673ab7 bold"),  # Token.Selected
        ("selected", "fg:#cc5454"),  # Token.Selected
        ("separator", "fg:#cc5454"),  # Token.Separator
        ("instruction", ""),  # Token.Instruction
        ("text", ""),  # Token.Text
        ("disabled", "fg:#858585 italic"),  # Token.Disabled
    ]
)


# Menu choices formatting
# We use questionary's formatting, not raw ANSI
def fmt_choice(text: str, action: str = "edit") -> questionary.Choice:
    """Format a choice with color based on action type."""
    return questionary.Choice(title=text, value=text)  # text is displayed


# Actually, questionary.Choice takes (title, value).
# To style the title, we can rely on the style sheet or use simple logic.
# But for different actions having different colors in the same list?
# Questionary supports FormattedText from prompt_toolkit, but simple strings are safer.
# Let's simple use prefixes or rely on 'pointer' color.
# OR we can keep using ANSI but use rich to generate it? No that's complex.
# Questionary's 'style' applies to the UI elements, difficult to style individual choices differently without prompt_toolkit.
# However, user asked to remove "hardcoded ANSI".
# Let's use simple textual prefixes for now, or just clean text.


class PathValidator(Validator):
    def validate(self, document):
        if not document.text:
            return  # Empty allowed
        path = Path(document.text).expanduser()
        if not path.is_absolute():
            # We generally prefer absolute paths or at least valid ones
            pass  # Relative paths are okay if intended


class UrlValidator(Validator):
    def validate(self, document):
        if not document.text:
            return
        if not (
            document.text.startswith("http://")
            or document.text.startswith("https://")
            or document.text.startswith("git@")
            or document.text.startswith("ssh://")
        ):
            raise ValidationError(
                message="Please enter a valid URL (http/https/ssh/git)",
                cursor_position=len(document.text),
            )


def print_section_dashboard(section: Section):
    """Print a dashboard summary for the section."""
    table = Table(title=None, box=None, show_header=False, padding=(0, 2))
    table.add_column("Key", style="cyan bold")
    table.add_column("Value")

    paths = ", ".join(str(p) for p in section.paths)
    inherits = ", ".join(section.inherits) if section.inherits else "[dim]None[/dim]"

    table.add_row("Paths", paths)
    table.add_row("Repo Base", section.repo_base)
    table.add_row("Update Strategy", section.update_strategy)
    table.add_row(
        "Secrets Filter",
        "[green]Enabled[/green]" if section.secrets_filter else "[dim]Disabled[/dim]",
    )
    table.add_row("InheritsFrom", inherits)
    table.add_row("Pre-deploy", section.pre_deploy or "[dim]None[/dim]")
    table.add_row("Post-deploy", section.post_deploy or "[dim]None[/dim]")

    console.print(
        Panel(
            table,
            title=f"[magenta bold]Editing Section: {section.name}[/magenta bold]",
            subtitle="[dim]Select a field below to edit[/dim]",
            border_style="cyan",
        )
    )


def run_section_wizard(config: DotManConfig, section_name: str):
    """Run interactive wizard to edit a section."""
    section = config.get_section(section_name)

    while True:
        console.clear()
        print_section_dashboard(section)
        console.print()

        # Using clean text, relying on style for selection highlight
        choices = [
            questionary.Choice("Edit Paths", value="paths"),
            questionary.Choice("Edit Repo Base", value="repo_base"),
            questionary.Choice("Edit Update Strategy", value="update_strategy"),
            questionary.Choice("Toggle Secrets Filter", value="secrets_filter"),
            questionary.Choice("Edit Inherits", value="inherits"),
            questionary.Choice("Edit Pre-deploy Hook", value="pre_deploy"),
            questionary.Choice("Edit Post-deploy Hook", value="post_deploy"),
            questionary.Separator(),
            questionary.Choice("Save & Return", value="save", shortcut_key="s"),
            questionary.Choice("Cancel", value="cancel", shortcut_key="q"),
        ]

        field = questionary.select(
            "Select action:", choices=choices, style=custom_style
        ).ask()

        if not field or field == "cancel":
            return

        if field == "save":
            try:
                # Fix paths to be relative if possible
                fixed_paths = []
                home = Path.home()
                for p in section.paths:
                    path_obj = Path(p)
                    if path_obj.is_absolute() and path_obj.is_relative_to(home):
                        # Convert absolute /home/user/.foo to .foo
                        # The config expects relative paths to imply relative to home (or repo checkout)
                        # Usually standard dotfiles are relative to home.
                        rel = path_obj.relative_to(home)
                        fixed_paths.append(str(rel))
                    else:
                        fixed_paths.append(str(p))

                # Re-add section to save changes (updates existing)
                config.add_section(
                    name=section_name,
                    paths=fixed_paths,
                    repo_base=section.repo_base,
                    update_strategy=section.update_strategy,
                    secrets_filter=section.secrets_filter,
                    pre_deploy=section.pre_deploy,
                    post_deploy=section.post_deploy,
                    include=section.include,
                    exclude=section.exclude,
                    inherits=section.inherits,
                    overwrite=True,
                )
                config.save()
                success(f"Section '{section_name}' updated.")
                return
            except Exception as e:
                error(f"Failed to save: {e}")
                input("Press Enter to continue...")
                continue

        # Field Editing
        if field == "paths":
            current = ", ".join(str(p) for p in section.paths)
            val = questionary.text(
                "Paths (comma separated):",
                default=current,
                validate=PathValidator,
                style=custom_style,
            ).ask()
            if val:
                section.paths = [Path(p.strip()) for p in val.split(",") if p.strip()]

        elif field == "repo_base":
            val = questionary.text(
                "Repo Base Directory:", default=section.repo_base, style=custom_style
            ).ask()
            if val:
                section.repo_base = val

        elif field == "update_strategy":
            val = questionary.select(
                "Update Strategy:",
                choices=["replace", "rename_old", "ignore"],
                default=section.update_strategy,
                style=custom_style,
            ).ask()
            if val:
                section.update_strategy = val

        elif field == "secrets_filter":
            # Toggle logic since it's a checkbox essentially
            section.secrets_filter = not section.secrets_filter

        elif field == "inherits":
            current = ", ".join(section.inherits)
            val = questionary.text(
                "Inherits templates (comma separated):",
                default=current,
                style=custom_style,
            ).ask()
            if val is not None:
                section.inherits = [t.strip() for t in val.split(",") if t.strip()]

        elif field == "pre_deploy":
            val = questionary.text(
                "Pre-deploy Hook:", default=section.pre_deploy or "", style=custom_style
            ).ask()
            section.pre_deploy = val if val else None

        elif field == "post_deploy":
            val = questionary.text(
                "Post-deploy Hook:",
                default=section.post_deploy or "",
                style=custom_style,
            ).ask()
            section.post_deploy = val if val else None


def print_global_dashboard(config: GlobalConfig):
    """Print global config dashboard."""
    table = Table(title=None, box=None, show_header=False, padding=(0, 2))
    table.add_column("Key", style="cyan bold")
    table.add_column("Value")

    table.add_row("Default Editor", config.editor or "[dim]System Default[/dim]")
    table.add_row("Remote URL", config.remote_url or "[dim]Not Set[/dim]")
    table.add_row(
        "Default Secrets Filter",
        (
            "[green]Enabled[/green]"
            if config.secrets_filter_enabled
            else "[dim]Disabled[/dim]"
        ),
    )

    console.print(
        Panel(
            table,
            title="[magenta bold]Global Configuration[/magenta bold]",
            subtitle="[dim]Settings apply to all new sections/machines[/dim]",
            border_style="cyan",
        )
    )


def run_global_wizard(config: GlobalConfig):
    """Edit global configuration."""
    while True:
        console.clear()
        print_global_dashboard(config)
        console.print()

        choices = [
            questionary.Choice("Edit Default Editor", value="editor"),
            questionary.Choice("Edit Remote URL", value="remote_url"),
            questionary.Choice("Toggle Default Secrets Filter", value="secrets_filter"),
            questionary.Separator(),
            questionary.Choice("Save & Return", value="save", shortcut_key="s"),
            questionary.Choice("Cancel", value="cancel", shortcut_key="q"),
        ]

        field = questionary.select(
            "Select action:", choices=choices, style=custom_style
        ).ask()

        if not field or field == "cancel":
            return

        if field == "save":
            config.save()
            success("Global config updated.")
            return

        if field == "editor":
            val = questionary.text(
                "Editor Command:", default=config.editor or "", style=custom_style
            ).ask()
            config.editor = val if val else None

        elif field == "remote_url":
            val = questionary.text(
                "Remote URL:",
                default=config.remote_url,
                validate=UrlValidator,
                style=custom_style,
            ).ask()
            config.remote_url = val if val else ""

        elif field == "secrets_filter":
            current = config.secrets_filter_enabled
            # Toggle
            val = not current
            if "defaults" not in config._data:
                config._data["defaults"] = {}
            config._data["defaults"]["secrets_filter"] = val


def run_templates_wizard(config: DotManConfig):
    """Add or edit templates."""
    while True:
        console.clear()
        print_banner("Templates Manager")

        templates = config.get_local_templates()
        if templates:
            table = Table(title="Available Templates", show_header=True)
            table.add_column("Name", style="green")
            table.add_column("Update Strategy")
            table.add_column("Hooks")

            for name in templates:
                tmpl = config._data["templates"][name]
                hooks = []
                if tmpl.get("pre_deploy"):
                    hooks.append("Pre")
                if tmpl.get("post_deploy"):
                    hooks.append("Post")

                table.add_row(
                    name,
                    tmpl.get("update_strategy", "default"),
                    ", ".join(hooks) if hooks else "-",
                )
            console.print(table)
            console.print()

        choices = []
        if templates:
            for name in templates:
                choices.append(questionary.Choice(f"Edit {name}", value=name))

        choices.append(questionary.Separator())
        choices.append(questionary.Choice("Add New Template", value="add_new"))
        choices.append(questionary.Choice("Back", value="back", shortcut_key="q"))

        selection = questionary.select(
            "Manage Templates:", choices=choices, use_shortcuts=True, style=custom_style
        ).ask()

        if not selection or selection == "back":
            return

        if selection == "add_new":
            name = questionary.text("Template Name:", style=custom_style).ask()
            if name:
                if name in templates:
                    warn("Template already exists!")
                else:
                    if "templates" not in config._data:
                        config._data["templates"] = {}
                    config._data["templates"][name] = {}
                    edit_template(config, name)
        else:
            edit_template(config, selection)


def edit_template(config: DotManConfig, name: str):
    """Edit a specific template."""
    template = config._data["templates"][name]

    while True:
        console.clear()

        # Mini dashboard for template
        table = Table(title=None, box=None, show_header=False, padding=(0, 2))
        table.add_column("Key", style="cyan bold")
        table.add_column("Value")

        table.add_row("Pre-deploy Hook", template.get("pre_deploy", "[dim]None[/dim]"))
        table.add_row(
            "Post-deploy Hook", template.get("post_deploy", "[dim]None[/dim]")
        )
        table.add_row("Update Strategy", template.get("update_strategy", "Default"))

        console.print(
            Panel(
                table,
                title=f"[magenta bold]Template: {name}[/magenta bold]",
                border_style="cyan",
            )
        )
        console.print()

        choices = [
            questionary.Choice("Edit Pre-deploy Hook", value="pre_deploy"),
            questionary.Choice("Edit Post-deploy Hook", value="post_deploy"),
            questionary.Choice("Edit Update Strategy", value="update_strategy"),
            questionary.Separator(),
            questionary.Choice("Save & Return", value="save", shortcut_key="s"),
            questionary.Choice("Delete Template", value="delete"),
        ]

        field = questionary.select(
            "Edit Template Field:",
            choices=choices,
            use_shortcuts=True,
            style=custom_style,
        ).ask()

        if not field or field == "save":
            config.save()
            return

        if field == "delete":
            if questionary.confirm(
                f"Delete template '{name}'?", style=custom_style
            ).ask():
                del config._data["templates"][name]
                config.save()
                return

        if field == "pre_deploy":
            val = questionary.text(
                "Pre-deploy Hook:",
                default=template.get("pre_deploy", ""),
                style=custom_style,
            ).ask()
            if val:
                template["pre_deploy"] = val
            elif "pre_deploy" in template:
                del template["pre_deploy"]

        elif field == "post_deploy":
            val = questionary.text(
                "Post-deploy Hook:",
                default=template.get("post_deploy", ""),
                style=custom_style,
            ).ask()
            if val:
                template["post_deploy"] = val
            elif "post_deploy" in template:
                del template["post_deploy"]

        elif field == "update_strategy":
            val = questionary.select(
                "Update Strategy:",
                choices=["replace", "rename_old", "ignore"],
                default=template.get("update_strategy", "replace"),
                style=custom_style,
            ).ask()
            if val:
                template["update_strategy"] = val
