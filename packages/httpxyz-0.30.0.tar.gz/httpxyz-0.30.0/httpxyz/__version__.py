__title__ = "httpxyz"
__description__ = "The friendly fork of a next generation HTTP client, for Python 3."
__version__ = "0.30.0"
