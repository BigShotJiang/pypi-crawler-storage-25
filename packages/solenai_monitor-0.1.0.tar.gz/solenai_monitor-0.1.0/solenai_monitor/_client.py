"""HTTP client and HMAC signature for Solen incident webhooks."""

from __future__ import annotations

import hashlib
import hmac
import json
import traceback
from datetime import datetime, timezone
from typing import Any, Dict, Optional

_endpoint: Optional[str] = None
_secret: Optional[str] = None


def configure(endpoint: str, secret: str) -> None:
    global _endpoint, _secret
    endpoint = (endpoint or "").strip()
    secret = (secret or "").strip()
    if not endpoint:
        raise ValueError("solenai_monitor: endpoint is required")
    if not secret:
        raise ValueError("solenai_monitor: secret is required")
    _endpoint = endpoint
    _secret = secret


def sign_payload(body: bytes, secret: str) -> str:
    """Hex-encoded HMAC-SHA256 of the raw request body."""
    return hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()


def build_payload(
    exc: BaseException,
    *,
    source: str = "python",
) -> Dict[str, Any]:
    import socket

    return {
        "source": source,
        "error": str(exc),
        "traceback": "".join(
            traceback.format_exception(type(exc), exc, exc.__traceback__)
        ),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "hostname": socket.gethostname(),
    }


def _post(body: bytes) -> None:
    if _endpoint is None or _secret is None:
        return

    signature = sign_payload(body, _secret)
    headers = {
        "Content-Type": "application/json",
        "X-Solen-Signature": signature,
        "X-Solen-Secret": _secret,
    }

    try:
        import requests  # type: ignore[import-untyped]

        requests.post(_endpoint, data=body, headers=headers, timeout=10)
        return
    except ImportError:
        pass
    except Exception:
        return

    try:
        import urllib.error
        import urllib.request

        request = urllib.request.Request(
            _endpoint,
            data=body,
            headers=headers,
            method="POST",
        )
        urllib.request.urlopen(request, timeout=10)
    except Exception:
        pass


def report_exception(exc: BaseException) -> None:
    """Serialize and POST an exception payload. Never raises."""
    try:
        payload = build_payload(exc)
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        _post(body)
    except Exception:
        pass
