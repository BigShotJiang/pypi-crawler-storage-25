"""Solen MetaShift runtime monitor for Python."""

from __future__ import annotations

from solenai_monitor._client import configure, report_exception
from solenai_monitor._hooks import install_hooks

__all__ = ["init", "report_exception"]
__version__ = "0.1.0"


def init(*, endpoint: str, secret: str) -> None:
    """
    Configure the webhook endpoint and register global exception handlers.

    Example::

        import solenai_monitor
        solenai_monitor.init(
            endpoint="https://api.solenai.ca/api/webhooks/incident/<endpointId>",
            secret="<your-secret>",
        )
    """
    configure(endpoint, secret)
    install_hooks()
