"""Process-wide exception hooks for sync and asyncio runtimes."""

from __future__ import annotations

import asyncio
import sys
from typing import Any, Callable, Optional

from solenai_monitor._client import report_exception

_original_excepthook: Optional[Callable[[type, BaseException, Any], None]] = None
_original_unraisablehook: Optional[Callable[..., None]] = None
_installed = False


def _excepthook(
    exc_type: type,
    exc_value: BaseException,
    exc_tb: Any,
) -> None:
    if exc_value is not None:
        report_exception(exc_value)
    if _original_excepthook is not None:
        _original_excepthook(exc_type, exc_value, exc_tb)
    else:
        sys.__excepthook__(exc_type, exc_value, exc_tb)


def _asyncio_exception_handler(
    loop: asyncio.AbstractEventLoop,
    context: dict,
) -> None:
    exc = context.get("exception")
    if isinstance(exc, BaseException):
        report_exception(exc)
    else:
        message = context.get("message", "asyncio error")
        report_exception(RuntimeError(str(message)))


def _unraisablehook(unraisable: sys.UnraisableHookArgs) -> None:
    if isinstance(unraisable.exc_value, BaseException):
        report_exception(unraisable.exc_value)
    if _original_unraisablehook is not None:
        _original_unraisablehook(unraisable)
    else:
        sys.__unraisablehook__(unraisable)


class _SolenEventLoopPolicy(asyncio.DefaultEventLoopPolicy):
    def new_event_loop(self) -> asyncio.AbstractEventLoop:
        loop = super().new_event_loop()
        loop.set_exception_handler(_asyncio_exception_handler)
        return loop


def install_hooks() -> None:
    global _original_excepthook, _original_unraisablehook, _installed
    if _installed:
        return
    _installed = True

    _original_excepthook = sys.excepthook
    sys.excepthook = _excepthook

    if hasattr(sys, "unraisablehook"):
        _original_unraisablehook = sys.unraisablehook
        sys.unraisablehook = _unraisablehook

    policy = asyncio.get_event_loop_policy()
    if not isinstance(policy, _SolenEventLoopPolicy):
        asyncio.set_event_loop_policy(_SolenEventLoopPolicy())

    try:
        loop = asyncio.get_running_loop()
        loop.set_exception_handler(_asyncio_exception_handler)
    except RuntimeError:
        pass
