"""Unit tests for SparkConfigAdvisor."""

from __future__ import annotations

from sparktimise.config.spark_config import (
    ConfigSparkRecommendationSource,
    SparkConfigAdvisor,
    SparkConfigRecommendation,
)

_RECOMMENDATIONS = {
    "spark.sql.shuffle.partitions": "40",
    "spark.sql.adaptive.enabled": "true",
    "spark.sql.adaptive.coalescePartitions.enabled": "true",
    "spark.sql.adaptive.skewJoin.enabled": "true",
    "spark.memory.fraction": "0.75",
    "spark.memory.storageFraction": "0.30",
    "spark.sql.execution.arrow.pyspark.enabled": "true",
    "spark.sql.broadcastTimeout": "600",
    "spark.sql.autoBroadcastJoinThreshold": "10485760",
}


class TestSparkConfigAdvisor:
    """Tests for :class:`SparkConfigAdvisor`."""

    def test_returns_list_of_recommendations(self) -> None:
        """recommend() should return a non-empty list."""
        advisor = SparkConfigAdvisor(
            recommendation_source=ConfigSparkRecommendationSource(_RECOMMENDATIONS),
        )
        recs = advisor.recommend()
        assert len(recs) > 0
        assert all(isinstance(r, SparkConfigRecommendation) for r in recs)

    def test_shuffle_partitions_heuristic(self) -> None:
        """Shuffle partitions should come from recommendations."""
        advisor = SparkConfigAdvisor(
            recommendation_source=ConfigSparkRecommendationSource(_RECOMMENDATIONS),
        )
        recs = {r.key: r.value for r in advisor.recommend()}
        assert recs["spark.sql.shuffle.partitions"] == "40"

    def test_aqe_enabled(self) -> None:
        """AQE must always be recommended as enabled."""
        advisor = SparkConfigAdvisor(
            recommendation_source=ConfigSparkRecommendationSource(_RECOMMENDATIONS),
        )
        recs = {r.key: r.value for r in advisor.recommend()}
        assert recs["spark.sql.adaptive.enabled"] == "true"

    def test_to_dict_keys_match(self) -> None:
        """to_dict keys should match recommendation keys."""
        advisor = SparkConfigAdvisor(
            recommendation_source=ConfigSparkRecommendationSource(_RECOMMENDATIONS),
        )
        d = advisor.to_dict()
        keys_from_recs = {r.key for r in advisor.recommend()}
        assert set(d.keys()) == keys_from_recs
