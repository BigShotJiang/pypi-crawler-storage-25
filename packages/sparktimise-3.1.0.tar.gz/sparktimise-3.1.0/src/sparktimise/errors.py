"""Typed package exceptions.

For a library/package, using explicit exception types is more SOLID-friendly
than relying on `assert` or forcing callers to match on generic exception
messages.

Callers can catch `SparktimiseError` (or narrower subclasses) without depending
on implementation details.

This package also provides `SparktimiseErrorHandler` as a single choke point for
wrapping/raising consistent typed exceptions.
"""

from __future__ import annotations

from typing import NoReturn


class SparktimiseError(Exception):
    """Base error for all sparktimise exceptions."""


class ConfigError(SparktimiseError):
    """Raised for configuration load/parse/validation failures."""


class ConfigValidationError(ConfigError):
    """Raised when configuration values are invalid or unsupported."""


class ConfigNotFoundError(ConfigError):
    """Raised when a config file path does not exist."""


class UnsupportedConfigFileTypeError(ConfigError):
    """Raised when a config file suffix is not supported."""


class ValidationError(SparktimiseError):
    """Raised when function arguments or inputs are invalid."""


class PipelineError(SparktimiseError):
    """Raised for pipeline construction/execution failures."""


class InputDataError(PipelineError):
    """Raised when pipeline input is not a supported DataFrame type."""


class SparkSessionNotFoundError(PipelineError):
    """Raised when Pandas→Spark coercion requires a SparkSession but none exists."""


class OptimiserExecutionError(PipelineError):
    """Raised when an optimiser step throws during execution."""

    def __init__(self, optimiser_name: str, message: str | None = None) -> None:
        super().__init__(message or f"Optimiser '{optimiser_name}' failed during optimise().")
        self.optimiser_name = optimiser_name


class SparktimiseErrorHandler:
    """Centralised exception wrapping for sparktimise.

    This helper keeps try/except blocks at call sites small and consistent by
    translating native exceptions into typed sparktimise exceptions.
    """

    @staticmethod
    def raise_error(error: SparktimiseError) -> NoReturn:
        """Raise a sparktimise exception."""
        raise error

    @classmethod
    def raise_optimiser_error(
        cls,
        exc: BaseException,
        *,
        optimiser_name: str,
    ) -> NoReturn:
        """Raise an `OptimiserExecutionError`.

        If *exc* is already a SparktimiseError, it is re-raised unchanged.
        """
        if isinstance(exc, SparktimiseError):
            raise exc
        raise OptimiserExecutionError(optimiser_name) from exc


__all__ = [
    "ConfigError",
    "ConfigNotFoundError",
    "ConfigValidationError",
    "InputDataError",
    "OptimiserExecutionError",
    "PipelineError",
    "SparkSessionNotFoundError",
    "SparktimiseError",
    "SparktimiseErrorHandler",
    "UnsupportedConfigFileTypeError",
    "ValidationError",
]
