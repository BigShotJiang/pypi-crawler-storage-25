"""Shared internal logging utilities."""

from __future__ import annotations

import logging


def get_logger(name: str) -> logging.Logger:
    """Return a consistently configured logger for *name*.

    Attaches a `logging.NullHandler` by default (library best practice).
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.addHandler(logging.NullHandler())
    return logger
