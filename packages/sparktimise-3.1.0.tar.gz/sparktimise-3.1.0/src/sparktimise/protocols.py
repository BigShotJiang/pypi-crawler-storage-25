"""Structural protocols for dependency injection."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class SparkConfProtocol(Protocol):
    """Minimal interface for Spark configuration access."""

    def get(self, key: str, default: str | None = None) -> str: ...
    def set(self, key: str, value: str) -> None: ...
    def unset(self, key: str) -> None: ...


@runtime_checkable
class SparkSessionProtocol(Protocol):
    """Minimal interface for a SparkSession-like object."""

    @property
    def conf(self) -> SparkConfProtocol: ...


class SparkContextProtocol(Protocol):
    """Minimal interface for SparkContext runtime metrics."""

    @property
    def defaultParallelism(self) -> int: ...  # noqa: N802

    def statusTracker(self) -> Any: ...  # noqa: N802
