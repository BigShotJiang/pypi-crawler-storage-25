"""Context-manager driven Spark plan assessment and session tuning."""

from __future__ import annotations

import hashlib
import sys
import time
from collections.abc import Callable, Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sparktimise.df_transforms import (
    TransformResult,
    add_broadcast_hint,
    cache_reused_dataframe,
    coalesce_after_filter,
    repartition_skewed_key,
)
from sparktimise.exporter import ReportExporter
from sparktimise.history import HistoryStore
from sparktimise.logger import get_logger
from sparktimise.plan_signals import (
    collect_explain_metrics,
    default_plan_signals,
    evaluate_plan_signals,
)
from sparktimise.profiler import PlanProfiler
from sparktimise.recommendation_engine import RecommendationEngine
from sparktimise.report import OptimisationReport
from sparktimise.thresholds import Thresholds
from sparktimise.types import AnalysisResult, OptimisationResult, PipelineRun, RunType

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class PlanAssessment:
    """Risk assessment for a single Spark DataFrame plan."""

    qualified_function_name: str
    risk_score: int
    warnings: list[str]
    recommended_conf: dict[str, str]
    plan_hash: str
    plan: str | None = None
    plan_metrics: dict[str, Any] = field(default_factory=dict)
    recommendation_insights: list[dict[str, Any]] = field(default_factory=list)
    source_file: str | None = None
    source_line: int | None = None


@dataclass
class PipelineAudit:
    """In-memory audit for one context-manager pipeline run."""

    pipeline_name: str
    started_at: float = field(default_factory=time.perf_counter)
    assessments: list[PlanAssessment] = field(default_factory=list)
    actions: list[dict[str, Any]] = field(default_factory=list)

    def add_assessment(self, assessment: PlanAssessment) -> None:
        """Record a plan assessment."""
        self.assessments.append(assessment)

    def add_action(self, action: dict[str, Any]) -> None:
        """Record a terminal action, baseline, or report."""
        self.actions.append(action)

    def summary(self) -> dict[str, Any]:
        """Return a serialisable summary of the pipeline audit."""
        return {
            "pipeline_name": self.pipeline_name,
            "duration_seconds": round(time.perf_counter() - self.started_at, 3),
            "assessments": [
                {
                    "qualified_function_name": a.qualified_function_name,
                    "risk_score": a.risk_score,
                    "warnings": a.warnings,
                    "recommended_conf": a.recommended_conf,
                    "plan_hash": a.plan_hash,
                }
                for a in self.assessments
            ],
            "actions": self.actions,
        }


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


@contextmanager
def temporary_spark_conf(
    spark: Any,
    conf: dict[str, str],
) -> Generator[None, None, None]:
    """Temporarily apply Spark SQL config and restore previous values."""
    previous: dict[str, str | None] = {}
    for key, value in conf.items():
        try:
            previous[key] = spark.conf.get(key)
        except Exception:  # noqa: BLE001
            previous[key] = None
        spark.conf.set(key, value)
    try:
        yield
    finally:
        for key, prev_value in previous.items():
            try:
                if prev_value is None:
                    spark.conf.unset(key)
                else:
                    spark.conf.set(key, prev_value)
            except Exception:  # noqa: BLE001, S110
                continue


def is_spark_dataframe(value: Any) -> bool:
    """Return whether *value* behaves like a PySpark DataFrame."""
    return bool(
        value is not None
        and value.__class__.__name__ == "DataFrame"
        and hasattr(value, "_jdf")
        and hasattr(value, "sparkSession")
    )


def get_plan_text(df: Any) -> str:
    """Return the Spark query plan without triggering an action."""
    try:
        return str(df._jdf.queryExecution().toString())
    except Exception:  # noqa: BLE001
        return ""


def hash_plan(plan: str) -> str:
    """Hash a plan so repeated captures can be de-duplicated."""
    return hashlib.sha256(plan.encode("utf-8")).hexdigest()[:16]


def assess_dataframe_plan(
    qualified_function_name: str,
    df: Any,
    *,
    include_plan: bool = False,
    source_file: str | None = None,
    source_line: int | None = None,
    thresholds: Thresholds | None = None,
) -> PlanAssessment:
    """Assess a DataFrame plan and recommend safe session config."""
    thresholds = thresholds or Thresholds()
    plan = get_plan_text(df)
    signals = default_plan_signals(thresholds)
    risk_score, warnings, conf = evaluate_plan_signals(plan, signals)

    conf.setdefault("spark.sql.adaptive.enabled", "true")
    conf.setdefault("spark.sql.adaptive.skewJoin.enabled", "true")
    conf.setdefault("spark.sql.adaptive.coalescePartitions.enabled", "true")

    if not warnings:
        warnings.append("No obvious high-risk plan features detected.")

    plan_metrics = collect_explain_metrics(plan)

    return PlanAssessment(
        qualified_function_name=qualified_function_name,
        risk_score=risk_score,
        warnings=warnings,
        recommended_conf=conf,
        plan_hash=hash_plan(plan),
        plan=plan if include_plan else None,
        plan_metrics=plan_metrics,
        source_file=source_file,
        source_line=source_line,
    )


# ---------------------------------------------------------------------------
# Tuner configuration
# ---------------------------------------------------------------------------


@dataclass
class TunerConfig:
    """Configuration for :class:`SparkPipelineAutoTuner`."""

    watched_functions: list[str] | str | Path = field(default_factory=list)
    watched_modules: list[str] | str | Path = field(default_factory=list)
    auto_capture: bool = True
    include_plan: bool = False
    min_risk_to_log: int = 0
    output_path: str | Path | None = None
    run_id: str | None = None
    run_type: str = "optimise"
    enable_sample_validation: bool = False
    sample_validation_fraction: float = 0.02
    max_sample_rows: int = 5000
    thresholds: Thresholds = field(default_factory=Thresholds)


def _load_watch_list(value: list[str] | str | Path | None) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    path = Path(value)
    if path.is_file() and path.suffix == ".txt":
        lines: list[str] = []
        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if line and not line.startswith("#"):
                lines.append(line)
        return lines
    return [str(value)]


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------


class SparkPipelineAutoTuner:
    """Auto-assess watched DataFrame-returning functions in a pipeline.

    This is a thin orchestrator that delegates to:

    - :class:`~sparktimise.profiler.PlanProfiler` for frame capture
    - :class:`~sparktimise.recommendation_engine.RecommendationEngine` for insights
    - :class:`~sparktimise.history.HistoryStore` for trend tracking
    - :class:`~sparktimise.exporter.ReportExporter` for file export
    """

    def __init__(
        self,
        spark: Any,
        pipeline_name: str,
        config: TunerConfig | None = None,
        *,
        watched_functions: list[str] | str | Path | None = None,
        watched_modules: list[str] | str | Path | None = None,
        auto_capture: bool = True,
        include_plan: bool = False,
        min_risk_to_log: int = 0,
        output_path: str | Path | None = None,
        run_id: str | None = None,
        run_type: str = "optimise",
        enable_sample_validation: bool = False,
        sample_validation_fraction: float = 0.02,
        max_sample_rows: int = 5000,
        thresholds: Thresholds | None = None,
    ) -> None:
        if config is not None:
            watched_functions = config.watched_functions or watched_functions
            watched_modules = config.watched_modules or watched_modules
            auto_capture = config.auto_capture
            include_plan = config.include_plan
            min_risk_to_log = config.min_risk_to_log
            output_path = config.output_path or output_path
            run_id = config.run_id or run_id
            run_type = config.run_type
            enable_sample_validation = config.enable_sample_validation
            sample_validation_fraction = config.sample_validation_fraction
            max_sample_rows = config.max_sample_rows
            thresholds = config.thresholds

        self.spark = spark
        self.pipeline_name = pipeline_name
        self.watched_functions = set(_load_watch_list(watched_functions))
        self.watched_modules = _load_watch_list(watched_modules)
        self.auto_capture = auto_capture
        self.include_plan = include_plan
        self.min_risk_to_log = min_risk_to_log
        self.output_path = Path(output_path) if output_path is not None else Path.cwd()
        self.run_id = run_id or pipeline_name
        self.run_type = RunType.from_str(run_type)
        self.enable_sample_validation = enable_sample_validation
        self.sample_validation_fraction = sample_validation_fraction
        self.max_sample_rows = max_sample_rows
        self.thresholds = thresholds or Thresholds()
        self.audit = PipelineAudit(pipeline_name=pipeline_name)
        self.last_report: dict[str, Any] | None = None
        self._previous_profile: Any = None
        self._seen_assessment_keys: set[tuple[str, str]] = set()
        self._seen_plan_hashes: set[str] = set()
        self._combined_conf: dict[str, str] = {}
        self._df_transformations: list[str] = []

        # Collaborators
        self._recommendations = RecommendationEngine(self.thresholds)
        self._history = HistoryStore(self.output_path)
        self._exporter = ReportExporter(self.output_path, self.run_id, self.pipeline_name)
        self._baseline_started_conf = self._capture_conf_snapshot()
        self._runtime_snapshot = self._capture_runtime_snapshot()

    # -- Context manager protocol -------------------------------------------

    def __enter__(self) -> SparkPipelineAutoTuner:
        if self.auto_capture:
            self._previous_profile = sys.getprofile()
            profiler = PlanProfiler(
                watched_functions=self.watched_functions,
                watched_modules=self.watched_modules,
                on_capture=self._on_profiler_capture,
                is_dataframe=is_spark_dataframe,
            )
            sys.setprofile(profiler)
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        if self.auto_capture:
            sys.setprofile(self._previous_profile)

    def _on_profiler_capture(
        self,
        qualified_name: str,
        df: Any,
        *,
        source_file: str | None = None,
        source_line: int | None = None,
    ) -> None:
        """Handle a DataFrame return event from the profiler."""
        try:
            self.assess(qualified_name, df, source_file=source_file, source_line=source_line)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Assessment failed for %s: %s", qualified_name, exc)
            self.audit.add_action(
                {"type": "assessment_error", "qualified_function_name": qualified_name, "error": str(exc)}
            )

    # -- Config snapshots ---------------------------------------------------

    def _capture_conf_snapshot(self) -> dict[str, str | None]:
        keys = [
            "spark.sql.shuffle.partitions",
            "spark.sql.adaptive.enabled",
            "spark.sql.adaptive.coalescePartitions.enabled",
            "spark.sql.adaptive.skewJoin.enabled",
            "spark.sql.adaptive.localShuffleReader.enabled",
            "spark.sql.autoBroadcastJoinThreshold",
            "spark.sql.broadcastTimeout",
            "spark.executor.memory",
            "spark.executor.cores",
        ]
        snapshot: dict[str, str | None] = {}
        for key in keys:
            try:
                snapshot[key] = str(self.spark.conf.get(key))
            except Exception:  # noqa: BLE001
                snapshot[key] = None
        return snapshot

    def _capture_runtime_snapshot(self) -> dict[str, Any]:
        metrics: dict[str, Any] = {}
        try:
            spark_context = self.spark.sparkContext
        except Exception:  # noqa: BLE001
            return metrics
        try:
            metrics["default_parallelism"] = int(spark_context.defaultParallelism)
        except (AttributeError, TypeError, ValueError):
            metrics["default_parallelism"] = None
        try:
            tracker = spark_context.statusTracker()
            stage_ids = list(tracker.getActiveStageIds())
            metrics["active_stage_count"] = len(stage_ids)
            metrics["active_stage_ids"] = stage_ids
        except (AttributeError, TypeError):
            metrics["active_stage_count"] = 0
            metrics["active_stage_ids"] = []
        return metrics

    def _resource_context(self) -> dict[str, Any]:
        context: dict[str, Any] = {}
        context.update(self._runtime_snapshot)
        context["executor_memory"] = self._baseline_started_conf.get("spark.executor.memory")
        context["executor_cores"] = self._baseline_started_conf.get("spark.executor.cores")
        return context

    # -- Assessment ---------------------------------------------------------

    def assess(
        self,
        qualified_function_name: str,
        df: Any,
        *,
        source_file: str | None = None,
        source_line: int | None = None,
    ) -> Any:
        """Assess *df* and update the combined session recommendations."""
        assessment = assess_dataframe_plan(
            qualified_function_name=qualified_function_name,
            df=df,
            include_plan=self.include_plan,
            source_file=source_file,
            source_line=source_line,
            thresholds=self.thresholds,
        )

        sample_validation = self._collect_sample_validation(df)
        if sample_validation:
            assessment.plan_metrics["sample_validation"] = sample_validation

        assessment_key = (qualified_function_name, assessment.plan_hash)
        if assessment_key in self._seen_assessment_keys:
            return df

        assessment.recommendation_insights = self._recommendations.build_insights(
            qualified_function_name,
            assessment,
            resource_ctx=self._resource_context(),
            baseline_conf=self._baseline_started_conf,
        )
        self._recommendations.record(assessment.recommendation_insights)

        self._seen_assessment_keys.add(assessment_key)
        self._seen_plan_hashes.add(assessment.plan_hash)
        if assessment.risk_score >= self.min_risk_to_log:
            self.audit.add_assessment(assessment)
        self._combined_conf.update(assessment.recommended_conf)
        return df

    def _collect_sample_validation(self, df: Any) -> dict[str, Any]:
        if not self.enable_sample_validation or not is_spark_dataframe(df):
            return {}

        result: dict[str, Any] = {
            "sample_fraction": self.sample_validation_fraction,
            "max_sample_rows": self.max_sample_rows,
        }
        try:
            sample_df = df.sample(False, self.sample_validation_fraction, seed=7)
            sampled = sample_df.limit(self.max_sample_rows)
        except Exception:  # noqa: BLE001
            return {}

        try:
            result["sampled_rows"] = int(sampled.count())
        except (AttributeError, TypeError, ValueError):
            result["sampled_rows"] = 0

        try:
            result["sampled_partitions"] = int(sampled.rdd.getNumPartitions())
        except (AttributeError, TypeError, ValueError):
            result["sampled_partitions"] = None

        try:
            columns = list(getattr(df, "columns", []) or [])[:2]
            best_share = 0.0
            best_column: str | None = None
            sampled_rows = int(result.get("sampled_rows", 0) or 0)
            if sampled_rows > 0:
                for column in columns:
                    top = sampled.groupBy(column).count().orderBy("count", ascending=False).limit(1).collect()
                    if not top:
                        continue
                    row = top[0]
                    try:
                        value = int(row["count"])
                    except (KeyError, TypeError, ValueError):
                        value = int(row[1])
                    share = value / sampled_rows
                    if share > best_share:
                        best_share = share
                        best_column = column
            if best_column is not None:
                result["dominant_key_column"] = best_column
                result["dominant_key_share"] = round(best_share, 4)
        except Exception:  # noqa: BLE001
            result["sample_validation_error"] = "dominant_key_sampling_failed"

        return result

    # -- Public API ---------------------------------------------------------

    def recommendation_insights(self) -> list[dict[str, Any]]:
        """Return ranked recommendation payloads."""
        return self._recommendations.ranked()

    def recommended_conf(self) -> dict[str, str]:
        """Return combined Spark SQL recommendations collected so far."""
        return dict(self._combined_conf)

    def baseline(self, action_name: str, df: Any = None) -> OptimisationReport:
        """Build a baseline report without applying session config."""
        report = self._build_report(action_name, df, mode="baseline")
        self._store_report(report, "baseline", action_name=action_name)
        return report

    def report(self, action_name: str, df: Any = None) -> OptimisationReport:
        """Build a report-only view of the current final DataFrame."""
        report = self._build_report(action_name, df, mode="report_only")
        self._store_report(report, "report_only", action_name=action_name)
        return report

    def execute(
        self,
        action_name: str,
        df: Any = None,
        action: Callable[..., Any] | None = None,
    ) -> Any:
        """Dispatch the configured run type for a terminal action or pipeline entrypoint."""
        if callable(df) and action is None:
            action = df
            df = None

        if self.run_type is RunType.BASELINE:
            return self._execute_baseline(action_name, df, action)
        if self.run_type is RunType.REPORT:
            return self._execute_report(action_name, df, action)
        if action is None:
            msg = "An action callable is required when run_type='optimise'."
            raise ValueError(msg)

        if df is not None and is_spark_dataframe(df):
            self.assess(action_name, df)
            df = self._apply_df_transforms(df)

        conf = self.recommended_conf()
        conf.update(self._recommendations.appliable_conf())
        started = time.perf_counter()

        with temporary_spark_conf(self.spark, conf):
            result = action(df) if df is not None else action()

        result_df = result if is_spark_dataframe(result) else df
        if result_df is not None and is_spark_dataframe(result_df):
            result_df = self._apply_df_transforms(result_df)
            self.assess(action_name, result_df)

        duration_seconds = round(time.perf_counter() - started, 3)
        report = self._build_report(
            action_name,
            result_df,
            mode="optimised",
            duration_seconds=duration_seconds,
            session_settings=conf,
        )
        self._store_report(report, "optimised", action_name=action_name)
        self.audit.add_action(
            {"type": "action", "action_name": action_name, "duration_seconds": duration_seconds, "applied_conf": conf}
        )
        return result

    def export_report(
        self,
        report: OptimisationReport,
        mode: str,
        *,
        label: str | None = None,
    ) -> Path | None:
        """Write a report text file using the package's existing folder layout."""
        return self._exporter.export(report, mode, label=label)

    # -- Internal -----------------------------------------------------------

    def _resolve_df(self, df: Any, action: Callable[..., Any] | None) -> Any:
        if action is not None and df is None:
            result = action()
            if is_spark_dataframe(result):
                return result
        return df

    def _apply_df_transforms(self, df: Any) -> Any:
        """Apply low-cost DataFrame transformations and record what changed."""
        if not is_spark_dataframe(df):
            return df

        from sparktimise.recommendation_engine import _parse_memory_string  # noqa: PLC0415

        plan = get_plan_text(df)
        plan_hash_val = hash_plan(plan)
        default_parallelism = int(self._runtime_snapshot.get("default_parallelism") or 8)
        exec_mem_str = str(self._baseline_started_conf.get("spark.executor.memory") or "2g")
        exec_mem_bytes = _parse_memory_string(exec_mem_str)

        # Gather sample skew info from latest assessments
        dominant_key_column: str | None = None
        dominant_key_share: float | None = None
        for assessment in reversed(self.audit.assessments):
            sv = assessment.plan_metrics.get("sample_validation", {})
            if sv.get("dominant_key_column"):
                dominant_key_column = sv["dominant_key_column"]
                dominant_key_share = sv.get("dominant_key_share")
                break

        transforms: list[TransformResult] = [
            coalesce_after_filter(
                df,
                thresholds=self.thresholds,
                default_parallelism=default_parallelism,
            ),
            cache_reused_dataframe(
                df,
                seen_hashes=self._seen_plan_hashes,
                plan_hash=plan_hash_val,
            ),
            add_broadcast_hint(
                df,
                spark=self.spark,
                plan=plan,
                thresholds=self.thresholds,
                executor_memory_bytes=exec_mem_bytes,
            ),
            repartition_skewed_key(
                df,
                dominant_key_column=dominant_key_column,
                dominant_key_share=dominant_key_share,
                thresholds=self.thresholds,
                default_parallelism=default_parallelism,
            ),
        ]

        for result in transforms:
            if result.applied:
                df = result.df
                self._df_transformations.append(result.description)

        return df

    def _execute_baseline(self, action_name: str, df: Any, action: Callable[..., Any] | None) -> OptimisationReport:
        return self.baseline(action_name, self._resolve_df(df, action))

    def _execute_report(self, action_name: str, df: Any, action: Callable[..., Any] | None) -> OptimisationReport:
        return self.report(action_name, self._resolve_df(df, action))

    def _build_report(
        self,
        action_name: str,
        df: Any,
        *,
        mode: str,
        duration_seconds: float | None = None,
        session_settings: dict[str, str] | None = None,
    ) -> OptimisationReport:
        if df is not None and is_spark_dataframe(df):
            self.assess(action_name, df)

        assessments = list(self.audit.assessments)
        analysis_results = [self._assessment_to_analysis(a) for a in assessments]
        plan = get_plan_text(df) if df is not None and is_spark_dataframe(df) else ""
        metrics: dict[str, Any] = collect_explain_metrics(plan)
        if duration_seconds is not None:
            metrics["function_duration_seconds"] = duration_seconds
        else:
            metrics["function_duration_seconds"] = round(
                time.perf_counter() - self.audit.started_at,
                3,
            )

        # One step per assessed function
        step_results: list[OptimisationResult] = [
            OptimisationResult(
                optimiser_name=a.qualified_function_name,
                df=df,
                transformations_applied=[],
                metadata={
                    "baseline": True,
                    "risk_score": a.risk_score,
                    "plan_hash": a.plan_hash,
                },
            )
            for a in assessments
        ]
        if mode == "optimised":
            step_results.append(
                OptimisationResult(
                    optimiser_name="SparkPlanAutoTuner",
                    df=df,
                    transformations_applied=[f"Applied {len(session_settings or {})} SparkSession configurations."],
                    metadata={
                        "settings_applied": session_settings or {},
                        "recommendations_applied": [
                            item["id"] for item in self.recommendation_insights() if item.get("applies_in_optimise")
                        ],
                    },
                )
            )
            if self._df_transformations:
                step_results.append(
                    OptimisationResult(
                        optimiser_name="DataFrameTransforms",
                        df=df,
                        transformations_applied=list(self._df_transformations),
                        metadata={"transform_count": len(self._df_transformations)},
                    )
                )

        recommendations = self.recommendation_insights()
        config_delta = self._build_config_delta(
            self._baseline_started_conf,
            session_settings or self._recommendations.appliable_conf(),
        )
        total_risk = sum(int(a.risk_score) for a in assessments)

        history_row = {
            "generated_at": datetime.now(tz=timezone.utc).isoformat(timespec="seconds"),
            "pipeline_name": self.pipeline_name,
            "mode": mode,
            "function_name": action_name,
            "total_risk": total_risk,
            "recommendation_count": len(recommendations),
        }
        trend = self._history.compute_trend(history_row, self.pipeline_name)
        history_row["trend_status"] = trend.get("status")
        self._history.append(history_row)

        pipeline_run = PipelineRun(
            df=df,
            step_results=step_results,
            dataset_metrics={},
            execution_metrics={
                **metrics,
                "resource_context": self._resource_context(),
                "runtime_snapshot": self._runtime_snapshot,
                "recommendations": recommendations,
                "config_delta": config_delta,
                "history_trend": trend,
            },
        )
        return OptimisationReport(
            pipeline_run=pipeline_run,
            analysis_results=analysis_results,
            mode=mode,
            function_name=action_name,
        )

    @staticmethod
    def _assessment_to_analysis(assessment: PlanAssessment) -> AnalysisResult:
        return AnalysisResult(
            analyser_name=assessment.qualified_function_name,
            signals={
                "risk_score": assessment.risk_score,
                "warnings": assessment.warnings,
                "session_settings": assessment.recommended_conf,
                "plan_hash": assessment.plan_hash,
                "qualified_function_name": assessment.qualified_function_name,
                "plan_metrics": assessment.plan_metrics,
                "recommendation_insights": assessment.recommendation_insights,
                "source_file": assessment.source_file,
                "source_line": assessment.source_line,
            },
            recommendations=assessment.warnings,
            metadata={
                "plan_metrics": assessment.plan_metrics,
                "recommendation_insights": assessment.recommendation_insights,
                "source_file": assessment.source_file,
                "source_line": assessment.source_line,
            },
        )

    @staticmethod
    def _build_config_delta(
        before: dict[str, str | None],
        proposed: dict[str, str],
    ) -> list[dict[str, str | None]]:
        delta: list[dict[str, str | None]] = []
        for key, after in sorted(proposed.items()):
            prev = before.get(key)
            if prev == after:
                continue
            delta.append({"key": key, "before": prev, "after": after})
        return delta

    def _store_report(self, report: OptimisationReport, mode: str, *, action_name: str) -> None:
        self.last_report = report.to_dict()
        self.audit.add_action({"type": mode, "action_name": action_name, "report": self.last_report})
        self._exporter.auto_export(report)


def optimise_context(
    spark: Any,
    pipeline_name: str,
    **kwargs: Any,
) -> SparkPipelineAutoTuner:
    """Create a :class:`SparkPipelineAutoTuner` with a compact public name."""
    return SparkPipelineAutoTuner(spark=spark, pipeline_name=pipeline_name, **kwargs)
