"""JSONL-backed history store for pipeline trend tracking."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from sparktimise.logger import get_logger

logger = get_logger(__name__)


class HistoryStore:
    """Append-only JSONL store for cross-run trend comparison.

    Each row records a snapshot of a pipeline run (risk, mode, timestamp).
    The store is intentionally file-based so it can work without a database
    and survives across interpreter sessions.
    """

    def __init__(self, output_path: Path) -> None:
        self._output_path = output_path

    @property
    def history_file(self) -> Path:
        """Return the path to the JSONL history file."""  # noqa: D401
        return self._output_path / "sparktimise_history.jsonl"

    def read(self) -> list[dict[str, Any]]:
        """Read all history rows, returning an empty list on any I/O failure."""
        path = self.history_file
        if not path.exists():
            return []
        rows: list[dict[str, Any]] = []
        try:
            for line in path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                rows.append(json.loads(line))
        except OSError:
            logger.debug("Failed to read history file %s", path, exc_info=True)
            return []
        except json.JSONDecodeError:
            logger.debug("Corrupted history file %s", path, exc_info=True)
            return []
        return rows

    def append(self, row: dict[str, Any]) -> None:
        """Append a single row to the history file."""
        try:
            self._output_path.mkdir(parents=True, exist_ok=True)
            with self.history_file.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(row, sort_keys=True) + "\n")
        except OSError:
            logger.debug("Failed to append to history file", exc_info=True)

    def compute_trend(
        self,
        current: dict[str, Any],
        pipeline_name: str,
    ) -> dict[str, Any]:
        """Compare *current* against the last matching history entry."""
        history = self.read()
        comparable = [
            row
            for row in history
            if row.get("pipeline_name") == pipeline_name and row.get("mode") == current.get("mode")
        ]
        previous = comparable[-1] if comparable else None
        if previous is None:
            return {"status": "no_prior_baseline"}

        prev_risk = _safe_int(previous.get("total_risk"))
        curr_risk = _safe_int(current.get("total_risk"))
        delta_risk = curr_risk - prev_risk
        if delta_risk > 0:
            status = "regression"
        elif delta_risk < 0:
            status = "improved"
        else:
            status = "unchanged"
        return {
            "status": status,
            "previous_total_risk": prev_risk,
            "current_total_risk": curr_risk,
            "delta_total_risk": delta_risk,
            "previous_generated_at": previous.get("generated_at"),
        }


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value))
    except (ValueError, TypeError):
        return default
