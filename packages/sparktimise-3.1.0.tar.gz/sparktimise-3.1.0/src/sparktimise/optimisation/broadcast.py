"""Broadcast join analyser and hint applier."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyspark.sql import DataFrame
else:
    DataFrame = Any

from sparktimise.errors import SparktimiseErrorHandler, ValidationError
from sparktimise.logger import get_logger

logger: logging.Logger = get_logger(__name__)

_DEFAULT_BROADCAST_THRESHOLD_BYTES: int = 10 * 1024 * 1024
_BYTES_PER_CELL_HEURISTIC: int = 8


@dataclass
class TableProfile:
    """Profile of a table for broadcast join analysis."""

    name: str
    estimated_bytes: int
    row_count: int
    column_count: int
    broadcast_eligible: bool


@dataclass
class BroadcastAdvice:
    """Advice and metadata for broadcast join strategy."""

    profiles: list[TableProfile] = field(default_factory=list)
    broadcast_candidates: list[str] = field(default_factory=list)
    join_strategy: str = "shuffle_sort_merge"
    recommendations: list[str] = field(default_factory=list)
    spark_hints: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


def apply_broadcast_hints(tables: dict[str, DataFrame], advice: BroadcastAdvice) -> dict[str, DataFrame]:
    """Apply Spark broadcast hints to eligible tables based on advice."""
    result = {}
    for name, df in tables.items():
        if name in advice.broadcast_candidates:
            result[name] = df.hint("broadcast")
        else:
            result[name] = df
    return result


def analyse_broadcast(
    tables: dict[str, DataFrame],
    *,
    broadcast_threshold_bytes: int = _DEFAULT_BROADCAST_THRESHOLD_BYTES,
    sample_fraction: float = 0.05,
    seed: int = 42,
    aqe_enabled: bool = True,
) -> BroadcastAdvice:
    """Analyse join candidates and recommend broadcast strategy."""
    if len(tables) < 2:
        SparktimiseErrorHandler.raise_error(
            ValidationError("analyse_broadcast requires at least two tables to analyse a join.")
        )
    profiles = [
        _profile_table(name, df, sample_fraction, seed, broadcast_threshold_bytes) for name, df in tables.items()
    ]
    candidates = [p.name for p in profiles if p.broadcast_eligible]
    non_candidates = [p.name for p in profiles if not p.broadcast_eligible]
    strategy = _derive_strategy(profiles, candidates)
    recommendations = _build_recommendations(
        profiles, candidates, non_candidates, broadcast_threshold_bytes, aqe_enabled
    )
    hints = _build_hints(candidates, non_candidates)

    return BroadcastAdvice(
        profiles=profiles,
        broadcast_candidates=candidates,
        join_strategy=strategy,
        recommendations=recommendations,
        spark_hints=hints,
        metadata={
            "broadcast_threshold_bytes": broadcast_threshold_bytes,
            "aqe_enabled": aqe_enabled,
            "tables_analysed": list(tables.keys()),
        },
    )


def _profile_table(name: str, df: DataFrame, sample_fraction: float, seed: int, threshold: int) -> TableProfile:
    """Profile a table for broadcast eligibility and size estimation."""
    row_count = df.sample(
        withReplacement=False,
        fraction=min(sample_fraction, 1.0),
        seed=seed,
    ).count()
    total_rows = max(round(row_count / max(sample_fraction, 0.001)), row_count)
    col_count = len(df.schema.fields)
    estimated_bytes = total_rows * col_count * _BYTES_PER_CELL_HEURISTIC

    return TableProfile(
        name=name,
        estimated_bytes=estimated_bytes,
        row_count=total_rows,
        column_count=col_count,
        broadcast_eligible=estimated_bytes <= threshold,
    )


def _derive_strategy(profiles: list[TableProfile], candidates: list[str]) -> str:
    if not candidates:
        return "shuffle_sort_merge"
    return "broadcast_hash"


def _build_recommendations(
    profiles: list[TableProfile],
    candidates: list[str],
    non_candidates: list[str],
    threshold: int,
    aqe_enabled: bool,
) -> list[str]:
    recs: list[str] = []
    threshold_mb = threshold / (1024 * 1024)
    for p in profiles:
        size_mb = p.estimated_bytes / (1024 * 1024)
        eligibility = "✓ broadcast eligible" if p.broadcast_eligible else "✗ too large to broadcast"
        recs.append(
            f"Table '{p.name}': ~{size_mb:.1f} MB estimated "
            f"({p.row_count:,} rows × {p.column_count} cols) "
            f"— {eligibility}."
        )
    if candidates:
        recs.append(
            f"Recommended strategy: broadcast_hash join. "
            f"Apply .hint('broadcast') to: "
            f"{', '.join(repr(c) for c in candidates)}."
        )
        recs.append(
            f"Ensure spark.sql.autoBroadcastJoinThreshold is set to at least "
            f"{threshold_mb:.0f} MB, or use explicit hints to guarantee "
            f"broadcasting."
        )
    else:
        recs.append(
            "No tables fall below the broadcast threshold "
            f"({threshold_mb:.0f} MB). Spark will use shuffle sort-merge join. "
            "Consider increasing spark.sql.autoBroadcastJoinThreshold or "
            "reducing table size via filtering before the join."
        )
    if aqe_enabled:
        recs.append(
            "AQE is enabled: Spark may automatically switch to broadcast join at "
            "runtime if table stats allow it. Explicit hints guarantee the strategy"
            " regardless."
        )
    return recs


def _build_hints(candidates: list[str], non_candidates: list[str]) -> list[str]:
    hints: list[str] = []
    for name in candidates:
        hints.append(f'{name}_df = {name}_df.hint("broadcast")')
    for name in non_candidates:
        hints.append(f"# {name}_df: no broadcast hint (exceeds threshold)")
    return hints
