"""Functional PySpark optimisers and analysers.

This package provides pure functions that inspect and modify PySpark
DataFrames. Analysers return signals and metadata, whilst optimisers
apply the necessary PySpark transformations based on those signals.
"""

from __future__ import annotations

from sparktimise.optimisation.auto_tuning import (
    analyse_auto_tuning,
    optimise_auto_tuning,
)
from sparktimise.optimisation.broadcast import analyse_broadcast, apply_broadcast_hints
from sparktimise.optimisation.cache import analyse_cache, optimise_cache
from sparktimise.optimisation.explain import collect_explain_metrics
from sparktimise.optimisation.partition import analyse_partitions, optimise_partitions
from sparktimise.optimisation.skew import (
    analyse_skew,
    apply_optimal_salt,
    calculate_optimal_salt_count,
    optimise_skew,
)
from sparktimise.optimisation.spark_session import (
    analyse_spark_session,
    optimise_spark_session,
)

__all__ = [
    # Explain metrics
    "collect_explain_metrics",
    # Auto-tuning
    "analyse_auto_tuning",
    "optimise_auto_tuning",
    # Broadcast
    "analyse_broadcast",
    "apply_broadcast_hints",
    # Cache
    "analyse_cache",
    "optimise_cache",
    # Partition
    "analyse_partitions",
    "optimise_partitions",
    # Skew
    "analyse_skew",
    "calculate_optimal_salt_count",
    "apply_optimal_salt",
    "optimise_skew",
    # Spark Session
    "analyse_spark_session",
    "optimise_spark_session",
]
