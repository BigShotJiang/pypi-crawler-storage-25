"""SparkSession analysis and configuration optimiser."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyspark.sql import SparkSession
else:
    SparkSession = Any

from sparktimise.config.spark_config import (
    ConfigSparkRecommendationSource,
    SparkConfigAdvisor,
    SparkConfigRecommendation,
)
from sparktimise.logger import get_logger
from sparktimise.types import SparkAnalysisResult, SparkOptimisationResult

logger = get_logger(__name__)

DEFAULT_SPARK_RECOMMENDATIONS: dict[str, str] = {
    "spark.sql.shuffle.partitions": "200",
    "spark.sql.adaptive.enabled": "true",
    "spark.sql.adaptive.coalescePartitions.enabled": "true",
    "spark.sql.adaptive.skewJoin.enabled": "true",
    "spark.sql.execution.arrow.pyspark.enabled": "true",
    "spark.sql.broadcastTimeout": "600",
    "spark.sql.autoBroadcastJoinThreshold": "-1",
}

SPARK_RECOMMENDATION_REASONS: dict[str, str] = {
    "spark.sql.shuffle.partitions": ("Configured shuffle partitions for balanced shuffle parallelism: {value}."),
    "spark.sql.adaptive.enabled": "Adaptive Query Execution (AQE) enabled: {value}.",
    "spark.sql.adaptive.coalescePartitions.enabled": ("Allow AQE to merge small post-shuffle partitions: {value}."),
    "spark.sql.adaptive.skewJoin.enabled": "Enable AQE skew join handling: {value}.",
    "spark.sql.execution.arrow.pyspark.enabled": ("Enable Apache Arrow for Pandas and Spark conversion: {value}."),
    "spark.sql.broadcastTimeout": "Configured broadcast timeout (seconds): {value}.",
    "spark.sql.autoBroadcastJoinThreshold": (
        "Auto broadcast join threshold derived from executor memory (bytes): {value}."
    ),
}


def _get_default_spark_recommendations(
    overrides: dict[str, str] | None = None,
) -> dict[str, str]:
    merged = {**DEFAULT_SPARK_RECOMMENDATIONS}
    if overrides:
        merged.update({k: str(v) for k, v in overrides.items()})
    return merged


def analyse_spark_session(
    spark: SparkSession,
    *,
    advisor: SparkConfigAdvisor | None = None,
    recommendation_overrides: dict[str, str] | None = None,
) -> SparkAnalysisResult:
    """Analyse the session and return recommendations."""
    if advisor is None:
        advisor = SparkConfigAdvisor(
            recommendation_source=ConfigSparkRecommendationSource(
                _get_default_spark_recommendations(recommendation_overrides),
                reasons=SPARK_RECOMMENDATION_REASONS,
            )
        )

    recommendations = advisor.recommend()
    recommendations = _tune_recommendations(spark, recommendations)

    return SparkAnalysisResult(
        analyser_name="SparkSessionAnalyser",
        recommendations=recommendations,
        metadata={"recommendations": advisor.to_dict()},
    )


def _tune_recommendations(
    spark: SparkSession,
    recommendations: list[SparkConfigRecommendation],
) -> list[SparkConfigRecommendation]:
    """Adjust recommendations based on the current Spark session.

    When AQE coalescePartitions is being enabled, shuffle partitions are set
    high (200) so AQE can dynamically coalesce them at runtime — the static
    value becomes a ceiling rather than a fixed cost.

    When AQE is not available, a conservative heuristic based on
    ``defaultParallelism`` is used instead of the raw core count.
    """
    try:
        default_parallelism = spark.sparkContext.defaultParallelism
    except (AttributeError, TypeError, ValueError) as exc:
        logger.debug("Could not read defaultParallelism, falling back to 8: %s", exc)
        default_parallelism = 8

    # Derive broadcast threshold: 10% of executor memory, 10 MB–256 MB.
    broadcast_min_bytes = 10 * 1024 * 1024
    broadcast_max_bytes = 256 * 1024 * 1024
    _unit_map = {"g": 1024**3, "m": 1024**2, "k": 1024}
    try:
        executor_memory_str: str = spark.conf.get("spark.executor.memory", "2g") or "2g"
        unit = executor_memory_str[-1].lower()
        amount = int(executor_memory_str[:-1])
        executor_memory_bytes = amount * _unit_map.get(unit, 1024**3)
    except (AttributeError, KeyError, TypeError, ValueError) as exc:
        logger.debug("Could not read executor memory, defaulting to 2 GB: %s", exc)
        executor_memory_bytes = 2 * 1024**3
    broadcast_threshold = max(
        broadcast_min_bytes,
        min(broadcast_max_bytes, int(executor_memory_bytes * 0.10)),
    )

    tuned = []
    for rec in recommendations:
        if rec.key == "spark.sql.shuffle.partitions":
            # Cap shuffle partitions at defaultParallelism but respect any
            # lower value already provided via recommendation_overrides (e.g.
            # from optimise_partitions data-size estimate).  This ensures
            # auto_tuning sets a sensible ceiling derived from cluster
            # parallelism without overriding a more precise DataFrame-driven
            # recommendation with a larger value.
            override_value = int(rec.value) if rec.value else None
            ceiling = max(8, default_parallelism)
            value = min(override_value, ceiling) if override_value else ceiling
            rec = SparkConfigRecommendation(
                key=rec.key,
                value=str(value),
                reason=rec.reason,
            )
        elif rec.key == "spark.sql.autoBroadcastJoinThreshold":
            rec = SparkConfigRecommendation(
                key=rec.key,
                value=str(broadcast_threshold),
                reason=rec.reason,
            )
        tuned.append(rec)
    return tuned


def optimise_spark_session(
    spark: SparkSession,
    *,
    recommendation_overrides: dict[str, str] | None = None,
) -> SparkOptimisationResult:
    """Apply SparkConfigAdvisor recommendations to a SparkSession."""
    analysis = analyse_spark_session(spark, recommendation_overrides=recommendation_overrides)

    settings_applied: dict[str, str] = {}
    settings_skipped: dict[str, str] = {}
    for rec in analysis.recommendations:
        try:
            spark.conf.set(rec.key, rec.value)
            settings_applied[rec.key] = rec.value
        except (AttributeError, TypeError) as exc:
            logger.debug("Skipped setting %s: %s", rec.key, exc)
            settings_skipped[rec.key] = rec.value

    return SparkOptimisationResult(
        optimiser_name="SparkSessionOptimiser",
        spark=spark,
        settings_applied=settings_applied,
        metadata={
            **analysis.metadata,
            "settings_skipped": settings_skipped,
        },
    )
