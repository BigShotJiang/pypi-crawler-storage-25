"""Auto-tuning analyser and optimiser."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyspark.sql import DataFrame
else:
    DataFrame = Any

from sparktimise.logger import get_logger
from sparktimise.optimisation.spark_session import analyse_spark_session
from sparktimise.types import AnalysisResult, OptimisationResult

logger = get_logger(__name__)


def analyse_auto_tuning(df: DataFrame) -> AnalysisResult:
    """Analyse Spark session settings using the active SparkSession."""
    session_analysis = analyse_spark_session(df.sparkSession)

    return AnalysisResult(
        analyser_name="AutoTuningAnalyser",
        signals={
            "session_recommendations": session_analysis.recommendations,
            "session_settings": {rec.key: rec.value for rec in session_analysis.recommendations},
        },
        recommendations=[
            (rec.reason.format(value=rec.value) if "{value}" in rec.reason else rec.reason)
            for rec in session_analysis.recommendations
        ],
        metadata={
            "session_metadata": session_analysis.metadata,
        },
    )


def optimise_auto_tuning(df: DataFrame) -> OptimisationResult:
    """Apply session recommendations to the active Spark session.

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        DataFrame to automatically tune for.

    Returns
    -------
    OptimisationResult
        Original DataFrame, with applied configurations traced.
    """
    analysis = analyse_auto_tuning(df)

    settings_applied: dict[str, Any] = {}
    settings_skipped: dict[str, Any] = {}

    spark = df.sparkSession
    session_settings = analysis.signals.get("session_settings", {})

    for key, val in session_settings.items():
        try:
            spark.conf.set(key, val)
            settings_applied[key] = val
        except Exception as e:  # noqa: BLE001
            logger.debug("Skipping %s: %s", key, e)
            settings_skipped[key] = val

    return OptimisationResult(
        optimiser_name="AutoTuningOptimiser",
        df=df,
        transformations_applied=[f"Applied {len(settings_applied)} SparkSession configurations."],
        metadata={
            **analysis.metadata,
            "settings_applied": settings_applied,
            "settings_skipped": settings_skipped,
        },
    )
