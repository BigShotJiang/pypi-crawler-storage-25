"""Partitioning strategy analyser and optimiser."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyspark.sql import DataFrame
else:
    DataFrame = Any

try:
    from pyspark.sql import functions as F
except ModuleNotFoundError:  # pragma: no cover - optional PySpark import
    F = None  # type: ignore[assignment]

from sparktimise.optimisation.spark_session import optimise_spark_session
from sparktimise.types import AnalysisResult, OptimisationResult

# Thresholds
_DEFAULT_TARGET_PARTITION_BYTES: int = 128 * 1024 * 1024  # 128 MB
_CARDINALITY_THRESHOLD: float = 0.01  # 1 %
_MAX_COLUMNS: int = 200
_MIN_PARTITIONS: int = 1
_MAX_SENSIBLE_PARTITIONS: int = 10_000


def analyse_partitions(
    df: DataFrame,
    *,
    target_partition_bytes: int = _DEFAULT_TARGET_PARTITION_BYTES,
    cardinality_threshold: float = _CARDINALITY_THRESHOLD,
    columns: list[str] | None = None,
    max_columns: int | None = _MAX_COLUMNS,
    distinct_rsd: float = 0.05,
    sample_fraction: float | None = None,
) -> AnalysisResult:
    """Analyse *df* partitioning and recommend improvements.

    The DataFrame is expected to be persisted before calling this function.
    All aggregations run directly on *df* — no sampling is performed unless
    *sample_fraction* is set.

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        DataFrame to inspect (should already be persisted).
    target_partition_bytes : int, optional
        Desired size per partition in bytes.  Default is 128 MiB.
    cardinality_threshold : float, optional
        Maximum ratio of distinct values to total rows for a column to
        be considered a good partition-by candidate.  Default is
        ``0.01`` (1 %).
    columns : list[str] | None, optional
        Restrict partition candidate profiling to this column list.
        When ``None`` all columns are considered.
    max_columns : int | None, optional
        Maximum number of columns to profile for partition candidates.
        When ``None`` all columns are considered. Default is ``200``.
    distinct_rsd : float, optional
        Relative standard deviation for approximate distinct counts.
        Higher values are faster but less accurate. Default is ``0.05``.
    sample_fraction : float | None, optional
        When provided (e.g. ``0.1``), the DataFrame is sampled before
        aggregation and the row count is scaled back up.  Since both
        cardinality detection and byte estimation are heuristics, a
        10 % sample typically gives equivalent recommendations at a
        fraction of the scan cost.  ``None`` scans the full DataFrame.

    Returns
    -------
    AnalysisResult
        Signals include ``current_partitions``,
        ``recommended_partitions``, and
        ``partition_by_candidates``.
    """
    current_partitions = df.rdd.getNumPartitions()
    num_cols = len(df.schema.fields)
    columns_profiled = _resolve_columns(df, columns, max_columns)
    row_count, candidates = _find_partition_candidates(
        df=df,
        columns=columns_profiled,
        cardinality_threshold=cardinality_threshold,
        distinct_rsd=distinct_rsd,
        sample_fraction=sample_fraction,
    )

    # Rough heuristic: 8 bytes per column per row.
    # Deliberately avoids sizeInBytes() from the Spark optimised plan — that
    # value is unreliable when CBO stats are absent and can be orders of
    # magnitude off after shuffle-partition config changes.
    estimated_bytes = row_count * num_cols * 8

    recommended = max(
        _MIN_PARTITIONS,
        min(
            _MAX_SENSIBLE_PARTITIONS,
            round(estimated_bytes / target_partition_bytes),
        ),
    )

    recommendations: list[str] = []
    if recommended != current_partitions:
        recommendations.append(
            f"Repartition from {current_partitions} →"
            f" {recommended} partitions"
            f" (estimated data ~{estimated_bytes / 1e6:.1f} MB,"
            f" target {target_partition_bytes / 1e6:.0f} MB/partition)."
        )
    if candidates:
        col_list = "[" + ", ".join(f"'{c}'" for c in candidates) + "]"
        recommendations.append(
            f"Consider partitioning by {col_list} to improve partition pruning and predicate push-down."
        )

    return AnalysisResult(
        analyser_name="PartitionAnalyser",
        signals={
            "current_partitions": current_partitions,
            "recommended_partitions": recommended,
            "estimated_bytes": estimated_bytes,
            "partition_by_candidates": candidates,
        },
        recommendations=recommendations,
        metadata={
            "actual_row_count": row_count,
            "columns_profiled": columns_profiled,
        },
    )


def _find_partition_candidates(
    df: DataFrame,
    columns: list[str],
    cardinality_threshold: float,
    distinct_rsd: float,
    sample_fraction: float | None = None,
) -> tuple[int, list[str]]:
    already_cached = df.is_cached
    if not already_cached:
        df.persist()

    try:
        profiled: DataFrame = df.select(*columns) if columns else df

        if sample_fraction is not None and 0.0 < sample_fraction < 1.0:
            profiled = profiled.sample(fraction=sample_fraction, seed=42)

        if not columns:
            row_count = profiled.count()
            return row_count, []

        agg_exprs = [F.count(F.lit(1)).alias("__rows")]
        for name in columns:
            agg_exprs.append(F.approx_count_distinct(F.col(name), rsd=distinct_rsd).alias(f"{name}__distinct"))

        stats = profiled.agg(*agg_exprs).collect()[0].asDict()
        sampled_rows = max(int(stats.get("__rows") or 0), 1)

        # Scale sampled row count back to estimate the full dataset size.
        # The ratio is used locally (within this sample) so cardinality
        # detection remains consistent regardless of sample size.
        row_count = (
            max(round(sampled_rows / sample_fraction), 1)
            if sample_fraction is not None and sample_fraction < 1.0
            else sampled_rows
        )

        candidates: list[str] = []
        for name in columns:
            distinct = int(stats.get(f"{name}__distinct") or 0)
            ratio = distinct / sampled_rows
            if ratio <= cardinality_threshold and distinct > 1:
                candidates.append(name)

        return row_count, candidates
    finally:
        if not already_cached:
            df.unpersist()


def _resolve_columns(df: DataFrame, columns: list[str] | None, max_columns: int | None) -> list[str]:
    schema_columns = [field.name for field in df.schema.fields]
    resolved = [name for name in columns if name in schema_columns] if columns else schema_columns

    if max_columns is not None and len(resolved) > max_columns:
        return resolved[: int(max_columns)]
    return resolved


def optimise_partitions(
    df: DataFrame,
    *,
    target_partition_bytes: int | None = None,
    cardinality_threshold: float = 0.01,
    candidate_columns: list[str] | None = None,
    max_columns: int | None = 200,
    apply_session_recommendations: bool = False,
    sample_fraction: float | None = None,
) -> OptimisationResult:
    """Update shuffle partitions according to analysis recommendations.

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        DataFrame to optimise.
    target_partition_bytes : int | None, optional
        Target size per partition in bytes. When ``None``, a heuristic is used.
    cardinality_threshold : float, optional
        Forwarded to analysis. Default is ``0.01``.
    candidate_columns : list[str] | None, optional
        Restrict partition-by candidate profiling to these columns.
    max_columns : int | None, optional
        Maximum number of columns to profile for partition candidates.
        Default is ``200``.
    apply_session_recommendations : bool, optional
        When ``True``, apply Spark session recommendations.
    sample_fraction : float | None, optional
        Fraction of the DataFrame to sample for profiling (e.g. ``0.1``).
        ``None`` scans the full DataFrame. Useful for large tables where
        exact counts are not required.

    Returns
    -------
    OptimisationResult
        DataFrame with applied configuration details.
    """
    if target_partition_bytes is None:
        analysis = analyse_partitions(
            df,
            cardinality_threshold=cardinality_threshold,
            columns=candidate_columns,
            max_columns=max_columns,
            sample_fraction=sample_fraction,
        )
    else:
        analysis = analyse_partitions(
            df,
            target_partition_bytes=target_partition_bytes,
            cardinality_threshold=cardinality_threshold,
            columns=candidate_columns,
            max_columns=max_columns,
            sample_fraction=sample_fraction,
        )

    signals = analysis.signals
    current = signals["current_partitions"]
    recommended = signals["recommended_partitions"]
    transformations: list[str] = []
    result_df = df
    settings_applied: dict[str, str] = {}

    spark = df.sparkSession
    if apply_session_recommendations:
        session_result = optimise_spark_session(
            spark,
            recommendation_overrides={"spark.sql.shuffle.partitions": str(recommended)},
        )
        settings_applied = session_result.settings_applied
        transformations.append(f"session config applied ({len(settings_applied)} settings)")
    else:
        if recommended != current:
            spark.conf.set("spark.sql.shuffle.partitions", str(recommended))
            transformations.append(
                f"spark.sql.shuffle.partitions={recommended}  [{current} → {recommended} partitions]"
            )
        else:
            transformations.append(f"Shuffle partition count {current} already optimal; no change.")

    return OptimisationResult(
        optimiser_name="PartitionOptimiser",
        df=result_df,
        transformations_applied=transformations,
        metadata={
            "previous_partitions": current,
            "new_partitions": recommended,
            "partition_by_columns": [],
            "session_settings_applied": settings_applied,
        },
    )
