"""Cache analysis and persistence optimiser."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyspark.sql import DataFrame
else:
    DataFrame = Any

try:
    from pyspark.storagelevel import StorageLevel
except ModuleNotFoundError:  # pragma: no cover - optional PySpark import

    class StorageLevel:  # type: ignore[no-redef]
        """Tiny fallback for import-time tests without PySpark."""

        MEMORY_ONLY = "MEMORY_ONLY"
        MEMORY_AND_DISK = "MEMORY_AND_DISK"
        DISK_ONLY = "DISK_ONLY"
        OFF_HEAP = "OFF_HEAP"

        def __init__(self, *args: object) -> None:
            self.args = args


from sparktimise.errors import SparktimiseErrorHandler, ValidationError
from sparktimise.logger import get_logger
from sparktimise.types import AnalysisResult, OptimisationResult

logger = get_logger(__name__)

# Sentinel used to distinguish local-checkpoint from StorageLevel-based persist.
_LOCAL_CHECKPOINT = "LOCAL_CHECKPOINT"

_STORAGE_LEVEL_MAP: dict[str, StorageLevel] = {
    "MEMORY_ONLY": StorageLevel.MEMORY_ONLY,
    "MEMORY_AND_DISK": StorageLevel.MEMORY_AND_DISK,
    "MEMORY_ONLY_SER": getattr(
        StorageLevel,
        "MEMORY_ONLY_SER",
        StorageLevel(False, True, False, False, 1),
    ),
    "MEMORY_AND_DISK_SER": getattr(
        StorageLevel,
        "MEMORY_AND_DISK_SER",
        StorageLevel(True, True, False, False, 1),
    ),
    "DISK_ONLY": StorageLevel.DISK_ONLY,
    "OFF_HEAP": StorageLevel.OFF_HEAP,
}

_ALL_CACHE_LEVELS: frozenset[str] = frozenset(_STORAGE_LEVEL_MAP) | {_LOCAL_CHECKPOINT}


def analyse_cache(df: DataFrame) -> AnalysisResult:
    """Evaluate DataFrame size and suggest a storage level.

    The DataFrame is expected to be persisted before calling this function.
    Size is estimated from the actual row count.

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        DataFrame to analyse (should already be persisted).

    Returns
    -------
    AnalysisResult
        Contains the recommended storage level in signals.
    """
    storage_level_name = _recommend_cache_storage_level(df)

    return AnalysisResult(
        analyser_name="CacheAnalyser",
        signals={"recommended_storage_level": storage_level_name},
        recommendations=[f"Use {storage_level_name} to persist DataFrame efficiently."],
        metadata={"recommended_storage_level": storage_level_name},
    )


def _estimate_total_bytes(df: DataFrame) -> int:
    total_rows: int = int(df.count())
    num_cols = len(df.schema.fields)
    return total_rows * num_cols * 8


def _recommend_cache_storage_level(df: DataFrame) -> str:
    total_bytes = _estimate_total_bytes(df)
    if total_bytes > 10 * 1024 * 1024 * 1024:  # > 10 GiB
        return _LOCAL_CHECKPOINT
    if total_bytes > 1 * 1024 * 1024 * 1024:  # > 1 GiB
        return "MEMORY_AND_DISK"
    return "MEMORY_ONLY"


def optimise_cache(
    df: DataFrame,
    *,
    storage_level_val: str | None = None,
    unpersist_existing: bool = True,
    repartition_before_checkpoint: bool = True,
    sample_fraction: float | None = None,
) -> OptimisationResult:
    """Persist *df* at the configured storage level.

    Choosing the right storage level can dramatically reduce
    recomputation cost when a DataFrame is accessed multiple times in
    a Spark job.

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        DataFrame to persist.
    storage_level_val : str | None, optional
        One of ``"MEMORY_ONLY"``, ``"MEMORY_AND_DISK"``,
        ``"MEMORY_ONLY_SER"``, ``"MEMORY_AND_DISK_SER"``,
        ``"DISK_ONLY"``, ``"OFF_HEAP"``, or ``"LOCAL_CHECKPOINT"``.

        ``"LOCAL_CHECKPOINT"`` calls ``df.localCheckpoint(eager=True)``:
        it materialises the DataFrame eagerly on executor-local disk,
        **truncates the lineage DAG**, and requires no checkpoint
        directory configuration.  This is the recommended replacement
        for ``df.checkpoint()`` when the goal is to break a deep
        lineage graph without the cost of writing to HDFS.

        When ``None``, a heuristic recommends ``LOCAL_CHECKPOINT`` for
        DataFrames estimated above 10 GiB, ``MEMORY_AND_DISK`` above
        1 GiB, and ``MEMORY_ONLY`` otherwise.
    unpersist_existing : bool, optional
        When ``True``, any existing persistence on the DataFrame is
        cleared before re-persisting.  Default is ``True``.
        Has no effect when ``storage_level_val="LOCAL_CHECKPOINT"``
        because local checkpoints do not use the RDD storage API.
    repartition_before_checkpoint : bool, optional
        When ``True`` (default) and ``storage_level_val`` resolves to
        ``"LOCAL_CHECKPOINT"``, the DataFrame is repartitioned to the
        partition analyser's recommended count and columns *before*
        the checkpoint write.  This caps per-task partition size so
        each executor task holds less data in memory during
        materialisation, directly reducing memory spill.  Set to
        ``False`` to skip repartitioning and checkpoint as-is.
    sample_fraction : float | None, optional
        When ``repartition_before_checkpoint=True``, this fraction is
        forwarded to the partition analyser so the profiling scan runs
        on a sample rather than the full DataFrame.  ``None`` scans the
        full DataFrame.

    Returns
    -------
    OptimisationResult
        The persisted DataFrame and a record of what was applied.
    """
    if storage_level_val is not None and storage_level_val not in _ALL_CACHE_LEVELS:
        valid = ", ".join(sorted(_ALL_CACHE_LEVELS))
        SparktimiseErrorHandler.raise_error(
            ValidationError(f"Unknown storage_level '{storage_level_val}'.  Valid options: {valid}")
        )

    if storage_level_val is None:
        analysis = analyse_cache(df)
        storage_level_val = analysis.signals["recommended_storage_level"]

    transformations: list[str] = []

    if storage_level_val == _LOCAL_CHECKPOINT:
        # Repartition to the recommended partition count (and columns) before
        # checkpointing.  Each task then holds a smaller slice of data in memory
        # during materialisation, directly reducing execution-memory spill.
        if repartition_before_checkpoint:
            from sparktimise.optimisation.partition import analyse_partitions

            partition_analysis = analyse_partitions(df, sample_fraction=sample_fraction)
            recommended = int(partition_analysis.signals["recommended_partitions"])
            candidates: list[str] = partition_analysis.signals["partition_by_candidates"]
            if candidates:
                df = df.repartition(recommended, *candidates)
                transformations.append(
                    f"repartition({recommended}, {candidates!r}) applied before checkpoint to limit per-task memory."
                )
            else:
                df = df.repartition(recommended)
                transformations.append(
                    f"repartition({recommended}) applied before checkpoint to limit per-task memory."
                )

        # localCheckpoint(eager=True) materialises immediately on executor-local
        # disk and severs the upstream lineage graph — the fastest way to break a
        # deep plan without a checkpoint directory or HDFS write.
        result_df = df.localCheckpoint(eager=True)
        transformations.append("localCheckpoint(eager=True) applied — lineage truncated.")
    else:
        if unpersist_existing:
            df.unpersist()
            transformations.append("unpersist() called on existing plan.")
        selected_storage_level = _STORAGE_LEVEL_MAP[storage_level_val]
        result_df = df.persist(selected_storage_level)
        transformations.append(f"persist({storage_level_val}) applied.")

    return OptimisationResult(
        optimiser_name="CacheOptimiser",
        df=result_df,
        transformations_applied=transformations,
        metadata={"storage_level": storage_level_val},
    )
