"""Query plan metrics collector.

Parses the output of ``df.explain()`` to extract lightweight plan-level
signals without triggering any Spark action.

Extracted metrics
-----------------
physical_plan : str
    The raw physical plan string (printed by ``df.explain()``).
join_strategies : list[str]
    All join node types detected in the plan.
exchange_count : int
    Number of shuffle Exchange nodes (excludes BroadcastExchange).
broadcast_exchange_count : int
    Number of BroadcastExchange nodes.
has_aqe : bool
    Whether AdaptiveSparkPlan (AQE) is present.
has_partition_pruning : bool
    Whether dynamic partition pruning is detected.
"""

from __future__ import annotations

import contextlib
import io
import re
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyspark.sql import DataFrame
else:
    DataFrame = Any

# Join strategy labels as they appear in the physical plan string
_JOIN_TYPES: list[str] = [
    "BroadcastHashJoin",
    "SortMergeJoin",
    "ShuffleHashJoin",
    "CartesianProduct",
    "BroadcastNestedLoopJoin",
]

# Shuffle Exchange — negative lookahead excludes BroadcastExchange
_RE_EXCHANGE = re.compile(r"(?<!Broadcast)Exchange")
_RE_BROADCAST_EXCHANGE = re.compile(r"BroadcastExchange")


def collect_explain_metrics(df: DataFrame) -> dict[str, Any]:
    """Return a dictionary of query-plan metrics for *df*.

    This function captures ``df.explain()`` by redirecting stdout — no Spark
    actions are triggered.  An empty dict is returned silently on any failure.

    Parameters
    ----------
    df : DataFrame
        The Spark DataFrame to inspect.

    Returns
    -------
    dict[str, Any]
        Keys: ``physical_plan``, ``join_strategies``, ``exchange_count``,
        ``broadcast_exchange_count``, ``has_aqe``, ``has_partition_pruning``.
    """
    plan_str = ""
    try:
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            df.explain(extended=False)
        plan_str = buf.getvalue()
    except Exception:  # noqa: BLE001
        return {}

    if not plan_str.strip():
        return {}

    exchange_count = len(_RE_EXCHANGE.findall(plan_str))
    broadcast_exchange_count = len(_RE_BROADCAST_EXCHANGE.findall(plan_str))
    join_strategies = [j for j in _JOIN_TYPES if j in plan_str]
    has_aqe = "AdaptiveSparkPlan" in plan_str or "AdaptiveQueryExecution" in plan_str
    has_partition_pruning = "DynamicPruning" in plan_str or "dynamicPartitionPruning" in plan_str

    return {
        "physical_plan": plan_str.strip(),
        "join_strategies": join_strategies,
        "exchange_count": exchange_count,
        "broadcast_exchange_count": broadcast_exchange_count,
        "has_aqe": has_aqe,
        "has_partition_pruning": has_partition_pruning,
    }
