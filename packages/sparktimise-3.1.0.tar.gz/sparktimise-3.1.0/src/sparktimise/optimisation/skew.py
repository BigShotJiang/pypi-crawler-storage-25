"""Data skew detection and mitigation using salting."""

from __future__ import annotations

import random
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyspark.sql import DataFrame, Row
else:
    DataFrame = Any
    Row = Any

try:
    from pyspark.sql import functions as F
    from pyspark.sql.types import IntegerType
except ModuleNotFoundError:  # pragma: no cover - optional PySpark import
    F = None  # type: ignore[assignment]

    class IntegerType:  # type: ignore[no-redef]  # noqa: N801
        """Fallback placeholder used when PySpark is unavailable."""


from sparktimise.errors import SparktimiseErrorHandler, ValidationError
from sparktimise.types import AnalysisResult, OptimisationResult

_SKEW_THRESHOLD: float = 0.5  # fraction of rows in one key
_TOP_N: int = 10
_SALT_COLUMN: str = "__sparktimise_salt__"
_SALT_COUNT_COL: str = "__sparktimise_key_count__"
_SALT_NULL_SENTINEL: str = "__sparktimise_null__"


def analyse_skew(
    df: DataFrame,
    *,
    columns: list[str] | None = None,
) -> AnalysisResult:
    """Detect skewed key columns in *df*.

    A column is flagged as skewed when the most frequent key accounts
    for more than half of total rows.  The DataFrame is expected to
    be persisted before calling this function.

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        DataFrame to analyse (should already be persisted).
    columns : list[str] | None, optional
        Columns to analyse.  When ``None`` no skew analysis is performed.
        Default is ``None``.

    Returns
    -------
    AnalysisResult
        Signals include ``skewed_columns`` (mapping column name to
        the fraction held by the dominant key) and
        ``top_keys`` (the most frequent values per skewed column).
    """
    already_cached = df.is_cached
    if not already_cached:
        df.persist()

    try:
        total = df.count()
        if total == 0:
            return AnalysisResult(
                analyser_name="SkewAnalyser",
                signals={"skewed_columns": {}, "top_keys": {}},
                recommendations=["DataFrame is empty; skew analysis skipped."],
            )

        skewed: dict[str, float] = {}
        top_keys: dict[str, list[dict[str, object]]] = {}
        recommendations: list[str] = []

        if columns:
            for col in columns:
                top_full, dominant_frac = _get_top_keys(df, col, total)
                if not top_full:
                    continue
                top_keys[col] = [{"value": str(row[col]), "count": row["cnt"]} for row in top_full]
                if dominant_frac >= _SKEW_THRESHOLD:
                    skewed[col] = round(dominant_frac, 4)
                    recommendations.append(
                        f"Column '{col}' is skewed: the dominant key"
                        f" represents {dominant_frac:.1%} of rows."
                        " Consider Spark skew join hints (e.g."
                        f" SQL /*+ SKEW('{col}') */)."
                    )

        return AnalysisResult(
            analyser_name="SkewAnalyser",
            signals={
                "skewed_columns": skewed,
                "skew_hint_columns": list(skewed.keys()),
                "top_keys": top_keys,
                "total_rows": total,
            },
            recommendations=recommendations,
            metadata={
                "columns_analysed": columns,
            },
        )
    finally:
        if not already_cached:
            df.unpersist()


def _get_top_keys(df: DataFrame, col: str, total: int) -> tuple[list[Row], float]:
    top: list[Row] = (
        df.groupBy(F.col(col)).agg(F.count("*").alias("cnt")).orderBy(F.col("cnt").desc()).limit(_TOP_N).collect()
    )
    if not top or total == 0:
        return [], 0.0
    dominant_frac = top[0]["cnt"] / total
    return top, dominant_frac


def optimise_skew(
    df: DataFrame,
    *,
    columns: list[str] | None = None,
) -> OptimisationResult:
    """Add salt columns to mitigate skew for detected keys.

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        DataFrame to optimise.
    columns : list[str] | None, optional
        Restrict analysis to these columns.  ``None`` inspects all
        non-numeric columns.  Default is ``None``.

    Returns
    -------
    OptimisationResult
        DataFrame with additional ``<col>__salt`` columns and a
        combined salt key column ``__sparktimise_salt__``.
    """
    analysis = analyse_skew(df, columns=columns)
    skewed_cols: dict[str, float] = analysis.signals.get("skewed_columns", {})
    transformations: list[str] = []
    result_df = df

    if not skewed_cols:
        return OptimisationResult(
            optimiser_name="SkewOptimiser",
            df=df,
            transformations_applied=["No skewed columns detected; no salting applied."],
        )

    existing_columns = set(df.columns)
    collisions = [col for col in skewed_cols if f"{col}__salt" in existing_columns]
    if _SALT_COLUMN in existing_columns or collisions:
        collision_names: list[str] = []
        if _SALT_COLUMN in existing_columns:
            collision_names.append(_SALT_COLUMN)
        collision_names.extend([f"{col}__salt" for col in collisions])
        collision_list = ", ".join(collision_names)
        SparktimiseErrorHandler.raise_error(
            ValidationError(f"SkewOptimiser would overwrite existing salt columns: {collision_list}.")
        )

    bucket_map = {col_name: _determine_buckets(dominant_frac) for col_name, dominant_frac in skewed_cols.items()}

    for col_name in skewed_cols:
        num_buckets = bucket_map[col_name]
        salt_col = f"{col_name}__salt"
        result_df = result_df.withColumn(
            salt_col,
            (F.rand(seed=random.randint(0, 9999)) * num_buckets).cast(IntegerType()),  # noqa: S311
        )
        transformations.append(f"Salt column '{salt_col}' added ({num_buckets} buckets) for skewed key '{col_name}'.")

    # Composite salt key for convenience
    salt_parts = [
        F.concat_ws(
            "_",
            F.col(c),
            F.col(f"{c}__salt").cast("string"),
        )
        for c in skewed_cols
    ]
    result_df = result_df.withColumn(
        _SALT_COLUMN,
        salt_parts[0] if len(salt_parts) == 1 else F.concat_ws("|", *salt_parts),
    )
    transformations.append(f"Composite salt key '{_SALT_COLUMN}' added.")

    return OptimisationResult(
        optimiser_name="SkewOptimiser",
        df=result_df,
        transformations_applied=transformations,
        metadata={
            "salted_columns": list(skewed_cols.keys()),
            "num_salt_buckets": bucket_map,
        },
    )


def calculate_optimal_salt_count(
    df: DataFrame,
    *,
    key_columns: list[str],
    target_rows_per_bucket: int = 1_000_000,
    min_salt_buckets: int = 2,
    max_salt_buckets: int = 128,
) -> int:
    """Estimate a salt bucket count using the largest observed key group.

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        DataFrame containing the skewed keys.
    key_columns : list[str]
        Columns that define the key distribution to rebalance.
    target_rows_per_bucket : int, optional
        Target maximum rows per salted key bucket. Default is ``1_000_000``.
    min_salt_buckets : int, optional
        Minimum buckets used when salting is required. Default is ``2``.
    max_salt_buckets : int, optional
        Upper bound for buckets to avoid excess shuffle overhead. Default is ``128``.

    Returns
    -------
    int
        Salt bucket count. Returns ``1`` when salting is not needed.
    """
    _validate_salt_arguments(
        key_columns=key_columns,
        target_rows_per_bucket=target_rows_per_bucket,
        min_salt_buckets=min_salt_buckets,
        max_salt_buckets=max_salt_buckets,
    )
    _validate_key_columns_exist(df=df, key_columns=key_columns)

    max_rows_per_key_row = (
        df.groupBy(*[F.col(c) for c in key_columns])
        .agg(F.count("*").alias(_SALT_COUNT_COL))
        .agg(F.max(F.col(_SALT_COUNT_COL)).alias("max_rows_per_key"))
        .collect()
    )
    max_rows_per_key = int(max_rows_per_key_row[0]["max_rows_per_key"] or 0)

    return _derive_salt_bucket_count(
        max_rows_per_key=max_rows_per_key,
        target_rows_per_bucket=target_rows_per_bucket,
        min_salt_buckets=min_salt_buckets,
        max_salt_buckets=max_salt_buckets,
    )


def apply_optimal_salt(
    df: DataFrame,
    *,
    key_columns: list[str],
    salt_column: str = _SALT_COLUMN,
    target_rows_per_bucket: int = 1_000_000,
    min_salt_buckets: int = 2,
    max_salt_buckets: int = 128,
) -> OptimisationResult:
    """Calculate and apply deterministic salting to *df*.

    This helper first estimates an optimal bucket count using
    :func:`calculate_optimal_salt_count`, then adds ``salt_column``.

    Parameters
    ----------
    df : pyspark.sql.DataFrame
        DataFrame to salt.
    key_columns : list[str]
        Columns that define the skewed key.
    salt_column : str, optional
        Name of the salt column to add. Default is ``__sparktimise_salt__``.
    target_rows_per_bucket : int, optional
        Target maximum rows per salted key bucket. Default is ``1_000_000``.
    min_salt_buckets : int, optional
        Minimum buckets used when salting is required. Default is ``2``.
    max_salt_buckets : int, optional
        Upper bound for buckets to avoid excess shuffle overhead. Default is ``128``.

    Returns
    -------
    OptimisationResult
        DataFrame with the added salt column and metadata describing
        chosen bucket count.
    """
    if salt_column in set(df.columns):
        SparktimiseErrorHandler.raise_error(
            ValidationError(f"SkewOptimiser would overwrite existing salt column: {salt_column}.")
        )

    num_salt_buckets = calculate_optimal_salt_count(
        df,
        key_columns=key_columns,
        target_rows_per_bucket=target_rows_per_bucket,
        min_salt_buckets=min_salt_buckets,
        max_salt_buckets=max_salt_buckets,
    )

    key_hash_parts = [F.coalesce(F.col(c).cast("string"), F.lit(_SALT_NULL_SENTINEL)) for c in key_columns]
    salt_expr = F.lit(0)
    if num_salt_buckets > 1:
        # Keep modulo non-negative without relying on F.pmod, which is not
        # available in some older PySpark builds.
        hash_value = F.xxhash64(*key_hash_parts)
        buckets_lit = F.lit(num_salt_buckets)
        salt_expr = ((hash_value % buckets_lit) + buckets_lit) % buckets_lit

    result_df = df.withColumn(salt_column, salt_expr.cast(IntegerType()))
    transformations = [f"Salt column '{salt_column}' added ({num_salt_buckets} buckets) for key columns {key_columns}."]

    return OptimisationResult(
        optimiser_name="SkewOptimiser",
        df=result_df,
        transformations_applied=transformations,
        metadata={
            "salt_column": salt_column,
            "salted_columns": key_columns,
            "num_salt_buckets": num_salt_buckets,
        },
    )


def _validate_salt_arguments(
    *,
    key_columns: list[str],
    target_rows_per_bucket: int,
    min_salt_buckets: int,
    max_salt_buckets: int,
) -> None:
    if not key_columns:
        SparktimiseErrorHandler.raise_error(ValidationError("key_columns must contain at least one column."))
    if target_rows_per_bucket <= 0:
        SparktimiseErrorHandler.raise_error(ValidationError("target_rows_per_bucket must be greater than zero."))
    if min_salt_buckets < 2:
        SparktimiseErrorHandler.raise_error(ValidationError("min_salt_buckets must be at least 2."))
    if max_salt_buckets < min_salt_buckets:
        SparktimiseErrorHandler.raise_error(
            ValidationError("max_salt_buckets must be greater than or equal to min_salt_buckets.")
        )


def _validate_key_columns_exist(df: DataFrame, *, key_columns: list[str]) -> None:
    missing = [col_name for col_name in key_columns if col_name not in set(df.columns)]
    if missing:
        SparktimiseErrorHandler.raise_error(
            ValidationError(f"Key columns not found in DataFrame: {', '.join(missing)}")
        )


def _derive_salt_bucket_count(
    *,
    max_rows_per_key: int,
    target_rows_per_bucket: int,
    min_salt_buckets: int,
    max_salt_buckets: int,
) -> int:
    """Convert the largest key-group size into a bounded bucket count."""
    if max_rows_per_key <= 0:
        return 1

    estimated_buckets = (max_rows_per_key + target_rows_per_bucket - 1) // target_rows_per_bucket
    if estimated_buckets <= 1:
        return 1
    return int(max(min_salt_buckets, min(max_salt_buckets, estimated_buckets)))


def _determine_buckets(dominant_frac: float) -> int:
    """Derive a bucket count from the dominant key share.

    Uses a capped linear heuristic so higher skew yields more buckets.
    """
    scaled = round(dominant_frac * 20)
    return max(2, min(50, int(scaled)))
