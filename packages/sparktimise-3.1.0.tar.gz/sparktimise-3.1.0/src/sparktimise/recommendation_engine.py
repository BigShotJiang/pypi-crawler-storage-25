"""Recommendation engine — builds and ranks evidence-based suggestions."""

from __future__ import annotations

from typing import Any

from sparktimise.logger import get_logger
from sparktimise.thresholds import Thresholds

logger = get_logger(__name__)


class RecommendationEngine:
    """Build, record, and rank evidence-based tuning recommendations.

    This class is injected into :class:`SparkPipelineAutoTuner` and owns
    all recommendation logic that was previously embedded in the tuner.
    """

    def __init__(self, thresholds: Thresholds) -> None:
        self._thresholds = thresholds
        self._catalog: dict[str, dict[str, Any]] = {}

    # -- public API ----------------------------------------------------------

    def build_insights(
        self,
        qualified_function_name: str,
        assessment: Any,
        *,
        resource_ctx: dict[str, Any],
        baseline_conf: dict[str, str | None],
    ) -> list[dict[str, Any]]:
        """Create ranked recommendation payloads with evidence and confidence."""
        insights: list[dict[str, Any]] = []
        default_parallelism = _safe_int(resource_ctx.get("default_parallelism"), default=8)

        def add(
            *,
            rid: str,
            category: str,
            title: str,
            recommendation: str,
            impact: str,
            confidence: str,
            evidence: list[str],
            applies_in_optimise: bool,
            proposed_settings: dict[str, str] | None = None,
        ) -> None:
            insights.append(
                {
                    "id": rid,
                    "function": qualified_function_name,
                    "category": category,
                    "title": title,
                    "recommendation": recommendation,
                    "impact": impact,
                    "confidence": confidence,
                    "evidence": evidence,
                    "applies_in_optimise": applies_in_optimise,
                    "proposed_settings": proposed_settings or {},
                }
            )

        exchange_count = int(assessment.plan_metrics.get("exchange_count", 0) or 0)
        bc_exchange_count = int(assessment.plan_metrics.get("broadcast_exchange_count", 0) or 0)
        joins: list[str] = list(assessment.plan_metrics.get("join_strategies", []) or [])
        has_pp = bool(assessment.plan_metrics.get("has_partition_pruning", False))
        sample_validation: dict[str, Any] = assessment.plan_metrics.get("sample_validation", {})
        executor_memory_str = str(baseline_conf.get("spark.executor.memory") or "2g")

        if exchange_count >= self._thresholds.high_shuffle_min_exchanges:
            target = max(8, default_parallelism)
            current_shuffle = _safe_int(
                baseline_conf.get("spark.sql.shuffle.partitions") or "0",
                default=0,
            )
            what_if_estimate = ""
            if current_shuffle > 0 and current_shuffle != target:
                what_if_estimate = f" what-if: shuffle partition ceiling could move from {current_shuffle} to {target}."
            add(
                rid=f"shuffle-{assessment.plan_hash}",
                category="shuffle",
                title="High shuffle exchange pressure",
                recommendation=(
                    "Enable adaptive coalesce and set shuffle partitions ceiling to match cluster parallelism "
                    f"(suggested ceiling={target}).{what_if_estimate}"
                ),
                impact="high",
                confidence="high",
                evidence=[f"exchange_count={exchange_count}", f"default_parallelism={default_parallelism}"],
                applies_in_optimise=True,
                proposed_settings={
                    "spark.sql.adaptive.coalescePartitions.enabled": "true",
                    "spark.sql.shuffle.partitions": str(target),
                },
            )

        if "SortMergeJoin" in joins:
            add(
                rid=f"join-local-reader-{assessment.plan_hash}",
                category="join",
                title="Sort-merge join heavy plan",
                recommendation="Enable local shuffle reader and AQE skew handling for large join stages.",
                impact="medium",
                confidence="high",
                evidence=["join_strategy=SortMergeJoin"],
                applies_in_optimise=True,
                proposed_settings={
                    "spark.sql.adaptive.localShuffleReader.enabled": "true",
                    "spark.sql.adaptive.skewJoin.enabled": "true",
                },
            )

            # Auto-broadcast threshold: raise to 10% of executor memory when
            # SortMergeJoin is present so smaller dimensions get broadcast.
            exec_bytes = _parse_memory_string(executor_memory_str)
            broadcast_cap = int(exec_bytes * self._thresholds.executor_memory_broadcast_fraction)
            broadcast_cap = max(
                self._thresholds.broadcast_min_bytes,
                min(broadcast_cap, self._thresholds.broadcast_max_bytes),
            )
            current_bc = _safe_int(
                baseline_conf.get("spark.sql.autoBroadcastJoinThreshold") or "0",
                default=0,
            )
            if current_bc < broadcast_cap:
                add(
                    rid=f"broadcast-threshold-{assessment.plan_hash}",
                    category="join",
                    title="Broadcast join threshold increase",
                    recommendation=(
                        f"Raise autoBroadcastJoinThreshold to {broadcast_cap // (1024 * 1024)}MB "
                        "(10% of executor memory) to convert eligible SortMergeJoins to BroadcastHashJoins."
                    ),
                    impact="high",
                    confidence="high",
                    evidence=[
                        "join_strategy=SortMergeJoin",
                        f"executor_memory={executor_memory_str}",
                        f"current_threshold={current_bc}",
                    ],
                    applies_in_optimise=True,
                    proposed_settings={
                        "spark.sql.autoBroadcastJoinThreshold": str(broadcast_cap),
                    },
                )

        # Broadcast timeout: increase when broadcast exchanges are present
        if bc_exchange_count > 0:
            current_timeout = _safe_int(
                baseline_conf.get("spark.sql.broadcastTimeout") or "0",
                default=0,
            )
            recommended_timeout = self._thresholds.broadcast_timeout_recommended
            if current_timeout < recommended_timeout:
                add(
                    rid=f"broadcast-timeout-{assessment.plan_hash}",
                    category="join",
                    title="Broadcast timeout increase",
                    recommendation=(
                        f"Increase broadcastTimeout to {recommended_timeout}s to prevent "
                        "false timeout failures on large broadcast exchanges."
                    ),
                    impact="medium",
                    confidence="high",
                    evidence=[
                        f"broadcast_exchange_count={bc_exchange_count}",
                        f"current_timeout={current_timeout}s",
                    ],
                    applies_in_optimise=True,
                    proposed_settings={
                        "spark.sql.broadcastTimeout": str(recommended_timeout),
                    },
                )

        # Advisory partition size: guide post-shuffle coalescing when shuffles are heavy
        if exchange_count >= self._thresholds.high_shuffle_min_exchanges:
            add(
                rid=f"advisory-partition-size-{assessment.plan_hash}",
                category="shuffle",
                title="Advisory partition size for post-shuffle coalescing",
                recommendation=(
                    f"Set advisoryPartitionSizeInBytes to {self._thresholds.advisory_partition_size_bytes} "
                    "to guide AQE coalescing toward right-sized partitions."
                ),
                impact="medium",
                confidence="high",
                evidence=[f"exchange_count={exchange_count}"],
                applies_in_optimise=True,
                proposed_settings={
                    "spark.sql.adaptive.advisoryPartitionSizeInBytes": (self._thresholds.advisory_partition_size_bytes),
                },
            )

            # Coalesce min partitions: prevent over-coalescing
            min_partitions = max(2, default_parallelism // self._thresholds.coalesce_min_partition_divisor)
            add(
                rid=f"coalesce-min-partitions-{assessment.plan_hash}",
                category="shuffle",
                title="Coalesce minimum partition guard",
                recommendation=(
                    f"Set coalescePartitions.minPartitionNum to {min_partitions} "
                    "(parallelism / 4) to prevent over-coalescing into too few partitions."
                ),
                impact="medium",
                confidence="medium",
                evidence=[f"default_parallelism={default_parallelism}", f"min_partitions={min_partitions}"],
                applies_in_optimise=True,
                proposed_settings={
                    "spark.sql.adaptive.coalescePartitions.minPartitionNum": str(min_partitions),
                },
            )

        dominant_key_share = sample_validation.get("dominant_key_share")
        dominant_key_column = sample_validation.get("dominant_key_column")
        if isinstance(dominant_key_share, float | int) and dominant_key_share >= self._thresholds.sample_skew_threshold:
            add(
                rid=f"sample-skew-{assessment.plan_hash}",
                category="skew",
                title="Sampled key distribution indicates potential skew",
                recommendation=(
                    f"A sampled dominant key share exceeded {self._thresholds.sample_skew_threshold:.0%}; "
                    "tuning AQE skew join parameters and consider salting or repartitioning on "
                    "a higher-cardinality key before large joins."
                ),
                impact="high",
                confidence="medium",
                evidence=[
                    f"dominant_key_column={dominant_key_column}",
                    f"dominant_key_share={float(dominant_key_share):.2f}",
                ],
                applies_in_optimise=True,
                proposed_settings={
                    "spark.sql.adaptive.skewJoin.enabled": "true",
                    "spark.sql.adaptive.skewJoin.skewedPartitionFactor": str(self._thresholds.skew_partition_factor),
                    "spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes": (
                        self._thresholds.skew_partition_threshold_bytes
                    ),
                },
            )

        if not has_pp:
            add(
                rid=f"partition-pruning-{assessment.plan_hash}",
                category="data-layout",
                title="Partition pruning not observed",
                recommendation=(
                    "Enable dynamic partition pruning and review filters and partition keys; "
                    "consider aligning table partition columns with frequent predicates."
                ),
                impact="medium",
                confidence="medium",
                evidence=["has_partition_pruning=false"],
                applies_in_optimise=True,
                proposed_settings={
                    "spark.sql.optimizer.dynamicPartitionPruning.enabled": "true",
                },
            )

        if "BroadcastNestedLoopJoin" in assessment.plan_metrics.get("join_strategies", []):
            add(
                rid=f"bnlj-{assessment.plan_hash}",
                category="join",
                title="Broadcast nested loop join detected",
                recommendation="Rewrite join predicates or pre-filter dimensions to avoid nested-loop joins.",
                impact="high",
                confidence="high",
                evidence=["join_strategy=BroadcastNestedLoopJoin"],
                applies_in_optimise=False,
            )

        return insights

    def record(self, insights: list[dict[str, Any]]) -> None:
        """Upsert insights into the catalog, keeping the strongest per ID."""
        for item in insights:
            rid = str(item.get("id", ""))
            if not rid:
                continue
            prev = self._catalog.get(rid)
            if prev is None:
                self._catalog[rid] = item
                continue

            order = {"low": 0, "medium": 1, "high": 2}
            prev_score = order.get(str(prev.get("impact", "low")), 0) + order.get(
                str(prev.get("confidence", "low")),
                0,
            )
            new_score = order.get(str(item.get("impact", "low")), 0) + order.get(
                str(item.get("confidence", "low")),
                0,
            )
            if new_score >= prev_score:
                self._catalog[rid] = item

    def ranked(self) -> list[dict[str, Any]]:
        """Return recommendation payloads sorted by impact then confidence."""
        order = {"low": 0, "medium": 1, "high": 2}
        ranked = sorted(
            self._catalog.values(),
            key=lambda item: (
                order.get(str(item.get("impact", "low")), 0),
                order.get(str(item.get("confidence", "low")), 0),
            ),
            reverse=True,
        )
        return [dict(item) for item in ranked]

    def appliable_conf(self) -> dict[str, str]:
        """Merge settings from recommendations safe to auto-apply."""
        merged: dict[str, str] = {}
        for item in self.ranked():
            if not bool(item.get("applies_in_optimise", False)):
                continue
            proposed = item.get("proposed_settings", {})
            if not isinstance(proposed, dict):
                continue
            for key, value in proposed.items():
                merged[str(key)] = str(value)
        return merged


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value))
    except (ValueError, TypeError):
        return default


def _parse_memory_string(mem_str: str) -> int:
    """Parse a Spark memory string (e.g. '2g', '512m') to bytes."""
    mem_str = mem_str.strip().lower()
    if not mem_str:
        return 2 * 1024**3
    unit_map = {"k": 1024, "m": 1024**2, "g": 1024**3, "t": 1024**4}
    unit = mem_str[-1]
    if unit in unit_map:
        amount = _safe_int(mem_str[:-1], default=2)
        return amount * unit_map[unit]
    return _safe_int(mem_str, default=2 * 1024**3)
