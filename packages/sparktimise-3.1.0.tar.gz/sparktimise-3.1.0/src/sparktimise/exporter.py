"""Report file exporter — decouples I/O from report generation."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from sparktimise.logger import get_logger
from sparktimise.report import OptimisationReport

logger = get_logger(__name__)


class ReportExporter:
    """Write :class:`OptimisationReport` instances to disk.

    Separating export from the tuner makes it easy to swap in cloud storage
    or disable file output entirely in unit tests.
    """

    def __init__(self, output_path: Path, run_id: str, pipeline_name: str) -> None:
        self._output_path = output_path
        self._run_id = run_id
        self._pipeline_name = pipeline_name
        self._export_counters: dict[str, int] = {}

    def auto_export(self, report: OptimisationReport) -> Path | None:
        """Write report with a timestamped filename to the output directory."""
        try:
            self._output_path.mkdir(parents=True, exist_ok=True)
        except OSError:
            logger.debug("Cannot create output directory %s", self._output_path, exc_info=True)
            return None

        ts = datetime.now(tz=timezone.utc).strftime("%d-%m-%Y_%H-%M-%S")
        filename = f"{ts}_sparktimise.txt"
        path = self._output_path / filename
        try:
            path.write_text(report.to_text(), encoding="utf-8")
        except OSError:
            logger.debug("Failed to write report to %s", path, exc_info=True)
            return None
        return path

    def export(
        self,
        report: OptimisationReport,
        mode: str,
        *,
        label: str | None = None,
    ) -> Path | None:
        """Write report using the ``sparktimise_results/<run_id>_<mode>/`` layout."""
        run_dir = self._output_path / "sparktimise_results" / f"{self._run_id}_{mode}"
        try:
            run_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            logger.debug("Cannot create run directory %s", run_dir, exc_info=True)
            return None

        self._export_counters[mode] = self._export_counters.get(mode, 0) + 1
        suffix = f"_{label}" if label else ""
        filename = f"{self._pipeline_name}{suffix}{self._export_counters[mode]}.txt"
        path = run_dir / filename
        try:
            path.write_text(report.to_text(), encoding="utf-8")
        except OSError:
            logger.debug("Failed to write report to %s", path, exc_info=True)
            return None
        return path
