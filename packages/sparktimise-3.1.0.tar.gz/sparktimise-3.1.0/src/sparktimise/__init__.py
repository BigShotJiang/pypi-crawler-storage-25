"""sparktimise.

sparktimise
===========
A Python wrapper that analyses DataFrames and applies the best
data-optimisation techniques so PySpark sessions run at full potential.

Quick start -- context manager
------------------------------
The simplest way to use sparktimise is the ``optimise`` context manager,
which observes watched DataFrame-returning functions and applies safe
Spark SQL tuning around the final action:

    import sparktimise

    with sparktimise.optimise(spark, "orders", run_type="optimise") as tuner:
        tuner.execute("write_orders", run_pipeline)

Modules
-------
adapters      : External system wiring (Spark session, IO paths).
factories     : optimise context-manager factory and pipeline run helpers.
optimisation/ : Analyse and optimise DataFrames (partitions, skew, cache, session).
report        : Produce human-readable optimisation summaries.
config        : Typed configuration and Spark config helpers.
"""

from importlib.metadata import PackageNotFoundError, version
from typing import TYPE_CHECKING

try:
    __version__ = version("sparktimise")
except PackageNotFoundError:
    __version__ = "0.0.0"

# PySpark is a runtime dependency -- it is not available in every
# environment (e.g. CI linting, documentation builds, plain Python
# scripts that only inspect package metadata).  All PySpark-dependent
# symbols are therefore imported lazily so that ``import sparktimise``
# never fails regardless of whether PySpark is installed.


def __getattr__(name: str) -> object:  # noqa: N807
    """Lazily expose PySpark-dependent public symbols.

    This module-level ``__getattr__`` is called by Python whenever an
    attribute lookup on this module fails normally.  We use it to defer
    PySpark imports until the symbol is actually accessed at runtime
    (i.e. when a SparkSession already exists), rather than eagerly at
    import time.

    Parameters
    ----------
    name : str
        Attribute name being looked up.

    Returns
    -------
    object
        The requested symbol.

    Raises
    ------
    AttributeError
        If ``name`` is not a known public symbol.
    """
    if name == "optimise":
        from sparktimise.factories import optimise  # noqa: PLC0415

        return optimise
    if name == "pipeline_run":
        from sparktimise.factories import pipeline_run  # noqa: PLC0415

        return pipeline_run
    if name == "OptimisationReport":
        from sparktimise.report import OptimisationReport  # noqa: PLC0415

        return OptimisationReport
    if name == "SparkPipelineAutoTuner":
        from sparktimise.context import SparkPipelineAutoTuner  # noqa: PLC0415

        return SparkPipelineAutoTuner
    if name == "TunerConfig":
        from sparktimise.context import TunerConfig  # noqa: PLC0415

        return TunerConfig
    if name == "optimise_context":
        from sparktimise.context import optimise_context  # noqa: PLC0415

        return optimise_context
    if name == "Thresholds":
        from sparktimise.thresholds import Thresholds  # noqa: PLC0415

        return Thresholds
    if name == "RunType":
        from sparktimise.types import RunType  # noqa: PLC0415

        return RunType
    raise AttributeError(f"module 'sparktimise' has no attribute {name!r}")


if TYPE_CHECKING:
    from sparktimise.context import SparkPipelineAutoTuner, TunerConfig, optimise_context
    from sparktimise.factories import optimise, pipeline_run
    from sparktimise.report import OptimisationReport
    from sparktimise.thresholds import Thresholds
    from sparktimise.types import RunType

__all__: list[str] = [
    "optimise",
    "OptimisationReport",
    "pipeline_run",
    "RunType",
    "SparkPipelineAutoTuner",
    "Thresholds",
    "TunerConfig",
    "optimise_context",
]
