"""External system adapters (Spark session + IO path helpers)."""

from __future__ import annotations

import logging
from typing import Protocol

from sparktimise.errors import SparktimiseErrorHandler, ValidationError
from sparktimise.logger import get_logger

logger: logging.Logger = get_logger(__name__)


class IOConnectorProtocol(Protocol):
    """Protocol for IO connectors."""

    name: str

    def setup(self) -> None:
        """Prepare the connector (e.g., set up credentials)."""
        ...

    def path(self, key: str = "") -> str:
        """Return a fully-qualified storage path for *key*."""
        ...


class ManagedIOConnector(IOConnectorProtocol):
    """Managed-storage connector backed by explicit parameters."""

    name = "ManagedIOConnector"

    def __init__(self, *, bucket: str, scheme: str, root: str | None = None) -> None:
        self._bucket = bucket
        self._scheme = scheme
        self._root = root

    def setup(self) -> None:
        """Prepare the connector (no-op for managed paths)."""
        return None

    def path(self, key: str = "") -> str:
        """Return a fully-qualified managed storage path."""
        if not self._bucket:
            SparktimiseErrorHandler.raise_error(ValidationError("ManagedIOConnector.path() requires bucket to be set."))
        if not self._scheme:
            SparktimiseErrorHandler.raise_error(ValidationError("ManagedIOConnector.path() requires scheme to be set."))

        parts: list[str] = []
        if self._root:
            parts.append(self._root.strip("/"))
        if key:
            parts.append(key.lstrip("/"))

        suffix = "/".join([p for p in parts if p])
        if not suffix:
            return f"{self._scheme}://{self._bucket}/"
        return f"{self._scheme}://{self._bucket}/{suffix}"


class IOConnector:
    """Delegate IO concerns to a connector implementation.

    Parameters
    ----------
    connector : IOConnectorProtocol
        Fully-featured IO connector implementation.
    """

    def __init__(self, connector: IOConnectorProtocol) -> None:
        self._connector = connector
        self.name = connector.name

    def setup(self) -> None:
        """Prepare the connector (no-op for path-only connectors)."""
        self._connector.setup()

    def path(self, key: str = "") -> str:
        """Return a fully-qualified managed storage path."""
        return self._connector.path(key)


__all__ = ["IOConnector", "ManagedIOConnector"]
