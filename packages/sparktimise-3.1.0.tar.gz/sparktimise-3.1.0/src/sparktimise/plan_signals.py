"""Plan signal definitions for data-driven plan assessment."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sparktimise.thresholds import Thresholds


@dataclass(frozen=True)
class PlanSignal:
    """A single detectable pattern in a Spark query plan."""

    name: str
    pattern: str
    risk_score: int
    warning_template: str
    recommended_conf: dict[str, str] = field(default_factory=dict)
    min_count: int | None = None
    count_pattern: str | None = None


def default_plan_signals(thresholds: Thresholds) -> list[PlanSignal]:
    """Build the default plan signal list from *thresholds*."""
    return [
        PlanSignal(
            name="cartesian_product",
            pattern="CartesianProduct",
            risk_score=thresholds.cartesian_risk,
            warning_template="Critical: Cartesian product detected.",
        ),
        PlanSignal(
            name="broadcast_nested_loop_join",
            pattern="BroadcastNestedLoopJoin",
            risk_score=thresholds.broadcast_nested_loop_risk,
            warning_template="Critical: BroadcastNestedLoopJoin detected.",
        ),
        PlanSignal(
            name="high_shuffle",
            pattern="Exchange",
            risk_score=thresholds.high_shuffle_risk,
            warning_template="High shuffle risk: {count} Exchange operators detected.",
            recommended_conf={"spark.sql.adaptive.coalescePartitions.enabled": "true"},
            min_count=thresholds.high_shuffle_min_exchanges,
            count_pattern="Exchange",
        ),
        PlanSignal(
            name="sort_merge_join",
            pattern="SortMergeJoin",
            risk_score=thresholds.sort_merge_join_risk,
            warning_template="SortMergeJoin detected.",
            recommended_conf={"spark.sql.adaptive.localShuffleReader.enabled": "true"},
        ),
        PlanSignal(
            name="window",
            pattern="Window",
            risk_score=thresholds.window_risk,
            warning_template="Window operation detected.",
        ),
        PlanSignal(
            name="multi_sort",
            pattern="Sort",
            risk_score=thresholds.multi_sort_risk,
            warning_template="Multiple sorts detected: {count} Sort operators.",
            min_count=thresholds.multi_sort_min_sorts,
            count_pattern="Sort",
        ),
        PlanSignal(
            name="no_pushdown",
            pattern="PushedFilters: []",
            risk_score=thresholds.no_pushdown_risk,
            warning_template="No predicate pushdown detected.",
        ),
        PlanSignal(
            name="no_pruning",
            pattern="PartitionFilters: []",
            risk_score=thresholds.no_pruning_risk,
            warning_template="No partition pruning detected.",
        ),
    ]


def evaluate_plan_signals(
    plan: str,
    signals: list[PlanSignal],
) -> tuple[int, list[str], dict[str, str]]:
    """Evaluate *plan* against *signals* and return risk, warnings, and conf."""
    risk_score = 0
    warnings: list[str] = []
    conf: dict[str, str] = {}

    for signal in signals:
        count = plan.count(signal.pattern) if signal.count_pattern else (1 if signal.pattern in plan else 0)

        if signal.min_count is not None:
            if count < signal.min_count:
                continue
        elif count == 0:
            continue

        risk_score += signal.risk_score
        warning = signal.warning_template.format(count=count)
        warnings.append(warning)
        conf.update(signal.recommended_conf)

    return risk_score, warnings, conf


def collect_explain_metrics(plan: str) -> dict[str, Any]:
    """Extract query-plan metrics from a plan string."""
    if not plan.strip():
        return {}

    join_types = [
        "BroadcastHashJoin",
        "SortMergeJoin",
        "ShuffleHashJoin",
        "CartesianProduct",
        "BroadcastNestedLoopJoin",
    ]
    return {
        "physical_plan": plan,
        "join_strategies": [jt for jt in join_types if jt in plan],
        "exchange_count": plan.count("Exchange") - plan.count("BroadcastExchange"),
        "broadcast_exchange_count": plan.count("BroadcastExchange"),
        "has_aqe": "AdaptiveSparkPlan" in plan or "AdaptiveQueryExecution" in plan,
        "has_partition_pruning": "DynamicPruning" in plan or "dynamicPartitionPruning" in plan,
    }
