"""Centralised tuning thresholds for plan assessment and optimisation."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Thresholds:
    """Immutable collection of tuning thresholds used across sparktimise.

    Pass a custom instance via :class:`TunerConfig` to override defaults
    without modifying source code.
    """

    # -- Plan risk scoring (context / assess_dataframe_plan) -----------------
    cartesian_risk: int = 100
    broadcast_nested_loop_risk: int = 90
    high_shuffle_risk: int = 30
    high_shuffle_min_exchanges: int = 3
    sort_merge_join_risk: int = 20
    window_risk: int = 15
    multi_sort_risk: int = 15
    multi_sort_min_sorts: int = 2
    no_pushdown_risk: int = 20
    no_pruning_risk: int = 20

    # -- Recommendation engine -----------------------------------------------
    sample_skew_threshold: float = 0.30
    skew_partition_factor: int = 5
    skew_partition_threshold_bytes: str = "256m"
    broadcast_timeout_recommended: int = 300
    advisory_partition_size_bytes: str = "128m"
    coalesce_min_partition_divisor: int = 4

    # -- Broadcast analyser --------------------------------------------------
    broadcast_threshold_bytes: int = 10 * 1024 * 1024
    bytes_per_cell_heuristic: int = 8

    # -- Cache analyser ------------------------------------------------------
    cache_large_threshold_bytes: int = 10 * 1024**3
    cache_medium_threshold_bytes: int = 1 * 1024**3

    # -- Partition analyser --------------------------------------------------
    target_partition_bytes: int = 128 * 1024 * 1024
    partition_cardinality_threshold: float = 0.01
    partition_max_columns: int = 200
    partition_min: int = 1
    partition_max: int = 10_000

    # -- Skew analyser -------------------------------------------------------
    skew_dominant_fraction: float = 0.50
    skew_top_n: int = 10
    skew_bucket_multiplier: float = 20.0
    skew_min_buckets: int = 2
    skew_max_buckets: int = 50

    # -- Spark session tuning ------------------------------------------------
    default_shuffle_partitions: int = 200
    broadcast_timeout_seconds: int = 600
    broadcast_min_bytes: int = 10 * 1024 * 1024
    broadcast_max_bytes: int = 256 * 1024 * 1024
    executor_memory_broadcast_fraction: float = 0.10
    fallback_parallelism: int = 8
    fallback_executor_memory: str = "2g"
