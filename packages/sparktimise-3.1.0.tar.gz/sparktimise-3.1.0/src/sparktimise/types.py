"""Core types and data classes for sparktimise."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyspark.sql import DataFrame, SparkSession
else:
    DataFrame = Any
    SparkSession = Any


class RunType(enum.Enum):
    """Supported pipeline run modes."""

    OPTIMISE = "optimise"
    BASELINE = "baseline"
    REPORT = "report"

    @property
    def internal_mode(self) -> str:
        """Return the internal mode string used in reports and history."""
        return _INTERNAL_MODES[self]

    @classmethod
    def from_str(cls, value: str) -> RunType:
        """Resolve a public name to a ``RunType`` member.

        Raises ``ValueError`` for unknown names.
        """
        try:
            return cls(value)
        except ValueError:
            choices = ", ".join(sorted(m.value for m in cls))
            msg = f"run_type={value!r} is invalid. Choose one of: {choices}."
            raise ValueError(msg) from None


_INTERNAL_MODES: dict[RunType, str] = {
    RunType.OPTIMISE: "optimised",
    RunType.BASELINE: "baseline",
    RunType.REPORT: "report_only",
}


@dataclass
class AnalysisResult:
    """Container returned by analysers."""

    analyser_name: str
    signals: dict[str, Any] = field(default_factory=dict)
    recommendations: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class OptimisationResult:
    """Container returned by optimisers."""

    optimiser_name: str
    df: DataFrame
    transformations_applied: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SparkAnalysisResult:
    """Container returned by Spark session analysers."""

    analyser_name: str
    recommendations: list[Any] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class SparkOptimisationResult:
    """Container returned by Spark session optimisers."""

    optimiser_name: str
    spark: SparkSession
    settings_applied: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineRun:
    """Result of executing a full optimisation pipeline run."""

    df: DataFrame | None = None
    step_results: list[OptimisationResult] = field(default_factory=list)
    dataset_metrics: dict[str, Any] = field(default_factory=dict)
    execution_metrics: dict[str, Any] = field(default_factory=dict)

    @property
    def all_transformations(self) -> list[str]:
        """Flattened list of transformations applied by all steps."""
        return [t for step in self.step_results for t in step.transformations_applied]
