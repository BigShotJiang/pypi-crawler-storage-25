"""Config parsing utilities.

Format-agnostic conversion of a raw mapping (YAML/JSON/etc.) into a typed
:class:`~sparktimise.config.schema.SparktimiseConfig`.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Protocol, TypeVar

from sparktimise.config.schema import SparktimiseConfig

T = TypeVar("T", covariant=True)


class ConfigParserProtocol(Protocol[T]):
    """Structural interface for configuration parsing functionality."""

    def parse(self, raw: Mapping[str, Any], *, strict: bool = False) -> T:
        """Parse raw config mapping into a typed object."""
        ...


def parse_config(raw: Mapping[str, Any], *, strict: bool = False) -> SparktimiseConfig:
    """Parse a raw mapping into a fully-typed config object."""
    return SparktimiseConfig(raw=dict(raw))


class SparktimiseConfigParser(ConfigParserProtocol[SparktimiseConfig]):
    """Default parser for SparktimiseConfig."""

    def parse(
        self,
        raw: Mapping[str, Any],
        *,
        strict: bool = False,
    ) -> SparktimiseConfig:
        """Parse raw config into a SparktimiseConfig."""
        return parse_config(raw, strict=strict)
