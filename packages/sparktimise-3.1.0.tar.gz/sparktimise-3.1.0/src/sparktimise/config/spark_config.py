"""Recommended Spark configuration helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from pyspark.sql import SparkSession
else:
    SparkSession = Any

from sparktimise.errors import ConfigValidationError, SparktimiseErrorHandler


@dataclass
class SparkConfigRecommendation:
    """A single Spark configuration key-value recommendation.

    Parameters
    ----------
    key : str
        Spark configuration key (e.g.
        ``"spark.sql.shuffle.partitions"``).
    value : str
        Recommended value.
    reason : str
        Human-readable explanation for the recommendation.
    """

    key: str
    value: str
    reason: str


class SparkRecommendationSourceProtocol(Protocol):
    """Protocol for generating SparkConfigRecommendation objects."""

    def get(self) -> list[SparkConfigRecommendation]:
        """Return ordered Spark config recommendations."""
        ...


class ConfigSparkRecommendationSource:
    """Build SparkConfigRecommendation entries from config values.

    Parameters
    ----------
    values : dict[str, str]
        Mapping of Spark config keys to recommended values.
    """

    def __init__(
        self,
        values: dict[str, str],
        *,
        reasons: dict[str, str] | None = None,
    ) -> None:
        if not values:
            SparktimiseErrorHandler.raise_error(
                ConfigValidationError("Spark recommendations require a non-empty mapping.")
            )
        self._reasons = reasons or {}
        missing = set(self._reasons.keys()) - set(values.keys()) if self._reasons else set()
        if missing:
            SparktimiseErrorHandler.raise_error(
                ConfigValidationError(f"Spark recommendations missing keys: {sorted(missing)}.")
            )
        self._values = {k: str(v) for k, v in values.items()}

    def get(self) -> list[SparkConfigRecommendation]:
        """Return ordered Spark config recommendations."""
        if self._reasons:
            return [
                SparkConfigRecommendation(
                    key=key,
                    value=self._values[key],
                    reason=self._reasons[key],
                )
                for key in self._reasons
            ]
        return [
            SparkConfigRecommendation(
                key=key,
                value=value,
                reason=f"Configured {key}: {value}.",
            )
            for key, value in self._values.items()
        ]


class SparkConfigAdvisor:
    """Generate recommended ``SparkConf`` settings based on context.

    Parameters
    ----------
    recommendation_source : SparkRecommendationSourceProtocol
        Provider for Spark config recommendations.
    """

    def __init__(
        self,
        recommendation_source: SparkRecommendationSourceProtocol | None = None,
    ) -> None:
        if recommendation_source is None:
            SparktimiseErrorHandler.raise_error(
                ConfigValidationError("SparkConfigAdvisor requires a recommendation source.")
            )
        self._recommendation_source = recommendation_source

    def recommend(self) -> list[SparkConfigRecommendation]:
        """Return a list of recommended Spark configuration settings.

        Returns
        -------
        list[SparkConfigRecommendation]
            Ordered list of configuration recommendations.
        """
        return list(self._recommendation_source.get())

    def apply_to_session(self, spark: SparkSession) -> None:
        """Apply all recommendations to an active SparkSession.

        Parameters
        ----------
        spark : pyspark.sql.SparkSession
            Session to configure.

        Notes
        -----
        Some settings (e.g. ``spark.memory.fraction``) take effect only
        on session creation and cannot be changed at runtime.  Those
        will be silently ignored by Spark.
        """
        for rec in self.recommend():
            spark.conf.set(rec.key, rec.value)

    def to_dict(self) -> dict[str, Any]:
        """Return recommendations as a plain dictionary.

        Returns
        -------
        dict[str, Any]
            Keys are Spark config keys; values contain ``value`` and
            ``reason``.
        """
        return {rec.key: {"value": rec.value, "reason": rec.reason} for rec in self.recommend()}
