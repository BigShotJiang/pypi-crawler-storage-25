"""Typed dataclass schema for sparktimise configuration files.

Every section of the config is represented as a frozen or mutable
dataclass.  Loader modules parse raw dicts into these types so the rest
of the codebase never handles unvalidated strings.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class WatchConfig:
    """Function and module watch list configuration."""

    functions: list[str] = field(default_factory=list)
    modules: list[str] = field(default_factory=list)


@dataclass
class OutputConfig:
    """Report output configuration."""

    path: str | None = None
    run_id: str | None = None


@dataclass
class ThresholdOverrides:
    """Optional overrides for plan assessment thresholds."""

    cartesian_risk: int | None = None
    broadcast_nested_loop_risk: int | None = None
    high_shuffle_risk: int | None = None
    high_shuffle_min_exchanges: int | None = None
    sort_merge_join_risk: int | None = None
    window_risk: int | None = None
    broadcast_threshold_bytes: int | None = None
    target_partition_bytes: int | None = None
    skew_dominant_fraction: float | None = None


@dataclass
class SparkOverrides:
    """Spark session recommendation overrides."""

    recommendations: dict[str, str] = field(default_factory=dict)


@dataclass
class SparktimiseConfig:
    """Root configuration object parsed from a config file.

    Parameters
    ----------
    raw : dict[str, Any]
        Raw configuration mapping (preserved for backward compat).
    watch : WatchConfig
        Watch list settings.
    output : OutputConfig
        Output path settings.
    thresholds : ThresholdOverrides
        Plan assessment threshold overrides.
    spark : SparkOverrides
        Spark session overrides.
    """

    raw: dict[str, Any] = field(default_factory=dict)
    watch: WatchConfig = field(default_factory=WatchConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    thresholds: ThresholdOverrides = field(default_factory=ThresholdOverrides)
    spark: SparkOverrides = field(default_factory=SparkOverrides)

    @classmethod
    def from_raw(cls, raw: dict[str, Any]) -> SparktimiseConfig:
        """Parse a raw dict into a typed config, falling back to defaults."""
        watch_raw = raw.get("watch", {})
        output_raw = raw.get("output", {})
        thresholds_raw = raw.get("thresholds", {})
        spark_raw = raw.get("spark", {})

        return cls(
            raw=raw,
            watch=WatchConfig(
                functions=list(watch_raw.get("functions", [])),
                modules=list(watch_raw.get("modules", [])),
            ),
            output=OutputConfig(
                path=output_raw.get("path"),
                run_id=output_raw.get("run_id"),
            ),
            thresholds=ThresholdOverrides(
                **{k: v for k, v in thresholds_raw.items() if hasattr(ThresholdOverrides, k)},
            ),
            spark=SparkOverrides(
                recommendations=dict(spark_raw.get("recommendations", {})),
            ),
        )
