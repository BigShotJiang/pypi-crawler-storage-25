"""File-backed configuration loader."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from sparktimise.config.parser import ConfigParserProtocol, SparktimiseConfigParser
from sparktimise.config.readers import DEFAULT_READERS, ReaderFn
from sparktimise.config.schema import SparktimiseConfig
from sparktimise.errors import (
    ConfigNotFoundError,
    ConfigValidationError,
    SparktimiseErrorHandler,
    UnsupportedConfigFileTypeError,
)
from sparktimise.logger import get_logger

logger = get_logger(__name__)


class ConfigLoader:
    """Load and validate sparktimise config files."""

    def __init__(
        self,
        config_path: str | Path | None = None,
        *,
        strict: bool = False,
        readers: Mapping[str, ReaderFn] | None = None,
        parser: ConfigParserProtocol[SparktimiseConfig] | None = None,
    ) -> None:
        self._path = Path(config_path) if config_path else None
        self._strict = strict
        self._readers: dict[str, ReaderFn] = {**DEFAULT_READERS, **dict(readers or {})}
        self._parser = parser or SparktimiseConfigParser()

    def load(self) -> SparktimiseConfig:
        """Read the config file and return a typed config object."""
        if self._path is None:
            SparktimiseErrorHandler.raise_error(
                ConfigValidationError("No sparktimise config path provided. Pass config_path=...")
            )

        if not self._path.exists():
            SparktimiseErrorHandler.raise_error(
                ConfigNotFoundError(f"sparktimise config not found: {self._path}. Pass config_path.")
            )

        logger.info("Loading sparktimise config from: %s", self._path)
        raw = self._read_file(self._path)
        return self._parser.parse(raw, strict=self._strict)

    @classmethod
    def from_dict(
        cls,
        raw: dict[str, Any],
        *,
        strict: bool = False,
        parser: ConfigParserProtocol[SparktimiseConfig] | None = None,
    ) -> SparktimiseConfig:
        """Build a typed config directly from a raw mapping."""
        return (parser or SparktimiseConfigParser()).parse(raw, strict=strict)

    def _read_file(self, path: Path) -> dict[str, Any]:
        suffix = path.suffix.lower()
        reader = self._readers.get(suffix)
        if reader is None:
            SparktimiseErrorHandler.raise_error(
                UnsupportedConfigFileTypeError(
                    f"Unsupported config file type '{suffix}'. Supported: {sorted(self._readers.keys())}."
                )
            )
        return reader(path)
