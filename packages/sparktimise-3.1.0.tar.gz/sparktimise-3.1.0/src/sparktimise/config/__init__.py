"""Config sub-package: configuration helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from sparktimise.config.parser import SparktimiseConfigParser
from sparktimise.config.schema import SparktimiseConfig
from sparktimise.config.spark_config import (
    SparkConfigAdvisor,
    SparkConfigRecommendation,
)

if TYPE_CHECKING:
    from sparktimise.config.loader import ConfigLoader

__all__ = [
    "ConfigLoader",
    "SparktimiseConfigParser",
    "SparkConfigAdvisor",
    "SparkConfigRecommendation",
    "SparktimiseConfig",
]


def __getattr__(name: str) -> object:  # noqa: N807
    if name == "ConfigLoader":
        from sparktimise.config.loader import ConfigLoader  # noqa: PLC0415

        return ConfigLoader
    raise AttributeError(f"module 'sparktimise.config' has no attribute {name!r}")
