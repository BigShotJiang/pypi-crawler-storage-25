"""Config file readers and registry."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

from sparktimise.config.formats import (
    safe_load_ini_mapping_file,
    safe_load_json_mapping_file,
    safe_load_toml_mapping_file,
    safe_load_yaml_mapping_file,
)

ReaderFn = Callable[[Path], dict[str, Any]]


def read_yaml(path: Path) -> dict[str, Any]:
    """Read a YAML config file into a mapping."""
    return safe_load_yaml_mapping_file(path)


def read_json(path: Path) -> dict[str, Any]:
    """Read a JSON config file into a mapping."""
    return safe_load_json_mapping_file(path)


def read_ini(path: Path) -> dict[str, Any]:
    """Read an INI config file into a mapping."""
    return safe_load_ini_mapping_file(path)


def read_toml(path: Path) -> dict[str, Any]:
    """Read a TOML config file into a mapping."""
    return safe_load_toml_mapping_file(path)


DEFAULT_READERS: dict[str, ReaderFn] = {
    ".yaml": read_yaml,
    ".yml": read_yaml,
    ".json": read_json,
    ".ini": read_ini,
    ".toml": read_toml,
}


def get_default_readers() -> dict[str, ReaderFn]:
    """Return a copy of the default reader mapping."""
    return dict(DEFAULT_READERS)
