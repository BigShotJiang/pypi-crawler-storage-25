"""Data format parsing helpers.

Intentionally lightweight: load JSON/YAML/TOML/INI and enforce a mapping shape.
"""

from __future__ import annotations

import configparser
import json
from pathlib import Path
from typing import Any

import yaml

from sparktimise.errors import SparktimiseErrorHandler, ValidationError

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - py<3.11
    import tomli as tomllib  # noqa: F401


def load_json_config(text: str) -> dict[str, Any]:
    """Parse JSON content and require the top-level to be a mapping."""
    data = json.loads(text) or {}
    if not isinstance(data, dict):
        SparktimiseErrorHandler.raise_error(ValidationError(f"Expected JSON mapping, got {type(data)}."))
    return {str(key): value for key, value in data.items()}


def safe_load_json_mapping_file(path: Path) -> dict[str, Any]:
    """Load a JSON mapping from a file path."""
    return load_json_config(path.read_text(encoding="utf-8"))


def load_yaml_config(text: str) -> dict[str, Any]:
    """Parse YAML content and require the top-level to be a mapping."""
    data = yaml.safe_load(text) or {}
    if not isinstance(data, dict):
        SparktimiseErrorHandler.raise_error(ValidationError(f"Expected YAML mapping, got {type(data)}."))
    return {str(key): value for key, value in data.items()}


def safe_load_yaml_mapping_file(path: Path) -> dict[str, Any]:
    """Load a YAML mapping from a file path."""
    return load_yaml_config(path.read_text(encoding="utf-8"))


def load_toml_config(text: str) -> dict[str, Any]:
    """Parse TOML content and require the top-level to be a mapping."""
    data = tomllib.loads(text) or {}
    if not isinstance(data, dict):
        SparktimiseErrorHandler.raise_error(ValidationError(f"Expected TOML mapping, got {type(data)}."))
    return {str(key): value for key, value in data.items()}


def safe_load_toml_mapping_file(path: Path) -> dict[str, Any]:
    """Load a TOML mapping from a file path."""
    return load_toml_config(path.read_text(encoding="utf-8"))


def load_ini_config(text: str) -> dict[str, Any]:
    """Parse INI content and require the top-level to be a mapping."""
    parser = configparser.ConfigParser()
    parser.read_string(text)
    data: dict[str, Any] = {}
    defaults = dict(parser.defaults())
    if defaults:
        data["DEFAULT"] = defaults
    for section in parser.sections():
        data[section] = dict(parser[section])
    if not isinstance(data, dict):
        SparktimiseErrorHandler.raise_error(ValidationError(f"Expected INI mapping, got {type(data)}."))
    return data


def safe_load_ini_mapping_file(path: Path) -> dict[str, Any]:
    """Load an INI mapping from a file path."""
    return load_ini_config(path.read_text(encoding="utf-8"))
