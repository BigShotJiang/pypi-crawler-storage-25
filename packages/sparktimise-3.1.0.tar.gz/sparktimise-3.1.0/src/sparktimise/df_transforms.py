"""Low-cost DataFrame transformations applied during optimise mode."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from sparktimise.logger import get_logger
from sparktimise.thresholds import Thresholds

logger = get_logger(__name__)


@dataclass
class TransformResult:
    """Outcome of a single DataFrame transformation attempt."""

    applied: bool
    description: str
    df: Any
    metadata: dict[str, Any] = field(default_factory=dict)


def coalesce_after_filter(
    df: Any,
    *,
    thresholds: Thresholds,
    default_parallelism: int = 8,
) -> TransformResult:
    """Coalesce partitions when most are empty or undersized after a filter.

    Safe because coalesce never triggers a shuffle — it only combines
    existing partitions on the same executor.
    """
    try:
        current_partitions = int(df.rdd.getNumPartitions())
    except (AttributeError, TypeError, ValueError):
        return TransformResult(applied=False, description="", df=df)

    target = max(thresholds.partition_min, default_parallelism)

    if current_partitions <= target:
        return TransformResult(applied=False, description="", df=df)

    # Only coalesce if significantly over-partitioned (>2x target)
    if current_partitions < target * 2:
        return TransformResult(applied=False, description="", df=df)

    new_df = df.coalesce(target)
    desc = f"Coalesced from {current_partitions} to {target} partitions (no shuffle)."
    logger.debug(desc)
    return TransformResult(
        applied=True,
        description=desc,
        df=new_df,
        metadata={"previous_partitions": current_partitions, "new_partitions": target},
    )


def cache_reused_dataframe(
    df: Any,
    *,
    seen_hashes: set[str],
    plan_hash: str,
) -> TransformResult:
    """Cache a DataFrame whose plan hash has been seen before.

    A repeated plan hash means the same logical computation is being
    materialised multiple times — caching avoids recomputation.
    """
    if plan_hash not in seen_hashes:
        return TransformResult(applied=False, description="", df=df)

    # Check if already cached
    try:
        if df.is_cached:
            return TransformResult(applied=False, description="", df=df)
    except AttributeError:
        pass

    try:
        new_df = df.cache()
    except Exception:  # noqa: BLE001
        return TransformResult(applied=False, description="", df=df)

    desc = f"Cached reused DataFrame (plan_hash={plan_hash[:8]}…)."
    logger.debug(desc)
    return TransformResult(
        applied=True,
        description=desc,
        df=new_df,
        metadata={"plan_hash": plan_hash, "reason": "repeated_plan"},
    )


def add_broadcast_hint(
    df: Any,
    *,
    spark: Any,
    plan: str,
    thresholds: Thresholds,
    executor_memory_bytes: int,
) -> TransformResult:
    """Inject a broadcast hint on the smaller side of a SortMergeJoin.

    This is a no-op if:
    - No SortMergeJoin is detected in the plan
    - The DataFrame's estimated size exceeds the broadcast cap
    - The DataFrame has no statistics available

    The hint only suggests to the optimiser; it won't force broadcast if
    the table is too large at runtime.
    """
    if "SortMergeJoin" not in plan:
        return TransformResult(applied=False, description="", df=df)

    broadcast_cap = int(executor_memory_bytes * thresholds.executor_memory_broadcast_fraction)
    broadcast_cap = max(thresholds.broadcast_min_bytes, min(broadcast_cap, thresholds.broadcast_max_bytes))

    # Estimate DataFrame size from Catalyst statistics if available
    estimated_bytes = _estimate_df_size(df)
    if estimated_bytes is None or estimated_bytes > broadcast_cap:
        return TransformResult(applied=False, description="", df=df)

    try:
        from pyspark.sql.functions import broadcast  # noqa: PLC0415

        new_df = broadcast(df)
    except Exception:  # noqa: BLE001
        return TransformResult(applied=False, description="", df=df)

    desc = (
        f"Added broadcast hint (estimated {estimated_bytes // (1024 * 1024)}MB "
        f"< cap {broadcast_cap // (1024 * 1024)}MB)."
    )
    logger.debug(desc)
    return TransformResult(
        applied=True,
        description=desc,
        df=new_df,
        metadata={"estimated_bytes": estimated_bytes, "broadcast_cap": broadcast_cap},
    )


def repartition_skewed_key(
    df: Any,
    *,
    dominant_key_column: str | None,
    dominant_key_share: float | None,
    thresholds: Thresholds,
    default_parallelism: int = 8,
) -> TransformResult:
    """Repartition on the skewed column to distribute data more evenly.

    Triggers one shuffle but pays off on subsequent joins and aggregations
    by evening out partition sizes. Only applied when sample validation
    confirms skew above the threshold.
    """
    if dominant_key_column is None or dominant_key_share is None:
        return TransformResult(applied=False, description="", df=df)

    if dominant_key_share < thresholds.sample_skew_threshold:
        return TransformResult(applied=False, description="", df=df)

    target_partitions = max(thresholds.partition_min, default_parallelism * 2)

    try:
        new_df = df.repartition(target_partitions, dominant_key_column)
    except Exception:  # noqa: BLE001
        return TransformResult(applied=False, description="", df=df)

    desc = (
        f"Repartitioned on skewed column '{dominant_key_column}' "
        f"({dominant_key_share:.0%} dominant) into {target_partitions} partitions."
    )
    logger.debug(desc)
    return TransformResult(
        applied=True,
        description=desc,
        df=new_df,
        metadata={
            "skew_column": dominant_key_column,
            "dominant_share": dominant_key_share,
            "target_partitions": target_partitions,
        },
    )


def _estimate_df_size(df: Any) -> int | None:
    """Attempt to estimate DataFrame size in bytes from Catalyst stats."""
    try:
        size = df._jdf.queryExecution().optimizedPlan().stats().sizeInBytes()
        val = int(size)
        # Spark uses Long.MaxValue as "unknown"
        if val > 0 and val < 2**62:
            return val
    except Exception:  # noqa: BLE001
        pass
    return None
