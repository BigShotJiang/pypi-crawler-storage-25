"""Profiler hook for automatic DataFrame capture via sys.setprofile."""

from __future__ import annotations

import fnmatch
from pathlib import Path
from types import FrameType
from typing import Any

from sparktimise.logger import get_logger

logger = get_logger(__name__)


def frame_qualified_name(frame: FrameType) -> str:
    """Build a module or class qualified function name for a frame."""
    module_name = str(frame.f_globals.get("__name__", "<unknown_module>"))
    function_name = frame.f_code.co_name
    self_obj = frame.f_locals.get("self")
    cls_obj = frame.f_locals.get("cls")

    if self_obj is not None:
        return f"{module_name}.{self_obj.__class__.__name__}.{function_name}"
    if cls_obj is not None and hasattr(cls_obj, "__name__"):
        return f"{module_name}.{cls_obj.__name__}.{function_name}"
    return f"{module_name}.{function_name}"


class PlanProfiler:
    """Filters and dispatches DataFrame return events to an assessment callback.

    The profiler is installed via ``sys.setprofile`` and decides which frames
    belong to user pipeline code (vs. library internals).  The actual
    assessment logic is injected via *on_capture* so the profiler has no
    dependency on the tuner or recommendation engine.
    """

    def __init__(
        self,
        *,
        watched_functions: set[str],
        watched_modules: list[str],
        on_capture: Any,
        is_dataframe: Any,
    ) -> None:
        self._watched_functions = watched_functions
        self._watched_modules = watched_modules
        self._on_capture = on_capture
        self._is_dataframe = is_dataframe

    def __call__(self, frame: FrameType, event: str, arg: Any) -> None:
        """sys.setprofile callback."""
        if event != "return" or not self._is_dataframe(arg):
            return

        qualified_name = frame_qualified_name(frame)
        if not self._should_watch(qualified_name):
            logger.debug("Profiler skipped %s (not in watch list)", qualified_name)
            return
        if not self._watched_functions and not self._watched_modules and not self._is_pipeline_frame(frame):
            logger.debug(
                "Profiler skipped %s (not recognised as pipeline code: %s)",
                qualified_name,
                frame.f_code.co_filename,
            )
            return

        self._on_capture(
            qualified_name,
            arg,
            source_file=str(Path(frame.f_code.co_filename)),
            source_line=int(frame.f_code.co_firstlineno),
        )

    def _should_watch(self, qualified_function_name: str) -> bool:
        if not self._watched_functions and not self._watched_modules:
            return True
        if qualified_function_name in self._watched_functions:
            return True
        if any(fnmatch.fnmatch(qualified_function_name, pat) for pat in self._watched_functions):
            return True
        return any(
            qualified_function_name == prefix or qualified_function_name.startswith(f"{prefix}.")
            for prefix in self._watched_modules
        )

    @staticmethod
    def _is_pipeline_frame(frame: FrameType) -> bool:
        """Return whether a frame likely belongs to user pipeline code."""
        module_name = str(frame.f_globals.get("__name__", ""))
        if module_name.startswith(("pyspark", "py4j", "sparktimise")):
            return False

        filename = Path(frame.f_code.co_filename)
        lower = str(filename).lower().replace("\\", "/")
        if "site-packages" in lower or "/lib/" in lower:
            return False

        if module_name == "__main__" or "<ipython-input" in lower or lower.startswith("<stdin"):
            return True

        if filename.suffix == ".py":
            return True

        try:
            return filename.resolve().is_relative_to(Path.cwd().resolve())
        except (OSError, ValueError):
            return False
